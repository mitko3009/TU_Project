базата с данни - масивър с информация архивирън
дейтабейс мениджмънт софтуер (замества човека от римско време в библиотеката)
дейтабейс администратори и разработчици
табличен вид с редове и колони.Релационни бази с данни(свързват и таблици)
таблици - основния логически компонент
view - административни и апликейшън вюта (групирани неща от различни таблици и колони ,за да покаже търсената информация
index - за подобряване на пърформънса

plsql -  за порограмиране на оръкал
sql - езика , с който оправляваме базата данни

relational database management software - RDBMS 

enterprise edition - пълна версия кооперативна,всичко което може да ти даде Oracle

oracle base (/u01/app/oracle)= Локация където ние ще съхраняваме нашият софтуер

oracle home (/u01/app/oracle/product/11.2.0/db_1 - съдържа всички байнарита на базата
inventory directory - описани всички исталации и зададени къдет точно ще се съграняват

dbca - database configuration assistant 

системни акаунт:
SYS
SYSTEM
SYSMAN
и др.


$ORACLE_BASE/oradata - тук съхраняваме дейта файлове

redo log i controlfiles

flash_recovery_area - мястото където съхраняваме нащите рекавър файлове,начите архивирани копия на нашите redo logs
Всичко нужно за възтановяване идва тука

system global area
memory global area



desc dba_data_files
desc dba_tablespaces
desc v$instance
desc v$database
desc v$version
desc v$logfile
desc v$log


чекваме в google


## Academy
UNDO

select to_char(begin_time, 'DD-MON-RR HH24:MI') begin_time,
to_char(end_time, 'DD-MON-RR HH24:MI') end_time, tuned_undoretention
from v$undostat order by end_time;

###
select file_id,FILE_NAME, TABLESPACE_NAME, BYTES/1024/1024, MAXBYTES/1024/1024, AUTOEXTENSIBLE from dba_data_files where TABLESPACE_NAME='&tablespace_name';


######################
ОЕМ -oracle enterprice manager
от него се деплойват по сървърите, римоут, агенти
сетваш си в ОЕМ за тоя сървър/база определени неща да мониторва и тва е
агента праща информацията на ОЕМ-а
няма файлове, няма нищо