#### Качвам се на базата и проверявам за  processes ans sessions ######

SQL> select * from v$resource_limit;

RESOURCE_NAME                  CURRENT_UTILIZATION MAX_UTILIZATION INITIAL_AL LIMIT_VALU
------------------------------ ------------------- --------------- ---------- ----------
processes                                       98             300        300        300
sessions                                        95             325        600        600
enqueue_locks                                   72             315       7360       7360
enqueue_resources                               42             201       2860  UNLIMITED
ges_procs                                        0               0          0          0
ges_ress                                         0               0          0  UNLIMITED
ges_locks                                        0               0          0  UNLIMITED
ges_cache_ress                                   0               0          0  UNLIMITED
ges_reg_msgs                                     0               0          0  UNLIMITED
ges_big_msgs                                     0               0          0  UNLIMITED
ges_rsv_msgs                                     0               0          0          0
gcs_resources                                    0               0  UNLIMITED  UNLIMITED
gcs_shadows                                      0               0  UNLIMITED  UNLIMITED
smartio_overhead_memory                          0           71704          0  UNLIMITED
smartio_buffer_memory                            0               0          0  UNLIMITED
smartio_metadata_memory                          0               0          0  UNLIMITED
smartio_sessions                                 0               1          0  UNLIMITED
dml_locks                                        0            1052       2640  UNLIMITED
temporary_table_locks                            0               9  UNLIMITED  UNLIMITED
transactions                                     0              33        660  UNLIMITED
branches                                         0               0        660  UNLIMITED
cmtcallbk                                        0              16        660  UNLIMITED
max_rollback_segments                           22              23        660      65535
sort_segment_locks                               3              40  UNLIMITED  UNLIMITED
k2q_locks                                        0               0       1200  UNLIMITED
max_shared_servers                               1               1  UNLIMITED  UNLIMITED
parallel_max_servers                            16              16        270       3600

##### Check za Inactive sessions ######
=========================================================================================================================

select SID, SERIAL#, USERNAME, SCHEMANAME, MACHINE, PROGRAM, STATUS from gv$session where STATUS='INACTIVE';

select SID, SERIAL#, USERNAME, SCHEMANAME, MACHINE, PROGRAM, STATUS from gv$session where USERNAME='VNGUSR' and STATUS='INACTIVE';


SQL> set lines 666
SQL> /

       SID    SERIAL# USERNAME                       SCHEMANAME                     MACHINE                                                          PROGRAM                                          STATUS
---------- ---------- ------------------------------ ------------------------------ ---------------------------------------------------------------- ------------------------------------------------ --------
         6       8493 FISCAL                         FISCAL                         630330e2f90a                                                     JDBC Thin Client                                 INACTIVE
         7      44877 FISCAL                         FISCAL                         CORP\W1538                                                       sfiscm.exe                                       INACTIVE
         8      24317 FISCAL                         FISCAL                         CORP\W1214                                                       plsqldev.exe                                     INACTIVE
        10      55803 SCONN                          SCONN                          W1214                                                            JDBC Thin Client                                 INACTIVE
        11      48079 FISCAL                         FISCAL                         CORP\W1538                                                       DOF.EXE                                          INACTIVE
        16      56185 FISCAL                         FISCAL                         CORP\W1214                                                       DOF.EXE                                          INACTIVE
        19      61545 FISCAL                         FISCAL                         CORP\W1538                                                       sfiscm.exe                                       INACTIVE
        22      29497 FISCAL                         FISCAL                         CORP\W1538                                                       sfiscm.exe                                       INACTIVE
        23      11439 FISCAL                         FISCAL                         630330e2f90a                                                     JDBC Thin Client                                 INACTIVE
        24      40533 FISCAL                         FISCAL                         CORP\W1214                                                       plsqldev.exe                                     INACTIVE
        30       3341 FISCAL                         FISCAL                         630330e2f90a                                                     JDBC Thin Client                                 INACTIVE



#### KILL ALL Inactive sessions #####

select 'ALTER SYSTEM KILL SESSION '||''''||sid||','||serial#||',@'||inst_id||''' IMMEDIATE;' from gv$session where STATUS='INACTIVE';

select 'ALTER SYSTEM KILL SESSION '||''''||sid||','||serial#||',@'||inst_id||''' IMMEDIATE;' from gv$session where USERNAME='VNGUSR' and STATUS='INACTIVE';


SQL> set pagesize 200
SQL> /

'ALTERSYSTEMKILLSESSION'||''''||SID||','||SERIAL#||',@'||INST_ID||'''IMMEDIATE;'
------------------------------------------------------------------------------------------------------------------------------------------------------------------
ALTER SYSTEM KILL SESSION '6,8493,@1' IMMEDIATE;
ALTER SYSTEM KILL SESSION '7,44877,@1' IMMEDIATE;
ALTER SYSTEM KILL SESSION '8,24317,@1' IMMEDIATE;
ALTER SYSTEM KILL SESSION '10,55803,@1' IMMEDIATE;
ALTER SYSTEM KILL SESSION '11,48079,@1' IMMEDIATE;
ALTER SYSTEM KILL SESSION '16,56185,@1' IMMEDIATE;
ALTER SYSTEM KILL SESSION '19,61545,@1' IMMEDIATE;
ALTER SYSTEM KILL SESSION '22,29497,@1' IMMEDIATE;
ALTER SYSTEM KILL SESSION '23,11439,@1' IMMEDIATE;
ALTER SYSTEM KILL SESSION '24,40533,@1' IMMEDIATE;
ALTER SYSTEM KILL SESSION '30,3343,@1' IMMEDIATE;
ALTER SYSTEM KILL SESSION '37,56431,@1' IMMEDIATE;
ALTER SYSTEM KILL SESSION '39,40093,@1' IMMEDIATE;
ALTER SYSTEM KILL SESSION '40,26727,@1' IMMEDIATE;
ALTER SYSTEM KILL SESSION '42,3047,@1' IMMEDIATE;
ALTER SYSTEM KILL SESSION '83,17511,@1' IMMEDIATE;
ALTER SYSTEM KILL SESSION '84,61709,@1' IMMEDIATE;
ALTER SYSTEM KILL SESSION '85,17697,@1' IMMEDIATE;
ALTER SYSTEM KILL SESSION '87,43643,@1' IMMEDIATE;
ALTER SYSTEM KILL SESSION '89,56265,@1' IMMEDIATE;
ALTER SYSTEM KILL SESSION '94,16615,@1' IMMEDIATE;
ALTER SYSTEM KILL SESSION '95,34557,@1' IMMEDIATE;
ALTER SYSTEM KILL SESSION '96,42499,@1' IMMEDIATE;
ALTER SYSTEM KILL SESSION '98,22549,@1' IMMEDIATE;
ALTER SYSTEM KILL SESSION '99,32067,@1' IMMEDIATE;


#### Копирам ги и ги пействам пак, ако не стане правя spool и го изпълнявам като script $#####

SQL> spool pesho.sql                                         ### izmislqm si ime i tova se zapametqva v osnovnata direktoriq na oracle #####
SQL> select 'ALTER SYSTEM KILL SESSION '||''''||sid||','||serial#||',@'||inst_id||''' IMMEDIATE;' from gv$session where STATUS='INACTIVE';  ### sled tova runvam kakvo iskam da mi spoolva ####
SQL> !vi pe602.sql

##### И ЗАДЪЛЖИТЕЛНО ДАВАМ ####  ЗА ДА СПРА SPOOL-ВАНЕТО!!!!!
SQL> spool off


 
