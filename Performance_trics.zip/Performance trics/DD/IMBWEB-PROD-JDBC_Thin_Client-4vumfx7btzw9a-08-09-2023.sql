/********************************************************************************
*********       E-mail subject: IMBWEB-7343
*********             Instance: PROD
*********          Description: 
Problem:
Limit Real Time Report took more than one and a half hour on PROD on 04/09/2023.

Analysis:
After the investigation, we found that the slowness comes from three SQLs (with sql_id: 4vumfx7btzw9a, 50p4mv1p0u17b, 12q3a5c5b9zpc) in JDBC Thin Client module.
The problem was that Oracle was using inappropriate index access.

Suggestion:
1. Please set module for this report: https://tervel.codixfr.private/wiki/index.php/How_to_set_MODULE,_CLIENT_IDENTIFIER_and_ACTION_in_SQL*Plus

2. Please add hints and in SQLs with sql_id 4vumfx7btzw9a and 50p4mv1p0u17b change the column by which the data for :B1 and :B2 is accessed 
   as it is shown in the New SQL section below.

*********               SQL_ID: 4vumfx7btzw9a, 50p4mv1p0u17b, 12q3a5c5b9zpc
*********      Program/Package: Limit Real Time Report
*********              Request: Dimitare Ivanov
*********               Author: Dimitar Dimitrov
********* Received e-mail date: 07/09/2023
*********      Resolution date: 08/09/2023
*********  Trace old file here: \\epox\specifs\performance\tmp\
*********  Trace new file here:
***********************************************************************************/

/********************************OLD SQL*******************************************/
-- 4vumfx7btzw9a

var B1 varchar2(32);
EXEC :B1  := 'A600ESEI';
var B2 varchar2(32);
EXEC :B2  := 'A600J4B1';
var B3 varchar2(32);
EXEC :B3  := 'S';
var B4 varchar2(32);
EXEC :B4  := '';
var B5 varchar2(32);
EXEC :B5  := '';
var B6 varchar2(32);
EXEC :B6  := 'A';
var B7 number;
EXEC :B7  := 0;

SELECT TO_CHAR(DECODE(SUM(DECODE(:B6, 'A', NVL(RL.F_LIM_AMT, 0), NULL)),
                      NULL,
                      NULL,
                      TO_CHAR(CH_TAUX.CONV_ORIG_DEST_TX(TO_CHAR(SYSDATE, 'J'),
                                                        SUM(DECODE(:B6,
                                                                   'A',
                                                                   NVL(RL.F_LIM_AMT,
                                                                       0),
                                                                   0)),
                                                        MAX(DECODE(:B6,
                                                                   'A',
                                                                   RL.F_LIM_AMT_CCY,
                                                                   :B5)),
                                                        MAX(:B5),
                                                        'MR')))) AS RECOURSE_LIM,
       DECODE(SUM(DECODE(:B6, 'A', NVL(RL.F_LIM_AMT, 0), NULL)),
              NULL,
              NULL,
              MAX(:B5)) AS REC_LIM_CCY,
       DECODE(SUM(DECODE(:B6, 'S', NVL(RL.F_LIM_AMT, 0), NULL)),
              NULL,
              NULL,
              TO_CHAR(CH_TAUX.CONV_ORIG_DEST_TX(TO_CHAR(SYSDATE, 'J'),
                                                SUM(DECODE(:B6,
                                                           'S',
                                                           NVL(RL.F_LIM_AMT, 0),
                                                           0)),
                                                MAX(DECODE(:B6,
                                                           'S',
                                                           RL.F_LIM_AMT_CCY,
                                                           :B5)),
                                                MAX(:B5),
                                                'MR'))) AS NON_REC_LIM,
       DECODE(SUM(DECODE(:B6, 'S', NVL(RL.F_LIM_AMT, 0), NULL)),
              NULL,
              NULL,
              MAX(:B5)) AS NON_REC_LIM_CCY,
       DECODE(SUM(DECODE(:B6, 'A', NVL(RL.F_LIM_AMT, 0), NULL)),
              NULL,
              NULL,
              TO_CHAR(CH_TAUX.CONV_ORIG_DEST_TX(TO_CHAR(SYSDATE, 'J'),
                                                SUM(DECODE(:B6,
                                                           'A',
                                                           (NVL(RL.F_LIM_CONSUM,
                                                                0) +
                                                           NVL(:B7, 0)),
                                                           0)),
                                                MAX(RL.F_LIM_AMT_CCY),
                                                MAX(:B5),
                                                'MR'))) AS CONSUMP_F_LIM_REC,
       DECODE(SUM(DECODE(:B6, 'S', NVL(RL.F_LIM_AMT, 0), NULL)),
              NULL,
              NULL,
              TO_CHAR(CH_TAUX.CONV_ORIG_DEST_TX(TO_CHAR(SYSDATE, 'J'),
                                                SUM(DECODE(:B6,
                                                           'S',
                                                           NVL(RL.F_LIM_CONSUM,
                                                               0),
                                                           0)),
                                                MAX(RL.F_LIM_AMT_CCY),
                                                MAX(:B5),
                                                'MR'))) AS CONSUMP_F_LIM_NREC,
       TO_CHAR(MAX(CASE
                     WHEN :B4 IS NOT NULL AND :B3 = 'S' THEN
                      RL.F_LIM_CONSUM
                     ELSE
                      CASE
                        WHEN :B4 IS NOT NULL AND :B3 = 'S' THEN
                         RL.F_LIM_CONSUM
                        ELSE
                         0
                      END
                   END)) AS CONSUMP_F_LIM_NREC_APF,
       TO_CHAR(MAX(F_LIM_AMT_CHECK)) AS F_LIM_AMT_CHECK,
       TO_CHAR(MAX(F_LIM_AMT_CCY)) AS F_LIM_AMT_CCY,
       TO_CHAR(MAX(F_LIM_CONSUM)) AS VC_F_LIM_CONSUM
  FROM (SELECT DISTINCT DECODE(LIM.TYPEDOC, 'F', LIM.MT02, NULL) AS F_LIM_AMT,
                        DECODE(LIM.TYPEDOC, 'F', CLIM.CONSUMMED_AMT, NULL) AS F_LIM_CONSUM,
                        DECODE(LIM.TYPEDOC, 'F', LIM.MT02, NULL) AS F_LIM_AMT_CHECK,
                        DECODE(LIM.TYPEDOC, 'F', LIM.GPIDEVIS, '') AS F_LIM_AMT_CCY,
                        LIM.REFPIECE
          FROM G_PIECE LIM,
               G_PIECE PLIM,
               (SELECT LIMIT_ID, SUM(CONSUMED_LIM) AS CONSUMMED_AMT
                  FROM G_VENFILIMIT
                 GROUP BY LIMIT_ID) CLIM,
               G_PIECE POL,
               T_INTERVENANTS IPOL,
               T_INTERVENANTS TDB,
               T_INTERVENANTS CL,
               G_DOSSIER CMPT
         WHERE LIM.TYPPIECE = 'REQUEST_LIMITE'
           AND LIM.FG05 = 'O'
           AND LIM.TYPEDOC IN ('F', 'C')
           AND LIM.GPIROLE IN ('DT', 'DC')
           AND PLIM.TYPPIECE(+) = 'PARAM_LIMITE'
           AND PLIM.REFPIECE(+) = LIM.LIBELLE_20_12
           AND CLIM.LIMIT_ID(+) = PLIM.REFPIECE
           AND POL.TYPPIECE(+) = 'POLICE'
           AND POL.REFPIECE(+) = LIM.LIBELLE_100_8
           AND IPOL.REFDOSS(+) = POL.REFDOSS
           AND IPOL.REFTYPE(+) = 'CL'
           AND TDB.REFINDIVIDU = LIM.GPIADR3
           AND TDB.REFTYPE = 'DB'
           AND CL.REFDOSS = TDB.REFDOSS
           AND CL.REFINDIVIDU = LIM.GPIDEPOT
           AND CL.REFTYPE = 'CL'
           AND CL.REFDOSS = CMPT.REFDOSS
           AND LIM.GPIADR3 = :B2
           AND CL.REFINDIVIDU = :B1) RL;


-- 50p4mv1p0u17b

var B1 varchar2(32);
EXEC :B1  := 'A600ERTG';
var B2 varchar2(32);
EXEC :B2  := 'A600I60L';
var B3 varchar2(32);
EXEC :B3  := 'A600I60L';
var B4 varchar2(32);
EXEC :B4  := 'A600I60L';
var B5 varchar2(32);
EXEC :B5  := 'A600I60L';
var B6 varchar2(32);
EXEC :B6  := 'A600I60L';
var B7 number;
EXEC :B7  := ;

SELECT TO_CHAR(SUM(F_LIMIT)) AS TOT_F_LIM_CONSUM
  FROM (SELECT DISTINCT CH_TAUX.CONV_ORIG_DEST_TX(TO_CHAR(SYSDATE, 'J'),
                                                  NVL(LIM.MT02, 0),
                                                  LIM.GPIDEVIS,
                                                  PBU.GPIDEVIS,
                                                  'MR') F_LIMIT,
                        LIM.REFPIECE
          FROM G_PIECE LIM,
               G_PIECE PLIM,
               (SELECT LIMIT_ID, SUM(CONSUMED_LIM) AS CONSUMMED_AMT
                  FROM G_VENFILIMIT
                 GROUP BY LIMIT_ID) CLIM,
               G_DOSSIER CMPT,
               G_DOSSIER DCMPT,
               G_PIECE PBU,
               T_INTERVENANTS TDB,
               T_INTERVENANTS CL
         WHERE LIM.TYPPIECE = 'REQUEST_LIMITE'
           AND LIM.FG05 = 'O'
           AND LIM.TYPEDOC = 'F'
           AND LIM.GPIROLE IN ('DT', 'DC')
           AND PLIM.TYPPIECE(+) = 'PARAM_LIMITE'
           AND PLIM.REFPIECE(+) = LIM.LIBELLE_20_12
           AND CLIM.LIMIT_ID(+) = PLIM.REFPIECE
           AND LIM.GPIADR3 = :B2
           AND TDB.REFINDIVIDU = LIM.GPIADR3
           AND TDB.REFTYPE = 'DB'
           AND CL.REFDOSS = TDB.REFDOSS
           AND CL.REFINDIVIDU = LIM.GPIDEPOT
           AND CL.REFTYPE = 'CL'
           AND CL.REFDOSS = CMPT.REFDOSS
           AND CL.REFINDIVIDU = :B1
           AND DCMPT.REFDOSS = CMPT.REFLOT
           AND PBU.REFPIECE(+) = DCMPT.REFFACTOR
           AND PBU.TYPPIECE(+) = 'FACTOR');


-- 12q3a5c5b9zpc

var B1 varchar2(32);
EXEC :B1  := 'A600I60L';
var B2 varchar2(32);
EXEC :B2  := 'A600I60L';
var B3 varchar2(32);
EXEC :B3  := '';
var B4 varchar2(32);
EXEC :B4  := '';
var B5 varchar2(32);
EXEC :B5  := '';
var B6 varchar2(32);
EXEC :B6  := '';
var B7 varchar2(32);
EXEC :B7  := '';
var B8 varchar2(32);
EXEC :B8  := '';
var B9 varchar2(32);
EXEC :B9  := '';
var B10 varchar2(32);
EXEC :B10  := '';
var B11 varchar2(32);
EXEC :B11  := '';

SELECT NVL(LIM.MT02, 0) AS DB_GLOB_LIM_GFL,
       LIM.GPIDEVIS AS GFL_CCY,
       LIM.COMMENTAIRE,
       CASE
         WHEN (:B11 IS NULL OR :B11 = 'no limit defined') AND
              (:B10 IS NULL OR :B10 = 'no limit defined') AND :B9 IS NULL THEN
          'no limit defined'
         ELSE
          TO_CHAR(CASE
                    WHEN TO_CHAR(:B8) <> 'no limit defined' THEN
                     NVL(CH_TAUX.CONV_ORIG_DEST_TX(TO_CHAR(SYSDATE, 'j'),
                                                   NVL(:B8, 0),
                                                   :B7,
                                                   :B2,
                                                   'MR',
                                                   ''),
                         0)
                    ELSE
                     0
                  END + CASE
                    WHEN TO_CHAR(:B6) <> 'no limit defined' THEN
                     NVL(CH_TAUX.CONV_ORIG_DEST_TX(TO_CHAR(SYSDATE, 'j'),
                                                   NVL(:B6, 0),
                                                   :B5,
                                                   :B2,
                                                   'MR',
                                                   ''),
                         0)
                    ELSE
                     0
                  END + CASE
                    WHEN TO_CHAR(:B4) <> 'no limit defined' THEN
                     NVL(CH_TAUX.CONV_ORIG_DEST_TX(TO_CHAR(SYSDATE, 'j'),
                                                   :B4,
                                                   :B3,
                                                   :B2,
                                                   'MR',
                                                   ''),
                         0)
                    ELSE
                     0
                  END)
       END AS CONSUMP_GFL
  FROM G_PIECE LIM
 WHERE LIM.TYPPIECE = 'REQUEST_LIMITE'
   AND LIM.FG05 = 'O'
   AND LIM.TYPEDOC = 'GFL'
   AND LIM.GPIROLE IN ('DT', 'DC')
   AND LIM.GPIADR3 = :B1;

/********************************OLD SQL*******************************************/
/********************************OLD Metrics***************************************/
/*

MODULE                           SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
JDBC Thin Client                 4vumfx7btzw9a 1824791463       2186      22422                      2023/09/04 10:32:47  2023/09/04 12:03:42         180                  693 +000000000 01:30:54.912 33%
JDBC Thin Client                 50p4mv1p0u17b 3191538885       2186      22422 ON CPU               2023/09/04 10:33:18  2023/09/04 12:04:03         179                  692 +000000000 01:30:44.672 33%
JDBC Thin Client                 12q3a5c5b9zpc 1558150397       2186      22422 ON CPU               2023/09/04 10:32:57  2023/09/04 12:03:52         174                  693 +000000000 01:30:54.912 32%
JDBC Thin Client                 1nbmpwd0krsnp 4093145175       2186      22422                      2023/09/04 10:31:15  2023/09/04 10:32:37           9                    1 +000000000 00:01:22.303 2%
JDBC Thin Client                 dqpmqy1f98fj5                  2186      22422                      2023/09/04 10:39:58  2023/09/04 11:30:53           2                    1 +000000000 00:50:55.424 0%
JDBC Thin Client                 f9q4u2ukyvh5p 3048453407       2186      22422 ON CPU               2023/09/04 10:31:04  2023/09/04 10:31:04           1                    1 +000000000 00:00:00.000 0%


-- 4vumfx7btzw9a


Plan hash value: 1824791463
-----------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                       | Name                      | Rows  | Bytes | Cost (%CPU)| Time     |
-----------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                                |                           |       |       |     8 (100)|          |
|   1 |  SORT AGGREGATE                                 |                           |     1 |   101 |            |          |
|   2 |   VIEW                                          |                           |     1 |   101 |     8  (13)| 00:00:01 |
|   3 |    HASH UNIQUE                                  |                           |     1 |   254 |     8  (13)| 00:00:01 |
|   4 |     HASH GROUP BY                               |                           |     1 |   254 |     8  (13)| 00:00:01 |
|   5 |      NESTED LOOPS OUTER                         |                           |     1 |   254 |     7   (0)| 00:00:01 |
|   6 |       NESTED LOOPS                              |                           |     1 |   227 |     6   (0)| 00:00:01 |
|   7 |        NESTED LOOPS OUTER                       |                           |     1 |   191 |     5   (0)| 00:00:01 |
|   8 |         NESTED LOOPS OUTER                      |                           |     1 |   179 |     4   (0)| 00:00:01 |
|   9 |          NESTED LOOPS OUTER                     |                           |     1 |   146 |     3   (0)| 00:00:01 |
|  10 |           MERGE JOIN CARTESIAN                  |                           |     1 |   105 |     2   (0)| 00:00:01 |
|  11 |            INDEX RANGE SCAN                     | INT_INDIV                 |     1 |    36 |     1   (0)| 00:00:01 |
|  12 |            BUFFER SORT                          |                           |     1 |    69 |     1   (0)| 00:00:01 |
|  13 |             INLIST ITERATOR                     |                           |       |       |            |          |
|  14 |              TABLE ACCESS BY INDEX ROWID BATCHED| G_PIECE                   |     1 |    69 |     1   (0)| 00:00:01 |
|  15 |               INDEX RANGE SCAN                  | G_PIECE$ID_VENTE          |     8 |       |     1   (0)| 00:00:01 |
|  16 |           TABLE ACCESS BY INDEX ROWID BATCHED   | G_PIECE                   |     1 |    41 |     1   (0)| 00:00:01 |
|  17 |            INDEX RANGE SCAN                     | PIE_REFPIECE              |     1 |       |     1   (0)| 00:00:01 |
|  18 |          TABLE ACCESS BY INDEX ROWID BATCHED    | G_PIECE                   |     1 |    33 |     1   (0)| 00:00:01 |
|  19 |           INDEX RANGE SCAN                      | PIE_REFPIECE              |     1 |       |     1   (0)| 00:00:01 |
|  20 |         TABLE ACCESS BY INDEX ROWID BATCHED     | G_VENFILIMIT              |   236 |  2832 |     1   (0)| 00:00:01 |
|  21 |          INDEX RANGE SCAN                       | G_VENFILIMIT$LIMIT_ID_IDX |   382 |       |     1   (0)| 00:00:01 |
|  22 |        INDEX RANGE SCAN                         | INT_INDIV                 |     1 |    36 |     1   (0)| 00:00:01 |
|  23 |       INDEX RANGE SCAN                          | INT_REFDOSS               |     1 |    27 |     1   (0)| 00:00:01 |
-----------------------------------------------------------------------------------------------------------------------------


INSTANCE_NUMBER SQL_ID            ELAPSED MAX_WAIT_ON     PC_OF  WAIT_TIME            GETS      READS       ROWS  ELAP/EXEC       GETS/EXEC READS/EXEC  ROWS/EXEC       EXEC PLAN_HASH_VALUE
--------------- ------------- ----------- --------------- ----- ---------- --------------- ---------- ---------- ---------- --------------- ---------- ---------- ---------- ---------------
              2 4vumfx7btzw9a       10348 CPU             95%   10085.5849      6661637258    1501432       3760       2.75         1771241     399.21          1       3761      1824791463
              1 4vumfx7btzw9a        8202 CPU             96%     8031.313      5445886806     995764       3093       2.65         1761853     322.15          1       3091      1824791463
              1 4vumfx7btzw9a        3529 CPU             87%   3502.87263      2170566672    1467005       1213       2.91         1789420     1209.4          1       1213      2156230183
              2 4vumfx7btzw9a        1784 IO              52%   1909.55694       482312418    3344132        274       6.53         1766712   12249.57          1        273      2156230183




SQL_ID        SQL_PLAN_HASH_VALUE SQL_PLAN_LINE_ID SQL_PLAN_OPERATION             SQL_PLAN_OPTIONS                   ACTIVE
------------- ------------------- ---------------- ------------------------------ ------------------------------ ----------
4vumfx7btzw9a                   0                  SELECT STATEMENT                                                       1
4vumfx7btzw9a          1824791463               14 TABLE ACCESS                   BY INDEX ROWID BATCHED               1746
4vumfx7btzw9a          1824791463               15 INDEX                          RANGE SCAN                            132
4vumfx7btzw9a          1824791463                                                                                         6
4vumfx7btzw9a          1824791463                1 SORT                           AGGREGATE                               2
4vumfx7btzw9a          2156230183               14 TABLE ACCESS                   BY INDEX ROWID BATCHED                498
4vumfx7btzw9a          2156230183               15 INDEX                          RANGE SCAN                             31
4vumfx7btzw9a          2156230183                                                                                         1


-- 50p4mv1p0u17b


Plan hash value: 3191538885
---------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                     | Name                      | Rows  | Bytes | Cost (%CPU)| Time     |
---------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                              |                           |       |       |     9 (100)|          |
|   1 |  SORT AGGREGATE                               |                           |     1 |    13 |            |          |
|   2 |   VIEW                                        |                           |     1 |    13 |     9  (12)| 00:00:01 |
|   3 |    HASH UNIQUE                                |                           |     1 |   282 |     9  (12)| 00:00:01 |
|   4 |     HASH GROUP BY                             |                           |     1 |   282 |     9  (12)| 00:00:01 |
|   5 |      NESTED LOOPS OUTER                       |                           |     1 |   282 |     8   (0)| 00:00:01 |
|   6 |       NESTED LOOPS OUTER                      |                           |     1 |   273 |     7   (0)| 00:00:01 |
|   7 |        NESTED LOOPS OUTER                     |                           |     1 |   240 |     6   (0)| 00:00:01 |
|   8 |         MERGE JOIN CARTESIAN                  |                           |     1 |   205 |     5   (0)| 00:00:01 |
|   9 |          NESTED LOOPS                         |                           |     1 |   138 |     4   (0)| 00:00:01 |
|  10 |           NESTED LOOPS                        |                           |     1 |   138 |     4   (0)| 00:00:01 |
|  11 |            NESTED LOOPS                       |                           |     1 |   106 |     3   (0)| 00:00:01 |
|  12 |             NESTED LOOPS                      |                           |     1 |    72 |     2   (0)| 00:00:01 |
|  13 |              INDEX RANGE SCAN                 | INT_INDIV                 |     1 |    36 |     1   (0)| 00:00:01 |
|  14 |              INDEX RANGE SCAN                 | INT_INDIV                 |     1 |    36 |     1   (0)| 00:00:01 |
|  15 |             INDEX RANGE SCAN                  | DOS_REFDOSS_REFLOT_IDX    |     1 |    34 |     1   (0)| 00:00:01 |
|  16 |            INDEX UNIQUE SCAN                  | DOS_REFDOSS               |     1 |       |     1   (0)| 00:00:01 |
|  17 |           TABLE ACCESS BY INDEX ROWID         | G_DOSSIER                 |     1 |    32 |     1   (0)| 00:00:01 |
|  18 |          BUFFER SORT                          |                           |     1 |    67 |     4   (0)| 00:00:01 |
|  19 |           INLIST ITERATOR                     |                           |       |       |            |          |
|  20 |            TABLE ACCESS BY INDEX ROWID BATCHED| G_PIECE                   |     1 |    67 |     1   (0)| 00:00:01 |
|  21 |             INDEX RANGE SCAN                  | G_PIECE$ID_VENTE          |     8 |       |     1   (0)| 00:00:01 |
|  22 |         TABLE ACCESS BY INDEX ROWID BATCHED   | G_PIECE                   |     1 |    35 |     1   (0)| 00:00:01 |
|  23 |          INDEX RANGE SCAN                     | PIE_REFPIECE              |     1 |       |     1   (0)| 00:00:01 |
|  24 |        TABLE ACCESS BY INDEX ROWID BATCHED    | G_PIECE                   |     1 |    33 |     1   (0)| 00:00:01 |
|  25 |         INDEX RANGE SCAN                      | PIE_REFPIECE              |     1 |       |     1   (0)| 00:00:01 |
|  26 |       INDEX RANGE SCAN                        | G_VENFILIMIT$LIMIT_ID_IDX |   236 |  2124 |     1   (0)| 00:00:01 |
---------------------------------------------------------------------------------------------------------------------------


INSTANCE_NUMBER SQL_ID            ELAPSED MAX_WAIT_ON     PC_OF  WAIT_TIME            GETS      READS       ROWS  ELAP/EXEC       GETS/EXEC READS/EXEC  ROWS/EXEC       EXEC PLAN_HASH_VALUE
--------------- ------------- ----------- --------------- ----- ---------- --------------- ---------- ---------- ---------- --------------- ---------- ---------- ---------- ---------------
              2 50p4mv1p0u17b       11646 CPU             92%   11464.4636      7152071726    2740060       4039       2.89         1772069      678.9          1       4036      3191538885
              1 50p4mv1p0u17b       10937 CPU             100%  10641.6823      7594334509        189       4294       2.55         1768592        .04          1       4294      3191538885
     

SQL_ID        SQL_PLAN_HASH_VALUE SQL_PLAN_LINE_ID SQL_PLAN_OPERATION             SQL_PLAN_OPTIONS                   ACTIVE
------------- ------------------- ---------------- ------------------------------ ------------------------------ ----------
50p4mv1p0u17b                   0                  SELECT STATEMENT                                                       1
50p4mv1p0u17b          3191538885               20 TABLE ACCESS                   BY INDEX ROWID BATCHED               2128
50p4mv1p0u17b          3191538885               21 INDEX                          RANGE SCAN                            136
50p4mv1p0u17b          3191538885                                                                                         9
50p4mv1p0u17b          3191538885                4 HASH                           GROUP BY                                1


-- 12q3a5c5b9zpc


Plan hash value: 1558150397
---------------------------------------------------------------------------------------------------------
| Id  | Operation                            | Name             | Rows  | Bytes | Cost (%CPU)| Time     |
---------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                     |                  |       |       |     1 (100)|          |
|   1 |  INLIST ITERATOR                     |                  |       |       |            |          |
|   2 |   TABLE ACCESS BY INDEX ROWID BATCHED| G_PIECE          |     1 |    36 |     1   (0)| 00:00:01 |
|   3 |    INDEX RANGE SCAN                  | G_PIECE$ID_VENTE |     8 |       |     1   (0)| 00:00:01 |
---------------------------------------------------------------------------------------------------------

INSTANCE_NUMBER SQL_ID            ELAPSED MAX_WAIT_ON     PC_OF  WAIT_TIME            GETS      READS       ROWS  ELAP/EXEC       GETS/EXEC READS/EXEC  ROWS/EXEC       EXEC PLAN_HASH_VALUE
--------------- ------------- ----------- --------------- ----- ---------- --------------- ---------- ---------- ---------- --------------- ---------- ---------- ---------- ---------------
              2 12q3a5c5b9zpc       11569 CPU             89%   11425.7702      7140321766    3518429       4031       2.87         1770913     872.63          1       4032      1558150397
              1 12q3a5c5b9zpc       10601 CPU             100%  10309.7768      7567316032      34889       4278       2.48         1768478       8.15          1       4279      1558150397


SQL_ID        SQL_PLAN_HASH_VALUE SQL_PLAN_LINE_ID SQL_PLAN_OPERATION             SQL_PLAN_OPTIONS                   ACTIVE
------------- ------------------- ---------------- ------------------------------ ------------------------------ ----------
12q3a5c5b9zpc          1558150397                2 TABLE ACCESS                   BY INDEX ROWID BATCHED               2036
12q3a5c5b9zpc          1558150397                3 INDEX                          RANGE SCAN                            152

*/
/********************************OLD Metrics***************************************/

/********************************New SQL*******************************************/
-- 4vumfx7btzw9a

SELECT TO_CHAR(DECODE(SUM(DECODE(:B6, 'A', NVL(RL.F_LIM_AMT, 0), NULL)),
                      NULL,
                      NULL,
                      TO_CHAR(CH_TAUX.CONV_ORIG_DEST_TX(TO_CHAR(SYSDATE, 'J'),
                                                        SUM(DECODE(:B6,
                                                                   'A',
                                                                   NVL(RL.F_LIM_AMT,
                                                                       0),
                                                                   0)),
                                                        MAX(DECODE(:B6,
                                                                   'A',
                                                                   RL.F_LIM_AMT_CCY,
                                                                   :B5)),
                                                        MAX(:B5),
                                                        'MR')))) AS RECOURSE_LIM,
       DECODE(SUM(DECODE(:B6, 'A', NVL(RL.F_LIM_AMT, 0), NULL)),
              NULL,
              NULL,
              MAX(:B5)) AS REC_LIM_CCY,
       DECODE(SUM(DECODE(:B6, 'S', NVL(RL.F_LIM_AMT, 0), NULL)),
              NULL,
              NULL,
              TO_CHAR(CH_TAUX.CONV_ORIG_DEST_TX(TO_CHAR(SYSDATE, 'J'),
                                                SUM(DECODE(:B6,
                                                           'S',
                                                           NVL(RL.F_LIM_AMT, 0),
                                                           0)),
                                                MAX(DECODE(:B6,
                                                           'S',
                                                           RL.F_LIM_AMT_CCY,
                                                           :B5)),
                                                MAX(:B5),
                                                'MR'))) AS NON_REC_LIM,
       DECODE(SUM(DECODE(:B6, 'S', NVL(RL.F_LIM_AMT, 0), NULL)),
              NULL,
              NULL,
              MAX(:B5)) AS NON_REC_LIM_CCY,
       DECODE(SUM(DECODE(:B6, 'A', NVL(RL.F_LIM_AMT, 0), NULL)),
              NULL,
              NULL,
              TO_CHAR(CH_TAUX.CONV_ORIG_DEST_TX(TO_CHAR(SYSDATE, 'J'),
                                                SUM(DECODE(:B6,
                                                           'A',
                                                           (NVL(RL.F_LIM_CONSUM,
                                                                0) +
                                                           NVL(:B7, 0)),
                                                           0)),
                                                MAX(RL.F_LIM_AMT_CCY),
                                                MAX(:B5),
                                                'MR'))) AS CONSUMP_F_LIM_REC,
       DECODE(SUM(DECODE(:B6, 'S', NVL(RL.F_LIM_AMT, 0), NULL)),
              NULL,
              NULL,
              TO_CHAR(CH_TAUX.CONV_ORIG_DEST_TX(TO_CHAR(SYSDATE, 'J'),
                                                SUM(DECODE(:B6,
                                                           'S',
                                                           NVL(RL.F_LIM_CONSUM,
                                                               0),
                                                           0)),
                                                MAX(RL.F_LIM_AMT_CCY),
                                                MAX(:B5),
                                                'MR'))) AS CONSUMP_F_LIM_NREC,
       TO_CHAR(MAX(CASE
                     WHEN :B4 IS NOT NULL AND :B3 = 'S' THEN
                      RL.F_LIM_CONSUM
                     ELSE
                      CASE
                        WHEN :B4 IS NOT NULL AND :B3 = 'S' THEN
                         RL.F_LIM_CONSUM
                        ELSE
                         0
                      END
                   END)) AS CONSUMP_F_LIM_NREC_APF,
       TO_CHAR(MAX(F_LIM_AMT_CHECK)) AS F_LIM_AMT_CHECK,
       TO_CHAR(MAX(F_LIM_AMT_CCY)) AS F_LIM_AMT_CCY,
       TO_CHAR(MAX(F_LIM_CONSUM)) AS VC_F_LIM_CONSUM
  FROM (SELECT /*+ index(LIM PIE_GPILIBLIBRE) */
               DISTINCT DECODE(LIM.TYPEDOC, 'F', LIM.MT02, NULL) AS F_LIM_AMT,
                        DECODE(LIM.TYPEDOC, 'F', CLIM.CONSUMMED_AMT, NULL) AS F_LIM_CONSUM,
                        DECODE(LIM.TYPEDOC, 'F', LIM.MT02, NULL) AS F_LIM_AMT_CHECK,
                        DECODE(LIM.TYPEDOC, 'F', LIM.GPIDEVIS, '') AS F_LIM_AMT_CCY,
                        LIM.REFPIECE
          FROM G_PIECE LIM,
               G_PIECE PLIM,
               (SELECT LIMIT_ID, SUM(CONSUMED_LIM) AS CONSUMMED_AMT
                  FROM G_VENFILIMIT
                 GROUP BY LIMIT_ID) CLIM,
               G_PIECE POL,
               T_INTERVENANTS IPOL,
               T_INTERVENANTS TDB,
               T_INTERVENANTS CL,
               G_DOSSIER CMPT
         WHERE LIM.TYPPIECE = 'REQUEST_LIMITE'
           AND LIM.FG05 = 'O'
           AND LIM.TYPEDOC IN ('F', 'C')
           AND LIM.GPIROLE IN ('DT', 'DC')
           AND PLIM.TYPPIECE(+) = 'PARAM_LIMITE'
           AND PLIM.REFPIECE(+) = LIM.LIBELLE_20_12
           AND CLIM.LIMIT_ID(+) = PLIM.REFPIECE
           AND POL.TYPPIECE(+) = 'POLICE'
           AND POL.REFPIECE(+) = LIM.LIBELLE_100_8
           AND IPOL.REFDOSS(+) = POL.REFDOSS
           AND IPOL.REFTYPE(+) = 'CL'
           AND TDB.REFINDIVIDU = LIM.GPIADR3
           AND TDB.REFTYPE = 'DB'
           AND CL.REFDOSS = TDB.REFDOSS
           AND CL.REFINDIVIDU = LIM.GPIDEPOT
           AND CL.REFTYPE = 'CL'
           AND CL.REFDOSS = CMPT.REFDOSS
           -- AND LIM.GPIADR3 = :B2
           -- AND CL.REFINDIVIDU = :B1
           AND LIM.GPILIBLIBRE LIKE 'L1.' || :B2 || '.' || :B1 || '.%' ) RL;


-- 50p4mv1p0u17b


SELECT TO_CHAR(SUM(F_LIMIT)) AS TOT_F_LIM_CONSUM
  FROM (SELECT /*+ index(LIM PIE_GPILIBLIBRE) */ DISTINCT CH_TAUX.CONV_ORIG_DEST_TX(TO_CHAR(SYSDATE, 'J'),
                                                  NVL(LIM.MT02, 0),
                                                  LIM.GPIDEVIS,
                                                  PBU.GPIDEVIS,
                                                  'MR') F_LIMIT,
                        LIM.REFPIECE
          FROM G_PIECE LIM,
               G_PIECE PLIM,
               (SELECT LIMIT_ID, SUM(CONSUMED_LIM) AS CONSUMMED_AMT
                  FROM G_VENFILIMIT
                 GROUP BY LIMIT_ID) CLIM,
               G_DOSSIER CMPT,
               G_DOSSIER DCMPT,
               G_PIECE PBU,
               T_INTERVENANTS TDB,
               T_INTERVENANTS CL
         WHERE LIM.TYPPIECE = 'REQUEST_LIMITE'
           AND LIM.FG05 = 'O'
           AND LIM.TYPEDOC = 'F'
           AND LIM.GPIROLE IN ('DT', 'DC')
           AND PLIM.TYPPIECE(+) = 'PARAM_LIMITE'
           AND PLIM.REFPIECE(+) = LIM.LIBELLE_20_12
           AND CLIM.LIMIT_ID(+) = PLIM.REFPIECE
           AND TDB.REFINDIVIDU = LIM.GPIADR3
           AND TDB.REFTYPE = 'DB'
           AND CL.REFDOSS = TDB.REFDOSS
           AND CL.REFINDIVIDU = LIM.GPIDEPOT
           AND CL.REFTYPE = 'CL'
           AND CL.REFDOSS = CMPT.REFDOSS
           AND DCMPT.REFDOSS = CMPT.REFLOT
           AND PBU.REFPIECE(+) = DCMPT.REFFACTOR
           AND PBU.TYPPIECE(+) = 'FACTOR'           
           AND LIM.GPILIBLIBRE LIKE 'L1.' || :B2 || '.' || :B1 || '.%');


-- 12q3a5c5b9zpc


SELECT /*+ index(LIM G_PIECE$ADR3) */ NVL(LIM.MT02, 0) AS DB_GLOB_LIM_GFL,
       LIM.GPIDEVIS AS GFL_CCY,
       LIM.COMMENTAIRE,
       CASE
         WHEN (:B11 IS NULL OR :B11 = 'no limit defined') AND
              (:B10 IS NULL OR :B10 = 'no limit defined') AND :B9 IS NULL THEN
          'no limit defined'
         ELSE
          TO_CHAR(CASE
                    WHEN TO_CHAR(:B8) <> 'no limit defined' THEN
                     NVL(CH_TAUX.CONV_ORIG_DEST_TX(TO_CHAR(SYSDATE, 'j'),
                                                   NVL(:B8, 0),
                                                   :B7,
                                                   :B2,
                                                   'MR',
                                                   ''),
                         0)
                    ELSE
                     0
                  END + CASE
                    WHEN TO_CHAR(:B6) <> 'no limit defined' THEN
                     NVL(CH_TAUX.CONV_ORIG_DEST_TX(TO_CHAR(SYSDATE, 'j'),
                                                   NVL(:B6, 0),
                                                   :B5,
                                                   :B2,
                                                   'MR',
                                                   ''),
                         0)
                    ELSE
                     0
                  END + CASE
                    WHEN TO_CHAR(:B4) <> 'no limit defined' THEN
                     NVL(CH_TAUX.CONV_ORIG_DEST_TX(TO_CHAR(SYSDATE, 'j'),
                                                   :B4,
                                                   :B3,
                                                   :B2,
                                                   'MR',
                                                   ''),
                         0)
                    ELSE
                     0
                  END)
       END AS CONSUMP_GFL
  FROM G_PIECE LIM
 WHERE LIM.TYPPIECE = 'REQUEST_LIMITE'
   AND LIM.FG05 = 'O'
   AND LIM.TYPEDOC = 'GFL'
   AND LIM.GPIROLE IN ('DT', 'DC')
   AND LIM.GPIADR3 = :B1;

/********************************New SQL*******************************************/
/********************************New Metrics***************************************/
/*
-- 4vumfx7btzw9a

Plan hash value: 1440031513
--------------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                     | Name                      | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers |
--------------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                              |                           |      1 |        |     8 (100)|      1 |00:00:00.01 |      63 |
|   1 |  SORT AGGREGATE                               |                           |      1 |      1 |            |      1 |00:00:00.01 |      63 |
|   2 |   VIEW                                        |                           |      1 |      1 |     8  (13)|      2 |00:00:00.01 |      63 |
|   3 |    HASH UNIQUE                                |                           |      1 |      1 |     8  (13)|      2 |00:00:00.01 |      63 |
|   4 |     HASH GROUP BY                             |                           |      1 |      1 |     8  (13)|      4 |00:00:00.01 |      63 |
|   5 |      NESTED LOOPS                             |                           |      1 |      1 |     7   (0)|      8 |00:00:00.01 |      63 |
|   6 |       NESTED LOOPS                            |                           |      1 |      1 |     6   (0)|      8 |00:00:00.01 |      45 |
|   7 |        NESTED LOOPS OUTER                     |                           |      1 |      1 |     5   (0)|      4 |00:00:00.01 |      35 |
|   8 |         NESTED LOOPS OUTER                    |                           |      1 |      1 |     4   (0)|      4 |00:00:00.01 |      30 |
|   9 |          NESTED LOOPS OUTER                   |                           |      1 |      1 |     3   (0)|      2 |00:00:00.01 |      21 |
|  10 |           NESTED LOOPS OUTER                  |                           |      1 |      1 |     2   (0)|      2 |00:00:00.01 |      14 |
|* 11 |            TABLE ACCESS BY INDEX ROWID BATCHED| G_PIECE                   |      1 |      1 |     1   (0)|      2 |00:00:00.01 |      10 |
|* 12 |             INDEX RANGE SCAN                  | PIE_GPILIBLIBRE           |      1 |     15 |     1   (0)|      4 |00:00:00.01 |       3 |
|* 13 |            TABLE ACCESS BY INDEX ROWID BATCHED| G_PIECE                   |      2 |      1 |     1   (0)|      1 |00:00:00.01 |       4 |
|* 14 |             INDEX RANGE SCAN                  | PIE_REFPIECE              |      2 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |
|* 15 |           TABLE ACCESS BY INDEX ROWID BATCHED | G_PIECE                   |      2 |      1 |     1   (0)|      2 |00:00:00.01 |       7 |
|* 16 |            INDEX RANGE SCAN                   | PIE_REFPIECE              |      2 |      1 |     1   (0)|      2 |00:00:00.01 |       6 |
|  17 |          TABLE ACCESS BY INDEX ROWID BATCHED  | G_VENFILIMIT              |      2 |    252 |     1   (0)|      4 |00:00:00.01 |       9 |
|* 18 |           INDEX RANGE SCAN                    | G_VENFILIMIT$LIMIT_ID_IDX |      2 |    403 |     1   (0)|      4 |00:00:00.01 |       8 |
|* 19 |         INDEX RANGE SCAN                      | INT_REFDOSS               |      4 |      1 |     1   (0)|      2 |00:00:00.01 |       5 |
|* 20 |        INDEX RANGE SCAN                       | INT_INDIV                 |      4 |      1 |     1   (0)|      8 |00:00:00.01 |      10 |
|* 21 |       INDEX RANGE SCAN                        | INT_INDIV                 |      8 |      1 |     1   (0)|      8 |00:00:00.01 |      18 |
--------------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
  11 - filter(("LIM"."GPIADR3" IS NOT NULL AND "LIM"."TYPPIECE"='REQUEST_LIMITE' AND "LIM"."GPIDEPOT" IS NOT NULL AND "LIM"."FG05"='O'
              AND INTERNAL_FUNCTION("LIM"."GPIROLE") AND INTERNAL_FUNCTION("LIM"."TYPEDOC")))
  12 - access("LIM"."GPILIBLIBRE" LIKE 'L1.'||:B2||'.'||:B1||'.%')
       filter("LIM"."GPILIBLIBRE" LIKE 'L1.'||:B2||'.'||:B1||'.%')
  13 - filter("POL"."TYPPIECE"='POLICE')
  14 - access("POL"."REFPIECE"="LIM"."LIBELLE_100_8")
  15 - filter("PLIM"."TYPPIECE"='PARAM_LIMITE')
  16 - access("PLIM"."REFPIECE"="LIM"."LIBELLE_20_12")
  18 - access("LIMIT_ID"="PLIM"."REFPIECE")
  19 - access("IPOL"."REFDOSS"="POL"."REFDOSS" AND "IPOL"."REFTYPE"='CL')
  20 - access("TDB"."REFINDIVIDU"="LIM"."GPIADR3" AND "TDB"."REFTYPE"='DB')
  21 - access("CL"."REFINDIVIDU"="LIM"."GPIDEPOT" AND "CL"."REFTYPE"='CL' AND "CL"."REFDOSS"="TDB"."REFDOSS")


-- 50p4mv1p0u17b

Plan hash value: 3318124201
------------------------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                      | Name                      | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  |
------------------------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                               |                           |      1 |        |     9 (100)|      1 |00:00:00.02 |      70 |     11 |
|   1 |  SORT AGGREGATE                                |                           |      1 |      1 |            |      1 |00:00:00.02 |      70 |     11 |
|   2 |   VIEW                                         |                           |      1 |      1 |     9  (12)|      1 |00:00:00.02 |      70 |     11 |
|   3 |    HASH UNIQUE                                 |                           |      1 |      1 |     9  (12)|      1 |00:00:00.02 |      70 |     11 |
|   4 |     HASH GROUP BY                              |                           |      1 |      1 |     9  (12)|      2 |00:00:00.01 |      65 |     11 |
|   5 |      NESTED LOOPS OUTER                        |                           |      1 |      1 |     8   (0)|      2 |00:00:00.01 |      65 |     11 |
|   6 |       NESTED LOOPS OUTER                       |                           |      1 |      1 |     7   (0)|      2 |00:00:00.01 |      57 |      8 |
|   7 |        NESTED LOOPS OUTER                      |                           |      1 |      1 |     6   (0)|      2 |00:00:00.01 |      50 |      6 |
|   8 |         NESTED LOOPS                           |                           |      1 |      1 |     5   (0)|      2 |00:00:00.01 |      40 |      6 |
|   9 |          NESTED LOOPS                          |                           |      1 |      1 |     4   (0)|      2 |00:00:00.01 |      28 |      6 |
|  10 |           NESTED LOOPS                         |                           |      1 |      1 |     3   (0)|      2 |00:00:00.01 |      22 |      6 |
|  11 |            NESTED LOOPS                        |                           |      1 |      1 |     2   (0)|      2 |00:00:00.01 |      16 |      6 |
|* 12 |             TABLE ACCESS BY INDEX ROWID BATCHED| G_PIECE                   |      1 |      1 |     1   (0)|      1 |00:00:00.01 |      13 |      6 |
|* 13 |              INDEX RANGE SCAN                  | PIE_GPILIBLIBRE           |      1 |     15 |     1   (0)|      6 |00:00:00.01 |       3 |      2 |
|* 14 |             INDEX RANGE SCAN                   | INT_INDIV                 |      1 |      1 |     1   (0)|      2 |00:00:00.01 |       3 |      0 |
|* 15 |            INDEX RANGE SCAN                    | INT_INDIV                 |      2 |      1 |     1   (0)|      2 |00:00:00.01 |       6 |      0 |
|* 16 |           INDEX RANGE SCAN                     | DOS_REFDOSS_REFLOT_IDX    |      2 |      1 |     1   (0)|      2 |00:00:00.01 |       6 |      0 |
|  17 |          TABLE ACCESS BY INDEX ROWID           | G_DOSSIER                 |      2 |      1 |     1   (0)|      2 |00:00:00.01 |      12 |      0 |
|* 18 |           INDEX UNIQUE SCAN                    | DOS_REFDOSS               |      2 |      1 |     1   (0)|      2 |00:00:00.01 |       6 |      0 |
|* 19 |         TABLE ACCESS BY INDEX ROWID BATCHED    | G_PIECE                   |      2 |      1 |     1   (0)|      2 |00:00:00.01 |      10 |      0 |
|* 20 |          INDEX RANGE SCAN                      | PIE_REFPIECE              |      2 |      1 |     1   (0)|      2 |00:00:00.01 |       9 |      0 |
|* 21 |        TABLE ACCESS BY INDEX ROWID BATCHED     | G_PIECE                   |      2 |      1 |     1   (0)|      2 |00:00:00.01 |       7 |      2 |
|* 22 |         INDEX RANGE SCAN                       | PIE_REFPIECE              |      2 |      1 |     1   (0)|      2 |00:00:00.01 |       6 |      1 |
|* 23 |       INDEX RANGE SCAN                         | G_VENFILIMIT$LIMIT_ID_IDX |      2 |    252 |     1   (0)|      0 |00:00:00.01 |       8 |      3 |
------------------------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
  12 - filter(("LIM"."GPIADR3" IS NOT NULL AND "LIM"."TYPEDOC"='F' AND "LIM"."TYPPIECE"='REQUEST_LIMITE' AND "LIM"."GPIDEPOT" IS NOT NULL AND
              "LIM"."FG05"='O' AND INTERNAL_FUNCTION("LIM"."GPIROLE")))
  13 - access("LIM"."GPILIBLIBRE" LIKE 'L1.'||:B2||'.'||:B1||'.%')
       filter("LIM"."GPILIBLIBRE" LIKE 'L1.'||:B2||'.'||:B1||'.%')
  14 - access("TDB"."REFINDIVIDU"="LIM"."GPIADR3" AND "TDB"."REFTYPE"='DB')
  15 - access("CL"."REFINDIVIDU"="LIM"."GPIDEPOT" AND "CL"."REFTYPE"='CL' AND "CL"."REFDOSS"="TDB"."REFDOSS")
  16 - access("CL"."REFDOSS"="CMPT"."REFDOSS")
  18 - access("DCMPT"."REFDOSS"="CMPT"."REFLOT")
  19 - filter("PBU"."TYPPIECE"='FACTOR')
  20 - access("PBU"."REFPIECE"="DCMPT"."REFFACTOR")
  21 - filter("PLIM"."TYPPIECE"='PARAM_LIMITE')
  22 - access("PLIM"."REFPIECE"="LIM"."LIBELLE_20_12")
  23 - access("LIMIT_ID"="PLIM"."REFPIECE")


-- 12q3a5c5b9zpc

Plan hash value: 385531285
------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                           | Name         | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  |
------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                    |              |      1 |        |     1 (100)|      1 |00:00:00.01 |      23 |      4 |
|*  1 |  TABLE ACCESS BY INDEX ROWID BATCHED| G_PIECE      |      1 |      1 |     1   (0)|      1 |00:00:00.01 |      23 |      4 |
|*  2 |   INDEX RANGE SCAN                  | G_PIECE$ADR3 |      1 |     33 |     1   (0)|     10 |00:00:00.01 |       5 |      1 |
------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   1 - filter(("LIM"."TYPEDOC"='GFL' AND "LIM"."TYPPIECE"='REQUEST_LIMITE' AND "LIM"."FG05"='O' AND
              INTERNAL_FUNCTION("LIM"."GPIROLE")))
   2 - access("LIM"."GPIADR3"=:B1)

*/
/********************************New Metrics***************************************/

/********************************Index statistics**********************************/

/********************************Other SQLs****************************************/          
/*

*/ 
/********************************Other SQLs****************************************/              
