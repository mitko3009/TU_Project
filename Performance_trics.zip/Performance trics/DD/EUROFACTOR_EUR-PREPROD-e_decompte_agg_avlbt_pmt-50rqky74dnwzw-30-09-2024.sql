/********************************************************************************
*********       E-mail subject: EFDE2DEV-1930
*********             Instance: PRE-PROD
*********          Description: 
Problem:
SQL 50rqky74dnwzw was the TOP SQL in the trace file ( \\epox\specifs\performance\tmp\EUROFACTOR_EUR\PRE PROD PERF\EFDE2DEV-1930 )

Analysis:
We executed it manually on PRE-PROD and found that we can improve its execution plan. The first thing that can be optimized here is to reduce the selected rows from the tables 
earlier in the execution in the first UNION. The query starts from the INDIV inline view, after that access table T_INTERVENANTS CL, where it founds over 9k rows for the selected individues.
After that, for every of the selected rows from T_INTERVENANTS CL access table G_DOSSIER CTR, where te rows keeps 9k and then access table G_PIECE PCTR, where the condition PCTR.TYPPIECE = 'CONTRAT' 
reduces the rows from over 9k to only 14. We changed it and joined table G_PIECE PCTR directly to T_INTERVENANTS CL as it is shown in the New SQL section below. By this way, we access only 
table G_PIECE PCTR for 9k rows, in which the rows becomes to 14 and continue only with the 14 rows. The second thing that we made is that we added hint in the second UNION to force oracle to 
start the execution from the inline view CONTR_GR, where it selects the REFGROUP for the given refdoss.

Suggestion:
Please change the query as it is shown in the New SQL section below.

*********               SQL_ID: 50rqky74dnwzw
*********      Program/Package: 
*********              Request: Dimitare Ivanov
*********               Author: Dimitar Dimitrov
********* Received e-mail date: 24/09/2024
*********      Resolution date: 30/09/2024
*********  Trace old file here: \\epox\specifs\performance\tmp\
*********  Trace new file here:
***********************************************************************************/

/********************************OLD SQL*******************************************/

VAR B1 VARCHAR2(32);
EXEC :B1 := 'A602PSL3';
VAR B2 VARCHAR2(32);
EXEC :B2 := 'N';
VAR B3 VARCHAR2(32);
EXEC :B3 := 'EUR';
VAR B4 VARCHAR2(32);
EXEC :B4 := '9/25/2024';
VAR B5 VARCHAR2(32);
EXEC :B5 := 'O';
VAR B6 VARCHAR2(32);
EXEC :B6 := 'O';
VAR B7 VARCHAR2(32);
EXEC :B7 := 'N';
VAR B8 VARCHAR2(32);
EXEC :B8 := 'A600M0KW';
VAR B9 VARCHAR2(32);
EXEC :B9 := '0301010127';
var B10 varchar2(32);
exec :B10 := 'INT00000';
exec utl_app_date.cacheAppDate(:B10);
 
SELECT STMNT,
       CTR,
       GR_CTR,
       CL,
       GR,
       REFFACTOR,
       STMNT_MAX_FIU,
       CTR_MAX_FIU,
       GR_CTR_MAX_FIU,
       CL_MAX_FIU,
       CL_BU_MAX_FIU,
       GR_MAX_FIU,
       GR_BU_MAX_FIU,
       STMNT_CURR_FIU,
       STMNT_PEND_ITEMS,
       ROWNUM
  FROM (SELECT D.REFDOSS STMNT,
               D.REFFACTOR REFFACTOR,
               CTR.REFDOSS CTR,
               NULL GR_CTR,
               CL.REFINDIVIDU CL,
               INDIV.REFGROUPE GR,
               FTR_VIEWS.CONV(PSC.MT39, D.DEVISE, :B3) STMNT_MAX_FIU,
               FTR_VIEWS.CONV(PCTR.MT39, CTR.DEVISE, :B3) CTR_MAX_FIU,
               NULL GR_CTR_MAX_FIU,
               (SELECT DISTINCT FIRST_VALUE(FTR_VIEWS.CONV(CD.MT01,
                                                           CD.STR1,
                                                           :B3)) OVER(ORDER BY CD.DT01_DT DESC NULLS LAST)
                  FROM G_PIECEDET CD, G_PIECE CP
                 WHERE CP.TYPPIECE = 'CLIENT_PARAMS'
                   AND CP.GPIHEURE = CL.REFINDIVIDU
                   AND CD.TYPE = 'CONC_DET'
                   AND CD.REFPIECE = CP.REFPIECE
                   AND TRUNC(CD.DT01_DT) <= TRUNC(SYSDATE)
                   AND TRUNC(SYSDATE) <= NVL(CD.DT03_DT, SYSDATE + 1)
                   AND NVL(CD.STR2, 'V') = 'V'
                   AND CD.STR5 IS NULL) CL_MAX_FIU,
               (SELECT DISTINCT FIRST_VALUE(FTR_VIEWS.CONV(CD.MT01,
                                                           CD.STR1,
                                                           :B3)) OVER(ORDER BY CD.DT01_DT DESC NULLS LAST)
                  FROM G_PIECEDET CD, G_PIECE CP
                 WHERE CP.TYPPIECE = 'CLIENT_PARAMS'
                   AND CP.GPIHEURE = CL.REFINDIVIDU
                   AND CD.TYPE = 'CONC_DET'
                   AND CD.REFPIECE = CP.REFPIECE
                   AND TRUNC(CD.DT01_DT) <= TRUNC(SYSDATE)
                   AND TRUNC(SYSDATE) <= NVL(CD.DT03_DT, SYSDATE + 1)
                   AND NVL(CD.STR2, 'V') = 'V'
                   AND CD.STR5 = :B8) CL_BU_MAX_FIU,
               (SELECT DISTINCT FIRST_VALUE(FTR_VIEWS.CONV(CD.MT01,
                                                           CD.STR1,
                                                           :B3)) OVER(ORDER BY CD.DT01_DT DESC NULLS LAST)
                  FROM G_INDIVPARAM CD
                 WHERE CD.TYPE = 'CONC_DET'
                   AND CD.REFINDIVIDU = INDIV.REFGROUPE
                   AND TRUNC(CD.DT01_DT) <= TRUNC(SYSDATE)
                   AND TRUNC(SYSDATE) <= NVL(CD.DT03_DT, SYSDATE + 1)
                   AND NVL(CD.STR2, 'V') = 'V'
                   AND CD.STR5 IS NULL) GR_MAX_FIU,
               (SELECT DISTINCT FIRST_VALUE(FTR_VIEWS.CONV(CD.MT01,
                                                           CD.STR1,
                                                           :B3)) OVER(ORDER BY CD.DT01_DT DESC NULLS LAST)
                  FROM G_INDIVPARAM CD
                 WHERE CD.TYPE = 'CONC_DET'
                   AND CD.REFINDIVIDU = INDIV.REFGROUPE
                   AND TRUNC(CD.DT01_DT) <= TRUNC(SYSDATE)
                   AND TRUNC(SYSDATE) <= NVL(CD.DT03_DT, SYSDATE + 1)
                   AND NVL(CD.STR2, 'V') = 'V'
                   AND CD.STR5 = :B8) GR_BU_MAX_FIU,
               FTR_VIEWS.CONV(DECODE(:B2,
                                     'O',
                                     FTR_DECOMPTE.GETFUNDINGSENT(D.REFDOSS),
                                     FTR_DECOMPTE.GETFIU_CASH(D.REFDOSS) +
                                     FTR_DECOMPTE.GETFIU_STRAIGHTLOAN(D.REFDOSS) +
                                     FTR_DECOMPTE.GETFIU_LOAN(D.REFDOSS) +
                                     FTR_DECOMPTE.GETBLOCKEDAMOUNTSTD(D.REFDOSS,
                                                                      'UTILISATION_EXTERNE')),
                              D.DEVISE,
                              :B3) STMNT_CURR_FIU,
               FTR_VIEWS.CONV(FTR_DECOMPTE.GETPENDINGPAYMENTS(D.REFDOSS) +
                              INV_PENDING_PMT.GETPENDINGCOSTS(D.REFDOSS) +
                              DECODE(:B7,
                                     'O',
                                     FTR_DECOMPTE.GETPENDINGBUNDLES(D.REFDOSS),
                                     0) + CASE
                                WHEN :B6 = 'O' THEN
                                 0
                                WHEN :B5 = 'O' THEN
                                 GREATEST(FACTOR_INVFUNC.GETFUNDINGCOMMISSION(D.REFDOSS,
                                                                              TO_CHAR(to_date(:B4,'MM-DD-YYYY'),
                                                                                      'j'),
                                                                              'supplier'),
                                          0)
                                ELSE
                                 FACTOR_INVFUNC.GETFUNDINGCOMMISSION(D.REFDOSS,
                                                                     TO_CHAR(to_date(:B4,'MM-DD-YYYY'), 'j'),
                                                                     'supplier')
                              END,
                              D.DEVISE,
                              :B3) STMNT_PEND_ITEMS
          FROM G_DOSSIER D,
               G_PIECE PSC,
               G_DOSSIER CTR,
               G_PIECE PCTR,
               T_INTERVENANTS CL,
               ( SELECT GCLD.REF1 REFINDIVIDU, 
                        GCL.REFGROUPE REFGROUPE
                   FROM G_GROUPINDIVDET GCLD, 
                        G_GROUPINDIV GCL
                  WHERE GCLD.TYPE = 'LIST'
                    AND GCL.TYPE = 'CLIENTS'
                    AND GCLD.REFGROUPE = GCL.REFGROUPE
                    AND EXISTS ( SELECT 1
                                   FROM G_GROUPINDIVDET
                                  WHERE REFGROUPE = GCLD.REFGROUPE
                                    AND TYPE = 'LIST'
                                    AND REF1 = :B1 )
                 UNION ALL
                 SELECT :B1, NULL
                   FROM DUAL
                  WHERE NOT EXISTS ( SELECT 1
                                       FROM G_GROUPINDIV CLGR, 
                                            G_GROUPINDIVDET CLGRD
                                      WHERE CLGR.REFGROUPE = CLGRD.REFGROUPE
                                        AND CLGR.TYPE = 'CLIENTS'
                                        AND CLGRD.TYPE = 'LIST'
                                        AND CLGRD.REF1 = :B1 ) ) INDIV
         WHERE D.CATEGDOSS LIKE 'DECOMPTE%'
           AND PSC.TYPPIECE = 'SOUS-CONTRAT'
           AND PSC.REFDOSS = D.REFDOSS
           AND CTR.REFDOSS = D.REFLOT
           AND PCTR.TYPPIECE = 'CONTRAT'
           AND PCTR.REFDOSS = CTR.REFDOSS
           AND CL.REFTYPE = DECODE(CTR.CATEGDOSS, 'CONTRAT IMP', 'TC', 'CL')
           AND CL.REFDOSS = CTR.REFDOSS
           AND CL.REFINDIVIDU = INDIV.REFINDIVIDU
           AND NVL(PSC.FG30, 'N') = :B2
        UNION ALL
        SELECT D.REFDOSS STMNT,
               D.REFFACTOR REFFACTOR,
               MC.REFDOSS CTR,
               MC.REFGROUP GR_CTR,
               NULL CL,
               NULL GR,
               FTR_VIEWS.CONV(PSC.MT39, D.DEVISE, :B3) STMNT_MAX_FIU,
               FTR_VIEWS.CONV(PCTR.MT39, CTR.DEVISE, :B3) CTR_MAX_FIU,
               FTR_VIEWS.CONV(MF.AMOUNT, MF.CURRENCY, :B3) GR_CTR_MAX_FIU,
               NULL CL_MAX_FIU,
               NULL CL_BU_MAX_FIU,
               NULL GR_MAX_FIU,
               NULL GR_BU_MAX_FIU,
               FTR_VIEWS.CONV(DECODE(:B2,
                                     'O',
                                     FTR_DECOMPTE.GETFUNDINGSENT(D.REFDOSS),
                                     FTR_DECOMPTE.GETFIU_CASH(D.REFDOSS) +
                                     FTR_DECOMPTE.GETFIU_STRAIGHTLOAN(D.REFDOSS) +
                                     FTR_DECOMPTE.GETFIU_LOAN(D.REFDOSS) +
                                     FTR_DECOMPTE.GETBLOCKEDAMOUNTSTD(D.REFDOSS,
                                                                      'UTILISATION_EXTERNE')),
                              D.DEVISE,
                              :B3) STMNT_CURR_FIU,
               FTR_VIEWS.CONV(FTR_DECOMPTE.GETPENDINGPAYMENTS(D.REFDOSS) +
                              INV_PENDING_PMT.GETPENDINGCOSTS(D.REFDOSS) +
                              DECODE(:B7,
                                     'O',
                                     FTR_DECOMPTE.GETPENDINGBUNDLES(D.REFDOSS),
                                     0) + CASE
                                WHEN :B6 = 'O' THEN
                                 0
                                WHEN :B5 = 'O' THEN
                                 GREATEST(FACTOR_INVFUNC.GETFUNDINGCOMMISSION(D.REFDOSS,TO_CHAR(to_date(:B4,'MM-DD-YYYY'),'j'),'supplier'),
                                          0)
                                ELSE
                                 FACTOR_INVFUNC.GETFUNDINGCOMMISSION(D.REFDOSS,
                                                                     TO_CHAR(to_date(:B4,'MM-DD-YYYY'), 'j'),
                                                                     'supplier')
                              END,
                              D.DEVISE,
                              :B3) STMNT_PEND_ITEMS
          FROM MEMBER_CONTRACT MC,
               GROUP_CONTRACTS GC,
               MAX_FIU_LIMIT MF,
               G_DOSSIER CTR,
               G_DOSSIER D,
               G_PIECE PSC,
               G_PIECE PCTR,
               ( SELECT REFGROUP 
                   FROM MEMBER_CONTRACT 
                  WHERE REFDOSS = :B9 ) CONTR_GR
         WHERE MC.REFGROUP = CONTR_GR.REFGROUP
           AND GC.REFGROUP = MC.REFGROUP
           AND GC.VALID = 'O'
           AND MF.REFGROUP = GC.REFGROUP
           AND TRUNC(SYSDATE) BETWEEN TRUNC(MF.START_DT) AND TRUNC(NVL(MF.END_DT, SYSDATE + 1))
           AND NVL(MF.STATUS, 'V') = 'V'
           AND CTR.REFDOSS = MC.REFDOSS
           AND D.REFLOT = CTR.REFDOSS
           AND PSC.REFDOSS = D.REFDOSS
           AND PSC.TYPPIECE = 'SOUS-CONTRAT'
           AND PCTR.REFDOSS = CTR.REFDOSS
           AND PCTR.TYPPIECE = 'CONTRAT'
           AND NVL(PSC.FG30, 'N') = :B2);
/********************************OLD SQL*******************************************/
/********************************OLD Metrics***************************************/
/*
Plan hash value: 1186569863
-----------------------------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                          | Name                       | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  |
-----------------------------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                                   |                            |      1 |        |   124 (100)|     14 |00:00:03.31 |   55564 |   1386 |
|   1 |  COUNT                                             |                            |      1 |        |            |     14 |00:00:03.31 |   55564 |   1386 |
|   2 |   VIEW                                             |                            |      1 |      2 |   124   (8)|     14 |00:00:03.31 |   55564 |   1386 |
|   3 |    UNION-ALL                                       |                            |      1 |        |            |     14 |00:00:03.31 |   55564 |   1386 |
|   4 |     SORT UNIQUE                                    |                            |     12 |      1 |    10  (20)|      0 |00:00:00.10 |      56 |     23 |
|   5 |      WINDOW SORT                                   |                            |     12 |      1 |    10  (20)|      0 |00:00:00.10 |      56 |     23 |
|   6 |       NESTED LOOPS                                 |                            |     12 |      1 |     8   (0)|      0 |00:00:00.10 |      56 |     23 |
|   7 |        NESTED LOOPS                                |                            |     12 |      1 |     8   (0)|      0 |00:00:00.10 |      56 |     23 |
|*  8 |         TABLE ACCESS BY INDEX ROWID BATCHED        | G_PIECE                    |     12 |      1 |     4   (0)|     12 |00:00:00.10 |      38 |     21 |
|*  9 |          INDEX RANGE SCAN                          | G_PIECE$GPIHEURE           |     12 |      1 |     3   (0)|     12 |00:00:00.06 |      26 |     11 |
|* 10 |         INDEX RANGE SCAN                           | G_PIECEDET_REFP            |     12 |      1 |     3   (0)|      0 |00:00:00.01 |      18 |      2 |
|* 11 |        TABLE ACCESS BY INDEX ROWID                 | G_PIECEDET                 |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|  12 |     SORT UNIQUE                                    |                            |     12 |      1 |    10  (20)|      0 |00:00:00.01 |      56 |      0 |
|  13 |      WINDOW SORT                                   |                            |     12 |      1 |    10  (20)|      0 |00:00:00.01 |      56 |      0 |
|  14 |       NESTED LOOPS                                 |                            |     12 |      1 |     8   (0)|      0 |00:00:00.01 |      56 |      0 |
|  15 |        NESTED LOOPS                                |                            |     12 |      1 |     8   (0)|      0 |00:00:00.01 |      56 |      0 |
|* 16 |         TABLE ACCESS BY INDEX ROWID BATCHED        | G_PIECE                    |     12 |      1 |     4   (0)|     12 |00:00:00.01 |      38 |      0 |
|* 17 |          INDEX RANGE SCAN                          | G_PIECE$GPIHEURE           |     12 |      1 |     3   (0)|     12 |00:00:00.01 |      26 |      0 |
|* 18 |         INDEX RANGE SCAN                           | G_PIECEDET_REFP            |     12 |      1 |     3   (0)|      0 |00:00:00.01 |      18 |      0 |
|* 19 |        TABLE ACCESS BY INDEX ROWID                 | G_PIECEDET                 |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|  20 |     SORT UNIQUE                                    |                            |      1 |      1 |     6  (34)|      0 |00:00:00.01 |       3 |      2 |
|  21 |      WINDOW SORT                                   |                            |      1 |      1 |     6  (34)|      0 |00:00:00.01 |       3 |      2 |
|* 22 |       TABLE ACCESS BY INDEX ROWID BATCHED          | G_INDIVPARAM               |      1 |      1 |     4   (0)|      0 |00:00:00.01 |       3 |      2 |
|* 23 |        INDEX RANGE SCAN                            | G_IND_REFIND_TYPE_DT01     |      1 |      1 |     3   (0)|      0 |00:00:00.01 |       3 |      2 |
|  24 |     SORT UNIQUE                                    |                            |      1 |      1 |     6  (34)|      0 |00:00:00.01 |       3 |      0 |
|  25 |      WINDOW SORT                                   |                            |      1 |      1 |     6  (34)|      0 |00:00:00.01 |       3 |      0 |
|* 26 |       TABLE ACCESS BY INDEX ROWID BATCHED          | G_INDIVPARAM               |      1 |      1 |     4   (0)|      0 |00:00:00.01 |       3 |      0 |
|* 27 |        INDEX RANGE SCAN                            | G_IND_REFIND_TYPE_DT01     |      1 |      1 |     3   (0)|      0 |00:00:00.01 |       3 |      0 |
|  28 |     NESTED LOOPS                                   |                            |      1 |      1 |    49   (3)|     14 |00:00:00.87 |   43797 |    457 |
|  29 |      NESTED LOOPS                                  |                            |      1 |      1 |    49   (3)|     14 |00:00:00.82 |   43769 |    443 |
|  30 |       NESTED LOOPS                                 |                            |      1 |      1 |    45   (3)|     14 |00:00:00.79 |   43721 |    429 |
|  31 |        NESTED LOOPS                                |                            |      1 |      1 |    41   (3)|     14 |00:00:00.78 |   43676 |    417 |
|  32 |         NESTED LOOPS                               |                            |      1 |      1 |    37   (3)|   9241 |00:00:00.11 |   21062 |      0 |
|  33 |          NESTED LOOPS                              |                            |      1 |      6 |    25   (4)|   9264 |00:00:00.01 |     291 |      0 |
|  34 |           VIEW                                     |                            |      1 |      2 |    21   (5)|     13 |00:00:00.01 |     198 |      0 |
|  35 |            UNION-ALL                               |                            |      1 |        |            |     13 |00:00:00.01 |     198 |      0 |
|  36 |             NESTED LOOPS                           |                            |      1 |      1 |    16   (7)|     13 |00:00:00.01 |     192 |      0 |
|  37 |              NESTED LOOPS                          |                            |      1 |      1 |    16   (7)|     67 |00:00:00.01 |     120 |      0 |
|  38 |               NESTED LOOPS                         |                            |      1 |      1 |    15   (7)|     67 |00:00:00.01 |      98 |      0 |
|  39 |                SORT UNIQUE                         |                            |      1 |      1 |     2   (0)|      3 |00:00:00.01 |       5 |      0 |
|* 40 |                 TABLE ACCESS BY INDEX ROWID BATCHED| G_GROUPINDIVDET            |      1 |      1 |     2   (0)|      3 |00:00:00.01 |       5 |      0 |
|* 41 |                  INDEX RANGE SCAN                  | G_GROUPINDIVDET_REF1_IDX   |      1 |      1 |     1   (0)|      3 |00:00:00.01 |       2 |      0 |
|* 42 |                TABLE ACCESS BY INDEX ROWID BATCHED | G_GROUPINDIVDET            |      3 |      4 |    12   (0)|     67 |00:00:00.01 |      93 |      0 |
|* 43 |                 INDEX RANGE SCAN                   | G_GROUPINDIVDET_RFTRPE_IDX |      3 |     17 |     1   (0)|     67 |00:00:00.01 |       8 |      0 |
|* 44 |               INDEX UNIQUE SCAN                    | PK_G_GROUPINDIV            |     67 |      1 |     0   (0)|     67 |00:00:00.01 |      22 |      0 |
|* 45 |              TABLE ACCESS BY INDEX ROWID           | G_GROUPINDIV               |     67 |      1 |     1   (0)|     13 |00:00:00.01 |      72 |      0 |
|* 46 |             FILTER                                 |                            |      1 |        |            |      0 |00:00:00.01 |       6 |      0 |
|  47 |              FAST DUAL                             |                            |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|  48 |              NESTED LOOPS                          |                            |      1 |      1 |     3   (0)|      1 |00:00:00.01 |       6 |      0 |
|  49 |               NESTED LOOPS                         |                            |      1 |      1 |     3   (0)|      1 |00:00:00.01 |       5 |      0 |
|* 50 |                TABLE ACCESS BY INDEX ROWID BATCHED | G_GROUPINDIVDET            |      1 |      1 |     2   (0)|      1 |00:00:00.01 |       3 |      0 |
|* 51 |                 INDEX RANGE SCAN                   | G_GROUPINDIVDET_REF1_IDX   |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       2 |      0 |
|* 52 |                INDEX UNIQUE SCAN                   | PK_G_GROUPINDIV            |      1 |      1 |     0   (0)|      1 |00:00:00.01 |       2 |      0 |
|* 53 |               TABLE ACCESS BY INDEX ROWID          | G_GROUPINDIV               |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       1 |      0 |
|* 54 |           INDEX RANGE SCAN                         | INT_INDIV                  |     13 |      3 |     2   (0)|   9264 |00:00:00.01 |      93 |      0 |
|* 55 |          TABLE ACCESS BY INDEX ROWID               | G_DOSSIER                  |   9264 |      1 |     2   (0)|   9241 |00:00:00.09 |   20771 |      0 |
|* 56 |           INDEX UNIQUE SCAN                        | DOS_REFDOSS                |   9264 |      1 |     1   (0)|   9264 |00:00:00.03 |   12885 |      0 |
|  57 |         TABLE ACCESS BY INDEX ROWID BATCHED        | G_PIECE                    |   9241 |      1 |     4   (0)|     14 |00:00:00.66 |   22614 |    417 |
|* 58 |          INDEX RANGE SCAN                          | PIE_REFDOSS                |   9241 |      1 |     3   (0)|     14 |00:00:00.64 |   22586 |    403 |
|  59 |        TABLE ACCESS BY INDEX ROWID BATCHED         | G_DOSSIER                  |     14 |      1 |     4   (0)|     14 |00:00:00.02 |      45 |     12 |
|* 60 |         INDEX RANGE SCAN                           | G_DOSSIER_RL_CD_RD_RF_IDX  |     14 |      3 |     2   (0)|     14 |00:00:00.02 |      31 |     12 |
|* 61 |       INDEX RANGE SCAN                             | PIE_REFDOSS                |     14 |      1 |     3   (0)|     14 |00:00:00.03 |      48 |     14 |
|* 62 |      TABLE ACCESS BY INDEX ROWID                   | G_PIECE                    |     14 |      1 |     4   (0)|     14 |00:00:00.04 |      28 |     14 |
|  63 |     NESTED LOOPS                                   |                            |      1 |      1 |    43   (0)|      0 |00:00:01.45 |    3732 |    676 |
|  64 |      NESTED LOOPS                                  |                            |      1 |      1 |    43   (0)|      0 |00:00:01.45 |    3732 |    676 |
|  65 |       NESTED LOOPS                                 |                            |      1 |      1 |    42   (0)|    237 |00:00:01.44 |    3729 |    675 |
|  66 |        NESTED LOOPS                                |                            |      1 |      1 |    38   (0)|    237 |00:00:00.75 |    2347 |    373 |
|  67 |         NESTED LOOPS                               |                            |      1 |      1 |    14   (0)|    153 |00:00:00.60 |    1553 |    289 |
|  68 |          NESTED LOOPS                              |                            |      1 |      1 |    10   (0)|    153 |00:00:00.09 |     648 |     43 |
|  69 |           NESTED LOOPS                             |                            |      1 |      1 |     8   (0)|    153 |00:00:00.06 |      97 |     42 |
|  70 |            NESTED LOOPS                            |                            |      1 |      1 |     6   (0)|     30 |00:00:00.04 |      49 |     28 |
|* 71 |             TABLE ACCESS FULL                      | MAX_FIU_LIMIT              |      1 |      1 |     5   (0)|     30 |00:00:00.02 |      15 |     14 |
|* 72 |             TABLE ACCESS BY INDEX ROWID            | GROUP_CONTRACTS            |     30 |      1 |     1   (0)|     30 |00:00:00.02 |      34 |     14 |
|* 73 |              INDEX UNIQUE SCAN                     | PK_GROUP_CONTRACTS         |     30 |      1 |     0   (0)|     30 |00:00:00.01 |       4 |      1 |
|  74 |            TABLE ACCESS BY INDEX ROWID BATCHED     | MEMBER_CONTRACT            |     30 |      5 |     2   (0)|    153 |00:00:00.02 |      48 |     14 |
|* 75 |             INDEX RANGE SCAN                       | MC_REFGROUP_IDX            |     30 |      5 |     0   (0)|    153 |00:00:00.01 |       3 |      1 |
|  76 |           TABLE ACCESS BY INDEX ROWID              | G_DOSSIER                  |    153 |      1 |     2   (0)|    153 |00:00:00.03 |     551 |      1 |
|* 77 |            INDEX UNIQUE SCAN                       | DOS_REFDOSS                |    153 |      1 |     1   (0)|    153 |00:00:00.02 |     308 |      1 |
|  78 |          TABLE ACCESS BY INDEX ROWID BATCHED       | G_PIECE                    |    153 |      1 |     4   (0)|    153 |00:00:00.51 |     905 |    246 |
|* 79 |           INDEX RANGE SCAN                         | PIE_REFDOSS                |    153 |      1 |     3   (0)|    153 |00:00:00.34 |     461 |    124 |
|  80 |         TABLE ACCESS BY INDEX ROWID BATCHED        | G_DOSSIER                  |    153 |     39 |    24   (0)|    237 |00:00:00.15 |     794 |     84 |
|* 81 |          INDEX RANGE SCAN                          | DOSS_LOT                   |    153 |     40 |     2   (0)|    237 |00:00:00.15 |     308 |     84 |
|* 82 |        TABLE ACCESS BY INDEX ROWID BATCHED         | G_PIECE                    |    237 |      1 |     4   (0)|    237 |00:00:00.69 |    1382 |    302 |
|* 83 |         INDEX RANGE SCAN                           | PIE_REFDOSS                |    237 |      1 |     3   (0)|    237 |00:00:00.64 |     751 |    241 |
|* 84 |       INDEX RANGE SCAN                             | MC_REFDOSS_IDX             |    237 |      1 |     0   (0)|      0 |00:00:00.01 |       3 |      1 |
|* 85 |      TABLE ACCESS BY INDEX ROWID                   | MEMBER_CONTRACT            |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
-----------------------------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   8 - filter("CP"."TYPPIECE"='CLIENT_PARAMS')
   9 - access("CP"."GPIHEURE"=:B1)
  10 - access("CD"."REFPIECE"="CP"."REFPIECE" AND "CD"."TYPE"='CONC_DET')
       filter(TRUNC(INTERNAL_FUNCTION("CD"."DT01_DT"))<=TRUNC(SYSDATE@!))
  11 - filter(("CD"."STR5" IS NULL AND NVL("CD"."STR2",'V')='V' AND NVL("CD"."DT03_DT",SYSDATE@!+1)>=TRUNC(SYSDATE@!)))
  16 - filter("CP"."TYPPIECE"='CLIENT_PARAMS')
  17 - access("CP"."GPIHEURE"=:B1)
  18 - access("CD"."REFPIECE"="CP"."REFPIECE" AND "CD"."TYPE"='CONC_DET')
       filter(TRUNC(INTERNAL_FUNCTION("CD"."DT01_DT"))<=TRUNC(SYSDATE@!))
  19 - filter(("CD"."STR5"=:B8 AND NVL("CD"."STR2",'V')='V' AND NVL("CD"."DT03_DT",SYSDATE@!+1)>=TRUNC(SYSDATE@!)))
  22 - filter((NVL("CD"."STR2",'V')='V' AND "CD"."STR5" IS NULL AND NVL("CD"."DT03_DT",SYSDATE@!+1)>=TRUNC(SYSDATE@!)))
  23 - access("CD"."REFINDIVIDU"=:B1 AND "CD"."TYPE"='CONC_DET')
       filter(TRUNC(INTERNAL_FUNCTION("DT01_DT"))<=TRUNC(SYSDATE@!))
  26 - filter(("CD"."STR5"=:B8 AND NVL("CD"."STR2",'V')='V' AND NVL("CD"."DT03_DT",SYSDATE@!+1)>=TRUNC(SYSDATE@!)))
  27 - access("CD"."REFINDIVIDU"=:B1 AND "CD"."TYPE"='CONC_DET')
       filter(TRUNC(INTERNAL_FUNCTION("DT01_DT"))<=TRUNC(SYSDATE@!))
  40 - filter("TYPE"='LIST')
  41 - access("REF1"=:B1)
  42 - filter("GCLD"."TYPE"='LIST')
  43 - access("REFGROUPE"="GCLD"."REFGROUPE")
  44 - access("GCLD"."REFGROUPE"="GCL"."REFGROUPE")
  45 - filter("GCL"."TYPE"='CLIENTS')
  46 - filter( IS NULL)
  50 - filter("CLGRD"."TYPE"='LIST')
  51 - access("CLGRD"."REF1"=:B1)
  52 - access("CLGR"."REFGROUPE"="CLGRD"."REFGROUPE")
  53 - filter("CLGR"."TYPE"='CLIENTS')
  54 - access("CL"."REFINDIVIDU"="INDIV"."REFINDIVIDU")
  55 - filter("CL"."REFTYPE"=DECODE("CTR"."CATEGDOSS",'CONTRAT IMP','TC','CL'))
  56 - access("CL"."REFDOSS"="CTR"."REFDOSS")
  58 - access("PCTR"."REFDOSS"="CTR"."REFDOSS" AND "PCTR"."TYPPIECE"='CONTRAT')
       filter("PCTR"."REFDOSS" IS NOT NULL)
  60 - access("CTR"."REFDOSS"="D"."REFLOT" AND "D"."CATEGDOSS" LIKE 'DECOMPTE%')
       filter("D"."CATEGDOSS" LIKE 'DECOMPTE%')
  61 - access("PSC"."REFDOSS"="D"."REFDOSS" AND "PSC"."TYPPIECE"='SOUS-CONTRAT')
       filter("PSC"."REFDOSS" IS NOT NULL)
  62 - filter(NVL("PSC"."FG30",'N')=:B2)
  71 - filter((TRUNC(INTERNAL_FUNCTION("MF"."START_DT"))<=TRUNC(SYSDATE@!) AND TRUNC(NVL("MF"."END_DT",SYSDATE@!+1))>=TRUNC(SYSDATE@!) AND
              NVL("MF"."STATUS",'V')='V'))
  72 - filter("GC"."VALID"='O')
  73 - access("MF"."REFGROUP"="GC"."REFGROUP")
  75 - access("GC"."REFGROUP"="MC"."REFGROUP")
  77 - access("CTR"."REFDOSS"="MC"."REFDOSS")
  79 - access("PCTR"."REFDOSS"="CTR"."REFDOSS" AND "PCTR"."TYPPIECE"='CONTRAT')
       filter("PCTR"."REFDOSS" IS NOT NULL)
  81 - access("D"."REFLOT"="CTR"."REFDOSS")
  82 - filter(NVL("PSC"."FG30",'N')=:B2)
  83 - access("PSC"."REFDOSS"="D"."REFDOSS" AND "PSC"."TYPPIECE"='SOUS-CONTRAT')
       filter("PSC"."REFDOSS" IS NOT NULL)
  84 - access("REFDOSS"=:B9)
  85 - filter("MC"."REFGROUP"="REFGROUP")
*/
/********************************OLD Metrics***************************************/

/********************************New SQL*******************************************/

SELECT STMNT,
       CTR,
       GR_CTR,
       CL,
       GR,
       REFFACTOR,
       STMNT_MAX_FIU,
       CTR_MAX_FIU,
       GR_CTR_MAX_FIU,
       CL_MAX_FIU,
       CL_BU_MAX_FIU,
       GR_MAX_FIU,
       GR_BU_MAX_FIU,
       STMNT_CURR_FIU,
       STMNT_PEND_ITEMS,
       ROWNUM
  FROM (SELECT /*+ leading(INDIV CL) */
               D.REFDOSS STMNT,
               D.REFFACTOR REFFACTOR,
               CTR.REFDOSS CTR,
               NULL GR_CTR,
               CL.REFINDIVIDU CL,
               INDIV.REFGROUPE GR,
               FTR_VIEWS.CONV(PSC.MT39, D.DEVISE, :B3) STMNT_MAX_FIU,
               FTR_VIEWS.CONV(PCTR.MT39, CTR.DEVISE, :B3) CTR_MAX_FIU,
               NULL GR_CTR_MAX_FIU,
               (SELECT DISTINCT FIRST_VALUE(FTR_VIEWS.CONV(CD.MT01,
                                                           CD.STR1,
                                                           :B3)) OVER(ORDER BY CD.DT01_DT DESC NULLS LAST)
                  FROM G_PIECEDET CD, G_PIECE CP
                 WHERE CP.TYPPIECE = 'CLIENT_PARAMS'
                   AND CP.GPIHEURE = CL.REFINDIVIDU
                   AND CD.TYPE = 'CONC_DET'
                   AND CD.REFPIECE = CP.REFPIECE
                   AND TRUNC(CD.DT01_DT) <= TRUNC(SYSDATE)
                   AND TRUNC(SYSDATE) <= NVL(CD.DT03_DT, SYSDATE + 1)
                   AND NVL(CD.STR2, 'V') = 'V'
                   AND CD.STR5 IS NULL) CL_MAX_FIU,
               (SELECT DISTINCT FIRST_VALUE(FTR_VIEWS.CONV(CD.MT01,
                                                           CD.STR1,
                                                           :B3)) OVER(ORDER BY CD.DT01_DT DESC NULLS LAST)
                  FROM G_PIECEDET CD, G_PIECE CP
                 WHERE CP.TYPPIECE = 'CLIENT_PARAMS'
                   AND CP.GPIHEURE = CL.REFINDIVIDU
                   AND CD.TYPE = 'CONC_DET'
                   AND CD.REFPIECE = CP.REFPIECE
                   AND TRUNC(CD.DT01_DT) <= TRUNC(SYSDATE)
                   AND TRUNC(SYSDATE) <= NVL(CD.DT03_DT, SYSDATE + 1)
                   AND NVL(CD.STR2, 'V') = 'V'
                   AND CD.STR5 = :B8) CL_BU_MAX_FIU,
               (SELECT DISTINCT FIRST_VALUE(FTR_VIEWS.CONV(CD.MT01,
                                                           CD.STR1,
                                                           :B3)) OVER(ORDER BY CD.DT01_DT DESC NULLS LAST)
                  FROM G_INDIVPARAM CD
                 WHERE CD.TYPE = 'CONC_DET'
                   AND CD.REFINDIVIDU = INDIV.REFGROUPE
                   AND TRUNC(CD.DT01_DT) <= TRUNC(SYSDATE)
                   AND TRUNC(SYSDATE) <= NVL(CD.DT03_DT, SYSDATE + 1)
                   AND NVL(CD.STR2, 'V') = 'V'
                   AND CD.STR5 IS NULL) GR_MAX_FIU,
               (SELECT DISTINCT FIRST_VALUE(FTR_VIEWS.CONV(CD.MT01,
                                                           CD.STR1,
                                                           :B3)) OVER(ORDER BY CD.DT01_DT DESC NULLS LAST)
                  FROM G_INDIVPARAM CD
                 WHERE CD.TYPE = 'CONC_DET'
                   AND CD.REFINDIVIDU = INDIV.REFGROUPE
                   AND TRUNC(CD.DT01_DT) <= TRUNC(SYSDATE)
                   AND TRUNC(SYSDATE) <= NVL(CD.DT03_DT, SYSDATE + 1)
                   AND NVL(CD.STR2, 'V') = 'V'
                   AND CD.STR5 = :B8) GR_BU_MAX_FIU,
               FTR_VIEWS.CONV(DECODE(:B2,
                                     'O',
                                     FTR_DECOMPTE.GETFUNDINGSENT(D.REFDOSS),
                                     FTR_DECOMPTE.GETFIU_CASH(D.REFDOSS) +
                                     FTR_DECOMPTE.GETFIU_STRAIGHTLOAN(D.REFDOSS) +
                                     FTR_DECOMPTE.GETFIU_LOAN(D.REFDOSS) +
                                     FTR_DECOMPTE.GETBLOCKEDAMOUNTSTD(D.REFDOSS,
                                                                      'UTILISATION_EXTERNE')),
                              D.DEVISE,
                              :B3) STMNT_CURR_FIU,
               FTR_VIEWS.CONV(FTR_DECOMPTE.GETPENDINGPAYMENTS(D.REFDOSS) +
                              INV_PENDING_PMT.GETPENDINGCOSTS(D.REFDOSS) +
                              DECODE(:B7,
                                     'O',
                                     FTR_DECOMPTE.GETPENDINGBUNDLES(D.REFDOSS),
                                     0) + CASE
                                WHEN :B6 = 'O' THEN
                                 0
                                WHEN :B5 = 'O' THEN
                                 GREATEST(FACTOR_INVFUNC.GETFUNDINGCOMMISSION(D.REFDOSS,
                                                                              TO_CHAR(to_date(:B4,'MM-DD-YYYY'),
                                                                                      'j'),
                                                                              'supplier'),
                                          0)
                                ELSE
                                 FACTOR_INVFUNC.GETFUNDINGCOMMISSION(D.REFDOSS,
                                                                     TO_CHAR(to_date(:B4,'MM-DD-YYYY'), 'j'),
                                                                     'supplier')
                              END,
                              D.DEVISE,
                              :B3) STMNT_PEND_ITEMS
          FROM G_DOSSIER D,
               G_PIECE PSC,
               G_DOSSIER CTR,
               G_PIECE PCTR,
               T_INTERVENANTS CL,
               ( SELECT GCLD.REF1 REFINDIVIDU, 
                        GCL.REFGROUPE REFGROUPE
                   FROM G_GROUPINDIVDET GCLD, 
                        G_GROUPINDIV GCL
                  WHERE GCLD.TYPE = 'LIST'
                    AND GCL.TYPE = 'CLIENTS'
                    AND GCLD.REFGROUPE = GCL.REFGROUPE
                    AND EXISTS ( SELECT 1
                                   FROM G_GROUPINDIVDET
                                  WHERE REFGROUPE = GCLD.REFGROUPE
                                    AND TYPE = 'LIST'
                                    AND REF1 = :B1 )
                 UNION ALL
                 SELECT :B1, NULL
                   FROM DUAL
                  WHERE NOT EXISTS ( SELECT 1
                                       FROM G_GROUPINDIV CLGR, 
                                            G_GROUPINDIVDET CLGRD
                                      WHERE CLGR.REFGROUPE = CLGRD.REFGROUPE
                                        AND CLGR.TYPE = 'CLIENTS'
                                        AND CLGRD.TYPE = 'LIST'
                                        AND CLGRD.REF1 = :B1 ) ) INDIV
         WHERE D.CATEGDOSS LIKE 'DECOMPTE%'
           AND PSC.TYPPIECE = 'SOUS-CONTRAT'
           AND PSC.REFDOSS = D.REFDOSS
           AND CTR.REFDOSS = D.REFLOT
           AND PCTR.TYPPIECE = 'CONTRAT'
           AND PCTR.REFDOSS = CTR.REFDOSS
           AND CL.REFTYPE = DECODE(CTR.CATEGDOSS, 'CONTRAT IMP', 'TC', 'CL')
           AND CL.REFDOSS = PCTR.REFDOSS
           AND CL.REFINDIVIDU = INDIV.REFINDIVIDU
           AND NVL(PSC.FG30, 'N') = :B2
        UNION ALL
        SELECT /*+ leading(CONTR_GR) */
               D.REFDOSS STMNT,
               D.REFFACTOR REFFACTOR,
               MC.REFDOSS CTR,
               MC.REFGROUP GR_CTR,
               NULL CL,
               NULL GR,
               FTR_VIEWS.CONV(PSC.MT39, D.DEVISE, :B3) STMNT_MAX_FIU,
                FTR_VIEWS.CONV(PCTR.MT39, CTR.DEVISE, :B3) CTR_MAX_FIU,
               FTR_VIEWS.CONV(MF.AMOUNT, MF.CURRENCY, :B3) GR_CTR_MAX_FIU,
               NULL CL_MAX_FIU,
               NULL CL_BU_MAX_FIU,
               NULL GR_MAX_FIU,
               NULL GR_BU_MAX_FIU,
               FTR_VIEWS.CONV(DECODE(:B2,
                                     'O',
                                     FTR_DECOMPTE.GETFUNDINGSENT(D.REFDOSS),
                                     FTR_DECOMPTE.GETFIU_CASH(D.REFDOSS) +
                                     FTR_DECOMPTE.GETFIU_STRAIGHTLOAN(D.REFDOSS) +
                                     FTR_DECOMPTE.GETFIU_LOAN(D.REFDOSS) +
                                     FTR_DECOMPTE.GETBLOCKEDAMOUNTSTD(D.REFDOSS,
                                                                      'UTILISATION_EXTERNE')),
                              D.DEVISE,
                              :B3) STMNT_CURR_FIU,
               FTR_VIEWS.CONV(FTR_DECOMPTE.GETPENDINGPAYMENTS(D.REFDOSS) +
                              INV_PENDING_PMT.GETPENDINGCOSTS(D.REFDOSS) +
                              DECODE(:B7,
                                     'O',
                                     FTR_DECOMPTE.GETPENDINGBUNDLES(D.REFDOSS),
                                     0) + CASE
                                WHEN :B6 = 'O' THEN
                                 0
                                WHEN :B5 = 'O' THEN
                                 GREATEST(FACTOR_INVFUNC.GETFUNDINGCOMMISSION(D.REFDOSS,TO_CHAR(to_date(:B4,'MM-DD-YYYY'),'j'),'supplier'),
                                          0)
                                ELSE
                                 FACTOR_INVFUNC.GETFUNDINGCOMMISSION(D.REFDOSS,
                                                                     TO_CHAR(to_date(:B4,'MM-DD-YYYY'), 'j'),
                                                                     'supplier')
                              END,
                              D.DEVISE,
                              :B3) STMNT_PEND_ITEMS
          FROM MEMBER_CONTRACT MC,
               GROUP_CONTRACTS GC,
               MAX_FIU_LIMIT MF,
               G_DOSSIER CTR,
               G_DOSSIER D,
               G_PIECE PSC,
               G_PIECE PCTR,
               ( SELECT REFGROUP 
                   FROM MEMBER_CONTRACT 
                  WHERE REFDOSS = :B9 ) CONTR_GR
         WHERE MC.REFGROUP = CONTR_GR.REFGROUP
           AND GC.REFGROUP = MC.REFGROUP
           AND GC.VALID = 'O'
           AND MF.REFGROUP = GC.REFGROUP
           AND TRUNC(SYSDATE) BETWEEN TRUNC(MF.START_DT) AND TRUNC(NVL(MF.END_DT, SYSDATE + 1))
           AND NVL(MF.STATUS, 'V') = 'V'
           AND CTR.REFDOSS = MC.REFDOSS
           AND D.REFLOT = CTR.REFDOSS
           AND PSC.REFDOSS = D.REFDOSS
           AND PSC.TYPPIECE = 'SOUS-CONTRAT'
           AND PCTR.REFDOSS = CTR.REFDOSS
           AND PCTR.TYPPIECE = 'CONTRAT'
           AND NVL(PSC.FG30, 'N') = :B2);
/********************************New SQL*******************************************/
/********************************New Metrics***************************************/
/*
Plan hash value: 492987280
--------------------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                          | Name                       | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers |
--------------------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                                   |                            |      1 |        |   138 (100)|     14 |00:00:00.10 |   25103 |
|   1 |  COUNT                                             |                            |      1 |        |            |     14 |00:00:00.10 |   25103 |
|   2 |   VIEW                                             |                            |      1 |      2 |   138   (7)|     14 |00:00:00.10 |   25103 |
|   3 |    UNION-ALL                                       |                            |      1 |        |            |     14 |00:00:00.10 |   25103 |
|   4 |     SORT UNIQUE                                    |                            |     12 |      1 |    10  (20)|      0 |00:00:00.01 |      56 |
|   5 |      WINDOW SORT                                   |                            |     12 |      1 |    10  (20)|      0 |00:00:00.01 |      56 |
|   6 |       NESTED LOOPS                                 |                            |     12 |      1 |     8   (0)|      0 |00:00:00.01 |      56 |
|   7 |        NESTED LOOPS                                |                            |     12 |      1 |     8   (0)|      0 |00:00:00.01 |      56 |
|*  8 |         TABLE ACCESS BY INDEX ROWID BATCHED        | G_PIECE                    |     12 |      1 |     4   (0)|     12 |00:00:00.01 |      38 |
|*  9 |          INDEX RANGE SCAN                          | G_PIECE$GPIHEURE           |     12 |      1 |     3   (0)|     12 |00:00:00.01 |      26 |
|* 10 |         INDEX RANGE SCAN                           | G_PIECEDET_REFP            |     12 |      1 |     3   (0)|      0 |00:00:00.01 |      18 |
|* 11 |        TABLE ACCESS BY INDEX ROWID                 | G_PIECEDET                 |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|  12 |     SORT UNIQUE                                    |                            |     12 |      1 |    10  (20)|      0 |00:00:00.01 |      56 |
|  13 |      WINDOW SORT                                   |                            |     12 |      1 |    10  (20)|      0 |00:00:00.01 |      56 |
|  14 |       NESTED LOOPS                                 |                            |     12 |      1 |     8   (0)|      0 |00:00:00.01 |      56 |
|  15 |        NESTED LOOPS                                |                            |     12 |      1 |     8   (0)|      0 |00:00:00.01 |      56 |
|* 16 |         TABLE ACCESS BY INDEX ROWID BATCHED        | G_PIECE                    |     12 |      1 |     4   (0)|     12 |00:00:00.01 |      38 |
|* 17 |          INDEX RANGE SCAN                          | G_PIECE$GPIHEURE           |     12 |      1 |     3   (0)|     12 |00:00:00.01 |      26 |
|* 18 |         INDEX RANGE SCAN                           | G_PIECEDET_REFP            |     12 |      1 |     3   (0)|      0 |00:00:00.01 |      18 |
|* 19 |        TABLE ACCESS BY INDEX ROWID                 | G_PIECEDET                 |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|  20 |     SORT UNIQUE                                    |                            |      1 |      1 |     6  (34)|      0 |00:00:00.01 |       3 |
|  21 |      WINDOW SORT                                   |                            |      1 |      1 |     6  (34)|      0 |00:00:00.01 |       3 |
|* 22 |       TABLE ACCESS BY INDEX ROWID BATCHED          | G_INDIVPARAM               |      1 |      1 |     4   (0)|      0 |00:00:00.01 |       3 |
|* 23 |        INDEX RANGE SCAN                            | G_IND_REFIND_TYPE_DT01     |      1 |      1 |     3   (0)|      0 |00:00:00.01 |       3 |
|  24 |     SORT UNIQUE                                    |                            |      1 |      1 |     6  (34)|      0 |00:00:00.01 |       3 |
|  25 |      WINDOW SORT                                   |                            |      1 |      1 |     6  (34)|      0 |00:00:00.01 |       3 |
|* 26 |       TABLE ACCESS BY INDEX ROWID BATCHED          | G_INDIVPARAM               |      1 |      1 |     4   (0)|      0 |00:00:00.01 |       3 |
|* 27 |        INDEX RANGE SCAN                            | G_IND_REFIND_TYPE_DT01     |      1 |      1 |     3   (0)|      0 |00:00:00.01 |       3 |
|  28 |     NESTED LOOPS                                   |                            |      1 |      1 |    59   (2)|     14 |00:00:00.07 |   23143 |
|  29 |      NESTED LOOPS                                  |                            |      1 |      1 |    59   (2)|     14 |00:00:00.07 |   23115 |
|  30 |       NESTED LOOPS                                 |                            |      1 |      1 |    55   (2)|     14 |00:00:00.07 |   23067 |
|  31 |        NESTED LOOPS                                |                            |      1 |      1 |    51   (2)|     14 |00:00:00.07 |   23022 |
|  32 |         NESTED LOOPS                               |                            |      1 |      1 |    49   (3)|     14 |00:00:00.07 |   22978 |
|  33 |          NESTED LOOPS                              |                            |      1 |      6 |    25   (4)|   9264 |00:00:00.01 |     291 |
|  34 |           VIEW                                     |                            |      1 |      2 |    21   (5)|     13 |00:00:00.01 |     198 |
|  35 |            UNION-ALL                               |                            |      1 |        |            |     13 |00:00:00.01 |     198 |
|  36 |             NESTED LOOPS                           |                            |      1 |      1 |    16   (7)|     13 |00:00:00.01 |     192 |
|  37 |              NESTED LOOPS                          |                            |      1 |      1 |    16   (7)|     67 |00:00:00.01 |     120 |
|  38 |               NESTED LOOPS                         |                            |      1 |      1 |    15   (7)|     67 |00:00:00.01 |      98 |
|  39 |                SORT UNIQUE                         |                            |      1 |      1 |     2   (0)|      3 |00:00:00.01 |       5 |
|* 40 |                 TABLE ACCESS BY INDEX ROWID BATCHED| G_GROUPINDIVDET            |      1 |      1 |     2   (0)|      3 |00:00:00.01 |       5 |
|* 41 |                  INDEX RANGE SCAN                  | G_GROUPINDIVDET_REF1_IDX   |      1 |      1 |     1   (0)|      3 |00:00:00.01 |       2 |
|* 42 |                TABLE ACCESS BY INDEX ROWID BATCHED | G_GROUPINDIVDET            |      3 |      4 |    12   (0)|     67 |00:00:00.01 |      93 |
|* 43 |                 INDEX RANGE SCAN                   | G_GROUPINDIVDET_RFTRPE_IDX |      3 |     17 |     1   (0)|     67 |00:00:00.01 |       8 |
|* 44 |               INDEX UNIQUE SCAN                    | PK_G_GROUPINDIV            |     67 |      1 |     0   (0)|     67 |00:00:00.01 |      22 |
|* 45 |              TABLE ACCESS BY INDEX ROWID           | G_GROUPINDIV               |     67 |      1 |     1   (0)|     13 |00:00:00.01 |      72 |
|* 46 |             FILTER                                 |                            |      1 |        |            |      0 |00:00:00.01 |       6 |
|  47 |              FAST DUAL                             |                            |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |
|  48 |              NESTED LOOPS                          |                            |      1 |      1 |     3   (0)|      1 |00:00:00.01 |       6 |
|  49 |               NESTED LOOPS                         |                            |      1 |      1 |     3   (0)|      1 |00:00:00.01 |       5 |
|* 50 |                TABLE ACCESS BY INDEX ROWID BATCHED | G_GROUPINDIVDET            |      1 |      1 |     2   (0)|      1 |00:00:00.01 |       3 |
|* 51 |                 INDEX RANGE SCAN                   | G_GROUPINDIVDET_REF1_IDX   |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       2 |
|* 52 |                INDEX UNIQUE SCAN                   | PK_G_GROUPINDIV            |      1 |      1 |     0   (0)|      1 |00:00:00.01 |       2 |
|* 53 |               TABLE ACCESS BY INDEX ROWID          | G_GROUPINDIV               |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       1 |
|* 54 |           INDEX RANGE SCAN                         | INT_INDIV                  |     13 |      3 |     2   (0)|   9264 |00:00:00.01 |      93 |
|  55 |          TABLE ACCESS BY INDEX ROWID BATCHED       | G_PIECE                    |   9264 |      1 |     4   (0)|     14 |00:00:00.05 |   22687 |
|* 56 |           INDEX RANGE SCAN                         | PIE_REFDOSS                |   9264 |      1 |     3   (0)|     14 |00:00:00.05 |   22659 |
|* 57 |         TABLE ACCESS BY INDEX ROWID                | G_DOSSIER                  |     14 |      1 |     2   (0)|     14 |00:00:00.01 |      44 |
|* 58 |          INDEX UNIQUE SCAN                         | DOS_REFDOSS                |     14 |      1 |     1   (0)|     14 |00:00:00.01 |      30 |
|  59 |        TABLE ACCESS BY INDEX ROWID BATCHED         | G_DOSSIER                  |     14 |      1 |     4   (0)|     14 |00:00:00.01 |      45 |
|* 60 |         INDEX RANGE SCAN                           | G_DOSSIER_RL_CD_RD_RF_IDX  |     14 |      3 |     2   (0)|     14 |00:00:00.01 |      31 |
|* 61 |       INDEX RANGE SCAN                             | PIE_REFDOSS                |     14 |      1 |     3   (0)|     14 |00:00:00.01 |      48 |
|* 62 |      TABLE ACCESS BY INDEX ROWID                   | G_PIECE                    |     14 |      1 |     4   (0)|     14 |00:00:00.01 |      28 |
|  63 |     NESTED LOOPS                                   |                            |      1 |      1 |    47   (0)|      0 |00:00:00.01 |       1 |
|  64 |      NESTED LOOPS                                  |                            |      1 |      1 |    47   (0)|      0 |00:00:00.01 |       1 |
|  65 |       NESTED LOOPS                                 |                            |      1 |      1 |    43   (0)|      0 |00:00:00.01 |       1 |
|  66 |        NESTED LOOPS                                |                            |      1 |      1 |    20   (0)|      0 |00:00:00.01 |       1 |
|  67 |         NESTED LOOPS                               |                            |      1 |      1 |    16   (0)|      0 |00:00:00.01 |       1 |
|* 68 |          HASH JOIN                                 |                            |      1 |      1 |    14   (0)|      0 |00:00:00.01 |       1 |
|  69 |           NESTED LOOPS                             |                            |      1 |      3 |     9   (0)|      0 |00:00:00.01 |       1 |
|  70 |            NESTED LOOPS                            |                            |      1 |      5 |     9   (0)|      0 |00:00:00.01 |       1 |
|  71 |             NESTED LOOPS                           |                            |      1 |      5 |     4   (0)|      0 |00:00:00.01 |       1 |
|  72 |              TABLE ACCESS BY INDEX ROWID BATCHED   | MEMBER_CONTRACT            |      1 |      1 |     2   (0)|      0 |00:00:00.01 |       1 |
|* 73 |               INDEX RANGE SCAN                     | MC_REFDOSS_IDX             |      1 |      1 |     1   (0)|      0 |00:00:00.01 |       1 |
|  74 |              TABLE ACCESS BY INDEX ROWID BATCHED   | MEMBER_CONTRACT            |      0 |      5 |     2   (0)|      0 |00:00:00.01 |       0 |
|* 75 |               INDEX RANGE SCAN                     | MC_REFGROUP_IDX            |      0 |      5 |     0   (0)|      0 |00:00:00.01 |       0 |
|* 76 |             INDEX UNIQUE SCAN                      | PK_GROUP_CONTRACTS         |      0 |      1 |     0   (0)|      0 |00:00:00.01 |       0 |
|* 77 |            TABLE ACCESS BY INDEX ROWID             | GROUP_CONTRACTS            |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 78 |           TABLE ACCESS FULL                        | MAX_FIU_LIMIT              |      0 |      1 |     5   (0)|      0 |00:00:00.01 |       0 |
|  79 |          TABLE ACCESS BY INDEX ROWID               | G_DOSSIER                  |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |
|* 80 |           INDEX UNIQUE SCAN                        | DOS_REFDOSS                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|  81 |         TABLE ACCESS BY INDEX ROWID BATCHED        | G_PIECE                    |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|* 82 |          INDEX RANGE SCAN                          | PIE_REFDOSS                |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|  83 |        TABLE ACCESS BY INDEX ROWID BATCHED         | G_DOSSIER                  |      0 |     39 |    23   (0)|      0 |00:00:00.01 |       0 |
|* 84 |         INDEX RANGE SCAN                           | DOSS_LOT                   |      0 |     40 |     2   (0)|      0 |00:00:00.01 |       0 |
|* 85 |       INDEX RANGE SCAN                             | PIE_REFDOSS                |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|* 86 |      TABLE ACCESS BY INDEX ROWID                   | G_PIECE                    |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
--------------------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   8 - filter("CP"."TYPPIECE"='CLIENT_PARAMS')
   9 - access("CP"."GPIHEURE"=:B1)
  10 - access("CD"."REFPIECE"="CP"."REFPIECE" AND "CD"."TYPE"='CONC_DET')
       filter(TRUNC(INTERNAL_FUNCTION("CD"."DT01_DT"))<=TRUNC(SYSDATE@!))
  11 - filter(("CD"."STR5" IS NULL AND NVL("CD"."STR2",'V')='V' AND NVL("CD"."DT03_DT",SYSDATE@!+1)>=TRUNC(SYSDATE@!)))
  16 - filter("CP"."TYPPIECE"='CLIENT_PARAMS')
  17 - access("CP"."GPIHEURE"=:B1)
  18 - access("CD"."REFPIECE"="CP"."REFPIECE" AND "CD"."TYPE"='CONC_DET')
       filter(TRUNC(INTERNAL_FUNCTION("CD"."DT01_DT"))<=TRUNC(SYSDATE@!))
  19 - filter(("CD"."STR5"=:B8 AND NVL("CD"."STR2",'V')='V' AND NVL("CD"."DT03_DT",SYSDATE@!+1)>=TRUNC(SYSDATE@!)))
  22 - filter((NVL("CD"."STR2",'V')='V' AND "CD"."STR5" IS NULL AND NVL("CD"."DT03_DT",SYSDATE@!+1)>=TRUNC(SYSDATE@!)))
  23 - access("CD"."REFINDIVIDU"=:B1 AND "CD"."TYPE"='CONC_DET')
       filter(TRUNC(INTERNAL_FUNCTION("DT01_DT"))<=TRUNC(SYSDATE@!))
  26 - filter(("CD"."STR5"=:B8 AND NVL("CD"."STR2",'V')='V' AND NVL("CD"."DT03_DT",SYSDATE@!+1)>=TRUNC(SYSDATE@!)))
  27 - access("CD"."REFINDIVIDU"=:B1 AND "CD"."TYPE"='CONC_DET')
       filter(TRUNC(INTERNAL_FUNCTION("DT01_DT"))<=TRUNC(SYSDATE@!))
  40 - filter("TYPE"='LIST')
  41 - access("REF1"=:B1)
  42 - filter("GCLD"."TYPE"='LIST')
  43 - access("REFGROUPE"="GCLD"."REFGROUPE")
  44 - access("GCLD"."REFGROUPE"="GCL"."REFGROUPE")
  45 - filter("GCL"."TYPE"='CLIENTS')
  46 - filter( IS NULL)
  50 - filter("CLGRD"."TYPE"='LIST')
  51 - access("CLGRD"."REF1"=:B1)
  52 - access("CLGR"."REFGROUPE"="CLGRD"."REFGROUPE")
  53 - filter("CLGR"."TYPE"='CLIENTS')
  54 - access("CL"."REFINDIVIDU"="INDIV"."REFINDIVIDU")
  56 - access("CL"."REFDOSS"="PCTR"."REFDOSS" AND "PCTR"."TYPPIECE"='CONTRAT')
       filter("PCTR"."REFDOSS" IS NOT NULL)
  57 - filter("CL"."REFTYPE"=DECODE("CTR"."CATEGDOSS",'CONTRAT IMP','TC','CL'))
  58 - access("PCTR"."REFDOSS"="CTR"."REFDOSS")
  60 - access("CTR"."REFDOSS"="D"."REFLOT" AND "D"."CATEGDOSS" LIKE 'DECOMPTE%')
       filter("D"."CATEGDOSS" LIKE 'DECOMPTE%')
  61 - access("PSC"."REFDOSS"="D"."REFDOSS" AND "PSC"."TYPPIECE"='SOUS-CONTRAT')
       filter("PSC"."REFDOSS" IS NOT NULL)
  62 - filter(NVL("PSC"."FG30",'N')=:B2)
  68 - access("MF"."REFGROUP"="GC"."REFGROUP")
  73 - access("REFDOSS"=:B9)
  75 - access("MC"."REFGROUP"="REFGROUP")
  76 - access("GC"."REFGROUP"="MC"."REFGROUP")
  77 - filter("GC"."VALID"='O')
  78 - filter((TRUNC(INTERNAL_FUNCTION("MF"."START_DT"))<=TRUNC(SYSDATE@!) AND TRUNC(NVL("MF"."END_DT",SYSDATE@!+1))>=TRUNC(SYSDATE@!) AND
              NVL("MF"."STATUS",'V')='V'))
  80 - access("CTR"."REFDOSS"="MC"."REFDOSS")
  82 - access("PCTR"."REFDOSS"="CTR"."REFDOSS" AND "PCTR"."TYPPIECE"='CONTRAT')
       filter("PCTR"."REFDOSS" IS NOT NULL)
  84 - access("D"."REFLOT"="CTR"."REFDOSS")
  85 - access("PSC"."REFDOSS"="D"."REFDOSS" AND "PSC"."TYPPIECE"='SOUS-CONTRAT')
       filter("PSC"."REFDOSS" IS NOT NULL)
  86 - filter(NVL("PSC"."FG30",'N')=:B2)

*/
/********************************New Metrics***************************************/

/********************************Index statistics**********************************/

/********************************Other SQLs****************************************/          
/*

*/ 
/********************************Other SQLs****************************************/              
