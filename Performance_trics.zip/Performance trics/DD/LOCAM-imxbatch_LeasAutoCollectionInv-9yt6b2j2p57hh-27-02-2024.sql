/********************************************************************************
*********       E-mail subject: LOCAMDEV-22821
*********             Instance: BIRDVAL
*********          Description: 
Problem:
Slowness in LeasAutoCollectionInv batch on BIRDVAL.

Analysis:
The TOP SQL for module imxbatch_LeasAutoCollectionInv for the provided period was 9yt6b2j2p57hh.
The problem in this SQL is that we have a lot of rows selected from the other tables and table G_ELEMFI FI_FR 
should also be accessed a lot of times. Because there is no appropriate index on column LIBELLE_20_2 on table G_ELEMFI,  
it uses column REFDOSS and the index on it, which leads to searching in a lot of data, which is slow. On refbg2, there is already 
index on column LIBELLE_20_2 on table G_ELEMFI, so this index should be delivered to BIRDVAL.

Suggestion:
Please deliver index G_ELEM_LIBEL_IDX on table G_ELEMFI from refbg2 to BIRDVAL.

*********               SQL_ID: 9yt6b2j2p57hh
*********      Program/Package: imxbatch_LeasAutoCollectionInv
*********              Request: Rositsa Nenova 
*********               Author: Dimitar Dimitrov
********* Received e-mail date: 27-02-2024
*********      Resolution date: 27-02-2024
*********  Trace old file here: \\epox\specifs\performance\tmp\
*********  Trace new file here:
***********************************************************************************/

/********************************OLD SQL*******************************************/

var B1 VARCHAR2(128);
exec :B1 := '';
var B2 VARCHAR2(128);
exec :B2 := '2012110094';
var B3 NUMBER;
exec :B3 := NULL;
var B4 VARCHAR2(128);
exec :B4 := '';
var B5 VARCHAR2(128);
exec :B5 := '';

SELECT *
  FROM (SELECT FI_CA.REFELEM REFELEMCA,
               FI_CA.MONTANT_DOS AMOUNTCA,
               FI_CA.DTJOUR_DT,
               FI_CA.DTDEBUT DTINVOICCA,
               NVL(FI_CA.MT_OUVERT_MVT, FI_CA.MONTANT_DOS) BALCA,
               FI_FR.REFELEM REFELEMFR,
               FI_FR.MONTANT_DOS AMOUNTFR,
               NVL(FI_FR.MT_OUVERT_MVT, FI_FR.MONTANT_DOS) BALFR,
               FI_FR.REFDOSS REFDOSSFR,
               NVL(VFI.MATCHING_PRIORITY, 999) MPRIORITY,
               FI_CA.LETTRAGEGRP MATCHGRPCA,
               CASE FI_CA.LETTRAGEGRP
                 WHEN :B4 THEN
                  1
                 ELSE
                  0
               END MATCHGORUP,
               CASE
                 WHEN FI_CA.DTDEBUT > :B3 THEN
                  1
                 ELSE
                  0
               END FGMATURED
          FROM G_ELEMFI FI_CA,
               F_ENTREL ENT,
               F_DETFAC DET,
               G_ELEMFI FI_FR,
               V_ELEMFI VFI
         WHERE FI_CA.REFDOSS = :B2
           AND FI_CA.LIBELLE_20_1 = ENT.ER_NUM
           AND DET.DF_REL = ENT.ER_NUM
           AND DET.DF_CLI = ENT.ER_CLI
           AND FI_FR.REFDOSS = DET.DF_DOS
           AND FI_FR.LIBELLE_20_2 = DET.DF_NUM
           AND FI_CA.DTANNUL IS NULL
           AND FI_FR.DTANNUL IS NULL
           AND FI_CA.DTTRAITE IS NULL
           AND FI_FR.DTTRAITE IS NULL
           AND NVL(FI_FR.MT_OUVERT_MVT, FI_FR.MONTANT_DOS) > 0
           AND NVL(FI_CA.MT_OUVERT_MVT, FI_CA.MONTANT_DOS) > 0
           AND FI_FR.MONTANT_DOS > 0
           AND VFI.TYPE = FI_FR.TYPE
           AND (:B1 IS NULL OR FI_FR.REFDOSS = :B1)
        UNION ALL
        SELECT FI_CA.REFELEM REFELEMCA,
               FI_CA.MONTANT_DOS AMOUNTCA,
               FI_CA.DTJOUR_DT,
               FI_CA.DTDEBUT DTINVOICCA,
               NVL(FI_CA.MT_OUVERT_MVT, FI_CA.MONTANT_DOS) BALCA,
               NULL REFELEMFR,
               NULL AMOUNTFR,
               NULL BALFR,
               NULL REFDOSSFR,
               NULL MPRIORITY,
               FI_CA.LETTRAGEGRP MATCHGRPCA,
               CASE FI_CA.LETTRAGEGRP
                 WHEN :B4 THEN
                  1
                 ELSE
                  0
               END MATCHGORUP,
               CASE
                 WHEN FI_CA.DTDEBUT > :B3 THEN
                  1
                 ELSE
                  0
               END FGMATURED
          FROM G_ELEMFI FI_CA
         WHERE FI_CA.REFDOSS = :B2
           AND FI_CA.DTANNUL IS NULL
           AND FI_CA.DTTRAITE IS NULL
           AND FI_CA.LIBELLE_20_1 IS NULL
           AND FI_CA.MONTANT_DOS > 0
           AND NVL(FI_CA.MT_OUVERT_MVT, FI_CA.MONTANT_DOS) > 0
        UNION ALL
        SELECT FI_CA.REFELEM REFELEMCA,
               FI_CA.MONTANT_DOS AMOUNTCA,
               FI_CA.DTJOUR_DT,
               FI_CA.DTDEBUT DTINVOICCA,
               NVL(FI_CA.MT_OUVERT_MVT, FI_CA.MONTANT_DOS) BALCA,
               NULL REFELEMFR,
               NULL AMOUNTFR,
               NULL BALFR,
               NULL REFDOSSFR,
               NULL MPRIORITY,
               FI_CA.LETTRAGEGRP MATCHGRPCA,
               CASE FI_CA.LETTRAGEGRP
                 WHEN :B4 THEN
                  1
                 ELSE
                  0
               END MATCHGORUP,
               CASE
                 WHEN FI_CA.DTDEBUT > :B3 THEN
                  1
                 ELSE
                  0
               END FGMATURED
          FROM G_ELEMFI FI_CA
         WHERE FI_CA.REFDOSS = :B2
           AND FI_CA.DTANNUL IS NULL
           AND FI_CA.DTTRAITE IS NULL
           AND FI_CA.LIBELLE_20_1 IS NOT NULL
           AND FI_CA.MONTANT_DOS > 0
           AND NVL(FI_CA.MT_OUVERT_MVT, FI_CA.MONTANT_DOS) > 0
           AND NOT EXISTS
         (SELECT 1 FROM G_ELEMFI WHERE REFELEM_CA = FI_CA.REFELEM))
 ORDER BY MATCHGORUP DESC,
          CASE :B5
            WHEN 'FIORDERMAT' THEN
             FGMATURED
          END ASC,
          CASE :B5
            WHEN 'FIORDERMAT' THEN
             CASE FGMATURED
               WHEN 1 THEN
                DTINVOICCA
             END
          END,
          MPRIORITY,
          DTINVOICCA ASC,
          REFELEMFR DESC;
/********************************OLD SQL*******************************************/
/********************************OLD Metrics***************************************/
/*
MODULE                           SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
imxbatch_LeasAutoCollectionInv                                  2005      65377 ON CPU               2024/02/27 02:29:27  2024/02/27 04:00:06        5310               326082 +000000000 01:30:39.146 68%
                                                        0       1139      58652 log file parallel wr 2024/02/27 02:29:32  2024/02/27 04:09:29         405                      +000000000 01:39:57.186 5%
std_mon_kpi                      bc5fary7hmr3r 3938332083                       direct path read     2024/02/27 02:35:30  2024/02/27 04:06:32         263                   10 +000000000 01:31:02.172 3%
3D10E9BDD047B03134883E68EDB6D03D                                1748      65100 db file sequential r 2024/02/27 03:27:40  2024/02/27 03:30:54         189                    1 +000000000 00:03:14.001 2%


MODULE                           SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
imxbatch_LeasAutoCollectionInv                                  2005      65377 ON CPU               2024/02/27 02:29:43  2024/02/27 04:00:06        5295               326080 +000000000 01:30:23.146 98%
imxbatch_LeasAutoCollectionInv                          0       2005      65377 log file sync        2024/02/27 02:30:42  2024/02/27 03:56:59          97                      +000000000 01:26:17.142 2%
imxbatch_LeasAutoCollectionInv                                  2005      65377 db file sequential r 2024/02/27 02:31:01  2024/02/27 03:59:20          18                 6634 +000000000 01:28:19.143 0%


MODULE                           SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
imxbatch_LeasAutoCollectionInv   9yt6b2j2p57hh 2565312171       2005      65377 ON CPU               2024/02/27 02:29:46  2024/02/27 04:00:06        5169                  524 +000000000 01:30:20.146 96%
imxbatch_LeasAutoCollectionInv                          0       2005      65377                      2024/02/27 02:30:42  2024/02/27 03:56:59         103                      +000000000 01:26:17.142 2%
imxbatch_LeasAutoCollectionInv   f83d7mkuxx8jn          0       2005      65377 ON CPU               2024/02/27 02:30:13  2024/02/27 03:58:43          24                  513 +000000000 01:28:30.146 0%


INSTANCE_NUMBER SQL_ID            ELAPSED MAX_WAIT_ON     PC_OF  WAIT_TIME            GETS      READS       ROWS  ELAP/EXEC       GETS/EXEC READS/EXEC  ROWS/EXEC       EXEC PLAN_HASH_VALUE
--------------- ------------- ----------- --------------- ----- ---------- --------------- ---------- ---------- ---------- --------------- ---------- ---------- ---------- ---------------
              1 9yt6b2j2p57hh        88 98 CPU             100%  8885.35894      4103011367       3789      88449       9.81         4523717       4.18      97.52        907      2565312171

SQL_ID        SQL_PLAN_HASH_VALUE SQL_PLAN_LINE_ID SQL_PLAN_OPERATION             SQL_PLAN_OPTIONS                   ACTIVE
------------- ------------------- ---------------- ------------------------------ ------------------------------ ----------
9yt6b2j2p57hh          2565312171               15 TABLE ACCESS                   BY INDEX ROWID BATCHED               4195
9yt6b2j2p57hh          2565312171               16 INDEX                          RANGE SCAN                            725
9yt6b2j2p57hh          2565312171               14 INDEX                          RANGE SCAN                             12
9yt6b2j2p57hh          2565312171               22 TABLE ACCESS                   BY INDEX ROWID BATCHED                 10
9yt6b2j2p57hh          2565312171               11 TABLE ACCESS                   BY INDEX ROWID                          6
9yt6b2j2p57hh          2565312171               24 INDEX                          RANGE SCAN                              5




Plan hash value: 2565312171
--------------------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                   | Name                     | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  |
--------------------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                            |                          |      1 |        |     9 (100)|   4606 |00:00:16.31 |    4642K|   1726 |
|   1 |  SORT ORDER BY                              |                          |      1 |      3 |     9  (12)|   4606 |00:00:16.31 |    4642K|   1726 |
|   2 |   VIEW                                      |                          |      1 |      3 |     8   (0)|   4606 |00:00:16.30 |    4642K|   1726 |
|   3 |    UNION-ALL                                |                          |      1 |        |            |   4606 |00:00:16.29 |    4642K|   1726 |
|   4 |     NESTED LOOPS                            |                          |      1 |      1 |     5   (0)|   4591 |00:00:16.16 |    4632K|   1670 |
|   5 |      NESTED LOOPS                           |                          |      1 |      1 |     5   (0)|   4591 |00:00:16.15 |    4632K|   1670 |
|   6 |       NESTED LOOPS                          |                          |      1 |      1 |     4   (0)|   4592 |00:00:16.13 |    4632K|   1670 |
|   7 |        NESTED LOOPS                         |                          |      1 |      1 |     3   (0)|   4662 |00:00:02.47 |   21281 |   1170 |
|   8 |         NESTED LOOPS                        |                          |      1 |      1 |     2   (0)|   4596 |00:00:01.13 |   12226 |    566 |
|*  9 |          TABLE ACCESS BY INDEX ROWID BATCHED| G_ELEMFI                 |      1 |      1 |     1   (0)|   4596 |00:00:01.00 |    3146 |    528 |
|* 10 |           INDEX RANGE SCAN                  | ELEMFI_REFDOSS_GRP_ANSAF |      1 |     25 |     1   (0)|  14430 |00:00:00.20 |      68 |     24 |
|  11 |          TABLE ACCESS BY INDEX ROWID        | F_ENTREL                 |   4596 |      1 |     1   (0)|   4596 |00:00:00.13 |    9080 |     38 |
|* 12 |           INDEX UNIQUE SCAN                 | ENTREL_CL1               |   4596 |      1 |     1   (0)|   4596 |00:00:00.11 |    4484 |     38 |
|  13 |         TABLE ACCESS BY INDEX ROWID BATCHED | F_DETFAC                 |   4596 |      1 |     1   (0)|   4662 |00:00:01.33 |    9055 |    604 |
|* 14 |          INDEX RANGE SCAN                   | DF_CLIREL                |   4596 |      1 |     1   (0)|   4662 |00:00:00.06 |    7662 |     27 |
|* 15 |        TABLE ACCESS BY INDEX ROWID BATCHED  | G_ELEMFI                 |   4662 |      1 |     1   (0)|   4592 |00:00:13.65 |    4610K|    500 |
|* 16 |         INDEX RANGE SCAN                    | G_ELEMFI$REFDOSS_ACTIF   |   4662 |      1 |     1   (0)|     13M|00:00:02.59 |     645K|    124 |
|* 17 |       INDEX RANGE SCAN                      | VF_TYPE_FINANCING        |   4592 |      1 |     1   (0)|   4591 |00:00:00.02 |     171 |      0 |
|  18 |      TABLE ACCESS BY INDEX ROWID            | V_ELEMFI                 |   4591 |      1 |     1   (0)|   4591 |00:00:00.01 |      94 |      0 |
|* 19 |     TABLE ACCESS BY INDEX ROWID BATCHED     | G_ELEMFI                 |      1 |      1 |     1   (0)|      0 |00:00:00.01 |    3118 |      0 |
|* 20 |      INDEX RANGE SCAN                       | ELEMFI_REFDOSS_GRP_ANSAF |      1 |     25 |     1   (0)|  14430 |00:00:00.01 |      68 |      0 |
|  21 |     NESTED LOOPS ANTI                       |                          |      1 |      1 |     2   (0)|     15 |00:00:00.10 |    6834 |     56 |
|* 22 |      TABLE ACCESS BY INDEX ROWID BATCHED    | G_ELEMFI                 |      1 |      1 |     1   (0)|   4595 |00:00:00.01 |    3118 |      0 |
|* 23 |       INDEX RANGE SCAN                      | ELEMFI_REFDOSS_GRP_ANSAF |      1 |     25 |     1   (0)|  14430 |00:00:00.01 |      68 |      0 |
|* 24 |      INDEX RANGE SCAN                       | REFELEM_CA_IDX           |   4595 |    115K|     1   (0)|   4580 |00:00:00.08 |    3716 |     56 |
--------------------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   9 - filter(("FI_CA"."LIBELLE_20_1" IS NOT NULL AND NVL("FI_CA"."MT_OUVERT_MVT","FI_CA"."MONTANT_DOS")>0 AND "FI_CA"."DTANNUL" IS NULL AND
              "FI_CA"."DTTRAITE" IS NULL))
  10 - access("FI_CA"."REFDOSS"=:B2)
  12 - access("FI_CA"."LIBELLE_20_1"="ENT"."ER_NUM")
  14 - access("DET"."DF_CLI"="ENT"."ER_CLI" AND "DET"."DF_REL"="ENT"."ER_NUM")
  15 - filter(("FI_FR"."LIBELLE_20_2" IS NOT NULL AND "FI_FR"."LIBELLE_20_2"="DET"."DF_NUM" AND
              NVL("FI_FR"."MT_OUVERT_MVT","FI_FR"."MONTANT_DOS")>0 AND "FI_FR"."DTANNUL" IS NULL AND "FI_FR"."MONTANT_DOS">0 AND "FI_FR"."DTTRAITE" IS NULL))
  16 - access("FI_FR"."REFDOSS"="DET"."DF_DOS")
       filter((:B1 IS NULL OR "FI_FR"."REFDOSS"=:B1))
  17 - access("VFI"."TYPE"="FI_FR"."TYPE")
  19 - filter(("FI_CA"."LIBELLE_20_1" IS NULL AND NVL("FI_CA"."MT_OUVERT_MVT","FI_CA"."MONTANT_DOS")>0 AND "FI_CA"."DTANNUL" IS NULL AND
              "FI_CA"."MONTANT_DOS">0 AND "FI_CA"."DTTRAITE" IS NULL))
  20 - access("FI_CA"."REFDOSS"=:B2)
  22 - filter(("FI_CA"."LIBELLE_20_1" IS NOT NULL AND NVL("FI_CA"."MT_OUVERT_MVT","FI_CA"."MONTANT_DOS")>0 AND "FI_CA"."DTANNUL" IS NULL AND
              "FI_CA"."MONTANT_DOS">0 AND "FI_CA"."DTTRAITE" IS NULL))
  23 - access("FI_CA"."REFDOSS"=:B2)
  24 - access("REFELEM_CA"="FI_CA"."REFELEM")
       filter("REFELEM_CA" IS NOT NULL)
*/
/********************************OLD Metrics***************************************/

/********************************New SQL*******************************************/
SELECT *
  FROM (SELECT FI_CA.REFELEM REFELEMCA,
               FI_CA.MONTANT_DOS AMOUNTCA,
               FI_CA.DTJOUR_DT,
               FI_CA.DTDEBUT DTINVOICCA,
               NVL(FI_CA.MT_OUVERT_MVT, FI_CA.MONTANT_DOS) BALCA,
               FI_FR.REFELEM REFELEMFR,
               FI_FR.MONTANT_DOS AMOUNTFR,
               NVL(FI_FR.MT_OUVERT_MVT, FI_FR.MONTANT_DOS) BALFR,
               FI_FR.REFDOSS REFDOSSFR,
               NVL(VFI.MATCHING_PRIORITY, 999) MPRIORITY,
               FI_CA.LETTRAGEGRP MATCHGRPCA,
               CASE FI_CA.LETTRAGEGRP
                 WHEN :B4 THEN
                  1
                 ELSE
                  0
               END MATCHGORUP,
               CASE
                 WHEN FI_CA.DTDEBUT > :B3 THEN
                  1
                 ELSE
                  0
               END FGMATURED
          FROM G_ELEMFI FI_CA,
               F_ENTREL ENT,
               F_DETFAC DET,
               G_ELEMFI FI_FR,
               V_ELEMFI VFI
         WHERE FI_CA.REFDOSS = :B2
           AND FI_CA.LIBELLE_20_1 = ENT.ER_NUM
           AND DET.DF_REL = ENT.ER_NUM
           AND DET.DF_CLI = ENT.ER_CLI
           AND FI_FR.REFDOSS = DET.DF_DOS
           AND FI_FR.LIBELLE_20_2 = DET.DF_NUM
           AND FI_CA.DTANNUL IS NULL
           AND FI_FR.DTANNUL IS NULL
           AND FI_CA.DTTRAITE IS NULL
           AND FI_FR.DTTRAITE IS NULL
           AND FI_CA.ACTIF='O'
           AND NVL(FI_FR.MT_OUVERT_MVT, FI_FR.MONTANT_DOS) > 0
           AND NVL(FI_CA.MT_OUVERT_MVT, FI_CA.MONTANT_DOS) > 0
           AND FI_FR.MONTANT_DOS > 0
           AND VFI.TYPE = FI_FR.TYPE
           AND (:B1 IS NULL OR FI_FR.REFDOSS = :B1)
        UNION ALL
        SELECT FI_CA.REFELEM REFELEMCA,
               FI_CA.MONTANT_DOS AMOUNTCA,
               FI_CA.DTJOUR_DT,
               FI_CA.DTDEBUT DTINVOICCA,
               NVL(FI_CA.MT_OUVERT_MVT, FI_CA.MONTANT_DOS) BALCA,
               NULL REFELEMFR,
               NULL AMOUNTFR,
               NULL BALFR,
               NULL REFDOSSFR,
               NULL MPRIORITY,
               FI_CA.LETTRAGEGRP MATCHGRPCA,
               CASE FI_CA.LETTRAGEGRP
                 WHEN :B4 THEN
                  1
                 ELSE
                  0
               END MATCHGORUP,
               CASE
                 WHEN FI_CA.DTDEBUT > :B3 THEN
                  1
                 ELSE
                  0
               END FGMATURED
          FROM G_ELEMFI FI_CA
         WHERE FI_CA.REFDOSS = :B2
           AND FI_CA.DTANNUL IS NULL
           AND FI_CA.DTTRAITE IS NULL
           AND FI_CA.LIBELLE_20_1 IS NULL
           AND FI_CA.ACTIF='O'
           AND FI_CA.MONTANT_DOS > 0
           AND NVL(FI_CA.MT_OUVERT_MVT, FI_CA.MONTANT_DOS) > 0
        UNION ALL
        SELECT FI_CA.REFELEM REFELEMCA,
               FI_CA.MONTANT_DOS AMOUNTCA,
               FI_CA.DTJOUR_DT,
               FI_CA.DTDEBUT DTINVOICCA,
               NVL(FI_CA.MT_OUVERT_MVT, FI_CA.MONTANT_DOS) BALCA,
               NULL REFELEMFR,
               NULL AMOUNTFR,
               NULL BALFR,
               NULL REFDOSSFR,
               NULL MPRIORITY,
               FI_CA.LETTRAGEGRP MATCHGRPCA,
               CASE FI_CA.LETTRAGEGRP
                 WHEN :B4 THEN
                  1
                 ELSE
                  0
               END MATCHGORUP,
               CASE
                 WHEN FI_CA.DTDEBUT > :B3 THEN
                  1
                 ELSE
                  0
               END FGMATURED
          FROM G_ELEMFI FI_CA
         WHERE FI_CA.REFDOSS = :B2
           AND FI_CA.DTANNUL IS NULL
           AND FI_CA.DTTRAITE IS NULL
           AND FI_CA.LIBELLE_20_1 IS NOT NULL
           AND FI_CA.ACTIF='O'
           AND FI_CA.MONTANT_DOS > 0
           AND NVL(FI_CA.MT_OUVERT_MVT, FI_CA.MONTANT_DOS) > 0
           AND NOT EXISTS
         (SELECT 1 FROM G_ELEMFI WHERE REFELEM_CA = FI_CA.REFELEM))
 ORDER BY MATCHGORUP DESC,
          CASE :B5
            WHEN 'FIORDERMAT' THEN
             FGMATURED
          END ASC,
          CASE :B5
            WHEN 'FIORDERMAT' THEN
             CASE FGMATURED
               WHEN 1 THEN
                DTINVOICCA
             END
          END,
          MPRIORITY,
          DTINVOICCA ASC,
          REFELEMFR DESC;
select * from table(dbms_xplan.dis
/********************************New SQL*******************************************/
/********************************New Metrics***************************************/
/*
Plan hash value: 273884168
--------------------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                   | Name                     | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  |
--------------------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                            |                          |      1 |        |     9 (100)|   4606 |00:00:00.54 |   36096 |     56 |
|   1 |  SORT ORDER BY                              |                          |      1 |      3 |     9  (12)|   4606 |00:00:00.54 |   36096 |     56 |
|   2 |   VIEW                                      |                          |      1 |      3 |     8   (0)|   4606 |00:00:00.54 |   36096 |     56 |
|   3 |    UNION-ALL                                |                          |      1 |        |            |   4606 |00:00:00.54 |   36096 |     56 |
|   4 |     NESTED LOOPS                            |                          |      1 |      1 |     5   (0)|   4591 |00:00:00.05 |   26144 |      0 |
|   5 |      NESTED LOOPS                           |                          |      1 |      1 |     5   (0)|   4591 |00:00:00.05 |   26049 |      0 |
|   6 |       NESTED LOOPS                          |                          |      1 |      1 |     4   (0)|   4592 |00:00:00.04 |   25881 |      0 |
|   7 |        NESTED LOOPS                         |                          |      1 |      1 |     3   (0)|   4662 |00:00:00.03 |   20878 |      0 |
|   8 |         NESTED LOOPS                        |                          |      1 |      1 |     2   (0)|   4596 |00:00:00.02 |   12034 |      0 |
|*  9 |          TABLE ACCESS BY INDEX ROWID BATCHED| G_ELEMFI                 |      1 |      1 |     1   (0)|   4596 |00:00:00.01 |    3118 |      0 |
|* 10 |           INDEX RANGE SCAN                  | ELEMFI_REFDOSS_GRP_ANSAF |      1 |     25 |     1   (0)|  14430 |00:00:00.01 |      68 |      0 |
|  11 |          TABLE ACCESS BY INDEX ROWID        | F_ENTREL                 |   4596 |      1 |     1   (0)|   4596 |00:00:00.01 |    8916 |      0 |
|* 12 |           INDEX UNIQUE SCAN                 | ENTREL_CL1               |   4596 |      1 |     1   (0)|   4596 |00:00:00.01 |    4320 |      0 |
|  13 |         TABLE ACCESS BY INDEX ROWID BATCHED | F_DETFAC                 |   4596 |      1 |     1   (0)|   4662 |00:00:00.01 |    8844 |      0 |
|* 14 |          INDEX RANGE SCAN                   | DF_CLIREL                |   4596 |      1 |     1   (0)|   4662 |00:00:00.01 |    7533 |      0 |
|* 15 |        TABLE ACCESS BY INDEX ROWID BATCHED  | G_ELEMFI                 |   4662 |      1 |     1   (0)|   4592 |00:00:00.01 |    5003 |      0 |
|* 16 |         INDEX RANGE SCAN                    | TEST_DD_INDEX            |   4662 |      1 |     1   (0)|   4647 |00:00:00.01 |    3871 |      0 |
|* 17 |       INDEX RANGE SCAN                      | VF_TYPE_FINANCING        |   4592 |      1 |     1   (0)|   4591 |00:00:00.01 |     168 |      0 |
|  18 |      TABLE ACCESS BY INDEX ROWID            | V_ELEMFI                 |   4591 |      1 |     1   (0)|   4591 |00:00:00.01 |      95 |      0 |
|* 19 |     TABLE ACCESS BY INDEX ROWID BATCHED     | G_ELEMFI                 |      1 |      1 |     1   (0)|      0 |00:00:00.01 |    3118 |      0 |
|* 20 |      INDEX RANGE SCAN                       | ELEMFI_REFDOSS_GRP_ANSAF |      1 |     25 |     1   (0)|  14430 |00:00:00.01 |      68 |      0 |
|  21 |     NESTED LOOPS ANTI                       |                          |      1 |      1 |     2   (0)|     15 |00:00:00.47 |    6834 |     56 |
|* 22 |      TABLE ACCESS BY INDEX ROWID BATCHED    | G_ELEMFI                 |      1 |      1 |     1   (0)|   4595 |00:00:00.02 |    3118 |      0 |
|* 23 |       INDEX RANGE SCAN                      | ELEMFI_REFDOSS_GRP_ANSAF |      1 |     25 |     1   (0)|  14430 |00:00:00.01 |      68 |      0 |
|* 24 |      INDEX RANGE SCAN                       | REFELEM_CA_IDX           |   4595 |    115K|     1   (0)|   4580 |00:00:00.46 |    3716 |     56 |
--------------------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   9 - filter(("FI_CA"."LIBELLE_20_1" IS NOT NULL AND NVL("FI_CA"."MT_OUVERT_MVT","FI_CA"."MONTANT_DOS")>0 AND "FI_CA"."DTANNUL" IS NULL AND
              "FI_CA"."DTTRAITE" IS NULL))
  10 - access("FI_CA"."REFDOSS"=:B2)
  12 - access("FI_CA"."LIBELLE_20_1"="ENT"."ER_NUM")
  14 - access("DET"."DF_CLI"="ENT"."ER_CLI" AND "DET"."DF_REL"="ENT"."ER_NUM")
  15 - filter(("FI_FR"."REFDOSS"="DET"."DF_DOS" AND (:B1 IS NULL OR "FI_FR"."REFDOSS"=:B1) AND
              NVL("FI_FR"."MT_OUVERT_MVT","FI_FR"."MONTANT_DOS")>0 AND "FI_FR"."DTANNUL" IS NULL AND "FI_FR"."MONTANT_DOS">0 AND "FI_FR"."DTTRAITE" IS NULL))
  16 - access("FI_FR"."LIBELLE_20_2"="DET"."DF_NUM")
       filter("FI_FR"."LIBELLE_20_2" IS NOT NULL)
  17 - access("VFI"."TYPE"="FI_FR"."TYPE")
  19 - filter(("FI_CA"."LIBELLE_20_1" IS NULL AND NVL("FI_CA"."MT_OUVERT_MVT","FI_CA"."MONTANT_DOS")>0 AND "FI_CA"."DTANNUL" IS NULL AND
              "FI_CA"."MONTANT_DOS">0 AND "FI_CA"."DTTRAITE" IS NULL))
  20 - access("FI_CA"."REFDOSS"=:B2)
  22 - filter(("FI_CA"."LIBELLE_20_1" IS NOT NULL AND NVL("FI_CA"."MT_OUVERT_MVT","FI_CA"."MONTANT_DOS")>0 AND "FI_CA"."DTANNUL" IS NULL AND
              "FI_CA"."MONTANT_DOS">0 AND "FI_CA"."DTTRAITE" IS NULL))
  23 - access("FI_CA"."REFDOSS"=:B2)
  24 - access("REFELEM_CA"="FI_CA"."REFELEM")
       filter("REFELEM_CA" IS NOT NULL)       	
*/
/********************************New Metrics***************************************/

/********************************Index statistics**********************************/

/********************************Other SQLs****************************************/          
/*

*/ 
/********************************Other SQLs****************************************/              
