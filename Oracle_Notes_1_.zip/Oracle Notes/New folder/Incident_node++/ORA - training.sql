
### df_mon.cfg

/var/opt/OV/conf/OpC/df_mon.cfg   ------> monitoring na failovata sistema

/var/opt/OV/dbspi/db_mon.cfg  ----------> monitoring na incident errors 


## LISTENER
#cd $ORACLE_HOME/network/admin/ 
#tnsadmin - service name
#listener.ora - listeners
#sqlnet.ora - 


Single instance - Single database
it is single, because the machine CAN'T handle 2 or more instances, because of the limited resourses of the machine.
ex A: disk space, cpu power, memory, processes
ex B: two databases on ONE node, and two instances. INSTANCE 1 accesses DATABASE 1, INSTANCE 2, accesses DATABASE 2.

DATABASE INSTANCE has:
SGA system global area (Shared pool, Large pool, Redo log buffer, Database buffer cache, Fixed SGA, Java Pool, Stream Pool), SHARED MEMORY.
PGA program globar area (NON-SHAREABLE)

SHARED POOL - DATA DICTIONARY

Notes: If 1 Instance fails, the instance can be set that the traffic fails over (goes thru) to the other instances.
If we hit the maximum of out resources, we can easly add another instance to distribute the load across.
The process can be done with one BIG machine or with several smaller machines.

# INSTANCE IS LOGICAL MEMORY STRUCTURE AND PROCESSES.

SERVER PROCESS IS PROCESS THAT WORKS FOR YOU!

BLOCK - THE SMALLEST UNIT SIZE OF I/O, THAT ORACLE WILL DO. (SIZES: 2K, 4K, 8K, 16K, 32K)
When we read data, we always read it in BLOCKS.

REDO LOG - It holds changes. What is changed in the database. Holds ONLY what we did to data. Protects from dataloss.
It saves: commit, insert, update, delete, commit, rollback.

BACKGROUND PROCESSES:
REQUIRED: DBWn, CKPT, LGWR, SMON, LREG, PMON, RECO, others
OPTIONAL: ARCn, others

BACKGROUOND PROCESS: ASH BUFFER - active session history. It records what happens to all the transactions second by second.
DATABASE WRITER DBWn - writes data from the buffer cache down to the disk. It can has up to 100 DBWn.
LOG WRITER (LGWR) - The log writer is writing the data in memory down to disk.
SMON - It handles the recoveries, when you bring up the instance.
PMON - handles process crashes.
RECO - Recovery process. If you decide to ROLL BACK a transaction in a multi-database environment.
LREG - Listener registration
ARCHIVER - makes permanent copy. & you need to go in ARCHIVELOG mode.

each database has a memory structure.
METADATA: In each database has a couple of gigs repeating metadata.

PDBs - plugable databases
CDB - ROOT container
BLOCK - Smallest unit in Oracle. When we have a group of continious blocks (ONE AFTER ANOTHER), they are physically connected.

What's an OBJECT? -It is a SEGMENT.
What's an SEGMENT? -It is a generic name for an object in ORACLE. A TABLE, INDEX, MATERIALIZED VIEW, PARTITION are segments.
SEGMENTS require a storage.

What is EXTENT? -It is contiguous blocks of storage.
The SEGMENTS are stored in TABLE SPACE. TABLE SPACE can contain lots of SEGMENTS.
TABLE SPACESES are made up of physical data files. IN ONE TABLESPACE CAN EXIST UP TO 1.022 IN A SMALL FILE TABLESPACE.

NFS - NETWORK FILE SYSTEM
SAN - 
NAS - 

ROW file system - NOT SUPPORTED ANYMORE!
DATABASE IS COLLECTION OF TABLESPACES. 
SYSAUX TABLESPACE - THE SYSAUX IS ADDITIONAL FUNCTIONALITY LIKE PERFORMANCE METRICS, AUDIT LOGS.
TEMPRORARY TABLEESPACE - IT IS A PLACE, WHERE WE HOLD DATA TEMRORARILY THAT EVERRUNS MEMORY.
UNDO - WHAT IS UNDO? - IT GIVES US THE ABILITY TO CHANGE OUR MIND. ALLOWS US TO REVERT TO PREVIOUS STATES OF THE DATA BEFORE WE COMMIT A TRANSACTION. AND EVEN IF WE COMMIT A TRANSACTION IT STILL ALLOWS US TO UNDO THIS.
USERS TABLESPACE - USUALLY THERE ARE THE POWER USERS, WHO ARE NOT PART OF OUR APPLICATION, SUCH AS DBAs.

BACKUP AND RECOVERY - IT HAS A WHOLE HOST OF BLOCKS THAT TELL US WHEN DID WE BACKUP OUR DATABASE.
- at least 2 CONTROL FILES, If we loos one, the database will be down, but we will use the second CONTROL FILE, to recreate the first one.

- Online redo log files - files in which are holding places. They are usually done in groups. 

- Initialization parameter file (pfile) or server parameter file (spfile) - When we create the INSTRANCE, automaticaly 30 parameters are set. 380 parameters that can be optionally set.
pfile (parameter file) - it is a text file, that is user maintained with a text editor.
spfile (system parameter file) - it is a file that oracle maintence, can make updates.
ORACLE HOME folder is named "dbs"
PASSWORD FILE - stores encrypted passwords

BACKUP FILES - Copies of the database.

ARCHIVED REDO LOG FILES - They are copy of the online DB, when it fills up, it is writed out to a disk location in FRA(Fast Recovery Area)

ALERT LOG FILE - File that tells you about what happened in ORACLE. (STARTUP, SHUTDOWN, PRECESSES, ERRORS, STRUCTURAL CHANGES BETWEEN LOG FILES)

TRACE FILE - LONG ERRORS ARE WRITEN IN THE TRACE FILE.

LISTNER - IT HAS A PORT (for example: 1521) [user process -> listner -> server process]

POINT TIME ROCOVERY - It makes recovery from date and time that we want. 

HOW TO CONNECT TO ORACLE DATABASES
1. whit client applications, you can connect with CDB and PDBs.
2. user session, by using operating system authentication - $ sqlplus / as sysdba
3. by using Easy Conect Syntax - SQL> CONNECT hr/hr@host1.example.com:1521/db.example.com
TNS - #1: IP adresss of where the listner is operating, #2: the port at which the listner is talking on, #3: what database service do you want to connect to.

each session/user can reat it's own data, and it's own data that we've done.

TOOLS:
SQL*Plus - REPORT WRITER, we can login, we can insert, update, delete, create, drop. If we have permissions we can start and stop the database, and alter its parameters.
- to see what user is connected in SQL*Plus, type "show user"

SQL Command Line (SQLcl)

SQL Developer - graphical tool
Database Configuration Assistant (DBCA) - allows you to create databases, It works with no commands (witch clicks)
Oracle Enterprise Manager Database Express - scaled-back version of managing your database.
Enterprise Manager Cloud Control - managing CDB and PDB

ORACLE COMMANDS in terminal for SQL DBAs or DEVELOPERS
which oraenv - shows us which ORACLE ENVIRONMENT we are using.

# . oraenv

#set home directory
ORACLE_SID = [oracle] ? ORCL	### ORCL is SID

#shows what is set Oracle base was set, Oracle home and Oracle SID is set
set|grep ORACLE

#LOG IN SQL*PLUS - connected up to the root container
sqlplus / as sysdba

# confrim that our user is SYS with this command.
show user

# Information about current container that we're connected to.
show con_name
# Container Identification digit (ID)
show con_id

# From this we can see that the name of the DB is ORACLE, it is the container, and it is the root container.
select name, cdb, con_id from v$database;

# what version we are running?
select banner from v$version;

# List all the containers in the CDB
col name format a8
select name, con_id from v$containers order by con_id;

# list all PDBs with show command
show pdbs

# We can see taht both PDBs are open with a normal status.
select pdb_name, status from cdb_pdbs order by 1;

# Files between PDBs - all the filenames are assosiated with tablespaces
col file_name format a50
col tablespace_name format a10
select file_name, tablespace_name from cdb_data_files;

# We see all the files, tablespace numbers, container id's
col name format a12
SQL> select d.file#, ts.name, ts.ts#, ts.con_id
  2  from v$datafile d, v$tablespace ts
  3  where d.ts#=ts.ts# and
  4        d.con_id = ts.con_id
  5  order by 4;

# shows us all the temp files.
select file_name, tablespace_name from cdb_temp_files;

# show redo log files
col number format a42
select group#, member, con_id from v$logfile;

# List control files
col name format a55
select name, con_id from v$controlfile;

# we see all the created users in our db
set pages 140
select distinct username
  2  from cdb_users
  3  where common='YES'           
  4  order by 1;

# all usernames
col username format a25
select con_id, username from cdb_users;

# shows instance name, status
select instance_name, status, con_id from v$instance;

#XML schema
select con_id, name from v$services order by 1;

# We see both PDBs
col con_id format 999
col name format a10
select con_id, name, open_mode from v$pdbs;

# If ODB1 was closed, we woud say:
alter pluggable database pdb1 open;

# connect and alter our session to use the PDB1
alter session set container=PDB1;

# this command shows the con
show con_name;

# QUERY OUR DATA FILES
select file_name, tablespace_name from dba_data_files;

# Now we can see our file names and the tablespaces
set linesize 132
col file_name format a50
/

# We see filenames from temprorary files
select file_name from dba_temp_files;

# We are selecting distinct username from dba_users where common equals NO
select distinct username from dba_users
  2  where common='NO';

# This command is for disconnecting from our database
disconnect

# connects to this DB
connect system/oracle_4U@localhost:1521/PDB1.example.com

# this command show us the PORT(listener)
select dbms_xdb_config.gethttpsport() from dual;

# To make sure that the global port is enabled
exec dbms_xdb_config.SetGlobalPortEnabled(True);

# Gives new permissions
chmod 755 sql

# Shows version of the java
java -version

# connects sql with usr/pass/port
sql system/oracle_4U@localhost:1521/PDB1.example.com

# ask for username and password to login
 ./sql

# connect and alter our session to use the PDB1
alter session set container=PDB1;

# This command helps you with another commands
help

# It generated the Create Table statement, using index, showing all our parameters and all our comments, including column comments and table comments.
ddl hr.locations

#
help set ddl

# creating simple query:
select first_name, last_name, salary, hire_date from hr.employees;

# what format is sql?
show sqlformat

### ORACLE CLOUD ###
### Features and Tooling ###
patches and tools whitch of them can be configure with a simple click
connection to the cloud is encrypted.
the data in the cloud is automatically encrypted with TDE - Transperent Data Encryption.

RAC - rac technology allows you to have basically concurrently used multiple database instances on different compute nodes.

### OPENING AND CLOSING PDBs ###
shut down IMMEDIATE - does not allow new connections, does not wait for them to end, stop transactions!
after we are back we made a checkpoint

# 
select * from v$diag_info;

# adrci allows to find the alert log and other components.
adrci - automatic diagnostic repository - command line interface
adrci - automatinc diagnostic repository command line interface

# showing alert messeges
show alerts

# setting another vim editor (GEDIT)
set editor gedit

# USING TRACE FILES
oracle can make scheduale when to delete trace files 1 mounth, 1 year, or even to limit the size of trace files.

# ADMINISTERING THE DDL LOG FILE
it is non basic parameter
it is not turned on by default
it is an initialization parameter
to turn it on you have to say "enable ddl logging='true'"
DDL is in .xml or .log format
it is showing what last has been altered
shows when the user was dropped, table was dropped, when a column was dropped

# QUERYING DINAMIC PERFORMANCE VIEWS
DPV contain info about the changing states of the instance memory structure:
sessions, file state, locks
process of jobs and locks
backup status memory usage and allocation
system and session parameters
sql execution
statistics and metrics

- dynamic performance views start with the prefix V$
example: SELECT * FROM V$SESSION
WHERE machine = 'EDXX9P1'
AND logon_time > SYSDATE - 1;

# CREATING PFILE AND SPFILE
show parameter spfile

spfile is in /u01/app/oracle/product/12.2.0/dbhome_1/dbs

creating new pfile
create pfile='initORCL.ora' from spfile;

# SHUTTING DOWN THE DATABASE (turns off for about 30 secs)
shutdown

# STARTING UP THE DATABASE
startup

# show parameter spfile
show parameter spfile

# shwos parameter database name
show parameter db_name

# shows parameter database domain
show parameter db_domain

# shows parameter recovery file
show parameter recovery_file

# shows parameter db_recovery_file_dest
show parameter db_recovery_file_dest

#
show parameter sga

show parameter undo_tablespace

show parameter compatible;

# CONTROL FILES PARAMETER
show parameter control_files

# PROCESSES parameter
show parameter processes

# PARAMETER SESSIONS
show parameter_sessions

# TRANSACTIONS PARAMETER
show parameter transactions

# database files parameter
show parameter db_files;

show parameter commit_logging
show parameter commit_wait
show parameter shared_pool_size
show parameter db_block_size
show parameter db_cache_size
show parameter undo_management
show parameter memory_target
show parameter memory_max_target
show parameter pga_aggregate_target

SQL> set pages 100
SQL> select table_name
  2  from dict
  3  where table_name like '%PARAMETER%' 
  4  ;

# DESCRIBEs V$ PARAMETER (ALL PARAMETERS)
desc v$parameter

select name, issys_modifiable, value from v$parameter;

# shows only parameters with pool in the name.
select name, value from v$parameter where name like '%pool%'

desc v$spparameter
select name, value from v$spparameter;

desc v$parameter2 - describes parameter2
select name, value from v$parameter2;

desc v$system_parameter
select name, value from v$system_parameter;

### Modifying Initialization Parameters ###
select name, value from v$parameter where name = 'nls_territory';
alter session set container=PDB1;

  1  select name, isses_modifiable, isses_sysmodifiable, ispdb_modifiable, value
  2  from v$parameter
  3* where name = 'nls_date_format'

alter pluggable database pdb1 open;
select last_name, hire_date from hr.employees;
show parameter nls_date_format
select name, isses_modifiable, issys_modifiable, value from v$parameter
where name = 'job_queue_processes';

alter system set sec_max_failed_login_attempt=2 comment='Reduced for tighter security' scope=spfile;

select name, isses_modifieable, issys_modifiable, value from v$parameter
where name = 'sec_max_failed_login_attempts'

# start the DB with nomount
startup nomount

# MOUNTING THE DB
alter database mount;

# OPEN the DB
alter database open;

# ALL THE DATA FILES FOR THE ROOT CONTAINER
 select file_name, tablespace_name from cdb_data_files;

# OPENS PDB1
alter pluggable database pdb1 open;

# NOW WE SEE ALL PDB DATA FILES
select file_name, tablespace_name from cdb_data_files;

# CREATES FILE this command creates file named q.sql
save q

# gets the query we save (q.sql)
get q

### DIAGNOSTIC INFORMATION ###

select name, value from v$diag_info
col value format a50
col name format a25
/

# HERE WE CAN READ LOGS, TRACEs, instance starts up, shutdown
info in "alert_ORCL.log"

Diag Enabled		  TRUE
ADR Base		  /u01/app/oracle
ADR Home		  /u01/app/oracle/diag/rdbms/orcl/ORCL
Diag Trace		  /u01/app/oracle/diag/rdbms/orcl/ORCL/trace
Diag Alert		  /u01/app/oracle/diag/rdbms/orcl/ORCL/alert
Diag Incident		  /u01/app/oracle/diag/rdbms/orcl/ORCL/incident
Diag Cdump		  /u01/app/oracle/diag/rdbms/orcl/ORCL/cdump
Health Monitor		  /u01/app/oracle/diag/rdbms/orcl/ORCL/hm
Default Trace File	  /u01/app/oracle/diag/rdbms/orcl/ORCL/trace/ORCL_ora_24056.trc
			  
#adrci - command-line tool that you use to manage Oracle Database diagnostic data.
ADR base = "/u01/app/oracle" 
show alert

#this commnad deletes table called test 
drop table test

alter session set nls_date_format ='mon dd yyyy';
select last_name, hire_date from hr.emploees;
show parameter nls_date_format
example 2: usr/pass@HRPDB @script.sql

save q1
get q1

### Creating DBCS Database Deployments ###
...

Creating PDBs (pluggable databases)
Creating a PDB from Seed

# LISTENER CONTROL
lsnrctl start

select file_name, tablespace_name from dba_temp_files;
select distinct username from dba_users where common='no';

### HOT CLONING A PDB ###
alter session set container =PDB1;
alter user HR account unlock identified by oracle_4U;

select salary from hr.employees where employee_id =100;
update hr.employees set salary=salary*1.1;

# creates pluggable database
SQL> create pluggable database PDB3 from PDB1
  2  create_file_dest='/u01/app/oracle/oradata/ORCL/PDB3';

select con_id, name, open_mode from v$pdbs;
update employees set salary=salary/1.1;

## Unplugging and Plugging a PDB
alter database PDB3 close immediate;
alter pluggable database PDB3 unplug into '/u01/app/oracle/oradata/PDB3.xml';
drop pluggable database PDB3 keep datafiles;
select pdb_name, status from cdb_pdbs where pdb_name in ('PDB3');
save q
save q replace
set serverout on

set serverout on
DECLARE
 2 compatible BOOLEAN := FALSE;
 3 BEGIN
 4 compatible := DBMS_PDB.CHECK_PLUG_COMPATIBILITY('pdb_descr_file=>/u01/app/oracle/oradata/PDB3.xml');
 5 if compatible then
 6 dbms_output.put_line('PDB3 is compatible');
 7 else
 8 dbms_output.put_line('PDB3 is NOT compatible');
 9 end if;
 10 END;

create pluggable database HRPDB using '/u01/app/oracle/oradata/PDB3.xml' NOCOPY TEMPFILE REUSE;
col name format a8
select name, con_id from v$containers order by con_id;
select pdb_name, status from cdb_pdbs where pdb_name='HRPDB';
select open_mode from v$pdbs where name ='RDPDB';
col name format a50
select name from v$datafile where con_id=5;
exit
sqlplus / as sysdba
alter pluggable database hrpdb open;
connect sys/oracle_4U@localhost:1521/HRPDB.example.com as SYSDBA
show con_name
exit

## Dropping a PDB
. oraenv
ORCL
sqlplus / as sysdba
show pdbs
alter pluggable database hrpdb close;
show pdbs
drop pluggable database hrpdb including datafiles;
show pdbs
exit

## Managing DBCS Database Deployments
## Viewing Database Deployment Information and Menus
## Connecting to the Database Deployment Compute Node
PuTTy - connects with Public IP address/HOST Name
to use auto-login it must have a USERname
public/private key pair - PASSWORD

### ORACLE NETWORK EVIRONMENT ###
## Oracle Net Services - Shows listner, address, protocol, port, key
 . oraenv
ORCL
cd $ORACLE_HOME/network/admin
ls
cat listner.ora

cat tnsnames.ora - there we can see our tns names, entry for the listner, entry for PDB1,PDB2 and ORCL.

listner.ora creaters a SID_LIST_<listner_name>

ORACLE Net Manager
it is manager, in which must insert service name, SID, connection type, protocol, host name, port number.
the info will get from "cd $ORACLE_HOME/network/admin"

### Advanced Connection Options ###

# creates database links (also called pipe or tunnel)
CREATE DATABASE LINK <database_link_name>;

# command to connect to another database
CONNECT TO <user> IDENTIFIED BY <password> USING '<connect_string_for_remote_db>';

# Example SQL command to query a table on the other database
SELECT * FROM employees@<database_link_name>;

SST - Shared Server Technology
balancing system is keeping the server processes busier.

### Exploring the Default Listener ###
show parameter instance_name
show parameter service_names
show parameter local_listener
show parameter remote_listener
exit

cd $ORACLE_HOME/network/admin
ls
cat tnsnames.ora
cat listener.ora
lsnrctl
help
show current_listener
status
services
show log_status
show log_file
exit

### Creating a Dynamic Listener ###

editing tnsnames.ora in 
computer / > filesystem > u01 / app / oracle / product / 12.2.0 / dbhome_1 / network / admin

EDIT "tnsnames.ora" to "tnsnames.ora.txt"
open it with text editor

remove TIMECARD ADRESS
copy LISTENER_ORCL and rename it to "LISTENER_2" and change the port "1561"
save the file and rename it again to the old name "tnsnames.ora.txt" to "tnsnames.ora"

set the envoronment and LOGIN as sysdba
show parameter local_listener
select isses_modifiable, issys_modifiable from v$parameter where name='local_listener'
/
save q repl
alter system set local_listener="LISTENER_ORCL,LISTENER_2" SCOPE=BOTH;
show parameter local_listener

- WE go back in the folder and rename "listener.ora" to "listener.ora.txt" and edit it.

we add 
LISTENER_2 description coppied
and
ADR_BASE-LISTENER_2 = /u01/app/oracle
save and close and rename it to the old name

netmgr

#creating database link
crerate database link mylink to SYSTEM identified by oracle_4U using 'em13rep'

# desc - means describe - for ex.: desc dba_bd_links

### Backing Up and Restoring DBCS Database Deployments ###
RMAN - Recovery manager (backup configuration settings)
For Single INSTANCE database use the "bkup_api"
For RAC databases, use the "raccli" utility.

RECOVERY
orec, subcommand of the dbaascli utility to restore and recover the database
#restoring from the most recent backup and performing complete recovery
dbaascli orec -- args -latest
#restoring from a specific backup and performing pont-in-time recovery
dbaascli orec -pitr backup-tag
#restoring from a specific long-term backup and performing time-in-time recovery
dbaascli oreg --args -keep -tag backup-tag

# to see hostname
hostname --1

# to see our database configuration
cd /home/oracle/bkup/ORCL/
ls

# this is db configuration file
dbcfg.spec
cat dbcfg.spec

# from here we can see all the OS directories that get backed up
cat oscfb.spec

### Creating an On-Demand Backup ###
rman target "/ as sysbackup'"
set|grep ORA
rman target /
list backup;
exit

### Recovering the Database ###

### LOGIN AS A SYSTEM USER ###
sqlplus system
password: 

# DROP/DELETE TABLE
drop table mytable;

### Administering User Security ####
# USER ACCOUNTS
Anybody who connects up to the DB should have an account in the DB. The user accounts are a unique name.
The users have an authentication method, to ensure who that user is.

The users have "unique username, authentication method, default tablespace, temprorary tablespace, user profile, initial consumer group, account status"
The objects that are in the user account are owned by the user, and they are called SCHEMA OBJECTS

The place for the user's stuff is called "DEFAULT TABLESPACE" and there they create objects if they have privileges.
The users also need a place for their temprorary stuff.
USERS NEED A PROFILE, TO CONTROL THEIR RESOURSES

account that user can use is called OPEN
If we don't want the user to login we can lock the account.
The users can change their password, if is grace or expired

When we create users, we can create them in root containers. They are called common users.

ORACLE have standard user accounts
SYS - super user, owns the data dictionary and the automatic workload repository (awr). used for starting up and shutting down the database instance.
SYSTEM - owns additional administrative tables and views
SYSBACKUP - facilitates oracle recovery manager (rman) backup and recovery operations
SYSDG - facilitates oracle data guard operations
SYSKM - facilitates transparent data encryption wallet operations
SYSRAC - for real application clusters (RAC) database administration tasks
SYSMAN - for oracle enterprise manager database administration tasks
DBSNMP - used by the management agent component of oracle enterprise to monitor and manage the DB

SYSTEM PRIVILAGES
each system privilage allows a user to perform a particular database operation or class of database operations.
special system privilages for administrators:
SYSDBA
SYSOPER
SYSASM
SYSBACKUP
SYSDG
SYSKM
SYSRAC

GRANTING - GRANT <common role> TO <common user or role> CONTAINER=ALL;

CONNECT SYS@PDB1 AS SYSDBA
GRANT <common or local role> TO <common or local user>;

RESOURCE - CREATE CLUSTER, CREATE INDEXTYPE, CREATE OPERATOR, CREATE PROCEDURE, CREATE SEQUENCE, CREATE TABLE, CREATE TRIGGER, CREATE TYPE
SCHEDULER_ADMIN - CREATE ANY JOB, CREATE EXTERNAL JOB, CREATE JOB, EXECUTE ANY CLASS, EXECUTE ANY PROGRAM, MANAGE SCHDULER
SELECT_CATALOG_ROLE - SELECT privilages on data dictionary objects

# revoving privilages and roles
you can use the ROVEKE statement to:
- Revoke system privilages from users and roles
- revoke roles from users, roles, and program units
- revoke object privilages for a particular object from users and roles

# Assigning Profiles
commonly: connect / as sysdba
alter user <common user> PROFILE <common profile> CONTAINER=ALL;

locally: connect sys@pdb1 as sysdba
alter user <common or local user> PROFILE <common or local profile>;

# password parameters
account locking -
password aging and expiration
password history
password complexity verification

#Resource Parameters
pic saved on desktop

#oracle-supplied password verification functions
pic saved on desktop

#authenticating users
pic saved on desktop

#password authentication
pic saved on desktop

#password file authentication
pic saved on desktop

#OS authentication
pic saved on desktop

#assigning quotas to users
saved on desktop

#applying the principal of least privilage
saved on desktop

##  Creating Common and Local User

create user:
create user c##CDB_ADMIN1 identified by oracle_4U container=all
2 default tablespace users temporary tablespace temp account unlock;

gives permissions
grant create session, dba, sysdba to c##CDB_ADMIN1 container=all
/

select distinct username from dba_users where common='YES';

disconnect
show user
connect c##cdb_admin1/oracle_4U as sysdba
show con_name
show user > must be SYS
select * from session_privs;
dissconnect
connect c##cdb_admin1/oracle_4U
show user
select * from session_privs;
alter session set container=PDB1
2 ;

show con_name
create user PDB1_ADMIN1 identified by oracle_4U
2  default tablespace users temporary tablespace temp account unlock;

grant create session, dba to pdb1_admin;
select disinct username from dba_users where common='NO';
disconnect

connect PDB1_ADMIN1/oracle_4U@PDB1
show user
select * from session_privs;

alter session set container=CDB$ROOT; - user don't have permissions in the root container!

##  Creating a Local User for an Application
set ora env
sqlplus PDB1_ADMIN1/oracle_4U@PDB1
create user INVENTORY identified by oracle_4U
2 default tablespace users
3 quota unlimited on users;

grand create session to INVENTORY;

select distinct username from dba_users where common='NO';

disconnect
connect inventory/oracle_4u@PDB1
select * from session_privs;
exit

## Granting the DBA Role to PDBADMIN
oraenv
sqlplus/as sysdba

select * from dba_sys_privs where grantee='PDBADMIN';

select granted_role, admin_option from cdb_role_privs where grantee='PDADMIN';
alter session set container=PDB1;

select privilege from role_sys_privs where role='PDB_DBA';
select granted_role from dba_roloe_privs where grantee = 'PDB_DBA';

select privilege from role_sys_privs where role='connect';
grant dba to PDBADMIN;
select granted_role from dba_role_privs where grantee='PDBADMIN';
exit

## Creating a Local Profile in EM Express and Locking Accounts\
oraenv
orcl
sqlplus PDBADMIN/oracle_4U@PDB1

alter profie hrprofile limit INACTIVE_ACCOUNT_TIME 10;
col limit format a20
select resource_rype, resource_name, limit from dba_profiles where profile='HRPROFILE';
 ! oerr ora 2377
alter profile hrprofile limit inactive_account_time 15;
select resource_rype, resource_name, limit from dba_profiles where profile='HRPROFILE';
exit

## Creating Local Roles in EM Express
delete from hr.employees where employee_id=197;
select salary from hr.employees where employee_id=197;
delete from hr.employees where employee_id=197;

## Configuring a Default Role for a User
alter user azsumborko default role hrclerk;
select granted_role, default_role from dba_role_privs where grantee = 'AZSUMBORKO';
disconnect
connect azsymborko/oracle_4U@PDB1
select * from session_roles;
set role AZSUMBORKO
select * from session_roles;
set role HRMANAGER, HRCLERK;
select * from v$option where parameter = 'unified auditing';
create audit policy drop_pol privileges drop any table;
audit policy drop_pol by users with granted roles dba;

select entity_name, entity_type, enabled_option
2 from audit_nified_enabled_policies
3 where policy_name='DROP_POL';

connect pdbadmin/oracle_4U@PDB1
create table hr.test (c number) p;
drop table hr.test;
connect system/oracle_4U@PD1
select dbusername, action_name, object_name
2 from unified audit_trial
3 where dbusername = 'PDBADMIN' and
4 	action_name = 'DROP TABLE';
/

create user john identified by oracle_4U;
grant create session, dba to john;
create table list (user_name varchar2(20));
connect joh/oracle_4U@PDB1
drop table system.list;
connect system/oracle_4U@PDB1
drop 

select dbusername, action_name, object_name
2 from unified audit_trial
3 where dbusername='JOHN'
/

drop audit policy drop_pol;
noaudit policy drop_pol;
drop audit policy drop_pol

noaudit policy drop_pol by users with granted roles dba;

## Exploring OS and Password File Authentication
cat /etc/group
man group
whoami
grep oracle /etc/passwd - we see home dir/ primary id/
grep  54321 /etc/group
grep oracle /etc/group
. oraenv
ORCL
sqlplus / as sysdba
desc v$pwfile_users
select username from v$pwfile_users;
select account_status, sysdba from v$pwfile_users where username='SYS'; - account info

## Patching DBCS Database Deployments
patching tools:
dbpatchm - subcommand of the dbaascli utility for single-instance databaases

#using the dbaascli utility to manage patches
- checking prerequisites: 
# dbaascli dbpatchm --run -prereq
-applying a patch - dbaascli dbpatchm -run -apply
# rolling back a patch - dbaascli dbpatchm --run -rollback

##  Viewing Available Patches
dbaascli --run -list
dbpatchm --run -list -cli
dbaascli d bpatchm --run -list

---- - login as root
id
whoami
sudo -s
whoami
----

run the command:
dbaascli dbpatchm --run -list_patches

### Creating and Managing Tablespaces



raccli - utility for oracle rac databases
dbpatchmdg - utility for oracle data guard configurations


























## Auditing User Activity
. oraenv
ORCL
$HOME/labs/enable_unified_auditingv2.sh

### Database Block Content ###
every block has a BLOCK HEADER, FREE SPACE, ROW DATA

# Creating Tablespace
pic on desktop

# viewing tablespace information
pic on desktop

#Implementing oracle managed files
pic on desktop

#moving or renaming online data files
pic on desktop

#example of moving and renaming online data files
pic on desktop

###  Viewing Tablespace Information ###
. oraenv
ORCL
sqlplus PDBADMIN.oracle_4U@PDB1
desc dba_tablespaces;

select distinct tablespace_name from dba_tablespaces

-now we are going to find out which one contains all the HR schema by querying all tables.
select distinct tablespace_name from all tables where owner='HR';
select status, contents, logging, pluged_in, bigfile, extent_management, allocation_type
2 from dba_tablespaces where tablespace_name='SYSAUX';
set linesize 132

-we see statuses online, it's permanent, logging is turned on, it is not plugged in, it is not a big file, it is using system managed extents.

desc v$tablespace
select * from v$tablespace where name='SYSAUX'; - we see that it is tablespace number one, we see that it's included in the backup, it is not a big file
flashback is on, it is not encrypted in the  backup, and its container ID is 3.

select * from v$tablespace where name='SYSAUX';

we are going to list all the tables in the SYSAUX tablespace
select table_name from all_tables where tablespace_name='SYSAUX' and owner='HR';
select index_name from indexes where tablespace_name='SYSAUX' and owner='HR';

from this, we see the name of the file, it is auto extensible, we see the current size, we see that it is maxsize is unlimited we can see the size of the user data in bytes, that's in that file.
desc dba_data_files - DESCRIBE DBA DATA FILES
col file_name format a50
select file_name, AUTOEXTENSIBLE, byte, maxbytes, user_bytes
2 from dba_data_files
3 where tablespace_name='SYSAUX'
/

# ONE OF THE OPS STATS INDICES
select count(segment_name) from dba_segments where tablespace_name='SYSAUX';
select * from
2 (select segment_name, segment_type, bytes from dba_segments
3 where segment_type='INDEX' and tablespace_name='SYSAUX'
4 order by bytes desc
5 )
6 where rownum < 2;

### Creating a Tablespace ###

# running a script / importing a .sql file in DB
@/home/oracle/createinventorytablespace.sql

# deleting tablespace / DROP TABLESPACE
drop_tablespace inventory including contents and datafiles;

### CREATING MASTER ENCRYPTION KEYS FOR PDBs ###
SET THE CONTAINER TO THE PDB

ALTER SESSION SET CONTAINER = PDB;

* Query the STATUS column in V$ENCRYPTION_WALLET. If STATUS contains a value of OPEN_NO_MASTER_KEY, create and activate the master encryption key.
SELECT wrl_parameter, status, wallet_type
2 FROM v$encryption_wallet;

to create and activate an encryption key, before creating and doing this in there, you first have to close the auto-logon key store in the root container, and then reopen it as a password key store.
ADMINISTER KEY MANAGEMENT SET KEYSTORE close;
ADMINISTER KEY MANAGEMENT SET KEYSTORE open;
2 IDENTIFIED BY keystore-password CONTAINER = all;

Set the container to the PDB. Create and activate a master encryption key in the PDB.
ADMINISTER KEY MANAGEMENT SET KEY USING TAG 'tag'
2 IDENTIFIED BY keystore-password
3 WITH BACKUP USING 'backup_identifier';

Query V$ENCRYPTION_WALLET again, verifying that STATUS is OPEN.

###  Creating and Activating an Encryption Key ###
login using username "ORACLE"

whoami
id
.oraenv
ORCL

mkdir /u02/app/oracle/oradata/ORCL/PDBTEST
sqlplus sys as sysdba
enter password: *****

show PDBS
create pluggable database pdbtest
admin user pdbtestadmin
identified by "A1-b2-c3-d4"
roles=(dba)
file_name_convert=('/u02/app/oracle/oradata/ORCL/pdbseed/',
		   '/u02/app/oracle/oradata/ORCL/PDBTEST/',
		   '/u04/app/oracle/oradata/temp/pdbseed', 
		   '/u04/app/oracle/oradata/temp/PDBTEST');

alter pluggable database PDBTEST open;
alter session set container=PDBTEST;
select status, wallet_type from v$encryption_wallet;
alter session set container=CDB$ROOT;
show PDBS;
show CON_ID
select wallet_type from v$encryption_wallet;

administer key management set keystore close;
administer key management set keystore open identified by "A1-b2-c3-d4" container=all;
select wwallet_type from v$encryption_wallet;
alter session set container=PDBTEST;
administer key management set keys
2 identified by "A1-b3-C3-d4"
3 with backup using 'bdtest_bkup';
/

select status, wallet_type from v$encryption_wallet;
exit

### SPACE MANAGEMENT ###
ORACLE MANAGED FILES (OMF) - pic on desktop

FREE SPACE MANAGEMENT WITHIN SEGMENTS
BMB - Bitmap BLOCK
* - pic on desktop

ROW CHAINING AND MIGRATION
* pic on desktop

TYPES OF SEGMENTS
* - pic on desktop

ALLOCATING EXTENTS
* - pic on desktop

DEFERRED SEGMENT CREATION
* - pic on desktop

show user
show parameter deffered_segment
connect fox@PDB1
show user
set linesize 132
select * from user_segmets;
save q1

create table segtest (coll int,  col12 varchar2(20));
desc segtest
get q1
/

insert into segtest values (1,'aaaaa');
get q1
we have created segment

rollback;
get q1 - the segment still exist

### CONTROLLING DEFERRED SEGMENT CREATION ###
pic in desktop

Restrictions and exeptions
pic on desktop

space-saving features
- pic on desktop

table compression overview
2 types of compression BASIC and ADVANCED
with compression we can hold in one block the equivalent of up to 10 blocks.
-NO DML, cant update existing tables
- pic on desktop

compressions for direct-patch insert operations
- pic in desktop

advanced row compression for DML operations
- pic on desktop

specifying table compression
- pic on desktop

using the compression advisor
- pic on desktop

### SPACE USAGE ###
resolving space usage issues
-DBA outstanding alerts
-pic on desktop

monitoring tablespace space usage
-pic on desktop

reclaiming space by shrinking segments
- pic on desktop

shrinking segments
-pic on desktop

result of a shrinking operations
-pic on desktop

managing resumable space allocation
-pic on desktop

using resumable space allocation
-pic on desktop

resuming suspended statemnets
-pic on desktop

### MANAGING TABLESPACE SPACE ###
. oraenv
ORCL
sqlplus system/oracle_4U@PDB1

exec DBMS_SERVER_ALERT.SET_THRESHOLD(-
dbms_server_alert.tablespace_pct_full,-
NULL,NULL,NULL,NULL,1,1,NULL,-
dbms_server_alter.object_type_tablespace,NULL)> > > ;

alter session set container =cdb$root;

- shows critical tablespace usage
SELECT warning_value, critical_value FROM dba-thresholds
 WHERE metrics_name='Tablespace Space Usage' AND object_name IS NULL; 2

-creating tablespace
CREATE TABLESPACE tbsalert
 DATAFILE '/u01/app/oracle/oradata/ORCL/PDB1/tbsalert.dbf'
 SIZE 120M REUSE LOGGING EXTENT MANAGEMENT LOCAL
 SEGMENT SPACE MANAGEMENT AUTO; 2	2	4

how much free space tsb has?
SELECT df.tablespace_name tablespace. fs.bytes free, df.bytes, fs.bytes*100/ df.bytes PCT_FREE
 FROM dba_data_files df, dba_free_space fs
 WHERE df.tablespace_name = fs.tablespace_name AND df.tablespace_name = 'TBSALERT';

delete hr.employees1;
drop table space dbsalert including contents and datafiles;
exit
high watermark

### USING COMPRESSION ###
select index_name, compression from user_indexes where index_name='I_TEST';
col index_nama format a20
select blocks from user_segments where segmenet_name = 'I_TEST';

more $ORACLE_HOME/rdbms/admin/dbmscomp.sql - to see/scroll the script

alter index hr.i_test rebuild nocompress;

### HANDLING RESUMABLE SPACE ALLOCATION ###
grand pda to pdbadmin; - gives permissions
connect pdbadmin/oracle_4U@PDB1

@$HOME/labs/CreateINVENTORYTablespace.sql
cat $HOME/labs/CreateTable_x.sql

alter session enable resumable
@HOME/labs/CreateTable_x.sql

select file_name, autoextensible from dba_data_files where tablespace_name = 'INVENTORY';
alter database datafile '/u01/app/oracle/oradata/ORCL/PDB1/INVENTPORY01.DBF' autoextend on maxsize 10M;

### Tablespace Encryption by Default ###

transperent data encryption overview (TDE)
-pic on desktop

USING TDE
-pic on desktop

CONTROLLING TABLESPACE ENCRYPTION BY DEFAULT
-pic in desktop

MANAGING THE SOFTWARE KEYSTORE AND MASTER ENCRYPTION KEY
-pic on desktop

MANAGING THE KEYSTORE IN A CDB and PDBs
pic / desktop

CREATING AN ENCRYPTED TABLESPACE BY USING A NON-DEFAULT ALGORITHM
pic / desktop

### Creating a Tablespace That Is Encrypted by Default ###
whoami
sqlplus system
show parameter encrypt
alter session set container=pdb1;
select tablespace_name, encrypted from dba_tablespaces;
create tablespace testencrypt
2 datafile '/u02/app/oracle/oradata/ORCL/PDB1/testencrypt01.dbf' size 20M;
select tablespace_name, encrypted from dba_tablespaces;
drop table tablespace TESTENCRYPT including contents and datafiles.

### MANAGING UNDO DATA ###
what is UNDO data? - It is a record of a transaction and it is done for each and every transaction.
It is retained until the transaction is ended.
Read Consistancy - If some person is updating a record and making a change, and other person want's to read the change,
he can't read the change, until the 1st person commit it, but he can read the original record.

now we can do rollback, read consistancy, and flashback, undo tablespace for recovery.
pic / desktop
transactions and undo data - pic/desktop

REDO - allows to REDO a transaction, to repeat it so that we understand what was it doing.
REDO records get written over here to the undo tablespace. The REDO records get written to the redo log files.

UNDO is stored in specialized segments. UNDO only stores the record that gets changed.
UNDO tablespace is a specially formatted tablespace that holds those undo segments. IF YOU LOSE THIS TABLESPACE, YOU ARE IN TROUBLE, IF DB CRASHES.

WE CAN HAVE A LOT OF TABLESPACES, BUT ONLY ONE OF THEM CAN BE ACTIVE WITH ANI INSTANCE AT A TIME.

storing undo information - pic/desktop

RACK node - in the rack node, we can have two UNDO TABLESPACES, only one is active with one instance and the other is active with another instance.
BUT THE TWO OF THEM CANNOT BE ACTIVE AT THE SAME TIME, IN THE SAME DATABASE.

- Comparing UNDO DATA AND REDO DATA - pic/desktop
Undo stores the original record, so that we can reproduce it.
REDO TELLS US HOW TO REPRODUCE A CHANGE

UNDO PROTECTS FROM INCONSISTENT READS IN A MULTIUSER ENVIRONMENT. IT GIVES THE ABILITY TO CHANGE YOUR MIND ON A TRANSACTION AND ROLL BACK.
REDO I INTENDED TO PROTECT YOU FROM DATA LOSS.

-MANAGING UNDO - pic/desktop
Local Undo Mode Versus Shared Undo Mode - pic/desktop
configuring undo retention - pic/desktop

-categories of undo - pic/desktop

WHAT IF UNDO TABLESPACE FILLS UP?
WE HAD ACTIVE TRANSACTIONS, AND WE HAD UNEXPIRED TRANSACTIONS.

FLASHBACK - FLASHBACK QUERY, FLASHBACK TRANSACTION. WE CAN UNDO TRANSACTIONS

-GENERANTEEING UNDO RETENTION - pic/desktop
- lets say your retention is 900 seconds, which is 15 minutes. the issue is commint. the data will stay in the undo tablespace for 15 minutes. 

-changing an undo tablespace to a fixed size - desktop/pic
-temporary undo overview - desktop/pic
-temporary undo benefits - desktop/pic
-enabling temporary undo - desktop/pic
-monitoring temporary undo - desktop/pic

ROWS UPDATE
update oe.lineorder set LO-QUANTITY=LO=QUANTITY*10;
update oe.product_information set min_price = min_price*10;

rowback;

select comission_pct from hr.employees where employee_id=100;
update hr.employees set comission_pct = .10 where employee_id=100;
create pluggable database PDB4 from PDB1
 2 create file_dest ='/u01/app/oracle/oradata/ORCL/PDB4';

select property_name, property_value from database_properties
2 where property_name = 'LOCAL_UNDO_ENABLED';

shutdown immediate;

startup upgrade;

alter database local undo on;

startup - starting up the database

alter pluggable database pdb1 open;

### MOVING DATA ###
moving data - general architecture - desktop/pic
data pump - it is high-speed server-based utility for both data and metadata movement.
It is callable via the DBMS Data Pump package in the database, and we provide several tools for accessing it - IMPDP and EXPDP
we also have the ability to move data over a database network link

oracle data pump overview - desktop/pic
oracle data pump benefits - desktop/pic
data pump export and import clients - desktop/pic
data pump interfaces and modes - desktop/pic
data pump import tranformations - desktop/pic
sql loader overview - desktop/pic
express mode - desktop/pic
loading methods - desktop/pic
external tables - desktop/pic
external table benefits - desktop/pic

PRACTICE - MOVING DATA FROM ONE PDB TO ANOTHER
expdp oe/oracle_4U@PDB1 schemas=oe dumpfile=/u01/app/oracle/ORCL/dpdump/expoe.dmp - DONT LIKE THE PATH, YOU CAN'T PUT FILES DIRECTLY
log as sys
create directory dp_for_oe as '/u01/app/oracle/admin/ORCL/dpdump';

grant read, write on directory dp_for_oe to oe;

EXPORT - expdp oe/oracle_4U@DPB1 schemas=oe directory=dp_for_oe dumpfile=expoe.dmp;
IMPORT - impdp oe/oracle_4U@DPB1 schemas=oe directory=dp_for_oe dumpfile=expoe.dmp sqlfile=oe_SQL;

delete user command - drop user oetest cascade;

IMPORT - impdp system/oracle_4U@DPB2 remap_schema oe:oetest directory=dp_for_oe dumpfile=expoe.dmp;
select table_name from user_tables;
select count(*) from order_items;
select index_name from user_indexes;
select sequence_name from user_sequences;

create database link link_pdb1 connect to system identified by oracle_4U using 'PDB1';
drop user oetest cascade;

select table_name from user_tables;
select count(*) from order_items;

PRACTICE: Loading Data into a PDB from an External File

SELECT * FROM PRODUCTS;
CREATE TABLE "SYS_SQLLDR_X_EXT_PRODUCTS"

### Querying External Tables ###
ext_dir as '/home/oracle/labs/DP/'
2 ;

create user sh identified bu oracle_4U;
grant create session, create table to sh;
grant read, write on directory ext_dir to sh;
drop table sh.sales_ext_range

select table_name, partition_name, location, directory_name from dba_xternal_loc_partitions;

select count(*) from sh.sales_ext_range partition (year1998);

wc -l /home/oracle/labs/DP/DP_sales_1998.dat

create sh.i_ext_sales_time_id on sh.sales_ext_range (time_id);
alter table sh.sales_ext_range add partition year2000 values less than (to_date('31-12-2000', 'DD-MM-YYYY'))
 2 location (ext_dir2: 'DP2_sales_2000.dat');

select count(*) from sh.shales_ext_range partition (year2000);


CHECK OF THE DATA
select count(*) from sh.sales.ext_range
2 where time_id <= to_date('31-12-2000','DD-MM-YYYY') and time_id => to_date('01-01-2000','DD-MM-YYYY')
; 

### Unloading External Tables ###

set environment
sqlplus system/oracle_4U@pd1

create table eo.orders_ext
2 organization external
3 (type oracle_datapump
4 default directory ext_dir
5 location ('orders.dmp'))
6 as select * from oe.orders;

select count(*) from oe.orders_exit;

create user OE identified by oracle_4U;

create directory ext_dir as '/home/oracle/labs/DP/';

### Backup and Recovery Concepts ###
### DBA Responsibilities ###
RAID - Redundant Array of Inexpensive Disks

#DBA Responsibilities
- Protect the database from failure wherever possible
-Increase the mean time between failured (MTBF)
-Protect critical components by using redundancy
-Decrease the mean time to recover (MTTR)
-Minimize the loss of data

#Statement Failure - desktop/pic
#user process failure - desktop/pic
- your job as DBA is to watch for TRENDS. 
#network failure - desktop/pic
#user error - desktop/pic
#instance failure - desktop/pic
#media failure - desktop/pic
#understanding instance recovery - desktop/pic
#the checkpoint process - desktop/pic
#the redo files and log writers - desktop/pic
#automatic instance or crach recovery - desktop/pic
#phases of instance recovery

#### Tuning Instance Recovery ###
tuning instance rocovery - pic
using the MTTR advisor - (cloud control) - pic
understanding types of backups - pic
backup terminology - pic
types of backups - pic
rman backup types - pic
comparing complete and incomplete rocovery - pic
compete recovery process - pic
point-in-time recovery process - pic
oracle data protection solutions - pic
flashback technology - pic

# Practice 10-1 Configuring Your Database for Recovery
. oraenv
ORCL
$HOME/labs/RMAN_glogin.sh
sqlplus / as sysdba

// info about our control file
select name from v$controlfile;
set linesize 132
show parameter control_file

// creating new control file
create pfile from spfile;

// shuts down the DB imeediate
shutdown immediate;

exit

mkdir -p /u01/app/oracle/controlfiles_dir/ORCL
cp $ORACLE_HOME/dbs/initORCL.ora $ORACLE_HOME/dbs/backup_initORCL.ora
vi $ORACLE_HOME/dbs/initORCL.ora

find control file parameter
*control_files='/u01/app/oracle/oradata/ORCL/control01.ctl','/u01/app/oracle/fast_recovery_area/ORCL/control01.ctl','/u01/app/oracle/controlfiles_dir/ORCL/control03.ctl'

cp /u01/app/oracle/oradata/ORCL/control01.ctl /u01/app/oracle/controlfiles_dir/ORCL/control03.ctl

// log back in
sql plus / as sysdba

//start db
startup

set linesize 132
show parameter control_files

exit
sqlplus / as sysdba
shutdown immediate
exit

cp /u01/app/oracle/oradata/ORCL/control01.ctl /u01/app/oracle/controlfiles_dir/ORCL/control03.ctl
sqlpus / as sysdba

create spfile from pfile;

startup

show parameter control_file

select name from v$controlfile;

show parameter db_recovery_file_dest

alter system set db_recovery_file_dest_size = 30G scope=both;

show parameter db_recovery_file_dest_size

select group#, status, member from v$logfile;

alter database add logfile member '/u01/app/oracle/fast_recovery_area/ORCL/redo01b.log' to group 2;
alter database add logfile member '/u01/app/oracle/fast_recovery_area/ORCL/redo02b.log' to group 2;
alter database add logfile member '/u01/app/oracle/fast_recovery_area/ORCL/redo03b.log' to group 3;

//re-run our query
select group#, status, member from v$logfile;
select group#, members, archived, status from v$log;

alter system switch logfile;
/ - one
/ - twice
/ - tree times

select group#, status, member from v$logfile order by 1, 3;
select group#, member, archived, status from v$log;

alter system switch logfile;

shutdown immediate;
startup mount;
alter database archivelog;
alter database open;

shutdown immediate;
startup

archive log list
mkdir /u01/app/oracle/oradata/ORCL/archive_dir2
sqlplus / as sysdba

alter system set log_archive_dest_1='LOCATION=USE_DB_RECOVERY_FILE_DEST' scope=both;

alter system set log_archive_dest_1='LOCATION=/u01/app/oracle/oradata/ORCL/archive_dir2' scope=both;

alter system switch logfile;
/
/
/

select group#, members, archived, status from v$log;
select name from v$archived_log order by stamp;
col name format a80
set linesize 132
col name format a120
/

### Practice 10-2 Backing up the Control File ###
. oraenv
ORCL
sqlplus system/oracle_4U

select name from v$controlfile;

//going to create a text file backup of our control file (IMPORTANT COMMAND)
alter database backup controlfile to trace;

exit

cd /u01/app/oracle/diag/rdbms/orcl/ORCL/trace
ls
adrci
show alert


tail alert_ORCL.log
cat /u01/app/oracle/diag/rdbms/orcl/ORCL/trace/ORCL_ora_25218.trc

### Practice 10-3 Configuring Automatic Backups of the Control File and SPFILE ###
. oraenv
ORCL

rman target "'/ as sysbackup'";  OR  rman target /

show all;

CONFIGURE CONTROLFILE AUTOBACKUP OFF;
exit

show all;

CONFIGURE CONTROL AUTOBACKUP ON;

exit

### Practice 10-4 Creating a Whole Database Backup ###
. oraenv
ORCL

$HOME/labs/RMAN_setup.sh

rman target /

//(DBID=1231434 - DATA BASE ID)

// we can see all our database files and a list of temporary files
report schema;

//backup our database
backup database plus archivelog;

list backup;

exit

cd /u01/app/oracle/fast_recovery_area/ORCL/ORCL/
ls -ltr

cd
rman target /
show retention policy
backup as copy database plus archivelog delete input;
exit

### Practice 10-5 Creating a Partial Database Backup ###
. oraenv
ORCL
rman target /

backup pluggable database  pdb1 plus archivelog;
exit

// going to perform a partial backup of the database in RMAN directly.
rman target sys/oracle_4U@PDB1

backup database;

configure controlfile autobackup on;
exit

rman target sys/oracle_4U@PDB2

backup tablespace tbs_app;
exit

rman target /

backup tablespace pdb2:tbs_app;
exit

###  Practice 10-6 Recovering From an Essential Data File Loss ###
. oraenv
ORCL
$HOME/labs/RMAN_crash.sh

sqlplus system/oracle_4U
create user c##test identified by oracle_4U;
exit

rman target /
restore datafile 1;

shutdown immediate;

shutdown abort;

startup mount;

restore data file1;

recover datafile 1;

alter databse open;

alter pluggable database all open;

exit

sqlplus system/oracle_4U
create user C##test identified by oracle_4U;

// recovery command
$HOME/labs/RMAN_crash.sh

create user c##test2 identified by oracle_4U;

//resize file
alter database datafile 1 resize 1G;

exit

sqlplus / as sysdba
shutdown abort
exit

start mount;
startup mount;

list failure; //data advisor
advise failure; //advisor for failures
repair failure; preview /step by step for repairing

repair failure; // will ask "do you really want to repair this - YES or NO

alter pluggable database all open;
exit
sqlplus / as sysdba
alter database datafile 1 resize 1G;
exit

### Practice 10-7 Recovering From an Application Data File Loss ###
. oraenv
ORCL
$HOME/labs/setup_pdb1.sh

rman target /
backup pluggable database pdb1 plus archivelog;
exit

$HOME/labs/RMAN_crush_app.sh
sqlplus / as sysdba
alter session set container = pdb1;
create table oe.test (c number) ;
insert into oe.test values(1);
select tablespace_name from dba_data_files where file_id=92;
select tablespace_name, status from dba_tablespaces; //show if the table is online
show pdbs
exit


rman target sys/oracle_4U@PDB1
report schema;

shutdown immediata;
restore database;

recover database;
exit

alter session set container=pdb1;
insert into oe.test values(1);
exit

$HOME/labs/RMAN_crash_app.sh
sqlplus / as sysdba
alter session set container = pdb1;
show pdbs
create table oe.test2 (c number) ;
insert into oe.test2 values (1); // the file is missing
alter pluggable database pdb1 close;
repair pluggable database pdb1;
alter pluggable database pd1 open;
exit
sqlplus / as sysdba
sqlplus system/oracle_4U@PDB1
insert into oe.test2 values(2);
commit;
exit

###  Monitoring and Tuning Database Performance ###
### Performance Management Activities ###
#performane management activities - pic
// if  the devices that we are reading and writing from could lead you to a network bottleneck. So if you are using an NFS mounted device you are constantly reading and writing

### performance planning considerations - pic
### database server statistics and metrics - pic
3 levels - basic, typical, all
### performance monitoring - pic
### monitoring wait events - pic
### viewing instance statistics - pic
### monitoring sessions - pic
### monitoring services - pic
### database maintenance - pic
### automatic workload repository - pic
### automatic database diagnostic monitor - pic
### performance tuning mathodology - pic

###Managing Memory Components - pic
# automatic shared memory management - pic
# automatic memory management - pic

// creating pfile
create pfile='/tmp/xxx.ora'from spfile;
view /tmp/xxx.ora;

# managing SGA for PDBs - pic
# managing the program global area - pic
# managing the PGA for a PDB - pic

### Practice 11-1 Managing Performance in EM Express ###
. oraenv
ORCL
// run a script - generating activity in db
$HOME/labs/PERF_setup_tuning.sh
$HOME/labs/PERF_loop.sh

### Practice 11-2 Resolving Lock Issues ###
. oraenv
ORCL
$HOME/labs/RESOLVE_LOCK_ISSUES_setup.sh

sqlplus ngreenberg/oracle_4U@PDB1
update hr.employees set phone_number='650.555.1212 where employee_id=110;


// log and set env in new tab
. oraenv
ORCL
sqlplus smavris/oracle_4U@PDB1
enter user-name: 

update hr.employees set Salary=8300 where employee_id=110;

// in new tab
. oraenv
ORCL
sqlplus system/oracle_4U@PDB1
alter system kill session '200,55217' where employee_id=110;

select phone_number from hr.employeees where employee_id=110;
exit

### 12. Tuning SQL ###
# tuning sql process - pic
# oracle optimizer - pic 
// what is view? VIEW it might be part of a table, might looks like a table, acts like a table but is's NOT A TABLE. It is a stored SQL statement
that gives the illusion of a table. It might be a few columns, or maybe just a few rows of a table. Or it might be a join across multiple tables.

#optimizer statistics - NO pic
// optimizer statistics tell us different things about tables, indices. It's going to tell us about what's going on with the system cpu and i/o.

#optimizer statistics collection - pic
// Statistics collection is automatic in the system.
dynamic statistics where it do sampling. sampling happens if statistics are missing, or they're extremely stale, or the statistics are insufficient

#setting optimizer statistics preferences - pic

#optimizer statistics advisor - pic
#sql plan directives - pic
#adaptive execution plans - pic
// adaptive query execution, we can make adaptive plans, which tells to re-optimize or use some distributed parallelization methods. adoptive statistics
For instance if we have fewer han a hundred rows, we are gonna use nested loop
If 

#sql tuning advisor - pic
#sql access advisor - pic
#sql performance analyzer - pic


### Practice 12-1 Using SQL Tuning Advisor ###
// set the environment
. oraenv
ORCL
//run a script
$HOME/labs/PERF_setup_tuning.sh

//this script makes activity
$HOME/labs/PERF_loop.sh

//and we log in EM EXPRESS, and we see executions statistics, sql details, sql tuning

//FLUSH SHARED POOL MEMORY
alter system flush shared_pool;
alter system flush buffer_cache;
exit

### Practice 12-2 Using Optimizer Statistics Advisor ###
//set the environment
. oraenv
ORCL
// run a script
$HOME/labs/PERF_setup_tuning.sh

// run a script to provide some data
$HOME/labs/PERF_loop.sh

// in new terminal/window set environment
. eranev
ORCL
sqlplus sys/oracle_4U@PDB1 as sysdba

// what's in the file?
cat $HOME/labs/OPTADV_1.sql

// run the script
$HOME/labs/OPTADV_1.sql

// what's in the file?
cat $HOME/labs/OPTADV_2.sql

exit

// run the script
$HOME/labs/OPTADV_2.sql

// from this we see the task is completed.
set linesize 132
select advisor_name execution_type, last_execution, status
2 from user_advisor_tasks
3 where task_name='my_taks;
/

col ADVISOR_NAME format a20
col EXECUTION_TYPE format a20
col LAST_EXECUTION format a15
col TASK_NAME format a15
col execution_name format a15
col execution_time format a15


col TYPE format a20
select task_name, execution_name, execution_end, execution_type as type, status
2 from user_advisor_executions
3 /

cat $HOME/labs/OPTADV_3.sql
// execute
$HOME/labs/OPTADV_3.sql

cat $HOME/labs/OPTADV_4.sql
// execute
$HOME/labs/OPTADV_4.sql

cat $HOME/labs/OPTADV_5.sql
// run script
$HOME/labs/OPTADV_5.sql


// from this we gonna see extreme amount of blocks, we see when they are last updated and analyzed
@$HOME/labs/OPTADV-8
col table_name format a20
set linesize 132
select table_name, num_rows, blocks, empty_blocks, avg_row_len, last_analyzed
2 from dba_tables
3 where owner='OE';

//execution command
exec dbms_stats.drop_advisor_task('my_task')
exit

### Oracle Database Resource Manager ###
Oracle Database Resource Manager Overview - pic
//it's also called resource manager, tather than database resource manager.
and it allows you to control the allocation of resources in a database and OS for users.
For instance, maybe in your database, you have a whole host of users (batch users, people doing some reporting, OLTP users)
We want the OLTP users to get the lion's share of the resource.
We want the DSS users to have resources but not so as much.

Oracle database resource manager basicly handles this by distrubing the resources amont sessions, when we start running out of resources.

#resource manager elements - pic
#using resource manager to allocate resources - pic
#create a simple resource plan - pic
// SYSGROUP gets 100% at level 1. it has 8 cascading levels. Whatever one group doesn't use, the remainder is pushed down to the remaining groups.
when the machine is bagged up, it will proceed, everybody is going to get something and everything is going to preceed.
Each and every group gets little share of the resource.

#Creating a complec resource plan - pic
#use the active session pool feature - pic
// in the pic we can see that we can support up to five OLTP users at once
DSS users use too much resources

#Limiting CPU utilization at the database level - pic
#Limiting CPU utilization at the server level - pic
#viewing resource manager information - pic
#limiting pga memory allocated to each session - pic
// you can define a per-session PGA limit, like the OLTP users. we can have a limit of a 350 megs, that a session can use before we kill it.
#creating directives for PDB performance profiles - pic
//numbers of shares, we can set physical limits, we can say what the performance is based on application container
so we can set those shares and we can set them in a profile and apply them to our PDB's or our application PDB's.

### Practice 13-1 Dispatching Resources Amongst PDBs by Using Resource Manager ###
// set environment
. oraenv
ORCL

//run a script
$HOME/labs/TUNING_rsrc_cleanup.sh

// open new terminal window and set environments
. oraenv
ORCL
sqlplus system/oracle_4U@PDB1
@$HOME/labs/create_burn_cpu.sql

// open another terminal window, set environment
. oraenv
ORCL
sqlplus system/oracle_4U@PDB2
@$HOME/labs/create_burn_cpu.sql
cat $HOME/labs/setup_plan_directives.sql // we see the fair plans and the amout of shares that they have.

sqlplus / as sysdba
@HOME/labs/setup_plan_directives.sql
select plan from cdb_cdb_resource_plans where con_id=1 and plan in ('FAIRPLAN','UNFAIRPLAN');

//list the shares among them
select plan, pluggable_database, shares
2 from cdb_cdb_rstc_plan_directives
3 where con_id=1 and plan in ('FAIRPLAN','UNFAIRPALN') and pluggable_database in ('PDB1','PDB2')
4 order by 1, 2;

col pluggable_database format a20
col plan format a20

save plan_q.sql
alter system set resource_manager_plan=fairplan;
select name from v$rsrc_plan where con_id=1;

set serverout on

set serverout on
exec Burn_CPU_for_RM_Demo();	//shows amount about the cpu

save qplan.sql
alter system set resource_manager_plan=unfairplan;
@qplan // runs qplan

set serverout on
exec Burn_CPU_For_RM_Demo();

### Practice 13-2 Avoiding Excessive PGA Memory Usage ###
// set environment
. oraenv
ORCL
//run the script
$HOME/labs/undo_setup_tuning.sh

. oraenv // to be sure for the environment
ORCL
sqlplus oe/oracle_4U@PDB1
set linesize 132
select * from oe.lineorder order by lo_orderkey, lo_custkey, lo_partkey, lo_suppkey;

// in new window set environment
. oraenv
ORCL
sqlplus system/oracle_4U@PDB1
cat $HOME/labs/PGAMEM_1.sql

exit

//run script
$HOME/labs/PGAMEM_1.sql

col username format a20
col name format a30
$HOME/labs/PGAMEM_1.sql

@$HOME/labs/script_rm.sql

col plan format a20
col GROUP OR SUBPLAN format a20

execute dbms_resource_manager.clear_pending_area();

//second script
execute dbms_resource_manager.create_pending_area();

//third script
execute dbms_resource_manager.create_plan_directive('PGA_plan','Reporting_Users',session_pga_limit => 80);
execute dbms_resource_manager.validate_pending_area();
execute dbms_resource_manager.submit_pending_area();

//activate the plan in PDB1
alter system set resource_manager_plan='PGA_plan';
alter system flush buffer_cache;
col plan format a20
col group_or_subplan format a20

select plan, group_or_subplan, session_pga_limit
2 from dba_rsrc_plan_directives
3 where plan = 'PGA_PLAN';

// in window 1 will exit
exit

set linesize 132
select * from oe.lineorder order by lo_orderkey, lo_customerkey, lo_parkkey, lo_suppkey; // we will see we have a limit up to 80 mg

select name, pga_limit_sessions_killed from v$rsrc_consumer_group;

// will check the pga limit with script
@HOME/labs/PGAMEM_1.sql
exit

$HOME/labs/cleanup_rm.sh


### Enterprise Manager Cloud Control ###
# Starting enterprise manager cloud control - 

#challenges for administrators - pic
// what is cloud control? - dba tool

#what is enterprise manager cloud control? - pic
// cloud control allows us to manage all these components, and bring them together.

#controlling the enterprise manager cloud control flamework - pic
//enterprise manager cloud control is a set of a different components.
1st component: database - reposotory / OMR (Oracle Management Repository), database dedicated to the cloud control
2nd component: OMS (ORACLE MANAGEMENT SERVER) - Its a WebLogic server, running a set of Java programs that are going to collect data process data, present data to clients(web based client) or command line client.
3rd component: AGENTS are deployed in the field on our servers, on our hosts, and the agents are going to manage those hosts and manage things running ot those hosts. (THE THINGS RUNNING ON THOSE HOSTS ARE CALLED TARGETS)
stored data on cloud is METRICS, CONFIGURATION DATA, TRACKING DATA, CHANGE IN CONFIGURATION 
CAN MANAGE OPERATION SYSTEMS - WINDOWS, LINUX, UNIX AND WE CAN COLLECT METRICS ON IT.

what are the AGENTS? - They are Java programs, installed into their own homes, on the host or virtual server.

# Starting the Enterprise Manager Cloud Control Framework - pic
How to start MANAGER CLOUD CONTROL
1st - start the repository (OMR), lister
2dn - start OMS and agents (all agents start communicating to the central agent, which stores data in OMS and OMR)

# stopping the Enterprise Manager Cloud Control Framework - pic

// from cloud control manager you can see all datafiles, components, configuration, can download configuration

EMC13c - Enterprise Manager Cloud Control 13c
