/********************************************************************************
*********       E-mail subject: MOBARCWEB-665
*********             Instance: PROD
*********          Description: 
Problem:
There was a slowness on e_tlc_savirmtdv screen on MOB_ARCOLE PROD.

Analysis:
The problem in the provided query was that Oracle was using 
inappropriate execution plan, starting the execution from column refindividu in table T_INTERVENANTS, which column in 
this case was equal to 'INT00000'. For this reason over 8 milion rows were selected, which takes time. The solution is to 
make Oracle to start from column tva in table G_INDIVIDU, which is much more selective.

Suggestion:
Please add hint as it is shown in the New SQL section below to make Oracle start from the more selective part, 
but add the hint only in this variant of the query (if the query is dinamic).

*********               SQL_ID: 59zbknb8wmdr8
*********      Program/Package: 
*********              Request: Andrey Kostadinov
*********               Author: Dimitar Dimitrov
********* Received e-mail date: 14/09/2023
*********      Resolution date: 14/09/2023
*********  Trace old file here: \\epox\specifs\performance\tmp\
*********  Trace new file here:
***********************************************************************************/

/********************************OLD SQL*******************************************/
var B1 varchar2(32);
exec :B1 := 'C106';
var B2 varchar2(32);
exec :B2 := 'DB';
var B3 varchar2(32);
exec :B3 := 'BE0423865353';
var B4 varchar2(32);
exec :B4 := '1510147278';
var B5 varchar2(32);
exec :B5 := 'CL';
var B6 varchar2(32);
exec :B6 := 'INT00000';
var B7 NUMBER;
exec :B7 := 2001;
var B8 NUMBER;
exec :B8 := 1;

SELECT *
  FROM (SELECT /*+ first_rows(2001)*/
         foo.*, ROWNUM rnum
          FROM (SELECT refdoss     intCaseReference,
                       clientname  clientName,
                       soldedb     debitBalance,
                       reftype     refType,
                       ancrefdoss  extCaseReference,
                       refindividu refIndividu,
                       debiteur    customerName
                  FROM (SELECT gi.nom || ' ' || gi.prenom debiteur,
                               DECODE(:B1,
                                      'C106',
                                      tcm_dossier.debitbalance(GD.refdoss),
                                      GD.soldedb) soldedb,
                               GD.ancrefdoss ancrefdoss,
                               TI_DB.reftype reftype,
                               TI_DB.refindividu refindividu,
                               TI_DB.refdoss refdoss,
                               TI_CL.nom clientname
                          FROM t_intervenants TI_DB,
                               g_individu     GI,
                               t_intervenants TI_CL,
                               g_dossier      GD
                         WHERE TI_DB.reftype = :B2
                           AND TI_DB.refindividu = GI.refindividu
                           AND GI.tva = :B3
                           AND TI_DB.refdoss <> :B4
                           AND TI_CL.reftype = :B5
                           AND TI_DB.refdoss = TI_CL.refdoss
                           AND TI_CL.refindividu = :B6
                           AND TI_DB.refdoss = GD.refdoss)
                 WHERE 1 = 1
                 ORDER BY refdoss, refdoss) foo
         WHERE ROWNUM <= :B7)
 WHERE 1 = 1
   AND rnum >= :B8;
/********************************OLD SQL*******************************************/
/********************************OLD Metrics***************************************/
/*
Plan hash value: 1774178039
------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                          | Name           | Starts | E-Rows | A-Rows |   A-Time   | Buffers | Reads  |
------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                   |                |      1 |        |      9 |00:10:35.18 |      26M|   2168K|
|*  1 |  VIEW                              |                |      1 |      1 |      9 |00:10:35.18 |      26M|   2168K|
|*  2 |   COUNT STOPKEY                    |                |      1 |        |      9 |00:10:35.18 |      26M|   2168K|
|   3 |    VIEW                            |                |      1 |      1 |      9 |00:10:35.18 |      26M|   2168K|
|   4 |     NESTED LOOPS                   |                |      1 |      1 |      9 |00:10:35.10 |      26M|   2167K|
|   5 |      NESTED LOOPS                  |                |      1 |      1 |   8883K|00:06:37.14 |      13M|   1337K|
|   6 |       NESTED LOOPS                 |                |      1 |      1 |   8883K|00:06:09.33 |    8372K|   1328K|
|   7 |        NESTED LOOPS                |                |      1 |      1 |   8883K|00:02:44.08 |    4417K|    478K|
|   8 |         TABLE ACCESS BY INDEX ROWID| T_INTERVENANTS |      1 |      1 |   8883K|00:02:01.97 |    3307K|    382K|
|*  9 |          INDEX RANGE SCAN          | INT_INDIV      |      1 |      1 |   8883K|00:00:10.79 |   45066 |  45063 |
|* 10 |         INDEX RANGE SCAN           | INT_REFDOSS    |   8883K|      1 |   8883K|00:00:34.54 |    1110K|  95979 |
|  11 |        TABLE ACCESS BY INDEX ROWID | G_DOSSIER      |   8883K|      1 |   8883K|00:03:18.22 |    3954K|    849K|
|* 12 |         INDEX UNIQUE SCAN          | DOS_REFDOSS    |   8883K|      1 |   8883K|00:00:12.34 |     310K|  16172 |
|* 13 |       INDEX UNIQUE SCAN            | IND_REFINDIV   |   8883K|      1 |   8883K|00:00:20.89 |    5306K|   9114 |
|* 14 |      TABLE ACCESS BY INDEX ROWID   | G_INDIVIDU     |   8883K|      1 |      9 |00:03:53.60 |      12M|    830K|
------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   1 - filter("RNUM">=:B8)
   2 - filter(ROWNUM<=:B7)
   9 - access("TI_CL"."REFINDIVIDU"=:B6 AND "TI_CL"."REFTYPE"=:B5)
       filter("TI_CL"."REFDOSS"<>:B4)
  10 - access("TI_DB"."REFDOSS"="TI_CL"."REFDOSS" AND "TI_DB"."REFTYPE"=:B2)
       filter("TI_DB"."REFDOSS"<>:B4)
  12 - access("TI_DB"."REFDOSS"="GD"."REFDOSS")
       filter("GD"."REFDOSS"<>:B4)
  13 - access("TI_DB"."REFINDIVIDU"="GI"."REFINDIVIDU")
  14 - filter("GI"."TVA"=:B3) 
*/
/********************************OLD Metrics***************************************/

/********************************New SQL*******************************************/

SELECT *
  FROM (SELECT /*+ first_rows(2001)*/
         foo.*, ROWNUM rnum
          FROM (SELECT refdoss     intCaseReference,
                       clientname  clientName,
                       soldedb     debitBalance,
                       reftype     refType,
                       ancrefdoss  extCaseReference,
                       refindividu refIndividu,
                       debiteur    customerName
                  FROM (SELECT /*+ leading(GI) */ gi.nom || ' ' || gi.prenom debiteur,
                               DECODE(:B1,
                                      'C106',
                                      tcm_dossier.debitbalance(GD.refdoss),
                                      GD.soldedb) soldedb,
                               GD.ancrefdoss ancrefdoss,
                               TI_DB.reftype reftype,
                               TI_DB.refindividu refindividu,
                               TI_DB.refdoss refdoss,
                               TI_CL.nom clientname
                          FROM t_intervenants TI_DB,
                               g_individu     GI,
                               t_intervenants TI_CL,
                               g_dossier      GD
                         WHERE TI_DB.reftype = :B2
                           AND TI_DB.refindividu = GI.refindividu
                           AND GI.tva = :B3
                           AND TI_DB.refdoss <> :B4
                           AND TI_CL.reftype = :B5
                           AND TI_DB.refdoss = TI_CL.refdoss
                           AND TI_CL.refindividu = :B6
                           AND TI_DB.refdoss = GD.refdoss)
                 WHERE 1 = 1
                 ORDER BY refdoss, refdoss) foo
         WHERE ROWNUM <= :B7)
 WHERE 1 = 1
   AND rnum >= :B8;
/********************************New SQL*******************************************/
/********************************New Metrics***************************************/
/*
Plan hash value: 2407907825
----------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                   | Name            | Starts | E-Rows | A-Rows |   A-Time   | Buffers | Reads  |
----------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                            |                 |      1 |        |      9 |00:00:00.04 |     380 |    253 |
|*  1 |  VIEW                                       |                 |      1 |      1 |      9 |00:00:00.04 |     380 |    253 |
|*  2 |   COUNT STOPKEY                             |                 |      1 |        |      9 |00:00:00.04 |     380 |    253 |
|   3 |    VIEW                                     |                 |      1 |      1 |      9 |00:00:00.04 |     380 |    253 |
|*  4 |     SORT ORDER BY STOPKEY                   |                 |      1 |      1 |      9 |00:00:00.02 |     101 |     43 |
|   5 |      NESTED LOOPS                           |                 |      1 |      1 |      9 |00:00:00.02 |     101 |     43 |
|   6 |       NESTED LOOPS                          |                 |      1 |      1 |      9 |00:00:00.02 |      93 |     36 |
|   7 |        NESTED LOOPS                         |                 |      1 |      1 |      9 |00:00:00.02 |      73 |     32 |
|   8 |         NESTED LOOPS                        |                 |      1 |      2 |      9 |00:00:00.02 |      45 |     14 |
|   9 |          TABLE ACCESS BY INDEX ROWID BATCHED| G_INDIVIDU      |      1 |      1 |     10 |00:00:00.01 |      13 |      8 |
|* 10 |           INDEX RANGE SCAN                  | G_INDIV_TVA_IDX |      1 |      1 |     10 |00:00:00.01 |       4 |      2 |
|* 11 |          INDEX RANGE SCAN                   | INT_INDIV       |     10 |      1 |      9 |00:00:00.01 |      32 |      6 |
|  12 |         TABLE ACCESS BY INDEX ROWID BATCHED | T_INTERVENANTS  |      9 |      1 |      9 |00:00:00.01 |      28 |     18 |
|* 13 |          INDEX RANGE SCAN                   | INT_REFDOSS     |      9 |      1 |      9 |00:00:00.01 |      20 |     10 |
|* 14 |        INDEX UNIQUE SCAN                    | DOS_REFDOSS     |      9 |      1 |      9 |00:00:00.01 |      20 |      4 |
|  15 |       TABLE ACCESS BY INDEX ROWID           | G_DOSSIER       |      9 |      1 |      9 |00:00:00.01 |       8 |      7 |
----------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   1 - filter("RNUM">=:B8)
   2 - filter(ROWNUM<=:B7)
   4 - filter(ROWNUM<=:B7)
  10 - access("GI"."TVA"=:B3)
  11 - access("TI_DB"."REFINDIVIDU"="GI"."REFINDIVIDU" AND "TI_DB"."REFTYPE"=:B2)
       filter("TI_DB"."REFDOSS"<>:B4)
  13 - access("TI_DB"."REFDOSS"="TI_CL"."REFDOSS" AND "TI_CL"."REFTYPE"=:B5 AND "TI_CL"."REFINDIVIDU"=:B6)
       filter("TI_CL"."REFDOSS"<>:B4)
  14 - access("TI_DB"."REFDOSS"="GD"."REFDOSS")
       filter("GD"."REFDOSS"<>:B4)
*/
/********************************New Metrics***************************************/

/********************************Index statistics**********************************/

/********************************Other SQLs****************************************/          
/*

*/ 
/********************************Other SQLs****************************************/              
