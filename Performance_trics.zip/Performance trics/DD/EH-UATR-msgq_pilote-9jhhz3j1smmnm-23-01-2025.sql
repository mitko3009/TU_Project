/********************************************************************************
*********       E-mail subject: EH-37585
*********             Instance: UATR
*********          Description: 
Problem:
The msgq processing work slow and there were 17K unprocessed calls and the system processes two calls per minute.

Analysis:
We checked for module msgq% on UATR for the period between 13:00 on 22/01/2025 and 10:00 on 23/01/2025 and as you can see below, the heaviest module in the AWR is the msgq_pilote.
The TOP SQL in it is 9jhhz3j1smmnm ( SE Variable ds_DB_act_cases ), which was responsible for 96% of the time. The problem in it is that it is using IN in the subselect, which leads to looping millions times ( for every 
selected row from table t_intervenants t2 ). The solution here is to remove the IN and join the tables directly. Also, to escape the looping, we used table t_intervenants t1 to enter into 
the NOT EXISTS instead of table t_intervenants t2 and also added rownum = 1 to the query.

In the task, SE Variable ds_db_inv_party was identified that takes long. We checked the SQL text in this variable and found that this query can be improved. The solution here is similar as 
the solution for SQL 9jhhz3j1smmnm - the IN in the subselect should be removed and we joined table t_intervenants t with table t_intervenants t1 by refdoss column.

Suggestion: 
Please check is the variand of SE variables ds_DB_act_cases and ds_db_inv_party in the New SQL section below are functionally correct and if they are, please change them as it is shown 
in the New SQL section below.

*********               SQL_ID: 9jhhz3j1smmnm -> SE Variable ds_DB_act_cases, SE Variable ds_db_inv_party
*********      Program/Package: 
*********              Request: Dimitare Ivanov
*********               Author: Dimitar Dimitrov
********* Received e-mail date: 23/01/2025
*********      Resolution date: 23/01/2025
*********  Trace old file here: \\epox\specifs\performance\tmp\
*********  Trace new file here:
***********************************************************************************/

/********************************OLD SQL*******************************************/

-- 9jhhz3j1smmnm -> SE Variable ds_DB_act_cases

var REFDOS VARCHAR2(32);
exec :REFDOS := '2501150045';

select count(*)
  from t_intervenants t1, 
       t_intervenants t2
 where t1.reftype = 'DB'
   and t2.reftype = 'DB'
   and t1.refdoss = :refdos
   and t1.refindividu = t2.refindividu
   and not exists ( select 1
                      from t_filiere
                     where refdoss in ( select refdoss
                                          from t_intervenants
                                         where refindividu = t2.refindividu )
                       and nvl(nom, 'x') in ('CLO', 'BAL')
                       and dtfin is null );


-- SE Variable ds_db_inv_party 

var REFDOS VARCHAR2(32);
exec :REFDOS := '2501150045';

select count(*)
  from t_intervenants t, 
       v_domaine v
 where t.refdoss = :REFDOS
   and t.reftype = v.valeur
   and v.type = 'INV_PRTY_ADDITION'
   and not exists ( select 1
                      from t_intervenants t1
                     where reftype = t.reftype
                       and refdoss in ( select t2.refdoss
                                          from t_intervenants t1, 
                                               t_intervenants t2
                                         where t1.refdoss <> t2.refdoss
                                           and t1.reftype = 'DB'
                                           and t2.reftype = 'DB'
                                           and t1.refdoss = :REFDOS
                                           and t1.refindividu = t2.refindividu ) );


/********************************OLD SQL*******************************************/
/********************************OLD Metrics***************************************/
/*
MODULE                    SQL_ID         PLAN_HASH SID    SERIAL# EVENT                          FROM                           TO                                 ACTIVE NUMBER_OF_EXECUTIONS PERC
------------------------- ------------- ---------- ------ ------- ------------------------------ ------------------------------ ------------------------------ ---------- -------------------- ------
msgq_pilote                                                                                      2025/01/22 13:00:58            2025/01/23 09:59:52                277360              5372115 99%
msgq                                                                                             2025/01/22 13:00:58            2025/01/23 08:06:38                  2450               990429 1%
msgq_variab                                                                                      2025/01/22 13:09:28            2025/01/23 07:32:20                   500              1874962 0%



MODULE                    SQL_ID         PLAN_HASH SID    SERIAL# EVENT                          FROM                           TO                                 ACTIVE NUMBER_OF_EXECUTIONS PERC
------------------------- ------------- ---------- ------ ------- ------------------------------ ------------------------------ ------------------------------ ---------- -------------------- ------
msgq_pilote                                                       ON CPU                         2025/01/22 13:00:58            2025/01/23 09:59:52                272560              5372115 97%
msgq                                                              ON CPU                         2025/01/22 13:00:58            2025/01/23 07:34:41                  2180               990429 1%
msgq_pilote               9jhhz3j1smmnm 1980655748                direct path write temp         2025/01/22 13:18:58            2025/01/23 09:32:36                  1550                22262 1%
msgq_pilote                                                       enq: TX - row lock contention  2025/01/22 13:04:38            2025/01/22 13:09:18                  1150                  121 0%


MODULE                    SQL_ID         PLAN_HASH SID    SERIAL# EVENT                          FROM                           TO                                 ACTIVE NUMBER_OF_EXECUTIONS PERC
------------------------- ------------- ---------- ------ ------- ------------------------------ ------------------------------ ------------------------------ ---------- -------------------- ------
msgq_pilote                                                       ON CPU                         2025/01/22 13:00:58            2025/01/23 09:59:52                272560              5372115 98%
msgq_pilote               9jhhz3j1smmnm 1980655748                direct path write temp         2025/01/22 13:18:58            2025/01/23 09:32:36                  1550                22262 1%
msgq_pilote                                                       enq: TX - row lock contention  2025/01/22 13:04:38            2025/01/22 13:09:18                  1150                  121 0%



MODULE                    SQL_ID         PLAN_HASH SID    SERIAL# EVENT                          FROM                           TO                                 ACTIVE NUMBER_OF_EXECUTIONS PERC
------------------------- ------------- ---------- ------ ------- ------------------------------ ------------------------------ ------------------------------ ---------- -------------------- ------
msgq_pilote               9jhhz3j1smmnm 1980655748                                               2025/01/22 13:01:08            2025/01/23 09:59:52                265700                22826 96%
msgq_pilote               dzxjxsvpdzk9c 2253319006                                               2025/01/22 20:37:20            2025/01/23 09:59:52                  3680                   36 1%
msgq_pilote               9wkxnq194wya3 1530890336                ON CPU                         2025/01/22 13:09:38            2025/01/23 09:44:58                  1060              1357758 0%
msgq_pilote               b3ntrd3uxjsdf          0                                               2025/01/22 13:04:38            2025/01/23 09:29:46                   920                13685 0%


-- 9jhhz3j1smmnm -> SE Variable ds_DB_act_cases

Plan hash value: 1980655748
-------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation            | Name          | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  | Writes |
-------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT     |               |      1 |        |  2099 (100)|      1 |00:00:26.63 |     160K|   4487 |   4487 |
|   1 |  SORT AGGREGATE      |               |      1 |      1 |            |      1 |00:00:26.63 |     160K|   4487 |   4487 |
|*  2 |   HASH JOIN ANTI     |               |      1 |    112 |  2099   (1)|      0 |00:00:26.63 |     160K|   4487 |   4487 |
|   3 |    NESTED LOOPS      |               |      1 |  11176 |     2   (0)|      3 |00:00:00.01 |       7 |      0 |      0 |
|*  4 |     INDEX RANGE SCAN | INT_REFDOSS   |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |      0 |      0 |
|*  5 |     INDEX RANGE SCAN | INT_INDIV     |      1 |  10600 |     1   (0)|      3 |00:00:00.01 |       4 |      0 |      0 |
|   6 |    VIEW              | VW_SQ_1       |      1 |    442K|  2095   (1)|     13M|00:00:23.21 |     160K|   4487 |   4487 |
|   7 |     MERGE JOIN SEMI  |               |      1 |    442K|  2095   (1)|     13M|00:00:21.27 |     160K|   4487 |   4487 |
|   8 |      INDEX FULL SCAN | INT_DOS_INDIV |      1 |     15M|   745   (1)|     16M|00:00:02.99 |   77087 |      0 |      0 |
|*  9 |      SORT UNIQUE     |               |     16M|  73242 |  1350   (1)|     13M|00:00:11.46 |   83887 |   4487 |   4487 |
|* 10 |       INDEX SKIP SCAN| TIND_FIL      |      1 |  73242 |   861   (1)|   2279K|00:00:04.34 |   83885 |      0 |      0 |
-------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   2 - access("ITEM_1"="T2"."REFINDIVIDU")
   4 - access("T1"."REFDOSS"=:REFDOS AND "T1"."REFTYPE"='DB')
   5 - access("T1"."REFINDIVIDU"="T2"."REFINDIVIDU" AND "T2"."REFTYPE"='DB')
   9 - access("REFDOSS"="REFDOSS")
       filter("REFDOSS"="REFDOSS")
  10 - access("DTFIN" IS NULL)
       filter(("DTFIN" IS NULL AND (NVL("NOM",'x')='CLO' OR NVL("NOM",'x')='BAL')))



-- SE Variable ds_db_inv_party 

Plan hash value: 2253319006
------------------------------------------------------------------------------------------------------------
| Id  | Operation             | Name        | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers |
------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT      |             |      1 |        |     5 (100)|      1 |00:00:36.24 |    3240K|
|   1 |  SORT AGGREGATE       |             |      1 |      1 |            |      1 |00:00:36.24 |    3240K|
|   2 |   NESTED LOOPS        |             |      1 |      1 |     2   (0)|      0 |00:00:36.24 |    3240K|
|*  3 |    INDEX RANGE SCAN   | INT_REFDOSS |      1 |      1 |     1   (0)|      0 |00:00:36.24 |    3240K|
|   4 |     NESTED LOOPS SEMI |             |      7 |      2 |     3   (0)|      7 |00:00:36.24 |    3240K|
|   5 |      NESTED LOOPS     |             |      7 |      2 |     2   (0)|   6988K|00:00:21.91 |     398K|
|*  6 |       INDEX RANGE SCAN| INT_REFDOSS |      7 |      1 |     1   (0)|      7 |00:00:00.01 |      17 |
|*  7 |       INDEX SKIP SCAN | INT_REFDOSS |      7 |      2 |     1   (0)|   6988K|00:00:20.46 |     398K|
|*  8 |      INDEX RANGE SCAN | INT_REFDOSS |   6988K|    256K|     1   (0)|      7 |00:00:10.71 |    2842K|
|*  9 |    INDEX RANGE SCAN   | DOM_TYPVAL  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   3 - access("T"."REFDOSS"=:REFDOS)
       filter( IS NULL)
   6 - access("T1"."REFDOSS"=:REFDOS AND "T1"."REFTYPE"='DB')
   7 - access("REFTYPE"=:B1)
       filter(("REFTYPE"=:B1 AND "REFDOSS"<>:REFDOS))
   8 - access("REFDOSS"="T2"."REFDOSS" AND "T2"."REFTYPE"='DB' AND
              "T1"."REFINDIVIDU"="T2"."REFINDIVIDU")
       filter(("T1"."REFDOSS"<>"T2"."REFDOSS" AND "T2"."REFDOSS"<>:REFDOS))
   9 - access("T"."REFTYPE"="V"."VALEUR" AND "V"."TYPE"='INV_PRTY_ADDITION')
       filter("V"."VALEUR" IS NOT NULL) 

*/
/********************************OLD Metrics***************************************/

/********************************New SQL*******************************************/

-- SE Variable ds_DB_act_cases

select count(*)
  from t_intervenants t1, 
       t_intervenants t2
 where t1.reftype = 'DB'
   and t2.reftype = 'DB'
   and t1.refdoss = :refdos
   and t1.refindividu = t2.refindividu
   and not exists ( select 1
                      from t_filiere tf,
                           t_intervenants ti
                     where tf.refdoss = ti.refdoss
                       and ti.refindividu = t1.refindividu
                       and tf.nom in ('CLO', 'BAL')
                       and tf.dtfin is null )
   and rownum = 1;


-- SE Variable ds_db_inv_party 

select count(*)
  from t_intervenants t, 
       v_domaine v
 where t.refdoss = :REFDOS
   and t.reftype = v.valeur
   and v.type = 'INV_PRTY_ADDITION'
   and not exists ( select 1
                      from t_intervenants ti,
                           t_intervenants t1, 
                           t_intervenants t2
                     where ti.reftype = t.reftype
                       and ti.refdoss = t2.refdoss
                       and t1.refdoss <> t2.refdoss
                       and t1.reftype = 'DB'
                       and t2.reftype = 'DB'
                       and t1.refdoss = t.refdoss
                       and t1.refindividu = t2.refindividu );

/********************************New SQL*******************************************/
/********************************New Metrics***************************************/
/*
-- SE Variable ds_DB_act_cases

Plan hash value: 10480278
-----------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                 | Name           | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers |
-----------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                          |                |      1 |        |     4 (100)|      1 |00:00:00.01 |      11 |
|   1 |  SORT AGGREGATE                           |                |      1 |      1 |            |      1 |00:00:00.01 |      11 |
|*  2 |   COUNT STOPKEY                           |                |      1 |        |            |      0 |00:00:00.01 |      11 |
|   3 |    NESTED LOOPS                           |                |      1 |      1 |     4   (0)|      0 |00:00:00.01 |      11 |
|   4 |     NESTED LOOPS ANTI                     |                |      1 |      1 |     3   (0)|      0 |00:00:00.01 |      11 |
|*  5 |      INDEX RANGE SCAN                     | INT_REFDOSS    |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |
|   6 |      VIEW PUSHED PREDICATE                | VW_SQ_1        |      1 |      1 |     2   (0)|      1 |00:00:00.01 |       8 |
|   7 |       NESTED LOOPS SEMI                   |                |      1 |      2 |     2   (0)|      1 |00:00:00.01 |       8 |
|*  8 |        INDEX RANGE SCAN                   | INT_INDIV      |      1 |      8 |     1   (0)|      1 |00:00:00.01 |       4 |
|*  9 |        TABLE ACCESS BY INDEX ROWID BATCHED| T_FILIERE      |      1 |  73754 |     1   (0)|      1 |00:00:00.01 |       4 |
|* 10 |         INDEX RANGE SCAN                  | T_FIL_DTFINDEB |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |
|* 11 |     INDEX RANGE SCAN                      | INT_INDIV      |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
-----------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   2 - filter(ROWNUM=1)
   5 - access("T1"."REFDOSS"=:REFDOS AND "T1"."REFTYPE"='DB')
   8 - access("TI"."REFINDIVIDU"="T1"."REFINDIVIDU")
   9 - filter(("TF"."NOM"='BAL' OR "TF"."NOM"='CLO'))
  10 - access("TF"."REFDOSS"="TI"."REFDOSS" AND "TF"."DTFIN" IS NULL)
  11 - access("T1"."REFINDIVIDU"="T2"."REFINDIVIDU" AND "T2"."REFTYPE"='DB')


-- SE Variable ds_db_inv_party

Plan hash value: 3192440637
---------------------------------------------------------------------------------------------------------------------
| Id  | Operation             | Name        | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  |
---------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT      |             |      1 |        |     5 (100)|      1 |00:00:00.01 |      67 |      1 |
|   1 |  SORT AGGREGATE       |             |      1 |      1 |            |      1 |00:00:00.01 |      67 |      1 |
|   2 |   NESTED LOOPS        |             |      1 |      1 |     2   (0)|      0 |00:00:00.01 |      67 |      1 |
|*  3 |    INDEX RANGE SCAN   | INT_REFDOSS |      1 |      1 |     1   (0)|      0 |00:00:00.01 |      67 |      1 |
|   4 |     NESTED LOOPS SEMI |             |      7 |      2 |     3   (0)|      7 |00:00:00.01 |      64 |      1 |
|   5 |      NESTED LOOPS     |             |      7 |      2 |     2   (0)|      9 |00:00:00.01 |      39 |      1 |
|*  6 |       INDEX RANGE SCAN| INT_REFDOSS |      7 |      1 |     1   (0)|      7 |00:00:00.01 |      17 |      0 |
|*  7 |       INDEX RANGE SCAN| INT_INDIV   |      7 |     18 |     1   (0)|      9 |00:00:00.01 |      22 |      1 |
|*  8 |      INDEX RANGE SCAN | INT_REFDOSS |      9 |    256K|     1   (0)|      7 |00:00:00.01 |      25 |      0 |
|*  9 |    INDEX RANGE SCAN   | DOM_TYPVAL  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
---------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   3 - access("T"."REFDOSS"=:REFDOS)
       filter( IS NULL)
   6 - access("T1"."REFDOSS"=:B1 AND "T1"."REFTYPE"='DB')
   7 - access("T1"."REFINDIVIDU"="T2"."REFINDIVIDU" AND "T2"."REFTYPE"='DB')
       filter(("T1"."REFDOSS"<>"T2"."REFDOSS" AND "T2"."REFDOSS"<>:B1))
   8 - access("TI"."REFDOSS"="T2"."REFDOSS" AND "TI"."REFTYPE"=:B1)
       filter("TI"."REFDOSS"<>:B1)
   9 - access("T"."REFTYPE"="V"."VALEUR" AND "V"."TYPE"='INV_PRTY_ADDITION')
       filter("V"."VALEUR" IS NOT NULL) 
*/
/********************************New Metrics***************************************/

/********************************Index statistics**********************************/

/********************************Other SQLs****************************************/          
/*

*/ 
/********************************Other SQLs****************************************/              
