/********************************************************************************
*********       E-mail subject: IMB//iMX ProdRel4 - UATR
*********             Instance: UATR
*********          Description: 
Problem:

Slow query on UATR from SQL*Plus module.

Analysis:

On 04/07/2023 the provided query started and on 05/07/2023 it has not finished yet.
The problem was that on 25/06/2023 when the statistics were collected the table NAM_ECR_COMPTA was empty.
It caused the SQL 8sqzjfwxxunhz from opcode_reclassindiv.pck to use inappropriate execution plan.

Suggestion:

Please modify the query as it is shown in the new SQL.

*********               SQL_ID: 8sqzjfwxxunhz
*********      Program/Package: opcode_reclassindiv.pck
*********              Request: Dimitare Ivanov
*********               Author: Dimitar Dimitrov
********* Received e-mail date: 05/07/2023
*********      Resolution date: 05/07/2023
*********  Trace old file here: \\epox\specifs\performance\tmp\
*********  Trace new file here:
***********************************************************************************/

/********************************OLD SQL*******************************************/
SELECT 'nam_ecr_compta' AS TABLE_NAME,
       NAM.REFER AS REFER,
       NAM.REFFACTOR AS REFFACTOR,
       NAM.COMPTE AS COMPTE,
       NAM.EXTREF38 AS ACCOUNT,
       NAM.EXTREF1 AS REFINDIVIDU,
       NAM.EXTREF2 AS IMP_STAGE,
       NAM.EXTREF5 AS FINREP_ACC,
       NAM.EXTREF39 AS FINREP_ACC_PARAM,
       NAM.REFDOSS AS REFDOSS,
       DECODE(NAM.SENS, 'c', -1, 1) * MONTANT AS MONTANT,
       NAM.DEVISE AS DEVISE,
       DECODE(NAM.SENS, 'c', -1, 1) * MONTANT_MVT AS MONTANT_MVT,
       NAM.EL2 AS DEVISE_MVT,
       NAM.EXTREF11 AS VERRKONT
  FROM NAM_ECR_COMPTA NAM
 WHERE NAM.FG_GL_ACC_RECLASSIFIC = 'O'
   AND NAM.EXTREF38 IS NOT NULL
   AND NAM.EXTREF39 IS NOT NULL
   AND NAM.REF_OPCODE_IND_BATCH IS NULL
   AND NAM.REFDOSS = :B1
UNION
SELECT 'nam_ecr_compta_bak' AS TABLE_NAME,
       NAM.REFER AS REFER,
       NAM.REFFACTOR AS REFFACTOR,
       NAM.COMPTE AS COMPTE,
       NAM.EXTREF38 AS ACCOUNT,
       NAM.EXTREF1 AS REFINDIVIDU,
       NAM.EXTREF2 AS IMP_STAGE,
       NAM.EXTREF5 AS FINREP_ACC,
       NAM.EXTREF39 AS FINREP_ACC_PARAM,
       NAM.REFDOSS AS REFDOSS,
       DECODE(NAM.SENS, 'c', -1, 1) * MONTANT AS MONTANT,
       NAM.DEVISE AS DEVISE,
       DECODE(NAM.SENS, 'c', -1, 1) * MONTANT_MVT AS MONTANT_MVT,
       NAM.EL2 AS DEVISE_MVT,
       NAM.EXTREF11 AS VERRKONT
  FROM NAM_ECR_COMPTA_BAK NAM
 WHERE NAM.FG_GL_ACC_RECLASSIFIC = 'O'
   AND NAM.EXTREF38 IS NOT NULL
   AND NAM.EXTREF39 IS NOT NULL
   AND NAM.REF_OPCODE_IND_BATCH IS NULL
   AND NAM.REFDOSS = :B1
 ORDER BY REFER;

/********************************OLD SQL*******************************************/
/********************************OLD Metrics***************************************/
/*
 SQL_ID              SQL_PLAN_HASH_VALUE SQL_PLAN_LINE_ID SQL_PLAN_OPERATION             SQL_PLAN_OPTIONS                   ACTIVE
------------------- ------------------- ---------------- ------------------------------ ------------------------------ ----------
8sqzjfwxxunhz                3733742293                3 TABLE ACCESS                   BY INDEX ROWID BATCHED               4836
8sqzjfwxxunhz                3733742293                4 INDEX                          RANGE SCAN                            353
8sqzjfwxxunhz                3733742293                5 TABLE ACCESS                   BY INDEX ROWID BATCHED                 83
8sqzjfwxxunhz                3733742293                6 INDEX                          RANGE SCAN                             15
8sqzjfwxxunhz                3733742293                  SELECT STATEMENT                                                       1
8sqzjfwxxunhz                3733742293                2 UNION-ALL                                                              1


SQL_ID              MODULE               ELAPSED MAX_WAIT        GETS      READS       ROWS   ELAP/EXEC  GETS/EXEC READS/EXEC  ROWS/EXEC       EXEC PLAN_HASH_VALUE
------------------- ----------------- ---------- --------- ---------- ---------- ---------- ----------- ---------- ---------- ---------- ---------- ---------------
8sqzjfwxxunhz       SQL*Plus               54121 94% cpu    727443433   10630679    3258396         .81   10913.07     159.48      48.88      66658      3733742293




BLOCKS   NUM_ROWS AVG_ROW_LEN   MB_AS_IS   MB_TO_BE LAST_ANALYZED       SAMPLE_SIZE    INSERTS    UPDATES    DELETES PERC_MODIFIED
---------- ---------- ----------- ---------- ---------- ------------------- ----------- ---------- ---------- ---------- -------------
     42737          0           0        608          0 2023/06/25 11:52:01           0    2256894    3365764    1507693     713035100

Plan hash value: 3733742293
---------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                             | Name                         | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers |
---------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                      |                              |      1 |        |   452 (100)|      2 |00:00:00.74 |   79352 |
|   1 |  SORT UNIQUE                          |                              |      1 |      2 |   451   (1)|      2 |00:00:00.74 |   79352 |
|   2 |   UNION-ALL                           |                              |      1 |        |            |      2 |00:00:00.74 |   79352 |
|*  3 |    TABLE ACCESS BY INDEX ROWID BATCHED| NAM_ECR_COMPTA               |      1 |      1 |     0   (0)|      0 |00:00:00.74 |   79277 |
|*  4 |     INDEX RANGE SCAN                  | NAM_REF_OPCODE_IND_BATCH_IDX |      1 |      1 |     0   (0)|    504K|00:00:00.07 |    2001 |
|*  5 |    TABLE ACCESS BY INDEX ROWID BATCHED| NAM_ECR_COMPTA_BAK           |      1 |      1 |   451   (1)|      2 |00:00:00.01 |      75 |
|*  6 |     INDEX RANGE SCAN                  | NAMECRDOS_BAK                |      1 |    447 |     6   (0)|     76 |00:00:00.01 |       4 |
---------------------------------------------------------------------------------------------------------------------------------------------

 

Predicate Information (identified by operation id):
---------------------------------------------------
 3 - filter(("NAM"."EXTREF38" IS NOT NULL AND "NAM"."EXTREF39" IS NOT NULL AND "NAM"."FG_GL_ACC_RECLASSIFIC"='O' AND
              "NAM"."REFDOSS"=:B1))
   4 - access("NAM"."REF_OPCODE_IND_BATCH" IS NULL)
   5 - filter(("NAM"."EXTREF39" IS NOT NULL AND "NAM"."EXTREF38" IS NOT NULL AND "NAM"."FG_GL_ACC_RECLASSIFIC"='O' AND
              "NAM"."REF_OPCODE_IND_BATCH" IS NULL))
   6 - access("NAM"."REFDOSS"=:B1)



*/
/********************************OLD Metrics***************************************/

/********************************New SQL*******************************************/
SELECT /*+ index(NAM NAMECRDOS) */
	     'nam_ecr_compta' AS TABLE_NAME,
       NAM.REFER AS REFER,
       NAM.REFFACTOR AS REFFACTOR,
       NAM.COMPTE AS COMPTE,
       NAM.EXTREF38 AS ACCOUNT,
       NAM.EXTREF1 AS REFINDIVIDU,
       NAM.EXTREF2 AS IMP_STAGE,
       NAM.EXTREF5 AS FINREP_ACC,
       NAM.EXTREF39 AS FINREP_ACC_PARAM,
       NAM.REFDOSS AS REFDOSS,
       DECODE(NAM.SENS, 'c', -1, 1) * MONTANT AS MONTANT,
       NAM.DEVISE AS DEVISE,
       DECODE(NAM.SENS, 'c', -1, 1) * MONTANT_MVT AS MONTANT_MVT,
       NAM.EL2 AS DEVISE_MVT,
       NAM.EXTREF11 AS VERRKONT
  FROM NAM_ECR_COMPTA NAM
 WHERE NAM.FG_GL_ACC_RECLASSIFIC = 'O'
   AND NAM.EXTREF38 IS NOT NULL
   AND NAM.EXTREF39 IS NOT NULL
   AND NAM.REF_OPCODE_IND_BATCH IS NULL
   AND NAM.REFDOSS = :B1
UNION
SELECT /*+ index(NAM NAMECRDOS_BAK) */
	     'nam_ecr_compta_bak' AS TABLE_NAME,
       NAM.REFER AS REFER,
       NAM.REFFACTOR AS REFFACTOR,
       NAM.COMPTE AS COMPTE,
       NAM.EXTREF38 AS ACCOUNT,
       NAM.EXTREF1 AS REFINDIVIDU,
       NAM.EXTREF2 AS IMP_STAGE,
       NAM.EXTREF5 AS FINREP_ACC,
       NAM.EXTREF39 AS FINREP_ACC_PARAM,
       NAM.REFDOSS AS REFDOSS,
       DECODE(NAM.SENS, 'c', -1, 1) * MONTANT AS MONTANT,
       NAM.DEVISE AS DEVISE,
       DECODE(NAM.SENS, 'c', -1, 1) * MONTANT_MVT AS MONTANT_MVT,
       NAM.EL2 AS DEVISE_MVT,
       NAM.EXTREF11 AS VERRKONT
  FROM NAM_ECR_COMPTA_BAK NAM
 WHERE NAM.FG_GL_ACC_RECLASSIFIC = 'O'
   AND NAM.EXTREF38 IS NOT NULL
   AND NAM.EXTREF39 IS NOT NULL
   AND NAM.REF_OPCODE_IND_BATCH IS NULL
   AND NAM.REFDOSS = :B1
 ORDER BY REFER;

/********************************New SQL*******************************************/
/********************************New Metrics***************************************/
/*
Plan hash value: 511026944
-----------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                             | Name               | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers |
-----------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                      |                    |      1 |        |   454 (100)|      2 |00:00:00.01 |      83 |
|   1 |  SORT UNIQUE                          |                    |      1 |      2 |   453   (1)|      2 |00:00:00.01 |      83 |
|   2 |   UNION-ALL                           |                    |      1 |        |            |      2 |00:00:00.01 |      83 |
|*  3 |    TABLE ACCESS BY INDEX ROWID BATCHED| NAM_ECR_COMPTA     |      1 |      1 |     2   (0)|      0 |00:00:00.01 |       8 |
|*  4 |     INDEX RANGE SCAN                  | NAMECRDOS          |      1 |      1 |     2   (0)|     10 |00:00:00.01 |       3 |
|*  5 |    TABLE ACCESS BY INDEX ROWID BATCHED| NAM_ECR_COMPTA_BAK |      1 |      1 |   451   (1)|      2 |00:00:00.01 |      75 |
|*  6 |     INDEX RANGE SCAN                  | NAMECRDOS_BAK      |      1 |    447 |     6   (0)|     76 |00:00:00.01 |       4 |
-----------------------------------------------------------------------------------------------------------------------------------

 

Predicate Information (identified by operation id):
---------------------------------------------------
 3 - filter(("NAM"."EXTREF38" IS NOT NULL AND "NAM"."EXTREF39" IS NOT NULL AND "NAM"."FG_GL_ACC_RECLASSIFIC"='O' AND
              "NAM"."REF_OPCODE_IND_BATCH"||'' IS NULL))
   4 - access("NAM"."REFDOSS"=:B1)
   5 - filter(("NAM"."EXTREF39" IS NOT NULL AND "NAM"."EXTREF38" IS NOT NULL AND "NAM"."FG_GL_ACC_RECLASSIFIC"='O' AND
              "NAM"."REF_OPCODE_IND_BATCH" IS NULL))
   6 - access("NAM"."REFDOSS"=:B1)
*/
/********************************New Metrics***************************************/

/********************************Index statistics**********************************/

/********************************Other SQLs****************************************/          
/*

*/ 
/********************************Other SQLs****************************************/              
