/********************************************************************************
*********       E-mail subject: IMBWEB-7850
*********             Instance: PROD
*********          Description: 
Problem:
SQL gcjs8q1bp6u01 was the TOP SQL for E_NAMCOL.

Analysis:
We analyzed for module E_NAMCOL on IMB PROD for the period between 14:25 and 14:45 on 22/05/2024 and the TOP SQL was gcjs8q1bp6u01.
As you can see on the OLD Metrics section below, this SQL selects all rows from table nam_collecte where etat = 'RCI' ( which are over 1.2 million rows ), 
then the condition nc.fg_non_bank_payment IS NULL makes them around 1.1 million and finally after the distinct, the query returns ~ 100k rows. We can't do much from performance point of view here. 
The question here is why this SQL selects 100k rows?
Could you please check from business point of view what is the purpose from selecting so much rows?


Suggestion:
Please check what is the purpose of SQL gcjs8q1bp6u01 to select over 100k rows.

*********               SQL_ID: gcjs8q1bp6u01
*********      Program/Package: 
*********              Request: Dimitare Ivanov
*********               Author: Dimitar Dimitrov
********* Received e-mail date: 23/05/2024
*********      Resolution date: 27/05/2024
*********  Trace old file here: \\epox\specifs\performance\tmp\
*********  Trace new file here:
***********************************************************************************/

/********************************OLD SQL*******************************************/

SELECT DTLOT,
       DTLOT_DESC,
       CREATEUR,
       TOTMONT,
       ANCSOLDE,
       NUMCPT,
       REFFACTOR,
       REFCPTBQ
  FROM (SELECT DISTINCT gl.dtlot     dtlot,
                        gl.dtlot     dtlot_desc,
                        gl.traite,
                        gl.valide,
                        gl.createur,
                        gl.totmont,
                        gl.ancsolde,
                        gl.numcpt,
                        gl.reffactor,
                        gl.refcptbq
          FROM g_lotcoll gl, 
               nam_collecte nc
         WHERE gl.dtlot = nc.dtlot
           AND nc.etat = 'RCI'
           AND nc.fg_non_bank_payment IS NULL) g
 order by substr(dtlot, 1, 3),
          to_date(substr(dtlot, -8), 'dd/mm/yy') desc,
          decode(length(dtlot), 15, to_number(substr(dtlot, 5, 2)));  
/********************************OLD SQL*******************************************/
/********************************OLD Metrics***************************************/
/*

MODULE                           SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL             PERC
-------------------------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
E_NAMCOL                         gcjs8q1bp6u01 2006023521       1610      41080                      2024/05/22 14:25:14  2024/05/22 14:43:03          92                    4 +000000000 00:17:48.160 84%


INSTANCE_NUMBER SQL_ID            ELAPSED MAX_WAIT_ON     PC_OF  WAIT_TIME            GETS      READS       ROWS  ELAP/EXEC       GETS/EXEC READS/EXEC  ROWS/EXEC       EXEC PLAN_HASH_VALUE
--------------- ------------- ----------- --------------- ----- ---------- --------------- ---------- ---------- ---------- --------------- ---------- ---------- ---------- ---------------
              2 20cft2g7xk6sj          10 CPU             100%   10.194157             102          0          1      10.44             102          0          1          1      2969633590

Plan hash value: 2006023521
----------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                  | Name            | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  |
----------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                           |                 |      1 |        | 16614 (100)|    103K|00:01:00.05 |     595K|    181K|
|   1 |  SORT ORDER BY                             |                 |      1 |    109K| 16614   (1)|    103K|00:01:00.05 |     595K|    181K|
|   2 |   VIEW                                     |                 |      1 |    109K|  8864   (1)|    103K|00:00:59.80 |     595K|    181K|
|   3 |    HASH UNIQUE                             |                 |      1 |    109K|  8864   (1)|    103K|00:00:59.79 |     595K|    181K|
|   4 |     NESTED LOOPS                           |                 |      1 |    109K|  6870   (1)|    103K|00:00:59.67 |     595K|    181K|
|   5 |      NESTED LOOPS                          |                 |      1 |    110K|  6870   (1)|    103K|00:00:57.32 |     491K|    178K|
|   6 |       VIEW                                 | VW_DTP_BE596448 |      1 |    110K|  5765   (1)|    103K|00:00:56.94 |     455K|    177K|
|   7 |        HASH UNIQUE                         |                 |      1 |    110K|  5765   (1)|    103K|00:00:56.92 |     455K|    177K|
|*  8 |         TABLE ACCESS BY INDEX ROWID BATCHED| NAM_COLLECTE    |      1 |   1154K|  3096   (1)|   1184K|00:00:56.41 |     455K|    177K|
|*  9 |          INDEX SKIP SCAN                   | DTLOT_ETAT_IND  |      1 |   1228K|   100   (0)|   1231K|00:00:04.60 |    9459 |   9412 |
|* 10 |       INDEX UNIQUE SCAN                    | G_LOTCOLL_PK    |    103K|      1 |     1   (0)|    103K|00:00:00.35 |   35427 |    403 |
|  11 |      TABLE ACCESS BY INDEX ROWID           | G_LOTCOLL       |    103K|      1 |     1   (0)|    103K|00:00:02.33 |     104K|   3683 |
----------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   8 - filter("NC"."FG_NON_BANK_PAYMENT" IS NULL)
   9 - access("NC"."ETAT"='RCI')
       filter("NC"."ETAT"='RCI')
  10 - access("GL"."DTLOT"="ITEM_1")


select count(*)
  FROM nam_collecte
where etat = 'RCI'   
 
   COUNT(*)
----------
   1231147

select count(*)
  FROM nam_collecte
where etat = 'RCI'
   and fg_non_bank_payment IS NULL;
   
   
  COUNT(*)
----------
   1175984


*/
/********************************OLD Metrics***************************************/

/********************************New SQL*******************************************/

-- No chenges in the SQL text.
/********************************New SQL*******************************************/
/********************************New Metrics***************************************/
/*

*/
/********************************New Metrics***************************************/

/********************************Index statistics**********************************/

/********************************Other SQLs****************************************/          
/*

*/ 
/********************************Other SQLs****************************************/              
