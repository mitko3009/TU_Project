/********************************************************************************
*********       E-mail subject: BELFWEB-1130
*********             Instance: PROD V9
*********          Description: 
Problem:
SQL 61csu0421jcdp from SE variable anx_validate1b was considered as slow on PROD V9.

Analysis:
The main problem in this SQL was index full scan because of missing index on PROD V9.
I created test index on column reference on table prm_values to test, but still the execution plan wasn't good. I removed the nested 'in' operator and joined table g_dossier directly 
with table g_piece, than using hints I forced Oracle to start the execution from table g_dossier and with nested loop to access table g_piece.

Suggestion:
Please change the query as it is shown in the New SQL section below.

*********               SQL_ID: 61csu0421jcdp -> SE Variable anx_validate1b
*********      Program/Package: 
*********              Request: Valeriya Borisova
*********               Author: Dimitar Dimitrov
********* Received e-mail date: 26/06/2024
*********      Resolution date: 27/06/2024
*********  Trace old file here: \\epox\specifs\performance\tmp\
*********  Trace new file here:
***********************************************************************************/

/********************************OLD SQL*******************************************/

update prm_values
   set p_level = 'SOUS-CONTRAT'
 where reference in ( select refpiece
                        from g_piece
                       where refdoss in ( select refdoss 
                                            from g_dossier 
                                           where reflot = :refdos )
   and typpiece = 'SOUS-CONTRAT ANNEXE');
/********************************OLD SQL*******************************************/
/********************************OLD Metrics***************************************/
/*
INSTANCE_NUMBER SQL_ID            ELAPSED MAX_WAIT_ON     PC_OF  WAIT_TIME            GETS      READS       ROWS  ELAP/EXEC       GETS/EXEC READS/EXEC  ROWS/EXEC       EXEC PLAN_HASH_VALUE
--------------- ------------- ----------- --------------- ----- ---------- --------------- ---------- ---------- ---------- --------------- ---------- ---------- ---------- ---------------
              1 61csu0421jcdp        1782 IO              59%   2008.55233         6399325    6177849        910     198.02          711036  686427.67     101.11          9  1445973302
              1 61csu0421jcdp           0 CPU             100%     .007897               0          0          0        .02               0          0          0          0   0
              1 cgv1x143nv2hv         782 IO              45%    805.63368         3844630    3473962         13      60.13          295741  267227.85          1         13  1286998476
              1 cgv1x143nv2hv           0 CPU             100%     .018683               0          0          0        .03               0          0          0          0   0


SQL_ID        SQL_PLAN_HASH_VALUE SQL_PLAN_LINE_ID SQL_PLAN_OPERATION             SQL_PLAN_OPTIONS                   ACTIVE
------------- ------------------- ---------------- ------------------------------ ------------------------------ ----------
cgv1x143nv2hv          1286998476                4 INDEX                          SKIP SCAN                             114
cgv1x143nv2hv          1286998476                3 TABLE ACCESS                   BY INDEX ROWID BATCHED                  1
61csu0421jcdp          1445973302                9 INDEX                          FULL SCAN                             230


Plan hash value: 1445973302
--------------------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                | Name                        | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  |
--------------------------------------------------------------------------------------------------------------------------------------------------------
|   0 | UPDATE STATEMENT                         |                             |      1 |        |  4328 (100)|      0 |00:00:00.01 |     111 |     74 |
|   1 |  UPDATE                                  | PRM_VALUES                  |      1 |        |            |      0 |00:00:00.01 |     111 |     74 |
|   2 |   NESTED LOOPS                           |                             |      1 |     20 |  4328   (1)|      0 |00:00:00.01 |     111 |     74 |
|   3 |    VIEW                                  | VW_NSO_1                    |      1 |      1 |     2   (0)|      0 |00:00:00.01 |     111 |     74 |
|   4 |     SORT UNIQUE                          |                             |      1 |      1 |            |      0 |00:00:00.01 |     111 |     74 |
|   5 |      NESTED LOOPS SEMI                   |                             |      1 |      1 |     2   (0)|      0 |00:00:00.01 |     111 |     74 |
|*  6 |       TABLE ACCESS BY INDEX ROWID BATCHED| G_PIECE                     |      1 |     24 |     1   (0)|     36 |00:00:00.01 |      37 |     36 |
|*  7 |        INDEX RANGE SCAN                  | PIECE_TYP_MT43_IDX          |      1 |     27 |     1   (0)|     36 |00:00:00.01 |       3 |      2 |
|*  8 |       INDEX RANGE SCAN                   | DOS_REFDOSS_REFLOT_IDX      |     36 |      1 |     1   (0)|      0 |00:00:00.01 |      74 |     38 |
|*  9 |    INDEX FULL SCAN                       | AK_UNQ_PRM_VAL_KEY_PRM_VALU |      0 |     20 |  4325   (1)|      0 |00:00:00.01 |       0 |      0 |
--------------------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   6 - filter("REFDOSS" IS NOT NULL)
   7 - access("TYPPIECE"='SOUS-CONTRAT ANNEXE')
   8 - access("REFDOSS"="REFDOSS" AND "REFLOT"=:REFDOS)
   9 - access("REFERENCE"="REFPIECE")
       filter("REFERENCE"="REFPIECE")
*/
/********************************OLD Metrics***************************************/

/********************************New SQL*******************************************/

update prm_values pv
   set p_level = 'SOUS-CONTRAT'
 where reference in ( select /*+ leading(gd gp) index(gd DOSS_LOT) use_nl(gp)*/
                             gp.refpiece
                        from g_piece gp,
                             g_dossier gd
                       where gp.refdoss = gd.refdoss
                         and reflot = :refdos
                         and typpiece = 'SOUS-CONTRAT ANNEXE' );



-- Variant with Merge statement

MERGE INTO prm_values pv
      USING ( SELECT /*+ leading(gd) index(gd DOSS_LOT) use_nl(gp)*/
                     refpiece
                FROM g_piece gp,
                     g_dossier gd
               where gp.refdoss = gd.refdoss
                 and reflot = :refdos
                 and typpiece = 'SOUS-CONTRAT ANNEXE' ) rp
         ON ( pv.reference = rp.refpiece )
 WHEN MATCHED THEN
	    UPDATE SET p_level = 'SOUS-CONTRAT';
/********************************New SQL*******************************************/
/********************************New Metrics***************************************/
/*

Plan hash value: 3033533451
-------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                 | Name          | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  |
-------------------------------------------------------------------------------------------------------------------------------------------
|   0 | UPDATE STATEMENT                          |               |      1 |        |    10 (100)|      0 |00:00:00.01 |       8 |      4 |
|   1 |  UPDATE                                   | PRM_VALUES    |      1 |        |            |      0 |00:00:00.01 |       8 |      4 |
|   2 |   NESTED LOOPS                            |               |      1 |     20 |    10  (10)|      0 |00:00:00.01 |       8 |      4 |
|   3 |    VIEW                                   | VW_NSO_1      |      1 |      1 |     8   (0)|      0 |00:00:00.01 |       8 |      4 |
|   4 |     SORT UNIQUE                           |               |      1 |      1 |            |      0 |00:00:00.01 |       8 |      4 |
|   5 |      NESTED LOOPS                         |               |      1 |      1 |     8   (0)|      0 |00:00:00.01 |       8 |      4 |
|   6 |       NESTED LOOPS                        |               |      1 |    166 |     8   (0)|      0 |00:00:00.01 |       8 |      4 |
|   7 |        TABLE ACCESS BY INDEX ROWID BATCHED| G_DOSSIER     |      1 |    166 |     1   (0)|      1 |00:00:00.01 |       4 |      0 |
|*  8 |         INDEX RANGE SCAN                  | DOSS_LOT      |      1 |    166 |     1   (0)|      1 |00:00:00.01 |       3 |      0 |
|*  9 |        INDEX RANGE SCAN                   | PIE_REFDOSS   |      1 |      1 |     1   (0)|      0 |00:00:00.01 |       4 |      4 |
|  10 |       TABLE ACCESS BY INDEX ROWID         | G_PIECE       |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 11 |    INDEX RANGE SCAN                       | TEST_DD_INDEX |      0 |     20 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
-------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   8 - access("REFLOT"=:REFDOS)
   9 - access("GP"."REFDOSS"="GD"."REFDOSS" AND "TYPPIECE"='SOUS-CONTRAT ANNEXE')
       filter("GP"."REFDOSS" IS NOT NULL)
  11 - access("REFERENCE"="REFPIECE")
*/
/********************************New Metrics***************************************/

/********************************Index statistics**********************************/

/********************************Other SQLs****************************************/          
/*

*/ 
/********************************Other SQLs****************************************/              
