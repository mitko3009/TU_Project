/********************************************************************************
*********       E-mail subject: IMBWEB-8085
*********             Instance: PROD
*********          Description: 
Problem:
Long loading time in the screen ec_cf_supplier_cash_flow when clicking on the amount to see accounts payable for the day - Xnet Version PROD.

Analysis:
We watched the attached video and checked the work of module EXTRANET for the time period in the video. The TOP SQL for this module was 4nnsa9v6pmy09, which was 
responsible for 81% fo the time. We found that the query is searching for all factures and also table " t_intervenants t " is unnecessary joined, so after confirmation, 
table " t_intervenants t " was removed from the query and condition " AND ge.actif = 'O' " was added to the query. Also, we added some hints to force Oracle to make a good execution plan.

Suggestion:
Please change the query as it is shown in the New SQL section below.

*********               SQL_ID: 4nnsa9v6pmy09
*********      Program/Package: 
*********              Request: Karin Steiner 
*********               Author: Dimitar Dimitrov
********* Received e-mail date: 11/10/2024
*********      Resolution date: 15/10/2024
*********  Trace old file here: \\epox\specifs\performance\tmp\
*********  Trace new file here:
***********************************************************************************/

/********************************OLD SQL*******************************************/

VAR B1 VARCHAR2(32);
EXEC :B1 := 'AN';
VAR B2 VARCHAR2(32);
EXEC :B2 := '0001010293';
VAR B3 VARCHAR2(32);
EXEC :B3 := '06/10/2024';


SELECT cnt.refdoss AS contractId,
       dcmp.refdoss AS decompteId,
       cmp.refdoss AS compteId,
       'Invoice' AS doc_type,
       ge.refext AS doc_ref,
       ge.montant_dos AS doc_value,
       cmp.devise currency,
       (SELECT NVL(valeur_trad, valeur)
          FROM v_tdomaine
         WHERE type = 'STATUS_DOC'
           AND langue = :B1
           AND ABREV = (CASE
                 WHEN ge.matched_amt = ge.montant_dos THEN
                  'P'
                 WHEN ge.matched_amt > 0 AND ge.matched_amt <> ge.montant_dos THEN
                  'PP'
                 ELSE
                  'NP'
               END)) doc_status,
       TRIM(gi.nom || ' ' || gi.prenom) AS doc_person
  FROM g_dossier      cmp,
       g_dossier      dcmp,
       g_dossier      cnt,
       t_intervenants ti,
       g_individu     gi,
       g_elemfi       ge,
       g_piece        gp,
       t_intervenants t
 WHERE cmp.pieceinit = 'COMPTE'
   AND cmp.reflot = dcmp.refdoss
   AND dcmp.reflot = cnt.refdoss
   AND cnt.refdoss = :B2
   AND ti.refdoss = cmp.refdoss
   AND ti.reftype = 'DB'
   AND gi.refindividu = ti.refindividu
   AND ge.refdoss = cmp.refdoss
   AND ge.type = 'FACTURE'
   AND gp.refdoss = cmp.refdoss
   AND gp.refpiece = ge.refpiece2
   AND gp.st09 NOT IN ('C', 'RT')
   AND ge.dtannul IS NULL
   AND gp.typpiece = 'FACTURE'
   AND to_char(TRUNC(GREATEST(NVL(ge.dtdebut_dt,
                                  to_date('01/01/1970', 'dd/mm/yyyy')),
                              NVL(gp.dt13_dt,
                                  to_date('01/01/1970', 'dd/mm/yyyy')),
                              NVL(gp.dt14_dt,
                                  to_date('01/01/1970', 'dd/mm/yyyy'))))) =
       to_char(to_date(:B3, 'dd/mm/yyyy'))
   AND t.refdoss = cmp.refdoss
   AND t.reftype = 'DB';
/********************************OLD SQL*******************************************/
/********************************OLD Metrics***************************************/
/*
MODULE                           PROGRAM                                            CLIENT_ID       SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                    ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- -------------------------------------------------- --------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
EXTRANET                         EXTRANET                                                                                                                               2024/10/11 15:40:37  2024/10/11 15:47:34      180             16885848 +000000000 00:06:56.779 100%




MODULE                           PROGRAM                                            CLIENT_ID       SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                    ACTIVE    NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- -------------------------------------------------- --------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
EXTRANET                         EXTRANET                                           J100Y6A                                        1598      31598 cell single block ph 2024/10/11 15:43:56  2024/10/11 15:46:28         130                    1 +000000000 00:02:32.162 83%
EXTRANET                         EXTRANET                                           J100Y6A                                                        ON CPU               2024/10/11 15:43:54  2024/10/11 15:46:33          24                   65 +000000000 00:02:39.169 15%
EXTRANET                         EXTRANET                                           J100Y6A         4nnsa9v6pmy09  344222875       1598      31598 cell multiblock phys 2024/10/11 15:45:42  2024/10/11 15:45:42           1                    1 +000000000 00:00:00.000 1%
EXTRANET                         EXTRANET                                           J100Y6A         4nnsa9v6pmy09  344222875       1598      31598 cell list of blocks  2024/10/11 15:45:21  2024/10/11 15:45:21           1                    1 +000000000 00:00:00.000 1%
E_ELOGIN                         frmweb                                             J100Y6A         4x67cddkafzqq 3463374839       1908      56233 ON CPU               2024/10/11 15:43:37  2024/10/11 15:43:37           1                      +000000000 00:00:00.000 1%


MODULE                           PROGRAM                                            CLIENT_ID       SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- -------------------------------------------------- --------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
EXTRANET                         EXTRANET                                           J100Y6A         4nnsa9v6pmy09  344222875       1598      31598                      2024/10/11 15:44:04  2024/10/11 15:46:29         146                    1 +000000000 00:02:25.155 81%
EXTRANET                         EXTRANET                                           J100Y6A         bgcnhzp4nknnb  652649025       1598      31598                      2024/10/11 15:43:55  2024/10/11 15:43:59           5                    1 +000000000 00:00:04.004 3%
EXTRANET                         EXTRANET                                           KK@AL-TRANSPORT 5qmyqqx5ju2hf 3614975587        324      15681 ON CPU               2024/10/11 15:46:36  2024/10/11 15:46:39           4                      +000000000 00:00:03.003 2%
                                                                                    .AT

EXTRANET                         EXTRANET                                           J100Y6A         g8vtptxpkm26y 3790308890       2182       7831 ON CPU               2024/10/11 15:46:31  2024/10/11 15:46:33           3                    1 +000000000 00:00:02.002 2%
EXTRANET                         EXTRANET                                                                                  0                                            2024/10/11 15:40:37  2024/10/11 15:46:11           2                      +000000000 00:05:33.807 1%
EXTRANET                         EXTRANET                                           KK@AL-TRANSPORT 7qkxdq3vgrps5 3971698126        324      15681 ON CPU               2024/10/11 15:46:34  2024/10/11 15:46:34           1                      +000000000 00:00:00.000 1%


INSTANCE_NUMBER SQL_ID            ELAPSED MAX_WAIT_ON     PC_OF  WAIT_TIME            GETS      READS       ROWS  ELAP/EXEC       GETS/EXEC READS/EXEC  ROWS/EXEC       EXEC PLAN_HASH_VALUE
--------------- ------------- ----------- --------------- ----- ---------- --------------- ---------- ---------- ---------- --------------- ---------- ---------- ---------- ---------------
              1 4nnsa9v6pmy09          64 IO              77%     71.94379          274423     192762         50      63.68          274423     192762         50          1       344222875


SQL_ID        SQL_PLAN_HASH_VALUE SQL_PLAN_LINE_ID SQL_PLAN_OPERATION             SQL_PLAN_OPTIONS                   ACTIVE
------------- ------------------- ---------------- ------------------------------ ------------------------------ ----------
4nnsa9v6pmy09           344222875              129 TABLE ACCESS                   BY INDEX ROWID BATCHED                 15


SQL_ID           SNAP_ID INSTANCE_NUMBER NAME                   POSITION DUP_POSITION DATATYPE_STRING      VALUE_STRING                             INTERVAL
------------- ---------- --------------- -------------------- ---------- ------------ -------------------- ---------------------------------------- -----------------------
4nnsa9v6pmy09     136963               1 :1                            1              VARCHAR2(32)         AN                                       2024/10/11 15
4nnsa9v6pmy09     136963               1 :2                            2              VARCHAR2(128)        0001010293                               2024/10/11 15
4nnsa9v6pmy09     136963               1 :3                            3              VARCHAR2(128)        06/10/2024                               2024/10/11 15


Plan hash value: 344222875
-----------------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                               | Name                      | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  |
-----------------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                        |                           |      1 |        |   930 (100)|     88 |00:03:12.80 |     663K|    529K|
|   1 |  VIEW                                   | V_TDOMAINE                |     88 |     37 |    37   (0)|     88 |00:00:00.01 |     186 |      0 |
|   2 |   UNION-ALL                             |                           |     88 |        |            |     88 |00:00:00.01 |     186 |      0 |
|*  3 |    FILTER                               |                           |     88 |        |            |      0 |00:00:00.01 |       0 |      0 |
|   4 |     TABLE ACCESS BY INDEX ROWID BATCHED | V_DOMAINE                 |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*  5 |      INDEX RANGE SCAN                   | DOM_TYPABREV              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*  6 |    FILTER                               |                           |     88 |        |            |     88 |00:00:00.01 |     186 |      0 |
|   7 |     TABLE ACCESS BY INDEX ROWID BATCHED | V_DOMAINE                 |     88 |      1 |     1   (0)|     88 |00:00:00.01 |     186 |      0 |
|*  8 |      INDEX RANGE SCAN                   | DOM_TYPABREV              |     88 |      1 |     1   (0)|     88 |00:00:00.01 |      98 |      0 |
|*  9 |    FILTER                               |                           |     88 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  10 |     TABLE ACCESS BY INDEX ROWID BATCHED | V_DOMAINE                 |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 11 |      INDEX RANGE SCAN                   | DOM_TYPABREV              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 12 |    FILTER                               |                           |     88 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  13 |     TABLE ACCESS BY INDEX ROWID BATCHED | V_DOMAINE                 |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 14 |      INDEX RANGE SCAN                   | DOM_TYPABREV              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 15 |    FILTER                               |                           |     88 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  16 |     TABLE ACCESS BY INDEX ROWID BATCHED | V_DOMAINE                 |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 17 |      INDEX RANGE SCAN                   | DOM_TYPABREV              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 18 |    FILTER                               |                           |     88 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  19 |     TABLE ACCESS BY INDEX ROWID BATCHED | V_DOMAINE                 |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 20 |      INDEX RANGE SCAN                   | DOM_TYPABREV              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 21 |    FILTER                               |                           |     88 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  22 |     TABLE ACCESS BY INDEX ROWID BATCHED | V_DOMAINE                 |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 23 |      INDEX RANGE SCAN                   | DOM_TYPABREV              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 24 |    FILTER                               |                           |     88 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  25 |     TABLE ACCESS BY INDEX ROWID BATCHED | V_DOMAINE                 |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 26 |      INDEX RANGE SCAN                   | DOM_TYPABREV              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 27 |    FILTER                               |                           |     88 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  28 |     TABLE ACCESS BY INDEX ROWID BATCHED | V_DOMAINE                 |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 29 |      INDEX RANGE SCAN                   | DOM_TYPABREV              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 30 |    FILTER                               |                           |     88 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  31 |     TABLE ACCESS BY INDEX ROWID BATCHED | V_DOMAINE                 |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 32 |      INDEX RANGE SCAN                   | DOM_TYPABREV              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 33 |    FILTER                               |                           |     88 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  34 |     TABLE ACCESS BY INDEX ROWID BATCHED | V_DOMAINE                 |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 35 |      INDEX RANGE SCAN                   | DOM_TYPABREV              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 36 |    FILTER                               |                           |     88 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  37 |     TABLE ACCESS BY INDEX ROWID BATCHED | V_DOMAINE                 |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 38 |      INDEX RANGE SCAN                   | DOM_TYPABREV              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 39 |    FILTER                               |                           |     88 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  40 |     TABLE ACCESS BY INDEX ROWID BATCHED | V_DOMAINE                 |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 41 |      INDEX RANGE SCAN                   | DOM_TYPABREV              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 42 |    FILTER                               |                           |     88 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  43 |     TABLE ACCESS BY INDEX ROWID BATCHED | V_DOMAINE                 |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 44 |      INDEX RANGE SCAN                   | DOM_TYPABREV              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 45 |    FILTER                               |                           |     88 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  46 |     TABLE ACCESS BY INDEX ROWID BATCHED | V_DOMAINE                 |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 47 |      INDEX RANGE SCAN                   | DOM_TYPABREV              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 48 |    FILTER                               |                           |     88 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  49 |     TABLE ACCESS BY INDEX ROWID BATCHED | V_DOMAINE                 |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 50 |      INDEX RANGE SCAN                   | DOM_TYPABREV              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 51 |    FILTER                               |                           |     88 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  52 |     TABLE ACCESS BY INDEX ROWID BATCHED | V_DOMAINE                 |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 53 |      INDEX RANGE SCAN                   | DOM_TYPABREV              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 54 |    FILTER                               |                           |     88 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  55 |     TABLE ACCESS BY INDEX ROWID BATCHED | V_DOMAINE                 |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 56 |      INDEX RANGE SCAN                   | DOM_TYPABREV              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 57 |    FILTER                               |                           |     88 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  58 |     TABLE ACCESS BY INDEX ROWID BATCHED | V_DOMAINE                 |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 59 |      INDEX RANGE SCAN                   | DOM_TYPABREV              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 60 |    FILTER                               |                           |     88 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  61 |     TABLE ACCESS BY INDEX ROWID BATCHED | V_DOMAINE                 |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 62 |      INDEX RANGE SCAN                   | DOM_TYPABREV              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 63 |    FILTER                               |                           |     88 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  64 |     TABLE ACCESS BY INDEX ROWID BATCHED | V_DOMAINE                 |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 65 |      INDEX RANGE SCAN                   | DOM_TYPABREV              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 66 |    FILTER                               |                           |     88 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  67 |     TABLE ACCESS BY INDEX ROWID BATCHED | V_DOMAINE                 |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 68 |      INDEX RANGE SCAN                   | DOM_TYPABREV              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 69 |    FILTER                               |                           |     88 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  70 |     TABLE ACCESS BY INDEX ROWID BATCHED | V_DOMAINE                 |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 71 |      INDEX RANGE SCAN                   | DOM_TYPABREV              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 72 |    FILTER                               |                           |     88 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  73 |     TABLE ACCESS BY INDEX ROWID BATCHED | V_DOMAINE                 |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 74 |      INDEX RANGE SCAN                   | DOM_TYPABREV              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 75 |    FILTER                               |                           |     88 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  76 |     TABLE ACCESS BY INDEX ROWID BATCHED | V_DOMAINE                 |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 77 |      INDEX RANGE SCAN                   | DOM_TYPABREV              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 78 |    FILTER                               |                           |     88 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  79 |     TABLE ACCESS BY INDEX ROWID BATCHED | V_DOMAINE                 |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 80 |      INDEX RANGE SCAN                   | DOM_TYPABREV              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 81 |    FILTER                               |                           |     88 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  82 |     TABLE ACCESS BY INDEX ROWID BATCHED | V_DOMAINE                 |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 83 |      INDEX RANGE SCAN                   | DOM_TYPABREV              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 84 |    FILTER                               |                           |     88 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  85 |     TABLE ACCESS BY INDEX ROWID BATCHED | V_DOMAINE                 |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 86 |      INDEX RANGE SCAN                   | DOM_TYPABREV              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 87 |    FILTER                               |                           |     88 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  88 |     TABLE ACCESS BY INDEX ROWID BATCHED | V_DOMAINE                 |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 89 |      INDEX RANGE SCAN                   | DOM_TYPABREV              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 90 |    FILTER                               |                           |     88 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  91 |     TABLE ACCESS BY INDEX ROWID BATCHED | V_DOMAINE                 |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 92 |      INDEX RANGE SCAN                   | DOM_TYPABREV              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 93 |    FILTER                               |                           |     88 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  94 |     TABLE ACCESS BY INDEX ROWID BATCHED | V_DOMAINE                 |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 95 |      INDEX RANGE SCAN                   | DOM_TYPABREV              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 96 |    FILTER                               |                           |     88 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  97 |     TABLE ACCESS BY INDEX ROWID BATCHED | V_DOMAINE                 |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 98 |      INDEX RANGE SCAN                   | DOM_TYPABREV              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 99 |    FILTER                               |                           |     88 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 100 |     TABLE ACCESS BY INDEX ROWID BATCHED | V_DOMAINE                 |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*101 |      INDEX RANGE SCAN                   | DOM_TYPABREV              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*102 |    FILTER                               |                           |     88 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 103 |     TABLE ACCESS BY INDEX ROWID BATCHED | V_DOMAINE                 |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*104 |      INDEX RANGE SCAN                   | DOM_TYPABREV              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*105 |    FILTER                               |                           |     88 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 106 |     TABLE ACCESS BY INDEX ROWID BATCHED | V_DOMAINE                 |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*107 |      INDEX RANGE SCAN                   | DOM_TYPABREV              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*108 |    FILTER                               |                           |     88 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 109 |     TABLE ACCESS BY INDEX ROWID BATCHED | V_DOMAINE                 |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*110 |      INDEX RANGE SCAN                   | DOM_TYPABREV              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*111 |    FILTER                               |                           |     88 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 112 |     TABLE ACCESS BY INDEX ROWID BATCHED | V_DOMAINE                 |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*113 |      INDEX RANGE SCAN                   | DOM_TYPABREV              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 114 |  NESTED LOOPS                           |                           |      1 |      1 |   893   (1)|     88 |00:03:12.80 |     663K|    529K|
| 115 |   NESTED LOOPS                          |                           |      1 |      1 |   893   (1)|     88 |00:03:12.80 |     663K|    529K|
| 116 |    NESTED LOOPS                         |                           |      1 |      1 |   892   (1)|     88 |00:03:12.79 |     663K|    529K|
|*117 |     HASH JOIN                           |                           |      1 |  14972 |   442   (1)|  41499 |00:03:09.56 |     546K|    521K|
|*118 |      HASH JOIN                          |                           |      1 |  12074 |   242   (0)|    837 |00:00:00.38 |    4773 |     44 |
|*119 |       HASH JOIN                         |                           |      1 |  15062 |   203   (0)|    837 |00:00:00.25 |    2674 |     44 |
|*120 |        INDEX SKIP SCAN                  | INT_INDIV                 |      1 |  52915 |    39   (0)|    264K|00:00:00.12 |    2099 |     39 |
| 121 |        NESTED LOOPS                     |                           |      1 |  18789 |   164   (0)|    837 |00:00:00.04 |     575 |      5 |
| 122 |         NESTED LOOPS                    |                           |      1 |  75350 |   164   (0)|    837 |00:00:00.01 |      13 |      5 |
| 123 |          NESTED LOOPS                   |                           |      1 |    274 |     2   (0)|      1 |00:00:00.01 |       6 |      0 |
|*124 |           INDEX UNIQUE SCAN             | DOS_REFDOSS               |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |      0 |
|*125 |           INDEX RANGE SCAN              | G_DOSSIER_RL_CD_RD_RF_IDX |      1 |    274 |     1   (0)|      1 |00:00:00.01 |       3 |      0 |
|*126 |          INDEX RANGE SCAN               | DOSS_LOT                  |      1 |    275 |     1   (0)|    837 |00:00:00.01 |       7 |      5 |
|*127 |         TABLE ACCESS BY INDEX ROWID     | G_DOSSIER                 |    837 |     69 |     1   (0)|    837 |00:00:00.03 |     562 |      0 |
|*128 |       INDEX SKIP SCAN                   | INT_INDIV                 |      1 |  52915 |    39   (0)|    264K|00:00:00.08 |    2099 |      0 |
|*129 |      TABLE ACCESS BY INDEX ROWID BATCHED| G_ELEMFI                  |      1 |    212K|   200   (0)|   7533K|00:03:06.77 |     542K|    521K|
|*130 |       INDEX RANGE SCAN                  | IDX_FFSI_G_ELEMFI         |      1 |    225K|     9   (0)|   7866K|00:00:13.01 |   28954 |  28931 |
|*131 |     TABLE ACCESS BY INDEX ROWID BATCHED | G_PIECE                   |  41499 |      1 |     1   (0)|     88 |00:00:03.22 |     116K|   7805 |
|*132 |      INDEX RANGE SCAN                   | PIE_REFPIECE              |  41499 |      1 |     1   (0)|  41499 |00:00:00.30 |   20546 |    499 |
|*133 |    INDEX UNIQUE SCAN                    | IND_REFINDIV              |     88 |      1 |     1   (0)|     88 |00:00:00.01 |     174 |      0 |
| 134 |   TABLE ACCESS BY INDEX ROWID           | G_INDIVIDU                |     88 |      1 |     1   (0)|     88 |00:00:00.01 |      64 |      1 |
-----------------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   3 - filter('AL'=:B1)
   5 - access("TYPE"='STATUS_DOC' AND "ABREV"=CASE  WHEN (:B1=:B2) THEN 'P' WHEN ((:B3>0) AND (:B4<>:B5)) THEN 'PP' ELSE 'NP' END )
   6 - filter('AN'=:B1)
   8 - access("TYPE"='STATUS_DOC' AND "ABREV"=CASE  WHEN (:B1=:B2) THEN 'P' WHEN ((:B3>0) AND (:B4<>:B5)) THEN 'PP' ELSE 'NP' END )
   9 - filter('AR'=:B1)
  11 - access("TYPE"='STATUS_DOC' AND "ABREV"=CASE  WHEN (:B1=:B2) THEN 'P' WHEN ((:B3>0) AND (:B4<>:B5)) THEN 'PP' ELSE 'NP' END )
  12 - filter('BG'=:B1)
  14 - access("TYPE"='STATUS_DOC' AND "ABREV"=CASE  WHEN (:B1=:B2) THEN 'P' WHEN ((:B3>0) AND (:B4<>:B5)) THEN 'PP' ELSE 'NP' END )
  15 - filter('BR'=:B1)
  17 - access("TYPE"='STATUS_DOC' AND "ABREV"=CASE  WHEN (:B1=:B2) THEN 'P' WHEN ((:B3>0) AND (:B4<>:B5)) THEN 'PP' ELSE 'NP' END )
  18 - filter('CE'=:B1)
  20 - access("TYPE"='STATUS_DOC' AND "ABREV"=CASE  WHEN (:B1=:B2) THEN 'P' WHEN ((:B3>0) AND (:B4<>:B5)) THEN 'PP' ELSE 'NP' END )
  21 - filter('CH'=:B1)
  23 - access("TYPE"='STATUS_DOC' AND "ABREV"=CASE  WHEN (:B1=:B2) THEN 'P' WHEN ((:B3>0) AND (:B4<>:B5)) THEN 'PP' ELSE 'NP' END )
  24 - filter('CS'=:B1)
  26 - access("TYPE"='STATUS_DOC' AND "ABREV"=CASE  WHEN (:B1=:B2) THEN 'P' WHEN ((:B3>0) AND (:B4<>:B5)) THEN 'PP' ELSE 'NP' END )
  27 - filter('DA'=:B1)
  29 - access("TYPE"='STATUS_DOC' AND "ABREV"=CASE  WHEN (:B1=:B2) THEN 'P' WHEN ((:B3>0) AND (:B4<>:B5)) THEN 'PP' ELSE 'NP' END )
  30 - filter('EL'=:B1)
  32 - access("TYPE"='STATUS_DOC' AND "ABREV"=CASE  WHEN (:B1=:B2) THEN 'P' WHEN ((:B3>0) AND (:B4<>:B5)) THEN 'PP' ELSE 'NP' END )
  33 - filter('ES'=:B1)
  35 - access("TYPE"='STATUS_DOC' AND "ABREV"=CASE  WHEN (:B1=:B2) THEN 'P' WHEN ((:B3>0) AND (:B4<>:B5)) THEN 'PP' ELSE 'NP' END )
  36 - filter('ET'=:B1)
  38 - access("TYPE"='STATUS_DOC' AND "ABREV"=CASE  WHEN (:B1=:B2) THEN 'P' WHEN ((:B3>0) AND (:B4<>:B5)) THEN 'PP' ELSE 'NP' END )
  39 - filter('FI'=:B1)
  41 - access("TYPE"='STATUS_DOC' AND "ABREV"=CASE  WHEN (:B1=:B2) THEN 'P' WHEN ((:B3>0) AND (:B4<>:B5)) THEN 'PP' ELSE 'NP' END )
  42 - filter('FL'=:B1)
  44 - access("TYPE"='STATUS_DOC' AND "ABREV"=CASE  WHEN (:B1=:B2) THEN 'P' WHEN ((:B3>0) AND (:B4<>:B5)) THEN 'PP' ELSE 'NP' END )
  45 - filter('FR'=:B1)
  47 - access("TYPE"='STATUS_DOC' AND "ABREV"=CASE  WHEN (:B1=:B2) THEN 'P' WHEN ((:B3>0) AND (:B4<>:B5)) THEN 'PP' ELSE 'NP' END )
  48 - filter('HR'=:B1)
  50 - access("TYPE"='STATUS_DOC' AND "ABREV"=CASE  WHEN (:B1=:B2) THEN 'P' WHEN ((:B3>0) AND (:B4<>:B5)) THEN 'PP' ELSE 'NP' END )
  51 - filter('HU'=:B1)
  53 - access("TYPE"='STATUS_DOC' AND "ABREV"=CASE  WHEN (:B1=:B2) THEN 'P' WHEN ((:B3>0) AND (:B4<>:B5)) THEN 'PP' ELSE 'NP' END )
  54 - filter('IT'=:B1)
  56 - access("TYPE"='STATUS_DOC' AND "ABREV"=CASE  WHEN (:B1=:B2) THEN 'P' WHEN ((:B3>0) AND (:B4<>:B5)) THEN 'PP' ELSE 'NP' END )
  57 - filter('IW'=:B1)
  59 - access("TYPE"='STATUS_DOC' AND "ABREV"=CASE  WHEN (:B1=:B2) THEN 'P' WHEN ((:B3>0) AND (:B4<>:B5)) THEN 'PP' ELSE 'NP' END )
  60 - filter('JA'=:B1)
  62 - access("TYPE"='STATUS_DOC' AND "ABREV"=CASE  WHEN (:B1=:B2) THEN 'P' WHEN ((:B3>0) AND (:B4<>:B5)) THEN 'PP' ELSE 'NP' END )
  63 - filter('LV'=:B1)
  65 - access("TYPE"='STATUS_DOC' AND "ABREV"=CASE  WHEN (:B1=:B2) THEN 'P' WHEN ((:B3>0) AND (:B4<>:B5)) THEN 'PP' ELSE 'NP' END )
  66 - filter('MX'=:B1)
  68 - access("TYPE"='STATUS_DOC' AND "ABREV"=CASE  WHEN (:B1=:B2) THEN 'P' WHEN ((:B3>0) AND (:B4<>:B5)) THEN 'PP' ELSE 'NP' END )
  69 - filter('NL'=:B1)
  71 - access("TYPE"='STATUS_DOC' AND "ABREV"=CASE  WHEN (:B1=:B2) THEN 'P' WHEN ((:B3>0) AND (:B4<>:B5)) THEN 'PP' ELSE 'NP' END )
  72 - filter('NO'=:B1)
  74 - access("TYPE"='STATUS_DOC' AND "ABREV"=CASE  WHEN (:B1=:B2) THEN 'P' WHEN ((:B3>0) AND (:B4<>:B5)) THEN 'PP' ELSE 'NP' END )
  75 - filter('NO'=:B1)
  77 - access("TYPE"='STATUS_DOC' AND "ABREV"=CASE  WHEN (:B1=:B2) THEN 'P' WHEN ((:B3>0) AND (:B4<>:B5)) THEN 'PP' ELSE 'NP' END )
  78 - filter('PL'=:B1)
  80 - access("TYPE"='STATUS_DOC' AND "ABREV"=CASE  WHEN (:B1=:B2) THEN 'P' WHEN ((:B3>0) AND (:B4<>:B5)) THEN 'PP' ELSE 'NP' END )
  81 - filter('PT'=:B1)
  83 - access("TYPE"='STATUS_DOC' AND "ABREV"=CASE  WHEN (:B1=:B2) THEN 'P' WHEN ((:B3>0) AND (:B4<>:B5)) THEN 'PP' ELSE 'NP' END )
  84 - filter('RO'=:B1)
  86 - access("TYPE"='STATUS_DOC' AND "ABREV"=CASE  WHEN (:B1=:B2) THEN 'P' WHEN ((:B3>0) AND (:B4<>:B5)) THEN 'PP' ELSE 'NP' END )
  87 - filter('RU'=:B1)
  89 - access("TYPE"='STATUS_DOC' AND "ABREV"=CASE  WHEN (:B1=:B2) THEN 'P' WHEN ((:B3>0) AND (:B4<>:B5)) THEN 'PP' ELSE 'NP' END )
  90 - filter('SK'=:B1)
  92 - access("TYPE"='STATUS_DOC' AND "ABREV"=CASE  WHEN (:B1=:B2) THEN 'P' WHEN ((:B3>0) AND (:B4<>:B5)) THEN 'PP' ELSE 'NP' END )
  93 - filter('SL'=:B1)
  95 - access("TYPE"='STATUS_DOC' AND "ABREV"=CASE  WHEN (:B1=:B2) THEN 'P' WHEN ((:B3>0) AND (:B4<>:B5)) THEN 'PP' ELSE 'NP' END )
  96 - filter('SR'=:B1)
  98 - access("TYPE"='STATUS_DOC' AND "ABREV"=CASE  WHEN (:B1=:B2) THEN 'P' WHEN ((:B3>0) AND (:B4<>:B5)) THEN 'PP' ELSE 'NP' END )
  99 - filter('SV'=:B1)
101 - access("TYPE"='STATUS_DOC' AND "ABREV"=CASE  WHEN (:B1=:B2) THEN 'P' WHEN ((:B3>0) AND (:B4<>:B5)) THEN 'PP' ELSE 'NP' END )
102 - filter('TR'=:B1)
104 - access("TYPE"='STATUS_DOC' AND "ABREV"=CASE  WHEN (:B1=:B2) THEN 'P' WHEN ((:B3>0) AND (:B4<>:B5)) THEN 'PP' ELSE 'NP' END )
105 - filter('US'=:B1)
107 - access("TYPE"='STATUS_DOC' AND "ABREV"=CASE  WHEN (:B1=:B2) THEN 'P' WHEN ((:B3>0) AND (:B4<>:B5)) THEN 'PP' ELSE 'NP' END )
108 - filter('VI'=:B1)
110 - access("TYPE"='STATUS_DOC' AND "ABREV"=CASE  WHEN (:B1=:B2) THEN 'P' WHEN ((:B3>0) AND (:B4<>:B5)) THEN 'PP' ELSE 'NP' END )
111 - filter('ZH'=:B1)
113 - access("TYPE"='STATUS_DOC' AND "ABREV"=CASE  WHEN (:B1=:B2) THEN 'P' WHEN ((:B3>0) AND (:B4<>:B5)) THEN 'PP' ELSE 'NP' END )
117 - access("GE"."REFDOSS"="CMP"."REFDOSS")
118 - access("TI"."REFDOSS"="CMP"."REFDOSS")
119 - access("T"."REFDOSS"="CMP"."REFDOSS")
120 - access("T"."REFTYPE"='DB')
       filter("T"."REFTYPE"='DB')
124 - access("CNT"."REFDOSS"=:B2)
125 - access("DCMP"."REFLOT"=:B2)
126 - access("CMP"."REFLOT"="DCMP"."REFDOSS")
127 - filter("CMP"."PIECEINIT"='COMPTE')
128 - access("TI"."REFTYPE"='DB')
       filter("TI"."REFTYPE"='DB')
129 - filter(("GE"."REFDOSS" IS NOT NULL AND "GE"."DTANNUL" IS NULL))
130 - access("GE"."TYPE"='FACTURE')
131 - filter(("GP"."REFDOSS"="CMP"."REFDOSS" AND "GP"."REFDOSS" IS NOT NULL AND "GP"."TYPPIECE"='FACTURE' AND
              TO_CHAR(TRUNC(GREATEST(NVL("GE"."DTDEBUT_DT",TO_DATE(' 1970-01-01 00:00:00', 'syyyy-mm-dd hh24:mi:ss')),NVL("GP"."DT13_DT",TO_DATE('
              1970-01-01 00:00:00', 'syyyy-mm-dd hh24:mi:ss')),NVL("GP"."DT14_DT",TO_DATE(' 1970-01-01 00:00:00', 'syyyy-mm-dd
              hh24:mi:ss')))))=TO_CHAR(TO_DATE(:B3,'dd/mm/yyyy')) AND "GP"."ST09"<>'C' AND "GP"."ST09"<>'RT'))
132 - access("GP"."REFPIECE"="GE"."REFPIECE2")
133 - access("GI"."REFINDIVIDU"="TI"."REFINDIVIDU")
*/
/********************************OLD Metrics***************************************/

/********************************New SQL*******************************************/

SELECT /*+ leading(cnt dcmp cmp ge) index(ge G_ELEMFI$REFDOSS_ACTIF ) use_nl(ge) use_nl(ti) */
        cnt.refdoss  AS contractId,                                                                                      
        dcmp.refdoss AS decompteId,                                                                                      
        cmp.refdoss  AS compteId,                                                                                        
        'Invoice' AS doc_type,                                                                                           
        ge.refext AS doc_ref,                                                                                            
        ge.montant_dos AS doc_value,                                                                                     
        cmp.devise currency,                                                                                             
        (SELECT NVL(valeur_trad, valeur)          FROM v_tdomaine                                                        
        WHERE type = 'STATUS_DOC'                                                                                        
        AND langue = :B1                                                                                               
        AND ABREV = (CASE                                                                                                
        WHEN ge.matched_amt = ge.montant_dos THEN  'P'                                                                   
        WHEN ge.matched_amt > 0 AND ge.matched_amt <> ge.montant_dos THEN 'PP'                                           
        ELSE  'NP'                                                                                                       
        END)) doc_status,                                                                                                
        TRIM(gi.nom||' '||gi.prenom) AS doc_person                                                                       
   FROM g_dossier cmp,                                                                                                   
        g_dossier dcmp,                                                                                                  
        g_dossier cnt,                                                                                                   
        t_intervenants ti,                                                                                               
        g_individu gi,                                                                                                   
        g_elemfi ge,                                                                                                     
        g_piece gp                                                                                                       
  WHERE cmp.pieceinit  = 'COMPTE'                                                                                        
    AND cmp.reflot     = dcmp.refdoss                                                                                    
    AND dcmp.reflot    = cnt.refdoss                                                                                     
    AND cnt.refdoss    = :B2                                                                                       
    AND ti.refdoss     = cmp.refdoss                                                                                     
    AND ti.reftype     = 'DB'                                                                                            
    AND gi.refindividu = ti.refindividu                                                                                  
    AND ge.refdoss     = cmp.refdoss                                                                                     
    AND ge.type        = 'FACTURE'                                                                                       
    AND gp.refdoss     = cmp.refdoss                                                                                     
    AND gp.refpiece    = ge.refpiece2                                                                                    
    AND gp.st09 NOT IN ('C','RT')                                                                                        
    AND ge.dtannul IS NULL                                                                                               
    AND gp.typpiece    = 'FACTURE'                                                                                       
    AND to_char(TRUNC(GREATEST(NVL(ge.dtdebut_dt, to_date('01/01/1970','dd/mm/yyyy')),                                   
                   NVL(gp.dt13_dt, to_date('01/01/1970','dd/mm/yyyy')),                                                  
                   NVL(gp.dt14_dt, to_date('01/01/1970','dd/mm/yyyy'))))) = to_char(to_date(:B3,'dd/mm/yyyy')) 
    AND ge.actif = 'O';
/********************************New SQL*******************************************/
/********************************New Metrics***************************************/
/*
Plan hash value: 1678869833
-------------------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                 | Name                      | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  |
-------------------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                          |                           |      1 |        |   977 (100)|     11 |00:00:00.22 |   12462 |    482 |
|   1 |  VIEW                                     | V_TDOMAINE                |     11 |     37 |    37   (0)|     11 |00:00:00.01 |      32 |      0 |
|   2 |   UNION-ALL                               |                           |     11 |        |            |     11 |00:00:00.01 |      32 |      0 |
|*  3 |    FILTER                                 |                           |     11 |        |            |      0 |00:00:00.01 |       0 |      0 |
|   4 |     TABLE ACCESS BY INDEX ROWID BATCHED   | V_DOMAINE                 |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*  5 |      INDEX RANGE SCAN                     | DOM_TYPABREV              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*  6 |    FILTER                                 |                           |     11 |        |            |     11 |00:00:00.01 |      32 |      0 |
|   7 |     TABLE ACCESS BY INDEX ROWID BATCHED   | V_DOMAINE                 |     11 |      1 |     1   (0)|     11 |00:00:00.01 |      32 |      0 |
|*  8 |      INDEX RANGE SCAN                     | DOM_TYPABREV              |     11 |      1 |     1   (0)|     11 |00:00:00.01 |      21 |      0 |
|*  9 |    FILTER                                 |                           |     11 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  10 |     TABLE ACCESS BY INDEX ROWID BATCHED   | V_DOMAINE                 |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 11 |      INDEX RANGE SCAN                     | DOM_TYPABREV              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 12 |    FILTER                                 |                           |     11 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  13 |     TABLE ACCESS BY INDEX ROWID BATCHED   | V_DOMAINE                 |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 14 |      INDEX RANGE SCAN                     | DOM_TYPABREV              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 15 |    FILTER                                 |                           |     11 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  16 |     TABLE ACCESS BY INDEX ROWID BATCHED   | V_DOMAINE                 |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 17 |      INDEX RANGE SCAN                     | DOM_TYPABREV              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 18 |    FILTER                                 |                           |     11 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  19 |     TABLE ACCESS BY INDEX ROWID BATCHED   | V_DOMAINE                 |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 20 |      INDEX RANGE SCAN                     | DOM_TYPABREV              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 21 |    FILTER                                 |                           |     11 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  22 |     TABLE ACCESS BY INDEX ROWID BATCHED   | V_DOMAINE                 |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 23 |      INDEX RANGE SCAN                     | DOM_TYPABREV              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 24 |    FILTER                                 |                           |     11 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  25 |     TABLE ACCESS BY INDEX ROWID BATCHED   | V_DOMAINE                 |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 26 |      INDEX RANGE SCAN                     | DOM_TYPABREV              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 27 |    FILTER                                 |                           |     11 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  28 |     TABLE ACCESS BY INDEX ROWID BATCHED   | V_DOMAINE                 |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 29 |      INDEX RANGE SCAN                     | DOM_TYPABREV              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 30 |    FILTER                                 |                           |     11 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  31 |     TABLE ACCESS BY INDEX ROWID BATCHED   | V_DOMAINE                 |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 32 |      INDEX RANGE SCAN                     | DOM_TYPABREV              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 33 |    FILTER                                 |                           |     11 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  34 |     TABLE ACCESS BY INDEX ROWID BATCHED   | V_DOMAINE                 |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 35 |      INDEX RANGE SCAN                     | DOM_TYPABREV              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 36 |    FILTER                                 |                           |     11 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  37 |     TABLE ACCESS BY INDEX ROWID BATCHED   | V_DOMAINE                 |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 38 |      INDEX RANGE SCAN                     | DOM_TYPABREV              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 39 |    FILTER                                 |                           |     11 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  40 |     TABLE ACCESS BY INDEX ROWID BATCHED   | V_DOMAINE                 |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 41 |      INDEX RANGE SCAN                     | DOM_TYPABREV              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 42 |    FILTER                                 |                           |     11 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  43 |     TABLE ACCESS BY INDEX ROWID BATCHED   | V_DOMAINE                 |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 44 |      INDEX RANGE SCAN                     | DOM_TYPABREV              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 45 |    FILTER                                 |                           |     11 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  46 |     TABLE ACCESS BY INDEX ROWID BATCHED   | V_DOMAINE                 |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 47 |      INDEX RANGE SCAN                     | DOM_TYPABREV              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 48 |    FILTER                                 |                           |     11 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  49 |     TABLE ACCESS BY INDEX ROWID BATCHED   | V_DOMAINE                 |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 50 |      INDEX RANGE SCAN                     | DOM_TYPABREV              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 51 |    FILTER                                 |                           |     11 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  52 |     TABLE ACCESS BY INDEX ROWID BATCHED   | V_DOMAINE                 |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 53 |      INDEX RANGE SCAN                     | DOM_TYPABREV              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 54 |    FILTER                                 |                           |     11 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  55 |     TABLE ACCESS BY INDEX ROWID BATCHED   | V_DOMAINE                 |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 56 |      INDEX RANGE SCAN                     | DOM_TYPABREV              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 57 |    FILTER                                 |                           |     11 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  58 |     TABLE ACCESS BY INDEX ROWID BATCHED   | V_DOMAINE                 |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 59 |      INDEX RANGE SCAN                     | DOM_TYPABREV              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 60 |    FILTER                                 |                           |     11 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  61 |     TABLE ACCESS BY INDEX ROWID BATCHED   | V_DOMAINE                 |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 62 |      INDEX RANGE SCAN                     | DOM_TYPABREV              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 63 |    FILTER                                 |                           |     11 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  64 |     TABLE ACCESS BY INDEX ROWID BATCHED   | V_DOMAINE                 |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 65 |      INDEX RANGE SCAN                     | DOM_TYPABREV              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 66 |    FILTER                                 |                           |     11 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  67 |     TABLE ACCESS BY INDEX ROWID BATCHED   | V_DOMAINE                 |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 68 |      INDEX RANGE SCAN                     | DOM_TYPABREV              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 69 |    FILTER                                 |                           |     11 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  70 |     TABLE ACCESS BY INDEX ROWID BATCHED   | V_DOMAINE                 |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 71 |      INDEX RANGE SCAN                     | DOM_TYPABREV              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 72 |    FILTER                                 |                           |     11 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  73 |     TABLE ACCESS BY INDEX ROWID BATCHED   | V_DOMAINE                 |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 74 |      INDEX RANGE SCAN                     | DOM_TYPABREV              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 75 |    FILTER                                 |                           |     11 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  76 |     TABLE ACCESS BY INDEX ROWID BATCHED   | V_DOMAINE                 |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 77 |      INDEX RANGE SCAN                     | DOM_TYPABREV              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 78 |    FILTER                                 |                           |     11 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  79 |     TABLE ACCESS BY INDEX ROWID BATCHED   | V_DOMAINE                 |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 80 |      INDEX RANGE SCAN                     | DOM_TYPABREV              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 81 |    FILTER                                 |                           |     11 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  82 |     TABLE ACCESS BY INDEX ROWID BATCHED   | V_DOMAINE                 |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 83 |      INDEX RANGE SCAN                     | DOM_TYPABREV              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 84 |    FILTER                                 |                           |     11 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  85 |     TABLE ACCESS BY INDEX ROWID BATCHED   | V_DOMAINE                 |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 86 |      INDEX RANGE SCAN                     | DOM_TYPABREV              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 87 |    FILTER                                 |                           |     11 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  88 |     TABLE ACCESS BY INDEX ROWID BATCHED   | V_DOMAINE                 |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 89 |      INDEX RANGE SCAN                     | DOM_TYPABREV              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 90 |    FILTER                                 |                           |     11 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  91 |     TABLE ACCESS BY INDEX ROWID BATCHED   | V_DOMAINE                 |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 92 |      INDEX RANGE SCAN                     | DOM_TYPABREV              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 93 |    FILTER                                 |                           |     11 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  94 |     TABLE ACCESS BY INDEX ROWID BATCHED   | V_DOMAINE                 |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 95 |      INDEX RANGE SCAN                     | DOM_TYPABREV              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 96 |    FILTER                                 |                           |     11 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  97 |     TABLE ACCESS BY INDEX ROWID BATCHED   | V_DOMAINE                 |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 98 |      INDEX RANGE SCAN                     | DOM_TYPABREV              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 99 |    FILTER                                 |                           |     11 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 100 |     TABLE ACCESS BY INDEX ROWID BATCHED   | V_DOMAINE                 |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*101 |      INDEX RANGE SCAN                     | DOM_TYPABREV              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*102 |    FILTER                                 |                           |     11 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 103 |     TABLE ACCESS BY INDEX ROWID BATCHED   | V_DOMAINE                 |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*104 |      INDEX RANGE SCAN                     | DOM_TYPABREV              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*105 |    FILTER                                 |                           |     11 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 106 |     TABLE ACCESS BY INDEX ROWID BATCHED   | V_DOMAINE                 |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*107 |      INDEX RANGE SCAN                     | DOM_TYPABREV              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*108 |    FILTER                                 |                           |     11 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 109 |     TABLE ACCESS BY INDEX ROWID BATCHED   | V_DOMAINE                 |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*110 |      INDEX RANGE SCAN                     | DOM_TYPABREV              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*111 |    FILTER                                 |                           |     11 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 112 |     TABLE ACCESS BY INDEX ROWID BATCHED   | V_DOMAINE                 |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*113 |      INDEX RANGE SCAN                     | DOM_TYPABREV              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 114 |  NESTED LOOPS                             |                           |      1 |      1 |   940   (0)|     11 |00:00:00.22 |   12462 |    482 |
| 115 |   NESTED LOOPS                            |                           |      1 |      1 |   940   (0)|     11 |00:00:00.22 |   12453 |    482 |
| 116 |    NESTED LOOPS                           |                           |      1 |      1 |   939   (0)|     11 |00:00:00.22 |   12429 |    482 |
| 117 |     NESTED LOOPS                          |                           |      1 |      1 |   938   (0)|     11 |00:00:00.22 |   12404 |    482 |
| 118 |      NESTED LOOPS                         |                           |      1 |    744 |   915   (0)|   1973 |00:00:00.02 |    4158 |      3 |
| 119 |       NESTED LOOPS                        |                           |      1 |  18789 |   164   (0)|    838 |00:00:00.01 |     573 |      0 |
| 120 |        NESTED LOOPS                       |                           |      1 |    274 |     2   (0)|      1 |00:00:00.01 |       7 |      0 |
|*121 |         INDEX UNIQUE SCAN                 | DOS_REFDOSS               |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |      0 |
|*122 |         INDEX RANGE SCAN                  | G_DOSSIER_RL_CD_RD_RF_IDX |      1 |    274 |     1   (0)|      1 |00:00:00.01 |       4 |      0 |
|*123 |        TABLE ACCESS BY INDEX ROWID BATCHED| G_DOSSIER                 |      1 |     69 |     1   (0)|    838 |00:00:00.01 |     566 |      0 |
|*124 |         INDEX RANGE SCAN                  | DOSS_LOT                  |      1 |    275 |     1   (0)|    838 |00:00:00.01 |       8 |      0 |
|*125 |       TABLE ACCESS BY INDEX ROWID BATCHED | G_ELEMFI                  |    838 |      1 |     1   (0)|   1973 |00:00:00.01 |    3585 |      3 |
|*126 |        INDEX RANGE SCAN                   | G_ELEMFI$REFDOSS_ACTIF    |    838 |      1 |     1   (0)|   1973 |00:00:00.01 |    2542 |      3 |
|*127 |      TABLE ACCESS BY INDEX ROWID BATCHED  | G_PIECE                   |   1973 |      1 |     1   (0)|     11 |00:00:00.20 |    8246 |    479 |
|*128 |       INDEX RANGE SCAN                    | PIE_REFPIECE              |   1973 |      1 |     1   (0)|   1973 |00:00:00.01 |    2997 |      8 |
|*129 |     INDEX RANGE SCAN                      | INT_REFDOSS               |     11 |      1 |     1   (0)|     11 |00:00:00.01 |      25 |      0 |
|*130 |    INDEX UNIQUE SCAN                      | IND_REFINDIV              |     11 |      1 |     1   (0)|     11 |00:00:00.01 |      24 |      0 |
| 131 |   TABLE ACCESS BY INDEX ROWID             | G_INDIVIDU                |     11 |      1 |     1   (0)|     11 |00:00:00.01 |       9 |      0 |
-------------------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   3 - filter('AL'=:B1)
   5 - access("TYPE"='STATUS_DOC' AND "ABREV"=CASE  WHEN (:B1=:B2) THEN 'P' WHEN ((:B3>0) AND (:B4<>:B5)) THEN 'PP' ELSE 'NP' END )
   6 - filter('AN'=:B1)
   8 - access("TYPE"='STATUS_DOC' AND "ABREV"=CASE  WHEN (:B1=:B2) THEN 'P' WHEN ((:B3>0) AND (:B4<>:B5)) THEN 'PP' ELSE 'NP' END )
   9 - filter('AR'=:B1)
  11 - access("TYPE"='STATUS_DOC' AND "ABREV"=CASE  WHEN (:B1=:B2) THEN 'P' WHEN ((:B3>0) AND (:B4<>:B5)) THEN 'PP' ELSE 'NP' END )
  12 - filter('BG'=:B1)
  14 - access("TYPE"='STATUS_DOC' AND "ABREV"=CASE  WHEN (:B1=:B2) THEN 'P' WHEN ((:B3>0) AND (:B4<>:B5)) THEN 'PP' ELSE 'NP' END )
  15 - filter('BR'=:B1)
  17 - access("TYPE"='STATUS_DOC' AND "ABREV"=CASE  WHEN (:B1=:B2) THEN 'P' WHEN ((:B3>0) AND (:B4<>:B5)) THEN 'PP' ELSE 'NP' END )
  18 - filter('CE'=:B1)
  20 - access("TYPE"='STATUS_DOC' AND "ABREV"=CASE  WHEN (:B1=:B2) THEN 'P' WHEN ((:B3>0) AND (:B4<>:B5)) THEN 'PP' ELSE 'NP' END )
  21 - filter('CH'=:B1)
  23 - access("TYPE"='STATUS_DOC' AND "ABREV"=CASE  WHEN (:B1=:B2) THEN 'P' WHEN ((:B3>0) AND (:B4<>:B5)) THEN 'PP' ELSE 'NP' END )
  24 - filter('CS'=:B1)
  26 - access("TYPE"='STATUS_DOC' AND "ABREV"=CASE  WHEN (:B1=:B2) THEN 'P' WHEN ((:B3>0) AND (:B4<>:B5)) THEN 'PP' ELSE 'NP' END )
  27 - filter('DA'=:B1)
  29 - access("TYPE"='STATUS_DOC' AND "ABREV"=CASE  WHEN (:B1=:B2) THEN 'P' WHEN ((:B3>0) AND (:B4<>:B5)) THEN 'PP' ELSE 'NP' END )
  30 - filter('EL'=:B1)
  32 - access("TYPE"='STATUS_DOC' AND "ABREV"=CASE  WHEN (:B1=:B2) THEN 'P' WHEN ((:B3>0) AND (:B4<>:B5)) THEN 'PP' ELSE 'NP' END )
  33 - filter('ES'=:B1)
  35 - access("TYPE"='STATUS_DOC' AND "ABREV"=CASE  WHEN (:B1=:B2) THEN 'P' WHEN ((:B3>0) AND (:B4<>:B5)) THEN 'PP' ELSE 'NP' END )
  36 - filter('ET'=:B1)
  38 - access("TYPE"='STATUS_DOC' AND "ABREV"=CASE  WHEN (:B1=:B2) THEN 'P' WHEN ((:B3>0) AND (:B4<>:B5)) THEN 'PP' ELSE 'NP' END )
  39 - filter('FI'=:B1)
  41 - access("TYPE"='STATUS_DOC' AND "ABREV"=CASE  WHEN (:B1=:B2) THEN 'P' WHEN ((:B3>0) AND (:B4<>:B5)) THEN 'PP' ELSE 'NP' END )
  42 - filter('FL'=:B1)
  44 - access("TYPE"='STATUS_DOC' AND "ABREV"=CASE  WHEN (:B1=:B2) THEN 'P' WHEN ((:B3>0) AND (:B4<>:B5)) THEN 'PP' ELSE 'NP' END )
  45 - filter('FR'=:B1)
  47 - access("TYPE"='STATUS_DOC' AND "ABREV"=CASE  WHEN (:B1=:B2) THEN 'P' WHEN ((:B3>0) AND (:B4<>:B5)) THEN 'PP' ELSE 'NP' END )
  48 - filter('HR'=:B1)
  50 - access("TYPE"='STATUS_DOC' AND "ABREV"=CASE  WHEN (:B1=:B2) THEN 'P' WHEN ((:B3>0) AND (:B4<>:B5)) THEN 'PP' ELSE 'NP' END )
  51 - filter('HU'=:B1)
  53 - access("TYPE"='STATUS_DOC' AND "ABREV"=CASE  WHEN (:B1=:B2) THEN 'P' WHEN ((:B3>0) AND (:B4<>:B5)) THEN 'PP' ELSE 'NP' END )
  54 - filter('IT'=:B1)
  56 - access("TYPE"='STATUS_DOC' AND "ABREV"=CASE  WHEN (:B1=:B2) THEN 'P' WHEN ((:B3>0) AND (:B4<>:B5)) THEN 'PP' ELSE 'NP' END )
  57 - filter('IW'=:B1)
  59 - access("TYPE"='STATUS_DOC' AND "ABREV"=CASE  WHEN (:B1=:B2) THEN 'P' WHEN ((:B3>0) AND (:B4<>:B5)) THEN 'PP' ELSE 'NP' END )
  60 - filter('JA'=:B1)
  62 - access("TYPE"='STATUS_DOC' AND "ABREV"=CASE  WHEN (:B1=:B2) THEN 'P' WHEN ((:B3>0) AND (:B4<>:B5)) THEN 'PP' ELSE 'NP' END )
  63 - filter('LV'=:B1)
  65 - access("TYPE"='STATUS_DOC' AND "ABREV"=CASE  WHEN (:B1=:B2) THEN 'P' WHEN ((:B3>0) AND (:B4<>:B5)) THEN 'PP' ELSE 'NP' END )
  66 - filter('MX'=:B1)
  68 - access("TYPE"='STATUS_DOC' AND "ABREV"=CASE  WHEN (:B1=:B2) THEN 'P' WHEN ((:B3>0) AND (:B4<>:B5)) THEN 'PP' ELSE 'NP' END )
  69 - filter('NL'=:B1)
  71 - access("TYPE"='STATUS_DOC' AND "ABREV"=CASE  WHEN (:B1=:B2) THEN 'P' WHEN ((:B3>0) AND (:B4<>:B5)) THEN 'PP' ELSE 'NP' END )
  72 - filter('NO'=:B1)
  74 - access("TYPE"='STATUS_DOC' AND "ABREV"=CASE  WHEN (:B1=:B2) THEN 'P' WHEN ((:B3>0) AND (:B4<>:B5)) THEN 'PP' ELSE 'NP' END )
  75 - filter('NO'=:B1)
  77 - access("TYPE"='STATUS_DOC' AND "ABREV"=CASE  WHEN (:B1=:B2) THEN 'P' WHEN ((:B3>0) AND (:B4<>:B5)) THEN 'PP' ELSE 'NP' END )
  78 - filter('PL'=:B1)
  80 - access("TYPE"='STATUS_DOC' AND "ABREV"=CASE  WHEN (:B1=:B2) THEN 'P' WHEN ((:B3>0) AND (:B4<>:B5)) THEN 'PP' ELSE 'NP' END )
  81 - filter('PT'=:B1)
  83 - access("TYPE"='STATUS_DOC' AND "ABREV"=CASE  WHEN (:B1=:B2) THEN 'P' WHEN ((:B3>0) AND (:B4<>:B5)) THEN 'PP' ELSE 'NP' END )
  84 - filter('RO'=:B1)
  86 - access("TYPE"='STATUS_DOC' AND "ABREV"=CASE  WHEN (:B1=:B2) THEN 'P' WHEN ((:B3>0) AND (:B4<>:B5)) THEN 'PP' ELSE 'NP' END )
  87 - filter('RU'=:B1)
  89 - access("TYPE"='STATUS_DOC' AND "ABREV"=CASE  WHEN (:B1=:B2) THEN 'P' WHEN ((:B3>0) AND (:B4<>:B5)) THEN 'PP' ELSE 'NP' END )
  90 - filter('SK'=:B1)
  92 - access("TYPE"='STATUS_DOC' AND "ABREV"=CASE  WHEN (:B1=:B2) THEN 'P' WHEN ((:B3>0) AND (:B4<>:B5)) THEN 'PP' ELSE 'NP' END )
  93 - filter('SL'=:B1)
  95 - access("TYPE"='STATUS_DOC' AND "ABREV"=CASE  WHEN (:B1=:B2) THEN 'P' WHEN ((:B3>0) AND (:B4<>:B5)) THEN 'PP' ELSE 'NP' END )
  96 - filter('SR'=:B1)
  98 - access("TYPE"='STATUS_DOC' AND "ABREV"=CASE  WHEN (:B1=:B2) THEN 'P' WHEN ((:B3>0) AND (:B4<>:B5)) THEN 'PP' ELSE 'NP' END )
  99 - filter('SV'=:B1)
101 - access("TYPE"='STATUS_DOC' AND "ABREV"=CASE  WHEN (:B1=:B2) THEN 'P' WHEN ((:B3>0) AND (:B4<>:B5)) THEN 'PP' ELSE 'NP' END )
102 - filter('TR'=:B1)
104 - access("TYPE"='STATUS_DOC' AND "ABREV"=CASE  WHEN (:B1=:B2) THEN 'P' WHEN ((:B3>0) AND (:B4<>:B5)) THEN 'PP' ELSE 'NP' END )
105 - filter('US'=:B1)
107 - access("TYPE"='STATUS_DOC' AND "ABREV"=CASE  WHEN (:B1=:B2) THEN 'P' WHEN ((:B3>0) AND (:B4<>:B5)) THEN 'PP' ELSE 'NP' END )
108 - filter('VI'=:B1)
110 - access("TYPE"='STATUS_DOC' AND "ABREV"=CASE  WHEN (:B1=:B2) THEN 'P' WHEN ((:B3>0) AND (:B4<>:B5)) THEN 'PP' ELSE 'NP' END )
111 - filter('ZH'=:B1)
113 - access("TYPE"='STATUS_DOC' AND "ABREV"=CASE  WHEN (:B1=:B2) THEN 'P' WHEN ((:B3>0) AND (:B4<>:B5)) THEN 'PP' ELSE 'NP' END )
121 - access("CNT"."REFDOSS"=:B2)
122 - access("DCMP"."REFLOT"=:B2)
123 - filter("CMP"."PIECEINIT"='COMPTE')
124 - access("CMP"."REFLOT"="DCMP"."REFDOSS")
125 - filter("GE"."DTANNUL" IS NULL)
126 - access("GE"."REFDOSS"="CMP"."REFDOSS" AND "GE"."ACTIF"='O' AND "GE"."TYPE"='FACTURE')
       filter("GE"."REFDOSS" IS NOT NULL)
127 - filter(("GP"."REFDOSS"="CMP"."REFDOSS" AND "GP"."REFDOSS" IS NOT NULL AND "GP"."TYPPIECE"='FACTURE' AND
              TO_CHAR(TRUNC(GREATEST(NVL("GE"."DTDEBUT_DT",TO_DATE(' 1970-01-01 00:00:00', 'syyyy-mm-dd hh24:mi:ss')),NVL("GP"."DT13_DT",TO_DATE('
              1970-01-01 00:00:00', 'syyyy-mm-dd hh24:mi:ss')),NVL("GP"."DT14_DT",TO_DATE(' 1970-01-01 00:00:00', 'syyyy-mm-dd
              hh24:mi:ss')))))=TO_CHAR(TO_DATE(:B3,'dd/mm/yyyy')) AND "GP"."ST09"<>'C' AND "GP"."ST09"<>'RT'))
128 - access("GP"."REFPIECE"="GE"."REFPIECE2")
129 - access("TI"."REFDOSS"="CMP"."REFDOSS" AND "TI"."REFTYPE"='DB')
130 - access("GI"."REFINDIVIDU"="TI"."REFINDIVIDU")
*/
/********************************New Metrics***************************************/

/********************************Index statistics**********************************/

/********************************Other SQLs****************************************/          
/*

*/ 
/********************************Other SQLs****************************************/              
