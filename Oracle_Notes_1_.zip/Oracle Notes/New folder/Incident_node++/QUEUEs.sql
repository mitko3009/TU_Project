####################################################################

### Pat Putty save
C:\Temp\Putty\&Y-&M-&D-&H_.log 


################################################
### missrouted EON queue
s
### Service Desk EON ###
E-INCFLS-EON-GSD-SOFIA-CE
E-INCFLS-EON-GSD-BANGALORE-CE
E-INCFLS-EON-GSD-NORDICS-CE
E-INCFLS-EON-GSD-MISROUTE-CE   - this is the QUEUE


####################################################
#### AUDI
OPS WEB-EXT-DB-GER Advanced Support AUDI


###########################################
###### VOBE ####
FLEMISH GOVERNMENT/VOBE/

E-INCSSP-VOBE_BHV-TOE-AMOS 
pdl-ito-do-bulgaria-database-fg-oracle@dxc.com
fg.amos@dxc.com

CHANGE OPASHKA CHANGE SUPERVISOR GROUP:

E-CHGSUP-GDO-GCB-DB-ORACLE-II 
/VOBE/


[‎5/‎23/‎2020 6:57 PM]  Naydenova, Martina Krasimirova:  
network queue VOBE - Proximus

Proximus Service Desk	servicedesk.bgc.hbplus@proximus.com	​+32 800 98 088
+32 78 15 21 20 (2nd line hotline)​​​​
Proximus Network - out of office hours	​ict-servicedesk.roc@proximus.com	​+32 2 382 95 34 (outside office hours only)
 
Procedure for openning/transfering a case to Proximux Network Team :  HERE

MVLG_BSC_BE_TAU  messaging, mail supporting team
MCSBEGOVERNMENT@dxc.com​
 
E-INCSSP-VOBE-BGC-LAN-L1-CE - NTP issues

Proximus team (third party). You can create or reassign an incident to this queue.
But it's import to remove HP in the field Service Provider otherwise you will not find the group of Proximus. 
 


################################################################
### opashka na MSSQL FCC
INFR-GLOBAL-HP-INCSSP_GDO_GCB_DB 



##### Opashkata na BASF
E-INCSP-GDO-BG-LINUX-BASF


####### Server desk team
RMC-GERMANY-OPERATIONS FULLACCESS
 aleksandar milushev




The past year was very exciting for me. I've learned a lot during my UNIX Academy. I passed successfully the final exam, as a result, that my manager offered me to become a part of the Oracle Team and I agreed. With the help of my colleagues, I was able to learn the technology and do my job well, but I admit that a lot is yet to be learned.I've managed to make a "U" turn in my career because started without any experience and can say that now I'm a very good performer. I have very good feedback from my colleagues because I make every task that I have during my shifts and think that doing them without mistakes. I am very careful in my daily work. During the year I watched a lot of Oracle pieces of training because I want to become a good DBA.
I like the work and I think to continue in the same spirit, to pass more pieces of training to improve my knowledge and to continue with the language lessons.

