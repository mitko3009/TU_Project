﻿########## TEMP  ##########

HOW TO CHECK TEMP FILES:

The current size of your temporary tablespace can be found by querying the DBA_TEMP_FILES view:

select tablespace_name, 
sum(bytes)/1024/1024 MB
from dba_temp_files
group by tablespace_name
/

TABLESPACE_NAME                        MB
------------------------------ ----------
TEMP                                 1024


---------------------NADIA TEMP-------------------------------------
If you want to find information for a temporary tablespace you may run queries against dba_temp_files.


set linesize 400
col FILE_NAME for a70
select file_id,tablespace_name,file_name,bytes/1024/1024 MB,autoextensible,status
from dba_temp_files
where TABLESPACE_NAME=upper('GTOTM_TEMP');


   FILE_ID TABLESPACE_NAME                FILE_NAME                                                                      MB AUT STATUS
---------- ------------------------------ ---------------------------------------------------------------------- ---------- --- -------
        14 GTOTM_TEMP                     +DATA2/P60025/TEMPFILE/gtotm_temp.410.1014990257                            32768 NO  ONLINE



In temporary TBS are performed the sort operation and etc. it stores the temporary data that only exists during the database session. 

-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-

### Checking if there are any active sessions to TEMP tablespace:

SQL>
select *
from v$session
where saddr in (select session_addr
from v$tempseg_usage v
where v.tablespace = 'TEMP') ;
-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-





###############################################
SHRINK TEMP FILES :

alter tablespace EVKIS_TEMP shrink space; 





###############################################
SHOW TEMP FREE SPACE:

set lines 250
set pages 40
col 1 noprint;
break on 1
compute sum of megs_alloc on 1
compute sum of megs_free on 1
compute sum of megs_used on 1
compute sum of megs_max on 1
select  1, a.tablespace_name,
       round(a.bytes_alloc / 1024 / 1024, 2) megs_alloc,
       round(nvl(b.bytes_free, 0) / 1024 / 1024, 2) megs_free,
       round((a.bytes_alloc - nvl(b.bytes_free, 0)) / 1024 / 1024, 2) megs_used,
       round((nvl(b.bytes_free, 0) / a.bytes_alloc) * 100,2) Pct_Free,
       100 - round((nvl(b.bytes_free, 0) / a.bytes_alloc) * 100,2) Pct_used,
       round(maxbytes/1048576,2) Megs_max,
      round(100*(round((a.bytes_alloc - nvl(b.bytes_free, 0)) / 1024 / 1024, 2))/(round(maxbytes/1048576,2)),2) pct_used_max
from  ( select  f.tablespace_name,
               sum(f.bytes) bytes_alloc,
               sum(decode(f.autoextensible, 'YES', CASE WHEN f.maxbytes >= f.bytes THEN f.maxbytes ELSE f.bytes END, 'NO', f.bytes)) maxbytes
        from dba_data_files f
        group by tablespace_name) a,
      ( select  f.tablespace_name,
               sum(f.bytes)  bytes_free
        from dba_free_space f
        group by tablespace_name) b
where a.tablespace_name = b.tablespace_name (+)
union
select 1, h.tablespace_name,
       round(sum(h.bytes_free + h.bytes_used) / 1048576, 2),
       round(sum((h.bytes_free + h.bytes_used) - nvl(p.bytes_used, 0)) / 1048576, 2),
       round(sum(nvl(p.bytes_used, 0))/ 1048576, 2) megs_used,
       round((sum((h.bytes_free + h.bytes_used) - nvl(p.bytes_used, 0)) / sum(h.bytes_used + h.bytes_free)) * 100,2),
       100 - round((sum((h.bytes_free + h.bytes_used) - nvl(p.bytes_used, 0)) / sum(h.bytes_used + h.bytes_free)) * 100,2),
       round(sum(decode(f.autoextensible, 'YES', CASE WHEN f.maxbytes >= (h.bytes_used + h.bytes_free) THEN f.maxbytes ELSE (h.bytes_used + h.bytes_free) END, 'NO', f.bytes)) / 1048576, 2) Max,
       round(100*(round(sum(nvl(p.bytes_used, 0))/ 1048576, 2))/(round(sum(decode(f.autoextensible, 'YES', CASE WHEN f.maxbytes >= (h.bytes_used + h.bytes_free) THEN f.maxbytes ELSE (h.bytes_used + h.bytes_free) END, 'NO', f.bytes)) / 1048576, 2)),2)
from   sys.v_$TEMP_SPACE_HEADER h, sys.v_$Temp_extent_pool p, dba_temp_files f
where  p.file_id(+) = h.file_id
and    p.tablespace_name(+) = h.tablespace_name
and    h.file_id = f.file_id
and    h.tablespace_name = f.tablespace_name
group by h.tablespace_name
ORDER BY PCT_USED_MAX desc;

*********************************************************************
*********************************************************************
### TEMP SHORT:

SELECT A.tablespace_name tablespace, D.mb_total, 
         SUM (A.used_blocks * D.block_size) / 1024 / 1024 mb_used, 
         D.mb_total - SUM (A.used_blocks * D.block_size) / 1024 / 1024 mb_		 
FROM v$sort_segment A, 
         ( 
         SELECT B.name, C.block_size, SUM (C.bytes) / 1024 / 1024 mb_total 
         FROM v$tablespace B, v$tempfile C 
         WHERE B.ts#= C.ts# 
         GROUP BY B.name, C.block_size 
         ) D 
WHERE A.tablespace_name = D.name 
GROUP by A.tablespace_name, D.mb_total;



#### TEMP DATAFILES:

set linesize 400
  col FILE_NAME for a70
  select FILE_ID,FILE_NAME, TABLESPACE_NAME, (increment_by*(bytes/blocks))/1024 increment_by_kb, BYTES/1024/1024, MAXBYTES/1024/1024, 
  AUTOEXTENSIBLE from sys.dba_temp_files where TABLESPACE_NAME='&tablespace_name'; 
  
  
###############################################
#### SHRINK TEMP FILES :

alter tablespace EVKIS_TEMP shrink space;


SQL> alter database datafile 3 autoextend on maxsize 3000M;

Database altered.


###############################################

select sum(free_blocks)
from gv$sort_segment
where tablespace_name = 'EVKIS_TEMP'

###############################################
### TEMP USAGE:

col SQL_TEXT for a80 
col TABLESPACE for a10 
SELECT   S.sid || ',' || S.serial# sid_serial, S.username, S.machine,
         T.blocks * TBS.block_size / 1024 / 1024 mb_used,
         T.sqladdr address, Q.hash_value, Q.sql_text 
FROM     v$sort_usage T, v$session S, v$sqlarea Q, dba_tablespaces TBS 
WHERE    T.session_addr = S.saddr 
AND      T.sqladdr = Q.address (+) 
AND      T.tablespace = TBS.tablespace_name 
-- and  SQL_TEXT  like '%DUAL%'
ORDER BY mb_used asc; 
 

-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-

### Recreating the old structure of the temp tablespace:

select TABLESPACE_NAME, BYTES_USED, BYTES_FREE from V$TEMP_SPACE_HEADER;

SELECT * FROM DATABASE_PROPERTIES where PROPERTY_NAME='DEFAULT_TEMP_TABLESPACE';



SQL> CREATE TEMPORARY TABLESPACE TEMP TEMPFILE '/var/opt/orawh/oratemp/CRDWEPRD/TEMPCRDWEPRD01.dbf' size 5G autoextend ON maxsize 15G;

Tablespace created.


ALTER TABLESPACE TEMP ADD TEMPFILE '+DATAC1' SIZE 10G AUTOEXTEND ON NEXT 1G MAXSIZE 32767M; 



SQL>

SQL> ALTER DATABASE DEFAULT TEMPORARY TABLESPACE temp;

Database altered.

SQL> DROP TABLESPACE temp2 INCLUDING CONTENTS AND DATAFILES;

Tablespace dropped.

-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
====
extending temp file
====
SQL> alter database tempfile '/var/opt/oraradr/oratemp/RADR/RADR_temp_01.dbf' autoextend on maxsize 7700M;

Database altered.

SQL> select file_name, tablespace_name, maxbytes/1024/1024, bytes/1024/1024 from dba_temp_files;

FILE_NAME
--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
TABLESPACE_NAME                MAXBYTES/1024/1024 BYTES/1024/1024
------------------------------ ------------------ ---------------
/var/opt/oraradr/oratemp/RADR/RADR_temp_01.dbf
TEMP                                         7700            5888


-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------
 
set lines 400
col FILE_NAME for a70
select FILE_ID, FILE_NAME, TABLESPACE_NAME, BYTES/1024/1024, MAXBYTES/1024/1024, AUTOEXTENSIBLE from dba_temp_files;



   FILE_ID FILE_NAME                                                              TABLESPACE_NAME                BYTES/1024/1024 MAXBYTES/1024/1024 AUT
---------- ---------------------------------------------------------------------- ------------------------------ --------------- ------------------ ---
         1 +DATA/simprod/tempfile/temp.396.997645405                              TEMP                                     32767         32767.9844 YES





  FILE_ID FILE_NAME                                                              TABLESPACE_NAME                BYTES/1024/1024 MAXBYTES/1024/1024 AUT
---------- ---------------------------------------------------------------------- ------------------------------ --------------- ------------------ ---
         2 +DATA/SIMPROD/TEMPFILE/temp.463.1011465365                             TEMP                                       450              32767 YES
         1 +DATA/simprod/tempfile/temp.396.997645405                              TEMP                                     32767         32767.9844 YES


alter tablespace temp drop tempfile 2; 
 
АКО ИЗЛИЗА ТАЗИ ГРЕШКА:

ERROR at line 1:
ORA-25152: TEMPFILE cannot be dropped at this time
 
ТРЯБВА ДА ПРОВЕРЯ дали в момента се ползва/долните query-та/



====================unable to extent TEMP SEGMENTS CHECK=======================================
 
7/

SELECT A.tablespace_name tablespace, D.mb_total,
SUM (A.used_blocks * D.block_size) / 1024 / 1024 mb_used,
D.mb_total - SUM (A.used_blocks * D.block_size) / 1024 / 1024 mb_free
FROM v$sort_segment A,
(
SELECT B.name, C.block_size, SUM (C.bytes) / 1024 / 1024 mb_total
FROM v$tablespace B, v$tempfile C
WHERE B.ts#= C.ts#
GROUP BY B.name, C.block_size
) D
WHERE A.tablespace_name = D.name
GROUP by A.tablespace_name, D.mb_total;
 
OUTPUT:

TABLESPACE   MB_TOTAL    MB_USED    MB_FREE
---------- ---------- ---------- ----------
TEMP            32767        750      32017


6/

set lines 152
col FreeSpaceGB format 999.999
col UsedSpaceGB format 999.999
col TotalSpaceGB format 999.999
col host_name format a30
col tablespace_name format a30
select tablespace_name,
(free_blocks*8)/1024/1024 FreeSpaceGB,
(used_blocks*8)/1024/1024 UsedSpaceGB,
(total_blocks*8)/1024/1024 TotalSpaceGB,
i.instance_name,i.host_name
from gv$sort_segment ss,gv$instance i where ss.tablespace_name in (select tablespace_name from dba_tablespaces where contents='TEMPORARY') and
i.inst_id=ss.inst_id;
 
OUTPUT:

TABLESPACE_NAME                FREESPACEGB USEDSPACEGB TOTALSPACEGB INSTANCE_NAME    HOST_NAME
------------------------------ ----------- ----------- ------------ ---------------- ------------------------------
TEMP                                31.713        .655       32.368 SIMPROD_1        fivatx0236.adinfra.net


5/

set lines 500
set pages 500
col SID_SERIAL for a15
col USERNAME for a15
col SQL_TEXT for a100
col TABLESPACE for a10
SELECT S.sid || ',' || S.serial# sid_serial, S.username,
T.blocks * TBS.block_size / 1024 / 1024 mb_used, T.tablespace,
T.sqladdr address, Q.hash_value, Q.sql_text
FROM v$sort_usage T, v$session S, v$sqlarea Q, dba_tablespaces TBS
WHERE T.session_addr = S.saddr
AND T.sqladdr = Q.address (+)
AND T.tablespace = TBS.tablespace_name
ORDER BY MB_USED,S.sid;
 

OUTPUT:

SID_SERIAL      USERNAME           MB_USED TABLESPACE ADDRESS          HASH_VALUE SQL_TEXT
--------------- --------------- ---------- ---------- ---------------- ---------- ----------------------------------------------------------------------------------------------------
1738,17020      KIRJOVIL                 1 TEMP       000000010F797470 1653802045 SELECT --+ RDERED NDEX(OC IDX_OBJ_CHANGED_OBJ_KEY_DATE)  OC.OBJECT_KEY , OC.FROMTIME , OC.TOTIME , M
                                                                                  AX(OC.ORA_ROWSCN) OVER () MAX_ORA_ROWSCN , OC.RCOUNT , OC.APP_KEY FROM TSDBMONITOR_ M JOIN OBJECT_CH
                                                                                  ANGED OC ON ( OC.OBJECT_KEY = M.OBJECT_KEY AND OC.DATETIM > NVL(TRIM(:B5 ), '0') AND ( :B2 IN (:B4 ,
                                                                                   :B3 ) AND OC.OBJECT_TYPE IN (:B4 , :B3 ) OR :B2 NOT IN (:B4 , :B3 ) AND OC.OBJECT_TYPE = :B2 ) AND
                                                                                  OC.ORA_ROWSCN > :B1 ) WHERE 1 = 1 AND M.ID = :B6 ORDER BY OC.OBJECT_KEY , OC.FROMTIME , OC.TOTIME

1738,17020      KIRJOVIL                 1 TEMP       000000010F797470 1653802045 SELECT --+ RDERED NDEX(OC IDX_OBJ_CHANGED_OBJ_KEY_DATE)  OC.OBJECT_KEY , OC.FROMTIME , OC.TOTIME , M
                                                                                  AX(OC.ORA_ROWSCN) OVER () MAX_ORA_ROWSCN , OC.RCOUNT , OC.APP_KEY FROM TSDBMONITOR_ M JOIN OBJECT_CH
                                                                                  ANGED OC ON ( OC.OBJECT_KEY = M.OBJECT_KEY AND OC.DATETIM > NVL(TRIM(:B5 ), '0') AND ( :B2 IN (:B4 ,
                                                                                   :B3 ) AND OC.OBJECT_TYPE IN (:B4 , :B3 ) OR :B2 NOT IN (:B4 , :B3 ) AND OC.OBJECT_TYPE = :B2 ) AND
                                                                                  OC.ORA_ROWSCN > :B1 ) WHERE 1 = 1 AND M.ID = :B6 ORDER BY OC.OBJECT_KEY , OC.FROMTIME , OC.TOTIME

or
 
set lines 500
set pages 500
col SQL_TEXT for a80
col TABLESPACE for a10
SELECT S.sid || ',' || S.serial# sid_serial, S.username,
T.blocks * TBS.block_size / 1024 / 1024 mb_used, T.tablespace,
T.sqladdr address, Q.hash_value, Q.sql_text
FROM v$sort_usage T, v$session S, v$sqlarea Q, dba_tablespaces TBS
WHERE T.session_addr = S.saddr
AND T.sqladdr = Q.address (+)
AND T.tablespace = TBS.tablespace_name
ORDER BY S.sid;

OUTPUT:

SID_SERIAL      USERNAME      MB_USED TABLESPACE ADDRESS          HASH_VALUE SQL_TEXT
--------------- ---------- ---------- ---------- ---------------- ---------- --------------------------------------------------------------------------------
                                                                             KEY

2025,14088      FI_DC               1 TEMP       00000000EEA1D888 1597180379 SELECT PARENTKEY_ORDER , PRIORITY , TIMS_KEY , COMP_KEY , COMPRESTRICTION_COUNT
                                                                             FROM DYNAMIC_RESTRICTIONS ORDER BY PARENTKEY_ORDER , PRIORITY , TIMS_KEY , COMP_
                                                                             KEY

2025,14088      FI_DC               1 TEMP       00000000EEA1D888 1597180379 SELECT PARENTKEY_ORDER , PRIORITY , TIMS_KEY , COMP_KEY , COMPRESTRICTION_COUNT
                                                                             FROM DYNAMIC_RESTRICTIONS ORDER BY PARENTKEY_ORDER , PRIORITY , TIMS_KEY , COMP_
                                                                             KEY
 
4/
 
set linesize 400 
col FILE_NAME for a70 
select FILE_NAME, FILE_ID, TABLESPACE_NAME, BYTES/1024/1024, MAXBYTES/1024/1024, AUTOEXTENSIBLE from dba_temp_files order by FILE_ID;
 
OUTPUT:

FILE_NAME                                                                 FILE_ID TABLESPACE_NAME           BYTES/1024/1024 MAXBYTES/1024/1024 AUT
---------------------------------------------------------------------- ---------- ------------------------- --------------- ------------------ ---
+DATA/simprod/tempfile/temp.396.997645405                                       1 TEMP                                32767         32767.9844 YES
                                                                                2 TEMP

3/ 
 
col TABLESPACE_NAME for a25
col FILE_NAME for a55
set lines 200
SELECT DBA_TABLESPACES.tablespace_name, file_name, dba_temp_files.BYTES/(1024*1024) MB, DBA_TEMP_FILES.MAXBYTES/(1024*1024) MAX_MB, DBA_TEMP_FILES.INCREMENT_BY/(1024*1024) INC
FROM DBA_TABLESPACES JOIN dba_temp_files
ON DBA_TABLESPACES.TABLESPACE_NAME = dba_temp_files.TABLESPACE_NAME
ORDER BY dba_temp_files.BYTES ASC;
 
OUTPUT:

TABLESPACE_NAME           FILE_NAME                                                       MB     MAX_MB        INC
------------------------- ------------------------------------------------------- ---------- ---------- ----------
TEMP                      +DATA/simprod/tempfile/temp.396.997645405                    32767 32767.9844 .012207031
TEMP

2/
  
set linesize 200
col SID_SERIAL for a15
col USERNAME for a10
col OSUSER for a10
col MODULE for a30
SELECT S.sid || ',' || S.serial# sid_serial, S.username, S.osuser, P.spid, S.module, S.program, SUM (T.blocks) * TBS.block_size / 1024 / 1024 mb_used, T.tablespace, COUNT(*) sort_ops 
FROM v$sort_usage T, v$session S, dba_tablespaces TBS, v$process P
WHERE T.session_addr = S.saddr
AND S.paddr = P.addr
AND T.tablespace = TBS.tablespace_name
Group by S.sid, S.serial#, S.username, S.osuser, P.spid, S.module, S.program, TBS.block_size, T.tablespace
ORDER BY sid_serial; 

OUTPUT:

SID_SERIAL      USERNAME   OSUSER     SPID                     MODULE                         PROGRAM                                             MB_USED TABLESPACE   SORT_OPS
--------------- ---------- ---------- ------------------------ ------------------------------ ------------------------------------------------ ---------- ---------- ----------
1006,46330      FI_DC      _hydro_dcf 24515                    Simulator.exe                  Simulator.exe                                             8 TEMP                8
1008,34886      FI_MC      _fi_pmt_va 2915                     TsRServer.exe                  TsRServer.exe                                             9 TEMP                8
                           lvo3

1013,33368      DCS1       dcs1       10256                    Simulator.exe                  Simulator.exe                                             8 TEMP                8
1015,15504      TOWLEANN   towleann   29354                    Simulator.exe                  Simulator.exe                                             7 TEMP                7

 
1/======Session using temp======/да видя active or inactive са 
 
set linesize 300
SELECT b.TABLESPACE, b.segfile#, b.segblk#, ROUND ((( b.blocks * p.VALUE ) / 1024 / 1024 ), 2 ) size_mb, to_char(a.logon_time, 'MON/DD/YYYY hh24:mi:ss'), a.SID, a.serial#
, a.username, a.osuser, a.program, a.status, a.sql_id
FROM v$session a, v$sort_usage b, v$process c, v$parameter p
WHERE p.NAME = 'db_block_size' AND a.saddr = b.session_addr AND a.paddr = c.addr
ORDER BY b.blocks, b.TABLESPACE, b.segfile#, b.segblk#;

OUTPUT:

TABLESPACE   SEGFILE#    SEGBLK#    SIZE_MB TO_CHAR(A.LOGON_TIME        SID    SERIAL# USERNAME                       OSUSER                              PROGRAM                                          STATUS   SQL_ID
---------- ---------- ---------- ---------- -------------------- ---------- ---------- ------------------------------ ----------------------------------- ------------------------------------------------ -------- -------------
TEMP              201    2863104          1 JUN/14/2019 17:00:07         43      23308 DCS3                           DCS3                                Simulator.exe                                    INACTIVE
TEMP              201    2870272          1 JUN/20/2019 06:11:14        868      11909 AUTO_SIMPSON                   s-spmtpts2                          TsRServer.exe                                    INACTIVE
TEMP              201    2888704          1 JUN/04/2019 18:29:05       1006      46330 FI_DC                          _hydro_dcf                          Simulator.exe                                    INACTIVE
TEMP              201    2895488          1 JUN/21/2019 07:18:46       2027      61544 SYS_NELSON                     _fi_GenerisService                  TsApiServer.exe                                  INACTIVE
TEMP              201    2896512          1 JUN/20/2019 13:56:10        582      39992 ALFHEPER                       alfheper                            TsRServer.exe                                    INACTIVE
TEMP              201    2904320          1 JUN/21/2019 07:23:03       1594      49953 SYS_NELSON                     _fi_GenerisService                  TsApiServer.exe                                  INACTIVE













----------------------------------------------------------


SQL> alter database default temporary tablespace TEMP;

Database altered.

SQL> column property_value format a25
SQL> SELECT property_name,property_value FROM DATABASE_PROPERTIES where PROPERTY_NAME='DEFAULT_TEMP_TABLESPACE';

PROPERTY_NAME             PROPERTY_VALUE
------------------------- -------------------------
DEFAULT_TEMP_TABLESPACE   TEMP











DEFAULT TEMP TABLESPACE HOW TO CHECK:

SQL> select * from database_properties where property_name like '%TABLESPACE%';


TO CHANGE IT:

SQL> ALTER DATABASE DEFAULT TEMPORARY TABLESPACE TEMP2;

Database altered.


------------------

HOW TO CREATE TEMPGROUP

CREATE TEMPORARY TABLESPACE TEMP1 TEMFILE '/DISK1/DEV//DATA/TEMP01.DBF' SIEZE 50M TABLESPACE GROUP TEMPGROUP1;

------------------


IMAME LI TABLESPACE GROUPS:

SQL> SELECT * FROM DBA_TABLESPACE_GROUPS;

no rows selected


SQL> SELECT * FROM DBA_TABLESPACE_GROUPS;

GROUP_NAME                     TABLESPACE_NAME
------------------------------ ------------------------------
TE_GROUP                       TEMP5



SQL> create temporary tablespace TEMP5 tempfile '/disk2/prod1/data/temp05.dbf' size 10m tablespace group TE_GROUP;

Tablespace created.





SQL> SELECT TABLESPACE_NAME, FILE_NAME FROM DBA_TEMP_FILES;

TABLESPACE_NAME                FILE_NAME
------------------------------ --------------------------------------------------
TEMP                           /disk2/prod1/data/temp01.dbf
TEMP2                          /disk2/prod1/data/temp02.dbf
TEMP5                          /disk2/prod1/data/temp05.dbf

SQL> ALTER TABLESPACE TEMP2 TABLESPACE GROUP TE_GROUP;

Tablespace altered.


SQL> SQL> SELECT * FROM DBA_TABLESPACE_GROUPS;

GROUP_NAME                     TABLESPACE_NAME
------------------------------ ------------------------------
TE_GROUP                       TEMP2
TE_GROUP                       TEMP5







SQL> ALTER DATABASE DEFAULT TEMPORARY TABLESPACE TE_GROUP;

Database altered.


COL PROPERTY_NAME FOR A20;
COL DESCRIPTION FOR A50;
COL PROPERTY_VALUE FOR A15;
SELECT * FROM DATABASE_PROPERTIES WHERE PROPERTY_NAME LIKE '%TABLESPACE%';

PROPERTY_NAME           PROPERTY_VALUE  DESCRIPTION
--------------------    --------------- --------------------------------------------------
DEFAULT_TEMP_TABLESPACE TE_GROUP        Name of default temporary tablespace


DEFAULT_PERMANENT_TA    USER_DATA       Name of default permanent tablespace
BLESPACE

