﻿###### ApoBank how to connect ####

user : oracle
pass :  Orakle4u


################
ot hopa
puTTy

Името на сървъра без интервал слагам ----> open 
иска ми user: oracle
иска ми парола: Orakle4u

#### set env
. oraenv
TXSPFBRP

И следвам процедурата за дейтагард

localhost33399   ----> HOP ApoBank

TXSPFBRP dexxtdapo0018    ---> primary DB
TXSPFBRPS dexxtdapo0019  ---> standby DB




#####################
apobank\a-zdravkve@derlapovl0297 
 

         @UC4PROD 
--or--
dgmgrl sys/O4d9P2uFcJKCL38gKxnw         @UC4PROD  
--or--
dgmgrl sys/oracle12                      @UC4PROD  
 


DGMGRL> show configuration

Configuration - dg_trporpro

  Protection Mode: MaxPerformance
  Members:
  trporpro  - Primary database
    trporpros - (*) Physical standby database

Fast-Start Failover: ENABLED

Configuration Status:
SUCCESS   (status updated 43 seconds ago)

DGMGRL> 
 
 
observer  ---> когато я има (*) и ENABLED  , това означава,че мога да не взимам екшън ,сама трябва да се суитчне към стендбая като загасят сървъра
 

 
kogato nqma zvezda i e disabled 
pravi6 : " switchover to 'imeto na bazata s malki bukvi' " ;
 


startup mount

cd $ORACLE_HOME/dbs --->password file


sudo su -
sudo su - oracle



Primary Host: DERLAPOVL0315 
PrimAry DB Name: RCATP 
 




