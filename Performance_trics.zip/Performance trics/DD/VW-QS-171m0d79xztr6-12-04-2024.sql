/********************************************************************************
*********       E-mail subject: VWGSWEB-660
*********             Instance: QS
*********          Description: 
Problem:
Slow query was provided from VQ SQL.

Analysis:
This query was ones analyzed and optimized in VWGSWEB-615, but now an additional condition has been added ( AND client LIKE :B5 ), which "confuses" Oracle which is the most selective path.
The most selective path that can be chosen here is to start the execution from table t_intervenants from "t.refindividu = :B4". For this purpose, table t_intervenants t should be moved into the
FROM clause and be joined with table G_ELEMFI GE through column refdoss as it is made in the New SQL section below.

Suggestion:
Please change the query as it is shown in the New SQL section below.

*********               SQL_ID: 171m0d79xztr6
*********      Program/Package: 
*********              Request: Yordan Kameldzhiev
*********               Author: Dimitar Dimitrov
********* Received e-mail date: 12/04/2024
*********      Resolution date: 12/04/2024
*********  Trace old file here: \\epox\specifs\performance\tmp\
*********  Trace new file here:
***********************************************************************************/

/********************************OLD SQL*******************************************/

VAR B1 VARCHAR2(32);
EXEC :B1 := 'AN';
VAR B2 NUMBER;
EXEC :B2 := 13;
VAR B3 VARCHAR2(32);
EXEC :B3 := 'EUR';
VAR B4 VARCHAR2(32);
EXEC :B4 := 'A90003RT';
VAR B5 VARCHAR2(32);
EXEC :B5 := 'VOL%';
VAR B6 NUMBER;
EXEC :B6 := 201;
VAR B7 NUMBER;
EXEC :B7 := 1;


SELECT *
  FROM (SELECT /*+ first_rows(201)*/
         foo.*, ROWNUM rnum
          FROM (SELECT typeElem typeElem,
                       finElemExtRef finElemExtRef,
                       SUM(balance) OVER() totalBalance,
                       dueDate dueDate,
                       SUM(notPreMatched) OVER() totalNotPreMatched,
                       preMatching preMatching,
                       caseRef caseRef,
                       SUM(finElemAmt) OVER() totalFinElemAmt,
                       balance balance,
                       client client,
                       solde solde,
                       currency currency,
                       notPreMatched notPreMatched,
                       refElem refElem,
                       finElemAmt finElemAmt
                  FROM (SELECT ti.REFDOSS caseRef,
                               ti.REFELEM refElem,
                               ti.TYPEELEM typeElem,
                               GE.REFEXT finElemExtRef,
                               GE.DTDEBUT_DT dueDate,
                               GE.MONTANT_DOS finElemAmt,
                               ICL.Nom client,
                               v1.abrev_trad currency,
                               (SELECT NVL(SUM(montant_dos), 0)
                                  FROM g_prelettrage
                                 WHERE typelem = ti.typeelem
                                   AND refelem = ti.refelem) preMatching,
                               NVL(GE.montant_dos, 0) -
                               NVL(Ftr_Match.LettrReelDette(ti.refelem,ti.typeelem,''),0) balance,
                               GE.MONTANT_DOS - NVL(Ftr_Match.LettrReelDette(ti.refelem, ti.typeelem,ti.abrev), 0) - ( SELECT NVL(SUM(montant_dos), 0)
                                                                                                                         FROM g_prelettrage
                                                                                                                        WHERE typelem = ti.typeelem
                                                                                                                          AND refelem = ti.refelem) notPreMatched,
                               NVL(GE.MONTANT_DOS, 0) - NVL(ge.matched_amt, 0) - NVL(( SELECT NVL(SUM(montant_dos), 0)
                                                                                         FROM g_prelettrage
                                                                                        WHERE typelem = ti.typeelem
                                                                                          AND refelem = ti.refelem) , 0) solde
                          FROM T_ELEMENTS ti,
                               G_ELEMFI GE,
                               G_DOSSIER D,
                               V_ELEMFI V,
                               t_intervenants CL,
                               g_individu ICL,
                               (SELECT abrev, max(abrev_trad) abrev_trad
                                  FROM v_tdomaine td
                                 WHERE td.langue = :B1
                                   AND td.type = 'DEVISE'
                                 GROUP BY abrev) v1
                         WHERE ge.refelem = ti.refelem
                           AND ge.montant >= 0
                           AND D.refdoss = ti.REFDOSS
                           AND CL.refdoss = D.refdoss
                           AND D.devise = v1.abrev
                           AND CL.reftype =
                               DECODE(D.categdoss, 'COMPTE IMP', 'TC', 'CL')
                           AND ICL.refindividu = CL.refindividu
                           AND NVL(GE.libelle, 'X') <> 'TOLERANCE AMOUNT'
                           AND ti.typeelem = 'fi'
                           AND GE.TYPE = V.TYPE
                           AND V.cession = 'O'
                           AND ti.libelle not like '%MVT MIGRATION CTX%'
                           AND NVL(ti.Libelle, 'X') NOT LIKE
                               'REMBOURSEMENT NC%'
                           AND D.reffactor IN
                               (SELECT FF.refindividu
                                  FROM t_gestfctcomp CC,
                                       g_mangrp      GG,
                                       t_fctmembmg   FF
                                 WHERE CC.refmangrp = GG.refmangrp
                                   AND GG.refmangrp = FF.refmangrp
                                   AND CC.refperso = :B2)
                           AND ti.devise_dos LIKE :B3
                           AND (GE.MONTANT_DOS -
                               (SELECT NVL(SUM(montant_dos), 0)
                                   FROM g_prelettrage
                                  WHERE typelem = ti.typeelem
                                    AND refelem = ti.refelem) -
                               (SELECT NVL(SUM(montant_dos), 0)
                                   FROM g_venelem
                                  WHERE typelem = ti.typeelem
                                    AND refelem = ti.refelem) > 0)
                           AND GE.actif = 'O'
                           AND GE.refdoss IN (SELECT t.refdoss refd
                                                FROM t_intervenants t
                                               WHERE t.refindividu = :B4
                                                 and T.reftype = 'DB')) T_ELEMENTS
                 WHERE 1 = 1
                   AND client LIKE :B5
                 ORDER BY finelemextref ASC, client) foo
         WHERE ROWNUM <= :B6)
 WHERE 1 = 1
   AND rnum >= :B7;
/********************************OLD SQL*******************************************/
/********************************OLD Metrics***************************************/
/*

MODULE                    SQL_ID         PLAN_HASH SID    SERIAL# EVENT                          FROM                           TO                                 ACTIVE NUMBER_OF_EXECUTIONS PERC
------------------------- ------------- ---------- ------ ------- ------------------------------ ------------------------------ ------------------------------ ---------- -------------------- ------
B1AFF2E9377C0A52582381148 171m0d79xztr6 1741572868 1439   5816    db file sequential read        2024/04/08 07:49:07            2024/04/08 07:51:57                   110       1 58%
34BC0BB

B1AFF2E9377C0A52582381148 171m0d79xztr6 1741572868 1439   5816    read by other session          2024/04/08 07:50:27            2024/04/08 07:51:37                    60       1 32%
34BC0BB

B1AFF2E9377C0A52582381148 171m0d79xztr6            1439   5816    ON CPU                         2024/04/08 07:48:57            2024/04/08 07:49:17                    20       1 11%
34BC0BB

MODULE                    SQL_ID         PLAN_HASH SID    SERIAL# EVENT                          FROM                           TO                                 ACTIVE NUMBER_OF_EXECUTIONS PERC
------------------------- ------------- ---------- ------ ------- ------------------------------ ------------------------------ ------------------------------ ---------- -------------------- ------
B1AFF2E9377C0A52582381148 171m0d79xztr6            1439   5816                                   2024/04/08 07:48:57            2024/04/08 07:51:57                   190       1 100%


Plan hash value: 1741572868
----------------------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                       | Name                   | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  |
----------------------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                                |                        |      1 |        |    24 (100)|     72 |00:00:05.40 |    1749K|     38 |
|   1 |  SORT AGGREGATE                                 |                        |     74 |      1 |            |     74 |00:00:00.01 |      75 |      0 |
|*  2 |   TABLE ACCESS BY INDEX ROWID BATCHED           | G_PRELETTRAGE          |     74 |      1 |     1   (0)|      0 |00:00:00.01 |      75 |      0 |
|*  3 |    INDEX RANGE SCAN                             | G_PREL_ELEM            |     74 |      1 |     1   (0)|      0 |00:00:00.01 |      75 |      0 |
|   4 |  SORT AGGREGATE                                 |                        |     72 |      1 |            |     72 |00:00:00.01 |      62 |      0 |
|*  5 |   TABLE ACCESS BY INDEX ROWID BATCHED           | G_PRELETTRAGE          |     72 |      1 |     1   (0)|      0 |00:00:00.01 |      62 |      0 |
|*  6 |    INDEX RANGE SCAN                             | G_PREL_ELEM            |     72 |      1 |     1   (0)|      0 |00:00:00.01 |      62 |      0 |
|   7 |  SORT AGGREGATE                                 |                        |     72 |      1 |            |     72 |00:00:00.01 |      62 |      0 |
|*  8 |   TABLE ACCESS BY INDEX ROWID BATCHED           | G_PRELETTRAGE          |     72 |      1 |     1   (0)|      0 |00:00:00.01 |      62 |      0 |
|*  9 |    INDEX RANGE SCAN                             | G_PREL_ELEM            |     72 |      1 |     1   (0)|      0 |00:00:00.01 |      62 |      0 |
|* 10 |  VIEW                                           |                        |      1 |      1 |    24   (0)|     72 |00:00:05.40 |    1749K|     38 |
|* 11 |   COUNT STOPKEY                                 |                        |      1 |        |            |     72 |00:00:05.40 |    1749K|     38 |
|  12 |    VIEW                                         |                        |      1 |      1 |    24   (0)|     72 |00:00:05.40 |    1749K|     38 |
|  13 |     WINDOW SORT                                 |                        |      1 |      1 |    24   (0)|     72 |00:00:05.40 |    1748K|     38 |
|* 14 |      FILTER                                     |                        |      1 |        |            |     72 |00:00:05.39 |    1747K|     38 |
|  15 |       NESTED LOOPS                              |                        |      1 |      1 |    17   (0)|     74 |00:00:05.39 |    1747K|     38 |
|  16 |        NESTED LOOPS                             |                        |      1 |      1 |     7   (0)|     74 |00:00:05.39 |    1747K|     38 |
|  17 |         NESTED LOOPS SEMI                       |                        |      1 |      1 |     6   (0)|     74 |00:00:05.39 |    1747K|     38 |
|  18 |          NESTED LOOPS                           |                        |      1 |      6 |     5   (0)|   9964 |00:00:05.38 |    1746K|     38 |
|  19 |           NESTED LOOPS                          |                        |      1 |      6 |     4   (0)|   1470K|00:00:02.08 |     348K|      0 |
|  20 |            NESTED LOOPS                         |                        |      1 |      3 |     3   (0)|    466 |00:00:00.01 |    1476 |      0 |
|  21 |             NESTED LOOPS                        |                        |      1 |     13 |     2   (0)|   1065 |00:00:00.01 |      93 |      0 |
|  22 |              TABLE ACCESS BY INDEX ROWID BATCHED| G_INDIVIDU             |      1 |      1 |     1   (0)|     43 |00:00:00.01 |      43 |      0 |
|* 23 |               INDEX RANGE SCAN                  | G_INDIV_NOM_PROF       |      1 |      1 |     1   (0)|     43 |00:00:00.01 |       2 |      0 |
|* 24 |              INDEX RANGE SCAN                   | INT_INDIV              |     43 |     12 |     1   (0)|   1065 |00:00:00.01 |      50 |      0 |
|* 25 |             TABLE ACCESS BY INDEX ROWID         | G_DOSSIER              |   1065 |      1 |     1   (0)|    466 |00:00:00.01 |    1383 |      0 |
|* 26 |              INDEX UNIQUE SCAN                  | DOS_REFDOSS            |   1065 |      1 |     1   (0)|   1065 |00:00:00.01 |     321 |      0 |
|* 27 |            TABLE ACCESS BY INDEX ROWID BATCHED  | T_ELEMENTS             |    466 |      2 |     1   (0)|   1470K|00:00:01.92 |     347K|      0 |
|* 28 |             INDEX RANGE SCAN                    | ELE_DOSS_TYP_ASSOC_LIB |    466 |     81 |     1   (0)|   1625K|00:00:00.59 |   10081 |      0 |
|* 29 |           TABLE ACCESS BY INDEX ROWID           | G_ELEMFI               |   1470K|      1 |     1   (0)|   9964 |00:00:03.07 |    1398K|     38 |
|* 30 |            INDEX UNIQUE SCAN                    | EFI_REFELEM            |   1470K|      1 |     1   (0)|   1470K|00:00:01.11 |     741K|      6 |
|* 31 |          INDEX RANGE SCAN                       | INT_REFDOSS            |   9964 |      1 |     1   (0)|     74 |00:00:00.01 |      83 |      0 |
|* 32 |         TABLE ACCESS BY INDEX ROWID BATCHED     | V_ELEMFI               |     74 |      1 |     1   (0)|     74 |00:00:00.01 |       4 |      0 |
|* 33 |          INDEX RANGE SCAN                       | VF_TYPE_FINANCING      |     74 |      1 |     1   (0)|     74 |00:00:00.01 |       3 |      0 |
|  34 |        VIEW PUSHED PREDICATE                    |                        |     74 |      1 |    10   (0)|     74 |00:00:00.01 |     153 |      0 |
|* 35 |         FILTER                                  |                        |     74 |        |            |     74 |00:00:00.01 |     153 |      0 |
|  36 |          SORT AGGREGATE                         |                        |     74 |      1 |            |     74 |00:00:00.01 |     153 |      0 |
|  37 |           VIEW                                  | V_TDOMAINE             |     74 |     10 |    10   (0)|     74 |00:00:00.01 |     153 |      0 |
|  38 |            UNION-ALL                            |                        |     74 |        |            |     74 |00:00:00.01 |     153 |      0 |
|* 39 |             FILTER                              |                        |     74 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  40 |              TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 41 |               INDEX RANGE SCAN                  | DOM_TYPABREV           |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 42 |             FILTER                              |                        |     74 |        |            |     74 |00:00:00.01 |     153 |      0 |
|  43 |              TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE              |     74 |      1 |     1   (0)|     74 |00:00:00.01 |     153 |      0 |
|* 44 |               INDEX RANGE SCAN                  | DOM_TYPABREV           |     74 |      1 |     1   (0)|     74 |00:00:00.01 |      79 |      0 |
|* 45 |             FILTER                              |                        |     74 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  46 |              TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 47 |               INDEX RANGE SCAN                  | DOM_TYPABREV           |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 48 |             FILTER                              |                        |     74 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  49 |              TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 50 |               INDEX RANGE SCAN                  | DOM_TYPABREV           |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 51 |             FILTER                              |                        |     74 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  52 |              TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 53 |               INDEX RANGE SCAN                  | DOM_TYPABREV           |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 54 |             FILTER                              |                        |     74 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  55 |              TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 56 |               INDEX RANGE SCAN                  | DOM_TYPABREV           |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 57 |             FILTER                              |                        |     74 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  58 |              TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 59 |               INDEX RANGE SCAN                  | DOM_TYPABREV           |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 60 |             FILTER                              |                        |     74 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  61 |              TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 62 |               INDEX RANGE SCAN                  | DOM_TYPABREV           |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 63 |             FILTER                              |                        |     74 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  64 |              TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 65 |               INDEX RANGE SCAN                  | DOM_TYPABREV           |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 66 |             FILTER                              |                        |     74 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  67 |              TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 68 |               INDEX RANGE SCAN                  | DOM_TYPABREV           |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|  69 |       NESTED LOOPS                              |                        |      1 |      1 |     3   (0)|      1 |00:00:00.01 |       3 |      0 |
|  70 |        NESTED LOOPS                             |                        |      1 |      1 |     2   (0)|      1 |00:00:00.01 |       2 |      0 |
|* 71 |         INDEX RANGE SCAN                        | PK_T_FCTMEMBMG         |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       1 |      0 |
|* 72 |         INDEX UNIQUE SCAN                       | PK_G_MANGRP            |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       1 |      0 |
|* 73 |        INDEX UNIQUE SCAN                        | PK_T_GESTFCTCOMP       |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       1 |      0 |
|  74 |       SORT AGGREGATE                            |                        |     74 |      1 |            |     74 |00:00:00.01 |      72 |      0 |
|* 75 |        TABLE ACCESS BY INDEX ROWID BATCHED      | G_PRELETTRAGE          |     74 |      1 |     1   (0)|      2 |00:00:00.01 |      72 |      0 |
|* 76 |         INDEX RANGE SCAN                        | G_PREL_ELEM            |     74 |      1 |     1   (0)|      2 |00:00:00.01 |      71 |      0 |
|  77 |       SORT AGGREGATE                            |                        |     74 |      1 |            |     74 |00:00:00.01 |     152 |      0 |
|* 78 |        TABLE ACCESS BY INDEX ROWID BATCHED      | G_VENELEM              |     74 |      1 |     1   (0)|      0 |00:00:00.01 |     152 |      0 |
|* 79 |         INDEX RANGE SCAN                        | VEN_ELEM               |     74 |      1 |     1   (0)|      0 |00:00:00.01 |     152 |      0 |
----------------------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   2 - filter("TYPELEM"=:B1)
   3 - access("REFELEM"=:B1)
   5 - filter("TYPELEM"=:B1)
   6 - access("REFELEM"=:B1)
   8 - filter("TYPELEM"=:B1)
   9 - access("REFELEM"=:B1)
  10 - filter("RNUM">=:B7)
  11 - filter(ROWNUM<=:B6)
  14 - filter(( IS NOT NULL AND "GE"."MONTANT_DOS"-->0))
  23 - access("ICL"."NOM" LIKE :B5)
       filter("ICL"."NOM" LIKE :B5)
  24 - access("ICL"."REFINDIVIDU"="CL"."REFINDIVIDU")
  25 - filter("CL"."REFTYPE"=DECODE("D"."CATEGDOSS",'COMPTE IMP','TC','CL'))
  26 - access("CL"."REFDOSS"="D"."REFDOSS")
  27 - filter("TI"."DEVISE_DOS" LIKE :B3)
  28 - access("D"."REFDOSS"="TI"."REFDOSS" AND "TI"."TYPEELEM"='fi')
       filter((NVL("TI"."LIBELLE",'X') NOT LIKE 'REMBOURSEMENT NC%' AND "TI"."LIBELLE" NOT LIKE '%MVT MIGRATION CTX%' AND "TI"."LIBELLE" IS NOT
              NULL))
  29 - filter(("GE"."ACTIF"='O' AND "GE"."MONTANT">=0 AND NVL("GE"."LIBELLE",'X')<>'TOLERANCE AMOUNT'))
  30 - access("GE"."REFELEM"="TI"."REFELEM")
  31 - access("GE"."REFDOSS"="T"."REFDOSS" AND "T"."REFTYPE"='DB' AND "T"."REFINDIVIDU"=:B4)
  32 - filter("V"."CESSION"='O')
  33 - access("GE"."TYPE"="V"."TYPE")
  35 - filter(COUNT(*)>0)
  39 - filter('AL'=:B1)
  41 - access("TYPE"='DEVISE' AND "ABREV"="D"."DEVISE")
  42 - filter('AN'=:B1)
  44 - access("TYPE"='DEVISE' AND "ABREV"="D"."DEVISE")
  45 - filter('DA'=:B1)
  47 - access("TYPE"='DEVISE' AND "ABREV"="D"."DEVISE")
  48 - filter('ES'=:B1)
  50 - access("TYPE"='DEVISE' AND "ABREV"="D"."DEVISE")
  51 - filter('FI'=:B1)
  53 - access("TYPE"='DEVISE' AND "ABREV"="D"."DEVISE")
  54 - filter('FR'=:B1)
  56 - access("TYPE"='DEVISE' AND "ABREV"="D"."DEVISE")
  57 - filter('IT'=:B1)
  59 - access("TYPE"='DEVISE' AND "ABREV"="D"."DEVISE")
  60 - filter('NL'=:B1)
  62 - access("TYPE"='DEVISE' AND "ABREV"="D"."DEVISE")
  63 - filter('NO'=:B1)
  65 - access("TYPE"='DEVISE' AND "ABREV"="D"."DEVISE")
  66 - filter('PT'=:B1)
  68 - access("TYPE"='DEVISE' AND "ABREV"="D"."DEVISE")
  71 - access("FF"."REFINDIVIDU"=:B1)
  72 - access("GG"."REFMANGRP"="FF"."REFMANGRP")
  73 - access("CC"."REFPERSO"=:B2 AND "CC"."REFMANGRP"="GG"."REFMANGRP")
  75 - filter("TYPELEM"=:B1)
  76 - access("REFELEM"=:B1)
  78 - filter("TYPELEM"=:B1)
  79 - access("REFELEM"=:B1)
*/
/********************************OLD Metrics***************************************/

/********************************New SQL*******************************************/

VAR B1 VARCHAR2(32);
EXEC :B1 := 'AN';
VAR B2 NUMBER;
EXEC :B2 := 13;
VAR B3 VARCHAR2(32);
EXEC :B3 := 'EUR';
VAR B4 VARCHAR2(32);
EXEC :B4 := 'A90003RT';
VAR B5 VARCHAR2(32);
EXEC :B5 := 'VOL%';
VAR B6 NUMBER;
EXEC :B6 := 201;
VAR B7 NUMBER;
EXEC :B7 := 1;


SELECT *
  FROM (SELECT /*+ first_rows(201)*/
         foo.*, ROWNUM rnum
          FROM (SELECT typeElem typeElem,
                       finElemExtRef finElemExtRef,
                       SUM(balance) OVER() totalBalance,
                       dueDate dueDate,
                       SUM(notPreMatched) OVER() totalNotPreMatched,
                       preMatching preMatching,
                       caseRef caseRef,
                       SUM(finElemAmt) OVER() totalFinElemAmt,
                       balance balance,
                       client client,
                       solde solde,
                       currency currency,
                       notPreMatched notPreMatched,
                       refElem refElem,
                       finElemAmt finElemAmt
                  FROM (SELECT ti.REFDOSS caseRef,
                               ti.REFELEM refElem,
                               ti.TYPEELEM typeElem,
                               GE.REFEXT finElemExtRef,
                               GE.DTDEBUT_DT dueDate,
                               GE.MONTANT_DOS finElemAmt,
                               ICL.Nom client,
                               v1.abrev_trad currency,
                               (SELECT NVL(SUM(montant_dos), 0)
                                  FROM g_prelettrage
                                 WHERE typelem = ti.typeelem
                                   AND refelem = ti.refelem) preMatching,
                               NVL(GE.montant_dos, 0) -
                               NVL(Ftr_Match.LettrReelDette(ti.refelem,ti.typeelem,''),0) balance,
                               GE.MONTANT_DOS - NVL(Ftr_Match.LettrReelDette(ti.refelem, ti.typeelem,ti.abrev), 0) - ( SELECT NVL(SUM(montant_dos), 0)
                                                                                                                         FROM g_prelettrage
                                                                                                                        WHERE typelem = ti.typeelem
                                                                                                                          AND refelem = ti.refelem) notPreMatched,
                               NVL(GE.MONTANT_DOS, 0) - NVL(ge.matched_amt, 0) - NVL(( SELECT NVL(SUM(montant_dos), 0)
                                                                                         FROM g_prelettrage
                                                                                        WHERE typelem = ti.typeelem
                                                                                          AND refelem = ti.refelem) , 0) solde
                          FROM T_ELEMENTS ti,
                               G_ELEMFI GE,
                               G_DOSSIER D,
                               V_ELEMFI V,
                               t_intervenants CL,
                               g_individu ICL,
                               t_intervenants t,
                               (SELECT abrev, max(abrev_trad) abrev_trad
                                  FROM v_tdomaine td
                                 WHERE td.langue = :B1
                                   AND td.type = 'DEVISE'
                                 GROUP BY abrev) v1
                         WHERE ge.refelem = ti.refelem
                           AND ge.montant >= 0
                           AND D.refdoss = ti.REFDOSS
                           AND CL.refdoss = D.refdoss
                           AND D.devise = v1.abrev
                           AND CL.reftype = DECODE(D.categdoss, 'COMPTE IMP', 'TC', 'CL')
                           AND ICL.refindividu = CL.refindividu
                           AND NVL(GE.libelle, 'X') <> 'TOLERANCE AMOUNT'
                           AND ti.typeelem = 'fi'
                           AND GE.TYPE = V.TYPE
                           AND V.cession = 'O'
                           AND ti.libelle not like '%MVT MIGRATION CTX%'
                           AND NVL(ti.Libelle, 'X') NOT LIKE
                               'REMBOURSEMENT NC%'
                           AND D.reffactor IN
                               (SELECT FF.refindividu
                                  FROM t_gestfctcomp CC,
                                       g_mangrp      GG,
                                       t_fctmembmg   FF
                                 WHERE CC.refmangrp = GG.refmangrp
                                   AND GG.refmangrp = FF.refmangrp
                                   AND CC.refperso = :B2)
                           AND ti.devise_dos LIKE :B3
                           AND (GE.MONTANT_DOS -
                               (SELECT NVL(SUM(montant_dos), 0)
                                   FROM g_prelettrage
                                  WHERE typelem = ti.typeelem
                                    AND refelem = ti.refelem) -
                               (SELECT NVL(SUM(montant_dos), 0)
                                   FROM g_venelem
                                  WHERE typelem = ti.typeelem
                                    AND refelem = ti.refelem) > 0)
                           AND GE.actif = 'O'
                           AND GE.refdoss = t.refdoss 
                           AND t.refindividu = :B4
                           and T.reftype = 'DB') T_ELEMENTS
                 WHERE 1 = 1
                   AND client LIKE :B5
                 ORDER BY finelemextref ASC, client) foo
         WHERE ROWNUM <= :B6)
 WHERE 1 = 1
   AND rnum >= :B7;

/********************************New SQL*******************************************/
/********************************New Metrics***************************************/
/*
Plan hash value: 3239043215
----------------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                          | Name                   | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers |
----------------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                                   |                        |      1 |        |    24 (100)|     72 |00:00:00.02 |    3098 |
|   1 |  SORT AGGREGATE                                    |                        |     74 |      1 |            |     74 |00:00:00.01 |      75 |
|*  2 |   TABLE ACCESS BY INDEX ROWID BATCHED              | G_PRELETTRAGE          |     74 |      1 |     1   (0)|      0 |00:00:00.01 |      75 |
|*  3 |    INDEX RANGE SCAN                                | G_PREL_ELEM            |     74 |      1 |     1   (0)|      0 |00:00:00.01 |      75 |
|   4 |  SORT AGGREGATE                                    |                        |     72 |      1 |            |     72 |00:00:00.01 |      62 |
|*  5 |   TABLE ACCESS BY INDEX ROWID BATCHED              | G_PRELETTRAGE          |     72 |      1 |     1   (0)|      0 |00:00:00.01 |      62 |
|*  6 |    INDEX RANGE SCAN                                | G_PREL_ELEM            |     72 |      1 |     1   (0)|      0 |00:00:00.01 |      62 |
|   7 |  SORT AGGREGATE                                    |                        |     72 |      1 |            |     72 |00:00:00.01 |      62 |
|*  8 |   TABLE ACCESS BY INDEX ROWID BATCHED              | G_PRELETTRAGE          |     72 |      1 |     1   (0)|      0 |00:00:00.01 |      62 |
|*  9 |    INDEX RANGE SCAN                                | G_PREL_ELEM            |     72 |      1 |     1   (0)|      0 |00:00:00.01 |      62 |
|* 10 |  VIEW                                              |                        |      1 |      1 |    24   (0)|     72 |00:00:00.02 |    3098 |
|* 11 |   COUNT STOPKEY                                    |                        |      1 |        |            |     72 |00:00:00.02 |    3098 |
|  12 |    VIEW                                            |                        |      1 |      1 |    24   (0)|     72 |00:00:00.02 |    3098 |
|  13 |     WINDOW SORT                                    |                        |      1 |      1 |    24   (0)|     72 |00:00:00.01 |    2106 |
|  14 |      NESTED LOOPS SEMI                             |                        |      1 |      1 |    20   (0)|     72 |00:00:00.01 |    1171 |
|  15 |       NESTED LOOPS                                 |                        |      1 |      1 |    17   (0)|     72 |00:00:00.01 |    1160 |
|  16 |        NESTED LOOPS                                |                        |      1 |      1 |    16   (0)|     72 |00:00:00.01 |    1156 |
|  17 |         NESTED LOOPS                               |                        |      1 |      1 |    15   (0)|     88 |00:00:00.01 |    1136 |
|  18 |          NESTED LOOPS                              |                        |      1 |      1 |    14   (0)|     88 |00:00:00.01 |    1116 |
|  19 |           NESTED LOOPS                             |                        |      1 |      1 |     4   (0)|     88 |00:00:00.01 |     935 |
|  20 |            NESTED LOOPS                            |                        |      1 |      1 |     3   (0)|     88 |00:00:00.01 |     827 |
|  21 |             NESTED LOOPS                           |                        |      1 |     32 |     2   (0)|    115 |00:00:00.01 |     138 |
|* 22 |              INDEX RANGE SCAN                      | INT_INDIV              |      1 |      2 |     1   (0)|      7 |00:00:00.01 |       2 |
|* 23 |              TABLE ACCESS BY INDEX ROWID BATCHED   | G_ELEMFI               |      7 |     18 |     1   (0)|    115 |00:00:00.01 |     136 |
|* 24 |               INDEX RANGE SCAN                     | G_ELEMFI$REFDOSS_ACTIF |      7 |     35 |     1   (0)|    115 |00:00:00.01 |      23 |
|* 25 |             TABLE ACCESS BY INDEX ROWID BATCHED    | T_ELEMENTS             |    115 |      1 |     1   (0)|     88 |00:00:00.01 |     689 |
|* 26 |              INDEX RANGE SCAN                      | ELE_ELEMTYPE           |    115 |      1 |     1   (0)|     88 |00:00:00.01 |     603 |
|  27 |               SORT AGGREGATE                       |                        |    115 |      1 |            |    115 |00:00:00.01 |     136 |
|* 28 |                TABLE ACCESS BY INDEX ROWID BATCHED | G_PRELETTRAGE          |    115 |      1 |     1   (0)|     29 |00:00:00.01 |     136 |
|* 29 |                 INDEX RANGE SCAN                   | G_PREL_ELEM            |    115 |      1 |     1   (0)|     29 |00:00:00.01 |     112 |
|  30 |               SORT AGGREGATE                       |                        |    115 |      1 |            |    115 |00:00:00.01 |     234 |
|* 31 |                TABLE ACCESS BY INDEX ROWID BATCHED | G_VENELEM              |    115 |      1 |     1   (0)|      0 |00:00:00.01 |     234 |
|* 32 |                 INDEX RANGE SCAN                   | VEN_ELEM               |    115 |      1 |     1   (0)|      0 |00:00:00.01 |     234 |
|  33 |            TABLE ACCESS BY INDEX ROWID             | G_DOSSIER              |     88 |      1 |     1   (0)|     88 |00:00:00.01 |     108 |
|* 34 |             INDEX UNIQUE SCAN                      | DOS_REFDOSS            |     88 |      1 |     1   (0)|     88 |00:00:00.01 |      16 |
|  35 |           VIEW PUSHED PREDICATE                    |                        |     88 |      1 |    10   (0)|     88 |00:00:00.01 |     181 |
|* 36 |            FILTER                                  |                        |     88 |        |            |     88 |00:00:00.01 |     181 |
|  37 |             SORT AGGREGATE                         |                        |     88 |      1 |            |     88 |00:00:00.01 |     181 |
|  38 |              VIEW                                  | V_TDOMAINE             |     88 |     10 |    10   (0)|     88 |00:00:00.01 |     181 |
|  39 |               UNION-ALL                            |                        |     88 |        |            |     88 |00:00:00.01 |     181 |
|* 40 |                FILTER                              |                        |     88 |        |            |      0 |00:00:00.01 |       0 |
|  41 |                 TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 42 |                  INDEX RANGE SCAN                  | DOM_TYPABREV           |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 43 |                FILTER                              |                        |     88 |        |            |     88 |00:00:00.01 |     181 |
|  44 |                 TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE              |     88 |      1 |     1   (0)|     88 |00:00:00.01 |     181 |
|* 45 |                  INDEX RANGE SCAN                  | DOM_TYPABREV           |     88 |      1 |     1   (0)|     88 |00:00:00.01 |      93 |
|* 46 |                FILTER                              |                        |     88 |        |            |      0 |00:00:00.01 |       0 |
|  47 |                 TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 48 |                  INDEX RANGE SCAN                  | DOM_TYPABREV           |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 49 |                FILTER                              |                        |     88 |        |            |      0 |00:00:00.01 |       0 |
|  50 |                 TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 51 |                  INDEX RANGE SCAN                  | DOM_TYPABREV           |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 52 |                FILTER                              |                        |     88 |        |            |      0 |00:00:00.01 |       0 |
|  53 |                 TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 54 |                  INDEX RANGE SCAN                  | DOM_TYPABREV           |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 55 |                FILTER                              |                        |     88 |        |            |      0 |00:00:00.01 |       0 |
|  56 |                 TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 57 |                  INDEX RANGE SCAN                  | DOM_TYPABREV           |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 58 |                FILTER                              |                        |     88 |        |            |      0 |00:00:00.01 |       0 |
|  59 |                 TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 60 |                  INDEX RANGE SCAN                  | DOM_TYPABREV           |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 61 |                FILTER                              |                        |     88 |        |            |      0 |00:00:00.01 |       0 |
|  62 |                 TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 63 |                  INDEX RANGE SCAN                  | DOM_TYPABREV           |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 64 |                FILTER                              |                        |     88 |        |            |      0 |00:00:00.01 |       0 |
|  65 |                 TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 66 |                  INDEX RANGE SCAN                  | DOM_TYPABREV           |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 67 |                FILTER                              |                        |     88 |        |            |      0 |00:00:00.01 |       0 |
|  68 |                 TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 69 |                  INDEX RANGE SCAN                  | DOM_TYPABREV           |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 70 |          INDEX RANGE SCAN                          | INT_REFDOSS            |     88 |      1 |     1   (0)|     88 |00:00:00.01 |      20 |
|* 71 |         TABLE ACCESS BY INDEX ROWID                | G_INDIVIDU             |     88 |      1 |     1   (0)|     72 |00:00:00.01 |      20 |
|* 72 |          INDEX UNIQUE SCAN                         | IND_REFINDIV           |     88 |      1 |     1   (0)|     88 |00:00:00.01 |      16 |
|* 73 |        TABLE ACCESS BY INDEX ROWID BATCHED         | V_ELEMFI               |     72 |      1 |     1   (0)|     72 |00:00:00.01 |       4 |
|* 74 |         INDEX RANGE SCAN                           | VF_TYPE_FINANCING      |     72 |      1 |     1   (0)|     72 |00:00:00.01 |       3 |
|  75 |       VIEW PUSHED PREDICATE                        | VW_NSO_1               |     72 |      1 |     3   (0)|     72 |00:00:00.01 |      11 |
|  76 |        NESTED LOOPS                                |                        |     72 |      1 |     3   (0)|     72 |00:00:00.01 |      11 |
|  77 |         NESTED LOOPS                               |                        |     72 |      1 |     2   (0)|     72 |00:00:00.01 |       7 |
|* 78 |          INDEX RANGE SCAN                          | PK_T_FCTMEMBMG         |     72 |      1 |     1   (0)|     72 |00:00:00.01 |       3 |
|* 79 |          INDEX UNIQUE SCAN                         | PK_G_MANGRP            |     72 |      1 |     1   (0)|     72 |00:00:00.01 |       4 |
|* 80 |         INDEX UNIQUE SCAN                          | PK_T_GESTFCTCOMP       |     72 |      1 |     1   (0)|     72 |00:00:00.01 |       4 |
----------------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   2 - filter("TYPELEM"=:B1)
   3 - access("REFELEM"=:B1)
   5 - filter("TYPELEM"=:B1)
   6 - access("REFELEM"=:B1)
   8 - filter("TYPELEM"=:B1)
   9 - access("REFELEM"=:B1)
  10 - filter("RNUM">=:B7)
  11 - filter(ROWNUM<=:B6)
  22 - access("T"."REFINDIVIDU"=:B4 AND "T"."REFTYPE"='DB')
  23 - filter(("GE"."MONTANT">=0 AND NVL("GE"."LIBELLE",'X')<>'TOLERANCE AMOUNT'))
  24 - access("GE"."REFDOSS"="T"."REFDOSS" AND "GE"."ACTIF"='O')
  25 - filter(("TI"."DEVISE_DOS" LIKE :B3 AND NVL("TI"."LIBELLE",'X') NOT LIKE 'REMBOURSEMENT NC%' AND "TI"."LIBELLE" NOT LIKE '%MVT
              MIGRATION CTX%' AND "TI"."LIBELLE" IS NOT NULL))
  26 - access("GE"."REFELEM"="TI"."REFELEM" AND "TI"."TYPEELEM"='fi')
       filter("GE"."MONTANT_DOS"-->0)
  28 - filter("TYPELEM"=:B1)
  29 - access("REFELEM"=:B1)
  31 - filter("TYPELEM"=:B1)
  32 - access("REFELEM"=:B1)
  34 - access("D"."REFDOSS"="TI"."REFDOSS")
  36 - filter(COUNT(*)>0)
  40 - filter('AL'=:B1)
  42 - access("TYPE"='DEVISE' AND "ABREV"="D"."DEVISE")
  43 - filter('AN'=:B1)
  45 - access("TYPE"='DEVISE' AND "ABREV"="D"."DEVISE")
  46 - filter('DA'=:B1)
  48 - access("TYPE"='DEVISE' AND "ABREV"="D"."DEVISE")
  49 - filter('ES'=:B1)
  51 - access("TYPE"='DEVISE' AND "ABREV"="D"."DEVISE")
  52 - filter('FI'=:B1)
  54 - access("TYPE"='DEVISE' AND "ABREV"="D"."DEVISE")
  55 - filter('FR'=:B1)
  57 - access("TYPE"='DEVISE' AND "ABREV"="D"."DEVISE")
  58 - filter('IT'=:B1)
  60 - access("TYPE"='DEVISE' AND "ABREV"="D"."DEVISE")
  61 - filter('NL'=:B1)
  63 - access("TYPE"='DEVISE' AND "ABREV"="D"."DEVISE")
  64 - filter('NO'=:B1)
  66 - access("TYPE"='DEVISE' AND "ABREV"="D"."DEVISE")
  67 - filter('PT'=:B1)
  69 - access("TYPE"='DEVISE' AND "ABREV"="D"."DEVISE")
  70 - access("CL"."REFDOSS"="D"."REFDOSS" AND "CL"."REFTYPE"=DECODE("D"."CATEGDOSS",'COMPTE IMP','TC','CL'))
  71 - filter("ICL"."NOM" LIKE :B5)
  72 - access("ICL"."REFINDIVIDU"="CL"."REFINDIVIDU")
  73 - filter("V"."CESSION"='O')
  74 - access("GE"."TYPE"="V"."TYPE")
  78 - access("FF"."REFINDIVIDU"="D"."REFFACTOR")
  79 - access("GG"."REFMANGRP"="FF"."REFMANGRP")
  80 - access("CC"."REFPERSO"=:B2 AND "CC"."REFMANGRP"="GG"."REFMANGRP")
*/
/********************************New Metrics***************************************/

/********************************Index statistics**********************************/

/********************************Other SQLs****************************************/          
/*

*/ 
/********************************Other SQLs****************************************/              
