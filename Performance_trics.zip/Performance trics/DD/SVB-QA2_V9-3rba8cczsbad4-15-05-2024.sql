/********************************************************************************
*********       E-mail subject: SVBDEV-7618
*********             Instance: QA2 V9
*********          Description: 
Problem:
SQL 3rba8cczsbad4 was found in AWR Report in task PT-14.

Analysis:
The main problem with this SQL is that table T_INTERVENANTS is accesed through column REFTYPE instead through the REFDOSS from table 
G_DOSSIER, which costs more buffer gets. To optimize this, we should add hint and force Oracle to access table T_INTERVENANTS through the REFDOSS.

Suggestion:
Please add hint as it is shown in the New SQL section below.

*********               SQL_ID: 3rba8cczsbad4
*********      Program/Package: ftr_views 
*********              Request: Dimitare Ivanov
*********               Author: Dimitar Dimitrov
********* Received e-mail date: 02/05/2024
*********      Resolution date: 15/02/2024
*********  Trace old file here: \\epox\specifs\performance\tmp\
*********  Trace new file here:
***********************************************************************************/

/********************************OLD SQL*******************************************/

var B2 number;
exec :B2 := 2;
var B1 varchar2(32);
exec :B1 := '1709110543';

SELECT D.REFDOSS REFDOSS_DCMP, 
       C.REFDOSS DOC_REF, 
       IDB.PAYS PAYS_DB, 
       DECODE(AR.REASON, 'SD', 'DSCD', AR.REASON) REASON_CODE, 
       SYSDATE DOC_DATE, 
       C.REFDOSS DOC_REFEXT, 
       ROUND(DECODE(C.DEVISE, D.DEVISE, AR.AMOUNT, CH_TAUX.CONV_ORIG_DEST_TX(TO_CHAR(SYSDATE,'j'), AR.AMOUNT, C.DEVISE, D.DEVISE, 'MER') ), :B2 ) EXCLUDED_AMT, 
       ROUND(DECODE(C.DEVISE, D.DEVISE, AR.AMOUNT, CH_TAUX.CONV_ORIG_DEST_TX(TO_CHAR(SYSDATE,'j'), AR.AMOUNT, C.DEVISE, D.DEVISE, 'MER') ), :B2 ) INITIAL_AMT, 
       FTR_UTIL.REFDB(IDB.REFINDIVIDU) DEBTOR_NUMBER, 
       SUBSTR(IDB.NOM, 1, 100) NOMDB, 
       IDB.REFINDIVIDU REFINDIVIDUDB, 
       ( SELECT FTR_DECOMPTE.REFCL2(IDB.REFINDIVIDU) FROM DUAL ) CLIENT_NUMBER, 
       C.REFDOSS REFDOSS_CMP, 
       NULL START_DATE, 
       NULL END_DATE 
  FROM G_DOSSIER C, 
       G_DOSSIER D, 
       T_INTERVENANTS DB, 
       G_INDIVIDU IDB, 
       G_ACCOUNT_RESTRICTION AR 
 WHERE D.REFDOSS = :B1 
   AND C.REFLOT = D.REFDOSS 
   AND AR.ACCOUNT_ID = C.REFDOSS
   AND AR.AMOUNT != 0 
   AND DB.REFDOSS = C.REFDOSS 
   AND DB.REFTYPE = 'DB' 
   AND IDB.REFINDIVIDU = DB.REFINDIVIDU;
/********************************OLD SQL*******************************************/
/********************************OLD Metrics***************************************/
/*
Plan hash value: 2582013595
-----------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                | Name                        | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers |
-----------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                         |                             |      1 |        |   984 (100)|      0 |00:00:00.50 |    8602 |
|   1 |  FAST DUAL                               |                             |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |
|*  2 |  HASH JOIN                               |                             |      1 |    411 |   572   (0)|      0 |00:00:00.50 |    8602 |
|   3 |   NESTED LOOPS                           |                             |      1 |    407 |   566   (0)|    272 |00:00:00.50 |    8586 |
|   4 |    NESTED LOOPS                          |                             |      1 |    407 |   566   (0)|    272 |00:00:00.50 |    8561 |
|*  5 |     HASH JOIN                            |                             |      1 |    407 |   159   (0)|    272 |00:00:00.50 |    8509 |
|   6 |      NESTED LOOPS                        |                             |      1 |    405 |    78   (0)|    272 |00:00:00.01 |     101 |
|   7 |       TABLE ACCESS BY INDEX ROWID        | G_DOSSIER                   |      1 |      1 |     2   (0)|      1 |00:00:00.01 |       4 |
|*  8 |        INDEX UNIQUE SCAN                 | DOS_REFDOSS                 |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |
|   9 |       TABLE ACCESS BY INDEX ROWID BATCHED| G_DOSSIER                   |      1 |    405 |    76   (0)|    272 |00:00:00.01 |      97 |
|* 10 |        INDEX RANGE SCAN                  | DOSS_LOT                    |      1 |    405 |     2   (0)|    272 |00:00:00.01 |       4 |
|* 11 |      INDEX RANGE SCAN                    | T_INTERVENANTS_COMPD_IDX_01 |      1 |  33817 |    81   (0)|   1773K|00:00:00.22 |    8408 |
|* 12 |     INDEX UNIQUE SCAN                    | IND_REFINDIV                |    272 |      1 |     1   (0)|    272 |00:00:00.01 |      52 |
|  13 |    TABLE ACCESS BY INDEX ROWID           | G_INDIVIDU                  |    272 |      1 |     1   (0)|    272 |00:00:00.01 |      25 |
|* 14 |   TABLE ACCESS FULL                      | G_ACC_RESTR                 |      1 |   1402 |     6   (0)|    475 |00:00:00.01 |      16 |
-----------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   2 - access("AR"."ACCOUNT_ID"="C"."REFDOSS")
   5 - access("DB"."REFDOSS"="C"."REFDOSS")
   8 - access("D"."REFDOSS"=:B1)
  10 - access("C"."REFLOT"=:B1)
  11 - access("DB"."REFTYPE"='DB')
  12 - access("IDB"."REFINDIVIDU"="DB"."REFINDIVIDU")
  14 - filter("AR"."AMOUNT"<>0)
*/
/********************************OLD Metrics***************************************/

/********************************New SQL*******************************************/

SELECT /*+ index(DB INT_REFDOSS*/
       D.REFDOSS REFDOSS_DCMP, 
       C.REFDOSS DOC_REF, 
       IDB.PAYS PAYS_DB, 
       DECODE(AR.REASON, 'SD', 'DSCD', AR.REASON) REASON_CODE, 
       SYSDATE DOC_DATE, 
       C.REFDOSS DOC_REFEXT, 
       ROUND(DECODE(C.DEVISE, D.DEVISE, AR.AMOUNT, CH_TAUX.CONV_ORIG_DEST_TX(TO_CHAR(SYSDATE,'j'), AR.AMOUNT, C.DEVISE, D.DEVISE, 'MER') ), :B2 ) EXCLUDED_AMT, 
       ROUND(DECODE(C.DEVISE, D.DEVISE, AR.AMOUNT, CH_TAUX.CONV_ORIG_DEST_TX(TO_CHAR(SYSDATE,'j'), AR.AMOUNT, C.DEVISE, D.DEVISE, 'MER') ), :B2 ) INITIAL_AMT, 
       FTR_UTIL.REFDB(IDB.REFINDIVIDU) DEBTOR_NUMBER, 
       SUBSTR(IDB.NOM, 1, 100) NOMDB, 
       IDB.REFINDIVIDU REFINDIVIDUDB, 
       ( SELECT FTR_DECOMPTE.REFCL2(IDB.REFINDIVIDU) FROM DUAL ) CLIENT_NUMBER, 
       C.REFDOSS REFDOSS_CMP, 
       NULL START_DATE, 
       NULL END_DATE 
  FROM G_DOSSIER C, 
       G_DOSSIER D, 
       T_INTERVENANTS DB, 
       G_INDIVIDU IDB, 
       G_ACCOUNT_RESTRICTION AR 
 WHERE D.REFDOSS = :B1 
   AND C.REFLOT = D.REFDOSS 
   AND AR.ACCOUNT_ID = C.REFDOSS
   AND AR.AMOUNT != 0 
   AND DB.REFDOSS = C.REFDOSS 
   AND DB.REFTYPE = 'DB' 
   AND IDB.REFINDIVIDU = DB.REFINDIVIDU;
/********************************New SQL*******************************************/
/********************************New Metrics***************************************/
/*
Plan hash value: 3903800917
--------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                | Name         | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers |
--------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                         |              |      1 |        |  1307 (100)|      0 |00:00:00.01 |     956 |
|   1 |  FAST DUAL                               |              |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |
|*  2 |  HASH JOIN                               |              |      1 |    411 |   896   (0)|      0 |00:00:00.01 |     956 |
|   3 |   NESTED LOOPS                           |              |      1 |    407 |   890   (0)|    272 |00:00:00.01 |     940 |
|   4 |    NESTED LOOPS                          |              |      1 |    407 |   890   (0)|    272 |00:00:00.01 |     839 |
|   5 |     NESTED LOOPS                         |              |      1 |    407 |   483   (0)|    272 |00:00:00.01 |     543 |
|   6 |      NESTED LOOPS                        |              |      1 |    405 |    78   (0)|    272 |00:00:00.01 |     101 |
|   7 |       TABLE ACCESS BY INDEX ROWID        | G_DOSSIER    |      1 |      1 |     2   (0)|      1 |00:00:00.01 |       4 |
|*  8 |        INDEX UNIQUE SCAN                 | DOS_REFDOSS  |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |
|   9 |       TABLE ACCESS BY INDEX ROWID BATCHED| G_DOSSIER    |      1 |    405 |    76   (0)|    272 |00:00:00.01 |      97 |
|* 10 |        INDEX RANGE SCAN                  | DOSS_LOT     |      1 |    405 |     2   (0)|    272 |00:00:00.01 |       4 |
|* 11 |      INDEX RANGE SCAN                    | INT_REFDOSS  |    272 |      1 |     1   (0)|    272 |00:00:00.01 |     442 |
|* 12 |     INDEX UNIQUE SCAN                    | IND_REFINDIV |    272 |      1 |     1   (0)|    272 |00:00:00.01 |     296 |
|  13 |    TABLE ACCESS BY INDEX ROWID           | G_INDIVIDU   |    272 |      1 |     1   (0)|    272 |00:00:00.01 |     101 |
|* 14 |   TABLE ACCESS FULL                      | G_ACC_RESTR  |      1 |   1402 |     6   (0)|    475 |00:00:00.01 |      16 |
--------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   2 - access("AR"."ACCOUNT_ID"="C"."REFDOSS")
   8 - access("D"."REFDOSS"=:B1)
  10 - access("C"."REFLOT"=:B1)
  11 - access("DB"."REFDOSS"="C"."REFDOSS" AND "DB"."REFTYPE"='DB')
  12 - access("IDB"."REFINDIVIDU"="DB"."REFINDIVIDU")
  14 - filter("AR"."AMOUNT"<>0)
*/
/********************************New Metrics***************************************/

/********************************Index statistics**********************************/

/********************************Other SQLs****************************************/          
/*

*/ 
/********************************Other SQLs****************************************/              
