/********************************************************************************
*********       E-mail subject: COFADEV-13060
*********             Instance: UAT
*********          Description: 
Problem:
The nb_manager was killed on UAT.

Analysis:
From the analyze, we found that the TOP SQL adzbr897spw34 in module std_imx2bank_ct was responsible for 100% of the time.
The problem in this SQL was that some of the tables were not joined, which leads to full scans and selecting a lot of data.
We requested from the B&I team to join the tables, and they rewrote the query as it is shown in the New SQL section below.

Suggestion:

*********               SQL_ID: adzbr897spw34
*********      Program/Package: std_imx2bank_ct
*********              Request: Daniel Vargas 
*********               Author: Dimitar Dimitrov
********* Received e-mail date: 28/03/2024
*********      Resolution date: 08/04/2024
*********  Trace old file here: \\epox\specifs\performance\tmp\
*********  Trace new file here:
***********************************************************************************/

/********************************OLD SQL*******************************************/

var refoutpmt varchar2(32);
exec :refoutpmt := '80713';

select case
         when length(res.string1) > 140 then
          res.string2
         else
          res.string1
       end
  from (SELECT contr.refdoss || ',' ||
               (DECODE(contr.categdoss,
                       'NOT INSURED',
                       (SELECT REFDOSSEXT
                          from t_intervenants
                         where refdoss = contr.refdoss
                           and reftype = 'CL'),
                       'INSURED',
                       (SELECT REFDOSSEXT
                          from t_intervenants
                         where refdoss = contr.refdoss
                           and reftype = 'TC'))) || ',' ||
               DECODE((SELECT INSTR(contr.EXT_REFERENCE_U1, '#') from dual),
                      0,
                      '',
                      SUBSTR(contr.EXT_REFERENCE_U1,
                             (SELECT INSTR(contr.EXT_REFERENCE_U1, '#')
                                from dual) + 1)) || ',' ||
               DECODE(bu_sepa_pmt_desc.champ,
                      '1',
                      (SELECT t.nom
                         from t_intervenants t
                        where t.refdoss = contr.refdoss
                          AND t.reftype = 'DB')) || ',' || pmt.comm_note as string1,
               contr.refdoss || ',' ||
               (DECODE(contr.categdoss,
                       'NOT INSURED',
                       (SELECT REFDOSSEXT
                          from t_intervenants
                         where refdoss = contr.refdoss
                           and reftype = 'CL'),
                       'INSURED',
                       (SELECT REFDOSSEXT
                          from t_intervenants
                         where refdoss = contr.refdoss
                           and reftype = 'TC'))) || ',' ||
               DECODE((SELECT INSTR(contr.EXT_REFERENCE_U1, '#') from dual),
                      0,
                      '',
                      SUBSTR(contr.EXT_REFERENCE_U1,
                             (SELECT INSTR(contr.EXT_REFERENCE_U1, '#')
                                from dual) + 1)) || ',' || pmt.comm_note as string2
          FROM g_piece       rec_contrat,
               g_dossier     dos,
               g_outpmt      pmt,
               g_outpmt_exec out,
               v_domaine     bu_sepa_pmt_desc,
               g_dossier     contr
         WHERE rec_contrat.refdoss IN ( Select pmt.refdoss
                                          from dual
                                         UNION
                                        SELECT contr.refhierarchie
                                          from g_dossier contr
                                         where contr.refdoss = pmt.refdoss
                                         UNION
                                        SELECT contr.refhierarchie2
                                          from g_dossier contr
                                         where contr.refdoss = pmt.refdoss )
           AND contr.refdoss IN ( select pmt.refdoss
                                    from dual
                                   where exists ( select 1
                                                    from g_dossier
                                                   where refdoss = pmt.refdoss
                                                     and categdoss in ('INSURED', 'NOT INSURED' ) )
                                   UNION 
                                  select det.df_dos
                                    from f_entrel entr, 
                                         f_detfac det
                                   where entr.er_refext1 = nvl(out.comm_note, entr.er_refext1 )
                                     and det.df_rel = entr.er_num
                                     and not exists ( select 1
                                                        from g_dossier
                                                       where refdoss = pmt.refdoss
                                                         and categdoss in ('INSURED', 'NOT INSURED' ) ) )
           AND pmt.refoutpmt = :refoutpmt
           AND out.refoutpmt = pmt.refoutpmt
           AND rec_contrat.st08 IN ('C', 'CN')
           AND rec_contrat.st01 = 'STA1'
           AND trunc(sysdate) between nvl(to_date(gpidtdeb, 'JSP'), trunc(sysdate)) and nvl(to_date(gpidtfin, 'JSP'), trunc(sysdate))
           AND bu_sepa_pmt_desc.type = 'BU_SEPA_PMT_DESC'
           AND bu_sepa_pmt_desc.abrev = dos.reffactor
           and dos.refdoss = rec_contrat.refdoss
           AND EXISTS ( SELECT 1 
                          FROM g_etude et 
                         WHERE et.STD_DC_INV_MOD_U = 'O' ) ) res;
/********************************OLD SQL*******************************************/
/********************************OLD Metrics***************************************/
/*
MODULE                           SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL              PERC
-------------------------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
std_imx2bank_ct                                                  213      29937 db file sequential r 2024/03/27 20:01:08  2024/03/28 03:59:57        2248      8801 +000000000 07:58:49.242 19%
imxbatch_DcInvParamInherit                       53526185                       read by other sessio 2024/03/27 20:11:08  2024/03/28 02:10:33        1192         1 +000000000 05:59:25.068 10%
msgq_pilote                                                                     ON CPU               2024/03/27 20:03:48  2024/03/28 02:42:45         978          16725588 +000000000 06:38:56.737 8%
imx2easy_monitoring              1fk8sqs69tyw2 1492917123        611      32970 db file sequential r 2024/03/27 20:00:48  2024/03/28 03:59:47         928       963 +000000000 07:58:59.243 8%
imx2easy_monitoring              1fk8sqs69tyw2 1492917123        611      32970 ON CPU               2024/03/27 20:00:18  2024/03/28 03:58:27         904       961 +000000000 07:58:09.254 8%
msgq_pilote                                                                     db file sequential r 2024/03/27 20:03:48  2024/03/28 02:43:05         741           1384590 +000000000 06:39:16.737 6%
imxbatch_bkg_nightse                                                            read by other sessio 2024/03/27 20:11:18  2024/03/28 02:06:33         675         1 +000000000 05:55:14.880 6%

 
MODULE                           SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL              PERC
-------------------------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
std_imx2bank_ct                                                  213      29937 db file sequential r 2024/03/27 20:01:08  2024/03/28 03:59:57        2248      8801 +000000000 07:58:49.242 78%
std_imx2bank_ct                                                  213      29937 ON CPU               2024/03/27 20:02:08  2024/03/28 03:56:47         614           2480951 +000000000 07:54:39.098 21%
std_imx2bank_ct                  adzbr897spw34 3703928024        213      29937 direct path read     2024/03/27 22:30:04  2024/03/28 03:26:46           4       136 +000000000 04:56:41.724 0%
std_imx2bank_ct                  gx8vsv97v0qdf 3982841713        213      29937 db file parallel rea 2024/03/27 23:22:17  2024/03/28 02:50:15           3      1324 +000000000 03:27:57.468 0%
std_imx2bank_ct                  gx8vsv97v0qdf 3982841713        213      29937 db file scattered re 2024/03/28 00:22:40  2024/03/28 01:30:32           2        36 +000000000 01:07:52.398 0%


MODULE                           SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL              PERC
-------------------------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
std_imx2bank_ct                  adzbr897spw34 3703928024        213      29937                      2024/03/27 20:01:08  2024/03/28 03:59:57        2861       209 +000000000 07:58:49.242 100%
std_imx2bank_ct                  gx8vsv97v0qdf 3982841713        213      29937                      2024/03/27 21:37:42  2024/03/28 02:50:15           7      5234 +000000000 05:12:33.261 0%
std_imx2bank_ct                  9fyzycp9a53r3 3931255564        213      29937 ON CPU               2024/03/27 22:14:04  2024/03/27 22:14:04           1         1 +000000000 00:00:00.000 0%
std_imx2bank_ct                  ct63sh59jz2br 2806475533        213      29937 ON CPU               2024/03/27 20:48:40  2024/03/27 20:48:40           1         1 +000000000 00:00:00.000 0%
std_imx2bank_ct                  2cvm80zn47xnb          0        213      29937 ON CPU               2024/03/27 23:12:17  2024/03/27 23:12:17           1           +000000000 00:00:00.000 0%

INSTANCE_NUMBER SQL_ID            ELAPSED MAX_WAIT_ON     PC_OF  WAIT_TIME            GETS      READS       ROWS  ELAP/EXEC       GETS/EXEC READS/EXEC  ROWS/EXEC       EXEC PLAN_HASH_VALUE
--------------- ------------- ----------- --------------- ----- ---------- --------------- ---------- ---------- ---------- --------------- ---------- ---------- ---------- ---------------
              1 adzbr897spw34       28674 IO              71%   32431.5251      1127604234   97826766        208     137.86         5421174  470320.99       1           208      3703928024
 
SQL_ID        SQL_PLAN_HASH_VALUE SQL_PLAN_LINE_ID SQL_PLAN_OPERATION             SQL_PLAN_OPTIONS                   ACTIVE
------------- ------------------- ---------------- ------------------------------ ------------------------------ ----------
adzbr897spw34          3703928024               41 TABLE ACCESS                   FULL                                 1364
adzbr897spw34          3703928024               51 TABLE ACCESS                   BY INDEX ROWID BATCHED                796
adzbr897spw34          3703928024               30 INDEX                          RANGE SCAN                            202
adzbr897spw34          3703928024               52 INDEX                          RANGE SCAN                            160
adzbr897spw34          3703928024               53 INDEX                          RANGE SCAN                             78

 
Plan hash value: 3703928024
--------------------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                  | Name                      | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  |
--------------------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                           |                           |      1 |        | 21095 (100)|      1 |00:03:50.43 |    5399K|    470K|
|   1 |  TABLE ACCESS BY INDEX ROWID BATCHED       | T_INTERVENANTS            |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*  2 |   INDEX RANGE SCAN                         | INT_REFDOSS               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|   3 |   TABLE ACCESS BY INDEX ROWID BATCHED      | T_INTERVENANTS            |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       4 |      3 |
|*  4 |    INDEX RANGE SCAN                        | INT_REFDOSS               |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |      2 |
|   5 |    FAST DUAL                               |                           |      1 |      1 |     2   (0)|      1 |00:00:00.01 |       0 |      0 |
|   6 |     FAST DUAL                              |                           |      1 |      1 |     2   (0)|      1 |00:00:00.01 |       0 |      0 |
|   7 |      TABLE ACCESS BY INDEX ROWID BATCHED   | T_INTERVENANTS            |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       4 |      0 |
|*  8 |       INDEX RANGE SCAN                     | INT_REFDOSS               |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |      0 |
|   9 |       TABLE ACCESS BY INDEX ROWID BATCHED  | T_INTERVENANTS            |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 10 |        INDEX RANGE SCAN                    | INT_REFDOSS               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|  11 |        TABLE ACCESS BY INDEX ROWID BATCHED | T_INTERVENANTS            |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 12 |         INDEX RANGE SCAN                   | INT_REFDOSS               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|  13 |         FAST DUAL                          |                           |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|  14 |          FAST DUAL                         |                           |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 15 |  FILTER                                    |                           |      1 |        |            |      1 |00:03:50.43 |    5399K|    470K|
|* 16 |   FILTER                                   |                           |      1 |        |            |    534K|00:02:40.04 |    2454K|    337K|
|  17 |    MERGE JOIN CARTESIAN                    |                           |      1 |      1 | 21043   (1)|    534K|00:02:39.94 |    2454K|    337K|
|  18 |     NESTED LOOPS                           |                           |      1 |      1 |    99   (2)|      1 |00:00:29.36 |    1115K|  27302 |
|  19 |      NESTED LOOPS                          |                           |      1 |   1797 |    99   (2)|    238 |00:00:28.90 |    1115K|  27066 |
|* 20 |       HASH JOIN                            |                           |      1 |   1797 |    45   (3)|  95146 |00:00:03.71 |    4107 |   4107 |
|  21 |        NESTED LOOPS                        |                           |      1 |     69 |     3   (0)|      3 |00:00:00.06 |      11 |     11 |
|  22 |         NESTED LOOPS                       |                           |      1 |      1 |     2   (0)|      1 |00:00:00.06 |       6 |      6 |
|  23 |          TABLE ACCESS BY INDEX ROWID       | G_OUTPMT_EXEC             |      1 |      1 |     1   (0)|      1 |00:00:00.02 |       3 |      3 |
|* 24 |           INDEX UNIQUE SCAN                | G_OUTPMT_EXEC$REFOUTPMT   |      1 |      1 |     1   (0)|      1 |00:00:00.02 |       2 |      2 |
|  25 |          TABLE ACCESS BY INDEX ROWID       | G_OUTPMT                  |      1 |      1 |     1   (0)|      1 |00:00:00.04 |       3 |      3 |
|* 26 |           INDEX UNIQUE SCAN                | G_OUTPMT$REFOUTPMT        |      1 |      1 |     1   (0)|      1 |00:00:00.03 |       2 |      2 |
|* 27 |         TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE                 |      1 |     69 |     1   (0)|      3 |00:00:00.01 |       5 |      5 |
|* 28 |          INDEX RANGE SCAN                  | V_DOMAINE_TYPE_CODE_IDX   |      1 |     78 |     1   (0)|      3 |00:00:00.01 |       3 |      3 |
|  29 |        INDEX FULL SCAN                     | G_DOSSIER_RL_CD_RD_RF_IDX |      1 |    534K|    41   (0)|    534K|00:00:03.40 |    4096 |   4096 |
|* 30 |       INDEX RANGE SCAN                     | PIE_REFDOSS               |  95146 |      1 |     1   (0)|    238 |00:00:25.15 |    1111K|  22959 |
|  31 |        SORT UNIQUE                         |                           |  95146 |      3 |     4   (0)|      1 |00:00:02.11 |     951K|      2 |
|  32 |         UNION-ALL                          |                           |  95146 |        |            |      1 |00:00:01.88 |     951K|      2 |
|* 33 |          FILTER                            |                           |  95146 |        |            |      1 |00:00:00.05 |       0 |      0 |
|  34 |           FAST DUAL                        |                           |      1 |      1 |     2   (0)|      1 |00:00:00.01 |       0 |      0 |
|* 35 |          TABLE ACCESS BY INDEX ROWID       | G_DOSSIER                 |  95146 |      1 |     1   (0)|      0 |00:00:00.84 |     475K|      2 |
|* 36 |           INDEX UNIQUE SCAN                | DOS_REFDOSS               |  95146 |      1 |     1   (0)|  95146 |00:00:00.23 |   95156 |      0 |
|* 37 |          TABLE ACCESS BY INDEX ROWID       | G_DOSSIER                 |  95146 |      1 |     1   (0)|      0 |00:00:00.67 |     475K|      0 |
|* 38 |           INDEX UNIQUE SCAN                | DOS_REFDOSS               |  95146 |      1 |     1   (0)|  95146 |00:00:00.16 |   95156 |      0 |
|* 39 |      TABLE ACCESS BY INDEX ROWID           | G_PIECE                   |    238 |      1 |     1   (0)|      1 |00:00:00.45 |     481 |    236 |
|  40 |     BUFFER SORT                            |                           |      1 |    534K| 21042   (1)|    534K|00:02:10.50 |    1338K|    310K|
|  41 |      TABLE ACCESS FULL                     | G_DOSSIER                 |      1 |    534K| 20944   (1)|    534K|00:02:09.73 |    1338K|    310K|
|* 42 |    TABLE ACCESS FULL                       | G_ETUDE                   |      1 |      1 |     3   (0)|      1 |00:00:00.01 |      10 |      0 |
|  43 |   SORT UNIQUE                              |                           |    534K|      2 |     6   (0)|      1 |00:01:09.82 |    2945K|    132K|
|  44 |    UNION-ALL                               |                           |    534K|        |            |      1 |00:01:09.09 |    2945K|    132K|
|* 45 |     FILTER                                 |                           |    534K|        |            |      0 |00:00:00.45 |       4 |      1 |
|  46 |      FAST DUAL                             |                           |    534K|      1 |     2   (0)|    534K|00:00:00.16 |       0 |      0 |
|* 47 |      TABLE ACCESS BY INDEX ROWID           | G_DOSSIER                 |      1 |      1 |     1   (0)|      0 |00:00:00.01 |       4 |      1 |
|* 48 |       INDEX UNIQUE SCAN                    | DOS_REFDOSS               |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |      0 |
|* 49 |     FILTER                                 |                           |    534K|        |            |      1 |00:01:07.42 |    2945K|    132K|
|  50 |      NESTED LOOPS SEMI                     |                           |    534K|      1 |     2   (0)|      1 |00:01:07.24 |    2945K|    132K|
|* 51 |       TABLE ACCESS BY INDEX ROWID BATCHED  | F_DETFAC                  |    534K|      4 |     1   (0)|    819K|00:00:59.76 |    2062K|    126K|
|* 52 |        INDEX RANGE SCAN                    | DETFAC_DOS                |    534K|      5 |     1   (0)|   1005K|00:00:08.18 |    1393K|  12316 |
|* 53 |       INDEX RANGE SCAN                     | F_ENTREL_ER_NUM_IDX       |    352K|      1 |     1   (0)|      1 |00:00:04.81 |     882K|   5728 |
|* 54 |      TABLE ACCESS BY INDEX ROWID           | G_DOSSIER                 |      1 |      1 |     1   (0)|      0 |00:00:00.01 |       4 |      1 |
|* 55 |       INDEX UNIQUE SCAN                    | DOS_REFDOSS               |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |      0 |
--------------------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   2 - access("REFDOSS"=:B1 AND "REFTYPE"='CL')
   4 - access("REFDOSS"=:B1 AND "REFTYPE"='TC')
   8 - access("T"."REFDOSS"=:B1 AND "T"."REFTYPE"='DB')
  10 - access("REFDOSS"=:B1 AND "REFTYPE"='CL')
  12 - access("REFDOSS"=:B1 AND "REFTYPE"='TC')
  15 - filter( IS NOT NULL)
  16 - filter( IS NOT NULL)
  20 - access("BU_SEPA_PMT_DESC"."ABREV"="DOS"."REFFACTOR")
  24 - access("OUT"."REFOUTPMT"=:REFOUTPMT)
  26 - access("PMT"."REFOUTPMT"=:REFOUTPMT)
  27 - filter("BU_SEPA_PMT_DESC"."ABREV" IS NOT NULL)
  28 - access("BU_SEPA_PMT_DESC"."TYPE"='BU_SEPA_PMT_DESC')
  30 - access("DOS"."REFDOSS"="REC_CONTRAT"."REFDOSS")
       filter( IS NOT NULL)
  33 - filter(:B1=:B2)
  35 - filter("CONTR"."REFHIERARCHIE"=:B1)
  36 - access("CONTR"."REFDOSS"=:B1)
  37 - filter("CONTR"."REFHIERARCHIE2"=:B1)
  38 - access("CONTR"."REFDOSS"=:B1)
  39 - filter(("REC_CONTRAT"."ST01"='STA1' AND INTERNAL_FUNCTION("REC_CONTRAT"."ST08") AND
              NVL(TO_DATE(TO_CHAR("GPIDTDEB"),'Jsp'),TRUNC(SYSDATE@!))<=TRUNC(SYSDATE@!) AND
              NVL(TO_DATE(TO_CHAR("GPIDTFIN"),'Jsp'),TRUNC(SYSDATE@!))>=TRUNC(SYSDATE@!)))
  42 - filter("ET"."STD_DC_INV_MOD_U"='O')
  45 - filter(( IS NOT NULL AND :B1=:B2))
  47 - filter(("CATEGDOSS"='INSURED' OR "CATEGDOSS"='NOT INSURED'))
  48 - access("REFDOSS"=:B1)
  49 - filter( IS NULL)
  51 - filter("DET"."DF_REL" IS NOT NULL)
  52 - access("DET"."DF_DOS"=:B1)
  53 - access("DET"."DF_REL"="ENTR"."ER_NUM")
       filter("ENTR"."ER_REFEXT1"=NVL(:B1,"ENTR"."ER_REFEXT1"))
  54 - filter(("CATEGDOSS"='INSURED' OR "CATEGDOSS"='NOT INSURED'))
  55 - access("REFDOSS"=:B1)

*/
/********************************OLD Metrics***************************************/

/********************************New SQL*******************************************/

var B1 varchar2(32);
exec :B1 := '10021';

SELECT ustrd.imx_ref
       ||','|| ustrd.cust_ref
       ||','|| ustrd.claim_ref
       || CASE WHEN LENGTH(ustrd.imx_ref||','||ustrd.cust_ref||','||ustrd.claim_ref||','||ustrd.db_name||','||ustrd.inv_ref) > 140
                 THEN SUBSTR(','||ustrd.db_name, 140 - LENGTH(ustrd.imx_ref ||','|| ustrd.cust_ref ||','||ustrd.claim_ref ||','|| ustrd.inv_ref))
               ELSE DECODE(ustrd.db_name,'','',','||ustrd.db_name)
          END
       ||','|| ustrd.inv_ref
  FROM (SELECT COUNT(1) AS std_inv FROM g_etude WHERE std_dc_inv_mod_u = 'O') et
     , (SELECT dos.refdoss     AS imx_ref
             , cust.refdossext AS cust_ref
             , CASE WHEN INSTR(dos.ext_reference_u1,'#') = 0 THEN  ''
                    ELSE SUBSTR(dos.ext_reference_u1, INSTR(dos.ext_reference_u1, '#') + 1)
               END             AS claim_ref
             , CASE WHEN bu_sepa_pmt_desc.champ = '1' THEN db.nom
                    ELSE ''
               END             AS db_name
             , pmt.comm_note   AS inv_ref
          FROM t_intervenants db
             , t_intervenants cust
             , t_intervenants bu
             , g_piece        rec_contrat
             , g_dossier      dos
             , g_outpmt       pmt
             , g_outpmt_exec  out
             , v_domaine      bu_sepa_pmt_desc
         WHERE bu_sepa_pmt_desc.type  = 'BU_SEPA_PMT_DESC'
           AND bu_sepa_pmt_desc.abrev = bu.refindividu
           AND rec_contrat.st01       = 'STA1'
           AND rec_contrat.st08       IN ('C', 'CN')
           AND rec_contrat.typpiece   = 'REC_CONTRAT'
           AND rec_contrat.refdoss    = dos.refhierarchie
           AND TRUNC(SYSDATE) BETWEEN NVL(TO_DATE(rec_contrat.gpidtdeb, 'JSP'), TRUNC(SYSDATE)) AND NVL(TO_DATE(rec_contrat.gpidtfin, 'JSP'), TRUNC(SYSDATE))
           AND dos.categdoss          = 'NOT INSURED'
           AND dos.refdoss            = pmt.refdoss
           AND dos.refdoss            = db.refdoss
           AND dos.refdoss            = cust.refdoss
           AND dos.refdoss            = bu.refdoss
           AND db.reftype             = 'DB'
           AND cust.reftype           = 'CL'
           AND bu.reftype             = 'BU'
           AND out.refoutpmt          = pmt.refoutpmt
           AND pmt.refoutpmt          = :b1
         UNION
        SELECT dos.refdoss
             , cust.refdossext
             , CASE WHEN INSTR(dos.ext_reference_u1,'#') = 0 THEN  ''
                    ELSE SUBSTR(dos.ext_reference_u1, INSTR(dos.ext_reference_u1, '#') + 1)
               END
             , CASE WHEN bu_sepa_pmt_desc.champ = '1' THEN db.nom
                    ELSE ''
               END
             , pmt.comm_note
          FROM t_intervenants db
             , t_intervenants cust
             , t_intervenants bu
             , g_piece        rec_contrat
             , g_dossier      dos
             , g_outpmt       pmt
             , g_outpmt_exec  out
             , v_domaine      bu_sepa_pmt_desc
         WHERE bu_sepa_pmt_desc.type  = 'BU_SEPA_PMT_DESC'
           AND bu_sepa_pmt_desc.abrev = bu.refindividu
           AND rec_contrat.st01       = 'STA1'
           AND rec_contrat.st08       IN ('C', 'CN')
           AND rec_contrat.typpiece   = 'REC_CONTRAT'
           AND rec_contrat.refdoss    = dos.refhierarchie2
           AND TRUNC(SYSDATE) BETWEEN NVL(TO_DATE(rec_contrat.gpidtdeb, 'JSP'), TRUNC(SYSDATE)) AND NVL(TO_DATE(rec_contrat.gpidtfin, 'JSP'), TRUNC(SYSDATE))
           AND dos.categdoss          = 'INSURED'
           AND dos.refdoss            = pmt.refdoss
           AND dos.refdoss            = db.refdoss
           AND dos.refdoss            = cust.refdoss
           AND dos.refdoss            = bu.refdoss
           AND db.reftype             = 'DB'
           AND cust.reftype           = 'TC'
           AND bu.reftype             = 'BU'
           AND out.refoutpmt          = pmt.refoutpmt
           AND pmt.refoutpmt          = :B1) ustrd
  WHERE et.std_inv = 1;
/********************************New SQL*******************************************/
/********************************New Metrics***************************************/
/*
Plan hash value: 3489364303
-------------------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                   | Name                    | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  |
-------------------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                            |                         |      1 |        |    19 (100)|      0 |00:00:00.01 |      34 |      8 |
|   1 |  NESTED LOOPS                               |                         |      1 |      2 |    19   (0)|      0 |00:00:00.01 |      34 |      8 |
|   2 |   VIEW                                      |                         |      1 |      1 |     3   (0)|      1 |00:00:00.01 |      10 |      0 |
|*  3 |    FILTER                                   |                         |      1 |        |            |      1 |00:00:00.01 |      10 |      0 |
|   4 |     SORT AGGREGATE                          |                         |      1 |      1 |            |      1 |00:00:00.01 |      10 |      0 |
|*  5 |      TABLE ACCESS FULL                      | G_ETUDE                 |      1 |      1 |     3   (0)|      1 |00:00:00.01 |      10 |      0 |
|   6 |   VIEW                                      |                         |      1 |      2 |    16   (0)|      0 |00:00:00.01 |      24 |      8 |
|   7 |    SORT UNIQUE                              |                         |      1 |      2 |    16   (0)|      0 |00:00:00.01 |      24 |      8 |
|   8 |     UNION-ALL                               |                         |      1 |        |            |      0 |00:00:00.01 |      24 |      8 |
|   9 |      NESTED LOOPS SEMI                      |                         |      1 |      1 |     8   (0)|      0 |00:00:00.01 |      12 |      8 |
|  10 |       NESTED LOOPS                          |                         |      1 |      1 |     7   (0)|      0 |00:00:00.01 |      12 |      8 |
|  11 |        NESTED LOOPS                         |                         |      1 |      1 |     6   (0)|      0 |00:00:00.01 |      12 |      8 |
|  12 |         NESTED LOOPS                        |                         |      1 |      1 |     5   (0)|      0 |00:00:00.01 |      12 |      8 |
|  13 |          NESTED LOOPS                       |                         |      1 |      1 |     4   (0)|      0 |00:00:00.01 |      12 |      8 |
|  14 |           NESTED LOOPS                      |                         |      1 |      1 |     3   (0)|      0 |00:00:00.01 |      12 |      8 |
|  15 |            NESTED LOOPS                     |                         |      1 |      1 |     2   (0)|      1 |00:00:00.01 |       5 |      5 |
|* 16 |             INDEX UNIQUE SCAN               | G_OUTPMT_EXEC$REFOUTPMT |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       2 |      2 |
|  17 |             TABLE ACCESS BY INDEX ROWID     | G_OUTPMT                |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |      3 |
|* 18 |              INDEX UNIQUE SCAN              | G_OUTPMT$REFOUTPMT      |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       2 |      2 |
|* 19 |            TABLE ACCESS BY INDEX ROWID      | G_DOSSIER               |      1 |      1 |     1   (0)|      0 |00:00:00.01 |       7 |      3 |
|* 20 |             INDEX UNIQUE SCAN               | DOS_REFDOSS             |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |      1 |
|* 21 |           INDEX RANGE SCAN                  | INT_REFDOSS             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|  22 |          TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 23 |           INDEX RANGE SCAN                  | DOM_TYPABREV            |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|  24 |         TABLE ACCESS BY INDEX ROWID BATCHED | T_INTERVENANTS          |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 25 |          INDEX RANGE SCAN                   | INT_REFDOSS             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|  26 |        TABLE ACCESS BY INDEX ROWID BATCHED  | T_INTERVENANTS          |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 27 |         INDEX RANGE SCAN                    | INT_REFDOSS             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 28 |       TABLE ACCESS BY INDEX ROWID BATCHED   | G_PIECE                 |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 29 |        INDEX RANGE SCAN                     | PIE_REFDOSS             |      0 |      3 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|  30 |      NESTED LOOPS SEMI                      |                         |      1 |      1 |     8   (0)|      0 |00:00:00.01 |      12 |      0 |
|  31 |       NESTED LOOPS                          |                         |      1 |      1 |     7   (0)|      0 |00:00:00.01 |      12 |      0 |
|  32 |        NESTED LOOPS                         |                         |      1 |      1 |     6   (0)|      0 |00:00:00.01 |      12 |      0 |
|  33 |         NESTED LOOPS                        |                         |      1 |      1 |     5   (0)|      0 |00:00:00.01 |      12 |      0 |
|  34 |          NESTED LOOPS                       |                         |      1 |      1 |     4   (0)|      0 |00:00:00.01 |      12 |      0 |
|  35 |           NESTED LOOPS                      |                         |      1 |      1 |     3   (0)|      0 |00:00:00.01 |      12 |      0 |
|  36 |            NESTED LOOPS                     |                         |      1 |      1 |     2   (0)|      1 |00:00:00.01 |       5 |      0 |
|* 37 |             INDEX UNIQUE SCAN               | G_OUTPMT_EXEC$REFOUTPMT |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       2 |      0 |
|  38 |             TABLE ACCESS BY INDEX ROWID     | G_OUTPMT                |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |      0 |
|* 39 |              INDEX UNIQUE SCAN              | G_OUTPMT$REFOUTPMT      |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       2 |      0 |
|* 40 |            TABLE ACCESS BY INDEX ROWID      | G_DOSSIER               |      1 |      1 |     1   (0)|      0 |00:00:00.01 |       7 |      0 |
|* 41 |             INDEX UNIQUE SCAN               | DOS_REFDOSS             |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |      0 |
|* 42 |           INDEX RANGE SCAN                  | INT_REFDOSS             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|  43 |          TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 44 |           INDEX RANGE SCAN                  | DOM_TYPABREV            |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|  45 |         TABLE ACCESS BY INDEX ROWID BATCHED | T_INTERVENANTS          |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 46 |          INDEX RANGE SCAN                   | INT_REFDOSS             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|  47 |        TABLE ACCESS BY INDEX ROWID BATCHED  | T_INTERVENANTS          |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 48 |         INDEX RANGE SCAN                    | INT_REFDOSS             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 49 |       TABLE ACCESS BY INDEX ROWID BATCHED   | G_PIECE                 |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 50 |        INDEX RANGE SCAN                     | PIE_REFDOSS             |      0 |      3 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
-------------------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   3 - filter(COUNT(*)=1)
   5 - filter("STD_DC_INV_MOD_U"='O')
  16 - access("OUT"."REFOUTPMT"=:B1)
  18 - access("PMT"."REFOUTPMT"=:B1)
  19 - filter(("DOS"."CATEGDOSS"='NOT INSURED' AND "DOS"."REFHIERARCHIE" IS NOT NULL))
  20 - access("DOS"."REFDOSS"="PMT"."REFDOSS")
  21 - access("DOS"."REFDOSS"="BU"."REFDOSS" AND "BU"."REFTYPE"='BU')
  23 - access("BU_SEPA_PMT_DESC"."TYPE"='BU_SEPA_PMT_DESC' AND "BU_SEPA_PMT_DESC"."ABREV"="BU"."REFINDIVIDU")
       filter("BU_SEPA_PMT_DESC"."ABREV" IS NOT NULL)
  25 - access("DOS"."REFDOSS"="DB"."REFDOSS" AND "DB"."REFTYPE"='DB')
  27 - access("DOS"."REFDOSS"="CUST"."REFDOSS" AND "CUST"."REFTYPE"='CL')
  28 - filter(("REC_CONTRAT"."ST01"='STA1' AND INTERNAL_FUNCTION("REC_CONTRAT"."ST08") AND
              NVL(TO_DATE(TO_CHAR("REC_CONTRAT"."GPIDTDEB"),'Jsp'),TRUNC(SYSDATE@!))<=TRUNC(SYSDATE@!) AND
              NVL(TO_DATE(TO_CHAR("REC_CONTRAT"."GPIDTFIN"),'Jsp'),TRUNC(SYSDATE@!))>=TRUNC(SYSDATE@!)))
  29 - access("REC_CONTRAT"."REFDOSS"="DOS"."REFHIERARCHIE" AND "REC_CONTRAT"."TYPPIECE"='REC_CONTRAT')
  37 - access("OUT"."REFOUTPMT"=:B1)
  39 - access("PMT"."REFOUTPMT"=:B1)
  40 - filter(("DOS"."REFHIERARCHIE2" IS NOT NULL AND "DOS"."CATEGDOSS"='INSURED'))
  41 - access("DOS"."REFDOSS"="PMT"."REFDOSS")
  42 - access("DOS"."REFDOSS"="BU"."REFDOSS" AND "BU"."REFTYPE"='BU')
  44 - access("BU_SEPA_PMT_DESC"."TYPE"='BU_SEPA_PMT_DESC' AND "BU_SEPA_PMT_DESC"."ABREV"="BU"."REFINDIVIDU")
       filter("BU_SEPA_PMT_DESC"."ABREV" IS NOT NULL)
  46 - access("DOS"."REFDOSS"="DB"."REFDOSS" AND "DB"."REFTYPE"='DB')
  48 - access("DOS"."REFDOSS"="CUST"."REFDOSS" AND "CUST"."REFTYPE"='TC')
  49 - filter(("REC_CONTRAT"."ST01"='STA1' AND INTERNAL_FUNCTION("REC_CONTRAT"."ST08") AND
              NVL(TO_DATE(TO_CHAR("REC_CONTRAT"."GPIDTDEB"),'Jsp'),TRUNC(SYSDATE@!))<=TRUNC(SYSDATE@!) AND
              NVL(TO_DATE(TO_CHAR("REC_CONTRAT"."GPIDTFIN"),'Jsp'),TRUNC(SYSDATE@!))>=TRUNC(SYSDATE@!)))
  50 - access("REC_CONTRAT"."REFDOSS"="DOS"."REFHIERARCHIE2" AND "REC_CONTRAT"."TYPPIECE"='REC_CONTRAT')
*/
/********************************New Metrics***************************************/

/********************************Index statistics**********************************/

/********************************Other SQLs****************************************/          
/*

*/ 
/********************************Other SQLs****************************************/              
