/********************************************************************************
*********       E-mail subject: EFEURWEB-4252
*********             Instance: UAT1
*********          Description: 
Problem:
The imxbatch_RapprochementProcessAll took ~5 hours on UAT1.

Analysis:
I checked the work of the imxbatch_RapprochementProcessAll on UAT for the period between 20:40 on 25/03/2025 and 02:00 on 26/03/2025. As you can see below, the TOP SQL for this module, which 
was responsible for 89% of the time was 9cpw9q6a41rjc ( from ftr_util2.pcs ). The heaviest step in the execution plan of this query is the filter to check the TI.ville in table g_individu TI. From what I see, it looks 
like table g_individu TI is accessed through the "cp" column for the provided value in B3 bind variable, but as you can see below, there are values for "cp" column in table g_individu which 
have thousands rows. I think that the most selective path here is to access table g_individu TI through the refindividu column, which should select less rows. I added hint to the query to force Oracle to do it.

Suggestion:
Please add hint as it is shown in the New SQL section below.

*********               SQL_ID: 9cpw9q6a41rjc
*********      Program/Package: ftr_util2.pcs
*********              Request: Lubomir Vladov 
*********               Author: Dimitar Dimitrov
********* Received e-mail date: 27/03/2025
*********      Resolution date: 27/03/2025
*********  Trace old file here: \\epox\specifs\performance\tmp\
*********  Trace new file here:
***********************************************************************************/

/********************************OLD SQL*******************************************/

VAR B2 VARCHAR2(32);
EXEC :B2 := 'A90AQGT7';
VAR B3 VARCHAR2(32);
EXEC :B3 := '';
VAR B4 VARCHAR2(32);
EXEC :B4 := '';

select max(TI.refindividu), count(*)
  INTO :b0, :b1
  FROM T_COLL_SEARCHRESULT TS, 
       g_individu TI
 WHERE TS.SESSION_ID = :b2
   AND TS.ELEM_TYPE = 'IDENT_COLL_IND'
   AND TI.refindividu = TS.ELEM_ID
   AND TI.cp = :b3
   AND utl_phonetic.toPhonetic('FR', TI.ville) = utl_phonetic.toPhonetic('FR', :b4);
/********************************OLD SQL*******************************************/
/********************************OLD Metrics***************************************/
/*
MODULE                           PROGRAM                                            CLIENT_ID       SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- -------------------------------------------------- --------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
imxbatch_RapprochementProcessAll imxbatch                                                                                                                               2025/03/25 20:49:05  2025/03/26 01:56:50        1907              8170663 +000000000 05:07:44.957 27%


MODULE                           PROGRAM                                            CLIENT_ID       SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- -------------------------------------------------- --------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
imxbatch_RapprochementProcessAll imxbatch                                                                                                          ON CPU               2025/03/25 20:49:05  2025/03/26 01:56:50        1886              8170663 +000000000 05:07:44.957 99%
imxbatch_RapprochementProcessAll imxbatch                                                                                                          db file sequential r 2025/03/25 20:49:05  2025/03/26 00:38:27          13              1454480 +000000000 03:49:21.843 1%
imxbatch_RapprochementProcessAll imxbatch                                                                                  0                       log file sync        2025/03/25 20:49:35  2025/03/25 22:19:00           3                      +000000000 01:29:24.715 0%
imxbatch_RapprochementProcessAll imxbatch                                                                         1558442417                       read by other sessio 2025/03/25 20:49:05  2025/03/25 20:49:05           2                    1 +000000000 00:00:00.000 0%
    
    
MODULE                           PROGRAM                                            CLIENT_ID       SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- -------------------------------------------------- --------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
imxbatch_RapprochementProcessAll imxbatch                                                                                          1897      53649                      2025/03/25 20:49:05  2025/03/26 01:56:50        1840              1511449 +000000000 05:07:44.957 96%
imxbatch_RapprochementProcessAll imxbatch                                                                                          1898      63057                      2025/03/25 20:49:05  2025/03/25 20:58:26          53              8170663 +000000000 00:09:20.588 3%
imxbatch_RapprochementProcessAll imxbatch                                                                                            11      52772                      2025/03/25 20:49:05  2025/03/25 20:51:25          12                 5449 +000000000 00:02:20.202 1%
imxbatch_RapprochementProcessAll imxbatch                                                           8azxnaq35g0mw 1558442417        153      59889 db file scattered re 2025/03/25 20:49:05  2025/03/25 20:49:05           1                    1 +000000000 00:00:00.000 0%
imxbatch_RapprochementProcessAll imxbatch                                                           32yuc9r3xhd0c 1558442417       1357      55085 read by other sessio 2025/03/25 20:49:05  2025/03/25 20:49:05           1                    1 +000000000 00:00:00.000 0%    
                                                                                                                                                                                                                        

MODULE                           PROGRAM                                            CLIENT_ID       SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- -------------------------------------------------- --------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
imxbatch_RapprochementProcessAll imxbatch                                                           9cpw9q6a41rjc 3033217850       1897      53649 ON CPU               2025/03/25 20:49:35  2025/03/26 01:56:40        1702                 5822 +000000000 05:07:04.912 89%
imxbatch_RapprochementProcessAll imxbatch                                                           8f69h7h4k75tq 1447559841                       ON CPU               2025/03/25 20:49:15  2025/03/26 01:56:50          64                 5876 +000000000 05:07:34.944 3%
imxbatch_RapprochementProcessAll imxbatch                                                           7hhr93znmh6bh  693181328                       ON CPU               2025/03/25 20:53:16  2025/03/26 00:47:08          17                 3791 +000000000 03:53:52.072 1%
imxbatch_RapprochementProcessAll imxbatch                                                           g0tfvjah1vxdu 1896898787                       ON CPU               2025/03/25 20:49:15  2025/03/26 01:26:49          16                 4600 +000000000 04:37:33.889 1%
imxbatch_RapprochementProcessAll imxbatch                                                           7smwwqsvwkzzm 3712815160                                            2025/03/25 20:50:35  2025/03/26 00:38:47          12                   71 +000000000 03:48:11.728 1%


INDEX_NAME                     INFO       BLEVEL       ROWS   ROWS/KEY       KEYS     BLOCKS   CF  DATAB/KEY  LEAFB/KEY LAST_ANALYZED       COLUMNS
------------------------------ ------ ---------- ---------- ---------- ---------- ---------- ---- ---------- ---------- ------------------- ------------------------------------------------------------
TCSR_REFDOSS_IDX                                                                                                                            REFDOSS
TCSR_SESSID_ELEMTYPE_IDX                                                                                                                    SESSION_ID,ELEM_TYPE

INSTANCE_NUMBER SQL_ID            ELAPSED MAX_WAIT_ON     PC_OF  WAIT_TIME            GETS      READS       ROWS  ELAP/EXEC       GETS/EXEC READS/EXEC  ROWS/EXEC       EXEC PLAN_HASH_VALUE
--------------- ------------- ----------- --------------- ----- ---------- --------------- ---------- ---------- ---------- --------------- ---------- ---------- ---------- ---------------
              1 9cpw9q6a41rjc       17087 CPU             50%   33234.6425         8765659        128       5932       2.88            1478        .02          1       5932  3033217850
              

SQL_ID        SQL_PLAN_HASH_VALUE SQL_PLAN_LINE_ID SQL_PLAN_OPERATION             SQL_PLAN_OPTIONS                   ACTIVE
------------- ------------------- ---------------- ------------------------------ ------------------------------ ----------
9cpw9q6a41rjc          3033217850                7 TABLE ACCESS                   BY INDEX ROWID                       1701
9cpw9q6a41rjc          3033217850                6 INDEX                          RANGE SCAN                              1

       
       
select cp, count(*)
  from g_individu
 group by cp
 order by count(*) desc
 fetch first 20 rows only;
 
CP                                                             COUNT(*)
------------------------------------------------------------ ----------
                                                                  11189
.                                                                  4687
1000                                                                732
9000                                                                430
10117                                                               412
59100                                                               409
2000                                                                408
20457                                                               358
57072                                                               350
55232                                                               349
2800                                                                341
46002                                                               324
20097                                                               316
0                                                                   315
20095                                                               315
38855                                                               300
57368                                                               299
59872                                                               296
1050                                                                291
39004                                                               289 


Plan hash value: 3033217850
--------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                              | Name                     | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   |
--------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                       |                          |      1 |        |     2 (100)|      1 |00:00:00.01 |
|   1 |  SORT AGGREGATE                        |                          |      1 |      1 |            |      1 |00:00:00.01 |
|   2 |   NESTED LOOPS                         |                          |      1 |      1 |     2   (0)|      0 |00:00:00.01 |
|   3 |    NESTED LOOPS                        |                          |      1 |      1 |     2   (0)|      0 |00:00:00.01 |
|   4 |     TABLE ACCESS BY INDEX ROWID BATCHED| T_COLL_SEARCHRESULT      |      1 |      1 |     1   (0)|      0 |00:00:00.01 |
|*  5 |      INDEX RANGE SCAN                  | TCSR_SESSID_ELEMTYPE_IDX |      0 |      1 |     1   (0)|      0 |00:00:00.01 |
|*  6 |     INDEX RANGE SCAN                   | G_INDIV_CP_PROF          |      0 |      1 |     1   (0)|      0 |00:00:00.01 |
|*  7 |    TABLE ACCESS BY INDEX ROWID         | G_INDIVIDU               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |
--------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   5 - access("TS"."SESSION_ID"=:B2 AND "TS"."ELEM_TYPE"='IDENT_COLL_IND')
   6 - access("TI"."CP"=:B3)
   7 - filter(("UTL_PHONETIC"."TOPHONETIC"('FR',"TI"."VILLE")="UTL_PHONETIC"."TOPHONETIC"('FR',:B4) AND
              "TI"."REFINDIVIDU"="TS"."ELEM_ID"))
*/
/********************************OLD Metrics***************************************/

/********************************New SQL*******************************************/

select /*+ leading(TS TI) index(TI IND_REFINDIV) use_nl(TI) */
       max(TI.refindividu), count(*)
   INTO :b0, :b1
  FROM T_COLL_SEARCHRESULT TS, 
       g_individu TI
 WHERE TS.SESSION_ID = :b2
   AND TS.ELEM_TYPE = 'IDENT_COLL_IND'
   AND TI.refindividu = TS.ELEM_ID
   AND TI.cp = :b3
   AND utl_phonetic.toPhonetic('FR', TI.ville) = utl_phonetic.toPhonetic('FR', :b4);
/********************************New SQL*******************************************/
/********************************New Metrics***************************************/
/*Plan hash value: 693181328
--------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                              | Name                     | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   |
--------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                       |                          |      1 |        |     3 (100)|      1 |00:00:00.01 |
|   1 |  SORT AGGREGATE                        |                          |      1 |      1 |            |      1 |00:00:00.01 |
|   2 |   NESTED LOOPS                         |                          |      1 |      1 |     3   (0)|      0 |00:00:00.01 |
|   3 |    NESTED LOOPS                        |                          |      1 |      1 |     3   (0)|      0 |00:00:00.01 |
|   4 |     TABLE ACCESS BY INDEX ROWID BATCHED| T_COLL_SEARCHRESULT      |      1 |      1 |     1   (0)|      0 |00:00:00.01 |
|*  5 |      INDEX RANGE SCAN                  | TCSR_SESSID_ELEMTYPE_IDX |      0 |      1 |     1   (0)|      0 |00:00:00.01 |
|*  6 |     INDEX UNIQUE SCAN                  | IND_REFINDIV             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |
|*  7 |    TABLE ACCESS BY INDEX ROWID         | G_INDIVIDU               |      0 |      1 |     2   (0)|      0 |00:00:00.01 |
--------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   5 - access("TS"."SESSION_ID"=:B2 AND "TS"."ELEM_TYPE"='IDENT_COLL_IND')
   6 - access("TI"."REFINDIVIDU"="TS"."ELEM_ID")
   7 - filter(("TI"."CP"=:B3 AND "UTL_PHONETIC"."TOPHONETIC"('FR',"TI"."VILLE")="UTL_PHONETIC"."TOPHONETIC"('FR',:B4)))

Note
-----
   - dynamic statistics used: dynamic sampling (level=2)
*/
/********************************New Metrics***************************************/

/********************************Index statistics**********************************/

/********************************Other SQLs****************************************/          
/*

*/ 
/********************************Other SQLs****************************************/              
