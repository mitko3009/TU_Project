################################################################################################
################################################################################################

srvctl - е на oracle user
crsctl - е на grid user


###### STOP MONITORING ######
#############################

with root:

dbspicol OFF
dbspicol ON

##### STOP LISTENER #####
#########################

with oracle user:

lsnrctl stop
lsnrctl start


##### STOP DATABASE SINGLE INSTANCE #####
#########################################

shutdown immediate
shu immediate

startup

select status from v$instance; - Проверявам базата дали е горе


############################# START RAC INSTANCE ####################
#####################################################################

with oracle user:

srvctl start instance -d <database_name> -i <instance name>

[oracle@hhorat02 ora9i]$ srvctl stop instance -d IPCT -i IPCT1
[oracle@hhorat02 ora9i]$ srvctl start instance -d IPCT -i IPCT1

######## CRS cluster start / stop #######

######################## Check cluster resources ####################

su - grid
crsctl stat res -t

###################### Check init resources ########################

crsctl stat res -t -init

##################### Check status nodes on cluster #### Everything must be online #################

crsctl check cluster -all


#############################

dbmoncol OFF/ON                       #### Спираме и стартираме мониторинга на всички бази.
as root - 
1. cat /etc/oratab
2. cd <ASM_HOME>\bin
3. ./crsctl stat res -t
4. if needed - ./crsctl stop crs -f 
5. ./crsctl start crs
6. Wait max 5 minutes 
7. Check with ./crsctl stat res -t

###########

cat /etc/oratab     -  да видим холма на ASM
cd < home_ASM/bin >
### стартирам с root ###
./crsctl start crs           ./crsctl stop crs         ./crsctl stop has  (ако няма клъстърни ресурси)--->  ./crsctl disable has ---> ./crsctl start has ---> enable
./crsctl stat res -t

######################### INSTANCE STARTUP TIME ###################

select to_char(startup_time, 'YYYY/MM/DD HH24:MI:SS') from v$instance;


######## RAC CHECK ######

select INST_ID,SCHEMANAME,MACHINE,PROGRAM, count(*) from gv$session where SCHEMANAME!='SYS' group by INST_ID,SCHEMANAME,MACHINE,PROGRAM;


