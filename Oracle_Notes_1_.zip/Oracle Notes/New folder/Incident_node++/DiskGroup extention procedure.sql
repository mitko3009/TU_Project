############################# SHOW DISKS ###############################
Pri vseki mail za storage request v cc slednite hora:
https://ivmg700.dxc.web.audi.vwg/ServiceOutageAnalyse/default/index
<extern.horst.frahler@audi.de>; Schiechel, Gregor (I/BT-T8, extern) <extern.gregor.schiechel@audi.de>; Dieterle, Joachim (I/BT-T8) <Joachim.Dieterle@AUDI.DE> 

Eventualno i Peter Eisenmann

########################################

SET LINESIZE  200
SET PAGESIZE  9999
SET VERIFY    off 
COLUMN disk_group_name        FORMAT a20           HEAD 'Disk Group Name'
COLUMN disk_file_path         FORMAT a40           HEAD 'Path'
COLUMN disk_file_name         FORMAT a20           HEAD 'File Name'
COLUMN disk_file_fail_group   FORMAT a20           HEAD 'Fail Group'
COLUMN total_mb               FORMAT 999,999,999   HEAD 'File Size (MB)'
COLUMN used_mb                FORMAT 999,999,999   HEAD 'Used Size (MB)'
COLUMN pct_used               FORMAT 999.99        HEAD 'Pct. Used'
COLUMN State				  FORMAT a20           HEAD 'State'
break on report on disk_group_name skip 1
compute sum label ""              of total_mb used_mb on disk_group_name
compute sum label "Grand Total: " of total_mb used_mb on report
SELECT
 GROUP_NUMBER          Group_number
  , NVL(a.name, '[CANDIDATE]')                       disk_group_name
  , b.path                                           disk_file_path
  , b.name                                           disk_file_name
  , b.failgroup                                      disk_file_fail_group
  , b.total_mb                                       total_mb
 , (b.total_mb - b.free_mb)                         used_mb,
 a.STATE                                            State
--  , ROUND((1- (b.free_mb / b.total_mb))*100, 2)      pct_used
FROM
	v$asm_diskgroup a RIGHT OUTER JOIN v$asm_disk b USING (group_number)
ORDER BY b.name
/

#######################################################################
COMPATIBILITY CHECKS OF DG IN ASM:

col COMPATIBILITY form a10
col DATABASE_COMPATIBILITY form a10
col NAME form a20
select group_number, name, compatibility, type, database_compatibility from v$asm_diskgroup;

set lines 300
set pages 10000
select dg.name group_name,
    dg.type,
    dg.compatibility,
    d.name disk_name,
    d.total_mb
  from v$asm_diskgroup dg, v$asm_disk d
  where dg.group_number=d.group_number
  order by d.disk_number;

####################################################
Chcking disks of DG:

asmcmd lsdsk -p -G ACFS
col GROUP_NUMBER for a40
col STATE for a40
col name for a40
col path for a40
col REPAIR_TIME for a30
select GROUP_NUMBER,STATE,name,path,REPAIR_TIMER from v$asm_disk;
alter diskgroup DATA5 add failgroup DATA5_RZ_T2 disk '/dev/oracleasm/disks/U3_DATA5_T2_002' name DATA5_T2_DISK02 size 7168000M FORCE;
alter diskgroup DATA6 add failgroup DATA6_RZ_T2 disk '/dev/oracleasm/disks/U3_DATA6_T2_002' name DATA6_T2_DISK02 size 3072000M FORCE;
alter diskgroup FRA1 add failgroup FRA1_RZ_T2 disk '/dev/oracleasm/disks/U4_FRA1_T2_002' name FRA1_T2_DISK02 size 2048000M FORCE;
alter diskgroup FRA5 add failgroup FRA5_RZ_T2 disk '/dev/oracleasm/disks/U3_FRA5_T2_002' name FRA5_T2_DISK02 size 2048000M FORCE;
alter diskgroup FRA6 add failgroup FRA6_RZ_T2 disk '/dev/oracleasm/disks/U3_FRA6_T2_002' name FRA6_T2_DISK02 size 2048000M FORCE;
###################################################################################

set pagesize 200 linesize 200
col DISK_FILE_PATH format a40
col path format a40
SELECT
    NVL(a.name, '[CANDIDATE]')      disk_group_name
 ,  b.path                          disk_file_path
 ,  b.name                          disk_file_name
 ,  b.failgroup                     disk_file_fail_group
FROM
    v$asm_diskgroup a RIGHT OUTER JOIN v$asm_disk b USING (group_number)
ORDER BY
    a.name;
	
############################### ASMlib #############################################

set pagesize 200 linesize 200
select NVL(g.name, '[CANDIDATE]'), d.NAME, d.DISK_NUMBER, d.OS_MB, d.TOTAL_MB, d.MOUNT_STATUS, d.HEADER_STATUS 
 from  v$asm_diskgroup G RIGHT OUTER JOIN v$asm_disk d USING (group_number)
-- where d.GROUP_NUMBER = G.GROUP_NUMBER 
order by 1,2;


############################# FILTER DISKS ###############################
set pages 10000
set linesize 300
col PATH for a40
col OS_MB for a20
col MOUNT_STATUS for a20
col HEADER_STATUS for a20
col MODE_STATUS for a20
col STATE for a20
select PATH,OS_MB,MOUNT_STATUS,HEADER_STATUS,MODE_STATUS,STATE from v$asm_disk where PATH like '%/dev/oradisk/u10_DATA5_%' and HEADER_STATUS='FORMER' order by PATH;

set pages 10000
set linesize 300
col PATH for a40
col OS_MB for a40
col MOUNT_STATUS for a20
col HEADER_STATUS for a20
col MODE_STATUS for a20
col STATE for a20
select PATH,OS_MB,MOUNT_STATUS,HEADER_STATUS,MODE_STATUS,STATE from v$asm_disk where PATH like '%/dev/oracleasm/disks/U7_%' and HEADER_STATUS='PROVISIONED' order by PATH;

SELECT g.name dg_name,d.name dk_name, d.path , d.total_mb disk_size_mb, d.state dk_state
FROM v$asm_disk d, v$asm_diskgroup g
WHERE g.group_number=d.group_number;

select failgroup,path,os_mb from v$asm_disk where GROUP_NUMBER='14'; 
############################# CHECK REBALANCE ###############################
set lines 300
set pagesize 4000
select INST_ID, OPERATION, STATE, POWER, SOFAR, EST_WORK, EST_RATE, EST_MINUTES, ERROR_CODE from GV$ASM_OPERATION;

SET LINESIZE 130
SET PAGES 10000
COL NAME FOR A12
COL "group#" FORMAT 9999998
COL OPERATION FORMAT A9
COL STATE FORMAT A5
COL POWER FORMAT 99
COL ACTUAL FORMAT 99
COL ERROR_CODE FOR A15
BREAK ON NAME
SELECT name
       , o.inst_id RAC_INST
       , o.operation
       , o.state
       , power
       , actual
       , sofar
       , est_work
       , est_rate
       , est_minutes
       , error_code
FROM   gv$asm_operation o
       , v$asm_diskgroup g
WHERE  o.group_number = g.group_number
ORDER  BY name, inst_id;


#############################################################################
alter diskgroup DATA2 drop disk DATA2_A57_DISK07, DATA2_A57_DISK08, DATA2_T2_DISK07, DATA2_T2_DISK08 rebalance power 10;
CLEARING DISK HEADERS:

Manual:
Assuming the disk is in /dev/asm-disk1:
# dd if=/dev/zero of=/dev/asm-disk1 bs=1024 count=100

Using oracleasm delete disks:
oracleasm deletedisk /dev/oracleasm/disks/U12_T1000G_T2_027
Clearing disk header: done
Dropping disk: done

############################# ADD DISKS ###############################


/dev/oracleasm/disks/U12_T1000G_A57_119
/dev/oracleasm/disks/U12_T1000G_A57_120
/dev/oracleasm/disks/U12_T1000G_A57_121
/dev/oracleasm/disks/U12_T1000G_A57_122
/dev/oracleasm/disks/U12_T1000G_A57_123
/dev/oracleasm/disks/U12_T1000G_A57_124
/dev/oracleasm/disks/U12_T1000G_A57_125
/dev/oracleasm/disks/U12_T1000G_A57_126

/dev/oracleasm/disks/U12_T1000G_T2_119
/dev/oracleasm/disks/U12_T1000G_T2_120
/dev/oracleasm/disks/U12_T1000G_T2_121
/dev/oracleasm/disks/U12_T1000G_T2_122
/dev/oracleasm/disks/U12_T1000G_T2_123
/dev/oracleasm/disks/U12_T1000G_T2_124
/dev/oracleasm/disks/U12_T1000G_T2_125
/dev/oracleasm/disks/U12_T1000G_T2_126



ALTER DISKGROUP DATA5 add
FAILGROUP DATA5_RZ_A57 DISK
'/dev/oracleasm/disks/U12_T1000G_A57_119' NAME DATA5_A57_DISK73,
'/dev/oracleasm/disks/U12_T1000G_A57_120' NAME DATA5_A57_DISK74,
'/dev/oracleasm/disks/U12_T1000G_A57_121' NAME DATA5_A57_DISK75,
'/dev/oracleasm/disks/U12_T1000G_A57_122' NAME DATA5_A57_DISK76,
'/dev/oracleasm/disks/U12_T1000G_A57_123' NAME DATA5_A57_DISK77,
'/dev/oracleasm/disks/U12_T1000G_A57_124' NAME DATA5_A57_DISK78,
'/dev/oracleasm/disks/U12_T1000G_A57_125' NAME DATA5_A57_DISK79,
'/dev/oracleasm/disks/U12_T1000G_A57_126' NAME DATA5_A57_DISK80
FAILGROUP DATA5_RZ_T2 DISK
'/dev/oracleasm/disks/U12_T1000G_T2_119' NAME DATA5_T2_DISK73,
'/dev/oracleasm/disks/U12_T1000G_T2_120' NAME DATA5_T2_DISK74,
'/dev/oracleasm/disks/U12_T1000G_T2_121' NAME DATA5_T2_DISK75,
'/dev/oracleasm/disks/U12_T1000G_T2_122' NAME DATA5_T2_DISK76,
'/dev/oracleasm/disks/U12_T1000G_T2_123' NAME DATA5_T2_DISK77,
'/dev/oracleasm/disks/U12_T1000G_T2_124' NAME DATA5_T2_DISK78,
'/dev/oracleasm/disks/U12_T1000G_T2_125' NAME DATA5_T2_DISK79,
'/dev/oracleasm/disks/U12_T1000G_T2_126' NAME DATA5_T2_DISK80
rebalance power 10;

alter diskgroup DATA4 drop disk 
DATA4_A57_DISK76,
DATA4_A57_DISK77,
DATA4_A57_DISK78,
DATA4_A57_DISK79,
DATA4_A57_DISK80,
DATA4_A57_DISK81,
DATA4_A57_DISK82,
DATA4_A57_DISK83,
DATA4_T2_DISK76,
DATA4_T2_DISK77,
DATA4_T2_DISK78,
DATA4_T2_DISK79,
DATA4_T2_DISK80,
DATA4_T2_DISK81,
DATA4_T2_DISK82,
DATA4_T2_DISK83
rebalance power 8;

/dev/oracleasm/disks/U12_T500G_A57_160
/dev/oracleasm/disks/U12_T500G_A57_161
/dev/oracleasm/disks/U12_T500G_A57_162
/dev/oracleasm/disks/U12_T500G_A57_163
/dev/oracleasm/disks/U12_T500G_T2_160
/dev/oracleasm/disks/U12_T500G_T2_161
/dev/oracleasm/disks/U12_T500G_T2_162
/dev/oracleasm/disks/U12_T500G_T2_163 


/dev/oracleasm/disks/U12_T500G_A57_162
/dev/oradisk/u10_DATA5_T2_1T_058      
/dev/oracleasm/disks/U12_T500G_A57_163
/dev/oradisk/u10_DATA5_T2_1T_056      
/dev/oracleasm/disks/U12_T500G_A57_160
/dev/oradisk/u10_DATA5_T2_1T_064      
/dev/oracleasm/disks/U12_T500G_T2_162 
/dev/oradisk/u10_DATA5_T2_1T_062      
/dev/oracleasm/disks/U12_T500G_T2_161 
/dev/oradisk/u10_DATA5_T2_1T_060      
/dev/oracleasm/disks/U12_T500G_A57_161
/dev/oracleasm/disks/U12_T500G_T2_163 
/dev/oracleasm/disks/U12_T500G_T2_160 


ALTER DISKGROUP FRA6 add
FAILGROUP FRA6_RZ_A57 DISK
'/dev/oracleasm/disks/U12_T1000G_A57_007' NAME FRA6_A57_DISK04
FAILGROUP FRA6_RZ_T2 DISK
'/dev/oracleasm/disks/U12_T1000G_T2_007' NAME FRA6_T2_DISK04
rebalance power 4; 

select nvl(name,'NONAME') as name , path, header_status, total_mb, free_mb from v$asm_disk
/

Later tonight!

ALTER DISKGROUP BACKUPS add
FAILGROUP BACKUPS_RZ_A57 DISK
'/dev/oracleasm/disks/U11_TEMP_A57_128' NAME BACKUPS_A57_DISK08,
'/dev/oracleasm/disks/U11_TEMP_A57_129' NAME BACKUPS_A57_DISK09,
'/dev/oracleasm/disks/U11_TEMP_A57_130' NAME BACKUPS_A57_DISK10,
'/dev/oracleasm/disks/U11_TEMP_A57_131' NAME BACKUPS_A57_DISK11
FAILGROUP BACKUPS_RZ_T2 DISK
'/dev/oracleasm/disks/U11_TEMP_T2_128' NAME BACKUPS_T2_DISK08,
'/dev/oracleasm/disks/U11_TEMP_T2_129' NAME BACKUPS_T2_DISK09,
'/dev/oracleasm/disks/U11_TEMP_T2_130' NAME BACKUPS_T2_DISK10,
'/dev/oracleasm/disks/U11_TEMP_T2_131' NAME BACKUPS_T2_DISK11
rebalance power 10;

ALTER DISKGROUP FRA add
FAILGROUP FRA_RZ_A57 DISK
'/dev/oradisk/u10_FRA_A57_500G_001' NAME FRA_A57_DISK02
FAILGROUP FRA_RZ_T2 DISK
'/dev/oradisk/u10_FRA_T2_500G_002' NAME FRA_T2_DISK02
rebalance power 8;


iv5Z_vMuMCv6uhg_xoUbiYPknMuCLQ@T60007


alter diskgroup DATA2 drop disk
DATA2_A57_DISK10,DATA2_T2_DISK10,DATA2_A57_DISK09,DATA2_T2_DISK09
rebalance power 6;


alter diskgroup DATA6 drop disk DATA6_A57_DISK20, DATA6_A57_DISK21, DATA6_A57_DISK30, DATA6_T2_DISK20, DATA6_T2_DISK21, DATA6_T2_DISK30 rebalance power 4;
alter diskgroup <DG_NAME> rebalance power 10;

#################################################
Checking the storage capacity of DG:

select * from INVENTORY_V2.V_GET_DISK_GROUP_LOW_DATA;
select * from INVENTORY_V2.V_GET_DISK_GROUP_LOW_FRA;
select * from INVENTORY_V2.V_GET_DISK_GROUP_LOW_OCR;
select * from INVENTORY_V2.V_GET_DISK_GROUP_LOW_TEST; 

######################################## 
ASMLIB CREATE NEW DISK GROUP:
########################################
u3_DATA5_A57_002
u3_DATA5_T2_002 
u3_DATA6_A57_002
u3_DATA6_T2_002 

u3_FRA5_A57_002
u3_FRA5_T2_002 
u3_FRA6_A57_002
u3_FRA6_T2_002 

1. After Unix team add the disks to multipath check and detect them:

ll /dev/mapper

2. Once you see the new LUNs in /dev/mapper create ASM volumes:

*ROOT*

oracleasm createdisk "disk name" /dev/mapper/"disk name"

Example: 
oracleasm createdisk U10_OCRVOTE_A57_001 /dev/mapper/U10_OCRVOTE_A57_001
oracleasm createdisk U10_OCRVOTE_T2_001 /dev/mapper/U10_OCRVOTE_T2_001

oracleasm createdisk u4_FRA8_A57_002 /dev/mapper/u4_FRA8_A57_002
oracleasm createdisk u4_FRA8_T2_002 /dev/mapper/u4_FRA8_T2_002

oracleasm createdisk u2_DATA6_A57_002 /dev/mapper/u2_DATA6_A57_002
oracleasm createdisk u2_DATA6_T2_002 /dev/mapper/u2_DATA6_T2_002

oracleasm createdisk u2_FRA6_A57_002 /dev/mapper/u2_FRA6_A57_002
oracleasm createdisk u2_FRA6_T2_002 /dev/mapper/u2_FRA6_T2_002

oracleasm createdisk U7_TEST_A57_002 /dev/mapper/u7_TEST_A57_002
oracleasm createdisk U7_TEST_T2_002 /dev/mapper/u7_TEST_T2_002
Example: oracleasm createdisk u5_FRA8_T2_002 /dev/mapper/u5_FRA8_T2_002

3. Check if the new LUNS are available:

oracleasm scandisks

oracleasm listdisks

4. Repeate step 3 on all nodes of the RAC 


5. Creation of the DiskGroup:

CREATE DISKGROUP TEST NORMAL REDUNDANCY
  FAILGROUP TEST_RZ_A57 DISK
    '/dev/oracleasm/disks/U7_TEST_A57_002' NAME TEST_A57_DISK02
  FAILGROUP TEST_RZ_T2 DISK
    '/dev/oracleasm/disks/U7_TEST_T2_002' NAME TEST_T2_DISK02
  ATTRIBUTE 'au_size'='4M',
    'compatible.asm' = '12.2.0.1.0',
    'compatible.rdbms' = '12.1.0.0.0',
	'compatible.advm' = '11.2';
	

CREATE DISKGROUP TEST EXTERNAL REDUNDANCY DISK '/dev/oracleasm/disks/U7_TEST_A57_002' NAME TEST_A57_DISK02
  ATTRIBUTE 'au_size'='4M',
    'compatible.asm' = '12.2.0.1.0',
    'compatible.rdbms' = '12.1.0.0.0',
	'compatible.advm' = '11.2';

  FAILGROUP TEST_RZ_T2 DISK
    '/dev/oracleasm/disks/U7_TEST_T2_002' NAME TEST_T2_DISK02










	
CREATE DISKGROUP DATA8 NORMAL REDUNDANCY
  FAILGROUP DATA8_RZ_A57 DISK
    '/dev/oracleasm/disks/U4_DATA8_A57_002' NAME DATA8_A57_DISK02
  FAILGROUP DATA8_RZ_T2 DISK
    '/dev/oracleasm/disks/U4_DATA8_T2_002' NAME DATA8_T2_DISK02
  ATTRIBUTE 'au_size'='4M',
    'compatible.asm' = '12.2.0.1.0',
    'compatible.rdbms' = '12.1.0.0.0',
	'compatible.advm' = '11.2';

As Grid user to start the new DG (execute on each node):

srvctl start diskgroup -diskgroup DATA8
srvctl start diskgroup -diskgroup DATA6
srvctl start diskgroup -diskgroup FRA8
srvctl start diskgroup -diskgroup FRA6

################################################################################
################################################################################

volcreate -G ACFS -s VOL_APP3                       /dev/asm/vol_app3-187
VOL_APP4                       /dev/asm/vol_app4-187


As root
Creation of the FS
/sbin/mkfs -t acfs -n /u01/dbteam/application/094_FONG/prelive /dev/asm/vol_app3-187
/sbin/mkfs -t acfs -n /u01/dbteam/application/094_FONG/tui /dev/asm/vol_app4-187

Registering the FS:
/sbin/acfsutil registry -a /dev/asm/vol_app3-187 /u01/dbteam/application/094_FONG/prelive
/sbin/acfsutil registry -a /dev/asm/vol_app4-187 /u01/dbteam/application/094_FONG/tui

Mount the FS:
/bin/mount -t acfs -o all /dev/asm/vol_app3-187 /u01/dbteam/application/094_FONG/prelive
/bin/mount -t acfs -o all /dev/asm/vol_app4-187 /u01/dbteam/application/094_FONG/tui

Setting up the ownership:
chown -R fongimp:oinstall /u01/dbteam/application/094_FONG/prelive
chown -R fongimp:oinstall /u01/dbteam/application/094_FONG/tui






/bin/umount -t acfs -o all /dev/asm/vol_dump1-187 /u01/dbteam/dump



/bin/mount -t acfs /dev/asm/vol_dbs1-187 /u01/app/oracle/product/rdbms/dbs
/bin/mount -t acfs /dev/asm/vol_app2-187 /u01/dbteam/application/038_GWB/PreLive
/bin/mount -t acfs /dev/asm/vol_app1-187 /u01/dbteam/application/038_GWB/TuI
/bin/mount -t acfs /dev/asm/vol_app3-187 /u01/dbteam/application/094_FONG/prelive
/bin/mount -t acfs /dev/asm/vol_app4-187 /u01/dbteam/application/094_FONG/tui




srvctl start diskgroup -diskgroup DATA5
srvctl start diskgroup -diskgroup DATA6
srvctl start diskgroup -diskgroup FRA5
srvctl start diskgroup -diskgroup FRA6

################ How to drop a diskgroup from Asm in RAC ################
Perform the following command on all remote nodes of the cluster (2,3,4..):
su - grid
sqlplus / as sysasm
alter diskgroup <DG_NAME> dismount force;

Once the above operation is completed on all of the remote nodes of the cluster do the following from the local node (1):
su - grid
sqlplus / as sysasm
drop diskgroup <DG_NAME> including contents;




#########################################################################
#########################################################################
HOW TO FIX THE FOLLOWING ISSUE:

NVL(G.NAME,'[CANDIDATE]')      NAME                           DISK_NUMBER      OS_MB   TOTAL_MB MOUNT_S HEADER_STATU
------------------------------ ------------------------------ ----------- ---------- ---------- ------- ------------
BACKUPS                        BACKUPS_A57_DISK02                       0    1024000    1024000 CACHED  MEMBER
BACKUPS                        _DROPPED_0002_BACKUPS                    2          0    1024000 MISSING UNKNOWN

SQL> select name,disk_number,path,mount_status,header_status,mode_status,state,failgroup,repair_timer from v$asm_disk where group_number = 1 order by disk_number;

NAME                           DISK_NUMBER
------------------------------ -----------
PATH
--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
MOUNT_S HEADER_STATU MODE_ST STATE    FAILGROUP                      REPAIR_TIMER
------- ------------ ------- -------- ------------------------------ ------------
BACKUPS_A57_DISK02                       0
/dev/oracleasm/disks/U7_BACKUPS_A57_002
CACHED  MEMBER       ONLINE  NORMAL   BACKUPS_RZ_A57                            0

_DROPPED_0002_BACKUPS                    2

MISSING UNKNOWN      OFFLINE FORCING  BACKUPS_RZ_T2                            71


SQL> select group_number,name,state,HEADER_STATUS,path,label from v$asm_disk;

GROUP_NUMBER NAME                           STATE    HEADER_STATU
------------ ------------------------------ -------- ------------
PATH
--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
LABEL
-------------------------------
           0                                NORMAL   MEMBER
/dev/oracleasm/disks/U7_FRA_T2_002


           0                                NORMAL   MEMBER
/dev/oracleasm/disks/U7_DATA2_T2_002


          13 _DROPPED_0002_FRA              FORCING  UNKNOWN



           1 _DROPPED_0002_BACKUPS          FORCING  UNKNOWN



          11 _DROPPED_0002_ACFS             FORCING  UNKNOWN



          10 _DROPPED_0001_FRA3             FORCING  UNKNOWN



           9 _DROPPED_0001_DATA3            FORCING  UNKNOWN



           8 _DROPPED_0002_FRA1             FORCING  UNKNOWN



           7 _DROPPED_0001_FRA4             FORCING  UNKNOWN



           6 _DROPPED_0001_DATA2            FORCING  UNKNOWN



           5 _DROPPED_0001_DATA4            FORCING  UNKNOWN



           4 _DROPPED_0002_DATA1            FORCING  UNKNOWN



           2 _DROPPED_0000_FRA2             FORCING  UNKNOWN




Because of the redundancy the failed disk from the T2 Failgroup couldn`t be removed even with force option, therefore the disk could not be added back in the DG because it is not yet dropped.

Here is how to proceed (remember this isssue is spotted on ASMlib configured systems)

Step 1) Verify that the header of the failed disk is available:

	[root@iudb939(Staging) ~]# kfed read /dev/mapper/u7_BACKUPS_T2_002
clscfpinit: Failed clsdinitx [-1] ecode [64]
2019-09-27 08:48:00.899 [3646931456] gipclibInitializeClsd: clscfpinit failed with -1.

kfbh.endian:                          1 ; 0x000: 0x01
kfbh.hard:                          130 ; 0x001: 0x82
kfbh.type:                            1 ; 0x002: KFBTYP_DISKHEAD
kfbh.datfmt:                          2 ; 0x003: 0x02
kfbh.block.blk:                       0 ; 0x004: blk=0
kfbh.block.obj:              2147483650 ; 0x008: disk=2
kfbh.check:                  1519507864 ; 0x00c: 0x5a91d998
kfbh.fcn.base:                   316172 ; 0x010: 0x0004d30c
kfbh.fcn.wrap:                        0 ; 0x014: 0x00000000
kfbh.spare1:                          0 ; 0x018: 0x00000000
kfbh.spare2:                          0 ; 0x01c: 0x00000000
kfdhdb.driver.provstr:ORCLDISKU7_BACKUPS_T2_002 ; 0x000: length=25
kfdhdb.driver.reserved[0]:   1113536341 ; 0x008: 0x425f3755
kfdhdb.driver.reserved[1]:   1430995777 ; 0x00c: 0x554b4341
kfdhdb.driver.reserved[2]:   1415533392 ; 0x010: 0x545f5350
kfdhdb.driver.reserved[3]:    808476466 ; 0x014: 0x30305f32
kfdhdb.driver.reserved[4]:           50 ; 0x018: 0x00000032
kfdhdb.driver.reserved[5]:            0 ; 0x01c: 0x00000000
kfdhdb.compat:                203424000 ; 0x020: 0x0c200100
kfdhdb.dsknum:                        2 ; 0x024: 0x0002
kfdhdb.grptyp:                        2 ; 0x026: KFDGTP_NORMAL
kfdhdb.hdrsts:                        3 ; 0x027: KFDHDR_MEMBER
kfdhdb.dskname:       BACKUPS_T2_DISK02 ; 0x028: length=17
kfdhdb.grpname:                 BACKUPS ; 0x048: length=7
kfdhdb.fgname:            BACKUPS_RZ_T2 ; 0x068: length=13
kfdhdb.siteguid[0]:                   0 ; 0x088: 0x00

If you receive and error you should re-create the header.

The main rows we are looking for are kfdhdb.dskname; kfdhdb.grpname; kfdhdb.fgname; kfdhdb.grptyp; kfdhdb.hdrsts

In our case the header is okay.

Step 2) 

Log in as sysasm and issue the following command:

Remember to use the full path and name it exactly with the same name and the size should be the exact size the of the disk/LUN!

alter diskgroup BACKUPS add FAILGROUP BACKUPS_RZ_T2 disk '/dev/oracleasm/disks/U7_BACKUPS_T2_002' name BACKUPS_T2_DISK02 size 1024000M force;

Check the disks:

set pagesize 200 linesize 200
select NVL(g.name, '[CANDIDATE]'), d.NAME, d.DISK_NUMBER, d.OS_MB, d.TOTAL_MB, d.MOUNT_STATUS, d.HEADER_STATUS
 from  v$asm_diskgroup G RIGHT OUTER JOIN v$asm_disk d USING (group_number)
-- where d.GROUP_NUMBER = G.GROUP_NUMBER
  4  order by 1,2;

NVL(G.NAME,'[CANDIDATE]')      NAME                           DISK_NUMBER      OS_MB   TOTAL_MB MOUNT_S HEADER_STATU
------------------------------ ------------------------------ ----------- ---------- ---------- ------- ------------
BACKUPS                        BACKUPS_A57_DISK02                       0    1024000    1024000 CACHED  MEMBER
BACKUPS                        BACKUPS_T2_DISK02                        3    1024000    1024000 CACHED  MEMBER
BACKUPS                        _DROPPED_0002_BACKUPS                    2          0    1024000 MISSING UNKNOWN

Now the failed disk is restored and rebalance process should be triggered to allow the ASM to get rid of the disk named "_DROPPED_0002_*****":

SQL> select INST_ID, OPERATION, STATE, POWER, SOFAR, EST_WORK, EST_RATE, EST_MINUTES, ERROR_CODE from GV$ASM_OPERATION;

   INST_ID OPERA STAT      POWER      SOFAR   EST_WORK   EST_RATE EST_MINUTES ERROR_CODE
---------- ----- ---- ---------- ---------- ---------- ---------- ----------- --------------------------------------------
         1 REBAL WAIT          1          0          0          0           0
         1 REBAL WAIT          1          0          0          0           0
         1 REBAL RUN           1       2009      94382      13944           6
         1 REBAL DONE          1          0          0          0           0
         2 REBAL WAIT          1
         2 REBAL WAIT          1
         2 REBAL WAIT          1
         2 REBAL WAIT          1

Wait until the rebalance is complete and check the status of the diskgroup "BACKUPS" once more:


NVL(G.NAME,'[CANDIDATE]')      NAME                           DISK_NUMBER      OS_MB   TOTAL_MB MOUNT_S HEADER_STATU
------------------------------ ------------------------------ ----------- ---------- ---------- ------- ------------
BACKUPS                        BACKUPS_A57_DISK02                       0    1024000    1024000 CACHED  MEMBER
BACKUPS                        BACKUPS_T2_DISK02                        3    1024000    1024000 CACHED  MEMBER



