========================================================
=======================================================
####### ERROR:
 ORA-01017: invalid username/password; logon denied
 CONNECT: rman/*****@FMAXPRD                                       <Username>/<Password>@<service>
                                    
									Не си разпознава паролата или не се знае
 
 =======================================================
 
 su - oracle
 
 . oraenv
 
 rman target /
 
 RMAN> connect catalog rman/fortumuser@FMAXPRD                 ###### Пробваме дали ще се закачи за каталога, като пробваме за парола <fortumuser>
 
 MAN> connect catalog rman/rman04bkp@FMAXPRD;                  ###### Пробваме дали ще се закачи за каталога, като пробваме за парола <rman04bkp>
 
 
                      ##############Ако не става значи пасуърд каталог аима нещо нередно ##########
					  
					  
sqlplus / as sysdba


############# Да Проверим статуса на акаунта ####

SQL> select USERNAME, ACCOUNT_STATUS from dba_users where username='RMAN';

USERNAME                                                                                                                         ACCOUNT_STATUS
-------------------------------------------------------------------------------------------------------------------------------- --------------------------------
RMAN                                                                                                                             OPEN
					  
					  
					  




######### Даа проверим в Password file

SQL> SELECT * FROM v$pwfile_users WHERE sysdba='TRUE';

no rows selected


####### Да проверим в оракъл холма за пасуърд файла

cd $OARCLE_HOME
ls -la

drwxr-xr-x  4 oracle oinstall     4096 Aug  6 19:04 .
drwxrwxr-x 74 oracle oinstall     4096 Aug 15 05:41 ..
drwxr-x---  2 oracle asmadmin     4096 Mar  6 02:45 core_2309
drwxr-x---  2 oracle asmadmin     4096 Mar  6 02:46 core_32576
-rw-rw----  1 oracle asmadmin     1544 Aug  6 19:04 hc_FMAXPRD1.dat
-rw-rw----  1 oracle asmadmin   524288 Aug 15 08:13 id_FMAXPRD1.dat
-rw-r--r--  1 oracle asmadmin      928 Apr  8  2017 initFMAXPRD1_kk.ora
-rw-r-----  1 oracle oinstall       41 Apr  7  2017 initFMAXPRD1.ora
-rw-r--r--  1 oracle oinstall     2992 Feb  3  2012 init.ora
-rw-r-----  1 oracle oinstall     7680 Jul 25 13:09 orapwFMAXPRD1.old                      ###### orapw - това е пасуърд файла,тук проблема е ,че е сменено името с окончание .old
-rw-r--r--  1 oracle asmadmin     1017 Apr  7  2017 rado2.ora                                       и не се четат паролите както е по спецификация
-rw-r--r--  1 oracle asmadmin     1759 Apr  7  2017 rado_backu_spfile.ora
-rw-r--r--  1 oracle asmadmin     1926 Feb 22 21:03 rado.ora
-rw-r--r--  1 oracle oinstall      944 Apr  7  2017 rado.rado
-rwxrwxrwx  1 oracle asmadmin      855 May 17  2017 rado_restore.ora
-rw-r-----  1 oracle asmadmin 21151744 Apr 10  2017 snapcf_FMAXPRD1.f
-rw-r-----  1 oracle asmadmin     4608 Apr  8  2017 spfileFMAXPRD1.ora
-rw-r-----  1 oracle oinstall     4608 Apr  7  2017 spfile.ora.fmaxprod.old

				  
mv orapwFMAXPRD1.old orapwFMAXPRD1                                    #### като user oracle
				  
				  
				 
### Проверяваме пак,но има само sys Правата				 
SQL> SELECT * FROM v$pwfile_users WHERE sysdba='TRUE';

USERNAME                       SYSDB SYSOP SYSAS SYSBA SYSDG SYSKM     CON_ID
------------------------------ ----- ----- ----- ----- ----- ----- ----------
SYS                            TRUE  TRUE  FALSE FALSE FALSE FALSE          0



#### Грантваме sysdba за RMAN
SQL> grant sysdba to RMAN ;

Grant succeeded.


### проверяваме и вече го има RMAN, колона SYSDB трябва винаги да е TRUE
SQL> SELECT * FROM v$pwfile_users WHERE sysdba='TRUE';

USERNAME                       SYSDB SYSOP SYSAS SYSBA SYSDG SYSKM     CON_ID
------------------------------ ----- ----- ----- ----- ----- ----- ----------
SYS                            TRUE  TRUE  FALSE FALSE FALSE FALSE          0
RMAN                           TRUE  FALSE FALSE FALSE FALSE FALSE          0



#######Виждаме дали има oмnib и пускаме за проверка archive log backup за да видим дали сме разрешили проблема 
			  
[oracle@fivatx0191:FMAXPRD1 dbs]$ nohup /opt/omni/bin/omnib  -Oracle8 fivatx0191_FMAXPRD_archivelog_on &


[oracle@fivatx0191:FMAXPRD1 dbs]$ tail -100f nohup.out




===================================
===================================
Hello ,

Please be informed that we experience issue with fiesps0865.adinfra.net . Our backup failed due to authentication error :

	The database reported error while performing requested operation.

ERROR:
 ORA-01017: invalid username/password; logon denied
 CONNECT: rman/*****@FMAXPRD

Could you please check the base and if it configured properly ?

Thank you in advance!
BURS TEAM
=====================================
=====================================

Hello,

We received service request E2-IM020602755/ [FORTUM] Issue with fiesps0865.adinfra.net
The issue have been resolved. We run archive log backup which was completed successfully.

Your service request will be put on status Resolved. If you need any further assistance do not hesitate to contact us via e-mail or reopen the case.


Best regards,
Izabela Pehlivanska
Technical Support
iAction | Oracle Database Team
+359 889 820 093 Red Phone
CM-ITO-DO-BULGARIA-ORACLE@dxc.com
Business Park Sofia, Building 9
Sofia, Bulgaria
 
=========================================
========================================


