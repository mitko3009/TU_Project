/********************************************************************************
*********       E-mail subject: EFDE2DEV-1239
*********             Instance: PATCH2
*********          Description: 
Problem:
SQL cgk034na3y2wh from std_migr_mvt.migrate_lim was using innapropriate execution plan.

Analysis:
From the analyze of td_migr_mvt.migrate_lim module, I found that SQL cgk034na3y2wh was making full scan 
of table STD_MIGR_CCD, which is not good from performance point of view in this case. There are two possible optimizations that can be applied here.
The first variant is to create index on column DEBTOR_ID on table STD_MIGR_CCD, which will allow the table to be accessed by the index instead of making full scan.
The second variant is to koin the query directly to the cursor. This variant is better, but may by it will be difficult to do it and will take more time.

Suggestion:
Please apply one of the suggested variants.


*********               SQL_ID: cgk034na3y2wh
*********      Program/Package: std_migr_mvt.migrate_lim
*********              Request: Ognyan Tonev
*********               Author: Dimitar Dimitrov
********* Received e-mail date: 27/02/2024
*********      Resolution date: 29/02/2024
*********  Trace old file here: \\epox\specifs\performance\tmp\
*********  Trace new file here:
***********************************************************************************/

/********************************OLD SQL*******************************************/
var B1 VARCHAR2(128);
exec :B1 := '1501010253';
var B2 VARCHAR2(2000);
exec :B2 := 'A601GCYP';
var B3 VARCHAR2(2000);
exec :B3 := 'A607UWQF';
var B4 VARCHAR2(128);
exec :B4 := 'CONTRAT';

SELECT MAX(CPT.REFDOSS)
  FROM STD_MIGR_CCD A, 
       G_DOSSIER CPT, 
       G_DOSSIER DE, 
       G_DOSSIER CON
 WHERE DECODE(:B4, 'CONTRAT IMP', A.T_C, A.CLIENT_ID) = :B3
   AND A.DEBTOR_ID = :B2
   AND CPT.REFDOSS = A.IMX_REF
   AND DE.REFDOSS = CPT.REFLOT
   AND CON.REFDOSS = DE.REFLOT
   AND CON.REFDOSS = :B1; 
/********************************OLD SQL*******************************************/
/********************************OLD Metrics***************************************/
/*
MODULE                           SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL            PERC
-------------------------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
std_migr_mvt.migrate_lim                                                        ON CPU               2024/02/25 15:25:04  2024/02/25 16:11:38        4689             14045214 +000000000 00:46:33.616 99%


MODULE                           SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL            PERC
-------------------------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
std_migr_mvt.migrate_lim         cgk034na3y2wh 4174792455                       ON CPU               2024/02/25 15:25:04  2024/02/25 16:09:48        3806               468165 +000000000 00:44:43.554 81%
std_migr_mvt.migrate_lim         4xhw8z3u415as          0                                            2024/02/25 15:25:14  2024/02/25 16:09:38         221               443730 +000000000 00:44:23.536 5%
std_migr_mvt.migrate_lim         gcz8uccwcfyb2          0                                            2024/02/25 15:25:04  2024/02/25 16:10:38         189                   18 +000000000 00:45:33.586 4%
std_migr_mvt.migrate_lim                                0                                            2024/02/25 15:25:04  2024/02/25 16:10:38          42                    1 +000000000 00:45:33.586 1%
std_migr_mvt.migrate_lim         cpfga38c7as8x 2215417754                                            2024/02/25 15:25:14  2024/02/25 16:08:28          30               425858 +000000000 00:43:13.493 1%
std_migr_mvt.migrate_lim         6ts3csw962ngw          0                       ON CPU               2024/02/25 15:25:14  2024/02/25 16:05:58          28               216065 +000000000 00:40:43.326 1%

MODULE                           SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL            PERC
-------------------------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
std_migr_mvt.migrate_lim         cgk034na3y2wh 4174792455        359      46172 ON CPU               2024/02/25 15:25:04  2024/02/25 16:09:38         228               467999 +000000000 00:44:33.547 5%
std_migr_mvt.migrate_lim         cgk034na3y2wh 4174792455        870      55885 ON CPU               2024/02/25 15:25:04  2024/02/25 16:09:08         228               466432 +000000000 00:44:03.530 5%
std_migr_mvt.migrate_lim         cgk034na3y2wh 4174792455        183       8441 ON CPU               2024/02/25 15:25:04  2024/02/25 16:08:58         227               465585 +000000000 00:43:53.524 5%
std_migr_mvt.migrate_lim         cgk034na3y2wh 4174792455        521      34590 ON CPU               2024/02/25 15:25:04  2024/02/25 16:09:28         226               467748 +000000000 00:44:23.542 5%
std_migr_mvt.migrate_lim         cgk034na3y2wh 4174792455         14      51021 ON CPU               2024/02/25 15:25:04  2024/02/25 16:08:38         223               463789 +000000000 00:43:33.511 5%
std_migr_mvt.migrate_lim         cgk034na3y2wh 4174792455        867      39234 ON CPU               2024/02/25 15:25:04  2024/02/25 16:09:18         223               467153 +000000000 00:44:13.535 5%
std_migr_mvt.migrate_lim         cgk034na3y2wh 4174792455        182      43354 ON CPU               2024/02/25 15:25:04  2024/02/25 16:09:08         219               466429 +000000000 00:44:03.530 5%
std_migr_mvt.migrate_lim         cgk034na3y2wh 4174792455        524       1708 ON CPU               2024/02/25 15:25:14  2024/02/25 16:08:08         216               459131 +000000000 00:42:53.472 5%
std_migr_mvt.migrate_lim         cgk034na3y2wh 4174792455        697       1010 ON CPU               2024/02/25 15:25:14  2024/02/25 16:09:48         212               466432 +000000000 00:44:33.543 4%
std_migr_mvt.migrate_lim         cgk034na3y2wh 4174792455        354      55972 ON CPU               2024/02/25 15:25:14  2024/02/25 16:04:58         206               442405 +000000000 00:39:43.240 4%
std_migr_mvt.migrate_lim         cgk034na3y2wh 4174792455        358      40316 ON CPU               2024/02/25 15:25:04  2024/02/25 16:04:58         205               444123 +000000000 00:39:53.251 4%
std_migr_mvt.migrate_lim         cgk034na3y2wh 4174792455        181       7213 ON CPU               2024/02/25 15:25:14  2024/02/25 16:05:08         203               443485 +000000000 00:39:53.255 4%
std_migr_mvt.migrate_lim         cgk034na3y2wh 4174792455       1208       6680 ON CPU               2024/02/25 15:25:04  2024/02/25 16:04:18         201               438745 +000000000 00:39:13.195 4%
std_migr_mvt.migrate_lim         cgk034na3y2wh 4174792455         17      65437 ON CPU               2024/02/25 15:25:14  2024/02/25 16:05:08         201               443483 +000000000 00:39:53.255 4%
std_migr_mvt.migrate_lim         cgk034na3y2wh 4174792455        692      42214 ON CPU               2024/02/25 15:25:14  2024/02/25 16:04:58         200               442404 +000000000 00:39:43.240 4%
std_migr_mvt.migrate_lim         cgk034na3y2wh 4174792455        517      35339 ON CPU               2024/02/25 15:25:04  2024/02/25 16:04:38         197               441686 +000000000 00:39:33.223 4%
std_migr_mvt.migrate_lim         cgk034na3y2wh 4174792455       1034      38318 ON CPU               2024/02/25 15:25:04  2024/02/25 16:04:18         196               438744 +000000000 00:39:13.195 4%
std_migr_mvt.migrate_lim         cgk034na3y2wh 4174792455       1380      11917 ON CPU               2024/02/25 15:25:04  2024/02/25 16:04:08         195               437077 +000000000 00:39:03.183 4%

INSTANCE_NUMBER SQL_ID            ELAPSED MAX_WAIT_ON     PC_OF  WAIT_TIME            GETS      READS       ROWS  ELAP/EXEC       GETS/EXEC READS/EXEC  ROWS/EXEC       EXEC PLAN_HASH_VALUE
--------------- ------------- ----------- --------------- ----- ---------- --------------- ---------- ---------- ---------- --------------- ---------- ---------- ---------- ---------------
              1 4xhw8z3u415as        2412 CPU             90%   2565.85956        43340442         38     430536        .01             101          0          1     430008   0
              1 cgk034na3y2wh       32483 CPU             100%  32062.1837      3631128906          0     463659        .07            7805          0          1     465228  4174792455
              1 gcz8uccwcfyb2       33588 CPU             96%   34721.7638      3324780819     114235         18    1866.01       184710046    6346.39          1         18   0
 
Plan hash value: 4174792455
-----------------------------------------------------------------------------------------------------------------------
| Id  | Operation             | Name                   | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers |
-----------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT      |                        |      1 |        |  1815 (100)|      1 |00:00:00.06 |    8214 |
|   1 |  SORT AGGREGATE       |                        |      1 |      1 |            |      1 |00:00:00.06 |    8214 |
|   2 |   NESTED LOOPS SEMI   |                        |      1 |      1 |  1815   (2)|      1 |00:00:00.06 |    8214 |
|   3 |    NESTED LOOPS       |                        |      1 |      1 |  1813   (2)|      1 |00:00:00.06 |    8211 |
|   4 |     NESTED LOOPS      |                        |      1 |      1 |  1811   (2)|      1 |00:00:00.06 |    8208 |
|*  5 |      INDEX UNIQUE SCAN| DOS_REFDOSS            |      1 |      1 |     2   (0)|      1 |00:00:00.01 |       3 |
|*  6 |      TABLE ACCESS FULL| STD_MIGR_CCD           |      1 |      1 |  1809   (2)|      1 |00:00:00.06 |    8205 |
|*  7 |     INDEX RANGE SCAN  | DOS_REFDOSS_REFLOT_IDX |      1 |      1 |     2   (0)|      1 |00:00:00.01 |       3 |
|*  8 |    INDEX RANGE SCAN   | DOS_REFDOSS_REFLOT_IDX |      1 |      1 |     2   (0)|      1 |00:00:00.01 |       3 |
-----------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   5 - access("CON"."REFDOSS"=:B1)
   6 - filter(("A"."DEBTOR_ID"=:B2 AND DECODE(:B4,'CONTRAT IMP',"A"."T_C","A"."CLIENT_ID")=:B3))
   7 - access("CPT"."REFDOSS"="A"."IMX_REF")
   8 - access("DE"."REFDOSS"="CPT"."REFLOT" AND "DE"."REFLOT"=:B1)

*/
/********************************OLD Metrics***************************************/

/********************************New SQL*******************************************/

-- No changes in the SQL text.
/********************************New SQL*******************************************/
/********************************New Metrics***************************************/
/*
-- This execution plan is from the variant where there is created index on column DEBTOR_ID on table STD_MIGR_CCD.

Plan hash value: 1183951566
-----------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                               | Name                   | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers |
-----------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                        |                        |      1 |        |    10 (100)|      1 |00:00:00.01 |      13 |
|   1 |  SORT AGGREGATE                         |                        |      1 |      1 |            |      1 |00:00:00.01 |      13 |
|   2 |   NESTED LOOPS SEMI                     |                        |      1 |      1 |    10   (0)|      1 |00:00:00.01 |      13 |
|   3 |    NESTED LOOPS                         |                        |      1 |      1 |     8   (0)|      1 |00:00:00.01 |      10 |
|   4 |     NESTED LOOPS                        |                        |      1 |      1 |     6   (0)|      1 |00:00:00.01 |       7 |
|*  5 |      INDEX UNIQUE SCAN                  | DOS_REFDOSS            |      1 |      1 |     2   (0)|      1 |00:00:00.01 |       3 |
|*  6 |      TABLE ACCESS BY INDEX ROWID BATCHED| STD_MIGR_CCD           |      1 |      1 |     4   (0)|      1 |00:00:00.01 |       4 |
|*  7 |       INDEX RANGE SCAN                  | TESD_DD_INDEX          |      1 |      1 |     2   (0)|      1 |00:00:00.01 |       3 |
|*  8 |     INDEX RANGE SCAN                    | DOS_REFDOSS_REFLOT_IDX |      1 |      1 |     2   (0)|      1 |00:00:00.01 |       3 |
|*  9 |    INDEX RANGE SCAN                     | DOS_REFDOSS_REFLOT_IDX |      1 |      1 |     2   (0)|      1 |00:00:00.01 |       3 |
-----------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   5 - access("CON"."REFDOSS"=:B1)
   6 - filter(DECODE(:B4,'CONTRAT IMP',"A"."T_C","A"."CLIENT_ID")=:B3)
   7 - access("A"."DEBTOR_ID"=:B2)
   8 - access("CPT"."REFDOSS"="A"."IMX_REF")
   9 - access("DE"."REFDOSS"="CPT"."REFLOT" AND "DE"."REFLOT"=:B1) 
*/
/********************************New Metrics***************************************/

/********************************Index statistics**********************************/

/********************************Other SQLs****************************************/          
/*

*/ 
/********************************Other SQLs****************************************/              
