/********************************************************************************
*********       E-mail subject: LBPDEV-6703
*********             Instance: LAGO
*********          Description: 
Problem:
Slowness in e_videcompte2 on instance LAGO.

Analysis:
From the trace file, we found that whe problems comes from SQL 0z055us1su08b. It whis SQL we have a function, that is called in the WHERE clause, which is 
bad for the performance and it is not recomended by P&T. This leads to unnecessary executing other SQLs hundreds of times. Also, we comapere column refperso of 
table t_gestfctcomp which is of type VARCHAR2 with NUMBER twice in query ( C.refperso = 29 ), which also can lead to performance problem. The solution is to move 
the function from the WHERE clause to the SELECT part and to compare columnd C.refperso with value of type VARCHAR2.

Suggestion:
Please change the SQL text as it is shown in the New SQL section below.

*********               SQL_ID: 0z055us1su08b
*********      Program/Package: e_videcompte2
*********              Request: Nadya Tsvetkova 
*********               Author: Dimitar Dimitrov
********* Received e-mail date: 06/02/2024
*********      Resolution date: 07/02/2024
*********  Trace old file here: \\epox\specifs\performance\tmp\
*********  Trace new file here: \\epox\specifs\performance\tmp\LBP\e_videcompte2\20240207
***********************************************************************************/

/********************************OLD SQL*******************************************/
SELECT ANCREFDOSS, DEVISE, REFDOSS, REFINDIVIDU, REFLOT, REFFACTOR
  FROM (SELECT (SELECT gd.ancrefdoss
                  FROM g_dossier GD
                 WHERE gd.refdoss = D.reflot
                   AND gd.categdoss = 'CONTRAT') ancrefdoss,
               D.refdoss refdoss,
               D.reflot reflot,
               D.devise devise,
               T.refindividu refindividu,
               D.reffactor
          FROM g_dossier D, t_intervenants T
         WHERE D.categdoss LIKE 'DECOMPTE%'
           AND D.refdoss = T.refdoss
           AND T.reftype = DECODE(D.categdoss, 'DECOMPTE IMP', 'TC', 'CL')
           AND EXISTS
         (SELECT 1
                  FROM g_piece P
                 WHERE NVL(P.fg121, 'N') = 'N'
                   AND NVL(P.fg30, 'N') = NVL('N', 'N')
                   AND P.typpiece = 'SOUS-CONTRAT'
                   AND P.refdoss = D.refdoss)
           AND Ftr_Decompte.isContractValid(D.refdoss) = 1)
 WHERE refdoss IN
       (SELECT d.refdoss
          FROM member_contract mc, group_contracts gc, g_dossier d
         WHERE gc.refgroup = mc.refgroup
           AND gc.valid = 'O'
           AND d.reflot = mc.refdoss
           AND d.categdoss LIKE 'DECOMPTE%'
           AND mc.refgroup IN (SELECT refgroup
                                 FROM member_contract
                                WHERE refdoss = '1911200024')
        UNION
        SELECT refdoss
          FROM g_dossier
         WHERE reflot = '1911200024'
           AND categdoss LIKE 'DECOMPTE%')
   AND (NOT EXISTS
        (SELECT 1
           FROM t_gestfctcomp C, g_mangrp G
          WHERE C.refmangrp = G.refmangrp
            AND C.refperso = 29) OR
        reffactor IN (SELECT F.refindividu
                        FROM t_gestfctcomp C, g_mangrp G, t_fctmembmg F
                       WHERE C.refmangrp = G.refmangrp
                         AND G.refmangrp = F.refmangrp
                         AND C.refperso = 29))
   AND EXISTS (SELECT 1
          FROM g_piece P
         WHERE NVL(P.fg121, 'N') = 'N'
           AND NVL(P.fg30, 'N') = NVL('N', 'N')
           AND P.typpiece = 'SOUS-CONTRAT'
           AND P.refdoss = refdoss);
/********************************OLD SQL*******************************************/
/********************************OLD Metrics***************************************/
/*
Plan hash value: 503515333
----------------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                       | Name                      | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers |
----------------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                                |                           |      1 |        |    12 (100)|      2 |00:00:00.25 |   18318 |
|*  1 |  TABLE ACCESS BY INDEX ROWID                    | G_DOSSIER                 |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |
|*  2 |   INDEX UNIQUE SCAN                             | DOS_REFDOSS               |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       2 |
|*  3 |  FILTER                                         |                           |      1 |        |            |      2 |00:00:00.25 |   18318 |
|*  4 |   FILTER                                        |                           |      1 |        |            |      2 |00:00:00.25 |   18314 |
|   5 |    NESTED LOOPS SEMI                            |                           |      1 |      1 |     3   (0)|      2 |00:00:00.25 |   18308 |
|   6 |     NESTED LOOPS                                |                           |      1 |      1 |     2   (0)|      2 |00:00:00.25 |   18296 |
|   7 |      TABLE ACCESS BY INDEX ROWID BATCHED        | G_DOSSIER                 |      1 |      1 |     1   (0)|      2 |00:00:00.25 |   18291 |
|*  8 |       INDEX SKIP SCAN                           | REFHIERARCHIE_IDX         |      1 |      1 |     1   (0)|      2 |00:00:00.25 |   18285 |
|   9 |        SORT UNIQUE                              |                           |    542 |      2 |     5   (0)|      2 |00:00:00.01 |    2341 |
|  10 |         UNION-ALL                               |                           |    542 |        |            |      2 |00:00:00.01 |    2341 |
|  11 |          NESTED LOOPS                           |                           |    542 |      1 |     4   (0)|      0 |00:00:00.01 |    1794 |
|  12 |           NESTED LOOPS                          |                           |    542 |      1 |     4   (0)|      0 |00:00:00.01 |    1794 |
|  13 |            NESTED LOOPS                         |                           |    542 |      1 |     3   (0)|      0 |00:00:00.01 |    1794 |
|  14 |             NESTED LOOPS                        |                           |    542 |      1 |     2   (0)|      2 |00:00:00.01 |    1792 |
|* 15 |              TABLE ACCESS BY INDEX ROWID        | G_DOSSIER                 |    542 |      1 |     1   (0)|    542 |00:00:00.01 |    1248 |
|* 16 |               INDEX UNIQUE SCAN                 | DOS_REFDOSS               |    542 |      1 |     1   (0)|    542 |00:00:00.01 |     668 |
|  17 |              TABLE ACCESS BY INDEX ROWID BATCHED| MEMBER_CONTRACT           |    542 |      1 |     1   (0)|      2 |00:00:00.01 |     544 |
|* 18 |               INDEX RANGE SCAN                  | MC_REFDOSS_IDX            |    542 |      1 |     1   (0)|      2 |00:00:00.01 |     542 |
|* 19 |             TABLE ACCESS BY INDEX ROWID BATCHED | MEMBER_CONTRACT           |      2 |      1 |     1   (0)|      0 |00:00:00.01 |       2 |
|* 20 |              INDEX RANGE SCAN                   | MC_REFDOSS_IDX            |      2 |      1 |     1   (0)|      0 |00:00:00.01 |       2 |
|* 21 |            INDEX UNIQUE SCAN                    | PK_GROUP_CONTRACTS        |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 22 |           TABLE ACCESS BY INDEX ROWID           | GROUP_CONTRACTS           |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 23 |          INDEX RANGE SCAN                       | G_DOSSIER_RL_CD_RD_RF_IDX |    542 |      1 |     1   (0)|      2 |00:00:00.01 |     547 |
|* 24 |      INDEX RANGE SCAN                           | INT_REFDOSS               |      2 |      1 |     1   (0)|      2 |00:00:00.01 |       5 |
|* 25 |     TABLE ACCESS BY INDEX ROWID BATCHED         | G_PIECE                   |      2 |    751 |     1   (0)|      2 |00:00:00.01 |      12 |
|* 26 |      INDEX RANGE SCAN                           | PIE_REFDOSS               |      2 |      1 |     1   (0)|      2 |00:00:00.01 |       6 |
|* 27 |    TABLE ACCESS BY INDEX ROWID BATCHED          | G_PIECE                   |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       6 |
|* 28 |     INDEX RANGE SCAN                            | GP_TYPP_FG01_NB04_DOS_IDX |      1 |    757 |     1   (0)|      1 |00:00:00.01 |       3 |
|  29 |   NESTED LOOPS                                  |                           |      1 |      1 |     2   (0)|      0 |00:00:00.01 |       4 |
|  30 |    NESTED LOOPS                                 |                           |      1 |     12 |     2   (0)|      9 |00:00:00.01 |       2 |
|  31 |     INDEX FULL SCAN                             | PK_G_MANGRP               |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       1 |
|* 32 |     INDEX RANGE SCAN                            | IS_COMPETENT_FOR_FK       |      1 |     12 |     1   (0)|      9 |00:00:00.01 |       1 |
|* 33 |    TABLE ACCESS BY INDEX ROWID                  | T_GESTFCTCOMP             |      9 |      1 |     1   (0)|      0 |00:00:00.01 |       2 |
|  34 |   NESTED LOOPS                                  |                           |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|  35 |    NESTED LOOPS                                 |                           |      0 |     12 |     3   (0)|      0 |00:00:00.01 |       0 |
|  36 |     NESTED LOOPS                                |                           |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |
|  37 |      INDEX FULL SCAN                            | PK_G_MANGRP               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 38 |      INDEX UNIQUE SCAN                          | PK_T_FCTMEMBMG            |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 39 |     INDEX RANGE SCAN                            | IS_COMPETENT_FOR_FK       |      0 |     12 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 40 |    TABLE ACCESS BY INDEX ROWID                  | T_GESTFCTCOMP             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
----------------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   1 - filter("GD"."CATEGDOSS"='CONTRAT')
   2 - access("GD"."REFDOSS"=:B1)
   3 - filter(( IS NULL OR  IS NOT NULL))
   4 - filter( IS NOT NULL)
   8 - access("D"."CATEGDOSS" LIKE 'DECOMPTE%')
       filter(("D"."CATEGDOSS" LIKE 'DECOMPTE%' AND "FTR_DECOMPTE"."ISCONTRACTVALID"("D"."REFDOSS")=1 AND  IS NOT NULL))
  15 - filter(("D"."CATEGDOSS" LIKE 'DECOMPTE%' AND "D"."REFLOT" IS NOT NULL))
  16 - access("D"."REFDOSS"=:B1)
  18 - access("D"."REFLOT"="MC"."REFDOSS")
  19 - filter("MC"."REFGROUP"="REFGROUP")
  20 - access("REFDOSS"='1911200024')
  21 - access("GC"."REFGROUP"="MC"."REFGROUP")
  22 - filter("GC"."VALID"='O')
  23 - access("REFLOT"='1911200024' AND "CATEGDOSS" LIKE 'DECOMPTE%' AND "REFDOSS"=:B1)
       filter(("REFDOSS"=:B1 AND "CATEGDOSS" LIKE 'DECOMPTE%'))
  24 - access("D"."REFDOSS"="T"."REFDOSS" AND "T"."REFTYPE"=DECODE("D"."CATEGDOSS",'DECOMPTE IMP','TC','CL'))
  25 - filter((NVL("P"."FG30",'N')='N' AND NVL("P"."FG121",'N')='N'))
  26 - access("P"."REFDOSS"="D"."REFDOSS" AND "P"."TYPPIECE"='SOUS-CONTRAT')
  27 - filter((NVL("P"."FG30",'N')='N' AND NVL("P"."FG121",'N')='N'))
  28 - access("P"."TYPPIECE"='SOUS-CONTRAT')
       filter("P"."REFDOSS" IS NOT NULL)
  32 - access("C"."REFMANGRP"="G"."REFMANGRP")
  33 - filter(TO_NUMBER("C"."REFPERSO")=29)
  38 - access("F"."REFINDIVIDU"=:B1 AND "G"."REFMANGRP"="F"."REFMANGRP")
  39 - access("C"."REFMANGRP"="G"."REFMANGRP")
  40 - filter(TO_NUMBER("C"."REFPERSO")=29)

*/
/********************************OLD Metrics***************************************/

/********************************New SQL*******************************************/
SELECT ANCREFDOSS, DEVISE, REFDOSS, REFINDIVIDU, REFLOT, REFFACTOR
  FROM (SELECT (SELECT gd.ancrefdoss
                  FROM g_dossier GD
                 WHERE gd.refdoss = D.reflot
                   AND gd.categdoss = 'CONTRAT') ancrefdoss,
               D.refdoss refdoss,
               D.reflot reflot,
               D.devise devise,
               T.refindividu refindividu,
               D.reffactor,
               ( SELECT Ftr_Decompte.isContractValid(D.refdoss) FROM dual) isContractValid
          FROM g_dossier D, 
               t_intervenants T
         WHERE D.categdoss LIKE 'DECOMPTE%'
           AND D.refdoss = T.refdoss
           AND T.reftype = DECODE(D.categdoss, 'DECOMPTE IMP', 'TC', 'CL')
           AND EXISTS
         (SELECT 1
                  FROM g_piece P
                 WHERE NVL(P.fg121, 'N') = 'N'
                   AND NVL(P.fg30, 'N') = NVL('N', 'N')
                   AND P.typpiece = 'SOUS-CONTRAT'
                   AND P.refdoss = D.refdoss))
 WHERE isContractValid = 1 
   AND refdoss IN
       (SELECT d.refdoss
          FROM member_contract mc, group_contracts gc, g_dossier d
         WHERE gc.refgroup = mc.refgroup
           AND gc.valid = 'O'
           AND d.reflot = mc.refdoss
           AND d.categdoss LIKE 'DECOMPTE%'
           AND mc.refgroup IN (SELECT refgroup
                                 FROM member_contract
                                WHERE refdoss = '1911200024')
        UNION
        SELECT refdoss
          FROM g_dossier
         WHERE reflot = '1911200024'
           AND categdoss LIKE 'DECOMPTE%')
   AND (NOT EXISTS
        (SELECT 1
           FROM t_gestfctcomp C, 
                g_mangrp G
          WHERE C.refmangrp = G.refmangrp
            AND C.refperso = '29') OR
        reffactor IN (SELECT F.refindividu
                        FROM t_gestfctcomp C, g_mangrp G, t_fctmembmg F
                       WHERE C.refmangrp = G.refmangrp
                         AND G.refmangrp = F.refmangrp
                         AND C.refperso = '29'))
   AND EXISTS (SELECT 1
          FROM g_piece P
         WHERE NVL(P.fg121, 'N') = 'N'
           AND NVL(P.fg30, 'N') = NVL('N', 'N')
           AND P.typpiece = 'SOUS-CONTRAT'
           AND P.refdoss = refdoss);
/********************************New SQL*******************************************/
/********************************New Metrics***************************************/
/*
Plan hash value: 3269414039
-------------------------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                       | Name                      | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  |
-------------------------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                                |                           |      1 |        |    15 (100)|      2 |00:00:00.14 |    2500 |     48 |
|*  1 |  TABLE ACCESS BY INDEX ROWID                    | G_DOSSIER                 |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |      0 |
|*  2 |   INDEX UNIQUE SCAN                             | DOS_REFDOSS               |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       2 |      0 |
|*  3 |  FILTER                                         |                           |      1 |        |            |      2 |00:00:00.14 |    2500 |     48 |
|*  4 |   FILTER                                        |                           |      1 |        |            |      2 |00:00:00.14 |    2498 |     48 |
|   5 |    NESTED LOOPS SEMI                            |                           |      1 |      1 |     9  (12)|      2 |00:00:00.14 |    2492 |     48 |
|   6 |     NESTED LOOPS                                |                           |      1 |      1 |     8  (13)|      2 |00:00:00.14 |    2480 |     48 |
|   7 |      NESTED LOOPS                               |                           |      1 |      1 |     7  (15)|      2 |00:00:00.14 |    2475 |     48 |
|   8 |       VIEW                                      | VW_NSO_1                  |      1 |      2 |     6  (17)|      2 |00:00:00.01 |       3 |      0 |
|   9 |        SORT UNIQUE                              |                           |      1 |      2 |     6  (17)|      2 |00:00:00.01 |       3 |      0 |
|  10 |         UNION-ALL                               |                           |      1 |        |            |      2 |00:00:00.01 |       3 |      0 |
|  11 |          NESTED LOOPS                           |                           |      1 |      1 |     4   (0)|      0 |00:00:00.01 |       1 |      0 |
|  12 |           NESTED LOOPS                          |                           |      1 |      1 |     4   (0)|      0 |00:00:00.01 |       1 |      0 |
|  13 |            NESTED LOOPS                         |                           |      1 |      1 |     3   (0)|      0 |00:00:00.01 |       1 |      0 |
|  14 |             NESTED LOOPS                        |                           |      1 |      1 |     2   (0)|      0 |00:00:00.01 |       1 |      0 |
|  15 |              TABLE ACCESS BY INDEX ROWID BATCHED| MEMBER_CONTRACT           |      1 |      1 |     1   (0)|      0 |00:00:00.01 |       1 |      0 |
|* 16 |               INDEX RANGE SCAN                  | MC_REFDOSS_IDX            |      1 |      1 |     1   (0)|      0 |00:00:00.01 |       1 |      0 |
|  17 |              TABLE ACCESS BY INDEX ROWID BATCHED| MEMBER_CONTRACT           |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 18 |               INDEX RANGE SCAN                  | MC_REFGROUP_IDX           |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 19 |             INDEX RANGE SCAN                    | G_DOSSIER_RL_CD_RD_RF_IDX |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 20 |            INDEX UNIQUE SCAN                    | PK_GROUP_CONTRACTS        |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 21 |           TABLE ACCESS BY INDEX ROWID           | GROUP_CONTRACTS           |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 22 |          INDEX RANGE SCAN                       | G_DOSSIER_RL_CD_RD_RF_IDX |      1 |      1 |     1   (0)|      2 |00:00:00.01 |       2 |      0 |
|* 23 |       TABLE ACCESS BY INDEX ROWID               | G_DOSSIER                 |      2 |      1 |     1   (0)|      2 |00:00:00.14 |    2472 |     48 |
|* 24 |        INDEX UNIQUE SCAN                        | DOS_REFDOSS               |      2 |      1 |     1   (0)|      2 |00:00:00.14 |    2466 |     48 |
|  25 |         FAST DUAL                               |                           |      2 |      1 |     2   (0)|      2 |00:00:00.01 |       0 |      0 |
|* 26 |      INDEX RANGE SCAN                           | INT_REFDOSS               |      2 |      1 |     1   (0)|      2 |00:00:00.01 |       5 |      0 |
|* 27 |     TABLE ACCESS BY INDEX ROWID BATCHED         | G_PIECE                   |      2 |    518 |     1   (0)|      2 |00:00:00.01 |      12 |      0 |
|* 28 |      INDEX RANGE SCAN                           | PIE_REFDOSS               |      2 |      1 |     1   (0)|      2 |00:00:00.01 |       6 |      0 |
|* 29 |    TABLE ACCESS BY INDEX ROWID BATCHED          | G_PIECE                   |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       6 |      0 |
|* 30 |     INDEX RANGE SCAN                            | GP_TYPP_FG01_NB04_DOS_IDX |      1 |    757 |     1   (0)|      1 |00:00:00.01 |       3 |      0 |
|  31 |   NESTED LOOPS                                  |                           |      1 |      1 |     2   (0)|      0 |00:00:00.01 |       2 |      0 |
|  32 |    INDEX FULL SCAN                              | PK_G_MANGRP               |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       1 |      0 |
|* 33 |    INDEX UNIQUE SCAN                            | PK_T_GESTFCTCOMP          |      1 |      1 |     1   (0)|      0 |00:00:00.01 |       1 |      0 |
|  34 |   NESTED LOOPS                                  |                           |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|  35 |    NESTED LOOPS                                 |                           |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|  36 |     INDEX FULL SCAN                             | PK_G_MANGRP               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 37 |     INDEX UNIQUE SCAN                           | PK_T_FCTMEMBMG            |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 38 |    INDEX UNIQUE SCAN                            | PK_T_GESTFCTCOMP          |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
-------------------------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   1 - filter("GD"."CATEGDOSS"='CONTRAT')
   2 - access("GD"."REFDOSS"=:B1)
   3 - filter(( IS NULL OR  IS NOT NULL))
   4 - filter( IS NOT NULL)
  16 - access("REFDOSS"='1911200024')
  18 - access("MC"."REFGROUP"="REFGROUP")
  19 - access("D"."REFLOT"="MC"."REFDOSS" AND "D"."CATEGDOSS" LIKE 'DECOMPTE%')
       filter(("D"."CATEGDOSS" LIKE 'DECOMPTE%' AND "D"."REFLOT" IS NOT NULL))
  20 - access("GC"."REFGROUP"="MC"."REFGROUP")
  21 - filter("GC"."VALID"='O')
  22 - access("REFLOT"='1911200024' AND "CATEGDOSS" LIKE 'DECOMPTE%')
       filter("CATEGDOSS" LIKE 'DECOMPTE%')
  23 - filter("D"."CATEGDOSS" LIKE 'DECOMPTE%')
  24 - access("D"."REFDOSS"="REFDOSS")
       filter(=1)
  26 - access("D"."REFDOSS"="T"."REFDOSS" AND "T"."REFTYPE"=DECODE("D"."CATEGDOSS",'DECOMPTE IMP','TC','CL'))
  27 - filter((NVL("P"."FG30",'N')='N' AND NVL("P"."FG121",'N')='N'))
  28 - access("P"."REFDOSS"="D"."REFDOSS" AND "P"."TYPPIECE"='SOUS-CONTRAT')
  29 - filter((NVL("P"."FG30",'N')='N' AND NVL("P"."FG121",'N')='N'))
  30 - access("P"."TYPPIECE"='SOUS-CONTRAT')
       filter("P"."REFDOSS" IS NOT NULL)
  33 - access("C"."REFPERSO"='29' AND "C"."REFMANGRP"="G"."REFMANGRP")
  37 - access("F"."REFINDIVIDU"=:B1 AND "G"."REFMANGRP"="F"."REFMANGRP")
  38 - access("C"."REFPERSO"='29' AND "C"."REFMANGRP"="G"."REFMANGRP")
*/
/********************************New Metrics***************************************/

/********************************Index statistics**********************************/

/********************************Other SQLs****************************************/          
/*

*/ 
/********************************Other SQLs****************************************/              
