/********************************************************************************
*********       E-mail subject: LOCAMDEV-25497
*********             Instance: BIRDVAL
*********          Description: 
Problem:
Three service calls was provided as slow form V9 BE logs from BIRDVAL.

Analysis:
I executed the provided queries on BIRDVAL ( we have the same query in the second and the third service calls ). The problem in these queries is that we are searching 
only for the active elements, but instead using table t_element_se, which contains only the active elements, the queries are using table t_elements, which 
leads to INDEX SKIP SCAN and slow execution. The solution here is to use table t_element_se instead of table t_elements.

Suggestion:
Please rewrite the queries to use table t_element_se instead of table t_elements as it is shown in the New SQL section below.

*********               SQL_ID: 3p5w55v4mh2u7, 7h0shr9ry8x5c
*********      Program/Package: 
*********              Request: Corentin Dupriez 
*********               Author: Dimitar Dimitrov
********* Received e-mail date: 25/07/2024
*********      Resolution date: 25/07/2024
*********  Trace old file here: \\epox\specifs\performance\tmp\
*********  Trace new file here:
***********************************************************************************/

/********************************OLD SQL*******************************************/

-- 3p5w55v4mh2u7

SELECT COUNT(*)
  FROM t_elements
 WHERE typeelem = 'se'
   AND actif = 'o'
   AND libelle like '%exam PEP avenant MODAG'
   AND refperso IN (SELECT refperso
                      FROM g_personnel
                     WHERE CATEGPERSO = 'SERVICE PEP'
                       AND groupe = 'SERVICE PEP');

-- 7h0shr9ry8x5c

VAR B1 NUMBER;
EXEC :B1 := 366;

SELECT COUNT(*)
  FROM t_elements
 WHERE typeelem = 'se'
   AND refperso = :B1
   AND actif = 'o'
   AND libelle like '%exam PEP avenant MODAG';
/********************************OLD SQL*******************************************/
/********************************OLD Metrics***************************************/
/*

-- 3p5w55v4mh2u7

Plan hash value: 2017700729
------------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                             | Name                   | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  |
------------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                      |                        |      1 |        |   846 (100)|      1 |00:00:31.26 |   62551 |  62548 |
|   1 |  SORT AGGREGATE                       |                        |      1 |      1 |            |      1 |00:00:31.26 |   62551 |  62548 |
|   2 |   NESTED LOOPS                        |                        |      1 |      1 |   846   (0)|      1 |00:00:31.26 |   62551 |  62548 |
|*  3 |    TABLE ACCESS BY INDEX ROWID BATCHED| G_PERSONNEL            |      1 |      1 |     1   (0)|      1 |00:00:00.01 |      10 |     10 |
|*  4 |     INDEX RANGE SCAN                  | G_PERS_GROUPE_IDX      |      1 |      4 |     1   (0)|     10 |00:00:00.01 |       1 |      1 |
|*  5 |    TABLE ACCESS BY INDEX ROWID BATCHED| T_ELEMENTS             |      1 |      1 |   845   (0)|      1 |00:00:31.25 |   62541 |  62538 |
|*  6 |     INDEX SKIP SCAN                   | ELE_DOSS_TYP_ASSOC_LIB |      1 |  13272 |   772   (0)|     49 |00:00:31.25 |   62517 |  62516 |
------------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   3 - filter("CATEGPERSO"='SERVICE PEP')
   4 - access("GROUPE"='SERVICE PEP')
   5 - filter(("REFPERSO"="REFPERSO" AND "REFPERSO" IS NOT NULL AND "ACTIF"='o'))
   6 - access("TYPEELEM"='se')
       filter(("TYPEELEM"='se' AND "LIBELLE" LIKE '%exam PEP avenant MODAG' AND "LIBELLE" IS NOT NULL))


-- 7h0shr9ry8x5c

Plan hash value: 4010067596
-----------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                            | Name                   | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  |
-----------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                     |                        |      1 |        |   845 (100)|      1 |00:00:21.01 |   62541 |  62538 |
|   1 |  SORT AGGREGATE                      |                        |      1 |      1 |            |      1 |00:00:21.01 |   62541 |  62538 |
|*  2 |   TABLE ACCESS BY INDEX ROWID BATCHED| T_ELEMENTS             |      1 |      1 |   845   (0)|      0 |00:00:21.01 |   62541 |  62538 |
|*  3 |    INDEX SKIP SCAN                   | ELE_DOSS_TYP_ASSOC_LIB |      1 |  13272 |   772   (0)|     49 |00:00:21.01 |   62517 |  62516 |
-----------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   2 - filter(("REFPERSO"=:B1 AND "ACTIF"='o'))
   3 - access("TYPEELEM"='se')
       filter(("TYPEELEM"='se' AND "LIBELLE" LIKE '%exam PEP avenant MODAG' AND "LIBELLE" IS NOT NULL))

*/
/********************************OLD Metrics***************************************/

/********************************New SQL*******************************************/

-- 3p5w55v4mh2u7

SELECT COUNT(*)
  FROM t_element_se
 WHERE libelle like '%exam PEP avenant MODAG'
   AND refperso IN (SELECT refperso
                      FROM g_personnel
                     WHERE CATEGPERSO = 'SERVICE PEP'
                       AND groupe = 'SERVICE PEP');


-- 7h0shr9ry8x5c

VAR B1 NUMBER;
EXEC :B1 := 366;

SELECT COUNT(*)
  FROM t_element_se
 WHERE refperso = :B1
   AND libelle like '%exam PEP avenant MODAG';

/********************************New SQL*******************************************/
/********************************New Metrics***************************************/
/*
-- 3p5w55v4mh2u7

Plan hash value: 3831435992
-----------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                             | Name               | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers |
-----------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                      |                    |      1 |        |     2 (100)|      1 |00:00:00.01 |      18 |
|   1 |  SORT AGGREGATE                       |                    |      1 |      1 |            |      1 |00:00:00.01 |      18 |
|   2 |   NESTED LOOPS                        |                    |      1 |      2 |     2   (0)|      1 |00:00:00.01 |      18 |
|*  3 |    TABLE ACCESS BY INDEX ROWID BATCHED| G_PERSONNEL        |      1 |      1 |     1   (0)|      1 |00:00:00.01 |      10 |
|*  4 |     INDEX RANGE SCAN                  | G_PERS_GROUPE_IDX  |      1 |      4 |     1   (0)|     10 |00:00:00.01 |       1 |
|*  5 |    INDEX RANGE SCAN                   | ELESE_REFPERSO_IDX |      1 |     45 |     1   (0)|      1 |00:00:00.01 |       8 |
-----------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   3 - filter("CATEGPERSO"='SERVICE PEP')
   4 - access("GROUPE"='SERVICE PEP')
   5 - access("REFPERSO"="REFPERSO")
       filter(("LIBELLE" LIKE '%exam PEP avenant MODAG' AND "LIBELLE" IS NOT NULL))


-- 7h0shr9ry8x5c

Plan hash value: 3235018671
------------------------------------------------------------------------------------------------------------------------
| Id  | Operation         | Name               | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  |
------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT  |                    |      1 |        |     1 (100)|      1 |00:00:00.01 |       3 |      2 |
|   1 |  SORT AGGREGATE   |                    |      1 |      1 |            |      1 |00:00:00.01 |       3 |      2 |
|*  2 |   INDEX RANGE SCAN| ELESE_REFPERSO_IDX |      1 |     45 |     1   (0)|      0 |00:00:00.01 |       3 |      2 |
------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   2 - access("REFPERSO"=:B1)
       filter(("LIBELLE" LIKE '%exam PEP avenant MODAG' AND "LIBELLE" IS NOT NULL))
*/
/********************************New Metrics***************************************/

/********************************Index statistics**********************************/

/********************************Other SQLs****************************************/          
/*

*/ 
/********************************Other SQLs****************************************/              
