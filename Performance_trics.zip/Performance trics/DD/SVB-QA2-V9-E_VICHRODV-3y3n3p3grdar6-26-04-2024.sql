/********************************************************************************
*********       E-mail subject: SVBDEV-7593
*********             Instance: QA2 V9
*********          Description: 
Problem:

Analysis:
In SVBDEV-7593 we analyzed SQL 3y3n3p3grdar6. The problem in this SQL is that function ui_e_vichrodv.translateTitle is called 
for every of the found elements in table t_elements for a specific refodoss. We can't do much to improve the performance of the query. 
As Vasil Todorov wrote in SVBDEV-7593, his attempts to make some changes with C&D were declined as the migration requirement seems insurmountable.
Also as Vasil wrote, this case where we are using this query is very rare, so we will leave it as it is.

Suggestion:

*********               SQL_ID: 3y3n3p3grdar6
*********      Program/Package: E_VICHRODV 
*********              Request: Dimitare Ivanov
*********               Author: Dimitar Dimitrov
********* Received e-mail date: 26/04/2024
*********      Resolution date: 26/04/2024
*********  Trace old file here: \\epox\specifs\performance\tmp\
*********  Trace new file here:
***********************************************************************************/

/********************************OLD SQL*******************************************/

VAR B1 VARCHAR2(32);
EXEC :B1 := '';
VAR B4 VARCHAR2(32);
EXEC :B4 := 'AN';
VAR B6 VARCHAR2(32);
EXEC :B6 := 'assignment%';
VAR B7 NUMBER;
EXEC :B7 := 2001;
VAR B8 NUMBER;
EXEC :B8 := 1;

SELECT /*+ OPT_PARAM('_optimizer_use_feedback' 'false') */
 CASE
   WHEN EXISTS (SELECT 1
           FROM v_domaine
          WHERE TYPE = 'ELEM_CHRONO'
            AND type_delai = 'O'
            AND abrev = eventType) THEN
    readStatus
   ELSE
    'O'
 END readStatus,
 currencyCase currencyCase,
 rejected rejected,
 financial financial,
 processingDate processingDate,
 origin origin,
 refExt refExt,
 eventRef eventRef,
 title title,
 (SELECT ui_e_vichrodv.getAttachement(pi_typelem => eventType,
                                      pi_refelem => eventRef)
    FROM dual) withAttachment,
 (SELECT ui_e_vichrodv.translateTitle(pi_elem_title    => title,
                                      pi_typeelem      => eventType,
                                      pi_refelem       => eventRef,
                                      pi_rejet         => rejected,
                                      pi_refext        => refExt,
                                      pi_bu_out_of_imx => :B1,
                                      pi_lang          => :B1)
    FROM dual) displayTitle,
 finEvent finEvent,
 refExt refIndividual,
 refDuplicate refDuplicate,
 NULL litigeReference,
 partyName partyName,
 sendMode sendMode,
 (SELECT ui_e_vichrodv.get_display_chrono(eventType, :B1) FROM dual) displayEventType,
 CASE
   WHEN eventType = 'in' THEN
    (SELECT extranet_invis FROM g_information WHERE refinfo = eventRef)
   WHEN eventType = 'me' THEN
    (SELECT not_visible FROM t_entmail WHERE refmail = eventRef)
 END invisibleExtranet,
 amountCase amountCase,
 eventType eventType,
 duplicate duplicate,
 (SELECT ui_e_vichrodv.getDeviseCom(pi_refdoss       => caseRef,
                                    pi_case_currency => devise_dos,
                                    pi_typelem       => eventType,
                                    pi_refelem       => eventRef,
                                    pi_libelle_el    => title,
                                    pi_montant_dos   => montant_dos,
                                    pi_montant6      => montant6,
                                    pi_refext        => refext,
                                    pi_dtassoc_dt    => processingDate)
    FROM dual) currencyMvt,
 elemId elemId,
 validatedBy validatedBy,
 (SELECT valeur_trad
    FROM g_information g, v_tdomaine v
   WHERE v.type = 'INFO_RES'
     AND v.valeur = g.info_res
     AND g.refinfo = eventRef
     AND v.langue = :B4) callResult,
 entranceDate entranceDate,
 (SELECT CASE
           WHEN eventType IN ('mr', 'me') THEN
            (SELECT fg_importance_highlight
               FROM t_entmail
              WHERE refmail = eventRef)
           WHEN eventType IN ('ms', 'in') THEN
            (SELECT fg_importance_highlight
               FROM g_information
              WHERE refinfo = eventRef)
         END impHighlight
    FROM dual) impHighlight,
 (SELECT ui_e_vichrodv.getmontantcom(pi_refdoss       => caseRef,
                                     pi_case_currency => devise_dos,
                                     pi_typelem       => eventType,
                                     pi_refelem       => eventRef,
                                     pi_libelle_el    => title,
                                     pi_montant_dos   => montant_dos,
                                     pi_montant6      => montant6,
                                     pi_refext        => refext,
                                     pi_dtassoc_dt    => processingDate)
    FROM dual) amountMvt,
 status status,
 rnum
  FROM (SELECT /*+ first_rows(2001)*/
         foo.*, ROWNUM rnum
          FROM (SELECT readStatus readStatus,
                       devise currencyCase,
                       rejet rejected,
                       refelemfi financial,
                       dtassoc_dt processingDate,
                       ancrefdoss origin,
                       ancrefdoss refExt,
                       refelem eventRef,
                       libelle_el title,
                       image withAttachment,
                       refdoss caseRef,
                       refelemfi finEvent,
                       ref_Double refDuplicate,
                       ref_Double litigeReference,
                       nom partyName,
                       attribut sendMode,
                       montant_dos montant_dos,
                       montant_dos amountCase,
                       ref_Double ref_Double,
                       typeelem eventType,
                       DECODE(ref_Double, NULL, 'N', 'O') duplicate,
                       devise_dos devise_dos,
                       montant6 montant6,
                       imx_un_id elemId,
                       valide_par validatedBy,
                       refext refIndivdiual,
                       dtsaisie_dt entranceDate,
                       rejet status
                  FROM (SELECT *
                          FROM (SELECT *
                                  FROM (select IMX_UN_ID,
                                               createur,
                                               ROWID          TELEM_ROWID,
                                               attribut,
                                               dtassoc,
                                               dtsaisie,
                                               dtassoc_dt,
                                               dtsaisie_dt,
                                               dtannul_dt,
                                               typeelem,
                                               rejet,
                                               libelle        libelle_el,
                                               nom,
                                               actif_dos,
                                               null           invisible_extranet,
                                               null           image,
                                               null           re_reftexte,
                                               null           message,
                                               null           x_ref_double,
                                               null           montant_com,
                                               null           DEVISE_COM,
                                               null           LIBELLE_TRAD,
                                               null           TYPEELEM_TRAD,
                                               null           screen,
                                               montant_dos,
                                               refdoss,
                                               ancrefdoss,
                                               valide_par,
                                               lib_lettrage,
                                               refelem,
                                               devise,
                                               devise_dos,
                                               devise         devise_elem,
                                               reprise,
                                               abrev,
                                               montant,
                                               montant1,
                                               montant6,
                                               refelemfi,
                                               ref_Double,
                                               refext,
                                               refelem        refelem_order,
                                               fg_read_status readStatus
                                          FROM t_elements t
                                         where t.refdoss = '1605050003'
                                           AND NVL(t.fg_hidden_chrono, 'N') <> 'O'
                                           AND (t.ancrefdoss IS NULL OR
                                               t.ancrefdoss LIKE '%')
                                           AND t.typeelem NOT IN
                                               ('yy',
                                                'ng',
                                                'xx',
                                                'ce',
                                                'zz',
                                                'yy',
                                                'se',
                                                'an',
                                                'ac')
                                           AND t.typeelem <> 'rg'
                                           AND UPPER(ui_e_vichrodv.translateTitle(pi_elem_title    => t.libelle,
                                                                                  pi_typeelem      => t.typeelem,
                                                                                  pi_refelem       => t.refelem,
                                                                                  pi_rejet         => t.rejet,
                                                                                  pi_refext        => t.refext,
                                                                                  pi_bu_out_of_imx => 'N',
                                                                                  pi_lang          => :B4)) like UPPER(:B6))
                                 WHERE 1 = 1
                                   AND NOT (typeelem = 'in' AND
                                        UPPER(NVL(createur, '#')) =
                                        'TELEPHONIE')) dq)
                 WHERE 1 = 1
                 ORDER BY entranceDate DESC, eventRef DESC, elemId DESC) foo
         WHERE ROWNUM <= :B7) fooo
 WHERE 1 = 1
   AND rnum >= :B8;

/********************************OLD SQL*******************************************/
/********************************OLD Metrics***************************************/
/*
INSTANCE_NUMBER SQL_ID            ELAPSED MAX_WAIT_ON     PC_OF  WAIT_TIME            GETS      READS       ROWS  ELAP/EXEC       GETS/EXEC READS/EXEC  ROWS/EXEC       EXEC PLAN_HASH_VALUE
--------------- ------------- ----------- --------------- ----- ---------- --------------- ---------- ---------- ---------- --------------- ---------- ---------- ---------- ---------------
              1 3y3n3p3grdar6         195 CPU             52%   351.447349         2787224       2050       7846      48.74          696806      512.5     1961.5          4      3011173601
              
              
SQL_ID        SQL_PLAN_HASH_VALUE SQL_PLAN_LINE_ID SQL_PLAN_OPERATION             SQL_PLAN_OPTIONS                   ACTIVE
------------- ------------------- ---------------- ------------------------------ ------------------------------ ----------
3y3n3p3grdar6          3011173601                  SELECT STATEMENT                                                      17
3y3n3p3grdar6          3011173601               51 VIEW                                                                   1


Plan hash value: 3011173601
--------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                               | Name             | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  |
--------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                        |                  |      1 |        |   350 (100)|   1930 |00:00:49.37 |     339K|   2385 |
|*  1 |  TABLE ACCESS BY INDEX ROWID BATCHED    | V_DOMAINE        |      1 |      1 |     2   (0)|      0 |00:00:00.01 |       5 |      0 |
|*  2 |   INDEX RANGE SCAN                      | DOM_TYPABREV     |      1 |      1 |     2   (0)|      1 |00:00:00.01 |       3 |      0 |
|   3 |  FAST DUAL                              |                  |   1930 |      1 |     2   (0)|   1930 |00:00:00.01 |       0 |      0 |
|   4 |  FAST DUAL                              |                  |   1930 |      1 |     2   (0)|   1930 |00:00:00.01 |       0 |      0 |
|   5 |  FAST DUAL                              |                  |      1 |      1 |     2   (0)|      1 |00:00:00.01 |       0 |      0 |
|   6 |  TABLE ACCESS BY INDEX ROWID BATCHED    | G_INFORMATION    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*  7 |   INDEX RANGE SCAN                      | PK_G_INFORMATION |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|   8 |   TABLE ACCESS BY INDEX ROWID           | T_ENTMAIL        |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*  9 |    INDEX UNIQUE SCAN                    | PK_MAIL          |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|  10 |  FAST DUAL                              |                  |   1930 |      1 |     2   (0)|   1930 |00:00:00.01 |       0 |      0 |
|  11 |  NESTED LOOPS                           |                  |   1930 |      1 |    15   (0)|      0 |00:00:00.01 |     136 |      0 |
|  12 |   TABLE ACCESS BY INDEX ROWID BATCHED   | G_INFORMATION    |   1930 |      1 |     1   (0)|      0 |00:00:00.01 |     136 |      0 |
|* 13 |    INDEX RANGE SCAN                     | PK_G_INFORMATION |   1930 |      1 |     1   (0)|      0 |00:00:00.01 |     136 |      0 |
|  14 |   VIEW                                  | V_TDOMAINE       |      0 |      1 |    14   (0)|      0 |00:00:00.01 |       0 |      0 |
|  15 |    UNION ALL PUSHED PREDICATE           |                  |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|* 16 |     FILTER                              |                  |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  17 |      TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE        |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 18 |       INDEX RANGE SCAN                  | DOM_TYPVAL       |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 19 |     FILTER                              |                  |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  20 |      TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE        |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 21 |       INDEX RANGE SCAN                  | DOM_TYPVAL       |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 22 |     FILTER                              |                  |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  23 |      TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE        |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 24 |       INDEX RANGE SCAN                  | DOM_TYPVAL       |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 25 |     FILTER                              |                  |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  26 |      TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE        |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 27 |       INDEX RANGE SCAN                  | DOM_TYPVAL       |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 28 |     FILTER                              |                  |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  29 |      TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE        |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 30 |       INDEX RANGE SCAN                  | DOM_TYPVAL       |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 31 |     FILTER                              |                  |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  32 |      TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE        |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 33 |       INDEX RANGE SCAN                  | DOM_TYPVAL       |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 34 |     FILTER                              |                  |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  35 |      TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE        |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 36 |       INDEX RANGE SCAN                  | DOM_TYPVAL       |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 37 |     FILTER                              |                  |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  38 |      TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE        |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 39 |       INDEX RANGE SCAN                  | DOM_TYPVAL       |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 40 |     FILTER                              |                  |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  41 |      TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE        |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 42 |       INDEX RANGE SCAN                  | DOM_TYPVAL       |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|  43 |  TABLE ACCESS BY INDEX ROWID            | T_ENTMAIL        |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 44 |   INDEX UNIQUE SCAN                     | PK_MAIL          |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|  45 |   TABLE ACCESS BY INDEX ROWID BATCHED   | G_INFORMATION    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 46 |    INDEX RANGE SCAN                     | PK_G_INFORMATION |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|  47 |  FAST DUAL                              |                  |   1930 |      1 |     2   (0)|   1930 |00:00:00.01 |       0 |      0 |
|  48 |  FAST DUAL                              |                  |   1930 |      1 |     2   (0)|   1930 |00:00:00.01 |       0 |      0 |
|* 49 |  VIEW                                   |                  |      1 |     21 |     9  (12)|   1930 |00:00:49.37 |     339K|   2385 |
|* 50 |   COUNT STOPKEY                         |                  |      1 |        |            |   1930 |00:00:49.36 |     339K|   2385 |
|* 51 |    VIEW                                 |                  |      1 |     21 |     9  (12)|   1930 |00:00:49.36 |     339K|   2385 |
|  52 |     SORT ORDER BY                       |                  |      1 |     21 |     9  (12)|  25141 |00:00:00.10 |   22340 |      0 |
|* 53 |      TABLE ACCESS BY INDEX ROWID BATCHED| T_ELEMENTS       |      1 |     21 |     8   (0)|  25141 |00:00:00.05 |   22340 |      0 |
|* 54 |       INDEX RANGE SCAN                  | ELE_ELEMDOSS     |      1 |     22 |     2   (0)|  25141 |00:00:00.01 |     129 |      0 |
--------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   1 - filter("TYPE_DELAI"='O')
   2 - access("TYPE"='ELEM_CHRONO' AND "ABREV"=:B1)
   7 - access("REFINFO"=:B1)
   9 - access("REFMAIL"=:B1)
  13 - access("G"."REFINFO"=:B1)
  16 - filter('AL'=:B4)
  18 - access("VALEUR"="G"."INFO_RES" AND "TYPE"='INFO_RES')
  19 - filter('AN'=:B4)
  21 - access("VALEUR"="G"."INFO_RES" AND "TYPE"='INFO_RES')
  22 - filter('CH'=:B4)
  24 - access("VALEUR"="G"."INFO_RES" AND "TYPE"='INFO_RES')
  25 - filter('ES'=:B4)
  27 - access("VALEUR"="G"."INFO_RES" AND "TYPE"='INFO_RES')
  28 - filter('FR'=:B4)
  30 - access("VALEUR"="G"."INFO_RES" AND "TYPE"='INFO_RES')
  31 - filter('IT'=:B4)
  33 - access("VALEUR"="G"."INFO_RES" AND "TYPE"='INFO_RES')
  34 - filter('NL'=:B4)
  36 - access("VALEUR"="G"."INFO_RES" AND "TYPE"='INFO_RES')
  37 - filter('RU'=:B4)
  39 - access("VALEUR"="G"."INFO_RES" AND "TYPE"='INFO_RES')
  40 - filter('US'=:B4)
  42 - access("VALEUR"="G"."INFO_RES" AND "TYPE"='INFO_RES')
  44 - access("REFMAIL"=:B1)
  46 - access("REFINFO"=:B1)
  49 - filter("RNUM">=:B8)
  50 - filter(ROWNUM<=:B7)
  51 - filter(UPPER("UI_E_VICHRODV"."TRANSLATETITLE"("TITLE","EVENTTYPE","EVENTREF","REJECTED","REFINDIVDIUAL",'N',:B4)) LIKE
              UPPER(:B6))
  53 - filter((("TYPEELEM"<>'in' OR UPPER(NVL("CREATEUR",'#'))<>'TELEPHONIE') AND ("T"."ANCREFDOSS" IS NULL OR ("T"."ANCREFDOSS" IS
              NOT NULL AND "T"."ANCREFDOSS" IS NOT NULL AND "T"."ANCREFDOSS" LIKE '%')) AND NVL("T"."FG_HIDDEN_CHRONO",'N')<>'O'))
  54 - access("T"."REFDOSS"='1605050003')
       filter(("T"."TYPEELEM"<>'yy' AND "T"."TYPEELEM"<>'ng' AND "T"."TYPEELEM"<>'xx' AND "T"."TYPEELEM"<>'ce' AND
              "T"."TYPEELEM"<>'zz' AND "T"."TYPEELEM"<>'se' AND "T"."TYPEELEM"<>'an' AND "T"."TYPEELEM"<>'rg' AND "T"."TYPEELEM"<>'ac'))


     RUNID TYPE                 NAME                                 LINE TOTAL_OCCUR TOTAL_TIME   MIN_TIME   MAX_TIME TEXT
---------- -------------------- ------------------------------ ---------- ----------- ---------- ---------- ---------- ------------------------------------------------------------
        10 PACKAGE BODY         IMX                                   435       50150 2.45059097 .000000872 .000289901                    FOR ITEM IN ( SELECT valeur, valeur_trad
        10 PACKAGE BODY         IMX                                  1066       29210 2.42614241 .000000031 .000357695                        SELECT valeur_trad, valeur
        10 PACKAGE BODY         IMX                                     7       26997  1.7574015  .00005123 .000774276            SELECT valeur_trad
        10 PACKAGE BODY         IMX                                   639       27071 .893299129 .000026421 .000518628                SELECT getdcli
        10 PACKAGE BODY         UI_E_VICHRODV                        2160        1930 .260389527 .000120183 .000274275             SELECT 'O'
        10 PACKAGE BODY         UI_E_VICHRODV                        2150        1930 .236473582 .000085732 .000225313         SELECT 'O'
        10 PACKAGE BODY         UI_E_VICHRODV                        1734        3860   .1809401 .000037605 .000097567          SELECT mt01, gpidevis
        10 PACKAGE BODY         UI_E_VICHRODV                        1587        3740 .135361872 .000027864    .000098            SELECT NVL(gpirole, gpidepot) INTO l_numero FROM
        10 PACKAGE BODY         IMX                                   635       27071 .089180956 .000000035  .00002353         PROCEDURE chrono(tp IN VARCHAR2) IS
        10 PACKAGE BODY         UI_E_VICHRODV                        1477       27071 .075142353 .000002168 .000032285    FUNCTION translateTitle(
        10 PACKAGE BODY         IMX                                  1015       27071 .053914222 .000000057 .000014072             IF typelem IN ('se','pe','at','er','pr','in','rf
        10 PACKAGE BODY         IMX                                   706         502 .048946047 .000001071 .000316272                      FOR trec IN ( SELECT  NVL(pf_lib_trad,
        10 PACKAGE BODY         IMX                                   443       22717 .047747133  .00000146 .000022712                        translated := REPLACE (  translated
        10 PACKAGE BODY         IMX                                   703       21614 .046399782 .000000084 .000025417             ELSIF UPPER(tp) IN (  'FA', 'RE')
        10 PACKAGE BODY         IMX                                  1065       27071 .042652852 .000000128 .000017681                     FOR l IN (
        10 PACKAGE BODY         IMX                                   462       26997 .039251203 .000000309  .00001662         END;
        10 PACKAGE BODY         IMX                                   420       26997 .038540763 .000001102 .000033453         FUNCTION v_tdTranslate ( lbl VARCHAR2, tp VARCHAR2 D
        10 PACKAGE BODY         UI_E_VICHRODV                        1498       27071  .03844438 .000000088 .000064867          libelle_trad := ftranslate_str(libelle_trad, NVL(pi
        10 PACKAGE BODY         IMX                                  1078           0 .036005895 .000000894  .00001468                     END LOOP;
        10 PACKAGE BODY         IMX                                  1052       27071 .035763037 .000000888 .000012976             IF SUBSTR(RTRIM(libelle), -1, 1) = '''' AND type
*/
/********************************OLD Metrics***************************************/

/********************************New SQL*******************************************/

;
/********************************New SQL*******************************************/
/********************************New Metrics***************************************/
/*

*/
/********************************New Metrics***************************************/

/********************************Index statistics**********************************/

/********************************Other SQLs****************************************/          
/*

*/ 
/********************************Other SQLs****************************************/              
