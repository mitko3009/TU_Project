/********************************************************************************
*********       E-mail subject: EFDE2DEV-1471
*********             Instance: PATCH 2
*********          Description: 
Problem:
Slow execution of SQL f18gkt6mkxjxt on PATCH 2.

Analysis:
From the analyze, I found that SQL f18gkt6mkxjxt ( this is the sql_id of the MERGE statement from the task description ) was responsible for 98% of the time of std_migr_mvt.reloadFiLimitMap module.
There problem is missing index on column DECOMPTE_ID on table G_VENFILIMIT, which leads to a full scan.

Suggestion:
Please ask DBA to deliver the missing index GVFL_DECOMPTE_ID_IDX on table G_VENFILIMIT from refbg2 to Patch 2.


*********               SQL_ID: f18gkt6mkxjxt
*********      Program/Package: std_migr_mvt.reloadFiLimitMap
*********              Request: Ognyan Tonev 
*********               Author: Dimitar Dimitrov
********* Received e-mail date: 25/03/2024
*********      Resolution date: 25/03/2024
*********  Trace old file here: \\epox\specifs\performance\tmp\
*********  Trace new file here:
***********************************************************************************/

/********************************OLD SQL*******************************************/

MERGE INTO G_VENFILIMIT V_DESTINATION
USING (SELECT V.IMX_UN_ID,
              CASE
                WHEN V.LIMIT_ROLE = 'COVERAGE' THEN
                 M.COVER_AMT
                ELSE
                 M.FUNDED_AMT
              END NEW_CONSUMED_MVT,
              CASE
                WHEN E.DEVISE_DOS = L.GPIDEVIS THEN
                 CASE
                   WHEN V.LIMIT_ROLE = 'COVERAGE' THEN
                    M.COVER_AMT
                   ELSE
                    M.FUNDED_AMT
                 END
                ELSE
                 CH_TAUX.CONV_ORIG_DEST_TX(CASE
                                             WHEN NVL(S.FG_USE_EXCH_RATE_FIR, 'N') = 'O' THEN
                                              TO_CHAR(SYSDATE, 'j')
                                             ELSE
                                              TO_CHAR(NVL(R.GPIDATE6_DT, D.DT01_DT), 'j')
                                           END,
                                           CASE
                                             WHEN V.LIMIT_ROLE = 'COVERAGE' THEN
                                              M.COVER_AMT
                                             ELSE
                                              M.FUNDED_AMT
                                           END,
                                           E.DEVISE_DOS,
                                           L.GPIDEVIS,
                                           'MER',
                                           FTR_FIN_FACTOR.GETCURRENCY(A.REFFACTOR),
                                           FTR_FIN_FACTOR.GETPAYS(A.REFFACTOR),
                                           0)
              END NEW_CONSUMED_LIM
         FROM G_VENFILIMIT V,
              G_ELEMFI     E,
              G_DOSSIER    A,
              STD_MIGR_FNC M,
              G_ETUDE      S,
              G_PIECE      L,
              G_PIECEDET   D,
              G_PIECE      R
        WHERE V.DECOMPTE_ID = :B1
          AND V.LIMIT_ROLE IN ('FINANCING', 'COVERAGE')
          AND E.REFELEM = V.FI_ID
          AND A.REFDOSS = E.REFDOSS
          AND M.IMX_REF = V.FI_ID
          AND L.REFPIECE = V.LIMIT_ID
          AND D.REFPIECE = V.LIMIT_ID
          AND D.NB04 = V.LIMIT_DETAIL_ID
          AND R.TYPPIECE(+) = 'REQUEST_LIMITE'
          AND R.REFPIECE(+) = L.STR_20_1
          AND ((V.LIMIT_ROLE = 'COVERAGE' AND NVL(M.COVER_AMT, 0) != 0) OR
              (V.LIMIT_ROLE = 'FINANCING' AND NVL(M.FUNDED_AMT, 0) != 0))) V_SOURCE
ON (V_SOURCE.IMX_UN_ID = V_DESTINATION.IMX_UN_ID AND NVL(V_SOURCE.NEW_CONSUMED_MVT, V_SOURCE.NEW_CONSUMED_LIM) IS NOT NULL)
WHEN MATCHED THEN
  UPDATE
     SET CONSUMED_MVT = NVL(V_SOURCE.NEW_CONSUMED_MVT, CONSUMED_MVT),
         CONSUMED_LIM = NVL(V_SOURCE.NEW_CONSUMED_LIM, CONSUMED_LIM)
   WHERE V_DESTINATION.CONSUMED_MVT !=
         NVL(V_SOURCE.NEW_CONSUMED_MVT, V_DESTINATION.CONSUMED_MVT)
      OR V_DESTINATION.CONSUMED_LIM !=
         NVL(V_SOURCE.NEW_CONSUMED_LIM, V_DESTINATION.CONSUMED_LIM);

/********************************OLD SQL*******************************************/
/********************************OLD Metrics***************************************/
/*
MODULE                           SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL            PERC
-------------------------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
std_migr_mvt.reloadFiLimitMap                                    181      36802 ON CPU               2024/03/22 15:22:10  2024/03/22 23:23:42        2871              3873331 +000000000 08:01:31.990 84%
DBMS_SCHEDULER                                                   363            ON CPU               2024/03/22 17:25:56  2024/03/22 22:34:40         203             16337994 +000000000 05:08:44.215 6%
SQL*Plus                                                                        ON CPU               2024/03/22 15:20:30  2024/03/22 20:13:43         126                31065 +000000000 04:53:13.629 4%
pt_migr_stats_create                                                            ON CPU               2024/03/22 15:23:10  2024/03/22 23:29:02          86               255836 +000000000 08:05:52.134 3%
PT_MIGR_STATS_CREATE                                                            ON CPU               2024/03/22 15:23:50  2024/03/22 21:55:38          27                   19 +000000000 06:31:48.468 1%


MODULE                           SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL            PERC
-------------------------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
std_migr_mvt.reloadFiLimitMap                                    181      36802 ON CPU               2024/03/22 15:22:10  2024/03/22 23:23:42        2871              3873331 +000000000 08:01:31.990 99%
std_migr_mvt.reloadFiLimitMap                                    181      36802 db file scattered re 2024/03/22 15:22:00  2024/03/22 15:31:30           8                    1 +000000000 00:09:30.493 0%
std_migr_mvt.reloadFiLimitMap                                    181      36802 db file sequential r 2024/03/22 15:22:40  2024/03/22 17:51:47           8                55950 +000000000 02:29:06.997 0%


MODULE                           SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL            PERC
-------------------------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
std_migr_mvt.reloadFiLimitMap    f18gkt6mkxjxt 1504382107        181      36802                      2024/03/22 15:30:30  2024/03/22 23:23:42        2822                 6197 +000000000 07:53:11.562 98%
std_migr_mvt.reloadFiLimitMap    7uua6gvdqnk3j  367807891        181      36802                      2024/03/22 15:22:20  2024/03/22 15:30:10          27                55321 +000000000 00:07:50.402 1%


SQL_ID        SQL_PLAN_HASH_VALUE SQL_PLAN_LINE_ID SQL_PLAN_OPERATION             SQL_PLAN_OPTIONS                   ACTIVE
------------- ------------------- ---------------- ------------------------------ ------------------------------ ----------
f18gkt6mkxjxt          1504382107               12 TABLE ACCESS                   FULL                                 2751
f18gkt6mkxjxt          1504382107               16 TABLE ACCESS                   FULL                                   37
f18gkt6mkxjxt          1504382107                                                                                        13
f18gkt6mkxjxt          1504382107                  MERGE STATEMENT                                                        4
f18gkt6mkxjxt          1504382107               26 INDEX                          RANGE SCAN                              3
f18gkt6mkxjxt          1504382107                1 MERGE                                                                  3
f18gkt6mkxjxt          1504382107               17 TABLE ACCESS                   BY INDEX ROWID BATCHED                  2
f18gkt6mkxjxt          1504382107               19 TABLE ACCESS                   BY INDEX ROWID                          2
f18gkt6mkxjxt          1504382107               11 HASH JOIN                                                              2
f18gkt6mkxjxt          1504382107               23 TABLE ACCESS                   BY INDEX ROWID BATCHED                  1
f18gkt6mkxjxt          1504382107               22 INDEX                          UNIQUE SCAN                             1
f18gkt6mkxjxt          1504382107               20 INDEX                          UNIQUE SCAN                             1
f18gkt6mkxjxt          1504382107               27 INDEX                          UNIQUE SCAN                             1
f18gkt6mkxjxt          1504382107               18 INDEX                          RANGE SCAN                              1

Plan hash value: 1504382107
-----------------------------------------------------------------------------------------------------------------
| Id  | Operation                                     | Name            | Rows  | Bytes | Cost (%CPU)| Time     |
-----------------------------------------------------------------------------------------------------------------
|   0 | MERGE STATEMENT                               |                 |       |       |   113K(100)|          |
|   1 |  MERGE                                        | G_VENFILIMIT    |       |       |            |          |
|   2 |   VIEW                                        |                 |       |       |            |          |
|   3 |    NESTED LOOPS                               |                 |     1 |   309 |   113K  (1)| 00:00:05 |
|   4 |     NESTED LOOPS                              |                 |     1 |   309 |   113K  (1)| 00:00:05 |
|*  5 |      FILTER                                   |                 |       |       |            |          |
|   6 |       NESTED LOOPS OUTER                      |                 |     1 |   177 |   113K  (1)| 00:00:05 |
|   7 |        NESTED LOOPS                           |                 |     1 |   155 |   113K  (1)| 00:00:05 |
|   8 |         NESTED LOOPS                          |                 |     1 |   142 |   113K  (1)| 00:00:05 |
|   9 |          NESTED LOOPS                         |                 |     1 |   122 |   113K  (1)| 00:00:05 |
|  10 |           NESTED LOOPS                        |                 |     1 |   100 |   113K  (1)| 00:00:05 |
|* 11 |            HASH JOIN                          |                 |  2712 |   219K| 91998   (1)| 00:00:04 |
|* 12 |             TABLE ACCESS FULL                 | G_VENFILIMIT    | 11979 |   608K| 87112   (1)| 00:00:04 |
|  13 |             MERGE JOIN CARTESIAN              |                 |   843K|    24M|  4882   (2)| 00:00:01 |
|  14 |              TABLE ACCESS FULL                | G_ETUDE         |     1 |     4 |     5   (0)| 00:00:01 |
|  15 |              BUFFER SORT                      |                 |   843K|    21M|  4877   (2)| 00:00:01 |
|  16 |               TABLE ACCESS FULL               | STD_MIGR_FNC    |   843K|    21M|  4877   (2)| 00:00:01 |
|* 17 |            TABLE ACCESS BY INDEX ROWID BATCHED| G_PIECEDET      |     1 |    17 |     8   (0)| 00:00:01 |
|* 18 |             INDEX RANGE SCAN                  | G_PIECEDET_REFP |     9 |       |     3   (0)| 00:00:01 |
|* 19 |           TABLE ACCESS BY INDEX ROWID         | G_ELEMFI        |     1 |    22 |     2   (0)| 00:00:01 |
|* 20 |            INDEX UNIQUE SCAN                  | EFI_REFELEM     |     1 |       |     1   (0)| 00:00:01 |
|  21 |          TABLE ACCESS BY INDEX ROWID          | G_DOSSIER       |     1 |    20 |     2   (0)| 00:00:01 |
|* 22 |           INDEX UNIQUE SCAN                   | DOS_REFDOSS     |     1 |       |     1   (0)| 00:00:01 |
|  23 |         TABLE ACCESS BY INDEX ROWID BATCHED   | G_PIECE         |     1 |    13 |     3   (0)| 00:00:01 |
|* 24 |          INDEX RANGE SCAN                     | PIE_REFPIECE    |     1 |       |     2   (0)| 00:00:01 |
|* 25 |        TABLE ACCESS BY INDEX ROWID BATCHED    | G_PIECE         |     1 |    22 |     3   (0)| 00:00:01 |
|* 26 |         INDEX RANGE SCAN                      | PIE_REFPIECE    |     1 |       |     2   (0)| 00:00:01 |
|* 27 |      INDEX UNIQUE SCAN                        | PK_G_VENFILIMIT |     1 |       |     1   (0)| 00:00:01 |
|  28 |     TABLE ACCESS BY INDEX ROWID               | G_VENFILIMIT    |     1 |   132 |     2   (0)| 00:00:01 |
-----------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   5 - filter(NVL(CASE "V"."LIMIT_ROLE" WHEN 'COVERAGE' THEN "M"."COVER_AMT" ELSE "M"."FUNDED_AMT" END
              ,CASE "E"."DEVISE_DOS" WHEN "L"."GPIDEVIS" THEN CASE "V"."LIMIT_ROLE" WHEN 'COVERAGE' THEN
              "M"."COVER_AMT" ELSE "M"."FUNDED_AMT" END  ELSE "CH_TAUX"."CONV_ORIG_DEST_TX"(TO_NUMBER(CASE
              NVL("S"."FG_USE_EXCH_RATE_FIR",'N') WHEN 'O' THEN TO_CHAR(SYSDATE@!,'j') ELSE
              TO_CHAR(NVL("R"."GPIDATE6_DT","D"."DT01_DT"),'j') END ),CASE "V"."LIMIT_ROLE" WHEN 'COVERAGE' THEN
              "M"."COVER_AMT" ELSE "M"."FUNDED_AMT" END ,"E"."DEVISE_DOS","L"."GPIDEVIS",'MER',"FTR_FIN_FACTOR"."GETCUR
              RENCY"("A"."REFFACTOR"),"FTR_FIN_FACTOR"."GETPAYS"("A"."REFFACTOR"),0) END ) IS NOT NULL)
  11 - access("M"."IMX_REF"="V"."FI_ID")
       filter((("V"."LIMIT_ROLE"='COVERAGE' AND NVL("M"."COVER_AMT",0)<>0) OR
              ("V"."LIMIT_ROLE"='FINANCING' AND NVL("M"."FUNDED_AMT",0)<>0)))
  12 - filter("V"."DECOMPTE_ID"=:B1)
  17 - filter("D"."NB04"=TO_NUMBER("V"."LIMIT_DETAIL_ID"))
  18 - access("D"."REFPIECE"="V"."LIMIT_ID")
  19 - filter("E"."REFDOSS" IS NOT NULL)
  20 - access("E"."REFELEM"="V"."FI_ID")
  22 - access("A"."REFDOSS"="E"."REFDOSS")
  24 - access("L"."REFPIECE"="V"."LIMIT_ID")
  25 - filter("R"."TYPPIECE"='REQUEST_LIMITE')
  26 - access("R"."REFPIECE"="L"."STR_20_1")
  27 - access("V"."IMX_UN_ID"="V_DESTINATION"."IMX_UN_ID") 
*/
/********************************OLD Metrics***************************************/

/********************************New SQL*******************************************/

-- No changes in the SQL text.
/********************************New SQL*******************************************/
/********************************New Metrics***************************************/
/*

*/
/********************************New Metrics***************************************/

/********************************Index statistics**********************************/

/********************************Other SQLs****************************************/          
/*

*/ 
/********************************Other SQLs****************************************/              
