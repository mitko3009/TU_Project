=================================================================================================================================
=================================================================================================================================
######### STOP AND START DATABASE, AND LOCATED ON RIGHT NODE ######

Using username "dxcbella".
Authenticating with public key "imported-openssh-key" from agent
The authenticity of host 'fivatx0237.adinfra.net (132.171.139.165)' can't be established.
RSA key fingerprint is 11:e5:9f:a8:ac:5c:bb:12:c1:41:50:bd:a1:6b:55:8f.
Are you sure you want to continue connecting (yes/no)? yes
Warning: Permanently added 'fivatx0237.adinfra.net,132.171.139.165' (RSA) to the list of known hosts.
-bash-4.2$ nsu
Password:

Warning: Your password to nsu will expire in 4 weeks

[root@fivatx0237 ~]#
[root@fivatx0237 ~]#
[root@fivatx0237 ~]#
[root@fivatx0237 ~]# dbspicao -pdfv
DB-SPI Collection/Analysis has been turned OFF for instance SIMPROD_2
DB-SPI Collection/Analysis has been turned OFF for instance ABAT_1
Checking instance: 'ABAT_2' @ '/oracle/product/12.2.0/dbhome_2':
2019-07-15T16:21:00 ERROR dbspicao(10) ABAT_2 [cola:ora_util.pc:411]: DBSPI10-23: Unable to connect to database 'ABAT_2' [ORA-12520: TNS:listener could not f                                                                                ind available handler for requested type of server]. See Instruction text or User's Guide for details.
        Connect:         FAILED

Checking instance: 'AQUA_2' @ '/oracle/product/12.2.0/dbhome_2':
        Connect:         OKAY
        Filter 4:        OKAY
        Filter 6:        OKAY

[root@fivatx0237 ~]# ps -ef | grep tns
root        52     2  0 Jul09 ?        00:00:00 [netns]
root      6088  4460  0 16:21 pts/0    00:00:00 grep --color=auto tns
grid     10286     1  0 16:07 ?        00:00:00 /grid/app/grid/18/bin/tnslsnr ASMNET1LSNR_ASM -no_crs_notify -inherit
grid     10314     1  0 16:07 ?        00:00:00 /grid/app/grid/18/bin/tnslsnr LISTENER -no_crs_notify -inherit
grid     10340     1  0 16:07 ?        00:00:00 /grid/app/grid/18/bin/tnslsnr LISTENER_SCAN1 -no_crs_notify -inherit
[root@fivatx0237 ~]# w
 16:21:42 up 5 days, 23:46,  1 user,  load average: 1.18, 1.43, 1.51
USER     TTY      FROM             LOGIN@   IDLE   JCPU   PCPU WHAT
dxcbella pts/0    132.171.7.8      16:20    6.00s  0.00s  0.00s sshd: dxcbella [priv]
[root@fivatx0237 ~]#
[root@fivatx0237 ~]#
[root@fivatx0237 ~]# su - oracle
Last login: Mon Jul 15 16:18:05 UTC 2019
[oracle@fivatx0237 ~]$
[oracle@fivatx0237 ~]$
[oracle@fivatx0237 ~]$ . oraenv
ORACLE_SID = [oracle] ? ABAT_2
The Oracle base has been set to /oracle
[oracle@fivatx0237 ~]$
[oracle@fivatx0237 ~]$
[oracle@fivatx0237 ~]$
[oracle@fivatx0237 ~]$ sqlplus / as sysdba

SQL*Plus: Release 12.2.0.1.0 Production on Mon Jul 15 16:22:11 2019

Copyright (c) 1982, 2016, Oracle.  All rights reserved.

Connected to an idle instance.

SQL>
SQL>
SQL>
SQL> start up
SP2-0310: unable to open file "up.sql"
SQL> startup
ORA-39510: CRS error performing start on instance 'ABAT_2' on 'ABAT'
CRS-2552: There are no available instances of resource 'ora.abat.db' to start.
CRS-0223: Resource 'ora.abat.db' has placement error.
clsr_start_resource:260 status:223
clsrapi_start_db:start_asmdbs status:223
SQL> exit
Disconnected
[oracle@fivatx0237 ~]$ srvctl status database -d ABAT
Instance ABAT_2 is running on node fivatx0236
Online relocation: INACTIVE
[oracle@fivatx0237 ~]$ srvctl stop  database -d ABAT
[oracle@fivatx0237 ~]$
[oracle@fivatx0237 ~]$ srvctl start database -d ABAT -i ABAT_2 -n fivatx0237
PRKO-2002 : Invalid command line option: -i
[oracle@fivatx0237 ~]$ srvctl start database -d ABAT -n fivatx0237
[oracle@fivatx0237 ~]$ srvctl stop database -d **** && srvctl start database -d -n^C
[oracle@fivatx0237 ~]$
[oracle@fivatx0237 ~]$
[oracle@fivatx0237 ~]$
[oracle@fivatx0237 ~]$ logout
[root@fivatx0237 ~]# dbspicao -pdfv
DB-SPI Collection/Analysis has been turned OFF for instance SIMPROD_2
DB-SPI Collection/Analysis has been turned OFF for instance ABAT_1
Checking instance: 'ABAT_2' @ '/oracle/product/12.2.0/dbhome_2':
        Connect:         OKAY
        Filter 4:        OKAY
        Filter 6:        OKAY

Checking instance: 'AQUA_2' @ '/oracle/product/12.2.0/dbhome_2':
        Connect:         OKAY
        Filter 4:        OKAY
        Filter 6:        OKAY

