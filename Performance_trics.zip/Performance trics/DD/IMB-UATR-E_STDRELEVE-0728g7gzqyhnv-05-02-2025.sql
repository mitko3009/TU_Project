/********************************************************************************
*********       E-mail subject: IMBWEB-8226
*********             Instance: UATR
*********          Description: 
Problem:
Slowness in E_STDRELEVE screen.

Analysis:
We received complaint for E_STDRELEVE screen from 03/02/2025 on UATR. There was no provided exact time period for the slowness, but we think that we identified what is the 
reason for the slowness ( based on the TTY that can be seen in the screenshots in the task ). For session with SID = 580 and SERIAL# = 52385 the TOP two SQLs are 83p9wum019ku4 and 0728g7gzqyhnv.
They were responsible for over 80% of the time. SQL 83p9wum019ku4 was executed ~6 million times and it is from function FACTOR_RELEVE.isBrokerReleve() in SQL 0728g7gzqyhnv, which was executed 
only once. Because there is no selective search criteria, SQL 0728g7gzqyhnv makes FULL SCANs and calls the function millions times, which is the reason for the delay. We made the 
scalar subquery caching trick for function FACTOR_RELEVE.isBrokerReleve(), which saves time, but in any case if it is expected this screen to work without providing selective search criteria 
it should be expected to take time and not finish in 1-2 seconds. 

Suggestion:
1. Please change the query as it is shown in the New SQL section below.
2. Please check is it OK to have screen in which the user can search without anything selective and if it is, you can think for addind some warning to the user that this search can take time.

*********               SQL_ID: 0728g7gzqyhnv
*********      Program/Package: 
*********              Request: Galya Georgieva 
*********               Author: Dimitar Dimitrov
********* Received e-mail date: 04/02/2025
*********      Resolution date: 05/02/2025
*********  Trace old file here: \\epox\specifs\performance\tmp\
*********  Trace new file here:
***********************************************************************************/

/********************************OLD SQL*******************************************/

-- 0728g7gzqyhnv

SELECT SOURCE_PMT,
       SOURCE_STATUS,
       ORIG_ID,
       BATCH,
       RECEIVED_DT,
       PAYER_ID,
       AMOUNT,
       CURR,
       PMETHODE
  FROM (SELECT REL.er_num orig_id,
               to_char( REL.er_dat_dt, NVL( 'DD/MM/RRRR', 'DD/MM/RRRR' ) ) batch,
               REL.er_cli payer_id,
               REL.er_dat_dt received_dt,
               REL.er_tcr_mvt amount,
               REL.er_devise_mvt curr,
               REL.er_moyp pmethode,
               'REL' source_status,
               'CN' source_pmt,
               FACTOR_RELEVE.isBrokerReleve(rel.er_num) isBrokerReleve
          FROM f_entrel REL
         WHERE Nvl( REL.er_tcr_mvt, 0 ) > 0
           AND Nvl( REL.er_com, '$' ) <> 'P'
           AND NOT EXISTS ( SELECT 1
                              FROM f_detfac, 
                                   t_ecrdos
                             WHERE df_rel = er_num
                               AND df_cli = er_cli
                               AND df_num = t_ecrdos.refelem
                               AND UPPER( df_nom ) = t_ecrdos.codecr )
        UNION
        SELECT COL.compostage orig_id,
               dtlot batch,
               COL.refpayeur payer_id,
               COL.dtextrait_dt received_dt,
               COL.montant amount,
               COL.devise curr,
               COL.familLe pmethode,
               COL.etat source_status,
               'COL' source_pmt,
               0 isBrokerReleve
          FROM nam_collecte COL, 
               g_encaissement ENC
         WHERE compostage = encodeur
           AND typencaiss IN ( 'e_releve', 'e_reglatt' )
           AND dtannul_dt IS NULL
           AND dtreventil IS NULL
           AND compostage NOT LIKE 'MAN%'
           AND etat = 'RCI'
        UNION
        SELECT COL.compostage orig_id,
               dtlot batch,
               COL.refpayeur payer_id,
               COL.dtextrait_dt received_dt,
               COL.montant amount,
               COL.devise curr,
               COL.familLe pmethode,
               COL.etat source_status,
               'COL' source_pmt,
               0 isBrokerReleve
          FROM nam_collecte COL
         WHERE etat = 'RCN'
           AND compostage NOT LIKE 'MAN%'
        UNION
        SELECT REL.er_num orig_id,
               to_char( REL.er_dat_dt, NVL( 'DD/MM/RRRR', 'DD/MM/RRRR' ) ) batch,
               REL.er_cli payer_id,
               ENC.dtreception_dt received_dt,
               REL.er_tdb_mvt amount,
               REL.er_devise_mvt curr,
               ENC.moyenpaimt pmethode,
               'DP' source_status,
               'DP' source_pmt,
               0 isBrokerReleve
          FROM f_entrel REL, 
               g_encaissement ENC
         WHERE ENC.refext = 'RQST'
           AND ENC.createur = 'e_releve_rqst'
           AND ENC.lieupaimt = REL.er_num ) P
 WHERE 1 = 1
   AND EXISTS ( SELECT 1
                  FROM g_individu I
                 WHERE I.nom LIKE 'PALFINGER%'
                   AND I.refindividu = P.payer_id )
   AND P.isBrokerReleve = 0
 order by RECEIVED_DT desc;
/********************************OLD SQL*******************************************/
/********************************OLD Metrics***************************************/
/*

MODULE                           PROGRAM                                            CLIENT_ID       ACTION                    SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- -------------------------------------------------- --------------- ------------------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
E_STDRELEVE                      frmweb                                             J10FECB                                                                                                       2025/02/03 10:12:57  2025/02/03 12:19:40          36              6066725 +000000000 02:06:43.001 100%


MODULE                           PROGRAM                                            CLIENT_ID       ACTION                    SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- -------------------------------------------------- --------------- ------------------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
E_STDRELEVE                      frmweb                                             J10FECB                                                                                  ON CPU               2025/02/03 10:13:07  2025/02/03 12:19:40           18             5611963 +000000000 02:06:32.995 50%
E_STDRELEVE                      frmweb                                             J10FECB                                                                                  cell single block ph 2025/02/03 10:12:57  2025/02/03 12:19:10           15             6027679 +000000000 02:06:12.983 42%
E_STDRELEVE                      frmweb                                             J10FECB                                   0728g7gzqyhnv 3400672075        580      52385 cell multiblock phys 2025/02/03 10:17:48  2025/02/03 10:18:08            3                   1 +000000000 00:00:20.012 8%


MODULE                           PROGRAM                                            CLIENT_ID       ACTION                    SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                  TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- -------------------------------------------------- --------------- ------------------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
E_STDRELEVE                      frmweb                                             J10FECB                                   83p9wum019ku4  276563559        580      52385                      2025/02/03 10:12:57  2025/02/03 10:17:38          18              5957244 +000000000 00:04:40.510 50%
E_STDRELEVE                      frmweb                                             J10FECB                                   0728g7gzqyhnv 3400672075        580      52385                      2025/02/03 10:13:58  2025/02/03 10:18:08          12                    1 +000000000 00:04:10.152 33%
E_STDRELEVE                      frmweb                                             J10FECB                                   0c5u9jh9579g6 1584077880         92      34561 ON CPU               2025/02/03 12:17:50  2025/02/03 12:19:40           2                27220 +000000000 00:01:50.065 6%
E_STDRELEVE                      frmweb                                             J10FECB                                   01gkydqqh7whh 3563877274         92      34561 cell single block ph 2025/02/03 12:18:30  2025/02/03 12:19:10           2                10026 +000000000 00:00:40.024 6%
E_STDRELEVE                      frmweb                                             J10FECB                                   aq0y6j826jrut 2551813405         92      34561 ON CPU               2025/02/03 12:16:40  2025/02/03 12:16:40           1                      +000000000 00:00:00.000 3%
E_STDRELEVE                      frmweb                                             J10FECB                                                          0        580      52385 ON CPU               2025/02/03 10:14:58  2025/02/03 10:14:58           1                      +000000000 00:00:00.000 3%



INSTANCE_NUMBER SQL_ID            ELAPSED MAX_WAIT_ON     PC_OF  WAIT_TIME            GETS      READS       ROWS  ELAP/EXEC       GETS/EXEC READS/EXEC  ROWS/EXEC       EXEC PLAN_HASH_VALUE
--------------- ------------- ----------- --------------- ----- ---------- --------------- ---------- ---------- ---------- --------------- ---------- ---------- ---------- ---------------
              1 01gkydqqh7whh          12 IO              70%    13.700671          242586      34430      66573          0               4        .52          1      66573      3563877274
              1 0728g7gzqyhnv         320 CPU             65%   366.492163        45633768    2812586         83     319.71        45633768    2812586         83          1      3400672075
              1 0c5u9jh9579g6          11 IO              56%    15.398124          266242      20140      66557          0               4         .3          1      66557      1584077880
              1 83p9wum019ku4         168 CPU             56%   202.251024        43106963     290666          2          0               7        .05          0    6154034       276563559
              1 aq0y6j826jrut           7 CPU             100%    4.348999          255146          2      63784          0               4          0          1      63784      2551813405



SQL_ID        SQL_PLAN_HASH_VALUE SQL_PLAN_LINE_ID SQL_PLAN_OPERATION             SQL_PLAN_OPTIONS                   ACTIVE
------------- ------------------- ---------------- ------------------------------ ------------------------------ ----------
0728g7gzqyhnv          3400672075                  SELECT STATEMENT                                                       9
0728g7gzqyhnv          3400672075               13 INDEX                          STORAGE FAST FULL SCAN                  3


SQL_ID        TOP_LEVEL_SQL   COUNT(*)
------------- ------------- ----------
83p9wum019ku4 0728g7gzqyhnv         18
0728g7gzqyhnv 0728g7gzqyhnv         12
              0728g7gzqyhnv          1


Plan hash value: 3400672075
------------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                  | Name              | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  |
------------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                           |                   |      1 |        |   108K(100)|     83 |00:07:52.87 |      45M|   2813K|
|   1 |  SORT ORDER BY                             |                   |      1 |      1 |   108K (16)|     83 |00:07:52.87 |      45M|   2813K|
|*  2 |   HASH JOIN                                |                   |      1 |      1 |   108K (16)|     83 |00:07:52.87 |      45M|   2813K|
|   3 |    TABLE ACCESS BY INDEX ROWID BATCHED     | G_INDIVIDU        |      1 |      1 |     5   (0)|     18 |00:00:00.01 |      21 |      3 |
|*  4 |     INDEX RANGE SCAN                       | G_INDIV_NOM_PROF  |      1 |      1 |     3   (0)|     18 |00:00:00.01 |       3 |      3 |
|   5 |    VIEW                                    |                   |      1 |    124K|   108K (16)|  67924 |00:07:52.85 |      45M|   2813K|
|   6 |     SORT UNIQUE                            |                   |      1 |    124K|   108K (16)|  67924 |00:07:52.84 |      45M|   2813K|
|   7 |      UNION-ALL                             |                   |      1 |        |            |    381K|00:07:52.54 |      45M|   2813K|
|*  8 |       HASH JOIN ANTI                       |                   |      1 |    615 | 43255  (22)|   1351 |00:07:51.50 |      43M|   1109K|
|*  9 |        TABLE ACCESS STORAGE FULL           | F_ENTREL          |      1 |  61512 | 13144  (40)|   7637 |00:07:02.14 |      43M|    538K|
|  10 |        VIEW                                | VW_SQ_1           |      1 |    115K| 30107  (13)|   5618K|00:00:47.20 |     570K|    570K|
|* 11 |         HASH JOIN                          |                   |      1 |    115K| 30107  (13)|   5618K|00:00:46.52 |     570K|    570K|
|  12 |          TABLE ACCESS STORAGE FULL         | F_DETFAC          |      1 |   6173K| 12274  (10)|   6174K|00:00:02.20 |     353K|    353K|
|  13 |          INDEX STORAGE FAST FULL SCAN      | IDX_FFSI_T_ECRDOS |      1 |     32M|  7742  (15)|     32M|00:00:12.65 |     216K|    216K|
|* 14 |       HASH JOIN                            |                   |      1 |  60139 | 51226  (13)|    315K|00:00:00.68 |    1419K|   1419K|
|  15 |        JOIN FILTER CREATE                  | :BF0000           |      1 |  60139 | 41141  (14)|    316K|00:00:00.48 |    1135K|   1135K|
|* 16 |         TABLE ACCESS STORAGE FULL          | G_ENCAISSEMENT    |      1 |  60139 | 41141  (14)|    316K|00:00:00.46 |    1135K|   1135K|
|  17 |        JOIN FILTER USE                     | :BF0000           |      1 |   1602K| 10050  (11)|  62835 |00:00:00.07 |     284K|    284K|
|* 18 |         TABLE ACCESS STORAGE FULL          | NAM_COLLECTE      |      1 |   1602K| 10050  (11)|  62835 |00:00:00.06 |     284K|    284K|
|* 19 |       TABLE ACCESS STORAGE FULL            | NAM_COLLECTE      |      1 |  64003 |  9909   (9)|  64003 |00:00:00.08 |     284K|    284K|
|  20 |       NESTED LOOPS                         |                   |      1 |      1 |     6   (0)|      0 |00:00:00.09 |     192 |    178 |
|  21 |        NESTED LOOPS                        |                   |      1 |      1 |     6   (0)|      0 |00:00:00.09 |     192 |    178 |
|* 22 |         TABLE ACCESS BY INDEX ROWID BATCHED| G_ENCAISSEMENT    |      1 |      1 |     4   (0)|    250 |00:00:00.09 |     178 |    178 |
|* 23 |          INDEX RANGE SCAN                  | GENC_REFEXT_IDX   |      1 |      1 |     3   (0)|    387 |00:00:00.01 |       4 |      4 |
|* 24 |         INDEX UNIQUE SCAN                  | ENTREL_CL1        |    250 |      1 |     1   (0)|      0 |00:00:00.01 |      14 |      0 |
|  25 |        TABLE ACCESS BY INDEX ROWID         | F_ENTREL          |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
------------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   2 - access("I"."REFINDIVIDU"="P"."PAYER_ID")
   4 - access("I"."NOM" LIKE 'PALFINGER%')
       filter("I"."NOM" LIKE 'PALFINGER%')
   8 - access("ITEM_1"="ER_NUM" AND "ITEM_2"="ER_CLI")
   9 - filter(("FACTOR_RELEVE"."ISBROKERRELEVE"("REL"."ER_NUM")=0 AND NVL("REL"."ER_TCR_MVT",0)>0 AND NVL("REL"."ER_COM",'$')<>'P'))
  11 - access("DF_NUM"="T_ECRDOS"."REFELEM" AND "T_ECRDOS"."CODECR"=UPPER("DF_NOM"))
  14 - access("COMPOSTAGE"="ENCODEUR")
  16 - storage(("ENCODEUR" IS NOT NULL AND INTERNAL_FUNCTION("TYPENCAISS") AND "DTANNUL_DT" IS NULL AND "DTREVENTIL" IS NULL))
       filter(("ENCODEUR" IS NOT NULL AND INTERNAL_FUNCTION("TYPENCAISS") AND "DTANNUL_DT" IS NULL AND "DTREVENTIL" IS NULL))
  18 - storage(("ETAT"='RCI' AND "COMPOSTAGE" NOT LIKE 'MAN%' AND SYS_OP_BLOOM_FILTER(:BF0000,"COMPOSTAGE")))
       filter(("ETAT"='RCI' AND "COMPOSTAGE" NOT LIKE 'MAN%' AND SYS_OP_BLOOM_FILTER(:BF0000,"COMPOSTAGE")))
  19 - storage(("ETAT"='RCN' AND "COMPOSTAGE" NOT LIKE 'MAN%'))
       filter(("ETAT"='RCN' AND "COMPOSTAGE" NOT LIKE 'MAN%'))
  22 - filter(("ENC"."LIEUPAIMT" IS NOT NULL AND "ENC"."CREATEUR"='e_releve_rqst'))
  23 - access("ENC"."REFEXT"='RQST')
  24 - access("ENC"."LIEUPAIMT"="REL"."ER_NUM")
*/
/********************************OLD Metrics***************************************/

/********************************New SQL*******************************************/

SELECT SOURCE_PMT,
       SOURCE_STATUS,
       ORIG_ID,
       BATCH,
       RECEIVED_DT,
       PAYER_ID,
       AMOUNT,
       CURR,
       PMETHODE   
  FROM (SELECT REL.er_num orig_id,
               to_char( REL.er_dat_dt, NVL( 'DD/MM/RRRR', 'DD/MM/RRRR' ) ) batch,
               REL.er_cli payer_id,
               REL.er_dat_dt received_dt,
               REL.er_tcr_mvt amount,
               REL.er_devise_mvt curr,
               REL.er_moyp pmethode,
               'REL' source_status,
               'CN' source_pmt,
               ( select FACTOR_RELEVE.isBrokerReleve(rel.er_num)  from dual ) isBrokerReleve             
          FROM f_entrel REL
         WHERE Nvl( REL.er_tcr_mvt, 0 ) > 0
           AND Nvl( REL.er_com, '$' ) <> 'P'
           AND NOT EXISTS ( SELECT 1
                              FROM f_detfac, 
                                   t_ecrdos
                             WHERE df_rel = er_num
                               AND df_cli = er_cli
                               AND df_num = t_ecrdos.refelem
                               AND UPPER( df_nom ) = t_ecrdos.codecr )
        UNION
        SELECT COL.compostage orig_id,
               dtlot batch,
               COL.refpayeur payer_id,
               COL.dtextrait_dt received_dt,
               COL.montant amount,
               COL.devise curr,
               COL.familLe pmethode,
               COL.etat source_status,
               'COL' source_pmt,
               0 isBrokerReleve
          FROM nam_collecte COL, 
               g_encaissement ENC
         WHERE compostage = encodeur
           AND typencaiss IN ( 'e_releve', 'e_reglatt' )
           AND dtannul_dt IS NULL
           AND dtreventil IS NULL
           AND compostage NOT LIKE 'MAN%'
           AND etat = 'RCI'
        UNION
        SELECT COL.compostage orig_id,
               dtlot batch,
               COL.refpayeur payer_id,
               COL.dtextrait_dt received_dt,
               COL.montant amount,
               COL.devise curr,
               COL.familLe pmethode,
               COL.etat source_status,
               'COL' source_pmt,
               0 isBrokerReleve
          FROM nam_collecte COL
         WHERE etat = 'RCN'
           AND compostage NOT LIKE 'MAN%'
        UNION
        SELECT REL.er_num orig_id,
               to_char( REL.er_dat_dt, NVL( 'DD/MM/RRRR', 'DD/MM/RRRR' ) ) batch,
               REL.er_cli payer_id,
               ENC.dtreception_dt received_dt,
               REL.er_tdb_mvt amount,
               REL.er_devise_mvt curr,
               ENC.moyenpaimt pmethode,
               'DP' source_status,
               'DP' source_pmt,
               0 isBrokerReleve
          FROM f_entrel REL, 
               g_encaissement ENC
         WHERE ENC.refext = 'RQST'
           AND ENC.createur = 'e_releve_rqst'
           AND ENC.lieupaimt = REL.er_num ) P
 WHERE 1 = 1
   AND EXISTS ( SELECT 1
                  FROM g_individu I
                 WHERE I.nom LIKE 'PALFINGER%'
                   AND I.refindividu = P.payer_id )
   AND P.isBrokerReleve = 0
 order by RECEIVED_DT desc;
/********************************New SQL*******************************************/
/********************************New Metrics***************************************/
/*
Plan hash value: 2205690601
---------------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                  | Name                 | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  |
---------------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                           |                      |      1 |        |   223K(100)|     83 |00:00:31.91 |    2532K|   2305K|
|   1 |  SORT ORDER BY                             |                      |      1 |     20 |   223K  (7)|     83 |00:00:31.91 |    2532K|   2305K|
|*  2 |   HASH JOIN                                |                      |      1 |     20 |   223K  (7)|     83 |00:00:31.91 |    2532K|   2305K|
|   3 |    TABLE ACCESS BY INDEX ROWID BATCHED     | G_INDIVIDU           |      1 |     18 |     5   (0)|     18 |00:00:00.01 |      22 |      4 |
|*  4 |     INDEX RANGE SCAN                       | IDX_GIND_NOM_CP_PREN |      1 |      1 |     3   (0)|     18 |00:00:00.01 |       4 |      4 |
|*  5 |    VIEW                                    |                      |      1 |    185K|   223K  (7)|  67924 |00:00:31.90 |    2532K|   2305K|
|   6 |     SORT UNIQUE                            |                      |      1 |    185K|   223K  (7)|  67926 |00:00:31.89 |    2532K|   2305K|
|   7 |      UNION-ALL                             |                      |      1 |        |            |    381K|00:00:31.68 |    2532K|   2305K|
|   8 |       FAST DUAL                            |                      |   1353 |      1 |     2   (0)|   1353 |00:00:00.01 |       0 |      0 |
|*  9 |       HASH JOIN RIGHT ANTI                 |                      |      1 |  61512 | 43060  (16)|   1353 |00:00:30.93 |     818K|    601K|
|  10 |        VIEW                                | VW_SQ_1              |      1 |    115K| 30107  (13)|   5618K|00:00:28.11 |     570K|    353K|
|* 11 |         HASH JOIN                          |                      |      1 |    115K| 30107  (13)|   5618K|00:00:27.62 |     570K|    353K|
|  12 |          TABLE ACCESS STORAGE FULL         | F_DETFAC             |      1 |   6173K| 12274  (10)|   6174K|00:00:01.64 |     353K|    353K|
|  13 |          INDEX STORAGE FAST FULL SCAN      | IDX_FFSI_T_ECRDOS    |      1 |     32M|  7742  (15)|     32M|00:00:03.50 |     216K|      0 |
|* 14 |        TABLE ACCESS STORAGE FULL           | F_ENTREL             |      1 |   6151K| 10275  (23)|   7639 |00:00:00.03 |     248K|    248K|
|* 15 |       HASH JOIN                            |                      |      1 |  60139 | 51226  (13)|    315K|00:00:00.55 |    1419K|   1419K|
|  16 |        JOIN FILTER CREATE                  | :BF0000              |      1 |  60139 | 41141  (14)|    316K|00:00:00.40 |    1135K|   1135K|
|* 17 |         TABLE ACCESS STORAGE FULL          | G_ENCAISSEMENT       |      1 |  60139 | 41141  (14)|    316K|00:00:00.38 |    1135K|   1135K|
|  18 |        JOIN FILTER USE                     | :BF0000              |      1 |   1602K| 10050  (11)|  62835 |00:00:00.05 |     284K|    284K|
|* 19 |         TABLE ACCESS STORAGE FULL          | NAM_COLLECTE         |      1 |   1602K| 10050  (11)|  62835 |00:00:00.04 |     284K|    284K|
|* 20 |       TABLE ACCESS STORAGE FULL            | NAM_COLLECTE         |      1 |  64003 |  9909   (9)|  64003 |00:00:00.06 |     284K|    284K|
|  21 |       NESTED LOOPS                         |                      |      1 |      1 |     6   (0)|      0 |00:00:00.01 |     192 |      0 |
|  22 |        NESTED LOOPS                        |                      |      1 |      1 |     6   (0)|      0 |00:00:00.01 |     192 |      0 |
|* 23 |         TABLE ACCESS BY INDEX ROWID BATCHED| G_ENCAISSEMENT       |      1 |      1 |     4   (0)|    250 |00:00:00.01 |     178 |      0 |
|* 24 |          INDEX RANGE SCAN                  | GENC_REFEXT_IDX      |      1 |      1 |     3   (0)|    387 |00:00:00.01 |       4 |      0 |
|* 25 |         INDEX UNIQUE SCAN                  | ENTREL_CL1           |    250 |      1 |     1   (0)|      0 |00:00:00.01 |      14 |      0 |
|  26 |        TABLE ACCESS BY INDEX ROWID         | F_ENTREL             |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
---------------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   2 - access("I"."REFINDIVIDU"="P"."PAYER_ID")
   4 - access("I"."NOM" LIKE 'PALFINGER%')
       filter("I"."NOM" LIKE 'PALFINGER%')
   5 - filter("P"."ISBROKERRELEVE"=0)
   9 - access("ITEM_1"="ER_NUM" AND "ITEM_2"="ER_CLI")
  11 - access("DF_NUM"="T_ECRDOS"."REFELEM" AND "T_ECRDOS"."CODECR"=UPPER("DF_NOM"))
  14 - storage((NVL("REL"."ER_TCR_MVT",0)>0 AND NVL("REL"."ER_COM",'$')<>'P'))
       filter((NVL("REL"."ER_TCR_MVT",0)>0 AND NVL("REL"."ER_COM",'$')<>'P'))
  15 - access("COMPOSTAGE"="ENCODEUR")
  17 - storage(("ENCODEUR" IS NOT NULL AND INTERNAL_FUNCTION("TYPENCAISS") AND "DTANNUL_DT" IS NULL AND "DTREVENTIL" IS NULL))
       filter(("ENCODEUR" IS NOT NULL AND INTERNAL_FUNCTION("TYPENCAISS") AND "DTANNUL_DT" IS NULL AND "DTREVENTIL" IS NULL))
  19 - storage(("ETAT"='RCI' AND "COMPOSTAGE" NOT LIKE 'MAN%' AND SYS_OP_BLOOM_FILTER(:BF0000,"COMPOSTAGE")))
       filter(("ETAT"='RCI' AND "COMPOSTAGE" NOT LIKE 'MAN%' AND SYS_OP_BLOOM_FILTER(:BF0000,"COMPOSTAGE")))
  20 - storage(("ETAT"='RCN' AND "COMPOSTAGE" NOT LIKE 'MAN%'))
       filter(("ETAT"='RCN' AND "COMPOSTAGE" NOT LIKE 'MAN%'))
  23 - filter(("ENC"."LIEUPAIMT" IS NOT NULL AND "ENC"."CREATEUR"='e_releve_rqst'))
  24 - access("ENC"."REFEXT"='RQST')
  25 - access("ENC"."LIEUPAIMT"="REL"."ER_NUM")

*/
/********************************New Metrics***************************************/

/********************************Index statistics**********************************/

/********************************Other SQLs****************************************/          
/*

*/ 
/********************************Other SQLs****************************************/              
