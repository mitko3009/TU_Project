/********************************************************************************
*********       E-mail subject: IMBWEB-7918
*********             Instance: PROD AD
*********          Description: 
Problem:
This is a client query that was provided for perforamnce optimization.

Analysis:
We tried to execute the provided query, but we found that there are two syntax problems, which doesn't allow us to execute it.
The first problem is that two of the WITHs ( ClientStatement_days_prep and ClientStatement_days_prep_last_year ) are defined twice, which is not allowed in Oracle, so we removed the duplicates.
The second problem is that in the main SELECT it is not specified from which table column imx_case_reference should be selected ( we made it to nrod.imx_case_reference ) as
can be seen in the New SQL section below, but please check is it functional correct.
After we fixed this two syntax problems, we found that the performance problems is that when creating the PortfolioDetails_prep temporary view ( WITH ), Oracle CBO joins the two data sets in the select statement
using Nested Loops, which is not appropriate in cases like this where we have tables like AD_PORTFOLIO_DETAIL which contains ~ 14 million rows. We tried to force the CBO with hints
to make Hash Join, but it looks like the ANSI syntax of the join doesn't allow Oracle to use the hints.
To be able to use the hints and make Hash Join, we rewrite the join from ANSI syntax to the standard Oracle syntax as you can see in the New SQL section below.
Could you please check is it possible to use this syntax in this case?


Suggestion:
Please check is the query in the New SQLs ection functionally OK from your point of view and if it is, please change the query as it is shown in the New SQL section below.

*********               SQL_ID: 7juntmzdz8rqx
*********      Program/Package: 
*********              Request: Dimitare Ivanov
*********               Author: Dimitar Dimitrov
********* Received e-mail date: 01/07/2024
*********      Resolution date: 16/07/2024
*********  Trace old file here: \\epox\specifs\performance\tmp\
*********  Trace new file here:
***********************************************************************************/

/********************************OLD SQL*******************************************/

var p_date varchar2(32);
exec :p_date = '2024/04/05';


WITH ReportPeriod AS
 (SELECT trunc(to_date(:p_date, 'yyyy/mm/dd'), 'iw') - 7 Start_Date,
         trunc(to_date(:p_date, 'yyyy/mm/dd'), 'iw') - 1 / 86400 End_Date,
         to_char(trunc(to_date(:p_date, 'yyyy/mm/dd'), 'iw') - 7, 'j') Start_Date_j,
         to_char(trunc(to_date(:p_date, 'yyyy/mm/dd'), 'iw') - 1 / 86400, 'j') End_Date_j,
         to_char(to_date(:p_date, 'yyyy/mm/dd') - 7, 'iyyy-iw') Report_Period,
         to_char(to_date(:p_date, 'yyyy/mm/dd') - 7, 'iyyy') cal_year,
         to_char(to_date(:p_date, 'yyyy/mm/dd') - 7, 'iw') cal_week,
         trunc(ADD_MONTHS(to_date(:p_date, 'yyyy/mm/dd') - 7, -1), 'mm') last_month_start_date,
         LAST_DAY(trunc(ADD_MONTHS(to_date(:p_date, 'yyyy/mm/dd') - 7, -1), 'mm')) last_month_end_date,
         to_char(LAST_DAY(trunc(ADD_MONTHS(to_date(:p_date, 'yyyy/mm/dd') - 7, -1), 'mm')), 'j') last_month_end_date_j,
         trunc(ADD_MONTHS(to_date(:p_date, 'yyyy/mm/dd') - 7, -6), 'mm') last_6_month_start_date,
         trunc(ADD_MONTHS(to_date(:p_date, 'yyyy/mm/dd') - 7, -3), 'mm') last_3_month_start_date,
         to_char(trunc(ADD_MONTHS(to_date(:p_date, 'yyyy/mm/dd') - 7, -3), 'mm'), 'j') last_3_month_start_date_j,
         trunc(ADD_MONTHS(to_date(:p_date, 'yyyy/mm/dd') - 7, -12), 'mm') last_12_month_start_date,
         trunc(ADD_MONTHS(ADD_MONTHS(to_date(:p_date, 'yyyy/mm/dd') - 7, -3), -12), 'mm') last_3_month_last_year_start_date,
         to_char(trunc(ADD_MONTHS(ADD_MONTHS(to_date(:p_date, 'yyyy/mm/dd') - 7, -3), -12), 'mm'),'j') last_3_month_last_year_start_date_j,
         to_char(LAST_DAY(trunc(ADD_MONTHS(ADD_MONTHS(to_date(:p_date, 'yyyy/mm/dd') - 7, -1), -12),'mm')),'j') last_month_last_year_end_date_j,
         LAST_DAY(trunc(ADD_MONTHS(ADD_MONTHS(to_date(:p_date, 'yyyy/mm/dd') - 7, -1), -12), 'mm')) last_month_last_year_end_date
    FROM dual),
ReportPeriod_old AS
 (SELECT trunc(ADD_MONTHS(ADD_MONTHS(trunc(SYSDATE, 'mm'), -1), -11)) Start_Date,
         trunc(ADD_MONTHS(ADD_MONTHS(trunc(SYSDATE, 'mm'), -1), -25)) Start_Date_2,
         trunc(LAST_DAY(ADD_MONTHS(trunc(SYSDATE, 'mm'), -1))) End_Date,
         to_char(trunc(ADD_MONTHS(ADD_MONTHS(trunc(SYSDATE, 'mm'), -1), -11)),'yyyymm') Start_month,
         to_char(trunc(ADD_MONTHS(ADD_MONTHS(trunc(SYSDATE, 'mm'), -1), -11)),'J') Start_date_Julian
    FROM dual)
/*SELECT * FROM ReportPeriod*/
,
all_days_last_3_month_current_year AS
 (SELECT last_3_month_start_date,
         last_3_month_start_date_j,
         last_month_end_date,
         to_date(last_3_month_start_date_j + LEVEL - 1, 'J') AS day_of_month,
         to_char(to_date(last_3_month_start_date_j + LEVEL - 1, 'J'), 'J') AS day_of_month_j,
         to_char(to_date(last_3_month_start_date_j + LEVEL - 1, 'J'),
                 'yyyymm') MONTH,
         trunc(to_date(last_3_month_start_date_j + LEVEL - 1, 'J'), 'mm') first_calendar, -- des jeweiligen monats
         to_char(trunc(to_date(last_3_month_start_date_j + LEVEL - 1, 'J'),
                       'mm'),
                 'J') first_calendar_j -- des jeweiligen monats
    FROM ReportPeriod rp
  CONNECT BY last_3_month_start_date_j + LEVEL - 1 <=
             rp.last_month_end_date_j
   ORDER BY 1),
all_days_last_3_month_last_year AS
 (SELECT last_3_month_last_year_start_date,
         last_3_month_last_year_start_date_j,
         last_month_last_year_end_date,
         to_date(last_3_month_last_year_start_date_j + LEVEL - 1, 'J') AS day_of_month,
         to_char(to_date(last_3_month_last_year_start_date_j + LEVEL - 1,
                         'J'),
                 'J') AS day_of_month_j,
         to_char(to_date(last_3_month_last_year_start_date_j + LEVEL - 1,
                         'J'),
                 'yyyymm') MONTH,
         trunc(to_date(last_3_month_last_year_start_date_j + LEVEL - 1, 'J'),
               'mm') first_calendar,
         to_char(trunc(to_date(last_3_month_last_year_start_date_j + LEVEL - 1,
                               'J'),
                       'mm'),
                 'J') first_calendar_j
    FROM ReportPeriod rp
  CONNECT BY last_3_month_last_year_start_date_j + LEVEL - 1 <=
             rp.last_month_last_year_end_date_j
   ORDER BY 1)
/*SELECT * FROM all_days_last_3_month_last_year

*/
,
period_list_subcontract AS
 (SELECT rp.*,
         cla.CONTRACT_NUMBER,
         cla.REFLOT          AS iMX_Contract_Reference,
         cla.REFDOSS         AS iMX_Case_Reference,
         cla.DEVISE          AS currency,
         cla.CLIENT          AS iMX_Client_Reference,
         GP_FG06,
         contract_type,
         cl_nom              AS client_name,
         CLIENT_MANAGER_NOM,
         ACCOUNT_MANAGER_NOM,
         TEAM_ASSISTANT_NAME,
         MAXFIU
    FROM ReportPeriod rp, AD_ACCOUNT_CLIENT_MVIEW cla
   INNER JOIN AD_CASE_CONTRAT c
      ON c.ANCREFDOSS = cla.CONTRACT_NUMBER
  --  WHERE cla.CONTRACT_NUMBER = :p_contract_number
  --  AND c.ANCREFDOSS = :p_contract_number
  )
--SELECT * FROM period_list_subcontract
,
contract_status AS
 (SELECT /*+no_merge no_push_pred LEADING(p) INDEX(p G_PIECE_TYPE_REFPIECE_INX) INDEX(PD GPDET_TYP_REF_IDX) USE_NL(PD) FULL(last_stus) USE_HASH(last_stus)*/
  --              last_stus.status as status,
  --            last_stus.rn,
   P.refpiece   as refpiece,
   P.refdoss    AS iMX_Case_Reference,
   vd.valeur_an AS status
  --              pd.*
    FROM period_list_subcontract status
    LEFT JOIN g_piecedet PD
      ON pd.refdoss = status.iMX_Case_Reference
    left join v_domaine vd
      ON pd.str1 = vd.abrev
     and vd.type = 'CONRSIT',
   (select /*+LEADING(a) INDEX(a GPDET_TYP_REF_IDX) INDEX(b V_DOMAINE_IND) USE_NL(b)*/
           a.str1 AS status,
           a.refpiece as refpiece,
           ROW_NUMBER() OVER(PARTITION BY a.refpiece ORDER BY imx_un_id DESC) AS rn
            from period_list_subcontract status
            LEFT JOIN g_piecedet a
              ON a.refdoss = status.iMX_Case_Reference
           where a.type = 'CONTRACT SITUATIONS') last_stus, g_piece p
   WHERE p.typpiece = 'SOUS-CONTRAT'
     AND PD.refpiece = P.refpiece
     AND PD.type = 'CONTRACT SITUATIONS'
        --      AND PD.STR1 in ('V','P')
     AND last_stus.refpiece = P.refpiece
     AND last_stus.rn = 1
     AND pd.str1 = last_stus.status
  --    AND p.refdoss = :p_case
  ),
FinancingRateLastRec AS
 (SELECT pd.REFDOSS, MAX(pd.IMX_UN_ID) AS UN_ID
    FROM AD_ACCOUNT_CLIENT_MVIEW cla
    LEFT JOIN G_PIECEDET pd
      ON pd.refdoss = cla.refdoss
   WHERE pd.TYPE = 'FINRATE'
     AND pd.STR2 = 'PDEF'
     AND pd.DW_ACTION <> 'D'
   GROUP BY pd.REFDOSS),
FinancingRate AS
 (SELECT pd.REFDOSS, pd.MT01 Financing_rate
    FROM G_PIECEDET pd
   INNER JOIN FinancingRateLastRec frlr
      ON frlr.un_id = pd.IMX_UN_ID
   WHERE pd.TYPE = 'FINRATE'
     AND pd.STR2 = 'PDEF'
  --  AND pd.refdoss = '0001010044' -- 0001010265 0001010468
  ),
TypeList AS
 (SELECT a.ListType, a.ListArea, b.ListMult
    FROM (SELECT objectschema ListType, objectname ListArea
            FROM TABLE(sys.ODCIObjectList(sys.odciobject('CANCELLED PAYMENT',
                                                         'PAYMENT'),
                                          sys.odciobject('DEBTOR PAYMENT',
                                                         'PAYMENT'),
                                          sys.odciobject('DEBTOR REIMBURSEMENT',
                                                         'PAYMENT'),
                                          sys.odciobject('DEDUCTION',
                                                         'ADJUSTMENT'),
                                          sys.odciobject('FACTURE', 'INVOICE'),
                                          sys.odciobject('FACTURE CANCEL.',
                                                         'ADJUSTMENT'),
                                          sys.odciobject('NOTE DE CREDIT',
                                                         'CREDIT NOTE'),
                                          sys.odciobject('NOTE DE CREDIT CANCEL.',
                                                         'ADJUSTMENT'),
                                          sys.odciobject('OTHER DEBIT (SAF)',
                                                         'OTHER DEBIT'),
                                          sys.odciobject('RETROCESSION',
                                                         'ADJUSTMENT'),
                                          sys.odciobject('RETROCESSION NC',
                                                         'ADJUSTMENT'),
                                          sys.odciobject('UNDO ALLOCATION',
                                                         'PAYMENT'),
                                          sys.odciobject('UNDO DEDUCTION',
                                                         'ADJUSTMENT')))) a
    JOIN (SELECT objectschema ListType, objectname ListMult
           FROM TABLE(sys.ODCIObjectList(sys.odciobject('CANCELLED PAYMENT',
                                                        -1),
                                         sys.odciobject('DEBTOR PAYMENT', -1),
                                         sys.odciobject('DEBTOR REIMBURSEMENT',
                                                        -1),
                                         sys.odciobject('DEDUCTION', -1),
                                         sys.odciobject('FACTURE', 1),
                                         sys.odciobject('FACTURE CANCEL.', -1),
                                         sys.odciobject('NOTE DE CREDIT', -1),
                                         sys.odciobject('NOTE DE CREDIT CANCEL.',
                                                        -1),
                                         sys.odciobject('OTHER DEBIT (SAF)',
                                                        1),
                                         sys.odciobject('RETROCESSION', -1),
                                         sys.odciobject('RETROCESSION NC', -1),
                                         sys.odciobject('UNDO ALLOCATION', -1),
                                         sys.odciobject('UNDO DEDUCTION', -1)))) b
      ON b.ListType = a.ListType),
ClientAccount AS
 (SELECT cla.FACTOR          iMX_Business_Unit,
         cla.REFDOSS         iMX_Case_Reference, -- Client Account
         cla.REFLOT          iMX_Contract_Reference, -- Contract
         cla.CONTRACT_NUMBER Contract_Number, -- Contract
         cla.DEVISE          Contract_Currency,
         cla.CLIENT          iMX_Client_Reference,
         cla.REFDOSSEXT      Subcontract_Number
    FROM AD_ACCOUNT_CLIENT_MVIEW cla
  --  WHERE cla.CONTRACT_NUMBER = :p_contract_number
  ),
ClientStatementDate AS -- Das letztverfügbare Statement für den Case ermitteln
 (SELECT clst.CONTRACT_CASE iMX_Contract_Reference,
         clst.CL_ACCOUNT_CASE iMX_Case_Reference,
         MAX(clst.DATE_ID) Statement_Date
    FROM AD_CLIENT_STATEMENT_HISTORY clst, ReportPeriod rp
   WHERE clst.MEMO_SOURCE = 'A'
     AND clst.DATE_ID BETWEEN TRUNC(rp.Start_Date_j) AND
         TRUNC(rp.End_Date_j)
  --    AND clst.CL_ACCOUNT_CASE = :p_case
   GROUP BY clst.CONTRACT_CASE, clst.CL_ACCOUNT_CASE),
ClientStatementDate_week_bevore AS -- Das letztverfügbare Statement für den Case ermitteln
 (SELECT clst.CONTRACT_CASE iMX_Contract_Reference,
         clst.CL_ACCOUNT_CASE iMX_Case_Reference,
         MAX(clst.DATE_ID) Statement_Date
    FROM AD_CLIENT_STATEMENT_HISTORY clst, ReportPeriod rp
   WHERE clst.MEMO_SOURCE = 'A'
     AND clst.DATE_ID BETWEEN TRUNC(rp.Start_Date_j - 7) AND
         TRUNC(rp.End_Date_j - 7)
   GROUP BY clst.CONTRACT_CASE, clst.CL_ACCOUNT_CASE),
ClientStatementDate_current AS -- Das letztverfügbare Statement für den Case ermitteln
 (SELECT clst.CONTRACT_CASE iMX_Contract_Reference,
         clst.CL_ACCOUNT_CASE iMX_Case_Reference,
         MAX(clst.DATE_ID) Statement_Date
    FROM AD_CLIENT_STATEMENT_HISTORY clst, ReportPeriod rp
   WHERE clst.MEMO_SOURCE = 'A'
     AND clst.DATE_ID <= TRUNC(rp.End_Date_j)
   GROUP BY clst.CONTRACT_CASE, clst.CL_ACCOUNT_CASE),
ClientStatement AS
 (
  -- 16.1.2023 am 31.12.2022: Rückwirkend da am 16.1. gestartet wurde --> der Satz muss weg
  -- Sind größteils nuller Sätze
  SELECT clst.CONTRACT_NUMBER,
          clst.CONTRACT_CASE iMX_Contract_Reference,
          clst.CL_ACCOUNT_CASE iMX_Case_Reference,
          to_date(clst.DATE_ID, 'j') datum,
          clst.date_id,
          (clst.FINANCING_BASE_EUR) Financing_Base,
          (clst.RETENTIONS_EUR) Retentions_eur,
          (clst.RETENTIONS) Retentions,
          -- clst.CURRENCY            Currency,
          (clst.BLOCKED_AMOUNT_EUR) Blocked_Amount_eur,
          (clst.BLOCKED_AMOUNT) Blocked_Amount,
          (clst.FUNDABLE_AMOUNT_EUR) Fundable_Amount,
          (clst.FIU) FIU,
          (clst.FIU_EUR) FIU_EUR,
          (clst.AVAILABILITY_EUR) Availability,
          (clst.NON_MATCHED_PAYMENTS_EUR) NonMatchedPayments,
          (clst.PORTFOLIO) Portfolio,
          (clst.PORTFOLIO_EUR) Portfolio_eur
    FROM AD_CLIENT_STATEMENT_HIST_VIEW clst, ClientStatementDate stmtd
   WHERE MEMO_SOURCE = 'A' -- A=Täglich; E=EOM
        --    AND CL_ACCOUNT_CASE = :p_case
     AND clst.CONTRACT_CASE = stmtd.iMX_Contract_Reference
     AND clst.CL_ACCOUNT_CASE = stmtd.iMX_Case_Reference
     AND clst.DATE_ID = stmtd.Statement_Date
  --GROUP BY 
  --  clst.CONTRACT_NUMBER, clst.CONTRACT_CASE, clst.CL_ACCOUNT_CASE
  ),
ClientStatement_current AS
 (
  -- 16.1.2023 am 31.12.2022: Rückwirkend da am 16.1. gestartet wurde --> der Satz muss weg
  -- Sind größteils nuller Sätze
  SELECT clst.CONTRACT_NUMBER,
          clst.CONTRACT_CASE iMX_Contract_Reference,
          clst.CL_ACCOUNT_CASE iMX_Case_Reference,
          (clst.FINANCING_BASE_EUR) Financing_Base,
          (clst.RETENTIONS_EUR) Retentions_eur,
          (clst.RETENTIONS) Retentions,
          -- clst.CURRENCY            Currency,
          (clst.BLOCKED_AMOUNT_EUR) Blocked_Amount_eur,
          (clst.BLOCKED_AMOUNT) Blocked_Amount,
          (clst.FUNDABLE_AMOUNT_EUR) Fundable_Amount,
          (clst.FIU) FIU,
          (clst.FIU_EUR) FIU_EUR,
          (clst.AVAILABILITY) Availability,
          (clst.AVAILABILITY_EUR) Availability_eur,
          (clst.NON_MATCHED_PAYMENTS_EUR) NonMatchedPayments,
          (clst.PORTFOLIO) Portfolio,
          (clst.PORTFOLIO_EUR) Portfolio_eur
    FROM AD_CLIENT_STATEMENT_HIST_VIEW clst,
          ClientStatementDate_current   stmtd
   WHERE MEMO_SOURCE = 'A' -- A=Täglich; E=EOM
     AND clst.CONTRACT_CASE = stmtd.iMX_Contract_Reference
     AND clst.CL_ACCOUNT_CASE = stmtd.iMX_Case_Reference
     AND clst.DATE_ID = stmtd.Statement_Date
  --GROUP BY 
  --  clst.CONTRACT_NUMBER, clst.CONTRACT_CASE, clst.CL_ACCOUNT_CASE
  ),
ClientStatement_week_bevore AS
 (
  -- 16.1.2023 am 31.12.2022: Rückwirkend da am 16.1. gestartet wurde --> der Satz muss weg
  -- Sind größteils nuller Sätze
  SELECT clst.CONTRACT_NUMBER,
          clst.CONTRACT_CASE iMX_Contract_Reference,
          clst.CL_ACCOUNT_CASE iMX_Case_Reference,
          (clst.FINANCING_BASE_EUR) Financing_Base,
          (clst.RETENTIONS_EUR) Retentions_eur,
          (clst.RETENTIONS) Retentions,
          -- clst.CURRENCY            Currency,
          (clst.BLOCKED_AMOUNT_EUR) Blocked_Amount_eur,
          (clst.BLOCKED_AMOUNT) Blocked_Amount,
          (clst.FUNDABLE_AMOUNT_EUR) Fundable_Amount,
          (clst.FIU) FIU,
          (clst.FIU_EUR) FIU_EUR,
          (clst.AVAILABILITY_EUR) Availability,
          (clst.NON_MATCHED_PAYMENTS_EUR) NonMatchedPayments,
          (clst.PORTFOLIO) Portfolio,
          (clst.PORTFOLIO_EUR) Portfolio_eur
    FROM AD_CLIENT_STATEMENT_HIST_VIEW   clst,
          ClientStatementDate_week_bevore stmtd
   WHERE MEMO_SOURCE = 'A' -- A=Täglich; E=EOM
     AND clst.CONTRACT_CASE = stmtd.iMX_Contract_Reference
     AND clst.CL_ACCOUNT_CASE = stmtd.iMX_Case_Reference
     AND clst.DATE_ID = stmtd.Statement_Date
  --GROUP BY 
  --  clst.CONTRACT_NUMBER, clst.CONTRACT_CASE, clst.CL_ACCOUNT_CASE
  ),
ClientStatement_days AS
 (SELECT days.last_3_month_start_date   AS start_date,
         days.last_3_month_start_date_j AS start_date_j,
         days.day_of_month,
         days.day_of_month_j,
         ca.CONTRACT_NUMBER,
         ca.iMX_Contract_Reference, -- Contract
         ca.iMX_Case_Reference -- Client Account
    FROM all_days_last_3_month_current_year days, ClientAccount ca),
ClientStatement_days_last_year AS
 (SELECT days.last_3_month_last_year_start_date   AS start_date,
         days.last_3_month_last_year_start_date_j AS start_date_j,
         days.day_of_month,
         days.day_of_month_j,
         ca.CONTRACT_NUMBER,
         ca.iMX_Contract_Reference, -- Contract
         ca.iMX_Case_Reference -- Client Account
    FROM all_days_last_3_month_last_year days, ClientAccount ca),
ClientStatement_days_prep AS
 (SELECT days.START_date,
         days.START_date_j,
         days.day_of_month,
         days.day_of_month_j,
         days.CONTRACT_NUMBER,
         days.iMX_Contract_Reference,
         days.iMX_Case_Reference,
         clst.DATE_ID,
         fiu,
         FUNDABLE_AMOUNT,
         PORTFOLIO,
         RETENTIONS,
         fiu_EUR,
         FUNDABLE_AMOUNT_EUR,
         PORTFOLIO_EUR,
         RETENTIONS_EUR
    FROM ClientStatement_days days
    LEFT JOIN AD_CLIENT_STATEMENT_HIST_VIEW clst
      ON clst.CONTRACT_NUMBER = days.CONTRACT_NUMBER
     AND clst.CONTRACT_CASE = days.iMX_Contract_Reference
     AND clst.CL_ACCOUNT_CASE = days.iMX_Case_Reference
     and clst.DATE_ID = days.day_of_month_j
     AND clst.MEMO_SOURCE = 'A' -- (=Not EOM)
  ),
ClientStatement_days_prep_last_year AS
 (SELECT days.START_date,
         days.START_date_j,
         days.day_of_month,
         days.day_of_month_j,
         days.CONTRACT_NUMBER,
         days.iMX_Contract_Reference,
         days.iMX_Case_Reference,
         clst.DATE_ID,
         fiu,
         FUNDABLE_AMOUNT,
         PORTFOLIO,
         RETENTIONS,
         fiu_EUR,
         FUNDABLE_AMOUNT_EUR,
         PORTFOLIO_EUR,
         RETENTIONS_EUR
    FROM ClientStatement_days_last_year days
    LEFT JOIN AD_CLIENT_STATEMENT_HIST_VIEW clst
      ON clst.CONTRACT_NUMBER = days.CONTRACT_NUMBER
     AND clst.CONTRACT_CASE = days.iMX_Contract_Reference
     AND clst.CL_ACCOUNT_CASE = days.iMX_Case_Reference
     and clst.DATE_ID = days.day_of_month_j
     AND clst.MEMO_SOURCE = 'A' -- (=Not EOM)
  ),
ClientStatement_days_prep AS
 (SELECT days.START_date,
         days.START_date_j,
         days.day_of_month,
         days.day_of_month_j,
         days.CONTRACT_NUMBER,
         days.iMX_Contract_Reference,
         days.iMX_Case_Reference,
         clst.DATE_ID,
         fiu,
         FUNDABLE_AMOUNT,
         PORTFOLIO,
         RETENTIONS,
         fiu_EUR,
         FUNDABLE_AMOUNT_EUR,
         PORTFOLIO_EUR,
         RETENTIONS_EUR
    FROM ClientStatement_days days
    LEFT JOIN AD_CLIENT_STATEMENT_HIST_VIEW clst
      ON clst.CONTRACT_NUMBER = days.CONTRACT_NUMBER
     AND clst.CONTRACT_CASE = days.iMX_Contract_Reference
     AND clst.CL_ACCOUNT_CASE = days.iMX_Case_Reference
     and clst.DATE_ID = days.day_of_month_j
     AND clst.MEMO_SOURCE = 'A' -- (=Not EOM)
  ),
ClientStatement_days_prep_last_year AS
 (SELECT days.START_date,
         days.START_date_j,
         days.day_of_month,
         days.day_of_month_j,
         days.CONTRACT_NUMBER,
         days.iMX_Contract_Reference,
         days.iMX_Case_Reference,
         clst.DATE_ID,
         fiu,
         FUNDABLE_AMOUNT,
         PORTFOLIO,
         RETENTIONS,
         fiu_EUR,
         FUNDABLE_AMOUNT_EUR,
         PORTFOLIO_EUR,
         RETENTIONS_EUR
    FROM ClientStatement_days_last_year days
    LEFT JOIN AD_CLIENT_STATEMENT_HIST_VIEW clst
      ON clst.CONTRACT_NUMBER = days.CONTRACT_NUMBER
     AND clst.CONTRACT_CASE = days.iMX_Contract_Reference
     AND clst.CL_ACCOUNT_CASE = days.iMX_Case_Reference
     and clst.DATE_ID = days.day_of_month_j
     AND clst.MEMO_SOURCE = 'A' -- (=Not EOM)
  ),
ClientStatement_days_previous_prep AS
 (SELECT days.start_date,
         days.start_date_j,
         days.day_of_month,
         days.day_of_month_j,
         days.CONTRACT_NUMBER,
         days.iMX_Contract_Reference,
         days.iMX_Case_Reference,
         max(clst.DATE_ID) AS previous_statement_date
    FROM ClientStatement_days_prep days
    LEFT JOIN AD_CLIENT_STATEMENT_HIST_VIEW clst
      ON clst.CONTRACT_NUMBER = days.CONTRACT_NUMBER
     AND clst.CONTRACT_CASE = days.iMX_Contract_Reference
     AND clst.CL_ACCOUNT_CASE = days.iMX_Case_Reference
     AND clst.DATE_ID <= days.day_of_month_j
     AND clst.date_id >= days.start_date_j
     AND trunc(clst.dt04_dt) >= to_date('2022-09-01', 'yyyy-mm-dd')
     AND clst.MEMO_SOURCE = 'A' -- (=Not EOM)
   WHERE days.date_id IS NULL
   GROUP BY days.start_date,
            days.start_date_j,
            days.day_of_month,
            days.day_of_month_j,
            days.CONTRACT_NUMBER,
            days.iMX_Contract_Reference,
            days.iMX_Case_Reference),
ClientStatement_days_previous_prep_last_year AS
 (SELECT days.start_date,
         days.start_date_j,
         days.day_of_month,
         days.day_of_month_j,
         days.CONTRACT_NUMBER,
         days.iMX_Contract_Reference,
         days.iMX_Case_Reference,
         max(clst.DATE_ID) AS previous_statement_date
    FROM ClientStatement_days_prep_last_year days
    LEFT JOIN AD_CLIENT_STATEMENT_HIST_VIEW clst
      ON clst.CONTRACT_NUMBER = days.CONTRACT_NUMBER
     AND clst.CONTRACT_CASE = days.iMX_Contract_Reference
     AND clst.CL_ACCOUNT_CASE = days.iMX_Case_Reference
     AND clst.DATE_ID <= days.day_of_month_j
     AND clst.date_id >= days.start_date_j
     AND trunc(clst.dt04_dt) >= to_date('2022-09-01', 'yyyy-mm-dd')
     AND clst.MEMO_SOURCE = 'A' -- (=Not EOM)
   WHERE days.date_id IS NULL
   GROUP BY days.start_date,
            days.start_date_j,
            days.day_of_month,
            days.day_of_month_j,
            days.CONTRACT_NUMBER,
            days.iMX_Contract_Reference,
            days.iMX_Case_Reference),
ClientStatement_days_previous AS
 (SELECT days.start_date,
         days.start_date_j,
         days.day_of_month,
         days.day_of_month_j,
         days.CONTRACT_NUMBER,
         days.iMX_Contract_Reference,
         days.iMX_Case_Reference,
         clst.DATE_ID,
         fiu,
         FUNDABLE_AMOUNT,
         PORTFOLIO,
         RETENTIONS,
         fiu_EUR,
         FUNDABLE_AMOUNT_EUR,
         PORTFOLIO_EUR,
         RETENTIONS_EUR
    FROM ClientStatement_days_previous_prep days
    LEFT JOIN AD_CLIENT_STATEMENT_HIST_VIEW clst
      ON clst.CONTRACT_NUMBER = days.CONTRACT_NUMBER
     AND clst.CONTRACT_CASE = days.iMX_Contract_Reference
     AND clst.CL_ACCOUNT_CASE = days.iMX_Case_Reference
     AND clst.DATE_ID = days.previous_statement_date
     AND clst.MEMO_SOURCE = 'A'),
ClientStatement_days_previous_last_year AS
 (SELECT days.start_date,
         days.start_date_j,
         days.day_of_month,
         days.day_of_month_j,
         days.CONTRACT_NUMBER,
         days.iMX_Contract_Reference,
         days.iMX_Case_Reference,
         clst.DATE_ID,
         fiu,
         FUNDABLE_AMOUNT,
         PORTFOLIO,
         RETENTIONS,
         fiu_EUR,
         FUNDABLE_AMOUNT_EUR,
         PORTFOLIO_EUR,
         RETENTIONS_EUR
    FROM ClientStatement_days_previous_prep_last_year days
    LEFT JOIN AD_CLIENT_STATEMENT_HIST_VIEW clst
      ON clst.CONTRACT_NUMBER = days.CONTRACT_NUMBER
     AND clst.CONTRACT_CASE = days.iMX_Contract_Reference
     AND clst.CL_ACCOUNT_CASE = days.iMX_Case_Reference
     AND clst.DATE_ID = days.previous_statement_date
     AND clst.MEMO_SOURCE = 'A'),
ClientStatement_all_days AS
 (SELECT *
    FROM ClientStatement_days_prep
   WHERE date_id IS NOT NULL
  UNION ALL
  SELECT *
    FROM ClientStatement_days_previous),
ClientStatement_all_days_last_year AS
 (SELECT *
    FROM ClientStatement_days_prep_last_year
   WHERE date_id IS NOT NULL
  UNION ALL
  SELECT *
    FROM ClientStatement_days_previous_last_year),
ClientStatement_avg_until_begin AS
 (SELECT max(clst.day_of_month_j) - min(clst.start_date_j) days_from_begin,
         min(clst.day_of_month) start_date,
         max(clst.day_of_month) end_date,
         clst.iMX_Contract_Reference,
         clst.iMX_Case_Reference,
         avg(clst.FIU) FIU,
         avg(clst.FUNDABLE_AMOUNT) FUNDABLE_AMOUNT,
         avg(clst.PORTFOLIO) PORTFOLIO,
         avg(clst.FIU_EUR) FIU_EUR,
         avg(clst.FUNDABLE_AMOUNT_EUR) FUNDABLE_AMOUNT_EUR,
         avg(clst.PORTFOLIO_EUR) PORTFOLIO_EUR
    FROM ClientStatement_all_days clst
   WHERE clst.fiu IS NOT NULL
   GROUP BY clst.iMX_Contract_Reference, clst.iMX_Case_Reference),
ClientStatement_avg_until_begin_last_year AS
 (SELECT max(clst.day_of_month_j) - min(clst.start_date_j) days_from_begin,
         min(clst.day_of_month) start_date,
         max(clst.day_of_month) end_date,
         clst.iMX_Contract_Reference,
         clst.iMX_Case_Reference,
         avg(clst.FIU) FIU,
         avg(clst.FUNDABLE_AMOUNT) FUNDABLE_AMOUNT,
         avg(clst.PORTFOLIO) PORTFOLIO,
         avg(clst.FIU_EUR) FIU_EUR,
         avg(clst.FUNDABLE_AMOUNT_EUR) FUNDABLE_AMOUNT_EUR,
         avg(clst.PORTFOLIO_EUR) PORTFOLIO_EUR
    FROM ClientStatement_all_days_last_year clst
   WHERE clst.fiu IS NOT NULL
   GROUP BY clst.iMX_Contract_Reference, clst.iMX_Case_Reference),
PortfolioDetails_prep AS
 (SELECT pl.contract_number,
         pl.imx_contract_reference,
         pl.imx_case_reference,
         tl.ListArea,
         --    pd.AMOUNT_CPT * tl.ListMult ListSum, -- AMOUNT_ACCY --> IN BU Currency (â‚¬)
         CASE
           WHEN (trunc(pd.TECR_DTJOUR_DT) BETWEEN pl.Start_Date AND
                pl.End_Date) THEN
            CH_TAUX.CONV_ORIG_DEST_TX(to_char(sysdate, 'J'),
                                      pd.AMOUNT_CPT * tl.ListMult,
                                      pl.Currency,
                                      'EUR',
                                      'MR',
                                      NULL)
         END AS last_week_ListSum_EUR,
         CASE
           WHEN (trunc(pd.TECR_DTJOUR_DT) BETWEEN pl.last_12_month_start_date AND
                pl.last_month_end_date) THEN
            CH_TAUX.CONV_ORIG_DEST_TX(to_char(sysdate, 'J'),
                                      pd.AMOUNT_CPT * tl.ListMult,
                                      pl.Currency,
                                      'EUR',
                                      'MR',
                                      NULL)
         END AS last_12_month_ListSum_EUR,
         CASE
           WHEN (trunc(pd.TECR_DTJOUR_DT) BETWEEN pl.last_6_month_start_date AND
                pl.last_month_end_date) THEN
            CH_TAUX.CONV_ORIG_DEST_TX(to_char(sysdate, 'J'),
                                      pd.AMOUNT_CPT * tl.ListMult,
                                      pl.Currency,
                                      'EUR',
                                      'MR',
                                      NULL)
         END AS last_6_month_ListSum_EUR,
         CASE
           WHEN (trunc(pd.TECR_DTJOUR_DT) BETWEEN pl.last_month_start_date AND
                pl.last_month_end_date) THEN
            CH_TAUX.CONV_ORIG_DEST_TX(to_char(sysdate, 'J'),
                                      pd.AMOUNT_CPT * tl.ListMult,
                                      pl.Currency,
                                      'EUR',
                                      'MR',
                                      NULL)
         END AS last_month_ListSum_EUR,
         CASE
           WHEN (trunc(pd.TECR_DTJOUR_DT) BETWEEN pl.last_3_month_start_date AND
                pl.last_month_end_date) THEN
            CH_TAUX.CONV_ORIG_DEST_TX(to_char(sysdate, 'J'),
                                      pd.AMOUNT_CPT * tl.ListMult,
                                      pl.Currency,
                                      'EUR',
                                      'MR',
                                      NULL)
         END AS last_3_month_ListSum_eur,
         CASE
           WHEN (trunc(pd.TECR_DTJOUR_DT) BETWEEN
                pl.last_3_month_last_year_start_date AND
                pl.last_month_last_year_end_date) THEN
            CH_TAUX.CONV_ORIG_DEST_TX(to_char(sysdate, 'J'),
                                      pd.AMOUNT_CPT * tl.ListMult,
                                      pl.Currency,
                                      'EUR',
                                      'MR',
                                      NULL)
         END AS last_3_month_last_year_ListSum_eur,
         --
         CASE
           WHEN (trunc(pd.TECR_DTJOUR_DT) BETWEEN pl.Start_Date AND
                pl.End_Date) THEN
            pd.AMOUNT_CPT * tl.ListMult
         END AS last_week_ListSum,
         CASE
           WHEN (trunc(pd.TECR_DTJOUR_DT) BETWEEN pl.last_12_month_start_date AND
                pl.last_month_end_date) THEN
            pd.AMOUNT_CPT * tl.ListMult
         END AS last_12_month_ListSum,
         CASE
           WHEN (trunc(pd.TECR_DTJOUR_DT) BETWEEN pl.last_6_month_start_date AND
                pl.last_month_end_date) THEN
            pd.AMOUNT_CPT * tl.ListMult
         END AS last_6_month_ListSum,
         CASE
           WHEN (trunc(pd.TECR_DTJOUR_DT) BETWEEN pl.last_3_month_start_date AND
                pl.last_month_end_date) THEN
            pd.AMOUNT_CPT * tl.ListMult
         END AS last_3_month_ListSum,
         CASE
           WHEN (trunc(pd.TECR_DTJOUR_DT) BETWEEN
                pl.last_3_month_last_year_start_date AND
                pl.last_month_last_year_end_date) THEN
            pd.AMOUNT_CPT * tl.ListMult
         END AS last_3_month_last_year_ListSum,
         CASE
           WHEN (trunc(pd.TECR_DTJOUR_DT) BETWEEN pl.last_month_start_date AND
                pl.last_month_end_date) THEN
            pd.AMOUNT_CPT * tl.ListMult
         END AS last_month_ListSum
  --    tl.ListMult
    FROM period_list_subcontract pl
    LEFT JOIN AD_PORTFOLIO_DETAIL pd
      ON pd.SUBCONTRACT_CASE = pl.imx_case_reference
     AND ((trunc(pd.TECR_DTJOUR_DT) >= pl.last_3_month_last_year_start_date AND
         trunc(pd.TECR_DTJOUR_DT) <= pl.last_month_end_date) OR
         (trunc(pd.TECR_DTJOUR_DT) >= pl.Start_Date AND
         trunc(pd.TECR_DTJOUR_DT) <= pl.End_Date))
    LEFT JOIN TypeList tl
      ON tl.ListType = pd."TYPE"
   WHERE tl.ListArea <> '?'),
PortfolioDetails AS
 (SELECT pfd.iMX_Contract_Reference,
         pfd.iMX_Case_Reference, -- Client Account
         pfd.ListArea,
         last_week_ListSum_EUR,
         last_12_month_ListSum_EUR,
         last_6_month_ListSum_EUR,
         last_month_ListSum_EUR,
         LAST_3_MONTH_LAST_YEAR_LISTSUM_EUR,
         LAST_3_MONTH_LISTSUM_EUR
    FROM PortfolioDetails_prep pfd),
PortfolioDetails_sum_until_begin AS
 (SELECT to_char(min(pfd.TECR_DTJOUR_DT), 'J') as first_available_day_J,
         min(pfd.TECR_DTJOUR_DT) as first_available_day,
         max(pfd.TECR_DTJOUR_DT) as last_available_day,
         pl.last_3_month_start_date,
         pl.last_3_month_start_date_j,
         pl.last_month_end_date eom,
         pl.iMX_Contract_Reference,
         pl.iMX_Case_Reference, -- Client Account
         SUM(pfd.AMOUNT_CPT * tl.ListMult) AS SumOfInvoices,
         SUM(CH_TAUX.CONV_ORIG_DEST_TX(to_char(sysdate, 'J'),
                                       pfd.AMOUNT_CPT * tl.ListMult,
                                       pl.Currency,
                                       'EUR',
                                       'MR',
                                       NULL)) AS SumOfInvoices_EUR
    FROM period_list_subcontract pl
    LEFT JOIN AD_PORTFOLIO_DETAIL pfd
      ON pfd.cap_case = pl.imx_contract_reference
     AND pfd.SUBCONTRACT_CASE = pl.imx_case_reference
     AND pfd.TECR_DTJOUR_DT <= pl.last_month_end_date
     AND pfd.TECR_DTJOUR_DT >= pl.last_3_month_start_date
     AND trunc(pfd.TECR_DTJOUR_DT) >= to_date('2022-09-01', 'yyyy-mm-dd')
    LEFT JOIN TypeList tl
      ON tl.ListType = pfd."TYPE"
   WHERE tl.ListArea = 'INVOICE'
   GROUP BY pl.last_3_month_start_date,
            pl.last_3_month_start_date_j,
            pl.last_month_end_date,
            pl.iMX_Contract_Reference,
            pl.imx_case_reference),
PortfolioDetails_sum_until_begin_last_year AS
 (SELECT to_char(min(pfd.TECR_DTJOUR_DT), 'J') as first_available_day_J,
         min(pfd.TECR_DTJOUR_DT) as first_available_day,
         max(pfd.TECR_DTJOUR_DT) as last_available_day,
         pl.last_3_month_last_year_start_date,
         pl.last_3_month_last_year_start_date_j,
         pl.last_month_last_year_end_date eom,
         pl.iMX_Contract_Reference,
         pl.iMX_Case_Reference, -- Client Account
         SUM(pfd.AMOUNT_CPT * tl.ListMult) AS SumOfInvoices,
         SUM(CH_TAUX.CONV_ORIG_DEST_TX(to_char(sysdate, 'J'),
                                       pfd.AMOUNT_CPT * tl.ListMult,
                                       pl.Currency,
                                       'EUR',
                                       'MR',
                                       NULL)) AS SumOfInvoices_EUR
    FROM period_list_subcontract pl
    LEFT JOIN AD_PORTFOLIO_DETAIL pfd
      ON pfd.cap_case = pl.imx_contract_reference
     AND pfd.SUBCONTRACT_CASE = pl.imx_case_reference
     AND pfd.TECR_DTJOUR_DT <= pl.last_month_last_year_end_date
     AND pfd.TECR_DTJOUR_DT >= pl.last_3_month_last_year_start_date
     AND trunc(pfd.TECR_DTJOUR_DT) >= to_date('2022-09-01', 'yyyy-mm-dd')
    LEFT JOIN TypeList tl
      ON tl.ListType = pfd."TYPE"
   WHERE tl.ListArea = 'INVOICE'
   GROUP BY pl.last_3_month_last_year_start_date,
            pl.last_3_month_last_year_start_date_j,
            pl.last_month_last_year_end_date,
            pl.iMX_Contract_Reference,
            pl.imx_case_reference),
PortfolioDetailsSum AS
 (SELECT iMX_Contract_Reference,
         iMX_Case_Reference,
         SUM(CASE
               WHEN ListArea = 'INVOICE' THEN
                last_week_ListSum_EUR
             END) AS SumOfInvoices,
         SUM(CASE
               WHEN ListArea = 'CREDIT NOTE' THEN
                last_week_ListSum_EUR
             END) AS SumOfCreditNotes,
         SUM(CASE
               WHEN ListArea = 'ADJUSTMENT' THEN
                last_week_ListSum_EUR
             END) AS SumOfAdjustments,
         SUM(CASE
               WHEN ListArea = 'PAYMENT' THEN
                last_week_ListSum_EUR
             END) AS SumOfPayments,
         SUM(CASE
               WHEN ListArea = 'OTHER DEBIT' THEN
                last_week_ListSum_EUR
             END) AS SumOfOtherDebits,
         --
         SUM(CASE
               WHEN ListArea = 'INVOICE' THEN
                last_12_month_ListSum_EUR
             END) AS last_12_month_SumOfInvoices,
         SUM(CASE
               WHEN ListArea = 'CREDIT NOTE' THEN
                last_12_month_ListSum_EUR
             END) AS last_12_month_SumOfCreditNotes,
         SUM(CASE
               WHEN ListArea = 'ADJUSTMENT' THEN
                last_12_month_ListSum_EUR
             END) AS last_12_month_SumOfAdjustments,
         SUM(CASE
               WHEN ListArea = 'PAYMENT' THEN
                last_12_month_ListSum_EUR
             END) AS last_12_month_SumOfPayments,
         SUM(CASE
               WHEN ListArea = 'OTHER DEBIT' THEN
                last_12_month_ListSum_EUR
             END) AS last_12_month_SumOfOtherDebits,
         --
         SUM(CASE
               WHEN ListArea = 'INVOICE' THEN
                last_6_month_ListSum_EUR
             END) AS last_6_month_SumOfInvoices,
         SUM(CASE
               WHEN ListArea = 'CREDIT NOTE' THEN
                last_6_month_ListSum_EUR
             END) AS last_6_month_SumOfCreditNotes,
         SUM(CASE
               WHEN ListArea = 'ADJUSTMENT' THEN
                last_6_month_ListSum_EUR
             END) AS last_6_month_SumOfAdjustments,
         SUM(CASE
               WHEN ListArea = 'PAYMENT' THEN
                last_6_month_ListSum_EUR
             END) AS last_6_month_SumOfPayments,
         SUM(CASE
               WHEN ListArea = 'OTHER DEBIT' THEN
                last_6_month_ListSum_EUR
             END) AS last_6_month_SumOfOtherDebits,
         --
         SUM(CASE
               WHEN ListArea = 'INVOICE' THEN
                last_3_month_ListSum_EUR
             END) AS last_3_month_SumOfInvoices,
         SUM(CASE
               WHEN ListArea = 'CREDIT NOTE' THEN
                last_3_month_ListSum_EUR
             END) AS last_3_month_SumOfCreditNotes,
         SUM(CASE
               WHEN ListArea = 'ADJUSTMENT' THEN
                last_3_month_ListSum_EUR
             END) AS last_3_month_SumOfAdjustments,
         SUM(CASE
               WHEN ListArea = 'PAYMENT' THEN
                last_3_month_ListSum_EUR
             END) AS last_3_month_SumOfPayments,
         SUM(CASE
               WHEN ListArea = 'OTHER DEBIT' THEN
                last_3_month_ListSum_EUR
             END) AS last_3_month_SumOfOtherDebits,
         --
         SUM(CASE
               WHEN ListArea = 'INVOICE' THEN
                last_3_month_last_year_ListSum_EUR
             END) AS last_3_month_last_year_SumOfInvoices,
         SUM(CASE
               WHEN ListArea = 'CREDIT NOTE' THEN
                last_3_month_last_year_ListSum_EUR
             END) AS last_3_month_last_year_SumOfCreditNotes,
         SUM(CASE
               WHEN ListArea = 'ADJUSTMENT' THEN
                last_3_month_last_year_ListSum_EUR
             END) AS last_3_month_last_year_SumOfAdjustments,
         SUM(CASE
               WHEN ListArea = 'PAYMENT' THEN
                last_3_month_last_year_ListSum_EUR
             END) AS last_3_month_last_year_SumOfPayments,
         SUM(CASE
               WHEN ListArea = 'OTHER DEBIT' THEN
                last_3_month_last_year_ListSum_EUR
             END) AS last_3_month_last_year_SumOfOtherDebits,
         --
         SUM(CASE
               WHEN ListArea = 'INVOICE' THEN
                last_month_ListSum_EUR
             END) AS last_month_SumOfInvoices,
         SUM(CASE
               WHEN ListArea = 'CREDIT NOTE' THEN
                last_month_ListSum_EUR
             END) AS last_month_SumOfCreditNotes,
         SUM(CASE
               WHEN ListArea = 'ADJUSTMENT' THEN
                last_month_ListSum_EUR
             END) AS last_month_SumOfAdjustments,
         SUM(CASE
               WHEN ListArea = 'PAYMENT' THEN
                last_month_ListSum_EUR
             END) AS last_month_SumOfPayments,
         SUM(CASE
               WHEN ListArea = 'OTHER DEBIT' THEN
                last_month_ListSum_EUR
             END) AS last_month_SumOfOtherDebits
    FROM PortfolioDetails
   GROUP BY iMX_Contract_Reference, iMX_Case_Reference),
new_receivables_other_debit AS
 (SELECT pfd.iMX_Contract_Reference,
         pfd.iMX_Case_Reference,
         SUM(pfd.last_12_month_listsum) ListSum
    FROM PortfolioDetails_prep pfd
   WHERE pfd.listarea IN ('INVOICE', 'OTHER DEBIT')
   GROUP BY pfd.iMX_Contract_Reference, pfd.iMX_Case_Reference),
SAF_CIT_details AS
 (SELECT cla.iMX_Contract_Reference,
         cla.iMX_Case_Reference,
         bfd.TYPMVT,
         CASE
           WHEN bfd.TYPMVT LIKE 'pmtSAF%' THEN
            CASE
              WHEN bfd.SIGNE = 1 THEN
               bfd.MONTANT
              ELSE
               (bfd.MONTANT * -1)
            END
         END CITAdjustments,
         CASE
           WHEN bfd.TYPMVT LIKE 'encSAF%' THEN
            CASE
              WHEN bfd.SIGNE = 0 THEN
               bfd.MONTANT
              ELSE
               (bfd.MONTANT * -1)
            END
         END payments_on_bank_account
    FROM ReportPeriod rp
   INNER JOIN NAM_COLLECTE bfd
      ON trunc(bfd.DTVENTIL_DT) BETWEEN TRUNC(rp.Start_Date) AND
         TRUNC(rp.End_Date)
   INNER JOIN ClientAccount cla
      ON cla.iMX_Case_Reference = bfd.REFDOSS
   WHERE bfd.TYPMVT IN ('pmtSAF_sd_deduc',
                        'pmtSAF_ajust',
                        'encSAF',
                        'encSAF_col',
                        'encSAF_derec')
  --AND TRUNC(bfd.DTVENTIL_DT) BETWEEN TRUNC(rp.Start_Date) AND TRUNC(rp.End_Date) 
   ORDER BY cla.iMX_Contract_Reference),
SAF_CIT_PREP AS
 (SELECT cla.iMX_Contract_Reference,
         cla.iMX_Case_Reference,
         bfd.DTVENTIL_DT,
         CASE
           WHEN bfd.TYPMVT LIKE 'pmtSAF%' THEN
            CASE
              WHEN bfd.SIGNE = 1 THEN
               bfd.MONTANT
              ELSE
               (bfd.MONTANT * -1)
            END
         END CITAdjustments,
         CASE
           WHEN bfd.TYPMVT LIKE 'encSAF%' THEN
            CASE
              WHEN bfd.SIGNE = 0 THEN
               bfd.MONTANT
              ELSE
               (bfd.MONTANT * -1)
            END
         END payments_on_bank_account,
         CASE
           WHEN bfd.TYPMVT LIKE 'pmtSAF%' THEN
            CASE
              WHEN bfd.SIGNE = 1 THEN
               bfd.MONTANT2
              ELSE
               (bfd.MONTANT2 * -1)
            END
         END CITAdjustments_EUR,
         CASE
           WHEN bfd.TYPMVT LIKE 'encSAF%' THEN
            CASE
              WHEN bfd.SIGNE = 0 THEN
               bfd.MONTANT2
              ELSE
               (bfd.MONTANT2 * -1)
            END
         END payments_on_bank_account_EUR
    FROM ReportPeriod rp
   INNER JOIN NAM_COLLECTE bfd
  --ON trunc(bfd.DTVENTIL_DT) BETWEEN TRUNC(rp.Start_Date) AND TRUNC(rp.End_Date)
      ON ((trunc(bfd.DTVENTIL_DT) >= rp.last_12_month_start_date AND
         trunc(bfd.DTVENTIL_DT) <= rp.last_month_end_date) OR
         (trunc(bfd.DTVENTIL_DT) >= rp.Start_Date AND
         trunc(bfd.DTVENTIL_DT) <= rp.End_Date))
   INNER JOIN ClientAccount cla
      ON cla.iMX_Case_Reference = bfd.REFDOSS
   WHERE bfd.TYPMVT IN ('pmtSAF_sd_deduc',
                        'pmtSAF_ajust',
                        'encSAF',
                        'encSAF_col',
                        'encSAF_derec')
  --AND TRUNC(bfd.DTVENTIL_DT) BETWEEN TRUNC(rp.Start_Date) AND TRUNC(rp.End_Date) 
   ORDER BY cla.iMX_Contract_Reference),
SAF_CIT AS
 (SELECT iMX_Contract_Reference,
         iMX_Case_Reference,
         Sum(CASE
               WHEN (trunc(DTVENTIL_DT) BETWEEN rp.Start_Date AND rp.End_Date) THEN
                CITAdjustments
             END) last_week_CITAdjustments,
         Sum(CASE
               WHEN (trunc(DTVENTIL_DT) BETWEEN rp.Start_Date AND rp.End_Date) THEN
                CITAdjustments_EUR
             END) last_week_CITAdjustments_EUR,
         Sum(CASE
               WHEN (trunc(DTVENTIL_DT) BETWEEN rp.Start_Date AND rp.End_Date) THEN
                payments_on_bank_account
             END) last_week_payments_on_bank_account,
         Sum(CASE
               WHEN (trunc(DTVENTIL_DT) BETWEEN rp.Start_Date AND rp.End_Date) THEN
                payments_on_bank_account_EUR
             END) last_week_payments_on_bank_account_EUR,
         --
         Sum(CASE
               WHEN (trunc(DTVENTIL_DT) BETWEEN rp.last_12_month_start_date AND
                    rp.last_month_end_date) THEN
                CITAdjustments
             END) last_12_month_CITAdjustments,
         Sum(CASE
               WHEN (trunc(DTVENTIL_DT) BETWEEN rp.last_12_month_start_date AND
                    rp.last_month_end_date) THEN
                CITAdjustments_EUR
             END) last_12_month_CITAdjustments_EUR,
         Sum(CASE
               WHEN (trunc(DTVENTIL_DT) BETWEEN rp.last_12_month_start_date AND
                    rp.last_month_end_date) THEN
                payments_on_bank_account
             END) last_12_month_payments_on_bank_account,
         Sum(CASE
               WHEN (trunc(DTVENTIL_DT) BETWEEN rp.last_12_month_start_date AND
                    rp.last_month_end_date) THEN
                payments_on_bank_account_EUR
             END) last_12_month_payments_on_bank_account_EUR,
         --
         Sum(CASE
               WHEN (trunc(DTVENTIL_DT) BETWEEN rp.last_6_month_start_date AND
                    rp.last_month_end_date) THEN
                CITAdjustments
             END) last_6_month_CITAdjustments,
         Sum(CASE
               WHEN (trunc(DTVENTIL_DT) BETWEEN rp.last_6_month_start_date AND
                    rp.last_month_end_date) THEN
                CITAdjustments_EUR
             END) last_6_month_CITAdjustments_EUR,
         Sum(CASE
               WHEN (trunc(DTVENTIL_DT) BETWEEN rp.last_6_month_start_date AND
                    rp.last_month_end_date) THEN
                payments_on_bank_account
             END) last_6_month_payments_on_bank_account,
         Sum(CASE
               WHEN (trunc(DTVENTIL_DT) BETWEEN rp.last_6_month_start_date AND
                    rp.last_month_end_date) THEN
                payments_on_bank_account_EUR
             END) last_6_month_payments_on_bank_account_EUR,
         --
         Sum(CASE
               WHEN (trunc(DTVENTIL_DT) BETWEEN rp.last_month_start_date AND
                    rp.last_month_end_date) THEN
                CITAdjustments
             END) last_month_CITAdjustments,
         Sum(CASE
               WHEN (trunc(DTVENTIL_DT) BETWEEN rp.last_month_start_date AND
                    rp.last_month_end_date) THEN
                CITAdjustments_EUR
             END) last_month_CITAdjustments_EUR,
         Sum(CASE
               WHEN (trunc(DTVENTIL_DT) BETWEEN rp.last_month_start_date AND
                    rp.last_month_end_date) THEN
                payments_on_bank_account
             END) last_month_payments_on_bank_account,
         Sum(CASE
               WHEN (trunc(DTVENTIL_DT) BETWEEN rp.last_month_start_date AND
                    rp.last_month_end_date) THEN
                payments_on_bank_account_EUR
             END) last_month_payments_on_bank_account_EUR
    FROM ReportPeriod rp, SAF_CIT_PREP
   GROUP BY iMX_Contract_Reference, iMX_Case_Reference
   ORDER BY iMX_Contract_Reference),
pre_ratings AS
 (SELECT DISTINCT fin.REFINDIVIDU,
                  rp.*,
                  fin.str2,
                  --fin.DT01_DT, 
                  rank() over(partition by fin.REFINDIVIDU order by fin.TYPE, fin.DT01_DT desc) rank_x
    FROM G_INDIVPARAM fin, -- Ermittelt FIN Rating
         ReportPeriod rp
   WHERE fin.str1 = 'FIN'
     AND fin.TYPE IN ('COTE FACTOR HIS', 'COTE FACTOR')
     AND trunc(fin.DT01_DT) <= trunc(rp.End_Date)),
fin_ratings AS
 (SELECT * FROM pre_ratings WHERE rank_x = 1),
MemberGroups AS
 (SELECT gc.GRP_NAME, gc.REFGROUP, mc.REFDOSS
    FROM GROUP_CONTRACTS gc, MEMBER_CONTRACT mc
   WHERE mc.REFGROUP = gc.REFGROUP
     AND (gc.DEACTIVATED = 'N' OR gc.DEACTIVATED IS NULL)),
MFTLimits AS
 (SELECT pl.contract_number, pl.imx_case_reference, l.amount, l.currency
    FROM period_list_subcontract pl
    LEFT JOIN MAX_FIU_LIMIT l
      ON l.refgroup = pl.contract_number
     AND l.start_dt <= pl.End_Date
     AND (l.END_DT >= pl.End_Date OR l.end_dt IS NULL)),
report_pre AS
 (SELECT 1 AS sort,
         pl.cal_year,
         pl.cal_week,
         pl.iMX_Client_Reference,
         pl.Contract_Number, -- Vertragsnummer
         pl.iMX_Contract_Reference,
         pl.iMX_Case_Reference, -- Subcontract
         pl.client_name,
         pl.Currency AS SUBCONTRACT_CURRENCY,
         pl.CLIENT_MANAGER_NOM, -- Kontomanager
         pl.ACCOUNT_MANAGER_NOM, -- Kundenbetreuer
         pl.TEAM_ASSISTANT_NAME, -- Riskmanager
         pl.MAXFIU maxfiu, -- LIMIT BV
         mft.amount MaxFiU_group, -- LIMIT BV Gruppe
         mft.currency MaxFiU_group_CCY,
         status.status,
         fin.str2 fin_rating, -- fin rating,
         CH_TAUX.CONV_ORIG_DEST_TX(to_char(sysdate, 'J'),
                                   cls.FIU,
                                   pl.Currency,
                                   'EUR',
                                   'MR',
                                   NULL) AS funds_in_use_eur,
         cls.PORTFOLIO,
         CH_TAUX.CONV_ORIG_DEST_TX(to_char(sysdate, 'J'),
                                   cls.PORTFOLIO,
                                   pl.Currency,
                                   'EUR',
                                   'MR',
                                   NULL) AS portfolio_eur,
         CH_TAUX.CONV_ORIG_DEST_TX(to_char(sysdate, 'J'),
                                   cls.Retentions,
                                   pl.Currency,
                                   'EUR',
                                   'MR',
                                   NULL) AS Retentions_eur,
         CH_TAUX.CONV_ORIG_DEST_TX(to_char(sysdate, 'J'),
                                   pds.SumOfCreditNotes,
                                   pl.Currency,
                                   'EUR',
                                   'MR',
                                   NULL) AS CreditNotes_eur,
         cls.Fundable_Amount,
         CH_TAUX.CONV_ORIG_DEST_TX(to_char(sysdate, 'J'),
                                   cls.Fundable_Amount,
                                   pl.Currency,
                                   'EUR',
                                   'MR',
                                   NULL) AS Fundable_Amount_eur,
         CH_TAUX.CONV_ORIG_DEST_TX(to_char(sysdate, 'J'),
                                   NULLIF(CASE
                                            WHEN pl.GP_FG06 = 'O' -- (= 'Is SAF flag' true) dann 
                                             THEN
                                             nvl(pds.SumOfAdjustments, 0) +
                                             nvl(sca.last_week_CITAdjustments, 0)
                                            ELSE
                                             pds.SumOfAdjustments
                                          END,
                                          0),
                                   pl.Currency,
                                   'EUR',
                                   'MR',
                                   NULL) AS Adjustments_eur,
         CH_TAUX.CONV_ORIG_DEST_TX(to_char(sysdate, 'J'),
                                   pds.SumOfOtherDebits,
                                   pl.Currency,
                                   'EUR',
                                   'MR',
                                   NULL) AS OtherDebits_eur,
         CH_TAUX.CONV_ORIG_DEST_TX(to_char(sysdate, 'J'),
                                   pds.SumOfInvoices,
                                   pl.Currency,
                                   'EUR',
                                   'MR',
                                   NULL) AS Invoices_eur,
         ---
         CH_TAUX.CONV_ORIG_DEST_TX(to_char(sysdate, 'J'),
                                   pds.last_month_SumOfCreditNotes,
                                   pl.Currency,
                                   'EUR',
                                   'MR',
                                   NULL) AS last_month_CreditNotes_eur,
         CH_TAUX.CONV_ORIG_DEST_TX(to_char(sysdate, 'J'),
                                   NULLIF(CASE
                                            WHEN pl.GP_FG06 = 'O' -- (= 'Is SAF flag' true) dann 
                                             THEN
                                             nvl(pds.last_month_SumOfAdjustments, 0) +
                                             nvl(sca.last_month_CITAdjustments, 0)
                                            ELSE
                                             pds.last_month_SumOfAdjustments
                                          END,
                                          0),
                                   pl.Currency,
                                   'EUR',
                                   'MR',
                                   NULL) AS last_month_Adjustments_eur,
         CH_TAUX.CONV_ORIG_DEST_TX(to_char(sysdate, 'J'),
                                   pds.last_month_SumOfOtherDebits,
                                   pl.Currency,
                                   'EUR',
                                   'MR',
                                   NULL) AS last_month_OtherDebits_eur,
         CH_TAUX.CONV_ORIG_DEST_TX(to_char(sysdate, 'J'),
                                   pds.last_month_SumOfInvoices,
                                   pl.Currency,
                                   'EUR',
                                   'MR',
                                   NULL) AS last_month_Invoices_eur,
         ---
         CH_TAUX.CONV_ORIG_DEST_TX(to_char(sysdate, 'J'),
                                   pds.last_6_month_SumOfCreditNotes,
                                   pl.Currency,
                                   'EUR',
                                   'MR',
                                   NULL) AS last_6_month_CreditNotes_eur,
         CH_TAUX.CONV_ORIG_DEST_TX(to_char(sysdate, 'J'),
                                   NULLIF(CASE
                                            WHEN pl.GP_FG06 = 'O' -- (= 'Is SAF flag' true) dann 
                                             THEN
                                             nvl(pds.last_6_month_SumOfAdjustments, 0) +
                                             nvl(sca.last_6_month_CITAdjustments, 0)
                                            ELSE
                                             pds.last_6_month_SumOfAdjustments
                                          END,
                                          0),
                                   pl.Currency,
                                   'EUR',
                                   'MR',
                                   NULL) AS last_6_month_Adjustments_eur,
         CH_TAUX.CONV_ORIG_DEST_TX(to_char(sysdate, 'J'),
                                   pds.last_6_month_SumOfOtherDebits,
                                   pl.Currency,
                                   'EUR',
                                   'MR',
                                   NULL) AS last_6_month_OtherDebits_eur,
         CH_TAUX.CONV_ORIG_DEST_TX(to_char(sysdate, 'J'),
                                   pds.last_6_month_SumOfInvoices,
                                   pl.Currency,
                                   'EUR',
                                   'MR',
                                   NULL) AS last_6_month_Invoices_eur,
         ---
         CH_TAUX.CONV_ORIG_DEST_TX(to_char(sysdate, 'J'),
                                   pds.last_12_month_SumOfCreditNotes,
                                   pl.Currency,
                                   'EUR',
                                   'MR',
                                   NULL) AS last_12_month_CreditNotes_eur,
         CH_TAUX.CONV_ORIG_DEST_TX(to_char(sysdate, 'J'),
                                   NULLIF(CASE
                                            WHEN pl.GP_FG06 = 'O' -- (= 'Is SAF flag' true) dann 
                                             THEN
                                             nvl(pds.last_12_month_SumOfAdjustments, 0) +
                                             nvl(sca.last_12_month_CITAdjustments, 0)
                                            ELSE
                                             pds.last_12_month_SumOfAdjustments
                                          END,
                                          0),
                                   pl.Currency,
                                   'EUR',
                                   'MR',
                                   NULL) AS last_12_month_Adjustments_eur,
         CH_TAUX.CONV_ORIG_DEST_TX(to_char(sysdate, 'J'),
                                   pds.last_12_month_SumOfOtherDebits,
                                   pl.Currency,
                                   'EUR',
                                   'MR',
                                   NULL) AS last_12_month_OtherDebits_eur,
         CH_TAUX.CONV_ORIG_DEST_TX(to_char(sysdate, 'J'),
                                   pds.last_12_month_SumOfInvoices,
                                   pl.Currency,
                                   'EUR',
                                   'MR',
                                   NULL) AS last_12_month_Invoices_eur,
         ---
         pds.last_3_month_SumOfInvoices,
         pds.last_3_month_SumOfOtherDebits,
         pds.last_3_month_last_year_SumOfInvoices,
         pds.last_3_month_last_year_SumOfOtherDebits,
         CASE
           WHEN cs_avg_ub_ly.portfolio = 0 OR pds_ub_ly.SumOfInvoices = 0 THEN
            NULL
           ELSE
            cs_avg_ub_ly.days_from_begin /
            (pds_ub_ly.SumOfInvoices / cs_avg_ub_ly.portfolio)
         END AS DebtorTurnover_last_year,
         --
         pl.GP_FG06,
         sca.last_12_month_payments_on_bank_account,
         pds.last_12_month_SumOfPayments,
         --
         CH_TAUX.CONV_ORIG_DEST_TX(to_char(sysdate, 'J'),
                                   cls_wb.Retentions,
                                   pl.Currency,
                                   'EUR',
                                   'MR',
                                   NULL) AS Retentions_eur_week_bevore,
         CH_TAUX.CONV_ORIG_DEST_TX(to_char(sysdate, 'J'),
                                   cls_curernt.AVAILABILITY,
                                   pl.Currency,
                                   'EUR',
                                   'MR',
                                   NULL) AS AVAILABILITY_eur_current,
         cls_curernt.BLOCKED_AMOUNT AS BLOCKED_AMOUNT_current,
         cls_curernt.FIU AS FIU_current,
         --
         fr.financing_rate
    FROM period_list_subcontract pl
    LEFT JOIN contract_status status
      ON status.iMX_Case_Reference = pl.iMX_Case_Reference
    LEFT OUTER JOIN ClientStatement cls
      ON cls.iMX_Contract_Reference = pl.iMX_Contract_Reference
     AND cls.iMX_Case_Reference = pl.iMX_Case_Reference
    LEFT OUTER JOIN ClientStatement_current cls_curernt
      ON cls_curernt.iMX_Contract_Reference = pl.iMX_Contract_Reference
     AND cls_curernt.iMX_Case_Reference = pl.iMX_Case_Reference
    LEFT OUTER JOIN ClientStatement_week_bevore cls_wb
      ON cls_wb.iMX_Contract_Reference = pl.iMX_Contract_Reference
     AND cls_wb.iMX_Case_Reference = pl.iMX_Case_Reference
  --
    LEFT OUTER JOIN PortfolioDetailsSum pds
      ON pds.iMX_Contract_Reference = pl.iMX_Contract_Reference
     AND pds.iMX_Case_Reference = pl.iMX_Case_Reference
  --
    LEFT OUTER JOIN SAF_CIT sca
      ON sca.iMX_Contract_Reference = pl.iMX_Contract_Reference
     AND sca.iMX_Case_Reference = pl.iMX_Case_Reference
  --
    LEFT OUTER JOIN MFTLIMITS mft
      ON mft.contract_number = pl.contract_number
     AND mft.iMX_Case_Reference = pl.iMX_Case_Reference
    LEFT OUTER JOIN fin_ratings fin -- OK!!
      ON fin.REFINDIVIDU = pl.iMX_Client_Reference
  --
    LEFT JOIN ClientStatement_avg_until_begin cs_avg_ub
      ON cs_avg_ub.iMX_Case_Reference = pl.iMX_Case_Reference
    LEFT JOIN ClientStatement_avg_until_begin_last_year cs_avg_ub_ly
      ON cs_avg_ub_ly.iMX_Case_Reference = pl.iMX_Case_Reference
    LEFT OUTER JOIN PortfolioDetails_sum_until_begin pds_ub
      ON pds_ub.iMX_Contract_Reference = pl.iMX_Contract_Reference
     AND pds_ub.iMX_Case_Reference = pl.iMX_Case_Reference
    LEFT OUTER JOIN PortfolioDetails_sum_until_begin_last_year pds_ub_ly
      ON pds_ub_ly.iMX_Contract_Reference = pl.iMX_Contract_Reference
     AND pds_ub_ly.iMX_Case_Reference = pl.iMX_Case_Reference
    LEFT JOIN FinancingRate fr
      ON fr.refdoss = pl.iMX_Case_Reference
   WHERE 1 = 1
   ORDER BY pl.iMX_Case_Reference),
report AS
 (SELECT cal_year,
         cal_week,
         CONTRACT_NUMBER,
         iMX_Case_Reference,
         SUBCONTRACT_CURRENCY,
         client_name,
         ACCOUNT_MANAGER_NOM AS Client_manager,
         CLIENT_MANAGER_NOM AS Case_manager,
         TEAM_ASSISTANT_NAME AS Risk_manager,
         MAXFIU,
         MAXFIU_GROUP,
         MAXFIU_GROUP_CCY,
         status,
         fin_rating,
         funds_in_use_eur,
         portfolio_eur,
         Retentions_eur,
         CreditNotes_eur,
         Adjustments_eur,
         round(((nvl(CreditNotes_eur, 0) + nvl(Adjustments_eur, 0)) /
               (NULLIF(nvl(invoices_eur, 0) + nvl(otherDebits_eur, 0), 0))) * 100,
               2) AS credit_notes_adjustments_perc,
         round(((nvl(last_month_CreditNotes_eur, 0) +
               nvl(last_month_Adjustments_eur, 0)) /
               (NULLIF(nvl(last_month_invoices_eur, 0) +
                        nvl(last_month_otherDebits_eur, 0),
                        0))) * 100,
               2) AS last_month_credit_notes_adjustments_perc,
         round(((nvl(last_6_month_CreditNotes_eur, 0) +
               nvl(last_6_month_Adjustments_eur, 0)) /
               (NULLIF(nvl(last_6_month_invoices_eur, 0) +
                        nvl(last_6_month_otherDebits_eur, 0),
                        0))) * 100,
               2) AS last_6_month_credit_notes_adjustments_perc,
         round(((nvl(last_12_month_CreditNotes_eur, 0) +
               nvl(last_12_month_Adjustments_eur, 0)) /
               (NULLIF(nvl(last_12_month_invoices_eur, 0) +
                        nvl(last_12_month_otherDebits_eur, 0),
                        0))) * 100,
               2) AS last_12_month_credit_notes_adjustments_perc,
         (((last_3_month_SumOfInvoices + last_3_month_SumOfOtherDebits) -
         (last_3_month_last_year_SumOfInvoices +
         last_3_month_last_year_SumOfOtherDebits)) /
         (last_3_month_last_year_SumOfInvoices +
         last_3_month_last_year_SumOfOtherDebits)) * 100 AS turnover,
         (1 - (Retentions_eur / NULLIF(Retentions_eur_week_bevore, 0))) * -1 AS retentions_change_perc,
         (FIU_current / NULLIF(Fundable_Amount, 0)) * 100 AS overdraft,
         '###' AS break,
         invoices_eur AS invoices_last_week_eur,
         otherDebits_eur AS otherDebits_last_week_eur,
         portfolio AS portfolio_last_week,
         financing_rate,
         GP_FG06,
         AVAILABILITY_eur_current,
         FIU_current,
         BLOCKED_AMOUNT_current,
         last_12_month_payments_on_bank_account,
         last_12_month_SumOfPayments,
         last_month_CreditNotes_eur,
         last_month_Adjustments_eur,
         last_month_invoices_eur,
         last_month_otherDebits_eur
    FROM report_pre)
SELECT *
  FROM report pl
  FULL OUTER JOIN new_receivables_other_debit nrod
    on nrod.iMX_Case_Reference = pl.iMX_Case_Reference 
   AND imx_case_reference = '0001010345';
/********************************OLD SQL*******************************************/
/********************************OLD Metrics***************************************/
/*
SQL Plan Monitoring Details (Plan Hash Value=3659274432)
===============================================================================================================================================================================================================================================================
| Id    |                             Operation                              |             Name              |  Rows   | Cost  |   Time    | Start  | Execs |   Rows   | Read | Read  | Write | Write |  Mem  | Temp | Activity |    Activity Detail       |
|       |                                                                    |                               | (Estim) |       | Active(s) | Active |       | (Actual) | Reqs | Bytes | Reqs  | Bytes |       |      |        (%)    |         (# samples)         |
===============================================================================================================================================================================================================================================================
|     0 | SELECT STATEMENT                                                   |                               |         |       |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|     1 |   TEMP TABLE TRANSFORMATION                                        |                               |         |       |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|     2 |    LOAD AS SELECT (CURSOR DURATION MEMORY)                         | SYS_TEMP_0FD9E76B4_92BF0312   |         |       |         1 |     +3 |     1 |        1 |      |       |       |       | 161KB |    . |               |                             |
|     3 |     HASH JOIN                                                      |                               |     508 |    24 |         1 |     +3 |     1 |      492 |      |       |       |       |     . |    . |               |                             |
|     4 |      NESTED LOOPS                                                  |                               |     492 |     7 |         1 |     +3 |     1 |      492 |      |       |       |       |     . |    . |               |                             |
|     5 |       FAST DUAL                                                    |                               |       1 |     2 |         1 |     +3 |     1 |        1 |      |       |       |       |     . |    . |               |                             |
|     6 |       MAT_VIEW ACCESS STORAGE FULL                                 | AD_ACCOUNT_CLIENT_MVIEW       |     492 |     5 |         1 |     +3 |     1 |      492 |      |       |       |       |     . |    . |               |                             |
|     7 |      TABLE ACCESS STORAGE FULL                                     | AD_CASE_CONTRAT               |     439 |    17 |         1 |     +3 |     1 |      439 |      |       |       |       |     . |    . |               |                             |
|     8 |    LOAD AS SELECT (CURSOR DURATION MEMORY)                         | SYS_TEMP_0FD9E76B5_92BF0312   |         |       |         1 |     +3 |     1 |        1 |      |       |       |       |   6MB |    . |               |                             |
|     9 |     HASH JOIN                                                      |                               |    667K |    60 |         1 |     +3 |     1 |       13 |      |       |       |       |     . |    . |               |                             |
|    10 |      COLLECTION ITERATOR CONSTRUCTOR FETCH                         |                               |    8168 |    29 |         1 |     +3 |     1 |       13 |      |       |       |       |     . |    . |               |                             |
|    11 |      COLLECTION ITERATOR CONSTRUCTOR FETCH                         |                               |    8168 |    29 |         1 |     +3 |     1 |       13 |      |       |       |       |     . |    . |               |                             |
|    12 |    LOAD AS SELECT (CURSOR DURATION MEMORY)                         | SYS_TEMP_0FD9E76B6_92BF0312   |         |       |         1 |     +3 |     1 |        1 |      |       |       |       |   6MB |    . |               |                             |
|    13 |     NESTED LOOPS OUTER                                             |                               |     492 |  1484 |         1 |     +3 |     1 |    44772 |      |       |       |       |     . |    . |               |                             |
|    14 |      MERGE JOIN CARTESIAN                                          |                               |     492 |     8 |         1 |     +3 |     1 |    44772 |      |       |       |       |     . |    . |               |                             |
|    15 |       VIEW                                                         |                               |       1 |     3 |         1 |     +3 |     1 |       91 |      |       |       |       |     . |    . |               |                             |
|    16 |        SORT ORDER BY                                               |                               |       1 |     3 |         1 |     +3 |     1 |       91 |      |       |       |       |     . |    . |               |                             |
|    17 |         CONNECT BY WITHOUT FILTERING                               |                               |         |       |         1 |     +3 |     1 |       91 |      |       |       |       |     . |    . |               |                             |
|    18 |          FAST DUAL                                                 |                               |       1 |     2 |         1 |     +3 |     1 |        1 |      |       |       |       |     . |    . |               |                             |
|    19 |       BUFFER SORT                                                  |                               |     492 |     8 |         1 |     +3 |    91 |    44772 |      |       |       |       |     . |    . |               |                             |
|    20 |        MAT_VIEW ACCESS STORAGE FULL                                | AD_ACCOUNT_CLIENT_MVIEW       |     492 |     5 |         1 |     +3 |     1 |      492 |      |       |       |       |     . |    . |               |                             |
|    21 |      VIEW                                                          | AD_CLIENT_STATEMENT_HIST_VIEW |       1 |     3 |         1 |     +3 | 44772 |    39668 |      |       |       |       |     . |    . |               |                             |
|    22 |       UNION-ALL PARTITION                                          |                               |         |       |         1 |     +3 | 44772 |    39668 |      |       |       |       |     . |    . |               |                             |
|    23 |        TABLE ACCESS BY INDEX ROWID                                 | AD_CLIENT_STATEMENT_HISTORY   |       1 |     3 |           |        | 44772 |          |      |       |       |       |     . |    . |               |                             |
|    24 |         INDEX UNIQUE SCAN                                          | PK_AD_CL_HISTORY              |       1 |     2 |           |        | 44772 |          |      |       |       |       |     . |    . |               |                             |
|    25 |        TABLE ACCESS BY INDEX ROWID                                 | AD_CLIENT_STATEMENT_HIST_ARCH |       1 |     3 |         1 |     +3 | 44772 |    39668 |      |       |       |       |     . |    . |               |                             |
|    26 |         INDEX UNIQUE SCAN                                          | AD_CL_STM_ARCH_PK             |       1 |     2 |         1 |     +3 | 44772 |    39668 |      |       |       |       |     . |    . |               |                             |
|    27 |    LOAD AS SELECT (CURSOR DURATION MEMORY)                         | SYS_TEMP_0FD9E76B7_92BF0312   |         |       |         1 |     +3 |     1 |        1 |      |       |       |       |   6MB |    . |               |                             |
|    28 |     NESTED LOOPS OUTER                                             |                               |     492 |  1484 |         1 |     +3 |     1 |    44280 |      |       |       |       |     . |    . |               |                             |
|    29 |      MERGE JOIN CARTESIAN                                          |                               |     492 |     8 |         1 |     +3 |     1 |    44280 |      |       |       |       |     . |    . |               |                             |
|    30 |       VIEW                                                         |                               |       1 |     3 |         1 |     +3 |     1 |       90 |      |       |       |       |     . |    . |               |                             |
|    31 |        SORT ORDER BY                                               |                               |       1 |     3 |         1 |     +3 |     1 |       90 |      |       |       |       |     . |    . |               |                             |
|    32 |         CONNECT BY WITHOUT FILTERING                               |                               |         |       |         1 |     +3 |     1 |       90 |      |       |       |       |     . |    . |               |                             |
|    33 |          FAST DUAL                                                 |                               |       1 |     2 |         1 |     +3 |     1 |        1 |      |       |       |       |     . |    . |               |                             |
|    34 |       BUFFER SORT                                                  |                               |     492 |     8 |         1 |     +3 |    90 |    44280 |      |       |       |       |     . |    . |               |                             |
|    35 |        MAT_VIEW ACCESS STORAGE FULL                                | AD_ACCOUNT_CLIENT_MVIEW       |     492 |     5 |         1 |     +3 |     1 |      492 |      |       |       |       |     . |    . |               |                             |
|    36 |      VIEW                                                          | AD_CLIENT_STATEMENT_HIST_VIEW |       1 |     3 |         1 |     +3 | 44280 |    37145 |      |       |       |       |     . |    . |               |                             |
|    37 |       UNION-ALL PARTITION                                          |                               |         |       |         1 |     +3 | 44280 |    37145 |      |       |       |       |     . |    . |               |                             |
|    38 |        TABLE ACCESS BY INDEX ROWID                                 | AD_CLIENT_STATEMENT_HISTORY   |       1 |     3 |           |        | 44280 |          |      |       |       |       |     . |    . |               |                             |
|    39 |         INDEX UNIQUE SCAN                                          | PK_AD_CL_HISTORY              |       1 |     2 |           |        | 44280 |          |      |       |       |       |     . |    . |               |                             |
|    40 |        TABLE ACCESS BY INDEX ROWID                                 | AD_CLIENT_STATEMENT_HIST_ARCH |       1 |     3 |         1 |     +3 | 44280 |    37145 |      |       |       |       |     . |    . |               |                             |
|    41 |         INDEX UNIQUE SCAN                                          | AD_CL_STM_ARCH_PK             |       1 |     2 |         4 |     +0 | 44280 |    37145 |      |       |       |       |     . |    . |          0.23 | Cpu (1)                     |
|    42 |    LOAD AS SELECT (CURSOR DURATION MEMORY)                         | SYS_TEMP_0FD9E76B8_92BF0312   |         |       |           |        |     1 |          |      |       |       |       |     . |    . |               |                             |
| -> 43 |     HASH JOIN                                                      |                               |   13989 |   69M |       440 |     +3 |     1 |        0 |      |       |   191 |  94MB |  89MB | 97MB |          0.45 | Cpu (2)                     |
| -> 44 |      NESTED LOOPS                                                  |                               |   75692 |   69M |       440 |     +3 |     1 |       1M |      |       |       |       |     . |    . |               |                             |
| -> 45 |       VIEW                                                         |                               |     508 |     5 |       440 |     +3 |     1 |       88 |      |       |       |       |     . |    . |               |                             |
| -> 46 |        TABLE ACCESS STORAGE FULL                                   | SYS_TEMP_0FD9E76B4_92BF0312   |     508 |     5 |       440 |     +3 |     1 |       88 |      |       |       |       |     . |    . |               |                             |
| -> 47 |       VIEW                                                         | VW_LAT_A1F5E987               |     149 |  137K |       440 |     +3 |    88 |       1M |      |       |       |       |     . |    . |               |                             |
| -> 48 |        TABLE ACCESS STORAGE FULL                                   | AD_PORTFOLIO_DETAIL           |     149 |  137K |       442 |     +1 |    88 |       1M | 643K | 330GB |       |       |  10MB |    . |         99.32 | Cpu (248)                   |
|       |                                                                    |                               |         |       |           |        |       |          |      |       |       |       |       |      |               | reliable message (1)        |
|       |                                                                    |                               |         |       |           |        |       |          |      |       |       |       |       |      |               | cell smart table scan (189) |
|    49 |      VIEW                                                          |                               |    667K |   103 |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|    50 |       TABLE ACCESS STORAGE FULL                                    | SYS_TEMP_0FD9E76B5_92BF0312   |    667K |   103 |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|    51 |    SORT AGGREGATE                                                  |                               |       1 |       |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|    52 |     VIEW                                                           | VW_FOJ_0                      |    164K |  241M |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|    53 |      HASH JOIN FULL OUTER                                          |                               |    164K |  241M |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|    54 |       VIEW                                                         |                               |     545 |  125M |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|    55 |        HASH JOIN RIGHT OUTER                                       |                               |     545 |  125M |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|    56 |         VIEW                                                       |                               |     493 |  7187 |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|    57 |          HASH GROUP BY                                             |                               |     493 |  7187 |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|    58 |           VIEW                                                     |                               |     493 |  7186 |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|    59 |            UNION-ALL                                               |                               |         |       |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|    60 |             VIEW                                                   |                               |     492 |     4 |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|    61 |              TABLE ACCESS STORAGE FULL                             | SYS_TEMP_0FD9E76B7_92BF0312   |     492 |     4 |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|    62 |             NESTED LOOPS                                           |                               |       1 |  7182 |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|    63 |              VIEW                                                  |                               |     492 |  5706 |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|    64 |               HASH GROUP BY                                        |                               |     492 |  5706 |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|    65 |                HASH JOIN OUTER                                     |                               |     492 |  5705 |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|    66 |                 VIEW                                               |                               |     492 |     4 |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|    67 |                  TABLE ACCESS STORAGE FULL                         | SYS_TEMP_0FD9E76B7_92BF0312   |     492 |     4 |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|    68 |                 VIEW                                               | AD_CLIENT_STATEMENT_HIST_VIEW |   14408 |  5418 |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|    69 |                  UNION-ALL                                         |                               |         |       |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|    70 |                   TABLE ACCESS BY INDEX ROWID BATCHED              | AD_CLIENT_STATEMENT_HISTORY   |    2312 |   735 |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|    71 |                    INDEX SKIP SCAN                                 | AD_CL_HIST_DT04_CLIENT_IDX    |     416 |   347 |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|    72 |                   TABLE ACCESS STORAGE FULL                        | AD_CLIENT_STATEMENT_HIST_ARCH |   12096 |  4683 |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|    73 |              VIEW                                                  | AD_CLIENT_STATEMENT_HIST_VIEW |       1 |     3 |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|    74 |               UNION-ALL PARTITION                                  |                               |         |       |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|    75 |                TABLE ACCESS BY INDEX ROWID                         | AD_CLIENT_STATEMENT_HISTORY   |       1 |     3 |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|    76 |                 INDEX UNIQUE SCAN                                  | PK_AD_CL_HISTORY              |       1 |     2 |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|    77 |                TABLE ACCESS BY INDEX ROWID                         | AD_CLIENT_STATEMENT_HIST_ARCH |       1 |     3 |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|    78 |                 INDEX UNIQUE SCAN                                  | AD_CL_STM_ARCH_PK             |       1 |     2 |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|    79 |         HASH JOIN RIGHT OUTER                                      |                               |     526 |  125M |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|    80 |          VIEW                                                      |                               |     493 |  7187 |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|    81 |           HASH GROUP BY                                            |                               |     493 |  7187 |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|    82 |            VIEW                                                    |                               |     493 |  7186 |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|    83 |             UNION-ALL                                              |                               |         |       |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|    84 |              VIEW                                                  |                               |     492 |     4 |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|    85 |               TABLE ACCESS STORAGE FULL                            | SYS_TEMP_0FD9E76B6_92BF0312   |     492 |     4 |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|    86 |              NESTED LOOPS                                          |                               |       1 |  7182 |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|    87 |               VIEW                                                 |                               |     492 |  5706 |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|    88 |                HASH GROUP BY                                       |                               |     492 |  5706 |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|    89 |                 HASH JOIN OUTER                                    |                               |     492 |  5705 |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|    90 |                  VIEW                                              |                               |     492 |     4 |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|    91 |                   TABLE ACCESS STORAGE FULL                        | SYS_TEMP_0FD9E76B6_92BF0312   |     492 |     4 |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|    92 |                  VIEW                                              | AD_CLIENT_STATEMENT_HIST_VIEW |   14408 |  5418 |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|    93 |                   UNION-ALL                                        |                               |         |       |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|    94 |                    TABLE ACCESS BY INDEX ROWID BATCHED             | AD_CLIENT_STATEMENT_HISTORY   |    2312 |   735 |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|    95 |                     INDEX SKIP SCAN                                | AD_CL_HIST_DT04_CLIENT_IDX    |     416 |   347 |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|    96 |                    TABLE ACCESS STORAGE FULL                       | AD_CLIENT_STATEMENT_HIST_ARCH |   12096 |  4683 |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|    97 |               VIEW                                                 | AD_CLIENT_STATEMENT_HIST_VIEW |       1 |     3 |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|    98 |                UNION-ALL PARTITION                                 |                               |         |       |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|    99 |                 TABLE ACCESS BY INDEX ROWID                        | AD_CLIENT_STATEMENT_HISTORY   |       1 |     3 |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|   100 |                  INDEX UNIQUE SCAN                                 | PK_AD_CL_HISTORY              |       1 |     2 |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|   101 |                 TABLE ACCESS BY INDEX ROWID                        | AD_CLIENT_STATEMENT_HIST_ARCH |       1 |     3 |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|   102 |                  INDEX UNIQUE SCAN                                 | AD_CL_STM_ARCH_PK             |       1 |     2 |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|   103 |          HASH JOIN OUTER                                           |                               |     508 |  125M |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|   104 |           JOIN FILTER CREATE                                       | :BF0000                       |     508 |  307K |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|   105 |            HASH JOIN RIGHT OUTER                                   |                               |     508 |  307K |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|   106 |             VIEW                                                   |                               |     508 |  1530 |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|   107 |              MERGE JOIN OUTER                                      |                               |     508 |  1530 |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|   108 |               VIEW                                                 |                               |     508 |     5 |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|   109 |                TABLE ACCESS STORAGE FULL                           | SYS_TEMP_0FD9E76B4_92BF0312   |     508 |     5 |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|   110 |               BUFFER SORT                                          |                               |       1 |  1530 |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|   111 |                VIEW                                                | VW_LAT_E5EC2EE8               |       1 |     3 |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|   112 |                 TABLE ACCESS STORAGE FULL                          | MAX_FIU_LIMIT                 |       1 |     3 |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|   113 |             HASH JOIN RIGHT OUTER                                  |                               |     508 |  305K |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|   114 |              VIEW                                                  |                               |     108 |   362 |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|   115 |               HASH UNIQUE                                          |                               |     108 |   362 |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|   116 |                WINDOW SORT PUSHED RANK                             |                               |     108 |   362 |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|   117 |                 NESTED LOOPS                                       |                               |     108 |   360 |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|   118 |                  FAST DUAL                                         |                               |       1 |     2 |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|   119 |                  INLIST ITERATOR                                   |                               |         |       |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|   120 |                   TABLE ACCESS BY INDEX ROWID BATCHED              | G_INDIVPARAM                  |     108 |   358 |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|   121 |                    INDEX RANGE SCAN                                | G_INDPAR_TYPSTR1_IDX          |    2152 |    17 |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|   122 |              HASH JOIN RIGHT OUTER                                 |                               |     508 |  305K |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|   123 |               VIEW                                                 |                               |     101 | 11824 |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|   124 |                SORT GROUP BY                                       |                               |     101 | 11824 |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|   125 |                 NESTED LOOPS                                       |                               |     101 | 11823 |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|   126 |                  NESTED LOOPS                                      |                               |   34440 | 11823 |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|   127 |                   NESTED LOOPS                                     |                               |     492 |     9 |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|   128 |                    NESTED LOOPS                                    |                               |       1 |     4 |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|   129 |                     FAST DUAL                                      |                               |       1 |     2 |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|   130 |                     FAST DUAL                                      |                               |       1 |     2 |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|   131 |                    MAT_VIEW ACCESS STORAGE FULL                    | AD_ACCOUNT_CLIENT_MVIEW       |     492 |     5 |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|   132 |                   INDEX RANGE SCAN                                 | NAM_COLLECTE_REFDOSS_IDX      |      70 |     2 |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|   133 |                  TABLE ACCESS BY INDEX ROWID                       | NAM_COLLECTE                  |       1 |    24 |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|   134 |               HASH JOIN RIGHT OUTER                                |                               |     508 |  293K |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|   135 |                VIEW                                                |                               |       1 |  2587 |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|   136 |                 NESTED LOOPS                                       |                               |       1 |  2587 |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|   137 |                  NESTED LOOPS                                      |                               |       1 |  2587 |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|   138 |                   VIEW                                             |                               |       1 |  2584 |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|   139 |                    HASH GROUP BY                                   |                               |       1 |  2584 |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|   140 |                     HASH JOIN                                      |                               |       1 |  2583 |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|   141 |                      JOIN FILTER CREATE                            | :BF0001                       |      90 |  2578 |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|   142 |                       TABLE ACCESS BY INDEX ROWID BATCHED          | G_PIECEDET                    |      90 |  2578 |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|   143 |                        INDEX RANGE SCAN                            | G_PIECEDET_TYPE_LASTLOAD_IDX  |   25591 |   202 |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|   144 |                      JOIN FILTER USE                               | :BF0001                       |     492 |     5 |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|   145 |                       MAT_VIEW ACCESS STORAGE FULL                 | AD_ACCOUNT_CLIENT_MVIEW       |     492 |     5 |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|   146 |                   INDEX UNIQUE SCAN                                | G_PIECEDET_PK                 |       1 |     2 |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|   147 |                  TABLE ACCESS BY INDEX ROWID                       | G_PIECEDET                    |       1 |     3 |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|   148 |                HASH JOIN RIGHT OUTER                               |                               |     508 |  291K |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|   149 |                 VIEW                                               |                               |       1 |  137K |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|   150 |                  HASH GROUP BY                                     |                               |       1 |  137K |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|   151 |                   HASH JOIN                                        |                               |       1 |  137K |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|   152 |                    JOIN FILTER CREATE                              | :BF0002                       |       5 |  137K |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|   153 |                     HASH JOIN                                      |                               |       5 |  137K |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|   154 |                      JOIN FILTER CREATE                            | :BF0003                       |     508 |     5 |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|   155 |                       VIEW                                         |                               |     508 |     5 |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|   156 |                        TABLE ACCESS STORAGE FULL                   | SYS_TEMP_0FD9E76B4_92BF0312   |     508 |     5 |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|   157 |                      JOIN FILTER USE                               | :BF0003                       |    712K |  137K |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|   158 |                       TABLE ACCESS STORAGE FULL                    | AD_PORTFOLIO_DETAIL           |    712K |  137K |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|   159 |                    VIEW                                            |                               |    667K |   103 |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|   160 |                     JOIN FILTER USE                                | :BF0002                       |    667K |   103 |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|   161 |                      TABLE ACCESS STORAGE FULL                     | SYS_TEMP_0FD9E76B5_92BF0312   |    667K |   103 |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|   162 |                 HASH JOIN RIGHT OUTER                              |                               |     508 |  154K |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|   163 |                  VIEW                                              |                               |       1 |  137K |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|   164 |                   HASH GROUP BY                                    |                               |       1 |  137K |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|   165 |                    HASH JOIN                                       |                               |       1 |  137K |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|   166 |                     JOIN FILTER CREATE                             | :BF0004                       |       5 |  137K |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|   167 |                      HASH JOIN                                     |                               |       5 |  137K |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|   168 |                       JOIN FILTER CREATE                           | :BF0005                       |     508 |     5 |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|   169 |                        VIEW                                        |                               |     508 |     5 |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|   170 |                         TABLE ACCESS STORAGE FULL                  | SYS_TEMP_0FD9E76B4_92BF0312   |     508 |     5 |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|   171 |                       JOIN FILTER USE                              | :BF0005                       |    712K |  137K |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|   172 |                        TABLE ACCESS STORAGE FULL                   | AD_PORTFOLIO_DETAIL           |    712K |  137K |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|   173 |                     VIEW                                           |                               |    667K |   103 |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|   174 |                      JOIN FILTER USE                               | :BF0004                       |    667K |   103 |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|   175 |                       TABLE ACCESS STORAGE FULL                    | SYS_TEMP_0FD9E76B5_92BF0312   |    667K |   103 |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|   176 |                  HASH JOIN RIGHT OUTER                             |                               |     508 | 16435 |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|   177 |                   VIEW                                             |                               |       1 |   793 |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|   178 |                    NESTED LOOPS                                    |                               |       1 |   793 |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|   179 |                     VIEW                                           |                               |     211 |   160 |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|   180 |                      HASH GROUP BY                                 |                               |     211 |   160 |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|   181 |                       FILTER                                       |                               |         |       |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|   182 |                        NESTED LOOPS                                |                               |     211 |   159 |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|   183 |                         FAST DUAL                                  |                               |       1 |     2 |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|   184 |                         TABLE ACCESS BY INDEX ROWID BATCHED        | AD_CLIENT_STATEMENT_HISTORY   |     211 |   157 |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|   185 |                          INDEX RANGE SCAN                          | PK_AD_CL_HISTORY              |     195 |     3 |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|   186 |                     VIEW                                           | AD_CLIENT_STATEMENT_HIST_VIEW |       1 |     3 |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|   187 |                      UNION-ALL PARTITION                           |                               |         |       |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|   188 |                       TABLE ACCESS BY INDEX ROWID                  | AD_CLIENT_STATEMENT_HISTORY   |       1 |     3 |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|   189 |                        INDEX UNIQUE SCAN                           | PK_AD_CL_HISTORY              |       1 |     2 |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|   190 |                       TABLE ACCESS BY INDEX ROWID                  | AD_CLIENT_STATEMENT_HIST_ARCH |       1 |     3 |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|   191 |                        INDEX UNIQUE SCAN                           | AD_CL_STM_ARCH_PK             |       1 |     2 |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|   192 |                   HASH JOIN RIGHT OUTER                            |                               |     508 | 15642 |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|   193 |                    VIEW                                            |                               |       1 |   798 |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|   194 |                     NESTED LOOPS                                   |                               |       1 |   798 |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|   195 |                      VIEW                                          |                               |     209 |   171 |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|   196 |                       HASH GROUP BY                                |                               |     209 |   171 |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|   197 |                        NESTED LOOPS                                |                               |     209 |   170 |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|   198 |                         FAST DUAL                                  |                               |       1 |     2 |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|   199 |                         TABLE ACCESS BY INDEX ROWID BATCHED        | AD_CLIENT_STATEMENT_HISTORY   |     209 |   168 |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|   200 |                          INDEX RANGE SCAN                          | PK_AD_CL_HISTORY              |     209 |     3 |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|   201 |                      VIEW                                          | AD_CLIENT_STATEMENT_HIST_VIEW |       1 |     3 |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|   202 |                       UNION-ALL PARTITION                          |                               |         |       |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|   203 |                        TABLE ACCESS BY INDEX ROWID                 | AD_CLIENT_STATEMENT_HISTORY   |       1 |     3 |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|   204 |                         INDEX UNIQUE SCAN                          | PK_AD_CL_HISTORY              |       1 |     2 |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|   205 |                        TABLE ACCESS BY INDEX ROWID                 | AD_CLIENT_STATEMENT_HIST_ARCH |       1 |     3 |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|   206 |                         INDEX UNIQUE SCAN                          | AD_CL_STM_ARCH_PK             |       1 |     2 |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|   207 |                    HASH JOIN RIGHT OUTER                           |                               |     508 | 14844 |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|   208 |                     VIEW                                           |                               |       1 |   804 |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|   209 |                      NESTED LOOPS                                  |                               |       1 |   804 |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|   210 |                       VIEW                                         |                               |     211 |   171 |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|   211 |                        HASH GROUP BY                               |                               |     211 |   171 |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|   212 |                         FILTER                                     |                               |         |       |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|   213 |                          NESTED LOOPS                              |                               |     211 |   170 |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|   214 |                           FAST DUAL                                |                               |       1 |     2 |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|   215 |                           TABLE ACCESS BY INDEX ROWID BATCHED      | AD_CLIENT_STATEMENT_HISTORY   |     211 |   168 |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|   216 |                            INDEX RANGE SCAN                        | PK_AD_CL_HISTORY              |     209 |     3 |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|   217 |                       VIEW                                         | AD_CLIENT_STATEMENT_HIST_VIEW |       1 |     3 |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|   218 |                        UNION-ALL PARTITION                         |                               |         |       |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|   219 |                         TABLE ACCESS BY INDEX ROWID                | AD_CLIENT_STATEMENT_HISTORY   |       1 |     3 |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|   220 |                          INDEX UNIQUE SCAN                         | PK_AD_CL_HISTORY              |       1 |     2 |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|   221 |                         TABLE ACCESS BY INDEX ROWID                | AD_CLIENT_STATEMENT_HIST_ARCH |       1 |     3 |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|   222 |                          INDEX UNIQUE SCAN                         | AD_CL_STM_ARCH_PK             |       1 |     2 |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|   223 |                     HASH JOIN RIGHT OUTER                          |                               |     508 | 14039 |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|   224 |                      VIEW                                          |                               |       1 | 14034 |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|   225 |                       NESTED LOOPS OUTER                           |                               |       1 | 14034 |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|   226 |                        HASH JOIN                                   |                               |       1 | 14033 |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|   227 |                         JOIN FILTER CREATE                         | :BF0006                       |       3 | 14028 |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|   228 |                          NESTED LOOPS                              |                               |       3 | 14028 |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|   229 |                           NESTED LOOPS                             |                               |      43 | 14028 |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|   230 |                            HASH JOIN                               |                               |      43 | 13861 |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|   231 |                             TABLE ACCESS BY INDEX ROWID BATCHED    | G_PIECE                       |     492 |   357 |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|   232 |                              INDEX RANGE SCAN                      | G_PIECE_TYPE_REFPIECE_INX     |     492 |     6 |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|   233 |                             VIEW                                   |                               |      43 | 13504 |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|   234 |                              WINDOW SORT PUSHED RANK               |                               |      43 | 13504 |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|   235 |                               HASH JOIN                            |                               |      43 | 13503 |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|   236 |                                TABLE ACCESS BY INDEX ROWID BATCHED | G_PIECEDET                    |   21248 | 13498 |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|   237 |                                 INDEX RANGE SCAN                   | GPDET_TYP_REF_IDX             |   28322 |   233 |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|   238 |                                VIEW                                |                               |     508 |     5 |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|   239 |                                 TABLE ACCESS STORAGE FULL          | SYS_TEMP_0FD9E76B4_92BF0312   |     508 |     5 |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|   240 |                            INDEX RANGE SCAN                        | GPDET_TYP_REF_IDX             |       1 |     3 |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|   241 |                           TABLE ACCESS BY INDEX ROWID              | G_PIECEDET                    |       1 |     4 |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|   242 |                         VIEW                                       |                               |     508 |     5 |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|   243 |                          JOIN FILTER USE                           | :BF0006                       |     508 |     5 |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|   244 |                           TABLE ACCESS STORAGE FULL                | SYS_TEMP_0FD9E76B4_92BF0312   |     508 |     5 |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|   245 |                        INDEX RANGE SCAN                            | V_DOMAINE_IND                 |       1 |     1 |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|   246 |                      VIEW                                          |                               |     508 |     5 |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|   247 |                       TABLE ACCESS STORAGE FULL                    | SYS_TEMP_0FD9E76B4_92BF0312   |     508 |     5 |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|   248 |           VIEW                                                     |                               |    143K |  125M |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|   249 |            HASH GROUP BY                                           |                               |    143K |  125M |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|   250 |             VIEW                                                   |                               |      2G |  100M |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|   251 |              JOIN FILTER USE                                       | :BF0000                       |      2G |  100M |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|   252 |               TABLE ACCESS STORAGE FULL                            | SYS_TEMP_0FD9E76B8_92BF0312   |      2G |  100M |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|   253 |       VIEW                                                         |                               |    143K |  116M |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|   254 |        HASH GROUP BY                                               |                               |    143K |  116M |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|   255 |         VIEW                                                       |                               |      2G |  100M |           |        |       |          |      |       |       |       |     . |    . |               |                             |
|   256 |          TABLE ACCESS STORAGE FULL                                 | SYS_TEMP_0FD9E76B8_92BF0312   |      2G |  100M |           |        |       |          |      |       |       |       |     . |    . |               |                             |
===============================================================================================================================================================================================================================================================


*/
/********************************OLD Metrics***************************************/

/********************************New SQL*******************************************/

WITH ReportPeriod AS
(SELECT trunc(to_date(:p_date, 'yyyy/mm/dd'), 'iw') - 7 Start_Date,
         trunc(to_date(:p_date, 'yyyy/mm/dd'), 'iw') - 1 / 86400 End_Date,
         to_char(trunc(to_date(:p_date, 'yyyy/mm/dd'), 'iw') - 7, 'j') Start_Date_j,
         to_char(trunc(to_date(:p_date, 'yyyy/mm/dd'), 'iw') - 1 / 86400, 'j') End_Date_j,
         to_char(to_date(:p_date, 'yyyy/mm/dd') - 7, 'iyyy-iw') Report_Period,
         to_char(to_date(:p_date, 'yyyy/mm/dd') - 7, 'iyyy') cal_year,
         to_char(to_date(:p_date, 'yyyy/mm/dd') - 7, 'iw') cal_week,
         trunc(ADD_MONTHS(to_date(:p_date, 'yyyy/mm/dd') - 7, -1), 'mm') last_month_start_date,
         LAST_DAY(trunc(ADD_MONTHS(to_date(:p_date, 'yyyy/mm/dd') - 7, -1), 'mm')) last_month_end_date,
         to_char(LAST_DAY(trunc(ADD_MONTHS(to_date(:p_date, 'yyyy/mm/dd') - 7, -1), 'mm')), 'j') last_month_end_date_j,
         trunc(ADD_MONTHS(to_date(:p_date, 'yyyy/mm/dd') - 7, -6), 'mm') last_6_month_start_date,
         trunc(ADD_MONTHS(to_date(:p_date, 'yyyy/mm/dd') - 7, -3), 'mm') last_3_month_start_date,
         to_char(trunc(ADD_MONTHS(to_date(:p_date, 'yyyy/mm/dd') - 7, -3), 'mm'), 'j') last_3_month_start_date_j,
         trunc(ADD_MONTHS(to_date(:p_date, 'yyyy/mm/dd') - 7, -12), 'mm') last_12_month_start_date,
         trunc(ADD_MONTHS(ADD_MONTHS(to_date(:p_date, 'yyyy/mm/dd') - 7, -3), -12), 'mm') last_3_month_last_year_start_date,
         to_char(trunc(ADD_MONTHS(ADD_MONTHS(to_date(:p_date, 'yyyy/mm/dd') - 7, -3), -12), 'mm'),'j') last_3_month_last_year_start_date_j,
         to_char(LAST_DAY(trunc(ADD_MONTHS(ADD_MONTHS(to_date(:p_date, 'yyyy/mm/dd') - 7, -1), -12),'mm')),'j') last_month_last_year_end_date_j,
         LAST_DAY(trunc(ADD_MONTHS(ADD_MONTHS(to_date(:p_date, 'yyyy/mm/dd') - 7, -1), -12), 'mm')) last_month_last_year_end_date
    FROM dual),
ReportPeriod_old AS
(SELECT trunc(ADD_MONTHS(ADD_MONTHS(trunc(SYSDATE, 'mm'), -1), -11)) Start_Date,
         trunc(ADD_MONTHS(ADD_MONTHS(trunc(SYSDATE, 'mm'), -1), -25)) Start_Date_2,
         trunc(LAST_DAY(ADD_MONTHS(trunc(SYSDATE, 'mm'), -1))) End_Date,
         to_char(trunc(ADD_MONTHS(ADD_MONTHS(trunc(SYSDATE, 'mm'), -1), -11)),'yyyymm') Start_month,
         to_char(trunc(ADD_MONTHS(ADD_MONTHS(trunc(SYSDATE, 'mm'), -1), -11)),'J') Start_date_Julian
    FROM dual)
/*SELECT * FROM ReportPeriod*/
,
all_days_last_3_month_current_year AS
(SELECT last_3_month_start_date,
         last_3_month_start_date_j,
         last_month_end_date,
         to_date(last_3_month_start_date_j + LEVEL - 1, 'J') AS day_of_month,
         to_char(to_date(last_3_month_start_date_j + LEVEL - 1, 'J'), 'J') AS day_of_month_j,
         to_char(to_date(last_3_month_start_date_j + LEVEL - 1, 'J'),
                 'yyyymm') MONTH,
         trunc(to_date(last_3_month_start_date_j + LEVEL - 1, 'J'), 'mm') first_calendar, -- des jeweiligen monats
         to_char(trunc(to_date(last_3_month_start_date_j + LEVEL - 1, 'J'),
                       'mm'),
                 'J') first_calendar_j -- des jeweiligen monats
    FROM ReportPeriod rp
  CONNECT BY last_3_month_start_date_j + LEVEL - 1 <=
             rp.last_month_end_date_j
   ORDER BY 1),
all_days_last_3_month_last_year AS
(SELECT last_3_month_last_year_start_date,
         last_3_month_last_year_start_date_j,
         last_month_last_year_end_date,
         to_date(last_3_month_last_year_start_date_j + LEVEL - 1, 'J') AS day_of_month,
         to_char(to_date(last_3_month_last_year_start_date_j + LEVEL - 1,
                         'J'),
                 'J') AS day_of_month_j,
         to_char(to_date(last_3_month_last_year_start_date_j + LEVEL - 1,
                         'J'),
                 'yyyymm') MONTH,
         trunc(to_date(last_3_month_last_year_start_date_j + LEVEL - 1, 'J'),
               'mm') first_calendar,
         to_char(trunc(to_date(last_3_month_last_year_start_date_j + LEVEL - 1,
                               'J'),
                       'mm'),
                 'J') first_calendar_j
    FROM ReportPeriod rp
  CONNECT BY last_3_month_last_year_start_date_j + LEVEL - 1 <=
             rp.last_month_last_year_end_date_j
   ORDER BY 1)
/*SELECT * FROM all_days_last_3_month_last_year

*/
,
period_list_subcontract AS
(SELECT rp.*,
         cla.CONTRACT_NUMBER,
         cla.REFLOT          AS iMX_Contract_Reference,
         cla.REFDOSS         AS iMX_Case_Reference,
         cla.DEVISE          AS currency,
         cla.CLIENT          AS iMX_Client_Reference,
         GP_FG06,
         contract_type,
         cl_nom              AS client_name,
         CLIENT_MANAGER_NOM,
         ACCOUNT_MANAGER_NOM,
         TEAM_ASSISTANT_NAME,
         MAXFIU
    FROM ReportPeriod rp, 
                 AD_ACCOUNT_CLIENT_MVIEW cla
   INNER JOIN AD_CASE_CONTRAT c
      ON c.ANCREFDOSS = cla.CONTRACT_NUMBER
  --  WHERE cla.CONTRACT_NUMBER = :p_contract_number
  --  AND c.ANCREFDOSS = :p_contract_number
  )
--SELECT * FROM period_list_subcontract
,
contract_status AS
(SELECT /*+no_merge no_push_pred LEADING(p) INDEX(p G_PIECE_TYPE_REFPIECE_INX) INDEX(PD GPDET_TYP_REF_IDX) USE_NL(PD) FULL(last_stus) USE_HASH(last_stus)*/
  --              last_stus.status as status,
  --            last_stus.rn,
   P.refpiece   as refpiece,
   P.refdoss    AS iMX_Case_Reference,
   vd.valeur_an AS status
  --              pd.*
    FROM period_list_subcontract status
    LEFT JOIN g_piecedet PD
      ON pd.refdoss = status.iMX_Case_Reference
    left join v_domaine vd
      ON pd.str1 = vd.abrev
     and vd.type = 'CONRSIT',
   (select /*+LEADING(a) INDEX(a GPDET_TYP_REF_IDX) INDEX(b V_DOMAINE_IND) USE_NL(b)*/
           a.str1 AS status,
           a.refpiece as refpiece,
           ROW_NUMBER() OVER(PARTITION BY a.refpiece ORDER BY imx_un_id DESC) AS rn
            from period_list_subcontract status
            LEFT JOIN g_piecedet a
              ON a.refdoss = status.iMX_Case_Reference
           where a.type = 'CONTRACT SITUATIONS') last_stus, g_piece p
   WHERE p.typpiece = 'SOUS-CONTRAT'
     AND PD.refpiece = P.refpiece
     AND PD.type = 'CONTRACT SITUATIONS'
        --      AND PD.STR1 in ('V','P')
     AND last_stus.refpiece = P.refpiece
     AND last_stus.rn = 1
     AND pd.str1 = last_stus.status
  --    AND p.refdoss = :p_case
  ),
FinancingRateLastRec AS
(SELECT pd.REFDOSS, MAX(pd.IMX_UN_ID) AS UN_ID
    FROM AD_ACCOUNT_CLIENT_MVIEW cla
    LEFT JOIN G_PIECEDET pd
      ON pd.refdoss = cla.refdoss
   WHERE pd.TYPE = 'FINRATE'
     AND pd.STR2 = 'PDEF'
     AND pd.DW_ACTION <> 'D'
   GROUP BY pd.REFDOSS),
FinancingRate AS
(SELECT pd.REFDOSS, pd.MT01 Financing_rate
    FROM G_PIECEDET pd
   INNER JOIN FinancingRateLastRec frlr
      ON frlr.un_id = pd.IMX_UN_ID
   WHERE pd.TYPE = 'FINRATE'
     AND pd.STR2 = 'PDEF'
  --  AND pd.refdoss = '0001010044' -- 0001010265 0001010468
  ),
TypeList AS
(SELECT a.ListType, a.ListArea, b.ListMult
    FROM (SELECT objectschema ListType, objectname ListArea
            FROM TABLE(sys.ODCIObjectList(sys.odciobject('CANCELLED PAYMENT',
                                                         'PAYMENT'),
                                          sys.odciobject('DEBTOR PAYMENT',
                                                         'PAYMENT'),
                                          sys.odciobject('DEBTOR REIMBURSEMENT',
                                                         'PAYMENT'),
                                          sys.odciobject('DEDUCTION',
                                                         'ADJUSTMENT'),
                                          sys.odciobject('FACTURE', 'INVOICE'),
                                          sys.odciobject('FACTURE CANCEL.',
                                                         'ADJUSTMENT'),
                                          sys.odciobject('NOTE DE CREDIT',
                                                         'CREDIT NOTE'),
                                          sys.odciobject('NOTE DE CREDIT CANCEL.',
                                                         'ADJUSTMENT'),
                                          sys.odciobject('OTHER DEBIT (SAF)',
                                                         'OTHER DEBIT'),
                                          sys.odciobject('RETROCESSION',
                                                         'ADJUSTMENT'),
                                          sys.odciobject('RETROCESSION NC',
                                                         'ADJUSTMENT'),
                                          sys.odciobject('UNDO ALLOCATION',
                                                         'PAYMENT'),
                                          sys.odciobject('UNDO DEDUCTION',
                                                         'ADJUSTMENT')))) a
    JOIN (SELECT objectschema ListType, objectname ListMult
           FROM TABLE(sys.ODCIObjectList(sys.odciobject('CANCELLED PAYMENT',
                                                        -1),
                                         sys.odciobject('DEBTOR PAYMENT', -1),
                                         sys.odciobject('DEBTOR REIMBURSEMENT',
                                                        -1),
                                         sys.odciobject('DEDUCTION', -1),
                                         sys.odciobject('FACTURE', 1),
                                         sys.odciobject('FACTURE CANCEL.', -1),
                                         sys.odciobject('NOTE DE CREDIT', -1),
                                         sys.odciobject('NOTE DE CREDIT CANCEL.',
                                                        -1),
                                         sys.odciobject('OTHER DEBIT (SAF)',
                                                        1),
                                         sys.odciobject('RETROCESSION', -1),
                                         sys.odciobject('RETROCESSION NC', -1),
                                         sys.odciobject('UNDO ALLOCATION', -1),
                                         sys.odciobject('UNDO DEDUCTION', -1)))) b
      ON b.ListType = a.ListType),
ClientAccount AS
(SELECT cla.FACTOR          iMX_Business_Unit,
         cla.REFDOSS         iMX_Case_Reference, -- Client Account
         cla.REFLOT          iMX_Contract_Reference, -- Contract
         cla.CONTRACT_NUMBER Contract_Number, -- Contract
         cla.DEVISE          Contract_Currency,
         cla.CLIENT          iMX_Client_Reference,
         cla.REFDOSSEXT      Subcontract_Number
    FROM AD_ACCOUNT_CLIENT_MVIEW cla
  --  WHERE cla.CONTRACT_NUMBER = :p_contract_number
  ),
ClientStatementDate AS -- Das letztverfügbare Statement für den Case ermitteln
(SELECT clst.CONTRACT_CASE iMX_Contract_Reference,
         clst.CL_ACCOUNT_CASE iMX_Case_Reference,
         MAX(clst.DATE_ID) Statement_Date
    FROM AD_CLIENT_STATEMENT_HISTORY clst, ReportPeriod rp
   WHERE clst.MEMO_SOURCE = 'A'
     AND clst.DATE_ID BETWEEN TRUNC(rp.Start_Date_j) AND
         TRUNC(rp.End_Date_j)
  --    AND clst.CL_ACCOUNT_CASE = :p_case
   GROUP BY clst.CONTRACT_CASE, clst.CL_ACCOUNT_CASE),
ClientStatementDate_week_bevore AS -- Das letztverfügbare Statement für den Case ermitteln
(SELECT clst.CONTRACT_CASE iMX_Contract_Reference,
         clst.CL_ACCOUNT_CASE iMX_Case_Reference,
         MAX(clst.DATE_ID) Statement_Date
    FROM AD_CLIENT_STATEMENT_HISTORY clst, ReportPeriod rp
   WHERE clst.MEMO_SOURCE = 'A'
     AND clst.DATE_ID BETWEEN TRUNC(rp.Start_Date_j - 7) AND
         TRUNC(rp.End_Date_j - 7)
   GROUP BY clst.CONTRACT_CASE, clst.CL_ACCOUNT_CASE),
ClientStatementDate_current AS -- Das letztverfügbare Statement für den Case ermitteln
(SELECT clst.CONTRACT_CASE iMX_Contract_Reference,
         clst.CL_ACCOUNT_CASE iMX_Case_Reference,
         MAX(clst.DATE_ID) Statement_Date
    FROM AD_CLIENT_STATEMENT_HISTORY clst, ReportPeriod rp
   WHERE clst.MEMO_SOURCE = 'A'
     AND clst.DATE_ID <= TRUNC(rp.End_Date_j)
   GROUP BY clst.CONTRACT_CASE, clst.CL_ACCOUNT_CASE),
ClientStatement AS
(
  -- 16.1.2023 am 31.12.2022: Rückwirkend da am 16.1. gestartet wurde --> der Satz muss weg
  -- Sind größteils nuller Sätze
  SELECT clst.CONTRACT_NUMBER,
          clst.CONTRACT_CASE iMX_Contract_Reference,
          clst.CL_ACCOUNT_CASE iMX_Case_Reference,
          to_date(clst.DATE_ID, 'j') datum,
          clst.date_id,
          (clst.FINANCING_BASE_EUR) Financing_Base,
          (clst.RETENTIONS_EUR) Retentions_eur,
          (clst.RETENTIONS) Retentions,
          -- clst.CURRENCY            Currency,
          (clst.BLOCKED_AMOUNT_EUR) Blocked_Amount_eur,
          (clst.BLOCKED_AMOUNT) Blocked_Amount,
          (clst.FUNDABLE_AMOUNT_EUR) Fundable_Amount,
          (clst.FIU) FIU,
          (clst.FIU_EUR) FIU_EUR,
          (clst.AVAILABILITY_EUR) Availability,
          (clst.NON_MATCHED_PAYMENTS_EUR) NonMatchedPayments,
          (clst.PORTFOLIO) Portfolio,
          (clst.PORTFOLIO_EUR) Portfolio_eur
    FROM AD_CLIENT_STATEMENT_HIST_VIEW clst, ClientStatementDate stmtd
   WHERE MEMO_SOURCE = 'A' -- A=Täglich; E=EOM
        --    AND CL_ACCOUNT_CASE = :p_case
     AND clst.CONTRACT_CASE = stmtd.iMX_Contract_Reference
     AND clst.CL_ACCOUNT_CASE = stmtd.iMX_Case_Reference
     AND clst.DATE_ID = stmtd.Statement_Date
  --GROUP BY 
  --  clst.CONTRACT_NUMBER, clst.CONTRACT_CASE, clst.CL_ACCOUNT_CASE
  ),
ClientStatement_current AS
(
  -- 16.1.2023 am 31.12.2022: Rückwirkend da am 16.1. gestartet wurde --> der Satz muss weg
  -- Sind größteils nuller Sätze
  SELECT clst.CONTRACT_NUMBER,
          clst.CONTRACT_CASE iMX_Contract_Reference,
          clst.CL_ACCOUNT_CASE iMX_Case_Reference,
          (clst.FINANCING_BASE_EUR) Financing_Base,
          (clst.RETENTIONS_EUR) Retentions_eur,
          (clst.RETENTIONS) Retentions,
          -- clst.CURRENCY            Currency,
          (clst.BLOCKED_AMOUNT_EUR) Blocked_Amount_eur,
          (clst.BLOCKED_AMOUNT) Blocked_Amount,
          (clst.FUNDABLE_AMOUNT_EUR) Fundable_Amount,
          (clst.FIU) FIU,
          (clst.FIU_EUR) FIU_EUR,
          (clst.AVAILABILITY) Availability,
          (clst.AVAILABILITY_EUR) Availability_eur,
          (clst.NON_MATCHED_PAYMENTS_EUR) NonMatchedPayments,
          (clst.PORTFOLIO) Portfolio,
          (clst.PORTFOLIO_EUR) Portfolio_eur
    FROM AD_CLIENT_STATEMENT_HIST_VIEW clst,
          ClientStatementDate_current   stmtd
   WHERE MEMO_SOURCE = 'A' -- A=Täglich; E=EOM
     AND clst.CONTRACT_CASE = stmtd.iMX_Contract_Reference
     AND clst.CL_ACCOUNT_CASE = stmtd.iMX_Case_Reference
     AND clst.DATE_ID = stmtd.Statement_Date
  --GROUP BY 
  --  clst.CONTRACT_NUMBER, clst.CONTRACT_CASE, clst.CL_ACCOUNT_CASE
  ),
ClientStatement_week_bevore AS
(
  -- 16.1.2023 am 31.12.2022: Rückwirkend da am 16.1. gestartet wurde --> der Satz muss weg
  -- Sind größteils nuller Sätze
  SELECT clst.CONTRACT_NUMBER,
          clst.CONTRACT_CASE iMX_Contract_Reference,
          clst.CL_ACCOUNT_CASE iMX_Case_Reference,
          (clst.FINANCING_BASE_EUR) Financing_Base,
          (clst.RETENTIONS_EUR) Retentions_eur,
          (clst.RETENTIONS) Retentions,
          -- clst.CURRENCY            Currency,
          (clst.BLOCKED_AMOUNT_EUR) Blocked_Amount_eur,
          (clst.BLOCKED_AMOUNT) Blocked_Amount,
          (clst.FUNDABLE_AMOUNT_EUR) Fundable_Amount,
          (clst.FIU) FIU,
          (clst.FIU_EUR) FIU_EUR,
          (clst.AVAILABILITY_EUR) Availability,
          (clst.NON_MATCHED_PAYMENTS_EUR) NonMatchedPayments,
          (clst.PORTFOLIO) Portfolio,
          (clst.PORTFOLIO_EUR) Portfolio_eur
    FROM AD_CLIENT_STATEMENT_HIST_VIEW   clst,
          ClientStatementDate_week_bevore stmtd
   WHERE MEMO_SOURCE = 'A' -- A=Täglich; E=EOM
     AND clst.CONTRACT_CASE = stmtd.iMX_Contract_Reference
     AND clst.CL_ACCOUNT_CASE = stmtd.iMX_Case_Reference
     AND clst.DATE_ID = stmtd.Statement_Date
  --GROUP BY 
  --  clst.CONTRACT_NUMBER, clst.CONTRACT_CASE, clst.CL_ACCOUNT_CASE
  ),
ClientStatement_days AS
(SELECT days.last_3_month_start_date   AS start_date,
         days.last_3_month_start_date_j AS start_date_j,
         days.day_of_month,
         days.day_of_month_j,
         ca.CONTRACT_NUMBER,
         ca.iMX_Contract_Reference, -- Contract
         ca.iMX_Case_Reference -- Client Account
    FROM all_days_last_3_month_current_year days, ClientAccount ca),
ClientStatement_days_last_year AS
(SELECT days.last_3_month_last_year_start_date   AS start_date,
         days.last_3_month_last_year_start_date_j AS start_date_j,
         days.day_of_month,
         days.day_of_month_j,
         ca.CONTRACT_NUMBER,
         ca.iMX_Contract_Reference, -- Contract
         ca.iMX_Case_Reference -- Client Account
    FROM all_days_last_3_month_last_year days, ClientAccount ca),
ClientStatement_days_prep AS
(SELECT days.START_date,
         days.START_date_j,
         days.day_of_month,
         days.day_of_month_j,
         days.CONTRACT_NUMBER,
         days.iMX_Contract_Reference,
         days.iMX_Case_Reference,
         clst.DATE_ID,
         fiu,
         FUNDABLE_AMOUNT,
         PORTFOLIO,
         RETENTIONS,
         fiu_EUR,
         FUNDABLE_AMOUNT_EUR,
         PORTFOLIO_EUR,
         RETENTIONS_EUR
    FROM ClientStatement_days days
    LEFT JOIN AD_CLIENT_STATEMENT_HIST_VIEW clst
      ON clst.CONTRACT_NUMBER = days.CONTRACT_NUMBER
     AND clst.CONTRACT_CASE = days.iMX_Contract_Reference
     AND clst.CL_ACCOUNT_CASE = days.iMX_Case_Reference
     and clst.DATE_ID = days.day_of_month_j
     AND clst.MEMO_SOURCE = 'A' -- (=Not EOM)
  ),
ClientStatement_days_prep_last_year AS
(SELECT days.START_date,
         days.START_date_j,
         days.day_of_month,
         days.day_of_month_j,
         days.CONTRACT_NUMBER,
         days.iMX_Contract_Reference,
         days.iMX_Case_Reference,
         clst.DATE_ID,
         fiu,
         FUNDABLE_AMOUNT,
         PORTFOLIO,
         RETENTIONS,
         fiu_EUR,
         FUNDABLE_AMOUNT_EUR,
         PORTFOLIO_EUR,
         RETENTIONS_EUR
    FROM ClientStatement_days_last_year days
    LEFT JOIN AD_CLIENT_STATEMENT_HIST_VIEW clst
      ON clst.CONTRACT_NUMBER = days.CONTRACT_NUMBER
     AND clst.CONTRACT_CASE = days.iMX_Contract_Reference
     AND clst.CL_ACCOUNT_CASE = days.iMX_Case_Reference
     and clst.DATE_ID = days.day_of_month_j
     AND clst.MEMO_SOURCE = 'A' -- (=Not EOM)
  ),
ClientStatement_days_previous_prep AS
(SELECT days.start_date,
         days.start_date_j,
         days.day_of_month,
         days.day_of_month_j,
         days.CONTRACT_NUMBER,
         days.iMX_Contract_Reference,
         days.iMX_Case_Reference,
         max(clst.DATE_ID) AS previous_statement_date
    FROM ClientStatement_days_prep days
    LEFT JOIN AD_CLIENT_STATEMENT_HIST_VIEW clst
      ON clst.CONTRACT_NUMBER = days.CONTRACT_NUMBER
     AND clst.CONTRACT_CASE = days.iMX_Contract_Reference
     AND clst.CL_ACCOUNT_CASE = days.iMX_Case_Reference
     AND clst.DATE_ID <= days.day_of_month_j
     AND clst.date_id >= days.start_date_j
     AND trunc(clst.dt04_dt) >= to_date('2022-09-01', 'yyyy-mm-dd')
     AND clst.MEMO_SOURCE = 'A' -- (=Not EOM)
   WHERE days.date_id IS NULL
   GROUP BY days.start_date,
            days.start_date_j,
            days.day_of_month,
            days.day_of_month_j,
            days.CONTRACT_NUMBER,
            days.iMX_Contract_Reference,
            days.iMX_Case_Reference),
ClientStatement_days_previous_prep_last_year AS
(SELECT days.start_date,
         days.start_date_j,
         days.day_of_month,
         days.day_of_month_j,
         days.CONTRACT_NUMBER,
         days.iMX_Contract_Reference,
         days.iMX_Case_Reference,
         max(clst.DATE_ID) AS previous_statement_date
    FROM ClientStatement_days_prep_last_year days
    LEFT JOIN AD_CLIENT_STATEMENT_HIST_VIEW clst
      ON clst.CONTRACT_NUMBER = days.CONTRACT_NUMBER
     AND clst.CONTRACT_CASE = days.iMX_Contract_Reference
     AND clst.CL_ACCOUNT_CASE = days.iMX_Case_Reference
     AND clst.DATE_ID <= days.day_of_month_j
     AND clst.date_id >= days.start_date_j
     AND trunc(clst.dt04_dt) >= to_date('2022-09-01', 'yyyy-mm-dd')
     AND clst.MEMO_SOURCE = 'A' -- (=Not EOM)
   WHERE days.date_id IS NULL
   GROUP BY days.start_date,
            days.start_date_j,
            days.day_of_month,
            days.day_of_month_j,
            days.CONTRACT_NUMBER,
            days.iMX_Contract_Reference,
            days.iMX_Case_Reference),
ClientStatement_days_previous AS
(SELECT days.start_date,
         days.start_date_j,
         days.day_of_month,
         days.day_of_month_j,
         days.CONTRACT_NUMBER,
         days.iMX_Contract_Reference,
         days.iMX_Case_Reference,
         clst.DATE_ID,
         fiu,
         FUNDABLE_AMOUNT,
         PORTFOLIO,
         RETENTIONS,
         fiu_EUR,
         FUNDABLE_AMOUNT_EUR,
         PORTFOLIO_EUR,
         RETENTIONS_EUR
    FROM ClientStatement_days_previous_prep days
    LEFT JOIN AD_CLIENT_STATEMENT_HIST_VIEW clst
      ON clst.CONTRACT_NUMBER = days.CONTRACT_NUMBER
     AND clst.CONTRACT_CASE = days.iMX_Contract_Reference
     AND clst.CL_ACCOUNT_CASE = days.iMX_Case_Reference
     AND clst.DATE_ID = days.previous_statement_date
     AND clst.MEMO_SOURCE = 'A'),
ClientStatement_days_previous_last_year AS
(SELECT days.start_date,
         days.start_date_j,
         days.day_of_month,
         days.day_of_month_j,
         days.CONTRACT_NUMBER,
         days.iMX_Contract_Reference,
         days.iMX_Case_Reference,
         clst.DATE_ID,
         fiu,
         FUNDABLE_AMOUNT,
         PORTFOLIO,
         RETENTIONS,
         fiu_EUR,
         FUNDABLE_AMOUNT_EUR,
         PORTFOLIO_EUR,
         RETENTIONS_EUR
    FROM ClientStatement_days_previous_prep_last_year days
    LEFT JOIN AD_CLIENT_STATEMENT_HIST_VIEW clst
      ON clst.CONTRACT_NUMBER = days.CONTRACT_NUMBER
     AND clst.CONTRACT_CASE = days.iMX_Contract_Reference
     AND clst.CL_ACCOUNT_CASE = days.iMX_Case_Reference
     AND clst.DATE_ID = days.previous_statement_date
     AND clst.MEMO_SOURCE = 'A'),
ClientStatement_all_days AS
(SELECT *
    FROM ClientStatement_days_prep
   WHERE date_id IS NOT NULL
  UNION ALL
  SELECT *
    FROM ClientStatement_days_previous),
ClientStatement_all_days_last_year AS
(SELECT *
    FROM ClientStatement_days_prep_last_year
   WHERE date_id IS NOT NULL
  UNION ALL
  SELECT *
    FROM ClientStatement_days_previous_last_year),
ClientStatement_avg_until_begin AS
(SELECT max(clst.day_of_month_j) - min(clst.start_date_j) days_from_begin,
         min(clst.day_of_month) start_date,
         max(clst.day_of_month) end_date,
         clst.iMX_Contract_Reference,
         clst.iMX_Case_Reference,
         avg(clst.FIU) FIU,
         avg(clst.FUNDABLE_AMOUNT) FUNDABLE_AMOUNT,
         avg(clst.PORTFOLIO) PORTFOLIO,
         avg(clst.FIU_EUR) FIU_EUR,
         avg(clst.FUNDABLE_AMOUNT_EUR) FUNDABLE_AMOUNT_EUR,
         avg(clst.PORTFOLIO_EUR) PORTFOLIO_EUR
    FROM ClientStatement_all_days clst
   WHERE clst.fiu IS NOT NULL
   GROUP BY clst.iMX_Contract_Reference, clst.iMX_Case_Reference),
ClientStatement_avg_until_begin_last_year AS
(SELECT max(clst.day_of_month_j) - min(clst.start_date_j) days_from_begin,
         min(clst.day_of_month) start_date,
         max(clst.day_of_month) end_date,
         clst.iMX_Contract_Reference,
         clst.iMX_Case_Reference,
         avg(clst.FIU) FIU,
         avg(clst.FUNDABLE_AMOUNT) FUNDABLE_AMOUNT,
         avg(clst.PORTFOLIO) PORTFOLIO,
         avg(clst.FIU_EUR) FIU_EUR,
         avg(clst.FUNDABLE_AMOUNT_EUR) FUNDABLE_AMOUNT_EUR,
         avg(clst.PORTFOLIO_EUR) PORTFOLIO_EUR
    FROM ClientStatement_all_days_last_year clst
   WHERE clst.fiu IS NOT NULL
   GROUP BY clst.iMX_Contract_Reference, clst.iMX_Case_Reference),
PortfolioDetails_prep AS
(SELECT /*+ no_merge no_push_pred use_hash(pd) merge(pd) */
        pl.contract_number,
         pl.imx_contract_reference,
         pl.imx_case_reference,
         tl.ListArea,
         --    pd.AMOUNT_CPT * tl.ListMult ListSum, -- AMOUNT_ACCY --> IN BU Currency (â‚¬)
         CASE
           WHEN (trunc(pd.TECR_DTJOUR_DT) BETWEEN pl.Start_Date AND
                pl.End_Date) THEN
            CH_TAUX.CONV_ORIG_DEST_TX(to_char(sysdate, 'J'),
                                      pd.AMOUNT_CPT * tl.ListMult,
                                      pl.Currency,
                                      'EUR',
                                      'MR',
                                      NULL)
         END AS last_week_ListSum_EUR,
         CASE
           WHEN (trunc(pd.TECR_DTJOUR_DT) BETWEEN pl.last_12_month_start_date AND
                pl.last_month_end_date) THEN
            CH_TAUX.CONV_ORIG_DEST_TX(to_char(sysdate, 'J'),
                                      pd.AMOUNT_CPT * tl.ListMult,
                                     pl.Currency,
                                      'EUR',
                                      'MR',
                                      NULL)
         END AS last_12_month_ListSum_EUR,
         CASE
           WHEN (trunc(pd.TECR_DTJOUR_DT) BETWEEN pl.last_6_month_start_date AND
                pl.last_month_end_date) THEN
            CH_TAUX.CONV_ORIG_DEST_TX(to_char(sysdate, 'J'),
                                      pd.AMOUNT_CPT * tl.ListMult,
                                      pl.Currency,
                                      'EUR',
                                      'MR',
                                      NULL)
         END AS last_6_month_ListSum_EUR,
         CASE
           WHEN (trunc(pd.TECR_DTJOUR_DT) BETWEEN pl.last_month_start_date AND
                pl.last_month_end_date) THEN
            CH_TAUX.CONV_ORIG_DEST_TX(to_char(sysdate, 'J'),
                                      pd.AMOUNT_CPT * tl.ListMult,
                                      pl.Currency,
                                      'EUR',
                                      'MR',
                                      NULL)
         END AS last_month_ListSum_EUR,
         CASE
           WHEN (trunc(pd.TECR_DTJOUR_DT) BETWEEN pl.last_3_month_start_date AND
                pl.last_month_end_date) THEN
            CH_TAUX.CONV_ORIG_DEST_TX(to_char(sysdate, 'J'),
                                      pd.AMOUNT_CPT * tl.ListMult,
                                      pl.Currency,
                                      'EUR',
                                      'MR',
                                      NULL)
         END AS last_3_month_ListSum_eur,
         CASE
           WHEN (trunc(pd.TECR_DTJOUR_DT) BETWEEN
                pl.last_3_month_last_year_start_date AND
                pl.last_month_last_year_end_date) THEN
            CH_TAUX.CONV_ORIG_DEST_TX(to_char(sysdate, 'J'),
                                      pd.AMOUNT_CPT * tl.ListMult,
                                      pl.Currency,
                                      'EUR',
                                      'MR',
                                      NULL)
         END AS last_3_month_last_year_ListSum_eur,
         --
         CASE
           WHEN (trunc(pd.TECR_DTJOUR_DT) BETWEEN pl.Start_Date AND
                pl.End_Date) THEN
            pd.AMOUNT_CPT * tl.ListMult
         END AS last_week_ListSum,
         CASE
           WHEN (trunc(pd.TECR_DTJOUR_DT) BETWEEN pl.last_12_month_start_date AND
                pl.last_month_end_date) THEN
            pd.AMOUNT_CPT * tl.ListMult
         END AS last_12_month_ListSum,
         CASE
           WHEN (trunc(pd.TECR_DTJOUR_DT) BETWEEN pl.last_6_month_start_date AND
                pl.last_month_end_date) THEN
            pd.AMOUNT_CPT * tl.ListMult
         END AS last_6_month_ListSum,
         CASE
           WHEN (trunc(pd.TECR_DTJOUR_DT) BETWEEN pl.last_3_month_start_date AND
                pl.last_month_end_date) THEN
            pd.AMOUNT_CPT * tl.ListMult
         END AS last_3_month_ListSum,
         CASE
           WHEN (trunc(pd.TECR_DTJOUR_DT) BETWEEN
                pl.last_3_month_last_year_start_date AND
                pl.last_month_last_year_end_date) THEN
            pd.AMOUNT_CPT * tl.ListMult
         END AS last_3_month_last_year_ListSum,
         CASE
           WHEN (trunc(pd.TECR_DTJOUR_DT) BETWEEN pl.last_month_start_date AND
                pl.last_month_end_date) THEN
            pd.AMOUNT_CPT * tl.ListMult
         END AS last_month_ListSum
  --    tl.ListMult
    FROM period_list_subcontract pl,
         AD_PORTFOLIO_DETAIL pd,
                        TypeList tl
   where pd.SUBCONTRACT_CASE(+) = pl.imx_case_reference
     AND ((trunc(pd.TECR_DTJOUR_DT) >= pl.last_3_month_last_year_start_date AND
         trunc(pd.TECR_DTJOUR_DT) <= pl.last_month_end_date) OR
         (trunc(pd.TECR_DTJOUR_DT) >= pl.Start_Date AND
         trunc(pd.TECR_DTJOUR_DT) <= pl.End_Date))
     and tl.ListType(+) = pd."TYPE"
     and tl.ListArea <> '?'),
PortfolioDetails AS
(SELECT pfd.iMX_Contract_Reference,
         pfd.iMX_Case_Reference, -- Client Account
         pfd.ListArea,
         last_week_ListSum_EUR,
         last_12_month_ListSum_EUR,
         last_6_month_ListSum_EUR,
         last_month_ListSum_EUR,
         LAST_3_MONTH_LAST_YEAR_LISTSUM_EUR,
         LAST_3_MONTH_LISTSUM_EUR
    FROM PortfolioDetails_prep pfd),
PortfolioDetails_sum_until_begin AS
(SELECT to_char(min(pfd.TECR_DTJOUR_DT), 'J') as first_available_day_J,
         min(pfd.TECR_DTJOUR_DT) as first_available_day,
         max(pfd.TECR_DTJOUR_DT) as last_available_day,
         pl.last_3_month_start_date,
         pl.last_3_month_start_date_j,
         pl.last_month_end_date eom,
         pl.iMX_Contract_Reference,
         pl.iMX_Case_Reference, -- Client Account
         SUM(pfd.AMOUNT_CPT * tl.ListMult) AS SumOfInvoices,
         SUM(CH_TAUX.CONV_ORIG_DEST_TX(to_char(sysdate, 'J'),
                                       pfd.AMOUNT_CPT * tl.ListMult,
                                       pl.Currency,
                                       'EUR',
                                       'MR',
                                       NULL)) AS SumOfInvoices_EUR
    FROM period_list_subcontract pl
    LEFT JOIN AD_PORTFOLIO_DETAIL pfd
      ON pfd.cap_case = pl.imx_contract_reference
     AND pfd.SUBCONTRACT_CASE = pl.imx_case_reference
     AND pfd.TECR_DTJOUR_DT <= pl.last_month_end_date
     AND pfd.TECR_DTJOUR_DT >= pl.last_3_month_start_date
     AND trunc(pfd.TECR_DTJOUR_DT) >= to_date('2022-09-01', 'yyyy-mm-dd')
    LEFT JOIN TypeList tl
      ON tl.ListType = pfd."TYPE"
   WHERE tl.ListArea = 'INVOICE'
   GROUP BY pl.last_3_month_start_date,
            pl.last_3_month_start_date_j,
            pl.last_month_end_date,
            pl.iMX_Contract_Reference,
            pl.imx_case_reference),
PortfolioDetails_sum_until_begin_last_year AS
(SELECT to_char(min(pfd.TECR_DTJOUR_DT), 'J') as first_available_day_J,
         min(pfd.TECR_DTJOUR_DT) as first_available_day,
         max(pfd.TECR_DTJOUR_DT) as last_available_day,
         pl.last_3_month_last_year_start_date,
         pl.last_3_month_last_year_start_date_j,
         pl.last_month_last_year_end_date eom,
         pl.iMX_Contract_Reference,
         pl.iMX_Case_Reference, -- Client Account
         SUM(pfd.AMOUNT_CPT * tl.ListMult) AS SumOfInvoices,
         SUM(CH_TAUX.CONV_ORIG_DEST_TX(to_char(sysdate, 'J'),
                                       pfd.AMOUNT_CPT * tl.ListMult,
                                       pl.Currency,
                                       'EUR',
                                       'MR',
                                       NULL)) AS SumOfInvoices_EUR
    FROM period_list_subcontract pl
    LEFT JOIN AD_PORTFOLIO_DETAIL pfd
      ON pfd.cap_case = pl.imx_contract_reference
     AND pfd.SUBCONTRACT_CASE = pl.imx_case_reference
     AND pfd.TECR_DTJOUR_DT <= pl.last_month_last_year_end_date
     AND pfd.TECR_DTJOUR_DT >= pl.last_3_month_last_year_start_date
     AND trunc(pfd.TECR_DTJOUR_DT) >= to_date('2022-09-01', 'yyyy-mm-dd')
    LEFT JOIN TypeList tl
      ON tl.ListType = pfd."TYPE"
   WHERE tl.ListArea = 'INVOICE'
   GROUP BY pl.last_3_month_last_year_start_date,
            pl.last_3_month_last_year_start_date_j,
            pl.last_month_last_year_end_date,
            pl.iMX_Contract_Reference,
            pl.imx_case_reference),
PortfolioDetailsSum AS
(SELECT iMX_Contract_Reference,
         iMX_Case_Reference,
         SUM(CASE
               WHEN ListArea = 'INVOICE' THEN
                last_week_ListSum_EUR
             END) AS SumOfInvoices,
         SUM(CASE
               WHEN ListArea = 'CREDIT NOTE' THEN
                last_week_ListSum_EUR
             END) AS SumOfCreditNotes,
         SUM(CASE
               WHEN ListArea = 'ADJUSTMENT' THEN
                last_week_ListSum_EUR
             END) AS SumOfAdjustments,
         SUM(CASE
               WHEN ListArea = 'PAYMENT' THEN
                last_week_ListSum_EUR
             END) AS SumOfPayments,
         SUM(CASE
               WHEN ListArea = 'OTHER DEBIT' THEN
                last_week_ListSum_EUR
             END) AS SumOfOtherDebits,
         --
         SUM(CASE
               WHEN ListArea = 'INVOICE' THEN
                last_12_month_ListSum_EUR
             END) AS last_12_month_SumOfInvoices,
         SUM(CASE
               WHEN ListArea = 'CREDIT NOTE' THEN
                last_12_month_ListSum_EUR
             END) AS last_12_month_SumOfCreditNotes,
         SUM(CASE
               WHEN ListArea = 'ADJUSTMENT' THEN
                last_12_month_ListSum_EUR
             END) AS last_12_month_SumOfAdjustments,
         SUM(CASE
               WHEN ListArea = 'PAYMENT' THEN
                last_12_month_ListSum_EUR
             END) AS last_12_month_SumOfPayments,
         SUM(CASE
               WHEN ListArea = 'OTHER DEBIT' THEN
                last_12_month_ListSum_EUR
             END) AS last_12_month_SumOfOtherDebits,
         --
         SUM(CASE
               WHEN ListArea = 'INVOICE' THEN
                last_6_month_ListSum_EUR
             END) AS last_6_month_SumOfInvoices,
         SUM(CASE
               WHEN ListArea = 'CREDIT NOTE' THEN
                last_6_month_ListSum_EUR
             END) AS last_6_month_SumOfCreditNotes,
         SUM(CASE
               WHEN ListArea = 'ADJUSTMENT' THEN
                last_6_month_ListSum_EUR
             END) AS last_6_month_SumOfAdjustments,
         SUM(CASE
               WHEN ListArea = 'PAYMENT' THEN
                last_6_month_ListSum_EUR
             END) AS last_6_month_SumOfPayments,
         SUM(CASE
               WHEN ListArea = 'OTHER DEBIT' THEN
                last_6_month_ListSum_EUR
             END) AS last_6_month_SumOfOtherDebits,
         --
         SUM(CASE
               WHEN ListArea = 'INVOICE' THEN
                last_3_month_ListSum_EUR
             END) AS last_3_month_SumOfInvoices,
         SUM(CASE
               WHEN ListArea = 'CREDIT NOTE' THEN
                last_3_month_ListSum_EUR
             END) AS last_3_month_SumOfCreditNotes,
         SUM(CASE
               WHEN ListArea = 'ADJUSTMENT' THEN
                last_3_month_ListSum_EUR
             END) AS last_3_month_SumOfAdjustments,
         SUM(CASE
               WHEN ListArea = 'PAYMENT' THEN
                last_3_month_ListSum_EUR
             END) AS last_3_month_SumOfPayments,
         SUM(CASE
               WHEN ListArea = 'OTHER DEBIT' THEN
                last_3_month_ListSum_EUR
             END) AS last_3_month_SumOfOtherDebits,
         --
         SUM(CASE
               WHEN ListArea = 'INVOICE' THEN
                last_3_month_last_year_ListSum_EUR
             END) AS last_3_month_last_year_SumOfInvoices,
         SUM(CASE
               WHEN ListArea = 'CREDIT NOTE' THEN
                last_3_month_last_year_ListSum_EUR
             END) AS last_3_month_last_year_SumOfCreditNotes,
         SUM(CASE
               WHEN ListArea = 'ADJUSTMENT' THEN
                last_3_month_last_year_ListSum_EUR
             END) AS last_3_month_last_year_SumOfAdjustments,
         SUM(CASE
               WHEN ListArea = 'PAYMENT' THEN
                last_3_month_last_year_ListSum_EUR
             END) AS last_3_month_last_year_SumOfPayments,
         SUM(CASE
               WHEN ListArea = 'OTHER DEBIT' THEN
                last_3_month_last_year_ListSum_EUR
             END) AS last_3_month_last_year_SumOfOtherDebits,
         --
         SUM(CASE
               WHEN ListArea = 'INVOICE' THEN
                last_month_ListSum_EUR
             END) AS last_month_SumOfInvoices,
         SUM(CASE
               WHEN ListArea = 'CREDIT NOTE' THEN
                last_month_ListSum_EUR
             END) AS last_month_SumOfCreditNotes,
         SUM(CASE
               WHEN ListArea = 'ADJUSTMENT' THEN
                last_month_ListSum_EUR
             END) AS last_month_SumOfAdjustments,
         SUM(CASE
               WHEN ListArea = 'PAYMENT' THEN
                last_month_ListSum_EUR
             END) AS last_month_SumOfPayments,
         SUM(CASE
               WHEN ListArea = 'OTHER DEBIT' THEN
                last_month_ListSum_EUR
             END) AS last_month_SumOfOtherDebits
    FROM PortfolioDetails
   GROUP BY iMX_Contract_Reference, iMX_Case_Reference),
new_receivables_other_debit AS
(SELECT pfd.iMX_Contract_Reference,
         pfd.iMX_Case_Reference,
         SUM(pfd.last_12_month_listsum) ListSum
    FROM PortfolioDetails_prep pfd
   WHERE pfd.listarea IN ('INVOICE', 'OTHER DEBIT')
   GROUP BY pfd.iMX_Contract_Reference, pfd.iMX_Case_Reference),
SAF_CIT_details AS
(SELECT cla.iMX_Contract_Reference,
         cla.iMX_Case_Reference,
         bfd.TYPMVT,
         CASE
           WHEN bfd.TYPMVT LIKE 'pmtSAF%' THEN
            CASE
              WHEN bfd.SIGNE = 1 THEN
               bfd.MONTANT
              ELSE
               (bfd.MONTANT * -1)
            END
         END CITAdjustments,
         CASE
           WHEN bfd.TYPMVT LIKE 'encSAF%' THEN
            CASE
              WHEN bfd.SIGNE = 0 THEN
               bfd.MONTANT
              ELSE
               (bfd.MONTANT * -1)
            END
         END payments_on_bank_account
    FROM ReportPeriod rp
   INNER JOIN NAM_COLLECTE bfd
      ON trunc(bfd.DTVENTIL_DT) BETWEEN TRUNC(rp.Start_Date) AND
         TRUNC(rp.End_Date)
   INNER JOIN ClientAccount cla
      ON cla.iMX_Case_Reference = bfd.REFDOSS
   WHERE bfd.TYPMVT IN ('pmtSAF_sd_deduc',
                        'pmtSAF_ajust',
                        'encSAF',
                        'encSAF_col',
                        'encSAF_derec')
  --AND TRUNC(bfd.DTVENTIL_DT) BETWEEN TRUNC(rp.Start_Date) AND TRUNC(rp.End_Date) 
   ORDER BY cla.iMX_Contract_Reference),
SAF_CIT_PREP AS
(SELECT cla.iMX_Contract_Reference,
         cla.iMX_Case_Reference,
         bfd.DTVENTIL_DT,
         CASE
           WHEN bfd.TYPMVT LIKE 'pmtSAF%' THEN
            CASE
              WHEN bfd.SIGNE = 1 THEN
               bfd.MONTANT
              ELSE
               (bfd.MONTANT * -1)
            END
         END CITAdjustments,
         CASE
           WHEN bfd.TYPMVT LIKE 'encSAF%' THEN
            CASE
              WHEN bfd.SIGNE = 0 THEN
               bfd.MONTANT
              ELSE
               (bfd.MONTANT * -1)
            END
         END payments_on_bank_account,
         CASE
           WHEN bfd.TYPMVT LIKE 'pmtSAF%' THEN
            CASE
              WHEN bfd.SIGNE = 1 THEN
               bfd.MONTANT2
              ELSE
               (bfd.MONTANT2 * -1)
            END
         END CITAdjustments_EUR,
         CASE
           WHEN bfd.TYPMVT LIKE 'encSAF%' THEN
            CASE
              WHEN bfd.SIGNE = 0 THEN
               bfd.MONTANT2
              ELSE
               (bfd.MONTANT2 * -1)
            END
         END payments_on_bank_account_EUR
    FROM ReportPeriod rp
   INNER JOIN NAM_COLLECTE bfd
  --ON trunc(bfd.DTVENTIL_DT) BETWEEN TRUNC(rp.Start_Date) AND TRUNC(rp.End_Date)
      ON ((trunc(bfd.DTVENTIL_DT) >= rp.last_12_month_start_date AND
         trunc(bfd.DTVENTIL_DT) <= rp.last_month_end_date) OR
         (trunc(bfd.DTVENTIL_DT) >= rp.Start_Date AND
         trunc(bfd.DTVENTIL_DT) <= rp.End_Date))
   INNER JOIN ClientAccount cla
      ON cla.iMX_Case_Reference = bfd.REFDOSS
   WHERE bfd.TYPMVT IN ('pmtSAF_sd_deduc',
                        'pmtSAF_ajust',
                        'encSAF',
                        'encSAF_col',
                        'encSAF_derec')
  --AND TRUNC(bfd.DTVENTIL_DT) BETWEEN TRUNC(rp.Start_Date) AND TRUNC(rp.End_Date) 
   ORDER BY cla.iMX_Contract_Reference),
SAF_CIT AS
(SELECT iMX_Contract_Reference,
         iMX_Case_Reference,
         Sum(CASE
               WHEN (trunc(DTVENTIL_DT) BETWEEN rp.Start_Date AND rp.End_Date) THEN
                CITAdjustments
             END) last_week_CITAdjustments,
         Sum(CASE
               WHEN (trunc(DTVENTIL_DT) BETWEEN rp.Start_Date AND rp.End_Date) THEN
                CITAdjustments_EUR
             END) last_week_CITAdjustments_EUR,
         Sum(CASE
               WHEN (trunc(DTVENTIL_DT) BETWEEN rp.Start_Date AND rp.End_Date) THEN
                payments_on_bank_account
             END) last_week_payments_on_bank_account,
         Sum(CASE
               WHEN (trunc(DTVENTIL_DT) BETWEEN rp.Start_Date AND rp.End_Date) THEN
                payments_on_bank_account_EUR
             END) last_week_payments_on_bank_account_EUR,
         --
         Sum(CASE
               WHEN (trunc(DTVENTIL_DT) BETWEEN rp.last_12_month_start_date AND
                    rp.last_month_end_date) THEN
                CITAdjustments
             END) last_12_month_CITAdjustments,
         Sum(CASE
               WHEN (trunc(DTVENTIL_DT) BETWEEN rp.last_12_month_start_date AND
                    rp.last_month_end_date) THEN
                CITAdjustments_EUR
             END) last_12_month_CITAdjustments_EUR,
         Sum(CASE
               WHEN (trunc(DTVENTIL_DT) BETWEEN rp.last_12_month_start_date AND
                    rp.last_month_end_date) THEN
                payments_on_bank_account
             END) last_12_month_payments_on_bank_account,
         Sum(CASE
               WHEN (trunc(DTVENTIL_DT) BETWEEN rp.last_12_month_start_date AND
                    rp.last_month_end_date) THEN
                payments_on_bank_account_EUR
             END) last_12_month_payments_on_bank_account_EUR,
         --
         Sum(CASE
               WHEN (trunc(DTVENTIL_DT) BETWEEN rp.last_6_month_start_date AND
                    rp.last_month_end_date) THEN
                CITAdjustments
             END) last_6_month_CITAdjustments,
         Sum(CASE
               WHEN (trunc(DTVENTIL_DT) BETWEEN rp.last_6_month_start_date AND
                    rp.last_month_end_date) THEN
                CITAdjustments_EUR
             END) last_6_month_CITAdjustments_EUR,
         Sum(CASE
               WHEN (trunc(DTVENTIL_DT) BETWEEN rp.last_6_month_start_date AND
                    rp.last_month_end_date) THEN
                payments_on_bank_account
             END) last_6_month_payments_on_bank_account,
         Sum(CASE
               WHEN (trunc(DTVENTIL_DT) BETWEEN rp.last_6_month_start_date AND
                    rp.last_month_end_date) THEN
                payments_on_bank_account_EUR
             END) last_6_month_payments_on_bank_account_EUR,
         --
         Sum(CASE
               WHEN (trunc(DTVENTIL_DT) BETWEEN rp.last_month_start_date AND
                    rp.last_month_end_date) THEN
                CITAdjustments
             END) last_month_CITAdjustments,
         Sum(CASE
               WHEN (trunc(DTVENTIL_DT) BETWEEN rp.last_month_start_date AND
                    rp.last_month_end_date) THEN
                CITAdjustments_EUR
             END) last_month_CITAdjustments_EUR,
         Sum(CASE
               WHEN (trunc(DTVENTIL_DT) BETWEEN rp.last_month_start_date AND
                    rp.last_month_end_date) THEN
                payments_on_bank_account
             END) last_month_payments_on_bank_account,
         Sum(CASE
               WHEN (trunc(DTVENTIL_DT) BETWEEN rp.last_month_start_date AND
                    rp.last_month_end_date) THEN
                payments_on_bank_account_EUR
             END) last_month_payments_on_bank_account_EUR
    FROM ReportPeriod rp, SAF_CIT_PREP
   GROUP BY iMX_Contract_Reference, iMX_Case_Reference
   ORDER BY iMX_Contract_Reference),
pre_ratings AS
(SELECT DISTINCT fin.REFINDIVIDU,
                  rp.*,
                  fin.str2,
                  --fin.DT01_DT, 
                  rank() over(partition by fin.REFINDIVIDU order by fin.TYPE, fin.DT01_DT desc) rank_x
    FROM G_INDIVPARAM fin, -- Ermittelt FIN Rating
         ReportPeriod rp
   WHERE fin.str1 = 'FIN'
     AND fin.TYPE IN ('COTE FACTOR HIS', 'COTE FACTOR')
     AND trunc(fin.DT01_DT) <= trunc(rp.End_Date)),
fin_ratings AS
(SELECT * FROM pre_ratings WHERE rank_x = 1),
MemberGroups AS
(SELECT gc.GRP_NAME, gc.REFGROUP, mc.REFDOSS
    FROM GROUP_CONTRACTS gc, MEMBER_CONTRACT mc
   WHERE mc.REFGROUP = gc.REFGROUP
     AND (gc.DEACTIVATED = 'N' OR gc.DEACTIVATED IS NULL)),
MFTLimits AS
(SELECT pl.contract_number, pl.imx_case_reference, l.amount, l.currency
    FROM period_list_subcontract pl
    LEFT JOIN MAX_FIU_LIMIT l
      ON l.refgroup = pl.contract_number
     AND l.start_dt <= pl.End_Date
     AND (l.END_DT >= pl.End_Date OR l.end_dt IS NULL)),
report_pre AS
(SELECT  1 AS sort,
         pl.cal_year,
         pl.cal_week,
         pl.iMX_Client_Reference,
         pl.Contract_Number, -- Vertragsnummer
         pl.iMX_Contract_Reference,
         pl.iMX_Case_Reference, -- Subcontract
         pl.client_name,
         pl.Currency AS SUBCONTRACT_CURRENCY,
         pl.CLIENT_MANAGER_NOM, -- Kontomanager
         pl.ACCOUNT_MANAGER_NOM, -- Kundenbetreuer
         pl.TEAM_ASSISTANT_NAME, -- Riskmanager
         pl.MAXFIU maxfiu, -- LIMIT BV
         mft.amount MaxFiU_group, -- LIMIT BV Gruppe
         mft.currency MaxFiU_group_CCY,
         status.status,
         fin.str2 fin_rating, -- fin rating,
         CH_TAUX.CONV_ORIG_DEST_TX(to_char(sysdate, 'J'),
                                   cls.FIU,
                                   pl.Currency,
                                   'EUR',
                                   'MR',
                                   NULL) AS funds_in_use_eur,
         cls.PORTFOLIO,
         CH_TAUX.CONV_ORIG_DEST_TX(to_char(sysdate, 'J'),
                                   cls.PORTFOLIO,
                                   pl.Currency,
                                   'EUR',
                                   'MR',
                                   NULL) AS portfolio_eur,
         CH_TAUX.CONV_ORIG_DEST_TX(to_char(sysdate, 'J'),
                                   cls.Retentions,
                                   pl.Currency,
                                   'EUR',
                                   'MR',
                                   NULL) AS Retentions_eur,
         CH_TAUX.CONV_ORIG_DEST_TX(to_char(sysdate, 'J'),
                                   pds.SumOfCreditNotes,
                                   pl.Currency,
                                   'EUR',
                                   'MR',
                                   NULL) AS CreditNotes_eur,
         cls.Fundable_Amount,
         CH_TAUX.CONV_ORIG_DEST_TX(to_char(sysdate, 'J'),
                                   cls.Fundable_Amount,
                                   pl.Currency,
                                   'EUR',
                                   'MR',
                                   NULL) AS Fundable_Amount_eur,
         CH_TAUX.CONV_ORIG_DEST_TX(to_char(sysdate, 'J'),
                                   NULLIF(CASE
                                            WHEN pl.GP_FG06 = 'O' -- (= 'Is SAF flag' true) dann 
                                             THEN
                                             nvl(pds.SumOfAdjustments, 0) +
                                             nvl(sca.last_week_CITAdjustments, 0)
                                            ELSE
                                             pds.SumOfAdjustments
                                          END,
                                          0),
                                   pl.Currency,
                                   'EUR',
                                   'MR',
                                   NULL) AS Adjustments_eur,
         CH_TAUX.CONV_ORIG_DEST_TX(to_char(sysdate, 'J'),
                                   pds.SumOfOtherDebits,
                                   pl.Currency,
                                   'EUR',
                                   'MR',
                                   NULL) AS OtherDebits_eur,
         CH_TAUX.CONV_ORIG_DEST_TX(to_char(sysdate, 'J'),
                                   pds.SumOfInvoices,
                                   pl.Currency,
                                   'EUR',
                                   'MR',
                                   NULL) AS Invoices_eur,
         ---
         CH_TAUX.CONV_ORIG_DEST_TX(to_char(sysdate, 'J'),
                                   pds.last_month_SumOfCreditNotes,
                                   pl.Currency,
                                   'EUR',
                                   'MR',
                                   NULL) AS last_month_CreditNotes_eur,
         CH_TAUX.CONV_ORIG_DEST_TX(to_char(sysdate, 'J'),
                                   NULLIF(CASE
                                            WHEN pl.GP_FG06 = 'O' -- (= 'Is SAF flag' true) dann 
                                             THEN
                                             nvl(pds.last_month_SumOfAdjustments, 0) +
                                             nvl(sca.last_month_CITAdjustments, 0)
                                            ELSE
                                             pds.last_month_SumOfAdjustments
                                          END,
                                          0),
                                   pl.Currency,
                                   'EUR',
                                   'MR',
                                   NULL) AS last_month_Adjustments_eur,
         CH_TAUX.CONV_ORIG_DEST_TX(to_char(sysdate, 'J'),
                                   pds.last_month_SumOfOtherDebits,
                                   pl.Currency,
                                   'EUR',
                                   'MR',
                                   NULL) AS last_month_OtherDebits_eur,
         CH_TAUX.CONV_ORIG_DEST_TX(to_char(sysdate, 'J'),
                                   pds.last_month_SumOfInvoices,
                                   pl.Currency,
                                   'EUR',
                                   'MR',
                                   NULL) AS last_month_Invoices_eur,
         ---
         CH_TAUX.CONV_ORIG_DEST_TX(to_char(sysdate, 'J'),
                                   pds.last_6_month_SumOfCreditNotes,
                                   pl.Currency,
                                   'EUR',
                                   'MR',
                                   NULL) AS last_6_month_CreditNotes_eur,
         CH_TAUX.CONV_ORIG_DEST_TX(to_char(sysdate, 'J'),
                                   NULLIF(CASE
                                            WHEN pl.GP_FG06 = 'O' -- (= 'Is SAF flag' true) dann 
                                             THEN
                                             nvl(pds.last_6_month_SumOfAdjustments, 0) +
                                             nvl(sca.last_6_month_CITAdjustments, 0)
                                            ELSE
                                             pds.last_6_month_SumOfAdjustments
                                          END,
                                          0),
                                   pl.Currency,
                                   'EUR',
                                   'MR',
                                   NULL) AS last_6_month_Adjustments_eur,
         CH_TAUX.CONV_ORIG_DEST_TX(to_char(sysdate, 'J'),
                                   pds.last_6_month_SumOfOtherDebits,
                                   pl.Currency,
                                   'EUR',
                                   'MR',
                                   NULL) AS last_6_month_OtherDebits_eur,
         CH_TAUX.CONV_ORIG_DEST_TX(to_char(sysdate, 'J'),
                                   pds.last_6_month_SumOfInvoices,
                                   pl.Currency,
                                   'EUR',
                                   'MR',
                                   NULL) AS last_6_month_Invoices_eur,
         ---
         CH_TAUX.CONV_ORIG_DEST_TX(to_char(sysdate, 'J'),
                                   pds.last_12_month_SumOfCreditNotes,
                                   pl.Currency,
                                   'EUR',
                                   'MR',
                                   NULL) AS last_12_month_CreditNotes_eur,
         CH_TAUX.CONV_ORIG_DEST_TX(to_char(sysdate, 'J'),
                                   NULLIF(CASE
                                            WHEN pl.GP_FG06 = 'O' -- (= 'Is SAF flag' true) dann 
                                             THEN
                                             nvl(pds.last_12_month_SumOfAdjustments, 0) +
                                             nvl(sca.last_12_month_CITAdjustments, 0)
                                            ELSE
                                             pds.last_12_month_SumOfAdjustments
                                          END,
                                          0),
                                   pl.Currency,
                                   'EUR',
                                   'MR',
                                   NULL) AS last_12_month_Adjustments_eur,
         CH_TAUX.CONV_ORIG_DEST_TX(to_char(sysdate, 'J'),
                                   pds.last_12_month_SumOfOtherDebits,
                                   pl.Currency,
                                   'EUR',
                                   'MR',
                                   NULL) AS last_12_month_OtherDebits_eur,
         CH_TAUX.CONV_ORIG_DEST_TX(to_char(sysdate, 'J'),
                                   pds.last_12_month_SumOfInvoices,
                                   pl.Currency,
                                   'EUR',
                                   'MR',
                                   NULL) AS last_12_month_Invoices_eur,
         ---
         pds.last_3_month_SumOfInvoices,
         pds.last_3_month_SumOfOtherDebits,
         pds.last_3_month_last_year_SumOfInvoices,
         pds.last_3_month_last_year_SumOfOtherDebits,
         CASE
           WHEN cs_avg_ub_ly.portfolio = 0 OR pds_ub_ly.SumOfInvoices = 0 THEN
            NULL
           ELSE
            cs_avg_ub_ly.days_from_begin /
            (pds_ub_ly.SumOfInvoices / cs_avg_ub_ly.portfolio)
         END AS DebtorTurnover_last_year,
         --
         pl.GP_FG06,
         sca.last_12_month_payments_on_bank_account,
         pds.last_12_month_SumOfPayments,
         --
         CH_TAUX.CONV_ORIG_DEST_TX(to_char(sysdate, 'J'),
                                   cls_wb.Retentions,
                                   pl.Currency,
                                   'EUR',
                                   'MR',
                                   NULL) AS Retentions_eur_week_bevore,
         CH_TAUX.CONV_ORIG_DEST_TX(to_char(sysdate, 'J'),
                                   cls_curernt.AVAILABILITY,
                                   pl.Currency,
                                   'EUR',
                                   'MR',
                                   NULL) AS AVAILABILITY_eur_current,
         cls_curernt.BLOCKED_AMOUNT AS BLOCKED_AMOUNT_current,
         cls_curernt.FIU AS FIU_current,
         --
         fr.financing_rate
    FROM period_list_subcontract pl
    LEFT JOIN contract_status status
      ON status.iMX_Case_Reference = pl.iMX_Case_Reference
    LEFT OUTER JOIN ClientStatement cls
      ON cls.iMX_Contract_Reference = pl.iMX_Contract_Reference
     AND cls.iMX_Case_Reference = pl.iMX_Case_Reference
    LEFT OUTER JOIN ClientStatement_current cls_curernt
      ON cls_curernt.iMX_Contract_Reference = pl.iMX_Contract_Reference
     AND cls_curernt.iMX_Case_Reference = pl.iMX_Case_Reference
    LEFT OUTER JOIN ClientStatement_week_bevore cls_wb
      ON cls_wb.iMX_Contract_Reference = pl.iMX_Contract_Reference
     AND cls_wb.iMX_Case_Reference = pl.iMX_Case_Reference
  --
    LEFT OUTER JOIN PortfolioDetailsSum pds
      ON pds.iMX_Contract_Reference = pl.iMX_Contract_Reference
     AND pds.iMX_Case_Reference = pl.iMX_Case_Reference
  --
    LEFT OUTER JOIN SAF_CIT sca
      ON sca.iMX_Contract_Reference = pl.iMX_Contract_Reference
     AND sca.iMX_Case_Reference = pl.iMX_Case_Reference
  --
    LEFT OUTER JOIN MFTLIMITS mft
      ON mft.contract_number = pl.contract_number
     AND mft.iMX_Case_Reference = pl.iMX_Case_Reference
    LEFT OUTER JOIN fin_ratings fin -- OK!!
      ON fin.REFINDIVIDU = pl.iMX_Client_Reference
  --
    LEFT JOIN ClientStatement_avg_until_begin cs_avg_ub
      ON cs_avg_ub.iMX_Case_Reference = pl.iMX_Case_Reference
    LEFT JOIN ClientStatement_avg_until_begin_last_year cs_avg_ub_ly
      ON cs_avg_ub_ly.iMX_Case_Reference = pl.iMX_Case_Reference
    LEFT OUTER JOIN PortfolioDetails_sum_until_begin pds_ub
      ON pds_ub.iMX_Contract_Reference = pl.iMX_Contract_Reference
     AND pds_ub.iMX_Case_Reference = pl.iMX_Case_Reference
    LEFT OUTER JOIN PortfolioDetails_sum_until_begin_last_year pds_ub_ly
      ON pds_ub_ly.iMX_Contract_Reference = pl.iMX_Contract_Reference
     AND pds_ub_ly.iMX_Case_Reference = pl.iMX_Case_Reference
    LEFT JOIN FinancingRate fr
      ON fr.refdoss = pl.iMX_Case_Reference
   WHERE 1 = 1
   ORDER BY pl.iMX_Case_Reference),
report AS
(SELECT  cal_week,
         CONTRACT_NUMBER,
         iMX_Case_Reference,
         SUBCONTRACT_CURRENCY,
         client_name,
         ACCOUNT_MANAGER_NOM AS Client_manager,
         CLIENT_MANAGER_NOM AS Case_manager,
         TEAM_ASSISTANT_NAME AS Risk_manager,
         MAXFIU,
         MAXFIU_GROUP,
         MAXFIU_GROUP_CCY,
         status,
         fin_rating,
         funds_in_use_eur,
         portfolio_eur,
         Retentions_eur,
         CreditNotes_eur,
         Adjustments_eur,
         round(((nvl(CreditNotes_eur, 0) + nvl(Adjustments_eur, 0)) /
               (NULLIF(nvl(invoices_eur, 0) + nvl(otherDebits_eur, 0), 0))) * 100,
               2) AS credit_notes_adjustments_perc,
         round(((nvl(last_month_CreditNotes_eur, 0) +
               nvl(last_month_Adjustments_eur, 0)) /
               (NULLIF(nvl(last_month_invoices_eur, 0) +
                        nvl(last_month_otherDebits_eur, 0),
                        0))) * 100,
               2) AS last_month_credit_notes_adjustments_perc,
         round(((nvl(last_6_month_CreditNotes_eur, 0) +
               nvl(last_6_month_Adjustments_eur, 0)) /
               (NULLIF(nvl(last_6_month_invoices_eur, 0) +
                        nvl(last_6_month_otherDebits_eur, 0),
                        0))) * 100,
               2) AS last_6_month_credit_notes_adjustments_perc,
         round(((nvl(last_12_month_CreditNotes_eur, 0) +
               nvl(last_12_month_Adjustments_eur, 0)) /
               (NULLIF(nvl(last_12_month_invoices_eur, 0) +
                        nvl(last_12_month_otherDebits_eur, 0),
                        0))) * 100,
               2) AS last_12_month_credit_notes_adjustments_perc,
         (((last_3_month_SumOfInvoices + last_3_month_SumOfOtherDebits) -
         (last_3_month_last_year_SumOfInvoices +
         last_3_month_last_year_SumOfOtherDebits)) /
         (last_3_month_last_year_SumOfInvoices +
         last_3_month_last_year_SumOfOtherDebits)) * 100 AS turnover,
         (1 - (Retentions_eur / NULLIF(Retentions_eur_week_bevore, 0))) * -1 AS retentions_change_perc,
         (FIU_current / NULLIF(Fundable_Amount, 0)) * 100 AS overdraft,
         '###' AS break,
         invoices_eur AS invoices_last_week_eur,
        otherDebits_eur AS otherDebits_last_week_eur,
         portfolio AS portfolio_last_week,
         financing_rate,
         GP_FG06,
         AVAILABILITY_eur_current,
         FIU_current,
         BLOCKED_AMOUNT_current,
         last_12_month_payments_on_bank_account,
         last_12_month_SumOfPayments,
         last_month_CreditNotes_eur,
         last_month_Adjustments_eur,
         last_month_invoices_eur,
         last_month_otherDebits_eur
    FROM report_pre )
SELECT count(*)
  FROM report pl
  FULL OUTER JOIN new_receivables_other_debit nrod
    on nrod.iMX_Case_Reference = pl.iMX_Case_Reference 
   AND nrod.imx_case_reference = '0001010345';
/********************************New SQL*******************************************/
/********************************New Metrics***************************************/
/*
Plan hash value: 4233821664
---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                                    | Name                          | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  | Writes |
---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                                             |                               |      1 |        |   173M(100)|      1 |00:03:14.66 |      10M|   1920K|    349K|
|   1 |  TEMP TABLE TRANSFORMATION                                   |                               |      1 |        |            |      1 |00:03:14.66 |      10M|   1920K|    349K|
|   2 |   LOAD AS SELECT (CURSOR DURATION MEMORY)                    | SYS_TEMP_0FD9E76D7_92BF0312   |      1 |        |            |      0 |00:00:00.01 |      75 |      0 |      0 |
|*  3 |    HASH JOIN                                                 |                               |      1 |    508 |    24   (0)|    492 |00:00:00.01 |      74 |      0 |      0 |
|   4 |     NESTED LOOPS                                             |                               |      1 |    492 |     7   (0)|    492 |00:00:00.01 |      13 |      0 |      0 |
|   5 |      FAST DUAL                                               |                               |      1 |      1 |     2   (0)|      1 |00:00:00.01 |       0 |      0 |      0 |
|   6 |      MAT_VIEW ACCESS STORAGE FULL                            | AD_ACCOUNT_CLIENT_MVIEW       |      1 |    492 |     5   (0)|    492 |00:00:00.01 |      13 |      0 |      0 |
|   7 |     TABLE ACCESS STORAGE FULL                                | AD_CASE_CONTRAT               |      1 |    439 |    17   (0)|    439 |00:00:00.01 |      61 |      0 |      0 |
|   8 |   LOAD AS SELECT (CURSOR DURATION MEMORY)                    | SYS_TEMP_0FD9E76D8_92BF0312   |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
|*  9 |    HASH JOIN                                                 |                               |      1 |    667K|    60   (4)|     13 |00:00:00.01 |       0 |      0 |      0 |
|  10 |     COLLECTION ITERATOR CONSTRUCTOR FETCH                    |                               |      1 |   8168 |    29   (0)|     13 |00:00:00.01 |       0 |      0 |      0 |
|  11 |     COLLECTION ITERATOR CONSTRUCTOR FETCH                    |                               |      1 |   8168 |    29   (0)|     13 |00:00:00.01 |       0 |      0 |      0 |
|  12 |   LOAD AS SELECT (CURSOR DURATION MEMORY)                    | SYS_TEMP_0FD9E76D9_92BF0312   |      1 |        |            |      0 |00:00:00.31 |     249K|      0 |      0 |
|  13 |    NESTED LOOPS OUTER                                        |                               |      1 |    492 |  1484   (1)|  44772 |00:00:00.26 |     249K|      0 |      0 |
|  14 |     MERGE JOIN CARTESIAN                                     |                               |      1 |    492 |     8  (13)|  44772 |00:00:00.01 |      13 |      0 |      0 |
|  15 |      VIEW                                                    |                               |      1 |      1 |     3  (34)|     91 |00:00:00.01 |       0 |      0 |      0 |
|  16 |       SORT ORDER BY                                          |                               |      1 |      1 |     3  (34)|     91 |00:00:00.01 |       0 |      0 |      0 |
|  17 |        CONNECT BY WITHOUT FILTERING                          |                               |      1 |        |            |     91 |00:00:00.01 |       0 |      0 |      0 |
|  18 |         FAST DUAL                                            |                               |      1 |      1 |     2   (0)|      1 |00:00:00.01 |       0 |      0 |      0 |
|  19 |      BUFFER SORT                                             |                               |     91 |    492 |     8  (13)|  44772 |00:00:00.01 |      13 |      0 |      0 |
|  20 |       MAT_VIEW ACCESS STORAGE FULL                           | AD_ACCOUNT_CLIENT_MVIEW       |      1 |    492 |     5   (0)|    492 |00:00:00.01 |      13 |      0 |      0 |
|* 21 |     VIEW                                                     | AD_CLIENT_STATEMENT_HIST_VIEW |  44772 |      1 |     3   (0)|  39668 |00:00:00.24 |     248K|      0 |      0 |
|  22 |      UNION-ALL PARTITION                                     |                               |  44772 |        |            |  39668 |00:00:00.22 |     248K|      0 |      0 |
|  23 |       TABLE ACCESS BY INDEX ROWID                            | AD_CLIENT_STATEMENT_HISTORY   |  44772 |      1 |     3   (0)|      0 |00:00:00.06 |     142K|      0 |      0 |
|* 24 |        INDEX UNIQUE SCAN                                     | PK_AD_CL_HISTORY              |  44772 |      1 |     2   (0)|      0 |00:00:00.05 |     142K|      0 |      0 |
|  25 |       TABLE ACCESS BY INDEX ROWID                            | AD_CLIENT_STATEMENT_HIST_ARCH |  44772 |      1 |     3   (0)|  39668 |00:00:00.09 |     106K|      0 |      0 |
|* 26 |        INDEX UNIQUE SCAN                                     | AD_CL_STM_ARCH_PK             |  44772 |      1 |     2   (0)|  39668 |00:00:00.04 |   66417 |      0 |      0 |
|  27 |   LOAD AS SELECT (CURSOR DURATION MEMORY)                    | SYS_TEMP_0FD9E76DA_92BF0312   |      1 |        |            |      0 |00:00:00.30 |     245K|      0 |      0 |
|  28 |    NESTED LOOPS OUTER                                        |                               |      1 |    492 |  1484   (1)|  44280 |00:00:00.25 |     245K|      0 |      0 |
|  29 |     MERGE JOIN CARTESIAN                                     |                               |      1 |    492 |     8  (13)|  44280 |00:00:00.01 |      13 |      0 |      0 |
|  30 |      VIEW                                                    |                               |      1 |      1 |     3  (34)|     90 |00:00:00.01 |       0 |      0 |      0 |
|  31 |       SORT ORDER BY                                          |                               |      1 |      1 |     3  (34)|     90 |00:00:00.01 |       0 |      0 |      0 |
|  32 |        CONNECT BY WITHOUT FILTERING                          |                               |      1 |        |            |     90 |00:00:00.01 |       0 |      0 |      0 |
|  33 |         FAST DUAL                                            |                               |      1 |      1 |     2   (0)|      1 |00:00:00.01 |       0 |      0 |      0 |
|  34 |      BUFFER SORT                                             |                               |     90 |    492 |     8  (13)|  44280 |00:00:00.01 |      13 |      0 |      0 |
|  35 |       MAT_VIEW ACCESS STORAGE FULL                           | AD_ACCOUNT_CLIENT_MVIEW       |      1 |    492 |     5   (0)|    492 |00:00:00.01 |      13 |      0 |      0 |
|* 36 |     VIEW                                                     | AD_CLIENT_STATEMENT_HIST_VIEW |  44280 |      1 |     3   (0)|  37145 |00:00:00.22 |     245K|      0 |      0 |
|  37 |      UNION-ALL PARTITION                                     |                               |  44280 |        |            |  37145 |00:00:00.20 |     245K|      0 |      0 |
|  38 |       TABLE ACCESS BY INDEX ROWID                            | AD_CLIENT_STATEMENT_HISTORY   |  44280 |      1 |     3   (0)|      0 |00:00:00.06 |     143K|      0 |      0 |
|* 39 |        INDEX UNIQUE SCAN                                     | PK_AD_CL_HISTORY              |  44280 |      1 |     2   (0)|      0 |00:00:00.05 |     143K|      0 |      0 |
|  40 |       TABLE ACCESS BY INDEX ROWID                            | AD_CLIENT_STATEMENT_HIST_ARCH |  44280 |      1 |     3   (0)|  37145 |00:00:00.09 |     102K|      0 |      0 |
|* 41 |        INDEX UNIQUE SCAN                                     | AD_CL_STM_ARCH_PK             |  44280 |      1 |     2   (0)|  37145 |00:00:00.04 |   64951 |      0 |      0 |
|  42 |   LOAD AS SELECT (CURSOR DURATION MEMORY)                    | SYS_TEMP_0FD9E76DB_92BF0312   |      1 |        |            |      0 |00:02:50.79 |    7487K|    708K|    295K|
|* 43 |    HASH JOIN                                                 |                               |      1 |  14027 |   144K  (1)|   9303K|00:00:27.38 |     497K|    708K|    211K|
|* 44 |     HASH JOIN                                                |                               |      1 |  75896 |   136K  (1)|   9720K|00:00:11.04 |     497K|    497K|      0 |
|  45 |      VIEW                                                    |                               |      1 |    508 |     5   (0)|    492 |00:00:00.01 |       0 |      0 |      0 |
|  46 |       TABLE ACCESS STORAGE FULL                              | SYS_TEMP_0FD9E76D7_92BF0312   |      1 |    508 |     5   (0)|    492 |00:00:00.01 |       0 |      0 |      0 |
|  47 |      TABLE ACCESS STORAGE FULL                               | AD_PORTFOLIO_DETAIL           |      1 |     14M|   136K  (1)|     14M|00:00:02.70 |     497K|    497K|      0 |
|* 48 |     VIEW                                                     |                               |      1 |    667K|   103   (3)|     13 |00:00:00.01 |       0 |      0 |      0 |
|  49 |      TABLE ACCESS STORAGE FULL                               | SYS_TEMP_0FD9E76D8_92BF0312   |      1 |    667K|   103   (3)|     13 |00:00:00.01 |       0 |      0 |      0 |
|  50 |   SORT AGGREGATE                                             |                               |      1 |      1 |            |      1 |00:00:23.26 |    2281K|   1212K|  53802 |
|  51 |    VIEW                                                      | VW_FOJ_0                      |      1 |    164K|   173M  (1)|    929 |00:00:23.26 |    2281K|   1212K|  53802 |
|* 52 |     HASH JOIN FULL OUTER                                     |                               |      1 |    164K|   173M  (1)|    929 |00:00:23.26 |    2281K|   1212K|  53802 |
|  53 |      VIEW                                                    |                               |      1 |    545 |    91M  (1)|    492 |00:00:20.75 |    2197K|   1128K|  53802 |
|* 54 |       HASH JOIN RIGHT OUTER                                  |                               |      1 |    545 |    91M  (1)|    492 |00:00:20.75 |    2197K|   1128K|  53802 |
|  55 |        VIEW                                                  |                               |      1 |    493 |  7187   (1)|    430 |00:00:00.82 |   60774 |      0 |      0 |
|  56 |         HASH GROUP BY                                        |                               |      1 |    493 |  7187   (1)|    430 |00:00:00.82 |   60774 |      0 |      0 |
|  57 |          VIEW                                                |                               |      1 |    493 |  7186   (1)|  37257 |00:00:00.80 |   60774 |      0 |      0 |
|  58 |           UNION-ALL                                          |                               |      1 |        |            |  37257 |00:00:00.80 |   60774 |      0 |      0 |
|* 59 |            VIEW                                              |                               |      1 |    492 |     4   (0)|  37145 |00:00:00.01 |       0 |      0 |      0 |
|  60 |             TABLE ACCESS STORAGE FULL                        | SYS_TEMP_0FD9E76DA_92BF0312   |      1 |    492 |     4   (0)|  44280 |00:00:00.01 |       0 |      0 |      0 |
|  61 |            NESTED LOOPS                                      |                               |      1 |      1 |  7182   (1)|    112 |00:00:00.78 |   60774 |      0 |      0 |
|  62 |             VIEW                                             |                               |      1 |    492 |  5706   (1)|   7135 |00:00:00.76 |   60059 |      0 |      0 |
|  63 |              HASH GROUP BY                                   |                               |      1 |    492 |  5706   (1)|   7135 |00:00:00.76 |   60059 |      0 |      0 |
|* 64 |               HASH JOIN OUTER                                |                               |      1 |    492 |  5705   (1)|   9221 |00:00:00.76 |   60059 |      0 |      0 |
|* 65 |                VIEW                                          |                               |      1 |    492 |     4   (0)|   7135 |00:00:00.01 |       0 |      0 |      0 |
|  66 |                 TABLE ACCESS STORAGE FULL                    | SYS_TEMP_0FD9E76DA_92BF0312   |      1 |    492 |     4   (0)|  44280 |00:00:00.01 |       0 |      0 |      0 |
|  67 |                VIEW                                          | AD_CLIENT_STATEMENT_HIST_VIEW |      1 |  14408 |  5418   (1)|    288K|00:00:00.35 |   60059 |      0 |      0 |
|  68 |                 UNION-ALL                                    |                               |      1 |        |            |    288K|00:00:00.32 |   60059 |      0 |      0 |
|  69 |                  TABLE ACCESS BY INDEX ROWID BATCHED         | AD_CLIENT_STATEMENT_HISTORY   |      1 |   2312 |   735   (0)|  46230 |00:00:00.08 |   43056 |      0 |      0 |
|* 70 |                   INDEX SKIP SCAN                            | AD_CL_HIST_DT04_CLIENT_IDX    |      1 |    416 |   347   (0)|  46230 |00:00:00.03 |     434 |      0 |      0 |
|* 71 |                  TABLE ACCESS STORAGE FULL                   | AD_CLIENT_STATEMENT_HIST_ARCH |      1 |  12096 |  4683   (1)|    241K|00:00:00.18 |   17003 |      0 |      0 |
|* 72 |             VIEW                                             | AD_CLIENT_STATEMENT_HIST_VIEW |   7135 |      1 |     3   (0)|    112 |00:00:00.01 |     715 |      0 |      0 |
|  73 |              UNION-ALL PARTITION                             |                               |   7135 |        |            |    112 |00:00:00.01 |     715 |      0 |      0 |
|* 74 |               TABLE ACCESS BY INDEX ROWID                    | AD_CLIENT_STATEMENT_HISTORY   |   7135 |      1 |     3   (0)|      0 |00:00:00.01 |     354 |      0 |      0 |
|* 75 |                INDEX UNIQUE SCAN                             | PK_AD_CL_HISTORY              |   7135 |      1 |     2   (0)|      0 |00:00:00.01 |     354 |      0 |      0 |
|* 76 |               TABLE ACCESS BY INDEX ROWID                    | AD_CLIENT_STATEMENT_HIST_ARCH |   7135 |      1 |     3   (0)|    112 |00:00:00.01 |     361 |      0 |      0 |
|* 77 |                INDEX UNIQUE SCAN                             | AD_CL_STM_ARCH_PK             |   7135 |      1 |     2   (0)|    112 |00:00:00.01 |     249 |      0 |      0 |
|* 78 |        HASH JOIN RIGHT OUTER                                 |                               |      1 |    526 |    91M  (1)|    492 |00:00:20.75 |    2137K|   1128K|  53802 |
|  79 |         VIEW                                                 |                               |      1 |    493 |  7187   (1)|    443 |00:00:00.67 |   62849 |      0 |      0 |
|  80 |          HASH GROUP BY                                       |                               |      1 |    493 |  7187   (1)|    443 |00:00:00.67 |   62849 |      0 |      0 |
|  81 |           VIEW                                               |                               |      1 |    493 |  7186   (1)|  40089 |00:00:00.65 |   62849 |      0 |      0 |
|  82 |            UNION-ALL                                         |                               |      1 |        |            |  40089 |00:00:00.64 |   62849 |      0 |      0 |
|* 83 |             VIEW                                             |                               |      1 |    492 |     4   (0)|  39668 |00:00:00.01 |       0 |      0 |      0 |
|  84 |              TABLE ACCESS STORAGE FULL                       | SYS_TEMP_0FD9E76D9_92BF0312   |      1 |    492 |     4   (0)|  44772 |00:00:00.01 |       0 |      0 |      0 |
|  85 |             NESTED LOOPS                                     |                               |      1 |      1 |  7182   (1)|    421 |00:00:00.62 |   62849 |      0 |      0 |
|  86 |              VIEW                                            |                               |      1 |    492 |  5706   (1)|   5104 |00:00:00.61 |   60059 |      0 |      0 |
|  87 |               HASH GROUP BY                                  |                               |      1 |    492 |  5706   (1)|   5104 |00:00:00.61 |   60059 |      0 |      0 |
|* 88 |                HASH JOIN OUTER                               |                               |      1 |    492 |  5705   (1)|  22178 |00:00:00.60 |   60059 |      0 |      0 |
|* 89 |                 VIEW                                         |                               |      1 |    492 |     4   (0)|   5104 |00:00:00.01 |       0 |      0 |      0 |
|  90 |                  TABLE ACCESS STORAGE FULL                   | SYS_TEMP_0FD9E76D9_92BF0312   |      1 |    492 |     4   (0)|  44772 |00:00:00.01 |       0 |      0 |      0 |
|  91 |                 VIEW                                         | AD_CLIENT_STATEMENT_HIST_VIEW |      1 |  14408 |  5418   (1)|    288K|00:00:00.32 |   60059 |      0 |      0 |
|  92 |                  UNION-ALL                                   |                               |      1 |        |            |    288K|00:00:00.29 |   60059 |      0 |      0 |
|  93 |                   TABLE ACCESS BY INDEX ROWID BATCHED        | AD_CLIENT_STATEMENT_HISTORY   |      1 |   2312 |   735   (0)|  46230 |00:00:00.07 |   43056 |      0 |      0 |
|* 94 |                    INDEX SKIP SCAN                           | AD_CL_HIST_DT04_CLIENT_IDX    |      1 |    416 |   347   (0)|  46230 |00:00:00.03 |     434 |      0 |      0 |
|* 95 |                   TABLE ACCESS STORAGE FULL                  | AD_CLIENT_STATEMENT_HIST_ARCH |      1 |  12096 |  4683   (1)|    241K|00:00:00.17 |   17003 |      0 |      0 |
|* 96 |              VIEW                                            | AD_CLIENT_STATEMENT_HIST_VIEW |   5104 |      1 |     3   (0)|    421 |00:00:00.01 |    2790 |      0 |      0 |
|  97 |               UNION-ALL PARTITION                            |                               |   5104 |        |            |    421 |00:00:00.01 |    2790 |      0 |      0 |
|* 98 |                TABLE ACCESS BY INDEX ROWID                   | AD_CLIENT_STATEMENT_HISTORY   |   5104 |      1 |     3   (0)|      0 |00:00:00.01 |    1330 |      0 |      0 |
|* 99 |                 INDEX UNIQUE SCAN                            | PK_AD_CL_HISTORY              |   5104 |      1 |     2   (0)|      0 |00:00:00.01 |    1330 |      0 |      0 |
|*100 |                TABLE ACCESS BY INDEX ROWID                   | AD_CLIENT_STATEMENT_HIST_ARCH |   5104 |      1 |     3   (0)|    421 |00:00:00.01 |    1460 |      0 |      0 |
|*101 |                 INDEX UNIQUE SCAN                            | AD_CL_STM_ARCH_PK             |   5104 |      1 |     2   (0)|    421 |00:00:00.01 |    1039 |      0 |      0 |
|*102 |         HASH JOIN OUTER                                      |                               |      1 |    508 |    91M  (1)|    492 |00:00:20.75 |    2074K|   1128K|  53802 |
| 103 |          JOIN FILTER CREATE                                  | :BF0000                       |      1 |    508 |   306K  (1)|    492 |00:00:10.74 |    1990K|   1044K|  53802 |
|*104 |           HASH JOIN RIGHT OUTER                              |                               |      1 |    508 |   306K  (1)|    492 |00:00:10.73 |    1990K|   1044K|  53802 |
| 105 |            VIEW                                              |                               |      1 |    508 |  1530   (1)|    492 |00:00:00.01 |    3444 |      0 |      0 |
| 106 |             MERGE JOIN OUTER                                 |                               |      1 |    508 |  1530   (1)|    492 |00:00:00.01 |    3444 |      0 |      0 |
| 107 |              VIEW                                            |                               |      1 |    508 |     5   (0)|    492 |00:00:00.01 |       0 |      0 |      0 |
| 108 |               TABLE ACCESS STORAGE FULL                      | SYS_TEMP_0FD9E76D7_92BF0312   |      1 |    508 |     5   (0)|    492 |00:00:00.01 |       0 |      0 |      0 |
| 109 |              BUFFER SORT                                     |                               |    492 |      1 |  1530   (1)|      0 |00:00:00.01 |    3444 |      0 |      0 |
| 110 |               VIEW                                           | VW_LAT_2813F249               |    492 |      1 |     3   (0)|      0 |00:00:00.01 |    3444 |      0 |      0 |
|*111 |                TABLE ACCESS STORAGE FULL                     | MAX_FIU_LIMIT                 |    492 |      1 |     3   (0)|      0 |00:00:00.01 |    3444 |      0 |      0 |
|*112 |            HASH JOIN RIGHT OUTER                             |                               |      1 |    508 |   305K  (1)|    492 |00:00:10.74 |    1987K|   1044K|  53802 |
|*113 |             VIEW                                             |                               |      1 |    108 |   362   (1)|    412 |00:00:00.01 |    1969 |      0 |      0 |
| 114 |              HASH UNIQUE                                     |                               |      1 |    108 |   362   (1)|    412 |00:00:00.01 |    1969 |      0 |      0 |
|*115 |               WINDOW SORT PUSHED RANK                        |                               |      1 |    108 |   362   (1)|    412 |00:00:00.01 |    1969 |      0 |      0 |
| 116 |                NESTED LOOPS                                  |                               |      1 |    108 |   360   (0)|    965 |00:00:00.01 |    1969 |      0 |      0 |
| 117 |                 FAST DUAL                                    |                               |      1 |      1 |     2   (0)|      1 |00:00:00.01 |       0 |      0 |      0 |
| 118 |                 INLIST ITERATOR                              |                               |      1 |        |            |    965 |00:00:00.01 |    1969 |      0 |      0 |
|*119 |                  TABLE ACCESS BY INDEX ROWID BATCHED         | G_INDIVPARAM                  |      2 |    108 |   358   (0)|    965 |00:00:00.01 |    1969 |      0 |      0 |
|*120 |                   INDEX RANGE SCAN                           | G_INDPAR_TYPSTR1_IDX          |      2 |   2152 |    17   (0)|   3041 |00:00:00.01 |      26 |      0 |      0 |
|*121 |             HASH JOIN RIGHT OUTER                            |                               |      1 |    508 |   305K  (1)|    492 |00:00:10.73 |    1985K|   1044K|  53802 |
| 122 |              VIEW                                            |                               |      1 |    101 | 11824   (1)|    269 |00:00:03.77 |     229K|      0 |      0 |
| 123 |               SORT GROUP BY                                  |                               |      1 |    101 | 11824   (1)|    269 |00:00:03.77 |     229K|      0 |      0 |
| 124 |                NESTED LOOPS                                  |                               |      1 |    101 | 11823   (1)|    610K|00:00:02.59 |     229K|      0 |      0 |
| 125 |                 NESTED LOOPS                                 |                               |      1 |  34440 | 11823   (1)|   1179K|00:00:00.30 |    6521 |      0 |      0 |
| 126 |                  NESTED LOOPS                                |                               |      1 |    492 |     9   (0)|    492 |00:00:00.01 |      13 |      0 |      0 |
| 127 |                   NESTED LOOPS                               |                               |      1 |      1 |     4   (0)|      1 |00:00:00.01 |       0 |      0 |      0 |
| 128 |                    FAST DUAL                                 |                               |      1 |      1 |     2   (0)|      1 |00:00:00.01 |       0 |      0 |      0 |
| 129 |                    FAST DUAL                                 |                               |      1 |      1 |     2   (0)|      1 |00:00:00.01 |       0 |      0 |      0 |
| 130 |                   MAT_VIEW ACCESS STORAGE FULL               | AD_ACCOUNT_CLIENT_MVIEW       |      1 |    492 |     5   (0)|    492 |00:00:00.01 |      13 |      0 |      0 |
|*131 |                  INDEX RANGE SCAN                            | NAM_COLLECTE_REFDOSS_IDX      |    492 |     70 |     2   (0)|   1179K|00:00:00.20 |    6508 |      0 |      0 |
|*132 |                 TABLE ACCESS BY INDEX ROWID                  | NAM_COLLECTE                  |   1179K|      1 |    24   (0)|    610K|00:00:02.00 |     223K|      0 |      0 |
|*133 |              HASH JOIN RIGHT OUTER                           |                               |      1 |    508 |   293K  (1)|    492 |00:00:10.73 |    1755K|   1044K|  53802 |
| 134 |               VIEW                                           |                               |      1 |      1 |  2587   (1)|    486 |00:00:00.05 |   12370 |      0 |      0 |
| 135 |                NESTED LOOPS                                  |                               |      1 |      1 |  2587   (1)|    486 |00:00:00.05 |   12370 |      0 |      0 |
| 136 |                 NESTED LOOPS                                 |                               |      1 |      1 |  2587   (1)|    486 |00:00:00.05 |   11884 |      0 |      0 |
| 137 |                  VIEW                                        |                               |      1 |      1 |  2584   (1)|    486 |00:00:00.05 |   10424 |      0 |      0 |
| 138 |                   HASH GROUP BY                              |                               |      1 |      1 |  2584   (1)|    486 |00:00:00.05 |   10424 |      0 |      0 |
|*139 |                    HASH JOIN                                 |                               |      1 |      1 |  2583   (1)|   8806 |00:00:00.05 |   10424 |      0 |      0 |
| 140 |                     JOIN FILTER CREATE                       | :BF0001                       |      1 |     90 |  2578   (1)|  16185 |00:00:00.04 |   10411 |      0 |      0 |
|*141 |                      TABLE ACCESS BY INDEX ROWID BATCHED     | G_PIECEDET                    |      1 |     90 |  2578   (1)|  16185 |00:00:00.04 |   10411 |      0 |      0 |
|*142 |                       INDEX RANGE SCAN                       | G_PIECEDET_TYPE_LASTLOAD_IDX  |      1 |  25591 |   202   (0)|  25593 |00:00:00.01 |     201 |      0 |      0 |
| 143 |                     JOIN FILTER USE                          | :BF0001                       |      1 |    492 |     5   (0)|    486 |00:00:00.01 |      13 |      0 |      0 |
|*144 |                      MAT_VIEW ACCESS STORAGE FULL            | AD_ACCOUNT_CLIENT_MVIEW       |      1 |    492 |     5   (0)|    486 |00:00:00.01 |      13 |      0 |      0 |
|*145 |                  INDEX UNIQUE SCAN                           | G_PIECEDET_PK                 |    486 |      1 |     2   (0)|    486 |00:00:00.01 |    1460 |      0 |      0 |
|*146 |                 TABLE ACCESS BY INDEX ROWID                  | G_PIECEDET                    |    486 |      1 |     3   (0)|    486 |00:00:00.01 |     486 |      0 |      0 |
|*147 |               HASH JOIN RIGHT OUTER                          |                               |      1 |    508 |   290K  (1)|    492 |00:00:10.73 |    1743K|   1044K|  53802 |
| 148 |                VIEW                                          |                               |      1 |      1 |   137K  (1)|    397 |00:00:14.80 |     892K|    519K|  25704 |
| 149 |                 HASH GROUP BY                                |                               |      1 |      1 |   137K  (1)|    397 |00:00:14.80 |     892K|    519K|  25704 |
|*150 |                  HASH JOIN                                   |                               |      1 |      1 |   137K  (1)|    707K|00:00:08.36 |     497K|    519K|  25704 |
| 151 |                   JOIN FILTER CREATE                         | :BF0002                       |      1 |      5 |   136K  (1)|   1733K|00:00:06.97 |     497K|    497K|      0 |
|*152 |                    HASH JOIN                                 |                               |      1 |      5 |   136K  (1)|   1733K|00:00:06.85 |     497K|    497K|      0 |
| 153 |                     JOIN FILTER CREATE                       | :BF0003                       |      1 |    508 |     5   (0)|    492 |00:00:00.01 |       0 |      0 |      0 |
| 154 |                      VIEW                                    |                               |      1 |    508 |     5   (0)|    492 |00:00:00.01 |       0 |      0 |      0 |
| 155 |                       TABLE ACCESS STORAGE FULL              | SYS_TEMP_0FD9E76D7_92BF0312   |      1 |    508 |     5   (0)|    492 |00:00:00.01 |       0 |      0 |      0 |
| 156 |                     JOIN FILTER USE                          | :BF0003                       |      1 |    712K|   136K  (1)|     13M|00:00:03.46 |     497K|    497K|      0 |
|*157 |                      TABLE ACCESS STORAGE FULL               | AD_PORTFOLIO_DETAIL           |      1 |    712K|   136K  (1)|     13M|00:00:03.39 |     497K|    497K|      0 |
|*158 |                   VIEW                                       |                               |      1 |    667K|   103   (3)|      1 |00:00:00.01 |       0 |      0 |      0 |
| 159 |                    JOIN FILTER USE                           | :BF0002                       |      1 |    667K|   103   (3)|     13 |00:00:00.01 |       0 |      0 |      0 |
|*160 |                     TABLE ACCESS STORAGE FULL                | SYS_TEMP_0FD9E76D8_92BF0312   |      1 |    667K|   103   (3)|     13 |00:00:00.01 |       0 |      0 |      0 |
|*161 |                HASH JOIN RIGHT OUTER                         |                               |      1 |    508 |   153K  (1)|    492 |00:00:10.73 |     850K|    524K|  28098 |
| 162 |                 VIEW                                         |                               |      1 |      1 |   137K  (1)|    382 |00:00:10.60 |     822K|    524K|  28098 |
| 163 |                  HASH GROUP BY                               |                               |      1 |      1 |   137K  (1)|    382 |00:00:10.60 |     822K|    524K|  28098 |
|*164 |                   HASH JOIN                                  |                               |      1 |      1 |   137K  (1)|    715K|00:00:04.62 |     497K|    524K|  28098 |
| 165 |                    JOIN FILTER CREATE                        | :BF0004                       |      1 |      5 |   136K  (1)|   1893K|00:00:06.34 |     497K|    497K|      0 |
|*166 |                     HASH JOIN                                |                               |      1 |      5 |   136K  (1)|   1893K|00:00:06.23 |     497K|    497K|      0 |
| 167 |                      JOIN FILTER CREATE                      | :BF0005                       |      1 |    508 |     5   (0)|    492 |00:00:00.01 |       0 |      0 |      0 |
| 168 |                       VIEW                                   |                               |      1 |    508 |     5   (0)|    492 |00:00:00.01 |       0 |      0 |      0 |
| 169 |                        TABLE ACCESS STORAGE FULL             | SYS_TEMP_0FD9E76D7_92BF0312   |      1 |    508 |     5   (0)|    492 |00:00:00.01 |       0 |      0 |      0 |
| 170 |                      JOIN FILTER USE                         | :BF0005                       |      1 |    712K|   136K  (1)|     13M|00:00:03.11 |     497K|    497K|      0 |
|*171 |                       TABLE ACCESS STORAGE FULL              | AD_PORTFOLIO_DETAIL           |      1 |    712K|   136K  (1)|     13M|00:00:03.05 |     497K|    497K|      0 |
|*172 |                    VIEW                                      |                               |      1 |    667K|   103   (3)|      1 |00:00:00.01 |       0 |      0 |      0 |
| 173 |                     JOIN FILTER USE                          | :BF0004                       |      1 |    667K|   103   (3)|     13 |00:00:00.01 |       0 |      0 |      0 |
|*174 |                      TABLE ACCESS STORAGE FULL               | SYS_TEMP_0FD9E76D8_92BF0312   |      1 |    667K|   103   (3)|     13 |00:00:00.01 |       0 |      0 |      0 |
|*175 |                 HASH JOIN RIGHT OUTER                        |                               |      1 |    508 | 16435   (1)|    492 |00:00:00.13 |   27962 |      0 |      0 |
| 176 |                  VIEW                                        |                               |      1 |      1 |   793   (1)|      0 |00:00:00.01 |      18 |      0 |      0 |
| 177 |                   NESTED LOOPS                               |                               |      1 |      1 |   793   (1)|      0 |00:00:00.01 |      18 |      0 |      0 |
| 178 |                    VIEW                                      |                               |      1 |    211 |   160   (1)|      0 |00:00:00.01 |      18 |      0 |      0 |
| 179 |                     HASH GROUP BY                            |                               |      1 |    211 |   160   (1)|      0 |00:00:00.01 |      18 |      0 |      0 |
|*180 |                      FILTER                                  |                               |      1 |        |            |      0 |00:00:00.01 |      18 |      0 |      0 |
| 181 |                       NESTED LOOPS                           |                               |      1 |    211 |   159   (0)|      0 |00:00:00.01 |      18 |      0 |      0 |
| 182 |                        FAST DUAL                             |                               |      1 |      1 |     2   (0)|      1 |00:00:00.01 |       0 |      0 |      0 |
| 183 |                        TABLE ACCESS BY INDEX ROWID BATCHED   | AD_CLIENT_STATEMENT_HISTORY   |      1 |    211 |   157   (0)|      0 |00:00:00.01 |      18 |      0 |      0 |
|*184 |                         INDEX RANGE SCAN                     | PK_AD_CL_HISTORY              |      1 |    195 |     3   (0)|      0 |00:00:00.01 |      18 |      0 |      0 |
|*185 |                    VIEW                                      | AD_CLIENT_STATEMENT_HIST_VIEW |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 186 |                     UNION-ALL PARTITION                      |                               |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
| 187 |                      TABLE ACCESS BY INDEX ROWID             | AD_CLIENT_STATEMENT_HISTORY   |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*188 |                       INDEX UNIQUE SCAN                      | PK_AD_CL_HISTORY              |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 189 |                      TABLE ACCESS BY INDEX ROWID             | AD_CLIENT_STATEMENT_HIST_ARCH |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*190 |                       INDEX UNIQUE SCAN                      | AD_CL_STM_ARCH_PK             |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*191 |                  HASH JOIN RIGHT OUTER                       |                               |      1 |    508 | 15642   (1)|    492 |00:00:00.13 |   27944 |      0 |      0 |
| 192 |                   VIEW                                       |                               |      1 |      1 |   798   (1)|      0 |00:00:00.01 |     146 |      0 |      0 |
| 193 |                    NESTED LOOPS                              |                               |      1 |      1 |   798   (1)|      0 |00:00:00.01 |     146 |      0 |      0 |
| 194 |                     VIEW                                     |                               |      1 |    209 |   171   (1)|      0 |00:00:00.01 |     146 |      0 |      0 |
| 195 |                      HASH GROUP BY                           |                               |      1 |    209 |   171   (1)|      0 |00:00:00.01 |     146 |      0 |      0 |
| 196 |                       NESTED LOOPS                           |                               |      1 |    209 |   170   (0)|      0 |00:00:00.01 |     146 |      0 |      0 |
| 197 |                        FAST DUAL                             |                               |      1 |      1 |     2   (0)|      1 |00:00:00.01 |       0 |      0 |      0 |
| 198 |                        TABLE ACCESS BY INDEX ROWID BATCHED   | AD_CLIENT_STATEMENT_HISTORY   |      1 |    209 |   168   (0)|      0 |00:00:00.01 |     146 |      0 |      0 |
|*199 |                         INDEX RANGE SCAN                     | PK_AD_CL_HISTORY              |      1 |    209 |     3   (0)|      0 |00:00:00.01 |     146 |      0 |      0 |
|*200 |                     VIEW                                     | AD_CLIENT_STATEMENT_HIST_VIEW |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 201 |                      UNION-ALL PARTITION                     |                               |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
| 202 |                       TABLE ACCESS BY INDEX ROWID            | AD_CLIENT_STATEMENT_HISTORY   |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*203 |                        INDEX UNIQUE SCAN                     | PK_AD_CL_HISTORY              |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 204 |                       TABLE ACCESS BY INDEX ROWID            | AD_CLIENT_STATEMENT_HIST_ARCH |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*205 |                        INDEX UNIQUE SCAN                     | AD_CL_STM_ARCH_PK             |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*206 |                   HASH JOIN RIGHT OUTER                      |                               |      1 |    508 | 14844   (1)|    492 |00:00:00.13 |   27798 |      0 |      0 |
| 207 |                    VIEW                                      |                               |      1 |      1 |   804   (1)|      0 |00:00:00.01 |      18 |      0 |      0 |
| 208 |                     NESTED LOOPS                             |                               |      1 |      1 |   804   (1)|      0 |00:00:00.01 |      18 |      0 |      0 |
| 209 |                      VIEW                                    |                               |      1 |    211 |   171   (1)|      0 |00:00:00.01 |      18 |      0 |      0 |
| 210 |                       HASH GROUP BY                          |                               |      1 |    211 |   171   (1)|      0 |00:00:00.01 |      18 |      0 |      0 |
|*211 |                        FILTER                                |                               |      1 |        |            |      0 |00:00:00.01 |      18 |      0 |      0 |
| 212 |                         NESTED LOOPS                         |                               |      1 |    211 |   170   (0)|      0 |00:00:00.01 |      18 |      0 |      0 |
| 213 |                          FAST DUAL                           |                               |      1 |      1 |     2   (0)|      1 |00:00:00.01 |       0 |      0 |      0 |
| 214 |                          TABLE ACCESS BY INDEX ROWID BATCHED | AD_CLIENT_STATEMENT_HISTORY   |      1 |    211 |   168   (0)|      0 |00:00:00.01 |      18 |      0 |      0 |
|*215 |                           INDEX RANGE SCAN                   | PK_AD_CL_HISTORY              |      1 |    209 |     3   (0)|      0 |00:00:00.01 |      18 |      0 |      0 |
|*216 |                      VIEW                                    | AD_CLIENT_STATEMENT_HIST_VIEW |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 217 |                       UNION-ALL PARTITION                    |                               |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
| 218 |                        TABLE ACCESS BY INDEX ROWID           | AD_CLIENT_STATEMENT_HISTORY   |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*219 |                         INDEX UNIQUE SCAN                    | PK_AD_CL_HISTORY              |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 220 |                        TABLE ACCESS BY INDEX ROWID           | AD_CLIENT_STATEMENT_HIST_ARCH |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*221 |                         INDEX UNIQUE SCAN                    | AD_CL_STM_ARCH_PK             |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*222 |                    HASH JOIN RIGHT OUTER                     |                               |      1 |    508 | 14039   (1)|    492 |00:00:00.13 |   27780 |      0 |      0 |
| 223 |                     VIEW                                     |                               |      1 |      1 | 14034   (1)|    492 |00:00:00.13 |   27780 |      0 |      0 |
| 224 |                      NESTED LOOPS OUTER                      |                               |      1 |      1 | 14034   (1)|    492 |00:00:00.13 |   27780 |      0 |      0 |
|*225 |                       HASH JOIN                              |                               |      1 |      1 | 14033   (1)|    492 |00:00:00.13 |   27772 |      0 |      0 |
| 226 |                        JOIN FILTER CREATE                    | :BF0006                       |      1 |      3 | 14028   (1)|    492 |00:00:00.13 |   27772 |      0 |      0 |
| 227 |                         NESTED LOOPS                         |                               |      1 |      3 | 14028   (1)|    492 |00:00:00.13 |   27772 |      0 |      0 |
| 228 |                          NESTED LOOPS                        |                               |      1 |     43 | 14028   (1)|   1349 |00:00:00.12 |   26728 |      0 |      0 |
|*229 |                           HASH JOIN                          |                               |      1 |     43 | 13861   (1)|    492 |00:00:00.12 |   25521 |      0 |      0 |
| 230 | ED                         TABLE ACCESS BY INDEX ROWID BATCH | G_PIECE                       |      1 |    492 |   357   (0)|    492 |00:00:00.01 |     478 |      0 |      0 |
|*231 |                             INDEX RANGE SCAN                 | G_PIECE_TYPE_REFPIECE_INX     |      1 |    492 |     6   (0)|    492 |00:00:00.01 |      19 |      0 |      0 |
|*232 |                            VIEW                              |                               |      1 |     43 | 13504   (1)|   5142 |00:00:00.12 |   25043 |      0 |      0 |
|*233 |                             WINDOW SORT PUSHED RANK          |                               |      1 |     43 | 13504   (1)|   5142 |00:00:00.12 |   25043 |      0 |      0 |
|*234 |                              HASH JOIN                       |                               |      1 |     43 | 13503   (1)|  12090 |00:00:00.09 |   25043 |      0 |      0 |
|*235 | TCHED                         TABLE ACCESS BY INDEX ROWID BA | G_PIECEDET                    |      1 |  21248 | 13498   (1)|  28335 |00:00:00.07 |   25043 |      0 |      0 |
|*236 |                                INDEX RANGE SCAN              | GPDET_TYP_REF_IDX             |      1 |  28322 |   233   (0)|  28335 |00:00:00.01 |     314 |      0 |      0 |
| 237 |                               VIEW                           |                               |      1 |    508 |     5   (0)|    492 |00:00:00.01 |       0 |      0 |      0 |
| 238 |                                TABLE ACCESS STORAGE FULL     | SYS_TEMP_0FD9E76D7_92BF0312   |      1 |    508 |     5   (0)|    492 |00:00:00.01 |       0 |      0 |      0 |
|*239 |                           INDEX RANGE SCAN                   | GPDET_TYP_REF_IDX             |    492 |      1 |     3   (0)|   1349 |00:00:00.01 |    1207 |      0 |      0 |
|*240 |                          TABLE ACCESS BY INDEX ROWID         | G_PIECEDET                    |   1349 |      1 |     4   (0)|    492 |00:00:00.01 |    1044 |      0 |      0 |
| 241 |                        VIEW                                  |                               |      1 |    508 |     5   (0)|    492 |00:00:00.01 |       0 |      0 |      0 |
| 242 |                         JOIN FILTER USE                      | :BF0006                       |      1 |    508 |     5   (0)|    492 |00:00:00.01 |       0 |      0 |      0 |
|*243 |                          TABLE ACCESS STORAGE FULL           | SYS_TEMP_0FD9E76D7_92BF0312   |      1 |    508 |     5   (0)|    492 |00:00:00.01 |       0 |      0 |      0 |
|*244 |                       INDEX RANGE SCAN                       | V_DOMAINE_IND                 |    492 |      1 |     1   (0)|    492 |00:00:00.01 |       8 |      0 |      0 |
| 245 |                     VIEW                                     |                               |      1 |    508 |     5   (0)|    492 |00:00:00.01 |       0 |      0 |      0 |
| 246 |                      TABLE ACCESS STORAGE FULL               | SYS_TEMP_0FD9E76D7_92BF0312   |      1 |    508 |     5   (0)|    492 |00:00:00.01 |       0 |      0 |      0 |
| 247 |          VIEW                                                |                               |      1 |    143K|    90M  (1)|    450 |00:00:10.01 |   83670 |  83653 |      0 |
| 248 |           HASH GROUP BY                                      |                               |      1 |    143K|    90M  (1)|    450 |00:00:10.01 |   83670 |  83653 |      0 |
| 249 |            VIEW                                              |                               |      1 |   2411M|    65M  (1)|   9303K|00:00:02.29 |   83670 |  83653 |      0 |
| 250 |             JOIN FILTER USE                                  | :BF0000                       |      1 |   2411M|    65M  (1)|   9303K|00:00:02.25 |   83670 |  83653 |      0 |
|*251 |              TABLE ACCESS STORAGE FULL                       | SYS_TEMP_0FD9E76DB_92BF0312   |      1 |   2411M|    65M  (1)|   9303K|00:00:02.22 |   83670 |  83653 |      0 |
| 252 |      VIEW                                                    |                               |      1 |    143K|    81M  (1)|    438 |00:00:02.51 |   83667 |  83653 |      0 |
| 253 |       HASH GROUP BY                                          |                               |      1 |    143K|    81M  (1)|    438 |00:00:02.51 |   83667 |  83653 |      0 |
|*254 |        VIEW                                                  |                               |      1 |   2411M|    65M  (1)|   4071K|00:00:02.01 |   83667 |  83653 |      0 |
| 255 |         TABLE ACCESS STORAGE FULL                            | SYS_TEMP_0FD9E76DB_92BF0312   |      1 |   2411M|    65M  (1)|   9303K|00:00:01.76 |   83667 |  83653 |      0 |
---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   3 - access("C"."ANCREFDOSS"="CLA"."CONTRACT_NUMBER")
   9 - access(SYS_OP_ATG(VALUE(KOKBF$),1,2,2)=SYS_OP_ATG(VALUE(KOKBF$),1,2,2))
  21 - filter(("CLST"."CONTRACT_NUMBER"="CLA"."CONTRACT_NUMBER" AND "CLST"."CONTRACT_CASE"="CLA"."REFLOT"))
  24 - access("DATE_ID"=TO_NUMBER("DAYS"."DAY_OF_MONTH_J") AND "CL_ACCOUNT_CASE"="CLA"."REFDOSS" AND "MEMO_SOURCE"='A')
  26 - access("DATE_ID"=TO_NUMBER("DAYS"."DAY_OF_MONTH_J") AND "CL_ACCOUNT_CASE"="CLA"."REFDOSS" AND "MEMO_SOURCE"='A')
  36 - filter(("CLST"."CONTRACT_NUMBER"="CLA"."CONTRACT_NUMBER" AND "CLST"."CONTRACT_CASE"="CLA"."REFLOT"))
  39 - access("DATE_ID"=TO_NUMBER("DAYS"."DAY_OF_MONTH_J") AND "CL_ACCOUNT_CASE"="CLA"."REFDOSS" AND "MEMO_SOURCE"='A')
  41 - access("DATE_ID"=TO_NUMBER("DAYS"."DAY_OF_MONTH_J") AND "CL_ACCOUNT_CASE"="CLA"."REFDOSS" AND "MEMO_SOURCE"='A')
  43 - access("TL"."LISTTYPE"="PD"."TYPE")
  44 - access("PD"."SUBCONTRACT_CASE"="PL"."IMX_CASE_REFERENCE")
       filter(((TRUNC(INTERNAL_FUNCTION("PD"."TECR_DTJOUR_DT"))>=INTERNAL_FUNCTION("PL"."LAST_3_MONTH_LAST_YEAR_START_DATE") AND
              TRUNC(INTERNAL_FUNCTION("PD"."TECR_DTJOUR_DT"))<=INTERNAL_FUNCTION("PL"."LAST_MONTH_END_DATE")) OR
              (TRUNC(INTERNAL_FUNCTION("PD"."TECR_DTJOUR_DT"))>=INTERNAL_FUNCTION("PL"."START_DATE") AND
              TRUNC(INTERNAL_FUNCTION("PD"."TECR_DTJOUR_DT"))<=INTERNAL_FUNCTION("PL"."END_DATE"))))
  48 - filter("TL"."LISTAREA"<>'?')
  52 - access("NROD"."IMX_CASE_REFERENCE"="PL"."IMX_CASE_REFERENCE")
       filter("NROD"."IMX_CASE_REFERENCE"='0001010345')
  54 - access("CS_AVG_UB_LY"."IMX_CASE_REFERENCE"="PL"."IMX_CASE_REFERENCE")
  59 - filter(("DATE_ID" IS NOT NULL AND "CLIENTSTATEMENT_DAYS_PREP_LAST_YEAR"."FIU" IS NOT NULL))
  64 - access("CLST"."CONTRACT_NUMBER"="DAYS"."CONTRACT_NUMBER" AND "CLST"."CONTRACT_CASE"="DAYS"."IMX_CONTRACT_REFERENCE" AND
              "CLST"."CL_ACCOUNT_CASE"="DAYS"."IMX_CASE_REFERENCE")
       filter(("CLST"."DATE_ID"<=TO_NUMBER("DAYS"."DAY_OF_MONTH_J") AND "CLST"."DATE_ID">=TO_NUMBER("DAYS"."START_DATE_J")))
  65 - filter("DAYS"."DATE_ID" IS NULL)
  70 - access("MEMO_SOURCE"='A')
       filter(("MEMO_SOURCE"='A' AND TRUNC(INTERNAL_FUNCTION("DT04_DT"))>=TO_DATE(' 2022-09-01 00:00:00', 'syyyy-mm-dd hh24:mi:ss')))
  71 - storage(("MEMO_SOURCE"='A' AND TRUNC(INTERNAL_FUNCTION("DT04_DT"))>=TO_DATE(' 2022-09-01 00:00:00', 'syyyy-mm-dd hh24:mi:ss')))
       filter(("MEMO_SOURCE"='A' AND TRUNC(INTERNAL_FUNCTION("DT04_DT"))>=TO_DATE(' 2022-09-01 00:00:00', 'syyyy-mm-dd hh24:mi:ss')))
  72 - filter(("CLST"."CONTRACT_NUMBER"="DAYS"."CONTRACT_NUMBER" AND "CLST"."CONTRACT_CASE"="DAYS"."IMX_CONTRACT_REFERENCE"))
  74 - filter("FIU" IS NOT NULL)
  75 - access("DATE_ID"="DAYS"."PREVIOUS_STATEMENT_DATE" AND "CL_ACCOUNT_CASE"="DAYS"."IMX_CASE_REFERENCE" AND "MEMO_SOURCE"='A')
  76 - filter("FIU" IS NOT NULL)
  77 - access("DATE_ID"="DAYS"."PREVIOUS_STATEMENT_DATE" AND "CL_ACCOUNT_CASE"="DAYS"."IMX_CASE_REFERENCE" AND "MEMO_SOURCE"='A')
 78 - access("CS_AVG_UB"."IMX_CASE_REFERENCE"="PL"."IMX_CASE_REFERENCE")
  83 - filter(("DATE_ID" IS NOT NULL AND "CLIENTSTATEMENT_DAYS_PREP"."FIU" IS NOT NULL))
  88 - access("CLST"."CONTRACT_NUMBER"="DAYS"."CONTRACT_NUMBER" AND "CLST"."CONTRACT_CASE"="DAYS"."IMX_CONTRACT_REFERENCE" AND
              "CLST"."CL_ACCOUNT_CASE"="DAYS"."IMX_CASE_REFERENCE")
       filter(("CLST"."DATE_ID"<=TO_NUMBER("DAYS"."DAY_OF_MONTH_J") AND "CLST"."DATE_ID">=TO_NUMBER("DAYS"."START_DATE_J")))
  89 - filter("DAYS"."DATE_ID" IS NULL)
  94 - access("MEMO_SOURCE"='A')
       filter(("MEMO_SOURCE"='A' AND TRUNC(INTERNAL_FUNCTION("DT04_DT"))>=TO_DATE(' 2022-09-01 00:00:00', 'syyyy-mm-dd hh24:mi:ss')))
  95 - storage(("MEMO_SOURCE"='A' AND TRUNC(INTERNAL_FUNCTION("DT04_DT"))>=TO_DATE(' 2022-09-01 00:00:00', 'syyyy-mm-dd hh24:mi:ss')))
       filter(("MEMO_SOURCE"='A' AND TRUNC(INTERNAL_FUNCTION("DT04_DT"))>=TO_DATE(' 2022-09-01 00:00:00', 'syyyy-mm-dd hh24:mi:ss')))
  96 - filter(("CLST"."CONTRACT_NUMBER"="DAYS"."CONTRACT_NUMBER" AND "CLST"."CONTRACT_CASE"="DAYS"."IMX_CONTRACT_REFERENCE"))
  98 - filter("FIU" IS NOT NULL)
  99 - access("DATE_ID"="DAYS"."PREVIOUS_STATEMENT_DATE" AND "CL_ACCOUNT_CASE"="DAYS"."IMX_CASE_REFERENCE" AND "MEMO_SOURCE"='A')
100 - filter("FIU" IS NOT NULL)
101 - access("DATE_ID"="DAYS"."PREVIOUS_STATEMENT_DATE" AND "CL_ACCOUNT_CASE"="DAYS"."IMX_CASE_REFERENCE" AND "MEMO_SOURCE"='A')
102 - access("PDS"."IMX_CONTRACT_REFERENCE"="PL"."IMX_CONTRACT_REFERENCE" AND "PDS"."IMX_CASE_REFERENCE"="PL"."IMX_CASE_REFERENCE")
104 - access("MFT"."CONTRACT_NUMBER"="PL"."CONTRACT_NUMBER" AND "MFT"."IMX_CASE_REFERENCE"="PL"."IMX_CASE_REFERENCE")
111 - filter(("L"."REFGROUP"="PL"."CONTRACT_NUMBER" AND "L"."START_DT"<=INTERNAL_FUNCTION("PL"."END_DATE") AND ("L"."END_DT" IS NULL OR
              "L"."END_DT">=INTERNAL_FUNCTION("PL"."END_DATE"))))
112 - access("PRE_RATINGS"."REFINDIVIDU"="PL"."IMX_CLIENT_REFERENCE")
113 - filter("RANK_X"=1)
115 - filter(RANK() OVER ( PARTITION BY "FIN"."REFINDIVIDU" ORDER BY "FIN"."TYPE",INTERNAL_FUNCTION("FIN"."DT01_DT") DESC )<=1)
119 - filter(TRUNC(INTERNAL_FUNCTION("FIN"."DT01_DT"))<=TRUNC(TRUNC(TO_DATE(:P_DATE,'yyyy/mm/dd'),'fmiw')-.00001157407407407407407407407407407407407407))
120 - access((("FIN"."TYPE"='COTE FACTOR' OR "FIN"."TYPE"='COTE FACTOR HIS')) AND "FIN"."STR1"='FIN')
121 - access("SCA"."IMX_CONTRACT_REFERENCE"="PL"."IMX_CONTRACT_REFERENCE" AND "SCA"."IMX_CASE_REFERENCE"="PL"."IMX_CASE_REFERENCE")
131 - access("CLA"."REFDOSS"="BFD"."REFDOSS")
       filter("BFD"."REFDOSS" IS NOT NULL)
132 - filter((INTERNAL_FUNCTION("BFD"."TYPMVT") AND ((TRUNC(INTERNAL_FUNCTION("BFD"."DTVENTIL_DT"))>=TRUNC(TO_DATE(:P_DATE,'yyyy/mm/dd'),'fmiw')-7 AND
              TRUNC(INTERNAL_FUNCTION("BFD"."DTVENTIL_DT"))<=TRUNC(TO_DATE(:P_DATE,'yyyy/mm/dd'),'fmiw')-.00001157407407407407407407407407407407407407) OR
              (TRUNC(INTERNAL_FUNCTION("BFD"."DTVENTIL_DT"))>=TRUNC(ADD_MONTHS(TO_DATE(:P_DATE,'yyyy/mm/dd')-7,(-12)),'fmmm') AND
              TRUNC(INTERNAL_FUNCTION("BFD"."DTVENTIL_DT"))<=LAST_DAY(TRUNC(ADD_MONTHS(TO_DATE(:P_DATE,'yyyy/mm/dd')-7,(-1)),'fmmm'))))))
133 - access("FR"."REFDOSS"="PL"."IMX_CASE_REFERENCE")
139 - access("PD"."REFDOSS"="CLA"."REFDOSS")
141 - filter(("PD"."STR2"='PDEF' AND "PD"."REFDOSS" IS NOT NULL AND "PD"."DW_ACTION"<>'D'))
142 - access("PD"."TYPE"='FINRATE')
144 - storage(SYS_OP_BLOOM_FILTER(:BF0001,"CLA"."REFDOSS"))
       filter(SYS_OP_BLOOM_FILTER(:BF0001,"CLA"."REFDOSS"))
145 - access("FRLR"."UN_ID"="PD"."IMX_UN_ID")
146 - filter(("PD"."TYPE"='FINRATE' AND "PD"."STR2"='PDEF'))
147 - access("PDS_UB_LY"."IMX_CONTRACT_REFERENCE"="PL"."IMX_CONTRACT_REFERENCE" AND "PDS_UB_LY"."IMX_CASE_REFERENCE"="PL"."IMX_CASE_REFERENCE")
150 - access("TL"."LISTTYPE"="PFD"."TYPE")
152 - access("PFD"."CAP_CASE"="PL"."IMX_CONTRACT_REFERENCE" AND "PFD"."SUBCONTRACT_CASE"="PL"."IMX_CASE_REFERENCE")
       filter(("PFD"."TECR_DTJOUR_DT"<=INTERNAL_FUNCTION("PL"."LAST_MONTH_LAST_YEAR_END_DATE") AND
              "PFD"."TECR_DTJOUR_DT">=INTERNAL_FUNCTION("PL"."LAST_3_MONTH_LAST_YEAR_START_DATE")))
157 - storage((TRUNC(INTERNAL_FUNCTION("PFD"."TECR_DTJOUR_DT"))>=TO_DATE(' 2022-09-01 00:00:00', 'syyyy-mm-dd hh24:mi:ss') AND
              SYS_OP_BLOOM_FILTER(:BF0003,"PFD"."CAP_CASE","PFD"."SUBCONTRACT_CASE")))
       filter((TRUNC(INTERNAL_FUNCTION("PFD"."TECR_DTJOUR_DT"))>=TO_DATE(' 2022-09-01 00:00:00', 'syyyy-mm-dd hh24:mi:ss') AND
              SYS_OP_BLOOM_FILTER(:BF0003,"PFD"."CAP_CASE","PFD"."SUBCONTRACT_CASE")))
158 - filter("TL"."LISTAREA"='INVOICE')
160 - storage(SYS_OP_BLOOM_FILTER(:BF0002,"C0"))
       filter(SYS_OP_BLOOM_FILTER(:BF0002,"C0"))
161 - access("PDS_UB"."IMX_CONTRACT_REFERENCE"="PL"."IMX_CONTRACT_REFERENCE" AND "PDS_UB"."IMX_CASE_REFERENCE"="PL"."IMX_CASE_REFERENCE")
164 - access("TL"."LISTTYPE"="PFD"."TYPE")
166 - access("PFD"."CAP_CASE"="PL"."IMX_CONTRACT_REFERENCE" AND "PFD"."SUBCONTRACT_CASE"="PL"."IMX_CASE_REFERENCE")
       filter(("PFD"."TECR_DTJOUR_DT"<=INTERNAL_FUNCTION("PL"."LAST_MONTH_END_DATE") AND "PFD"."TECR_DTJOUR_DT">=INTERNAL_FUNCTION("PL"."LAST_3_MONTH_START_DATE")))
171 - storage((TRUNC(INTERNAL_FUNCTION("PFD"."TECR_DTJOUR_DT"))>=TO_DATE(' 2022-09-01 00:00:00', 'syyyy-mm-dd hh24:mi:ss') AND
              SYS_OP_BLOOM_FILTER(:BF0005,"PFD"."CAP_CASE","PFD"."SUBCONTRACT_CASE")))
       filter((TRUNC(INTERNAL_FUNCTION("PFD"."TECR_DTJOUR_DT"))>=TO_DATE(' 2022-09-01 00:00:00', 'syyyy-mm-dd hh24:mi:ss') AND
              SYS_OP_BLOOM_FILTER(:BF0005,"PFD"."CAP_CASE","PFD"."SUBCONTRACT_CASE")))
172 - filter("TL"."LISTAREA"='INVOICE')
174 - storage(SYS_OP_BLOOM_FILTER(:BF0004,"C0"))
       filter(SYS_OP_BLOOM_FILTER(:BF0004,"C0"))
175 - access("CLS_WB"."IMX_CONTRACT_REFERENCE"="PL"."IMX_CONTRACT_REFERENCE" AND "CLS_WB"."IMX_CASE_REFERENCE"="PL"."IMX_CASE_REFERENCE")
180 - filter(TRUNC(TO_NUMBER(TO_CHAR(TRUNC(TO_DATE(:P_DATE,'yyyy/mm/dd'),'fmiw')-.00001157407407407407407407407407407407407407,'j'))-7)>=TRUNC(TO_NUMBER(TO_CHAR(TRUNC(TO_DATE
              (:P_DATE,'yyyy/mm/dd'),'fmiw')-7,'j'))-7))
184 - access("CLST"."DATE_ID">=TRUNC(TO_NUMBER(TO_CHAR(TRUNC(TO_DATE(:P_DATE,'yyyy/mm/dd'),'fmiw')-7,'j'))-7) AND "CLST"."MEMO_SOURCE"='A' AND
              "CLST"."DATE_ID"<=TRUNC(TO_NUMBER(TO_CHAR(TRUNC(TO_DATE(:P_DATE,'yyyy/mm/dd'),'fmiw')-.00001157407407407407407407407407407407407407,'j'))-7))
       filter("CLST"."MEMO_SOURCE"='A')
185 - filter("CLST"."CONTRACT_CASE"="STMTD"."IMX_CONTRACT_REFERENCE")
188 - access("DATE_ID"="STMTD"."STATEMENT_DATE" AND "CL_ACCOUNT_CASE"="STMTD"."IMX_CASE_REFERENCE" AND "MEMO_SOURCE"='A')
190 - access("DATE_ID"="STMTD"."STATEMENT_DATE" AND "CL_ACCOUNT_CASE"="STMTD"."IMX_CASE_REFERENCE" AND "MEMO_SOURCE"='A')
191 - access("CLS_CURERNT"."IMX_CONTRACT_REFERENCE"="PL"."IMX_CONTRACT_REFERENCE" AND "CLS_CURERNT"."IMX_CASE_REFERENCE"="PL"."IMX_CASE_REFERENCE")
199 - access("CLST"."MEMO_SOURCE"='A' AND "CLST"."DATE_ID"<=TRUNC(TO_NUMBER(TO_CHAR(TRUNC(TO_DATE(:P_DATE,'yyyy/mm/dd'),'fmiw')-.00001157407407407407407407407407407407407407,
              'j'))))
       filter("CLST"."MEMO_SOURCE"='A')
200 - filter("CLST"."CONTRACT_CASE"="STMTD"."IMX_CONTRACT_REFERENCE")
203 - access("DATE_ID"="STMTD"."STATEMENT_DATE" AND "CL_ACCOUNT_CASE"="STMTD"."IMX_CASE_REFERENCE" AND "MEMO_SOURCE"='A')
205 - access("DATE_ID"="STMTD"."STATEMENT_DATE" AND "CL_ACCOUNT_CASE"="STMTD"."IMX_CASE_REFERENCE" AND "MEMO_SOURCE"='A')
206 - access("CLS"."IMX_CONTRACT_REFERENCE"="PL"."IMX_CONTRACT_REFERENCE" AND "CLS"."IMX_CASE_REFERENCE"="PL"."IMX_CASE_REFERENCE")
211 - filter(TRUNC(TO_NUMBER(TO_CHAR(TRUNC(TO_DATE(:P_DATE,'yyyy/mm/dd'),'fmiw')-.00001157407407407407407407407407407407407407,'j')))>=TRUNC(TO_NUMBER(TO_CHAR(TRUNC(TO_DATE(:
              P_DATE,'yyyy/mm/dd'),'fmiw')-7,'j'))))
215 - access("CLST"."DATE_ID">=TRUNC(TO_NUMBER(TO_CHAR(TRUNC(TO_DATE(:P_DATE,'yyyy/mm/dd'),'fmiw')-7,'j'))) AND "CLST"."MEMO_SOURCE"='A' AND
              "CLST"."DATE_ID"<=TRUNC(TO_NUMBER(TO_CHAR(TRUNC(TO_DATE(:P_DATE,'yyyy/mm/dd'),'fmiw')-.00001157407407407407407407407407407407407407,'j'))))
       filter("CLST"."MEMO_SOURCE"='A')
216 - filter("CLST"."CONTRACT_CASE"="STMTD"."IMX_CONTRACT_REFERENCE")
219 - access("DATE_ID"="STMTD"."STATEMENT_DATE" AND "CL_ACCOUNT_CASE"="STMTD"."IMX_CASE_REFERENCE" AND "MEMO_SOURCE"='A')
221 - access("DATE_ID"="STMTD"."STATEMENT_DATE" AND "CL_ACCOUNT_CASE"="STMTD"."IMX_CASE_REFERENCE" AND "MEMO_SOURCE"='A')
222 - access("STATUS"."IMX_CASE_REFERENCE"="PL"."IMX_CASE_REFERENCE")
225 - access("PD"."REFDOSS"="STATUS"."IMX_CASE_REFERENCE")
229 - access("LAST_STUS"."REFPIECE"="P"."REFPIECE")
231 - access("P"."TYPPIECE"='SOUS-CONTRAT')
232 - filter("LAST_STUS"."RN"=1)
233 - filter(ROW_NUMBER() OVER ( PARTITION BY "A"."REFPIECE" ORDER BY INTERNAL_FUNCTION("A"."IMX_UN_ID") DESC )<=1)
234 - access("A"."REFDOSS"="STATUS"."IMX_CASE_REFERENCE")
235 - filter("A"."REFDOSS" IS NOT NULL)
236 - access("A"."TYPE"='CONTRACT SITUATIONS')
239 - access("PD"."TYPE"='CONTRACT SITUATIONS' AND "PD"."REFPIECE"="P"."REFPIECE")
240 - filter(("PD"."STR1"="LAST_STUS"."STATUS" AND "PD"."REFDOSS" IS NOT NULL AND "PD"."STR1" IS NOT NULL))
243 - storage(SYS_OP_BLOOM_FILTER(:BF0006,"C20"))
       filter(SYS_OP_BLOOM_FILTER(:BF0006,"C20"))
244 - access("VD"."TYPE"='CONRSIT' AND "PD"."STR1"="VD"."ABREV")
251 - storage(SYS_OP_BLOOM_FILTER(:BF0000,"C1","C2"))
       filter(SYS_OP_BLOOM_FILTER(:BF0000,"C1","C2
*/
/********************************New Metrics***************************************/

/********************************Index statistics**********************************/

/********************************Other SQLs****************************************/          
/*

*/ 
/********************************Other SQLs****************************************/              
