oracle@sv364 @ (/home/oracle) # sqlplus / as sysdba

SQL> show parameter unique

NAME                                 TYPE        VALUE
------------------------------------ ----------- ------------------------------
db_unique_name                       string      DIAP


SQL> set lines 400 pages 100                                              ############ Да видим running and completed backups ######
col device for a8
SQL> SQL> col time_taken for a8
col START__TIME for a19
SQL> SQL> col END_TIME for a19
SQL> column TIME_TAKEN_DISPLAY format a40;
SQL> col status for a28
select command_id,TO_CHAR(start_time, 'MM/DD/YY HH24:MI:SS') as start__time,
TO_CHAR(end_time, 'MM/DD/YY HH24:MI:SS') as end_time, output_device_type as device,input_type,time_taken_display as time_taken, status
from V_$RMAN_BACKUP_JOB_DETAILS order by start_time;SQL>   2    3

COMMAND_ID                        START__TIME         END_TIME            DEVICE   INPUT_TYPE    TIME_TAK STATUS
--------------------------------- ------------------- ------------------- -------- ------------- -------- --------------------------

2019-07-24T11:19:07               07/24/19 11:19:14   07/24/19 11:20:32   SBT_TAPE ARCHIVELOG    00:01:18 COMPLETED
2019-07-24T12:20:10               07/24/19 12:20:17   07/24/19 12:21:39   SBT_TAPE ARCHIVELOG    00:01:22 COMPLETED
2019-07-24T13:20:10               07/24/19 13:20:17   07/24/19 13:21:50   SBT_TAPE ARCHIVELOG    00:01:33 COMPLETED

286 filas seleccionadas.

SQL> set lines 400                                                  ###### Long ops operations ###############
col TARGET for a15
col TARGET_DESC for a10
col UNITS for a10
col TIME_REMAINING for a20
col OPNAME for a35
col LAST_UPDATE_TIME for a20
SQL> SQL> SQL> SQL> SQL> SQL> SQL> col START_TIME for a20
SELECT inst_id,SID, SERIAL#,OPNAME, SQL_ID, to_char(START_TIME, 'YYYY/MON/DD HH24:MI:SS') "START_TIME",
SQL>   2  to_char(LAST_UPDATE_TIME, 'YYYY/MON/DD HH24:MI:SS') "LAST_UPDATE_TIME",
TIME_REMAINING/60 as "remaining mins",
  3    4  TARGET, TARGET_DESC, SOFAR,
TOTALWORK, UNITS, ROUND(SOFAR/TOTALWORK*100,2) "%_COMPLETE"
FROM GV$SESSION_LONGOPS
WHERE
  5    6    7    8  TOTALWORK != 0
AND SOFAR <> TOTALWORK
order by START_TIME;  9   10


   INST_ID        SID    SERIAL# OPNAME                              SQL_ID        START_TIME           LAST_UPDATE_TIME     remaining mins TARGET          TARGET_DES      SOFAR  TOTALWORK UNITS      %_COMPLETE
---------- ---------- ---------- ----------------------------------- ------------- -------------------- -------------------- -------------- --------------- ---------- ---------- ---------- ---------- ----------
         1        417      17251 Sort Output                         0pvfvdj4gx6hu 2019/JUL/24 18:35:52 2019/JUL/24 18:46:31     3,11666667                                  4434       5730 Blocks          77,38





oracle@sv364 @ (/home/oracle) # crontab -l                            ######## Проверяваме Cronta-a за скрипта за backup-a #######



SQL> SET LINESIZE 400                                         ######## Quary for backup pieces  за да извадим спецификацията от там ######
SET PAGESIZE 9999
COLUMN bs_key FORMAT 9999 HEADING 'BS|Key'
SQL> SQL> SQL> COLUMN piece# FORMAT 99999 HEADING 'Piece|#'
COLUMN copy# FORMAT 9999 HEADING 'Copy|#'
COLUMN bp_key FORMAT 9999 HEADING 'BP|Key'
COLUMN status FORMAT a9 HEADING 'Status'
COLUMN handle FORMAT a65 HEADING 'Handle'
COLUMN start_time FORMAT a17 HEADING 'Start|Time'
COLUMN completion_time FORMAT a17 HEADING 'End|Time'
COLUMN elapsed_seconds FORMAT 999,999 HEADING 'Elapsed|Seconds'
COLUMN deleted FORMAT a8 HEADING 'Deleted?'
BREAK ON bs_key
prompt
prompt Available backup pieces contained in the control file.
prompt Includes available and expired backup sets.
prompt
SELECT
bs.recid bs_key
SQL> SQL> SQL> SQL> SQL> SQL> SQL> SQL> SQL> SQL>
SQL> Available backup pieces contained in the control file.
SQL> Includes available and expired backup sets.
SQL>
SQL>   2    3  , bp.piece# piece#
, bp.copy# copy#
, bp.recid bp_key
, DECODE( status
, 'A', 'Available'
, 'D', 'Deleted'
  4    5    6    7    8    9  , 'X', 'Expired') status
, handle handle
, TO_CHAR(bp.start_time, 'mm/dd/yy HH24:MI:SS') start_time
, TO_CHAR(bp.completion_time, 'mm/dd/yy HH24:MI:SS') completion_time
 10   11   12   13  , bp.elapsed_seconds elapsed_seconds
FROM
v$backup_set bs
 14   15   16  , v$backup_piece bp
WHERE
bs.set_stamp = bp.set_stamp
AND bs.set_count = bp.set_count
 17   18   19   20  AND bp.status IN ('A', 'X')
ORDER BY
bs.recid
, piece#
/ 21   22   23   24

   BS  Piece  Copy    BP                                                                             Start             End                Elapsed
  Key      #     #   Key Status    Handle                                                            Time              Time               Seconds
----- ------ ----- ----- --------- ----------------------------------------------------------------- ----------------- ----------------- --------

#####      1     1 ##### Available BCK_DC2_ARCH_pkDIPdbadm_DIAP<DIAP_250709:1014455962:1>.al         07/24/19 09:19:22 07/24/19 09:20:35       73
#####      1     1 ##### Available c-1713899410-20190724-0a                                          07/24/19 09:20:41 07/24/19 09:20:44        3
#####      1     1 ##### Available BCK_DC2_ARCH_pkDIPdbadm_DIAP<DIAP_250711:1014459562:1>.al         07/24/19 10:19:22 07/24/19 10:20:29       67
#####      1     1 ##### Available c-1713899410-20190724-0b                                          07/24/19 10:20:41 07/24/19 10:20:44        3
#####      1     1 ##### Available BCK_DC2_ARCH_pkDIPdbadm_DIAP<DIAP_250713:1014463156:1>.al         07/24/19 11:19:16 07/24/19 11:20:13       57
#####      1     1 ##### Available c-1713899410-20190724-0c                                          07/24/19 11:20:25 07/24/19 11:20:28        3
#####      1     1 ##### Available BCK_DC2_ARCH_pkDIPdbadm_DIAP<DIAP_250715:1014466823:1>.al         07/24/19 12:20:23 07/24/19 12:21:26       63
#####      1     1 ##### Available c-1713899410-20190724-0d                                          07/24/19 12:21:32 07/24/19 12:21:35        3
#####      1     1 ##### Available BCK_DC2_ARCH_pkDIPdbadm_DIAP<DIAP_250717:1014470423:1>.al         07/24/19 13:20:23 07/24/19 13:21:31       68
#####      1     1 ##### Available c-1713899410-20190724-0e                                          07/24/19 13:21:43 07/24/19 13:21:45        2

1009 filas seleccionadas.


oracle@sv364 @ (/home/oracle) # locate omnib
ksh: locate:  not found
oracle@sv364 @ (/home/oracle) # which omnib
/opt/omni/bin/omnib
oracle@sv364 @ (/home/oracle) # nohup /opt/omni/bin/omnib -Oracle8 BCK_DC2_ARCH_pkDIPdbadm_DIAP &        ###### Пускаме backup-a с nohup (виждаме къде се намира Omnib командата-> пишем -Oracle8 и след него спецификацията на backup-a

[1]     24212
oracle@sv364 @ (/home/oracle) # Sending output to nohup.out

oracle@sv364 @ (/home/oracle) # tail -100f nohup.out
oracle@sv364 @ (/home/oracle) # sql


