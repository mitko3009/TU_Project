##### UXMON: Filesystem /u01/app/oracle diskspace utilization exceeds 90 threshold. ####### 

1.nsu
2.ps -ef | grep pmon
3.su - oracle
4. . oraenv
5. cd ( kym dadenata direktoriq)
6. df -h + dadenata direktoriq

[oracle@fivatx0191 oracle]$ df -h /u01/app/oracle
Filesystem            Size  Used Avail Use% Mounted on
/dev/mapper/vgora-lv_oracle01
                       99G   84G  9.6G  90% /u01/app/oracle
					   
ls -la (dadenata direktoriq)				   
find . -xdev -mtime 0 -size +10000c -type f -exec ls -al {} \; |sort -k5nr |head -100
find . -xdev -size +10000c -type f -exec ls -al {} \; |sort -k5nr |head -100


-rwxrwxr-x 1 grid oinstall 171793890 May 26 19:41 ./diag/tnslsnr/fivatx0191/listener/trace/listener.log
-rw-rw---- 1 grid oinstall 52434800 May 26 17:59 ./diag/crs/fivatx0191/crs/trace/ocssd_16569.trc
-rw-rw---- 1 grid oinstall 52429267 May 26 11:01 ./diag/crs/fivatx0191/crs/trace/ocssd_16564.trc
-rw-rw---- 1 grid oinstall 52429252 May 26 08:14 ./diag/crs/fivatx0191/crs/trace/ocssd_16562.trc
-rw-rw---- 1 grid oinstall 52429114 May 26 13:48 ./diag/crs/fivatx0191/crs/trace/ocssd_16566.trc
-rw-r----- 1 oracle asmadmin 43058141 May 26 19:30 ./diag/rdbms/fmaxprd/FMAXPRD1/trace/alert_FMAXPRD1.log
-rwxrwxr-x 1 grid oinstall 18083727 May 26 19:41 ./diag/tnslsnr/fivatx0191/listener_scan1/trace/listener_scan1.log
-rw-r----- 1 oracle asmadmin 16138258 May 26 19:40 ./diag/rdbms/fmaxprd/FMAXPRD1/trace/FMAXPRD1_lmhb_7803.trc
-rw-rw---- 1 root oinstall 10486543 May 26 10:51 ./diag/crs/fivatx0191/crs/trace/octssd_546.trc
-rw-rw---- 1 grid oinstall 10486065 May 26 09:12 ./diag/tnslsnr/fivatx0191/listener/alert/log_10.xml
-rw-rw---- 1 grid oinstall 10486061 May 26 08:00 ./diag/crs/fivatx0191/crs/trace/ohasd_oraagent_grid_77.trc
-rw-rw---- 1 root oinstall 10485963 May 25 21:21 ./diag/crs/fivatx0191/crs/trace/ohasd_orarootagent_root_799.trc
-rw-rw---- 1 grid oinstall 10485879 May 26 00:11 ./diag/asm/+asm/+ASM1/alert/log_33.xml
-rw-rw---- 1 grid oinstall 10485879 May 26 17:46 ./diag/asm/+asm/+ASM1/alert/log_34.xml
-rw-r----- 1 oracle asmadmin 10241568 May 26 10:30 ./admin/FMAXPRD/adump/FMAXPRD1_ora_21177_20190526103002556045143795.aud
-rw-r----- 1 oracle asmadmin 10241556 May 26 10:00 ./admin/FMAXPRD/adump/FMAXPRD1_ora_6608_20190526100001631841143795.aud
-rw-r----- 1 oracle asmadmin 10241532 May 26 15:45 ./admin/FMAXPRD/adump/FMAXPRD1_ora_17100_20190526154501698285143795.aud

cd ./admin/FMAXPRD/adump   (zashtoto tam sa pokazani,che sa audit failovete)
ls -la | wc -l     (prebroqva kolko fajla ima)

### Izbqgva se taka da se izpolzvat !!!
find . -xdev -name "*.trc" -exec rm -f {} \;
find . -name "*.trm" -exec rm {} \; && find . -name "*.trc" -exec rm {} \; && find . -name "*.aud" -exec rm {} \; && find . -name "log_*.xml" -exec gzip -9f {} \; > redirection &  
find . -name "*.trm" -exec rm {} \; && find . -name "*.trc" -exec rm {} \; && find . -name "*.aud" -exec rm {} \; > redirection & 


[‎7/‎29/‎2019 9:08 AM]  Stoyanov, Evgeni: 
find . -xdev -size +100000c -type f -exec ls -la {} \; 2> /dev/null |  sort -nk5 | tail -5000
find . -xdev -name "*.tr[cm]" -type f -mtime +2 -exec rm -f {} \; 
find . -xdev -type f -name "*.aud" -exec ls -la {} \; 2> /dev/null |  sort -nk5 | tail -2000
find . -xdev -mtime +30 -type f -name "*.tr[cm].gz" -type f -exec rm -f {} \; 
find . -xdev -mtime +10 -type f -name "*.tr[cm]" -exec  gzip -9f {} \; 
find . -xdev -mtime +40 -type f -name "*.aud" -exec rm -f  {} \; 
find . -xdev -mtime +3 -type f -name "log_*.xml" -exec gzip -9f  {} \;

### Vinagi se polzva tazi posledovatelnost v AUDI
1   find . -xdev -name "*.tr[cm]" -type f -mtime +1 -exec rm -f {} \; 

2   find . -xdev -mtime +7 -type f -name "*.tr[cm].gz" -type f -exec rm -f {} \;

3   find . -xdev -mtime +0 -type f -name "*.tr[cm]" -exec  gzip -9f {} \;



find . -xdev -mtime +7 -type f -name "log_*.xml.gz" -type f -exec rm -f {} \; 

### Da gzip-nem alert log
gzip -9cv alert_SDWD.log > alert_SDWD.log`date +%Y%m%d`.gz && > alert_SDWD.log


### Find crontab log
find /var -iname "cron*.log*" -type f

 
 ######### При спешни случаи и винаги трябва да съм в трейс директорията за да го пусна и с root
 
 for f in `ls *.trc*`; do 
PROC=`fuser $f` 
if [ -n "$PROC" ]; then 
echo Skipping file $f. Running process $PROC 
continue 
fi 
rm -f $f 
done


###### Triem syshto i 'core' failove ,vinagi trqbva da sme v samata direktoriq kydeto sa te i da sa core_* ######

df -h  (proverqwame kolko % e padnala direktoriqta)

[oracle@fivatx0191 adump]$ df -h .
Filesystem            Size  Used Avail Use% Mounted on
/dev/mapper/vgora-lv_oracle01
                       99G   28G   67G  30% /u01/app/oracle