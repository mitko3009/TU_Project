/********************************************************************************
*********       E-mail subject: TFDEV-1319
*********             Instance: UAT
*********          Description: 
Problem:
PROC_DCMPT_INV batch processed takes too much time.

Analysis:
On 31/07/23 the PROC_DCMPT_INV batch processed for approximately 2 hours on UAT
and the processing time for few days before and after 31/07/23 was approximately 1 hour.
The third TOP SQL was f063xu66ztp4h.
Inneficient execution plan due to cardinality misestimates and the join predicate in function. 
The leading table should be V_DOMAINE. We had the same problem in TFDEV-552 task, and the solution there, which is 
to remove the NVL and add hints to make Oracle use appropriate execution plan. If we are sure that there are no 
NULL values, we can make the same thing here. 

Suggestion:
Please remove the NVL and add hints as it is shown in the New SQL section below.

*********               SQL_ID: f063xu66ztp4h
*********      Program/Package: PROC_DCMPT_INV 
*********              Request: Dimitare Ivanov
*********               Author: Dimitar Dimitrov	
********* Received e-mail date: 03/08/2023
*********      Resolution date: 08/08/2023
*********  Trace old file here: \\epox\specifs\performance\tmp\
*********  Trace new file here:
***********************************************************************************/

/********************************OLD SQL*******************************************/
update g_commfin
   SET montant_con = DECODE(:b0,
                            :b1,
                            montant,
                            CH_TAUX . Conv_Ori_Des_Fact(:b2,
                                              refdoss,
                                              montant,
                                              :b0,
                                              :b1,
                                              'P'))
 WHERE refdoss = :b5
   AND fg_invoiced IS NULL
   AND numfact IS NULL
   AND numfact_db IS NULL
   AND NVL(TYPE, 'FUC') IN (SELECT abrev
                              FROM v_domaine
                             WHERE type = 'COMMFIN'
                               AND abrev1 = 'FIU');

/********************************OLD SQL*******************************************/
/********************************OLD Metrics***************************************/
/*
Plan hash value: 3161438817
--------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                               | Name                    | Starts | E-Rows | A-Rows |   A-Time   | Buffers | Reads  |
--------------------------------------------------------------------------------------------------------------------------------------
|   0 | UPDATE STATEMENT                        |                         |      1 |        |      0 |00:00:14.87 |     155K|   6059 |
|   1 |  UPDATE                                 | G_COMMFIN               |      1 |        |      0 |00:00:14.87 |     155K|   6059 |
|   2 |   NESTED LOOPS                          |                         |      1 |      1 |   4556 |00:00:13.25 |   49231 |   6037 |
|   3 |    NESTED LOOPS                         |                         |      1 |     87 |   5914 |00:00:13.24 |   48713 |   6037 |
|   4 |     SORT UNIQUE                         |                         |      1 |      1 |      8 |00:00:00.01 |       7 |      0 |
|*  5 |      TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE               |      1 |      1 |     10 |00:00:00.01 |       7 |      0 |
|*  6 |       INDEX RANGE SCAN                  | V_DOMAINE_TYPE_CODE_IDX |      1 |     59 |     20 |00:00:00.01 |       2 |      0 |
|*  7 |     INDEX RANGE SCAN                    | G_COMMFIN_REFDOSS_IDX   |      8 |     87 |   5914 |00:00:13.24 |   48706 |   6037 |
|*  8 |    TABLE ACCESS BY INDEX ROWID          | G_COMMFIN               |   5914 |      3 |   4556 |00:00:00.01 |     518 |      0 |
--------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   5 - filter("ABREV1"='FIU')
   6 - access("TYPE"='COMMFIN')
   7 - access("REFDOSS"=:B5 AND "FG_INVOICED" IS NULL)
       filter(("FG_INVOICED" IS NULL AND "ABREV"=NVL("TYPE",'FUC')))
   8 - filter(("NUMFACT" IS NULL AND "NUMFACT_DB" IS NULL))
*/
/********************************OLD Metrics***************************************/

/********************************New SQL*******************************************/
update /*+ LEADING(V_DOMAINE) USE_NL(G_COMMFIN)*/ g_commfin
   SET montant_con = DECODE(:b0,
                            :b1,
                            montant,
                            CH_TAUX . Conv_Ori_Des_Fact(:b2,
                                              refdoss,
                                              montant,
                                              :b0,
                                              :b1,
                                              'P'))
 WHERE refdoss = :b5
   AND fg_invoiced IS NULL
   AND numfact IS NULL
   AND numfact_db IS NULL
   AND TYPE IN (SELECT /*+ unnest */ abrev
                              FROM v_domaine
                             WHERE type = 'COMMFIN'
                               AND abrev1 = 'FIU');

/********************************New SQL*******************************************/
/********************************New Metrics***************************************/
/*
Plan hash value: 3161438817
--------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                               | Name                    | Starts | E-Rows | A-Rows |   A-Time   | Buffers | Reads  |
--------------------------------------------------------------------------------------------------------------------------------------
|   0 | UPDATE STATEMENT                        |                         |      1 |        |      0 |00:00:02.05 |     106K|     46 |
|   1 |  UPDATE                                 | G_COMMFIN               |      1 |        |      0 |00:00:02.05 |     106K|     46 |
|   2 |   NESTED LOOPS                          |                         |      1 |      1 |   4556 |00:00:00.38 |     594 |     15 |
|   3 |    NESTED LOOPS                         |                         |      1 |     91 |   5914 |00:00:00.33 |      76 |      4 |
|   4 |     SORT UNIQUE                         |                         |      1 |      1 |      8 |00:00:00.32 |       7 |      2 |
|*  5 |      TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE               |      1 |      1 |     10 |00:00:00.31 |       7 |      2 |
|*  6 |       INDEX RANGE SCAN                  | V_DOMAINE_TYPE_CODE_IDX |      1 |     59 |     20 |00:00:00.31 |       2 |      1 |
|*  7 |     INDEX RANGE SCAN                    | G_COMMFIN_REFDOSS_IDX   |      8 |     91 |   5914 |00:00:00.01 |      69 |      2 |
|*  8 |    TABLE ACCESS BY INDEX ROWID          | G_COMMFIN               |   5914 |      3 |   4556 |00:00:00.05 |     518 |     11 |
--------------------------------------------------------------------------------------------------------------------------------------

Predicate Information (identified by operation id):
---------------------------------------------------
   5 - filter("ABREV1"='FIU')
   6 - access("TYPE"='COMMFIN')
   7 - access("REFDOSS"=:B5 AND "TYPE"="ABREV" AND "FG_INVOICED" IS NULL)
   8 - filter(("NUMFACT" IS NULL AND "NUMFACT_DB" IS NULL))
*/
/********************************New Metrics***************************************/

/********************************Index statistics**********************************/

/********************************Other SQLs****************************************/          
/*

*/ 
/********************************Other SQLs****************************************/              
