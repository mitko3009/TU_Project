/********************************************************************************
*********       E-mail subject: TSTDEV-2147
*********             Instance: PREPROD
*********          Description: 
Problem:
The SQL with id fvscvp2bk3qp5 was slow on PREPROD.

Analysis:
Bad performance because of inappropriate execution plan.

Suggestion:
Please change the ds_ex_CLDB_acc_s variable as shown in the New SQL section below.

*********               SQL_ID: fvscvp2bk3qp5
*********      Program/Package: msgq_pilote
*********              Request: Dimitare Ivanov
*********               Author: Dimitar Dimitrov
********* Received e-mail date: 25/08/2023
*********      Resolution date: 25/08/2023
*********  Trace old file here: \\epox\specifs\performance\tmp\
*********  Trace new file here:
***********************************************************************************/

/********************************OLD SQL*******************************************/
select count(*)
  from g_dossier d
 where d.categdoss = 'COMPTE'
   and d.reffactor = ( select reffactor 
                         from g_dossier 
                        where refdoss = :refdos )
   and d.refdoss <> :refdos
   and exists ( select 1
                  from t_intervenants
                 where refdoss = d.refdoss
                   and reftype = 'DB'
                   and refindividu = ( select refindividu
                                         from t_intervenants
                                        where refdoss = :refdos
                                          and reftype = 'DB' ) )
   and exists ( select 1
                  from t_intervenants
                 where refdoss = d.refdoss
                   and reftype = 'CL'
                   and refindividu = ( select refindividu
                                         from t_intervenants
                                        where refdoss = :refdos
                                          and reftype = 'CL' ) )
   and exists ( select 1
                  from g_dossier ctr, 
                       g_piece t
                 where ctr.refdoss = ( select reflot
                                         from g_dossier
                                        where refdoss = ( select reflot 
                                                            from g_dossier 
                                                           where refdoss = d.refdoss ) )
                   and ctr.refdoss = t.refdoss
                   and ctr.pieceinit = t.typpiece
                   and nvl(t.st09, 'x') = 'S' );
/********************************OLD SQL*******************************************/
/********************************OLD Metrics***************************************/
/*
Plan hash value: 1947709132
-------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                 | Name                   | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers |
-------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                          |                        |      1 |        |    49 (100)|      1 |00:00:00.26 |     169K|
|   1 |  SORT AGGREGATE                           |                        |      1 |      1 |            |      1 |00:00:00.26 |     169K|
|   2 |   NESTED LOOPS SEMI                       |                        |      1 |      1 |    43   (0)|     32 |00:00:00.26 |     169K|
|   3 |    NESTED LOOPS                           |                        |      1 |      1 |    37   (0)|   9424 |00:00:00.25 |     169K|
|   4 |     NESTED LOOPS                          |                        |      1 |     14 |     9   (0)|   9424 |00:00:00.01 |      90 |
|   5 |      TABLE ACCESS BY INDEX ROWID          | G_DOSSIER              |      1 |      1 |     3   (0)|      1 |00:00:00.01 |       6 |
|*  6 |       INDEX UNIQUE SCAN                   | DOS_REFDOSS            |      1 |      1 |     2   (0)|      1 |00:00:00.01 |       3 |
|   7 |      VIEW                                 | VW_SQ_2                |      1 |     14 |     6   (0)|   9424 |00:00:00.01 |      84 |
|   8 |       SORT UNIQUE                         |                        |      1 |     14 |            |   9424 |00:00:00.01 |      84 |
|*  9 |        INDEX RANGE SCAN                   | INT_INDIV              |      1 |     14 |     3   (0)|   9424 |00:00:00.01 |      84 |
|* 10 |         INDEX RANGE SCAN                  | INT_REFDOSS            |      1 |      1 |     3   (0)|      1 |00:00:00.01 |       3 |
|* 11 |     TABLE ACCESS BY INDEX ROWID           | G_DOSSIER              |   9424 |      1 |     2   (0)|   9424 |00:00:00.24 |     169K|
|* 12 |      INDEX UNIQUE SCAN                    | DOS_REFDOSS            |   9424 |      1 |     1   (0)|   9424 |00:00:00.16 |     141K|
|  13 |       NESTED LOOPS SEMI                   |                        |   9424 |      1 |     6   (0)|   9424 |00:00:00.13 |     122K|
|  14 |        TABLE ACCESS BY INDEX ROWID        | G_DOSSIER              |   9424 |      1 |     3   (0)|   9424 |00:00:00.08 |   75579 |
|* 15 |         INDEX UNIQUE SCAN                 | DOS_REFDOSS            |   9424 |      1 |     2   (0)|   9424 |00:00:00.07 |   66155 |
|* 16 |          INDEX RANGE SCAN                 | DOS_REFDOSS_REFLOT_IDX |   9424 |      1 |     3   (0)|   9424 |00:00:00.05 |   37883 |
|* 17 |           INDEX RANGE SCAN                | DOS_REFDOSS_REFLOT_IDX |   9424 |      1 |     3   (0)|   9424 |00:00:00.03 |   18976 |
|* 18 |        TABLE ACCESS BY INDEX ROWID BATCHED| G_PIECE                |   9424 |      1 |     3   (0)|   9424 |00:00:00.04 |   47121 |
|* 19 |         INDEX RANGE SCAN                  | PIE_REFDOSS            |   9424 |      1 |     2   (0)|   9424 |00:00:00.02 |   28272 |
|  20 |    VIEW PUSHED PREDICATE                  | VW_SQ_3                |   9424 |      1 |     6   (0)|     32 |00:00:00.01 |     188 |
|* 21 |     INDEX RANGE SCAN                      | INT_INDIV              |   9424 |      1 |     3   (0)|     32 |00:00:00.01 |     188 |
|* 22 |      INDEX RANGE SCAN                     | INT_REFDOSS            |      1 |      1 |     3   (0)|      1 |00:00:00.01 |       3 |
-------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   6 - access("REFDOSS"=:REFDOS)
   9 - access("REFINDIVIDU"= AND "REFTYPE"='DB')
       filter("REFDOSS"<>:REFDOS)
  10 - access("REFDOSS"=:REFDOS AND "REFTYPE"='DB')
  11 - filter(("D"."CATEGDOSS"='COMPTE' AND "D"."REFFACTOR"="REFFACTOR"))
  12 - access("ITEM_1"="D"."REFDOSS")
       filter(("D"."REFDOSS"<>:REFDOS AND  IS NOT NULL))
  15 - access("CTR"."REFDOSS"=)
  16 - access("REFDOSS"=)
  17 - access("REFDOSS"=:B1)
  18 - filter(NVL("T"."ST09",'x')='S')
  19 - access("CTR"."REFDOSS"="T"."REFDOSS" AND "CTR"."PIECEINIT"="T"."TYPPIECE")
  21 - access("REFINDIVIDU"= AND "REFTYPE"='CL' AND "REFDOSS"="D"."REFDOSS")
  22 - access("REFDOSS"=:REFDOS AND "REFTYPE"='CL')
*/
/********************************OLD Metrics***************************************/

/********************************New SQL*******************************************/
select count(*)
  from g_dossier d,
       ( select db1.refdoss
           from t_intervenants db2,
                t_intervenants db1
          where db2.refdoss = :refdos
            and db2.reftype = 'DB'
            and db2.refindividu = db1.refindividu
            and db1.reftype = 'DB'
         intersect
         select cl1.refdoss
           from t_intervenants cl2,
                t_intervenants cl1
          where cl2.refdoss = :refdos
            and cl2.reftype = 'CL'
            and cl2.refindividu = cl1.refindividu
            and cl1.reftype = 'CL' ) ti
 where ti.refdoss <> :refdos
   and ti.refdoss = d.refdoss
   and d.categdoss = 'COMPTE'
   and d.reffactor = ( select reffactor 
                         from g_dossier 
                        where refdoss = :refdos )
   and exists ( select 1
                  from g_dossier ctr, 
                       g_piece t,
                       g_dossier dcm,
                       g_dossier cmp
                 where ctr.refdoss = dcm.reflot
                   and dcm.refdoss = cmp.reflot
                   and cmp.refdoss = d.refdoss
                   and ctr.refdoss = t.refdoss
                   and ctr.pieceinit = t.typpiece
                   and nvl(t.st09, 'x') = 'S' ); 
/********************************New SQL*******************************************/
/********************************New Metrics***************************************/
/*
Plan hash value: 3823556283
------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                          | Name                   | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers |
------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                   |                        |      1 |        |  1477 (100)|      1 |00:00:00.12 |     577 |
|   1 |  SORT AGGREGATE                    |                        |      1 |      1 |            |      1 |00:00:00.12 |     577 |
|   2 |   NESTED LOOPS                     |                        |      1 |      5 |   986   (1)|     32 |00:00:00.12 |     577 |
|   3 |    NESTED LOOPS                    |                        |      1 |    487 |   986   (1)|     32 |00:00:00.12 |     475 |
|   4 |     VIEW                           |                        |      1 |    487 |    12  (17)|     32 |00:00:00.12 |      91 |
|   5 |      INTERSECTION                  |                        |      1 |        |            |     32 |00:00:00.12 |      91 |
|   6 |       SORT UNIQUE                  |                        |      1 |    487 |            |   9424 |00:00:00.12 |      84 |
|   7 |        NESTED LOOPS                |                        |      1 |    487 |     5   (0)|   9424 |00:00:00.01 |      84 |
|*  8 |         INDEX RANGE SCAN           | INT_REFDOSS            |      1 |      1 |     3   (0)|      1 |00:00:00.01 |       3 |
|*  9 |         INDEX RANGE SCAN           | INT_INDIV              |      1 |    487 |     2   (0)|   9424 |00:00:00.01 |      81 |
|  10 |       SORT UNIQUE                  |                        |      1 |    487 |            |    163 |00:00:00.01 |       7 |
|  11 |        NESTED LOOPS                |                        |      1 |    487 |     5   (0)|    163 |00:00:00.01 |       7 |
|* 12 |         INDEX RANGE SCAN           | INT_REFDOSS            |      1 |      1 |     3   (0)|      1 |00:00:00.01 |       3 |
|* 13 |         INDEX RANGE SCAN           | INT_INDIV              |      1 |    487 |     2   (0)|    163 |00:00:00.01 |       4 |
|* 14 |     INDEX UNIQUE SCAN              | DOS_REFDOSS            |     32 |      1 |     1   (0)|     32 |00:00:00.01 |     384 |
|  15 |      NESTED LOOPS                  |                        |     32 |      1 |    10   (0)|     32 |00:00:00.01 |     318 |
|  16 |       NESTED LOOPS                 |                        |     32 |      1 |    10   (0)|     32 |00:00:00.01 |     254 |
|  17 |        NESTED LOOPS                |                        |     32 |      1 |     7   (0)|     32 |00:00:00.01 |     212 |
|  18 |         NESTED LOOPS               |                        |     32 |      1 |     5   (0)|     32 |00:00:00.01 |     138 |
|* 19 |          INDEX RANGE SCAN          | DOS_REFDOSS_REFLOT_IDX |     32 |      1 |     3   (0)|     32 |00:00:00.01 |      96 |
|* 20 |          INDEX RANGE SCAN          | DOS_REFDOSS_REFLOT_IDX |     32 |      1 |     2   (0)|     32 |00:00:00.01 |      42 |
|  21 |         TABLE ACCESS BY INDEX ROWID| G_DOSSIER              |     32 |      1 |     2   (0)|     32 |00:00:00.01 |      74 |
|* 22 |          INDEX UNIQUE SCAN         | DOS_REFDOSS            |     32 |      1 |     1   (0)|     32 |00:00:00.01 |      42 |
|* 23 |        INDEX RANGE SCAN            | PIE_REFDOSS            |     32 |      1 |     2   (0)|     32 |00:00:00.01 |      42 |
|* 24 |       TABLE ACCESS BY INDEX ROWID  | G_PIECE                |     32 |      1 |     3   (0)|     32 |00:00:00.01 |      64 |
|* 25 |    TABLE ACCESS BY INDEX ROWID     | G_DOSSIER              |     32 |      1 |     2   (0)|     32 |00:00:00.01 |     102 |
|  26 |     TABLE ACCESS BY INDEX ROWID    | G_DOSSIER              |      1 |      1 |     3   (0)|      1 |00:00:00.01 |       6 |
|* 27 |      INDEX UNIQUE SCAN             | DOS_REFDOSS            |      1 |      1 |     2   (0)|      1 |00:00:00.01 |       3 |
------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   8 - access("DB2"."REFDOSS"=:REFDOS AND "DB2"."REFTYPE"='DB')
   9 - access("DB2"."REFINDIVIDU"="DB1"."REFINDIVIDU" AND "DB1"."REFTYPE"='DB')
       filter("DB1"."REFDOSS"<>:REFDOS)
  12 - access("CL2"."REFDOSS"=:REFDOS AND "CL2"."REFTYPE"='CL')
  13 - access("CL2"."REFINDIVIDU"="CL1"."REFINDIVIDU" AND "CL1"."REFTYPE"='CL')
       filter("CL1"."REFDOSS"<>:REFDOS)
  14 - access("TI"."REFDOSS"="D"."REFDOSS")
       filter(("D"."REFDOSS"<>:REFDOS AND  IS NOT NULL))
  19 - access("CMP"."REFDOSS"=:B1)
  20 - access("DCM"."REFDOSS"="CMP"."REFLOT")
  22 - access("CTR"."REFDOSS"="DCM"."REFLOT")
  23 - access("CTR"."REFDOSS"="T"."REFDOSS" AND "CTR"."PIECEINIT"="T"."TYPPIECE")
  24 - filter(NVL("T"."ST09",'x')='S')
  25 - filter(("D"."CATEGDOSS"='COMPTE' AND "D"."REFFACTOR"=))
  27 - access("REFDOSS"=:REFDOS)
*/
/********************************New Metrics***************************************/

/********************************Index statistics**********************************/

/********************************Other SQLs****************************************/          
/*

*/ 
/********************************Other SQLs****************************************/              
