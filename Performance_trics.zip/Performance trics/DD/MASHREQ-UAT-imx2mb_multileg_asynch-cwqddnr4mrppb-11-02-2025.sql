/********************************************************************************
*********       E-mail subject: IMBWEB-8227
*********             Instance: UAT
*********          Description: 
Problem:
On UAT, the batch AMORT_OPCODE processed 948 records in 31 minutes.

Analysis:
We checked the work of the imx2mb_multileg_asynch on UAT for the period between 23:00 and 23:50 on 15/01/2025. As you can see below, the TOP SQL for this module in this period was cwqddnr4mrppb, 
which was responsible for 98% of the time.  This query is made of two UNIONs - in the first UNION we are selecting from table nam_ecr_compta for given batch_id and creat_sess_id. In the second 
UNION it is the same, but the select is from table nam_ecr_compta_bak for given batch_id and creat_sess_id. The problem is that there is no appropriate index on table nam_ecr_compta_bak and Oracle 
is making FULL SCAN on every execution. We need from index on columns batch_id, creat_sess_id on table nam_ecr_compta_bak to avoid the FULL SCAN.

Suggestion:
Please check and advise is it possible to create index on (batch_id, creat_sess_id) on table nam_ecr_compta_bak.

*********               SQL_ID: cwqddnr4mrppb
*********      Program/Package: 
*********              Request: Thinh Ngoc Van 
*********               Author: Dimitar Dimitrov
********* Received e-mail date: 16/01/2025
*********      Resolution date: 10/02/2025
*********  Trace old file here: \\epox\specifs\performance\tmp\
*********  Trace new file here:
***********************************************************************************/

/********************************OLD SQL*******************************************/

VAR B1 VARCHAR2(32);
EXEC :B1 := 'DMZL';
VAR B2 VARCHAR2(32);
EXEC :B2 := 'DMZL';
          
SELECT DISTINCT (c.refdoss) refdoss
  FROM nam_ecr_compta nec, 
       g_dossier c
 WHERE nec.batch_id = :B1
   AND nec.creat_sess_id = :B2
   AND nec.extref4 = c.ancrefdoss
UNION
SELECT DISTINCT (c.refdoss) refdoss
  FROM nam_ecr_compta_bak nec, 
       g_dossier c
 WHERE nec.batch_id = :B1
   AND nec.creat_sess_id = :B2
   AND nec.extref4 = c.ancrefdoss;
/********************************OLD SQL*******************************************/
/********************************OLD Metrics***************************************/
/*
INSTANCE_NUMBER SQL_ID            ELAPSED MAX_WAIT_ON     PC_OF  WAIT_TIME           GETS      READS       ROWS  ELAP/EXEC       GETS/EXEC READS/EXEC   ROWS/EXEC       EXEC PLAN_HASH_VALUE  
--------------- ------------- ----------- --------------- ----- ---------- --------------- ---------- ---------- ---------- --------------- ---------- ---------- ---------- ---------------       
              1 cwqddnr4mrppb        1745 IO              90%   1363.08247        87165545   87138912        948       1.84           91947   91918.68          1        948       176813159            
    
                                          
MODULE                           PROGRAM                                            CLIENT_ID       SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC                                                                                                                                  
-------------------------------- -------------------------------------------------- --------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------                                                                                                                                
imx2mb_multileg_asynch           soa_integration                                                                                                                        2025/01/15 23:15:04  2025/01/15 23:46:25         173                  944 +000000000 00:31:20.652 100%                                            
 
 
MODULE                           PROGRAM                                            CLIENT_ID       SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC                                                                                                                                  
-------------------------------- -------------------------------------------------- --------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------                                                                                                                                
imx2mb_multileg_asynch           soa_integration                                                    cwqddnr4mrppb  176813159          7      18785 direct path read     2025/01/15 23:29:45  2025/01/15 23:29:45           1                    1 +000000000 00:00:00.000 1%                                                                                                                                    
imx2mb_multileg_asynch           soa_integration                                                    cwqddnr4mrppb  176813159        932      40357 direct path read     2025/01/15 23:21:14  2025/01/15 23:21:14           1                    1 +000000000 00:00:00.000 1%                                                                                                                                    
imx2mb_multileg_asynch           soa_integration                                                    cwqddnr4mrppb  176813159        932        376 ON CPU               2025/01/15 23:23:55  2025/01/15 23:23:55           1                    1 +000000000 00:00:00.000 1%                                                                                                                                    
imx2mb_multileg_asynch           soa_integration                                                    cwqddnr4mrppb  176813159        932       1402 direct path read     2025/01/15 23:43:35  2025/01/15 23:43:35           1                    1 +000000000 00:00:00.000 1%                                                                                                                                    
imx2mb_multileg_asynch           soa_integration                                                    cwqddnr4mrppb  176813159        932       2108 ON CPU               2025/01/15 23:24:25  2025/01/15 23:24:25           1                    1 +000000000 00:00:00.000 1%                                                                                                                                    
imx2mb_multileg_asynch           soa_integration                                                    cwqddnr4mrppb  176813159        932       2565 direct path read     2025/01/15 23:31:45  2025/01/15 23:31:45           1                    1 +000000000 00:00:00.000 1%                                                                                                                                    
imx2mb_multileg_asynch           soa_integration                                                    cwqddnr4mrppb  176813159        932       2884 direct path read     2025/01/15 23:18:04  2025/01/15 23:18:04           1                    1 +000000000 00:00:00.000 1%                                                                                                                                    
imx2mb_multileg_asynch           soa_integration                                                    cwqddnr4mrppb  176813159        932       2984 direct path read     2025/01/15 23:42:35  2025/01/15 23:42:35           1                    1 +000000000 00:00:00.000 1%                                                                                                                                    
imx2mb_multileg_asynch           soa_integration                                                    cwqddnr4mrppb  176813159        932       3390 direct path read     2025/01/15 23:17:34  2025/01/15 23:17:34           1                    1 +000000000 00:00:00.000 1%                                                                                                                                    
imx2mb_multileg_asynch           soa_integration                                                    cwqddnr4mrppb  176813159        932       5948 direct path read     2025/01/15 23:19:04  2025/01/15 23:19:04           1                    1 +000000000 00:00:00.000 1%                                                                                                                                    
imx2mb_multileg_asynch           soa_integration                                                    cwqddnr4mrppb  176813159        932       7627 direct path read     2025/01/15 23:21:44  2025/01/15 23:21:44           1                    1 +000000000 00:00:00.000 1%                                                                                                                                    
imx2mb_multileg_asynch           soa_integration                                                    cwqddnr4mrppb  176813159        932       9979 ON CPU               2025/01/15 23:27:05  2025/01/15 23:27:05           1                    1 +000000000 00:00:00.000 1%                                                                                                                                    
imx2mb_multileg_asynch           soa_integration                                                    cwqddnr4mrppb  176813159        932      18900 ON CPU               2025/01/15 23:30:15  2025/01/15 23:30:15           1                    1 +000000000 00:00:00.000 1%                                                                                                                                    
imx2mb_multileg_asynch           soa_integration                                                    cwqddnr4mrppb  176813159        932      12837 ON CPU               2025/01/15 23:42:15  2025/01/15 23:42:15           1                    1 +000000000 00:00:00.000 1%                                                                                                                                    
imx2mb_multileg_asynch           soa_integration                                                    cwqddnr4mrppb  176813159        932      14068 direct path read     2025/01/15 23:39:35  2025/01/15 23:39:35           1                    1 +000000000 00:00:00.000 1%                                                                                                                                    
imx2mb_multileg_asynch           soa_integration                                                    cwqddnr4mrppb  176813159        932      14078 direct path read     2025/01/15 23:26:05  2025/01/15 23:26:05           1                    1 +000000000 00:00:00.000 1%                                                                                                                                    
imx2mb_multileg_asynch           soa_integration                                                    cwqddnr4mrppb  176813159        932      14226 direct path read     2025/01/15 23:19:44  2025/01/15 23:19:44           1                    1 +000000000 00:00:00.000 1%       
 
 
MODULE                           PROGRAM                                            CLIENT_ID       SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC                                                                                                                                  
-------------------------------- -------------------------------------------------- --------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------                                                                                                                                
imx2mb_multileg_asynch           soa_integration                                                    cwqddnr4mrppb  176813159                       direct path read     2025/01/15 23:15:04  2025/01/15 23:46:25         117                  944 +000000000 00:31:20.652 68%                                                                                                                                   
imx2mb_multileg_asynch           soa_integration                                                                                                   ON CPU               2025/01/15 23:15:44  2025/01/15 23:46:15          54                  919 +000000000 00:30:30.643 31%                                                                                                                                   
imx2mb_multileg_asynch           soa_integration                                                    cwqddnr4mrppb  176813159        932      38449 enq: KO - fast objec 2025/01/15 23:15:14  2025/01/15 23:15:14           1                    1 +000000000 00:00:00.000 1%                                                                                                                                    
imx2mb_multileg_asynch           soa_integration                                                    1gbrc944778pq  514666218        932      39443 db file sequential r 2025/01/15 23:43:15  2025/01/15 23:43:15           1                    1 +000000000 00:00:00.000 1%  

     
MODULE                           PROGRAM                                            CLIENT_ID       SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC                                                                                                                                  
-------------------------------- -------------------------------------------------- --------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------                                                                                                                                
imx2mb_multileg_asynch           soa_integration                                                    cwqddnr4mrppb  176813159                                            2025/01/15 23:15:04  2025/01/15 23:46:25         170                  944 +000000000 00:31:20.652 98%                                                                                                                                   
imx2mb_multileg_asynch           soa_integration                                                    a3fh2afaa4p67 2032274287        932            ON CPU               2025/01/15 23:32:45  2025/01/15 23:34:25           2                   54 +000000000 00:01:40.070 1%                                                                                                                                    
imx2mb_multileg_asynch           soa_integration                                                    1gbrc944778pq  514666218        932      39443 db file sequential r 2025/01/15 23:43:15  2025/01/15 23:43:15           1                    1 +000000000 00:00:00.000 1%                                             
  

SQL_ID        SQL_PLAN_HASH_VALUE SQL_PLAN_LINE_ID SQL_PLAN_OPERATION             SQL_PLAN_OPTIONS                   ACTIVE
------------- ------------------- ---------------- ------------------------------ ------------------------------ ----------
cwqddnr4mrppb           176813159               11 TABLE ACCESS                   FULL                                  170    


Plan hash value: 176813159
----------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                               | Name               | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  |
----------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                        |                    |      1 |        | 56079 (100)|      0 |00:00:20.32 |     251K|    251K|
|   1 |  SORT UNIQUE                            |                    |      1 |      2 | 56079   (2)|      0 |00:00:20.32 |     251K|    251K|
|   2 |   UNION-ALL                             |                    |      1 |        |            |      0 |00:00:20.32 |     251K|    251K|
|   3 |    NESTED LOOPS                         |                    |      1 |      1 |     2   (0)|      0 |00:00:00.02 |       3 |      2 |
|   4 |     NESTED LOOPS                        |                    |      1 |      2 |     2   (0)|      0 |00:00:00.02 |       3 |      2 |
|*  5 |      TABLE ACCESS BY INDEX ROWID BATCHED| NAM_ECR_COMPTA     |      1 |      1 |     1   (0)|      0 |00:00:00.02 |       3 |      2 |
|*  6 |       INDEX RANGE SCAN                  | NAM_ECR_BATCH_IDX  |      1 |      2 |     1   (0)|      0 |00:00:00.02 |       3 |      2 |
|*  7 |      INDEX RANGE SCAN                   | DOS_ANCREFDOSS     |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|   8 |     TABLE ACCESS BY INDEX ROWID         | G_DOSSIER          |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|   9 |    NESTED LOOPS                         |                    |      1 |      1 | 56077   (2)|      0 |00:00:20.30 |     251K|    251K|
|  10 |     NESTED LOOPS                        |                    |      1 |      2 | 56077   (2)|      0 |00:00:20.30 |     251K|    251K|
|* 11 |      TABLE ACCESS FULL                  | NAM_ECR_COMPTA_BAK |      1 |      1 | 56076   (2)|      0 |00:00:20.30 |     251K|    251K|
|* 12 |      INDEX RANGE SCAN                   | DOS_ANCREFDOSS     |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|  13 |     TABLE ACCESS BY INDEX ROWID         | G_DOSSIER          |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
----------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   5 - filter("NEC"."CREAT_SESS_ID"=:B2)
   6 - access("NEC"."BATCH_ID"=:B1)
   7 - access("NEC"."EXTREF4"="C"."ANCREFDOSS")
       filter("C"."ANCREFDOSS" IS NOT NULL)
  11 - filter(("NEC"."BATCH_ID"=:B1 AND "NEC"."CREAT_SESS_ID"=:B2))
  12 - access("NEC"."EXTREF4"="C"."ANCREFDOSS")
       filter("C"."ANCREFDOSS" IS NOT NULL)   
*/
/********************************OLD Metrics***************************************/

/********************************New SQL*******************************************/

-- No changes in the SQL text
/********************************New SQL*******************************************/
/********************************New Metrics***************************************/
/*
-- With index on batch_id, creat_sess_id

Plan hash value: 2786255983
----------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                               | Name               | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  |
----------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                        |                    |      1 |        |     4 (100)|      0 |00:00:00.01 |       6 |      1 |
|   1 |  SORT UNIQUE                            |                    |      1 |      2 |     4   (0)|      0 |00:00:00.01 |       6 |      1 |
|   2 |   UNION-ALL                             |                    |      1 |        |            |      0 |00:00:00.01 |       6 |      1 |
|   3 |    NESTED LOOPS                         |                    |      1 |      1 |     2   (0)|      0 |00:00:00.01 |       3 |      0 |
|   4 |     NESTED LOOPS                        |                    |      1 |      2 |     2   (0)|      0 |00:00:00.01 |       3 |      0 |
|*  5 |      TABLE ACCESS BY INDEX ROWID BATCHED| NAM_ECR_COMPTA     |      1 |      1 |     1   (0)|      0 |00:00:00.01 |       3 |      0 |
|*  6 |       INDEX RANGE SCAN                  | NAM_ECR_BATCH_IDX  |      1 |      2 |     1   (0)|      0 |00:00:00.01 |       3 |      0 |
|*  7 |      INDEX RANGE SCAN                   | DOS_ANCREFDOSS     |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|   8 |     TABLE ACCESS BY INDEX ROWID         | G_DOSSIER          |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|   9 |    NESTED LOOPS                         |                    |      1 |      1 |     2   (0)|      0 |00:00:00.01 |       3 |      1 |
|  10 |     NESTED LOOPS                        |                    |      1 |      2 |     2   (0)|      0 |00:00:00.01 |       3 |      1 |
|  11 |      TABLE ACCESS BY INDEX ROWID BATCHED| NAM_ECR_COMPTA_BAK |      1 |      1 |     1   (0)|      0 |00:00:00.01 |       3 |      1 |
|* 12 |       INDEX RANGE SCAN                  | TEST_DD_INDEX      |      1 |      1 |     1   (0)|      0 |00:00:00.01 |       3 |      1 |
|* 13 |      INDEX RANGE SCAN                   | DOS_ANCREFDOSS     |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|  14 |     TABLE ACCESS BY INDEX ROWID         | G_DOSSIER          |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
----------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   5 - filter("NEC"."CREAT_SESS_ID"=:B2)
   6 - access("NEC"."BATCH_ID"=:B1)
   7 - access("NEC"."EXTREF4"="C"."ANCREFDOSS")
       filter("C"."ANCREFDOSS" IS NOT NULL)
  12 - access("NEC"."BATCH_ID"=:B1 AND "NEC"."CREAT_SESS_ID"=:B2)
  13 - access("NEC"."EXTREF4"="C"."ANCREFDOSS")
       filter("C"."ANCREFDOSS" IS NOT NULL)  
*/
/********************************New Metrics***************************************/

/********************************Index statistics**********************************/

/********************************Other SQLs****************************************/          
/*

*/ 
/********************************Other SQLs****************************************/              
