/********************************************************************************
*********       E-mail subject: COFADEV-13452
*********             Instance: NUGAVAL
*********          Description: 
Problem:
Slowness in cfc_imx_pix_case on NUGAVAL.

Analysis:
After the analyze of module cfc_imx_pix_case on NUGAVAL, I found that the TOP SQL for the period between 23:00 on 10/06 and 04:00 on 11/06 is 5zc9kfvfta01b.
This SQL is responsible for 100% of the time of cfc_imx_pix_case. The problem in the query are the analytic functions in the select part. They were applied for a lot of rows, 
which needs time. We don't see the purpose from this functions in this SQL and we rewrite the query as we think it should be ( as it is shown in the New SQL section below ), where we moved the select from table 
g_telephone the max for the tel, fax and email in inline views and joined the inline views to the other part of the query. Could you please check and if it is OK, apply the suggested 
optimization from the New SQL section below.

Suggestion:
Please see the query in the New SQL section below and if it is OK, please change the query as it is shown in the New SQL section below.

*********               SQL_ID: 5zc9kfvfta01b
*********      Program/Package: 
*********              Request: Boris Arsov
*********               Author: Dimitar Dimitrov
********* Received e-mail date: 13/06/2024
*********      Resolution date: 13/06/2024
*********  Trace old file here: \\epox\specifs\performance\tmp\
*********  Trace new file here:
***********************************************************************************/

/********************************OLD SQL*******************************************/

VAR caseRef VARCHAR2(32);
EXEC :caseRef := '2206160010';

SELECT DISTINCT parties.id,
                CASE
                  WHEN parties.ca IS NOT NULL AND parties.id IN (3, 4) THEN
                   parties.refindividu
                  WHEN parties.ca IS NULL AND parties.id IN (3, 4) THEN
                   parties.sp
                  ELSE
                   parties.refindividu
                END,
                parties.ancrefdoss,
                i.tva,
                crs.refext,
                estab.refext,
                gcc.refext,
                i.nom,
                i.adr1,
                '',
                i.adr2,
                i.cp,
                i.ville,
                i.pays,
                pays.abrev16,
                MAX(tel.numtel) OVER(PARTITION BY tel.refindividu),
                pays.abrev16,
                MAX(fax.numtel) OVER(PARTITION BY fax.refindividu),
                MAX(email.numtel) OVER(PARTITION BY email.refindividu),
                contact.prenom || ' ' || contact.nom,
                crs1.refext
  FROM g_individu i,
       v_domaine pays,
       g_telephone tel,
       g_telephone fax,
       g_telephone email,
       t_individu crs,
       t_individu crs1,
       t_individu estab,
       t_individu gcc,
       (SELECT /*+ push_pred no_merge */
               MAX(st01) AS st01
          FROM g_piece
         WHERE refpiece = (SELECT MAX(refelem)
                             FROM t_elements
                            WHERE refdoss = :caseRef
                              AND libelle = 'POLICY CONTRACT'
                              AND typeelem = 'pr')) pol,
       (SELECT /*+ push_pred no_merge */
               t.refindividu,
               t.refdossext,
               t.reftype,
               CASE
                 WHEN d.ext_source = 'NCX' OR d.createur = 'cfc_ncx_imx_cases'
                 THEN 1
           WHEN d.categdoss = 'INSURED' THEN
            2
           ELSE
            0
         END AS ncx,
         DECODE(rec.gpiliblibre, NULL, '', '000', '', '/' || rec.gpiliblibre) AS claim,
         d.ancrefdoss,
         CASE
           WHEN t.reftype = 'BU' AND
                t.refindividu NOT IN ('INTBUPRT', 'INTBUESP') AND
                sp.refindividu IN ('INTBUPRT', 'INTBUESP') THEN
            0
           WHEN t.reftype = 'CL' AND
                (t.refindividu IN ('INTBUPRT', 'INTBUESP') OR
                sp.refindividu NOT IN ('INTBUPRT', 'INTBUESP')) THEN
            0
           WHEN t.reftype = 'DB' THEN
            2
           WHEN t.reftype = 'CA' THEN
            3
           WHEN t.reftype = 'LA' THEN
            4
           WHEN t.reftype = 'AV' THEN
            4
         END AS ID,
         ca.refindividu AS ca,
         sp.refindividu AS sp
          FROM t_intervenants t,
               g_dossier      d,
               g_piece        rec,
               t_intervenants ca,
               t_intervenants sp
         WHERE d.refdoss = :caseRef
           AND d.refdoss = rec.refdoss
           AND rec.typpiece = 'RECOUVREMENT'
           AND d.refdoss = t.refdoss
           AND ca.refdoss(+) = t.refdoss
           AND ca.reftype(+) = 'CL'
           AND sp.reftype(+) = 'SP'
           AND sp.refdoss(+) = t.refdoss
           AND t.reftype IN ('DB', 'BU', 'CL', 'CA', 'LA', 'AV')
        UNION
        SELECT /*+ push_pred no_merge */
               t.refindividu,
               t.refdossext,
               t.reftype,
         CASE
           WHEN d.ext_source = 'NCX' OR d.createur = 'cfc_ncx_imx_cases' THEN
            1
           WHEN d.categdoss = 'INSURED' THEN
            2
           ELSE
            0
         END AS ncx,
         DECODE(rec.gpiliblibre, NULL, '', '/' || rec.gpiliblibre) AS claim,
         d.ancrefdoss,
         1,
         ca.refindividu AS ca,
         sp.refindividu AS sp
          FROM t_intervenants t,
               g_dossier      d,
               g_piece        rec,
               t_intervenants ca,
               t_intervenants sp
         WHERE d.refdoss = :caseRef
           AND d.refdoss = rec.refdoss
           AND rec.typpiece = 'RECOUVREMENT'
           AND d.refdoss = t.refdoss
           AND ca.refdoss(+) = t.refdoss
           AND ca.reftype(+) = 'CL'
           AND sp.reftype(+) = 'SP'
           AND sp.refdoss(+) = t.refdoss
           AND ( ( d.categdoss = 'INSURED' AND t.reftype = 'TC')
               OR( d.categdoss = 'NOT INSURED' AND t.reftype = 'CRO') 
               OR( d.categdoss = 'NOT INSURED' AND t.reftype = 'CL' AND NOT EXISTS (SELECT 1
                                                                                      FROM t_intervenants
                                                                                     WHERE reftype = 'CRO'
                                                                                       AND refdoss = t.refdoss)))
        UNION
        SELECT t.refindividu,
               t.refdossext,
               t.reftype,
               CASE
                 WHEN d.ext_source = 'NCX' OR
                      d.createur = 'cfc_ncx_imx_cases' THEN
                  1
                 WHEN d.categdoss = 'INSURED' THEN
                  2
                 ELSE
                  0
               END AS ncx,
               DECODE(rec.gpiliblibre, NULL, '', '/' || rec.gpiliblibre) AS claim,
               d.ancrefdoss,
               3,
               ca.refindividu AS ca,
               t.refindividu AS sp
          FROM t_intervenants t,
               g_dossier d,
               g_piece rec, 
               t_intervenants ca
         WHERE d.refdoss = :caseRef
           AND d.refdoss = rec.refdoss
           AND rec.typpiece = 'RECOUVREMENT'
           AND d.refdoss = t.refdoss
           AND ca.refdoss(+) = t.refdoss
           AND ca.reftype(+) = 'CL'
           AND t.reftype = 'SP'
           AND NOT EXISTS (SELECT 1
                  FROM t_intervenants
                 WHERE reftype = 'CA'
                   AND refdoss = t.refdoss)) parties,
       (SELECT /*+ push_pred no_merge */
        DISTINCT cp.refindividu, pers.nom, pers.prenom
          FROM g_indivparam cp, g_individu pers
         WHERE pers.refindividu = cp.str2) contact,
       g_individu db
 WHERE contact.refindividu(+) = i.refindividu
   AND db.refindividu = (SELECT refindividu
                           FROM t_intervenants
                          WHERE refdoss = :caseRef
                            AND reftype = 'DB')
   AND tel.refindividu(+) = i.refindividu
   AND tel.typetel(+) IN ('DOM', 'BUR', 'GSM')
   AND fax.refindividu(+) = i.refindividu
   AND fax.typetel(+) = 'FAX'
   AND email.refindividu(+) = i.refindividu
   AND email.typetel(+) = 'EMAIL'
   AND crs.refindividu(+) = db.refindividu
   AND crs.societe(+) LIKE 'CRS%'
   AND crs1.refindividu(+) = parties.refindividu
   AND crs1.societe(+) LIKE 'CRS%'
   AND estab.refindividu(+) = i.refindividu
   AND estab.societe(+) = 'ESTAB_NUMBER'
   AND gcc.refindividu(+) = i.refindividu
   AND gcc.societe(+) = 'GCC'
   AND pays.type(+) = 'pays'
   AND pays.abrev(+) = i.pays
   AND i.refindividu = parties.refindividu
 ORDER BY parties.id DESC;
/********************************OLD SQL*******************************************/
/********************************OLD Metrics***************************************/
/*
MODULE                           SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
cfc_imx_pix_case                 5zc9kfvfta01b 2100518138        876      28492 direct path read tem 2024/06/10 23:31:09  2024/06/11 04:09:47        1431                   11 +000000000 04:38:38.018 23%
imx2advoware_add                 6dp9wtgas77nr 4066461546         20      36277 direct path read     2024/06/10 23:00:17  2024/06/11 04:09:47         948                  888 +000000000 05:09:29.739 15%
inv_dc_batch                                                                    ON CPU               2024/06/10 23:06:28  2024/06/11 00:35:12         500              4246559 +000000000 01:28:44.015 8%
imxbatch_XnetDcDashboard                                                        direct path read     2024/06/10 23:04:48  2024/06/11 00:38:02         452                    1 +000000000 01:33:14.457 7%
                                                        0                       log file parallel wr 2024/06/10 23:00:58  2024/06/11 04:05:17         286                      +000000000 05:04:19.337 5%
imxbatch_bkg_nightse                                                            read by other sessio 2024/06/10 23:04:38  2024/06/11 00:38:32         222                    1 +000000000 01:33:54.520 4%
SQL*Plus                                       2447020438                       read by other sessio 2024/06/10 23:00:37  2024/06/11 04:01:17         210                    1 +000000000 05:00:39.075 3%
imxbatch_DcInvParamInherit                       53526185                       read by other sessio 2024/06/10 23:04:38  2024/06/11 00:39:32         196                    1 +000000000 01:34:54.587 3%
cfc_imx_pix_case                 5zc9kfvfta01b 2100518138        876      28492 direct path write te 2024/06/10 23:26:19  2024/06/11 04:08:57         168                   11 +000000000 04:42:38.161 3%
imxbatch_DcInvParamInherit                                                      db file sequential r 2024/06/10 23:04:38  2024/06/11 00:39:32         146               240459 +000000000 01:34:54.587 2%
cfc_imx_pix_case                 5zc9kfvfta01b 2100518138        876      28492 ON CPU               2024/06/10 23:26:09  2024/06/11 04:09:57         101                   11 +000000000 04:43:48.238 2%
msgq_pilote                                                                     db file sequential r 2024/06/10 23:06:48  2024/06/11 01:30:06         100               106788 +000000000 02:23:17.960 2%
MMON_SLAVE                                                                      db file sequential r 2024/06/10 23:00:58  2024/06/11 04:05:17         100                66784 +000000000 05:04:19.337 2%


MODULE                           SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
cfc_imx_pix_case                 5zc9kfvfta01b 2100518138        876      28492 direct path read tem 2024/06/10 23:31:09  2024/06/11 04:09:47        1431                   11 +000000000 04:38:38.018 84%
cfc_imx_pix_case                 5zc9kfvfta01b 2100518138        876      28492 direct path write te 2024/06/10 23:26:19  2024/06/11 04:08:57         168                   11 +000000000 04:42:38.161 10%
cfc_imx_pix_case                 5zc9kfvfta01b 2100518138        876      28492 ON CPU               2024/06/10 23:26:09  2024/06/11 04:09:57         101                   11 +000000000 04:43:48.238 6%
cfc_imx_pix_case                                                 876      28492 db file sequential r 2024/06/10 23:25:49  2024/06/11 03:43:55           3                   10 +000000000 04:18:06.380 0%
cfc_imx_pix_case                 g9wyb3996y296 3518559935        876      28492 db file parallel rea 2024/06/10 23:25:59  2024/06/10 23:25:59           1                    1 +000000000 00:00:00.000 0%




MODULE                           SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
cfc_imx_pix_case                 5zc9kfvfta01b 2100518138        876      28492                      2024/06/10 23:26:09  2024/06/11 04:09:57        1701                   11 +000000000 04:43:48.238 100%
cfc_imx_pix_case                 g9wyb3996y296 3518559935        876      28492                      2024/06/10 23:25:49  2024/06/10 23:25:59           2                    1 +000000000 00:00:10.005 0%
cfc_imx_pix_case                 brscnr93d5z5j 1831667577        876      28492 db file sequential r 2024/06/11 01:15:05  2024/06/11 01:15:05           1                    1 +000000000 00:00:00.000 0%


INSTANCE_NUMBER SQL_ID            ELAPSED MAX_WAIT_ON     PC_OF  WAIT_TIME            GETS      READS       ROWS  ELAP/EXEC       GETS/EXEC READS/EXEC  ROWS/EXEC       EXEC PLAN_HASH_VALUE
--------------- ------------- ----------- --------------- ----- ---------- --------------- ---------- ---------- ---------- --------------- ---------- ---------- ---------- ---------------
              1 5zc9kfvfta01b       16485 IO              94%   16540.5141        73584785   10020811         78    1177.48         5256056  715772.21       5.57         14      2100518138



SQL_ID        SQL_PLAN_HASH_VALUE SQL_PLAN_LINE_ID SQL_PLAN_OPERATION             SQL_PLAN_OPTIONS                   ACTIVE
------------- ------------------- ---------------- ------------------------------ ------------------------------ ----------
5zc9kfvfta01b          2100518138                5 WINDOW                         SORT                                  701
5zc9kfvfta01b          2100518138                4 WINDOW                         SORT                                  666
5zc9kfvfta01b          2100518138                3 WINDOW                         SORT                                  324
5zc9kfvfta01b          2100518138               95 NESTED LOOPS                                                           2
5zc9kfvfta01b          2100518138               93 SORT                           UNIQUE                                  2
5zc9kfvfta01b          2100518138               96 TABLE ACCESS                   BY INDEX ROWID BATCHED                  2
5zc9kfvfta01b          2100518138                2 HASH                           UNIQUE                                  1
5zc9kfvfta01b          2100518138               89 INDEX                          RANGE SCAN                              1
5zc9kfvfta01b          2100518138               98 INDEX                          UNIQUE SCAN                             1
5zc9kfvfta01b          2100518138               99 TABLE ACCESS                   BY INDEX ROWID                          1


Plan hash value: 2100518138
-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                                   | Name                   | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  | Writes |
-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                                            |                        |      1 |        |    50 (100)|      0 |00:00:00.02 |       3 |      2 |      0 |
|   1 |  SORT ORDER BY                                              |                        |      1 |     27 |    50  (24)|      0 |00:00:00.02 |       3 |      2 |      0 |
|   2 |   HASH UNIQUE                                               |                        |      1 |     27 |    49  (23)|      0 |00:00:00.02 |       3 |      2 |      0 |
|   3 |    WINDOW SORT                                              |                        |      1 |     27 |    50  (24)|      0 |00:00:00.02 |       3 |      2 |      0 |
|   4 |     WINDOW SORT                                             |                        |      1 |     27 |    50  (24)|      0 |00:00:00.02 |       3 |      2 |      0 |
|   5 |      WINDOW SORT                                            |                        |      1 |     27 |    50  (24)|      5 |00:03:53.78 |      18M|    376K|    751K|
|   6 |       NESTED LOOPS OUTER                                    |                        |      1 |     27 |    44  (16)|   9158K|00:00:49.22 |      18M|    746 |      0 |
|   7 |        NESTED LOOPS OUTER                                   |                        |      1 |      5 |    29   (7)|   2289K|00:00:07.29 |   67853 |     45 |      0 |
|   8 |         NESTED LOOPS OUTER                                  |                        |      1 |      5 |    28   (8)|   2289K|00:00:02.23 |   67836 |     44 |      0 |
|   9 |          NESTED LOOPS OUTER                                 |                        |      1 |      5 |    27   (8)|   2396 |00:00:00.11 |     165 |     18 |      0 |
|  10 |           NESTED LOOPS OUTER                                |                        |      1 |      5 |    26   (8)|   2394 |00:00:00.10 |     144 |     18 |      0 |
|  11 |            NESTED LOOPS OUTER                               |                        |      1 |      5 |    25   (8)|      5 |00:00:00.06 |     114 |     13 |      0 |
|  12 |             NESTED LOOPS OUTER                              |                        |      1 |      5 |    24   (9)|      5 |00:00:00.06 |     100 |     13 |      0 |
|  13 |              NESTED LOOPS                                   |                        |      1 |      5 |    23   (9)|      5 |00:00:00.06 |      86 |     13 |      0 |
|  14 |               NESTED LOOPS OUTER                            |                        |      1 |      5 |    22  (10)|      5 |00:00:00.06 |      70 |      9 |      0 |
|  15 |                MERGE JOIN CARTESIAN                         |                        |      1 |      5 |    21  (10)|      5 |00:00:00.05 |      56 |      7 |      0 |
|  16 |                 NESTED LOOPS OUTER                          |                        |      1 |      1 |     4   (0)|      1 |00:00:00.02 |       9 |      2 |      0 |
|  17 |                  NESTED LOOPS                               |                        |      1 |      1 |     3   (0)|      1 |00:00:00.02 |       7 |      2 |      0 |
|  18 |                   VIEW                                      |                        |      1 |      1 |     2   (0)|      1 |00:00:00.02 |       3 |      2 |      0 |
|  19 |                    SORT AGGREGATE                           |                        |      1 |      1 |            |      1 |00:00:00.02 |       3 |      2 |      0 |
|* 20 |                     TABLE ACCESS BY INDEX ROWID BATCHED     | G_PIECE                |      1 |      1 |     1   (0)|      0 |00:00:00.02 |       3 |      2 |      0 |
|* 21 |                      INDEX RANGE SCAN                       | PIE_REFPIECE           |      1 |      1 |     1   (0)|      0 |00:00:00.02 |       3 |      2 |      0 |
|  22 |                       SORT AGGREGATE                        |                        |      1 |      1 |            |      1 |00:00:00.02 |       3 |      2 |      0 |
|  23 |                        TABLE ACCESS BY INDEX ROWID BATCHED  | T_ELEMENTS             |      1 |      1 |     1   (0)|      0 |00:00:00.02 |       3 |      2 |      0 |
|* 24 |                         INDEX RANGE SCAN                    | ELE_DOSS_TYP_ASSOC_LIB |      1 |      1 |     1   (0)|      0 |00:00:00.02 |       3 |      2 |      0 |
|* 25 |                   INDEX UNIQUE SCAN                         | IND_REFINDIV           |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       4 |      0 |      0 |
|* 26 |                    INDEX RANGE SCAN                         | INT_REFDOSS            |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       2 |      0 |      0 |
|* 27 |                  TABLE ACCESS BY INDEX ROWID BATCHED        | T_INDIVIDU             |      1 |      1 |     1   (0)|      0 |00:00:00.01 |       2 |      0 |      0 |
|* 28 |                   INDEX RANGE SCAN                          | IX_T_INDIVIDU          |      1 |      6 |     1   (0)|      0 |00:00:00.01 |       2 |      0 |      0 |
|  29 |                 BUFFER SORT                                 |                        |      1 |      5 |    20  (10)|      5 |00:00:00.04 |      47 |      5 |      0 |
|  30 |                  VIEW                                       |                        |      1 |      5 |    17  (12)|      5 |00:00:00.04 |      47 |      5 |      0 |
|  31 |                   SORT UNIQUE                               |                        |      1 |      5 |    17  (12)|      5 |00:00:00.04 |      47 |      5 |      0 |
|  32 |                    UNION-ALL                                |                        |      1 |        |            |      5 |00:00:00.04 |      47 |      5 |      0 |
|  33 |                     MERGE JOIN OUTER                        |                        |      1 |      3 |     5   (0)|      4 |00:00:00.03 |      17 |      4 |      0 |
|  34 |                      MERGE JOIN OUTER                       |                        |      1 |      3 |     4   (0)|      4 |00:00:00.03 |      15 |      4 |      0 |
|  35 |                       MERGE JOIN CARTESIAN                  |                        |      1 |      3 |     3   (0)|      4 |00:00:00.03 |      13 |      4 |      0 |
|  36 |                        NESTED LOOPS                         |                        |      1 |      1 |     2   (0)|      1 |00:00:00.02 |       8 |      2 |      0 |
|  37 |                         TABLE ACCESS BY INDEX ROWID         | G_DOSSIER              |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       4 |      1 |      0 |
|* 38 |                          INDEX UNIQUE SCAN                  | DOS_REFDOSS            |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       2 |      0 |      0 |
|  39 |                         TABLE ACCESS BY INDEX ROWID BATCHED | G_PIECE                |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       4 |      1 |      0 |
|* 40 |                          INDEX RANGE SCAN                   | PIE_REFDOSS            |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |      1 |      0 |
|  41 |                        BUFFER SORT                          |                        |      1 |      6 |     2   (0)|      4 |00:00:00.01 |       5 |      2 |      0 |
|  42 |                         TABLE ACCESS BY INDEX ROWID BATCHED | T_INTERVENANTS         |      1 |      6 |     1   (0)|      4 |00:00:00.01 |       5 |      2 |      0 |
|* 43 |                          INDEX RANGE SCAN                   | INT_REFDOSS            |      1 |      1 |     1   (0)|      4 |00:00:00.01 |       2 |      0 |      0 |
|  44 |                       BUFFER SORT                           |                        |      4 |      1 |     3   (0)|      4 |00:00:00.01 |       2 |      0 |      0 |
|* 45 |                        INDEX RANGE SCAN                     | INT_REFDOSS            |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       2 |      0 |      0 |
|  46 |                      BUFFER SORT                            |                        |      4 |      1 |     4   (0)|      4 |00:00:00.01 |       2 |      0 |      0 |
|* 47 |                       INDEX RANGE SCAN                      | INT_REFDOSS            |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       2 |      0 |      0 |
|* 48 |                     FILTER                                  |                        |      1 |        |            |      1 |00:00:00.01 |      19 |      1 |      0 |
|  49 |                      MERGE JOIN OUTER                       |                        |      1 |     58 |     5   (0)|      1 |00:00:00.01 |      17 |      1 |      0 |
|  50 |                       MERGE JOIN OUTER                      |                        |      1 |     56 |     4   (0)|      1 |00:00:00.01 |      15 |      1 |      0 |
|  51 |                        MERGE JOIN CARTESIAN                 |                        |      1 |     54 |     3   (0)|      1 |00:00:00.01 |      13 |      1 |      0 |
|  52 |                         NESTED LOOPS                        |                        |      1 |      1 |     2   (0)|      1 |00:00:00.01 |       8 |      0 |      0 |
|* 53 |                          TABLE ACCESS BY INDEX ROWID        | G_DOSSIER              |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       4 |      0 |      0 |
|* 54 |                           INDEX UNIQUE SCAN                 | DOS_REFDOSS            |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       2 |      0 |      0 |
|  55 |                          TABLE ACCESS BY INDEX ROWID BATCHED| G_PIECE                |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       4 |      0 |      0 |
|* 56 |                           INDEX RANGE SCAN                  | PIE_REFDOSS            |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |      0 |      0 |
|  57 |                         BUFFER SORT                         |                        |      1 |      3 |     2   (0)|      1 |00:00:00.01 |       5 |      1 |      0 |
|* 58 |                          TABLE ACCESS BY INDEX ROWID BATCHED| T_INTERVENANTS         |      1 |      3 |     1   (0)|      1 |00:00:00.01 |       5 |      1 |      0 |
|* 59 |                           INDEX RANGE SCAN                  | INT_DOS_INDIV          |      1 |      4 |     1   (0)|      5 |00:00:00.01 |       2 |      1 |      0 |
|  60 |                        BUFFER SORT                          |                        |      1 |      1 |     3   (0)|      1 |00:00:00.01 |       2 |      0 |      0 |
|* 61 |                         INDEX RANGE SCAN                    | INT_REFDOSS            |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       2 |      0 |      0 |
|  62 |                       BUFFER SORT                           |                        |      1 |      1 |     4   (0)|      1 |00:00:00.01 |       2 |      0 |      0 |
|* 63 |                        INDEX RANGE SCAN                     | INT_REFDOSS            |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       2 |      0 |      0 |
|* 64 |                      INDEX RANGE SCAN                       | INT_REFDOSS            |      1 |      1 |     1   (0)|      0 |00:00:00.01 |       2 |      0 |      0 |
|  65 |                     MERGE JOIN CARTESIAN                    |                        |      1 |      1 |     5   (0)|      0 |00:00:00.01 |      11 |      0 |      0 |
|  66 |                      NESTED LOOPS ANTI                      |                        |      1 |      1 |     4   (0)|      0 |00:00:00.01 |      11 |      0 |      0 |
|  67 |                       MERGE JOIN OUTER                      |                        |      1 |      1 |     3   (0)|      1 |00:00:00.01 |       9 |      0 |      0 |
|  68 |                        NESTED LOOPS                         |                        |      1 |      1 |     2   (0)|      1 |00:00:00.01 |       7 |      0 |      0 |
|  69 |                         TABLE ACCESS BY INDEX ROWID         | G_DOSSIER              |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       4 |      0 |      0 |
|* 70 |                          INDEX UNIQUE SCAN                  | DOS_REFDOSS            |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       2 |      0 |      0 |
|  71 |                         TABLE ACCESS BY INDEX ROWID BATCHED | T_INTERVENANTS         |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |      0 |      0 |
|* 72 |                          INDEX RANGE SCAN                   | INT_REFDOSS            |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       2 |      0 |      0 |
|  73 |                        BUFFER SORT                          |                        |      1 |      1 |     2   (0)|      1 |00:00:00.01 |       2 |      0 |      0 |
|* 74 |                         INDEX RANGE SCAN                    | INT_REFDOSS            |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       2 |      0 |      0 |
|* 75 |                       INDEX RANGE SCAN                      | INT_REFDOSS            |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       2 |      0 |      0 |
|  76 |                      BUFFER SORT                            |                        |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|  77 |                       TABLE ACCESS BY INDEX ROWID BATCHED   | G_PIECE                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|* 78 |                        INDEX RANGE SCAN                     | PIE_REFDOSS            |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|* 79 |                TABLE ACCESS BY INDEX ROWID BATCHED          | T_INDIVIDU             |      5 |      1 |     1   (0)|      0 |00:00:00.01 |      14 |      2 |      0 |
|* 80 |                 INDEX RANGE SCAN                            | IX_T_INDIVIDU          |      5 |      6 |     1   (0)|      8 |00:00:00.01 |       7 |      0 |      0 |
|  81 |               TABLE ACCESS BY INDEX ROWID                   | G_INDIVIDU             |      5 |      1 |     1   (0)|      5 |00:00:00.01 |      16 |      4 |      0 |
|* 82 |                INDEX UNIQUE SCAN                            | IND_REFINDIV           |      5 |      1 |     1   (0)|      5 |00:00:00.01 |       7 |      0 |      0 |
|* 83 |              TABLE ACCESS BY INDEX ROWID BATCHED            | T_INDIVIDU             |      5 |      1 |     1   (0)|      1 |00:00:00.01 |      14 |      0 |      0 |
|* 84 |               INDEX RANGE SCAN                              | IX_T_INDIVIDU          |      5 |      6 |     1   (0)|      8 |00:00:00.01 |       7 |      0 |      0 |
|* 85 |             TABLE ACCESS BY INDEX ROWID BATCHED             | T_INDIVIDU             |      5 |      1 |     1   (0)|      0 |00:00:00.01 |      14 |      0 |      0 |
|* 86 |              INDEX RANGE SCAN                               | IX_T_INDIVIDU          |      5 |      6 |     1   (0)|      8 |00:00:00.01 |       7 |      0 |      0 |
|* 87 |            INDEX RANGE SCAN                                 | IDX_G_TEL_INDIV        |      5 |      1 |     1   (0)|   2391 |00:00:00.03 |      30 |      5 |      0 |
|* 88 |           INDEX RANGE SCAN                                  | IDX_G_TEL_INDIV        |   2394 |      1 |     1   (0)|      5 |00:00:00.01 |      21 |      0 |      0 |
|* 89 |          INDEX RANGE SCAN                                   | IDX_G_TEL_INDIV        |   2396 |      1 |     1   (0)|   2289K|00:00:01.72 |   67671 |     26 |      0 |
|  90 |         TABLE ACCESS BY INDEX ROWID BATCHED                 | V_DOMAINE              |   2289K|      1 |     1   (0)|   2289K|00:00:04.25 |      17 |      1 |      0 |
|* 91 |          INDEX RANGE SCAN                                   | DOM_TYPABREV           |   2289K|      1 |     1   (0)|   2289K|00:00:01.94 |      13 |      0 |      0 |
|  92 |        VIEW PUSHED PREDICATE                                |                        |   2289K|      1 |     3  (34)|   9158K|00:00:40.29 |      18M|    701 |      0 |
|  93 |         SORT UNIQUE                                         |                        |   2289K|     16 |     3  (34)|   9158K|00:00:38.54 |      18M|    701 |      0 |
|  94 |          NESTED LOOPS                                       |                        |   2289K|     16 |     2   (0)|   9158K|00:00:31.69 |      18M|    701 |      0 |
|  95 |           NESTED LOOPS                                      |                        |   2289K|     16 |     2   (0)|   9158K|00:00:21.66 |      13M|    699 |      0 |
|* 96 |            TABLE ACCESS BY INDEX ROWID BATCHED              | G_INDIVPARAM           |   2289K|     16 |     1   (0)|   9160K|00:00:10.41 |    4580K|    699 |      0 |
|* 97 |             INDEX RANGE SCAN                                | G_IND_REFIND_TYPE_DT01 |   2289K|     26 |     1   (0)|   9160K|00:00:03.54 |      42 |     20 |      0 |
|* 98 |            INDEX UNIQUE SCAN                                | IND_REFINDIV           |   9160K|      1 |     1   (0)|   9158K|00:00:07.59 |    9159K|      0 |      0 |
|  99 |           TABLE ACCESS BY INDEX ROWID                       | G_INDIVIDU             |   9158K|      1 |     1   (0)|   9158K|00:00:06.44 |    4579K|      2 |      0 |
-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
  20 - filter("ST01" IS NOT NULL)
  21 - access("REFPIECE"=)
  24 - access("REFDOSS"=:CASEREF AND "TYPEELEM"='pr' AND "LIBELLE"='POLICY CONTRACT')
       filter("LIBELLE"='POLICY CONTRACT')
  25 - access("DB"."REFINDIVIDU"=)
  26 - access("REFDOSS"=:CASEREF AND "REFTYPE"='DB')
  27 - filter("CRS"."SOCIETE" LIKE 'CRS%')
  28 - access("CRS"."REFINDIVIDU"="DB"."REFINDIVIDU")
  38 - access("D"."REFDOSS"=:CASEREF)
  40 - access("REC"."REFDOSS"=:CASEREF AND "REC"."TYPPIECE"='RECOUVREMENT')
  43 - access("T"."REFDOSS"=:CASEREF)
       filter(("T"."REFTYPE"='AV' OR "T"."REFTYPE"='BU' OR "T"."REFTYPE"='CA' OR "T"."REFTYPE"='CL' OR "T"."REFTYPE"='DB' OR "T"."REFTYPE"='LA'))
  45 - access("CA"."REFDOSS"=:CASEREF AND "CA"."REFTYPE"='CL')
  47 - access("SP"."REFDOSS"=:CASEREF AND "SP"."REFTYPE"='SP')
  48 - filter((("T"."REFTYPE"='TC' AND "D"."CATEGDOSS"='INSURED') OR ("T"."REFTYPE"='CRO' AND "D"."CATEGDOSS"='NOT INSURED') OR ("T"."REFTYPE"='CL' AND
              "D"."CATEGDOSS"='NOT INSURED' AND  IS NULL)))
  53 - filter(("D"."CATEGDOSS"='INSURED' OR "D"."CATEGDOSS"='NOT INSURED'))
  54 - access("D"."REFDOSS"=:CASEREF)
  56 - access("REC"."REFDOSS"=:CASEREF AND "REC"."TYPPIECE"='RECOUVREMENT')
  58 - filter(("T"."REFTYPE"='CL' OR "T"."REFTYPE"='CRO' OR "T"."REFTYPE"='TC'))
  59 - access("T"."REFDOSS"=:CASEREF)
  61 - access("CA"."REFDOSS"=:CASEREF AND "CA"."REFTYPE"='CL')
  63 - access("SP"."REFDOSS"=:CASEREF AND "SP"."REFTYPE"='SP')
  64 - access("REFDOSS"=:B1 AND "REFTYPE"='CRO')
  70 - access("D"."REFDOSS"=:CASEREF)
  72 - access("T"."REFDOSS"=:CASEREF AND "T"."REFTYPE"='SP')
  74 - access("CA"."REFDOSS"=:CASEREF AND "CA"."REFTYPE"='CL')
  75 - access("REFDOSS"=:CASEREF AND "REFTYPE"='CA')
  78 - access("REC"."REFDOSS"=:CASEREF AND "REC"."TYPPIECE"='RECOUVREMENT')
  79 - filter("CRS1"."SOCIETE" LIKE 'CRS%')
  80 - access("CRS1"."REFINDIVIDU"="PARTIES"."REFINDIVIDU")
  82 - access("I"."REFINDIVIDU"="PARTIES"."REFINDIVIDU")
  83 - filter("ESTAB"."SOCIETE"='ESTAB_NUMBER')
  84 - access("ESTAB"."REFINDIVIDU"="I"."REFINDIVIDU")
  85 - filter("GCC"."SOCIETE"='GCC')
  86 - access("GCC"."REFINDIVIDU"="I"."REFINDIVIDU")
  87 - access("FAX"."REFINDIVIDU"="I"."REFINDIVIDU" AND "FAX"."TYPETEL"='FAX')
  88 - access("EMAIL"."REFINDIVIDU"="I"."REFINDIVIDU" AND "EMAIL"."TYPETEL"='EMAIL')
  89 - access("TEL"."REFINDIVIDU"="I"."REFINDIVIDU")
       filter(("TEL"."TYPETEL"='BUR' OR "TEL"."TYPETEL"='DOM' OR "TEL"."TYPETEL"='GSM'))
  91 - access("PAYS"."TYPE"='pays' AND "PAYS"."ABREV"="I"."PAYS")
       filter("PAYS"."ABREV" IS NOT NULL)
  96 - filter("CP"."STR2" IS NOT NULL)
  97 - access("CP"."REFINDIVIDU"="I"."REFINDIVIDU")
  98 - access("PERS"."REFINDIVIDU"="CP"."STR2")

*/
/********************************OLD Metrics***************************************/

/********************************New SQL*******************************************/

SELECT DISTINCT parties.id,
                CASE
                  WHEN parties.ca IS NOT NULL AND parties.id IN (3, 4) THEN
                   parties.refindividu
                  WHEN parties.ca IS NULL AND parties.id IN (3, 4) THEN
                   parties.sp
                  ELSE
                   parties.refindividu
                END,
                parties.ancrefdoss,
                i.tva,
                crs.refext,
                estab.refext,
                gcc.refext,
                i.nom,
                i.adr1,
                '',
                i.adr2,
                i.cp,
                i.ville,
                i.pays,
                pays.abrev16,
                tel.numtel,
                fax.numtel,
                email.numtel,
                pays.abrev16,          
                contact.prenom || ' ' || contact.nom,
                crs1.refext
  FROM g_individu i,
       v_domaine pays,
       (SELECT /*+ push_pred no_merge */
               MAX(numtel) numtel,
               refindividu 
          FROM g_telephone
         WHERE typetel IN ('DOM', 'BUR', 'GSM')
         GROUP BY refindividu ) tel,
              (SELECT /*+ push_pred no_merge */
               MAX(numtel) numtel,
               refindividu 
          FROM g_telephone
         WHERE typetel = 'FAX'
         GROUP BY refindividu  ) fax,
       (SELECT /*+ push_pred no_merge */
               MAX(numtel) numtel,
               refindividu 
          FROM g_telephone 
         WHERE typetel = 'EMAIL'
         GROUP BY refindividu ) email,  
       t_individu crs,
       t_individu crs1,
       t_individu estab,
       t_individu gcc,        
       (SELECT /*+ push_pred no_merge */
               MAX(st01) AS st01
          FROM g_piece
         WHERE refpiece = (SELECT MAX(refelem)
                             FROM t_elements
                            WHERE refdoss = :caseRef
                              AND libelle = 'POLICY CONTRACT'
                              AND typeelem = 'pr')) pol,
       (SELECT /*+ push_pred no_merge */
               t.refindividu,
               t.refdossext,
               t.reftype,
               CASE
                 WHEN d.ext_source = 'NCX' OR d.createur = 'cfc_ncx_imx_cases'
                 THEN 1
           WHEN d.categdoss = 'INSURED' THEN
            2
           ELSE
            0
         END AS ncx,
         DECODE(rec.gpiliblibre, NULL, '', '000', '', '/' || rec.gpiliblibre) AS claim,
         d.ancrefdoss,
         CASE
           WHEN t.reftype = 'BU' AND
                t.refindividu NOT IN ('INTBUPRT', 'INTBUESP') AND
                sp.refindividu IN ('INTBUPRT', 'INTBUESP') THEN
            0
           WHEN t.reftype = 'CL' AND
                (t.refindividu IN ('INTBUPRT', 'INTBUESP') OR
                sp.refindividu NOT IN ('INTBUPRT', 'INTBUESP')) THEN
            0
           WHEN t.reftype = 'DB' THEN
            2
           WHEN t.reftype = 'CA' THEN
            3
           WHEN t.reftype = 'LA' THEN
            4
           WHEN t.reftype = 'AV' THEN
            4
         END AS ID,
         ca.refindividu AS ca,
         sp.refindividu AS sp
          FROM t_intervenants t,
               g_dossier      d,
               g_piece        rec,
               t_intervenants ca,
               t_intervenants sp
         WHERE d.refdoss = :caseRef
           AND d.refdoss = rec.refdoss
           AND rec.typpiece = 'RECOUVREMENT'
           AND d.refdoss = t.refdoss
           AND ca.refdoss(+) = t.refdoss
           AND ca.reftype(+) = 'CL'
           AND sp.reftype(+) = 'SP'
           AND sp.refdoss(+) = t.refdoss
           AND t.reftype IN ('DB', 'BU', 'CL', 'CA', 'LA', 'AV')
        UNION
        SELECT /*+ push_pred no_merge */
               t.refindividu,
               t.refdossext,
               t.reftype,
         CASE
           WHEN d.ext_source = 'NCX' OR d.createur = 'cfc_ncx_imx_cases' THEN
            1
           WHEN d.categdoss = 'INSURED' THEN
            2
           ELSE
            0
         END AS ncx,
         DECODE(rec.gpiliblibre, NULL, '', '/' || rec.gpiliblibre) AS claim,
         d.ancrefdoss,
         1,
         ca.refindividu AS ca,
         sp.refindividu AS sp
          FROM t_intervenants t,
               g_dossier      d,
               g_piece        rec,
               t_intervenants ca,
               t_intervenants sp
         WHERE d.refdoss = :caseRef
           AND d.refdoss = rec.refdoss
           AND rec.typpiece = 'RECOUVREMENT'
           AND d.refdoss = t.refdoss
           AND ca.refdoss(+) = t.refdoss
           AND ca.reftype(+) = 'CL'
           AND sp.reftype(+) = 'SP'
           AND sp.refdoss(+) = t.refdoss
           AND ( ( d.categdoss = 'INSURED' AND t.reftype = 'TC')
               OR( d.categdoss = 'NOT INSURED' AND t.reftype = 'CRO') 
               OR( d.categdoss = 'NOT INSURED' AND t.reftype = 'CL' AND NOT EXISTS (SELECT 1
                                                                                      FROM t_intervenants
                                                                                     WHERE reftype = 'CRO'
                                                                                       AND refdoss = t.refdoss)))
        UNION
        SELECT t.refindividu,
               t.refdossext,
               t.reftype,
               CASE
                 WHEN d.ext_source = 'NCX' OR
                      d.createur = 'cfc_ncx_imx_cases' THEN
                  1
                 WHEN d.categdoss = 'INSURED' THEN
                  2
                 ELSE
                  0
               END AS ncx,
               DECODE(rec.gpiliblibre, NULL, '', '/' || rec.gpiliblibre) AS claim,
               d.ancrefdoss,
               3,
               ca.refindividu AS ca,
               t.refindividu AS sp
          FROM t_intervenants t,
               g_dossier d,
               g_piece rec, 
               t_intervenants ca
         WHERE d.refdoss = :caseRef
           AND d.refdoss = rec.refdoss
           AND rec.typpiece = 'RECOUVREMENT'
           AND d.refdoss = t.refdoss
           AND ca.refdoss(+) = t.refdoss
           AND ca.reftype(+) = 'CL'
           AND t.reftype = 'SP'
           AND NOT EXISTS (SELECT 1
                  FROM t_intervenants
                 WHERE reftype = 'CA'
                   AND refdoss = t.refdoss)) parties,
       (SELECT /*+ push_pred no_merge */
        DISTINCT cp.refindividu, pers.nom, pers.prenom
          FROM g_indivparam cp, g_individu pers
         WHERE pers.refindividu = cp.str2) contact,
       g_individu db
 WHERE contact.refindividu(+) = i.refindividu
   AND db.refindividu = (SELECT refindividu
                           FROM t_intervenants
                          WHERE refdoss = :caseRef
                            AND reftype = 'DB')
   AND tel.refindividu(+) = i.refindividu
   AND fax.refindividu(+) = i.refindividu
   AND email.refindividu(+) = i.refindividu
   AND crs.refindividu(+) = db.refindividu
   AND crs.societe(+) LIKE 'CRS%'
   AND crs1.refindividu(+) = parties.refindividu
   AND crs1.societe(+) LIKE 'CRS%'
   AND estab.refindividu(+) = i.refindividu
   AND estab.societe(+) = 'ESTAB_NUMBER'
   AND gcc.refindividu(+) = i.refindividu
   AND gcc.societe(+) = 'GCC'
   AND pays.type(+) = 'pays'
   AND pays.abrev(+) = i.pays
   AND i.refindividu = parties.refindividu
 ORDER BY parties.id DESC;
/********************************New SQL*******************************************/
/********************************New Metrics***************************************/
/*
Plan hash value: 3924626012
-------------------------------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                                | Name                   | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  |
-------------------------------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                                         |                        |      1 |        |    59 (100)|      8 |00:00:00.58 |    2073 |    736 |
|   1 |  SORT ORDER BY                                           |                        |      1 |     25 |    59  (16)|      8 |00:00:00.58 |    2073 |    736 |
|   2 |   HASH UNIQUE                                            |                        |      1 |     25 |    58  (14)|      8 |00:00:00.58 |    2073 |    736 |
|   3 |    NESTED LOOPS OUTER                                    |                        |      1 |     25 |    56  (13)|      8 |00:00:00.58 |    2073 |    736 |
|   4 |     NESTED LOOPS OUTER                                   |                        |      1 |      5 |    41   (5)|      5 |00:00:00.12 |     210 |     21 |
|   5 |      NESTED LOOPS OUTER                                  |                        |      1 |      5 |    36   (6)|      5 |00:00:00.12 |     198 |     21 |
|   6 |       NESTED LOOPS OUTER                                 |                        |      1 |      5 |    31   (7)|      5 |00:00:00.12 |     168 |     21 |
|   7 |        NESTED LOOPS OUTER                                |                        |      1 |      5 |    30   (7)|      5 |00:00:00.11 |     152 |     17 |
|   8 |         NESTED LOOPS OUTER                               |                        |      1 |      5 |    29   (7)|      5 |00:00:00.11 |     138 |     17 |
|   9 |          NESTED LOOPS OUTER                              |                        |      1 |      5 |    28   (8)|      5 |00:00:00.11 |     124 |     17 |
|  10 |           NESTED LOOPS                                   |                        |      1 |      5 |    23   (9)|      5 |00:00:00.10 |      86 |     14 |
|  11 |            NESTED LOOPS OUTER                            |                        |      1 |      5 |    22  (10)|      5 |00:00:00.09 |      70 |     11 |
|  12 |             MERGE JOIN CARTESIAN                         |                        |      1 |      5 |    21  (10)|      5 |00:00:00.09 |      56 |     11 |
|  13 |              NESTED LOOPS OUTER                          |                        |      1 |      1 |     4   (0)|      1 |00:00:00.01 |       9 |      3 |
|  14 |               NESTED LOOPS                               |                        |      1 |      1 |     3   (0)|      1 |00:00:00.01 |       7 |      3 |
|  15 |                VIEW                                      |                        |      1 |      1 |     2   (0)|      1 |00:00:00.01 |       3 |      3 |
|  16 |                 SORT AGGREGATE                           |                        |      1 |      1 |            |      1 |00:00:00.01 |       3 |      3 |
|* 17 |                  TABLE ACCESS BY INDEX ROWID BATCHED     | G_PIECE                |      1 |      1 |     1   (0)|      0 |00:00:00.01 |       3 |      3 |
|* 18 |                   INDEX RANGE SCAN                       | PIE_REFPIECE           |      1 |      1 |     1   (0)|      0 |00:00:00.01 |       3 |      3 |
|  19 |                    SORT AGGREGATE                        |                        |      1 |      1 |            |      1 |00:00:00.01 |       3 |      3 |
|  20 |                     TABLE ACCESS BY INDEX ROWID BATCHED  | T_ELEMENTS             |      1 |      1 |     1   (0)|      0 |00:00:00.01 |       3 |      3 |
|* 21 |                      INDEX RANGE SCAN                    | ELE_DOSS_TYP_ASSOC_LIB |      1 |      1 |     1   (0)|      0 |00:00:00.01 |       3 |      3 |
|* 22 |                INDEX UNIQUE SCAN                         | IND_REFINDIV           |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       4 |      0 |
|* 23 |                 INDEX RANGE SCAN                         | INT_REFDOSS            |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       2 |      0 |
|* 24 |               TABLE ACCESS BY INDEX ROWID BATCHED        | T_INDIVIDU             |      1 |      1 |     1   (0)|      0 |00:00:00.01 |       2 |      0 |
|* 25 |                INDEX RANGE SCAN                          | IX_T_INDIVIDU          |      1 |      6 |     1   (0)|      0 |00:00:00.01 |       2 |      0 |
|  26 |              BUFFER SORT                                 |                        |      1 |      5 |    20  (10)|      5 |00:00:00.09 |      47 |      8 |
|  27 |               VIEW                                       |                        |      1 |      5 |    17  (12)|      5 |00:00:00.09 |      47 |      8 |
|  28 |                SORT UNIQUE                               |                        |      1 |      5 |    17  (12)|      5 |00:00:00.09 |      47 |      8 |
|  29 |                 UNION-ALL                                |                        |      1 |        |            |      5 |00:00:00.09 |      47 |      8 |
|  30 |                  MERGE JOIN OUTER                        |                        |      1 |      3 |     5   (0)|      4 |00:00:00.05 |      17 |      6 |
|  31 |                   MERGE JOIN OUTER                       |                        |      1 |      3 |     4   (0)|      4 |00:00:00.05 |      15 |      6 |
|  32 |                    MERGE JOIN CARTESIAN                  |                        |      1 |      3 |     3   (0)|      4 |00:00:00.05 |      13 |      6 |
|  33 |                     NESTED LOOPS                         |                        |      1 |      1 |     2   (0)|      1 |00:00:00.04 |       8 |      4 |
|  34 |                      TABLE ACCESS BY INDEX ROWID         | G_DOSSIER              |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       4 |      1 |
|* 35 |                       INDEX UNIQUE SCAN                  | DOS_REFDOSS            |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       2 |      0 |
|  36 |                      TABLE ACCESS BY INDEX ROWID BATCHED | G_PIECE                |      1 |      1 |     1   (0)|      1 |00:00:00.04 |       4 |      3 |
|* 37 |                       INDEX RANGE SCAN                   | PIE_REFDOSS            |      1 |      1 |     1   (0)|      1 |00:00:00.04 |       3 |      3 |
|  38 |                     BUFFER SORT                          |                        |      1 |      6 |     2   (0)|      4 |00:00:00.01 |       5 |      2 |
|  39 |                      TABLE ACCESS BY INDEX ROWID BATCHED | T_INTERVENANTS         |      1 |      6 |     1   (0)|      4 |00:00:00.01 |       5 |      2 |
|* 40 |                       INDEX RANGE SCAN                   | INT_REFDOSS            |      1 |      1 |     1   (0)|      4 |00:00:00.01 |       2 |      0 |
|  41 |                    BUFFER SORT                           |                        |      4 |      1 |     3   (0)|      4 |00:00:00.01 |       2 |      0 |
|* 42 |                     INDEX RANGE SCAN                     | INT_REFDOSS            |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       2 |      0 |
|  43 |                   BUFFER SORT                            |                        |      4 |      1 |     4   (0)|      4 |00:00:00.01 |       2 |      0 |
|* 44 |                    INDEX RANGE SCAN                      | INT_REFDOSS            |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       2 |      0 |
|* 45 |                  FILTER                                  |                        |      1 |        |            |      1 |00:00:00.04 |      19 |      2 |
|  46 |                   MERGE JOIN OUTER                       |                        |      1 |     58 |     5   (0)|      1 |00:00:00.04 |      17 |      2 |
|  47 |                    MERGE JOIN OUTER                      |                        |      1 |     56 |     4   (0)|      1 |00:00:00.04 |      15 |      2 |
|  48 |                     MERGE JOIN CARTESIAN                 |                        |      1 |     54 |     3   (0)|      1 |00:00:00.04 |      13 |      2 |
|  49 |                      NESTED LOOPS                        |                        |      1 |      1 |     2   (0)|      1 |00:00:00.01 |       8 |      0 |
|* 50 |                       TABLE ACCESS BY INDEX ROWID        | G_DOSSIER              |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       4 |      0 |
|* 51 |                        INDEX UNIQUE SCAN                 | DOS_REFDOSS            |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       2 |      0 |
|  52 |                       TABLE ACCESS BY INDEX ROWID BATCHED| G_PIECE                |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       4 |      0 |
|* 53 |                        INDEX RANGE SCAN                  | PIE_REFDOSS            |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |      0 |
|  54 |                      BUFFER SORT                         |                        |      1 |      3 |     2   (0)|      1 |00:00:00.04 |       5 |      2 |
|* 55 |                       TABLE ACCESS BY INDEX ROWID BATCHED| T_INTERVENANTS         |      1 |      3 |     1   (0)|      1 |00:00:00.04 |       5 |      2 |
|* 56 |                        INDEX RANGE SCAN                  | INT_DOS_INDIV          |      1 |      4 |     1   (0)|      5 |00:00:00.04 |       2 |      2 |
|  57 |                     BUFFER SORT                          |                        |      1 |      1 |     3   (0)|      1 |00:00:00.01 |       2 |      0 |
|* 58 |                      INDEX RANGE SCAN                    | INT_REFDOSS            |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       2 |      0 |
|  59 |                    BUFFER SORT                           |                        |      1 |      1 |     4   (0)|      1 |00:00:00.01 |       2 |      0 |
|* 60 |                     INDEX RANGE SCAN                     | INT_REFDOSS            |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       2 |      0 |
|* 61 |                   INDEX RANGE SCAN                       | INT_REFDOSS            |      1 |      1 |     1   (0)|      0 |00:00:00.01 |       2 |      0 |
|  62 |                  MERGE JOIN CARTESIAN                    |                        |      1 |      1 |     5   (0)|      0 |00:00:00.01 |      11 |      0 |
|  63 |                   NESTED LOOPS ANTI                      |                        |      1 |      1 |     4   (0)|      0 |00:00:00.01 |      11 |      0 |
|  64 |                    MERGE JOIN OUTER                      |                        |      1 |      1 |     3   (0)|      1 |00:00:00.01 |       9 |      0 |
|  65 |                     NESTED LOOPS                         |                        |      1 |      1 |     2   (0)|      1 |00:00:00.01 |       7 |      0 |
|  66 |                      TABLE ACCESS BY INDEX ROWID         | G_DOSSIER              |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       4 |      0 |
|* 67 |                       INDEX UNIQUE SCAN                  | DOS_REFDOSS            |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       2 |      0 |
|  68 |                      TABLE ACCESS BY INDEX ROWID BATCHED | T_INTERVENANTS         |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |      0 |
|* 69 |                       INDEX RANGE SCAN                   | INT_REFDOSS            |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       2 |      0 |
|  70 |                     BUFFER SORT                          |                        |      1 |      1 |     2   (0)|      1 |00:00:00.01 |       2 |      0 |
|* 71 |                      INDEX RANGE SCAN                    | INT_REFDOSS            |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       2 |      0 |
|* 72 |                    INDEX RANGE SCAN                      | INT_REFDOSS            |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       2 |      0 |
|  73 |                   BUFFER SORT                            |                        |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|  74 |                    TABLE ACCESS BY INDEX ROWID BATCHED   | G_PIECE                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 75 |                     INDEX RANGE SCAN                     | PIE_REFDOSS            |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 76 |             TABLE ACCESS BY INDEX ROWID BATCHED          | T_INDIVIDU             |      5 |      1 |     1   (0)|      0 |00:00:00.01 |      14 |      0 |
|* 77 |              INDEX RANGE SCAN                            | IX_T_INDIVIDU          |      5 |      6 |     1   (0)|      8 |00:00:00.01 |       7 |      0 |
|  78 |            TABLE ACCESS BY INDEX ROWID                   | G_INDIVIDU             |      5 |      1 |     1   (0)|      5 |00:00:00.01 |      16 |      3 |
|* 79 |             INDEX UNIQUE SCAN                            | IND_REFINDIV           |      5 |      1 |     1   (0)|      5 |00:00:00.01 |       7 |      0 |
|  80 |           VIEW PUSHED PREDICATE                          |                        |      5 |      1 |     1   (0)|      5 |00:00:00.01 |      38 |      3 |
|  81 |            SORT GROUP BY                                 |                        |      5 |      1 |     1   (0)|      5 |00:00:00.01 |      38 |      3 |
|* 82 |             INDEX RANGE SCAN                             | IDX_G_TEL_INDIV        |      5 |      1 |     1   (0)|    962 |00:00:00.01 |      38 |      3 |
|* 83 |          TABLE ACCESS BY INDEX ROWID BATCHED             | T_INDIVIDU             |      5 |      1 |     1   (0)|      1 |00:00:00.01 |      14 |      0 |
|* 84 |           INDEX RANGE SCAN                               | IX_T_INDIVIDU          |      5 |      6 |     1   (0)|      8 |00:00:00.01 |       7 |      0 |
|* 85 |         TABLE ACCESS BY INDEX ROWID BATCHED              | T_INDIVIDU             |      5 |      1 |     1   (0)|      0 |00:00:00.01 |      14 |      0 |
|* 86 |          INDEX RANGE SCAN                                | IX_T_INDIVIDU          |      5 |      6 |     1   (0)|      8 |00:00:00.01 |       7 |      0 |
|  87 |        TABLE ACCESS BY INDEX ROWID BATCHED               | V_DOMAINE              |      5 |      1 |     1   (0)|      5 |00:00:00.01 |      16 |      4 |
|* 88 |         INDEX RANGE SCAN                                 | DOM_TYPABREV           |      5 |      1 |     1   (0)|      5 |00:00:00.01 |      12 |      2 |
|  89 |       VIEW PUSHED PREDICATE                              |                        |      5 |      1 |     1   (0)|      2 |00:00:00.01 |      30 |      0 |
|  90 |        SORT GROUP BY                                     |                        |      5 |      1 |     1   (0)|      2 |00:00:00.01 |      30 |      0 |
|* 91 |         INDEX RANGE SCAN                                 | IDX_G_TEL_INDIV        |      5 |      1 |     1   (0)|   2391 |00:00:00.01 |      30 |      0 |
|  92 |      VIEW PUSHED PREDICATE                               |                        |      5 |      1 |     1   (0)|      3 |00:00:00.01 |      12 |      0 |
|  93 |       SORT GROUP BY                                      |                        |      5 |      1 |     1   (0)|      3 |00:00:00.01 |      12 |      0 |
|* 94 |        INDEX RANGE SCAN                                  | IDX_G_TEL_INDIV        |      5 |      1 |     1   (0)|      5 |00:00:00.01 |      12 |      0 |
|  95 |     VIEW PUSHED PREDICATE                                |                        |      5 |      1 |     3  (34)|      6 |00:00:00.46 |    1863 |    715 |
|  96 |      SORT UNIQUE                                         |                        |      5 |     16 |     3  (34)|      6 |00:00:00.46 |    1863 |    715 |
|  97 |       NESTED LOOPS                                       |                        |      5 |     16 |     2   (0)|      6 |00:00:00.46 |    1863 |    715 |
|  98 |        NESTED LOOPS                                      |                        |      5 |     16 |     2   (0)|      6 |00:00:00.46 |    1859 |    715 |
|* 99 |         TABLE ACCESS BY INDEX ROWID BATCHED              | G_INDIVPARAM           |      5 |     16 |     1   (0)|   1806 |00:00:00.46 |     772 |    715 |
|*100 |          INDEX RANGE SCAN                                | G_IND_REFIND_TYPE_DT01 |      5 |     26 |     1   (0)|   1841 |00:00:00.09 |      27 |     22 |
|*101 |         INDEX UNIQUE SCAN                                | IND_REFINDIV           |   1806 |      1 |     1   (0)|      6 |00:00:00.01 |    1087 |      0 |
| 102 |        TABLE ACCESS BY INDEX ROWID                       | G_INDIVIDU             |      6 |      1 |     1   (0)|      6 |00:00:00.01 |       4 |      0 |
-------------------------------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
  17 - filter("ST01" IS NOT NULL)
  18 - access("REFPIECE"=)
  21 - access("REFDOSS"=:CASEREF AND "TYPEELEM"='pr' AND "LIBELLE"='POLICY CONTRACT')
       filter("LIBELLE"='POLICY CONTRACT')
  22 - access("DB"."REFINDIVIDU"=)
  23 - access("REFDOSS"=:CASEREF AND "REFTYPE"='DB')
  24 - filter("CRS"."SOCIETE" LIKE 'CRS%')
  25 - access("CRS"."REFINDIVIDU"="DB"."REFINDIVIDU")
  35 - access("D"."REFDOSS"=:CASEREF)
  37 - access("REC"."REFDOSS"=:CASEREF AND "REC"."TYPPIECE"='RECOUVREMENT')
  40 - access("T"."REFDOSS"=:CASEREF)
       filter(("T"."REFTYPE"='AV' OR "T"."REFTYPE"='BU' OR "T"."REFTYPE"='CA' OR "T"."REFTYPE"='CL' OR "T"."REFTYPE"='DB' OR "T"."REFTYPE"='LA'))
  42 - access("CA"."REFDOSS"=:CASEREF AND "CA"."REFTYPE"='CL')
  44 - access("SP"."REFDOSS"=:CASEREF AND "SP"."REFTYPE"='SP')
  45 - filter((("T"."REFTYPE"='TC' AND "D"."CATEGDOSS"='INSURED') OR ("T"."REFTYPE"='CRO' AND "D"."CATEGDOSS"='NOT INSURED') OR ("T"."REFTYPE"='CL' AND
              "D"."CATEGDOSS"='NOT INSURED' AND  IS NULL)))
  50 - filter(("D"."CATEGDOSS"='INSURED' OR "D"."CATEGDOSS"='NOT INSURED'))
  51 - access("D"."REFDOSS"=:CASEREF)
  53 - access("REC"."REFDOSS"=:CASEREF AND "REC"."TYPPIECE"='RECOUVREMENT')
  55 - filter(("T"."REFTYPE"='CL' OR "T"."REFTYPE"='CRO' OR "T"."REFTYPE"='TC'))
  56 - access("T"."REFDOSS"=:CASEREF)
  58 - access("CA"."REFDOSS"=:CASEREF AND "CA"."REFTYPE"='CL')
  60 - access("SP"."REFDOSS"=:CASEREF AND "SP"."REFTYPE"='SP')
  61 - access("REFDOSS"=:B1 AND "REFTYPE"='CRO')
  67 - access("D"."REFDOSS"=:CASEREF)
  69 - access("T"."REFDOSS"=:CASEREF AND "T"."REFTYPE"='SP')
  71 - access("CA"."REFDOSS"=:CASEREF AND "CA"."REFTYPE"='CL')
  72 - access("REFDOSS"=:CASEREF AND "REFTYPE"='CA')
  75 - access("REC"."REFDOSS"=:CASEREF AND "REC"."TYPPIECE"='RECOUVREMENT')
  76 - filter("CRS1"."SOCIETE" LIKE 'CRS%')
  77 - access("CRS1"."REFINDIVIDU"="PARTIES"."REFINDIVIDU")
  79 - access("I"."REFINDIVIDU"="PARTIES"."REFINDIVIDU")
  82 - access("REFINDIVIDU"="I"."REFINDIVIDU")
       filter(("TYPETEL"='BUR' OR "TYPETEL"='DOM' OR "TYPETEL"='GSM'))
  83 - filter("ESTAB"."SOCIETE"='ESTAB_NUMBER')
  84 - access("ESTAB"."REFINDIVIDU"="I"."REFINDIVIDU")
  85 - filter("GCC"."SOCIETE"='GCC')
  86 - access("GCC"."REFINDIVIDU"="I"."REFINDIVIDU")
  88 - access("PAYS"."TYPE"='pays' AND "PAYS"."ABREV"="I"."PAYS")
       filter("PAYS"."ABREV" IS NOT NULL)
  91 - access("REFINDIVIDU"="I"."REFINDIVIDU" AND "TYPETEL"='FAX')
  94 - access("REFINDIVIDU"="I"."REFINDIVIDU" AND "TYPETEL"='EMAIL')
  99 - filter("CP"."STR2" IS NOT NULL)
 100 - access("CP"."REFINDIVIDU"="I"."REFINDIVIDU")
 101 - access("PERS"."REFINDIVIDU"="CP"."STR2")

*/
/********************************New Metrics***************************************/

/********************************Index statistics**********************************/

/********************************Other SQLs****************************************/          
/*

*/ 
/********************************Other SQLs****************************************/              
