/********************************************************************************
*********       E-mail subject: ACSTDWEB-1633
*********             Instance: PreProd
*********          Description: 
Problem:
SE variable ds_Al_CS_uns_match was provided as slow from PreProd.

Analysis:
The problem of the variable ds_Al_CS_uns_match is that it is using table t_elements to select data only for the active elements, which makes INDEX SKIP SCAN on index ELE_DOSS_TYP_ASSOC_LIB 
to search through big amount of data.
The solution here is to select the data from table t_element_se, where are stored only the active elements and we can access it with INDEX RANGE SCAN throgh index ELESE_LIBELLE_IDX.

Suggestion:
Please change the query to use table t_element_se instead of table t_elements as it is shown in the New SQL section below.

*********               SQL_ID: a9fap248zaxkr
*********      Program/Package: 
*********              Request: Galina Trifonova 
*********               Author: Dimitar Dimitrov
********* Received e-mail date: 12/07/2024
*********      Resolution date: 12/07/2024
*********  Trace old file here: \\epox\specifs\performance\tmp\
*********  Trace new file here:
***********************************************************************************/

/********************************OLD SQL*******************************************/

select count(*)
  from t_elements
 where typeelem = 'se'
   and libelle = 'Alert: CS unsucsfull match'
   and actif = 'o';
/********************************OLD SQL*******************************************/
/********************************OLD Metrics***************************************/
/*
Plan hash value: 4010067596
-----------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                            | Name                   | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  |
-----------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                     |                        |      1 |        |  1373 (100)|      1 |00:00:35.70 |     114K|  76759 |
|   1 |  SORT AGGREGATE                      |                        |      1 |      1 |            |      1 |00:00:35.70 |     114K|  76759 |
|*  2 |   TABLE ACCESS BY INDEX ROWID BATCHED| T_ELEMENTS             |      1 |      1 |  1373   (0)|      0 |00:00:35.70 |     114K|  76759 |
|*  3 |    INDEX SKIP SCAN                   | ELE_DOSS_TYP_ASSOC_LIB |      1 |      1 |  1373   (0)|      0 |00:00:35.70 |     114K|  76759 |
-----------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   2 - filter("ACTIF"='o')
   3 - access("TYPEELEM"='se' AND "LIBELLE"='Alert: CS unsucsfull match')
       filter(("LIBELLE"='Alert: CS unsucsfull match' AND "TYPEELEM"='se'))
*/
/********************************OLD Metrics***************************************/

/********************************New SQL*******************************************/

select count(*)
  from t_element_se
 where libelle = 'Alert: CS unsucsfull match';
/********************************New SQL*******************************************/
/********************************New Metrics***************************************/
/*
Plan hash value: 2782874386
-----------------------------------------------------------------------------------------------------------------------
| Id  | Operation         | Name              | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  |
-----------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT  |                   |      1 |        |     1 (100)|      1 |00:00:00.01 |       3 |      2 |
|   1 |  SORT AGGREGATE   |                   |      1 |      1 |            |      1 |00:00:00.01 |       3 |      2 |
|*  2 |   INDEX RANGE SCAN| ELESE_LIBELLE_IDX |      1 |    605 |     1   (0)|      0 |00:00:00.01 |       3 |      2 |
-----------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   2 - access("LIBELLE"='Alert: CS unsucsfull match')
*/
/********************************New Metrics***************************************/

/********************************Index statistics**********************************/

/********************************Other SQLs****************************************/          
/*

*/ 
/********************************Other SQLs****************************************/              
