/********************************************************************************
*********       E-mail subject: FGADEV-5918
*********             Instance: IMXREC(UAT)
*********          Description: 
Problem:
We were requested to check is there something that can be improved in the bkg_anonyme batch.

Analysis:
We checked the work of the bkg_anonyme batch for the provided periods and as you can see below, the TOP SQL for the first period between 11:24:51 and 11:56:21 on 26/11/2024 is apt3h5ys9qd30 
( which is the cursor of the batch ). Based on the information in the AWR and the manual execution, it takes ~9-10 minutes and its execution plan looks OK. The next TOP SQLs are ddr8uck5s5kp3 and 02yb6k216ntqf, 
which are ctxsys.drvdml.com_sync_index and ctxsys.syncrn . For the second period between 11:58:39 and 12:36:12 on 26/11/2024, the TOP SQL is dnrsdj7d301zv ( which was responsible for 39% of the time ). From what we 
see in its execution plan, it doesn't start from the selective predicate, which is the "g.fg_ready_for_anon = 'O'". In the IN clase, there is NOT EXISTS, which confuse Oracle which execution plan to choose. We moved 
this NOT EXISTS outside in the main query and added hint to force Oracle to start from g.fg_ready_for_anon = 'O' with FULL SCAN of g_dossier ( because column g.fg_ready_for_anon is not indexed ).
Please check is it functionally correct to move the NOT EXISTS as it is shown in the New SQL section below. Also, as it is decribed in the task, the bkg_anonyme has processed ~9k individuals in the first period and 
~ 18k individuals for the second period, so please keep in mind that the idea of this batch is not to process such big number of individuals, so if you use it for thousands of individuals, it will take time.
Also, we noticed that there is executions of SQL 9fyzycp9a53r3 ( the query for MODULE='dwhextr' in iMX DCL ) which was discussed to be removed in KBCCFDEV-5802. 
The optimization of SQL dnrsdj7d301zv and the removal of SQL 9fyzycp9a53r3 should save some time, but don't expect to see huge difference in the execution time.

Suggestion:
1. Please ask DBA team to remove SQL 9fyzycp9a53r3 from iMX DCL as it is discussed in KBCCFDEV-5802 in comment.
2. Please ask B&I team to check is the variant of SQL dnrsdj7d301zv in the New SQL section below functionally correct and if it is, change the query as it is shown in the New SQL section below.

*********               SQL_ID: dnrsdj7d301zv
*********      Program/Package: 
*********              Request: Loua Latrech
*********               Author: Dimitar Dimitrov
********* Received e-mail date: 04/12/2024
*********      Resolution date: 05/12/2024
*********  Trace old file here: \\epox\specifs\performance\tmp\
*********  Trace new file here:
***********************************************************************************/

/********************************OLD SQL*******************************************/

-- dnrsdj7d301zv

SELECT g.refdoss
  FROM g_dossier g
 WHERE g.fg_ready_for_anon = 'O'
   AND g.refdoss in ( SELECT refdoss
                        FROM t_intervenants t, 
                             g_individu ind, 
                             v_domaine VD
                       WHERE t.refindividu = ind.refindividu
                         AND ind.dtanonym_dt is not NULL
                         AND t.reftype = VD.abrev
                         AND VD.type = 'intervenant'
                         AND VD.abrev5 = 'X'
                         AND ind.moralphy = 'P'
                         AND NOT EXISTS ( SELECT 1
                                            FROM T_INTERVENANTS
                                           WHERE REFTYPE = 'CL'
                                             AND REFDOSS = g.refdoss
                                             AND REFINDIVIDU NOT IN ('INTFGTIS') ) )
   AND NOT EXISTS ( SELECT 1
                      FROM t_intervenants ti, 
                           g_individu ind, 
                           v_domaine VD
                     WHERE g.refdoss = ti.refdoss
                       AND ti.refindividu = ind.refindividu
                       AND ind.dtanonym_dt is NULL
                       AND ind.moralphy = 'P'
                       AND ti.reftype = VD.abrev
                       AND VD.type = 'intervenant'
                       AND VD.abrev5 = 'X' )
   AND NOT EXISTS ( SELECT 1
                      FROM G_CONNU_EXT_DWH
                     WHERE EXTSYSTEM = 'bkg_anonym'
                       AND REFERENCE = g.refdoss
                       AND TABLENAME = 'G_DOSSIER' );
/********************************OLD SQL*******************************************/
/********************************OLD Metrics***************************************/
/*
-- For the full period

MODULE                    SQL_ID         PLAN_HASH SID    SERIAL# EVENT                          FROM                           TO                                 ACTIVE NUMBER_OF_EXECUTIONS PERC
------------------------- ------------- ---------- ------ ------- ------------------------------ ------------------------------ ------------------------------ ---------- -------------------- ------
bkg_anonyme               apt3h5ys9qd30            760                                           2024/11/26 11:24:57            2024/11/26 12:06:39                   910                    2 25%
bkg_anonyme               dnrsdj7d301zv  838481363 760    8295                                   2024/11/26 12:06:49            2024/11/26 12:21:09                   750                    1 21%
bkg_anonyme               ddr8uck5s5kp3          0 760    8219                                   2024/11/26 11:32:08            2024/11/26 11:56:18                   370                 9494 10%
bkg_anonyme               9fyzycp9a53r3  582637025 760            ON CPU                         2024/11/26 11:34:28            2024/11/26 12:36:00                   300               671191 8%
bkg_anonyme               02yb6k216ntqf          0 760    8219                                   2024/11/26 11:32:38            2024/11/26 11:55:58                   250                 9186 7%


SQL_ID           ELAPSED                     GETS      READS       ROWS  ELAP/EXEC  GETS/EXEC READS/EXEC  ROWS/EXEC       EXEC PLAN_HASH_VALUE
------------- ---------- ------------------------ ---------- ---------- ---------- ---------- ---------- ---------- ---------- ---------------
dnrsdj7d301zv 721.005029                152376550    1863060      18496     721.01  152376550    1863060      18496          1       838481363
apt3h5ys9qd30 910.128191                 76106800    7350249       9707     455.06   38053400  3675124.5     4853.5          2       998817326



-- Individual anonymization run:

MODULE                    SQL_ID         PLAN_HASH SID    SERIAL# EVENT                          FROM                           TO                                 ACTIVE NUMBER_OF_EXECUTIONS PERC
------------------------- ------------- ---------- ------ ------- ------------------------------ ------------------------------ ------------------------------ ---------- -------------------- ------
bkg_anonyme                                        760                                           2024/11/26 11:24:57            2024/11/26 11:59:58                  1860              2785403 100%



MODULE                    SQL_ID         PLAN_HASH SID    SERIAL# EVENT                          FROM                           TO                                 ACTIVE NUMBER_OF_EXECUTIONS PERC
------------------------- ------------- ---------- ------ ------- ------------------------------ ------------------------------ ------------------------------ ---------- -------------------- ------
bkg_anonyme                                        760            ON CPU                         2024/11/26 11:24:57            2024/11/26 11:59:48                  1320              2785403 71%
bkg_anonyme                                        760            db file sequential read        2024/11/26 11:25:57            2024/11/26 11:59:58                   450                27869 24%
bkg_anonyme               apt3h5ys9qd30 1458055896 760    8219    db file scattered read         2024/11/26 11:25:07            2024/11/26 11:31:57                    40                    1 2%
bkg_anonyme               NULL                     760    8219    log file sync                  2024/11/26 11:35:18            2024/11/26 11:45:28                    30                      2%
bkg_anonyme               02yb6k216ntqf          0 760    8219    direct path read               2024/11/26 11:49:28            2024/11/26 11:55:58                    20                 2640 1%



MODULE                    SQL_ID         PLAN_HASH SID    SERIAL# EVENT                          FROM                           TO                                 ACTIVE NUMBER_OF_EXECUTIONS PERC
------------------------- ------------- ---------- ------ ------- ------------------------------ ------------------------------ ------------------------------ ---------- -------------------- ------
bkg_anonyme               apt3h5ys9qd30            760                                           2024/11/26 11:24:57            2024/11/26 11:59:58                   510                    2 27%
bkg_anonyme               ddr8uck5s5kp3          0 760    8219                                   2024/11/26 11:32:08            2024/11/26 11:56:18                   370                 9494 20%
bkg_anonyme               02yb6k216ntqf          0 760    8219                                   2024/11/26 11:32:38            2024/11/26 11:55:58                   250                 9186 13%
bkg_anonyme               4r23u15d4c9rh 2727418660 760    8219    ON CPU                         2024/11/26 11:34:48            2024/11/26 11:56:08                   140                 8449 8%
bkg_anonyme               9fyzycp9a53r3  582637025 760    8219    ON CPU                         2024/11/26 11:34:28            2024/11/26 11:50:58                    80               132895 4%
bkg_anonyme               NULL                     760    8219                                   2024/11/26 11:35:18            2024/11/26 11:55:38                    70                      4%
bkg_anonyme               dn18ybgkt5r3r 1465023683 760    8219    db file sequential read        2024/11/26 11:32:28            2024/11/26 11:54:18                    70                 8571 4%


-- Case anonymization run:

MODULE                    SQL_ID         PLAN_HASH SID    SERIAL# EVENT                          FROM                           TO                                 ACTIVE NUMBER_OF_EXECUTIONS PERC
------------------------- ------------- ---------- ------ ------- ------------------------------ ------------------------------ ------------------------------ ---------- -------------------- ------
bkg_anonyme                                        760                                           2024/11/26 11:55:08            2024/11/26 12:36:10                  1940              3323699 100%


MODULE                    SQL_ID         PLAN_HASH SID    SERIAL# EVENT                          FROM                           TO                                 ACTIVE NUMBER_OF_EXECUTIONS PERC
------------------------- ------------- ---------- ------ ------- ------------------------------ ------------------------------ ------------------------------ ---------- -------------------- ------
bkg_anonyme                                        760            ON CPU                         2024/11/26 11:55:18            2024/11/26 12:36:00                  1160              3323699 60%
bkg_anonyme                                        760            db file sequential read        2024/11/26 11:55:08            2024/11/26 12:36:10                   640                27869 33%
bkg_anonyme               dnrsdj7d301zv  838481363 760    8295    db file parallel read          2024/11/26 12:07:19            2024/11/26 12:10:59                    60                    1 3%
bkg_anonyme               NULL                     760    8295    log file sync                  2024/11/26 12:21:59            2024/11/26 12:35:00                    40                      2%
bkg_anonyme               apt3h5ys9qd30  998817326 760    8295    db file scattered read         2024/11/26 12:03:49            2024/11/26 12:06:39                    30                    1 2%
bkg_anonyme               02yb6k216ntqf          0 760    8219    direct path read               2024/11/26 11:55:58            2024/11/26 11:55:58                    10                    1 1%


MODULE                    SQL_ID         PLAN_HASH SID    SERIAL# EVENT                          FROM                           TO                                 ACTIVE NUMBER_OF_EXECUTIONS PERC
------------------------- ------------- ---------- ------ ------- ------------------------------ ------------------------------ ------------------------------ ---------- -------------------- ------
bkg_anonyme               dnrsdj7d301zv  838481363 760    8295                                   2024/11/26 12:06:49            2024/11/26 12:21:09                   750                    1 39%
bkg_anonyme               apt3h5ys9qd30  998817326 760    8295                                   2024/11/26 11:58:48            2024/11/26 12:06:39                   480                    1 25%
bkg_anonyme               9fyzycp9a53r3  582637025 760    8295    ON CPU                         2024/11/26 12:13:29            2024/11/26 12:36:00                   220               485611 11%
bkg_anonyme               bkzw80krv1p4f 1772580724 760    8295                                   2024/11/26 12:15:39            2024/11/26 12:32:40                    90                15698 5%
bkg_anonyme               5gy4fz1nh40pc  415296538 760    8295                                   2024/11/26 12:13:39            2024/11/26 12:27:40                    70                10075 4%

Plan hash value: 3103601244
-----------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                          | Name               | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  |
-----------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                   |                    |      1 |        |  4787 (100)|      0 |00:07:01.97 |     106M|    418K|
|   1 |  MERGE JOIN ANTI                   |                    |      1 |    819 |  1921   (1)|      0 |00:07:01.97 |     106M|    418K|
|*  2 |   TABLE ACCESS BY INDEX ROWID      | G_DOSSIER          |      1 |  19087 |  1917   (1)|  18496 |00:07:01.92 |     106M|    418K|
|*  3 |    INDEX FULL SCAN                 | DOS_REFDOSS        |      1 |    290K|   206   (1)|  18504 |00:06:56.08 |     106M|    403K|
|*  4 |     FILTER                         |                    |   5819K|        |            |  18516 |00:06:31.54 |     105M|    384K|
|   5 |      NESTED LOOPS                  |                    |   5819K|        |            |  19012 |00:06:28.27 |     105M|    384K|
|   6 |       NESTED LOOPS                 |                    |   5819K|      1 |     3   (0)|     12M|00:04:31.42 |      82M|    178K|
|   7 |        NESTED LOOPS                |                    |   5819K|      1 |     2   (0)|     12M|00:03:37.53 |      54M|    170K|
|*  8 |         INDEX RANGE SCAN           | INT_REFDOSS        |   5819K|      4 |     1   (0)|     24M|00:01:11.13 |    8817K|    170K|
|*  9 |         TABLE ACCESS BY INDEX ROWID| V_DOMAINE          |     24M|      1 |     1   (0)|     12M|00:02:12.53 |      46M|      0 |
|* 10 |          INDEX RANGE SCAN          | DOM_TYPABREV       |     24M|      1 |     1   (0)|     23M|00:01:19.87 |      25M|      0 |
|* 11 |        INDEX UNIQUE SCAN           | IND_REFINDIV       |     12M|      1 |     1   (0)|     12M|00:00:43.13 |      27M|   8326 |
|* 12 |       TABLE ACCESS BY INDEX ROWID  | G_INDIVIDU         |     12M|      1 |     1   (0)|  19012 |00:01:48.57 |      23M|    205K|
|* 13 |      INDEX RANGE SCAN              | INT_REFDOSS        |  18640 |      1 |     1   (0)|    124 |00:00:00.10 |   73813 |      0 |
|  14 |     NESTED LOOPS                   |                    |  18516 |        |            |     12 |00:00:00.93 |     354K|    395 |
|  15 |      NESTED LOOPS                  |                    |  18516 |      1 |     3   (0)|  38874 |00:00:00.72 |     286K|    268 |
|  16 |       NESTED LOOPS                 |                    |  18516 |      1 |     2   (0)|  38874 |00:00:00.57 |     190K|    267 |
|* 17 |        INDEX RANGE SCAN            | INT_REFDOSS        |  18516 |      4 |     1   (0)|  60996 |00:00:00.20 |   73842 |    267 |
|* 18 |        TABLE ACCESS BY INDEX ROWID | V_DOMAINE          |  60996 |      1 |     1   (0)|  38874 |00:00:00.34 |     116K|      0 |
|* 19 |         INDEX RANGE SCAN           | DOM_TYPABREV       |  60996 |      1 |     1   (0)|  60951 |00:00:00.20 |   62428 |      0 |
|* 20 |       INDEX UNIQUE SCAN            | IND_REFINDIV       |  38874 |      1 |     1   (0)|  38874 |00:00:00.11 |   96191 |      1 |
|* 21 |      TABLE ACCESS BY INDEX ROWID   | G_INDIVIDU         |  38874 |      1 |     1   (0)|     12 |00:00:00.19 |   67650 |    127 |
|* 22 |   SORT UNIQUE                      |                    |  18496 |  18498 |     4  (50)|  18496 |00:00:00.04 |     214 |      0 |
|* 23 |    INDEX RANGE SCAN                | PK_G_CONNU_EXT_DWH |      1 |  18498 |     2   (0)|  18498 |00:00:00.01 |     214 |      0 |
-----------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   2 - filter("G"."FG_READY_FOR_ANON"='O')
   3 - filter(( IS NOT NULL AND  IS NULL))
   4 - filter( IS NULL)
   8 - access("REFDOSS"=:B1)
   9 - filter("VD"."ABREV5"='X')
  10 - access("VD"."TYPE"='intervenant' AND "T"."REFTYPE"="VD"."ABREV")
       filter("VD"."ABREV" IS NOT NULL)
  11 - access("T"."REFINDIVIDU"="IND"."REFINDIVIDU")
  12 - filter(("IND"."DTANONYM_DT" IS NOT NULL AND "IND"."MORALPHY"='P'))
  13 - access("REFDOSS"=:B1 AND "REFTYPE"='CL')
       filter("REFINDIVIDU"<>'INTFGTIS')
  17 - access("TI"."REFDOSS"=:B1)
  18 - filter("VD"."ABREV5"='X')
  19 - access("VD"."TYPE"='intervenant' AND "TI"."REFTYPE"="VD"."ABREV")
       filter("VD"."ABREV" IS NOT NULL)
  20 - access("TI"."REFINDIVIDU"="IND"."REFINDIVIDU")
  21 - filter(("IND"."MORALPHY"='P' AND "IND"."DTANONYM_DT" IS NULL))
  22 - access("REFERENCE"="G"."REFDOSS")
       filter("REFERENCE"="G"."REFDOSS")
  23 - access("EXTSYSTEM"='bkg_anonym' AND "TABLENAME"='G_DOSSIER')

*/
/********************************OLD Metrics***************************************/

/********************************New SQL*******************************************/

SELECT /*+ leading(g) FULL(G) */
       g.refdoss
  FROM g_dossier g
 WHERE g.fg_ready_for_anon = 'O'
   AND g.refdoss in ( SELECT refdoss
                        FROM t_intervenants t, 
                             g_individu ind, 
                             v_domaine VD
                       WHERE t.refindividu = ind.refindividu
                         AND ind.dtanonym_dt is not NULL
                         AND t.reftype = VD.abrev
                         AND VD.type = 'intervenant'
                         AND VD.abrev5 = 'X'
                         AND ind.moralphy = 'P' )
   AND NOT EXISTS ( SELECT 1
                     FROM T_INTERVENANTS
                    WHERE REFTYPE = 'CL'
                      AND REFDOSS = g.refdoss
                      AND REFINDIVIDU NOT IN ('INTFGTIS') )                      
   AND NOT EXISTS ( SELECT 1
                      FROM t_intervenants ti, 
                           g_individu ind, 
                           v_domaine VD
                     WHERE g.refdoss = ti.refdoss
                       AND ti.refindividu = ind.refindividu
                       AND ind.dtanonym_dt is NULL
                       AND ind.moralphy = 'P'
                       AND ti.reftype = VD.abrev
                       AND VD.type = 'intervenant'
                       AND VD.abrev5 = 'X' )
   AND NOT EXISTS ( SELECT 1
                      FROM G_CONNU_EXT_DWH
                     WHERE EXTSYSTEM = 'bkg_anonym'
                       AND REFERENCE = g.refdoss
                       AND TABLENAME = 'G_DOSSIER' );
/********************************New SQL*******************************************/
/********************************New Metrics***************************************/
/*
Plan hash value: 1163305868
----------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                         | Name               | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  |
----------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                  |                    |      1 |        |   124K(100)|      0 |00:01:29.76 |      12M|    910K|
|   1 |  NESTED LOOPS SEMI                |                    |      1 |      1 |   124K  (4)|      0 |00:01:29.76 |      12M|    910K|
|   2 |   NESTED LOOPS ANTI               |                    |      1 |      1 |   124K  (4)|     57 |00:01:29.76 |      12M|    910K|
|   3 |    NESTED LOOPS ANTI              |                    |      1 |      8 |   124K  (4)|    474 |00:01:29.63 |      12M|    909K|
|   4 |     NESTED LOOPS ANTI             |                    |      1 |    819 |   124K  (4)|    589 |00:01:29.54 |      12M|    909K|
|*  5 |      TABLE ACCESS FULL            | G_DOSSIER          |      1 |  19087 |   124K  (4)|  19087 |00:01:29.39 |      12M|    909K|
|*  6 |      INDEX UNIQUE SCAN            | PK_G_CONNU_EXT_DWH |  19087 |  17704 |     1   (0)|  18498 |00:00:00.13 |   13842 |    214 |
|*  7 |     INDEX RANGE SCAN              | INT_REFDOSS        |    589 |    165K|     1   (0)|    115 |00:00:00.09 |    1769 |    212 |
|   8 |    VIEW PUSHED PREDICATE          | VW_SQ_2            |    474 |      1 |     3   (0)|    417 |00:00:00.13 |    4196 |    380 |
|   9 |     NESTED LOOPS                  |                    |    474 |        |            |    417 |00:00:00.13 |    4196 |    380 |
|  10 |      NESTED LOOPS                 |                    |    474 |      1 |     3   (0)|    484 |00:00:00.07 |    3299 |    163 |
|  11 |       NESTED LOOPS                |                    |    474 |      1 |     2   (0)|    484 |00:00:00.01 |    2326 |      5 |
|* 12 |        INDEX RANGE SCAN           | INT_REFDOSS        |    474 |      4 |     1   (0)|    935 |00:00:00.01 |    1426 |      0 |
|* 13 |        TABLE ACCESS BY INDEX ROWID| V_DOMAINE          |    935 |      1 |     1   (0)|    484 |00:00:00.01 |     900 |      5 |
|* 14 |         INDEX RANGE SCAN          | DOM_TYPABREV       |    935 |      1 |     1   (0)|    935 |00:00:00.01 |      60 |      2 |
|* 15 |       INDEX UNIQUE SCAN           | IND_REFINDIV       |    484 |      1 |     1   (0)|    484 |00:00:00.06 |     973 |    158 |
|* 16 |      TABLE ACCESS BY INDEX ROWID  | G_INDIVIDU         |    484 |      1 |     1   (0)|    417 |00:00:00.06 |     897 |    217 |
|  17 |   VIEW PUSHED PREDICATE           | VW_NSO_1           |     57 |      1 |     3   (0)|      0 |00:00:00.01 |     542 |      0 |
|  18 |    NESTED LOOPS                   |                    |     57 |        |            |      0 |00:00:00.01 |     542 |      0 |
|  19 |     NESTED LOOPS                  |                    |     57 |      1 |     3   (0)|     61 |00:00:00.01 |     424 |      0 |
|  20 |      NESTED LOOPS                 |                    |     57 |      1 |     2   (0)|     61 |00:00:00.01 |     299 |      0 |
|* 21 |       INDEX RANGE SCAN            | INT_REFDOSS        |     57 |      4 |     1   (0)|    118 |00:00:00.01 |     173 |      0 |
|* 22 |       TABLE ACCESS BY INDEX ROWID | V_DOMAINE          |    118 |      1 |     1   (0)|     61 |00:00:00.01 |     126 |      0 |
|* 23 |        INDEX RANGE SCAN           | DOM_TYPABREV       |    118 |      1 |     1   (0)|    118 |00:00:00.01 |       8 |      0 |
|* 24 |      INDEX UNIQUE SCAN            | IND_REFINDIV       |     61 |      1 |     1   (0)|     61 |00:00:00.01 |     125 |      0 |
|* 25 |     TABLE ACCESS BY INDEX ROWID   | G_INDIVIDU         |     61 |      1 |     1   (0)|      0 |00:00:00.01 |     118 |      0 |
----------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   5 - filter("G"."FG_READY_FOR_ANON"='O')
   6 - access("EXTSYSTEM"='bkg_anonym' AND "TABLENAME"='G_DOSSIER' AND "REFERENCE"="G"."REFDOSS")
   7 - access("REFDOSS"="G"."REFDOSS" AND "REFTYPE"='CL')
       filter("REFINDIVIDU"<>'INTFGTIS')
  12 - access("TI"."REFDOSS"="G"."REFDOSS")
  13 - filter("VD"."ABREV5"='X')
  14 - access("VD"."TYPE"='intervenant' AND "TI"."REFTYPE"="VD"."ABREV")
       filter("VD"."ABREV" IS NOT NULL)
  15 - access("TI"."REFINDIVIDU"="IND"."REFINDIVIDU")
  16 - filter(("IND"."MORALPHY"='P' AND "IND"."DTANONYM_DT" IS NULL))
  21 - access("REFDOSS"="G"."REFDOSS")
  22 - filter("VD"."ABREV5"='X')
  23 - access("VD"."TYPE"='intervenant' AND "T"."REFTYPE"="VD"."ABREV")
       filter("VD"."ABREV" IS NOT NULL)
  24 - access("T"."REFINDIVIDU"="IND"."REFINDIVIDU")
  25 - filter(("IND"."DTANONYM_DT" IS NOT NULL AND "IND"."MORALPHY"='P'))

*/
/********************************New Metrics***************************************/

/********************************Index statistics**********************************/

/********************************Other SQLs****************************************/          
/*

*/ 
/********************************Other SQLs****************************************/              
