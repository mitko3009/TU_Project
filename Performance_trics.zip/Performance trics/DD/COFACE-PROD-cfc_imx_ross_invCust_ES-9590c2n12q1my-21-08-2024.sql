/********************************************************************************
*********       E-mail subject: COFADEV-13709
*********             Instance: PROD
*********          Description: 
Problem:
The cfc_imx_ross_invCust_ES interface was running out of TEMP.

Analysis:
After the analyze, we found that the TOP SQL in cfc_imx_ross_invCust_ES was 9590c2n12q1my and it was responsible for 100% of the time.
The problem in this query is that the HASH JOIN of step 9 in the execution plan was with too many rows selected from tables F_ENTREL, F_DETFAC and F_DETFFORMULA, which fills the TEMP. 
The solution that we can propose is to access table t_intervenants invoiced_individual through the refdoss and the refindividu instead only through the refindividu as it was, which 
helps to decrease the number of selected rows.

Suggestion:
Please change the query as it is shown in the New SQL section below.

*********               SQL_ID: 9590c2n12q1my 
*********      Program/Package: 
*********              Request: Dimitare Ivanov
*********               Author: Dimitar Dimitrov
********* Received e-mail date: 21/08/2024
*********      Resolution date: 21/08/2024
*********  Trace old file here: \\epox\specifs\performance\tmp\
*********  Trace new file here:
***********************************************************************************/

/********************************OLD SQL*******************************************/

var BU_REF varchar2(32);
exec :BU_REF := 'INTBUESP';
var BU_FLAG varchar2(32);
exec :BU_FLAG := 'S';
var FLOW_ID number;
exec :FLOW_ID := 2;

SELECT /*+ OPT_PARAM('optimizer_index_cost_adj' 500)*/
       DISTINCT stmt_header.er_contr AS case_ref,
                CASE :bu_ref WHEN 'INTBUESP'
                             THEN nvl(decode(case_data.bu_refindividu,'INTBUESP',substr(case_data.mig_reference, 8),substr(case_data.sp_extref, 8)),case_data.inv_refdoss)
                             WHEN 'INTBUPRT'
                             THEN nvl(decode(case_data.bu_refindividu,'INTBUPRT',substr(case_data.mig_reference, 8),substr(case_data.sp_extref, 8)),case_data.inv_refdoss)
                 END AS case_number,
                decode(invoiced_individual.reftype,'TC',poliza.st01,intercompcustacc_case.ancrefdoss) AS ca_policy_num,
                inv_item_det.df_num AS inv_item_ref,
                to_char(formula.pmtref),
                to_char(inv_item_det.df_monht_bu * (decode(inv_item_det.df_sen, 'C', -1, 1)), 'FM999999999999990.90') AS comiss,
                to_char(inv_item_det.df_monht_bu * (decode(inv_item_det.df_sen, 'C', -1, 1)), 'FM999999999999990.90') AS inv_amt_eur,
                to_char(inv_item_det.df_dat_dt, 'DDMMYYYY') AS trans_date,
                inv_item_det.df_dat AS trans_date_j,
                inv_item_det.df_devise_con AS inv_curr,
                case_data.inv_refdoss,
                case_data.categdoss,
                inv_item_det.df_nom,
                to_char(inv_item_det.df_refinit),
                nvl(to_char(floor(formula.com_rate), 'FM09'), '00'),
                nvl(to_char(mod(formula.com_rate, 1) * 100, 'FM09'), '00'),
                invoiced_individual.refindividu,
                invoiced_individual.reftype,
                stmt_header.er_refext1
  FROM f_entrel stmt_header,
       f_detfac inv_item_det,
       F_DETFFORMULA formula,
       t_intervenants invoiced_individual,
       ( SELECT db_case.refdoss           AS inv_refdoss,
                bu.refindividu            AS bu_refindividu,
                sp.refindividu            AS sp_refindividu,
                db_case.categdoss,
                db_case.ancrefdoss,
                db_case.ext_reference_nu1,
                db_case.mig_reference     AS mig_reference,
                sp.refdossext             AS sp_extref,
                recouv.fg29               AS case_coll_fees
           FROM g_dossier      db_case,
                g_piece        recouv,
                t_intervenants bu,
                t_intervenants sp
          WHERE db_case.categdoss IN ('NOT INSURED', 'INSURED')
            AND recouv.refdoss = db_case.refdoss
            AND recouv.typpiece = 'RECOUVREMENT'
            AND bu.refdoss = db_case.refdoss
            AND bu.reftype = 'BU'
            AND sp.refdoss = db_case.refdoss
            AND sp.reftype = 'SP' ) case_data,
       ( SELECT e.refdoss,
                p.refpiece,
                p.st01,
                ROW_NUMBER() OVER(PARTITION BY e.refdoss ORDER BY refpiece DESC) AS row_num
           FROM g_piece p, t_elements e
          WHERE p.typpiece = 'POLICY CONTRACT'
            AND e.libelle = 'POLICY CONTRACT'
            AND e.typeelem = 'pr'
            AND p.refpiece = e.refelem ) poliza,
       g_dossier intercompcustacc_case
 WHERE 1 = 1
   AND inv_item_det.df_rel = stmt_header.er_num
   AND inv_item_det.df_ann IS NULL
   AND inv_item_det.df_cli = stmt_header.er_cli
   AND formula.df_num(+) = inv_item_det.df_num
   AND formula.df_nom(+) = inv_item_det.df_nom
   AND upper(inv_item_det.df_nom) IN ( SELECT /*+ NO_UNNEST*/
                                              ecran
                                         FROM v_domaine
                                        WHERE type = 'ROSS_SP_PT_PRODUCT_CODE'
                                          AND nbjour = :flow_id
                                          AND nvl(to_char(validfrom_dt, 'j'), stmt_header.er_dat) <= stmt_header.er_dat
                                          AND chemin = :bu_flag )
   AND inv_item_det.df_dos = case_data.inv_refdoss
   AND NOT EXISTS ( SELECT 1
                      FROM g_connu_ext_dwh
                     WHERE reference = inv_item_det.df_num
                       AND extsystem = 'INVCUST_' || :bu_flag )
   AND invoiced_individual.refdoss = case_data.inv_refdoss
   AND invoiced_individual.refindividu = inv_item_det.df_cli
   AND invoiced_individual.reftype IN ('TC', 'CL', 'BU')
   AND (    invoiced_individual.reftype <> 'TC'
         OR case_data.case_coll_fees <> 'C' )
   AND poliza.refdoss(+) = case_data.inv_refdoss
   AND poliza.row_num(+) = 1
   AND intercompcustacc_case.refdoss = stmt_header.er_contr
   AND stmt_header.ER_ISSUER = :bu_ref;
/********************************OLD SQL*******************************************/
/********************************OLD Metrics***************************************/
/*

SAMPLE_TIME               SESSION_ID SESSION_SERIAL# MODULE                                   CLIENT_ID                                TEMP_SPACE_ALLOCATED_MB SQL_ID
------------------------- ---------- --------------- ---------------------------------------- ---------------------------------------- ----------------------- -------------
2024/08/21 00:27:38             1540            6699 cfc_imx_ross_invCust_ES@frprocoi01.cofac                                                           107698 9590c2n12q1my

...
2024/08/21 00:33:39             1540            6699 cfc_imx_ross_invCust_ES@frprocoi01.cofac                                                           129365 9590c2n12q1my
          


MODULE                           SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL              PERC
-------------------------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
cfc_imx_ross_invCust_ES          9590c2n12q1my 4255898082       1540       6699                      2024/08/20 23:57:25  2024/08/21 00:33:39         218                    1 +000000000 00:36:13.266 100%


Plan hash value: 4255898082
-------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                   | Name                    | Rows  | Bytes |TempSpc| Cost (%CPU)| Time     |
-------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                            |                         |       |       |       | 64570 (100)|          |
|   1 |  HASH UNIQUE                                |                         |     1 |   557 |       | 64570   (1)| 00:00:03 |
|   2 |   FILTER                                    |                         |       |       |       |            |          |
|   3 |    NESTED LOOPS OUTER                       |                         |     1 |   557 |       | 64504   (1)| 00:00:03 |
|   4 |     NESTED LOOPS ANTI                       |                         |     1 |   340 |       | 64463   (1)| 00:00:03 |
|   5 |      NESTED LOOPS                           |                         |     1 |   321 |       | 64412   (1)| 00:00:03 |
|   6 |       NESTED LOOPS                          |                         |     1 |   300 |       | 64402   (1)| 00:00:03 |
|   7 |        NESTED LOOPS                         |                         |     1 |   273 |       | 64387   (1)| 00:00:03 |
|   8 |         NESTED LOOPS                        |                         |     1 |   249 |       | 64377   (1)| 00:00:03 |
|   9 |          HASH JOIN                          |                         |     1 |   227 |  2072K| 64362   (1)| 00:00:03 |
|  10 |           HASH JOIN                         |                         | 10380 |  1946K|       | 40209   (1)| 00:00:02 |
|  11 |            HASH JOIN OUTER                  |                         |  9142 |  1499K|       | 34280   (1)| 00:00:02 |
|  12 |             HASH JOIN                       |                         |  8847 |  1235K|       | 28315   (1)| 00:00:02 |
|  13 |              TABLE ACCESS FULL              | F_ENTREL                |  8847 |   518K|       |  5533   (1)| 00:00:01 |
|  14 |              TABLE ACCESS FULL              | F_DETFAC                |   939K|    74M|       | 22780   (1)| 00:00:01 |
|  15 |             TABLE ACCESS FULL               | F_DETFFORMULA           |  1218K|    29M|       |  5962   (1)| 00:00:01 |
|  16 |            INDEX FAST FULL SCAN             | INT_REFDOSS             |   161K|  3775K|       |  5928   (1)| 00:00:01 |
|  17 |           TABLE ACCESS FULL                 | G_DOSSIER               |   205K|  7023K|       | 23595   (1)| 00:00:01 |
|  18 |          TABLE ACCESS BY INDEX ROWID BATCHED| T_INTERVENANTS          |     1 |    22 |       |    15   (0)| 00:00:01 |
|  19 |           INDEX RANGE SCAN                  | INT_REFDOSS             |     1 |       |       |    10   (0)| 00:00:01 |
|  20 |         INDEX RANGE SCAN                    | INT_REFDOSS             |     1 |    24 |       |    10   (0)| 00:00:01 |
|  21 |        TABLE ACCESS BY INDEX ROWID BATCHED  | G_PIECE                 |     1 |    27 |       |    15   (0)| 00:00:01 |
|  22 |         INDEX RANGE SCAN                    | PIE_REFDOSS             |     1 |       |       |    10   (0)| 00:00:01 |
|  23 |       TABLE ACCESS BY INDEX ROWID           | G_DOSSIER               |     1 |    21 |       |    10   (0)| 00:00:01 |
|  24 |        INDEX UNIQUE SCAN                    | DOS_REFDOSS             |     1 |       |       |     5   (0)| 00:00:01 |
|  25 |      INDEX SKIP SCAN                        | PK_G_CONNU_EXT_DWH      |  2132 | 40508 |       |    51   (2)| 00:00:01 |
|  26 |     VIEW PUSHED PREDICATE                   |                         |     1 |   217 |       |    41   (3)| 00:00:01 |
|  27 |      WINDOW SORT                            |                         |     1 |    76 |       |    41   (3)| 00:00:01 |
|  28 |       NESTED LOOPS                          |                         |     1 |    76 |       |    40   (0)| 00:00:01 |
|  29 |        NESTED LOOPS                         |                         |     1 |    76 |       |    40   (0)| 00:00:01 |
|  30 |         TABLE ACCESS BY INDEX ROWID BATCHED | T_ELEMENTS              |     1 |    50 |       |    25   (0)| 00:00:01 |
|  31 |          INDEX RANGE SCAN                   | ELE_DOSS_TYP_ASSOC_LIB  |     1 |       |       |    20   (0)| 00:00:01 |
|  32 |         INDEX RANGE SCAN                    | PIE_REFPIECE            |     1 |       |       |    10   (0)| 00:00:01 |
|  33 |        TABLE ACCESS BY INDEX ROWID          | G_PIECE                 |     1 |    26 |       |    15   (0)| 00:00:01 |
|  34 |    TABLE ACCESS BY INDEX ROWID BATCHED      | V_DOMAINE               |     1 |    26 |       |    65   (0)| 00:00:01 |
|  35 |     INDEX RANGE SCAN                        | V_DOMAINE_TYPE_CODE_IDX |    78 |       |       |    15   (0)| 00:00:01 |
-------------------------------------------------------------------------------------------------------------------------------


*/
/********************************OLD Metrics***************************************/

/********************************New SQL*******************************************/

SELECT /*+ OPT_PARAM('optimizer_index_cost_adj' 500) */
       DISTINCT stmt_header.er_contr AS case_ref,
                CASE :bu_ref WHEN 'INTBUESP'
                             THEN nvl(decode(case_data.bu_refindividu,'INTBUESP',substr(case_data.mig_reference, 8),substr(case_data.sp_extref, 8)),case_data.inv_refdoss)
                             WHEN 'INTBUPRT'
                             THEN nvl(decode(case_data.bu_refindividu,'INTBUPRT',substr(case_data.mig_reference, 8),substr(case_data.sp_extref, 8)),case_data.inv_refdoss)
                 END AS case_number,
                decode(invoiced_individual.reftype,'TC',poliza.st01,intercompcustacc_case.ancrefdoss) AS ca_policy_num,
                inv_item_det.df_num AS inv_item_ref,
                to_char(formula.pmtref),
                to_char(inv_item_det.df_monht_bu * (decode(inv_item_det.df_sen, 'C', -1, 1)), 'FM999999999999990.90') AS comiss,
                to_char(inv_item_det.df_monht_bu * (decode(inv_item_det.df_sen, 'C', -1, 1)), 'FM999999999999990.90') AS inv_amt_eur,
                to_char(inv_item_det.df_dat_dt, 'DDMMYYYY') AS trans_date,
                inv_item_det.df_dat AS trans_date_j,
                inv_item_det.df_devise_con AS inv_curr,
                case_data.inv_refdoss,
                case_data.categdoss,
                inv_item_det.df_nom,
                to_char(inv_item_det.df_refinit),
                nvl(to_char(floor(formula.com_rate), 'FM09'), '00'),
                nvl(to_char(mod(formula.com_rate, 1) * 100, 'FM09'), '00'),
                invoiced_individual.refindividu,
                invoiced_individual.reftype,
                stmt_header.er_refext1
  FROM f_entrel stmt_header,
       f_detfac inv_item_det,
       F_DETFFORMULA formula,
       t_intervenants invoiced_individual,
       ( SELECT db_case.refdoss           AS inv_refdoss,
                bu.refindividu            AS bu_refindividu,
                sp.refindividu            AS sp_refindividu,
                db_case.categdoss,
                db_case.ancrefdoss,
                db_case.ext_reference_nu1,
                db_case.mig_reference     AS mig_reference,
                sp.refdossext             AS sp_extref,
                recouv.fg29               AS case_coll_fees
           FROM g_dossier      db_case,
                g_piece        recouv,
                t_intervenants bu,
                t_intervenants sp
          WHERE db_case.categdoss IN ('NOT INSURED', 'INSURED')
            AND recouv.refdoss = db_case.refdoss
            AND recouv.typpiece = 'RECOUVREMENT'
            AND bu.refdoss = db_case.refdoss
            AND bu.reftype = 'BU'
            AND sp.refdoss = db_case.refdoss
            AND sp.reftype = 'SP' ) case_data,
       ( SELECT e.refdoss,
                p.refpiece,
                p.st01,
                ROW_NUMBER() OVER(PARTITION BY e.refdoss ORDER BY refpiece DESC) AS row_num
           FROM g_piece p, t_elements e
          WHERE p.typpiece = 'POLICY CONTRACT'
            AND e.libelle = 'POLICY CONTRACT'
            AND e.typeelem = 'pr'
            AND p.refpiece = e.refelem ) poliza,
       g_dossier intercompcustacc_case
 WHERE 1 = 1
   AND inv_item_det.df_rel = stmt_header.er_num
   AND inv_item_det.df_ann IS NULL
   AND inv_item_det.df_cli = stmt_header.er_cli
   AND formula.df_num(+) = inv_item_det.df_num
   AND formula.df_nom(+) = inv_item_det.df_nom
   AND upper(inv_item_det.df_nom) IN ( SELECT /*+ NO_UNNEST*/
                                              ecran
                                         FROM v_domaine
                                        WHERE type = 'ROSS_SP_PT_PRODUCT_CODE'
                                          AND nbjour = :flow_id
                                          AND nvl(to_char(validfrom_dt, 'j'), stmt_header.er_dat) <= stmt_header.er_dat
                                          AND chemin = :bu_flag )
   AND inv_item_det.df_dos = case_data.inv_refdoss
   AND NOT EXISTS ( SELECT 1
                      FROM g_connu_ext_dwh
                     WHERE reference = inv_item_det.df_num
                       AND extsystem = 'INVCUST_' || :bu_flag )
   AND invoiced_individual.refdoss = inv_item_det.df_dos
   AND invoiced_individual.refindividu = inv_item_det.df_cli
   AND invoiced_individual.reftype IN ('TC', 'CL', 'BU')
   AND (    invoiced_individual.reftype <> 'TC'
         OR case_data.case_coll_fees <> 'C' )
   AND poliza.refdoss(+) = case_data.inv_refdoss
   AND poliza.row_num(+) = 1
   AND intercompcustacc_case.refdoss = stmt_header.er_contr
   AND stmt_header.ER_ISSUER = :bu_ref;
/********************************New SQL*******************************************/
/********************************New Metrics***************************************/
/*
Plan hash value: 1262024545
--------------------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                    | Name                    | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  |
--------------------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                             |                         |      1 |        |   103K(100)|    168 |00:00:51.54 |    1845K|    445K|
|   1 |  HASH UNIQUE                                 |                         |      1 |      1 |   103K  (1)|    168 |00:00:51.54 |    1845K|    445K|
|*  2 |   FILTER                                     |                         |      1 |        |            |    168 |00:00:51.54 |    1845K|    445K|
|   3 |    NESTED LOOPS                              |                         |      1 |    231 | 96038   (1)|    393 |00:00:50.12 |    1724K|    444K|
|   4 |     NESTED LOOPS                             |                         |      1 |    231 | 96038   (1)|    393 |00:00:49.95 |    1723K|    444K|
|   5 |      NESTED LOOPS OUTER                      |                         |      1 |    223 | 92693   (1)|    395 |00:00:49.91 |    1722K|    444K|
|   6 |       NESTED LOOPS                           |                         |      1 |    223 | 83548   (1)|    395 |00:00:49.23 |    1719K|    443K|
|   7 |        NESTED LOOPS                          |                         |      1 |    223 | 81317   (1)|    395 |00:00:49.19 |    1718K|    443K|
|*  8 |         HASH JOIN ANTI                       |                         |      1 |    316 | 76576   (1)|  27850 |00:00:44.44 |    1595K|    435K|
|   9 |          NESTED LOOPS OUTER                  |                         |      1 |    332 | 72993   (1)|  72716 |00:00:43.64 |    1573K|    421K|
|* 10 |           HASH JOIN                          |                         |      1 |    322 | 68162   (1)|  71824 |00:00:38.58 |    1385K|    405K|
|* 11 |            HASH JOIN                         |                         |      1 |   1875 | 62233   (1)|  71894 |00:00:37.23 |    1362K|    381K|
|* 12 |             TABLE ACCESS FULL                | F_ENTREL                |      1 |   8847 |  5533   (1)|  49983 |00:00:00.26 |   20427 |  20424 |
|* 13 |             HASH JOIN                        |                         |      1 |    199K| 56699   (1)|    995K|00:00:36.78 |    1341K|    361K|
|* 14 |              HASH JOIN                       |                         |      1 |  53696 | 29515   (1)|    471K|00:00:34.64 |    1257K|    277K|
|* 15 |               INDEX FAST FULL SCAN           | INT_REFDOSS             |      1 |  53697 |  5920   (1)|    616K|00:00:00.86 |   23635 |  23515 |
|* 16 |               TABLE ACCESS FULL              | G_DOSSIER               |      1 |    205K| 23595   (1)|    472K|00:00:33.16 |    1233K|    253K|
|* 17 |              TABLE ACCESS FULL               | F_DETFAC                |      1 |    939K| 22780   (1)|   1006K|00:00:01.48 |   84299 |  84176 |
|* 18 |            INDEX FAST FULL SCAN              | INT_REFDOSS             |      1 |    161K|  5928   (1)|   1570K|00:00:00.92 |   23636 |  23517 |
|  19 |           TABLE ACCESS BY INDEX ROWID BATCHED| F_DETFFORMULA           |  71824 |      1 |    15   (0)|  68594 |00:00:05.03 |     187K|  16658 |
|* 20 |            INDEX RANGE SCAN                  | FDFF_F_DETFAC_FK        |  71824 |      1 |    10   (0)|  68594 |00:00:01.51 |     136K|   4817 |
|* 21 |          INDEX FAST FULL SCAN                | PK_G_CONNU_EXT_DWH      |      1 |  44761 |  3583   (1)|  47221 |00:00:00.65 |   21779 |  13969 |
|* 22 |         TABLE ACCESS BY INDEX ROWID BATCHED  | G_PIECE                 |  27850 |      1 |    15   (0)|    395 |00:00:04.75 |     123K|   7175 |
|* 23 |          INDEX RANGE SCAN                    | PIE_REFDOSS             |  27850 |      1 |    10   (0)|  27850 |00:00:01.49 |   56833 |   2531 |
|  24 |        TABLE ACCESS BY INDEX ROWID           | G_DOSSIER               |    395 |      1 |    10   (0)|    395 |00:00:00.03 |    1181 |    147 |
|* 25 |         INDEX UNIQUE SCAN                    | DOS_REFDOSS             |    395 |      1 |     5   (0)|    395 |00:00:00.01 |     792 |     18 |
|* 26 |       VIEW PUSHED PREDICATE                  |                         |    395 |      1 |    41   (3)|    338 |00:00:00.68 |    3050 |   1055 |
|  27 |        WINDOW SORT                           |                         |    395 |      1 |    41   (3)|    338 |00:00:00.68 |    3050 |   1055 |
|  28 |         NESTED LOOPS                         |                         |    395 |      1 |    40   (0)|    338 |00:00:00.67 |    3050 |   1055 |
|  29 |          NESTED LOOPS                        |                         |    395 |      1 |    40   (0)|    338 |00:00:00.53 |    2256 |    831 |
|  30 |           TABLE ACCESS BY INDEX ROWID BATCHED| T_ELEMENTS              |    395 |      1 |    25   (0)|    338 |00:00:00.41 |    1576 |    621 |
|* 31 |            INDEX RANGE SCAN                  | ELE_DOSS_TYP_ASSOC_LIB  |    395 |      1 |    20   (0)|    338 |00:00:00.37 |    1241 |    490 |
|* 32 |           INDEX RANGE SCAN                   | PIE_REFPIECE            |    338 |      1 |    10   (0)|    338 |00:00:00.12 |     680 |    210 |
|* 33 |          TABLE ACCESS BY INDEX ROWID         | G_PIECE                 |    338 |      1 |    15   (0)|    338 |00:00:00.14 |     794 |    224 |
|* 34 |      INDEX RANGE SCAN                        | INT_REFDOSS             |    395 |      1 |    10   (0)|    393 |00:00:00.04 |     792 |    179 |
|  35 |     TABLE ACCESS BY INDEX ROWID              | T_INTERVENANTS          |    393 |      1 |    15   (0)|    393 |00:00:00.17 |     389 |    244 |
|* 36 |    TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE               |    230 |      1 |    65   (0)|     52 |00:00:01.42 |     121K|    536 |
|* 37 |     INDEX RANGE SCAN                         | V_DOMAINE_TYPE_CODE_IDX |    230 |     78 |    15   (0)|   2028K|00:00:00.25 |   19817 |     94 |
--------------------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   2 - filter( IS NOT NULL)
   8 - access("REFERENCE"="INV_ITEM_DET"."DF_NUM")
  10 - access("INVOICED_INDIVIDUAL"."REFDOSS"="INV_ITEM_DET"."DF_DOS" AND "INVOICED_INDIVIDUAL"."REFINDIVIDU"="INV_ITEM_DET"."DF_CLI")
  11 - access("INV_ITEM_DET"."DF_REL"="STMT_HEADER"."ER_NUM" AND "INV_ITEM_DET"."DF_CLI"="STMT_HEADER"."ER_CLI")
  12 - filter("STMT_HEADER"."ER_ISSUER"=:BU_REF)
  13 - access("INV_ITEM_DET"."DF_DOS"="DB_CASE"."REFDOSS")
  14 - access("BU"."REFDOSS"="DB_CASE"."REFDOSS")
  15 - filter("BU"."REFTYPE"='BU')
  16 - filter(("DB_CASE"."CATEGDOSS"='INSURED' OR "DB_CASE"."CATEGDOSS"='NOT INSURED'))
  17 - filter(("INV_ITEM_DET"."DF_REL" IS NOT NULL AND "INV_ITEM_DET"."DF_ANN" IS NULL))
  18 - filter(("INVOICED_INDIVIDUAL"."REFTYPE"='BU' OR "INVOICED_INDIVIDUAL"."REFTYPE"='CL' OR "INVOICED_INDIVIDUAL"."REFTYPE"='TC'))
  20 - access("FORMULA"."DF_NUM"="INV_ITEM_DET"."DF_NUM" AND "FORMULA"."DF_NOM"="INV_ITEM_DET"."DF_NOM")
  21 - filter("EXTSYSTEM"='INVCUST_'||:BU_FLAG)
  22 - filter(("INVOICED_INDIVIDUAL"."REFTYPE"<>'TC' OR "RECOUV"."FG29"<>'C'))
  23 - access("RECOUV"."REFDOSS"="DB_CASE"."REFDOSS" AND "RECOUV"."TYPPIECE"='RECOUVREMENT')
       filter("RECOUV"."REFDOSS" IS NOT NULL)
  25 - access("INTERCOMPCUSTACC_CASE"."REFDOSS"="STMT_HEADER"."ER_CONTR")
  26 - filter("POLIZA"."ROW_NUM"=1)
  31 - access("E"."REFDOSS"="DB_CASE"."REFDOSS" AND "E"."TYPEELEM"='pr' AND "E"."LIBELLE"='POLICY CONTRACT')
       filter("E"."LIBELLE"='POLICY CONTRACT')
  32 - access("P"."REFPIECE"="E"."REFELEM")
  33 - filter("P"."TYPPIECE"='POLICY CONTRACT')
  34 - access("SP"."REFDOSS"="DB_CASE"."REFDOSS" AND "SP"."REFTYPE"='SP')
  36 - filter(("ECRAN"=:B1 AND "CHEMIN"=:BU_FLAG AND "NBJOUR"=:FLOW_ID AND
              TO_NUMBER(NVL(TO_CHAR(INTERNAL_FUNCTION("VALIDFROM_DT"),'j'),TO_CHAR(:B2)))<=:B3))
  37 - access("TYPE"='ROSS_SP_PT_PRODUCT_CODE')

*/
/********************************New Metrics***************************************/

/********************************Index statistics**********************************/

/********************************Other SQLs****************************************/          
/*

*/ 
/********************************Other SQLs****************************************/              
