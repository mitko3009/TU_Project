
################### VOBE m58 backup #################

root@v158842 # dbspicao -m58 -r1


                    Report For Database RWOSPWPS

                      Mon May 27 21:15:30 2019

                    Metric ArchiveFreeSpcPct (0058)

  Archive Directory /oracle/oraarch/RWOSPWPS
  FILESYSTEM           KBYTES      USED       AVAIL     %USED   MOUNTED ON
  ---------------------------------- ---------------------------------------------------------
  /rwospwr/oraarch     4707264652432637952  4637335425680146432 4707264535931650048 1      /rwospwr/oraarch

  Archive Directory /oracle/oraarchstb/RWOSPWPS
  FILESYSTEM           KBYTES      USED       AVAIL     %USED   MOUNTED ON
  ---------------------------------- ---------------------------------------------------------
  /rwospwr/orabck      4720775606470443008  4718292325099372544 4713234567585071104 69     /rwospwr/orabck


Archive Directory:  Archive directory path
FILESYSTEM:         Filesystem Name
KBYTES:             Size of Filesystem in K bytes
USED:               K Bytes Used
AVAIL:              K Bytes Avail
%USED:              Percent Used
MOUNTED ON:         Directory Mount Point

root@v158842 # cd /oracle


root@v158842 # ls -la
total 117
drwxrwxr-x  15 oracle   oinstall      17 Nov 19  2018 .
drwxr-xr-x  39 root     root        1038 May 27 21:15 ..
drwxr-xr-x   5 oracle   oinstall      14 Oct 11  2016 11gUpgrade
drwxr-xr-x  18 oracle   oinstall      27 Oct 11  2016 admin
drwxr-xr-x   5 oracle   oinstall       5 Oct  2  2013 cfgtoollogs
drwxr-xr-x   2 oracle   oinstall       2 Nov 19  2018 checkpoints
drwxrwxr-x  11 oracle   oinstall      11 Jun 28  2012 diag
drwxr-xr-x   7 oracle   oinstall       7 May 22  2014 flash_recovery_area
drwxrwx---   7 oracle   oinstall       9 Dec  4 12:09 oraInventory
drwxr-xr-x   2 oracle   oinstall      21 Jan 20  2016 oraarch
drwxr-xr-x   2 oracle   oinstall      11 Jan 20  2016 oraarchstb
drwxr-xr-x   2 oracle   oinstall      19 Oct  2  2015 orabck
drwxr-xr-x  14 oracle   oinstall      21 Jan 20  2016 oradata
lrwxrwxrwx   1 oracle   oinstall       6 Apr 19  2011 orasw -> /orasw
drwxr-xr-x   8 oracle   oinstall       9 Dec  4 12:09 product
-rw-r--r--   1 root     root           0 Aug 20  2017 redirection
drwxr-xr-x   2 oracle   oinstall       9 Jun 14  2016 startstop

root@v158842 # cd oraarchstb                                               ###### Tazi dir ni e po ticket-a) #######

root@v158842 # ls -al                                               ######### vijdame kym koi soft link ni wodi bazata #######
total 15
drwxr-xr-x   2 oracle   oinstall      11 Jan 20  2016 .
drwxrwxr-x  15 oracle   oinstall      17 Nov 19  2018 ..
lrwxrwxrwx   1 oracle   oinstall      33 Oct 16  2014 DHO2E_PS -> /dho2-etio-repl/orabck/oraarchstb
lrwxrwxrwx   1 oracle   oinstall      37 Dec  6  2011 DISET_PS -> /discimus-etio-repl/orabck/oraarchstb
lrwxrwxrwx   1 oracle   oinstall      27 Jul 16  2012 DOMINOPS -> /dominops/orabck/oraarchstb
lrwxrwxrwx   1 oracle   oinstall      40 Apr 14  2014 DVNCE_PS -> /davinci-etio-repl/ufs/orabck/oraarchstb
lrwxrwxrwx   1 oracle   oinstall      36 Mar 20  2012 DVNCE_PS.old -> /davinci-etio-repl/orabck/oraarchstb
lrwxrwxrwx   1 oracle   oinstall      27 Oct  1  2015 EDELTAPS -> /edeltaps/orabck/oraarchstb
lrwxrwxrwx   1 oracle   oinstall      25 Oct  8  2012 ESF_PS -> /esf_ps/orabck/oraarchstb
lrwxrwxrwx   1 oracle   oinstall      26 Feb 21  2013 RWOSPWPS -> /rwospwr/orabck/oraarchstb
lrwxrwxrwx   1 oracle   oinstall      31 Jan 20  2016 TESTPS -> /vsb-p/orabck/TESTPS/oraarchstb

root@v158842 # cd RWOSPWPS

root@v158842 # pwd
/oracle/oraarchstb/RWOSPWPS

root@v158842 # ls -la
total 951961
drwxr-xr-x   2 oracle   oinstall      21 May 27 20:33 .
drwxr-xr-x  11 oracle   oinstall      12 Dec 30  2015 ..
-rw-r-----   1 oracle   oinstall 41435136 May 26 18:01 RWOSPWPS_1_36741_807795654.arc
-rw-r-----   1 oracle   oinstall 10797056 May 26 20:16 RWOSPWPS_1_36742_807795654.arc
-rw-r-----   1 oracle   oinstall    5632 May 26 20:16 RWOSPWPS_1_36743_807795654.arc
-rw-r-----   1 oracle   oinstall 42295808 May 27 01:20 RWOSPWPS_1_36744_807795654.arc
-rw-r-----   1 oracle   oinstall 40040960 May 27 02:00 RWOSPWPS_1_36745_807795654.arc
-rw-r-----   1 oracle   oinstall 24109568 May 27 06:15 RWOSPWPS_1_36746_807795654.arc
-rw-r-----   1 oracle   oinstall   19456 May 27 06:15 RWOSPWPS_1_36747_807795654.arc
-rw-r-----   1 oracle   oinstall 40047104 May 27 09:00 RWOSPWPS_1_36748_807795654.arc
-rw-r-----   1 oracle   oinstall 39272448 May 27 09:48 RWOSPWPS_1_36749_807795654.arc
-rw-r-----   1 oracle   oinstall 39265280 May 27 10:09 RWOSPWPS_1_36750_807795654.arc
-rw-r-----   1 oracle   oinstall 38684160 May 27 10:52 RWOSPWPS_1_36751_807795654.arc
-rw-r-----   1 oracle   oinstall 38739968 May 27 12:04 RWOSPWPS_1_36752_807795654.arc
-rw-r-----   1 oracle   oinstall 5513728 May 27 12:15 RWOSPWPS_1_36753_807795654.arc
-rw-r-----   1 oracle   oinstall    9728 May 27 12:15 RWOSPWPS_1_36754_807795654.arc
-rw-r-----   1 oracle   oinstall 38660096 May 27 14:00 RWOSPWPS_1_36755_807795654.arc
-rw-r-----   1 oracle   oinstall 38707200 May 27 15:28 RWOSPWPS_1_36756_807795654.arc
-rw-r-----   1 oracle   oinstall 38739456 May 27 19:07 RWOSPWPS_1_36757_807795654.arc
-rw-r-----   1 oracle   oinstall 9576448 May 27 20:33 RWOSPWPS_1_36758_807795654.arc
-rw-r-----   1 oracle   oinstall   26624 May 27 20:33 RWOSPWPS_1_36759_807795654.arc


root@v158842 # df -h .
Filesystem             size   used  avail capacity  Mounted on
/rwospwr/orabck         39G    27G    12G    69%    /rwospwr/orabck


root@v158842 # cd /rwospwr/orabck

root@v158842 # ls -la                                                     ##### Na VOBE backup-ite sedqt vinagi v RMAN ######
total 23282
drwxr-xr-x  11 oracle   oinstall      12 Dec 30  2015 .
drwxr-xr-x   7 root     root           7 Feb 11  2013 ..
-rw-r-----   1 oracle   oinstall 11600384 May 27 21:17 block_change_tracking.bct
drwxr-xr-x   2 oracle   oinstall       3 Mar  2  2013 bu_ctrl
drwxr-xr-x   6 oracle   oinstall       6 Mar  2  2013 coldbu
drwxr-xr-x   2 oracle   oinstall       2 Feb 21  2013 exp
drwxr-xr-x   2 oracle   oinstall       2 Feb 21  2013 flash
drwxr-xr-x   2 oracle   oinstall    2199 May 27 20:30 log
drwxr-xr-x   2 oracle   oinstall      21 May 27 20:33 oraarchstb
drwxr-xr-x   2 oracle   oinstall     132 Mar  2  2013 oraarchstb_old
drwxr-xr-x   2 oracle   oinstall     115 May 27 20:50 rman
drwxr-xr-x   2 oracle   oinstall      85 Mar  2  2013 rman_old
root@v158842 # cd rman

find . -mtime +0 -exec ls -la {} \;                                 ########### vivdame koi sa naj starite i triem nai-stariq "LEVEL 0" i ot nego do pyrwiq "LEVEL 1" ###########
