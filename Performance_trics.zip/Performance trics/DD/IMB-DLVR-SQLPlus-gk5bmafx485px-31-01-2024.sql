/********************************************************************************
*********       E-mail subject: IMB-3860
*********             Instance: DLVR
*********          Description: 
Problem:
Script $H/BD/reprise/reprise_fill_group_of_same_limits_id.sql was slow on instance DLVR.

Analysis:
We found two TOP SQLs (gk5bmafx485px and a74ansnv3phva) which were responsible for almost 100% of the time.
The problem in both SQLs is that they don't use the appropriate indexes and make bad execution plans which leads to selecting 
a lot of data unnecessary and slow execution.

Suggestion:
Please change the SQLs as it is shown in the New SQL section below.

*********               SQL_ID: gk5bmafx485px, a74ansnv3phva
*********      Program/Package: SQL*Plus 
*********              Request: Dobromir Boyadzhiev 
*********               Author: Dimitar Dimitrov
********* Received e-mail date: 30/01/2024
*********      Resolution date: 31/01/2024
*********  Trace old file here: \\epox\specifs\performance\tmp\
*********  Trace new file here:
***********************************************************************************/

/********************************OLD SQL*******************************************/

-- gk5bmafx485px

var B1 VARCHAR2(32);
exec :B1 := 'A0003CNN';
var B2 VARCHAR2(32);
exec :B2 := 'INT00000';
var B3 VARCHAR2(32);
exec :B3 := 'FIN';
var B4 VARCHAR2(32);
exec :B4 := 'A600DPC0';

SELECT GPIHEURE
  FROM G_PIECE P
WHERE TYPPIECE = 'PARAM_LIMITE'
   AND REFEXT = 'IND'
   AND GPIBUREAU = :B4
   AND GPIDEPOT = :B3
   AND (GPITYPTRIB = :B2 OR (GPITYPTRIB IS NULL AND :B2 IS NULL))
   AND GPIROLE = :B1
   AND GPIHEURE IS NOT NULL
   AND ROWNUM = 1;


-- a74ansnv3phva

var B1 VARCHAR2(32);
exec :B1 := 'A709TTID';
var B2 VARCHAR2(32);
exec :B2 := 'A0003CEB';
var B3 VARCHAR2(32);
exec :B3 := 'A600DPC0';
var B4 VARCHAR2(32);
exec :B4 := 'DGCF';

SELECT GPIRESSORT
  FROM G_PIECE
WHERE TYPPIECE = 'REQUEST_LIMITE'
   AND TYPEDOC = :B4
   AND GPIRESSORT IS NOT NULL
   AND GPIDEPOT = :B3
   AND ST41 = :B2
   AND REFPIECE != :B1
   AND ROWNUM = 1;   

/********************************OLD SQL*******************************************/
/********************************OLD Metrics***************************************/
/*
MODULE                           SQL_ID         PLAN_HASH     SID SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- ------------- ---------- ------- ------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
SQL*Plus                                                       58    6866 cell single block ph 2024/01/29 17:19:17  2024/01/30 11:10:06        5365                 4946 +000000000 17:50:49.281 86%
SQL*Plus                                                       58    6866 ON CPU               2024/01/29 17:18:46  2024/01/30 11:07:42         870                31215 +000000000 17:48:56.193 14%
SQL*Plus                                                       58    6866 cell single block re 2024/01/29 18:01:19  2024/01/30 10:42:35          34                 1272 +000000000 16:41:15.583 1%


MODULE                           SQL_ID         PLAN_HASH     SID SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- ------------- ---------- ------- ------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
SQL*Plus                         gk5bmafx485px 4036935372      58    6866                      2024/01/29 17:20:39  2024/01/30 11:10:06        4127                 1353 +000000000 17:49:26.977 66%
SQL*Plus                         a74ansnv3phva 2615056867      58    6866                      2024/01/29 17:34:39  2024/01/30 11:09:35        2063                 1352 +000000000 17:34:55.808 33%
SQL*Plus                         5y0bttu76mnuk  648733644      58    6866                      2024/01/29 17:22:01  2024/01/29 17:27:49          32                 3965 +000000000 00:05:48.543 1%
SQL*Plus                         8z277a8h92pn9 4036935372      58    6866                      2024/01/29 17:20:29  2024/01/29 17:32:57          26                 7289 +000000000 00:12:28.288 0%
SQL*Plus                         1fcvvw738n1h6 1267079415      58    6866                      2024/01/29 17:18:46  2024/01/29 17:20:19           9                    1 +000000000 00:01:32.552 0%
SQL*Plus                         cbwu3hu8t0ycg  322569057      58    6866 ON CPU               2024/01/29 17:26:17  2024/01/29 17:33:07           4                 4869 +000000000 00:06:49.983 0%
SQL*Plus                         8qj29wmjn2pqw          0      58    6866 ON CPU               2024/01/29 17:23:33  2024/01/29 23:15:46           3                    1 +000000000 05:52:13.120 0%
SQL*Plus                         9fyzycp9a53r3 4145146419      58    6866 ON CPU               2024/01/29 17:19:06  2024/01/29 17:23:02           2                    1 +000000000 00:03:55.904 0%
SQL*Plus                         0v79vrk7t8sj7 3664023496      58    6866 cell single block ph 2024/01/29 17:30:54  2024/01/29 17:30:54           1                    1 +000000000 00:00:00.000 0%
SQL*Plus                         gapbxnuv5rcd2 4060975977      58    6866 cell single block ph 2024/01/29 17:21:51  2024/01/29 17:21:51           1                    1 +000000000 00:00:00.000 0%
SQL*Plus                         5s13apmbavtfm 1388734953      58    6866 ON CPU               2024/01/29 17:30:13  2024/01/29 17:30:13           1                    1 +000000000 00:00:00.000 0%


-- gk5bmafx485px

INSTANCE_NUMBER SQL_ID            ELAPSED MAX_WAIT_ON     PC_OF  WAIT_TIME            GETS      READS       ROWS  ELAP/EXEC       GETS/EXEC READS/EXEC  ROWS/EXEC       EXEC PLAN_HASH_VALUE
--------------- ------------- ----------- --------------- ----- ---------- --------------- ---------- ---------- ---------- --------------- ---------- ---------- ---------- ---------------
              1 gk5bmafx485px      278279 IO              78%   322192.878      4217001830  793739041          0      63.07          955803  179904.59          0       4412      4036935372

SQL_ID        SQL_PLAN_HASH_VALUE SQL_PLAN_LINE_ID SQL_PLAN_OPERATION             SQL_PLAN_OPTIONS                   ACTIVE
------------- ------------------- ---------------- ------------------------------ ------------------------------ ----------
gk5bmafx485px          4036935372                2 TABLE ACCESS                   BY INDEX ROWID BATCHED               4140
gk5bmafx485px          4036935372                3 INDEX                          RANGE SCAN                             85

Plan hash value: 4036935372
----------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                            | Name      | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  |
----------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                     |           |      1 |        |     5 (100)|      0 |00:00:51.23 |     955K|  56707 |
|*  1 |  COUNT STOPKEY                       |           |      1 |        |            |      0 |00:00:51.23 |     955K|  56707 |
|*  2 |   TABLE ACCESS BY INDEX ROWID BATCHED| G_PIECE   |      1 |      1 |     5   (0)|      0 |00:00:51.23 |     955K|  56707 |
|*  3 |    INDEX RANGE SCAN                  | PIE_DOUBL |      1 |      3 |     3   (0)|    988K|00:00:01.09 |    3311 |    915 |
----------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   1 - filter(ROWNUM=1)
   2 - filter(("GPIBUREAU"=:B4 AND "GPIROLE"=:B1 AND "GPIDEPOT"=:B3 AND "GPIHEURE" IS NOT NULL AND
              "TYPPIECE"='PARAM_LIMITE' AND ("GPITYPTRIB"=:B2 OR (:B2 IS NULL AND "GPITYPTRIB" IS NULL))))
   3 - access("REFEXT"='IND')


-- a74ansnv3phva

INSTANCE_NUMBER SQL_ID            ELAPSED MAX_WAIT_ON     PC_OF  WAIT_TIME            GETS      READS       ROWS  ELAP/EXEC       GETS/EXEC READS/EXEC  ROWS/EXEC       EXEC PLAN_HASH_VALUE
--------------- ------------- ----------- --------------- ----- ---------- --------------- ---------- ---------- ---------- --------------- ---------- ---------- ---------- ---------------
              1 a74ansnv3phva       56723 IO              78%   65540.0134      1039226973  175806506       2792       7.87          144277    24407.4        .39       7203      2615056867


SQL_ID        SQL_PLAN_HASH_VALUE SQL_PLAN_LINE_ID SQL_PLAN_OPERATION             SQL_PLAN_OPTIONS                   ACTIVE
------------- ------------------- ---------------- ------------------------------ ------------------------------ ----------
a74ansnv3phva          2615056867                2 TABLE ACCESS                   BY INDEX ROWID BATCHED               2080
a74ansnv3phva          2615056867                3 INDEX                          RANGE SCAN                             16

Plan hash value: 2615056867
-------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                            | Name      | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers |
-------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                     |           |      1 |        |    39 (100)|      0 |00:00:00.58 |     471K|
|*  1 |  COUNT STOPKEY                       |           |      1 |        |            |      0 |00:00:00.58 |     471K|
|*  2 |   TABLE ACCESS BY INDEX ROWID BATCHED| G_PIECE   |      1 |      1 |    39   (0)|      0 |00:00:00.58 |     471K|
|*  3 |    INDEX RANGE SCAN                  | GP_GPIDEP |      1 |     69 |     3   (0)|    172K|00:00:00.03 |     665 |
-------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   1 - filter(ROWNUM=1)
   2 - filter(("GPIRESSORT" IS NOT NULL AND "ST41"=:B2 AND "TYPEDOC"=:B4 AND "TYPPIECE"='REQUEST_LIMITE' AND
              "REFPIECE"<>:B1))
   3 - access("GPIDEPOT"=:B3)

*/
/********************************OLD Metrics***************************************/

/********************************New SQL*******************************************/
-- gk5bmafx485px

SELECT /*+ index(P G_PIECE$ID_VENTE ) */
       GPIHEURE
  FROM G_PIECE P
WHERE TYPPIECE = 'PARAM_LIMITE'
   AND REFEXT = 'IND'
   AND GPIBUREAU = :B4
   AND GPIDEPOT = :B3
   AND (GPITYPTRIB = :B2 OR (GPITYPTRIB IS NULL AND :B2 IS NULL))
   AND GPIROLE = :B1
   AND GPIHEURE IS NOT NULL
   AND ROWNUM = 1;


-- a74ansnv3phva

SELECT /*+ leading(G_PIECE PIE_ST41_FUNC_IDX) */
       GPIRESSORT
  FROM G_PIECE
WHERE TYPPIECE = 'REQUEST_LIMITE'
   AND TYPEDOC = :B4
   AND GPIRESSORT IS NOT NULL
   AND GPIDEPOT || '' = :B3
   AND NVL("ST41",NULL) = :B2
   AND REFPIECE != :B1
   AND ROWNUM = 1;  
/********************************New SQL*******************************************/
/********************************New Metrics***************************************/
/*
-- gk5bmafx485px

Plan hash value: 2801807227
-----------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                            | Name             | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  |
-----------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                     |                  |      1 |        |     5 (100)|      0 |00:00:00.10 |    1131 |    188 |
|*  1 |  COUNT STOPKEY                       |                  |      1 |        |            |      0 |00:00:00.10 |    1131 |    188 |
|*  2 |   TABLE ACCESS BY INDEX ROWID BATCHED| G_PIECE          |      1 |      1 |     5   (0)|      0 |00:00:00.10 |    1131 |    188 |
|*  3 |    INDEX RANGE SCAN                  | G_PIECE$ID_VENTE |      1 |      3 |     3   (0)|   1126 |00:00:00.03 |       9 |      9 |
-----------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   1 - filter(ROWNUM=1)
   2 - filter(("REFEXT"='IND' AND "GPIBUREAU"=:B4 AND "GPIDEPOT"=:B3 AND "GPIHEURE" IS NOT NULL AND ("GPITYPTRIB"=:B2 OR (:B2 IS
              NULL AND "GPITYPTRIB" IS NULL))))
   3 - access("GPIROLE"=:B1 AND "TYPPIECE"='PARAM_LIMITE')


-- a74ansnv3phva

Plan hash value: 2339686929
------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                            | Name              | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  |
------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                     |                   |      1 |        |    43 (100)|      0 |00:00:00.01 |     292 |      9 |
|*  1 |  COUNT STOPKEY                       |                   |      1 |        |            |      0 |00:00:00.01 |     292 |      9 |
|*  2 |   TABLE ACCESS BY INDEX ROWID BATCHED| G_PIECE           |      1 |      1 |    43   (0)|      0 |00:00:00.01 |     292 |      9 |
|*  3 |    INDEX RANGE SCAN                  | PIE_ST41_FUNC_IDX |      1 |     43 |     3   (0)|    288 |00:00:00.01 |       4 |      0 |
------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   1 - filter(ROWNUM=1)
   2 - filter(("GPIRESSORT" IS NOT NULL AND "TYPEDOC"=:B4 AND "TYPPIECE"='REQUEST_LIMITE' AND "GPIDEPOT"||''=:B3 AND
              "REFPIECE"<>:B1))
   3 - access("G_PIECE"."SYS_NC00791$"=:B2)
*/
/********************************New Metrics***************************************/

/********************************Index statistics**********************************/

/********************************Other SQLs****************************************/          
/*

*/ 
/********************************Other SQLs****************************************/              
