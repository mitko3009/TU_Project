========================================================================================
========================================================================================

UC4_BUR: TSM Event: Job: 'HA ORAUNIXSA1 Backup PSI1D_SL04999' failed with RC=1. Message: UC4 RunID 1652008493, ---:RMAN-03002: failure of show command at 08/14/2019 20:24:27 
RMAN-06004: ORACLE error from recovery catalog database: RMAN-20001: target database not found in recovery catalog Instance: PSI1D Date: 2019-08-14 Time: 20:24:32

#####  Когато Rman узъра не може да се кънектне,не разпознава recovery catalog database #######

=========================================================================================

cd /tsm
ls -la

drwxr-xr-x  6 root   root        4096 Mar 21  2016 .
drwxr-xr-x 26 root   root       12288 Aug 11 17:36 ..
drwxrwxr-x  5 oracle dba         4096 Apr 12 16:19 PSI1D
drwxrwxr-x  5 oracle dba         4096 Apr 12 16:24 PSI1T
-rwxr-xr-x  1 oracle oinstall    3841 Mar 18  2015 autoaction_tsm.sh
drwxrwxr-x  2 oracle oinstall 1085440 Aug 12 11:51 log
drwxrwxr-x  2 root   root        4096 Aug 14 20:40 sl04999


cd PSI1D
ls -la

drwxrwxr-x 5 oracle dba    4096 Apr 12 16:19 .
drwxr-xr-x 6 root   root   4096 Mar 21  2016 ..
-rwx------ 1 oracle dba     483 Aug 14 20:24 StartBackup.sh
-rwxrwxr-x 1 oracle dba      88 Apr 12 16:19 StartRedolog.out
-rwx------ 1 oracle dba     483 Aug 14 20:24 StartRedolog.sh
-rw-r--r-- 1 oracle dba      57 Jan 19  2017 TDPO.PSI1D_SL04999
-rwxrwxr-x 1 oracle dba       0 Nov 18  2014 TSM.PWD
drwxrwxr-x 2 oracle dba    4096 Aug 15 06:44 conf
drwxrwxr-x 2 oracle dba  311296 Aug 15 06:44 log
-rwxrwxr-x 1 oracle dba     186 Nov 30  2015 noBackup.txt
-rwxrwxr-x 1 oracle dba     186 Jul  7  2015 noDelete.txt
-rwxrwxr-x 1 oracle dba     186 Nov 30  2015 noRedolog.txt
-rwxrwxr-x 1 oracle dba      95 Nov  5  2018 nohup.out
drwxrwxr-x 2 oracle dba    4096 Feb  6  2019 rman



cat StartRedolog.sh                                   ###### За да видим паролата за RMAN 

#!/usr/bin/ksh
export ORACLE_HOME=/oracle/11.2.0.4.4
export ORACLE_SID=PSI1D
export LD_LIBRARY_PATH=/oracle/11.2.0.4.4/lib
export NLS_DATE_FORMAT="DD-MON-YYYY HH24:MI:SS"
Timestamp=$(date +%Y%m%d_%H%M)
echo Logfile: /tsm/PSI1D/log/Redolog_$Timestamp.log
RMANCMD="connect catalog RMAN12C/T#gbnhy13@REPODG8.WORLD;"                                        ##### <user_name>/<password>@<service>
while read LINE; do RMANCMD="$RMANCMD\n$LINE"; done < /tsm/PSI1D/rman/Redolog.rcv
print $RMANCMD|$ORACLE_HOME/bin/rman target / log=/tsm/PSI1D/log/Redolog_$Timestamp.log


su - oracle

. oraenv

rman target /


RMAN> connect catalog RMAN12C/T#gbnhy13@REPODG8.WORLD;

connected to recovery catalog database


RMAN> register database;

database registered in recovery catalog
starting full resync of recovery catalog
full resync complete

#########################################
The issue was resolved 


