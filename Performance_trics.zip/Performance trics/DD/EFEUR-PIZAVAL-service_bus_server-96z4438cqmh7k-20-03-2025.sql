/********************************************************************************
*********       E-mail subject: EFEURDEV-6545
*********             Instance: PIAVAL
*********          Description: 
Problem:
Saving 'Debtor Reverse Credit Limit' takes 1 minute.

Analysis:
We checked the provided HAR file and found the session, which stays behind the 1 minute delay ( SID = 1173 ). We found and the service_bus session, which matches the session from the HAR file 
and the TOP SQL in it is 96z4438cqmh7k ( from ftr_request.pcc ), which was executed only once, took ~1 minute and was responsible for 95% of the time. It looks like the most selective predicate 
is the gpiadr3 column, so we added hint to start the execution from it.

Suggestion:
Please change SQL 96z4438cqmh7k as it is shown in the New SQL section below.

*********               SQL_ID: 96z4438cqmh7k
*********      Program/Package: ftr_request.pcc
*********              Request: Dimitare Ivanov
*********               Author: Dimitar Dimitrov
********* Received e-mail date: 19/03/2025
*********      Resolution date: 20/03/2025
*********  Trace old file here: \\epox\specifs\performance\tmp\
*********  Trace new file here:
***********************************************************************************/

/********************************OLD SQL*******************************************/

var B0 VARCHAR2(1000);
exec :B0 := 'EUR';
var B2 VARCHAR2(1000);
exec :B2 := 'DRC';
var B3 VARCHAR2(1000);
exec :B3 := 'A600HXUQ';
var B5 VARCHAR2(1000);
exec :B5 := '2503195013';

select CH_TAUX.Conv_Orig_Dest_Tx( TO_CHAR(SYSDATE,'j'),
                                  mt02,
                                  code,
                                  :b0,
                                  'MR',
                                  ftr_fin_factor.getCurrency(gpityptrib),
                                  ftr_fin_factor.getPays(gpityptrib) )
  from g_piece
 where typpiece = 'REQUEST_LIMITE'
   and fg05 = 'O'
   and gpirole in ('DC','DT')
   and typedoc = :b2
   and gpiadr3 = :b3
   and (    :b2 = 'D'
         or refdoss = :b5 )
   and TRUNC(NVL(gpidtfin_dt,(SYSDATE+1))) >= TRUNC(SYSDATE);
/********************************OLD SQL*******************************************/
/********************************OLD Metrics***************************************/
/*
MODULE                           ACTION                    SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- ------------------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
service_bus_server_4BACB2C63144E 1/1173/561334                                            1439       7232                      2025/03/19 15:30:03  2025/03/19 15:30:59          57                    1 +000000000 00:00:56.023 47%
89B07E15B5F60D53818

MODULE                           ACTION                    SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- ------------------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
service_bus_server_4BACB2C63144E 1/1173/561334             96z4438cqmh7k 1558150397       1439       7232                      2025/03/19 15:30:05  2025/03/19 15:30:58          54                    1 +000000000 00:00:53.021 95%
89B07E15B5F60D53818

service_bus_server_4BACB2C63144E 1/1173/561334             asgj8pw61rbj6 4060975977       1439       7232 db file sequential r 2025/03/19 15:30:03  2025/03/19 15:30:03           1                    1 +000000000 00:00:00.000 2%
89B07E15B5F60D53818

service_bus_server_4BACB2C63144E 1/1173/561334             4sn2nnrb45gz7 4183308657       1439       7232 ON CPU               2025/03/19 15:30:04  2025/03/19 15:30:04           1                      +000000000 00:00:00.000 2%
89B07E15B5F60D53818

service_bus_server_4BACB2C63144E 1/1173/561334             au3gcnwgdnnx2 1825804526       1439       7232 ON CPU               2025/03/19 15:30:59  2025/03/19 15:30:59           1                      +000000000 00:00:00.000 2%

Plan hash value: 1558150397
-----------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                            | Name             | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  |
-----------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                     |                  |      1 |        |     1 (100)|      0 |00:01:08.42 |     108K|    102K|
|   1 |  INLIST ITERATOR                     |                  |      1 |        |            |      0 |00:01:08.42 |     108K|    102K|
|*  2 |   TABLE ACCESS BY INDEX ROWID BATCHED| G_PIECE          |      2 |      1 |     1   (0)|      0 |00:01:08.42 |     108K|    102K|
|*  3 |    INDEX RANGE SCAN                  | G_PIECE$ID_VENTE |      2 |      1 |     1   (0)|    182K|00:00:00.84 |     797 |    797 |
-----------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   2 - filter(("GPIADR3"=:B3 AND "TYPEDOC"=:B2 AND "FG05"='O' AND (:B2='D' OR "REFDOSS"=:B5) AND
              TRUNC(NVL("GPIDTFIN_DT",SYSDATE@!+1))>=TRUNC(SYSDATE@!)))
   3 - access((("GPIROLE"='DC' OR "GPIROLE"='DT')) AND "TYPPIECE"='REQUEST_LIMITE')
*/
/********************************OLD Metrics***************************************/

/********************************New SQL*******************************************/


select /*+ index( g_piece G_PIECE$ADR3 ) */
       CH_TAUX.Conv_Orig_Dest_Tx( TO_CHAR(SYSDATE,'j'),
                                  mt02,
                                  code,
                                  :b0,
                                  'MR',
                                  ftr_fin_factor.getCurrency(gpityptrib),
                                  ftr_fin_factor.getPays(gpityptrib) )
  from g_piece
 where typpiece = 'REQUEST_LIMITE'
   and fg05 = 'O'
   and gpirole in ('DC','DT')
   and typedoc = :b2
   and gpiadr3 = :b3
   and (    :b2 = 'D'
         or refdoss = :b5 )
   and TRUNC(NVL(gpidtfin_dt,(SYSDATE+1))) >= TRUNC(SYSDATE);


 
/********************************New SQL*******************************************/
/********************************New Metrics***************************************/
/*

Plan hash value: 385531285
------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                           | Name         | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  |
------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                    |              |      1 |        |     1 (100)|      0 |00:00:00.01 |       7 |      2 |
|*  1 |  TABLE ACCESS BY INDEX ROWID BATCHED| G_PIECE      |      1 |      1 |     1   (0)|      0 |00:00:00.01 |       7 |      2 |
|*  2 |   INDEX RANGE SCAN                  | G_PIECE$ADR3 |      1 |      7 |     1   (0)|      2 |00:00:00.01 |       3 |      0 |
------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   1 - filter(("TYPPIECE"='REQUEST_LIMITE' AND "TYPEDOC"=:B2 AND "FG05"='O' AND INTERNAL_FUNCTION("GPIROLE") AND (:B2='D'
              OR "REFDOSS"=:B5) AND TRUNC(NVL("GPIDTFIN_DT",SYSDATE@!+1))>=TRUNC(SYSDATE@!)))
   2 - access("GPIADR3"=:B3) 
  
*/
/********************************New Metrics***************************************/

/********************************Index statistics**********************************/

/********************************Other SQLs****************************************/          
/*

*/ 
/********************************Other SQLs****************************************/              
