Customer : FCC
Server : A0ORA022D

There will be OS patching , so you will have to stop the CRS and later patch both DB & GRID homes.

The procedure is : 



dbspicao -vdfp



dbspicol OFF



dbspicao -vdfp





### as root

/u01/app/11.2.0.3/grid/bin/crsctl stop crs

/u01/app/11.2.0.3/grid/bin/crsctl disable crs



/u01/app/11.2.0.3/grid/bin/crsctl config crs

/u01/app/11.2.0.3/grid/bin//crsctl stat res -t



ps -fu oracle


###########INFORM UX TEAM THAT YOU ARE READY #####################

###### DB Relink ######



1) Stop all oracle instances and listeners accessing this ORACLE_HOME. Verify for running processes

As root:

ps -fu oracle



2) Connect as oracle and relink binaries:



$ $ORACLE_HOME/bin/relink all



3) Check relink log for errors:



$ORACLE_HOME/install/relink.log 



###### Relink Grid ######



As root user, unlock the home:

cd /u01/app/11.2.0.3/grid/crs/install

./rootcrs.pl -unlock


As the grid infrastructure owner, relink the binaries:

$ export ORACLE_HOME=/u01/app/11.2.0.3/grid

$ /u01/app/11.2.0.3/grid/bin/relink all

As root  : 

cd /u01/app/11.2.0.3/grid/crs/install

./rootcrs.pl -patch



CRS services (CRS, CSS ASM instances, diskgroups, listeners, DB instances, etc.) will automatically start.



$ < Grid Infrastructure Oracle Home>/install/relink.log





/u01/app/11.2.0.3/grid/bin/crsctl enable crs

/u01/app/11.2.0.3/grid/bin/crsctl check crs

/u01/app/11.2.0.3/grid/bin/crsctl config crs

/u01/app/11.2.0.3/grid/bin/crsctl stat res -t



dbspicol ON

