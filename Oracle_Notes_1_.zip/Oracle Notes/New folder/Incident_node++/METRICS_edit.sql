#####################################

/opt/oracle/util/mlpx/rc_mon ------> oramoncfg ima edin file v tazi directoriq
tam gi pishe
другата е тука: /var/opt/OV/conf/OpC 

SQL> select TABLESPACE_NAME from DBA_TABLESPACE_USAGE_METRICS where USED_PERCENT between 80 and 90;

TABLESPACE_NAME
------------------------------
SYSAUX 


##########
###########
select (m.TABLESPACE_NAME) from DBA_TABLESPACE_USAGE_METRICS_TEST1 m, 
DBA_TABLESPACES c where m.TABLESPACE_NAME=c.TABLESPACE_NAME 
and c.contents not like '%UNDO%' and c.contents not like '%TEMP%' and MAX_TS_PCT_USED between 80 and 90;


########
########
MetricSQL="select count(m.TABLESPACE_NAME) from DBA_TABLESPACE_USAGE_METRICS_TEST1 m, DBA_TABLESPACES c where m.TABLESPACE_NAME=c.TABLESPACE_NAME and c.contents not like '%UNDO%' and c.contents not like '%TEMP%' and MAX_TS_PCT_USED >= $TBS_USED_THRHLD_CRITICAL;" 



select count(m.TABLESPACE_NAME) from DBA_TABLESPACE_USAGE_METRICS_TEST1 m, 
DBA_TABLESPACES c where m.TABLESPACE_NAME=c.TABLESPACE_NAME 
and c.contents not like '%UNDO%' and c.contents not like '%TEMP%' and MAX_TS_PCT_USED >= 90;" 



###########
###########
#Da zakomentiram metricite 731 i t.n.
 vi /var/opt/OV/bin/instrumentation/db_mon.cfg
 
 
 
 ######################################
 ######################################
 
  [4:55 PM] Naydenova, Martina Krasimirova
    
[root@mlpwi-bnk001 ~]# dbspicfg -e
SYNTAX_VERSION 4


ORACLE


  HOME "/oracle/FAGDWHP/app/product/11.2.0.4"
    DATABASE "FAGDWHP" CONNECT "hp_dbspi/pwd4mon_MLP@FAGDWHP"
     DISABLED
           LOGFILE "/oracle/FAGDWHP/diag/rdbms/fagdwhp/FAGDWHP/trace/alert_FAGDWHP.log"
           FILTER 6 "tablespace_name not in ('TEMPSPACE','UNDOTBS','RBS')"


  HOME "/export/home/ora_bdmlpp/oracle/11.2.0.4"
    DATABASE "BDMLPP" CONNECT "hp_dbspi/dbspi_MLPJaVa@BDMLPP"
           LOGFILE "/BDMLPP/app/oracle/diag/rdbms/bdmlpp/BDMLPP/trace/alert_BDMLPP.log"
           FILTER 6 "TABLESPACE_NAME not like '%UNDO%'"


  HOME "/oracle/DIPDBP/app/product/12.2.0.1"
    DATABASE "DIPDBP" CONNECT "hp_dbspi/pwd4mon_MLP@DIPDBP"
           LOGFILE "/oracle/DIPDBP/diag/rdbms/dipdbp/DIPDBP/trace/alert_DIPDBP.log"
           FILTER 4 "USERNAME not in ('MGMT_VIEW','SYSDG','SYSKM','SYSBACKUP')"
           FILTER 6 "TABLESPACE_NAME not like '%UNDO%' and TABLESPACE_NAME not like '%TEMP%' and TABLESPACE_NAME not like '%TMP%'"
           FILTER 16 "TABLESPACE_NAME not like '%UNDO%' and TABLESPACE_NAME not like '%TEMP%' and TABLESPACE_NAME not like '%TMP%'"





[root@mlpwi-bnk001 ~]# dbspicfg.sh
i + enter --- insert mode, за да можем да edit-ваме, все едно сме отворили файла с vi


SYNTAX_VERSION 4


ORACLE


  HOME "/oracle/FAGDWHP/app/product/11.2.0.4"
    DATABASE "FAGDWHP" CONNECT "hp_dbspi/pwd4mon_MLP@FAGDWHP"
     DISABLED
           LOGFILE "/oracle/FAGDWHP/diag/rdbms/fagdwhp/FAGDWHP/trace/alert_FAGDWHP.log"
           FILTER 6 "tablespace_name not in ('TEMPSPACE','UNDOTBS','RBS')"



  HOME "/export/home/ora_bdmlpp/oracle/11.2.0.4"      --- В случаят тази база е вече upgrade-ната към 18с и не може да се мониторира с dbspi, добавяме нов ред и пишем DISABLED
    DATABASE "BDMLPP" CONNECT "hp_dbspi/dbspi_MLPJaVa@BDMLPP"
     DISABLED
           LOGFILE "/BDMLPP/app/oracle/diag/rdbms/bdmlpp/BDMLPP/trace/alert_BDMLPP.log"
           FILTER 6 "TABLESPACE_NAME not like '%UNDO%'"


ESC
:wq!

#########################################
###########################################