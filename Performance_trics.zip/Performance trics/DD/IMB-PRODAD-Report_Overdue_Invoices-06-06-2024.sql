/********************************************************************************
*********       E-mail subject: IMBWEB-7871
*********             Instance: PRODAD
*********          Description: 
Problem:
SQL was provided in IMBWEB-7871 as slow on IMB PRODAD.

Analysis:
The problem in this SQL was inappropriate use of hints for the way and the order by which to access the tables in the unions.
We changed the hints and now the query makes a full scan of table G_PIECEDET which takes less than a second on PRODAD and it is the optimal way 
to access the table in this case.

Suggestion:
Please change the hints as it is shown in the New SQL section below.

*********               SQL_ID: 
*********      Program/Package: 
*********              Request: Thuy Le Mong 
*********               Author: Dimitar Dimitrov
********* Received e-mail date: 05/06/2024
*********      Resolution date: 06/06/2024
*********  Trace old file here: \\epox\specifs\performance\tmp\
*********  Trace new file here:
***********************************************************************************/

/********************************OLD SQL*******************************************/

SELECT *
FROM (SELECT /*+LEADING(db_cl debtor client request_declre inv fi inf invstus deb_pol) FULL(db_cl) FULL(debtor) USE_HASH(debtor) FULL(client) USE_HASH(client)
            FULL(request_declre) FULL(inv) USE_HASH(inv) FULL(fi) USE_HASH(fi) USE_HASH(inf) FULL(invstus) USE_HASH(invstus) USE_HASH(request_declre)
            USE_HASH(deb_pol) USE_HASH(fin_lim)*/
         db_cl.ANCREFDOSS AS "Contract number",
         client.client_nom AS "Client Name",
         client.client_refindividu AS "Client ID",
         db_cl.REFDOSS AS "CLDB account",
         db_cl.clcl_number AS "CLI_CLI number",
         debtor.debtor_nom AS "Debtor Name",
         debtor.debtor_refindividu AS "Debtor ID",
         debtor.debtor_pays AS "Debtor Country",
         decode(inv.typeref,'INV','Invoice',
                                  'CR','Credit note',
                                  'PAY','Non-matched payment',
                                  'Other debit') AS "Document Type",
         inv.doc_reference AS "Document Number",
         invstus.valeur_an AS "Document Status",
         inv.reminder_level AS "Dunning Level",
         (case when inv.comments is not null
              then inv.comments||' '||fi.GP_COMMENTAIRE_15 ||' '||inf.ginfo_libreinfo
         else fi.GP_COMMENTAIRE_15||' '|| inf.ginfo_libreinfo end) AS "Comments on document",
         inv.doc_date AS "Document Issue Date",
         inv.due_date AS "Document Due date",
         decode(inv.typeref,'PAY',(-1)*inv.item_amt, inv.item_amt) AS "Document Amount" ,
         decode(inv.typeref,'PAY',(-1)*inv.open_amt, inv.open_amt) AS "Open Amount of the Document",
         fi.gp_mt14 AS "Fundable amount",
        reten_reason.valeur_an AS "Retention reason",
         inv.item_ccy AS "Document Currency",
         (case when inv.item_ccy = 'EUR' then null
              else CH_TAUX.Conv_Orig_Dest_Tx(to_char(sysdate,'j'),
                                             decode(inv.typeref,'PAY',(-1)*inv.item_amt, inv.item_amt),
                                             inv.item_ccy ,
                                             'EUR' ,
                                              'MR' ,
                                             '') end) AS "Document amount calculated with current FX rate",
         (case when db_cl.devise = 'EUR' then db_cl.restprin_dos
              else CH_TAUX.Conv_Orig_Dest_Tx(to_char(sysdate,'j'),
                                             db_cl.restprin_dos,
                                             db_cl.devise,
                                             'EUR' ,
                                              'MR' ,
                                             '') end) AS "Outstanding balance of the CL/DB",
         --IMBWEB-6360
         CH_TAUX.Conv_Orig_Dest_Tx(to_char(sysdate,'j'),
                                             amt_lm_con.consumed_lim,
                                             request_declre.gpidevis,
                                             'EUR' ,
                                              'MR' ,
                                             '') AS "Insured outstanding", /*IMBWEB-6496 currency take from request limit*/
         deb_pol.nom AS "Insurance company",
         deb_pol.policy_number AS "Policy number",
         ins_udf.Insurance_quality AS "Insurance quality",
         --IMBWEB-6360
         request_declre.gpidevis AS "Limit currency (Delcredere Limit)",
         request_declre.mt02 AS "Delcredere Limit",
         --IMBWEB-6360
         --request_declre.gpidtdeb_dt AS "Start Date of Delceredere Limit",
         request_declre.dt04_dt AS "Decision date of Delcredere limit",
         request_declre.pre_Limamt AS "Previous Delcredere Limit",
         
         CH_TAUX.Conv_Orig_Dest_Tx(to_char(sysdate,'j'),
                                             request_declre.mt02,
                                             request_declre.gpidevis,
                                             'EUR' ,
                                              'MR' ,
                                             '') AS "Delcredere Limit EUR",
         --IMBWEB-6360
         fin_lim.FIN_Limit AS "FIN Limit Level 3",
         ad_jullian_date(sysdate)- ad_jullian_date(inv.due_date) AS "Document overdue",
         ad_jullian_date(sysdate)- ad_jullian_date(inv.doc_date) AS "Older than",
         null AS "Comment"
    FROM ad_account_debtor_client db_cl,
         ad_debtors debtor,
         ad_clients client,
         (SELECT /*+no_merge no_push_pred*/COMPTE_CASE,
                 NVL(pol_compt, pol_contract) policy_number,
                 NVL(str_20_1_compt, str_20_1_contract) str_20_1,
                 NVL(st02_compt, st02_compt) st02,
                 NVL(nom_compt, nom_contract) nom
            FROM (SELECT /*+no_merge no_push_pred*/ COMPTE_CASE,
                         max(pol_compt) pol_compt,
                         max(str_20_1_compt) str_20_1_compt,
                         max(st02_compt) st02_compt,
                         max(nom_compt) nom_compt,
                         max(pol_contract) pol_contract,
                         max(str_20_1_contract) str_20_1_contract,
                         max(st02_contract) st02_contract,
                         max(nom_contract) nom_contract
                   FROM (SELECT /*+LEADING(B C D E dbcl F) INDEX(B TYPPIECE_LASTLOAD_IND) INDEX(C GPDET_TYP_REF_IDX) USE_NL(C)
                               INDEX(D G_PIECE_TYPE_REFPIECE_INX) USE_NL(D) INDEX(E AD_CASE_POLICE_PK) USE_NL(E)
                               FULL(dbcl) USE_HASH(dbcl) FULL(F) USE_HASH(F)*/
                               distinct gp.refdoss COMPTE_CASE,
                               pol.refext AS pol_compt,
                               pol.str_20_1 AS str_20_1_compt,
                               pol.st02 AS st02_compt,
                               cre_ins.refext AS nom_compt,
                               NULL AS pol_contract,
                               NULL AS str_20_1_contract,
                               NULL AS st02_contract,
                               NULL AS nom_contract
                          FROM G_PIECE gp,
                               G_PIECEDET gpdet,
                               G_PIECE pol,
                               AD_CASE_POLICE pol_case,
                               AD_ACCOUNT_DEBTOR_CLIENT dbcl,
                               AD_DEBTORS af,
                               t_individu cre_ins
                          WHERE gp.TYPPIECE ='COMPTE'
                            AND gp.REFPIECE = gpdet.REFPIECE
                            AND gpdet.TYPE = 'ASSURANCE_CREDIT'
                            AND NVL(gpdet.STR7,gpdet.STR9) = pol.REFPIECE
                            AND pol.TYPPIECE ='POLICE'
                            AND pol.REFDOSS = pol_case.REFDOSS
                            AND SYSDATE BETWEEN gpdet.DT01_DT AND NVL(gpdet.DT02_DT,SYSDATE)
                            AND dbcl.REFDOSS = gp.REFDOSS
                            AND dbcl.DEBTOR = af.DEBTOR_REFINDIVIDU
                            AND af.DEBTOR_PAYS = gpdet.STR1
                            AND pol_case.db_ref = cre_ins.refindividu(+)
                            AND cre_ins.societe(+) = 'CR_INSURER'
                            UNION
                            SELECT /*+LEADING(B C D E dbcl F) INDEX(B TYPPIECE_LASTLOAD_IND) INDEX(C GPDET_TYP_REF_IDX) USE_NL(C)
                                     INDEX(D G_PIECE_TYPE_REFPIECE_INX) USE_NL(D) INDEX(E AD_CASE_POLICE_PK) USE_NL(E)
                                     FULL(dbcl) USE_HASH(dbcl) FULL(F) USE_HASH(F)*/
                                   dbcl.refdoss AS COMPTE_CASE,
                                   NULL AS pol_compt,
                                   NULL AS str_20_1_compt,
                                   NULL AS st02_compt,
                                   NULL AS nom_compt,
                                   pol.refext AS pol_contract,
                                   pol.str_20_1 AS str_20_1_contract,
                                   pol.st02 AS st02_contract,
                                   cre_ins.refext AS nom_contract
                          FROM G_PIECE gp,
                               G_PIECEDET gpdet,
                               G_PIECE pol,
                               AD_CASE_POLICE pol_case,
                               AD_CASES dbcl,
                               AD_DEBTORS af,
                               t_individu cre_ins
                          WHERE gp.TYPPIECE ='CONTRAT'
                            AND gp.REFPIECE = gpdet.REFPIECE
                            AND gpdet.TYPE = 'ASSURANCE_CREDIT'
                            AND NVL(gpdet.STR7,gpdet.STR9) = pol.REFPIECE
                            AND pol.TYPPIECE ='POLICE'
                            AND pol.REFDOSS = pol_case.REFDOSS
                            AND gp.REFDOSS = dbcl.CONTRACT_CASE
                            AND dbcl.CATEGDOSS ='COMPTE'
                            AND SYSDATE BETWEEN gpdet.DT01_DT AND NVL(gpdet.DT02_DT,SYSDATE)
                            AND dbcl.DEBTOR_REF = af.DEBTOR_REFINDIVIDU
                            AND af.DEBTOR_PAYS = gpdet.STR1
                            AND pol_case.db_ref = cre_ins.refindividu(+)
                            AND cre_ins.societe(+) = 'CR_INSURER'
                      )group by COMPTE_CASE
                 )
         )deb_pol,
         (SELECT /*+LEADING(a b) FULL(a) FULL(b) USE_HASH(b)*/
                 a.refdoss,
                 decode(a.typeref, 'PAY', nvl(b.numchq,b.lieupaimt), a.doc_reference) doc_reference,
                 a.reminder_level,
                 a.typeref,
                 a.comments,
                 a.doc_date,
                 a.due_date,
                 a.open_amt,
                 --a.item_ccy, --IMBWEB-6360
                 (case when a.typeref = 'PAY' then b.devise_mvt else a.item_ccy end) item_ccy,
                 a.reference,
                 a.st09,
                 --IMBWEB-6360
                (case when a.typeref = 'PAY' then b.montant_mvt else a.item_amt end) item_amt
            FROM ad_fipay a,
                 g_encaissement b
           WHERE a.doc_reference = b.refencaiss(+)
           )inv,
         ad_finelem_3nf fi,
         ( select /*+no_merge no_push_pred*/
                  el_refdoss,
                  ginfo_encodeur,
                  ginfo_libreinfo
             from ( select /*+FULL(ad_information_mview)*/
                           el_refdoss,
                           ginfo_encodeur,
                           ginfo_libreinfo,
                           row_number() over(partition by el_refdoss order by el_imx_un_id desc) rn
                      from ad_information_mview
                  )
            where rn = 1
         )inf,
         v_domaine invstus,
         (
           select /*+no_merge no_push_pred LEADING(cur_lim) INDEX(pre_lim GP_TYPEDOC)*/
                    cur_lim.gpiadr3,
                    cur_lim.gpidepot,
                    cur_lim.gpiheure,
                    max(cur_lim.gpidevis) gpidevis,
                    max(cur_lim.gpidtdeb_dt) gpidtdeb_dt,
                    max(cur_lim.mt02) mt02,
                    max(pre_lim.mt02) pre_Limamt,
                    --IMBDEV-10689
                    max(cur_lim.dt04_dt) dt04_dt
                    --cur_lim.libelle_20_12
              from g_piece pre_lim,
                   (select /*+INDEX(lim GP_TYPEDOC)*/
                           lim.gpiadr3,
                           lim.gpidepot,
                           lim.gpiheure,
                           lim.dt04_dt,
                           --lim.libelle_20_12,
                           max(decode(lim.fg05,'O',lim.gpidevis,null)) gpidevis,
                           max(decode(lim.fg05,'O',lim.gpidtdeb_dt,null)) gpidtdeb_dt,
                           max(decode(lim.fg05,'O',lim.mt02,null)) mt02,
                           max(case when lim.fg05 ='O' then lim.st04
                                when nvl(lim.fg05,'N') = 'N' then lim.refpiece else null end) pre_piece
                      from g_piece lim
                     where lim.TYPPIECE ='REQUEST_LIMITE'
                       and lim.typedoc IN ('C')
                       and lim.gpirole IN ('DC', 'DT')
                     group by lim.gpiadr3,
                              lim.gpiDEPOT,
                              lim.GPIHEURE,
                              lim.dt04_dt
                              --lim.libelle_20_12
                     )cur_lim
                 where cur_lim.pre_piece = pre_lim.refpiece(+)
                   and pre_lim.TYPPIECE(+) ='REQUEST_LIMITE'
                   and pre_lim.typedoc(+) IN ('C')
                   and pre_lim.gpirole(+) IN ('DC', 'DT')
                   group by cur_lim.gpiadr3,
                    cur_lim.gpidepot,
                    cur_lim.gpiheure
          )request_declre,
          
          (SELECT /*+FULL(req)*/
                    req.gpiadr3 debtor ,
                    req.gpidepot client,
                    req.gpiheure contract,
                    req.gpidevis gpidevis,
                    req.mt02 FIN_Limit
               FROM ad_request_limit_mview req
              WHERE req.typedoc = 'F'
                AND req.fg05 ='O'
          UNION ALL
           SELECT /*+LEADING(req_dbfl) FULL(req_dbfl) FULL(req_nf) USE_HASH(req_nf) FULL(dbcl_dbfl) SE_HASH(dbcl_dbfl)*/
                  distinct req_dbfl.gpiadr3 debtor ,
                  dbcl_dbfl.client client,
                  dbcl_dbfl.ancrefdoss contract,
                  req_dbfl.gpidevis gpidevis,
                  req_dbfl.mt02 FIN_Limit
             FROM ad_request_limit_mview req_dbfl,
                  ad_account_debtor_client dbcl_dbfl,
                  ad_request_limit_mview req_nf
            WHERE req_dbfl.typedoc = 'DBFL'
              AND req_dbfl.fg05 ='O'
              AND req_dbfl.gpiadr3 is not null
              AND req_dbfl.gpiadr3 = dbcl_dbfl.debtor
              AND req_nf.typedoc(+) = 'F'
              AND req_nf.fg05(+) ='O'
              AND req_dbfl.gpiadr3 = req_nf.gpiadr3(+)
              AND dbcl_dbfl.client = req_nf.gpidepot(+)
              AND dbcl_dbfl.ancrefdoss = req_nf.gpiheure(+)
              AND req_nf.gpiadr3 IS NULL
              AND req_nf.gpidepot IS NULL
              AND req_nf.gpiheure IS NULL
          )fin_lim,
          (SELECT refdoss, refelem, valeur_an
            FROM (SELECT /*+ full(gve)*/
                 gve.refdoss,
                 gve.refelem,
                 lov.valeur_an,
                 row_number() over(PARTITION BY refdoss, refelem ORDER BY real_amount_dec DESC) rnk
                  FROM g_venrestriction gve, v_domaine lov
                 WHERE gve.restriction_code = lov.abrev
                   AND lov.type = 'DECOMPTE_RESTRICTIONS')
         WHERE rnk = 1
         )reten_reason,
         (SELECT REFDOSS,MAX(VERSITAT)||MAX(INSUR)Insurance_quality
            FROM (
            SELECT /*+ INDEX(gdet G_PIECEDET_TYPE_LASTLOAD_IDX)*/
                   gdet.REFDOSS,gdet.REFPIECE,gdet.LIB2,
                   DECODE(gdet.LIB2,'INSUR',gdet.LIB3,NULL)INSUR,
                   DECODE(gdet.LIB2,'VERSITAT',gdet.LIB3,NULL) VERSITAT,
                   ROW_NUMBER() OVER(PARTITION BY gdet.REFDOSS,gdet.LIB2 ORDER BY gdet.IMX_UN_ID DESC) rnk
            FROM G_PIECEDET gdet
            WHERE TYPE ='UDF'
             AND LIB2 IN ('VERSITAT','INSUR')
             )
             WHERE rnk =1
             GROUP BY REFDOSS
         )ins_udf,
         --IMBDEV-10689
      (
           select compte_id,
                  limit_id,
                  sum(consumed_lim) consumed_lim
           from
           (
             select sub.compte_id,
                    sub.limit_id,
                    sub.consumed_lim
                    /*sub.fi_id*/
             from
                 (select compte_id,
                         limit_id,
                         consumed_lim,
                         fi_id,
                         RANK() OVER (PARTITION BY compte_id, fi_id ORDER BY IMX_UN_ID desc) rnk
                    from G_VENFILIMIT where limit_role='COVERAGE'
                 )sub
             where sub.rnk=1
           )
           group by compte_id, limit_id
         ) amt_lm_con
   WHERE debtor.debtor_refindividu = db_cl.debtor
     AND client.client_refindividu = db_cl.client
     AND inv.refdoss = deb_pol.COMPTE_CASE(+)
     AND inv.refdoss = db_cl.refdoss
     AND fi.fi_refelem(+) = DECODE(inv.typeref, 'PAY', NULL, inv.reference)
     AND fi.fi_actif(+) = 'O'
     --
     AND request_declre.gpiadr3(+) = db_cl.debtor
     AND request_declre.gpidepot(+) = db_cl.client
     AND request_declre.gpiheure(+) = db_cl.ancrefdoss
     AND db_cl.refdoss = amt_lm_con.compte_id(+)
     --
     AND invstus.abrev(+) = inv.st09
     AND invstus.type(+) ='INVSTATUS'
     AND inf.el_refdoss(+) = inv.refdoss
     AND inf.ginfo_encodeur(+) = inv.reference
     --
     AND fin_lim.DEBTOR(+) = db_cl.debtor
     AND fin_lim.CLIENT(+) = db_cl.client
     AND fin_lim.CONTRACT(+) = db_cl.ancrefdoss
     --
     AND reten_reason.refdoss(+) = fi.fi_refdoss
     AND reten_reason.refelem(+) = fi.fi_refelem
     AND ins_udf.REFDOSS(+) = db_cl.CONTRACT
)main_tab
ORDER BY main_tab."Client ID",main_tab."Debtor ID"; 
/********************************OLD SQL*******************************************/
/********************************OLD Metrics***************************************/
/*
Plan hash value: 1441032556
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                                | Name                         | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  | Writes |
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                                         |                              |      1 |        |   149M(100)|      0 |00:00:00.01 |       0 |      0 |      0 |
|   1 |  SORT ORDER BY                                           |                              |      1 |    132M|   149M  (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*  2 |   HASH JOIN RIGHT OUTER                                  |                              |      1 |    132M|  2230K  (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*  3 |    VIEW                                                  |                              |      1 |      9 |   352   (1)|  21585 |00:00:00.04 |    1295 |      0 |      0 |
|*  4 |     WINDOW SORT PUSHED RANK                              |                              |      1 |      9 |   352   (1)|  21585 |00:00:00.04 |    1295 |      0 |      0 |
|*  5 |      HASH JOIN                                           |                              |      1 |      9 |   351   (0)|  21591 |00:00:00.01 |    1295 |      0 |      0 |
|   6 |       JOIN FILTER CREATE                                 | :BF0000                      |      1 |     13 |    10   (0)|     42 |00:00:00.01 |      38 |      0 |      0 |
|   7 |        TABLE ACCESS BY INDEX ROWID BATCHED               | V_DOMAINE                    |      1 |     13 |    10   (0)|     42 |00:00:00.01 |      38 |      0 |      0 |
|*  8 |         INDEX RANGE SCAN                                 | V_DOMAINE_IND                |      1 |     13 |     2   (0)|     42 |00:00:00.01 |       2 |      0 |      0 |
|   9 |       JOIN FILTER USE                                    | :BF0000                      |      1 |  21225 |   341   (0)|  21591 |00:00:00.01 |    1257 |      0 |      0 |
|* 10 |        TABLE ACCESS STORAGE FULL                         | G_VENRESTRICTION             |      1 |  21225 |   341   (0)|  21591 |00:00:00.01 |    1257 |      0 |      0 |
|* 11 |    HASH JOIN RIGHT OUTER                                 |                              |      1 |    132M|  2230K  (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|  12 |     VIEW                                                 |                              |      1 |  52362 |  7557   (1)|  31787 |00:00:00.17 |   12303 |      0 |      0 |
|  13 |      HASH GROUP BY                                       |                              |      1 |  52362 |  7557   (1)|  31787 |00:00:00.17 |   12303 |      0 |      0 |
|* 14 |       VIEW                                               |                              |      1 |  58912 |  7557   (1)|  31910 |00:00:00.12 |   12303 |      0 |      0 |
|* 15 |        WINDOW SORT PUSHED RANK                           |                              |      1 |  58912 |  7557   (1)|  31910 |00:00:00.12 |   12303 |      0 |      0 |
|* 16 |         TABLE ACCESS BY INDEX ROWID BATCHED              | G_PIECEDET                   |      1 |  58912 |  7034   (1)|  35029 |00:00:00.07 |   12303 |      0 |      0 |
|* 17 |          INDEX RANGE SCAN                                | G_PIECEDET_TYPE_LASTLOAD_IDX |      1 |  70276 |   546   (0)|  70436 |00:00:00.01 |     329 |      0 |      0 |
|* 18 |     HASH JOIN RIGHT OUTER                                |                              |      1 |   7289K|  1241K  (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|  19 |      VIEW                                                |                              |      1 |   5179K|   603K  (1)|  22929 |00:00:13.91 |    1832K|   1859K|  26878 |
|  20 |       HASH GROUP BY                                      |                              |      1 |   5179K|   603K  (1)|  22929 |00:00:13.91 |    1832K|   1859K|  26878 |
|* 21 |        VIEW                                              |                              |      1 |   5179K|   547K  (1)|   3639K|00:00:13.60 |    1832K|   1859K|  26878 |
|* 22 |         WINDOW SORT PUSHED RANK                          |                              |      1 |   5179K|   547K  (1)|   3639K|00:00:13.56 |    1832K|   1859K|  26878 |
|* 23 |          TABLE ACCESS STORAGE FULL                       | G_VENFILIMIT                 |      1 |   5179K|   489K  (1)|   3640K|00:00:02.07 |    1832K|   1832K|      0 |
|* 24 |      HASH JOIN RIGHT OUTER                               |                              |      1 |    332K|   585K  (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|* 25 |       TABLE ACCESS STORAGE FULL                          | AD_FINELEM_3NF               |      1 |    611K|   119K  (1)|    456K|00:00:00.25 |     450K|    450K|      0 |
|* 26 |       HASH JOIN RIGHT OUTER                              |                              |      1 |    332K|   420K  (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|  27 |        VIEW                                              |                              |      1 |      2 | 26875   (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|  28 |         VIEW                                             |                              |      1 |      2 | 26875   (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|  29 |          HASH GROUP BY                                   |                              |      1 |      2 | 26875   (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|  30 |           VIEW                                           |                              |      1 |      2 | 26874   (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|  31 |            SORT UNIQUE                                   |                              |      1 |      2 | 26874   (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|  32 |             UNION-ALL                                    |                              |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
|  33 |              NESTED LOOPS                                |                              |      1 |      1 | 25279   (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|  34 |               NESTED LOOPS                               |                              |      1 |      1 | 25279   (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|* 35 |                HASH JOIN                                 |                              |      1 |      1 | 25277   (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|  36 |                 JOIN FILTER CREATE                       | :BF0001                      |      1 |      1 | 23292   (1)|   1083K|00:03:15.66 |      98M|  15754 |      0 |
|  37 |                  NESTED LOOPS                            |                              |      1 |      1 | 23292   (1)|   1083K|00:03:15.46 |      98M|  15754 |      0 |
|  38 |                   NESTED LOOPS                           |                              |      1 |   5478 | 23292   (1)|    107M|00:00:27.89 |     882K|    586 |      0 |
|  39 |                    MERGE JOIN CARTESIAN                  |                              |      1 |   5478 |  1376   (1)|  12086 |00:00:00.08 |    4933 |      1 |      0 |
|  40 |                     NESTED LOOPS OUTER                   |                              |      1 |      1 |    44   (0)|      2 |00:00:00.01 |      19 |      1 |      0 |
|  41 |                      NESTED LOOPS                        |                              |      1 |      1 |    41   (0)|      2 |00:00:00.01 |      12 |      0 |      0 |
|* 42 |                       TABLE ACCESS BY INDEX ROWID BATCHED| G_PIECE                      |      1 |     84 |    40   (0)|      2 |00:00:00.01 |       7 |      0 |      0 |
|* 43 |                        INDEX RANGE SCAN                  | GP_TYPPLIB_IDX               |      1 |    119 |     4   (0)|      2 |00:00:00.01 |       4 |      0 |      0 |
|  44 |                       TABLE ACCESS BY INDEX ROWID        | AD_CASE_POLICE               |      2 |      1 |     1   (0)|      2 |00:00:00.01 |       5 |      0 |      0 |
|* 45 |                        INDEX UNIQUE SCAN                 | AD_CASE_POLICE_PK            |      2 |      1 |     0   (0)|      2 |00:00:00.01 |       2 |      0 |      0 |
|  46 |                      TABLE ACCESS BY INDEX ROWID BATCHED | T_INDIVIDU                   |      2 |      1 |     3   (0)|      2 |00:00:00.01 |       7 |      1 |      0 |
|* 47 |                       INDEX RANGE SCAN                   | T_INDIVIDU_RSR_IDX           |      2 |      1 |     2   (0)|      2 |00:00:00.01 |       6 |      1 |      0 |
|  48 |                     BUFFER SORT                          |                              |      1 |    148K|  1373   (1)|  12086 |00:00:00.07 |    4914 |      0 |      0 |
|  49 |                      TABLE ACCESS STORAGE FULL           | AD_DEBTORS                   |      1 |    148K|  1332   (1)|    148K|00:00:00.02 |    4914 |      0 |      0 |
|* 50 |                    INDEX RANGE SCAN                      | G_PIECEDET_STR1_IDX          |  12086 |      1 |     3   (0)|    107M|00:00:18.91 |     878K|    585 |      0 |
|* 51 |                   TABLE ACCESS BY INDEX ROWID            | G_PIECEDET                   |    107M|      1 |     4   (0)|   1083K|00:02:30.79 |      97M|  15168 |      0 |
|  52 |                 JOIN FILTER USE                          | :BF0001                      |      0 |    240K|  1984   (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|* 53 |                  TABLE ACCESS STORAGE FULL               | AD_ACCOUNT_DEBTOR_CLIENT     |      0 |    240K|  1984   (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|* 54 |                INDEX UNIQUE SCAN                         | G_PIECE_PK                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|* 55 |               TABLE ACCESS BY INDEX ROWID                | G_PIECE                      |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|  56 |              NESTED LOOPS                                |                              |      0 |      1 |  1594   (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|  57 |               NESTED LOOPS                               |                              |      0 |      1 |  1594   (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|* 58 |                HASH JOIN                                 |                              |      0 |      1 |  1592   (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|  59 |                 JOIN FILTER CREATE                       | :BF0002                      |      0 |      1 |   224   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|  60 |                  NESTED LOOPS                            |                              |      0 |      1 |   224   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|  61 |                   NESTED LOOPS                           |                              |      0 |     11 |   224   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|  62 |                    MERGE JOIN CARTESIAN                  |                              |      0 |     11 |   181   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|  63 |                     NESTED LOOPS OUTER                   |                              |      0 |      1 |    44   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|  64 |                      NESTED LOOPS                        |                              |      0 |      1 |    41   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|* 65 |                       TABLE ACCESS BY INDEX ROWID BATCHED| G_PIECE                      |      0 |     84 |    40   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|* 66 |                        INDEX RANGE SCAN                  | GP_TYPPLIB_IDX               |      0 |    119 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|  67 |                       TABLE ACCESS BY INDEX ROWID        | AD_CASE_POLICE               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|* 68 |                        INDEX UNIQUE SCAN                 | AD_CASE_POLICE_PK            |      0 |      1 |     0   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|  69 |                      TABLE ACCESS BY INDEX ROWID BATCHED | T_INDIVIDU                   |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|* 70 |                       INDEX RANGE SCAN                   | T_INDIVIDU_RSR_IDX           |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|  71 |                     BUFFER SORT                          |                              |      0 |    307 |   178   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|* 72 |                      TABLE ACCESS BY INDEX ROWID BATCHED | G_PIECE                      |      0 |    307 |   137   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|* 73 |                       INDEX RANGE SCAN                   | GP_TYPPLIB_IDX               |      0 |    436 |     6   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|* 74 |                    INDEX RANGE SCAN                      | GPDET_TYP_REF_IDX            |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|* 75 |                   TABLE ACCESS BY INDEX ROWID            | G_PIECEDET                   |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|  76 |                 JOIN FILTER USE                          | :BF0002                      |      0 |    240K|  1368   (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|* 77 |                  TABLE ACCESS STORAGE FULL               | AD_CASES                     |      0 |    240K|  1368   (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|* 78 |                INDEX RANGE SCAN                          | AD_DEBTORS_PK                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|* 79 |               TABLE ACCESS BY INDEX ROWID                | AD_DEBTORS                   |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|* 80 |        HASH JOIN                                         |                              |      0 |    332K|   393K  (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|  81 |         TABLE ACCESS STORAGE FULL                        | AD_DEBTORS                   |      0 |    148K|  1332   (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|* 82 |         HASH JOIN                                        |                              |      0 |    332K|   357K  (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|  83 |          TABLE ACCESS STORAGE FULL                       | AD_CLIENTS                   |      0 |    423 |     7   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|* 84 |          HASH JOIN RIGHT OUTER                           |                              |      0 |    332K|   357K  (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|  85 |           VIEW                                           |                              |      0 |   2281 |  5705   (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|  86 |            HASH GROUP BY                                 |                              |      0 |   2281 |  5705   (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|* 87 |             HASH JOIN OUTER                              |                              |      0 |   2281 |  5280   (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|  88 |              VIEW                                        |                              |      0 |   2281 |  2641   (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|  89 |               HASH GROUP BY                              |                              |      0 |   2281 |  2641   (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|* 90 |                TABLE ACCESS BY INDEX ROWID BATCHED       | G_PIECE                      |      0 |   2281 |  2640   (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|* 91 |                 INDEX RANGE SCAN                         | GP_TYPEDOC                   |      0 |  10789 |    68   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|* 92 |              TABLE ACCESS BY INDEX ROWID BATCHED         | G_PIECE                      |      0 |   2281 |  2639   (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|* 93 |               INDEX RANGE SCAN                           | GP_TYPEDOC                   |      0 |  10789 |    68   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|* 94 |           HASH JOIN RIGHT OUTER                          |                              |      0 |    329K|   351K  (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|  95 |            VIEW                                          |                              |      0 |    136K| 79330   (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|  96 |             UNION-ALL                                    |                              |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
|* 97 |              MAT_VIEW ACCESS STORAGE FULL                | AD_REQUEST_LIMIT_MVIEW       |      0 |  37836 | 25298   (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|  98 |              HASH UNIQUE                                 |                              |      0 |  98819 | 54032   (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|* 99 |               FILTER                                     |                              |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
|*100 |                HASH JOIN RIGHT OUTER                     |                              |      0 |  98819 | 52581   (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*101 |                 MAT_VIEW ACCESS STORAGE FULL             | AD_REQUEST_LIMIT_MVIEW       |      0 |  37836 | 25298   (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*102 |                 HASH JOIN                                |                              |      0 |    100K| 27283   (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 103 |                  JOIN FILTER CREATE                      | :BF0003                      |      0 |  66305 | 25298   (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*104 |                   MAT_VIEW ACCESS STORAGE FULL           | AD_REQUEST_LIMIT_MVIEW       |      0 |  66305 | 25298   (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 105 |                  JOIN FILTER USE                         | :BF0003                      |      0 |    240K|  1984   (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*106 |                   TABLE ACCESS STORAGE FULL              | AD_ACCOUNT_DEBTOR_CLIENT     |      0 |    240K|  1984   (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*107 |            HASH JOIN                                     |                              |      0 |    329K|   240K  (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 108 |             TABLE ACCESS STORAGE FULL                    | AD_ACCOUNT_DEBTOR_CLIENT     |      0 |    240K|  1989   (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*109 |             HASH JOIN RIGHT OUTER                        |                              |      0 |    329K|   206K  (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*110 |              TABLE ACCESS STORAGE FULL                   | V_DOMAINE                    |      0 |     13 |   512   (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*111 |              HASH JOIN OUTER                             |                              |      0 |    329K|   205K  (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*112 |               HASH JOIN OUTER                            |                              |      0 |    329K|   172K  (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 113 |                JOIN FILTER CREATE                        | :BF0004                      |      0 |    329K|  2193   (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 114 |                 TABLE ACCESS STORAGE FULL                | AD_FIPAY                     |      0 |    329K|  2193   (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 115 |                JOIN FILTER USE                           | :BF0004                      |      0 |     12M|   148K  (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*116 |                 TABLE ACCESS STORAGE FULL                | G_ENCAISSEMENT               |      0 |     12M|   148K  (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 117 |               VIEW                                       |                              |      0 |    276K|  7145   (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*118 |                VIEW                                      |                              |      0 |    276K|  7145   (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*119 |                 WINDOW SORT PUSHED RANK                  |                              |      0 |    276K|  7145   (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 120 |                  MAT_VIEW ACCESS STORAGE FULL            | AD_INFORMATION_MVIEW         |      0 |    276K|  1153   (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   2 - access("REFDOSS"="FI"."FI_REFDOSS" AND "REFELEM"="FI"."FI_REFELEM")
   3 - filter("RNK"=1)
   4 - filter(ROW_NUMBER() OVER ( PARTITION BY "REFDOSS","REFELEM" ORDER BY INTERNAL_FUNCTION("REAL_AMOUNT_DEC") DESC )<=1)
   5 - access("GVE"."RESTRICTION_CODE"="LOV"."ABREV")
   8 - access("LOV"."TYPE"='DECOMPTE_RESTRICTIONS')
  10 - storage(SYS_OP_BLOOM_FILTER(:BF0000,"GVE"."RESTRICTION_CODE"))
       filter(SYS_OP_BLOOM_FILTER(:BF0000,"GVE"."RESTRICTION_CODE"))
  11 - access("INS_UDF"."REFDOSS"="DB_CL"."CONTRACT")
  14 - filter("RNK"=1)
  15 - filter(ROW_NUMBER() OVER ( PARTITION BY "GDET"."REFDOSS","GDET"."LIB2" ORDER BY INTERNAL_FUNCTION("GDET"."IMX_UN_ID") DESC )<=1)
  16 - filter(("LIB2"='INSUR' OR "LIB2"='VERSITAT'))
  17 - access("TYPE"='UDF')
  18 - access("DB_CL"."REFDOSS"="AMT_LM_CON"."COMPTE_ID")
  21 - filter("SUB"."RNK"=1)
  22 - filter(RANK() OVER ( PARTITION BY "COMPTE_ID","FI_ID" ORDER BY INTERNAL_FUNCTION("IMX_UN_ID") DESC )<=1)
  23 - storage("LIMIT_ROLE"='COVERAGE')
       filter("LIMIT_ROLE"='COVERAGE')
  24 - access("FI"."FI_REFELEM"=DECODE("A"."TYPEREF",'PAY',NULL,"A"."REFERENCE"))
  25 - storage("FI"."FI_ACTIF"='O')
       filter("FI"."FI_ACTIF"='O')
  26 - access("A"."REFDOSS"="DEB_POL"."COMPTE_CASE")
  35 - access("DBCL"."DEBTOR"="AF"."DEBTOR_REFINDIVIDU")
  42 - filter("POL"."REFDOSS" IS NOT NULL)
  43 - access("POL"."TYPPIECE"='POLICE')
  45 - access("POL"."REFDOSS"="POL_CASE"."REFDOSS")
  47 - access("POL_CASE"."DB_REF"="CRE_INS"."REFINDIVIDU" AND "CRE_INS"."SOCIETE"='CR_INSURER')
  50 - access("GPDET"."TYPE"='ASSURANCE_CREDIT' AND "AF"."DEBTOR_PAYS"="GPDET"."STR1")
       filter("GPDET"."STR1" IS NOT NULL)
  51 - filter(("POL"."REFPIECE"=NVL("GPDET"."STR7","GPDET"."STR9") AND NVL("GPDET"."DT02_DT",SYSDATE@!)>=SYSDATE@! AND "GPDET"."DT01_DT"<=SYSDATE@!))
  53 - storage(SYS_OP_BLOOM_FILTER(:BF0001,"DBCL"."DEBTOR"))
       filter(SYS_OP_BLOOM_FILTER(:BF0001,"DBCL"."DEBTOR"))
  54 - access("GP"."REFPIECE"="GPDET"."REFPIECE")
  55 - filter(("DBCL"."REFDOSS"="GP"."REFDOSS" AND "GP"."TYPPIECE"='COMPTE' AND "GP"."REFDOSS" IS NOT NULL))
  58 - access("GP"."REFDOSS"="DBCL"."CONTRACT_CASE")
  65 - filter("POL"."REFDOSS" IS NOT NULL)
  66 - access("POL"."TYPPIECE"='POLICE')
  68 - access("POL"."REFDOSS"="POL_CASE"."REFDOSS")
  70 - access("POL_CASE"."DB_REF"="CRE_INS"."REFINDIVIDU" AND "CRE_INS"."SOCIETE"='CR_INSURER')
  72 - filter("GP"."REFDOSS" IS NOT NULL)
  73 - access("GP"."TYPPIECE"='CONTRAT')
  74 - access("GPDET"."TYPE"='ASSURANCE_CREDIT' AND "GP"."REFPIECE"="GPDET"."REFPIECE" AND "GPDET"."DT01_DT"<=SYSDATE@!)
  75 - filter(("GPDET"."STR1" IS NOT NULL AND "POL"."REFPIECE"=NVL("GPDET"."STR7","GPDET"."STR9") AND NVL("GPDET"."DT02_DT",SYSDATE@!)>=SYSDATE@!))
  77 - storage(("DBCL"."CATEGDOSS"='COMPTE' AND SYS_OP_BLOOM_FILTER(:BF0002,"DBCL"."CONTRACT_CASE")))
       filter(("DBCL"."CATEGDOSS"='COMPTE' AND SYS_OP_BLOOM_FILTER(:BF0002,"DBCL"."CONTRACT_CASE")))
  78 - access("DBCL"."DEBTOR_REF"="AF"."DEBTOR_REFINDIVIDU")
  79 - filter("AF"."DEBTOR_PAYS"="GPDET"."STR1")
  80 - access("DEBTOR"."DEBTOR_REFINDIVIDU"="DB_CL"."DEBTOR")
  82 - access("CLIENT"."CLIENT_REFINDIVIDU"="DB_CL"."CLIENT")
  84 - access("REQUEST_DECLRE"."GPIADR3"="DB_CL"."DEBTOR" AND "REQUEST_DECLRE"."GPIDEPOT"="DB_CL"."CLIENT" AND "REQUEST_DECLRE"."GPIHEURE"="DB_CL"."ANCREFDOSS")
  87 - access("CUR_LIM"."PRE_PIECE"="PRE_LIM"."REFPIECE")
  90 - filter(("LIM"."GPIROLE"='DC' OR "LIM"."GPIROLE"='DT'))
  91 - access("LIM"."TYPEDOC"='C' AND "LIM"."TYPPIECE"='REQUEST_LIMITE')
  92 - filter(("PRE_LIM"."GPIROLE"='DC' OR "PRE_LIM"."GPIROLE"='DT'))
  93 - access("PRE_LIM"."TYPEDOC"='C' AND "PRE_LIM"."TYPPIECE"='REQUEST_LIMITE')
  94 - access("FIN_LIM"."DEBTOR"="DB_CL"."DEBTOR" AND "FIN_LIM"."CLIENT"="DB_CL"."CLIENT" AND "FIN_LIM"."CONTRACT"="DB_CL"."ANCREFDOSS")
  97 - storage(("REQ"."TYPEDOC"='F' AND "REQ"."FG05"='O'))
       filter(("REQ"."TYPEDOC"='F' AND "REQ"."FG05"='O'))
  99 - filter(("REQ_NF"."GPIADR3" IS NULL AND "REQ_NF"."GPIDEPOT" IS NULL AND "REQ_NF"."GPIHEURE" IS NULL))
100 - access("REQ_DBFL"."GPIADR3"="REQ_NF"."GPIADR3" AND "DBCL_DBFL"."CLIENT"="REQ_NF"."GPIDEPOT" AND "DBCL_DBFL"."ANCREFDOSS"="REQ_NF"."GPIHEURE")
101 - storage(("REQ_NF"."TYPEDOC"='F' AND "REQ_NF"."FG05"='O'))
       filter(("REQ_NF"."TYPEDOC"='F' AND "REQ_NF"."FG05"='O'))
102 - access("REQ_DBFL"."GPIADR3"="DBCL_DBFL"."DEBTOR")
104 - storage(("REQ_DBFL"."GPIADR3" IS NOT NULL AND "REQ_DBFL"."TYPEDOC"='DBFL' AND "REQ_DBFL"."FG05"='O'))
       filter(("REQ_DBFL"."GPIADR3" IS NOT NULL AND "REQ_DBFL"."TYPEDOC"='DBFL' AND "REQ_DBFL"."FG05"='O'))
106 - storage(SYS_OP_BLOOM_FILTER(:BF0003,"DBCL_DBFL"."DEBTOR"))
       filter(SYS_OP_BLOOM_FILTER(:BF0003,"DBCL_DBFL"."DEBTOR"))
107 - access("A"."REFDOSS"="DB_CL"."REFDOSS")
109 - access("INVSTUS"."ABREV"="A"."ST09")
110 - storage("INVSTUS"."TYPE"='INVSTATUS')
       filter("INVSTUS"."TYPE"='INVSTATUS')
111 - access("INF"."EL_REFDOSS"="A"."REFDOSS" AND "INF"."GINFO_ENCODEUR"="A"."REFERENCE")
112 - access("A"."DOC_REFERENCE"="B"."REFENCAISS")
116 - storage(SYS_OP_BLOOM_FILTER(:BF0004,"B"."REFENCAISS"))
       filter(SYS_OP_BLOOM_FILTER(:BF0004,"B"."REFENCAISS"))
118 - filter("RN"=1)
119 - filter(ROW_NUMBER() OVER ( PARTITION BY "EL_REFDOSS" ORDER BY INTERNAL_FUNCTION("EL_IMX_UN_ID") DESC )<=1)

*/
/********************************OLD Metrics***************************************/

/********************************New SQL*******************************************/

SELECT *
FROM (SELECT /*+LEADING(db_cl debtor client request_declre inv fi inf invstus deb_pol) FULL(db_cl) FULL(debtor) USE_HASH(debtor) FULL(client) USE_HASH(client)
            FULL(request_declre) FULL(inv) USE_HASH(inv) FULL(fi) USE_HASH(fi) USE_HASH(inf) FULL(invstus) USE_HASH(invstus) USE_HASH(request_declre)
            USE_HASH(deb_pol) USE_HASH(fin_lim)*/
         db_cl.ANCREFDOSS AS "Contract number",
         client.client_nom AS "Client Name",
         client.client_refindividu AS "Client ID",
         db_cl.REFDOSS AS "CLDB account",
         db_cl.clcl_number AS "CLI_CLI number",
         debtor.debtor_nom AS "Debtor Name",
         debtor.debtor_refindividu AS "Debtor ID",
         debtor.debtor_pays AS "Debtor Country",
         decode(inv.typeref,'INV','Invoice',
                                  'CR','Credit note',
                                  'PAY','Non-matched payment',
                                  'Other debit') AS "Document Type",
         inv.doc_reference AS "Document Number",
         invstus.valeur_an AS "Document Status",
         inv.reminder_level AS "Dunning Level",
         (case when inv.comments is not null
              then inv.comments||' '||fi.GP_COMMENTAIRE_15 ||' '||inf.ginfo_libreinfo
         else fi.GP_COMMENTAIRE_15||' '|| inf.ginfo_libreinfo end) AS "Comments on document",
         inv.doc_date AS "Document Issue Date",
         inv.due_date AS "Document Due date",
         decode(inv.typeref,'PAY',(-1)*inv.item_amt, inv.item_amt) AS "Document Amount" ,
         decode(inv.typeref,'PAY',(-1)*inv.open_amt, inv.open_amt) AS "Open Amount of the Document",
         fi.gp_mt14 AS "Fundable amount",
         reten_reason.valeur_an AS "Retention reason",
         inv.item_ccy AS "Document Currency",
         (case when inv.item_ccy = 'EUR' then null
              else CH_TAUX.Conv_Orig_Dest_Tx(to_char(sysdate,'j'),
                                             decode(inv.typeref,'PAY',(-1)*inv.item_amt, inv.item_amt),
                                             inv.item_ccy ,
                                             'EUR' ,
                                              'MR' ,
                                             '') end) AS "Document amount calculated with current FX rate",
         (case when db_cl.devise = 'EUR' then db_cl.restprin_dos
              else CH_TAUX.Conv_Orig_Dest_Tx(to_char(sysdate,'j'),
                                             db_cl.restprin_dos,
                                             db_cl.devise,
                                             'EUR' ,
                                              'MR' ,
                                             '') end) AS "Outstanding balance of the CL/DB",
         --IMBWEB-6360
         CH_TAUX.Conv_Orig_Dest_Tx(to_char(sysdate,'j'),
                                             amt_lm_con.consumed_lim,
                                             request_declre.gpidevis,
                                             'EUR' ,
                                              'MR' ,
                                             '') AS "Insured outstanding", /*IMBWEB-6496 currency take from request limit*/
         deb_pol.nom AS "Insurance company",
         deb_pol.policy_number AS "Policy number",
         ins_udf.Insurance_quality AS "Insurance quality",
         --IMBWEB-6360
         request_declre.gpidevis AS "Limit currency (Delcredere Limit)",
         request_declre.mt02 AS "Delcredere Limit",
         --IMBWEB-6360
         --request_declre.gpidtdeb_dt AS "Start Date of Delceredere Limit",
         request_declre.dt04_dt AS "Decision date of Delcredere limit",
         request_declre.pre_Limamt AS "Previous Delcredere Limit",
         
         CH_TAUX.Conv_Orig_Dest_Tx(to_char(sysdate,'j'),
                                             request_declre.mt02,
                                             request_declre.gpidevis,
                                             'EUR' ,
                                              'MR' ,
                                             '') AS "Delcredere Limit EUR",
         --IMBWEB-6360
         fin_lim.FIN_Limit AS "FIN Limit Level 3",
         ad_jullian_date(sysdate)- ad_jullian_date(inv.due_date) AS "Document overdue",
         ad_jullian_date(sysdate)- ad_jullian_date(inv.doc_date) AS "Older than",
         null AS "Comment"
    FROM ad_account_debtor_client db_cl,
         ad_debtors debtor,
         ad_clients client,
         (SELECT /*+no_merge no_push_pred*/COMPTE_CASE,
                 NVL(pol_compt, pol_contract) policy_number,
                 NVL(str_20_1_compt, str_20_1_contract) str_20_1,
                 NVL(st02_compt, st02_compt) st02,
                 NVL(nom_compt, nom_contract) nom
            FROM (SELECT /*+no_merge no_push_pred*/ COMPTE_CASE,
                         max(pol_compt) pol_compt,
                         max(str_20_1_compt) str_20_1_compt,
                         max(st02_compt) st02_compt,
                         max(nom_compt) nom_compt,
                         max(pol_contract) pol_contract,
                         max(str_20_1_contract) str_20_1_contract,
                         max(st02_contract) st02_contract,
                         max(nom_contract) nom_contract
                   FROM (SELECT /*+ leading(pol gpdet) full(gpdet) */
                               distinct gp.refdoss COMPTE_CASE,
                               pol.refext AS pol_compt,
                               pol.str_20_1 AS str_20_1_compt,
                               pol.st02 AS st02_compt,
                               cre_ins.refext AS nom_compt,
                               NULL AS pol_contract,
                               NULL AS str_20_1_contract,
                               NULL AS st02_contract,
                               NULL AS nom_contract
                          FROM G_PIECE gp,
                               G_PIECEDET gpdet,
                               G_PIECE pol,
                               AD_CASE_POLICE pol_case,
                               AD_ACCOUNT_DEBTOR_CLIENT dbcl,
                               AD_DEBTORS af,
                               t_individu cre_ins
                          WHERE gp.TYPPIECE ='COMPTE'
                            AND gp.REFPIECE = gpdet.REFPIECE
                            AND gpdet.TYPE = 'ASSURANCE_CREDIT'
                            AND NVL(gpdet.STR7,gpdet.STR9) = pol.REFPIECE
                            AND pol.TYPPIECE ='POLICE'
                            AND pol.REFDOSS = pol_case.REFDOSS
                            AND SYSDATE BETWEEN gpdet.DT01_DT AND NVL(gpdet.DT02_DT,SYSDATE)
                            AND dbcl.REFDOSS = gp.REFDOSS
                            AND dbcl.DEBTOR = af.DEBTOR_REFINDIVIDU
                            AND af.DEBTOR_PAYS = gpdet.STR1
                            AND pol_case.db_ref = cre_ins.refindividu(+)
                            AND cre_ins.societe(+) = 'CR_INSURER'
                            UNION
                           SELECT /*+ leading(pol gpdet gp dbcl af) full(gpdet) */
                                   dbcl.refdoss AS COMPTE_CASE,
                                   NULL AS pol_compt,
                                   NULL AS str_20_1_compt,
                                   NULL AS st02_compt,
                                   NULL AS nom_compt,
                                   pol.refext AS pol_contract,
                                   pol.str_20_1 AS str_20_1_contract,
                                   pol.st02 AS st02_contract,
                                   cre_ins.refext AS nom_contract
                          FROM G_PIECE gp,
                               G_PIECEDET gpdet,
                               G_PIECE pol,
                               AD_CASE_POLICE pol_case,
                               AD_CASES dbcl,
                               AD_DEBTORS af,
                               t_individu cre_ins
                          WHERE gp.TYPPIECE ='CONTRAT'
                            AND gp.REFPIECE = gpdet.REFPIECE
                            AND gpdet.TYPE = 'ASSURANCE_CREDIT'
                            AND NVL(gpdet.STR7,gpdet.STR9) = pol.REFPIECE
                            AND pol.TYPPIECE ='POLICE'
                            AND pol.REFDOSS = pol_case.REFDOSS
                            AND gp.REFDOSS = dbcl.CONTRACT_CASE
                            AND dbcl.CATEGDOSS ='COMPTE'
                            AND SYSDATE BETWEEN gpdet.DT01_DT AND NVL(gpdet.DT02_DT,SYSDATE)
                            AND dbcl.DEBTOR_REF = af.DEBTOR_REFINDIVIDU
                            AND af.DEBTOR_PAYS = gpdet.STR1
                            AND pol_case.db_ref = cre_ins.refindividu(+)
                            AND cre_ins.societe(+) = 'CR_INSURER'
                      )group by COMPTE_CASE
                 )
         )deb_pol,
         (SELECT /*+LEADING(a b) FULL(a) FULL(b) USE_HASH(b)*/
                 a.refdoss,
                 decode(a.typeref, 'PAY', nvl(b.numchq,b.lieupaimt), a.doc_reference) doc_reference,
                 a.reminder_level,
                 a.typeref,
                 a.comments,
                 a.doc_date,
                 a.due_date,
                 a.open_amt,
                 --a.item_ccy, --IMBWEB-6360
                 (case when a.typeref = 'PAY' then b.devise_mvt else a.item_ccy end) item_ccy,
                 a.reference,
                 a.st09,
                 --IMBWEB-6360
                 (case when a.typeref = 'PAY' then b.montant_mvt else a.item_amt end) item_amt
            FROM ad_fipay a,
                 g_encaissement b
           WHERE a.doc_reference = b.refencaiss(+)
           )inv,
         ad_finelem_3nf fi,
         ( select /*+no_merge no_push_pred*/
                  el_refdoss,
                  ginfo_encodeur,
                  ginfo_libreinfo
             from ( select /*+FULL(ad_information_mview)*/
                           el_refdoss,
                           ginfo_encodeur,
                           ginfo_libreinfo,
                           row_number() over(partition by el_refdoss order by el_imx_un_id desc) rn
                      from ad_information_mview
                  )
            where rn = 1
         )inf,
         v_domaine invstus,
         (
           select /*+no_merge no_push_pred LEADING(cur_lim) INDEX(pre_lim GP_TYPEDOC)*/
                    cur_lim.gpiadr3,
                    cur_lim.gpidepot,
                    cur_lim.gpiheure,
                    max(cur_lim.gpidevis) gpidevis,
                    max(cur_lim.gpidtdeb_dt) gpidtdeb_dt,
                    max(cur_lim.mt02) mt02,
                    max(pre_lim.mt02) pre_Limamt,
                    --IMBDEV-10689
                    max(cur_lim.dt04_dt) dt04_dt
                    --cur_lim.libelle_20_12
              from g_piece pre_lim,
                   (select /*+INDEX(lim GP_TYPEDOC)*/
                           lim.gpiadr3,
                           lim.gpidepot,
                           lim.gpiheure,
                           lim.dt04_dt,
                           --lim.libelle_20_12,
                           max(decode(lim.fg05,'O',lim.gpidevis,null)) gpidevis,
                           max(decode(lim.fg05,'O',lim.gpidtdeb_dt,null)) gpidtdeb_dt,
                           max(decode(lim.fg05,'O',lim.mt02,null)) mt02,
                           max(case when lim.fg05 ='O' then lim.st04
                                when nvl(lim.fg05,'N') = 'N' then lim.refpiece else null end) pre_piece
                      from g_piece lim
                     where lim.TYPPIECE ='REQUEST_LIMITE'
                       and lim.typedoc IN ('C')
                       and lim.gpirole IN ('DC', 'DT')
                     group by lim.gpiadr3,
                              lim.gpiDEPOT,
                              lim.GPIHEURE,
                              lim.dt04_dt
                              --lim.libelle_20_12
                     )cur_lim
                 where cur_lim.pre_piece = pre_lim.refpiece(+)
                   and pre_lim.TYPPIECE(+) ='REQUEST_LIMITE'
                   and pre_lim.typedoc(+) IN ('C')
                   and pre_lim.gpirole(+) IN ('DC', 'DT')
                   group by cur_lim.gpiadr3,
                    cur_lim.gpidepot,
                    cur_lim.gpiheure
          )request_declre,
          
          (SELECT /*+FULL(req)*/
                    req.gpiadr3 debtor ,
                    req.gpidepot client,
                    req.gpiheure contract,
                    req.gpidevis gpidevis,
                    req.mt02 FIN_Limit
               FROM ad_request_limit_mview req
              WHERE req.typedoc = 'F'
                AND req.fg05 ='O'
          UNION ALL
           SELECT /*+LEADING(req_dbfl) FULL(req_dbfl) FULL(req_nf) USE_HASH(req_nf) FULL(dbcl_dbfl) SE_HASH(dbcl_dbfl)*/
                  distinct req_dbfl.gpiadr3 debtor ,
                  dbcl_dbfl.client client,
                  dbcl_dbfl.ancrefdoss contract,
                  req_dbfl.gpidevis gpidevis,
                  req_dbfl.mt02 FIN_Limit
             FROM ad_request_limit_mview req_dbfl,
                  ad_account_debtor_client dbcl_dbfl,
                  ad_request_limit_mview req_nf
            WHERE req_dbfl.typedoc = 'DBFL'
              AND req_dbfl.fg05 ='O'
              AND req_dbfl.gpiadr3 is not null
              AND req_dbfl.gpiadr3 = dbcl_dbfl.debtor
              AND req_nf.typedoc(+) = 'F'
              AND req_nf.fg05(+) ='O'
              AND req_dbfl.gpiadr3 = req_nf.gpiadr3(+)
              AND dbcl_dbfl.client = req_nf.gpidepot(+)
              AND dbcl_dbfl.ancrefdoss = req_nf.gpiheure(+)
              AND req_nf.gpiadr3 IS NULL
              AND req_nf.gpidepot IS NULL
              AND req_nf.gpiheure IS NULL
          )fin_lim,
          (SELECT refdoss, refelem, valeur_an
            FROM (SELECT /*+ full(gve)*/
                 gve.refdoss,
                 gve.refelem,
                 lov.valeur_an,
                 row_number() over(PARTITION BY refdoss, refelem ORDER BY real_amount_dec DESC) rnk
                  FROM g_venrestriction gve, v_domaine lov
                 WHERE gve.restriction_code = lov.abrev
                   AND lov.type = 'DECOMPTE_RESTRICTIONS')
         WHERE rnk = 1
         )reten_reason,
         (SELECT REFDOSS,MAX(VERSITAT)||MAX(INSUR)Insurance_quality
            FROM (
            SELECT /*+ INDEX(gdet G_PIECEDET_TYPE_LASTLOAD_IDX)*/
                   gdet.REFDOSS,gdet.REFPIECE,gdet.LIB2,
                   DECODE(gdet.LIB2,'INSUR',gdet.LIB3,NULL)INSUR,
                   DECODE(gdet.LIB2,'VERSITAT',gdet.LIB3,NULL) VERSITAT,
                   ROW_NUMBER() OVER(PARTITION BY gdet.REFDOSS,gdet.LIB2 ORDER BY gdet.IMX_UN_ID DESC) rnk
            FROM G_PIECEDET gdet
            WHERE TYPE ='UDF'
             AND LIB2 IN ('VERSITAT','INSUR')
             )
             WHERE rnk =1
             GROUP BY REFDOSS
         )ins_udf,
         --IMBDEV-10689
      (
           select compte_id,
                  limit_id,
                  sum(consumed_lim) consumed_lim
           from
           (
             select sub.compte_id,
                    sub.limit_id,
                    sub.consumed_lim
                    /*sub.fi_id*/
             from
                 (select compte_id,
                         limit_id,
                         consumed_lim,
                         fi_id,
                         RANK() OVER (PARTITION BY compte_id, fi_id ORDER BY IMX_UN_ID desc) rnk
                    from G_VENFILIMIT where limit_role='COVERAGE'
                 )sub
             where sub.rnk=1
           )
           group by compte_id, limit_id
         ) amt_lm_con
   WHERE debtor.debtor_refindividu = db_cl.debtor
     AND client.client_refindividu = db_cl.client
     AND inv.refdoss = deb_pol.COMPTE_CASE(+)
     AND inv.refdoss = db_cl.refdoss
     AND fi.fi_refelem(+) = DECODE(inv.typeref, 'PAY', NULL, inv.reference)
     AND fi.fi_actif(+) = 'O'
     --
     AND request_declre.gpiadr3(+) = db_cl.debtor
     AND request_declre.gpidepot(+) = db_cl.client
     AND request_declre.gpiheure(+) = db_cl.ancrefdoss
     AND db_cl.refdoss = amt_lm_con.compte_id(+)
     --
     AND invstus.abrev(+) = inv.st09
     AND invstus.type(+) ='INVSTATUS'
     AND inf.el_refdoss(+) = inv.refdoss
     AND inf.ginfo_encodeur(+) = inv.reference
     --
     AND fin_lim.DEBTOR(+) = db_cl.debtor
     AND fin_lim.CLIENT(+) = db_cl.client
     AND fin_lim.CONTRACT(+) = db_cl.ancrefdoss
     --
     AND reten_reason.refdoss(+) = fi.fi_refdoss
     AND reten_reason.refelem(+) = fi.fi_refelem
     AND ins_udf.REFDOSS(+) = db_cl.CONTRACT
)main_tab
ORDER BY main_tab."Client ID",main_tab."Debtor ID"; 
/********************************New SQL*******************************************/
/********************************New Metrics***************************************/
/*
Plan hash value: 2027325598
--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                              | Name                         | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  | Writes |
--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                                       |                              |      1 |        |  2807K(100)|      1 |00:00:28.90 |      11M|   9654K|  32106 |
|   1 |  SORT AGGREGATE                                        |                              |      1 |      1 |            |      1 |00:00:28.90 |      11M|   9654K|  32106 |
|   2 |   VIEW                                                 |                              |      1 |    132M|  2807K  (1)|    335K|00:00:28.89 |      11M|   9654K|  32106 |
|*  3 |    HASH JOIN RIGHT OUTER                               |                              |      1 |    132M|  2807K  (1)|    335K|00:00:28.86 |      11M|   9654K|  32106 |
|   4 |     VIEW                                               |                              |      1 |  52362 |  7557   (1)|  31787 |00:00:00.19 |   12303 |      0 |      0 |
|   5 |      HASH GROUP BY                                     |                              |      1 |  52362 |  7557   (1)|  31787 |00:00:00.19 |   12303 |      0 |      0 |
|*  6 |       VIEW                                             |                              |      1 |  58912 |  7557   (1)|  31910 |00:00:00.14 |   12303 |      0 |      0 |
|*  7 |        WINDOW SORT PUSHED RANK                         |                              |      1 |  58912 |  7557   (1)|  31910 |00:00:00.14 |   12303 |      0 |      0 |
|*  8 |         TABLE ACCESS BY INDEX ROWID BATCHED            | G_PIECEDET                   |      1 |  58912 |  7034   (1)|  35029 |00:00:00.08 |   12303 |      0 |      0 |
|*  9 |          INDEX RANGE SCAN                              | G_PIECEDET_TYPE_LASTLOAD_IDX |      1 |  70276 |   546   (0)|  70436 |00:00:00.01 |     329 |      0 |      0 |
|* 10 |     HASH JOIN RIGHT OUTER                              |                              |      1 |   7289K|  2799K  (1)|    335K|00:00:28.56 |      11M|   9654K|  32106 |
|* 11 |      VIEW                                              |                              |      1 |      9 |   344   (1)|  21585 |00:00:00.04 |    1259 |      0 |      0 |
|* 12 |       WINDOW SORT PUSHED RANK                          |                              |      1 |      9 |   344   (1)|  21585 |00:00:00.04 |    1259 |      0 |      0 |
|* 13 |        HASH JOIN                                       |                              |      1 |      9 |   343   (0)|  21591 |00:00:00.01 |    1259 |      0 |      0 |
|  14 |         JOIN FILTER CREATE                             | :BF0000                      |      1 |     13 |     2   (0)|     42 |00:00:00.01 |       2 |      0 |      0 |
|* 15 |          INDEX RANGE SCAN                              | V_DOMAINE_IND                |      1 |     13 |     2   (0)|     42 |00:00:00.01 |       2 |      0 |      0 |
|  16 |         JOIN FILTER USE                                | :BF0000                      |      1 |  21225 |   341   (0)|  21591 |00:00:00.01 |    1257 |      0 |      0 |
|* 17 |          TABLE ACCESS STORAGE FULL                     | G_VENRESTRICTION             |      1 |  21225 |   341   (0)|  21591 |00:00:00.01 |    1257 |      0 |      0 |
|* 18 |      HASH JOIN RIGHT OUTER                             |                              |      1 |   7289K|  2799K  (1)|    335K|00:00:28.43 |      11M|   9654K|  32106 |
|  19 |       VIEW                                             |                              |      1 |   5179K|   603K  (1)|  22929 |00:00:14.51 |    1832K|   1859K|  26877 |
|  20 |        HASH GROUP BY                                   |                              |      1 |   5179K|   603K  (1)|  22929 |00:00:14.51 |    1832K|   1859K|  26877 |
|* 21 |         VIEW                                           |                              |      1 |   5179K|   547K  (1)|   3639K|00:00:14.20 |    1832K|   1859K|  26877 |
|* 22 |          WINDOW SORT PUSHED RANK                       |                              |      1 |   5179K|   547K  (1)|   3639K|00:00:14.16 |    1832K|   1859K|  26877 |
|* 23 |           TABLE ACCESS STORAGE FULL                    | G_VENFILIMIT                 |      1 |   5179K|   489K  (1)|   3640K|00:00:02.02 |    1832K|   1832K|      0 |
|* 24 |       HASH JOIN RIGHT OUTER                            |                              |      1 |    332K|  2168K  (1)|    335K|00:00:13.78 |    9213K|   7795K|   5229 |
|* 25 |        TABLE ACCESS STORAGE FULL                       | AD_FINELEM_3NF               |      1 |    611K|   119K  (1)|    456K|00:00:00.24 |     450K|    450K|      0 |
|* 26 |        HASH JOIN RIGHT OUTER                           |                              |      1 |    332K|  2027K  (1)|    335K|00:00:13.12 |    8762K|   7344K|   5229 |
|  27 |         VIEW                                           |                              |      1 |      2 |  1763K  (1)|  47732 |00:00:07.39 |    7743K|   6519K|   5229 |
|  28 |          VIEW                                          |                              |      1 |      2 |  1763K  (1)|  47732 |00:00:07.38 |    7743K|   6519K|   5229 |
|  29 |           HASH GROUP BY                                |                              |      1 |      2 |  1763K  (1)|  47732 |00:00:07.38 |    7743K|   6519K|   5229 |
|  30 |            VIEW                                        |                              |      1 |      2 |  1763K  (1)|  63717 |00:00:06.99 |    7743K|   6514K|      0 |
|  31 |             SORT UNIQUE                                |                              |      1 |      2 |  1763K  (1)|  63717 |00:00:06.98 |    7743K|   6514K|      0 |
|  32 |              UNION-ALL                                 |                              |      1 |        |            |  63717 |00:00:06.90 |    7743K|   6514K|      0 |
|  33 |               NESTED LOOPS OUTER                       |                              |      1 |      1 |   881K  (1)|  16039 |00:00:01.37 |    3864K|   3257K|      0 |
|  34 |                NESTED LOOPS                            |                              |      1 |      1 |   881K  (1)|  16039 |00:00:01.35 |    3860K|   3257K|      0 |
|  35 |                 NESTED LOOPS                           |                              |      1 |      1 |   881K  (1)|  16042 |00:00:01.26 |    3812K|   3257K|      0 |
|  36 |                  NESTED LOOPS                          |                              |      1 |      1 |   881K  (1)|  16042 |00:00:01.20 |    3765K|   3257K|      0 |
|  37 |                   NESTED LOOPS                         |                              |      1 |      1 |   881K  (1)|    229K|00:00:00.81 |    3606K|   3257K|      0 |
|* 38 |                    HASH JOIN                           |                              |      1 |      1 |   881K  (1)|    229K|00:00:00.39 |    3257K|   3257K|      0 |
|* 39 |                     TABLE ACCESS BY INDEX ROWID BATCHED| G_PIECE                      |      1 |     84 |    40   (0)|    119 |00:00:00.01 |     202 |      0 |      0 |
|* 40 |                      INDEX RANGE SCAN                  | GP_TYPPLIB_IDX               |      1 |    119 |     4   (0)|    119 |00:00:00.01 |       5 |      0 |      0 |
|* 41 |                     TABLE ACCESS STORAGE FULL          | G_PIECEDET                   |      1 |  20541 |   881K  (1)|    229K|00:00:00.31 |    3257K|   3257K|      0 |
|  42 |                    TABLE ACCESS BY INDEX ROWID         | AD_CASE_POLICE               |    229K|      1 |     1   (0)|    229K|00:00:00.33 |     349K|      0 |      0 |
|* 43 |                     INDEX UNIQUE SCAN                  | AD_CASE_POLICE_PK            |    229K|      1 |     0   (0)|    229K|00:00:00.09 |      35 |      0 |      0 |
|* 44 |                   TABLE ACCESS BY INDEX ROWID          | G_PIECE                      |    229K|      1 |     2   (0)|  16042 |00:00:00.30 |     159K|      0 |      0 |
|* 45 |                    INDEX UNIQUE SCAN                   | G_PIECE_PK                   |    229K|      1 |     1   (0)|    229K|00:00:00.16 |     129K|      0 |      0 |
|  46 |                  TABLE ACCESS BY INDEX ROWID           | AD_ACCOUNT_DEBTOR_CLIENT     |  16042 |      1 |     2   (0)|  16042 |00:00:00.04 |   46677 |      0 |      0 |
|* 47 |                   INDEX UNIQUE SCAN                    | AD_ACCOUNT_DBCL_PK           |  16042 |      1 |     1   (0)|  16042 |00:00:00.02 |   30621 |      0 |      0 |
|* 48 |                 TABLE ACCESS BY INDEX ROWID BATCHED    | AD_DEBTORS                   |  16042 |      1 |     2   (0)|  16039 |00:00:00.08 |   48113 |      0 |      0 |
|* 49 |                  INDEX RANGE SCAN                      | AD_DEBTORS_PK                |  16042 |      1 |     1   (0)|  16042 |00:00:00.04 |   32135 |      0 |      0 |
|  50 |                TABLE ACCESS BY INDEX ROWID BATCHED     | T_INDIVIDU                   |  16039 |      1 |     3   (0)|  14798 |00:00:00.02 |    3481 |      0 |      0 |
|* 51 |                 INDEX RANGE SCAN                       | T_INDIVIDU_RSR_IDX           |  16039 |      1 |     2   (0)|  14798 |00:00:00.01 |    3480 |      0 |      0 |
|* 52 |               HASH JOIN OUTER                          |                              |      1 |      1 |   881K  (1)|  47678 |00:00:05.51 |    3879K|   3257K|      0 |
|  53 |                NESTED LOOPS                            |                              |      1 |      1 |   881K  (1)|  47678 |00:00:05.47 |    3879K|   3257K|      0 |
|  54 |                 NESTED LOOPS                           |                              |      1 |      1 |   881K  (1)|  47678 |00:00:05.37 |    3811K|   3257K|      0 |
|* 55 |                  HASH JOIN                             |                              |      1 |      1 |   881K  (1)|   3288K|00:00:01.15 |    3262K|   3257K|      0 |
|* 56 |                   HASH JOIN                            |                              |      1 |      1 |   881K  (1)|   7957 |00:00:00.58 |    3257K|   3257K|      0 |
|* 57 |                    HASH JOIN                           |                              |      1 |      1 |   881K  (1)|    229K|00:00:00.46 |    3257K|   3257K|      0 |
|* 58 |                     TABLE ACCESS BY INDEX ROWID BATCHED| G_PIECE                      |      1 |     84 |    40   (0)|    119 |00:00:00.01 |     202 |      0 |      0 |
|* 59 |                      INDEX RANGE SCAN                  | GP_TYPPLIB_IDX               |      1 |    119 |     4   (0)|    119 |00:00:00.01 |       5 |      0 |      0 |
|* 60 |                     TABLE ACCESS STORAGE FULL          | G_PIECEDET                   |      1 |  20541 |   881K  (1)|    229K|00:00:00.39 |    3257K|   3257K|      0 |
|* 61 |                    TABLE ACCESS BY INDEX ROWID BATCHED | G_PIECE                      |      1 |      1 |     2   (0)|    436 |00:00:00.01 |     433 |      0 |      0 |
|* 62 |                     INDEX RANGE SCAN                   | GP_TYPPLIB_IDX               |      1 |      1 |     1   (0)|    436 |00:00:00.01 |       7 |      0 |      0 |
|* 63 |                   TABLE ACCESS STORAGE FULL            | AD_CASES                     |      1 |     40 |   436   (0)|    241K|00:00:00.06 |    5040 |      0 |      0 |
|* 64 |                  TABLE ACCESS BY INDEX ROWID BATCHED   | AD_DEBTORS                   |   3288K|      1 |     2   (0)|  47678 |00:00:03.75 |     548K|      0 |      0 |
|* 65 |                   INDEX RANGE SCAN                     | AD_DEBTORS_PK                |   3288K|      1 |     1   (0)|   3288K|00:00:02.39 |     502K|      0 |      0 |
|  66 |                 TABLE ACCESS BY INDEX ROWID            | AD_CASE_POLICE               |  47678 |      1 |     1   (0)|  47678 |00:00:00.08 |   67722 |      0 |      0 |
|* 67 |                  INDEX UNIQUE SCAN                     | AD_CASE_POLICE_PK            |  47678 |      1 |     0   (0)|  47678 |00:00:00.02 |      32 |      0 |      0 |
|  68 |                TABLE ACCESS BY INDEX ROWID BATCHED     | T_INDIVIDU                   |      1 |      1 |     3   (0)|     10 |00:00:00.01 |       4 |      0 |      0 |
|* 69 |                 INDEX RANGE SCAN                       | SOC_INDIV                    |      1 |      1 |     2   (0)|     10 |00:00:00.01 |       3 |      0 |      0 |
|* 70 |         HASH JOIN                                      |                              |      1 |    332K|   264K  (1)|    335K|00:00:05.56 |    1019K|    824K|      0 |
|  71 |          TABLE ACCESS STORAGE FULL                     | AD_CLIENTS                   |      1 |    423 |     7   (0)|    423 |00:00:00.01 |      23 |      0 |      0 |
|* 72 |          HASH JOIN                                     |                              |      1 |    332K|   264K  (1)|    335K|00:00:05.46 |    1019K|    824K|      0 |
|  73 |           TABLE ACCESS STORAGE FULL                    | AD_DEBTORS                   |      1 |    148K|  1331   (1)|    148K|00:00:00.02 |    4914 |      0 |      0 |
|* 74 |           HASH JOIN RIGHT OUTER                        |                              |      1 |    332K|   263K  (1)|    335K|00:00:05.23 |    1014K|    824K|      0 |
|  75 |            VIEW                                        |                              |      1 |   2281 |  5705   (1)|  29117 |00:00:00.54 |     160K|      0 |      0 |
|  76 |             HASH GROUP BY                              |                              |      1 |   2281 |  5705   (1)|  29117 |00:00:00.54 |     160K|      0 |      0 |
|* 77 |              HASH JOIN OUTER                           |                              |      1 |   2281 |  5280   (1)|  62449 |00:00:00.50 |     160K|      0 |      0 |
|  78 |               VIEW                                     |                              |      1 |   2281 |  2641   (1)|  62449 |00:00:00.30 |     109K|      0 |      0 |
|  79 |                HASH GROUP BY                           |                              |      1 |   2281 |  2641   (1)|  62449 |00:00:00.29 |     109K|      0 |      0 |
|* 80 |                 TABLE ACCESS BY INDEX ROWID BATCHED    | G_PIECE                      |      1 |   2281 |  2640   (1)|  62450 |00:00:00.17 |     109K|      0 |      0 |
|* 81 |                  INDEX RANGE SCAN                      | GP_TYPEDOC                   |      1 |  10789 |    68   (0)|  68129 |00:00:00.01 |     997 |      0 |      0 |
|* 82 |               TABLE ACCESS BY INDEX ROWID BATCHED      | G_PIECE                      |      1 |   2281 |  2639   (1)|  62450 |00:00:00.12 |   51475 |      0 |      0 |
|* 83 |                INDEX RANGE SCAN                        | GP_TYPEDOC                   |      1 |  10789 |    68   (0)|  68129 |00:00:00.01 |     997 |      0 |      0 |
|* 84 |            HASH JOIN RIGHT OUTER                       |                              |      1 |    329K|   257K  (1)|    335K|00:00:04.52 |     853K|    824K|      0 |
|  85 |             VIEW                                       |                              |      1 |    136K| 79330   (1)|    232K|00:00:00.63 |     285K|    277K|      0 |
|  86 |              UNION-ALL                                 |                              |      1 |        |            |    232K|00:00:00.61 |     285K|    277K|      0 |
|* 87 |               MAT_VIEW ACCESS STORAGE FULL             | AD_REQUEST_LIMIT_MVIEW       |      1 |  37836 | 25298   (1)|  36847 |00:00:00.05 |   92593 |  92587 |      0 |
|  88 |               HASH UNIQUE                              |                              |      1 |  98819 | 54032   (1)|    195K|00:00:00.50 |     192K|    185K|      0 |
|* 89 |                FILTER                                  |                              |      1 |        |            |    201K|00:00:00.39 |     192K|    185K|      0 |
|* 90 |                 HASH JOIN RIGHT OUTER                  |                              |      1 |  98819 | 52581   (1)|    241K|00:00:00.39 |     192K|    185K|      0 |
|* 91 |                  MAT_VIEW ACCESS STORAGE FULL          | AD_REQUEST_LIMIT_MVIEW       |      1 |  37836 | 25298   (1)|  36847 |00:00:00.07 |   92593 |  92587 |      0 |
|* 92 |                  HASH JOIN                             |                              |      1 |    100K| 27283   (1)|    241K|00:00:00.26 |   99904 |  92587 |      0 |
|  93 |                   JOIN FILTER CREATE                   | :BF0001                      |      1 |  66305 | 25298   (1)|    148K|00:00:00.12 |   92593 |  92587 |      0 |
|* 94 |                    MAT_VIEW ACCESS STORAGE FULL        | AD_REQUEST_LIMIT_MVIEW       |      1 |  66305 | 25298   (1)|    148K|00:00:00.10 |   92593 |  92587 |      0 |
|  95 |                   JOIN FILTER USE                      | :BF0001                      |      1 |    240K|  1984   (1)|    241K|00:00:00.06 |    7310 |      0 |      0 |
|* 96 |                    TABLE ACCESS STORAGE FULL           | AD_ACCOUNT_DEBTOR_CLIENT     |      1 |    240K|  1984   (1)|    241K|00:00:00.06 |    7310 |      0 |      0 |
|* 97 |             HASH JOIN                                  |                              |      1 |    329K|   175K  (1)|    335K|00:00:03.56 |     568K|    546K|      0 |
|  98 |              TABLE ACCESS STORAGE FULL                 | AD_ACCOUNT_DEBTOR_CLIENT     |      1 |    240K|  1984   (1)|    241K|00:00:00.05 |    7310 |      0 |      0 |
|* 99 |              HASH JOIN RIGHT OUTER                     |                              |      1 |    329K|   170K  (1)|    335K|00:00:03.20 |     561K|    546K|      0 |
|*100 |               TABLE ACCESS STORAGE FULL                | V_DOMAINE                    |      1 |     13 |   512   (1)|     18 |00:00:00.01 |    1830 |      0 |      0 |
|*101 |               HASH JOIN OUTER                          |                              |      1 |    329K|   170K  (1)|    335K|00:00:03.09 |     559K|    546K|      0 |
|*102 |                HASH JOIN OUTER                         |                              |      1 |    329K|   162K  (1)|    335K|00:00:02.35 |     555K|    546K|      0 |
| 103 |                 JOIN FILTER CREATE                     | :BF0002                      |      1 |    329K|  2189   (1)|    335K|00:00:00.10 |    8300 |      0 |      0 |
| 104 |                  TABLE ACCESS STORAGE FULL             | AD_FIPAY                     |      1 |    329K|  2189   (1)|    335K|00:00:00.07 |    8300 |      0 |      0 |
| 105 |                 JOIN FILTER USE                        | :BF0002                      |      1 |     12M|   148K  (1)|    480K|00:00:01.91 |     546K|    546K|      0 |
|*106 |                  TABLE ACCESS STORAGE FULL             | G_ENCAISSEMENT               |      1 |     12M|   148K  (1)|     12M|00:00:01.36 |     546K|    546K|      0 |
| 107 |                VIEW                                    |                              |      1 |    276K|  5783   (1)|  39087 |00:00:00.50 |    4166 |      0 |      0 |
|*108 |                 VIEW                                   |                              |      1 |    276K|  5783   (1)|  39087 |00:00:00.50 |    4166 |      0 |      0 |
|*109 |                  WINDOW SORT PUSHED RANK               |                              |      1 |    276K|  5783   (1)|  39087 |00:00:00.49 |    4166 |      0 |      0 |
| 110 |                   MAT_VIEW ACCESS STORAGE FULL         | AD_INFORMATION_MVIEW         |      1 |    276K|  1153   (1)|    276K|00:00:00.03 |    4166 |      0 |      0 |
--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   3 - access("INS_UDF"."REFDOSS"="DB_CL"."CONTRACT")
   6 - filter("RNK"=1)
   7 - filter(ROW_NUMBER() OVER ( PARTITION BY "GDET"."REFDOSS","GDET"."LIB2" ORDER BY INTERNAL_FUNCTION("GDET"."IMX_UN_ID") DESC )<=1)
   8 - filter(("LIB2"='INSUR' OR "LIB2"='VERSITAT'))
   9 - access("TYPE"='UDF')
  10 - access("REFDOSS"="FI"."FI_REFDOSS" AND "REFELEM"="FI"."FI_REFELEM")
  11 - filter("RNK"=1)
  12 - filter(ROW_NUMBER() OVER ( PARTITION BY "REFDOSS","REFELEM" ORDER BY INTERNAL_FUNCTION("REAL_AMOUNT_DEC") DESC )<=1)
  13 - access("GVE"."RESTRICTION_CODE"="LOV"."ABREV")
  15 - access("LOV"."TYPE"='DECOMPTE_RESTRICTIONS')
  17 - storage(SYS_OP_BLOOM_FILTER(:BF0000,"GVE"."RESTRICTION_CODE"))
       filter(SYS_OP_BLOOM_FILTER(:BF0000,"GVE"."RESTRICTION_CODE"))
  18 - access("DB_CL"."REFDOSS"="AMT_LM_CON"."COMPTE_ID")
  21 - filter("SUB"."RNK"=1)
  22 - filter(RANK() OVER ( PARTITION BY "COMPTE_ID","FI_ID" ORDER BY INTERNAL_FUNCTION("IMX_UN_ID") DESC )<=1)
  23 - storage("LIMIT_ROLE"='COVERAGE')
       filter("LIMIT_ROLE"='COVERAGE')
  24 - access("FI"."FI_REFELEM"=DECODE("A"."TYPEREF",'PAY',NULL,"A"."REFERENCE"))
  25 - storage("FI"."FI_ACTIF"='O')
       filter("FI"."FI_ACTIF"='O')
  26 - access("A"."REFDOSS"="DEB_POL"."COMPTE_CASE")
  38 - access("POL"."REFPIECE"=NVL("GPDET"."STR7","GPDET"."STR9"))
  39 - filter("POL"."REFDOSS" IS NOT NULL)
  40 - access("POL"."TYPPIECE"='POLICE')
  41 - storage(("GPDET"."TYPE"='ASSURANCE_CREDIT' AND "GPDET"."STR1" IS NOT NULL))
       filter(("GPDET"."TYPE"='ASSURANCE_CREDIT' AND "GPDET"."STR1" IS NOT NULL AND NVL("GPDET"."DT02_DT",SYSDATE@!)>=SYSDATE@! AND "GPDET"."DT01_DT"<=SYSDATE@!))
  43 - access("POL"."REFDOSS"="POL_CASE"."REFDOSS")
  44 - filter(("GP"."TYPPIECE"='COMPTE' AND "GP"."REFDOSS" IS NOT NULL))
  45 - access("GP"."REFPIECE"="GPDET"."REFPIECE")
  47 - access("DBCL"."REFDOSS"="GP"."REFDOSS")
  48 - filter("AF"."DEBTOR_PAYS"="GPDET"."STR1")
  49 - access("DBCL"."DEBTOR"="AF"."DEBTOR_REFINDIVIDU")
  51 - access("POL_CASE"."DB_REF"="CRE_INS"."REFINDIVIDU" AND "CRE_INS"."SOCIETE"='CR_INSURER')
  52 - access("POL_CASE"."DB_REF"="CRE_INS"."REFINDIVIDU")
  55 - access("GP"."REFDOSS"="DBCL"."CONTRACT_CASE")
  56 - access("GP"."REFPIECE"="GPDET"."REFPIECE")
  57 - access("POL"."REFPIECE"=NVL("GPDET"."STR7","GPDET"."STR9"))
  58 - filter("POL"."REFDOSS" IS NOT NULL)
  59 - access("POL"."TYPPIECE"='POLICE')
  60 - storage(("GPDET"."TYPE"='ASSURANCE_CREDIT' AND "GPDET"."STR1" IS NOT NULL))
       filter(("GPDET"."TYPE"='ASSURANCE_CREDIT' AND "GPDET"."STR1" IS NOT NULL AND NVL("GPDET"."DT02_DT",SYSDATE@!)>=SYSDATE@! AND "GPDET"."DT01_DT"<=SYSDATE@!))
  61 - filter("GP"."REFDOSS" IS NOT NULL)
  62 - access("GP"."TYPPIECE"='CONTRAT')
  63 - storage("DBCL"."CATEGDOSS"='COMPTE')
       filter("DBCL"."CATEGDOSS"='COMPTE')
  64 - filter("AF"."DEBTOR_PAYS"="GPDET"."STR1")
  65 - access("DBCL"."DEBTOR_REF"="AF"."DEBTOR_REFINDIVIDU")
  67 - access("POL"."REFDOSS"="POL_CASE"."REFDOSS")
  69 - access("CRE_INS"."SOCIETE"='CR_INSURER')
  70 - access("CLIENT"."CLIENT_REFINDIVIDU"="DB_CL"."CLIENT")
  72 - access("DEBTOR"."DEBTOR_REFINDIVIDU"="DB_CL"."DEBTOR")
  74 - access("REQUEST_DECLRE"."GPIADR3"="DB_CL"."DEBTOR" AND "REQUEST_DECLRE"."GPIDEPOT"="DB_CL"."CLIENT" AND "REQUEST_DECLRE"."GPIHEURE"="DB_CL"."ANCREFDOSS")
  77 - access("CUR_LIM"."PRE_PIECE"="PRE_LIM"."REFPIECE")
  80 - filter(("LIM"."GPIROLE"='DC' OR "LIM"."GPIROLE"='DT'))
  81 - access("LIM"."TYPEDOC"='C' AND "LIM"."TYPPIECE"='REQUEST_LIMITE')
  82 - filter(("PRE_LIM"."GPIROLE"='DC' OR "PRE_LIM"."GPIROLE"='DT'))
  83 - access("PRE_LIM"."TYPEDOC"='C' AND "PRE_LIM"."TYPPIECE"='REQUEST_LIMITE')
  84 - access("FIN_LIM"."DEBTOR"="DB_CL"."DEBTOR" AND "FIN_LIM"."CLIENT"="DB_CL"."CLIENT" AND "FIN_LIM"."CONTRACT"="DB_CL"."ANCREFDOSS")
  87 - storage(("REQ"."TYPEDOC"='F' AND "REQ"."FG05"='O'))
       filter(("REQ"."TYPEDOC"='F' AND "REQ"."FG05"='O'))
  89 - filter(("REQ_NF"."GPIADR3" IS NULL AND "REQ_NF"."GPIDEPOT" IS NULL AND "REQ_NF"."GPIHEURE" IS NULL))
  90 - access("REQ_DBFL"."GPIADR3"="REQ_NF"."GPIADR3" AND "DBCL_DBFL"."CLIENT"="REQ_NF"."GPIDEPOT" AND "DBCL_DBFL"."ANCREFDOSS"="REQ_NF"."GPIHEURE")
  91 - storage(("REQ_NF"."TYPEDOC"='F' AND "REQ_NF"."FG05"='O'))
       filter(("REQ_NF"."TYPEDOC"='F' AND "REQ_NF"."FG05"='O'))
  92 - access("REQ_DBFL"."GPIADR3"="DBCL_DBFL"."DEBTOR")
  94 - storage(("REQ_DBFL"."GPIADR3" IS NOT NULL AND "REQ_DBFL"."TYPEDOC"='DBFL' AND "REQ_DBFL"."FG05"='O'))
       filter(("REQ_DBFL"."GPIADR3" IS NOT NULL AND "REQ_DBFL"."TYPEDOC"='DBFL' AND "REQ_DBFL"."FG05"='O'))
  96 - storage(SYS_OP_BLOOM_FILTER(:BF0001,"DBCL_DBFL"."DEBTOR"))
       filter(SYS_OP_BLOOM_FILTER(:BF0001,"DBCL_DBFL"."DEBTOR"))
  97 - access("A"."REFDOSS"="DB_CL"."REFDOSS")
  99 - access("INVSTUS"."ABREV"="A"."ST09")
100 - storage("INVSTUS"."TYPE"='INVSTATUS')
       filter("INVSTUS"."TYPE"='INVSTATUS')
101 - access("INF"."EL_REFDOSS"="A"."REFDOSS" AND "INF"."GINFO_ENCODEUR"="A"."REFERENCE")
102 - access("A"."DOC_REFERENCE"="B"."REFENCAISS")
106 - storage(SYS_OP_BLOOM_FILTER(:BF0002,"B"."REFENCAISS"))
       filter(SYS_OP_BLOOM_FILTER(:BF0002,"B"."REFENCAISS"))
108 - filter("RN"=1)
109 - filter(ROW_NUMBER() OVER ( PARTITION BY "EL_REFDOSS" ORDER BY INTERNAL_FUNCTION("EL_IMX_UN_ID") DESC )<=1)
*/
/********************************New Metrics***************************************/

/********************************Index statistics**********************************/

/********************************Other SQLs****************************************/          
/*

*/ 
/********************************Other SQLs****************************************/              
