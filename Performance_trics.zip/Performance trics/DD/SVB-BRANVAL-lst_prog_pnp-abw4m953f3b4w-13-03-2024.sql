/********************************************************************************
*********       E-mail subject: SVBDEV-7340
*********             Instance: BRANVAL
*********          Description: 
Problem:
From the analyze of lst_prog_pnp module on BRANVAL we found that SQL abw4m953f3b4w was responsible for 73% of the time.

Analysis:
We executed the query manually on BRANVAL and found that in makes a bad execution plan. This was caused from several things.
The first is that the tables were joined in inappropriate order which leads to selecting a lot of rows unnecessary. The exists was removed in the second UNION and the tables 
in it was directly selected as a data set which we named "dos" in the FROM clause to be possible to use hints and to point out the correct order how the tables to be joined.
Also, table g_dossier C was removed and we used table g_dossier d instead, which was moved into the "dos" data set. 
Another change that we made is instead of accessing table f_detfac from table g_dossier d, we changed the conditon to access table f_entfac from table g_dossier d and 
then from table f_entfac access table f_detfac, because this is the most selective order.
 

Suggestion:
Please check if the query is functional correct after the modifications that we made and if it is, please change the query as it is shown in the New SQL section below.

*********               SQL_ID: abw4m953f3b4w
*********      Program/Package: 
*********              Request: Dimitare Ivanov
*********               Author: Dimitar Dimitrov
********* Received e-mail date: 12/03/2024
*********      Resolution date: 13/03/2024
*********  Trace old file here: \\epox\specifs\performance\tmp\
*********  Trace new file here:
***********************************************************************************/

/********************************OLD SQL*******************************************/

var B0 VARCHAR2(32);
exec :B0 := 'dd/mm/yyyy';
var B3 NUMBER;
exec :B3 := 2460342;
var B5 NUMBER;
exec :B5 := 2460370;
var B7 VARCHAR2(32);
exec :B7 := '1504200007';
var B10 NUMBER;
exec :B10 := 2460341;
var B11 NUMBER;
exec :B11 := 2460370;
var B12 VARCHAR2(32);
exec :B12 := '';
var B15 VARCHAR2(32);
exec :B15 := 'USD';
var B16 VARCHAR2(128);
exec :B16 := 'A60039A9';
var B17 NUMBER;
exec :B17 := 0;
var B18 NUMBER;
exec :B18 := -1;
var B20 NUMBER;
exec :B20 := 0;
var B22 VARCHAR2(128);
exec :B22 := 'ALL';
var B26 NUMBER;
exec :B26 := 0;
var B30 NUMBER;
exec :B30 := 0;
var B35 NUMBER;
exec :B35 := 2;
var B36 NUMBER;
exec :B36 := 0;
var B38 VARCHAR2(128);
exec :B38 := '1504200009';
var B41 NUMBER;
exec :B41 := 1;
var B42 VARCHAR2(32);
exec :B42 := '';
var B43 VARCHAR2(32);
exec :B43 := '02/2024';
var B44 NUMBER;
exec :B44 := 0;


SELECT df_rel,
       decode(GC . type,'CORRECTION',to_char(GC . dtcorrection_dt, :b0),'.CORRECTION',to_char(GC . dtcorrection_dt, :b0),to_char(GC . dtcalc_dt, :b0)),
       decode(GC . type,'CORRECTION',to_char(GC . dtcorrection_dt, 'j'),'.CORRECTION',to_char(GC . dtcorrection_dt, 'j'),to_char(GC . dtcalc_dt, 'j')),
       SUM(nvl(GC . mt05, 0.0)),
       CASE
         WHEN GC . rate - (nvl(GC . base_rate, 0.0) + nvl(GC . margin, 0.0)) >=
              -0.000001 THEN
          GC . rate
         else
          CASE
            WHEN (nvl(GC . base_rate, 0.0) + nvl(GC . margin, 0.0)) /
                 (GC . rate * 365) < 0.1 THEN
             (nvl(GC . base_rate, 0.0) + nvl(GC . margin, 0.0)) * 100
            else
             nvl(GC . base_rate, 0.0) + nvl(GC . margin, 0.0)
          END
       END,
       SUM(decode(SIGN(nvl(MNT_DCPT, decode(df_sen, 'D', 1, 'C', -1))),-1,-1,1) * NVL(GC . montant, 0) * NVL(ef_split, 1)),
       SUM(decode(SIGN(nvl(MNT_DCPT, decode(df_sen, 'D', 1, 'C', -1))),-1,-1,1) * NVL(GC . montant_con, 0) * NVL(ef_split, 1)),
       NVL(df_taux_tva * 100, -1),
       SUM(nvl(GC . mt05, 0.0)),
       SUM(NVL(GC . fdg_amount, 0.0)),
       df_dos,
       'FUC',
       to_char(to_date(:b3, 'j'), :b0),
       to_char(to_date(:b5, 'j'), :b0),
       gc . type,
       1,
       MAX(GC . imx_un_id),
       SUM(DECODE(GC . type,'CORRECTION',DECODE(SIGN(NVL(GC . mt05, 0.0)),1,NVL(GC . mt05, 0.0),0),0)),
       SUM(DECODE(GC . type,'CORRECTION',DECODE(SIGN(NVL(GC . mt05, 0.0)),-1,NVL(GC . mt05, 0.0),0),0)),
       MAX(case WHEN GC . mt01 IS NULL AND GC . mt04 IS NULL THEN 1 else 0 END),
       GC . numfact,
       TRUNC(GC . dtcalc_dt)
  FROM g_commfin gc, 
       f_detfac d, 
       f_entfac, 
       t_ecrdos T, 
       f_parfac fp
 WHERE ef_dos IN ( SELECT refdoss
                     FROM g_dossier
                    WHERE refdoss = :b7
                    UNION ALL
                   SELECT refdoss
                     FROM g_dossier
                    WHERE reflot = :b7
                    UNION ALL
                   SELECT C . refdoss
                     FROM g_dossier C, 
                          g_dossier D
                    WHERE D . reflot = :b7
                      AND C . reflot = D . refdoss )
   AND ef_imp > :b10
   AND ef_imp <= :b11
   AND ef_imp is not NULL
   AND (    :b12 IS NULL 
         OR (     :b12 IS NOT NULL 
              AND ef_rel > :b12 ) )
   AND NVL(ef_devise_mvt, 'EUR') = NVL(:b15, NVL(ef_devise_mvt, 'EUR'))
   AND nvl(ef_createur, 'X') NOT LIKE '%e_factur%'
   AND df_cli = :b16
   AND df_num = ef_num
   AND df_dos = ef_dos
   AND df_nom IN ('FUC', 'FUCC')
   AND (    d . df_taux_tva = DECODE(:b17, 1, :b18, d . df_taux_tva) 
         OR d . df_taux_tva = DECODE(:b17, 1, DECODE(:b20, 1, 0, :b18), d . df_taux_tva) )
   AND (    :b22 = 'ALL' 
         OR (     :b22 IN ('ELSE', 'ISR') 
              AND NVL(fp . PF_TTC, 'X') = DECODE(:b22, 'ISR', 'ISR', 'ELSE', NVL(fp . PF_TTC, 'X')) 
              AND NVL(fp . PF_TTC, 'X') NOT IN ('IS0', 'HTS') 
              AND NVL(fp . PF_TTC, 'X') != DECODE(:b22, 'ELSE', 'ISR', 'Y') 
              AND d . df_taux_tva != DECODE(:b26, 1, 0, -1) )
         OR (     :b22 in ('IS0', 'HTS') 
              AND (    fp . PF_TTC = :b22 
                    OR (     NVL(fp . PF_TTC, 'X') = DECODE(:b22, 'IS0', 'ISR', 'HTS', NVL(fp . PF_TTC, 'X')) 
                         AND NVL(fp . PF_TTC, 'X') != DECODE(:b30, 1, 'IS0', 'Y') 
                         AND NVL(fp . PF_TTC, 'X') != DECODE(:b22, 'HTS', DECODE(:b30, 1, 'ISR', 'Y'), 'Y') 
                         AND NVL(fp . PF_TTC, 'X') != DECODE(:b22, 'HTS', DECODE(:b26, 0, 'HT', 'Y'), 'Y') 
                         AND d . df_taux_tva = 0 ) ) ) )
   AND df_sen = DECODE(:b35, 0, 'D', 1, 'C', df_sen)
   AND (    (     GC . type IN ('CORRECTION', '.CORRECTION') 
              AND NVL(GC . montant, 0) != 0 ) 
         OR (     GC . type <> 'CORRECTION' 
              AND GC . type <> '.CORRECTION' ) )
   AND GC . numfact = df_num
   AND nvl(T . refdoss, DECODE(:b36, 1, :b7, df_dos)) IN ( SELECT refdoss
                                                             FROM g_dossier
                                                            WHERE reflot = :b38
                                                            UNION ALL
                                                           SELECT :b38 as refdoss
                                                             FROM dual
                                                            UNION ALL
                                                           SELECT :b7 as refdoss
                                                             FROM dual
                                                            WHERE :b41 = 1 )
   AND T . ancrefdoss(+) = df_dos
   AND T . refelem(+) = df_num
   AND T . codecr(+) = upper(df_nom)
   AND fp . rowid = ( select factor_interest . getCostParams(upper(d . df_nom), :b42) from dual )
   AND fp . pf_nom = upper(d . df_nom)
   AND (    (     nvl(length(:b43), 0) != 0 
              AND NVL(fp . pf_relimp, 'M') IN ('M', 'D', 'X') AND :b44 = 0 )
         OR (     nvl(length(:b43), 0) = 0 
              AND NVL(fp . pf_relimp, 'M') = 'D') )
 GROUP BY df_rel,
          decode(GC . type, 'CORRECTION', to_char(GC . dtcorrection_dt, :b0), '.CORRECTION', to_char(GC . dtcorrection_dt, :b0), to_char(GC . dtcalc_dt, :b0)),
          decode(GC . type, 'CORRECTION', to_char(GC . dtcorrection_dt, 'j'), '.CORRECTION', to_char(GC . dtcorrection_dt, 'j'), to_char(GC . dtcalc_dt, 'j')),
          CASE
            WHEN GC .
             rate - (nvl(GC . base_rate, 0.0) + nvl(GC . margin, 0.0)) >=
                 -0.000001 THEN
             GC . rate
            else
             CASE
               WHEN (nvl(GC . base_rate, 0.0) + nvl(GC . margin, 0.0)) /
                    (GC . rate * 365) < 0.1 THEN
                (nvl(GC . base_rate, 0.0) + nvl(GC . margin, 0.0)) * 100
               else
                nvl(GC . base_rate, 0.0) + nvl(GC . margin, 0.0)
             END
          END,
          NVL(df_taux_tva * 100, -1),
          df_dos,
          gc . type,
          GC . numfact,
          TRUNC(GC . dtcalc_dt)
 UNION
SELECT '',
       to_char(gca . COMMFIN_DAY_DT, :b0) AS "Value date",
       to_char(gca . COMMFIN_DAY_DT, 'j') AS "Julian value date",
       0.0,
       GREATEST((nvl(gca . real_base_rate, 0) + nvl(gca . real_margin, 0)), nvl(gca . real_floor_rate, 0)) AS "Rate",
       gca . ROUND_COMM_AMT AS "Interest amount",
       0.0,
       0.0,
       round(gca . real_commfin_base, 2) AS "Contractual FiU Balance",
       0.0,
       gca . refdoss,
       'AII',
       case
         WHEN nvl(p . fg07, 'N') = 'O' THEN
          to_char(p . GPIDATE_DT, :b0)
         else
          to_char(to_date(:b3, 'j'), :b0)
       end,
       case
         WHEN nvl(p . fg07, 'N') = 'O' THEN
          to_char(p . GPIDATE2_DT, :b0)
         else
          to_char(to_date(:b5, 'j'), :b0)
       end,
       'AII',
       2,
       0,
       0,
       0,
       1,
       NULL,
       NULL
  FROM g_commfin_accrual gca, 
       g_dossier d, 
       g_piece p
 WHERE gca . refdoss IN ( SELECT C . refdoss
                            FROM g_dossier C
                           WHERE C . reflot = :b38
                             AND c . categdoss LIKE '%LOAN%' )
   AND p . refdoss = gca . refdoss
   AND p . typpiece = d . pieceinit
   AND (    (     p . fg07 = 'O' 
              AND to_char(COMMFIN_DAY_DT, 'j') <= :b5 )
         OR (     nvl(p . fg07, 'N') = 'N' 
              AND to_char(COMMFIN_DAY_DT, 'j') >= :b3 
              AND to_char(COMMFIN_DAY_DT, 'j') <= :b5 ) )
   AND commfin_type LIKE '%ITRBQ_VALUE_DATE%'
   AND d . refdoss = gca . refdoss
   AND nvl(d . devise, 'EUR') = NVL(:b15, nvl(d . devise, 'EUR'))
   AND EXISTS ( SELECT 1
                  FROM f_detfac, 
                       f_entfac, 
                       f_parfac fp
                 WHERE ef_imp > :b10
                   AND ef_imp <= :b11
                   AND (    :b12 IS NULL 
                         OR (     :b12 IS NOT NULL 
                              AND ef_rel > :b12 ) )
                   AND df_nom IN ('AII', 'IN')
                   AND df_dos = d . refdoss
                   AND ef_num = df_num
                   AND df_rel IS NOT NULL
                   AND df_dos = ef_dos
                   AND df_sen = DECODE(:b35, 0, 'D', 1, 'C', df_sen)
                   AND (    df_taux_tva = DECODE(:b17, 1, :b18, df_taux_tva) 
                         OR df_taux_tva = DECODE(:b17, 1, DECODE(:b20, 1, 0, :b18), df_taux_tva) )
                   AND (    :b22 = 'ALL' 
                         OR (     :b22 IN ('ELSE', 'ISR') 
                              AND NVL(fp . PF_TTC, 'X') = DECODE(:b22, 'ISR', 'ISR', 'ELSE', NVL(fp . PF_TTC, 'X')) 
                              AND NVL(fp . PF_TTC, 'X') NOT IN ('IS0', 'HTS') 
                              AND NVL(fp . PF_TTC, 'X') != DECODE(:b22, 'ELSE', 'ISR', 'Y') 
                              AND df_taux_tva != DECODE(:b26, 1, 0, -1) ) 
                         OR (     :b22 in ('IS0', 'HTS') 
                              AND (    fp . PF_TTC = :b22 
                                    OR (     NVL(fp . PF_TTC, 'X') = DECODE(:b22, 'IS0', 'ISR', 'HTS', NVL(fp . PF_TTC, 'X')) 
                                         AND NVL(fp . PF_TTC, 'X') != DECODE(:b30, 1, 'IS0', 'Y') 
                                         AND NVL(fp . PF_TTC, 'X') != DECODE(:b22, 'HTS', DECODE(:b30, 1, 'ISR', 'Y'), 'Y') 
                                         AND NVL(fp . PF_TTC, 'X') != DECODE(:b22, 'HTS', DECODE(:b26, 0, 'HT', 'Y'), 'Y') 
                                         AND df_taux_tva = 0 ) ) ) )
                   AND fp . pf_nom = upper(df_nom)
                   AND fp . rowid = ( select factor_interest . getCostParams(upper(df_nom), :b42)
                                        from dual )
                   AND (   (     :b44 = 0 
                             AND NVL(fp . pf_relimp, 'M') IN ('M', 'D', 'X') 
                             AND (    NVL(fp . pf_relimp, 'M') != 'X' 
                                   OR (     NVL(fp . pf_relimp, 'M') = 'X' 
                                        AND NOT EXISTS ( SELECT 1
                                                           FROM f_entrel CUR
                                                          WHERE CUR . er_num = df_rel
                                                            AND CUR . er_f_rel_val IS NOT NULL ) ) ) ) 
                        OR (     :b44 = 1 
                             AND NVL(fp . pf_relimp, 'M') = 'D' ) 
                        OR (     :b44 = 2 
                             AND NVL(fp . pf_relimp, 'M') = 'X' ) ) )
 ORDER BY 16, 11, 3;
/********************************OLD SQL*******************************************/
/********************************OLD Metrics***************************************/
/*
MODULE                           SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
oracle                                                                                               2024/03/11 20:37:44  2024/03/11 21:59:49         512               129983 +000000000 01:22:05.571 25%
lst_prog_pnp                                                                                         2024/03/11 20:45:14  2024/03/11 21:33:53         277                 2600 +000000000 00:48:38.399 13%
EXPORTLOANPAYMENTSCH                                                                                 2024/03/11 21:34:44  2024/03/11 21:59:49         160               636709 +000000000 00:25:05.411 8%

MODULE                           SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
lst_prog_pnp                                                                    db file sequential r 2024/03/11 20:45:14  2024/03/11 21:33:53         214                 2598 +000000000 00:48:38.399 77%
lst_prog_pnp                                                                    ON CPU               2024/03/11 20:47:27  2024/03/11 21:32:41          34                  531 +000000000 00:45:13.601 12%
lst_prog_pnp                                                                    db file parallel rea 2024/03/11 20:45:35  2024/03/11 21:33:22          28                  216 +000000000 00:47:47.201 10%
lst_prog_pnp                                            0       1184      60162 log file sync        2024/03/11 20:51:54  2024/03/11 20:51:54           1                      +000000000 00:00:00.000 0%

MODULE                           SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
lst_prog_pnp                     abw4m953f3b4w 1209821558                                            2024/03/11 20:45:55  2024/03/11 21:33:53         202                  206 +000000000 00:47:57.440 73%
lst_prog_pnp                     9bqjcvsd3q3nr 3284054457                                            2024/03/11 20:45:35  2024/03/11 21:33:22          25                  216 +000000000 00:47:47.201 9%
lst_prog_pnp                     75j8jwfhhh255   77962881                       db file sequential r 2024/03/11 20:53:36  2024/03/11 21:33:01          18                  115 +000000000 00:39:25.438 6%
lst_prog_pnp                     1p0m7j0k68zk8 3333722595                       db file sequential r 2024/03/11 20:50:01  2024/03/11 21:33:12          10                  183 +000000000 00:43:10.720 4%

INSTANCE_NUMBER SQL_ID            ELAPSED MAX_WAIT_ON     PC_OF  WAIT_TIME            GETS      READS       ROWS  ELAP/EXEC       GETS/EXEC READS/EXEC  ROWS/EXEC       EXEC PLAN_HASH_VALUE
--------------- ------------- ----------- --------------- ----- ---------- --------------- ---------- ---------- ---------- --------------- ---------- ---------- ---------- ---------------
              1 abw4m953f3b4w         763 IO              89%   747.619002        93289913      49114          0      13.63         1665891     877.04          0         56      1209821558


Plan hash value: 1209821558
-------------------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                      | Name                          | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers |
-------------------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                               |                               |      1 |        |    27 (100)|      0 |00:00:00.10 |   96593 |
|   1 |  SORT UNIQUE                                   |                               |      1 |      2 |    26   (4)|      0 |00:00:00.10 |   96593 |
|   2 |   UNION-ALL                                    |                               |      1 |        |            |      0 |00:00:00.10 |   96593 |
|   3 |    HASH GROUP BY                               |                               |      1 |      1 |    17   (6)|      0 |00:00:00.01 |      11 |
|*  4 |     FILTER                                     |                               |      1 |        |            |      0 |00:00:00.01 |      11 |
|*  5 |      FILTER                                    |                               |      1 |        |            |      0 |00:00:00.01 |      11 |
|   6 |       NESTED LOOPS                             |                               |      1 |      1 |     9   (0)|      0 |00:00:00.01 |      11 |
|   7 |        NESTED LOOPS                            |                               |      1 |    346 |     9   (0)|      0 |00:00:00.01 |      11 |
|   8 |         NESTED LOOPS OUTER                     |                               |      1 |      1 |     8   (0)|      0 |00:00:00.01 |      11 |
|   9 |          NESTED LOOPS                          |                               |      1 |      1 |     7   (0)|      0 |00:00:00.01 |      11 |
|  10 |           NESTED LOOPS                         |                               |      1 |      1 |     3   (0)|      0 |00:00:00.01 |      11 |
|  11 |            NESTED LOOPS                        |                               |      1 |      1 |     2   (0)|      0 |00:00:00.01 |      11 |
|* 12 |             TABLE ACCESS BY INDEX ROWID BATCHED| F_DETFAC                      |      1 |      4 |     1   (0)|      0 |00:00:00.01 |      11 |
|* 13 |              INDEX RANGE SCAN                  | DF_CLIREL                     |      1 |     11 |     1   (0)|      0 |00:00:00.01 |      11 |
|* 14 |             TABLE ACCESS BY INDEX ROWID BATCHED| F_PARFAC                      |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 15 |              INDEX RANGE SCAN                  | PARFAC_CL1                    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|  16 |               FAST DUAL                        |                               |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |
|* 17 |            TABLE ACCESS BY INDEX ROWID         | F_ENTFAC                      |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 18 |             INDEX UNIQUE SCAN                  | ENTFAC_CL1                    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|  19 |           VIEW                                 | VW_NSO_1                      |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|  20 |            SORT UNIQUE                         |                               |      0 |      3 |     4   (0)|      0 |00:00:00.01 |       0 |
|  21 |             UNION ALL PUSHED PREDICATE         |                               |      0 |        |            |      0 |00:00:00.01 |       0 |
|* 22 |              FILTER                            |                               |      0 |        |            |      0 |00:00:00.01 |       0 |
|* 23 |               INDEX UNIQUE SCAN                | DOS_REFDOSS                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 24 |              INDEX RANGE SCAN                  | DOS_REFDOSS_REFLOT_IDX        |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|  25 |              NESTED LOOPS                      |                               |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |
|* 26 |               INDEX RANGE SCAN                 | DOS_REFDOSS_REFLOT_IDX        |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 27 |               INDEX RANGE SCAN                 | DOS_REFDOSS_REFLOT_IDX        |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 28 |          TABLE ACCESS BY INDEX ROWID BATCHED   | T_ECRDOS                      |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 29 |           INDEX RANGE SCAN                     | TECR_REFELEM                  |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 30 |         INDEX RANGE SCAN                       | G_COMMFIN_NUMFACT_IDX         |      0 |    346 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 31 |        TABLE ACCESS BY INDEX ROWID             | G_COMMFIN                     |      0 |    261 |     1   (0)|      0 |00:00:00.01 |       0 |
|  32 |      UNION-ALL                                 |                               |      0 |        |            |      0 |00:00:00.01 |       0 |
|* 33 |       INDEX RANGE SCAN                         | DOS_REFDOSS_REFLOT_IDX        |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 34 |       FILTER                                   |                               |      0 |        |            |      0 |00:00:00.01 |       0 |
|  35 |        FAST DUAL                               |                               |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |
|* 36 |       FILTER                                   |                               |      0 |        |            |      0 |00:00:00.01 |       0 |
|  37 |        FAST DUAL                               |                               |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |
|* 38 |    FILTER                                      |                               |      1 |        |            |      0 |00:00:00.10 |   96582 |
|* 39 |     FILTER                                     |                               |      1 |        |            |      0 |00:00:00.10 |   96582 |
|  40 |      NESTED LOOPS                              |                               |      1 |      1 |     7   (0)|      0 |00:00:00.10 |   96582 |
|  41 |       NESTED LOOPS                             |                               |      1 |      4 |     7   (0)|      0 |00:00:00.10 |   96582 |
|  42 |        NESTED LOOPS                            |                               |      1 |      1 |     6   (0)|      0 |00:00:00.10 |   96582 |
|  43 |         NESTED LOOPS                           |                               |      1 |      1 |     5   (0)|      0 |00:00:00.10 |   96582 |
|  44 |          NESTED LOOPS                          |                               |      1 |     25 |     4   (0)|  20769 |00:00:00.06 |   34273 |
|  45 |           NESTED LOOPS                         |                               |      1 |     19 |     3   (0)|   2967 |00:00:00.02 |    1634 |
|  46 |            NESTED LOOPS                        |                               |      1 |     41 |     2   (0)|   2967 |00:00:00.02 |    1624 |
|* 47 |             INDEX RANGE SCAN                   | G_DOSSIER_RL_CD_RD_RF_IDX     |      1 |      1 |     1   (0)|      4 |00:00:00.01 |       3 |
|  48 |             TABLE ACCESS BY INDEX ROWID BATCHED| G_COMMFIN_ACCRUAL             |      4 |    177 |     1   (0)|   2967 |00:00:00.02 |    1621 |
|* 49 |              INDEX RANGE SCAN                  | IDX_COMFIN_ACC_REFD_CT_NF_IDX |      4 |    177 |     1   (0)|   2967 |00:00:00.01 |      52 |
|* 50 |            TABLE ACCESS BY INDEX ROWID         | G_DOSSIER                     |   2967 |      1 |     1   (0)|   2967 |00:00:00.01 |      10 |
|* 51 |             INDEX UNIQUE SCAN                  | DOS_REFDOSS                   |   2967 |      1 |     1   (0)|   2967 |00:00:00.01 |       9 |
|  52 |           INLIST ITERATOR                      |                               |   2967 |        |            |  20769 |00:00:00.04 |   32639 |
|* 53 |            TABLE ACCESS BY INDEX ROWID BATCHED | F_DETFAC                      |   5934 |      1 |     1   (0)|  20769 |00:00:00.03 |   32639 |
|* 54 |             INDEX RANGE SCAN                   | DETFAC_DOS                    |   5934 |      5 |     1   (0)|  20769 |00:00:00.01 |   11870 |
|* 55 |          TABLE ACCESS BY INDEX ROWID           | F_ENTFAC                      |  20769 |      1 |     1   (0)|      0 |00:00:00.04 |   62309 |
|* 56 |           INDEX UNIQUE SCAN                    | ENTFAC_CL1                    |  20769 |      1 |     1   (0)|  20769 |00:00:00.02 |   41540 |
|* 57 |         TABLE ACCESS BY INDEX ROWID BATCHED    | F_PARFAC                      |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 58 |          INDEX RANGE SCAN                      | PARFAC_CL1                    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|  59 |           FAST DUAL                            |                               |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |
|* 60 |        INDEX RANGE SCAN                        | PIE_REFDOSS                   |      0 |      4 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 61 |       TABLE ACCESS BY INDEX ROWID              | G_PIECE                       |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 62 |     TABLE ACCESS BY INDEX ROWID                | F_ENTREL                      |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 63 |      INDEX UNIQUE SCAN                         | ENTREL_CL1                    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
-------------------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   4 - filter( IS NOT NULL)
   5 - filter(:B11>:B10)
  12 - filter(("DF_SEN"=DECODE(:B35,0,'D',1,'C',"DF_SEN") AND ("D"."DF_TAUX_TVA"=DECODE(:B17,1,:B18,"D"."DF_TAUX_TVA") OR
              "D"."DF_TAUX_TVA"=DECODE(:B17,1,DECODE(:B20,1,0,:B18),"D"."DF_TAUX_TVA"))))
  13 - access("DF_CLI"=:B16)
       filter(("DF_NOM"='FUC' OR "DF_NOM"='FUCC'))
  14 - filter(((:B22='ALL' OR ((:B22='ELSE' OR :B22='ISR') AND NVL("FP"."PF_TTC",'X')=DECODE(:B22,'ISR','ISR','ELSE',NVL("FP"."PF_TTC",'X'))
              AND NVL("FP"."PF_TTC",'X')<>'IS0' AND NVL("FP"."PF_TTC",'X')<>'HTS' AND NVL("FP"."PF_TTC",'X')<>DECODE(:B22,'ELSE','ISR','Y') AND
              "D"."DF_TAUX_TVA"<>DECODE(:B26,1,0,(-1))) OR ((:B22='IS0' OR :B22='HTS') AND ("FP"."PF_TTC"=:B22 OR
              (NVL("FP"."PF_TTC",'X')=DECODE(:B22,'IS0','ISR','HTS',NVL("FP"."PF_TTC",'X')) AND "D"."DF_TAUX_TVA"=0 AND
              NVL("FP"."PF_TTC",'X')<>DECODE(:B30,1,'IS0','Y') AND NVL("FP"."PF_TTC",'X')<>DECODE(:B22,'HTS',DECODE(:B30,1,'ISR','Y'),'Y') AND
              NVL("FP"."PF_TTC",'X')<>DECODE(:B22,'HTS',DECODE(:B26,0,'HT','Y'),'Y'))))) AND ((:B44=0 AND NVL(LENGTH(:B43),0)<>0 AND
              (NVL("FP"."PF_RELIMP",'M')='M' OR NVL("FP"."PF_RELIMP",'M')='D' OR NVL("FP"."PF_RELIMP",'M')='X')) OR (NVL(LENGTH(:B43),0)=0 AND
              NVL("FP"."PF_RELIMP",'M')='D'))))
  15 - access("FP"."PF_NOM"=UPPER("D"."DF_NOM"))
       filter("FP".ROWID=CHARTOROWID())
  17 - filter(((:B12 IS NULL OR (:B12 IS NOT NULL AND "EF_REL">:B12)) AND "EF_IMP">:B10 AND "DF_DOS"="EF_DOS" AND NVL("EF_CREATEUR",'X') NOT
              LIKE '%e_factur%' AND NVL("EF_DEVISE_MVT",'EUR')=NVL(:B15,NVL("EF_DEVISE_MVT",'EUR')) AND "EF_IMP"<=:B11))
  18 - access("DF_NUM"="EF_NUM")
  22 - filter("EF_DOS"=:B7)
  23 - access("REFDOSS"=:B7)
  24 - access("REFDOSS"="EF_DOS" AND "REFLOT"=:B7)
  26 - access("C"."REFDOSS"="EF_DOS")
       filter("C"."REFLOT" IS NOT NULL)
  27 - access("C"."REFLOT"="D"."REFDOSS" AND "D"."REFLOT"=:B7)
  28 - filter(("T"."ANCREFDOSS" IS NOT NULL AND "T"."ANCREFDOSS"="DF_DOS" AND "T"."CODECR"=UPPER("D"."DF_NOM")))
  29 - access("T"."REFELEM"="DF_NUM")
  30 - access("GC"."NUMFACT"="DF_NUM")
       filter("GC"."NUMFACT" IS NOT NULL)
  31 - filter((("GC"."TYPE"<>'CORRECTION' AND "GC"."TYPE"<>'.CORRECTION') OR (INTERNAL_FUNCTION("GC"."TYPE") AND NVL("GC"."MONTANT",0)<>0)))
  33 - access("REFDOSS"=NVL(:B1,DECODE(:B36,1,:B7,:B2)) AND "REFLOT"=:B38)
  34 - filter(NVL(:B1,DECODE(:B36,1,:B7,:B2))=:B38)
  36 - filter((:B41=1 AND NVL(:B1,DECODE(:B36,1,:B7,:B2))=:B7))
  38 - filter(((:B44=1 AND NVL("FP"."PF_RELIMP",'M')='D') OR (:B44=2 AND NVL("FP"."PF_RELIMP",'M')='X') OR (:B44=0 AND
              (NVL("FP"."PF_RELIMP",'M')='M' OR NVL("FP"."PF_RELIMP",'M')='D' OR NVL("FP"."PF_RELIMP",'M')='X') AND (NVL("FP"."PF_RELIMP",'M')<>'X' OR
              (NVL("FP"."PF_RELIMP",'M')='X' AND  IS NULL)))))
  39 - filter(:B11>:B10)
  47 - access("C"."REFLOT"=:B38)
       filter("C"."CATEGDOSS" LIKE '%LOAN%')
  49 - access("GCA"."REFDOSS"="C"."REFDOSS")
       filter(("COMMFIN_TYPE" LIKE '%ITRBQ_VALUE_DATE%' AND "COMMFIN_TYPE" IS NOT NULL))
  50 - filter(NVL("D"."DEVISE",'EUR')=NVL(:B15,NVL("D"."DEVISE",'EUR')))
  51 - access("D"."REFDOSS"="GCA"."REFDOSS")
  53 - filter(("DF_REL" IS NOT NULL AND "DF_SEN"=DECODE(:B35,0,'D',1,'C',"DF_SEN") AND ("DF_TAUX_TVA"=DECODE(:B17,1,:B18,"DF_TAUX_TVA") OR
              "DF_TAUX_TVA"=DECODE(:B17,1,DECODE(:B20,1,0,:B18),"DF_TAUX_TVA"))))
  54 - access("DF_DOS"="D"."REFDOSS" AND (("DF_NOM"='AII' OR "DF_NOM"='IN')))
  55 - filter(((:B12 IS NULL OR (:B12 IS NOT NULL AND "EF_REL">:B12)) AND "EF_IMP">:B10 AND "DF_DOS"="EF_DOS" AND "EF_IMP"<=:B11))
  56 - access("EF_NUM"="DF_NUM")
  57 - filter((:B22='ALL' OR ((:B22='ELSE' OR :B22='ISR') AND NVL("FP"."PF_TTC",'X')=DECODE(:B22,'ISR','ISR','ELSE',NVL("FP"."PF_TTC",'X'))
              AND NVL("FP"."PF_TTC",'X')<>'IS0' AND NVL("FP"."PF_TTC",'X')<>'HTS' AND NVL("FP"."PF_TTC",'X')<>DECODE(:B22,'ELSE','ISR','Y') AND
              "DF_TAUX_TVA"<>DECODE(:B26,1,0,(-1))) OR ((:B22='IS0' OR :B22='HTS') AND ("FP"."PF_TTC"=:B22 OR
              (NVL("FP"."PF_TTC",'X')=DECODE(:B22,'IS0','ISR','HTS',NVL("FP"."PF_TTC",'X')) AND "DF_TAUX_TVA"=0 AND
              NVL("FP"."PF_TTC",'X')<>DECODE(:B30,1,'IS0','Y') AND NVL("FP"."PF_TTC",'X')<>DECODE(:B22,'HTS',DECODE(:B30,1,'ISR','Y'),'Y') AND
              NVL("FP"."PF_TTC",'X')<>DECODE(:B22,'HTS',DECODE(:B26,0,'HT','Y'),'Y'))))))
  58 - access("FP"."PF_NOM"=UPPER("DF_NOM"))
       filter("FP".ROWID=CHARTOROWID())
  60 - access("P"."REFDOSS"="GCA"."REFDOSS" AND "P"."TYPPIECE"="D"."PIECEINIT")
       filter("P"."REFDOSS" IS NOT NULL)
  61 - filter((("P"."FG07"='O' AND TO_NUMBER(TO_CHAR(INTERNAL_FUNCTION("COMMFIN_DAY_DT"),'j'))<=:B5) OR (NVL("P"."FG07",'N')='N' AND
              TO_NUMBER(TO_CHAR(INTERNAL_FUNCTION("COMMFIN_DAY_DT"),'j'))>=:B3 AND TO_NUMBER(TO_CHAR(INTERNAL_FUNCTION("COMMFIN_DAY_DT"),'j'))<=:B5)))
  62 - filter("CUR"."ER_F_REL_VAL" IS NOT NULL)
  63 - access("CUR"."ER_NUM"=:B1)

*/
/********************************OLD Metrics***************************************/

/********************************New SQL*******************************************/

SELECT /*+ no_merge(dos) no_push_pred(dos) leading(dos f_entfac)*/
       df_rel,
       decode(GC . type,'CORRECTION',to_char(GC . dtcorrection_dt, :b0),'.CORRECTION',to_char(GC . dtcorrection_dt, :b0),to_char(GC . dtcalc_dt, :b0)),
       decode(GC . type,'CORRECTION',to_char(GC . dtcorrection_dt, 'j'),'.CORRECTION',to_char(GC . dtcorrection_dt, 'j'),to_char(GC . dtcalc_dt, 'j')),
       SUM(nvl(GC . mt05, 0.0)),
       CASE
         WHEN GC . rate - (nvl(GC . base_rate, 0.0) + nvl(GC . margin, 0.0)) >=
              -0.000001 THEN
          GC . rate
         else
          CASE
            WHEN (nvl(GC . base_rate, 0.0) + nvl(GC . margin, 0.0)) /
                 (GC . rate * 365) < 0.1 THEN
             (nvl(GC . base_rate, 0.0) + nvl(GC . margin, 0.0)) * 100
            else
             nvl(GC . base_rate, 0.0) + nvl(GC . margin, 0.0)
          END
       END,
       SUM(decode(SIGN(nvl(MNT_DCPT, decode(df_sen, 'D', 1, 'C', -1))),-1,-1,1) * NVL(GC . montant, 0) * NVL(ef_split, 1)),
       SUM(decode(SIGN(nvl(MNT_DCPT, decode(df_sen, 'D', 1, 'C', -1))),-1,-1,1) * NVL(GC . montant_con, 0) * NVL(ef_split, 1)),
       NVL(df_taux_tva * 100, -1),
       SUM(nvl(GC . mt05, 0.0)),
       SUM(NVL(GC . fdg_amount, 0.0)),
       df_dos,
       'FUC',
       to_char(to_date(:b3, 'j'), :b0),
       to_char(to_date(:b5, 'j'), :b0),
       gc . type,
       1,
       MAX(GC . imx_un_id),
       SUM(DECODE(GC . type,'CORRECTION',DECODE(SIGN(NVL(GC . mt05, 0.0)),1,NVL(GC . mt05, 0.0),0),0)),
       SUM(DECODE(GC . type,'CORRECTION',DECODE(SIGN(NVL(GC . mt05, 0.0)),-1,NVL(GC . mt05, 0.0),0),0)),
       MAX(case WHEN GC . mt01 IS NULL AND GC . mt04 IS NULL THEN 1 else 0 END),
       GC . numfact,
       TRUNC(GC . dtcalc_dt)
  FROM g_commfin gc, 
       f_detfac d, 
       f_entfac, 
       t_ecrdos T, 
       f_parfac fp
 WHERE ef_dos IN ( SELECT refdoss
                     FROM g_dossier
                    WHERE refdoss = :b7
                    UNION ALL
                   SELECT refdoss
                     FROM g_dossier
                    WHERE reflot = :b7
                    UNION ALL
                   SELECT C . refdoss
                     FROM g_dossier C, 
                          g_dossier D
                    WHERE D . reflot = :b7
                      AND C . reflot = D . refdoss )
   AND ef_imp > :b10
   AND ef_imp <= :b11
   AND ef_imp is not NULL
   AND (    :b12 IS NULL 
         OR (     :b12 IS NOT NULL 
              AND ef_rel > :b12 ) )
   AND NVL(ef_devise_mvt, 'EUR') = NVL(:b15, NVL(ef_devise_mvt, 'EUR'))
   AND nvl(ef_createur, 'X') NOT LIKE '%e_factur%'
   AND df_cli = :b16
   AND df_num = ef_num
   AND df_dos = ef_dos
   AND df_nom IN ('FUC', 'FUCC')
   AND (    d . df_taux_tva = DECODE(:b17, 1, :b18, d . df_taux_tva) 
         OR d . df_taux_tva = DECODE(:b17, 1, DECODE(:b20, 1, 0, :b18), d . df_taux_tva) )
   AND (    :b22 = 'ALL' 
         OR (     :b22 IN ('ELSE', 'ISR') 
              AND NVL(fp . PF_TTC, 'X') = DECODE(:b22, 'ISR', 'ISR', 'ELSE', NVL(fp . PF_TTC, 'X')) 
              AND NVL(fp . PF_TTC, 'X') NOT IN ('IS0', 'HTS') 
              AND NVL(fp . PF_TTC, 'X') != DECODE(:b22, 'ELSE', 'ISR', 'Y') 
              AND d . df_taux_tva != DECODE(:b26, 1, 0, -1) )
         OR (     :b22 in ('IS0', 'HTS') 
              AND (    fp . PF_TTC = :b22 
                    OR (     NVL(fp . PF_TTC, 'X') = DECODE(:b22, 'IS0', 'ISR', 'HTS', NVL(fp . PF_TTC, 'X')) 
                         AND NVL(fp . PF_TTC, 'X') != DECODE(:b30, 1, 'IS0', 'Y') 
                         AND NVL(fp . PF_TTC, 'X') != DECODE(:b22, 'HTS', DECODE(:b30, 1, 'ISR', 'Y'), 'Y') 
                         AND NVL(fp . PF_TTC, 'X') != DECODE(:b22, 'HTS', DECODE(:b26, 0, 'HT', 'Y'), 'Y') 
                         AND d . df_taux_tva = 0 ) ) ) )
   AND df_sen = DECODE(:b35, 0, 'D', 1, 'C', df_sen)
   AND (    (     GC . type IN ('CORRECTION', '.CORRECTION') 
              AND NVL(GC . montant, 0) != 0 ) 
         OR (     GC . type <> 'CORRECTION' 
              AND GC . type <> '.CORRECTION' ) )
   AND GC . numfact = df_num
   AND nvl(T . refdoss, DECODE(:b36, 1, :b7, df_dos)) IN ( SELECT refdoss
                                                             FROM g_dossier
                                                            WHERE reflot = :b38
                                                            UNION ALL
                                                           SELECT :b38 as refdoss
                                                             FROM dual
                                                            UNION ALL
                                                           SELECT :b7 as refdoss
                                                             FROM dual
                                                            WHERE :b41 = 1 )
   AND T . ancrefdoss(+) = df_dos
   AND T . refelem(+) = df_num
   AND T . codecr(+) = upper(df_nom)
   AND fp . rowid = ( select factor_interest . getCostParams(upper(d . df_nom), :b42) from dual )
   AND fp . pf_nom = upper(d . df_nom)
   AND (    (     nvl(length(:b43), 0) != 0 
              AND NVL(fp . pf_relimp, 'M') IN ('M', 'D', 'X') AND :b44 = 0 )
         OR (     nvl(length(:b43), 0) = 0 
              AND NVL(fp . pf_relimp, 'M') = 'D') )
 GROUP BY df_rel,
          decode(GC . type, 'CORRECTION', to_char(GC . dtcorrection_dt, :b0), '.CORRECTION', to_char(GC . dtcorrection_dt, :b0), to_char(GC . dtcalc_dt, :b0)),
          decode(GC . type, 'CORRECTION', to_char(GC . dtcorrection_dt, 'j'), '.CORRECTION', to_char(GC . dtcorrection_dt, 'j'), to_char(GC . dtcalc_dt, 'j')),
          CASE
            WHEN GC .
             rate - (nvl(GC . base_rate, 0.0) + nvl(GC . margin, 0.0)) >=
                 -0.000001 THEN
             GC . rate
            else
             CASE
               WHEN (nvl(GC . base_rate, 0.0) + nvl(GC . margin, 0.0)) /
                    (GC . rate * 365) < 0.1 THEN
                (nvl(GC . base_rate, 0.0) + nvl(GC . margin, 0.0)) * 100
               else
                nvl(GC . base_rate, 0.0) + nvl(GC . margin, 0.0)
             END
          END,
          NVL(df_taux_tva * 100, -1),
          df_dos,
          gc . type,
          GC . numfact,
          TRUNC(GC . dtcalc_dt)
 UNION
SELECT /*+ leading(dos p gpa)*/
       '',
       to_char(gca . COMMFIN_DAY_DT, :b0) AS "Value date",
       to_char(gca . COMMFIN_DAY_DT, 'j') AS "Julian value date",
       0.0,
       GREATEST((nvl(gca . real_base_rate, 0) + nvl(gca . real_margin, 0)), nvl(gca . real_floor_rate, 0)) AS "Rate",
       gca . ROUND_COMM_AMT AS "Interest amount",
       0.0,
       0.0,
       round(gca . real_commfin_base, 2) AS "Contractual FiU Balance",
       0.0,
       gca . refdoss,
       'AII',
       case
         WHEN nvl(p . fg07, 'N') = 'O' THEN
          to_char(p . GPIDATE_DT, :b0)
         else
          to_char(to_date(:b3, 'j'), :b0)
       end,
       case
         WHEN nvl(p . fg07, 'N') = 'O' THEN
          to_char(p . GPIDATE2_DT, :b0)
         else
          to_char(to_date(:b5, 'j'), :b0)
       end,
       'AII',
       2,
       0,
       0,
       0,
       1,
       NULL,
       NULL
  FROM g_commfin_accrual gca,  
       g_piece p,
       ( SELECT /*+ leading(d f_entfac f_detfac fp) */
                DISTINCT refdoss,
                       pieceinit
                  FROM f_detfac, 
                       f_entfac, 
                       f_parfac fp,
                       g_dossier d
                 WHERE ef_imp > :b10
                   AND ef_imp <= :b11
                   AND (    :b12 IS NULL 
                         OR (     :b12 IS NOT NULL 
                              AND ef_rel > :b12 ) )
                   AND df_nom IN ('AII', 'IN')
                   AND d . reflot = :b38
                   AND d . categdoss LIKE '%LOAN%'
                   AND nvl(d . devise, 'EUR') = NVL(:b15, nvl(d . devise, 'EUR')) 
                   AND ef_dos = d . refdoss
                   AND ef_num = df_num
                   AND df_rel IS NOT NULL
                   AND df_dos = ef_dos
                   AND df_sen = DECODE(:b35, 0, 'D', 1, 'C', df_sen)
                   AND (    df_taux_tva = DECODE(:b17, 1, :b18, df_taux_tva) 
                         OR df_taux_tva = DECODE(:b17, 1, DECODE(:b20, 1, 0, :b18), df_taux_tva) )
                   AND (    :b22 = 'ALL' 
                         OR (     :b22 IN ('ELSE', 'ISR') 
                              AND NVL(fp . PF_TTC, 'X') = DECODE(:b22, 'ISR', 'ISR', 'ELSE', NVL(fp . PF_TTC, 'X')) 
                              AND NVL(fp . PF_TTC, 'X') NOT IN ('IS0', 'HTS') 
                              AND NVL(fp . PF_TTC, 'X') != DECODE(:b22, 'ELSE', 'ISR', 'Y') 
                              AND df_taux_tva != DECODE(:b26, 1, 0, -1) ) 
                         OR (     :b22 in ('IS0', 'HTS') 
                              AND (    fp . PF_TTC = :b22 
                                    OR (     NVL(fp . PF_TTC, 'X') = DECODE(:b22, 'IS0', 'ISR', 'HTS', NVL(fp . PF_TTC, 'X')) 
                                         AND NVL(fp . PF_TTC, 'X') != DECODE(:b30, 1, 'IS0', 'Y') 
                                         AND NVL(fp . PF_TTC, 'X') != DECODE(:b22, 'HTS', DECODE(:b30, 1, 'ISR', 'Y'), 'Y') 
                                         AND NVL(fp . PF_TTC, 'X') != DECODE(:b22, 'HTS', DECODE(:b26, 0, 'HT', 'Y'), 'Y') 
                                         AND df_taux_tva = 0 ) ) ) )
                   AND fp . pf_nom = upper(df_nom)
                   AND fp . rowid = ( select factor_interest . getCostParams(upper(df_nom), :b42)
                                        from dual )
                   AND (   (     :b44 = 0 
                             AND NVL(fp . pf_relimp, 'M') IN ('M', 'D', 'X') 
                             AND (    NVL(fp . pf_relimp, 'M') != 'X' 
                                   OR (     NVL(fp . pf_relimp, 'M') = 'X' 
                                        AND NOT EXISTS ( SELECT 1
                                                           FROM f_entrel CUR
                                                          WHERE CUR . er_num = df_rel
                                                            AND CUR . er_f_rel_val IS NOT NULL ) ) ) ) 
                        OR (     :b44 = 1 
                             AND NVL(fp . pf_relimp, 'M') = 'D' ) 
                        OR (     :b44 = 2 
                             AND NVL(fp . pf_relimp, 'M') = 'X' ) ) ) dos
 WHERE gca . refdoss = dos . refdoss
   AND p . typpiece = dos  . pieceinit
   AND p. refdoss = dos . refdoss
   AND (    (     p . fg07 = 'O' 
              AND to_char(COMMFIN_DAY_DT, 'j') <= :b5 )
         OR (     nvl(p . fg07, 'N') = 'N' 
              AND to_char(COMMFIN_DAY_DT, 'j') >= :b3 
              AND to_char(COMMFIN_DAY_DT, 'j') <= :b5 ) )
   AND commfin_type LIKE '%ITRBQ_VALUE_DATE%'
 ORDER BY 16, 11, 3;
/********************************New SQL*******************************************/
/********************************New Metrics***************************************/
/*
Plan hash value: 3437884106
----------------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                       | Name                      | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers |
----------------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                                |                           |      1 |        |    27 (100)|      0 |00:00:00.01 |      66 |
|   1 |  SORT UNIQUE                                    |                           |      1 |      2 |    26   (8)|      0 |00:00:00.01 |      66 |
|   2 |   UNION-ALL                                     |                           |      1 |        |            |      0 |00:00:00.01 |      66 |
|   3 |    HASH GROUP BY                                |                           |      1 |      1 |    17   (6)|      0 |00:00:00.01 |      11 |
|*  4 |     FILTER                                      |                           |      1 |        |            |      0 |00:00:00.01 |      11 |
|*  5 |      FILTER                                     |                           |      1 |        |            |      0 |00:00:00.01 |      11 |
|   6 |       NESTED LOOPS                              |                           |      1 |      1 |     9   (0)|      0 |00:00:00.01 |      11 |
|   7 |        NESTED LOOPS                             |                           |      1 |    346 |     9   (0)|      0 |00:00:00.01 |      11 |
|   8 |         NESTED LOOPS OUTER                      |                           |      1 |      1 |     8   (0)|      0 |00:00:00.01 |      11 |
|   9 |          NESTED LOOPS                           |                           |      1 |      1 |     7   (0)|      0 |00:00:00.01 |      11 |
|  10 |           NESTED LOOPS                          |                           |      1 |      1 |     3   (0)|      0 |00:00:00.01 |      11 |
|  11 |            NESTED LOOPS                         |                           |      1 |      1 |     2   (0)|      0 |00:00:00.01 |      11 |
|* 12 |             TABLE ACCESS BY INDEX ROWID BATCHED | F_DETFAC                  |      1 |      4 |     1   (0)|      0 |00:00:00.01 |      11 |
|* 13 |              INDEX RANGE SCAN                   | DF_CLIREL                 |      1 |     11 |     1   (0)|      0 |00:00:00.01 |      11 |
|* 14 |             TABLE ACCESS BY INDEX ROWID BATCHED | F_PARFAC                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 15 |              INDEX RANGE SCAN                   | PARFAC_CL1                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|  16 |               FAST DUAL                         |                           |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |
|* 17 |            TABLE ACCESS BY INDEX ROWID          | F_ENTFAC                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 18 |             INDEX UNIQUE SCAN                   | ENTFAC_CL1                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|  19 |           VIEW                                  | VW_NSO_1                  |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|  20 |            SORT UNIQUE                          |                           |      0 |      3 |     4   (0)|      0 |00:00:00.01 |       0 |
|  21 |             UNION ALL PUSHED PREDICATE          |                           |      0 |        |            |      0 |00:00:00.01 |       0 |
|* 22 |              FILTER                             |                           |      0 |        |            |      0 |00:00:00.01 |       0 |
|* 23 |               INDEX UNIQUE SCAN                 | DOS_REFDOSS               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 24 |              INDEX RANGE SCAN                   | DOS_REFDOSS_REFLOT_IDX    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|  25 |              NESTED LOOPS                       |                           |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |
|* 26 |               INDEX RANGE SCAN                  | DOS_REFDOSS_REFLOT_IDX    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 27 |               INDEX RANGE SCAN                  | DOS_REFDOSS_REFLOT_IDX    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 28 |          TABLE ACCESS BY INDEX ROWID BATCHED    | T_ECRDOS                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 29 |           INDEX RANGE SCAN                      | TECR_REFELEM              |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 30 |         INDEX RANGE SCAN                        | G_COMMFIN_NUMFACT_IDX     |      0 |    346 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 31 |        TABLE ACCESS BY INDEX ROWID              | G_COMMFIN                 |      0 |    261 |     1   (0)|      0 |00:00:00.01 |       0 |
|  32 |      UNION-ALL                                  |                           |      0 |        |            |      0 |00:00:00.01 |       0 |
|* 33 |       INDEX RANGE SCAN                          | DOS_REFDOSS_REFLOT_IDX    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 34 |       FILTER                                    |                           |      0 |        |            |      0 |00:00:00.01 |       0 |
|  35 |        FAST DUAL                                |                           |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |
|* 36 |       FILTER                                    |                           |      0 |        |            |      0 |00:00:00.01 |       0 |
|  37 |        FAST DUAL                                |                           |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |
|  38 |    VIEW                                         | VM_NWVW_2                 |      1 |      1 |     9  (12)|      0 |00:00:00.01 |      55 |
|  39 |     HASH UNIQUE                                 |                           |      1 |      1 |     9  (12)|      0 |00:00:00.01 |      55 |
|* 40 |      FILTER                                     |                           |      1 |        |            |      0 |00:00:00.01 |      55 |
|* 41 |       FILTER                                    |                           |      1 |        |            |      0 |00:00:00.01 |      55 |
|  42 |        NESTED LOOPS                             |                           |      1 |      1 |     6   (0)|      0 |00:00:00.01 |      55 |
|  43 |         NESTED LOOPS                            |                           |      1 |      1 |     6   (0)|      0 |00:00:00.01 |      55 |
|  44 |          NESTED LOOPS                           |                           |      1 |      1 |     5   (0)|      0 |00:00:00.01 |      55 |
|  45 |           NESTED LOOPS                          |                           |      1 |      1 |     4   (0)|      0 |00:00:00.01 |      55 |
|  46 |            NESTED LOOPS                         |                           |      1 |      1 |     3   (0)|      0 |00:00:00.01 |      55 |
|  47 |             NESTED LOOPS                        |                           |      1 |      1 |     2   (0)|     12 |00:00:00.01 |      29 |
|* 48 |              TABLE ACCESS BY INDEX ROWID BATCHED| G_DOSSIER                 |      1 |      1 |     1   (0)|      4 |00:00:00.01 |       7 |
|* 49 |               INDEX RANGE SCAN                  | G_DOSSIER_RL_CD_RD_RF_IDX |      1 |      1 |     1   (0)|      4 |00:00:00.01 |       3 |
|* 50 |              TABLE ACCESS BY INDEX ROWID BATCHED| F_ENTFAC                  |      4 |      1 |     1   (0)|     12 |00:00:00.01 |      22 |
|* 51 |               INDEX RANGE SCAN                  | EF_DOS_IDX                |      4 |      1 |     1   (0)|     12 |00:00:00.01 |      10 |
|* 52 |             TABLE ACCESS BY INDEX ROWID BATCHED | F_DETFAC                  |     12 |      1 |     1   (0)|      0 |00:00:00.01 |      26 |
|* 53 |              INDEX RANGE SCAN                   | AK_DFNUM_DFNOM_F_DETFAC   |     12 |      1 |     1   (0)|      0 |00:00:00.01 |      26 |
|* 54 |            TABLE ACCESS BY INDEX ROWID BATCHED  | F_PARFAC                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 55 |             INDEX RANGE SCAN                    | PARFAC_CL1                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|  56 |              FAST DUAL                          |                           |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |
|  57 |           TABLE ACCESS BY INDEX ROWID BATCHED   | G_PIECE                   |      0 |      4 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 58 |            INDEX RANGE SCAN                     | PIE_REFDOSS               |      0 |      4 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 59 |          INDEX RANGE SCAN                       | IDX_COMMFIN_ACCRUAL       |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|  60 |         TABLE ACCESS BY INDEX ROWID             | G_COMMFIN_ACCRUAL         |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 61 |       TABLE ACCESS BY INDEX ROWID               | F_ENTREL                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 62 |        INDEX UNIQUE SCAN                        | ENTREL_CL1                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
----------------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   4 - filter( IS NOT NULL)
   5 - filter(:B11>:B10)
  12 - filter(("DF_SEN"=DECODE(:B35,0,'D',1,'C',"DF_SEN") AND ("D"."DF_TAUX_TVA"=DECODE(:B17,1,:B18,"D"."DF_TAUX_TVA") OR
              "D"."DF_TAUX_TVA"=DECODE(:B17,1,DECODE(:B20,1,0,:B18),"D"."DF_TAUX_TVA"))))
  13 - access("DF_CLI"=:B16)
       filter(("DF_NOM"='FUC' OR "DF_NOM"='FUCC'))
  14 - filter(((:B22='ALL' OR ((:B22='ELSE' OR :B22='ISR') AND NVL("FP"."PF_TTC",'X')=DECODE(:B22,'ISR','ISR','ELSE',NVL("FP"."PF_TTC",'X'))
               AND NVL("FP"."PF_TTC",'X')<>'IS0' AND NVL("FP"."PF_TTC",'X')<>'HTS' AND NVL("FP"."PF_TTC",'X')<>DECODE(:B22,'ELSE','ISR','Y') AND
              "D"."DF_TAUX_TVA"<>DECODE(:B26,1,0,(-1))) OR ((:B22='IS0' OR :B22='HTS') AND ("FP"."PF_TTC"=:B22 OR
              (NVL("FP"."PF_TTC",'X')=DECODE(:B22,'IS0','ISR','HTS',NVL("FP"."PF_TTC",'X')) AND "D"."DF_TAUX_TVA"=0 AND
              NVL("FP"."PF_TTC",'X')<>DECODE(:B30,1,'IS0','Y') AND NVL("FP"."PF_TTC",'X')<>DECODE(:B22,'HTS',DECODE(:B30,1,'ISR','Y'),'Y') AND
              NVL("FP"."PF_TTC",'X')<>DECODE(:B22,'HTS',DECODE(:B26,0,'HT','Y'),'Y'))))) AND ((:B44=0 AND NVL(LENGTH(:B43),0)<>0 AND
              (NVL("FP"."PF_RELIMP",'M')='M' OR NVL("FP"."PF_RELIMP",'M')='D' OR NVL("FP"."PF_RELIMP",'M')='X')) OR (NVL(LENGTH(:B43),0)=0 AND
              NVL("FP"."PF_RELIMP",'M')='D'))))
  15 - access("FP"."PF_NOM"=UPPER("D"."DF_NOM"))
       filter("FP".ROWID=CHARTOROWID())
  17 - filter(((:B12 IS NULL OR (:B12 IS NOT NULL AND "EF_REL">:B12)) AND "EF_IMP">:B10 AND "DF_DOS"="EF_DOS" AND NVL("EF_CREATEUR",'X')
              NOT LIKE '%e_factur%' AND NVL("EF_DEVISE_MVT",'EUR')=NVL(:B15,NVL("EF_DEVISE_MVT",'EUR')) AND "EF_IMP"<=:B11))
  18 - access("DF_NUM"="EF_NUM")
  22 - filter("EF_DOS"=:B7)
  23 - access("REFDOSS"=:B7)
  24 - access("REFDOSS"="EF_DOS" AND "REFLOT"=:B7)
  26 - access("C"."REFDOSS"="EF_DOS")
       filter("C"."REFLOT" IS NOT NULL)
  27 - access("C"."REFLOT"="D"."REFDOSS" AND "D"."REFLOT"=:B7)
  28 - filter(("T"."ANCREFDOSS" IS NOT NULL AND "T"."ANCREFDOSS"="DF_DOS" AND "T"."CODECR"=UPPER("D"."DF_NOM")))
  29 - access("T"."REFELEM"="DF_NUM")
  30 - access("GC"."NUMFACT"="DF_NUM")
       filter("GC"."NUMFACT" IS NOT NULL)
  31 - filter((("GC"."TYPE"<>'CORRECTION' AND "GC"."TYPE"<>'.CORRECTION') OR (INTERNAL_FUNCTION("GC"."TYPE") AND NVL("GC"."MONTANT",0)<>0)))
  33 - access("REFDOSS"=NVL(:B1,DECODE(:B36,1,:B7,:B2)) AND "REFLOT"=:B38)
  34 - filter(NVL(:B1,DECODE(:B36,1,:B7,:B2))=:B38)
  36 - filter((:B41=1 AND NVL(:B1,DECODE(:B36,1,:B7,:B2))=:B7))
  40 - filter(((:B44=1 AND NVL("FP"."PF_RELIMP",'M')='D') OR (:B44=2 AND NVL("FP"."PF_RELIMP",'M')='X') OR (:B44=0 AND
              (NVL("FP"."PF_RELIMP",'M')='M' OR NVL("FP"."PF_RELIMP",'M')='D' OR NVL("FP"."PF_RELIMP",'M')='X') AND (NVL("FP"."PF_RELIMP",'M')<>'X' OR
              (NVL("FP"."PF_RELIMP",'M')='X' AND  IS NULL)))))
  41 - filter(:B11>:B10)
  48 - filter(NVL("D"."DEVISE",'EUR')=NVL(:B15,NVL("D"."DEVISE",'EUR')))
  49 - access("D"."REFLOT"=:B38)
       filter("D"."CATEGDOSS" LIKE '%LOAN%')
  50 - filter((:B12 IS NULL OR (:B12 IS NOT NULL AND "EF_REL">:B12)))
  51 - access("EF_DOS"="D"."REFDOSS" AND "EF_IMP">:B10 AND "EF_IMP"<=:B11)
  52 - filter(("DF_REL" IS NOT NULL AND "DF_DOS"="EF_DOS" AND "DF_SEN"=DECODE(:B35,0,'D',1,'C',"DF_SEN") AND
              ("DF_TAUX_TVA"=DECODE(:B17,1,:B18,"DF_TAUX_TVA") OR "DF_TAUX_TVA"=DECODE(:B17,1,DECODE(:B20,1,0,:B18),"DF_TAUX_TVA"))))
  53 - access("EF_NUM"="DF_NUM")
       filter(("DF_NOM"='AII' OR "DF_NOM"='IN'))
  54 - filter((:B22='ALL' OR ((:B22='ELSE' OR :B22='ISR') AND NVL("FP"."PF_TTC",'X')=DECODE(:B22,'ISR','ISR','ELSE',NVL("FP"."PF_TTC",'X'))
              AND NVL("FP"."PF_TTC",'X')<>'IS0' AND NVL("FP"."PF_TTC",'X')<>'HTS' AND NVL("FP"."PF_TTC",'X')<>DECODE(:B22,'ELSE','ISR','Y') AND
              "DF_TAUX_TVA"<>DECODE(:B26,1,0,(-1))) OR ((:B22='IS0' OR :B22='HTS') AND ("FP"."PF_TTC"=:B22 OR
              (NVL("FP"."PF_TTC",'X')=DECODE(:B22,'IS0','ISR','HTS',NVL("FP"."PF_TTC",'X')) AND "DF_TAUX_TVA"=0 AND
              NVL("FP"."PF_TTC",'X')<>DECODE(:B30,1,'IS0','Y') AND NVL("FP"."PF_TTC",'X')<>DECODE(:B22,'HTS',DECODE(:B30,1,'ISR','Y'),'Y') AND
              NVL("FP"."PF_TTC",'X')<>DECODE(:B22,'HTS',DECODE(:B26,0,'HT','Y'),'Y'))))))
  55 - access("FP"."PF_NOM"=UPPER("DF_NOM"))
       filter("FP".ROWID=CHARTOROWID())
  58 - access("P"."REFDOSS"="REFDOSS" AND "P"."TYPPIECE"="PIECEINIT")
       filter("P"."REFDOSS" IS NOT NULL)
  59 - access("GCA"."REFDOSS"="REFDOSS")
       filter(("COMMFIN_TYPE" LIKE '%ITRBQ_VALUE_DATE%' AND (("P"."FG07"='O' AND
              TO_NUMBER(TO_CHAR(INTERNAL_FUNCTION("COMMFIN_DAY_DT"),'j'))<=:B5) OR (NVL("P"."FG07",'N')='N' AND
              TO_NUMBER(TO_CHAR(INTERNAL_FUNCTION("COMMFIN_DAY_DT"),'j'))>=:B3 AND TO_NUMBER(TO_CHAR(INTERNAL_FUNCTION("COMMFIN_DAY_DT"),'j'))<=:B5)) AND
              "COMMFIN_TYPE" IS NOT NULL))
  61 - filter("CUR"."ER_F_REL_VAL" IS NOT NULL)
  62 - access("CUR"."ER_NUM"=:B1)
*/
/********************************New Metrics***************************************/

/********************************Index statistics**********************************/

/********************************Other SQLs****************************************/          
/*

*/ 
/********************************Other SQLs****************************************/              
