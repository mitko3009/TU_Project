/********************************************************************************
*********       E-mail subject: ACSTDDEV-2344
*********             Instance: SNOW
*********          Description: 
Problem:
A slow query was provided from instance SNOW.

Analysis:
The problem was that Oracle was using inappropriate execution plan, accessing tables in the NOT IN part a lot of times unnecessary.
The solution here is to make a data set using with clause and after that to access the data from the created set instead of accessing the tables every time.

Suggestion:
Please modify the SQL as it is shown in the New SQL section below.

*********               SQL_ID: 6gsgv86srawkj
*********      Program/Package: SQL_Developer
*********              Request: Luis Gonzalo Lopez 
*********               Author: Dimitar Dimitrov
********* Received e-mail date: 26/12/2023
*********      Resolution date: 28/12/2023
*********  Trace old file here: \\epox\specifs\performance\tmp\
*********  Trace new file here:
***********************************************************************************/

/********************************OLD SQL*******************************************/

SELECT count (*)
  FROM h_countries_in_group cig
 WHERE ref_cntr_grp NOT in (SELECT country_group_set.imx_un_id
                              FROM g_piece, 
                                   country_group_set
                             WHERE typpiece = 'REC_CONTRAT'
                               AND country_group_set.ref_rec_contrat = refpiece
                               AND country_group_set.refentite = refdoss
                            UNION
                            SELECT h_country_group_set.imx_un_id
                              FROM g_piece,
                                   h_country_group_set
                             WHERE typpiece = 'REC_CONTRAT'
                               AND h_country_group_set.ref_rec_contrat = refpiece
                               AND h_country_group_set.refentite = refdoss
                            UNION
                            SELECT IMX_UN_ID
                              FROM country_group_set
                             WHERE refentite like 'INTBU%'
                            UNION
                            SELECT IMX_UN_ID
                              FROM h_country_group_set
                             WHERE refentite like 'INTBU%');
/********************************OLD SQL*******************************************/
/********************************OLD Metrics***************************************/
/*
 MODULE                           SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
SQL Developer                    6gsgv86srawkj 3872818336        589      21891 ON CPU               2023/12/26 19:27:26  2023/12/26 19:49:58         126                    2 +000000000 00:22:31.679 93%
                                 7am4w4pp3nwtm                                  ON CPU               2023/12/26 19:33:56  2023/12/26 19:43:49           4                    1 +000000000 00:09:53.920 3%
SQL Developer                                                    589      21891 db file sequential r 2023/12/26 19:29:09  2023/12/26 19:29:40           4                    1 +000000000 00:00:30.719 3%
                                                        0       1710       8250 db file parallel wri 2023/12/26 19:29:09  2023/12/26 19:29:09           1                      +000000000 00:00:00.000 1%
KTSJ                                                    0        578       5725 latch free           2023/12/26 19:48:05  2023/12/26 19:48:05           1                      +000000000 00:00:00.000 1%


MODULE                           SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
SQL Developer                    6gsgv86srawkj 3872818336        589      21891 ON CPU               2023/12/26 19:27:26  2023/12/26 19:49:58         126                    2 +000000000 00:22:31.679 97%
SQL Developer                                                    589      21891 db file sequential r 2023/12/26 19:29:09  2023/12/26 19:29:40           4                    1 +000000000 00:00:30.719 3%


Plan hash value: 3872818336
---------------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                | Name                   | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  |
---------------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                         |                        |      1 |        |   662M(100)|      1 |00:27:55.67 |      80M|  15202 |
|   1 |  SORT AGGREGATE                          |                        |      1 |      1 |            |      1 |00:27:55.67 |      80M|  15202 |
|*  2 |   FILTER                                 |                        |      1 |        |            |   4934K|00:53:16.63 |      80M|  15202 |
|   3 |    TABLE ACCESS FULL                     | H_COUNTRIES_IN_GROUP   |      1 |   5489K|  3394   (1)|   5489K|00:00:00.75 |   15201 |  15197 |
|   4 |    SORT UNIQUE                           |                        |    125K|      4 |   135   (1)|   8351 |00:53:14.62 |      80M|      5 |
|   5 |     UNION-ALL                            |                        |    125K|        |            |   8351 |00:53:14.02 |      80M|      5 |
|   6 |      NESTED LOOPS SEMI                   |                        |    125K|      1 |     5   (0)|   6176 |00:02:37.21 |    6845K|      5 |
|   7 |       VIEW                               | index$_join$_003       |    125K|      1 |     4   (0)|   6176 |00:02:36.21 |    6831K|      0 |
|*  8 |        HASH JOIN                         |                        |    125K|        |            |   6176 |00:02:36.11 |    6831K|      0 |
|*  9 |         HASH JOIN                        |                        |    125K|        |            |   6176 |00:02:04.26 |    6491K|      0 |
|* 10 |          INDEX FAST FULL SCAN            | PK_COUNTRY_GROUP_SET   |    125K|      1 |     1   (0)|   6176 |00:01:31.96 |    6009K|      0 |
|  11 |          INDEX FAST FULL SCAN            | CGS_REFENTITE_IDX      |   6176 |      1 |     1   (0)|     88M|00:00:10.30 |     481K|      0 |
|  12 |         INDEX FAST FULL SCAN             | FK_REF_REC_CONTRAT_IX  |   6176 |      1 |     1   (0)|     87M|00:00:09.47 |     339K|      0 |
|* 13 |       TABLE ACCESS BY INDEX ROWID BATCHED| G_PIECE                |   6176 |      1 |     1   (0)|   6176 |00:00:00.13 |   14708 |      5 |
|* 14 |        INDEX RANGE SCAN                  | PIE_REFPIECE           |   6176 |      1 |     1   (0)|   6176 |00:00:00.09 |    8532 |      5 |
|  15 |      NESTED LOOPS                        |                        |    125K|      1 |   128   (1)|    110 |00:48:18.47 |      33M|      0 |
|  16 |       NESTED LOOPS                       |                        |    125K|    230K|   128   (1)|     11M|00:48:07.34 |      29M|      0 |
|  17 |        VIEW                              | index$_join$_004       |    125K|   5771 |     4   (0)|    722M|00:22:17.95 |      29M|      0 |
|* 18 |         HASH JOIN                        |                        |    125K|        |            |    722M|00:20:40.79 |      29M|      0 |
|* 19 |          HASH JOIN                       |                        |    125K|        |            |    722M|00:10:35.89 |      16M|      0 |
|* 20 |           INDEX RANGE SCAN               | GP_GRTYPE_MT_DT        |    125K|   5771 |     1   (0)|    722M|00:01:33.90 |    3756K|      0 |
|* 21 |           INDEX FAST FULL SCAN           | GP_REFEXT_IDX          |    125K|   5771 |     1   (0)|    722M|00:02:34.05 |      12M|      0 |
|* 22 |          INDEX FAST FULL SCAN            | GP_ST01_FUNC_IDX       |    125K|   5771 |     1   (0)|    722M|00:03:25.83 |      12M|      0 |
|  23 |        BITMAP CONVERSION TO ROWIDS       |                        |    722M|        |            |     11M|00:23:31.29 |     250K|      0 |
|  24 |         BITMAP AND                       |                        |    722M|        |            |   2003K|00:20:11.55 |     250K|      0 |
|  25 |          BITMAP CONVERSION FROM ROWIDS   |                        |    722M|        |            |   2003K|00:10:25.85 |     125K|      0 |
|* 26 |           INDEX RANGE SCAN               | FK_REF_REC_CONTRAT_IDX |    722M|     40 |     1   (0)|     11M|00:07:12.84 |     125K|      0 |
|  27 |          BITMAP CONVERSION FROM ROWIDS   |                        |    722M|        |            |   2003K|00:04:59.09 |     125K|      0 |
|* 28 |           INDEX RANGE SCAN               | CGS_REFENTITE_IX       |    722M|     40 |     1   (0)|     17M|00:03:12.88 |     125K|      0 |
|* 29 |       TABLE ACCESS BY INDEX ROWID        | H_COUNTRY_GROUP_SET    |     11M|      1 |   128   (1)|    110 |00:00:08.62 |    3505K|      0 |
|* 30 |      TABLE ACCESS BY INDEX ROWID BATCHED | COUNTRY_GROUP_SET      |    125K|      1 |     1   (0)|      0 |00:00:05.72 |    2378K|      0 |
|* 31 |       INDEX RANGE SCAN                   | CGS_REFENTITE_IDX      |    125K|     30 |     1   (0)|   5884K|00:00:02.07 |     125K|      0 |
|* 32 |      TABLE ACCESS BY INDEX ROWID BATCHED | H_COUNTRY_GROUP_SET    |    125K|      1 |     1   (0)|   2065 |00:02:11.39 |      38M|      0 |
|* 33 |       INDEX RANGE SCAN                   | CGS_REFENTITE_IX       |    125K|    184 |     1   (0)|    230M|00:00:51.48 |     876K|      0 |
---------------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   2 - filter( IS NULL)
   8 - access(ROWID=ROWID)
   9 - access(ROWID=ROWID)
  10 - filter(LNNVL("COUNTRY_GROUP_SET"."IMX_UN_ID"<>:B1))
  13 - filter(("COUNTRY_GROUP_SET"."REFENTITE"="REFDOSS" AND "TYPPIECE"='REC_CONTRAT'))
  14 - access("COUNTRY_GROUP_SET"."REF_REC_CONTRAT"="REFPIECE")
  18 - access(ROWID=ROWID)
  19 - access(ROWID=ROWID)
  20 - access("TYPPIECE"='REC_CONTRAT')
  21 - filter("TYPPIECE"='REC_CONTRAT')
  22 - filter("TYPPIECE"='REC_CONTRAT')
  26 - access("H_COUNTRY_GROUP_SET"."REF_REC_CONTRAT"="REFPIECE")
  28 - access("H_COUNTRY_GROUP_SET"."REFENTITE"="REFDOSS")
  29 - filter(LNNVL("H_COUNTRY_GROUP_SET"."IMX_UN_ID"<>:B1))
  30 - filter(LNNVL("IMX_UN_ID"<>:B1))
  31 - access("REFENTITE" LIKE 'INTBU%')
       filter("REFENTITE" LIKE 'INTBU%')
  32 - filter(LNNVL("IMX_UN_ID"<>:B1))
  33 - access("REFENTITE" LIKE 'INTBU%')
       filter("REFENTITE" LIKE 'INTBU%')
*/
/********************************OLD Metrics***************************************/

/********************************New SQL*******************************************/

WITH C AS (
                            SELECT country_group_set.imx_un_id
                              FROM g_piece, 
                                   country_group_set
                             WHERE typpiece = 'REC_CONTRAT'
                               AND country_group_set.ref_rec_contrat = refpiece
                               AND country_group_set.refentite = refdoss
                            UNION
                            SELECT h_country_group_set.imx_un_id
                              FROM g_piece,
                                   h_country_group_set
                             WHERE typpiece = 'REC_CONTRAT'
                               AND h_country_group_set.ref_rec_contrat = refpiece
                               AND h_country_group_set.refentite = refdoss
                            UNION
                            SELECT IMX_UN_ID 
                              FROM country_group_set
                             WHERE refentite like 'INTBU%'
                            UNION
                            SELECT IMX_UN_ID
                              FROM h_country_group_set
                             WHERE refentite like 'INTBU%'
) 
SELECT count (*)
  FROM h_countries_in_group cig
 WHERE ref_cntr_grp NOT in (select * from C);
/********************************New SQL*******************************************/
/********************************New Metrics***************************************/
/*

Plan hash value: 1430989456
---------------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                | Name                   | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  |
---------------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                         |                        |      1 |        |  3550 (100)|      1 |00:00:08.92 |   16219 |  15316 |
|   1 |  SORT AGGREGATE                          |                        |      1 |      1 |            |      1 |00:00:08.92 |   16219 |  15316 |
|*  2 |   HASH JOIN RIGHT ANTI NA                |                        |      1 |   5489K|  3550   (2)|   4934K|00:00:08.68 |   16219 |  15316 |
|   3 |    VIEW                                  |                        |      1 |  11756 |   144   (5)|  16187 |00:00:00.51 |    1019 |    119 |
|   4 |     SORT UNIQUE                          |                        |      1 |  11756 |   144   (5)|  16187 |00:00:00.50 |    1019 |    119 |
|   5 |      UNION-ALL                           |                        |      1 |        |            |  16187 |00:00:00.50 |    1019 |    119 |
|*  6 |       HASH JOIN                          |                        |      1 |   5771 |     8   (0)|  14208 |00:00:00.47 |     416 |    119 |
|   7 |        VIEW                              | index$_join$_001       |      1 |   5771 |     4   (0)|   5772 |00:00:00.03 |     235 |      0 |
|*  8 |         HASH JOIN                        |                        |      1 |        |            |   5772 |00:00:00.03 |     235 |      0 |
|*  9 |          HASH JOIN                       |                        |      1 |        |            |   5772 |00:00:00.02 |     133 |      0 |
|* 10 |           INDEX RANGE SCAN               | GP_GRTYPE_MT_DT        |      1 |   5771 |     1   (0)|   5772 |00:00:00.01 |      31 |      0 |
|* 11 |           INDEX FAST FULL SCAN           | GP_REFEXT_IDX          |      1 |   5771 |     1   (0)|   5772 |00:00:00.01 |     102 |      0 |
|* 12 |          INDEX FAST FULL SCAN            | GP_ST01_FUNC_IDX       |      1 |   5771 |     1   (0)|   5772 |00:00:00.01 |     102 |      0 |
|  13 |        VIEW                              | index$_join$_002       |      1 |  14286 |     4   (0)|  14208 |00:00:00.43 |     181 |    119 |
|* 14 |         HASH JOIN                        |                        |      1 |        |            |  14208 |00:00:00.43 |     181 |    119 |
|* 15 |          HASH JOIN                       |                        |      1 |        |            |  14286 |00:00:00.27 |     126 |     72 |
|  16 |           INDEX FAST FULL SCAN           | PK_COUNTRY_GROUP_SET   |      1 |  14286 |     1   (0)|  14286 |00:00:00.01 |      48 |      0 |
|  17 |           INDEX FAST FULL SCAN           | CGS_REFENTITE_IDX      |      1 |  14286 |     1   (0)|  14286 |00:00:00.26 |      78 |     72 |
|  18 |          INDEX FAST FULL SCAN            | FK_REF_REC_CONTRAT_IX  |      1 |  14286 |     1   (0)|  14208 |00:00:00.15 |      55 |     47 |
|  19 |       NESTED LOOPS                       |                        |      1 |   5771 |   128   (1)|     94 |00:00:00.02 |     278 |      0 |
|  20 |        NESTED LOOPS                      |                        |      1 |    230K|   128   (1)|     94 |00:00:00.02 |     250 |      0 |
|  21 |         VIEW                             | index$_join$_003       |      1 |   5771 |     4   (0)|   5772 |00:00:00.01 |     235 |      0 |
|* 22 |          HASH JOIN                       |                        |      1 |        |            |   5772 |00:00:00.01 |     235 |      0 |
|* 23 |           HASH JOIN                      |                        |      1 |        |            |   5772 |00:00:00.01 |     133 |      0 |
|* 24 |            INDEX RANGE SCAN              | GP_GRTYPE_MT_DT        |      1 |   5771 |     1   (0)|   5772 |00:00:00.01 |      31 |      0 |
|* 25 |            INDEX FAST FULL SCAN          | GP_REFEXT_IDX          |      1 |   5771 |     1   (0)|   5772 |00:00:00.01 |     102 |      0 |
|* 26 |           INDEX FAST FULL SCAN           | GP_ST01_FUNC_IDX       |      1 |   5771 |     1   (0)|   5772 |00:00:00.01 |     102 |      0 |
|  27 |         BITMAP CONVERSION TO ROWIDS      |                        |   5772 |        |            |     94 |00:00:00.01 |      15 |      0 |
|  28 |          BITMAP AND                      |                        |   5772 |        |            |     16 |00:00:00.01 |      15 |      0 |
|  29 |           BITMAP CONVERSION FROM ROWIDS  |                        |   5772 |        |            |     16 |00:00:00.01 |       8 |      0 |
|* 30 |            INDEX RANGE SCAN              | FK_REF_REC_CONTRAT_IDX |   5772 |     40 |     1   (0)|     94 |00:00:00.01 |       8 |      0 |
|  31 |           BITMAP CONVERSION FROM ROWIDS  |                        |   5772 |        |            |     16 |00:00:00.01 |       7 |      0 |
|* 32 |            INDEX RANGE SCAN              | CGS_REFENTITE_IX       |   5772 |     40 |     1   (0)|    136 |00:00:00.01 |       7 |      0 |
|  33 |        TABLE ACCESS BY INDEX ROWID       | H_COUNTRY_GROUP_SET    |     94 |      1 |   128   (1)|     94 |00:00:00.01 |      28 |      0 |
|  34 |       TABLE ACCESS BY INDEX ROWID BATCHED| COUNTRY_GROUP_SET      |      1 |     30 |     1   (0)|     47 |00:00:00.01 |      20 |      0 |
|* 35 |        INDEX RANGE SCAN                  | CGS_REFENTITE_IDX      |      1 |     30 |     1   (0)|     47 |00:00:00.01 |       2 |      0 |
|  36 |       TABLE ACCESS BY INDEX ROWID BATCHED| H_COUNTRY_GROUP_SET    |      1 |    184 |     1   (0)|   1838 |00:00:00.01 |     305 |      0 |
|* 37 |        INDEX RANGE SCAN                  | CGS_REFENTITE_IX       |      1 |    184 |     1   (0)|   1838 |00:00:00.01 |       8 |      0 |
|  38 |    TABLE ACCESS FULL                     | H_COUNTRIES_IN_GROUP   |      1 |   5489K|  3391   (1)|   5489K|00:00:06.88 |   15200 |  15197 |
---------------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   2 - access("REF_CNTR_GRP"="C"."IMX_UN_ID")
   6 - access("COUNTRY_GROUP_SET"."REF_REC_CONTRAT"="REFPIECE" AND "COUNTRY_GROUP_SET"."REFENTITE"="REFDOSS")
   8 - access(ROWID=ROWID)
   9 - access(ROWID=ROWID)
  10 - access("TYPPIECE"='REC_CONTRAT')
  11 - filter("TYPPIECE"='REC_CONTRAT')
  12 - filter("TYPPIECE"='REC_CONTRAT')
  14 - access(ROWID=ROWID)
  15 - access(ROWID=ROWID)
  22 - access(ROWID=ROWID)
  23 - access(ROWID=ROWID)
  24 - access("TYPPIECE"='REC_CONTRAT')
  25 - filter("TYPPIECE"='REC_CONTRAT')
  26 - filter("TYPPIECE"='REC_CONTRAT')
  30 - access("H_COUNTRY_GROUP_SET"."REF_REC_CONTRAT"="REFPIECE")
  32 - access("H_COUNTRY_GROUP_SET"."REFENTITE"="REFDOSS")
  35 - access("REFENTITE" LIKE 'INTBU%')
       filter("REFENTITE" LIKE 'INTBU%')
  37 - access("REFENTITE" LIKE 'INTBU%')
       filter("REFENTITE" LIKE 'INTBU%')
*/
/********************************New Metrics***************************************/

/********************************Index statistics**********************************/

/********************************Other SQLs****************************************/          
/*

*/ 
/********************************Other SQLs****************************************/              
