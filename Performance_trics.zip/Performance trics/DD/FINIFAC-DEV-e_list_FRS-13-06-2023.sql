/********************************************************************************
*********       E-mail subject: FINIFACDEV-2249 
*********             Instance: DEV
*********          Description: 
Problem:

Slow query on DEV from e_list_FRS module.

Analysis:

On 13/06/2023 the provided query was slow and was taking more than 10 seconds.
The problem was that was used column with no index and too much data were taken.

Suggestion:
1. Please ask DBA to install the DET_TY_IT_ID_IDX index on AINZ and create PR.
2. Please use GE.dtjour_dt column because it has index on it instead of GE.dtjour to check the date as it is shown in the new SQL.

*********               SQL_ID: 
*********      Program/Package: 
*********              Request: Dimitare Ivanov
*********               Author: Dimitar Dimitrov
********* Received e-mail date: 13/06/2023
*********      Resolution date: 13/06/2023
*********  Trace old file here: \\epox\specifs\performance\tmp\
*********  Trace new file here:
***********************************************************************************/

/********************************OLD SQL*******************************************/
SELECT FR.FUNDING_ID fundingId
  FROM t_bundle_fund_det FR,
       g_piece           BNDL,
       g_elemfi          GE,
       g_piece           GP_FACT,
       g_elemfi_aggr     GR
 WHERE 1 = 1
   AND FR.detail_type = 'FUNDING_REQUEST'
   AND FR.item_id = BNDL.gpirole
   AND GE.refelem = GP_FACT.gpiheure
   AND GP_FACT.typpiece = 'FACTURE'
   AND GP_FACT.refpiece = GR.reffacture
   AND GR.refaggr = BNDL.refpiece
   AND GE.dtjour = TO_CHAR(to_date('05/06/2023', 'dd/mm/yyyy'), 'j');
   

/********************************OLD SQL*******************************************/
/********************************OLD Metrics***************************************/
/*
  Plan hash value: 2687726118

----------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                 | Name              | Starts | E-Rows | A-Rows |   A-Time   | Buffers | Reads  |
----------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                          |                   |      1 |        |      1 |00:00:11.12 |   48602 |   9630 |
|*  1 |  HASH JOIN                                |                   |      1 |      1 |      1 |00:00:11.12 |   48602 |   9630 |
|   2 |   NESTED LOOPS                            |                   |      1 |    203 |      1 |00:00:11.12 |   48556 |   9630 |
|   3 |    NESTED LOOPS                           |                   |      1 |    203 |      1 |00:00:11.12 |   48555 |   9630 |
|   4 |     NESTED LOOPS                          |                   |      1 |    203 |      1 |00:00:11.12 |   48552 |   9630 |
|   5 |      MERGE JOIN                           |                   |      1 |    202 |     11 |00:00:11.12 |   48544 |   9630 |
|*  6 |       TABLE ACCESS BY INDEX ROWID         | G_ELEMFI          |      1 |    371 |     25 |00:00:00.82 |   23982 |    389 |
|   7 |        INDEX FULL SCAN                    | EFI_REFELEM       |      1 |    153K|    153K|00:00:00.51 |     369 |    367 |
|*  8 |       SORT JOIN                           |                   |     25 |  79152 |     11 |00:00:10.30 |   24562 |   9241 |
|   9 |        TABLE ACCESS BY INDEX ROWID BATCHED| G_PIECE           |      1 |  79152 |    145K|00:00:10.23 |   24562 |   9241 |
|* 10 |         INDEX RANGE SCAN                  | GP_GRTYPE_MT_DT   |      1 |  79152 |    145K|00:00:01.53 |    2339 |    772 |
|* 11 |      INDEX RANGE SCAN                     | AK_KEY_2_G_ELEMFI |     11 |      1 |      1 |00:00:00.01 |       8 |      0 |
|* 12 |     INDEX RANGE SCAN                      | PIE_REFPIECE      |      1 |      1 |      1 |00:00:00.01 |       3 |      0 |
|* 13 |    TABLE ACCESS BY INDEX ROWID            | G_PIECE           |      1 |      1 |      1 |00:00:00.01 |       1 |      0 |
|* 14 |   TABLE ACCESS FULL                       | T_BUNDLE_FUND_DET |      1 |    539 |   1960 |00:00:00.01 |      46 |      0 |
----------------------------------------------------------------------------------------------------------------------------------

Predicate Information (identified by operation id):
---------------------------------------------------

   1 - access("FR"."ITEM_ID"="BNDL"."GPIROLE")
   6 - filter("GE"."DTJOUR"=2460101)
   8 - access("GE"."REFELEM"="GP_FACT"."GPIHEURE")
       filter("GE"."REFELEM"="GP_FACT"."GPIHEURE")
  10 - access("GP_FACT"."TYPPIECE"='FACTURE')
       filter("GP_FACT"."GPIHEURE" IS NOT NULL)
  11 - access("GP_FACT"."REFPIECE"="GR"."REFFACTURE")
  12 - access("GR"."REFAGGR"="BNDL"."REFPIECE")
  13 - filter("BNDL"."GPIROLE" IS NOT NULL)
  14 - filter("FR"."DETAIL_TYPE"='FUNDING_REQUEST')

*/
/********************************OLD Metrics***************************************/

/********************************New SQL*******************************************/
var B1 varchar2(32);
exec :B1 := '05/06/2023';

SELECT FR.FUNDING_ID fundingId
  FROM t_bundle_fund_det FR,
       g_piece           BNDL,
       g_elemfi          GE,
       g_piece           GP_FACT,
       g_elemfi_aggr     GR
 WHERE 1 = 1
   AND FR.detail_type = 'FUNDING_REQUEST'
   AND FR.item_id = BNDL.gpirole
   AND GE.refelem = GP_FACT.gpiheure
   AND GP_FACT.typpiece = 'FACTURE'
   AND GP_FACT.refpiece = GR.reffacture
   AND GR.refaggr = BNDL.refpiece
   AND GE.dtjour_dt >= to_date(:B1, 'dd/mm/yyyy')
   AND GE.dtjour_dt < to_date(:B1, 'dd/mm/yyyy') + 1;

/********************************New SQL*******************************************/
/********************************New Metrics***************************************/
/*

Plan hash value: 1782129667

-------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                 | Name              | Starts | E-Rows | A-Rows |   A-Time   | Buffers |
-------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                          |                   |      1 |        |      1 |00:00:00.01 |      57 |
|*  1 |  FILTER                                   |                   |      1 |        |      1 |00:00:00.01 |      57 |
|   2 |   NESTED LOOPS                            |                   |      1 |      1 |      1 |00:00:00.01 |      57 |
|   3 |    NESTED LOOPS                           |                   |      1 |    264 |      1 |00:00:00.01 |      56 |
|   4 |     NESTED LOOPS                          |                   |      1 |    132 |      1 |00:00:00.01 |      53 |
|   5 |      NESTED LOOPS                         |                   |      1 |    132 |      1 |00:00:00.01 |      48 |
|   6 |       NESTED LOOPS                        |                   |      1 |    131 |     11 |00:00:00.01 |      39 |
|   7 |        TABLE ACCESS BY INDEX ROWID BATCHED| G_ELEMFI          |      1 |    241 |     25 |00:00:00.01 |      17 |
|*  8 |         INDEX RANGE SCAN                  | ELEMFI_DTJOUR_IDX |      1 |    241 |     25 |00:00:00.01 |       4 |
|   9 |        TABLE ACCESS BY INDEX ROWID BATCHED| G_PIECE           |     25 |      1 |     11 |00:00:00.01 |      22 |
|* 10 |         INDEX RANGE SCAN                  | GP_GRTYPE_MT_DT   |     25 |      1 |     11 |00:00:00.01 |      15 |
|* 11 |       INDEX RANGE SCAN                    | AK_KEY_2_G_ELEMFI |     11 |      1 |      1 |00:00:00.01 |       9 |
|* 12 |      TABLE ACCESS BY INDEX ROWID BATCHED  | G_PIECE           |      1 |      1 |      1 |00:00:00.01 |       5 |
|* 13 |       INDEX RANGE SCAN                    | PIE_REFPIECE      |      1 |      1 |      1 |00:00:00.01 |       4 |
|* 14 |     INDEX RANGE SCAN                      | DET_TY_IT_ID_IDX  |      1 |      2 |      1 |00:00:00.01 |       3 |
|  15 |    TABLE ACCESS BY INDEX ROWID            | T_BUNDLE_FUND_DET |      1 |      1 |      1 |00:00:00.01 |       1 |
-------------------------------------------------------------------------------------------------------------------------

Predicate Information (identified by operation id):
---------------------------------------------------

   1 - filter(TO_DATE(:B1,'dd/mm/yyyy')+1>TO_DATE(:B1,'dd/mm/yyyy'))
   8 - access("GE"."DTJOUR_DT">=TO_DATE(:B1,'dd/mm/yyyy') AND "GE"."DTJOUR_DT"<TO_DATE(:B1,'dd/mm/yyyy')+1)
  10 - access("GP_FACT"."TYPPIECE"='FACTURE' AND "GE"."REFELEM"="GP_FACT"."GPIHEURE")
       filter("GP_FACT"."GPIHEURE" IS NOT NULL)
  11 - access("GP_FACT"."REFPIECE"="GR"."REFFACTURE")
  12 - filter("BNDL"."GPIROLE" IS NOT NULL)
  13 - access("GR"."REFAGGR"="BNDL"."REFPIECE")
  14 - access("FR"."DETAIL_TYPE"='FUNDING_REQUEST' AND "FR"."ITEM_ID"="BNDL"."GPIROLE")
*/
/********************************New Metrics***************************************/

/********************************Index statistics**********************************/

/********************************Other SQLs****************************************/          
/*

*/ 
/********************************Other SQLs****************************************/              
