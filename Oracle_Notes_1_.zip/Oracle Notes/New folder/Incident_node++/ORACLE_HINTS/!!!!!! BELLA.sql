#### Backup control files (.dbf)
#### Ако се намират в /root/var/opt и започват с ctrl_KCQ_---.dbf ,може да се трият най-старите,но не и ако са в /oracle файлова система и не ако завършват на .log



https://www.w3schools.com/sql/sql_min_max.asp

https://www.youtube.com/watch?v=RaizJx4ZXjY

https://ss64.com/ora/desc.html 



shared pool = cash memory
logwriter = Когато се пише нещо в базата не се записва директно в базата
ps -ef | grep pmon  =  да ми покаже какви инстанси вървят на сървъра
. oraenv  =  сетва инстансите (къде му е холма на дадената база)
sqlplus / as sysdba  =  влизам в базата
desc = може да видим дадена таблица и съдържанието и
ASM = това е сториджа той се оправлява не от oracle,а от grid (трябва да се суитчваш като Grid, не като oracle)





export ORACLE_HOSTNAME=centos7.dbaora.com  -  Хост нейм на машината

export ORACLE_UNQNAME=ORA11G  -  уникално име на базата,така се казва базата

export ORACLE_BASE=/ora01/app/oracle  -  

export ORACLE_HOME=$ORACLE_BASE/product/11.2.0/db_1  -  инсталацията на Oracle,държи байнаритата на oracle

export ORACLE_SID=ORA11G  -  името на инстанса

PATH=/usr/sbin:$PATH:$ORACLE_HOME/bin 

export LD_LIBRARY_PATH=$ORACLE_HOME/lib:/lib:/usr/lib;
export CLASSPATH=$ORACLE_HOME/jlib:$ORACLE_HOME/rdbms/jlib;

alias cdob='cd $ORACLE_BASE'
alias cdoh='cd $ORACLE_HOME'
alias tns='cd $ORACLE_HOME/network/admin'
alias envo='env | grep ORACLE'


 MLPHPTSF\EXLBARBO
 !QAZ1qaz                   


[‎3/‎26/‎2020 11:19 AM]  Vodenicharova, Velichka (Oracle DBA):  
No Title 
SOLUTION 
As a solution for the issue you can disable the use of durations.
The shared pool can have subpools with 4 durations. These durations are "instance", "session", "cursor", and "execution". By default these durations are separate from each other.

The disable durations, you have to set the underscore parameter "_enable_shared_pool_durations = false":
SQL> alter system set "_enable_shared_pool_durations"=false scope=spfile;
- restart the database
This is recommended by development for all similar issues.

The main advantage of "_enable_shared_pool_durations = false" is that all the durations are combined into one pool and so a duration will not run out while another duration has free memory.
This issue will be fixed in 12c version due to architectural changes which will allow less need of durations for subpools. 
 


