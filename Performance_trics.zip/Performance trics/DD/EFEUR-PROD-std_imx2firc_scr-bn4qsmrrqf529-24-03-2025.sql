/********************************************************************************
*********       E-mail subject: EFEURWEB-4194
*********             Instance: PROD
*********          Description: 
Problem:
The std_imx2firc_scr took 4 hours on PROD.

Analysis:
We checked the work of the std_imx2firc_scr on PROD for the provided period from 18:00 to 22:00  on 12/03/2025 and as you can see below, the TOP SQLs are light queries, executed millions 
times. The metrics of the queries shows us that the only query that is making significant amount of buffer gets is SQL bn4qsmrrqf529. This query is the cursor from File:/home/sst/imx_source/prog/imxstd/interfaces/imx2fircosoft_screening/imx_imx2fircosoft_scr.cpp. 
For every of the selected rows it loops to find find iFlagDebtor, the refdoss and executes the queries from isDossierForBU() ( which are the light queries that we see as top SQLs 
in the std_imx2firc_scr module ). On every of the million executions of the queries, we have time spent in the network between the application server and the DB server 
( the std_imx2firc_scr  has only ~1h activity in the DB for the period of 4h ) . As it is described in document SQL_with_SLA_acceptable_performance on Performance and Tuning wiki page, 
as much work as possible should be done in the cursor instead of the body of the batch. After discussions and tests with Angel Santiago, in the New SQL section below can be found the final 
version of the cursor bn4qsmrrqf529, where the light queries are joined directly into it.


Suggestion:
Please see the New SQL section below, where can be found the final version of the cursor bn4qsmrrqf529, where the light queries are joined directly into it.

*********               SQL_ID: bn4qsmrrqf529
*********      Program/Package: 
*********              Request: Angel Santiago 
*********               Author: Dimitar Dimitrov
********* Received e-mail date: 13/03/2025
*********      Resolution date: 24/03/2025
*********  Trace old file here: \\epox\specifs\performance\tmp\
*********  Trace new file here:
***********************************************************************************/

/********************************OLD SQL*******************************************/
-- 5qnwrb6x22bcs

SELECT d.categdoss
  FROM g_dossier d
 WHERE d.refdoss = :refdoss;


-- a5t95w9zcj4rf

SELECT t.refindividu
  FROM t_intervenants t
 WHERE t.refdoss = :refdoss
   AND t.reftype = 'CL';


-- avarjqpbw58yt

SELECT CONTRAT.refdoss
  FROM g_dossier CONTRAT, g_dossier DECOMPTE, g_dossier COMPTE
 WHERE CONTRAT.refdoss = DECOMPTE.reflot
   AND DECOMPTE.refdoss = COMPTE.reflot
   AND COMPTE.refdoss = :refdoss;


-- bn4qsmrrqf529

SELECT gi.refindividu,
       gi.moralphy,
       RC.refext,
       decode(gi.moralphy, 'M', 'C', 'P', 'I'),
       REPLACE(gi.nom, '|', ' '),
       NULL,
       REPLACE(DECODE(gi.moralphy,
                      'P',
                      gi.nomjf || NVL2(gi.nomjf, ',', '') || gi.prenom ||
                      NVL2(gi.prenom, ' ', '') || gi.str33 ||
                      NVL2(gi.str33, ' ', '') || gi.nomcompl,
                      'M',
                      gi.raissoc1),
               '|',
               ' '),
       REPLACE(gi.adr1, '|', ' ') ||
       DECODE(gi.adr2, NULL, NULL, ';' || REPLACE(gi.adr2, '|', ' ')) ||
       DECODE(gi.adr3, NULL, NULL, ';' || REPLACE(gi.adr3, '|', ' ')) ||
       DECODE(gi.adr4, NULL, NULL, ';' || REPLACE(gi.adr4, '|', ' ')),
       REPLACE(gi.ville, '|', ' ') ||
       DECODE(gi.cp, NULL, NULL, ',' || REPLACE(gi.cp, '|', ' ')),
       gi.pays || ',' || pays.valeur_an,
       CASE
         WHEN gi.moralphy = 'P' AND gi.nationalite IS NOT NULL THEN
          (decode((SELECT count(*)
                    FROM v_dom_out_trans nat_trans
                   WHERE nat_trans.contexte = 'FIRCO'
                     AND nat_trans.domain = nat.type
                     AND nat_trans.int_code = nat.abrev),
                  0,
                  nat.abrev || ',' || nat.valeur_an,
                  (SELECT nat_trans.ext_code
                     FROM v_dom_out_trans nat_trans
                    WHERE nat_trans.domain = nat.type
                      AND nat_trans.int_code = nat.abrev)))
         WHEN gi.moralphy = 'P' AND gi.nationalite IS NULL THEN
          (gi.pays || ',' || pays.valeur_an)
       END,
       DECODE(gi.moralphy, 'M', NVL(gi.tva, gi.siret), 'P', gi.numident),
       CASE
         WHEN gi.moralphy = 'M' THEN
          to_char(COALESCE(gi.dtcreasoc_dt, gi.dt_maj_dt), 'YYYY-MM-DD')
         WHEN gi.moralphy = 'P' THEN
          to_char(gi.dtnaiss_dt, 'YYYY-MM-DD')
       END,
       DECODE(gi.moralphy,
              'M',
              (gi.pays_immat || ',' || paysim.valeur_an),
              'P',
              (gi.paysnaiss || ',' || paysns.valeur_an)),
       CASE
         WHEN gi.moralphy = 'P' THEN
          NULL
         WHEN gi.moralphy = 'M' AND gi.str44 IS NULL AND gi.str15 IS NULL THEN
          NULL
         ELSE
          DECODE(gi.str44,
                 NULL,
                 (tnaf.abrev || ',' || tnaf.valeur_an),
                 (sic.abrev || ',' || sic.valeur_an))
       END,
       LRC.refext,
       LRC.refext3,
       REPLACE(LNK.nom, '|', ' '),
       gi.numident,
       DECODE(gi.moralphy, 'P', gi.profession, 'M', NULL),
       NULL,
       NULL,
       DECODE(gi.moralphy, 'P', gi.title, 'M', NULL),
       CASE
         WHEN (SELECT pays FROM g_individu WHERE refindividu = 'INT00000') =
              gi.pays THEN
          'R'
         ELSE
          'N'
       END,
       REPLACE(DECODE(gi.moralphy, 'P', gi.complete_name, 'M', gi.raissoc2),
               '|',
               ' '),
       NULL,
       NULL,
       NULL,
       NULL,
       NULL,
       NULL
  FROM g_individu gi,
       v_domaine  pays,
       v_domaine  paysns,
       v_domaine  paysim,
       v_domaine  nat,
       v_domaine  tnaf,
       v_domaine  sic,
       t_individu RC,
       t_individu LRC,
       g_individu LNK
 WHERE gi.typautre IS NULL
   AND gi.moralphy IS NOT NULL
   AND pays.abrev = gi.pays
   AND pays.type = 'pays'
   AND paysim.abrev(+) = gi.pays_immat
   AND paysim.type(+) = 'pays'
   AND paysns.abrev(+) = gi.paysnaiss
   AND paysns.type(+) = 'pays'
   AND nat.valeur(+) = gi.nationalite
   AND nat.type(+) = 'nationalite'
   AND tnaf.type(+) = 'T.NAF'
   AND tnaf.abrev(+) = gi.str15
   AND sic.type(+) = 'SIC_CODE'
   AND sic.abrev(+) = gi.str44
   AND RC.refindividu(+) = gi.refindividu
   AND RC.societe(+) = 'RECORD_ID_2'
   AND LRC.refindividu(+) = gi.refindividu
   AND LRC.societe(+) = 'LINK_RECORD_ID'
   AND LNK.refindividu(+) = LRC.refindividu
   AND gi.str86 = 'NORMAL';

/********************************OLD SQL*******************************************/
/********************************OLD Metrics***************************************/
/*
MODULE                           PROGRAM                                            CLIENT_ID       SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- -------------------------------------------------- --------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
std_imx2firc_scr                 std_imx2firc_scr                                                                                  2020      25309                      2025/03/12 18:00:34  2025/03/12 21:59:52         351              2353391 +000000000 03:59:18.017 100%


MODULE                           PROGRAM                                            CLIENT_ID       SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- -------------------------------------------------- --------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
std_imx2firc_scr                 std_imx2firc_scr                                                                                  2020      25309 ON CPU               2025/03/12 18:00:34  2025/03/12 21:59:52         350              2353391 +000000000 03:59:18.017 100%
std_imx2firc_scr                 std_imx2firc_scr                                                   1qqwvhdrbqcw6 4059022147       2020      25309 db file sequential r 2025/03/12 21:13:31  2025/03/12 21:13:31           1                    1 +000000000 00:00:00.000 0%



MODULE                           PROGRAM                                            CLIENT_ID       SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- -------------------------------------------------- --------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
std_imx2firc_scr                 std_imx2firc_scr                                                   5qnwrb6x22bcs                  2020      25309 ON CPU               2025/03/12 18:00:54  2025/03/12 21:47:22          46              1564899 +000000000 03:46:27.673 13%
std_imx2firc_scr                 std_imx2firc_scr                                                   5bgsj08na8msb                  2020      25309 ON CPU               2025/03/12 18:13:15  2025/03/12 21:38:42          40              1293770 +000000000 03:25:26.956 11%
std_imx2firc_scr                 std_imx2firc_scr                                                   avarjqpbw58yt                  2020      25309 ON CPU               2025/03/12 18:02:34  2025/03/12 21:41:22          39              1307879 +000000000 03:38:47.414 11%
std_imx2firc_scr                 std_imx2firc_scr                                                   2qa4j7dx76k5x                  2020      25309 ON CPU               2025/03/12 18:16:05  2025/03/12 21:48:52          37              1836602 +000000000 03:32:47.145 11%
std_imx2firc_scr                 std_imx2firc_scr                                                   fshjhjvupd8az 1703598991       2020      25309 ON CPU               2025/03/12 18:02:24  2025/03/12 21:58:42          32              2329620 +000000000 03:56:17.897 9%
std_imx2firc_scr                 std_imx2firc_scr                                                                          0       2020      25309 ON CPU               2025/03/12 18:06:14  2025/03/12 21:57:42          31                      +000000000 03:51:27.709 9%
std_imx2firc_scr                 std_imx2firc_scr                                                   bn4qsmrrqf529                  2020      25309 ON CPU               2025/03/12 18:02:14  2025/03/12 21:59:52          30                    4 +000000000 03:57:37.936 9%
std_imx2firc_scr                 std_imx2firc_scr                                                   c6rfxtt8y6vfb                  2020      25309 ON CPU               2025/03/12 18:00:34  2025/03/12 21:46:12          28              1458970 +000000000 03:45:37.668 8%
std_imx2firc_scr                 std_imx2firc_scr                                                   bwc40vtghypz4                  2020      25309 ON CPU               2025/03/12 18:14:55  2025/03/12 21:58:12          23               940718 +000000000 03:43:17.434 7%
std_imx2firc_scr                 std_imx2firc_scr                                                   023buvs04ndz0                  2020      25309 ON CPU               2025/03/12 18:20:15  2025/03/12 20:53:01          11                      +000000000 02:32:45.630 3%
std_imx2firc_scr                 std_imx2firc_scr                                                   a5t95w9zcj4rf 3185332316       2020      25309 ON CPU               2025/03/12 19:01:26  2025/03/12 21:45:42           9                      +000000000 02:44:15.902 3%
std_imx2firc_scr                 std_imx2firc_scr                                                   6q6zgu55tha6r 1456285233       2020      25309 ON CPU               2025/03/12 19:50:07  2025/03/12 21:57:22           8               202049 +000000000 02:07:15.075 2%
std_imx2firc_scr                 std_imx2firc_scr                                                   gxakqu7g05p1w 1870781345       2020      25309 ON CPU               2025/03/12 18:54:56  2025/03/12 21:34:12           6               140538 +000000000 02:39:15.715 2%
std_imx2firc_scr                 std_imx2firc_scr                                                   4511gtpsnf6vp 2520246178       2020      25309 ON CPU               2025/03/12 18:56:26  2025/03/12 21:46:02           6               200210 +000000000 02:49:36.030 2%
std_imx2firc_scr                 std_imx2firc_scr                                                   1qqwvhdrbqcw6 4059022147       2020      25309                      2025/03/12 18:01:44  2025/03/12 21:13:31           5                57392 +000000000 03:11:46.786 1%


INSTANCE_NUMBER SQL_ID            ELAPSED MAX_WAIT_ON     PC_OF  WAIT_TIME            GETS      READS       ROWS  ELAP/EXEC       GETS/EXEC READS/EXEC  ROWS/EXEC       EXEC PLAN_HASH_VALUE
--------------- ------------- ----------- --------------- ----- ---------- --------------- ---------- ---------- ---------- --------------- ---------- ---------- ---------- ---------------
              1 2qa4j7dx76k5x         206 CPU             100%  206.163568         7483861          0    1681651          0               4          0        .81    2075222   222010329
              1 5bgsj08na8msb         170 CPU             100%  169.877067         6201672          0    1550418          0               4          0          1    1550418  3185332316
              1 5qnwrb6x22bcs         208 CPU             100%  207.790359         7588598         11    1682597          0               5          0          1    1682597  3997628364
              1 avarjqpbw58yt         234 CPU             100%  234.290608        17054444          5    1550404          0              11          0          1    1550404   382801797
              1 bn4qsmrrqf529          74 CPU             100%   73.974517         6889987        196     662502      73.91         6889987        196     662502          0  2515495106
              1 bn4qsmrrqf529          40 CPU             100%   39.706841         1451809          0     519065       39.7         1451809          0     519065          1   107324693
              1 bn4qsmrrqf529           9 CPU             100%    8.893275          321415          0      86887       8.89          321415          0      86887          1  3336395476
              1 fshjhjvupd8az         223 CPU             99%   224.092489        17346120       3593      77570          0               6          0        .03    2888067  1703598991


SQL_ID        SQL_PLAN_HASH_VALUE SQL_PLAN_LINE_ID SQL_PLAN_OPERATION             SQL_PLAN_OPTIONS                   ACTIVE
------------- ------------------- ---------------- ------------------------------ ------------------------------ ----------
5qnwrb6x22bcs                   0                  SELECT STATEMENT                                                       4
5bgsj08na8msb                   0                  SELECT STATEMENT                                                       2


SQL_ID        SQL_PLAN_HASH_VALUE SQL_PLAN_LINE_ID SQL_PLAN_OPERATION             SQL_PLAN_OPTIONS                   ACTIVE
------------- ------------------- ---------------- ------------------------------ ------------------------------ ----------
avarjqpbw58yt                   0                  SELECT STATEMENT                                                       1


SQL_ID        SQL_PLAN_HASH_VALUE SQL_PLAN_LINE_ID SQL_PLAN_OPERATION             SQL_PLAN_OPTIONS                   ACTIVE
------------- ------------------- ---------------- ------------------------------ ------------------------------ ----------
2qa4j7dx76k5x                   0                  SELECT STATEMENT                                                       1
2qa4j7dx76k5x           222010329                  SELECT STATEMENT                                                      33
2qa4j7dx76k5x           222010329                1 INDEX                          RANGE SCAN                              3


SQL_ID        SQL_PLAN_HASH_VALUE SQL_PLAN_LINE_ID SQL_PLAN_OPERATION             SQL_PLAN_OPTIONS                   ACTIVE
------------- ------------------- ---------------- ------------------------------ ------------------------------ ----------
avarjqpbw58yt           382801797                  SELECT STATEMENT                                                      27
avarjqpbw58yt           382801797                3 INDEX                          RANGE SCAN                              5
avarjqpbw58yt           382801797                4 INDEX                          RANGE SCAN                              3
avarjqpbw58yt           382801797                5 INDEX                          UNIQUE SCAN                             2
avarjqpbw58yt           382801797                                                                                         1


SQL_ID        SQL_PLAN_HASH_VALUE SQL_PLAN_LINE_ID SQL_PLAN_OPERATION             SQL_PLAN_OPTIONS                   ACTIVE
------------- ------------------- ---------------- ------------------------------ ------------------------------ ----------
fshjhjvupd8az          1703598991                  SELECT STATEMENT                                                      24
fshjhjvupd8az          1703598991                2 INDEX                          RANGE SCAN                              5
fshjhjvupd8az          1703598991                4 INDEX                          RANGE SCAN                              3


SQL_ID        SQL_PLAN_HASH_VALUE SQL_PLAN_LINE_ID SQL_PLAN_OPERATION             SQL_PLAN_OPTIONS                   ACTIVE
------------- ------------------- ---------------- ------------------------------ ------------------------------ ----------
5bgsj08na8msb          3185332316                  SELECT STATEMENT                                                      34
5bgsj08na8msb          3185332316                1 INDEX                          RANGE SCAN                              3
5bgsj08na8msb          3185332316                                                                                         1
5qnwrb6x22bcs          3997628364                  SELECT STATEMENT                                                      33
5qnwrb6x22bcs          3997628364                2 INDEX                          UNIQUE SCAN                             5
5qnwrb6x22bcs          3997628364                1 TABLE ACCESS                   BY INDEX ROWID                          4


-- bn4qsmrrqf529

Plan hash value: 3336395476
------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                    | Name                    | Rows  | Bytes | Cost (%CPU)| Time     |
------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                             |                         |       |       | 35586 (100)|          |
|   1 |  SORT AGGREGATE                              |                         |     1 |    22 |            |          |
|*  2 |   INDEX RANGE SCAN                           | AK_KEY_2_V_DOM_OU       |     1 |    22 |     1   (0)| 00:00:01 |
|   3 |    TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOM_OUT_TRANS         |     1 |    30 |     2   (0)| 00:00:01 |
|*  4 |     INDEX RANGE SCAN                         | AK_KEY_2_V_DOM_OU       |     1 |       |     1   (0)| 00:00:01 |
|   5 |  TABLE ACCESS BY INDEX ROWID                 | G_INDIVIDU              |     1 |    13 |     3   (0)| 00:00:01 |
|*  6 |   INDEX UNIQUE SCAN                          | IND_REFINDIV            |     1 |       |     2   (0)| 00:00:01 |
|*  7 |  HASH JOIN RIGHT OUTER                       |                         |  3355 |  2519K| 30547   (2)| 00:00:02 |
|*  8 |   TABLE ACCESS FULL                          | T_INDIVIDU              | 35900 |  1051K|  4635   (1)| 00:00:01 |
|   9 |   NESTED LOOPS OUTER                         |                         |  3344 |  2413K| 25912   (2)| 00:00:02 |
|* 10 |    HASH JOIN RIGHT OUTER                     |                         |  3344 |  2295K| 19221   (2)| 00:00:01 |
|* 11 |     TABLE ACCESS FULL                        | T_INDIVIDU              | 35900 |  1191K|  4635   (1)| 00:00:01 |
|* 12 |     HASH JOIN RIGHT OUTER                    |                         |  3334 |  2178K| 14585   (3)| 00:00:01 |
|* 13 |      TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE               |  1105 | 40885 |   165   (0)| 00:00:01 |
|* 14 |       INDEX RANGE SCAN                       | V_DOMAINE_TYPE_CODE_IDX |  1105 |       |     7   (0)| 00:00:01 |
|* 15 |      HASH JOIN RIGHT OUTER                   |                         |  3334 |  2057K| 14420   (3)| 00:00:01 |
|* 16 |       TABLE ACCESS BY INDEX ROWID BATCHED    | V_DOMAINE               |   995 | 36815 |   148   (0)| 00:00:01 |
|* 17 |        INDEX RANGE SCAN                      | V_DOMAINE_TYPE_CODE_IDX |   995 |       |     6   (0)| 00:00:01 |
|* 18 |       HASH JOIN RIGHT OUTER                  |                         |  3334 |  1937K| 14272   (3)| 00:00:01 |
|* 19 |        TABLE ACCESS BY INDEX ROWID BATCHED   | V_DOMAINE               |   261 |  9657 |    41   (0)| 00:00:01 |
|* 20 |         INDEX RANGE SCAN                     | V_DOMAINE_TYPE_CODE_IDX |   261 |       |     3   (0)| 00:00:01 |
|  21 |        NESTED LOOPS OUTER                    |                         |  3334 |  1816K| 14231   (3)| 00:00:01 |
|  22 |         NESTED LOOPS OUTER                   |                         |  3334 |  1627K| 14228   (3)| 00:00:01 |
|* 23 |          HASH JOIN                           |                         |  3334 |  1507K| 14225   (3)| 00:00:01 |
|* 24 |           TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE               |   261 |  9657 |    41   (0)| 00:00:01 |
|* 25 |            INDEX RANGE SCAN                  | V_DOMAINE_TYPE_CODE_IDX |   261 |       |     3   (0)| 00:00:01 |
|* 26 |           TABLE ACCESS FULL                  | G_INDIVIDU              |   258K|   104M| 14182   (3)| 00:00:01 |
|  27 |          TABLE ACCESS BY INDEX ROWID BATCHED | V_DOMAINE               |     1 |    37 |     3   (0)| 00:00:01 |
|* 28 |           INDEX RANGE SCAN                   | DOM_TYPABREV            |     1 |       |     2   (0)| 00:00:01 |
|  29 |         TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE               |     1 |    58 |     3   (0)| 00:00:01 |
|* 30 |          INDEX RANGE SCAN                    | DOM_TYPVAL              |     1 |       |     1   (0)| 00:00:01 |
|  31 |    TABLE ACCESS BY INDEX ROWID               | G_INDIVIDU              |     1 |    36 |     2   (0)| 00:00:01 |
|* 32 |     INDEX UNIQUE SCAN                        | IND_REFINDIV            |     1 |       |     1   (0)| 00:00:01 |
------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   2 - access("NAT_TRANS"."DOMAIN"=:B1 AND "NAT_TRANS"."CONTEXTE"='FIRCO' AND "NAT_TRANS"."INT_CODE"=:B2)
   4 - access("NAT_TRANS"."DOMAIN"=:B1 AND "NAT_TRANS"."INT_CODE"=:B2)
       filter("NAT_TRANS"."INT_CODE"=:B1)
   6 - access("REFINDIVIDU"='INT00000')
   7 - access("RC"."REFINDIVIDU"="GI"."REFINDIVIDU")
   8 - filter("RC"."SOCIETE"='RECORD_ID_2')
  10 - access("LRC"."REFINDIVIDU"="GI"."REFINDIVIDU")
  11 - filter("LRC"."SOCIETE"='LINK_RECORD_ID')
  12 - access("SIC"."ABREV"="GI"."STR44")
  13 - filter("SIC"."ABREV" IS NOT NULL)
  14 - access("SIC"."TYPE"='SIC_CODE')
  15 - access("TNAF"."ABREV"="GI"."STR15")
  16 - filter("TNAF"."ABREV" IS NOT NULL)
  17 - access("TNAF"."TYPE"='T.NAF')
  18 - access("PAYSIM"."ABREV"="GI"."PAYS_IMMAT")
  19 - filter("PAYSIM"."ABREV" IS NOT NULL)
  20 - access("PAYSIM"."TYPE"='pays')
  23 - access("PAYS"."ABREV"="GI"."PAYS")
  24 - filter("PAYS"."ABREV" IS NOT NULL)
  25 - access("PAYS"."TYPE"='pays')
  26 - filter(("GI"."STR86"='NORMAL' AND "GI"."TYPAUTRE" IS NULL AND "GI"."MORALPHY" IS NOT NULL))
  28 - access("PAYSNS"."TYPE"='pays' AND "PAYSNS"."ABREV"="GI"."PAYSNAISS")
       filter("PAYSNS"."ABREV" IS NOT NULL)
  30 - access("NAT"."VALEUR"="GI"."NATIONALITE" AND "NAT"."TYPE"='nationalite')
  32 - access("LNK"."REFINDIVIDU"="LRC"."REFINDIVIDU")

*/
/********************************OLD Metrics***************************************/

/********************************New SQL*******************************************/

var refext varchar2(32);
exec :refext := 'CALF_EU_IMX';

SELECT /*+ opt_param('_optimizer_join_factorization' 'false')
           opt_param('optimizer_index_cost_adj' 10000)
           leading(gi) use_hash(bus PAYSNS NAT) swap_join_inputs(bus)
           no_merge(bus) no_pus_pred(bus) */  
         gi.refindividu
        ,gi.moralphy
        ,RC.refext
        ,decode(gi.moralphy,'M','C','P','I')
        ,REPLACE(gi.nom, '|', ' ')
        ,NULL
        ,REPLACE(DECODE(gi.moralphy, 'P',gi.nomjf  || NVL2(gi.nomjf, ',', '')  ||
                                         gi.prenom || NVL2(gi.prenom, ' ', '') ||
                                         gi.str33  || NVL2(gi.str33, ' ', '')  ||
                                         gi.nomcompl, 'M', gi.raissoc1), '|', ' ')
        ,REPLACE(gi.adr1, '|', ' ') ||
         DECODE(gi.adr2, NULL, NULL, ';' || REPLACE(gi.adr2, '|', ' ')) ||
         DECODE(gi.adr3, NULL, NULL, ';' || REPLACE(gi.adr3, '|', ' ')) ||
         DECODE(gi.adr4, NULL, NULL, ';' || REPLACE(gi.adr4, '|', ' '))
        ,REPLACE(gi.ville, '|', ' ') ||
         DECODE(gi.cp, NULL, NULL, ',' || REPLACE(gi.cp , '|' , ' '))
        ,gi.pays || ',' || pays.valeur_an
        ,CASE WHEN gi.moralphy = 'P' 
               AND gi.nationalite IS NOT NULL
              THEN CASE WHEN nat_trans_cnt.cnt = 0
                        THEN nat.abrev || ',' || nat.valeur_an
                        ELSE nat_trans.ext_code
                    END
              WHEN gi.moralphy = 'P' 
               AND gi.nationalite IS NULL
              THEN (gi.pays   || ',' || pays.valeur_an)
          END
        ,DECODE(gi.moralphy,'M',NVL(gi.tva, gi.siret), 'P', gi.numident)
        ,CASE
           WHEN gi.moralphy = 'M'
             THEN to_char(COALESCE(gi.dtcreasoc_dt, gi.dt_maj_dt), 'YYYY-MM-DD')
           WHEN gi.moralphy = 'P'
             THEN to_char(gi.dtnaiss_dt,'YYYY-MM-DD')
         END
        ,DECODE(gi.moralphy, 'M', (gi.pays_immat ||','|| paysim.valeur_an),
                             'P', (gi.paysnaiss ||','|| paysns.valeur_an))
        ,CASE
           WHEN gi.moralphy = 'P'
             THEN NULL
           WHEN gi.moralphy = 'M' AND gi.str44 IS NULL AND gi.str15 IS NULL
             THEN NULL
           ELSE
               DECODE(gi.str44, NULL, (tnaf.abrev ||','|| tnaf.valeur_an),
                                      (sic.abrev  ||','|| sic.valeur_an))
         END
        ,LRC.refext
        ,LRC.refext3
        ,REPLACE(LNK.nom, '|', ' ')
        ,gi.numident
        ,DECODE(gi.moralphy,'P', gi.profession ,'M', NULL)
        ,NULL
        ,NULL
        ,DECODE(gi.moralphy,'P', gi.title ,'M', NULL)
        ,CASE
           WHEN (SELECT pays FROM g_individu WHERE refindividu = 'INT00000') = gi.pays
             THEN 'R'
           ELSE 'N'
         END
        ,REPLACE(DECODE(gi.moralphy,'P', gi.complete_name ,'M', gi.raissoc2), '|', ' ')
        ,NULL
        ,NULL
        ,NULL
        ,NULL
        ,NULL
        ,NULL
        ,CASE WHEN gi.refindividu = bus.refindividu
            THEN 1
            ELSE 0
        end as isForCurrBU
  FROM  g_individu gi
       ,v_domaine  pays
       ,v_domaine  paysns
       ,v_domaine  paysim
       ,v_domaine  nat
       ,v_domaine  tnaf
       ,v_domaine  sic
       ,t_individu RC
       ,t_individu LRC
       ,g_individu LNK
       , ( SELECT /*+ leading(t dos db) use_hash(dos db)
                    no_merge(dos) no_pus_pred(dos) index_ffs(db INT_REFDOSS) */
                DISTINCT db.refindividu
           FROM t_individu t,
                ( SELECT c.refdoss,
                         cl.refindividu BU
                    FROM g_dossier c,
                         t_intervenants cl
                   WHERE c.categdoss = 'COMPTE DB CTR'
                     AND c.refdoss = cl.refdoss
                     AND cl.reftype = 'CL'
                   UNION ALL
                  SELECT c.refdoss,
                         db.refindividu BU
                    FROM g_dossier c,
                         t_intervenants db
                   WHERE c.categdoss = 'CONTRAT'
                     AND c.refdoss = db.refdoss
                     AND db.reftype = 'CL'
                   UNION ALL
                  SELECT d.refdoss,
                         db.refindividu BU
                    FROM g_dossier d,
                         t_intervenants db
                   WHERE d.categdoss = 'DECOMPTE'
                     AND d.reflot = db.refdoss
                     AND db.reftype = 'DB'
                   UNION ALL
                  SELECT c.refdoss,
                         db.refindividu BU
                    FROM g_dossier c,
                         g_dossier d,
                         t_intervenants db
                   WHERE c.reflot = d.refdoss
                     AND c.categdoss = 'COMPTE'
                     AND d.reflot = db.refdoss
                     AND db.reftype = 'DB' ) dos,
                t_intervenants db
          WHERE t.societe = 'BUNIT_FIRCOSOFT'
            AND t.refext = :refext
            AND t.refindividu = dos.BU
            AND dos.refdoss = db.refdoss
            AND db.reftype = 'DB' ) bus,
       v_dom_out_trans nat_trans,
       ( SELECT domain,
                int_code,
                count(*) cnt
           FROM v_dom_out_trans
          WHERE contexte = 'FIRCO'
          GROUP BY domain,
                   int_code ) nat_trans_cnt
 WHERE  gi.typautre IS NULL
   AND  gi.moralphy IS NOT NULL
   AND  pays.abrev                = gi.pays
   AND  pays.type                 = 'pays'
   AND  paysim.abrev(+)           = gi.pays_immat
   AND  paysim.type(+)            = 'pays'
   AND  paysns.abrev(+)           = gi.paysnaiss
   AND  paysns.type(+)            = 'pays'
   AND  nat.valeur(+)             = gi.nationalite
   AND  nat.type(+)               = 'nationalite'
   AND  tnaf.type(+)              = 'T.NAF'
   AND  tnaf.abrev(+)             = gi.str15
   AND  sic.type(+)               = 'SIC_CODE'
   AND  sic.abrev(+)              = gi.str44
   AND  RC.refindividu(+)         = gi.refindividu
   AND  RC.societe(+)             = 'RECORD_ID_2'
   AND  LRC.refindividu(+)        = gi.refindividu
   AND  LRC.societe(+)            = 'LINK_RECORD_ID'
   AND  LNK.refindividu(+)        = LRC.refindividu
   AND  gi.str86                  = 'NORMAL'
   AND  gi.refindividu            = bus.refindividu(+)
   AND  nat_trans.domain(+)       = nat.type
   AND  nat_trans.int_code(+)     = nat.abrev
   AND  nat_trans_cnt.domain(+)   = nat.type
   AND  nat_trans_cnt.int_code(+) = nat.abrev;
/********************************New SQL*******************************************/
/********************************New Metrics***************************************/
/*
Plan hash value: 1036875380
--------------------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                           | Name                      | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers |
--------------------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                                    |                           |      1 |        | 54951 (100)|      0 |00:00:00.01 |       0 |
|   1 |  TABLE ACCESS BY INDEX ROWID                        | G_INDIVIDU                |      0 |      1 |   300   (0)|      0 |00:00:00.01 |       0 |
|*  2 |   INDEX UNIQUE SCAN                                 | IND_REFINDIV              |      0 |      1 |   200   (0)|      0 |00:00:00.01 |       0 |
|*  3 |  HASH JOIN OUTER                                    |                           |      1 |    467 | 54651   (1)|      0 |00:00:00.01 |       0 |
|*  4 |   HASH JOIN OUTER                                   |                           |      1 |    466 | 49866   (1)|      0 |00:00:00.01 |       0 |
|*  5 |    HASH JOIN OUTER                                  |                           |      1 |    466 | 35746   (2)|      0 |00:00:00.01 |       0 |
|*  6 |     HASH JOIN RIGHT OUTER                           |                           |      1 |    464 | 30962   (2)|    205K|00:00:04.65 |     519K|
|   7 |      TABLE ACCESS FULL                              | V_DOM_OUT_TRANS           |      1 |     67 |     5   (0)|     67 |00:00:00.01 |      15 |
|*  8 |      HASH JOIN RIGHT OUTER                          |                           |      1 |    464 | 30957   (2)|    205K|00:00:04.42 |     519K|
|   9 |       VIEW                                          |                           |      1 |     48 |     3  (34)|     67 |00:00:00.01 |       4 |
|  10 |        HASH GROUP BY                                |                           |      1 |     48 |     3  (34)|     67 |00:00:00.01 |       4 |
|* 11 |         INDEX FAST FULL SCAN                        | AK_KEY_2_V_DOM_OU         |      1 |     67 |     2   (0)|     67 |00:00:00.01 |       4 |
|* 12 |       HASH JOIN RIGHT OUTER                         |                           |      1 |    464 | 30954   (2)|    205K|00:00:04.20 |     519K|
|* 13 |        TABLE ACCESS FULL                            | V_DOMAINE                 |      1 |     39 |   607   (1)|     72 |00:00:00.02 |    2737 |
|* 14 |        HASH JOIN RIGHT OUTER                        |                           |      1 |    464 | 30347   (2)|    205K|00:00:03.97 |     516K|
|* 15 |         TABLE ACCESS FULL                           | V_DOMAINE                 |      1 |     36 |   607   (1)|   1105 |00:00:00.02 |    2744 |
|* 16 |         HASH JOIN RIGHT OUTER                       |                           |      1 |    464 | 29740   (2)|    205K|00:00:03.72 |     514K|
|* 17 |          TABLE ACCESS FULL                          | V_DOMAINE                 |      1 |     36 |   607   (1)|    995 |00:00:00.02 |    2846 |
|* 18 |          HASH JOIN RIGHT OUTER                      |                           |      1 |    464 | 29134   (2)|    205K|00:00:03.46 |     511K|
|* 19 |           TABLE ACCESS FULL                         | V_DOMAINE                 |      1 |     36 |   607   (1)|    261 |00:00:00.02 |    2740 |
|* 20 |           HASH JOIN RIGHT OUTER                     |                           |      1 |    464 | 28527   (2)|    205K|00:00:03.21 |     508K|
|* 21 |            TABLE ACCESS FULL                        | V_DOMAINE                 |      1 |     36 |   607   (1)|    261 |00:00:00.02 |    2740 |
|* 22 |            HASH JOIN                                |                           |      1 |    464 | 27920   (2)|    205K|00:00:02.98 |     505K|
|* 23 |             TABLE ACCESS FULL                       | V_DOMAINE                 |      1 |     36 |   607   (1)|    261 |00:00:00.02 |    2740 |
|* 24 |             HASH JOIN RIGHT OUTER                   |                           |      1 |    261K| 27312   (2)|    205K|00:00:02.73 |     503K|
|  25 |              VIEW                                   |                           |      1 |      2 | 12929   (1)|      0 |00:00:00.01 |       3 |
|  26 |               HASH UNIQUE                           |                           |      1 |      2 | 12929   (1)|      0 |00:00:00.01 |       3 |
|* 27 |                HASH JOIN                            |                           |      1 |      2 | 12928   (1)|      0 |00:00:00.01 |       3 |
|* 28 |                 HASH JOIN                           |                           |      1 |      2 | 11395   (1)|      0 |00:00:00.01 |       3 |
|  29 |                  TABLE ACCESS BY INDEX ROWID BATCHED| T_INDIVIDU                |      1 |      1 |   400   (0)|      0 |00:00:00.01 |       3 |
|* 30 |                   INDEX RANGE SCAN                  | SOC_INDIV                 |      1 |      1 |   300   (0)|      0 |00:00:00.01 |       3 |
|  31 |                  VIEW                               |                           |      0 |    141K| 10994   (1)|      0 |00:00:00.01 |       0 |
|  32 |                   UNION-ALL                         |                           |      0 |        |            |      0 |00:00:00.01 |       0 |
|* 33 |                    HASH JOIN                        |                           |      0 |  35753 |  2352   (1)|      0 |00:00:00.01 |       0 |
|* 34 |                     INDEX FAST FULL SCAN            | REFHIERARCHIE_IDX         |      0 |  34072 |   818   (1)|      0 |00:00:00.01 |       0 |
|* 35 |                     INDEX FAST FULL SCAN            | INT_INDIV                 |      0 |  81672 |  1533   (1)|      0 |00:00:00.01 |       0 |
|* 36 |                    HASH JOIN                        |                           |      0 |  35753 |  2352   (1)|      0 |00:00:00.01 |       0 |
|* 37 |                     INDEX FAST FULL SCAN            | REFHIERARCHIE_IDX         |      0 |  34072 |   818   (1)|      0 |00:00:00.01 |       0 |
|* 38 |                     INDEX FAST FULL SCAN            | INT_INDIV                 |      0 |  81672 |  1533   (1)|      0 |00:00:00.01 |       0 |
|* 39 |                    HASH JOIN                        |                           |      0 |  35210 |  2589   (1)|      0 |00:00:00.01 |       0 |
|* 40 |                     INDEX FAST FULL SCAN            | G_DOSSIER_RL_CD_RD_RF_IDX |      0 |  34072 |  1055   (1)|      0 |00:00:00.01 |       0 |
|* 41 |                     INDEX FAST FULL SCAN            | INT_INDIV                 |      0 |  81672 |  1533   (1)|      0 |00:00:00.01 |       0 |
|* 42 |                    HASH JOIN                        |                           |      0 |  34675 |  3702   (1)|      0 |00:00:00.01 |       0 |
|* 43 |                     HASH JOIN                       |                           |      0 |  33554 |  1926   (1)|      0 |00:00:00.01 |       0 |
|* 44 |                      INDEX FAST FULL SCAN           | G_DOSSIER_RL_CD_RD_RF_IDX |      0 |  34072 |  1055   (1)|      0 |00:00:00.01 |       0 |
|  45 |                      INDEX FAST FULL SCAN           | DOS_REFDOSS_REFLOT_IDX    |      0 |    477K|   868   (1)|      0 |00:00:00.01 |       0 |
|* 46 |                     INDEX FAST FULL SCAN            | INT_INDIV                 |      0 |  81672 |  1533   (1)|      0 |00:00:00.01 |       0 |
|* 47 |                 INDEX FAST FULL SCAN                | INT_INDIV                 |      0 |  81672 |  1533   (1)|      0 |00:00:00.01 |       0 |
|* 48 |              TABLE ACCESS FULL                      | G_INDIVIDU                |      1 |    261K| 14381   (3)|    205K|00:00:02.45 |     503K|
|* 49 |     TABLE ACCESS FULL                               | T_INDIVIDU                |      0 |  36198 |  4784   (1)|      0 |00:00:00.01 |       0 |
|  50 |    TABLE ACCESS FULL                                | G_INDIVIDU                |      0 |    545K| 14117   (1)|      0 |00:00:00.01 |       0 |
|* 51 |   TABLE ACCESS FULL                                 | T_INDIVIDU                |      0 |  36198 |  4784   (1)|      0 |00:00:00.01 |       0 |
--------------------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   2 - access("REFINDIVIDU"='INT00000')
   3 - access("RC"."REFINDIVIDU"="GI"."REFINDIVIDU")
   4 - access("LNK"."REFINDIVIDU"="LRC"."REFINDIVIDU")
   5 - access("LRC"."REFINDIVIDU"="GI"."REFINDIVIDU")
   6 - access("NAT_TRANS"."DOMAIN"="NAT"."TYPE" AND "NAT_TRANS"."INT_CODE"="NAT"."ABREV")
   8 - access("NAT_TRANS_CNT"."DOMAIN"="NAT"."TYPE" AND "NAT_TRANS_CNT"."INT_CODE"="NAT"."ABREV")
  11 - filter("CONTEXTE"='FIRCO')
  12 - access("NAT"."VALEUR"="GI"."NATIONALITE")
  13 - filter("NAT"."TYPE"='nationalite')
  14 - access("SIC"."ABREV"="GI"."STR44")
  15 - filter(("SIC"."TYPE"='SIC_CODE' AND "SIC"."ABREV" IS NOT NULL))
  16 - access("TNAF"."ABREV"="GI"."STR15")
  17 - filter(("TNAF"."TYPE"='T.NAF' AND "TNAF"."ABREV" IS NOT NULL))
  18 - access("PAYSIM"."ABREV"="GI"."PAYS_IMMAT")
  19 - filter(("PAYSIM"."TYPE"='pays' AND "PAYSIM"."ABREV" IS NOT NULL))
  20 - access("PAYSNS"."ABREV"="GI"."PAYSNAISS")
  21 - filter(("PAYSNS"."TYPE"='pays' AND "PAYSNS"."ABREV" IS NOT NULL))
  22 - access("PAYS"."ABREV"="GI"."PAYS")
  23 - filter(("PAYS"."TYPE"='pays' AND "PAYS"."ABREV" IS NOT NULL))
  24 - access("GI"."REFINDIVIDU"="BUS"."REFINDIVIDU")
  27 - access("DOS"."REFDOSS"="DB"."REFDOSS")
  28 - access("T"."REFINDIVIDU"="DOS"."BU")
  30 - access("T"."SOCIETE"='BUNIT_FIRCOSOFT' AND "T"."REFEXT"=:REFEXT)
  33 - access("C"."REFDOSS"="CL"."REFDOSS")
  34 - filter("C"."CATEGDOSS"='COMPTE DB CTR')
  35 - filter("CL"."REFTYPE"='CL')
  36 - access("C"."REFDOSS"="DB"."REFDOSS")
  37 - filter("C"."CATEGDOSS"='CONTRAT')
  38 - filter("DB"."REFTYPE"='CL')
  39 - access("D"."REFLOT"="DB"."REFDOSS")
  40 - filter("D"."CATEGDOSS"='DECOMPTE')
  41 - filter("DB"."REFTYPE"='DB')
  42 - access("D"."REFLOT"="DB"."REFDOSS")
  43 - access("C"."REFLOT"="D"."REFDOSS")
  44 - filter("C"."CATEGDOSS"='COMPTE')
  46 - filter("DB"."REFTYPE"='DB')
  47 - filter("DB"."REFTYPE"='DB')
  48 - filter(("GI"."STR86"='NORMAL' AND "GI"."TYPAUTRE" IS NULL AND "GI"."MORALPHY" IS NOT NULL))
  49 - filter("LRC"."SOCIETE"='LINK_RECORD_ID')
  51 - filter("RC"."SOCIETE"='RECORD_ID_2')
*/
/********************************New Metrics***************************************/

/********************************Index statistics**********************************/

/********************************Other SQLs****************************************/          
/*

*/ 
/********************************Other SQLs****************************************/              
