/********************************************************************************
*********       E-mail subject: EFDE2DEV-1750
*********             Instance: UAT2
*********          Description: 
Problem:
SQL 8s2gz0vh67b3p was provided from UAT2 as slow.

Analysis:
I executed the query manually on UAT2 and it took ~ 13 seconds to finish. The most time consuming part was the access to table T_ALERTE for each of the 
selected rows from table G_PERSONNEL. When accessing table T_ALERTE, we filter the selected rows on condition ta.refext LIKE :B8, where we don't found any rows that 
match this condition and the query ends. The most selective path that we can choose in this situation is to start the execution from table T_ALERTE from ta.refext LIKE :B8, but for 
this purpose we will need index on column refext, because now it is not indexed. Also, we noticed that we are making full scan of table g_personnel, because missing index, so index 
GPERS_REFIN_IDX on table g_personnel should be delivered from refbg2 to UAT2.
Also, when I tried to get the explain plan of the query, it took ~7 seconds, which means that the query needs some time to be parsed.

Suggestion:
1. For C&D -> Please check is it possible to create index on column refext on table T_ALERTE.
2. For DBA -> After C&D create the new index on column refext on table T_ALERTE, please deliver it to UAT2 and also plase 
deliver index GPERS_REFIN_IDX on table g_personnel from refbg2 to UAT2.

*********               SQL_ID: 8s2gz0vh67b3p
*********      Program/Package: 
*********              Request: Moez Sokrati 
*********               Author: Dimitar Dimitrov
********* Received e-mail date: 23/07/2024
*********      Resolution date: 23/07/2024
*********  Trace old file here: \\epox\specifs\performance\tmp\
*********  Trace new file here:
***********************************************************************************/

/********************************OLD SQL*******************************************/

VAR B1 VARCHAR2(32);
EXEC :B1 := 'AN';
VAR B2 VARCHAR2(32);
EXEC :B2 := 'DONT_USE';
VAR B3 VARCHAR2(32);
EXEC :B3 := 'FACTORING';
VAR B4 VARCHAR2(32);
EXEC :B4 := 'A602TY72';
VAR B5 NUMBER;
EXEC :B5 := 3280;
VAR B6 VARCHAR2(32);
EXEC :B6 := '2024-07-16';
VAR B7 VARCHAR2(32);
EXEC :B7 := 'Limit';
VAR B8 VARCHAR2(32);
EXEC :B8 := 'A70FQ5BR';
VAR B9 NUMBER;
EXEC :B9 := 2001;
VAR B10 NUMBER;
EXEC :B10 := 1;

SELECT /*+ OPT_PARAM('_optimizer_use_feedback' 'false') */
 *
  FROM (SELECT /*+ first_rows(2001)*/
         foo.*, ROWNUM rnum
          FROM (SELECT displayStage      displayStage,
                       amount            amount,
                       creator           creator,
                       contract          contract,
                       caseRefIMX        caseRefIMX,
                       creationDate      creationDate,
                       additionalDetails additionalDetails,
                       typeStage         typeStage,
                       nbAlertProcessed  nbAlertProcessed,
                       reference         reference,
                       uniqueRowId       uniqueRowId,
                       caseRef           caseRef,
                       readyToExport     readyToExport,
                       stage             stage,
                       intRef            intRef,
                       nameManager       nameManager,
                       processDate       processDate,
                       nameDebtor        nameDebtor,
                       displayTypeStage  displayTypeStage,
                       idManager         idManager,
                       currency          currency,
                       groupManager      groupManager,
                       alertId           alertId,
                       nameClient        nameClient
                  FROM (SELECT groupManager groupManager,
                               idManager idManager,
                               namemanager nameManager,
                               typestage typeStage,
                               displayTypeStage displayTypeStage,
                               stage stage,
                               displayStage displayStage,
                               caseref caseRef,
                               caseRefIMX caseRefIMX,
                               nameclient nameClient,
                               reference reference,
                               amount amount,
                               processdate processDate,
                               creationDate creationDate,
                               intref intRef,
                               CASE
                                 WHEN EXISTS
                                  (SELECT 1
                                         FROM g_dossier
                                        WHERE refdoss IN
                                              (SELECT refhierarchie
                                                 FROM g_dossier
                                                WHERE ancrefdoss = contract)
                                          AND categdoss = 'COMPTE DB CTR') THEN
                                  (SELECT ancrefdoss
                                     FROM g_dossier
                                    WHERE refdoss IN
                                          (SELECT refhierarchie
                                             FROM g_dossier
                                            WHERE ancrefdoss = t.contract)
                                      AND categdoss = 'COMPTE DB CTR')
                                 ELSE
                                  t.contract
                               END contract,
                               CASE
                                 WHEN EXISTS
                                  (SELECT 1
                                         FROM g_dossier
                                        WHERE refdoss IN
                                              (SELECT refhierarchie
                                                 FROM g_dossier
                                                WHERE ancrefdoss = contract)
                                          AND categdoss = 'COMPTE DB CTR') THEN
                                  (SELECT I.nom
                                     FROM g_individu     I,
                                          t_intervenants TI,
                                          g_dossier      D1,
                                          g_dossier      D2
                                    WHERE TI.refdoss = D1.refdoss
                                      AND D1.refdoss = D2.refhierarchie
                                      AND D2.ancrefdoss = t.contract
                                      AND D1.categdoss = 'COMPTE DB CTR'
                                      AND I.refindividu = TI.refindividu
                                      AND TI.reftype = 'DB'
                                      AND ROWNUM = 1)
                                 ELSE
                                  (SELECT I.nom
                                     FROM g_individu     I,
                                          t_intervenants TI,
                                          g_dossier      GD
                                    WHERE TI.refdoss = GD.refdoss
                                      AND GD.ancrefdoss = t.contract
                                      AND I.refindividu = TI.refindividu
                                      AND TI.reftype = 'DB'
                                      AND ROWNUM = 1)
                               END nameDebtor,
                               alerte_id alertId,
                               un_key uniqueRowId,
                               readyToExport readyToExport,
                               v.abrev_trad currency,
                               creator creator,
                               nbAlertProcessed nbAlertProcessed,
                               CASE
                                 WHEN EXISTS
                                  (SELECT 1
                                         FROM t_alert_not_es_det
                                        WHERE alerte_id = t.alerte_id) THEN
                                  (SELECT LISTAGG(valeur, '; ') WITHIN GROUP(ORDER BY order_info)
                                     FROM (SELECT v.valeur_trad || ' ' ||
                                                  td.value_info valeur,
                                                  order_info
                                             FROM t_alert_not_es_det td,
                                                  v_tdomaine         v
                                            WHERE v.type = 'DV_AGENDA_DETAILS'
                                              AND td.type_info = v.abrev
                                              AND v.langue = :B1
                                              AND td.alerte_id = t.alerte_id))
                               END additionalDetails
                          FROM (SELECT ta.ROWID un_key,
                                       NVL(vgr.valeur_trad, gp.groupe) groupManager,
                                       ta.catperso idManager,
                                       DECODE(gi.prenom,
                                              NULL,
                                              gi.nom,
                                              gi.prenom || ' ' || gi.nom) namemanager,
                                       NVL(v.valeur_trad, ta.typentite) displayTypeStage,
                                       ta.typentite typestage,
                                       ta.refentite intref,
                                       ta.refext reference,
                                       ta.refdoss caseRefIMX,
                                       ta.refctr contract,
                                       NVL(v1.valeur_trad, ta.typencour) displayStage,
                                       ta.typencour stage,
                                       ta.montant amount,
                                       ta.dttrait_dt processdate,
                                       ta.dtcreation_dt creationDate,
                                       DECODE(:B2,
                                              'C204',
                                              ta.refctr,
                                              'C405',
                                              ta.refdoss,
                                              'C202',
                                              ta.refdoss,
                                              NVL(gd.ancrefdoss, gd.refdoss)) caseref,
                                       ta.alerte_id alerte_id,
                                       ta.fg02 readyToExport,
                                       NVL(cli.nameclient, cl.nameclient) nameclient,
                                       CASE
                                         WHEN :B3 = 'FACTORING' AND
                                              gd.reffactor IS NOT NULL AND
                                              v1.place = 1 THEN
                                          ftr_fin_factor.getCurrency(gd.reffactor)
                                         WHEN v1.place = 2 THEN
                                          ta.devise_alerte
                                         ELSE
                                          NVL(gd.devise, ta.devise_alerte)
                                       END currency,
                                       CASE
                                         WHEN :B3 = 'FACTORING' THEN
                                          CASE
                                            WHEN ta.createur = 'SE' THEN
                                             NVL((SELECT valeur_trad
                                                   FROM v_tdomaine
                                                  WHERE type = 'NONSE_CREATOR'
                                                    AND abrev = 'SE'
                                                    AND langue = :B1),
                                                 ta.createur)
                                            WHEN ta.createur = 'FTR_CTRL' AND
                                                 EXISTS
                                             (SELECT 1
                                                    FROM eligib_ctrl e
                                                   WHERE e.alerte_id = ta.alerte_id) THEN
                                             NVL((SELECT valeur_trad
                                                   FROM v_tdomaine
                                                  WHERE type = 'NONSE_CREATOR'
                                                    AND abrev = 'EC'
                                                    AND langue = :B1),
                                                 ta.createur)
                                            WHEN ta.createur = 'FTR_CTRL' AND
                                                 NOT EXISTS
                                             (SELECT 1
                                                    FROM eligib_ctrl e
                                                   WHERE e.alerte_id = ta.alerte_id) THEN
                                             NVL((SELECT valeur_trad
                                                   FROM v_tdomaine
                                                  WHERE type = 'NONSE_CREATOR'
                                                    AND abrev = 'AF'
                                                    AND langue = :B1),
                                                 ta.createur)
                                            ELSE
                                             ta.createur
                                          END
                                         ELSE
                                          ta.createur
                                       END creator,
                                       ta.nb_alert_processed nbAlertProcessed
                                  FROM t_alerte ta,
                                       g_personnel gp,
                                       g_individu gi,
                                       g_dossier gd,
                                       (SELECT valeur,
                                               MAX(valeur_trad) valeur_trad
                                          FROM v_tdomaine
                                         WHERE type = 'GROUPE'
                                           AND langue = :B1
                                         GROUP BY valeur) vgr,
                                       (SELECT abrev,
                                               MAX(valeur_trad) valeur_trad
                                          FROM v_tdomaine
                                         WHERE type = 'DV_TYPE_APPEL'
                                           AND langue = :B1
                                         GROUP BY abrev) v,
                                       (SELECT valeur,
                                               MAX(valeur_trad) valeur_trad,
                                               MAX(place) place
                                          FROM v_tdomaine
                                         WHERE type = 'DV_AGENDA_NON_SE'
                                           AND langue = :B1
                                         GROUP BY valeur) v1,
                                       (SELECT /*+ merge push_pred */
                                         ti.refdoss, gi.nom nameclient
                                          FROM t_intervenants ti,
                                               g_individu     gi,
                                               v_intervenants I,
                                               v_domaine      D,
                                               g_dossier      G
                                         WHERE ti.refdoss = G.refdoss
                                           AND ti.refindividu = gi.refindividu
                                           AND I.reftype_aff = 'CLI'
                                           AND I.categdoss = D.abrev
                                           AND I.reftype_bd = ti.reftype
                                           AND D.type = 'categdoss'
                                           AND D.valeur = G.categdoss) cli,
                                       (SELECT /*+ merge push_pred */
                                               t.refdoss, 
                                               i.nom nameclient
                                          FROM g_individu i, 
                                               t_intervenants t
                                         WHERE i.refindividu = t.refindividu
                                           AND t.reftype = 'CL') cl
                                 WHERE ta.catperso = gp.refperso
                                   AND ta.refdoss = gd.refdoss(+)
                                   AND vgr.valeur(+) = gp.groupe
                                   AND ta.typentite = v.abrev(+)
                                   AND ta.typencour = v1.valeur(+)
                                   AND ta.refdoss = cli.refdoss(+)
                                   AND ta.refdoss = cl.refdoss(+)
                                   AND gp.refindividu = gi.refindividu
                                   AND gi.refindividu IN ( SELECT gip.str1
                                                             FROM g_indivparam gip
                                                            WHERE gip.type = 'appel_nonse'
                                                              AND gip.refindividu = :B4
                                                           UNION ALL
                                                           SELECT :B4
                                                             FROM dual
                                                           UNION ALL
                                                           SELECT P.refindividu
                                                             FROM g_personnel P, 
                                                                  g_agenda A
                                                            WHERE P.refrempl = :B5
                                                              AND TO_CHAR(SYSDATE, 'j') = A.jour
                                                              AND A.refperso = P.refperso )
                                   AND NOT EXISTS ( SELECT 1
                                                      FROM v_domaine
                                                     WHERE type = 'DV_AGENDA_NON_SE'
                                                       AND valeur = ta.typencour
                                                       AND abrev6 = 'O' )
                                   AND TRUNC(ta.dtcreation_dt) >= TO_DATE(TO_CHAR(to_date(:B6, 'YYYY-MM-DD'), 'RRRRMMDD'), 'RRRRMMDD')
                                   AND TRUNC(ta.dtcreation_dt) <= TO_DATE(TO_CHAR(to_date(:B6, 'YYYY-MM-DD'), 'RRRRMMDD'), 'RRRRMMDD')
                                   AND ( ta.reffactor IS NULL 
                                   	  OR ta.reffactor IN ( SELECT F.refindividu
                                                             FROM t_gestfctcomp C,
                                                                  g_mangrp      G,
                                                                  t_fctmembmg   F
                                                            WHERE C.refmangrp = G.refmangrp
                                                              AND G.refmangrp = F.refmangrp
                                                              AND C.refperso = :B5 ) ) ) t,
                               (SELECT abrev, MAX(abrev_trad) abrev_trad
                                  FROM v_tdomaine
                                 WHERE type = 'DEVISE'
                                   AND langue = :B1
                                 GROUP BY abrev) v
                         WHERE t.currency = v.abrev(+)) mca
                 WHERE 1 = 1
                   AND UPPER(mca.displayTypeStage) LIKE UPPER(:B7)
                   AND mca.reference LIKE :B8
                 ORDER BY processDate DESC, processDate DESC) foo
         WHERE ROWNUM <= :B9)
 WHERE 1 = 1
   AND rnum >= :B10;
/********************************OLD SQL*******************************************/
/********************************OLD Metrics***************************************/
/*

MODULE                           PROGRAM                                            SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                   ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- -------------------------------------------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
699264288D62D7CCD8E041A7392BBB6E iMX BE                                                                             653      46090 ON CPU               2024/07/16 15:00:10  2024/07/16 15:00:50       4                      +000000000 00:00:40.042 80%
BCA46E732AB6B71AE5EB637D444318C2 iMX BE                                             644ubgcwggs4h  838130951        653      46090 ON CPU               2024/07/16 14:59:50  2024/07/16 14:59:50       1                      +000000000 00:00:00.000 20%


MODULE                           PROGRAM                                            SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                   ACTIVE     NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- -------------------------------------------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
699264288D62D7CCD8E041A7392BBB6E iMX BE                                             8s2gz0vh67b3p  703897654        653      46090 ON CPU               2024/07/16 15:00:40  2024/07/16 15:00:50           2                      +000000000 00:00:10.011 40%
BCA46E732AB6B71AE5EB637D444318C2 iMX BE                                             644ubgcwggs4h  838130951        653      46090 ON CPU               2024/07/16 14:59:50  2024/07/16 14:59:50           1                      +000000000 00:00:00.000 20%
699264288D62D7CCD8E041A7392BBB6E iMX BE                                             068pm6uj3168m 3933482253        653      46090 ON CPU               2024/07/16 15:00:20  2024/07/16 15:00:20           1                      +000000000 00:00:00.000 20%
699264288D62D7CCD8E041A7392BBB6E iMX BE                                             gnrb6upvjz4r5 3697540325        653      46090 ON CPU               2024/07/16 15:00:10  2024/07/16 15:00:10           1                      +000000000 00:00:00.000 20%


SQL_ID        SQL_PLAN_HASH_VALUE SQL_PLAN_LINE_ID SQL_PLAN_OPERATION             SQL_PLAN_OPTIONS                   ACTIVE
------------- ------------------- ---------------- ------------------------------ ------------------------------ ----------
8s2gz0vh67b3p           703897654                                                                                         2 
 

INSTANCE_NUMBER SQL_ID            ELAPSED MAX_WAIT_ON     PC_OF  WAIT_TIME            GETS      READS       ROWS  ELAP/EXEC       GETS/EXEC READS/EXEC  ROWS/EXEC       EXEC PLAN_HASH_VALUE
--------------- ------------- ----------- --------------- ----- ---------- --------------- ---------- ---------- ---------- --------------- ---------- ---------- ---------- ---------------
              1 8s2gz0vh67b3p          14 CPU             100%   12.042711          110695          0          2       6.92           55348          0          1          2   703897654 
 

Plan hash value: 703897654
-------------------------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                             | Name                | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  |
-------------------------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                                      |                     |      1 |        | 50788 (100)|      0 |00:00:13.97 |   57277 |  12457 |
|   1 |  VIEW                                                 | V_TDOMAINE          |      0 |     36 |   144   (0)|      0 |00:00:00.01 |       0 |      0 |
|   2 |   UNION-ALL                                           |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*  3 |    FILTER                                             |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|   4 |     TABLE ACCESS BY INDEX ROWID BATCHED               | V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*  5 |      INDEX RANGE SCAN                                 | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*  6 |    FILTER                                             |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|   7 |     TABLE ACCESS BY INDEX ROWID BATCHED               | V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*  8 |      INDEX RANGE SCAN                                 | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*  9 |    FILTER                                             |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  10 |     TABLE ACCESS BY INDEX ROWID BATCHED               | V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 11 |      INDEX RANGE SCAN                                 | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 12 |    FILTER                                             |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  13 |     TABLE ACCESS BY INDEX ROWID BATCHED               | V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 14 |      INDEX RANGE SCAN                                 | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 15 |    FILTER                                             |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  16 |     TABLE ACCESS BY INDEX ROWID BATCHED               | V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 17 |      INDEX RANGE SCAN                                 | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 18 |    FILTER                                             |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  19 |     TABLE ACCESS BY INDEX ROWID BATCHED               | V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 20 |      INDEX RANGE SCAN                                 | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 21 |    FILTER                                             |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  22 |     TABLE ACCESS BY INDEX ROWID BATCHED               | V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 23 |      INDEX RANGE SCAN                                 | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 24 |    FILTER                                             |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  25 |     TABLE ACCESS BY INDEX ROWID BATCHED               | V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 26 |      INDEX RANGE SCAN                                 | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 27 |    FILTER                                             |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  28 |     TABLE ACCESS BY INDEX ROWID BATCHED               | V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 29 |      INDEX RANGE SCAN                                 | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 30 |    FILTER                                             |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  31 |     TABLE ACCESS BY INDEX ROWID BATCHED               | V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 32 |      INDEX RANGE SCAN                                 | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 33 |    FILTER                                             |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  34 |     TABLE ACCESS BY INDEX ROWID BATCHED               | V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 35 |      INDEX RANGE SCAN                                 | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 36 |    FILTER                                             |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  37 |     TABLE ACCESS BY INDEX ROWID BATCHED               | V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 38 |      INDEX RANGE SCAN                                 | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 39 |    FILTER                                             |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  40 |     TABLE ACCESS BY INDEX ROWID BATCHED               | V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 41 |      INDEX RANGE SCAN                                 | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 42 |    FILTER                                             |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  43 |     TABLE ACCESS BY INDEX ROWID BATCHED               | V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 44 |      INDEX RANGE SCAN                                 | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 45 |    FILTER                                             |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  46 |     TABLE ACCESS BY INDEX ROWID BATCHED               | V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 47 |      INDEX RANGE SCAN                                 | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 48 |    FILTER                                             |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  49 |     TABLE ACCESS BY INDEX ROWID BATCHED               | V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 50 |      INDEX RANGE SCAN                                 | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 51 |    FILTER                                             |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  52 |     TABLE ACCESS BY INDEX ROWID BATCHED               | V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 53 |      INDEX RANGE SCAN                                 | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 54 |    FILTER                                             |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  55 |     TABLE ACCESS BY INDEX ROWID BATCHED               | V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 56 |      INDEX RANGE SCAN                                 | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 57 |    FILTER                                             |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  58 |     TABLE ACCESS BY INDEX ROWID BATCHED               | V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 59 |      INDEX RANGE SCAN                                 | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 60 |    FILTER                                             |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  61 |     TABLE ACCESS BY INDEX ROWID BATCHED               | V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 62 |      INDEX RANGE SCAN                                 | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 63 |    FILTER                                             |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  64 |     TABLE ACCESS BY INDEX ROWID BATCHED               | V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 65 |      INDEX RANGE SCAN                                 | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 66 |    FILTER                                             |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  67 |     TABLE ACCESS BY INDEX ROWID BATCHED               | V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 68 |      INDEX RANGE SCAN                                 | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 69 |    FILTER                                             |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  70 |     TABLE ACCESS BY INDEX ROWID BATCHED               | V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 71 |      INDEX RANGE SCAN                                 | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 72 |    FILTER                                             |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  73 |     TABLE ACCESS BY INDEX ROWID BATCHED               | V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 74 |      INDEX RANGE SCAN                                 | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 75 |    FILTER                                             |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  76 |     TABLE ACCESS BY INDEX ROWID BATCHED               | V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 77 |      INDEX RANGE SCAN                                 | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 78 |    FILTER                                             |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  79 |     TABLE ACCESS BY INDEX ROWID BATCHED               | V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 80 |      INDEX RANGE SCAN                                 | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 81 |    FILTER                                             |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  82 |     TABLE ACCESS BY INDEX ROWID BATCHED               | V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 83 |      INDEX RANGE SCAN                                 | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 84 |    FILTER                                             |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  85 |     TABLE ACCESS BY INDEX ROWID BATCHED               | V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 86 |      INDEX RANGE SCAN                                 | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 87 |    FILTER                                             |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  88 |     TABLE ACCESS BY INDEX ROWID BATCHED               | V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 89 |      INDEX RANGE SCAN                                 | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 90 |    FILTER                                             |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  91 |     TABLE ACCESS BY INDEX ROWID BATCHED               | V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 92 |      INDEX RANGE SCAN                                 | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 93 |    FILTER                                             |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  94 |     TABLE ACCESS BY INDEX ROWID BATCHED               | V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 95 |      INDEX RANGE SCAN                                 | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 96 |    FILTER                                             |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  97 |     TABLE ACCESS BY INDEX ROWID BATCHED               | V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 98 |      INDEX RANGE SCAN                                 | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 99 |    FILTER                                             |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 100 |     TABLE ACCESS BY INDEX ROWID BATCHED               | V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*101 |      INDEX RANGE SCAN                                 | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*102 |    FILTER                                             |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 103 |     TABLE ACCESS BY INDEX ROWID BATCHED               | V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*104 |      INDEX RANGE SCAN                                 | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*105 |    FILTER                                             |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 106 |     TABLE ACCESS BY INDEX ROWID BATCHED               | V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*107 |      INDEX RANGE SCAN                                 | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*108 |    FILTER                                             |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 109 |     TABLE ACCESS BY INDEX ROWID BATCHED               | V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*110 |      INDEX RANGE SCAN                                 | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*111 |     INDEX RANGE SCAN                                  | ELIGB_ALERT_ID_IDX  |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
| 112 |      VIEW                                             | V_TDOMAINE          |      0 |     36 |   144   (0)|      0 |00:00:00.01 |       0 |      0 |
| 113 |       UNION-ALL                                       |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*114 |        FILTER                                         |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 115 |         TABLE ACCESS BY INDEX ROWID BATCHED           | V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*116 |          INDEX RANGE SCAN                             | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*117 |        FILTER                                         |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 118 |         TABLE ACCESS BY INDEX ROWID BATCHED           | V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*119 |          INDEX RANGE SCAN                             | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*120 |        FILTER                                         |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 121 |         TABLE ACCESS BY INDEX ROWID BATCHED           | V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*122 |          INDEX RANGE SCAN                             | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*123 |        FILTER                                         |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 124 |         TABLE ACCESS BY INDEX ROWID BATCHED           | V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*125 |          INDEX RANGE SCAN                             | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*126 |        FILTER                                         |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 127 |         TABLE ACCESS BY INDEX ROWID BATCHED           | V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*128 |          INDEX RANGE SCAN                             | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*129 |        FILTER                                         |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 130 |         TABLE ACCESS BY INDEX ROWID BATCHED           | V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*131 |          INDEX RANGE SCAN                             | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*132 |        FILTER                                         |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 133 |         TABLE ACCESS BY INDEX ROWID BATCHED           | V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*134 |          INDEX RANGE SCAN                             | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*135 |        FILTER                                         |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 136 |         TABLE ACCESS BY INDEX ROWID BATCHED           | V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*137 |          INDEX RANGE SCAN                             | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*138 |        FILTER                                         |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 139 |         TABLE ACCESS BY INDEX ROWID BATCHED           | V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*140 |          INDEX RANGE SCAN                             | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*141 |        FILTER                                         |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 142 |         TABLE ACCESS BY INDEX ROWID BATCHED           | V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*143 |          INDEX RANGE SCAN                             | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*144 |        FILTER                                         |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 145 |         TABLE ACCESS BY INDEX ROWID BATCHED           | V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*146 |          INDEX RANGE SCAN                             | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*147 |        FILTER                                         |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 148 |         TABLE ACCESS BY INDEX ROWID BATCHED           | V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*149 |          INDEX RANGE SCAN                             | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*150 |        FILTER                                         |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 151 |         TABLE ACCESS BY INDEX ROWID BATCHED           | V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*152 |          INDEX RANGE SCAN                             | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*153 |        FILTER                                         |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 154 |         TABLE ACCESS BY INDEX ROWID BATCHED           | V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*155 |          INDEX RANGE SCAN                             | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*156 |        FILTER                                         |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 157 |         TABLE ACCESS BY INDEX ROWID BATCHED           | V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*158 |          INDEX RANGE SCAN                             | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*159 |        FILTER                                         |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 160 |         TABLE ACCESS BY INDEX ROWID BATCHED           | V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*161 |          INDEX RANGE SCAN                             | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*162 |        FILTER                                         |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 163 |         TABLE ACCESS BY INDEX ROWID BATCHED           | V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*164 |          INDEX RANGE SCAN                             | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*165 |        FILTER                                         |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 166 |         TABLE ACCESS BY INDEX ROWID BATCHED           | V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*167 |          INDEX RANGE SCAN                             | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*168 |        FILTER                                         |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 169 |         TABLE ACCESS BY INDEX ROWID BATCHED           | V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*170 |          INDEX RANGE SCAN                             | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*171 |        FILTER                                         |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 172 |         TABLE ACCESS BY INDEX ROWID BATCHED           | V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*173 |          INDEX RANGE SCAN                             | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*174 |        FILTER                                         |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 175 |         TABLE ACCESS BY INDEX ROWID BATCHED           | V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*176 |          INDEX RANGE SCAN                             | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*177 |        FILTER                                         |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 178 |         TABLE ACCESS BY INDEX ROWID BATCHED           | V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*179 |          INDEX RANGE SCAN                             | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*180 |        FILTER                                         |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 181 |         TABLE ACCESS BY INDEX ROWID BATCHED           | V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*182 |          INDEX RANGE SCAN                             | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*183 |        FILTER                                         |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 184 |         TABLE ACCESS BY INDEX ROWID BATCHED           | V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*185 |          INDEX RANGE SCAN                             | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*186 |        FILTER                                         |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 187 |         TABLE ACCESS BY INDEX ROWID BATCHED           | V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*188 |          INDEX RANGE SCAN                             | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*189 |        FILTER                                         |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 190 |         TABLE ACCESS BY INDEX ROWID BATCHED           | V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*191 |          INDEX RANGE SCAN                             | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*192 |        FILTER                                         |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 193 |         TABLE ACCESS BY INDEX ROWID BATCHED           | V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*194 |          INDEX RANGE SCAN                             | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*195 |        FILTER                                         |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 196 |         TABLE ACCESS BY INDEX ROWID BATCHED           | V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*197 |          INDEX RANGE SCAN                             | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*198 |        FILTER                                         |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 199 |         TABLE ACCESS BY INDEX ROWID BATCHED           | V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*200 |          INDEX RANGE SCAN                             | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*201 |        FILTER                                         |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 202 |         TABLE ACCESS BY INDEX ROWID BATCHED           | V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*203 |          INDEX RANGE SCAN                             | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*204 |        FILTER                                         |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 205 |         TABLE ACCESS BY INDEX ROWID BATCHED           | V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*206 |          INDEX RANGE SCAN                             | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*207 |        FILTER                                         |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 208 |         TABLE ACCESS BY INDEX ROWID BATCHED           | V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*209 |          INDEX RANGE SCAN                             | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*210 |        FILTER                                         |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 211 |         TABLE ACCESS BY INDEX ROWID BATCHED           | V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*212 |          INDEX RANGE SCAN                             | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*213 |        FILTER                                         |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 214 |         TABLE ACCESS BY INDEX ROWID BATCHED           | V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*215 |          INDEX RANGE SCAN                             | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*216 |        FILTER                                         |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 217 |         TABLE ACCESS BY INDEX ROWID BATCHED           | V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*218 |          INDEX RANGE SCAN                             | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*219 |        FILTER                                         |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 220 |         TABLE ACCESS BY INDEX ROWID BATCHED           | V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*221 |          INDEX RANGE SCAN                             | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*222 |         INDEX RANGE SCAN                              | ELIGB_ALERT_ID_IDX  |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
| 223 |          VIEW                                         | V_TDOMAINE          |      0 |     36 |   144   (0)|      0 |00:00:00.01 |       0 |      0 |
| 224 |           UNION-ALL                                   |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*225 |            FILTER                                     |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 226 |             TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*227 |              INDEX RANGE SCAN                         | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*228 |            FILTER                                     |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 229 |             TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*230 |              INDEX RANGE SCAN                         | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*231 |            FILTER                                     |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 232 |             TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*233 |              INDEX RANGE SCAN                         | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*234 |            FILTER                                     |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 235 |             TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*236 |              INDEX RANGE SCAN                         | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*237 |            FILTER                                     |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 238 |             TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*239 |              INDEX RANGE SCAN                         | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*240 |            FILTER                                     |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 241 |             TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*242 |              INDEX RANGE SCAN                         | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*243 |            FILTER                                     |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 244 |             TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*245 |              INDEX RANGE SCAN                         | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*246 |            FILTER                                     |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 247 |             TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*248 |              INDEX RANGE SCAN                         | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*249 |            FILTER                                     |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 250 |             TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*251 |              INDEX RANGE SCAN                         | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*252 |            FILTER                                     |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 253 |             TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*254 |              INDEX RANGE SCAN                         | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*255 |            FILTER                                     |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 256 |             TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*257 |              INDEX RANGE SCAN                         | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*258 |            FILTER                                     |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 259 |             TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*260 |              INDEX RANGE SCAN                         | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*261 |            FILTER                                     |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 262 |             TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*263 |              INDEX RANGE SCAN                         | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*264 |            FILTER                                     |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 265 |             TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*266 |              INDEX RANGE SCAN                         | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*267 |            FILTER                                     |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 268 |             TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*269 |              INDEX RANGE SCAN                         | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*270 |            FILTER                                     |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 271 |             TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*272 |              INDEX RANGE SCAN                         | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*273 |            FILTER                                     |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 274 |             TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*275 |              INDEX RANGE SCAN                         | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*276 |            FILTER                                     |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 277 |             TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*278 |              INDEX RANGE SCAN                         | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*279 |            FILTER                                     |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 280 |             TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*281 |              INDEX RANGE SCAN                         | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*282 |            FILTER                                     |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 283 |             TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*284 |              INDEX RANGE SCAN                         | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*285 |            FILTER                                     |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 286 |             TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*287 |              INDEX RANGE SCAN                         | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*288 |            FILTER                                     |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 289 |             TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*290 |              INDEX RANGE SCAN                         | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*291 |            FILTER                                     |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 292 |             TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*293 |              INDEX RANGE SCAN                         | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*294 |            FILTER                                     |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 295 |             TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*296 |              INDEX RANGE SCAN                         | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*297 |            FILTER                                     |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 298 |             TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*299 |              INDEX RANGE SCAN                         | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*300 |            FILTER                                     |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 301 |             TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*302 |              INDEX RANGE SCAN                         | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*303 |            FILTER                                     |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 304 |             TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*305 |              INDEX RANGE SCAN                         | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*306 |            FILTER                                     |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 307 |             TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*308 |              INDEX RANGE SCAN                         | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*309 |            FILTER                                     |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 310 |             TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*311 |              INDEX RANGE SCAN                         | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*312 |            FILTER                                     |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 313 |             TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*314 |              INDEX RANGE SCAN                         | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*315 |            FILTER                                     |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 316 |             TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*317 |              INDEX RANGE SCAN                         | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*318 |            FILTER                                     |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 319 |             TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*320 |              INDEX RANGE SCAN                         | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*321 |            FILTER                                     |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 322 |             TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*323 |              INDEX RANGE SCAN                         | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*324 |            FILTER                                     |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 325 |             TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*326 |              INDEX RANGE SCAN                         | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*327 |            FILTER                                     |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 328 |             TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*329 |              INDEX RANGE SCAN                         | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*330 |            FILTER                                     |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 331 |             TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*332 |              INDEX RANGE SCAN                         | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
| 333 |  NESTED LOOPS                                         |                     |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
| 334 |   NESTED LOOPS                                        |                     |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*335 |    TABLE ACCESS BY INDEX ROWID BATCHED                | G_DOSSIER           |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*336 |     INDEX RANGE SCAN                                  | DOS_ANCREFDOSS      |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*337 |    INDEX UNIQUE SCAN                                  | DOS_REFDOSS         |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*338 |   TABLE ACCESS BY INDEX ROWID                         | G_DOSSIER           |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*339 |    FILTER                                             |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 340 |     TABLE ACCESS BY INDEX ROWID BATCHED               | G_DOSSIER           |      0 |  26295 |  2979   (1)|      0 |00:00:00.01 |       0 |      0 |
|*341 |      INDEX RANGE SCAN                                 | DOS_CATDOSS         |      0 |  26295 |   122   (0)|      0 |00:00:00.01 |       0 |      0 |
|*342 |     TABLE ACCESS BY INDEX ROWID BATCHED               | G_DOSSIER           |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*343 |      INDEX RANGE SCAN                                 | DOS_ANCREFDOSS      |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*344 |  INDEX RANGE SCAN                                     | IDX_ALERTID_DET     |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 345 |   SORT GROUP BY                                       |                     |      0 |      1 |            |      0 |00:00:00.01 |       0 |      0 |
| 346 |    NESTED LOOPS                                       |                     |      0 |      1 |   145   (0)|      0 |00:00:00.01 |       0 |      0 |
| 347 |     TABLE ACCESS BY INDEX ROWID BATCHED               | T_ALERT_NOT_ES_DET  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*348 |      INDEX RANGE SCAN                                 | IDX_ALERTID_DET     |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 349 |     VIEW                                              | V_TDOMAINE          |      0 |      1 |   144   (0)|      0 |00:00:00.01 |       0 |      0 |
| 350 |      UNION ALL PUSHED PREDICATE                       |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*351 |       FILTER                                          |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 352 |        TABLE ACCESS BY INDEX ROWID BATCHED            | V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*353 |         INDEX RANGE SCAN                              | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*354 |       FILTER                                          |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 355 |        TABLE ACCESS BY INDEX ROWID BATCHED            | V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*356 |         INDEX RANGE SCAN                              | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*357 |       FILTER                                          |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 358 |        TABLE ACCESS BY INDEX ROWID BATCHED            | V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*359 |         INDEX RANGE SCAN                              | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*360 |       FILTER                                          |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 361 |        TABLE ACCESS BY INDEX ROWID BATCHED            | V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*362 |         INDEX RANGE SCAN                              | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*363 |       FILTER                                          |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 364 |        TABLE ACCESS BY INDEX ROWID BATCHED            | V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*365 |         INDEX RANGE SCAN                              | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*366 |       FILTER                                          |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 367 |        TABLE ACCESS BY INDEX ROWID BATCHED            | V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*368 |         INDEX RANGE SCAN                              | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*369 |       FILTER                                          |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 370 |        TABLE ACCESS BY INDEX ROWID BATCHED            | V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*371 |         INDEX RANGE SCAN                              | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*372 |       FILTER                                          |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 373 |        TABLE ACCESS BY INDEX ROWID BATCHED            | V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*374 |         INDEX RANGE SCAN                              | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*375 |       FILTER                                          |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 376 |        TABLE ACCESS BY INDEX ROWID BATCHED            | V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*377 |         INDEX RANGE SCAN                              | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*378 |       FILTER                                          |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 379 |        TABLE ACCESS BY INDEX ROWID BATCHED            | V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*380 |         INDEX RANGE SCAN                              | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*381 |       FILTER                                          |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 382 |        TABLE ACCESS BY INDEX ROWID BATCHED            | V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*383 |         INDEX RANGE SCAN                              | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*384 |       FILTER                                          |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 385 |        TABLE ACCESS BY INDEX ROWID BATCHED            | V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*386 |         INDEX RANGE SCAN                              | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*387 |       FILTER                                          |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 388 |        TABLE ACCESS BY INDEX ROWID BATCHED            | V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*389 |         INDEX RANGE SCAN                              | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*390 |       FILTER                                          |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 391 |        TABLE ACCESS BY INDEX ROWID BATCHED            | V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*392 |         INDEX RANGE SCAN                              | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*393 |       FILTER                                          |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 394 |        TABLE ACCESS BY INDEX ROWID BATCHED            | V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*395 |         INDEX RANGE SCAN                              | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*396 |       FILTER                                          |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 397 |        TABLE ACCESS BY INDEX ROWID BATCHED            | V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*398 |         INDEX RANGE SCAN                              | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*399 |       FILTER                                          |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 400 |        TABLE ACCESS BY INDEX ROWID BATCHED            | V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*401 |         INDEX RANGE SCAN                              | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*402 |       FILTER                                          |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 403 |        TABLE ACCESS BY INDEX ROWID BATCHED            | V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*404 |         INDEX RANGE SCAN                              | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*405 |       FILTER                                          |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 406 |        TABLE ACCESS BY INDEX ROWID BATCHED            | V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*407 |         INDEX RANGE SCAN                              | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*408 |       FILTER                                          |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 409 |        TABLE ACCESS BY INDEX ROWID BATCHED            | V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*410 |         INDEX RANGE SCAN                              | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*411 |       FILTER                                          |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 412 |        TABLE ACCESS BY INDEX ROWID BATCHED            | V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*413 |         INDEX RANGE SCAN                              | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*414 |       FILTER                                          |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 415 |        TABLE ACCESS BY INDEX ROWID BATCHED            | V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*416 |         INDEX RANGE SCAN                              | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*417 |       FILTER                                          |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 418 |        TABLE ACCESS BY INDEX ROWID BATCHED            | V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*419 |         INDEX RANGE SCAN                              | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*420 |       FILTER                                          |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 421 |        TABLE ACCESS BY INDEX ROWID BATCHED            | V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*422 |         INDEX RANGE SCAN                              | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*423 |       FILTER                                          |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 424 |        TABLE ACCESS BY INDEX ROWID BATCHED            | V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*425 |         INDEX RANGE SCAN                              | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*426 |       FILTER                                          |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 427 |        TABLE ACCESS BY INDEX ROWID BATCHED            | V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*428 |         INDEX RANGE SCAN                              | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*429 |       FILTER                                          |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 430 |        TABLE ACCESS BY INDEX ROWID BATCHED            | V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*431 |         INDEX RANGE SCAN                              | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*432 |       FILTER                                          |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 433 |        TABLE ACCESS BY INDEX ROWID BATCHED            | V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*434 |         INDEX RANGE SCAN                              | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*435 |       FILTER                                          |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 436 |        TABLE ACCESS BY INDEX ROWID BATCHED            | V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*437 |         INDEX RANGE SCAN                              | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*438 |       FILTER                                          |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 439 |        TABLE ACCESS BY INDEX ROWID BATCHED            | V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*440 |         INDEX RANGE SCAN                              | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*441 |       FILTER                                          |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 442 |        TABLE ACCESS BY INDEX ROWID BATCHED            | V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*443 |         INDEX RANGE SCAN                              | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*444 |       FILTER                                          |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 445 |        TABLE ACCESS BY INDEX ROWID BATCHED            | V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*446 |         INDEX RANGE SCAN                              | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*447 |       FILTER                                          |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 448 |        TABLE ACCESS BY INDEX ROWID BATCHED            | V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*449 |         INDEX RANGE SCAN                              | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*450 |       FILTER                                          |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 451 |        TABLE ACCESS BY INDEX ROWID BATCHED            | V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*452 |         INDEX RANGE SCAN                              | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*453 |       FILTER                                          |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 454 |        TABLE ACCESS BY INDEX ROWID BATCHED            | V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*455 |         INDEX RANGE SCAN                              | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*456 |       FILTER                                          |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 457 |        TABLE ACCESS BY INDEX ROWID BATCHED            | V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*458 |         INDEX RANGE SCAN                              | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
| 459 |  NESTED LOOPS                                         |                     |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
| 460 |   NESTED LOOPS                                        |                     |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*461 |    TABLE ACCESS BY INDEX ROWID BATCHED                | G_DOSSIER           |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*462 |     INDEX RANGE SCAN                                  | DOS_ANCREFDOSS      |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*463 |    INDEX UNIQUE SCAN                                  | DOS_REFDOSS         |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*464 |   TABLE ACCESS BY INDEX ROWID                         | G_DOSSIER           |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*465 |    COUNT STOPKEY                                      |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 466 |     NESTED LOOPS                                      |                     |      0 |      1 |     8   (0)|      0 |00:00:00.01 |       0 |      0 |
| 467 |      NESTED LOOPS                                     |                     |      0 |      1 |     8   (0)|      0 |00:00:00.01 |       0 |      0 |
| 468 |       NESTED LOOPS                                    |                     |      0 |      1 |     6   (0)|      0 |00:00:00.01 |       0 |      0 |
| 469 |        NESTED LOOPS                                   |                     |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*470 |         TABLE ACCESS BY INDEX ROWID BATCHED           | G_DOSSIER           |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*471 |          INDEX RANGE SCAN                             | DOS_ANCREFDOSS      |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*472 |         TABLE ACCESS BY INDEX ROWID                   | G_DOSSIER           |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*473 |          INDEX UNIQUE SCAN                            | DOS_REFDOSS         |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*474 |        INDEX RANGE SCAN                               | INT_REFDOSS         |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*475 |       INDEX UNIQUE SCAN                               | IND_REFINDIV        |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 476 |      TABLE ACCESS BY INDEX ROWID                      | G_INDIVIDU          |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*477 |     COUNT STOPKEY                                     |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 478 |      NESTED LOOPS                                     |                     |      0 |      3 |    14   (0)|      0 |00:00:00.01 |       0 |      0 |
| 479 |       NESTED LOOPS                                    |                     |      0 |      3 |    14   (0)|      0 |00:00:00.01 |       0 |      0 |
| 480 |        NESTED LOOPS                                   |                     |      0 |      3 |     8   (0)|      0 |00:00:00.01 |       0 |      0 |
| 481 |         TABLE ACCESS BY INDEX ROWID BATCHED           | G_DOSSIER           |      0 |     60 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*482 |          INDEX RANGE SCAN                             | DOS_ANCREFDOSS      |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*483 |         INDEX RANGE SCAN                              | INT_REFDOSS         |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*484 |        INDEX UNIQUE SCAN                              | IND_REFINDIV        |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 485 |       TABLE ACCESS BY INDEX ROWID                     | G_INDIVIDU          |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*486 |  VIEW                                                 |                     |      1 |      1 | 50788   (1)|      0 |00:00:13.97 |   57277 |  12457 |
|*487 |   COUNT STOPKEY                                       |                     |      1 |        |            |      0 |00:00:13.97 |   57277 |  12457 |
| 488 |    VIEW                                               |                     |      1 |      1 | 50788   (1)|      0 |00:00:13.97 |   57277 |  12457 |
|*489 |     SORT ORDER BY STOPKEY                             |                     |      1 |      1 | 50788   (1)|      0 |00:00:13.97 |   57277 |  12457 |
|*490 |      FILTER                                           |                     |      1 |        |            |      0 |00:00:13.97 |   57277 |  12457 |
|*491 |       FILTER                                          |                     |      1 |        |            |      0 |00:00:13.97 |   57277 |  12457 |
| 492 |        NESTED LOOPS OUTER                             |                     |      1 |      1 |  1131   (1)|      0 |00:00:13.97 |   57277 |  12457 |
| 493 |         NESTED LOOPS OUTER                            |                     |      1 |      1 |  1023   (1)|      0 |00:00:13.97 |   57277 |  12457 |
| 494 |          NESTED LOOPS OUTER                           |                     |      1 |      1 |   879   (1)|      0 |00:00:13.97 |   57277 |  12457 |
| 495 |           NESTED LOOPS OUTER                          |                     |      1 |      1 |   771   (1)|      0 |00:00:13.97 |   57277 |  12457 |
| 496 |            NESTED LOOPS OUTER                         |                     |      1 |      1 |   761   (1)|      0 |00:00:13.97 |   57277 |  12457 |
|*497 |             FILTER                                    |                     |      1 |        |            |      0 |00:00:13.97 |   57277 |  12457 |
| 498 |              NESTED LOOPS OUTER                       |                     |      1 |      1 |   756   (1)|      0 |00:00:13.97 |   57277 |  12457 |
| 499 |               NESTED LOOPS OUTER                      |                     |      1 |      1 |   612   (1)|      0 |00:00:13.97 |   57277 |  12457 |
| 500 |                NESTED LOOPS ANTI                      |                     |      1 |      1 |   610   (1)|      0 |00:00:13.97 |   57277 |  12457 |
| 501 |                 NESTED LOOPS                          |                     |      1 |      1 |   607   (1)|      0 |00:00:13.97 |   57277 |  12457 |
|*502 |                  HASH JOIN                            |                     |      1 |      1 |   112   (0)|    349 |00:00:00.04 |    1310 |      7 |
| 503 |                   NESTED LOOPS                        |                     |      1 |      4 |    16   (0)|    349 |00:00:00.03 |     862 |      7 |
| 504 |                    NESTED LOOPS                       |                     |      1 |      4 |    16   (0)|    349 |00:00:00.02 |     577 |      4 |
| 505 |                     VIEW                              | VW_NSO_1            |      1 |      4 |     8   (0)|    350 |00:00:00.02 |       7 |      4 |
| 506 |                      HASH UNIQUE                      |                     |      1 |      4 |     8   (0)|    350 |00:00:00.01 |       7 |      4 |
| 507 |                       UNION-ALL                       |                     |      1 |        |            |    351 |00:00:00.01 |       7 |      4 |
|*508 |                        INDEX RANGE SCAN               | G_INDIVPARAM_REFIND |      1 |      2 |     3   (0)|    350 |00:00:00.01 |       6 |      4 |
| 509 |                        FAST DUAL                      |                     |      1 |      1 |     2   (0)|      1 |00:00:00.01 |       0 |      0 |
| 510 |                        NESTED LOOPS                   |                     |      1 |      1 |     3   (0)|      0 |00:00:00.01 |       1 |      0 |
| 511 |                         NESTED LOOPS                  |                     |      1 |      1 |     3   (0)|      0 |00:00:00.01 |       1 |      0 |
|*512 |                          INDEX RANGE SCAN             | AGE_PERSOJOUR       |      1 |      1 |     1   (0)|      0 |00:00:00.01 |       1 |      0 |
|*513 |                          INDEX RANGE SCAN             | GPERSREFP           |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*514 |                         TABLE ACCESS BY INDEX ROWID   | G_PERSONNEL         |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*515 |                     INDEX UNIQUE SCAN                 | IND_REFINDIV        |    350 |      1 |     1   (0)|    349 |00:00:00.01 |     570 |      0 |
| 516 |                    TABLE ACCESS BY INDEX ROWID        | G_INDIVIDU          |    349 |      1 |     2   (0)|    349 |00:00:00.01 |     285 |      3 |
| 517 |                   TABLE ACCESS FULL                   | G_PERSONNEL         |      1 |   3310 |    96   (0)|   3310 |00:00:00.01 |     448 |      0 |
|*518 |                  TABLE ACCESS BY INDEX ROWID BATCHED  | T_ALERTE            |    349 |      1 |   494   (0)|      0 |00:00:13.93 |   55967 |  12450 |
|*519 |                   INDEX RANGE SCAN                    | AL_PERS_TYPENC      |    349 |   1600 |    35   (0)|    177K|00:00:04.55 |    4726 |   3870 |
|*520 |                 TABLE ACCESS BY INDEX ROWID BATCHED   | V_DOMAINE           |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*521 |                  INDEX RANGE SCAN                     | DOM_TYPVAL          |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 522 |                TABLE ACCESS BY INDEX ROWID            | G_DOSSIER           |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*523 |                 INDEX UNIQUE SCAN                     | DOS_REFDOSS         |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 524 |               VIEW PUSHED PREDICATE                   |                     |      0 |      1 |   144   (0)|      0 |00:00:00.01 |       0 |      0 |
| 525 |                SORT GROUP BY                          |                     |      0 |      1 |   144   (0)|      0 |00:00:00.01 |       0 |      0 |
| 526 |                 VIEW                                  | V_TDOMAINE          |      0 |     36 |   144   (0)|      0 |00:00:00.01 |       0 |      0 |
| 527 |                  UNION-ALL                            |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*528 |                   FILTER                              |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 529 |                    TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*530 |                     INDEX RANGE SCAN                  | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*531 |                   FILTER                              |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 532 |                    TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*533 |                     INDEX RANGE SCAN                  | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*534 |                   FILTER                              |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 535 |                    TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*536 |                     INDEX RANGE SCAN                  | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*537 |                   FILTER                              |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 538 |                    TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*539 |                     INDEX RANGE SCAN                  | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*540 |                   FILTER                              |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 541 |                    TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*542 |                     INDEX RANGE SCAN                  | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*543 |                   FILTER                              |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 544 |                    TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*545 |                     INDEX RANGE SCAN                  | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*546 |                   FILTER                              |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 547 |                    TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*548 |                     INDEX RANGE SCAN                  | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*549 |                   FILTER                              |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 550 |                    TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*551 |                     INDEX RANGE SCAN                  | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*552 |                   FILTER                              |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 553 |                    TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*554 |                     INDEX RANGE SCAN                  | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*555 |                   FILTER                              |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 556 |                    TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*557 |                     INDEX RANGE SCAN                  | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*558 |                   FILTER                              |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 559 |                    TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*560 |                     INDEX RANGE SCAN                  | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*561 |                   FILTER                              |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 562 |                    TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*563 |                     INDEX RANGE SCAN                  | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*564 |                   FILTER                              |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 565 |                    TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*566 |                     INDEX RANGE SCAN                  | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*567 |                   FILTER                              |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 568 |                    TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*569 |                     INDEX RANGE SCAN                  | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*570 |                   FILTER                              |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 571 |                    TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*572 |                     INDEX RANGE SCAN                  | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*573 |                   FILTER                              |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 574 |                    TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*575 |                     INDEX RANGE SCAN                  | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*576 |                   FILTER                              |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 577 |                    TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*578 |                     INDEX RANGE SCAN                  | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*579 |                   FILTER                              |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 580 |                    TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*581 |                     INDEX RANGE SCAN                  | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*582 |                   FILTER                              |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 583 |                    TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*584 |                     INDEX RANGE SCAN                  | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*585 |                   FILTER                              |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 586 |                    TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*587 |                     INDEX RANGE SCAN                  | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*588 |                   FILTER                              |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 589 |                    TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*590 |                     INDEX RANGE SCAN                  | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*591 |                   FILTER                              |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 592 |                    TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*593 |                     INDEX RANGE SCAN                  | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*594 |                   FILTER                              |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 595 |                    TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*596 |                     INDEX RANGE SCAN                  | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*597 |                   FILTER                              |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 598 |                    TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*599 |                     INDEX RANGE SCAN                  | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*600 |                   FILTER                              |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 601 |                    TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*602 |                     INDEX RANGE SCAN                  | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*603 |                   FILTER                              |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 604 |                    TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*605 |                     INDEX RANGE SCAN                  | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*606 |                   FILTER                              |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 607 |                    TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*608 |                     INDEX RANGE SCAN                  | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*609 |                   FILTER                              |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 610 |                    TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*611 |                     INDEX RANGE SCAN                  | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*612 |                   FILTER                              |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 613 |                    TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*614 |                     INDEX RANGE SCAN                  | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*615 |                   FILTER                              |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 616 |                    TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*617 |                     INDEX RANGE SCAN                  | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*618 |                   FILTER                              |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 619 |                    TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*620 |                     INDEX RANGE SCAN                  | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*621 |                   FILTER                              |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 622 |                    TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*623 |                     INDEX RANGE SCAN                  | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*624 |                   FILTER                              |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 625 |                    TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*626 |                     INDEX RANGE SCAN                  | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*627 |                   FILTER                              |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 628 |                    TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*629 |                     INDEX RANGE SCAN                  | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*630 |                   FILTER                              |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 631 |                    TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*632 |                     INDEX RANGE SCAN                  | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*633 |                   FILTER                              |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 634 |                    TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*635 |                     INDEX RANGE SCAN                  | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
| 636 |             VIEW PUSHED PREDICATE                     |                     |      0 |      1 |     5   (0)|      0 |00:00:00.01 |       0 |      0 |
| 637 |              NESTED LOOPS                             |                     |      0 |      1 |     5   (0)|      0 |00:00:00.01 |       0 |      0 |
| 638 |               NESTED LOOPS                            |                     |      0 |      1 |     5   (0)|      0 |00:00:00.01 |       0 |      0 |
|*639 |                INDEX RANGE SCAN                       | INT_REFDOSS         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*640 |                INDEX UNIQUE SCAN                      | IND_REFINDIV        |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 641 |               TABLE ACCESS BY INDEX ROWID             | G_INDIVIDU          |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
| 642 |            VIEW PUSHED PREDICATE                      |                     |      0 |      1 |    10   (0)|      0 |00:00:00.01 |       0 |      0 |
| 643 |             NESTED LOOPS                              |                     |      0 |      1 |    10   (0)|      0 |00:00:00.01 |       0 |      0 |
| 644 |              NESTED LOOPS                             |                     |      0 |      1 |    10   (0)|      0 |00:00:00.01 |       0 |      0 |
| 645 |               NESTED LOOPS                            |                     |      0 |      1 |     8   (0)|      0 |00:00:00.01 |       0 |      0 |
| 646 |                NESTED LOOPS                           |                     |      0 |      1 |     7   (0)|      0 |00:00:00.01 |       0 |      0 |
| 647 |                 NESTED LOOPS                          |                     |      0 |      1 |     5   (0)|      0 |00:00:00.01 |       0 |      0 |
| 648 |                  TABLE ACCESS BY INDEX ROWID          | G_DOSSIER           |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*649 |                   INDEX UNIQUE SCAN                   | DOS_REFDOSS         |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*650 |                  INDEX RANGE SCAN                     | DOM_TYPABREV        |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*651 |                 INDEX RANGE SCAN                      | INT_REFDOSS         |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*652 |                TABLE ACCESS BY INDEX ROWID BATCHED    | V_INTERVENANTS      |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*653 |                 INDEX RANGE SCAN                      | V_INTERVENANTS_AK   |      0 |      1 |     0   (0)|      0 |00:00:00.01 |       0 |      0 |
|*654 |               INDEX UNIQUE SCAN                       | IND_REFINDIV        |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 655 |              TABLE ACCESS BY INDEX ROWID              | G_INDIVIDU          |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
| 656 |           VIEW PUSHED PREDICATE                       |                     |      0 |      1 |   108   (0)|      0 |00:00:00.01 |       0 |      0 |
| 657 |            SORT GROUP BY                              |                     |      0 |      1 |   108   (0)|      0 |00:00:00.01 |       0 |      0 |
| 658 |             VIEW                                      | V_TDOMAINE          |      0 |     36 |   108   (0)|      0 |00:00:00.01 |       0 |      0 |
| 659 |              UNION-ALL                                |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*660 |               FILTER                                  |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 661 |                TABLE ACCESS BY INDEX ROWID BATCHED    | V_DOMAINE           |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*662 |                 INDEX RANGE SCAN                      | DOM_TYPVAL          |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*663 |               FILTER                                  |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 664 |                TABLE ACCESS BY INDEX ROWID BATCHED    | V_DOMAINE           |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*665 |                 INDEX RANGE SCAN                      | DOM_TYPVAL          |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*666 |               FILTER                                  |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 667 |                TABLE ACCESS BY INDEX ROWID BATCHED    | V_DOMAINE           |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*668 |                 INDEX RANGE SCAN                      | DOM_TYPVAL          |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*669 |               FILTER                                  |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 670 |                TABLE ACCESS BY INDEX ROWID BATCHED    | V_DOMAINE           |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*671 |                 INDEX RANGE SCAN                      | DOM_TYPVAL          |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*672 |               FILTER                                  |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 673 |                TABLE ACCESS BY INDEX ROWID BATCHED    | V_DOMAINE           |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*674 |                 INDEX RANGE SCAN                      | DOM_TYPVAL          |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*675 |               FILTER                                  |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 676 |                TABLE ACCESS BY INDEX ROWID BATCHED    | V_DOMAINE           |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*677 |                 INDEX RANGE SCAN                      | DOM_TYPVAL          |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*678 |               FILTER                                  |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 679 |                TABLE ACCESS BY INDEX ROWID BATCHED    | V_DOMAINE           |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*680 |                 INDEX RANGE SCAN                      | DOM_TYPVAL          |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*681 |               FILTER                                  |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 682 |                TABLE ACCESS BY INDEX ROWID BATCHED    | V_DOMAINE           |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*683 |                 INDEX RANGE SCAN                      | DOM_TYPVAL          |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*684 |               FILTER                                  |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 685 |                TABLE ACCESS BY INDEX ROWID BATCHED    | V_DOMAINE           |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*686 |                 INDEX RANGE SCAN                      | DOM_TYPVAL          |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*687 |               FILTER                                  |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 688 |                TABLE ACCESS BY INDEX ROWID BATCHED    | V_DOMAINE           |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*689 |                 INDEX RANGE SCAN                      | DOM_TYPVAL          |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*690 |               FILTER                                  |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 691 |                TABLE ACCESS BY INDEX ROWID BATCHED    | V_DOMAINE           |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*692 |                 INDEX RANGE SCAN                      | DOM_TYPVAL          |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*693 |               FILTER                                  |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 694 |                TABLE ACCESS BY INDEX ROWID BATCHED    | V_DOMAINE           |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*695 |                 INDEX RANGE SCAN                      | DOM_TYPVAL          |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*696 |               FILTER                                  |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 697 |                TABLE ACCESS BY INDEX ROWID BATCHED    | V_DOMAINE           |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*698 |                 INDEX RANGE SCAN                      | DOM_TYPVAL          |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*699 |               FILTER                                  |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 700 |                TABLE ACCESS BY INDEX ROWID BATCHED    | V_DOMAINE           |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*701 |                 INDEX RANGE SCAN                      | DOM_TYPVAL          |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*702 |               FILTER                                  |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 703 |                TABLE ACCESS BY INDEX ROWID BATCHED    | V_DOMAINE           |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*704 |                 INDEX RANGE SCAN                      | DOM_TYPVAL          |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*705 |               FILTER                                  |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 706 |                TABLE ACCESS BY INDEX ROWID BATCHED    | V_DOMAINE           |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*707 |                 INDEX RANGE SCAN                      | DOM_TYPVAL          |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*708 |               FILTER                                  |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 709 |                TABLE ACCESS BY INDEX ROWID BATCHED    | V_DOMAINE           |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*710 |                 INDEX RANGE SCAN                      | DOM_TYPVAL          |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*711 |               FILTER                                  |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 712 |                TABLE ACCESS BY INDEX ROWID BATCHED    | V_DOMAINE           |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*713 |                 INDEX RANGE SCAN                      | DOM_TYPVAL          |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*714 |               FILTER                                  |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 715 |                TABLE ACCESS BY INDEX ROWID BATCHED    | V_DOMAINE           |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*716 |                 INDEX RANGE SCAN                      | DOM_TYPVAL          |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*717 |               FILTER                                  |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 718 |                TABLE ACCESS BY INDEX ROWID BATCHED    | V_DOMAINE           |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*719 |                 INDEX RANGE SCAN                      | DOM_TYPVAL          |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*720 |               FILTER                                  |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 721 |                TABLE ACCESS BY INDEX ROWID BATCHED    | V_DOMAINE           |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*722 |                 INDEX RANGE SCAN                      | DOM_TYPVAL          |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*723 |               FILTER                                  |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 724 |                TABLE ACCESS BY INDEX ROWID BATCHED    | V_DOMAINE           |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*725 |                 INDEX RANGE SCAN                      | DOM_TYPVAL          |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*726 |               FILTER                                  |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 727 |                TABLE ACCESS BY INDEX ROWID BATCHED    | V_DOMAINE           |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*728 |                 INDEX RANGE SCAN                      | DOM_TYPVAL          |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*729 |               FILTER                                  |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 730 |                TABLE ACCESS BY INDEX ROWID BATCHED    | V_DOMAINE           |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*731 |                 INDEX RANGE SCAN                      | DOM_TYPVAL          |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*732 |               FILTER                                  |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 733 |                TABLE ACCESS BY INDEX ROWID BATCHED    | V_DOMAINE           |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*734 |                 INDEX RANGE SCAN                      | DOM_TYPVAL          |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*735 |               FILTER                                  |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 736 |                TABLE ACCESS BY INDEX ROWID BATCHED    | V_DOMAINE           |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*737 |                 INDEX RANGE SCAN                      | DOM_TYPVAL          |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*738 |               FILTER                                  |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 739 |                TABLE ACCESS BY INDEX ROWID BATCHED    | V_DOMAINE           |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*740 |                 INDEX RANGE SCAN                      | DOM_TYPVAL          |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*741 |               FILTER                                  |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 742 |                TABLE ACCESS BY INDEX ROWID BATCHED    | V_DOMAINE           |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*743 |                 INDEX RANGE SCAN                      | DOM_TYPVAL          |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*744 |               FILTER                                  |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 745 |                TABLE ACCESS BY INDEX ROWID BATCHED    | V_DOMAINE           |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*746 |                 INDEX RANGE SCAN                      | DOM_TYPVAL          |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*747 |               FILTER                                  |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 748 |                TABLE ACCESS BY INDEX ROWID BATCHED    | V_DOMAINE           |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*749 |                 INDEX RANGE SCAN                      | DOM_TYPVAL          |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*750 |               FILTER                                  |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 751 |                TABLE ACCESS BY INDEX ROWID BATCHED    | V_DOMAINE           |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*752 |                 INDEX RANGE SCAN                      | DOM_TYPVAL          |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*753 |               FILTER                                  |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 754 |                TABLE ACCESS BY INDEX ROWID BATCHED    | V_DOMAINE           |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*755 |                 INDEX RANGE SCAN                      | DOM_TYPVAL          |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*756 |               FILTER                                  |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 757 |                TABLE ACCESS BY INDEX ROWID BATCHED    | V_DOMAINE           |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*758 |                 INDEX RANGE SCAN                      | DOM_TYPVAL          |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*759 |               FILTER                                  |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 760 |                TABLE ACCESS BY INDEX ROWID BATCHED    | V_DOMAINE           |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*761 |                 INDEX RANGE SCAN                      | DOM_TYPVAL          |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*762 |               FILTER                                  |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 763 |                TABLE ACCESS BY INDEX ROWID BATCHED    | V_DOMAINE           |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*764 |                 INDEX RANGE SCAN                      | DOM_TYPVAL          |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*765 |               FILTER                                  |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 766 |                TABLE ACCESS BY INDEX ROWID BATCHED    | V_DOMAINE           |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*767 |                 INDEX RANGE SCAN                      | DOM_TYPVAL          |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 768 |          VIEW PUSHED PREDICATE                        |                     |      0 |      1 |   144   (0)|      0 |00:00:00.01 |       0 |      0 |
| 769 |           SORT GROUP BY                               |                     |      0 |      1 |   144   (0)|      0 |00:00:00.01 |       0 |      0 |
| 770 |            VIEW                                       | V_TDOMAINE          |      0 |     36 |   144   (0)|      0 |00:00:00.01 |       0 |      0 |
| 771 |             UNION-ALL                                 |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*772 |              FILTER                                   |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 773 |               TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*774 |                INDEX RANGE SCAN                       | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*775 |              FILTER                                   |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 776 |               TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*777 |                INDEX RANGE SCAN                       | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*778 |              FILTER                                   |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 779 |               TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*780 |                INDEX RANGE SCAN                       | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*781 |              FILTER                                   |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 782 |               TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*783 |                INDEX RANGE SCAN                       | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*784 |              FILTER                                   |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 785 |               TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*786 |                INDEX RANGE SCAN                       | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*787 |              FILTER                                   |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 788 |               TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*789 |                INDEX RANGE SCAN                       | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*790 |              FILTER                                   |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 791 |               TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*792 |                INDEX RANGE SCAN                       | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*793 |              FILTER                                   |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 794 |               TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*795 |                INDEX RANGE SCAN                       | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*796 |              FILTER                                   |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 797 |               TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*798 |                INDEX RANGE SCAN                       | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*799 |              FILTER                                   |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 800 |               TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*801 |                INDEX RANGE SCAN                       | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*802 |              FILTER                                   |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 803 |               TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*804 |                INDEX RANGE SCAN                       | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*805 |              FILTER                                   |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 806 |               TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*807 |                INDEX RANGE SCAN                       | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*808 |              FILTER                                   |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 809 |               TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*810 |                INDEX RANGE SCAN                       | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*811 |              FILTER                                   |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 812 |               TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*813 |                INDEX RANGE SCAN                       | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*814 |              FILTER                                   |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 815 |               TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*816 |                INDEX RANGE SCAN                       | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*817 |              FILTER                                   |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 818 |               TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*819 |                INDEX RANGE SCAN                       | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*820 |              FILTER                                   |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 821 |               TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*822 |                INDEX RANGE SCAN                       | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*823 |              FILTER                                   |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 824 |               TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*825 |                INDEX RANGE SCAN                       | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*826 |              FILTER                                   |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 827 |               TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*828 |                INDEX RANGE SCAN                       | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*829 |              FILTER                                   |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 830 |               TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*831 |                INDEX RANGE SCAN                       | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*832 |              FILTER                                   |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 833 |               TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*834 |                INDEX RANGE SCAN                       | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*835 |              FILTER                                   |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 836 |               TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*837 |                INDEX RANGE SCAN                       | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*838 |              FILTER                                   |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 839 |               TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*840 |                INDEX RANGE SCAN                       | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*841 |              FILTER                                   |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 842 |               TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*843 |                INDEX RANGE SCAN                       | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*844 |              FILTER                                   |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 845 |               TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*846 |                INDEX RANGE SCAN                       | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*847 |              FILTER                                   |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 848 |               TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*849 |                INDEX RANGE SCAN                       | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*850 |              FILTER                                   |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 851 |               TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*852 |                INDEX RANGE SCAN                       | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*853 |              FILTER                                   |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 854 |               TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*855 |                INDEX RANGE SCAN                       | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*856 |              FILTER                                   |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 857 |               TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*858 |                INDEX RANGE SCAN                       | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*859 |              FILTER                                   |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 860 |               TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*861 |                INDEX RANGE SCAN                       | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*862 |              FILTER                                   |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 863 |               TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*864 |                INDEX RANGE SCAN                       | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*865 |              FILTER                                   |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 866 |               TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*867 |                INDEX RANGE SCAN                       | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*868 |              FILTER                                   |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 869 |               TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*870 |                INDEX RANGE SCAN                       | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*871 |              FILTER                                   |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 872 |               TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*873 |                INDEX RANGE SCAN                       | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*874 |              FILTER                                   |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 875 |               TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*876 |                INDEX RANGE SCAN                       | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*877 |              FILTER                                   |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 878 |               TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*879 |                INDEX RANGE SCAN                       | DOM_TYPABREV        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
| 880 |         VIEW PUSHED PREDICATE                         |                     |      0 |      1 |   108   (0)|      0 |00:00:00.01 |       0 |      0 |
| 881 |          SORT GROUP BY                                |                     |      0 |      1 |   108   (0)|      0 |00:00:00.01 |       0 |      0 |
| 882 |           VIEW                                        | V_TDOMAINE          |      0 |     36 |   108   (0)|      0 |00:00:00.01 |       0 |      0 |
| 883 |            UNION-ALL                                  |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*884 |             FILTER                                    |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 885 |              TABLE ACCESS BY INDEX ROWID BATCHED      | V_DOMAINE           |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*886 |               INDEX RANGE SCAN                        | DOM_TYPVAL          |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*887 |             FILTER                                    |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 888 |              TABLE ACCESS BY INDEX ROWID BATCHED      | V_DOMAINE           |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*889 |               INDEX RANGE SCAN                        | DOM_TYPVAL          |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*890 |             FILTER                                    |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 891 |              TABLE ACCESS BY INDEX ROWID BATCHED      | V_DOMAINE           |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*892 |               INDEX RANGE SCAN                        | DOM_TYPVAL          |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*893 |             FILTER                                    |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 894 |              TABLE ACCESS BY INDEX ROWID BATCHED      | V_DOMAINE           |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*895 |               INDEX RANGE SCAN                        | DOM_TYPVAL          |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*896 |             FILTER                                    |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 897 |              TABLE ACCESS BY INDEX ROWID BATCHED      | V_DOMAINE           |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*898 |               INDEX RANGE SCAN                        | DOM_TYPVAL          |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*899 |             FILTER                                    |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 900 |              TABLE ACCESS BY INDEX ROWID BATCHED      | V_DOMAINE           |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*901 |               INDEX RANGE SCAN                        | DOM_TYPVAL          |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*902 |             FILTER                                    |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 903 |              TABLE ACCESS BY INDEX ROWID BATCHED      | V_DOMAINE           |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*904 |               INDEX RANGE SCAN                        | DOM_TYPVAL          |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*905 |             FILTER                                    |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 906 |              TABLE ACCESS BY INDEX ROWID BATCHED      | V_DOMAINE           |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*907 |               INDEX RANGE SCAN                        | DOM_TYPVAL          |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*908 |             FILTER                                    |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 909 |              TABLE ACCESS BY INDEX ROWID BATCHED      | V_DOMAINE           |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*910 |               INDEX RANGE SCAN                        | DOM_TYPVAL          |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*911 |             FILTER                                    |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 912 |              TABLE ACCESS BY INDEX ROWID BATCHED      | V_DOMAINE           |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*913 |               INDEX RANGE SCAN                        | DOM_TYPVAL          |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*914 |             FILTER                                    |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 915 |              TABLE ACCESS BY INDEX ROWID BATCHED      | V_DOMAINE           |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*916 |               INDEX RANGE SCAN                        | DOM_TYPVAL          |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*917 |             FILTER                                    |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 918 |              TABLE ACCESS BY INDEX ROWID BATCHED      | V_DOMAINE           |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*919 |               INDEX RANGE SCAN                        | DOM_TYPVAL          |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*920 |             FILTER                                    |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 921 |              TABLE ACCESS BY INDEX ROWID BATCHED      | V_DOMAINE           |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*922 |               INDEX RANGE SCAN                        | DOM_TYPVAL          |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*923 |             FILTER                                    |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 924 |              TABLE ACCESS BY INDEX ROWID BATCHED      | V_DOMAINE           |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*925 |               INDEX RANGE SCAN                        | DOM_TYPVAL          |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*926 |             FILTER                                    |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 927 |              TABLE ACCESS BY INDEX ROWID BATCHED      | V_DOMAINE           |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*928 |               INDEX RANGE SCAN                        | DOM_TYPVAL          |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*929 |             FILTER                                    |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 930 |              TABLE ACCESS BY INDEX ROWID BATCHED      | V_DOMAINE           |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*931 |               INDEX RANGE SCAN                        | DOM_TYPVAL          |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*932 |             FILTER                                    |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 933 |              TABLE ACCESS BY INDEX ROWID BATCHED      | V_DOMAINE           |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*934 |               INDEX RANGE SCAN                        | DOM_TYPVAL          |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*935 |             FILTER                                    |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 936 |              TABLE ACCESS BY INDEX ROWID BATCHED      | V_DOMAINE           |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*937 |               INDEX RANGE SCAN                        | DOM_TYPVAL          |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*938 |             FILTER                                    |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 939 |              TABLE ACCESS BY INDEX ROWID BATCHED      | V_DOMAINE           |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*940 |               INDEX RANGE SCAN                        | DOM_TYPVAL          |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*941 |             FILTER                                    |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 942 |              TABLE ACCESS BY INDEX ROWID BATCHED      | V_DOMAINE           |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*943 |               INDEX RANGE SCAN                        | DOM_TYPVAL          |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*944 |             FILTER                                    |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 945 |              TABLE ACCESS BY INDEX ROWID BATCHED      | V_DOMAINE           |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*946 |               INDEX RANGE SCAN                        | DOM_TYPVAL          |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*947 |             FILTER                                    |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 948 |              TABLE ACCESS BY INDEX ROWID BATCHED      | V_DOMAINE           |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*949 |               INDEX RANGE SCAN                        | DOM_TYPVAL          |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*950 |             FILTER                                    |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 951 |              TABLE ACCESS BY INDEX ROWID BATCHED      | V_DOMAINE           |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*952 |               INDEX RANGE SCAN                        | DOM_TYPVAL          |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*953 |             FILTER                                    |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 954 |              TABLE ACCESS BY INDEX ROWID BATCHED      | V_DOMAINE           |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*955 |               INDEX RANGE SCAN                        | DOM_TYPVAL          |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*956 |             FILTER                                    |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 957 |              TABLE ACCESS BY INDEX ROWID BATCHED      | V_DOMAINE           |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*958 |               INDEX RANGE SCAN                        | DOM_TYPVAL          |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*959 |             FILTER                                    |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 960 |              TABLE ACCESS BY INDEX ROWID BATCHED      | V_DOMAINE           |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*961 |               INDEX RANGE SCAN                        | DOM_TYPVAL          |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*962 |             FILTER                                    |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 963 |              TABLE ACCESS BY INDEX ROWID BATCHED      | V_DOMAINE           |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*964 |               INDEX RANGE SCAN                        | DOM_TYPVAL          |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*965 |             FILTER                                    |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 966 |              TABLE ACCESS BY INDEX ROWID BATCHED      | V_DOMAINE           |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*967 |               INDEX RANGE SCAN                        | DOM_TYPVAL          |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*968 |             FILTER                                    |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 969 |              TABLE ACCESS BY INDEX ROWID BATCHED      | V_DOMAINE           |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*970 |               INDEX RANGE SCAN                        | DOM_TYPVAL          |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*971 |             FILTER                                    |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 972 |              TABLE ACCESS BY INDEX ROWID BATCHED      | V_DOMAINE           |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*973 |               INDEX RANGE SCAN                        | DOM_TYPVAL          |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*974 |             FILTER                                    |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 975 |              TABLE ACCESS BY INDEX ROWID BATCHED      | V_DOMAINE           |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*976 |               INDEX RANGE SCAN                        | DOM_TYPVAL          |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*977 |             FILTER                                    |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 978 |              TABLE ACCESS BY INDEX ROWID BATCHED      | V_DOMAINE           |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*979 |               INDEX RANGE SCAN                        | DOM_TYPVAL          |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*980 |             FILTER                                    |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 981 |              TABLE ACCESS BY INDEX ROWID BATCHED      | V_DOMAINE           |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*982 |               INDEX RANGE SCAN                        | DOM_TYPVAL          |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*983 |             FILTER                                    |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 984 |              TABLE ACCESS BY INDEX ROWID BATCHED      | V_DOMAINE           |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*985 |               INDEX RANGE SCAN                        | DOM_TYPVAL          |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*986 |             FILTER                                    |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 987 |              TABLE ACCESS BY INDEX ROWID BATCHED      | V_DOMAINE           |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*988 |               INDEX RANGE SCAN                        | DOM_TYPVAL          |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*989 |             FILTER                                    |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 990 |              TABLE ACCESS BY INDEX ROWID BATCHED      | V_DOMAINE           |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*991 |               INDEX RANGE SCAN                        | DOM_TYPVAL          |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 992 |       NESTED LOOPS                                    |                     |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 993 |        NESTED LOOPS                                   |                     |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*994 |         INDEX RANGE SCAN                              | PK_T_FCTMEMBMG      |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*995 |         INDEX UNIQUE SCAN                             | PK_G_MANGRP         |      0 |      1 |     0   (0)|      0 |00:00:00.01 |       0 |      0 |
|*996 |        INDEX UNIQUE SCAN                              | PK_T_GESTFCTCOMP    |      0 |      1 |     0   (0)|      0 |00:00:00.01 |       0 |      0 |
-------------------------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   3 - filter('AL'=:B1)
   5 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='SE')
   6 - filter('AN'=:B1)
   8 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='SE')
   9 - filter('AR'=:B1)
  11 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='SE')
  12 - filter('BG'=:B1)
  14 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='SE')
  15 - filter('BR'=:B1)
  17 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='SE')
  18 - filter('CE'=:B1)
  20 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='SE')
  21 - filter('CH'=:B1)
  23 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='SE')
  24 - filter('CS'=:B1)
  26 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='SE')
  27 - filter('DA'=:B1)
  29 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='SE')
  30 - filter('EL'=:B1)
  32 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='SE')
  33 - filter('ES'=:B1)
  35 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='SE')
  36 - filter('ET'=:B1)
  38 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='SE')
  39 - filter('FI'=:B1)
  41 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='SE')
  42 - filter('FR'=:B1)
  44 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='SE')
  45 - filter('HR'=:B1)
  47 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='SE')
  48 - filter('HU'=:B1)
  50 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='SE')
  51 - filter('IT'=:B1)
  53 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='SE')
  54 - filter('IW'=:B1)
  56 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='SE')
  57 - filter('JA'=:B1)
  59 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='SE')
  60 - filter('LT'=:B1)
  62 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='SE')
  63 - filter('LV'=:B1)
  65 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='SE')
  66 - filter('MX'=:B1)
  68 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='SE')
  69 - filter('NL'=:B1)
  71 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='SE')
  72 - filter('NO'=:B1)
  74 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='SE')
  75 - filter('PL'=:B1)
  77 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='SE')
  78 - filter('PT'=:B1)
  80 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='SE')
  81 - filter('RO'=:B1)
  83 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='SE')
  84 - filter('RU'=:B1)
  86 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='SE')
  87 - filter('SK'=:B1)
  89 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='SE')
  90 - filter('SL'=:B1)
  92 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='SE')
  93 - filter('SR'=:B1)
  95 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='SE')
  96 - filter('SV'=:B1)
  98 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='SE')
  99 - filter('TR'=:B1)
 101 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='SE')
 102 - filter('US'=:B1)
 104 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='SE')
 105 - filter('VI'=:B1)
 107 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='SE')
 108 - filter('ZH'=:B1)
 110 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='SE')
 111 - access("E"."ALERTE_ID"=:B1)
 114 - filter('AL'=:B1)
 116 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='EC')
 117 - filter('AN'=:B1)
 119 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='EC')
 120 - filter('AR'=:B1)
 122 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='EC')
 123 - filter('BG'=:B1)
 125 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='EC')
 126 - filter('BR'=:B1)
 128 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='EC')
 129 - filter('CE'=:B1)
 131 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='EC')
 132 - filter('CH'=:B1)
 134 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='EC')
 135 - filter('CS'=:B1)
 137 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='EC')
 138 - filter('DA'=:B1)
 140 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='EC')
 141 - filter('EL'=:B1)
 143 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='EC')
 144 - filter('ES'=:B1)
 146 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='EC')
 147 - filter('ET'=:B1)
 149 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='EC')
 150 - filter('FI'=:B1)
 152 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='EC')
 153 - filter('FR'=:B1)
 155 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='EC')
 156 - filter('HR'=:B1)
 158 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='EC')
 159 - filter('HU'=:B1)
 161 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='EC')
 162 - filter('IT'=:B1)
 164 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='EC')
 165 - filter('IW'=:B1)
 167 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='EC')
 168 - filter('JA'=:B1)
 170 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='EC')
 171 - filter('LT'=:B1)
 173 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='EC')
 174 - filter('LV'=:B1)
 176 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='EC')
 177 - filter('MX'=:B1)
 179 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='EC')
 180 - filter('NL'=:B1)
 182 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='EC')
 183 - filter('NO'=:B1)
 185 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='EC')
 186 - filter('PL'=:B1)
 188 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='EC')
 189 - filter('PT'=:B1)
 191 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='EC')
 192 - filter('RO'=:B1)
 194 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='EC')
 195 - filter('RU'=:B1)
 197 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='EC')
 198 - filter('SK'=:B1)
 200 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='EC')
 201 - filter('SL'=:B1)
 203 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='EC')
 204 - filter('SR'=:B1)
 206 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='EC')
 207 - filter('SV'=:B1)
 209 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='EC')
 210 - filter('TR'=:B1)
 212 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='EC')
 213 - filter('US'=:B1)
 215 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='EC')
 216 - filter('VI'=:B1)
 218 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='EC')
 219 - filter('ZH'=:B1)
 221 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='EC')
 222 - access("E"."ALERTE_ID"=:B1)
 225 - filter('AL'=:B1)
 227 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='AF')
 228 - filter('AN'=:B1)
 230 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='AF')
 231 - filter('AR'=:B1)
 233 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='AF')
 234 - filter('BG'=:B1)
 236 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='AF')
 237 - filter('BR'=:B1)
 239 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='AF')
 240 - filter('CE'=:B1)
 242 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='AF')
 243 - filter('CH'=:B1)
 245 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='AF')
 246 - filter('CS'=:B1)
 248 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='AF')
 249 - filter('DA'=:B1)
 251 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='AF')
 252 - filter('EL'=:B1)
 254 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='AF')
 255 - filter('ES'=:B1)
 257 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='AF')
 258 - filter('ET'=:B1)
 260 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='AF')
 261 - filter('FI'=:B1)
 263 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='AF')
 264 - filter('FR'=:B1)
 266 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='AF')
 267 - filter('HR'=:B1)
 269 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='AF')
 270 - filter('HU'=:B1)
 272 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='AF')
 273 - filter('IT'=:B1)
 275 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='AF')
 276 - filter('IW'=:B1)
 278 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='AF')
 279 - filter('JA'=:B1)
 281 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='AF')
 282 - filter('LT'=:B1)
 284 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='AF')
 285 - filter('LV'=:B1)
 287 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='AF')
 288 - filter('MX'=:B1)
 290 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='AF')
 291 - filter('NL'=:B1)
 293 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='AF')
 294 - filter('NO'=:B1)
 296 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='AF')
 297 - filter('PL'=:B1)
 299 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='AF')
 300 - filter('PT'=:B1)
 302 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='AF')
 303 - filter('RO'=:B1)
 305 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='AF')
 306 - filter('RU'=:B1)
 308 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='AF')
 309 - filter('SK'=:B1)
 311 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='AF')
 312 - filter('SL'=:B1)
 314 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='AF')
 315 - filter('SR'=:B1)
 317 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='AF')
 318 - filter('SV'=:B1)
 320 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='AF')
 321 - filter('TR'=:B1)
 323 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='AF')
 324 - filter('US'=:B1)
 326 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='AF')
 327 - filter('VI'=:B1)
 329 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='AF')
 330 - filter('ZH'=:B1)
 332 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='AF')
 335 - filter("REFHIERARCHIE" IS NOT NULL)
 336 - access("ANCREFDOSS"=:B1)
 337 - access("REFDOSS"="REFHIERARCHIE")
 338 - filter("CATEGDOSS"='COMPTE DB CTR')
 339 - filter( IS NOT NULL)
 341 - access("CATEGDOSS"='COMPTE DB CTR')
 342 - filter("REFHIERARCHIE"=:B1)
 343 - access("ANCREFDOSS"=:B1)
 344 - access("ALERTE_ID"=:B1)
 348 - access("TD"."ALERTE_ID"=:B1)
 351 - filter('AL'=:B1)
 353 - access("TYPE"='DV_AGENDA_DETAILS' AND "ABREV"="TD"."TYPE_INFO")
 354 - filter('AN'=:B1)
 356 - access("TYPE"='DV_AGENDA_DETAILS' AND "ABREV"="TD"."TYPE_INFO")
 357 - filter('AR'=:B1)
 359 - access("TYPE"='DV_AGENDA_DETAILS' AND "ABREV"="TD"."TYPE_INFO")
 360 - filter('BG'=:B1)
 362 - access("TYPE"='DV_AGENDA_DETAILS' AND "ABREV"="TD"."TYPE_INFO")
 363 - filter('BR'=:B1)
 365 - access("TYPE"='DV_AGENDA_DETAILS' AND "ABREV"="TD"."TYPE_INFO")
 366 - filter('CE'=:B1)
 368 - access("TYPE"='DV_AGENDA_DETAILS' AND "ABREV"="TD"."TYPE_INFO")
 369 - filter('CH'=:B1)
 371 - access("TYPE"='DV_AGENDA_DETAILS' AND "ABREV"="TD"."TYPE_INFO")
 372 - filter('CS'=:B1)
 374 - access("TYPE"='DV_AGENDA_DETAILS' AND "ABREV"="TD"."TYPE_INFO")
 375 - filter('DA'=:B1)
 377 - access("TYPE"='DV_AGENDA_DETAILS' AND "ABREV"="TD"."TYPE_INFO")
 378 - filter('EL'=:B1)
 380 - access("TYPE"='DV_AGENDA_DETAILS' AND "ABREV"="TD"."TYPE_INFO")
 381 - filter('ES'=:B1)
 383 - access("TYPE"='DV_AGENDA_DETAILS' AND "ABREV"="TD"."TYPE_INFO")
 384 - filter('ET'=:B1)
 386 - access("TYPE"='DV_AGENDA_DETAILS' AND "ABREV"="TD"."TYPE_INFO")
 387 - filter('FI'=:B1)
 389 - access("TYPE"='DV_AGENDA_DETAILS' AND "ABREV"="TD"."TYPE_INFO")
 390 - filter('FR'=:B1)
 392 - access("TYPE"='DV_AGENDA_DETAILS' AND "ABREV"="TD"."TYPE_INFO")
 393 - filter('HR'=:B1)
 395 - access("TYPE"='DV_AGENDA_DETAILS' AND "ABREV"="TD"."TYPE_INFO")
 396 - filter('HU'=:B1)
 398 - access("TYPE"='DV_AGENDA_DETAILS' AND "ABREV"="TD"."TYPE_INFO")
 399 - filter('IT'=:B1)
 401 - access("TYPE"='DV_AGENDA_DETAILS' AND "ABREV"="TD"."TYPE_INFO")
 402 - filter('IW'=:B1)
 404 - access("TYPE"='DV_AGENDA_DETAILS' AND "ABREV"="TD"."TYPE_INFO")
 405 - filter('JA'=:B1)
 407 - access("TYPE"='DV_AGENDA_DETAILS' AND "ABREV"="TD"."TYPE_INFO")
 408 - filter('LT'=:B1)
 410 - access("TYPE"='DV_AGENDA_DETAILS' AND "ABREV"="TD"."TYPE_INFO")
 411 - filter('LV'=:B1)
 413 - access("TYPE"='DV_AGENDA_DETAILS' AND "ABREV"="TD"."TYPE_INFO")
 414 - filter('MX'=:B1)
 416 - access("TYPE"='DV_AGENDA_DETAILS' AND "ABREV"="TD"."TYPE_INFO")
 417 - filter('NL'=:B1)
 419 - access("TYPE"='DV_AGENDA_DETAILS' AND "ABREV"="TD"."TYPE_INFO")
 420 - filter('NO'=:B1)
 422 - access("TYPE"='DV_AGENDA_DETAILS' AND "ABREV"="TD"."TYPE_INFO")
 423 - filter('PL'=:B1)
 425 - access("TYPE"='DV_AGENDA_DETAILS' AND "ABREV"="TD"."TYPE_INFO")
 426 - filter('PT'=:B1)
 428 - access("TYPE"='DV_AGENDA_DETAILS' AND "ABREV"="TD"."TYPE_INFO")
 429 - filter('RO'=:B1)
 431 - access("TYPE"='DV_AGENDA_DETAILS' AND "ABREV"="TD"."TYPE_INFO")
 432 - filter('RU'=:B1)
 434 - access("TYPE"='DV_AGENDA_DETAILS' AND "ABREV"="TD"."TYPE_INFO")
 435 - filter('SK'=:B1)
 437 - access("TYPE"='DV_AGENDA_DETAILS' AND "ABREV"="TD"."TYPE_INFO")
 438 - filter('SL'=:B1)
 440 - access("TYPE"='DV_AGENDA_DETAILS' AND "ABREV"="TD"."TYPE_INFO")
 441 - filter('SR'=:B1)
 443 - access("TYPE"='DV_AGENDA_DETAILS' AND "ABREV"="TD"."TYPE_INFO")
 444 - filter('SV'=:B1)
 446 - access("TYPE"='DV_AGENDA_DETAILS' AND "ABREV"="TD"."TYPE_INFO")
 447 - filter('TR'=:B1)
 449 - access("TYPE"='DV_AGENDA_DETAILS' AND "ABREV"="TD"."TYPE_INFO")
 450 - filter('US'=:B1)
 452 - access("TYPE"='DV_AGENDA_DETAILS' AND "ABREV"="TD"."TYPE_INFO")
 453 - filter('VI'=:B1)
 455 - access("TYPE"='DV_AGENDA_DETAILS' AND "ABREV"="TD"."TYPE_INFO")
 456 - filter('ZH'=:B1)
 458 - access("TYPE"='DV_AGENDA_DETAILS' AND "ABREV"="TD"."TYPE_INFO")
 461 - filter("REFHIERARCHIE" IS NOT NULL)
 462 - access("ANCREFDOSS"=:B1)
 463 - access("REFDOSS"="REFHIERARCHIE")
 464 - filter("CATEGDOSS"='COMPTE DB CTR')
 465 - filter(ROWNUM=1)
 470 - filter("D2"."REFHIERARCHIE" IS NOT NULL)
 471 - access("D2"."ANCREFDOSS"=:B1)
 472 - filter("D1"."CATEGDOSS"='COMPTE DB CTR')
 473 - access("D1"."REFDOSS"="D2"."REFHIERARCHIE")
 474 - access("TI"."REFDOSS"="D1"."REFDOSS" AND "TI"."REFTYPE"='DB')
 475 - access("I"."REFINDIVIDU"="TI"."REFINDIVIDU")
 477 - filter(ROWNUM=1)
 482 - access("GD"."ANCREFDOSS"=:B1)
 483 - access("TI"."REFDOSS"="GD"."REFDOSS" AND "TI"."REFTYPE"='DB')
 484 - access("I"."REFINDIVIDU"="TI"."REFINDIVIDU")
 486 - filter("RNUM">=:B10)
 487 - filter(ROWNUM<=:B9)
 489 - filter(ROWNUM<=:B9)
 490 - filter(("TA"."REFFACTOR" IS NULL OR  IS NOT NULL))
 491 - filter(TO_DATE(TO_CHAR(TO_DATE(:B6,'YYYY-MM-DD'),'RRRRMMDD'),'RRRRMMDD')>=TO_DATE(TO_CHAR(TO_DATE(:B6,'YYYY-MM-DD'),'RRRRMMDD'),'RRRRMMDD'))
 497 - filter(UPPER(NVL("V"."VALEUR_TRAD","TA"."TYPENTITE")) LIKE UPPER(:B7))
 502 - access("GP"."REFINDIVIDU"="GI"."REFINDIVIDU")
 508 - access("GIP"."REFINDIVIDU"=:B4 AND "GIP"."TYPE"='appel_nonse')
 512 - access("A"."JOUR"=TO_NUMBER(TO_CHAR(SYSDATE@!,'j')))
       filter("A"."REFPERSO" IS NOT NULL)
 513 - access("A"."REFPERSO"="P"."REFPERSO")
 514 - filter("P"."REFREMPL"=:B5)
 515 - access("GI"."REFINDIVIDU"="STR1")
 518 - filter(("TA"."REFEXT" LIKE :B8 AND TRUNC(INTERNAL_FUNCTION("TA"."DTCREATION_DT"))>=TO_DATE(TO_CHAR(TO_DATE(:B6,'YYYY-MM-DD'),'RRRRMMDD'),'RRRR
              MMDD') AND TRUNC(INTERNAL_FUNCTION("TA"."DTCREATION_DT"))<=TO_DATE(TO_CHAR(TO_DATE(:B6,'YYYY-MM-DD'),'RRRRMMDD'),'RRRRMMDD')))
 519 - access("TA"."CATPERSO"="GP"."REFPERSO")
 520 - filter("ABREV6"='O')
 521 - access("VALEUR"="TA"."TYPENCOUR" AND "TYPE"='DV_AGENDA_NON_SE')
 523 - access("TA"."REFDOSS"="GD"."REFDOSS")
 528 - filter('AL'=:B1)
 530 - access("TYPE"='DV_TYPE_APPEL' AND "ABREV"="TA"."TYPENTITE")
 531 - filter('AN'=:B1)
 533 - access("TYPE"='DV_TYPE_APPEL' AND "ABREV"="TA"."TYPENTITE")
 534 - filter('AR'=:B1)
 536 - access("TYPE"='DV_TYPE_APPEL' AND "ABREV"="TA"."TYPENTITE")
 537 - filter('BG'=:B1)
 539 - access("TYPE"='DV_TYPE_APPEL' AND "ABREV"="TA"."TYPENTITE")
 540 - filter('BR'=:B1)
 542 - access("TYPE"='DV_TYPE_APPEL' AND "ABREV"="TA"."TYPENTITE")
 543 - filter('CE'=:B1)
 545 - access("TYPE"='DV_TYPE_APPEL' AND "ABREV"="TA"."TYPENTITE")
 546 - filter('CH'=:B1)
 548 - access("TYPE"='DV_TYPE_APPEL' AND "ABREV"="TA"."TYPENTITE")
 549 - filter('CS'=:B1)
 551 - access("TYPE"='DV_TYPE_APPEL' AND "ABREV"="TA"."TYPENTITE")
 552 - filter('DA'=:B1)
 554 - access("TYPE"='DV_TYPE_APPEL' AND "ABREV"="TA"."TYPENTITE")
 555 - filter('EL'=:B1)
 557 - access("TYPE"='DV_TYPE_APPEL' AND "ABREV"="TA"."TYPENTITE")
 558 - filter('ES'=:B1)
 560 - access("TYPE"='DV_TYPE_APPEL' AND "ABREV"="TA"."TYPENTITE")
 561 - filter('ET'=:B1)
 563 - access("TYPE"='DV_TYPE_APPEL' AND "ABREV"="TA"."TYPENTITE")
 564 - filter('FI'=:B1)
 566 - access("TYPE"='DV_TYPE_APPEL' AND "ABREV"="TA"."TYPENTITE")
 567 - filter('FR'=:B1)
 569 - access("TYPE"='DV_TYPE_APPEL' AND "ABREV"="TA"."TYPENTITE")
 570 - filter('HR'=:B1)
 572 - access("TYPE"='DV_TYPE_APPEL' AND "ABREV"="TA"."TYPENTITE")
 573 - filter('HU'=:B1)
 575 - access("TYPE"='DV_TYPE_APPEL' AND "ABREV"="TA"."TYPENTITE")
 576 - filter('IT'=:B1)
 578 - access("TYPE"='DV_TYPE_APPEL' AND "ABREV"="TA"."TYPENTITE")
 579 - filter('IW'=:B1)
 581 - access("TYPE"='DV_TYPE_APPEL' AND "ABREV"="TA"."TYPENTITE")
 582 - filter('JA'=:B1)
 584 - access("TYPE"='DV_TYPE_APPEL' AND "ABREV"="TA"."TYPENTITE")
 585 - filter('LT'=:B1)
 587 - access("TYPE"='DV_TYPE_APPEL' AND "ABREV"="TA"."TYPENTITE")
 588 - filter('LV'=:B1)
 590 - access("TYPE"='DV_TYPE_APPEL' AND "ABREV"="TA"."TYPENTITE")
 591 - filter('MX'=:B1)
 593 - access("TYPE"='DV_TYPE_APPEL' AND "ABREV"="TA"."TYPENTITE")
 594 - filter('NL'=:B1)
 596 - access("TYPE"='DV_TYPE_APPEL' AND "ABREV"="TA"."TYPENTITE")
 597 - filter('NO'=:B1)
 599 - access("TYPE"='DV_TYPE_APPEL' AND "ABREV"="TA"."TYPENTITE")
 600 - filter('PL'=:B1)
 602 - access("TYPE"='DV_TYPE_APPEL' AND "ABREV"="TA"."TYPENTITE")
 603 - filter('PT'=:B1)
 605 - access("TYPE"='DV_TYPE_APPEL' AND "ABREV"="TA"."TYPENTITE")
 606 - filter('RO'=:B1)
 608 - access("TYPE"='DV_TYPE_APPEL' AND "ABREV"="TA"."TYPENTITE")
 609 - filter('RU'=:B1)
 611 - access("TYPE"='DV_TYPE_APPEL' AND "ABREV"="TA"."TYPENTITE")
 612 - filter('SK'=:B1)
 614 - access("TYPE"='DV_TYPE_APPEL' AND "ABREV"="TA"."TYPENTITE")
 615 - filter('SL'=:B1)
 617 - access("TYPE"='DV_TYPE_APPEL' AND "ABREV"="TA"."TYPENTITE")
 618 - filter('SR'=:B1)
 620 - access("TYPE"='DV_TYPE_APPEL' AND "ABREV"="TA"."TYPENTITE")
 621 - filter('SV'=:B1)
 623 - access("TYPE"='DV_TYPE_APPEL' AND "ABREV"="TA"."TYPENTITE")
 624 - filter('TR'=:B1)
 626 - access("TYPE"='DV_TYPE_APPEL' AND "ABREV"="TA"."TYPENTITE")
 627 - filter('US'=:B1)
 629 - access("TYPE"='DV_TYPE_APPEL' AND "ABREV"="TA"."TYPENTITE")
 630 - filter('VI'=:B1)
 632 - access("TYPE"='DV_TYPE_APPEL' AND "ABREV"="TA"."TYPENTITE")
 633 - filter('ZH'=:B1)
 635 - access("TYPE"='DV_TYPE_APPEL' AND "ABREV"="TA"."TYPENTITE")
 639 - access("T"."REFDOSS"="TA"."REFDOSS" AND "T"."REFTYPE"='CL')
 640 - access("I"."REFINDIVIDU"="T"."REFINDIVIDU")
 649 - access("G"."REFDOSS"="TA"."REFDOSS")
 650 - access("D"."TYPE"='categdoss' AND "D"."VALEUR"="G"."CATEGDOSS")
       filter(("D"."VALEUR"="G"."CATEGDOSS" AND "D"."ABREV" IS NOT NULL))
 651 - access("TI"."REFDOSS"="TA"."REFDOSS")
       filter("TI"."REFDOSS"="G"."REFDOSS")
 652 - filter("I"."REFTYPE_AFF"='CLI')
 653 - access("I"."CATEGDOSS"="D"."ABREV" AND "I"."REFTYPE_BD"="TI"."REFTYPE")
 654 - access("TI"."REFINDIVIDU"="GI"."REFINDIVIDU")
 660 - filter('AL'=:B1)
 662 - access("VALEUR"="TA"."TYPENCOUR" AND "TYPE"='DV_AGENDA_NON_SE')
 663 - filter('AN'=:B1)
 665 - access("VALEUR"="TA"."TYPENCOUR" AND "TYPE"='DV_AGENDA_NON_SE')
 666 - filter('AR'=:B1)
 668 - access("VALEUR"="TA"."TYPENCOUR" AND "TYPE"='DV_AGENDA_NON_SE')
 669 - filter('BG'=:B1)
 671 - access("VALEUR"="TA"."TYPENCOUR" AND "TYPE"='DV_AGENDA_NON_SE')
 672 - filter('BR'=:B1)
 674 - access("VALEUR"="TA"."TYPENCOUR" AND "TYPE"='DV_AGENDA_NON_SE')
 675 - filter('CE'=:B1)
 677 - access("VALEUR"="TA"."TYPENCOUR" AND "TYPE"='DV_AGENDA_NON_SE')
 678 - filter('CH'=:B1)
 680 - access("VALEUR"="TA"."TYPENCOUR" AND "TYPE"='DV_AGENDA_NON_SE')
 681 - filter('CS'=:B1)
 683 - access("VALEUR"="TA"."TYPENCOUR" AND "TYPE"='DV_AGENDA_NON_SE')
 684 - filter('DA'=:B1)
 686 - access("VALEUR"="TA"."TYPENCOUR" AND "TYPE"='DV_AGENDA_NON_SE')
 687 - filter('EL'=:B1)
 689 - access("VALEUR"="TA"."TYPENCOUR" AND "TYPE"='DV_AGENDA_NON_SE')
 690 - filter('ES'=:B1)
 692 - access("VALEUR"="TA"."TYPENCOUR" AND "TYPE"='DV_AGENDA_NON_SE')
 693 - filter('ET'=:B1)
 695 - access("VALEUR"="TA"."TYPENCOUR" AND "TYPE"='DV_AGENDA_NON_SE')
 696 - filter('FI'=:B1)
 698 - access("VALEUR"="TA"."TYPENCOUR" AND "TYPE"='DV_AGENDA_NON_SE')
 699 - filter('FR'=:B1)
 701 - access("VALEUR"="TA"."TYPENCOUR" AND "TYPE"='DV_AGENDA_NON_SE')
 702 - filter('HR'=:B1)
 704 - access("VALEUR"="TA"."TYPENCOUR" AND "TYPE"='DV_AGENDA_NON_SE')
 705 - filter('HU'=:B1)
 707 - access("VALEUR"="TA"."TYPENCOUR" AND "TYPE"='DV_AGENDA_NON_SE')
 708 - filter('IT'=:B1)
 710 - access("VALEUR"="TA"."TYPENCOUR" AND "TYPE"='DV_AGENDA_NON_SE')
 711 - filter('IW'=:B1)
 713 - access("VALEUR"="TA"."TYPENCOUR" AND "TYPE"='DV_AGENDA_NON_SE')
 714 - filter('JA'=:B1)
 716 - access("VALEUR"="TA"."TYPENCOUR" AND "TYPE"='DV_AGENDA_NON_SE')
 717 - filter('LT'=:B1)
 719 - access("VALEUR"="TA"."TYPENCOUR" AND "TYPE"='DV_AGENDA_NON_SE')
 720 - filter('LV'=:B1)
 722 - access("VALEUR"="TA"."TYPENCOUR" AND "TYPE"='DV_AGENDA_NON_SE')
 723 - filter('MX'=:B1)
 725 - access("VALEUR"="TA"."TYPENCOUR" AND "TYPE"='DV_AGENDA_NON_SE')
 726 - filter('NL'=:B1)
 728 - access("VALEUR"="TA"."TYPENCOUR" AND "TYPE"='DV_AGENDA_NON_SE')
 729 - filter('NO'=:B1)
 731 - access("VALEUR"="TA"."TYPENCOUR" AND "TYPE"='DV_AGENDA_NON_SE')
 732 - filter('PL'=:B1)
 734 - access("VALEUR"="TA"."TYPENCOUR" AND "TYPE"='DV_AGENDA_NON_SE')
 735 - filter('PT'=:B1)
 737 - access("VALEUR"="TA"."TYPENCOUR" AND "TYPE"='DV_AGENDA_NON_SE')
 738 - filter('RO'=:B1)
 740 - access("VALEUR"="TA"."TYPENCOUR" AND "TYPE"='DV_AGENDA_NON_SE')
 741 - filter('RU'=:B1)
 743 - access("VALEUR"="TA"."TYPENCOUR" AND "TYPE"='DV_AGENDA_NON_SE')
 744 - filter('SK'=:B1)
 746 - access("VALEUR"="TA"."TYPENCOUR" AND "TYPE"='DV_AGENDA_NON_SE')
 747 - filter('SL'=:B1)
 749 - access("VALEUR"="TA"."TYPENCOUR" AND "TYPE"='DV_AGENDA_NON_SE')
 750 - filter('SR'=:B1)
 752 - access("VALEUR"="TA"."TYPENCOUR" AND "TYPE"='DV_AGENDA_NON_SE')
 753 - filter('SV'=:B1)
 755 - access("VALEUR"="TA"."TYPENCOUR" AND "TYPE"='DV_AGENDA_NON_SE')
 756 - filter('TR'=:B1)
 758 - access("VALEUR"="TA"."TYPENCOUR" AND "TYPE"='DV_AGENDA_NON_SE')
 759 - filter('US'=:B1)
 761 - access("VALEUR"="TA"."TYPENCOUR" AND "TYPE"='DV_AGENDA_NON_SE')
 762 - filter('VI'=:B1)
 764 - access("VALEUR"="TA"."TYPENCOUR" AND "TYPE"='DV_AGENDA_NON_SE')
 765 - filter('ZH'=:B1)
 767 - access("VALEUR"="TA"."TYPENCOUR" AND "TYPE"='DV_AGENDA_NON_SE')
 772 - filter('AL'=:B1)
 774 - access("TYPE"='DEVISE' AND "ABREV"=CASE  WHEN ((:B3='FACTORING') AND ("GD"."REFFACTOR" IS NOT NULL) AND ("V1"."PLACE"=1)) THEN
              "FTR_FIN_FACTOR"."GETCURRENCY"("GD"."REFFACTOR") WHEN ("V1"."PLACE"=2) THEN "TA"."DEVISE_ALERTE" ELSE NVL("GD"."DEVISE","TA"."DEVISE_ALERTE") END )
 775 - filter('AN'=:B1)
 777 - access("TYPE"='DEVISE' AND "ABREV"=CASE  WHEN ((:B3='FACTORING') AND ("GD"."REFFACTOR" IS NOT NULL) AND ("V1"."PLACE"=1)) THEN
              "FTR_FIN_FACTOR"."GETCURRENCY"("GD"."REFFACTOR") WHEN ("V1"."PLACE"=2) THEN "TA"."DEVISE_ALERTE" ELSE NVL("GD"."DEVISE","TA"."DEVISE_ALERTE") END )
 778 - filter('AR'=:B1)
 780 - access("TYPE"='DEVISE' AND "ABREV"=CASE  WHEN ((:B3='FACTORING') AND ("GD"."REFFACTOR" IS NOT NULL) AND ("V1"."PLACE"=1)) THEN
              "FTR_FIN_FACTOR"."GETCURRENCY"("GD"."REFFACTOR") WHEN ("V1"."PLACE"=2) THEN "TA"."DEVISE_ALERTE" ELSE NVL("GD"."DEVISE","TA"."DEVISE_ALERTE") END )
 781 - filter('BG'=:B1)
 783 - access("TYPE"='DEVISE' AND "ABREV"=CASE  WHEN ((:B3='FACTORING') AND ("GD"."REFFACTOR" IS NOT NULL) AND ("V1"."PLACE"=1)) THEN
              "FTR_FIN_FACTOR"."GETCURRENCY"("GD"."REFFACTOR") WHEN ("V1"."PLACE"=2) THEN "TA"."DEVISE_ALERTE" ELSE NVL("GD"."DEVISE","TA"."DEVISE_ALERTE") END )
 784 - filter('BR'=:B1)
 786 - access("TYPE"='DEVISE' AND "ABREV"=CASE  WHEN ((:B3='FACTORING') AND ("GD"."REFFACTOR" IS NOT NULL) AND ("V1"."PLACE"=1)) THEN
              "FTR_FIN_FACTOR"."GETCURRENCY"("GD"."REFFACTOR") WHEN ("V1"."PLACE"=2) THEN "TA"."DEVISE_ALERTE" ELSE NVL("GD"."DEVISE","TA"."DEVISE_ALERTE") END )
 787 - filter('CE'=:B1)
 789 - access("TYPE"='DEVISE' AND "ABREV"=CASE  WHEN ((:B3='FACTORING') AND ("GD"."REFFACTOR" IS NOT NULL) AND ("V1"."PLACE"=1)) THEN
              "FTR_FIN_FACTOR"."GETCURRENCY"("GD"."REFFACTOR") WHEN ("V1"."PLACE"=2) THEN "TA"."DEVISE_ALERTE" ELSE NVL("GD"."DEVISE","TA"."DEVISE_ALERTE") END )
 790 - filter('CH'=:B1)
 792 - access("TYPE"='DEVISE' AND "ABREV"=CASE  WHEN ((:B3='FACTORING') AND ("GD"."REFFACTOR" IS NOT NULL) AND ("V1"."PLACE"=1)) THEN
              "FTR_FIN_FACTOR"."GETCURRENCY"("GD"."REFFACTOR") WHEN ("V1"."PLACE"=2) THEN "TA"."DEVISE_ALERTE" ELSE NVL("GD"."DEVISE","TA"."DEVISE_ALERTE") END )
 793 - filter('CS'=:B1)
 795 - access("TYPE"='DEVISE' AND "ABREV"=CASE  WHEN ((:B3='FACTORING') AND ("GD"."REFFACTOR" IS NOT NULL) AND ("V1"."PLACE"=1)) THEN
              "FTR_FIN_FACTOR"."GETCURRENCY"("GD"."REFFACTOR") WHEN ("V1"."PLACE"=2) THEN "TA"."DEVISE_ALERTE" ELSE NVL("GD"."DEVISE","TA"."DEVISE_ALERTE") END )
 796 - filter('DA'=:B1)
 798 - access("TYPE"='DEVISE' AND "ABREV"=CASE  WHEN ((:B3='FACTORING') AND ("GD"."REFFACTOR" IS NOT NULL) AND ("V1"."PLACE"=1)) THEN
              "FTR_FIN_FACTOR"."GETCURRENCY"("GD"."REFFACTOR") WHEN ("V1"."PLACE"=2) THEN "TA"."DEVISE_ALERTE" ELSE NVL("GD"."DEVISE","TA"."DEVISE_ALERTE") END )
 799 - filter('EL'=:B1)
 801 - access("TYPE"='DEVISE' AND "ABREV"=CASE  WHEN ((:B3='FACTORING') AND ("GD"."REFFACTOR" IS NOT NULL) AND ("V1"."PLACE"=1)) THEN
              "FTR_FIN_FACTOR"."GETCURRENCY"("GD"."REFFACTOR") WHEN ("V1"."PLACE"=2) THEN "TA"."DEVISE_ALERTE" ELSE NVL("GD"."DEVISE","TA"."DEVISE_ALERTE") END )
 802 - filter('ES'=:B1)
 804 - access("TYPE"='DEVISE' AND "ABREV"=CASE  WHEN ((:B3='FACTORING') AND ("GD"."REFFACTOR" IS NOT NULL) AND ("V1"."PLACE"=1)) THEN
              "FTR_FIN_FACTOR"."GETCURRENCY"("GD"."REFFACTOR") WHEN ("V1"."PLACE"=2) THEN "TA"."DEVISE_ALERTE" ELSE NVL("GD"."DEVISE","TA"."DEVISE_ALERTE") END )
 805 - filter('ET'=:B1)
 807 - access("TYPE"='DEVISE' AND "ABREV"=CASE  WHEN ((:B3='FACTORING') AND ("GD"."REFFACTOR" IS NOT NULL) AND ("V1"."PLACE"=1)) THEN
              "FTR_FIN_FACTOR"."GETCURRENCY"("GD"."REFFACTOR") WHEN ("V1"."PLACE"=2) THEN "TA"."DEVISE_ALERTE" ELSE NVL("GD"."DEVISE","TA"."DEVISE_ALERTE") END )
 808 - filter('FI'=:B1)
 810 - access("TYPE"='DEVISE' AND "ABREV"=CASE  WHEN ((:B3='FACTORING') AND ("GD"."REFFACTOR" IS NOT NULL) AND ("V1"."PLACE"=1)) THEN
              "FTR_FIN_FACTOR"."GETCURRENCY"("GD"."REFFACTOR") WHEN ("V1"."PLACE"=2) THEN "TA"."DEVISE_ALERTE" ELSE NVL("GD"."DEVISE","TA"."DEVISE_ALERTE") END )
 811 - filter('FR'=:B1)
 813 - access("TYPE"='DEVISE' AND "ABREV"=CASE  WHEN ((:B3='FACTORING') AND ("GD"."REFFACTOR" IS NOT NULL) AND ("V1"."PLACE"=1)) THEN
              "FTR_FIN_FACTOR"."GETCURRENCY"("GD"."REFFACTOR") WHEN ("V1"."PLACE"=2) THEN "TA"."DEVISE_ALERTE" ELSE NVL("GD"."DEVISE","TA"."DEVISE_ALERTE") END )
 814 - filter('HR'=:B1)
 816 - access("TYPE"='DEVISE' AND "ABREV"=CASE  WHEN ((:B3='FACTORING') AND ("GD"."REFFACTOR" IS NOT NULL) AND ("V1"."PLACE"=1)) THEN
              "FTR_FIN_FACTOR"."GETCURRENCY"("GD"."REFFACTOR") WHEN ("V1"."PLACE"=2) THEN "TA"."DEVISE_ALERTE" ELSE NVL("GD"."DEVISE","TA"."DEVISE_ALERTE") END )
 817 - filter('HU'=:B1)
 819 - access("TYPE"='DEVISE' AND "ABREV"=CASE  WHEN ((:B3='FACTORING') AND ("GD"."REFFACTOR" IS NOT NULL) AND ("V1"."PLACE"=1)) THEN
              "FTR_FIN_FACTOR"."GETCURRENCY"("GD"."REFFACTOR") WHEN ("V1"."PLACE"=2) THEN "TA"."DEVISE_ALERTE" ELSE NVL("GD"."DEVISE","TA"."DEVISE_ALERTE") END )
 820 - filter('IT'=:B1)
 822 - access("TYPE"='DEVISE' AND "ABREV"=CASE  WHEN ((:B3='FACTORING') AND ("GD"."REFFACTOR" IS NOT NULL) AND ("V1"."PLACE"=1)) THEN
              "FTR_FIN_FACTOR"."GETCURRENCY"("GD"."REFFACTOR") WHEN ("V1"."PLACE"=2) THEN "TA"."DEVISE_ALERTE" ELSE NVL("GD"."DEVISE","TA"."DEVISE_ALERTE") END )
 823 - filter('IW'=:B1)
 825 - access("TYPE"='DEVISE' AND "ABREV"=CASE  WHEN ((:B3='FACTORING') AND ("GD"."REFFACTOR" IS NOT NULL) AND ("V1"."PLACE"=1)) THEN
              "FTR_FIN_FACTOR"."GETCURRENCY"("GD"."REFFACTOR") WHEN ("V1"."PLACE"=2) THEN "TA"."DEVISE_ALERTE" ELSE NVL("GD"."DEVISE","TA"."DEVISE_ALERTE") END )
 826 - filter('JA'=:B1)
 828 - access("TYPE"='DEVISE' AND "ABREV"=CASE  WHEN ((:B3='FACTORING') AND ("GD"."REFFACTOR" IS NOT NULL) AND ("V1"."PLACE"=1)) THEN
              "FTR_FIN_FACTOR"."GETCURRENCY"("GD"."REFFACTOR") WHEN ("V1"."PLACE"=2) THEN "TA"."DEVISE_ALERTE" ELSE NVL("GD"."DEVISE","TA"."DEVISE_ALERTE") END )
 829 - filter('LT'=:B1)
 831 - access("TYPE"='DEVISE' AND "ABREV"=CASE  WHEN ((:B3='FACTORING') AND ("GD"."REFFACTOR" IS NOT NULL) AND ("V1"."PLACE"=1)) THEN
              "FTR_FIN_FACTOR"."GETCURRENCY"("GD"."REFFACTOR") WHEN ("V1"."PLACE"=2) THEN "TA"."DEVISE_ALERTE" ELSE NVL("GD"."DEVISE","TA"."DEVISE_ALERTE") END )
 832 - filter('LV'=:B1)
 834 - access("TYPE"='DEVISE' AND "ABREV"=CASE  WHEN ((:B3='FACTORING') AND ("GD"."REFFACTOR" IS NOT NULL) AND ("V1"."PLACE"=1)) THEN
              "FTR_FIN_FACTOR"."GETCURRENCY"("GD"."REFFACTOR") WHEN ("V1"."PLACE"=2) THEN "TA"."DEVISE_ALERTE" ELSE NVL("GD"."DEVISE","TA"."DEVISE_ALERTE") END )
 835 - filter('MX'=:B1)
 837 - access("TYPE"='DEVISE' AND "ABREV"=CASE  WHEN ((:B3='FACTORING') AND ("GD"."REFFACTOR" IS NOT NULL) AND ("V1"."PLACE"=1)) THEN
              "FTR_FIN_FACTOR"."GETCURRENCY"("GD"."REFFACTOR") WHEN ("V1"."PLACE"=2) THEN "TA"."DEVISE_ALERTE" ELSE NVL("GD"."DEVISE","TA"."DEVISE_ALERTE") END )
 838 - filter('NL'=:B1)
 840 - access("TYPE"='DEVISE' AND "ABREV"=CASE  WHEN ((:B3='FACTORING') AND ("GD"."REFFACTOR" IS NOT NULL) AND ("V1"."PLACE"=1)) THEN
              "FTR_FIN_FACTOR"."GETCURRENCY"("GD"."REFFACTOR") WHEN ("V1"."PLACE"=2) THEN "TA"."DEVISE_ALERTE" ELSE NVL("GD"."DEVISE","TA"."DEVISE_ALERTE") END )
 841 - filter('NO'=:B1)
 843 - access("TYPE"='DEVISE' AND "ABREV"=CASE  WHEN ((:B3='FACTORING') AND ("GD"."REFFACTOR" IS NOT NULL) AND ("V1"."PLACE"=1)) THEN
              "FTR_FIN_FACTOR"."GETCURRENCY"("GD"."REFFACTOR") WHEN ("V1"."PLACE"=2) THEN "TA"."DEVISE_ALERTE" ELSE NVL("GD"."DEVISE","TA"."DEVISE_ALERTE") END )
 844 - filter('PL'=:B1)
 846 - access("TYPE"='DEVISE' AND "ABREV"=CASE  WHEN ((:B3='FACTORING') AND ("GD"."REFFACTOR" IS NOT NULL) AND ("V1"."PLACE"=1)) THEN
              "FTR_FIN_FACTOR"."GETCURRENCY"("GD"."REFFACTOR") WHEN ("V1"."PLACE"=2) THEN "TA"."DEVISE_ALERTE" ELSE NVL("GD"."DEVISE","TA"."DEVISE_ALERTE") END )
 847 - filter('PT'=:B1)
 849 - access("TYPE"='DEVISE' AND "ABREV"=CASE  WHEN ((:B3='FACTORING') AND ("GD"."REFFACTOR" IS NOT NULL) AND ("V1"."PLACE"=1)) THEN
              "FTR_FIN_FACTOR"."GETCURRENCY"("GD"."REFFACTOR") WHEN ("V1"."PLACE"=2) THEN "TA"."DEVISE_ALERTE" ELSE NVL("GD"."DEVISE","TA"."DEVISE_ALERTE") END )
 850 - filter('RO'=:B1)
 852 - access("TYPE"='DEVISE' AND "ABREV"=CASE  WHEN ((:B3='FACTORING') AND ("GD"."REFFACTOR" IS NOT NULL) AND ("V1"."PLACE"=1)) THEN
              "FTR_FIN_FACTOR"."GETCURRENCY"("GD"."REFFACTOR") WHEN ("V1"."PLACE"=2) THEN "TA"."DEVISE_ALERTE" ELSE NVL("GD"."DEVISE","TA"."DEVISE_ALERTE") END )
 853 - filter('RU'=:B1)
 855 - access("TYPE"='DEVISE' AND "ABREV"=CASE  WHEN ((:B3='FACTORING') AND ("GD"."REFFACTOR" IS NOT NULL) AND ("V1"."PLACE"=1)) THEN
              "FTR_FIN_FACTOR"."GETCURRENCY"("GD"."REFFACTOR") WHEN ("V1"."PLACE"=2) THEN "TA"."DEVISE_ALERTE" ELSE NVL("GD"."DEVISE","TA"."DEVISE_ALERTE") END )
 856 - filter('SK'=:B1)
 858 - access("TYPE"='DEVISE' AND "ABREV"=CASE  WHEN ((:B3='FACTORING') AND ("GD"."REFFACTOR" IS NOT NULL) AND ("V1"."PLACE"=1)) THEN
              "FTR_FIN_FACTOR"."GETCURRENCY"("GD"."REFFACTOR") WHEN ("V1"."PLACE"=2) THEN "TA"."DEVISE_ALERTE" ELSE NVL("GD"."DEVISE","TA"."DEVISE_ALERTE") END )
 859 - filter('SL'=:B1)
 861 - access("TYPE"='DEVISE' AND "ABREV"=CASE  WHEN ((:B3='FACTORING') AND ("GD"."REFFACTOR" IS NOT NULL) AND ("V1"."PLACE"=1)) THEN
              "FTR_FIN_FACTOR"."GETCURRENCY"("GD"."REFFACTOR") WHEN ("V1"."PLACE"=2) THEN "TA"."DEVISE_ALERTE" ELSE NVL("GD"."DEVISE","TA"."DEVISE_ALERTE") END )
 862 - filter('SR'=:B1)
 864 - access("TYPE"='DEVISE' AND "ABREV"=CASE  WHEN ((:B3='FACTORING') AND ("GD"."REFFACTOR" IS NOT NULL) AND ("V1"."PLACE"=1)) THEN
              "FTR_FIN_FACTOR"."GETCURRENCY"("GD"."REFFACTOR") WHEN ("V1"."PLACE"=2) THEN "TA"."DEVISE_ALERTE" ELSE NVL("GD"."DEVISE","TA"."DEVISE_ALERTE") END )
 865 - filter('SV'=:B1)
 867 - access("TYPE"='DEVISE' AND "ABREV"=CASE  WHEN ((:B3='FACTORING') AND ("GD"."REFFACTOR" IS NOT NULL) AND ("V1"."PLACE"=1)) THEN
              "FTR_FIN_FACTOR"."GETCURRENCY"("GD"."REFFACTOR") WHEN ("V1"."PLACE"=2) THEN "TA"."DEVISE_ALERTE" ELSE NVL("GD"."DEVISE","TA"."DEVISE_ALERTE") END )
 868 - filter('TR'=:B1)
 870 - access("TYPE"='DEVISE' AND "ABREV"=CASE  WHEN ((:B3='FACTORING') AND ("GD"."REFFACTOR" IS NOT NULL) AND ("V1"."PLACE"=1)) THEN
              "FTR_FIN_FACTOR"."GETCURRENCY"("GD"."REFFACTOR") WHEN ("V1"."PLACE"=2) THEN "TA"."DEVISE_ALERTE" ELSE NVL("GD"."DEVISE","TA"."DEVISE_ALERTE") END )
 871 - filter('US'=:B1)
 873 - access("TYPE"='DEVISE' AND "ABREV"=CASE  WHEN ((:B3='FACTORING') AND ("GD"."REFFACTOR" IS NOT NULL) AND ("V1"."PLACE"=1)) THEN
              "FTR_FIN_FACTOR"."GETCURRENCY"("GD"."REFFACTOR") WHEN ("V1"."PLACE"=2) THEN "TA"."DEVISE_ALERTE" ELSE NVL("GD"."DEVISE","TA"."DEVISE_ALERTE") END )
 874 - filter('VI'=:B1)
 876 - access("TYPE"='DEVISE' AND "ABREV"=CASE  WHEN ((:B3='FACTORING') AND ("GD"."REFFACTOR" IS NOT NULL) AND ("V1"."PLACE"=1)) THEN
              "FTR_FIN_FACTOR"."GETCURRENCY"("GD"."REFFACTOR") WHEN ("V1"."PLACE"=2) THEN "TA"."DEVISE_ALERTE" ELSE NVL("GD"."DEVISE","TA"."DEVISE_ALERTE") END )
 877 - filter('ZH'=:B1)
 879 - access("TYPE"='DEVISE' AND "ABREV"=CASE  WHEN ((:B3='FACTORING') AND ("GD"."REFFACTOR" IS NOT NULL) AND ("V1"."PLACE"=1)) THEN
              "FTR_FIN_FACTOR"."GETCURRENCY"("GD"."REFFACTOR") WHEN ("V1"."PLACE"=2) THEN "TA"."DEVISE_ALERTE" ELSE NVL("GD"."DEVISE","TA"."DEVISE_ALERTE") END )
 884 - filter('AL'=:B1)
 886 - access("VALEUR"="GP"."GROUPE" AND "TYPE"='GROUPE')
 887 - filter('AN'=:B1)
 889 - access("VALEUR"="GP"."GROUPE" AND "TYPE"='GROUPE')
 890 - filter('AR'=:B1)
 892 - access("VALEUR"="GP"."GROUPE" AND "TYPE"='GROUPE')
 893 - filter('BG'=:B1)
 895 - access("VALEUR"="GP"."GROUPE" AND "TYPE"='GROUPE')
 896 - filter('BR'=:B1)
 898 - access("VALEUR"="GP"."GROUPE" AND "TYPE"='GROUPE')
 899 - filter('CE'=:B1)
 901 - access("VALEUR"="GP"."GROUPE" AND "TYPE"='GROUPE')
 902 - filter('CH'=:B1)
 904 - access("VALEUR"="GP"."GROUPE" AND "TYPE"='GROUPE')
 905 - filter('CS'=:B1)
 907 - access("VALEUR"="GP"."GROUPE" AND "TYPE"='GROUPE')
 908 - filter('DA'=:B1)
 910 - access("VALEUR"="GP"."GROUPE" AND "TYPE"='GROUPE')
 911 - filter('EL'=:B1)
 913 - access("VALEUR"="GP"."GROUPE" AND "TYPE"='GROUPE')
 914 - filter('ES'=:B1)
 916 - access("VALEUR"="GP"."GROUPE" AND "TYPE"='GROUPE')
 917 - filter('ET'=:B1)
 919 - access("VALEUR"="GP"."GROUPE" AND "TYPE"='GROUPE')
 920 - filter('FI'=:B1)
 922 - access("VALEUR"="GP"."GROUPE" AND "TYPE"='GROUPE')
 923 - filter('FR'=:B1)
 925 - access("VALEUR"="GP"."GROUPE" AND "TYPE"='GROUPE')
 926 - filter('HR'=:B1)
 928 - access("VALEUR"="GP"."GROUPE" AND "TYPE"='GROUPE')
 929 - filter('HU'=:B1)
 931 - access("VALEUR"="GP"."GROUPE" AND "TYPE"='GROUPE')
 932 - filter('IT'=:B1)
 934 - access("VALEUR"="GP"."GROUPE" AND "TYPE"='GROUPE')
 935 - filter('IW'=:B1)
 937 - access("VALEUR"="GP"."GROUPE" AND "TYPE"='GROUPE')
 938 - filter('JA'=:B1)
 940 - access("VALEUR"="GP"."GROUPE" AND "TYPE"='GROUPE')
 941 - filter('LT'=:B1)
 943 - access("VALEUR"="GP"."GROUPE" AND "TYPE"='GROUPE')
 944 - filter('LV'=:B1)
 946 - access("VALEUR"="GP"."GROUPE" AND "TYPE"='GROUPE')
 947 - filter('MX'=:B1)
 949 - access("VALEUR"="GP"."GROUPE" AND "TYPE"='GROUPE')
 950 - filter('NL'=:B1)
 952 - access("VALEUR"="GP"."GROUPE" AND "TYPE"='GROUPE')
 953 - filter('NO'=:B1)
 955 - access("VALEUR"="GP"."GROUPE" AND "TYPE"='GROUPE')
 956 - filter('PL'=:B1)
 958 - access("VALEUR"="GP"."GROUPE" AND "TYPE"='GROUPE')
 959 - filter('PT'=:B1)
 961 - access("VALEUR"="GP"."GROUPE" AND "TYPE"='GROUPE')
 962 - filter('RO'=:B1)
 964 - access("VALEUR"="GP"."GROUPE" AND "TYPE"='GROUPE')
 965 - filter('RU'=:B1)
 967 - access("VALEUR"="GP"."GROUPE" AND "TYPE"='GROUPE')
 968 - filter('SK'=:B1)
 970 - access("VALEUR"="GP"."GROUPE" AND "TYPE"='GROUPE')
 971 - filter('SL'=:B1)
 973 - access("VALEUR"="GP"."GROUPE" AND "TYPE"='GROUPE')
 974 - filter('SR'=:B1)
 976 - access("VALEUR"="GP"."GROUPE" AND "TYPE"='GROUPE')
 977 - filter('SV'=:B1)
 979 - access("VALEUR"="GP"."GROUPE" AND "TYPE"='GROUPE')
 980 - filter('TR'=:B1)
 982 - access("VALEUR"="GP"."GROUPE" AND "TYPE"='GROUPE')
 983 - filter('US'=:B1)
 985 - access("VALEUR"="GP"."GROUPE" AND "TYPE"='GROUPE')
 986 - filter('VI'=:B1)
 988 - access("VALEUR"="GP"."GROUPE" AND "TYPE"='GROUPE')
 989 - filter('ZH'=:B1)
 991 - access("VALEUR"="GP"."GROUPE" AND "TYPE"='GROUPE')
 994 - access("F"."REFINDIVIDU"=:B1)
 995 - access("G"."REFMANGRP"="F"."REFMANGRP")
 996 - access("C"."REFPERSO"=:B5 AND "C"."REFMANGRP"="G"."REFMANGRP")
*/
/********************************OLD Metrics***************************************/

/********************************New SQL*******************************************/

-- No changes in the SQL text.
/********************************New SQL*******************************************/
/********************************New Metrics***************************************/
/*
Plan hash value: 2573343439
-------------------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                               | Name                 | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers |
-------------------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                                        |                      |      1 |        | 50198 (100)|      0 |00:00:00.01 |       3 |
|   1 |  VIEW                                                   | V_TDOMAINE           |      0 |     36 |   144   (0)|      0 |00:00:00.01 |       0 |
|   2 |   UNION-ALL                                             |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
|*  3 |    FILTER                                               |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
|   4 |     TABLE ACCESS BY INDEX ROWID BATCHED                 | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|*  5 |      INDEX RANGE SCAN                                   | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*  6 |    FILTER                                               |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
|   7 |     TABLE ACCESS BY INDEX ROWID BATCHED                 | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|*  8 |      INDEX RANGE SCAN                                   | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*  9 |    FILTER                                               |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
|  10 |     TABLE ACCESS BY INDEX ROWID BATCHED                 | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|* 11 |      INDEX RANGE SCAN                                   | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|* 12 |    FILTER                                               |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
|  13 |     TABLE ACCESS BY INDEX ROWID BATCHED                 | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|* 14 |      INDEX RANGE SCAN                                   | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|* 15 |    FILTER                                               |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
|  16 |     TABLE ACCESS BY INDEX ROWID BATCHED                 | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|* 17 |      INDEX RANGE SCAN                                   | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|* 18 |    FILTER                                               |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
|  19 |     TABLE ACCESS BY INDEX ROWID BATCHED                 | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|* 20 |      INDEX RANGE SCAN                                   | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|* 21 |    FILTER                                               |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
|  22 |     TABLE ACCESS BY INDEX ROWID BATCHED                 | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|* 23 |      INDEX RANGE SCAN                                   | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|* 24 |    FILTER                                               |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
|  25 |     TABLE ACCESS BY INDEX ROWID BATCHED                 | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|* 26 |      INDEX RANGE SCAN                                   | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|* 27 |    FILTER                                               |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
|  28 |     TABLE ACCESS BY INDEX ROWID BATCHED                 | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|* 29 |      INDEX RANGE SCAN                                   | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|* 30 |    FILTER                                               |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
|  31 |     TABLE ACCESS BY INDEX ROWID BATCHED                 | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|* 32 |      INDEX RANGE SCAN                                   | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|* 33 |    FILTER                                               |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
|  34 |     TABLE ACCESS BY INDEX ROWID BATCHED                 | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|* 35 |      INDEX RANGE SCAN                                   | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|* 36 |    FILTER                                               |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
|  37 |     TABLE ACCESS BY INDEX ROWID BATCHED                 | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|* 38 |      INDEX RANGE SCAN                                   | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|* 39 |    FILTER                                               |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
|  40 |     TABLE ACCESS BY INDEX ROWID BATCHED                 | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|* 41 |      INDEX RANGE SCAN                                   | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|* 42 |    FILTER                                               |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
|  43 |     TABLE ACCESS BY INDEX ROWID BATCHED                 | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|* 44 |      INDEX RANGE SCAN                                   | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|* 45 |    FILTER                                               |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
|  46 |     TABLE ACCESS BY INDEX ROWID BATCHED                 | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|* 47 |      INDEX RANGE SCAN                                   | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|* 48 |    FILTER                                               |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
|  49 |     TABLE ACCESS BY INDEX ROWID BATCHED                 | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|* 50 |      INDEX RANGE SCAN                                   | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|* 51 |    FILTER                                               |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
|  52 |     TABLE ACCESS BY INDEX ROWID BATCHED                 | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|* 53 |      INDEX RANGE SCAN                                   | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|* 54 |    FILTER                                               |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
|  55 |     TABLE ACCESS BY INDEX ROWID BATCHED                 | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|* 56 |      INDEX RANGE SCAN                                   | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|* 57 |    FILTER                                               |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
|  58 |     TABLE ACCESS BY INDEX ROWID BATCHED                 | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|* 59 |      INDEX RANGE SCAN                                   | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|* 60 |    FILTER                                               |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
|  61 |     TABLE ACCESS BY INDEX ROWID BATCHED                 | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|* 62 |      INDEX RANGE SCAN                                   | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|* 63 |    FILTER                                               |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
|  64 |     TABLE ACCESS BY INDEX ROWID BATCHED                 | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|* 65 |      INDEX RANGE SCAN                                   | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|* 66 |    FILTER                                               |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
|  67 |     TABLE ACCESS BY INDEX ROWID BATCHED                 | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|* 68 |      INDEX RANGE SCAN                                   | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|* 69 |    FILTER                                               |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
|  70 |     TABLE ACCESS BY INDEX ROWID BATCHED                 | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|* 71 |      INDEX RANGE SCAN                                   | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|* 72 |    FILTER                                               |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
|  73 |     TABLE ACCESS BY INDEX ROWID BATCHED                 | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|* 74 |      INDEX RANGE SCAN                                   | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|* 75 |    FILTER                                               |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
|  76 |     TABLE ACCESS BY INDEX ROWID BATCHED                 | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|* 77 |      INDEX RANGE SCAN                                   | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|* 78 |    FILTER                                               |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
|  79 |     TABLE ACCESS BY INDEX ROWID BATCHED                 | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|* 80 |      INDEX RANGE SCAN                                   | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|* 81 |    FILTER                                               |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
|  82 |     TABLE ACCESS BY INDEX ROWID BATCHED                 | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|* 83 |      INDEX RANGE SCAN                                   | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|* 84 |    FILTER                                               |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
|  85 |     TABLE ACCESS BY INDEX ROWID BATCHED                 | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|* 86 |      INDEX RANGE SCAN                                   | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|* 87 |    FILTER                                               |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
|  88 |     TABLE ACCESS BY INDEX ROWID BATCHED                 | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|* 89 |      INDEX RANGE SCAN                                   | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|* 90 |    FILTER                                               |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
|  91 |     TABLE ACCESS BY INDEX ROWID BATCHED                 | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|* 92 |      INDEX RANGE SCAN                                   | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|* 93 |    FILTER                                               |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
|  94 |     TABLE ACCESS BY INDEX ROWID BATCHED                 | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|* 95 |      INDEX RANGE SCAN                                   | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|* 96 |    FILTER                                               |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
|  97 |     TABLE ACCESS BY INDEX ROWID BATCHED                 | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|* 98 |      INDEX RANGE SCAN                                   | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|* 99 |    FILTER                                               |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 100 |     TABLE ACCESS BY INDEX ROWID BATCHED                 | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|*101 |      INDEX RANGE SCAN                                   | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*102 |    FILTER                                               |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 103 |     TABLE ACCESS BY INDEX ROWID BATCHED                 | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|*104 |      INDEX RANGE SCAN                                   | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*105 |    FILTER                                               |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 106 |     TABLE ACCESS BY INDEX ROWID BATCHED                 | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|*107 |      INDEX RANGE SCAN                                   | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*108 |    FILTER                                               |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 109 |     TABLE ACCESS BY INDEX ROWID BATCHED                 | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|*110 |      INDEX RANGE SCAN                                   | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*111 |     INDEX RANGE SCAN                                    | ELIGB_ALERT_ID_IDX   |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
| 112 |      VIEW                                               | V_TDOMAINE           |      0 |     36 |   144   (0)|      0 |00:00:00.01 |       0 |
| 113 |       UNION-ALL                                         |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
|*114 |        FILTER                                           |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 115 |         TABLE ACCESS BY INDEX ROWID BATCHED             | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|*116 |          INDEX RANGE SCAN                               | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*117 |        FILTER                                           |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 118 |         TABLE ACCESS BY INDEX ROWID BATCHED             | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|*119 |          INDEX RANGE SCAN                               | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*120 |        FILTER                                           |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 121 |         TABLE ACCESS BY INDEX ROWID BATCHED             | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|*122 |          INDEX RANGE SCAN                               | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*123 |        FILTER                                           |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 124 |         TABLE ACCESS BY INDEX ROWID BATCHED             | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|*125 |          INDEX RANGE SCAN                               | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*126 |        FILTER                                           |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 127 |         TABLE ACCESS BY INDEX ROWID BATCHED             | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|*128 |          INDEX RANGE SCAN                               | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*129 |        FILTER                                           |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 130 |         TABLE ACCESS BY INDEX ROWID BATCHED             | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|*131 |          INDEX RANGE SCAN                               | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*132 |        FILTER                                           |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 133 |         TABLE ACCESS BY INDEX ROWID BATCHED             | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|*134 |          INDEX RANGE SCAN                               | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*135 |        FILTER                                           |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 136 |         TABLE ACCESS BY INDEX ROWID BATCHED             | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|*137 |          INDEX RANGE SCAN                               | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*138 |        FILTER                                           |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 139 |         TABLE ACCESS BY INDEX ROWID BATCHED             | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|*140 |          INDEX RANGE SCAN                               | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*141 |        FILTER                                           |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 142 |         TABLE ACCESS BY INDEX ROWID BATCHED             | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|*143 |          INDEX RANGE SCAN                               | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*144 |        FILTER                                           |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 145 |         TABLE ACCESS BY INDEX ROWID BATCHED             | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|*146 |          INDEX RANGE SCAN                               | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*147 |        FILTER                                           |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 148 |         TABLE ACCESS BY INDEX ROWID BATCHED             | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|*149 |          INDEX RANGE SCAN                               | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*150 |        FILTER                                           |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 151 |         TABLE ACCESS BY INDEX ROWID BATCHED             | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|*152 |          INDEX RANGE SCAN                               | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*153 |        FILTER                                           |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 154 |         TABLE ACCESS BY INDEX ROWID BATCHED             | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|*155 |          INDEX RANGE SCAN                               | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*156 |        FILTER                                           |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 157 |         TABLE ACCESS BY INDEX ROWID BATCHED             | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|*158 |          INDEX RANGE SCAN                               | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*159 |        FILTER                                           |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 160 |         TABLE ACCESS BY INDEX ROWID BATCHED             | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|*161 |          INDEX RANGE SCAN                               | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*162 |        FILTER                                           |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 163 |         TABLE ACCESS BY INDEX ROWID BATCHED             | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|*164 |          INDEX RANGE SCAN                               | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*165 |        FILTER                                           |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 166 |         TABLE ACCESS BY INDEX ROWID BATCHED             | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|*167 |          INDEX RANGE SCAN                               | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*168 |        FILTER                                           |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 169 |         TABLE ACCESS BY INDEX ROWID BATCHED             | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|*170 |          INDEX RANGE SCAN                               | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*171 |        FILTER                                           |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 172 |         TABLE ACCESS BY INDEX ROWID BATCHED             | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|*173 |          INDEX RANGE SCAN                               | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*174 |        FILTER                                           |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 175 |         TABLE ACCESS BY INDEX ROWID BATCHED             | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|*176 |          INDEX RANGE SCAN                               | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*177 |        FILTER                                           |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 178 |         TABLE ACCESS BY INDEX ROWID BATCHED             | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|*179 |          INDEX RANGE SCAN                               | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*180 |        FILTER                                           |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 181 |         TABLE ACCESS BY INDEX ROWID BATCHED             | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|*182 |          INDEX RANGE SCAN                               | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*183 |        FILTER                                           |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 184 |         TABLE ACCESS BY INDEX ROWID BATCHED             | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|*185 |          INDEX RANGE SCAN                               | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*186 |        FILTER                                           |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 187 |         TABLE ACCESS BY INDEX ROWID BATCHED             | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|*188 |          INDEX RANGE SCAN                               | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*189 |        FILTER                                           |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 190 |         TABLE ACCESS BY INDEX ROWID BATCHED             | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|*191 |          INDEX RANGE SCAN                               | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*192 |        FILTER                                           |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 193 |         TABLE ACCESS BY INDEX ROWID BATCHED             | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|*194 |          INDEX RANGE SCAN                               | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*195 |        FILTER                                           |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 196 |         TABLE ACCESS BY INDEX ROWID BATCHED             | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|*197 |          INDEX RANGE SCAN                               | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*198 |        FILTER                                           |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 199 |         TABLE ACCESS BY INDEX ROWID BATCHED             | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|*200 |          INDEX RANGE SCAN                               | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*201 |        FILTER                                           |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 202 |         TABLE ACCESS BY INDEX ROWID BATCHED             | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|*203 |          INDEX RANGE SCAN                               | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*204 |        FILTER                                           |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 205 |         TABLE ACCESS BY INDEX ROWID BATCHED             | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|*206 |          INDEX RANGE SCAN                               | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*207 |        FILTER                                           |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 208 |         TABLE ACCESS BY INDEX ROWID BATCHED             | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|*209 |          INDEX RANGE SCAN                               | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*210 |        FILTER                                           |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 211 |         TABLE ACCESS BY INDEX ROWID BATCHED             | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|*212 |          INDEX RANGE SCAN                               | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*213 |        FILTER                                           |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 214 |         TABLE ACCESS BY INDEX ROWID BATCHED             | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|*215 |          INDEX RANGE SCAN                               | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*216 |        FILTER                                           |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 217 |         TABLE ACCESS BY INDEX ROWID BATCHED             | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|*218 |          INDEX RANGE SCAN                               | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*219 |        FILTER                                           |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 220 |         TABLE ACCESS BY INDEX ROWID BATCHED             | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|*221 |          INDEX RANGE SCAN                               | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*222 |         INDEX RANGE SCAN                                | ELIGB_ALERT_ID_IDX   |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
| 223 |          VIEW                                           | V_TDOMAINE           |      0 |     36 |   144   (0)|      0 |00:00:00.01 |       0 |
| 224 |           UNION-ALL                                     |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
|*225 |            FILTER                                       |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 226 |             TABLE ACCESS BY INDEX ROWID BATCHED         | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|*227 |              INDEX RANGE SCAN                           | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*228 |            FILTER                                       |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 229 |             TABLE ACCESS BY INDEX ROWID BATCHED         | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|*230 |              INDEX RANGE SCAN                           | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*231 |            FILTER                                       |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 232 |             TABLE ACCESS BY INDEX ROWID BATCHED         | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|*233 |              INDEX RANGE SCAN                           | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*234 |            FILTER                                       |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 235 |             TABLE ACCESS BY INDEX ROWID BATCHED         | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|*236 |              INDEX RANGE SCAN                           | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*237 |            FILTER                                       |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 238 |             TABLE ACCESS BY INDEX ROWID BATCHED         | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|*239 |              INDEX RANGE SCAN                           | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*240 |            FILTER                                       |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 241 |             TABLE ACCESS BY INDEX ROWID BATCHED         | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|*242 |              INDEX RANGE SCAN                           | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*243 |            FILTER                                       |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 244 |             TABLE ACCESS BY INDEX ROWID BATCHED         | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|*245 |              INDEX RANGE SCAN                           | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*246 |            FILTER                                       |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 247 |             TABLE ACCESS BY INDEX ROWID BATCHED         | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|*248 |              INDEX RANGE SCAN                           | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*249 |            FILTER                                       |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 250 |             TABLE ACCESS BY INDEX ROWID BATCHED         | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|*251 |              INDEX RANGE SCAN                           | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*252 |            FILTER                                       |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 253 |             TABLE ACCESS BY INDEX ROWID BATCHED         | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|*254 |              INDEX RANGE SCAN                           | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*255 |            FILTER                                       |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 256 |             TABLE ACCESS BY INDEX ROWID BATCHED         | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|*257 |              INDEX RANGE SCAN                           | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*258 |            FILTER                                       |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 259 |             TABLE ACCESS BY INDEX ROWID BATCHED         | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|*260 |              INDEX RANGE SCAN                           | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*261 |            FILTER                                       |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 262 |             TABLE ACCESS BY INDEX ROWID BATCHED         | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|*263 |              INDEX RANGE SCAN                           | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*264 |            FILTER                                       |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 265 |             TABLE ACCESS BY INDEX ROWID BATCHED         | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|*266 |              INDEX RANGE SCAN                           | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*267 |            FILTER                                       |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 268 |             TABLE ACCESS BY INDEX ROWID BATCHED         | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|*269 |              INDEX RANGE SCAN                           | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*270 |            FILTER                                       |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 271 |             TABLE ACCESS BY INDEX ROWID BATCHED         | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|*272 |              INDEX RANGE SCAN                           | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*273 |            FILTER                                       |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 274 |             TABLE ACCESS BY INDEX ROWID BATCHED         | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|*275 |              INDEX RANGE SCAN                           | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*276 |            FILTER                                       |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 277 |             TABLE ACCESS BY INDEX ROWID BATCHED         | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|*278 |              INDEX RANGE SCAN                           | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*279 |            FILTER                                       |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 280 |             TABLE ACCESS BY INDEX ROWID BATCHED         | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|*281 |              INDEX RANGE SCAN                           | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*282 |            FILTER                                       |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 283 |             TABLE ACCESS BY INDEX ROWID BATCHED         | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|*284 |              INDEX RANGE SCAN                           | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*285 |            FILTER                                       |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 286 |             TABLE ACCESS BY INDEX ROWID BATCHED         | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|*287 |              INDEX RANGE SCAN                           | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*288 |            FILTER                                       |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 289 |             TABLE ACCESS BY INDEX ROWID BATCHED         | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|*290 |              INDEX RANGE SCAN                           | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*291 |            FILTER                                       |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 292 |             TABLE ACCESS BY INDEX ROWID BATCHED         | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|*293 |              INDEX RANGE SCAN                           | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*294 |            FILTER                                       |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 295 |             TABLE ACCESS BY INDEX ROWID BATCHED         | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|*296 |              INDEX RANGE SCAN                           | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*297 |            FILTER                                       |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 298 |             TABLE ACCESS BY INDEX ROWID BATCHED         | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|*299 |              INDEX RANGE SCAN                           | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*300 |            FILTER                                       |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 301 |             TABLE ACCESS BY INDEX ROWID BATCHED         | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|*302 |              INDEX RANGE SCAN                           | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*303 |            FILTER                                       |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 304 |             TABLE ACCESS BY INDEX ROWID BATCHED         | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|*305 |              INDEX RANGE SCAN                           | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*306 |            FILTER                                       |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 307 |             TABLE ACCESS BY INDEX ROWID BATCHED         | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|*308 |              INDEX RANGE SCAN                           | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*309 |            FILTER                                       |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 310 |             TABLE ACCESS BY INDEX ROWID BATCHED         | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|*311 |              INDEX RANGE SCAN                           | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*312 |            FILTER                                       |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 313 |             TABLE ACCESS BY INDEX ROWID BATCHED         | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|*314 |              INDEX RANGE SCAN                           | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*315 |            FILTER                                       |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 316 |             TABLE ACCESS BY INDEX ROWID BATCHED         | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|*317 |              INDEX RANGE SCAN                           | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*318 |            FILTER                                       |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 319 |             TABLE ACCESS BY INDEX ROWID BATCHED         | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|*320 |              INDEX RANGE SCAN                           | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*321 |            FILTER                                       |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 322 |             TABLE ACCESS BY INDEX ROWID BATCHED         | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|*323 |              INDEX RANGE SCAN                           | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*324 |            FILTER                                       |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 325 |             TABLE ACCESS BY INDEX ROWID BATCHED         | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|*326 |              INDEX RANGE SCAN                           | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*327 |            FILTER                                       |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 328 |             TABLE ACCESS BY INDEX ROWID BATCHED         | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|*329 |              INDEX RANGE SCAN                           | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*330 |            FILTER                                       |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 331 |             TABLE ACCESS BY INDEX ROWID BATCHED         | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|*332 |              INDEX RANGE SCAN                           | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
| 333 |  NESTED LOOPS                                           |                      |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
| 334 |   NESTED LOOPS                                          |                      |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|*335 |    TABLE ACCESS BY INDEX ROWID BATCHED                  | G_DOSSIER            |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |
|*336 |     INDEX RANGE SCAN                                    | DOS_ANCREFDOSS       |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|*337 |    INDEX UNIQUE SCAN                                    | DOS_REFDOSS          |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|*338 |   TABLE ACCESS BY INDEX ROWID                           | G_DOSSIER            |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |
|*339 |    FILTER                                               |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 340 |     TABLE ACCESS BY INDEX ROWID BATCHED                 | G_DOSSIER            |      0 |  26295 |  2979   (1)|      0 |00:00:00.01 |       0 |
|*341 |      INDEX RANGE SCAN                                   | DOS_CATDOSS          |      0 |  26295 |   122   (0)|      0 |00:00:00.01 |       0 |
|*342 |     TABLE ACCESS BY INDEX ROWID BATCHED                 | G_DOSSIER            |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |
|*343 |      INDEX RANGE SCAN                                   | DOS_ANCREFDOSS       |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|*344 |  INDEX RANGE SCAN                                       | IDX_ALERTID_DET      |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
| 345 |   SORT GROUP BY                                         |                      |      0 |      1 |            |      0 |00:00:00.01 |       0 |
| 346 |    NESTED LOOPS                                         |                      |      0 |      1 |   145   (0)|      0 |00:00:00.01 |       0 |
| 347 |     TABLE ACCESS BY INDEX ROWID BATCHED                 | T_ALERT_NOT_ES_DET   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|*348 |      INDEX RANGE SCAN                                   | IDX_ALERTID_DET      |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
| 349 |     VIEW                                                | V_TDOMAINE           |      0 |      1 |   144   (0)|      0 |00:00:00.01 |       0 |
| 350 |      UNION ALL PUSHED PREDICATE                         |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
|*351 |       FILTER                                            |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 352 |        TABLE ACCESS BY INDEX ROWID BATCHED              | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|*353 |         INDEX RANGE SCAN                                | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*354 |       FILTER                                            |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 355 |        TABLE ACCESS BY INDEX ROWID BATCHED              | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|*356 |         INDEX RANGE SCAN                                | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*357 |       FILTER                                            |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 358 |        TABLE ACCESS BY INDEX ROWID BATCHED              | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|*359 |         INDEX RANGE SCAN                                | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*360 |       FILTER                                            |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 361 |        TABLE ACCESS BY INDEX ROWID BATCHED              | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|*362 |         INDEX RANGE SCAN                                | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*363 |       FILTER                                            |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 364 |        TABLE ACCESS BY INDEX ROWID BATCHED              | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|*365 |         INDEX RANGE SCAN                                | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*366 |       FILTER                                            |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 367 |        TABLE ACCESS BY INDEX ROWID BATCHED              | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|*368 |         INDEX RANGE SCAN                                | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*369 |       FILTER                                            |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 370 |        TABLE ACCESS BY INDEX ROWID BATCHED              | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|*371 |         INDEX RANGE SCAN                                | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*372 |       FILTER                                            |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 373 |        TABLE ACCESS BY INDEX ROWID BATCHED              | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|*374 |         INDEX RANGE SCAN                                | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*375 |       FILTER                                            |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 376 |        TABLE ACCESS BY INDEX ROWID BATCHED              | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|*377 |         INDEX RANGE SCAN                                | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*378 |       FILTER                                            |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 379 |        TABLE ACCESS BY INDEX ROWID BATCHED              | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|*380 |         INDEX RANGE SCAN                                | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*381 |       FILTER                                            |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 382 |        TABLE ACCESS BY INDEX ROWID BATCHED              | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|*383 |         INDEX RANGE SCAN                                | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*384 |       FILTER                                            |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 385 |        TABLE ACCESS BY INDEX ROWID BATCHED              | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|*386 |         INDEX RANGE SCAN                                | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*387 |       FILTER                                            |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 388 |        TABLE ACCESS BY INDEX ROWID BATCHED              | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|*389 |         INDEX RANGE SCAN                                | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*390 |       FILTER                                            |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 391 |        TABLE ACCESS BY INDEX ROWID BATCHED              | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|*392 |         INDEX RANGE SCAN                                | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*393 |       FILTER                                            |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 394 |        TABLE ACCESS BY INDEX ROWID BATCHED              | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|*395 |         INDEX RANGE SCAN                                | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*396 |       FILTER                                            |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 397 |        TABLE ACCESS BY INDEX ROWID BATCHED              | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|*398 |         INDEX RANGE SCAN                                | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*399 |       FILTER                                            |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 400 |        TABLE ACCESS BY INDEX ROWID BATCHED              | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|*401 |         INDEX RANGE SCAN                                | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*402 |       FILTER                                            |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 403 |        TABLE ACCESS BY INDEX ROWID BATCHED              | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|*404 |         INDEX RANGE SCAN                                | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*405 |       FILTER                                            |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 406 |        TABLE ACCESS BY INDEX ROWID BATCHED              | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|*407 |         INDEX RANGE SCAN                                | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*408 |       FILTER                                            |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 409 |        TABLE ACCESS BY INDEX ROWID BATCHED              | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|*410 |         INDEX RANGE SCAN                                | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*411 |       FILTER                                            |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 412 |        TABLE ACCESS BY INDEX ROWID BATCHED              | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|*413 |         INDEX RANGE SCAN                                | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*414 |       FILTER                                            |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 415 |        TABLE ACCESS BY INDEX ROWID BATCHED              | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|*416 |         INDEX RANGE SCAN                                | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*417 |       FILTER                                            |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 418 |        TABLE ACCESS BY INDEX ROWID BATCHED              | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|*419 |         INDEX RANGE SCAN                                | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*420 |       FILTER                                            |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 421 |        TABLE ACCESS BY INDEX ROWID BATCHED              | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|*422 |         INDEX RANGE SCAN                                | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*423 |       FILTER                                            |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 424 |        TABLE ACCESS BY INDEX ROWID BATCHED              | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|*425 |         INDEX RANGE SCAN                                | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*426 |       FILTER                                            |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 427 |        TABLE ACCESS BY INDEX ROWID BATCHED              | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|*428 |         INDEX RANGE SCAN                                | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*429 |       FILTER                                            |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 430 |        TABLE ACCESS BY INDEX ROWID BATCHED              | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|*431 |         INDEX RANGE SCAN                                | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*432 |       FILTER                                            |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 433 |        TABLE ACCESS BY INDEX ROWID BATCHED              | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|*434 |         INDEX RANGE SCAN                                | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*435 |       FILTER                                            |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 436 |        TABLE ACCESS BY INDEX ROWID BATCHED              | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|*437 |         INDEX RANGE SCAN                                | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*438 |       FILTER                                            |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 439 |        TABLE ACCESS BY INDEX ROWID BATCHED              | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|*440 |         INDEX RANGE SCAN                                | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*441 |       FILTER                                            |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 442 |        TABLE ACCESS BY INDEX ROWID BATCHED              | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|*443 |         INDEX RANGE SCAN                                | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*444 |       FILTER                                            |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 445 |        TABLE ACCESS BY INDEX ROWID BATCHED              | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|*446 |         INDEX RANGE SCAN                                | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*447 |       FILTER                                            |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 448 |        TABLE ACCESS BY INDEX ROWID BATCHED              | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|*449 |         INDEX RANGE SCAN                                | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*450 |       FILTER                                            |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 451 |        TABLE ACCESS BY INDEX ROWID BATCHED              | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|*452 |         INDEX RANGE SCAN                                | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*453 |       FILTER                                            |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 454 |        TABLE ACCESS BY INDEX ROWID BATCHED              | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|*455 |         INDEX RANGE SCAN                                | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*456 |       FILTER                                            |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 457 |        TABLE ACCESS BY INDEX ROWID BATCHED              | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|*458 |         INDEX RANGE SCAN                                | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
| 459 |  NESTED LOOPS                                           |                      |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
| 460 |   NESTED LOOPS                                          |                      |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|*461 |    TABLE ACCESS BY INDEX ROWID BATCHED                  | G_DOSSIER            |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |
|*462 |     INDEX RANGE SCAN                                    | DOS_ANCREFDOSS       |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|*463 |    INDEX UNIQUE SCAN                                    | DOS_REFDOSS          |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|*464 |   TABLE ACCESS BY INDEX ROWID                           | G_DOSSIER            |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |
|*465 |    COUNT STOPKEY                                        |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 466 |     NESTED LOOPS                                        |                      |      0 |      1 |     8   (0)|      0 |00:00:00.01 |       0 |
| 467 |      NESTED LOOPS                                       |                      |      0 |      1 |     8   (0)|      0 |00:00:00.01 |       0 |
| 468 |       NESTED LOOPS                                      |                      |      0 |      1 |     6   (0)|      0 |00:00:00.01 |       0 |
| 469 |        NESTED LOOPS                                     |                      |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|*470 |         TABLE ACCESS BY INDEX ROWID BATCHED             | G_DOSSIER            |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |
|*471 |          INDEX RANGE SCAN                               | DOS_ANCREFDOSS       |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|*472 |         TABLE ACCESS BY INDEX ROWID                     | G_DOSSIER            |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |
|*473 |          INDEX UNIQUE SCAN                              | DOS_REFDOSS          |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|*474 |        INDEX RANGE SCAN                                 | INT_REFDOSS          |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |
|*475 |       INDEX UNIQUE SCAN                                 | IND_REFINDIV         |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
| 476 |      TABLE ACCESS BY INDEX ROWID                        | G_INDIVIDU           |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |
|*477 |     COUNT STOPKEY                                       |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 478 |      NESTED LOOPS                                       |                      |      0 |      3 |    14   (0)|      0 |00:00:00.01 |       0 |
| 479 |       NESTED LOOPS                                      |                      |      0 |      3 |    14   (0)|      0 |00:00:00.01 |       0 |
| 480 |        NESTED LOOPS                                     |                      |      0 |      3 |     8   (0)|      0 |00:00:00.01 |       0 |
| 481 |         TABLE ACCESS BY INDEX ROWID BATCHED             | G_DOSSIER            |      0 |     60 |     2   (0)|      0 |00:00:00.01 |       0 |
|*482 |          INDEX RANGE SCAN                               | DOS_ANCREFDOSS       |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|*483 |         INDEX RANGE SCAN                                | INT_REFDOSS          |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |
|*484 |        INDEX UNIQUE SCAN                                | IND_REFINDIV         |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
| 485 |       TABLE ACCESS BY INDEX ROWID                       | G_INDIVIDU           |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |
|*486 |  VIEW                                                   |                      |      1 |      1 | 50198   (1)|      0 |00:00:00.01 |       3 |
|*487 |   COUNT STOPKEY                                         |                      |      1 |        |            |      0 |00:00:00.01 |       3 |
| 488 |    VIEW                                                 |                      |      1 |      1 | 50198   (1)|      0 |00:00:00.01 |       3 |
|*489 |     SORT ORDER BY STOPKEY                               |                      |      1 |      1 | 50198   (1)|      0 |00:00:00.01 |       3 |
|*490 |      FILTER                                             |                      |      1 |        |            |      0 |00:00:00.01 |       3 |
|*491 |       FILTER                                            |                      |      1 |        |            |      0 |00:00:00.01 |       3 |
| 492 |        NESTED LOOPS OUTER                               |                      |      1 |      1 |   540   (0)|      0 |00:00:00.01 |       3 |
| 493 |         NESTED LOOPS OUTER                              |                      |      1 |      1 |   432   (0)|      0 |00:00:00.01 |       3 |
| 494 |          NESTED LOOPS OUTER                             |                      |      1 |      1 |   288   (0)|      0 |00:00:00.01 |       3 |
| 495 |           NESTED LOOPS OUTER                            |                      |      1 |      1 |   180   (0)|      0 |00:00:00.01 |       3 |
| 496 |            NESTED LOOPS OUTER                           |                      |      1 |      1 |   170   (0)|      0 |00:00:00.01 |       3 |
|*497 |             FILTER                                      |                      |      1 |        |            |      0 |00:00:00.01 |       3 |
| 498 |              NESTED LOOPS OUTER                         |                      |      1 |      1 |   165   (0)|      0 |00:00:00.01 |       3 |
|*499 |               HASH JOIN                                 |                      |      1 |      1 |    21   (0)|      0 |00:00:00.01 |       3 |
| 500 |                JOIN FILTER CREATE                       | :BF0000              |      1 |      1 |    13   (0)|      0 |00:00:00.01 |       3 |
| 501 |                 NESTED LOOPS                            |                      |      1 |      1 |    13   (0)|      0 |00:00:00.01 |       3 |
| 502 |                  NESTED LOOPS                           |                      |      1 |      1 |    13   (0)|      0 |00:00:00.01 |       3 |
| 503 |                   NESTED LOOPS                          |                      |      1 |      1 |    11   (0)|      0 |00:00:00.01 |       3 |
| 504 |                    NESTED LOOPS OUTER                   |                      |      1 |      1 |     9   (0)|      0 |00:00:00.01 |       3 |
| 505 |                     NESTED LOOPS ANTI                   |                      |      1 |      1 |     7   (0)|      0 |00:00:00.01 |       3 |
|*506 |                      TABLE ACCESS BY INDEX ROWID BATCHED| T_ALERTE             |      1 |      1 |     4   (0)|      0 |00:00:00.01 |       3 |
|*507 |                       INDEX RANGE SCAN                  | TEST_DD_REFEXT_INDEX |      1 |      2 |     3   (0)|      0 |00:00:00.01 |       3 |
|*508 |                      TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE            |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*509 |                       INDEX RANGE SCAN                  | DOM_TYPVAL           |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
| 510 |                     TABLE ACCESS BY INDEX ROWID         | G_DOSSIER            |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |
|*511 |                      INDEX UNIQUE SCAN                  | DOS_REFDOSS          |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
| 512 |                    TABLE ACCESS BY INDEX ROWID BATCHED  | G_PERSONNEL          |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |
|*513 |                     INDEX RANGE SCAN                    | GPERSREFP            |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|*514 |                   INDEX UNIQUE SCAN                     | IND_REFINDIV         |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
| 515 |                  TABLE ACCESS BY INDEX ROWID            | G_INDIVIDU           |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |
| 516 |                VIEW                                     | VW_NSO_1             |      0 |      4 |     8   (0)|      0 |00:00:00.01 |       0 |
| 517 |                 HASH UNIQUE                             |                      |      0 |      4 |     8   (0)|      0 |00:00:00.01 |       0 |
| 518 |                  JOIN FILTER USE                        | :BF0000              |      0 |        |            |      0 |00:00:00.01 |       0 |
| 519 |                   UNION-ALL                             |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
|*520 |                    INDEX RANGE SCAN                     | G_INDIVPARAM_REFIND  |      0 |      2 |     3   (0)|      0 |00:00:00.01 |       0 |
| 521 |                    FAST DUAL                            |                      |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |
| 522 |                    NESTED LOOPS                         |                      |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
| 523 |                     NESTED LOOPS                        |                      |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*524 |                      INDEX RANGE SCAN                   | AGE_PERSOJOUR        |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|*525 |                      INDEX RANGE SCAN                   | GPERSREFP            |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|*526 |                     TABLE ACCESS BY INDEX ROWID         | G_PERSONNEL          |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |
| 527 |               VIEW PUSHED PREDICATE                     |                      |      0 |      1 |   144   (0)|      0 |00:00:00.01 |       0 |
| 528 |                SORT GROUP BY                            |                      |      0 |      1 |   144   (0)|      0 |00:00:00.01 |       0 |
| 529 |                 VIEW                                    | V_TDOMAINE           |      0 |     36 |   144   (0)|      0 |00:00:00.01 |       0 |
| 530 |                  UNION-ALL                              |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
|*531 |                   FILTER                                |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 532 |                    TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|*533 |                     INDEX RANGE SCAN                    | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*534 |                   FILTER                                |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 535 |                    TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|*536 |                     INDEX RANGE SCAN                    | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*537 |                   FILTER                                |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 538 |                    TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|*539 |                     INDEX RANGE SCAN                    | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*540 |                   FILTER                                |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 541 |                    TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|*542 |                     INDEX RANGE SCAN                    | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*543 |                   FILTER                                |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 544 |                    TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|*545 |                     INDEX RANGE SCAN                    | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*546 |                   FILTER                                |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 547 |                    TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|*548 |                     INDEX RANGE SCAN                    | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*549 |                   FILTER                                |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 550 |                    TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|*551 |                     INDEX RANGE SCAN                    | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*552 |                   FILTER                                |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 553 |                    TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|*554 |                     INDEX RANGE SCAN                    | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*555 |                   FILTER                                |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 556 |                    TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|*557 |                     INDEX RANGE SCAN                    | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*558 |                   FILTER                                |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 559 |                    TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|*560 |                     INDEX RANGE SCAN                    | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*561 |                   FILTER                                |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 562 |                    TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|*563 |                     INDEX RANGE SCAN                    | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*564 |                   FILTER                                |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 565 |                    TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|*566 |                     INDEX RANGE SCAN                    | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*567 |                   FILTER                                |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 568 |                    TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|*569 |                     INDEX RANGE SCAN                    | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*570 |                   FILTER                                |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 571 |                    TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|*572 |                     INDEX RANGE SCAN                    | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*573 |                   FILTER                                |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 574 |                    TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|*575 |                     INDEX RANGE SCAN                    | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*576 |                   FILTER                                |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 577 |                    TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|*578 |                     INDEX RANGE SCAN                    | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*579 |                   FILTER                                |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 580 |                    TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|*581 |                     INDEX RANGE SCAN                    | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*582 |                   FILTER                                |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 583 |                    TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|*584 |                     INDEX RANGE SCAN                    | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*585 |                   FILTER                                |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 586 |                    TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|*587 |                     INDEX RANGE SCAN                    | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*588 |                   FILTER                                |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 589 |                    TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|*590 |                     INDEX RANGE SCAN                    | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*591 |                   FILTER                                |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 592 |                    TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|*593 |                     INDEX RANGE SCAN                    | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*594 |                   FILTER                                |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 595 |                    TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|*596 |                     INDEX RANGE SCAN                    | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*597 |                   FILTER                                |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 598 |                    TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|*599 |                     INDEX RANGE SCAN                    | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*600 |                   FILTER                                |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 601 |                    TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|*602 |                     INDEX RANGE SCAN                    | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*603 |                   FILTER                                |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 604 |                    TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|*605 |                     INDEX RANGE SCAN                    | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*606 |                   FILTER                                |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 607 |                    TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|*608 |                     INDEX RANGE SCAN                    | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*609 |                   FILTER                                |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 610 |                    TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|*611 |                     INDEX RANGE SCAN                    | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*612 |                   FILTER                                |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 613 |                    TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|*614 |                     INDEX RANGE SCAN                    | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*615 |                   FILTER                                |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 616 |                    TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|*617 |                     INDEX RANGE SCAN                    | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*618 |                   FILTER                                |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 619 |                    TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|*620 |                     INDEX RANGE SCAN                    | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*621 |                   FILTER                                |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 622 |                    TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|*623 |                     INDEX RANGE SCAN                    | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*624 |                   FILTER                                |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 625 |                    TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|*626 |                     INDEX RANGE SCAN                    | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*627 |                   FILTER                                |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 628 |                    TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|*629 |                     INDEX RANGE SCAN                    | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*630 |                   FILTER                                |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 631 |                    TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|*632 |                     INDEX RANGE SCAN                    | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*633 |                   FILTER                                |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 634 |                    TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|*635 |                     INDEX RANGE SCAN                    | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*636 |                   FILTER                                |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 637 |                    TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|*638 |                     INDEX RANGE SCAN                    | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
| 639 |             VIEW PUSHED PREDICATE                       |                      |      0 |      1 |     5   (0)|      0 |00:00:00.01 |       0 |
| 640 |              NESTED LOOPS                               |                      |      0 |      1 |     5   (0)|      0 |00:00:00.01 |       0 |
| 641 |               NESTED LOOPS                              |                      |      0 |      1 |     5   (0)|      0 |00:00:00.01 |       0 |
|*642 |                INDEX RANGE SCAN                         | INT_REFDOSS          |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*643 |                INDEX UNIQUE SCAN                        | IND_REFINDIV         |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
| 644 |               TABLE ACCESS BY INDEX ROWID               | G_INDIVIDU           |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |
| 645 |            VIEW PUSHED PREDICATE                        |                      |      0 |      1 |    10   (0)|      0 |00:00:00.01 |       0 |
| 646 |             NESTED LOOPS                                |                      |      0 |      1 |    10   (0)|      0 |00:00:00.01 |       0 |
| 647 |              NESTED LOOPS                               |                      |      0 |      1 |    10   (0)|      0 |00:00:00.01 |       0 |
| 648 |               NESTED LOOPS                              |                      |      0 |      1 |     8   (0)|      0 |00:00:00.01 |       0 |
| 649 |                NESTED LOOPS                             |                      |      0 |      1 |     7   (0)|      0 |00:00:00.01 |       0 |
| 650 |                 NESTED LOOPS                            |                      |      0 |      1 |     5   (0)|      0 |00:00:00.01 |       0 |
| 651 |                  TABLE ACCESS BY INDEX ROWID            | G_DOSSIER            |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*652 |                   INDEX UNIQUE SCAN                     | DOS_REFDOSS          |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |
|*653 |                  INDEX RANGE SCAN                       | DOM_TYPABREV         |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |
|*654 |                 INDEX RANGE SCAN                        | INT_REFDOSS          |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |
|*655 |                TABLE ACCESS BY INDEX ROWID BATCHED      | V_INTERVENANTS       |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|*656 |                 INDEX RANGE SCAN                        | V_INTERVENANTS_AK    |      0 |      1 |     0   (0)|      0 |00:00:00.01 |       0 |
|*657 |               INDEX UNIQUE SCAN                         | IND_REFINDIV         |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
| 658 |              TABLE ACCESS BY INDEX ROWID                | G_INDIVIDU           |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |
| 659 |           VIEW PUSHED PREDICATE                         |                      |      0 |      1 |   108   (0)|      0 |00:00:00.01 |       0 |
| 660 |            SORT GROUP BY                                |                      |      0 |      1 |   108   (0)|      0 |00:00:00.01 |       0 |
| 661 |             VIEW                                        | V_TDOMAINE           |      0 |     36 |   108   (0)|      0 |00:00:00.01 |       0 |
| 662 |              UNION-ALL                                  |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
|*663 |               FILTER                                    |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 664 |                TABLE ACCESS BY INDEX ROWID BATCHED      | V_DOMAINE            |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*665 |                 INDEX RANGE SCAN                        | DOM_TYPVAL           |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|*666 |               FILTER                                    |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 667 |                TABLE ACCESS BY INDEX ROWID BATCHED      | V_DOMAINE            |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*668 |                 INDEX RANGE SCAN                        | DOM_TYPVAL           |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|*669 |               FILTER                                    |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 670 |                TABLE ACCESS BY INDEX ROWID BATCHED      | V_DOMAINE            |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*671 |                 INDEX RANGE SCAN                        | DOM_TYPVAL           |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|*672 |               FILTER                                    |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 673 |                TABLE ACCESS BY INDEX ROWID BATCHED      | V_DOMAINE            |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*674 |                 INDEX RANGE SCAN                        | DOM_TYPVAL           |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|*675 |               FILTER                                    |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 676 |                TABLE ACCESS BY INDEX ROWID BATCHED      | V_DOMAINE            |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*677 |                 INDEX RANGE SCAN                        | DOM_TYPVAL           |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|*678 |               FILTER                                    |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 679 |                TABLE ACCESS BY INDEX ROWID BATCHED      | V_DOMAINE            |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*680 |                 INDEX RANGE SCAN                        | DOM_TYPVAL           |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|*681 |               FILTER                                    |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 682 |                TABLE ACCESS BY INDEX ROWID BATCHED      | V_DOMAINE            |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*683 |                 INDEX RANGE SCAN                        | DOM_TYPVAL           |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|*684 |               FILTER                                    |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 685 |                TABLE ACCESS BY INDEX ROWID BATCHED      | V_DOMAINE            |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*686 |                 INDEX RANGE SCAN                        | DOM_TYPVAL           |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|*687 |               FILTER                                    |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 688 |                TABLE ACCESS BY INDEX ROWID BATCHED      | V_DOMAINE            |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*689 |                 INDEX RANGE SCAN                        | DOM_TYPVAL           |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|*690 |               FILTER                                    |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 691 |                TABLE ACCESS BY INDEX ROWID BATCHED      | V_DOMAINE            |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*692 |                 INDEX RANGE SCAN                        | DOM_TYPVAL           |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|*693 |               FILTER                                    |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 694 |                TABLE ACCESS BY INDEX ROWID BATCHED      | V_DOMAINE            |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*695 |                 INDEX RANGE SCAN                        | DOM_TYPVAL           |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|*696 |               FILTER                                    |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 697 |                TABLE ACCESS BY INDEX ROWID BATCHED      | V_DOMAINE            |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*698 |                 INDEX RANGE SCAN                        | DOM_TYPVAL           |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|*699 |               FILTER                                    |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 700 |                TABLE ACCESS BY INDEX ROWID BATCHED      | V_DOMAINE            |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*701 |                 INDEX RANGE SCAN                        | DOM_TYPVAL           |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|*702 |               FILTER                                    |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 703 |                TABLE ACCESS BY INDEX ROWID BATCHED      | V_DOMAINE            |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*704 |                 INDEX RANGE SCAN                        | DOM_TYPVAL           |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|*705 |               FILTER                                    |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 706 |                TABLE ACCESS BY INDEX ROWID BATCHED      | V_DOMAINE            |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*707 |                 INDEX RANGE SCAN                        | DOM_TYPVAL           |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|*708 |               FILTER                                    |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 709 |                TABLE ACCESS BY INDEX ROWID BATCHED      | V_DOMAINE            |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*710 |                 INDEX RANGE SCAN                        | DOM_TYPVAL           |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|*711 |               FILTER                                    |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 712 |                TABLE ACCESS BY INDEX ROWID BATCHED      | V_DOMAINE            |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*713 |                 INDEX RANGE SCAN                        | DOM_TYPVAL           |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|*714 |               FILTER                                    |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 715 |                TABLE ACCESS BY INDEX ROWID BATCHED      | V_DOMAINE            |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*716 |                 INDEX RANGE SCAN                        | DOM_TYPVAL           |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|*717 |               FILTER                                    |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 718 |                TABLE ACCESS BY INDEX ROWID BATCHED      | V_DOMAINE            |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*719 |                 INDEX RANGE SCAN                        | DOM_TYPVAL           |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|*720 |               FILTER                                    |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 721 |                TABLE ACCESS BY INDEX ROWID BATCHED      | V_DOMAINE            |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*722 |                 INDEX RANGE SCAN                        | DOM_TYPVAL           |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|*723 |               FILTER                                    |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 724 |                TABLE ACCESS BY INDEX ROWID BATCHED      | V_DOMAINE            |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*725 |                 INDEX RANGE SCAN                        | DOM_TYPVAL           |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|*726 |               FILTER                                    |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 727 |                TABLE ACCESS BY INDEX ROWID BATCHED      | V_DOMAINE            |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*728 |                 INDEX RANGE SCAN                        | DOM_TYPVAL           |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|*729 |               FILTER                                    |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 730 |                TABLE ACCESS BY INDEX ROWID BATCHED      | V_DOMAINE            |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*731 |                 INDEX RANGE SCAN                        | DOM_TYPVAL           |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|*732 |               FILTER                                    |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 733 |                TABLE ACCESS BY INDEX ROWID BATCHED      | V_DOMAINE            |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*734 |                 INDEX RANGE SCAN                        | DOM_TYPVAL           |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|*735 |               FILTER                                    |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 736 |                TABLE ACCESS BY INDEX ROWID BATCHED      | V_DOMAINE            |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*737 |                 INDEX RANGE SCAN                        | DOM_TYPVAL           |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|*738 |               FILTER                                    |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 739 |                TABLE ACCESS BY INDEX ROWID BATCHED      | V_DOMAINE            |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*740 |                 INDEX RANGE SCAN                        | DOM_TYPVAL           |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|*741 |               FILTER                                    |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 742 |                TABLE ACCESS BY INDEX ROWID BATCHED      | V_DOMAINE            |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*743 |                 INDEX RANGE SCAN                        | DOM_TYPVAL           |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|*744 |               FILTER                                    |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 745 |                TABLE ACCESS BY INDEX ROWID BATCHED      | V_DOMAINE            |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*746 |                 INDEX RANGE SCAN                        | DOM_TYPVAL           |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|*747 |               FILTER                                    |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 748 |                TABLE ACCESS BY INDEX ROWID BATCHED      | V_DOMAINE            |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*749 |                 INDEX RANGE SCAN                        | DOM_TYPVAL           |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|*750 |               FILTER                                    |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 751 |                TABLE ACCESS BY INDEX ROWID BATCHED      | V_DOMAINE            |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*752 |                 INDEX RANGE SCAN                        | DOM_TYPVAL           |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|*753 |               FILTER                                    |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 754 |                TABLE ACCESS BY INDEX ROWID BATCHED      | V_DOMAINE            |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*755 |                 INDEX RANGE SCAN                        | DOM_TYPVAL           |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|*756 |               FILTER                                    |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 757 |                TABLE ACCESS BY INDEX ROWID BATCHED      | V_DOMAINE            |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*758 |                 INDEX RANGE SCAN                        | DOM_TYPVAL           |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|*759 |               FILTER                                    |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 760 |                TABLE ACCESS BY INDEX ROWID BATCHED      | V_DOMAINE            |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*761 |                 INDEX RANGE SCAN                        | DOM_TYPVAL           |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|*762 |               FILTER                                    |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 763 |                TABLE ACCESS BY INDEX ROWID BATCHED      | V_DOMAINE            |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*764 |                 INDEX RANGE SCAN                        | DOM_TYPVAL           |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|*765 |               FILTER                                    |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 766 |                TABLE ACCESS BY INDEX ROWID BATCHED      | V_DOMAINE            |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*767 |                 INDEX RANGE SCAN                        | DOM_TYPVAL           |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|*768 |               FILTER                                    |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 769 |                TABLE ACCESS BY INDEX ROWID BATCHED      | V_DOMAINE            |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*770 |                 INDEX RANGE SCAN                        | DOM_TYPVAL           |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
| 771 |          VIEW PUSHED PREDICATE                          |                      |      0 |      1 |   144   (0)|      0 |00:00:00.01 |       0 |
| 772 |           SORT GROUP BY                                 |                      |      0 |      1 |   144   (0)|      0 |00:00:00.01 |       0 |
| 773 |            VIEW                                         | V_TDOMAINE           |      0 |     36 |   144   (0)|      0 |00:00:00.01 |       0 |
| 774 |             UNION-ALL                                   |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
|*775 |              FILTER                                     |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 776 |               TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|*777 |                INDEX RANGE SCAN                         | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*778 |              FILTER                                     |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 779 |               TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|*780 |                INDEX RANGE SCAN                         | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*781 |              FILTER                                     |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 782 |               TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|*783 |                INDEX RANGE SCAN                         | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*784 |              FILTER                                     |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 785 |               TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|*786 |                INDEX RANGE SCAN                         | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*787 |              FILTER                                     |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 788 |               TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|*789 |                INDEX RANGE SCAN                         | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*790 |              FILTER                                     |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 791 |               TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|*792 |                INDEX RANGE SCAN                         | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*793 |              FILTER                                     |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 794 |               TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|*795 |                INDEX RANGE SCAN                         | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*796 |              FILTER                                     |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 797 |               TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|*798 |                INDEX RANGE SCAN                         | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*799 |              FILTER                                     |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 800 |               TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|*801 |                INDEX RANGE SCAN                         | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*802 |              FILTER                                     |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 803 |               TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|*804 |                INDEX RANGE SCAN                         | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*805 |              FILTER                                     |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 806 |               TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|*807 |                INDEX RANGE SCAN                         | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*808 |              FILTER                                     |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 809 |               TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|*810 |                INDEX RANGE SCAN                         | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*811 |              FILTER                                     |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 812 |               TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|*813 |                INDEX RANGE SCAN                         | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*814 |              FILTER                                     |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 815 |               TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|*816 |                INDEX RANGE SCAN                         | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*817 |              FILTER                                     |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 818 |               TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|*819 |                INDEX RANGE SCAN                         | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*820 |              FILTER                                     |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 821 |               TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|*822 |                INDEX RANGE SCAN                         | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*823 |              FILTER                                     |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 824 |               TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|*825 |                INDEX RANGE SCAN                         | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*826 |              FILTER                                     |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 827 |               TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|*828 |                INDEX RANGE SCAN                         | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*829 |              FILTER                                     |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 830 |               TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|*831 |                INDEX RANGE SCAN                         | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*832 |              FILTER                                     |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 833 |               TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|*834 |                INDEX RANGE SCAN                         | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*835 |              FILTER                                     |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 836 |               TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|*837 |                INDEX RANGE SCAN                         | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*838 |              FILTER                                     |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 839 |               TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|*840 |                INDEX RANGE SCAN                         | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*841 |              FILTER                                     |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 842 |               TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|*843 |                INDEX RANGE SCAN                         | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*844 |              FILTER                                     |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 845 |               TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|*846 |                INDEX RANGE SCAN                         | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*847 |              FILTER                                     |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 848 |               TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|*849 |                INDEX RANGE SCAN                         | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*850 |              FILTER                                     |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 851 |               TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|*852 |                INDEX RANGE SCAN                         | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*853 |              FILTER                                     |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 854 |               TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|*855 |                INDEX RANGE SCAN                         | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*856 |              FILTER                                     |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 857 |               TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|*858 |                INDEX RANGE SCAN                         | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*859 |              FILTER                                     |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 860 |               TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|*861 |                INDEX RANGE SCAN                         | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*862 |              FILTER                                     |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 863 |               TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|*864 |                INDEX RANGE SCAN                         | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*865 |              FILTER                                     |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 866 |               TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|*867 |                INDEX RANGE SCAN                         | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*868 |              FILTER                                     |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 869 |               TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|*870 |                INDEX RANGE SCAN                         | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*871 |              FILTER                                     |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 872 |               TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|*873 |                INDEX RANGE SCAN                         | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*874 |              FILTER                                     |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 875 |               TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|*876 |                INDEX RANGE SCAN                         | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*877 |              FILTER                                     |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 878 |               TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|*879 |                INDEX RANGE SCAN                         | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*880 |              FILTER                                     |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 881 |               TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|*882 |                INDEX RANGE SCAN                         | DOM_TYPABREV         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
| 883 |         VIEW PUSHED PREDICATE                           |                      |      0 |      1 |   108   (0)|      0 |00:00:00.01 |       0 |
| 884 |          SORT GROUP BY                                  |                      |      0 |      1 |   108   (0)|      0 |00:00:00.01 |       0 |
| 885 |           VIEW                                          | V_TDOMAINE           |      0 |     36 |   108   (0)|      0 |00:00:00.01 |       0 |
| 886 |            UNION-ALL                                    |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
|*887 |             FILTER                                      |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 888 |              TABLE ACCESS BY INDEX ROWID BATCHED        | V_DOMAINE            |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*889 |               INDEX RANGE SCAN                          | DOM_TYPVAL           |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|*890 |             FILTER                                      |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 891 |              TABLE ACCESS BY INDEX ROWID BATCHED        | V_DOMAINE            |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*892 |               INDEX RANGE SCAN                          | DOM_TYPVAL           |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|*893 |             FILTER                                      |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 894 |              TABLE ACCESS BY INDEX ROWID BATCHED        | V_DOMAINE            |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*895 |               INDEX RANGE SCAN                          | DOM_TYPVAL           |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|*896 |             FILTER                                      |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 897 |              TABLE ACCESS BY INDEX ROWID BATCHED        | V_DOMAINE            |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*898 |               INDEX RANGE SCAN                          | DOM_TYPVAL           |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|*899 |             FILTER                                      |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 900 |              TABLE ACCESS BY INDEX ROWID BATCHED        | V_DOMAINE            |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*901 |               INDEX RANGE SCAN                          | DOM_TYPVAL           |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|*902 |             FILTER                                      |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 903 |              TABLE ACCESS BY INDEX ROWID BATCHED        | V_DOMAINE            |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*904 |               INDEX RANGE SCAN                          | DOM_TYPVAL           |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|*905 |             FILTER                                      |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 906 |              TABLE ACCESS BY INDEX ROWID BATCHED        | V_DOMAINE            |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*907 |               INDEX RANGE SCAN                          | DOM_TYPVAL           |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|*908 |             FILTER                                      |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 909 |              TABLE ACCESS BY INDEX ROWID BATCHED        | V_DOMAINE            |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*910 |               INDEX RANGE SCAN                          | DOM_TYPVAL           |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|*911 |             FILTER                                      |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 912 |              TABLE ACCESS BY INDEX ROWID BATCHED        | V_DOMAINE            |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*913 |               INDEX RANGE SCAN                          | DOM_TYPVAL           |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|*914 |             FILTER                                      |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 915 |              TABLE ACCESS BY INDEX ROWID BATCHED        | V_DOMAINE            |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*916 |               INDEX RANGE SCAN                          | DOM_TYPVAL           |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|*917 |             FILTER                                      |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 918 |              TABLE ACCESS BY INDEX ROWID BATCHED        | V_DOMAINE            |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*919 |               INDEX RANGE SCAN                          | DOM_TYPVAL           |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|*920 |             FILTER                                      |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 921 |              TABLE ACCESS BY INDEX ROWID BATCHED        | V_DOMAINE            |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*922 |               INDEX RANGE SCAN                          | DOM_TYPVAL           |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|*923 |             FILTER                                      |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 924 |              TABLE ACCESS BY INDEX ROWID BATCHED        | V_DOMAINE            |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*925 |               INDEX RANGE SCAN                          | DOM_TYPVAL           |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|*926 |             FILTER                                      |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 927 |              TABLE ACCESS BY INDEX ROWID BATCHED        | V_DOMAINE            |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*928 |               INDEX RANGE SCAN                          | DOM_TYPVAL           |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|*929 |             FILTER                                      |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 930 |              TABLE ACCESS BY INDEX ROWID BATCHED        | V_DOMAINE            |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*931 |               INDEX RANGE SCAN                          | DOM_TYPVAL           |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|*932 |             FILTER                                      |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 933 |              TABLE ACCESS BY INDEX ROWID BATCHED        | V_DOMAINE            |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*934 |               INDEX RANGE SCAN                          | DOM_TYPVAL           |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|*935 |             FILTER                                      |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 936 |              TABLE ACCESS BY INDEX ROWID BATCHED        | V_DOMAINE            |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*937 |               INDEX RANGE SCAN                          | DOM_TYPVAL           |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|*938 |             FILTER                                      |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 939 |              TABLE ACCESS BY INDEX ROWID BATCHED        | V_DOMAINE            |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*940 |               INDEX RANGE SCAN                          | DOM_TYPVAL           |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|*941 |             FILTER                                      |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 942 |              TABLE ACCESS BY INDEX ROWID BATCHED        | V_DOMAINE            |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*943 |               INDEX RANGE SCAN                          | DOM_TYPVAL           |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|*944 |             FILTER                                      |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 945 |              TABLE ACCESS BY INDEX ROWID BATCHED        | V_DOMAINE            |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*946 |               INDEX RANGE SCAN                          | DOM_TYPVAL           |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|*947 |             FILTER                                      |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 948 |              TABLE ACCESS BY INDEX ROWID BATCHED        | V_DOMAINE            |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*949 |               INDEX RANGE SCAN                          | DOM_TYPVAL           |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|*950 |             FILTER                                      |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 951 |              TABLE ACCESS BY INDEX ROWID BATCHED        | V_DOMAINE            |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*952 |               INDEX RANGE SCAN                          | DOM_TYPVAL           |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|*953 |             FILTER                                      |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 954 |              TABLE ACCESS BY INDEX ROWID BATCHED        | V_DOMAINE            |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*955 |               INDEX RANGE SCAN                          | DOM_TYPVAL           |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|*956 |             FILTER                                      |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 957 |              TABLE ACCESS BY INDEX ROWID BATCHED        | V_DOMAINE            |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*958 |               INDEX RANGE SCAN                          | DOM_TYPVAL           |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|*959 |             FILTER                                      |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 960 |              TABLE ACCESS BY INDEX ROWID BATCHED        | V_DOMAINE            |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*961 |               INDEX RANGE SCAN                          | DOM_TYPVAL           |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|*962 |             FILTER                                      |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 963 |              TABLE ACCESS BY INDEX ROWID BATCHED        | V_DOMAINE            |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*964 |               INDEX RANGE SCAN                          | DOM_TYPVAL           |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|*965 |             FILTER                                      |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 966 |              TABLE ACCESS BY INDEX ROWID BATCHED        | V_DOMAINE            |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*967 |               INDEX RANGE SCAN                          | DOM_TYPVAL           |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|*968 |             FILTER                                      |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 969 |              TABLE ACCESS BY INDEX ROWID BATCHED        | V_DOMAINE            |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*970 |               INDEX RANGE SCAN                          | DOM_TYPVAL           |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|*971 |             FILTER                                      |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 972 |              TABLE ACCESS BY INDEX ROWID BATCHED        | V_DOMAINE            |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*973 |               INDEX RANGE SCAN                          | DOM_TYPVAL           |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|*974 |             FILTER                                      |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 975 |              TABLE ACCESS BY INDEX ROWID BATCHED        | V_DOMAINE            |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*976 |               INDEX RANGE SCAN                          | DOM_TYPVAL           |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|*977 |             FILTER                                      |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 978 |              TABLE ACCESS BY INDEX ROWID BATCHED        | V_DOMAINE            |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*979 |               INDEX RANGE SCAN                          | DOM_TYPVAL           |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|*980 |             FILTER                                      |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 981 |              TABLE ACCESS BY INDEX ROWID BATCHED        | V_DOMAINE            |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*982 |               INDEX RANGE SCAN                          | DOM_TYPVAL           |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|*983 |             FILTER                                      |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 984 |              TABLE ACCESS BY INDEX ROWID BATCHED        | V_DOMAINE            |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*985 |               INDEX RANGE SCAN                          | DOM_TYPVAL           |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|*986 |             FILTER                                      |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 987 |              TABLE ACCESS BY INDEX ROWID BATCHED        | V_DOMAINE            |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*988 |               INDEX RANGE SCAN                          | DOM_TYPVAL           |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|*989 |             FILTER                                      |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 990 |              TABLE ACCESS BY INDEX ROWID BATCHED        | V_DOMAINE            |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*991 |               INDEX RANGE SCAN                          | DOM_TYPVAL           |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|*992 |             FILTER                                      |                      |      0 |        |            |      0 |00:00:00.01 |       0 |
| 993 |              TABLE ACCESS BY INDEX ROWID BATCHED        | V_DOMAINE            |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*994 |               INDEX RANGE SCAN                          | DOM_TYPVAL           |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
| 995 |       NESTED LOOPS                                      |                      |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
| 996 |        NESTED LOOPS                                     |                      |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |
|*997 |         INDEX RANGE SCAN                                | PK_T_FCTMEMBMG       |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |
|*998 |         INDEX UNIQUE SCAN                               | PK_G_MANGRP          |      0 |      1 |     0   (0)|      0 |00:00:00.01 |       0 |
|*999 |        INDEX UNIQUE SCAN                                | PK_T_GESTFCTCOMP     |      0 |      1 |     0   (0)|      0 |00:00:00.01 |       0 |
-------------------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   3 - filter('AL'=:B1)
   5 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='SE')
   6 - filter('AN'=:B1)
   8 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='SE')
   9 - filter('AR'=:B1)
  11 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='SE')
  12 - filter('BG'=:B1)
  14 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='SE')
  15 - filter('BR'=:B1)
  17 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='SE')
  18 - filter('CE'=:B1)
  20 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='SE')
  21 - filter('CH'=:B1)
  23 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='SE')
  24 - filter('CS'=:B1)
  26 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='SE')
  27 - filter('DA'=:B1)
  29 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='SE')
  30 - filter('EL'=:B1)
  32 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='SE')
  33 - filter('ES'=:B1)
  35 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='SE')
  36 - filter('ET'=:B1)
  38 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='SE')
  39 - filter('FI'=:B1)
  41 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='SE')
  42 - filter('FR'=:B1)
  44 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='SE')
  45 - filter('HR'=:B1)
  47 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='SE')
  48 - filter('HU'=:B1)
  50 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='SE')
  51 - filter('IT'=:B1)
  53 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='SE')
  54 - filter('IW'=:B1)
  56 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='SE')
  57 - filter('JA'=:B1)
  59 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='SE')
  60 - filter('LT'=:B1)
  62 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='SE')
  63 - filter('LV'=:B1)
  65 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='SE')
  66 - filter('MX'=:B1)
  68 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='SE')
  69 - filter('NL'=:B1)
  71 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='SE')
  72 - filter('NO'=:B1)
  74 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='SE')
  75 - filter('PL'=:B1)
  77 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='SE')
  78 - filter('PT'=:B1)
  80 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='SE')
  81 - filter('RO'=:B1)
  83 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='SE')
  84 - filter('RU'=:B1)
  86 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='SE')
  87 - filter('SK'=:B1)
  89 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='SE')
  90 - filter('SL'=:B1)
  92 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='SE')
  93 - filter('SR'=:B1)
  95 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='SE')
  96 - filter('SV'=:B1)
  98 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='SE')
  99 - filter('TR'=:B1)
 101 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='SE')
 102 - filter('US'=:B1)
 104 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='SE')
 105 - filter('VI'=:B1)
 107 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='SE')
 108 - filter('ZH'=:B1)
 110 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='SE')
 111 - access("E"."ALERTE_ID"=:B1)
 114 - filter('AL'=:B1)
 116 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='EC')
 117 - filter('AN'=:B1)
 119 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='EC')
 120 - filter('AR'=:B1)
 122 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='EC')
 123 - filter('BG'=:B1)
 125 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='EC')
 126 - filter('BR'=:B1)
 128 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='EC')
 129 - filter('CE'=:B1)
 131 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='EC')
 132 - filter('CH'=:B1)
 134 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='EC')
 135 - filter('CS'=:B1)
 137 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='EC')
 138 - filter('DA'=:B1)
 140 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='EC')
 141 - filter('EL'=:B1)
 143 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='EC')
 144 - filter('ES'=:B1)
 146 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='EC')
 147 - filter('ET'=:B1)
 149 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='EC')
 150 - filter('FI'=:B1)
 152 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='EC')
 153 - filter('FR'=:B1)
 155 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='EC')
 156 - filter('HR'=:B1)
 158 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='EC')
 159 - filter('HU'=:B1)
 161 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='EC')
 162 - filter('IT'=:B1)
 164 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='EC')
 165 - filter('IW'=:B1)
 167 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='EC')
 168 - filter('JA'=:B1)
 170 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='EC')
 171 - filter('LT'=:B1)
 173 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='EC')
 174 - filter('LV'=:B1)
 176 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='EC')
 177 - filter('MX'=:B1)
 179 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='EC')
 180 - filter('NL'=:B1)
 182 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='EC')
 183 - filter('NO'=:B1)
 185 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='EC')
 186 - filter('PL'=:B1)
 188 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='EC')
 189 - filter('PT'=:B1)
 191 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='EC')
 192 - filter('RO'=:B1)
 194 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='EC')
 195 - filter('RU'=:B1)
 197 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='EC')
 198 - filter('SK'=:B1)
 200 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='EC')
 201 - filter('SL'=:B1)
 203 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='EC')
 204 - filter('SR'=:B1)
 206 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='EC')
 207 - filter('SV'=:B1)
 209 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='EC')
 210 - filter('TR'=:B1)
 212 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='EC')
 213 - filter('US'=:B1)
 215 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='EC')
 216 - filter('VI'=:B1)
 218 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='EC')
 219 - filter('ZH'=:B1)
 221 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='EC')
 222 - access("E"."ALERTE_ID"=:B1)
 225 - filter('AL'=:B1)
 227 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='AF')
 228 - filter('AN'=:B1)
 230 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='AF')
 231 - filter('AR'=:B1)
 233 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='AF')
 234 - filter('BG'=:B1)
 236 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='AF')
 237 - filter('BR'=:B1)
 239 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='AF')
 240 - filter('CE'=:B1)
 242 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='AF')
 243 - filter('CH'=:B1)
 245 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='AF')
 246 - filter('CS'=:B1)
 248 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='AF')
 249 - filter('DA'=:B1)
 251 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='AF')
 252 - filter('EL'=:B1)
 254 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='AF')
 255 - filter('ES'=:B1)
 257 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='AF')
 258 - filter('ET'=:B1)
 260 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='AF')
 261 - filter('FI'=:B1)
 263 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='AF')
 264 - filter('FR'=:B1)
 266 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='AF')
 267 - filter('HR'=:B1)
 269 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='AF')
 270 - filter('HU'=:B1)
 272 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='AF')
 273 - filter('IT'=:B1)
 275 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='AF')
 276 - filter('IW'=:B1)
 278 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='AF')
 279 - filter('JA'=:B1)
 281 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='AF')
 282 - filter('LT'=:B1)
 284 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='AF')
 285 - filter('LV'=:B1)
 287 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='AF')
 288 - filter('MX'=:B1)
 290 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='AF')
 291 - filter('NL'=:B1)
 293 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='AF')
 294 - filter('NO'=:B1)
 296 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='AF')
 297 - filter('PL'=:B1)
 299 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='AF')
 300 - filter('PT'=:B1)
 302 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='AF')
 303 - filter('RO'=:B1)
 305 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='AF')
 306 - filter('RU'=:B1)
 308 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='AF')
 309 - filter('SK'=:B1)
 311 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='AF')
 312 - filter('SL'=:B1)
 314 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='AF')
 315 - filter('SR'=:B1)
 317 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='AF')
 318 - filter('SV'=:B1)
 320 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='AF')
 321 - filter('TR'=:B1)
 323 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='AF')
 324 - filter('US'=:B1)
 326 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='AF')
 327 - filter('VI'=:B1)
 329 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='AF')
 330 - filter('ZH'=:B1)
 332 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='AF')
 335 - filter("REFHIERARCHIE" IS NOT NULL)
 336 - access("ANCREFDOSS"=:B1)
 337 - access("REFDOSS"="REFHIERARCHIE")
 338 - filter("CATEGDOSS"='COMPTE DB CTR')
 339 - filter( IS NOT NULL)
 341 - access("CATEGDOSS"='COMPTE DB CTR')
 342 - filter("REFHIERARCHIE"=:B1)
 343 - access("ANCREFDOSS"=:B1)
 344 - access("ALERTE_ID"=:B1)
 348 - access("TD"."ALERTE_ID"=:B1)
 351 - filter('AL'=:B1)
 353 - access("TYPE"='DV_AGENDA_DETAILS' AND "ABREV"="TD"."TYPE_INFO")
 354 - filter('AN'=:B1)
 356 - access("TYPE"='DV_AGENDA_DETAILS' AND "ABREV"="TD"."TYPE_INFO")
 357 - filter('AR'=:B1)
 359 - access("TYPE"='DV_AGENDA_DETAILS' AND "ABREV"="TD"."TYPE_INFO")
 360 - filter('BG'=:B1)
 362 - access("TYPE"='DV_AGENDA_DETAILS' AND "ABREV"="TD"."TYPE_INFO")
 363 - filter('BR'=:B1)
 365 - access("TYPE"='DV_AGENDA_DETAILS' AND "ABREV"="TD"."TYPE_INFO")
 366 - filter('CE'=:B1)
 368 - access("TYPE"='DV_AGENDA_DETAILS' AND "ABREV"="TD"."TYPE_INFO")
 369 - filter('CH'=:B1)
 371 - access("TYPE"='DV_AGENDA_DETAILS' AND "ABREV"="TD"."TYPE_INFO")
 372 - filter('CS'=:B1)
 374 - access("TYPE"='DV_AGENDA_DETAILS' AND "ABREV"="TD"."TYPE_INFO")
 375 - filter('DA'=:B1)
 377 - access("TYPE"='DV_AGENDA_DETAILS' AND "ABREV"="TD"."TYPE_INFO")
 378 - filter('EL'=:B1)
 380 - access("TYPE"='DV_AGENDA_DETAILS' AND "ABREV"="TD"."TYPE_INFO")
 381 - filter('ES'=:B1)
 383 - access("TYPE"='DV_AGENDA_DETAILS' AND "ABREV"="TD"."TYPE_INFO")
 384 - filter('ET'=:B1)
 386 - access("TYPE"='DV_AGENDA_DETAILS' AND "ABREV"="TD"."TYPE_INFO")
 387 - filter('FI'=:B1)
 389 - access("TYPE"='DV_AGENDA_DETAILS' AND "ABREV"="TD"."TYPE_INFO")
 390 - filter('FR'=:B1)
 392 - access("TYPE"='DV_AGENDA_DETAILS' AND "ABREV"="TD"."TYPE_INFO")
 393 - filter('HR'=:B1)
 395 - access("TYPE"='DV_AGENDA_DETAILS' AND "ABREV"="TD"."TYPE_INFO")
 396 - filter('HU'=:B1)
 398 - access("TYPE"='DV_AGENDA_DETAILS' AND "ABREV"="TD"."TYPE_INFO")
 399 - filter('IT'=:B1)
 401 - access("TYPE"='DV_AGENDA_DETAILS' AND "ABREV"="TD"."TYPE_INFO")
 402 - filter('IW'=:B1)
 404 - access("TYPE"='DV_AGENDA_DETAILS' AND "ABREV"="TD"."TYPE_INFO")
 405 - filter('JA'=:B1)
 407 - access("TYPE"='DV_AGENDA_DETAILS' AND "ABREV"="TD"."TYPE_INFO")
 408 - filter('LT'=:B1)
 410 - access("TYPE"='DV_AGENDA_DETAILS' AND "ABREV"="TD"."TYPE_INFO")
 411 - filter('LV'=:B1)
 413 - access("TYPE"='DV_AGENDA_DETAILS' AND "ABREV"="TD"."TYPE_INFO")
 414 - filter('MX'=:B1)
 416 - access("TYPE"='DV_AGENDA_DETAILS' AND "ABREV"="TD"."TYPE_INFO")
 417 - filter('NL'=:B1)
 419 - access("TYPE"='DV_AGENDA_DETAILS' AND "ABREV"="TD"."TYPE_INFO")
 420 - filter('NO'=:B1)
 422 - access("TYPE"='DV_AGENDA_DETAILS' AND "ABREV"="TD"."TYPE_INFO")
 423 - filter('PL'=:B1)
 425 - access("TYPE"='DV_AGENDA_DETAILS' AND "ABREV"="TD"."TYPE_INFO")
 426 - filter('PT'=:B1)
 428 - access("TYPE"='DV_AGENDA_DETAILS' AND "ABREV"="TD"."TYPE_INFO")
 429 - filter('RO'=:B1)
 431 - access("TYPE"='DV_AGENDA_DETAILS' AND "ABREV"="TD"."TYPE_INFO")
 432 - filter('RU'=:B1)
 434 - access("TYPE"='DV_AGENDA_DETAILS' AND "ABREV"="TD"."TYPE_INFO")
 435 - filter('SK'=:B1)
 437 - access("TYPE"='DV_AGENDA_DETAILS' AND "ABREV"="TD"."TYPE_INFO")
 438 - filter('SL'=:B1)
 440 - access("TYPE"='DV_AGENDA_DETAILS' AND "ABREV"="TD"."TYPE_INFO")
 441 - filter('SR'=:B1)
 443 - access("TYPE"='DV_AGENDA_DETAILS' AND "ABREV"="TD"."TYPE_INFO")
 444 - filter('SV'=:B1)
 446 - access("TYPE"='DV_AGENDA_DETAILS' AND "ABREV"="TD"."TYPE_INFO")
 447 - filter('TR'=:B1)
 449 - access("TYPE"='DV_AGENDA_DETAILS' AND "ABREV"="TD"."TYPE_INFO")
 450 - filter('US'=:B1)
 452 - access("TYPE"='DV_AGENDA_DETAILS' AND "ABREV"="TD"."TYPE_INFO")
 453 - filter('VI'=:B1)
 455 - access("TYPE"='DV_AGENDA_DETAILS' AND "ABREV"="TD"."TYPE_INFO")
 456 - filter('ZH'=:B1)
 458 - access("TYPE"='DV_AGENDA_DETAILS' AND "ABREV"="TD"."TYPE_INFO")
 461 - filter("REFHIERARCHIE" IS NOT NULL)
 462 - access("ANCREFDOSS"=:B1)
 463 - access("REFDOSS"="REFHIERARCHIE")
 464 - filter("CATEGDOSS"='COMPTE DB CTR')
 465 - filter(ROWNUM=1)
 470 - filter("D2"."REFHIERARCHIE" IS NOT NULL)
 471 - access("D2"."ANCREFDOSS"=:B1)
 472 - filter("D1"."CATEGDOSS"='COMPTE DB CTR')
 473 - access("D1"."REFDOSS"="D2"."REFHIERARCHIE")
 474 - access("TI"."REFDOSS"="D1"."REFDOSS" AND "TI"."REFTYPE"='DB')
 475 - access("I"."REFINDIVIDU"="TI"."REFINDIVIDU")
 477 - filter(ROWNUM=1)
 482 - access("GD"."ANCREFDOSS"=:B1)
 483 - access("TI"."REFDOSS"="GD"."REFDOSS" AND "TI"."REFTYPE"='DB')
 484 - access("I"."REFINDIVIDU"="TI"."REFINDIVIDU")
 486 - filter("RNUM">=:B10)
 487 - filter(ROWNUM<=:B9)
 489 - filter(ROWNUM<=:B9)
 490 - filter(("TA"."REFFACTOR" IS NULL OR  IS NOT NULL))
 491 - filter(TO_DATE(TO_CHAR(TO_DATE(:B6,'YYYY-MM-DD'),'RRRRMMDD'),'RRRRMMDD')>=TO_DATE(TO_CHAR(TO_DATE(:B6,'YYYY-MM-DD'),'RRRRMMDD'),'RRRRMMD
              D'))
 497 - filter(UPPER(NVL("V"."VALEUR_TRAD","TA"."TYPENTITE")) LIKE UPPER(:B7))
 499 - access("GI"."REFINDIVIDU"="STR1")
 506 - filter((TRUNC(INTERNAL_FUNCTION("TA"."DTCREATION_DT"))>=TO_DATE(TO_CHAR(TO_DATE(:B6,'YYYY-MM-DD'),'RRRRMMDD'),'RRRRMMDD') AND
              TRUNC(INTERNAL_FUNCTION("TA"."DTCREATION_DT"))<=TO_DATE(TO_CHAR(TO_DATE(:B6,'YYYY-MM-DD'),'RRRRMMDD'),'RRRRMMDD')))
 507 - access("TA"."REFEXT" LIKE :B8)
       filter("TA"."REFEXT" LIKE :B8)
 508 - filter("ABREV6"='O')
 509 - access("VALEUR"="TA"."TYPENCOUR" AND "TYPE"='DV_AGENDA_NON_SE')
 511 - access("TA"."REFDOSS"="GD"."REFDOSS")
 513 - access("TA"."CATPERSO"="GP"."REFPERSO")
 514 - access("GP"."REFINDIVIDU"="GI"."REFINDIVIDU")
 520 - access("GIP"."REFINDIVIDU"=:B4 AND "GIP"."TYPE"='appel_nonse')
 524 - access("A"."JOUR"=TO_NUMBER(TO_CHAR(SYSDATE@!,'j')))
       filter("A"."REFPERSO" IS NOT NULL)
 525 - access("A"."REFPERSO"="P"."REFPERSO")
 526 - filter("P"."REFREMPL"=:B5)
 531 - filter('AL'=:B1)
 533 - access("TYPE"='DV_TYPE_APPEL' AND "ABREV"="TA"."TYPENTITE")
 534 - filter('AN'=:B1)
 536 - access("TYPE"='DV_TYPE_APPEL' AND "ABREV"="TA"."TYPENTITE")
 537 - filter('AR'=:B1)
 539 - access("TYPE"='DV_TYPE_APPEL' AND "ABREV"="TA"."TYPENTITE")
 540 - filter('BG'=:B1)
 542 - access("TYPE"='DV_TYPE_APPEL' AND "ABREV"="TA"."TYPENTITE")
 543 - filter('BR'=:B1)
 545 - access("TYPE"='DV_TYPE_APPEL' AND "ABREV"="TA"."TYPENTITE")
 546 - filter('CE'=:B1)
 548 - access("TYPE"='DV_TYPE_APPEL' AND "ABREV"="TA"."TYPENTITE")
 549 - filter('CH'=:B1)
 551 - access("TYPE"='DV_TYPE_APPEL' AND "ABREV"="TA"."TYPENTITE")
 552 - filter('CS'=:B1)
 554 - access("TYPE"='DV_TYPE_APPEL' AND "ABREV"="TA"."TYPENTITE")
 555 - filter('DA'=:B1)
 557 - access("TYPE"='DV_TYPE_APPEL' AND "ABREV"="TA"."TYPENTITE")
 558 - filter('EL'=:B1)
 560 - access("TYPE"='DV_TYPE_APPEL' AND "ABREV"="TA"."TYPENTITE")
 561 - filter('ES'=:B1)
 563 - access("TYPE"='DV_TYPE_APPEL' AND "ABREV"="TA"."TYPENTITE")
 564 - filter('ET'=:B1)
 566 - access("TYPE"='DV_TYPE_APPEL' AND "ABREV"="TA"."TYPENTITE")
 567 - filter('FI'=:B1)
 569 - access("TYPE"='DV_TYPE_APPEL' AND "ABREV"="TA"."TYPENTITE")
 570 - filter('FR'=:B1)
 572 - access("TYPE"='DV_TYPE_APPEL' AND "ABREV"="TA"."TYPENTITE")
 573 - filter('HR'=:B1)
 575 - access("TYPE"='DV_TYPE_APPEL' AND "ABREV"="TA"."TYPENTITE")
 576 - filter('HU'=:B1)
 578 - access("TYPE"='DV_TYPE_APPEL' AND "ABREV"="TA"."TYPENTITE")
 579 - filter('IT'=:B1)
 581 - access("TYPE"='DV_TYPE_APPEL' AND "ABREV"="TA"."TYPENTITE")
 582 - filter('IW'=:B1)
 584 - access("TYPE"='DV_TYPE_APPEL' AND "ABREV"="TA"."TYPENTITE")
 585 - filter('JA'=:B1)
 587 - access("TYPE"='DV_TYPE_APPEL' AND "ABREV"="TA"."TYPENTITE")
 588 - filter('LT'=:B1)
 590 - access("TYPE"='DV_TYPE_APPEL' AND "ABREV"="TA"."TYPENTITE")
 591 - filter('LV'=:B1)
 593 - access("TYPE"='DV_TYPE_APPEL' AND "ABREV"="TA"."TYPENTITE")
 594 - filter('MX'=:B1)
 596 - access("TYPE"='DV_TYPE_APPEL' AND "ABREV"="TA"."TYPENTITE")
 597 - filter('NL'=:B1)
 599 - access("TYPE"='DV_TYPE_APPEL' AND "ABREV"="TA"."TYPENTITE")
 600 - filter('NO'=:B1)
 602 - access("TYPE"='DV_TYPE_APPEL' AND "ABREV"="TA"."TYPENTITE")
 603 - filter('PL'=:B1)
 605 - access("TYPE"='DV_TYPE_APPEL' AND "ABREV"="TA"."TYPENTITE")
 606 - filter('PT'=:B1)
 608 - access("TYPE"='DV_TYPE_APPEL' AND "ABREV"="TA"."TYPENTITE")
 609 - filter('RO'=:B1)
 611 - access("TYPE"='DV_TYPE_APPEL' AND "ABREV"="TA"."TYPENTITE")
 612 - filter('RU'=:B1)
 614 - access("TYPE"='DV_TYPE_APPEL' AND "ABREV"="TA"."TYPENTITE")
 615 - filter('SK'=:B1)
 617 - access("TYPE"='DV_TYPE_APPEL' AND "ABREV"="TA"."TYPENTITE")
 618 - filter('SL'=:B1)
 620 - access("TYPE"='DV_TYPE_APPEL' AND "ABREV"="TA"."TYPENTITE")
 621 - filter('SR'=:B1)
 623 - access("TYPE"='DV_TYPE_APPEL' AND "ABREV"="TA"."TYPENTITE")
 624 - filter('SV'=:B1)
 626 - access("TYPE"='DV_TYPE_APPEL' AND "ABREV"="TA"."TYPENTITE")
 627 - filter('TR'=:B1)
 629 - access("TYPE"='DV_TYPE_APPEL' AND "ABREV"="TA"."TYPENTITE")
 630 - filter('US'=:B1)
 632 - access("TYPE"='DV_TYPE_APPEL' AND "ABREV"="TA"."TYPENTITE")
 633 - filter('VI'=:B1)
 635 - access("TYPE"='DV_TYPE_APPEL' AND "ABREV"="TA"."TYPENTITE")
 636 - filter('ZH'=:B1)
 638 - access("TYPE"='DV_TYPE_APPEL' AND "ABREV"="TA"."TYPENTITE")
 642 - access("T"."REFDOSS"="TA"."REFDOSS" AND "T"."REFTYPE"='CL')
 643 - access("I"."REFINDIVIDU"="T"."REFINDIVIDU")
 652 - access("G"."REFDOSS"="TA"."REFDOSS")
 653 - access("D"."TYPE"='categdoss' AND "D"."VALEUR"="G"."CATEGDOSS")
       filter(("D"."VALEUR"="G"."CATEGDOSS" AND "D"."ABREV" IS NOT NULL))
 654 - access("TI"."REFDOSS"="TA"."REFDOSS")
       filter("TI"."REFDOSS"="G"."REFDOSS")
 655 - filter("I"."REFTYPE_AFF"='CLI')
 656 - access("I"."CATEGDOSS"="D"."ABREV" AND "I"."REFTYPE_BD"="TI"."REFTYPE")
 657 - access("TI"."REFINDIVIDU"="GI"."REFINDIVIDU")
 663 - filter('AL'=:B1)
 665 - access("VALEUR"="TA"."TYPENCOUR" AND "TYPE"='DV_AGENDA_NON_SE')
 666 - filter('AN'=:B1)
 668 - access("VALEUR"="TA"."TYPENCOUR" AND "TYPE"='DV_AGENDA_NON_SE')
 669 - filter('AR'=:B1)
 671 - access("VALEUR"="TA"."TYPENCOUR" AND "TYPE"='DV_AGENDA_NON_SE')
 672 - filter('BG'=:B1)
 674 - access("VALEUR"="TA"."TYPENCOUR" AND "TYPE"='DV_AGENDA_NON_SE')
 675 - filter('BR'=:B1)
 677 - access("VALEUR"="TA"."TYPENCOUR" AND "TYPE"='DV_AGENDA_NON_SE')
 678 - filter('CE'=:B1)
 680 - access("VALEUR"="TA"."TYPENCOUR" AND "TYPE"='DV_AGENDA_NON_SE')
 681 - filter('CH'=:B1)
 683 - access("VALEUR"="TA"."TYPENCOUR" AND "TYPE"='DV_AGENDA_NON_SE')
 684 - filter('CS'=:B1)
 686 - access("VALEUR"="TA"."TYPENCOUR" AND "TYPE"='DV_AGENDA_NON_SE')
 687 - filter('DA'=:B1)
 689 - access("VALEUR"="TA"."TYPENCOUR" AND "TYPE"='DV_AGENDA_NON_SE')
 690 - filter('EL'=:B1)
 692 - access("VALEUR"="TA"."TYPENCOUR" AND "TYPE"='DV_AGENDA_NON_SE')
 693 - filter('ES'=:B1)
 695 - access("VALEUR"="TA"."TYPENCOUR" AND "TYPE"='DV_AGENDA_NON_SE')
 696 - filter('ET'=:B1)
 698 - access("VALEUR"="TA"."TYPENCOUR" AND "TYPE"='DV_AGENDA_NON_SE')
 699 - filter('FI'=:B1)
 701 - access("VALEUR"="TA"."TYPENCOUR" AND "TYPE"='DV_AGENDA_NON_SE')
 702 - filter('FR'=:B1)
 704 - access("VALEUR"="TA"."TYPENCOUR" AND "TYPE"='DV_AGENDA_NON_SE')
 705 - filter('HR'=:B1)
 707 - access("VALEUR"="TA"."TYPENCOUR" AND "TYPE"='DV_AGENDA_NON_SE')
 708 - filter('HU'=:B1)
 710 - access("VALEUR"="TA"."TYPENCOUR" AND "TYPE"='DV_AGENDA_NON_SE')
 711 - filter('IT'=:B1)
 713 - access("VALEUR"="TA"."TYPENCOUR" AND "TYPE"='DV_AGENDA_NON_SE')
 714 - filter('IW'=:B1)
 716 - access("VALEUR"="TA"."TYPENCOUR" AND "TYPE"='DV_AGENDA_NON_SE')
 717 - filter('JA'=:B1)
 719 - access("VALEUR"="TA"."TYPENCOUR" AND "TYPE"='DV_AGENDA_NON_SE')
 720 - filter('LT'=:B1)
 722 - access("VALEUR"="TA"."TYPENCOUR" AND "TYPE"='DV_AGENDA_NON_SE')
 723 - filter('LV'=:B1)
 725 - access("VALEUR"="TA"."TYPENCOUR" AND "TYPE"='DV_AGENDA_NON_SE')
 726 - filter('MX'=:B1)
 728 - access("VALEUR"="TA"."TYPENCOUR" AND "TYPE"='DV_AGENDA_NON_SE')
 729 - filter('NL'=:B1)
 731 - access("VALEUR"="TA"."TYPENCOUR" AND "TYPE"='DV_AGENDA_NON_SE')
 732 - filter('NO'=:B1)
 734 - access("VALEUR"="TA"."TYPENCOUR" AND "TYPE"='DV_AGENDA_NON_SE')
 735 - filter('PL'=:B1)
 737 - access("VALEUR"="TA"."TYPENCOUR" AND "TYPE"='DV_AGENDA_NON_SE')
 738 - filter('PT'=:B1)
 740 - access("VALEUR"="TA"."TYPENCOUR" AND "TYPE"='DV_AGENDA_NON_SE')
 741 - filter('RO'=:B1)
 743 - access("VALEUR"="TA"."TYPENCOUR" AND "TYPE"='DV_AGENDA_NON_SE')
 744 - filter('RU'=:B1)
 746 - access("VALEUR"="TA"."TYPENCOUR" AND "TYPE"='DV_AGENDA_NON_SE')
 747 - filter('SK'=:B1)
 749 - access("VALEUR"="TA"."TYPENCOUR" AND "TYPE"='DV_AGENDA_NON_SE')
 750 - filter('SL'=:B1)
 752 - access("VALEUR"="TA"."TYPENCOUR" AND "TYPE"='DV_AGENDA_NON_SE')
 753 - filter('SR'=:B1)
 755 - access("VALEUR"="TA"."TYPENCOUR" AND "TYPE"='DV_AGENDA_NON_SE')
 756 - filter('SV'=:B1)
 758 - access("VALEUR"="TA"."TYPENCOUR" AND "TYPE"='DV_AGENDA_NON_SE')
 759 - filter('TR'=:B1)
 761 - access("VALEUR"="TA"."TYPENCOUR" AND "TYPE"='DV_AGENDA_NON_SE')
 762 - filter('US'=:B1)
 764 - access("VALEUR"="TA"."TYPENCOUR" AND "TYPE"='DV_AGENDA_NON_SE')
 765 - filter('VI'=:B1)
 767 - access("VALEUR"="TA"."TYPENCOUR" AND "TYPE"='DV_AGENDA_NON_SE')
 768 - filter('ZH'=:B1)
 770 - access("VALEUR"="TA"."TYPENCOUR" AND "TYPE"='DV_AGENDA_NON_SE')
 775 - filter('AL'=:B1)
 777 - access("TYPE"='DEVISE' AND "ABREV"=CASE  WHEN ((:B3='FACTORING') AND ("GD"."REFFACTOR" IS NOT NULL) AND ("V1"."PLACE"=1)) THEN
              "FTR_FIN_FACTOR"."GETCURRENCY"("GD"."REFFACTOR") WHEN ("V1"."PLACE"=2) THEN "TA"."DEVISE_ALERTE" ELSE NVL("GD"."DEVISE","TA"."DEVISE_ALERTE")
              END )
 778 - filter('AN'=:B1)
 780 - access("TYPE"='DEVISE' AND "ABREV"=CASE  WHEN ((:B3='FACTORING') AND ("GD"."REFFACTOR" IS NOT NULL) AND ("V1"."PLACE"=1)) THEN
              "FTR_FIN_FACTOR"."GETCURRENCY"("GD"."REFFACTOR") WHEN ("V1"."PLACE"=2) THEN "TA"."DEVISE_ALERTE" ELSE NVL("GD"."DEVISE","TA"."DEVISE_ALERTE")
              END )
 781 - filter('AR'=:B1)
 783 - access("TYPE"='DEVISE' AND "ABREV"=CASE  WHEN ((:B3='FACTORING') AND ("GD"."REFFACTOR" IS NOT NULL) AND ("V1"."PLACE"=1)) THEN
              "FTR_FIN_FACTOR"."GETCURRENCY"("GD"."REFFACTOR") WHEN ("V1"."PLACE"=2) THEN "TA"."DEVISE_ALERTE" ELSE NVL("GD"."DEVISE","TA"."DEVISE_ALERTE")
              END )
 784 - filter('BG'=:B1)
 786 - access("TYPE"='DEVISE' AND "ABREV"=CASE  WHEN ((:B3='FACTORING') AND ("GD"."REFFACTOR" IS NOT NULL) AND ("V1"."PLACE"=1)) THEN
              "FTR_FIN_FACTOR"."GETCURRENCY"("GD"."REFFACTOR") WHEN ("V1"."PLACE"=2) THEN "TA"."DEVISE_ALERTE" ELSE NVL("GD"."DEVISE","TA"."DEVISE_ALERTE")
              END )
 787 - filter('BR'=:B1)
 789 - access("TYPE"='DEVISE' AND "ABREV"=CASE  WHEN ((:B3='FACTORING') AND ("GD"."REFFACTOR" IS NOT NULL) AND ("V1"."PLACE"=1)) THEN
              "FTR_FIN_FACTOR"."GETCURRENCY"("GD"."REFFACTOR") WHEN ("V1"."PLACE"=2) THEN "TA"."DEVISE_ALERTE" ELSE NVL("GD"."DEVISE","TA"."DEVISE_ALERTE")
              END )
 790 - filter('CE'=:B1)
 792 - access("TYPE"='DEVISE' AND "ABREV"=CASE  WHEN ((:B3='FACTORING') AND ("GD"."REFFACTOR" IS NOT NULL) AND ("V1"."PLACE"=1)) THEN
              "FTR_FIN_FACTOR"."GETCURRENCY"("GD"."REFFACTOR") WHEN ("V1"."PLACE"=2) THEN "TA"."DEVISE_ALERTE" ELSE NVL("GD"."DEVISE","TA"."DEVISE_ALERTE")
              END )
 793 - filter('CH'=:B1)
 795 - access("TYPE"='DEVISE' AND "ABREV"=CASE  WHEN ((:B3='FACTORING') AND ("GD"."REFFACTOR" IS NOT NULL) AND ("V1"."PLACE"=1)) THEN
              "FTR_FIN_FACTOR"."GETCURRENCY"("GD"."REFFACTOR") WHEN ("V1"."PLACE"=2) THEN "TA"."DEVISE_ALERTE" ELSE NVL("GD"."DEVISE","TA"."DEVISE_ALERTE")
              END )
 796 - filter('CS'=:B1)
 798 - access("TYPE"='DEVISE' AND "ABREV"=CASE  WHEN ((:B3='FACTORING') AND ("GD"."REFFACTOR" IS NOT NULL) AND ("V1"."PLACE"=1)) THEN
              "FTR_FIN_FACTOR"."GETCURRENCY"("GD"."REFFACTOR") WHEN ("V1"."PLACE"=2) THEN "TA"."DEVISE_ALERTE" ELSE NVL("GD"."DEVISE","TA"."DEVISE_ALERTE")
              END )
 799 - filter('DA'=:B1)
 801 - access("TYPE"='DEVISE' AND "ABREV"=CASE  WHEN ((:B3='FACTORING') AND ("GD"."REFFACTOR" IS NOT NULL) AND ("V1"."PLACE"=1)) THEN
              "FTR_FIN_FACTOR"."GETCURRENCY"("GD"."REFFACTOR") WHEN ("V1"."PLACE"=2) THEN "TA"."DEVISE_ALERTE" ELSE NVL("GD"."DEVISE","TA"."DEVISE_ALERTE")
              END )
 802 - filter('EL'=:B1)
 804 - access("TYPE"='DEVISE' AND "ABREV"=CASE  WHEN ((:B3='FACTORING') AND ("GD"."REFFACTOR" IS NOT NULL) AND ("V1"."PLACE"=1)) THEN
              "FTR_FIN_FACTOR"."GETCURRENCY"("GD"."REFFACTOR") WHEN ("V1"."PLACE"=2) THEN "TA"."DEVISE_ALERTE" ELSE NVL("GD"."DEVISE","TA"."DEVISE_ALERTE")
              END )
 805 - filter('ES'=:B1)
 807 - access("TYPE"='DEVISE' AND "ABREV"=CASE  WHEN ((:B3='FACTORING') AND ("GD"."REFFACTOR" IS NOT NULL) AND ("V1"."PLACE"=1)) THEN
              "FTR_FIN_FACTOR"."GETCURRENCY"("GD"."REFFACTOR") WHEN ("V1"."PLACE"=2) THEN "TA"."DEVISE_ALERTE" ELSE NVL("GD"."DEVISE","TA"."DEVISE_ALERTE")
              END )
 808 - filter('ET'=:B1)
 810 - access("TYPE"='DEVISE' AND "ABREV"=CASE  WHEN ((:B3='FACTORING') AND ("GD"."REFFACTOR" IS NOT NULL) AND ("V1"."PLACE"=1)) THEN
              "FTR_FIN_FACTOR"."GETCURRENCY"("GD"."REFFACTOR") WHEN ("V1"."PLACE"=2) THEN "TA"."DEVISE_ALERTE" ELSE NVL("GD"."DEVISE","TA"."DEVISE_ALERTE")
              END )
 811 - filter('FI'=:B1)
 813 - access("TYPE"='DEVISE' AND "ABREV"=CASE  WHEN ((:B3='FACTORING') AND ("GD"."REFFACTOR" IS NOT NULL) AND ("V1"."PLACE"=1)) THEN
              "FTR_FIN_FACTOR"."GETCURRENCY"("GD"."REFFACTOR") WHEN ("V1"."PLACE"=2) THEN "TA"."DEVISE_ALERTE" ELSE NVL("GD"."DEVISE","TA"."DEVISE_ALERTE")
              END )
 814 - filter('FR'=:B1)
 816 - access("TYPE"='DEVISE' AND "ABREV"=CASE  WHEN ((:B3='FACTORING') AND ("GD"."REFFACTOR" IS NOT NULL) AND ("V1"."PLACE"=1)) THEN
              "FTR_FIN_FACTOR"."GETCURRENCY"("GD"."REFFACTOR") WHEN ("V1"."PLACE"=2) THEN "TA"."DEVISE_ALERTE" ELSE NVL("GD"."DEVISE","TA"."DEVISE_ALERTE")
              END )
 817 - filter('HR'=:B1)
 819 - access("TYPE"='DEVISE' AND "ABREV"=CASE  WHEN ((:B3='FACTORING') AND ("GD"."REFFACTOR" IS NOT NULL) AND ("V1"."PLACE"=1)) THEN
              "FTR_FIN_FACTOR"."GETCURRENCY"("GD"."REFFACTOR") WHEN ("V1"."PLACE"=2) THEN "TA"."DEVISE_ALERTE" ELSE NVL("GD"."DEVISE","TA"."DEVISE_ALERTE")
              END )
 820 - filter('HU'=:B1)
 822 - access("TYPE"='DEVISE' AND "ABREV"=CASE  WHEN ((:B3='FACTORING') AND ("GD"."REFFACTOR" IS NOT NULL) AND ("V1"."PLACE"=1)) THEN
              "FTR_FIN_FACTOR"."GETCURRENCY"("GD"."REFFACTOR") WHEN ("V1"."PLACE"=2) THEN "TA"."DEVISE_ALERTE" ELSE NVL("GD"."DEVISE","TA"."DEVISE_ALERTE")
              END )
 823 - filter('IT'=:B1)
 825 - access("TYPE"='DEVISE' AND "ABREV"=CASE  WHEN ((:B3='FACTORING') AND ("GD"."REFFACTOR" IS NOT NULL) AND ("V1"."PLACE"=1)) THEN
              "FTR_FIN_FACTOR"."GETCURRENCY"("GD"."REFFACTOR") WHEN ("V1"."PLACE"=2) THEN "TA"."DEVISE_ALERTE" ELSE NVL("GD"."DEVISE","TA"."DEVISE_ALERTE")
              END )
 826 - filter('IW'=:B1)
 828 - access("TYPE"='DEVISE' AND "ABREV"=CASE  WHEN ((:B3='FACTORING') AND ("GD"."REFFACTOR" IS NOT NULL) AND ("V1"."PLACE"=1)) THEN
              "FTR_FIN_FACTOR"."GETCURRENCY"("GD"."REFFACTOR") WHEN ("V1"."PLACE"=2) THEN "TA"."DEVISE_ALERTE" ELSE NVL("GD"."DEVISE","TA"."DEVISE_ALERTE")
              END )
 829 - filter('JA'=:B1)
 831 - access("TYPE"='DEVISE' AND "ABREV"=CASE  WHEN ((:B3='FACTORING') AND ("GD"."REFFACTOR" IS NOT NULL) AND ("V1"."PLACE"=1)) THEN
              "FTR_FIN_FACTOR"."GETCURRENCY"("GD"."REFFACTOR") WHEN ("V1"."PLACE"=2) THEN "TA"."DEVISE_ALERTE" ELSE NVL("GD"."DEVISE","TA"."DEVISE_ALERTE")
              END )
 832 - filter('LT'=:B1)
 834 - access("TYPE"='DEVISE' AND "ABREV"=CASE  WHEN ((:B3='FACTORING') AND ("GD"."REFFACTOR" IS NOT NULL) AND ("V1"."PLACE"=1)) THEN
              "FTR_FIN_FACTOR"."GETCURRENCY"("GD"."REFFACTOR") WHEN ("V1"."PLACE"=2) THEN "TA"."DEVISE_ALERTE" ELSE NVL("GD"."DEVISE","TA"."DEVISE_ALERTE")
              END )
 835 - filter('LV'=:B1)
 837 - access("TYPE"='DEVISE' AND "ABREV"=CASE  WHEN ((:B3='FACTORING') AND ("GD"."REFFACTOR" IS NOT NULL) AND ("V1"."PLACE"=1)) THEN
              "FTR_FIN_FACTOR"."GETCURRENCY"("GD"."REFFACTOR") WHEN ("V1"."PLACE"=2) THEN "TA"."DEVISE_ALERTE" ELSE NVL("GD"."DEVISE","TA"."DEVISE_ALERTE")
              END )
 838 - filter('MX'=:B1)
 840 - access("TYPE"='DEVISE' AND "ABREV"=CASE  WHEN ((:B3='FACTORING') AND ("GD"."REFFACTOR" IS NOT NULL) AND ("V1"."PLACE"=1)) THEN
              "FTR_FIN_FACTOR"."GETCURRENCY"("GD"."REFFACTOR") WHEN ("V1"."PLACE"=2) THEN "TA"."DEVISE_ALERTE" ELSE NVL("GD"."DEVISE","TA"."DEVISE_ALERTE")
              END )
 841 - filter('NL'=:B1)
 843 - access("TYPE"='DEVISE' AND "ABREV"=CASE  WHEN ((:B3='FACTORING') AND ("GD"."REFFACTOR" IS NOT NULL) AND ("V1"."PLACE"=1)) THEN
              "FTR_FIN_FACTOR"."GETCURRENCY"("GD"."REFFACTOR") WHEN ("V1"."PLACE"=2) THEN "TA"."DEVISE_ALERTE" ELSE NVL("GD"."DEVISE","TA"."DEVISE_ALERTE")
              END )
 844 - filter('NO'=:B1)
 846 - access("TYPE"='DEVISE' AND "ABREV"=CASE  WHEN ((:B3='FACTORING') AND ("GD"."REFFACTOR" IS NOT NULL) AND ("V1"."PLACE"=1)) THEN
              "FTR_FIN_FACTOR"."GETCURRENCY"("GD"."REFFACTOR") WHEN ("V1"."PLACE"=2) THEN "TA"."DEVISE_ALERTE" ELSE NVL("GD"."DEVISE","TA"."DEVISE_ALERTE")
              END )
 847 - filter('PL'=:B1)
 849 - access("TYPE"='DEVISE' AND "ABREV"=CASE  WHEN ((:B3='FACTORING') AND ("GD"."REFFACTOR" IS NOT NULL) AND ("V1"."PLACE"=1)) THEN
              "FTR_FIN_FACTOR"."GETCURRENCY"("GD"."REFFACTOR") WHEN ("V1"."PLACE"=2) THEN "TA"."DEVISE_ALERTE" ELSE NVL("GD"."DEVISE","TA"."DEVISE_ALERTE")
              END )
 850 - filter('PT'=:B1)
 852 - access("TYPE"='DEVISE' AND "ABREV"=CASE  WHEN ((:B3='FACTORING') AND ("GD"."REFFACTOR" IS NOT NULL) AND ("V1"."PLACE"=1)) THEN
              "FTR_FIN_FACTOR"."GETCURRENCY"("GD"."REFFACTOR") WHEN ("V1"."PLACE"=2) THEN "TA"."DEVISE_ALERTE" ELSE NVL("GD"."DEVISE","TA"."DEVISE_ALERTE")
              END )
 853 - filter('RO'=:B1)
 855 - access("TYPE"='DEVISE' AND "ABREV"=CASE  WHEN ((:B3='FACTORING') AND ("GD"."REFFACTOR" IS NOT NULL) AND ("V1"."PLACE"=1)) THEN
              "FTR_FIN_FACTOR"."GETCURRENCY"("GD"."REFFACTOR") WHEN ("V1"."PLACE"=2) THEN "TA"."DEVISE_ALERTE" ELSE NVL("GD"."DEVISE","TA"."DEVISE_ALERTE")
              END )
 856 - filter('RU'=:B1)
 858 - access("TYPE"='DEVISE' AND "ABREV"=CASE  WHEN ((:B3='FACTORING') AND ("GD"."REFFACTOR" IS NOT NULL) AND ("V1"."PLACE"=1)) THEN
              "FTR_FIN_FACTOR"."GETCURRENCY"("GD"."REFFACTOR") WHEN ("V1"."PLACE"=2) THEN "TA"."DEVISE_ALERTE" ELSE NVL("GD"."DEVISE","TA"."DEVISE_ALERTE")
              END )
 859 - filter('SK'=:B1)
 861 - access("TYPE"='DEVISE' AND "ABREV"=CASE  WHEN ((:B3='FACTORING') AND ("GD"."REFFACTOR" IS NOT NULL) AND ("V1"."PLACE"=1)) THEN
              "FTR_FIN_FACTOR"."GETCURRENCY"("GD"."REFFACTOR") WHEN ("V1"."PLACE"=2) THEN "TA"."DEVISE_ALERTE" ELSE NVL("GD"."DEVISE","TA"."DEVISE_ALERTE")
              END )
 862 - filter('SL'=:B1)
 864 - access("TYPE"='DEVISE' AND "ABREV"=CASE  WHEN ((:B3='FACTORING') AND ("GD"."REFFACTOR" IS NOT NULL) AND ("V1"."PLACE"=1)) THEN
              "FTR_FIN_FACTOR"."GETCURRENCY"("GD"."REFFACTOR") WHEN ("V1"."PLACE"=2) THEN "TA"."DEVISE_ALERTE" ELSE NVL("GD"."DEVISE","TA"."DEVISE_ALERTE")
              END )
 865 - filter('SR'=:B1)
 867 - access("TYPE"='DEVISE' AND "ABREV"=CASE  WHEN ((:B3='FACTORING') AND ("GD"."REFFACTOR" IS NOT NULL) AND ("V1"."PLACE"=1)) THEN
              "FTR_FIN_FACTOR"."GETCURRENCY"("GD"."REFFACTOR") WHEN ("V1"."PLACE"=2) THEN "TA"."DEVISE_ALERTE" ELSE NVL("GD"."DEVISE","TA"."DEVISE_ALERTE")
              END )
 868 - filter('SV'=:B1)
 870 - access("TYPE"='DEVISE' AND "ABREV"=CASE  WHEN ((:B3='FACTORING') AND ("GD"."REFFACTOR" IS NOT NULL) AND ("V1"."PLACE"=1)) THEN
              "FTR_FIN_FACTOR"."GETCURRENCY"("GD"."REFFACTOR") WHEN ("V1"."PLACE"=2) THEN "TA"."DEVISE_ALERTE" ELSE NVL("GD"."DEVISE","TA"."DEVISE_ALERTE")
              END )
 871 - filter('TR'=:B1)
 873 - access("TYPE"='DEVISE' AND "ABREV"=CASE  WHEN ((:B3='FACTORING') AND ("GD"."REFFACTOR" IS NOT NULL) AND ("V1"."PLACE"=1)) THEN
              "FTR_FIN_FACTOR"."GETCURRENCY"("GD"."REFFACTOR") WHEN ("V1"."PLACE"=2) THEN "TA"."DEVISE_ALERTE" ELSE NVL("GD"."DEVISE","TA"."DEVISE_ALERTE")
              END )
 874 - filter('US'=:B1)
 876 - access("TYPE"='DEVISE' AND "ABREV"=CASE  WHEN ((:B3='FACTORING') AND ("GD"."REFFACTOR" IS NOT NULL) AND ("V1"."PLACE"=1)) THEN
              "FTR_FIN_FACTOR"."GETCURRENCY"("GD"."REFFACTOR") WHEN ("V1"."PLACE"=2) THEN "TA"."DEVISE_ALERTE" ELSE NVL("GD"."DEVISE","TA"."DEVISE_ALERTE")
              END )
 877 - filter('VI'=:B1)
 879 - access("TYPE"='DEVISE' AND "ABREV"=CASE  WHEN ((:B3='FACTORING') AND ("GD"."REFFACTOR" IS NOT NULL) AND ("V1"."PLACE"=1)) THEN
              "FTR_FIN_FACTOR"."GETCURRENCY"("GD"."REFFACTOR") WHEN ("V1"."PLACE"=2) THEN "TA"."DEVISE_ALERTE" ELSE NVL("GD"."DEVISE","TA"."DEVISE_ALERTE")
              END )
 880 - filter('ZH'=:B1)
 882 - access("TYPE"='DEVISE' AND "ABREV"=CASE  WHEN ((:B3='FACTORING') AND ("GD"."REFFACTOR" IS NOT NULL) AND ("V1"."PLACE"=1)) THEN
              "FTR_FIN_FACTOR"."GETCURRENCY"("GD"."REFFACTOR") WHEN ("V1"."PLACE"=2) THEN "TA"."DEVISE_ALERTE" ELSE NVL("GD"."DEVISE","TA"."DEVISE_ALERTE")
              END )
 887 - filter('AL'=:B1)
 889 - access("VALEUR"="GP"."GROUPE" AND "TYPE"='GROUPE')
 890 - filter('AN'=:B1)
 892 - access("VALEUR"="GP"."GROUPE" AND "TYPE"='GROUPE')
 893 - filter('AR'=:B1)
 895 - access("VALEUR"="GP"."GROUPE" AND "TYPE"='GROUPE')
 896 - filter('BG'=:B1)
 898 - access("VALEUR"="GP"."GROUPE" AND "TYPE"='GROUPE')
 899 - filter('BR'=:B1)
 901 - access("VALEUR"="GP"."GROUPE" AND "TYPE"='GROUPE')
 902 - filter('CE'=:B1)
 904 - access("VALEUR"="GP"."GROUPE" AND "TYPE"='GROUPE')
 905 - filter('CH'=:B1)
 907 - access("VALEUR"="GP"."GROUPE" AND "TYPE"='GROUPE')
 908 - filter('CS'=:B1)
 910 - access("VALEUR"="GP"."GROUPE" AND "TYPE"='GROUPE')
 911 - filter('DA'=:B1)
 913 - access("VALEUR"="GP"."GROUPE" AND "TYPE"='GROUPE')
 914 - filter('EL'=:B1)
 916 - access("VALEUR"="GP"."GROUPE" AND "TYPE"='GROUPE')
 917 - filter('ES'=:B1)
 919 - access("VALEUR"="GP"."GROUPE" AND "TYPE"='GROUPE')
 920 - filter('ET'=:B1)
 922 - access("VALEUR"="GP"."GROUPE" AND "TYPE"='GROUPE')
 923 - filter('FI'=:B1)
 925 - access("VALEUR"="GP"."GROUPE" AND "TYPE"='GROUPE')
 926 - filter('FR'=:B1)
 928 - access("VALEUR"="GP"."GROUPE" AND "TYPE"='GROUPE')
 929 - filter('HR'=:B1)
 931 - access("VALEUR"="GP"."GROUPE" AND "TYPE"='GROUPE')
 932 - filter('HU'=:B1)
 934 - access("VALEUR"="GP"."GROUPE" AND "TYPE"='GROUPE')
 935 - filter('IT'=:B1)
 937 - access("VALEUR"="GP"."GROUPE" AND "TYPE"='GROUPE')
 938 - filter('IW'=:B1)
 940 - access("VALEUR"="GP"."GROUPE" AND "TYPE"='GROUPE')
 941 - filter('JA'=:B1)
 943 - access("VALEUR"="GP"."GROUPE" AND "TYPE"='GROUPE')
 944 - filter('LT'=:B1)
 946 - access("VALEUR"="GP"."GROUPE" AND "TYPE"='GROUPE')
 947 - filter('LV'=:B1)
 949 - access("VALEUR"="GP"."GROUPE" AND "TYPE"='GROUPE')
 950 - filter('MX'=:B1)
 952 - access("VALEUR"="GP"."GROUPE" AND "TYPE"='GROUPE')
 953 - filter('NL'=:B1)
 955 - access("VALEUR"="GP"."GROUPE" AND "TYPE"='GROUPE')
 956 - filter('NO'=:B1)
 958 - access("VALEUR"="GP"."GROUPE" AND "TYPE"='GROUPE')
 959 - filter('PL'=:B1)
 961 - access("VALEUR"="GP"."GROUPE" AND "TYPE"='GROUPE')
 962 - filter('PT'=:B1)
 964 - access("VALEUR"="GP"."GROUPE" AND "TYPE"='GROUPE')
 965 - filter('RO'=:B1)
 967 - access("VALEUR"="GP"."GROUPE" AND "TYPE"='GROUPE')
 968 - filter('RU'=:B1)
 970 - access("VALEUR"="GP"."GROUPE" AND "TYPE"='GROUPE')
 971 - filter('SK'=:B1)
 973 - access("VALEUR"="GP"."GROUPE" AND "TYPE"='GROUPE')
 974 - filter('SL'=:B1)
 976 - access("VALEUR"="GP"."GROUPE" AND "TYPE"='GROUPE')
 977 - filter('SR'=:B1)
 979 - access("VALEUR"="GP"."GROUPE" AND "TYPE"='GROUPE')
 980 - filter('SV'=:B1)
 982 - access("VALEUR"="GP"."GROUPE" AND "TYPE"='GROUPE')
 983 - filter('TR'=:B1)
 985 - access("VALEUR"="GP"."GROUPE" AND "TYPE"='GROUPE')
 986 - filter('US'=:B1)
 988 - access("VALEUR"="GP"."GROUPE" AND "TYPE"='GROUPE')
 989 - filter('VI'=:B1)
 991 - access("VALEUR"="GP"."GROUPE" AND "TYPE"='GROUPE')
 992 - filter('ZH'=:B1)
 994 - access("VALEUR"="GP"."GROUPE" AND "TYPE"='GROUPE')
 997 - access("F"."REFINDIVIDU"=:B1)
 998 - access("G"."REFMANGRP"="F"."REFMANGRP")
 999 - access("C"."REFPERSO"=:B5 AND "C"."REFMANGRP"="G"."REFMANGRP")
*/
/********************************New Metrics***************************************/

/********************************Index statistics**********************************/

/********************************Other SQLs****************************************/          
/*

*/ 
/********************************Other SQLs****************************************/              
