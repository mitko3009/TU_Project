/********************************************************************************
*********       E-mail subject: IMBWEB-7690
*********             Instance: PROD
*********          Description: 
Problem:
Slowness in msgq_chkcess on IMB PROD.

Analysis:
From the analyze of msgq_chkcess on PORD, we found two SQLs ( 6mshk24m2csk3 and 4gsya325nky4y) that can be optimized.
The problem in both of them is accessing table G_PIECE through inappropriate index. Table G_PIECE should be accessed through
column REFPIECE in SQL 6mshk24m2csk3 and through column REFPIECE in SQL 4gsya325nky4y, so we should add hints to do it.
In SQL 6mshk24m2csk3 also we don't see the purpose of table G_GROUPINDIV, so please check is it functionally correct to remove it as it is shown in the New SQL section below.

Suggestion:
Please add hints and check if SQL 6mshk24m2csk3 can be changed as it is shown in the New SQL section below.

*********               SQL_ID: 6mshk24m2csk3, 4gsya325nky4y 
*********      Program/Package: eligibility_controls.pck
*********              Request: Dimitare Ivanov
*********               Author: Dimitar Dimitrov
********* Received e-mail date: 06/03/2024
*********      Resolution date: 07/03/2024
*********  Trace old file here: \\epox\specifs\performance\tmp\
*********  Trace new file here:
***********************************************************************************/

/********************************OLD SQL*******************************************/
--6mshk24m2csk3 

SELECT G.REFGROUPE GROUP_REF,
       XMLELEMENT("table",
                  (SELECT XMLAGG(XMLELEMENT("record",
                                            XMLFOREST(P.REFEXT AS
                                                      "limit_level",
                                                      P.REFPIECE AS "limit_id",
                                                      D.IMX_UN_ID AS
                                                      "limit_detail_id",
                                                      D.TX01 / 100 AS
                                                      "limit_rate",
                                                      D.DT01_DT AS "start_date",
                                                      D.DT02_DT AS "end_date",
                                                      NVL(P.GPICPENREG, 'MIX') AS
                                                      "portfolio_type",
                                                      P.GPITYPTRIB AS "bu_ref",
                                                      P.GPIBUREAU AS
                                                      "client_ref")))
                     FROM G_PIECE P, G_PIECEDET D
                    WHERE P.TYPPIECE = 'PARAM_LIMITE'
                      AND P.GPIDEPOT = 'COR'
                      AND NVL(P.FG01, 'N') != 'O'
                      AND P.REFEXT = 'IND'
                      AND P.GPIROLE = G.REFGROUPE
                      AND D.REFPIECE = P.REFPIECE)) CONCENTRATION_LIMITS
  FROM G_GROUPINDIV G
 WHERE G.REFGROUPE IN (SELECT COLUMN_VALUE FROM TABLE(:B1));

-- 4gsya325nky4y 

SELECT D.DEVISE CURRENCY,
       D.CATEGDOSS CATEGORY,
       A.NB67 FUNDING_ELIGIBILITY_TERM,
       A.NB69 MAX_TENOR,
       A.NB08 MAX_TERM_OF_PAYMENT,
       A.NB83 MAX_TERM_OF_PAYMENT_CDD,
       A.NB22 MIN_TERM_OF_PAYMENT,
       (SELECT DECODE(MIN(FR.MT01), 0, 0, MIN(FR.MT01) / 100)
          FROM G_PIECEDET FR
         WHERE FR.REFPIECE = A.REFPIECE
           AND FR.TYPE = 'FINRATE'
           AND :B2 BETWEEN TRUNC(NVL(DT01_DT, :B2)) AND
               TRUNC(NVL(DT02_DT, :B2))) MIN_FINANCING_RATE,
       XMLELEMENT("table",
                  (SELECT /*+ index(P (GPIMARQUE)) */
                    XMLAGG(XMLELEMENT("record",
                                      XMLFOREST(P.REFEXT AS "limit_level",
                                                P.REFPIECE AS "limit_id",
                                                D.IMX_UN_ID AS
                                                "limit_detail_id",
                                                D.TX01 / 100 AS "limit_rate",
                                                D.DT01_DT AS "start_date",
                                                D.DT02_DT AS "end_date",
                                                NVL(P.GPICPENREG, 'MIX') AS
                                                "portfolio_type",
                                                P.GPITYPTRIB AS "bu_ref",
                                                P.GPIBUREAU AS "client_ref")))
                     FROM G_PIECE P, G_PIECEDET D
                    WHERE P.TYPPIECE = 'PARAM_LIMITE'
                      AND P.GPIDEPOT = 'COR'
                      AND NVL(P.FG01, 'N') != 'O'
                      AND P.REFEXT = 'COM'
                      AND P.GPIBUREAU = :B4
                      AND P.GPIMARQUE = :B3
                      AND D.REFPIECE = P.REFPIECE)) CONCENTRATION_LIMITS,
       A.NB20 RANDOM_SOUNDING_PERCENTAGE,
       A.MT61 RANDOM_SOUNDING_THRESHOLD,
       XMLELEMENT("table",
                  (SELECT /*+ index(P (GPIMARQUE)) */
                    XMLAGG(XMLELEMENT("record",
                                      XMLFOREST(P.REFPIECE AS
                                                "limit_reference",
                                                P.GPIDEPOT AS "limit_type",
                                                R.MT02 AS "limit_amount")))
                     FROM G_PIECE P, G_PIECE R
                    WHERE P.TYPPIECE = 'PARAM_LIMITE'
                      AND P.REFEXT = 'COM'
                      AND P.GPIBUREAU = :B4
                      AND P.GPIMARQUE = :B3
                      AND P.GPITYPTRIB = :B5
                      AND R.REFPIECE = P.STR_20_1
                      AND R.TYPPIECE = 'REQUEST_LIMITE'
                      AND R.FG05 = 'O')) APPROVED_LIMITS_COM,
       NVL(A.FG85, 'N') SPECIAL_RELATIONSHIP,
       NVL(A.FG83, 'N') LEGAL_NOTIF_NOT_RECEIVED,
       A.FG38 SILENT,
       A.MT21 IMPORTANT_INVOICE_THRESHOLD,
       (SELECT MIN(E.DTDEBUT_DT)
          FROM G_ELEMFI E
         WHERE E.ACTIF = 'O'
           AND E.REFDOSS = D.REFDOSS) OLDEST_OPEN_DUE_DATE,
       A.NB21 OVERDUE_DISAPPROVAL_NEW_INV,
       A.MT17 INVOICE_VALIDITY_PERIOD,
       A.LIBELLE_20_13 TRANSPORT_DOC_TYPE,
       A.LIBELLE_20_8 CREDIT_PERIOD_TYPE,
       A.LIBELLE_20_9 DUE_DATE_FROM,
       XMLELEMENT("table",
                  (SELECT XMLAGG(XMLELEMENT("record",
                                            XMLFOREST(STAT_TYPE AS "stat_type",
                                                      CASE
                                                        WHEN STAT_TYPE IN ('INV_AVG_AMT', 'PINV_AVG_AMT') THEN
                                                         SUM(STAT_AMOUNT)
                                                        ELSE
                                                         MAX(STAT_AMOUNT)
                                                      END AS "stat_amount")))
                     FROM (SELECT STAT_TYPE,
                                  CASE
                                    WHEN STAT_TYPE IN
                                         ('INV_AVG_AMT', 'PINV_AVG_AMT') THEN
                                     STAT_NUMBER / SUM(STAT_NUMBER)
                                     OVER(PARTITION BY STAT_TYPE) * STAT_AMOUNT
                                    ELSE
                                     MAX(STAT_AMOUNT)
                                     OVER(PARTITION BY STAT_TYPE)
                                  END STAT_AMOUNT
                             FROM STAT_MEMO_EOD
                            WHERE REFDOSS = D.REFDOSS
                              AND STAT_TYPE IN ('INV_AVG_AMT',
                                                'INV_MAX_AMT',
                                                'PINV_AVG_AMT',
                                                'PINV_MAX_AMT')
                              AND CALCUL_DT BETWEEN
                                  ADD_MONTHS(TRUNC(:B2, 'MONTH'), -12) AND
                                  LAST_DAY(TRUNC(:B2, 'MONTH')))
                    GROUP BY STAT_TYPE)) AVG_MAX_INV_AMOUNTS,
       A.MT83 AVERAGE_INVOICE_AMOUNT,
       A.NB82 AVERAGE_INVOICE_PERENTAGE,
       A.MT84 MAX_INVOICE_AMOUNT,
       A.NB77 HIGH_LIMIT_UTILIZATION_RATE,
       (SELECT /*+ leading(r) use_nl(p) index(r PIE_GPILIBLIBRE) */
        DISTINCT FIRST_VALUE(R.MT02) OVER(ORDER BY R.DT_CREATION_DT DESC)
          FROM G_PIECE P, G_PIECE R
         WHERE P.TYPPIECE = 'PARAM_LIMITE'
           AND R.TYPPIECE = 'REQUEST_LIMITE'
           AND R.LIBELLE_20_12 = P.REFPIECE
           AND P.GPIDEPOT = 'FIN'
           AND P.REFEXT = 'COM'
           AND R.FG05 = 'O'
           AND R.GPILIBLIBRE LIKE 'L1.' || :B3 || '.' || :B4 || '.' || :B5 || '%') LAST_APPROVED_LIMIT_F_COM_AMT
  FROM G_DOSSIER D, G_PIECE A
 WHERE A.TYPPIECE = D.PIECEINIT
   AND A.REFDOSS = D.REFDOSS
   AND D.REFDOSS = :B1;

/********************************OLD SQL*******************************************/
/********************************OLD Metrics***************************************/
/*
MODULE                           SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL           PERC
-------------------------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
msgq_chkcess                                                                    ON CPU               2024/03/06 12:00:20  2024/03/06 15:55:46        1073             23398186 +000000000 03:55:26.217 12%
msgq                                                                            ON CPU               2024/03/06 12:00:58  2024/03/06 15:58:30        1039             17213072 +000000000 03:57:31.903 12%
                                                                                ON CPU               2024/03/06 12:00:09  2024/03/06 15:59:26        1009             17328808 +000000000 03:59:16.416 11%
SQL*Plus                         1y06ahwzq0upa 3938725563                       enq: TX - row lock c 2024/03/06 12:00:09  2024/03/06 12:41:31         582             16777218 +000000000 00:41:21.793 7%
msgq_report                                                                     cell single block ph 2024/03/06 12:12:28  2024/03/06 14:36:59         565             16777225 +000000000 02:24:31.496 6%


MODULE                           SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL           PERC
-------------------------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
msgq_chkcess                                                                    ON CPU               2024/03/06 12:00:20  2024/03/06 15:55:46        1073             23398186 +000000000 03:55:26.217 86%
msgq_chkcess                                                                    cell single block ph 2024/03/06 12:03:11  2024/03/06 15:55:56          47             16989068 +000000000 03:52:45.184 4%
msgq_chkcess                                                     884      28796 PX Deq: Join ACK     2024/03/06 12:03:52  2024/03/06 13:50:40          35               107993 +000000000 01:46:48.128 3%
msgq_chkcess                                                                    enq: PS - contention 2024/03/06 13:07:36  2024/03/06 13:49:18          19                78780 +000000000 00:41:41.696 2%
msgq_chkcess                                                                    PX Deq: Slave Sessio 2024/03/06 12:05:24  2024/03/06 13:45:33          17                37590 +000000000 01:40:08.384 1%
msgq_chkcess                                                                    gc cr block 2-way    2024/03/06 12:17:56  2024/03/06 15:41:25          10             16792160 +000000000 03:23:28.968 1%
msgq_chkcess                                                     884      28796 reliable message     2024/03/06 12:05:24  2024/03/06 13:50:51          10                93625 +000000000 01:45:26.208 1%


MODULE                           PROGRAM                                            SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                  ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                 PERC
-------------------------------- -------------------------------------------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
msgq_chkcess                     msg_q02                                                                            884      28796                      2024/03/06 12:03:11  2024/03/06 15:55:56     749              6373751 +000000000 03:52:45.184 60%
msgq_chkcess                     msg_q05                                                                           1896      18410                      2024/03/06 12:00:40  2024/03/06 13:26:28     160              6620969 +000000000 01:25:47.712 13%
msgq_chkcess                     oracle                                                                                                                 2024/03/06 12:03:52  2024/03/06 13:50:40      57               103363 +000000000 01:46:48.128 5%
msgq_chkcess                     msg_q11                                                                                                                2024/03/06 12:10:25  2024/03/06 14:29:07      56             17801499 +000000000 02:18:42.504 4%
msgq_chkcess                     msg_q06                                                                                                                2024/03/06 12:15:19  2024/03/06 15:26:02      47             16839375 +000000000 03:10:42.624 4%
msgq_chkcess                     oracle                                                                                                                 2024/03/06 12:04:16  2024/03/06 13:46:38      39                90401 +000000000 01:42:22.144 3%
msgq_chkcess                     msg_q03                                                                                                                2024/03/06 12:00:20  2024/03/06 15:32:15      32             16803132 +000000000 03:31:55.648 3%
msgq_chkcess                     msg_q09                                                                           1400      39845                      2024/03/06 12:50:31  2024/03/06 12:58:02      25              1285054 +000000000 00:07:30.945 2%
msgq_chkcess                     msg_q12                                                                                                                2024/03/06 12:17:25  2024/03/06 15:49:26      22             22109007 +000000000 03:32:01.417 2%
msgq_chkcess                     msg_q10                                                                                                                2024/03/06 13:19:34  2024/03/06 14:34:39      14             16853681 +000000000 01:15:04.951 1%
msgq_chkcess                     msg_q08                                                                                                                2024/03/06 12:49:44  2024/03/06 15:19:22      12             16896180 +000000000 02:29:38.120 1%
msgq_chkcess                     msg_queue                                                                                                              2024/03/06 12:41:07  2024/03/06 14:33:17      11             16806431 +000000000 01:52:10.103 1%
msgq_chkcess                     msg_q04                                                                                                                2024/03/06 12:03:01  2024/03/06 13:53:35      10                 9473 +000000000 01:50:33.792 1%
msgq_chkcess                     oracle                                                                                                                 2024/03/06 12:10:42  2024/03/06 13:45:12       9                70263 +000000000 01:34:30.080 1%
msgq_chkcess                     oracle                                                                    0       1889            enq: PS - contention 2024/03/06 13:37:34  2024/03/06 13:38:15       2                      +000000000 00:00:40.960 0%
msgq_chkcess                     msg_q07                                            0h0j3r534j41x 1608423733       1881      41969 cell single block ph 2024/03/06 14:16:59  2024/03/06 14:16:59       1                    1 +000000000 00:00:00.000 0%



MODULE                           SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL           PERC
-------------------------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
msgq_chkcess                     9fyzycp9a53r3 4145146419        884      28796 ON CPU               2024/03/06 12:04:13  2024/03/06 15:48:35          62              1311667 +000000000 03:44:22.272 8%
msgq_chkcess                     93bwzfxswwruw  850208434        884      28796 ON CPU               2024/03/06 14:04:31  2024/03/06 15:46:53          48                 9459 +000000000 01:42:22.016 6%
msgq_chkcess                     4gsya325nky4y 1514805201        884      28796 ON CPU               2024/03/06 12:48:38  2024/03/06 12:55:59          44                 1110 +000000000 00:07:21.088 6%
msgq_chkcess                     4yt6p8wvy6s4z          0        884      28796                      2024/03/06 12:48:28  2024/03/06 13:51:01          37                    1 +000000000 01:02:32.897 5%
msgq_chkcess                     cajzhqufxymz0 1039665909        884      28796 ON CPU               2024/03/06 13:03:30  2024/03/06 13:49:08          36                15208 +000000000 00:45:37.601 5%
msgq_chkcess                     cz4rmm6x7800j 2952248063        884      28796                      2024/03/06 12:16:21  2024/03/06 13:50:30          31                93799 +000000000 01:34:09.600 4%
msgq_chkcess                     g7mug6shmfrdm 2952248063        884      28796                      2024/03/06 12:03:52  2024/03/06 13:50:51          30                95040 +000000000 01:46:58.368 4%


MODULE                           SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL           PERC
-------------------------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
msgq_chkcess                                            0                                            2024/03/06 12:02:33  2024/03/06 15:30:43          95                    1 +000000000 03:28:10.367 8%
msgq_chkcess                     9fyzycp9a53r3 4145146419                       ON CPU               2024/03/06 12:04:13  2024/03/06 15:48:35          81             21532845 +000000000 03:44:22.272 7%
msgq_chkcess                     7uua6gvdqnk3j 2900873134                                            2024/03/06 12:18:47  2024/03/06 15:53:43          65             16778879 +000000000 03:34:55.496 5%
msgq_chkcess                     4gsya325nky4y 1514805201                                            2024/03/06 12:17:25  2024/03/06 14:54:14          54             16779799 +000000000 02:36:49.544 4%
msgq_chkcess                     93bwzfxswwruw  850208434                       ON CPU               2024/03/06 12:58:57  2024/03/06 15:46:53          52             16783421 +000000000 02:47:55.784 4%
msgq_chkcess                     6mshk24m2csk3 1869278382                                            2024/03/06 12:03:01  2024/03/06 15:32:42          52             16777240 +000000000 03:29:40.800 4%
msgq_chkcess                     g7mug6shmfrdm                                                       2024/03/06 12:03:52  2024/03/06 13:50:51          49                95040 +000000000 01:46:58.368 4%


INSTANCE_NUMBER SQL_ID            ELAPSED MAX_WAIT_ON     PC_OF  WAIT_TIME            GETS      READS       ROWS  ELAP/EXEC       GETS/EXEC READS/EXEC  ROWS/EXEC       EXEC PLAN_HASH_VALUE
--------------- ------------- ----------- --------------- ----- ---------- --------------- ---------- ---------- ---------- --------------- ---------- ---------- ---------- ---------------
              1 4gsya325nky4y         495 CPU             98%   475.209746       166132698      59972       1155        .43          143838      51.92          1       1155      1514805201
              2 4gsya325nky4y          62 CPU             77%    63.550383        14816624     127943        498        .12           29752     256.91          1        498      1514805201
              1 6mshk24m2csk3         400 CPU             89%   398.742354       246038498     147922        200       18.2        11183568    6723.73       9.09         22      1869278382
              2 6mshk24m2csk3         368 CPU             78%   372.784491       183090550     272914        150       9.95         4948393    7376.05       4.05         37      1869278382
              2 7uua6gvdqnk3j         490 CPU             83%   545.087734         6413913     303206      17507        .23            2963     140.05       8.09       2165      2900873134
              1 7uua6gvdqnk3j         301 CPU             82%   315.893639         7618578     172686      88709        .17            4244       96.2      49.42       1795      2900873134
              1 93bwzfxswwruw         485 CPU             100%   468.33209        28311361       1486         30        .05            2889        .15          0       9799       850208434
              2 93bwzfxswwruw          67 CPU             100%   64.331302         3385693         17          0        .04            1801        .01          0       1880       850208434
              1 9fyzycp9a53r3        1079 CPU             100%  967.279911              80          0    1970112          0               0          0          1    1970141      4145146419
              2 9fyzycp9a53r3         257 CPU             100%   228.24868             863          9     488717          0               0          0          1     488732      4145146419
              1 g7mug6shmfrdm         617 CPU             100%  360.876386               0          0     120427        .01               0          0          1     120427      2952248063
              2 g7mug6shmfrdm         121 CPU             100%   94.255626              92          0      14358        .01               0          0          1      14358      2952248063


-- 6mshk24m2csk3 

SQL_ID        SQL_PLAN_HASH_VALUE SQL_PLAN_LINE_ID SQL_PLAN_OPERATION             SQL_PLAN_OPTIONS                   ACTIVE
------------- ------------------- ---------------- ------------------------------ ------------------------------ ----------
6mshk24m2csk3          1869278382                4 TABLE ACCESS                   BY INDEX ROWID BATCHED                 53
6mshk24m2csk3          1869278382                5 INDEX                          RANGE SCAN                              6

Plan hash value: 1869278382
-----------------------------------------------------------------------------------------------------------
| Id  | Operation                              | Name             | Rows  | Bytes | Cost (%CPU)| Time     |
-----------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                       |                  |       |       |    32 (100)|          |
|   1 |  SORT AGGREGATE                        |                  |     1 |    69 |            |          |
|   2 |   NESTED LOOPS                         |                  |     1 |    69 |     2   (0)| 00:00:01 |
|   3 |    NESTED LOOPS                        |                  |     9 |    69 |     2   (0)| 00:00:01 |
|   4 |     TABLE ACCESS BY INDEX ROWID BATCHED| G_PIECE          |     1 |    44 |     1   (0)| 00:00:01 |
|   5 |      INDEX RANGE SCAN                  | PIECE_REFEXT_IDX |     1 |       |     1   (0)| 00:00:01 |
|   6 |     INDEX RANGE SCAN                   | G_PIECEDET_REFP  |     9 |       |     1   (0)| 00:00:01 |
|   7 |    TABLE ACCESS BY INDEX ROWID         | G_PIECEDET       |     9 |   225 |     1   (0)| 00:00:01 |
|   8 |  HASH JOIN RIGHT SEMI                  |                  |     1 |    11 |    30   (0)| 00:00:01 |
|   9 |   COLLECTION ITERATOR PICKLER FETCH    |                  |     1 |     2 |    29   (0)| 00:00:01 |
|  10 |   INDEX FULL SCAN                      | PK_G_GROUPINDIV  |  4066 | 36594 |     1   (0)| 00:00:01 |
-----------------------------------------------------------------------------------------------------------

-- 4gsya325nky4y

SQL_ID        SQL_PLAN_HASH_VALUE SQL_PLAN_LINE_ID SQL_PLAN_OPERATION             SQL_PLAN_OPTIONS                   ACTIVE
------------- ------------------- ---------------- ------------------------------ ------------------------------ ----------
4gsya325nky4y          1514805201               34 TABLE ACCESS                   BY INDEX ROWID                         52
4gsya325nky4y          1514805201               33 INDEX                          RANGE SCAN                              4
 

Plan hash value: 1514805201
-------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                | Name                   | Rows  | Bytes | Cost (%CPU)| Time     |
-------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                         |                        |       |       |    14 (100)|          |
|   1 |  SORT AGGREGATE                          |                        |     1 |    36 |            |          |
|   2 |   INDEX RANGE SCAN                       | G_PIECEDET_REFP        |     1 |    36 |     1   (0)| 00:00:01 |
|   3 |  SORT AGGREGATE                          |                        |     1 |    68 |            |          |
|   4 |   NESTED LOOPS                           |                        |     1 |    68 |     2   (0)| 00:00:01 |
|   5 |    NESTED LOOPS                          |                        |     8 |    68 |     2   (0)| 00:00:01 |
|   6 |     TABLE ACCESS BY INDEX ROWID BATCHED  | G_PIECE                |     1 |    43 |     1   (0)| 00:00:01 |
|   7 |      INDEX RANGE SCAN                    | REFVIGN                |     6 |       |     1   (0)| 00:00:01 |
|   8 |     INDEX RANGE SCAN                     | G_PIECEDET_REFP        |     8 |       |     1   (0)| 00:00:01 |
|   9 |    TABLE ACCESS BY INDEX ROWID           | G_PIECEDET             |     8 |   200 |     1   (0)| 00:00:01 |
|  10 |  SORT AGGREGATE                          |                        |     1 |    66 |            |          |
|  11 |   NESTED LOOPS                           |                        |     1 |    66 |     2   (0)| 00:00:01 |
|  12 |    NESTED LOOPS                          |                        |     1 |    66 |     2   (0)| 00:00:01 |
|  13 |     TABLE ACCESS BY INDEX ROWID BATCHED  | G_PIECE                |     1 |    41 |     1   (0)| 00:00:01 |
|  14 |      INDEX RANGE SCAN                    | REFVIGN                |     6 |       |     1   (0)| 00:00:01 |
|  15 |     INDEX RANGE SCAN                     | PIE_REFPIECE           |     1 |       |     1   (0)| 00:00:01 |
|  16 |    TABLE ACCESS BY INDEX ROWID           | G_PIECE                |     1 |    25 |     1   (0)| 00:00:01 |
|  17 |  SORT AGGREGATE                          |                        |     1 |    21 |            |          |
|  18 |   TABLE ACCESS BY INDEX ROWID BATCHED    | G_ELEMFI               |     3 |    63 |     1   (0)| 00:00:01 |
|  19 |    INDEX RANGE SCAN                      | G_ELEMFI$REFDOSS_ACTIF |     3 |       |     1   (0)| 00:00:01 |
|  20 |  SORT AGGREGATE                          |                        |     1 |    19 |     2  (50)| 00:00:01 |
|  21 |   SORT GROUP BY                          |                        |     1 |    19 |     2  (50)| 00:00:01 |
|  22 |    VIEW                                  |                        |     1 |    19 |     2  (50)| 00:00:01 |
|  23 |     WINDOW SORT                          |                        |     1 |    41 |     2  (50)| 00:00:01 |
|  24 |      FILTER                              |                        |       |       |            |          |
|  25 |       TABLE ACCESS BY INDEX ROWID BATCHED| STAT_MEMO_EOD          |     1 |    41 |     1   (0)| 00:00:01 |
|  26 |        INDEX RANGE SCAN                  | IDX_STAT_MEMO_REFDOSS  |    11 |       |     1   (0)| 00:00:01 |
|  27 |  HASH UNIQUE                             |                        |     1 |    64 |     4  (50)| 00:00:01 |
|  28 |   WINDOW SORT                            |                        |     1 |    64 |     4  (50)| 00:00:01 |
|  29 |    NESTED LOOPS                          |                        |     1 |    64 |     2   (0)| 00:00:01 |
|  30 |     NESTED LOOPS                         |                        |     1 |    64 |     2   (0)| 00:00:01 |
|  31 |      TABLE ACCESS BY INDEX ROWID BATCHED | G_PIECE                |     1 |    33 |     1   (0)| 00:00:01 |
|  32 |       INDEX RANGE SCAN                   | PIE_GPILIBLIBRE        |    17 |       |     1   (0)| 00:00:01 |
|  33 |      INDEX RANGE SCAN                    | PIECE_REFEXT_IDX       |     1 |       |     1   (0)| 00:00:01 |
|  34 |     TABLE ACCESS BY INDEX ROWID          | G_PIECE                |     1 |    31 |     1   (0)| 00:00:01 |
|  35 |  NESTED LOOPS                            |                        |     1 |   277 |     2   (0)| 00:00:01 |
|  36 |   TABLE ACCESS BY INDEX ROWID            | G_DOSSIER              |     1 |    31 |     1   (0)| 00:00:01 |
|  37 |    INDEX UNIQUE SCAN                     | DOS_REFDOSS            |     1 |       |     1   (0)| 00:00:01 |
|  38 |   TABLE ACCESS BY INDEX ROWID BATCHED    | G_PIECE                |     1 |   246 |     1   (0)| 00:00:01 |
|  39 |    INDEX RANGE SCAN                      | PIE_REFDOSS            |     1 |       |     1   (0)| 00:00:01 |
-------------------------------------------------------------------------------------------------------------------


*/
/********************************OLD Metrics***************************************/

/********************************New SQL*******************************************/

-- 6mshk24m2csk3

SELECT G.COLUMN_VALUE GROUP_REF,
       XMLELEMENT("table",
                  (SELECT /*+ index(P G_PIECE$ID_VENTE) */
                          XMLAGG(XMLELEMENT("record",
                                            XMLFOREST(P.REFEXT AS
                                                      "limit_level",
                                                      P.REFPIECE AS "limit_id",
                                                      D.IMX_UN_ID AS
                                                      "limit_detail_id",
                                                      D.TX01 / 100 AS
                                                      "limit_rate",
                                                      D.DT01_DT AS "start_date",
                                                      D.DT02_DT AS "end_date",
                                                      NVL(P.GPICPENREG, 'MIX') AS
                                                      "portfolio_type",
                                                      P.GPITYPTRIB AS "bu_ref",
                                                      P.GPIBUREAU AS
                                                      "client_ref")))
                     FROM G_PIECE P, G_PIECEDET D
                    WHERE P.TYPPIECE = 'PARAM_LIMITE'
                      AND P.GPIDEPOT = 'COR'
                      AND NVL(P.FG01, 'N') != 'O'
                      AND P.REFEXT = 'IND'
                      AND P.GPIROLE = G.COLUMN_VALUE
                      AND D.REFPIECE = P.REFPIECE)) CONCENTRATION_LIMITS
  FROM TABLE(:B1) G;

-- 4gsya325nky4y

SELECT D.DEVISE CURRENCY,
       D.CATEGDOSS CATEGORY,
       A.NB67 FUNDING_ELIGIBILITY_TERM,
       A.NB69 MAX_TENOR,
       A.NB08 MAX_TERM_OF_PAYMENT,
       A.NB83 MAX_TERM_OF_PAYMENT_CDD,
       A.NB22 MIN_TERM_OF_PAYMENT,
       (SELECT DECODE(MIN(FR.MT01), 0, 0, MIN(FR.MT01) / 100)
          FROM G_PIECEDET FR
         WHERE FR.REFPIECE = A.REFPIECE
           AND FR.TYPE = 'FINRATE'
           AND :B2 BETWEEN TRUNC(NVL(DT01_DT, :B2)) AND
               TRUNC(NVL(DT02_DT, :B2))) MIN_FINANCING_RATE,
       XMLELEMENT("table",
                  (SELECT /*+ index(P (GPIMARQUE)) */
                    XMLAGG(XMLELEMENT("record",
                                      XMLFOREST(P.REFEXT AS "limit_level",
                                                P.REFPIECE AS "limit_id",
                                                D.IMX_UN_ID AS
                                                "limit_detail_id",
                                                D.TX01 / 100 AS "limit_rate",
                                                D.DT01_DT AS "start_date",
                                                D.DT02_DT AS "end_date",
                                                NVL(P.GPICPENREG, 'MIX') AS
                                                "portfolio_type",
                                                P.GPITYPTRIB AS "bu_ref",
                                                P.GPIBUREAU AS "client_ref")))
                     FROM G_PIECE P, G_PIECEDET D
                    WHERE P.TYPPIECE = 'PARAM_LIMITE'
                      AND P.GPIDEPOT = 'COR'
                      AND NVL(P.FG01, 'N') != 'O'
                      AND P.REFEXT = 'COM'
                      AND P.GPIBUREAU = :B4
                      AND P.GPIMARQUE = :B3
                      AND D.REFPIECE = P.REFPIECE)) CONCENTRATION_LIMITS,
       A.NB20 RANDOM_SOUNDING_PERCENTAGE,
       A.MT61 RANDOM_SOUNDING_THRESHOLD,
       XMLELEMENT("table",
                  (SELECT /*+ index(P (GPIMARQUE)) */
                    XMLAGG(XMLELEMENT("record",
                                      XMLFOREST(P.REFPIECE AS
                                                "limit_reference",
                                                P.GPIDEPOT AS "limit_type",
                                                R.MT02 AS "limit_amount")))
                     FROM G_PIECE P, G_PIECE R
                    WHERE P.TYPPIECE = 'PARAM_LIMITE'
                      AND P.REFEXT = 'COM'
                      AND P.GPIBUREAU = :B4
                      AND P.GPIMARQUE = :B3
                      AND P.GPITYPTRIB = :B5
                      AND R.REFPIECE = P.STR_20_1
                      AND R.TYPPIECE = 'REQUEST_LIMITE'
                      AND R.FG05 = 'O')) APPROVED_LIMITS_COM,
       NVL(A.FG85, 'N') SPECIAL_RELATIONSHIP,
       NVL(A.FG83, 'N') LEGAL_NOTIF_NOT_RECEIVED,
       A.FG38 SILENT,
       A.MT21 IMPORTANT_INVOICE_THRESHOLD,
       (SELECT MIN(E.DTDEBUT_DT)
          FROM G_ELEMFI E
         WHERE E.ACTIF = 'O'
           AND E.REFDOSS = D.REFDOSS) OLDEST_OPEN_DUE_DATE,
       A.NB21 OVERDUE_DISAPPROVAL_NEW_INV,
       A.MT17 INVOICE_VALIDITY_PERIOD,
       A.LIBELLE_20_13 TRANSPORT_DOC_TYPE,
       A.LIBELLE_20_8 CREDIT_PERIOD_TYPE,
       A.LIBELLE_20_9 DUE_DATE_FROM,
       XMLELEMENT("table",
                  (SELECT XMLAGG(XMLELEMENT("record",
                                            XMLFOREST(STAT_TYPE AS "stat_type",
                                                      CASE
                                                        WHEN STAT_TYPE IN ('INV_AVG_AMT', 'PINV_AVG_AMT') THEN
                                                         SUM(STAT_AMOUNT)
                                                        ELSE
                                                         MAX(STAT_AMOUNT)
                                                      END AS "stat_amount")))
                     FROM (SELECT STAT_TYPE,
                                  CASE
                                    WHEN STAT_TYPE IN
                                         ('INV_AVG_AMT', 'PINV_AVG_AMT') THEN
                                     STAT_NUMBER / SUM(STAT_NUMBER)
                                     OVER(PARTITION BY STAT_TYPE) * STAT_AMOUNT
                                    ELSE
                                     MAX(STAT_AMOUNT)
                                     OVER(PARTITION BY STAT_TYPE)
                                  END STAT_AMOUNT
                             FROM STAT_MEMO_EOD
                            WHERE REFDOSS = D.REFDOSS
                              AND STAT_TYPE IN ('INV_AVG_AMT',
                                                'INV_MAX_AMT',
                                                'PINV_AVG_AMT',
                                                'PINV_MAX_AMT')
                              AND CALCUL_DT BETWEEN
                                  ADD_MONTHS(TRUNC(:B2, 'MONTH'), -12) AND
                                  LAST_DAY(TRUNC(:B2, 'MONTH')))
                    GROUP BY STAT_TYPE)) AVG_MAX_INV_AMOUNTS,
       A.MT83 AVERAGE_INVOICE_AMOUNT,
       A.NB82 AVERAGE_INVOICE_PERENTAGE,
       A.MT84 MAX_INVOICE_AMOUNT,
       A.NB77 HIGH_LIMIT_UTILIZATION_RATE,
       (SELECT /*+ leading(r) use_nl(p) index(r PIE_GPILIBLIBRE) index(p PIE_REFPIECE) */
        DISTINCT FIRST_VALUE(R.MT02) OVER(ORDER BY R.DT_CREATION_DT DESC)
          FROM G_PIECE P, G_PIECE R
         WHERE P.TYPPIECE = 'PARAM_LIMITE'
           AND R.TYPPIECE = 'REQUEST_LIMITE'
           AND R.LIBELLE_20_12 = P.REFPIECE
           AND P.GPIDEPOT = 'FIN'
           AND P.REFEXT = 'COM'
           AND R.FG05 = 'O'
           AND R.GPILIBLIBRE LIKE 'L1.' || :B3 || '.' || :B4 || '.' || :B5 || '%') LAST_APPROVED_LIMIT_F_COM_AMT
  FROM G_DOSSIER D, G_PIECE A
 WHERE A.TYPPIECE = D.PIECEINIT
   AND A.REFDOSS = D.REFDOSS
   AND D.REFDOSS = :B1;
/********************************New SQL*******************************************/
/********************************New Metrics***************************************/
/*
-- 6mshk24m2csk3

Plan hash value: 716031928
--------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                              | Name              | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  |
--------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                       |                   |      1 |        |   540 (100)|      1 |00:00:00.01 |      97 |      0 |
|   1 |  SORT AGGREGATE                        |                   |      1 |      1 |            |      1 |00:00:00.01 |    3441 |     13 |
|   2 |   NESTED LOOPS                         |                   |      1 |      1 |     2   (0)|      0 |00:00:00.01 |    3441 |     13 |
|   3 |    NESTED LOOPS                        |                   |      1 |      8 |     2   (0)|      0 |00:00:00.01 |    3441 |     13 |
|*  4 |     TABLE ACCESS BY INDEX ROWID BATCHED| G_PIECE           |      1 |      1 |     1   (0)|      0 |00:00:00.01 |    3441 |     13 |
|*  5 |      INDEX RANGE SCAN                  | G_PIECE$ID_VENTE  |      1 |      3 |     1   (0)|   1726 |00:00:00.01 |      15 |     13 |
|*  6 |     INDEX RANGE SCAN                   | G_PIECEDET_REFP   |      0 |      8 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|   7 |    TABLE ACCESS BY INDEX ROWID         | G_PIECEDET        |      0 |      8 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|   8 |  COLLECTION ITERATOR PICKLER FETCH     | SHOW_INVOICE_LIST |      1 |   8168 |    29   (0)|      1 |00:00:00.01 |      97 |      0 |
--------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   4 - filter(("P"."REFEXT"='IND' AND "P"."GPIDEPOT"='COR' AND NVL("P"."FG01",'N')<>'O'))
   5 - access("P"."GPIROLE"=:B1 AND "P"."TYPPIECE"='PARAM_LIMITE')
   6 - access("D"."REFPIECE"="P"."REFPIECE")

-- 4gsya325nky4y

Plan hash value: 3408031939
------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                | Name                   | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers |
------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                         |                        |      1 |        |    14 (100)|      1 |00:00:00.01 |      13 |
|   1 |  SORT AGGREGATE                          |                        |      1 |      1 |            |      1 |00:00:00.01 |       4 |
|*  2 |   INDEX RANGE SCAN                       | G_PIECEDET_REFP        |      1 |      1 |     1   (0)|      0 |00:00:00.01 |       4 |
|   3 |  SORT AGGREGATE                          |                        |      1 |      1 |            |      1 |00:00:00.01 |      42 |
|   4 |   NESTED LOOPS                           |                        |      1 |      1 |     2   (0)|      0 |00:00:00.01 |      42 |
|   5 |    NESTED LOOPS                          |                        |      1 |      8 |     2   (0)|      0 |00:00:00.01 |      42 |
|*  6 |     TABLE ACCESS BY INDEX ROWID BATCHED  | G_PIECE                |      1 |      1 |     1   (0)|      0 |00:00:00.01 |      42 |
|*  7 |      INDEX RANGE SCAN                    | REFVIGN                |      1 |      6 |     1   (0)|     21 |00:00:00.01 |       3 |
|*  8 |     INDEX RANGE SCAN                     | G_PIECEDET_REFP        |      0 |      8 |     1   (0)|      0 |00:00:00.01 |       0 |
|   9 |    TABLE ACCESS BY INDEX ROWID           | G_PIECEDET             |      0 |      8 |     1   (0)|      0 |00:00:00.01 |       0 |
|  10 |  SORT AGGREGATE                          |                        |      1 |      1 |            |      1 |00:00:00.01 |     124 |
|  11 |   NESTED LOOPS                           |                        |      1 |      1 |     2   (0)|      3 |00:00:00.01 |     124 |
|  12 |    NESTED LOOPS                          |                        |      1 |      1 |     2   (0)|     16 |00:00:00.01 |      97 |
|* 13 |     TABLE ACCESS BY INDEX ROWID BATCHED  | G_PIECE                |      1 |      1 |     1   (0)|     16 |00:00:00.01 |      63 |
|* 14 |      INDEX RANGE SCAN                    | REFVIGN                |      1 |      6 |     1   (0)|     21 |00:00:00.01 |       3 |
|* 15 |     INDEX RANGE SCAN                     | PIE_REFPIECE           |     16 |      1 |     1   (0)|     16 |00:00:00.01 |      34 |
|* 16 |    TABLE ACCESS BY INDEX ROWID           | G_PIECE                |     16 |      1 |     1   (0)|      3 |00:00:00.01 |      27 |
|  17 |  SORT AGGREGATE                          |                        |      1 |      1 |            |      1 |00:00:00.01 |       5 |
|  18 |   TABLE ACCESS BY INDEX ROWID BATCHED    | G_ELEMFI               |      1 |      2 |     1   (0)|      1 |00:00:00.01 |       5 |
|* 19 |    INDEX RANGE SCAN                      | G_ELEMFI$REFDOSS_ACTIF |      1 |      2 |     1   (0)|      1 |00:00:00.01 |       4 |
|  20 |  SORT AGGREGATE                          |                        |      1 |      1 |     2  (50)|      1 |00:00:00.01 |      17 |
|  21 |   SORT GROUP BY                          |                        |      1 |      1 |     2  (50)|      0 |00:00:00.01 |      17 |
|  22 |    VIEW                                  |                        |      1 |      9 |     2  (50)|      0 |00:00:00.01 |      17 |
|  23 |     WINDOW SORT                          |                        |      1 |      9 |     2  (50)|      0 |00:00:00.01 |      17 |
|* 24 |      FILTER                              |                        |      1 |        |            |      0 |00:00:00.01 |      17 |
|* 25 |       TABLE ACCESS BY INDEX ROWID BATCHED| STAT_MEMO_EOD          |      1 |      9 |     1   (0)|      0 |00:00:00.01 |      17 |
|* 26 |        INDEX RANGE SCAN                  | IDX_STAT_MEMO_REFDOSS  |      1 |     14 |     1   (0)|     14 |00:00:00.01 |       3 |
|  27 |  HASH UNIQUE                             |                        |      1 |      1 |     4  (50)|      1 |00:00:00.01 |      45 |
|  28 |   WINDOW SORT                            |                        |      1 |      1 |     4  (50)|      1 |00:00:00.01 |      45 |
|  29 |    NESTED LOOPS                          |                        |      1 |      1 |     2   (0)|      1 |00:00:00.01 |      45 |
|  30 |     NESTED LOOPS                         |                        |      1 |      1 |     2   (0)|      3 |00:00:00.01 |      39 |
|* 31 |      TABLE ACCESS BY INDEX ROWID BATCHED | G_PIECE                |      1 |      1 |     1   (0)|      3 |00:00:00.01 |      31 |
|* 32 |       INDEX RANGE SCAN                   | PIE_GPILIBLIBRE        |      1 |     18 |     1   (0)|     16 |00:00:00.01 |       3 |
|* 33 |      INDEX RANGE SCAN                    | PIE_REFPIECE           |      3 |      1 |     1   (0)|      3 |00:00:00.01 |       8 |
|* 34 |     TABLE ACCESS BY INDEX ROWID          | G_PIECE                |      3 |      1 |     1   (0)|      1 |00:00:00.01 |       6 |
|  35 |  NESTED LOOPS                            |                        |      1 |      2 |     2   (0)|      1 |00:00:00.01 |      13 |
|  36 |   TABLE ACCESS BY INDEX ROWID            | G_DOSSIER              |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       5 |
|* 37 |    INDEX UNIQUE SCAN                     | DOS_REFDOSS            |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |
|  38 |   TABLE ACCESS BY INDEX ROWID BATCHED    | G_PIECE                |      1 |      2 |     1   (0)|      1 |00:00:00.01 |       8 |
|* 39 |    INDEX RANGE SCAN                      | PIE_REFDOSS            |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       4 |
------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   2 - access("FR"."REFPIECE"=:B1 AND "FR"."TYPE"='FINRATE')
       filter(("FR"."MT01" IS NOT NULL AND TRUNC(NVL("DT02_DT",:B2))>=TO_DATE(:B2,'MM-DD-YYYY') AND
              TRUNC(NVL("DT01_DT",TO_DATE(:B2,'MM-DD-YYYY')))<=TO_DATE(:B2,'MM-DD-YYYY')))
   6 - filter(("P"."REFEXT"='COM' AND "P"."GPIBUREAU"=:B4 AND "P"."GPIDEPOT"='COR' AND "P"."TYPPIECE"='PARAM_LIMITE' AND
              NVL("P"."FG01",'N')<>'O'))
   7 - access("P"."GPIMARQUE"=:B3)
   8 - access("D"."REFPIECE"="P"."REFPIECE")
  13 - filter(("P"."STR_20_1" IS NOT NULL AND "P"."REFEXT"='COM' AND "P"."GPIBUREAU"=:B4 AND "P"."TYPPIECE"='PARAM_LIMITE' AND
              "P"."GPITYPTRIB"=:B5))
  14 - access("P"."GPIMARQUE"=:B3)
  15 - access("R"."REFPIECE"="P"."STR_20_1")
  16 - filter(("R"."TYPPIECE"='REQUEST_LIMITE' AND "R"."FG05"='O'))
  19 - access("E"."REFDOSS"=:B1 AND "E"."ACTIF"='O')
  24 - filter(LAST_DAY(TRUNC(TO_DATE(:B2,'MM-DD-YYYY'),'fmmonth'))>=ADD_MONTHS(TRUNC(TO_DATE(:B2,'MM-DD-YYYY'),'fmmonth'),(-12)))
  25 - filter((INTERNAL_FUNCTION("STAT_TYPE") AND "CALCUL_DT">=ADD_MONTHS(TRUNC(TO_DATE(:B2,'MM-DD-YYYY'),'fmmonth'),(-12)) AND
              "CALCUL_DT"<=LAST_DAY(TRUNC(TO_DATE(:B2,'MM-DD-YYYY'),'fmmonth'))))
  26 - access("REFDOSS"=:B1)
  31 - filter(("R"."LIBELLE_20_12" IS NOT NULL AND "R"."TYPPIECE"='REQUEST_LIMITE' AND "R"."FG05"='O'))
  32 - access("R"."GPILIBLIBRE" LIKE 'L1.'||:B3||'.'||:B4||'.'||:B5||'%')
       filter("R"."GPILIBLIBRE" LIKE 'L1.'||:B3||'.'||:B4||'.'||:B5||'%')
  33 - access("R"."LIBELLE_20_12"="P"."REFPIECE")
  34 - filter(("P"."REFEXT"='COM' AND "P"."GPIDEPOT"='FIN' AND "P"."TYPPIECE"='PARAM_LIMITE'))
  37 - access("D"."REFDOSS"=:B1)
  39 - access("A"."REFDOSS"=:B1 AND "A"."TYPPIECE"="D"."PIECEINIT")
*/
/********************************New Metrics***************************************/

/********************************Index statistics**********************************/

/********************************Other SQLs****************************************/          
/*

*/ 
/********************************Other SQLs****************************************/              
