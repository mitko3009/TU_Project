/********************************************************************************
*********       E-mail subject: BCOCTLMWEB-475
*********             Instance: PROD
*********          Description: 
Problem:
Slow SQL query was provided from PROD.

Analysis:
The problem was that Oracle choose inappropriate execution plan, because it expects a lot of data to be returned. We checked when 
the statistics were last gathered and found that is was on 06/10/2023. After running the script for gathering 
the statistics the problematic SQL was still slow, so as it is in the specification the solution here is 
to change optimizer_index_cost_adj to 1.

Suggestion:
1. Change the optimizer_index_cost_adj to 1 as in the specification.

2. The first point from the suggestion will fix the problem, but please open new low priority task and assigne it to Performance and Tuning team to 
try to find more complex solution with V9 team.

*********               SQL_ID: 2htcbmrpa65hb
*********      Program/Package: 
*********              Request: Vasil Todorov 
*********               Author: Dimitar Dimitrov
********* Received e-mail date: 18/10/2023
*********      Resolution date: 19/10/2023
*********  Trace old file here: \\epox\specifs\performance\tmp\
*********  Trace new file here:
***********************************************************************************/

/********************************OLD SQL*******************************************/
var B1 VARCHAR2(128);
exec :B1 := '%';
var B2 VARCHAR2(128);
exec :B2 := 050112939X%';
var B3 VARCHAR2(128);
exec :B3 := 050112939X%';
var B4 VARCHAR2(128);
exec :B4 := 050112939X%';
var B5 NUMBER;
exec :B5 := 2001;
var B6 NUMBER;
exec :B6 := 1;

SELECT g_main.*
  FROM  (SELECT /*+ first_rows(%d)*/
         foo.*, ROWNUM rnum
          FROM (SELECT tel1 tel1
                      ,pays  country
                      ,tel2 tel2
                      ,ville city
                      ,str83 indvType
                      ,bqdet_str_50_2 bqdet_str_50_2
                      ,raissoc2 commercialSign
                      ,refext extIndividualRef
                      ,tel3 tel3
                      ,bqdet_NumIban bqdet_NumIban
                      ,str22 tradingAs
                      ,vvt.vvt_tel tel
                      ,adr4 address4
                      ,email email
                      ,division territorialDivision
                      ,bqdet_NoCompte bqdet_NoCompte
                      ,adr1 address
                      ,adr3 address3
                      ,adr2 address2
                      ,NVL(siret, NVL(tva, regcomm)) legalId
                      ,raissoc1 corpName
                      ,dtmajec_dt situationDate
                      ,dtnaiss_dt birthDate
                      ,bqdet_UMR bqdet_UMR
                      ,prenom firstName
                      ,apprgendeb indivSituation
                      ,refindividu individualRef
                      ,nom NAME
                      ,cp postCode
                  FROM G_INDIVIDU I
                 OUTER APPLY (SELECT refindividu AS bqdet_refindividu
                                   ,nocompte    AS bqdet_nocompte
                                   ,numiban     AS bqdet_numiban
                                   ,umr         AS bqdet_umr
                                   ,str_50_2    AS bqdet_str_50_2
                               FROM g_domiciliation g1
                              WHERE 1 = 1
                                AND i.refindividu = g1.refindividu
                              ORDER BY DECODE(NVL(etat, 'H'), 'V', 1, 'H', 2) DESC, imx_un_id DESC FETCH FIRST 1 ROW ONLY) bqdet
                 OUTER apply (SELECT tel AS vvt_tel, refindividu AS vvt_refindividu
                               FROM vv_tels
                              WHERE tel || '' LIKE :B1
                                AND i.refindividu = refindividu
                              ORDER BY tel DESC FETCH FIRST 1 ROW ONLY) vvt
                 WHERE 1 = 1
                   AND i.refindividu IN (SELECT refindividu
                                           FROM g_individu
                                          WHERE tva LIKE :B2
                                         UNION ALL
                                         SELECT refindividu
                                           FROM g_individu
                                          WHERE siret LIKE :B3
                                         UNION ALL
                                         SELECT refindividu
                                           FROM g_individu
                                          WHERE regcomm LIKE :B4)
                   AND EXISTS (SELECT DISTINCT 1
                          FROM t_intervenants t
                         WHERE t.refindividu = i.refindividu
                           AND t.reftype != 'XX')
                 ORDER BY nom, prenom, refindividu) foo
         WHERE ROWNUM <= :B5) g_main
 WHERE 1 = 1
   AND rnum >=  :B6;

/********************************OLD SQL*******************************************/
/********************************OLD Metrics***************************************/
/*
Plan hash value: 642006207
------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                       | Name                | Starts | E-Rows | A-Rows |   A-Time   | Buffers | Reads  |
------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                                |                     |      1 |        |      0 |00:00:00.01 |       0 |      0 |
|*  1 |  VIEW                                           |                     |      1 |   2001 |      0 |00:00:00.01 |       0 |      0 |
|*  2 |   COUNT STOPKEY                                 |                     |      1 |        |      0 |00:00:00.01 |       0 |      0 |
|   3 |    VIEW                                         |                     |      1 |   4416M|      0 |00:00:00.01 |       0 |      0 |
|*  4 |     SORT ORDER BY STOPKEY                       |                     |      1 |   4416M|      0 |00:00:00.01 |       0 |      0 |
|*  5 |      HASH JOIN                                  |                     |      1 |   4416M|      0 |00:00:00.01 |       0 |      0 |
|   6 |       VIEW                                      | VW_NSO_1            |      1 |      3 |      1 |00:00:00.01 |       7 |      1 |
|   7 |        HASH UNIQUE                              |                     |      1 |      3 |      1 |00:00:00.01 |       7 |      1 |
|   8 |         UNION-ALL                               |                     |      1 |        |      1 |00:00:00.01 |       7 |      1 |
|   9 |          TABLE ACCESS BY INDEX ROWID BATCHED    | G_INDIVIDU          |      1 |      1 |      0 |00:00:00.01 |       1 |      0 |
|* 10 |           INDEX RANGE SCAN                      | G_INDIV_TVA_IDX     |      1 |      1 |      0 |00:00:00.01 |       1 |      0 |
|  11 |          TABLE ACCESS BY INDEX ROWID BATCHED    | G_INDIVIDU          |      1 |      1 |      1 |00:00:00.01 |       4 |      1 |
|* 12 |           INDEX RANGE SCAN                      | GINDSIRET           |      1 |      1 |      1 |00:00:00.01 |       3 |      1 |
|  13 |          TABLE ACCESS BY INDEX ROWID BATCHED    | G_INDIVIDU          |      1 |      1 |      0 |00:00:00.01 |       2 |      0 |
|* 14 |           INDEX RANGE SCAN                      | G_INDIV_REGCOMM_IDX |      1 |      1 |      0 |00:00:00.01 |       2 |      0 |
|  15 |       MERGE JOIN OUTER                          |                     |      1 |   1660K|      0 |00:00:00.01 |       0 |      0 |
|  16 |        MERGE JOIN OUTER                         |                     |      1 |   1660K|      0 |00:00:00.01 |       0 |      0 |
|* 17 |         HASH JOIN SEMI                          |                     |      1 |   1660K|      0 |00:00:00.01 |       0 |      0 |
|  18 |          TABLE ACCESS FULL                      | G_INDIVIDU          |      1 |   1745K|    521K|00:00:01.05 |     566K|      0 |
|* 19 |          INDEX FAST FULL SCAN                   | INT_REFDOSS         |      0 |     15M|      0 |00:00:00.01 |       0 |      0 |
|  20 |         BUFFER SORT                             |                     |      0 |      1 |      0 |00:00:00.01 |       0 |      0 |
|  21 |          VIEW                                   | VW_LAT_F9E09D1C     |      0 |      1 |      0 |00:00:00.01 |       0 |      0 |
|  22 |           VIEW                                  | VW_LAT_1BBF5C63     |      0 |      1 |      0 |00:00:00.01 |       0 |      0 |
|* 23 |            VIEW                                 |                     |      0 |      1 |      0 |00:00:00.01 |       0 |      0 |
|* 24 |             WINDOW SORT PUSHED RANK             |                     |      0 |      1 |      0 |00:00:00.01 |       0 |      0 |
|  25 |              TABLE ACCESS BY INDEX ROWID BATCHED| G_DOMICILIATION     |      0 |      1 |      0 |00:00:00.01 |       0 |      0 |
|* 26 |               INDEX RANGE SCAN                  | REF_DOM             |      0 |      1 |      0 |00:00:00.01 |       0 |      0 |
|  27 |        BUFFER SORT                              |                     |      0 |      1 |      0 |00:00:00.01 |       0 |      0 |
|  28 |         VIEW                                    | VW_LAT_F9E09D1C     |      0 |      1 |      0 |00:00:00.01 |       0 |      0 |
|  29 |          VIEW                                   | VW_LAT_7C006CC6     |      0 |      1 |      0 |00:00:00.01 |       0 |      0 |
|* 30 |           VIEW                                  |                     |      0 |      1 |      0 |00:00:00.01 |       0 |      0 |
|* 31 |            WINDOW SORT PUSHED RANK              |                     |      0 |      1 |      0 |00:00:00.01 |       0 |      0 |
|  32 |             NESTED LOOPS                        |                     |      0 |      1 |      0 |00:00:00.01 |       0 |      0 |
|  33 |              NESTED LOOPS                       |                     |      0 |      3 |      0 |00:00:00.01 |       0 |      0 |
|* 34 |               INDEX RANGE SCAN                  | DOM_TYPABREV        |      0 |      1 |      0 |00:00:00.01 |       0 |      0 |
|* 35 |               INDEX RANGE SCAN                  | IDX_G_TEL_INDIV     |      0 |      3 |      0 |00:00:00.01 |       0 |      0 |
|* 36 |              TABLE ACCESS BY INDEX ROWID        | G_TELEPHONE         |      0 |      1 |      0 |00:00:00.01 |       0 |      0 |
------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   1 - filter("RNUM">=:B6)
   2 - filter(ROWNUM<=:B5)
   4 - filter(ROWNUM<=:B5)
   5 - access("I"."REFINDIVIDU"="REFINDIVIDU")
  10 - access("TVA" LIKE :B2)
       filter("TVA" LIKE :B2)
  12 - access("SIRET" LIKE :B3)
       filter("SIRET" LIKE :B3)
  14 - access("REGCOMM" LIKE :B4)
       filter("REGCOMM" LIKE :B4)
  17 - access("T"."REFINDIVIDU"="I"."REFINDIVIDU")
  19 - filter("T"."REFTYPE"<>'XX')
  23 - filter("from$_subquery$_006"."rowlimit_$$_rownumber"<=1)
  24 - filter(ROW_NUMBER() OVER ( ORDER BY DECODE(NVL("ETAT",'H'),'V',1,'H',2) DESC ,INTERNAL_FUNCTION("IMX_UN_ID") DESC )<=1)
  26 - access("I"."REFINDIVIDU"="G1"."REFINDIVIDU")
  30 - filter("from$_subquery$_010"."rowlimit_$$_rownumber"<=1)
  31 - filter(ROW_NUMBER() OVER ( ORDER BY INTERNAL_FUNCTION("GT"."NUMTEL") DESC )<=1)
  34 - access("VD"."TYPE"='TEL_PRIORITE' AND "VD"."ABREV" LIKE 'TEL%')
       filter("VD"."ABREV" LIKE 'TEL%')
  35 - access("I"."REFINDIVIDU"="GT"."REFINDIVIDU")
       filter("GT"."NUMTEL"||'' LIKE :B1)
  36 - filter("VD"."VALEUR"="GT"."LIBELLE2"||"GT"."TYPETEL")
*/
/********************************OLD Metrics***************************************/

/********************************New SQL*******************************************/
SELECT g_main.*
  FROM  (SELECT /*+ first_rows(%d)*/
         foo.*, ROWNUM rnum
          FROM (SELECT tel1 tel1
                      ,pays  country
                      ,tel2 tel2
                      ,ville city
                      ,str83 indvType
                      ,bqdet_str_50_2 bqdet_str_50_2
                      ,raissoc2 commercialSign
                      ,refext extIndividualRef
                      ,tel3 tel3
                      ,bqdet_NumIban bqdet_NumIban
                      ,str22 tradingAs
                      ,vvt.vvt_tel tel
                      ,adr4 address4
                      ,email email
                      ,division territorialDivision
                      ,bqdet_NoCompte bqdet_NoCompte
                      ,adr1 address
                      ,adr3 address3
                      ,adr2 address2
                      ,NVL(siret, NVL(tva, regcomm)) legalId
                      ,raissoc1 corpName
                      ,dtmajec_dt situationDate
                      ,dtnaiss_dt birthDate
                      ,bqdet_UMR bqdet_UMR
                      ,prenom firstName
                      ,apprgendeb indivSituation
                      ,refindividu individualRef
                      ,nom NAME
                      ,cp postCode
                  FROM ( SELECT *
                           FROM g_individu
                          WHERE tva LIKE :B2
                          UNION 
                         SELECT *
                           FROM g_individu
                          WHERE siret LIKE :B3
                          UNION 
                         SELECT *
                           FROM g_individu
                          WHERE regcomm LIKE :B4 ) I
                 OUTER APPLY (SELECT refindividu AS bqdet_refindividu
                                   ,nocompte    AS bqdet_nocompte
                                   ,numiban     AS bqdet_numiban
                                   ,umr         AS bqdet_umr
                                   ,str_50_2    AS bqdet_str_50_2
                               FROM g_domiciliation g1
                              WHERE 1 = 1
                                AND i.refindividu = g1.refindividu
                              ORDER BY DECODE(NVL(etat, 'H'), 'V', 1, 'H', 2) DESC, imx_un_id DESC FETCH FIRST 1 ROW ONLY) bqdet
                 OUTER apply (SELECT tel AS vvt_tel, refindividu AS vvt_refindividu
                               FROM vv_tels
                              WHERE tel || '' LIKE :B1
                                AND i.refindividu = refindividu
                              ORDER BY tel DESC FETCH FIRST 1 ROW ONLY) vvt
                 WHERE 1 = 1
                   AND EXISTS (SELECT DISTINCT 1
                          FROM t_intervenants t
                         WHERE t.refindividu = i.refindividu
                           AND t.reftype != 'XX')
                 ORDER BY nom, prenom, refindividu) foo
         WHERE ROWNUM <= :B5) g_main
 WHERE 1 = 1
   AND rnum >=  :B6;
/********************************New SQL*******************************************/
/********************************New Metrics***************************************/
/*
Plan hash value: 4038633914
--------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                      | Name                | Starts | E-Rows | A-Rows |   A-Time   | Buffers |
--------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                               |                     |      1 |        |      1 |00:00:00.01 |      31 |
|*  1 |  VIEW                                          |                     |      1 |      1 |      1 |00:00:00.01 |      31 |
|*  2 |   COUNT STOPKEY                                |                     |      1 |        |      1 |00:00:00.01 |      31 |
|   3 |    VIEW                                        |                     |      1 |      1 |      1 |00:00:00.01 |      31 |
|*  4 |     SORT ORDER BY STOPKEY                      |                     |      1 |      1 |      1 |00:00:00.01 |      31 |
|   5 |      MERGE JOIN OUTER                          |                     |      1 |      1 |      1 |00:00:00.01 |      31 |
|   6 |       MERGE JOIN OUTER                         |                     |      1 |      1 |      1 |00:00:00.01 |      15 |
|   7 |        NESTED LOOPS SEMI                       |                     |      1 |      1 |      1 |00:00:00.01 |      11 |
|   8 |         VIEW                                   |                     |      1 |      3 |      1 |00:00:00.01 |       8 |
|   9 |          SORT UNIQUE                           |                     |      1 |      3 |      1 |00:00:00.01 |       8 |
|  10 |           UNION-ALL                            |                     |      1 |        |      1 |00:00:00.01 |       8 |
|  11 |            TABLE ACCESS BY INDEX ROWID BATCHED | G_INDIVIDU          |      1 |      1 |      0 |00:00:00.01 |       1 |
|* 12 |             INDEX RANGE SCAN                   | G_INDIV_TVA_IDX     |      1 |      1 |      0 |00:00:00.01 |       1 |
|  13 |            TABLE ACCESS BY INDEX ROWID BATCHED | G_INDIVIDU          |      1 |      1 |      1 |00:00:00.01 |       5 |
|* 14 |             INDEX RANGE SCAN                   | GINDSIRET           |      1 |      1 |      1 |00:00:00.01 |       3 |
|  15 |            TABLE ACCESS BY INDEX ROWID BATCHED | G_INDIVIDU          |      1 |      1 |      0 |00:00:00.01 |       2 |
|* 16 |             INDEX RANGE SCAN                   | G_INDIV_REGCOMM_IDX |      1 |      1 |      0 |00:00:00.01 |       2 |
|* 17 |         INDEX RANGE SCAN                       | INT_INDIV           |      1 |      9 |      1 |00:00:00.01 |       3 |
|  18 |        BUFFER SORT                             |                     |      1 |      1 |      1 |00:00:00.01 |       4 |
|  19 |         VIEW                                   | VW_LAT_EBBB6F00     |      1 |      1 |      1 |00:00:00.01 |       4 |
|  20 |          VIEW                                  | VW_LAT_1BBF5C63     |      1 |      1 |      1 |00:00:00.01 |       4 |
|* 21 |           VIEW                                 |                     |      1 |      1 |      1 |00:00:00.01 |       4 |
|* 22 |            WINDOW SORT PUSHED RANK             |                     |      1 |      1 |      1 |00:00:00.01 |       4 |
|  23 |             TABLE ACCESS BY INDEX ROWID BATCHED| G_DOMICILIATION     |      1 |      1 |      1 |00:00:00.01 |       4 |
|* 24 |              INDEX RANGE SCAN                  | REF_DOM             |      1 |      1 |      1 |00:00:00.01 |       3 |
|  25 |       BUFFER SORT                              |                     |      1 |      1 |      1 |00:00:00.01 |      16 |
|  26 |        VIEW                                    | VW_LAT_EBBB6F00     |      1 |      1 |      1 |00:00:00.01 |      16 |
|  27 |         VIEW                                   | VW_LAT_4BB1B9CA     |      1 |      1 |      1 |00:00:00.01 |      16 |
|* 28 |          VIEW                                  |                     |      1 |      1 |      1 |00:00:00.01 |      16 |
|* 29 |           WINDOW SORT PUSHED RANK              |                     |      1 |      1 |      1 |00:00:00.01 |      16 |
|  30 |            NESTED LOOPS                        |                     |      1 |      1 |      3 |00:00:00.01 |      16 |
|  31 |             NESTED LOOPS                       |                     |      1 |      3 |     92 |00:00:00.01 |      15 |
|* 32 |              INDEX RANGE SCAN                  | DOM_TYPABREV        |      1 |      1 |     23 |00:00:00.01 |       2 |
|* 33 |              INDEX RANGE SCAN                  | IDX_G_TEL_INDIV     |     23 |      3 |     92 |00:00:00.01 |      13 |
|* 34 |             TABLE ACCESS BY INDEX ROWID        | G_TELEPHONE         |     92 |      1 |      3 |00:00:00.01 |       1 |
--------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   1 - filter("RNUM">=:B6)
   2 - filter(ROWNUM<=:B5)
   4 - filter(ROWNUM<=:B5)
  12 - access("TVA" LIKE :B2)
       filter("TVA" LIKE :B2)
  14 - access("SIRET" LIKE :B3)
       filter("SIRET" LIKE :B3)
  16 - access("REGCOMM" LIKE :B4)
       filter("REGCOMM" LIKE :B4)
  17 - access("T"."REFINDIVIDU"="I"."REFINDIVIDU")
       filter("T"."REFTYPE"<>'XX')
  21 - filter("from$_subquery$_009"."rowlimit_$$_rownumber"<=1)
  22 - filter(ROW_NUMBER() OVER ( ORDER BY DECODE(NVL("ETAT",'H'),'V',1,'H',2) DESC ,INTERNAL_FUNCTION("IMX_UN_ID")
              DESC )<=1)
  24 - access("I"."REFINDIVIDU"="G1"."REFINDIVIDU")
  28 - filter("from$_subquery$_013"."rowlimit_$$_rownumber"<=1)
  29 - filter(ROW_NUMBER() OVER ( ORDER BY INTERNAL_FUNCTION("GT"."NUMTEL") DESC )<=1)
  32 - access("VD"."TYPE"='TEL_PRIORITE' AND "VD"."ABREV" LIKE 'TEL%')
       filter("VD"."ABREV" LIKE 'TEL%')
  33 - access("I"."REFINDIVIDU"="GT"."REFINDIVIDU")
       filter("GT"."NUMTEL"||'' LIKE :B1)
  34 - filter("VD"."VALEUR"="GT"."LIBELLE2"||"GT"."TYPETEL")
*/
/********************************New Metrics***************************************/

/********************************Index statistics**********************************/

/********************************Other SQLs****************************************/          
/*

*/ 
/********************************Other SQLs****************************************/              
