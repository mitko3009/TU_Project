/********************************************************************************
*********       E-mail subject: LBPDEV-6703
*********             Instance: LAGO
*********          Description: 
Problem:
Slowness in e_videcompte2 on instance LAGO.

Analysis:
From the trace file we can see that when accessing the screen and tab via the Chrono the TOP SQL 1tvczpzrg744h took around 11 seconds.
The problem in this SQL is that when accessing table t_elements through TRUNC(E.dtsaisie_dt) we have no appropriate index. The solution here is to use column dtsaisie instead of 
column dtsaisie_dt on table t_elements. By this way we will use index TE_DTSAISIE which is on columns DTSAISIE and REFDOSS.

Suggestion:
Please modify the query as it is shown in the New SQL section below.

*********               SQL_ID: 1tvczpzrg744h 
*********      Program/Package: e_videcompte2
*********              Request: Nadya Tsvetkova 
*********               Author: Dimitar Dimitrov
********* Received e-mail date: 09-02-2024
*********      Resolution date: 09-02-2024
*********  Trace old file here: \\epox\specifs\performance\tmp\
*********  Trace new file here: \\epox\specifs\performance\tmp\LBP\e_videcompte2\20240209
***********************************************************************************/

/********************************OLD SQL*******************************************/
SELECT ANCREFDOSS, DEVISE, REFDOSS, REFINDIVIDU, REFLOT, REFFACTOR
  FROM (SELECT (SELECT gd.ancrefdoss
                  FROM g_dossier GD
                 WHERE gd.refdoss = D.reflot
                   AND gd.categdoss = 'CONTRAT') ancrefdoss,
               D.refdoss refdoss,
               D.reflot reflot,
               D.devise devise,
               T.refindividu refindividu,
               D.reffactor
          FROM g_dossier D, t_intervenants T
         WHERE D.categdoss LIKE 'DECOMPTE%'
           AND D.refdoss = T.refdoss
           AND T.reftype = DECODE(D.categdoss, 'DECOMPTE IMP', 'TC', 'CL')
           AND EXISTS
               (SELECT 1
                  FROM t_elements E
                 WHERE E.refdoss = D.refdoss
                   AND E.typeelem = 're'
                   AND E.libelle || '' LIKE 'DECOMPTE NO%'
                   AND TRUNC(E.dtsaisie_dt) = ( SELECT TRUNC(EE.dtsaisie_dt)
                                                  FROM t_elements EE
                                                 WHERE EE.refelem = 'A707IG6I'
                                                   AND EE.refdoss = '1911200025' ) ) )
 WHERE refdoss IN
       (SELECT d.refdoss
          FROM member_contract mc, group_contracts gc, g_dossier d
         WHERE gc.refgroup = mc.refgroup
           AND gc.valid = 'O'
           AND d.reflot = mc.refdoss
           AND d.categdoss LIKE 'DECOMPTE%'
           AND mc.refgroup IN (SELECT refgroup
                                 FROM member_contract
                                WHERE refdoss = '1911200024')
        UNION
        SELECT refdoss
          FROM g_dossier
         WHERE reflot = '1911200024'
           AND categdoss LIKE 'DECOMPTE%')
   AND (NOT EXISTS
        (SELECT 1
           FROM t_gestfctcomp C, g_mangrp G
          WHERE C.refmangrp = G.refmangrp
            AND C.refperso = 29) OR
        reffactor IN (SELECT F.refindividu
                        FROM t_gestfctcomp C, g_mangrp G, t_fctmembmg F
                       WHERE C.refmangrp = G.refmangrp
                         AND G.refmangrp = F.refmangrp
                         AND C.refperso = 29))
   AND EXISTS (SELECT 1
          FROM g_piece P
         WHERE NVL(P.fg121, 'N') = 'N'
           AND NVL(P.fg30, 'N') = NVL('N', 'N')
           AND P.typpiece = 'SOUS-CONTRAT'
           AND P.refdoss = refdoss);
/********************************OLD SQL*******************************************/
/********************************OLD Metrics***************************************/
/*
Plan hash value: 3034428550
------------------------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                      | Name                      | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  |
------------------------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                               |                           |      1 |        |    14 (100)|      2 |00:00:18.11 |    3015 |   2179 |
|*  1 |  TABLE ACCESS BY INDEX ROWID                   | G_DOSSIER                 |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |      0 |
|*  2 |   INDEX UNIQUE SCAN                            | DOS_REFDOSS               |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       2 |      0 |
|*  3 |  FILTER                                        |                           |      1 |        |            |      2 |00:00:18.11 |    3015 |   2179 |
|*  4 |   FILTER                                       |                           |      1 |        |            |      2 |00:00:18.11 |    3013 |   2179 |
|   5 |    NESTED LOOPS SEMI                           |                           |      1 |      1 |    10  (10)|      2 |00:00:18.10 |    3007 |   2178 |
|   6 |     NESTED LOOPS                               |                           |      1 |      1 |     8  (13)|      2 |00:00:00.01 |      18 |      0 |
|   7 |      NESTED LOOPS                              |                           |      1 |      1 |     7  (15)|      2 |00:00:00.01 |      13 |      0 |
|   8 |       VIEW                                     | VW_NSO_1                  |      1 |      2 |     6  (17)|      2 |00:00:00.01 |       3 |      0 |
|   9 |        SORT UNIQUE                             |                           |      1 |      2 |     6  (17)|      2 |00:00:00.01 |       3 |      0 |
|  10 |         UNION-ALL                              |                           |      1 |        |            |      2 |00:00:00.01 |       3 |      0 |
|  11 |          NESTED LOOPS SEMI                     |                           |      1 |      1 |     4   (0)|      0 |00:00:00.01 |       1 |      0 |
|  12 |           NESTED LOOPS                         |                           |      1 |      1 |     3   (0)|      0 |00:00:00.01 |       1 |      0 |
|  13 |            NESTED LOOPS                        |                           |      1 |      1 |     2   (0)|      0 |00:00:00.01 |       1 |      0 |
|  14 |             TABLE ACCESS BY INDEX ROWID BATCHED| MEMBER_CONTRACT           |      1 |      1 |     1   (0)|      0 |00:00:00.01 |       1 |      0 |
|* 15 |              INDEX RANGE SCAN                  | MC_REFDOSS_IDX            |      1 |      1 |     1   (0)|      0 |00:00:00.01 |       1 |      0 |
|  16 |             TABLE ACCESS BY INDEX ROWID BATCHED| MEMBER_CONTRACT           |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 17 |              INDEX RANGE SCAN                  | MC_REFGROUP_IDX           |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 18 |            INDEX RANGE SCAN                    | G_DOSSIER_RL_CD_RD_RF_IDX |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 19 |           TABLE ACCESS BY INDEX ROWID          | GROUP_CONTRACTS           |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 20 |            INDEX UNIQUE SCAN                   | PK_GROUP_CONTRACTS        |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 21 |          INDEX RANGE SCAN                      | G_DOSSIER_RL_CD_RD_RF_IDX |      1 |      1 |     1   (0)|      2 |00:00:00.01 |       2 |      0 |
|* 22 |       TABLE ACCESS BY INDEX ROWID              | G_DOSSIER                 |      2 |      1 |     1   (0)|      2 |00:00:00.01 |      10 |      0 |
|* 23 |        INDEX UNIQUE SCAN                       | DOS_REFDOSS               |      2 |      1 |     1   (0)|      2 |00:00:00.01 |       4 |      0 |
|* 24 |      INDEX RANGE SCAN                          | INT_REFDOSS               |      2 |      1 |     1   (0)|      2 |00:00:00.01 |       5 |      0 |
|  25 |     VIEW PUSHED PREDICATE                      | VW_SQ_2                   |      2 |      1 |     2   (0)|      2 |00:00:18.10 |    2989 |   2178 |
|* 26 |      TABLE ACCESS BY INDEX ROWID BATCHED       | T_ELEMENTS                |      2 |      1 |     1   (0)|      2 |00:00:18.10 |    2989 |   2178 |
|* 27 |       INDEX RANGE SCAN                         | ELE_DOSS_TYP_ASSOC_LIB    |      2 |      1 |     1   (0)|   2958 |00:00:00.21 |      30 |     24 |
|* 28 |       TABLE ACCESS BY INDEX ROWID BATCHED      | T_ELEMENTS                |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       4 |      0 |
|* 29 |        INDEX RANGE SCAN                        | ELE_ELEMTYPE              |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |      0 |
|* 30 |    TABLE ACCESS BY INDEX ROWID BATCHED         | G_PIECE                   |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       6 |      1 |
|* 31 |     INDEX RANGE SCAN                           | GP_TYPP_FG01_NB04_DOS_IDX |      1 |    757 |     1   (0)|      1 |00:00:00.01 |       3 |      1 |
|  32 |   NESTED LOOPS SEMI                            |                           |      1 |      1 |     2   (0)|      0 |00:00:00.01 |       2 |      0 |
|  33 |    INDEX FULL SCAN                             | PK_G_MANGRP               |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       1 |      0 |
|* 34 |    INDEX UNIQUE SCAN                           | PK_T_GESTFCTCOMP          |      1 |      4 |     1   (0)|      0 |00:00:00.01 |       1 |      0 |
|  35 |   NESTED LOOPS SEMI                            |                           |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|  36 |    NESTED LOOPS SEMI                           |                           |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|  37 |     INDEX FULL SCAN                            | PK_G_MANGRP               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 38 |     INDEX UNIQUE SCAN                          | PK_T_FCTMEMBMG            |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 39 |    INDEX UNIQUE SCAN                           | PK_T_GESTFCTCOMP          |      0 |      4 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
------------------------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   1 - filter("GD"."CATEGDOSS"='CONTRAT')
   2 - access("GD"."REFDOSS"=:B1)
   3 - filter(( IS NULL OR  IS NOT NULL))
   4 - filter( IS NOT NULL)
  15 - access("REFDOSS"='1911200024')
  17 - access("MC"."REFGROUP"="REFGROUP")
  18 - access("D"."REFLOT"="MC"."REFDOSS" AND "D"."CATEGDOSS" LIKE 'DECOMPTE%')
       filter(("D"."CATEGDOSS" LIKE 'DECOMPTE%' AND "D"."REFLOT" IS NOT NULL))
  19 - filter("GC"."VALID"='O')
  20 - access("GC"."REFGROUP"="MC"."REFGROUP")
  21 - access("REFLOT"='1911200024' AND "CATEGDOSS" LIKE 'DECOMPTE%')
       filter("CATEGDOSS" LIKE 'DECOMPTE%')
  22 - filter("D"."CATEGDOSS" LIKE 'DECOMPTE%')
  23 - access("D"."REFDOSS"="REFDOSS")
  24 - access("D"."REFDOSS"="T"."REFDOSS" AND "T"."REFTYPE"=DECODE("D"."CATEGDOSS",'DECOMPTE IMP','TC','CL'))
  26 - filter(TRUNC(INTERNAL_FUNCTION("E"."DTSAISIE_DT"))=)
  27 - access("E"."REFDOSS"="D"."REFDOSS" AND "E"."TYPEELEM"='re')
       filter("E"."LIBELLE"||'' LIKE 'DECOMPTE NO%')
  28 - filter("EE"."REFDOSS"='1911200025')
  29 - access("EE"."REFELEM"='A707IG6I')
  30 - filter((NVL("P"."FG30",'N')='N' AND NVL("P"."FG121",'N')='N'))
  31 - access("P"."TYPPIECE"='SOUS-CONTRAT')
       filter("P"."REFDOSS" IS NOT NULL)
  34 - access("C"."REFPERSO"=29 AND "C"."REFMANGRP"="G"."REFMANGRP")
  38 - access("F"."REFINDIVIDU"=:B1 AND "G"."REFMANGRP"="F"."REFMANGRP")
  39 - access("C"."REFPERSO"=29 AND "C"."REFMANGRP"="G"."REFMANGRP")
*/
/********************************OLD Metrics***************************************/

/********************************New SQL*******************************************/

SELECT ANCREFDOSS, DEVISE, REFDOSS, REFINDIVIDU, REFLOT, REFFACTOR
  FROM (SELECT (SELECT gd.ancrefdoss
                  FROM g_dossier GD
                 WHERE gd.refdoss = D.reflot
                   AND gd.categdoss = 'CONTRAT') ancrefdoss,
               D.refdoss refdoss,
               D.reflot reflot,
               D.devise devise,
               T.refindividu refindividu,
               D.reffactor
          FROM g_dossier D, t_intervenants T
         WHERE D.categdoss LIKE 'DECOMPTE%'
           AND D.refdoss = T.refdoss
           AND T.reftype = DECODE(D.categdoss, 'DECOMPTE IMP', 'TC', 'CL')
           AND EXISTS
               (SELECT 1
                  FROM t_elements E
                 WHERE E.refdoss = D.refdoss
                   AND E.typeelem || '' = 're'
                   AND E.libelle || '' LIKE 'DECOMPTE NO%'
                   AND E.dtsaisie = ( SELECT EE.dtsaisie
                                                  FROM t_elements EE
                                                 WHERE EE.refelem = 'A707IG6I'
                                                   AND EE.refdoss = '1911200025' ) ) )
 WHERE refdoss IN
       (SELECT d.refdoss
          FROM member_contract mc, group_contracts gc, g_dossier d
         WHERE gc.refgroup = mc.refgroup
           AND gc.valid = 'O'
           AND d.reflot = mc.refdoss
           AND d.categdoss LIKE 'DECOMPTE%'
           AND mc.refgroup IN (SELECT refgroup
                                 FROM member_contract
                                WHERE refdoss = '1911200024')
        UNION
        SELECT refdoss
          FROM g_dossier
         WHERE reflot = '1911200024'
           AND categdoss LIKE 'DECOMPTE%')
   AND (NOT EXISTS
        (SELECT 1
           FROM t_gestfctcomp C, g_mangrp G
          WHERE C.refmangrp = G.refmangrp
            AND C.refperso = 29) OR
        reffactor IN (SELECT F.refindividu
                        FROM t_gestfctcomp C, g_mangrp G, t_fctmembmg F
                       WHERE C.refmangrp = G.refmangrp
                         AND G.refmangrp = F.refmangrp
                         AND C.refperso = 29))
   AND EXISTS (SELECT 1
          FROM g_piece P
         WHERE NVL(P.fg121, 'N') = 'N'
           AND NVL(P.fg30, 'N') = NVL('N', 'N')
           AND P.typpiece = 'SOUS-CONTRAT'
           AND P.refdoss = refdoss);
/********************************New SQL*******************************************/
/********************************New Metrics***************************************/
/*
Plan hash value: 510527720
---------------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                      | Name                      | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers |
---------------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                               |                           |      1 |        |    14 (100)|      2 |00:00:00.01 |      38 |
|*  1 |  TABLE ACCESS BY INDEX ROWID                   | G_DOSSIER                 |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |
|*  2 |   INDEX UNIQUE SCAN                            | DOS_REFDOSS               |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       2 |
|*  3 |  FILTER                                        |                           |      1 |        |            |      2 |00:00:00.01 |      38 |
|*  4 |   FILTER                                       |                           |      1 |        |            |      2 |00:00:00.01 |      36 |
|   5 |    NESTED LOOPS SEMI                           |                           |      1 |      1 |    10  (10)|      2 |00:00:00.01 |      30 |
|   6 |     NESTED LOOPS                               |                           |      1 |      1 |     8  (13)|      2 |00:00:00.01 |      18 |
|   7 |      NESTED LOOPS                              |                           |      1 |      1 |     7  (15)|      2 |00:00:00.01 |      13 |
|   8 |       VIEW                                     | VW_NSO_1                  |      1 |      2 |     6  (17)|      2 |00:00:00.01 |       3 |
|   9 |        SORT UNIQUE                             |                           |      1 |      2 |     6  (17)|      2 |00:00:00.01 |       3 |
|  10 |         UNION-ALL                              |                           |      1 |        |            |      2 |00:00:00.01 |       3 |
|  11 |          NESTED LOOPS SEMI                     |                           |      1 |      1 |     4   (0)|      0 |00:00:00.01 |       1 |
|  12 |           NESTED LOOPS                         |                           |      1 |      1 |     3   (0)|      0 |00:00:00.01 |       1 |
|  13 |            NESTED LOOPS                        |                           |      1 |      1 |     2   (0)|      0 |00:00:00.01 |       1 |
|  14 |             TABLE ACCESS BY INDEX ROWID BATCHED| MEMBER_CONTRACT           |      1 |      1 |     1   (0)|      0 |00:00:00.01 |       1 |
|* 15 |              INDEX RANGE SCAN                  | MC_REFDOSS_IDX            |      1 |      1 |     1   (0)|      0 |00:00:00.01 |       1 |
|  16 |             TABLE ACCESS BY INDEX ROWID BATCHED| MEMBER_CONTRACT           |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 17 |              INDEX RANGE SCAN                  | MC_REFGROUP_IDX           |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 18 |            INDEX RANGE SCAN                    | G_DOSSIER_RL_CD_RD_RF_IDX |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 19 |           TABLE ACCESS BY INDEX ROWID          | GROUP_CONTRACTS           |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 20 |            INDEX UNIQUE SCAN                   | PK_GROUP_CONTRACTS        |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 21 |          INDEX RANGE SCAN                      | G_DOSSIER_RL_CD_RD_RF_IDX |      1 |      1 |     1   (0)|      2 |00:00:00.01 |       2 |
|* 22 |       TABLE ACCESS BY INDEX ROWID              | G_DOSSIER                 |      2 |      1 |     1   (0)|      2 |00:00:00.01 |      10 |
|* 23 |        INDEX UNIQUE SCAN                       | DOS_REFDOSS               |      2 |      1 |     1   (0)|      2 |00:00:00.01 |       4 |
|* 24 |      INDEX RANGE SCAN                          | INT_REFDOSS               |      2 |      1 |     1   (0)|      2 |00:00:00.01 |       5 |
|  25 |     VIEW PUSHED PREDICATE                      | VW_SQ_2                   |      2 |      1 |     2   (0)|      2 |00:00:00.01 |      12 |
|* 26 |      TABLE ACCESS BY INDEX ROWID BATCHED       | T_ELEMENTS                |      2 |      1 |     1   (0)|      2 |00:00:00.01 |      12 |
|* 27 |       INDEX RANGE SCAN                         | TE_DTSAISIE               |      2 |      3 |     1   (0)|      2 |00:00:00.01 |      10 |
|* 28 |        TABLE ACCESS BY INDEX ROWID BATCHED     | T_ELEMENTS                |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       4 |
|* 29 |         INDEX RANGE SCAN                       | ELE_ELEMTYPE              |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |
|* 30 |    TABLE ACCESS BY INDEX ROWID BATCHED         | G_PIECE                   |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       6 |
|* 31 |     INDEX RANGE SCAN                           | GP_TYPP_FG01_NB04_DOS_IDX |      1 |    757 |     1   (0)|      1 |00:00:00.01 |       3 |
|  32 |   NESTED LOOPS SEMI                            |                           |      1 |      1 |     2   (0)|      0 |00:00:00.01 |       2 |
|  33 |    INDEX FULL SCAN                             | PK_G_MANGRP               |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       1 |
|* 34 |    INDEX UNIQUE SCAN                           | PK_T_GESTFCTCOMP          |      1 |      4 |     1   (0)|      0 |00:00:00.01 |       1 |
|  35 |   NESTED LOOPS SEMI                            |                           |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|  36 |    NESTED LOOPS SEMI                           |                           |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |
|  37 |     INDEX FULL SCAN                            | PK_G_MANGRP               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 38 |     INDEX UNIQUE SCAN                          | PK_T_FCTMEMBMG            |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 39 |    INDEX UNIQUE SCAN                           | PK_T_GESTFCTCOMP          |      0 |      4 |     1   (0)|      0 |00:00:00.01 |       0 |
---------------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   1 - filter("GD"."CATEGDOSS"='CONTRAT')
   2 - access("GD"."REFDOSS"=:B1)
   3 - filter(( IS NULL OR  IS NOT NULL))
   4 - filter( IS NOT NULL)
  15 - access("REFDOSS"='1911200024')
  17 - access("MC"."REFGROUP"="REFGROUP")
  18 - access("D"."REFLOT"="MC"."REFDOSS" AND "D"."CATEGDOSS" LIKE 'DECOMPTE%')
       filter(("D"."CATEGDOSS" LIKE 'DECOMPTE%' AND "D"."REFLOT" IS NOT NULL))
  19 - filter("GC"."VALID"='O')
  20 - access("GC"."REFGROUP"="MC"."REFGROUP")
  21 - access("REFLOT"='1911200024' AND "CATEGDOSS" LIKE 'DECOMPTE%')
       filter("CATEGDOSS" LIKE 'DECOMPTE%')
  22 - filter("D"."CATEGDOSS" LIKE 'DECOMPTE%')
  23 - access("D"."REFDOSS"="REFDOSS")
  24 - access("D"."REFDOSS"="T"."REFDOSS" AND "T"."REFTYPE"=DECODE("D"."CATEGDOSS",'DECOMPTE IMP','TC','CL'))
  26 - filter(("E"."TYPEELEM"||''='re' AND "E"."LIBELLE"||'' LIKE 'DECOMPTE NO%'))
  27 - access("E"."DTSAISIE"= AND "E"."REFDOSS"="D"."REFDOSS")
  28 - filter("EE"."REFDOSS"='1911200025')
  29 - access("EE"."REFELEM"='A707IG6I')
  30 - filter((NVL("P"."FG30",'N')='N' AND NVL("P"."FG121",'N')='N'))
  31 - access("P"."TYPPIECE"='SOUS-CONTRAT')
       filter("P"."REFDOSS" IS NOT NULL)
  34 - access("C"."REFPERSO"=29 AND "C"."REFMANGRP"="G"."REFMANGRP")
  38 - access("F"."REFINDIVIDU"=:B1 AND "G"."REFMANGRP"="F"."REFMANGRP")
  39 - access("C"."REFPERSO"=29 AND "C"."REFMANGRP"="G"."REFMANGRP")
*/
/********************************New Metrics***************************************/

/********************************Index statistics**********************************/

/********************************Other SQLs****************************************/          
/*

*/ 
/********************************Other SQLs****************************************/              
