/********************************************************************************
*********       E-mail subject: IMBWEB-7047
*********             Instance: UATHF
*********          Description: 
Problem:
Slow opening of E_STDRELEVE screen.

Analysis:

1. For the 6ggcuz2sauhnw SQL there is already optimization in EHPRODDEV-3991.
2. In the other queries need to be added DF_CLI predicate to efficiently utilize the index access through DF_CLIREL and in some ot them 
to remove the repetition of the exist clause which unnecessarily appears twice in the query. Similar optimization was done in COFADEV-10322.
3. For SQL with id c8wp8kp53bd4v need to be added second predicate DF_CLI = :B2;

Suggestions:
1. Please ask Accounting to apply the same optimization for FACTOR_RELEVE.isBrokerReleve as in EHPRODDEV-3991.
2. Please ask FORMS to modify the queries fkf7f9s8uj67b, 2ay6rzfnwu19y and 4gn9hvd8jxgdw as suggested int COFADEV-10322.
   Practically, df_cli = er_cli has to be added in all of them.
   And the redundant EXISTS ( SELECT 1 FROM f_detfact .. ) has to be removed.
3. Please ask FORMS to modify the query c8wp8kp53bd4v  as it is shown in the New SQL section below.


*********               SQL_ID: 6ggcuz2sauhnw , fkf7f9s8uj67b, 2ay6rzfnwu19y, 4gn9hvd8jxgdw, c8wp8kp53bd4v  
*********      Program/Package: V9 E_STDRELEVE
*********              Request: Dimitare Ivanov
*********               Author: Dimitar Dimitrov
********* Received e-mail date: 10/08/2023
*********      Resolution date: 10/08/2023
*********  Trace old file here: \\epox\specifs\performance\tmp\
*********  Trace new file here:
***********************************************************************************/

/********************************OLD SQL*******************************************/
-- 6ggcuz2sauhnw from FACTOR_RELEVE.isBrokerReleve - apply the modifiaction from EHPRODDEV-3991.

SELECT 1
  FROM F_ENTREL
 WHERE ER_NUM = :B1
   AND EXISTS
 (SELECT DF_NUM
          FROM F_DETFAC
         WHERE DF_REL = ER_NUM
           AND UPPER(DF_NOM) IN ('BCO', 'BCFAC', 'BCINT', 'BRCO'));

-- fkf7f9s8uj67b from E_STDRELEVE screen

SELECT COUNT(1) COL1, er_cli COL2
  FROM f_entrel
 WHERE 1 = 1
   AND er_cli = 'A600ER5T'
   AND Nvl(er_com, '$') NOT IN ('P', 'Y')
   AND exists (select 1
          from f_detfac
         where df_rel = er_num
           and (df_ann is null or df_sen = 'C'))
   AND NOT EXISTS
 (SELECT 1 FROM g_elemfi WHERE er_num = g_elemfi.libelle_20_1)
   AND NOT EXISTS (SELECT 1
          FROM f_detfac, t_ecrdos
         WHERE df_rel = er_num
           AND df_cli = er_cli
           AND df_num = t_ecrdos.refelem
           AND UPPER(df_nom) = t_ecrdos.codecr)
   AND (FACTOR_RELEVE.isBrokerReleve(er_num) = 0)
   AND exists (select 1
          from f_detfac
         where df_rel = er_num
           and (df_ann is null or df_sen = 'C'))
   AND NVL(er_tcr_mvt, 0) - NVL(er_tdb_mvt, 0) < 0
   AND NVL(er_tdb_mvt, 0) - NVL(er_paye_mvt, 0) > 0
   AND Nvl(er_encours, 0) = 0
 GROUP BY er_cli;

--2ay6rzfnwu19y from E_STDRELEVE screen

SELECT COUNT(1) COL1, er_cli COL2
  FROM f_entrel
 WHERE 1 = 1
   AND er_cli = 'A600EZJ1'
   AND Nvl(er_com, '$') NOT IN ('P', 'Y')
   AND exists (select 1
          from f_detfac
         where df_rel = er_num
           and (df_ann is null or df_sen = 'C'))
   AND NOT EXISTS
 (SELECT 1 FROM g_elemfi WHERE er_num = g_elemfi.libelle_20_1)
   AND NOT EXISTS (SELECT 1
          FROM f_detfac, t_ecrdos
         WHERE df_rel = er_num
           AND df_cli = er_cli
           AND df_num = t_ecrdos.refelem
           AND UPPER(df_nom) = t_ecrdos.codecr)
   AND (FACTOR_RELEVE.isBrokerReleve(er_num) = 0)
   AND exists (select 1
          from f_detfac
         where df_rel = er_num
           and (df_ann is null or df_sen = 'C'))
   AND NVL(er_tcr_mvt, 0) - NVL(er_tdb_mvt, 0) < 0
   AND NVL(er_tdb_mvt, 0) - NVL(er_paye_mvt, 0) > 0
   AND Nvl(er_encours, 0) = 0
 GROUP BY er_cli;

--4gn9hvd8jxgdw from E_STDRELEVE screen

SELECT ER_NUM,
       ER_DAT_DT,
       ER_CURR_SCREEN,
       ER_TCR_SCREEN,
       ER_TDB_SCREEN,
       ER_FG_DD_REQUEST,
       ER_PAYE_SCREEN,
       ER_ENCOURS_SCREEN,
       ER_REG_DT,
       ER_BAL_SCREEN,
       ER_CCR_SCREEN,
       ER_REASON,
       ER_CANCEL_REASON,
       NUM_VCS,
       ER_DAT,
       ER_CLI,
       ER_ANN,
       ER_REFEXT1,
       ER_REFEXT2,
       ER_REFTXT,
       ER_ORG_INVOICE_REF,
       ER_CFDI_TYPE,
       ER_TCR_MVT,
       ER_TDB_MVT,
       ER_PAYE_MVT,
       ER_ENCOURS,
       ER_CONTR
  FROM (SELECT ER_NUM,
               ER_DAT_DT,
               ER_REG_DT,
               NUM_VCS,
               ER_DAT,
               ER_CLI,
               ER_ANN,
               ER_REFEXT1,
               ER_REFEXT2,
               ER_REFTXT,
               ER_REASON,
               ER_CANCEL_REASON,
               ER_CONTR,
               ER_TCR_MVT ER_TCR_SCREEN,
               ER_TDB_MVT ER_TDB_SCREEN,
               ER_PAYE_MVT ER_PAYE_SCREEN,
               ER_ENCOURS ER_ENCOURS_SCREEN,
               ER_CCR_MVT ER_CCR_SCREEN,
               ER_DEVISE_MVT ER_CURR_SCREEN,
               Nvl(er_tdb_MVT, 0) - Nvl(er_paye_MVT, 0) ER_BAL_SCREEN,
               er_org_invoice_ref,
               er_cfdi_type,
               er_tcr_mvt,
               er_tdb_mvt,
               er_paye_mvt,
               er_encours,
               er_com,
               er_fg_dd_request
          FROM f_entrel) F
 WHERE er_cli = 'A600EZJ1'
   AND er_ann IS NULL
   AND Nvl(er_com, '$') NOT IN ('P', 'Y')
   AND exists (select 1
          from f_detfac
         where df_rel = er_num
           and (df_ann is null or df_sen = 'C'))
   AND NVL(er_tcr_mvt, 0) - NVL(er_tdb_mvt, 0) < 0
   AND NOT EXISTS
 (SELECT 1 FROM g_elemfi WHERE er_num = g_elemfi.libelle_20_1)
   AND NOT EXISTS (SELECT 1
          FROM f_detfac, t_ecrdos
         WHERE df_rel = er_num
           AND df_cli = er_cli
           AND df_num = t_ecrdos.refelem
           AND UPPER(df_nom) = t_ecrdos.codecr)
   AND (FACTOR_RELEVE.isBrokerReleve(er_num) = 0)
   AND exists (select 1
          from f_detfac
         where df_rel = er_num
           and (df_ann is null or df_sen = 'C'))
   AND NVL(er_tdb_mvt, 0) - NVL(er_paye_mvt, 0) > 0
   AND Nvl(er_encours, 0) = 0
 order by er_num desc;


--c8wp8kp53bd4v

SELECT SUM(DF_ENAN), MIN(DT_DUE_DT) FROM F_DETFAC WHERE DF_REL = :b1;

/********************************OLD SQL*******************************************/
/********************************OLD Metrics***************************************/
/*

-- 6ggcuz2sauhnw

Plan hash value: 2993154259
---------------------------------------------------------------------------------
| Id  | Operation          | Name       | Rows  | Bytes | Cost (%CPU)| Time     |
---------------------------------------------------------------------------------
|   0 | SELECT STATEMENT   |            |       |       |    10 (100)|          |
|   1 |  NESTED LOOPS SEMI |            |     1 |    23 |    10   (0)| 00:00:01 |
|   2 |   INDEX UNIQUE SCAN| ENTREL_CL1 |     1 |     9 |     1   (0)| 00:00:01 |
|   3 |   INDEX SKIP SCAN  | DF_CLIREL  |     1 |    14 |     9   (0)| 00:00:01 |
---------------------------------------------------------------------------------


-- fkf7f9s8uj67b

Plan hash value: 262641972
------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                  | Name                | Rows  | Bytes | Cost (%CPU)| Time     |
------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                           |                     |       |       |    13 (100)|          |
|   1 |  SORT GROUP BY NOSORT                      |                     |     1 |    48 |    13   (0)| 00:00:01 |
|   2 |   NESTED LOOPS SEMI                        |                     |     1 |    48 |    11   (0)| 00:00:01 |
|   3 |    NESTED LOOPS ANTI                       |                     |     1 |    35 |     2   (0)| 00:00:01 |
|   4 |     TABLE ACCESS BY INDEX ROWID            | F_ENTREL            |     1 |    33 |     1   (0)| 00:00:01 |
|   5 |      INDEX RANGE SCAN                      | F_ENTREL_ER_CLI_NUM |     1 |       |     1   (0)| 00:00:01 |
|   6 |       NESTED LOOPS                         |                     |     1 |    46 |     2   (0)| 00:00:01 |
|   7 |        NESTED LOOPS                        |                     |     1 |    46 |     2   (0)| 00:00:01 |
|   8 |         TABLE ACCESS BY INDEX ROWID BATCHED| F_DETFAC            |     1 |    32 |     1   (0)| 00:00:01 |
|   9 |          INDEX RANGE SCAN                  | DF_CLIREL           |     1 |       |     1   (0)| 00:00:01 |
|  10 |         INDEX RANGE SCAN                   | TECR_REFELEM        |     1 |       |     1   (0)| 00:00:01 |
|  11 |        TABLE ACCESS BY INDEX ROWID         | T_ECRDOS            |     1 |    14 |     1   (0)| 00:00:01 |
|  12 |     INDEX RANGE SCAN                       | EFI_LIB_20_1_IDX    |     1 |     2 |     1   (0)| 00:00:01 |
|  13 |    TABLE ACCESS BY INDEX ROWID             | F_DETFAC            |  2513K|    31M|     9   (0)| 00:00:01 |
|  14 |     INDEX SKIP SCAN                        | DF_CLIREL           |     1 |       |     9   (0)| 00:00:01 |
------------------------------------------------------------------------------------------------------------------


-- 2ay6rzfnwu19y

Plan hash value: 262641972
-------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                  | Name                | Starts | E-Rows | A-Rows |   A-Time   | Buffers | Reads  |
-------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                           |                     |      1 |        |      0 |00:00:00.01 |       0 |      0 |
|   1 |  SORT GROUP BY NOSORT                      |                     |      1 |      1 |      0 |00:00:00.01 |       0 |      0 |
|   2 |   NESTED LOOPS SEMI                        |                     |      1 |      1 |  11218 |00:01:01.05 |      15M|    186 |
|   3 |    NESTED LOOPS ANTI                       |                     |      1 |      1 |  11218 |00:00:35.15 |    8828K|    186 |
|*  4 |     TABLE ACCESS BY INDEX ROWID            | F_ENTREL            |      1 |      1 |  11218 |00:00:35.12 |    8828K|    186 |
|*  5 |      INDEX RANGE SCAN                      | F_ENTREL_ER_CLI_NUM |      1 |      1 |  13264 |00:00:35.08 |    8827K|    186 |
|   6 |       NESTED LOOPS                         |                     |  13266 |      1 |      2 |00:00:00.26 |   40614 |    143 |
|   7 |        NESTED LOOPS                        |                     |  13266 |      1 |      2 |00:00:00.25 |   40612 |    142 |
|   8 |         TABLE ACCESS BY INDEX ROWID BATCHED| F_DETFAC            |  13266 |      1 |  13266 |00:00:00.21 |   27278 |    140 |
|*  9 |          INDEX RANGE SCAN                  | DF_CLIREL           |  13266 |      1 |  13266 |00:00:00.05 |   14012 |      0 |
|* 10 |         INDEX RANGE SCAN                   | TECR_REFELEM        |  13266 |      1 |      2 |00:00:00.02 |   13334 |      2 |
|* 11 |        TABLE ACCESS BY INDEX ROWID         | T_ECRDOS            |      2 |      1 |      2 |00:00:00.01 |       2 |      1 |
|* 12 |     INDEX RANGE SCAN                       | EFI_LIB_20_1_IDX    |  11218 |      1 |      0 |00:00:00.01 |       8 |      0 |
|* 13 |    TABLE ACCESS BY INDEX ROWID             | F_DETFAC            |  11218 |   2514K|  11218 |00:00:25.89 |    6941K|      0 |
|* 14 |     INDEX SKIP SCAN                        | DF_CLIREL           |  11218 |      1 |  11218 |00:00:25.87 |    6940K|      0 |
-------------------------------------------------------------------------------------------------------------------------------------


-- 4gn9hvd8jxgdw

Plan hash value: 3077403295
--------------------------------------------------------------------------------------------------------
| Id  | Operation                        | Name                | Rows  | Bytes | Cost (%CPU)| Time     |
--------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                 |                     |       |       |    13 (100)|          |
|   1 |  NESTED LOOPS SEMI               |                     |     1 |   201 |    13   (0)| 00:00:01 |
|   2 |   NESTED LOOPS ANTI              |                     |     1 |   188 |     4   (0)| 00:00:01 |
|   3 |    NESTED LOOPS ANTI             |                     |     1 |   184 |     2   (0)| 00:00:01 |
|   4 |     TABLE ACCESS BY INDEX ROWID  | F_ENTREL            |     1 |   182 |     1   (0)| 00:00:01 |
|   5 |      INDEX RANGE SCAN DESCENDING | F_ENTREL_ER_CLI_NUM |    29 |       |     1   (0)| 00:00:01 |
|   6 |     INDEX RANGE SCAN             | EFI_LIB_20_1_IDX    |     1 |     2 |     1   (0)| 00:00:01 |
|   7 |    VIEW PUSHED PREDICATE         | VW_SQ_1             |     1 |     4 |     2   (0)| 00:00:01 |
|   8 |     NESTED LOOPS                 |                     |     1 |    46 |     2   (0)| 00:00:01 |
|   9 |      NESTED LOOPS                |                     |     1 |    46 |     2   (0)| 00:00:01 |
|  10 |       TABLE ACCESS BY INDEX ROWID| F_DETFAC            |     1 |    32 |     1   (0)| 00:00:01 |
|  11 |        INDEX RANGE SCAN          | DF_CLIREL           |     1 |       |     1   (0)| 00:00:01 |
|  12 |       INDEX RANGE SCAN           | TECR_REFELEM        |     1 |       |     1   (0)| 00:00:01 |
|  13 |      TABLE ACCESS BY INDEX ROWID | T_ECRDOS            |     1 |    14 |     1   (0)| 00:00:01 |
|  14 |   TABLE ACCESS BY INDEX ROWID    | F_DETFAC            |  2515K|    31M|     9   (0)| 00:00:01 |
|  15 |    INDEX SKIP SCAN               | DF_CLIREL           |     1 |       |     9   (0)| 00:00:01 |
--------------------------------------------------------------------------------------------------------


-- c8wp8kp53bd4v

Plan hash value: 2562915746
--------------------------------------------------------------------------------------------------
| Id  | Operation                            | Name      | Rows  | Bytes | Cost (%CPU)| Time     |
--------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                     |           |       |       |     9 (100)|          |
|   1 |  SORT AGGREGATE                      |           |     1 |    24 |            |          |
|   2 |   TABLE ACCESS BY INDEX ROWID BATCHED| F_DETFAC  |     1 |    24 |     9   (0)| 00:00:01 |
|   3 |    INDEX SKIP SCAN                   | DF_CLIREL |     1 |       |     9   (0)| 00:00:01 |
--------------------------------------------------------------------------------------------------

*/
/********************************OLD Metrics***************************************/

/********************************New SQL*******************************************/

-- 6ggcuz2sauhnw

SELECT 1
  FROM F_ENTREL
 WHERE ER_NUM = :B1
   AND EXISTS
 (SELECT DF_NUM
          FROM F_DETFAC
         WHERE DF_REL = ER_NUM
           AND df_cli = er_cli
           AND UPPER(DF_NOM) IN ('BCO', 'BCFAC', 'BCINT', 'BRCO'));


-- 2ay6rzfnwu19y -> for fkf7f9s8uj67b and 4gn9hvd8jxgdw you can apply the same modification 

SELECT COUNT(1) COL1, er_cli COL2
  FROM f_entrel
 WHERE 1 = 1
   AND er_cli = 'A600EZJ1'
   AND Nvl(er_com, '$') NOT IN ('P', 'Y')
   AND exists (select 1
          from f_detfac
         where df_rel = er_num
           and df_cli = er_cli
           and (df_ann is null or df_sen = 'C'))
   AND NOT EXISTS
 (SELECT 1 FROM g_elemfi WHERE er_num = g_elemfi.libelle_20_1)
   AND NOT EXISTS (SELECT 1
          FROM f_detfac, t_ecrdos
         WHERE df_rel = er_num
           AND df_cli = er_cli
           AND df_num = t_ecrdos.refelem
           AND UPPER(df_nom) = t_ecrdos.codecr)
   AND (FACTOR_RELEVE.isBrokerReleve(er_num) = 0)
   AND NVL(er_tcr_mvt, 0) - NVL(er_tdb_mvt, 0) < 0
   AND NVL(er_tdb_mvt, 0) - NVL(er_paye_mvt, 0) > 0
   AND Nvl(er_encours, 0) = 0
 GROUP BY er_cli;


-- c8wp8kp53bd4v

var B1 Varchar2(32);
exec :B1 := 'A102VB7Q';
var B2 Varchar2(32);
exec :B2 := 'A600EZJ1';

SELECT SUM(DF_ENAN),
       MIN(DT_DUE_DT)
       FROM F_DETFAC 
      WHERE DF_REL = :b1
        AND df_cli = :B2;

/********************************New SQL*******************************************/
/********************************New Metrics***************************************/
/*
-- 6ggcuz2sauhnw

Plan hash value: 276563559
-----------------------------------------------------------------------------------------------------
| Id  | Operation                    | Name       | Starts | E-Rows | A-Rows |   A-Time   | Buffers |
-----------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT             |            |      1 |        |      0 |00:00:00.01 |       7 |
|   1 |  NESTED LOOPS SEMI           |            |      1 |      1 |      0 |00:00:00.01 |       7 |
|   2 |   TABLE ACCESS BY INDEX ROWID| F_ENTREL   |      1 |      1 |      1 |00:00:00.01 |       4 |
|*  3 |    INDEX UNIQUE SCAN         | ENTREL_CL1 |      1 |      1 |      1 |00:00:00.01 |       3 |
|*  4 |   INDEX RANGE SCAN           | DF_CLIREL  |      1 |      1 |      0 |00:00:00.01 |       3 |
-----------------------------------------------------------------------------------------------------

Predicate Information (identified by operation id):
---------------------------------------------------
   3 - access("ER_NUM"=:B1)
   4 - access("DF_CLI"="ER_CLI" AND "DF_REL"=:B1)
       filter(((UPPER("DF_NOM")='BCO' OR UPPER("DF_NOM")='BCFAC' OR UPPER("DF_NOM")='BCINT'
              OR UPPER("DF_NOM")='BRCO') AND "DF_REL"="ER_NUM"))


-- 2ay6rzfnwu19y

Plan hash value: 3990673249
----------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                  | Name                | Starts | E-Rows | A-Rows |   A-Time   | Buffers |
----------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                           |                     |      1 |        |      1 |00:00:01.13 |     335K|
|   1 |  SORT GROUP BY NOSORT                      |                     |      1 |      1 |      1 |00:00:01.13 |     335K|
|   2 |   NESTED LOOPS SEMI                        |                     |      1 |      1 |  28035 |00:00:01.12 |     335K|
|   3 |    NESTED LOOPS ANTI                       |                     |      1 |      1 |  28035 |00:00:01.08 |     331K|
|*  4 |     TABLE ACCESS BY INDEX ROWID            | F_ENTREL            |      1 |      1 |  28035 |00:00:01.05 |     331K|
|*  5 |      INDEX RANGE SCAN                      | F_ENTREL_ER_CLI_NUM |      1 |      1 |  32613 |00:00:01.02 |     328K|
|   6 |       NESTED LOOPS                         |                     |  32618 |      1 |      5 |00:00:00.13 |   99939 |
|   7 |        NESTED LOOPS                        |                     |  32618 |      1 |      5 |00:00:00.12 |   99934 |
|   8 |         TABLE ACCESS BY INDEX ROWID BATCHED| F_DETFAC            |  32618 |      1 |  32618 |00:00:00.08 |   67046 |
|*  9 |          INDEX RANGE SCAN                  | DF_CLIREL           |  32618 |      1 |  32618 |00:00:00.04 |   34428 |
|* 10 |         INDEX RANGE SCAN                   | TECR_REFELEM        |  32618 |      1 |      5 |00:00:00.03 |   32888 |
|* 11 |        TABLE ACCESS BY INDEX ROWID         | T_ECRDOS            |      5 |      1 |      5 |00:00:00.01 |       5 |
|* 12 |     INDEX RANGE SCAN                       | EFI_LIB_20_1_IDX    |  28035 |      1 |      0 |00:00:00.02 |       8 |
|* 13 |    TABLE ACCESS BY INDEX ROWID             | F_DETFAC            |  28035 |      3 |  28035 |00:00:00.03 |    4619 |
|* 14 |     INDEX RANGE SCAN                       | DF_CLIREL           |  28035 |      1 |  28035 |00:00:00.02 |    1478 |
----------------------------------------------------------------------------------------------------------------------------

Predicate Information (identified by operation id):
---------------------------------------------------
   4 - filter((NVL("ER_ENCOURS",0)=0 AND NVL("ER_TCR_MVT",0)-NVL("ER_TDB_MVT",0)<0 AND
              NVL("ER_TDB_MVT",0)-NVL("ER_PAYE_MVT",0)>0 AND NVL("ER_COM",'$')<>'P' AND NVL("ER_COM",'$')<>'Y'))
   5 - access("ER_CLI"='A600EZJ1')
       filter(("TEST_DI_ISBROKERRELEVE"("ER_NUM")=0 AND  IS NULL))
   9 - access("DF_CLI"=:B1 AND "DF_REL"=:B2)
  10 - access("DF_NUM"="T_ECRDOS"."REFELEM")
  11 - filter("T_ECRDOS"."CODECR"=UPPER("DF_NOM"))
  12 - access("ER_NUM"="G_ELEMFI"."LIBELLE_20_1")
       filter("G_ELEMFI"."LIBELLE_20_1" IS NOT NULL)
  13 - filter(("DF_ANN" IS NULL OR "DF_SEN"='C'))
  14 - access("DF_CLI"='A600EZJ1' AND "DF_REL"="ER_NUM")
       filter("DF_CLI"="ER_CLI")



-- c8wp8kp53bd4v

Plan hash value: 1665286110
------------------------------------------------------------------------------------------------------------
| Id  | Operation                            | Name      | Starts | E-Rows | A-Rows |   A-Time   | Buffers |
------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                     |           |      1 |        |      1 |00:00:00.01 |       4 |
|   1 |  SORT AGGREGATE                      |           |      1 |      1 |      1 |00:00:00.01 |       4 |
|*  2 |   TABLE ACCESS BY INDEX ROWID BATCHED| F_DETFAC  |      1 |      1 |      0 |00:00:00.01 |       4 |
|*  3 |    INDEX RANGE SCAN                  | DF_CLIREL |      1 |      1 |      1 |00:00:00.01 |       3 |
------------------------------------------------------------------------------------------------------------

Predicate Information (identified by operation id):
---------------------------------------------------
   2 - filter(("DT_DUE_DT" IS NOT NULL OR "DF_ENAN" IS NOT NULL))
   3 - access("DF_CLI"=:B2 AND "DF_REL"=:B1)

*/
/********************************New Metrics***************************************/

/********************************Index statistics**********************************/

/********************************Other SQLs****************************************/          
/*

*/ 
/********************************Other SQLs****************************************/              
