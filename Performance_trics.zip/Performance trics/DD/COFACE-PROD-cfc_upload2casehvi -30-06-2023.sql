/********************************************************************************
*********       E-mail subject: COFAWEB-6991
*********             Instance: PROD
*********          Description: 
Problem:

Performance issue with interface upload2casehvi on coface PROD.

Analysis:

On 26/06/2023 the heaviest query on COFACE PROD was 2zfm9q1j5fwbz.
The problem was inapropriate execution plan because of missing index on tax_id.

Suggestion:

Please create index on G_INDIVIDU(TAX_ID).

*********               SQL_ID: 2zfm9q1j5fwbz
*********      Program/Package: upload2casehvi
*********              Request: Eduardo Jiménez
*********               Author: Dimitar Dimitrov
********* Received e-mail date: 29/06/2023
*********      Resolution date: 30/06/2023
*********  Trace old file here: \\epox\specifs\performance\tmp\
*********  Trace new file here:
***********************************************************************************/

/********************************OLD SQL*******************************************/
var strVat varchar2(32);
EXEC :strVat := 'TAXID8183';
var regNum varchar2(32);
EXEC :regNum := '';

SELECT refindividu
  FROM g_individu
 WHERE tax_id = :strVat
UNION ALL
SELECT refindividu
  FROM g_individu
 WHERE SIRET = :regNum;

/********************************OLD SQL*******************************************/
/********************************OLD Metrics***************************************/
/*


MODULE                           SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL            PERC
-------------------------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
cfc_upload2casehvi                                               213      37092                      2023/06/26 07:53:26  2023/06/26 14:53:32        2499                77204 +000000000 07:00:05.928 100%

 

MODULE                           SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL            PERC
-------------------------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
cfc_upload2casehvi                                               213      37092 db file sequential r 2023/06/26 07:53:26  2023/06/26 14:53:32        2269                77204 +000000000 07:00:05.928 91%
cfc_upload2casehvi                                               213      37092 ON CPU               2023/06/26 07:54:26  2023/06/26 14:53:22         210                 1508 +000000000 06:58:55.918 8%
cfc_upload2casehvi               2zfm9q1j5fwbz 1003134047        213      37092 direct path read     2023/06/26 08:50:28  2023/06/26 14:32:21          20                  123 +000000000 05:41:53.330 1%

 

MODULE                           SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL            PERC
-------------------------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
cfc_upload2casehvi               2zfm9q1j5fwbz 1003134047        213      37092                      2023/06/26 07:53:26  2023/06/26 14:53:32        2497                  150 +000000000 07:00:05.928 100%
cfc_upload2casehvi               a89161ht2ka4y 2888929071        213      37092 db file sequential r 2023/06/26 08:25:37  2023/06/26 08:25:37           1                    1 +000000000 00:00:00.000 0%
cfc_upload2casehvi               ftgzu9ctgtc0p 1741974895        213      37092 ON CPU               2023/06/26 11:29:25  2023/06/26 11:29:25           1                    1 +000000000 00:00:00.000 0%

 

INSTANCE_NUMBER SQL_ID            ELAPSED MAX_WAIT_ON     PC_OF  WAIT_TIME            GETS      READS       ROWS  ELAP/EXEC       GETS/EXEC READS/EXEC  ROWS/EXEC       EXEC PLAN_HASH_VALUE
--------------- ------------- ----------- --------------- ----- ---------- --------------- ---------- ---------- ---------- --------------- ---------- ---------- ---------- ---------------
              1 2zfm9q1j5fwbz       24998 IO              82%   28422.2564      1330146299  194807750          0     166.65         8867642 1298718.33          0        150      1003134047

 

 

SQL_ID        SQL_PLAN_HASH_VALUE SQL_PLAN_LINE_ID SQL_PLAN_OPERATION             SQL_PLAN_OPTIONS                   ACTIVE
------------- ------------------- ---------------- ------------------------------ ------------------------------ ----------
2zfm9q1j5fwbz          1003134047                2 TABLE ACCESS                   FULL                                 2497

Plan hash value: 1003134047
-----------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                            | Name       | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  |
-----------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                     |            |      1 |        |   133K(100)|      2 |00:03:17.07 |    8886K|   1299K|
|   1 |  UNION-ALL                           |            |      1 |        |            |      2 |00:03:17.07 |    8886K|   1299K|
|*  2 |   TABLE ACCESS FULL                  | G_INDIVIDU |      1 |      1 |   133K  (2)|      2 |00:03:17.07 |    8886K|   1299K|
|   3 |   TABLE ACCESS BY INDEX ROWID BATCHED| G_INDIVIDU |      1 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*  4 |    INDEX RANGE SCAN                  | GINDSIRET  |      1 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
-----------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   2 - filter("TAX_ID"=:STRVAT)
   4 - access("SIRET"=:REGNUM)

Plan hash value: 1003134047

---------------------------------------------------------------------------------------------------
| Id  | Operation                            | Name       | Rows  | Bytes | Cost (%CPU)| Time     |
---------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                     |            |       |       |   133K(100)|          |
|   1 |  UNION-ALL                           |            |       |       |            |          |
|   2 |   TABLE ACCESS FULL                  | G_INDIVIDU |     1 |    11 |   133K  (2)| 00:00:06 |
|   3 |   TABLE ACCESS BY INDEX ROWID BATCHED| G_INDIVIDU |     1 |    13 |     1   (0)| 00:00:01 |
|   4 |    INDEX RANGE SCAN                  | GINDSIRET  |     1 |       |     1   (0)| 00:00:01 |
---------------------------------------------------------------------------------------------------


Predicate Information (identified by operation id):
---------------------------------------------------

   2 - filter("TAX_ID"=:STRVAT)
   4 - access("SIRET"=:REGNUM)

*/
/********************************OLD Metrics***************************************/

/********************************New SQL*******************************************/

No change in the SQL.

/********************************New SQL*******************************************/
/********************************New Metrics***************************************/
/*
Plan hash value: 1293852635

-------------------------------------------------------------------------------------------------------------
| Id  | Operation                            | Name       | Starts | E-Rows | A-Rows |   A-Time   | Buffers |
-------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                     |            |      1 |        |      6 |00:00:00.01 |       7 |
|   1 |  UNION-ALL                           |            |      1 |        |      6 |00:00:00.01 |       7 |
|   2 |   TABLE ACCESS BY INDEX ROWID BATCHED| G_INDIVIDU |      1 |      1 |      6 |00:00:00.01 |       7 |
|*  3 |    INDEX RANGE SCAN                  | TAX_ID_IDX |      1 |      1 |      6 |00:00:00.01 |       2 |
|   4 |   TABLE ACCESS BY INDEX ROWID BATCHED| G_INDIVIDU |      1 |      1 |      0 |00:00:00.01 |       0 |
|*  5 |    INDEX RANGE SCAN                  | GINDSIRET  |      1 |      1 |      0 |00:00:00.01 |       0 |
-------------------------------------------------------------------------------------------------------------

Predicate Information (identified by operation id):
---------------------------------------------------

   3 - access("TAX_ID"=:STRVAT)
   5 - access("SIRET"=:REGNUM)

*/
/********************************New Metrics***************************************/

/********************************Index statistics**********************************/

/********************************Other SQLs****************************************/          
/*

*/ 
/********************************Other SQLs****************************************/              
