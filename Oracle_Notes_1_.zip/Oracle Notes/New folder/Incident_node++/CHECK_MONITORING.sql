===============================================================================================================
#######  Check the monitoring. Start and stop monitoring ######

-bash-4.1$ nsu
Password:

[root@fivatx0012 ~]#  ps -ef |egrep 'pmon|tns' | grep -v egrep;TMOUT=0
root       133     2  0 May21 ?        00:00:00 [netns]
oracle    8658     1  0 17:14 ?        00:00:01 ora_pmon_CTECABST
oragrid  37994     1  0 May21 ?        00:00:37 /grid/12.1.0/bin/tnslsnr LISTENER -no_crs_notify -inherit
oragrid  40718     1  0 May21 ?        00:01:00 asm_pmon_+ASM

[root@fivatx0012 ~]# w
 19:03:43 up 6 days,  3:05,  2 users,  load average: 0.34, 0.18, 0.18
USER     TTY      FROM              LOGIN@   IDLE   JCPU   PCPU WHAT
hprvstav pts/0    132.171.7.8      17:07    1:46m  0.10s  0.01s sshd: hprvstav [priv]
hparmihv pts/1    132.171.7.8      19:03    0.00s  0.05s  0.02s sshd: hparmihv [priv]


[root@fivatx0012 ~]# dbspicao -pdvf
Checking instance: 'CTECABST' @ '/oracle/product/12.1.0.2/db_1':
        Connect:         OKAY
        Filter 6:        OKAY
        Filter 4:        OKAY


[root@fivatx0012 ~]# dbspicfg -e    ( proverqvam kakyv e kynekshyn stringa kym bazata na monitoring-a i dali se vryzva prez listener-a)
SYNTAX_VERSION 4

ORACLE

  HOME "/oracle/product/12.1.0.2/db_1"
    DATABASE "CTECABST" CONNECT "hp_dbspi/hp_dbspi@CTECABST"                 #######(SHTOM IMA "@" OZNACHAVA,CHE SE KYNEKTVA PREZ LISTENER-A)########
           LOGFILE "DISABLED"
           FILTER 6 "TABLESPACE_NAME not like '%UNDO%' and TABLESPACE_NAME not like '%TEMP%' and TABLESPACE_NAME not like '%TMP%'"
           FILTER 4 "username not in ('XS$NULL','ORACLE_OCM','MGMT_VIEW')"

ORA_ASM

  HOME "/grid/12.1.0"
    DATABASE "+ASM" CONNECT "/"
	
	
	su - oracle
	sqlplus hp_dbspi/hp_dbspi@CTECABST
	
	
[root@fivatx0012 ~]# su - oracle
!!!!!!!!!!!!!SET ORACLE SID!!!!!!!!!!!!!!

         Present  Choices:
=========================================

Usage: grep [OPTION]... PATTERN [FILE]...
Try 'grep --help' for more information.


   Current ORACLE_SID=
=========================================
*****************************************************************
The following aliases are available
 * psora - Shows the processes that contains .ora. string
 * cdn - change to network/admin folder
 * sqldba - sqlplus / as sysdba
 * alertlog - tail -100 to the alert.log
 * cdo - change to ORACLE_HOME
 * lsnrstatus - lsnrctl status
********************************************************************
To set the environment for CTECABST type CTECABST
:/home/oracle:fivatx0012.adinfra.net # CTECABST
********************************************************************
             ORACLE BASE: /oracle
             ORACLE HOME: /oracle/product/12.1.0.2/db_1
             ORACLE SID : CTECABST
********************************************************************
The environment is set for instance CTECABST of  database CTECABST


[oracle@fivatx0012:CTECABST ~]$ sqlplus hp_dbspi/hp_dbspi@CTECABST                     ############# tAKA MOJE DA PROVERIM DALI DBSPI-A IMA WRYZKA PREZ LISTENERA KYM BAZATA) ########

SQL*Plus: Release 12.1.0.2.0 Production on Mon May 27 19:08:23 2019

Copyright (c) 1982, 2014, Oracle.  All rights reserved.

Last Successful login time: Tue May 21 2019 15:13:24 +02:00

Connected to:
Oracle Database 12c Enterprise Edition Release 12.1.0.2.0 - 64bit Production
With the Partitioning, Automatic Storage Management, OLAP, Advanced Analytics
and Real Application Testing options


SQL> show parameter db_name;

NAME                                 TYPE        VALUE
------------------------------------ ----------- ------------------------------
db_name                              string      CTECAB
SQL> show parameter unique

NAME                                 TYPE        VALUE
------------------------------------ ----------- ------------------------------
db_unique_name                       string      CTECABST

SQL> Disconnected from Oracle Database 12c Enterprise Edition Release 12.1.0.2.0 - 64bit Production
With the Partitioning, Automatic Storage Management, OLAP, Advanced Analytics
and Real Application Testing options

[oracle@fivatx0012:CTECABST ~]$ logout

[root@fivatx0012 ~]# dbmoncol                                          ##################### S TAZI KOMANDA MOVE DA SPREM I PUSNEM MONITORINGA ##############
Use of uninitialized value in pattern match (m//) at /var/opt/OV/bin/instrumentation/dbmoncol.pl line 248, <CFG> line 771.

ERROR: No arguments
Usage:
        dbmoncol LISTENER <listener owner> <listener name> <ON|OFF|AUTO>
        dbmoncol DATABASE <dbtype> <instance> <BACKUP|SCHEDULED_OUTAGE|STANDBY_CLUSTER|OFF|ON>
        dbmoncol -version

Examples:
        dbmoncol LISTENER ORACLE LISTENER OFF
        dbmoncol LISTENER ORACLE LISTENER1 ON
        dbmoncol LISTENER ORACLE LISTENER1 AUTO

        dbmoncol DATABASE ORACLE openview BACKUP
        dbmoncol DATABASE ORACLE openview SCHEDULED_OUTAGE
        dbmoncol DATABASE ORACLE openview STANDBY_CLUSTER
        dbmoncol DATABASE ORACLE openview OFF
        dbmoncol DATABASE ORACLE openview ON

        dbmoncol DATABASE PROGRESS instance_name ON
        dbmoncol DATABASE PROGRESS instance_name OFF

        dbmoncol DATABASE MYSQL instance_name ON
        dbmoncol DATABASE MYSQL instance_name OFF

        dbmoncol -version
		
[root@fivatx0012 ~]# dbmoncol DATABASE ORACLE CTECABST OFF

[root@fivatx0012 ~]# dbspicao -vpdf
DB-SPI Collection/Analysis has been turned OFF for instance CTECABST


[root@fivatx0012 ~]# dbmoncol DATABASE ORACLE CTECABST ON

[root@fivatx0012 ~]# dbspicao -vpdf
Checking instance: 'CTECABST' @ '/oracle/product/12.1.0.2/db_1':
        Connect:         OKAY
        Filter 6:        OKAY
        Filter 4:        OKAY


 
