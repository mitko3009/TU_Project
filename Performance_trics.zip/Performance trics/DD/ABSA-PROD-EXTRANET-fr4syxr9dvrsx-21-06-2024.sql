/********************************************************************************
*********       E-mail subject: ABSADEV-5483
*********             Instance: PROD V9
*********          Description: 
Problem:
SQL fr4syxr9dvrsx was the TOP SQL for module EXTRANET on 18/06/2024 on ABSA PROD.

Analysis:
The mentioned SQL fr4syxr9dvrsx was found from MPM notification for module EXTRANET on ABSA PROD in ABSA-7193.
The problem in this SQL is that because of the 'in' operator, the Oracle CBO decides that it can use it as a filter, selects a lot of rows 
before that and filter them in the 'in', but in this case we have function utl_indiv_search.FindDebtor in the 'in' operator and this function is 
executed for every selected row before that ( over 130k rows ), which is unnecessary and takes time. The solution here is to move the function in the 
'from' clause as inline view and join it to table g_individu.

Suggestion:
Please change the query as it is shown in the New SQL section below.

*********               SQL_ID: fr4syxr9dvrsx
*********      Program/Package: 
*********              Request: Ninh Ngoc Nguyen
*********               Author: Dimitar Dimitrov
********* Received e-mail date: 18/06/2024
*********      Resolution date: 21/06/2024
*********  Trace old file here: \\epox\specifs\performance\tmp\
*********  Trace new file here:
***********************************************************************************/

/********************************OLD SQL*******************************************/

var B1 VARCHAR2(32);
exec :B1 := 'A60020GM'
var B2 VARCHAR2(32);
exec :B2 := 'ADA056'
var B3 VARCHAR2(32);
exec :B3 := 'A60020GM';
var B4 VARCHAR2(32);
exec :B4 := '';
var B5 VARCHAR2(32);
exec :B5 := 'AN';




SELECT DISTINCT i.refindividu refindividu,
                nom name,
                tva vat,
                cp cp,
                ville city,
                i.siret siret,
                i.regcomm regcomm,
                i.pays pays,
                DECODE(i.pays,
                       'FRA',
                       i.siret,
                       (SELECT CASE autorise
                                 WHEN 'O' THEN
                                  i.tva
                                 ELSE
                                  i.regcomm
                               END
                          FROM v_domaine vd
                         WHERE vd.TYPE = 'pays'
                           AND vd.abrev = i.pays)) national_id,
                NVL(c.valeur_trad, c.valeur) country,
                '' currency,
                '' refdoss,
                str79 cRegNum,
                (SELECT refext
                   FROM t_individu
                  WHERE societe = 'CLIENT_NUMBER'
                    AND refext2 = :B1
                    AND refext = :B2
                    AND ROWNUM < 2) refext,
                i.adr1 address,
                i.adr2 address2,
                i.division state,
                i.STR86 tmpIndividu,
                NVL(i.str86, 'X') tmp,
                ti.refext creditInsurerNum,
                (CASE
                  WHEN ti.societe = 'EASY_NUMBER' THEN
                   'COFACE'
                  WHEN ti.societe = 'REF_ATRADIUS' THEN
                   'ATRADUIS'
                  WHEN ti.societe = 'EH ID' THEN
                   'EH'
                END) as societe
  FROM g_individu i, 
       v_tdomaine c, 
       t_individu ti
 WHERE i.refindividu in
       (SELECT COLUMN_VALUE refindividu
          FROM TABLE(utl_indiv_search.FindDebtor(:B3,
                                                 upper(:B4),
                                                 UPPER((SELECT refext
                                                          FROM t_individu
                                                         WHERE societe = 'CLIENT_NUMBER'
                                                           AND refext2 = :B1
                                                           AND refext = :B2
                                                           AND ROWNUM < 2)),
                                                 :B4,
                                                 upper(:B4),
                                                 upper(:B4),
                                                 NULL,
                                                 NULL,
                                                 :B4,
                                                 :B4,
                                                 :B4,
                                                 NULL,
                                                 NULL,
                                                 :B4,
                                                 :B4)))
   AND c.type = 'pays'
   AND NVL(c.langue, 'FR') = NVL(UPPER(:B5), 'FR')
   AND c.abrev = i.pays
   AND ti.REFINDIVIDU(+) = i.REFINDIVIDU
   AND ti.societe(+) in ('EASY_NUMBER', 'REF_ATRADIUS', 'EH ID')
 ORDER BY name;
/********************************OLD SQL*******************************************/
/********************************OLD Metrics***************************************/
/*

MODULE                    SQL_ID         PLAN_HASH SID    SERIAL# EVENT                          FROM                           TO                                 ACTIVE NUMBER_OF_EXECUTIONS PERC
------------------------- ------------- ---------- ------ ------- ------------------------------ ------------------------------ ------------------------------ ---------- -------------------- ------
EXTRANET                  fr4syxr9dvrsx            1722   20282   ON CPU                         2024/06/18 08:08:26            2024/06/18 15:25:23                   470              6174412 24%
EXTRANET                  6pj9r5vbdk2yq   41573073                ON CPU                         2024/06/18 07:58:23            2024/06/18 16:18:25                   280                 7751 14%
EXTRANET                  c2rg74b1vt0k2  260108809 1722   20282                                  2024/06/18 08:05:25            2024/06/18 14:01:53                   220                   26 11%
EXTRANET                  7w7tyus3wdrma 4292461729 1722   20282                                  2024/06/18 09:17:01            2024/06/18 14:38:12                   160                    3 8%
EXTRANET                  7t5skdxhszfhs 3631935574 1722   20282   ON CPU                         2024/06/18 09:09:29            2024/06/18 15:29:43                   140              5265341 7%
EXTRANET                  831j4r9w7pfzd  837440010                ON CPU                         2024/06/18 09:09:29            2024/06/18 14:26:29                    80              1100150 4%



Plan hash value: 938940927
-------------------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                   | Name                    | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  |
-------------------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                            |                         |      1 |        |  3097K(100)|      1 |00:00:07.27 |     879K|   3826 |
|   1 |  TABLE ACCESS BY INDEX ROWID BATCHED        | V_DOMAINE               |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       4 |      0 |
|*  2 |   INDEX RANGE SCAN                          | DOM_TYPABREV            |      1 |      2 |     1   (0)|      1 |00:00:00.01 |       3 |      0 |
|*  3 |  COUNT STOPKEY                              |                         |      1 |        |            |      1 |00:00:00.01 |       3 |      0 |
|*  4 |   INDEX RANGE SCAN                          | SOC_INDIV               |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |      0 |
|   5 |  SORT ORDER BY                              |                         |      1 |   8232 |  3097K  (1)|      1 |00:00:07.27 |     879K|   3826 |
|   6 |   HASH UNIQUE                               |                         |      1 |   8232 |  3096K  (1)|      1 |00:00:07.27 |     879K|   3826 |
|*  7 |    FILTER                                   |                         |      1 |        |            |      1 |00:00:07.27 |     879K|   3826 |
|   8 |     NESTED LOOPS                            |                         |      1 |   8232 |  3092K  (1)|      1 |00:00:07.27 |     879K|   3826 |
|*  9 |      HASH JOIN                              |                         |      1 |    140K|  1514   (1)|    136K|00:00:02.34 |     198K|   3808 |
|  10 |       TABLE ACCESS BY INDEX ROWID BATCHED   | V_DOMAINE               |      1 |    103 |     1   (0)|    261 |00:00:00.01 |     323 |      6 |
|* 11 |        INDEX RANGE SCAN                     | V_DOMAINE_TYPE_CODE_IDX |      1 |    103 |     1   (0)|    261 |00:00:00.01 |       5 |      3 |
|  12 |       MERGE JOIN OUTER                      |                         |      1 |    145K|  1513   (1)|    139K|00:00:02.28 |     197K|   3802 |
|  13 |        TABLE ACCESS BY INDEX ROWID          | G_INDIVIDU              |      1 |    139K|   516   (0)|    139K|00:00:02.18 |     197K|   3801 |
|  14 |         INDEX FULL SCAN                     | IND_REFINDIV            |      1 |    139K|     4   (0)|    139K|00:00:00.02 |     384 |      1 |
|* 15 |        SORT JOIN                            |                         |    139K|  55245 |   997   (1)|      0 |00:00:00.03 |       8 |      1 |
|  16 |         INLIST ITERATOR                     |                         |      1 |        |            |      0 |00:00:00.01 |       8 |      1 |
|  17 |          TABLE ACCESS BY INDEX ROWID BATCHED| T_INDIVIDU              |      3 |  55245 |   513   (0)|      0 |00:00:00.01 |       8 |      1 |
|* 18 |           INDEX RANGE SCAN                  | SOC_INDIV               |      3 |  55245 |     4   (0)|      0 |00:00:00.01 |       8 |      1 |
|* 19 |      COLLECTION ITERATOR PICKLER FETCH      | FINDDEBTOR              |    136K|      1 |    22   (0)|      1 |00:00:04.89 |     681K|     18 |
|* 20 |       COUNT STOPKEY                         |                         |      1 |        |            |      1 |00:00:00.01 |       4 |      2 |
|* 21 |        INDEX RANGE SCAN                     | SOC_INDIV               |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       4 |      2 |
-------------------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   2 - access("VD"."TYPE"='pays' AND "VD"."ABREV"=:B1)
   3 - filter(ROWNUM<2)
   4 - access("SOCIETE"='CLIENT_NUMBER' AND "REFEXT"=:B2 AND "REFEXT2"=:B1)
   7 - filter(NVL(UPPER(:B5),'FR')='AN')
   9 - access("ABREV"="I"."PAYS")
  11 - access("TYPE"='pays')
  15 - access("TI"."REFINDIVIDU"="I"."REFINDIVIDU")
       filter("TI"."REFINDIVIDU"="I"."REFINDIVIDU")
  18 - access(("TI"."SOCIETE"='EASY_NUMBER' OR "TI"."SOCIETE"='EH ID' OR "TI"."SOCIETE"='REF_ATRADIUS'))
  19 - filter("I"."REFINDIVIDU"=VALUE(KOKBF$))
  20 - filter(ROWNUM<2)
  21 - access("SOCIETE"='CLIENT_NUMBER' AND "REFEXT"=:B2 AND "REFEXT2"=:B1)
*/
/********************************OLD Metrics***************************************/

/********************************New SQL*******************************************/

SELECT DISTINCT i.refindividu refindividu,
                nom name,
                tva vat,
                cp cp,
                ville city,
                i.siret siret,
                i.regcomm regcomm,
                i.pays pays,
                DECODE(i.pays,
                       'FRA',
                       i.siret,
                       (SELECT CASE autorise
                                 WHEN 'O' THEN
                                  i.tva
                                 ELSE
                                  i.regcomm
                               END
                          FROM v_domaine vd
                         WHERE vd.TYPE = 'pays'
                           AND vd.abrev = i.pays)) national_id,
                NVL(c.valeur_trad, c.valeur) country,
                '' currency,
                '' refdoss,
                str79 cRegNum,
                (SELECT refext
                   FROM t_individu
                  WHERE societe = 'CLIENT_NUMBER'
                    AND refext2 = :B1
                    AND refext = :B2
                    AND ROWNUM < 2) refext,
                i.adr1 address,
                i.adr2 address2,
                i.division state,
                i.STR86 tmpIndividu,
                NVL(i.str86, 'X') tmp,
                ti.refext creditInsurerNum,
                (CASE
                  WHEN ti.societe = 'EASY_NUMBER' THEN
                   'COFACE'
                  WHEN ti.societe = 'REF_ATRADIUS' THEN
                   'ATRADUIS'
                  WHEN ti.societe = 'EH ID' THEN
                   'EH'
                END) as societe
  FROM g_individu i, 
       v_tdomaine c, 
       t_individu ti,       
       ( SELECT COLUMN_VALUE refindividu
           FROM TABLE(utl_indiv_search.FindDebtor(:B3,
                                                  upper(:B4),
                                                  UPPER((SELECT refext
                                                           FROM t_individu
                                                          WHERE societe = 'CLIENT_NUMBER'
                                                            AND refext2 = :B1
                                                            AND refext = :B2
                                                            AND ROWNUM < 2)),
                                                   :B4,
                                                   upper(:B4),
                                                   upper(:B4),
                                                   NULL,
                                                   NULL,
                                                   :B4,
                                                   :B4,
                                                   :B4,
                                                   NULL,
                                                   NULL,
                                                   :B4,
                                                   :B4)) ) re
 WHERE i.refindividu = re.refindividu
   AND c.type = 'pays'
   AND NVL(c.langue, 'FR') = NVL(UPPER(:B5), 'FR')
   AND c.abrev = i.pays
   AND ti.REFINDIVIDU(+) = i.REFINDIVIDU
   AND ti.societe(+) in ('EASY_NUMBER', 'REF_ATRADIUS', 'EH ID')
 ORDER BY name;
/********************************New SQL*******************************************/
/********************************New Metrics***************************************/
/*
Plan hash value: 110354236
-------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                | Name                    | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers |
-------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                         |                         |      1 |        |  5163 (100)|      1 |00:00:00.01 |     347 |
|   1 |  TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE               |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       4 |
|*  2 |   INDEX RANGE SCAN                       | DOM_TYPABREV            |      1 |      2 |     1   (0)|      1 |00:00:00.01 |       3 |
|*  3 |  COUNT STOPKEY                           |                         |      1 |        |            |      1 |00:00:00.01 |       3 |
|*  4 |   INDEX RANGE SCAN                       | SOC_INDIV               |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |
|   5 |  SORT ORDER BY                           |                         |      1 |   8232 |  5163   (1)|      1 |00:00:00.01 |     347 |
|   6 |   HASH UNIQUE                            |                         |      1 |   8232 |  4811   (1)|      1 |00:00:00.01 |     347 |
|*  7 |    FILTER                                |                         |      1 |        |            |      1 |00:00:00.01 |     340 |
|   8 |     NESTED LOOPS OUTER                   |                         |      1 |   8232 |   343   (0)|      1 |00:00:00.01 |     340 |
|*  9 |      HASH JOIN                           |                         |      1 |   7878 |   107   (0)|      1 |00:00:00.01 |     335 |
|  10 |       TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE               |      1 |    103 |     1   (0)|    261 |00:00:00.01 |     323 |
|* 11 |        INDEX RANGE SCAN                  | V_DOMAINE_TYPE_CODE_IDX |      1 |    103 |     1   (0)|    261 |00:00:00.01 |       5 |
|  12 |       NESTED LOOPS                       |                         |      1 |   8168 |   106   (0)|      1 |00:00:00.01 |      12 |
|  13 |        NESTED LOOPS                      |                         |      1 |   8168 |   106   (0)|      1 |00:00:00.01 |      10 |
|  14 |         COLLECTION ITERATOR PICKLER FETCH| FINDDEBTOR              |      1 |   8168 |    24   (0)|      1 |00:00:00.01 |       8 |
|* 15 |          COUNT STOPKEY                   |                         |      1 |        |            |      1 |00:00:00.01 |       3 |
|* 16 |           INDEX RANGE SCAN               | SOC_INDIV               |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |
|* 17 |         INDEX UNIQUE SCAN                | IND_REFINDIV            |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       2 |
|  18 |        TABLE ACCESS BY INDEX ROWID       | G_INDIVIDU              |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       2 |
|* 19 |      TABLE ACCESS BY INDEX ROWID BATCHED | T_INDIVIDU              |      1 |      1 |     1   (0)|      0 |00:00:00.01 |       5 |
|* 20 |       INDEX RANGE SCAN                   | IX_T_INDIVIDU           |      1 |      2 |     1   (0)|      2 |00:00:00.01 |       3 |
-------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   2 - access("VD"."TYPE"='pays' AND "VD"."ABREV"=:B1)
   3 - filter(ROWNUM<2)
   4 - access("SOCIETE"='CLIENT_NUMBER' AND "REFEXT"=:B2 AND "REFEXT2"=:B1)
   7 - filter(NVL(UPPER(:B5),'FR')='AN')
   9 - access("ABREV"="I"."PAYS")
  11 - access("TYPE"='pays')
  15 - filter(ROWNUM<2)
  16 - access("SOCIETE"='CLIENT_NUMBER' AND "REFEXT"=:B2 AND "REFEXT2"=:B1)
  17 - access("I"."REFINDIVIDU"=VALUE(KOKBF$))
  19 - filter(("TI"."SOCIETE"='EASY_NUMBER' OR "TI"."SOCIETE"='EH ID' OR "TI"."SOCIETE"='REF_ATRADIUS'))
  20 - access("TI"."REFINDIVIDU"="I"."REFINDIVIDU")
*/
/********************************New Metrics***************************************/

/********************************Index statistics**********************************/

/********************************Other SQLs****************************************/          
/*

*/ 
/********************************Other SQLs****************************************/              
