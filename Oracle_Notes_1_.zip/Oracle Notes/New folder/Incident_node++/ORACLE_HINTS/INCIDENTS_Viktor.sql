###########################################################################################################################################################################################################################################
###########################################################################################################################################################################################################################################
###########################################################################################################################################################################################################################################
BACKUPS:

omnistat -det
###############################################
###############################################
ADIDAS BACKUPS:

1. su - usera
2. setva se envirementa
3. cdrman
4. rman cmdfile=backup_online_arch_OSDEV.rman log=backup_online_arch_OSDEV`date +%Y%m%d%H%M`.log


rman cmdfile=backup_online_arch_OSTST.rman log=backup_online_arch_OSTST`date +%Y%m%d%H%M`.log

omnib -oracle8 ORA_ARCHDEL_RBLTDCA1_HPDW_2MECH 

###############################################
###############################################
#### NETBACKUP ####
[root@]bpadm  <--- startirane ot cell servera

/usr/openv/netbackup/logs/user_ops/dbext/oracle <--- tuk sa logovete ot rman-a

===================NETBACKUP====================================================
kacvame se na backup sell-a

bpadm s root


sledvash menu 4 - manula backup - 
specifikaciq (m-Manual Backup - e-Spe

v taq dir mojesh da sledish kakvo se backupva ot clientskiq server
/usr/openv/netbackup/logs/user_ops/dbext/oracle/
ls -lart
tail -f posledniq syzdaden *.log

###############################################
###############################################
OMNIB FULL PATH:

/opt/omni/bin/omnib

###############################################
###############################################
EON BACKUPS TSM:

switchvash v usera na bazata "oracle naprimer"

cd /tsm

ls

cd v bazata

ls -al

./StartRedolog.sh <-- tova e vzeto ot bazata na koqto e pusnat backup-a dokato se ucha. Smenq se sas StartRedolog-a na dadenata baza.


###############################################
###############################################
INFORMIX ARCHIVELOG BACKUP FCC:

Kachvame se s informix user-a (Ima go v security tab-a)

onstat -l    <-- Vadi statusa na logovete

onstat -b -l    <--- Puska Archivelog backup-a


ona2aqifx023p0 - instance name
a2aqifx023p - server name

###############################################
###############################################
CHECK BACKUP IN DAYS

set lines 220
set pages 1000
col cf for 11
col df for 11
col elapsed_seconds heading "ELAPSED|SECONDS"
col i0 for 11
col i1 for 11
col l for 11
col END_TIME for a20
col DOW for a10
col output_mbytes for 9,999,999 heading "OUTPUT|MBYTES"
col session_recid for 999999 heading "SESSION|RECID"
col session_stamp for 99999999999 heading "SESSION|STAMP"
col status for a10 trunc
col time_taken_display for a10 heading "TIME|TAKEN"
col output_instance for 9999 heading "OUT|INST"
select
  j.session_recid, j.session_stamp,
  to_char(j.start_time, 'yyyy-mm-dd hh24:mi:ss') start_time,
  to_char(j.end_time, 'yyyy-mm-dd hh24:mi:ss') end_time,
  (j.output_bytes/1024/1024) output_mbytes, j.status, j.input_type,
  decode(to_char(j.start_time, 'd'), 1, 'Sunday', 2, 'Monday',
                                     3, 'Tuesday', 4, 'Wednesday',
                                     5, 'Thursday', 6, 'Friday',
                                     7, 'Saturday') dow,
  j.elapsed_seconds, j.time_taken_display,
  x.cf, x.df, x.i0, x.i1, x.l,
  ro.inst_id output_instance
from V$RMAN_BACKUP_JOB_DETAILS j
  left outer join (select
                     d.session_recid, d.session_stamp,
                     sum(case when d.controlfile_included = 'YES' then d.pieces else 0 end) CF,
                     sum(case when d.controlfile_included = 'NO'
                               and d.backup_type||d.incremental_level = 'D' then d.pieces else 0 end) DF,
                     sum(case when d.backup_type||d.incremental_level = 'D0' then d.pieces else 0 end) I0,
                     sum(case when d.backup_type||d.incremental_level = 'I1' then d.pieces else 0 end) I1,
                     sum(case when d.backup_type = 'L' then d.pieces else 0 end) L
                   from
                     V$BACKUP_SET_DETAILS d
                     join V$BACKUP_SET s on s.set_stamp = d.set_stamp and s.set_count = d.set_count
                   where s.input_file_scan_only = 'NO'
                   group by d.session_recid, d.session_stamp) x
    on x.session_recid = j.session_recid and x.session_stamp = j.session_stamp
  left outer join (select o.session_recid, o.session_stamp, min(inst_id) inst_id
                   from GV$RMAN_OUTPUT o
                   group by o.session_recid, o.session_stamp)
    ro on ro.session_recid = j.session_recid and ro.session_stamp = j.session_stamp
where j.start_time > trunc(sysdate)-&NUMBER_OF_DAYS
order by j.start_time;

###############################################
###############################################
BACKUP PROGRESS CHECK:

select SID, START_TIME,TOTALWORK, sofar, (sofar/totalwork) * 100 done,
sysdate + TIME_REMAINING/3600/24 end_at
from v$session_longops
where totalwork > sofar
AND opname NOT LIKE '%aggregate%'
AND opname like 'RMAN%'
/

###############################################
###############################################
RUNNING AND COMPLETED BACKUPS:

set lines 400 pages 100
col device for a8
col time_taken for a8
col START__TIME for a19
col END_TIME for a19
column TIME_TAKEN_DISPLAY format a40;
col status for a28
select command_id,TO_CHAR(start_time, 'MM/DD/YY HH24:MI:SS') as start__time,
TO_CHAR(end_time, 'MM/DD/YY HH24:MI:SS') as end_time, output_device_type as device,input_type,time_taken_display as time_taken, status 
from V_$RMAN_BACKUP_JOB_DETAILS order by start_time;

###############################################
###############################################
ARCH FILES DURING LAST DAYS

SELECT to_char(FIRST_TIME, 'YYYY/MM/DD HH24') "Date and hour", count(to_char(FIRST_TIME, 'YYYY/MM/DD-HH24')) "Count redo switch", ROUND(SUM(BLOCK_SIZE * NVL(BLOCKS ,BLOCKS))/1024/1024) MB_size 
from v$archived_log 
where dest_id=1
and FIRST_TIME between trunc(sysdate-3) and sysdate 
GROUP BY to_char(FIRST_TIME, 'YYYY/MM/DD HH24') 
order by 1 
/ 

###############################################
###############################################
Delete already backed up arhchive logs:

DELETE ALL BACKED UP 1 TIMES TO DEVICE TYPE sbt;



###############################################
###############################################
SHOW LONG RUNNING OPERATIONS:

set linesize 400
col TARGET for a28
col TARGET_DESC for a16
col UNITS for a10
col TIME_REMAINING for a20
col START_TIME for a20
col LAST_UPDATE_TIME for a20
col SOFAR for c13
col TOTALWORK for c13
SELECT inst_id,SID, SERIAL#, to_char(START_TIME, 'YYYY/MON/DD HH:MI:SS') "START_TIME",
to_char(LAST_UPDATE_TIME, 'YYYY/MON/DD HH:MI:SS') "LAST_UPDATE_TIME",
TIME_REMAINING/60 as "remaining mins",
TARGET, TARGET_DESC, SOFAR,
TOTALWORK, UNITS, ROUND(SOFAR/TOTALWORK*100,2) "%_COMPLETE"
FROM GV$SESSION_LONGOPS
WHERE
TOTALWORK != 0
AND SOFAR <> TOTALWORK
order by START_TIME;


###############################################
###############################################
BACKUP SIZES:

select ctime "Date"
     , decode(backup_type, 'L', 'Archive Log', 'D', 'Full', 'Incremental') backup_type
     , bsize "Size MB"
from (select trunc(bp.completion_time) ctime
        , backup_type
        , round(sum(bp.bytes/1024/1024),2) bsize
   from v$backup_set bs, v$backup_piece bp
   where bs.set_stamp = bp.set_stamp
   and bs.set_count  = bp.set_count
   and bp.status = 'A'
   group by trunc(bp.completion_time), backup_type)
order by 1, 2;

	 /opt/omni/bin/omnidb -datalist "Oracle8 gemb_dk_mydkslhpod701_ora_DNETLLOAD_daily_full_on" -ses -last 3

	
	################ DATA BLOCK CORRUPTION ########################

	select *
from dba_extents
where file_id = &DATA_FILE_ID
and &CORRUPTED_BLOCK_ID between block_id AND block_id + blocks - 1;

########## CHECK RMAN ADVISE #####

	RMAN> LIST FAILURE;

####### How many Archives are being generated for 10 days ###

select sum ((blocks+1)*BLOCK_SIZE)/1024/1024 as "MB_archlogs", to_char(COMPLETION_TIME, 'YYYY/MM/DD') as "DATE"�
from v$archived_log where COMPLETION_TIME > sysdate-10 and DEST_ID =1 group by to_char(COMPLETION_TIME, 'YYYY/MM/DD')�
order by to_char(COMPLETION_TIME, 'YYYY/MM/DD');



###############################################
###############################################
BACKUP PIECES:   - FINDKING THE BACKUP SPECIFICATION

SET LINESIZE 145
SET PAGESIZE 9999 
COLUMN bs_key FORMAT 9999 HEADING 'BS|Key'
COLUMN piece# FORMAT 99999 HEADING 'Piece|#'
COLUMN copy# FORMAT 9999 HEADING 'Copy|#'
COLUMN bp_key FORMAT 9999 HEADING 'BP|Key'
COLUMN status FORMAT a9 HEADING 'Status'
COLUMN handle FORMAT a65 HEADING 'Handle'
COLUMN start_time FORMAT a17 HEADING 'Start|Time'
COLUMN completion_time FORMAT a17 HEADING 'End|Time'
COLUMN elapsed_seconds FORMAT 999,999 HEADING 'Elapsed|Seconds'
COLUMN deleted FORMAT a8 HEADING 'Deleted?'
BREAK ON bs_key
prompt
prompt Available backup pieces contained in the control file.
prompt Includes available and expired backup sets.
prompt 
SELECT
bs.recid bs_key
, bp.piece# piece#
, bp.copy# copy#
, bp.recid bp_key
, DECODE( status
, 'A', 'Available'
, 'D', 'Deleted'
, 'X', 'Expired') status
, handle handle
, TO_CHAR(bp.start_time, 'mm/dd/yy HH24:MI:SS') start_time
, TO_CHAR(bp.completion_time, 'mm/dd/yy HH24:MI:SS') completion_time
, bp.elapsed_seconds elapsed_seconds
FROM
v$backup_set bs
, v$backup_piece bp
WHERE
bs.set_stamp = bp.set_stamp
AND bs.set_count = bp.set_count
AND bp.status IN ('A', 'X')
ORDER BY
bs.recid
, piece#
/


###############################################
###############################################
CHECKING FRA:

set lines 300
select * from v$flash_recovery_area_usage;

find /efro_p/orabck/rman  -xdev -type f -mtime +10 -name  "EFRO_P_20*" -exec rm -rf {} \; 2>/dev/null

###########################################################################################################################################################################################################################################
###########################################################################################################################################################################################################################################
###########################################################################################################################################################################################################################################
UXMON:

###############################################
###############################################
INODE:
df -i																		###########################################################
find . -xdev -name "*.aud" -type f -mtime +30 -exec rm -f {} ;		###           Triqt se stari audit file-ove             ###
find . -mtime +20 \( -name "*.aud" \) -exec rm {} \;																			###########################################################

###############################################
###############################################
LARGEST FILES IN FS CHECKS:

find . -xdev  -size +10000c -type f -exec ls -al {} \; |sort -k5nr |head -300
find . -xdev -mtime 0 -size +10000c -type f -exec ls -al {} \; |sort -k5nr |head -100
find . -xdev  -size +10000c -type f -exec ls -la {} \; 2> /dev/null | sort -n -k5 | tail -5000

###############################################
###############################################
LOG GZIP:

gzip -9cv alert_SDWP.log> alert_SDWP.log.`date +%Y%m%d`.log.gz && > alert_SDWP.log


###############################################
###############################################
TRC, TRM, AUD GZIP:
find . -xdev -name "*.trm" -type f -exec gzip -9f {} \;
find . -xdev -name "*.trm" -type f -mtime +1 -exec gzip -9f {} \;
find . -xdev -name "*.aud" -type f -mtime +2 -exec gzip -9f {} \;

 
###############################################
###############################################
TRC,TRM TRUNCATE:

find . -mtime +1 \( -name "*.trc" -o -name "*.trm" -o -name "*.aud" \) -exec rm {} \;
find . -mtime +2 \( -name "*.trc" -o -name "*.trm" \) -exec rm -f {} \;

find . -mtime +15 \( -name "oracle_*" \) -exec rm -f {} \;


###############################################
###############################################
TRC, TRM CHECK FOR FILES USED BY FUSER:

for f in `ls *.trm *.trc`; do
PROC=`fuser $f`
if [ -n "$PROC" ]; then
echo Skipping file $f. Running process $PROC
continue
fi
echo $f
done

------------------------------------------------------------------
DELETE ALL TRC, TRM NOT USER BY FUSER:

for f in `ls *.trm *.trc`; do
PROC=`fuser $f`
if [ -n "$PROC" ]; then
echo Skipping file $f. Running process $PROC
continue
fi
rm -f $f
done



###############################################
###############################################
DELETE CORE FILES - ONLY OLDER THAN 5 DAYS

find . -mtime +5 \( -name "core_*" \) -exec rm -R {} \;

gzip -9cv core.26321> core.26321.`date +%Y%m%d`.log.gz && > core.26321

###############################################
###############################################
AUD DELETE:

find . -name \*.aud  -exec rm -f {} \;


###############################################
###############################################
XML GZIP:

find . \( -name "heat.sqlite-*"  \) -exec gzip -9vf {} \;
find . -mtime +2 \( -name "*.xml"  \) -exec gzip -9vf {} \;
find . -mtime +3 \( -name "log_*.xml"  \) -exec gzip -9vf {} \;

find . \( -name "*.gz"  \) -mtime +150 -exec rm -f {} \;

###############################################
###############################################
DELETING FLASHBACK LOGS "FLB"

show parameter DB_FLASHBACK_RETENTION_TARGET = set to lower value ( 60 minutes )

alter system set DB_FLASHBACK_RETENTION_TARGET = set to lower value ( 60 minutes )

show parameter dest - check for the db_recovery_file_dest_size

alter system set db_recovery_file_dest_size= half ( doing pressure )

Return the original values


###############################################
###############################################
HIGH WATERMARK SCRIPT:

SET pagesize 300
SET pagesize 300
SET linesize 300
COL "Resize Command" for a110
SELECT 'alter database datafile '''||file_name||''' resize '|| 
DECODE(trunc(ceil( (nvl(hwm,1)*(size_db_block))/1024/1024 ) /10),0 ,10, ceil( (nvl(hwm,1)* (size_db_block))/1024/1024 )) ||'M;' "Resize Command", 
AUTOEXTENSIBLE , bytes/1024/1024 "CurrentSize(Mb)" , 
( (bytes/1024/1024) - ceil( (nvl(hwm,1)* (size_db_block))/1024/1024 ) ) "FreeSize(Mb)"
FROM dba_data_files a, 
( SELECT /* +RULE */ file_id, max(block_id+blocks-1) AS hwm FROM dba_extents GROUP BY file_id ) b , 
(SELECT TO_NUMBER(value) AS size_db_block FROM v$parameter WHERE name = 'db_block_size') c
WHERE a.file_id = b.file_id(+) AND AUTOEXTENSIBLE='YES' 
AND ceil(blocks*(c.size_db_block)/1024/1024)- ceil((nvl(hwm,1)*(c.size_db_block))/1024/1024 ) > 10 ORDER BY "FreeSize(Mb)" ASC;

!!!!!!!!!!!!! Without sysaux, undo, system

HIGH WATERMARK SCRIPT v2:

SET SERVEROUTPUT ON 
DECLARE
BEGIN
----purge recyclebin
execute immediate 'purge dba_recyclebin';
----Resize all files to HWM except UNDO
FOR cmd in (SELECT /*+ RULE */ 'alter database datafile '''||file_name||''' resize '|| 
			DECODE(trunc(ceil( (nvl(hwm,1)*(size_db_block))/1024/1024 ) /10),0 ,10, ceil( (nvl(hwm,1)* (size_db_block))/1024/1024 )) ||'M' Resize
			FROM dba_data_files a, 
			( SELECT  file_id, max(block_id+blocks-1) AS hwm FROM dba_extents GROUP BY file_id ) b , 
			(SELECT TO_NUMBER(value) AS size_db_block FROM v$parameter WHERE name = 'db_block_size') c
			WHERE a.file_id = b.file_id(+) AND AUTOEXTENSIBLE='YES' and a.tablespace_name not in (select tablespace_name from dba_tablespaces where CONTENTS='UNDO')
			AND ceil(blocks*(c.size_db_block)/1024/1024)- ceil((nvl(hwm,1)*(c.size_db_block))/1024/1024 ) > 10)
LOOP
BEGIN
DBMS_OUTPUT.PUT_LINE('Executing '||cmd.Resize);
execute immediate(cmd.Resize);
EXCEPTION
WHEN OTHERS THEN
	DBMS_OUTPUT.PUT_LINE('Error Executing '||cmd.Resize);
END;
END LOOP;
END;
/

###############################################
###############################################
Zombie process - Zoooooooooombiessssssss

ps axo stat,ppid,pid,comm | grep -w defunct

Kill them all:
kill -9 $(ps -A -ostat,ppid | grep -e '[zZ]'| awk '{ print $2 }')Be 

###############################################
###############################################
UNDO FREESPACE

select a.tablespace_name, SIZEMB, USAGEMB, (SIZEMB - USAGEMB) FREEMB
from (select sum(bytes) / 1024 / 1024 SIZEMB, b.tablespace_name
from dba_data_files a, dba_tablespaces b
where a.tablespace_name = b.tablespace_name
and b.contents = 'UNDO'
group by b.tablespace_name) a,
(select c.tablespace_name, sum(bytes) / 1024 / 1024 USAGEMB
from DBA_UNDO_EXTENTS c
where status <> 'EXPIRED'
group by c.tablespace_name) b
where a.tablespace_name = b.tablespace_name; 

###############################################
###############################################
CHECK QUERY - ORA-01555 

set long 20000
set pages 500
select SQL_FULLTEXT from v$sql where sql_id='dtuauqqu14vfs';

###############################################
###############################################
DROPPING ALL OBJECTS OF THE GIVEN SCHEMA

SET serveroutput ON
 DECLARE
 l_execute varchar2(2000);
 c_execute varchar2(2000);
 m_execute varchar2(2000);
 j_execute varchar2(2000);
 t_execute varchar2(2000);
 schema_owner varchar2(100);
 BEGIN
 DBMS_OUTPUT.ENABLE(1000000);
 SELECT USER INTO schema_owner FROM DUAL WHERE USER NOT IN ('SYS','SYSTEM','OUTLN','DBSNMP');
 
 
 IF UPPER(schema_owner) = UPPER('&schemaname')
 THEN
 -- Clean JOBS
 
  FOR r_job IN (SELECT object_type
 , object_name
 FROM   user_objects
 WHERE  object_type IN ('JOB'))
  loop
  begin
  execute immediate 'begin DBMS_SCHEDULER.DROP_JOB('''||r_job.object_name||'''); end;';
 
  EXCEPTION
  WHEN OTHERS THEN NULL;
  dbms_output.put_line ('PURGE RECYCLEBIN');
  execute immediate 'purge recyclebin';
  end;
 end loop;
 
   -- Clean AQ objects first
 
 FOR x IN (SELECT name FROM user_queues WHERE queue_type = 'NORMAL_QUEUE'
              ) LOOP
     BEGIN
        execute immediate 'begin DBMS_AQADM.stop_queue('''||x.name||'''); end;';
        EXCEPTION WHEN OTHERS THEN NULL;
     END;
   END LOOP;
 
 
  BEGIN
        execute immediate 'DBMS_LOCK.sleep(8)';
        EXCEPTION WHEN OTHERS THEN NULL;
     END;
 
 FOR x IN (SELECT name FROM user_queues WHERE queue_type = 'NORMAL_QUEUE'
              ) LOOP
     BEGIN
         execute immediate 'begin DBMS_AQADM.drop_queue('''||x.name||''', TRUE); end;';
         EXCEPTION WHEN OTHERS THEN NULL;
     END;
   END LOOP;
 
  FOR x IN (SELECT queue_table FROM user_queue_tables
              ) LOOP
     BEGIN
        execute immediate 'begin DBMS_AQADM.DROP_QUEUE_TABLE('''||x.queue_table||''', force => TRUE); end;';
        EXCEPTION WHEN OTHERS THEN NULL;
     END;
   END LOOP;
 
   FOR x IN (SELECT TABLE_NAME FROM user_tables WHERE TABLE_NAME LIKE 'AQ_%'
              ) LOOP
     BEGIN
      execute immediate 'begin DBMS_AQADM.DROP_QUEUE_TABLE('''||x.TABLE_NAME||''',  force => TRUE); end;';
        EXCEPTION WHEN OTHERS THEN NULL;
     END;
   END LOOP;
 
 
   -- Clean JAVA objects
   FOR r_java IN (SELECT object_type, object_name
                    FROM user_objects
                   WHERE object_type IN ('JAVA SOURCE','JAVA CLASS','JAVA RESOURCE'))
   LOOP
      BEGIN
        j_execute:= 'drop '||r_java.object_type||' "'||r_java.object_name||'"';
        dbms_output.put_line(j_execute);  
        EXECUTE IMMEDIATE j_execute;
        EXCEPTION WHEN OTHERS THEN NULL;
        dbms_output.put_line ('PURGE RECYCLEBIN');
        execute immediate 'purge recyclebin';
      END;
   END LOOP;
 
   -- Clean MATERIALIZED VIEW objects
   FOR r_mview IN (SELECT object_type ,object_name
                     FROM   user_objects
                    WHERE  object_type IN ('MATERIALIZED VIEW'))
   LOOP
      BEGIN
      m_execute:= 'drop '||r_mview.object_type||' "'||r_mview.object_name||'"';
      dbms_output.put_line(m_execute);  
      EXECUTE IMMEDIATE m_execute;
 
      EXCEPTION
      WHEN OTHERS THEN NULL;
      dbms_output.put_line ('PURGE RECYCLEBIN');
      EXECUTE IMMEDIATE 'purge recyclebin';
      END;
   END LOOP;
 
   FOR r_type IN (SELECT object_type, object_name
                    FROM user_objects
                   WHERE object_type IN ('TYPE'))
   LOOP
      BEGIN
        t_execute:= 'drop '||r_type.object_type||' "'||r_type.object_name||'" FORCE';
        dbms_output.put_line(t_execute);  
        EXECUTE IMMEDIATE t_execute;
      EXCEPTION
        WHEN OTHERS THEN 
        NULL;
        dbms_output.put_line ('PURGE RECYCLENIB');
        execute immediate 'purge recyclebin';
      END;
   END LOOP;
 
   -- Drop CONSTRAINTS
   FOR r_const IN ( SELECT a.table_name, a.constraint_name 
                      FROM user_constraints a, user_constraints b
                     WHERE a.constraint_type = 'R'
                       AND a.r_constraint_name = b.constraint_name
                       AND b.table_name IN ( SELECT table_name FROM user_tables)
                   )
   LOOP 
     BEGIN
       c_execute:='alter table '||r_const.table_name||' drop constraint "'||r_const.constraint_name||'"';
       dbms_output.put_line(c_execute);
       EXECUTE IMMEDIATE c_execute;
 
     EXCEPTION
       WHEN OTHERS THEN NULL;
       dbms_output.put_line ('PURGE RECYCLEBIN');
       EXECUTE IMMEDIATE 'purge recyclebin';
     END;
 
   END LOOP; 
 
   ---
   FOR r_obj IN (SELECT object_type, object_name
                   FROM user_objects
                  WHERE object_type NOT IN ('PACKAGE BODY', 'INDEX', 'UNDEFINED', 'LOB', 'JAVA CLASS','JAVA SOURCE','TABLE PARTITION')
                    AND object_name NOT IN ( SELECT m.LOG_TABLE FROM USER_MVIEW_LOGS m)
                )
   LOOP
     BEGIN
       l_execute:= 'drop '||r_obj.object_type||' "'||r_obj.object_name||'"';
       dbms_output.put_line(l_execute);  
       EXECUTE IMMEDIATE l_execute;
 
     EXCEPTION
       WHEN OTHERS THEN NULL;
       dbms_output.put_line ('PURGE RECYCLEBIN');
       execute immediate 'purge recyclebin';
     END;
   END LOOP;
 
   ---
   FOR r_obj IN (SELECT object_type
     , object_name
     FROM   user_objects
     WHERE  object_type IN ('PACKAGE BODY')
     AND object_name NOT IN (SELECT m.LOG_TABLE FROM USER_MVIEW_LOGS m))
   LOOP
     BEGIN
       l_execute:= 'drop '||r_obj.object_type||' "'||r_obj.object_name||'"';
       dbms_output.put_line(l_execute);  
       EXECUTE IMMEDIATE l_execute;
 
     EXCEPTION
       WHEN OTHERS THEN NULL;
       dbms_output.put_line ('PURGE RECYCLEBIN');
       execute immediate 'purge recyclebin';
     END;
   END LOOP;
 
   execute immediate 'purge recyclebin';
 
 
 
  BEGIN
        execute immediate 'DBMS_LOCK.sleep(15)'; 
     EXCEPTION
       WHEN OTHERS THEN
          NULL;
     END;
 
       -- List not dropped objects
   FOR x IN (SELECT object_name FROM user_objects
              ) LOOP
     BEGIN
         dbms_output.put_line ('OBJECT '||x.object_name|| ' IS NOT DROPPED!!!!!!');
     EXCEPTION
       WHEN OTHERS THEN
         NULL;
     END;
   END LOOP;
 
 
 ELSE
  dbms_output.put_line('USER NAME IS NOT THE SAME AS SCHEMA IN WITCH SCRIPT IS EXECUTED PLESE CHECK!!!!!!');  
 END IF;
 END;
 /
 
 



/* ========================================================================================================================


-- Check if some objects still persist:

SELECT 'drop '|| k.OBJECT_TYPE ||' '||k.OBJECT_NAME||';' FROM user_objects k;
-- Drop AQ tables : 

exec DBMS_AQADM.DROP_QUEUE_TABLE(queue_table => 'TEST', force => TRUE);

*/




###############################################
###############################################
Tablespace growth:

SELECT TO_CHAR (sp.begin_interval_time,'YYYY-MM-DD') days 
, ts.tsname
, max(round((tsu.tablespace_size* dt.block_size )/(1024*1024),2) ) cur_size_MB
, max(round((tsu.tablespace_usedsize* dt.block_size )/(1024*1024),2)) usedsize_MB 
FROM DBA_HIST_TBSPC_SPACE_USAGE tsu, DBA_HIST_TABLESPACE_STAT ts 
, DBA_HIST_SNAPSHOT sp, DBA_TABLESPACES dt
WHERE tsu.tablespace_id= ts.ts#
AND tsu.snap_id = sp.snap_id AND ts.tsname = dt.tablespace_name
AND ts.tsname = '&tablespace_name'
GROUP BY TO_CHAR (sp.begin_interval_time,'YYYY-MM-DD'), ts.tsname 
ORDER BY days;  

###############################################
###############################################
SWAP:

 
free | awk '/Swap/{print ("Used swap is"),($3/$2)*100,("%")}' 


/opt/OV/bin/ovcodautil -support 

echo "Used swap is:";/usr/sbin/swap -l | grep -v "^swapfile.*dev.*free$" | awk '{ TOTAL+= $4; FREE+= $5 } END { print sprintf "%.1f", 100-FREE/TOTAL*100 }'

###############################################
swap utilization

UNIX95=1 ps -e -o vsz,pid,ppid,args | sort -rn | head -20

/usr/sbin/swap -s|sed 's/k/ /g'|awk '{print "Free swap is",($11/$9)*100"%"}'


ps -e -o vsz,pid,ppid,args | sort -rn | head -10

###############################################
SHOWS ACTIVE SESSIONS:

set lines 300
col SPID for a10
col MACHINE for a15
col PROGRAM for a20
col LOGON_TIME for a20
col EVENT for a30
select a.spid ,b.SID, b.SERIAL#,b.EVENT, b.USERNAME, b.MACHINE,
TO_CHAR(b.logon_time, 'MM/DD/YY HH24:MI:SS') as LOGON_TIME, b.STATUS, b.program, b.sql_id  
from v$process a, v$session b 
where a.addr = b.paddr order by 2;

select resource_name, current_utilization, max_utilization from v$resource_limit where resource_name in ('processes','sessions');

###############################################
CURRENT SESSIONS:

set linesize 400
set pagesize 300
col LOGON_TIME for a17
col orapid for 9999 
col SRVPID for a7  
col OSUSER for a17
col USERNAME for a15
col MACHINE for a25
col CLIENTPROGRAM for a30
col INST_ID for 99
col STATUS for a10
col CLIENTPROGRAM for a 60
select s.sid, s.serial#,s.SQL_ID, s.username,
       p.pid orapid, p.spid "SRVPID", 
       s.program clientprogram, s.machine, s.osuser,
       s.status, to_char(s.logon_time,'DD-MON HH24:MI:SS') logon_time,
	   s.last_call_et/60 as MIN_WAIT, s.INST_ID
from gv$session s, gv$process p
where s.paddr=p.addr
-- and s.sid in ('828')
-- and s.serial#=21961
and s.status='ACTIVE'
-- and s.program not like ''
-- and s.program like '
-- and s.program like ''
-- and s.username like 'RMAN'
-- order by LOGON_TIME
-- and s.username <>'RMAN'
order by 1;

###############################################
###############################################
SHOW WHAT A PROCESS IS DOING CPU SPID:

[2015-09-08 7:47 PM] Asenov, Pavel (Oracle TS): 
set long 999999
set long 999999
set lines 250
set pages 250
col machine for a20
col program for a25
col username for a12
col osuser for a18
col LOGON_TIME for a20
col CLIENTPROGRAM for a21
col module for a21
col status for a8
select s.sid, s.serial#, s.username,s.sql_id,
       to_char(s.logon_time,'DD-MON HH24:MI:SS') logon_time,
       p.pid oraclepid, p.spid "ServerPID", s.process "ClientPID",
       s.program clientprogram,s.event, s.module, s.machine, s.osuser,
       s.status, s.last_call_et, s.sql_id
from v$session s, v$process p
where p.spid in (   
11334,
20362,
25552,
29155,
27672
 )  --server processes
and s.paddr=p.addr
order by s.sid
/


----------------------------------------------------------------------------------------

select sql_fulltext from v$sqlarea where sql_id='5kzjvwc17h4nd';

###########################################################################################################################################################################################################################################
###########################################################################################################################################################################################################################################
###########################################################################################################################################################################################################################################
STANDBY, ARCHIVELOGS:



###############################################
###############################################
RESTORING ARCHIVELOG FROM PRIMARY TO BE SHIPPED ON STANDBY:

RMAN> restore archivelog from sequence 125223 until sequence 125223 thread=1,2,3;


#########################################################
############## GRP GUARANTEE RESTORE POINT ##############

select to_char(current_scn) from v$database; 

set lines 300
col NAME for a30
col time for a40
SELECT NAME, INST_ID, SCN, TIME,GUARANTEE_FLASHBACK_DATABASE,STORAGE_SIZE /1024/1024/1024 GB
FROM GV$RESTORE_POINT; 

set lines 300
col NAME for a30
col time for a40
SELECT NAME, SCN, TIME,GUARANTEE_FLASHBACK_DATABASE,STORAGE_SIZE /1024/1024/1024 GB
FROM V$RESTORE_POINT; 

CREATE RESTORE POINT "E-C01697634_BEFORE_DEPLOYMENT" GUARANTEE FLASHBACK DATABASE; 

DROP RESTORE POINT "RP_7DAYS_20190404_192703";
DROP RESTORE POINT BEFORE_FLASHBACK;


###############################################
###############################################
CHECK IF THE PRIMARY AND STANDBY ARE IN SYNC:


select al.RESETLOGS_TIME, al.thread#,
        al.last_rec "Last Recd",
        la.last_app "Last Applied"
from
  (select RESETLOGS_TIME, thread#, max(sequence#) last_rec
    from v$archived_log
    group by RESETLOGS_TIME,thread#) al,
  (select RESETLOGS_TIME, thread#, max(sequence#) last_app
    from v$archived_log
    where applied='YES' and registrar='RFS'
    group by RESETLOGS_TIME, thread#) la
where al.thread#=la.thread#
and   al.RESETLOGS_TIME = la.RESETLOGS_TIME
and   al.thread# != 0
and   al.RESETLOGS_TIME = (select max(RESETLOGS_TIME) from v$archived_log)
order by al.thread#
/

###############################################
###############################################
CHECK FOR STANDBY:

set pages 1000
set lines 120
column DEST_NAME format a20
column DESTINATION format a35
column ARCHIVER format a10
column TARGET format a15
column status format a10
column error format a15
select DEST_ID,DEST_NAME,DESTINATION,TARGET,STATUS,ERROR from v$archive_dest
where DESTINATION is NOT NULL
/


###############################################
###############################################
FIND DATABASE IN A CLUSTER GROUP:

srvctl status database -d DATABASENAME


###############################################
###############################################
VALID DESTINATION:

set pages 1000
set lines 120
column DEST_NAME format a20
column DESTINATION format a35
column ARCHIVER format a10
column TARGET format a15
column status format a10
column error format a15
select DEST_ID,DEST_NAME,DESTINATION,TARGET,STATUS,ERROR from v$archive_dest
where DESTINATION is NOT NULL
/


###############################################
###############################################
CHECK STANDBY OR PRIMARY:

select database_role from v$database;

show parameter config

vM.6VKRCDHe2eAg 

###############################################
###############################################
ARCHIVE DEST SPACE UTILIZATION:

PROMPT Archivelog Space Report
col limit format 999,999,999 heading "Limit (mb)";
col used format 999,999,999 heading "Space Used (mb)";
col free format 999,999,999 heading "Space Free (mb)";
select space_limit/(1024*1024) limit
, (space_used + space_reclaimable)/(1024*1024) used
, (space_limit-(space_used+space_reclaimable))/(1024*1024) free
,number_of_files
from v$recovery_file_dest
/

select * from v$flash_recovery_area_usage

select database_role from v$database;

###############################################
###############################################
APPLY CHECK:

set lines 300
col REALTIME_APPLY for a15
select * from V$LOGSTDBY_STATE;

set linesize 400
COL DICT_BEGIN FORMAT A10
col FILE_NAME for a60
SET NUMF 9999999999999
SELECT FILE_NAME, SEQUENCE# AS SEQ#, NEXT_CHANGE#, to_char(TIMESTAMP, 'YYYY/MON/DD HH24:MI:SS') as TIMESTAMP,
DICT_BEGIN AS BEG, DICT_END AS END, THREAD# AS THR#, APPLIED FROM DBA_LOGSTDBY_LOG
ORDER BY SEQUENCE#;



###############################################
###############################################
LAST RECEIVED LAST APPLIED ARCHIVELOGS:

PROMPT Last log received and last applied
select al.thread#,
        al.last_rec "Last Recd",
        la.last_app "Last Applied"
from
  (select thread#, max(sequence#) last_rec
    from v$archived_log
    group by thread#) al,
  (select thread#, max(sequence#) last_app
    from v$archived_log
    where applied='YES' and registrar='RFS'
    group by thread#) la
where al.thread#=la.thread#
and al.thread# != 0
order by al.thread#
/

--------------------------------------------------

PROMPT Archivelog Space Report
col limit format 999,999,999 heading "Limit (mb)";
col used format 999,999,999 heading "Space Used (mb)";
col free format 999,999,999 heading "Space Free (mb)";
select space_limit/(1024*1024) limit
, (space_used + space_reclaimable)/(1024*1024) used
, (space_limit-(space_used+space_reclaimable))/(1024*1024) free
,number_of_files
from v$recovery_file_dest
/


###############################################
###############################################
DELETE APPLIED LOGS FROM STANDBY:  

rman target / 
crosscheck archivelog all;     <------ ne se pravi ,ako ne se nalaga,poneje dekatologirizira vsichi archive logove

Triem samo ot Phisical Standby !!!!!
delete noprompt archivelog until sequence 109 thread 1;  <--- sequence-a se slaga s 5 po-malko ot rezultata na last applied i se executeva ot rman-a na standby-a
delete noprompt archivelog until sequence 18 thread 2;
delete noprompt archivelog until sequence 185043 thread 3;
delete noprompt archivelog until sequence 163641 thread 4;
delete noprompt archivelog until logseq 110140 thread 1;

delete noprompt archivelog all;
###############################################
###############################################
CHECK IF THE STANDBY IS APPLYING:  OT PRIMARY-to SE SWITCHVAT LOGOVE I SE NABLIUDAVA STANDBY-a

select al.RESETLOGS_TIME, al.thread#,
        al.last_rec "Last Recd",
        la.last_app "Last Applied"
from
  (select RESETLOGS_TIME, thread#, max(sequence#) last_rec
    from v$archived_log
    group by RESETLOGS_TIME,thread#) al,
  (select RESETLOGS_TIME, thread#, max(sequence#) last_app
    from v$archived_log
    where applied='YES' and registrar='RFS'
    group by RESETLOGS_TIME, thread#) la
where al.thread#=la.thread#
and   al.RESETLOGS_TIME = la.RESETLOGS_TIME
and   al.thread# != 0
and   al.RESETLOGS_TIME = (select max(RESETLOGS_TIME) from v$archived_log)
order by al.thread#
/



###############################################
###############################################
RESTORE ARCHIVE SEQUENCE ON PRIMARY:

[oracle@db2rq ~]$ rman target /

RMAN> restore archivelog logseq 25438;
RMAN> restore archivelog from sequence 1530 until sequence 1530;
RMAN>�restore archivelog from logseq=5793 until logseq=5806 thread=2;



RMAN> run {
ALLOCATE CHANNEL CH1 DEVICE TYPE DISK;
restore archivelog from logseq 25438 until logseq 25438;
release channel CH1;
}

###############################################
###############################################
REDO LOGFILE COUNT:

SELECT to_char(FIRST_TIME, 'YYYY/MM/DD HH24') "Date and hour", count(to_char(FIRST_TIME, 'YYYY/MM/DD-HH24')) "Count redo switch", ROUND(SUM(BLOCK_SIZE * NVL(BLOCKS ,BLOCKS))/1024/1024) MB_size 
from v$archived_log 
where dest_id=1
and FIRST_TIME between trunc(sysdate-3) and sysdate 
GROUP BY to_char(FIRST_TIME, 'YYYY/MM/DD HH24') 
order by 1 
/

###############################################
###############################################





###########################################################################################################################################################################################################################################
###########################################################################################################################################################################################################################################
###########################################################################################################################################################################################################################################
LOGICAL STANDBY:



###############################################
###############################################
RESTORING ARCHIVELOG FROM PRIMARY TO BE SHIPPED ON STANDBY:

RMAN> restore archivelog from sequence 125223 until sequence 125223;


	=================== Apply on / off 
set lines 300
col REALTIME_APPLY for a15
select * from V$LOGSTDBY_STATE;

	=========================== failed transaction to skip ====================================================================

SET LINESIZE 200
SET LONG 400 
SET PAGESIZE 999
column EVENT_TIME FORMAT A20 
column STATUS FORMAT A50
column EVENT FORMAT A100
SELECT TO_CHAR(EVENT_TIME,'YYYY/MM/DD HH24:MI:SS') "EVENT_TIME", STATUS, EVENT FROM DBA_LOGSTDBY_EVENTS ORDER BY EVENT_TIME;

	
ALTER DATABASE START LOGICAL STANDBY APPLY IMMEDIATE;





###############################################
###############################################
CHECKS IF THE ARCs ARE BEING SHIPPED FROM THE PRIMARY TO THE STANDBY:


set linesize 400
COL DICT_BEGIN FORMAT A10
col FILE_NAME for a60
SET NUMF 9999999999999
SELECT FILE_NAME, SEQUENCE# AS SEQ#, NEXT_CHANGE#, to_char(TIMESTAMP, 'YYYY/MON/DD HH24:MI:SS') as TIMESTAMP,
DICT_BEGIN AS BEG, DICT_END AS END, THREAD# AS THR#, APPLIED FROM DBA_LOGSTDBY_LOG
ORDER BY SEQUENCE#;




###############################################
###############################################
### Check the database if it on STANDBY / Primary

select database_role from v$database;

###logical standby log

SET LINESIZE 200
SET LONG 400
SET PAGESIZE 999
column EVENT_TIME FORMAT A20
column STATUS FORMAT A50
column EVENT FORMAT A100
SELECT TO_CHAR(EVENT_TIME,'YYYY/MM/DD HH24:MI:SS') "EVENT_TIME", STATUS, EVENT FROM DBA_LOGSTDBY_EVENTS ORDER BY EVENT_TIME;

####check apllied archive


select al.RESETLOGS_TIME, al.thread#,
al.last_rec "Last Recd",
la.last_app "Last Applied"
from
(select RESETLOGS_TIME, thread#, max(sequence#) last_rec
from v$archived_log
group by RESETLOGS_TIME,thread#) al,
(select RESETLOGS_TIME, thread#, max(sequence#) last_app
from v$archived_log
where applied='YES' and registrar='RFS'
group by RESETLOGS_TIME, thread#) la
where al.thread#=la.thread#
and al.RESETLOGS_TIME = la.RESETLOGS_TIME
and al.thread# != 0
and al.RESETLOGS_TIME = (select max(RESETLOGS_TIME) from v$archived_log)
order by al.thread#
/

############
select * from V$LOGSTDBY_STATE;




ALTER DATABASE START LOGICAL STANDBY APPLY IMMEDIATE SKIP FAILED TRANSACTION;     <---- SAMO SLED APPROVAL OT AMOS TEAM


###########################################################################################################################################################################################################################################
###########################################################################################################################################################################################################################################
###########################################################################################################################################################################################################################################
METRIC 58


###############################################
###############################################
CHANGE ARCHIVE DEST:

Kachvame se na bazata "SQL"

>show parameter des

>!bdf "full path"

>!bdf
izbirame si derektoriq, v koqto ima dostatachno free space


                     primerno                primerno
>alter system set log_archive_dest='LOCATION=/oradata/CAEEFRR1/arch/temp_arch' scope=memory;

>alter system archive log current;

>alter system switch logfile;









###########################################################################################################################################################################################################################################
###########################################################################################################################################################################################################################################
###########################################################################################################################################################################################################################################
TEMP:

###############################################
###############################################
SHOW TEMP FREE SPACE:

set lines 250
set pages 40
col 1 noprint;
break on 1
compute sum of megs_alloc on 1
compute sum of megs_free on 1
compute sum of megs_used on 1
compute sum of megs_max on 1
select  1, a.tablespace_name,
       round(a.bytes_alloc / 1024 / 1024, 2) megs_alloc,
       round(nvl(b.bytes_free, 0) / 1024 / 1024, 2) megs_free,
       round((a.bytes_alloc - nvl(b.bytes_free, 0)) / 1024 / 1024, 2) megs_used,
       round((nvl(b.bytes_free, 0) / a.bytes_alloc) * 100,2) Pct_Free,
       100 - round((nvl(b.bytes_free, 0) / a.bytes_alloc) * 100,2) Pct_used,
       round(maxbytes/1048576,2) Megs_max,
      round(100*(round((a.bytes_alloc - nvl(b.bytes_free, 0)) / 1024 / 1024, 2))/(round(maxbytes/1048576,2)),2) pct_used_max
from  ( select  f.tablespace_name,
               sum(f.bytes) bytes_alloc,
               sum(decode(f.autoextensible, 'YES', CASE WHEN f.maxbytes >= f.bytes THEN f.maxbytes ELSE f.bytes END, 'NO', f.bytes)) maxbytes
        from dba_data_files f
        group by tablespace_name) a,
      ( select  f.tablespace_name,
               sum(f.bytes)  bytes_free
        from dba_free_space f
        group by tablespace_name) b
where a.tablespace_name = b.tablespace_name (+)
union
select 1, h.tablespace_name,
       round(sum(h.bytes_free + h.bytes_used) / 1048576, 2),
       round(sum((h.bytes_free + h.bytes_used) - nvl(p.bytes_used, 0)) / 1048576, 2),
       round(sum(nvl(p.bytes_used, 0))/ 1048576, 2) megs_used,
       round((sum((h.bytes_free + h.bytes_used) - nvl(p.bytes_used, 0)) / sum(h.bytes_used + h.bytes_free)) * 100,2),
       100 - round((sum((h.bytes_free + h.bytes_used) - nvl(p.bytes_used, 0)) / sum(h.bytes_used + h.bytes_free)) * 100,2),
       round(sum(decode(f.autoextensible, 'YES', CASE WHEN f.maxbytes >= (h.bytes_used + h.bytes_free) THEN f.maxbytes ELSE (h.bytes_used + h.bytes_free) END, 'NO', f.bytes)) / 1048576, 2) Max,
       round(100*(round(sum(nvl(p.bytes_used, 0))/ 1048576, 2))/(round(sum(decode(f.autoextensible, 'YES', CASE WHEN f.maxbytes >= (h.bytes_used + h.bytes_free) THEN f.maxbytes ELSE (h.bytes_used + h.bytes_free) END, 'NO', f.bytes)) / 1048576, 2)),2)
from   sys.v_$TEMP_SPACE_HEADER h, sys.v_$Temp_extent_pool p, dba_temp_files f
where  p.file_id(+) = h.file_id
and    p.tablespace_name(+) = h.tablespace_name
and    h.file_id = f.file_id
and    h.tablespace_name = f.tablespace_name
group by h.tablespace_name
ORDER BY PCT_USED_MAX desc;

*********************************************************************
*********************************************************************
TEMP SHORT:

SELECT A.tablespace_name tablespace, D.mb_total, 
         SUM (A.used_blocks * D.block_size) / 1024 / 1024 mb_used, 
         D.mb_total - SUM (A.used_blocks * D.block_size) / 1024 / 1024 mb_		 
FROM v$sort_segment A, 
         ( 
         SELECT B.name, C.block_size, SUM (C.bytes) / 1024 / 1024 mb_total 
         FROM v$tablespace B, v$tempfile C 
         WHERE B.ts#= C.ts# 
         GROUP BY B.name, C.block_size 
         ) D 
WHERE A.tablespace_name = D.name 
GROUP by A.tablespace_name, D.mb_total;

TEMP DATAFILES:

set linesize 400
  col FILE_NAME for a70
  select FILE_ID,FILE_NAME, TABLESPACE_NAME, (increment_by*(bytes/blocks))/1024 increment_by_kb, BYTES/1024/1024, MAXBYTES/1024/1024, AUTOEXTENSIBLE from sys.dba_temp_files where TABLESPACE_NAME='&tablespace_name'; 
  
  
###############################################
SHRINK TEMP FILES :

alter tablespace BI_EDWH_TEMP shrink space;

###############################################
###############################################
TEMP USAGE:

col SQL_TEXT for a80 
col TABLESPACE for a10 
SELECT   S.sid || ',' || S.serial# sid_serial, S.username, S.machine,
         T.blocks * TBS.block_size / 1024 / 1024 mb_used,
         T.sqladdr address, Q.hash_value, Q.sql_text 
FROM     v$sort_usage T, v$session S, v$sqlarea Q, dba_tablespaces TBS 
WHERE    T.session_addr = S.saddr 
AND      T.sqladdr = Q.address (+) 
AND      T.tablespace = TBS.tablespace_name 
-- and  SQL_TEXT  like '%DUAL%'
ORDER BY mb_used asc;


###########################################################################################################################################################################################################################################
###########################################################################################################################################################################################################################################
###########################################################################################################################################################################################################################################
TABLESPACESS:


###############################################
###############################################
TABLESPACE RIGHT EXTEND WITH DDL:

set long 99999
select dbms_metadata.get_ddl('TABLESPACE','FISCAL_DATA_8KB_4GB') from dual;
alter tablespace FISCAL_DATA_8KB_4GB add datafile '+DATA3' SIZE 104857600 AUTOEXTEND ON NEXT 104857600 MAXSIZE 32767M;



	
###############################################
###############################################
CHECK FOR STANDBY:

set pages 1000 
set lines 120 
column DEST_NAME format a20 
column DESTINATION format a35 
column ARCHIVER format a10 
column TARGET format a15 
column status format a10 
column error format a15 
select DEST_ID,DEST_NAME,DESTINATION,TARGET,STATUS,ERROR from v$archive_dest 
where DESTINATION is NOT NULL 
/


###########################################
###########################################
CHECK FOR LOW FREE SPACE IN TABLESPACESS: (TABLESPACE 006 metric)


select df.tablespace_name "Tablespace",
totalusedspace "Used MB",
(df.totalspace - tu.totalusedspace) "Free MB",
df.totalspace "Total MB",
round(100 * ( (df.totalspace - tu.totalusedspace)/ df.totalspace))
"Pct. Free"
from
(select tablespace_name,
round(sum(bytes) / 1048576) TotalSpace
from dba_data_files 
group by tablespace_name) df,
(select round(sum(bytes)/(1024*1024)) totalusedspace, tablespace_name
from dba_segments 
group by tablespace_name) tu
where df.tablespace_name = tu.tablespace_name ;


##### THE BETTER ONE - METRIC 6

set lines 250
set pages 40
col 1 noprint;
break on 1
compute sum of megs_alloc on 1
compute sum of megs_free on 1
compute sum of megs_used on 1
compute sum of megs_max on 1
select 1, a.tablespace_name,
       round(a.bytes_alloc / 1024 / 1024, 2) megs_alloc,
       round(nvl(b.bytes_free, 0) / 1024 / 1024, 2) megs_free,
       round((a.bytes_alloc - nvl(b.bytes_free, 0)) / 1024 / 1024, 2) megs_used,
       round((nvl(b.bytes_free, 0) / a.bytes_alloc) * 100,2) Pct_Free,
       100 - round((nvl(b.bytes_free, 0) / a.bytes_alloc) * 100,2) Pct_used,
       round(maxbytes/1048576,2) Megs_max,
       round(100*(round((a.bytes_alloc - nvl(b.bytes_free, 0)) / 1024 / 1024, 2))/(round(maxbytes/1048576,2)),2) pct_used_max
from ( select f.tablespace_name,
               sum(f.bytes) bytes_alloc,
               sum(decode(f.autoextensible, 'YES', CASE WHEN f.maxbytes >= f.bytes THEN f.maxbytes ELSE f.bytes END, 'NO', f.bytes)) maxbytes
        from dba_data_files f
        group by tablespace_name) a,
      ( select f.tablespace_name,
               sum(f.bytes) bytes_free
        from dba_free_space f
        group by tablespace_name) b
where a.tablespace_name = b.tablespace_name (+)
union
select 1, h.tablespace_name,
       round(sum(h.bytes_free + h.bytes_used) / 1048576, 2),
       round(sum((h.bytes_free + h.bytes_used) - nvl(p.bytes_used, 0)) / 1048576, 2),
       round(sum(nvl(p.bytes_used, 0))/ 1048576, 2) megs_used,
       round((sum((h.bytes_free + h.bytes_used) - nvl(p.bytes_used, 0)) / sum(h.bytes_used + h.bytes_free)) * 100,2),
       100 - round((sum((h.bytes_free + h.bytes_used) - nvl(p.bytes_used, 0)) / sum(h.bytes_used + h.bytes_free)) * 100,2),
       round(sum(decode(f.autoextensible, 'YES', CASE WHEN f.maxbytes >= (h.bytes_used + h.bytes_free) THEN f.maxbytes ELSE (h.bytes_used + h.bytes_free) END, 'NO', f.bytes)) / 1048576, 2) Max,
       round(100*(round(sum(nvl(p.bytes_used, 0))/ 1048576, 2))/(round(sum(decode(f.autoextensible, 'YES', CASE WHEN f.maxbytes >= (h.bytes_used + h.bytes_free) THEN f.maxbytes ELSE (h.bytes_used + h.bytes_free) END, 'NO', f.bytes)) / 1048576, 2)),2)
from sys.v_$TEMP_SPACE_HEADER h, sys.v_$Temp_extent_pool p, dba_temp_files f
where p.file_id(+) = h.file_id
and p.tablespace_name(+) = h.tablespace_name
and h.file_id = f.file_id
and h.tablespace_name = f.tablespace_name
group by h.tablespace_name
ORDER BY PCT_USED_MAX desc; 

###############################################
###############################################

AUDI QUERY

set pagesize 400
set linesize 300
col INSTANCE_NAME for a10
col USER_NAME for a20
col USER_PROFILE for a20
col USER_PASSWORD for a40
col ACCOUNT_STATUS for a20
col APPLICATION_NAME for a30
col APPLICATION_ID for a10
col SERVICE_NAME for a20
select INSTANCE_NAME,ACCOUNT_STATUS,APPLICATION_NAME,USER_NAME,USER_PASSWORD,SERVICE_NAME,USER_PROFILE from inventory_v2.tbl_user 

where USER_NAME like'&username';
where INSTANCE_NAME like'&instance';

 and INSTANCE_NAME like'%P%';



###############################################
###############################################
CHECK DATAFILES IN TABLESPACE:

set lines 300
col FILE_NAME for a60
select FILE_ID,FILE_NAME,TABLESPACE_NAME,BYTES/1024/1024 "MB",MAXBYTES/1024/1024 "MAX MB",AUTOEXTENSIBLE from dba_data_files where TABLESPACE_NAME='&TABLESPACE_NAME';


###############################

select 
   file_id, 
   user_bytes
from 
   dba_data_files
where 
   tablespace_name='&tablespace_name';
   
   
select file_id, bytes, user_bytes
from dba_data_files
where tablespace_name='&tablespace_name';

###############################################
###############################################
CHECK TEMPFILES IN TABLESPACE:

set lines 300
col FILE_NAME for a60
select FILE_ID,FILE_NAME,TABLESPACE_NAME,BYTES/1024/1024 "MB",MAXBYTES/1024/1024 "MAX MB",AUTOEXTENSIBLE from dba_temp_files where TABLESPACE_NAME='TEMP';

###############################################
###############################################
CHECK ASM FREE SPACE:

column pct_free format 99.99
select name, total_mb, free_mb, total_mb -free_mb used_mb
from v$asm_diskgroup
/


column pct_free format 99.99 
select name, total_mb, free_mb, total_mb -free_mb used_mb,
free_mb/total_mb *100 pct_free
from v$asm_diskgroup
/

###############################################
###############################################
CHECK ASM DISKGROUP:

SELECT name, header_status, path FROM V$ASM_DISK;



set pages 1000
col path format a40
set lines 200
col NAME for a30
col FAILGROUP for a15
col PATH for a40
select GROUP_NUMBER,NAME, STATE, MOUNT_STATUS,MODE_STATUS, HEADER_STATUS, FAILGROUP,PATH, TOTAL_MB,FREE_MB,OS_MB, MOUNT_DATE from v$asm_disk;


###############################################
###############################################
CHECKS WHICH SPACE OF DISKGROUPS

su - grid

set environment 

asmcmd ls | while read; do printf '%s\n' "$REPLY"; asmcmd du "$REPLY"; done

asmcmd ls +DG_LOGS | while read; do printf '+DG_LOGS/%s\n' "$REPLY"; asmcmd du "+DG_LOGS/$REPLY"; done

asmcmd ls RECO | while read; do printf 'RECO/%s\n' "$REPLY"; asmcmd du "RECO/$REPLY"; done

###############################################
###############################################
CHECK FOR IN-DUBT:

SELECT * FROM DBA_2PC_PENDING


###############################################
###############################################
SYSTEM TABLESPACE UTILIZATION:

COLUMN TABLE_NAME FORMAT A32
COLUMN OBJECT_NAME FORMAT A32
COLUMN OWNER FORMAT A10

SELECT
   owner, table_name, TRUNC(sum(bytes)/1024/1024) Meg
FROM
(SELECT segment_name table_name, owner, bytes
 FROM dba_segments
 WHERE segment_type = 'TABLE'
 UNION ALL
 SELECT i.table_name, i.owner, s.bytes
 FROM dba_indexes i, dba_segments s
 WHERE s.segment_name = i.index_name
 AND s.owner = i.owner
 AND s.segment_type = 'INDEX'
 UNION ALL
 SELECT l.table_name, l.owner, s.bytes
 FROM dba_lobs l, dba_segments s
 WHERE s.segment_name = l.segment_name
 AND s.owner = l.owner
 AND s.segment_type = 'LOBSEGMENT'
 UNION ALL
 SELECT l.table_name, l.owner, s.bytes
 FROM dba_lobs l, dba_segments s
 WHERE s.segment_name = l.index_name
 AND s.owner = l.owner
 AND s.segment_type = 'LOBINDEX')
WHERE owner in UPPER('&owner')
GROUP BY table_name, owner
HAVING SUM(bytes)/1024/1024 > 10 /* Ignore really small tables */
ORDER BY SUM(bytes) desc
;

###############################################
###############################################
SYSAUX CHECK:

select occupant_desc, space_usage_kbytes/1024 as usage_MB from v$sysaux_occupants where space_usage_kbytes > 0 order by space_usage_kbytes desc;    -   SYSAUX USAGE

select dbms_stats.get_stats_history_retention from dual; - RETENTION

select dbms_stats.get_stats_history_availability from dual; - RETENTION CHECK


###############################################
###############################################
CHECKS TABLESPACES FROM THE DATABASE:

set lines 250
set pages 40
col 1 noprint;
break on 1
compute sum of megs_alloc on 1
compute sum of megs_free on 1
compute sum of megs_used on 1
compute sum of megs_max on 1
select  1, a.tablespace_name,
       round(a.bytes_alloc / 1024 / 1024, 2) megs_alloc,
       round(nvl(b.bytes_free, 0) / 1024 / 1024, 2) megs_free,
       round((a.bytes_alloc - nvl(b.bytes_free, 0)) / 1024 / 1024, 2) megs_used,
       round((nvl(b.bytes_free, 0) / a.bytes_alloc) * 100,2) Pct_Free,
       100 - round((nvl(b.bytes_free, 0) / a.bytes_alloc) * 100,2) Pct_used,
       round(maxbytes/1048576,2) Megs_max,
      round(100*(round((a.bytes_alloc - nvl(b.bytes_free, 0)) / 1024 / 1024, 2))/(round(maxbytes/1048576,2)),2) pct_used_max
from  ( select  f.tablespace_name,
               sum(f.bytes) bytes_alloc,
               sum(decode(f.autoextensible, 'YES', CASE WHEN f.maxbytes >= f.bytes THEN f.maxbytes ELSE f.bytes END, 'NO', f.bytes)) maxbytes
        from dba_data_files f
        group by tablespace_name) a,
      ( select  f.tablespace_name,
               sum(f.bytes)  bytes_free
        from dba_free_space f
        group by tablespace_name) b
where a.tablespace_name = b.tablespace_name (+)
union
select 1, h.tablespace_name,
       round(sum(h.bytes_free + h.bytes_used) / 1048576, 2),
       round(sum((h.bytes_free + h.bytes_used) - nvl(p.bytes_used, 0)) / 1048576, 2),
       round(sum(nvl(p.bytes_used, 0))/ 1048576, 2) megs_used,
       round((sum((h.bytes_free + h.bytes_used) - nvl(p.bytes_used, 0)) / sum(h.bytes_used + h.bytes_free)) * 100,2),
       100 - round((sum((h.bytes_free + h.bytes_used) - nvl(p.bytes_used, 0)) / sum(h.bytes_used + h.bytes_free)) * 100,2),
       round(sum(decode(f.autoextensible, 'YES', CASE WHEN f.maxbytes >= (h.bytes_used + h.bytes_free) THEN f.maxbytes ELSE (h.bytes_used + h.bytes_free) END, 'NO', f.bytes)) / 1048576, 2) Max,
       round(100*(round(sum(nvl(p.bytes_used, 0))/ 1048576, 2))/(round(sum(decode(f.autoextensible, 'YES', CASE WHEN f.maxbytes >= (h.bytes_used + h.bytes_free) THEN f.maxbytes ELSE (h.bytes_used + h.bytes_free) END, 'NO', f.bytes)) / 1048576, 2)),2)
from   sys.v_$TEMP_SPACE_HEADER h, sys.v_$Temp_extent_pool p, dba_temp_files f
where  p.file_id(+) = h.file_id
and    p.tablespace_name(+) = h.tablespace_name
and    h.file_id = f.file_id
and    h.tablespace_name = f.tablespace_name
group by h.tablespace_name
ORDER BY PCT_USED_MAX desc;


###############################################
###############################################
METADATA CHECKS:

select dbms_metadata.get_ddl('CLUSTER','C_MLOG#','SYS') from dual;
select dbms_metadata.get_ddl('CONTEXT','LT_CTX') from dual;
select dbms_metadata.get_ddl('DB_LINK','PROD.WORLD','ADAM') from dual;
select dbms_metadata.get_ddl('DB_LINK','DBLINK_WMS_PROD_ANLADM.FORTUM.COM','CABDQ') from dual;
select dbms_metadata.get_ddl('FUNCTION','TO_DATE_FUNC','SCOTT') from dual;
select dbms_metadata.get_ddl('INDEX','LCSCOUNTRY$UNIQUE50','SPM') from dual;
select dbms_metadata.get_ddl('JAVA_SOURCE','java_util','ADAM') from dual
select dbms_metadata.get_ddl('JAVA_SOURCE','/6c363944_Dumper','SYS') from dual
select dbms_metadata.get_ddl('LIBRARY','UTL_SMT_LIB','SYS') from dual;
select dbms_metadata.get_ddl('MATERIALIZED_VIEW','WCPL_PRODUCT_D','POST_DWH_STG') from dual;
select dbms_metadata.get_ddl('MATERIALIZED_VIEW_LOG','V_NLS_SCHLUESSEL_AUSPR','VNGSYS') from dual;
select dbms_metadata.get_ddl('OPERATOR','OLAP_EXPRESSION') from dual;
select dbms_metadata.get_ddl('OPERATOR','OLAP_EXPRESSION','SYS') from dual;
select dbms_metadata.get_ddl('PACKAGE','ESL_CARDS4') from dual;
select dbms_metadata.get_ddl('PACKAGE','ESL_CARDS4','ESL') from dual;
select dbms_metadata.get_ddl('PACKAGE_BODY','RR_PKG_LOAD_DATA','CANDEM') from dual;
select dbms_metadata.get_ddl('PROCEDURE','SP_TFVALCST_CNPART_DEPOT','CANON_HUB') from dual;
select dbms_metadata.get_ddl('SEQUENCE','STATS$SNAPSHOT_ID','PERFSTAT') from dual;
select dbms_metadata.get_ddl('SYNONYM','/2fddc42_paintARGB_PRE_ONTO_S5','PUBLIC') from dual;
select dbms_metadata.get_ddl('TABLE','LCSREVISABLEENTITY','SPM') from dual;
select dbms_metadata.get_ddl('TABLESPACE','ZEB_ITM_TBS') from dual;
select dbms_metadata.get_ddl('TRIGGER','tt$connect_logon','cabdw_dw') from dual;
select dbms_metadata.get_ddl('TYPE','LCSREVISABLEENTITY','SYS') from dual;
select dbms_metadata.get_ddl('TYPE_BODY','ORACLE_LOADER','SYS') from dual;
select dbms_metadata.get_ddl('VIEW','V_ESL_AB','ESL') from dual;
select dbms_metadata.get_ddl('VIEW','DBA_PROPAGATION') from dual;select 
dbms_metadata.get_ddl('PACKAGE','DBMS_METADATA','SYS') from dual;






select
( select sum(bytes)/1024/1024/1024 data_size from dba_data_files ) +
( select nvl(sum(bytes),0)/1024/1024/1024 temp_size from dba_temp_files ) +
( select sum(bytes)/1024/1024/1024 redo_size from sys.v_$log ) +
( select sum(BLOCK_SIZE*FILE_SIZE_BLKS)/1024/1024/1024 controlfile_size from v$controlfile) "Size in GB"
from
dual

###############################################
###############################################
CHECK THE DATABASE SIZE:

clear columns
column tablespace format a20
column total_mb format 999,999,999,999.99
column used_mb format 999,999,999,999.99
column free_mb format 999,999,999.99
column pct_used format 999.99
column graph format a25 heading &quot;GRAPH (X=5%)&quot;
column status format a10
compute sum of total_mb on report
compute sum of used_mb on report
compute sum of free_mb on report
break on report 
set lines 200 pages 100
select  total.ts tablespace,
        DECODE(total.mb,null,'OFFLINE',dbat.status) status,
 total.mb total_mb,
 NVL(total.mb - free.mb,total.mb) used_mb,
 NVL(free.mb,0) free_mb,
        DECODE(total.mb,NULL,0,NVL(ROUND((total.mb - free.mb)/(total.mb)*100,2),100)) pct_used,
 CASE WHEN (total.mb IS NULL) THEN '['||RPAD(LPAD('OFFLINE',13,'-'),20,'-')||']'
 ELSE '['|| DECODE(free.mb,
                             null,'XXXXXXXXXXXXXXXXXXXX',
                             NVL(RPAD(LPAD('X',trunc((100-ROUND( (free.mb)/(total.mb) * 100, 2))/5),'X'),20,'-'),
  '--------------------'))||']' 
         END as GRAPH
from
 (select tablespace_name ts, sum(bytes)/1024/1024 mb from dba_data_files group by tablespace_name) total,
 (select tablespace_name ts, sum(bytes)/1024/1024 mb from dba_free_space group by tablespace_name) free,
        dba_tablespaces dbat
where total.ts=free.ts(+) and
      total.ts=dbat.tablespace_name
UNION ALL
select  sh.tablespace_name, 
        'TEMP',
 SUM(sh.bytes_used+sh.bytes_free)/1024/1024 total_mb,
 SUM(sh.bytes_used)/1024/1024 used_mb,
 SUM(sh.bytes_free)/1024/1024 free_mb,
        ROUND(SUM(sh.bytes_used)/SUM(sh.bytes_used+sh.bytes_free)*100,2) pct_used,
        '['||DECODE(SUM(sh.bytes_free),0,'XXXXXXXXXXXXXXXXXXXX',
              NVL(RPAD(LPAD('X',(TRUNC(ROUND((SUM(sh.bytes_used)/SUM(sh.bytes_used+sh.bytes_free))*100,2)/5)),'X'),20,'-'),
                '--------------------'))||']'
FROM v$temp_space_header sh
GROUP BY tablespace_name
order by 1
/
ttitle off
clear columns

###############################################
CHECK DATABASE GROWTH:

SET LINESIZE 200
SET PAGESIZE 200
COL "Database Size" FORMAT a13
COL "Used Space" FORMAT a11
COL "Used in %" FORMAT a11
COL "Free in %" FORMAT a11
COL "Database Name" FORMAT a13
COL "Free Space" FORMAT a12
COL "Growth DAY" FORMAT a11
COL "Growth WEEK" FORMAT a12
COL "Growth DAY in %" FORMAT a16
COL "Growth WEEK in %" FORMAT a16
SELECT
(select min(creation_time) from v$datafile) "Create Time",
(select name from v$database) "Database Name",
ROUND((SUM(USED.BYTES) / 1024 / 1024 ),2) || ' MB' "Database Size",
ROUND((SUM(USED.BYTES) / 1024 / 1024 ) - ROUND(FREE.P / 1024 / 1024 ),2) || ' MB' "Used Space",
ROUND(((SUM(USED.BYTES) / 1024 / 1024 ) - (FREE.P / 1024 / 1024 )) / ROUND(SUM(USED.BYTES) / 1024 / 1024 ,2)*100,2) || '% MB' "Used in %",
ROUND((FREE.P / 1024 / 1024 ),2) || ' MB' "Free Space",
ROUND(((SUM(USED.BYTES) / 1024 / 1024 ) - ((SUM(USED.BYTES) / 1024 / 1024 ) - ROUND(FREE.P / 1024 / 1024 )))/ROUND(SUM(USED.BYTES) / 1024 / 1024,2 )*100,2) || '% MB' "Free in %",
ROUND(((SUM(USED.BYTES) / 1024 / 1024 ) - (FREE.P / 1024 / 1024 ))/(select sysdate-min(creation_time) from v$datafile),2) || ' MB' "Growth DAY",
ROUND(((SUM(USED.BYTES) / 1024 / 1024 ) - (FREE.P / 1024 / 1024 ))/(select sysdate-min(creation_time) from v$datafile)/ROUND((SUM(USED.BYTES) / 1024 / 1024 ),2)*100,3) || '% MB' "Growth DAY in %",
ROUND(((SUM(USED.BYTES) / 1024 / 1024 ) - (FREE.P / 1024 / 1024 ))/(select sysdate-min(creation_time) from v$datafile)*7,2) || ' MB' "Growth WEEK",
ROUND((((SUM(USED.BYTES) / 1024 / 1024 ) - (FREE.P / 1024 / 1024 ))/(select sysdate-min(creation_time) from v$datafile)/ROUND((SUM(USED.BYTES) / 1024 / 1024 ),2)*100)*7,3) || '% MB' "Growth WEEK in %"
FROM    (SELECT BYTES FROM V$DATAFILE
UNION ALL
SELECT BYTES FROM V$TEMPFILE
UNION ALL
SELECT BYTES FROM V$LOG) USED,
(SELECT SUM(BYTES) AS P FROM DBA_FREE_SPACE) FREE
GROUP BY FREE.P;

###############################################
CHECK THE SCHEMA SIZE:

SELECT sum(bytes) / 1024 / 1024 / 1024 as "Size in GB" FROM dba_segments WHERE owner = UPPER('&schema_name');

###############################################

####-- HISTORICALLY DAILY TABLESPACE SIZE FROM DBA_HIST_TBSPC_SPACE_USAGE (AWR TABLE)
SELECT TO_CHAR(end_interval_time,'dd-mm-yyyy') snap_time,
ROUND(SUM(tablespace_size) * 8192 / 1024 / 1024 / 1024, 1) size_gb,
ROUND(SUM(tablespace_usedsize) * 8192 / 1024 / 1024 / 1024, 1) usedsize_gb
FROM sys.dba_hist_tbspc_space_usage tsu,
sys.dba_hist_snapshot s
WHERE tsu.snap_id = s.snap_id
AND s.snap_id IN
(SELECT snap_id
FROM sys.dba_hist_snapshot
WHERE TO_CHAR(end_interval_time, 'HH24') = '00' )
GROUP BY end_interval_time
ORDER BY end_interval_time;
 
####-- SPACE ADDED TO THE DATAFILES PER MONTH
SELECT TO_CHAR(creation_time, 'YYYY Month') "Month",
ROUND(SUM(bytes)/1024/1024/1024) "Growth in GBytes"
FROM sys.v_$datafile
GROUP BY TO_CHAR(creation_time, 'YYYY Month')
ORDER BY TO_DATE(TO_CHAR(creation_time, 'YYYY Month'),'YYYY Month')

###############################################
###############################################
MANAGE DATAFILES:


###############################################
MOVING ONLINE DATAFILES:

alter database MOVE DATAFILE 'datafile full path and name' to 'datafile new full path and name'

###############################################
MOVING DATAFILE FROM FS TO ASM:

alter database MOVE DATAFILE 'datafile full path and name' to '+ASM DISKGROUP NAME' KEEP;

with the KEEP option we keep the original file aswell as the new one. Withiut this clouse the originak FS file will be deleted.

###############################################
CHANGING THE NAME OF A DATAFILE:

alter database MOVE DATAFILE 'datafile full path and name' to 'datafile full path and new name'



###########################################################################################################################################################################################################################################
###########################################################################################################################################################################################################################################
###########################################################################################################################################################################################################################################
SHARED POOL, DBMON LOCK:

###############################################
###############################################
CHECK AND FLUSH SHARED POOL:

select * from v$sgastat where name = 'free memory';
alter system flush shared_pool;


###############################################
###############################################
KILL ALL HUNG PROCESSES:

ps -ef|grep dbmon|grep -v grep|awk '{print $2}'|xargs kill -9
ps -ef|grep dbspi|grep -v grep|awk '{print $2}'|xargs kill -9

ps -ef|grep dbmon|grep -v grep|awk '{print $2}'|xargs super kill -9
ps -ef|grep dbspi|grep -v grep|awk '{print $2}'|xargs super kill -9

ps -ef|grep dbmon|grep -v grep|awk '{print $2}'|xargs sudo kill -9
ps -ef|grep dbspi|grep -v grep|awk '{print $2}'|xargs sudo kill -9

###########################################################################################################################################################################################################################################
###########################################################################################################################################################################################################################################
###########################################################################################################################################################################################################################################

###############################################
###############################################
CHECK FOR USER SESSIONS: ( It will ask you for the user name )

select a.value, s.username, s.sid, s.serial# from v$sesstat a, v$statname b, v$session s where a.statistic# = b.statistic#  and s.sid=a.sid and b.name = 'opened cursors current' and s.username is not null;

select SID,SERIAL#, STATUS from v$session where USERNAME='&USERNAME_FOR_DROP';

###############################################
###############################################
SHOWS ALL BLOCKING SESSIONS: THIS IS VERY GOOD - BLOCK SESSIONS

select 
   blocking_session, 
   sid, 
   serial#, 
   wait_class,
   seconds_in_wait
from 
   v$session
where 
   blocking_session is not NULL
order by 
   blocking_session;
   
   
###############################################
###############################################
SHOW LOCKED OBJECTS:

set lines 100 pages 999
col username 	format a20
col sess_id 	format a10
col object	format a25
col mode_held	format a10
select	oracle_username || ' (' || s.osuser || ')' username
,	s.sid || ',' || s.serial# sess_id
,	owner || '.' ||	object_name object
,	object_type
,	decode(	l.block
	,	0, 'Not Blocking'
	,	1, 'Blocking'
	,	2, 'Global') status
,	decode(v.locked_mode
	,	0, 'None'
	,	1, 'Null'
	,	2, 'Row-S (SS)'
	,	3, 'Row-X (SX)'
	,	4, 'Share'
	,	5, 'S/Row-X (SSX)'
	,	6, 'Exclusive', TO_CHAR(lmode)) mode_held
from	v$locked_object v
,	dba_objects d
,	v$lock l
,	v$session s
where 	v.object_id = d.object_id
and 	v.object_id = l.id1
and 	v.session_id = s.sid
order by oracle_username
,	session_id
/

###############################################
###############################################
SHOW LOCKS:

select sid, seq#, EVENT,  WAIT_CLASS,  SECONDS_IN_WAIT,p1, p2 from v$session_wait


###############################################
###############################################
SESSIONS BLOCKING EACHOTHER:

select	'SID ' || l1.sid ||' is blocking  ' || l2.sid blocking
from	v$lock l1, v$lock l2
where	l1.block =1 and l2.request > 0
and	l1.id1=l2.id1
and	l1.id2=l2.id2
/

-----------------------------------------------

set linesize 400
col USERNAME for a10
col LOGON_TIME for a20
col IS_BLOCKING for a15
col PROGRAM for a25
select
l1.INST_ID, l1.sid, a.serial#, a.USERNAME, a.PROGRAM, TO_CHAR(a.logon_time, 'MM/DD/YY HH24:MI:SS') as logon_time, 'IS_BLOCKING' as IS_BLOCKING,
l2.INST_ID, l2.sid, b.serial#, b.USERNAME, b.PROGRAM, TO_CHAR(b.logon_time, 'MM/DD/YY HH24:MI:SS') as logon_time
from gv$lock l1, gv$lock l2, gv$session a, gv$session b
where l1.id1=l2.id1 and l1.id2=l2.id2 and a.SID=l1.sid and b.SID=l2.sid
and l1.inst_id=l2.inst_id and l2.inst_id=a.inst_id and a.inst_id=b.inst_id  and l1.sid! = l2.sid
and l1.block =1 and l2.request > 0 order by a.LOGON_TIME;

select 'ALTER SYSTEM KILL SESSION '||''''||sid||','||serial#||',@'||inst_id||''' IMMEDIATE;' from gv$session where SID=162;


select sql_id from v$session where sid=&sid;

###############################################
###############################################
BLOCKED SESSIONS:

select 
	s.username, s.status, s.sid, s.serial#,
	p.spid, s.machine, s.process, s.lockwait
from	v$session s, v$process p
where	s.lockwait is not null
and	s.paddr = p.addr; 

SELECT a.sid,a.serial#, a.username, a.program, c.os_user_name,a.terminal,type,b.object_id,substr(b.object_name,1,40) object_name
from v$session a, dba_objects b, v$locked_object c
where a.sid = c.session_id
and b.object_id = c.object_id
order by SID;
 
select
INST_ID,
blocking_session,
sid,
serial#,
wait_class,
seconds_in_wait
from
gv$session
where
blocking_session is not NULL
order by
blocking_session;

###### BLOCKED -GETOVSKI

set linesize 400
set pages 1500
 col MACHINE for a15
 col USERNAME for a10
 col LOGON_TIME for a20 
 col IS_BLOCKING for a15
 col PROGRAM for a15
 select  l1.INST_ID, l1.sid, a.serial#, a.status, a.USERNAME, a.PROGRAM,a.MACHINE, TO_CHAR(a.logon_time, 'MM/DD/YY HH24:MI:SS') as logon_time, 'IS_BLOCKING' as IS_BLOCKING,
l2.INST_ID, l2.sid, b.serial#, b.USERNAME, b.PROGRAM, TO_CHAR(b.logon_time, 'MM/DD/YY HH24:MI:SS') as logon_time
     from gv$lock l1, gv$lock l2, gv$session a, gv$session b
    where l1.id1=l2.id1 and l1.id2=l2.id2 and a.SID=l1.sid and b.SID=l2.sid
    and l1.inst_id=l2.inst_id and l2.inst_id=a.inst_id and a.inst_id=b.inst_id  and l1.sid! = l2.sid
    and l1.block =1 and l2.request > 0 order by a.LOGON_TIME; 

#### KILL SESSIONS:

select 'ALTER SYSTEM KILL SESSION '||''''||sid||','||serial#||',@'||inst_id||''' IMMEDIATE;' from gv$session where SID=&sid;
	
###### WAIT EVENTS

select sid, seq#, EVENT,  WAIT_CLASS,  SECONDS_IN_WAIT,p1, p2 from v$session_wait order by SECONDS_IN_WAIT;

###############################################
###############################################
CHECK ALL SESSIONS EVEN IDLE:

WITH   
gl AS ( 
  select  
    inst_id || '-' || sid instsid, id1, id2,  
    ctime, lmode, block, request  
  from  
    gv$lock  
),  
l AS ( 
  SELECT  
    l1.instsid holding_session,  
    l2.instsid waiting_session  
  FROM 
    gl l1,  
    gl l2  
  WHERE 
    l1.block > 0  
    AND l2.request > 0  
    AND l1.id1=l2.id1  
    AND l1.id2=l2.id2  
),  
rs AS (  
  SELECT   
    lpad(' ',3*(level-1),' ') || waiting_session running_session  
  FROM (  
    (SELECT  
      '-' holding_session, holding_session waiting_session  
    FROM  
      l  
    MINUS  
      SELECT  
      '-', waiting_session  
    FROM  
      l  
        )  
    UNION ALL  
        SELECT  
      holding_session, waiting_session  
        FROM  
      l   
    )  
    CONNECT BY PRIOR  
    waiting_session = holding_session  
    START WITH  
    holding_session = '-'  
),  
s AS (  
  SELECT   
    inst_id, sid, serial#, machine, osuser, username,  
    nvl(sql_id, '-') sql_id, event, wait_class  
  FROM gv$session  
)  
SELECT  
*  
FROM  
rs  
JOIN  
s ON ltrim(rs.running_session)=s.inst_id || '-' || s.sid  ;


###############################################
###############################################
SHOW LOCKS:

column lock_type format a12
column mode_held format a10
column mode_requested format a10
column blocking_others format a20
column username format a10
SELECT	session_id
,	lock_type
,	mode_held
,	mode_requested
,	blocking_others
,	lock_id1
FROM	dba_lock l
WHERE 	lock_type NOT IN ('Media Recovery', 'Redo Thread')
/


###############################################
###############################################
SESSION LOCKS:

select distinct 'ALTER SYSTEM KILL SESSION ''' || sid || ',' || serial# || '''' stmt
from (
SELECT *
FROM
   v$session s
WHERE
   blocking_session IS NOT NULL
union all
select *
from v$session
where sid in (select blocking_session
              from   v$session
              where blocking_session is not null)
) ;


*************************************************************

CHECK SESSION SQL_TEXT:

3dbvs_vags831c
3dbvs_vags831c


###############################################
###############################################
ACTIVE SESSIONS:

set linesize 200
set pages 1500
col PROGRAM for a40
col MACHINE for a9
col username for a10
col TO_CHAR(LOGON_TIME,'YYYY/MM/DDHH24:MI:SS') for a45
select sql_id,inst_id,SID,SERIAL#,STATUS,USERNAME,MACHINE,PROGRAM,to_char(LOGON_TIME, 'YYYY/MM/DD HH24:MI:SS'),LOCKWAIT from gv$session where status='ACTIVE' order by inst_id, LOGON_TIME;
  
  
###############################################
###############################################
INACTIVE SESSIONS:

set linesize 400
set pages 500
col PROGRAM for a40
col MACHINE for a12
col username for a10
col TO_CHAR(LOGON_TIME,'YYYY/MM/DDHH24:MI:SS') for a45
col LOCKWAIT for a8
select sql_id,inst_id,SID,SERIAL#,STATUS,USERNAME,MACHINE,PROGRAM,to_char(LOGON_TIME, 'YYYY/MM/DD HH24:MI:SS'),LOCKWAIT from gv$session where status='INACTIVE' order by inst_id, LOGON_TIME;

set linesize 200
col PROGRAM for a40
col MACHINE for a15
col username for a10
col TO_CHAR(LOGON_TIME,'YYYY/MM/DDHH24:MI:SS') for a45
select sql_id,inst_id,SID,SERIAL#,STATUS,USERNAME,MACHINE,PROGRAM,to_char(LOGON_TIME, 'YYYY/MM/DD HH24:MI:SS'),LOCKWAIT from gv$session where SID=2559 order by 
inst_id, LOGON_TIME;

set linesize 200
set pages 1500
col PROGRAM for a40
col MACHINE for a15
col username for a15
col TO_CHAR(LOGON_TIME,'YYYY/MM/DDHH24:MI:SS') for a45
select sql_id,inst_id,SID,SERIAL#,STATUS,USERNAME,MACHINE,PROGRAM,to_char(LOGON_TIME, 'YYYY/MM/DD HH24:MI:SS'),LOCKWAIT from gv$session where USERNAME='CHOICEWS_OUSR' order by 
inst_id, LOGON_TIME;

set linesize 400
set pages 500
col PROGRAM for a40
col MACHINE for a12
col username for a10
col TO_CHAR(LOGON_TIME,'YYYY/MM/DDHH24:MI:SS') for a45
col LOCKWAIT for a8
select sql_id,inst_id,SID,SERIAL#,STATUS,USERNAME,MACHINE,PROGRAM,to_char(LOGON_TIME, 'YYYY/MM/DD HH24:MI:SS'),LOCKWAIT from gv$session where USERNAME='GP_BPVONL' order by inst_id, LOGON_TIME;
  
*************************************************************
GET SQLTEXT FROM THE SESSIONS:

SELECT * FROM V$SQLTEXT WHERE SQL_ID='13aq3aj1vsw19';



###############################################
###############################################
KILL ALL INACTIVE SESSIONS:

select 'ALTER SYSTEM KILL SESSION '||''''||sid||','||serial#||',@'||inst_id||''' IMMEDIATE;' from gv$session where STATUS='INACTIVE';
select 'ALTER SYSTEM KILL SESSION '||''''||sid||','||serial#||',@'||inst_id||''' IMMEDIATE;' from gv$session where STATUS='INACTIVE';
select 'ALTER SYSTEM KILL SESSION '||''''||sid||','||serial#||',@'||inst_id||''' IMMEDIATE;' from gv$session where SID=&sid;
select 'ALTER SYSTEM KILL SESSION '||''''||sid||','||serial#||',@'||inst_id||''' IMMEDIATE;' from gv$session where USERNAME='CHOICEWS_OUSR';


### KILL ALL INACTIVE SESSONS SCRIPT:

set linesize 550;
col username for a11
col machine for a11
col lockwait for a11
col osuser for a10
col SCHEMANAME for a12
col WAIT_CLASS for a12
select 
'ALTER SYSTEM KILL SESSION '||''''||sid||','||serial#||''''||' IMMEDIATE;'
from gv$session where status='INACTIVE'; 

###############################################
###############################################
set linesize 400
set pages 400
select SID,SERIAL#,USERNAME,STATUS,SCHEMANAME,PROGRAM,OSUSER,LOGON_TIME from gv$session where STATUS='INACTIVE' order by LOGON_TIME;


###############################################
###############################################
set linesize 200 
  col PROGRAM for a40 
  col MACHINE for a9 
  col username for a10 
  col TO_CHAR(LOGON_TIME,'YYYY/MM/DDHH24:MI:SS') for a45 
  select inst_id,SID,SERIAL#,STATUS,USERNAME,MACHINE,PROGRAM,to_char(LOGON_TIME, 'YYYY/MM/DD HH24:MI:SS'),LOCKWAIT from gv$session where status='INACTIVE' order by SID
  
 
###############################################
###############################################
Velizar Style - BEST STYLE

col MACHINE for a10
col USERNAME for a10
col PROGRAM for a20
set linesize 500
select inst_id,SID,SERIAL#,STATUS,USERNAME,MACHINE,PROGRAM,to_char(LOGON_TIME, 'YYYY/MM/DD HH24:MI:SS'),LOCKWAIT, SQL_ID from gv$session where SID='121,196,223,240,542,710,800,837,850,912,966,1062,1172,1215,1409,1413,1418,1424';

 
###############################################
###############################################
KILLING SESSIONS:

ALTER SYSTEM KILL SESSION '776,57357' immediate;
ALTER SYSTEM KILL SESSION '836,819' immediate;

###############################################
###############################################
KILLING SESSIONS ON A RAC DB:


ALTER SYSTEM KILL SESSION 'SID,SERIAL ID,@RAC NUMBER';
ALTER SYSTEM KILL SESSION '682,48157,@4';

 
###########################################################################################################################################################################################################################################
###########################################################################################################################################################################################################################################
###########################################################################################################################################################################################################################################
UNABLE TO CONNECT:

###############################################
###############################################
DATABASE UPTIME, DATABASE STATUS:

set linesize 300
col uptime for a24
col status for a6
col db_name for a10
col DATABASE for a15
col hosted_on for a30
col current_time for a22
col database_started for a22
col logins for a7
select
instance_name as DATABASE,
host_name as HOSTED_ON,
status,
logins,
to_char(startup_time, 'MON/DD/YYYY hh24:mi:ss') as DATABASE_STARTED,
to_char(sysdate, 'MON/DD/YYYY hh24:mm:ss') as CURRENT_TIME,
floor(sysdate - startup_time) || 'd / ' ||
trunc( 24*((sysdate-startup_time) - trunc(sysdate-startup_time))) || 'h / ' ||
mod(trunc(1440*((sysdate-startup_time) - trunc(sysdate-startup_time))), 60) ||'m / ' ||
mod(trunc(86400*((sysdate-startup_time) - trunc(sysdate-startup_time))), 60) ||'s' as UPTIME
from v$instance;

###############################################
###############################################

PHYSICAL STANDBY DATABASE CHECK:

set lines 400
col DATABASE_ROLE for a20
col INSTANCE for a20
col OPEN_MODE for a20
col PROTECTION_LEVEL for a20
col SWITCHOVER_STATUS for a20
col PROTECTION_MODE for a25
SELECT DATABASE_ROLE, DB_UNIQUE_NAME INSTANCE, OPEN_MODE, PROTECTION_MODE, PROTECTION_LEVEL, SWITCHOVER_STATUS FROM V$DATABASE; 


###############################################
###############################################
MONITORING ON/OFF:

dbmoncol database oracle ERFPRD_1 OFF
dbmoncol database oracle ERFPRD_1 ON


dbmoncol database oracle SIMPROD_2 OFF
dbmoncol database oracle ABAT_1 OFF
dbmoncol database oracle AQUA_1 OFF

dbspicol database oracle off

sudo /var/opt/OV/bin/instrumentation/dbmoncol database oracle TATQ ON

###############################################
###############################################
USER PASSWORD,PROFILE RESET/CHANGE:


###############################################
###############################################
KEEP THE OLD PASSWORD:

set long 10000
select 'alter user '||username||' identified by values '||REGEXP_SUBSTR(DBMS_METADATA.get_ddl ('USER',USERNAME), '''[^'']+''')||';' from dba_users where username = 'HP_DBSPI';

###############################################
###############################################
BETTER ONE - PASSWORD REUSE :

EXTRACT OLD PASSWORD - REUSE

select 
'alter user "'||username||'" identified by values '''||extract(xmltype(dbms_metadata.get_xml('USER',username)),'//USER_T/PASSWORD/text()').getStringVal()||''';'  old_password 
from dba_users where username = '&Username';

DBSPI_USER		HP_DBSPI

select REGEXP_SUBSTR(DBMS_METADATA.get_ddl ('USER','OO1060'), '''[^'']+''') PASSWD from dual;

###############################################
###############################################
USER INFO:

set linesize 500
SELECT USERNAME, PROFILE, ACCOUNT_STATUS FROM DBA_USERS WHERE USERNAME='HP_DBSPI'; HP_DBSPI

################################################
################################################
PASSWORD HASH:
set long 9999999999
select 
   dbms_metadata.get_ddl('USER', username) || '/' usercreate
from 
   dba_users
where username='DCV10';

#########################################################################
#########################################################################
GET DDL:

select dbms_metadata.get_ddl('INDEX','EDW_CUST_SALES_HIER_ESS_PK','EDWPROD') from dual;
select dbms_metadata.get_ddl('USER','DMT_TRN') from dual;
select dbms_metadata.get_ddl('TABLESPACE','FLEXPLM101') from dual;

select dbms_metadata.get_granted_ddl('SYSTEM_GRANT','USERPROVIF') from dual;
select dbms_metadata.get_granted_ddl('OBJECT_GRANT','USERPROVIF') from dual;
select dbms_metadata.get_granted_ddl('....._GRANT','USERPROVIF') from dual;

select dbms_metadata.get_ddl('CLUSTER','C_MLOG#','SYS') from dual;
select dbms_metadata.get_ddl('CONTEXT','LT_CTX') from dual;
select dbms_metadata.get_ddl('DB_LINK','RMA_CMDB_DBLINK','CMDB') from dual;
select dbms_metadata.get_ddl('DB_LINK','OMIST','ADIDBA') from dual;
select dbms_metadata.get_ddl('FUNCTION','TO_DATE_FUNC','SCOTT') from dual;
select dbms_metadata.get_ddl('INDEX','LCSPRODUCT$UNIQUE50','FLEXPLM101') from dual; 
select dbms_metadata.get_ddl('JAVA_SOURCE','java_util','ADAM') from dual
select dbms_metadata.get_ddl('JAVA_SOURCE','/6c363944_Dumper','SYS') from dual
select dbms_metadata.get_ddl('LIBRARY','UTL_SMT_LIB','SYS') from dual;
select dbms_metadata.get_ddl('MATERIALIZED_VIEW','SMU_CUSTOMER_VIEW','DMT') from dual;
select dbms_metadata.get_ddl('MATERIALIZED_VIEW_LOG','V_NLS_SCHLUESSEL_AUSPR','VNGSYS') from dual;
select dbms_metadata.get_ddl('OPERATOR','OLAP_EXPRESSION') from dual;
select dbms_metadata.get_ddl('OPERATOR','OLAP_EXPRESSION','SYS') from dual;
select dbms_metadata.get_ddl('PACKAGE','ESL_CARDS4') from dual;
select dbms_metadata.get_ddl('PACKAGE','DBMS_AQADM','SYS') from dual;
select dbms_metadata.get_ddl('PACKAGE_BODY','RR_PKG_LOAD_DATA','CANDEM') from dual;
select dbms_metadata.get_ddl('PROCEDURE','SP_TFVALCST_CNPART_DEPOT','CANON_HUB') from dual;
select dbms_metadata.get_ddl('SEQUENCE','STATS$SNAPSHOT_ID','PERFSTAT') from dual;
select dbms_metadata.get_ddl('SYNONYM','/2fddc42_paintARGB_PRE_ONTO_S5','PUBLIC') from dual;
select dbms_metadata.get_ddl('TABLE','DUMMY','EDI') from dual;
select dbms_metadata.get_ddl('TABLESPACE','FTWCT') from dual;
select dbms_metadata.get_ddl('TRIGGER','WWV_BIU_FLOW_FILE_OBJECTS','FLOWS_FILES') from dual;
select dbms_metadata.get_ddl('TYPE','LCSREVISABLEENTITY','SYS') from dual;
select dbms_metadata.get_ddl('TYPE_BODY','ORACLE_LOADER','SYS') from dual;
select dbms_metadata.get_ddl('VIEW','RRMONREQ','AFM') from dual;
select dbms_metadata.get_ddl('VIEW','DBA_PROPAGATION') from dual;
select dbms_metadata.get_ddl('PACKAGE','DBMS_METADATA','SYS') from dual;
SELECT dbms_metadata.get_ddl('ROLE','AFM_ROLE') from dual;
SELECT DBMS_METADATA.GET_GRANTED_DDL('ROLE','ADIDAS_DBA') from dual; 

###############################################
###############################################
PROFILE CHANGE:

alter user ?USER NAME? profile ?PROFILE?;


###############################################
###############################################
PASSWORD RESET:

alter user 'username' identified by "password";


###############################################
###############################################
CHECKS ROLLBACK PROGRESS:

select SYSDATE, START_TIME,START_SCNB,USED_UBLK,LOG_IO,PHY_IO from v$transaction;


###############################################
###############################################
FAST WAY TO RELOCATE DATABASES:

srvctl stop database -d omstrpr && srvctl start database -d omstrpr -n ryelxtraxpdb2

###############################################
###############################################
LISTING ROLES AND PRIVILEGES FOR GIVEN USER:


select granted_role from dba_role_privs where upper(grantee)='ODW2';
select privilege from dba_sys_privs where upper(grantee)='ODW2';
select PRIVILEGE from dba_tab_privs where upper(grantee)='ODW2';
select PRIVILEGE from DBA_COL_PRIVS where upper(grantee)='ODW2';

select privilege 
from dba_sys_privs 
where grantee='ODW2' 
order by 1;


###############################################
###############################################
FIND LISTENER NAME:

SQL> show parameter local

###############################################
###############################################
Shared Pool:

TOTAL SIZE:      select sum(bytes) from v$sgastat where pool = 'shared pool';
FREE:                 select sum(decode(name,'free memory',bytes)) from v$sgastat where pool = 'shared pool';

select pool, name, bytes/(1024 * 1024) size_mb from v$sgastat where pool='shared pool' and bytes > (1024 * 1024);
###############################################
###############################################
CHECK RESOURCES: PROCESSES AND SESSIONS

set linesize 300
col RESOURCE_NAME for a26
col INITIAL_ALLOCATION for a18
col LIMIT_VALUE for a12
select * from v$resource_limit;


###############################################
###############################################
CHECK CORRUPTED BLOCKS:

RMAN> backup validate check logical database; 
#RMAN does not physically backup the database with this command
#but it reads all blocks and checks for corruptions.
#If it finds corrupted blocks it will place the information about the corruption into a view:
SQL> select * from v$database_block_corruption;



###############################################
###############################################
DB AND DF MON:

grep -v ^# /var/opt/OV/conf/OpC/df_mon.cfg
grep -v ^# /var/opt/OV/conf/OpC/ps_mon.cfg
grep -v ^# /var/opt/OV/dbspi/db_mon.cfg  ---> Listener monitoring
/var/opt/OV/dbspi/dbmon-event.cfg
C:\usr\OV\dbspi

cat /var/opt/OV/dbspi/db_mon.cfg | grep -v ^# ---> all active metrics

###############################################
###############################################
AWR

@$ORACLE_HOME/rdbms/admin/awrrpt.sql


###############################################
###############################################
CHECKING USER ROLES AND PRIVILEGES:

select privilege
from dba_sys_privs 
where grantee='AMP' 
order by 1;


###############################################
###############################################
CHECK FOR FAILED INDEXES

SELECT OWNER,OBJECT_TYPE,OBJECT_NAME FROM DBA_OBJECTS WHERE STATUS= 'INVALID' and owner='RWIN';

select object_type, object_name, status from user_objects where status = 'INVALID' order by object_type, object_name; 

SELECT OWNER,OBJECT_TYPE,OBJECT_NAME FROM DBA_OBJECTS WHERE STATUS= 'INVALID' and owner='HCMDB1010';



###############################################
###############################################
CHECK CURSORS METRIC-31:

set linesize 200 
col PROGRAM for a40 
col MACHINE for a9 
col username for a10 
col TO_CHAR(LOGON_TIME,'YYYY/MM/DDHH24:MI:SS') for a45 
select inst_id,SID,SERIAL#,STATUS,USERNAME,MACHINE,PROGRAM,to_char(LOGON_TIME, 'YYYY/MM/DD HH24:MI:SS'),LOCKWAIT from gv$session where status='INACTIVE' order by SID;

###############################################
###############################################
CHECK DATABASE CURSORS

set linesize 333
col MAX_OPEN_CUR for a15
select max(a.value) as highest_open_cur, p.value as max_open_cur
  from v$sesstat a, v$statname b, v$parameter p
  where a.statistic# = b.statistic# 
  and b.name = 'opened cursors current'
  and p.name= 'open_cursors'
  group by p.value; 
  
  
 ###############################################
###############################################
 COPY FILES BETWEEN SERVERS:

scp hpmnrang@deheremcln347:/opt/oracle/orasave/CHG0052888_RMA* .  <--- Runva se ot destination host-a i se polzva ERM personal password-a


###############################################
###############################################
FIXING THE ^M IN UPLOADED SCRIPTS:

:%s/ctrl+vm//g      <------- vm se cakat posledovatelno dokato se darji ctrl. trqbva da se poluchi ^M


###############################################
###############################################
VIEW FOR DINAMIC AND STATIC PARAMETERS:

v$parameter 


###############################################
###############################################
/local/outils/fp

###############################################
###############################################
FTP COPPY FILES:

as root#ftp IP
Username: ********
Password: ********
once you find what you are looking for:
get coppy the file
It will download it to the folder from which you typed FTP

###############################################
###############################################
STARTING A SQL SCRIPT IN NOHUP:

nohup sqlplus "/ as sysdba" @eTTStatisticCollection.sql > eTTStatisticCollection.log &

###############################################
###############################################
CHECKING USER UNLOCK/LOCK USER

col USERNAME for a20
col PROFILE for a20
col ACCOUNT_STATUS for a20
select USERNAME, PROFILE, ACCOUNT_STATUS, DEFAULT_TABLESPACE, TEMPORARY_TABLESPACE from dba_users where username='C##HPDBSPI';  hp_dbspi

set long 10000
select 'alter user '||username||' identified by values '||REGEXP_SUBSTR(DBMS_METADATA.get_ddl ('USER',USERNAME), '''[^'']+''')||';'
from dba_users
where username = 'HP_DBSPI';

ALTER USER user_name ACCOUNT UNLOCK;

###############################################
###############################################
EXTRACT OLD PASSWORD - REUSE

select 
'alter user "'||username||'" identified by values '''||extract(xmltype(dbms_metadata.get_xml('USER',username)),'//USER_T/PASSWORD/text()').getStringVal()||''';'  old_password 
from 
   dba_users
where
username = 'HP_DBSPI';

DBSPI_USER

select REGEXP_SUBSTR(DBMS_METADATA.get_ddl ('USER','OO1060'), '''[^'']+''') PASSWD from dual;

#### SHOW YOU ALL LOCK USERS

select username,
       account_status 
  from dba_users 
 where lock_date is not null;

###############################################
###############################################

DBA_REGISTRY_SQLPATCH - information about new patches (CPU and PSU)

set lines 300 pages 9999
column APPLIED_TIME format a25
column DESCRIPTION format a80
column HOST_NAME format a20
column BUNDLE_SERIES for a15
select 
b.instance_name,
b.host_name,
b.version,
a.action,
a.status,
TO_CHAR(a.action_time,'YYYY-MON-DD HH24:MI:SS') applied_time,
a.bundle_series,
a.description 
from 
dba_registry_sqlpatch a,
(select instance_name,host_name,version from v$instance) b
--where rownum < 3
/

###############################################
###############################################
##### GRANT SELECT ON THE TABLES OWNED BY A SPECIFIC USER

--Grant "select" on the tables owned by a specific user
set serveroutput on verify off
DECLARE
v_grant_cmd varchar(200);
v_owner varchar(30) := upper('&input_owner');
v_sql_user varchar(30) := upper('&input_sql_user');
BEGIN
  FOR i IN (select object_name from dba_objects
            where object_type in ('TABLE','VIEW')
            and owner=v_owner)
  LOOP
  v_grant_cmd := ('grant select on '||'"'||v_owner||'"."'||i.object_name||'"'||' to "'||v_sql_user||'"');
  --dbms_output.put_line('Executing: '||v_grant_cmd);
  dbms_output.put_line(v_grant_cmd||';');
  --EXECUTE IMMEDIATE v_grant_cmd;
  END LOOP;
END;
/ 

select 



#############

--Grant "select" on the tables owned by a specific user
set serveroutput on verify off
DECLARE
v_grant_cmd varchar(200);
v_owner varchar(30) := upper('&input_owner');
v_sql_user varchar(30) := upper('&input_sql_user');
BEGIN
  FOR i IN (select object_name from dba_objects
            where object_type in ('TABLE','VIEW')
            and owner=v_owner
                     and status <>'INVALID'
                     and generated='N')
  LOOP
       BEGIN
              v_grant_cmd := ('grant select on '||'"'||v_owner||'"."'||i.object_name||'"'||' to "'||v_sql_user||'"');
              dbms_output.put_line('Executing: '||v_grant_cmd);
              execute immediate(v_grant_cmd);
       EXCEPTION
              WHEN OTHERS THEN
              dbms_output.put_line('Error '||SQLERRM||' at '||v_grant_cmd);
       END;
  END LOOP;
END;
/ 

#################### GET OBJECT SYNONYM

set linesize 400
set pagesize 50000
set long 10000000
spool AVSALESLINE_SYNONYM

SELECT DBMS_METADATA.GET_DDL (object_type => 'SYNONYM', name => 'AVSALESLINE', schema=>'BMSSA') FROM dual;

spool off 

####

select iot_name from dba_tables where table_name in('SYS_IOT_OVER_97717','SYS_IOT_OVER_97722','SYS_IOT_OVER_97725','SYS_IOT_OVER_97369','SYS_IOT_OVER_97372','SYS_IOT_OVER_97661','SYS_IOT_OVER_97661','SYS_IOT_OVER_97668','SYS_IOT_OVER_97671','SYS_IOT_OVER_97674','SYS_IOT_OVER_97677','SYS_IOT_OVER_97686','SYS_IOT_OVER_97689','SYS_IOT_OVER_97692','SYS_IOT_OVER_97698','SYS_IOT_OVER_97706');

Enter value for input_owner: DBFRWKUSER
Enter value for input_sql_user: SQL_HTOURE
Error ORA-25191: cannot reference overflow table of an index-organized table at
grant select on "DBFRWKUSER"."SYS_IOT_OVER_97717" to "SQL_HTOURE"
Error ORA-25191: cannot reference overflow table of an index-organized table at
grant select on "DBFRWKUSER"."SYS_IOT_OVER_97722" to "SQL_HTOURE"
Error ORA-25191: cannot reference overflow table of an index-organized table at
grant select on "DBFRWKUSER"."SYS_IOT_OVER_97725" to "SQL_HTOURE"
Error ORA-25191: cannot reference overflow table of an index-organized table at
grant select on "DBFRWKUSER"."SYS_IOT_OVER_97369" to "SQL_HTOURE"
Error ORA-25191: cannot reference overflow table of an index-organized table at
grant select on "DBFRWKUSER"."SYS_IOT_OVER_97372" to "SQL_HTOURE"
Error ORA-25191: cannot reference overflow table of an index-organized table at
grant select on "DBFRWKUSER"."SYS_IOT_OVER_97661" to "SQL_HTOURE"
Error ORA-25191: cannot reference overflow table of an index-organized table at
grant select on "DBFRWKUSER"."SYS_IOT_OVER_97661" to "SQL_HTOURE"
Error ORA-25191: cannot reference overflow table of an index-organized table at
grant select on "DBFRWKUSER"."SYS_IOT_OVER_97668" to "SQL_HTOURE"
Error ORA-25191: cannot reference overflow table of an index-organized table at
grant select on "DBFRWKUSER"."SYS_IOT_OVER_97671" to "SQL_HTOURE"
Error ORA-25191: cannot reference overflow table of an index-organized table at
grant select on "DBFRWKUSER"."SYS_IOT_OVER_97674" to "SQL_HTOURE"
Error ORA-25191: cannot reference overflow table of an index-organized table at
grant select on "DBFRWKUSER"."SYS_IOT_OVER_97677" to "SQL_HTOURE"
Error ORA-25191: cannot reference overflow table of an index-organized table at
grant select on "DBFRWKUSER"."SYS_IOT_OVER_97686" to "SQL_HTOURE"
Error ORA-25191: cannot reference overflow table of an index-organized table at
grant select on "DBFRWKUSER"."SYS_IOT_OVER_97689" to "SQL_HTOURE"
Error ORA-25191: cannot reference overflow table of an index-organized table at
grant select on "DBFRWKUSER"."SYS_IOT_OVER_97692" to "SQL_HTOURE"
Error ORA-25191: cannot reference overflow table of an index-organized table at
grant select on "DBFRWKUSER"."SYS_IOT_OVER_97698" to "SQL_HTOURE"
Error ORA-25191: cannot reference overflow table of an index-organized table at
grant select on "DBFRWKUSER"."SYS_IOT_OVER_97706" to "SQL_HTOURE"

grant select on "DBFRWKUSER"."TCHNCAL_CNTXT" to "SQL_HTOURE";
grant select on "DBFRWKUSER"."RESUBMISSION" to "SQL_HTOURE";
grant select on "DBFRWKUSER"."BATCH" to "SQL_HTOURE";
grant select on "DBFRWKUSER"."PROCESS_CNTXT" to "SQL_HTOURE";
grant select on "DBFRWKUSER"."BATCH_STS_LST" to "SQL_HTOURE";
grant select on "DBFRWKUSER"."TGROUP_TO_XCHANGE" to "SQL_HTOURE";
grant select on "DBFRWKUSER"."TGROUP_TO_COMPONENT" to "SQL_HTOURE";
grant select on "DBFRWKUSER"."TGROUP" to "SQL_HTOURE";
grant select on "DBFRWKUSER"."COMPONENT" to "SQL_HTOURE";
grant select on "DBFRWKUSER"."ADRSS_COMPNT" to "SQL_HTOURE";
grant select on "DBFRWKUSER"."USAGE_COMPNT" to "SQL_HTOURE";
grant select on "DBFRWKUSER"."TYPE_XCHANGE" to "SQL_HTOURE";
grant select on "DBFRWKUSER"."LOG_EVENT" to "SQL_HTOURE";
grant select on "DBFRWKUSER"."MSG_BODY" to "SQL_HTOURE";
grant select on "DBFRWKUSER"."APPLI_CONTEXT" to "SQL_HTOURE";


select iot_name from dba_tables where table_name in(
'SYS_IOT_OVER_96769',
'SYS_IOT_OVER_96773',
'SYS_IOT_OVER_96776',
'SYS_IOT_OVER_96779',
'SYS_IOT_OVER_96782',
'SYS_IOT_OVER_96791',
'SYS_IOT_OVER_96794',
'SYS_IOT_OVER_96797',
'SYS_IOT_OVER_96803',
'SYS_IOT_OVER_96811',
'SYS_IOT_OVER_96822',
'SYS_IOT_OVER_96827',
'SYS_IOT_OVER_96830',
'SYS_IOT_OVER_96379',
'SYS_IOT_OVER_96382',
'SYS_IOT_OVER_96766');


grant select on "DBFRWKUSER"."TCHNCAL_CNTXT" to "SQL_HTOURE";
grant select on "DBFRWKUSER"."RESUBMISSION" to "SQL_HTOURE";
grant select on "DBFRWKUSER"."BATCH" to "SQL_HTOURE";
grant select on "DBFRWKUSER"."PROCESS_CNTXT" to "SQL_HTOURE";
grant select on "DBFRWKUSER"."COMPONENT" to "SQL_HTOURE";
grant select on "DBFRWKUSER"."ADRSS_COMPNT" to "SQL_HTOURE";
grant select on "DBFRWKUSER"."USAGE_COMPNT" to "SQL_HTOURE";
grant select on "DBFRWKUSER"."TYPE_XCHANGE" to "SQL_HTOURE";
grant select on "DBFRWKUSER"."BATCH_STS_LST" to "SQL_HTOURE";
grant select on "DBFRWKUSER"."TGROUP_TO_XCHANGE" to "SQL_HTOURE";
grant select on "DBFRWKUSER"."TGROUP_TO_COMPONENT" to "SQL_HTOURE";
grant select on "DBFRWKUSER"."TGROUP" to "SQL_HTOURE";
grant select on "DBFRWKUSER"."XCHANGE" to "SQL_HTOURE";
grant select on "DBFRWKUSER"."LOG_EVENT" to "SQL_HTOURE";
grant select on "DBFRWKUSER"."MSG_BODY" to "SQL_HTOURE";
grant select on "DBFRWKUSER"."APPLI_CONTEXT" to "SQL_HTOURE";



### Cross reference between SID and sPID

alter session set nls_date_format='DD-MON HH24:MI:SS';
set long 999999
set lines 250
set pages 250
col machine for a20
col program for a25
col username for a20
col osuser for a10
col LOGON_TIME for a20
col CLIENTPROGRAM for a35
col module for a20
col status for a8
col event for a30
col ClientPID for a9
col ServerPID for a10
select s.sid, s.serial#, s.username,
       to_char(s.logon_time,'DD-MON HH24:MI:SS') logon_time,
       p.pid oraclepid, p.spid "ServerPID", s.process "ClientPID",
       s.program clientprogram, s.module, s.machine, s.osuser,
       s.status, s.last_call_et, s.sql_id
from v$session s, v$process p
where p.spid in (
 11472,
 11434,
11480,
 8987,
3205,
 23018,
11587,
13828,
13834,
 31459
)  --server processes
and s.paddr=p.addr
order by s.sid
/ 




########## CHECK ARCHIVELOG SIZE FOR PAST AND COUNT REDO SWITCH 


SELECT to_char(FIRST_TIME, 'YYYY/MM/DD HH24') "Date and hour", count(to_char(FIRST_TIME, 'YYYY/MM/DD-HH24')) "Count redo switch", ROUND(SUM(BLOCK_SIZE * NVL(BLOCKS ,BLOCKS))/1024/1024) MB_size 
from v$archived_log 
where dest_id=1
and FIRST_TIME between trunc(sysdate-7) and sysdate 
GROUP BY to_char(FIRST_TIME, 'YYYY/MM/DD HH24') 
order by 1 
/ 

########### CHECK FOR INVALID OBJECTS #######

col OWNER for a20
col OBJECT_TYPE for a20
col OBJECT_NAME for a20
COLUMN object_name FORMAT A30
SELECT owner,
       object_type,
       object_name,
       status
FROM   dba_objects
WHERE  status = 'INVALID'
ORDER BY owner, object_type, object_name;



### FULL ASM CHECK FOR DATAFILES ###


col gname form a30
col dbname form a10
col file_type form a20
set lines 300 pages 600 
SELECT
    gname,
    dbname,
    file_type,
    round(SUM(space)/1024/1024) mb,
    round(SUM(space)/1024/1024/1024) gb,
    COUNT(*) "#FILES"
FROM
    (
        SELECT
            gname,
            regexp_substr(full_alias_path, '[[:alnum:]_]*',1,4) dbname,
            file_type,
            space,
            aname,
            system_created,
            alias_directory
        FROM
            (
                SELECT
                    concat('+'||gname, sys_connect_by_path(aname, '/')) full_alias_path,
                    system_created,
                    alias_directory,
                    file_type,
                    space,
                    level,
                    gname,
                    aname
                FROM
                    (
                        SELECT
                            b.name            gname,
                            a.parent_index    pindex,
                            a.name            aname,
                            a.reference_index rindex ,
                            a.system_created,
                            a.alias_directory,
                            c.type file_type,
                            c.space
                        FROM
                            v$asm_alias a,
                            v$asm_diskgroup b,
                            v$asm_file c
                        WHERE
                            a.group_number = b.group_number
                        AND a.group_number = c.group_number(+)
                        AND a.file_number = c.file_number(+)
                        AND a.file_incarnation = c.incarnation(+) ) START WITH (mod(pindex, power(2, 24))) = 0
                AND rindex IN
                    (
                        SELECT
                            a.reference_index
                        FROM
                            v$asm_alias a,
                            v$asm_diskgroup b
                        WHERE
                            a.group_number = b.group_number
                        AND (
                                mod(a.parent_index, power(2, 24))) = 0
                            ) CONNECT BY prior rindex = pindex 
							)
        WHERE
            NOT file_type IS NULL
            and system_created = 'Y' )
GROUP BY
    gname,
    dbname,
    file_type
ORDER BY
    gname,
    dbname,
    file_type
/

######## CHECK FOR OBJECTS

SELECT * FROM ALL_OBJECTS WHERE OBJECT_NAME = 'IMA_SHORTS_PKG_ES'


#################################################
#################################################

### Password cannot be reused workarround:

select profile from dba_users where username='HP_DBSPI';

#####

create profile CHACHA limit password_verify_function null;
alter profile CHACHA limit PASSWORD_REUSE_MAX UNLIMITED;
alter profile CHACHA limit PASSWORD_REUSE_TIME UNLIMITED;

alter user HP_DBSPI profile CHACHA;

alter user HP_DBSPI identified by "hp_dbspi111111";

alter user HP_DBSPI profile DEFAULT;

drop profile CHACHA;


###################################################
###################################################
RECOMPILE

For small numbers of objects you may decide that a manual recompilation is sufficient. The following example shows the compile syntax for several object types.
ALTER PACKAGE my_package COMPILE;
ALTER PACKAGE EMEA_INT.IMA_SHORTS_PKG_ES COMPILE BODY;
ALTER PROCEDURE my_procedure COMPILE;
ALTER FUNCTION my_function COMPILE;
ALTER TRIGGER my_trigger COMPILE;
ALTER VIEW my_view COMPILE; 

###################################################
###################################################

SQL ID

set long 9000
select sql_id,sql_fulltext 
from v$sqlarea 
where sql_id='&SQL_ID'
/  


##################################################
##################################################

########## CHECK CORRUPTED BLOCKS:


#block coruption
RMAN> backup validate check logical database; 
#RMAN does not physically backup the database with this command
#but it reads all blocks and checks for corruptions.
#If it finds corrupted blocks it will place the information about the corruption into a view:
SQL> select * from v$database_block_corruption;

http://www.dba-oracle.com/t_rman_repair_corrupt_blocks.htm

Master Note for Handling Oracle Database Corruption Issues (Doc ID 1088018.1)

###List corrupted blocks

set pagesize 2000
set linesize 250
SELECT e.owner, e.segment_type, e.segment_name, e.partition_name, c.file#,greatest(e.block_id, c.block#) corr_start_block#,least(e.block_id+e.blocks-1, c.block#+c.blocks-1) 
corr_end_block#,least(e.block_id+e.blocks-1, c.block#+c.blocks-1) - greatest(e.block_id, c.block#) + 1 blocks_corrupted,null description FROM dba_extents e, v$database_block_corruption c
WHERE e.file_id = c.file#
AND e.block_id <= c.block# + c.blocks - 1
AND e.block_id + e.blocks - 1 >= c.block#
UNION
SELECT s.owner, s.segment_type, s.segment_name, s.partition_name, c.file#,header_block corr_start_block#,header_block corr_end_block#,1 blocks_corrupted,'Segment Header' description
FROM dba_segments s, v$database_block_corruption c
WHERE s.header_file = c.file#
AND s.header_block between c.block# and c.block# + c.blocks - 1
UNION
SELECT null owner, null segment_type, null segment_name, null partition_name, c.file#,greatest(f.block_id, c.block#) corr_start_block#,least(f.block_id+f.blocks-1, c.block#+c.blocks-1) corr_end_block#,least(f.block_id+f.blocks-1, c.block#+c.blocks-1) - greatest(f.block_id, c.block#) + 1 blocks_corrupted , 'Free Block' description
FROM dba_free_space f, v$database_block_corruption c
WHERE f.file_id = c.file#
AND f.block_id <= c.block# + c.blocks - 1
AND f.block_id + f.blocks - 1 >= c.block#
order by file#, corr_start_block#  

###########IDENTIFY OS PROCESS ID BASED ON DATABASE SID :

col sid format 999999
col username format a20
col osuser format a15
select a.sid, a.serial#,a.username, a.osuser, b.spid
from v$session a, v$process b
where a.paddr= b.addr
and a.sid='&sid'
order by a.sid;

#################### ASM CHECK DISK GROUPS


SET LINESIZE  200
SET PAGESIZE  9999
SET VERIFY    off 
COLUMN disk_group_name        FORMAT a20           HEAD 'Disk Group Name'
COLUMN disk_file_path         FORMAT a40           HEAD 'Path'
COLUMN disk_file_name         FORMAT a20           HEAD 'File Name'
COLUMN disk_file_fail_group   FORMAT a20           HEAD 'Fail Group'
COLUMN total_mb               FORMAT 999,999,999   HEAD 'File Size (MB)'
COLUMN used_mb                FORMAT 999,999,999   HEAD 'Used Size (MB)'
COLUMN pct_used               FORMAT 999.99        HEAD 'Pct. Used'
COLUMN State				  FORMAT a20           HEAD 'State'
break on report on disk_group_name skip 1
compute sum label ""              of total_mb used_mb on disk_group_name
compute sum label "Grand Total: " of total_mb used_mb on report
SELECT
 GROUP_NUMBER          Group_number
  , NVL(a.name, '[CANDIDATE]')                       disk_group_name
  , b.path                                           disk_file_path
  , b.name                                           disk_file_name
  , b.failgroup                                      disk_file_fail_group
  , b.total_mb                                       total_mb
 , (b.total_mb - b.free_mb)                         used_mb,
 a.STATE                                            State
--  , ROUND((1- (b.free_mb / b.total_mb))*100, 2)      pct_used
FROM
	v$asm_diskgroup a RIGHT OUTER JOIN v$asm_disk b USING (group_number)
ORDER BY b.name
/

################## SQL*Net message from client

select event, time_waited
from v$session_event
where sid = ( select sid from v$mystat where rownum = 1 )
and event = 'SQL*Net message from client'
/

################## CHECKING WAITS - CHECK QUERY ON LEVEL SEGMENTS

select sid, seq#, EVENT,  WAIT_CLASS,  SECONDS_IN_WAIT,p1, p2 from v$session_wait where sid=1161;

################## ANALYZE SCHEMA TABLES

exec dbms_stats.gather_schema_stats( -
     ownname          => 'GOMAC_BASE_OMS', -
     estimate_percent => dbms_stats.auto_sample_size, -
     method_opt       => 'for all columns size repeat', -
     degree           => 7 -
   )

################## ANALYZE SPECIFIC TABLE and INDEX (CACADE=YES)
   
   exec  dbms_stats.gather_table_stats( -
      ownname          => 'PERFSTAT', -
      tabname          => 'STATS$SNAPSHOT' -
      estimate_percent => dbms_stats.auto_sample_size, -
      method_opt       => 'for all columns size skewonly', -
      cascade          => true, -
      degree           => 7 -
   )

################### MVIEW SNAPSHOT:

BEGIN
  DBMS_SNAPSHOT.REFRESH(
    LIST                 => 'WEBEETR_RPT.AVLMEMBERS_RPL'
   ,METHOD               => 'C'
   ,PUSH_DEFERRED_RPC    => TRUE
   ,REFRESH_AFTER_ERRORS => FALSE
   ,PURGE_OPTION         => 1
   ,PARALLELISM          => 0
   ,ATOMIC_REFRESH       => TRUE
   ,NESTED               => FALSE);
END;
/
