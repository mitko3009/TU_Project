/********************************************************************************
*********       E-mail subject: KBCCFWEB-2160
*********             Instance: PROD
*********          Description: 
Problem:
There was slow SQL from screen on PROD.

Analysis:
The problem was that because of joining tables with nested subqueries Oracle was using inappropriate execution plan  
making full scan of table G_INDIVIDU a lot of times.

Suggestion:
Please rewrite the query as it is show in the New SQL section below.

*********               SQL_ID: 
*********      Program/Package: 
*********              Request: Petar Gichev
*********               Author: Dimitar Dimitrov
********* Received e-mail date: 16/10/2023
*********      Resolution date: 16/10/2023
*********  Trace old file here: \\epox\specifs\performance\tmp\
*********  Trace new file here:
***********************************************************************************/

/********************************OLD SQL*******************************************/
var B1 VARCHAR2(32);
exec :B1 := '45724749_1';   
var B2 NUMBER;
exec :B2 := 1001;
var B3 NUMBER;
exec :B3 := 1;

SELECT *
  FROM (SELECT /*+ first_rows(1001)*/
         foo.*, ROWNUM rnum
          FROM (SELECT type itemType,
                       reference itemRef,
                       debtor_number dbNum,
                       (SELECT nom
                          FROM g_individu
                         WHERE 1 = 1
                           AND refindividu IN
                               (SELECT refindividu
                                  FROM t_individu
                                 WHERE societe = 'CLIENT_NUMBER'
                                   AND refext2 =
                                       (SELECT refcl
                                          FROM t_invlot
                                         WHERE lot_id = l.lot_id)
                                   AND refext = l.debtor_number)
                           AND ROWNUM = 1) dbName,
                       due_date dueDate,
                       item_date itemDate,
                       lot_id lotId,
                       seqnum contractNum,
                       currency currency,
                       amount openAmt,
                       invoice_amount initialAmt,
                       imx_err_mess errorMsg
                  FROM t_invlot_item l
                 WHERE 1 = 1
                   AND lot_id = :B1
                 ORDER BY seqnum asc, seqnum) foo
         WHERE ROWNUM <= :B2)
 WHERE 1 = 1
   AND rnum >= :B3;
/********************************OLD SQL*******************************************/
/********************************OLD Metrics***************************************/
/*
Plan hash value: 414442499
-----------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                               | Name           | Starts | E-Rows | A-Rows |   A-Time   | Buffers | Reads  |
-----------------------------------------------------------------------------------------------------------------------------
|   0 | CREATE TABLE STATEMENT                  |                |      1 |        |      0 |00:00:00.01 |       0 |      0 |
|*  1 |  COUNT STOPKEY                          |                |     24 |        |     23 |00:12:21.75 |     319M|      4 |
|*  2 |   FILTER                                |                |     24 |        |     23 |00:12:21.75 |     319M|      4 |
|   3 |    TABLE ACCESS FULL                    | G_INDIVIDU     |     24 |   6095K|     81M|00:00:36.26 |    8603K|      0 |
|*  4 |    TABLE ACCESS BY INDEX ROWID BATCHED  | T_INDIVIDU     |     81M|      1 |     23 |00:11:48.40 |     324M|      4 |
|*  5 |     INDEX SKIP SCAN                     | SOC_INDIV      |     81M|      1 |     81M|00:11:03.73 |     243M|      3 |
|   6 |      TABLE ACCESS BY INDEX ROWID BATCHED| T_INVLOT       |      1 |      1 |      1 |00:00:00.01 |       3 |      0 |
|*  7 |       INDEX RANGE SCAN                  | INVLOT_LOTID   |      1 |      1 |      1 |00:00:00.01 |       2 |      0 |
|   8 |  LOAD AS SELECT                         | DD_TMP_TABLE   |      1 |        |      0 |00:00:00.01 |       0 |      0 |
|   9 |   OPTIMIZER STATISTICS GATHERING        |                |      1 |   1001 |     71 |00:12:21.75 |     319M|      5 |
|* 10 |    VIEW                                 |                |      1 |   1001 |     71 |00:12:21.75 |     319M|      5 |
|* 11 |     COUNT STOPKEY                       |                |      1 |        |     71 |00:12:21.75 |     319M|      5 |
|  12 |      VIEW                               |                |      1 |   1001 |     71 |00:12:21.75 |     319M|      5 |
|  13 |       TABLE ACCESS BY INDEX ROWID       | T_INVLOT_ITEM  |      1 |   1001 |     72 |00:00:00.01 |      39 |      1 |
|* 14 |        INDEX RANGE SCAN                 | INVLOT_ITEM_PK |      1 |   2887 |     72 |00:00:00.01 |       3 |      0 |
-----------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   1 - filter(ROWNUM=1)
   2 - filter( IS NOT NULL)
   4 - filter("REFINDIVIDU"=:B1)
   5 - access("SOCIETE"='CLIENT_NUMBER' AND "REFEXT"=:B1 AND "REFEXT2"=)
   7 - access("LOT_ID"=:B1)
  10 - filter("RNUM">=1)
  11 - filter(ROWNUM<=1001)
  14 - access("LOT_ID"='45724749_1')
*/
/********************************OLD Metrics***************************************/

/********************************New SQL*******************************************/
SELECT *
  FROM (SELECT /*+ first_rows(1001)*/
         foo.*, ROWNUM rnum
          FROM (SELECT type itemType,
                       reference itemRef,
                       debtor_number dbNum,
                       (SELECT gi.nom
                          FROM g_individu gi,
                               t_individu ti,
                               t_invlot tl
                         WHERE 1 = 1
                           AND tl.lot_id = l.lot_id
                           AND ti.refext = l.debtor_number
                           AND ti.refext2 = tl.refcl
                           AND ti.societe = 'CLIENT_NUMBER'
                           AND gi.refindividu = ti.refindividu
                           AND ROWNUM = 1) dbName,
                       due_date dueDate,
                       item_date itemDate,
                       lot_id lotId,
                       seqnum contractNum,
                       currency currency,
                       amount openAmt,
                       invoice_amount initialAmt,
                       imx_err_mess errorMsg
                  FROM t_invlot_item l
                 WHERE 1 = 1
                   AND lot_id = :B1
                 ORDER BY seqnum asc, seqnum) foo
         WHERE ROWNUM <= :B2)
 WHERE 1 = 1
   AND rnum >= :B3;
/********************************New SQL*******************************************/
/********************************New Metrics***************************************/
/*
Plan hash value: 3290807974
--------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                               | Name           | Starts | E-Rows | A-Rows |   A-Time   | Buffers | Reads  | Writes |
--------------------------------------------------------------------------------------------------------------------------------------
|   0 | CREATE TABLE STATEMENT                  |                |      1 |        |      0 |00:00:00.14 |    3221 |    214 |     15 |
|*  1 |  COUNT STOPKEY                          |                |    257 |        |    257 |00:00:00.08 |    2562 |    159 |      0 |
|   2 |   NESTED LOOPS                          |                |    257 |      1 |    257 |00:00:00.08 |    2562 |    159 |      0 |
|   3 |    NESTED LOOPS                         |                |    257 |      1 |    257 |00:00:00.08 |    2305 |    159 |      0 |
|   4 |     NESTED LOOPS                        |                |    257 |      1 |    257 |00:00:00.05 |    1534 |    104 |      0 |
|   5 |      TABLE ACCESS BY INDEX ROWID BATCHED| T_INVLOT       |    257 |      1 |    257 |00:00:00.01 |     519 |      0 |      0 |
|*  6 |       INDEX RANGE SCAN                  | INVLOT_LOTID   |    257 |      1 |    257 |00:00:00.01 |     262 |      0 |      0 |
|   7 |      TABLE ACCESS BY INDEX ROWID BATCHED| T_INDIVIDU     |    257 |      1 |    257 |00:00:00.05 |    1015 |    104 |      0 |
|*  8 |       INDEX RANGE SCAN                  | SOC_INDIV      |    257 |      1 |    257 |00:00:00.04 |     758 |     94 |      0 |
|*  9 |     INDEX UNIQUE SCAN                   | IND_REFINDIV   |    257 |      1 |    257 |00:00:00.03 |     771 |     55 |      0 |
|  10 |    TABLE ACCESS BY INDEX ROWID          | G_INDIVIDU     |    257 |      1 |    257 |00:00:00.01 |     257 |      0 |      0 |
|  11 |  LOAD AS SELECT                         | DD_TMP_TABLE   |      1 |        |      0 |00:00:00.14 |    3221 |    214 |     15 |
|  12 |   OPTIMIZER STATISTICS GATHERING        |                |      1 |   1001 |   1001 |00:00:00.10 |    2905 |    193 |      0 |
|* 13 |    VIEW                                 |                |      1 |   1001 |   1001 |00:00:00.10 |    2905 |    193 |      0 |
|* 14 |     COUNT STOPKEY                       |                |      1 |        |   1001 |00:00:00.10 |    2905 |    193 |      0 |
|  15 |      VIEW                               |                |      1 |   1001 |   1001 |00:00:00.10 |    2905 |    193 |      0 |
|  16 |       TABLE ACCESS BY INDEX ROWID       | T_INVLOT_ITEM  |      1 |   1001 |   1001 |00:00:00.02 |     343 |     34 |      0 |
|* 17 |        INDEX RANGE SCAN                 | INVLOT_ITEM_PK |      1 |   2887 |   1001 |00:00:00.01 |       6 |      0 |      0 |
--------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   1 - filter(ROWNUM=1)
   6 - access("TL"."LOT_ID"=:B1)
   8 - access("TI"."SOCIETE"='CLIENT_NUMBER' AND "TI"."REFEXT"=:B1 AND "TI"."REFEXT2"="TL"."REFCL")
       filter("TI"."REFEXT2" IS NOT NULL)
   9 - access("GI"."REFINDIVIDU"="TI"."REFINDIVIDU")
  13 - filter("RNUM">=1)
  14 - filter(ROWNUM<=1001)
  17 - access("LOT_ID"='45724749_1')
*/
/********************************New Metrics***************************************/

/********************************Index statistics**********************************/

/********************************Other SQLs****************************************/          
/*

*/ 
/********************************Other SQLs****************************************/              
