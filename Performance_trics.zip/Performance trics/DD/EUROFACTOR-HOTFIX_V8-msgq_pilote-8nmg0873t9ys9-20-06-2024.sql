/********************************************************************************
*********       E-mail subject: EFDE2DEV-1624
*********             Instance: HOTFIX V8
*********          Description: 
Problem:
Slowness in the pilote calls processed on HOTFIX V8.

Analysis:
After the analyze we found that SQL 8nmg0873t9ys9, which is SE variable ds_lim_cmt is responsible for 99% of the time.
The problem in it is that Oracle CBO expect 1 rows from index G_PIECE$ID_VENTE of table G_PIECE and makes bad execution plan.
The solution here is to force Oracle to start the execution from table t_elements accesing by refdoss and than access table g_piece through the refpiece.
Also, we removed the nvl of the typpiece and added and rownum = 1 in the select in the decode.

Suggestion:
Please change the query from SE variable ds_lim_cmt as it is shown in the New SQL section below.

*********               SQL_ID: 8nmg0873t9ys9
*********      Program/Package: SE variable ds_lim_cmt
*********              Request: Ivaylo Tsvetkov 
*********               Author: Dimitar Dimitrov
********* Received e-mail date: 20/06/2024
*********      Resolution date: 20/06/2024
*********  Trace old file here: \\epox\specifs\performance\tmp\
*********  Trace new file here:
***********************************************************************************/

/********************************OLD SQL*******************************************/

VAR refdos VARCHAR2(32);
EXEC :refdos := '2406130056';

select decode((select count(*)
                 from t_elements e,
                      g_piece p
                where nvl(p.typpiece, 'xxx') = 'REQUEST_LIMITE'
                  and p.refpiece = e.refelem
                  and p.gpirole in ('DC', 'DT')
                  and e.refdoss = :refdos
                  and e.typeelem = 'pr'
                  and p.typedoc = 'C' ),
               0,
              '0',
              '1')
  from g_dossier      d,
       t_intervenants t,
       t_intervenants i,
       t_intervenants cf,
       t_intervenants f,
       g_dossier      de
 where i.refdoss = d.Refdoss
   and t.refdoss = d.Refdoss
   and cf.refdoss = d.Refdoss
   and d.refdoss = :refdos
   and ((d.categdoss = 'COMPTE IMP' and t.reftype = 'TC' and
       i.reftype = 'DB' and cf.reftype = 'CL') or
       (d.categdoss = 'COMPTE EXP' and t.reftype = 'CL' and
       i.reftype = 'DB' and cf.reftype = 'CF'))
   and de.refdoss = (select reflot from g_dossier where refdoss = :refdos)
   and f.reftype = 'DB'
   and de.refdoss = f.refdoss;
/********************************OLD SQL*******************************************/
/********************************OLD Metrics***************************************/
/*
MODULE                           SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
msgq_pilote                      8nmg0873t9ys9 2908343622                       read by other sessio 2024/06/19 17:22:22  2024/06/19 20:43:37        2827                  322 +000000000 03:21:14.154 44%
msgq_pilote                                                                     db file sequential r 2024/06/19 17:22:52  2024/06/19 20:49:47         758               339726 +000000000 03:26:54.241 12%
msgq_pilote                                                                     ON CPU               2024/06/19 17:22:22  2024/06/19 20:46:07         674              2229156 +000000000 03:23:44.176 11%
msgq_pilote                                                                     db file parallel rea 2024/06/19 17:23:12  2024/06/19 20:45:27         605                28381 +000000000 03:22:14.165 10%
imxbatch_ValidateCessions                                                       ON CPU               2024/06/19 20:02:26  2024/06/19 20:31:06         390             10702270 +000000000 00:28:40.472 6%


MODULE                           PROGRAM                                            SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- -------------------------------------------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
msgq_pilote                      msg_q03                                                                            147                                 2024/06/19 17:22:22  2024/06/19 20:49:47        1237               339724 +000000000 03:27:24.239 25%
msgq_pilote                      msg_q02                                                                                                                2024/06/19 17:22:22  2024/06/19 20:49:47        1236                66017 +000000000 03:27:24.239 25%
msgq_pilote                      msg_queue                                                                          296                                 2024/06/19 17:22:22  2024/06/19 20:49:37        1230              2229156 +000000000 03:27:14.241 25%
msgq_pilote                      msg_q04                                                                            199                                 2024/06/19 17:22:22  2024/06/19 20:49:27        1229                65996 +000000000 03:27:04.243 25%



MODULE                           SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
msgq_pilote                      8nmg0873t9ys9 2908343622                       read by other sessio 2024/06/19 17:22:22  2024/06/19 20:43:37        2827                  322 +000000000 03:21:14.154 57%
msgq_pilote                                                                     db file sequential r 2024/06/19 17:22:52  2024/06/19 20:49:47         758               339726 +000000000 03:26:54.241 15%
msgq_pilote                                                                     ON CPU               2024/06/19 17:22:22  2024/06/19 20:46:07         674              2229156 +000000000 03:23:44.176 14%
msgq_pilote                                                                     db file parallel rea 2024/06/19 17:23:12  2024/06/19 20:45:27         605                28381 +000000000 03:22:14.165 12%
msgq_pilote                      8nmg0873t9ys9 2908343622                       db file scattered re 2024/06/19 17:23:22  2024/06/19 20:38:37          59                  313 +000000000 03:15:14.103 1%
msgq_pilote                      8nmg0873t9ys9 2908343622                       latch: cache buffers 2024/06/19 17:42:43  2024/06/19 20:23:36           9                  239 +000000000 02:40:53.631 0%



MODULE                           PROGRAM                                            SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- -------------------------------------------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
msgq_pilote                      msg_queue                                          8nmg0873t9ys9 2908343622        296      42893                      2024/06/19 17:22:22  2024/06/19 20:00:06         946                  231 +000000000 02:37:43.512 19%
msgq_pilote                      msg_q03                                            8nmg0873t9ys9 2908343622        147      36195                      2024/06/19 17:22:22  2024/06/19 20:00:06         946                  227 +000000000 02:37:43.512 19%
msgq_pilote                      msg_q04                                            8nmg0873t9ys9 2908343622        199      20167                      2024/06/19 17:22:22  2024/06/19 19:59:56         945                  228 +000000000 02:37:33.505 19%
msgq_pilote                      msg_q02                                            8nmg0873t9ys9 2908343622         99      22755                      2024/06/19 17:22:22  2024/06/19 20:00:06         944                  230 +000000000 02:37:43.512 19%
msgq_pilote                      msg_q02                                                                            819      42882                      2024/06/19 20:00:16  2024/06/19 20:49:47         292                65787 +000000000 00:49:30.731 6%
msgq_pilote                      msg_q03                                                                            147      12893                      2024/06/19 20:00:16  2024/06/19 20:49:47         291               339494 +000000000 00:49:30.731 6%
msgq_pilote                      msg_queue                                                                          296        611                      2024/06/19 20:00:16  2024/06/19 20:49:37         284              2228921 +000000000 00:49:20.733 6%
msgq_pilote                      msg_q04                                                                            199      17886                      2024/06/19 20:00:16  2024/06/19 20:49:27         284                65763 +000000000 00:49:10.735 6%



MODULE                           PROGRAM                                            SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- -------------------------------------------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
msgq_pilote                                                                         8nmg0873t9ys9 2908343622                                            2024/06/19 17:22:22  2024/06/19 20:43:37        4814                  322 +000000000 03:21:14.154 98%
msgq_pilote                                                                         5x92xrc2765ku 2502607534                                            2024/06/19 20:42:07  2024/06/19 20:49:47          71                  512 +000000000 00:07:40.109 1%
msgq_pilote                                                                         dtc7129bh998g 2287755472                       db file sequential r 2024/06/19 20:43:57  2024/06/19 20:49:47          30                  482 +000000000 00:05:50.091 1%
msgq_pilote                                                                         4gwpgprkg2bm5 3672832161                       db file sequential r 2024/06/19 20:42:37  2024/06/19 20:47:47          12                  244 +000000000 00:05:10.065 0%
msgq_pilote                      msg_q04                                                                   0        199      17886 ON CPU               2024/06/19 20:46:07  2024/06/19 20:46:07           1                      +000000000 00:00:00.000 0%
msgq_pilote                      msg_queue                                          71w5a7nsgs38b 1216744797        296        611 db file parallel rea 2024/06/19 20:45:27  2024/06/19 20:45:27           1                    1 +000000000 00:00:00.000 0%
msgq_pilote                      msg_q03                                            9tq7qm6vyvzw6 3645922107        147      12893 db file sequential r 2024/06/19 20:49:17  2024/06/19 20:49:17           1                    1 +000000000 00:00:00.000 0%
msgq_pilote                      msg_q02                                            7x8z5y674h059 1010830785        819      42882 db file sequential r 2024/06/19 20:47:17  2024/06/19 20:47:17           1                    1 +000000000 00:00:00.000 0%
msgq_pilote                      msg_queue                                          cgufjhvr9ybun 4256010850        296        611 ON CPU               2024/06/19 20:44:17  2024/06/19 20:44:17           1                    1 +000000000 00:00:00.000 0%


INSTANCE_NUMBER SQL_ID            ELAPSED MAX_WAIT_ON     PC_OF  WAIT_TIME            GETS      READS       ROWS  ELAP/EXEC       GETS/EXEC READS/EXEC  ROWS/EXEC       EXEC PLAN_HASH_VALUE
--------------- ------------- ----------- --------------- ----- ---------- --------------- ---------- ---------- ---------- --------------- ---------- ---------- ---------- ---------------
              1 8nmg0873t9ys9       47370 IO              95%   43032.0243      1385986380  104430366        255     147.11         4304306  324317.91        .79        322      2908343622
              1 8nmg0873t9ys9           0 CPU             100%     .001033               0          0          0          0               0          0          0          0               0
              
              
SQL_ID        SQL_PLAN_HASH_VALUE SQL_PLAN_LINE_ID SQL_PLAN_OPERATION             SQL_PLAN_OPTIONS                   ACTIVE
------------- ------------------- ---------------- ------------------------------ ------------------------------ ----------
8nmg0873t9ys9          2908343622                5 TABLE ACCESS                   BY INDEX ROWID BATCHED               3503
8nmg0873t9ys9          2908343622                8 TABLE ACCESS                   BY INDEX ROWID                        607
8nmg0873t9ys9          2908343622                6 INDEX                          RANGE SCAN                            382
8nmg0873t9ys9          2908343622                7 INDEX                          RANGE SCAN                            298
8nmg0873t9ys9          2908343622                3 NESTED LOOPS                                                          13
8nmg0873t9ys9          2908343622                2 NESTED LOOPS                                                          11


Plan hash value: 2908343622
--------------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                               | Name                   | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  |
--------------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                        |                        |      1 |        |     9 (100)|      1 |00:00:00.01 |      25 |      4 |
|   1 |  SORT AGGREGATE                         |                        |      1 |      1 |            |      0 |00:00:00.01 |       0 |      0 |
|   2 |   NESTED LOOPS                          |                        |      1 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|   3 |    NESTED LOOPS                         |                        |      1 |      1 |     2   (0)|    139K|00:00:22.90 |     493K|    133K|
|   4 |     INLIST ITERATOR                     |                        |      1 |        |            |    129K|00:00:08.45 |     137K|    118K|
|*  5 |      TABLE ACCESS BY INDEX ROWID BATCHED| G_PIECE                |      1 |      1 |     1   (0)|    129K|00:00:08.42 |     137K|    118K|
|*  6 |       INDEX RANGE SCAN                  | G_PIECE$ID_VENTE       |      1 |      1 |     1   (0)|    198K|00:00:01.02 |    1116 |   1114 |
|*  7 |     INDEX RANGE SCAN                    | ELE_ELEMTYPE           |    129K|      1 |     1   (0)|    139K|00:00:14.37 |     355K|  15330 |
|*  8 |    TABLE ACCESS BY INDEX ROWID          | T_ELEMENTS             |    139K|      1 |     1   (0)|      0 |00:00:43.55 |     104K|  51388 |
|   9 |  NESTED LOOPS                           |                        |      1 |      1 |     7   (0)|      1 |00:00:00.01 |      25 |      4 |
|  10 |   MERGE JOIN CARTESIAN                  |                        |      1 |      3 |     6   (0)|      2 |00:00:00.01 |      19 |      4 |
|  11 |    NESTED LOOPS                         |                        |      1 |      1 |     5   (0)|      1 |00:00:00.01 |      16 |      4 |
|  12 |     NESTED LOOPS                        |                        |      1 |      1 |     4   (0)|      1 |00:00:00.01 |      13 |      3 |
|  13 |      NESTED LOOPS                       |                        |      1 |      1 |     3   (0)|      1 |00:00:00.01 |      10 |      2 |
|  14 |       NESTED LOOPS                      |                        |      1 |      1 |     2   (0)|      1 |00:00:00.01 |       7 |      2 |
|* 15 |        TABLE ACCESS BY INDEX ROWID      | G_DOSSIER              |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       4 |      0 |
|* 16 |         INDEX UNIQUE SCAN               | DOS_REFDOSS            |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |      0 |
|* 17 |        INDEX RANGE SCAN                 | DOS_REFDOSS_REFLOT_IDX |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |      2 |
|* 18 |       INDEX UNIQUE SCAN                 | DOS_REFDOSS            |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |      0 |
|* 19 |      INDEX RANGE SCAN                   | INT_REFDOSS            |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |      1 |
|* 20 |     INDEX RANGE SCAN                    | INT_REFDOSS            |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |      1 |
|  21 |    BUFFER SORT                          |                        |      1 |      2 |     5   (0)|      2 |00:00:00.01 |       3 |      0 |
|* 22 |     INDEX RANGE SCAN                    | INT_REFDOSS            |      1 |      2 |     1   (0)|      2 |00:00:00.01 |       3 |      0 |
|* 23 |   INDEX RANGE SCAN                      | INT_REFDOSS            |      2 |      1 |     1   (0)|      1 |00:00:00.01 |       6 |      0 |
--------------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   5 - filter("P"."TYPEDOC"='C')
   6 - access(("P"."GPIROLE"='DC' OR "P"."GPIROLE"='DT'))
       filter(NVL("P"."TYPPIECE",'xxx')='REQUEST_LIMITE')
   7 - access("P"."REFPIECE"="E"."REFELEM" AND "E"."TYPEELEM"='pr')
   8 - filter("E"."REFDOSS"=:REFDOS)
  15 - filter(("D"."CATEGDOSS"='COMPTE EXP' OR "D"."CATEGDOSS"='COMPTE IMP'))
  16 - access("D"."REFDOSS"=:REFDOS)
  17 - access("REFDOSS"=:REFDOS)
  18 - access("DE"."REFDOSS"="REFLOT")
  19 - access("I"."REFDOSS"=:REFDOS AND "I"."REFTYPE"='DB')
  20 - access("DE"."REFDOSS"="F"."REFDOSS" AND "F"."REFTYPE"='DB')
  22 - access("T"."REFDOSS"=:REFDOS)
       filter(("T"."REFTYPE"='CL' OR "T"."REFTYPE"='TC'))
  23 - access("CF"."REFDOSS"=:REFDOS)
       filter(((("D"."CATEGDOSS"='COMPTE IMP' AND "T"."REFTYPE"='TC' AND "CF"."REFTYPE"='CL') OR ("D"."CATEGDOSS"='COMPTE EXP' AND
              "T"."REFTYPE"='CL' AND "CF"."REFTYPE"='CF')) AND INTERNAL_FUNCTION("CF"."REFTYPE")))


*/
/********************************OLD Metrics***************************************/

/********************************New SQL*******************************************/

select decode((select /*+ leading(e) index(e ELE_ELEMDOSS) index(p PIE_REFPIECE)*/
                      count(*)
                 from t_elements e,
                      g_piece p
                where p.typpiece = 'REQUEST_LIMITE'
                  and p.refpiece = e.refelem
                  and p.gpirole in ('DC', 'DT')
                  and e.refdoss = :refdos
                  and e.typeelem = 'pr'
                  and p.typedoc = 'C'
                  and rownum = 1 ),
               0,
              '0',
              '1')
  from g_dossier      d,
       t_intervenants t,
       t_intervenants i,
       t_intervenants cf,
       t_intervenants f,
       g_dossier      de
 where i.refdoss = d.Refdoss
   and t.refdoss = d.Refdoss
   and cf.refdoss = d.Refdoss
   and d.refdoss = :refdos
   and ((d.categdoss = 'COMPTE IMP' and t.reftype = 'TC' and
       i.reftype = 'DB' and cf.reftype = 'CL') or
       (d.categdoss = 'COMPTE EXP' and t.reftype = 'CL' and
       i.reftype = 'DB' and cf.reftype = 'CF'))
   and de.refdoss = ( select reflot 
                        from g_dossier 
                       where refdoss = :refdos )
   and f.reftype = 'DB'
   and de.refdoss = f.refdoss;
/********************************New SQL*******************************************/
/********************************New Metrics***************************************/
/*
Plan hash value: 3570902788
-------------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                              | Name                   | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  |
-------------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                       |                        |      1 |        |    10 (100)|      1 |00:00:00.01 |      26 |      7 |
|   1 |  SORT AGGREGATE                        |                        |      1 |      1 |            |      1 |00:00:00.01 |      15 |      0 |
|   2 |   NESTED LOOPS                         |                        |      1 |      1 |     3   (0)|      0 |00:00:00.01 |      15 |      0 |
|   3 |    NESTED LOOPS                        |                        |      1 |     44 |     3   (0)|      2 |00:00:00.01 |      13 |      0 |
|   4 |     TABLE ACCESS BY INDEX ROWID BATCHED| T_ELEMENTS             |      1 |     44 |     1   (0)|      2 |00:00:00.01 |       5 |      0 |
|*  5 |      INDEX RANGE SCAN                  | ELE_ELEMDOSS           |      1 |     44 |     1   (0)|      2 |00:00:00.01 |       4 |      0 |
|*  6 |     INDEX RANGE SCAN                   | PIE_REFPIECE           |      2 |      1 |     1   (0)|      2 |00:00:00.01 |       8 |      0 |
|*  7 |    TABLE ACCESS BY INDEX ROWID         | G_PIECE                |      2 |      1 |     1   (0)|      0 |00:00:00.01 |       2 |      0 |
|   8 |  NESTED LOOPS                          |                        |      1 |      1 |     7   (0)|      1 |00:00:00.01 |      26 |      7 |
|   9 |   MERGE JOIN CARTESIAN                 |                        |      1 |      3 |     6   (0)|      2 |00:00:00.01 |      19 |      7 |
|  10 |    NESTED LOOPS                        |                        |      1 |      1 |     5   (0)|      1 |00:00:00.01 |      16 |      7 |
|  11 |     NESTED LOOPS                       |                        |      1 |      1 |     4   (0)|      1 |00:00:00.01 |      13 |      5 |
|  12 |      NESTED LOOPS                      |                        |      1 |      1 |     3   (0)|      1 |00:00:00.01 |      10 |      3 |
|  13 |       NESTED LOOPS                     |                        |      1 |      1 |     2   (0)|      1 |00:00:00.01 |       7 |      3 |
|* 14 |        TABLE ACCESS BY INDEX ROWID     | G_DOSSIER              |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       4 |      0 |
|* 15 |         INDEX UNIQUE SCAN              | DOS_REFDOSS            |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |      0 |
|* 16 |        INDEX RANGE SCAN                | DOS_REFDOSS_REFLOT_IDX |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |      3 |
|* 17 |       INDEX UNIQUE SCAN                | DOS_REFDOSS            |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |      0 |
|* 18 |      INDEX RANGE SCAN                  | INT_REFDOSS            |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |      2 |
|* 19 |     INDEX RANGE SCAN                   | INT_REFDOSS            |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |      2 |
|  20 |    BUFFER SORT                         |                        |      1 |      2 |     5   (0)|      2 |00:00:00.01 |       3 |      0 |
|* 21 |     INDEX RANGE SCAN                   | INT_REFDOSS            |      1 |      2 |     1   (0)|      2 |00:00:00.01 |       3 |      0 |
|* 22 |   INDEX RANGE SCAN                     | INT_REFDOSS            |      2 |      1 |     1   (0)|      1 |00:00:00.01 |       7 |      0 |
-------------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   5 - access("E"."REFDOSS"=:REFDOS AND "E"."TYPEELEM"='pr')
   6 - access("P"."REFPIECE"="E"."REFELEM")
   7 - filter(("P"."TYPEDOC"='C' AND INTERNAL_FUNCTION("P"."GPIROLE") AND NVL("P"."TYPPIECE",'xxx')='REQUEST_LIMITE'))
  14 - filter(("D"."CATEGDOSS"='COMPTE EXP' OR "D"."CATEGDOSS"='COMPTE IMP'))
  15 - access("D"."REFDOSS"=:REFDOS)
  16 - access("REFDOSS"=:REFDOS)
  17 - access("DE"."REFDOSS"="REFLOT")
  18 - access("I"."REFDOSS"=:REFDOS AND "I"."REFTYPE"='DB')
  19 - access("DE"."REFDOSS"="F"."REFDOSS" AND "F"."REFTYPE"='DB')
  21 - access("T"."REFDOSS"=:REFDOS)
       filter(("T"."REFTYPE"='CL' OR "T"."REFTYPE"='TC'))
  22 - access("CF"."REFDOSS"=:REFDOS)
       filter(((("D"."CATEGDOSS"='COMPTE IMP' AND "T"."REFTYPE"='TC' AND "CF"."REFTYPE"='CL') OR ("D"."CATEGDOSS"='COMPTE EXP' AND
              "T"."REFTYPE"='CL' AND "CF"."REFTYPE"='CF')) AND INTERNAL_FUNCTION("CF"."REFTYPE")))
*/
/********************************New Metrics***************************************/

/********************************Index statistics**********************************/

/********************************Other SQLs****************************************/          
/*

*/ 
/********************************Other SQLs****************************************/              
