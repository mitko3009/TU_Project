/********************************************************************************
*********       E-mail subject: IMBDEV-11651
*********             Instance: PROD
*********          Description: 
Problem:
Slow SQL was found on IMB PROD on 06/11/2023.

Analysis:
After the investigation we found that the TOP SQL on 06/11/2023 for msgq_ProcessLimit module on PROD was afjfgsp1um2tr.
The problem was that inappropriate index was used and Oracle make inapproproate execution plan.

Suggestion:
Please add hint as it is shown in the New SQL section below.
The query is from module msgq_ProcessLimit, but we could not find the source of the query. We guess that it is a C source.

*********               SQL_ID: afjfgsp1um2tr
*********      Program/Package: msgq_ProcessLimit
*********              Request: Zornitsa Taskova 
*********               Author: Dimitar Dimitrov
********* Received e-mail date: 06/11/2023
*********      Resolution date: 07/11/2023
*********  Trace old file here: \\epox\specifs\performance\tmp\
*********  Trace new file here:
***********************************************************************************/

/********************************OLD SQL*******************************************/
var B2 VARCHAR2(32);
exec :B2 := 'A600F7DG';
var B3 VARCHAR2(32);
exec :B3 := 'INT00000';

select count(*),
       NVL(TO_CHAR(max(imx_session_params.getCurrentMsgseq())),'no msgseq') 
  from msg_queue ms,
       g_piece p,
       m_statement_limit_fi_cons  m 
 where p.typpiece = 'PARAM_LIMITE' 
   and p.gpidepot = 'FIN'  
   and p.gpimarque = :b2 
   and p.refext = 'COM' 
   and p.gpityptrib = :b3 
   and NVL(p.fg01,'N') <> 'O' 
   and m.limit_id = p.refpiece 
   and (    (     ms.buff like 'calfidec%' 
              and ms.refdoss = m.decompte_id ) 
         or (     ms.buff like 'limit_changed%' 
              and ms.refdoss = p.refpiece ) );
/********************************OLD SQL*******************************************/
/********************************OLD Metrics***************************************/
/*
MODULE                           PROGRAM                                            SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL   PERC
-------------------------------- -------------------------------------------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
msgq_ProcessLimit                                                                   afjfgsp1um2tr 3906167898                                            2023/11/06 12:00:14  2023/11/06 14:59:54        2927             16826985 +000000000 02:59:40.007 46%
msgq                                                                                9h9hjc3u8j6wf 2218561286                                            2023/11/06 12:01:57  2023/11/06 14:58:19         313             16820479 +000000000 02:56:21.440 5%
msgq_report                                                                         0bfz0hwhrm035                                                       2023/11/06 12:00:08  2023/11/06 14:59:54         310             16777236 +000000000 02:59:46.624 5%
msgq_treatEventMatchfi                                                              3km23gdxw26qc 1907579263                                            2023/11/06 12:49:51  2023/11/06 14:58:43         296             16777263 +000000000 02:08:51.392 5%
msgq_ProcessLimit                                                                   68hrmh1u5wbv3 4031323031                                            2023/11/06 12:00:28  2023/11/06 14:59:13         284             16826871 +000000000 02:58:45.184 4%



SQL_ID        SQL_PLAN_HASH_VALUE SQL_PLAN_LINE_ID SQL_PLAN_OPERATION             SQL_PLAN_OPTIONS                   ACTIVE
------------- ------------------- ---------------- ------------------------------ ------------------------------ ----------
afjfgsp1um2tr          3906167898               15 TABLE ACCESS                   BY INDEX ROWID BATCHED               1381
afjfgsp1um2tr          3906167898                7 TABLE ACCESS                   BY INDEX ROWID BATCHED               1372
afjfgsp1um2tr          3906167898               16 INDEX                          RANGE SCAN                             88
afjfgsp1um2tr          3906167898                8 INDEX                          RANGE SCAN                             84
afjfgsp1um2tr          3906167898                9 INDEX                          RANGE SCAN                              1
afjfgsp1um2tr          3906167898                1 SORT                           AGGREGATE                               1


INSTANCE_NUMBER SQL_ID            ELAPSED MAX_WAIT_ON     PC_OF  WAIT_TIME            GETS      READS       ROWS  ELAP/EXEC       GETS/EXEC READS/EXEC  ROWS/EXEC       EXEC PLAN_HASH_VALUE
--------------- ------------- ----------- --------------- ----- ---------- --------------- ---------- ---------- ---------- --------------- ---------- ---------- ---------- ---------------
              2 afjfgsp1um2tr       17070 CPU             100%  16462.8666      8503466825       3036      29468        .58          287765         .1          1      29550      3906167898
              1 afjfgsp1um2tr       16060 CPU             100%   15314.888      9229151758        720      27243        .59          338324        .03          1      27279      3906167898



Plan hash value: 3906167898
-------------------------------------------------------------------------------
| Id  | Operation                                 | Name             | E-Rows |
-------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                          |                  |        |
|   1 |  SORT AGGREGATE                           |                  |      1 |
|   2 |   VIEW                                    | VW_ORE_6FD6BCCF  |      2 |
|   3 |    UNION-ALL                              |                  |        |
|   4 |     NESTED LOOPS                          |                  |      1 |
|   5 |      NESTED LOOPS                         |                  |      3 |
|   6 |       NESTED LOOPS                        |                  |      1 |
|*  7 |        TABLE ACCESS BY INDEX ROWID BATCHED| G_PIECE          |      1 |
|*  8 |         INDEX RANGE SCAN                  | PIECE_REFEXT_IDX |      1 |
|*  9 |        INDEX RANGE SCAN                   | M_S_L_F_C_PK     |      2 |
|* 10 |       INDEX RANGE SCAN                    | MSG_DOSS         |      3 |
|* 11 |      TABLE ACCESS BY INDEX ROWID          | MSG_QUEUE        |      1 |
|  12 |     NESTED LOOPS                          |                  |      1 |
|  13 |      NESTED LOOPS                         |                  |      3 |
|  14 |       NESTED LOOPS                        |                  |      1 |
|* 15 |        TABLE ACCESS BY INDEX ROWID BATCHED| G_PIECE          |      1 |
|* 16 |         INDEX RANGE SCAN                  | PIECE_REFEXT_IDX |      1 |
|* 17 |        INDEX RANGE SCAN                   | M_S_L_F_C_PK     |      2 |
|* 18 |       INDEX RANGE SCAN                    | MSG_DOSS         |      3 |
|* 19 |      TABLE ACCESS BY INDEX ROWID          | MSG_QUEUE        |      1 |
-------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   7 - filter(("P"."GPIMARQUE"=:B2 AND "P"."GPIDEPOT"='FIN' AND
              "P"."GPITYPTRIB"=:B3 AND NVL("P"."FG01",'N')<>'O'))
   8 - access("P"."REFEXT"='COM' AND "P"."TYPPIECE"='PARAM_LIMITE')
   9 - access("M"."LIMIT_ID"="P"."REFPIECE")
  10 - access("MS"."REFDOSS"="M"."DECOMPTE_ID")
  11 - filter("MS"."BUFF" LIKE 'calfidec%')
  15 - filter(("P"."GPIMARQUE"=:B2 AND "P"."GPIDEPOT"='FIN' AND
              "P"."GPITYPTRIB"=:B3 AND NVL("P"."FG01",'N')<>'O'))
  16 - access("P"."REFEXT"='COM' AND "P"."TYPPIECE"='PARAM_LIMITE')
  17 - access("M"."LIMIT_ID"="P"."REFPIECE")
  18 - access("MS"."REFDOSS"="P"."REFPIECE")
  19 - filter(("MS"."BUFF" LIKE 'limit_changed%' AND (LNNVL("MS"."BUFF"
              LIKE 'calfidec%') OR LNNVL("MS"."REFDOSS"="M"."DECOMPTE_ID"))))


-- After manual execution of the query

Plan hash value: 1325772062
--------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                               | Name             | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  |
--------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                        |                  |      1 |        |     8 (100)|      1 |00:00:00.88 |     196K|      1 |
|   1 |  SORT AGGREGATE                         |                  |      1 |      1 |            |      1 |00:00:00.88 |     196K|      1 |
|   2 |   NESTED LOOPS                          |                  |      1 |      1 |     8   (0)|      0 |00:00:00.88 |     196K|      1 |
|   3 |    NESTED LOOPS                         |                  |      1 |      1 |     8   (0)|      0 |00:00:00.88 |     196K|      1 |
|   4 |     NESTED LOOPS                        |                  |      1 |      1 |     2   (0)|      2 |00:00:00.88 |     196K|      1 |
|*  5 |      TABLE ACCESS BY INDEX ROWID BATCHED| G_PIECE          |      1 |      1 |     1   (0)|      2 |00:00:00.88 |     196K|      0 |
|*  6 |       INDEX RANGE SCAN                  | PIECE_REFEXT_IDX |      1 |      1 |     1   (0)|    172K|00:00:00.03 |    1014 |      0 |
|*  7 |      INDEX RANGE SCAN                   | M_S_L_F_C_PK     |      2 |      2 |     1   (0)|      2 |00:00:00.01 |       6 |      1 |
|   8 |     BITMAP CONVERSION TO ROWIDS         |                  |      2 |        |            |      0 |00:00:00.01 |       8 |      0 |
|   9 |      BITMAP OR                          |                  |      2 |        |            |      0 |00:00:00.01 |       8 |      0 |
|  10 |       BITMAP CONVERSION FROM ROWIDS     |                  |      2 |        |            |      0 |00:00:00.01 |       4 |      0 |
|* 11 |        INDEX RANGE SCAN                 | MSG_DOSS         |      2 |        |     1   (0)|      0 |00:00:00.01 |       4 |      0 |
|  12 |       BITMAP CONVERSION FROM ROWIDS     |                  |      2 |        |            |      0 |00:00:00.01 |       4 |      0 |
|* 13 |        INDEX RANGE SCAN                 | MSG_DOSS         |      2 |        |     1   (0)|      0 |00:00:00.01 |       4 |      0 |
|* 14 |    TABLE ACCESS BY INDEX ROWID          | MSG_QUEUE        |      0 |      1 |     8   (0)|      0 |00:00:00.01 |       0 |      0 |
--------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   5 - filter(("P"."GPIMARQUE"=:B2 AND "P"."GPIDEPOT"='FIN' AND "P"."GPITYPTRIB"=:B3 AND NVL("P"."FG01",'N')<>'O'))
   6 - access("P"."REFEXT"='COM' AND "P"."TYPPIECE"='PARAM_LIMITE')
   7 - access("M"."LIMIT_ID"="P"."REFPIECE")
  11 - access("MS"."REFDOSS"="M"."DECOMPTE_ID")
  13 - access("MS"."REFDOSS"="P"."REFPIECE")
  14 - filter((("MS"."BUFF" LIKE 'calfidec%' AND "MS"."REFDOSS"="M"."DECOMPTE_ID") OR ("MS"."BUFF" LIKE 'limit_changed%' AND
              "MS"."REFDOSS"="P"."REFPIECE")))

*/
/********************************OLD Metrics***************************************/

/********************************New SQL*******************************************/
select /*+ use_concat leading(p m ms) index(p REFVIGN) use_nl(m ms) */
       count(*),
       NVL(TO_CHAR(max(imx_session_params.getCurrentMsgseq())),'no msgseq') 
  from msg_queue ms,
       g_piece p,
       m_statement_limit_fi_cons  m 
 where p.typpiece = 'PARAM_LIMITE' 
   and p.gpidepot = 'FIN'  
   and p.gpimarque = :b2 
   and p.refext = 'COM' 
   and p.gpityptrib = :b3 
   and NVL(p.fg01,'N') <> 'O' 
   and m.limit_id = p.refpiece 
   and (    (     ms.buff like 'calfidec%' 
              and ms.refdoss = m.decompte_id ) 
         or (     ms.buff like 'limit_changed%' 
              and ms.refdoss = p.refpiece ) );
/********************************New SQL*******************************************/
/********************************New Metrics***************************************/
/*
Plan hash value: 1665596792
--------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                | Name         | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers |
--------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                         |              |      1 |        |    10 (100)|      1 |00:00:00.01 |      52 |
|   1 |  SORT AGGREGATE                          |              |      1 |      1 |            |      1 |00:00:00.01 |      52 |
|   2 |   CONCATENATION                          |              |      1 |        |            |      0 |00:00:00.01 |      52 |
|   3 |    NESTED LOOPS                          |              |      1 |      1 |     5   (0)|      0 |00:00:00.01 |      24 |
|   4 |     NESTED LOOPS                         |              |      1 |   3011 |     5   (0)|      0 |00:00:00.01 |      24 |
|   5 |      NESTED LOOPS                        |              |      1 |      1 |     2   (0)|      2 |00:00:00.01 |      20 |
|*  6 |       TABLE ACCESS BY INDEX ROWID BATCHED| G_PIECE      |      1 |      1 |     1   (0)|      2 |00:00:00.01 |      14 |
|*  7 |        INDEX RANGE SCAN                  | REFVIGN      |      1 |      6 |     1   (0)|      9 |00:00:00.01 |       3 |
|*  8 |       INDEX RANGE SCAN                   | M_S_L_F_C_PK |      2 |      2 |     1   (0)|      2 |00:00:00.01 |       6 |
|*  9 |      INDEX RANGE SCAN                    | MSG_DOSS     |      2 |   3011 |     1   (0)|      0 |00:00:00.01 |       4 |
|* 10 |     TABLE ACCESS BY INDEX ROWID          | MSG_QUEUE    |      0 |     11 |     3   (0)|      0 |00:00:00.01 |       0 |
|  11 |    NESTED LOOPS                          |              |      1 |      1 |     5   (0)|      0 |00:00:00.01 |      28 |
|  12 |     NESTED LOOPS                         |              |      1 |   3011 |     5   (0)|      0 |00:00:00.01 |      28 |
|  13 |      NESTED LOOPS                        |              |      1 |      1 |     2   (0)|      2 |00:00:00.01 |      20 |
|* 14 |       TABLE ACCESS BY INDEX ROWID BATCHED| G_PIECE      |      1 |      1 |     1   (0)|      2 |00:00:00.01 |      14 |
|* 15 |        INDEX RANGE SCAN                  | REFVIGN      |      1 |      6 |     1   (0)|      9 |00:00:00.01 |       3 |
|* 16 |       INDEX RANGE SCAN                   | M_S_L_F_C_PK |      2 |      2 |     1   (0)|      2 |00:00:00.01 |       6 |
|* 17 |      INDEX RANGE SCAN                    | MSG_DOSS     |      2 |   3011 |     1   (0)|      0 |00:00:00.01 |       8 |
|* 18 |     TABLE ACCESS BY INDEX ROWID          | MSG_QUEUE    |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
--------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   6 - filter(("P"."REFEXT"='COM' AND "P"."GPIDEPOT"='FIN' AND "P"."TYPPIECE"='PARAM_LIMITE' AND "P"."GPITYPTRIB"=:B3
              AND NVL("P"."FG01",'N')<>'O'))
   7 - access("P"."GPIMARQUE"=:B2)
   8 - access("M"."LIMIT_ID"="P"."REFPIECE")
   9 - access("MS"."REFDOSS"="P"."REFPIECE")
  10 - filter("MS"."BUFF" LIKE 'limit_changed%')
  14 - filter(("P"."REFEXT"='COM' AND "P"."GPIDEPOT"='FIN' AND "P"."TYPPIECE"='PARAM_LIMITE' AND "P"."GPITYPTRIB"=:B3
              AND NVL("P"."FG01",'N')<>'O'))
  15 - access("P"."GPIMARQUE"=:B2)
  16 - access("M"."LIMIT_ID"="P"."REFPIECE")
  17 - access("MS"."REFDOSS"="M"."DECOMPTE_ID")
  18 - filter(("MS"."BUFF" LIKE 'calfidec%' AND (LNNVL("MS"."BUFF" LIKE 'limit_changed%') OR
              LNNVL("MS"."REFDOSS"="P"."REFPIECE"))))

*/
/********************************New Metrics***************************************/

/********************************Index statistics**********************************/

/********************************Other SQLs****************************************/          
/*

*/ 
/********************************Other SQLs****************************************/              
