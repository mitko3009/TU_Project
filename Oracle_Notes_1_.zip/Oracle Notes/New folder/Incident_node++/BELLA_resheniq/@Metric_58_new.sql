===============================================================================================================================
1. Check dbspicao (with ROOT)
dbspicao -m58 -r1 -i INSTANCE

2. Login to the database and check the database_role and status
set lines 400
select status from v$instance;

select database_role, db_unique_name instance, open_mode, protection_mode, protection_level, switchover_status from v$database;

*** if the database role is a PHYSICAL STANDBY database procced with step 7 
*** if it’s a PRIMARY procced directly to step 3.


3. Check the Arch utilization

set linesize 300
select * from v$flash_recovery_area_usage;


#### Example output:
FILE_TYPE	PERCENT_SPACE_USED	PERCENT_SPACE_RECLAIMABLE	NUMBER_OF_FILES
--------------------	------------------	-------------------------	---------------
CONTROL FILE	0	0	0
REDO LOG	0	0	0
ARCHIVED LOG	29.6	0	86
BACKUP PIECE	0	0	0
IMAGE COPY	0	0	0
FLASHBACK LOG	45.8	0	439
FOREIGN ARCHIVED LOG	0	0	0

* If you see FLASHBACK LOG percent space usage is high procced with step 3.1 or if not proceed with step 4
* If the above command return “no rows selected” check the utilization with below statement:
show parameter dest

### Example output on what you need to check:
db_recovery_file_dest	string	
db_recovery_file_dest_size           	big integer	0
diagnostic_dest	string	E:\ORACLE
log_archive_dest	string	
log_archive_dest_1	string	LOCATION=j:\iops\arch

WARNING ! - If you see that the database will hang due to almost or full arch dest. Please take appropriate actions and switch or extend the arch destination. If you have issues how to procced with this check with senior or oncall.

## If FLASHBACK is ON/YES procced with 3.1 :
## If FLASHBACK is OFF/NO and you saw that you have FLASHBACK LOGs procced with step 3.2

3.1 FLASHBACK LOG - Check if the FLASHBACK MODE is ON

select log_mode,flashback_on from v$database;


#### Example output: (always first check if the option is ON !)
LOG_MODE     FLASHBACK_ON
------------ ------------------
ARCHIVELOG   YES
## If FLASHBACK is ON please procced with next steps:
alter database flashback off; -- can take a while
alter database flashback on;


**** IF the command alter database flashback on; return an error:
ORA-01153: an incompatible media recovery is active
Procced with below FIX :
-	First at 100% you have DataGuard configuration here and because of that you need to follow next steps to restore the flashback operations on your physical standby database :

[oracle@rbcdevesh** ~]$ dgmgrl /
DGMGRL for Linux: Version 12.1.0.2.0 - 64bit Production

Copyright (c) 2000, 2013, Oracle. All rights reserved.

Welcome to DGMGRL, type "help" for information.
Connected as SYSDG.
DGMGRL> show configuration

Configuration - DGConfig

  Protection Mode: MaxPerformance
  Members:
  p394fra - Primary database
    p394rue - (*) Physical standby database

Fast-Start Failover: ENABLED

Configuration Status:
SUCCESS   (status updated 29 seconds ago)	

DGMGRL> edit database 'PHYSICAL_DATABASE NAME' set state='apply-off';
Succeeded.

### Now login at the database and start flashback -> SQL> alter database flashback on;
### After that login again at dataguard broker and start the apply process
DGMGRL> edit database 'PHYSICAL_DATABASE_NAME' set state='apply-on';
Succeeded.


## If after the operation “flashback OFF and ON”  and you still have Flashback logs on the database or they are not decreased significantly, just procced with step 3.2

3.2 Check for GRPs :
set lines 300
col NAME for a30
col time for a40
SELECT NAME, INST_ID, SCN, TIME,GUARANTEE_FLASHBACK_DATABASE,STORAGE_SIZE /1024/1024/1024 GB
FROM GV$RESTORE_POINT; 

#### Example output:
NAME                              INST_ID        SCN TIME                                     GUA         GB
------------------------------ ---------- ---------- ---------------------------------------- --- ----------
RP_3DAYS_20190403_183333                1 1478244364 03-APR-19 06.33.33.000000000 PM          YES    245.625

## If you have GRP, check with PDL/DL appropriate for the given customer if you can drop the GRP or at least how to procced with this case. Drop after approval only!
DROP RESTORE POINT "RP_3DAYS_20190403_183333";

WARNING ! - If you see that the database will hang due to almost or full arch dest. Please take appropriate actions and switch or extend the arch destination. If you have issues how to procced with this check with senior or oncall.


4. After check from step 3 and you are sure that the ARCH is utilized with ARCH logs procced with below steps:
## Check if the backup is currently running:

LONG OPERATIONS query :
set linesize 400
set pages 60
col TARGET for a30
col TARGET_DESC for a16
col UNITS for a6
col TIME_REMAINING for a20
col START_TIME for a20
col LAST_UPDATE_TIME for a20
col SOFAR for c13
col OPNAME for a27
col SID for c6
col TARGET_DESC for a11
SELECT SID, SERIAL#,OPNAME, to_char(START_TIME, 'YYYY/MON/DD HH:MI:SS') "START_TIME", to_char(LAST_UPDATE_TIME, 'YYYY/MON/DD HH:MI:SS') "LAST_UPDATE_TIME", TIME_REMAINING/60 as "remaining mins", TARGET, TARGET_DESC, SOFAR, UNITS, ROUND(SOFAR/TOTALWORK*100,2) "%_COMPLETE" FROM GV$SESSION_LONGOPS WHERE TOTALWORK != 0 AND SOFAR <> TOTALWORK order by START_TIME;


RUNNING AND COMPLETED BACKUPS query :
(if you see that FULL BACKUP is running check with senior agent or oncall if it necessary to trigger ARCH BACKUP(step5)) :
set lines 400 pages 100
col device for a8
col time_taken for a8
col START__TIME for a19
col END_TIME for a19
column TIME_TAKEN_DISPLAY format a40;
col status for a28
select command_id,TO_CHAR(start_time, 'MM/DD/YY HH24:MI:SS') as start__time,
TO_CHAR(end_time, 'MM/DD/YY HH24:MI:SS') as end_time, output_device_type as device,input_type,time_taken_display as time_taken, status 
from V_$RMAN_BACKUP_JOB_DETAILS order by start_time;

## If you see that backup is not running or will be not triggered soon procced with step 5

WARNING ! - If you see that the database will hang due to almost or full arch dest. Please take appropriate actions and switch or extend the arch destination. If you have issues how to procced with this check with senior or oncall.


5. Finding ARCHIVELOG BACKUP:

## There are a few ways to find how to trigger/find arch backup

5.1 Check ESL if the Backup tab is --> Backup Method: DataProtector
	If its a DataProtector take the backup specification and run the backup
5.2 Check the crontab with root and oracle for arch backup --> crontab -l | grep DATABASE_NAME
5.3 Check the database RMAN for all arch backups 
(only valid for DataProtector method when you don’t have information from ESL) 
RMAN> list backup of archivelog all;
	get the specification from the output to start the backup

6. Triggering ARCHIVELOG BACKUP:

6.1 DataProtector:

Linux: /opt/omni/bin/omnib  -oracle8 USGD_IDA_CANON_plnpdodb302-b_ORA_CPQTST_ARC
Windows: "C:\Program Files\OmniBack\bin\omnib.exe" -oracle8 mewa_derusas812_ora_MIDSYS01_arch_del

6.2 EON BACKUPS:

Linux: cd /tsm/<DATABASE_NAME>/<check the directory for arch|redo backup>
Windows: C:\Programs\Tivoli\TSM\<DATABASE_NAME>\rman 

6.3 SIDEL BACKUPS:

C:\Program Files\VERITAS\NetBackup\scripts\Oracle



7. Check Arch utilization:
set linesize 300
select * from v$flash_recovery_area_usage;

*** if the above command return “no rows selected” or zero values check the utilization with below statement:
show parameter dest

### Example output on what you need to check:
db_recovery_file_dest	string	****
db_recovery_file_dest_size           	big integer	0
diagnostic_dest	string	E:\ORACLE
log_archive_dest	string	
log_archive_dest_1	string	LOCATION=j:\iops\arch

7.2. Check last received and applied
select al.thread#,
        al.last_rec "Last Recd",
        la.last_app "Last Applied"
from
  (select thread#, max(sequence#) last_rec
    from v$archived_log
    group by thread#) al,
  (select thread#, max(sequence#) last_app
    from v$archived_log
    where applied='YES' and registrar='RFS'
    group by thread#) la
where al.thread#=la.thread#
and al.thread# != 0
order by al.thread#
/


### Example output:
   THREAD#  Last Recd Last Applied
---------- ---------- ------------
         1      89241        89240
         2      76231        76230
		 
7.3 DELETE ONLY APPLIED ONES minus 10 (Example: 89240-10=89230)
### delete archivelog 
### EXAMPLE BELOW:
rman target /
delete noprompt archivelog until sequence 89230 thread 1;
delete noprompt archivelog until sequence 76220 thread 2;


*** if you have more than one THREAD# delete others as well (like example above)

7.4 Check Arch utilization again (step 2.1)
7.5 Check dbspicao (step 1) and the arch utilization should be back to normal. Close the case.


IF you are not sure for something please check senior or oncall
