How To Find and Download The Latest Patchset and Associated Patch Number For Oracle Database Release [ID 330374.1]
3-2080094401 - za RAC+DG installa
Using Oracle 10g Release 2 Real Application Clusters and Automatic Storage Management with Oracle E-Business Suite Release 12 [ID 388577.1]
How to install/deinstall Oracle Database Server software silently without response file [ID 782918.1]
11 How To De-install Oracle Home Using runinstaller [ID 1070610.1]
How To Clone An Existing RDBMS Installation Using OUI [ID 300062.1]
Cloning Oracle E-Business Suite Release 12 RAC-Enabled Systems with Rapid Clone [ID 559518.1]


set linesize 400
col FILE_NAME for a70
select file_id,FILE_NAME, TABLESPACE_NAME, BYTES/1024/1024, MAXBYTES/1024/1024, AUTOEXTENSIBLE from dba_data_files where TABLESPACE_NAME='&tablespace_name';

set linesize 400
col FILE_NAME for a70
select FILE_NAME, TABLESPACE_NAME, BYTES/1024/1024, MAXBYTES/1024/1024, AUTOEXTENSIBLE from dba_temp_files;

set linesize 400
col FILE_NAME for a70
select FILE_NAME, TABLESPACE_NAME, BYTES/1024/1024, MAXBYTES/1024/1024, AUTOEXTENSIBLE from dba_data_files where FILE_NAME like '%&FILE_NAME_LIKE%';


set linesize 200
col PROGRAM for a40
col MACHINE for a30
col username for a12
select inst_id,SID,SERIAL#,STATUS,USERNAME,MACHINE,PROGRAM,to_char(LOGON_TIME, 'YYYY/MM/DD HH24:MI:SS'),LOCKWAIT from gv$session where STATUS <> 'INACTIVE' order by LOGON_TIME
/

col p1text for a8
col p1 for a10
col p1 for 9999999999
col p2text for a8
col p2 for a12
col p2 for 999999999999
col p3text for a8
col p3 for a6
col p3 for 99999999
col action for a14
col WAIT_CLASS for a10
col WCL# for a3
col WCL# for 999
col bses for a5
col bses for 99999
select a.P1TEXT,a.P1,a.P2TEXT,a.P2,a.P3TEXT,a.P3,b.name action,a.BLOCKING_SESSION as bses,a.LOCKWAIT,a.WAIT_CLASS_ID W_CLASS_ID,a.WAIT_CLASS# "WCL#",
a.WAIT_CLASS,a.WAIT_TIME as "wtime",a.SECONDS_IN_WAIT as "swait" from v$session a, AUDIT_ACTIONS b where  a.command=b.ACTION and SID='&SID';


### RESIZE TO HIGH WATER MARK #####

SET pagesize 300
SET linesize 200
COL "Resize Command" for a110
SELECT 'alter database datafile '''||file_name||''' resize '|| 
     DECODE(trunc(ceil( (nvl(hwm,1)*(size_db_block))/1024/1024 ) /10),0 ,10, ceil( (nvl(hwm,1)* (size_db_block))/1024/1024 )) ||'M;' "Resize Command", 
 AUTOEXTENSIBLE , bytes/1024/1024 "CurrentSize(Mb)" , 
 ( (bytes/1024/1024) - ceil( (nvl(hwm,1)* (size_db_block))/1024/1024 ) ) "FreeSize(Mb)"
FROM dba_data_files a, 
       ( SELECT file_id, max(block_id+blocks-1) AS hwm FROM dba_extents GROUP BY file_id ) b , 
    (SELECT TO_NUMBER(value) AS size_db_block FROM v$parameter WHERE name = 'db_block_size') c
 WHERE a.file_id = b.file_id(+) AND AUTOEXTENSIBLE='YES' 
AND ceil(blocks*(c.size_db_block)/1024/1024)- ceil((nvl(hwm,1)*(c.size_db_block))/1024/1024 ) > 10 ORDER BY "FreeSize(Mb)" ASC;



### V$SESSION SELECT WITH INPUT - SPID  #####

select s.inst_id,s.SID,p.spid,s.SERIAL#,s.STATUS,s.USERNAME,s.MACHINE,s.PROGRAM,
to_char(s.LOGON_TIME, 'YYYY/MM/DD HH24:MI:SS'),s.LOCKWAIT from gv$session s, gv$process p where
s.paddr = p.addr and 
p.spid in ('8914')  order by LOGON_TIME;

----------


### alter tablespace temp2 shrink space keep 500m;


----------

### TOTAL SIZE OF DB FILES #####

select sum(bytes)/1024/1024/1024 from (select bytes from dba_data_files union all select bytes from dba_temp_files);

----------
###### SESSIONS CHECK #####
----------

select distinct machine from v$session;
select SCHEMANAME,MACHINE,PROGRAM, count(*) from v$session where SCHEMANAME!='SYS' group by SCHEMANAME,MACHINE,PROGRAM;

----------
#### INSTANCE STARTUP TIME #####
----------

select to_char(startup_time, 'YYYY/MM/DD HH24:MI:SS') from v$instance;

----------
#### RAC CHECK ####
----------

select INST_ID,SCHEMANAME,MACHINE,PROGRAM, count(*) from gv$session where SCHEMANAME!='SYS' group by INST_ID,SCHEMANAME,MACHINE,PROGRAM;

____

### CHECK SOURCE USER(S) SCHEMA(S) SIZE - SCHEMA SIZE ####

SELECT s.owner,SUM (s.BYTES) / (1024 * 1024) SIZE_IN_MB FROM dba_segments s GROUP BY s.owner;
select owner, tablespace_name, sum(bytes)/1024/1024 from dba_segments group by owner, tablespace_name;

create or replace directory DDPP1 as '/var/opt/oracle/oradata1/ESLD/temp_exp';
grant read, write on directory DATA_PUMP_DIR to SYSTEM;



----------

SQL_VGRANCHAROV 
pass: ��344fl#g


----------
----------


### GET DDL ####

Set pages 999;
set long 90000;
 
select dbms_metadata.get_ddl('INDEX','EDW_CUST_SALES_HIER_ESS_PK','EDWPROD') from dual;

----------

Customer      Recovery Catalog       User             Pass         TNS_ENTRY         Cell Server                 Type
=====================================================================================================================
Adecco FR          N/A               N/A              N/A            N/A             bkintfr04011/12/14          DP
Aibel              yes               rman             rman           rman            on disk+TSM                 TSM
Bunge              N/A               N/A              N/A            N/A             gen-nt-bkp2                 Other 
EANDIS             N/A               N/A              N/A            N/A             spibkp01/02                 DP 
GEMB               N/A               N/A              N/A            N/A             mysedpmgrbrm01              DP
CAP GEMINI         yes               rman             rman04bkp      RCVCAT          emix-dp01                   DP
Infra EMEA         N/A               N/A              N/A            N/A             greidacs01                  DP
Infra WW           N/A               N/A              N/A            N/A             tsaupdp1                    DP
Sara Lee NA        yes               rman             rm4ns1t5       CATDBP          nbmstr1b                    Netbackup 
Sara Lee EMEA      yes               N/A              N/A            N/A             deshkofps005                DP
LP Payback         yes               <DBNAME>_RMAN    tara1          RMAN9/1         lpucell1/2	                 DP 
LP eLOK            yes               <DBNAME>_RMAN    tara1          RMAN102         bcucell1/2                  DP        
HUS                N/A               N/A              N/A            N/A             ppu-dpcm01                  DP   
Nokia              N/A               N/A              N/A            N/A             viehpbck                    DP 
Panasonic          N/A               N/A              N/A            N/A             jendpcell                   DP  
Tradeka            N/A               N/A              N/A            N/A             ppu-dpcm01                  DP 
Fortum             N/A               N/A              N/A            N/A                                         Legato

----------
----------
----------


----------
USER CREATE LIKE
----------
###SalOppenheim - create DB user - When he is able to login to the Oppenheim network and to get access with sudo to oracle machines:
create user ... profile EDS_ADMINS identified by "..." password expire;
GRANT "CONNECT" to ...;
GRANT "DBA" TO ...;
###SalOppenheim - create DB user

### Create new user DEVADAS mimic existing user KUMARG
### 'KUMARG'	- source user
### "DEVADAS"	- target user
set linesize 200;
select 'create user "BRIAN.KEATING" identified by changeme default tablespace '|| default_tablespace ||' temporary tablespace '|| temporary_tablespace ||' profile '|| profile ||' ;' from dba_users where upper(username)='KARTHIKEYAN.MUNNUDAYAR';

select 'grant '||granted_role||' to "BRIAN.KEATING";' from dba_role_privs where upper(grantee)='KARTHIKEYAN.MUNNUDAYAR';
select 'grant '||privilege||' to "BRIAN.KEATING";' from dba_sys_privs where upper(grantee)='KARTHIKEYAN.MUNNUDAYAR';
select 'grant '||PRIVILEGE||' on '|| TABLE_NAME||' to "BRIAN.KEATING";' from dba_tab_privs where upper(grantee)='KARTHIKEYAN.MUNNUDAYAR';

--user creation
set long 2000
SELECT DBMS_METADATA.GET_DDL('USER','SQL_VOU') || ';' FROM dual;
or for 11g 
select password,spare4 from user$ where name='T5225';

--grant sysprivs
select 'grant '||a.privilege||' to "SQL_VAIOUN"'||decode(ADMIN_OPTION,'YES',' WITH ADMIN OPTION','')||';'
from dba_sys_privs a, dba_users b
where a.grantee=b.username
and b.username ='SQL_VAIOUN';

--grant role_rivs
select 'grant '||c.granted_role||' to "SQL_VAIOUN"'||decode(ADMIN_OPTION,'YES',' WITH ADMIN OPTION','')||';'
from dba_role_privs c, dba_users d
where d.username=c.grantee
and username ='SQL_VAIOUN';

--grant tab_privs
select 'grant '||e.privilege||' on '||e.owner||'.'||e.table_name||' to "SQL_VAIOUN"'||decode(grantable,'YES',' WITH ADMIN OPTION','')||';'
from dba_tab_privs e, dba_users f
where f.username=e.grantee
and username ='SQL_VAIOUN';

--alter quota
select 'alter user "SQL_VAIOUN" '||decode(MAX_BYTES,'-1',' quota unlimited',MAX_BYTES)||' on '||TABLESPACE_NAME||';'
from dba_ts_quotas where username ='SQL_VAIOUN';




set long 1000000
set lines 200
pagesize 20000
select dbms_metadata.get_ddl( 'USER', 'STSC' ) from dual
UNION ALL
select dbms_metadata.get_granted_ddl( 'SYSTEM_GRANT', 'STSC' ) from dual
UNION ALL
select dbms_metadata.get_granted_ddl( 'OBJECT_GRANT', 'STSC' ) from dual
UNION ALL
select dbms_metadata.get_granted_ddl( 'ROLE_GRANT', 'STSC' ) from dual
/

set pages  0
set lines 220
set linesize 9999
set feedback off
set truncate off
set verify off
set head off
set long 9999999
set pause off
set serveroutput off
set heading off
set trims on
set trim on
set tab off
set echo off


----------
### RAC ISSUES ###
----------

[oracle@hhorat02 ora9i]$ srvctl start instance -d IPCT -i IPCT1
PRKP-1040 : Failed to get status of the listeners associated with instance IPCT1 on nodehhorat01
PRKC-1019 : Error creating handle to daemon on the node hhorat01

� ��� �� ����� ���� :) 

===================
[oracle@hhorat01 ora9i]$ gsdctl start
CMCLI ERROR: OpenCommPort: connect failed with error 111.
CMCLI ERROR: OpenCommPort: connect failed with error 111.
CMCLI ERROR: OpenCommPort: connect failed with error 111.
PRKC-1021 : Problem in der Clusterware
Failed to get list of active nodes from clusterware
[oracle@hhorat01 ora9i]$
===================

���� �� ���� ���� :)

�� ���� �� ������� ���� ����� � ����� ������ 

  hangcheck-timer

�� unixa �� ������ modprobe...

�� �� ����� �� root user -> $ORACLE_HOME/oracm/bin/ocmstart.sh &
���� � -> 
[oracle@hhorat01 ora9i]$ lsnrctl start
Successfully started GSD on local node
[oracle@hhorat01 ora9i]$


� ���� ���� ���� �� ���� �� ����...

[oracle@hhorat02 ora9i]$ srvctl start instance -d IPCT -i IPCT1
[oracle@hhorat02 ora9i]$ srvctl start instance -d PDG -i PDG1
[oracle@hhorat02 ora9i]$


-------------
###TEMP check


=-=-

###There are 90Gb allocated into 3 temp files. Our investigation showed no need of more (sort segments) at the moment.
###The following query displays information about each statement that is using space in a sort segment.


col TABLESPACE for a20
col SID_SERIAL for a20
col SQL_TEXT for a50
SELECT   S.sid || ',' || S.serial# sid_serial, S.username,
         T.blocks * TBS.block_size / 1024 / 1024 mb_used, T.tablespace,
         T.sqladdr address, Q.hash_value, Q.sql_text
FROM     v$sort_usage T, v$session S, v$sqlarea Q, dba_tablespaces TBS
WHERE    T.session_addr = S.saddr
AND      T.sqladdr = Q.address (+)
AND      T.tablespace = TBS.tablespace_name
ORDER BY S.sid;


###The following query displays information about each database session that is using space in a sort segment.

col USERNAME for a15
col MODULE for a30
col OSUSER for a20
SELECT   S.sid || ',' || S.serial# sid_serial, S.username, S.osuser, P.spid, S.module,
         S.program, SUM (T.blocks) * TBS.block_size / 1024 / 1024 mb_used, T.tablespace,
         COUNT(*) sort_ops
FROM     v$sort_usage T, v$session S, dba_tablespaces TBS, v$process P
WHERE    T.session_addr = S.saddr
AND      S.paddr = P.addr
AND      T.tablespace = TBS.tablespace_name
GROUP BY S.sid, S.serial#, S.username, S.osuser, P.spid, S.module,
         S.program, TBS.block_size, T.tablespace
ORDER BY sid_serial;


###The following query displays information about all sort segments in the database.
 
SELECT   A.tablespace_name tablespace, D.mb_total,
         SUM (A.used_blocks * D.block_size) / 1024 / 1024 mb_used,
         D.mb_total - SUM (A.used_blocks * D.block_size) / 1024 / 1024 mb_free
FROM     v$sort_segment A,
         (
         SELECT   B.name, C.block_size, SUM (C.bytes) / 1024 / 1024 mb_total
         FROM     v$tablespace B, v$tempfile C
         WHERE    B.ts#= C.ts#
         GROUP BY B.name, C.block_size
         ) D
WHERE    A.tablespace_name = D.name
GROUP by A.tablespace_name, D.mb_total;

=-=-


select count(SESSION_NUM) Sessions, tablespace Temp_Tablespace from v$sort_usage group by TABLESPACE;


------------
### temp check

First find the block size:


select value "BLOCK_SIZE" from v$parameter where name='db_block_size' ;

Now check the usage of the tablespace:

select s.username "USER",s.sid,s.osuser,
u.tablespace "TS" ,
sum(u.blocks) * &BLOCK_SIZE./1024/1024 MB,
x.sql_text
from v$session s,v$sort_usage u,v$sqltext x
where s.saddr=u.session_addr and s.sql_address=x.address
group by s.sid, s.username, osuser, tablespace, sql_text, address, piece
order by sid, piece asc;

-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
### temp tablespace recreation

CREATE TEMPORARY TABLESPACE TEMP2
TEMPFILE '/var/adm/crash/JET_TEMP_file/temp2_01.dbf' SIZE 2000M
AUTOEXTEND ON NEXT 100M MAXSIZE 6000M;

ALTER DATABASE DEFAULT TEMPORARY TABLESPACE TEMP2;


-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-


set linesize 200
col FILE_NAME for a60
select FILE_NAME, TABLESPACE_NAME, BYTES/1024/1024, MAXBYTES/1024/1204 from dba_data_files where TABLESPACE_NAME='OVSCDEV1';



alter database datafile '/base/GTIDB/index/jobexei_02.dbf' autoextend on maxsize 31000;


-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
DBSPI and DBMON:
-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-

dbspiadm conncheck -nw
ww_dbmon.exe -db oracle -period 15m -test | grep 'tatus =' - test check of specific metric period
dbspicao -d -v -f - connectivity check
dbspicao -m 66 -r 1 -i - metric execution

dbspicfg -e - check configuration

/var/opt/OV/dbspi/local.cfg 
/var/opt/OV/dbspi/defaults

dbspicol ON/OFF INSTANCE - turn monitoring on/off

ww_dbmon.exe -version


-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
Manual apply of arch logs:
-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
alter database recover managed standby database disconnect from session;
alter database recover managed standby database cancel;
SELECT SEQUENCE#,APPLIED FROM V$ARCHIVED_LOG ORDER BY SEQUENCE#;

ALTER DATABASE RECOVER MANAGED STANDBY DATABASE  THROUGH ALL SWITCHOVER DISCONNECT  USING CURRENT LOGFILE;

-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
select * from DBA_FREE_SPACE where rownum<5;
-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-

### Checking if there are any active sessions to TEMP tablespace:

SQL> select *
from v$session
where saddr in (select session_addr
from v$tempseg_usage v
where v.tablespace = 'TEMP') ;
-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-



### SGA size >>

SQL> select sum(value)/1024/1024 from v$sga;

### Current SGA size >>

select current_size from v$buffer_pool;


select pool, sum(bytes)/1024/1024 Mbytes from v$sgastat group by  pool;


-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-


select TABLESPACE_NAME from dba_tablespaces;

select SADDR, SID, USER_NAME from v$open_cursor;


select file_name, tablespace_name, bytes/1024/1024, maxbytes/1024/1024 from dba_data_files where tablespace_name='baba_tablespace';

select file_name, tablespace_name, bytes/1024/1024, maxbytes/1024/1024 from dba_temp_files where tablespace_name='TEMP_TT';


select file_name, tablespace_name, bytes/1024/1024, maxbytes/1024/1024 from dba_data_files where tablespace_name='OIMTS';

alter database datafile '/var/opt/oraeslp/oradata1/ESLP/UNDOTBS1_ESLD_01.dbf' autoextend on maxsize 6496M;
desc dba_data_files;


-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-


-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
DATAFILES
-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
select * from V$RECOVER_FILE; - datafiles in recovery mode

select file#, status, checkpoint_change# from v$datafile; - status of all datafiles


-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
Performing Reporter data logging integration for Oracle
-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
/var/opt/OV/bin/OpC/cmds/dbspi_mw_int
/var/opt/OV/bin/OpC/cmds/dbspi_mw_int -osm
/var/opt/OV/bin/OpC/cmds/dbspi_mw_int -udm







-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-



#### disable the recyclebin feature.

SQL> show parameter recyclebin

NAME                                 TYPE        VALUE
------------------------------------ ----------- ------------------------------
recyclebin                           string      on
SQL> SHOW RECYCLEBIN
SQL> PURGE RECYCLEBIN;

Recyclebin purged.

SQL> ALTER SYSTEM SET recyclebin = OFF scope = both;

System altered.

SQL> SHOW RECYCLEBIN
SQL> PURGE RECYCLEBIN;

Recyclebin purged.

SQL> show parameter recyclebin

NAME                                 TYPE        VALUE
------------------------------------ ----------- ------------------------------
recyclebin                           string      OFF
SQL>

-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-

### Recreating the old structure of the temp tablespace:

select TABLESPACE_NAME, BYTES_USED, BYTES_FREE from V$TEMP_SPACE_HEADER;

SELECT * FROM DATABASE_PROPERTIES where PROPERTY_NAME='DEFAULT_TEMP_TABLESPACE';



SQL> CREATE TEMPORARY TABLESPACE TEMP TEMPFILE '/var/opt/orawh/oratemp/CRDWEPRD/TEMPCRDWEPRD01.dbf' size 5G autoextend ON maxsize 15G;

Tablespace created.

SQL>

SQL> ALTER DATABASE DEFAULT TEMPORARY TABLESPACE temp;

Database altered.

SQL> DROP TABLESPACE temp2 INCLUDING CONTENTS AND DATAFILES;

Tablespace dropped.

-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
Cannot connect
-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
dbspicao -d -v -f

dbspicao -m1 -v -p

SQL> select * from v$resource_limit;

SQL> select count(1) from v$process;

  COUNT(1)
----------
       299

SQL> show parameter process;

NAME                                 TYPE        VALUE
------------------------------------ ----------- ------------------------------
aq_tm_processes                      integer     0
db_writer_processes                  integer     1
gcs_server_processes                 integer     2
job_queue_processes                  integer     4
log_archive_max_processes            integer     2
processes                            integer     300
SQL>



-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
###Check for PID of sessions from RMAN
-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
select s.sid, s.serial#, p.spid from v$session s, v$process p where s.paddr = p.addr and upper(s.program) like '%RMAN%';

select 'ALTER SYSTEM KILL SESSION '||''''||sid||','||serial#||''''||' IMMEDIATE;' from gv$session where lower(PROGRAM) like 'rman%';

for i in `ps -ef | grep rman |grep -v grep| awk '{print $2}'`;do echo $i; done;

select '!kill -9 '||b.spid
FROM   gv$session a, gv$process b
WHERE  a.paddr = b.addr
AND   a.username IS NOT null
and a.inst_id=b.inst_id
and a.program like 'rman%';

select 'alter system kill session '||chr(39)||a.sid||','||a.SERIAL#||chr(39)||' IMMEDIATE;'
FROM gV$SESSION A,gV$SQLAREA B
WHERE A.SQL_ADDRESS=B.ADDRESS(+)
AND A.INST_ID=B.INST_ID
AND A.sql_id='9xgru7xbs0k7fasdasdasdasdasdasdasd'
order by logon_time;

###RMAN script for oracle crontab - detele archivelogs

0 * * * * /home/oracle/tseko/tseko.sh >> /home/oracle/tseko/tseko.log


export ORACLE_SID=WWRIM
export ORACLE_HOME=/opt/app/orawrim/product/10.2.0.4
export PATH=$PATH:$ORACLE_HOME/bin
rman target / <<EOF
delete noprompt archivelog all completed before 'sysdate -0.3';
exit
EOF


delete noprompt archivelog all backed up 1 times to disk;

-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
Killed backup sessions.
-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
SELECT s.sid, serial#, username AS "User", program, module, action, logon_time "Logon", PROCESS, STATUS, l.*
FROM v$session s, v$enqueue_lock l
WHERE l.sid = s.sid and l.type = 'CF' AND l.id1 = 0 and l.id2 = 2;
 
-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
### RMAN catalog register backuppiece
CONFIGURE DEFAULT DEVICE TYPE TO 'SBT_TAPE';
catalog device type 'sbt_tape' backuppiece '3dl4n76v_1_1';
-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-

### restore from different device OB_DEVICE, OB2

Specify these devices in the /etc/opt/omni/server/cell/restoredev (UNIX systems)
or
<Data_Protector_home>\Config\server\Cell\restoredev(Windows systems) file in the following format:
"DEV 1" "DEV 2"
where
DEV 1 is the original device and DEV 2 the new device.

-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
All sessions for a specified user holding open cursors
-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-

select USERNAME, STATUS, OSUSER, PROGRAM from v$session;

select USERNAME, STATUS, SERVER, OSUSER, PROGRAM, count(1) from v$session, v$open_cursor; 
### Inactive open cursors
where v$session.sid = v$open_cursor.sid and USER_NAME='SIGNUP' and STATUS = 'INACTIVE';

### Active open cursors
SELECT v.value as numopencursors ,s.machine ,s.osuser,s.username
FROM V$SESSTAT v, V$SESSION s
WHERE v.statistic# = 3 and v.sid = s.sid and USERNAME='SADMIN';


select sid, count(1) from v$open_cursor group by sid having count(1) > 1000;

       SID   COUNT(1)
---------- ----------
       845       1007
       
select program, username from v$session where sid = 845;

PROGRAM                                          USERNAME
------------------------------------------------ ------------------------------
siebmtshmw.exe                                   LDAPUSER

select program, username from v$session where sid = 1050;

PROGRAM                                          USERNAME
------------------------------------------------ ------------------------------
siebmtshmw.exe                                   LDAPUSER



-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
DBSPI-0087: Current processes percentage (99.33%) too high for EDUBCDW2 (>=95%).
-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
SQL> select INSTANCE_NAME,VERSION,STATUS,LOGINS from v$instance;
SQL> select count(1) from v$process;
SQL> show parameter process;
SQL> select s.sid, s.program, p.spid from v$session s, v$process p
     where p.addr = s.paddr
     and PQ_STATUS!='DISABLED';


-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
UXMON: Filesystem /var/opt/oraeslp/oratemp/ESLP diskspace utilization exceeds
-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
SQL> alter database tempfile '/var/opt/oraeslp/oratemp/ESLP/TEMP_ESLD_01.dbf' resize 25G;


-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
checking whether there is a lock file preventing the db monitor from running
-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
$ ll /var/opt/OV/dbspi/dbmon.lock*
-rw-------   1 root       sys             11 May  8 06:40 /var/opt/OV/dbspi/dbmon.lock.15m
-rw-------   1 root       sys             11 May  8 07:25 /var/opt/OV/dbspi/dbmon.lock.5m


-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
ORA-1652: unable to extend temp segment by 128 in tablespace
-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
===
CHECKS
===
dbspicao -m 16 -r 1 -v -p
dbspicao -m 9 -r1 -i CRDWESTG -v -p
===
extending file system
===
iwwrim:/root/home/root (root) lvextend -L 16384M /dev/vg_RADR/lvol5
Logical volume "/dev/vg_RADR/lvol5" has been successfully extended.
Volume Group configuration for /dev/vg_RADR has been saved in /etc/lvmconf/vg_RADR.conf

iwwrim:/root/home/root (root) fsadm -b 16384M /var/opt/oraradr/oratemp/RADR
fsadm: /etc/default/fs is used for determining the file system type
vxfs fsadm: /dev/vg_RADR/rlvol5 is currently 6291456 sectors - size will be increased

iwwrim:/root/home/root (root) bdf /var/opt/oraradr/oratemp/RADR
Filesystem          kbytes    used   avail %used Mounted on
/dev/vg_RADR/lvol5 16777216 6063588 10044033   38% /var/opt/oraradr/oratemp/RADR

====
extending temp file
====
SQL> alter database tempfile '/var/opt/oraradr/oratemp/RADR/RADR_temp_01.dbf' autoextend on maxsize 7700M;

Database altered.

SQL> select file_name, tablespace_name, maxbytes/1024/1024, bytes/1024/1024 from dba_temp_files;

FILE_NAME
--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
TABLESPACE_NAME                MAXBYTES/1024/1024 BYTES/1024/1024
------------------------------ ------------------ ---------------
/var/opt/oraradr/oratemp/RADR/RADR_temp_01.dbf
TEMP                                         7700            5888


-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
Check DB status and replication if in cluster enviroement.
-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-

SQL> select INSTANCE_NAME, DATABASE_STATUS, ACTIVE_STATE from v$instance;
SQL> select open_mode from v$database;
SQL> select count(1) from v$session;
SQL> select max(sequence#) from v$archived_log;
SQL> select sequence#,APPLIED from v$archived_log where sequence# like '%1746%';
na drugiq node:
idasdp1:/u05/oraarch/OVSDPROD (root) ll (ll na arhive FS-a, za da se proveri posledniq arhlog)


-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
Kato skapq redo log member 
-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-

- Dropvam iztritite memberi
ALTER DATABASE 
    DROP LOGFILE MEMBER '/u01/app/oracle/arch/redolog1/redo01a.log' 
    
- Switch ako e current
alter system switch logfile;

- Dobavqm gi otnovo
ALTER DATABASE 
    ADD LOGFILE MEMBER 
    '/u01/app/oracle/arch/redolog1/redo01a.log' TO GROUP 1

ALTER DATABASE 
    ADD LOGFILE MEMBER 
    '/u01/app/oracle/arch/redolog1/redo02a.log' TO GROUP 2

ALTER DATABASE 
    ADD LOGFILE MEMBER 
    '/u01/app/oracle/arch/redolog1/redo03a.log' TO GROUP 3
    
-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
Cluster Stuff:
-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
cmmakepkg
cmhaltpkg oracleGMRIM; 
cmmodpkg -e -n hprasupdb04 oracleGMRIM
cmrunpkg -n hprasupdb04 oracleGMRIM
cmviewcl


-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
Connection/Process issues:
-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-

SQL> select INSTANCE_NAME,VERSION,STATUS,LOGINS from v$instance;

SQL> select * from v$resource_limit;

SQL> show parameter process;
SQL> select count(1) from v$process;

SQL> show parameter session;
SQL> select count(1) from v$session;
SQL> select machine,count(*) from v$session group by machine;
SQL> select s.sid, s.program, p.spid from v$session s, v$process p
  2  where p.addr = s.paddr
  3  and PQ_STATUS!='DISABLED';
  
  
-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
Extending tablespace:
-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-

SQL> select file_name, tablespace_name, maxbytes/1024/1024, bytes/1024/1024 from dba_temp_files;

FILE_NAME
--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
TABLESPACE_NAME                MAXBYTES/1024/1024 BYTES/1024/1024
------------------------------ ------------------ ---------------
/var/opt/oraradr/oratemp/RADR/RADR_temp_01.dbf
TEMP                                         5120            5888

iwwrim:/root/home/root (root) bdf /var/opt/oraradr/oratemp/RADR
Filesystem          kbytes    used   avail %used Mounted on
/dev/vg_RADR/lvol5 6291456 6061018  216043   97% /var/opt/oraradr/oratemp/RADR


===
extending file system
===
iwwrim:/root/home/root (root) lvextend -L 16384M /dev/vg_RADR/lvol5
Logical volume "/dev/vg_RADR/lvol5" has been successfully extended.
Volume Group configuration for /dev/vg_RADR has been saved in /etc/lvmconf/vg_RADR.conf
iwwrim:/root/home/root (root) fsadm -b 16384M /var/opt/oraradr/oratemp/RADR
fsadm: /etc/default/fs is used for determining the file system type
vxfs fsadm: /dev/vg_RADR/rlvol5 is currently 6291456 sectors - size will be increased
iwwrim:/root/home/root (root) bdf /var/opt/oraradr/oratemp/RADR
Filesystem          kbytes    used   avail %used Mounted on
/dev/vg_RADR/lvol5 16777216 6063588 10044033   38% /var/opt/oraradr/oratemp/RADR

====
extending temp file
====
SQL> alter database tempfile '/var/opt/oraradr/oratemp/RADR/RADR_temp_01.dbf' autoextend on maxsize 7700M;

Database altered.

	SQL> select file_name, tablespace_name, maxbytes/1024/1024, bytes/1024/1024 from dba_temp_files;

FILE_NAME
--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
TABLESPACE_NAME                MAXBYTES/1024/1024 BYTES/1024/1024
------------------------------ ------------------ ---------------
/var/opt/oraradr/oratemp/RADR/RADR_temp_01.dbf
TEMP       


-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-

gwwrim:/opt/app/oraerpm/admin/EMEARPM/bdump (root) ll | grep alert
-rw-r--r--   1 oraerpm    dbaerpm    45301423 Apr 11 02:48 alert_EMEARPM.log

-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
DB Links
-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-

set linesize 120
set pagesize 300
col OWNER for a20
col DB_LINK for a20
col host for a20
col username for a20
select * from dba_db_links;


-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
### checking inventory

/cfs/POID/back/patch/OPatch/opatch lsinventory -InvPtrLoc /var/opt/oracle/oraInst.loc_POID


[BAC@igdeslp2]10.2.0/OPatch $ ./opatch lsinventory
Invoking OPatch 10.2.0.3.0

Oracle interim Patch Installer version 10.2.0.3.0
Copyright (c) 2005, Oracle Corporation.  All rights reserved..


Oracle Home       : /opt/app/orabac/product/10.2.0
Central Inventory : /opt/app/oraonbp/oraInventory
   from           : /var/opt/oracle/oraInst.loc
OPatch version    : 10.2.0.3.0
OUI version       : 10.2.0.3.0
OUI location      : /opt/app/orabac/product/10.2.0/oui
Log file location : /opt/app/orabac/product/10.2.0/cfgtoollogs/opatch/opatch2009-01-30_18-25-25PM.log


opatch prereq CheckConflictAgainstOHWithDetail -phBaseDir ./1231231231

-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-

SQL> select * from v$resource_limit


DBSPU checks:
[hp@vieiora1 ~]$ sudo su - root
root@vieiora1:/root#dbspicao -d -f -v

ORACLE checks:

Oracle Clusterware checks:
##########
/opt/oracle/product/10.2.0/crs/bin/crsctl check crs
/opt/oracle/product/10.2.0/crs/bin/crsctl query css votedisk
check log files in $ORA_CRS_HOME/log/`hostname`/cssd directory and any other logs in $ORA_CRS_HOME/log/
#####


su - oracle
lsnrctl status
srvctl status database -d DBINSTANCEname
srvctl status service -s DBINSTANCEname_TAF -d DBINSTANCEname

oifcfg getif

sqlplus / as sysdba
SQL> select * from v$instance;

export ORACLE_SID=+ASM1
sqlplus / as sysdba
SQL> select * from v$asm_disk;
SQL> select * from v$asm_diskgrop;
SQL> select * from v$asm_operation;

## start up checks
------------
with root:
/opt/oracle/product/10.2.0/crs/bin/evmwatch -A -t '@timestamp@@'
- another console:
su - oracle
srvctl start database -d DBINSTANCEname







SQL> select * from v$version;











SQL>archive log start to '/oracle/SID/sapdataxx/sos_arch/<LOGPREFIX>'; 

Attention: for the 10g version the command is:

SQL>alter system set log_archive_dest='/oracle/SID/sapdataxx/sos_arch/<LOGPREFIX>'
scope=memory;    

-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-

### cursors

### check session
select program, username from v$session where sid =458

### checking oracle parameters
show parameter cursors

### change parameter open_cursors

alter system set open_cursors=900;

### archive log info
archive log list



=========================================


-----Original Message-----
From: GCB-DB-TS 
Sent: Wednesday, April 01, 2009 11:06 PM
To: GNSC-HOSTING@nsn.com
Cc: Saparev, Sevar (DB DL)
Subject: <[HP - EMERGENCY request]> < HP ticket ID 305,411,897 and 305,411,904> < NSN ticket ID - filled on reply by NSN >


Dear all,

We have detected:  
 
	-DBSPI-0001.3: DB-SPI cannot connect to database HIF2, may be down; Oracle error [ORA-12520: TNS:listener could not find available handler for requested type of server]

	-DBSPI-0001.3: DB-SPI cannot connect to database HIF1, may be down; Oracle error [ORA-00020: maximum number of processes %s exceeded]. 


 vieiora2.oam.hosting.emea.com    < ip address  172.22.153.140 >  HP Incident # < 305,411,897   > 
 vieiora1.oam.hosting.emea.com    < ip address  172.22.153.138 >  HP Incident # < 305,411,904   >




Problem details: HIF1 (instance on vieiora2) and HIF2 (instance on vieiora1) are up but do not accepting connections because of there are no free processes to handle new sessions there on any of the nodes.

=============

SQL> select * from gv$resource_limit where RESOURCE_NAME in 
SQL> ('processes','sessions');

   INST_ID RESOURCE_NAME                  CURRENT_UTILIZATION MAX_UTILIZATION INITIAL_ALLOCATION                       LIMIT_VALUE
---------- ------------------------------ ------------------- --------------- ---------------------------------------- ----------------------------------------
         2 processes                                      299             300        300                                      300
         2 sessions                                       307             309        335                                      335
         1 processes                                      299             300        300                                      300
         1 sessions                                       306             310        335                                      335

SQL>


=============


To fix the problem this could be the solution:
 We have 2 options :
1. to increase the number of processes and sessions parameters (needs database restart) 2. you to check the application connections to the database to assure there are no connections which are not supposed to be there.

Can you advice how to proceed?



Please fill your NSN ticket ID in the subject on reply to us.

Best regards,

  Tseko Ivanov Tsekov
  Database Technical Support
  HP
  Global Delivery Center Bulgaria
  Remote Management Center 

  Business Park Sofia
  Sofia 1766
  Bulgaria
  Email: gcbdbts@hp.com

The contents of this message and any attachments to it are confidential and may be legally privileged. If you have received this message in error you should delete it from your system immediately and advise the sender.

To any recipient of this message within HP, unless otherwise stated, you should consider this message and attachments as "HP CONFIDENTIAL". 


=========================================================

From: Saparev, Sevar 
Sent: Monday, November 10, 2008 12:30 PM
To: arnold.gabor@nsn.com; Prettner, Christof
Cc: Nagy, Tamas (ATL (NSN - HSL Vienna)); Zahariev, Zahari; GCB-DB-TS
Subject: Emertgency on HIF1/2 instances (HIF database): Maximum number of processes reached.
Importance: High


Hi Arnold, Christof,

We have noticed the following issue on Vieiora1 :
HIF1 instance is up but does not accepting connections. Incident IDs 304,631,000(vieiora1), 304,631,550 (vieiora2).

After some minutes it went ok and start accepting connections again but HIF2 on Vieiora2 have stopped accepting connection for a while.

We notice multiple failing attempts in the listener.log:
10-NOV-2008 11:01:18 * (CONNECT_DATA=(CID=(PROGRAM=)(HOST=__jdbc__)(USER=))(SERVICE_NAME=HIFsvc1.hosting.emea.com)) * (ADDRESS=(PROTOCOL=tcp)(HOST=172.22.201
.24)(PORT=38354)) * establish * HIFsvc1.hosting.emea.com * 12516

From the same 172.22.201.24 address.

What we may see in the alert log is:


Mon Nov 10 10:00:06 2008
Process m000 died, see its trace file
Mon Nov 10 10:00:06 2008
ksvcreate: Process(m000) creation failed
Mon Nov 10 10:00:58 2008
Process m000 died, see its trace file
Mon Nov 10 10:00:58 2008
ksvcreate: Process(m000) creation failed
Mon Nov 10 10:05:05 2008
Process q001 died, see its trace file
Mon Nov 10 10:05:05 2008
ksvcreate: Process(q001) creation failed
Mon Nov 10 10:20:11 2008
Process q001 died, see its trace file
Mon Nov 10 10:20:11 2008
ksvcreate: Process(q001) creation failed
Mon Nov 10 10:33:51 2008
Thread 1 advanced to log sequence 3215
  Current log# 1 seq# 3215 mem# 0: +DG_DATA/hif/onlinelog/group_1.1503.646042093
  Current log# 1 seq# 3215 mem# 1: +DG_FRA/hif/onlinelog/group_1.368.646042093
Mon Nov 10 10:33:52 2008
Process O000 died, see its trace file
Mon Nov 10 10:33:52 2008
ksvsubmit: Process(O000) creation failed
Mon Nov 10 10:42:02 2008
GES: Potential blocker (pid=26853) on resource TX-003D0001-0000093F;
 enqueue info in file /u01/app/oracle/admin/HIF/bdump/hif1_lmd0_25989.trc and DIAG trace file




What we see in the database limits is :

SQL> select * from gv$resource_limit where RESOURCE_NAME in ('processes','sessions');

   INST_ID RESOURCE_NAME                  CURRENT_UTILIZATION MAX_UTILIZATION INITIAL_ALLOCATION                       LIMIT_VALUE
---------- ------------------------------ ------------------- --------------- ---------------------------------------- ----------------------------------------
         1 processes                                      147             150        150                                      150
         1 sessions                                       154             158        170                                      170
         2 processes                                      148             150        150                                      150
         2 sessions                                       156             161        170                                      170

SQL>


So there are no free processes to handle new sessions there on any of the nodes.

We checked and 172.22.201.24  is not public :
oracle@vieiora1:/u01/app/oracle/admin/HIF/bdump#nslookup
> 172.22.201.24
Server:         172.22.150.140
Address:        172.22.150.140#53

** server can't find 24.201.22.172.in-addr.arpa: NXDOMAIN
>


So we have 2 options :
1. to increase the number of processes and sessions parameters (needs database restart)
2. you to check the application connections to the database to assure there are no connections which are not supposed to be there.

Can you advice how to proceed?


Best regards,
 Sevar Saparev



==================================





export ORACLE_SID=+ASM1
sqlplus / as sysdba
SQL> select * from v$asm_disk;
SQL> select * from v$asm_diskgrop;
SQL> select * from v$asm_operation;




=====================================


ORA-01994: GRANT failed: password file missing or disabled.

Cause of The Problem:
------------------------
The oracle software owner is not the owner of the passwordfile.

Solutions of The Problem:
----------------------------
1)Log on to Unix box as the same user who owns the file $ORACLE_HOME and create the password file as follows.

$orapwd file=$ORACLE_HOME/dbs/orapw$ORACLE_SID password=password entries=4 force=y 


orapwd file=+DATA/T900/PASSWORD/pwdt900 password=SXMFP?93634_jsqgw?37449?j4PTpJ entries=4 force=y  asm=y


2)Now grant sysdba privilege to the users that you need. Check V$PWFILE_USERS about the entry.

SQL>GRANT SYSDBA to SYSTEM;

3)Check the owner of $ORACLE_HOME/dbs/orapw$ORACLE_SID

This would typically,

SQL> !ls -l $ORACLE_HOME/dbs/orapw$ORACLE_SID
-rw-r----- 1 oracle oinstall 1536 Apr 23 16:31 /oracle/app/oracle/product/10.2.0/db_1/dbs/orapwdata1

4)If it is not to dba then change the ownership by

$chown oracle:dba $ORACLE_HOME/dbs/orapw$ORACLE_SID

Also change permission by,

$chmod 4640 $ORACLE_HOME/dbs/orapw$ORACLE_SID


�The passwords are embedded, in encrypted form, in an operating system file in the location $ORACLE_HOME/dbs/orapw on Unix, or %ORACLE_HOME%\pwd.ora database on Windows.

=====================================

e:\oracle\ora920\bin\
DBSPI filter


FILTER 4 "USERNAME not in ('MGMT_VIEW')"
FILTER 4 "USERNAME not in ('DBSNMP','TSMSYS','DIP','ORACLE_OCM')"
           FILTER 5 "OWNER not in ('OUTLN','ITESODBA','ITESOEXP','LMS','DBSNMP','RMAN')"
           FILTER 6 "TABLESPACE_NAME not like '%UNDO%' and TABLESPACE_NAME not like '%TEMP%' and TABLESPACE_NAME not like '%TMP%'"
           FILTER 9 "TABLESPACE_NAME not like '%TMP%' and TABLESPACE_NAME not like '%TEMP%'"
           FILTER 11 "TABLESPACE_NAME not like '%RBS%' and TABLESPACE_NAME not like '%TMP%' and TABLESPACE_NAME not like '%TEMP%' and TABLESPACE_NAME not like '%UNDO%' "
           FILTER 16 "TABLESPACE_NAME not like '%RBS%' and TABLESPACE_NAME not like '%TMP%' and TABLESPACE_NAME not like '%TEMP%' and TABLESPACE_NAME not like '%UNDO%' "
           FILTER 17 "TABLESPACE_NAME not like '%RBS%' and TABLESPACE_NAME not like '%TMP%' and TABLESPACE_NAME not like '%TEMP%' and TABLESPACE_NAME not like '%UNDO%' "

		   

TSMSYS                         SYSTEM                         OPC_TEMP
DIP                            SYSTEM                         OPC_TEMP
ORACLE_OCM                     SYSTEM                         OPC_TEMP


FILTER 6 "TABLESPACE_NAME not like '%UNDO%' "


=====================================
#### objects select invalid

select status,owner,object_type,count(*)  from dba_objects where OWNER='SIEBEL' group by status,owner,object_type order by owner, object_type ;

=====================================
	


�� ����-� �� ����� - �� ��� ���_���� � ��������, ���� �� �� �� �������.
����� - �� �� ������ ����� �������� - � �� ��� ����� �� �� ����� ����-�, ������ ���������� ���� ��� ���� �� ����� ��������:

SQL> alter database mount standby database;

Database altered.

����� �� �� ������ ����� ������� �� ������������� ������ ������. ����� - ������ � ����������, �� �� ���������, ����� �� � � ���� � ����������.
�� �� �� ����� �������� - �� ��������� ��� ������ ���� ����� - ������ �� �������� �������� �������:

SQL> ALTER DATABASE RECOVER MANAGED STANDBY DATABASE DISCONNECT FROM SESSION;

Database altered.

� ���� ���� � ����� ���-� �� ��������-�, �� �� ������ �������� ���������:
Media Recovery Log I:\ORADATA\ADPROD01\ARCH\ADPROD01_1_30540.ARC
Mon Sep 14 09:45:43 2009
Media Recovery Waiting for thread 1 seq# 30541 (in transit)


=====================================



SELECT GRANTEE, OWNER, GRANTOR, PRIVILEGE, GRANTABLE
FROM DBA_TAB_PRIVS 
WHERE TABLE_NAME = 'EMPLOYEES' and OWNER = 'HR';


=====================================


SELECT * FROM DICTIONARY
 WHERE Lower(COMMENTS) LIKE '%privilege%'
   OR  Lower(COMMENTS) LIKE '%grant%':


========================================



  1  select 'V$BUFFER_POOL_STATISTICS' object, PHYSICAL_READS,DB_BLOCK_GETS, CONSISTENT_GETS
  2  from V$BUFFER_POOL_STATISTICS
  3  union all
  4  select 'v$SYSSTAT' object, pr.value ,   bg.value , cg.value
  5  from    v$sysstat pr,   v$sysstat bg,   v$sysstat cg
  6* where    pr.name='physical reads' and   bg.name='db block gets'  and   cg.name ='consistent gets'

========================================


if you have case about truncate table or other issue with locks you can check which user lock the object and after that you can kill this session -> for more info please read the below information

 

## check for locks

 

SELECT oracle_username USERNAME, owner OBJECT_OWNER, 
object_name, object_type, s.osuser, s.sid, SERIAL#,
DECODE(l.block, 
  0, 'Not Blocking',
  1, 'Blocking',
  2, 'Global') STATUS,
  DECODE(v.locked_mode,
    0, 'None',
    1, 'Null',
    2, 'Row-S (SS)',
    3, 'Row-X (SX)',
    4, 'Share', 
    5, 'S/Row-X (SSX)', 
    6, 'Exclusive', TO_CHAR(lmode)
  ) MODE_HELD
FROM v$locked_object v, dba_objects d,
v$lock l, v$session s 
WHERE v.object_id = d.object_id
AND (v.object_id = l.id1)
and v.session_id = s.sid
ORDER BY oracle_username, session_id; 

========================================


Here is how to find whether the DB for which you have a case that it's down was shut down by Autosys or not:
 
On all unix or linux servers you can find logs of Autosys jobs execution in: /appl/autotree/LOGS
For Windows it is in C:\local\autosys\general\tmp or C:\local\autosys\general\log 
drive can be C:\ or D:\ some time
 
in UX: ls -lart to find most recent files
(i.e. for STN lx002157.wwit.adecco.net)
oracle@lx002157:RAC(GFSTE1P0)/appl/autotree/LOGS
-rw-rw-r-- 1 oracle oinstall 5739299 Sep 26 14:53 STNW7ORA1_MAINTENANCE.log
-rw-rw-r-- 1 oracle oinstall 63973 Sep 29 01:56 STND7STP-1_STOP_DB1.log
-rw-rw-r-- 1 oracle oinstall 6175 Sep 29 01:56 STND7STP-1_STOP_DB1.err
-rw-rw-r-- 1 oracle oinstall 56 Sep 29 01:56 STND7STP-1_STOP_DB1.trace
-rw-rw-r-- 1 oracle oinstall 6325 Sep 29 02:00 STND7EXP_localbkp.err
-rw-rw-r-- 1 oracle oinstall 57 Sep 29 02:59 STND7EXP_localbkp.trace
-rw-rw-r-- 1 oracle oinstall 3577098 Sep 29 02:59 STND7EXP_localbkp.log
-rw-rw-r-- 1 oracle oinstall 6422 Sep 29 03:00 STND7STR_DB_START_DB1.err
-rw-rw-r-- 1 oracle oinstall 1725 Sep 29 03:00 STND7BK_CATALOG_P0.err
-rw-rw-r-- 1 oracle oinstall 57 Sep 29 03:00 STND7STR_DB_START_DB1.trace
-rw-rw-r-- 1 oracle oinstall 214285 Sep 29 03:00 STND7STR_DB_START_DB1.log
-rw-rw-r-- 1 oracle oinstall 57 Sep 29 03:00 STND7BK_CATALOG_P0.trace
-rw-rw-r-- 1 oracle oinstall 33672 Sep 29 03:00 STND7BK_CATALOG_P0.log
-rw-r--r-- 1 root root 61 Sep 29 09:47 backup_log.log
oracle@lx002157:RAC(GFSTE1P0)/appl/autotree/LOGS >
 
You can see jobs with *STOP_DB* and jobs with *START_DB*.
    The .log - is log file of the whole execution. 
    The .err contains the errors from the execution
    The .trc contains the pid of the process - it's not interesting for us.
If you find this jobs at approx. date/time you receive the alarm, than - it is scheduled by Autosys
Some times jobs are named as followed: *shutdown_base* or *startup_base*

========================================

### INVALID objects

COLUMN object_name FORMAT A30
SELECT owner,object_type,object_name,status
FROM   dba_objects
WHERE  status = 'INVALID'
ORDER BY owner, object_type, object_name;


select 'ALTER ' || OBJECT_TYPE || ' ' || OWNER || '.' || OBJECT_NAME || ' COMPILE;'
from dba_objects
where status = 'INVALID'
and object_type in ('PACKAGE','FUNCTION','PROCEDURE','VIEW','TRIGGER');

select 'ALTER package ' || OWNER || '.' || OBJECT_NAME || ' COMPILE body;'
from dba_objects
where status = 'INVALID'
and object_type in ('PACKAGE BODY"');

Select 'alter public synonym '||object_name||� compile;�
From dba_objects
Where status <> 'VALID�
And owner = 'PUBLIC�
And object_type = 'SYNONYM�;




%PATH%\RDBMS\ADMIN\utlrt.sql

@?/rdbms/admin/utlrp.sql

-----------------------------------------

#### create role - with grant selects to schema objects

CREATE ROLE R_SELECT_ORDER_TECH;

BEGIN
  FOR x IN (SELECT table_name FROM dba_tables WHERE owner='ORDER_TECH')
  LOOP
    EXECUTE IMMEDIATE 'GRANT SELECT ON ' || x.table_name || ' TO R_SELECT_ORDER_TECH';
  END LOOP;
  FOR x IN (SELECT VIEW_NAME FROM dba_views WHERE owner='ORDER_TECH')
  LOOP
    EXECUTE IMMEDIATE 'GRANT SELECT ON ' || x.view_name || ' TO R_SELECT_ORDER_TECH';
  END LOOP;
END;
/

GRANT R_SELECT_ORDER_TECH TO SQL_CPAUCOD;
GRANT R_SELECT_ORDER_TECH TO SQL_MBOUCHARBA;
GRANT R_SELECT_ORDER_TECH TO SQL_MDJERBI;
GRANT R_SELECT_ORDER_TECH TO SQL_FFAURE;
GRANT R_SELECT_ORDER_TECH TO SQL_CADAM;
GRANT R_SELECT_ORDER_TECH TO SQL_DBLETON;
  predi tova 
  atter session set current_schema = ORDER_TECH;
  select * from ROLE_TAB_PRIVS where ROLE='R_SELECT_ORDER_TECH';
  
 
Adecco FR		OVSC-SC E-IM091718668 Work Environment France	1h		 

-----------------------------------------





8.5.3.5 Determining Which Logs Were Applied to the Standby Database
Query the V$LOG_HISTORY view on the standby database, which records the latest log sequence number that was applied. For example, issue the following query:

SQL> SELECT THREAD#, MAX(SEQUENCE#) AS "LAST_APPLIED_LOG" FROM V$LOG_HISTORY GROUP BY THREAD#;

THREAD# LAST_APPLIED_LOG
------- ----------------
      1              967

In this example, the archived redo log with log sequence number 967 is the most recently applied log.

You can also use the APPLIED column in the V$ARCHIVED_LOG fixed view on the standby database to find out which log is applied on the standby database. The column displays YES for the log that was applied. For example:

SQL> SELECT THREAD#, SEQUENCE#, APPLIED FROM V$ARCHIVED_LOG; 

   THREAD#  SEQUENCE# APP 
---------- ---------- --- 
         1          2 YES 
         1          3 YES 
         1          4 YES 
         1          5 YES 
         1          6 YES 
         1          7 YES 
         1          8 YES 
         1          9 YES 
         1         10 YES 
         1         11 NO 

10 rows selected.


-----------------------------------------



8.5.3.3 Determining the Location and Creator of Archived Redo Logs
You can also query the V$ARCHIVED_LOG view on the standby database to find additional information about archived redo logs. Some information you can get includes the location of the archived redo log, which process created the archived redo log, redo log sequence number of each archived redo log, when the log was archived, and whether or not the archived redo log was applied. For example:

SQL> SELECT NAME, CREATOR, SEQUENCE#, APPLIED, COMPLETION_TIME 
FROM V$ARCHIVED_LOG;

NAME                                            CREATOR SEQUENCE# APP COMPLETIO
----------------------------------------------  ------- --------- --- ---------
H:\ORACLE\ORADATA\PAYROLL\STANDBY\ARC00198.001  FGRD          198 YES 30-MAY-02
H:\ORACLE\ORADATA\PAYROLL\STANDBY\ARC00199.001  FGRD          199 YES 30-MAY-02
H:\ORACLE\ORADATA\PAYROLL\STANDBY\ARC00200.001  FGRD          200 YES 30-MAY-02
H:\ORACLE\ORADATA\PAYROLL\STANDBY\ARC00201.001  LGWR          201 YES 30-MAY-02
H:\ORACLE\ORADATA\PAYROLL\STANDBY\ARC00202.001  FGRD          202 YES 30-MAY-02
H:\ORACLE\ORADATA\PAYROLL\STANDBY\ARC00203.001  LGWR          203 YES 30-MAY-02

6 rows selected.

-----------------------------------------

###V$THREAD THREAD#
select THREAD#,STATUS,ENABLED,GROUPS,INSTANCE,SEQUENCE# from V$THREAD;

-----------------------------------------

#### RESTORE ARCh logs

run {
allocate channel 'dev_0' type 'sbt_tape'
 parms 'ENV=(OB2BARTYPE=Oracle8,OB2APPNAME=ADPROD01,OB2BARLIST=odcha0000001_ADPROD01_ARC)'
;
allocate channel 'dev_1' type 'sbt_tape'
 parms 'ENV=(OB2BARTYPE=Oracle8,OB2APPNAME=ADPROD01,OB2BARLIST=odcha0000001_ADPROD01_ARC)'
;


restore archivelog sequence between 31196 and 31196;
}

-----------------------------------------


Flush Shared Pool
The FLUSH SHARED POOL clause of ALTER SYSTEM lets you clear all data from the shared pool in the SGA (system global area). This is a useful feature to clear existing data and re-load fresh data.


select POOL, round(bytes/1024/1024,0) FREE_MB from v$sgastat where name like '%free memory%';   -------> ���������� ����� ���� 


SQL> alter system flush shared_pool;


-----------------------------------------


####SGA administration
Since 9i,
show parameter sga_max_size


DB cache size,
show parameter db_8k_cache_size
show parameter db_cache_size


Buffer cache
Check the buffer cache hit ratio (1),
SELECT (P1.value + P2.value - P3.value) / (P1.value + P2.value)
FROM v$sysstat P1, v$sysstat P2, v$sysstat P3
WHERE P1.name = 'db block gets'
AND P2.name = 'consistent gets'
AND P3.name = 'physical reads';


Note. best is between 90 and 95%
Note. tested on 9i
Ref. www.dbspecialists.com/files/presentations/buffercache.html



Check the buffer cache hit ratio (2),


select name, value from v$sysstat
where name in ('db block gets', 'consistent gets', 'physical reads');
--and calculate,
--Hit ratio = 1 - (physical reads / (db block gets + consistent gets))
--otherwise get the ratio directly,
select
100*(1 - (v3.value / (v1.value + v2.value))) "Cache Hit Ratio [%]"
from
v$sysstat v1, v$sysstat v2, v$sysstat v3
where
v1.name = 'db block gets' and
v2.name = 'consistent gets' and
v3.name = 'physical reads';



Note. best is between 90 and 95%
Note. tested on 9i
Ref. www.cryer.co.uk/brian/oracle/tuning_bchr.htm


Estimate buffer cache size

select /*+ ordered use_hash(b) */ n.bp_name buffer_pool,
count(*) current_buffers, count(*) +
count(decode(lru_flag, 0, decode(tch, 0, null, 1, null, 1))) -
count(decode(state, 0, 1, decode(lru_flag, 8, decode(tch, 0, 1, 1, 1))))
ideal_buffers
from (select /*+ ordered */ p.bp_name, s.addr
from x$kcbwbpd p, x$kcbwds s
where s.inst_id = userenv('Instance')
and p.inst_id = userenv('Instance')
and s.set_id >= p.bp_lo_sid
and s.set_id <= p.bp_hi_sid
and p.bp_size != 0) n, x$bh b
where b.inst_id = userenv('Instance')
and b.set_ds = n.addr
group by n.bp_name
/

Note. tested on 9i
Ref. www.dbasupport.com/forums/archive/index.php/t-26172.html

Automatic Shared Memory Management (10g)
Check ASMM is enabled,
show parameter sga_max_size
show parameter sga_target
show parameter statistics_l
Note. if 'sga_target' is defined and 'statistics_l' is not 'NONE', it's enabled !
Note. 'sga_target' and 'sga_max_size' may be equal
Note. also,
#select name, value from v$parameter where name='sga_target';
#select name, value from v$parameter where name='sga_max_size';


SGA target advice,
select * from v$sga_target_advice;
Note. since 10g


Show the SGA dynamic free memory,
select current_size from v$sga_dynamic_free_memory;
#select current_size/1024/1024 size_M from v$sga_dynamic_free_memory;
show the shared pool size,
select name, value from v$parameter where name ='shared_pool_size';
show free memory in SGA,
select * from v$sgainfo;
note. the latter view since 10g
note. 'Free SGA Memory Available' may be '0'
show the pool's free memory,
select * from v$sgastat where name = 'free memory';

show the 10 most busy (most MB used) pools,

SELECT * FROM(SELECT NAME, BYTES/(1024*1024) MB
FROM V$SGASTAT
WHERE POOL = 'shared pool'ORDER BY BYTES DESC)
WHERE ROWNUM <= 10;



------------------------------------------------

#### For SGA and max processes issues  Adecco :

Hello team,

As of today we have new procedure for handling Adecco incidents:

For SGA and max processes issues :

In no case we can restart the database without the agreement of the customer, even for non prod databases.

What you have to do :
GCB DB TS team notify directly the customer by sending an email to "IT.Account@adecco.com", copy to the DB DL, Application DL, and downtime contacts. 
The email must describe the issue (SGA/max process), the impact (no more connections possible) and the solution proposed (restart the database / kill inactive session).
Within 15 minutes, if there is no answer from the customer, contact by phone the DB delivery lead and the Application delivery lead.

No support in the night for non prod database; for prod database as usually call the dba on call

For offline backup issues
Elie Teman have to send you the final instructions. For the moment, go on with these instructions:
If an offline backup fails or is running too long and will not completed until 9 AM CET:
1) For non-production DB:
	GCB DB team should abort the backup and make the service available at 08:30 AM CET
2) For production DB:
	GCB DB team should abort the backup and make the service available at 07:30 AM CET. If the backup was started by Autosys (you can see this information in ESL or if there is no schedule for the barlist at the cell server but it's running)
	- If in business hours - notify Batch team that backup is failed or will be aborted (info is in ESL) - for both PROD and NON-PROD databases
	- If not in bussines hours - notify PSO team (Adecco Operators (+33 6 11 86 62 13)) that backup is failed or will be aborted - !!!! only for PROD databases !!!! 

Regards,

Vladislav Grancharov
RSS Database Deep Technical Support
ITO DO Bulgaria
------------------------------------------------

Users to roles and system privileges
This is a script that shows the hierarchical relationship between system privileges, roles and users. It makes use of Oracles connect by SQL idiom. Vladimir Gabzovski notifies me, that the following script doesn't run on 8.1 (ORA-01472). I want to thank him for pointing this out. 
select
  lpad(' ', 2*level) || granted_role "User, his roles and privileges"
from
  (
  /* THE USERS */
    select 
      null     grantee, 
      username granted_role
    from 
      dba_users
    where
      username like upper('%&enter_username%')
  /* THE ROLES TO ROLES RELATIONS */ 
  union
    select 
      grantee,
      granted_role
    from
      dba_role_privs
  /* THE ROLES TO PRIVILEGE RELATIONS */ 
  union
    select
      grantee,
      privilege
    from
      dba_sys_privs
  )
start with grantee is null
connect by grantee = prior granted_role;




------------------------------------------------


### find OS process against sid and serial# in the database

col username for a15
col machine for a20
col program for a30
SELECT a.inst_id, a.username, a.program, a.machine, a.osuser, a.sid, a.SERIAL#, b.spid
FROM   gv$session a, gv$process b
WHERE  a.paddr = b.addr
and a.inst_id=b.inst_id
AND   a.username IS NOT null
and b.spid=&SYSTEM_PROCES;

ili

col username for a15
col machine for a20
col program for a30
SELECT a.inst_id, a.username, a.program, a.machine, a.osuser, a.sid, a.SERIAL#, b.spid
FROM   gv$session a, gv$process b
WHERE  a.paddr = b.addr
AND   a.username IS NOT null
and a.inst_id=b.inst_id
and a.sid='&SID';




------------------------------------------------


###tsekoo RMAN jobs

  select sid, serial#, context, sofar, totalwork,
round(sofar/totalwork*100,2) "%_complete"
from v$session_longops
where opname like 'RMAN%'
and opname not like '%aggregate%'
and totalwork != 0
and sofar <> totalwork
/



  select sid, serial#, context, sofar, totalwork,
round(sofar/totalwork*100,2) "%_complete"
from v$session_longops
where totalwork != 0
and sofar <> totalwork
/

  select sid, serial#, to_char(START_TIME, 'YYYY/MM/DD HH24:MI:SS') START__TIME,to_char(LAST_UPDATE_TIME,'YYYY/MM/DD HH24:MI:SS') LAST__UPDATE_TIME, sofar, totalwork,
round(sofar/totalwork*100,2) "%_complete"
from v$session_longops
where totalwork != 0
and sofar <> totalwork
/

------------------------------------------------


### ASM space usage

set linesize 200
column pct_free format 99.99
select group_number, name, total_mb, free_mb, total_mb -free_mb used_mb,
free_mb/total_mb *100 pct_free
from v$asm_diskgroup
/

column pct_free format 99.99
select group_number, name, total_mb, free_mb, total_mb -free_mb used_mb,
case when total_mb=0 then 0 else  free_mb/total_mb *100 end pct_free
from v$asm_diskgroup
/


set linesize 400 pages 20
col NAME for a15
col PATH for a45
col TOTAL_MB for a30
col TOTAL_MB for 9999999999999999
select b.name, a.group_number, a.disk_number, a.mount_status, a.header_status, a.path, a.OS_MB, a.TOTAL_MB, a.free_mb
from v$asm_disk a, v$asm_diskgroup b
where a.group_number=b.group_number(+)
order by a.disk_number,a.header_status, b.name;


------------------------------------------------

### Flash recovery areas size dest

select * from v$flash_recovery_area_usage;
alter session set nls_date_format='DD-MON-YYYY HH24:MI:SS';
select * from v$flashback_database_log;

------------------------------------------------


### checking segment
SQL> select OWNER, SEGMENT_NAME, PARTITION_NAME, SEGMENT_TYPE, TABLESPACE_NAME, BYTES, EXTENTS, MIN_EXTENTS, MAX_EXTENTS, MAX_SIZE, PCT_INCREASE from dba_segments where SEGMENT_NAME='_SYSSMU26_1244648951$';

------------------------------------------------

### chained rows

spool chain.lst;

set pages 9999;
column c1 heading "Owner"   format a9;
column c2 heading "Table"   format a12;
column c3 heading "PCTFREE" format 99;
column c4 heading "PCTUSED" format 99;
column c5 heading "avg row" format 99,999;
column c6 heading "Rows"    format 999,999,999;
column c7 heading "Chains"  format 999,999,999;
column c8 heading "Pct"     format .99;
set heading off;
select 'Tables with > 10% chained rows and no RAW columns.' from dual;
set heading on;
select
owner              c1,
table_name         c2,
pct_free           c3,
pct_used           c4,
avg_row_len        c5,
num_rows           c6,
chain_cnt          c7,
chain_cnt/num_rows c8
from dba_tables
where
owner not in ('SYS','SYSTEM')
and
(chain_cnt/num_rows > .1 or chain_cnt > 1000)
and
table_name not in
(select table_name from dba_tab_columns
where
data_type in ('RAW','LONG RAW')
)
and
chain_cnt > 0
order by chain_cnt desc
;
set heading off;
select 'Tables with > 10% chained rows that contain RAW columns.' from dual;
set heading on;
select
owner              c1,
table_name         c2,
pct_free           c3,
pct_used           c4,
avg_row_len        c5,
num_rows           c6,
chain_cnt          c7,
chain_cnt/num_rows c8
from dba_tables
where
owner not in ('SYS','SYSTEM')
and chain_cnt/num_rows > .1
and
table_name in
(select table_name from dba_tab_columns
where
data_type in ('RAW','LONG RAW')
)
and
chain_cnt > 0
order by chain_cnt desc
;

  

  

spool off; 




------------------------------------------------


RMAN> crosscheck archivelog all;


------------------------------------------------
### UNDO

TUNED_UNDORETENTION in v$undostat

### expired, unexpired and active Undo extends usage

select STATUS, sum(BYTES)/1024/1024 "size MB" from DBA_UNDO_EXTENTS group by status
UNION ALL
select TABLESPACE_NAME||' size',sum(round(BYTES/1024/1204,2)) from dba_data_files where TABLESPACE_NAME='UNDOTBS1' group by TABLESPACE_NAME
UNION ALL
select TABLESPACE_NAME||' Max size',sum(round(MAXBYTES/1024/1204,2)) from dba_data_files where TABLESPACE_NAME='UNDOTBS1' group by TABLESPACE_NAME;

select count(status) from dba_undo_extents where status = 'UNEXPIRED';

select count(*) from dba_undo_extents;

### UNDO sizing

col "UNDO RETENTION [Sec]" for a20
SELECT d.undo_size/1024/1024 as "ACTUAL UNDO SIZE [MByte]", SUBSTR(e.value,1,25) as "UNDO RETENTION [Sec]",
(TO_NUMBER(e.value) * TO_NUMBER(f.value) * g.undo_block_per_sec) / (1024*1024) as "NEEDED UNDO SIZE [MByte]"
FROM (SELECT SUM(a.bytes) undo_size FROM v$datafile a, v$tablespace b, dba_tablespaces c
WHERE c.contents = 'UNDO' AND c.status = 'ONLINE' AND b.name = c.tablespace_name AND a.ts# = b.ts#
and b.name=(select value from v$parameter where NAME='undo_tablespace')) d,
v$parameter e, v$parameter f,
(SELECT MAX(undoblks/((end_time-begin_time)*3600*24)) undo_block_per_sec FROM v$undostat) g
WHERE e.name = 'undo_retention' AND f.name = 'db_block_size';


### optimal UNDO - depned on the current tablesapce size
SELECT d.undo_size/(1024*1024) "ACTUAL UNDO SIZE [MByte]",SUBSTR(e.value,1,25) "UNDO RETENTION [Sec]",
ROUND((d.undo_size/(to_number(f.value)*g.undo_block_per_sec))) "OPTIMAL UNDO RETENTION [Sec]"
FROM (SELECT SUM(a.bytes) undo_size FROM v$datafile a, v$tablespace b, dba_tablespaces c
WHERE c.contents = 'UNDO' AND c.status = 'ONLINE' AND b.name = c.tablespace_name AND a.ts# = b.ts#
and b.name=(select value from v$parameter where NAME='undo_tablespace')) d,v$parameter e,v$parameter f,
(SELECT MAX(undoblks/((end_time-begin_time)*3600*24)) undo_block_per_sec FROM v$undostat) g WHERE e.name = 'undo_retention'
AND f.name = 'db_block_size';

----------------

### undo guarantee
Select tablespace_name, retention from dba_tablespaces;

### alter tablespace UNDOTBS2 retention guarantee; 


------------------------------------------------

### RBS Rollback segment

##If you're using manual UNDO Mode or use an Oracle version <9i, you can try to set a larger optimal size on the rollback segments.
##You can issue following select to determine the current optimal size and the highwater mark size (maximum size ever reached since database startup).

select rb.segment_name, rb.TABLESPACE_NAME, rs.optsize, rs.hwmsize
from v$rollstat rs, dba_rollback_segs rb
where rs.usn = rb.segment_id;

---
select SEGMENT_NAME,SEGMENT_TYPE,TABLESPACE_NAME,BYTES/1024/1024 "MB",EXTENTS,INITIAL_EXTENT,NEXT_EXTENT,MAX_EXTENTS from dba_segments where SEGMENT_TYPE like '%ROLLBACK%';
---
col FILE_NAME for a65
set linesize 200 pagesize 300
select TABLESPACE_NAME, FILE_NAME, bytes/1024/1024 "Size MB" , MAXBYTES/1024/1024 "Max MB", AUTOEXTENSIBLE, STATUS FROM dba_data_files where TABLESPACE_NAME ='SYSTEM';
---
select sum(BYTES/1024/1024) MBBLOCK from dba_free_space where TABLESPACE_NAME='RBSBATCH1_TR';
---
CREATE PUBLIC ROLLBACK SEGMENT RBSBATCH3_TR TABLESPACE RBSBATCH1_TR STORAGE (INITIAL 62914560 NEXT 2914560 MAXEXTENTS  32765);
---


pr1dss:BIP:SYS:SQL> select SEGMENT_NAME,SEGMENT_TYPE,TABLESPACE_NAME,BYTES/1024/1024 from dba_segments where SEGMENT_NAME like '%RBS%';



alter rollback segment rbs0 storage (optimal 100m);


------------------------------------------------

#### chain chains

spool chain.lst;

set pages 9999;
column c1 heading "Owner"   format a9;
column c2 heading "Table"   format a12;
column c3 heading "PCTFREE" format 99;
column c4 heading "PCTUSED" format 99;
column c5 heading "avg row" format 99,999;
column c6 heading "Rows"    format 999,999,999;
column c7 heading "Chains"  format 999,999,999;
column c8 heading "Pct"     format .99;
set heading off;
select 'Tables with > 10% chained rows and no RAW columns.' from dual;
set heading on;
select
owner              c1,
table_name         c2,
pct_free           c3,
pct_used           c4,
avg_row_len        c5,
num_rows           c6,
chain_cnt          c7,
chain_cnt/num_rows c8
from dba_tables
where
owner not in ('SYS','SYSTEM')
and
(chain_cnt/num_rows > .1 or chain_cnt > 1000)
and
table_name not in
(select table_name from dba_tab_columns
where
data_type in ('RAW','LONG RAW')
)
and
chain_cnt > 0
order by chain_cnt desc
;
set heading off;
select 'Tables with > 10% chained rows that contain RAW columns.' from dual;
set heading on;
select
owner              c1,
table_name         c2,
pct_free           c3,
pct_used           c4,
avg_row_len        c5,
num_rows           c6,
chain_cnt          c7,
chain_cnt/num_rows c8
from dba_tables
where
owner not in ('SYS','SYSTEM')
and chain_cnt/num_rows > .1
and
table_name in
(select table_name from dba_tab_columns
where
data_type in ('RAW','LONG RAW')
)
and
chain_cnt > 0
order by chain_cnt desc
;

  

  

spool off; 



------------------------------------------------



###REM Monitor memory usage 

select sid, name, value
from v$statname n, v$sesstat s
where n.statistic# = s.statistic#
and n.name like '%memory%'
order by sid;

###REM monitor CPU usage 

select sid, name, value
from v$statname n, v$sesstat s
where n.statistic# = s.statistic#
and n.name like '%cpu%'
order by sid; 

###REM  monitor I/O 

select file#, phyrds, phywrts
from v$filestat; 



=================================================================


V$RSRC_SESSION_INFO 
Use this view to monitor the status of one or more sessions. The view shows how the session has been affected by the Resource Manager. It provides information such as:

The consumer group that the session currently belongs to.

The consumer group that the session originally belonged to.

The session attribute that was used to map the session to the consumer group.

Session state (RUNNING, WAIT_FOR_CPU, QUEUED, and so on).

Current and cumulative statistics for metrics, such as CPU consumed, wait times, and queued time. Current statistics reflect statistics for the session since it joined its current consumer group. Cumulative statistics reflect statistics for the session in all consumer groups to which it has belonged since it was created.

SQL> SELECT se.sid sess_id, co.name consumer_group, 
 se.state, se.consumed_cpu_time cpu_time, se.cpu_wait_time, se.queued_time
 FROM v$rsrc_session_info se, v$rsrc_consumer_group co
 WHERE se.current_consumer_group_id = co.id;

SESS_ID CONSUMER_GROUP     STATE     CPU_TIME CPU_WAIT_TIME QUEUED_TIME
------- ------------------ -------- --------- ------------- -----------
    113 OLTP_ORDER_ENTRY   WAITING     137947         28846           0
    135 OTHER_GROUPS       IDLE        785669         11126           0
    124 OTHER_GROUPS       WAITING      50401         14326           0
    114 SYS_GROUP          RUNNING        495             0           0
    102 SYS_GROUP          IDLE         88054            80           0
    147 DSS_QUERIES        WAITING     460910        512154           0
CPU_WAIT_TIME in this view has the same meaning as in the V$RSRC_CONSUMER_GROUP view, but applied to an individual session.

=================================================================

V$RSRC_CONS_GROUP_HISTORY 
This view helps you understand how resources were shared among the consumer groups over time. The sequence# column corresponds to the column of the same name in the V$RSRC_PLAN_HISTORY view. This enables you to determine the plan that was active for each row of consumer group statistics.

SQL> select sequence# seq, name, cpu_wait_time, cpu_waits,
consumed_cpu_time from V$RSRC_CONS_GROUP_HISTORY;
 
 SEQ NAME                      CPU_WAIT_TIME  CPU_WAITS CONSUMED_CPU_TIME
---- ------------------------- ------------- ---------- -----------------
   2 SYS_GROUP                         18133        691          33364431
   2 OTHER_GROUPS                      51252        825         181058333
   2 ORA$AUTOTASK_MEDIUM_GROUP            21          5           4019709
   2 ORA$AUTOTASK_URGENT_GROUP            35          1            198760
   2 ORA$AUTOTASK_STATS_GROUP              0          0                 0
   2 ORA$AUTOTASK_SPACE_GROUP              0          0                 0
   2 ORA$AUTOTASK_SQL_GROUP                0          0                 0
   2 ORA$AUTOTASK_HEALTH_GROUP             0          0                 0
   2 ORA$DIAGNOSTICS                       0          0           1072678
   4 SYS_GROUP                         40344         85          42519265
   4 OTHER_GROUPS                     123295       1040         371481422
   4 ORA$AUTOTASK_MEDIUM_GROUP             1          4           7433002
   4 ORA$AUTOTASK_URGENT_GROUP         22959        158          19964703
   4 ORA$AUTOTASK_STATS_GROUP              0          0                 0
      .
      .
   6 ORA$DIAGNOSTICS                       0          0                 0
AWR snapshots of this view are stored in the DBA_HIST_RSRC_CONSUMER_GROUP view. Use DBA_HIST_RSRC_CONSUMER_GROUP with DBA_HIST_RSRC_PLAN to determine the plan that was active for each historical set of consumer group statistics.



------------------------------------------------

### free space ???? shared pool, sga

select sysdate, 
decode(
sign(ksmchsiz - 812), -1, (ksmchsiz - 16) / 4,
decode(sign(ksmchsiz - 4012),-1, trunc((ksmchsiz + 11924) / 64),
decode(sign(ksmchsiz - 65548), -1, trunc(1/log(ksmchsiz - 11, 2)) + 238,254))) bucket,
sum(ksmchsiz) free_space,
count * free_chunks,
trunc(avg(ksmchsiz)) average_size,
max(ksmchsiz) biggest
from
x$ksmsp
where
inst_id = userenv('Instance') and
ksmchcls = 'free'
group by
decode(sign(ksmchsiz - 812),-1, (ksmchsiz - 16) / 4,
decode(sign(ksmchsiz - 4012),-1, trunc((ksmchsiz + 11924) / 64),
decode(sign(ksmchsiz - 65548),-1, trunc(1/log(ksmchsiz - 11, 2)) + 238,254 ))) ;


SQL> set linesize 1000
SQL> SELECT free_space, avg_free_size, used_space,
avg_used_size, REQUEST_MISSES,request_failures, last_miss_size
FROM v$shared_pool_reserved;


FREE_SPACE AVG_FREE_SIZE USED_SPACE AVG_USED_SIZE REQUEST_MISSES REQUEST_FAILURES LAST_MISS_SIZE
---------- ------------- ---------- ------------- -------------- ---------------- --------------
  89833808    3743075.33     166192    6924.66667              0              354              0

SQL>

------------------------------------------------



HR1 batch is handled with the autosys 3.5 (hx000100)

 

Here is how to get a batch status on autosys 3.5 without using graphical interface :

 

Log on autosys server : hx000100.lce.adecco.net, then


switch to user autosys

run the following  command �autorep �J HR1D0_ALL �L0�

it will display current batch status, 

If the batch is still running it will be marked as �RU� and if it is completed it will be either �SU� for success or �FA� for failed or �TE� for terminated

 

returned line will look like this :

Job Name                        Last Start        Last End     ST  Run  Pri/Xit

________________________ ________________ ________________ __ _______ ___

HR1D0_ALL                    01/18/2010 19:15 01/19/2010 01:57 SU 1070175/1


------------------------------------------------


set echo on pagesize 150
spool shared_pool_check.lis

rem Needed Queries to get the Shared pool status
rem ============================================

rem Is there a reload problem ?
rem ===========================
select namespace,pins,reloads from v$librarycache;
show parameters shared_pool
select bytes/1024/1024 from v$sgastat where pool='shared pool' and name='free memory';

rem Find the large queries in the shared pool library cache
rem (using more than 4mb each)
rem ===========================================================

SELECT sql_text "Stmt", count(*),
sum(sharable_mem) "Mem",
sum(users_opening) "Open",
sum(executions) "Exec"
FROM v$sql
GROUP BY sql_text
HAVING sum(sharable_mem) > 4096000;

rem
rem Objects that we should consider pining into the shared pool
rem ============================================================
column name format a40
column owner format a15

select owner,name,executions,locks,pins,loads,kept
from v$db_object_cache
where loads > 10;

rem
rem
Rem LRU work in the shared pool
rem KSMLRNUM stores the number of objects that were flushed to load
rem the large object. KSMLRISZ stores the size of the object that was
rem loaded (contiguous memory allocated)
rem ==================================================================
column ksmlrcom format a20
column username format a5
select
username,sid,KSMLRCOM,KSMLRSIZ,KSMLRNUM,
KSMLRHON,KSMLROHV,KSMLRSES
from x$ksmlru , v$session
where KSMLRSES=SADDR and
KSMLRNUM >2 ;


rem How much are waiting for Library Cache Latch
rem ============================================
select count(*),event from v$session_wait
where event not like '%SQL%' and event not like '%ipc%' and event not like '%timer%'
GROUP BY EVENT;

select count(*),wait_time from v$session_wait
where event='latch free' and p2=106  group by wait_time;

select sid,wait_time,seconds_in_wait from v$session_wait
where event='latch free' and p2=106 and  WAIT_TIME>1;

rem
rem
rem Find the queries which are identical but aren't shared
rem We should want this query to return 0 rows.
rem ========================================================


SELECT address, hash_value,
version_count ,
users_opening ,
users_executing,
substr(sql_text,1,240) "SQL"
FROM v$sqlarea
WHERE version_count > 10;


rem
rem See the biggest chunk of free memory and how many chuncks we have
rem ========================================================
select sysdate,
decode(
sign(ksmchsiz - 812), -1, (ksmchsiz - 16) / 4,
decode(sign(ksmchsiz - 4012),-1, trunc((ksmchsiz + 11924) / 64),
decode(sign(ksmchsiz - 65548), -1, trunc(1/log(ksmchsiz - 11, 2)) + 238,254))) bucket,
sum(ksmchsiz) free_space,
count(*) free_chunks,
trunc(avg(ksmchsiz)) average_size,
max(ksmchsiz) biggest
from
x$ksmsp
where
inst_id = userenv('Instance') and
ksmchcls = 'free'
group by
decode(sign(ksmchsiz - 812),-1, (ksmchsiz - 16) / 4,
decode(sign(ksmchsiz - 4012),-1, trunc((ksmchsiz + 11924) / 64),
decode(sign(ksmchsiz - 65548),-1, trunc(1/log(ksmchsiz - 11, 2)) + 238,254 ))) ;



rem
rem See the shared pool parameters
rem =================================
column name format a30
select name,value from v$parameter where name like '%shared_pool%' ;

select x.ksppinm, y.ksppstvl from x$ksppi x , x$ksppcv y
where x.indx = y.indx and lower(x.ksppinm) like '%spin%';

SELECT count(*) FROM v$latch_children WHERE NAME = 'library cache';  

rem
rem Check the shared pool reserved size status
rem ===================================

SELECT free_space, avg_free_size, used_space,
avg_used_size, REQUEST_MISSES,request_failures, last_miss_size
FROM v$shared_pool_reserved;


Rem
rem When having multiple subheaps:
rem =================================
select KSMCHIDX,ksmchcom ChunkComment,
decode(round(ksmchsiz/1000),0,'0-1K', 1,'1-2K', 2,'2-3K',
3,'3-4K',4,'4-5K',5,'5-6k',6,'6-7k',7,'7-8k',8,'8-9k',
9,'9-10k',
'> 10K'), count(*),
ksmchcls Status, sum(ksmchsiz) Bytes
from x$ksmsp
where KSMCHCOM = 'free memory'
group by KSMCHIDX,ksmchcom, ksmchcls,
decode(round(ksmchsiz/1000),0,'0-1K', 1,'1-2K', 2,'2-3K',
3,'3-4K',4,'4-5K',5,'5-6k',6,'6-7k',7,'7-8k',8,'8-9k',
9,'9-10k','> 10K');

spool off


--------------------------------------------------


## restore

Tsolev, Andrey Lyubomirov [17:51]:
  [root@pblrdbr2 ~]# omnimm -media_info LY0490L3

Medium Label        Medium ID                           Pool          Library
===============================================================================
[LY0490L3] LY0490L  0ac90222:434c4e69:342e:0001         lpnplib1_ONLINE lpnplib1
  
  This conversation is being saved in your Outlook Inbox folder.
  
Tsolev, Andrey Lyubomirov [18:02]:
  SELECT s.sid,
       s.serial#,
       s.osuser,
       s.program,
       s.status
FROM   v$session s;
  
  This conversation is being saved in your Outlook Inbox folder.
  
Tsolev, Andrey Lyubomirov [18:18]:
  run {
allocate channel 'dev_0' type 'sbt_tape'
 parms 'ENV=(OB2BARTYPE=Oracle8,OB2APPNAME=DP05,OB2BARLIST=SVIORA02-DP05-FULL-DAILY)';
restore database until time "to_date('02/05/10 09:00:00','mm/dd/yy hh24:mi s')";
}
  posle smenqsh restore na recover
  DB-to trqbva da e v mount mode


--------------------------------------------------


allocate channel for delete type disk;
change archivelog until time 'SYSDATE-5' delete;
release channel;

list backup of archivelog from  time 'SYSDATE-20';


--------------------------------------------------

17.3.3 Viewing Automatic SQL Tuning Reports
The automatic SQL tuning report is generated using the DBMS_SQLTUNE.REPORT_AUTO_TUNING_TASK function and contains information about all executions of the automatic SQL tuning task. To run this report, you need the ADVISOR privilege and SELECT privileges on the DBA_ADVISOR views. Unlike the standard SQL tuning report generated using the DBMS_SQLTUNE.REPORT_TUNING_TASK function, which only contains information about a single task execution of the SQL Tuning Advisor, the automatic SQL tuning report contains information about multiple executions of the automatic SQL tuning task.

To view the automatic SQL tuning report, run the REPORT_AUTO_TUNING_TASK function in the DBMS_SQLTUNE package:

variable my_rept CLOB;
BEGIN
  :my_rept :=DBMS_SQLTUNE.REPORT_AUTO_TUNING_TASK(
    begin_exec => NULL,
    end_exec => NULL,
    type => 'TEXT',
    level => 'TYPICAL',
    section => 'ALL',
    object_id => NULL,
    result_limit => NULL);
END;
/

print :my_rept


--------------------------------------------------


####bad corrupt block check and repair

###query the V$IR_FAILURE view to view details about the failure (corrupt block)
select failure_id, time_detected, description, impacts
from V$IR_FAILURE where impacts like '%BC%';

RMAN> advise failure all; 

--

Lookup DBMS_REPAIR. You may not need to perform recovery.

Use:
SELECT segment_name , segment_type , owner , tablespace_name
FROM sys.dba_extents
WHERE file_id = &bad_file_id
AND &bad_block_id BETWEEN block_id and block_id + blocks -1
/

To identify segment with bad block.

To create a repair table Use:
DBMS_REPAIR.ADMIN_TABLES (
TABLE_NAME => 'REPAIR_TABLE',
TABLE_TYPE => dbms_repair.repair_table,
ACTION => dbms_repair.create_action,
TABLESPACE => 'FIX');
END;
/

To fix use:
BEGIN 
num_fix := 0;
DBMS_REPAIR.FIX_CORRUPT_BLOCKS (
SCHEMA_NAME => 'SCOTT',
OBJECT_NAME=> 'EMP',
OBJECT_TYPE => dbms_repair.table_object,
REPAIR_TABLE_NAME => 'REPAIR_TABLE',
FIX_COUNT=> num_fix);
DBMS_OUTPUT.PUT_LINE('num fix: ' || TO_CHAR(num_fix));
END;
/


--------------------------------------------------

### restore prez san sana

/omniback/etc_opt_omni/server/cell

tuk ima restoredev

praish alias name na drive deto vurvi backupa

otivash na cella da creatnesh drive

praish go s alias name

izbirash clienta

izbirash /dev/nst3 - ili kvoto ima...

drive indexa da suvpada s gore

Advances - sizes - block size 256k

Lock name - tik sloji i imeto na originalniq drive deto e minaval backupa


--------------------------------------------------

### rman backup

backup as compressed backupset device type disk format '/appl/oraesb/rman_bkp_E-C10088738_E-C10088771/%U' database plus archivelog;

backup device type disk format '/u04/stage/edib/%U' current controlfile for standby;

####rman - scripts -> http://www.shutdownabort.com/dbaqueries/Backup_RMAN.php

####rman - list backup of database completed after 'sysdate-1';

run {
allocate channel dev0 type disk;
allocate channel dev1 type disk;
backup format '/export/PHUStemp/poimbackup/POIM_OFFLINE_FULL<POIM_%s:%t:%p>.dbf' archivelog all;

}

 

#### restore DB

rman target / catalog bcl_ppmbcsb1_rman/tara1@RMAN102 cmdfile=restore_db.rcv msglog=restore_db.log.`date +%Y%m%d%H%M`

.....

SET PARALLELMEDIARESTORE OFF;
run
{

allocate channel 'dev_0' type 'sbt_tape' parms 'ENV=(OB2BARTYPE=Oracle8,OB2APPNAME=PPMBCSB1,OB2BARLIST=BCL_PPMBCSB1_ONLINE_D,OB2BARHOSTNAME=bclpppm1.backup.lpdbrz.com)';
allocate channel 'dev_1' type 'sbt_tape' parms 'ENV=(OB2BARTYPE=Oracle8,OB2APPNAME=PPMBCSB1,OB2BARLIST=BCL_PPMBCSB1_ONLINE_D,OB2BARHOSTNAME=bclpppm1.backup.lpdbrz.com)';
allocate channel 'dev_2' type 'sbt_tape' parms 'ENV=(OB2BARTYPE=Oracle8,OB2APPNAME=PPMBCSB1,OB2BARLIST=BCL_PPMBCSB1_ONLINE_D,OB2BARHOSTNAME=bclpppm1.backup.lpdbrz.com)';
allocate channel 'dev_3' type 'sbt_tape' parms 'ENV=(OB2BARTYPE=Oracle8,OB2APPNAME=PPMBCSB1,OB2BARLIST=BCL_PPMBCSB1_ONLINE_D,OB2BARHOSTNAME=bclpppm1.backup.lpdbrz.com)';

restore database until time "to_date('03/25/10 16:30:00','mm/dd/yy hh24:mi:ss')";
}

.....

rman target / catalog bcl_ppmbcsb1_rman/tara1@RMAN102 cmdfile=recover.db msglog=recover_db.log.`date +%Y%m%d%H%M`

.....

run
{
allocate channel 'dev_0' type 'sbt_tape' parms 'ENV=(OB2BARTYPE=Oracle8,OB2APPNAME=PPMBCSB1,OB2BARLIST=BCL_PPMBCSB1_ONLINE_D,OB2BARHOSTNAME=bclpppm1.backup.lpdbrz.com)';
allocate channel 'dev_1' type 'sbt_tape' parms 'ENV=(OB2BARTYPE=Oracle8,OB2APPNAME=PPMBCSB1,OB2BARLIST=BCL_PPMBCSB1_ONLINE_D,OB2BARHOSTNAME=bclpppm1.backup.lpdbrz.com)';

recover database until time "to_date('03/25/10 16:30:00','mm/dd/yy hh24:mi:ss')";
}
/oracle/PPMBCSB1/admin/restore:[ORACLE_DB]

--
za restor na archivelogove ru4no v arch papkata
rman target / catalog bcl_ppmbcsb1_rman/tara1@RMAN102 cmdfile=arch_rest.rcv msglog=arch_rest.`date +%Y%m%d%H%M`
.....
run
{
allocate channel 'dev_0' type 'sbt_tape';
set archivelog destination to '/oracle/PPMBCSB1/oraarch';
restore archivelog from logseq=32807 until logseq=32862;
}

--
run {
allocate channel 'dev_0' type 'sbt_tape'
�parms 
'ENV=(OB2BARTYPE=Oracle8,OB2APPNAME=AGOLFRS1,OB2BARLIST=hx004100-vip_AGOLFRS1_ON_daily)';
restore archivelog sequence 758;
}
--

-- listvai incarnationa nakraq


RMAN> list incarnation
2> ;

new incarnation of database registered in recovery catalog
starting full resync of recovery catalog
full resync complete

List of Database Incarnations
DB Key  Inc Key DB Name  DB ID            STATUS  Reset SCN  Reset Time
------- ------- -------- ---------------- --- ---------- ----------
1       2       PPMBCSB1 3026194053       PARENT  1          11-FEB-2008 10:49:41
1       106243  PPMBCSB1 3026194053       PARENT  47358533560 27-MAR-2009 18:51:14
1       239475  PPMBCSB1 3026194053       CURRENT 63963232248 31-MAR-2010 03:24:45

RMAN>



-----

### predi restor za LP

origlogA i B sa dvata ctl faila



ESL message bord

bcucell2
RMAN102
user: orarm102
cd /admin/export
par failove
exp.parfile imeto na bazata
edit i slagash data - momentna
save
exp parfile=....
/manager


i po4vash restora na bozata

nakraq alter database open resetlogs;

--------------------------------------------------

RMAN> resync catalog;

--------------------------------------------------

Example for Oracle 8 use:
RMAN> Change Archivelog All Validate; 

Example for Oracle 8i use:
RMAN> Change Archivelog All Crosscheck; 

Example for Oracle 9i:

RMAN> crosscheck archivelog all;

--------------------------------------------------

### Triger

create or replace trigger login_trigger_1
after logon on database
begin
if (USER in ('MANUMGR')) then
execute immediate 'alter session set timed_statistics=true';
execute immediate 'alter session set sql_trace=true';
execute immediate 'alter session set events ''10046 trace name context forever, level 4''';
end if;
end;
/

--------------------------------------------------


#### xWindows

iscapps1:(/var/adm/crash)(root)#xclock
iscapps1:(/var/adm/crash)(root)#
iscapps1:(/var/adm/crash)(root)#
iscapps1:(/var/adm/crash)(root)#echo $DISPLAY
138.35.44.52:11.0
iscapps1:(/var/adm/crash)(root)#xauth list


cd /var/opt/ServiceManager/client10_temp_for_instnall


su - oracle

$ xauth add iscapps1.gre.hp.com:12  MIT-MAGIC-COOKIE-1  eb19cd1e0a1e655006e50bc8c8f98c45

$ xauth list
iscapps1.gre.hp.com:10  MIT-MAGIC-COOKIE-1  413a0dbb435fbc70a7075d6da25b39a8
iscapps1.gre.hp.com:11  MIT-MAGIC-COOKIE-1  33b0368f7f9868d573f706592f5a2de4
$ export DISPLAY=138.35.44.52:11.0
$ xclock
$
puskai si installera

--------------------------------------------------

### Export struktura i import f sql file

### Check source user(s) schema(s) size - schema size
SELECT s.owner,SUM (s.BYTES) / (1024 * 1024) SIZE_IN_MB FROM dba_segments s GROUP BY s.owner;
select owner, tablespace_name, sum(bytes)/1024/1024 from dba_segments group by owner, tablespace_name;

create or replace directory DDPP1 as '/var/opt/oracle/oradata1/ESLD/temp_exp';
grant read, write on directory DATA_PUMP_DIR to SYSTEM;

### metadata exp/imp
expdp directory=DDPP1 DUMPFILE=testest111.dmp LOGFILE=testest111.log content=METADATA_ONLY SCHEMAS=ACS_INT_XI
impdp directory=DDPP1 DUMPFILE=testest111.dmp sqlfile=testest111.sql SCHEMAS=ACS_INT_XI

imp file=backup_full.dmp full=Y show=Y log=DDL.sql


--------------------------------------------------

### traceoff na dbspi
dbspicol TRACEOFF

--------------------------------------------------

#### mass kill session

select 'ALTER SYSTEM KILL SESSION s||''''||sid||','||serial#||''''||' IMMEDIATE;' from v$session where PROGRAM like 'sql%' and MACHINE not like 'sracp0%';


--------------------------------------------------

### sqlnet.ora - experimental!!!

NAMES.DEFAULT_DOMAIN = your_new-domail_name

NAMES.DIRECTORY_PATH= (TNSNAMES, ONAMES, HOSTNAME)

--------------------------------------------------


###Find all lock waited sessions:

set echo off

rem
rem filename: session_locked.sql
rem SQL*Plus script to display selected sessions and related process infor-
rem mation for all Oracle sessions blocked from processing due to a lock
rem held by another session.
rem
rem 11/27/95 s3527 m d powell new script
rem 19991207 Mark D Powell Chg headings to reflect Oracle terminology
rem

set verify off
column machine format a08 heading "APPL.|MACHINE"
column sid format 99999
column serial# format 99999
column spid format 99999 heading "ORACLE|SERVER|PROCESS"
column process format 99999 heading "USER|APPL.|PROCESS"
column username format a12

rem

select 
	s.username, s.status, s.sid, s.serial#,
	p.spid, s.machine, s.process, s.lockwait
from	v$session s, v$process p
where	s.lockwait is not null
and	s.paddr = p.addr
/


-----

#### session lock

SELECT a.sid,a.serial#, a.username, a.program, c.os_user_name,a.terminal,type,b.object_id,substr(b.object_name,1,40) object_name
from v$session a, dba_objects b, v$locked_object c
where a.sid = c.session_id
and b.object_id = c.object_id;

col VLOCK for a8
col TYPE for a8
col LMODE for a10
SELECT p.username  username,p.pid pid,s.sid sid,s.serial# serial,p.spid spid,s.username ora,DECODE(l2.type,'TX','TRANSACTION ROW-LEVEL',
'RT','REDO-LOG','TS','TEMPORARY SEGMENT ','TD','TABLE LOCK','TM','ROW LOCK',l2.type) vlock,DECODE(l2.type,'TX','DML LOCK','RT','REDO LOG',
'TS','TEMPORARY SEGMENT','TD',DECODE(l2.lmode+l2.request,4,'PARSE '||u.name||'.'||o.name,6,'DDL',l2.lmode+l2.request),'TM','DML '||u.name||
'.'||o.name,l2.type) type,DECODE(l2.lmode+l2.request,2,'RS',3,'RX',4,'S',5,'SRX',6,'X',l2.lmode+l2.request) lmode,DECODE(l2.request,0,NULL                           ,
'WAIT') wait FROM v$process p,v$_lock l1,v$lock l2,v$resource r,sys.obj$ o,sys.user$ u,v$session s WHERE s.paddr=p.addr AND s.saddr=l1.saddr
AND l1.raddr=r.addr AND l2.addr=l1.laddr AND l2.type<>'MR' AND r.id1= o.obj#(+) AND o.owner#=u.user#(+)
--AND  u.name = 'GME'
ORDER BY p.username, p.pid, p.spid, ora, DECODE(l2.type,
'TX','TRANSACTION ROW-LEVEL','RT','REDO-LOG','TS','TEMPORARY SEGMENT ','TD','TABLE LOCK','TM','ROW LOCK',l2.type);

AND (:USER_NAME is null or s.username LIKE upper(:USER_NAME)) 
----------------
#### session locks

select /*+ ORDERED */
blocker.sid blocker_sid,waiting.sid waiting_sid,TRUNC(waiting.ctime/60) min_waiting,waiting.request
from (select * from v$lock where block != 0 and type = 'TX') blocker,v$lock waiting
where waiting.type='TX' and waiting.block = 0 and waiting.id1 = blocker.id1;

### who is locking, blocking who?

set linesize 400
col USERNAME for a10
col LOGON_TIME for a20
col IS_BLOCKING for a15
col PROGRAM for a25
select
l1.INST_ID, l1.sid, a.serial#, a.USERNAME, a.PROGRAM, TO_CHAR(a.logon_time, 'MM/DD/YY HH24:MI:SS') as logon_time, 'IS_BLOCKING' as IS_BLOCKING,
l2.INST_ID, l2.sid, b.serial#, b.USERNAME, b.PROGRAM, TO_CHAR(b.logon_time, 'MM/DD/YY HH24:MI:SS') as logon_time
from gv$lock l1, gv$lock l2, gv$session a, gv$session b
where l1.id1=l2.id1 and l1.id2=l2.id2 and a.SID=l1.sid and b.SID=l2.sid
and l1.inst_id=l2.inst_id and l2.inst_id=a.inst_id and a.inst_id=b.inst_id  and l1.sid! = l2.sid
and l1.block =1 and l2.request > 0 order by a.LOGON_TIME;

##advanced by blocking sid

set linesize 400
col USERNAME for a10
col LOGON_TIME for a20
col IS_BLOCKING for a15
col PROGRAM for a25
select
l1.INST_ID, l1.sid, a.serial#, a.USERNAME, a.PROGRAM, TO_CHAR(a.logon_time, 'MM/DD/YY HH24:MI:SS') as logon_time, 'IS_BLOCKING' as IS_BLOCKING,
l2.INST_ID, l2.sid, b.serial#, b.USERNAME, b.PROGRAM, TO_CHAR(b.logon_time, 'MM/DD/YY HH24:MI:SS') as logon_time
from gv$lock l1, gv$lock l2, gv$session a, gv$session b
where l1.id1=l2.id1 and l1.id2=l2.id2 and a.SID=l1.sid and b.SID=l2.sid
and l1.inst_id=l2.inst_id and l2.inst_id=a.inst_id and a.inst_id=b.inst_id  and l1.sid! = l2.sid
and l1.sid=&blocking_SID
order by a.LOGON_TIME;

##advanced by blocked sid

set linesize 400
col USERNAME for a10
col LOGON_TIME for a20
col IS_BLOCKING for a15
col PROGRAM for a25
select
l1.INST_ID, l1.sid, a.serial#, a.USERNAME, a.PROGRAM, TO_CHAR(a.logon_time, 'MM/DD/YY HH24:MI:SS') as logon_time, 'IS_BLOCKING' as IS_BLOCKING,
l2.INST_ID, l2.sid, b.serial#, b.USERNAME, b.PROGRAM, TO_CHAR(b.logon_time, 'MM/DD/YY HH24:MI:SS') as logon_time
from gv$lock l1, gv$lock l2, gv$session a, gv$session b
where l1.id1=l2.id1 and l1.id2=l2.id2 and a.SID=l1.sid and b.SID=l2.sid
and l1.inst_id=l2.inst_id and l2.inst_id=a.inst_id and a.inst_id=b.inst_id  and l1.sid! = l2.sid
and l2.sid=&blocked_SID
order by a.LOGON_TIME;


### blocking session is executing the following:

set wrap off
set linesize 400
col blocking_session_is_executing for a32
col SQL_TEXT for a150
SELECT A.inst_id, A.sid, 'blocking session is executing-->' as blocking_session_is_executing, B.SQL_TEXT
FROM GV$SESSION A,GV$SQLAREA B
WHERE A.SQL_ADDRESS=B.ADDRESS(+) and B.SQL_TEXT is not null and B.SQL_TEXT not like '%locking_session_is_executin%'
AND A.SID in (select l1.sid from gv$lock l1, gv$lock l2 where l1.block =1 and l2.request > 0 and l1.id1=l2.id1 and l1.id2=l2.id2 and l1.inst_id=l2.inst_id and l1.sid! = l2.sid)
ORDER by a.logon_time, a.sid;

### blocking session (+ db processes sessions) is executing the following:

set wrap off
set linesize 400
col blocking_session_is_executing for a32
col SQL_TEXT for a80
SELECT A.inst_id, A.sid, 'blocking session is executing-->' as blocking_session_is_executing, B.SQL_TEXT
FROM GV$SESSION A,GV$SQLAREA B
WHERE A.SQL_ADDRESS=B.ADDRESS(+) and B.SQL_TEXT is not null and B.SQL_TEXT not like '%locking_session_is_executin%'
AND A.SID in (select l1.sid from gv$lock l1, gv$lock l2 where l1.id1=l2.id1 and l1.id2=l2.id2 and l1.inst_id=l2.inst_id and l1.sid! = l2.sid)
ORDER by a.logon_time, a.sid;

## view_lock_history_DB.sql
set linesize 400
col program for a16
col sql_text for a100
col sample_time for a25
select * from ( SELECT a.sql_id , COUNT(*) OVER (PARTITION BY a.blocking_session,a.user_id ,a.program) cpt,
ROW_NUMBER() OVER (PARTITION BY a.blocking_session,a.user_id ,a.program order by blocking_session,a.user_id ,a.program ) rn,
a.blocking_session,a.user_id ,a.program, s.sql_text,a.sample_time
FROM sys.WRH$_ACTIVE_SESSION_HISTORY a ,sys.wrh$_sqltext s
where a.sql_id=s.sql_id
and blocking_session_serial# <> 0
and a.user_id <> 0
and a.sample_time > sysdate -&enter_days_behind
) where rn = 1 order by sample_time;

## view_lock_history_RAC.sql
set linesize 400
col module for a16
col sql_text for a100
col sample_time for a25
SELECT distinct a.sql_id ,a.inst_id,a.blocking_session BS,a.blocking_session_serial# BS_SERIAL#,a.user_id,a.module,s.sql_text,a.sample_time
FROM  GV$ACTIVE_SESSION_HISTORY a, gv$sql s
where a.sql_id=s.sql_id
and blocking_session is not null
and a.user_id <> 0 --  exclude SYS user
and a.sample_time > sysdate -&enter_days order by sample_time;

## Pokazwa ti lokowete:
select   object_name, object_type, session_id, type, lmode, request, block, ctime
from   v$locked_object, all_objects, v$lock 
where   v$locked_object.object_id = all_objects.object_id AND  v$lock.id1 = all_objects.object_id AND  v$lock.sid = v$locked_object.session_id 
order by   session_id, ctime desc, object_name 
/


### some more info for a session - requested in the promt when script executed:

set linesize 500
col USERNAME for a10
col MACHINE for a10
col logntime for a20
col PROGRAM for a40
col SQL_TEXT for a45
col SECONDS_IN_WAIT a10
SELECT
A.INST_ID,
A.SID,
A.SERIAL#,
A.USERNAME,
A.STATUS,
A.PROCESS,
A.MACHINE,
A.PROGRAM,
TO_CHAR(a.logon_time, 'MM/DD/YY HH24:MI:SS') as logntime,
--A.WAIT_TIME,
--A.SECONDS_IN_WAIT,
--A.STATE,
B.SQL_TEXT
FROM gV$SESSION A,gV$SQLAREA B
WHERE A.SQL_ADDRESS=B.ADDRESS(+)
AND A.INST_ID=B.INST_ID
AND A.SID=&sid
ORDER by TO_CHAR(logon_time, 'MM/DD/YY HH24:MI:SS'), a.SID;


### with prompt 

set linesize 500
col USERNAME for a10
col MACHINE for a10
col logntime for a20
col PROGRAM for a40
col SQL_TEXT for a45
col SECONDS_IN_WAIT a10
SELECT
A.INST_ID,
A.SID,
A.SERIAL#,
A.USERNAME,
A.STATUS,
A.PROCESS,
A.MACHINE,
A.PROGRAM,
TO_CHAR(a.logon_time, 'MM/DD/YY HH24:MI:SS') as logntime,
A.WAIT_TIME,
A.SECONDS_IN_WAIT,
A.STATE,
B.SQL_TEXT
FROM gV$SESSION A,gV$SQLAREA B
WHERE A.SQL_ADDRESS=B.ADDRESS(+)
AND A.INST_ID=B.INST_ID
AND B.SQL_TEXT like '%&part_of_the_query%'
ORDER by TO_CHAR(logon_time, 'MM/DD/YY HH24:MI:SS'), a.SID;

AND A.SID=&sid

set linesize 500
col USERNAME for a10
col MACHINE for a10
col logntime for a20
col PROGRAM for a40
col SQL_TEXT for a45
col SECONDS_IN_WAIT a10
SELECT
A.INST_ID,
A.SID,
A.SERIAL#,
A.USERNAME,
A.STATUS,
A.PROCESS,
A.MACHINE,
A.PROGRAM,
TO_CHAR(a.logon_time, 'MM/DD/YY HH24:MI:SS') as logntime,
--A.WAIT_TIME,
--A.SECONDS_IN_WAIT,
--A.STATE,
B.SQL_TEXT
FROM gV$SESSION A,gV$SQLAREA B
WHERE A.SQL_ADDRESS=B.ADDRESS(+)
AND A.INST_ID=B.INST_ID
AND A.sql_id='&sql_id'
ORDER by TO_CHAR(logon_time, 'MM/DD/YY HH24:MI:SS'), a.SID;


### blocking_session

select
INST_ID,
blocking_session,
sid,
serial#,
wait_class,
seconds_in_wait
from
gv$session
where
blocking_session is not NULL
order by
blocking_session;

-----------------------------------------------------
###DBA_HIST_ACTIVE_SESS_HISTORY

set linesize 1200
set pages 20000
col instance_number for 9
col SAMPLE_TIME for a21
col event for a30
col seser for a7
col seser for 9999999
select to_char(SAMPLE_TIME, 'YYYY/MM/DD HH24:MI:SS'),SESSION_ID,SESSION_SERIAL# seser,SQL_ID,BLOCKING_SESSION bls,BLOCKING_SESSION_SERIAL# blsr,SQL_CHILD_NUMBER,
SESSION_STATE sts,EVENT,time_waited
from dba_hist_active_sess_history
where sql_id is not null
and to_char(SAMPLE_TIME, 'YYYY/MM/DD HH24:MI:SS') between '2011/12/02 14:20:50' and '2011/12/02 15:20:34'
--and SESSION_ID=431
and BLOCKING_SESSION is NOT NULL        --324 --and BLOCKING_SESSION_SERIAL#=25940
and BLOCKING_SESSION=431
--and snap_id =21301
--and ((SESSION_ID=1209 and SESSION_SERIAL#=22327) or (BLOCKING_SESSION =1209 and BLOCKING_SESSION_SERIAL#=22327))
order by SAMPLE_TIME

-----------------------------------------------------

### SQL_TEXT SQL_FULLTEXT DBA_HIST_SQLTEXT
set long 9000;

Select sql_fulltext from v$sqlarea where sql_id='9xg23jhv4qa8a';

select sql_text from dba_hist_sqltext where sql_id='0825y010hnvzm';

-----------------------------------------------------

### DBID

http://www.oracle-base.com/articles/9i/DBNEWID.php


--------------------------------------------------

Load balancing advisor - LBA


select inst_id, count(*) from gv$session group by inst_id;



SELECT 
     name
    ,TO_CHAR(creation_date, 'mm-dd-yyyy hh24:mi:ss') created_on
    ,goal
    ,clb_goal
    ,aq_ha_notifications
  FROM dba_services
 WHERE goal IS NOT NULL
   AND name NOT LIKE 'SYS%'
 ORDER BY name
;


SELECT
     service_name
    ,TO_CHAR(begin_time,'hh24:mi:ss') beg_hist
    ,TO_CHAR(end_time,'hh24:mi:ss') end_hist
    ,inst_id
    ,goodness
    ,delta
    ,flags
    ,cpupercall
    ,dbtimepercall
    ,callspersec
    ,dbtimepersec
  FROM gv$servicemetric
 ORDER BY service_name, begin_time DESC, inst_id
;

EXECUTE DBMS_SERVICE.MODIFY_SERVICE (service_name => 'ORDER' 
        , CLB_GOAL => DBMS_SERVICE.CLB_GOAL_SHORT);


BEGIN

    DBMS_SERVICE.MODIFY_SERVICE(
        service_name => 'orcl'
--       ,aq_ha_notifications => TRUE
       ,goal => DBMS_SERVICE.GOAL_SERVICE_TIME
       ,clb_goal => DBMS_SERVICE.CLB_GOAL_LONG
    );

END;
/

--------------------------------------------------


###

Sorry, I had a DUH moment.

I just did this:

sqlplus "sys/$PSWD@$AUXILIARY_SID as sysdba" @shutdown.sql

I think this will work

THANKS! 



An alternative is:


Code:
echo $PSWD | sqlplus "sys@$AUXILIARY_SID as sysdba" @shutdown.sql
or you can use a named pipe:


Code:
mknod p sysdba_logon.sql
echo "connect sys/$PSWD@$AUXILIARY_SID as sysdba" > connect.sql &
sqlplus <<-EOF
@connect.sql
@shutdown.sql
EOF
rm connect.sql 


--------------------------------------------------

### lock files

you can also try deleting all the DBSPI lock files under
\usr\ov\dbspi\history\<dbtype> or /var/opt/OV/dbspi/history/<dbtype> and DBMon lock file in
\usr\ov\dbspi\dbmon.lock.* or /var/opt/OV/dbspi/dbmon.lock.*



--------------------------------------------------


### procedure for kill sessions that are not SYS and SYSTEM owned

procedure kill_session_custom
(pn_sid number,pn_serial number)
as
lv_user varchar2(30);
begin
select username into lv_user from v$session where sid = pn_sid and serial# = pn_serial;
if lv_user is not null and lv_user not in ('SYS','SYSTEM') then
execute immediate 'alter system kill session '''||pn_sid||','||pn_serial||'''';
else
raise_application_error(-20000,'Attempt to kill protected system session has been blocked.');
end if;
end;


grat execute on kill_session_custom to CRDW_REL1;
grant select on v_$session to CRDW_REL1;
grant select on v_$process to  CRDW_REL1;

#example
#execute kill_session_custom (292,21928);

create or replace procedure kill_session( p_sid in varchar2, 
                                          p_serial# in varchar2)
is
    cursor_name     pls_integer default dbms_sql.open_cursor;
    ignore          pls_integer;
BEGIN
    select count(*) into ignore
      from V$session
     where username = USER
       and sid = p_sid
       and serial# = p_serial# ;

    if ( ignore = 1 )
    then
        dbms_sql.parse(cursor_name,
                      'alter system kill session ''' 
                                ||p_sid||','||p_serial#||'''',
                       dbms_sql.native);
        ignore := dbms_sql.execute(cursor_name);
    else
        raise_application_error( -20001, 
                               'You do not own session ''' ||
                                p_sid || ',' || p_serial# ||
                               '''' );
    end if;
END;
/


#### procedure for kill sessions that are SNIPED due to IDLE_TIME profile limit


1.	Create new profile �SNIPED_PROFILE� and set the IDLE_TIME limit � this is the specified time in minutes that the sessions are SNIPED after

CREATE PROFILE "SNIPED_PROFILE" LIMIT IDLE_TIME 1440;

1440 = 24 hours

2.	Modify the resource_limit parameter to TRUE � this will enable the limits. However until we assign the profile to some user we still are not using the idle_time.

alter system set resource_limit=true;

3.	Create procedure in the sys schema to kill the SNIPED sessions (reason � SNIPED becomes the sessions that were idle for more than the IDLE_TIME and are not dropped until the user tries to run a query. But as the user is INACTIVE we will kill such SNIPED user):

CREATE OR REPLACE PROCEDURE "SYS"."KILL_SESSION_SNIPED"
as
sid number;
serial1 number;
CURSOR SESSION_SNIPED1 IS
select sid,serial# as serial1 from v$session where status = 'SNIPED' and USERNAME is not null and USERNAME !='SYS';
	BEGIN
		FOR r1 IN SESSION_SNIPED1 LOOP
		execute immediate 'alter system kill session '''||r1.sid||','||r1.serial1||''' immediate';
		END LOOP;
	END;
/

4.	Create job to execute KILL_SESSION_SNIPED every hour:

BEGIN
  DBMS_SCHEDULER.create_job (
    job_name        => 'JOB_KILL_SESSION_SNIPED',
    job_type        => 'PLSQL_BLOCK',
    job_action      => 'BEGIN KILL_SESSION_SNIPED; END;',
    start_date      => SYSTIMESTAMP,
    repeat_interval => 'freq=hourly; byminute=0; bysecond=0;',
    enabled         => TRUE,
    comments        => 'Job executes KILL_SESSION_SNIPED in order to kill SNIPED sessions');
END;
/

BEGIN
DBMS_SCHEDULER.SET_ATTRIBUTE (
   name           =>   'GATHER_STATS_S_PERIOD',
   attribute      =>   'repeat_interval',
   value          =>   'FREQ = DAILY; BYHOUR=10; BYMINUTE=30;BYSECOND=0 ');
END;
/ 



5.	Now set the profile to the users you need to be dropped if they stay more than the IDLE_TIME

Alter user xxxx profile SNIPED_PROFILE;




--------------------------------------------------

#### listener config RAC - if not registering automaticaly - but thisway the loadbalance does not work

NAME                                 TYPE        VALUE
------------------------------------ ----------- ------------------------------
local_listener                       string      (ADDRESS = (PROTOCOL = TCP)(HO
                                                 ST = sracp03-v.tor.omc.hp.com)
                                                 (PORT = 1521))

--------------------------------------------------											 
												 
### redu log resize

One of the best ways I have found to resize or recreate online redo log files and keep the current sequence is to perform it online. In this example, we will resize all online redo logs from 100MB to 250MB while the database is running and use SQL*Plus to drop/recreate them in stages. 

Before looking at the tasks involved to perform the resize, let's look at the current online redo log groups and their sizes: 

set linesize 400
col MEMBER for a70
SELECT a.type, a.group#, b.status, a.member, b.bytes FROM v$logfile a, v$log b WHERE a.group# = b.group#(+);

    GROUP# MEMBER                                          BYTES
---------- ---------------------------------------- ------------
         1 /u03/app/oradata/ORA920/redo_g01a.log     104,857,600
         1 /u04/app/oradata/ORA920/redo_g01b.log     104,857,600
         1 /u05/app/oradata/ORA920/redo_g01c.log     104,857,600
         2 /u03/app/oradata/ORA920/redo_g02a.log     104,857,600
         2 /u04/app/oradata/ORA920/redo_g02b.log     104,857,600
         2 /u05/app/oradata/ORA920/redo_g02c.log     104,857,600
         3 /u03/app/oradata/ORA920/redo_g03a.log     104,857,600
         3 /u04/app/oradata/ORA920/redo_g03b.log     104,857,600
         3 /u05/app/oradata/ORA920/redo_g03c.log     104,857,600

9 rows selected.


Make the last redo log CURRENT 
Force a log switch until the last redo log is marked "CURRENT" by issuing the following command: 


SQL> alter system switch logfile;

SQL> alter system switch logfile;

SQL> select group#, status from v$log;

    GROUP# STATUS
---------- ----------------
         1 INACTIVE
         2 INACTIVE
         3 CURRENT


Drop first redo log 
After making the last online redo log file the CURRENT one, drop the first online redo log: 

SQL> alter database drop logfile group 1;

Database altered.
   As a DBA, you should already be aware that if you are going to drop a logfile group, it cannot be the current logfile group. I have run into instances; however, where attempting to drop the logfile group resulted in the following error as a result of the logfile group having an active status: 
SQL> ALTER DATABASE DROP LOGFILE GROUP 1;
ALTER DATABASE DROP LOGFILE GROUP 1
*
ERROR at line 1:
ORA-01624: log 1 needed for crash recovery of instance ORA920 (thread 1)
ORA-00312: online log 1 thread 1: '<file_name>'
Easy problem to resolve. Simply perform a checkpoint on the database: 
SQL> ALTER SYSTEM CHECKPOINT GLOBAL;

System altered.

SQL> ALTER DATABASE DROP LOGFILE GROUP 1;

Database altered.
 
 




Re-create dropped online redo log group 
Re-create the dropped redo log group with different size (if desired): 

SQL> alter database add logfile group 1 (
  2  '/u03/app/oradata/ORA920/redo_g01a.log',  
  3  '/u04/app/oradata/ORA920/redo_g01b.log',
  4  '/u05/app/oradata/ORA920/redo_g01c.log') size 250m reuse;

Database altered.

Force another log switch 
After re-creating the online redo log group, force a log switch. The online redo log group just created should become the "CURRENT" one: 

SQL> select group#, status from v$log;

    GROUP# STATUS
---------- ----------------
         1 UNUSED
         2 INACTIVE
         3 CURRENT

SQL> alter system switch logfile;

SQL> select group#, status from v$log;

    GROUP# STATUS
---------- ----------------
         1 CURRENT
         2 INACTIVE
         3 ACTIVE

Loop back to Step 2 until all logs are rebuilt 
After re-creating an online redo log group, continue to re-create (or resize) all online redo log groups until all of them are rebuilt. 



--------------------------------------------------------------------------------

After rebuilding (resizing) all online redo log groups, here is a snapshot of all physical files: 

set linesize 400
col MEMBER for a70
SELECT a.group#, a.member, b.bytes
FROM v$logfile a, v$log b WHERE a.group# = b.group#;

    GROUP# MEMBER                                          BYTES
---------- ---------------------------------------- ------------
         1 /u03/app/oradata/ORA920/redo_g01a.log     262,144,000
         1 /u04/app/oradata/ORA920/redo_g01b.log     262,144,000
         1 /u05/app/oradata/ORA920/redo_g01c.log     262,144,000
         2 /u03/app/oradata/ORA920/redo_g02a.log     262,144,000
         2 /u04/app/oradata/ORA920/redo_g02b.log     262,144,000
         2 /u05/app/oradata/ORA920/redo_g02c.log     262,144,000
         3 /u03/app/oradata/ORA920/redo_g03a.log     262,144,000
         3 /u04/app/oradata/ORA920/redo_g03b.log     262,144,000
         3 /u05/app/oradata/ORA920/redo_g03c.log     262,144,000

9 rows selected.


---------------------------------------------

### total PGA usage in MB
SELECT inst_id, sum(PGA_USED_MEM)/1024/1024 as "Total PGA usage in MB", sum(PGA_ALLOC_MEM)/1024/1024 as "Total PGA Alloc" from GV$PROCESS group by inst_id;


### PGA for sesssion

col MACHINE for a30
select vs.sid,vs.serial#,vp.spid,vs.username,status, vs.osuser,vs.machine,vs.program ,vp.pga_used_mem/1024/1024 "PGA Mb",
vp.pga_alloc_mem/1024/1024 "PGA alloc" from v$session vs, v$process vp where vs.paddr = vp.addr order by vp.pga_alloc_mem;


---------------------------------------------


### export examples

### Check source user(s) schema(s) size - schema size
SELECT s.owner,SUM (s.BYTES) / (1024 * 1024) SIZE_IN_MB FROM dba_segments s GROUP BY s.owner;
select owner, tablespace_name, sum(bytes)/1024/1024 from dba_segments group by owner, tablespace_name;

create or replace directory DDPP1 as '/u02/oradata4/SPSTG/exp';
grant read, write on directory DDPP1 to SYSTEM;


expdp directory=DP1_EXP DUMPFILE=FIPSFRP0_AXINTFR04608_2010apr6.dmp LOGFILE=FIPSFRP0_AXINTFR04608_2010apr6.log full=Y estimate_only=y;

expdp directory=DP1_EXP parallel=4 DUMPFILE=FIPSFRP0_AXINTFR04608_2010apr6_paralel_1st.dmp, FIPSFRP0_AXINTFR04608_2010apr6_paralel_2nd.dmp, FIPSFRP0_AXINTFR04608_2010apr6_paralel_3rd.dmp, FIPSFRP0_AXINTFR04608_2010apr6_paralel_4th.dmp LOGFILE=FIPSFRP0_AXINTFR04608_2010apr6.log full=Y ;

impdp directory=DP1 parallel=8 DUMPFILE=ovacsdev_PGADMIN_2010aug18_paralel_%U.dmp LOGFILE=ovacsdev_PGADMIN_2010aug18_paralel_imp.log SCHEMAS=PGADMIN

expdp directory=DP1 parallel=8 DUMPFILE=ovacsdev_PGADMIN_2010aug18_paralel_%U.dmp LOGFILE=ovacsdev_PGADMIN_2010aug18_paralel_exp.log SCHEMAS=PGADMIN


DUMPFILE=DP1:FIPSFRP0_AXINTFR04608_2010apr6_paralel_1st.dmp, DP2:FIPSFRP0_AXINTFR04608_2010apr6_paralel_2nd.dmp, DP3:FIPSFRP0_AXINTFR04608_2010apr6_paralel_3rd.dmp, DP4:FIPSFRP0_AXINTFR04608_2010apr6_paralel_4th.dmp

expdp directory=DP3 logfile=exp_ESLP_ESL_13apr_10.log DUMPFILE=exp_ESLP_ESL_13apr_10.dmp SCHEMAS=ESL;

expdp directory=DP4 DUMPFILE=DBSTRUCTUREONLY_ESLP_13apr10.dmp LOGFILE=DBSTRUCTUREONLY_ESLP_13apr10.log content=METADATA_ONLY SCHEMAS=PWDB,ERM,ESAR,BTR,ACF,ESLROUSER,AB_USER;

### expdp impdp - parfile - paralel 2 with remap
DUMPFILE=DATA_PUMP_DIR:OVAC2PRD_LMSNOV32_paralel_1.dmp, DP_OVACPDB2:OVAC2PRD_LMSNOV32_paralel_2.dmp
logfile=DP_OVACPDB2:LMSNOV32_paralel_imp_withPAR.log
SCHEMAS=LMSNOV32
REMAP_SCHEMA=LMSNOV32:LMS_DEM29910_AC
REMAP_TABLESPACE=LMSNOV32:LMS_DEM29910_AC

---------------------------------------------

###Monitoring Oracle Data Pump import performance is simple

select 
   substr(sql_text,instr(sql_text,'into "'),30) table_name, 
   rows_processed, round((sysdate-to_date(first_load_time,'yyyy-mm-dd hh24:mi:ss'))*24*60,1) minutes,
   trunc(rows_processed/((sysdate-to_date(first_load_time,'yyyy-mm-dd hh24:mi:ss'))*24*60)) rows_per_minute 
from   
   sys.v_$sqlarea 
where  
   sql_text like 'insert %into "%' and command_type = 2 and open_versions > 0; 




---------------------------------------------

### backup to disk examples

run {
allocate channel t1 type disk;
allocate channel t2 type disk;
backup incremental level 0
format 'E:\Del_when_E-C10009621_finished\DB_ITECFRP0_ONLINE_1604_task_E-C10009621-T005_%s_%t_%p.dbf'
database;
backup
format 'E:\Del_when_E-C10009621_finished\C_ITECFRP0_ONLINE_1604_task_E-C10009621-T005_%s_%t_%p.dbf'
current controlfile;
}

---------------------------------------------

#### RMAN delete archivelogs

#delete noprompt archivelog until logseq 144180;

DELETE noprompt ARCHIVELOG ALL BACKED UP 1 times to device type SBT_TAPE;

#delete noprompt archivelog all completed before 'sysdate -0.7'; 
 
---------------------------------------------


root@irac05 # cat lgwr.sql
PROMPT instance_name
select instance_name from v$instance
/

##########################PROMPT  Last log received and last applied APPLIED 
select al.thread#,
        al.last_rec "Last Recd",
        la.last_app "Last Applied"
from
  (select thread#, max(sequence#) last_rec
    from v$archived_log
    group by thread#) al,
  (select thread#, max(sequence#) last_app
    from v$archived_log
    where applied='YES' and registrar='RFS'
    group by thread#) la
where al.thread#=la.thread#
and   al.thread# != 0
order by al.thread#
/

PROMPT  LGWR processes
select process, status, client_process, thread#, sequence#, block#
from v$managed_standby
-- where client_process in ('ARCH','LGWR','APPLYING_LOG')
where thread#> 0
order by thread#
/

PROMPT  Report archive gaps
select thread#, low_sequence#, high_sequence#
from  v$archive_gap
/

PROMPT  Currently waiting for the following log
select thread#, sequence#
from v$managed_standby
where status = 'WAIT_FOR_LOG'
/

PROMPT  Archivelog Space Report
col limit format 999,999,999 heading "Limit (mb)";
col used format 999,999,999 heading "Space Used (mb)";
col free format 999,999,999 heading "Space Free (mb)";
select space_limit/(1024*1024) limit
, (space_used + space_reclaimable)/(1024*1024) used
, (space_limit-(space_used+space_reclaimable))/(1024*1024) free
,number_of_files
from v$recovery_file_dest
/

select distinct database_mode, recovery_mode
from gv$archive_dest_status
/

---------------------------------------------

### size of tables

select owner,segment_name,tablespace_name, round(bytes/1024/1024/1024,2) as GB 
from dba_segments where SEGMENT_TYPE='TABLE' and segment_name in (
'BKUP_F','CALL_ACTY_F','CALL_F','ESL_INSTLD_PATCHES_F','EXCH_MLBX_CPCTY_F','INCID_ACTY_F',
'INCID_F','OVPI_BANDWIDTH_PACKET_LOSS_F','OVPI_PORT_AVL_HOURLY_F','SAP_PGM_PERF_F','SRVR_CPCTY_F','SRVR_HRLY_SYS_PERF_F',
'SRVR_SYS_PERF_F','STOR_AVL_F') order by segment_name;

---------------------------------------------

### list last SCN - rman backup restore

scn=$(echo "list backup of archivelog from time = 'SYSDATE-1';" |
rman TARGET "sys/GDssUE#9@AGOLF1R1" |
sed -n 's/^[[:blank:]]*[[:digit:]]*[[:blank:]]*[[:digit:]]*[[:blank:]]*\([[:digit:]]*\)[[:blank:]]*.*$/\1/p' |
sort -n |
tail -1)
echo $scn

### how to start rman plus log

rman cmdfile=AWM04_logs.rman msglog=AWM04_log.log.`date +%Y%m%d%H%M`

#contact of AWM04_logs.rman

connect target "sys/GDssUE#9@AGOLF1R1";
run {
allocate channel 'dev_0' type 'sbt_tape'
 parms 
'ENV=(OB2BARTYPE=Oracle8,OB2APPNAME=AGOLFRR1,OB2BARLIST=hx004100-vip_AGOLFRR1_ON_daily)';
allocate channel 'dev_1' type 'sbt_tape'
...
...
}


### Sample refresh script - at now - run in background

su oracle
stty sane
export MANPATH=/opt/quest/man:
export LANG=en_US
export LOGIN=oracle
export PATH=/appl/oracle/product/11.1.0/db_1/bin:/usr/bin:/etc:/usr/sbin:/usr/ucb:/home/oracle/bin:/usr/bin/X11:/sbin:.
export NLS_LANG=
export ORACLE_BASE=/appl/oracle
export LC__FASTMSG=true
export EDITOR=/usr/bin/vi
export MAIL=/usr/spool/mail/oracle
export ORACLE_SID=FIPSDES1
export LOCPATH=/usr/lib/nls/loc
export USER=oracle
export AUTHSTATE=files
export ORACLE_ADMIN=/local/FIPSDES1/admin
export ORA_NLS10=/appl/oracle/product/11.1.0/db_1/nls/data
export SHELL=/usr/bin/ksh
export ODMDIR=/etc/objrepos
export HOME=/home/oracle
export TERM=xterm
export ORACLE_HOME=/appl/oracle/product/11.1.0/db_1
export NLSPATH=/usr/lib/nls/msg/%L/%N:/usr/lib/nls/msg/%L/%N.cat
rman target sys/7upDBA@FIPSDEP0 nocatalog auxiliary sys/7upDBA@FIPSDES1 <<EOF
DUPLICATE TARGET DATABASE TO 'FIPSDES1' FROM ACTIVE DATABASE;
exit
EOF
exit

---------------------------------------------

### Duplicate fropm type

run
{
allocate auxiliary channel ch0 type 'sbt_tape';
allocate auxiliary channel ch1 type 'sbt_tape';
allocate auxiliary channel ch2 type 'sbt_tape';
allocate auxiliary channel ch3 type 'sbt_tape';
DUPLICATE TARGET DATABASE TO <DBNAME> NOFILENAMECHECK ;
}

---------------------------------------------

### creating session killing statement from spid

set linesize 32767;
set pagesize 0;
set verify off;
set heading off;
col program form a10 wrap
col process for a10
col sql_text for a80 wrap
col LOGIO for 999,999,999
col PHYSIO for 999,999,999
col HITRATIO for 999.99
col session_info heading "Session Info"
select 
'Sid/Serial#:         '||s.sid||'/'||s.serial#||chr(10)||
'Aud sid:             '||S.audsid||chr(10)||
'DB User/OS User:     '||S.Username||'/'||S.OSuser||chr(10)||
'Machine - Terminal:  '||s.machine||' -  '|| S.terminal||chr(10)||
'OS Process Ids: '||chr(10)||
'            CLIENT - '||S.Process||chr(10)||
'            SERVER - '||P.Spid||chr(10)||
'Client Program Name: '||s.program ||chr(10)||
'Server Program Name: '||p.program ||chr(10)||
'Module:              '||s.module||chr(10)||
'Status/Type:         '||s.status||'/'||s.type||chr(10)||
'Logical IO:          '||(e.consistent_Gets + e.block_Gets) ||chr(10)||
'Physical IO:         '||e.Physical_reads||chr(10)||
'HitRatio:            '||round(100 * ((e.consistent_Gets + e.block_Gets - e.Physical_reads) / (e.consistent_Gets + e.block_Gets)),2) ||chr(10)||
'Logon Time:          '||to_char(logon_time, 'mm/dd/yy hh24:mi:ss')||chr(10)||
'Seconds Since Active '||s.last_call_et ||chr(10)|| 
-- 'Terminal:            '||sys_context('USERENV','TERMINAL')||chr(10)||
'Kill Command:        '||'alter system kill session '''||s.sid||','||s.serial#||''';'||chr(10)||chr(10)||
'SQL Text:'||chr(10)||
t.sql_text
session_info
from v$process p, v$session s, v$sqlarea t, v$sess_io e
where p.addr = s.paddr
and s.sql_address = t.address
and s.sid=e.sid
and p.spid = <PUT PID HERE>;

---------------------------------------------

### select tables size and group partitions

set linesize 400
col SEGMENT_NAME for a40
select SEGMENT_NAME,SEGMENT_TYPE,OWNER,TABLESPACE_NAME,sum(BYTES/1024/1024) as MB from dba_segments where SEGMENT_NAME in ('INCID_F','INCID_ACTY_F','CALL_F') group by SEGMENT_NAME,SEGMENT_TYPE,OWNER,TABLESPACE_NAME;

---------------------------------------------

# Script name: refresh_OVSCSNOV_from_SMEMSTB.sh
export PATH=/opt/app/oracle/product/11.1.0/bin:$PATH
export ORACLE_HOME=/opt/app/oracle/product/11.1.0
export ORACLE_SID=OVSCSNOV
rman target /
SET PARALLELMEDIARESTORE OFF;
run {
allocate channel 'dev_0' type sbt_tape;
allocate channel 'dev_1' type sbt_tape;
allocate channel 'dev_2' type sbt_tape;
allocate channel 'dev_3' type sbt_tape;
set until SCN 10630609336959;
set newname for datafile 1 to '/var/opt/oracle/oradata1/OVSCSNOV/system01.dbf';
set newname for datafile 2 to '/var/opt/oracle/oradata1/OVSCSNOV/sysaux01.dbf';
set newname for datafile 3 to '/var/opt/oracle/oradata1/OVSCSNOV/undotbs01.dbf';
set newname for datafile 4 to '/var/opt/oracle/oradata1/OVSCSNOV/users01.dbf';
set newname for datafile 5 to '/var/opt/oracle/oradata1/OVSCSNOV/undotbs02.dbf';
set newname for datafile 6 to '/var/opt/oracle/oradata1/OVSCSNOV/SM_DATA01.dbf';
set newname for datafile 7 to '/var/opt/oracle/oradata1/OVSCSNOV/SM_INDEX01.dbf';
set newname for datafile 8 to '/var/opt/oracle/oradata1/OVSCSNOV/undotbs03.dbf';
set newname for datafile 9 to '/var/opt/oracle/oradata1/OVSCSNOV/SM_DATA02.dbf';
RESTORE DATABASE;
switch datafile all;
RECOVER DATABASE;
}

---------------------------------------------

#### explain plan
set echo on
SET AUTOTRACE TRACEONLY
query...

### explain plan

14:21:36 SQL> explain plan for
14:22:00   2  SELECT a.mtime, a.userid, a.sysdrv, a.wname, a.wsize, a.wlabel,a.wfreespace, a.wfilesystem FROM rad_report.test a;

Explained.

Elapsed: 00:00:00.16

-----

SET LINESIZE 130 
SET PAGESIZE 0 
SELECT * FROM table(DBMS_XPLAN.DISPLAY); 

-----

14:22:02 SQL> @$ORACLE_HOME/rdbms/admin/utlxpls.sql

PLAN_TABLE_OUTPUT
--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
Plan hash value: 1288531618

--------------------------------------------------------------------------------------------
| Id  | Operation          | Name          | Rows  | Bytes |TempSpc| Cost (%CPU)| Time     |
--------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT   |               |   102K|  9910K|       |  3587   (4)| 00:00:44 |
|*  1 |  HASH JOIN         |               |   102K|  9910K|  2032K|  3587   (4)| 00:00:44 |
|   2 |   TABLE ACCESS FULL| DEVICECONFIG  | 47289 |  1477K|       |  1143   (3)| 00:00:14 |
|*  3 |   TABLE ACCESS FULL| RWIN32_VOLUME |   102K|  6707K|       |  1948   (5)| 00:00:24 |
--------------------------------------------------------------------------------------------


PLAN_TABLE_OUTPUT
---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------

   1 - access("A"."USERID"="DEVICECONFIG"."DEVICE_ID")
   3 - filter("A"."WFILESYSTEM"<>'CDFS' AND "A"."WNAME" NOT LIKE '\\%')

16 rows selected.


--------------------------------------------------------------

Start a session to trace the SQL statement in the bad_sql.sql script as the SH 
user. Set the TRACEFILE_IDENTIFIER parameter for your session. Add the 
�badsql� string to the trace file name.  

ALTER SESSION SET TRACEFILE_IDENTIFIER="badsql"; 

Enable tracing in your session with the command, and then run the bad_sql.sql 

EXECUTE DBMS_SESSION.SET_SQL_TRACE(TRUE); 
 
exit

Find and format the trace file. The trace file will be in the 
$ORACLE_BASE/diag/rdbms/orcl/orcl/trace directory with the 
badsql string embedded in the name. The ls *badsql*.trc command returns 
the name of the trace file. Use that name of the trace file in the tkprof command. 

ls *badsql*.trc

tkprof orcl_ora_14804_badsql.trc badsql.txt EXPLAIN=sh/sh SYS=NO

 ---------------
############
############
############
############
############

#### archivleog destinatuion check

espx0160:/oracle/admin/CABDWPRO/log#cat /oracle/admin/CABDWPRO/scripts/CABDWPRO_archlog_check.sh
##########################################################################################
### This script checks the amounts of archivelogs generated,
### and starts the corresponding archivelog backup if threshold exceeded.
### The logfiles are located in /oracle/admin/CABDWPRO/log/
##########################################################################################

### Export default variables
DATE=`/usr/bin/date "+%H:%M:%S_%Y%m%d"`
LOGDIR=/oracle/admin/CABDWPRO/log
LOGFILE=$LOGDIR/$DATE-CABDWPRO_ARCHLOG.log
BACKUPLOG=$LOGDIR/$DATE-CABDWPRO_ARCHLOG_BACKUP.log
THRESHOLD=15360

### Generate backup status checking sql script
echo "set heading off" > $LOGDIR/status.sql
echo "set feedback off" >> $LOGDIR/status.sql
echo "spool /tmp/temp.log" >> $LOGDIR/status.sql
echo "select status, DB_NAME from RC_RMAN_BACKUP_JOB_DETAILS where db_name = 'CABDWPRO' and status = 'RUNNING';" >> $LOGDIR/status.sql
echo "spool off" >> $LOGDIR/status.sql
echo "exit" >> $LOGDIR/status.sql
/usr/bin/chown ora10g:oinstall $LOGDIR/status.sql

### Export current FRA utilization:
export ORACLE_SID="`cat /etc/oratab | grep ^+ASM | cut -d: -f1`"
export ORACLE_HOME="`cat /etc/oratab | grep -i ASM | cut -d: -f2 | uniq`"
FRA1=`su oraasm -c "$ORACLE_HOME/bin/asmcmd du -H PROARCH"`
FRA1=`echo  $FRA1 | awk '{ print $1}'`

if [ -z "$FRA1" ]; then
        FRA1=0
fi

### Check for running backup:
export ORACLE_SID="`cat /etc/oratab | grep ^CABDWPRO | cut -d: -f1`"
export ORACLE_HOME="`cat /etc/oratab | grep -i CABDWPRO | cut -d: -f2 | uniq`"
$ORACLE_HOME/bin/sqlplus rmanuser/fortumuser@RCAT.world @$LOGDIR/status.sql

T1=`cat /tmp/temp.log`
if [ -n "$T1" ]; then
echo "$DATE | +PROARCH/CABDWPRO/ARCHIVELOG/  | $FRA1 MB / $THRESHOLD MB | backup is still/already running. " >> $LOGFILE
exit 0;
fi;

### If no running backup and the utilization is below threshold, starting one:
if [ $FRA1 -gt $THRESHOLD ]; then
        echo ""
        echo "$DATE | +PROARCH/CABDWPRO/ARCHIVELOG/  | $FRA1 MB/ $THRESHOLD MB | backup CABDWPRO_ARCHIVELOGS started. " >> $BACKUPLOG
        su ora10g -c "/oracle/admin/RMAN_backup/CABDWPRO/scripts/RMAN_ARCH.sh" &
else
        echo "$DATE | +PROARCH/CABDWPRO/ARCHIVELOG/  | $FRA1 MB/ $THRESHOLD MB | no backup necessary. " >> $LOGFILE
        exit 0;
fi;

### Remove backup logs older than 14 days ...
find $LOGDIR \-type f -mtime +14 -exec rm {} \;
espx0160:/oracle/admin/CABDWPRO/log#

############
############
############
############
############
############


--------------------------------------------------------------


####The following query displays information about each statement that is using space in a sort segment.[query 1]

col SQL_TEXT for a80
col TABLESPACE for a10
SELECT   S.sid || ',' || S.serial# sid_serial, S.username,
         T.blocks * TBS.block_size / 1024 / 1024 mb_used, T.tablespace,
         T.sqladdr address, Q.hash_value, Q.sql_text
FROM     v$sort_usage T, v$session S, v$sqlarea Q, dba_tablespaces TBS
WHERE    T.session_addr = S.saddr
AND      T.sqladdr = Q.address (+)
AND      T.tablespace = TBS.tablespace_name
ORDER BY S.sid;

--------------------------------------------------------------

#####The following query displays information about each database session that is using space in a sort segment.[query 2]

set linesize 200
col SID_SERIAL for a15
col USERNAME for a10
col OSUSER for a10
col MODULE for a30
SELECT   S.sid || ',' || S.serial# sid_serial, S.username, S.osuser, P.spid, S.module,
         S.program, SUM (T.blocks) * TBS.block_size / 1024 / 1024 mb_used, T.tablespace,
         COUNT(*) sort_ops
FROM     v$sort_usage T, v$session S, dba_tablespaces TBS, v$process P
WHERE    T.session_addr = S.saddr
AND      S.paddr = P.addr
AND      T.tablespace = TBS.tablespace_name
GROUP BY S.sid, S.serial#, S.username, S.osuser, P.spid, S.module,
         S.program, TBS.block_size, T.tablespace
ORDER BY sid_serial;

--------------------------------------------------------------


###The following query displays information about all sort segments in the database. [query 3]

SELECT   A.tablespace_name tablespace, D.mb_total,
         SUM (A.used_blocks * D.block_size) / 1024 / 1024 mb_used,
         D.mb_total - SUM (A.used_blocks * D.block_size) / 1024 / 1024 mb_free
FROM     v$sort_segment A,
         (
         SELECT   B.name, C.block_size, SUM (C.bytes) / 1024 / 1024 mb_total
         FROM     v$tablespace B, v$tempfile C
         WHERE    B.ts#= C.ts#
         GROUP BY B.name, C.block_size
         ) D
WHERE    A.tablespace_name = D.name
GROUP by A.tablespace_name, D.mb_total;

--------------------------------------------------------------

### AWR report

cd $ORACLE_HOME/rdbms/admin
SQL> @awrrpt.sql

--------------------------------------------------------------

### date set NLS_LANG, NLS_DATE_FORMAT

SELECT * from NLS_DATABASE_PARAMETERS WHERE parameter IN ( 'NLS_LANGUAGE', 'NLS_TERRITORY', 'NLS_CHARACTERSET');

alter session set nls_date_format='MM/DD/YYYY HH24:MI:SS';

export NLS_LANG=american_america.UTF8
export NLS_DATE_FORMAT="yyyy-mm-dd:hh24:mi:ss" 

--------------------------------------------------------------

### Verify TEMP

create global temporary table tempfile_test (col1 number);

insert into tempfile_test values (1);

commit;

drop table tempfile_test;


--------------------------------------------------------------

### Unregister RMAN

SET LINESIZE 200
SET PAGESIZE 9999
COLUMN db_key		FORMAT 99999999               HEADING 'DB|Key'
COLUMN dbinc_key		FORMAT 99999999               HEADING 'DB Inc|Key'
COLUMN dbid			FORMAT 999999999999       HEADING 'DBID'
COLUMN name			FORMAT a12                         HEADING 'Database|Name'
COLUMN resetlogs_change_num   FORMAT 9999999999999999       HEADING 'Resetlogs|Change Num'
COLUMN resetlogs		FORMAT a21		HEADING 'Reset Logs|Date/Time'
prompt
prompt Listing of all databases in the RMAN recovery catalog
prompt 
SELECT
    rd.db_key
  , rd.dbinc_key
  , rd.dbid
  , rd.name
  , rd.resetlogs_change#                                 resetlogs_change_num
  , TO_CHAR(rd.resetlogs_time, 'DD-MON-YYYY HH24:MI:SS') resetlogs
FROM
    rc_database   rd
	where rd.name='&DB_NAME'
ORDER BY
    rd.name
/


###

SELECT db_key, db_id 
FROM   db 
WHERE  db_id = 3523359034;
 
    	DB_KEY      DB_ID
---------- ----------
   	1056621 3523359034

4.3 Unregister the database from RMAN catalog:

EXECUTE dbms_rcvcat.unregisterdatabase(1056621, 3523359034);

--------------------------------------------------------------


### RMAN issue - RMAN errors

@$ORACLE_HOME/rdbms/admin/catdpb.sql 

SQL> ALTER SESSION SET EVENTS'942 trace name errorstack level 3';

Session altered.

SQL> alter package KUPW$WORKER compile BODY;

Warning: Package Body altered with compilation errors.

SQL> show error


SQL> CREATE GLOBAL TEMPORARY TABLE sys.ku$noexp_tab ON COMMIT PRESERVE ROWS AS SELECT * FROM sys.ku_noexp_view;

Table created.

SQL> GRANT SELECT ON sys.ku$noexp_tab TO PUBLIC;

Grant succeeded.

SQL> GRANT INSERT ON sys.ku$noexp_tab TO PUBLIC;

Grant succeeded.

SQL> alter package KUPW$WORKER compile BODY;

Package body altered.

Check the INVALID

SQL>

ALTER PACKAGE <SchemaName>.<PackageName> COMPILE;
SHOW ERRORS PACKAGE <SchemaName>.<PackageName>;
ALTER PACKAGE <SchemaName>.<PackageBodyName> COMPILE BODY;
SHOW ERRORS PACKAGE BODY <SchemaName>.<PackageName>;



--------------------------------------------------------------


alter session set current_schema=SCHEMA_NAME /*without quotes*/

--------------------------------------------------------------


### ORA-01555 caused by SQL statement below 

select a.process, a.program, a.module, a.machine, b.USED_UREC, c.sql_text
from v$sql c, v$session a, v$transaction b
where b.addr = a.taddr
and a.sql_address = c.address
and a.sql_hash_value = c.hash_value
order by b.USED_UREC;


--------------------------------------------------------------
### db console certificate recreate

-- Change SYSMAN password procedure

1. Change the sysman password in the database:
                SQL> alter user sysman identified by newpassword;

2. Stop DBCONSOLE services
                emctl stop dbconsole
                
3. Edit emoms.properties , targets.xml files:
                emoms.properties --> $ORACLE_HOME/localhost.domainname_sid/sysman/config/
                targets.xml --> $ORACLE_HOME/localhost.domainname_sid/sysman/emd/


emoms.properties:

oracle.sysman.eml.mntr.emdRepPwd="c7021fd3720a0f18" replace with PASSWORD
oracle.sysman.eml.mntr.emdRepPwdEncrypted="TRUE" replace with FALSE

oracle.sysman.eml.mntr.emdRepPwd=PASSWORD
oracle.sysman.eml.mntr.emdRepPwdEncrypted=FALSE


targets.xml:

[Property NAME="UserName" VALUE="80ec9025e45b2d20" ENCRYPTED="TRUE"/]
[Property NAME="password" VALUE="94124d177df7c5d9" ENCRYPTED="TRUE"/]

Replace username value with �SYSMAN� and password value with �SYSMAN PASSWORD�

[Property NAME="UserName" VALUE="SYSMAN" ENCRYPTED="TRUE"/]
[Property NAME="password" VALUE="PASSWORD" ENCRYPTED="TRUE"/]


4. Start DBCONSOLE service:
                emctl start dbconsole
                
5. Unlock SYSMAN account: 
SQL> alter user sysman account unlock;
                
                
-- Renew EM Certificate procedure

1. Unsecure the Dbconsole:
$ORACLE_HOME/bin>emctl unsecure dbconsole 

2. Secure DBConsole providing SYSMAN password:
$ORACLE_HOME/bin>emctl secure dbconsole

--------------------------------------------------------------

### Configure EM Enterprise manager dbconsole

Manual drop of db repository (to avoid quiescent mode)
drop user sysman cascade;
drop public synonym SETEMVIEWUSERCONTEXT;
drop role MGMT_USER;
drop PUBLIC SYNONYM MGMT_TARGET_BLACKOUTS;
drop user MGMT_VIEW;
And then
$ emca -deconfig dbcontrol db
.....
In active/passive clusters:
export ORACLE_HOSTNAME=scdbpkg01.gre.hp.com
emca -config dbcontrol db -repos create

-------------

###dbcontrol dbconsole deconfig -Master Note for Enterprise Manager Configuration Assistant (EMCA) in Single Instance Database Environment [ID 1099271.1]

<ORACLE_HOME>/bin/emca -deconfig dbcontrol db

Step 1: Drop AQ related objects in the SYSMAN schema
Logon SQLPLUS as user SYS
SQL> exec DBMS_AQADM.DROP_QUEUE_TABLE(queue_table=>'SYSMAN.MGMT_NOTIFY_QTABLE',force=>TRUE);

Step 2: Drop the DB Control Repository Objects
Logon SQLPLUS as user SYS or SYSTEM, and drop the sysman account and management objects:
SQL> SHUTDOWN IMMEDIATE;
SQL> STARTUP RESTRICT;
SQL> EXEC sysman.emd_maintenance.remove_em_dbms_jobs;
SQL> EXEC sysman.setEMUserContext('',5);
SQL> REVOKE dba FROM sysman;
SQL> DECLARE
CURSOR c1 IS
SELECT owner, synonym_name name
FROM dba_synonyms
WHERE table_owner = 'SYSMAN';
BEGIN
FOR r1 IN c1 LOOP
IF r1.owner = 'PUBLIC' THEN
EXECUTE IMMEDIATE 'DROP PUBLIC SYNONYM '||r1.name;
ELSE
EXECUTE IMMEDIATE 'DROP SYNONYM '||r1.owner||'.'||r1.name;
END IF;
END LOOP;
END;
/
SQL> DROP USER mgmt_view CASCADE;
SQL> DROP ROLE mgmt_user;
SQL> DROP USER sysman CASCADE;
SQL> ALTER SYSTEM DISABLE RESTRICTED SESSION;


--------------------------------------------------------------

###Quiesce mode

When running 'emca -config dbcontrol db -repos recreate' or 'emca -deconfig dbcontrol db -repos drop' to recreate or drop the Enterprise Manager Database Control configuration files and repository the operation hangs and at the same time users are not able to login to the database.

SQL > alter system unquiesce;

--------------------------------------------------------------

### EM (Enterprise Manager) DB control - confiiguration

Manual drop of db repository (to avoid quiescent mode)
drop user sysman cascade;
drop public synonym SETEMVIEWUSERCONTEXT;
drop role MGMT_USER;
drop PUBLIC SYNONYM MGMT_TARGET_BLACKOUTS;
drop user MGMT_VIEW;
And then
$ emca -deconfig dbcontrol db
.....
In active/passive clusters:
export ORACLE_HOSTNAME=scdbpkg01.gre.hp.com
emca -config dbcontrol db -repos create

SQL> create user oem_crdw identified by we23ud_kj default tablespace users temporary tablespace temp;
SQL> grant connect, resource, select any dictionary, oem_advisor to oem_crdw;

--------------------------------------------------------------

### longops and session select for user or SID - time remaining

set linesize 400
col USERNAME for a10
col MESSAGE for a60
select b.USERNAME,a.MESSAGE,a.SID,a.SERIAL#,a.SOFAR,a.START_TIME,a.TIME_REMAINING/60 as "remaining in min",a.ELAPSED_SECONDS/60 as "elapsed in min" from v$session_longops a, v$session b where
a.SID=b.SID
and a.TIME_REMAINING >0
order by start_time;

--------------------------------------------------------------

### database statistics gather 10 cores(DEGREE=>10)

exec DBMS_STATS.GATHER_DATABASE_STATS( ESTIMATE_PERCENT=>'100',DEGREE=>10,GRANULARITY=>'ALL',CASCADE=>TRUE);

### index statistics - INDEX_STATISTICS - DBMS_STATS.GATHER_INDEX_STATS

#In order to gather statistics on an index we may use the Oracle supplied package DBMS_STATS:
SQL> Execute DBMS_STATS.GATHER_INDEX_STATS ('HR�,�LOC_COUNTRY_IX�);

#or gather statistics at index creation time:
SQL> Create index hr.loc_country_ix � compute statistics;

#or gathering statistics when rebuilding an index:
SQL> Alter index hr.loc_country_ix rebuild compute statistics;

#But after 10g even you do not mention to collect, statistics are collected by default;

### rebuild index

select OWNER,INDEX_NAME,INDEX_TYPE,STATUS from dba_indexes where STATUS !='VALID' and STATUS !='N/A';
select index_owner, index_name, PARTITION_NAME,STATUS from dba_IND_PARTITIONS where STATUS !='USABLE';
select index_owner, index_name, SUBPARTITION_NAME,STATUS from dba_IND_subPARTITIONS where STATUS !='VALID';

alter index I_WRI$_OPTSTssAT_OPR_STIME  rebuild online parallel (degree 8) INITRANS 10;
alter index I_WRI$_OPTSTssAT_OPR_STIME  rebuild online INITRANS 10;
alter index "EDWPROD"."EDW_CRFS_SLS_PRF_BRDG_CUST_IDX"  rebuild online;

set long 9000 pages 1000 linesize 150
select dbms_metadata.get_ddl('SEQUENSCE',INDEX_NAME,OWNER) from dba_indexes where STATUS='UNUSABLE';

select 'ALTER INDEX ' || OWNER || '.'|| index_name ||' REBUILD ONLINE COMPUTE STATISTICS ' || 'parallel (degree 2) INITRANS 10;' from dba_indexes
where status ='UNUSABLE';


#rebuild partitions and subpartitions of index
select 'ALTER INDEX '|| index_name ||' rebuild partition ' || PARTITION_NAME ||'parallel (degree 8) INITRANS 10;' from dba_IND_PARTITIONS
where
--INDEX_OWNER ='CRDW_REL1' and
status ='UNUSABLE';


select 'ALTER INDEX '|| index_name ||' rebuild subpartition ' || SUBPARTITION_NAME ||';' from dba_IND_subPARTITIONS
where INDEX_OWNER ='CRDW_REL1'
and status ='UNUSABLE';

###
###As with B-Tree indexes, IOTs can become fragmented and may need to be rebuilt. If the IOT has no overflow it can be rebuilt offline or online.

ALTER TABLE table_name MOVE INITRANS 10;
ALTER TABLE table_name MOVE ONLINE INITRANS 10;

###If the IOT does have overflow it can only be rebuilt offline.

ALTER TABLE table_name MOVE TABLESPACE iot_tablespace OVERFLOW TABLESPACE overflow_tablespace;

--------------------------------------------------------------

### tunel in tunel

1. Start Putty and in hostname type saijmpp2.omc.hp.com and press "Open"(this is 1st putty window)
2. When you login type top and press enter(this will run top and prevent the server to timeout your connection :) )
3. Open Putty settings and in Connection->SSH->Tunels make a local tunel -> L6666 15.171.0.114:22
4. Open new Putty(this is 2nd putty window)
5. In hostname type localhost and in port type 6666 and press "Open" (this will connect you through the tunel diretly to the DB server)
6. When you login type top and press enter(this will run top and prevent the server to timeout your connection :) )
7. Open Putty settings in the "2nd putty window" and there in Connection->SSH->Tunels make a local tunel -> L5500 15.171.0.114:5500
8. Then open your brouser and this is the link for the EM http://localhost:5500/em

### simple tunel through hop

1. Login to hop and -> ssh -L 5500:rptdwhp.tor.omc.hp.com:5500 rptdwhp.tor.omc.hp.com
2. Open properties
3. There in Connection->SSH->Tunels make a local tunel -> 5500 localhost:5500

--------------------------------------------------------------

If you have issue some times with datafile because of special characters in the name of the file
 
## when you grep for the file is missing:)

root@hx000132: /oradata/AGCDFRR1/group03 # ls -la | grep temp_tt23.dbf

## when you check with ll showing exact name
oot@hx000132: /oradata/AGCDFRR1/group03 # ll
total 289158496
-rw-r-----   1 oracle     dba        2097160192 Apr 12 14:01 temp_tt23.dbf

So how to indentify the exact name :)
 
ls -la > test
root@hx000132: /oradata/AGCDFRR1/group03 # ls -la > test
 
root@hx000132: /oradata/AGCDFRR1/group03 # vi test
"test" 71 lines, 5548 characters
total 289158514
-rw-r-----   1 oracle     dba        2097160192 Apr 12 14:01 temp_tt23.Dbf^?^?^?dbf

This is very nice workaround how to indentify the name :)

--------------------------------------------------------------

### create restore point georgi guarantee flashback database;

### select to_char(SCN),DATABASE_INCARNATION#,STORAGE_SIZE,GUARANTEE_FLASHBACK_DATABASE,RESTORE_POINT_TIME ,name from  v$restore_point;

--------------------------------------------------------------

### SCN to DATE TIMESTAMP and DATE TIMESTAMP to SCN

SQL> select scn_to_timestamp(884871) as timestamp from dual;
SQL> select timestamp_to_scn(to_timestamp('23/10/2010 23:51:00','DD/MM/YYYY HH24:MI:SS')) as scn from dual;


--------------------------------------------------------------

### to identify if you are hitting Base BUG# 6931689 go to $ORACLE_HOME/log//racg/*imon* <<< Notice the RDBMS_HOME, not CRS 
### there are log files for every cluster resource along with special*.imon file. These files have main purpose to provide instance health check monitoring. 
### a process called racgimon is writing data in those *.imon logs 
### basically search for line in the *.imon logs containing: 
2010-09-03 16:39:37.000: [ RACG][22] [9873][22][ora.OVACS1DG.OVACS1DG1.inst]: GIMH: GIM-00104: Health check failed to connect to instance. GIM-00090: OS-dependent operation:mmap failed with status: 12 GIM-00091: OS failure message: Not enough space GIM-00092: OS failure occurred at: sskgmsmr_13 .. 
### than you further complete the following check: 
root@irac05 # ps -ef | grep imon 
oracle 19561 1 0 10:18:43 ? 0:15 /u01/app/oracle/product/10.2.0/db1_cit/bin/racgimon startd SCITSTB oracle 15875 1 0 10:16:47 ? 0:10 /u01/app/oracle/product/10.2.0/db1_sc/bin/racgimon startd SCEMSTB 
#
root@irac05 # lsof +p 19561 | wc -l 
447
#
--------------------------------------------------------------

### put date in the filename:

cp recreate_user_HOXPCOR1.sql recreate_user_HOXPCOR1_backup_`date '+%Y-%m-%d'`.sql

--------------------------------------------------------------

### datapump data pump troubleshooting

Metalink Note ID 1264715.1

--------------------------------------------------------------

### porformance and tunning

Using the v$workarea views in Oracle9i
Oracle also has two new views to show active work area space, the v$sql_workarea and the v$sql_workarea_active views. The v$sql_workarea_active view will display all of the work areas that are currently executing in the instance. Note that small sorts (under 65,535 bytes) are excluded from the view, but you can use the v$sql_workarea_active view to quickly monitor the size of all large active work areas. 
select
   to_number(decode(SID, 65535, NULL, SID)) sid,
   operation_type              OPERATION,
   trunc(WORK_AREA_SIZE/1024)  WSIZE, 
   trunc(EXPECTED_SIZE/1024)   ESIZE,
   trunc(ACTUAL_MEM_USED/1024) MEM, 
   trunc(MAX_MEM_USED/1024)    "MAX MEM", 
   number_passes               PASS
from
   v$sql_workarea_active
order by
   1,2;
Here is a sample listing from this script.
SID OPERATION             WSIZE     ESIZE       MEM   MAX MEM PASS
--- --------------------- ----- --------- --------- --------- ----
 27 GROUP BY (SORT)          73        73        64        64    0
 44 HASH-JOIN              3148      3147      2437      6342    1
 71 HASH-JOIN             13241     19200     12884     34684    1
This output above shows that session 44 is running a hash-join whose work area is running in one-pass mode. This work area is currently using 2 megabytes of PGA memory and has used in the past up to 6.5 megabytes of PGA memory. 
This view is very useful for viewing the current memory operations within Oracle, and you can use the SID column to join into the v$process and v$session views for additional information about each task.


---------

column name  format a30
column value format 999,999,999
select
   name, 
   value 
from
   v$pgastat
;
The output of this query might look like the following: 
NAME                                                   VALUE     
------------------------------------------------------ ----------
aggregate PGA auto target                             736,052,224
global memory bound                                        21,200
total expected memory                                     141,144
total PGA inuse                                        22,234,736
total PGA allocated                                    55,327,872
maximum PGA allocated                                  23,970,624
total PGA used for auto workareas                         262,144
maximum PGA used for auto workareas                     7,333,032
total PGA used for manual workareas                             0
maximum PGA used for manual workareas                           0
estimated PGA memory for optimal                          141,395
maximum PGA memory for optimal                        500,123,520
estimated PGA memory for one-pass                         534,144
maximum PGA memory for one-pass                        52,123,520
In the above display from v$pgastat we see the following statistics.
* Aggregate PGA auto target � This column gives the total amount of available memory for Oracle9i connections.  As we have already noted, this value is derived from the value on the init.ora parameter pga_aggregate_target.
* Global memory bound � This statistic measures the max size of a work area, and Oracle recommends that whenever this statistics drops below one megabyte, then you should increase the value of the pga_aggregate_target parameter.
* Total PGA allocated � This statistic display the high-water mark of all PGA memory usage on the database.  You should see this value approach the value of pga_aggregate_target as usage increases.
* Total PGA used for auto workareas � This statistic monitors RAM consumption or all connections that are running in automatic memory mode.  Remember, not all internal processes may use the automatic memory feature.  For example, Java and PL/SQL will allocate RAM memory, and this will not be counted in this statistic.  Hence, we can subtract value to the total PGA allocated to see the amount of memory used by connections and the RAM memory consumed by Java and PL/SQL.
* Estimated PGA memory for optimal/one-pass � This statistic estimates how much memory is required to execute all task connections RAM demands in optimal mode.  Remember, when Oracle9i experienced a memory shortage, he will invoke the multi-pass operation.  This statistics is critical for monitoring RAM consumption in Oracle9i, and most Oracle DBA�s will increase pga_aggregate_target to this value.


-------------


select
   name                                      profile, 
   cnt, 
   decode(total, 0, 0, round(cnt*100/total)) percentage
from 
   (
      select 
         name, 
         value cnt, 
         (sum(value) over ()) total
      from
         v$sysstat 
      where
         name like 'workarea exec%'
   );
The output of this query might look like the following: 
PROFILE                             CNT        PERCENTAGE
----------------------------------- ---------- ----------
workarea executions - optimal             5395         95
workarea executions - onepass              284          5
workarea executions - multipass              0          0
This output of this query is used to tell the DBA when to dynamically adjust pga_aggregate_target.  In general the value of pga_aggregate_target should be increased when multi-pass executions is greater than zero, and reduced whenever the optimal executions is 100%



-----------------------

##sga and sga free

select sum(bytes)/1024/1024 " SGA Free size in MB" from v$sgastat where name='free memory';
select sum(bytes)/1024/1024 " SGA size used in MB" from v$sgastat where name!='free memory';


### total PGA usage in MB
SELECT inst_id, sum(PGA_USED_MEM)/1024/1024 as "Total PGA usage in MB", sum(PGA_ALLOC_MEM)/1024/1024 as "Total PGA Alloc" from GV$PROCESS group by inst_id;


### General view of the PGA usage
SELECT PROGRAM, PGA_USED_MEM, PGA_ALLOC_MEM, PGA_FREEABLE_MEM, PGA_MAX_MEM FROM V$PROCESS;

col SPID for a10
col USERNAME for a15
col OSUSER for a15
col MACHINE for a20
set linesize 400
select vs.sid,vs.serial#,vp.spid,vs.username,status, vs.osuser,vs.machine,vs.program ,vp.pga_used_mem/1024/1024 "PGA Mb",
vp.pga_alloc_mem/1024/1024 "PGA alloc" from v$session vs, v$process vp where vs.paddr = vp.addr order by vp.pga_alloc_mem;

-----------------------

### memory usage PGA

set lines 110
col unm format a30 hea "USERNAME (SID,SERIAL#)"
col pus format 999,990.9 hea "PROC KB|USED"
col pal format 999,990.9 hea "PROC KB|MAX ALLOC"
col pgu format 99,999,990.9 hea "PGA KB|USED"
col pga format 99,999,990.9 hea "PGA KB|ALLOC"
col pgm format 99,999,990.9 hea "PGA KB|MAX MEM"

select
s.username||' ('||s.sid||','||s.serial#||')' unm,
round((sum(m.used)/1024),1) pus,
round((sum(m.max_allocated)/1024),1) pal,
round((sum(p.pga_used_mem)/1024),1) pgu,
round((sum(p.pga_alloc_mem)/1024),1) pga,
round((sum(p.pga_max_mem)/1024),1) pgm
from v$process_memory m, v$session s, v$process p 
where m.serial# = p.serial# and p.pid = m.pid and p.addr=s.paddr and
s.username is not null group by s.username, s.sid, s.serial# order by unm;

-------------------------------
### memory usage PGA

set lines 400
col unm format a30 hea "USERNAME"
col pus format 99,999,990.9 hea "PROC KB|USED"
col pal format 99,999,990.9 hea "PROC KB|MAX ALLOCATED"
col pgu format 99,999,990.9 hea "PGA KB|USED"
col pga format 99,999,990.9 hea "PGA KB|ALLOC"
col pgm format 99,999,990.9 hea "PGA KB|MAX MEM"

select
s.INST_ID,
s.username unm,
round((sum(m.used)/1024),1) pus,
round((sum(m.max_allocated)/1024),1) pal,
round((sum(p.pga_used_mem)/1024),1) pgu,
round((sum(p.pga_alloc_mem)/1024),1) pga,
round((sum(p.pga_max_mem)/1024),1) pgm
from gv$process_memory m, gv$session s, gv$process p 
where m.serial# = p.serial# and p.pid = m.pid and p.addr=s.paddr  and s.INST_ID=p.INST_ID and p.INST_ID=m.INST_ID
group by  s.username, s.INST_ID
order by s.INST_ID, pga;

-----------------------------

### memory usage PGA with sid and serial

col "session Username" for a40
set linesize 400
select
p.INST_ID,round((sum(p.PGA_ALLOC_MEM)/1024/1024),1) as "##Sum of PGA alloc im MB##",
round((sum(p.PGA_USED_MEM)/1024/1024),1) as "##Sum of PGA used im MB##",
round((sum(m.used)/1024),1) as "PROC KB|USED",
s.username||' ('||s.sid||','||s.serial#||')' unm
from v$process_memory m, gv$session s, GV$PROCESS p where p.addr=s.paddr and p.pid = m.pid
group by p.INST_ID,s.username,s.sid,s.serial# order by p.INST_ID,SUM(P.PGA_ALLOC_MEM);

-----------------------------

### memory usage PGA no sid, no serial

col "session Username" for a40
set linesize 400
select
p.INST_ID,round((sum(p.PGA_ALLOC_MEM)/1024/1024),1) as "##PGA alloc im MB##",
round((sum(p.PGA_USED_MEM)/1024/1024),1) as "##PGA used im MB##",
round((sum(m.used)/1024/1024),1) as "PROC MB|USED",
s.username
from v$process_memory m, gv$session s, GV$PROCESS p where p.addr=s.paddr and p.pid = m.pid
group by p.INST_ID,s.username order by p.INST_ID,SUM(P.PGA_ALLOC_MEM);

-----------------------------

### fix crs_stat output - cool

#!/usr/bin/ksh
#
# Sample 10g CRS resource status query script
#
# Description:
#    - Returns formatted version of crs_stat -t, in tabular
#      format, with the complete rsc names and filtering keywords
#   - The argument, $RSC_KEY, is optional and if passed to the script, will
#     limit the output to HA resources whose names match $RSC_KEY.
# Requirements:
#   - $ORA_CRS_HOME should be set in your environment 

RSC_KEY=$1
QSTAT=-u
AWK=/usr/bin/awk    # if not available use /usr/xpg4/bin/awk

# Table header:echo ""
$AWK \
  'BEGIN {printf "%-45s %-10s %-18s\n", "HA Resource", "Target", "State";
          printf "%-45s %-10s %-18s\n", "-----------", "------", "-----";}'

# Table body:
$CRS_HOME/bin/crs_stat $QSTAT | $AWK \
 'BEGIN { FS="="; state = 0; }
  $1~/NAME/ && $2~/'$RSC_KEY'/ {appname = $2; state=1};
  state == 0 {next;}
  $1~/TARGET/ && state == 1 {apptarget = $2; state=2;}
  $1~/STATE/ && state == 2 {appstate = $2; state=3;}
  state == 3 {printf "%-45s %-10s %-18s\n", appname, apptarget, appstate; state=0;}'

-----------------------------

### rac crs services startup sequesnce

The starting sequence should be vip->asm->inst->lsnr->ons->gsd->DB. Start these services on orarac1 step by step manually.

-----------------------------

### flash recovery area

set lines 400
select * from v$flash_recovery_area_usage;
show parameter db_rec

select * from v$restore_point;
GRP - restore point
-----------------------------

### TEMP usage and what is executing

col SQL_TEXT for a80 
col TABLESPACE for a10 
SELECT   S.sid || ',' || S.serial# sid_serial, S.username, 
         T.blocks * TBS.block_size / 1024 / 1024 mb_used, T.tablespace, 
         T.sqladdr address, Q.hash_value, Q.sql_text 
FROM     v$sort_usage T, v$session S, v$sqlarea Q, dba_tablespaces TBS 
WHERE    T.session_addr = S.saddr 
AND      T.sqladdr = Q.address (+) 
AND      T.tablespace = TBS.tablespace_name 
ORDER BY S.sid;

-----------------------------

###Crsctl Stop Crs and Crsctl Stop Crs -f May Fail When Crsd Fails to Start [ID 954091.1]

    * Either kill these processes: 'ohasd|gipcd|mdnsd|gpnpd|evmd|crsd'
    * Or reboot the node 
for i in `ps -ef | egrep 'ohasd|gipcd|mdnsd|gpnpd|evmd|crsd' | grep -v grep |awk '{print $2}'`;do echo "kill -9 "$i; done;



/opt/grid/clusterware/11.2.0.2/grid/bin/crsctl stop crs
/opt/grid/clusterware/11.2.0.2/grid/bin/crsctl disable crs
If for some bug crs cannot stop one one of the nodes because of acfs filesystem, clean the socket files and reboot the node.
rm -rf /var/tmp/.oracle
rm -rf /tmp/.oracle


-----------------------------

###360962.1 Manual Completion of a Failed RMAN Duplicate, block by block
  
-----------------------------

###Environment Variables used by Oracle
ORACLE_BASE=/opt/oracle
ORACLE_SID=ORASID
ORACLE_HOME=${ORACLE_BASE}/product/10.2.0.1.db
ORA_CRS_HOME=${ORACLE_BASE}/product/10.2.0.1.crs
ORA_TZFILE=${ORACLE_HOME}/oracore/zoneinfo/timezone.dat
ORA_NLS10=${ORACLE_HOME}/nls/data
ORA_NLS33=${ORACLE_HOME}/ocommon/nls/admin/data
NLS_LANG=AMERICAN_AMERICA.WE8ISO8859P15
TNS_ADMIN=$ORACLE_BASE/admin/network
CLASSPATH must include the following JRE locations:
CLASSPATH=$ORACLE_HOME/JRE:$ORACLE_HOME/jlib:
$ORACLE_HOME/rdbms/jlib:$ORACLE_HOME/network/jlib

-----------------------------

Database buffer cache can be dynamically resized to grow
or shrink using ALTER SYSTEM.
� DB_CACHE_ADVICE can be set to gather statistics for
predicting different cache size behavior.
ALTER SYSTEM SET DB_CACHE_SIZE = 96M;

-----------------------------

###Extent Deallocation (2 of 2)
� What Happens When the Extents Are Deallocated?
� A DBA can deallocate unused extents using the following SQL
syntax:
� ALTER TABLE table_name DEALLOCATE UNUSED;

-----------------------------

### how to shrink table - possible performance issues!!!

The Oracle 10g segment advisor will recommend tables that will benefit from shrinking and indexes that require rebuilding (to reclaim space).

SQL> alter table mytable enable row movement;
Table altered

SQL> alter table mytable shrink space;
Table altered

alter table t1 disable row movement ;

###If you run ADDM, the segment advisor will tell you which tables can benefit from shrinking. You can read the advice from the latest run by running the following query:

select * from
table(dbms_space.asa_recommendations('FALSE', 'FALSE', 'FALSE'))
order by reclaimable_space desc

###I tried shrinking a table on my test machine, just to make sure the process is clear:

create table t1 (x number);

begin
for i in 1..1000000 loop
insert into t1 values (i);
end loop;
commit;
end;

select (count(*)*52428800)/1024/1024 from v$log_history --> 1050 (it was 800 before the inserts)

delete from t1 where mod(x,2)=0 --deleting half the rows in the table

select (count(*)*52428800)/1024/1024 from v$log_history --> 1200

select count(*) from t1;

--auto trace shows: consistent gets 1640

alter table t1 enable row movement ;
alter table t1 shrink space cascade;
alter table t1 disable row movement ;

select (count(*)*52428800)/1024/1024 from v$log_history --> 1300

select count(*) from t1;

--auto trace shows: consistent gets 837

-----------------------------

###Shrinking a Locally Managed Temporary Tablespace

Large sort operations performed by the database may result in a temporary tablespace growing and occupying a considerable amount of disk space. After the sort operation completes, the extra space is not released; it is just marked as free and available for reuse. Therefore, a single large sort operation might result in a large amount of allocated temporary space that remains unused after the sort operation is complete. For this reason, the database enables you to shrink locally managed temporary tablespaces and release unused space.

You use the SHRINK SPACE clause of the ALTER TABLESPACE statement to shrink a temporary tablespace, or the SHRINK TEMPFILE clause of the ALTER TABLESPACE statement to shrink a specific tempfile of a temporary tablespace. Shrinking frees as much space as possible while maintaining the other attributes of the tablespace or tempfile. The optional KEEP clause defines a minimum size for the tablespace or tempfile.

Shrinking is an online operation, which means that user sessions can continue to allocate sort extents if needed, and already-running queries are not affected.

The following example shrinks the locally managed temporary tablespace lmtmp1 to a size of 20M.

ALTER TABLESPACE lmtemp1 SHRINK SPACE KEEP 20M;

The following example shrinks the tempfile lmtemp02.dbf of the locally managed temporary tablespace lmtmp2. Because the KEEP clause is omitted, the database attempts to shrink the tempfile to the minimum possible size.

ALTER TABLESPACE lmtemp2 SHRINK TEMPFILE '/u02/oracle/data/lmtemp02.dbf';

-----------------------------

adrci> PURGE -age 1440 -type ALERT


3)  As oracle software user purge trace and alert information using ADRCI utility:

su - ora11g

adrci exec="set homepath diag/rdbms/rcat11g/RCAT11G;purge -age 7200 -type TRACE"
adrci exec="set homepath diag/rdbms/rcat11g/RCAT11G;purge -age 7200 -type ALERT"
adrci exec="set homepath diag/tnslsnr/grpesp05/listener;purge -age 7200 -type TRACE"
adrci exec="set homepath diag/tnslsnr/grpesp05/listener;purge -age 7200 -type ALERT"
adrci exec="set homepath diag/tnslsnr/grpesp05/listener_11g;purge -age 7200 -type TRACE"
adrci exec="set homepath diag/tnslsnr/grpesp05/listener_11g;purge -age 7200 -type ALERT"



-----------------------------

###audit TAP TAS to csv excel

root@natsci342:/oracle/TAP> cat audit_ibmtasdba.sql
set echo off pagesize 0 head off feed off veri off trimspool on linesize 999
spool audit_ibmtasdba.csv
select ID || ',' || KEY  || ',' || VALUE || ',' ||  CATEGORY || ',' || COLLEAGUE_ID || ',' || INTERNAL_ORG_ID || ',' || CREATED_BY || ',' || CREATED_DATE  || ',' || CHANGED_BY|| ',' || CHANGED_DATE || ',' || TYPE_ID  || ',' || LEVEL_ID 
from "CISADM"."APP_SETTING" 
WHERE key = 'InvalidCandidateDeletion'
  And Internal_Org_Id = '176AD352133AA649918442B3A639D9B8'; 
spool off
root@natsci342:/oracle/TAP>


 ID                                                                                                                                                                            NOT NULL RAW(16)
 KEY                                                                                                                                                                           NOT NULL VARCHAR2(300 CHAR)
 VALUE                                                                                                                                                                         NOT NULL NCLOB
 CATEGORY                                                                                                                                                                               NVARCHAR2(100)
 COLLEAGUE_ID                                                                                                                                                                           RAW(16)
 INTERNAL_ORG_ID                                                                                                                                                                        RAW(16)
 CREATED_BY                                                                                                                                                                    NOT NULL VARCHAR2(50 CHAR)
 CREATED_DATE                                                                                                                                                                  NOT NULL DATE
 CHANGED_BY                                                                                                                                                                    NOT NULL VARCHAR2(50 CHAR)
 CHANGED_DATE                                                                                                                                                                  NOT NULL DATE
 TYPE_ID                                                                                                                                                                                VARCHAR2(100 CHAR)
 LEVEL_ID                                                                                                                                                                               VARCHAR2(100 CHAR)



###Verify user equivalence by running the ssh command on the local node with the date command argument using the following syntax:

ssh node_name date
ssh node_name xclock


The output from these commands should be the timestamp of the remote node identified by the value that you use for node_name. In additionally, the system should display the remote node's xclock. When you run these commands, you should not see any other errors, warnings, or additional output. If ssh is in the /usr/local/bin directory, then use ssh to configure user equivalence.

The OUI cannot use ssh to verify user equivalence if ssh is in another location in your PATH. In this case, use rsh to confirm user equivalence.

-----------------------------

###The following steps are required to trace a user session with oradebug: 
1.   Obtain the SPID from v$process.   

col username for a15
col machine for a20
col program for a30
SELECT a.LOGON_TIME, a.inst_id, a.username, a.program, a.machine, a.osuser, a.sid, a.SERIAL#, b.spid
FROM   gv$session a, gv$process b
WHERE  a.paddr = b.addr
AND   a.username IS NOT null
and a.inst_id=b.inst_id
order by LOGON_TIME;

2.   Start the debug session with the SPID of the process that needs traced.
SQL> oradebug setospid 2280
SQL> oradebug unlimit
3.   Select the appropriate trace level.  There are four different options when specifying a tracing level:
�     Level 1 � provides �base set� tracing information.  Bind variables are displayed as variables (:b1). 
�     Level 4 � provides Level 1 data and the actual data values of bind variables.  
�     Level 8 � provides Level 1 data and information on wait events when the elapsed time is greater than the CPU time. 
�     Level 12 � combines levels 1, 4 and 8 tracing information.  A Level 12 trace contains base set, bind variable values and wait events.
The oradebug command below will enable the maximum tracing possible: 
SQL> oradebug event 10046 trace name context forever, level 12
1.   Turn tracing off.
SQL> oradebug event 10046 trace name context off
2.   Obtain the trace file name.  The oradebug facility provides an easy way to obtain the file name:   
SQL> oradebug tracefile_name

c:\oracle9i\admin\ORCL92\udump\mooracle_ora_2280.trc

-----------------------------

###With the Oracle 10g import utility, you can use a network connection so that you can directly import either a single or multiple table(s) from one server to another. Here are the steps you need to perform in order to import a table or tables from one server to another. First, assume that you have two servers, Server A and Server B, and you want to import a table or tables such as "EMP" and "DEPT" from server "A" to "B."

1. Go to Server B and create a database link that will access the database in Server A.
Example:
SQL> CREATE DATABASE LINK mylink2a CONNECT TO scott IDENTIFIED BY password USING 'mylink2a';
Note that 'scott' is a user in the database in Server "A" and that its password is 'password'.

2. Then, perform the following import dump command.
Example:
# impdp scott2/password2 TABLES=emp,dept DIRECTORY=dpump1 NETWORK_LINK=mylink2a
Note that 'scott2' is a user in the database in Server B and that its password is 'password2'.

-----------------------------

###redo generation per day
SELECT  TRUNC(FIRST_TIME), ROUND(SUM(BLOCK_SIZE  * NVL(BLOCKS ,BLOCKS))/1024/1024) MB_size 
from v$archived_log 
where FIRST_TIME between trunc(sysdate-3) and sysdate 
GROUP BY TRUNC(FIRST_TIME) 
order by 1 
/



-----------------------------

###monitor the RMAN sbt events, you can run the following SQL query:

COLUMN EVENT FORMAT a10
COLUMN SECONDS_IN_WAIT FORMAT 999
COLUMN STATE FORMAT a20
COLUMN CLIENT_INFO FORMAT a30

SELECT p.SPID, s.EVENT, s.SECONDS_IN_WAIT AS SEC_WAIT, 
       s.STATE, s.CLIENT_INFO
FROM V$SESSION_WAIT sw, V$SESSION s, V$PROCESS p
WHERE lower(sw.EVENT) LIKE 'sbt%'
AND s.SID=sw.SID
AND s.PADDR=p.ADDR
/


Examine the SQL output to determine which sbt functions are waiting. For example, the following output indicates that RMAN has been waiting for the sbtbackup function to return for ten minutes:

SPID EVENT        SEC_WAIT STATE                CLIENT_INFO
---- ---------- ---------- -------------------- ------------------------------
8642 sbtbackup         600 WAITING              rman channel=ORA_SBT_TAPE_1

-----------------------------
###rollback time, used undo segments

col username for a9
SELECT a.sid, a.username, b.xidusn "seg_name", b.xidslot "slot", b.xidsqn "sequence_n", b.used_urec "us_records", b.used_ublk "us_blocks",
round((select value from v$parameter where name='db_block_size')*b.used_ublk/1024/1024,2) "used MB", b.status,
b.START_TIME,to_char(a.logon_time, 'YYYY/MM/DD HH24:MI:SS') "logon time"
FROM v$session a, v$transaction b
WHERE a.saddr = b.ses_addr;

--How long will it take to rollback a transaction? (Oracle 9.x) 
--If the database has been restarted in 9i, there is an easier way to determine the number of undo blocks required for rollback by using the following query:

SELECT DISTINCT ktuxesiz FROM x$ktuxe;

SELECT KTUXEUSN,KTUXESLT,KTUXESQN,ktuxesiz FROM x$ktuxe
where KTUXEUSN=49
and KTUXESLT=18
and KTUXESQN=3884;
  
  Comments on a few of the v$transaction columns:
  --------------------------------
  XIDUSN          Rollback Segment ID       }  Transaction ID is
  XIDSLOT         Slot in RBS TX table      }   USN.SLOT.SQN or
  XIDSQN          Wrap of the entry         }  TX-USNxSLOT-SQNxxxxx

  UBAFIL          File for last undo entry  }  Tail end of UNDO for
  UBABLK          Block for last undo entry }  this transaction
  UBASQN          Sequence no of last entry }
  UBAREC          Record no in the block    }


  
--If the database HAS been shutdown and restarted. 
--If the database has been shutdown (abort) and restarted, the information in v$transaction is reset and is not useful.To find out how
--long the rollback will take, dump the rollback segment header to find the number of undo blocks.Take two segment header dumps,
--calculate the number of undo blocks rolled back during the time interval, and then calculate how long to roll back the entire transaction. 
--If the database has been restarted it will be difficult to tell which rollback segment was being used so you will
--need to dump all the rollback segment headers initially. 
--To dump the file headers, first determine which block stores the file header. 


SELECT segment_name, header_file, header_block
FROM dba_segments
WHERE segment_type='ROLLBACK';

  SEGMENT_NAME    HEADER_FILE HEADER_BLOCK
  --------------- ----------- ------------
  SYSTEM                    1            2
  RBS0                      2            2
  RBS1                      2          514
  RBS2                      2         1026
  RBS3                      2         1538
--Next, issue the following command in 8.x+ to dump the file header. 

alter system dump datafile 2 block 1026;

--This will generate a dump file in user_dump_dest. In the dump file look for the transaction table for the rollback segment. There will be a column called nub which holds the number of undo blocks for the transaction. 
-- Trace file snippet follows:

  index  state cflags  wrap#    uel         scn            dba            parent-xid    nub
  ------------------------------------------------------------------------------------------------
   0x00   10    0xc0  0x1995  0x0007  0x0000.009dd0ac  0x00800193  0x0000.000.00000000  0x00000052
   0x01    9    0x80  0x1994  0x003c  0x0000.009dd007  0x00801f3f  0x0000.000.00000000  0x00000001
Notice that the first slot holds an uncommitted transaction (state=10) and the nub (number undo blocks) = 0x52 or decimal 82. 



### rollback estimation - when will it finish

set serveroutput on
set echo on
DECLARE CURSOR tx IS
SELECT /*+ USE_NL(S,T,X) */ NVL (s.username,'session no more exists or running on the other node of RAC'),x.ktuxeusn,x.ktuxeslt,x.ktuxesqn,x.ktuxesiz
FROM ((sys.x$ktuxe x LEFT JOIN sys.gv_$transaction t ON t.xidusn = x.ktuxeusn AND t.xidslot = x.ktuxeslt AND t.xidsqn = x.ktuxesqn AND
x.inst_id = t.inst_id) LEFT JOIN sys.gv_$session s ON s.saddr = t.ses_addr AND s.inst_id = t.inst_id) WHERE x.ktuxesta = 'ACTIVE' AND x.ktuxesiz > 1;
user_name VARCHAR2 (80); xid_usn NUMBER; xid_slot NUMBER; xid_sqn NUMBER; used_ublk1 NUMBER; used_ublk2 NUMBER; BEGIN OPEN tx; LOOP FETCH tx
INTO user_name, xid_usn, xid_slot, xid_sqn, used_ublk1; EXIT WHEN tx%NOTFOUND; IF tx%ROWCOUNT = 1 THEN sys.DBMS_LOCK.sleep (50); SELECT SUM (ktuxesiz)
INTO used_ublk2 FROM sys.x$ktuxe WHERE ktuxeusn = xid_usn AND ktuxeslt = xid_slot AND ktuxesqn = xid_sqn AND ktuxesta = 'ACTIVE';
IF used_ublk2 < used_ublk1 THEN sys.DBMS_OUTPUT.put_line ('session (' || user_name || ')'); sys.DBMS_OUTPUT.put_line
( 'transaction '||xid_usn|| '.'||xid_slot||'.'||xid_sqn||' will finish rolling back at approximately '||TO_CHAR (SYSDATE+used_ublk2
/(used_ublk1 - used_ublk2)/30/24,'HH24:MI:SS DD-MON-YYYY')); END IF; END IF; END LOOP; IF user_name IS NULL THEN
sys.DBMS_OUTPUT.put_line ('No transactions appear to be rolling back.'); END IF; END;
/


### monitor export, RMAN v$session_longops

set linesize 400 pages 30
col TARGET for a21
col USERNAME for a10
col TARGET_DESC for a15
col "rem mins" for 9999.9 a8
col UNITS for a10
col TIME_REMAINING for a20
col START__TIME for a20
col LAST__UPDATE_TIME for a20
SELECT SID, SERIAL#,USERNAME, to_char(START_TIME, 'YYYY/MM/DD HH24:MI:SS') START__TIME,to_char(LAST_UPDATE_TIME,
'YYYY/MM/DD HH24:MI:SS') LAST__UPDATE_TIME,TIME_REMAINING/60 as "rem mins", TARGET, TARGET_DESC,SOFAR,
TOTALWORK, UNITS, ROUND(SOFAR/TOTALWORK*100,2) "%_COMPLETE" FROM GV$SESSION_LONGOPS WHERE TOTALWORK != 0 AND SOFAR <> TOTALWORK
--and sid='234'
order by START_TIME;

 ELAPSED_SECONDS CONTEXT MESSAGE USERNAME  
 


### failed RMAN backups - run with sys as sysdba
col START__TIME for a17
col END_TIME for a17
set lines 400 pages 100
col device for a8
col time_taken for a8
column TIME_TAKEN_DISPLAY format a40;
select command_id,TO_CHAR(start_time, 'MM/DD/YY HH24:MI:SS') as start__time,
TO_CHAR(end_time, 'MM/DD/YY HH24:MI:SS') as end_time, output_device_type as device,input_type,time_taken_display as time_taken,
status from V_$RMAN_BACKUP_JOB_DETAILS order by start_time;

### failed RMAN backups for all registered DBs - run from catalog user
set lines 160 pages 100
column time_taken for a10;
select db_name,command_id,TO_CHAR(start_time, 'MM/DD/YY HH24:MI:SS') as start_time,
TO_CHAR(end_time, 'MM/DD/YY HH24:MI:SS') as end_time, output_device_type as device,input_type,time_taken_display as time_taken,
status from RC_RMAN_BACKUP_JOB_DETAILS
where start_time > sysdate -10
--and INPUT_TYPE = 'DB INCR'
--and db_name in ('EPROD')
order by start_time;

### last RMAN backup for all registered DBs - run from catalog user
set lines 160 pages 100
column time_taken for a10;
select a.db_name,a.db_key,a.INPUT_TYPE,a.output_device_type as device,a.status,TO_CHAR(a.start_time, 'MM/DD/YY HH24:MI:SS') as start_time,time_taken_display as time_taken
from RC_RMAN_BACKUP_JOB_DETAILS a,
(select db_name,db_key,max(start_time) as max_stime from RC_RMAN_BACKUP_JOB_DETAILS where INPUT_TYPE = 'DB INCR' group by db_name,db_key) b
where a.start_time=b.max_stime
--and a.INPUT_TYPE = 'DB INCR'
--and a.db_name = 'FTEDM'
--and a.status = 'FAILED'
order by a.start_time;

### last RMAN full backup for all registered DBs with server name - run from catalog user
set lines 160 pages 100
column time_taken for a10;
col Server for a20
select
c.Server,a.db_name,a.db_key,a.INPUT_TYPE,a.output_device_type as device,a.status,TO_CHAR(a.start_time, 'MM/DD/YY HH24:MI:SS') as start_time,time_taken_display as time_taken
from 
RC_RMAN_BACKUP_JOB_DETAILS a,
(select db_name,db_key,max(start_time) as max_stime from RC_RMAN_BACKUP_JOB_DETAILS where INPUT_TYPE = 'DB INCR' group by db_name,db_key) b,
(SELECT distinct db_key,SUBSTR(tag,1,instr(tag,'_') -1) AS Server
	from bp where start_time in
	(SELECT MAX(start_time) FROM bp WHERE tag NOT LIKE 'TAG%' GROUP BY db_key)
	order by db_key
) c
where a.start_time=b.max_stime
and c.db_key=b.db_key
and a.INPUT_TYPE = 'DB INCR'
--and a.db_name = 'FTEDM'
--and a.status = 'FAILED'
order by a.start_time;


###NO_INCR_IN_2DAYS RMAN backup
SELECT e.db_name,
         SUBSTR(g.tag,1,instr(g.tag,'_') -1) AS Server
    FROM RMANUSER.dbinc e,
         RMANUSER.bp g
   WHERE g.db_key     = e.db_key
     AND db_name NOT IN --// To check against succesful backups
                        ( SELECT e.db_name
                            FROM RMANUSER.bs a,
                                 RMANUSER.db c,
                                 RMANUSER.dbinc e
                           WHERE a.db_key  = c.db_key
                             AND c.db_key  = e.db_key
                             AND a.bs_key IN
                                             (SELECT DISTINCT bs_key
                                                         FROM RMANUSER.bdf
                                             )
                                 --and a.bs_key in (select distinct bs_key from bcf)
                             AND a.completion_time > SYSDATE -2
                             AND a.bck_type        = 'D'
                        GROUP BY e.db_name,
                                 c.db_key,
                                 c.db_id,
                                 a.bck_type,
                                 a.incr_level,
                                 TRUNC(a.completion_time)
                        )
     AND e.dbinc_status     = 'CURRENT' --// The current Incarnation of the DB
     AND g.completion_time IN --// Select the latest tag from the backupset
                              ( SELECT MAX(completion_time)
                                  FROM RMANUSER.bp
                                 WHERE tag NOT LIKE 'TAG%'
                              GROUP BY db_key
                              )
     AND g.tag not like '%OFFLINE%'
GROUP BY e.db_name,
         g.tag
		 /

### NO_ARCH_IN_1DAY RMAN backup

SELECT e.db_name,
         g.tag
    FROM RMANUSER.dbinc e,
         RMANUSER.bp g,
         RMANUSER.bs w
   WHERE g.db_key     = e.db_key
     AND e.db_key     = w.db_key
     AND db_name NOT IN --// To check against succesful backups
                        ( SELECT e.db_name
                            FROM RMANUSER.bs a,
                                 RMANUSER.db c,
                                 RMANUSER.dbinc e
                           WHERE a.db_key  = c.db_key
                             AND c.db_key  = e.db_key
                             AND a.completion_time > sysdate - 1
                             AND a.bck_type        = 'L'
                        GROUP BY e.db_name,
                                 c.db_key,
                                 c.db_id,
                                 a.bck_type,
                                 a.incr_level,
                                 TRUNC(a.completion_time)
                        )					
     AND e.dbinc_status     = 'CURRENT' --// The current Incarnation of the DB
     AND g.completion_time IN --// Select the latest tag from the backupset
                              ( SELECT MAX(completion_time)
                                  FROM RMANUSER.bp
                                 WHERE tag NOT LIKE 'TAG%'
                              GROUP BY db_key
                              )
     AND w.bck_type = 'L'
GROUP BY e.db_name,
         g.tag
/ 
		 
###Query the RMAN catalog to list backup completion date/time
set lines 80
set pages 250
select DB NAME,dbid,NVL(TO_CHAR(max(backuptype_db),'DD/MM/YYYY HH24:MI'),'01/01/0001:00:00') DBBKP,
NVL(TO_CHAR(max(backuptype_arch),'DD/MM/YYYY HH24:MI'),'01/01/0001:00:00') ARCBKP
from (
select a.name DB,dbid,
decode(b.bck_type,'D',max(b.completion_time),'I', max(b.completion_time)) BACKUPTYPE_db,
decode(b.bck_type,'L',max(b.completion_time)) BACKUPTYPE_arch
from rc_database a,bs b
where a.db_key=b.db_key
and b.bck_type is not null
and b.bs_key not in(Select bs_key from rc_backup_controlfile where AUTOBACKUP_DATE
is not null or AUTOBACKUP_SEQUENCE is not null)
and b.bs_key not in(select bs_key from rc_backup_spfile)
group by a.name,dbid,b.bck_type
) group by db,dbid
ORDER BY least(to_date(DBBKP,'DD/MM/YYYY HH24:MI'),to_date(ARCBKP,'DD/MM/YYYY HH24:MI'))
/

---------------------------

####database backups and times to compleate - select from the recovery catalog

set pages 2000 lines 200
COL STATUS FORMAT a9
COL hrs FORMAT 999.99
select INPUT_BYTES/1024/1024/1024,SESSION_KEY,DB_NAME,INPUT_TYPE,TO_CHAR(START_TIME,'DDMonYY HH24') start_time,ELAPSED_SECONDS/3600 hrs from RC_RMAN_BACKUP_JOB_DETAILS
where trunc(start_time) >= to_date('06/21/2011' ,'mm/dd/yyyy') and INPUT_TYPE like 'DB%' and INPUT_BYTES/1024/1024/1024 > 200
order by DB_NAME,SESSION_KEY;

		 
---------------------------

###exp par file - export to several files with maxisze + tuning for fast export

userid="/ as sysdba" indexes=y grants=y constraints=n statistics=none RECORDLENGTH=64000 BUFFER=20000000
file=/data26/export/exp1.dmp,/data26/export/exp2.dmp,/data26/export/exp3.dmp
FILESIZE=8000M
LOG=/data26/export/exp_tseko.log
tables=(MANUMGR.ACCESSORIAL_MASTER,...)


###exp tuning for faster exports
Set the BUFFER parameter to a high value (e.g. 2Mb -- entered as an integer "2000000") 
Set the RECORDLENGTH parameter to a high value (e.g. 64Kb -- entered as an integer "64000") 


###Use the following technique if you use an Oracle version prior to 8i: 

###Create a compressed export on the fly. Depending on the type of data, you probably can export up to 10 gigabytes to a single file. This example uses gzip. It offers the best compression I know of, but you can also substitute it with zip, compress or whatever. 

# create a named pipe
mknod exp.pipe p
# read the pipe - output to zip file in the background
gzip -9 < exp.pipe > scott.exp.gz &
# feed the pipe
exp userid=scott/tiger file=exp.pipe ...
Import directly from a compressed export: 

# create a  name pipe
mknod imp_pipe p
# read the zip file and output to pipe
gunzip < exp_file.dmp.gz > imp_pipe &
# feed the pipe
imp system/pwd@sid file=imp_pipe log=imp_pipe.log ...
In case of low-performance system, it is better to add RECORDLENGTH parameter with tiny value to ensure that gzip has enough time to extract data before imp reads it: 

imp system/pwd@sid RECORDLENGTH=4096 file=imp_pipe log=imp_pipe.log ...

---------------------------

#Charset

select value from nls_database_parameters;

-----------------------------

#Logical Standby monitoring

�DBA_LOGSTDBY_EVENTS View

�DBA_LOGSTDBY_LOG View

�V$LOGSTDBY_STATS View

�V$LOGSTDBY_PROCESS View

�V$LOGSTDBY_PROGRESS View

�V$LOGSTDBY_STATE View

�V$LOGSTDBY_STATS View
#
set linesize 400
col EVENT for a70
col STATUS for a70
SELECT EVENT_TIME, STATUS, EVENT FROM DBA_LOGSTDBY_EVENTS
ORDER BY EVENT_TIMESTAMP, COMMIT_SCN;
#
set linesize 400
COL DICT_BEGIN FORMAT A10
col FILE_NAME for a60
SET NUMF 9999999999999
SELECT FILE_NAME, SEQUENCE# AS SEQ#, NEXT_CHANGE#, to_char(TIMESTAMP, 'YYYY/MM/DD HH24:MI:SS') as TIMESTAMP,
DICT_BEGIN AS BEG, DICT_END AS END, THREAD# AS THR#, APPLIED FROM DBA_LOGSTDBY_LOG
ORDER BY SEQUENCE#;

### check which sb logs can be deleted - logical standby
SQL> EXECUTE DBMS_LOGSTDBY.PURGE_SESSION; 
SQL> SELECT * FROM DBA_LOGMNR_PURGED_LOG; 



To start SQL Apply, start the logical standby database and issue the following statement:

SQL> ALTER DATABASE START LOGICAL STANDBY APPLY;

To start real-time apply on the logical standby database to immediately apply redo data from the standby redo log files on the logical standby database, include the IMMEDIATE keyword as shown in the following statement:

SQL>  ALTER DATABASE START LOGICAL STANDBY APPLY IMMEDIATE;

To stop SQL Apply, issue the following statement on the logical standby database:

SQL> ALTER DATABASE STOP LOGICAL STANDBY APPLY;

When you issue this statement, SQL Apply waits until it has committed all complete transactions that were in the process of being applied. Thus, this command may not stop the SQL Apply processes immediately.

If you want to stop SQL Apply immediately, issue the following statement:

SQL> ALTER DATABASE ABORT LOGICAL STANDBY APPLY;

---------------------------

### EOF

export ORACLE_SID=rcat
sqlplus -s / as sysdba <<-EOI
  shutdown immediate
  startup mount
  alter database archivelog;
  alter database open;
  quit
EOI
exit

---------------------------

###disable asynch io

  alter system set filesystemio_options = none scope = spfile;
  ALTER SYSTEM SET DISK_ASYNCH_IO = FALSE SCOPE=SPFILE;

---------------------------

###script to query V$BACKUP_DATAFILE to see how many of the blocks were read for creating the level 1 incremental backup

select file#, avg(datafile_blocks),
    avg(blocks_read),
    avg(blocks_read/datafile_blocks) * 100 as PCT_READ_FOR_BACKUP,
    avg(blocks)
  from v\$backup_datafile
  where used_change_tracking = 'YES'
    and incremental_level > 0
    group by file#;
	
	
---------------------------

###Dictionary Integrity Check - DictCheck
select dbms_hm.get_run_report('DictCheck') from dual; 

---------------------------

### Block corruption check - corrupted block
#check for physical/media corruption � where the contents of the block make no sense whatsoever; its contents don�t match the format expected by Oracle.
RMAN> BACKUP VALIDATE DATABASE;
#check for logical corruption � where the Oracle formatting is correct but the contents of the block are internally inconsistent.
RMAN> backup validate check logical database;
SQL> select * from v$database_block_corruption;
RMAN> blockrecover corruption list;

Note:28814.1



---------------------------

###ast_task_report.sh - text report for more in-depth information. How can you confirm that a SQL Profile was automatically implemented?
This shows you the execution statistics observed  during test-execute and allows you to get more of a feeling about the profile�s quality. 

#!/bin/bash
# For training only - execute as oracle OS user

sqlplus / as sysdba <<EOF!
set echo on
set long 1000000000
set longchunksize 1000
set serveroutput on

--
-- Check the execution names
--
alter session set nls_date_format = 'MM/DD/YYYY HH24:MI:SS';

select execution_name, status, execution_start
 from   dba_advisor_executions
 where  task_name = 'SYS_AUTO_SQL_TUNING_TASK'
 order by execution_start;

variable last_exec varchar2(30);

begin
  select max(execution_name) keep (dense_rank last order by execution_start)
  into   :last_exec
  from   dba_advisor_executions
  where  task_name = 'SYS_AUTO_SQL_TUNING_TASK';
end;
/

print :last_exec

--
-- Find the object ID for query AST with sql_id by9m5m597zh19
--
variable obj_id number;

begin
  select object_id
  into   :obj_id
  from   dba_advisor_objects
  where  task_name = 'SYS_AUTO_SQL_TUNING_TASK' and
         execution_name = :last_exec and
         type = 'SQL' and
         attr1 = 'by9m5m597zh19';
end;
/

print :obj_id

--
-- Get a text report to drill down on this one query
--
set pagesize 0
select dbms_sqltune.report_auto_tuning_task(
  :last_exec, :last_exec, 'TEXT', 'TYPICAL', 'ALL', :obj_id)
from dual;

EOF!


---------------------------

###Constraint
Check for the missing values into the parent table
You can identify the missing values with this query:

select  'select '||cc.column_name-
        ||' from '||c.owner||'.'||c.table_name-
        ||' a where not exists (select ''x'' from '-
        ||r.owner||'.'||r.table_name-
        ||' where '||rc.column_name||' = a.'||cc.column_name||')'
from    dba_constraints c,
        dba_constraints r,
        dba_cons_columns cc,
        dba_cons_columns rc
where   c.constraint_type = 'R'
and     c.owner not in ('SYS','SYSTEM') 			and     c.r_owner = r.owner
and     c.owner = cc.owner 							and     r.owner = rc.owner
and     c.constraint_name = cc.constraint_name 		and     r.constraint_name = rc.constraint_name
and     c.r_constraint_name = r.constraint_name 	and     cc.position = rc.position
and     c.owner = '&table_owner' 					and     c.table_name = '&table_name'
and     c.constraint_name = '&constraint_name'
/

select ORDER_LABEL_ID from ILA.ORDER_LABEL_SIZE a where not exists (select 'x' from ILA.ORDER_LABEL where ID = a.ORDER_LABEL_ID);

The output of this query is another query. Cut and paste the output back into sqlplus. The second query will list all of the values that are missing in the parent table. Obviously, it is only going to give you the values for one column, the column on which the tables are keyed, but it should help you to identify what has gone wrong.

---------------------------

###netbackup net backup - /usr/openv/netbackup/logs/user_ops/dbext/oracle

---------------------------

### dblink dblinks db_link db link

select * from dba_db_links;
set long 9000
SELECT DBMS_METADATA.GET_DDL('DB_LINK',a.db_link,a.owner) FROM dba_db_links a;

---------------------------

### kick logoff user from NT Domain

C:\Documents and Settings\Todor.Grigorov>quser /server deshmfaps001.de.saralee.com 
 USERNAME              SESSIONNAME        ID  STATE   IDLE TIME  LOGON TIME 
 install                                   0  Disc            .  5/10/2011 11:25 AM 
 julien.andonov                            1  Disc        none   5/10/2011 2:51 AM 
 todor.grigorov        rdp-tcp#42          2  Active          .  5/23/2011 1:03 PM 

C:\Documents and Settings\Todor.Grigorov>logoff 1 /server deshmfaps001.de.saralee.com 

---------------------------

### copy move from ASM to disk and disk to ASM

SQL> create directory abc1 as '+DATA/dbfiles';
SQL> create directory abc2 as '/u01/app/files';
SQL> begin
dmbs_file_ransfer.copy_file('abc1','tmp.dbf','abc2','tmp.dbf');
END;
/

---------------------------

DBA_SCHEDULER_SCHEDULES 
DBA_SCHEDULER_JOBS DBA_SCHEDULER_JOBS 

desc dba_scheduler_jobs;
select OWNER,JOB_NAME,JOB_ACTION,FAILURE_COUNT,to_char(LAST_START_DATE, 'YYYY/MM/DD HH24:MI:SS') as "LAST_START_DATE",
to_char(NEXT_RUN_DATE, 'YYYY/MM/DD HH24:MI:SS') as "NEXT_RUN_DATE",ENABLED from dba_scheduler_jobs;

--------------------------------------------------------------

## Procedure how to find and purge from the SYSAUX TABLESPACE the oldest snapshots;
-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
Check SYSAUX usage:
-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-

select occupant_desc,space_usage_kbytes/1024 space_mb, substr(schema_name,1,30) Schema from v$sysaux_occupants order by 2 desc;

col "Space (M)" for 999,999.99  
col OCCUPANT_NAME for a60
col MOVE_PROCEDURE for a40
set lines 200
SELECT occupant_name,round( space_usage_kbytes/1024) "Space (M)",schema_name,move_procedure
FROM v$sysaux_occupants  ORDER BY 1  
/ 

#### Check older and newer snapshot ids:
SELECT snap_id, begin_interval_time, end_interval_time FROM SYS.WRM$_SNAPSHOT WHERE snap_id = ( SELECT MIN (snap_id) FROM SYS.WRM$_SNAPSHOT) 
UNION
SELECT snap_id, begin_interval_time, end_interval_time FROM SYS.WRM$_SNAPSHOT WHERE snap_id = ( SELECT MAX (snap_id) FROM SYS.WRM$_SNAPSHOT)
/

SELECT snap_id, startup_time
FROM dba_hist_snapshot
ORDER BY 1,2;


### Purge a range of snapshot IDs to reclaim space in sysaux tablespace:
BEGIN                                                               
  dbms_workload_repository.drop_snapshot_range(low_snap_id => 12735, high_snap_id=>13000);                                         
END;
/

BEGIN                                                               
  dbms_workload_repository.drop_snapshot_range(13221,13222);                                         
END;
/
--------------------------------------------------

###Use the below command to know on which dates there was huge stats generation. sysaux
select trunc(SAVTIME),count(1),sum(sample_size)/1024/1024 "samp_size" from WRI$_OPTSTAT_HISTHEAD_HISTORY group by  trunc(SAVTIME) order by 1; 

--Start with oldest date and invoke below command
exec dbms_stats.purge_stats(to_date('01-JAN-2010','DD-MON-YYYY')); 

NOTE: Please note that this process is resource intensive. Do not perform in business hours.
--Once the amount of data comes down to a reasonable limit schedule it in off-peak hours, as a regular maintanance activity.
--Keep an eye on the amount of fragmentation and consider re-org process if needed.


--------------------------------------------------------------
###Procedure how to find and purge from the SYSAUX TABLESPACE
###segment size sysaux

col segment_name for a60
select * from 
(select owner,segment_name||'~'||partition_name segment_name,bytes/(1024*1024) size_m  
from dba_segments  
where tablespace_name = 'SYSAUX' 
ORDER BY BLOCKS desc)  
where rownum < 40  ;

###sysaux_occupants size
set linesize 120  
set pagesize 100
COLUMN "Item" FORMAT A25  
COLUMN "Space Used (GB)" FORMAT 999.99  
COLUMN "Schema" FORMAT A25  
COLUMN "Move Procedure" FORMAT A40  
SELECT  occupant_name "Item",  
space_usage_kbytes/1048576 "Space Used (GB)",  
schema_name "Schema",  
move_procedure "Move Procedure"  
FROM v$sysaux_occupants  
ORDER BY 1  
/ 

###How long old stats are kept

select dbms_stats.get_stats_history_retention from dual; 

###Set retention of old stats to 10 days

exec dbms_stats.alter_stats_history_retention(10); 

###Purge stats older than 10 days (best to do this in stages if there is a lot of data (sysdate-30,sydate-25 etc)

exec DBMS_STATS.PURGE_STATS(SYSDATE-88); 

###Show available stats that have not been purged

select dbms_stats.get_stats_history_availability from dual; 

###Show how big the tables are and rebuild after stats have been purged

col Mb form 9,999,999  
col SEGMENT_NAME form a40  
col SEGMENT_TYPE form a6  
set lines 120  
select sum(bytes/1024/1024) Mb, segment_name,segment_type from dba_segments  
where  tablespace_name = 'SYSAUX'  
and segment_name like 'WRI$_OPTSTAT%'  
and segment_type='TABLE'  
group by segment_name,segment_type order by 1 asc;

###Show how big the indexes are ready for a rebuild after stats have been purged

col Mb form 9,999,999  
col SEGMENT_NAME form a40  
col SEGMENT_TYPE form a6  
set lines 120  
select sum(bytes/1024/1024) Mb, segment_name,segment_type from dba_segments  
where  tablespace_name = 'SYSAUX'  
and segment_name like '%OPT%'  
and segment_type='INDEX'  
group by segment_name,segment_type order by 1 asc  
/ 

###Note that you cannot enable row movement and shrink the tables as the indexes are function based

alter table WRI$_OPTSTAT_IND_HISTORY enable row movement;  
alter table WRI$_OPTSTAT_IND_HISTORY shrink space;  
*  
ERROR at line 1:  
ORA-10631: SHRINK clause should not be specified for this object 

select 'alter table '||segment_name||'  move tablespace SYSAUX;' from dba_segments where tablespace_name = 'SYSAUX'  
and segment_name like '%OPT%' and segment_type='TABLE' 

###Run the rebuild table commands � note that this does cause any gather_stats jobs to fail

###Script to generate rebuild statements

select 'alter index '||INDEX_NAME||'  rebuild parallel (degree 2) initrans 10;' from dba_indexes where tablespace_name = 'SYSAUX'  
and INDEX_NAME like '%OPT%';

###Once completed it is best to check that the indexes (indices) are usable

select  di.index_name,di.index_type,di.status  from  dba_indexes di , dba_tables dt  
where  di.tablespace_name = 'SYSAUX'  
and dt.table_name = di.table_name  
and di.table_name like '%OPT%'  
order by 1 asc  
/ 

###Finally lets see what space has been saved with a retention date of 1 day and a gather schema stats for the SYSASDM schema

exec dbms_stats.alter_stats_history_retention(1);  
select dbms_stats.get_stats_history_retention from dual; 


--------------------------------------------------------------


# Validate the restore of the Hot Backup taken
#
echo "*********************************************************"
echo "Starting Validation of the backup                        "
echo "*********************************************************"
rman target $TARGETDB catalog $CATALOGDB<<eof
run {
ALLOCATE CHANNEL CH1 DEVICE TYPE DISK;
ALLOCATE CHANNEL CH2 DEVICE TYPE DISK;
ALLOCATE CHANNEL CH3 DEVICE TYPE DISK;
RESTORE CONTROLFILE TO '$backup_dir/VALIDATE_CTRL' FROM TAG='$TSTAMP' VALIDATE;
RESTORE DATABASE VALIDATE FROM TAG='$TSTAMP';
RESTORE ARCHIVELOG FROM SEQUENCE `cat $backup_dir/FROMSEQ` THREAD 1 VALIDATE;
}

--------------------------------------------------------------

exec dbms_service.start_service('EDOCFRE1XDB');

SQL> alter system shutdown immediate 'D001';
SQL> alter system set DISPATCHERS = '(protocol=tcp)(SERVICE=EDOCFRE1XDB)(dispatchers=3)';


--------------------------------------------------------------

determine the particular event application for which the sessions are waiting:

<        session_waits.sql
 
select   
   se.event,
   sum(se.total_waits),
   sum(se.total_timeouts),
   sum(se.time_waited/100) time_waited
from         
   v$session_event se, 
   v$session       sess
where 
   sess.username = 'SAPR3'
and 
   sess.sid = se.sid
group by 
   se.event  
order by 2 DESC;

--------------------------------------------------------------

### database gatherer stats info

#Catalog view DBA_OPTSTAT_OPERATIONS contain history of statistics operations performed at schema and database level using DBMS_STATS. 
#The views *_TAB_STATS_HISTORY views (ALL, DBA, or USER) contain a history of table statistics modifications.

col TARGET for a20
col OPERATION for a30
select OPERATION,TARGET,
to_char(START_TIME, 'YYYY/MM/DD HH24:MI:SS') START__TIME,
to_char(END_TIME, 'YYYY/MM/DD HH24:MI:SS') END_TIME 
from DBA_OPTSTAT_OPERATIONS order by START_TIME;

SELECT
   a.job_name,
   a.enabled,
   c.window_name,
   c.schedule_name,
   c.start_date,
   c.repeat_interval
FROM
   dba_scheduler_jobs             a,
   dba_scheduler_wingroup_members b,
   dba_scheduler_windows          c
WHERE
   job_name in ('GATHER_STATS_JOB','AUTO_SPACE_ADVISOR_JOB')
   and
     a.schedule_name=b.window_group_name
   and
     b.window_name=c.window_name;

#check running jobs
select * from dba_scheduler_running_jobs;
#
# identify program name for the stats

col PROGRAM_NAME for a30
col SCHEDULE_NAME for a30
select job_name, job_type, program_name, schedule_name, job_class from dba_scheduler_jobs where job_name = 'GATHER_STATS_JOB';

#The PROGRAM_NAME 'GATHER_STATS_PROG' starts the DBMS_STATS.GATHER_DATABASE_STATS_JOB_PROC stored procedure

col PROGRAM_ACTION for a70
select PROGRAM_ACTION from dba_scheduler_programs where PROGRAM_NAME = 'GATHER_STATS_PROG';

#The job is scheduled according to the value of the SCHEDULE_NAME field.
#In this example, the schedule being used is: 'MAINTENANCE_WINDOW_GROUP'.
#This schedule is defined in the DBA_SCHEDULER_WINGROUP_MEMBERS view

select * from DBA_SCHEDULER_WINGROUP_MEMBERS where WINDOW_GROUP_NAME = 'MAINTENANCE_WINDOW_GROUP';

#The meaning of these 'windows' can be found in 'DBA_SCHEDULER_WINDOWS':

col DURATION for a30
col REPEAT_INTERVAL for a80
select window_name, repeat_interval, duration from dba_scheduler_windows where window_name in 
('WEEKNIGHT_WINDOW','WEEKEND_WINDOW','MONDAY_WINDOW','TUESDAY_WINDOW','WEDNESDAY_WINDOW',
'THURSDAY_WINDOW','FRIDAY_WINDOW','SATURDAY_WINDOW','SUNDAY_WINDOW');

#heck the estimate_percent

select dbms_stats.get_param('estimate_percent') from dual;

#example index last analyzed date

select INDEX_NAME, PARTITION_NAME, SUBPARTITION_NAME, num_rows, to_char(last_analyzed,'YYYY/MM/DD HH24:MI:SS') last_analyzeda, stale_stats
from dba_ind_statistics
where owner='CRDW_REL1' and INDEX_NAME like 'XXIE%' and TABLE_NAME ='&tbl_name' order by last_analyzeda;

All these definitions can be found in the $ORACLE_HOME/rdbms/admin/catmwin.sql script.

RELATED DOCUMENTS

Oracle? Database Performance Tuning Guide
10g Release 2 (10.2)
Part Number B14211-01
Chapter 5 Automatic Performance Statistics

Note:228186.1 Differences between GATHER STALE and GATHER AUTO
Note:102334.1 How to Automate Change Based Statistic Gathering - Monitoring Tables
Note:311836.1 How to Disable Automatic Statistics Collection in 10g
Note.552568.1 How to Determine That GATHER_STATS_JOB Completed


--------------------------------------------------------------

### histograms

SELECT rownum num,column_name,type,len,precision,scale,histogram,buckets, nullok
         FROM (
               SELECT c.column_name,
                      c.data_type as type,
                      c.data_length as len,
                      c.data_precision as precision,
                      c.data_scale as scale,
                      c.histogram,
                      h.buckets,
                      c.nullable as nullok
               FROM dba_tab_columns c,
                    (SELECT owner,table_name,column_name,count(*) as buckets
                     FROM dba_histograms
                     WHERE owner='&&OWNERR' and
                           table_name='&&TABLEE'
                     GROUP BY owner,table_name,column_name ) h
               WHERE c.owner='&&OWNERR' and
                     c.table_name='&&TABLEE' and
                     c.table_name = h.table_name(+) and
                     c.column_name = h.column_name(+) and
                     c.owner = h.owner(+)
               ORDER BY c.column_id);


--------------------------------------------------------------

Wait Model Improvements
A number of views have been updated and added to improve the wait model. The updated views include the following.

�V$EVENT_NAME
�V$SESSION
�V$SESSION_WAIT
The new views include the following.

�V$ACTIVE_SESSION_HISTORY
�V$SESSION_WAIT_HISTORY
�V$SESS_TIME_MODEL
�V$SYS_TIME_MODEL
�V$SYSTEM_WAIT_CLASS
�V$SESSION_WAIT_CLASS
�V$EVENT_HISTOGRAM
�V$FILE_HISTOGRAM
�V$TEMP_HISTOGRAM
The following are some examples of how these updates can be used.

The V$EVENT_NAME view has had three new columns added (WAIT_CLASS_ID, WAIT_CLASS# and WAIT_CLASS) which indicate the class of the event. This allows easier aggregation of event details.

-- Display time waited for each wait class.
SELECT a.wait_class, sum(b.time_waited)/1000000 time_waited
FROM   v$event_name a
       JOIN v$system_event b ON a.name = b.event
GROUP BY a.wait_class;

WAIT_CLASS                  TIME_WAITED
--------------------------- -----------
Application                     .013388
Commit                          .003503
Concurrency                     .009891
Configuration                   .003489
Idle                         232.470445
Network                         .000432
Other                           .025698
System I/O                      .095651
User I/O                        .109552

9 rows selected.The V$SESSION view has had several columns added that include blocking session and wait information. The wait information means it's no longer necessary to join to V$SESSION_WAIT to get wait information for a session.

-- Display blocked session and their blocking session details.
SELECT sid, serial#, blocking_session_status, blocking_session
FROM   v$session
WHERE  blocking_session IS NOT NULL;

no rows selected

-- Display the resource or event the session is waiting for.
SELECT sid, serial#, event, (seconds_in_wait/1000000) seconds_in_wait
FROM   v$session
ORDER BY sid;

       SID    SERIAL# EVENT                               SECONDS_IN_WAIT
---------- ---------- ----------------------------------- ---------------
       131         20 SQL*Net message from client                 .000015
       133        501 wakeup time manager                         .000138
       134      28448 SQL*Net message to client                         0
       135          4 queue messages                              .000003
       137          8 SQL*Net message from client                 .000132
....
       167          1 rdbms ipc message                                 0
       168          1 rdbms ipc message                                 0
       169          1 rdbms ipc message                           .079485
       170          1 pmon timer                                  .092645

29 rows selected.The V$SESSION_WAIT_CLASS view allows you to see the session wait information broken down by wait class for each session.

-- Display session wait information by wait class.
SELECT *
FROM   v$session_wait_class
WHERE  sid = 134;

       SID    SERIAL# WAIT_CLASS_ID WAIT_CLASS# WAIT_CLASS          TOTAL_WAITS TIME_WAITED
---------- ---------- ------------- ----------- ------------------- ----------- -----------
       134      28448    4217450380           1 Application                   2           0
       134      28448    3875070507           4 Concurrency                   1           2
       134      28448    2723168908           6 Idle                         57      392127
       134      28448    2000153315           7 Network                      68           5

4 rows selected.The V$SESSION_WAIT_HISTORY view shows historical wait information which allows you to identify issues after the session has ended.


--------------------------------------------------------------

lsnrctl > set trc_level support
type C:\ORACLE\ora10g\network\trace\listener.trc | findstr �ntt2err�

--------------------------------------------------------------

###generate recreate script for dblinks (spool to a file)

spool dblinks.sql

set long 200 pagesize 200
SELECT 'CREATE '||DECODE(U.NAME,'PUBLIC','public ')||'DATABASE LINK '||CHR(10)
||DECODE(U.NAME,'PUBLIC',Null, 'SYS','',U.NAME||'.')|| L.NAME||chr(10)
||'CONNECT TO ' || L.USERID || ' IDENTIFIED BY "'||L.PASSWORD||'" USING 
'''||L.HOST||''''
||chr(10)||';' TEXT
FROM SYS.LINK$ L, SYS.USER$ U
WHERE L.OWNER# = U.USER#;
spool off

--------------------------------------------------------------

###sqlplus csv

set colsep ,     -- separate columns with a comma
set pagesize 0   -- only one header row
set trimspool on -- remove trailing blanks
set headsep off  -- this may or may not be useful...depends on your headings.
set linesize <XXX>   -- X should be the sum of the column widths
spool <myfile.csv> 

sql_script

spool off
..................



set pages  0
set lines 220
set feedback off
set truncate off
set verify off
set head off
set long 9999999
set pause off
set serveroutput off
set heading off
set trims on
set trim on
set tab off
set echo off
set colsep ,
set pagesize 0
set trimspool on
set headsep off
set linesize 8888

spool tseko1.csv 
...
spool off

--------------------------------------------------------------


### V$ACTIVE_SESSION_HISTORY - begining


select distinct SESSION_ID,SESSION_SERIAL#,blocking_session,
blocking_session_serial#
from V$ACTIVE_SESSION_HISTORY
where 1=1 and session_state = 'WAITING'
and event like '%TX%';

####Most Active SQL in the previous hour desc gv$active_session_history

SELECT sql_id,COUNT(*),ROUND(COUNT(*)/SUM(COUNT(*)) OVER(), 2) PCTLOAD
FROM gv$active_session_history
WHERE sample_time > SYSDATE - 1/24
AND session_type = 'BACKGROUND'
GROUP BY sql_id
ORDER BY COUNT(*) DESC;

SELECT sql_id,COUNT(*),ROUND(COUNT(*)/SUM(COUNT(*)) OVER(), 2) PCTLOAD
FROM gv$active_session_history
WHERE sample_time > SYSDATE - 1/24
AND session_type = 'FOREGROUND'
GROUP BY sql_id
ORDER BY COUNT(*) DESC; 


####Most Active I/O  SELECT DISTINCT wait_class

SELECT DISTINCT wait_class
FROM gv$event_name
ORDER BY 1;


SELECT sql_id, COUNT(*)
FROM gv$active_session_history ash, gv$event_name evt
WHERE ash.sample_time > SYSDATE - 1/24
AND ash.session_state = 'WAITING'
AND ash.event_id = evt.event_id
AND evt.wait_class = 'User I/O'
GROUP BY sql_id
ORDER BY COUNT(*) DESC;

set linesize 121

SELECT * FROM TABLE(dbms_xplan.display_cursor('gpv3kb4n2f2q1'));  



--------------------------------------------------------------

Select name from v$datafile;
Select name from v$tempfile;
Select member from v$logfile;
Select name from v$controlfile;

select sum(BYTES)/1024/1024 as SUM_DBF_usage from v$datafile;
select sum(BYTES)/1024/1024 as SUM_TMP_usage from v$tempfile;


--------------------------------------------------------------

### spool to HTML

SQLPLUS -S -M "HTML ON TABLE 'BORDER="2"'" HR/your_password@Ora9i 
@depart.sql>depart.html

--------------------------------------------------------------

###rman in backuground

nohup rman TARGET "sys/HK_68764"\@FIPSDEP0 NOCATALOG AUXILIARY "sys/HK_68764"\@FIPSDES1 msglog "restore_test.log" cmdfile "restore_test.txt" &

--------------------------------------------------------------


###Show me user sorts###
col username form a10 heading "DB User"
col osuser form a10 heading "OS User"
col name form a20 heading "Type Of Sort"
col tablespace form a10

SELECT s.username
                , s.sid
                , s.serial#
                , u.tablespace
                , u.contents
                , u.segtype
                , u.extents
                , u.blocks
FROM v$session s, v$sort_usage u
WHERE s.saddr = u.session_addr ;

SELECT  s.sid 
        ,s.username
        ,s.osuser
        ,vsn.name
        ,vss.value
FROM    v$session s,
        v$sesstat vss,
        v$statname vsn
WHERE   vss.statistic#=vsn.statistic#
AND     s.sid = vss.sid
AND     vsn.name like '%sort%'
AND     s.username is not null
ORDER BY s.username
/

--------------------------------------------------------------

### expdp windows script

if not exist "c:\local\outils\fp\fp_system.%ORACLE_SID%" goto ErreurFicInexistantFp
for /F "tokens=*" %%i in (c:\local\outils\fp\fp_system.%ORACLE_SID%) do @set PASSWD=%%i

rem Get the current date
for /F "tokens=6,7,8 delims=/ " %%i in ('D:\admin\AGSCFRP0\exp\recup_date.cmd') do @set DATERECUPERER=%%k%%i%%j

rem Get the current time
for /F "tokens=5,6,7 delims=: " %%i in ('D:\admin\AGSCFRP0\exp\recup_time.cmd') do @set TIMERECUPERER=%%iH%%jM%%kS

rem Generation of the dump file name

set FILE_EXP=%ORACLE_SID%_full_%DATERECUPERER%_%TIMERECUPERER%

rem Datapum export full start

expdp system/%PASSWD% DIRECTORY=DATA_PUMP DUMPFILE=%FILE_EXP%.dmp LOGFILE=%FILE_EXP%.LOG FULL=y

--------------------------------------------------------------

###Oracle logs in root FS
Root cause analysis is that when oracle database 11.1.0.6 or 11.1.0.7 is installed there is by default folder $ORACLE_HOME/log
but in this folder there is one subfolder which is missing and is needed for oracle clients. Needed folder is $ORACLE_HOME/log/diag/clients which should be created as oracle user.
When this folders is missing oracle clients creating ADR(Automatic Diagnostic Repository) structure in root home and start filling it with errors that cannot write and read to/from this folder.
At the moment filesystem is at 25% and there no more errors generated.
We can monitor for a few days the /root/home/root/oradiag_root/diag/clients/user_root/host_2157663133_11/trace/sqlnet.log and
/root/home/root/oradiag_root/diag/clients/user_root/host_2157663133_11/alert/log.xml if they will change their size from 0.

--------------------------------------------------------------


select
  lpad(' ', 2*level) || granted_role "User, his roles and privileges"
from
  (
  /* THE USERS */
    select null     grantee, username granted_role
    from dba_users
    where username like upper('%PR01%')
  /* THE ROLES TO ROLES RELATIONS */ 
  union
    select grantee, granted_role
    from dba_role_privs
  /* THE ROLES TO PRIVILEGE RELATIONS */ 
  union
    select grantee, privilege
    from dba_sys_privs
  )
start with grantee is null
connect by grantee = prior granted_role;


--------------------------------------------------------------


Rename datafile procedure
at 8:50 CET
###Lock users
alter user GSMCS account lock;
alter user GSMCSADMIN account lock;
alter user GSMCS_TIBSTG account lock;
alter user TIBCO account lock;

###Kill sessions
select 'alter system kill session ''' || sid || ',' || serial# || ''' immediate;'
from v$session
where username='GSMCS' or username='GSMCSADMIN' or username='GSMCS_TIBSTG' or username='TIBCO'; 

### Very carefully rename datafile
SQL>ALTER TABLESPACE GSMCD_TS OFFLINE NORMAL;
Check if operation is performed
du fuser on the datafile
fuser /oracle/OSLTP/oradata17/gsmcd_tsOLTP.dbf8
Rename the datafiles using the operating system.
mv /oracle/OSLTP/oradata17/gsmcd_tsOLTP.dbf8 /oracle/OLTP/oradata6/gsmcd_tsOLTP.dbf8
SQL>ALTER TABLESPACE GSMCD_TS RENAME DATAFILE '/oracle/OSLTP/oradata17/gsmcd_tsOLTP.dbf8' TO '/oracle/OLTP/oradata6/gsmcd_tsOLTP.dbf8'; 
SQL>ALTER TABLESPACE GSMCD_TS ONLINE;

--------------------------------------------------------------

exec DBMS_WORKLOAD_REPOSITORY.CREATE_SNAPSHOT();

--------------------------------------------------------------

#sqlplus script to quickly kill off all external sessions connecting to my oracle database without the supervision of and administrator
begin      
    for x in (   
            select Sid, Serial#, machine, program   
            from v$session   
            where   
                machine <> 'MyDatabaseServerName'   
        ) loop   
        execute immediate 'Alter System Kill Session '''|| x.Sid   
                     || ',' || x.Serial# || ''' IMMEDIATE';   
    end loop;   
end; 

--------------------------------------------------------------

###TABLESPCE GROWTH

SELECT TO_CHAR (sp.begin_interval_time,'YYYY-MM-DD') days 
, ts.tsname
, max(round((tsu.tablespace_size* dt.block_size )/(1024*1024),2) ) cur_size_MB
, max(round((tsu.tablespace_usedsize* dt.block_size )/(1024*1024),2)) usedsize_MB 
FROM DBA_HIST_TBSPC_SPACE_USAGE tsu, DBA_HIST_TABLESPACE_STAT ts 
, DBA_HIST_SNAPSHOT sp, DBA_TABLESPACES dt
WHERE tsu.tablespace_id= ts.ts#
AND tsu.snap_id = sp.snap_id AND ts.tsname = dt.tablespace_name
--AND ts.tsname = '&tablespace_name'
GROUP BY TO_CHAR (sp.begin_interval_time,'YYYY-MM-DD'), ts.tsname 
ORDER BY days; 

--------------------------------------------------------------

###DATABASE GROWTH

select days,sum(CUR_SIZE_MB) "CURENT SIZE MB ",sum(USEDSIZE_MB) "USED SIZE MB " from
(SELECT TO_CHAR (sp.begin_interval_time,'YYYY-MM-DD') days 
, ts.tsname
, max(round((tsu.tablespace_size* dt.block_size )/(1024*1024),2) ) cur_size_MB
, max(round((tsu.tablespace_usedsize* dt.block_size )/(1024*1024),2)) usedsize_MB 
FROM DBA_HIST_TBSPC_SPACE_USAGE tsu, DBA_HIST_TABLESPACE_STAT ts 
, DBA_HIST_SNAPSHOT sp, DBA_TABLESPACES dt
WHERE tsu.tablespace_id= ts.ts#
AND tsu.snap_id = sp.snap_id AND ts.tsname = dt.tablespace_name
GROUP BY  ts.tsname ,TO_CHAR(sp.begin_interval_time,'YYYY-MM-DD')
ORDER BY days)
group by days order by days;


--------------------------------------------------------------

###archive logs total size generated per day

select sum ((blocks+1)*BLOCK_SIZE)/1024/1024 as "MB_archlogs", to_char(COMPLETION_TIME, 'YYYY/MM/DD') as "DATE"
from v$archived_log where COMPLETION_TIME > sysdate-30 and DEST_ID =1 group by to_char(COMPLETION_TIME, 'YYYY/MM/DD')
order by to_char(COMPLETION_TIME, 'YYYY/MM/DD');


select sum(GB_USED_PER_DAY)/count(GB_USED_PER_DAY) from (SELECT
TO_CHAR(completion_time,'YYYY-MM-DD') completion_date,
round (SUM(block_size*(blocks+1)) / 1024 / 1024 / 1024 , 2) GB_USED_PER_DAY
FROM v$archived_log
WHERE TRUNC(completion_time) BETWEEN
TRUNC(SYSDATE-30) AND TRUNC(SYSDATE) 
GROUP BY TO_CHAR(completion_time,'YYYY-MM-DD')
order by 1 desc);


--------------------------------------------------------------

### prelim for max processes
sqlplus /nolog
set _prelim on
conn / as sysdba            

SQL> oradebug setmypid
Statement processed.
SQL> oradebug unlimit
Statement processed.
SQL> oradebug dump hanganalyze 1
Statement processed.
SQL> oradebug dump systemstate 10
Statement processed.
SQL> oradebug tracefile_name
/oracle/admin/diag/rdbms/demo11g/demo11g/trace/demo11g_ora_25010.trc

--------------------------------------------------------------

### nohup windows

Set LOGFILE=C:\tseko_test.tmp.log
Set ORACLE_SID=ovpi
:: creates script to START the DB
echo set echo on                  > C:\tseko_test.tmp
echo connect sys/dba as sysdba; >> C:\tseko_test.tmp
echo startup force;              >> C:\tseko_test.tmp
echo exit;                       >> C:\tseko_test.tmp

:: Execute the script that starts up the DB
echo "Starting the Oracle database -"  %date% - %time% >> %LOGFILE%
echo set PATH=%PATH%;C:\oracle\ora10g\bin
sqlplus /nolog @C:\tseko_test.tmp

:: Cleanup
del C:\tseko_test.tmp

--------------------------------------------------------------

###ORA-03113 Error When Executing Utlrp.sql - When UTL_RECOMP objects  are owned by two users, say one is SYS and another is SCOTT, in which the objects owned by SCOTT is invalid

- Check for UTL_RECOMP objects owner. 
SQL> select owner,object_name,object_type from dba_objects where object_name like 'UTL%'; 
- If those objects has two or more owner, one is SYS and another is SCOTT(for example). The UTL% objects should only be owned by SYS. 
- Drop the objects that are owned by scott (the user other than SYS). 
- If still the issue occurs, then conn as 'sys as sysdba' and execute 
SQL> @?/rdbms/admin/utlrcmp.sql 
which will create utl_recomp under SYS 
- then execute @?/rdbms/admin/utlrp.sql 
- To Check the status of the execution of utlrp.sql 
SQL> select count(*) from obj$ where status in (4,5,6); 
you can visualize the invalid objects count decreasing. 
-If still error occurs contact Oracle Support with alert log and result of the below queries: 
select owner,count(*),object_type from dba_objects where status='INVALID' group by owner,object_type; 
select owner,object_name,object_type from dba_objects where status='INVALID' order by owner; 
- Also upload alert log, to verify any ORA-07445 errors are resulted as a result of ORA-03113 and ORA-03114.


--------------------------------------------------------------

#### top SQL by Buffer Gets
select substr(sql_text,1,500) "SQL",(cpu_time/1000000) "CPU_Seconds",disk_reads "Disk_Reads",buffer_gets "Buffer_Gets",executions "Executions",
case when rows_processed = 0 then null else round((buffer_gets/nvl(replace(rows_processed,0,1),1))) end "Buffer_gets/rows_proc",
round((buffer_gets/nvl(replace(executions,0,1),1))) "Buffer_gets/executions",(elapsed_time/1000000) "Elapsed_Seconds",module "Module"
from v$sql s order by buffer_gets desc nulls last;

### top SQL by Buffer Gets/Rows proc
select substr(sql_text,1,500) "SQL",round((cpu_time/1000000),3) "CPU_Seconds",disk_reads "Disk_Reads",buffer_gets "Buffer_Gets",executions "Executions",
case when rows_processed = 0 then null else round((buffer_gets/nvl(replace(rows_processed,0,1),1))) end "Buffer_gets/rows_proc",
round((buffer_gets/nvl(replace(executions,0,1),1))) "Buffer_gets/executions",(elapsed_time/1000000) "Elapsed_Seconds",module "Module"
from v$sql s order by (buffer_gets/nvl(replace(rows_processed,0,1),1)) desc nulls last;

#### top SQL by CPU
select substr(sql_text,1,500) "SQL",(cpu_time/1000000) "CPU_Seconds",disk_reads "Disk_Reads",buffer_gets "Buffer_Gets",executions "Executions",
case when rows_processed = 0 then null else round((buffer_gets/nvl(replace(rows_processed,0,1),1))) end "Buffer_gets/rows_proc",
round((buffer_gets/nvl(replace(executions,0,1),1))) "Buffer_gets/executions",(elapsed_time/1000000) "Elapsed_Seconds",module "Module"
from v$sql s order by cpu_time desc nulls last;

### top SQL by Disk Reads
select substr(sql_text,1,500) "SQL",(cpu_time/1000000) "CPU_Seconds",disk_reads "Disk_Reads",buffer_gets "Buffer_Gets",executions "Executions",
case when rows_processed = 0 then null else round((buffer_gets/nvl(replace(rows_processed,0,1),1))) end "Buffer_gets/rows_proc",
round((buffer_gets/nvl(replace(executions,0,1),1))) "Buffer_gets/executions",(elapsed_time/1000000) "Elapsed_Seconds",module "Module"
from v$sql s order by disk_reads desc nulls last;

#### top SQL by Executions
select substr(sql_text,1,500) "SQL",(cpu_time/1000000) "CPU_Seconds",disk_reads "Disk_Reads",buffer_gets "Buffer_Gets",executions "Executions",
case when rows_processed = 0 then null else round((buffer_gets/nvl(replace(rows_processed,0,1),1))) end "Buffer_gets/rows_proc",
round((buffer_gets/nvl(replace(executions,0,1),1))) "Buffer_gets/executions",(elapsed_time/1000000) "Elapsed_Seconds",module "Module"
from v$sql s order by executions desc nulls last;

### top SQL by Waits
select INST_ID,(cpu_time/1000000) "CPU_Seconds",disk_reads "Disk_Reads",buffer_gets "Buffer_Gets",executions "Executions",case when rows_processed = 0 then null
else round((buffer_gets/nvl(replace(rows_processed,0,1),1))) end "Buffer_gets/rows_proc",round((buffer_gets/nvl(replace(executions,0,1),1)))
"Buffer_gets/executions",(elapsed_time/1000000) "Elapsed_Seconds", 
--round((elapsed_time/1000000)/nvl(replace(executions,0,1),1)) "Elapsed/Execution",
substr(sql_text,1,500) "SQL",module "Module",SQL_ID from gv$sql s where sql_id in (select distinct sql_id from (WITH sql_class AS (select sql_id,
state,count(*) occur from (select sql_id,CASE  WHEN session_state = 'ON CPU' THEN 'CPU' WHEN session_state = 'WAITING' AND wait_class
IN ('User I/O') THEN 'IO' ELSE 'WAIT' END state from gv$active_session_history where   session_type IN ( 'FOREGROUND')        
and sample_time  between trunc(sysdate,'MI') - 30/24/60 and trunc(sysdate,'MI') ) group by sql_id, state),ranked_sqls AS 
(select sql_id,  sum(occur) sql_occur  , rank () over (order by sum(occur)desc) xrank from sql_class           
group by sql_id ) select sc.sql_id, state, occur from sql_class sc, ranked_sqls rs where rs.sql_id = sc.sql_id 
--and rs.xrank <= :top_n 
order by xrank, sql_id, state )) order by elapsed_time desc nulls last;

####events in the past 30 minutes
select  inst_id,
nvl(event,'cpu')event, WAIT_CLASS, count(* ) sample_count
from gv$active_session_history
where sample_time >= sysdate - 30/(24*60) group by 
inst_id,
event,wait_class order by 4

--------------------------------------------------------------

###with the keyword "nowait" you force not to wait for (other) locks
lock table schema.table in exclusive mode nowait;

--------------------------------------------------------------

###materialized view, mview - complie and refresh
alter materialized view blabla complie;

complete refresh
EXECUTE DBMS_MVIEW.REFRESH('emp_dept_sum','C');

or 
fast refresh
EXECUTE DBMS_MVIEW.REFRESH('emp_dept_sum','F');

--------------------------------------------------------------

### disk reads, writes per session

SET LINESIZE 145
SET PAGESIZE 9999 

COLUMN sid                 FORMAT 99999            HEADING 'SID'
COLUMN session_status      FORMAT a8               HEADING 'Status'          JUSTIFY right
COLUMN oracle_username     FORMAT a11              HEADING 'Oracle User'     JUSTIFY right
COLUMN session_program     FORMAT a13              HEADING 'Session Program' TRUNC
COLUMN cpu_value           FORMAT 999,999,999      HEADING 'CPU'
COLUMN logical_io          FORMAT 999,999,999,999  HEADING 'Logical I/O'
COLUMN physical_reads      FORMAT 999,999,999,999  HEADING 'Physical Reads'
COLUMN physical_writes     FORMAT 999,999,999,999  HEADING 'Physical Writes'
COLUMN session_pga_memory  FORMAT 9,999,999,999    HEADING 'PGA Memory' 
COLUMN open_cursors        FORMAT 99,999           HEADING 'Cursors'
COLUMN num_transactions    FORMAT 999,999          HEADING 'Txns'

prompt 
prompt +------------------------------------------------------+
prompt | User Sessions and Statistics Ordered by Logical I/O  |
prompt +------------------------------------------------------+

SELECT
    s.sid                sid
  , lpad(s.status,8)     session_status
  , lpad(s.username,11)  oracle_username
  , s.program            session_program
  , sstat1.value         cpu_value
  , sstat2.value +
    sstat3.value         logical_io
  , sstat4.value         physical_reads
  , sstat5.value         physical_writes
  , sstat6.value         session_pga_memory
  , sstat7.value         open_cursors
  , sstat8.value         num_transactions
FROM 
    v$process  p
  , v$session  s
  , v$sesstat  sstat1
  , v$sesstat  sstat2
  , v$sesstat  sstat3
  , v$sesstat  sstat4
  , v$sesstat  sstat5
  , v$sesstat  sstat6
  , v$sesstat  sstat7
  , v$sesstat  sstat8
  , v$statname statname1
  , v$statname statname2
  , v$statname statname3
  , v$statname statname4
  , v$statname statname5
  , v$statname statname6
  , v$statname statname7
  , v$statname statname8
WHERE
      p.addr (+)            = s.paddr
  AND s.sid                 = sstat1.sid
  AND s.sid                 = sstat2.sid
  AND s.sid                 = sstat3.sid
  AND s.sid                 = sstat4.sid
  AND s.sid                 = sstat5.sid
  AND s.sid                 = sstat6.sid
  AND s.sid                 = sstat7.sid
  AND s.sid                 = sstat8.sid
  AND statname1.statistic#  = sstat1.statistic#
  AND statname2.statistic#  = sstat2.statistic#
  AND statname3.statistic#  = sstat3.statistic#
  AND statname4.statistic#  = sstat4.statistic#
  AND statname5.statistic#  = sstat5.statistic#
  AND statname6.statistic#  = sstat6.statistic#
  AND statname7.statistic#  = sstat7.statistic#
  AND statname8.statistic#  = sstat8.statistic#
  AND statname1.name        = 'CPU used by this session'
  AND statname2.name        = 'db block gets'
  AND statname3.name        = 'consistent gets'
  AND statname4.name        = 'physical reads'
  AND statname5.name        = 'physical writes'
  AND statname6.name        = 'session pga memory'
  AND statname7.name        = 'opened cursors current'
  AND statname8.name        = 'user commits'
ORDER BY logical_io DESC
/

--------------------------------------------------------------

### disk reads, writes

set pagesize 100
set linesize 250
column name format a18 heading 'Tablespace' jus cen
column file format a55 heading 'File Name' jus cen
column pbr format 99,999,999,990 heading 'Physical|Blocks|Read' jus cen 
column pbw format 99,999,999,990 heading 'Physical |Blocks|Written' jus cen 
column pyr format 99,999,999,990 heading 'Physical |Reads' jus cen 
column pyw format 99,999,999,990 heading 'Physical|Writes' jus cen 

compute sum of pyr on report
compute sum of pyw on report
compute sum of pbr on report
compute sum of pbw on report
break on report
select 
df.tablespace_name name,
df.file_name "file",
f.phyrds pyr,
f.phyblkrd pbr,
f.phywrts pyw,
f.phyblkwrt pbw
from v$filestat f, dba_data_files df
where
f.file# = df.file_id
order by f.phywrts,
f.phyblkwrt;

--------------------------------------------------------------


### Generate a sql script for dropping all user's objects using drop_user.sql script. After that run the generated script.

 

SQL> set pages 10000
spool drop_TRN_objects.sql
select 'drop '||object_type||' '||owner||'."'||object_name||decode(object_type,'TABLE','" cascade constraints;', '";') from dba_objects
where owner=upper('&owner') and object_type in ('CLUSTER','DATABASE LINK','FUNCTION','LIBRARY','LOB','PACKAGE','PACKAGE BODY',
'PROCEDURE','SEQUENCE','SYNONYM','TABLE','TRIGGER','MATERIALIZED VIEW','TYPE','VIEW') order by object_type;

Enter value for owner when asked.

###Run the generated drop script

SQL> @drop_TRN_objects.sql

Drop also the scheduled jobs:

select 'execute SYS.DBMS_SCHEDULER.DROP_JOB (job_name  => '''|| owner ||'.'|| job_name ||''');' from dba_scheduler_jobs where owner='&USERNAME_TOBE_DROPPED';

The final result must be:

SQL> select object_name,object_type  from dba_objects where owner='&USERNAME_TOBE_DROPPED';

no rows selected


--------------------------------------------------------------


---------------------------------------------------------

### locks hierarchy

set serveroutput ON

DECLARE
   TYPE array_num_type IS TABLE OF PLS_INTEGER
      INDEX BY BINARY_INTEGER;

   v_session_id   array_num_type;
   v_blocking1    array_num_type;
   v_blocking2    array_num_type;
   v_blocking3    array_num_type;
   v_blocking4    array_num_type;
   v_blocking5    array_num_type;
   v_deadlock     array_num_type;
   sn1            PLS_INTEGER;
   sn2            PLS_INTEGER;
   sn3            PLS_INTEGER;
   sn4            PLS_INTEGER;
   sn5            PLS_INTEGER;
   sn6            PLS_INTEGER;
   is_dead_lock   BOOLEAN;
   str            VARCHAR2 (1000);
BEGIN
   FOR cur1 IN (SELECT SID, blocking_session
                    FROM v$session
                   WHERE blocking_session IS NOT NULL
                ORDER BY logon_time)
   LOOP
      v_session_id (cur1.blocking_session) := cur1.SID;
      v_blocking1 (cur1.SID) := cur1.blocking_session;
   END LOOP;

   sn1 := v_blocking1.FIRST;

   WHILE (sn1 IS NOT NULL)
   LOOP
      sn2 := v_blocking1 (sn1);
      is_dead_lock := FALSE;

      IF v_blocking1.EXISTS (sn2)
      THEN
         sn3 := v_blocking1 (sn2);
         v_blocking2 (sn1) := sn3;

         IF sn3 = sn1
         THEN
            is_dead_lock := TRUE;
         END IF;

         IF v_blocking1.EXISTS (sn3)
         THEN
            sn4 := v_blocking1 (sn3);
            v_blocking3 (sn1) := sn4;

            IF sn4 = sn1 OR sn4 = sn2
            THEN
               is_dead_lock := TRUE;
            END IF;

            IF v_blocking1.EXISTS (sn4)
            THEN
               sn5 := v_blocking1 (sn4);
               v_blocking4 (sn1) := sn5;

               IF sn1 = sn5 OR sn2 = sn5 OR sn3 = sn5
               THEN
                  is_dead_lock := TRUE;
               END IF;

               IF v_blocking1.EXISTS (sn5)
               THEN
                  sn6 := v_blocking1 (sn5);
                  v_blocking5 (sn1) := sn6;

                  IF sn1 = sn6 OR sn2 = sn6 OR sn3 = sn6 OR sn4 = sn6
                  THEN
                     is_dead_lock := TRUE;
                  END IF;
               END IF;
            END IF;
         END IF;
      END IF;

      IF is_dead_lock = TRUE
      THEN
         v_deadlock (sn1) := 1;
      ELSE
         v_deadlock (sn1) := 0;
      END IF;

      sn1 := v_blocking1.NEXT (sn1);
   END LOOP;

   sn1 := v_blocking1.FIRST;

   WHILE (sn1 IS NOT NULL)
   LOOP
      IF v_deadlock (sn1) = 0
      THEN
         str := sn1;
      ELSE
         str := 'Deadlock ' || sn1;
      END IF;

      IF v_blocking1.EXISTS (sn1)
      THEN
         str := str || ' -> ' || v_blocking1 (sn1);
      END IF;

      IF v_blocking2.EXISTS (sn1)
      THEN
         str := str || ' -> ' || v_blocking2 (sn1);
      END IF;

      IF v_blocking3.EXISTS (sn1)
      THEN
         str := str || ' -> ' || v_blocking3 (sn1);
      END IF;

      IF v_blocking4.EXISTS (sn1)
      THEN
         str := str || ' -> ' || v_blocking4 (sn1);
      END IF;

      IF v_blocking5.EXISTS (sn1)
      THEN
         str := str || ' -> ' || v_blocking5 (sn1);
      END IF;

      sn1 := v_blocking1.NEXT (sn1);
      DBMS_OUTPUT.put_line (str);
   END LOOP;
END;
/


---------------------------------------------------------

###total waits and percentage of waits by wait class

SELECT WAIT_CLASS,
TOTAL_WAITS,
round(100 * (TOTAL_WAITS / SUM_WAITS),2) PCT_TOTWAITS,
ROUND((TIME_WAITED / 100),2) TOT_TIME_WAITED,
round(100 * (TIME_WAITED / SUM_TIME),2) PCT_TIME
FROM
(select WAIT_CLASS,
TOTAL_WAITS,
TIME_WAITED
FROM V$SYSTEM_WAIT_CLASS
WHERE WAIT_CLASS != 'Idle'),
(select sum(TOTAL_WAITS) SUM_WAITS,
sum(TIME_WAITED) SUM_TIME
from V$SYSTEM_WAIT_CLASS
where WAIT_CLASS != 'Idle')
ORDER BY PCT_TIME DESC; 


---------------------------------------------------------

###calculate the top n waits in the system by dividing the event�s wait time by the total wait time for all events

select EVENT, TOTAL_WAITS, TIME_WAITED, WAIT_CLASS from V$SYSTEM_EVENT
where wait_class != 'Idle'
order by time_waited desc;

---------------------------------------------------------

###we can get the session level waits for each event using V$SESSION_EVENT view. In this view the TIME_WAITED is the wait time per session.

select sid, EVENT, TOTAL_WAITS, TIME_WAITED, WAIT_CLASS
from V$SESSION_EVENT
where WAIT_CLASS != 'Idle'
and sid='&SID'
order by TIME_WAITED;

---------------------------------------------------------

###the V$SESSION_WAIT view enables you to probe into the exact bottleneck that�s slowing down the database

select sid, event, WAIT_CLASS, WAIT_TIME, SECONDS_IN_WAIT, STATE from v$session_wait
where wait_class != 'Idle';

---------------------------------------------------------

###obtaining the objects with highest waits

set linesize 400
col TOTAL_WAIT_TIME for a20
col TOTAL_WAIT_TIME for 999999999999
col OBJECT_NAME for a70
col EVENT for a60
col OBJECT_NAME for a40
SELECT a.current_obj#, o.object_name, o.object_type, a.event,
SUM(a.wait_time +
a.time_waited) total_wait_time
FROM v$active_session_history a,
dba_objects o
WHERE a.sample_time between sysdate-30/2880 and sysdate
AND a.current_obj# = o.object_id
GROUP BY a.current_obj#, o.object_name, o.object_type, a.event
ORDER BY total_wait_time;

---------------------------------------------------------

###some important wait events

SELECT a.event,
SUM(a.wait_time +
a.time_waited) total_wait_time
FROM v$active_session_history a
WHERE a.sample_time between
sysdate - 30/2880 and sysdate
GROUP BY a.event
ORDER BY total_wait_time DESC;

---------------------------------------------------------

###The following query lists the users with the highest wait times within the last 15 minutes

SELECT s.sid, s.username,
SUM(a.wait_time +
a.time_waited) total_wait_time
FROM v$active_session_history a,
v$session s
WHERE a.sample_time between sysdate - 30/2880 and sysdate
AND a.session_id=s.sid
GROUP BY s.sid, s.username
ORDER BY total_wait_time DESC;

---------------------------------------------------------

###Using the following query, you can identify the SQL that�s waiting the most in your instance with in last 15 mins

col SQL_TEXT for a90
SELECT a.user_id,d.username,s.sql_text,
SUM(a.wait_time + a.time_waited) total_wait_time
FROM v$active_session_history a,
v$sqlarea s,
dba_users d
WHERE a.sample_time between sysdate - 30/2880 and sysdate
AND a.sql_id = s.sql_id
AND a.user_id = d.user_id
GROUP BY a.user_id,s.sql_text, d.username; 

---------------------------------------------------------

### grant GRANT SELECT, UPDATE, INSERT, DELETE, EXECUTE to one user for the objects of another
set serverout on
DECLARE
targetuser varchar2(50):='&targetuser';
sourceuser varchar2(50):='&sourceuser';
BEGIN   
FOR Rec IN (SELECT object_name, object_type 
   FROM all_objects 
   WHERE owner=sourceuser 
   AND object_type IN ('TABLE','VIEW','PROCEDURE','FUNCTION','PACKAGE')) 
LOOP
IF Rec.object_type IN ('TABLE','VIEW') 
THEN 
dbms_output.put_line ('GRANT SELECT, UPDATE, INSERT, DELETE ON '||sourceuser||'.'||Rec.object_name||' TO '||targetuser);     
EXECUTE IMMEDIATE 'GRANT SELECT, UPDATE, INSERT, DELETE ON '||sourceuser||'.'||Rec.object_name||' TO '||targetuser;  
ELSIF Rec.object_type IN ('PROCEDURE','FUNCTION','PACKAGE') 
THEN   
dbms_output.put_line ('GRANT EXECUTE ON '||sourceuser||'.'||Rec.object_name||' TO '||targetuser);
EXECUTE IMMEDIATE 'GRANT EXECUTE ON '||sourceuser||'.'||Rec.object_name||' TO '||targetuser;     
END IF;   
END LOOP; 
END;
/

---------------------------------------------------------

### startup trigger - RECOVER MANAGED STANDBY DATABASE

CREATE OR REPLACE TRIGGER SYS.DB_ROLE1 
AFTER STARTUP ON DATABASE 
DECLARE 
CTL varchar(10); 
BEGIN 
   SELECT CONTROLFILE_TYPE INTO CTL FROM V$DATABASE; 
IF CTL = 'STANDBY' THEN 
execute immediate 'ALTER DATABASE RECOVER MANAGED STANDBY DATABASE NODELAY DISCONNECT FROM SESSION';
END IF ; 
END DB_ROLE1;
/

---------------------------------------------------------



###Re: When does LGWR write to the database? 
Answer
# 3 1.Every 3 secs
2.At commit(when a tx commits)
3.When one third of redo log buffer is filled.
4.When there is more than 1 Mb of redo entries(redo data or
changes) in the redo log buffer
5.Before DBWR background process writes dirty buffers from
db cache to datafiles(database)

At any of the above instances(cases) lgwr writes the redo
entries or redo data or changes from the redo log buffer to
the redo log file.
 
---------------------------------------------------------

## Deadlocks

http://www.oracle-base.com/articles/misc/Deadlocks.php

---------------------------------------------------------

DGMGRL> SHOW DATABASE VERBOSE 'DR_Sales';

---------------------------------------------------------


