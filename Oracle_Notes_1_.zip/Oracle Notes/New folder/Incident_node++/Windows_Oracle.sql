﻿##############################################################
##############################################################
##### To put your personal user in dba group in the server

Computer Management ---> Local users and groups ---.> Groups ---> dba_ora


mstsc ---> connectora


##############################################################
###############################################################

##### set enviroment on Windows ##### 

#### Да проверя кой е на сървъра : Windows Task Manager --> Users

set ----> да проверя дали е сетнат енвайрманта и търсим някъде дали има oracle home

C:\Users\EXTHP-pehliiza>SET ORACLE_SID=OSTIDB

C:\Users\EXTHP-pehliiza>SET ORACLE_HOME=c:\oracle\oradb11g     ----> oracle home-a мога и да го извадя от dbspicao ili ot services--> propertice na bazata

C:\Users\EXTHP-pehliiza>sqlplus / as sysdba

Tsvetomir Karlov: Windows

set PATH=%ORACLE_HOME%/bin;%PATH%

set ORACLE_SID=O114P048


SET ORACLE_HOME=d:\O114P048\product\12.2.0\se\bin    

 
set PATH=%ORACLE_HOME%/bin;%PATH%

###############################################################
##############################################################

### Check uptime on WINDOWS server #### or due to task manager --> Performance
systeminfo | find "System Boot Time"

C:\Users\xHPpehliiza_>systeminfo | find "System Boot Time"
System Boot Time:          23.2.2020, 10:42:12


### Check the reason for reboot
event viewer -->System ---> Filter Current LOg ---> above task category enter some of the below errors

Errors reasons
1074 - Restart (windows planned)
1076 - Unexpected
6008 - irregular Shutdown 
41 - power loss 

################################################################
################################################################


[‎11/‎18/‎2019 8:25 AM]  Rangelov, Martin (Oracle DBA):  
################### FS POWERSHELL

Clear-Host
Get-WmiObject Win32_logicaldisk -ComputerName LocalHost `
| Format-Table DeviceID, MediaType, `
@{Name=" Size(GB)";Expression={"{0,9:N2}" -f(($_.size/1gb).tostring("0.00"))}}, `
@{Name="Free Space(GB)";Expression={"{0,14:N2}" -f(($_.freespace/1gb).tostring("0.00"))}}, `
@{Name="   Free (%)";Expression={"   {0,6:P2}" -f(($_.freespace/1gb) / ($_.size/1gb))}} `
-AutoSize 
имаш го в Oracle_hints


#################################################################
#################################################################


##### Windows backup #####
============================================

C:\Program Files\OmniBack\bin\omnib.exe -oracle8 plwaws0004_ZDPS_archivelog_delete_on



#################################################################
#################################################################

####### ORACLE BACKUP ON WINDOWS MACHINE (58 metric)

1st step: hop or rdp
2nd step: rdp -> connection to the server
3rd step: checking if we are registered on the server -> Start button -> Administrative Tools -> Computer Management
4th step: Command Prompt: we are typing the following commands: dbspicao -pdfv (to see the path to the ORACLE_HOME) and dbspicao -m58 -r1 -i <db_name>
5th step: In new Command Prompt window we are typing: set ORACLE_SID=<db_name> and set ORACLE_HOME=<db_name>
6th step: To login in RMAN we need to type: "cd <ORACLE_HOME>\bin" and then to login in RMAN to type "rman target /"
7th step: To start backup on oracle hosted on windows machine, to get the backup script we need to go to this folder: "C:\Programs\Tivoli\tsm\<db_name>\rman" and to choose the script for which is the case.
8th step: Wait the backup to complete and close the ticket :)



#####################################################################
#########################################################################

FORTUM - HOW TO START A BACKUP WHEN THE INCIDENTS COMES FROM WINDOWS SERVER(WITH DATAPROTECTOR) - NODE: plwaws0004.adinfra.net - DATABASE: ZDPS

FROM ESL:
Backup Method: DataProtector    Details lookup details
Bkp/DL Name: Oracle8 plwaws0004_ZDPS_archivelog_delete_on

Client Backup, Cellserver: plwaws0010.adinfra.net

---TRQBVA DA SI NAMERIM LINUX SERVER KOITO DA BACKUPIRA NA SYSHTIQ CELLSERVER(plwaws0010.adinfra.net):

##Linux server in this case
plwrox0004.adinfra.net - FROM ROOT SWITCH TO ORACLE - nohup /opt/omni/bin/omnib -Oracle8 plwaws0004_ZDPS_archivelog_delete_on &


---DONE--- 


##################################################################
##################################################################

     ####   MEWA  #####
	 
hop ---> hop ----> server
defraas001.mewa-group.com    #### vtoria hop


######
На командпромпта десен бутон и run as administrator


######## 
Работа и управление на клъстъра без да отварям конзола
 

 От start--> Administrative Tools ---> Services   ---От тук може да видим как се казва лисънъра (OracleOraDb11g_home1TNSListenerFsIDEMSCDB041)
 
 
когато са много бази мога да си ги оправлявам през  Start--> Administrative tools--> Failover Cluster Manager
Разтягам и отивам на базата където пише и като ми се отвори Summery of oracle(database_name) ---> other resources ---> от там името на базата,лисънър и каквото и да е 
и от там десен бутон и избирам: Take this recourse offline/Bring this recourse online   (ГАСЯ И ПАЛЯ )

Run --> mmc --> file-->add/remote snap in--> oracle primary... ---> десен бутон на базата и от там може stop/start service и processes kill --->desen buton connect за да се кънектнем към базата 


oт комантпромта винаги с logoff  и ме изхвърля от сървъра  безопасно !!!!!!!!!!




8WSXcde>Bella    Primary KID
7RFVbgt<Bella