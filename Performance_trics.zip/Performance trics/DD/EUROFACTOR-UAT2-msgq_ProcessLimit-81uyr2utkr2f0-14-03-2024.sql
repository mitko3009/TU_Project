/********************************************************************************
*********       E-mail subject: EFAGDEV-3238
*********             Instance: UAT2
*********          Description: 
Problem:
SQL 81uyr2utkr2f0 was 100% of the time of msgq_ProcessLimit module on UAT2.

Analysis:
From the analyze of msgq_ProcessLimit, we considered that SQL 81uyr2utkr2f0 doesn't work properly from performance point of view.
The problem in it was that is accesses table g_piece through index G_PIECE$ID_VENTE on columns GPIROLE and TYPPIECE, which returns over 2 milion rows.
Selecting and processing such amount of data needs time, so the query took unacceptable amount of time to be executed. The solution here is to access table G_PIECE 
through index PIE_GPILIBLIBRE on column gpiliblibre, which is a special identification string and it is much more selevtive. For this purpose, 
we need to remove the NVL from column gpidepot ( NVL(gpidepot, 'X') = NVL(:b2, 'X') ) to be able to access it through column gpiliblibre.

Suggestion:
Please check is it functional correct to remove the NVL from column gpidepot and check its value through gpiliblibre as it is shown in the New SQL section below and if it is, 
please change the query as it is shown in the New SQL section.

*********               SQL_ID: 81uyr2utkr2f0
*********      Program/Package: msgq_ProcessLimit
*********              Request: Dimitare Ivanov
*********               Author: Dimitar Dimitrov
********* Received e-mail date: 13/03/2024
*********      Resolution date: 14/03/2024
*********  Trace old file here: \\epox\specifs\performance\tmp\
*********  Trace new file here:
***********************************************************************************/

/********************************OLD SQL*******************************************/

var B2 VARCHAR2(1000);
exec :B2 := 'A601E2XV';
var B3 VARCHAR2(1000);
exec :B3 := 'A601G9DC';
var B4 VARCHAR2(1000);
exec :B4 := '0EHHERM';
var B0 VARCHAR2(32);
exec :B0 := 'EUR';

select NVL(max(CH_TAUX.Conv_Orig_Dest_Tx(TO_CHAR(SYSDATE, 'j'),
                                         mt02,
                                         code,
                                         :b0,
                                         'MR',
                                         ftr_fin_factor.getCurrency(gpityptrib),
                                         ftr_fin_factor.getPays(gpityptrib))),
           0)
  into :b1
  from g_piece
 where typpiece = 'REQUEST_LIMITE' 
   and gpirole in ('DC', 'DT') 
   and NVL(gpidepot, 'X') = NVL(:b2, 'X')
   and gpiadr3 = :b3 
   and fg05 = 'O' 
   and NVL(gpidtfin_dt, (SYSDATE + 1)) > SYSDATE
   and libelle_20_7 = :b4;
/********************************OLD SQL*******************************************/
/********************************OLD Metrics***************************************/
/*
MODULE                           SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
msgq_ProcessLimit                                               1449      61963 db file sequential r 2024/03/13 16:51:39  2024/03/13 16:59:59         210                    5 +000000000 00:08:20.289 10%
                                 gw788nxk7vbwg                                  ON CPU               2024/03/13 13:40:59  2024/03/13 16:58:30         185                    1 +000000000 03:17:30.745 9%
msgq_ProcessLimit                81uyr2utkr2f0  230518406       1449      61963 db file parallel rea 2024/03/13 16:51:36  2024/03/13 16:59:50         145                    5 +000000000 00:08:14.291 7%
SQL*Plus                                                                        ON CPU               2024/03/13 13:40:28  2024/03/13 16:59:16         141              1983103 +000000000 03:18:47.766 6%
msgq_pilote                                                                     ON CPU               2024/03/13 16:48:01  2024/03/13 16:51:36         130             15285799 +000000000 00:03:34.108 6%
erf_saf2imx_load                                                                ON CPU               2024/03/13 13:41:36  2024/03/13 16:59:45         112             14050983 +000000000 03:18:08.784 5%
msgq_pilote                                                                     db file sequential r 2024/03/13 16:48:02  2024/03/13 16:51:18         109              4793011 +000000000 00:03:15.101 5%
msgq_ProcessLimit                81uyr2utkr2f0  230518406       1449      61963 ON CPU               2024/03/13 16:51:35  2024/03/13 16:59:57         101                    5 +000000000 00:08:22.290 5%


MODULE                           SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
msgq_ProcessLimit                                               1449      61963 db file sequential r 2024/03/13 16:51:39  2024/03/13 17:46:13        1356                  314 +000000000 00:54:34.383 41%
msgq_ProcessLimit                81uyr2utkr2f0  230518406       1449      61963 db file parallel rea 2024/03/13 16:51:36  2024/03/13 17:46:14        1002                   24 +000000000 00:54:38.383 31%
msgq_ProcessLimit                                               1449      61963 ON CPU               2024/03/13 16:51:35  2024/03/13 17:46:08         596                   24 +000000000 00:54:33.375 18%
msgq_ProcessLimit                81uyr2utkr2f0  230518406       1449      61963 db file scattered re 2024/03/13 16:52:01  2024/03/13 17:46:01         278                   24 +000000000 00:54:00.351 8%
msgq_ProcessLimit                81uyr2utkr2f0  230518406       1449      61963 read by other sessio 2024/03/13 17:38:07  2024/03/13 17:40:11          44                    1 +000000000 00:02:04.010 1%
msgq_ProcessLimit                81uyr2utkr2f0  230518406       1449      61963 latch: shared pool   2024/03/13 17:44:52  2024/03/13 17:44:52           1                    1 +000000000 00:00:00.000 0%


MODULE                           SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
msgq_ProcessLimit                81uyr2utkr2f0  230518406       1449      61963                      2024/03/13 16:51:35  2024/03/13 17:46:40        3294                   24 +000000000 00:55:05.412 100%
msgq_ProcessLimit                1hfx623wgqbn0 3357910158       1449      61963 ON CPU               2024/03/13 17:22:56  2024/03/13 17:22:56           1                      +000000000 00:00:00.000 0%
msgq_ProcessLimit                4wyt1rdtbgt6f 2781216301       1449      61963 db file sequential r 2024/03/13 17:05:45  2024/03/13 17:05:45           1                    1 +000000000 00:00:00.000 0%


INSTANCE_NUMBER SQL_ID            ELAPSED MAX_WAIT_ON     PC_OF  WAIT_TIME            GETS      READS       ROWS  ELAP/EXEC       GETS/EXEC READS/EXEC  ROWS/EXEC       EXEC PLAN_HASH_VALUE
--------------- ------------- ----------- --------------- ----- ---------- --------------- ---------- ---------- ---------- --------------- ---------- ---------- ---------- ---------------
              1 81uyr2utkr2f0         692 IO              87%   644.565664        18341751    5527226          5      115.3         3056959  921204.33        .83          6       230518406


Plan hash value: 230518406
------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                             | Name             | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  |
------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                      |                  |      1 |        |     1 (100)|      1 |00:02:31.36 |    3273K|   1062K|
|   1 |  SORT AGGREGATE                       |                  |      1 |      1 |            |      1 |00:02:31.36 |    3273K|   1062K|
|   2 |   INLIST ITERATOR                     |                  |      1 |        |            |      0 |00:02:31.36 |    3273K|   1062K|
|*  3 |    TABLE ACCESS BY INDEX ROWID BATCHED| G_PIECE          |      2 |      1 |     1   (0)|      0 |00:02:31.36 |    3273K|   1062K|
|*  4 |     INDEX RANGE SCAN                  | G_PIECE$ID_VENTE |      2 |      1 |     1   (0)|   2147K|00:00:09.96 |   10825 |  10825 |
------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   3 - filter(("GPIADR3"=:B3 AND "LIBELLE_20_7"=:B4 AND "FG05"='O' AND "GPILIBLIBRE" LIKE :B3||'.'||:B2||'%' AND
              NVL("GPIDEPOT",'X')=NVL(:B2,'X') AND NVL("GPIDTFIN_DT",SYSDATE@!+1)>SYSDATE@!))
   4 - access((("GPIROLE"='DC' OR "GPIROLE"='DT')) AND "TYPPIECE"='REQUEST_LIMITE')
*/
/********************************OLD Metrics***************************************/

/********************************New SQL*******************************************/

select /*+ index(g_piece PIE_GPILIBLIBRE) */
       NVL(max(CH_TAUX.Conv_Orig_Dest_Tx(TO_CHAR(SYSDATE, 'j'),
                                         mt02,
                                         code,
                                         :b0,
                                         'MR',
                                         ftr_fin_factor.getCurrency(gpityptrib),
                                         ftr_fin_factor.getPays(gpityptrib))),
           0)
  into :b1
  from g_piece
 where typpiece = 'REQUEST_LIMITE' 
   and gpirole in ('DC', 'DT') 
   and fg05 = 'O' 
   and NVL(gpidtfin_dt, (SYSDATE + 1)) > SYSDATE
   and libelle_20_7 = :b4
   and gpiliblibre like :b3 || '.' || :b2 || '%';
/********************************New SQL*******************************************/
/********************************New Metrics***************************************/
/*
Plan hash value: 3003023525
----------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                            | Name            | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  |
----------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                     |                 |      1 |        |     1 (100)|      1 |00:00:00.01 |       4 |      4 |
|   1 |  SORT AGGREGATE                      |                 |      1 |      1 |            |      1 |00:00:00.01 |       4 |      4 |
|*  2 |   TABLE ACCESS BY INDEX ROWID BATCHED| G_PIECE         |      1 |      1 |     1   (0)|      0 |00:00:00.01 |       4 |      4 |
|*  3 |    INDEX RANGE SCAN                  | PIE_GPILIBLIBRE |      1 |     81 |     1   (0)|      0 |00:00:00.01 |       4 |      4 |
----------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   2 - filter(("TYPPIECE"='REQUEST_LIMITE' AND "LIBELLE_20_7"=:B4 AND "FG05"='O' AND INTERNAL_FUNCTION("GPIROLE") AND
              NVL("GPIDTFIN_DT",SYSDATE@!+1)>SYSDATE@!))
   3 - access("GPILIBLIBRE" LIKE :B3||'.'||:B2||'%')
       filter("GPILIBLIBRE" LIKE :B3||'.'||:B2||'%')
*/
/********************************New Metrics***************************************/

/********************************Index statistics**********************************/

/********************************Other SQLs****************************************/          
/*

*/ 
/********************************Other SQLs****************************************/              
