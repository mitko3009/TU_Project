/********************************************************************************
*********       E-mail subject: KBCCFDEV-5901
*********             Instance: NOTOVAL
*********          Description: 
Problem:
The imxbatch_ReverseNotification took unexpectedly long time on NOTOVAL.

Analysis:
After the analyze of the imxbatch_ReverseNotification, we found that the TOP SQL was 3yycnnvj74mrt, which is SE variable LPI_bundle_lts.
The heaviest step in its execution plan is the INDEX SKIP SCAN on table F_DETFAC.
This SQL should not be heavy, but based on the inforamation in the AWR, it took over 1 hour for the reported period. We made AWR Report for the 
period between 23:00 and 00:00 on 31/08/2024 and in it it can be seen that the total "data blocks consistent reads - undo records applied" is 314,878,249. 
Based on this, we suggest that someone updated some rows in table F_DETFAC ( we don't know who ) without commit and this is the reason for the slowness. We have also several changes 
from performance point of view, so please see the New SQL section below.

Suggestion:
1. Please use bind variables instead of using literals ( for example for the t.reftexte ).
2. To avoid the INDEX SKIP SCAN, please add and the df_cli to the query ( you can see the New SQL section below, where we found some df_cli just for the test )
3. Please add hints as it is shown in the New SQL section below.

*********               SQL_ID: 3yycnnvj74mrt -> SE variable LPI_bundle_lts
*********      Program/Package: 
*********              Request: Ivaylo Tsvetkov 
*********               Author: Dimitar Dimitrov
********* Received e-mail date: 03/09/2024
*********      Resolution date: 03/09/2024
*********  Trace old file here: \\epox\specifs\performance\tmp\
*********  Trace new file here:
***********************************************************************************/

/********************************OLD SQL*******************************************/
select f.df_num || f.df_refinit || f.df_dos
  from f_detfac f
 where f.df_nom = 'LPIBU'
   and f.df_rel in (select e.libelle_20_1
                      from g_elemfi_texte t, 
                           g_elemfi e
                     where t.reftexte = 'C0065MZH'
                       and t.refelem = e.refelem
                       and e.libelle_20_2 = 'LPIBU');

/********************************OLD SQL*******************************************/
/********************************OLD Metrics***************************************/
/*
MODULE                           PROGRAM                                            CLIENT_ID       SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- -------------------------------------------------- --------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
imxbatch_ReverseNotification     imxbatch                                                                                          2012      33010                      2024/08/31 23:13:31  2024/09/01 00:33:02        466                    16 +000000000 01:19:31.840 100%



MODULE                           PROGRAM                                            CLIENT_ID       SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- -------------------------------------------------- --------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
imxbatch_ReverseNotification     imxbatch                                                                                          2012      33010 db file sequential r 2024/08/31 23:13:31  2024/09/01 00:32:52        431                    16 +000000000 01:19:21.602 92%
imxbatch_ReverseNotification     imxbatch                                                                                          2012      33010 ON CPU               2024/08/31 23:13:41  2024/09/01 00:33:02         34                    15 +000000000 01:19:21.599 7%
imxbatch_ReverseNotification     imxbatch                                                           atvymxj90km29  637204662       2012      33010 direct path read     2024/08/31 23:18:17  2024/08/31 23:18:17          1                     1 +000000000 00:00:00.000 0%


MODULE                           PROGRAM                                            CLIENT_ID       SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- -------------------------------------------------- --------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
imxbatch_ReverseNotification     imxbatch                                                           3yycnnvj74mrt 4202628151       2012      33010 db file sequential r 2024/08/31 23:21:01  2024/09/01 00:32:22        390                     1 +000000000 01:11:20.321 84%
imxbatch_ReverseNotification     imxbatch                                                           3yycnnvj74mrt 4202628151       2012      33010 ON CPU               2024/08/31 23:21:52  2024/09/01 00:18:01         29                     1 +000000000 00:56:08.962 6%
imxbatch_ReverseNotification     imxbatch                                                           03dwkdrqbg9gh  328948039       2012      33010 db file sequential r 2024/08/31 23:14:12  2024/08/31 23:18:07         24                     1 +000000000 00:03:55.520 5%
imxbatch_ReverseNotification     imxbatch                                                           atvymxj90km29  637204662       2012      33010 db file sequential r 2024/08/31 23:18:28  2024/08/31 23:20:51         14                     1 +000000000 00:02:23.361 3%
imxbatch_ReverseNotification     imxbatch                                                           9kpvpqnftu1h4 1808107619       2012      33010 db file sequential r 2024/08/31 23:13:31  2024/09/01 00:32:52          3                     2 +000000000 01:19:21.602 1%


KBC-NOTOVAL-imxbatch_ReverseNotification-3yycnnvj74mrt-03-09-2024


MODULE                           PROGRAM                                            CLIENT_ID       SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- -------------------------------------------------- --------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
imxbatch_ReverseNotification     imxbatch                                                           3yycnnvj74mrt 4202628151       2012      33010                      2024/08/31 23:21:01  2024/09/01 00:32:22        419                     1 +000000000 01:11:20.321 90%
imxbatch_ReverseNotification     imxbatch                                                           03dwkdrqbg9gh  328948039       2012      33010 db file sequential r 2024/08/31 23:14:12  2024/08/31 23:18:07         24                     1 +000000000 00:03:55.520 5%
imxbatch_ReverseNotification     imxbatch                                                           atvymxj90km29  637204662       2012      33010                      2024/08/31 23:18:17  2024/08/31 23:20:51         16                     1 +000000000 00:02:33.601 3%
imxbatch_ReverseNotification     imxbatch                                                           9kpvpqnftu1h4 1808107619       2012      33010                      2024/08/31 23:13:31  2024/09/01 00:32:52          4                     2 +000000000 01:19:21.602 1%



INSTANCE_NUMBER    SNAP_ID BEGIN_INTERVAL_TIME            END_INTERVAL_TIME              EVENT                          TOTAL_WAITS TIME_WAITED AVG_DISK_RESP_TIME_MS READ_DELTA_VALUE WRITE_DELTA_VALUE
--------------- ---------- ------------------------------ ------------------------------ ------------------------------ ----------- ----------- --------------------- ---------------- -----------------
              1       3420 2024/08/31 19:00:58            2024/08/31 20:00:17            db file sequential read            6249981  7202578865                   1.2               49                 1
              1       3421 2024/08/31 20:00:17            2024/08/31 21:00:39            db file sequential read            3106882  8786023967                   2.8               25                 1
              1       3422 2024/08/31 21:00:39            2024/08/31 22:00:59            db file sequential read            4743255  7555936261                   1.6               37                 1
              1       3423 2024/08/31 22:00:59            2024/08/31 23:00:16            db file sequential read            9162427  7724205846                    .8               74                 9
              1       3424 2024/08/31 23:00:16            2024/09/01 00:00:35            db file sequential read           12488657  1.4099E+10                   1.1              112                 4
              1       3425 2024/09/01 00:00:35            2024/09/01 01:00:54            db file sequential read            3161702  4727084999                   1.5               34                11
              1       3426 2024/09/01 01:00:54            2024/09/01 02:00:13            db file sequential read            2871376  9112094319                   3.2               41                 8
              1       3427 2024/09/01 02:00:13            2024/09/01 03:00:30            db file sequential read            2963402  4238921511                   1.4               27                 6
              1       3428 2024/09/01 03:00:30            2024/09/01 04:00:47            db file sequential read            4683597  2869309992                    .6               43                 1
              1       3429 2024/09/01 04:00:47            2024/09/01 05:00:33            db file sequential read             698244  3024361097                   4.3               81                 5
   

Plan hash value: 4202628151
--------------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                              | Name                    | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  |
--------------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                       |                         |      1 |        |    52 (100)|      1 |00:00:03.92 |    4544 |   4531 |
|*  1 |  HASH JOIN RIGHT SEMI                  |                         |      1 |      1 |    52   (0)|      1 |00:00:03.92 |    4544 |   4531 |
|   2 |   VIEW                                 | VW_NSO_1                |      1 |      1 |     2   (0)|      1 |00:00:00.05 |      10 |      7 |
|   3 |    NESTED LOOPS SEMI                   |                         |      1 |      1 |     2   (0)|      1 |00:00:00.05 |      10 |      7 |
|   4 |     TABLE ACCESS BY INDEX ROWID BATCHED| G_ELEMFI                |      1 |      2 |     1   (0)|      2 |00:00:00.03 |       4 |      3 |
|*  5 |      INDEX RANGE SCAN                  | G_ELEM_LIBEL_IDX        |      1 |      2 |     1   (0)|      2 |00:00:00.01 |       2 |      2 |
|*  6 |     INDEX UNIQUE SCAN                  | ELEMFI_TEXTE_PK         |      2 |      1 |     1   (0)|      1 |00:00:00.03 |       6 |      4 |
|   7 |   TABLE ACCESS BY INDEX ROWID BATCHED  | F_DETFAC                |      1 |   3499 |    50   (0)|     37 |00:00:03.87 |    4534 |   4524 |
|*  8 |    INDEX SKIP SCAN                     | AK_DFNUM_DFNOM_F_DETFAC |      1 |   3499 |    44   (0)|     37 |00:00:03.86 |    4507 |   4504 |
--------------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   1 - access("F"."DF_REL"="LIBELLE_20_1")
   5 - access("E"."LIBELLE_20_2"='LPIBU')
   6 - access("T"."REFELEM"="E"."REFELEM" AND "T"."REFTEXTE"=:REFTEXTE)
   8 - access("F"."DF_NOM"='LPIBU')
       filter("F"."DF_NOM"='LPIBU')

*/
/********************************OLD Metrics***************************************/

/********************************New SQL*******************************************/

var reftexte varchar2(32);
exec :reftexte := 'C0065MZH';
var refcli varchar2(32);
exec :refcli := 'A7902211';

select /*+ leading(t e f) index(t ELEMFI_TEXTE_REFTEXTE_IX) use_nl(e f) */
       distinct f.df_num || f.df_refinit || f.df_dos
  from g_elemfi_texte t,
       g_elemfi e,
       f_detfac f
 where t.reftexte = :reftexte
   and t.refelem = e.refelem
   and e.libelle_20_2 = 'LPIBU'
   and f.df_rel = e.libelle_20_1
   and f.df_nom = 'LPIBU'
   and f.df_cli = :refcli;   
/********************************New SQL*******************************************/
/********************************New Metrics***************************************/
/*
Plan hash value: 4294264395
----------------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                               | Name                     | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  |
----------------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                        |                          |      1 |        |     4 (100)|      1 |00:00:00.05 |     286 |     83 |
|   1 |  HASH UNIQUE                            |                          |      1 |      1 |     4  (25)|      1 |00:00:00.05 |     286 |     83 |
|   2 |   NESTED LOOPS                          |                          |      1 |      1 |     3   (0)|      1 |00:00:00.05 |     286 |     83 |
|   3 |    NESTED LOOPS                         |                          |      1 |      2 |     3   (0)|      1 |00:00:00.05 |     285 |     82 |
|   4 |     NESTED LOOPS                        |                          |      1 |      1 |     2   (0)|      1 |00:00:00.05 |     282 |     81 |
|   5 |      TABLE ACCESS BY INDEX ROWID BATCHED| G_ELEMFI_TEXTE           |      1 |     47 |     1   (0)|    219 |00:00:00.01 |       5 |      5 |
|*  6 |       INDEX RANGE SCAN                  | ELEMFI_TEXTE_REFTEXTE_IX |      1 |     47 |     1   (0)|    219 |00:00:00.01 |       3 |      3 |
|*  7 |      TABLE ACCESS BY INDEX ROWID        | G_ELEMFI                 |    219 |      1 |     1   (0)|      1 |00:00:00.05 |     277 |     76 |
|*  8 |       INDEX UNIQUE SCAN                 | EFI_REFELEM              |    219 |      1 |     1   (0)|    219 |00:00:00.01 |      58 |      4 |
|*  9 |     INDEX RANGE SCAN                    | DF_CLIREL                |      1 |      2 |     1   (0)|      1 |00:00:00.01 |       3 |      1 |
|  10 |    TABLE ACCESS BY INDEX ROWID          | F_DETFAC                 |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       1 |      1 |
----------------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   6 - access("T"."REFTEXTE"=:REFTEXTE)
   7 - filter(("E"."LIBELLE_20_1" IS NOT NULL AND "E"."LIBELLE_20_2"='LPIBU'))
   8 - access("T"."REFELEM"="E"."REFELEM")
   9 - access("F"."DF_CLI"=:REFCLI AND "F"."DF_REL"="E"."LIBELLE_20_1" AND "F"."DF_NOM"='LPIBU')  
*/
/********************************New Metrics***************************************/

/********************************Index statistics**********************************/

/********************************Other SQLs****************************************/          
/*

*/ 
/********************************Other SQLs****************************************/              
