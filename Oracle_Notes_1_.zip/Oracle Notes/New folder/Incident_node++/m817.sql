############# m817 #######Logical standby

[root@clv100556 ~]# dbspicao -m817 -r1


                    Report For Database DOMINOPS

                      Tue 23 Jun 2020 11:14:01 PM CEST

                    Metric UDM 0817 (Report 1)


     Hours
   Logical
   Standby
 is behind
----------
      3.25
	  
	  
	  [root@clv100556 ~]# dbspicao -m817 -r1


                    Report For Database DOMINOPS

                      Tue 23 Jun 2020 11:24:32 PM CEST

                    Metric UDM 0817 (Report 1)


     Hours
   Logical
   Standby
 is behind
----------
       .00 
	  
	  

1.Гледам в лога
2.Аплая дали е пуснат
3.През базата сравнявам по сикуенси кое се е аплайнало,ако няма липсваш сикуенс просто суитчвам няколко лога от праймарито и пак проверявам метриката
4.От праймарито ресторвам архайв лога,който липсва и гледам на стендбая да се аплайне
RMAN> restore archivelog sequence between 17033 and 17034; 


###### PHISICAL STANDBY / LOGICAL STANDBY ########
##### ORACLE 12C - LAST RECEIVED LAST APPLY ######

select al.thrd "Thread", almax "Last Seq Received", lhmax "Last Seq Applied"
from (select thread# thrd, max(sequence#) almax
      from v$archived_log
      where resetlogs_change#=(select resetlogs_change# from v$database)
      group by thread#) al,
     (select thread# thrd, max(sequence#) lhmax
      from v$log_history
      where first_time=(select max(first_time) from v$log_history)
      group by thread#) lh
where al.thrd = lh.thrd;


####
set lines 300
col REALTIME_APPLY for a15
select * from V$LOGSTDBY_STATE;	 


### CHECKING FOR MRP Process for apply #####
select process, client_process, sequence#, status, DELAY_MINS from V$managed_standby;
select GUARD_STATUS,OPEN_MODE,DATABASE_ROLE from v$database; 


#### da sledq apply-a ####

set linesize 400
COL TIMESTAMP for a30
COL DICT_BEGIN FORMAT A10
col FILE_NAME for a70
SET NUMF 9999999999999
SELECT FILE_NAME, SEQUENCE# AS SEQ#, NEXT_CHANGE#, to_char(TIMESTAMP, 'YYYY/MON/DD HH24:MI:SS') as TIMESTAMP,
DICT_BEGIN AS BEG, DICT_END AS END, THREAD# AS THR#, APPLIED FROM DBA_LOGSTDBY_LOG
ORDER BY SEQUENCE#; 