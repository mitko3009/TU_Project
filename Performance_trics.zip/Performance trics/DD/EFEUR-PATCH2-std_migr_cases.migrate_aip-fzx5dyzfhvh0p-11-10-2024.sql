/********************************************************************************
*********       E-mail subject: EFDE2DEV-1962
*********             Instance: Patch2
*********          Description: 
Problem:
The std_migr_cases.migrate_aip took ~50 minutes on Patch2 on 11/10/2024.

Analysis:
We checked the work of the std_migr_cases.migrate_aip on Patch2 and found that the TOP SQL fzx5dyzfhvh0p was responsible for 89% of the time.
This SQL was executed over 36k times for this period, and we suspect that it was executed more than once for one REFEXT.
We found and that there is better execution plan for this query, so we added hints to force Oralce to use better execution plan.

Suggestion:
1. Please add hints as it is shown in the New SQL section below.
2. Please check is it expected SQL fzx5dyzfhvh0p to be executed so many times.

*********               SQL_ID: fzx5dyzfhvh0p
*********      Program/Package: 
*********              Request: Ognyan Tonev
*********               Author: Dimitar Dimitrov
********* Received e-mail date: 11/10/2024
*********      Resolution date: 11/10/2024
*********  Trace old file here: \\epox\specifs\performance\tmp\
*********  Trace new file here:
***********************************************************************************/

/********************************OLD SQL*******************************************/

VAR B1 VARCHAR2(32);
EXEC :B1 := 'A600M0KW';
VAR B2 VARCHAR2(32);
EXEC :B2 := 'ATRADIUS';

SELECT DISTINCT T.REFINDIVIDU
  FROM T_INDIVIDU T, 
       T_INTERVENANTS DB, 
       T_INTERVENANTS TC
 WHERE T.SOCIETE = 'CR_INSURER'
   AND T.REFEXT = :B2
   AND DB.REFINDIVIDU = T.REFINDIVIDU
   AND TC.REFDOSS = DB.REFDOSS
   AND TC.REFTYPE = 'TC'
   AND TC.REFINDIVIDU = :B1;
/********************************OLD SQL*******************************************/
/********************************OLD Metrics***************************************/
/*
MODULE                           PROGRAM                                            CLIENT_ID       SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- -------------------------------------------------- --------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
std_migr_cases.migrate_abp       std_migration_robot                                                                                               ON CPU               2024/10/11 12:15:56  2024/10/11 12:35:14       17113              9056651 +000000000 00:19:17.629 35%
std_migr_cases.migrate_ese       std_migration_robot                                                                                               ON CPU               2024/10/11 12:36:19  2024/10/11 12:55:50       10514              10221883 +000000000 00:19:31.249 22%
std_migr_cases.migrate_ese       std_migration_robot                                                bu305u8bu65mc 2490382378                       enq: TX - row lock c 2024/10/11 12:36:22  2024/10/11 12:55:47        8685               568074 +000000000 00:19:25.244 18%
std_migr_cases.migrate_ddc       std_migration_robot                                                                                               ON CPU               2024/10/11 12:00:34  2024/10/11 12:04:42        4024              4365486 +000000000 00:04:07.331 8%
std_migr_cases.migrate_aip       std_migration_robot                                                                                354      28303 ON CPU               2024/10/11 12:07:55  2024/10/11 12:58:32        3010              9293435 +000000000 00:50:37.267 6%
std_migr_cases.migrate_inf       std_migration_robot                                                                               1041      14225 ON CPU               2024/10/11 12:15:56  2024/10/11 12:34:49        1061              9013415 +000000000 00:18:52.614 2%
std_migr_cases.migrate_asc       std_migration_robot                                                                                               ON CPU               2024/10/11 12:10:55  2024/10/11 12:12:01         901              6462694 +000000000 00:01:06.077 2%
                                                                                                                                                                                                                       
MODULE                           PROGRAM                                            CLIENT_ID       SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- -------------------------------------------------- --------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
std_migr_cases.migrate_aip       std_migration_robot                                                                                354      28303                      2024/10/11 12:07:55  2024/10/11 12:58:32        3031              9293435 +000000000 00:50:37.267 100%


MODULE                           PROGRAM                                            CLIENT_ID       SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- -------------------------------------------------- --------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
std_migr_cases.migrate_aip       std_migration_robot                                                                                354      28303 ON CPU               2024/10/11 12:07:55  2024/10/11 12:58:32        3010              9293435 +000000000 00:50:37.267 99%
std_migr_cases.migrate_aip       std_migration_robot                                                                                354      28303 log file switch comp 2024/10/11 12:11:16  2024/10/11 12:43:42           7                49193 +000000000 00:32:26.337 0%
std_migr_cases.migrate_aip       std_migration_robot                                                                                354      28303 log file switch (pri 2024/10/11 12:20:40  2024/10/11 12:31:29           7                26456 +000000000 00:10:49.893 0%
std_migr_cases.migrate_aip       std_migration_robot                                                                                354      28303 latch: shared pool   2024/10/11 12:16:51  2024/10/11 12:44:22           5                    1 +000000000 00:27:31.163 0%
std_migr_cases.migrate_aip       std_migration_robot                                                              3417776879        354      28303 row cache mutex      2024/10/11 12:19:27  2024/10/11 12:39:12           2                      +000000000 00:19:44.489 0%


MODULE                           PROGRAM                                            CLIENT_ID       SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- -------------------------------------------------- --------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
std_migr_cases.migrate_aip       std_migration_robot                                                fzx5dyzfhvh0p                   354      28303 ON CPU               2024/10/11 12:07:58  2024/10/11 12:58:29        2693                36170 +000000000 00:50:31.263 89%
std_migr_cases.migrate_aip       std_migration_robot                                                4r88c1b6s929d                   354      28303                      2024/10/11 12:07:59  2024/10/11 12:57:25          62                55418 +000000000 00:49:26.235 2%
std_migr_cases.migrate_aip       std_migration_robot                                                9skpg0zhhtpdr          0        354      28303 ON CPU               2024/10/11 12:08:27  2024/10/11 12:57:45          52                    1 +000000000 00:49:18.229 2%
std_migr_cases.migrate_aip       std_migration_robot                                                                       0        354      28303 ON CPU               2024/10/11 12:09:06  2024/10/11 12:51:51          16                      +000000000 00:42:44.941 1%


INSTANCE_NUMBER SQL_ID            ELAPSED MAX_WAIT_ON     PC_OF  WAIT_TIME            GETS      READS       ROWS  ELAP/EXEC       GETS/EXEC READS/EXEC  ROWS/EXEC       EXEC PLAN_HASH_VALUE
--------------- ------------- ----------- --------------- ----- ---------- --------------- ---------- ---------- ---------- --------------- ---------- ---------- ---------- ---------------
              1 fzx5dyzfhvh0p        2675 CPU             100%  2641.53606       409348372          0      36438        .07           11234          0          1      36438  2752307261
              

SQL_ID        SQL_PLAN_HASH_VALUE SQL_PLAN_LINE_ID SQL_PLAN_OPERATION             SQL_PLAN_OPTIONS                   ACTIVE
------------- ------------------- ---------------- ------------------------------ ------------------------------ ----------
fzx5dyzfhvh0p          2752307261                7 INDEX                          RANGE SCAN                            212
fzx5dyzfhvh0p          2752307261                6 INDEX                          RANGE SCAN                             22
fzx5dyzfhvh0p          2752307261                2 NESTED LOOPS                   SEMI                                   20
fzx5dyzfhvh0p          2752307261                3 NESTED LOOPS                                                           5
fzx5dyzfhvh0p          2752307261                5 INDEX                          RANGE SCAN                              1
fzx5dyzfhvh0p          2752307261                  SELECT STATEMENT                                                       1



SQL_ID           SNAP_ID INSTANCE_NUMBER NAME                   POSITION DUP_POSITION DATATYPE_STRING      VALUE_STRING                             INTERVAL
------------- ---------- --------------- -------------------- ---------- ------------ -------------------- ---------------------------------------- -----------------------
fzx5dyzfhvh0p         97               1 :B2                           1              VARCHAR2(128)        ATRADIUS                                 2024/10/11 13
fzx5dyzfhvh0p         97               1 :B1                           2              VARCHAR2(128)        A600M0KW                                 2024/10/11 13


Plan hash value: 2752307261
--------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                              | Name        | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  |
--------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                       |             |      1 |        |    13 (100)|      1 |00:00:00.22 |   18892 |     10 |
|   1 |  HASH UNIQUE                           |             |      1 |      1 |    13   (8)|      1 |00:00:00.22 |   18892 |     10 |
|   2 |   NESTED LOOPS SEMI                    |             |      1 |      1 |    12   (0)|    121 |00:00:00.22 |   18892 |     10 |
|   3 |    NESTED LOOPS                        |             |      1 |      3 |     6   (0)|  16165 |00:00:00.03 |     119 |      0 |
|   4 |     TABLE ACCESS BY INDEX ROWID BATCHED| T_INDIVIDU  |      1 |      1 |     4   (0)|      2 |00:00:00.01 |       5 |      0 |
|*  5 |      INDEX RANGE SCAN                  | SOC_INDIV   |      1 |      1 |     3   (0)|      2 |00:00:00.01 |       3 |      0 |
|*  6 |     INDEX RANGE SCAN                   | INT_INDIV   |      2 |      3 |     2   (0)|  16165 |00:00:00.02 |     114 |      0 |
|*  7 |    INDEX RANGE SCAN                    | INT_REFDOSS |  16165 |      2 |     2   (0)|    121 |00:00:00.17 |   18773 |     10 |
--------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   5 - access("T"."SOCIETE"='CR_INSURER' AND "T"."REFEXT"=:B2)
   6 - access("DB"."REFINDIVIDU"="T"."REFINDIVIDU")
   7 - access("TC"."REFDOSS"="DB"."REFDOSS" AND "TC"."REFTYPE"='TC' AND "TC"."REFINDIVIDU"=:B1)
*/
/********************************OLD Metrics***************************************/

/********************************New SQL*******************************************/

SELECT /*+ leading(TC DB T) use_nl(DB) use_hash(T) swap_join_inputs(T) */
       DISTINCT T.REFINDIVIDU
  FROM T_INDIVIDU T, 
       T_INTERVENANTS DB, 
       T_INTERVENANTS TC
 WHERE T.SOCIETE = 'CR_INSURER'
   AND T.REFEXT = :B2
   AND DB.REFINDIVIDU = T.REFINDIVIDU
   AND TC.REFDOSS = DB.REFDOSS
   AND TC.REFTYPE = 'TC'
   AND TC.REFINDIVIDU = :B1;
/********************************New SQL*******************************************/
/********************************New Metrics***************************************/
/*
Plan hash value: 965502014
------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                             | Name          | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers |
------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                      |               |      1 |        |   957 (100)|      1 |00:00:00.01 |     138 |
|   1 |  HASH UNIQUE                          |               |      1 |      1 |   957   (1)|      1 |00:00:00.01 |     138 |
|*  2 |   HASH JOIN                           |               |      1 |      1 |   956   (1)|    121 |00:00:00.01 |     138 |
|   3 |    TABLE ACCESS BY INDEX ROWID BATCHED| T_INDIVIDU    |      1 |      1 |     4   (0)|      2 |00:00:00.01 |       5 |
|*  4 |     INDEX RANGE SCAN                  | SOC_INDIV     |      1 |      1 |     3   (0)|      2 |00:00:00.01 |       3 |
|   5 |    NESTED LOOPS                       |               |      1 |   2082 |   952   (1)|   1083 |00:00:00.01 |     133 |
|*  6 |     INDEX RANGE SCAN                  | INT_INDIV     |      1 |    926 |     9   (0)|    361 |00:00:00.01 |       5 |
|*  7 |     INDEX RANGE SCAN                  | INT_DOS_INDIV |    361 |      2 |     2   (0)|   1083 |00:00:00.01 |     128 |
------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   2 - access("DB"."REFINDIVIDU"="T"."REFINDIVIDU")
   4 - access("T"."SOCIETE"='CR_INSURER' AND "T"."REFEXT"=:B2)
   6 - access("TC"."REFINDIVIDU"=:B1 AND "TC"."REFTYPE"='TC')
   7 - access("TC"."REFDOSS"="DB"."REFDOSS")   
   
*/
/********************************New Metrics***************************************/

/********************************Index statistics**********************************/

/********************************Other SQLs****************************************/          
/*

*/ 
/********************************Other SQLs****************************************/              
