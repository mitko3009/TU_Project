/********************************************************************************
*********       E-mail subject: SVBDEV-8101
*********             Instance: QA2
*********          Description: 
Problem:
Slowness in erf_batch WITHHOLDING_TAX during the EOM on SVB QA2.

Analysis:
After the analyze, we found that the TOP SQL, which was responsible for 97% of the time was 3vsnzdmwtfcry ( from inv_fixedcost_interests.pck ).
The problem of this query is that because of the OR operators, Oracle decided to start the execution with making full scan of table F_DETFAC, 
instead of accessing it through refdoss, which is the selective predicate.
We changed the query to use unions instead of the ORs, which will allow Oracle to start from the refdoss.

Suggestion:
Please change the query as it is shown in the New SQL section below.

*********               SQL_ID: 3vsnzdmwtfcry
*********      Program/Package: inv_fixedcost_interests.pck
*********              Request: Dimitare Ivanov
*********               Author: Dimitar Dimitrov
********* Received e-mail date: 07/08/2024
*********      Resolution date: 08/08/2024
*********  Trace old file here: \\epox\specifs\performance\tmp\
*********  Trace new file here:
***********************************************************************************/

/********************************OLD SQL*******************************************/

VAR B1 VARCHAR2(32);
EXEC :B1 := '1604060001';
VAR B2 VARCHAR2(32);
EXEC :B2 := 'N';
VAR B3 NUMBER);
EXEC :B3 := 2460523;

SELECT DF_NUM,
       DF_DOS,
       DF_NOM,
       DF_CLI,
       ( SELECT PAYS 
           FROM G_INDIVIDU 
          WHERE REFINDIVIDU = DF_CLI ) COUNTERPARTCOUNTRY,
       DF_MONHT_DOS,
       DECODE(DF_ANN, NULL, 0, 1) ISCOSTANN,
       DECODE(DF_SEN, 'D', 'WTHC', 'WTHD') INVOICEITEM,
       CATEGDOSS,
       DEVISE,
       FACT_INV.GETCLIENT(DF_DOS) INDIVIDUCL,
       DF_DAT ORIGINALITEMDATE,
       DF_REL,
       REFFACTOR
  FROM F_DETFAC COSTS, 
       G_DOSSIER CASES, 
       G_PIECE IND
 WHERE (:B1 = 'ALL' OR
       (:B1 <> 'ALL' AND ( ( :B2 = 'O' 
                          AND DF_DOS IN ( SELECT REFDOSS
                                            FROM G_DOSSIER
                                      START WITH REFDOSS = :B1
                                         CONNECT BY PRIOR REFLOT = REFDOSS
                                                       OR PRIOR REFHIERARCHIE = REFDOSS
                                           UNION
                                          SELECT REFDOSS
                                            FROM G_DOSSIER
                                      START WITH REFDOSS = :B1
                                         CONNECT BY PRIOR REFDOSS = REFLOT
                                                       OR PRIOR REFDOSS = REFHIERARCHIE) )
                      OR (  :B2 = 'N' 
                        AND DF_DOS = :B1 ))))
   AND ( ( COSTS.DF_ANN IS NULL 
   	   AND NOT EXISTS ( SELECT 1
                          FROM F_DETFAC F
                         WHERE F.DF_REFINIT = COSTS.DF_NUM
                           AND F.DF_NOM IN ('WTHC', 'WTHD', 'WTHRE')
                           AND F.DF_DOS = COSTS.DF_DOS
                           AND F.DF_ANN IS NULL ) 
           AND EXISTS ( SELECT 1
                          FROM G_INTERET
                         WHERE TYPE = 'W'
                           AND TYPEPER = CASES.REFFACTOR
                           AND PAYS =
                               (SELECT PAYS FROM G_INDIVIDU WHERE REFINDIVIDU = DF_CLI)
                           AND REFELEM = COSTS.DF_NOM
                           AND DTDEBUT <= :B3) )
       OR ( COSTS.DF_ANN IS NOT NULL 
       	 AND EXISTS ( SELECT 1
                        FROM F_DETFAC F
                       WHERE F.DF_REFINIT = COSTS.DF_NUM
                         AND F.DF_NOM IN ('WTHC', 'WTHD', 'WTHRE')
                         AND F.DF_DOS = COSTS.DF_DOS
                         AND F.DF_ANN IS NULL ) ) )
   AND ( ( EXISTS ( SELECT DTDEBUT
                      FROM G_INTERET
                     WHERE TYPE = 'W'
                       AND TYPEPER = CASES.REFFACTOR
                       AND PAYS =
                           (SELECT PAYS FROM G_INDIVIDU WHERE REFINDIVIDU = DF_CLI)
                       AND REFELEM = COSTS.DF_NOM
                       AND DTDEBUT <= :B3) AND DF_NOM != 'FUE') OR DF_NOM = 'FUE')
   AND DF_REL IS NOT NULL
   AND UPPER(DF_NOM) NOT LIKE 'WT%'
   AND DF_DOS = CASES.REFDOSS
   AND CATEGDOSS NOT LIKE 'FP COMPTE%'
   AND CATEGDOSS NOT LIKE 'COMPTE FP%'
   AND IND.GPIHEURE(+) = DF_CLI
   AND IND.TYPPIECE(+) = 'CLIENT_PARAMS'
   AND NVL(IND.FG25, 'N') = 'N'
 ORDER BY DF_DOS, DF_CLI, DF_NOM;
/********************************OLD SQL*******************************************/
/********************************OLD Metrics***************************************/
/*
MODULE                           PROGRAM                                            SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                   ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- -------------------------------------------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
erf_batch                        erf_batch                                                                          675      20368 ON CPU               2024/07/31 22:48:11  2024/07/31 23:05:52     105                  916 +000000000 00:17:40.503 30%
imxbatch_OverspendContract                                                                                                         db file sequential r 2024/07/31 23:07:12  2024/07/31 23:08:33      49                   49 +000000000 00:01:20.794 14%
imxbatch_OverspendContract                                                                        3527021828                       direct path read     2024/07/31 23:07:12  2024/07/31 23:08:13      41                    1 +000000000 00:01:00.794 12%
DBMS_SCHEDULER                   oracle                                                                             758      45263 ON CPU               2024/07/31 22:45:01  2024/07/31 22:51:41      40                   16 +000000000 00:06:40.127 11%
imxbatch_OverspendContract                                                                                                         ON CPU               2024/07/31 23:07:22  2024/07/31 23:08:53      18                  136 +000000000 00:01:30.794 5%
imxbatch_DecompteValidation      imxbatch                                                                                          db file sequential r 2024/07/31 23:06:22  2024/07/31 23:06:42      15               733084 +000000000 00:00:20.000 4%
imxbatch_Ddebit_CBS              imxbatch                                                         2373210702                       db file parallel rea 2024/07/31 23:07:12  2024/07/31 23:09:03      10                    1 +000000000 00:01:50.794 3%
imxbatch_Syndication             imxbatch                                                                                          ON CPU               2024/07/31 23:09:53  2024/07/31 23:09:53       9                      +000000000 00:00:00.000 3%
imxbatch_Ddebit_CBS              imxbatch                                                         2373210702                       read by other sessio 2024/07/31 23:07:22  2024/07/31 23:09:23       9                    1 +000000000 00:02:00.795 3%
imxbatch_Ddebit_CBS              imxbatch                                                         2373210702                       db file sequential r 2024/07/31 23:07:32  2024/07/31 23:09:23       8                    1 +000000000 00:01:50.795 2%
                                 oracle                                                                    0        412      45386 log file parallel wr 2024/07/31 22:49:01  2024/07/31 23:09:33       6                      +000000000 00:20:31.298 2%
imxbatch_DecompteValidation      imxbatch                                                                                          ON CPU               2024/07/31 23:06:22  2024/07/31 23:06:42       6                  994 +000000000 00:00:20.000 2%
imxbatch_bkg_calcEoMinterAccreu  imxbatch                                                                           597       2306 ON CPU               2024/07/31 22:45:21  2024/07/31 22:46:11       3                12970 +000000000 00:00:50.000 1%
SQL*Plus                         sqlplus                                                                                           ON CPU               2024/07/31 22:51:01  2024/07/31 23:07:42       3                    1 +000000000 00:16:40.502 1%
ftr_batch_FTR_CTRA_INVOICE       ftr_batch                                                                           87       9561 ON CPU               2024/07/31 22:47:11  2024/07/31 22:47:31       3                  580 +000000000 00:00:20.001 1%
msgq_memo_decompte                                                                                                                 db file sequential r 2024/07/31 22:45:31  2024/07/31 22:46:21       3                  886 +000000000 00:00:50.000 1%
imxbatch_Ddebit_CBS              imxbatch                                                                                          ON CPU               2024/07/31 23:07:12  2024/07/31 23:09:33       2                    1 +000000000 00:02:20.795 1%
imxbatch_RealAvailabilityCalcula imxbatch                                                         2717032163                       ON CPU               2024/07/31 23:07:12  2024/07/31 23:07:12       2                      +000000000 00:00:00.000 1%
tion

ftr_batch_FTR_CTRA_INVOICE       ftr_batch                                          0gwb94x4hsxaw 2963296158         87       9561 db file scattered re 2024/07/31 22:46:51  2024/07/31 22:47:01       2                    2 +000000000 00:00:10.000 1%
svb_imx_elcm                     svb_imx_elcm                                       5m6dw83dgfr02  389324436         90      58505 db file scattered re 2024/07/31 23:09:53  2024/07/31 23:09:53       1                    1 +000000000 00:00:00.000 0%
msgq_memo_decompte               msg_q02                                            9nbcax5qhkhcs  885344617          9      40294 enq: TX - row lock c 2024/07/31 22:45:31  2024/07/31 22:45:31       1                    1 +000000000 00:00:00.000 0%
msgq_memo_decompte               msg_q02                                            4v0hd0vkhv4vq 1008617661          9      40294 ON CPU               2024/07/31 22:46:21  2024/07/31 22:46:21       1                    1 +000000000 00:00:00.000 0%
DBMS_SCHEDULER                   oracle                                             5a5z8v12z95m9 2892286335        758      45263 db file scattered re 2024/07/31 22:50:11  2024/07/31 22:50:11       1                    1 +000000000 00:00:00.000 0%
imxbatch_DecompteValidation      imxbatch                                           53u435j008d29 3903800917        597      27291 db file parallel rea 2024/07/31 23:06:42  2024/07/31 23:06:42       1                    1 +000000000 00:00:00.000 0%
msgq_variab                      msg_q02                                            32jx5qk13rpn7  130842590          9      60710 ON CPU               2024/07/31 23:08:43  2024/07/31 23:08:43       1                    1 +000000000 00:00:00.000 0%
MMON_SLAVE                       oracle                                             6hnhqahphpk8n  486334127        417      58154 Sync ASM rebalance   2024/07/31 23:08:13  2024/07/31 23:08:13       1                    1 +000000000 00:00:00.000 0%
imxbatch_bkg_calcEoMinterAccreu  imxbatch                                           ggahfrmd49j66 2665555235        597       2306 enq: TX - index cont 2024/07/31 22:45:11  2024/07/31 22:45:11       1                    1 +000000000 00:00:00.000 0%
service_bus_broker               service_bus_broker                                 9rj3cjp9nbxjk          0        332      31796 ON CPU               2024/07/31 22:53:31  2024/07/31 22:53:31       1                      +000000000 00:00:00.000 0%
imxbatch_RealAvailabilityCalcula imxbatch                                                                  0         93      31180 log file sync        2024/07/31 23:07:32  2024/07/31 23:07:32       1                      +000000000 00:00:00.000 0%
tion

imxbatch_RealAvailabilityCalcula imxbatch                                           1uh2wfx2ha1y9 2717032163         93      31180 db file sequential r 2024/07/31 23:07:22  2024/07/31 23:07:22       1                    1 +000000000 00:00:00.000 0%
tion

                                 oracle                                                                    0        329      39073 ON CPU               2024/07/31 22:52:11  2024/07/31 22:52:11       1                      +000000000 00:00:00.000 0%
ftr_batch_FTR_LOAN_INVOICE       ftr_batch                                          662ng1z0ha7qh          0        680       7399 db file sequential r 2024/07/31 22:45:11  2024/07/31 22:45:11       1                    1 +000000000 00:00:00.000 0%
erf_batch                        erf_batch                                          fmkavgaw00gbq 1713439851        675      20368 db file sequential r 2024/07/31 22:53:11  2024/07/31 22:53:11       1                    1 +000000000 00:00:00.000 0%
ftr_batch_FTR_LOAN_INVOICE       ftr_batch                                          4rp5caxqbg6ra 1961383628        680       7399 ON CPU               2024/07/31 22:45:21  2024/07/31 22:45:21       1                    1 +000000000 00:00:00.000 0%
 
 
 
MODULE                           PROGRAM                                            SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- -------------------------------------------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
erf_batch                        erf_batch                                                                          675      20368 ON CPU               2024/07/31 22:48:11  2024/07/31 23:05:52         105                  916 +000000000 00:17:40.503 99%
erf_batch                        erf_batch                                          fmkavgaw00gbq 1713439851        675      20368 db file sequential r 2024/07/31 22:53:11  2024/07/31 22:53:11           1                    1 +000000000 00:00:00.000 1%
 

MODULE                           PROGRAM                                            SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- -------------------------------------------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
erf_batch                        erf_batch                                          3vsnzdmwtfcry  599546177        675      20368 ON CPU               2024/07/31 22:48:11  2024/07/31 23:05:52         103                  916 +000000000 00:17:40.503 97%
erf_batch                        erf_batch                                          b5tg3zbh3734z          0        675      20368 ON CPU               2024/07/31 22:49:01  2024/07/31 22:55:41           2                  345 +000000000 00:06:40.215 2%
erf_batch                        erf_batch                                          fmkavgaw00gbq 1713439851        675      20368 db file sequential r 2024/07/31 22:53:11  2024/07/31 22:53:11           1                    1 +000000000 00:00:00.000 1%


INSTANCE_NUMBER SQL_ID            ELAPSED MAX_WAIT_ON     PC_OF  WAIT_TIME            GETS      READS       ROWS  ELAP/EXEC       GETS/EXEC READS/EXEC  ROWS/EXEC       EXEC PLAN_HASH_VALUE
--------------- ------------- ----------- --------------- ----- ---------- --------------- ---------- ---------- ---------- --------------- ---------- ---------- ---------- ---------------
              1 3vsnzdmwtfcry        1031 CPU             100%  1029.77709       805008841        101       2446       1.12          876916        .11       2.66        918   599546177




SQL_ID        SQL_PLAN_HASH_VALUE SQL_PLAN_LINE_ID SQL_PLAN_OPERATION             SQL_PLAN_OPTIONS                   ACTIVE
------------- ------------------- ---------------- ------------------------------ ------------------------------ ----------
3vsnzdmwtfcry           599546177               11 INDEX                          RANGE SCAN                             23
3vsnzdmwtfcry           599546177               13 TABLE ACCESS                   BY INDEX ROWID                         14
3vsnzdmwtfcry           599546177               10 TABLE ACCESS                   BY INDEX ROWID BATCHED                 12
3vsnzdmwtfcry           599546177                9 TABLE ACCESS                   FULL                                    8
3vsnzdmwtfcry           599546177               12 INDEX                          UNIQUE SCAN                             7
3vsnzdmwtfcry           599546177                4 FILTER                                                                 7
3vsnzdmwtfcry           599546177               22 INDEX                          UNIQUE SCAN                             7
3vsnzdmwtfcry           599546177               19 TABLE ACCESS                   BY INDEX ROWID BATCHED                  7
3vsnzdmwtfcry           599546177               20 INDEX                          RANGE SCAN                              6
3vsnzdmwtfcry           599546177               17 INDEX                          RANGE SCAN                              3
3vsnzdmwtfcry           599546177               18 FILTER                                                                 2
3vsnzdmwtfcry           599546177               21 TABLE ACCESS                   BY INDEX ROWID                          2
3vsnzdmwtfcry           599546177                5 NESTED LOOPS                                                           2
3vsnzdmwtfcry           599546177                  SELECT STATEMENT                                                       1
3vsnzdmwtfcry           599546177               15 INDEX                          RANGE SCAN                              1
3vsnzdmwtfcry           599546177               16 TABLE ACCESS                   BY INDEX ROWID BATCHED                  1


Plan hash value: 599546177
------------------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                  | Name                    | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  |
------------------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                           |                         |      1 |        | 11561 (100)|      1 |00:00:06.27 |     881K|   6448 |
|   1 |  TABLE ACCESS BY INDEX ROWID               | G_INDIVIDU              |      1 |      1 |     2   (0)|      1 |00:00:00.01 |       4 |      0 |
|*  2 |   INDEX UNIQUE SCAN                        | IND_REFINDIV            |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |      0 |
|   3 |  SORT ORDER BY                             |                         |      1 |      1 | 11561   (1)|      1 |00:00:06.27 |     881K|   6448 |
|*  4 |   FILTER                                   |                         |      1 |        |            |      1 |00:00:06.24 |     879K|   6447 |
|   5 |    NESTED LOOPS                            |                         |      1 |   3437 | 11559   (1)|  66744 |00:00:04.11 |     599K|   4931 |
|   6 |     NESTED LOOPS                           |                         |      1 |   3437 | 11559   (1)|  66755 |00:00:03.88 |     461K|   4931 |
|*  7 |      FILTER                                |                         |      1 |        |            |  66755 |00:00:03.72 |     330K|   4931 |
|   8 |       NESTED LOOPS OUTER                   |                         |      1 |   3436 |  8120   (1)|  66954 |00:00:03.70 |     330K|   4931 |
|*  9 |        TABLE ACCESS FULL                   | F_DETFAC                |      1 |   3454 |  1208   (1)|  66954 |00:00:00.93 |    4409 |   2671 |
|  10 |        TABLE ACCESS BY INDEX ROWID BATCHED | G_PIECE                 |  66954 |      1 |     2   (0)|  66843 |00:00:02.74 |     325K|   2260 |
|* 11 |         INDEX RANGE SCAN                   | GP_GRTYPE_MT_DT         |  66954 |      1 |     2   (0)|  66843 |00:00:00.80 |     199K|    700 |
|* 12 |      INDEX UNIQUE SCAN                     | DOS_REFDOSS             |  66755 |      1 |     1   (0)|  66755 |00:00:00.14 |     131K|      0 |
|* 13 |     TABLE ACCESS BY INDEX ROWID            | G_DOSSIER               |  66755 |      1 |     1   (0)|  66744 |00:00:00.20 |     138K|      0 |
|* 14 |    TABLE ACCESS BY INDEX ROWID BATCHED     | F_DETFAC                |   4732 |      1 |     2   (0)|      0 |00:00:00.01 |    5372 |      4 |
|* 15 |     INDEX RANGE SCAN                       | F_DETFAC_DF_REFINIT_IDX |   4732 |      1 |     1   (0)|     34 |00:00:00.01 |    5338 |      1 |
|* 16 |    TABLE ACCESS BY INDEX ROWID BATCHED     | F_DETFAC                |  62012 |      1 |     2   (0)|   2033 |00:00:00.28 |   67683 |    189 |
|* 17 |     INDEX RANGE SCAN                       | F_DETFAC_DF_REFINIT_IDX |  62012 |      1 |     1   (0)|   2052 |00:00:00.09 |   65631 |      9 |
|* 18 |    FILTER                                  |                         |  53402 |        |            |   2120 |00:00:01.71 |     197K|   1323 |
|* 19 |     TABLE ACCESS BY INDEX ROWID BATCHED    | G_INTERET               |  53402 |      1 |     1   (0)|  47446 |00:00:00.17 |     106K|      1 |
|* 20 |      INDEX RANGE SCAN                      | INTERET_REF_TYPE        |  53402 |      2 |     1   (0)|    129K|00:00:00.09 |   53407 |      1 |
|  21 |     TABLE ACCESS BY INDEX ROWID            | G_INDIVIDU              |  30289 |      1 |     2   (0)|  30289 |00:00:01.51 |   91068 |   1322 |
|* 22 |      INDEX UNIQUE SCAN                     | IND_REFINDIV            |  30289 |      1 |     1   (0)|  30289 |00:00:00.07 |   60580 |      1 |
|* 23 |    FILTER                                  |                         |   1478 |        |            |   1478 |00:00:00.01 |    8625 |      0 |
|* 24 |     TABLE ACCESS BY INDEX ROWID BATCHED    | G_INTERET               |   1478 |      1 |     1   (0)|   2954 |00:00:00.01 |    4437 |      0 |
|* 25 |      INDEX RANGE SCAN                      | INTERET_REF_TYPE        |   1478 |      2 |     1   (0)|   7384 |00:00:00.01 |    1483 |      0 |
|  26 |     TABLE ACCESS BY INDEX ROWID            | G_INDIVIDU              |   1395 |      1 |     2   (0)|   1395 |00:00:00.01 |    4188 |      0 |
|* 27 |      INDEX UNIQUE SCAN                     | IND_REFINDIV            |   1395 |      1 |     1   (0)|   1395 |00:00:00.01 |    2792 |      0 |
|  28 |    SORT UNIQUE                             |                         |      0 |    405 |   156   (3)|      0 |00:00:00.01 |       0 |      0 |
|  29 |     UNION-ALL                              |                         |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|* 30 |      FILTER                                |                         |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  31 |       CONNECT BY WITH FILTERING (UNIQUE)   |                         |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  32 |        TABLE ACCESS BY INDEX ROWID         | G_DOSSIER               |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 33 |         INDEX UNIQUE SCAN                  | DOS_REFDOSS             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|  34 |        NESTED LOOPS                        |                         |      0 |      2 |     7   (0)|      0 |00:00:00.01 |       0 |      0 |
|  35 |         CONNECT BY PUMP                    |                         |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  36 |         TABLE ACCESS BY INDEX ROWID BATCHED| G_DOSSIER               |      0 |      2 |     7   (0)|      0 |00:00:00.01 |       0 |      0 |
|  37 |          BITMAP CONVERSION TO ROWIDS       |                         |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  38 |           BITMAP OR                        |                         |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  39 |            BITMAP CONVERSION FROM ROWIDS   |                         |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|* 40 |             INDEX RANGE SCAN               | DOS_REFDOSS             |      0 |        |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|  41 |            BITMAP CONVERSION FROM ROWIDS   |                         |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|* 42 |             INDEX RANGE SCAN               | DOS_REFDOSS             |      0 |        |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 43 |      FILTER                                |                         |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  44 |       CONNECT BY WITH FILTERING (UNIQUE)   |                         |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  45 |        TABLE ACCESS BY INDEX ROWID         | G_DOSSIER               |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 46 |         INDEX UNIQUE SCAN                  | DOS_REFDOSS             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|  47 |        NESTED LOOPS                        |                         |      0 |    401 |   144   (2)|      0 |00:00:00.01 |       0 |      0 |
|  48 |         CONNECT BY PUMP                    |                         |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|* 49 |         TABLE ACCESS BY INDEX ROWID BATCHED| G_DOSSIER               |      0 |    401 |   144   (2)|      0 |00:00:00.01 |       0 |      0 |
|  50 |          BITMAP CONVERSION TO ROWIDS       |                         |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  51 |           BITMAP OR                        |                         |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  52 |            BITMAP CONVERSION FROM ROWIDS   |                         |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  53 |             SORT ORDER BY                  |                         |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|* 54 |              INDEX RANGE SCAN              | DOSS_LOT                |      0 |        |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|  55 |            BITMAP CONVERSION FROM ROWIDS   |                         |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  56 |             SORT ORDER BY                  |                         |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|* 57 |              INDEX RANGE SCAN              | REFHIERARCHIE_IDX       |      0 |        |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
------------------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   2 - access("REFINDIVIDU"=:B1)
   4 - filter(((("COSTS"."DF_ANN" IS NOT NULL AND  IS NOT NULL) OR ("COSTS"."DF_ANN" IS NULL AND  IS NULL AND  IS NOT NULL)) AND
              ("DF_NOM"='FUE' OR ("DF_NOM"<>'FUE' AND  IS NOT NULL)) AND (:B1='ALL' OR (:B1<>'ALL' AND (("DF_DOS"=:B1 AND :B2='N') OR (:B2='O' AND  IS NOT
              NULL))))))
   7 - filter(NVL("IND"."FG25",'N')='N')
   9 - filter(("DF_REL" IS NOT NULL AND UPPER("DF_NOM") NOT LIKE 'WT%'))
  11 - access("IND"."TYPPIECE"='CLIENT_PARAMS' AND "IND"."GPIHEURE"="DF_CLI")
       filter("IND"."GPIHEURE" IS NOT NULL)
  12 - access("DF_DOS"="CASES"."REFDOSS")
  13 - filter(("CATEGDOSS" NOT LIKE 'FP COMPTE%' AND "CATEGDOSS" NOT LIKE 'COMPTE FP%'))
  14 - filter(("F"."DF_DOS"=:B1 AND "F"."DF_ANN" IS NULL))
  15 - access("F"."DF_REFINIT"=:B1)
       filter(("F"."DF_NOM"='WTHC' OR "F"."DF_NOM"='WTHD' OR "F"."DF_NOM"='WTHRE'))
  16 - filter(("F"."DF_DOS"=:B1 AND "F"."DF_ANN" IS NULL))
  17 - access("F"."DF_REFINIT"=:B1)
       filter(("F"."DF_NOM"='WTHC' OR "F"."DF_NOM"='WTHD' OR "F"."DF_NOM"='WTHRE'))
  18 - filter("PAYS"=)
  19 - filter(("TYPEPER"=:B1 AND "DTDEBUT"<=:B3))
  20 - access("REFELEM"=:B1 AND "TYPE"='W')
  22 - access("REFINDIVIDU"=:B1)
  23 - filter("PAYS"=)
  24 - filter(("TYPEPER"=:B1 AND "DTDEBUT"<=:B3))
  25 - access("REFELEM"=:B1 AND "TYPE"='W')
  27 - access("REFINDIVIDU"=:B1)
  30 - filter("REFDOSS"=:B1)
  33 - access("REFDOSS"=:B1)
  40 - access("connect$_by$_pump$_006"."PRIOR REFLOT "="REFDOSS")
  42 - access("connect$_by$_pump$_006"."PRIOR REFHIERARCHIE "="REFDOSS")
  43 - filter("REFDOSS"=:B1)
  46 - access("REFDOSS"=:B1)
  49 - filter(("connect$_by$_pump$_012"."PRIOR REFDOSS "="REFLOT" OR ("connect$_by$_pump$_012"."PRIOR REFDOSS "="REFHIERARCHIE" AND
              "REFHIERARCHIE" IS NOT NULL)))
  54 - access("connect$_by$_pump$_012"."PRIOR REFDOSS "="REFLOT")
       filter("connect$_by$_pump$_012"."PRIOR REFDOSS "="REFLOT")
  57 - access("connect$_by$_pump$_012"."PRIOR REFDOSS "="REFHIERARCHIE")
       filter(("REFHIERARCHIE" IS NOT NULL AND "connect$_by$_pump$_012"."PRIOR REFDOSS "="REFHIERARCHIE"))
*/
/********************************OLD Metrics***************************************/

/********************************New SQL*******************************************/

SELECT DF_NUM,
       DF_DOS,
       DF_NOM,
       DF_CLI,
       ( SELECT PAYS 
           FROM G_INDIVIDU 
          WHERE REFINDIVIDU = DF_CLI ) COUNTERPARTCOUNTRY,
       DF_MONHT_DOS,
       DECODE(DF_ANN, NULL, 0, 1) ISCOSTANN,
       DECODE(DF_SEN, 'D', 'WTHC', 'WTHD') INVOICEITEM,
       CATEGDOSS,
       DEVISE,
       FACT_INV.GETCLIENT(DF_DOS) INDIVIDUCL,
       DF_DAT ORIGINALITEMDATE,
       DF_REL,
       REFFACTOR
  FROM (SELECT DF.*
          FROM F_DETFAC DF
         WHERE :B1 = 'ALL'
        UNION  
        SELECT DF.*
          FROM F_DETFAC DF
         WHERE :B1 <> 'ALL'
           AND :B2 = 'N' 
           AND DF_DOS = :B1
         UNION   
        SELECT /*+ leading(DOS) use_nl(DF)*/
               DF.*
          FROM F_DETFAC DF,
               ( SELECT REFDOSS
                   FROM G_DOSSIER
                  START WITH REFDOSS = :B1
                CONNECT BY PRIOR REFLOT = REFDOSS
                UNION                                                       
                 SELECT REFDOSS
                   FROM G_DOSSIER
                  START WITH REFDOSS = :B1
                CONNECT BY PRIOR REFHIERARCHIE = REFDOSS
                UNION
                 SELECT REFDOSS
                   FROM G_DOSSIER
                  START WITH REFDOSS = :B1
                CONNECT BY PRIOR REFDOSS = REFLOT
                UNION                                                       
                 SELECT REFDOSS
                   FROM G_DOSSIER
                  START WITH REFDOSS = :B1
                CONNECT BY PRIOR REFDOSS = REFHIERARCHIE ) DOS       
          WHERE :B1 <> 'ALL'
            AND :B2 = 'O'
            AND DF_DOS = DOS.REFDOSS  ) COSTS, 
       G_DOSSIER CASES, 
       G_PIECE IND
 WHERE 1 = 1
   AND ( ( COSTS.DF_ANN IS NULL 
   	   AND NOT EXISTS ( SELECT 1
                          FROM F_DETFAC F
                         WHERE F.DF_REFINIT = COSTS.DF_NUM
                           AND F.DF_NOM IN ('WTHC', 'WTHD', 'WTHRE')
                           AND F.DF_DOS = COSTS.DF_DOS
                           AND F.DF_ANN IS NULL ) 
           AND EXISTS ( SELECT 1
                          FROM G_INTERET
                         WHERE TYPE = 'W'
                           AND TYPEPER = CASES.REFFACTOR
                           AND PAYS =
                               (SELECT PAYS FROM G_INDIVIDU WHERE REFINDIVIDU = DF_CLI)
                           AND REFELEM = COSTS.DF_NOM
                           AND DTDEBUT <= :B3) )
       OR ( COSTS.DF_ANN IS NOT NULL 
       	 AND EXISTS ( SELECT 1
                        FROM F_DETFAC F
                       WHERE F.DF_REFINIT = COSTS.DF_NUM
                         AND F.DF_NOM IN ('WTHC', 'WTHD', 'WTHRE')
                         AND F.DF_DOS = COSTS.DF_DOS
                         AND F.DF_ANN IS NULL ) ) )
   AND ( ( EXISTS ( SELECT DTDEBUT
                      FROM G_INTERET
                     WHERE TYPE = 'W'
                       AND TYPEPER = CASES.REFFACTOR
                       AND PAYS =
                           (SELECT PAYS FROM G_INDIVIDU WHERE REFINDIVIDU = DF_CLI)
                       AND REFELEM = COSTS.DF_NOM
                       AND DTDEBUT <= :B3) AND DF_NOM != 'FUE') OR DF_NOM = 'FUE')
   AND DF_REL IS NOT NULL
   AND UPPER(DF_NOM) NOT LIKE 'WT%'
   AND DF_DOS = CASES.REFDOSS
   AND CATEGDOSS NOT LIKE 'FP COMPTE%'
   AND CATEGDOSS NOT LIKE 'COMPTE FP%'
   AND IND.GPIHEURE(+) = DF_CLI
   AND IND.TYPPIECE(+) = 'CLIENT_PARAMS'
   AND NVL(IND.FG25, 'N') = 'N'
 ORDER BY DF_DOS, DF_CLI, DF_NOM;
/********************************New SQL*******************************************/
/********************************New Metrics***************************************/
/*
Plan hash value: 4276319954
-----------------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                        | Name                      | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers |
-----------------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                                 |                           |      1 |        |  1966 (100)|      1 |00:00:00.01 |      91 |
|   1 |  TABLE ACCESS BY INDEX ROWID                     | G_INDIVIDU                |      1 |      1 |     2   (0)|      1 |00:00:00.01 |       4 |
|*  2 |   INDEX UNIQUE SCAN                              | IND_REFINDIV              |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |
|   3 |  SORT ORDER BY                                   |                           |      1 |      1 |  1966   (1)|      1 |00:00:00.01 |      91 |
|*  4 |   FILTER                                         |                           |      1 |        |            |      1 |00:00:00.01 |      80 |
|*  5 |    FILTER                                        |                           |      1 |        |            |      5 |00:00:00.01 |      49 |
|   6 |     NESTED LOOPS OUTER                           |                           |      1 |    193 |  1964   (1)|      5 |00:00:00.01 |      49 |
|   7 |      NESTED LOOPS                                |                           |      1 |    194 |  1576   (1)|      5 |00:00:00.01 |      26 |
|   8 |       VIEW                                       |                           |      1 |   3800 |  2084   (1)|      5 |00:00:00.01 |       8 |
|   9 |        SORT UNIQUE                               |                           |      1 |   3800 |  2084   (1)|      5 |00:00:00.01 |       8 |
|  10 |         UNION-ALL                                |                           |      1 |        |            |      5 |00:00:00.01 |       8 |
|* 11 |          FILTER                                  |                           |      1 |        |            |      0 |00:00:00.01 |       0 |
|* 12 |           TABLE ACCESS FULL                      | F_DETFAC                  |      0 |   3454 |  1209   (1)|      0 |00:00:00.01 |       0 |
|* 13 |          FILTER                                  |                           |      1 |        |            |      5 |00:00:00.01 |       8 |
|* 14 |           TABLE ACCESS BY INDEX ROWID BATCHED    | F_DETFAC                  |      1 |      1 |     2   (0)|      5 |00:00:00.01 |       8 |
|* 15 |            INDEX RANGE SCAN                      | DETFAC_DOS                |      1 |      1 |     2   (0)|      5 |00:00:00.01 |       3 |
|* 16 |          FILTER                                  |                           |      1 |        |            |      0 |00:00:00.01 |       0 |
|  17 |           NESTED LOOPS                           |                           |      0 |    345 |   635   (1)|      0 |00:00:00.01 |       0 |
|  18 |            NESTED LOOPS                          |                           |      0 |    408 |   635   (1)|      0 |00:00:00.01 |       0 |
|  19 |             VIEW                                 |                           |      0 |    408 |    23  (22)|      0 |00:00:00.01 |       0 |
|  20 |              SORT UNIQUE                         |                           |      0 |    408 |    23  (22)|      0 |00:00:00.01 |       0 |
|  21 |               UNION-ALL                          |                           |      0 |        |            |      0 |00:00:00.01 |       0 |
|* 22 |                CONNECT BY WITH FILTERING (UNIQUE)|                           |      0 |        |            |      0 |00:00:00.01 |       0 |
|* 23 |                 INDEX RANGE SCAN                 | DOS_REFDOSS_REFLOT_IDX    |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |
|  24 |                 NESTED LOOPS                     |                           |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|  25 |                  CONNECT BY PUMP                 |                           |      0 |        |            |      0 |00:00:00.01 |       0 |
|* 26 |                  INDEX RANGE SCAN                | DOS_REFDOSS_REFLOT_IDX    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 27 |                CONNECT BY WITH FILTERING (UNIQUE)|                           |      0 |        |            |      0 |00:00:00.01 |       0 |
|  28 |                 TABLE ACCESS BY INDEX ROWID      | G_DOSSIER                 |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |
|* 29 |                  INDEX UNIQUE SCAN               | DOS_REFDOSS               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|  30 |                 NESTED LOOPS                     |                           |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|  31 |                  CONNECT BY PUMP                 |                           |      0 |        |            |      0 |00:00:00.01 |       0 |
|  32 |                  TABLE ACCESS BY INDEX ROWID     | G_DOSSIER                 |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 33 |                   INDEX UNIQUE SCAN              | DOS_REFDOSS               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 34 |                CONNECT BY WITH FILTERING (UNIQUE)|                           |      0 |        |            |      0 |00:00:00.01 |       0 |
|* 35 |                 INDEX RANGE SCAN                 | DOS_REFDOSS_REFLOT_IDX    |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |
|  36 |                 NESTED LOOPS                     |                           |      0 |    401 |     4   (0)|      0 |00:00:00.01 |       0 |
|  37 |                  CONNECT BY PUMP                 |                           |      0 |        |            |      0 |00:00:00.01 |       0 |
|* 38 |                  INDEX RANGE SCAN                | G_DOSSIER_RL_CD_RD_RF_IDX |      0 |    401 |     3   (0)|      0 |00:00:00.01 |       0 |
|* 39 |                CONNECT BY WITH FILTERING (UNIQUE)|                           |      0 |        |            |      0 |00:00:00.01 |       0 |
|  40 |                 TABLE ACCESS BY INDEX ROWID      | G_DOSSIER                 |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |
|* 41 |                  INDEX UNIQUE SCAN               | DOS_REFDOSS               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|  42 |                 NESTED LOOPS                     |                           |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|  43 |                  CONNECT BY PUMP                 |                           |      0 |        |            |      0 |00:00:00.01 |       0 |
|* 44 |                  INDEX RANGE SCAN                | REFHIERARCHIE_IDX         |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 45 |             INDEX RANGE SCAN                     | DETFAC_DOS                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 46 |            TABLE ACCESS BY INDEX ROWID           | F_DETFAC                  |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |
|* 47 |       TABLE ACCESS BY INDEX ROWID                | G_DOSSIER                 |      5 |      1 |     1   (0)|      5 |00:00:00.01 |      18 |
|* 48 |        INDEX UNIQUE SCAN                         | DOS_REFDOSS               |      5 |      1 |     1   (0)|      5 |00:00:00.01 |      12 |
|  49 |      TABLE ACCESS BY INDEX ROWID BATCHED         | G_PIECE                   |      5 |      1 |     2   (0)|      5 |00:00:00.01 |      23 |
|* 50 |       INDEX RANGE SCAN                           | GP_GRTYPE_MT_DT           |      5 |      1 |     2   (0)|      5 |00:00:00.01 |      17 |
|* 51 |    TABLE ACCESS BY INDEX ROWID BATCHED           | F_DETFAC                  |      2 |      1 |     2   (0)|      0 |00:00:00.01 |       4 |
|* 52 |     INDEX RANGE SCAN                             | F_DETFAC_DF_REFINIT_IDX   |      2 |      1 |     1   (0)|      0 |00:00:00.01 |       4 |
|* 53 |    TABLE ACCESS BY INDEX ROWID BATCHED           | F_DETFAC                  |      3 |      1 |     2   (0)|      0 |00:00:00.01 |       6 |
|* 54 |     INDEX RANGE SCAN                             | F_DETFAC_DF_REFINIT_IDX   |      3 |      1 |     1   (0)|      0 |00:00:00.01 |       6 |
|* 55 |    FILTER                                        |                           |      3 |        |            |      1 |00:00:00.01 |      13 |
|* 56 |     TABLE ACCESS BY INDEX ROWID BATCHED          | G_INTERET                 |      3 |      1 |     1   (0)|      3 |00:00:00.01 |       9 |
|* 57 |      INDEX RANGE SCAN                            | INTERET_REF_TYPE          |      3 |      2 |     1   (0)|      7 |00:00:00.01 |       6 |
|  58 |     TABLE ACCESS BY INDEX ROWID                  | G_INDIVIDU                |      1 |      1 |     2   (0)|      1 |00:00:00.01 |       4 |
|* 59 |      INDEX UNIQUE SCAN                           | IND_REFINDIV              |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |
|* 60 |    FILTER                                        |                           |      1 |        |            |      1 |00:00:00.01 |       8 |
|* 61 |     TABLE ACCESS BY INDEX ROWID BATCHED          | G_INTERET                 |      1 |      1 |     1   (0)|      2 |00:00:00.01 |       4 |
|* 62 |      INDEX RANGE SCAN                            | INTERET_REF_TYPE          |      1 |      2 |     1   (0)|      5 |00:00:00.01 |       2 |
|  63 |     TABLE ACCESS BY INDEX ROWID                  | G_INDIVIDU                |      1 |      1 |     2   (0)|      1 |00:00:00.01 |       4 |
|* 64 |      INDEX UNIQUE SCAN                           | IND_REFINDIV              |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |
-----------------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   2 - access("REFINDIVIDU"=:B1)
   4 - filter(((("COSTS"."DF_ANN" IS NOT NULL AND  IS NOT NULL) OR ("COSTS"."DF_ANN" IS NULL AND  IS NULL AND  IS NOT NULL)) AND
              ("DF_NOM"='FUE' OR ("DF_NOM"<>'FUE' AND  IS NOT NULL))))
   5 - filter(NVL("IND"."FG25",'N')='N')
  11 - filter(:B1='ALL')
  12 - filter(("DF"."DF_REL" IS NOT NULL AND UPPER("DF"."DF_NOM") NOT LIKE 'WT%'))
  13 - filter((:B1<>'ALL' AND :B2='N'))
  14 - filter("DF"."DF_REL" IS NOT NULL)
  15 - access("DF_DOS"=:B1)
       filter(UPPER("DF"."DF_NOM") NOT LIKE 'WT%')
  16 - filter((:B1<>'ALL' AND :B2='O'))
  22 - access("REFDOSS"=PRIOR NULL)
  23 - access("REFDOSS"=:B1)
  26 - access("connect$_by$_pump$_008"."PRIOR REFLOT "="REFDOSS")
  27 - access("REFDOSS"=PRIOR NULL)
  29 - access("REFDOSS"=:B1)
  33 - access("connect$_by$_pump$_014"."PRIOR REFHIERARCHIE "="REFDOSS")
  34 - access("REFLOT"=PRIOR NULL)
  35 - access("REFDOSS"=:B1)
  38 - access("connect$_by$_pump$_020"."PRIOR REFDOSS "="REFLOT")
  39 - access("REFHIERARCHIE"=PRIOR NULL)
  41 - access("REFDOSS"=:B1)
  44 - access("connect$_by$_pump$_026"."PRIOR REFDOSS "="REFHIERARCHIE")
       filter("REFHIERARCHIE" IS NOT NULL)
  45 - access("DF_DOS"="DOS"."REFDOSS")
       filter(UPPER("DF"."DF_NOM") NOT LIKE 'WT%')
  46 - filter("DF"."DF_REL" IS NOT NULL)
  47 - filter(("CATEGDOSS" NOT LIKE 'FP COMPTE%' AND "CATEGDOSS" NOT LIKE 'COMPTE FP%'))
  48 - access("DF_DOS"="CASES"."REFDOSS")
  50 - access("IND"."TYPPIECE"='CLIENT_PARAMS' AND "IND"."GPIHEURE"="DF_CLI")
       filter("IND"."GPIHEURE" IS NOT NULL)
  51 - filter(("F"."DF_DOS"=:B1 AND "F"."DF_ANN" IS NULL))
  52 - access("F"."DF_REFINIT"=:B1)
       filter(("F"."DF_NOM"='WTHC' OR "F"."DF_NOM"='WTHD' OR "F"."DF_NOM"='WTHRE'))
  53 - filter(("F"."DF_DOS"=:B1 AND "F"."DF_ANN" IS NULL))
  54 - access("F"."DF_REFINIT"=:B1)
       filter(("F"."DF_NOM"='WTHC' OR "F"."DF_NOM"='WTHD' OR "F"."DF_NOM"='WTHRE'))
  55 - filter("PAYS"=)
  56 - filter(("TYPEPER"=:B1 AND "DTDEBUT"<=:B3))
  57 - access("REFELEM"=:B1 AND "TYPE"='W')
  59 - access("REFINDIVIDU"=:B1)
  60 - filter("PAYS"=)
  61 - filter(("TYPEPER"=:B1 AND "DTDEBUT"<=:B3))
  62 - access("REFELEM"=:B1 AND "TYPE"='W')
  64 - access("REFINDIVIDU"=:B1)
  
*/
/********************************New Metrics***************************************/

/********************************Index statistics**********************************/

/********************************Other SQLs****************************************/          
/*

*/ 
/********************************Other SQLs****************************************/              
