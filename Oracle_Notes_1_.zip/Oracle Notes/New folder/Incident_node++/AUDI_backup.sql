UNIX - Mario Bismar

[‎3/‎18/‎2020 12:35 PM]  Ivanova-Stefanova Ivelinova, Nadezhda (Oracle TS):  
The space was cleaned, the next inc1 will be successful.

The DL has requested additional storage for the extension of the disk group. Waiting on 3th party vendor.
 


###### CHECK BACKUPS IN AUDI  (БЕЗ ДА СЕ КАЧВАШ НА БАЗАТА)
nsu
su - oracle
cd /dbteam/scripts/Backup 
[oracle@ivmg700(Production)  Backup]$ ./chk_backup.sh -sid <DB name> -T arch
[oracle@ivmg700(Production)  Backup]$ ./chk_backup.sh -sid <DB name>  -T inc1


#### To check why a backup failed
SQL> select OUTPUT from V$RMAN_OUTPUT;

#### More details for backups
desc V$RMAN_BACKUP_JOB_DETAILS


##########################################
-from management server /ivmg700/, whit user ORACLE:

su - oracle

cd /dbteam/scripts/Backup


[oracle@ivmg700(Production)  ~]$ geta -h   --help
[oracle@ivmg700(Production)  ~]$ geta -n   --search by APP name
[oracle@ivmg700(Production)  ~]$ geta -d   --search by database name
[oracle@ivmg700(Production)  ~]$ geta -u <username> -p  --show user password 
./chk_backup.sh -sid <DB name> -T arch
./chk_backup.sh -sid  E60003 -T arch
./chk_backup.sh -sid  E60016 -T inc1
./chk_backup.sh -sid  E60022 -T inc0
  

=====relocate RMAN service====

oracle@iudb904:P50000_1:/home/oracle$ srvctl status service -db T55003     
Service CP_RMANP50000 is running on nodes: iudb904
Service P_WC_EMREP is running on nodes: iudb904

oracle@iudb904:P50000_1:/home/oracle$ srvctl status database -db T55003    
Instance P50000_1 is running on node iudb904
Instance P50000_2 is running on node iudb920
 
 
 --- relocate from server na koito sa RMAN service-te kym drugiqt node sled koeto puskam backup-a
 
oracle@iudb904:P50000_1:/home/oracle$ srvctl relocate service -d T55003 -s CT_RMANT55003 -c iudb820 -n iudb804


Сетваме енварманта на базата !!!
като юзър Oracle ПУСКАМ СКРИПТА Само променям името на базата
oracle@iudb920:P50000_1$  nohup /sap_ora_tsm/ora_hp/backup/bin/db_backup.sh T55003 arch  &                     - tuk se puska backup  
 
nohup /sap_ora_tsm/ora_hp/backup/bin/db_backup.sh E60022 inc0 &


=================================================================================
==================================================================================





[‎10/‎17/‎2019 4:22 PM]    
trqbva da si izvadish parolata na U4CDB4CAT user-a parolata i da se opitash da se varjesh ot management server-a ivmg700 kam service-a T_CDB4CAT_826
 
U4CDB4CAT@T_CDB4CAT_826
iegk:y252



sqlplus U4CDB4CAT/"password"@T_CDB4CAT_826 


=================================================
====================================================

Dear Requestor,


We have checked and did not find any problem resolving the service name using LDAP.

Could you please check if you still experience any problems from your side.


We are waiting for your feedback!

 


============================================


######AUDI 

[‎10/‎12/‎2019 11:17 PM]  Stoyanov, Evgeni:  
/sbin/acfsutil registry - checks the file systems within the ACFS

srvctl start filesystem -d <file_system> -n node_name 


==========================

##### LONG OPS of expdp Schema #####

set linesize 400 pages 30 
col TARGET for a21 
col USERNAME for a10 
col TARGET_DESC for a15 
col "rem mins" for 9999.9 a8 
col UNITS for a10 
col TIME_REMAINING for a20 
col START__TIME for a20 
col LAST__UPDATE_TIME for a20 
SELECT SID, SERIAL#,USERNAME, to_char(START_TIME, 'YYYY/MM/DD HH24:MI:SS') START__TIME,to_char(LAST_UPDATE_TIME, 
'YYYY/MM/DD HH24:MI:SS') LAST__UPDATE_TIME,TIME_REMAINING/60 as "rem mins", TARGET, TARGET_DESC,SOFAR, 
TOTALWORK, UNITS, ROUND(SOFAR/TOTALWORK*100,2) "%_COMPLETE" FROM GV$SESSION_LONGOPS WHERE TOTALWORK != 0 AND SOFAR <> TOTALWORK 
--and sid='234' 
order by START_TIME; 


####### Start  expdp with parallel #######

expdp directory=DATA_PUMP_DIR DUMPFILE=141_MBVSRV_A4MBVSRV_2111Liveexp_%U.dmp LOGFILE=141_MBVSRV_A4MBVSRV_2111Liveexp.log FLASHBACK_SCN=************ SCHEMAS=A4MBVSRV parallel=4
 

