/********************************************************************************
*********       E-mail subject: SVBWEB-6027
*********             Instance: QA2
*********          Description: 
Problem:
The ClientOutput batch took over 1 hour during the EOM on SVB QA2.

Analysis:
After the analyze, we found that the TOP SQL czg106gs1fm88 was responsible for 94% of the time.
Same quqery was already analyzed in KBCCFDEV-1799. We should add the suggested hint from KBCCFDEV-1799, but in this case, we also
need to remove the condition "AND fp.pf_nom = upper(d.df_nom)", because table f_parfac fp is already joined through the rowid and also remove 
the unjoined table g_dossier from the second union.

Suggestion:
Please change the query as it is shown in the New SQL section below.

*********               SQL_ID: czg106gs1fm88
*********      Program/Package: 
*********              Request: Nikolai Nikolov
*********               Author: Dimitar Dimitrov
********* Received e-mail date: 07/08/2024
*********      Resolution date: 07/08/2024
*********  Trace old file here: \\epox\specifs\performance\tmp\
*********  Trace new file here:
***********************************************************************************/

/********************************OLD SQL*******************************************/

var B0 VARCHAR2(32);
EXEC :B0 := '';
var B3 NUMBER;
EXEC :B3 := NULL;
var B5 NUMBER;
EXEC :B5 := NULL;
var B7 VARCHAR2(32);
EXEC :B7 := '2405080001';
var B10 NUMBER;
EXEC :B10 := 2460490;
var B11 NUMBER;
EXEC :B11 := 2460523;
var B12 VARCHAR2(32);
EXEC :B12 := '';
var B15 VARCHAR2(32);
EXEC :B15 := 'GBP';
var B16 VARCHAR2(32);
EXEC :B16 := 'A600Z1O2';
var B17 NUMBER;
EXEC :B17 := 0;
var B18 NUMBER;
EXEC :B18 := -1;
var B20 NUMBER;
EXEC :B20 := 0;
var B22 VARCHAR2(32);
EXEC :B22 := 'ALL';
var B26 NUMBER;
EXEC :B26 := 0;
var B30 NUMBER;
EXEC :B30 := 0;
var B35 NUMBER;
EXEC :B35 := 2;
var B36 NUMBER;
EXEC :B36 := 0;
var B38 VARCHAR2(32);
EXEC :B38 := '2405080003';
var B41 NUMBER;
EXEC :B41 := 0;
var B42 VARCHAR2(32);
EXEC :B42 := '';
var B43 VARCHAR2(32);
EXEC :B43 := '07/2024';
var B44 NUMBER;
EXEC :B44 := 0;

SELECT /*+ no_merge(dos) no_push_pred(dos) leading(dos f_entfac)+ */
 df_rel,
 decode(GC . type,
        'CORRECTION',
        to_char(GC . dtcorrection_dt, :b0),
        '.CORRECTION',
        to_char(GC . dtcorrection_dt, :b0),
        to_char(GC . dtcalc_dt, :b0)),
 decode(GC . type,
        'CORRECTION',
        to_char(GC . dtcorrection_dt, 'j'),
        '.CORRECTION',
        to_char(GC . dtcorrection_dt, 'j'),
        to_char(GC . dtcalc_dt, 'j')),
 SUM(nvl(GC . mt05, 0.0)),
 CASE
   WHEN GC . rate - (nvl(GC . base_rate, 0.0) + nvl(GC . margin, 0.0)) >=
        -0.000001 THEN
    GC . rate
   else
    CASE
      WHEN (nvl(GC . base_rate, 0.0) + nvl(GC . margin, 0.0)) /
           (GC . rate * 365) < 0.1 THEN
       (nvl(GC . base_rate, 0.0) + nvl(GC . margin, 0.0)) * 100
      else
       nvl(GC . base_rate, 0.0) + nvl(GC . margin, 0.0)
    END
 END,
 SUM(decode(SIGN(nvl(MNT_DCPT, decode(df_sen, 'D', 1, 'C', -1))), -1, -1, 1) *
     NVL(GC . montant, 0) * NVL(ef_split, 1)),
 SUM(decode(SIGN(nvl(MNT_DCPT, decode(df_sen, 'D', 1, 'C', -1))), -1, -1, 1) *
     NVL(GC . montant_con, 0) * NVL(ef_split, 1)),
 NVL(df_taux_tva * 100, -1),
 SUM(nvl(GC . mt05, 0.0)),
 SUM(NVL(GC . fdg_amount, 0.0)),
 df_dos,
 'FUC',
 to_char(to_date(:b3, 'j'), :b0),
 to_char(to_date(:b5, 'j'), :b0),
 gc . type,
 1,
 MAX(GC . imx_un_id),
 SUM(DECODE(GC . type,
            'CORRECTION',
            DECODE(SIGN(NVL(GC . mt05, 0.0)), 1, NVL(GC . mt05, 0.0), 0),
            0)),
 SUM(DECODE(GC . type,
            'CORRECTION',
            DECODE(SIGN(NVL(GC . mt05, 0.0)), -1, NVL(GC . mt05, 0.0), 0),
            0)),
 MAX(case
       WHEN GC . mt01 IS NULL AND GC . mt04 IS NULL THEN
        1
       else
        0
     END),
 GC . numfact,
 TRUNC(GC . dtcalc_dt)
  FROM g_commfin gc,
       f_detfac d,
       f_entfac,
       t_ecrdos T,
       f_parfac fp,
       (SELECT refdoss
          FROM g_dossier
         WHERE refdoss = :b7
        union ALL
        SELECT refdoss
          FROM g_dossier
         WHERE reflot = :b7
        union ALL
        SELECT C . refdoss
          FROM g_dossier C, g_dossier D
         WHERE D . reflot = :b7
           AND C . reflot = D . refdoss) dos
 WHERE ef_dos = dos .refdoss
   AND ef_imp > :b10
   AND ef_imp <= :b11
   AND ef_imp is not NULL
   AND (:b12 IS NULL OR (:b12 IS NOT NULL AND ef_rel > :b12))
   AND NVL(ef_devise_mvt, 'EUR') = NVL(:b15, NVL(ef_devise_mvt, 'EUR'))
   AND nvl(ef_createur, 'X') NOT LIKE '%e_factur%'
   AND df_cli = :b16
   AND df_num = ef_num
   AND df_dos = ef_dos
   AND df_nom IN ('FUC', 'FUCC')
   AND (d . df_taux_tva = DECODE(:b17, 1, :b18, d . df_taux_tva) OR d .
        df_taux_tva =
        DECODE(:b17, 1, DECODE(:b20, 1, 0, :b18), d . df_taux_tva))
   AND (:b22 = 'ALL' OR
       (:b22 IN ('ELSE', 'ISR') AND
       NVL(fp . PF_TTC, 'X') =
       DECODE(:b22, 'ISR', 'ISR', 'ELSE', NVL(fp . PF_TTC, 'X')) AND
       NVL(fp . PF_TTC, 'X') NOT IN ('IS0', 'HTS') AND
       NVL(fp . PF_TTC, 'X') != DECODE(:b22, 'ELSE', 'ISR', 'Y') AND d .
        df_taux_tva != DECODE(:b26, 1, 0, -1)) OR
       (:b22 in ('IS0', 'HTS') AND
       (fp . PF_TTC = :b22 OR
        (NVL(fp . PF_TTC, 'X') =
        DECODE(:b22, 'IS0', 'ISR', 'HTS', NVL(fp . PF_TTC, 'X')) AND
        NVL(fp . PF_TTC, 'X') != DECODE(:b30, 1, 'IS0', 'Y') AND
        NVL(fp . PF_TTC, 'X') !=
        DECODE(:b22, 'HTS', DECODE(:b30, 1, 'ISR', 'Y'), 'Y') AND
        NVL(fp . PF_TTC, 'X') !=
        DECODE(:b22, 'HTS', DECODE(:b26, 0, 'HT', 'Y'), 'Y') AND d .
         df_taux_tva = 0))))
   AND df_sen = DECODE(:b35, 0, 'D', 1, 'C', df_sen)
   AND ((GC .
        type IN ('CORRECTION', '.CORRECTION') AND NVL(GC . montant, 0) != 0) OR
       (GC . type <> 'CORRECTION' AND GC . type <> '.CORRECTION'))
   AND GC . numfact = df_num
   AND nvl(T . refdoss, DECODE(:b36, 1, :b7, df_dos)) IN
       (SELECT refdoss
          FROM g_dossier
         WHERE reflot = :b38
        UNION ALL
        SELECT :b38 as refdoss
          FROM dual
        UNION ALL
        SELECT :b7 as refdoss
          FROM dual
         WHERE :b41 = 1)
   AND T . ancrefdoss(+) = df_dos
   AND T . refelem(+) = df_num
   AND T . codecr(+) = upper(df_nom)
   AND fp . rowid = (select factor_interest . getCostParams(upper(d . df_nom), :b42)
                  from dual)
   AND fp .
 pf_nom = upper(d . df_nom)
   AND ((nvl(length(:b43), 0) != 0 AND
       NVL(fp . pf_relimp, 'M') IN ('M', 'D', 'X') AND :b44 = 0) OR
       (nvl(length(:b43), 0) = 0 AND NVL(fp . pf_relimp, 'M') = 'D'))
 GROUP BY df_rel,
          decode(GC . type,
                 'CORRECTION',
                 to_char(GC . dtcorrection_dt, :b0),
                 '.CORRECTION',
                 to_char(GC . dtcorrection_dt, :b0),
                 to_char(GC . dtcalc_dt, :b0)),
          decode(GC . type,
                 'CORRECTION',
                 to_char(GC . dtcorrection_dt, 'j'),
                 '.CORRECTION',
                 to_char(GC . dtcorrection_dt, 'j'),
                 to_char(GC . dtcalc_dt, 'j')),
          CASE
            WHEN GC .
             rate - (nvl(GC . base_rate, 0.0) + nvl(GC . margin, 0.0)) >=
                 -0.000001 THEN
             GC . rate
            else
             CASE
               WHEN (nvl(GC . base_rate, 0.0) + nvl(GC . margin, 0.0)) /
                    (GC . rate * 365) < 0.1 THEN
                (nvl(GC . base_rate, 0.0) + nvl(GC . margin, 0.0)) * 100
               else
                nvl(GC . base_rate, 0.0) + nvl(GC . margin, 0.0)
             END
          END,
          NVL(df_taux_tva * 100, -1),
          df_dos,
          gc . type,
          GC . numfact,
          TRUNC(GC . dtcalc_dt)
UNION
SELECT /*+ leading(dos p gpa)+*/
 '',
 to_char(gca . COMMFIN_DAY_DT, :b0) AS "Value date",
 to_char(gca . COMMFIN_DAY_DT, 'j') AS "Julian value date",
 0.0,
 GREATEST((nvl(gca . real_base_rate, 0) + nvl(gca . real_margin, 0)),
          nvl(gca . real_floor_rate, 0)) AS "Rate",
 gca . ROUND_COMM_AMT AS "Interest amount",
 0.0,
 0.0,
 round(gca . real_commfin_base, 2) AS "Contractual FiU Balance",
 0.0,
 gca . refdoss,
 'AII',
 case
   WHEN nvl(p . fg07, 'N') = 'O' THEN
    to_char(p . GPIDATE_DT, :b0)
   else
    to_char(to_date(:b3, 'j'), :b0)
 end,
 case
   WHEN nvl(p . fg07, 'N') = 'O' THEN
    to_char(p . GPIDATE2_DT, :b0)
   else
    to_char(to_date(:b5, 'j'), :b0)
 end,
 'AII',
 2,
 0,
 0,
 0,
 1,
 NULL,
 NULL
  FROM g_commfin_accrual gca,
       g_dossier d,
       g_piece p,
       (SELECT /*+ leading(d f_entfac f_detfac fp) +*/
        DISTINCT d . refdoss, d . pieceinit
          FROM f_detfac, f_entfac, f_parfac fp, g_dossier d
         WHERE d . categdoss LIKE '%LOAN%'
           AND d .
         reflot = :b38
           AND nvl(d . devise, 'EUR') = NVL(:b15, nvl(d . devise, 'EUR'))
           AND ef_imp > :b10
           AND ef_imp <= :b11
           AND (:b12 IS NULL OR (:b12 IS NOT NULL AND ef_rel > :b12))
           AND df_nom IN ('AII', 'IN')
           AND ef_dos = d .
         refdoss
           AND ef_num = df_num
           AND df_rel IS NOT NULL
           AND df_dos = ef_dos
           AND df_sen = DECODE(:b35, 0, 'D', 1, 'C', df_sen)
           AND (df_taux_tva = DECODE(:b17, 1, :b18, df_taux_tva) OR
               df_taux_tva =
               DECODE(:b17, 1, DECODE(:b20, 1, 0, :b18), df_taux_tva))
           AND (:b22 = 'ALL' OR
               (:b22 IN ('ELSE', 'ISR') AND
               NVL(fp . PF_TTC, 'X') =
               DECODE(:b22, 'ISR', 'ISR', 'ELSE', NVL(fp . PF_TTC, 'X')) AND
               NVL(fp . PF_TTC, 'X') NOT IN ('IS0', 'HTS') AND
               NVL(fp . PF_TTC, 'X') != DECODE(:b22, 'ELSE', 'ISR', 'Y') AND
               df_taux_tva != DECODE(:b26, 1, 0, -1)) OR
               (:b22 in ('IS0', 'HTS') AND
               (fp .
                PF_TTC = :b22 OR
                (NVL(fp . PF_TTC, 'X') =
                DECODE(:b22, 'IS0', 'ISR', 'HTS', NVL(fp . PF_TTC, 'X')) AND
                NVL(fp . PF_TTC, 'X') != DECODE(:b30, 1, 'IS0', 'Y') AND
                NVL(fp . PF_TTC, 'X') !=
                DECODE(:b22, 'HTS', DECODE(:b30, 1, 'ISR', 'Y'), 'Y') AND
                NVL(fp . PF_TTC, 'X') !=
                DECODE(:b22, 'HTS', DECODE(:b26, 0, 'HT', 'Y'), 'Y') AND
                df_taux_tva = 0))))
           AND fp . pf_nom = upper(df_nom)
           AND fp .
         rowid = (select factor_interest . getCostParams(upper(df_nom), :b42)
                          from dual)
           AND ((:b44 = 0 AND NVL(fp . pf_relimp, 'M') IN ('M', 'D', 'X') AND
               (NVL(fp . pf_relimp, 'M') != 'X' OR
               (NVL(fp . pf_relimp, 'M') = 'X' AND NOT EXISTS
                (SELECT 1
                      FROM f_entrel CUR
                     WHERE CUR . er_num = df_rel
                       AND CUR . er_f_rel_val IS NOT NULL)))) OR
               (:b44 = 1 AND NVL(fp . pf_relimp, 'M') = 'D') OR
               (:b44 = 2 AND NVL(fp . pf_relimp, 'M') = 'X'))) dos
 WHERE p . refdoss = dos . refdoss
   AND p . typpiece = dos .
 pieceinit
   AND ((p . fg07 = 'O' AND to_char(gca . COMMFIN_DAY_DT, 'j') <= :b5) OR
       (nvl(p . fg07, 'N') = 'N' AND
       to_char(gca . COMMFIN_DAY_DT, 'j') >= :b3 AND
       to_char(gca . COMMFIN_DAY_DT, 'j') <= :b5))
   AND gca . commfin_type LIKE '%ITRBQ_VALUE_DATE%'
   AND gca . refdoss = p . refdoss
 ORDER BY 16, 11, 3;
/********************************OLD SQL*******************************************/
/********************************OLD Metrics***************************************/
/*
MODULE                           PROGRAM                                            SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- -------------------------------------------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
lst_prog_pnp                     lst_prog_pnp                                       czg106gs1fm88 3647829303                       ON CPU               2024/07/31 23:14:43  2024/08/01 00:07:14         254                  395 +000000000 00:52:31.319 94%
lst_prog_pnp                     lst_prog_pnp                                       5p74upfsyqgtq 3284054457                                            2024/07/31 23:13:13  2024/07/31 23:16:23           3                   31 +000000000 00:03:10.003 1%
lst_prog_pnp                     lst_prog_pnp                                       1ksh4srct43r4  444493654                                            2024/07/31 23:14:13  2024/07/31 23:20:03           3                   34 +000000000 00:05:50.162 1%
lst_prog_pnp                     lst_prog_pnp                                       5a6jgn5artx3c  876166674        675      21878 ON CPU               2024/07/31 23:35:43  2024/07/31 23:35:43           1                    1 +000000000 00:00:00.000 0%
lst_prog_pnp                     lst_prog_pnp                                       au5q4nyk5z0rk 2573280695          9      52261 ON CPU               2024/08/01 00:00:44  2024/08/01 00:00:44           1                    1 +000000000 00:00:00.000 0%
lst_prog_pnp                     lst_prog_pnp                                       bbdpjkyu09yqk 1430819510          9      21667 ON CPU               2024/07/31 23:39:23  2024/07/31 23:39:23           1                    1 +000000000 00:00:00.000 0%
lst_prog_pnp                     lst_prog_pnp                                       bkfukxgmu9mav 2220055602          9      54155 db file sequential r 2024/07/31 23:19:13  2024/07/31 23:19:13           1                    1 +000000000 00:00:00.000 0%
lst_prog_pnp                     lst_prog_pnp                                       27g65cuj6ngxj 1388734953          9      60987 ON CPU               2024/07/31 23:22:33  2024/07/31 23:22:33           1                      +000000000 00:00:00.000 0%
lst_prog_pnp                     lst_prog_pnp                                       1p0m7j0k68zk8 3333722595          9      56573 ON CPU               2024/07/31 23:41:13  2024/07/31 23:41:13           1                      +000000000 00:00:00.000 0%
lst_prog_pnp                     lst_prog_pnp                                                              0          9      25172 ON CPU               2024/07/31 23:19:23  2024/07/31 23:19:23           1                      +000000000 00:00:00.000 0%
lst_prog_pnp                     lst_prog_pnp                                       7hty3tbv3vmhm 2391948738          9      10816 ON CPU               2024/07/31 23:39:13  2024/07/31 23:39:13           1                    1 +000000000 00:00:00.000 0%
lst_prog_pnp                     lst_prog_pnp                                       5687gjkra4y65 2835409426          9      47918 ON CPU               2024/07/31 23:19:03  2024/07/31 23:19:03           1                    1 +000000000 00:00:00.000 0%
lst_prog_pnp                     lst_prog_pnp                                       3w1tck330jsxq 2421914267        680      26782 ON CPU               2024/07/31 23:13:03  2024/07/31 23:13:03           1                      +000000000 00:00:00.000 0%
lst_prog_pnp                     lst_prog_pnp                                       7p8fccm6zav4d  322569057          9      12434 ON CPU               2024/07/31 23:22:23  2024/07/31 23:22:23           1                    1 +000000000 00:00:00.000 0%


SQL_ID        SQL_PLAN_HASH_VALUE SQL_PLAN_LINE_ID SQL_PLAN_OPERATION             SQL_PLAN_OPTIONS                   ACTIVE
------------- ------------------- ---------------- ------------------------------ ------------------------------ ----------
czg106gs1fm88          3647829303                2 UNION-ALL                                                            162
czg106gs1fm88          3647829303                1 SORT                           UNIQUE                                 87
czg106gs1fm88          3647829303               63 BUFFER                         SORT                                    5


INSTANCE_NUMBER SQL_ID            ELAPSED MAX_WAIT_ON     PC_OF  WAIT_TIME            GETS      READS       ROWS  ELAP/EXEC       GETS/EXEC READS/EXEC  ROWS/EXEC       EXEC PLAN_HASH_VALUE
--------------- ------------- ----------- --------------- ----- ---------- --------------- ---------- ---------- ---------- --------------- ---------- ---------- ---------- ---------------
              1 czg106gs1fm88        2167 CPU             100%  2165.98834          694516       4227       5845       5.06            1623       9.88      13.66        428  3647829303


Plan hash value: 3647829303
----------------------------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                         | Name                       | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  |
----------------------------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                                  |                            |      1 |        |  2505 (100)|     31 |00:00:00.24 |    1350 |    426 |
|   1 |  SORT UNIQUE                                      |                            |      1 |    251 |  2504   (1)|     31 |00:00:00.24 |    1350 |    426 |
|   2 |   UNION-ALL                                       |                            |      1 |        |            |     31 |00:00:00.24 |    1350 |    426 |
|   3 |    HASH GROUP BY                                  |                            |      1 |      1 |  1411   (1)|     31 |00:00:00.23 |    1319 |    423 |
|*  4 |     FILTER                                        |                            |      1 |        |            |     31 |00:00:00.23 |    1319 |    423 |
|*  5 |      FILTER                                       |                            |      1 |        |            |     31 |00:00:00.23 |    1316 |    423 |
|   6 |       NESTED LOOPS                                |                            |      1 |      1 |  1402   (1)|     31 |00:00:00.23 |    1316 |    423 |
|   7 |        NESTED LOOPS                               |                            |      1 |    424 |  1402   (1)|     31 |00:00:00.22 |    1304 |    413 |
|   8 |         NESTED LOOPS OUTER                        |                            |      1 |      1 |  1386   (1)|      1 |00:00:00.22 |    1301 |    410 |
|   9 |          NESTED LOOPS                             |                            |      1 |      1 |  1384   (1)|      1 |00:00:00.22 |    1297 |    410 |
|  10 |           NESTED LOOPS                            |                            |      1 |      1 |  1383   (1)|      1 |00:00:00.21 |    1292 |    410 |
|* 11 |            HASH JOIN                              |                            |      1 |      1 |  1382   (1)|      5 |00:00:00.21 |    1282 |    407 |
|  12 |             VIEW                                  |                            |      1 |    161K|  1011   (1)|     12 |00:00:00.01 |      17 |      0 |
|  13 |              UNION-ALL                            |                            |      1 |        |            |     12 |00:00:00.01 |      17 |      0 |
|* 14 |               INDEX UNIQUE SCAN                   | DOS_REFDOSS                |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |      0 |
|* 15 |               INDEX RANGE SCAN                    | G_DOSSIER_RL_CD_RD_RF_IDX  |      1 |    401 |     3   (0)|      3 |00:00:00.01 |       3 |      0 |
|  16 |               NESTED LOOPS                        |                            |      1 |    160K|  1007   (1)|      8 |00:00:00.01 |      11 |      0 |
|* 17 |                INDEX RANGE SCAN                   | G_DOSSIER_RL_CD_RD_RF_IDX  |      1 |    401 |     3   (0)|      3 |00:00:00.01 |       3 |      0 |
|* 18 |                INDEX RANGE SCAN                   | G_DOSSIER_RL_CD_RD_RF_IDX  |      3 |    401 |     3   (0)|      8 |00:00:00.01 |       8 |      0 |
|* 19 |             TABLE ACCESS BY INDEX ROWID BATCHED   | F_ENTFAC                   |      1 |      1 |   192   (0)|     25 |00:00:00.21 |    1265 |    407 |
|* 20 |              INDEX SKIP SCAN                      | EF_DOS_IDX                 |      1 |     53 |   170   (0)|   1286 |00:00:00.16 |     331 |    329 |
|* 21 |            TABLE ACCESS BY INDEX ROWID BATCHED    | F_DETFAC                   |      5 |      1 |     1   (0)|      1 |00:00:00.01 |      10 |      3 |
|* 22 |             INDEX RANGE SCAN                      | DETFAC_NUM                 |      5 |      1 |     1   (0)|      5 |00:00:00.01 |       7 |      1 |
|* 23 |           TABLE ACCESS BY INDEX ROWID BATCHED     | F_PARFAC                   |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       5 |      0 |
|* 24 |            INDEX RANGE SCAN                       | PARFAC_CL1                 |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       4 |      0 |
|  25 |             FAST DUAL                             |                            |      1 |      1 |     2   (0)|      1 |00:00:00.01 |       0 |      0 |
|* 26 |          TABLE ACCESS BY INDEX ROWID BATCHED      | T_ECRDOS                   |      1 |      1 |     2   (0)|      0 |00:00:00.01 |       4 |      0 |
|* 27 |           INDEX RANGE SCAN                        | TECR_REFELEM               |      1 |      1 |     2   (0)|      0 |00:00:00.01 |       4 |      0 |
|* 28 |         INDEX RANGE SCAN                          | G_COMMFIN_NUMFACT_IDX      |      1 |    424 |     1   (0)|     31 |00:00:00.01 |       3 |      3 |
|* 29 |        TABLE ACCESS BY INDEX ROWID                | G_COMMFIN                  |     31 |    343 |    17   (0)|     31 |00:00:00.01 |      12 |     10 |
|  30 |      UNION-ALL                                    |                            |      1 |        |            |      1 |00:00:00.01 |       3 |      0 |
|* 31 |       INDEX RANGE SCAN                            | DOS_REFDOSS_REFLOT_IDX     |      1 |      1 |     2   (0)|      0 |00:00:00.01 |       3 |      0 |
|* 32 |       FILTER                                      |                            |      1 |        |            |      1 |00:00:00.01 |       0 |      0 |
|  33 |        FAST DUAL                                  |                            |      1 |      1 |     2   (0)|      1 |00:00:00.01 |       0 |      0 |
|* 34 |       FILTER                                      |                            |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  35 |        FAST DUAL                                  |                            |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|  36 |    MERGE JOIN CARTESIAN                           |                            |      1 |    250 |  1092   (2)|      0 |00:00:00.01 |      31 |      3 |
|  37 |     NESTED LOOPS                                  |                            |      1 |      1 |    18   (6)|      0 |00:00:00.01 |      31 |      3 |
|  38 |      NESTED LOOPS                                 |                            |      1 |      1 |    18   (6)|      0 |00:00:00.01 |      31 |      3 |
|  39 |       NESTED LOOPS                                |                            |      1 |      1 |    15   (7)|      1 |00:00:00.01 |      26 |      0 |
|  40 |        VIEW                                       |                            |      1 |      1 |    14   (8)|      1 |00:00:00.01 |      20 |      0 |
|  41 |         HASH UNIQUE                               |                            |      1 |      1 |    14   (8)|      1 |00:00:00.01 |      20 |      0 |
|* 42 |          FILTER                                   |                            |      1 |        |            |      1 |00:00:00.01 |      20 |      0 |
|* 43 |           FILTER                                  |                            |      1 |        |            |      1 |00:00:00.01 |      20 |      0 |
|  44 |            NESTED LOOPS                           |                            |      1 |      1 |    11   (0)|      1 |00:00:00.01 |      20 |      0 |
|  45 |             NESTED LOOPS                          |                            |      1 |      1 |    11   (0)|      1 |00:00:00.01 |      19 |      0 |
|  46 |              NESTED LOOPS                         |                            |      1 |      1 |    10   (0)|      1 |00:00:00.01 |      17 |      0 |
|  47 |               NESTED LOOPS                        |                            |      1 |      1 |     9   (0)|      4 |00:00:00.01 |       9 |      0 |
|* 48 |                TABLE ACCESS BY INDEX ROWID BATCHED| G_DOSSIER                  |      1 |      1 |     8   (0)|      1 |00:00:00.01 |       5 |      0 |
|* 49 |                 INDEX RANGE SCAN                  | G_DOSSIER_RL_CD_RD_RF_IDX  |      1 |     20 |     3   (0)|      1 |00:00:00.01 |       3 |      0 |
|* 50 |                TABLE ACCESS BY INDEX ROWID BATCHED| F_ENTFAC                   |      1 |      1 |     1   (0)|      4 |00:00:00.01 |       4 |      0 |
|* 51 |                 INDEX RANGE SCAN                  | EF_DOS_IDX                 |      1 |      1 |     1   (0)|      4 |00:00:00.01 |       2 |      0 |
|* 52 |               TABLE ACCESS BY INDEX ROWID BATCHED | F_DETFAC                   |      4 |      1 |     1   (0)|      1 |00:00:00.01 |       8 |      0 |
|* 53 |                INDEX RANGE SCAN                   | DETFAC_NUM                 |      4 |      1 |     1   (0)|      4 |00:00:00.01 |       6 |      0 |
|* 54 |              INDEX RANGE SCAN                     | PARFAC_CL1                 |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       2 |      0 |
|  55 |               FAST DUAL                           |                            |      1 |      1 |     2   (0)|      1 |00:00:00.01 |       0 |      0 |
|* 56 |             TABLE ACCESS BY INDEX ROWID           | F_PARFAC                   |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       1 |      0 |
|* 57 |           TABLE ACCESS BY INDEX ROWID             | F_ENTREL                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 58 |            INDEX UNIQUE SCAN                      | ENTREL_CL1                 |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|  59 |        TABLE ACCESS BY INDEX ROWID BATCHED        | G_PIECE                    |      1 |      1 |     2   (0)|      1 |00:00:00.01 |       6 |      0 |
|* 60 |         INDEX RANGE SCAN                          | PIE_REFDOSS                |      1 |      1 |     2   (0)|      1 |00:00:00.01 |       4 |      0 |
|* 61 |       INDEX RANGE SCAN                            | IDX_COMMFIN_ACCRUAL        |      1 |      1 |     3   (0)|      0 |00:00:00.01 |       5 |      3 |
|  62 |      TABLE ACCESS BY INDEX ROWID                  | G_COMMFIN_ACCRUAL          |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|  63 |     BUFFER SORT                                   |                            |      0 |   1773K|  1089   (2)|      0 |00:00:00.01 |       0 |      0 |
|  64 |      INDEX FAST FULL SCAN                         | DOS_PRESNT_BUREAU_FNCT_IDX |      0 |   1773K|  1074   (2)|      0 |00:00:00.01 |       0 |      0 |
----------------------------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   4 - filter( IS NOT NULL)
   5 - filter(:B11>:B10)
  11 - access("EF_DOS"="DOS"."REFDOSS")
  14 - access("REFDOSS"=:B7)
  15 - access("REFLOT"=:B7)
  17 - access("D"."REFLOT"=:B7)
  18 - access("C"."REFLOT"="D"."REFDOSS")
  19 - filter(((:B12 IS NULL OR (:B12 IS NOT NULL AND "EF_REL">:B12)) AND NVL("EF_CREATEUR",'X') NOT LIKE '%e_factur%' AND
              NVL("EF_DEVISE_MVT",'EUR')=NVL(:B15,NVL("EF_DEVISE_MVT",'EUR'))))
  20 - access("EF_IMP">:B10 AND "EF_IMP"<=:B11)
       filter(("EF_IMP">:B10 AND "EF_IMP"<=:B11))
  21 - filter(("DF_CLI"=:B16 AND "DF_DOS"="EF_DOS" AND INTERNAL_FUNCTION("DF_NOM") AND "DF_SEN"=DECODE(:B35,0,'D',1,'C',"DF_SEN") AND
              ("D"."DF_TAUX_TVA"=DECODE(:B17,1,:B18,"D"."DF_TAUX_TVA") OR "D"."DF_TAUX_TVA"=DECODE(:B17,1,DECODE(:B20,1,0,:B18),"D"."DF_TAUX_TVA"))))
  22 - access("DF_NUM"="EF_NUM")
  23 - filter(((:B22='ALL' OR ((:B22='ELSE' OR :B22='ISR') AND NVL("FP"."PF_TTC",'X')=DECODE(:B22,'ISR','ISR','ELSE',NVL("FP"."PF_TTC",'X')) AND
              NVL("FP"."PF_TTC",'X')<>'IS0' AND NVL("FP"."PF_TTC",'X')<>'HTS' AND NVL("FP"."PF_TTC",'X')<>DECODE(:B22,'ELSE','ISR','Y') AND
              "D"."DF_TAUX_TVA"<>DECODE(:B26,1,0,(-1))) OR ((:B22='IS0' OR :B22='HTS') AND ("FP"."PF_TTC"=:B22 OR
              (NVL("FP"."PF_TTC",'X')=DECODE(:B22,'IS0','ISR','HTS',NVL("FP"."PF_TTC",'X')) AND "D"."DF_TAUX_TVA"=0 AND
              NVL("FP"."PF_TTC",'X')<>DECODE(:B30,1,'IS0','Y') AND NVL("FP"."PF_TTC",'X')<>DECODE(:B22,'HTS',DECODE(:B30,1,'ISR','Y'),'Y') AND
              NVL("FP"."PF_TTC",'X')<>DECODE(:B22,'HTS',DECODE(:B26,0,'HT','Y'),'Y'))))) AND ((:B44=0 AND NVL(LENGTH(:B43),0)<>0 AND (NVL("FP"."PF_RELIMP",'M')='M'
              OR NVL("FP"."PF_RELIMP",'M')='D' OR NVL("FP"."PF_RELIMP",'M')='X')) OR (NVL(LENGTH(:B43),0)=0 AND NVL("FP"."PF_RELIMP",'M')='D'))))
  24 - access("FP"."PF_NOM"=UPPER("D"."DF_NOM"))
       filter("FP".ROWID=CHARTOROWID())
  26 - filter(("T"."ANCREFDOSS" IS NOT NULL AND "T"."ANCREFDOSS"="DF_DOS" AND "T"."CODECR"=UPPER("D"."DF_NOM")))
  27 - access("T"."REFELEM"="DF_NUM")
  28 - access("GC"."NUMFACT"="DF_NUM")
  29 - filter((("GC"."TYPE"<>'CORRECTION' AND "GC"."TYPE"<>'.CORRECTION') OR (INTERNAL_FUNCTION("GC"."TYPE") AND NVL("GC"."MONTANT",0)<>0)))
  31 - access("REFDOSS"=NVL(:B1,DECODE(:B36,1,:B7,:B2)) AND "REFLOT"=:B38)
  32 - filter(NVL(:B1,DECODE(:B36,1,:B7,:B2))=:B38)
  34 - filter((:B41=1 AND NVL(:B1,DECODE(:B36,1,:B7,:B2))=:B7))
  42 - filter(((:B44=1 AND NVL("FP"."PF_RELIMP",'M')='D') OR (:B44=2 AND NVL("FP"."PF_RELIMP",'M')='X') OR (:B44=0 AND (NVL("FP"."PF_RELIMP",'M')='M'
              OR NVL("FP"."PF_RELIMP",'M')='D' OR NVL("FP"."PF_RELIMP",'M')='X') AND (NVL("FP"."PF_RELIMP",'M')<>'X' OR (NVL("FP"."PF_RELIMP",'M')='X' AND  IS
              NULL)))))
  43 - filter(:B11>:B10)
  48 - filter(NVL("D"."DEVISE",'EUR')=NVL(:B15,NVL("D"."DEVISE",'EUR')))
  49 - access("D"."REFLOT"=:B38)
       filter("D"."CATEGDOSS" LIKE '%LOAN%')
  50 - filter((:B12 IS NULL OR (:B12 IS NOT NULL AND "EF_REL">:B12)))
  51 - access("EF_DOS"="D"."REFDOSS" AND "EF_IMP">:B10 AND "EF_IMP"<=:B11)
  52 - filter(("DF_DOS"="EF_DOS" AND "DF_REL" IS NOT NULL AND INTERNAL_FUNCTION("DF_NOM") AND "DF_SEN"=DECODE(:B35,0,'D',1,'C',"DF_SEN") AND
              ("DF_TAUX_TVA"=DECODE(:B17,1,:B18,"DF_TAUX_TVA") OR "DF_TAUX_TVA"=DECODE(:B17,1,DECODE(:B20,1,0,:B18),"DF_TAUX_TVA"))))
  53 - access("EF_NUM"="DF_NUM")
  54 - access("FP"."PF_NOM"=UPPER("DF_NOM"))
       filter("FP".ROWID=CHARTOROWID())
  56 - filter((:B22='ALL' OR ((:B22='ELSE' OR :B22='ISR') AND NVL("FP"."PF_TTC",'X')=DECODE(:B22,'ISR','ISR','ELSE',NVL("FP"."PF_TTC",'X')) AND
              NVL("FP"."PF_TTC",'X')<>'IS0' AND NVL("FP"."PF_TTC",'X')<>'HTS' AND NVL("FP"."PF_TTC",'X')<>DECODE(:B22,'ELSE','ISR','Y') AND
              "DF_TAUX_TVA"<>DECODE(:B26,1,0,(-1))) OR ((:B22='IS0' OR :B22='HTS') AND ("FP"."PF_TTC"=:B22 OR
              (NVL("FP"."PF_TTC",'X')=DECODE(:B22,'IS0','ISR','HTS',NVL("FP"."PF_TTC",'X')) AND "DF_TAUX_TVA"=0 AND NVL("FP"."PF_TTC",'X')<>DECODE(:B30,1,'IS0','Y')
              AND NVL("FP"."PF_TTC",'X')<>DECODE(:B22,'HTS',DECODE(:B30,1,'ISR','Y'),'Y') AND
              NVL("FP"."PF_TTC",'X')<>DECODE(:B22,'HTS',DECODE(:B26,0,'HT','Y'),'Y'))))))
  57 - filter("CUR"."ER_F_REL_VAL" IS NOT NULL)
  58 - access("CUR"."ER_NUM"=:B1)
  60 - access("P"."REFDOSS"="DOS"."REFDOSS" AND "P"."TYPPIECE"="DOS"."PIECEINIT")
       filter("P"."REFDOSS" IS NOT NULL)
  61 - access("GCA"."REFDOSS"="P"."REFDOSS")
       filter(("GCA"."COMMFIN_TYPE" LIKE '%ITRBQ_VALUE_DATE%' AND (("P"."FG07"='O' AND
              TO_NUMBER(TO_CHAR(INTERNAL_FUNCTION("GCA"."COMMFIN_DAY_DT"),'j'))<=:B5) OR (NVL("P"."FG07",'N')='N' AND
              TO_NUMBER(TO_CHAR(INTERNAL_FUNCTION("GCA"."COMMFIN_DAY_DT"),'j'))>=:B3 AND TO_NUMBER(TO_CHAR(INTERNAL_FUNCTION("GCA"."COMMFIN_DAY_DT"),'j'))<=:B5)) AND
              "GCA"."COMMFIN_TYPE" IS NOT NULL))

*/
/********************************OLD Metrics***************************************/

/********************************New SQL*******************************************/

SELECT  /*+ leading(dos f_entfac d) use_nl(f_entfac d) index(f_entfac EF_DOS_IDX) opt_param('_optimizer_use_feedback' 'false') */ 
 df_rel,
 decode(GC . type,
        'CORRECTION',
        to_char(GC . dtcorrection_dt, :b0),
        '.CORRECTION',
        to_char(GC . dtcorrection_dt, :b0),
        to_char(GC . dtcalc_dt, :b0)),
 decode(GC . type,
        'CORRECTION',
        to_char(GC . dtcorrection_dt, 'j'),
        '.CORRECTION',
        to_char(GC . dtcorrection_dt, 'j'),
        to_char(GC . dtcalc_dt, 'j')),
 SUM(nvl(GC . mt05, 0.0)),
 CASE
   WHEN GC . rate - (nvl(GC . base_rate, 0.0) + nvl(GC . margin, 0.0)) >=
        -0.000001 THEN
    GC . rate
   else
    CASE
      WHEN (nvl(GC . base_rate, 0.0) + nvl(GC . margin, 0.0)) /
           (GC . rate * 365) < 0.1 THEN
       (nvl(GC . base_rate, 0.0) + nvl(GC . margin, 0.0)) * 100
      else
       nvl(GC . base_rate, 0.0) + nvl(GC . margin, 0.0)
    END
 END,
 SUM(decode(SIGN(nvl(MNT_DCPT, decode(df_sen, 'D', 1, 'C', -1))), -1, -1, 1) *
     NVL(GC . montant, 0) * NVL(ef_split, 1)),
 SUM(decode(SIGN(nvl(MNT_DCPT, decode(df_sen, 'D', 1, 'C', -1))), -1, -1, 1) *
     NVL(GC . montant_con, 0) * NVL(ef_split, 1)),
 NVL(df_taux_tva * 100, -1),
 SUM(nvl(GC . mt05, 0.0)),
 SUM(NVL(GC . fdg_amount, 0.0)),
 df_dos,
 'FUC',
 to_char(to_date(:b3, 'j'), :b0),
 to_char(to_date(:b5, 'j'), :b0),
 gc . type,
 1,
 MAX(GC . imx_un_id),
 SUM(DECODE(GC . type,
            'CORRECTION',
            DECODE(SIGN(NVL(GC . mt05, 0.0)), 1, NVL(GC . mt05, 0.0), 0),
            0)),
 SUM(DECODE(GC . type,
            'CORRECTION',
            DECODE(SIGN(NVL(GC . mt05, 0.0)), -1, NVL(GC . mt05, 0.0), 0),
            0)),
 MAX(case
       WHEN GC . mt01 IS NULL AND GC . mt04 IS NULL THEN
        1
       else
        0
     END),
 GC . numfact,
 TRUNC(GC . dtcalc_dt)
  FROM g_commfin gc,
       f_detfac d,
       f_entfac,
       t_ecrdos T,
       f_parfac fp,
       (SELECT 
               refdoss
          FROM g_dossier
         WHERE refdoss = :b7
        union ALL
        SELECT refdoss
          FROM g_dossier
         WHERE reflot = :b7
        union ALL
        SELECT C . refdoss
          FROM g_dossier C, g_dossier D
         WHERE D . reflot = :b7
           AND C . reflot = D . refdoss) dos
 WHERE ef_dos = dos .refdoss
   AND ef_imp > :b10
   AND ef_imp <= :b11
   AND ef_imp is not NULL
   AND (:b12 IS NULL OR (:b12 IS NOT NULL AND ef_rel > :b12))
   AND NVL(ef_devise_mvt, 'EUR') = NVL(:b15, NVL(ef_devise_mvt, 'EUR'))
   AND nvl(ef_createur, 'X') NOT LIKE '%e_factur%'
   AND df_cli = :b16
   AND df_num = ef_num
   AND df_dos = ef_dos
   AND df_nom IN ('FUC', 'FUCC')
   AND ( d . df_taux_tva = DECODE(:b17, 1, :b18, d . df_taux_tva) 
      OR d . df_taux_tva = DECODE(:b17, 1, DECODE(:b20, 1, 0, :b18), d . df_taux_tva))
   AND (   :b22 = 'ALL' 
      OR ( :b22 IN ('ELSE', 'ISR') 
     AND
       NVL(fp . PF_TTC, 'X') =
       DECODE(:b22, 'ISR', 'ISR', 'ELSE', NVL(fp . PF_TTC, 'X')) AND
       NVL(fp . PF_TTC, 'X') NOT IN ('IS0', 'HTS') AND
       NVL(fp . PF_TTC, 'X') != DECODE(:b22, 'ELSE', 'ISR', 'Y') AND d .
        df_taux_tva != DECODE(:b26, 1, 0, -1)) OR
       (:b22 in ('IS0', 'HTS') AND
       (fp . PF_TTC = :b22 OR
        (NVL(fp . PF_TTC, 'X') =
        DECODE(:b22, 'IS0', 'ISR', 'HTS', NVL(fp . PF_TTC, 'X')) AND
        NVL(fp . PF_TTC, 'X') != DECODE(:b30, 1, 'IS0', 'Y') AND
        NVL(fp . PF_TTC, 'X') !=
        DECODE(:b22, 'HTS', DECODE(:b30, 1, 'ISR', 'Y'), 'Y') AND
        NVL(fp . PF_TTC, 'X') !=
        DECODE(:b22, 'HTS', DECODE(:b26, 0, 'HT', 'Y'), 'Y') AND d .
         df_taux_tva = 0))))
   AND df_sen = DECODE(:b35, 0, 'D', 1, 'C', df_sen)
   AND ((GC .
        type IN ('CORRECTION', '.CORRECTION') AND NVL(GC . montant, 0) != 0) OR
       (GC . type <> 'CORRECTION' AND GC . type <> '.CORRECTION'))
   AND GC . numfact = df_num
   AND nvl(T . refdoss, DECODE(:b36, 1, :b7, df_dos)) IN
       (SELECT refdoss
          FROM g_dossier
         WHERE reflot = :b38
        UNION ALL
        SELECT :b38 as refdoss
          FROM dual
        UNION ALL
        SELECT :b7 as refdoss
          FROM dual
         WHERE :b41 = 1)
   AND T . ancrefdoss(+) = df_dos
   AND T . refelem(+) = df_num
   AND T . codecr(+) = upper(df_nom)
   AND fp.rowid = (select factor_interest.getCostParams(upper(d . df_nom), :b42)
                     from dual)
   AND ((nvl(length(:b43), 0) != 0 AND
       NVL(fp . pf_relimp, 'M') IN ('M', 'D', 'X') AND :b44 = 0) OR
       (nvl(length(:b43), 0) = 0 AND NVL(fp . pf_relimp, 'M') = 'D'))
 GROUP BY df_rel,
          decode(GC . type,
                 'CORRECTION',
                 to_char(GC . dtcorrection_dt, :b0),
                 '.CORRECTION',
                 to_char(GC . dtcorrection_dt, :b0),
                 to_char(GC . dtcalc_dt, :b0)),
          decode(GC . type,
                 'CORRECTION',
                 to_char(GC . dtcorrection_dt, 'j'),
                 '.CORRECTION',
                 to_char(GC . dtcorrection_dt, 'j'),
                 to_char(GC . dtcalc_dt, 'j')),
          CASE
            WHEN GC .
             rate - (nvl(GC . base_rate, 0.0) + nvl(GC . margin, 0.0)) >=
                 -0.000001 THEN
             GC . rate
            else
             CASE
               WHEN (nvl(GC . base_rate, 0.0) + nvl(GC . margin, 0.0)) /
                    (GC . rate * 365) < 0.1 THEN
                (nvl(GC . base_rate, 0.0) + nvl(GC . margin, 0.0)) * 100
               else
                nvl(GC . base_rate, 0.0) + nvl(GC . margin, 0.0)
             END
          END,
          NVL(df_taux_tva * 100, -1),
          df_dos,
          gc . type,
          GC . numfact,
          TRUNC(GC . dtcalc_dt)
UNION
SELECT '',
 to_char(gca . COMMFIN_DAY_DT, :b0) AS "Value date",
 to_char(gca . COMMFIN_DAY_DT, 'j') AS "Julian value date",
 0.0,
 GREATEST((nvl(gca . real_base_rate, 0) + nvl(gca . real_margin, 0)),
          nvl(gca . real_floor_rate, 0)) AS "Rate",
 gca . ROUND_COMM_AMT AS "Interest amount",
 0.0,
 0.0,
 round(gca . real_commfin_base, 2) AS "Contractual FiU Balance",
 0.0,
 gca . refdoss,
 'AII',
 case
   WHEN nvl(p . fg07, 'N') = 'O' THEN
    to_char(p . GPIDATE_DT, :b0)
   else
    to_char(to_date(:b3, 'j'), :b0)
 end,
 case
   WHEN nvl(p . fg07, 'N') = 'O' THEN
    to_char(p . GPIDATE2_DT, :b0)
   else
    to_char(to_date(:b5, 'j'), :b0)
 end,
 'AII',
 2,
 0,
 0,
 0,
 1,
 NULL,
 NULL
  FROM g_commfin_accrual gca,
       g_piece p,
       ( SELECT /*+ leading(d f_entfac f_detfac fp) +*/
       DISTINCT d.refdoss, 
                d.pieceinit
           FROM f_detfac, 
                f_entfac, 
                f_parfac fp, 
                g_dossier d
         WHERE d . categdoss LIKE '%LOAN%'
           AND d . reflot = :b38
           AND nvl(d . devise, 'EUR') = NVL(:b15, nvl(d . devise, 'EUR'))
           AND ef_imp > :b10
           AND ef_imp <= :b11
           AND (:b12 IS NULL OR (:b12 IS NOT NULL AND ef_rel > :b12))
           AND df_nom IN ('AII', 'IN')
           AND ef_dos = d . refdoss
           AND ef_num = df_num
           AND df_rel IS NOT NULL
           AND df_dos = ef_dos
           AND df_sen = DECODE(:b35, 0, 'D', 1, 'C', df_sen)
           AND ( df_taux_tva = DECODE(:b17, 1, :b18, df_taux_tva) OR
                 df_taux_tva =  DECODE(:b17, 1, DECODE(:b20, 1, 0, :b18), df_taux_tva))
           AND (:b22 = 'ALL' OR
               (:b22 IN ('ELSE', 'ISR') AND
               NVL(fp . PF_TTC, 'X') =
               DECODE(:b22, 'ISR', 'ISR', 'ELSE', NVL(fp . PF_TTC, 'X')) AND
               NVL(fp . PF_TTC, 'X') NOT IN ('IS0', 'HTS') AND
               NVL(fp . PF_TTC, 'X') != DECODE(:b22, 'ELSE', 'ISR', 'Y') AND
               df_taux_tva != DECODE(:b26, 1, 0, -1)) OR
               (:b22 in ('IS0', 'HTS') AND
               (fp .
                PF_TTC = :b22 OR
                (NVL(fp . PF_TTC, 'X') =
                DECODE(:b22, 'IS0', 'ISR', 'HTS', NVL(fp . PF_TTC, 'X')) AND
                NVL(fp . PF_TTC, 'X') != DECODE(:b30, 1, 'IS0', 'Y') AND
                NVL(fp . PF_TTC, 'X') !=
                DECODE(:b22, 'HTS', DECODE(:b30, 1, 'ISR', 'Y'), 'Y') AND
                NVL(fp . PF_TTC, 'X') !=
                DECODE(:b22, 'HTS', DECODE(:b26, 0, 'HT', 'Y'), 'Y') AND
                df_taux_tva = 0))))
           AND fp . pf_nom = upper(df_nom)
           AND fp . rowid = ( select factor_interest . getCostParams(upper(df_nom), :b42)
                                from dual)
           AND ((:b44 = 0 AND NVL(fp . pf_relimp, 'M') IN ('M', 'D', 'X') AND
               (NVL(fp . pf_relimp, 'M') != 'X' OR
               (NVL(fp . pf_relimp, 'M') = 'X' AND NOT EXISTS
                (SELECT 1
                   FROM f_entrel CUR
                  WHERE CUR . er_num = df_rel
                    AND CUR . er_f_rel_val IS NOT NULL)))) OR
               (:b44 = 1 AND NVL(fp . pf_relimp, 'M') = 'D') OR
               (:b44 = 2 AND NVL(fp . pf_relimp, 'M') = 'X'))) dos
 WHERE p.refdoss = dos.refdoss
   AND p.typpiece = dos.pieceinit
   AND ( ( p.fg07 = 'O' 
       AND to_char( gca.COMMFIN_DAY_DT, 'j') <= :b5 ) 
       OR ( nvl(p . fg07, 'N') = 'N' 
          AND to_char(gca . COMMFIN_DAY_DT, 'j') >= :b3 
          AND to_char(gca . COMMFIN_DAY_DT, 'j') <= :b5) )
   AND gca.commfin_type LIKE '%ITRBQ_VALUE_DATE%'
   AND gca.refdoss = p.refdoss
 ORDER BY 16, 11, 3;
/********************************New SQL*******************************************/
/********************************New Metrics***************************************/
/*
Plan hash value: 1577374298
-----------------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                        | Name                      | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers |
-----------------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                                 |                           |      1 |        |    61 (100)|     31 |00:00:00.01 |      94 |
|   1 |  SORT UNIQUE                                     |                           |      1 |      2 |    60   (4)|     31 |00:00:00.01 |      94 |
|   2 |   UNION-ALL                                      |                           |      1 |        |            |     31 |00:00:00.01 |      94 |
|   3 |    HASH GROUP BY                                 |                           |      1 |      1 |    42   (3)|     31 |00:00:00.01 |      63 |
|*  4 |     FILTER                                       |                           |      1 |        |            |     31 |00:00:00.01 |      63 |
|*  5 |      HASH JOIN                                   |                           |      1 |      1 |    39   (0)|     31 |00:00:00.01 |      63 |
|   6 |       NESTED LOOPS                               |                           |      1 |      1 |    32   (0)|     31 |00:00:00.01 |      60 |
|   7 |        NESTED LOOPS                              |                           |      1 |      4 |    28   (0)|     31 |00:00:00.01 |      58 |
|   8 |         NESTED LOOPS                             |                           |      1 |      1 |    11   (0)|      1 |00:00:00.01 |      43 |
|   9 |          NESTED LOOPS OUTER                      |                           |      1 |      1 |     6   (0)|      1 |00:00:00.01 |      34 |
|  10 |           NESTED LOOPS                           |                           |      1 |      1 |     4   (0)|      1 |00:00:00.01 |      30 |
|* 11 |            TABLE ACCESS BY INDEX ROWID BATCHED   | F_DETFAC                  |      1 |      1 |     3   (0)|      7 |00:00:00.01 |      10 |
|* 12 |             INDEX RANGE SCAN                     | DF_CLIREL                 |      1 |      2 |     2   (0)|      7 |00:00:00.01 |       3 |
|* 13 |            TABLE ACCESS BY INDEX ROWID BATCHED   | F_ENTFAC                  |      7 |      1 |     1   (0)|      1 |00:00:00.01 |      20 |
|* 14 |             INDEX RANGE SCAN                     | EF_DOS_IDX                |      7 |      1 |     1   (0)|     13 |00:00:00.01 |       8 |
|* 15 |           TABLE ACCESS BY INDEX ROWID BATCHED    | T_ECRDOS                  |      1 |      1 |     2   (0)|      0 |00:00:00.01 |       4 |
|* 16 |            INDEX RANGE SCAN                      | TECR_REFELEM              |      1 |      1 |     2   (0)|      0 |00:00:00.01 |       4 |
|  17 |          VIEW                                    |                           |      1 |      1 |     5   (0)|      1 |00:00:00.01 |       9 |
|  18 |           UNION ALL PUSHED PREDICATE             |                           |      1 |        |            |      1 |00:00:00.01 |       9 |
|* 19 |            FILTER                                |                           |      1 |        |            |      0 |00:00:00.01 |       0 |
|* 20 |             INDEX UNIQUE SCAN                    | DOS_REFDOSS               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 21 |            INDEX RANGE SCAN                      | DOS_REFDOSS_REFLOT_IDX    |      1 |      1 |     2   (0)|      1 |00:00:00.01 |       3 |
|  22 |            NESTED LOOPS                          |                           |      1 |      1 |     3   (0)|      0 |00:00:00.01 |       6 |
|* 23 |             INDEX RANGE SCAN                     | DOS_REFDOSS_REFLOT_IDX    |      1 |      1 |     2   (0)|      1 |00:00:00.01 |       3 |
|* 24 |             INDEX RANGE SCAN                     | DOS_REFDOSS_REFLOT_IDX    |      1 |      1 |     1   (0)|      0 |00:00:00.01 |       3 |
|* 25 |         TABLE ACCESS BY INDEX ROWID BATCHED      | G_COMMFIN                 |      1 |    343 |    17   (0)|     31 |00:00:00.01 |      15 |
|* 26 |          INDEX RANGE SCAN                        | G_COMMFIN_NUMFACT_IDX     |      1 |    424 |     1   (0)|     31 |00:00:00.01 |       3 |
|* 27 |        TABLE ACCESS BY USER ROWID                | F_PARFAC                  |     31 |      1 |     1   (0)|     31 |00:00:00.01 |       2 |
|  28 |         FAST DUAL                                |                           |      1 |      1 |     2   (0)|      1 |00:00:00.01 |       0 |
|  29 |       VIEW                                       | VW_NSO_1                  |      1 |    403 |     7   (0)|      3 |00:00:00.01 |       3 |
|  30 |        HASH UNIQUE                               |                           |      1 |    403 |     7   (0)|      3 |00:00:00.01 |       3 |
|  31 |         UNION-ALL                                |                           |      1 |        |            |      3 |00:00:00.01 |       3 |
|* 32 |          INDEX RANGE SCAN                        | G_DOSSIER_RL_CD_RD_RF_IDX |      1 |    401 |     3   (0)|      2 |00:00:00.01 |       3 |
|  33 |          FAST DUAL                               |                           |      1 |      1 |     2   (0)|      1 |00:00:00.01 |       0 |
|* 34 |          FILTER                                  |                           |      1 |        |            |      0 |00:00:00.01 |       0 |
|  35 |           FAST DUAL                              |                           |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |
|  36 |    NESTED LOOPS                                  |                           |      1 |      1 |    18   (6)|      0 |00:00:00.01 |      31 |
|  37 |     NESTED LOOPS                                 |                           |      1 |      1 |    18   (6)|      0 |00:00:00.01 |      31 |
|  38 |      NESTED LOOPS                                |                           |      1 |      1 |    15   (7)|      1 |00:00:00.01 |      26 |
|  39 |       VIEW                                       |                           |      1 |      1 |    14   (8)|      1 |00:00:00.01 |      20 |
|  40 |        HASH UNIQUE                               |                           |      1 |      1 |    14   (8)|      1 |00:00:00.01 |      20 |
|* 41 |         FILTER                                   |                           |      1 |        |            |      1 |00:00:00.01 |      20 |
|* 42 |          FILTER                                  |                           |      1 |        |            |      1 |00:00:00.01 |      20 |
|  43 |           NESTED LOOPS                           |                           |      1 |      1 |    11   (0)|      1 |00:00:00.01 |      20 |
|  44 |            NESTED LOOPS                          |                           |      1 |      1 |    11   (0)|      1 |00:00:00.01 |      19 |
|  45 |             NESTED LOOPS                         |                           |      1 |      1 |    10   (0)|      1 |00:00:00.01 |      17 |
|  46 |              NESTED LOOPS                        |                           |      1 |      1 |     9   (0)|      4 |00:00:00.01 |       9 |
|* 47 |               TABLE ACCESS BY INDEX ROWID BATCHED| G_DOSSIER                 |      1 |      1 |     8   (0)|      1 |00:00:00.01 |       5 |
|* 48 |                INDEX RANGE SCAN                  | G_DOSSIER_RL_CD_RD_RF_IDX |      1 |     20 |     3   (0)|      1 |00:00:00.01 |       3 |
|* 49 |               TABLE ACCESS BY INDEX ROWID BATCHED| F_ENTFAC                  |      1 |      1 |     1   (0)|      4 |00:00:00.01 |       4 |
|* 50 |                INDEX RANGE SCAN                  | EF_DOS_IDX                |      1 |      1 |     1   (0)|      4 |00:00:00.01 |       2 |
|* 51 |              TABLE ACCESS BY INDEX ROWID BATCHED | F_DETFAC                  |      4 |      1 |     1   (0)|      1 |00:00:00.01 |       8 |
|* 52 |               INDEX RANGE SCAN                   | DETFAC_NUM                |      4 |      1 |     1   (0)|      4 |00:00:00.01 |       6 |
|* 53 |             INDEX RANGE SCAN                     | PARFAC_CL1                |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       2 |
|  54 |              FAST DUAL                           |                           |      1 |      1 |     2   (0)|      1 |00:00:00.01 |       0 |
|* 55 |            TABLE ACCESS BY INDEX ROWID           | F_PARFAC                  |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       1 |
|* 56 |          TABLE ACCESS BY INDEX ROWID             | F_ENTREL                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 57 |           INDEX UNIQUE SCAN                      | ENTREL_CL1                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|  58 |       TABLE ACCESS BY INDEX ROWID BATCHED        | G_PIECE                   |      1 |      1 |     2   (0)|      1 |00:00:00.01 |       6 |
|* 59 |        INDEX RANGE SCAN                          | PIE_REFDOSS               |      1 |      1 |     2   (0)|      1 |00:00:00.01 |       4 |
|* 60 |      INDEX RANGE SCAN                            | IDX_COMMFIN_ACCRUAL       |      1 |      1 |     3   (0)|      0 |00:00:00.01 |       5 |
|  61 |     TABLE ACCESS BY INDEX ROWID                  | G_COMMFIN_ACCRUAL         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
-----------------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   4 - filter(:B11>:B10)
   5 - access("REFDOSS"=NVL("T"."REFDOSS",DECODE(:B36,1,:B7,"DF_DOS")))
  11 - filter(("DF_SEN"=DECODE(:B35,0,'D',1,'C',"DF_SEN") AND ("D"."DF_TAUX_TVA"=DECODE(:B17,1,:B18,"D"."DF_TAUX_TVA") OR
              "D"."DF_TAUX_TVA"=DECODE(:B17,1,DECODE(:B20,1,0,:B18),"D"."DF_TAUX_TVA"))))
  12 - access("DF_CLI"=:B16)
       filter(("DF_NOM"='FUC' OR "DF_NOM"='FUCC'))
  13 - filter(((:B12 IS NULL OR (:B12 IS NOT NULL AND "EF_REL">:B12)) AND "DF_NUM"="EF_NUM" AND NVL("EF_CREATEUR",'X') NOT LIKE '%e_factur%'
              AND NVL("EF_DEVISE_MVT",'EUR')=NVL(:B15,NVL("EF_DEVISE_MVT",'EUR'))))
  14 - access("DF_DOS"="EF_DOS" AND "EF_IMP">:B10 AND "EF_IMP"<=:B11)
  15 - filter(("T"."ANCREFDOSS" IS NOT NULL AND "T"."ANCREFDOSS"="DF_DOS" AND "T"."CODECR"=UPPER("DF_NOM")))
  16 - access("T"."REFELEM"="DF_NUM")
  19 - filter("EF_DOS"=:B7)
  20 - access("REFDOSS"=:B7)
  21 - access("REFDOSS"="EF_DOS" AND "REFLOT"=:B7)
  23 - access("C"."REFDOSS"="EF_DOS")
  24 - access("C"."REFLOT"="D"."REFDOSS" AND "D"."REFLOT"=:B7)
  25 - filter((("GC"."TYPE"<>'CORRECTION' AND "GC"."TYPE"<>'.CORRECTION') OR (INTERNAL_FUNCTION("GC"."TYPE") AND NVL("GC"."MONTANT",0)<>0)))
  26 - access("GC"."NUMFACT"="DF_NUM")
  27 - filter(((:B22='ALL' OR ((:B22='ELSE' OR :B22='ISR') AND NVL("FP"."PF_TTC",'X')=DECODE(:B22,'ISR','ISR','ELSE',NVL("FP"."PF_TTC",'X'))
              AND NVL("FP"."PF_TTC",'X')<>'IS0' AND NVL("FP"."PF_TTC",'X')<>'HTS' AND NVL("FP"."PF_TTC",'X')<>DECODE(:B22,'ELSE','ISR','Y') AND
              "D"."DF_TAUX_TVA"<>DECODE(:B26,1,0,(-1))) OR ((:B22='IS0' OR :B22='HTS') AND ("FP"."PF_TTC"=:B22 OR
              (NVL("FP"."PF_TTC",'X')=DECODE(:B22,'IS0','ISR','HTS',NVL("FP"."PF_TTC",'X')) AND "D"."DF_TAUX_TVA"=0 AND
              NVL("FP"."PF_TTC",'X')<>DECODE(:B30,1,'IS0','Y') AND NVL("FP"."PF_TTC",'X')<>DECODE(:B22,'HTS',DECODE(:B30,1,'ISR','Y'),'Y') AND
              NVL("FP"."PF_TTC",'X')<>DECODE(:B22,'HTS',DECODE(:B26,0,'HT','Y'),'Y'))))) AND ((:B44=0 AND NVL(LENGTH(:B43),0)<>0 AND
              (NVL("FP"."PF_RELIMP",'M')='M' OR NVL("FP"."PF_RELIMP",'M')='D' OR NVL("FP"."PF_RELIMP",'M')='X')) OR (NVL(LENGTH(:B43),0)=0 AND
              NVL("FP"."PF_RELIMP",'M')='D'))))
  32 - access("REFLOT"=:B38)
  34 - filter(:B41=1)
  41 - filter(((:B44=1 AND NVL("FP"."PF_RELIMP",'M')='D') OR (:B44=2 AND NVL("FP"."PF_RELIMP",'M')='X') OR (:B44=0 AND
              (NVL("FP"."PF_RELIMP",'M')='M' OR NVL("FP"."PF_RELIMP",'M')='D' OR NVL("FP"."PF_RELIMP",'M')='X') AND (NVL("FP"."PF_RELIMP",'M')<>'X' OR
              (NVL("FP"."PF_RELIMP",'M')='X' AND  IS NULL)))))
  42 - filter(:B11>:B10)
  47 - filter(NVL("D"."DEVISE",'EUR')=NVL(:B15,NVL("D"."DEVISE",'EUR')))
  48 - access("D"."REFLOT"=:B38)
       filter("D"."CATEGDOSS" LIKE '%LOAN%')
  49 - filter((:B12 IS NULL OR (:B12 IS NOT NULL AND "EF_REL">:B12)))
  50 - access("EF_DOS"="D"."REFDOSS" AND "EF_IMP">:B10 AND "EF_IMP"<=:B11)
  51 - filter(("DF_DOS"="EF_DOS" AND "DF_REL" IS NOT NULL AND INTERNAL_FUNCTION("DF_NOM") AND "DF_SEN"=DECODE(:B35,0,'D',1,'C',"DF_SEN") AND
              ("DF_TAUX_TVA"=DECODE(:B17,1,:B18,"DF_TAUX_TVA") OR "DF_TAUX_TVA"=DECODE(:B17,1,DECODE(:B20,1,0,:B18),"DF_TAUX_TVA"))))
  52 - access("EF_NUM"="DF_NUM")
  53 - access("FP"."PF_NOM"=UPPER("DF_NOM"))
       filter("FP".ROWID=CHARTOROWID())
  55 - filter((:B22='ALL' OR ((:B22='ELSE' OR :B22='ISR') AND NVL("FP"."PF_TTC",'X')=DECODE(:B22,'ISR','ISR','ELSE',NVL("FP"."PF_TTC",'X'))
              AND NVL("FP"."PF_TTC",'X')<>'IS0' AND NVL("FP"."PF_TTC",'X')<>'HTS' AND NVL("FP"."PF_TTC",'X')<>DECODE(:B22,'ELSE','ISR','Y') AND
              "DF_TAUX_TVA"<>DECODE(:B26,1,0,(-1))) OR ((:B22='IS0' OR :B22='HTS') AND ("FP"."PF_TTC"=:B22 OR
              (NVL("FP"."PF_TTC",'X')=DECODE(:B22,'IS0','ISR','HTS',NVL("FP"."PF_TTC",'X')) AND "DF_TAUX_TVA"=0 AND
              NVL("FP"."PF_TTC",'X')<>DECODE(:B30,1,'IS0','Y') AND NVL("FP"."PF_TTC",'X')<>DECODE(:B22,'HTS',DECODE(:B30,1,'ISR','Y'),'Y') AND
              NVL("FP"."PF_TTC",'X')<>DECODE(:B22,'HTS',DECODE(:B26,0,'HT','Y'),'Y'))))))
  56 - filter("CUR"."ER_F_REL_VAL" IS NOT NULL)
  57 - access("CUR"."ER_NUM"=:B1)
  59 - access("P"."REFDOSS"="DOS"."REFDOSS" AND "P"."TYPPIECE"="DOS"."PIECEINIT")
       filter("P"."REFDOSS" IS NOT NULL)
  60 - access("GCA"."REFDOSS"="P"."REFDOSS")
       filter(("GCA"."COMMFIN_TYPE" LIKE '%ITRBQ_VALUE_DATE%' AND (("P"."FG07"='O' AND
              TO_NUMBER(TO_CHAR(INTERNAL_FUNCTION("GCA"."COMMFIN_DAY_DT"),'j'))<=:B5) OR (NVL("P"."FG07",'N')='N' AND
              TO_NUMBER(TO_CHAR(INTERNAL_FUNCTION("GCA"."COMMFIN_DAY_DT"),'j'))>=:B3 AND
              TO_NUMBER(TO_CHAR(INTERNAL_FUNCTION("GCA"."COMMFIN_DAY_DT"),'j'))<=:B5)) AND "GCA"."COMMFIN_TYPE" IS NOT NULL))
*/
/********************************New Metrics***************************************/

/********************************Index statistics**********************************/

/********************************Other SQLs****************************************/          
/*

*/ 
/********************************Other SQLs****************************************/              
