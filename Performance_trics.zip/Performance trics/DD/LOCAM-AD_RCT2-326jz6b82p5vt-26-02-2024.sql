/********************************************************************************
*********       E-mail subject: OCAMWEB-7524
*********             Instance: AD RCT2
*********          Description: 
Problem:
A query was provided from LOCAM AD RCT2 as slow.

Analysis:
We executed the query manualy on LOCAM AD RCT2 and in its execution plan we saw that the tables was joined in inappropriate order,
which leads to selecting a lot of rows from imxad.AD_LEASING_CASES alc and then accessing imxad.AD_INDIVIDU_MVIEW aim2 for each row, 
which heavy and it is not OK from Performance point of view. The solution is to use hits to access the tables in the correct order.

Suggestion:
Please add hints as it is shown in the New SQL section below.

*********               SQL_ID: 326jz6b82p5vt
*********      Program/Package: 
*********              Request: Dimitare Ivanov
*********               Author: Dimitar Dimitrov
********* Received e-mail date: 26/02/2024
*********      Resolution date: 26/02/2024
*********  Trace old file here: \\epox\specifs\performance\tmp\
*********  Trace new file here:
***********************************************************************************/

/********************************OLD SQL*******************************************/
WITH tempo1 AS ( SELECT /*+ no_push_pred */
                       p2.REFPIECE as REFPIECE1,
                       alc2.TI_PARTNER_REFINDIVIDU as TI_PARTNER_REFINDIVIDU1,
                       MAX( p2.DT01_DT ) as max_date1,
                       TO_CHAR(P2.DT01_DT, 'MM-YYYY') AS Mois_annee2
                  FROM IMXAD.G_PIECEDET p2
                       LEFT JOIN IMXAD.G_PIECE GP2
                    ON P2.REFPIECE = GP2.REFPIECE
                   AND TYPPIECE = 'FINANCING REQUEST'
                       LEFT JOIN imxad.AD_LEASING_CASES alc2
                    ON GP2.REFDOSS = alc2.REFDOSS
                 WHERE p2.STR1 = 'PRE'
                   AND p2.TYPE = 'REQUEST SITUATIONS'
                   AND p2.DT01_DT BETWEEN to_date( TO_CHAR( SYSDATE, 'YYYY' ) - 1 || TO_CHAR( SYSDATE, 'MM' ) - 1,'YYYYMM' ) 
                   AND to_date( TO_CHAR( SYSDATE, 'YYYY' ) || TO_CHAR( SYSDATE, 'MM' ), 'YYYYMM')
                   AND  alc2.TI_PARTNER_REFINDIVIDU = 'A600ZGZX'
              GROUP BY p2.REFPIECE,
                       alc2.TI_PARTNER_REFINDIVIDU,
                       TO_CHAR(P2.DT01_DT, 'MM-YYYY' ) ),
                       tempo2 AS (
                                   SELECT /*+ no_push_pred */
                                          p3.REFPIECE as REFPIECE2,
                                          alc3.TI_PARTNER_REFINDIVIDU as TI_PARTNER_REFINDIVIDU2,
                                          MAX(p3.DT01_DT) as max_date2,
                                          TO_CHAR(P3.DT01_DT, 'MM-YYYY') AS Mois_annee3
                                     FROM IMXAD.G_PIECEDET p3
                                LEFT JOIN IMXAD.G_PIECE GP3 
                                       ON P3.REFPIECE = GP3.REFPIECE
                                      AND TYPPIECE = 'FINANCING REQUEST'
                                LEFT JOIN imxad.AD_LEASING_CASES alc3
                                       ON GP3.REFDOSS = alc3.REFDOSS
                                LEFT JOIN imxad.AD_LESSEE al3
                                       ON alc3.TI_LESSEE_REFINDIVIDU = al3.REFINDIVIDU
                                LEFT JOIN imxad.AD_INDIVIDU_MVIEW aim3
                                       ON alc3.TI_LESSEE_REFINDIVIDU = aim3.U_REFINDIVIDU
                                    WHERE p3.STR1 = 'PRE'
                                      AND p3.TYPE = 'REQUEST SITUATIONS'
                                      AND p3.DT01_DT BETWEEN to_date( TO_CHAR( SYSDATE, 'YYYY' ) - 1 || TO_CHAR( SYSDATE, 'MM' ) - 1, 'YYYYMM' ) 
                                      AND to_date( TO_CHAR( SYSDATE, 'YYYY' ) || TO_CHAR( SYSDATE, 'MM' ), 'YYYYMM' )
                                      AND TO_CHAR(SYSDATE, 'YYYY') - TO_CHAR(al3.DT_CREATION_DT, 'YYYY') < 3
                                      AND MONTHS_BETWEEN(SYSDATE, aim3.GI_DTCREASOC_DT) < 36
                                      AND  alc3.TI_PARTNER_REFINDIVIDU = 'A600ZGZX'
                                    GROUP BY p3.REFPIECE,
                                             alc3.TI_PARTNER_REFINDIVIDU,
                                             TO_CHAR( P3.DT01_DT, 'MM-YYYY' ) 
                                  )
                SELECT distinct SUBSTR( ap.SIRET, 1, 9 ) AS Siren,
                       ap.SIRET AS Siret,
                       ap.REFINDIVIDU AS Ref_Int_Indiv,
                       aim.U_REFEXT AS Ref_Ext_Indiv,
                       ap.RAISSOC1 AS Raison_sociale,
                       TO_CHAR(P.DT01_DT, 'MM-YYYY') AS Mois_annee,
                       alc.DEVISE AS Devise,
                       count(DISTINCT tempo1.refpiece1) AS Nb_dfi_total,
                       count(distinct tempo2.refpiece2) AS Nb_dfi_ent_moins3ans,
                       TO_CHAR(P.DT01_DT, 'YYYY-MM') AS tri
                  FROM IMXAD.G_PIECEDET P
                  JOIN IMXAD.G_PIECE GP
                    ON P.REFPIECE = GP.REFPIECE
                   AND TYPPIECE = 'FINANCING REQUEST'
                  JOIN imxad.AD_LEASING_CASES alc
                    ON GP.REFDOSS = alc.REFDOSS
                  JOIN imxad.AD_PART ap
                    ON alc.TI_PARTNER_REFINDIVIDU = ap.REFINDIVIDU
                  JOIN imxad.AD_INDIVIDU_MVIEW aim
                    ON alc.TI_PARTNER_REFINDIVIDU = aim.U_REFINDIVIDU
                  JOIN imxad.AD_INDIVIDU_MVIEW aim2
                    ON alc.TI_LESSEE_REFINDIVIDU = aim2.U_REFINDIVIDU
                  JOIN tempo1
                    ON alc.TI_PARTNER_REFINDIVIDU = tempo1.TI_PARTNER_REFINDIVIDU1
                   AND TO_CHAR( P.DT01_DT, 'MM-YYYY' ) = tempo1.Mois_annee2
             LEFT JOIN tempo2
                    ON alc.TI_PARTNER_REFINDIVIDU = tempo2.TI_PARTNER_REFINDIVIDU2
                   AND TO_CHAR( P.DT01_DT, 'MM-YYYY' ) = tempo2.Mois_annee3
                 WHERE P.TYPE = 'REQUEST SITUATIONS'
                   AND P.STR1 IN ( 'PRE', 'AOFI', 'AREF', 'REFD', 'REF' )
                   AND to_date(TO_CHAR(P.DT01_DT, 'YYYYMM'), 'YYYYMM') BETWEEN to_date( TO_CHAR( SYSDATE, 'YYYY' ) - 1 || TO_CHAR( SYSDATE, 'MM' ) - 1, 'YYYYMM' ) 
                   AND to_date( TO_CHAR( SYSDATE, 'YYYY' ) || TO_CHAR( SYSDATE, 'MM' ) - 1, 'YYYYMM' )
                   AND ap.REFINDIVIDU = 'A600ZGZX'
                 GROUP BY ap.SIRET,
                          SUBSTR(ap.SIRET, 1, 9),
                          ap.REFINDIVIDU,
                          aim.U_REFEXT,
                          ap.RAISSOC1,
                          TO_CHAR(P.DT01_DT, 'MM-YYYY'),
                          alc.DEVISE,
                          TO_CHAR(P.DT01_DT, 'YYYY-MM'),
                     CASE WHEN MONTHS_BETWEEN(SYSDATE, aim2.GI_DTCREASOC_DT) < 36 
                          THEN  'Oui'
                          ELSE 'Non'
                      END,
                          TO_CHAR(P.DT01_DT, 'YYYYMM')
                 ORDER BY siret, tri ASC;
/********************************OLD SQL*******************************************/
/********************************OLD Metrics***************************************/
/*
Plan hash value: 2540131134
----------------------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                          | Name                         | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers |
----------------------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                                   |                              |      1 |        |  4239 (100)|      5 |00:00:13.24 |    5783K|
|   1 |  SORT ORDER BY                                     |                              |      1 |      1 |  4239   (1)|      5 |00:00:13.24 |    5783K|
|   2 |   HASH UNIQUE                                      |                              |      1 |      1 |  4239   (1)|      5 |00:00:13.24 |    5783K|
|   3 |    SORT GROUP BY                                   |                              |      1 |      1 |  4239   (1)|      9 |00:00:13.24 |    5783K|
|   4 |     NESTED LOOPS                                   |                              |      1 |      1 |  4238   (1)|   2005K|00:00:07.20 |    5783K|
|   5 |      NESTED LOOPS                                  |                              |      1 |      1 |  4238   (1)|   2005K|00:00:04.87 |    4081K|
|   6 |       MERGE JOIN CARTESIAN                         |                              |      1 |      1 |  4234   (1)|   2005K|00:00:01.82 |   53436 |
|*  7 |        HASH JOIN OUTER                             |                              |      1 |      1 |  4230   (1)|   2005K|00:00:00.84 |   53432 |
|*  8 |         HASH JOIN                                  |                              |      1 |      1 |  2881   (1)|    308K|00:00:00.16 |   50545 |
|   9 |          NESTED LOOPS                              |                              |      1 |      1 |  1209   (1)|   1504 |00:00:00.08 |   43979 |
|  10 |           NESTED LOOPS                             |                              |      1 |     11 |  1209   (1)|  13022 |00:00:00.07 |   30889 |
|  11 |            NESTED LOOPS                            |                              |      1 |     11 |  1187   (1)|  13022 |00:00:00.06 |   20729 |
|  12 |             NESTED LOOPS                           |                              |      1 |     11 |  1165   (1)|  13023 |00:00:00.03 |    4359 |
|  13 |              TABLE ACCESS BY INDEX ROWID           | AD_PART                      |      1 |      1 |     2   (0)|      1 |00:00:00.01 |       3 |
|* 14 |               INDEX UNIQUE SCAN                    | PK_AD_PART                   |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       2 |
|* 15 |              TABLE ACCESS FULL                     | G_PIECEDET                   |      1 |     11 |  1163   (1)|  13023 |00:00:00.03 |    4356 |
|* 16 |             TABLE ACCESS BY INDEX ROWID            | G_PIECE                      |  13023 |      1 |     2   (0)|  13022 |00:00:00.02 |   16370 |
|* 17 |              INDEX UNIQUE SCAN                     | G_PIECE_PK                   |  13023 |      1 |     1   (0)|  13023 |00:00:00.01 |    9785 |
|* 18 |            INDEX UNIQUE SCAN                       | AD_LEASING_CASES_PK          |  13022 |      1 |     1   (0)|  13022 |00:00:00.01 |   10160 |
|* 19 |           TABLE ACCESS BY INDEX ROWID              | AD_LEASING_CASES             |  13022 |      1 |     2   (0)|   1504 |00:00:00.01 |   13090 |
|  20 |          VIEW                                      |                              |      1 |      1 |  1672   (1)|    564 |00:00:00.05 |    6566 |
|* 21 |           FILTER                                   |                              |      1 |        |            |    564 |00:00:00.05 |    6566 |
|  22 |            HASH GROUP BY                           |                              |      1 |      1 |  1672   (1)|    564 |00:00:00.05 |    6566 |
|* 23 |             FILTER                                 |                              |      1 |        |            |    665 |00:00:00.04 |    6566 |
|  24 |              NESTED LOOPS                          |                              |      1 |     34 |  1671   (1)|    665 |00:00:00.04 |    6566 |
|  25 |               NESTED LOOPS                         |                              |      1 |    164 |  1671   (1)|   2606 |00:00:00.04 |    4620 |
|* 26 |                HASH JOIN                           |                              |      1 |    164 |  1276   (1)|   1307 |00:00:00.04 |    2148 |
|* 27 |                 VIEW                               | index$_join$_004             |      1 |   2562 |   579   (1)|   2616 |00:00:00.03 |     647 |
|* 28 |                  HASH JOIN                         |                              |      1 |        |            |   2616 |00:00:00.03 |     647 |
|* 29 |                   INDEX RANGE SCAN                 | AD_LEASING_CASES_PARTNER_IDX |      1 |   2562 |    10   (0)|   2616 |00:00:00.01 |      18 |
|  30 |                   INDEX FAST FULL SCAN             | AD_LEASING_CASES_PK          |      1 |   2562 |   711   (1)|    148K|00:00:00.01 |     629 |
|* 31 |                 TABLE ACCESS BY INDEX ROWID BATCHED| G_PIECE                      |      1 |   9566 |   697   (0)|  10661 |00:00:00.01 |    1501 |
|* 32 |                  INDEX RANGE SCAN                  | G_PIECE_TYPE_IDX             |      1 |  10678 |    55   (0)|  10661 |00:00:00.01 |      70 |
|* 33 |                INDEX RANGE SCAN                    | G_PIECEDE_IDX1               |   1307 |      1 |     2   (0)|   2606 |00:00:00.01 |    2472 |
|* 34 |               TABLE ACCESS BY INDEX ROWID          | G_PIECEDET                   |   2606 |      1 |     3   (0)|    665 |00:00:00.01 |    1946 |
|  35 |         VIEW                                       |                              |      1 |      1 |  1349   (1)|     14 |00:00:00.07 |    2887 |
|  36 |          HASH GROUP BY                             |                              |      1 |      1 |  1349   (1)|     14 |00:00:00.07 |    2887 |
|* 37 |           FILTER                                   |                              |      1 |        |            |     23 |00:00:00.07 |    2887 |
|* 38 |            FILTER                                  |                              |      1 |        |            |     23 |00:00:00.07 |    2887 |
|  39 |             NESTED LOOPS OUTER                     |                              |      1 |      1 |  1348   (1)|     23 |00:00:00.07 |    2887 |
|  40 |              NESTED LOOPS                          |                              |      1 |      1 |  1344   (1)|     23 |00:00:00.07 |    2825 |
|  41 |               NESTED LOOPS                         |                              |      1 |      1 |  1341   (1)|    152 |00:00:00.07 |    2301 |
|* 42 |                HASH JOIN RIGHT SEMI                |                              |      1 |      1 |  1339   (1)|    304 |00:00:00.07 |    1857 |
|* 43 |                 TABLE ACCESS FULL                  | AD_LESSEE                    |      1 |    499 |   171   (1)|   2358 |00:00:00.01 |     581 |
|* 44 |                 VIEW                               | index$_join$_009             |      1 |   2562 |  1169   (1)|   2616 |00:00:00.06 |    1276 |
|* 45 |                  HASH JOIN                         |                              |      1 |        |            |   2616 |00:00:00.06 |    1276 |
|* 46 |                   HASH JOIN                        |                              |      1 |        |            |   2616 |00:00:00.03 |     647 |
|* 47 |                    INDEX RANGE SCAN                | AD_LEASING_CASES_PARTNER_IDX |      1 |   2562 |    10   (0)|   2616 |00:00:00.01 |      18 |
|  48 |                    INDEX FAST FULL SCAN            | AD_LEASING_CASES_LESSEE_IDX  |      1 |   2562 |   724   (0)|    148K|00:00:00.01 |     629 |
|  49 |                   INDEX FAST FULL SCAN             | AD_LEASING_CASES_PK          |      1 |   2562 |   711   (1)|    148K|00:00:00.01 |     629 |
|* 50 |                INDEX RANGE SCAN                    | G_PIECE_IDX1                 |    304 |      1 |     2   (0)|    152 |00:00:00.01 |     444 |
|* 51 |               TABLE ACCESS BY INDEX ROWID BATCHED  | G_PIECEDET                   |    152 |      1 |     3   (0)|     23 |00:00:00.01 |     524 |
|* 52 |                INDEX RANGE SCAN                    | G_PIECEDE_IDX1               |    152 |      1 |     2   (0)|    359 |00:00:00.01 |     252 |
|  53 |              MAT_VIEW ACCESS BY INDEX ROWID BATCHED| AD_INDIVIDU_MVIEW            |     23 |      1 |     4   (0)|     23 |00:00:00.01 |      62 |
|* 54 |               INDEX RANGE SCAN                     | AD_INDIVIDU_MVIEW_IDX        |     23 |      1 |     2   (0)|     23 |00:00:00.01 |      48 |
|  55 |        BUFFER SORT                                 |                              |   2005K|      1 |  4234   (1)|   2005K|00:00:00.42 |       4 |
|  56 |         MAT_VIEW ACCESS BY INDEX ROWID BATCHED     | AD_INDIVIDU_MVIEW            |      1 |      1 |     4   (0)|      1 |00:00:00.01 |       4 |
|* 57 |          INDEX RANGE SCAN                          | AD_INDIVIDU_MVIEW_IDX        |      1 |      1 |     2   (0)|      1 |00:00:00.01 |       3 |
|* 58 |       INDEX RANGE SCAN                             | AD_INDIVIDU_MVIEW_IDX        |   2005K|      1 |     2   (0)|   2005K|00:00:02.65 |    4028K|
|  59 |      MAT_VIEW ACCESS BY INDEX ROWID                | AD_INDIVIDU_MVIEW            |   2005K|      1 |     4   (0)|   2005K|00:00:01.93 |    1702K|
----------------------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   7 - access("TEMPO2"."MOIS_ANNEE3"=TO_CHAR(INTERNAL_FUNCTION("P"."DT01_DT"),'MM-YYYY') AND
              "ALC"."TI_PARTNER_REFINDIVIDU"="TEMPO2"."TI_PARTNER_REFINDIVIDU2")
   8 - access("ALC"."TI_PARTNER_REFINDIVIDU"="TEMPO1"."TI_PARTNER_REFINDIVIDU1" AND
              "TEMPO1"."MOIS_ANNEE2"=TO_CHAR(INTERNAL_FUNCTION("P"."DT01_DT"),'MM-YYYY'))
  14 - access("AP"."REFINDIVIDU"='A600ZGZX')
  15 - filter(("P"."TYPE"='REQUEST SITUATIONS' AND INTERNAL_FUNCTION("P"."STR1") AND
              TO_DATE(TO_CHAR(INTERNAL_FUNCTION("P"."DT01_DT"),'YYYYMM'),'YYYYMM')<=TO_DATE(TO_CHAR(TO_NUMBER(TO_CHAR(SYSDATE@!,'YYYY')||TO_CHAR(SYSDATE@!,'MM')
              )-1),'YYYYMM') AND TO_DATE(TO_CHAR(INTERNAL_FUNCTION("P"."DT01_DT"),'YYYYMM'),'YYYYMM')>=TO_DATE(TO_CHAR(TO_NUMBER(TO_CHAR(TO_NUMBER(TO_CHAR(SYSDA
              TE@!,'YYYY'))-1)||TO_CHAR(SYSDATE@!,'MM'))-1),'YYYYMM')))
  16 - filter(("TYPPIECE"='FINANCING REQUEST' AND "GP"."REFDOSS" IS NOT NULL))
  17 - access("P"."REFPIECE"="GP"."REFPIECE")
  18 - access("GP"."REFDOSS"="ALC"."REFDOSS")
  19 - filter("ALC"."TI_PARTNER_REFINDIVIDU"='A600ZGZX')
  21 - filter("ALC2"."TI_PARTNER_REFINDIVIDU"='A600ZGZX')
  23 - filter((TO_DATE(TO_CHAR(SYSDATE@!,'YYYY')||TO_CHAR(SYSDATE@!,'MM'),'YYYYMM')>=TO_DATE(TO_CHAR(TO_NUMBER(TO_CHAR(TO_NUMBER(TO_CHAR(SYSDATE@!
              ,'YYYY'))-1)||TO_CHAR(SYSDATE@!,'MM'))-1),'YYYYMM') AND TO_DATE(TO_CHAR(TO_NUMBER(TO_CHAR(SYSDATE@!,'YYYY')||TO_CHAR(SYSDATE@!,'MM'))-1),'YYYYMM')
              >=TO_DATE(TO_CHAR(TO_NUMBER(TO_CHAR(TO_NUMBER(TO_CHAR(SYSDATE@!,'YYYY'))-1)||TO_CHAR(SYSDATE@!,'MM'))-1),'YYYYMM')))
  26 - access("GP2"."REFDOSS"="ALC2"."REFDOSS")
  27 - filter("ALC2"."TI_PARTNER_REFINDIVIDU"='A600ZGZX')
  28 - access(ROWID=ROWID)
  29 - access("ALC2"."TI_PARTNER_REFINDIVIDU"='A600ZGZX')
  31 - filter("GP2"."REFDOSS" IS NOT NULL)
  32 - access("TYPPIECE"='FINANCING REQUEST')
  33 - access("P2"."REFPIECE"="GP2"."REFPIECE" AND "P2"."TYPE"='REQUEST SITUATIONS')
  34 - filter(("P2"."STR1"='PRE' AND "P2"."DT01_DT">=TO_DATE(TO_CHAR(TO_NUMBER(TO_CHAR(TO_NUMBER(TO_CHAR(SYSDATE@!,'YYYY'))-1)||TO_CHAR(SYSDATE@!,
              'MM'))-1),'YYYYMM') AND "P2"."DT01_DT"<=TO_DATE(TO_CHAR(SYSDATE@!,'YYYY')||TO_CHAR(SYSDATE@!,'MM'),'YYYYMM')))
  37 - filter(TO_DATE(TO_CHAR(SYSDATE@!,'YYYY')||TO_CHAR(SYSDATE@!,'MM'),'YYYYMM')>=TO_DATE(TO_CHAR(TO_NUMBER(TO_CHAR(TO_NUMBER(TO_CHAR(SYSDATE@!,
              'YYYY'))-1)||TO_CHAR(SYSDATE@!,'MM'))-1),'YYYYMM'))
  38 - filter(MONTHS_BETWEEN(SYSDATE@!,INTERNAL_FUNCTION("AIM3"."GI_DTCREASOC_DT"))<36)
  42 - access("ALC3"."TI_LESSEE_REFINDIVIDU"="AL3"."REFINDIVIDU")
  43 - filter(TO_NUMBER(TO_CHAR(SYSDATE@!,'YYYY'))-TO_NUMBER(TO_CHAR(INTERNAL_FUNCTION("AL3"."DT_CREATION_DT"),'YYYY'))<3)
  44 - filter("ALC3"."TI_PARTNER_REFINDIVIDU"='A600ZGZX')
  45 - access(ROWID=ROWID)
  46 - access(ROWID=ROWID)
  47 - access("ALC3"."TI_PARTNER_REFINDIVIDU"='A600ZGZX')
  50 - access("GP3"."REFDOSS"="ALC3"."REFDOSS" AND "TYPPIECE"='FINANCING REQUEST')
       filter(("TYPPIECE"='FINANCING REQUEST' AND "GP3"."REFDOSS" IS NOT NULL))
  51 - filter(("P3"."STR1"='PRE' AND "P3"."DT01_DT">=TO_DATE(TO_CHAR(TO_NUMBER(TO_CHAR(TO_NUMBER(TO_CHAR(SYSDATE@!,'YYYY'))-1)||TO_CHAR(SYSDATE@!,
              'MM'))-1),'YYYYMM') AND "P3"."DT01_DT"<=TO_DATE(TO_CHAR(SYSDATE@!,'YYYY')||TO_CHAR(SYSDATE@!,'MM'),'YYYYMM')))
  52 - access("P3"."REFPIECE"="GP3"."REFPIECE" AND "P3"."TYPE"='REQUEST SITUATIONS')
  54 - access("ALC3"."TI_LESSEE_REFINDIVIDU"="AIM3"."U_REFINDIVIDU")
  57 - access("AIM"."U_REFINDIVIDU"='A600ZGZX')
  58 - access("ALC"."TI_LESSEE_REFINDIVIDU"="AIM2"."U_REFINDIVIDU")
*/
/********************************OLD Metrics***************************************/

/********************************New SQL*******************************************/

WITH tempo1 AS ( SELECT /*+ no_push_pred */
                       p2.REFPIECE as REFPIECE1,
                       alc2.TI_PARTNER_REFINDIVIDU as TI_PARTNER_REFINDIVIDU1,
                       MAX( p2.DT01_DT ) as max_date1,
                       TO_CHAR(P2.DT01_DT, 'MM-YYYY') AS Mois_annee2
                  FROM IMXAD.G_PIECEDET p2
                       LEFT JOIN IMXAD.G_PIECE GP2
                    ON P2.REFPIECE = GP2.REFPIECE
                   AND TYPPIECE = 'FINANCING REQUEST'
                       LEFT JOIN imxad.AD_LEASING_CASES alc2
                    ON GP2.REFDOSS = alc2.REFDOSS
                 WHERE p2.STR1 = 'PRE'
                   AND p2.TYPE = 'REQUEST SITUATIONS'
                   AND p2.DT01_DT BETWEEN to_date( TO_CHAR( SYSDATE, 'YYYY' ) - 1 || TO_CHAR( SYSDATE, 'MM' ) - 1,'YYYYMM' ) 
                   AND to_date( TO_CHAR( SYSDATE, 'YYYY' ) || TO_CHAR( SYSDATE, 'MM' ), 'YYYYMM')
                   AND  alc2.TI_PARTNER_REFINDIVIDU = 'A600ZGZX'
              GROUP BY p2.REFPIECE,
                       alc2.TI_PARTNER_REFINDIVIDU,
                       TO_CHAR(P2.DT01_DT, 'MM-YYYY' ) ),
                       tempo2 AS (
                                   SELECT /*+ no_push_pred */
                                          p3.REFPIECE as REFPIECE2,
                                          alc3.TI_PARTNER_REFINDIVIDU as TI_PARTNER_REFINDIVIDU2,
                                          MAX(p3.DT01_DT) as max_date2,
                                          TO_CHAR(P3.DT01_DT, 'MM-YYYY') AS Mois_annee3
                                     FROM IMXAD.G_PIECEDET p3
                                LEFT JOIN IMXAD.G_PIECE GP3 
                                       ON P3.REFPIECE = GP3.REFPIECE
                                      AND TYPPIECE = 'FINANCING REQUEST'
                                LEFT JOIN imxad.AD_LEASING_CASES alc3
                                       ON GP3.REFDOSS = alc3.REFDOSS
                                LEFT JOIN imxad.AD_LESSEE al3
                                       ON alc3.TI_LESSEE_REFINDIVIDU = al3.REFINDIVIDU
                                LEFT JOIN imxad.AD_INDIVIDU_MVIEW aim3
                                       ON alc3.TI_LESSEE_REFINDIVIDU = aim3.U_REFINDIVIDU
                                    WHERE p3.STR1 = 'PRE'
                                      AND p3.TYPE = 'REQUEST SITUATIONS'
                                      AND p3.DT01_DT BETWEEN to_date( TO_CHAR( SYSDATE, 'YYYY' ) - 1 || TO_CHAR( SYSDATE, 'MM' ) - 1, 'YYYYMM' ) 
                                      AND to_date( TO_CHAR( SYSDATE, 'YYYY' ) || TO_CHAR( SYSDATE, 'MM' ), 'YYYYMM' )
                                      AND TO_CHAR(SYSDATE, 'YYYY') - TO_CHAR(al3.DT_CREATION_DT, 'YYYY') < 3
                                      AND MONTHS_BETWEEN(SYSDATE, aim3.GI_DTCREASOC_DT) < 36
                                      AND  alc3.TI_PARTNER_REFINDIVIDU = 'A600ZGZX'
                                    GROUP BY p3.REFPIECE,
                                             alc3.TI_PARTNER_REFINDIVIDU,
                                             TO_CHAR( P3.DT01_DT, 'MM-YYYY' ) 
                                  )
                SELECT /*+ leading(ap alc aim ) */
                       distinct SUBSTR( ap.SIRET, 1, 9 ) AS Siren,
                       ap.SIRET AS Siret,
                       ap.REFINDIVIDU AS Ref_Int_Indiv,
                       aim.U_REFEXT AS Ref_Ext_Indiv,
                       ap.RAISSOC1 AS Raison_sociale,
                       TO_CHAR(P.DT01_DT, 'MM-YYYY') AS Mois_annee,
                       alc.DEVISE AS Devise,
                       count(DISTINCT tempo1.refpiece1) AS Nb_dfi_total,
                       count(distinct tempo2.refpiece2) AS Nb_dfi_ent_moins3ans,
                       TO_CHAR(P.DT01_DT, 'YYYY-MM') AS tri
                  FROM IMXAD.G_PIECEDET P
                  JOIN IMXAD.G_PIECE GP
                    ON P.REFPIECE = GP.REFPIECE
                   AND TYPPIECE = 'FINANCING REQUEST'
                  JOIN imxad.AD_LEASING_CASES alc
                    ON GP.REFDOSS = alc.REFDOSS
                  JOIN imxad.AD_PART ap
                    ON alc.TI_PARTNER_REFINDIVIDU = ap.REFINDIVIDU
                  JOIN imxad.AD_INDIVIDU_MVIEW aim
                    ON alc.TI_PARTNER_REFINDIVIDU = aim.U_REFINDIVIDU
                  JOIN imxad.AD_INDIVIDU_MVIEW aim2
                    ON alc.TI_LESSEE_REFINDIVIDU = aim2.U_REFINDIVIDU
                  JOIN tempo1
                    ON alc.TI_PARTNER_REFINDIVIDU = tempo1.TI_PARTNER_REFINDIVIDU1
                   AND TO_CHAR( P.DT01_DT, 'MM-YYYY' ) = tempo1.Mois_annee2
             LEFT JOIN tempo2
                    ON alc.TI_PARTNER_REFINDIVIDU = tempo2.TI_PARTNER_REFINDIVIDU2
                   AND TO_CHAR( P.DT01_DT, 'MM-YYYY' ) = tempo2.Mois_annee3
                 WHERE P.TYPE = 'REQUEST SITUATIONS'
                   AND P.STR1 IN ( 'PRE', 'AOFI', 'AREF', 'REFD', 'REF' )
                   AND to_date(TO_CHAR(P.DT01_DT, 'YYYYMM'), 'YYYYMM') BETWEEN to_date( TO_CHAR( SYSDATE, 'YYYY' ) - 1 || TO_CHAR( SYSDATE, 'MM' ) - 1, 'YYYYMM' ) 
                   AND to_date( TO_CHAR( SYSDATE, 'YYYY' ) || TO_CHAR( SYSDATE, 'MM' ) - 1, 'YYYYMM' )
                   AND ap.REFINDIVIDU = 'A600ZGZX'
                 GROUP BY ap.SIRET,
                          SUBSTR(ap.SIRET, 1, 9),
                          ap.REFINDIVIDU,
                          aim.U_REFEXT,
                          ap.RAISSOC1,
                          TO_CHAR(P.DT01_DT, 'MM-YYYY'),
                          alc.DEVISE,
                          TO_CHAR(P.DT01_DT, 'YYYY-MM'),
                     CASE WHEN MONTHS_BETWEEN(SYSDATE, aim2.GI_DTCREASOC_DT) < 36 
                          THEN  'Oui'
                          ELSE 'Non'
                      END,
                          TO_CHAR(P.DT01_DT, 'YYYYMM')
                 ORDER BY siret, tri ASC;
/********************************New SQL*******************************************/
/********************************New Metrics***************************************/
/*
Plan hash value: 4012397126
---------------------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                         | Name                         | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers |
---------------------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                                  |                              |      1 |        |  5734 (100)|      5 |00:00:06.24 |   25254 |
|   1 |  SORT ORDER BY                                    |                              |      1 |      1 |  5734   (1)|      5 |00:00:06.24 |   25254 |
|   2 |   HASH UNIQUE                                     |                              |      1 |      1 |  5734   (1)|      5 |00:00:06.24 |   25254 |
|   3 |    SORT GROUP BY                                  |                              |      1 |      1 |  5734   (1)|      9 |00:00:06.24 |   25254 |
|*  4 |     HASH JOIN OUTER                               |                              |      1 |      1 |  5733   (1)|   2005K|00:00:00.64 |   25254 |
|*  5 |      HASH JOIN                                    |                              |      1 |      1 |  4383   (1)|    308K|00:00:00.16 |   22367 |
|   6 |       NESTED LOOPS                                |                              |      1 |      1 |  2711   (1)|   1504 |00:00:00.08 |   15801 |
|   7 |        NESTED LOOPS                               |                              |      1 |      1 |  2711   (1)|   1504 |00:00:00.08 |   14909 |
|   8 |         NESTED LOOPS                              |                              |      1 |      1 |  2707   (1)|   1504 |00:00:00.07 |   11930 |
|*  9 |          HASH JOIN                                |                              |      1 |    164 |  2313   (1)|   1307 |00:00:00.07 |    7512 |
|* 10 |           HASH JOIN                               |                              |      1 |   2570 |  1615   (1)|   2616 |00:00:00.05 |    6011 |
|  11 |            NESTED LOOPS                           |                              |      1 |      1 |     6   (0)|      1 |00:00:00.01 |       7 |
|  12 |             TABLE ACCESS BY INDEX ROWID           | AD_PART                      |      1 |      1 |     2   (0)|      1 |00:00:00.01 |       3 |
|* 13 |              INDEX UNIQUE SCAN                    | PK_AD_PART                   |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       2 |
|  14 |             MAT_VIEW ACCESS BY INDEX ROWID BATCHED| AD_INDIVIDU_MVIEW            |      1 |      1 |     4   (0)|      1 |00:00:00.01 |       4 |
|* 15 |              INDEX RANGE SCAN                     | AD_INDIVIDU_MVIEW_IDX        |      1 |      1 |     2   (0)|      1 |00:00:00.01 |       3 |
|* 16 |            TABLE ACCESS FULL                      | AD_LEASING_CASES             |      1 |   2562 |  1609   (1)|   2616 |00:00:00.05 |    6004 |
|* 17 |           TABLE ACCESS BY INDEX ROWID BATCHED     | G_PIECE                      |      1 |   9566 |   697   (0)|  10661 |00:00:00.01 |    1501 |
|* 18 |            INDEX RANGE SCAN                       | G_PIECE_TYPE_IDX             |      1 |  10678 |    55   (0)|  10661 |00:00:00.01 |      70 |
|* 19 |          TABLE ACCESS BY INDEX ROWID BATCHED      | G_PIECEDET                   |   1307 |      1 |     3   (0)|   1504 |00:00:00.01 |    4418 |
|* 20 |           INDEX RANGE SCAN                        | G_PIECEDE_IDX1               |   1307 |      1 |     2   (0)|   2606 |00:00:00.01 |    2472 |
|* 21 |         INDEX RANGE SCAN                          | AD_INDIVIDU_MVIEW_IDX        |   1504 |      1 |     2   (0)|   1504 |00:00:00.01 |    2979 |
|  22 |        MAT_VIEW ACCESS BY INDEX ROWID             | AD_INDIVIDU_MVIEW            |   1504 |      1 |     4   (0)|   1504 |00:00:00.01 |     892 |
|  23 |       VIEW                                        |                              |      1 |      1 |  1672   (1)|    564 |00:00:00.04 |    6566 |
|* 24 |        FILTER                                     |                              |      1 |        |            |    564 |00:00:00.04 |    6566 |
|  25 |         HASH GROUP BY                             |                              |      1 |      1 |  1672   (1)|    564 |00:00:00.04 |    6566 |
|* 26 |          FILTER                                   |                              |      1 |        |            |    665 |00:00:00.04 |    6566 |
|  27 |           NESTED LOOPS                            |                              |      1 |     34 |  1671   (1)|    665 |00:00:00.04 |    6566 |
|  28 |            NESTED LOOPS                           |                              |      1 |    164 |  1671   (1)|   2606 |00:00:00.04 |    4620 |
|* 29 |             HASH JOIN                             |                              |      1 |    164 |  1276   (1)|   1307 |00:00:00.04 |    2148 |
|* 30 |              VIEW                                 | index$_join$_004             |      1 |   2562 |   579   (1)|   2616 |00:00:00.03 |     647 |
|* 31 |               HASH JOIN                           |                              |      1 |        |            |   2616 |00:00:00.03 |     647 |
|* 32 |                INDEX RANGE SCAN                   | AD_LEASING_CASES_PARTNER_IDX |      1 |   2562 |    10   (0)|   2616 |00:00:00.01 |      18 |
|  33 |                INDEX FAST FULL SCAN               | AD_LEASING_CASES_PK          |      1 |   2562 |   711   (1)|    148K|00:00:00.01 |     629 |
|* 34 |              TABLE ACCESS BY INDEX ROWID BATCHED  | G_PIECE                      |      1 |   9566 |   697   (0)|  10661 |00:00:00.01 |    1501 |
|* 35 |               INDEX RANGE SCAN                    | G_PIECE_TYPE_IDX             |      1 |  10678 |    55   (0)|  10661 |00:00:00.01 |      70 |
|* 36 |             INDEX RANGE SCAN                      | G_PIECEDE_IDX1               |   1307 |      1 |     2   (0)|   2606 |00:00:00.01 |    2472 |
|* 37 |            TABLE ACCESS BY INDEX ROWID            | G_PIECEDET                   |   2606 |      1 |     3   (0)|    665 |00:00:00.01 |    1946 |
|  38 |      VIEW                                         |                              |      1 |      1 |  1349   (1)|     14 |00:00:00.07 |    2887 |
|  39 |       HASH GROUP BY                               |                              |      1 |      1 |  1349   (1)|     14 |00:00:00.07 |    2887 |
|* 40 |        FILTER                                     |                              |      1 |        |            |     23 |00:00:00.07 |    2887 |
|* 41 |         FILTER                                    |                              |      1 |        |            |     23 |00:00:00.07 |    2887 |
|  42 |          NESTED LOOPS OUTER                       |                              |      1 |      1 |  1348   (1)|     23 |00:00:00.07 |    2887 |
|  43 |           NESTED LOOPS                            |                              |      1 |      1 |  1344   (1)|     23 |00:00:00.07 |    2825 |
|  44 |            NESTED LOOPS                           |                              |      1 |      1 |  1341   (1)|    152 |00:00:00.07 |    2301 |
|* 45 |             HASH JOIN RIGHT SEMI                  |                              |      1 |      1 |  1339   (1)|    304 |00:00:00.07 |    1857 |
|* 46 |              TABLE ACCESS FULL                    | AD_LESSEE                    |      1 |    499 |   171   (1)|   2358 |00:00:00.01 |     581 |
|* 47 |              VIEW                                 | index$_join$_009             |      1 |   2562 |  1169   (1)|   2616 |00:00:00.06 |    1276 |
|* 48 |               HASH JOIN                           |                              |      1 |        |            |   2616 |00:00:00.06 |    1276 |
|* 49 |                HASH JOIN                          |                              |      1 |        |            |   2616 |00:00:00.03 |     647 |
|* 50 |                 INDEX RANGE SCAN                  | AD_LEASING_CASES_PARTNER_IDX |      1 |   2562 |    10   (0)|   2616 |00:00:00.01 |      18 |
|  51 |                 INDEX FAST FULL SCAN              | AD_LEASING_CASES_LESSEE_IDX  |      1 |   2562 |   724   (0)|    148K|00:00:00.01 |     629 |
|  52 |                INDEX FAST FULL SCAN               | AD_LEASING_CASES_PK          |      1 |   2562 |   711   (1)|    148K|00:00:00.01 |     629 |
|* 53 |             INDEX RANGE SCAN                      | G_PIECE_IDX1                 |    304 |      1 |     2   (0)|    152 |00:00:00.01 |     444 |
|* 54 |            TABLE ACCESS BY INDEX ROWID BATCHED    | G_PIECEDET                   |    152 |      1 |     3   (0)|     23 |00:00:00.01 |     524 |
|* 55 |             INDEX RANGE SCAN                      | G_PIECEDE_IDX1               |    152 |      1 |     2   (0)|    359 |00:00:00.01 |     252 |
|  56 |           MAT_VIEW ACCESS BY INDEX ROWID BATCHED  | AD_INDIVIDU_MVIEW            |     23 |      1 |     4   (0)|     23 |00:00:00.01 |      62 |
|* 57 |            INDEX RANGE SCAN                       | AD_INDIVIDU_MVIEW_IDX        |     23 |      1 |     2   (0)|     23 |00:00:00.01 |      48 |
---------------------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   4 - access("TEMPO2"."MOIS_ANNEE3"=TO_CHAR(INTERNAL_FUNCTION("P"."DT01_DT"),'MM-YYYY') AND
              "ALC"."TI_PARTNER_REFINDIVIDU"="TEMPO2"."TI_PARTNER_REFINDIVIDU2")
   5 - access("ALC"."TI_PARTNER_REFINDIVIDU"="TEMPO1"."TI_PARTNER_REFINDIVIDU1" AND
              "TEMPO1"."MOIS_ANNEE2"=TO_CHAR(INTERNAL_FUNCTION("P"."DT01_DT"),'MM-YYYY'))
   9 - access("GP"."REFDOSS"="ALC"."REFDOSS")
  10 - access("ALC"."TI_PARTNER_REFINDIVIDU"="AIM"."U_REFINDIVIDU")
  13 - access("AP"."REFINDIVIDU"='A600ZGZX')
  15 - access("AIM"."U_REFINDIVIDU"='A600ZGZX')
  16 - filter("ALC"."TI_PARTNER_REFINDIVIDU"='A600ZGZX')
  17 - filter("GP"."REFDOSS" IS NOT NULL)
  18 - access("TYPPIECE"='FINANCING REQUEST')
  19 - filter((INTERNAL_FUNCTION("P"."STR1") AND TO_DATE(TO_CHAR(INTERNAL_FUNCTION("P"."DT01_DT"),'YYYYMM'),'YYYYMM')<=TO_DATE(TO_CHAR(TO_NUMBER(
              TO_CHAR(SYSDATE@!,'YYYY')||TO_CHAR(SYSDATE@!,'MM'))-1),'YYYYMM') AND TO_DATE(TO_CHAR(INTERNAL_FUNCTION("P"."DT01_DT"),'YYYYMM'),'YYYYMM')>=TO_DAT
              E(TO_CHAR(TO_NUMBER(TO_CHAR(TO_NUMBER(TO_CHAR(SYSDATE@!,'YYYY'))-1)||TO_CHAR(SYSDATE@!,'MM'))-1),'YYYYMM')))
  20 - access("P"."REFPIECE"="GP"."REFPIECE" AND "P"."TYPE"='REQUEST SITUATIONS')
  21 - access("ALC"."TI_LESSEE_REFINDIVIDU"="AIM2"."U_REFINDIVIDU")
  24 - filter("ALC2"."TI_PARTNER_REFINDIVIDU"='A600ZGZX')
  26 - filter((TO_DATE(TO_CHAR(SYSDATE@!,'YYYY')||TO_CHAR(SYSDATE@!,'MM'),'YYYYMM')>=TO_DATE(TO_CHAR(TO_NUMBER(TO_CHAR(TO_NUMBER(TO_CHAR(SYSDATE@
              !,'YYYY'))-1)||TO_CHAR(SYSDATE@!,'MM'))-1),'YYYYMM') AND TO_DATE(TO_CHAR(TO_NUMBER(TO_CHAR(SYSDATE@!,'YYYY')||TO_CHAR(SYSDATE@!,'MM'))-1),'YYYYMM
              ')>=TO_DATE(TO_CHAR(TO_NUMBER(TO_CHAR(TO_NUMBER(TO_CHAR(SYSDATE@!,'YYYY'))-1)||TO_CHAR(SYSDATE@!,'MM'))-1),'YYYYMM')))
  29 - access("GP2"."REFDOSS"="ALC2"."REFDOSS")
  30 - filter("ALC2"."TI_PARTNER_REFINDIVIDU"='A600ZGZX')
  31 - access(ROWID=ROWID)
  32 - access("ALC2"."TI_PARTNER_REFINDIVIDU"='A600ZGZX')
  34 - filter("GP2"."REFDOSS" IS NOT NULL)
  35 - access("TYPPIECE"='FINANCING REQUEST')
  36 - access("P2"."REFPIECE"="GP2"."REFPIECE" AND "P2"."TYPE"='REQUEST SITUATIONS')
  37 - filter(("P2"."STR1"='PRE' AND "P2"."DT01_DT">=TO_DATE(TO_CHAR(TO_NUMBER(TO_CHAR(TO_NUMBER(TO_CHAR(SYSDATE@!,'YYYY'))-1)||TO_CHAR(SYSDATE@!
              ,'MM'))-1),'YYYYMM') AND "P2"."DT01_DT"<=TO_DATE(TO_CHAR(SYSDATE@!,'YYYY')||TO_CHAR(SYSDATE@!,'MM'),'YYYYMM')))
  40 - filter(TO_DATE(TO_CHAR(SYSDATE@!,'YYYY')||TO_CHAR(SYSDATE@!,'MM'),'YYYYMM')>=TO_DATE(TO_CHAR(TO_NUMBER(TO_CHAR(TO_NUMBER(TO_CHAR(SYSDATE@!
              ,'YYYY'))-1)||TO_CHAR(SYSDATE@!,'MM'))-1),'YYYYMM'))
  41 - filter(MONTHS_BETWEEN(SYSDATE@!,INTERNAL_FUNCTION("AIM3"."GI_DTCREASOC_DT"))<36)
  45 - access("ALC3"."TI_LESSEE_REFINDIVIDU"="AL3"."REFINDIVIDU")
  46 - filter(TO_NUMBER(TO_CHAR(SYSDATE@!,'YYYY'))-TO_NUMBER(TO_CHAR(INTERNAL_FUNCTION("AL3"."DT_CREATION_DT"),'YYYY'))<3)
  47 - filter("ALC3"."TI_PARTNER_REFINDIVIDU"='A600ZGZX')
  48 - access(ROWID=ROWID)
  49 - access(ROWID=ROWID)
  50 - access("ALC3"."TI_PARTNER_REFINDIVIDU"='A600ZGZX')
  53 - access("GP3"."REFDOSS"="ALC3"."REFDOSS" AND "TYPPIECE"='FINANCING REQUEST')
       filter(("TYPPIECE"='FINANCING REQUEST' AND "GP3"."REFDOSS" IS NOT NULL))
  54 - filter(("P3"."STR1"='PRE' AND "P3"."DT01_DT">=TO_DATE(TO_CHAR(TO_NUMBER(TO_CHAR(TO_NUMBER(TO_CHAR(SYSDATE@!,'YYYY'))-1)||TO_CHAR(SYSDATE@!
              ,'MM'))-1),'YYYYMM') AND "P3"."DT01_DT"<=TO_DATE(TO_CHAR(SYSDATE@!,'YYYY')||TO_CHAR(SYSDATE@!,'MM'),'YYYYMM')))
  55 - access("P3"."REFPIECE"="GP3"."REFPIECE" AND "P3"."TYPE"='REQUEST SITUATIONS')
  57 - access("ALC3"."TI_LESSEE_REFINDIVIDU"="AIM3"."U_REFINDIVIDU")         
*/
/********************************New Metrics***************************************/

/********************************Index statistics**********************************/

/********************************Other SQLs****************************************/          
/*

*/ 
/********************************Other SQLs****************************************/              
