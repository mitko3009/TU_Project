/********************************************************************************
*********       E-mail subject: CIFCDEV-5092
*********             Instance: SAFIVAL
*********          Description: 
Problem:
Slowness in lst_pnp_DebtorBalances function.

Analysis:
The TOP SQL in lst_prog_pnp module for the period between 00:45 and 04:00 on 05/02/2024 of SAFIVAL was 8rfyjqsb0q0dp.
This SQL took 99% of the time. The problem was that Oracle choose bad execution plan because of not correctly gathered statistics.
The stable solution here is to add hints to force Oracle to choose good execution plan regardless of the statistics.

Suggestion:
In the New SQL section there are two variants how the query can be modified. From performance point of view it doesn't matter which variant you will choose, so 
please choose one of the suggested variants and rework the query like it.

*********               SQL_ID: 8rfyjqsb0q0dp
*********      Program/Package: lst_pnp_ClientOutput.pc
*********              Request: Iskren Todorov 
*********               Author: Dimitar Dimitrov
********* Received e-mail date: 06/02/2024
*********      Resolution date: 06/02/2024
*********  Trace old file here: \\epox\specifs\performance\tmp\
*********  Trace new file here:
***********************************************************************************/

/********************************OLD SQL*******************************************/

var B1 VARCHAR2(128);
exec :B1 := '2302140010';
var B2 VARCHAR2(128);
exec :B2 := 'A704A5B7';
var B3 VARCHAR2(128);
exec :B3 := 'C';
var B4 VARCHAR2(128);
exec :B4 := '01/2024';
var B5 NUMBER;
exec :B5 := 1;
var B6 VARCHAR2(128);
exec :B6 := '';
var B7 NUMBER;
exec :B7 := 0;
var B8 VARCHAR2(128);
exec :B8 := 'A704Z5PQ';
var B9 VARCHAR2(128);
exec :B9 := '';
var B9 varchar2(32);
exec :B9 := 'INT00000';
exec utl_app_date.cacheAppDate(:B9);


select MAX(tx15)
  INTO :b0
  FROM g_piece
 WHERE typpiece = 'MEMO_DECOMPTE'
   AND refpiece in (SELECT column_value
                      FROM TABLE(dfx_lst . GetListMemoDecompte(:B1,
                                                     :B2,
                                                     :B3,
                                                     :B4,
                                                     :B5,
                                                     :B6,
                                                     :B7,
                                                     :B8,
                                                     :B9))
                     WHERE ROWNUM < power(10, 12));

/********************************OLD SQL*******************************************/
/********************************OLD Metrics***************************************/
/*
MODULE                           SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
lst_prog_pnp                                                    2066      37936 db file sequential r 2024/02/05 00:46:32  2024/02/05 03:59:54        1073                    2 +000000000 03:13:22.240 13%
STATS_CREATE                                                    1152      64830 db file sequential r 2024/02/05 00:40:03  2024/02/05 03:59:33        1018               147145 +000000000 03:19:30.879 13%


MODULE                           SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
lst_prog_pnp                                                    2066      37936 db file sequential r 2024/02/05 00:46:32  2024/02/05 03:59:54        1073                    2 +000000000 03:13:22.240 95%
lst_prog_pnp                     8rfyjqsb0q0dp 1195547586       2066      37936 db file scattered re 2024/02/05 00:57:37  2024/02/05 03:59:33          46                    2 +000000000 03:01:56.160 4%
lst_prog_pnp                                                    2066      37936 db file parallel rea 2024/02/05 00:47:54  2024/02/05 03:48:17          15                    2 +000000000 03:00:23.680 1%
lst_prog_pnp                                            0       2066      37936 log file sync        2024/02/05 00:46:21  2024/02/05 00:46:21           1                      +000000000 00:00:00.000 0%


MODULE                           SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
lst_prog_pnp                     8rfyjqsb0q0dp 1195547586       2066      37936                      2024/02/05 00:48:24  2024/02/05 03:59:54        1119                    2 +000000000 03:11:29.600 99%
lst_prog_pnp                     474kgjsv7ffyj 2419307246       2066      37936                      2024/02/05 00:47:43  2024/02/05 00:48:14           4                    1 +000000000 00:00:30.720 0%
lst_prog_pnp                     6j7y2vk2jkpxz   80223676       2066      37936 db file sequential r 2024/02/05 00:46:32  2024/02/05 00:46:42           2                    1 +000000000 00:00:10.240 0%
lst_prog_pnp                     64wrm3wqpg97k 4209199340       2066      37936 db file sequential r 2024/02/05 00:47:02  2024/02/05 00:47:02           1                      +000000000 00:00:00.000 0%
lst_prog_pnp                     a8gmswpsu0d7k 2710611693       2066      37936 db file sequential r 2024/02/05 02:52:19  2024/02/05 02:52:19           1                    1 +000000000 00:00:00.000 0%
lst_prog_pnp                     fz8nmr2dy3d1m 1639167574       2066      37936 db file sequential r 2024/02/05 00:46:52  2024/02/05 00:46:52           1                      +000000000 00:00:00.000 0%
lst_prog_pnp                     56k8rnv2c78rg 2586878176       2066      37936 db file sequential r 2024/02/05 00:47:23  2024/02/05 00:47:23           1                    1 +000000000 00:00:00.000 0%
lst_prog_pnp                     157c70nzra3k5 3815996911       2066      37936 db file sequential r 2024/02/05 00:47:13  2024/02/05 00:47:13           1                      +000000000 00:00:00.000 0%
lst_prog_pnp                                            0       2066      37936 log file sync        2024/02/05 00:46:21  2024/02/05 00:46:21           1                      +000000000 00:00:00.000 0%
lst_prog_pnp                     g4b9s2m9s6ms8 1388734953       2066      37936 db file sequential r 2024/02/05 02:52:29  2024/02/05 02:52:29           1                      +000000000 00:00:00.000 0%
lst_prog_pnp                     5y4xhayuq5a5g 3772043142       2066      37936 db file sequential r 2024/02/05 02:51:58  2024/02/05 02:51:58           1                    1 +000000000 00:00:00.000 0%
lst_prog_pnp                     5dbs8y6tyjpxx 1621615037       2066      37936 db file sequential r 2024/02/05 02:52:08  2024/02/05 02:52:08           1                    1 +000000000 00:00:00.000 0%
lst_prog_pnp                     9y4paz6ngqu49  178278603       2066      37936 db file sequential r 2024/02/05 00:47:33  2024/02/05 00:47:33           1                      +000000000 00:00:00.000 0% 
 
 
 
INSTANCE_NUMBER SQL_ID            ELAPSED MAX_WAIT_ON     PC_OF  WAIT_TIME            GETS      READS       ROWS  ELAP/EXEC       GETS/EXEC READS/EXEC  ROWS/EXEC       EXEC PLAN_HASH_VALUE
--------------- ------------- ----------- --------------- ----- ---------- --------------- ---------- ---------- ---------- --------------- ---------- ---------- ---------- ---------------
              1 8rfyjqsb0q0dp       14984 IO              100%    15002.37         2472679     132110          2    3745.97          618170    33027.5         .5          4      1195547586
 

SQL_ID        SQL_PLAN_HASH_VALUE SQL_PLAN_LINE_ID SQL_PLAN_OPERATION             SQL_PLAN_OPTIONS                   ACTIVE
------------- ------------------- ---------------- ------------------------------ ------------------------------ ----------
8rfyjqsb0q0dp          1195547586                3 TABLE ACCESS                   BY INDEX ROWID BATCHED               1075
8rfyjqsb0q0dp          1195547586                4 INDEX                          RANGE SCAN                             44


Plan hash value: 1195547586
---------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                             | Name                | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  |
---------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                      |                     |      1 |        |    33 (100)|      0 |00:00:00.01 |       0 |      0 |
|   1 |  SORT AGGREGATE                       |                     |      1 |      1 |            |      0 |00:00:00.01 |       0 |      0 |
|*  2 |   HASH JOIN                           |                     |      1 |      1 |    33   (4)|      0 |00:00:00.01 |       0 |      0 |
|*  3 |    TABLE ACCESS BY INDEX ROWID BATCHED| G_PIECE             |      1 |      1 |     8   (0)|      0 |00:00:00.01 |       0 |      0 |
|*  4 |     INDEX RANGE SCAN                  | PIECE_TYP_MT43_IDX  |      1 |   4579 |     1   (0)|    243K|00:00:11.28 |    1225 |   1224 |
|   5 |    VIEW                               | VW_NSO_1            |      0 |   8168 |    24   (0)|      0 |00:00:00.01 |       0 |      0 |
|*  6 |     COUNT STOPKEY                     |                     |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|   7 |      COLLECTION ITERATOR PICKLER FETCH| GETLISTMEMODECOMPTE |      0 |   8168 |    24   (0)|      0 |00:00:00.01 |       0 |      0 |
---------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   2 - access("REFPIECE"="COLUMN_VALUE")
   3 - filter("TX15" IS NOT NULL)
   4 - access("TYPPIECE"='MEMO_DECOMPTE')
   6 - filter(ROWNUM<1000000000000)
*/
/********************************OLD Metrics***************************************/

/********************************New SQL*******************************************/
-- First variant:

select MAX(tx15)
  FROM g_piece
 WHERE typpiece = 'MEMO_DECOMPTE'
   AND refpiece in (SELECT /*+ cardinality(5) */
                            column_value
                      FROM TABLE(dfx_lst . GetListMemoDecompte(:B1,
                                                     :B2,
                                                     :B3,
                                                     :B4,
                                                     :B5,
                                                     :B6,
                                                     :B7,
                                                     :B8,
                                                     :B9))
                     WHERE ROWNUM < power(10, 12));


-- Second variant:

select /*+ leading(T) use_nl(gp) */
       MAX(gp.tx15)
  FROM g_piece gp,
       TABLE(dfx_lst . GetListMemoDecompte(:B1,
                                                     :B2,
                                                     :B3,
                                                     :B4,
                                                     :B5,
                                                     :B6,
                                                     :B7,
                                                     :B8,
                                                     :B9)) T
 WHERE gp.typpiece = 'MEMO_DECOMPTE'
   AND gp.refpiece = T.column_value;

/********************************New SQL*******************************************/
/********************************New Metrics***************************************/
/*
-- First variant execution plan:

Plan hash value: 517316018
-------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                              | Name                | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers |
-------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                       |                     |      1 |        |    25 (100)|      1 |00:00:00.01 |       6 |
|   1 |  SORT AGGREGATE                        |                     |      1 |      1 |            |      1 |00:00:00.01 |       6 |
|   2 |   NESTED LOOPS                         |                     |      1 |      1 |    25   (0)|      0 |00:00:00.01 |       6 |
|   3 |    NESTED LOOPS                        |                     |      1 |      5 |    25   (0)|      1 |00:00:00.01 |       3 |
|   4 |     VIEW                               | VW_NSO_1            |      1 |      5 |    24   (0)|      1 |00:00:00.01 |       0 |
|*  5 |      COUNT STOPKEY                     |                     |      1 |        |            |      1 |00:00:00.01 |       0 |
|   6 |       COLLECTION ITERATOR PICKLER FETCH| GETLISTMEMODECOMPTE |      1 |   8168 |    24   (0)|      1 |00:00:00.01 |       0 |
|*  7 |     INDEX RANGE SCAN                   | PIE_REFPIECE        |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |
|*  8 |    TABLE ACCESS BY INDEX ROWID         | G_PIECE             |      1 |      1 |     1   (0)|      0 |00:00:00.01 |       3 |
-------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   5 - filter(ROWNUM<1000000000000)
   7 - access("REFPIECE"="COLUMN_VALUE")
   8 - filter(("TX15" IS NOT NULL AND "TYPPIECE"='MEMO_DECOMPTE'))


-- Second variant execution plan:

Plan hash value: 2362163083
-----------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                            | Name                | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers |
-----------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                     |                     |      1 |        |   269 (100)|      1 |00:00:00.01 |       6 |
|   1 |  SORT AGGREGATE                      |                     |      1 |      1 |            |      1 |00:00:00.01 |       6 |
|   2 |   NESTED LOOPS                       |                     |      1 |      1 |   269   (0)|      0 |00:00:00.01 |       6 |
|   3 |    NESTED LOOPS                      |                     |      1 |   8168 |   269   (0)|      1 |00:00:00.01 |       3 |
|   4 |     COLLECTION ITERATOR PICKLER FETCH| GETLISTMEMODECOMPTE |      1 |   8168 |    24   (0)|      1 |00:00:00.01 |       0 |
|*  5 |     INDEX RANGE SCAN                 | PIE_REFPIECE        |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |
|*  6 |    TABLE ACCESS BY INDEX ROWID       | G_PIECE             |      1 |      1 |     1   (0)|      0 |00:00:00.01 |       3 |
-----------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   5 - access("GP"."REFPIECE"=VALUE(KOKBF$))
   6 - filter(("GP"."TX15" IS NOT NULL AND "GP"."TYPPIECE"='MEMO_DECOMPTE'))

*/
/********************************New Metrics***************************************/

/********************************Index statistics**********************************/

/********************************Other SQLs****************************************/          
/*

*/ 
/********************************Other SQLs****************************************/              
