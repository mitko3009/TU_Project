/********************************************************************************
*********       E-mail subject: RBRODEV-4193
*********             Instance: JUJUVAL
*********          Description: 
Problem:
The rbr_dwh_full.ksh has been working over 6 hours during the NJs on jujuval.

Analysis:
We checked for the period between 21:20 on 23/10/2024 and 04:00 on 24/10/2024 on JUJUVAL for database modules, which starts with EXPORT% and found that the EXPORT_RISK_EXPOSURE module
was responsible for ~90% of the time. We checked which were the TOP SQLs in this module and found that the 3 TOP SQLs, which were responsible summary for ~70% of the time were f488v1c6f2z9p,
b4uyncu1ftcuj and gjzdu6mdb82cx. They are almost the same and have the same problem in them. The heaviest part in their execution plans is when access table NAM_ECR_COMPTA_BAK through
the REFDOSS column, for one decompte it founds 800k rows and after that makes filter in table NAM_ECR_COMPTA_BAK on predicates CODEOPER = 'OFF_BALANCE_FIU' and
LINENUM = '1', which is the heaviest part. This is because there is no appropriate index, which to be used to access table NAM_ECR_COMPTA_BAK through columns REFDOSS and CODEOPER.
In SQLs b4uyncu1ftcuj and gjzdu6mdb82cx it is used index_combine hint to access table NAM_ECR_COMPTA_BAK through index NAMECRDOS_BAK and IDX6_NAM_ECR_COMPTA_BAK, but on JUJUVAL
we have Oracle Standard Edition and the index_combine doesn't work ( it works only on Enterprise edition ), so we will need to add column REFDOSS to index IDX6_NAM_ECR_COMPTA_BAK for RBRO, which
which will allow us to access table NAM_ECR_COMPTA_BAK through columns REFDOSS and CODEOPER. Also, we suspect that the mentioned SQLs f488v1c6f2z9p, b4uyncu1ftcuj and gjzdu6mdb82cx were
executed more times than the expected based on what we saw from the result of the cursor ( SQL 7jvvbqu566ctv ), so please check is it possible to reduce the number of executions ( each query was executed 5800 times ).


Suggestion:
1. Please ask C&D is it possible to add column REFDOSS to index IDX6_NAM_ECR_COMPTA_BAK on table NAM_ECR_COMPTA_BAK for RBRO, 
which will allow the easy access in table NAM_ECR_COMPTA_BAK and will skip the filtering.
2. Please ask B&I to remove the index_combine hint from SQLs b4uyncu1ftcuj and gjzdu6mdb82cx as it is shown in the New SQL section below and to 
check is it expected SQLs f488v1c6f2z9p, b4uyncu1ftcuj and gjzdu6mdb82cx to be executed so many times.

*********               SQL_ID: f488v1c6f2z9p, b4uyncu1ftcuj, gjzdu6mdb82cx
*********      Program/Package: 
*********              Request: Rositsa Nenova 
*********               Author: Dimitar Dimitrov
********* Received e-mail date: 24/10/2024
*********      Resolution date: 29/10/2024
*********  Trace old file here: \\epox\specifs\performance\tmp\
*********  Trace new file here:
***********************************************************************************/

/********************************OLD SQL*******************************************/

-- f488v1c6f2z9p

VAR B1 VARCHAR2(32);
EXEC :B1 := '';
VAR B2 VARCHAR2(32);
EXEC :B2 := '';
VAR B3 VARCHAR2(32);
EXEC :B3 := '1811280021';
var B9 varchar2(32);
exec :B9 := 'INT00000';
exec utl_app_date.cacheAppDate(:B9);


SELECT SUM(CH_TAUX.CONV_ORIG_DEST_TX(TO_NUMBER(TO_CHAR(:B2, 'J')),
                                     ACC.MONTANT *
                                     DECODE(ACC.SENS, 'c', -1, 1),
                                     ACC.DEVISE,
                                     to_date(:B1, 'YYYY-MM-DD'),
                                     'MR')) AS OFF_BALANCE_FIU
  FROM NAM_ECR_COMPTA_BAK ACC, 
       G_DOSSIER DCMP
 WHERE DCMP.REFLOT IN ( SELECT :B3
                          FROM DUAL
                        UNION
                        SELECT REFDOSS
                          FROM G_DOSSIER
                         WHERE REFHIERARCHIE = :B3)
   AND ACC.REFDOSS = DCMP.REFDOSS
   AND ACC.CODEOPER = 'OFF_BALANCE_FIU'
   AND ACC.LINENUM = '1'
   AND NOT EXISTS ( SELECT 1
                      FROM RBR_DWH_RISK_EXPOSURE
                     WHERE DATE_FROM = TRUNC(UTL_APP_DATE.GETAPPDATE)
                       AND CONTRACT_ID = :B3
                       AND EXPOSURE_ID LIKE :B3 || '%'
                       AND FACTORING_DERIVED_PROD = 'CLASSICAL_R' );


-- b4uyncu1ftcuj


VAR B1 VARCHAR2(32);
EXEC :B1 := '';
VAR B2 VARCHAR2(32);
EXEC :B2 := '';
VAR B3 VARCHAR2(32);
EXEC :B3 := '1811280021';
var B9 varchar2(32);
exec :B9 := 'INT00000';
exec utl_app_date.cacheAppDate(:B9);

SELECT /*+ index_combine(ACC NAMECRDOS_BAK IDX6_NAM_ECR_COMPTA_BAK) */
       SUM(CH_TAUX.CONV_ORIG_DEST_TX(TO_NUMBER(TO_CHAR(:B2, 'J')),
                                     ACC.MONTANT * DECODE(ACC.SENS, 'c', -1, 1),
                                     ACC.DEVISE,
                                     :B1,
                                     'MR')) AS OFF_BALANCE_INT
  FROM NAM_ECR_COMPTA_BAK ACC, 
       G_DOSSIER DCMP, 
       G_DOSSIER CNTR
 WHERE CNTR.REFDOSS IN ( SELECT :B3
                           FROM DUAL
                         UNION
                         SELECT REFDOSS
                           FROM G_DOSSIER
                          WHERE REFHIERARCHIE = :B3 )
   AND DCMP.REFLOT = CNTR.REFDOSS
   AND ACC.REFDOSS IN (CNTR.REFDOSS, DCMP.REFDOSS)
   AND ACC.CODEOPER = 'OFF_BALANCE_INT'
   AND ACC.LINENUM = '1'
   AND NOT EXISTS ( SELECT 1
                      FROM RBR_DWH_RISK_EXPOSURE
                     WHERE DATE_FROM = TRUNC(UTL_APP_DATE.GETAPPDATE)
                       AND CONTRACT_ID = :B3
                       AND EXPOSURE_ID LIKE :B3 || '%'
                       AND FACTORING_DERIVED_PROD = 'CLASSICAL_R' );


-- gjzdu6mdb82cx


VAR B1 VARCHAR2(32);
EXEC :B1 := '';
VAR B2 VARCHAR2(32);
EXEC :B2 := '';
VAR B3 VARCHAR2(32);
EXEC :B3 := '1811280021';
var B9 varchar2(32);
exec :B9 := 'INT00000';
exec utl_app_date.cacheAppDate(:B9);

SELECT /*+ index_combine(ACC NAMECRDOS_BAK IDX6_NAM_ECR_COMPTA_BAK) */
       SUM(CH_TAUX.CONV_ORIG_DEST_TX(TO_NUMBER(TO_CHAR(:B2, 'J')),
                                     ACC.MONTANT * DECODE(ACC.SENS, 'c', -1, 1),
                                     ACC.DEVISE,
                                     :B1,
                                     'MR')) AS WRITE_OFF_FEES
  FROM NAM_ECR_COMPTA_BAK ACC, 
       G_DOSSIER DCMP, 
       G_DOSSIER CNTR
 WHERE CNTR.REFDOSS IN ( SELECT :B3
                           FROM DUAL
                         UNION
                         SELECT REFDOSS
                           FROM G_DOSSIER
                          WHERE REFHIERARCHIE = :B3 )
   AND DCMP.REFLOT = CNTR.REFDOSS
   AND ACC.REFDOSS IN (CNTR.REFDOSS, DCMP.REFDOSS)
   AND ACC.CODEOPER = 'WRITE_OFF_AFEE'
   AND ACC.LINENUM = '1'
   AND NOT EXISTS ( SELECT 1
                      FROM RBR_DWH_RISK_EXPOSURE
                     WHERE DATE_FROM = TRUNC(UTL_APP_DATE.GETAPPDATE)
                       AND CONTRACT_ID = :B3
                       AND EXPOSURE_ID LIKE :B3 || '%'
                       AND FACTORING_DERIVED_PROD = 'CLASSICAL_R' );

/********************************OLD SQL*******************************************/
/********************************OLD Metrics***************************************/
/*
MODULE                           PROGRAM                                            CLIENT_ID       SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- -------------------------------------------------- --------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
EXPORT_RISK_EXPOSURE             sqlplus                                            unknown                                         404      26936 db file parallel rea 2024/10/23 21:57:57  2024/10/24 03:56:10        961                  9579 +000000000 05:58:13.759 20%
EXPORT_RISK_EXPOSURE             sqlplus                                            unknown                                         404      26936 db file sequential r 2024/10/23 21:58:07  2024/10/24 03:55:29        729                244964 +000000000 05:57:22.560 15%
                                                                                                    0gwc9vhhygvbb          0                       ON CPU               2024/10/23 21:00:05  2024/10/24 03:59:56        706                     1 +000000000 06:59:50.464 15%
DBMS_SCHEDULER                                                                                                                                     db file sequential r 2024/10/23 22:00:10  2024/10/24 03:00:12        364                247017 +000000000 05:00:01.921 8%
EXPORT_RISK_EXPOSURE             sqlplus                                            unknown                                         404      26936 ON CPU               2024/10/23 21:59:29  2024/10/24 03:56:21        254                495721 +000000000 05:56:51.839 5%
EXPORT_RISK_EXPOSURE             sqlplus                                            unknown         7jvvbqu566ctv  608508530        404      26936 direct path read     2024/10/23 21:57:26  2024/10/23 22:24:14        155                     1 +000000000 00:26:47.680 3%
DBMS_SCHEDULER                                                                                                                                     db file scattered re 2024/10/23 22:00:30  2024/10/23 22:54:57        130                     8 +000000000 00:54:26.560 3%


MODULE                           PROGRAM                                            CLIENT_ID       SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- -------------------------------------------------- --------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
EXPORT_RISK_EXPOSURE             sqlplus                                            unknown                                         404      26936                      2024/10/23 21:57:26  2024/10/24 03:56:21       2104                495721 +000000000 05:58:54.720 91%
EXPORT_LIMITS                    sqlplus                                            unknown                                         404      26936                      2024/10/23 21:20:55  2024/10/23 21:34:54         83                 35406 +000000000 00:13:59.681 4%
EXPORT_INVOICES                  sqlplus                                            unknown                                         404      26936                      2024/10/23 21:43:06  2024/10/23 21:55:33         74                242202 +000000000 00:12:27.522 3%
EXPORT_CONTRACTS                 sqlplus                                            unknown                                         404      26936                      2024/10/23 21:35:04  2024/10/23 21:40:01         30                224600 +000000000 00:04:56.960 1%


MODULE                           PROGRAM                                            CLIENT_ID       SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- -------------------------------------------------- --------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
EXPORT_RISK_EXPOSURE             sqlplus                                            unknown                                         404      26936                      2024/10/23 21:57:26  2024/10/24 03:56:21       2104                495721 +000000000 05:58:54.720 100%


MODULE                           PROGRAM                                            CLIENT_ID       SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- -------------------------------------------------- --------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
EXPORT_RISK_EXPOSURE             sqlplus                                            unknown                                         404      26936 db file parallel rea 2024/10/23 21:57:57  2024/10/24 03:56:10        961                  9579 +000000000 05:58:13.759 46%
EXPORT_RISK_EXPOSURE             sqlplus                                            unknown                                         404      26936 db file sequential r 2024/10/23 21:58:07  2024/10/24 03:55:29        729                244964 +000000000 05:57:22.560 35%
EXPORT_RISK_EXPOSURE             sqlplus                                            unknown                                         404      26936 ON CPU               2024/10/23 21:59:29  2024/10/24 03:56:21        254                495721 +000000000 05:56:51.839 12%
EXPORT_RISK_EXPOSURE             sqlplus                                            unknown         7jvvbqu566ctv  608508530        404      26936 direct path read     2024/10/23 21:57:26  2024/10/23 22:24:14        155                     1 +000000000 00:26:47.680 7%
EXPORT_RISK_EXPOSURE             sqlplus                                            unknown                                         404      26936 db file scattered re 2024/10/23 22:27:28  2024/10/24 03:38:56          5                  5808 +000000000 05:11:28.000 0%


MODULE                           PROGRAM                                            CLIENT_ID       SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- -------------------------------------------------- --------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
EXPORT_RISK_EXPOSURE             sqlplus                                            unknown         f488v1c6f2z9p 3391415704        404      26936                      2024/10/23 22:30:02  2024/10/24 03:52:35        546                  5794 +000000000 05:22:33.599 26%
EXPORT_RISK_EXPOSURE             sqlplus                                            unknown         b4uyncu1ftcuj 2604568021        404      26936                      2024/10/23 22:38:03  2024/10/24 03:53:37        475                  5794 +000000000 05:15:33.760 23%
EXPORT_RISK_EXPOSURE             sqlplus                                            unknown         gjzdu6mdb82cx 2604568021        404      26936                      2024/10/23 22:43:00  2024/10/24 03:54:48        472                  5794 +000000000 05:11:48.481 22%
EXPORT_RISK_EXPOSURE             sqlplus                                            unknown         7jvvbqu566ctv  608508530        404      26936                      2024/10/23 21:57:26  2024/10/23 22:24:14        158                     1 +000000000 00:26:47.680 8%
EXPORT_RISK_EXPOSURE             sqlplus                                            unknown         06gp1pv9xfa9r 2945860215        404      26936                      2024/10/23 22:24:24  2024/10/24 03:55:40         78                 10090 +000000000 05:31:15.840 4%


INSTANCE_NUMBER SQL_ID            ELAPSED MAX_WAIT_ON     PC_OF  WAIT_TIME            GETS      READS       ROWS  ELAP/EXEC       GETS/EXEC READS/EXEC  ROWS/EXEC       EXEC PLAN_HASH_VALUE
--------------- ------------- ----------- --------------- ----- ---------- --------------- ---------- ---------- ---------- --------------- ---------- ---------- ---------- ---------------
              1 b4uyncu1ftcuj        4870 IO              96%   4935.58442        11436129    2865761       5864        .83            1950      488.7          1       5864      2604568021
              1 f488v1c6f2z9p        5658 IO              97%   5724.17952        10865421    2966814       5863        .97            1853     506.02          1       5863      3391415704
              1 gjzdu6mdb82cx        4832 IO              96%   4898.02974        11434214    2864608       5864        .82            1950     488.51          1       5864      2604568021




SQL_ID        SQL_PLAN_HASH_VALUE SQL_PLAN_LINE_ID SQL_PLAN_OPERATION             SQL_PLAN_OPTIONS                   ACTIVE
------------- ------------------- ---------------- ------------------------------ ------------------------------ ----------
gjzdu6mdb82cx          2604568021               33 TABLE ACCESS                   BY INDEX ROWID                        426
gjzdu6mdb82cx          2604568021               32 INDEX                          RANGE SCAN                             43
gjzdu6mdb82cx          2604568021               19 INDEX                          SKIP SCAN                               2
gjzdu6mdb82cx          2604568021                  SELECT STATEMENT                                                       1

SQL_ID        SQL_PLAN_HASH_VALUE SQL_PLAN_LINE_ID SQL_PLAN_OPERATION             SQL_PLAN_OPTIONS                   ACTIVE
------------- ------------------- ---------------- ------------------------------ ------------------------------ ----------
b4uyncu1ftcuj          2604568021               33 TABLE ACCESS                   BY INDEX ROWID                        432
b4uyncu1ftcuj          2604568021               32 INDEX                          RANGE SCAN                             40
b4uyncu1ftcuj          2604568021               34 TABLE ACCESS                   BY INDEX ROWID BATCHED                  1
b4uyncu1ftcuj          2604568021               17 TABLE ACCESS                   BY INDEX ROWID                          1
b4uyncu1ftcuj          2604568021               19 INDEX                          SKIP SCAN                               1

SQL_ID        SQL_PLAN_HASH_VALUE SQL_PLAN_LINE_ID SQL_PLAN_OPERATION             SQL_PLAN_OPTIONS                   ACTIVE
------------- ------------------- ---------------- ------------------------------ ------------------------------ ----------
f488v1c6f2z9p          3391415704               13 TABLE ACCESS                   BY INDEX ROWID                        501
f488v1c6f2z9p          3391415704               12 INDEX                          RANGE SCAN                             44
f488v1c6f2z9p          3391415704                3 NESTED LOOPS                                                           1



-- f488v1c6f2z9p

Plan hash value: 3391415704
---------------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                             | Name                      | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  |
---------------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                      |                           |      1 |        |   215 (100)|      1 |00:06:04.76 |     376K|  96361 |
|   1 |  SORT AGGREGATE                       |                           |      1 |      1 |            |      1 |00:06:04.76 |     376K|  96361 |
|*  2 |   FILTER                              |                           |      1 |        |            |      0 |00:06:04.76 |     376K|  96361 |
|   3 |    NESTED LOOPS                       |                           |      1 |    155 |   214   (1)|      0 |00:06:04.76 |     376K|  96361 |
|   4 |     NESTED LOOPS                      |                           |      1 |  43192 |   214   (1)|    800K|00:00:27.03 |    4746 |   4588 |
|   5 |      NESTED LOOPS                     |                           |      1 |      4 |     6  (34)|      1 |00:00:00.01 |       4 |      0 |
|   6 |       VIEW                            | VW_NSO_1                  |      1 |      3 |     5  (40)|      1 |00:00:00.01 |       2 |      0 |
|   7 |        SORT UNIQUE                    |                           |      1 |      3 |     5  (40)|      1 |00:00:00.01 |       2 |      0 |
|   8 |         UNION-ALL                     |                           |      1 |        |            |      1 |00:00:00.01 |       2 |      0 |
|   9 |          FAST DUAL                    |                           |      1 |      1 |     2   (0)|      1 |00:00:00.01 |       0 |      0 |
|* 10 |          INDEX RANGE SCAN             | REFHIERARCHIE_IDX         |      1 |      2 |     1   (0)|      0 |00:00:00.01 |       2 |      0 |
|* 11 |       INDEX RANGE SCAN                | G_DOSSIER_RL_CD_RD_RF_IDX |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       2 |      0 |
|* 12 |      INDEX RANGE SCAN                 | NAMECRDOS_BAK             |      1 |  10798 |     1   (0)|    800K|00:00:26.92 |    4742 |   4588 |
|* 13 |     TABLE ACCESS BY INDEX ROWID       | NAM_ECR_COMPTA_BAK        |    800K|     35 |    52   (0)|      0 |00:05:37.48 |     371K|  91773 |
|* 14 |    TABLE ACCESS BY INDEX ROWID BATCHED| DWH_RISK_EXPOSURE         |      1 |      1 |     1   (0)|      0 |00:00:00.01 |       3 |      0 |
|* 15 |     INDEX SKIP SCAN                   | PK_DWH_RISK_EXPOSURE      |      1 |      5 |     1   (0)|      0 |00:00:00.01 |       3 |      0 |
---------------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   2 - filter( IS NULL)
  10 - access("REFHIERARCHIE"=:B3)
  11 - access("DCMP"."REFLOT"=":B3")
       filter("DCMP"."REFLOT" IS NOT NULL)
  12 - access("ACC"."REFDOSS"="DCMP"."REFDOSS")
  13 - filter(("ACC"."CODEOPER"='OFF_BALANCE_FIU' AND "ACC"."LINENUM"=1))
  14 - filter(("CONTRACT_ID"=:B3 AND "FACTORING_DERIVED_PROD"='CLASSICAL_R'))
  15 - access("EXPOSURE_ID" LIKE :B3||'%' AND "DATE_FROM"=TRUNC("UTL_APP_DATE"."GETAPPDATE"()))
       filter(("EXPOSURE_ID" LIKE :B3||'%' AND "DATE_FROM"=TRUNC("UTL_APP_DATE"."GETAPPDATE"())))



-- b4uyncu1ftcuj

Plan hash value: 2604568021
-----------------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                               | Name                      | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  |
-----------------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                        |                           |      1 |        |   120 (100)|      0 |00:00:00.01 |       3 |      0 |
|   1 |  SORT AGGREGATE                         |                           |      1 |      1 |            |      0 |00:00:00.01 |       3 |      0 |
|   2 |   VIEW                                  | VW_ORE_0F490904           |      1 |    122 |   120   (4)|      0 |00:00:00.01 |       3 |      0 |
|   3 |    UNION-ALL                            |                           |      1 |        |            |      0 |00:00:00.01 |       3 |      0 |
|*  4 |     FILTER                              |                           |      1 |        |            |      0 |00:00:00.01 |      14 |      0 |
|   5 |      NESTED LOOPS                       |                           |      1 |     76 |    59   (4)|      0 |00:00:00.01 |      11 |      0 |
|   6 |       NESTED LOOPS                      |                           |      1 |  10798 |    59   (4)|      0 |00:00:00.01 |      11 |      0 |
|   7 |        NESTED LOOPS                     |                           |      1 |      1 |     7  (29)|      1 |00:00:00.01 |       6 |      0 |
|   8 |         NESTED LOOPS                    |                           |      1 |      3 |     6  (34)|      1 |00:00:00.01 |       4 |      0 |
|   9 |          VIEW                           | VW_NSO_1                  |      1 |      3 |     5  (40)|      1 |00:00:00.01 |       2 |      0 |
|  10 |           SORT UNIQUE                   |                           |      1 |      3 |     5  (40)|      1 |00:00:00.01 |       2 |      0 |
|  11 |            UNION-ALL                    |                           |      1 |        |            |      1 |00:00:00.01 |       2 |      0 |
|  12 |             FAST DUAL                   |                           |      1 |      1 |     2   (0)|      1 |00:00:00.01 |       0 |      0 |
|* 13 |             INDEX RANGE SCAN            | REFHIERARCHIE_IDX         |      1 |      2 |     1   (0)|      0 |00:00:00.01 |       2 |      0 |
|* 14 |          INDEX UNIQUE SCAN              | DOS_REFDOSS               |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       2 |      0 |
|* 15 |         INDEX RANGE SCAN                | DOSS_LOT                  |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       2 |      0 |
|* 16 |        INDEX RANGE SCAN                 | NAMECRDOS_BAK             |      1 |  10798 |     1   (0)|      0 |00:00:00.01 |       5 |      0 |
|* 17 |       TABLE ACCESS BY INDEX ROWID       | NAM_ECR_COMPTA_BAK        |      0 |     57 |    52   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 18 |      TABLE ACCESS BY INDEX ROWID BATCHED| DWH_RISK_EXPOSURE         |      1 |      1 |     1   (0)|      0 |00:00:00.01 |       3 |      0 |
|* 19 |       INDEX SKIP SCAN                   | PK_DWH_RISK_EXPOSURE      |      1 |      5 |     1   (0)|      0 |00:00:00.01 |       3 |      0 |
|* 20 |     FILTER                              |                           |      1 |        |            |      0 |00:00:00.01 |       3 |      0 |
|  21 |      NESTED LOOPS                       |                           |      1 |     46 |    59   (4)|      0 |00:00:00.01 |       0 |      0 |
|  22 |       NESTED LOOPS                      |                           |      1 |  10798 |    59   (4)|  23671 |00:00:00.47 |     143 |    132 |
|  23 |        NESTED LOOPS                     |                           |      1 |      1 |     7  (29)|      1 |00:00:00.01 |       6 |      0 |
|  24 |         NESTED LOOPS                    |                           |      1 |      3 |     6  (34)|      1 |00:00:00.01 |       4 |      0 |
|  25 |          VIEW                           | VW_NSO_1                  |      1 |      3 |     5  (40)|      1 |00:00:00.01 |       2 |      0 |
|  26 |           SORT UNIQUE                   |                           |      1 |      3 |     5  (40)|      1 |00:00:00.01 |       2 |      0 |
|  27 |            UNION-ALL                    |                           |      1 |        |            |      1 |00:00:00.01 |       2 |      0 |
|  28 |             FAST DUAL                   |                           |      1 |      1 |     2   (0)|      1 |00:00:00.01 |       0 |      0 |
|* 29 |             INDEX RANGE SCAN            | REFHIERARCHIE_IDX         |      1 |      2 |     1   (0)|      0 |00:00:00.01 |       2 |      0 |
|* 30 |          INDEX UNIQUE SCAN              | DOS_REFDOSS               |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       2 |      0 |
|* 31 |         INDEX RANGE SCAN                | G_DOSSIER_RL_CD_RD_RF_IDX |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       2 |      0 |
|* 32 |        INDEX RANGE SCAN                 | NAMECRDOS_BAK             |      1 |  10798 |     1   (0)|  23671 |00:00:00.47 |     137 |    132 |
|* 33 |       TABLE ACCESS BY INDEX ROWID       | NAM_ECR_COMPTA_BAK        |  23671 |     35 |    52   (0)|      0 |00:00:12.18 |    5435 |   3208 |
|* 34 |      TABLE ACCESS BY INDEX ROWID BATCHED| DWH_RISK_EXPOSURE         |      1 |      1 |     1   (0)|      0 |00:00:00.01 |       3 |      0 |
|* 35 |       INDEX SKIP SCAN                   | PK_DWH_RISK_EXPOSURE      |      1 |      5 |     1   (0)|      0 |00:00:00.01 |       3 |      0 |
-----------------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   4 - filter( IS NULL)
  13 - access("REFHIERARCHIE"=:B3)
  14 - access("CNTR"."REFDOSS"=":B3")
  15 - access("DCMP"."REFLOT"="CNTR"."REFDOSS")
       filter("DCMP"."REFLOT" IS NOT NULL)
  16 - access("ACC"."REFDOSS"="CNTR"."REFDOSS")
  17 - filter(("ACC"."CODEOPER"='OFF_BALANCE_INT' AND "ACC"."LINENUM"=1))
  18 - filter(("CONTRACT_ID"=:B3 AND "FACTORING_DERIVED_PROD"='CLASSICAL_R'))
  19 - access("EXPOSURE_ID" LIKE :B3||'%' AND "DATE_FROM"=TRUNC("UTL_APP_DATE"."GETAPPDATE"()))
       filter(("EXPOSURE_ID" LIKE :B3||'%' AND "DATE_FROM"=TRUNC("UTL_APP_DATE"."GETAPPDATE"())))
  20 - filter( IS NULL)
  29 - access("REFHIERARCHIE"=:B3)
  30 - access("CNTR"."REFDOSS"=":B3")
  31 - access("DCMP"."REFLOT"="CNTR"."REFDOSS")
       filter("DCMP"."REFLOT" IS NOT NULL)
  32 - access("ACC"."REFDOSS"="DCMP"."REFDOSS")
       filter(LNNVL("ACC"."REFDOSS"="CNTR"."REFDOSS"))
  33 - filter(("ACC"."CODEOPER"='OFF_BALANCE_INT' AND "ACC"."LINENUM"=1))
  34 - filter(("CONTRACT_ID"=:B3 AND "FACTORING_DERIVED_PROD"='CLASSICAL_R'))
  35 - access("EXPOSURE_ID" LIKE :B3||'%' AND "DATE_FROM"=TRUNC("UTL_APP_DATE"."GETAPPDATE"()))
       filter(("EXPOSURE_ID" LIKE :B3||'%' AND "DATE_FROM"=TRUNC("UTL_APP_DATE"."GETAPPDATE"())))


-- gjzdu6mdb82cx

Plan hash value: 2604568021
-----------------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                               | Name                      | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  |
-----------------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                        |                           |      1 |        |   120 (100)|      0 |00:00:00.01 |       3 |      0 |
|   1 |  SORT AGGREGATE                         |                           |      1 |      1 |            |      0 |00:00:00.01 |       3 |      0 |
|   2 |   VIEW                                  | VW_ORE_0F490904           |      1 |    122 |   120   (4)|      0 |00:00:00.01 |       3 |      0 |
|   3 |    UNION-ALL                            |                           |      1 |        |            |      0 |00:00:00.01 |       3 |      0 |
|*  4 |     FILTER                              |                           |      1 |        |            |      0 |00:00:00.01 |      14 |      0 |
|   5 |      NESTED LOOPS                       |                           |      1 |     76 |    59   (4)|      0 |00:00:00.01 |      11 |      0 |
|   6 |       NESTED LOOPS                      |                           |      1 |  10798 |    59   (4)|      0 |00:00:00.01 |      11 |      0 |
|   7 |        NESTED LOOPS                     |                           |      1 |      1 |     7  (29)|      1 |00:00:00.01 |       6 |      0 |
|   8 |         NESTED LOOPS                    |                           |      1 |      3 |     6  (34)|      1 |00:00:00.01 |       4 |      0 |
|   9 |          VIEW                           | VW_NSO_1                  |      1 |      3 |     5  (40)|      1 |00:00:00.01 |       2 |      0 |
|  10 |           SORT UNIQUE                   |                           |      1 |      3 |     5  (40)|      1 |00:00:00.01 |       2 |      0 |
|  11 |            UNION-ALL                    |                           |      1 |        |            |      1 |00:00:00.01 |       2 |      0 |
|  12 |             FAST DUAL                   |                           |      1 |      1 |     2   (0)|      1 |00:00:00.01 |       0 |      0 |
|* 13 |             INDEX RANGE SCAN            | REFHIERARCHIE_IDX         |      1 |      2 |     1   (0)|      0 |00:00:00.01 |       2 |      0 |
|* 14 |          INDEX UNIQUE SCAN              | DOS_REFDOSS               |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       2 |      0 |
|* 15 |         INDEX RANGE SCAN                | DOSS_LOT                  |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       2 |      0 |
|* 16 |        INDEX RANGE SCAN                 | NAMECRDOS_BAK             |      1 |  10798 |     1   (0)|      0 |00:00:00.01 |       5 |      0 |
|* 17 |       TABLE ACCESS BY INDEX ROWID       | NAM_ECR_COMPTA_BAK        |      0 |     57 |    52   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 18 |      TABLE ACCESS BY INDEX ROWID BATCHED| DWH_RISK_EXPOSURE         |      1 |      1 |     1   (0)|      0 |00:00:00.01 |       3 |      0 |
|* 19 |       INDEX SKIP SCAN                   | PK_DWH_RISK_EXPOSURE      |      1 |      5 |     1   (0)|      0 |00:00:00.01 |       3 |      0 |
|* 20 |     FILTER                              |                           |      1 |        |            |      0 |00:00:00.01 |       3 |      0 |
|  21 |      NESTED LOOPS                       |                           |      1 |     46 |    59   (4)|      0 |00:00:00.01 |       0 |      0 |
|  22 |       NESTED LOOPS                      |                           |      1 |  10798 |    59   (4)|  23671 |00:00:00.47 |     143 |    132 |
|  23 |        NESTED LOOPS                     |                           |      1 |      1 |     7  (29)|      1 |00:00:00.01 |       6 |      0 |
|  24 |         NESTED LOOPS                    |                           |      1 |      3 |     6  (34)|      1 |00:00:00.01 |       4 |      0 |
|  25 |          VIEW                           | VW_NSO_1                  |      1 |      3 |     5  (40)|      1 |00:00:00.01 |       2 |      0 |
|  26 |           SORT UNIQUE                   |                           |      1 |      3 |     5  (40)|      1 |00:00:00.01 |       2 |      0 |
|  27 |            UNION-ALL                    |                           |      1 |        |            |      1 |00:00:00.01 |       2 |      0 |
|  28 |             FAST DUAL                   |                           |      1 |      1 |     2   (0)|      1 |00:00:00.01 |       0 |      0 |
|* 29 |             INDEX RANGE SCAN            | REFHIERARCHIE_IDX         |      1 |      2 |     1   (0)|      0 |00:00:00.01 |       2 |      0 |
|* 30 |          INDEX UNIQUE SCAN              | DOS_REFDOSS               |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       2 |      0 |
|* 31 |         INDEX RANGE SCAN                | G_DOSSIER_RL_CD_RD_RF_IDX |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       2 |      0 |
|* 32 |        INDEX RANGE SCAN                 | NAMECRDOS_BAK             |      1 |  10798 |     1   (0)|  23671 |00:00:00.47 |     137 |    132 |
|* 33 |       TABLE ACCESS BY INDEX ROWID       | NAM_ECR_COMPTA_BAK        |  23671 |     35 |    52   (0)|      0 |00:00:12.18 |    5435 |   3208 |
|* 34 |      TABLE ACCESS BY INDEX ROWID BATCHED| DWH_RISK_EXPOSURE         |      1 |      1 |     1   (0)|      0 |00:00:00.01 |       3 |      0 |
|* 35 |       INDEX SKIP SCAN                   | PK_DWH_RISK_EXPOSURE      |      1 |      5 |     1   (0)|      0 |00:00:00.01 |       3 |      0 |
-----------------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   4 - filter( IS NULL)
  13 - access("REFHIERARCHIE"=:B3)
  14 - access("CNTR"."REFDOSS"=":B3")
  15 - access("DCMP"."REFLOT"="CNTR"."REFDOSS")
       filter("DCMP"."REFLOT" IS NOT NULL)
  16 - access("ACC"."REFDOSS"="CNTR"."REFDOSS")
  17 - filter(("ACC"."CODEOPER"='OFF_BALANCE_INT' AND "ACC"."LINENUM"=1))
  18 - filter(("CONTRACT_ID"=:B3 AND "FACTORING_DERIVED_PROD"='CLASSICAL_R'))
  19 - access("EXPOSURE_ID" LIKE :B3||'%' AND "DATE_FROM"=TRUNC("UTL_APP_DATE"."GETAPPDATE"()))
       filter(("EXPOSURE_ID" LIKE :B3||'%' AND "DATE_FROM"=TRUNC("UTL_APP_DATE"."GETAPPDATE"())))
  20 - filter( IS NULL)
  29 - access("REFHIERARCHIE"=:B3)
  30 - access("CNTR"."REFDOSS"=":B3")
  31 - access("DCMP"."REFLOT"="CNTR"."REFDOSS")
       filter("DCMP"."REFLOT" IS NOT NULL)
  32 - access("ACC"."REFDOSS"="DCMP"."REFDOSS")
       filter(LNNVL("ACC"."REFDOSS"="CNTR"."REFDOSS"))
  33 - filter(("ACC"."CODEOPER"='OFF_BALANCE_INT' AND "ACC"."LINENUM"=1))
  34 - filter(("CONTRACT_ID"=:B3 AND "FACTORING_DERIVED_PROD"='CLASSICAL_R'))
  35 - access("EXPOSURE_ID" LIKE :B3||'%' AND "DATE_FROM"=TRUNC("UTL_APP_DATE"."GETAPPDATE"()))
       filter(("EXPOSURE_ID" LIKE :B3||'%' AND "DATE_FROM"=TRUNC("UTL_APP_DATE"."GETAPPDATE"())))
*/
/********************************OLD Metrics***************************************/

/********************************New SQL*******************************************/

-- f488v1c6f2z9p

No change in the SQL text.

-- b4uyncu1ftcuj

SELECT SUM(CH_TAUX.CONV_ORIG_DEST_TX(TO_NUMBER(TO_CHAR(:B2, 'J')),
                                     ACC.MONTANT * DECODE(ACC.SENS, 'c', -1, 1),
                                     ACC.DEVISE,
                                     :B1,
                                     'MR')) AS OFF_BALANCE_INT
  FROM NAM_ECR_COMPTA_BAK ACC, 
       G_DOSSIER DCMP, 
       G_DOSSIER CNTR
 WHERE CNTR.REFDOSS IN ( SELECT :B3
                           FROM DUAL
                         UNION
                         SELECT REFDOSS
                           FROM G_DOSSIER
                          WHERE REFHIERARCHIE = :B3 )
   AND DCMP.REFLOT = CNTR.REFDOSS
   AND ACC.REFDOSS IN (CNTR.REFDOSS, DCMP.REFDOSS)
   AND ACC.CODEOPER = 'OFF_BALANCE_INT'
   AND ACC.LINENUM = '1'
   AND NOT EXISTS ( SELECT 1
                      FROM RBR_DWH_RISK_EXPOSURE
                     WHERE DATE_FROM = TRUNC(UTL_APP_DATE.GETAPPDATE)
                       AND CONTRACT_ID = :B3
                       AND EXPOSURE_ID LIKE :B3 || '%'
                       AND FACTORING_DERIVED_PROD = 'CLASSICAL_R' );


-- gjzdu6mdb82cx

SELECT SUM(CH_TAUX.CONV_ORIG_DEST_TX(TO_NUMBER(TO_CHAR(:B2, 'J')),
                                     ACC.MONTANT * DECODE(ACC.SENS, 'c', -1, 1),
                                     ACC.DEVISE,
                                     :B1,
                                     'MR')) AS WRITE_OFF_FEES
  FROM NAM_ECR_COMPTA_BAK ACC, 
       G_DOSSIER DCMP, 
       G_DOSSIER CNTR
 WHERE CNTR.REFDOSS IN ( SELECT :B3
                           FROM DUAL
                         UNION
                         SELECT REFDOSS
                           FROM G_DOSSIER
                          WHERE REFHIERARCHIE = :B3 )
   AND DCMP.REFLOT = CNTR.REFDOSS
   AND ACC.REFDOSS IN (CNTR.REFDOSS, DCMP.REFDOSS)
   AND ACC.CODEOPER = 'WRITE_OFF_AFEE'
   AND ACC.LINENUM = '1'
   AND NOT EXISTS ( SELECT 1
                      FROM RBR_DWH_RISK_EXPOSURE
                     WHERE DATE_FROM = TRUNC(UTL_APP_DATE.GETAPPDATE)
                       AND CONTRACT_ID = :B3
                       AND EXPOSURE_ID LIKE :B3 || '%'
                       AND FACTORING_DERIVED_PROD = 'CLASSICAL_R' );

/********************************New SQL*******************************************/
/********************************New Metrics***************************************/
/*

-- f488v1c6f2z9p
-- With index on NAM_ECR_COMPTA_BAK(CODEOPER, EL2, REFDOSS)

Plan hash value: 3942926563
---------------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                             | Name                      | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  |
---------------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                      |                           |      1 |        |    90 (100)|      1 |00:00:00.04 |      13 |      4 |
|   1 |  SORT AGGREGATE                       |                           |      1 |      1 |            |      1 |00:00:00.04 |      13 |      4 |
|*  2 |   FILTER                              |                           |      1 |        |            |      0 |00:00:00.04 |      13 |      4 |
|   3 |    NESTED LOOPS                       |                           |      1 |    155 |    89   (4)|      0 |00:00:00.01 |       9 |      0 |
|   4 |     NESTED LOOPS                      |                           |      1 |  16544 |    89   (4)|      0 |00:00:00.01 |       9 |      0 |
|   5 |      NESTED LOOPS                     |                           |      1 |      4 |     6  (34)|      1 |00:00:00.01 |       4 |      0 |
|   6 |       VIEW                            | VW_NSO_1                  |      1 |      3 |     5  (40)|      1 |00:00:00.01 |       2 |      0 |
|   7 |        SORT UNIQUE                    |                           |      1 |      3 |     5  (40)|      1 |00:00:00.01 |       2 |      0 |
|   8 |         UNION-ALL                     |                           |      1 |        |            |      1 |00:00:00.01 |       2 |      0 |
|   9 |          FAST DUAL                    |                           |      1 |      1 |     2   (0)|      1 |00:00:00.01 |       0 |      0 |
|* 10 |          INDEX RANGE SCAN             | REFHIERARCHIE_IDX         |      1 |      2 |     1   (0)|      0 |00:00:00.01 |       2 |      0 |
|* 11 |       INDEX RANGE SCAN                | G_DOSSIER_RL_CD_RD_RF_IDX |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       2 |      0 |
|* 12 |      INDEX RANGE SCAN                 | TEST_DD_INDEX             |      1 |   4136 |    14   (0)|      0 |00:00:00.01 |       5 |      0 |
|* 13 |     TABLE ACCESS BY INDEX ROWID       | NAM_ECR_COMPTA_BAK        |      0 |     35 |    21   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 14 |    TABLE ACCESS BY INDEX ROWID BATCHED| DWH_RISK_EXPOSURE         |      1 |      1 |     1   (0)|      0 |00:00:00.04 |       4 |      4 |
|* 15 |     INDEX SKIP SCAN                   | PK_DWH_RISK_EXPOSURE      |      1 |      4 |     1   (0)|     11 |00:00:00.03 |       3 |      3 |
---------------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   2 - filter( IS NULL)
  10 - access("REFHIERARCHIE"=:B3)
  11 - access("DCMP"."REFLOT"=":B3")
       filter("DCMP"."REFLOT" IS NOT NULL)
  12 - access("ACC"."CODEOPER"='OFF_BALANCE_FIU' AND "ACC"."REFDOSS"="DCMP"."REFDOSS")
       filter("ACC"."REFDOSS"="DCMP"."REFDOSS")
  13 - filter("ACC"."LINENUM"=1)
  14 - filter(("CONTRACT_ID"=:B3 AND "FACTORING_DERIVED_PROD"='CLASSICAL_R'))
  15 - access("EXPOSURE_ID" LIKE :B3||'%' AND "DATE_FROM"=TRUNC("UTL_APP_DATE"."GETAPPDATE"()))
       filter(("EXPOSURE_ID" LIKE :B3||'%' AND "DATE_FROM"=TRUNC("UTL_APP_DATE"."GETAPPDATE"())))


-- b4uyncu1ftcuj
-- With index on NAM_ECR_COMPTA_BAK(CODEOPER, EL2, REFDOSS)

Plan hash value: 2651253612
------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                             | Name                      | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers |
------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                      |                           |      1 |        |    22 (100)|      1 |00:00:00.01 |      13 |
|   1 |  SORT AGGREGATE                       |                           |      1 |      1 |            |      1 |00:00:00.01 |      13 |
|*  2 |   FILTER                              |                           |      1 |        |            |      0 |00:00:00.01 |      13 |
|   3 |    NESTED LOOPS                       |                           |      1 |    122 |    21  (10)|      0 |00:00:00.01 |      10 |
|   4 |     NESTED LOOPS                      |                           |      1 |    370 |    21  (10)|      0 |00:00:00.01 |      10 |
|   5 |      NESTED LOOPS                     |                           |      1 |      1 |     7  (29)|      1 |00:00:00.01 |       6 |
|   6 |       NESTED LOOPS                    |                           |      1 |      3 |     6  (34)|      1 |00:00:00.01 |       4 |
|   7 |        VIEW                           | VW_NSO_1                  |      1 |      3 |     5  (40)|      1 |00:00:00.01 |       2 |
|   8 |         SORT UNIQUE                   |                           |      1 |      3 |     5  (40)|      1 |00:00:00.01 |       2 |
|   9 |          UNION-ALL                    |                           |      1 |        |            |      1 |00:00:00.01 |       2 |
|  10 |           FAST DUAL                   |                           |      1 |      1 |     2   (0)|      1 |00:00:00.01 |       0 |
|* 11 |           INDEX RANGE SCAN            | REFHIERARCHIE_IDX         |      1 |      2 |     1   (0)|      0 |00:00:00.01 |       2 |
|* 12 |        INDEX UNIQUE SCAN              | DOS_REFDOSS               |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       2 |
|* 13 |       INDEX RANGE SCAN                | G_DOSSIER_RL_CD_RD_RF_IDX |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       2 |
|* 14 |      INDEX RANGE SCAN                 | TEST_DD_INDEX             |      1 |    370 |    14   (0)|      0 |00:00:00.01 |       4 |
|* 15 |     TABLE ACCESS BY INDEX ROWID       | NAM_ECR_COMPTA_BAK        |      0 |     92 |    14   (0)|      0 |00:00:00.01 |       0 |
|* 16 |    TABLE ACCESS BY INDEX ROWID BATCHED| DWH_RISK_EXPOSURE         |      1 |      1 |     1   (0)|      0 |00:00:00.01 |       3 |
|* 17 |     INDEX SKIP SCAN                   | PK_DWH_RISK_EXPOSURE      |      1 |     13 |     1   (0)|      0 |00:00:00.01 |       3 |
------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   2 - filter( IS NULL)
  11 - access("REFHIERARCHIE"=:B3)
  12 - access("CNTR"."REFDOSS"=":B3")
  13 - access("DCMP"."REFLOT"="CNTR"."REFDOSS")
       filter("DCMP"."REFLOT" IS NOT NULL)
  14 - access("ACC"."CODEOPER"='OFF_BALANCE_INT')
       filter(("ACC"."REFDOSS"="CNTR"."REFDOSS" OR "ACC"."REFDOSS"="DCMP"."REFDOSS"))
  15 - filter("ACC"."LINENUM"=1)
  16 - filter(("CONTRACT_ID"=:B3 AND "FACTORING_DERIVED_PROD"='CLASSICAL_R'))
  17 - access("EXPOSURE_ID" LIKE :B3||'%' AND "DATE_FROM"=TRUNC("UTL_APP_DATE"."GETAPPDATE"()))
       filter(("EXPOSURE_ID" LIKE :B3||'%' AND "DATE_FROM"=TRUNC("UTL_APP_DATE"."GETAPPDATE"())))


-- gjzdu6mdb82cx
-- With index on NAM_ECR_COMPTA_BAK(CODEOPER, EL2, REFDOSS)

Plan hash value: 2651253612
---------------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                             | Name                      | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  |
---------------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                      |                           |      1 |        |    22 (100)|      1 |00:00:00.06 |      13 |      4 |
|   1 |  SORT AGGREGATE                       |                           |      1 |      1 |            |      1 |00:00:00.06 |      13 |      4 |
|*  2 |   FILTER                              |                           |      1 |        |            |      0 |00:00:00.06 |      13 |      4 |
|   3 |    NESTED LOOPS                       |                           |      1 |    122 |    21  (10)|      0 |00:00:00.02 |      10 |      1 |
|   4 |     NESTED LOOPS                      |                           |      1 |    370 |    21  (10)|      0 |00:00:00.02 |      10 |      1 |
|   5 |      NESTED LOOPS                     |                           |      1 |      1 |     7  (29)|      1 |00:00:00.02 |       6 |      1 |
|   6 |       NESTED LOOPS                    |                           |      1 |      3 |     6  (34)|      1 |00:00:00.01 |       4 |      0 |
|   7 |        VIEW                           | VW_NSO_1                  |      1 |      3 |     5  (40)|      1 |00:00:00.01 |       2 |      0 |
|   8 |         SORT UNIQUE                   |                           |      1 |      3 |     5  (40)|      1 |00:00:00.01 |       2 |      0 |
|   9 |          UNION-ALL                    |                           |      1 |        |            |      1 |00:00:00.01 |       2 |      0 |
|  10 |           FAST DUAL                   |                           |      1 |      1 |     2   (0)|      1 |00:00:00.01 |       0 |      0 |
|* 11 |           INDEX RANGE SCAN            | REFHIERARCHIE_IDX         |      1 |      2 |     1   (0)|      0 |00:00:00.01 |       2 |      0 |
|* 12 |        INDEX UNIQUE SCAN              | DOS_REFDOSS               |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       2 |      0 |
|* 13 |       INDEX RANGE SCAN                | G_DOSSIER_RL_CD_RD_RF_IDX |      1 |      1 |     1   (0)|      1 |00:00:00.02 |       2 |      1 |
|* 14 |      INDEX RANGE SCAN                 | TEST_DD_INDEX             |      1 |    370 |    14   (0)|      0 |00:00:00.01 |       4 |      0 |
|* 15 |     TABLE ACCESS BY INDEX ROWID       | NAM_ECR_COMPTA_BAK        |      0 |     92 |    14   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 16 |    TABLE ACCESS BY INDEX ROWID BATCHED| DWH_RISK_EXPOSURE         |      1 |      1 |     1   (0)|      0 |00:00:00.04 |       3 |      3 |
|* 17 |     INDEX SKIP SCAN                   | PK_DWH_RISK_EXPOSURE      |      1 |     13 |     1   (0)|      0 |00:00:00.04 |       3 |      3 |
---------------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   2 - filter( IS NULL)
  11 - access("REFHIERARCHIE"=:B3)
  12 - access("CNTR"."REFDOSS"=":B3")
  13 - access("DCMP"."REFLOT"="CNTR"."REFDOSS")
       filter("DCMP"."REFLOT" IS NOT NULL)
  14 - access("ACC"."CODEOPER"='WRITE_OFF_AFEE')
       filter(("ACC"."REFDOSS"="CNTR"."REFDOSS" OR "ACC"."REFDOSS"="DCMP"."REFDOSS"))
  15 - filter("ACC"."LINENUM"=1)
  16 - filter(("CONTRACT_ID"=:B3 AND "FACTORING_DERIVED_PROD"='CLASSICAL_R'))
  17 - access("EXPOSURE_ID" LIKE :B3||'%' AND "DATE_FROM"=TRUNC("UTL_APP_DATE"."GETAPPDATE"()))
       filter(("EXPOSURE_ID" LIKE :B3||'%' AND "DATE_FROM"=TRUNC("UTL_APP_DATE"."GETAPPDATE"())))



*/
/********************************New Metrics***************************************/

/********************************Index statistics**********************************/

/********************************Other SQLs****************************************/          
/*

*/ 
/********************************Other SQLs****************************************/              
