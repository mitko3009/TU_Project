Servers  : sv1406 , ra005

Follow the procedure and copy exp_full_QGSM.dmp located on sv1406 : /oradbf2/exp_imp/  to :  ra005 :  /u03/app/oracle/exp.

Some hints : 

Use screen session : 
To create screen session simply type :  screen
To detach from a screen session type : ctrl + a  + d
To list screen sessions : screen -ls 
To attach to a screen session : screen -r screen_session  ( example : screen -r 1206.pts-2.hx0 ) 

On sv1406 : chmod 777 exp_full_QGSM.dmp

On ra005 : cd /u03/app/oracle/exp 
                  scp your_erm_account@sv1406:/oradbf2/exp_imp/ exp_full_QGSM.dmp .
                  Password : your ERM personal password


Collect the timings and medium transfer speed rate and provide them to the customer. 











