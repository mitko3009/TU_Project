/********************************************************************************
*********       E-mail subject: BMCEDEV-1876
*********             Instance: PROD
*********          Description: 
Problem:
BE log with slow query was provided in the task.

Analysis:
We checked in the AWR for a session with the SID and the Serial from the provided BE log. For this session, we found that the TOP SQL, with CLIENT_ID = 'CHLILIKH' is 6u7bg1xc0k1y2 ( the same as this in the BE log ).
In the execution plan it can be seen that the query doesn't access table g_dossier through appropriate index. Instead of making INDEX RANGE SCAN through index DOS_GEST, it makes
INDEX SKIP SCAN on index G_DOSSIER_REFDOSS_SOLDE_RANGMT. The solution here is to add hint, which will force Oracle to use index DOS_GEST.
Also, from the manual execution, we found that in table g_dossier for ~3k rows it makes ~9k buffer gets, which means that there are chained rows. This should be checked by DBA team.

Suggestion:
1. Please ask V9 team to add hint as it is shown in the New SQL section below.
2. Please ask DBA to reorganize (move+rebuild indexes) the G_DOSSIER table on PROD.

*********               SQL_ID: 6u7bg1xc0k1y2
*********      Program/Package: 
*********              Request: Vasil Todorov
*********               Author: Dimitar Dimitrov
********* Received e-mail date: 31/10/2024
*********      Resolution date: 05/11/2024
*********  Trace old file here: \\epox\specifs\performance\tmp\
*********  Trace new file here:
***********************************************************************************/

/********************************OLD SQL*******************************************/

VAR B1 NUMBER;
EXEC :B1 := 55;

SELECT COUNT(1)
  FROM g_dossier g
 WHERE 1 = 1
   AND rangmt = :B1
   AND ( 0 = ( SELECT COUNT(1)
                 FROM t_filiere t, 
                      v_domaine v
                WHERE t.refdoss = g.refdoss
                  AND t.nom = v.ecran
                  AND t.dtfin IS NULL
                  AND v.TYPE = 'filiere'
                  AND v.contexte = 'C' ) 
       OR g.stratif IN ('A', 'R') );
/********************************OLD SQL*******************************************/
/********************************OLD Metrics***************************************/
/*

MODULE                           PROGRAM                                            CLIENT_ID       SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- -------------------------------------------------- --------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
32D86DA3B46F0E419C0004DE7146F913 iMX BE                                             CHLILIKH        6u7bg1xc0k1y2  422830490       1708       5277 db file sequential r 2024/10/23 10:04:32  2024/10/23 10:04:52           3                    1 +000000000 00:00:20.001 50%
A23FBD9B2A36A2B8678575015DCD6840 iMX BE                                             B0096714        fsv6pd6hp6npm 2823638682       1708       5277 ON CPU               2024/10/23 10:05:12  2024/10/23 10:07:02           3                    5 +000000000 00:01:50.061 50%


MODULE                           PROGRAM                                            CLIENT_ID       SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- -------------------------------------------------- --------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
32D86DA3B46F0E419C0004DE7146F913 iMX BE                                             CHLILIKH        6u7bg1xc0k1y2  422830490       1708       5277 db file sequential r 2024/10/23 10:04:32  2024/10/23 10:04:52           3                    1 +000000000 00:00:20.001 50%
A23FBD9B2A36A2B8678575015DCD6840 iMX BE                                             B0096714        fsv6pd6hp6npm 2823638682       1708       5277 ON CPU               2024/10/23 10:05:12  2024/10/23 10:07:02           3                    5 +000000000 00:01:50.061 50%


Plan hash value: 422830490
-------------------------------------------------------------------------------------------------------
| Id  | Operation                              | Name                           | E-Rows | Cost (%CPU)|
-------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                       |                                |        |    26 (100)|
|   1 |  SORT AGGREGATE                        |                                |      1 |            |
|   2 |   FILTER                               |                                |        |            |
|   3 |    INDEX SKIP SCAN                     | G_DOSSIER_REFDOSS_SOLDE_RANGMT |  35677 |    26   (0)|
|   4 |    NESTED LOOPS SEMI                   |                                |      1 |     2   (0)|
|   5 |     TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE                      |      1 |     1   (0)|
|   6 |      INDEX RANGE SCAN                  | V_DOMAINE_TYPE_CODE_IDX        |     43 |     1   (0)|
|   7 |     INDEX RANGE SCAN                   | TIND_FIL                       |      1 |     1   (0)|
-------------------------------------------------------------------------------------------------------


*/
/********************************OLD Metrics***************************************/

/********************************New SQL*******************************************/

SELECT /*+ index(g DOS_GEST) */
       COUNT(1)
  FROM g_dossier g
 WHERE 1 = 1
   AND rangmt = :B1
   AND ( 0 = ( SELECT COUNT(1)
                 FROM t_filiere t, 
                      v_domaine v
                WHERE t.refdoss = g.refdoss
                  AND t.nom = v.ecran
                  AND t.dtfin IS NULL
                  AND v.TYPE = 'filiere'
                  AND v.contexte = 'C' ) 
       OR g.stratif IN ('A', 'R') );
/********************************New SQL*******************************************/
/********************************New Metrics***************************************/
/*
Plan hash value: 545671788
--------------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                              | Name                    | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  |
--------------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                       |                         |      1 |        |     8 (100)|      1 |00:00:00.49 |   13368 |   1175 |
|   1 |  SORT AGGREGATE                        |                         |      1 |      1 |            |      1 |00:00:00.49 |   13368 |   1175 |
|*  2 |   FILTER                               |                         |      1 |        |            |   3295 |00:00:00.49 |   13368 |   1175 |
|   3 |    TABLE ACCESS BY INDEX ROWID BATCHED | G_DOSSIER               |      1 |   1009 |     8   (0)|   3295 |00:00:00.45 |    9493 |   1175 |
|*  4 |     INDEX RANGE SCAN                   | DOS_GEST                |      1 |   1009 |     1   (0)|   3295 |00:00:00.02 |      20 |     18 |
|   5 |    NESTED LOOPS SEMI                   |                         |    430 |      1 |     2   (0)|      0 |00:00:00.03 |    3875 |      0 |
|*  6 |     TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE               |    430 |      1 |     1   (0)|      0 |00:00:00.03 |    3875 |      0 |
|*  7 |      INDEX RANGE SCAN                  | V_DOMAINE_TYPE_CODE_IDX |    430 |     53 |     1   (0)|  58050 |00:00:00.01 |     865 |      0 |
|*  8 |     INDEX RANGE SCAN                   | TIND_FIL                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
--------------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   2 - filter((INTERNAL_FUNCTION("G"."STRATIF") OR  IS NULL))
   4 - access("RANGMT"=:B1)
   6 - filter(("V"."ECRAN" IS NOT NULL AND "V"."CONTEXTE"='C'))
   7 - access("V"."TYPE"='filiere')
   8 - access("T"."REFDOSS"=:B1 AND "T"."NOM"="V"."ECRAN" AND "T"."DTFIN" IS NULL)
*/
/********************************New Metrics***************************************/

/********************************Index statistics**********************************/

/********************************Other SQLs****************************************/          
/*

*/ 
/********************************Other SQLs****************************************/              
