/********************************************************************************
*********       E-mail subject: SVBWEB-5639
*********             Instance: PROD
*********          Description: 
Problem:
Slow query was provided from SVB PROD.

Analysis:
After the analyze I found that the provided query was executed in two session for different reffactors. The first session was with sql_id 804vvyqfs2rm0 for 
reffactor 'A6011F6K' and in the second was with sql_id a1gf0tbpgvbm1 for reffactor 'INT00000'. The problem in both of them was innappropriate execution plan, starting from scanning all 
typpiece = 'FACTURE' from table g_piece which leads to loading a lot of data unnecessary. 

Suggestion:
Please add hints as it is shown in the New SQL section below to achieve a good execution plan.

*********               SQL_ID: a1gf0tbpgvbm1
*********      Program/Package: imxbatch_RecalculateComptesByContract
*********              Request: Ngai Kong Chu
*********               Author: Dimitar Dimitrov
********* Received e-mail date: 26/01/2024
*********      Resolution date: 30/01/2024
*********  Trace old file here: \\epox\specifs\performance\tmp\
*********  Trace new file here:
***********************************************************************************/

/********************************OLD SQL*******************************************/
-- a1gf0tbpgvbm1

SELECT  CONT.reffactor
       ,cont.strRefdossContrat
       ,cont.strRefpieceCTRAACTIVE
       ,cont.iProcess
       ,dcpt.refdoss dcptRefdoss
       ,pf.refdoss   cptRefdoss
       ,PF.gpidepot refCession
       ,pf.refpiece
       ,pf.gpiheure refElem
       ,pf.st09
       ,CASE WHEN     cont.strOldFinancingStatus = pf.fg01
                  AND cont.strNewFinancingStatus = 'O'
             THEN 'O'
             ELSE 'N'
        END newFinancingInvFlag
       ,CASE WHEN     cont.strOldCoverageStatus = pf.fg02
                  AND cont.strNewCoverageStatus = 'O'
             THEN 'O'
             ELSE 'N'
        END newCoverageInvFlag
       ,CASE WHEN pf.st09 IN ('NFIN', 'FIN')
              AND DB.refindividu IN (
                  -- excluded debtors
                  SELECT str2
                    FROM g_piecedet
                   WHERE refpiece = cont.strContractPiece --:qstrRefpieceContract
                     AND TYPE = 'DEBTORS'
                     AND fg01 = 'N' -- excluded
                     AND TRUNC(NVL(dt01_dt,SYSDATE + 1),'DD') >= TRUNC(SYSDATE,'DD')
                     AND NOT EXISTS (
                                      SELECT 1
                                        FROM g_piecedet
                                       WHERE refpiece = cont.strContractPiece --:qstrRefpieceContract
                                         AND TYPE = 'DEBTORS'
                                         AND fg01 = 'O' -- included
                                         AND TRUNC(NVL(dt01_dt,SYSDATE + 1),'DD') >= TRUNC(SYSDATE,'DD')
                                    )
                   )
            THEN 1
            WHEN pf.st09 IN ('NFIN', 'FIN')
             AND DB.refindividu NOT IN (
                 --- not in included debtors
                                          SELECT str2
                                            FROM g_piecedet
                                           WHERE refpiece = cont.strContractPiece --:qstrRefpieceContract
                                             AND TYPE = 'DEBTORS'
                                             AND fg01 = 'O' -- included
                                             AND TRUNC(NVL(dt01_dt,SYSDATE + 1),'DD') >= TRUNC(SYSDATE,'DD')
                                             AND EXISTS (
                                                          SELECT 1
                                                            FROM g_piecedet
                                                           WHERE refpiece = cont.strContractPiece--:qstrRefpieceContract
                                                              AND TYPE = 'DEBTORS'
                                                              AND fg01 = 'O' -- included
                                                              AND TRUNC(NVL(dt01_dt,SYSDATE + 1),'DD') >= TRUNC(SYSDATE,'DD')
                                                         )
                                          )
            THEN 2
            ELSE 0
         END iHasExcludedDebtor
    FROM ( SELECT contr.reffactor
                 ,ca.refdoss strRefdossContrat
                 ,ca.refpiece strRefpieceCTRAACTIVE
                 ,CASE
                    WHEN    nvl( curr.fg10, 'X' ) <> nvl( prev.fg10, 'X' )
                         OR nvl( curr.fg09, 'X' ) <> nvl( prev.fg09, 'X' )
                    THEN 1
                    ELSE 0
                  END iProcess
                 ,curr.fg10 strNewCoverageStatus
                 ,curr.fg09 strNewFinancingStatus
                 ,prev.fg10 strOldCoverageStatus
                 ,prev.fg09 strOldFinancingStatus
                 ,curr.refpiece strContractPiece
            FROM g_piece ca, 
                 g_piece curr, 
                 g_piece prev, 
                 g_dossier contr
           WHERE ca.typpiece   = 'CTRA ACTIVE'
             AND curr.refdoss  = ca.refdoss
             AND contr.refdoss = ca.refdoss
             AND curr.typpiece = 'CONTRAT'
             AND prev.refpiece = ( SELECT max(p.refpiece)
                                     FROM g_piece p, 
                                          g_piecedet d
                                    WHERE p.refdoss = curr.refdoss
                                      AND p.typpiece = 'A.CONTRAT'
                                      AND d.refpiece = p.refpiece
                                      AND d.TYPE = 'CONTRACT SITUATIONS'
                                      AND d.str1 = 'V'
                                  )
        ) CONT
       ,g_piece PF
       ,g_dossier cmp
       ,g_dossier dcpt
       ,t_intervenants DB
  WHERE dcpt.reflot = cont.strRefdossContrat
    /* reffactor condition */
    AND CONT.reffactor IN ('INT00000')
    AND cmp.reflot = dcpt.refdoss
    AND PF.refdoss = cmp.refdoss
    AND PF.typpiece = 'FACTURE'
    AND PF.st09 IN ('NGPC', 'GPC', 'NFIN', 'FIN')
    AND DB.reftype = 'DB'
    AND DB.refdoss = cmp.refdoss
    AND cont.iProcess = 1
   UNION ALL
   (
   SELECT CONT.reffactor,
          ca.refdoss strRefdossContrat,
          ca.refpiece strRefpieceCTRAACTIVE,
          0 iProcess,
          'x' dcptRefdoss,
          'x' cptRefdoss,
          'x' refCession,
          'x' refpiece,
          'x' refElem,
          'x' st09,
          'x' newFinancingInvFlag,
          'x' newCoverageInvFlag,
           0 iHasExcludedDebtor
        FROM g_piece ca, 
             g_piece curr, 
             g_piece prev, 
             g_dossier cont
       WHERE 1=1
    /* reffactor condition */
   AND CONT.reffactor IN ('INT00000')
         AND cont.refdoss = ca.refdoss
         AND ca.typpiece = 'CTRA ACTIVE'
         AND curr.refdoss = ca.refdoss
         AND curr.typpiece = 'CONTRAT'
         --AND nvl( curr.fg10, 'X' ) = nvl( prev.fg10, 'X' )  --coverage
         --AND nvl( curr.fg09, 'X' ) = nvl( prev.fg09, 'X' ) --financing
         AND prev.refdoss = curr.refdoss
         AND prev.refpiece = (
                                SELECT max(p.refpiece)
                                  FROM g_piece p, 
                                       g_piecedet d
                                 WHERE p.refdoss = curr.refdoss
                                   AND p.typpiece = 'A.CONTRAT'
                                   AND d.refpiece = p.refpiece
                                   AND d.TYPE = 'CONTRACT SITUATIONS'
                                   AND d.str1 = 'V'
                              )
   )
  ORDER BY strRefdossContrat, dcptRefdoss, refCession, cptRefdoss;
/********************************OLD SQL*******************************************/
/********************************OLD Metrics***************************************/
/*
MODULE                           SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL            PERC
-------------------------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
imxbatch_RecalculateComptesByCon                911089547                       read by other sessio 2024/01/22 20:36:41  2024/01/22 21:16:04         216                    1 +000000000 00:39:23.112 26%
tract

imxbatch_RecalculateComptesByCon                911089547                       db file sequential r 2024/01/22 20:36:41  2024/01/22 21:16:04         212                    1 +000000000 00:39:23.112 26%
tract

                                 0gwc9vhhygvbb          0                       ON CPU               2024/01/22 20:35:21  2024/01/22 21:19:04          91                 1832 +000000000 00:43:43.118 11%
imxbatch_RecalculateComptesByCon                911089547                       ON CPU               2024/01/22 20:37:41  2024/01/22 21:15:54          43                    1 +000000000 00:38:13.106 5%
tract

msgq_memo_decompte                                                              ON CPU               2024/01/22 20:41:12  2024/01/22 20:43:02          23              2855671 +000000000 00:01:50.005 3%


MODULE                           SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL            PERC
-------------------------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
imxbatch_RecalculateComptesByCon                911089547                       read by other sessio 2024/01/22 20:36:41  2024/01/22 21:16:04         216                    1 +000000000 00:39:23.112 46%
tract

imxbatch_RecalculateComptesByCon                911089547                       db file sequential r 2024/01/22 20:36:41  2024/01/22 21:16:04         212                    1 +000000000 00:39:23.112 45%
tract

imxbatch_RecalculateComptesByCon                911089547                       ON CPU               2024/01/22 20:37:41  2024/01/22 21:15:54          43                    1 +000000000 00:38:13.106 9%
tract

imxbatch_RecalculateComptesByCon a1gf0tbpgvbm1  911089547       1931       1110 db file parallel rea 2024/01/22 21:00:43  2024/01/22 21:00:53           2                    1 +000000000 00:00:10.000 0%
tract

imxbatch_RecalculateComptesByCon a1gf0tbpgvbm1  911089547       1931       1110 db file scattered re 2024/01/22 21:11:34  2024/01/22 21:11:34           1                    1 +000000000 00:00:00.000 0%
tract


MODULE                           SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL            PERC
-------------------------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
imxbatch_RecalculateComptesByCon 804vvyqfs2rm0  911089547        333       4173                      2024/01/22 20:36:41  2024/01/22 21:16:04         237                    1 +000000000 00:39:23.112 50%
tract

imxbatch_RecalculateComptesByCon a1gf0tbpgvbm1  911089547       1931       1110                      2024/01/22 20:36:41  2024/01/22 21:16:04         237                    1 +000000000 00:39:23.112 50%
tract

INSTANCE_NUMBER SQL_ID            ELAPSED MAX_WAIT_ON     PC_OF  WAIT_TIME            GETS      READS       ROWS  ELAP/EXEC       GETS/EXEC READS/EXEC  ROWS/EXEC       EXEC PLAN_HASH_VALUE
--------------- ------------- ----------- --------------- ----- ---------- --------------- ---------- ---------- ---------- --------------- ---------- ---------- ---------- ---------------
              1 a1gf0tbpgvbm1        2373 IO              87%   2466.75544        87369223    1450863          3    2373.01        87369223    1450863          3          1   911089547
              
              
SQL_ID        SQL_PLAN_HASH_VALUE SQL_PLAN_LINE_ID SQL_PLAN_OPERATION             SQL_PLAN_OPTIONS                   ACTIVE
------------- ------------------- ---------------- ------------------------------ ------------------------------ ----------
a1gf0tbpgvbm1           911089547               21 TABLE ACCESS                   BY INDEX ROWID BATCHED                220
a1gf0tbpgvbm1           911089547               22 INDEX                          RANGE SCAN                              5
a1gf0tbpgvbm1           911089547               24 INDEX                          RANGE SCAN                              4
a1gf0tbpgvbm1           911089547               23 INDEX                          RANGE SCAN                              4
a1gf0tbpgvbm1           911089547               27 INDEX                          RANGE SCAN                              3
a1gf0tbpgvbm1           911089547               25 INDEX                          RANGE SCAN                              1                
  
  
Plan hash value: 911089547
-----------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                     | Name                      | Rows  | Bytes |TempSpc| Cost (%CPU)| Time     |
-----------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                              |                           |       |       |       |   426K(100)|          |
|   1 |  SORT ORDER BY                                |                           |     2 |   620 |       |   426K  (1)| 00:00:17 |
|   2 |   UNION-ALL                                   |                           |       |       |       |            |          |
|*  3 |    FILTER                                     |                           |       |       |       |            |          |
|*  4 |     TABLE ACCESS BY INDEX ROWID BATCHED       | G_PIECEDET                |     1 |    49 |       |     3   (0)| 00:00:01 |
|*  5 |      INDEX SKIP SCAN                          | G_PIECEDET_REFP           |     1 |       |       |     3   (0)| 00:00:01 |
|*  6 |     TABLE ACCESS BY INDEX ROWID BATCHED       | G_PIECEDET                |     1 |    45 |       |     3   (0)| 00:00:01 |
|*  7 |      INDEX SKIP SCAN                          | G_PIECEDET_REFP           |     1 |       |       |     3   (0)| 00:00:01 |
|*  8 |     FILTER                                    |                           |       |       |       |            |          |
|*  9 |      TABLE ACCESS BY INDEX ROWID BATCHED      | G_PIECEDET                |     1 |    49 |       |     3   (0)| 00:00:01 |
|* 10 |       INDEX SKIP SCAN                         | G_PIECEDET_REFP           |     1 |       |       |     3   (0)| 00:00:01 |
|* 11 |      TABLE ACCESS BY INDEX ROWID BATCHED      | G_PIECEDET                |     1 |    45 |       |     3   (0)| 00:00:01 |
|* 12 |       INDEX SKIP SCAN                         | G_PIECEDET_REFP           |     1 |       |       |     3   (0)| 00:00:01 |
|  13 |    NESTED LOOPS                               |                           |     1 |   220 |       |   104K  (1)| 00:00:05 |
|  14 |     NESTED LOOPS                              |                           |     1 |   220 |       |   104K  (1)| 00:00:05 |
|  15 |      NESTED LOOPS                             |                           |     1 |   207 |       |   104K  (1)| 00:00:05 |
|  16 |       NESTED LOOPS                            |                           |     1 |   173 |       |   104K  (1)| 00:00:05 |
|  17 |        NESTED LOOPS                           |                           |     1 |   153 |       |   104K  (1)| 00:00:05 |
|  18 |         NESTED LOOPS                          |                           |     1 |   123 |       |   104K  (1)| 00:00:05 |
|  19 |          NESTED LOOPS                         |                           |     1 |   101 |       |   104K  (1)| 00:00:05 |
|  20 |           NESTED LOOPS                        |                           |     1 |    77 |       |   104K  (1)| 00:00:05 |
|* 21 |            TABLE ACCESS BY INDEX ROWID BATCHED| G_PIECE                   |     1 |    55 |       |   104K  (1)| 00:00:05 |
|* 22 |             INDEX RANGE SCAN                  | PIECE_TYP_MT43_IDX        |   975K|       |       |  1808   (1)| 00:00:01 |
|* 23 |            INDEX RANGE SCAN                   | DOS_REFDOSS_REFLOT_IDX    |     1 |    22 |       |     1   (0)| 00:00:01 |
|* 24 |           INDEX RANGE SCAN                    | INT_REFDOSS               |     1 |    24 |       |     1   (0)| 00:00:01 |
|* 25 |          INDEX RANGE SCAN                     | DOS_REFDOSS_REFLOT_IDX    |     1 |    22 |       |     1   (0)| 00:00:01 |
|  26 |         TABLE ACCESS BY INDEX ROWID BATCHED   | G_PIECE                   |     1 |    30 |       |     4   (0)| 00:00:01 |
|* 27 |          INDEX RANGE SCAN                     | PIE_REFDOSS               |     9 |       |       |     2   (0)| 00:00:01 |
|* 28 |        TABLE ACCESS BY INDEX ROWID            | G_DOSSIER                 |     1 |    20 |       |     1   (0)| 00:00:01 |
|* 29 |         INDEX UNIQUE SCAN                     | DOS_REFDOSS               |     1 |       |       |     1   (0)| 00:00:01 |
|  30 |       TABLE ACCESS BY INDEX ROWID BATCHED     | G_PIECE                   |     1 |    34 |       |     4   (0)| 00:00:01 |
|* 31 |        INDEX RANGE SCAN                       | PIE_REFDOSS               |     9 |       |       |     2   (0)| 00:00:01 |
|* 32 |      INDEX RANGE SCAN                         | PIE_REFPIECE              |     1 |       |       |     1   (0)| 00:00:01 |
|  33 |       SORT AGGREGATE                          |                           |     1 |    74 |       |            |          |
|  34 |        NESTED LOOPS SEMI                      |                           |     1 |    74 |       |     8   (0)| 00:00:01 |
|  35 |         TABLE ACCESS BY INDEX ROWID BATCHED   | G_PIECE                   |     1 |    30 |       |     5   (0)| 00:00:01 |
|* 36 |          INDEX RANGE SCAN                     | PIE_REFDOSS               |    10 |       |       |     2   (0)| 00:00:01 |
|* 37 |         TABLE ACCESS BY INDEX ROWID BATCHED   | G_PIECEDET                |     3 |   132 |       |     3   (0)| 00:00:01 |
|* 38 |          INDEX RANGE SCAN                     | G_PIECEDET_REFP           |     1 |       |       |     2   (0)| 00:00:01 |
|* 39 |     TABLE ACCESS BY INDEX ROWID               | G_PIECE                   |     1 |    13 |       |     2   (0)| 00:00:01 |
|  40 |    NESTED LOOPS                               |                           |     1 |    90 |       |   322K  (1)| 00:00:13 |
|  41 |     NESTED LOOPS                              |                           |   137K|    90 |       |   322K  (1)| 00:00:13 |
|* 42 |      HASH JOIN                                |                           |   137K|  9499K|    16M|   116K  (1)| 00:00:05 |
|* 43 |       HASH JOIN                               |                           |   284K|    13M|    18M|   111K  (1)| 00:00:05 |
|* 44 |        INDEX FAST FULL SCAN                   | G_DOSSIER_RL_CD_RD_RF_IDX |   590K|    11M|       |  4480   (1)| 00:00:01 |
|* 45 |        TABLE ACCESS BY INDEX ROWID BATCHED    | G_PIECE                   |   844K|    24M|       |   104K  (1)| 00:00:05 |
|* 46 |         INDEX RANGE SCAN                      | PIECE_TYP_MT43_IDX        |   975K|       |       |  1808   (1)| 00:00:01 |
|* 47 |       INDEX RANGE SCAN                        | GP_TYPP_FG01_NB04_DOS_IDX |   844K|    16M|       |  3199   (1)| 00:00:01 |
|* 48 |      INDEX RANGE SCAN                         | PIE_REFPIECE              |     1 |       |       |     1   (0)| 00:00:01 |
|  49 |       SORT AGGREGATE                          |                           |     1 |    74 |       |            |          |
|  50 |        NESTED LOOPS SEMI                      |                           |     1 |    74 |       |     8   (0)| 00:00:01 |
|  51 |         TABLE ACCESS BY INDEX ROWID BATCHED   | G_PIECE                   |     1 |    30 |       |     5   (0)| 00:00:01 |
|* 52 |          INDEX RANGE SCAN                     | PIE_REFDOSS               |    10 |       |       |     2   (0)| 00:00:01 |
|* 53 |         TABLE ACCESS BY INDEX ROWID BATCHED   | G_PIECEDET                |     3 |   132 |       |     3   (0)| 00:00:01 |
|* 54 |          INDEX RANGE SCAN                     | G_PIECEDET_REFP           |     1 |       |       |     2   (0)| 00:00:01 |
|* 55 |     TABLE ACCESS BY INDEX ROWID               | G_PIECE                   |     1 |    19 |       |     2   (0)| 00:00:01 |
-----------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   3 - filter( IS NULL)
   4 - filter(("STR2"=:B1 AND "FG01"='N'))
   5 - access("REFPIECE"=:B1 AND "TYPE"='DEBTORS')
       filter(TRUNC(NVL("DT01_DT",SYSDATE@!+1),'fmdd')>=TRUNC(SYSDATE@!,'fmdd'))
   6 - filter("FG01"='O')
   7 - access("REFPIECE"=:B1 AND "TYPE"='DEBTORS')
       filter(TRUNC(NVL("DT01_DT",SYSDATE@!+1),'fmdd')>=TRUNC(SYSDATE@!,'fmdd'))
   8 - filter( IS NOT NULL)
   9 - filter(("FG01"='O' AND LNNVL("STR2"<>:B1)))
  10 - access("REFPIECE"=:B1 AND "TYPE"='DEBTORS')
       filter(TRUNC(NVL("DT01_DT",SYSDATE@!+1),'fmdd')>=TRUNC(SYSDATE@!,'fmdd'))
  11 - filter("FG01"='O')
  12 - access("REFPIECE"=:B1 AND "TYPE"='DEBTORS')
       filter(TRUNC(NVL("DT01_DT",SYSDATE@!+1),'fmdd')>=TRUNC(SYSDATE@!,'fmdd'))
  21 - filter(("PF"."REFDOSS" IS NOT NULL AND INTERNAL_FUNCTION("PF"."ST09")))
  22 - access("PF"."TYPPIECE"='FACTURE')
  23 - access("PF"."REFDOSS"="CMP"."REFDOSS")
  24 - access("DB"."REFDOSS"="CMP"."REFDOSS" AND "DB"."REFTYPE"='DB')
  25 - access("CMP"."REFLOT"="DCPT"."REFDOSS")
  27 - access("DCPT"."REFLOT"="CA"."REFDOSS" AND "CA"."TYPPIECE"='CTRA ACTIVE')
       filter("CA"."REFDOSS" IS NOT NULL)
  28 - filter("CONTR"."REFFACTOR"='INT00000')
  29 - access("CONTR"."REFDOSS"="CA"."REFDOSS")
  31 - access("CURR"."REFDOSS"="CA"."REFDOSS" AND "CURR"."TYPPIECE"='CONTRAT')
       filter("CURR"."REFDOSS" IS NOT NULL)
  32 - access("PREV"."REFPIECE"=)
  36 - access("P"."REFDOSS"=:B1 AND "P"."TYPPIECE"='A.CONTRAT')
  37 - filter("D"."STR1"='V')
  38 - access("D"."REFPIECE"="P"."REFPIECE" AND "D"."TYPE"='CONTRACT SITUATIONS')
  39 - filter(CASE  WHEN (NVL("CURR"."FG10",'X')<>NVL("PREV"."FG10",'X') OR
              NVL("CURR"."FG09",'X')<>NVL("PREV"."FG09",'X')) THEN 1 ELSE 0 END =1)
  42 - access("CURR"."REFDOSS"="CA"."REFDOSS")
  43 - access("CONT"."REFDOSS"="CA"."REFDOSS")
  44 - filter("CONT"."REFFACTOR"='INT00000')
  45 - filter("CA"."REFDOSS" IS NOT NULL)
  46 - access("CA"."TYPPIECE"='CTRA ACTIVE')
  47 - access("CURR"."TYPPIECE"='CONTRAT')
       filter("CURR"."REFDOSS" IS NOT NULL)
  48 - access("PREV"."REFPIECE"=)
  52 - access("P"."REFDOSS"=:B1 AND "P"."TYPPIECE"='A.CONTRAT')
  53 - filter("D"."STR1"='V')
  54 - access("D"."REFPIECE"="P"."REFPIECE" AND "D"."TYPE"='CONTRACT SITUATIONS')
  55 - filter(("PREV"."REFDOSS"="CURR"."REFDOSS" AND "PREV"."REFDOSS" IS NOT NULL))
*/
/********************************OLD Metrics***************************************/

/********************************New SQL*******************************************/

SELECT  /*+ leading(cont) */
       CONT.reffactor
       ,cont.strRefdossContrat
       ,cont.strRefpieceCTRAACTIVE
       ,cont.iProcess
       ,dcpt.refdoss dcptRefdoss
       ,pf.refdoss   cptRefdoss
       ,PF.gpidepot refCession
       ,pf.refpiece
       ,pf.gpiheure refElem
       ,pf.st09
       ,CASE WHEN     cont.strOldFinancingStatus = pf.fg01
                  AND cont.strNewFinancingStatus = 'O'
             THEN 'O'
             ELSE 'N'
        END newFinancingInvFlag
       ,CASE WHEN     cont.strOldCoverageStatus = pf.fg02
                  AND cont.strNewCoverageStatus = 'O'
             THEN 'O'
             ELSE 'N'
        END newCoverageInvFlag
       ,CASE WHEN pf.st09 IN ('NFIN', 'FIN')
              AND DB.refindividu IN (
                  -- excluded debtors
                  SELECT str2
                    FROM g_piecedet
                   WHERE refpiece = cont.strContractPiece --:qstrRefpieceContract
                     AND TYPE = 'DEBTORS'
                     AND fg01 = 'N' -- excluded
                     AND TRUNC(NVL(dt01_dt,SYSDATE + 1),'DD') >= TRUNC(SYSDATE,'DD')
                     AND NOT EXISTS (
                                      SELECT 1
                                        FROM g_piecedet
                                       WHERE refpiece = cont.strContractPiece --:qstrRefpieceContract
                                         AND TYPE = 'DEBTORS'
                                         AND fg01 = 'O' -- included
                                         AND TRUNC(NVL(dt01_dt,SYSDATE + 1),'DD') >= TRUNC(SYSDATE,'DD')
                                    )
                   )
            THEN 1
            WHEN pf.st09 IN ('NFIN', 'FIN')
             AND DB.refindividu NOT IN (
                 --- not in included debtors
                                          SELECT str2
                                            FROM g_piecedet
                                           WHERE refpiece = cont.strContractPiece --:qstrRefpieceContract
                                             AND TYPE = 'DEBTORS'
                                             AND fg01 = 'O' -- included
                                             AND TRUNC(NVL(dt01_dt,SYSDATE + 1),'DD') >= TRUNC(SYSDATE,'DD')
                                             AND EXISTS (
                                                          SELECT 1
                                                            FROM g_piecedet
                                                           WHERE refpiece = cont.strContractPiece--:qstrRefpieceContract
                                                              AND TYPE = 'DEBTORS'
                                                              AND fg01 = 'O' -- included
                                                              AND TRUNC(NVL(dt01_dt,SYSDATE + 1),'DD') >= TRUNC(SYSDATE,'DD')
                                                         )
                                          )
            THEN 2
            ELSE 0
         END iHasExcludedDebtor
    FROM ( SELECT /*+ leading(ca contr curr prev) no_merge no_push_pred */
                  contr.reffactor
                 ,ca.refdoss strRefdossContrat
                 ,ca.refpiece strRefpieceCTRAACTIVE
                 ,CASE
                    WHEN    nvl( curr.fg10, 'X' ) <> nvl( prev.fg10, 'X' )
                         OR nvl( curr.fg09, 'X' ) <> nvl( prev.fg09, 'X' )
                    THEN 1
                    ELSE 0
                  END iProcess
                 ,curr.fg10 strNewCoverageStatus
                 ,curr.fg09 strNewFinancingStatus
                 ,prev.fg10 strOldCoverageStatus
                 ,prev.fg09 strOldFinancingStatus
                 ,curr.refpiece strContractPiece
            FROM g_piece ca, 
                 g_piece curr, 
                 g_piece prev, 
                 g_dossier contr
           WHERE ca.typpiece   = 'CTRA ACTIVE'
             AND curr.refdoss  = ca.refdoss
             AND contr.refdoss = ca.refdoss
             AND curr.typpiece = 'CONTRAT'
             AND prev.refpiece = ( SELECT /*+ leading(p d) */
                                          max(p.refpiece)
                                     FROM g_piece p, 
                                          g_piecedet d
                                    WHERE p.refdoss = curr.refdoss
                                      AND p.typpiece = 'A.CONTRAT'
                                      AND d.refpiece = p.refpiece
                                      AND d.TYPE = 'CONTRACT SITUATIONS'
                                      AND d.str1 = 'V'
                                  )
        ) CONT
       ,g_piece PF
       ,g_dossier cmp
       ,g_dossier dcpt
       ,t_intervenants DB
  WHERE dcpt.reflot = cont.strRefdossContrat
    /* reffactor condition */
    AND CONT.reffactor IN ('INT00000')
    AND cmp.reflot = dcpt.refdoss
    AND PF.refdoss = cmp.refdoss
    AND PF.typpiece = 'FACTURE'
    AND PF.st09 IN ('NGPC', 'GPC', 'NFIN', 'FIN')
    AND DB.reftype = 'DB'
    AND DB.refdoss = cmp.refdoss
    AND cont.iProcess = 1
   UNION ALL
   (
   SELECT /*+ leading(ca curr cont prev)*/
          CONT.reffactor,
          ca.refdoss strRefdossContrat,
          ca.refpiece strRefpieceCTRAACTIVE,
          0 iProcess,
          'x' dcptRefdoss,
          'x' cptRefdoss,
          'x' refCession,
          'x' refpiece,
          'x' refElem,
          'x' st09,
          'x' newFinancingInvFlag,
          'x' newCoverageInvFlag,
           0 iHasExcludedDebtor
        FROM g_piece ca, 
             g_piece curr, 
             g_piece prev, 
             g_dossier cont
       WHERE 1=1
    /* reffactor condition */
   AND CONT.reffactor IN ('INT00000')
         AND cont.refdoss = ca.refdoss
         AND ca.typpiece = 'CTRA ACTIVE'
         AND curr.refdoss = ca.refdoss
         AND curr.typpiece = 'CONTRAT'
         --AND nvl( curr.fg10, 'X' ) = nvl( prev.fg10, 'X' )  --coverage
         --AND nvl( curr.fg09, 'X' ) = nvl( prev.fg09, 'X' ) --financing
         AND prev.refdoss = curr.refdoss
         AND prev.refpiece = (
                                SELECT max(p.refpiece)
                                  FROM g_piece p, 
                                       g_piecedet d
                                 WHERE p.refdoss = curr.refdoss
                                   AND p.typpiece = 'A.CONTRAT'
                                   AND d.refpiece = p.refpiece
                                   AND d.TYPE = 'CONTRACT SITUATIONS'
                                   AND d.str1 = 'V'
                              )
   )
  ORDER BY strRefdossContrat, dcptRefdoss, refCession, cptRefdoss; 
/********************************New SQL*******************************************/
/********************************New Metrics***************************************/
/*
Plan hash value: 1937002627
-----------------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                        | Name                      | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers |
-----------------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                                 |                           |      1 |        |   132 (100)|      0 |00:00:00.01 |    1268 |
|   1 |  SORT ORDER BY                                   |                           |      1 |      2 |   131   (0)|      0 |00:00:00.01 |    1268 |
|   2 |   UNION-ALL                                      |                           |      1 |        |            |      0 |00:00:00.01 |    1268 |
|*  3 |    FILTER                                        |                           |      0 |        |            |      0 |00:00:00.01 |       0 |
|*  4 |     TABLE ACCESS BY INDEX ROWID BATCHED          | G_PIECEDET                |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*  5 |      INDEX SKIP SCAN                             | G_PIECEDET_REFP           |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*  6 |     TABLE ACCESS BY INDEX ROWID BATCHED          | G_PIECEDET                |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*  7 |      INDEX SKIP SCAN                             | G_PIECEDET_REFP           |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*  8 |     FILTER                                       |                           |      0 |        |            |      0 |00:00:00.01 |       0 |
|*  9 |      TABLE ACCESS BY INDEX ROWID BATCHED         | G_PIECEDET                |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|* 10 |       INDEX SKIP SCAN                            | G_PIECEDET_REFP           |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|* 11 |      TABLE ACCESS BY INDEX ROWID BATCHED         | G_PIECEDET                |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|* 12 |       INDEX SKIP SCAN                            | G_PIECEDET_REFP           |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|  13 |    NESTED LOOPS                                  |                           |      1 |      1 |   100   (0)|      0 |00:00:00.01 |     759 |
|  14 |     NESTED LOOPS                                 |                           |      1 |     12 |   100   (0)|      0 |00:00:00.01 |     759 |
|  15 |      NESTED LOOPS                                |                           |      1 |      1 |    95   (0)|      0 |00:00:00.01 |     759 |
|  16 |       NESTED LOOPS                               |                           |      1 |      1 |    94   (0)|      0 |00:00:00.01 |     759 |
|  17 |        NESTED LOOPS                              |                           |      1 |      1 |    91   (0)|      0 |00:00:00.01 |     759 |
|  18 |         NESTED LOOPS                             |                           |      1 |      1 |    89   (0)|      0 |00:00:00.01 |     759 |
|  19 |          NESTED LOOPS                            |                           |      1 |      1 |    87   (0)|     54 |00:00:00.01 |     595 |
|  20 |           NESTED LOOPS                           |                           |      1 |     16 |    55   (0)|     54 |00:00:00.01 |     328 |
|* 21 |            TABLE ACCESS BY INDEX ROWID BATCHED   | G_PIECE                   |      1 |     47 |     8   (0)|     54 |00:00:00.01 |      61 |
|* 22 |             INDEX RANGE SCAN                     | PIECE_TYP_MT43_IDX        |      1 |     54 |     2   (0)|     54 |00:00:00.01 |       7 |
|* 23 |            TABLE ACCESS BY INDEX ROWID           | G_DOSSIER                 |     54 |      1 |     1   (0)|     54 |00:00:00.01 |     267 |
|* 24 |             INDEX UNIQUE SCAN                    | DOS_REFDOSS               |     54 |      1 |     1   (0)|     54 |00:00:00.01 |     110 |
|  25 |           TABLE ACCESS BY INDEX ROWID BATCHED    | G_PIECE                   |     54 |      1 |     2   (0)|     54 |00:00:00.01 |     267 |
|* 26 |            INDEX RANGE SCAN                      | PIE_REFDOSS               |     54 |      1 |     2   (0)|     54 |00:00:00.01 |     164 |
|* 27 |          TABLE ACCESS BY INDEX ROWID BATCHED     | G_PIECE                   |     54 |      1 |     2   (0)|      0 |00:00:00.01 |     164 |
|* 28 |           INDEX RANGE SCAN                       | PIE_REFPIECE              |     54 |      1 |     1   (0)|      0 |00:00:00.01 |     164 |
|  29 |            SORT AGGREGATE                        |                           |     54 |      1 |            |     54 |00:00:00.01 |     164 |
|  30 |             NESTED LOOPS                         |                           |     54 |      1 |     5   (0)|      0 |00:00:00.01 |     164 |
|  31 |              NESTED LOOPS                        |                           |     54 |      1 |     5   (0)|      0 |00:00:00.01 |     164 |
|  32 |               TABLE ACCESS BY INDEX ROWID BATCHED| G_PIECE                   |     54 |      1 |     3   (0)|      0 |00:00:00.01 |     164 |
|* 33 |                INDEX RANGE SCAN                  | PIE_REFDOSS               |     54 |      1 |     2   (0)|      0 |00:00:00.01 |     164 |
|* 34 |               INDEX RANGE SCAN                   | G_PIECEDET_REFP           |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |
|* 35 |              TABLE ACCESS BY INDEX ROWID         | G_PIECEDET                |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|* 36 |         INDEX RANGE SCAN                         | G_DOSSIER_RL_CD_RD_RF_IDX |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|* 37 |        INDEX RANGE SCAN                          | G_DOSSIER_RL_CD_RD_RF_IDX |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|* 38 |       INDEX RANGE SCAN                           | INT_REFDOSS               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 39 |      INDEX RANGE SCAN                            | PIE_REFDOSS               |      0 |     12 |     2   (0)|      0 |00:00:00.01 |       0 |
|* 40 |     TABLE ACCESS BY INDEX ROWID                  | G_PIECE                   |      0 |      1 |     5   (0)|      0 |00:00:00.01 |       0 |
|  41 |    NESTED LOOPS                                  |                           |      1 |      1 |    19   (0)|      0 |00:00:00.01 |     509 |
|  42 |     NESTED LOOPS                                 |                           |      1 |      1 |    19   (0)|      0 |00:00:00.01 |     509 |
|  43 |      NESTED LOOPS                                |                           |      1 |      1 |    18   (0)|     54 |00:00:00.01 |     345 |
|* 44 |       HASH JOIN                                  |                           |      1 |      1 |    17   (0)|     54 |00:00:00.01 |      78 |
|* 45 |        TABLE ACCESS BY INDEX ROWID BATCHED       | G_PIECE                   |      1 |     47 |     8   (0)|     54 |00:00:00.01 |      61 |
|* 46 |         INDEX RANGE SCAN                         | PIECE_TYP_MT43_IDX        |      1 |     54 |     2   (0)|     54 |00:00:00.01 |       7 |
|* 47 |        INDEX RANGE SCAN                          | GP_TYPP_FG01_NB04_DOS_IDX |      1 |   1812 |     9   (0)|   2094 |00:00:00.01 |      17 |
|* 48 |       TABLE ACCESS BY INDEX ROWID                | G_DOSSIER                 |     54 |      1 |     1   (0)|     54 |00:00:00.01 |     267 |
|* 49 |        INDEX UNIQUE SCAN                         | DOS_REFDOSS               |     54 |      1 |     1   (0)|     54 |00:00:00.01 |     110 |
|* 50 |      INDEX RANGE SCAN                            | PIE_REFPIECE              |     54 |      1 |     1   (0)|      0 |00:00:00.01 |     164 |
|  51 |       SORT AGGREGATE                             |                           |     54 |      1 |            |     54 |00:00:00.01 |     164 |
|  52 |        NESTED LOOPS SEMI                         |                           |     54 |      1 |     5   (0)|      0 |00:00:00.01 |     164 |
|  53 |         TABLE ACCESS BY INDEX ROWID BATCHED      | G_PIECE                   |     54 |      1 |     3   (0)|      0 |00:00:00.01 |     164 |
|* 54 |          INDEX RANGE SCAN                        | PIE_REFDOSS               |     54 |      1 |     2   (0)|      0 |00:00:00.01 |     164 |
|* 55 |         TABLE ACCESS BY INDEX ROWID BATCHED      | G_PIECEDET                |      0 |      3 |     3   (0)|      0 |00:00:00.01 |       0 |
|* 56 |          INDEX RANGE SCAN                        | G_PIECEDET_REFP           |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |
|* 57 |     TABLE ACCESS BY INDEX ROWID                  | G_PIECE                   |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |
-----------------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   3 - filter( IS NULL)
   4 - filter(("STR2"=:B1 AND "FG01"='N'))
   5 - access("REFPIECE"=:B1 AND "TYPE"='DEBTORS')
       filter(TRUNC(NVL("DT01_DT",SYSDATE@!+1),'fmdd')>=TRUNC(SYSDATE@!,'fmdd'))
   6 - filter("FG01"='O')
   7 - access("REFPIECE"=:B1 AND "TYPE"='DEBTORS')
       filter(TRUNC(NVL("DT01_DT",SYSDATE@!+1),'fmdd')>=TRUNC(SYSDATE@!,'fmdd'))
   8 - filter( IS NOT NULL)
   9 - filter(("FG01"='O' AND LNNVL("STR2"<>:B1)))
  10 - access("REFPIECE"=:B1 AND "TYPE"='DEBTORS')
       filter(TRUNC(NVL("DT01_DT",SYSDATE@!+1),'fmdd')>=TRUNC(SYSDATE@!,'fmdd'))
  11 - filter("FG01"='O')
  12 - access("REFPIECE"=:B1 AND "TYPE"='DEBTORS')
       filter(TRUNC(NVL("DT01_DT",SYSDATE@!+1),'fmdd')>=TRUNC(SYSDATE@!,'fmdd'))
  21 - filter("CA"."REFDOSS" IS NOT NULL)
  22 - access("CA"."TYPPIECE"='CTRA ACTIVE')
  23 - filter("CONTR"."REFFACTOR"='INT00000')
  24 - access("CONTR"."REFDOSS"="CA"."REFDOSS")
  26 - access("CURR"."REFDOSS"="CA"."REFDOSS" AND "CURR"."TYPPIECE"='CONTRAT')
       filter("CURR"."REFDOSS" IS NOT NULL)
  27 - filter(CASE  WHEN (NVL("CURR"."FG10",'X')<>NVL("PREV"."FG10",'X') OR NVL("CURR"."FG09",'X')<>NVL("PREV"."FG09",'X')) THEN 1 ELSE 0
              END =1)
  28 - access("PREV"."REFPIECE"=)
  33 - access("P"."REFDOSS"=:B1 AND "P"."TYPPIECE"='A.CONTRAT')
  34 - access("D"."REFPIECE"="P"."REFPIECE" AND "D"."TYPE"='CONTRACT SITUATIONS')
  35 - filter("D"."STR1"='V')
  36 - access("DCPT"."REFLOT"="CA"."REFDOSS")
  37 - access("CMP"."REFLOT"="DCPT"."REFDOSS")
  38 - access("DB"."REFDOSS"="CMP"."REFDOSS" AND "DB"."REFTYPE"='DB')
  39 - access("PF"."REFDOSS"="CMP"."REFDOSS" AND "PF"."TYPPIECE"='FACTURE')
       filter("PF"."REFDOSS" IS NOT NULL)
  40 - filter(("PF"."ST09"='FIN' OR "PF"."ST09"='GPC' OR "PF"."ST09"='NFIN' OR "PF"."ST09"='NGPC'))
  44 - access("CURR"."REFDOSS"="CA"."REFDOSS")
  45 - filter("CA"."REFDOSS" IS NOT NULL)
  46 - access("CA"."TYPPIECE"='CTRA ACTIVE')
  47 - access("CURR"."TYPPIECE"='CONTRAT')
       filter("CURR"."REFDOSS" IS NOT NULL)
  48 - filter("CONT"."REFFACTOR"='INT00000')
  49 - access("CONT"."REFDOSS"="CA"."REFDOSS")
  50 - access("PREV"."REFPIECE"=)
  54 - access("P"."REFDOSS"=:B1 AND "P"."TYPPIECE"='A.CONTRAT')
  55 - filter("D"."STR1"='V')
  56 - access("D"."REFPIECE"="P"."REFPIECE" AND "D"."TYPE"='CONTRACT SITUATIONS')
  57 - filter(("PREV"."REFDOSS"="CURR"."REFDOSS" AND "PREV"."REFDOSS" IS NOT NULL))
*/
/********************************New Metrics***************************************/

/********************************Index statistics**********************************/

/********************************Other SQLs****************************************/          
/*

*/ 
/********************************Other SQLs****************************************/              
