/********************************************************************************
*********       E-mail subject: KBCCFDEV-5842
*********             Instance: NOTOVAL
*********          Description: 
Problem:
Client Output on pointed case have been running for 2.5h on NOTOVAL and has been killed.

Analysis:
After the analyze of module ftr_lst, we found that the TOP SQL in it was 1y1jasjmrwkfs. This query was responsible for 99% of the time of the module.
The problem in it is that instead to start the execution from the dfx_lst.GetListMemoDecompte(), it makes full scan of table G_ELEMFI in the first UNION and 
then HASH JOIN it with the other dataset. In the second UNION, it makes concatenation and separates the ORs into UNIONs. We added more hints to force the CBO not to do it 
and to start the execution from dfx_lst.GetListMemoDecompte().

Suggestion:
Please add hints as it is shown in the New SQL section below.

*********               SQL_ID: 1y1jasjmrwkfs
*********      Program/Package: 
*********              Request: Nikolay Nikolov
*********               Author: Dimitar Dimitrov
********* Received e-mail date: 02/09/2024
*********      Resolution date: 03/09/2024
*********  Trace old file here: \\epox\specifs\performance\tmp\
*********  Trace new file here:
***********************************************************************************/

/********************************OLD SQL*******************************************/

var b0 NUMBER;
exec :b0 := 2;
var b4 varchar2(32);
exec :b4 := '1601140004';
var b5 varchar2(32);
exec :b5 := 'A791Y1Q2';
var b6 varchar2(32);
exec :b6 := 'C';
var b7 varchar2(32);
exec :b7 := '08/2024';
var b8 NUMBER;
exec :b8 := 1;
var b9 varchar2(32);
exec :b9 := '';
var b10 NUMBER;
exec :b10 := null;
var b11 varchar2(32);
exec :b11 := 'A7995A2N';
var b12 varchar2(32);
exec :b12 := '';



SELECT CASE
         WHEN :b0 = 0 OR :b0 = 2 THEN
          T . dtinter
         else
          NULL
       END,
       CASE
         WHEN :b0 = 1 OR :b0 = 2 THEN
          T . dtjour
         else
          NULL
       END,
       sum(T . mnt),
       T . motif,
       T . refdossDb,
       T . so_mov
  FROM ( SELECT /*+ LEADING(a TE fi fi2 p) INDEX(TE T_ECRDOS$ORIG_REFLOT) USE_NL(TE) +*/
                trunc(te . dtjour_dt) dtinter,
                trunc(te . dtjour_dt) dtjour,
                te.mnt_dcpt mnt,
                CASE
                  WHEN fi.type IN ('WRITE OFF', 'WRITE OFF CN') THEN
                   2
                  ELSE
                   DECODE(SIGN(NVL(Fi . dtannul, 0)),
                          1,
                          case
                            WHEN fi.type in ('RETROCESSION', 'RETROCESSION NC') and te.CODECR = 'PRIN' THEN
                             0
                            ELSE
                             2
                          END,
                          DECODE(v.abrev,
                                 'RDP',
                                 1,
                                 DECODE(fi.libelle_20_6, 'RDP', 1, 0)))
                END motif,
                te.refdoss refdossDb,
                0 so_mov,
                fi2.refelem ret_reflem,
                fi2.type ret_type
          FROM g_elemfi fi,
               g_elemfi fi2,
               g_piece p,
               v_domaine v,
               t_ecrdos TE,
               (TABLE(dfx_lst.GetListMemoDecompte( :b4,
                                                   :b5,
                                                   :b6,
                                                   :b7,
                                                   :b8,
                                                   :b9,
                                                   :b10,
                                                   :b11,
                                                   :b12 ) ) ) a
         WHERE te.orig_reflot = a.column_value
           AND 0 != ( SELECT NVL(SUM(t2 . mnt_dcpt), -1)
                        FROM t_ecrdos t2
                       WHERE t2.refelem = te.refelem
                         AND t2.refdoss = te.refdoss
                         AND t2.orig_reflot = te.orig_reflot
                         AND (  (    te.codecr IN ('AENAT', 'ENCAT') 
                                 AND t2.codecr IN ('AENAT', 'ENCAT') ) 
                             OR (    te.codecr IN ('ARFIN', 'RFIN') 
                                 AND t2.codecr IN ('ARFIN', 'RFIN') ) 
                             OR (    te.codecr IN ('ADPRI', 'DPRIN') 
                                 AND t2.codecr IN ('ADPRI', 'DPRIN') ) 
                             OR (    te.codecr IN ('ACVFI', 'CVFIN') 
                                 AND t2.codecr IN ('ACVFI', 'CVFIN') )
                             OR (    te.codecr NOT IN ( 'AENAT',
                                                        'ENCAT',
                                                        'ARFIN',
                                                        'RFIN',
                                                        'ADPRI',
                                                        'DPRIN',
                                                        'ACVFI',
                                                        'CVFIN' )
                                 AND t2.codecr = te.codecr ) )
                   AND ( ( t2.codecr IN ('DPRIN', 'ADPRI') AND
                        ((t2 . codecr = 'DPRIN' AND NVL(t2 . mnt_dcpt, 0) < 0) OR
                        (t2 . codecr = 'ADPRI' AND NVL(t2 . mnt_dcpt, 0) > 0))) OR t2 .
                        codecr NOT IN ('DPRIN', 'ADPRI'))
                     AND NVL(t2 . mnt_dcpt, 0) != 0)
           AND ( (    te.codecr LIKE 'A%' 
                  AND te.codecr != 'ADPRI' 
                  AND NVL(v.type, 'XXX') != 'MOTIF_RETROCESSION' )
              OR  NVL(v.type, 'XXX') = 'MOTIF_RETROCESSION' 
               OR fi.libelle_20_6 = 'RDP' 
               OR ( ( (    codecr = 'PRIN' 
                       AND SIGN(te.mnt_dcpt) != -1 ) 
                   OR (    codecr = 'APRIN' 
                       AND SIGN(te.mnt_dcpt) = -1) ) 
                 AND fi.Type IN ( 'RETROCESSION', 'RETROCESSION NC' ) )
               OR (    fi.type in ('RETROCESSION', 'RETROCESSION NC') 
                   and te.CODECR = 'PRIN' 
                   and fi.dtannul IS NOT NULL 
                   AND p.st20 IS NULL )
               OR fi.type IN ('WRITE OFF', 'WRITE OFF CN') )
           AND fi.refelem = TE.refelem
           AND fi.refdoss IN ( SELECT g.refdoss
                                 FROM g_dossier g
                                WHERE g.reflot = :b4
                                  AND g.categdoss LIKE 'COMPTE%' )
           AND (     fi.type like 'RETROCESSION%' 
                OR (    fi.dtannul IS NOT NULL 
                	  AND fi.type NOT IN ('SALES ORDER', 'SO INVOICED') ) 
                OR (    fi.type = 'FACTURE' 
                    AND fi.libelle LIKE 'RETROCESSION%' )
                OR fi.type IN ('WRITE OFF', 'WRITE OFF CN') )
           AND fi2.refelem(+) = fi.ref_creance
           AND p.refpiece(+) = fi2.refpiece2
           AND p.typpiece(+) = 'FACTURE'
           AND v.type(+) = 'MOTIF_RETROCESSION'
           AND v.abrev(+) = p.st20
        union ALL
        SELECT /*+LEADING(a TE fi fi2 p) INDEX(TE T_ECRDOS$ORIG_REFLOT) USE_NL(TE)+*/
         trunc(te . dtjour_dt) dtinter,
         trunc(te . dtjour_dt) dtjour,
         te . mnt_dcpt mnt,
         DECODE(SIGN(NVL(Fi . dtannul, 0)),
                1,
                2,
                DECODE(v . abrev,
                       'RDP',
                       1,
                       DECODE(fi . libelle_20_6, 'RDP', 1, 0))) motif,
         te . refdoss refdossDb,
         1 so_mov,
         fi2 . refelem ret_reflem,
         fi2 . type ret_type
          FROM g_elemfi fi,
               g_elemfi fi2,
               g_piece p,
               v_domaine v,
               t_ecrdos TE,
               (TABLE(dfx_lst.GetListMemoDecompte( :b4,
                                                   :b5,
                                                   :b6,
                                                   :b7,
                                                   :b8,
                                                   :b9,
                                                   :b10,
                                                   :b11,
                                                   :b12 ) ) ) a
         WHERE te.orig_reflot = a.column_value
           AND 0 !=
               (SELECT NVL(SUM(t2 . mnt_dcpt), -1)
                  FROM t_ecrdos t2
                 WHERE t2.refelem = te.refelem
                   AND t2.refdoss = te.refdoss
                   AND t2.orig_reflot = te.orig_reflot
                   AND ((te . codecr IN ('AENAT', 'ENCAT') AND t2 .
                        codecr IN ('AENAT', 'ENCAT')) OR
                       (te . codecr IN ('ARFIN', 'RFIN') AND t2 .
                        codecr IN ('ARFIN', 'RFIN')) OR
                       (te . codecr IN ('ADPRI', 'DPRIN') AND t2 .
                        codecr IN ('ADPRI', 'DPRIN')) OR
                       (te . codecr IN ('ACVFI', 'CVFIN') AND t2 .
                        codecr IN ('ACVFI', 'CVFIN')) OR
                       (te . codecr NOT IN ('AENAT',
                                             'ENCAT',
                                             'ARFIN',
                                             'RFIN',
                                             'ADPRI',
                                             'DPRIN',
                                             'ACVFI',
                                             'CVFIN') AND t2 . codecr = te .
                        codecr))
                   AND ((t2 .
                        codecr IN ('DPRIN', 'ADPRI') AND
                        ((t2 . codecr = 'DPRIN' AND NVL(t2 . mnt_dcpt, 0) < 0) OR
                        (t2 . codecr = 'ADPRI' AND NVL(t2 . mnt_dcpt, 0) > 0))) OR t2 .
                        codecr NOT IN ('DPRIN', 'ADPRI'))
                   AND NVL(t2 . mnt_dcpt, 0) != 0)
           AND ( (    te.codecr LIKE 'A%' 
                  AND te.codecr != 'ADPRI' 
                  AND NVL(v.type, 'XXX') != 'MOTIF_RETROCESSION' ) 
               OR NVL(v.type, 'XXX') = 'MOTIF_RETROCESSION' 
               OR fi.libelle_20_6 = 'RDP'
               OR ( ( (    codecr = 'PRIN' 
                       AND SIGN(te . mnt_dcpt) != -1 ) 
                   OR (    codecr = 'APRIN' 
                       AND SIGN(te . mnt_dcpt ) = -1 ) )
                 AND fi.Type IN ('RETROCESSION', 'RETROCESSION NC') ) )
           AND fi.refelem = TE.refelem
           AND (     fi.type like 'RETROCESSION%'
                OR (    fi.dtannul IS NOT NULL 
                  	AND fi.type IN ( 'SALES ORDER', 'SO INVOICED' ) )
                OR (    fi.type IN ( 'SALES ORDER', 'SO INVOICED' ) 
                    AND fi.libelle LIKE 'RETROCESSION%' ) )
           AND fi2.refelem(+) = fi.ref_creance
           AND p.refpiece(+) = fi2.refpiece2
           AND p.typpiece(+) = 'FACTURE'
           AND v.type(+) = 'MOTIF_RETROCESSION'
           AND v.abrev(+) = p.st20 ) T
 WHERE (T . ret_reflem IS NULL OR
        (T . ret_reflem IS NOT NULL AND
         ((T . so_mov = 0 AND T .
          ret_type NOT IN ('SALES ORDER', 'SO INVOICED')) OR
         (T . so_mov = 1 AND T .
          ret_type IN ('SALES ORDER', 'SO INVOICED')))))
 GROUP BY T . motif,
          CASE
            WHEN :b0 = 0 OR :b0 = 2 THEN
             T . dtinter
            else
             NULL
          END,
          CASE
            WHEN :b0 = 1 OR :b0 = 2 THEN
             T . dtjour
            else
             NULL
          END,
          t . refdossDb,
          T . so_mov
 ORDER BY T . motif,
          CASE
            WHEN :b0 = 0 OR :b0 = 2 THEN
             T . dtinter
            else
             NULL
          END,
          CASE
            WHEN :b0 = 1 OR :b0 = 2 THEN
             T . dtjour
            else
             NULL
          END;
/********************************OLD SQL*******************************************/
/********************************OLD Metrics***************************************/
/*

MODULE                           PROGRAM                                            CLIENT_ID       SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- -------------------------------------------------- --------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
ftr_lst                          ftr_lst                                                                                           1173      22884 db file sequential r 2024/09/01 01:38:04  2024/09/01 03:54:46        702                     1 +000000000 02:16:42.240 34%
msgq_calfidec                    msg_q02                                                                                             22      57571 ON CPU               2024/09/01 01:25:06  2024/09/01 02:52:59        353              13106632 +000000000 01:27:53.728 17%
                                 oracle                                                                                    0       1139      63872 log file parallel wr 2024/09/01 01:26:17  2024/09/01 04:09:48        149                       +000000000 02:43:30.180 7%
msgq_calfidec                    msg_q02                                                                                             22      57571 db file sequential r 2024/09/01 01:25:26  2024/09/01 02:52:19        145               2907136 +000000000 01:26:52.287 7%
imxbatch_Consolidation           imxbatch                                                                                                          db file sequential r 2024/09/01 01:25:06  2024/09/01 01:32:06         99                124276 +000000000 00:06:59.840 5%
                                                                                                                           0                       ON CPU               2024/09/01 01:27:50  2024/09/01 04:09:37         69                       +000000000 02:41:47.776 3%
envoi_sp                         envoi_sp                                                           c1gszng5dj7zk  990292786                       db file sequential r 2024/09/01 01:26:38  2024/09/01 04:08:26         69                    90 +000000000 02:41:47.776 3%
ftr_lst                          ftr_lst                                                                                                           db file parallel rea 2024/09/01 01:33:48  2024/09/01 03:54:57         62                   221 +000000000 02:21:08.544 3%
ftr_lst                          ftr_lst                                                                                                           ON CPU               2024/09/01 01:36:22  2024/09/01 03:52:33         41                   210 +000000000 02:16:11.584 2%
imxbatch_Syndication             imxbatch                                                                                                          db file sequential r 2024/09/01 01:33:17  2024/09/01 01:36:11         31                410214 +000000000 00:02:54.080 2%
imxbatch_Consolidation           imxbatch                                                                                                          db file parallel rea 2024/09/01 01:25:06  2024/09/01 01:32:16         30                117578 +000000000 00:07:10.080 1%
SQL*Plus                         sqlplus                                            unknown                                                        ON CPU               2024/09/01 01:33:28  2024/09/01 04:06:02         22               1292946 +000000000 02:32:34.748 1%
SQL*Plus                         sqlplus                                            unknown                                          25            db file sequential r 2024/09/01 04:01:36  2024/09/01 04:06:54         20                     1 +000000000 00:05:17.508 1%
                                 oracle                                                                                    0        856      27903 db file async I/O su 2024/09/01 01:25:47  2024/09/01 04:05:11         17                       +000000000 02:39:24.417 1%
msgq_calfidec                    msg_q02                                                            ckccypag67ffu 2650742522         22      57571 db file parallel rea 2024/09/01 01:27:50  2024/09/01 02:41:54         17                    21 +000000000 01:14:04.293 1%
msgq                                                                                                033pp0ww4q9yp 1577963609                       ON CPU               2024/09/01 01:27:29  2024/09/01 03:13:39         15                  1359 +000000000 01:46:09.410 1%
stats_create                                                                        unknown                                                        direct path read     2024/09/01 04:07:24  2024/09/01 04:09:27         15               1100044 +000000000 00:02:02.879 1%
ftr_batch_FTR_BATCH_OLDPORTFOLIO ftr_batch                                                          0vcszghgtsj11 3632390689       1176      15858 db file sequential r 2024/09/01 01:25:06  2024/09/01 01:27:19         14                     1 +000000000 00:02:13.121 1%




MODULE                           PROGRAM                                            CLIENT_ID       SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- -------------------------------------------------- --------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
ftr_lst                          ftr_lst                                                                                                                                2024/09/01 01:33:17  2024/09/01 03:54:57        814                   221 +000000000 02:21:39.264 100%



MODULE                           PROGRAM                                            CLIENT_ID       SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- -------------------------------------------------- --------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
ftr_lst                          ftr_lst                                                                                           1173      22884 db file sequential r 2024/09/01 01:38:04  2024/09/01 03:54:46        702                     1 +000000000 02:16:42.240 86%
ftr_lst                          ftr_lst                                                                                                           db file parallel rea 2024/09/01 01:33:48  2024/09/01 03:54:57         62                   221 +000000000 02:21:08.544 8%
ftr_lst                          ftr_lst                                                                                                           ON CPU               2024/09/01 01:36:22  2024/09/01 03:52:33         41                   210 +000000000 02:16:11.584 5%
ftr_lst                          ftr_lst                                                            1y1jasjmrwkfs  832146739       1173      22884 db file scattered re 2024/09/01 01:53:05  2024/09/01 03:36:31          5                     1 +000000000 01:43:25.439 1%
ftr_lst                          ftr_lst                                                                                   0                       log file sync        2024/09/01 01:33:17  2024/09/01 01:35:00          2                       +000000000 00:01:42.400 0%
ftr_lst                          ftr_lst                                                            1y1jasjmrwkfs  832146739       1173      22884 direct path read     2024/09/01 01:38:14  2024/09/01 01:38:25          2                     1 +000000000 00:00:10.242 0%




MODULE                           PROGRAM                                            CLIENT_ID       SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- -------------------------------------------------- --------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
ftr_lst                          ftr_lst                                                            1y1jasjmrwkfs  832146739       1173      22884                      2024/09/01 01:38:14  2024/09/01 03:54:57        802                     1 +000000000 02:16:42.238 99%
ftr_lst                          ftr_lst                                                            9sft7zb41zrdq 3862897561                                            2024/09/01 01:33:48  2024/09/01 01:36:32          7                   221 +000000000 00:02:43.841 1%
ftr_lst                          ftr_lst                                                                                   0                       log file sync        2024/09/01 01:33:17  2024/09/01 01:35:00          2                       +000000000 00:01:42.400 0%
ftr_lst                          ftr_lst                                                            76h70vsu34793 1208812917          5            db file parallel rea 2024/09/01 01:35:10  2024/09/01 01:36:11          2                    37 +000000000 00:01:01.439 0%
ftr_lst                          ftr_lst                                                            52z1suuq0vjbf 2458476382       1173      22884 db file sequential r 2024/09/01 01:38:04  2024/09/01 01:38:04          1                     1 +000000000 00:00:00.000 0%




SQL_ID        SQL_PLAN_HASH_VALUE SQL_PLAN_LINE_ID SQL_PLAN_OPERATION             SQL_PLAN_OPTIONS                   ACTIVE
------------- ------------------- ---------------- ------------------------------ ------------------------------ ----------
1y1jasjmrwkfs           832146739              181 TABLE ACCESS                   BY INDEX ROWID                        781
1y1jasjmrwkfs           832146739              180 INDEX                          FULL SCAN                              13
1y1jasjmrwkfs           832146739              166 NESTED LOOPS                                                           3
1y1jasjmrwkfs           832146739              167 NESTED LOOPS                                                           2
1y1jasjmrwkfs           832146739               13 TABLE ACCESS                   FULL                                    2
1y1jasjmrwkfs           832146739               57 TABLE ACCESS                   BY INDEX ROWID BATCHED                  1



INSTANCE_NUMBER SQL_ID            ELAPSED MAX_WAIT_ON     PC_OF  WAIT_TIME            GETS      READS       ROWS  ELAP/EXEC       GETS/EXEC READS/EXEC  ROWS/EXEC       EXEC PLAN_HASH_VALUE
--------------- ------------- ----------- --------------- ----- ---------- --------------- ---------- ---------- ---------- --------------- ---------- ---------- ---------- ---------------
              1 1y1jasjmrwkfs        8215 IO              91%   8433.26656        40918004    8865843          0    8214.53        40918004    8865843          0          1       832146739



Plan hash value: 832146739
---------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                         | Name                      | Rows  | Bytes |TempSpc| Cost (%CPU)| Time     |
---------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                                  |                           |       |       |       | 56905 (100)|          |
|   1 |  SORT GROUP BY                                    |                           |     9 |  1512 |       | 56905   (1)| 00:00:03 |
|   2 |   VIEW                                            |                           |     9 |  1512 |       | 56904   (1)| 00:00:03 |
|   3 |    UNION-ALL                                      |                           |       |       |       |            |          |
|*  4 |     FILTER                                        |                           |       |       |       |            |          |
|*  5 |      FILTER                                       |                           |       |       |       |            |          |
|   6 |       NESTED LOOPS OUTER                          |                           |    19 |  3439 |       | 45729   (1)| 00:00:02 |
|*  7 |        HASH JOIN                                  |                           |    19 |  3097 |       | 45728   (1)| 00:00:02 |
|*  8 |         INDEX RANGE SCAN                          | G_DOSSIER_RL_CD_RD_RF_IDX |     5 |   150 |       |     1   (0)| 00:00:01 |
|   9 |         NESTED LOOPS OUTER                        |                           |   177K|    22M|       | 45726   (1)| 00:00:02 |
|* 10 |          FILTER                                   |                           |       |       |       |            |          |
|  11 |           NESTED LOOPS OUTER                      |                           |   177K|    18M|       | 40489   (1)| 00:00:02 |
|* 12 |            HASH JOIN                              |                           |   177K|    13M|  4184K| 36937   (1)| 00:00:02 |
|* 13 |             TABLE ACCESS FULL                     | G_ELEMFI                  | 89123 |  3133K|       | 22073   (1)| 00:00:01 |
|  14 |             NESTED LOOPS                          |                           |  4730K|   198M|       |  2070   (1)| 00:00:01 |
|  15 |              NESTED LOOPS                         |                           |  4730K|   198M|       |  2070   (1)| 00:00:01 |
|  16 |               COLLECTION ITERATOR PICKLER FETCH   | GETLISTMEMODECOMPTE       |  8168 | 16336 |       |    24   (0)| 00:00:01 |
|* 17 |               INDEX RANGE SCAN                    | T_ECRDOS$ORIG_REFLOT      |   353 |       |       |     1   (0)| 00:00:01 |
|  18 |              TABLE ACCESS BY INDEX ROWID          | T_ECRDOS                  |   579 | 24318 |       |     1   (0)| 00:00:01 |
|  19 |            TABLE ACCESS BY INDEX ROWID            | G_ELEMFI                  |     1 |    28 |       |     1   (0)| 00:00:01 |
|* 20 |             INDEX UNIQUE SCAN                     | EFI_REFELEM               |     1 |       |       |     1   (0)| 00:00:01 |
|* 21 |          TABLE ACCESS BY INDEX ROWID BATCHED      | G_PIECE                   |     1 |    25 |       |     1   (0)| 00:00:01 |
|* 22 |           INDEX RANGE SCAN                        | PIE_REFPIECE              |     1 |       |       |     1   (0)| 00:00:01 |
|* 23 |        INDEX RANGE SCAN                           | DOM_TYPABREV              |     1 |    18 |       |     1   (0)| 00:00:01 |
|  24 |      SORT AGGREGATE                               |                           |     1 |    34 |       |            |          |
|* 25 |       TABLE ACCESS BY INDEX ROWID BATCHED         | T_ECRDOS                  |     1 |    34 |       |     1   (0)| 00:00:01 |
|* 26 |        INDEX RANGE SCAN                           | TECR_REFELEM              |     1 |       |       |     1   (0)| 00:00:01 |
|  27 |     CONCATENATION                                 |                           |       |       |       |            |          |
|* 28 |      FILTER                                       |                           |       |       |       |            |          |
|* 29 |       HASH JOIN RIGHT OUTER                       |                           |  1213 |   168K|       |  2155   (1)| 00:00:01 |
|* 30 |        INDEX RANGE SCAN                           | DOM_TYPABREV              |    41 |   738 |       |     1   (0)| 00:00:01 |
|  31 |        NESTED LOOPS OUTER                         |                           |  1213 |   146K|       |  2154   (1)| 00:00:01 |
|* 32 |         FILTER                                    |                           |       |       |       |            |          |
|  33 |          NESTED LOOPS OUTER                       |                           |  1213 |   117K|       |  2118   (1)| 00:00:01 |
|  34 |           NESTED LOOPS                            |                           |  1213 | 86123 |       |  2094   (1)| 00:00:01 |
|  35 |            NESTED LOOPS                           |                           |  1213 | 53372 |       |  2070   (1)| 00:00:01 |
|  36 |             COLLECTION ITERATOR PICKLER FETCH     | GETLISTMEMODECOMPTE       |  8168 | 16336 |       |    24   (0)| 00:00:01 |
|* 37 |             TABLE ACCESS BY INDEX ROWID BATCHED   | T_ECRDOS                  |     1 |    42 |       |     1   (0)| 00:00:01 |
|* 38 |              INDEX RANGE SCAN                     | T_ECRDOS$ORIG_REFLOT      |   353 |       |       |     1   (0)| 00:00:01 |
|* 39 |            TABLE ACCESS BY INDEX ROWID            | G_ELEMFI                  |     1 |    27 |       |     1   (0)| 00:00:01 |
|* 40 |             INDEX UNIQUE SCAN                     | EFI_REFELEM               |     1 |       |       |     1   (0)| 00:00:01 |
|  41 |           TABLE ACCESS BY INDEX ROWID             | G_ELEMFI                  |     1 |    28 |       |     1   (0)| 00:00:01 |
|* 42 |            INDEX UNIQUE SCAN                      | EFI_REFELEM               |     1 |       |       |     1   (0)| 00:00:01 |
|* 43 |         TABLE ACCESS BY INDEX ROWID BATCHED       | G_PIECE                   |     1 |    25 |       |     1   (0)| 00:00:01 |
|* 44 |          INDEX RANGE SCAN                         | PIE_REFPIECE              |     1 |       |       |     1   (0)| 00:00:01 |
|  45 |       SORT AGGREGATE                              |                           |     1 |    34 |       |            |          |
|* 46 |        TABLE ACCESS BY INDEX ROWID BATCHED        | T_ECRDOS                  |     1 |    34 |       |     1   (0)| 00:00:01 |
|* 47 |         INDEX RANGE SCAN                          | TECR_REFELEM              |     1 |       |       |     1   (0)| 00:00:01 |
|* 48 |      FILTER                                       |                           |       |       |       |            |          |
|  49 |       NESTED LOOPS                                |                           |     1 |   142 |       |    81   (0)| 00:00:01 |
|  50 |        NESTED LOOPS                               |                           |   353 |   142 |       |    81   (0)| 00:00:01 |
|  51 |         MERGE JOIN CARTESIAN                      |                           |     1 |   100 |       |    80   (0)| 00:00:01 |
|  52 |          NESTED LOOPS OUTER                       |                           |     1 |    98 |       |    56   (0)| 00:00:01 |
|  53 |           NESTED LOOPS OUTER                      |                           |     1 |    80 |       |    55   (0)| 00:00:01 |
|* 54 |            FILTER                                 |                           |       |       |       |            |          |
|  55 |             NESTED LOOPS OUTER                    |                           |     1 |    55 |       |    54   (0)| 00:00:01 |
|  56 |              INLIST ITERATOR                      |                           |       |       |       |            |          |
|* 57 |               TABLE ACCESS BY INDEX ROWID BATCHED | G_ELEMFI                  |     1 |    27 |       |    53   (0)| 00:00:01 |
|* 58 |                INDEX RANGE SCAN                   | IDX_FFSI_G_ELEMFI         | 84552 |       |       |     2   (0)| 00:00:01 |
|  59 |              TABLE ACCESS BY INDEX ROWID          | G_ELEMFI                  |     1 |    28 |       |     1   (0)| 00:00:01 |
|* 60 |               INDEX UNIQUE SCAN                   | EFI_REFELEM               |     1 |       |       |     1   (0)| 00:00:01 |
|* 61 |            TABLE ACCESS BY INDEX ROWID BATCHED    | G_PIECE                   |     1 |    25 |       |     1   (0)| 00:00:01 |
|* 62 |             INDEX RANGE SCAN                      | PIE_REFPIECE              |     1 |       |       |     1   (0)| 00:00:01 |
|* 63 |           INDEX RANGE SCAN                        | DOM_TYPABREV              |     1 |    18 |       |     1   (0)| 00:00:01 |
|  64 |          BUFFER SORT                              |                           |  8168 | 16336 |       |    79   (0)| 00:00:01 |
|  65 |           COLLECTION ITERATOR PICKLER FETCH       | GETLISTMEMODECOMPTE       |  8168 | 16336 |       |    24   (0)| 00:00:01 |
|* 66 |         INDEX RANGE SCAN                          | T_ECRDOS$ORIG_REFLOT      |   353 |       |       |     1   (0)| 00:00:01 |
|* 67 |        TABLE ACCESS BY INDEX ROWID                | T_ECRDOS                  |     1 |    42 |       |     1   (0)| 00:00:01 |
|  68 |       SORT AGGREGATE                              |                           |     1 |    34 |       |            |          |
|* 69 |        TABLE ACCESS BY INDEX ROWID BATCHED        | T_ECRDOS                  |     1 |    34 |       |     1   (0)| 00:00:01 |
|* 70 |         INDEX RANGE SCAN                          | TECR_REFELEM              |     1 |       |       |     1   (0)| 00:00:01 |
|* 71 |      FILTER                                       |                           |       |       |       |            |          |
|  72 |       NESTED LOOPS                                |                           |     1 |   142 |       |    81   (0)| 00:00:01 |
|  73 |        NESTED LOOPS                               |                           |   353 |   142 |       |    81   (0)| 00:00:01 |
|  74 |         MERGE JOIN CARTESIAN                      |                           |     1 |   100 |       |    80   (0)| 00:00:01 |
|  75 |          NESTED LOOPS OUTER                       |                           |     1 |    98 |       |    56   (0)| 00:00:01 |
|  76 |           NESTED LOOPS OUTER                      |                           |     1 |    80 |       |    55   (0)| 00:00:01 |
|* 77 |            FILTER                                 |                           |       |       |       |            |          |
|  78 |             NESTED LOOPS OUTER                    |                           |     1 |    55 |       |    54   (0)| 00:00:01 |
|  79 |              INLIST ITERATOR                      |                           |       |       |       |            |          |
|* 80 |               TABLE ACCESS BY INDEX ROWID BATCHED | G_ELEMFI                  |     1 |    27 |       |    53   (0)| 00:00:01 |
|* 81 |                INDEX RANGE SCAN                   | IDX_FFSI_G_ELEMFI         | 84552 |       |       |     2   (0)| 00:00:01 |
|  82 |              TABLE ACCESS BY INDEX ROWID          | G_ELEMFI                  |     1 |    28 |       |     1   (0)| 00:00:01 |
|* 83 |               INDEX UNIQUE SCAN                   | EFI_REFELEM               |     1 |       |       |     1   (0)| 00:00:01 |
|* 84 |            TABLE ACCESS BY INDEX ROWID BATCHED    | G_PIECE                   |     1 |    25 |       |     1   (0)| 00:00:01 |
|* 85 |             INDEX RANGE SCAN                      | PIE_REFPIECE              |     1 |       |       |     1   (0)| 00:00:01 |
|* 86 |           INDEX RANGE SCAN                        | DOM_TYPABREV              |     1 |    18 |       |     1   (0)| 00:00:01 |
|  87 |          BUFFER SORT                              |                           |  8168 | 16336 |       |    79   (0)| 00:00:01 |
|  88 |           COLLECTION ITERATOR PICKLER FETCH       | GETLISTMEMODECOMPTE       |  8168 | 16336 |       |    24   (0)| 00:00:01 |
|* 89 |         INDEX RANGE SCAN                          | T_ECRDOS$ORIG_REFLOT      |   353 |       |       |     1   (0)| 00:00:01 |
|* 90 |        TABLE ACCESS BY INDEX ROWID                | T_ECRDOS                  |     1 |    42 |       |     1   (0)| 00:00:01 |
|  91 |       SORT AGGREGATE                              |                           |     1 |    34 |       |            |          |
|* 92 |        TABLE ACCESS BY INDEX ROWID BATCHED        | T_ECRDOS                  |     1 |    34 |       |     1   (0)| 00:00:01 |
|* 93 |         INDEX RANGE SCAN                          | TECR_REFELEM              |     1 |       |       |     1   (0)| 00:00:01 |
|* 94 |      FILTER                                       |                           |       |       |       |            |          |
|  95 |       NESTED LOOPS                                |                           |     1 |   142 |       |    60   (0)| 00:00:01 |
|  96 |        NESTED LOOPS                               |                           |  8472 |   142 |       |    60   (0)| 00:00:01 |
|  97 |         MERGE JOIN CARTESIAN                      |                           |    24 |  2400 |       |    54   (0)| 00:00:01 |
|  98 |          NESTED LOOPS OUTER                       |                           |     1 |    98 |       |    30   (0)| 00:00:01 |
|  99 |           NESTED LOOPS OUTER                      |                           |     1 |    80 |       |    29   (0)| 00:00:01 |
|*100 |            FILTER                                 |                           |       |       |       |            |          |
| 101 |             NESTED LOOPS OUTER                    |                           |     1 |    55 |       |    28   (0)| 00:00:01 |
|*102 |              TABLE ACCESS BY INDEX ROWID BATCHED  | G_ELEMFI                  |     1 |    27 |       |    27   (0)| 00:00:01 |
|*103 |               INDEX RANGE SCAN                    | IDX_FFSI_G_ELEMFI         | 42276 |       |       |     1   (0)| 00:00:01 |
| 104 |              TABLE ACCESS BY INDEX ROWID          | G_ELEMFI                  |     1 |    28 |       |     1   (0)| 00:00:01 |
|*105 |               INDEX UNIQUE SCAN                   | EFI_REFELEM               |     1 |       |       |     1   (0)| 00:00:01 |
|*106 |            TABLE ACCESS BY INDEX ROWID BATCHED    | G_PIECE                   |     1 |    25 |       |     1   (0)| 00:00:01 |
|*107 |             INDEX RANGE SCAN                      | PIE_REFPIECE              |     1 |       |       |     1   (0)| 00:00:01 |
|*108 |           INDEX RANGE SCAN                        | DOM_TYPABREV              |     1 |    18 |       |     1   (0)| 00:00:01 |
| 109 |          BUFFER SORT                              |                           |  8168 | 16336 |       |    53   (0)| 00:00:01 |
| 110 |           COLLECTION ITERATOR PICKLER FETCH       | GETLISTMEMODECOMPTE       |  8168 | 16336 |       |    24   (0)| 00:00:01 |
|*111 |         INDEX RANGE SCAN                          | T_ECRDOS$ORIG_REFLOT      |   353 |       |       |     1   (0)| 00:00:01 |
|*112 |        TABLE ACCESS BY INDEX ROWID                | T_ECRDOS                  |     1 |    42 |       |     1   (0)| 00:00:01 |
| 113 |       SORT AGGREGATE                              |                           |     1 |    34 |       |            |          |
|*114 |        TABLE ACCESS BY INDEX ROWID BATCHED        | T_ECRDOS                  |     1 |    34 |       |     1   (0)| 00:00:01 |
|*115 |         INDEX RANGE SCAN                          | TECR_REFELEM              |     1 |       |       |     1   (0)| 00:00:01 |
|*116 |      FILTER                                       |                           |       |       |       |            |          |
| 117 |       NESTED LOOPS                                |                           |     1 |   142 |       |    81   (0)| 00:00:01 |
| 118 |        NESTED LOOPS                               |                           |  1412 |   142 |       |    81   (0)| 00:00:01 |
| 119 |         MERGE JOIN CARTESIAN                      |                           |     4 |   400 |       |    80   (0)| 00:00:01 |
|*120 |          FILTER                                   |                           |       |       |       |            |          |
| 121 |           NESTED LOOPS OUTER                      |                           |     1 |    98 |       |    56   (0)| 00:00:01 |
| 122 |            NESTED LOOPS OUTER                     |                           |     1 |    80 |       |    55   (0)| 00:00:01 |
|*123 |             FILTER                                |                           |       |       |       |            |          |
| 124 |              NESTED LOOPS OUTER                   |                           |     1 |    55 |       |    54   (0)| 00:00:01 |
| 125 |               INLIST ITERATOR                     |                           |       |       |       |            |          |
|*126 |                TABLE ACCESS BY INDEX ROWID BATCHED| G_ELEMFI                  |     9 |   243 |       |    53   (0)| 00:00:01 |
|*127 |                 INDEX RANGE SCAN                  | IDX_FFSI_G_ELEMFI         | 84552 |       |       |     2   (0)| 00:00:01 |
| 128 |               TABLE ACCESS BY INDEX ROWID         | G_ELEMFI                  |     1 |    28 |       |     1   (0)| 00:00:01 |
|*129 |                INDEX UNIQUE SCAN                  | EFI_REFELEM               |     1 |       |       |     1   (0)| 00:00:01 |
|*130 |             TABLE ACCESS BY INDEX ROWID BATCHED   | G_PIECE                   |     1 |    25 |       |     1   (0)| 00:00:01 |
|*131 |              INDEX RANGE SCAN                     | PIE_REFPIECE              |     1 |       |       |     1   (0)| 00:00:01 |
|*132 |            INDEX RANGE SCAN                       | DOM_TYPABREV              |     1 |    18 |       |     1   (0)| 00:00:01 |
| 133 |          BUFFER SORT                              |                           |  8168 | 16336 |       |    79   (0)| 00:00:01 |
| 134 |           COLLECTION ITERATOR PICKLER FETCH       | GETLISTMEMODECOMPTE       |  8168 | 16336 |       |    24   (0)| 00:00:01 |
|*135 |         INDEX RANGE SCAN                          | T_ECRDOS$ORIG_REFLOT      |   353 |       |       |     1   (0)| 00:00:01 |
|*136 |        TABLE ACCESS BY INDEX ROWID                | T_ECRDOS                  |     1 |    42 |       |     1   (0)| 00:00:01 |
| 137 |       SORT AGGREGATE                              |                           |     1 |    34 |       |            |          |
|*138 |        TABLE ACCESS BY INDEX ROWID BATCHED        | T_ECRDOS                  |     1 |    34 |       |     1   (0)| 00:00:01 |
|*139 |         INDEX RANGE SCAN                          | TECR_REFELEM              |     1 |       |       |     1   (0)| 00:00:01 |
|*140 |      FILTER                                       |                           |       |       |       |            |          |
| 141 |       NESTED LOOPS                                |                           |     1 |   142 |       |    82   (2)| 00:00:01 |
| 142 |        NESTED LOOPS                               |                           |  2118 |   142 |       |    82   (2)| 00:00:01 |
| 143 |         MERGE JOIN CARTESIAN                      |                           |     6 |   600 |       |    80   (0)| 00:00:01 |
|*144 |          FILTER                                   |                           |       |       |       |            |          |
| 145 |           NESTED LOOPS OUTER                      |                           |     1 |    98 |       |    56   (0)| 00:00:01 |
| 146 |            NESTED LOOPS OUTER                     |                           |     1 |    80 |       |    55   (0)| 00:00:01 |
|*147 |             FILTER                                |                           |       |       |       |            |          |
| 148 |              NESTED LOOPS OUTER                   |                           |     1 |    55 |       |    54   (0)| 00:00:01 |
| 149 |               INLIST ITERATOR                     |                           |       |       |       |            |          |
|*150 |                TABLE ACCESS BY INDEX ROWID BATCHED| G_ELEMFI                  |    13 |   351 |       |    53   (0)| 00:00:01 |
|*151 |                 INDEX RANGE SCAN                  | IDX_FFSI_G_ELEMFI         | 84552 |       |       |     2   (0)| 00:00:01 |
| 152 |               TABLE ACCESS BY INDEX ROWID         | G_ELEMFI                  |     1 |    28 |       |     1   (0)| 00:00:01 |
|*153 |                INDEX UNIQUE SCAN                  | EFI_REFELEM               |     1 |       |       |     1   (0)| 00:00:01 |
|*154 |             TABLE ACCESS BY INDEX ROWID BATCHED   | G_PIECE                   |     1 |    25 |       |     1   (0)| 00:00:01 |
|*155 |              INDEX RANGE SCAN                     | PIE_REFPIECE              |     1 |       |       |     1   (0)| 00:00:01 |
|*156 |            INDEX RANGE SCAN                       | DOM_TYPABREV              |     1 |    18 |       |     1   (0)| 00:00:01 |
| 157 |          BUFFER SORT                              |                           |  8168 | 16336 |       |    79   (0)| 00:00:01 |
| 158 |           COLLECTION ITERATOR PICKLER FETCH       | GETLISTMEMODECOMPTE       |  8168 | 16336 |       |    24   (0)| 00:00:01 |
|*159 |         INDEX RANGE SCAN                          | T_ECRDOS$ORIG_REFLOT      |   353 |       |       |     1   (0)| 00:00:01 |
|*160 |        TABLE ACCESS BY INDEX ROWID                | T_ECRDOS                  |     1 |    42 |       |     1   (0)| 00:00:01 |
| 161 |       SORT AGGREGATE                              |                           |     1 |    34 |       |            |          |
|*162 |        TABLE ACCESS BY INDEX ROWID BATCHED        | T_ECRDOS                  |     1 |    34 |       |     1   (0)| 00:00:01 |
|*163 |         INDEX RANGE SCAN                          | TECR_REFELEM              |     1 |       |       |     1   (0)| 00:00:01 |
|*164 |      FILTER                                       |                           |       |       |       |            |          |
|*165 |       HASH JOIN                                   |                           |     5 |   710 |       |  3323   (1)| 00:00:01 |
| 166 |        NESTED LOOPS                               |                           |     3 |   420 |       |  3299   (1)| 00:00:01 |
| 167 |         NESTED LOOPS                              |                           |  3504K|   420 |       |  3299   (1)| 00:00:01 |
|*168 |          FILTER                                   |                           |       |       |       |            |          |
|*169 |           HASH JOIN RIGHT OUTER                   |                           |     2 |   196 |       |   930   (1)| 00:00:01 |
|*170 |            INDEX RANGE SCAN                       | DOM_TYPABREV              |    41 |   738 |       |     1   (0)| 00:00:01 |
| 171 |            NESTED LOOPS OUTER                     |                           |  1921 |   150K|       |   929   (1)| 00:00:01 |
|*172 |             FILTER                                |                           |       |       |       |            |          |
| 173 |              NESTED LOOPS OUTER                   |                           |  1921 |   103K|       |   872   (0)| 00:00:01 |
|*174 |               TABLE ACCESS BY INDEX ROWID BATCHED | G_ELEMFI                  | 42264 |  1114K|       |    27   (0)| 00:00:01 |
|*175 |                INDEX RANGE SCAN                   | IDX_FFSI_G_ELEMFI         | 42276 |       |       |     1   (0)| 00:00:01 |
| 176 |               TABLE ACCESS BY INDEX ROWID         | G_ELEMFI                  |     1 |    28 |       |     1   (0)| 00:00:01 |
|*177 |                INDEX UNIQUE SCAN                  | EFI_REFELEM               |     1 |       |       |     1   (0)| 00:00:01 |
|*178 |             TABLE ACCESS BY INDEX ROWID BATCHED   | G_PIECE                   |     1 |    25 |       |     1   (0)| 00:00:01 |
|*179 |              INDEX RANGE SCAN                     | PIE_REFPIECE              |     1 |       |       |     1   (0)| 00:00:01 |
| 180 |          INDEX FULL SCAN                          | T_ECRDOS$ORIG_REFLOT      |  1752K|       |       |    46   (0)| 00:00:01 |
|*181 |         TABLE ACCESS BY INDEX ROWID               | T_ECRDOS                  |     1 |    42 |       |  1184   (1)| 00:00:01 |
| 182 |        COLLECTION ITERATOR PICKLER FETCH          | GETLISTMEMODECOMPTE       |  8168 | 16336 |       |    24   (0)| 00:00:01 |
| 183 |       SORT AGGREGATE                              |                           |     1 |    34 |       |            |          |
|*184 |        TABLE ACCESS BY INDEX ROWID BATCHED        | T_ECRDOS                  |     1 |    34 |       |     1   (0)| 00:00:01 |
|*185 |         INDEX RANGE SCAN                          | TECR_REFELEM              |     1 |       |       |     1   (0)| 00:00:01 |
|*186 |      FILTER                                       |                           |       |       |       |            |          |
|*187 |       HASH JOIN                                   |                           |  3177 |   440K|       |  3100   (2)| 00:00:01 |
| 188 |        COLLECTION ITERATOR PICKLER FETCH          | GETLISTMEMODECOMPTE       |  8168 | 16336 |       |    24   (0)| 00:00:01 |
|*189 |        FILTER                                     |                           |       |       |       |            |          |
|*190 |         HASH JOIN RIGHT OUTER                     |                           |  1930 |   263K|       |  3076   (2)| 00:00:01 |
|*191 |          INDEX RANGE SCAN                         | DOM_TYPABREV              |    41 |   738 |       |     1   (0)| 00:00:01 |
| 192 |          NESTED LOOPS OUTER                       |                           |  1930 |   229K|       |  3075   (2)| 00:00:01 |
|*193 |           FILTER                                  |                           |       |       |       |            |          |
| 194 |            NESTED LOOPS OUTER                     |                           |  1930 |   182K|       |  3018   (2)| 00:00:01 |
|*195 |             HASH JOIN                             |                           | 42455 |  2860K|  5352K|  2168   (3)| 00:00:01 |
|*196 |              TABLE ACCESS BY INDEX ROWID BATCHED  | T_ECRDOS                  |   101K|  4157K|       |  1184   (1)| 00:00:01 |
| 197 |               INDEX FULL SCAN                     | T_ECRDOS$ORIG_REFLOT      |  1752K|       |       |    46   (0)| 00:00:01 |
|*198 |              TABLE ACCESS BY INDEX ROWID BATCHED  | G_ELEMFI                  | 42297 |  1115K|       |   644   (8)| 00:00:01 |
| 199 |               BITMAP CONVERSION TO ROWIDS         |                           |       |       |       |            |          |
| 200 |                BITMAP OR                          |                           |       |       |       |            |          |
| 201 |                 BITMAP CONVERSION FROM ROWIDS     |                           |       |       |       |            |          |
| 202 |                  SORT ORDER BY                    |                           |       |       |   672K|            |          |
|*203 |                   INDEX RANGE SCAN                | IDX_FFSI_G_ELEMFI         |       |       |       |     1   (0)| 00:00:01 |
| 204 |                 BITMAP OR                         |                           |       |       |       |            |          |
| 205 |                  BITMAP CONVERSION FROM ROWIDS    |                           |       |       |       |            |          |
|*206 |                   INDEX RANGE SCAN                | IDX_FFSI_G_ELEMFI         |       |       |       |     1   (0)| 00:00:01 |
| 207 |                  BITMAP CONVERSION FROM ROWIDS    |                           |       |       |       |            |          |
|*208 |                   INDEX RANGE SCAN                | IDX_FFSI_G_ELEMFI         |       |       |       |     1   (0)| 00:00:01 |
| 209 |                 BITMAP OR                         |                           |       |       |       |            |          |
| 210 |                  BITMAP CONVERSION FROM ROWIDS    |                           |       |       |       |            |          |
|*211 |                   INDEX RANGE SCAN                | IDX_FFSI_G_ELEMFI         |       |       |       |     1   (0)| 00:00:01 |
| 212 |                  BITMAP CONVERSION FROM ROWIDS    |                           |       |       |       |            |          |
|*213 |                   INDEX RANGE SCAN                | IDX_FFSI_G_ELEMFI         |       |       |       |     1   (0)| 00:00:01 |
| 214 |             TABLE ACCESS BY INDEX ROWID           | G_ELEMFI                  |     1 |    28 |       |     1   (0)| 00:00:01 |
|*215 |              INDEX UNIQUE SCAN                    | EFI_REFELEM               |     1 |       |       |     1   (0)| 00:00:01 |
|*216 |           TABLE ACCESS BY INDEX ROWID BATCHED     | G_PIECE                   |     1 |    25 |       |     1   (0)| 00:00:01 |
|*217 |            INDEX RANGE SCAN                       | PIE_REFPIECE              |     1 |       |       |     1   (0)| 00:00:01 |
| 218 |       SORT AGGREGATE                              |                           |     1 |    34 |       |            |          |
|*219 |        TABLE ACCESS BY INDEX ROWID BATCHED        | T_ECRDOS                  |     1 |    34 |       |     1   (0)| 00:00:01 |
|*220 |         INDEX RANGE SCAN                          | TECR_REFELEM              |     1 |       |       |     1   (0)| 00:00:01 |
---------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   4 - filter(<>0)
   5 - filter((("TE"."CODECR" LIKE 'A%' AND "TE"."CODECR"<>'ADPRI' AND NVL("V"."TYPE",'XXX')<>'MOTIF_RETROCESSION') OR
              NVL("V"."TYPE",'XXX')='MOTIF_RETROCESSION' OR "FI"."LIBELLE_20_6"='RDP' OR ((("TE"."CODECR"='PRIN' AND
              SIGN("TE"."MNT_DCPT")<>(-1)) OR ("TE"."CODECR"='APRIN' AND SIGN("TE"."MNT_DCPT")=(-1))) AND INTERNAL_FUNCTION("FI"."TYPE")) OR
              (INTERNAL_FUNCTION("FI"."TYPE") AND "TE"."CODECR"='PRIN' AND "P"."ST20" IS NULL AND "FI"."DTANNUL" IS NOT NULL) OR
              INTERNAL_FUNCTION("FI"."TYPE")))
   7 - access("FI"."REFDOSS"="G"."REFDOSS")
   8 - access("G"."REFLOT"=:B4 AND "G"."CATEGDOSS" LIKE 'COMPTE%')
       filter("G"."CATEGDOSS" LIKE 'COMPTE%')
  10 - filter(("FI2"."REFELEM" IS NULL OR ("FI2"."REFELEM" IS NOT NULL AND "FI2"."TYPE"<>'SALES ORDER' AND "FI2"."TYPE"<>'SO
              INVOICED')))
  12 - access("FI"."REFELEM"="TE"."REFELEM")
  13 - filter(("FI"."REFDOSS" IS NOT NULL AND (INTERNAL_FUNCTION("FI"."TYPE") OR "FI"."TYPE" LIKE 'RETROCESSION%' OR
              ("FI"."DTANNUL" IS NOT NULL AND "FI"."TYPE"<>'SALES ORDER' AND "FI"."TYPE"<>'SO INVOICED') OR ("FI"."TYPE"='FACTURE' AND
              "FI"."LIBELLE" LIKE 'RETROCESSION%'))))
  17 - access("TE"."ORIG_REFLOT"=VALUE(KOKBF$))
  20 - access("FI2"."REFELEM"="FI"."REF_CREANCE")
  21 - filter("P"."TYPPIECE"='FACTURE')
  22 - access("P"."REFPIECE"="FI2"."REFPIECE2")
  23 - access("V"."TYPE"='MOTIF_RETROCESSION' AND "V"."ABREV"="P"."ST20")
  25 - filter(("T2"."REFDOSS"=:B1 AND "T2"."ORIG_REFLOT"=:B2 AND "T2"."MNT_DCPT" IS NOT NULL AND
              ((INTERNAL_FUNCTION("T2"."CODECR") AND (:B3='AENAT' OR :B4='ENCAT')) OR (INTERNAL_FUNCTION("T2"."CODECR") AND (:B5='ARFIN' OR
              :B6='RFIN')) OR (INTERNAL_FUNCTION("T2"."CODECR") AND (:B7='ADPRI' OR :B8='DPRIN')) OR (INTERNAL_FUNCTION("T2"."CODECR") AND
              (:B9='ACVFI' OR :B10='CVFIN')) OR ("T2"."CODECR"=:B11 AND :B12<>'AENAT' AND :B13<>'ENCAT' AND :B14<>'ARFIN' AND :B15<>'RFIN'
              AND :B16<>'ADPRI' AND :B17<>'DPRIN' AND :B18<>'ACVFI' AND :B19<>'CVFIN')) AND (("T2"."CODECR"<>'DPRIN' AND
              "T2"."CODECR"<>'ADPRI') OR ("T2"."CODECR"='ADPRI' AND NVL("T2"."MNT_DCPT",0)>0) OR ("T2"."CODECR"='DPRIN' AND
              NVL("T2"."MNT_DCPT",0)<0)) AND NVL("T2"."MNT_DCPT",0)<>0))
  26 - access("T2"."REFELEM"=:B1)
  28 - filter(<>0)
  29 - access("V"."ABREV"="P"."ST20")
  30 - access("V"."TYPE"='MOTIF_RETROCESSION')
  32 - filter(("FI2"."REFELEM" IS NULL OR (INTERNAL_FUNCTION("FI2"."TYPE") AND "FI2"."REFELEM" IS NOT NULL)))
  37 - filter((("CODECR"='PRIN' AND SIGN("TE"."MNT_DCPT")<>(-1)) OR ("CODECR"='APRIN' AND SIGN("TE"."MNT_DCPT")=(-1))))
  38 - access("TE"."ORIG_REFLOT"=VALUE(KOKBF$))
  39 - filter((INTERNAL_FUNCTION("FI"."TYPE") AND ("FI"."TYPE" LIKE 'RETROCESSION%' OR ("FI"."DTANNUL" IS NOT NULL AND
              INTERNAL_FUNCTION("FI"."TYPE")) OR ("FI"."LIBELLE" LIKE 'RETROCESSION%' AND INTERNAL_FUNCTION("FI"."TYPE")))))
  40 - access("FI"."REFELEM"="TE"."REFELEM")
  42 - access("FI2"."REFELEM"="FI"."REF_CREANCE")
  43 - filter("P"."TYPPIECE"='FACTURE')
  44 - access("P"."REFPIECE"="FI2"."REFPIECE2")
  46 - filter(("T2"."REFDOSS"=:B1 AND "T2"."ORIG_REFLOT"=:B2 AND "T2"."MNT_DCPT" IS NOT NULL AND
              ((INTERNAL_FUNCTION("T2"."CODECR") AND (:B3='AENAT' OR :B4='ENCAT')) OR (INTERNAL_FUNCTION("T2"."CODECR") AND (:B5='ARFIN' OR
              :B6='RFIN')) OR (INTERNAL_FUNCTION("T2"."CODECR") AND (:B7='ADPRI' OR :B8='DPRIN')) OR (INTERNAL_FUNCTION("T2"."CODECR") AND
              (:B9='ACVFI' OR :B10='CVFIN')) OR ("T2"."CODECR"=:B11 AND :B12<>'AENAT' AND :B13<>'ENCAT' AND :B14<>'ARFIN' AND :B15<>'RFIN'
              AND :B16<>'ADPRI' AND :B17<>'DPRIN' AND :B18<>'ACVFI' AND :B19<>'CVFIN')) AND (("T2"."CODECR"<>'DPRIN' AND
              "T2"."CODECR"<>'ADPRI') OR ("T2"."CODECR"='ADPRI' AND NVL("T2"."MNT_DCPT",0)>0) OR ("T2"."CODECR"='DPRIN' AND
              NVL("T2"."MNT_DCPT",0)<0)) AND NVL("T2"."MNT_DCPT",0)<>0))
  47 - access("T2"."REFELEM"=:B1)
  48 - filter(<>0)
  54 - filter(("FI2"."REFELEM" IS NULL OR (INTERNAL_FUNCTION("FI2"."TYPE") AND "FI2"."REFELEM" IS NOT NULL)))
  57 - filter(("FI"."LIBELLE_20_6"='RDP' AND "FI"."LIBELLE" LIKE 'RETROCESSION%'))
  58 - access(("FI"."TYPE"='SALES ORDER' OR "FI"."TYPE"='SO INVOICED'))
  60 - access("FI2"."REFELEM"="FI"."REF_CREANCE")
  61 - filter("P"."TYPPIECE"='FACTURE')
  62 - access("P"."REFPIECE"="FI2"."REFPIECE2")
  63 - access("V"."TYPE"='MOTIF_RETROCESSION' AND "V"."ABREV"="P"."ST20")
  66 - access("TE"."ORIG_REFLOT"=VALUE(KOKBF$))
  67 - filter(("FI"."REFELEM"="TE"."REFELEM" AND (((LNNVL("CODECR"='PRIN') OR LNNVL(SIGN("TE"."MNT_DCPT")<>(-1))) AND
              (LNNVL("CODECR"='APRIN') OR LNNVL(SIGN("TE"."MNT_DCPT")=(-1)))) OR (LNNVL("FI"."TYPE"='RETROCESSION') AND
              LNNVL("FI"."TYPE"='RETROCESSION NC')))))
  69 - filter(("T2"."REFDOSS"=:B1 AND "T2"."ORIG_REFLOT"=:B2 AND "T2"."MNT_DCPT" IS NOT NULL AND
              ((INTERNAL_FUNCTION("T2"."CODECR") AND (:B3='AENAT' OR :B4='ENCAT')) OR (INTERNAL_FUNCTION("T2"."CODECR") AND (:B5='ARFIN' OR
              :B6='RFIN')) OR (INTERNAL_FUNCTION("T2"."CODECR") AND (:B7='ADPRI' OR :B8='DPRIN')) OR (INTERNAL_FUNCTION("T2"."CODECR") AND
              (:B9='ACVFI' OR :B10='CVFIN')) OR ("T2"."CODECR"=:B11 AND :B12<>'AENAT' AND :B13<>'ENCAT' AND :B14<>'ARFIN' AND :B15<>'RFIN'
              AND :B16<>'ADPRI' AND :B17<>'DPRIN' AND :B18<>'ACVFI' AND :B19<>'CVFIN')) AND (("T2"."CODECR"<>'DPRIN' AND
              "T2"."CODECR"<>'ADPRI') OR ("T2"."CODECR"='ADPRI' AND NVL("T2"."MNT_DCPT",0)>0) OR ("T2"."CODECR"='DPRIN' AND
              NVL("T2"."MNT_DCPT",0)<0)) AND NVL("T2"."MNT_DCPT",0)<>0))
  70 - access("T2"."REFELEM"=:B1)
  71 - filter(<>0)
  77 - filter(("FI2"."REFELEM" IS NULL OR (INTERNAL_FUNCTION("FI2"."TYPE") AND "FI2"."REFELEM" IS NOT NULL)))
  80 - filter(("FI"."DTANNUL" IS NOT NULL AND "FI"."LIBELLE_20_6"='RDP' AND (LNNVL("FI"."LIBELLE" LIKE 'RETROCESSION%') OR
              (LNNVL("FI"."TYPE"='SALES ORDER') AND LNNVL("FI"."TYPE"='SO INVOICED')))))
  81 - access(("FI"."TYPE"='SALES ORDER' OR "FI"."TYPE"='SO INVOICED'))
  83 - access("FI2"."REFELEM"="FI"."REF_CREANCE")
  84 - filter("P"."TYPPIECE"='FACTURE')
  85 - access("P"."REFPIECE"="FI2"."REFPIECE2")
  86 - access("V"."TYPE"='MOTIF_RETROCESSION' AND "V"."ABREV"="P"."ST20")
  89 - access("TE"."ORIG_REFLOT"=VALUE(KOKBF$))
  90 - filter(("FI"."REFELEM"="TE"."REFELEM" AND (((LNNVL("CODECR"='PRIN') OR LNNVL(SIGN("TE"."MNT_DCPT")<>(-1))) AND
              (LNNVL("CODECR"='APRIN') OR LNNVL(SIGN("TE"."MNT_DCPT")=(-1)))) OR (LNNVL("FI"."TYPE"='RETROCESSION') AND
              LNNVL("FI"."TYPE"='RETROCESSION NC')))))
  92 - filter(("T2"."REFDOSS"=:B1 AND "T2"."ORIG_REFLOT"=:B2 AND "T2"."MNT_DCPT" IS NOT NULL AND
              ((INTERNAL_FUNCTION("T2"."CODECR") AND (:B3='AENAT' OR :B4='ENCAT')) OR (INTERNAL_FUNCTION("T2"."CODECR") AND (:B5='ARFIN' OR
              :B6='RFIN')) OR (INTERNAL_FUNCTION("T2"."CODECR") AND (:B7='ADPRI' OR :B8='DPRIN')) OR (INTERNAL_FUNCTION("T2"."CODECR") AND
              (:B9='ACVFI' OR :B10='CVFIN')) OR ("T2"."CODECR"=:B11 AND :B12<>'AENAT' AND :B13<>'ENCAT' AND :B14<>'ARFIN' AND :B15<>'RFIN'
              AND :B16<>'ADPRI' AND :B17<>'DPRIN' AND :B18<>'ACVFI' AND :B19<>'CVFIN')) AND (("T2"."CODECR"<>'DPRIN' AND
              "T2"."CODECR"<>'ADPRI') OR ("T2"."CODECR"='ADPRI' AND NVL("T2"."MNT_DCPT",0)>0) OR ("T2"."CODECR"='DPRIN' AND
              NVL("T2"."MNT_DCPT",0)<0)) AND NVL("T2"."MNT_DCPT",0)<>0))
  93 - access("T2"."REFELEM"=:B1)
  94 - filter(<>0)
 100 - filter(("FI2"."REFELEM" IS NULL OR (INTERNAL_FUNCTION("FI2"."TYPE") AND "FI2"."REFELEM" IS NOT NULL)))
 102 - filter(("FI"."LIBELLE_20_6"='RDP' AND (LNNVL("FI"."DTANNUL" IS NOT NULL) OR (LNNVL("FI"."TYPE"='SALES ORDER') AND
              LNNVL("FI"."TYPE"='SO INVOICED'))) AND (LNNVL("FI"."LIBELLE" LIKE 'RETROCESSION%') OR (LNNVL("FI"."TYPE"='SALES ORDER') AND
              LNNVL("FI"."TYPE"='SO INVOICED')))))
 103 - access("FI"."TYPE" LIKE 'RETROCESSION%')
       filter("FI"."TYPE" LIKE 'RETROCESSION%')
 105 - access("FI2"."REFELEM"="FI"."REF_CREANCE")
 106 - filter("P"."TYPPIECE"='FACTURE')
 107 - access("P"."REFPIECE"="FI2"."REFPIECE2")
 108 - access("V"."TYPE"='MOTIF_RETROCESSION' AND "V"."ABREV"="P"."ST20")
 111 - access("TE"."ORIG_REFLOT"=VALUE(KOKBF$))
 112 - filter(("FI"."REFELEM"="TE"."REFELEM" AND (((LNNVL("CODECR"='PRIN') OR LNNVL(SIGN("TE"."MNT_DCPT")<>(-1))) AND
              (LNNVL("CODECR"='APRIN') OR LNNVL(SIGN("TE"."MNT_DCPT")=(-1)))) OR (LNNVL("FI"."TYPE"='RETROCESSION') AND
              LNNVL("FI"."TYPE"='RETROCESSION NC')))))
 114 - filter(("T2"."REFDOSS"=:B1 AND "T2"."ORIG_REFLOT"=:B2 AND "T2"."MNT_DCPT" IS NOT NULL AND
              ((INTERNAL_FUNCTION("T2"."CODECR") AND (:B3='AENAT' OR :B4='ENCAT')) OR (INTERNAL_FUNCTION("T2"."CODECR") AND (:B5='ARFIN' OR
              :B6='RFIN')) OR (INTERNAL_FUNCTION("T2"."CODECR") AND (:B7='ADPRI' OR :B8='DPRIN')) OR (INTERNAL_FUNCTION("T2"."CODECR") AND
              (:B9='ACVFI' OR :B10='CVFIN')) OR ("T2"."CODECR"=:B11 AND :B12<>'AENAT' AND :B13<>'ENCAT' AND :B14<>'ARFIN' AND :B15<>'RFIN'
              AND :B16<>'ADPRI' AND :B17<>'DPRIN' AND :B18<>'ACVFI' AND :B19<>'CVFIN')) AND (("T2"."CODECR"<>'DPRIN' AND
              "T2"."CODECR"<>'ADPRI') OR ("T2"."CODECR"='ADPRI' AND NVL("T2"."MNT_DCPT",0)>0) OR ("T2"."CODECR"='DPRIN' AND
              NVL("T2"."MNT_DCPT",0)<0)) AND NVL("T2"."MNT_DCPT",0)<>0))
 115 - access("T2"."REFELEM"=:B1)
 116 - filter(<>0)
 120 - filter(NVL("V"."TYPE",'XXX')='MOTIF_RETROCESSION')
 123 - filter(("FI2"."REFELEM" IS NULL OR (INTERNAL_FUNCTION("FI2"."TYPE") AND "FI2"."REFELEM" IS NOT NULL)))
 126 - filter(("FI"."LIBELLE" LIKE 'RETROCESSION%' AND LNNVL("FI"."LIBELLE_20_6"='RDP')))
 127 - access(("FI"."TYPE"='SALES ORDER' OR "FI"."TYPE"='SO INVOICED'))
 129 - access("FI2"."REFELEM"="FI"."REF_CREANCE")
 130 - filter("P"."TYPPIECE"='FACTURE')
 131 - access("P"."REFPIECE"="FI2"."REFPIECE2")
 132 - access("V"."TYPE"='MOTIF_RETROCESSION' AND "V"."ABREV"="P"."ST20")
 135 - access("TE"."ORIG_REFLOT"=VALUE(KOKBF$))
 136 - filter(("FI"."REFELEM"="TE"."REFELEM" AND (((LNNVL("CODECR"='PRIN') OR LNNVL(SIGN("TE"."MNT_DCPT")<>(-1))) AND
              (LNNVL("CODECR"='APRIN') OR LNNVL(SIGN("TE"."MNT_DCPT")=(-1)))) OR (LNNVL("FI"."TYPE"='RETROCESSION') AND
              LNNVL("FI"."TYPE"='RETROCESSION NC')))))
 138 - filter(("T2"."REFDOSS"=:B1 AND "T2"."ORIG_REFLOT"=:B2 AND "T2"."MNT_DCPT" IS NOT NULL AND
              ((INTERNAL_FUNCTION("T2"."CODECR") AND (:B3='AENAT' OR :B4='ENCAT')) OR (INTERNAL_FUNCTION("T2"."CODECR") AND (:B5='ARFIN' OR
              :B6='RFIN')) OR (INTERNAL_FUNCTION("T2"."CODECR") AND (:B7='ADPRI' OR :B8='DPRIN')) OR (INTERNAL_FUNCTION("T2"."CODECR") AND
              (:B9='ACVFI' OR :B10='CVFIN')) OR ("T2"."CODECR"=:B11 AND :B12<>'AENAT' AND :B13<>'ENCAT' AND :B14<>'ARFIN' AND :B15<>'RFIN'
              AND :B16<>'ADPRI' AND :B17<>'DPRIN' AND :B18<>'ACVFI' AND :B19<>'CVFIN')) AND (("T2"."CODECR"<>'DPRIN' AND
              "T2"."CODECR"<>'ADPRI') OR ("T2"."CODECR"='ADPRI' AND NVL("T2"."MNT_DCPT",0)>0) OR ("T2"."CODECR"='DPRIN' AND
              NVL("T2"."MNT_DCPT",0)<0)) AND NVL("T2"."MNT_DCPT",0)<>0))
 139 - access("T2"."REFELEM"=:B1)
 140 - filter(<>0)
 144 - filter(NVL("V"."TYPE",'XXX')='MOTIF_RETROCESSION')
 147 - filter(("FI2"."REFELEM" IS NULL OR (INTERNAL_FUNCTION("FI2"."TYPE") AND "FI2"."REFELEM" IS NOT NULL)))
 150 - filter(("FI"."DTANNUL" IS NOT NULL AND (LNNVL("FI"."LIBELLE" LIKE 'RETROCESSION%') OR (LNNVL("FI"."TYPE"='SALES ORDER')
              AND LNNVL("FI"."TYPE"='SO INVOICED'))) AND LNNVL("FI"."LIBELLE_20_6"='RDP')))
 151 - access(("FI"."TYPE"='SALES ORDER' OR "FI"."TYPE"='SO INVOICED'))
 153 - access("FI2"."REFELEM"="FI"."REF_CREANCE")
 154 - filter("P"."TYPPIECE"='FACTURE')
 155 - access("P"."REFPIECE"="FI2"."REFPIECE2")
 156 - access("V"."TYPE"='MOTIF_RETROCESSION' AND "V"."ABREV"="P"."ST20")
 159 - access("TE"."ORIG_REFLOT"=VALUE(KOKBF$))
 160 - filter(("FI"."REFELEM"="TE"."REFELEM" AND (((LNNVL("CODECR"='PRIN') OR LNNVL(SIGN("TE"."MNT_DCPT")<>(-1))) AND
              (LNNVL("CODECR"='APRIN') OR LNNVL(SIGN("TE"."MNT_DCPT")=(-1)))) OR (LNNVL("FI"."TYPE"='RETROCESSION') AND
              LNNVL("FI"."TYPE"='RETROCESSION NC')))))
 162 - filter(("T2"."REFDOSS"=:B1 AND "T2"."ORIG_REFLOT"=:B2 AND "T2"."MNT_DCPT" IS NOT NULL AND
              ((INTERNAL_FUNCTION("T2"."CODECR") AND (:B3='AENAT' OR :B4='ENCAT')) OR (INTERNAL_FUNCTION("T2"."CODECR") AND (:B5='ARFIN' OR
              :B6='RFIN')) OR (INTERNAL_FUNCTION("T2"."CODECR") AND (:B7='ADPRI' OR :B8='DPRIN')) OR (INTERNAL_FUNCTION("T2"."CODECR") AND
              (:B9='ACVFI' OR :B10='CVFIN')) OR ("T2"."CODECR"=:B11 AND :B12<>'AENAT' AND :B13<>'ENCAT' AND :B14<>'ARFIN' AND :B15<>'RFIN'
              AND :B16<>'ADPRI' AND :B17<>'DPRIN' AND :B18<>'ACVFI' AND :B19<>'CVFIN')) AND (("T2"."CODECR"<>'DPRIN' AND
              "T2"."CODECR"<>'ADPRI') OR ("T2"."CODECR"='ADPRI' AND NVL("T2"."MNT_DCPT",0)>0) OR ("T2"."CODECR"='DPRIN' AND
              NVL("T2"."MNT_DCPT",0)<0)) AND NVL("T2"."MNT_DCPT",0)<>0))
 163 - access("T2"."REFELEM"=:B1)
 164 - filter(<>0)
 165 - access("TE"."ORIG_REFLOT"=VALUE(KOKBF$))
 168 - filter(NVL("V"."TYPE",'XXX')='MOTIF_RETROCESSION')
 169 - access("V"."ABREV"="P"."ST20")
 170 - access("V"."TYPE"='MOTIF_RETROCESSION')
 172 - filter(("FI2"."REFELEM" IS NULL OR (INTERNAL_FUNCTION("FI2"."TYPE") AND "FI2"."REFELEM" IS NOT NULL)))
 174 - filter(((LNNVL("FI"."DTANNUL" IS NOT NULL) OR (LNNVL("FI"."TYPE"='SALES ORDER') AND LNNVL("FI"."TYPE"='SO INVOICED')))
              AND (LNNVL("FI"."LIBELLE" LIKE 'RETROCESSION%') OR (LNNVL("FI"."TYPE"='SALES ORDER') AND LNNVL("FI"."TYPE"='SO INVOICED')))
              AND LNNVL("FI"."LIBELLE_20_6"='RDP')))
 175 - access("FI"."TYPE" LIKE 'RETROCESSION%')
       filter("FI"."TYPE" LIKE 'RETROCESSION%')
 177 - access("FI2"."REFELEM"="FI"."REF_CREANCE")
 178 - filter("P"."TYPPIECE"='FACTURE')
 179 - access("P"."REFPIECE"="FI2"."REFPIECE2")
 181 - filter(("FI"."REFELEM"="TE"."REFELEM" AND (((LNNVL("CODECR"='PRIN') OR LNNVL(SIGN("TE"."MNT_DCPT")<>(-1))) AND
              (LNNVL("CODECR"='APRIN') OR LNNVL(SIGN("TE"."MNT_DCPT")=(-1)))) OR (LNNVL("FI"."TYPE"='RETROCESSION') AND
              LNNVL("FI"."TYPE"='RETROCESSION NC')))))
 184 - filter(("T2"."REFDOSS"=:B1 AND "T2"."ORIG_REFLOT"=:B2 AND "T2"."MNT_DCPT" IS NOT NULL AND
              ((INTERNAL_FUNCTION("T2"."CODECR") AND (:B3='AENAT' OR :B4='ENCAT')) OR (INTERNAL_FUNCTION("T2"."CODECR") AND (:B5='ARFIN' OR
              :B6='RFIN')) OR (INTERNAL_FUNCTION("T2"."CODECR") AND (:B7='ADPRI' OR :B8='DPRIN')) OR (INTERNAL_FUNCTION("T2"."CODECR") AND
              (:B9='ACVFI' OR :B10='CVFIN')) OR ("T2"."CODECR"=:B11 AND :B12<>'AENAT' AND :B13<>'ENCAT' AND :B14<>'ARFIN' AND :B15<>'RFIN'
              AND :B16<>'ADPRI' AND :B17<>'DPRIN' AND :B18<>'ACVFI' AND :B19<>'CVFIN')) AND (("T2"."CODECR"<>'DPRIN' AND
              "T2"."CODECR"<>'ADPRI') OR ("T2"."CODECR"='ADPRI' AND NVL("T2"."MNT_DCPT",0)>0) OR ("T2"."CODECR"='DPRIN' AND
              NVL("T2"."MNT_DCPT",0)<0)) AND NVL("T2"."MNT_DCPT",0)<>0))
 185 - access("T2"."REFELEM"=:B1)
 186 - filter(<>0)
 187 - access("TE"."ORIG_REFLOT"=VALUE(KOKBF$))
 189 - filter((NVL("V"."TYPE",'XXX')<>'MOTIF_RETROCESSION' AND LNNVL(NVL("V"."TYPE",'XXX')='MOTIF_RETROCESSION')))
 190 - access("V"."ABREV"="P"."ST20")
 191 - access("V"."TYPE"='MOTIF_RETROCESSION')
 193 - filter(("FI2"."REFELEM" IS NULL OR (INTERNAL_FUNCTION("FI2"."TYPE") AND "FI2"."REFELEM" IS NOT NULL)))
 195 - access("FI"."REFELEM"="TE"."REFELEM")
       filter((((LNNVL("CODECR"='PRIN') OR LNNVL(SIGN("TE"."MNT_DCPT")<>(-1))) AND (LNNVL("CODECR"='APRIN') OR
              LNNVL(SIGN("TE"."MNT_DCPT")=(-1)))) OR (LNNVL("FI"."TYPE"='RETROCESSION') AND LNNVL("FI"."TYPE"='RETROCESSION NC'))))
 196 - filter(("CODECR" LIKE 'A%' AND "CODECR"<>'ADPRI'))
 198 - filter((("FI"."TYPE" LIKE 'RETROCESSION%' OR ("FI"."DTANNUL" IS NOT NULL AND INTERNAL_FUNCTION("FI"."TYPE")) OR
              ("FI"."LIBELLE" LIKE 'RETROCESSION%' AND INTERNAL_FUNCTION("FI"."TYPE"))) AND LNNVL("FI"."LIBELLE_20_6"='RDP')))
 203 - access("FI"."TYPE" LIKE 'RETROCESSION%')
       filter(("FI"."TYPE" LIKE 'RETROCESSION%' AND "FI"."TYPE" LIKE 'RETROCESSION%'))
 206 - access("FI"."TYPE"='SALES ORDER')
 208 - access("FI"."TYPE"='SO INVOICED')
 211 - access("FI"."TYPE"='SALES ORDER')
 213 - access("FI"."TYPE"='SO INVOICED')
 215 - access("FI2"."REFELEM"="FI"."REF_CREANCE")
 216 - filter("P"."TYPPIECE"='FACTURE')
 217 - access("P"."REFPIECE"="FI2"."REFPIECE2")
 219 - filter(("T2"."REFDOSS"=:B1 AND "T2"."ORIG_REFLOT"=:B2 AND "T2"."MNT_DCPT" IS NOT NULL AND
              ((INTERNAL_FUNCTION("T2"."CODECR") AND (:B3='AENAT' OR :B4='ENCAT')) OR (INTERNAL_FUNCTION("T2"."CODECR") AND (:B5='ARFIN' OR
              :B6='RFIN')) OR (INTERNAL_FUNCTION("T2"."CODECR") AND (:B7='ADPRI' OR :B8='DPRIN')) OR (INTERNAL_FUNCTION("T2"."CODECR") AND
              (:B9='ACVFI' OR :B10='CVFIN')) OR ("T2"."CODECR"=:B11 AND :B12<>'AENAT' AND :B13<>'ENCAT' AND :B14<>'ARFIN' AND :B15<>'RFIN'
              AND :B16<>'ADPRI' AND :B17<>'DPRIN' AND :B18<>'ACVFI' AND :B19<>'CVFIN')) AND (("T2"."CODECR"<>'DPRIN' AND
              "T2"."CODECR"<>'ADPRI') OR ("T2"."CODECR"='ADPRI' AND NVL("T2"."MNT_DCPT",0)>0) OR ("T2"."CODECR"='DPRIN' AND
              NVL("T2"."MNT_DCPT",0)<0)) AND NVL("T2"."MNT_DCPT",0)<>0))
 220 - access("T2"."REFELEM"=:B1)

*/
/********************************OLD Metrics***************************************/

/********************************New SQL*******************************************/

SELECT CASE
         WHEN :b0 = 0 OR :b0 = 2 THEN
          T . dtinter
         else
          NULL
       END,
       CASE
         WHEN :b0 = 1 OR :b0 = 2 THEN
          T . dtjour
         else
          NULL
       END,
       sum(T . mnt),
       T . motif,
       T . refdossDb,
       T . so_mov
  FROM ( SELECT /*+ LEADING(a TE fi fi2 p) INDEX(TE T_ECRDOS$ORIG_REFLOT) USE_NL(TE) use_nl(fi) cardinality(a 5) no_expand +*/
                trunc(te . dtjour_dt) dtinter,
                trunc(te . dtjour_dt) dtjour,
                te.mnt_dcpt mnt,
                CASE
                  WHEN fi.type IN ('WRITE OFF', 'WRITE OFF CN') THEN
                   2
                  ELSE
                   DECODE(SIGN(NVL(Fi . dtannul, 0)),
                          1,
                          case
                            WHEN fi.type in ('RETROCESSION', 'RETROCESSION NC') and te.CODECR = 'PRIN' THEN
                             0
                            ELSE
                             2
                          END,
                          DECODE(v.abrev,
                                 'RDP',
                                 1,
                                 DECODE(fi.libelle_20_6, 'RDP', 1, 0)))
                END motif,
                te.refdoss refdossDb,
                0 so_mov,
                fi2.refelem ret_reflem,
                fi2.type ret_type
          FROM g_elemfi fi,
               g_elemfi fi2,
               g_piece p,
               v_domaine v,
               t_ecrdos TE,
               (TABLE(dfx_lst.GetListMemoDecompte( :b4,
                                                   :b5,
                                                   :b6,
                                                   :b7,
                                                   :b8,
                                                   :b9,
                                                   :b10,
                                                   :b11,
                                                   :b12 ) ) ) a
         WHERE te.orig_reflot = a.column_value
           AND 0 != ( SELECT NVL(SUM(t2 . mnt_dcpt), -1)
                        FROM t_ecrdos t2
                       WHERE t2.refelem = te.refelem
                         AND t2.refdoss = te.refdoss
                         AND t2.orig_reflot = te.orig_reflot
                         AND (  (    te.codecr IN ('AENAT', 'ENCAT') 
                                 AND t2.codecr IN ('AENAT', 'ENCAT') ) 
                             OR (    te.codecr IN ('ARFIN', 'RFIN') 
                                 AND t2.codecr IN ('ARFIN', 'RFIN') ) 
                             OR (    te.codecr IN ('ADPRI', 'DPRIN') 
                                 AND t2.codecr IN ('ADPRI', 'DPRIN') ) 
                             OR (    te.codecr IN ('ACVFI', 'CVFIN') 
                                 AND t2.codecr IN ('ACVFI', 'CVFIN') )
                             OR (    te.codecr NOT IN ( 'AENAT',
                                                        'ENCAT',
                                                        'ARFIN',
                                                        'RFIN',
                                                        'ADPRI',
                                                        'DPRIN',
                                                        'ACVFI',
                                                        'CVFIN' )
                                 AND t2.codecr = te.codecr ) )
                   AND ( ( t2.codecr IN ('DPRIN', 'ADPRI') AND
                        ((t2 . codecr = 'DPRIN' AND NVL(t2 . mnt_dcpt, 0) < 0) OR
                        (t2 . codecr = 'ADPRI' AND NVL(t2 . mnt_dcpt, 0) > 0))) OR t2 .
                        codecr NOT IN ('DPRIN', 'ADPRI'))
                     AND NVL(t2 . mnt_dcpt, 0) != 0)
           AND ( (    te.codecr LIKE 'A%' 
                  AND te.codecr != 'ADPRI' 
                  AND NVL(v.type, 'XXX') != 'MOTIF_RETROCESSION' )
              OR  NVL(v.type, 'XXX') = 'MOTIF_RETROCESSION' 
               OR fi.libelle_20_6 = 'RDP' 
               OR ( ( (    codecr = 'PRIN' 
                       AND SIGN(te.mnt_dcpt) != -1 ) 
                   OR (    codecr = 'APRIN' 
                       AND SIGN(te.mnt_dcpt) = -1) ) 
                 AND fi.Type IN ( 'RETROCESSION', 'RETROCESSION NC' ) )
               OR (    fi.type in ('RETROCESSION', 'RETROCESSION NC') 
                   and te.CODECR = 'PRIN' 
                   and fi.dtannul IS NOT NULL 
                   AND p.st20 IS NULL )
               OR fi.type IN ('WRITE OFF', 'WRITE OFF CN') )
           AND fi.refelem = TE.refelem
           AND fi.refdoss IN ( SELECT g.refdoss
                                 FROM g_dossier g
                                WHERE g.reflot = :b4
                                  AND g.categdoss LIKE 'COMPTE%' )
           AND (     fi.type like 'RETROCESSION%' 
                OR (    fi.dtannul IS NOT NULL 
                	  AND fi.type NOT IN ('SALES ORDER', 'SO INVOICED') ) 
                OR (    fi.type = 'FACTURE' 
                    AND fi.libelle LIKE 'RETROCESSION%' )
                OR fi.type IN ('WRITE OFF', 'WRITE OFF CN') )
           AND fi2.refelem(+) = fi.ref_creance
           AND p.refpiece(+) = fi2.refpiece2
           AND p.typpiece(+) = 'FACTURE'
           AND v.type(+) = 'MOTIF_RETROCESSION'
           AND v.abrev(+) = p.st20
        union ALL
        SELECT /*+LEADING(a TE fi fi2 p) INDEX(TE T_ECRDOS$ORIG_REFLOT) USE_NL(TE) use_nl(fi) cardinality(a 5) no_expand +*/
         trunc(te . dtjour_dt) dtinter,
         trunc(te . dtjour_dt) dtjour,
         te . mnt_dcpt mnt,
         DECODE(SIGN(NVL(Fi . dtannul, 0)),
                1,
                2,
                DECODE(v . abrev,
                       'RDP',
                       1,
                       DECODE(fi . libelle_20_6, 'RDP', 1, 0))) motif,
         te . refdoss refdossDb,
         1 so_mov,
         fi2 . refelem ret_reflem,
         fi2 . type ret_type
          FROM g_elemfi fi,
               g_elemfi fi2,
               g_piece p,
               v_domaine v,
               t_ecrdos TE,
               (TABLE(dfx_lst.GetListMemoDecompte( :b4,
                                                   :b5,
                                                   :b6,
                                                   :b7,
                                                   :b8,
                                                   :b9,
                                                   :b10,
                                                   :b11,
                                                   :b12 ) ) ) a
         WHERE te.orig_reflot = a.column_value
           AND 0 !=
               (SELECT NVL(SUM(t2 . mnt_dcpt), -1)
                  FROM t_ecrdos t2
                 WHERE t2.refelem = te.refelem
                   AND t2.refdoss = te.refdoss
                   AND t2.orig_reflot = te.orig_reflot
                   AND ((te . codecr IN ('AENAT', 'ENCAT') AND t2 .
                        codecr IN ('AENAT', 'ENCAT')) OR
                       (te . codecr IN ('ARFIN', 'RFIN') AND t2 .
                        codecr IN ('ARFIN', 'RFIN')) OR
                       (te . codecr IN ('ADPRI', 'DPRIN') AND t2 .
                        codecr IN ('ADPRI', 'DPRIN')) OR
                       (te . codecr IN ('ACVFI', 'CVFIN') AND t2 .
                        codecr IN ('ACVFI', 'CVFIN')) OR
                       (te . codecr NOT IN ('AENAT',
                                             'ENCAT',
                                             'ARFIN',
                                             'RFIN',
                                             'ADPRI',
                                             'DPRIN',
                                             'ACVFI',
                                             'CVFIN') AND t2 . codecr = te .
                        codecr))
                   AND ((t2 .
                        codecr IN ('DPRIN', 'ADPRI') AND
                        ((t2 . codecr = 'DPRIN' AND NVL(t2 . mnt_dcpt, 0) < 0) OR
                        (t2 . codecr = 'ADPRI' AND NVL(t2 . mnt_dcpt, 0) > 0))) OR t2 .
                        codecr NOT IN ('DPRIN', 'ADPRI'))
                   AND NVL(t2 . mnt_dcpt, 0) != 0)
           AND ( (    te.codecr LIKE 'A%' 
                  AND te.codecr != 'ADPRI' 
                  AND NVL(v.type, 'XXX') != 'MOTIF_RETROCESSION' ) 
               OR NVL(v.type, 'XXX') = 'MOTIF_RETROCESSION' 
               OR fi.libelle_20_6 = 'RDP'
               OR ( ( (    codecr = 'PRIN' 
                       AND SIGN(te . mnt_dcpt) != -1 ) 
                   OR (    codecr = 'APRIN' 
                       AND SIGN(te . mnt_dcpt ) = -1 ) )
                 AND fi.Type IN ('RETROCESSION', 'RETROCESSION NC') ) )
           AND fi.refelem = TE.refelem
           AND (     fi.type like 'RETROCESSION%'
                OR (    fi.dtannul IS NOT NULL 
                  	AND fi.type IN ( 'SALES ORDER', 'SO INVOICED' ) )
                OR (    fi.type IN ( 'SALES ORDER', 'SO INVOICED' ) 
                    AND fi.libelle LIKE 'RETROCESSION%' ) )
           AND fi2.refelem(+) = fi.ref_creance
           AND p.refpiece(+) = fi2.refpiece2
           AND p.typpiece(+) = 'FACTURE'
           AND v.type(+) = 'MOTIF_RETROCESSION'
           AND v.abrev(+) = p.st20 ) T
 WHERE (T . ret_reflem IS NULL OR
        (T . ret_reflem IS NOT NULL AND
         ((T . so_mov = 0 AND T .
          ret_type NOT IN ('SALES ORDER', 'SO INVOICED')) OR
         (T . so_mov = 1 AND T .
          ret_type IN ('SALES ORDER', 'SO INVOICED')))))
 GROUP BY T . motif,
          CASE
            WHEN :b0 = 0 OR :b0 = 2 THEN
             T . dtinter
            else
             NULL
          END,
          CASE
            WHEN :b0 = 1 OR :b0 = 2 THEN
             T . dtjour
            else
             NULL
          END,
          t . refdossDb,
          T . so_mov
 ORDER BY T . motif,
          CASE
            WHEN :b0 = 0 OR :b0 = 2 THEN
             T . dtinter
            else
             NULL
          END,
          CASE
            WHEN :b0 = 1 OR :b0 = 2 THEN
             T . dtjour
            else
             NULL
          END;
/********************************New SQL*******************************************/
/********************************New Metrics***************************************/
/*
Plan hash value: 836783329
----------------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                       | Name                      | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers |
----------------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                                |                           |      1 |        |   133K(100)|      0 |00:00:00.01 |     173 |
|   1 |  SORT GROUP BY                                  |                           |      1 |      2 |   133K  (1)|      0 |00:00:00.01 |     173 |
|   2 |   VIEW                                          |                           |      1 |      2 |   133K  (1)|      0 |00:00:00.01 |     173 |
|   3 |    UNION-ALL                                    |                           |      1 |        |            |      0 |00:00:00.01 |     173 |
|*  4 |     FILTER                                      |                           |      1 |        |            |      0 |00:00:00.01 |      87 |
|*  5 |      FILTER                                     |                           |      1 |        |            |      0 |00:00:00.01 |      87 |
|   6 |       NESTED LOOPS OUTER                        |                           |      1 |      7 | 48716   (1)|      0 |00:00:00.01 |      87 |
|*  7 |        HASH JOIN                                |                           |      1 |      7 | 48715   (1)|      0 |00:00:00.01 |      87 |
|*  8 |         INDEX RANGE SCAN                        | G_DOSSIER_RL_CD_RD_RF_IDX |      1 |      5 |     1   (0)|      2 |00:00:00.01 |       3 |
|   9 |         NESTED LOOPS OUTER                      |                           |      1 |  88276 | 48713   (1)|      0 |00:00:00.01 |      84 |
|* 10 |          FILTER                                 |                           |      1 |        |            |      0 |00:00:00.01 |      84 |
|  11 |           NESTED LOOPS OUTER                    |                           |      1 |  88276 | 46105   (1)|      0 |00:00:00.01 |      84 |
|  12 |            NESTED LOOPS                         |                           |      1 |  88276 | 44339   (1)|      0 |00:00:00.01 |      84 |
|  13 |             NESTED LOOPS                        |                           |      1 |   2108K|  2150   (1)|      0 |00:00:00.01 |      84 |
|  14 |              COLLECTION ITERATOR PICKLER FETCH  | GETLISTMEMODECOMPTE       |      1 |   8168 |    24   (0)|     46 |00:00:00.01 |       0 |
|  15 |              TABLE ACCESS BY INDEX ROWID BATCHED| T_ECRDOS                  |     46 |    258 |     1   (0)|      0 |00:00:00.01 |      84 |
|* 16 |               INDEX RANGE SCAN                  | T_ECRDOS$ORIG_REFLOT      |     46 |    160 |     1   (0)|      0 |00:00:00.01 |      84 |
|* 17 |             TABLE ACCESS BY INDEX ROWID         | G_ELEMFI                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 18 |              INDEX UNIQUE SCAN                  | EFI_REFELEM               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|  19 |            TABLE ACCESS BY INDEX ROWID          | G_ELEMFI                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 20 |             INDEX UNIQUE SCAN                   | EFI_REFELEM               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 21 |          TABLE ACCESS BY INDEX ROWID BATCHED    | G_PIECE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 22 |           INDEX RANGE SCAN                      | PIE_REFPIECE              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 23 |        INDEX RANGE SCAN                         | DOM_TYPABREV              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|  24 |      SORT AGGREGATE                             |                           |      0 |      1 |            |      0 |00:00:00.01 |       0 |
|* 25 |       TABLE ACCESS BY INDEX ROWID BATCHED       | T_ECRDOS                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 26 |        INDEX RANGE SCAN                         | TECR_REFELEM              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 27 |     FILTER                                      |                           |      1 |        |            |      0 |00:00:00.01 |      86 |
|* 28 |      FILTER                                     |                           |      1 |        |            |      0 |00:00:00.01 |      86 |
|* 29 |       HASH JOIN RIGHT OUTER                     |                           |      1 |  40223 | 46333   (1)|      0 |00:00:00.01 |      86 |
|* 30 |        INDEX RANGE SCAN                         | DOM_TYPABREV              |      1 |     41 |     1   (0)|     12 |00:00:00.01 |       2 |
|  31 |        NESTED LOOPS OUTER                       |                           |      1 |  40223 | 46332   (1)|      0 |00:00:00.01 |      84 |
|* 32 |         FILTER                                  |                           |      1 |        |            |      0 |00:00:00.01 |      84 |
|  33 |          NESTED LOOPS OUTER                     |                           |      1 |  40223 | 45143   (1)|      0 |00:00:00.01 |      84 |
|  34 |           NESTED LOOPS                          |                           |      1 |  40223 | 44339   (1)|      0 |00:00:00.01 |      84 |
|  35 |            NESTED LOOPS                         |                           |      1 |   2108K|  2150   (1)|      0 |00:00:00.01 |      84 |
|  36 |             COLLECTION ITERATOR PICKLER FETCH   | GETLISTMEMODECOMPTE       |      1 |   8168 |    24   (0)|     46 |00:00:00.01 |       0 |
|  37 |             TABLE ACCESS BY INDEX ROWID BATCHED | T_ECRDOS                  |     46 |    258 |     1   (0)|      0 |00:00:00.01 |      84 |
|* 38 |              INDEX RANGE SCAN                   | T_ECRDOS$ORIG_REFLOT      |     46 |    160 |     1   (0)|      0 |00:00:00.01 |      84 |
|* 39 |            TABLE ACCESS BY INDEX ROWID          | G_ELEMFI                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 40 |             INDEX UNIQUE SCAN                   | EFI_REFELEM               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|  41 |           TABLE ACCESS BY INDEX ROWID           | G_ELEMFI                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 42 |            INDEX UNIQUE SCAN                    | EFI_REFELEM               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 43 |         TABLE ACCESS BY INDEX ROWID BATCHED     | G_PIECE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 44 |          INDEX RANGE SCAN                       | PIE_REFPIECE              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|  45 |      SORT AGGREGATE                             |                           |      0 |      1 |            |      0 |00:00:00.01 |       0 |
|* 46 |       TABLE ACCESS BY INDEX ROWID BATCHED       | T_ECRDOS                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 47 |        INDEX RANGE SCAN                         | TECR_REFELEM              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
----------------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   4 - filter(<>0)
   5 - filter((("TE"."CODECR" LIKE 'A%' AND "TE"."CODECR"<>'ADPRI' AND NVL("V"."TYPE",'XXX')<>'MOTIF_RETROCESSION') OR
              NVL("V"."TYPE",'XXX')='MOTIF_RETROCESSION' OR "FI"."LIBELLE_20_6"='RDP' OR ((("TE"."CODECR"='PRIN' AND SIGN("TE"."MNT_DCPT")<>(-1)) OR
              ("TE"."CODECR"='APRIN' AND SIGN("TE"."MNT_DCPT")=(-1))) AND INTERNAL_FUNCTION("FI"."TYPE")) OR (INTERNAL_FUNCTION("FI"."TYPE") AND
              "TE"."CODECR"='PRIN' AND "P"."ST20" IS NULL AND "FI"."DTANNUL" IS NOT NULL) OR INTERNAL_FUNCTION("FI"."TYPE")))
   7 - access("FI"."REFDOSS"="G"."REFDOSS")
   8 - access("G"."REFLOT"=:B4 AND "G"."CATEGDOSS" LIKE 'COMPTE%')
       filter("G"."CATEGDOSS" LIKE 'COMPTE%')
  10 - filter(("FI2"."REFELEM" IS NULL OR ("FI2"."REFELEM" IS NOT NULL AND "FI2"."TYPE"<>'SALES ORDER' AND "FI2"."TYPE"<>'SO INVOICED')))
  16 - access("TE"."ORIG_REFLOT"=VALUE(KOKBF$))
  17 - filter(("FI"."REFDOSS" IS NOT NULL AND (INTERNAL_FUNCTION("FI"."TYPE") OR "FI"."TYPE" LIKE 'RETROCESSION%' OR ("FI"."DTANNUL" IS NOT
              NULL AND "FI"."TYPE"<>'SALES ORDER' AND "FI"."TYPE"<>'SO INVOICED') OR ("FI"."TYPE"='FACTURE' AND "FI"."LIBELLE" LIKE 'RETROCESSION%'))))
  18 - access("FI"."REFELEM"="TE"."REFELEM")
  20 - access("FI2"."REFELEM"="FI"."REF_CREANCE")
  21 - filter("P"."TYPPIECE"='FACTURE')
  22 - access("P"."REFPIECE"="FI2"."REFPIECE2")
  23 - access("V"."TYPE"='MOTIF_RETROCESSION' AND "V"."ABREV"="P"."ST20")
  25 - filter(("T2"."REFDOSS"=:B1 AND "T2"."ORIG_REFLOT"=:B2 AND "T2"."MNT_DCPT" IS NOT NULL AND ((INTERNAL_FUNCTION("T2"."CODECR") AND
              (:B3='AENAT' OR :B4='ENCAT')) OR (INTERNAL_FUNCTION("T2"."CODECR") AND (:B5='ARFIN' OR :B6='RFIN')) OR (INTERNAL_FUNCTION("T2"."CODECR")
              AND (:B7='ADPRI' OR :B8='DPRIN')) OR (INTERNAL_FUNCTION("T2"."CODECR") AND (:B9='ACVFI' OR :B10='CVFIN')) OR ("T2"."CODECR"=:B11 AND
              :B12<>'AENAT' AND :B13<>'ENCAT' AND :B14<>'ARFIN' AND :B15<>'RFIN' AND :B16<>'ADPRI' AND :B17<>'DPRIN' AND :B18<>'ACVFI' AND
              :B19<>'CVFIN')) AND (("T2"."CODECR"<>'DPRIN' AND "T2"."CODECR"<>'ADPRI') OR ("T2"."CODECR"='ADPRI' AND NVL("T2"."MNT_DCPT",0)>0) OR
              ("T2"."CODECR"='DPRIN' AND NVL("T2"."MNT_DCPT",0)<0)) AND NVL("T2"."MNT_DCPT",0)<>0))
  26 - access("T2"."REFELEM"=:B1)
  27 - filter(<>0)
  28 - filter((("CODECR" LIKE 'A%' AND "CODECR"<>'ADPRI' AND NVL("V"."TYPE",'XXX')<>'MOTIF_RETROCESSION') OR
              NVL("V"."TYPE",'XXX')='MOTIF_RETROCESSION' OR "FI"."LIBELLE_20_6"='RDP' OR ((("CODECR"='PRIN' AND SIGN("TE"."MNT_DCPT")<>(-1)) OR
              ("CODECR"='APRIN' AND SIGN("TE"."MNT_DCPT")=(-1))) AND INTERNAL_FUNCTION("FI"."TYPE"))))
  29 - access("V"."ABREV"="P"."ST20")
  30 - access("V"."TYPE"='MOTIF_RETROCESSION')
  32 - filter(("FI2"."REFELEM" IS NULL OR (INTERNAL_FUNCTION("FI2"."TYPE") AND "FI2"."REFELEM" IS NOT NULL)))
  38 - access("TE"."ORIG_REFLOT"=VALUE(KOKBF$))
  39 - filter(("FI"."TYPE" LIKE 'RETROCESSION%' OR ("FI"."DTANNUL" IS NOT NULL AND INTERNAL_FUNCTION("FI"."TYPE")) OR ("FI"."LIBELLE" LIKE
              'RETROCESSION%' AND INTERNAL_FUNCTION("FI"."TYPE"))))
  40 - access("FI"."REFELEM"="TE"."REFELEM")
  42 - access("FI2"."REFELEM"="FI"."REF_CREANCE")
  43 - filter("P"."TYPPIECE"='FACTURE')
  44 - access("P"."REFPIECE"="FI2"."REFPIECE2")
  46 - filter(("T2"."REFDOSS"=:B1 AND "T2"."ORIG_REFLOT"=:B2 AND "T2"."MNT_DCPT" IS NOT NULL AND ((INTERNAL_FUNCTION("T2"."CODECR") AND
              (:B3='AENAT' OR :B4='ENCAT')) OR (INTERNAL_FUNCTION("T2"."CODECR") AND (:B5='ARFIN' OR :B6='RFIN')) OR (INTERNAL_FUNCTION("T2"."CODECR")
              AND (:B7='ADPRI' OR :B8='DPRIN')) OR (INTERNAL_FUNCTION("T2"."CODECR") AND (:B9='ACVFI' OR :B10='CVFIN')) OR ("T2"."CODECR"=:B11 AND
              :B12<>'AENAT' AND :B13<>'ENCAT' AND :B14<>'ARFIN' AND :B15<>'RFIN' AND :B16<>'ADPRI' AND :B17<>'DPRIN' AND :B18<>'ACVFI' AND
              :B19<>'CVFIN')) AND (("T2"."CODECR"<>'DPRIN' AND "T2"."CODECR"<>'ADPRI') OR ("T2"."CODECR"='ADPRI' AND NVL("T2"."MNT_DCPT",0)>0) OR
              ("T2"."CODECR"='DPRIN' AND NVL("T2"."MNT_DCPT",0)<0)) AND NVL("T2"."MNT_DCPT",0)<>0))
  47 - access("T2"."REFELEM"=:B1)
*/
/********************************New Metrics***************************************/

/********************************Index statistics**********************************/

/********************************Other SQLs****************************************/          
/*

*/ 
/********************************Other SQLs****************************************/              
