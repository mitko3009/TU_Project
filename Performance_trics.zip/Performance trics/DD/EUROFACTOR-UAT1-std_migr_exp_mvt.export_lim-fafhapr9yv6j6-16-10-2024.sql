/********************************************************************************
*********       E-mail subject: EFAGDEV-3544
*********             Instance: UAT1
*********          Description: 
Problem:
It was requested to check the std_migr_exp_mvt.export_lim on UAT1 for the period 11/10/24 12:25:17 - 11/10/24 13:32:57

Analysis:
We checked the work of the std_migr_exp_mvt.export_lim and found that the two TOP SQLs fafhapr9yv6j6 and 33hv83rutznyv were responsible for ~76% of the time.
It looks like because of the huge amount of data, the heaviest operation in both of the queries is the RANGE SCAN of table G_PIECE. The solution that I can suggest 
here is to use FULL SCAN and parallel to read the common data from tables like G_PIECE and T_INTERVENANTS and store it in materialized temporary views. After that, we can 
use them in the queries instead of the real tables. 

Suggestion:
Please change the queries as it is shown in the New SQL section below.

*********               SQL_ID: fafhapr9yv6j6, 33hv83rutznyv
*********      Program/Package: 
*********              Request: Spasiyan Todorov 
*********               Author: Dimitar Dimitrov
********* Received e-mail date: 15/10/2024
*********      Resolution date: 16/10/2024
*********  Trace old file here: \\epox\specifs\performance\tmp\
*********  Trace new file here:
***********************************************************************************/

/********************************OLD SQL*******************************************/
-- fafhapr9yv6j6

VAR B1 NUMBER;
EXEC :B1 := 0;
VAR B2 NUMBER;
EXEC :B2 := 0;

INSERT INTO STD_MIGR_LIM( LIMIT_REF,
                          CURRENCY_LIM,
                          LIMIT_TYPE,
                          LIMIT_LEVEL,
                          AMOUNT,
                          START_DATE,
                          END_DATE,
                          COVERS_WITH_BILL,
                          DELAI,
                          MODE_REG,
                          CREATION_DATE,
                          CREATOR,
                          CAR_NUMBER,
                          DECISION_COMMENTS,
                          AUTO_UPDATE,
                          AUTO_APPROVAL,
                          IS_LIMIT_REQUEST,
                          TYPE_OF_REQUEST,
                          CLIENT_ID,
                          DEBTOR_ID,
                          IND_GRP_ID,
                          CONTRACT_ID,
                          POLICY_ID,
                          BU_ID,
                          CLIENT_GRP_ID,
                          DEBTOR_GRP_ID,
                          POLICY_TYPE,
                          CI_CF_DECISION_REASON,
                          LINKED_LIMIT_REF,
                          REVISION_DT,
                          CO_FACTOR,
                          CI_CF_DECISION_AMT,
                          CI_CF_DECISION_CCY,
                          CI_CF_DECISION_START_DT,
                          CI_CF_DECISION_END_DT,
                          LRF_DATE,
                          DECISION_DATE )
  WITH CANC AS ( SELECT CONTR.ANCREFDOSS ANCREFDOSS, 
                        CLDB.REFDOSS REFDOSS
                   FROM G_DOSSIER    CLDB,
                        G_DOSSIER    DECOM,
                        G_DOSSIER    CONTR,
                        STD_MIGR_DOS DOS
                  WHERE CLDB.CATEGDOSS IN ('COMPTE', 'COMPTE IMP', 'COMPTE EXP')
                    AND DECOM.REFDOSS = CLDB.REFLOT
                    AND CONTR.REFDOSS = DECOM.REFLOT
                    AND DOS.CONTRACT_NO = CONTR.ANCREFDOSS )
  SELECT /*+ leading(p req md)  */
         REQ.REFPIECE AS LIMIT_REF,
         P.GPIDEVIS AS CURRENCY_LIM,
         CASE
           WHEN P.GPIDEPOT = 'CI' AND P.REFEXT = 'DB' THEN
            'CII'
           ELSE
            NULL
         END AS LIMIT_TYPE,
         CASE
           WHEN P.GPIDEPOT = 'CI' AND P.REFEXT = 'DB' THEN
            'DBP'
           ELSE
            NULL
         END AS LIMIT_LEVEL,
         CASE
           WHEN P.GPIDEPOT = 'CI' AND P.REFEXT = 'DB' THEN
            D.MT01
           ELSE
            REQ.MT02
         END AS AMOUNT,
         CASE
           WHEN P.GPIDEPOT = 'CI' AND P.REFEXT = 'DB' THEN
            D.DT01_DT
           ELSE
            REQ.GPIDTDEB_DT
         END AS START_DATE,
         CASE
           WHEN P.GPIDEPOT = 'CI' AND P.REFEXT = 'DB' THEN
            D.DT02_DT
           ELSE
            REQ.GPIDTFIN_DT
         END AS END_DATE,
   NVL(D.FG02, 'N') AS COVERS_WITH_BILL,
   D.NB01 AS DELAI,
   REQ.ST21 AS MODE_REG,
   P.DT_CREATION_DT AS CREATION_DATE,
   P.CREATEUR AS CREATOR,
   NULL AS CAR_NUMBER,
   P.COMMENTAIRE_1 AS DECISION_COMMENTS,
   REQ.FG10 AS AUTO_UPDATE,
   CASE
     WHEN NVL(D.DT01_DT, TRUNC(SYSDATE)) <= TRUNC(SYSDATE) AND
          NVL(D.DT02_DT, TRUNC(SYSDATE)) >= TRUNC(SYSDATE) THEN
      'O'
     ELSE
      'N'
   END AS AUTO_APPROVAL,
   CASE
     WHEN P.GPIDEPOT = 'CI' AND P.REFEXT = 'DB' THEN
      'N'
     ELSE
      'O'
   END AS IS_LIMIT_REQUEST,
   CASE P.GPIDEPOT
     WHEN 'FIN' THEN
      CASE P.REFEXT
        WHEN 'COM' THEN
         'F'
      END
     WHEN 'C' THEN
      CASE P.REFEXT
        WHEN 'COM' THEN
         'C'
      END
     WHEN 'CI' THEN
      CASE P.REFEXT
        WHEN 'DB' THEN
         NULL
      END
   END AS TYPE_OF_REQUEST,
   P.GPIBUREAU AS CLIENT_ID,
   REQ.GPIADR3 AS DEBTOR_ID,
   NULL AS IND_GRP_ID,
   REQ.GPIHEURE AS CONTRACT_ID,
   POL.REFEXT AS POLICY_ID,
   BU.REFEXT AS BU_ID,
   P.ST01 AS CLIENT_GRP_ID,
   P.GPIROLE AS DEBTOR_GRP_ID,
   DECODE(POL.STR_20_1,
          'CLIENT',
          'LBL',
          'GENERALE',
          'CIC',
          'GLOBAL',
          'GLOBAL') AS POLICY_TYPE,
   NULL AS CI_CF_DECISION_REASON,
   REQ.GPIREFNOTAIRE AS LINKED_LIMIT_REF,
   REQ.DT35_DT AS REVISION_DT,
   CASE
     WHEN CF_PROP.IMX_UN_ID IS NOT NULL THEN
      CASE
        WHEN EXISTS ( SELECT 1
                        FROM G_INDIVIDU
                       WHERE REFINDIVIDU = CF_PROP.STR7
                         AND TYPAUTRE = 'CF' ) THEN
         CF_PROP.STR7
        ELSE
         REQ.LIBELLE_20_11
      END
     ELSE
      REQ.LIBELLE_20_11
   END AS CO_FACTOR,
   CASE
     WHEN P.GPIDEPOT = 'C' THEN
      CF_PROP.MT01
     ELSE
      NULL
   END AS CI_CF_DECISION_AMT,
   CASE
     WHEN P.GPIDEPOT = 'C' THEN
      CF_PROP.STR6
     ELSE
      NULL
   END AS CI_CF_DECISION_CCY,
   CASE
     WHEN P.GPIDEPOT = 'C' THEN
      REQ.GPIDTDEB_DT
     ELSE
      NULL
   END AS CI_CF_DECISION_START_DT,
   CASE
     WHEN P.GPIDEPOT = 'C' THEN
      CF_PROP.DT02_DT
     ELSE
      NULL
   END AS CI_CF_DECISION_END_DT,
   REQ.DT18_DT AS LFR_DATE,
   REQ.DT04_DT AS DECISION_DATE
    FROM G_PIECE      P,
         G_PIECEDET   D,
         G_PIECE      POL,
         G_PIECE      REQ,
         G_PIECEDET   CF_PROP,
         T_INDIVIDU   BU,
         STD_MIGR_DOS MD,
         CANC
   WHERE P.TYPPIECE = 'PARAM_LIMITE'
     AND REQ.TYPPIECE = 'REQUEST_LIMITE'
     AND REQ.GPIHEURE = CANC.ANCREFDOSS(+)
     AND REQ.REFDOSS = CANC.REFDOSS(+)
     AND (   REQ.GPIHEURE IS NULL 
     	    OR (    REQ.GPIHEURE = CANC.ANCREFDOSS
     	        AND REQ.REFDOSS = CANC.REFDOSS ) )
     AND P.STR_20_1 = REQ.REFPIECE
     AND D.REFPIECE = P.REFPIECE
     AND D.TYPE = 'DETAIL_LIMITE'
     AND NVL(P.FG01, 'N') = 'N'
     AND NVL(REQ.FG05, 'N') = 'O'
     AND POL.REFPIECE(+) = REQ.LIBELLE_100_8
     AND POL.TYPPIECE(+) = 'POLICE'
     AND BU.REFINDIVIDU(+) = REQ.GPITYPTRIB
     AND BU.SOCIETE(+) = 'FACTOR_ID'
     AND NOT EXISTS ( SELECT 1
                        FROM V_PROC_CONF
                       WHERE PROC_KEY = 'EXPORT_MIGRATION'
                         AND PARAM_KEY = 'INCORRECT_BU'
                         AND PARAM_VAL = BU.REFEXT )
     AND MD.CONTRACT_NO(+) = REQ.GPIHEURE
     AND (   MD.CONTRACT_NO = REQ.GPIHEURE 
          OR REQ.GPIHEURE IS NULL )
     AND ( P.GPIDEPOT, P.REFEXT ) IN ( ( 'FIN', 'COM' ), ( 'C', 'COM' ), ( 'CI', 'DB' ) )
     AND CF_PROP.REFPIECE(+) = REQ.REFPIECE
     AND CF_PROP.TYPE(+) = 'REQUEST_CF_PROPOSAL'
     AND ( (    P.GPIDEPOT = 'FIN' 
            AND P.REFEXT = 'COM' 
            AND P.GPIBUREAU IS NOT NULL 
            AND P.GPIMARQUE IS NOT NULL
            AND REQ.GPIHEURE IS NOT NULL ) 
         OR (   P.GPIDEPOT = 'C' 
            AND P.REFEXT = 'COM' 
            AND P.GPIBUREAU IS NOT NULL 
            AND P.GPIMARQUE IS NOT NULL
            AND REQ.GPIHEURE IS NOT NULL ) 
         OR (   P.GPIDEPOT = 'CI' 
            AND P.REFEXT = 'DB' 
            AND P.GPIMARQUE IS NOT NULL 
            AND POL.REFEXT IS NOT NULL ) )
     AND P.GPIDEVIS IS NOT NULL
     AND D.MT01 IS NOT NULL
     AND DECODE( P.GPIDEPOT, 
                 'CI', 
                 DECODE( P.REFEXT, 
                         'DB', 
                         D.DT01_DT, 
                         REQ.GPIDTDEB_DT ),
                 REQ.GPIDTDEB_DT ) IS NOT NULL
     AND ORA_HASH(REQ.REFPIECE, :B2) = :B1
  UNION ALL
  SELECT REQ.REFPIECE AS LIMIT_REF,
         REQ.GPIDEVIS AS CURRENCY_LIM,
         NULL AS LIMIT_TYPE,
         NULL AS LIMIT_LEVEL,
         REQ.MT02 AS AMOUNT,
         REQ.GPIDTDEB_DT AS START_DATE,
         REQ.GPIDTFIN_DT AS END_DATE,
         NVL(REQ.FG02, 'N') AS COVERS_WITH_BILL,
         REQ.NB01 AS DELAI,
         REQ.ST21 AS MODE_REG,
         REQ.DT_CREATION_DT AS CREATION_DATE,
         REQ.CREATEUR AS CREATOR,
         NULL AS CAR_NUMBER,
         REQ.COMMENTAIRE_1 AS DECISION_COMMENTS,
         REQ.FG10 AS AUTO_UPDATE,
         CASE
           WHEN NVL(REQ.DT01_DT, TRUNC(SYSDATE)) <= TRUNC(SYSDATE) AND
                NVL(REQ.DT02_DT, TRUNC(SYSDATE)) >= TRUNC(SYSDATE) THEN
            'O'
           ELSE
            'N'
         END AS AUTO_APPROVAL,
         'O' AS IS_LIMIT_REQUEST,
         REQ.TYPEDOC AS TYPE_OF_REQUEST,
         REQ.GPIDEPOT AS CLIENT_ID,
         REQ.GPIADR3 AS DEBTOR_ID,
         NULL AS IND_GRP_ID,
         REQ.GPIHEURE AS CONTRACT_ID,
         CASE
           WHEN (SELECT NVL(FG_MULT_GL_LMT_ALLOW, 'N') FROM G_ETUDE) = 'N' AND
                REQ.TYPEDOC = 'G' THEN
            POL1.REFEXT
           ELSE
            POL.REFEXT
         END AS POLICY_ID,
         BU.REFEXT AS BU_ID,
         REQ.ST24 AS CLIENT_GRP_ID,
         REQ.ST41 AS DEBTOR_GRP_ID,
         CASE
           WHEN ( SELECT NVL(FG_MULT_GL_LMT_ALLOW, 'N') 
                    FROM G_ETUDE ) = 'N'
                 AND REQ.TYPEDOC = 'G' THEN
            DECODE(POL1.STR_20_1,
                   'CLIENT',
                   'LBL',
                   'GENERALE',
                   'CIC',
                   'GLOBAL',
                   'GLOBAL')
           ELSE
            DECODE(POL.STR_20_1,
                   'CLIENT',
                   'LBL',
                   'GENERALE',
                   'CIC',
                   'GLOBAL',
                   'GLOBAL')
         END AS POLICY_TYPE,
         NULL AS CI_CF_DECISION_REASON,
         REQ.GPIREFNOTAIRE AS LINKED_LIMIT_REF,
         REQ.DT35_DT AS REVISION_DT,
         REQ.LIBELLE_20_11 AS CO_FACTOR,
         NULL AS CI_CF_DECISION_AMT,
         NULL AS CI_CF_DECISION_CCY,
         NULL AS CI_CF_DECISION_START_DT,
         NULL AS CI_CF_DECISION_END_DT,
         NULL AS LFR_DATE,
         REQ.DT04_DT AS DECISION_DATE
    FROM G_PIECE      POL,
         G_PIECE      REQ,
         G_PIECEDET   GD,
         G_PIECE      GP,
         G_PIECE      POL1,
         T_INDIVIDU   BU,
         STD_MIGR_DOS MD,
         CANC
   WHERE REQ.TYPPIECE = 'REQUEST_LIMITE'
     AND NVL(REQ.FG05, 'N') = 'O'
     AND REQ.GPIHEURE = CANC.ANCREFDOSS(+)
     AND REQ.REFDOSS = CANC.REFDOSS(+)
     AND (    REQ.GPIHEURE IS NULL 
     	   OR (  REQ.GPIHEURE = CANC.ANCREFDOSS 
     	     AND REQ.REFDOSS = CANC.REFDOSS ) )
     AND POL.REFPIECE(+) = REQ.LIBELLE_100_8
     AND POL.TYPPIECE(+) = 'POLICE'
     AND REQ.TYPEDOC IN ('O', 'G')
     AND GP.TYPPIECE = 'FACTOR'
     AND GP.GPIHEURE = REQ.GPITYPTRIB
     AND GP.REFPIECE = GD.REFPIECE(+)
     AND GD.TYPE(+) = 'POLICIES'
     AND GD.NB01(+) = '1'
     AND POL1.REFPIECE(+) = GD.STR1
     AND POL1.TYPPIECE(+) = 'POLICE'
     AND BU.REFINDIVIDU(+) = REQ.GPITYPTRIB
     AND BU.SOCIETE(+) = 'FACTOR_ID'
     AND NOT EXISTS ( SELECT 1
                        FROM V_PROC_CONF
                       WHERE PROC_KEY = 'EXPORT_MIGRATION'
                         AND PARAM_KEY = 'INCORRECT_BU'
                         AND PARAM_VAL = BU.REFEXT )
     AND MD.CONTRACT_NO(+) = REQ.GPIHEURE
     AND (   MD.CONTRACT_NO = REQ.GPIHEURE 
          OR REQ.GPIHEURE IS NULL )
     AND REQ.GPIDEVIS IS NOT NULL
     AND REQ.MT01 IS NOT NULL
     AND REQ.GPIDTDEB_DT IS NOT NULL
     AND ORA_HASH(REQ.REFPIECE, :B2) = :B1;



-- 33hv83rutznyv

SELECT CL.REFINDIVIDU AS CLIENT_ID,
       DB.REFINDIVIDU AS DEBTOR_ID,
       MIN(FI.REFEXT) || 'DL' AS LIMIT_REF,
       MIN(D.REFDOSS) AS REFDOSS,
       MIN(FI.DT_EMIS_DT) AS START_DATE,
       MAX(FI.DT_EMIS_DT) AS END_DATE
  FROM STD_MIGR_FNC   FNC,
       G_ELEMFI       FI,
       G_DOSSIER      D,
       T_INTERVENANTS CL,
       T_INTERVENANTS DB
 WHERE NOT EXISTS ( SELECT 1
                      FROM G_VENDOSSLIMIT VEN, 
                           G_PIECE L, 
                           STD_MIGR_LIM LIM, 
                           G_PIECE REQ
                     WHERE L.TYPPIECE = 'PARAM_LIMITE'
                       AND L.REFPIECE = VEN.LIMIT_ID
                       AND LIM.LIMIT_REF = REQ.REFPIECE
                       AND REQ.TYPPIECE = 'REQUEST_LIMITE'
                       AND L.STR_20_1 = REQ.REFPIECE
                       AND LIM.TYPE_OF_REQUEST IN ('C', 'CI')
                       AND D.REFDOSS = VEN.REFDOSS )
   AND FI.REFDOSS = D.REFDOSS
   AND FNC.ID_DOCUMENT = FI.REFELEM
   AND FNC.COVER_AMT IS NOT NULL
   AND FNC.COVER_AMT > 0
   AND CL.REFDOSS = D.REFDOSS
   AND CL.REFTYPE = 'CL'
   AND DB.REFDOSS = D.REFDOSS
   AND DB.REFTYPE = 'DB'
 GROUP BY CL.REFINDIVIDU, DB.REFINDIVIDU;
/********************************OLD SQL*******************************************/
/********************************OLD Metrics***************************************/
/*

MODULE                           SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
std_migr_exp_mvt.export_lim      fafhapr9yv6j6  488448047         54      21252                      2024/10/11 12:25:25  2024/10/11 12:52:25         163                    1 +000000000 00:27:00.196 42%
std_migr_exp_mvt.export_lim      33hv83rutznyv 1020983754         54      21252                      2024/10/11 13:00:15  2024/10/11 13:21:55         131                    1 +000000000 00:21:40.202 34%


INSTANCE_NUMBER SQL_ID            ELAPSED MAX_WAIT_ON     PC_OF  WAIT_TIME            GETS      READS       ROWS  ELAP/EXEC       GETS/EXEC READS/EXEC  ROWS/EXEC       EXEC PLAN_HASH_VALUE
--------------- ------------- ----------- --------------- ----- ---------- --------------- ---------- ---------- ---------- --------------- ---------- ---------- ---------- ---------------
              1 33hv83rutznyv        1304 IO              96%    1254.7298        21856390    1674235        195    1304.27        21856390    1674235        195          1      1020983754
              1 fafhapr9yv6j6        1636 IO              96%   1581.09277        22065597    3335351     587913    1635.59        22065597    3335351     587913          1       488448047


EUROFACTOR-UAT1-std_migr_exp_mvt.export_lim-fafhapr9yv6j6-16-10-2024
              

SQL_ID        SQL_PLAN_HASH_VALUE SQL_PLAN_LINE_ID SQL_PLAN_OPERATION             SQL_PLAN_OPTIONS                   ACTIVE
------------- ------------------- ---------------- ------------------------------ ------------------------------ ----------
fafhapr9yv6j6           488448047               29 TABLE ACCESS                   BY INDEX ROWID BATCHED                 73
fafhapr9yv6j6           488448047               42 TABLE ACCESS                   BY INDEX ROWID BATCHED                 23
fafhapr9yv6j6           488448047               43 INDEX                          RANGE SCAN                             19
fafhapr9yv6j6           488448047               45 INDEX                          RANGE SCAN                             16
fafhapr9yv6j6           488448047               58 TABLE ACCESS                   BY INDEX ROWID BATCHED                  8
fafhapr9yv6j6           488448047               32 TABLE ACCESS                   BY INDEX ROWID                          6
fafhapr9yv6j6           488448047               44 TABLE ACCESS                   BY INDEX ROWID BATCHED                  5
fafhapr9yv6j6           488448047               59 INDEX                          SKIP SCAN                               4
fafhapr9yv6j6           488448047               30 INDEX                          RANGE SCAN                              3
fafhapr9yv6j6           488448047               31 INDEX                          RANGE SCAN                              3
fafhapr9yv6j6           488448047               11 INDEX                          FULL SCAN                               2
fafhapr9yv6j6           488448047               39 INDEX                          RANGE SCAN                              1


SQL_ID        SQL_PLAN_HASH_VALUE SQL_PLAN_LINE_ID SQL_PLAN_OPERATION             SQL_PLAN_OPTIONS                   ACTIVE
------------- ------------------- ---------------- ------------------------------ ------------------------------ ----------
33hv83rutznyv          1020983754               13 TABLE ACCESS                   BY INDEX ROWID BATCHED                 80
33hv83rutznyv          1020983754               15 TABLE ACCESS                   BY INDEX ROWID BATCHED                 27
33hv83rutznyv          1020983754               16 INDEX                          RANGE SCAN                             15
33hv83rutznyv          1020983754               23 INDEX                          UNIQUE SCAN                             2
33hv83rutznyv          1020983754               24 TABLE ACCESS                   BY INDEX ROWID                          2
33hv83rutznyv          1020983754               17 TABLE ACCESS                   BY INDEX ROWID BATCHED                  2
33hv83rutznyv          1020983754               14 INDEX                          RANGE SCAN                              1
33hv83rutznyv          1020983754               26 INDEX                          SKIP SCAN                               1
33hv83rutznyv          1020983754                3 INDEX                          SKIP SCAN                               1

-- fafhapr9yv6j6

Plan hash value: 488448047
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                           | Name                        | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  | Writes |
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------
|   0 | INSERT STATEMENT                                    |                             |      1 |        |  4383 (100)|      0 |00:26:01.49 |      22M|   3323K|    360 |
|   1 |  TEMP TABLE TRANSFORMATION                          |                             |      1 |        |            |      0 |00:26:01.49 |      22M|   3323K|    360 |
|   2 |   LOAD AS SELECT (CURSOR DURATION MEMORY)           | SYS_TEMP_0FD9D6849_723EC1AD |      1 |        |            |      0 |00:00:07.48 |   18855 |   9642 |      0 |
|*  3 |    HASH JOIN                                        |                             |      1 |   7119 |  1068   (1)|    337K|00:00:07.39 |   18854 |   9642 |      0 |
|*  4 |     HASH JOIN                                       |                             |      1 |  31949 |   572   (1)|   6361 |00:00:02.58 |   12424 |   3212 |      0 |
|   5 |      NESTED LOOPS                                   |                             |      1 |   7488 |   538   (0)|   4541 |00:00:00.13 |    9382 |    170 |      0 |
|   6 |       NESTED LOOPS                                  |                             |      1 |  30655 |   538   (0)|   4541 |00:00:00.11 |    4882 |    170 |      0 |
|   7 |        TABLE ACCESS FULL                            | STD_MIGR_DOS                |      1 |   6131 |   109   (0)|   4541 |00:00:00.03 |     626 |     88 |      0 |
|*  8 |        INDEX RANGE SCAN                             | DOS_ANCREFDOSS              |   4541 |      5 |     1   (0)|   4541 |00:00:00.08 |    4256 |     82 |      0 |
|   9 |       TABLE ACCESS BY INDEX ROWID                   | G_DOSSIER                   |   4541 |      1 |     1   (0)|   4541 |00:00:00.02 |    4500 |      0 |      0 |
|  10 |      INDEX FULL SCAN                                | DOS_REFDOSS_REFLOT_IDX      |      1 |    685K|    30   (0)|    685K|00:00:02.28 |    3042 |   3042 |      0 |
|* 11 |     INDEX FULL SCAN                                 | G_DOSSIER_RL_CD_RD_RF_IDX   |      1 |    158K|    64   (0)|    633K|00:00:04.61 |    6430 |   6430 |      0 |
|  12 |   LOAD TABLE CONVENTIONAL                           | STD_MIGR_LIM                |      1 |        |            |      0 |00:25:54.01 |      22M|   3314K|    360 |
|  13 |    UNION-ALL                                        |                             |      1 |        |            |    587K|00:25:38.54 |      21M|   3311K|    360 |
|* 14 |     TABLE ACCESS BY INDEX ROWID                     | G_INDIVIDU                  |     14 |      1 |     1   (0)|      1 |00:00:00.02 |      52 |     19 |      0 |
|* 15 |      INDEX UNIQUE SCAN                              | IND_REFINDIV                |     14 |      1 |     1   (0)|     13 |00:00:00.01 |      39 |     10 |      0 |
|  16 |     NESTED LOOPS OUTER                              |                             |      1 |      1 |   133   (0)|    496K|00:23:07.44 |      18M|   2137K|    360 |
|  17 |      NESTED LOOPS                                   |                             |      1 |      1 |   132   (0)|    496K|00:20:29.68 |      16M|   1987K|    360 |
|  18 |       NESTED LOOPS ANTI                             |                             |      1 |      1 |   131   (0)|    496K|00:13:41.89 |      14M|   1583K|    360 |
|  19 |        NESTED LOOPS OUTER                           |                             |      1 |      1 |   130   (0)|    496K|00:13:41.34 |      14M|   1583K|    360 |
|* 20 |         FILTER                                      |                             |      1 |        |            |    496K|00:13:33.35 |      13M|   1583K|    360 |
|* 21 |          HASH JOIN OUTER                            |                             |      1 |      1 |   129   (0)|    496K|00:13:32.49 |      13M|   1583K|    360 |
|* 22 |           FILTER                                    |                             |      1 |        |            |    496K|00:13:27.75 |      13M|   1583K|      0 |
|  23 |            NESTED LOOPS OUTER                       |                             |      1 |      1 |   112   (0)|    496K|00:13:27.61 |      13M|   1583K|      0 |
|* 24 |             FILTER                                  |                             |      1 |        |            |    496K|00:13:25.34 |      12M|   1582K|      0 |
|* 25 |              HASH JOIN OUTER                        |                             |      1 |      1 |   111   (0)|    855K|00:13:25.19 |      12M|   1582K|      0 |
|  26 |               NESTED LOOPS                          |                             |      1 |      1 |     2   (0)|    855K|00:13:22.00 |      12M|   1582K|      0 |
|  27 |                NESTED LOOPS                         |                             |      1 |      1 |     2   (0)|   1792K|00:08:18.03 |    9936K|   1251K|      0 |
|  28 |                 INLIST ITERATOR                     |                             |      1 |        |            |   1794K|00:05:34.05 |    4633K|   1092K|      0 |
|* 29 |                  TABLE ACCESS BY INDEX ROWID BATCHED| G_PIECE                     |      2 |      1 |     1   (0)|   1794K|00:05:33.62 |    4633K|   1092K|      0 |
|* 30 |                   INDEX RANGE SCAN                  | PIECE_REFEXT_IDX            |      2 |      1 |     1   (0)|   3390K|00:00:16.79 |   16153 |  16153 |      0 |
|* 31 |                 INDEX RANGE SCAN                    | PIE_REFPIECE                |   1794K|      1 |     1   (0)|   1792K|00:02:42.35 |    5303K|    158K|      0 |
|* 32 |                TABLE ACCESS BY INDEX ROWID          | G_PIECE                     |   1792K|      1 |     1   (0)|    855K|00:05:02.62 |    2972K|    331K|      0 |
|  33 |               TABLE ACCESS FULL                     | STD_MIGR_DOS                |      1 |   6131 |   109   (0)|   4541 |00:00:00.12 |     626 |    542 |      0 |
|* 34 |             TABLE ACCESS BY INDEX ROWID BATCHED     | G_PIECE                     |    496K|      1 |     1   (0)|    429K|00:00:02.14 |     473K|    478 |      0 |
|* 35 |              INDEX RANGE SCAN                       | PIE_REFPIECE                |    496K|      1 |     1   (0)|    429K|00:00:00.69 |   41559 |    160 |      0 |
|  36 |           VIEW                                      |                             |      1 |   7119 |    17   (0)|    337K|00:00:00.84 |       0 |      0 |      0 |
|  37 |            TABLE ACCESS FULL                        | SYS_TEMP_0FD9D6849_723EC1AD |      1 |   7119 |    17   (0)|    337K|00:00:00.57 |       0 |      0 |      0 |
|* 38 |         TABLE ACCESS BY INDEX ROWID BATCHED         | T_INDIVIDU                  |    496K|      1 |     1   (0)|    496K|00:00:07.44 |     949K|     13 |      0 |
|* 39 |          INDEX RANGE SCAN                           | IX_T_INDIVIDU               |    496K|      4 |     1   (0)|   3171K|00:00:02.30 |   10297 |      9 |      0 |
|* 40 |        TABLE ACCESS BY INDEX ROWID BATCHED          | V_PROC_CONF                 |      7 |      1 |     1   (0)|      0 |00:00:00.01 |      17 |      3 |      0 |
|* 41 |         INDEX RANGE SCAN                            | V_PROC_CONF_PROC_KEY_IDX    |      7 |      3 |     1   (0)|     49 |00:00:00.01 |       3 |      1 |      0 |
|  42 |       TABLE ACCESS BY INDEX ROWID BATCHED           | G_PIECEDET                  |    496K|      1 |     1   (0)|    496K|00:06:47.22 |    2248K|    403K|      0 |
|* 43 |        INDEX RANGE SCAN                             | G_PIECEDET_REFP             |    496K|      1 |     1   (0)|    496K|00:03:52.09 |    1965K|    223K|      0 |
|  44 |      TABLE ACCESS BY INDEX ROWID BATCHED            | G_PIECEDET                  |    496K|      1 |     1   (0)|    208K|00:02:36.76 |    2145K|    150K|      0 |
|* 45 |       INDEX RANGE SCAN                              | G_PIECEDET_REFP             |    496K|      1 |     1   (0)|    208K|00:01:45.34 |    1981K|    100K|      0 |
|  46 |     TABLE ACCESS FULL                               | G_ETUDE                     |      1 |      1 |     2   (0)|      1 |00:00:00.01 |       4 |      0 |      0 |
|  47 |     TABLE ACCESS FULL                               | G_ETUDE                     |      1 |      1 |     2   (0)|      1 |00:00:00.01 |       4 |      0 |      0 |
|  48 |     NESTED LOOPS ANTI                               |                             |      1 |      1 |  4245   (1)|  91657 |00:02:25.62 |    2469K|   1173K|      0 |
|  49 |      NESTED LOOPS OUTER                             |                             |      1 |      1 |  4244   (1)|  96523 |00:02:25.59 |    2469K|   1173K|      0 |
|  50 |       NESTED LOOPS OUTER                            |                             |      1 |      1 |  4243   (1)|  96523 |00:02:25.18 |    2362K|   1173K|      0 |
|  51 |        NESTED LOOPS OUTER                           |                             |      1 |      1 |  4242   (1)|  96523 |00:02:24.77 |    2256K|   1173K|      0 |
|  52 |         NESTED LOOPS                                |                             |      1 |      1 |  4241   (1)|  96523 |00:02:24.20 |    1867K|   1173K|      0 |
|  53 |          NESTED LOOPS OUTER                         |                             |      1 |      1 |  4240   (1)|  96523 |00:02:23.97 |    1864K|   1173K|      0 |
|* 54 |           FILTER                                    |                             |      1 |        |            |  96523 |00:02:23.25 |    1670K|   1173K|      0 |
|* 55 |            HASH JOIN OUTER                          |                             |      1 |      1 |  4239   (1)|  96523 |00:02:23.23 |    1670K|   1173K|      0 |
|* 56 |             FILTER                                  |                             |      1 |        |            |  96523 |00:02:22.93 |    1670K|   1173K|      0 |
|* 57 |              HASH JOIN OUTER                        |                             |      1 |      1 |  4222   (1)|  96565 |00:02:22.93 |    1670K|   1173K|      0 |
|* 58 |               TABLE ACCESS BY INDEX ROWID BATCHED   | G_PIECE                     |      1 |      1 |  4113   (1)|  96565 |00:02:22.65 |    1670K|   1173K|      0 |
|* 59 |                INDEX SKIP SCAN                      | GP_REFEXT_IDX               |      1 |  16200 |  4051   (1)|   2747K|00:00:23.08 |   21506 |  21506 |      0 |
|  60 |               TABLE ACCESS FULL                     | STD_MIGR_DOS                |      1 |   6131 |   109   (0)|   4541 |00:00:00.04 |     626 |    623 |      0 |
|  61 |             VIEW                                    |                             |      1 |   7119 |    17   (0)|    337K|00:00:00.05 |       0 |      0 |      0 |
|  62 |              TABLE ACCESS FULL                      | SYS_TEMP_0FD9D6849_723EC1AD |      1 |   7119 |    17   (0)|    337K|00:00:00.02 |       0 |      0 |      0 |
|* 63 |           TABLE ACCESS BY INDEX ROWID BATCHED       | T_INDIVIDU                  |  96523 |      1 |     1   (0)|  96523 |00:00:00.68 |     193K|      1 |      0 |
|* 64 |            INDEX RANGE SCAN                         | IX_T_INDIVIDU               |  96523 |      4 |     1   (0)|    635K|00:00:00.21 |   13613 |      1 |      0 |
|  65 |          TABLE ACCESS BY INDEX ROWID BATCHED        | G_PIECE                     |  96523 |      1 |     1   (0)|  96523 |00:00:00.20 |    2196 |     12 |      0 |
|* 66 |           INDEX RANGE SCAN                          | GP_GRTYPE_MT_DT             |  96523 |      1 |     1   (0)|  96523 |00:00:00.12 |      18 |      4 |      0 |
|  67 |         TABLE ACCESS BY INDEX ROWID BATCHED         | G_PIECEDET                  |  96523 |      1 |     1   (0)|  96523 |00:00:00.52 |     389K|     21 |      0 |
|* 68 |          INDEX RANGE SCAN                           | G_PIECEDET_REFP             |  96523 |      1 |     1   (0)|  96523 |00:00:00.44 |     387K|     13 |      0 |
|* 69 |        TABLE ACCESS BY INDEX ROWID BATCHED          | G_PIECE                     |  96523 |      1 |     1   (0)|  96213 |00:00:00.37 |     106K|      6 |      0 |
|* 70 |         INDEX RANGE SCAN                            | PIE_REFPIECE                |  96523 |      1 |     1   (0)|  96213 |00:00:00.10 |    8990 |      2 |      0 |
|* 71 |       TABLE ACCESS BY INDEX ROWID BATCHED           | G_PIECE                     |  96523 |      1 |     1   (0)|  96523 |00:00:00.36 |     106K|      0 |      0 |
|* 72 |        INDEX RANGE SCAN                             | PIE_REFPIECE                |  96523 |      1 |     1   (0)|  96523 |00:00:00.11 |    8994 |      0 |      0 |
|* 73 |      TABLE ACCESS BY INDEX ROWID BATCHED            | V_PROC_CONF                 |      8 |      1 |     1   (0)|      1 |00:00:00.01 |      17 |      1 |      0 |
|* 74 |       INDEX RANGE SCAN                              | V_PROC_CONF_PROC_KEY_IDX    |      8 |      3 |     1   (0)|     50 |00:00:00.01 |       3 |      1 |      0 |
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   3 - access("DECOM"."REFDOSS"="CLDB"."REFLOT")
   4 - access("CONTR"."REFDOSS"="DECOM"."REFLOT")
   8 - access("DOS"."CONTRACT_NO"="CONTR"."ANCREFDOSS")
       filter("CONTR"."ANCREFDOSS" IS NOT NULL)
  11 - filter(("CLDB"."CATEGDOSS"='COMPTE' OR "CLDB"."CATEGDOSS"='COMPTE EXP' OR "CLDB"."CATEGDOSS"='COMPTE IMP'))
  14 - filter("TYPAUTRE"='CF')
  15 - access("REFINDIVIDU"=:B1)
  20 - filter(("REQ"."GPIHEURE" IS NULL OR ("REQ"."GPIHEURE"="CANC"."ANCREFDOSS" AND "REQ"."REFDOSS"="CANC"."REFDOSS")))
  21 - access("REQ"."GPIHEURE"="CANC"."ANCREFDOSS" AND "REQ"."REFDOSS"="CANC"."REFDOSS")
  22 - filter((("P"."GPIDEPOT"='FIN' AND "P"."REFEXT"='COM' AND "P"."GPIBUREAU" IS NOT NULL AND "P"."GPIMARQUE" IS NOT NULL AND "REQ"."GPIHEURE" IS NOT NULL) OR
              ("P"."GPIDEPOT"='C' AND "P"."REFEXT"='COM' AND "P"."GPIBUREAU" IS NOT NULL AND "P"."GPIMARQUE" IS NOT NULL AND "REQ"."GPIHEURE" IS NOT NULL) OR
              ("P"."GPIDEPOT"='CI' AND "P"."REFEXT"='DB' AND "P"."GPIMARQUE" IS NOT NULL AND "POL"."REFEXT" IS NOT NULL)))
  24 - filter(("MD"."CONTRACT_NO"="REQ"."GPIHEURE" OR "REQ"."GPIHEURE" IS NULL))
  25 - access("MD"."CONTRACT_NO"="REQ"."GPIHEURE")
  29 - filter(("P"."STR_20_1" IS NOT NULL AND "P"."GPIDEVIS" IS NOT NULL AND (("P"."GPIDEPOT"='C' AND "P"."REFEXT"='COM') OR ("P"."GPIDEPOT"='CI' AND
              "P"."REFEXT"='DB') OR ("P"."GPIDEPOT"='FIN' AND "P"."REFEXT"='COM')) AND NVL("P"."FG01",'N')='N'))
  30 - access(("P"."REFEXT"='COM' OR "P"."REFEXT"='DB') AND "P"."TYPPIECE"='PARAM_LIMITE')
  31 - access("P"."STR_20_1"="REQ"."REFPIECE")
       filter(ORA_HASH("REQ"."REFPIECE",:B2)=:B1)
  32 - filter(("REQ"."TYPPIECE"='REQUEST_LIMITE' AND NVL("REQ"."FG05",'N')='O'))
  34 - filter("POL"."TYPPIECE"='POLICE')
  35 - access("POL"."REFPIECE"="REQ"."LIBELLE_100_8")
  38 - filter("BU"."SOCIETE"='FACTOR_ID')
  39 - access("BU"."REFINDIVIDU"="REQ"."GPITYPTRIB")
  40 - filter(("PARAM_VAL"="BU"."REFEXT" AND "PARAM_KEY"='INCORRECT_BU'))
  41 - access("PROC_KEY"='EXPORT_MIGRATION')
  43 - access("D"."REFPIECE"="P"."REFPIECE" AND "D"."TYPE"='DETAIL_LIMITE')
       filter(("D"."MT01" IS NOT NULL AND DECODE("P"."GPIDEPOT",'CI',DECODE("P"."REFEXT",'DB',"D"."DT01_DT","REQ"."GPIDTDEB_DT"),"REQ"."GPIDTDEB_DT") IS NOT NULL))
  45 - access("CF_PROP"."REFPIECE"="REQ"."REFPIECE" AND "CF_PROP"."TYPE"='REQUEST_CF_PROPOSAL')
  54 - filter(("REQ"."GPIHEURE" IS NULL OR ("REQ"."GPIHEURE"="CANC"."ANCREFDOSS" AND "REQ"."REFDOSS"="CANC"."REFDOSS")))
  55 - access("REQ"."GPIHEURE"="CANC"."ANCREFDOSS" AND "REQ"."REFDOSS"="CANC"."REFDOSS")
  56 - filter(("MD"."CONTRACT_NO"="REQ"."GPIHEURE" OR "REQ"."GPIHEURE" IS NULL))
  57 - access("MD"."CONTRACT_NO"="REQ"."GPIHEURE")
  58 - filter(("REQ"."GPIDTDEB_DT" IS NOT NULL AND "REQ"."GPITYPTRIB" IS NOT NULL AND "REQ"."GPIDEVIS" IS NOT NULL AND "REQ"."MT01" IS NOT NULL AND
              INTERNAL_FUNCTION("REQ"."TYPEDOC") AND NVL("REQ"."FG05",'N')='O'))
  59 - access("REQ"."TYPPIECE"='REQUEST_LIMITE')
       filter(("REQ"."TYPPIECE"='REQUEST_LIMITE' AND ORA_HASH("REQ"."REFPIECE",:B2)=:B1))
  63 - filter("BU"."SOCIETE"='FACTOR_ID')
  64 - access("BU"."REFINDIVIDU"="REQ"."GPITYPTRIB")
  66 - access("GP"."TYPPIECE"='FACTOR' AND "GP"."GPIHEURE"="REQ"."GPITYPTRIB")
       filter("GP"."GPIHEURE" IS NOT NULL)
  68 - access("GP"."REFPIECE"="GD"."REFPIECE" AND "GD"."TYPE"='POLICIES' AND "GD"."NB01"=1)
       filter("GD"."NB01"=1)
  69 - filter("POL"."TYPPIECE"='POLICE')
  70 - access("POL"."REFPIECE"="REQ"."LIBELLE_100_8")
  71 - filter("POL1"."TYPPIECE"='POLICE')
  72 - access("POL1"."REFPIECE"="GD"."STR1")
  73 - filter(("PARAM_VAL"="BU"."REFEXT" AND "PARAM_KEY"='INCORRECT_BU'))
  74 - access("PROC_KEY"='EXPORT_MIGRATION')


-- 33hv83rutznyv

Plan hash value: 1020983754
-----------------------------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                      | Name                           | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  |
-----------------------------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                               |                                |      1 |        | 42211 (100)|      0 |00:00:00.01 |       0 |      0 |
|   1 |  HASH GROUP BY                                 |                                |      1 |  14417 | 42211   (1)|      0 |00:00:00.01 |       0 |      0 |
|*  2 |   HASH JOIN                                    |                                |      1 |  14417 | 41632   (1)|      0 |00:00:00.01 |       0 |      0 |
|*  3 |    INDEX SKIP SCAN                             | INT_REFDOSS                    |      1 |    136K|   103   (0)|    685K|00:00:07.76 |   10039 |   9159 |
|   4 |    MERGE JOIN                                  |                                |      1 |  71095 | 40724   (1)|      0 |00:00:00.01 |       0 |      0 |
|   5 |     SORT JOIN                                  |                                |      1 |    350K| 39661   (1)|      0 |00:00:00.01 |       0 |      0 |
|   6 |      VIEW                                      | VW_GBC_18                      |      1 |    350K| 39661   (1)|      0 |00:00:00.01 |       0 |      0 |
|   7 |       HASH GROUP BY                            |                                |      1 |    350K| 39661   (1)|      0 |00:00:00.01 |       0 |      0 |
|*  8 |        HASH JOIN RIGHT ANTI                    |                                |      1 |    819K| 39633   (1)|      0 |00:00:00.01 |       0 |      0 |
|   9 |         VIEW                                   | VW_SQ_1                        |      1 |   7639 | 11019   (1)|  63771 |00:04:20.46 |    2845K|    282K|
|  10 |          NESTED LOOPS                          |                                |      1 |   7639 | 11019   (1)|  63771 |00:04:20.45 |    2845K|    282K|
|  11 |           NESTED LOOPS SEMI                    |                                |      1 |   6051 | 10898   (1)|  58519 |00:04:17.58 |    2756K|    279K|
|  12 |            NESTED LOOPS                        |                                |      1 |  79141 |  9315   (1)|    432K|00:04:10.07 |    2220K|    274K|
|* 13 |             TABLE ACCESS BY INDEX ROWID BATCHED| G_PIECE                        |      1 |  79141 |  6148   (1)|    434K|00:02:10.19 |     636K|    156K|
|* 14 |              INDEX RANGE SCAN                  | PIECE_TYP_MT43_IDX             |      1 |   4050K|   166   (1)|    464K|00:00:01.99 |    1874 |   1870 |
|* 15 |             TABLE ACCESS BY INDEX ROWID BATCHED| G_PIECE                        |    434K|      1 |     1   (0)|    432K|00:01:59.61 |    1584K|    117K|
|* 16 |              INDEX RANGE SCAN                  | PIE_REFPIECE                   |    434K|      1 |     1   (0)|    434K|00:00:36.21 |    1255K|  35148 |
|* 17 |            TABLE ACCESS BY INDEX ROWID BATCHED | STD_MIGR_LIM                   |    348K|  17802 |     1   (0)|  36874 |00:00:07.03 |     535K|   5785 |
|* 18 |             INDEX RANGE SCAN                   | STD_MIGR_LIM_LIMIT_REF         |    348K|      1 |     1   (0)|  71039 |00:00:01.87 |     491K|    456 |
|* 19 |           INDEX RANGE SCAN                     | G_VENDOSSLIMIT$REFDOSS_LIMITID |  58519 |      1 |     1   (0)|  63771 |00:00:02.82 |   88701 |   2587 |
|  20 |         NESTED LOOPS                           |                                |      0 |    828K| 28611   (1)|      0 |00:00:00.01 |       0 |      0 |
|  21 |          NESTED LOOPS                          |                                |      0 |    828K| 28611   (1)|      0 |00:00:00.01 |       0 |      0 |
|* 22 |           TABLE ACCESS FULL                    | STD_MIGR_FNC                   |      0 |    828K|  3738   (1)|      0 |00:00:00.01 |       0 |      0 |
|* 23 |           INDEX UNIQUE SCAN                    | EFI_REFELEM                    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 24 |          TABLE ACCESS BY INDEX ROWID           | G_ELEMFI                       |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 25 |     SORT JOIN                                  |                                |      0 |    136K|  1062   (1)|      0 |00:00:00.01 |       0 |      0 |
|* 26 |      INDEX SKIP SCAN                           | INT_REFDOSS                    |      0 |    136K|   103   (0)|      0 |00:00:00.01 |       0 |      0 |
-----------------------------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   2 - access("DB"."REFDOSS"="ITEM_1")
   3 - access("DB"."REFTYPE"='DB')
       filter("DB"."REFTYPE"='DB')
   8 - access("FI"."REFDOSS"="ITEM_1")
  13 - filter("L"."STR_20_1" IS NOT NULL)
  14 - access("L"."TYPPIECE"='PARAM_LIMITE')
  15 - filter("REQ"."TYPPIECE"='REQUEST_LIMITE')
  16 - access("L"."STR_20_1"="REQ"."REFPIECE")
  17 - filter(("LIM"."TYPE_OF_REQUEST"='C' OR "LIM"."TYPE_OF_REQUEST"='CI'))
  18 - access("LIM"."LIMIT_REF"="REQ"."REFPIECE")
  19 - access("L"."REFPIECE"="VEN"."LIMIT_ID")
  22 - filter("FNC"."COVER_AMT">0)
  23 - access("FNC"."ID_DOCUMENT"="FI"."REFELEM")
  24 - filter("FI"."REFDOSS" IS NOT NULL)
  25 - access("CL"."REFDOSS"="ITEM_1")
       filter("CL"."REFDOSS"="ITEM_1")
  26 - access("CL"."REFTYPE"='CL')
       filter("CL"."REFTYPE"='CL')

*/
/********************************OLD Metrics***************************************/

/********************************New SQL*******************************************/
-- fafhapr9yv6j6

INSERT INTO STD_MIGR_LIM( LIMIT_REF,
                          CURRENCY_LIM,
                          LIMIT_TYPE,
                          LIMIT_LEVEL,
                          AMOUNT,
                          START_DATE,
                          END_DATE,
                          COVERS_WITH_BILL,
                          DELAI,
                          MODE_REG,
                          CREATION_DATE,
                          CREATOR,
                          CAR_NUMBER,
                          DECISION_COMMENTS,
                          AUTO_UPDATE,
                          AUTO_APPROVAL,
                          IS_LIMIT_REQUEST,
                          TYPE_OF_REQUEST,
                          CLIENT_ID,
                          DEBTOR_ID,
                          IND_GRP_ID,
                          CONTRACT_ID,
                          POLICY_ID,
                          BU_ID,
                          CLIENT_GRP_ID,
                          DEBTOR_GRP_ID,
                          POLICY_TYPE,
                          CI_CF_DECISION_REASON,
                          LINKED_LIMIT_REF,
                          REVISION_DT,
                          CO_FACTOR,
                          CI_CF_DECISION_AMT,
                          CI_CF_DECISION_CCY,
                          CI_CF_DECISION_START_DT,
                          CI_CF_DECISION_END_DT,
                          LRF_DATE,
                          DECISION_DATE )
  WITH CANC AS ( SELECT CONTR.ANCREFDOSS ANCREFDOSS, 
                        CLDB.REFDOSS REFDOSS
                   FROM G_DOSSIER    CLDB,
                        G_DOSSIER    DECOM,
                        G_DOSSIER    CONTR,
                        STD_MIGR_DOS DOS
                  WHERE CLDB.CATEGDOSS IN ('COMPTE', 'COMPTE IMP', 'COMPTE EXP')
                    AND DECOM.REFDOSS = CLDB.REFLOT
                    AND CONTR.REFDOSS = DECOM.REFLOT
                    AND DOS.CONTRACT_NO = CONTR.ANCREFDOSS ),
       LIM AS ( SELECT /*+ materialize full(G_PIECE) parallel(4) */
                       *
                  FROM G_PIECE
                 WHERE TYPPIECE IN ( 'REQUEST_LIMITE', 'PARAM_LIMITE' )    )         
  SELECT /*+ leading(p req md) */
         REQ.REFPIECE AS LIMIT_REF,
         P.GPIDEVIS AS CURRENCY_LIM,
         CASE
           WHEN P.GPIDEPOT = 'CI' AND P.REFEXT = 'DB' THEN
            'CII'
           ELSE
            NULL
         END AS LIMIT_TYPE,
         CASE
           WHEN P.GPIDEPOT = 'CI' AND P.REFEXT = 'DB' THEN
            'DBP'
           ELSE
            NULL
         END AS LIMIT_LEVEL,
         CASE
           WHEN P.GPIDEPOT = 'CI' AND P.REFEXT = 'DB' THEN
            D.MT01
           ELSE
            REQ.MT02
         END AS AMOUNT,
         CASE
           WHEN P.GPIDEPOT = 'CI' AND P.REFEXT = 'DB' THEN
            D.DT01_DT
           ELSE
            REQ.GPIDTDEB_DT
         END AS START_DATE,
         CASE
           WHEN P.GPIDEPOT = 'CI' AND P.REFEXT = 'DB' THEN
            D.DT02_DT
           ELSE
            REQ.GPIDTFIN_DT
         END AS END_DATE,
   NVL(D.FG02, 'N') AS COVERS_WITH_BILL,
   D.NB01 AS DELAI,
   REQ.ST21 AS MODE_REG,
   P.DT_CREATION_DT AS CREATION_DATE,
   P.CREATEUR AS CREATOR,
   NULL AS CAR_NUMBER,
   P.COMMENTAIRE_1 AS DECISION_COMMENTS,
   REQ.FG10 AS AUTO_UPDATE,
   CASE
     WHEN NVL(D.DT01_DT, TRUNC(SYSDATE)) <= TRUNC(SYSDATE) AND
          NVL(D.DT02_DT, TRUNC(SYSDATE)) >= TRUNC(SYSDATE) THEN
      'O'
     ELSE
      'N'
   END AS AUTO_APPROVAL,
   CASE
     WHEN P.GPIDEPOT = 'CI' AND P.REFEXT = 'DB' THEN
      'N'
     ELSE
      'O'
   END AS IS_LIMIT_REQUEST,
   CASE P.GPIDEPOT
     WHEN 'FIN' THEN
      CASE P.REFEXT
        WHEN 'COM' THEN
         'F'
      END
     WHEN 'C' THEN
      CASE P.REFEXT
        WHEN 'COM' THEN
         'C'
      END
     WHEN 'CI' THEN
      CASE P.REFEXT
        WHEN 'DB' THEN
         NULL
      END
   END AS TYPE_OF_REQUEST,
   P.GPIBUREAU AS CLIENT_ID,
   REQ.GPIADR3 AS DEBTOR_ID,
   NULL AS IND_GRP_ID,
   REQ.GPIHEURE AS CONTRACT_ID,
   POL.REFEXT AS POLICY_ID,
   BU.REFEXT AS BU_ID,
   P.ST01 AS CLIENT_GRP_ID,
   P.GPIROLE AS DEBTOR_GRP_ID,
   DECODE(POL.STR_20_1,
          'CLIENT',
          'LBL',
          'GENERALE',
          'CIC',
          'GLOBAL',
          'GLOBAL') AS POLICY_TYPE,
   NULL AS CI_CF_DECISION_REASON,
   REQ.GPIREFNOTAIRE AS LINKED_LIMIT_REF,
   REQ.DT35_DT AS REVISION_DT,
   CASE
     WHEN CF_PROP.IMX_UN_ID IS NOT NULL THEN
      CASE
        WHEN EXISTS ( SELECT 1
                        FROM G_INDIVIDU
                       WHERE REFINDIVIDU = CF_PROP.STR7
                         AND TYPAUTRE = 'CF' ) THEN
         CF_PROP.STR7
        ELSE
         REQ.LIBELLE_20_11
      END
     ELSE
      REQ.LIBELLE_20_11
   END AS CO_FACTOR,
   CASE
     WHEN P.GPIDEPOT = 'C' THEN
      CF_PROP.MT01
     ELSE
      NULL
   END AS CI_CF_DECISION_AMT,
   CASE
     WHEN P.GPIDEPOT = 'C' THEN
      CF_PROP.STR6
     ELSE
      NULL
   END AS CI_CF_DECISION_CCY,
   CASE
     WHEN P.GPIDEPOT = 'C' THEN
      REQ.GPIDTDEB_DT
     ELSE
      NULL
   END AS CI_CF_DECISION_START_DT,
   CASE
     WHEN P.GPIDEPOT = 'C' THEN
      CF_PROP.DT02_DT
     ELSE
      NULL
   END AS CI_CF_DECISION_END_DT,
   REQ.DT18_DT AS LFR_DATE,
   REQ.DT04_DT AS DECISION_DATE
    FROM LIM      P,
         G_PIECEDET   D,
         G_PIECE      POL,
         LIM      REQ,
         G_PIECEDET   CF_PROP,
         T_INDIVIDU   BU,
         STD_MIGR_DOS MD,
         CANC
   WHERE P.TYPPIECE = 'PARAM_LIMITE'
     AND REQ.TYPPIECE = 'REQUEST_LIMITE'
     AND REQ.GPIHEURE = CANC.ANCREFDOSS(+)
     AND REQ.REFDOSS = CANC.REFDOSS(+)
     AND (   REQ.GPIHEURE IS NULL 
     	    OR (    REQ.GPIHEURE = CANC.ANCREFDOSS
     	        AND REQ.REFDOSS = CANC.REFDOSS ) )
     AND P.STR_20_1 = REQ.REFPIECE
     AND D.REFPIECE = P.REFPIECE
     AND D.TYPE = 'DETAIL_LIMITE'
     AND NVL(P.FG01, 'N') = 'N'
     AND NVL(REQ.FG05, 'N') = 'O'
     AND POL.REFPIECE(+) = REQ.LIBELLE_100_8
     AND POL.TYPPIECE(+) = 'POLICE'                                    
     AND BU.REFINDIVIDU(+) = REQ.GPITYPTRIB
     AND BU.SOCIETE(+) = 'FACTOR_ID'
     AND NOT EXISTS ( SELECT 1
                        FROM V_PROC_CONF
                       WHERE PROC_KEY = 'EXPORT_MIGRATION'
                         AND PARAM_KEY = 'INCORRECT_BU'
                         AND PARAM_VAL = BU.REFEXT )
     AND MD.CONTRACT_NO(+) = REQ.GPIHEURE
     AND (   MD.CONTRACT_NO = REQ.GPIHEURE 
          OR REQ.GPIHEURE IS NULL )
     AND ( P.GPIDEPOT, P.REFEXT ) IN ( ( 'FIN', 'COM' ), ( 'C', 'COM' ), ( 'CI', 'DB' ) )
     AND CF_PROP.REFPIECE(+) = REQ.REFPIECE
     AND CF_PROP.TYPE(+) = 'REQUEST_CF_PROPOSAL'
     AND ( (    P.GPIDEPOT = 'FIN' 
            AND P.REFEXT = 'COM' 
            AND P.GPIBUREAU IS NOT NULL 
            AND P.GPIMARQUE IS NOT NULL
            AND REQ.GPIHEURE IS NOT NULL ) 
         OR (   P.GPIDEPOT = 'C' 
            AND P.REFEXT = 'COM' 
            AND P.GPIBUREAU IS NOT NULL 
            AND P.GPIMARQUE IS NOT NULL
            AND REQ.GPIHEURE IS NOT NULL ) 
         OR (   P.GPIDEPOT = 'CI' 
            AND P.REFEXT = 'DB' 
            AND P.GPIMARQUE IS NOT NULL 
            AND POL.REFEXT IS NOT NULL ) )
     AND P.GPIDEVIS IS NOT NULL
     AND D.MT01 IS NOT NULL
     AND DECODE( P.GPIDEPOT, 
                 'CI', 
                 DECODE( P.REFEXT, 
                         'DB', 
                         D.DT01_DT, 
                         REQ.GPIDTDEB_DT ),
                 REQ.GPIDTDEB_DT ) IS NOT NULL
     AND ORA_HASH(REQ.REFPIECE, :B2) = :B1
  UNION ALL
  SELECT REQ.REFPIECE AS LIMIT_REF,
         REQ.GPIDEVIS AS CURRENCY_LIM,
         NULL AS LIMIT_TYPE,
         NULL AS LIMIT_LEVEL,
         REQ.MT02 AS AMOUNT,
         REQ.GPIDTDEB_DT AS START_DATE,
         REQ.GPIDTFIN_DT AS END_DATE,
         NVL(REQ.FG02, 'N') AS COVERS_WITH_BILL,
         REQ.NB01 AS DELAI,
         REQ.ST21 AS MODE_REG,
         REQ.DT_CREATION_DT AS CREATION_DATE,
         REQ.CREATEUR AS CREATOR,
         NULL AS CAR_NUMBER,
         REQ.COMMENTAIRE_1 AS DECISION_COMMENTS,
         REQ.FG10 AS AUTO_UPDATE,
         CASE
           WHEN NVL(REQ.DT01_DT, TRUNC(SYSDATE)) <= TRUNC(SYSDATE) AND
                NVL(REQ.DT02_DT, TRUNC(SYSDATE)) >= TRUNC(SYSDATE) THEN
            'O'
           ELSE
            'N'
         END AS AUTO_APPROVAL,
         'O' AS IS_LIMIT_REQUEST,
         REQ.TYPEDOC AS TYPE_OF_REQUEST,
         REQ.GPIDEPOT AS CLIENT_ID,
         REQ.GPIADR3 AS DEBTOR_ID,
         NULL AS IND_GRP_ID,
         REQ.GPIHEURE AS CONTRACT_ID,
         CASE
           WHEN (SELECT NVL(FG_MULT_GL_LMT_ALLOW, 'N') FROM G_ETUDE) = 'N' AND
                REQ.TYPEDOC = 'G' THEN
            POL1.REFEXT
           ELSE
            POL.REFEXT
         END AS POLICY_ID,
         BU.REFEXT AS BU_ID,
         REQ.ST24 AS CLIENT_GRP_ID,
         REQ.ST41 AS DEBTOR_GRP_ID,
         CASE
           WHEN ( SELECT NVL(FG_MULT_GL_LMT_ALLOW, 'N') 
                    FROM G_ETUDE ) = 'N'
                 AND REQ.TYPEDOC = 'G' THEN
            DECODE(POL1.STR_20_1,
                   'CLIENT',
                   'LBL',
                   'GENERALE',
                   'CIC',
                   'GLOBAL',
                   'GLOBAL')
           ELSE
            DECODE(POL.STR_20_1,
                   'CLIENT',
                   'LBL',
                   'GENERALE',
                   'CIC',
                   'GLOBAL',
                   'GLOBAL')
         END AS POLICY_TYPE,
         NULL AS CI_CF_DECISION_REASON,
         REQ.GPIREFNOTAIRE AS LINKED_LIMIT_REF,
         REQ.DT35_DT AS REVISION_DT,
         REQ.LIBELLE_20_11 AS CO_FACTOR,
         NULL AS CI_CF_DECISION_AMT,
         NULL AS CI_CF_DECISION_CCY,
         NULL AS CI_CF_DECISION_START_DT,
         NULL AS CI_CF_DECISION_END_DT,
         NULL AS LFR_DATE,
         REQ.DT04_DT AS DECISION_DATE
    FROM G_PIECE      POL,
         LIM      REQ,
         G_PIECEDET   GD,
         G_PIECE      GP,
         G_PIECE      POL1,
         T_INDIVIDU   BU,
         STD_MIGR_DOS MD,
         CANC
   WHERE REQ.TYPPIECE = 'REQUEST_LIMITE'
     AND NVL(REQ.FG05, 'N') = 'O'
     AND REQ.GPIHEURE = CANC.ANCREFDOSS(+)
     AND REQ.REFDOSS = CANC.REFDOSS(+)
     AND (    REQ.GPIHEURE IS NULL 
     	   OR (  REQ.GPIHEURE = CANC.ANCREFDOSS 
     	     AND REQ.REFDOSS = CANC.REFDOSS ) )
     AND POL.REFPIECE(+) = REQ.LIBELLE_100_8
     AND POL.TYPPIECE(+) = 'POLICE'
     AND REQ.TYPEDOC IN ('O', 'G')
     AND GP.TYPPIECE = 'FACTOR'
     AND GP.GPIHEURE = REQ.GPITYPTRIB
     AND GP.REFPIECE = GD.REFPIECE(+)
     AND GD.TYPE(+) = 'POLICIES'
     AND GD.NB01(+) = '1'
     AND POL1.REFPIECE(+) = GD.STR1
     AND POL1.TYPPIECE(+) = 'POLICE'
     AND BU.REFINDIVIDU(+) = REQ.GPITYPTRIB
     AND BU.SOCIETE(+) = 'FACTOR_ID'
     AND NOT EXISTS ( SELECT 1
                        FROM V_PROC_CONF
                       WHERE PROC_KEY = 'EXPORT_MIGRATION'
                         AND PARAM_KEY = 'INCORRECT_BU'
                         AND PARAM_VAL = BU.REFEXT )
     AND MD.CONTRACT_NO(+) = REQ.GPIHEURE
     AND (   MD.CONTRACT_NO = REQ.GPIHEURE 
          OR REQ.GPIHEURE IS NULL )
     AND REQ.GPIDEVIS IS NOT NULL
     AND REQ.MT01 IS NOT NULL
     AND REQ.GPIDTDEB_DT IS NOT NULL
     AND ORA_HASH(REQ.REFPIECE, :B2) = :B1;



-- 33hv83rutznyv


WITH GP AS ( SELECT /*+ parallel(4) materialize full(G_PIECE)*/
                    TYPPIECE,
                    REFPIECE,
                    STR_20_1
               FROM G_PIECE
              WHERE TYPPIECE IN ( 'PARAM_LIMITE', 'REQUEST_LIMITE' ) ),
     TI AS ( SELECT /*+ materialize */
                    REFINDIVIDU,
                    REFDOSS,
                    REFTYPE
               FROM T_INTERVENANTS
              WHERE REFTYPE IN ('CL', 'DB') )         
SELECT /*+ leading(FNC FI D) full(FNC) use_hash(FI) */
       CL.REFINDIVIDU AS CLIENT_ID,
       DB.REFINDIVIDU AS DEBTOR_ID,
       MIN(FI.REFEXT) || 'DL' AS LIMIT_REF,
       MIN(D.REFDOSS) AS REFDOSS,
       MIN(FI.DT_EMIS_DT) AS START_DATE,
       MAX(FI.DT_EMIS_DT) AS END_DATE
  FROM STD_MIGR_FNC   FNC,
       G_ELEMFI       FI,
       G_DOSSIER      D,
       TI CL,
       TI DB
 WHERE NOT EXISTS ( SELECT 1
                      FROM G_VENDOSSLIMIT VEN, 
                           GP L, 
                           STD_MIGR_LIM LIM, 
                           GP REQ
                     WHERE L.TYPPIECE = 'PARAM_LIMITE'
                       AND L.REFPIECE = VEN.LIMIT_ID
                       AND LIM.LIMIT_REF = REQ.REFPIECE
                       AND REQ.TYPPIECE = 'REQUEST_LIMITE'
                       AND L.STR_20_1 = REQ.REFPIECE
                       AND LIM.TYPE_OF_REQUEST IN ('C', 'CI')
                       AND D.REFDOSS = VEN.REFDOSS )
   AND FI.REFDOSS = D.REFDOSS
   AND FNC.ID_DOCUMENT = FI.REFELEM
   AND FNC.COVER_AMT IS NOT NULL
   AND FNC.COVER_AMT > 0
   AND CL.REFDOSS = D.REFDOSS
   AND CL.REFTYPE = 'CL'
   AND DB.REFDOSS = D.REFDOSS
   AND DB.REFTYPE = 'DB'
 GROUP BY CL.REFINDIVIDU, DB.REFINDIVIDU;
/********************************New SQL*******************************************/
/********************************New Metrics***************************************/
/*
-- fafhapr9yv6j6

Plan hash value: 3000450417
-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                                  | Name                        | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  | Writes |
-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
|   0 | INSERT STATEMENT                                           |                             |      1 |        |   590K(100)|      0 |00:05:15.20 |    1438K|  12801 |    254 |
|   1 |  TEMP TABLE TRANSFORMATION                                 |                             |      1 |        |            |      0 |00:05:15.20 |    1438K|  12801 |    254 |
|   2 |   PX COORDINATOR                                           |                             |      1 |        |            |      8 |00:00:08.47 |      23 |      0 |      0 |
|   3 |    PX SEND QC (RANDOM)                                     | :TQ30002                    |      0 |   5138 |   210   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|   4 |     LOAD AS SELECT (TEMP SEGMENT MERGE)                    | SYS_TEMP_0FD9D688B_723EC1AD |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
|*  5 |      HASH JOIN                                             |                             |      0 |   5138 |   210   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|   6 |       PX RECEIVE                                           |                             |      0 |  23057 |   146   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|   7 |        PX SEND HASH                                        | :TQ30000                    |      0 |  23057 |   146   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|   8 |         NESTED LOOPS                                       |                             |      0 |  23057 |   146   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|   9 |          NESTED LOOPS                                      |                             |      0 |   5404 |   116   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|  10 |           PX BLOCK ITERATOR                                |                             |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
|* 11 |            TABLE ACCESS FULL                               | STD_MIGR_DOS                |      0 |   4425 |    30   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|  12 |           TABLE ACCESS BY INDEX ROWID BATCHED              | G_DOSSIER                   |      0 |      1 |     0   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|* 13 |            INDEX RANGE SCAN                                | DOS_ANCREFDOSS              |      0 |      5 |     0   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|* 14 |          INDEX RANGE SCAN                                  | G_DOSSIER_RL_CD_RD_RF_IDX   |      0 |      4 |     0   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|  15 |       PX RECEIVE                                           |                             |      0 |    158K|    64   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|  16 |        PX SEND HASH                                        | :TQ30001                    |      0 |    158K|    64   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|  17 |         PX SELECTOR                                        |                             |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
|* 18 |          INDEX FULL SCAN                                   | G_DOSSIER_RL_CD_RD_RF_IDX   |      0 |    158K|    64   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|  19 |   PX COORDINATOR                                           |                             |      1 |        |            |      8 |00:01:39.77 |   15778 |      5 |      0 |
|  20 |    PX SEND QC (RANDOM)                                     | :TQ40000                    |      0 |   8100K|  1052K  (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|  21 |     LOAD AS SELECT (TEMP SEGMENT MERGE)                    | SYS_TEMP_0FD9D688C_723EC1AD |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
|  22 |      PX BLOCK ITERATOR                                     |                             |      0 |   8100K|  1052K  (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|* 23 |       TABLE ACCESS FULL                                    | G_PIECE                     |      0 |   8100K|  1052K  (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|  24 |   LOAD TABLE CONVENTIONAL                                  | STD_MIGR_LIM                |      1 |        |            |      0 |00:03:26.91 |    1419K|  12794 |      0 |
|  25 |    UNION-ALL                                               |                             |      1 |        |            |    587K|00:03:08.58 |     183 |     16 |      0 |
|* 26 |     TABLE ACCESS BY INDEX ROWID                            | G_INDIVIDU                  |     14 |      1 |     1   (0)|      1 |00:00:00.02 |      52 |     16 |      0 |
|* 27 |      INDEX UNIQUE SCAN                                     | IND_REFINDIV                |     14 |      1 |     1   (0)|     13 |00:00:00.01 |      39 |      8 |      0 |
|  28 |     PX COORDINATOR                                         |                             |      1 |        |            |    496K|00:02:46.78 |      82 |      0 |      0 |
|  29 |      PX SEND QC (RANDOM)                                   | :TQ50006                    |      0 |      1 |   547K  (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|  30 |       BUFFER SORT                                          |                             |      0 |    908K|            |      0 |00:00:00.01 |       0 |      0 |      0 |
|  31 |        NESTED LOOPS ANTI                                   |                             |      0 |      1 |   547K  (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|  32 |         NESTED LOOPS OUTER                                 |                             |      0 |      1 |   547K  (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|* 33 |          FILTER                                            |                             |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
|  34 |           NESTED LOOPS OUTER                               |                             |      0 |      1 |   547K  (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|  35 |            NESTED LOOPS                                    |                             |      0 |      1 |   547K  (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|  36 |             NESTED LOOPS OUTER                             |                             |      0 |      1 |   547K  (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|* 37 |              FILTER                                        |                             |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
|* 38 |               HASH JOIN OUTER                              |                             |      0 |      1 |   547K  (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|  39 |                PX RECEIVE                                  |                             |      0 |      1 |   547K  (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|  40 |                 PX SEND HASH                               | :TQ50004                    |      0 |      1 |   547K  (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|* 41 |                  FILTER                                    |                             |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
|* 42 |                   HASH JOIN OUTER BUFFERED                 |                             |      0 |      1 |   547K  (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|  43 |                    PX RECEIVE                              |                             |      0 |      1 |   547K  (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|  44 |                     PX SEND HASH (NULL RANDOM)             | :TQ50002                    |      0 |      1 |   547K  (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|* 45 |                      HASH JOIN BUFFERED                    |                             |      0 |      1 |   547K  (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|  46 |                       PX RECEIVE                           |                             |      0 |   8100K| 38175   (4)|      0 |00:00:00.01 |       0 |      0 |      0 |
|  47 |                        PX SEND HASH                        | :TQ50000                    |      0 |   8100K| 38175   (4)|      0 |00:00:00.01 |       0 |      0 |      0 |
|* 48 |                         VIEW                               |                             |      0 |   8100K| 38175   (4)|      0 |00:00:00.01 |       0 |      0 |      0 |
|  49 |                          PX BLOCK ITERATOR                 |                             |      0 |   8100K| 38175   (4)|      0 |00:00:00.01 |       0 |      0 |      0 |
|* 50 |                           TABLE ACCESS FULL                | SYS_TEMP_0FD9D688C_723EC1AD |      0 |   8100K| 38175   (4)|      0 |00:00:00.01 |       0 |      0 |      0 |
|  51 |                       PX RECEIVE                           |                             |      0 |   8100K| 38175   (4)|      0 |00:00:00.01 |       0 |      0 |      0 |
|  52 |                        PX SEND HASH                        | :TQ50001                    |      0 |   8100K| 38175   (4)|      0 |00:00:00.01 |       0 |      0 |      0 |
|* 53 |                         VIEW                               |                             |      0 |   8100K| 38175   (4)|      0 |00:00:00.01 |       0 |      0 |      0 |
|  54 |                          PX BLOCK ITERATOR                 |                             |      0 |   8100K| 38175   (4)|      0 |00:00:00.01 |       0 |      0 |      0 |
|* 55 |                           TABLE ACCESS FULL                | SYS_TEMP_0FD9D688C_723EC1AD |      0 |   8100K| 38175   (4)|      0 |00:00:00.01 |       0 |      0 |      0 |
|  56 |                    PX RECEIVE                              |                             |      0 |   4425 |    30   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|  57 |                     PX SEND HASH                           | :TQ50003                    |      0 |   4425 |    30   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|  58 |                      PX BLOCK ITERATOR                     |                             |      0 |   4425 |    30   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|* 59 |                       TABLE ACCESS FULL                    | STD_MIGR_DOS                |      0 |   4425 |    30   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|  60 |                PX RECEIVE                                  |                             |      0 |   5138 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|  61 |                 PX SEND HASH                               | :TQ50005                    |      0 |   5138 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|  62 |                  VIEW                                      |                             |      0 |   5138 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|  63 |                   PX BLOCK ITERATOR                        |                             |      0 |   5138 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|* 64 |                    TABLE ACCESS FULL                       | SYS_TEMP_0FD9D688B_723EC1AD |      0 |   5138 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|* 65 |              TABLE ACCESS BY INDEX ROWID BATCHED           | T_INDIVIDU                  |      0 |      1 |     0   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|* 66 |               INDEX RANGE SCAN                             | IX_T_INDIVIDU               |      0 |      4 |     0   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|  67 |             TABLE ACCESS BY INDEX ROWID BATCHED            | G_PIECEDET                  |      0 |      1 |     0   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|* 68 |              INDEX RANGE SCAN                              | G_PIECEDET_REFP             |      0 |      1 |     0   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|* 69 |            TABLE ACCESS BY INDEX ROWID BATCHED             | G_PIECE                     |      0 |      1 |     0   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|* 70 |             INDEX RANGE SCAN                               | PIE_REFPIECE                |      0 |      1 |     0   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|  71 |          TABLE ACCESS BY INDEX ROWID BATCHED               | G_PIECEDET                  |      0 |      1 |     0   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|* 72 |           INDEX RANGE SCAN                                 | G_PIECEDET_REFP             |      0 |      1 |     0   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|* 73 |         TABLE ACCESS BY INDEX ROWID BATCHED                | V_PROC_CONF                 |      0 |      1 |     0   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|* 74 |          INDEX RANGE SCAN                                  | V_PROC_CONF_PROC_KEY_IDX    |      0 |      3 |     0   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|  75 |     PX COORDINATOR                                         |                             |      1 |        |            |      1 |00:00:00.03 |       3 |      0 |      0 |
|  76 |      PX SEND QC (RANDOM)                                   | :TQ10000                    |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|  77 |       PX BLOCK ITERATOR                                    |                             |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|* 78 |        TABLE ACCESS FULL                                   | G_ETUDE                     |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|  79 |     PX COORDINATOR                                         |                             |      1 |        |            |      1 |00:00:00.02 |       3 |      0 |      0 |
|  80 |      PX SEND QC (RANDOM)                                   | :TQ20000                    |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|  81 |       PX BLOCK ITERATOR                                    |                             |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|* 82 |        TABLE ACCESS FULL                                   | G_ETUDE                     |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|  83 |     PX COORDINATOR                                         |                             |      1 |        |            |  91657 |00:00:20.50 |      43 |      0 |      0 |
|  84 |      PX SEND QC (RANDOM)                                   | :TQ60006                    |      0 |      1 | 43335   (4)|      0 |00:00:00.01 |       0 |      0 |      0 |
|  85 |       BUFFER SORT                                          |                             |      0 |    908K|            |      0 |00:00:00.01 |       0 |      0 |      0 |
|  86 |        NESTED LOOPS ANTI                                   |                             |      0 |      1 | 43335   (4)|      0 |00:00:00.01 |       0 |      0 |      0 |
|  87 |         NESTED LOOPS OUTER                                 |                             |      0 |      1 | 43335   (4)|      0 |00:00:00.01 |       0 |      0 |      0 |
|  88 |          NESTED LOOPS OUTER                                |                             |      0 |      1 | 43334   (4)|      0 |00:00:00.01 |       0 |      0 |      0 |
|  89 |           NESTED LOOPS OUTER                               |                             |      0 |      1 | 43334   (4)|      0 |00:00:00.01 |       0 |      0 |      0 |
|* 90 |            FILTER                                          |                             |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
|* 91 |             HASH JOIN OUTER                                |                             |      0 |      1 | 43334   (4)|      0 |00:00:00.01 |       0 |      0 |      0 |
|  92 |              PX RECEIVE                                    |                             |      0 |      1 | 43330   (4)|      0 |00:00:00.01 |       0 |      0 |      0 |
|  93 |               PX SEND HASH                                 | :TQ60004                    |      0 |      1 | 43330   (4)|      0 |00:00:00.01 |       0 |      0 |      0 |
|* 94 |                FILTER                                      |                             |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
|* 95 |                 HASH JOIN OUTER BUFFERED                   |                             |      0 |      1 | 43330   (4)|      0 |00:00:00.01 |       0 |      0 |      0 |
|  96 |                  PX RECEIVE                                |                             |      0 |      1 | 43300   (4)|      0 |00:00:00.01 |       0 |      0 |      0 |
|  97 |                   PX SEND HASH (NULL RANDOM)               | :TQ60002                    |      0 |      1 | 43300   (4)|      0 |00:00:00.01 |       0 |      0 |      0 |
|  98 |                    NESTED LOOPS OUTER                      |                             |      0 |      1 | 43300   (4)|      0 |00:00:00.01 |       0 |      0 |      0 |
|* 99 |                     HASH JOIN                              |                             |      0 |      1 | 43299   (4)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 100 |                      JOIN FILTER CREATE                    | :BF0000                     |      0 |  68156 |  5117   (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 101 |                       PX RECEIVE                           |                             |      0 |  68156 |  5117   (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 102 |                        PX SEND BROADCAST                   | :TQ60001                    |      0 |  68156 |  5117   (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 103 |                         TABLE ACCESS BY INDEX ROWID BATCHED| G_PIECE                     |      0 |  68156 |  5117   (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 104 |                          BUFFER SORT                       |                             |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
| 105 |                           PX RECEIVE                       |                             |      0 |   2629K|   243   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 106 |                            PX SEND HASH (BLOCK ADDRESS)    | :TQ60000                    |      0 |   2629K|   243   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 107 |                             PX SELECTOR                    |                             |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
|*108 |                              INDEX RANGE SCAN              | GP_GRTYPE_MT_DT             |      0 |   2629K|   243   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*109 |                      VIEW                                  |                             |      0 |   8100K| 38175   (4)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 110 |                       JOIN FILTER USE                      | :BF0000                     |      0 |   8100K| 38175   (4)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 111 |                        PX BLOCK ITERATOR                   |                             |      0 |   8100K| 38175   (4)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*112 |                         TABLE ACCESS FULL                  | SYS_TEMP_0FD9D688C_723EC1AD |      0 |   8100K| 38175   (4)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 113 |                     TABLE ACCESS BY INDEX ROWID BATCHED    | G_PIECEDET                  |      0 |      1 |     0   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*114 |                      INDEX RANGE SCAN                      | G_PIECEDET_REFP             |      0 |      1 |     0   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 115 |                  PX RECEIVE                                |                             |      0 |   4425 |    30   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 116 |                   PX SEND HASH                             | :TQ60003                    |      0 |   4425 |    30   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 117 |                    PX BLOCK ITERATOR                       |                             |      0 |   4425 |    30   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*118 |                     TABLE ACCESS FULL                      | STD_MIGR_DOS                |      0 |   4425 |    30   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 119 |              PX RECEIVE                                    |                             |      0 |   5138 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 120 |               PX SEND HASH                                 | :TQ60005                    |      0 |   5138 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 121 |                VIEW                                        |                             |      0 |   5138 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 122 |                 PX BLOCK ITERATOR                          |                             |      0 |   5138 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*123 |                  TABLE ACCESS FULL                         | SYS_TEMP_0FD9D688B_723EC1AD |      0 |   5138 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*124 |            TABLE ACCESS BY INDEX ROWID BATCHED             | T_INDIVIDU                  |      0 |      1 |     0   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*125 |             INDEX RANGE SCAN                               | IX_T_INDIVIDU               |      0 |      4 |     0   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*126 |           TABLE ACCESS BY INDEX ROWID BATCHED              | G_PIECE                     |      0 |      1 |     0   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*127 |            INDEX RANGE SCAN                                | PIE_REFPIECE                |      0 |      1 |     0   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*128 |          TABLE ACCESS BY INDEX ROWID BATCHED               | G_PIECE                     |      0 |      1 |     0   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*129 |           INDEX RANGE SCAN                                 | PIE_REFPIECE                |      0 |      1 |     0   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*130 |         TABLE ACCESS BY INDEX ROWID BATCHED                | V_PROC_CONF                 |      0 |      1 |     0   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*131 |          INDEX RANGE SCAN                                  | V_PROC_CONF_PROC_KEY_IDX    |      0 |      3 |     0   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   5 - access("DECOM"."REFDOSS"="CLDB"."REFLOT")
  11 - access(:Z>=:Z AND :Z<=:Z)
  13 - access("DOS"."CONTRACT_NO"="CONTR"."ANCREFDOSS")
       filter("CONTR"."ANCREFDOSS" IS NOT NULL)
  14 - access("CONTR"."REFDOSS"="DECOM"."REFLOT")
  18 - filter(("CLDB"."CATEGDOSS"='COMPTE' OR "CLDB"."CATEGDOSS"='COMPTE EXP' OR "CLDB"."CATEGDOSS"='COMPTE IMP'))
  23 - access(:Z>=:Z AND :Z<=:Z)
       filter(("TYPPIECE"='PARAM_LIMITE' OR "TYPPIECE"='REQUEST_LIMITE'))
  26 - filter("TYPAUTRE"='CF')
  27 - access("REFINDIVIDU"=:B1)
  33 - filter((("P"."GPIDEPOT"='FIN' AND "P"."REFEXT"='COM' AND "P"."GPIBUREAU" IS NOT NULL AND "P"."GPIMARQUE" IS NOT NULL AND "REQ"."GPIHEURE" IS NOT NULL) OR
              ("P"."GPIDEPOT"='C' AND "P"."REFEXT"='COM' AND "P"."GPIBUREAU" IS NOT NULL AND "P"."GPIMARQUE" IS NOT NULL AND "REQ"."GPIHEURE" IS NOT NULL) OR ("P"."GPIDEPOT"='CI' AND
              "P"."REFEXT"='DB' AND "P"."GPIMARQUE" IS NOT NULL AND "POL"."REFEXT" IS NOT NULL)))
  37 - filter(("REQ"."GPIHEURE" IS NULL OR ("REQ"."GPIHEURE"="CANC"."ANCREFDOSS" AND "REQ"."REFDOSS"="CANC"."REFDOSS")))
  38 - access("REQ"."GPIHEURE"="CANC"."ANCREFDOSS" AND "REQ"."REFDOSS"="CANC"."REFDOSS")
  41 - filter(("MD"."CONTRACT_NO"="REQ"."GPIHEURE" OR "REQ"."GPIHEURE" IS NULL))
  42 - access("MD"."CONTRACT_NO"="REQ"."GPIHEURE")
  45 - access("P"."STR_20_1"="REQ"."REFPIECE")
  48 - filter(("P"."TYPPIECE"='PARAM_LIMITE' AND NVL("P"."FG01",'N')='N' AND (("P"."GPIDEPOT"='C' AND "P"."REFEXT"='COM') OR ("P"."GPIDEPOT"='CI' AND "P"."REFEXT"='DB')
              OR ("P"."GPIDEPOT"='FIN' AND "P"."REFEXT"='COM')) AND "P"."GPIDEVIS" IS NOT NULL))
  50 - access(:Z>=:Z AND :Z<=:Z)
  53 - filter(("REQ"."TYPPIECE"='REQUEST_LIMITE' AND NVL("REQ"."FG05",'N')='O' AND ORA_HASH("REQ"."REFPIECE",:B2)=:B1))
  55 - access(:Z>=:Z AND :Z<=:Z)
  59 - access(:Z>=:Z AND :Z<=:Z)
  64 - access(:Z>=:Z AND :Z<=:Z)
  65 - filter("BU"."SOCIETE"='FACTOR_ID')
  66 - access("BU"."REFINDIVIDU"="REQ"."GPITYPTRIB")
  68 - access("D"."REFPIECE"="P"."REFPIECE" AND "D"."TYPE"='DETAIL_LIMITE')
       filter(("D"."MT01" IS NOT NULL AND DECODE("P"."GPIDEPOT",'CI',DECODE("P"."REFEXT",'DB',"D"."DT01_DT","REQ"."GPIDTDEB_DT"),"REQ"."GPIDTDEB_DT") IS NOT NULL))
  69 - filter("POL"."TYPPIECE"='POLICE')
  70 - access("POL"."REFPIECE"="REQ"."LIBELLE_100_8")
  72 - access("CF_PROP"."REFPIECE"="REQ"."REFPIECE" AND "CF_PROP"."TYPE"='REQUEST_CF_PROPOSAL')
  73 - filter(("PARAM_VAL"="BU"."REFEXT" AND "PARAM_KEY"='INCORRECT_BU'))
  74 - access("PROC_KEY"='EXPORT_MIGRATION')
  78 - access(:Z>=:Z AND :Z<=:Z)
  82 - access(:Z>=:Z AND :Z<=:Z)
  90 - filter(("REQ"."GPIHEURE" IS NULL OR ("REQ"."GPIHEURE"="CANC"."ANCREFDOSS" AND "REQ"."REFDOSS"="CANC"."REFDOSS")))
  91 - access("REQ"."GPIHEURE"="CANC"."ANCREFDOSS" AND "REQ"."REFDOSS"="CANC"."REFDOSS")
  94 - filter(("MD"."CONTRACT_NO"="REQ"."GPIHEURE" OR "REQ"."GPIHEURE" IS NULL))
  95 - access("MD"."CONTRACT_NO"="REQ"."GPIHEURE")
  99 - access("GP"."GPIHEURE"="REQ"."GPITYPTRIB")
 108 - access("GP"."TYPPIECE"='FACTOR')
       filter("GP"."GPIHEURE" IS NOT NULL)
 109 - filter(("REQ"."TYPPIECE"='REQUEST_LIMITE' AND NVL("REQ"."FG05",'N')='O' AND INTERNAL_FUNCTION("REQ"."TYPEDOC") AND "REQ"."GPIDEVIS" IS NOT NULL AND "REQ"."MT01" IS
              NOT NULL AND "REQ"."GPIDTDEB_DT" IS NOT NULL AND ORA_HASH("REQ"."REFPIECE",:B2)=:B1))
 112 - access(:Z>=:Z AND :Z<=:Z)
       filter(SYS_OP_BLOOM_FILTER(:BF0000,"C21"))
 114 - access("GP"."REFPIECE"="GD"."REFPIECE" AND "GD"."TYPE"='POLICIES' AND "GD"."NB01"=1)
       filter("GD"."NB01"=1)
 118 - access(:Z>=:Z AND :Z<=:Z)
 123 - access(:Z>=:Z AND :Z<=:Z)
 124 - filter("BU"."SOCIETE"='FACTOR_ID')
 125 - access("BU"."REFINDIVIDU"="REQ"."GPITYPTRIB")
 126 - filter("POL"."TYPPIECE"='POLICE')
 127 - access("POL"."REFPIECE"="REQ"."LIBELLE_100_8")
 128 - filter("POL1"."TYPPIECE"='POLICE')
 129 - access("POL1"."REFPIECE"="GD"."STR1")
 130 - filter(("PARAM_VAL"="BU"."REFEXT" AND "PARAM_KEY"='INCORRECT_BU'))
 131 - access("PROC_KEY"='EXPORT_MIGRATION')




-- 33hv83rutznyv

Plan hash value: 249278102
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                        | Name                           | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  | Writes |
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                                 |                                |      1 |        |  1259K(100)|    195 |00:01:30.03 |   16004 |      1 |   5445 |
|   1 |  TEMP TABLE TRANSFORMATION                       |                                |      1 |        |            |    195 |00:01:30.03 |   16004 |      1 |   5445 |
|   2 |   PX COORDINATOR                                 |                                |      1 |        |            |      8 |00:01:06.17 |     270 |      0 |      0 |
|   3 |    PX SEND QC (RANDOM)                           | :TQ10000                       |      0 |   8100K|  1051K  (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|   4 |     LOAD AS SELECT (TEMP SEGMENT MERGE)          | SYS_TEMP_0FD9D6895_723EC1AD    |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
|   5 |      PX BLOCK ITERATOR                           |                                |      0 |   8100K|  1051K  (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*  6 |       TABLE ACCESS FULL                          | G_PIECE                        |      0 |   8100K|  1051K  (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|   7 |   LOAD AS SELECT                                 | SYS_TEMP_0FD9D6896_723EC1AD    |      1 |        |            |      0 |00:00:00.82 |   15410 |      0 |   5318 |
|*  8 |    INDEX FULL SCAN                               | INT_REFDOSS                    |      1 |    272K|   103   (0)|   1371K|00:00:00.39 |   10007 |      0 |      0 |
|   9 |   PX COORDINATOR                                 |                                |      1 |        |            |    195 |00:00:22.97 |      70 |      0 |      0 |
|  10 |    PX SEND QC (RANDOM)                           | :TQ20010                       |      0 |    112K|   208K  (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|  11 |     HASH GROUP BY                                |                                |      0 |    112K|   208K  (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|  12 |      PX RECEIVE                                  |                                |      0 |    112K|   208K  (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|  13 |       PX SEND HASH                               | :TQ20009                       |      0 |    112K|   208K  (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|  14 |        HASH GROUP BY                             |                                |      0 |    112K|   208K  (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|* 15 |         HASH JOIN RIGHT ANTI                     |                                |      0 |    112K|   207K  (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|  16 |          PX RECEIVE                              |                                |      0 |      1 |  2572   (3)|      0 |00:00:00.01 |       0 |      0 |      0 |
|  17 |           PX SEND HASH                           | :TQ20006                       |      0 |      1 |  2572   (3)|      0 |00:00:00.01 |       0 |      0 |      0 |
|  18 |            BUFFER SORT                           |                                |      0 |    112K|   208K  (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|  19 |             VIEW                                 | VW_SQ_1                        |      0 |      1 |  2572   (3)|      0 |00:00:00.01 |       0 |      0 |      0 |
|  20 |              NESTED LOOPS SEMI                   |                                |      0 |      1 |  2572   (3)|      0 |00:00:00.01 |       0 |      0 |      0 |
|* 21 |               HASH JOIN                          |                                |      0 |      1 |  2572   (3)|      0 |00:00:00.01 |       0 |      0 |      0 |
|  22 |                JOIN FILTER CREATE                | :BF0000                        |      0 |   2920K|  1381   (3)|      0 |00:00:00.01 |       0 |      0 |      0 |
|  23 |                 PX RECEIVE                       |                                |      0 |   2920K|  1381   (3)|      0 |00:00:00.01 |       0 |      0 |      0 |
|  24 |                  PX SEND HASH                    | :TQ20001                       |      0 |   2920K|  1381   (3)|      0 |00:00:00.01 |       0 |      0 |      0 |
|* 25 |                   HASH JOIN                      |                                |      0 |   2920K|  1381   (3)|      0 |00:00:00.01 |       0 |      0 |      0 |
|  26 |                    PX RECEIVE                    |                                |      0 |   2920K|   189   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|  27 |                     PX SEND BROADCAST            | :TQ20000                       |      0 |   2920K|   189   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|  28 |                      PX SELECTOR                 |                                |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
|  29 |                       INDEX FULL SCAN            | G_VENDOSSLIMIT$REFDOSS_LIMITID |      0 |   2920K|   189   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|* 30 |                    VIEW                          |                                |      0 |   8100K|  1179   (2)|      0 |00:00:00.01 |       0 |      0 |      0 |
|  31 |                     PX BLOCK ITERATOR            |                                |      0 |   8100K|  1179   (2)|      0 |00:00:00.01 |       0 |      0 |      0 |
|* 32 |                      TABLE ACCESS FULL           | SYS_TEMP_0FD9D6895_723EC1AD    |      0 |   8100K|  1179   (2)|      0 |00:00:00.01 |       0 |      0 |      0 |
|  33 |                PX RECEIVE                        |                                |      0 |   8100K|  1179   (2)|      0 |00:00:00.01 |       0 |      0 |      0 |
|  34 |                 PX SEND HASH                     | :TQ20002                       |      0 |   8100K|  1179   (2)|      0 |00:00:00.01 |       0 |      0 |      0 |
|  35 |                  JOIN FILTER USE                 | :BF0000                        |      0 |   8100K|  1179   (2)|      0 |00:00:00.01 |       0 |      0 |      0 |
|* 36 |                   VIEW                           |                                |      0 |   8100K|  1179   (2)|      0 |00:00:00.01 |       0 |      0 |      0 |
|  37 |                    PX BLOCK ITERATOR             |                                |      0 |   8100K|  1179   (2)|      0 |00:00:00.01 |       0 |      0 |      0 |
|* 38 |                     TABLE ACCESS FULL            | SYS_TEMP_0FD9D6895_723EC1AD    |      0 |   8100K|  1179   (2)|      0 |00:00:00.01 |       0 |      0 |      0 |
|* 39 |               TABLE ACCESS BY INDEX ROWID BATCHED| STD_MIGR_LIM                   |      0 |   6525 |     0   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|* 40 |                INDEX RANGE SCAN                  | STD_MIGR_LIM_LIMIT_REF         |      0 |      1 |     0   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|* 41 |          HASH JOIN                               |                                |      0 |    112K|   204K  (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|  42 |           PX RECEIVE                             |                                |      0 |    272K|    44   (3)|      0 |00:00:00.01 |       0 |      0 |      0 |
|  43 |            PX SEND HASH                          | :TQ20007                       |      0 |    272K|    44   (3)|      0 |00:00:00.01 |       0 |      0 |      0 |
|* 44 |             VIEW                                 |                                |      0 |    272K|    44   (3)|      0 |00:00:00.01 |       0 |      0 |      0 |
|  45 |              PX BLOCK ITERATOR                   |                                |      0 |    272K|    44   (3)|      0 |00:00:00.01 |       0 |      0 |      0 |
|* 46 |               TABLE ACCESS FULL                  | SYS_TEMP_0FD9D6896_723EC1AD    |      0 |    272K|    44   (3)|      0 |00:00:00.01 |       0 |      0 |      0 |
|  47 |           PX RECEIVE                             |                                |      0 |    284K|   204K  (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|  48 |            PX SEND HASH                          | :TQ20008                       |      0 |    284K|   204K  (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|* 49 |             HASH JOIN                            |                                |      0 |    284K|   204K  (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|  50 |              PX RECEIVE                          |                                |      0 |    272K|    44   (3)|      0 |00:00:00.01 |       0 |      0 |      0 |
|  51 |               PX SEND BROADCAST                  | :TQ20003                       |      0 |    272K|    44   (3)|      0 |00:00:00.01 |       0 |      0 |      0 |
|* 52 |                VIEW                              |                                |      0 |    272K|    44   (3)|      0 |00:00:00.01 |       0 |      0 |      0 |
|  53 |                 PX BLOCK ITERATOR                |                                |      0 |    272K|    44   (3)|      0 |00:00:00.01 |       0 |      0 |      0 |
|* 54 |                  TABLE ACCESS FULL               | SYS_TEMP_0FD9D6896_723EC1AD    |      0 |    272K|    44   (3)|      0 |00:00:00.01 |       0 |      0 |      0 |
|* 55 |              HASH JOIN                           |                                |      0 |    715K|   204K  (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|  56 |               PX RECEIVE                         |                                |      0 |    685K|    20   (5)|      0 |00:00:00.01 |       0 |      0 |      0 |
|  57 |                PX SEND BROADCAST                 | :TQ20004                       |      0 |    685K|    20   (5)|      0 |00:00:00.01 |       0 |      0 |      0 |
|  58 |                 PX SELECTOR                      |                                |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
|  59 |                  INDEX FULL SCAN                 | DOS_REFDOSS                    |      0 |    685K|    20   (5)|      0 |00:00:00.01 |       0 |      0 |      0 |
|* 60 |               HASH JOIN                          |                                |      0 |    715K|   204K  (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|  61 |                JOIN FILTER CREATE                | :BF0001                        |      0 |    715K|  1036   (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|  62 |                 PX RECEIVE                       |                                |      0 |    715K|  1036   (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|  63 |                  PX SEND BROADCAST               | :TQ20005                       |      0 |    715K|  1036   (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|  64 |                   PX BLOCK ITERATOR              |                                |      0 |    715K|  1036   (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|* 65 |                    TABLE ACCESS FULL             | STD_MIGR_FNC                   |      0 |    715K|  1036   (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|  66 |                JOIN FILTER USE                   | :BF0001                        |      0 |     58M|   203K  (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|  67 |                 PX BLOCK ITERATOR                |                                |      0 |     58M|   203K  (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|* 68 |                  TABLE ACCESS FULL               | G_ELEMFI                       |      0 |     58M|   203K  (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   6 - access(:Z>=:Z AND :Z<=:Z)
       filter(("TYPPIECE"='PARAM_LIMITE' OR "TYPPIECE"='REQUEST_LIMITE'))
   8 - filter(("REFTYPE"='CL' OR "REFTYPE"='DB'))
  15 - access("D"."REFDOSS"="ITEM_1")
  21 - access("L"."STR_20_1"="REQ"."REFPIECE")
  25 - access("L"."REFPIECE"="VEN"."LIMIT_ID")
  30 - filter("L"."TYPPIECE"='PARAM_LIMITE')
  32 - access(:Z>=:Z AND :Z<=:Z)
  36 - filter("REQ"."TYPPIECE"='REQUEST_LIMITE')
  38 - access(:Z>=:Z AND :Z<=:Z)
  39 - filter(("LIM"."TYPE_OF_REQUEST"='C' OR "LIM"."TYPE_OF_REQUEST"='CI'))
  40 - access("LIM"."LIMIT_REF"="REQ"."REFPIECE")
  41 - access("DB"."REFDOSS"="D"."REFDOSS")
  44 - filter("DB"."REFTYPE"='DB')
  46 - access(:Z>=:Z AND :Z<=:Z)
  49 - access("CL"."REFDOSS"="D"."REFDOSS")
  52 - filter("CL"."REFTYPE"='CL')
  54 - access(:Z>=:Z AND :Z<=:Z)
  55 - access("FI"."REFDOSS"="D"."REFDOSS")
  60 - access("FNC"."ID_DOCUMENT"="FI"."REFELEM")
  65 - access(:Z>=:Z AND :Z<=:Z)
       filter("FNC"."COVER_AMT">0)
  68 - access(:Z>=:Z AND :Z<=:Z)
       filter(("FI"."REFDOSS" IS NOT NULL AND SYS_OP_BLOOM_FILTER(:BF0001,"FI"."REFELEM")))
*/
/********************************New Metrics***************************************/

/********************************Index statistics**********************************/

/********************************Other SQLs****************************************/          
/*

*/ 
/********************************Other SQLs****************************************/              
