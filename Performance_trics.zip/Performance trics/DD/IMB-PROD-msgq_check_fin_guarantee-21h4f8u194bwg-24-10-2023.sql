/********************************************************************************
*********       E-mail subject: IMBDEV-11637
*********             Instance: PROD
*********          Description: 
Problem:
SQL 21h4f8u194bwg was considered as slow.

Analysis:
The TOP SQL for the period between 07:00:00 and 09:00:00 on 23/10/2023 on IMB PROD (IMBWEB-7427) was 21h4f8u194bwg. The problem is that Oracle use 
inappropriate execution plan which takes a large amount of data, which makes the query execution slow.

Suggestion:
Please modify the query as it is shown in the New SQL section below.

*********               SQL_ID: 21h4f8u194bwg
*********      Program/Package: ftr_fin_calc_item.pck
*********              Request: Dimitare Ivanov
*********               Author: Dimitar Dimitrov
********* Received e-mail date: 24/10/2023	
*********      Resolution date: 24/10/2023
*********  Trace old file here: \\epox\specifs\performance\tmp\
*********  Trace new file here:
***********************************************************************************/

/********************************OLD SQL*******************************************/
var B2 varchar2(32);
exec :B2 := 'EUR';
var B3 varchar2(32);
exec :B3 := 'AUT';
var B9 varchar2(32);
exec :B9 := 'INT00000';
exec utl_app_date.cacheAppDate(:B9);


WITH CONSUMPTION_PER_ITEM AS
 (SELECT FI_ID ITEM_ID,
         MAX(V.CONSUMED_LIM) KEEP(DENSE_RANK LAST ORDER BY V.CONSUMED_LIM) CONSUMED,
         MAX(L.GPIDEVIS) KEEP(DENSE_RANK LAST ORDER BY V.CONSUMED_LIM) CURRENCY
    FROM G_VENFILIMIT V,
         G_ELEMFI     E,
         G_PIECE      L,
         G_DOSSIER    S,
         G_DOSSIER    C,
         G_PIECE      P
   WHERE V.LIMIT_ROLE = 'FINANCING'
     AND V.COMPTE_ID IN (SELECT COLUMN_VALUE FROM TABLE(:B1))
     AND E.REFELEM = V.FI_ID
     AND L.REFPIECE = V.LIMIT_ID
     AND S.REFDOSS = V.DECOMPTE_ID
     AND C.REFDOSS = S.REFLOT
     AND P.REFDOSS = C.REFDOSS
     AND P.TYPPIECE = C.PIECEINIT
     AND (NVL(P.FG150, 'N') = 'N' OR EXISTS
          (SELECT 1
             FROM G_ELEMFI_AGGR A, G_PIECE B, G_OUTPMT O
            WHERE A.REFFACTURE = E.REFPIECE2
              AND B.REFPIECE = A.REFAGGR
              AND O.REFER = B.GPIRESSORT))
   GROUP BY FI_ID),
CONSUMPTION_PER_CURRENCY AS
 (SELECT CURRENCY, SUM(CONSUMED) CONSUMED
    FROM CONSUMPTION_PER_ITEM
   GROUP BY CURRENCY)
SELECT SUM(CASE
             WHEN CURRENCY = :B2 THEN
              CONSUMED
             ELSE
              CH_TAUX.CONV_ORIG_DEST_TX(TO_CHAR(UTL_APP_DATE.GETAPPDATE(), 'j'),
                                        CONSUMED,
                                        CURRENCY,
                                        :B2,
                                        'MR',
                                        :B2,
                                        :B3)
           END)
  FROM CONSUMPTION_PER_CURRENCY;
/********************************OLD SQL*******************************************/
/********************************OLD Metrics***************************************/
/*
INSTANCE_NUMBER SQL_ID            ELAPSED MAX_WAIT_ON     PC_OF  WAIT_TIME            GETS      READS       ROWS  ELAP/EXEC       GETS/EXEC READS/EXEC  ROWS/EXEC       EXEC PLAN_HASH_VALUE
--------------- ------------- ----------- --------------- ----- ---------- --------------- ---------- ---------- ---------- --------------- ---------- ---------- ---------- ---------------
              2 21h4f8u194bwg      523265 CPU             56%   552135.233    170089805794  832286366       1594      323.8       105253593  515028.69        .99       1616      1375934778
              1 21h4f8u194bwg      444226 CPU             56%   473041.996    140526656772  628369654       1311     336.03       106298530  475317.44        .99       1322      1375934778
              1 21h4f8u194bwg       87274 CPU             57%   93228.5232     27230846714  126255412        269     323.24       100854988  467612.64          1        270      3707792542
              1 21h4f8u194bwg       16816 CPU             54%   17685.3797      4820870466   18050382         64      247.3        70895154  265446.79        .94         68      1343865963
              2 21h4f8u194bwg       14123 CPU             55%   15121.2484      5069427798   24860705         34     415.39       149100818  731197.21          1         34      3707792542
              1 21h4f8u194bwg        9436 CPU             58%   9719.29917      2787514818    7001333         34     255.02        75338238  189225.22        .92         37      4145777774
              2 21h4f8u194bwg        2599 CPU             53%   2741.16218       871838319    3999496         27      96.24        32290308  148129.48          1         27      1343865963
              1 21h4f8u194bwg        1234 CPU             57%    1270.2653       366131371    1095318         13      94.96        28163952   84255.23          1         13      1356022322
              2 21h4f8u194bwg         706 CPU             58%   737.261017       241927113    1025818          8      88.26        30240889  128227.25          1          8      4145777774
              2 21h4f8u194bwg         111 CPU             59%   111.463067        49481723      92688          2      55.27        24740862      46344          1          2      1356022322
              2 21h4f8u194bwg          48 CPU             100%   46.488775        41180109          2          5       9.54         8236022         .4          1          5       958814172

MODULE                           PROGRAM                                            SQL_ID         PLAN_HASH     SID SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL        PERC
-------------------------------- -------------------------------------------------- ------------- ---------- ------- ------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
msgq_check_fin_guarantee         msg_q11                                            21h4f8u194bwg 1375934778    1723   47727                      2023/10/23 07:14:52  2023/10/23 07:40:41        1512                    1 +000000000 00:25:49.312 9%


SQL_ID        SQL_PLAN_HASH_VALUE SQL_PLAN_LINE_ID SQL_PLAN_OPERATION             SQL_PLAN_OPTIONS                   ACTIVE
------------- ------------------- ---------------- ------------------------------ ------------------------------ ----------
21h4f8u194bwg          1375934778               18 TABLE ACCESS                   BY INDEX ROWID                      43243
21h4f8u194bwg          1375934778               27 TABLE ACCESS                   BY INDEX ROWID                      11260
21h4f8u194bwg          1375934778               17 INDEX                          RANGE SCAN                           7539
21h4f8u194bwg          1375934778                5 SORT                           GROUP BY                             6747
21h4f8u194bwg          1375934778               23 INDEX                          UNIQUE SCAN                          5392
21h4f8u194bwg          1375934778               22 TABLE ACCESS                   BY INDEX ROWID                       4579
21h4f8u194bwg          1375934778               24 TABLE ACCESS                   BY INDEX ROWID BATCHED               4413
21h4f8u194bwg          1375934778               26 INDEX                          RANGE SCAN                           2903
21h4f8u194bwg          1375934778               25 INDEX                          RANGE SCAN                           2578
21h4f8u194bwg          1375934778               12 HASH JOIN                                                           2126
21h4f8u194bwg          1375934778               21 INDEX                          UNIQUE SCAN                          1425
21h4f8u194bwg          1375934778               20 TABLE ACCESS                   BY INDEX ROWID                       1113
21h4f8u194bwg          1375934778                6 FILTER                                                               418
21h4f8u194bwg          1375934778               13 NESTED LOOPS                                                         376
21h4f8u194bwg          1375934778               30 INDEX                          RANGE SCAN                            338
21h4f8u194bwg          1375934778               31 TABLE ACCESS                   BY INDEX ROWID BATCHED                318
21h4f8u194bwg          1375934778               32 INDEX                          RANGE SCAN                            250
21h4f8u194bwg          1375934778               11 NESTED LOOPS                                                         205
21h4f8u194bwg          1375934778               10 NESTED LOOPS                                                         129
21h4f8u194bwg          1375934778                8 NESTED LOOPS                                                         117
21h4f8u194bwg          1375934778                7 NESTED LOOPS                                                          87
21h4f8u194bwg          1375934778                9 NESTED LOOPS                                                          85
21h4f8u194bwg          1375934778               33 INDEX                          RANGE SCAN                             77
21h4f8u194bwg          1375934778               14 NESTED LOOPS                                                          53
21h4f8u194bwg          1375934778               19 INDEX                          FULL SCAN                              39
21h4f8u194bwg          1375934778               29 NESTED LOOPS                                                          15
21h4f8u194bwg          1375934778               28 NESTED LOOPS                                                          12
21h4f8u194bwg          1375934778                                                                                         7
21h4f8u194bwg          1375934778                  SELECT STATEMENT                                                       2
21h4f8u194bwg          1375934778                3 HASH                           GROUP BY                                1


Plan hash value: 2477006588
--------------------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                     | Name                   | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  |
--------------------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                              |                        |      1 |        | 26701 (100)|      1 |00:14:14.90 |     432M|   1002K|
|   1 |  SORT AGGREGATE                               |                        |      1 |      1 |            |      1 |00:14:14.90 |     432M|   1002K|
|   2 |   VIEW                                        |                        |      1 |    210K| 26701   (1)|    183K|00:14:14.89 |     432M|   1002K|
|   3 |    SORT GROUP BY                              |                        |      1 |    210K| 26701   (1)|    183K|00:14:14.88 |     432M|   1002K|
|   4 |     NESTED LOOPS                              |                        |      1 |    210K| 20685   (1)|     71M|00:28:18.22 |     432M|   1002K|
|   5 |      NESTED LOOPS                             |                        |      1 |    210K| 20685   (1)|     71M|00:25:16.31 |     217M|   1002K|
|   6 |       NESTED LOOPS                            |                        |      1 |    193K| 12960   (1)|     71M|00:23:49.43 |     214M|   1002K|
|   7 |        NESTED LOOPS                           |                        |      1 |    193K|  7167   (1)|     71M|00:20:57.57 |     140M|    998K|
|   8 |         NESTED LOOPS                          |                        |      1 |    193K|  5235   (1)|     71M|00:18:45.10 |    3349K|    997K|
|*  9 |          HASH JOIN                            |                        |      1 |    193K|  1364   (1)|     71M|00:17:12.27 |    3340K|    997K|
|  10 |           INDEX FULL SCAN                     | DOS_REFDOSS_REFLOT_IDX |      1 |    217K|    18   (0)|    217K|00:00:00.04 |    1812 |      0 |
|  11 |           NESTED LOOPS                        |                        |      1 |    193K|   482   (1)|     71M|00:16:47.54 |    3339K|    997K|
|  12 |            NESTED LOOPS                       |                        |      1 |    585K|   482   (1)|     71M|00:04:43.69 |     637K|    250K|
|  13 |             SORT UNIQUE                       |                        |      1 |   8168 |    29   (0)|     45 |00:00:00.01 |       0 |      0 |
|  14 |              COLLECTION ITERATOR PICKLER FETCH| SHOW_INVOICE_LIST      |      1 |   8168 |    29   (0)|     45 |00:00:00.01 |       0 |      0 |
|* 15 |             INDEX RANGE SCAN                  | VENFILIMIT_COMPTE_IDX  |     45 |   2295 |     1   (0)|     71M|00:04:36.66 |     637K|    250K|
|  16 |            TABLE ACCESS BY INDEX ROWID        | G_VENFILIMIT           |     71M|    758 |     2   (0)|     71M|00:11:41.03 |    2701K|    746K|
|  17 |          TABLE ACCESS BY INDEX ROWID          | G_DOSSIER              |     71M|      1 |     1   (0)|     71M|00:01:12.73 |    8369 |     19 |
|* 18 |           INDEX UNIQUE SCAN                   | DOS_REFDOSS            |     71M|      1 |     1   (0)|     71M|00:00:35.22 |    4256 |      0 |
|* 19 |         INDEX UNIQUE SCAN                     | EFI_REFELEM            |     71M|      1 |     1   (0)|     71M|00:01:52.16 |     136M|    420 |
|  20 |        TABLE ACCESS BY INDEX ROWID BATCHED    | G_PIECE                |     71M|      1 |     1   (0)|     71M|00:02:30.75 |      74M|   4062 |
|* 21 |         INDEX RANGE SCAN                      | PIE_REFPIECE           |     71M|      1 |     1   (0)|     71M|00:00:53.36 |    2225K|   1843 |
|* 22 |       INDEX RANGE SCAN                        | PIE_REFDOSS            |     71M|      1 |     1   (0)|     71M|00:01:06.44 |    3071K|      6 |
|* 23 |      TABLE ACCESS BY INDEX ROWID              | G_PIECE                |     71M|      1 |     1   (0)|     71M|00:02:43.27 |     215M|      1 |
--------------------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   9 - access("S"."REFDOSS"="V"."DECOMPTE_ID")
  15 - access("V"."COMPTE_ID"=VALUE(KOKBF$) AND "V"."LIMIT_ROLE"='FINANCING')
  18 - access("C"."REFDOSS"="S"."REFLOT")
  19 - access("E"."REFELEM"="V"."FI_ID")
  21 - access("L"."REFPIECE"="V"."LIMIT_ID")
  22 - access("P"."REFDOSS"="C"."REFDOSS" AND "P"."TYPPIECE"="C"."PIECEINIT")
       filter("P"."REFDOSS" IS NOT NULL)
  23 - filter(NVL("P"."FG150",'N')='N')
*/
/********************************OLD Metrics***************************************/

/********************************New SQL*******************************************/
WITH CONSUMPTION_PER_ITEM AS ( SELECT /*+ leading(I D S C P E R V L) use_nl(D S C P E V L) push_pred(R) no_merge(R) */
                                      FI_ID ITEM_ID , 
                                      MAX( V.CONSUMED_LIM ) KEEP ( DENSE_RANK LAST ORDER BY V.CONSUMED_LIM ) CONSUMED , 
                                      MAX( L.GPIDEVIS ) KEEP ( DENSE_RANK LAST ORDER BY V.CONSUMED_LIM ) CURRENCY 
                                 FROM TABLE(test_di_invoice_list.show_invoice_list) I,
                                      G_DOSSIER D , 
                                      G_DOSSIER S , 
                                      G_DOSSIER C , 
                                      G_PIECE P,
                                      G_ELEMFI E ,
                                      ( SELECT A.REFFACTURE
                                          FROM G_ELEMFI_AGGR A , 
                                               G_PIECE B , 
                                               G_OUTPMT O 
                                         WHERE B.REFPIECE = A.REFAGGR 
                                           AND O.REFER = B.GPIRESSORT ) R,
                                      G_VENFILIMIT V ,
                                      G_PIECE L 
                                WHERE I.COLUMN_VALUE = D.REFDOSS
                                  AND D.REFLOT = S.REFDOSS
                                  AND S.REFLOT = C.REFDOSS
                                  AND C.REFDOSS = P.REFDOSS(+)
                                  AND C.PIECEINIT = P.TYPPIECE(+)
                                  AND NVL( P.FG150(+), 'N' ) = 'N'
                                  AND D.REFDOSS = E.REFDOSS
                                  AND E.ACTIF = 'O'
                                  AND E.REFPIECE2 = R.REFFACTURE(+)
                                  AND (     NVL( P.FG150, 'N' ) = 'N'
                                        OR E.REFPIECE2 = R.REFFACTURE )
                                  AND S.REFDOSS = V.DECOMPTE_ID 
                                  AND E.REFELEM = V.FI_ID
                                  AND E.REFDOSS = V.COMPTE_ID
                                  AND V.LIMIT_ROLE = 'FINANCING' 
                                  AND V.LIMIT_ID = L.REFPIECE
                                GROUP BY FI_ID ), 
     CONSUMPTION_PER_CURRENCY AS ( SELECT CURRENCY, 
                                          SUM( CONSUMED ) CONSUMED 
                                     FROM CONSUMPTION_PER_ITEM 
                                    GROUP BY CURRENCY ) 
SELECT SUM( CASE WHEN CURRENCY = :B2 
                 THEN CONSUMED 
                 ELSE CH_TAUX.CONV_ORIG_DEST_TX( TO_CHAR( UTL_APP_DATE.GETAPPDATE(), 'j' ) , CONSUMED , CURRENCY , :B2 , 'MR' , :B2 , :B3 ) 
             END ) 
  FROM CONSUMPTION_PER_CURRENCY;
/********************************New SQL*******************************************/
/********************************New Metrics***************************************/
/*
Plan hash value: 1256863963
-----------------------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                        | Name                   | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  |
-----------------------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                                 |                        |      1 |        | 47897 (100)|      1 |00:00:05.26 |    3425K|     12 |
|   1 |  SORT AGGREGATE                                  |                        |      1 |      1 |            |      1 |00:00:05.26 |    3425K|     12 |
|   2 |   VIEW                                           |                        |      1 |      1 | 47897   (1)|      2 |00:00:05.15 |    3423K|     11 |
|   3 |    HASH GROUP BY                                 |                        |      1 |      1 | 47897   (1)|      2 |00:00:05.15 |    3423K|     11 |
|   4 |     VIEW                                         |                        |      1 |      1 | 47896   (1)|  12014 |00:00:05.15 |    3423K|     11 |
|   5 |      SORT GROUP BY                               |                        |      1 |      1 | 47896   (1)|  12014 |00:00:05.15 |    3423K|     11 |
|   6 |       NESTED LOOPS                               |                        |      1 |      1 | 47895   (1)|    681K|00:00:04.61 |    3423K|     11 |
|   7 |        NESTED LOOPS                              |                        |      1 |      1 | 47895   (1)|    681K|00:00:03.24 |    2061K|     11 |
|   8 |         NESTED LOOPS                             |                        |      1 |      1 | 47894   (1)|    681K|00:00:01.53 |     699K|      4 |
|*  9 |          FILTER                                  |                        |      1 |        |            |  12014 |00:00:00.06 |    3590 |      3 |
|  10 |           NESTED LOOPS OUTER                     |                        |      1 |  14470 | 44710   (1)|  12014 |00:00:00.06 |    3590 |      3 |
|  11 |            NESTED LOOPS                          |                        |      1 |  14474 |  1288   (1)|  12014 |00:00:00.03 |    2344 |      3 |
|  12 |             NESTED LOOPS OUTER                   |                        |      1 |   8869 |   844   (0)|     45 |00:00:00.01 |     634 |      3 |
|  13 |              NESTED LOOPS                        |                        |      1 |   8129 |   519   (0)|     45 |00:00:00.01 |     318 |      3 |
|  14 |               NESTED LOOPS                       |                        |      1 |   8148 |   356   (0)|     45 |00:00:00.01 |     185 |      3 |
|  15 |                NESTED LOOPS                      |                        |      1 |   8168 |   192   (0)|     45 |00:00:00.01 |      92 |      3 |
|  16 |                 COLLECTION ITERATOR PICKLER FETCH| SHOW_INVOICE_LIST      |      1 |   8168 |    29   (0)|     45 |00:00:00.01 |       0 |      0 |
|* 17 |                 INDEX RANGE SCAN                 | DOS_REFDOSS_REFLOT_IDX |     45 |      1 |     1   (0)|     45 |00:00:00.01 |      92 |      3 |
|* 18 |                INDEX RANGE SCAN                  | DOS_REFDOSS_REFLOT_IDX |     45 |      1 |     1   (0)|     45 |00:00:00.01 |      93 |      0 |
|  19 |               TABLE ACCESS BY INDEX ROWID        | G_DOSSIER              |     45 |      1 |     1   (0)|     45 |00:00:00.01 |     133 |      0 |
|* 20 |                INDEX UNIQUE SCAN                 | DOS_REFDOSS            |     45 |      1 |     1   (0)|     45 |00:00:00.01 |      93 |      0 |
|* 21 |              TABLE ACCESS BY INDEX ROWID BATCHED | G_PIECE                |     45 |      1 |     1   (0)|     40 |00:00:00.01 |     316 |      0 |
|* 22 |               INDEX RANGE SCAN                   | PIE_REFDOSS            |     45 |      1 |     1   (0)|     45 |00:00:00.01 |     139 |      0 |
|  23 |             TABLE ACCESS BY INDEX ROWID BATCHED  | G_ELEMFI               |     45 |      2 |     1   (0)|  12014 |00:00:00.02 |    1710 |      0 |
|* 24 |              INDEX RANGE SCAN                    | G_ELEMFI$REFDOSS_ACTIF |     45 |      3 |     1   (0)|  12014 |00:00:00.01 |     430 |      0 |
|  25 |            VIEW PUSHED PREDICATE                 |                        |  12014 |      1 |     3   (0)|     80 |00:00:00.03 |    1246 |      0 |
|  26 |             NESTED LOOPS                         |                        |  12014 |      1 |     3   (0)|     80 |00:00:00.02 |    1246 |      0 |
|  27 |              NESTED LOOPS                        |                        |  12014 |      1 |     2   (0)|     80 |00:00:00.02 |    1203 |      0 |
|* 28 |               INDEX RANGE SCAN                   | AK_KEY_2_G_ELEMFI      |  12014 |      1 |     1   (0)|    136 |00:00:00.01 |     740 |      0 |
|* 29 |               TABLE ACCESS BY INDEX ROWID BATCHED| G_PIECE                |    136 |      1 |     1   (0)|     80 |00:00:00.01 |     463 |      0 |
|* 30 |                INDEX RANGE SCAN                  | PIE_REFPIECE           |    136 |      1 |     1   (0)|    136 |00:00:00.01 |     238 |      0 |
|* 31 |              INDEX RANGE SCAN                    | G_OUTPMT_REFER_IDX     |     80 |      1 |     1   (0)|     80 |00:00:00.01 |      43 |      0 |
|* 32 |          TABLE ACCESS BY INDEX ROWID BATCHED     | G_VENFILIMIT           |  12014 |      1 |     1   (0)|    681K|00:00:01.39 |     695K|      1 |
|* 33 |           INDEX RANGE SCAN                       | GVFL_CONSUMED_IDX      |  12014 |     19 |     1   (0)|    681K|00:00:00.20 |   42122 |      1 |
|* 34 |         INDEX RANGE SCAN                         | PIE_REFPIECE           |    681K|      1 |     1   (0)|    681K|00:00:01.49 |    1362K|      7 |
|  35 |        TABLE ACCESS BY INDEX ROWID               | G_PIECE                |    681K|      1 |     1   (0)|    681K|00:00:01.17 |    1361K|      0 |
-----------------------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   9 - filter((NVL("P"."FG150",'N')='N' OR "E"."REFPIECE2"="R"."REFFACTURE"))
  17 - access("D"."REFDOSS"=VALUE(KOKBF$))
  18 - access("D"."REFLOT"="S"."REFDOSS")
  20 - access("S"."REFLOT"="C"."REFDOSS")
  21 - filter(NVL("P"."FG150",'N')='N')
  22 - access("C"."REFDOSS"="P"."REFDOSS" AND "C"."PIECEINIT"="P"."TYPPIECE")
       filter("P"."REFDOSS" IS NOT NULL)
  24 - access("D"."REFDOSS"="E"."REFDOSS" AND "E"."ACTIF"='O')
  28 - access("A"."REFFACTURE"="E"."REFPIECE2")
  29 - filter("B"."GPIRESSORT" IS NOT NULL)
  30 - access("B"."REFPIECE"="A"."REFAGGR")
  31 - access("O"."REFER"="B"."GPIRESSORT")
  32 - filter(("E"."REFDOSS"="V"."COMPTE_ID" AND "S"."REFDOSS"="V"."DECOMPTE_ID"))
  33 - access("E"."REFELEM"="V"."FI_ID" AND "V"."LIMIT_ROLE"='FINANCING')
       filter("V"."LIMIT_ROLE"='FINANCING')
  34 - access("V"."LIMIT_ID"="L"."REFPIECE")

Hint Report (identified by operation id / Query Block Name / Object Alias):
Total hints for statement: 10 (U - Unused (1))
---------------------------------------------------------------------------

   4 -  SEL$F5BB74E1 / R@SEL$1
         U -  push_pred(R)
           -  no_merge(R)

   5 -  SEL$F5BB74E1
           -  leading(I D S C P E R V L)

  17 -  SEL$F5BB74E1 / D@SEL$1
           -  use_nl(D S C P E V L)

  18 -  SEL$F5BB74E1 / S@SEL$1
           -  use_nl(D S C P E V L)

  19 -  SEL$F5BB74E1 / C@SEL$1
           -  use_nl(D S C P E V L)

  21 -  SEL$F5BB74E1 / P@SEL$1
           -  use_nl(D S C P E V L)

  23 -  SEL$F5BB74E1 / E@SEL$1
           -  use_nl(D S C P E V L)

  32 -  SEL$F5BB74E1 / V@SEL$1
           -  use_nl(D S C P E V L)

  34 -  SEL$F5BB74E1 / L@SEL$1
           -  use_nl(D S C P E V L)

*/
/********************************New Metrics***************************************/

/********************************Index statistics**********************************/

/********************************Other SQLs****************************************/          
/*

*/ 
/********************************Other SQLs****************************************/              
