﻿   ############################# BEFORE PATCHING ###################
   
 Database : Oracle
Node: clm100511.8725.1469.ecs.hp.com


ps -ef | grep pmon

ps -ef | grep tns


dbspicol OFF
dbspicol ON


####### Stop databases ######
 su - oracle
 
. oraenv

====== DKO_ETS
========DIS_DS
=======DIGIS_TI
========OVEDWR_T
=======DVNCI_D
========MODW_D
=======MODW_TI
======WEBEDI_A
======PPOR_D
======DIS_T
=====DIS_ETS
======DKO_D
======DKO_DS
======STL_TI
----OVEDWZ_D
=====OVMDM_D
====OVEDWS_D
======OVEDWR_D
=====DAF_D
=====OVEDWS_A
======STL_D
=======DIS_D
=======DAF_TI
=======OVEDWR_A
========OVEDWS_I
======OVEDWR_I
=======DKO_T
=======OVEDWS_T
=======OVOS_D
========DIGIS_D

##### /oracle/product/12.2.0.1.0_EE_part  ######

DIS_D
DIS_DS
DIS_T
DIS_ETSN
DKO_D
DKO_DS
DKO_T
DKO_ETS
OVEDWS_D
OVEDWR_D
OVEDWS_T
OVEDWR_T
OVEDWZ_D
OVEDWS_A
OVEDWR_A
OVEDWS_I
OVEDWR_1  ???????
OVEDWR_I
OVMDM_D


###### /oracle/product/12.2.0.1.0_EE   ######

OVOS_D
DIGIS_D
DIGIS_TI
DVNCI_D
MODW_D
PPOR_D
MODW_TI
WEBEDI_A


###### /oracle/product/12.2.0.1.181016_EE #####

DAF_D
DAF_TI
STL_D
STL_TI





sqlplus / as sysdba

shutdown immediate;

exit
#### s oracle user
lsnrctl stop <name of the listener>

vi /etc/oratab
: 32,70s/:Y/:N/g     this will edit all necessary entries from Y to N



#####################  AFTER PATCHING ###################

ps -ef | grep pmon

ps -ef | grep tns

•#######   Be sure that no pmons and listeners are running (stop all listeners before relink !)  ######

su - oracle

. oraenv
DAF_D

$ORACLE_HOME/bin/relink all

lsnrctl start LISTENER_STL_VO
lsnrctl start LISTENER_STL_PRIV
lsnrctl start LISTENER_STLTI_VO
lsnrctl start LISTENER_STLTI_PRIV


. oraenv
OVOS_D

$ORACLE_HOME/bin/relink all

lsnrctl start LISTENER_MODW_PRIV
lsnrctl start LISTENER_MODW_VO
lsnrctl start LISTENER_WEBEDITI_VO
lsnrctl start LISTENER_WEBEDITI_PRIV
lsnrctl start LISTENER_MODWTI_VO
lsnrctl start LISTENER_MODWTI_PRIV
lsnrctl start LISTENER_PPOR_VO
lsnrctl start LISTENER_PPOR_PRIV
lsnrctl start LISTENER_DIGIS_VO
lsnrctl start LISTENER_DIGIS_PRIV
lsnrctl start LISTENER_DVNCI_VO
lsnrctl start LISTENER_DVNCI_PRIV
lsnrctl start LISTENER_DIGISTI_PRIV
lsnrctl start LISTENER_DIGISTI_VO


. oraenv
DIS_D

$ORACLE_HOME/bin/relink all

lsnrctl start LISTENER_OVMDM_VO
lsnrctl start LISTENER_OVMDM_PRIV
lsnrctl start LISTENER_DWHTI_VO
lsnrctl start LISTENER_DWHTI_PRIV
lsnrctl start LISTENER_DIS_VO
lsnrctl start LISTENER_DIS_PRIV
lsnrctl start LISTENER_DISREPL_VO
lsnrctl start LISTENER_DISREPL_PRIV
lsnrctl start LISTENER_OPI_PRIV
lsnrctl start LISTENER_OPI_VO
lsnrctl start LISTENER_DIS_ET_REP_VO
lsnrctl start LISTENER_DIS_ET_REP_PRIV



vi /etc/oratab
: 32,70s/:N/:Y/g     this will edit all necessary entries from N to Y 



### Start databases #####

        After relink and started listener, please startup the databases:

su - oracle
. oraenv
<bazata>

sqlplus / as sysdba

Connected to:
Oracle Database 12c Enterprise Edition Release 12.2.0.1.0 - 64bit Production

SQL> startup;


exit
dbspicol ON


The databases and the listeners on server clm100511.8725.1469.ecs.hp.com were stopped successfully. You can continue with the paching .





