/********************************************************************************
*********       E-mail subject: IMBDEV-11992
*********             Instance: PROD
*********          Description: 
Problem:
SQLs 60z8jc35ttb8q, 2ygcq7pt9jmnu, 9xyjhud4sy3wy from the trace on PROD can be optimized for better performance.

Analysis:
The main problem from performance point of view was the time for parsing. The solution that Atanas Orechkov suggested in IMBDEV-11992
helps to reduce the time for parsing, but we found that in SQLs 60z8jc35ttb8q, 2ygcq7pt9jmnu, 9xyjhud4sy3wy we can make some more optimization 
by using hints to force Oracle to make better execution plan. 

Suggestion:
Please change the SQLs as it is shown in the New SQL section below.

*********               SQL_ID: 60z8jc35ttb8q, 2ygcq7pt9jmnu, 9xyjhud4sy3wy
*********      Program/Package: 
*********              Request: Dimitare Ivanov
*********               Author: Dimitar Dimitrov
********* Received e-mail date: 05/06/2024
*********      Resolution date: 11/06/2024
*********  Trace old file here: \\epox\specifs\performance\tmp\
*********  Trace new file here:
***********************************************************************************/

/********************************OLD SQL*******************************************/
-- 60z8jc35ttb8q, 

SELECT SUM(SOLDE_CONV) AS AMOUNT
  FROM (SELECT /*+ no_index(GE IDX_FFSI_G_ELEMFI) */
         DECODE('EUR',
                GD_COMPTE.devise,
                DECODE(P.dt10, NULL, P.mt09, ftr_util.SoldeF(GE.refelem)),
                GD_DECOMPTE.devise,
                DECODE(P.dt10, NULL, P.mt24, ftr_util.SoldeF_DCPT(GE.refelem)),
                Ch_Taux.Conv_Orig_Dest_Tx(TO_CHAR(SYSDATE, 'j'),
                                          NVL(DECODE(P.dt10,
                                                     NULL,
                                                     P.mt09,
                                                     ftr_util.SoldeF(GE.refelem)),
                                              0),
                                          GD_COMPTE.devise,
                                          'EUR',
                                          'MER',
                                          ftr_fin_factor.getCurrency(GD_COMPTE.reffactor),
                                          ftr_fin_factor.getPays(GD_COMPTE.reffactor))) AS SOLDE_CONV
          FROM g_elemfi       GE,
               g_dossier      GD_COMPTE,
               g_dossier      GD_DECOMPTE,
               t_intervenants TI_COMPTE,
               t_intervenants TI_DECOMPTE,
               g_piece        P
         WHERE GE.dttraite_dt IS NULL
           AND GE.dtannul_dt IS NULL
           AND GE.refdoss = GD_COMPTE.refdoss
           AND GD_COMPTE.categdoss LIKE 'COMPTE%'
           AND GD_COMPTE.refdoss = TI_COMPTE.refdoss
           AND GE.actif = 'O'
           AND GD_DECOMPTE.reflot = '0001010163'
           AND TI_DECOMPTE.refindividu = 'A600DQHD'
           AND EXISTS
         (SELECT 1
                  FROM g_individu GI
                 WHERE GI.refindividu = TI_DECOMPTE.refindividu
                   AND (GI.str36 IS NULL OR
                       GI.str36 IN (SELECT str1
                                       FROM g_indivparam GP
                                      WHERE GP.refindividu = 'A6004VFN'
                                        AND type = 'type_indiv')))
           AND EXISTS
         (SELECT 1
                  FROM g_individu GI
                 WHERE GI.refindividu = TI_COMPTE.refindividu
                   AND (GI.str36 IS NULL OR
                       GI.str36 IN (SELECT str1
                                       FROM g_indivparam GP
                                      WHERE GP.refindividu = 'A6004VFN'
                                        AND type = 'type_indiv')))
           AND P.typpiece = 'FACTURE'
           AND P.gpiheure = GE.refelem
           AND GE.TYPE IN ('FACTURE', 'NOTE DE CREDIT')
           AND TI_COMPTE.reftype = 'DB'
           AND GD_COMPTE.reflot = GD_DECOMPTE.refdoss
           AND GD_DECOMPTE.categdoss LIKE 'DECOMPTE%'
           AND GD_DECOMPTE.refdoss = TI_DECOMPTE.refdoss
           AND TI_DECOMPTE.reftype =
               DECODE(GD_DECOMPTE.categdoss, 'DECOMPTE IMP', 'TC', 'CL')
           AND EXISTS (SELECT 1
                  FROM g_piecedet PD
                 WHERE PD.refpiece = P.refpiece
                   AND GD_COMPTE.refdoss = PD.refdoss
                   AND PD.type = 'PROROGATION')) V_FACT;

-- 2ygcq7pt9jmnu

select COUNT_TOTAL      count_total,
       NON_ECHU         non_echu,
       ECHU             echu,
       ECHU_30          echu_30,
       ECHU30           echu30,
       ECHU60           echu60,
       ECHU90           echu90,
       ECHU120          echu120,
       ECHU180          echu180,
       ECHU360          echu360,
       COUNT_BIEN       count_bien,
       COUNT25          count25,
       COUNT15          count15,
       COUNT26          count26,
       COUNT_PAST_EXT   count_past_ext,
       COUNT_MASTER_INV count_master_inv,
       COUNT13          count13,
       COUNT14          count14,
       COUNT_NC         count_nc,
       COUNT_COUVERT    count_couvert,
       COUNT_FIN        count_fin,
       COUNT_COV_NFIN   count_cov_nfin,
       COUNT_NCOV_NFIN  count_ncov_nfin,
       IMPAYE           impaye,
       ENC_IMPAYE       enc_impaye
  from (SELECT SUM(solde_conv) AS COUNT_TOTAL,
               SUM(DECODE(SIGN(dtdebut - TO_CHAR(SYSDATE, 'j')),
                          1,
                          solde_conv,
                          0)) NON_ECHU,
               SUM(DECODE(SIGN(dtdebut - TO_CHAR(SYSDATE, 'j')),
                          -1,
                          solde_conv,
                          0,
                          solde_conv,
                          0)) ECHU,
               SUM(DECODE(SIGN(dtdebut - TO_CHAR(SYSDATE - 0, 'j')),
                          -1,
                          DECODE(SIGN(dtdebut + 1 -
                                      TO_CHAR(SYSDATE - 30, 'j')),
                                 1,
                                 solde_conv,
                                 0),
                          0,
                          solde_conv,
                          0)) ECHU_30,
               SUM(DECODE(SIGN(dtdebut - TO_CHAR(SYSDATE - 31, 'j')),
                          -1,
                          DECODE(SIGN(dtdebut + 1 -
                                      TO_CHAR(SYSDATE - 60, 'j')),
                                 1,
                                 solde_conv,
                                 0),
                          0,
                          solde_conv,
                          0)) ECHU30,
               SUM(DECODE(SIGN(dtdebut - TO_CHAR(SYSDATE - 61, 'j')),
                          -1,
                          DECODE(SIGN(dtdebut + 1 -
                                      TO_CHAR(SYSDATE - 90, 'j')),
                                 1,
                                 solde_conv,
                                 0),
                          0,
                          solde_conv,
                          0)) ECHU60,
               SUM(DECODE(SIGN(dtdebut - TO_CHAR(SYSDATE - 91, 'j')),
                          -1,
                          DECODE(SIGN(dtdebut + 1 -
                                      TO_CHAR(SYSDATE - 120, 'j')),
                                 1,
                                 solde_conv,
                                 0),
                          0,
                          solde_conv,
                          0)) ECHU90,
               SUM(DECODE(SIGN(dtdebut - TO_CHAR(SYSDATE - 121, 'j')),
                          -1,
                          DECODE(SIGN(dtdebut + 1 -
                                      TO_CHAR(SYSDATE - 180, 'j')),
                                 1,
                                 solde_conv,
                                 0),
                          0,
                          solde_conv,
                          0)) ECHU120,
               SUM(DECODE(SIGN(dtdebut - TO_CHAR(SYSDATE - 181, 'j')),
                          -1,
                          DECODE(SIGN(dtdebut + 1 -
                                      TO_CHAR(SYSDATE - 99999, 'j')),
                                 1,
                                 solde_conv,
                                 0),
                          0,
                          solde_conv,
                          0)) ECHU180,
               NULL ECHU360,
               SUM(mt48_conv) AS COUNT15,
               SUM(mt09_mt48_conv) COUNT26,
               SUM(DECODE(SIGN(dt14 - TO_CHAR(SYSDATE, 'j')),
                          -1,
                          solde_conv,
                          0)) COUNT_PAST_EXT,
               SUM(DECODE(TYPE,
                          'FINANCEMENT SUR BIEN',
                          solde_conv,
                          'REEVALUATION DU BIEN - DIM',
                          solde_conv,
                          'REEVALUATION DU BIEN - AUGM',
                          solde_conv,
                          0)) AS COUNT_BIEN,
               SUM(DECODE(st09, 'NGPC', solde_conv, 0)) AS COUNT25,
               SUM(DECODE(st09, 'W', solde_conv, 0)) AS COUNT13,
               SUM(DECODE(st09, 'W', DECODE(fg09, 'O', solde_conv, 0), 0)) AS COUNT14,
               SUM(DECODE(TYPE,
                          'NOTE DE CREDIT',
                          solde_conv,
                          'BULK DEDUCTION',
                          solde_conv,
                          0)) AS COUNT_NC,
               SUM(DECODE(TYPE,
                          'NOTE DE DEBIT',
                          solde_conv,
                          'FACTURE',
                          solde_conv,
                          0)) AS IMPAYE,
               SUM(DECODE(SIGN(montant_dos),
                          1,
                          DECODE(mt01,
                                 NULL,
                                 0,
                                 DECODE(SIGN(mt01), 1, mt01_conv, 0)),
                          -1,
                          DECODE(mt01, NULL, 0, mt01_conv),
                          0)) COUNT_COUVERT,
               SUM(fin_conv) AS COUNT_FIN,
               SUM(cov_nfin_conv) AS COUNT_COV_NFIN,
               SUM(ncov_nfin_conv) AS COUNT_NCOV_NFIN,
               SUM(enc_impaye) AS enc_impaye,
               SUM(master_inv) AS COUNT_MASTER_INV
          FROM (SELECT GE.dtdebut,
                       GE.dt_emis,
                       GE.refelem,
                       GP_FACT.st09,
                       GP_FACT.fg09,
                       GE.type,
                       GP_FACT.mt09,
                       GP_FACT.dt14,
                       DECODE('EUR',
                              GD_COMPTE.devise,
                              GP_FACT.mt48,
                              GD_DECOMPTE.devise,
                              GP_FACT.mt49,
                              Ch_Taux.Conv_Orig_Dest_Tx(TO_CHAR(SYSDATE, 'j'),
                                                        NVL(GP_FACT.mt48, 0),
                                                        GD_COMPTE.devise,
                                                        'EUR',
                                                        'MER',
                                                        ftr_fin_factor.getCurrency(GD_COMPTE.reffactor),
                                                        ftr_fin_factor.getPays(GD_COMPTE.reffactor))) AS MT48_CONV,
                       DECODE('EUR',
                              GD_COMPTE.devise,
                              NVL(GP_FACT.mt09, 0) - NVL(GP_FACT.mt48, 0),
                              GD_DECOMPTE.devise,
                              NVL(GP_FACT.mt24, 0) - NVL(GP_FACT.mt49, 0),
                              Ch_Taux.Conv_Orig_Dest_Tx(TO_CHAR(SYSDATE, 'j'),
                                                        NVL(GP_FACT.mt09, 0) -
                                                        NVL(GP_FACT.mt48, 0),
                                                        GD_COMPTE.devise,
                                                        'EUR',
                                                        'MER',
                                                        ftr_fin_factor.getCurrency(GD_COMPTE.reffactor),
                                                        ftr_fin_factor.getPays(GD_COMPTE.reffactor))) AS MT09_MT48_CONV,
                       GE.montant_dos,
                       DECODE('EUR',
                              GD_COMPTE.devise,
                              DECODE(GP_FACT.dt10,
                                     NULL,
                                     GP_FACT.mt09,
                                     ftr_util.SoldeF(GE.refelem)),
                              GD_DECOMPTE.devise,
                              DECODE(GP_FACT.dt10,
                                     NULL,
                                     GP_FACT.mt24,
                                     ftr_util.SoldeF_DCPT(GE.refelem)),
                              Ch_Taux.Conv_Orig_Dest_Tx(TO_CHAR(SYSDATE, 'j'),
                                                        NVL(DECODE(GP_FACT.dt10,
                                                                   NULL,
                                                                   GP_FACT.mt09,
                                                                   ftr_util.SoldeF(GE.refelem)),
                                                            0),
                                                        GD_COMPTE.devise,
                                                        'EUR',
                                                        'MER',
                                                        ftr_fin_factor.getCurrency(GD_COMPTE.reffactor),
                                                        ftr_fin_factor.getPays(GD_COMPTE.reffactor))) AS SOLDE_CONV,
                       GP_FACT.mt01,
                       DECODE('EUR',
                              GD_COMPTE.devise,
                              GP_FACT.mt01,
                              GD_DECOMPTE.devise,
                              GP_FACT.mt27,
                              Ch_Taux.Conv_Orig_Dest_Tx(TO_CHAR(SYSDATE, 'j'),
                                                        NVL(GP_FACT.mt01, 0),
                                                        GD_COMPTE.devise,
                                                        'EUR',
                                                        'MER',
                                                        ftr_fin_factor.getCurrency(GD_COMPTE.reffactor),
                                                        ftr_fin_factor.getPays(GD_COMPTE.reffactor))) AS MT01_CONV,
                       GE.devise_dos,
                       GD_DECOMPTE.devise AS DEVISE_DCPT,
                       DECODE('EUR',
                              GD_DECOMPTE.devise,
                              ROUND(NVL(GP_FACT.mt24, 0), 2) -
                              ROUND(NVL(VR.real_amount_dec, 0), 2),
                              Ch_Taux.Conv_Orig_Dest_Tx(TO_CHAR(SYSDATE, 'j'),
                                                        NVL(GP_FACT.mt24, 0) -
                                                        NVL(VR.real_amount_dec,
                                                            0),
                                                        GD_DECOMPTE.devise,
                                                        'EUR',
                                                        'MER',
                                                        ftr_fin_factor.getCurrency(GD_COMPTE.reffactor),
                                                        ftr_fin_factor.getPays(GD_COMPTE.reffactor))) AS FIN_CONV,
                       DECODE('EUR',
                              GD_COMPTE.devise,
                              GP_FACT.mt63,
                              GD_DECOMPTE.devise,
                              GP_FACT.mt64,
                              Ch_Taux.Conv_Orig_Dest_Tx(TO_CHAR(SYSDATE, 'j'),
                                                        NVL(GP_FACT.mt63, 0),
                                                        GD_COMPTE.devise,
                                                        'EUR',
                                                        'MER',
                                                        ftr_fin_factor.getCurrency(GD_COMPTE.reffactor),
                                                        ftr_fin_factor.getPays(GD_COMPTE.reffactor))) AS COV_NFIN_CONV,
                       DECODE('EUR',
                              GD_COMPTE.devise,
                              GP_FACT.mt65,
                              GD_DECOMPTE.devise,
                              GP_FACT.mt66,
                              Ch_Taux.Conv_Orig_Dest_Tx(TO_CHAR(SYSDATE, 'j'),
                                                        NVL(GP_FACT.mt65, 0),
                                                        GD_COMPTE.devise,
                                                        'EUR',
                                                        'MER',
                                                        ftr_fin_factor.getCurrency(GD_COMPTE.reffactor),
                                                        ftr_fin_factor.getPays(GD_COMPTE.reffactor))) AS NCOV_NFIN_CONV,
                       0 AS enc_impaye,
                       0 AS MASTER_INV
                  FROM g_piece GP_FACT,
                       g_elemfi GE,
                       g_db_ptf_item PI,
                       g_dossier GD_COMPTE,
                       g_dossier GD_DECOMPTE,
                       g_piece GP_CESS,
                       t_intervenants TI_COMPTE,
                       t_intervenants TI_DECOMPTE,
                       v_elemfi VE,
                       (SELECT SUM(real_amount_dec) REAL_AMOUNT_DEC, refelem
                          FROM g_venrestriction
                         GROUP BY refelem) VR
                 WHERE GP_FACT.typpiece = 'FACTURE'
                   AND GP_FACT.gpiheure = GE.refelem
                   AND GE.refelem = PI.refelem
                   AND GE.dttraite_dt IS NULL
                   AND GE.dtannul_dt IS NULL
                   AND GE.refdoss = GD_COMPTE.refdoss
                   AND GD_COMPTE.categdoss LIKE 'COMPTE%'
                   AND GE.type = VE.type(+)
                   AND NVL(VE.fg_parent_invoice, 'N') <> 'O'
                   AND GD_COMPTE.refdoss = TI_COMPTE.refdoss
                   AND GE.actif = 'O'
                   AND GE.refelem = VR.refelem(+)
                   AND GD_DECOMPTE.reflot = '0001010163'
                   AND TI_DECOMPTE.refindividu = 'A600DQHD'
                   AND EXISTS
                 (SELECT 1
                          FROM g_individu GI
                         WHERE GI.refindividu = TI_DECOMPTE.refindividu
                           AND (GI.str36 IS NULL OR
                               GI.str36 IN
                               (SELECT str1
                                   FROM g_indivparam GP
                                  WHERE GP.refindividu = 'A6004VFN'
                                    AND type = 'type_indiv')))
                   AND EXISTS
                 (SELECT 1
                          FROM g_individu GI
                         WHERE GI.refindividu = TI_COMPTE.refindividu
                           AND (GI.str36 IS NULL OR
                               GI.str36 IN
                               (SELECT str1
                                   FROM g_indivparam GP
                                  WHERE GP.refindividu = 'A6004VFN'
                                    AND type = 'type_indiv')))
                   AND TI_COMPTE.reftype = 'DB'
                   AND GD_COMPTE.reflot = GD_DECOMPTE.refdoss
                   AND GD_DECOMPTE.categdoss LIKE 'DECOMPTE%'
                   AND GP_FACT.gpidepot = GP_CESS.refpiece(+)
                   AND GP_CESS.typpiece(+) = 'CESSION'
                   AND GD_DECOMPTE.refdoss = TI_DECOMPTE.refdoss
                   AND TI_DECOMPTE.reftype =
                       DECODE(GD_DECOMPTE.categdoss,
                              'DECOMPTE IMP',
                              'TC',
                              'CL')
                UNION ALL
                SELECT /*+ index(GE (refdoss,type))*/
                 GE.dtdebut,
                 GE.dt_emis,
                 GE.refelem,
                 NULL st09,
                 NULL fg09,
                 GE.type,
                 NULL mt09,
                 NULL dt14,
                 NULL MT48_CONV,
                 NULL MT09_MT48_CONV,
                 GE.montant_dos,
                 DECODE('EUR',
                        GD_COMPTE.devise,
                        ftr_util.SoldeF(GE.refelem),
                        GD_DECOMPTE.devise,
                        ftr_util.SoldeF_DCPT(GE.refelem),
                        Ch_Taux.Conv_Orig_Dest_Tx(TO_CHAR(SYSDATE, 'j'),
                                                  NVL(ftr_util.SoldeF(GE.refelem),
                                                      0),
                                                  GD_COMPTE.devise,
                                                  'EUR',
                                                  'MER',
                                                  ftr_fin_factor.getCurrency(GD_COMPTE.reffactor),
                                                  ftr_fin_factor.getPays(GD_COMPTE.reffactor))) AS SOLDE_CONV,
                 NULL mt01,
                 NULL MT01_CONV,
                 GE.devise_dos,
                 GD_DECOMPTE.devise AS DEVISE_DCPT,
                 0 AS FIN_CONV,
                 0 AS COV_NFIN_CONV,
                 0 AS NCOV_NFIN_CONV,
                 0 AS enc_impaye,
                 0 AS MASTER_INV
                  FROM g_elemfi       GE,
                       g_dossier      GD_COMPTE,
                       g_dossier      GD_DECOMPTE,
                       t_intervenants TI_COMPTE,
                       t_intervenants TI_DECOMPTE,
                       v_elemfi       VE
                 WHERE GE.dttraite_dt IS NULL
                   AND GE.dtannul_dt IS NULL
                   AND GE.refdoss = GD_COMPTE.refdoss
                   AND GE.type = VE.type
                   AND GE.type IN
                       ('NOTE DE DEBIT', 'BULK DEDUCTION', 'FACT NON RECUE')
                   AND DECODE(GE.type,
                              'NOTE DE DEBIT',
                              1,
                              'FACT NON RECUE',
                              1,
                              -1) * GE.montant_mvt > 0
                   AND GD_COMPTE.categdoss LIKE 'COMPTE%'
                   AND GD_COMPTE.refdoss = TI_COMPTE.refdoss
                   AND GD_DECOMPTE.reflot = '0001010163'
                   AND TI_DECOMPTE.refindividu = 'A600DQHD'
                   AND EXISTS
                 (SELECT 1
                          FROM g_individu GI
                         WHERE GI.refindividu = TI_DECOMPTE.refindividu
                           AND (GI.str36 IS NULL OR
                               GI.str36 IN
                               (SELECT str1
                                   FROM g_indivparam GP
                                  WHERE GP.refindividu = 'A6004VFN'
                                    AND type = 'type_indiv')))
                   AND EXISTS
                 (SELECT 1
                          FROM g_individu GI
                         WHERE GI.refindividu = TI_COMPTE.refindividu
                           AND (GI.str36 IS NULL OR
                               GI.str36 IN
                               (SELECT str1
                                   FROM g_indivparam GP
                                  WHERE GP.refindividu = 'A6004VFN'
                                    AND type = 'type_indiv')))
                   AND TI_COMPTE.reftype = 'DB'
                   AND GD_COMPTE.reflot = GD_DECOMPTE.refdoss
                   AND GD_DECOMPTE.categdoss LIKE 'DECOMPTE%'
                   AND GD_DECOMPTE.refdoss = TI_DECOMPTE.refdoss
                   AND TI_DECOMPTE.reftype =
                       DECODE(GD_DECOMPTE.categdoss,
                              'DECOMPTE IMP',
                              'TC',
                              'CL')
                UNION ALL
                SELECT NVL(ENC.dtencaiss, ENC.dtreception) AS DTDEBUT,
                       NVL(ENC.dtencaiss, ENC.dtreception) AS DT_EMIS,
                       VENTIL.refencaiss AS REFELEM,
                       NULL AS ST09,
                       NULL AS FG09,
                       'enIMP' AS TYPE,
                       NULL AS mt09,
                       NULL AS dt14,
                       NULL AS MT48_CONV,
                       NULL AS MT09_MT48_CONV,
                       VENTIL.montant_dos,
                       0 AS SOLDE_CONV,
                       NULL AS MT01,
                       NULL AS MT01_CONV,
                       GD_COMPTE.devise AS DEVISE_DOS,
                       GD_DECOMPTE.devise AS DEVISE_DCPT,
                       0 AS FIN_CONV,
                       NULL AS COV_NFIN_CONV,
                       NULL AS NCOV_NFIN_CONV,
                       Ch_Taux.Conv_Orig_Dest_Tx(TO_CHAR(SYSDATE, 'j'),
                                                 NVL(VENTIL.montant_dos, 0),
                                                 GD_COMPTE.devise,
                                                 'EUR',
                                                 'MER',
                                                 ftr_fin_factor.getCurrency(GD_COMPTE.reffactor),
                                                 ftr_fin_factor.getPays(GD_COMPTE.reffactor)) AS enc_impaye,
                       0 AS MASTER_INV
                  FROM g_ventilenc    VENTIL,
                       g_encaissement ENC,
                       g_dossier      GD_COMPTE,
                       g_dossier      GD_DECOMPTE,
                       g_dossier      GD_CONTRAT,
                       t_intervenants TI_COMPTE,
                       t_intervenants TI_CONTRAT
                 WHERE ENC.refencaiss = VENTIL.refencaiss
                   AND ENC.typencaiss = 'e_saencaiss'
                   AND VENTIL.traite = '9'
                   AND ENC.dtimpaye_dt IS NOT NULL
                   AND VENTIL.refdoss = GD_COMPTE.refdoss
                   AND GD_COMPTE.reflot = GD_DECOMPTE.refdoss
                   AND GD_DECOMPTE.reflot = GD_CONTRAT.refdoss
                   AND 'IMPAYE' =
                       (SELECT pmt_status
                          FROM pmt_status
                         WHERE ref_payment = ENC.refencaiss
                           AND pmt_status_id =
                               (SELECT MAX(pmt_status_id)
                                  FROM pmt_status
                                 WHERE ref_payment = ENC.refencaiss))
                   AND GD_COMPTE.refdoss = TI_COMPTE.refdoss
                   AND GD_CONTRAT.refdoss = TI_CONTRAT.refdoss
                   AND GD_CONTRAT.refdoss = '0001010163'
                   AND TI_CONTRAT.refindividu = 'A600DQHD'
                   AND EXISTS
                 (SELECT 1
                          FROM g_individu GI
                         WHERE GI.refindividu = TI_CONTRAT.refindividu
                           AND (GI.str36 IS NULL OR
                               GI.str36 IN
                               (SELECT str1
                                   FROM g_indivparam GP
                                  WHERE GP.refindividu = 'A6004VFN'
                                    AND type = 'type_indiv')))
                   AND EXISTS
                 (SELECT 1
                          FROM g_individu GI
                         WHERE GI.refindividu = TI_COMPTE.refindividu
                           AND (GI.str36 IS NULL OR
                               GI.str36 IN
                               (SELECT str1
                                   FROM g_indivparam GP
                                  WHERE GP.refindividu = 'A6004VFN'
                                    AND type = 'type_indiv')))
                   AND TI_COMPTE.reftype = 'DB'
                   AND GD_COMPTE.categdoss LIKE 'COMPTE%'
                   AND GD_DECOMPTE.categdoss LIKE 'DECOMPTE%'
                   AND GD_CONTRAT.categdoss LIKE 'CONTRAT%'
                   AND TI_CONTRAT.reftype =
                       DECODE(GD_CONTRAT.categdoss, 'CONTRAT IMP', 'TC', 'CL')) V_FACT)
 where 1 = 1
   and 1 = 1;

-- 9xyjhud4sy3wy

SELECT SUM(SIGN(montant_ltg) * LEAST(ABS(montant_ltg), ABS(solde))) AS COUNT_DISP,
       SUM(SIGN(montant_ltg48) * LEAST(ABS(montant_ltg48), ABS(solde))) AS COUNT_DISP48,
       SUM(SIGN(montant_pda) * LEAST(ABS(montant_pda), ABS(solde))) AS COUNT_PDA
  FROM (SELECT /*+ no_index(GE IDX_FFSI_G_ELEMFI) */
         montant_ltg,
         montant_ltg48,
         montant_pda,
         Ch_Taux.Conv_Orig_Dest_Tx(TO_CHAR(SYSDATE, 'j'),
                                   DECODE(P.dt10,
                                          NULL,
                                          P.mt09,
                                          ftr_util.SoldeF(GE.refelem)),
                                   ge.devise_dos,
                                   'EUR',
                                   'MER',
                                   ftr_fin_factor.getCurrency(GD_COMPTE.reffactor),
                                   ftr_fin_factor.getPays(GD_COMPTE.reffactor)) solde
          FROM g_elemfi GE,
               g_dossier GD_COMPTE,
               g_dossier GD_DECOMPTE,
               t_intervenants TI_COMPTE,
               t_intervenants TI_DECOMPTE,
               g_piece P,
               (SELECT ge.refelem,
                       SUM(DECODE(C.TYPE,
                                  'LTG',
                                  DECODE(SUBSTR(C.raison, 1, 2),
                                         '48',
                                         0,
                                         'PD',
                                         0,
                                         DECODE(GE.type,
                                                'NOTE DE CREDIT',
                                                Ch_Taux.Conv_Orig_Dest_Tx(TO_CHAR(SYSDATE,
                                                                                  'j'),
                                                                          NVL(GE.montant_dos,
                                                                              0),
                                                                          GE.devise_dos,
                                                                          'EUR',
                                                                          'MER'),
                                                Ch_Taux.Conv_Orig_Dest_Tx(TO_CHAR(SYSDATE,
                                                                                  'j'),
                                                                          NVL(VC.montant,
                                                                              0),
                                                                          GE.devise_dos,
                                                                          'EUR',
                                                                          'MER'))),
                                  0)) AS montant_ltg,
                       SUM(DECODE(C.TYPE,
                                  'PD',
                                  DECODE(C.retrocession,
                                         'N',
                                         DECODE(GE.type,
                                                'NOTE 
  DE CREDIT',
                                                Ch_Taux.Conv_Orig_Dest_Tx(TO_CHAR(SYSDATE,
                                                                                  'j'),
                                                                          NVL(GE.montant_dos,
                                                                              0),
                                                                          GE.devise_dos,
                                                                          'EUR',
                                                                          'MER'),
                                                Ch_Taux.Conv_Orig_Dest_Tx(TO_CHAR(SYSDATE,
                                                                                  'j'),
                                                                          NVL(VC.montant,
                                                                              0),
                                                                          GE.devise_dos,
                                                                          'EUR',
                                                                          'MER')),
                                         'A',
                                         DECODE(GE.type,
                                                'NOTE DE CREDIT',
                                                Ch_Taux.Conv_Orig_Dest_Tx(TO_CHAR(SYSDATE,
                                                                                  'j'),
                                                                          NVL(GE.montant_dos,
                                                                              0),
                                                                          GE.devise_dos,
                                                                          'EUR',
                                                                          'MER'),
                                                Ch_Taux.Conv_Orig_Dest_Tx(TO_CHAR(SYSDATE,
                                                                                  'j'),
                                                                          NVL(VC.montant,
                                                                              0),
                                                                          GE.devise_dos,
                                                                          'EUR',
                                                                          'MER')),
                                         0),
                                  0)) AS montant_pda,
                       SUM(DECODE(C.TYPE,
                                  'LTG',
                                  DECODE(SUBSTR(C.raison, 1, 2),
                                         '48',
                                         DECODE(GE.type,
                                                'NOTE DE CREDIT',
                                                Ch_Taux.Conv_Orig_Dest_Tx(TO_CHAR(SYSDATE,
                                                                                  'j'),
                                                                          NVL(GE.montant_dos,
                                                                              0),
                                                                          GE.devise_dos,
                                                                          'EUR',
                                                                          'MER'),
                                                Ch_Taux.Conv_Orig_Dest_Tx(TO_CHAR(SYSDATE,
                                                                                  'j'),
                                                                          NVL(VC.montant,
                                                                              0),
                                                                          GE.devise_dos,
                                                                          'EUR',
                                                                          'MER')),
                                         'PD',
                                         DECODE(GE.type,
                                                'NOTE DE 
  CREDIT',
                                                Ch_Taux.Conv_Orig_Dest_Tx(TO_CHAR(SYSDATE,
                                                                                  'j'),
                                                                          NVL(GE.montant_dos,
                                                                              0),
                                                                          GE.devise_dos,
                                                                          'EUR',
                                                                          'MER'),
                                                Ch_Taux.Conv_Orig_Dest_Tx(TO_CHAR(SYSDATE,
                                                                                  'j'),
                                                                          NVL(VC.montant,
                                                                              0),
                                                                          GE.devise_dos,
                                                                          'EUR',
                                                                          'MER')),
                                         0),
                                  0)) AS montant_ltg48
                  FROM g_vencontest VC, g_contestation C, g_elemfi ge
                 WHERE VC.refelem = GE.refelem
                   AND VC.refcontest = C.refcontest
                   AND C.TYPE IN ('LTG', 'PD')
                   AND (C.dtresolution_dt IS NULL OR
                       TRUNC(C.dtresolution_dt) > TRUNC(SYSDATE))
                 GROUP BY ge.refelem) LTG
         WHERE GE.dttraite_dt IS NULL
           AND GE.dtannul_dt IS NULL
           AND GE.refdoss = GD_COMPTE.refdoss
           AND GD_COMPTE.categdoss LIKE 'COMPTE%'
           AND GD_COMPTE.refdoss = TI_COMPTE.refdoss
           AND GE.actif = 'O'
           AND GD_DECOMPTE.reflot = '0001010163'
           AND TI_DECOMPTE.refindividu = 'A600DQHD'
           AND EXISTS
         (SELECT 1
                  FROM g_individu GI
                 WHERE GI.refindividu = TI_DECOMPTE.refindividu
                   AND (GI.str36 IS NULL OR
                       GI.str36 IN (SELECT str1
                                       FROM g_indivparam GP
                                      WHERE GP.refindividu = 'A6004VFN'
                                        AND type = 'type_indiv')))
           AND EXISTS
         (SELECT 1
                  FROM g_individu GI
                 WHERE GI.refindividu = TI_COMPTE.refindividu
                   AND (GI.str36 IS NULL OR
                       GI.str36 IN (SELECT str1
                                       FROM g_indivparam GP
                                      WHERE GP.refindividu = 'A6004VFN'
                                        AND type = 'type_indiv')))
           AND ltg.refelem = ge.refelem
           AND P.typpiece = 'FACTURE'
           AND P.gpiheure = GE.refelem
           AND GE.TYPE IN ('FACTURE',
                           'NOTE DE 
  CREDIT')
           AND TI_COMPTE.reftype = 'DB'
           AND GD_COMPTE.reflot = GD_DECOMPTE.refdoss
           AND GD_DECOMPTE.categdoss LIKE 'DECOMPTE%'
           AND GD_DECOMPTE.refdoss = TI_DECOMPTE.refdoss
           AND TI_DECOMPTE.reftype =
               DECODE(GD_DECOMPTE.categdoss, 'DECOMPTE IMP', 'TC', 'CL')) V_FACT;



/********************************OLD SQL*******************************************/
/********************************OLD Metrics***************************************/
/*

-- 60z8jc35ttb8q

Plan hash value: 553845
--------------------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                      | Name                           | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers |
--------------------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                               |                                |      1 |        |    18 (100)|      1 |00:00:00.09 |   42200 |
|   1 |  SORT AGGREGATE                                |                                |      1 |      1 |            |      1 |00:00:00.09 |   42200 |
|*  2 |   FILTER                                       |                                |      1 |        |            |      0 |00:00:00.09 |   42200 |
|   3 |    NESTED LOOPS                                |                                |      1 |      1 |    18   (0)|      0 |00:00:00.09 |   42200 |
|   4 |     NESTED LOOPS                               |                                |      1 |      1 |    18   (0)|      0 |00:00:00.09 |   42200 |
|   5 |      NESTED LOOPS                              |                                |      1 |      1 |    17   (0)|      0 |00:00:00.09 |   42200 |
|   6 |       NESTED LOOPS SEMI                        |                                |      1 |      1 |    16   (0)|      0 |00:00:00.09 |   42200 |
|   7 |        NESTED LOOPS                            |                                |      1 |     44 |    15   (0)|   1845 |00:00:00.08 |   37062 |
|   8 |         NESTED LOOPS                           |                                |      1 |     71 |    12   (0)|   1845 |00:00:00.07 |   28748 |
|   9 |          NESTED LOOPS                          |                                |      1 |    281 |     4   (0)|   1880 |00:00:00.01 |     861 |
|* 10 |           HASH JOIN                            |                                |      1 |      5 |     3   (0)|      1 |00:00:00.01 |      27 |
|  11 |            NESTED LOOPS                        |                                |      1 |     53 |     2   (0)|      1 |00:00:00.01 |       8 |
|  12 |             TABLE ACCESS BY INDEX ROWID        | G_INDIVIDU                     |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       4 |
|* 13 |              INDEX UNIQUE SCAN                 | IND_REFINDIV                   |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |
|  14 |             TABLE ACCESS BY INDEX ROWID BATCHED| G_DOSSIER                      |      1 |     53 |     1   (0)|      1 |00:00:00.01 |       4 |
|* 15 |              INDEX RANGE SCAN                  | G_DOSSIER_RL_CD_RD_RF_IDX      |      1 |     53 |     1   (0)|      1 |00:00:00.01 |       3 |
|* 16 |            INDEX RANGE SCAN                    | INT_INDIV                      |      1 |   1776 |     1   (0)|   1889 |00:00:00.01 |      19 |
|  17 |           TABLE ACCESS BY INDEX ROWID BATCHED  | G_DOSSIER                      |      1 |     53 |     1   (0)|   1880 |00:00:00.01 |     834 |
|* 18 |            INDEX RANGE SCAN                    | G_DOSSIER_RL_CD_RD_RF_IDX      |      1 |     53 |     1   (0)|   1880 |00:00:00.01 |      26 |
|* 19 |          TABLE ACCESS BY INDEX ROWID BATCHED   | G_ELEMFI                       |   1880 |      1 |     1   (0)|   1845 |00:00:00.06 |   27887 |
|* 20 |           INDEX RANGE SCAN                     | G_ELEMFI_DOS_TYP_FG02_CODE_IDX |   1880 |      2 |     1   (0)|  47182 |00:00:00.01 |    2921 |
|* 21 |         TABLE ACCESS BY INDEX ROWID BATCHED    | G_PIECE                        |   1845 |      1 |     1   (0)|   1845 |00:00:00.01 |    8314 |
|* 22 |          INDEX RANGE SCAN                      | G_PIECE$GPIHEURE               |   1845 |      1 |     1   (0)|   1845 |00:00:00.01 |    3388 |
|* 23 |        TABLE ACCESS BY INDEX ROWID BATCHED     | G_PIECEDET                     |   1845 |    700K|     1   (0)|      0 |00:00:00.01 |    5138 |
|* 24 |         INDEX RANGE SCAN                       | G_PIECEDET_REFP                |   1845 |      1 |     1   (0)|      0 |00:00:00.01 |    5138 |
|* 25 |       INDEX RANGE SCAN                         | INT_REFDOSS                    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 26 |      INDEX UNIQUE SCAN                         | IND_REFINDIV                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|  27 |     TABLE ACCESS BY INDEX ROWID                | G_INDIVIDU                     |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 28 |    INDEX RANGE SCAN                            | G_INDIVPARAM_REFIND            |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 29 |    INDEX RANGE SCAN                            | G_INDIVPARAM_REFIND            |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
--------------------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   2 - filter((("GI"."STR36" IS NULL OR  IS NOT NULL) AND ("GI"."STR36" IS NULL OR  IS NOT NULL)))
  10 - access("GD_DECOMPTE"."REFDOSS"="TI_DECOMPTE"."REFDOSS" AND "TI_DECOMPTE"."REFTYPE"=DECODE("GD_DECOMPTE"."CATEGDOSS",'DECOMPTE
              IMP','TC','CL') AND "GI"."REFINDIVIDU"="TI_DECOMPTE"."REFINDIVIDU")
  13 - access("GI"."REFINDIVIDU"='A600DQHD')
  15 - access("GD_DECOMPTE"."REFLOT"='0001010163' AND "GD_DECOMPTE"."CATEGDOSS" LIKE 'DECOMPTE%')
       filter("GD_DECOMPTE"."CATEGDOSS" LIKE 'DECOMPTE%')
  16 - access("TI_DECOMPTE"."REFINDIVIDU"='A600DQHD')
  18 - access("GD_COMPTE"."REFLOT"="GD_DECOMPTE"."REFDOSS" AND "GD_COMPTE"."CATEGDOSS" LIKE 'COMPTE%')
       filter("GD_COMPTE"."CATEGDOSS" LIKE 'COMPTE%')
  19 - filter(("GE"."ACTIF"='O' AND "GE"."DTTRAITE_DT" IS NULL AND "GE"."DTANNUL_DT" IS NULL))
  20 - access("GE"."REFDOSS"="GD_COMPTE"."REFDOSS")
       filter(("GE"."TYPE"='FACTURE' OR "GE"."TYPE"='NOTE DE CREDIT'))
  21 - filter("P"."TYPPIECE"='FACTURE')
  22 - access("P"."GPIHEURE"="GE"."REFELEM")
       filter("P"."GPIHEURE" IS NOT NULL)
  23 - filter(("GD_COMPTE"."REFDOSS"="PD"."REFDOSS" AND "PD"."REFDOSS" IS NOT NULL))
  24 - access("PD"."REFPIECE"="P"."REFPIECE" AND "PD"."TYPE"='PROROGATION')
  25 - access("GD_COMPTE"."REFDOSS"="TI_COMPTE"."REFDOSS" AND "TI_COMPTE"."REFTYPE"='DB')
  26 - access("GI"."REFINDIVIDU"="TI_COMPTE"."REFINDIVIDU")
  28 - access("GP"."REFINDIVIDU"='A6004VFN' AND "TYPE"='type_indiv' AND "STR1"=:B1)
       filter("STR1"=:B1)
  29 - access("GP"."REFINDIVIDU"='A6004VFN' AND "TYPE"='type_indiv' AND "STR1"=:B1)
       filter("STR1"=:B1)

-- 2ygcq7pt9jmnu

Plan hash value: 850870575
------------------------------------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                             | Name                           | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  |
------------------------------------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                                      |                                |      1 |        |    87 (100)|      1 |00:00:00.71 |   32789 |   1240 |
|   1 |  VIEW                                                 |                                |      1 |      1 |    87   (2)|      1 |00:00:00.71 |   32789 |   1240 |
|   2 |   SORT AGGREGATE                                      |                                |      1 |      1 |            |      1 |00:00:00.71 |   32789 |   1240 |
|   3 |    VIEW                                               |                                |      1 |    117 |    87   (2)|   1846 |00:00:00.70 |   32789 |   1240 |
|   4 |     UNION-ALL                                         |                                |      1 |        |            |   1846 |00:00:00.70 |   32789 |   1240 |
|   5 |      HASH GROUP BY                                    |                                |      1 |     96 |    58   (2)|   1846 |00:00:00.53 |   25546 |    937 |
|*  6 |       FILTER                                          |                                |      1 |        |            |   1846 |00:00:00.53 |   25546 |    937 |
|*  7 |        FILTER                                         |                                |      1 |        |            |   1846 |00:00:00.53 |   25534 |    937 |
|*  8 |         HASH JOIN RIGHT OUTER                         |                                |      1 |    353 |    57   (0)|   1846 |00:00:00.53 |   25534 |    937 |
|   9 |          TABLE ACCESS STORAGE FULL                    | V_ELEMFI                       |      1 |    146 |     4   (0)|    146 |00:00:00.01 |       7 |      0 |
|  10 |          NESTED LOOPS                                 |                                |      1 |    350 |    53   (0)|   1846 |00:00:00.53 |   25527 |    937 |
|* 11 |           HASH JOIN OUTER                             |                                |      1 |    350 |    49   (0)|   1846 |00:00:00.47 |   21835 |    827 |
|  12 |            NESTED LOOPS                               |                                |      1 |    350 |    44   (0)|   1846 |00:00:00.34 |   20974 |    786 |
|  13 |             NESTED LOOPS                              |                                |      1 |    567 |    44   (0)|   1846 |00:00:00.32 |   16012 |    776 |
|  14 |              NESTED LOOPS                             |                                |      1 |    567 |    27   (0)|   1846 |00:00:00.31 |   12623 |    776 |
|  15 |               NESTED LOOPS                            |                                |      1 |    282 |    15   (0)|   1880 |00:00:00.30 |    7419 |    773 |
|  16 |                NESTED LOOPS                           |                                |      1 |    282 |    10   (0)|   1880 |00:00:00.01 |    1945 |      0 |
|  17 |                 NESTED LOOPS                          |                                |      1 |    281 |     4   (0)|   1880 |00:00:00.01 |     861 |      0 |
|* 18 |                  HASH JOIN                            |                                |      1 |      5 |     3   (0)|      1 |00:00:00.01 |      27 |      0 |
|  19 |                   NESTED LOOPS                        |                                |      1 |     53 |     2   (0)|      1 |00:00:00.01 |       8 |      0 |
|  20 |                    TABLE ACCESS BY INDEX ROWID        | G_INDIVIDU                     |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       4 |      0 |
|* 21 |                     INDEX UNIQUE SCAN                 | IND_REFINDIV                   |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |      0 |
|  22 |                    TABLE ACCESS BY INDEX ROWID BATCHED| G_DOSSIER                      |      1 |     53 |     1   (0)|      1 |00:00:00.01 |       4 |      0 |
|* 23 |                     INDEX RANGE SCAN                  | G_DOSSIER_RL_CD_RD_RF_IDX      |      1 |     53 |     1   (0)|      1 |00:00:00.01 |       3 |      0 |
|* 24 |                   INDEX RANGE SCAN                    | INT_INDIV                      |      1 |   1776 |     1   (0)|   1889 |00:00:00.01 |      19 |      0 |
|  25 |                  TABLE ACCESS BY INDEX ROWID BATCHED  | G_DOSSIER                      |      1 |     53 |     1   (0)|   1880 |00:00:00.01 |     834 |      0 |
|* 26 |                   INDEX RANGE SCAN                    | G_DOSSIER_RL_CD_RD_RF_IDX      |      1 |     53 |     1   (0)|   1880 |00:00:00.01 |      26 |      0 |
|* 27 |                 INDEX RANGE SCAN                      | INT_REFDOSS                    |   1880 |      1 |     1   (0)|   1880 |00:00:00.01 |    1084 |      0 |
|  28 |                TABLE ACCESS BY INDEX ROWID            | G_INDIVIDU                     |   1880 |      1 |     1   (0)|   1880 |00:00:00.28 |    5474 |    773 |
|* 29 |                 INDEX UNIQUE SCAN                     | IND_REFINDIV                   |   1880 |      1 |     1   (0)|   1880 |00:00:00.01 |    3657 |      3 |
|* 30 |               TABLE ACCESS BY INDEX ROWID BATCHED     | G_ELEMFI                       |   1880 |      2 |     1   (0)|   1846 |00:00:00.02 |    5204 |      3 |
|* 31 |                INDEX RANGE SCAN                       | G_ELEMFI$REFDOSS_ACTIF         |   1880 |      2 |     1   (0)|   1846 |00:00:00.01 |    4139 |      3 |
|* 32 |              INDEX RANGE SCAN                         | G_PIECE$GPIHEURE               |   1846 |      1 |     1   (0)|   1846 |00:00:00.01 |    3389 |      0 |
|* 33 |             TABLE ACCESS BY INDEX ROWID               | G_PIECE                        |   1846 |      1 |     1   (0)|   1846 |00:00:00.01 |    4962 |     10 |
|  34 |            INDEX FULL SCAN                            | VENRESTRICT_IDX                |      1 |  21437 |     6   (0)|  21169 |00:00:00.12 |     861 |     41 |
|* 35 |           INDEX UNIQUE SCAN                           | PK_G_DB_PTF_ITEM               |   1846 |      1 |     1   (0)|   1846 |00:00:00.06 |    3692 |    110 |
|* 36 |        INDEX RANGE SCAN                               | G_INDIVPARAM_REFIND            |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |      0 |
|* 37 |        INDEX RANGE SCAN                               | G_INDIVPARAM_REFIND            |      3 |      1 |     1   (0)|      3 |00:00:00.01 |       9 |      0 |
|* 38 |      FILTER                                           |                                |      1 |        |            |      0 |00:00:00.01 |    3784 |      0 |
|  39 |       NESTED LOOPS                                    |                                |      1 |     73 |    19   (0)|      0 |00:00:00.01 |    3784 |      0 |
|  40 |        NESTED LOOPS                                   |                                |      1 |     73 |    19   (0)|      0 |00:00:00.01 |    3784 |      0 |
|  41 |         NESTED LOOPS                                  |                                |      1 |     73 |    18   (0)|      0 |00:00:00.01 |    3784 |      0 |
|* 42 |          HASH JOIN                                    |                                |      1 |     69 |    16   (0)|      0 |00:00:00.01 |    3784 |      0 |
|  43 |           INLIST ITERATOR                             |                                |      1 |        |            |      3 |00:00:00.01 |       2 |      0 |
|* 44 |            INDEX RANGE SCAN                           | VF_TYPE_FINANCING              |      3 |      3 |     1   (0)|      3 |00:00:00.01 |       2 |      0 |
|  45 |           NESTED LOOPS                                |                                |      1 |    137 |    15   (0)|      0 |00:00:00.01 |    3782 |      0 |
|  46 |            NESTED LOOPS                               |                                |      1 |   1124 |    15   (0)|      0 |00:00:00.01 |    3782 |      0 |
|  47 |             NESTED LOOPS                              |                                |      1 |    281 |     4   (0)|   1880 |00:00:00.01 |     861 |      0 |
|* 48 |              HASH JOIN                                |                                |      1 |      5 |     3   (0)|      1 |00:00:00.01 |      27 |      0 |
|  49 |               NESTED LOOPS                            |                                |      1 |     53 |     2   (0)|      1 |00:00:00.01 |       8 |      0 |
|  50 |                TABLE ACCESS BY INDEX ROWID            | G_INDIVIDU                     |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       4 |      0 |
|* 51 |                 INDEX UNIQUE SCAN                     | IND_REFINDIV                   |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |      0 |
|  52 |                TABLE ACCESS BY INDEX ROWID BATCHED    | G_DOSSIER                      |      1 |     53 |     1   (0)|      1 |00:00:00.01 |       4 |      0 |
|* 53 |                 INDEX RANGE SCAN                      | G_DOSSIER_RL_CD_RD_RF_IDX      |      1 |     53 |     1   (0)|      1 |00:00:00.01 |       3 |      0 |
|* 54 |               INDEX RANGE SCAN                        | INT_INDIV                      |      1 |   1776 |     1   (0)|   1889 |00:00:00.01 |      19 |      0 |
|  55 |              TABLE ACCESS BY INDEX ROWID BATCHED      | G_DOSSIER                      |      1 |     53 |     1   (0)|   1880 |00:00:00.01 |     834 |      0 |
|* 56 |               INDEX RANGE SCAN                        | G_DOSSIER_RL_CD_RD_RF_IDX      |      1 |     53 |     1   (0)|   1880 |00:00:00.01 |      26 |      0 |
|* 57 |             INDEX RANGE SCAN                          | G_ELEMFI_DOS_TYP_FG02_CODE_IDX |   1880 |      4 |     1   (0)|      0 |00:00:00.01 |    2921 |      0 |
|* 58 |            TABLE ACCESS BY INDEX ROWID                | G_ELEMFI                       |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 59 |          INDEX RANGE SCAN                             | INT_REFDOSS                    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 60 |         INDEX UNIQUE SCAN                             | IND_REFINDIV                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|  61 |        TABLE ACCESS BY INDEX ROWID                    | G_INDIVIDU                     |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 62 |       INDEX RANGE SCAN                                | G_INDIVPARAM_REFIND            |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 63 |       INDEX RANGE SCAN                                | G_INDIVPARAM_REFIND            |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 64 |      FILTER                                           |                                |      1 |        |            |      0 |00:00:00.15 |    3459 |    303 |
|  65 |       NESTED LOOPS                                    |                                |      1 |      1 |     9   (0)|      0 |00:00:00.15 |    3459 |    303 |
|  66 |        NESTED LOOPS                                   |                                |      1 |      1 |     9   (0)|      0 |00:00:00.15 |    3459 |    303 |
|  67 |         NESTED LOOPS                                  |                                |      1 |      1 |     8   (0)|      0 |00:00:00.15 |    3459 |    303 |
|  68 |          NESTED LOOPS                                 |                                |      1 |      1 |     7   (0)|      0 |00:00:00.15 |    3459 |    303 |
|  69 |           NESTED LOOPS                                |                                |      1 |     27 |     6   (0)|     71 |00:00:00.14 |    3242 |    271 |
|  70 |            NESTED LOOPS                               |                                |      1 |      2 |     5   (0)|   1880 |00:00:00.01 |     851 |      0 |
|  71 |             MERGE JOIN CARTESIAN                      |                                |      1 |      1 |     4   (0)|      1 |00:00:00.01 |      17 |      0 |
|  72 |              NESTED LOOPS                             |                                |      1 |      1 |     3   (0)|      1 |00:00:00.01 |      14 |      0 |
|  73 |               NESTED LOOPS                            |                                |      1 |      1 |     2   (0)|      1 |00:00:00.01 |      11 |      0 |
|* 74 |                INDEX SKIP SCAN                        | REFHIERARCHIE_IDX              |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       7 |      0 |
|  75 |                TABLE ACCESS BY INDEX ROWID            | G_INDIVIDU                     |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       4 |      0 |
|* 76 |                 INDEX UNIQUE SCAN                     | IND_REFINDIV                   |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |      0 |
|* 77 |               INDEX RANGE SCAN                        | INT_INDIV                      |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |      0 |
|  78 |              BUFFER SORT                              |                                |      1 |     53 |     3   (0)|      1 |00:00:00.01 |       3 |      0 |
|* 79 |               INDEX RANGE SCAN                        | G_DOSSIER_RL_CD_RD_RF_IDX      |      1 |     53 |     1   (0)|      1 |00:00:00.01 |       3 |      0 |
|  80 |             TABLE ACCESS BY INDEX ROWID BATCHED       | G_DOSSIER                      |      1 |     53 |     1   (0)|   1880 |00:00:00.01 |     834 |      0 |
|* 81 |              INDEX RANGE SCAN                         | G_DOSSIER_RL_CD_RD_RF_IDX      |      1 |     53 |     1   (0)|   1880 |00:00:00.01 |      26 |      0 |
|  82 |            TABLE ACCESS BY INDEX ROWID BATCHED        | G_VENTILENC                    |   1880 |     13 |     1   (0)|     71 |00:00:00.13 |    2391 |    271 |
|* 83 |             INDEX RANGE SCAN                          | G_VENTILENC_REFDOSS_TRAITE     |   1880 |     37 |     1   (0)|     71 |00:00:00.12 |    2320 |    239 |
|* 84 |           TABLE ACCESS BY INDEX ROWID                 | G_ENCAISSEMENT                 |     71 |      1 |     1   (0)|      0 |00:00:00.01 |     217 |     32 |
|* 85 |            INDEX UNIQUE SCAN                          | REFENCAISS                     |     71 |      1 |     1   (0)|      0 |00:00:00.01 |     217 |     32 |
|* 86 |             TABLE ACCESS BY INDEX ROWID               | PMT_STATUS                     |     71 |      1 |     1   (0)|      0 |00:00:00.01 |      73 |      0 |
|* 87 |              INDEX UNIQUE SCAN                        | PMT_STATUS_PK                  |     71 |      1 |     1   (0)|      0 |00:00:00.01 |      73 |      0 |
|  88 |               SORT AGGREGATE                          |                                |     71 |      1 |            |     71 |00:00:00.01 |      73 |      0 |
|  89 |                TABLE ACCESS BY INDEX ROWID BATCHED    | PMT_STATUS                     |     71 |      1 |     1   (0)|      0 |00:00:00.01 |      73 |      0 |
|* 90 |                 INDEX RANGE SCAN                      | PMT_STATUS_REF_PAYMENT_IDX     |     71 |      1 |     1   (0)|      0 |00:00:00.01 |      73 |      0 |
|* 91 |          INDEX RANGE SCAN                             | INT_REFDOSS                    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 92 |         INDEX UNIQUE SCAN                             | IND_REFINDIV                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|  93 |        TABLE ACCESS BY INDEX ROWID                    | G_INDIVIDU                     |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 94 |       INDEX RANGE SCAN                                | G_INDIVPARAM_REFIND            |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 95 |       INDEX RANGE SCAN                                | G_INDIVPARAM_REFIND            |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
------------------------------------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   6 - filter((("GI"."STR36" IS NULL OR  IS NOT NULL) AND ("GI"."STR36" IS NULL OR  IS NOT NULL)))
   7 - filter(NVL("VE"."FG_PARENT_INVOICE",'N')<>'O')
   8 - access("GE"."TYPE"="VE"."TYPE")
  11 - access("GE"."REFELEM"="REFELEM")
  18 - access("GD_DECOMPTE"."REFDOSS"="TI_DECOMPTE"."REFDOSS" AND "TI_DECOMPTE"."REFTYPE"=DECODE("GD_DECOMPTE"."CATEGDOSS",'DECOMPTE IMP','TC','CL') AND
              "GI"."REFINDIVIDU"="TI_DECOMPTE"."REFINDIVIDU")
  21 - access("GI"."REFINDIVIDU"='A600DQHD')
  23 - access("GD_DECOMPTE"."REFLOT"='0001010163' AND "GD_DECOMPTE"."CATEGDOSS" LIKE 'DECOMPTE%')
       filter("GD_DECOMPTE"."CATEGDOSS" LIKE 'DECOMPTE%')
  24 - access("TI_DECOMPTE"."REFINDIVIDU"='A600DQHD')
  26 - access("GD_COMPTE"."REFLOT"="GD_DECOMPTE"."REFDOSS" AND "GD_COMPTE"."CATEGDOSS" LIKE 'COMPTE%')
       filter("GD_COMPTE"."CATEGDOSS" LIKE 'COMPTE%')
  27 - access("GD_COMPTE"."REFDOSS"="TI_COMPTE"."REFDOSS" AND "TI_COMPTE"."REFTYPE"='DB')
  29 - access("GI"."REFINDIVIDU"="TI_COMPTE"."REFINDIVIDU")
  30 - filter(("GE"."DTTRAITE_DT" IS NULL AND "GE"."DTANNUL_DT" IS NULL))
  31 - access("GE"."REFDOSS"="GD_COMPTE"."REFDOSS" AND "GE"."ACTIF"='O')
  32 - access("GP_FACT"."GPIHEURE"="GE"."REFELEM")
       filter("GP_FACT"."GPIHEURE" IS NOT NULL)
  33 - filter("GP_FACT"."TYPPIECE"='FACTURE')
  35 - access("GE"."REFELEM"="PI"."REFELEM")
  36 - access("GP"."REFINDIVIDU"='A6004VFN' AND "TYPE"='type_indiv' AND "STR1"=:B1)
       filter("STR1"=:B1)
  37 - access("GP"."REFINDIVIDU"='A6004VFN' AND "TYPE"='type_indiv' AND "STR1"=:B1)
       filter("STR1"=:B1)
  38 - filter((("GI"."STR36" IS NULL OR  IS NOT NULL) AND ("GI"."STR36" IS NULL OR  IS NOT NULL)))
  42 - access("GE"."TYPE"="VE"."TYPE")
  44 - access(("VE"."TYPE"='BULK DEDUCTION' OR "VE"."TYPE"='FACT NON RECUE' OR "VE"."TYPE"='NOTE DE DEBIT'))
  48 - access("GD_DECOMPTE"."REFDOSS"="TI_DECOMPTE"."REFDOSS" AND "TI_DECOMPTE"."REFTYPE"=DECODE("GD_DECOMPTE"."CATEGDOSS",'DECOMPTE IMP','TC','CL') AND
              "GI"."REFINDIVIDU"="TI_DECOMPTE"."REFINDIVIDU")
  51 - access("GI"."REFINDIVIDU"='A600DQHD')
  53 - access("GD_DECOMPTE"."REFLOT"='0001010163' AND "GD_DECOMPTE"."CATEGDOSS" LIKE 'DECOMPTE%')
       filter("GD_DECOMPTE"."CATEGDOSS" LIKE 'DECOMPTE%')
  54 - access("TI_DECOMPTE"."REFINDIVIDU"='A600DQHD')
  56 - access("GD_COMPTE"."REFLOT"="GD_DECOMPTE"."REFDOSS" AND "GD_COMPTE"."CATEGDOSS" LIKE 'COMPTE%')
       filter("GD_COMPTE"."CATEGDOSS" LIKE 'COMPTE%')
  57 - access("GE"."REFDOSS"="GD_COMPTE"."REFDOSS")
       filter(("GE"."TYPE"='BULK DEDUCTION' OR "GE"."TYPE"='FACT NON RECUE' OR "GE"."TYPE"='NOTE DE DEBIT'))
  58 - filter(("GE"."DTTRAITE_DT" IS NULL AND DECODE("GE"."TYPE",'NOTE DE DEBIT',1,'FACT NON RECUE',1,(-1))*"GE"."MONTANT_MVT">0 AND "GE"."DTANNUL_DT" IS NULL))
  59 - access("GD_COMPTE"."REFDOSS"="TI_COMPTE"."REFDOSS" AND "TI_COMPTE"."REFTYPE"='DB')
  60 - access("GI"."REFINDIVIDU"="TI_COMPTE"."REFINDIVIDU")
  62 - access("GP"."REFINDIVIDU"='A6004VFN' AND "TYPE"='type_indiv' AND "STR1"=:B1)
       filter("STR1"=:B1)
  63 - access("GP"."REFINDIVIDU"='A6004VFN' AND "TYPE"='type_indiv' AND "STR1"=:B1)
       filter("STR1"=:B1)
  64 - filter((("GI"."STR36" IS NULL OR  IS NOT NULL) AND ("GI"."STR36" IS NULL OR  IS NOT NULL)))
  74 - access("GD_CONTRAT"."CATEGDOSS" LIKE 'CONTRAT%' AND "GD_CONTRAT"."REFDOSS"='0001010163')
       filter(("GD_CONTRAT"."REFDOSS"='0001010163' AND "GD_CONTRAT"."CATEGDOSS" LIKE 'CONTRAT%'))
  76 - access("GI"."REFINDIVIDU"='A600DQHD')
  77 - access("TI_CONTRAT"."REFINDIVIDU"='A600DQHD' AND "TI_CONTRAT"."REFTYPE"=DECODE("GD_CONTRAT"."CATEGDOSS",'CONTRAT IMP','TC','CL') AND
              "TI_CONTRAT"."REFDOSS"='0001010163')
  79 - access("GD_DECOMPTE"."REFLOT"='0001010163' AND "GD_DECOMPTE"."CATEGDOSS" LIKE 'DECOMPTE%')
       filter("GD_DECOMPTE"."CATEGDOSS" LIKE 'DECOMPTE%')
  81 - access("GD_COMPTE"."REFLOT"="GD_DECOMPTE"."REFDOSS" AND "GD_COMPTE"."CATEGDOSS" LIKE 'COMPTE%')
       filter("GD_COMPTE"."CATEGDOSS" LIKE 'COMPTE%')
  83 - access("VENTIL"."REFDOSS"="GD_COMPTE"."REFDOSS" AND "VENTIL"."TRAITE"='9')
  84 - filter(("ENC"."DTIMPAYE_DT" IS NOT NULL AND "ENC"."TYPENCAISS"='e_saencaiss'))
  85 - access("ENC"."REFENCAISS"="VENTIL"."REFENCAISS")
       filter(='IMPAYE')
  86 - filter("REF_PAYMENT"=:B1)
  87 - access("PMT_STATUS_ID"=)
  90 - access("REF_PAYMENT"=:B1)
  91 - access("GD_COMPTE"."REFDOSS"="TI_COMPTE"."REFDOSS" AND "TI_COMPTE"."REFTYPE"='DB')
  92 - access("GI"."REFINDIVIDU"="TI_COMPTE"."REFINDIVIDU")
  94 - access("GP"."REFINDIVIDU"='A6004VFN' AND "TYPE"='type_indiv' AND "STR1"=:B1)
       filter("STR1"=:B1)
  95 - access("GP"."REFINDIVIDU"='A6004VFN' AND "TYPE"='type_indiv' AND "STR1"=:B1)
       filter("STR1"=:B1)

-- 9xyjhud4sy3wy

Plan hash value: 170133243
-----------------------------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                      | Name                           | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  |
-----------------------------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                               |                                |      1 |        |    19 (100)|      1 |00:00:00.92 |   28269 |   2663 |
|   1 |  SORT AGGREGATE                                |                                |      1 |      1 |            |      1 |00:00:00.92 |   28269 |   2663 |
|   2 |   VIEW                                         | VM_NWVW_1                      |      1 |      1 |    19   (6)|      9 |00:00:00.89 |   28241 |   2663 |
|   3 |    HASH GROUP BY                               |                                |      1 |      1 |    19   (6)|      9 |00:00:00.89 |   28241 |   2663 |
|*  4 |     FILTER                                     |                                |      1 |        |            |      9 |00:00:00.88 |   28236 |   2663 |
|   5 |      NESTED LOOPS                              |                                |      1 |      4 |    18   (0)|      9 |00:00:00.88 |   28230 |   2663 |
|   6 |       NESTED LOOPS                             |                                |      1 |      4 |    18   (0)|      9 |00:00:00.88 |   28224 |   2663 |
|   7 |        NESTED LOOPS                            |                                |      1 |      4 |    17   (0)|      9 |00:00:00.88 |   28204 |   2663 |
|   8 |         NESTED LOOPS                           |                                |      1 |      6 |    16   (0)|      9 |00:00:00.87 |   28174 |   2653 |
|   9 |          NESTED LOOPS                          |                                |      1 |      6 |    15   (0)|      9 |00:00:00.87 |   28154 |   2653 |
|  10 |           NESTED LOOPS                         |                                |      1 |     78 |    14   (0)|      9 |00:00:00.87 |   28137 |   2645 |
|  11 |            NESTED LOOPS                        |                                |      1 |     71 |    12   (0)|   1720 |00:00:00.85 |   26543 |   2615 |
|  12 |             NESTED LOOPS                       |                                |      1 |    281 |     4   (0)|   1880 |00:00:00.01 |      52 |      0 |
|* 13 |              HASH JOIN                         |                                |      1 |      5 |     3   (0)|      1 |00:00:00.01 |      26 |      0 |
|  14 |               NESTED LOOPS                     |                                |      1 |     53 |     2   (0)|      1 |00:00:00.01 |       7 |      0 |
|  15 |                TABLE ACCESS BY INDEX ROWID     | G_INDIVIDU                     |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       4 |      0 |
|* 16 |                 INDEX UNIQUE SCAN              | IND_REFINDIV                   |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |      0 |
|* 17 |                INDEX RANGE SCAN                | G_DOSSIER_RL_CD_RD_RF_IDX      |      1 |     53 |     1   (0)|      1 |00:00:00.01 |       3 |      0 |
|* 18 |               INDEX RANGE SCAN                 | INT_INDIV                      |      1 |   1776 |     1   (0)|   1889 |00:00:00.01 |      19 |      0 |
|* 19 |              INDEX RANGE SCAN                  | G_DOSSIER_RL_CD_RD_RF_IDX      |      1 |     53 |     1   (0)|   1880 |00:00:00.01 |      26 |      0 |
|* 20 |             TABLE ACCESS BY INDEX ROWID BATCHED| G_ELEMFI                       |   1880 |      1 |     1   (0)|   1720 |00:00:00.84 |   26491 |   2615 |
|* 21 |              INDEX RANGE SCAN                  | G_ELEMFI_DOS_TYP_FG02_CODE_IDX |   1880 |      2 |     1   (0)|  45189 |00:00:00.02 |    2928 |      2 |
|  22 |            TABLE ACCESS BY INDEX ROWID BATCHED | G_VENCONTEST                   |   1720 |      1 |     1   (0)|      9 |00:00:00.02 |    1594 |     30 |
|* 23 |             INDEX RANGE SCAN                   | G_VCONT_REFELEM_IDX            |   1720 |      1 |     1   (0)|      9 |00:00:00.02 |    1587 |     24 |
|* 24 |           TABLE ACCESS BY INDEX ROWID          | G_CONTESTATION                 |      9 |      1 |     1   (0)|      9 |00:00:00.01 |      17 |      8 |
|* 25 |            INDEX UNIQUE SCAN                   | G_CONTESTATION$PK_REFCONTEST   |      9 |      1 |     1   (0)|      9 |00:00:00.01 |      11 |      4 |
|* 26 |          INDEX RANGE SCAN                      | INT_REFDOSS                    |      9 |      1 |     1   (0)|      9 |00:00:00.01 |      20 |      0 |
|* 27 |         INDEX RANGE SCAN                       | GP_GRTYPE_MT_DT                |      9 |      1 |     1   (0)|      9 |00:00:00.01 |      30 |     10 |
|* 28 |        INDEX UNIQUE SCAN                       | IND_REFINDIV                   |      9 |      1 |     1   (0)|      9 |00:00:00.01 |      20 |      0 |
|  29 |       TABLE ACCESS BY INDEX ROWID              | G_INDIVIDU                     |      9 |      1 |     1   (0)|      9 |00:00:00.01 |       6 |      0 |
|* 30 |      INDEX RANGE SCAN                          | G_INDIVPARAM_REFIND            |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |      0 |
|* 31 |      INDEX RANGE SCAN                          | G_INDIVPARAM_REFIND            |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |      0 |
-----------------------------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   4 - filter((("GI"."STR36" IS NULL OR  IS NOT NULL) AND ("GI"."STR36" IS NULL OR  IS NOT NULL)))
  13 - access("GD_DECOMPTE"."REFDOSS"="TI_DECOMPTE"."REFDOSS" AND "TI_DECOMPTE"."REFTYPE"=DECODE("GD_DECOMPTE"."CATEGDOSS",'DECOMPTE IMP','TC','CL') AND
              "GI"."REFINDIVIDU"="TI_DECOMPTE"."REFINDIVIDU")
  16 - access("GI"."REFINDIVIDU"='A600DQHD')
  17 - access("GD_DECOMPTE"."REFLOT"='0001010163' AND "GD_DECOMPTE"."CATEGDOSS" LIKE 'DECOMPTE%')
       filter("GD_DECOMPTE"."CATEGDOSS" LIKE 'DECOMPTE%')
  18 - access("TI_DECOMPTE"."REFINDIVIDU"='A600DQHD')
  19 - access("GD_COMPTE"."REFLOT"="GD_DECOMPTE"."REFDOSS" AND "GD_COMPTE"."CATEGDOSS" LIKE 'COMPTE%')
       filter("GD_COMPTE"."CATEGDOSS" LIKE 'COMPTE%')
  20 - filter(("GE"."ACTIF"='O' AND "GE"."DTTRAITE_DT" IS NULL AND "GE"."DTANNUL_DT" IS NULL))
  21 - access("GE"."REFDOSS"="GD_COMPTE"."REFDOSS")
       filter(("GE"."TYPE"='FACTURE' OR "GE"."TYPE"='NOTE DE   CREDIT'))
  23 - access("VC"."REFELEM"="REFELEM")
  24 - filter((("C"."DTRESOLUTION_DT" IS NULL OR TRUNC(INTERNAL_FUNCTION("C"."DTRESOLUTION_DT"))>TRUNC(SYSDATE@!)) AND INTERNAL_FUNCTION("C"."TYPE")))
  25 - access("VC"."REFCONTEST"="C"."REFCONTEST")
  26 - access("GD_COMPTE"."REFDOSS"="TI_COMPTE"."REFDOSS" AND "TI_COMPTE"."REFTYPE"='DB')
  27 - access("P"."TYPPIECE"='FACTURE' AND "P"."GPIHEURE"="GE"."REFELEM")
       filter("P"."GPIHEURE" IS NOT NULL)
  28 - access("GI"."REFINDIVIDU"="TI_COMPTE"."REFINDIVIDU")
  30 - access("GP"."REFINDIVIDU"='A6004VFN' AND "TYPE"='type_indiv' AND "STR1"=:B1)
       filter("STR1"=:B1)
  31 - access("GP"."REFINDIVIDU"='A6004VFN' AND "TYPE"='type_indiv' AND "STR1"=:B1)
       filter("STR1"=:B1)

*/
/********************************OLD Metrics***************************************/

/********************************New SQL*******************************************/
-- 60z8jc35ttb8q

SELECT SUM(SOLDE_CONV) AS AMOUNT
  FROM (SELECT /*+ index(GE G_ELEMFI$REFDOSS_ACTIF) */
         DECODE('EUR',
                GD_COMPTE.devise,
                DECODE(P.dt10, NULL, P.mt09, ftr_util.SoldeF(GE.refelem)),
                GD_DECOMPTE.devise,
                DECODE(P.dt10, NULL, P.mt24, ftr_util.SoldeF_DCPT(GE.refelem)),
                Ch_Taux.Conv_Orig_Dest_Tx(TO_CHAR(SYSDATE, 'j'),
                                          NVL(DECODE(P.dt10,
                                                     NULL,
                                                     P.mt09,
                                                     ftr_util.SoldeF(GE.refelem)),
                                              0),
                                          GD_COMPTE.devise,
                                          'EUR',
                                          'MER',
                                          ftr_fin_factor.getCurrency(GD_COMPTE.reffactor),
                                          ftr_fin_factor.getPays(GD_COMPTE.reffactor))) AS SOLDE_CONV
          FROM g_elemfi       GE,
               g_dossier      GD_COMPTE,
               g_dossier      GD_DECOMPTE,
               t_intervenants TI_COMPTE,
               t_intervenants TI_DECOMPTE,
               g_piece        P
         WHERE GE.dttraite_dt IS NULL
           AND GE.dtannul_dt IS NULL
           AND GE.refdoss = GD_COMPTE.refdoss
           AND GD_COMPTE.categdoss LIKE 'COMPTE%'
           AND GD_COMPTE.refdoss = TI_COMPTE.refdoss
           AND GE.actif = 'O'
           AND GD_DECOMPTE.reflot = '0001010163'
           AND TI_DECOMPTE.refindividu = 'A600DQHD'
           AND EXISTS
         (SELECT 1
                  FROM g_individu GI
                 WHERE GI.refindividu = TI_DECOMPTE.refindividu
                   AND (GI.str36 IS NULL OR
                       GI.str36 IN (SELECT str1
                                       FROM g_indivparam GP
                                      WHERE GP.refindividu = 'A6004VFN'
                                        AND type = 'type_indiv')))
           AND EXISTS
         (SELECT 1
                  FROM g_individu GI
                 WHERE GI.refindividu = TI_COMPTE.refindividu
                   AND (GI.str36 IS NULL OR
                       GI.str36 IN (SELECT str1
                                       FROM g_indivparam GP
                                      WHERE GP.refindividu = 'A6004VFN'
                                        AND type = 'type_indiv')))
           AND P.typpiece = 'FACTURE'
           AND P.gpiheure = GE.refelem
           AND GE.TYPE IN ('FACTURE', 'NOTE DE CREDIT')
           AND TI_COMPTE.reftype = 'DB'
           AND GD_COMPTE.reflot = GD_DECOMPTE.refdoss
           AND GD_DECOMPTE.categdoss LIKE 'DECOMPTE%'
           AND GD_DECOMPTE.refdoss = TI_DECOMPTE.refdoss
           AND TI_DECOMPTE.reftype =
               DECODE(GD_DECOMPTE.categdoss, 'DECOMPTE IMP', 'TC', 'CL')
           AND EXISTS (SELECT 1
                  FROM g_piecedet PD
                 WHERE PD.refpiece = P.refpiece
                   AND GD_COMPTE.refdoss = PD.refdoss
                   AND PD.type = 'PROROGATION')) V_FACT;


-- 2ygcq7pt9jmnu

select COUNT_TOTAL      count_total,
       NON_ECHU         non_echu,
       ECHU             echu,
       ECHU_30          echu_30,
       ECHU30           echu30,
       ECHU60           echu60,
       ECHU90           echu90,
       ECHU120          echu120,
       ECHU180          echu180,
       ECHU360          echu360,
       COUNT_BIEN       count_bien,
       COUNT25          count25,
       COUNT15          count15,
       COUNT26          count26,
       COUNT_PAST_EXT   count_past_ext,
       COUNT_MASTER_INV count_master_inv,
       COUNT13          count13,
       COUNT14          count14,
       COUNT_NC         count_nc,
       COUNT_COUVERT    count_couvert,
       COUNT_FIN        count_fin,
       COUNT_COV_NFIN   count_cov_nfin,
       COUNT_NCOV_NFIN  count_ncov_nfin,
       IMPAYE           impaye,
       ENC_IMPAYE       enc_impaye
  from (SELECT SUM(solde_conv) AS COUNT_TOTAL,
               SUM(DECODE(SIGN(dtdebut - TO_CHAR(SYSDATE, 'j')),
                          1,
                          solde_conv,
                          0)) NON_ECHU,
               SUM(DECODE(SIGN(dtdebut - TO_CHAR(SYSDATE, 'j')),
                          -1,
                          solde_conv,
                          0,
                          solde_conv,
                          0)) ECHU,
               SUM(DECODE(SIGN(dtdebut - TO_CHAR(SYSDATE - 0, 'j')),
                          -1,
                          DECODE(SIGN(dtdebut + 1 -
                                      TO_CHAR(SYSDATE - 30, 'j')),
                                 1,
                                 solde_conv,
                                 0),
                          0,
                          solde_conv,
                          0)) ECHU_30,
               SUM(DECODE(SIGN(dtdebut - TO_CHAR(SYSDATE - 31, 'j')),
                          -1,
                          DECODE(SIGN(dtdebut + 1 -
                                      TO_CHAR(SYSDATE - 60, 'j')),
                                 1,
                                 solde_conv,
                                 0),
                          0,
                          solde_conv,
                          0)) ECHU30,
               SUM(DECODE(SIGN(dtdebut - TO_CHAR(SYSDATE - 61, 'j')),
                          -1,
                          DECODE(SIGN(dtdebut + 1 -
                                      TO_CHAR(SYSDATE - 90, 'j')),
                                 1,
                                 solde_conv,
                                 0),
                          0,
                          solde_conv,
                          0)) ECHU60,
               SUM(DECODE(SIGN(dtdebut - TO_CHAR(SYSDATE - 91, 'j')),
                          -1,
                          DECODE(SIGN(dtdebut + 1 -
                                      TO_CHAR(SYSDATE - 120, 'j')),
                                 1,
                                 solde_conv,
                                 0),
                          0,
                          solde_conv,
                          0)) ECHU90,
               SUM(DECODE(SIGN(dtdebut - TO_CHAR(SYSDATE - 121, 'j')),
                          -1,
                          DECODE(SIGN(dtdebut + 1 -
                                      TO_CHAR(SYSDATE - 180, 'j')),
                                 1,
                                 solde_conv,
                                 0),
                          0,
                          solde_conv,
                          0)) ECHU120,
               SUM(DECODE(SIGN(dtdebut - TO_CHAR(SYSDATE - 181, 'j')),
                          -1,
                          DECODE(SIGN(dtdebut + 1 -
                                      TO_CHAR(SYSDATE - 99999, 'j')),
                                 1,
                                 solde_conv,
                                 0),
                          0,
                          solde_conv,
                          0)) ECHU180,
               NULL ECHU360,
               SUM(mt48_conv) AS COUNT15,
               SUM(mt09_mt48_conv) COUNT26,
               SUM(DECODE(SIGN(dt14 - TO_CHAR(SYSDATE, 'j')),
                          -1,
                          solde_conv,
                          0)) COUNT_PAST_EXT,
               SUM(DECODE(TYPE,
                          'FINANCEMENT SUR BIEN',
                          solde_conv,
                          'REEVALUATION DU BIEN - DIM',
                          solde_conv,
                          'REEVALUATION DU BIEN - AUGM',
                          solde_conv,
                          0)) AS COUNT_BIEN,
               SUM(DECODE(st09, 'NGPC', solde_conv, 0)) AS COUNT25,
               SUM(DECODE(st09, 'W', solde_conv, 0)) AS COUNT13,
               SUM(DECODE(st09, 'W', DECODE(fg09, 'O', solde_conv, 0), 0)) AS COUNT14,
               SUM(DECODE(TYPE,
                          'NOTE DE CREDIT',
                          solde_conv,
                          'BULK DEDUCTION',
                          solde_conv,
                          0)) AS COUNT_NC,
               SUM(DECODE(TYPE,
                          'NOTE DE DEBIT',
                          solde_conv,
                          'FACTURE',
                          solde_conv,
                          0)) AS IMPAYE,
               SUM(DECODE(SIGN(montant_dos),
                          1,
                          DECODE(mt01,
                                 NULL,
                                 0,
                                 DECODE(SIGN(mt01), 1, mt01_conv, 0)),
                          -1,
                          DECODE(mt01, NULL, 0, mt01_conv),
                          0)) COUNT_COUVERT,
               SUM(fin_conv) AS COUNT_FIN,
               SUM(cov_nfin_conv) AS COUNT_COV_NFIN,
               SUM(ncov_nfin_conv) AS COUNT_NCOV_NFIN,
               SUM(enc_impaye) AS enc_impaye,
               SUM(master_inv) AS COUNT_MASTER_INV
          FROM (SELECT /*+ use_nl(VR) index_rs(VR G_VENRESTRICTION$REFELEM) */
                                             GE.dtdebut,
                       GE.dt_emis,
                       GE.refelem,
                       GP_FACT.st09,
                       GP_FACT.fg09,
                       GE.type,
                       GP_FACT.mt09,
                       GP_FACT.dt14,
                       DECODE('EUR',
                              GD_COMPTE.devise,
                              GP_FACT.mt48,
                              GD_DECOMPTE.devise,
                              GP_FACT.mt49,
                              Ch_Taux.Conv_Orig_Dest_Tx(TO_CHAR(SYSDATE, 'j'),
                                                        NVL(GP_FACT.mt48, 0),
                                                        GD_COMPTE.devise,
                                                        'EUR',
                                                        'MER',
                                                        ftr_fin_factor.getCurrency(GD_COMPTE.reffactor),
                                                        ftr_fin_factor.getPays(GD_COMPTE.reffactor))) AS MT48_CONV,
                       DECODE('EUR',
                              GD_COMPTE.devise,
                              NVL(GP_FACT.mt09, 0) - NVL(GP_FACT.mt48, 0),
                              GD_DECOMPTE.devise,
                              NVL(GP_FACT.mt24, 0) - NVL(GP_FACT.mt49, 0),
                              Ch_Taux.Conv_Orig_Dest_Tx(TO_CHAR(SYSDATE, 'j'),
                                                        NVL(GP_FACT.mt09, 0) -
                                                        NVL(GP_FACT.mt48, 0),
                                                        GD_COMPTE.devise,
                                                        'EUR',
                                                        'MER',
                                                        ftr_fin_factor.getCurrency(GD_COMPTE.reffactor),
                                                        ftr_fin_factor.getPays(GD_COMPTE.reffactor))) AS MT09_MT48_CONV,
                       GE.montant_dos,
                       DECODE('EUR',
                              GD_COMPTE.devise,
                              DECODE(GP_FACT.dt10,
                                     NULL,
                                     GP_FACT.mt09,
                                     ftr_util.SoldeF(GE.refelem)),
                              GD_DECOMPTE.devise,
                              DECODE(GP_FACT.dt10,
                                     NULL,
                                     GP_FACT.mt24,
                                     ftr_util.SoldeF_DCPT(GE.refelem)),
                              Ch_Taux.Conv_Orig_Dest_Tx(TO_CHAR(SYSDATE, 'j'),
                                                        NVL(DECODE(GP_FACT.dt10,
                                                                   NULL,
                                                                   GP_FACT.mt09,
                                                                   ftr_util.SoldeF(GE.refelem)),
                                                            0),
                                                        GD_COMPTE.devise,
                                                        'EUR',
                                                        'MER',
                                                        ftr_fin_factor.getCurrency(GD_COMPTE.reffactor),
                                                        ftr_fin_factor.getPays(GD_COMPTE.reffactor))) AS SOLDE_CONV,
                       GP_FACT.mt01,
                       DECODE('EUR',
                              GD_COMPTE.devise,
                              GP_FACT.mt01,
                              GD_DECOMPTE.devise,
                              GP_FACT.mt27,
                              Ch_Taux.Conv_Orig_Dest_Tx(TO_CHAR(SYSDATE, 'j'),
                                                        NVL(GP_FACT.mt01, 0),
                                                        GD_COMPTE.devise,
                                                        'EUR',
                                                        'MER',
                                                        ftr_fin_factor.getCurrency(GD_COMPTE.reffactor),
                                                        ftr_fin_factor.getPays(GD_COMPTE.reffactor))) AS MT01_CONV,
                       GE.devise_dos,
                       GD_DECOMPTE.devise AS DEVISE_DCPT,
                       DECODE('EUR',
                              GD_DECOMPTE.devise,
                              ROUND(NVL(GP_FACT.mt24, 0), 2) -
                              ROUND(NVL(VR.real_amount_dec, 0), 2),
                              Ch_Taux.Conv_Orig_Dest_Tx(TO_CHAR(SYSDATE, 'j'),
                                                        NVL(GP_FACT.mt24, 0) -
                                                        NVL(VR.real_amount_dec,
                                                            0),
                                                        GD_DECOMPTE.devise,
                                                        'EUR',
                                                        'MER',
                                                        ftr_fin_factor.getCurrency(GD_COMPTE.reffactor),
                                                        ftr_fin_factor.getPays(GD_COMPTE.reffactor))) AS FIN_CONV,
                       DECODE('EUR',
                              GD_COMPTE.devise,
                              GP_FACT.mt63,
                              GD_DECOMPTE.devise,
                              GP_FACT.mt64,
                              Ch_Taux.Conv_Orig_Dest_Tx(TO_CHAR(SYSDATE, 'j'),
                                                        NVL(GP_FACT.mt63, 0),
                                                        GD_COMPTE.devise,
                                                        'EUR',
                                                        'MER',
                                                        ftr_fin_factor.getCurrency(GD_COMPTE.reffactor),
                                                        ftr_fin_factor.getPays(GD_COMPTE.reffactor))) AS COV_NFIN_CONV,
                       DECODE('EUR',
                              GD_COMPTE.devise,
                              GP_FACT.mt65,
                              GD_DECOMPTE.devise,
                              GP_FACT.mt66,
                              Ch_Taux.Conv_Orig_Dest_Tx(TO_CHAR(SYSDATE, 'j'),
                                                        NVL(GP_FACT.mt65, 0),
                                                        GD_COMPTE.devise,
                                                        'EUR',
                                                        'MER',
                                                        ftr_fin_factor.getCurrency(GD_COMPTE.reffactor),
                                                        ftr_fin_factor.getPays(GD_COMPTE.reffactor))) AS NCOV_NFIN_CONV,
                       0 AS enc_impaye,
                       0 AS MASTER_INV
                  FROM g_piece GP_FACT,
                       g_elemfi GE,
                       g_db_ptf_item PI,
                       g_dossier GD_COMPTE,
                       g_dossier GD_DECOMPTE,
                       g_piece GP_CESS,
                       t_intervenants TI_COMPTE,
                       t_intervenants TI_DECOMPTE,
                       v_elemfi VE,
                       (SELECT SUM(real_amount_dec) REAL_AMOUNT_DEC, refelem
                          FROM g_venrestriction
                         GROUP BY refelem) VR
                 WHERE GP_FACT.typpiece = 'FACTURE'
                   AND GP_FACT.gpiheure = GE.refelem
                   AND GE.refelem = PI.refelem
                   AND GE.dttraite_dt IS NULL
                   AND GE.dtannul_dt IS NULL
                   AND GE.refdoss = GD_COMPTE.refdoss
                   AND GD_COMPTE.categdoss LIKE 'COMPTE%'
                   AND GE.type = VE.type(+)
                   AND NVL(VE.fg_parent_invoice, 'N') <> 'O'
                   AND GD_COMPTE.refdoss = TI_COMPTE.refdoss
                   AND GE.actif = 'O'
                   AND GE.refelem = VR.refelem(+)
                   AND GD_DECOMPTE.reflot = '0001010163'
                   AND TI_DECOMPTE.refindividu = 'A600DQHD'
                   AND EXISTS
                 (SELECT 1
                          FROM g_individu GI
                         WHERE GI.refindividu = TI_DECOMPTE.refindividu
                           AND (GI.str36 IS NULL OR
                               GI.str36 IN
                               (SELECT str1
                                   FROM g_indivparam GP
                                  WHERE GP.refindividu = 'A6004VFN'
                                    AND type = 'type_indiv')))
                   AND EXISTS
                 (SELECT 1
                          FROM g_individu GI
                         WHERE GI.refindividu = TI_COMPTE.refindividu
                           AND (GI.str36 IS NULL OR
                               GI.str36 IN
                               (SELECT str1
                                   FROM g_indivparam GP
                                  WHERE GP.refindividu = 'A6004VFN'
                                    AND type = 'type_indiv')))
                   AND TI_COMPTE.reftype = 'DB'
                   AND GD_COMPTE.reflot = GD_DECOMPTE.refdoss
                   AND GD_DECOMPTE.categdoss LIKE 'DECOMPTE%'
                   AND GP_FACT.gpidepot = GP_CESS.refpiece(+)
                   AND GP_CESS.typpiece(+) = 'CESSION'
                   AND GD_DECOMPTE.refdoss = TI_DECOMPTE.refdoss
                   AND TI_DECOMPTE.reftype =
                       DECODE(GD_DECOMPTE.categdoss,
                              'DECOMPTE IMP',
                              'TC',
                              'CL')
                UNION ALL
                SELECT /*+ index(GE (refdoss,type))*/
                 GE.dtdebut,
                 GE.dt_emis,
                 GE.refelem,
                 NULL st09,
                 NULL fg09,
                 GE.type,
                 NULL mt09,
                 NULL dt14,
                 NULL MT48_CONV,
                 NULL MT09_MT48_CONV,
                 GE.montant_dos,
                 DECODE('EUR',
                        GD_COMPTE.devise,
                        ftr_util.SoldeF(GE.refelem),
                        GD_DECOMPTE.devise,
                        ftr_util.SoldeF_DCPT(GE.refelem),
                        Ch_Taux.Conv_Orig_Dest_Tx(TO_CHAR(SYSDATE, 'j'),
                                                  NVL(ftr_util.SoldeF(GE.refelem),
                                                      0),
                                                  GD_COMPTE.devise,
                                                  'EUR',
                                                  'MER',
                                                  ftr_fin_factor.getCurrency(GD_COMPTE.reffactor),
                                                  ftr_fin_factor.getPays(GD_COMPTE.reffactor))) AS SOLDE_CONV,
                 NULL mt01,
                 NULL MT01_CONV,
                 GE.devise_dos,
                 GD_DECOMPTE.devise AS DEVISE_DCPT,
                 0 AS FIN_CONV,
                 0 AS COV_NFIN_CONV,
                 0 AS NCOV_NFIN_CONV,
                 0 AS enc_impaye,
                 0 AS MASTER_INV
                  FROM g_elemfi       GE,
                       g_dossier      GD_COMPTE,
                       g_dossier      GD_DECOMPTE,
                       t_intervenants TI_COMPTE,
                       t_intervenants TI_DECOMPTE,
                       v_elemfi       VE
                 WHERE GE.dttraite_dt IS NULL
                   AND GE.dtannul_dt IS NULL
                   AND GE.refdoss = GD_COMPTE.refdoss
                   AND GE.type = VE.type
                   AND GE.type IN
                       ('NOTE DE DEBIT', 'BULK DEDUCTION', 'FACT NON RECUE')
                   AND DECODE(GE.type,
                              'NOTE DE DEBIT',
                              1,
                              'FACT NON RECUE',
                              1,
                              -1) * GE.montant_mvt > 0
                   AND GD_COMPTE.categdoss LIKE 'COMPTE%'
                   AND GD_COMPTE.refdoss = TI_COMPTE.refdoss
                   AND GD_DECOMPTE.reflot = '0001010163'
                   AND TI_DECOMPTE.refindividu = 'A600DQHD'
                   AND EXISTS
                 (SELECT 1
                          FROM g_individu GI
                         WHERE GI.refindividu = TI_DECOMPTE.refindividu
                           AND (GI.str36 IS NULL OR
                               GI.str36 IN
                               (SELECT str1
                                   FROM g_indivparam GP
                                  WHERE GP.refindividu = 'A6004VFN'
                                    AND type = 'type_indiv')))
                   AND EXISTS
                 (SELECT 1
                          FROM g_individu GI
                         WHERE GI.refindividu = TI_COMPTE.refindividu
                           AND (GI.str36 IS NULL OR
                               GI.str36 IN
                               (SELECT str1
                                   FROM g_indivparam GP
                                  WHERE GP.refindividu = 'A6004VFN'
                                    AND type = 'type_indiv')))
                   AND TI_COMPTE.reftype = 'DB'
                   AND GD_COMPTE.reflot = GD_DECOMPTE.refdoss
                   AND GD_DECOMPTE.categdoss LIKE 'DECOMPTE%'
                   AND GD_DECOMPTE.refdoss = TI_DECOMPTE.refdoss
                   AND TI_DECOMPTE.reftype =
                       DECODE(GD_DECOMPTE.categdoss,
                              'DECOMPTE IMP',
                              'TC',
                              'CL')
                UNION ALL
                SELECT NVL(ENC.dtencaiss, ENC.dtreception) AS DTDEBUT,
                       NVL(ENC.dtencaiss, ENC.dtreception) AS DT_EMIS,
                       VENTIL.refencaiss AS REFELEM,
                       NULL AS ST09,
                       NULL AS FG09,
                       'enIMP' AS TYPE,
                       NULL AS mt09,
                       NULL AS dt14,
                       NULL AS MT48_CONV,
                       NULL AS MT09_MT48_CONV,
                       VENTIL.montant_dos,
                       0 AS SOLDE_CONV,
                       NULL AS MT01,
                       NULL AS MT01_CONV,
                       GD_COMPTE.devise AS DEVISE_DOS,
                       GD_DECOMPTE.devise AS DEVISE_DCPT,
                       0 AS FIN_CONV,
                       NULL AS COV_NFIN_CONV,
                       NULL AS NCOV_NFIN_CONV,
                       Ch_Taux.Conv_Orig_Dest_Tx(TO_CHAR(SYSDATE, 'j'),
                                                 NVL(VENTIL.montant_dos, 0),
                                                 GD_COMPTE.devise,
                                                 'EUR',
                                                 'MER',
                                                 ftr_fin_factor.getCurrency(GD_COMPTE.reffactor),
                                                 ftr_fin_factor.getPays(GD_COMPTE.reffactor)) AS enc_impaye,
                       0 AS MASTER_INV
                  FROM g_ventilenc    VENTIL,
                       g_encaissement ENC,
                       g_dossier      GD_COMPTE,
                       g_dossier      GD_DECOMPTE,
                       g_dossier      GD_CONTRAT,
                       t_intervenants TI_COMPTE,
                       t_intervenants TI_CONTRAT
                 WHERE ENC.refencaiss = VENTIL.refencaiss
                   AND ENC.typencaiss = 'e_saencaiss'
                   AND VENTIL.traite = '9'
                   AND ENC.dtimpaye_dt IS NOT NULL
                   AND VENTIL.refdoss = GD_COMPTE.refdoss
                   AND GD_COMPTE.reflot = GD_DECOMPTE.refdoss
                   AND GD_DECOMPTE.reflot = GD_CONTRAT.refdoss
                   AND 'IMPAYE' =
                       (SELECT pmt_status
                          FROM pmt_status
                         WHERE ref_payment = ENC.refencaiss
                           AND pmt_status_id =
                               (SELECT MAX(pmt_status_id)
                                  FROM pmt_status
                                 WHERE ref_payment = ENC.refencaiss))
                   AND GD_COMPTE.refdoss = TI_COMPTE.refdoss
                   AND GD_CONTRAT.refdoss = TI_CONTRAT.refdoss
                   AND GD_CONTRAT.refdoss = '0001010163'
                   AND TI_CONTRAT.refindividu = 'A600DQHD'
                   AND EXISTS
                 (SELECT 1
                          FROM g_individu GI
                         WHERE GI.refindividu = TI_CONTRAT.refindividu
                           AND (GI.str36 IS NULL OR
                               GI.str36 IN
                               (SELECT str1
                                   FROM g_indivparam GP
                                  WHERE GP.refindividu = 'A6004VFN'
                                    AND type = 'type_indiv')))
                   AND EXISTS
                 (SELECT 1
                          FROM g_individu GI
                         WHERE GI.refindividu = TI_COMPTE.refindividu
                           AND (GI.str36 IS NULL OR
                               GI.str36 IN
                               (SELECT str1
                                   FROM g_indivparam GP
                                  WHERE GP.refindividu = 'A6004VFN'
                                    AND type = 'type_indiv')))
                   AND TI_COMPTE.reftype = 'DB'
                   AND GD_COMPTE.categdoss LIKE 'COMPTE%'
                   AND GD_DECOMPTE.categdoss LIKE 'DECOMPTE%'
                   AND GD_CONTRAT.categdoss LIKE 'CONTRAT%'
                   AND TI_CONTRAT.reftype =
                       DECODE(GD_CONTRAT.categdoss, 'CONTRAT IMP', 'TC', 'CL')) V_FACT)
where 1 = 1
   and 1 = 1;

-- 9xyjhud4sy3wy

SELECT SUM(SIGN(montant_ltg) * LEAST(ABS(montant_ltg), ABS(solde))) AS COUNT_DISP,
       SUM(SIGN(montant_ltg48) * LEAST(ABS(montant_ltg48), ABS(solde))) AS COUNT_DISP48,
       SUM(SIGN(montant_pda) * LEAST(ABS(montant_pda), ABS(solde))) AS COUNT_PDA
  FROM (SELECT /*+ index(GE G_ELEMFI$REFDOSS_ACTIF) */
         montant_ltg,
         montant_ltg48,
         montant_pda,
         Ch_Taux.Conv_Orig_Dest_Tx(TO_CHAR(SYSDATE, 'j'),
                                   DECODE(P.dt10,
                                          NULL,
                                          P.mt09,
                                          ftr_util.SoldeF(GE.refelem)),
                                   ge.devise_dos,
                                   'EUR',
                                   'MER',
                                   ftr_fin_factor.getCurrency(GD_COMPTE.reffactor),
                                   ftr_fin_factor.getPays(GD_COMPTE.reffactor)) solde
          FROM g_elemfi GE,
               g_dossier GD_COMPTE,
               g_dossier GD_DECOMPTE,
               t_intervenants TI_COMPTE,
               t_intervenants TI_DECOMPTE,
               g_piece P,
               (SELECT ge.refelem,
                       SUM(DECODE(C.TYPE,
                                  'LTG',
                                  DECODE(SUBSTR(C.raison, 1, 2),
                                         '48',
                                         0,
                                         'PD',
                                         0,
                                         DECODE(GE.type,
                                                'NOTE DE CREDIT',
                                                Ch_Taux.Conv_Orig_Dest_Tx(TO_CHAR(SYSDATE,
                                                                                  'j'),
                                                                          NVL(GE.montant_dos,
                                                                              0),
                                                                          GE.devise_dos,
                                                                          'EUR',
                                                                          'MER'),
                                                Ch_Taux.Conv_Orig_Dest_Tx(TO_CHAR(SYSDATE,
                                                                                  'j'),
                                                                          NVL(VC.montant,
                                                                              0),
                                                                          GE.devise_dos,
                                                                          'EUR',
                                                                          'MER'))),
                                  0)) AS montant_ltg,
                       SUM(DECODE(C.TYPE,
                                  'PD',
                                  DECODE(C.retrocession,
                                         'N',
                                         DECODE(GE.type,
                                                'NOTE 
  DE CREDIT',
                                                Ch_Taux.Conv_Orig_Dest_Tx(TO_CHAR(SYSDATE,
                                                                                  'j'),
                                                                          NVL(GE.montant_dos,
                                                                              0),
                                                                          GE.devise_dos,
                                                                          'EUR',
                                                                          'MER'),
                                                Ch_Taux.Conv_Orig_Dest_Tx(TO_CHAR(SYSDATE,
                                                                                  'j'),
                                                                          NVL(VC.montant,
                                                                              0),
                                                                          GE.devise_dos,
                                                                          'EUR',
                                                                          'MER')),
                                         'A',
                                         DECODE(GE.type,
                                                'NOTE DE CREDIT',
                                                Ch_Taux.Conv_Orig_Dest_Tx(TO_CHAR(SYSDATE,
                                                                                  'j'),
                                                                          NVL(GE.montant_dos,
                                                                              0),
                                                                          GE.devise_dos,
                                                                          'EUR',
                                                                          'MER'),
                                                Ch_Taux.Conv_Orig_Dest_Tx(TO_CHAR(SYSDATE,
                                                                                  'j'),
                                                                          NVL(VC.montant,
                                                                              0),
                                                                          GE.devise_dos,
                                                                          'EUR',
                                                                          'MER')),
                                         0),
                                  0)) AS montant_pda,
                       SUM(DECODE(C.TYPE,
                                  'LTG',
                                  DECODE(SUBSTR(C.raison, 1, 2),
                                        '48',
                                         DECODE(GE.type,
                                                'NOTE DE CREDIT',
                                                Ch_Taux.Conv_Orig_Dest_Tx(TO_CHAR(SYSDATE,
                                                                                  'j'),
                                                                          NVL(GE.montant_dos,
                                                                              0),
                                                                          GE.devise_dos,
                                                                          'EUR',
                                                                          'MER'),
                                                Ch_Taux.Conv_Orig_Dest_Tx(TO_CHAR(SYSDATE,
                                                                                  'j'),
                                                                          NVL(VC.montant,
                                                                              0),
                                                                          GE.devise_dos,
                                                                          'EUR',
                                                                          'MER')),
                                         'PD',
                                         DECODE(GE.type,
                                                'NOTE DE 
  CREDIT',
                                                Ch_Taux.Conv_Orig_Dest_Tx(TO_CHAR(SYSDATE,
                                                                                  'j'),
                                                                          NVL(GE.montant_dos,
                                                                              0),
                                                                          GE.devise_dos,
                                                                          'EUR',
                                                                          'MER'),
                                                Ch_Taux.Conv_Orig_Dest_Tx(TO_CHAR(SYSDATE,
                                                                                  'j'),
                                                                          NVL(VC.montant,
                                                                              0),
                                                                          GE.devise_dos,
                                                                          'EUR',
                                                                          'MER')),
                                         0),
                                  0)) AS montant_ltg48
                  FROM g_vencontest VC, g_contestation C, g_elemfi ge
                 WHERE VC.refelem = GE.refelem
                   AND VC.refcontest = C.refcontest
                   AND C.TYPE IN ('LTG', 'PD')
                   AND (C.dtresolution_dt IS NULL OR
                       TRUNC(C.dtresolution_dt) > TRUNC(SYSDATE))
                 GROUP BY ge.refelem) LTG
         WHERE GE.dttraite_dt IS NULL
           AND GE.dtannul_dt IS NULL
           AND GE.refdoss = GD_COMPTE.refdoss
           AND GD_COMPTE.categdoss LIKE 'COMPTE%'
           AND GD_COMPTE.refdoss = TI_COMPTE.refdoss
           AND GE.actif = 'O'
           AND GD_DECOMPTE.reflot = '0001010163'
           AND TI_DECOMPTE.refindividu = 'A600DQHD'
           AND EXISTS
         (SELECT 1
                  FROM g_individu GI
                 WHERE GI.refindividu = TI_DECOMPTE.refindividu
                   AND (GI.str36 IS NULL OR
                       GI.str36 IN (SELECT str1
                                       FROM g_indivparam GP
                                      WHERE GP.refindividu = 'A6004VFN'
                                        AND type = 'type_indiv')))
           AND EXISTS
         (SELECT 1
                  FROM g_individu GI
                 WHERE GI.refindividu = TI_COMPTE.refindividu
                   AND (GI.str36 IS NULL OR
                       GI.str36 IN (SELECT str1
                                       FROM g_indivparam GP
                                      WHERE GP.refindividu = 'A6004VFN'
                                        AND type = 'type_indiv')))
           AND ltg.refelem = ge.refelem
           AND P.typpiece = 'FACTURE'
           AND P.gpiheure = GE.refelem
           AND GE.TYPE IN ('FACTURE',
                           'NOTE DE 
  CREDIT')
           AND TI_COMPTE.reftype = 'DB'
           AND GD_COMPTE.reflot = GD_DECOMPTE.refdoss
           AND GD_DECOMPTE.categdoss LIKE 'DECOMPTE%'
           AND GD_DECOMPTE.refdoss = TI_DECOMPTE.refdoss
           AND TI_DECOMPTE.reftype =
               DECODE(GD_DECOMPTE.categdoss, 'DECOMPTE IMP', 'TC', 'CL')) V_FACT;


/********************************New SQL*******************************************/
/********************************New Metrics***************************************/
/*
-- 60z8jc35ttb8q

Plan hash value: 1969467506
------------------------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                      | Name                      | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  |
------------------------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                               |                           |      1 |        |    21 (100)|      1 |00:00:00.15 |   19526 |    310 |
|   1 |  SORT AGGREGATE                                |                           |      1 |      1 |            |      1 |00:00:00.15 |   19526 |    310 |
|*  2 |   FILTER                                       |                           |      1 |        |            |      0 |00:00:00.15 |   19526 |    310 |
|   3 |    NESTED LOOPS                                |                           |      1 |      1 |    21   (0)|      0 |00:00:00.15 |   19526 |    310 |
|   4 |     NESTED LOOPS                               |                           |      1 |      1 |    21   (0)|      0 |00:00:00.15 |   19526 |    310 |
|   5 |      NESTED LOOPS                              |                           |      1 |      1 |    20   (0)|      0 |00:00:00.15 |   19526 |    310 |
|   6 |       NESTED LOOPS SEMI                        |                           |      1 |      1 |    19   (0)|      0 |00:00:00.15 |   19526 |    310 |
|   7 |        NESTED LOOPS                            |                           |      1 |     44 |    17   (0)|   1845 |00:00:00.14 |   14379 |    310 |
|   8 |         NESTED LOOPS                           |                           |      1 |     71 |    15   (0)|   1845 |00:00:00.13 |    6064 |    310 |
|   9 |          NESTED LOOPS                          |                           |      1 |    281 |     4   (0)|   1880 |00:00:00.01 |     861 |      0 |
|* 10 |           HASH JOIN                            |                           |      1 |      5 |     3   (0)|      1 |00:00:00.01 |      27 |      0 |
|  11 |            NESTED LOOPS                        |                           |      1 |     53 |     2   (0)|      1 |00:00:00.01 |       8 |      0 |
|  12 |             TABLE ACCESS BY INDEX ROWID        | G_INDIVIDU                |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       4 |      0 |
|* 13 |              INDEX UNIQUE SCAN                 | IND_REFINDIV              |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |      0 |
|  14 |             TABLE ACCESS BY INDEX ROWID BATCHED| G_DOSSIER                 |      1 |     53 |     1   (0)|      1 |00:00:00.01 |       4 |      0 |
|* 15 |              INDEX RANGE SCAN                  | G_DOSSIER_RL_CD_RD_RF_IDX |      1 |     53 |     1   (0)|      1 |00:00:00.01 |       3 |      0 |
|* 16 |            INDEX RANGE SCAN                    | INT_INDIV                 |      1 |   1776 |     1   (0)|   1889 |00:00:00.01 |      19 |      0 |
|  17 |           TABLE ACCESS BY INDEX ROWID BATCHED  | G_DOSSIER                 |      1 |     53 |     1   (0)|   1880 |00:00:00.01 |     834 |      0 |
|* 18 |            INDEX RANGE SCAN                    | G_DOSSIER_RL_CD_RD_RF_IDX |      1 |     53 |     1   (0)|   1880 |00:00:00.01 |      26 |      0 |
|* 19 |          TABLE ACCESS BY INDEX ROWID BATCHED   | G_ELEMFI                  |   1880 |      1 |     1   (0)|   1845 |00:00:00.12 |    5203 |    310 |
|* 20 |           INDEX RANGE SCAN                     | G_ELEMFI$REFDOSS_ACTIF    |   1880 |      1 |     1   (0)|   1845 |00:00:00.12 |    4139 |    310 |
|* 21 |         TABLE ACCESS BY INDEX ROWID BATCHED    | G_PIECE                   |   1845 |      1 |     1   (0)|   1845 |00:00:00.01 |    8315 |      0 |
|* 22 |          INDEX RANGE SCAN                      | G_PIECE$GPIHEURE          |   1845 |      1 |     1   (0)|   1845 |00:00:00.01 |    3387 |      0 |
|* 23 |        TABLE ACCESS BY INDEX ROWID BATCHED     | G_PIECEDET                |   1845 |    700K|     1   (0)|      0 |00:00:00.01 |    5147 |      0 |
|* 24 |         INDEX RANGE SCAN                       | G_PIECEDET_REFP           |   1845 |      1 |     1   (0)|      0 |00:00:00.01 |    5147 |      0 |
|* 25 |       INDEX RANGE SCAN                         | INT_REFDOSS               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 26 |      INDEX UNIQUE SCAN                         | IND_REFINDIV              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|  27 |     TABLE ACCESS BY INDEX ROWID                | G_INDIVIDU                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 28 |    INDEX RANGE SCAN                            | G_INDIVPARAM_REFIND       |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 29 |    INDEX RANGE SCAN                            | G_INDIVPARAM_REFIND       |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
------------------------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   2 - filter((("GI"."STR36" IS NULL OR  IS NOT NULL) AND ("GI"."STR36" IS NULL OR  IS NOT NULL)))
  10 - access("GD_DECOMPTE"."REFDOSS"="TI_DECOMPTE"."REFDOSS" AND "TI_DECOMPTE"."REFTYPE"=DECODE("GD_DECOMPTE"."CATEGDOSS",'DECOMPTE
              IMP','TC','CL') AND "GI"."REFINDIVIDU"="TI_DECOMPTE"."REFINDIVIDU")
  13 - access("GI"."REFINDIVIDU"='A600DQHD')
  15 - access("GD_DECOMPTE"."REFLOT"='0001010163' AND "GD_DECOMPTE"."CATEGDOSS" LIKE 'DECOMPTE%')
       filter("GD_DECOMPTE"."CATEGDOSS" LIKE 'DECOMPTE%')
  16 - access("TI_DECOMPTE"."REFINDIVIDU"='A600DQHD')
  18 - access("GD_COMPTE"."REFLOT"="GD_DECOMPTE"."REFDOSS" AND "GD_COMPTE"."CATEGDOSS" LIKE 'COMPTE%')
       filter("GD_COMPTE"."CATEGDOSS" LIKE 'COMPTE%')
  19 - filter(("GE"."DTTRAITE_DT" IS NULL AND "GE"."DTANNUL_DT" IS NULL))
  20 - access("GE"."REFDOSS"="GD_COMPTE"."REFDOSS" AND "GE"."ACTIF"='O')
       filter(("GE"."TYPE"='FACTURE' OR "GE"."TYPE"='NOTE DE CREDIT'))
  21 - filter("P"."TYPPIECE"='FACTURE')
  22 - access("P"."GPIHEURE"="GE"."REFELEM")
       filter("P"."GPIHEURE" IS NOT NULL)
  23 - filter(("GD_COMPTE"."REFDOSS"="PD"."REFDOSS" AND "PD"."REFDOSS" IS NOT NULL))
  24 - access("PD"."REFPIECE"="P"."REFPIECE" AND "PD"."TYPE"='PROROGATION')
  25 - access("GD_COMPTE"."REFDOSS"="TI_COMPTE"."REFDOSS" AND "TI_COMPTE"."REFTYPE"='DB')
  26 - access("GI"."REFINDIVIDU"="TI_COMPTE"."REFINDIVIDU")
  28 - access("GP"."REFINDIVIDU"='A6004VFN' AND "TYPE"='type_indiv' AND "STR1"=:B1)
       filter("STR1"=:B1)
  29 - access("GP"."REFINDIVIDU"='A6004VFN' AND "TYPE"='type_indiv' AND "STR1"=:B1)
       filter("STR1"=:B1)

-- 2ygcq7pt9jmnu

Plan hash value: 1056821589
-----------------------------------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                            | Name                           | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  |
-----------------------------------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                                     |                                |      1 |        |    92 (100)|      1 |00:00:00.24 |   35069 |    222 |
|   1 |  VIEW                                                |                                |      1 |      1 |    92   (2)|      1 |00:00:00.24 |   35069 |    222 |
|   2 |   SORT AGGREGATE                                     |                                |      1 |      1 |            |      1 |00:00:00.24 |   35069 |    222 |
|   3 |    VIEW                                              |                                |      1 |    117 |    92   (2)|   1846 |00:00:00.23 |   35069 |    222 |
|   4 |     UNION-ALL                                        |                                |      1 |        |            |   1846 |00:00:00.23 |   35069 |    222 |
|   5 |      HASH GROUP BY                                   |                                |      1 |     96 |    63   (2)|   1846 |00:00:00.19 |   27826 |    203 |
|*  6 |       FILTER                                         |                                |      1 |        |            |   1846 |00:00:00.19 |   27826 |    203 |
|*  7 |        FILTER                                        |                                |      1 |        |            |   1846 |00:00:00.19 |   27814 |    203 |
|*  8 |         HASH JOIN RIGHT OUTER                        |                                |      1 |    353 |    62   (0)|   1846 |00:00:00.19 |   27814 |    203 |
|   9 |          TABLE ACCESS STORAGE FULL                   | V_ELEMFI                       |      1 |    146 |     4   (0)|    146 |00:00:00.01 |       7 |      0 |
|  10 |          NESTED LOOPS                                |                                |      1 |    350 |    58   (0)|   1846 |00:00:00.18 |   27807 |    203 |
|  11 |           NESTED LOOPS OUTER                         |                                |      1 |    350 |    54   (0)|   1846 |00:00:00.17 |   24374 |    187 |
|  12 |            NESTED LOOPS                              |                                |      1 |    350 |    44   (0)|   1846 |00:00:00.10 |   20974 |    105 |
|  13 |             NESTED LOOPS                             |                                |      1 |    567 |    27   (0)|   1846 |00:00:00.09 |   12623 |    103 |
|  14 |              NESTED LOOPS                            |                                |      1 |    282 |    15   (0)|   1880 |00:00:00.08 |    7419 |    103 |
|  15 |               NESTED LOOPS                           |                                |      1 |    282 |    10   (0)|   1880 |00:00:00.02 |    1945 |     20 |
|  16 |                NESTED LOOPS                          |                                |      1 |    281 |     4   (0)|   1880 |00:00:00.02 |     861 |     20 |
|* 17 |                 HASH JOIN                            |                                |      1 |      5 |     3   (0)|      1 |00:00:00.01 |      27 |      0 |
|  18 |                  NESTED LOOPS                        |                                |      1 |     53 |     2   (0)|      1 |00:00:00.01 |       8 |      0 |
|  19 |                   TABLE ACCESS BY INDEX ROWID        | G_INDIVIDU                     |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       4 |      0 |
|* 20 |                    INDEX UNIQUE SCAN                 | IND_REFINDIV                   |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |      0 |
|  21 |                   TABLE ACCESS BY INDEX ROWID BATCHED| G_DOSSIER                      |      1 |     53 |     1   (0)|      1 |00:00:00.01 |       4 |      0 |
|* 22 |                    INDEX RANGE SCAN                  | G_DOSSIER_RL_CD_RD_RF_IDX      |      1 |     53 |     1   (0)|      1 |00:00:00.01 |       3 |      0 |
|* 23 |                  INDEX RANGE SCAN                    | INT_INDIV                      |      1 |   1776 |     1   (0)|   1889 |00:00:00.01 |      19 |      0 |
|  24 |                 TABLE ACCESS BY INDEX ROWID BATCHED  | G_DOSSIER                      |      1 |     53 |     1   (0)|   1880 |00:00:00.02 |     834 |     20 |
|* 25 |                  INDEX RANGE SCAN                    | G_DOSSIER_RL_CD_RD_RF_IDX      |      1 |     53 |     1   (0)|   1880 |00:00:00.01 |      26 |      0 |
|* 26 |                INDEX RANGE SCAN                      | INT_REFDOSS                    |   1880 |      1 |     1   (0)|   1880 |00:00:00.01 |    1084 |      0 |
|  27 |               TABLE ACCESS BY INDEX ROWID            | G_INDIVIDU                     |   1880 |      1 |     1   (0)|   1880 |00:00:00.05 |    5474 |     83 |
|* 28 |                INDEX UNIQUE SCAN                     | IND_REFINDIV                   |   1880 |      1 |     1   (0)|   1880 |00:00:00.01 |    3657 |      1 |
|* 29 |              TABLE ACCESS BY INDEX ROWID BATCHED     | G_ELEMFI                       |   1880 |      2 |     1   (0)|   1846 |00:00:00.01 |    5204 |      0 |
|* 30 |               INDEX RANGE SCAN                       | G_ELEMFI$REFDOSS_ACTIF         |   1880 |      2 |     1   (0)|   1846 |00:00:00.01 |    4139 |      0 |
|* 31 |             TABLE ACCESS BY INDEX ROWID BATCHED      | G_PIECE                        |   1846 |      1 |     1   (0)|   1846 |00:00:00.02 |    8351 |      2 |
|* 32 |              INDEX RANGE SCAN                        | G_PIECE$GPIHEURE               |   1846 |      1 |     1   (0)|   1846 |00:00:00.01 |    3389 |      0 |
|  33 |            TABLE ACCESS BY INDEX ROWID BATCHED       | G_VENRESTRICTION               |   1846 |      1 |     1   (0)|     60 |00:00:00.07 |    3400 |     82 |
|* 34 |             INDEX RANGE SCAN                         | G_VENRESTRICTION$REFELEM       |   1846 |      1 |     1   (0)|     60 |00:00:00.06 |    3363 |     59 |
|* 35 |           INDEX UNIQUE SCAN                          | PK_G_DB_PTF_ITEM               |   1846 |      1 |     1   (0)|   1846 |00:00:00.01 |    3433 |     16 |
|* 36 |        INDEX RANGE SCAN                              | G_INDIVPARAM_REFIND            |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |      0 |
|* 37 |        INDEX RANGE SCAN                              | G_INDIVPARAM_REFIND            |      3 |      1 |     1   (0)|      3 |00:00:00.01 |       9 |      0 |
|* 38 |      FILTER                                          |                                |      1 |        |            |      0 |00:00:00.02 |    3784 |      0 |
|  39 |       NESTED LOOPS                                   |                                |      1 |     73 |    19   (0)|      0 |00:00:00.02 |    3784 |      0 |
|  40 |        NESTED LOOPS                                  |                                |      1 |     73 |    19   (0)|      0 |00:00:00.02 |    3784 |      0 |
|  41 |         NESTED LOOPS                                 |                                |      1 |     73 |    18   (0)|      0 |00:00:00.02 |    3784 |      0 |
|* 42 |          HASH JOIN                                   |                                |      1 |     69 |    16   (0)|      0 |00:00:00.02 |    3784 |      0 |
|  43 |           INLIST ITERATOR                            |                                |      1 |        |            |      3 |00:00:00.01 |       2 |      0 |
|* 44 |            INDEX RANGE SCAN                          | VF_TYPE_FINANCING              |      3 |      3 |     1   (0)|      3 |00:00:00.01 |       2 |      0 |
|  45 |           NESTED LOOPS                               |                                |      1 |    137 |    15   (0)|      0 |00:00:00.01 |    3782 |      0 |
|  46 |            NESTED LOOPS                              |                                |      1 |   1124 |    15   (0)|      0 |00:00:00.01 |    3782 |      0 |
|  47 |             NESTED LOOPS                             |                                |      1 |    281 |     4   (0)|   1880 |00:00:00.01 |     861 |      0 |
|* 48 |              HASH JOIN                               |                                |      1 |      5 |     3   (0)|      1 |00:00:00.01 |      27 |      0 |
|  49 |               NESTED LOOPS                           |                                |      1 |     53 |     2   (0)|      1 |00:00:00.01 |       8 |      0 |
|  50 |                TABLE ACCESS BY INDEX ROWID           | G_INDIVIDU                     |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       4 |      0 |
|* 51 |                 INDEX UNIQUE SCAN                    | IND_REFINDIV                   |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |      0 |
|  52 |                TABLE ACCESS BY INDEX ROWID BATCHED   | G_DOSSIER                      |      1 |     53 |     1   (0)|      1 |00:00:00.01 |       4 |      0 |
|* 53 |                 INDEX RANGE SCAN                     | G_DOSSIER_RL_CD_RD_RF_IDX      |      1 |     53 |     1   (0)|      1 |00:00:00.01 |       3 |      0 |
|* 54 |               INDEX RANGE SCAN                       | INT_INDIV                      |      1 |   1776 |     1   (0)|   1889 |00:00:00.01 |      19 |      0 |
|  55 |              TABLE ACCESS BY INDEX ROWID BATCHED     | G_DOSSIER                      |      1 |     53 |     1   (0)|   1880 |00:00:00.01 |     834 |      0 |
|* 56 |               INDEX RANGE SCAN                       | G_DOSSIER_RL_CD_RD_RF_IDX      |      1 |     53 |     1   (0)|   1880 |00:00:00.01 |      26 |      0 |
|* 57 |             INDEX RANGE SCAN                         | G_ELEMFI_DOS_TYP_FG02_CODE_IDX |   1880 |      4 |     1   (0)|      0 |00:00:00.01 |    2921 |      0 |
|* 58 |            TABLE ACCESS BY INDEX ROWID               | G_ELEMFI                       |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 59 |          INDEX RANGE SCAN                            | INT_REFDOSS                    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 60 |         INDEX UNIQUE SCAN                            | IND_REFINDIV                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|  61 |        TABLE ACCESS BY INDEX ROWID                   | G_INDIVIDU                     |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 62 |       INDEX RANGE SCAN                               | G_INDIVPARAM_REFIND            |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 63 |       INDEX RANGE SCAN                               | G_INDIVPARAM_REFIND            |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 64 |      FILTER                                          |                                |      1 |        |            |      0 |00:00:00.02 |    3459 |     19 |
|  65 |       NESTED LOOPS                                   |                                |      1 |      1 |     9   (0)|      0 |00:00:00.02 |    3459 |     19 |
|  66 |        NESTED LOOPS                                  |                                |      1 |      1 |     9   (0)|      0 |00:00:00.02 |    3459 |     19 |
|  67 |         NESTED LOOPS                                 |                                |      1 |      1 |     8   (0)|      0 |00:00:00.02 |    3459 |     19 |
|  68 |          NESTED LOOPS                                |                                |      1 |      1 |     7   (0)|      0 |00:00:00.02 |    3459 |     19 |
|  69 |           NESTED LOOPS                               |                                |      1 |     27 |     6   (0)|     71 |00:00:00.02 |    3242 |     15 |
|  70 |            NESTED LOOPS                              |                                |      1 |      2 |     5   (0)|   1880 |00:00:00.01 |     851 |      0 |
|  71 |             MERGE JOIN CARTESIAN                     |                                |      1 |      1 |     4   (0)|      1 |00:00:00.01 |      17 |      0 |
|  72 |              NESTED LOOPS                            |                                |      1 |      1 |     3   (0)|      1 |00:00:00.01 |      14 |      0 |
|  73 |               NESTED LOOPS                           |                                |      1 |      1 |     2   (0)|      1 |00:00:00.01 |      11 |      0 |
|* 74 |                INDEX SKIP SCAN                       | REFHIERARCHIE_IDX              |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       7 |      0 |
|  75 |                TABLE ACCESS BY INDEX ROWID           | G_INDIVIDU                     |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       4 |      0 |
|* 76 |                 INDEX UNIQUE SCAN                    | IND_REFINDIV                   |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |      0 |
|* 77 |               INDEX RANGE SCAN                       | INT_INDIV                      |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |      0 |
|  78 |              BUFFER SORT                             |                                |      1 |     53 |     3   (0)|      1 |00:00:00.01 |       3 |      0 |
|* 79 |               INDEX RANGE SCAN                       | G_DOSSIER_RL_CD_RD_RF_IDX      |      1 |     53 |     1   (0)|      1 |00:00:00.01 |       3 |      0 |
|  80 |             TABLE ACCESS BY INDEX ROWID BATCHED      | G_DOSSIER                      |      1 |     53 |     1   (0)|   1880 |00:00:00.01 |     834 |      0 |
|* 81 |              INDEX RANGE SCAN                        | G_DOSSIER_RL_CD_RD_RF_IDX      |      1 |     53 |     1   (0)|   1880 |00:00:00.01 |      26 |      0 |
|  82 |            TABLE ACCESS BY INDEX ROWID BATCHED       | G_VENTILENC                    |   1880 |     13 |     1   (0)|     71 |00:00:00.02 |    2391 |     15 |
|* 83 |             INDEX RANGE SCAN                         | G_VENTILENC_REFDOSS_TRAITE     |   1880 |     37 |     1   (0)|     71 |00:00:00.02 |    2320 |     13 |
|* 84 |           TABLE ACCESS BY INDEX ROWID                | G_ENCAISSEMENT                 |     71 |      1 |     1   (0)|      0 |00:00:00.01 |     217 |      4 |
|* 85 |            INDEX UNIQUE SCAN                         | REFENCAISS                     |     71 |      1 |     1   (0)|      0 |00:00:00.01 |     217 |      4 |
|* 86 |             TABLE ACCESS BY INDEX ROWID              | PMT_STATUS                     |     71 |      1 |     1   (0)|      0 |00:00:00.01 |      73 |      0 |
|* 87 |              INDEX UNIQUE SCAN                       | PMT_STATUS_PK                  |     71 |      1 |     1   (0)|      0 |00:00:00.01 |      73 |      0 |
|  88 |               SORT AGGREGATE                         |                                |     71 |      1 |            |     71 |00:00:00.01 |      73 |      0 |
|  89 |                TABLE ACCESS BY INDEX ROWID BATCHED   | PMT_STATUS                     |     71 |      1 |     1   (0)|      0 |00:00:00.01 |      73 |      0 |
|* 90 |                 INDEX RANGE SCAN                     | PMT_STATUS_REF_PAYMENT_IDX     |     71 |      1 |     1   (0)|      0 |00:00:00.01 |      73 |      0 |
|* 91 |          INDEX RANGE SCAN                            | INT_REFDOSS                    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 92 |         INDEX UNIQUE SCAN                            | IND_REFINDIV                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|  93 |        TABLE ACCESS BY INDEX ROWID                   | G_INDIVIDU                     |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 94 |       INDEX RANGE SCAN                               | G_INDIVPARAM_REFIND            |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 95 |       INDEX RANGE SCAN                               | G_INDIVPARAM_REFIND            |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
-----------------------------------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   6 - filter((("GI"."STR36" IS NULL OR  IS NOT NULL) AND ("GI"."STR36" IS NULL OR  IS NOT NULL)))
   7 - filter(NVL("VE"."FG_PARENT_INVOICE",'N')<>'O')
   8 - access("GE"."TYPE"="VE"."TYPE")
  17 - access("GD_DECOMPTE"."REFDOSS"="TI_DECOMPTE"."REFDOSS" AND "TI_DECOMPTE"."REFTYPE"=DECODE("GD_DECOMPTE"."CATEGDOSS",'DECOMPTE IMP','TC','CL') AND
              "GI"."REFINDIVIDU"="TI_DECOMPTE"."REFINDIVIDU")
  20 - access("GI"."REFINDIVIDU"='A600DQHD')
  22 - access("GD_DECOMPTE"."REFLOT"='0001010163' AND "GD_DECOMPTE"."CATEGDOSS" LIKE 'DECOMPTE%')
       filter("GD_DECOMPTE"."CATEGDOSS" LIKE 'DECOMPTE%')
  23 - access("TI_DECOMPTE"."REFINDIVIDU"='A600DQHD')
  25 - access("GD_COMPTE"."REFLOT"="GD_DECOMPTE"."REFDOSS" AND "GD_COMPTE"."CATEGDOSS" LIKE 'COMPTE%')
       filter("GD_COMPTE"."CATEGDOSS" LIKE 'COMPTE%')
  26 - access("GD_COMPTE"."REFDOSS"="TI_COMPTE"."REFDOSS" AND "TI_COMPTE"."REFTYPE"='DB')
  28 - access("GI"."REFINDIVIDU"="TI_COMPTE"."REFINDIVIDU")
  29 - filter(("GE"."DTTRAITE_DT" IS NULL AND "GE"."DTANNUL_DT" IS NULL))
  30 - access("GE"."REFDOSS"="GD_COMPTE"."REFDOSS" AND "GE"."ACTIF"='O')
  31 - filter("GP_FACT"."TYPPIECE"='FACTURE')
  32 - access("GP_FACT"."GPIHEURE"="GE"."REFELEM")
       filter("GP_FACT"."GPIHEURE" IS NOT NULL)
  34 - access("GE"."REFELEM"="REFELEM")
  35 - access("GE"."REFELEM"="PI"."REFELEM")
  36 - access("GP"."REFINDIVIDU"='A6004VFN' AND "TYPE"='type_indiv' AND "STR1"=:B1)
       filter("STR1"=:B1)
  37 - access("GP"."REFINDIVIDU"='A6004VFN' AND "TYPE"='type_indiv' AND "STR1"=:B1)
       filter("STR1"=:B1)
  38 - filter((("GI"."STR36" IS NULL OR  IS NOT NULL) AND ("GI"."STR36" IS NULL OR  IS NOT NULL)))
  42 - access("GE"."TYPE"="VE"."TYPE")
  44 - access(("VE"."TYPE"='BULK DEDUCTION' OR "VE"."TYPE"='FACT NON RECUE' OR "VE"."TYPE"='NOTE DE DEBIT'))
  48 - access("GD_DECOMPTE"."REFDOSS"="TI_DECOMPTE"."REFDOSS" AND "TI_DECOMPTE"."REFTYPE"=DECODE("GD_DECOMPTE"."CATEGDOSS",'DECOMPTE IMP','TC','CL') AND
              "GI"."REFINDIVIDU"="TI_DECOMPTE"."REFINDIVIDU")
  51 - access("GI"."REFINDIVIDU"='A600DQHD')
  53 - access("GD_DECOMPTE"."REFLOT"='0001010163' AND "GD_DECOMPTE"."CATEGDOSS" LIKE 'DECOMPTE%')
       filter("GD_DECOMPTE"."CATEGDOSS" LIKE 'DECOMPTE%')
  54 - access("TI_DECOMPTE"."REFINDIVIDU"='A600DQHD')
  56 - access("GD_COMPTE"."REFLOT"="GD_DECOMPTE"."REFDOSS" AND "GD_COMPTE"."CATEGDOSS" LIKE 'COMPTE%')
       filter("GD_COMPTE"."CATEGDOSS" LIKE 'COMPTE%')
  57 - access("GE"."REFDOSS"="GD_COMPTE"."REFDOSS")
       filter(("GE"."TYPE"='BULK DEDUCTION' OR "GE"."TYPE"='FACT NON RECUE' OR "GE"."TYPE"='NOTE DE DEBIT'))
  58 - filter(("GE"."DTTRAITE_DT" IS NULL AND DECODE("GE"."TYPE",'NOTE DE DEBIT',1,'FACT NON RECUE',1,(-1))*"GE"."MONTANT_MVT">0 AND "GE"."DTANNUL_DT" IS
              NULL))
  59 - access("GD_COMPTE"."REFDOSS"="TI_COMPTE"."REFDOSS" AND "TI_COMPTE"."REFTYPE"='DB')
  60 - access("GI"."REFINDIVIDU"="TI_COMPTE"."REFINDIVIDU")
  62 - access("GP"."REFINDIVIDU"='A6004VFN' AND "TYPE"='type_indiv' AND "STR1"=:B1)
       filter("STR1"=:B1)
  63 - access("GP"."REFINDIVIDU"='A6004VFN' AND "TYPE"='type_indiv' AND "STR1"=:B1)
       filter("STR1"=:B1)
  64 - filter((("GI"."STR36" IS NULL OR  IS NOT NULL) AND ("GI"."STR36" IS NULL OR  IS NOT NULL)))
  74 - access("GD_CONTRAT"."CATEGDOSS" LIKE 'CONTRAT%' AND "GD_CONTRAT"."REFDOSS"='0001010163')
       filter(("GD_CONTRAT"."REFDOSS"='0001010163' AND "GD_CONTRAT"."CATEGDOSS" LIKE 'CONTRAT%'))
  76 - access("GI"."REFINDIVIDU"='A600DQHD')
  77 - access("TI_CONTRAT"."REFINDIVIDU"='A600DQHD' AND "TI_CONTRAT"."REFTYPE"=DECODE("GD_CONTRAT"."CATEGDOSS",'CONTRAT IMP','TC','CL') AND
              "TI_CONTRAT"."REFDOSS"='0001010163')
  79 - access("GD_DECOMPTE"."REFLOT"='0001010163' AND "GD_DECOMPTE"."CATEGDOSS" LIKE 'DECOMPTE%')
       filter("GD_DECOMPTE"."CATEGDOSS" LIKE 'DECOMPTE%')
  81 - access("GD_COMPTE"."REFLOT"="GD_DECOMPTE"."REFDOSS" AND "GD_COMPTE"."CATEGDOSS" LIKE 'COMPTE%')
       filter("GD_COMPTE"."CATEGDOSS" LIKE 'COMPTE%')
  83 - access("VENTIL"."REFDOSS"="GD_COMPTE"."REFDOSS" AND "VENTIL"."TRAITE"='9')
  84 - filter(("ENC"."DTIMPAYE_DT" IS NOT NULL AND "ENC"."TYPENCAISS"='e_saencaiss'))
  85 - access("ENC"."REFENCAISS"="VENTIL"."REFENCAISS")
       filter(='IMPAYE')
  86 - filter("REF_PAYMENT"=:B1)
  87 - access("PMT_STATUS_ID"=)
  90 - access("REF_PAYMENT"=:B1)
  91 - access("GD_COMPTE"."REFDOSS"="TI_COMPTE"."REFDOSS" AND "TI_COMPTE"."REFTYPE"='DB')
  92 - access("GI"."REFINDIVIDU"="TI_COMPTE"."REFINDIVIDU")
  94 - access("GP"."REFINDIVIDU"='A6004VFN' AND "TYPE"='type_indiv' AND "STR1"=:B1)
       filter("STR1"=:B1)
  95 - access("GP"."REFINDIVIDU"='A6004VFN' AND "TYPE"='type_indiv' AND "STR1"=:B1)
       filter("STR1"=:B1)

-- 9xyjhud4sy3wy


Plan hash value: 647419807
------------------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                      | Name                         | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers |
------------------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                               |                              |      1 |        |    22 (100)|      1 |00:00:00.01 |    6838 |
|   1 |  SORT AGGREGATE                                |                              |      1 |      1 |            |      1 |00:00:00.01 |    6838 |
|   2 |   VIEW                                         | VM_NWVW_1                    |      1 |      1 |    22   (5)|      9 |00:00:00.01 |    6838 |
|   3 |    HASH GROUP BY                               |                              |      1 |      1 |    22   (5)|      9 |00:00:00.01 |    6838 |
|*  4 |     FILTER                                     |                              |      1 |        |            |      9 |00:00:00.01 |    6838 |
|   5 |      NESTED LOOPS                              |                              |      1 |      4 |    21   (0)|      9 |00:00:00.01 |    6832 |
|   6 |       NESTED LOOPS                             |                              |      1 |      4 |    21   (0)|      9 |00:00:00.01 |    6826 |
|   7 |        NESTED LOOPS                            |                              |      1 |      4 |    20   (0)|      9 |00:00:00.01 |    6806 |
|   8 |         NESTED LOOPS                           |                              |      1 |      6 |    19   (0)|      9 |00:00:00.01 |    6776 |
|   9 |          NESTED LOOPS                          |                              |      1 |      6 |    18   (0)|      9 |00:00:00.01 |    6756 |
|  10 |           NESTED LOOPS                         |                              |      1 |     78 |    17   (0)|      9 |00:00:00.01 |    6739 |
|  11 |            NESTED LOOPS                        |                              |      1 |     71 |    15   (0)|   1720 |00:00:00.01 |    5154 |
|  12 |             NESTED LOOPS                       |                              |      1 |    281 |     4   (0)|   1880 |00:00:00.01 |      52 |
|* 13 |              HASH JOIN                         |                              |      1 |      5 |     3   (0)|      1 |00:00:00.01 |      26 |
|  14 |               NESTED LOOPS                     |                              |      1 |     53 |     2   (0)|      1 |00:00:00.01 |       7 |
|  15 |                TABLE ACCESS BY INDEX ROWID     | G_INDIVIDU                   |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       4 |
|* 16 |                 INDEX UNIQUE SCAN              | IND_REFINDIV                 |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |
|* 17 |                INDEX RANGE SCAN                | G_DOSSIER_RL_CD_RD_RF_IDX    |      1 |     53 |     1   (0)|      1 |00:00:00.01 |       3 |
|* 18 |               INDEX RANGE SCAN                 | INT_INDIV                    |      1 |   1776 |     1   (0)|   1889 |00:00:00.01 |      19 |
|* 19 |              INDEX RANGE SCAN                  | G_DOSSIER_RL_CD_RD_RF_IDX    |      1 |     53 |     1   (0)|   1880 |00:00:00.01 |      26 |
|* 20 |             TABLE ACCESS BY INDEX ROWID BATCHED| G_ELEMFI                     |   1880 |      1 |     1   (0)|   1720 |00:00:00.01 |    5102 |
|* 21 |              INDEX RANGE SCAN                  | G_ELEMFI$REFDOSS_ACTIF       |   1880 |      1 |     1   (0)|   1720 |00:00:00.01 |    4139 |
|  22 |            TABLE ACCESS BY INDEX ROWID BATCHED | G_VENCONTEST                 |   1720 |      1 |     1   (0)|      9 |00:00:00.01 |    1585 |
|* 23 |             INDEX RANGE SCAN                   | G_VCONT_REFELEM_IDX          |   1720 |      1 |     1   (0)|      9 |00:00:00.01 |    1577 |
|* 24 |           TABLE ACCESS BY INDEX ROWID          | G_CONTESTATION               |      9 |      1 |     1   (0)|      9 |00:00:00.01 |      17 |
|* 25 |            INDEX UNIQUE SCAN                   | G_CONTESTATION$PK_REFCONTEST |      9 |      1 |     1   (0)|      9 |00:00:00.01 |      11 |
|* 26 |          INDEX RANGE SCAN                      | INT_REFDOSS                  |      9 |      1 |     1   (0)|      9 |00:00:00.01 |      20 |
|* 27 |         INDEX RANGE SCAN                       | GP_GRTYPE_MT_DT              |      9 |      1 |     1   (0)|      9 |00:00:00.01 |      30 |
|* 28 |        INDEX UNIQUE SCAN                       | IND_REFINDIV                 |      9 |      1 |     1   (0)|      9 |00:00:00.01 |      20 |
|  29 |       TABLE ACCESS BY INDEX ROWID              | G_INDIVIDU                   |      9 |      1 |     1   (0)|      9 |00:00:00.01 |       6 |
|* 30 |      INDEX RANGE SCAN                          | G_INDIVPARAM_REFIND          |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |
|* 31 |      INDEX RANGE SCAN                          | G_INDIVPARAM_REFIND          |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |
------------------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   4 - filter((("GI"."STR36" IS NULL OR  IS NOT NULL) AND ("GI"."STR36" IS NULL OR  IS NOT NULL)))
  13 - access("GD_DECOMPTE"."REFDOSS"="TI_DECOMPTE"."REFDOSS" AND "TI_DECOMPTE"."REFTYPE"=DECODE("GD_DECOMPTE"."CATEGDOSS",'DECOMPTE
              IMP','TC','CL') AND "GI"."REFINDIVIDU"="TI_DECOMPTE"."REFINDIVIDU")
  16 - access("GI"."REFINDIVIDU"='A600DQHD')
  17 - access("GD_DECOMPTE"."REFLOT"='0001010163' AND "GD_DECOMPTE"."CATEGDOSS" LIKE 'DECOMPTE%')
       filter("GD_DECOMPTE"."CATEGDOSS" LIKE 'DECOMPTE%')
  18 - access("TI_DECOMPTE"."REFINDIVIDU"='A600DQHD')
  19 - access("GD_COMPTE"."REFLOT"="GD_DECOMPTE"."REFDOSS" AND "GD_COMPTE"."CATEGDOSS" LIKE 'COMPTE%')
       filter("GD_COMPTE"."CATEGDOSS" LIKE 'COMPTE%')
  20 - filter(("GE"."DTTRAITE_DT" IS NULL AND "GE"."DTANNUL_DT" IS NULL))
  21 - access("GE"."REFDOSS"="GD_COMPTE"."REFDOSS" AND "GE"."ACTIF"='O')
       filter(("GE"."TYPE"='FACTURE' OR "GE"."TYPE"='NOTE DE   CREDIT'))
  23 - access("VC"."REFELEM"="REFELEM")
  24 - filter((("C"."DTRESOLUTION_DT" IS NULL OR TRUNC(INTERNAL_FUNCTION("C"."DTRESOLUTION_DT"))>TRUNC(SYSDATE@!)) AND
              INTERNAL_FUNCTION("C"."TYPE")))
  25 - access("VC"."REFCONTEST"="C"."REFCONTEST")
  26 - access("GD_COMPTE"."REFDOSS"="TI_COMPTE"."REFDOSS" AND "TI_COMPTE"."REFTYPE"='DB')
  27 - access("P"."TYPPIECE"='FACTURE' AND "P"."GPIHEURE"="GE"."REFELEM")
       filter("P"."GPIHEURE" IS NOT NULL)
  28 - access("GI"."REFINDIVIDU"="TI_COMPTE"."REFINDIVIDU")
  30 - access("GP"."REFINDIVIDU"='A6004VFN' AND "TYPE"='type_indiv' AND "STR1"=:B1)
       filter("STR1"=:B1)
  31 - access("GP"."REFINDIVIDU"='A6004VFN' AND "TYPE"='type_indiv' AND "STR1"=:B1)
       filter("STR1"=:B1)


*/
/********************************New Metrics***************************************/

/********************************Index statistics**********************************/

/********************************Other SQLs****************************************/          
/*

*/ 
/********************************Other SQLs****************************************/              
