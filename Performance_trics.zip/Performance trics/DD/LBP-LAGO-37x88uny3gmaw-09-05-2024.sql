/********************************************************************************
*********       E-mail subject: LBPWEB-5310 
*********             Instance: LAGO
*********          Description: 
Problem:
SQL 37x88uny3gmaw was provided as slow from instance Lago.

Analysis:
The main problem in this SQL is that Oracle use inappropriate execution plan, starting from selecting all rows from table g_dossier 
where the reffactor is 'INT00000' ( which are a lot of rows ). The optimization that I can propose here is using hints to force Oracle to 
start the execution from data set named "gt", from where we select 290 refdosses and then go to table g_dossier only for them.

Suggestion:
Please change the query as it is shown in the New SQL section below.

*********               SQL_ID: 37x88uny3gmaw
*********      Program/Package: 
*********              Request: Duyen Phuong Thi Nguyen 
*********               Author: Dimitar Dimitrov
********* Received e-mail date: 09/05/2024
*********      Resolution date: 09/05/2024
*********  Trace old file here: \\epox\specifs\performance\tmp\
*********  Trace new file here:
***********************************************************************************/

/********************************OLD SQL*******************************************/

SELECT  dos.reffactor /* automatically injected */, gt.*
   FROM (SELECT DISTINCT vd.refdoss, 1
           FROM g_vendosslimit vd, g_venfilimit vf
          WHERE vd.limit_id = vf.limit_id
            AND vf.limit_role = 'COVERAGE'
            AND NVL(vf.consumed_lim, 0) > 0
         UNION
         SELECT DISTINCT gc.refdoss, 2
           FROM t_collateral_cases gc, 
                t_collateral g
          WHERE gc.imx_colateral_id = g.imx_un_id
            AND g.dt_signature_dt IS NOT NULL
            AND (g.dt_due_dt IS NULL OR g.dt_due_dt >= to_date('08/05/2024','dd/mm/yyyy'))
            AND (dt_suspension_dt IS NULL OR dt_suspension_dt >= to_date('08/05/2024','dd/mm/yyyy'))) gt,
         g_dossier dos
  WHERE dos.refdoss =  gt.refdoss
    AND eom_manager.isEOM( dos.reffactor, to_date('08/05/2024','dd/mm/yyyy')  ) = 0
    /* reffactor condition */
   AND dos.reffactor IN ('INT00000')
  ORDER BY 2;
/********************************OLD SQL*******************************************/
/********************************OLD Metrics***************************************/
/*
Plan hash value: 448102010
-------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                         | Name                           | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers |
-------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                  |                                |      1 |        |    21 (100)|      0 |00:00:05.74 |     659K|
|   1 |  SORT ORDER BY                    |                                |      1 |    121 |    21  (24)|      0 |00:00:05.74 |     659K|
|*  2 |   HASH JOIN                       |                                |      1 |    121 |    20  (20)|      0 |00:00:05.74 |     659K|
|*  3 |    INDEX SKIP SCAN                | G_DOSSIER_RL_CD_RD_RF_IDX      |      1 |    150 |     2   (0)|      0 |00:00:05.74 |     659K|
|   4 |    VIEW                           |                                |      0 |  12112 |    18  (23)|      0 |00:00:00.01 |       0 |
|   5 |     SORT UNIQUE                   |                                |      0 |  12112 |    18  (23)|      0 |00:00:00.01 |       0 |
|   6 |      UNION-ALL                    |                                |      0 |        |            |      0 |00:00:00.01 |       0 |
|*  7 |       HASH JOIN                   |                                |      0 |  22987 |    10   (0)|      0 |00:00:00.01 |       0 |
|   8 |        INDEX FULL SCAN            | G_VENDOSSLIMIT$REFDOSS_LIMITID |      0 |  14939 |     1   (0)|      0 |00:00:00.01 |       0 |
|*  9 |        INDEX SKIP SCAN            | GVFL_CONSUMED_IDX              |      0 |  20033 |     9   (0)|      0 |00:00:00.01 |       0 |
|  10 |       NESTED LOOPS                |                                |      0 |     46 |     4   (0)|      0 |00:00:00.01 |       0 |
|  11 |        NESTED LOOPS               |                                |      0 |     69 |     4   (0)|      0 |00:00:00.01 |       0 |
|  12 |         TABLE ACCESS FULL         | T_COLLATERAL_CASES             |      0 |     69 |     3   (0)|      0 |00:00:00.01 |       0 |
|* 13 |         INDEX UNIQUE SCAN         | PK_T_COLLATERAL                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 14 |        TABLE ACCESS BY INDEX ROWID| T_COLLATERAL                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
-------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   2 - access("DOS"."REFDOSS"="GT"."REFDOSS")
   3 - access("DOS"."REFFACTOR"='INT00000')
       filter(("EOM_MANAGER"."ISEOM"("DOS"."REFFACTOR",TO_DATE(' 2024-05-08 00:00:00', 'syyyy-mm-dd hh24:mi:ss'))=0 AND
              "DOS"."REFFACTOR"='INT00000'))
   7 - access("VD"."LIMIT_ID"="VF"."LIMIT_ID")
   9 - access("VF"."LIMIT_ROLE"='COVERAGE' AND "VF"."CONSUMED_LIM">0)
       filter(("VF"."LIMIT_ROLE"='COVERAGE' AND "VF"."CONSUMED_LIM">0))
  13 - access("GC"."IMX_COLATERAL_ID"="G"."IMX_UN_ID")
  14 - filter(("G"."DT_SIGNATURE_DT" IS NOT NULL AND ("DT_SUSPENSION_DT" IS NULL OR "DT_SUSPENSION_DT">=TO_DATE(' 2024-05-08
              00:00:00', 'syyyy-mm-dd hh24:mi:ss')) AND ("G"."DT_DUE_DT" IS NULL OR "G"."DT_DUE_DT">=TO_DATE(' 2024-05-08 00:00:00',
              'syyyy-mm-dd hh24:mi:ss'))))
  
*/
/********************************OLD Metrics***************************************/

/********************************New SQL*******************************************/

SELECT /*+ leading(gt) use_nl(dos) */
       dos.reffactor /* automatically injected */, gt.*
   FROM (SELECT DISTINCT vd.refdoss, 1
           FROM g_vendosslimit vd, 
                g_venfilimit vf
          WHERE vd.limit_id = vf.limit_id
            AND vf.limit_role = 'COVERAGE'
            AND NVL(vf.consumed_lim, 0) > 0
         UNION
         SELECT /*+ index(gc IX_IMX_COLATER_ID) */
                DISTINCT gc.refdoss, 2
           FROM t_collateral_cases gc, 
                t_collateral g
          WHERE gc.imx_colateral_id = g.imx_un_id
            AND g.dt_signature_dt IS NOT NULL
            AND (g.dt_due_dt IS NULL OR g.dt_due_dt >= to_date('08/05/2024','dd/mm/yyyy'))
            AND (dt_suspension_dt IS NULL OR dt_suspension_dt >= to_date('08/05/2024','dd/mm/yyyy'))) gt,
         g_dossier dos
  WHERE dos.refdoss =  gt.refdoss
    AND eom_manager.isEOM( dos.reffactor, to_date('08/05/2024','dd/mm/yyyy')  ) = 0
    /* reffactor condition */
   AND dos.reffactor IN ('INT00000')
  ORDER BY 2;
/********************************New SQL*******************************************/
/********************************New Metrics***************************************/
/*
Plan hash value: 3867165862
-----------------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                   | Name                           | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers |
-----------------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                            |                                |      1 |        |    35 (100)|      0 |00:00:00.15 |   15118 |
|   1 |  SORT ORDER BY                              |                                |      1 |     19 |    35  (12)|      0 |00:00:00.15 |   15118 |
|   2 |   NESTED LOOPS                              |                                |      1 |     19 |    34   (9)|      0 |00:00:00.15 |   15118 |
|   3 |    NESTED LOOPS                             |                                |      1 |   1877 |    34   (9)|    290 |00:00:00.03 |    1201 |
|   4 |     VIEW                                    |                                |      1 |   1877 |    15  (20)|    290 |00:00:00.03 |    1079 |
|   5 |      SORT UNIQUE                            |                                |      1 |   1877 |    15  (20)|    290 |00:00:00.03 |    1079 |
|   6 |       UNION-ALL                             |                                |      1 |        |            |   4213 |00:00:00.02 |    1079 |
|*  7 |        HASH JOIN                            |                                |      1 |   1847 |    10   (0)|   4164 |00:00:00.02 |     982 |
|*  8 |         INDEX SKIP SCAN                     | GVFL_CONSUMED_IDX              |      1 |   1610 |     9   (0)|   1610 |00:00:00.01 |     909 |
|   9 |         INDEX FULL SCAN                     | G_VENDOSSLIMIT$REFDOSS_LIMITID |      1 |  14939 |     1   (0)|  14947 |00:00:00.01 |      73 |
|  10 |        NESTED LOOPS                         |                                |      1 |     46 |     2   (0)|     49 |00:00:00.01 |      97 |
|  11 |         NESTED LOOPS                        |                                |      1 |     69 |     2   (0)|     69 |00:00:00.01 |      51 |
|  12 |          TABLE ACCESS BY INDEX ROWID BATCHED| T_COLLATERAL_CASES             |      1 |     69 |     1   (0)|     69 |00:00:00.01 |      47 |
|  13 |           INDEX FULL SCAN                   | IX_IMX_COLATER_ID              |      1 |     69 |     1   (0)|     69 |00:00:00.01 |       1 |
|* 14 |          INDEX UNIQUE SCAN                  | PK_T_COLLATERAL                |     69 |      1 |     1   (0)|     69 |00:00:00.01 |       4 |
|* 15 |         TABLE ACCESS BY INDEX ROWID         | T_COLLATERAL                   |     69 |      1 |     1   (0)|     49 |00:00:00.01 |      46 |
|* 16 |     INDEX UNIQUE SCAN                       | DOS_REFDOSS                    |    290 |      1 |     1   (0)|    290 |00:00:00.01 |     122 |
|* 17 |    TABLE ACCESS BY INDEX ROWID              | G_DOSSIER                      |    290 |      1 |     1   (0)|      0 |00:00:00.12 |   13917 |
-----------------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   7 - access("VD"."LIMIT_ID"="VF"."LIMIT_ID")
   8 - access("VF"."LIMIT_ROLE"='COVERAGE' AND "VF"."CONSUMED_LIM">0)
       filter(("VF"."LIMIT_ROLE"='COVERAGE' AND "VF"."CONSUMED_LIM">0))
  14 - access("GC"."IMX_COLATERAL_ID"="G"."IMX_UN_ID")
  15 - filter(("G"."DT_SIGNATURE_DT" IS NOT NULL AND ("DT_SUSPENSION_DT" IS NULL OR "DT_SUSPENSION_DT">=TO_DATE(' 2024-05-08 00:00:00',
              'syyyy-mm-dd hh24:mi:ss')) AND ("G"."DT_DUE_DT" IS NULL OR "G"."DT_DUE_DT">=TO_DATE(' 2024-05-08 00:00:00', 'syyyy-mm-dd hh24:mi:ss'))))
  16 - access("DOS"."REFDOSS"="GT"."REFDOSS")
  17 - filter(("EOM_MANAGER"."ISEOM"("DOS"."REFFACTOR",TO_DATE(' 2024-05-08 00:00:00', 'syyyy-mm-dd hh24:mi:ss'))=0 AND
              "DOS"."REFFACTOR"='INT00000'))
*/
/********************************New Metrics***************************************/

/********************************Index statistics**********************************/

/********************************Other SQLs****************************************/          
/*

*/ 
/********************************Other SQLs****************************************/              
