#### How to recover accidentally removed Oracle DB datafile on OS level ####

Здравейте,

следващите редове може да са познати неща за някои от вас, но за мен беше за първи път. Все пак да споделя.
На една база някой, някога, по неясна причина, беше създал datafile в директорията, където се правят дъмпове, в случая /oracle/export/*, a не в */data където обикновено очакваме да ги видим и където им е мястото. И беше направил линк към /oracle/export/* на файла. И понеже бях почнал да разчиствам, гледам някакъв .dbf седи между всичките стари дъмпове на схеми, таблици и кво ли не. Проверих в базата, гледам истинския файл си сочи към */data и въобще не се усещам, че гледам линк към друго място и съвсем спокойно изтривам файла от /oracle/export/*. Ако не трябваше да правя експорт на базата, който изгърмя заради липсващ файл, вероятно нямаше да разбера какво съм сътворил, защото базата си продължи да работи. Лека паника. И обратно към възстановяването. Реших да видя дали има опция през OS директно, преди да минавам през RMAN-а. Оказа се, че има. 

Проверих бекграунд процесите на db writer-a:

ps -ef |grep dbw

oracle    1656     1  0  2019 ?        00:14:57 ora_dbw0_cast
oracle    1660     1  0  2019 ?        00:14:41 ora_dbw1_cast
oracle    3261     1  0  2019 ?        00:15:52 ora_dbw0_castest
oracle    3265     1  0  2019 ?        00:16:30 ora_dbw1_castest
oracle    9630  2705  0 17:27 pts/0    00:00:00 grep dbw
oracle   26225     1  0  2019 ?        00:14:51 ora_dbw0_or02
oracle   26229     1  0  2019 ?        00:14:47 ora_dbw1_or02
oracle   31811     1  0 Feb13 ?        00:02:50 ora_dbw0_casdev
oracle   31815     1  0 Feb13 ?        00:02:48 ora_dbw1_casdev
oracle   32243     1  0  2019 ?        00:17:27 ora_dbw0_case
oracle   32265     1  0  2019 ?        00:17:11 ora_dbw1_case

В случаят моя PID беше 1656.

/usr/sbin/lsof -p 1656

dr-xr-xr-x 8 oracle oinstall  0 Jun 15  2019 ..
dr-x------ 2 oracle oinstall  0 Jun 15  2019 .
lrwx------ 1 oracle oinstall 64 Apr  1 16:43 9 -> /oracle/cast/app/product/11.2.0.4/dbs/hc_cast.dat
lr-x------ 1 oracle oinstall 64 Apr  1 16:43 8 -> /dev/zero
lr-x------ 1 oracle oinstall 64 Apr  1 16:43 7 -> /proc/1656/fd
lr-x------ 1 oracle oinstall 64 Apr  1 16:43 6 -> /oracle/cast/app/product/11.2.0.4/rdbms/mesg/oraus.msb
lr-x------ 1 oracle oinstall 64 Apr  1 16:43 5 -> /dev/null
lr-x------ 1 oracle oinstall 64 Apr  1 16:43 4 -> /dev/null
lr-x------ 1 oracle oinstall 64 Apr  1 16:43 3 -> /dev/null
lrwx------ 1 oracle oinstall 64 Apr  1 16:43 270 -> /oracle/cast/data1/temp01.dbf
lrwx------ 1 oracle oinstall 64 Apr  1 16:43 269 -> /oracle/cast/data2/rbs.dbf
lrwx------ 1 oracle oinstall 64 Apr  1 16:43 268 -> /oracle/export/cast/mmdat02.dbf (deleted)
lrwx------ 1 oracle oinstall 64 Apr  1 16:43 267 -> /oracle/cast/data1/mmdat01.dbf
lrwx------ 1 oracle oinstall 64 Apr  1 16:43 266 -> /oracle/cast/data1/mmidx01
lrwx------ 1 oracle oinstall 64 Apr  1 16:43 265 -> /oracle/cast/data1/mmseldat01
lrwx------ 1 oracle oinstall 64 Apr  1 16:43 264 -> /oracle/cast/data1/mmselidx01
lrwx------ 1 oracle oinstall 64 Apr  1 16:43 263 -> /oracle/cast/data1/perfstat01.dbf
lrwx------ 1 oracle oinstall 64 Apr  1 16:43 262 -> /oracle/cast/data1/wd01.ora
lrwx------ 1 oracle oinstall 64 Apr  1 16:43 261 -> /oracle/cast/data1/users01.dbf
lrwx------ 1 oracle oinstall 64 Apr  1 16:43 260 -> /oracle/cast/data1/undotbs01.dbf
lrwx------ 1 oracle oinstall 64 Apr  1 16:43 259 -> /oracle/cast/data1/sysaux01.dbf
lrwx------ 1 oracle oinstall 64 Apr  1 16:43 258 -> /oracle/cast/data1/system01.dbf
lrwx------ 1 oracle oinstall 64 Apr  1 16:43 257 -> /oracle/cast/data2/control02.ctl
lrwx------ 1 oracle oinstall 64 Apr  1 16:43 256 -> /oracle/cast/data1/control01.ctl
l-wx------ 1 oracle oinstall 64 Apr  1 16:43 2 -> /dev/null
lr-x------ 1 oracle oinstall 64 Apr  1 16:43 11 -> /oracle/cast/app/product/11.2.0.4/rdbms/mesg/oraus.msb
lrwx------ 1 oracle oinstall 64 Apr  1 16:43 10 -> /oracle/cast/app/product/11.2.0.4/dbs/lkCAST
l-wx------ 1 oracle oinstall 64 Apr  1 16:43 1 -> /dev/null
lr-x------ 1 oracle oinstall 64 Apr  1 16:43 0 -> /dev/null
lrwx------ 1 oracle oinstall 64 Apr  1 17:15 12 -> socket:[764116458]

ls -ltar /proc/1656/fd/

total 0
dr-xr-xr-x 8 oracle oinstall  0 Jun 15  2019 ..
dr-x------ 2 oracle oinstall  0 Jun 15  2019 .
lrwx------ 1 oracle oinstall 64 Apr  1 16:43 9 -> /oracle/cast/app/product/11.2.0.4/dbs/hc_cast.dat
lr-x------ 1 oracle oinstall 64 Apr  1 16:43 8 -> /dev/zero
lr-x------ 1 oracle oinstall 64 Apr  1 16:43 7 -> /proc/1656/fd
lr-x------ 1 oracle oinstall 64 Apr  1 16:43 6 -> /oracle/cast/app/product/11.2.0.4/rdbms/mesg/oraus.msb
lr-x------ 1 oracle oinstall 64 Apr  1 16:43 5 -> /dev/null
lr-x------ 1 oracle oinstall 64 Apr  1 16:43 4 -> /dev/null
lr-x------ 1 oracle oinstall 64 Apr  1 16:43 3 -> /dev/null
lrwx------ 1 oracle oinstall 64 Apr  1 16:43 270 -> /oracle/cast/data1/temp01.dbf
lrwx------ 1 oracle oinstall 64 Apr  1 16:43 269 -> /oracle/cast/data2/rbs.dbf
lrwx------ 1 oracle oinstall 64 Apr  1 16:43 268 -> /oracle/export/cast/mmdat02.dbf (deleted)
lrwx------ 1 oracle oinstall 64 Apr  1 16:43 267 -> /oracle/cast/data1/mmdat01.dbf
lrwx------ 1 oracle oinstall 64 Apr  1 16:43 266 -> /oracle/cast/data1/mmidx01
lrwx------ 1 oracle oinstall 64 Apr  1 16:43 265 -> /oracle/cast/data1/mmseldat01
lrwx------ 1 oracle oinstall 64 Apr  1 16:43 264 -> /oracle/cast/data1/mmselidx01
lrwx------ 1 oracle oinstall 64 Apr  1 16:43 263 -> /oracle/cast/data1/perfstat01.dbf
lrwx------ 1 oracle oinstall 64 Apr  1 16:43 262 -> /oracle/cast/data1/wd01.ora
lrwx------ 1 oracle oinstall 64 Apr  1 16:43 261 -> /oracle/cast/data1/users01.dbf
lrwx------ 1 oracle oinstall 64 Apr  1 16:43 260 -> /oracle/cast/data1/undotbs01.dbf
lrwx------ 1 oracle oinstall 64 Apr  1 16:43 259 -> /oracle/cast/data1/sysaux01.dbf
lrwx------ 1 oracle oinstall 64 Apr  1 16:43 258 -> /oracle/cast/data1/system01.dbf
lrwx------ 1 oracle oinstall 64 Apr  1 16:43 257 -> /oracle/cast/data2/control02.ctl
lrwx------ 1 oracle oinstall 64 Apr  1 16:43 256 -> /oracle/cast/data1/control01.ctl
l-wx------ 1 oracle oinstall 64 Apr  1 16:43 2 -> /dev/null
lr-x------ 1 oracle oinstall 64 Apr  1 16:43 11 -> /oracle/cast/app/product/11.2.0.4/rdbms/mesg/oraus.msb
lrwx------ 1 oracle oinstall 64 Apr  1 16:43 10 -> /oracle/cast/app/product/11.2.0.4/dbs/lkCAST
l-wx------ 1 oracle oinstall 64 Apr  1 16:43 1 -> /dev/null
lr-x------ 1 oracle oinstall 64 Apr  1 16:43 0 -> /dev/null
lrwx------ 1 oracle oinstall 64 Apr  1 17:15 12 -> socket:[764116458]

Понеже беше единствен файл за тейбълспейса, не можaх да го сложа offline, а само в read only:

alter tablespace MMDAT read only;
Tablespace altered.

След това копираме file descriptor-a (268) с ново име като изтрития файл:

cp -p /proc/1656/fd/268 /oracle/export/cast/mmdat02.dbf

Вкарваме тейбълспейса в read/write:

alter tablespace MMDAT read write;
Tablespace altered.

За по-сигурно, да се убедя, че e consistant го преместих offline/online:

alter tablespace MMDAT offline;
Tablespace altered.

alter tablespace MMDAT online;
Tablespace altered.

В заключение, този метод има шанс да сработи ако се приложи веднага след изтриването на datafile-a. Спре ли базата, db writer-a oсвободи ли процеса, рестартира ли се сървъра – добрият стар RMAN само ще помогне. Възможно е все пак да се наложи recover на файла ако тейбълспейса не e consistant.
