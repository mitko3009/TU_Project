/********************************************************************************
*********       E-mail subject: SUDFWEB-2255
*********             Instance: UAT
*********          Description: 
Problem:
During the investigation in SUDFWEB-2255, Dimitare Ivanov noticed that SQL 3nf8wa1f6bvck ( from ftr_request.pcc ) can be optimized from Performance point of view.

Analysis:
We executed the query manually on UAT and as it can be seen in the execution plan in the Old Metrics section below, the query access table G_PIECE through index GP_TYPEDOC, which is on 
columns TYPEDOC and TYPPIECE. This leads to selecting over 500k rows in our case and after that filtering them. It looks like the selective predicates here are the st41 column and the gpiadr3 columns.
We changed the query to access table G_PIECE through these columns and it looks like it works better now.

Suggestion:
Please change the query as it is shown in the New SQL section below.

*********               SQL_ID: 3nf8wa1f6bvck
*********      Program/Package: ftr_request.pcc
*********              Request: Dimitare Ivanov
*********               Author: Dimitar Dimitrov
********* Received e-mail date: 24/09/2024
*********      Resolution date: 26/09/2024
*********  Trace old file here: \\epox\specifs\performance\tmp\
*********  Trace new file here:
***********************************************************************************/

/********************************OLD SQL*******************************************/

var b0 varchar2(32);
exec :b0 := '';
var b2 varchar2(32);
exec :b2 := 'INT00000';
var b3 number;
exec :b3 := 1;
var b4 varchar2(32);
exec :b4 := 'A703ZR39';
var b6 varchar2(32);
exec :b6 := 'A6013UA8';
var b7 varchar2(32);
exec :b7 := '';
var b8 varchar2(32);
exec :b8 := 'C';
var b9 varchar2(32);
exec :b9 := '2203080065';


select nvl(CH_TAUX.Conv_Orig_Dest_Tx(TO_CHAR(SYSDATE, 'j'),
                                     mt02,
                                     code,
                                     :b0,
                                     'MR',
                                     ftr_fin_factor.getCurrency(Req.gpityptrib),
                                     ftr_fin_factor.getPays(Req.gpityptrib)),
           0)
  from g_piece Req
 where nvl(typpiece, 'xxx') = 'REQUEST_LIMITE'
   and (   gpityptrib = :b2 
        or :b3 = 0 )  
   and (   libelle_100_8 = :b4 
        or :b4 is null ) 
   and nvl(gpirole, 'xxx') in ('DC', 'DT')  
   and ( (     typedoc in ('D', 'DRC', 'DBP') 
           and gpiadr3 = :b6 )
      or (      typedoc = 'DGP'
           and st41 = :b7 ) )  
   and typedoc = :b8  
   and (   typedoc in ('D', 'DBP', 'DGP')
        or refdoss = :b9 )  
   and trunc( nvl( gpidtfin_dt, (SYSDATE + 1) ) ) >= trunc(SYSDATE)  
   and fg05 = 'O';
/********************************OLD SQL*******************************************/
/********************************OLD Metrics***************************************/
/*
MODULE                           PROGRAM                                            CLIENT_ID       SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- -------------------------------------------------- --------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
msgq_ProcessLimit                                                                                                                                  ON CPU               2024/09/19 16:00:13  2024/09/19 16:59:54         385                 7405 +000000000 00:59:40.826 53%
msgq_pilote                                                                                                                                        ON CPU               2024/09/19 16:15:33  2024/09/19 16:56:24         119              3047678 +000000000 00:40:50.634 16%
msgq                                                                                                                                               ON CPU               2024/09/19 16:00:23  2024/09/19 16:59:04          38                45419 +000000000 00:58:40.835 5%
msgq_pilote                                                                                                                                        db file sequential r 2024/09/19 16:15:43  2024/09/19 16:38:03          38                20470 +000000000 00:22:20.347 5%
                                 oracle                                                                                    0       1492      38502 log file parallel wr 2024/09/19 16:00:13  2024/09/19 16:59:04          31                      +000000000 00:58:50.832 4%
                                 

MODULE                           PROGRAM                                            CLIENT_ID       SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- -------------------------------------------------- --------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
msgq_ProcessLimit                                                                                                                                  ON CPU               2024/09/19 16:00:13  2024/09/19 16:59:54         385                 7405 +000000000 00:59:40.826 99%
msgq_ProcessLimit                msg_q06                                                            4k19r0wh5bp0s          0        501      39414 db file sequential r 2024/09/19 16:26:23  2024/09/19 16:26:23           1                    1 +000000000 00:00:00.000 0%
msgq_ProcessLimit                msg_q06                                                                                   0        501      39414 log file sync        2024/09/19 16:51:43  2024/09/19 16:51:43           1                      +000000000 00:00:00.000 0%
msgq_ProcessLimit                msg_q06                                                            c9zr1v1p4gjjg  359329220        501      39414 db file parallel rea 2024/09/19 16:40:33  2024/09/19 16:40:33           1                    1 +000000000 00:00:00.000 0%


MODULE                           PROGRAM                                            CLIENT_ID       SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- -------------------------------------------------- --------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
msgq_ProcessLimit                msg_q06                                                            3nf8wa1f6bvck  331562649        501      39414 ON CPU               2024/09/19 16:00:23  2024/09/19 16:59:44         292                 1113 +000000000 00:59:20.832 75%
msgq_ProcessLimit                                                                                   81uyr2utkr2f0  230518406                       ON CPU               2024/09/19 16:00:13  2024/09/19 16:58:24          59                   76 +000000000 00:58:10.816 15%
msgq_ProcessLimit                msg_q06                                                            fcfwwhjv9mfk7 2214194569        501      39414 ON CPU               2024/09/19 16:05:23  2024/09/19 16:55:13          21                  540 +000000000 00:49:50.719 5%
msgq_ProcessLimit                msg_q06                                                                                   0        501      39414                      2024/09/19 16:22:33  2024/09/19 16:59:04           3                      +000000000 00:36:30.564 1%


INSTANCE_NUMBER SQL_ID            ELAPSED MAX_WAIT_ON     PC_OF  WAIT_TIME            GETS      READS       ROWS  ELAP/EXEC       GETS/EXEC READS/EXEC  ROWS/EXEC       EXEC PLAN_HASH_VALUE
--------------- ------------- ----------- --------------- ----- ---------- --------------- ---------- ---------- ---------- --------------- ---------- ---------- ---------- ---------------
              1 3nf8wa1f6bvck        3313 CPU             89%   1007.15089      1797151055     193456          0       2.64         1430853     154.03          0       1256       331562649


SQL_ID        SQL_PLAN_HASH_VALUE SQL_PLAN_LINE_ID SQL_PLAN_OPERATION             SQL_PLAN_OPTIONS                   ACTIVE
------------- ------------------- ---------------- ------------------------------ ------------------------------ ----------
3nf8wa1f6bvck           331562649                1 TABLE ACCESS                   BY INDEX ROWID BATCHED                282
3nf8wa1f6bvck           331562649                2 INDEX                          RANGE SCAN                             10


Plan hash value: 331562649
----------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                           | Name       | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  |
----------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                    |            |      1 |        |    32 (100)|      0 |00:00:14.33 |    1430K|  12640 |
|*  1 |  TABLE ACCESS BY INDEX ROWID BATCHED| G_PIECE    |      1 |      1 |    32   (0)|      0 |00:00:14.33 |    1430K|  12640 |
|*  2 |   INDEX RANGE SCAN                  | GP_TYPEDOC |      1 |  14988 |     1   (0)|    543K|00:00:00.39 |    4032 |    295 |
----------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   1 - filter(((:B4 IS NULL OR "LIBELLE_100_8"=:B4) AND "FG05"='O' AND (("GPIADR3"=:B6 AND INTERNAL_FUNCTION("TYPEDOC"))
              OR ("ST41"=:B7 AND "TYPEDOC"='DGP')) AND ("GPITYPTRIB"=:B2 OR :B3=0) AND (INTERNAL_FUNCTION("TYPEDOC") OR "REFDOSS"=:B9)
              AND (NVL("GPIROLE",'xxx')='DC' OR NVL("GPIROLE",'xxx')='DT') AND TRUNC(NVL("GPIDTFIN_DT",SYSDATE@!+1))>=TRUNC(SYSDATE@!)))
   2 - access("TYPEDOC"=:B8 AND "TYPPIECE"='REQUEST_LIMITE')
*/
/********************************OLD Metrics***************************************/

/********************************New SQL*******************************************/

select nvl(CH_TAUX.Conv_Orig_Dest_Tx(TO_CHAR(SYSDATE, 'j'),
                                     mt02,
                                     code,
                                     :b0,
                                     'MR',
                                     ftr_fin_factor.getCurrency(Req.gpityptrib),
                                     ftr_fin_factor.getPays(Req.gpityptrib)),
           0)
  from ( select *
           from g_piece
          where typedoc in ('D', 'DRC', 'DBP') 
            and gpiadr3 = :b6
         union
         select * 
           from g_piece
          where typedoc = 'DGP'
            and nvl(st41,null) = :b7 ) Req
 where nvl(typpiece, 'xxx') = 'REQUEST_LIMITE'
   and (   gpityptrib = :b2 
        or :b3 = 0 )  
   and (   libelle_100_8 = :b4 
        or :b4 is null ) 
   and nvl(gpirole, 'xxx') in ('DC', 'DT')   
   and typedoc = :b8  
   and (   typedoc in ('D', 'DBP', 'DGP')
        or refdoss = :b9 )  
   and trunc( nvl( gpidtfin_dt, (SYSDATE + 1) ) ) >= trunc(SYSDATE)  
   and fg05 = 'O';
/********************************New SQL*******************************************/
/********************************New Metrics***************************************/
/*
Plan hash value: 2826607602
--------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                               | Name              | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   |
--------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                        |                   |      1 |        |     2 (100)|      0 |00:00:00.01 |
|   1 |  VIEW                                   |                   |      1 |      2 |     2   (0)|      0 |00:00:00.01 |
|   2 |   SORT UNIQUE                           |                   |      1 |      2 |     2   (0)|      0 |00:00:00.01 |
|   3 |    UNION-ALL                            |                   |      1 |        |            |      0 |00:00:00.01 |
|*  4 |     FILTER                              |                   |      1 |        |            |      0 |00:00:00.01 |
|*  5 |      TABLE ACCESS BY INDEX ROWID BATCHED| G_PIECE           |      0 |      1 |     1   (0)|      0 |00:00:00.01 |
|*  6 |       INDEX RANGE SCAN                  | G_PIECE$ADR3      |      0 |    178 |     1   (0)|      0 |00:00:00.01 |
|*  7 |     FILTER                              |                   |      1 |        |            |      0 |00:00:00.01 |
|*  8 |      TABLE ACCESS BY INDEX ROWID BATCHED| G_PIECE           |      0 |      1 |     1   (0)|      0 |00:00:00.01 |
|*  9 |       INDEX RANGE SCAN                  | PIE_ST41_FUNC_IDX |      0 |      1 |     1   (0)|      0 |00:00:00.01 |
--------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   4 - filter((:B8='D' OR :B8='DBP' OR :B8='DRC'))
   5 - filter(("G_PIECE"."TYPPIECE"='REQUEST_LIMITE' AND "G_PIECE"."TYPEDOC"=:B8 AND (:B4 IS NULL OR
              "G_PIECE"."LIBELLE_100_8"=:B4) AND "G_PIECE"."FG05"='O' AND ("G_PIECE"."GPITYPTRIB"=:B2 OR :B3=0) AND
              (INTERNAL_FUNCTION("G_PIECE"."TYPEDOC") OR "G_PIECE"."REFDOSS"=:B9) AND INTERNAL_FUNCTION("TYPEDOC") AND
              (NVL("G_PIECE"."GPIROLE",'xxx')='DC' OR NVL("G_PIECE"."GPIROLE",'xxx')='DT') AND
              TRUNC(NVL("G_PIECE"."GPIDTFIN_DT",SYSDATE@!+1))>=TRUNC(SYSDATE@!)))
   6 - access("GPIADR3"=:B6)
   7 - filter(:B8='DGP')
   8 - filter(("G_PIECE"."TYPPIECE"='REQUEST_LIMITE' AND "TYPEDOC"='DGP' AND (:B4 IS NULL OR
              "G_PIECE"."LIBELLE_100_8"=:B4) AND "G_PIECE"."FG05"='O' AND ("G_PIECE"."GPITYPTRIB"=:B2 OR :B3=0) AND
              (NVL("G_PIECE"."GPIROLE",'xxx')='DC' OR NVL("G_PIECE"."GPIROLE",'xxx')='DT') AND
              TRUNC(NVL("G_PIECE"."GPIDTFIN_DT",SYSDATE@!+1))>=TRUNC(SYSDATE@!)))
   9 - access("G_PIECE"."SYS_NC00768$"=:B7)
*/
/********************************New Metrics***************************************/

/********************************Index statistics**********************************/

/********************************Other SQLs****************************************/          
/*

*/ 
/********************************Other SQLs****************************************/              
