=======================================================================================================================================
                                      ######## DATA GARD #########
Дейта гард е решение на Oracle за хайавелабилити и е на ниво database. Има два сървъка (primary и secondary),които са конфигурирани да имат връзка помежду си,за да Се apply-ва на secondary-to.
Secondary базата е на standby и е в mount state,на нея се прехвърля информация от primary-то така,че да има синхронизация на две места и в случай,че primary-То падне secondary-то става primary.
От версия 11.0.2 май secondary-то е в стейд "read only",което осзначава също,че може да се ползва за статистийи и вадене на информация и така да не се натоварва primary-to.

========================================================================================================================================
                                     ######## SERVICE GARD #########
Service Gard е решение на HP за HP/UX и е на ниво процеси и редънданси.Тук нодовете се казват "prefered node и secondary node". Процесите са разпределени да вървят на двата нода за по добър перформанс,
но единия нод,ако падне процесите се прехвърлят автоматично на другия и той поема цялата работа.

==========================================================================================================================================
                                       ######## DATABASE ##########
Database това са файлове,таблици. Презентира сториджа.Базата се състои от три основни файла:
 - Data files - съдържат основно файловете.
 - Control files - съдържа информация за това как се казват файловете и къде се намират.Мета данни.
 - Redo log files - Когато се правят промени в data-та се запазват в redo.log. Redo log files съдържат всички промени в базата.
 
 PASSWORD - user who can start the database - (sysdba)
 Parameter file - Текстови файл . 
 SPfiles (server pfile)- it's a binary files 
 PFILE and SPFILE - Използва се да стартира базата. Използва се да изгради инстанса с конфигурацията,която има в pfile или spfile.
 
 =========================================================================================================================================
                                          ####### DATABASE FILES ##########
Data files - Datafiles са записани върху блоковете (size of blocks) Database created as part of Tablespaces.
 - DATA
 - Block size (must be specify when the database create)
 - system (dictionary)
 - user data file
 - UNDO (contains old values of DML,to enable Rollback of transactions) Part of undo tablespace
 - temp files (work area to perform sort or join )

Control files
 - Stucture of database

Redo log files - Only change is written which is much smaller than a block
 - Changes ( chronological log of changes made in database )
 - Chronological
 - It's used to do recovery,if it crash of the server or if it lost a datafile
 - performance 
 
 ==========================================================================================================================================
                                         ######### INSTANCE ########
Виртуална мемори структора и процеси.Достъпна е за всички юзъри,които се кънектват към базата.Състои се от 5 основни части:

 - Shared pool 
   - Librery cache - ALL SQL query executables .They are SQL and PLSQL. SQL executables се пазят тук.SQL идват от юзърските сесии.Пазят се в Librery cache като се нарича SQL area.
   Ако друг използва същата команда,тя се екзекютва директно от librery cache-a.
   - Data Dictionary cache - system metadata . Чете инфо от Data files, вкарва SQL query-то я в librery cache-a и се изпълнява.
  
 - Buffer cache - Всяко SQL query трябва да го извадим от дейта файловете и отива в Buffer cache-a,Където се случват процесите. Query SQL,съдържа дата от вашите дейта  файлове.
   Блоковете се наричат data files и когато се копират в меморито почваме да ги наричаме "buffer".
 
 - Redo log buffer - Всяка промяна в базата(от buffer cache-a) и ентритата отиват в redo log buffer-a.и след това LGWR ги записва в "Redo log files"
 
 - Large pool - It'a specific purposes.It's comming to use
   - shared server processes
   -RMAN (backups)
   -
 
 - Java pool
 
 =========================================================================================================================================
                                    ############# PROCESSES ################
 
 SMON - System monitor . Главно помага в случай,че трябва да се прави recovery
 
 PMON - Process monitor. Грижи се процесите да работят правилно.
 
 DBWR - Отговорен да пише в data files от Buffer cache,това се нарича dirty buffer.
 
 CKPT - Синхронизира "Redo log" и "Data files".
 
 LGWR - Отговорен да пише в "Redo log files" от "Redo log buffer".
 
 ==============================================================================================================================================
 
 .aud files  -  това са кънекции към базата
 .trc files  -  грешки използвани от oracle
 .trm files  -  мета данни
 
 ===============================================================================================================================================
 ############# PERFORMANCE DEGRADATION ################
 
 performance degradation  -  Е КОГАТО ЕДИН ИЛИ ПОВЕЧЕ ИНСТАНСА СА БИЛИ ДОЛУ
 
 service interaption   -  Е КОГАТО НЯМА Я БАЗАТА.ДОЛУ Е НАПЪЛНО !
 
 ==============================================================================================================================================
 ===========================================================================================================================================
 
 
 
 
 
 
 
 
 
 
 
 
 
 https://www.youtube.com/watch?v=EqYB7mp_U3I&list=PL3Hc8S1SG2AQnk6Nu57m2JLkWxorMAsmE    ###### YOUTUBE indiec #########
 