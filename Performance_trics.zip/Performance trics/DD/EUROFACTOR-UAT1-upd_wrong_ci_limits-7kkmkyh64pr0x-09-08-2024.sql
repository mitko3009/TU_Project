/********************************************************************************
*********       E-mail subject: EFAGDEV-3457
*********             Instance: UAT1
*********          Description: 
Problem:
The upd_wrong_ci_limits took 20 minutes on UAT1.

Analysis:
After the analyze, we found that the TOP SQL in module upd_wrong_ci_limits, which was responsible for 100% of the time was 7kkmkyh64pr0x.
The main problem of this query is that we access table G_PIECE once for the 'PARAM_LIMITE' and once for the 'REQUEST_LIMITE'. The solution that we can propose 
here is to access table G_PIECE only once and take all 'PARAM_LIMITE' and 'REQUEST_LIMITE', store them in temporary view and than use the temporary view instead of the table, 
which based on the tests that we made is faster.

Suggestion:
Please change the query as it is shown in the New SQL section below.

*********               SQL_ID: 7kkmkyh64pr0x
*********      Program/Package: 
*********              Request: Siyana Nikolova 
*********               Author: Dimitar Dimitrov
********* Received e-mail date: 08/08/2024
*********      Resolution date: 09/08/2024
*********  Trace old file here: \\epox\specifs\performance\tmp\
*********  Trace new file here:
***********************************************************************************/

/********************************OLD SQL*******************************************/

INSERT INTO T_REPRISE_LIST ( CLIENT, DTCREATION_DT, CREATEUR, REFCL )
  WITH DOS AS ( SELECT DOS.REFDOSS, 
                       DOS.ANCREFDOSS AS CONTRACT_NO
                  FROM G_DOSSIER DOS,
                       T_INTERVENANTS CL,
                       G_PIECE CONTR,
                       G_INDIVIDU BU,
                       ( SELECT MAX(IMX_UN_ID) ID, 
                                REFPIECE
                           FROM G_PIECEDET
                          WHERE TYPE = 'CONTRACT SITUATIONS'
                          GROUP BY REFPIECE ) CONTR_SIT,
                          G_PIECEDET CONTR_SIT1
                 WHERE CONTR.TYPPIECE IN ('CONTRAT', 'CONTRAT REV')
                   AND CONTR.REFDOSS = DOS.REFDOSS
                   AND CONTR_SIT.REFPIECE = CONTR.REFPIECE
                   AND ( (     CONTR_SIT1.STR1 = 'C' 
                           AND DOS.CATEGDOSS = 'CONTRAT IMP PROSPET' 
                           AND TO_CHAR(CONTR_SIT1.DT01_DT, 'YYYYMMDD') >= '20220101'
                         ) 
                      OR (     CONTR_SIT1.STR1 IN ('E', 'I', 'N', 'O', 'P', 'R', 'S', 'V') 
                           AND DOS.CATEGDOSS != 'CONTRAT IMP PROSPET' ) 
                       )
                   AND CONTR_SIT1.IMX_UN_ID = CONTR_SIT.ID
                   AND CL.REFDOSS = CONTR.REFDOSS
                   AND CL.REFTYPE = 'CL'
                   AND BU.REFINDIVIDU = DOS.REFFACTOR),
       CANC AS ( SELECT CONTR.ANCREFDOSS ANCREFDOSS, 
                        CLDB.REFDOSS REFDOSS
                   FROM G_DOSSIER CLDB, 
                        G_DOSSIER DECOM, 
                        G_DOSSIER CONTR, 
                        DOS
                  WHERE CLDB.CATEGDOSS IN ('COMPTE', 'COMPTE IMP', 'COMPTE EXP')
                    AND DECOM.REFDOSS = CLDB.REFLOT
                    AND CONTR.REFDOSS = DECOM.REFLOT
                    AND DOS.CONTRACT_NO = CONTR.ANCREFDOSS ),
PARAM_LIMITE AS ( SELECT /*+ no_merge no_push_pred materialize full(p) parallel(p 4) */
                        P.REFPIECE,
                        P.GPIDEPOT,
                        P.GPIDEVIS,
                        P.FG01,
                        P.REFEXT,
                        P.GPIBUREAU,
                        P.GPIMARQUE,
                        P.STR_20_1,
                        P.TYPPIECE
                  FROM G_PIECE P
                 WHERE P.TYPPIECE = 'PARAM_LIMITE' )
  SELECT /*+ leading(p req md)  */
          'EFDE2WEB-761',
           SYSDATE, 
           'upd_wrong_ci_limits.sql', 
           REQ.REFPIECE
    FROM PARAM_LIMITE P,
         G_PIECEDET   D,
         G_PIECE      POL,
         G_PIECE      REQ,
         G_PIECEDET   CF_PROP,
         T_INDIVIDU   BU,
         DOS          MD,
         CANC
   WHERE P.TYPPIECE = 'PARAM_LIMITE'
     AND REQ.TYPPIECE = 'REQUEST_LIMITE'
     AND REQ.GPIHEURE = CANC.ANCREFDOSS(+)
     AND REQ.REFDOSS = CANC.REFDOSS(+)
     AND (  REQ.GPIHEURE IS NULL 
     	    OR (  REQ.GPIHEURE = CANC.ANCREFDOSS 
     	      AND REQ.REFDOSS = CANC.REFDOSS ) )
     AND P.STR_20_1 = REQ.REFPIECE
     AND D.REFPIECE = P.REFPIECE
     AND D.TYPE = 'DETAIL_LIMITE'
     AND NVL(P.FG01, 'N') = 'N'
     AND NVL(REQ.FG05, 'N') = 'O'
     AND POL.REFPIECE(+) = REQ.LIBELLE_100_8
     AND POL.TYPPIECE(+) = 'POLICE'
     AND BU.REFINDIVIDU(+) = REQ.GPITYPTRIB
     AND BU.SOCIETE(+) = 'FACTOR_ID'
     AND MD.CONTRACT_NO(+) = REQ.GPIHEURE
     AND ( MD.CONTRACT_NO = REQ.GPIHEURE 
        OR REQ.GPIHEURE IS NULL )
     AND (P.GPIDEPOT, P.REFEXT) IN (('FIN', 'COM'), ('C', 'COM'), ('CI', 'DB'))
     AND CF_PROP.REFPIECE(+) = REQ.REFPIECE
     AND CF_PROP.TYPE(+) = 'REQUEST_CF_PROPOSAL'
     AND ( (     P.GPIDEPOT = 'FIN' 
             AND P.REFEXT = 'COM' 
             AND P.GPIBUREAU IS NOT NULL 
             AND P.GPIMARQUE IS NOT NULL 
             AND REQ.GPIHEURE IS NOT NULL ) 
         OR (    P.GPIDEPOT = 'C'
             AND P.REFEXT = 'COM' 
             AND P.GPIBUREAU IS NOT NULL 
             AND P.GPIMARQUE IS NOT NULL
             AND REQ.GPIHEURE IS NOT NULL ) 
         OR (    P.GPIDEPOT = 'CI' 
             AND P.REFEXT = 'DB'
             AND P.GPIMARQUE IS NOT NULL 
             AND POL.REFEXT IS NOT NULL ) )
     AND P.GPIDEVIS IS NULL
  UNION ALL
  SELECT 'EFDE2WEB-761', 
         SYSDATE, 
         'upd_wrong_ci_limits.sql', 
         REQ.REFPIECE
    FROM G_PIECE    POL,
         G_PIECE    REQ,
         G_PIECEDET GD,
         G_PIECE    GP,
         G_PIECE    POL1,
         T_INDIVIDU BU,
         DOS        MD,
         CANC
   WHERE REQ.TYPPIECE = 'REQUEST_LIMITE'
     AND NVL(REQ.FG05, 'N') = 'O'
     AND NVL(REQ.GPIDTFIN_DT, TRUNC(SYSDATE)) >= TRUNC(SYSDATE)
     AND REQ.GPIHEURE = CANC.ANCREFDOSS(+)
     AND REQ.REFDOSS = CANC.REFDOSS(+)
     AND ( REQ.GPIHEURE IS NULL 
     	  OR (    REQ.GPIHEURE = CANC.ANCREFDOSS 
     	      AND REQ.REFDOSS = CANC.REFDOSS ) )
     AND POL.REFPIECE(+) = REQ.LIBELLE_100_8
     AND POL.TYPPIECE(+) = 'POLICE'
     AND REQ.TYPEDOC IN ('O', 'G')
     AND GP.TYPPIECE = 'FACTOR'
     AND GP.GPIHEURE = REQ.GPITYPTRIB
     AND GP.REFPIECE = GD.REFPIECE(+)
     AND GD.TYPE(+) = 'POLICIES'
     AND GD.NB01(+) = '1'
     AND POL1.REFPIECE(+) = GD.STR1
     AND POL1.TYPPIECE(+) = 'POLICE'
     AND BU.REFINDIVIDU(+) = REQ.GPITYPTRIB
     AND BU.SOCIETE(+) = 'FACTOR_ID'
     AND MD.CONTRACT_NO(+) = REQ.GPIHEURE
     AND ( MD.CONTRACT_NO = REQ.GPIHEURE 
        OR REQ.GPIHEURE IS NULL )
     AND REQ.GPIDEVIS IS NULL;
/********************************OLD SQL*******************************************/
/********************************OLD Metrics***************************************/
/*
MODULE                           PROGRAM                                            SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- -------------------------------------------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
SQL Developer                    SQL Developer                                      9g86bt18tsfz1  371014305                       read by other sessio 2024/08/08 15:40:00  2024/08/08 16:09:58        1593                    2 +000000000 00:29:57.046 31%
SQL Developer                    SQL Developer                                      9g86bt18tsfz1  371014305                       db file sequential r 2024/08/08 15:40:00  2024/08/08 16:09:59        1579                    2 +000000000 00:29:58.046 31%
upd_wrong_ci_limits                                                                 7kkmkyh64pr0x 3023427841                       db file sequential r 2024/08/08 15:45:39  2024/08/08 16:04:31         899                    1 +000000000 00:18:52.584 17%
SQL Developer                    SQL Developer                                      9g86bt18tsfz1  371014305                       ON CPU               2024/08/08 15:40:02  2024/08/08 16:09:59         398                    2 +000000000 00:29:56.035 8%
upd_wrong_ci_limits                                                                 7kkmkyh64pr0x 3023427841                       ON CPU               2024/08/08 15:45:31  2024/08/08 16:04:25         218                    1 +000000000 00:18:54.594 4%
upd_wrong_ci_limits                                                                 7kkmkyh64pr0x 3023427841                       db file parallel rea 2024/08/08 15:45:51  2024/08/08 15:50:52          80                    1 +000000000 00:05:01.119 2%


MODULE                           PROGRAM                                            SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- -------------------------------------------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
upd_wrong_ci_limits                                                                 7kkmkyh64pr0x 3023427841                       db file sequential r 2024/08/08 15:45:39  2024/08/08 16:04:31         899                    1 +000000000 00:18:52.584 70%
upd_wrong_ci_limits                                                                 7kkmkyh64pr0x 3023427841                       ON CPU               2024/08/08 15:45:31  2024/08/08 16:04:25         218                    1 +000000000 00:18:54.594 17%
upd_wrong_ci_limits                                                                 7kkmkyh64pr0x 3023427841                       db file parallel rea 2024/08/08 15:45:51  2024/08/08 15:50:52          80                    1 +000000000 00:05:01.119 6%
upd_wrong_ci_limits                                                                 7kkmkyh64pr0x 3023427841                       direct path read     2024/08/08 15:47:00  2024/08/08 15:47:42          64                    1 +000000000 00:00:42.024 5%
upd_wrong_ci_limits              oracle                                             7kkmkyh64pr0x 3023427841       1445      12943 db file scattered re 2024/08/08 15:48:04  2024/08/08 15:50:37          15                    1 +000000000 00:02:33.050 1%
upd_wrong_ci_limits                                                                 7kkmkyh64pr0x 3023427841                       direct path read tem 2024/08/08 15:47:44  2024/08/08 15:47:44           2                    1 +000000000 00:00:00.000 0%
upd_wrong_ci_limits              oracle                                             7kkmkyh64pr0x 3023427841       1445      12943 read by other sessio 2024/08/08 15:48:36  2024/08/08 15:48:36           1                    1 +000000000 00:00:00.000 0%




MODULE                           PROGRAM                                            SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- -------------------------------------------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
upd_wrong_ci_limits              sqlplus                                            7kkmkyh64pr0x 3023427841         53       7360                      2024/08/08 15:45:31  2024/08/08 16:04:31         908                    1 +000000000 00:19:00.595 71%
upd_wrong_ci_limits              oracle                                             7kkmkyh64pr0x 3023427841       1445      12943                      2024/08/08 15:47:45  2024/08/08 15:50:52         188                    1 +000000000 00:03:07.078 15%
upd_wrong_ci_limits              oracle                                             7kkmkyh64pr0x 3023427841        582      21368                      2024/08/08 15:47:00  2024/08/08 15:47:43          44                    1 +000000000 00:00:43.024 3%
upd_wrong_ci_limits              oracle                                             7kkmkyh64pr0x 3023427841        245      53115                      2024/08/08 15:47:00  2024/08/08 15:47:43          44                    1 +000000000 00:00:43.024 3%
upd_wrong_ci_limits              oracle                                             7kkmkyh64pr0x 3023427841        630      43434                      2024/08/08 15:47:00  2024/08/08 15:47:43          44                    1 +000000000 00:00:43.024 3%
upd_wrong_ci_limits              oracle                                             7kkmkyh64pr0x 3023427841        674      26610                      2024/08/08 15:47:00  2024/08/08 15:47:43          44                    1 +000000000 00:00:43.024 3%
upd_wrong_ci_limits              oracle                                             7kkmkyh64pr0x 3023427841        630      13144 ON CPU               2024/08/08 15:47:44  2024/08/08 15:49:53           3                    1 +000000000 00:02:09.042 0%
upd_wrong_ci_limits              oracle                                             7kkmkyh64pr0x 3023427841        245      40813                      2024/08/08 15:47:44  2024/08/08 15:50:41           2                    1 +000000000 00:02:57.055 0%
upd_wrong_ci_limits              oracle                                             7kkmkyh64pr0x 3023427841        674      56854 direct path read tem 2024/08/08 15:47:44  2024/08/08 15:47:44           1                    1 +000000000 00:00:00.000 0%
upd_wrong_ci_limits              oracle                                             7kkmkyh64pr0x 3023427841        582      52436 ON CPU               2024/08/08 15:47:44  2024/08/08 15:47:44           1                    1 +000000000 00:00:00.000 0%


MODULE                           PROGRAM                                            SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- -------------------------------------------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
upd_wrong_ci_limits                                                                 7kkmkyh64pr0x 3023427841                                            2024/08/08 15:45:31  2024/08/08 16:04:31        1279                    1 +000000000 00:19:00.595 100%


SQL_ID        SQL_PLAN_HASH_VALUE SQL_PLAN_LINE_ID SQL_PLAN_OPERATION             SQL_PLAN_OPTIONS                   ACTIVE
------------- ------------------- ---------------- ------------------------------ ------------------------------ ----------
7kkmkyh64pr0x          3023427841               90 TABLE ACCESS                   BY INDEX ROWID BATCHED                 82
7kkmkyh64pr0x          3023427841               36 TABLE ACCESS                   FULL                                   20
7kkmkyh64pr0x          3023427841               61 TABLE ACCESS                   BY INDEX ROWID BATCHED                 18
7kkmkyh64pr0x          3023427841               20 INDEX                          UNIQUE SCAN                             2
7kkmkyh64pr0x          3023427841               16 INDEX                          RANGE SCAN                              2
7kkmkyh64pr0x          3023427841               19 TABLE ACCESS                   BY INDEX ROWID                          1
7kkmkyh64pr0x          3023427841               62 INDEX                          RANGE SCAN                              1
7kkmkyh64pr0x          3023427841                8 INDEX                          SKIP SCAN                               1
7kkmkyh64pr0x          3023427841               17 TABLE ACCESS                   BY INDEX ROWID                          1
7kkmkyh64pr0x          3023427841               15 TABLE ACCESS                   BY INDEX ROWID BATCHED                  1



INSTANCE_NUMBER SQL_ID            ELAPSED MAX_WAIT_ON     PC_OF  WAIT_TIME            GETS      READS       ROWS  ELAP/EXEC       GETS/EXEC READS/EXEC  ROWS/EXEC       EXEC PLAN_HASH_VALUE
--------------- ------------- ----------- --------------- ----- ---------- --------------- ---------- ---------- ---------- --------------- ---------- ---------- ---------- ---------------
              1 7kkmkyh64pr0x        1049 IO              92%   950.849435        25629978   21891228    3310649    1049.24        25629978   21891228    3310649          0      3023427841


Plan hash value: 3023427841
-------------------------------------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                                 | Name                        | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  |
-------------------------------------------------------------------------------------------------------------------------------------------------------------------------
|   0 | INSERT STATEMENT                                          |                             |      1 |        |   168K(100)|      0 |00:00:00.01 |       0 |      0 |
|   1 |  TEMP TABLE TRANSFORMATION                                |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
|   2 |   LOAD AS SELECT                                          | SYS_TEMP_0FD9D68E3_D65D7942 |      1 |        |            |      0 |00:00:00.01 |       1 |      0 |
|   3 |    NESTED LOOPS                                           |                             |      1 |      1 | 42824   (1)|   2094 |00:00:47.26 |     291K|  74973 |
|   4 |     NESTED LOOPS                                          |                             |      1 |      1 | 42823   (1)|   2094 |00:00:47.24 |     291K|  74970 |
|   5 |      NESTED LOOPS                                         |                             |      1 |    995 | 42793   (1)|  17251 |00:00:38.97 |     222K|  67035 |
|   6 |       NESTED LOOPS                                        |                             |      1 |    995 | 42773   (1)|  17251 |00:00:34.88 |     154K|  62977 |
|*  7 |        HASH JOIN                                          |                             |      1 |  30027 | 12746   (1)|  17252 |00:00:08.22 |   26121 |   9920 |
|*  8 |         INDEX SKIP SCAN                                   | INT_REFDOSS                 |      1 |    134K|   102   (0)|    675K|00:00:07.41 |    9917 |   9843 |
|   9 |         INLIST ITERATOR                                   |                             |      1 |        |            |  17252 |00:00:00.25 |   16204 |     77 |
|* 10 |          TABLE ACCESS BY INDEX ROWID BATCHED              | G_PIECE                     |      1 |    148K| 12189   (1)|  17252 |00:00:00.24 |   16204 |     77 |
|* 11 |           INDEX RANGE SCAN                                | PIECE_TYP_MT43_IDX          |      1 |   8027K|   327   (1)|  17302 |00:00:00.08 |      76 |     76 |
|  12 |        VIEW PUSHED PREDICATE                              |                             |  17252 |      1 |     1   (0)|  17251 |00:00:26.63 |     128K|  53057 |
|* 13 |         FILTER                                            |                             |  17252 |        |            |  17251 |00:00:26.60 |     128K|  53057 |
|  14 |          SORT AGGREGATE                                   |                             |  17252 |      1 |            |  17251 |00:00:26.56 |     128K|  53057 |
|  15 |           TABLE ACCESS BY INDEX ROWID BATCHED             | G_PIECEDET                  |  17252 |      1 |     1   (0)|  59580 |00:00:26.44 |     128K|  53058 |
|* 16 |            INDEX RANGE SCAN                               | G_PIECEDET_REFP             |  17252 |      1 |     1   (0)|  59581 |00:00:13.90 |   69408 |  14968 |
|  17 |       TABLE ACCESS BY INDEX ROWID                         | G_DOSSIER                   |  17251 |      1 |     1   (0)|  17251 |00:00:04.05 |   68312 |   4058 |
|* 18 |        INDEX UNIQUE SCAN                                  | DOS_REFDOSS                 |  17251 |      1 |     1   (0)|  17251 |00:00:00.36 |   34388 |    152 |
|* 19 |      TABLE ACCESS BY INDEX ROWID                          | G_PIECEDET                  |  17251 |      1 |     1   (0)|   2094 |00:00:08.30 |   68753 |   8067 |
|* 20 |       INDEX UNIQUE SCAN                                   | PK_G_PIECEDET               |  17251 |      1 |     1   (0)|  17251 |00:00:08.06 |   51677 |   8067 |
|* 21 |     INDEX UNIQUE SCAN                                     | IND_REFINDIV                |   2094 |      1 |     1   (0)|   2094 |00:00:00.02 |     772 |      3 |
|  22 |   LOAD AS SELECT                                          | SYS_TEMP_0FD9D68E4_D65D7942 |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  23 |    NESTED LOOPS                                           |                             |      0 |      1 |     5   (0)|      0 |00:00:00.01 |       0 |      0 |
|  24 |     NESTED LOOPS                                          |                             |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|  25 |      NESTED LOOPS                                         |                             |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|  26 |       VIEW                                                |                             |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|  27 |        TABLE ACCESS FULL                                  | SYS_TEMP_0FD9D68E3_D65D7942 |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|  28 |       TABLE ACCESS BY INDEX ROWID BATCHED                 | G_DOSSIER                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 29 |        INDEX RANGE SCAN                                   | DOS_ANCREFDOSS              |      0 |      5 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 30 |      INDEX RANGE SCAN                                     | G_DOSSIER_RL_CD_RD_RF_IDX   |      0 |      4 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 31 |     INDEX RANGE SCAN                                      | G_DOSSIER_RL_CD_RD_RF_IDX   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|  32 |   PX COORDINATOR                                          |                             |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  33 |    PX SEND QC (RANDOM)                                    | :TQ10000                    |      0 |   4013K|  3656K  (1)|      0 |00:00:00.01 |       0 |      0 |
|  34 |     LOAD AS SELECT (TEMP SEGMENT MERGE)                   | SYS_TEMP_0FD9D68E5_D65D7942 |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  35 |      PX BLOCK ITERATOR                                    |                             |      0 |   4013K|  3656K  (1)|      0 |00:00:00.01 |       0 |      0 |
|* 36 |       TABLE ACCESS FULL                                   | G_PIECE                     |      0 |   4013K|  3656K  (1)|      0 |00:00:00.01 |       0 |      0 |
|  37 |   LOAD TABLE CONVENTIONAL                                 | T_REPRISE_LIST              |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  38 |    UNION-ALL                                              |                             |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  39 |     PX COORDINATOR                                        |                             |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  40 |      PX SEND QC (RANDOM)                                  | :TQ20005                    |      0 |      1 |   162K  (1)|      0 |00:00:00.01 |       0 |      0 |
|  41 |       NESTED LOOPS OUTER                                  |                             |      0 |      1 |   162K  (1)|      0 |00:00:00.01 |       0 |      0 |
|  42 |        NESTED LOOPS                                       |                             |      0 |      1 |   162K  (1)|      0 |00:00:00.01 |       0 |      0 |
|* 43 |         FILTER                                            |                             |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  44 |          NESTED LOOPS OUTER                               |                             |      0 |      1 |   162K  (1)|      0 |00:00:00.01 |       0 |      0 |
|  45 |           NESTED LOOPS OUTER                              |                             |      0 |      1 |   162K  (1)|      0 |00:00:00.01 |       0 |      0 |
|* 46 |            FILTER                                         |                             |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|* 47 |             HASH JOIN OUTER                               |                             |      0 |      1 |   162K  (1)|      0 |00:00:00.01 |       0 |      0 |
|  48 |              PX RECEIVE                                   |                             |      0 |      1 |   162K  (1)|      0 |00:00:00.01 |       0 |      0 |
|  49 |               PX SEND HASH                                | :TQ20004                    |      0 |      1 |   162K  (1)|      0 |00:00:00.01 |       0 |      0 |
|* 50 |                FILTER                                     |                             |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|* 51 |                 HASH JOIN OUTER                           |                             |      0 |      1 |   162K  (1)|      0 |00:00:00.01 |       0 |      0 |
|  52 |                  PX RECEIVE                               |                             |      0 |      1 |   162K  (1)|      0 |00:00:00.01 |       0 |      0 |
|  53 |                   PX SEND HASH (NULL RANDOM)              | :TQ20003                    |      0 |      1 |   162K  (1)|      0 |00:00:00.01 |       0 |      0 |
|* 54 |                    HASH JOIN BUFFERED                     |                             |      0 |      1 |   162K  (1)|      0 |00:00:00.01 |       0 |      0 |
|* 55 |                     VIEW                                  |                             |      0 |   4013K|  3725   (2)|      0 |00:00:00.01 |       0 |      0 |
|  56 |                      PX BLOCK ITERATOR                    |                             |      0 |   4013K|  3725   (2)|      0 |00:00:00.01 |       0 |      0 |
|* 57 |                       TABLE ACCESS FULL                   | SYS_TEMP_0FD9D68E5_D65D7942 |      0 |   4013K|  3725   (2)|      0 |00:00:00.01 |       0 |      0 |
|  58 |                     PX RECEIVE                            |                             |      0 |    814K|  6103   (1)|      0 |00:00:00.01 |       0 |      0 |
|  59 |                      PX SEND BROADCAST                    | :TQ20002                    |      0 |    814K|  6103   (1)|      0 |00:00:00.01 |       0 |      0 |
|  60 |                       PX SELECTOR                         |                             |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|* 61 |                        TABLE ACCESS BY INDEX ROWID BATCHED| G_PIECE                     |      0 |    814K|  6103   (1)|      0 |00:00:00.01 |       0 |      0 |
|* 62 |                         INDEX RANGE SCAN                  | PIECE_TYP_MT43_IDX          |      0 |   4013K|   164   (1)|      0 |00:00:00.01 |       0 |      0 |
|  63 |                  BUFFER SORT                              |                             |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  64 |                   PX RECEIVE                              |                             |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|  65 |                    PX SEND HASH                           | :TQ20000                    |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|  66 |                     VIEW                                  |                             |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|  67 |                      TABLE ACCESS FULL                    | SYS_TEMP_0FD9D68E3_D65D7942 |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|  68 |              BUFFER SORT                                  |                             |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  69 |               PX RECEIVE                                  |                             |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|  70 |                PX SEND HASH                               | :TQ20001                    |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|  71 |                 VIEW                                      |                             |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|  72 |                  TABLE ACCESS FULL                        | SYS_TEMP_0FD9D68E4_D65D7942 |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 73 |            TABLE ACCESS BY INDEX ROWID BATCHED            | T_INDIVIDU                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 74 |             INDEX RANGE SCAN                              | IX_T_INDIVIDU               |      0 |      4 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 75 |           TABLE ACCESS BY INDEX ROWID BATCHED             | G_PIECE                     |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 76 |            INDEX RANGE SCAN                               | PIE_REFPIECE                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 77 |         INDEX RANGE SCAN                                  | G_PIECEDET_REFP             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 78 |        INDEX RANGE SCAN                                   | G_PIECEDET_REFP             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|  79 |     NESTED LOOPS OUTER                                    |                             |      0 |      1 |  6116   (1)|      0 |00:00:00.01 |       0 |      0 |
|  80 |      NESTED LOOPS OUTER                                   |                             |      0 |      1 |  6115   (1)|      0 |00:00:00.01 |       0 |      0 |
|  81 |       NESTED LOOPS                                        |                             |      0 |      1 |  6114   (1)|      0 |00:00:00.01 |       0 |      0 |
|* 82 |        FILTER                                             |                             |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|* 83 |         HASH JOIN RIGHT OUTER                             |                             |      0 |    281 |  6103   (1)|      0 |00:00:00.01 |       0 |      0 |
|  84 |          VIEW                                             |                             |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|  85 |           TABLE ACCESS FULL                               | SYS_TEMP_0FD9D68E4_D65D7942 |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 86 |          FILTER                                           |                             |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|* 87 |           HASH JOIN RIGHT OUTER                           |                             |      0 |    794 |  6101   (1)|      0 |00:00:00.01 |       0 |      0 |
|  88 |            VIEW                                           |                             |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|  89 |             TABLE ACCESS FULL                             | SYS_TEMP_0FD9D68E3_D65D7942 |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 90 |            TABLE ACCESS BY INDEX ROWID BATCHED            | G_PIECE                     |      0 |   2242 |  6099   (1)|      0 |00:00:00.01 |       0 |      0 |
|* 91 |             INDEX RANGE SCAN                              | PIECE_TYP_MT43_IDX          |      0 |   4013K|   164   (1)|      0 |00:00:00.01 |       0 |      0 |
|  92 |        TABLE ACCESS BY INDEX ROWID BATCHED                | G_PIECE                     |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 93 |         INDEX RANGE SCAN                                  | GP_GRTYPE_MT_DT             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 94 |       INDEX RANGE SCAN                                    | G_PIECEDET_REFP             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 95 |      TABLE ACCESS BY INDEX ROWID BATCHED                  | T_INDIVIDU                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 96 |       INDEX RANGE SCAN                                    | IX_T_INDIVIDU               |      0 |      4 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
-------------------------------------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   7 - access("CL"."REFDOSS"="CONTR"."REFDOSS")
   8 - access("CL"."REFTYPE"='CL')
       filter("CL"."REFTYPE"='CL')
  10 - filter("CONTR"."REFDOSS" IS NOT NULL)
  11 - access(("CONTR"."TYPPIECE"='CONTRAT' OR "CONTR"."TYPPIECE"='CONTRAT REV'))
  13 - filter(COUNT(*)>0)
  16 - access("REFPIECE"="CONTR"."REFPIECE" AND "TYPE"='CONTRACT SITUATIONS')
  18 - access("CONTR"."REFDOSS"="DOS"."REFDOSS")
  19 - filter((("CONTR_SIT1"."STR1"='C' AND "DOS"."CATEGDOSS"='CONTRAT IMP PROSPET' AND
              TO_CHAR(INTERNAL_FUNCTION("CONTR_SIT1"."DT01_DT"),'YYYYMMDD')>='20220101') OR (INTERNAL_FUNCTION("CONTR_SIT1"."STR1") AND "DOS"."CATEGDOSS"<>'CONTRAT IMP
              PROSPET')))
  20 - access("CONTR_SIT1"."IMX_UN_ID"="CONTR_SIT"."ID")
  21 - access("BU"."REFINDIVIDU"="DOS"."REFFACTOR")
  29 - access("DOS"."CONTRACT_NO"="CONTR"."ANCREFDOSS")
       filter("CONTR"."ANCREFDOSS" IS NOT NULL)
  30 - access("CONTR"."REFDOSS"="DECOM"."REFLOT")
  31 - access("DECOM"."REFDOSS"="CLDB"."REFLOT")
       filter(("CLDB"."CATEGDOSS"='COMPTE' OR "CLDB"."CATEGDOSS"='COMPTE EXP' OR "CLDB"."CATEGDOSS"='COMPTE IMP'))
  36 - access(:Z>=:Z AND :Z<=:Z)
       filter("P"."TYPPIECE"='PARAM_LIMITE')
  43 - filter((("P"."GPIDEPOT"='FIN' AND "P"."REFEXT"='COM' AND "P"."GPIBUREAU" IS NOT NULL AND "P"."GPIMARQUE" IS NOT NULL AND "REQ"."GPIHEURE" IS NOT NULL) OR
              ("P"."GPIDEPOT"='C' AND "P"."REFEXT"='COM' AND "P"."GPIBUREAU" IS NOT NULL AND "P"."GPIMARQUE" IS NOT NULL AND "REQ"."GPIHEURE" IS NOT NULL) OR
              ("P"."GPIDEPOT"='CI' AND "P"."REFEXT"='DB' AND "P"."GPIMARQUE" IS NOT NULL AND "POL"."REFEXT" IS NOT NULL)))
  46 - filter(("REQ"."GPIHEURE" IS NULL OR ("REQ"."GPIHEURE"="CANC"."ANCREFDOSS" AND "REQ"."REFDOSS"="CANC"."REFDOSS")))
  47 - access("REQ"."GPIHEURE"="CANC"."ANCREFDOSS" AND "REQ"."REFDOSS"="CANC"."REFDOSS")
  50 - filter(("MD"."CONTRACT_NO"="REQ"."GPIHEURE" OR "REQ"."GPIHEURE" IS NULL))
  51 - access("MD"."CONTRACT_NO"="REQ"."GPIHEURE")
  54 - access("P"."STR_20_1"="REQ"."REFPIECE")
  55 - filter(("P"."TYPPIECE"='PARAM_LIMITE' AND NVL("P"."FG01",'N')='N' AND (("P"."GPIDEPOT"='C' AND "P"."REFEXT"='COM') OR ("P"."GPIDEPOT"='CI' AND
              "P"."REFEXT"='DB') OR ("P"."GPIDEPOT"='FIN' AND "P"."REFEXT"='COM')) AND "P"."GPIDEVIS" IS NULL))
  57 - access(:Z>=:Z AND :Z<=:Z)
  61 - filter(NVL("REQ"."FG05",'N')='O')
  62 - access("REQ"."TYPPIECE"='REQUEST_LIMITE')
  73 - filter("BU"."SOCIETE"='FACTOR_ID')
  74 - access("BU"."REFINDIVIDU"="REQ"."GPITYPTRIB")
  75 - filter("POL"."TYPPIECE"='POLICE')
  76 - access("POL"."REFPIECE"="REQ"."LIBELLE_100_8")
  77 - access("D"."REFPIECE"="P"."REFPIECE" AND "D"."TYPE"='DETAIL_LIMITE')
  78 - access("CF_PROP"."REFPIECE"="REQ"."REFPIECE" AND "CF_PROP"."TYPE"='REQUEST_CF_PROPOSAL')
  82 - filter(("REQ"."GPIHEURE" IS NULL OR ("REQ"."GPIHEURE"="CANC"."ANCREFDOSS" AND "REQ"."REFDOSS"="CANC"."REFDOSS")))
  83 - access("REQ"."GPIHEURE"="CANC"."ANCREFDOSS" AND "REQ"."REFDOSS"="CANC"."REFDOSS")
  86 - filter(("MD"."CONTRACT_NO"="REQ"."GPIHEURE" OR "REQ"."GPIHEURE" IS NULL))
  87 - access("MD"."CONTRACT_NO"="REQ"."GPIHEURE")
  90 - filter(("REQ"."GPITYPTRIB" IS NOT NULL AND INTERNAL_FUNCTION("REQ"."TYPEDOC") AND "REQ"."GPIDEVIS" IS NULL AND NVL("REQ"."FG05",'N')='O' AND
              NVL("REQ"."GPIDTFIN_DT",TRUNC(SYSDATE@!))>=TRUNC(SYSDATE@!)))
  91 - access("REQ"."TYPPIECE"='REQUEST_LIMITE')
  93 - access("GP"."TYPPIECE"='FACTOR' AND "GP"."GPIHEURE"="REQ"."GPITYPTRIB")
       filter("GP"."GPIHEURE" IS NOT NULL)
  94 - access("GP"."REFPIECE"="GD"."REFPIECE" AND "GD"."TYPE"='POLICIES' AND "GD"."NB01"=1)
       filter("GD"."NB01"=1)
  95 - filter("BU"."SOCIETE"='FACTOR_ID')
  96 - access("BU"."REFINDIVIDU"="REQ"."GPITYPTRIB")
*/
/********************************OLD Metrics***************************************/

/********************************New SQL*******************************************/

INSERT INTO T_REPRISE_LIST ( CLIENT, DTCREATION_DT, CREATEUR, REFCL )
  WITH DOS AS ( SELECT DOS.REFDOSS, 
                       DOS.ANCREFDOSS AS CONTRACT_NO
                  FROM G_DOSSIER DOS,
                       T_INTERVENANTS CL,
                       G_PIECE CONTR,
                       G_INDIVIDU BU,
                       ( SELECT MAX(IMX_UN_ID) ID, 
                                REFPIECE
                           FROM G_PIECEDET
                          WHERE TYPE = 'CONTRACT SITUATIONS'
                          GROUP BY REFPIECE ) CONTR_SIT,
                          G_PIECEDET CONTR_SIT1
                 WHERE CONTR.TYPPIECE IN ('CONTRAT', 'CONTRAT REV')
                   AND CONTR.REFDOSS = DOS.REFDOSS
                   AND CONTR_SIT.REFPIECE = CONTR.REFPIECE
                   AND (    (     CONTR_SIT1.STR1 = 'C' 
                              AND DOS.CATEGDOSS = 'CONTRAT IMP PROSPET' 
                              AND TO_CHAR(CONTR_SIT1.DT01_DT, 'YYYYMMDD') >= '20220101' )
                         OR (     CONTR_SIT1.STR1 IN ('E', 'I', 'N', 'O', 'P', 'R', 'S', 'V') 
                              AND DOS.CATEGDOSS != 'CONTRAT IMP PROSPET' ) )
                   AND CONTR_SIT1.IMX_UN_ID = CONTR_SIT.ID
                   AND CL.REFDOSS = CONTR.REFDOSS
                   AND CL.REFTYPE = 'CL'
                   AND BU.REFINDIVIDU = DOS.REFFACTOR ),
       CANC AS ( SELECT CONTR.ANCREFDOSS ANCREFDOSS, 
                        CLDB.REFDOSS REFDOSS
                   FROM G_DOSSIER CLDB, 
                        G_DOSSIER DECOM, 
                        G_DOSSIER CONTR, 
                        DOS
                  WHERE CLDB.CATEGDOSS IN ('COMPTE', 'COMPTE IMP', 'COMPTE EXP')
                    AND DECOM.REFDOSS = CLDB.REFLOT
                    AND CONTR.REFDOSS = DECOM.REFLOT
                    AND DOS.CONTRACT_NO = CONTR.ANCREFDOSS ),
      LIMITE AS ( SELECT /*+ no_merge no_push_pred materialize full(p) parallel(p 4) */
                         P.REFPIECE,
                         P.GPIDEPOT,
                         P.GPIDEVIS,
                         P.FG01,
                         P.REFEXT,
                         P.GPIBUREAU,
                         P.GPIMARQUE,
                         P.STR_20_1,
                         P.TYPPIECE,
                         P.GPIHEURE,
                         P.GPITYPTRIB,
                         P.LIBELLE_100_8,
                         P.FG05,
                         P.REFDOSS,
                         P.TYPEDOC,
                         P.GPIDTFIN_DT
                   FROM G_PIECE P
                  WHERE P.TYPPIECE IN ('PARAM_LIMITE','REQUEST_LIMITE') )
  SELECT /*+ leading(p req md)  */
          'EFDE2WEB-761',
           SYSDATE, 
           'upd_wrong_ci_limits.sql', 
           REQ.REFPIECE
    FROM LIMITE P,
         G_PIECEDET   D,
         G_PIECE      POL,
         LIMITE      REQ,
         G_PIECEDET   CF_PROP,
         T_INDIVIDU   BU,
         DOS          MD,
         CANC
   WHERE P.TYPPIECE = 'PARAM_LIMITE'
     AND REQ.TYPPIECE = 'REQUEST_LIMITE'
     AND REQ.GPIHEURE = CANC.ANCREFDOSS(+)
     AND REQ.REFDOSS = CANC.REFDOSS(+)
     AND (    REQ.GPIHEURE IS NULL 
           OR (     REQ.GPIHEURE = CANC.ANCREFDOSS 
                AND REQ.REFDOSS = CANC.REFDOSS ) )
     AND P.STR_20_1 = REQ.REFPIECE
     AND D.REFPIECE = P.REFPIECE
     AND D.TYPE = 'DETAIL_LIMITE'
     AND NVL(P.FG01, 'N') = 'N'
     AND NVL(REQ.FG05, 'N') = 'O'
     AND POL.REFPIECE(+) = REQ.LIBELLE_100_8
     AND POL.TYPPIECE(+) = 'POLICE'
     AND BU.REFINDIVIDU(+) = REQ.GPITYPTRIB
     AND BU.SOCIETE(+) = 'FACTOR_ID'
     AND MD.CONTRACT_NO(+) = REQ.GPIHEURE
     AND (    MD.CONTRACT_NO = REQ.GPIHEURE 
           OR REQ.GPIHEURE IS NULL )
     AND ( P.GPIDEPOT, P.REFEXT) IN (('FIN', 'COM'), ('C', 'COM'), ('CI', 'DB') )
     AND CF_PROP.REFPIECE(+) = REQ.REFPIECE
     AND CF_PROP.TYPE(+) = 'REQUEST_CF_PROPOSAL'
     AND (    (     P.GPIDEPOT = 'FIN' 
                AND P.REFEXT = 'COM' 
                AND P.GPIBUREAU IS NOT NULL 
                AND P.GPIMARQUE IS NOT NULL 
                AND REQ.GPIHEURE IS NOT NULL ) 
           OR (    P.GPIDEPOT = 'C'
                AND P.REFEXT = 'COM' 
                AND P.GPIBUREAU IS NOT NULL 
                AND P.GPIMARQUE IS NOT NULL
                AND REQ.GPIHEURE IS NOT NULL ) 
           OR (    P.GPIDEPOT = 'CI' 
                AND P.REFEXT = 'DB'
                AND P.GPIMARQUE IS NOT NULL 
                AND POL.REFEXT IS NOT NULL ) )
     AND P.GPIDEVIS IS NULL
  UNION ALL
  SELECT 'EFDE2WEB-761', 
         SYSDATE, 
         'upd_wrong_ci_limits.sql', 
         REQ.REFPIECE
    FROM G_PIECE    POL,
         LIMITE    REQ,
         G_PIECEDET GD,
         G_PIECE    GP,
         G_PIECE    POL1,
         T_INDIVIDU BU,
         DOS        MD,
         CANC
   WHERE REQ.TYPPIECE = 'REQUEST_LIMITE'
     AND NVL(REQ.FG05, 'N') = 'O'
     AND NVL(REQ.GPIDTFIN_DT, TRUNC(SYSDATE)) >= TRUNC(SYSDATE)
     AND REQ.GPIHEURE = CANC.ANCREFDOSS(+)
     AND REQ.REFDOSS = CANC.REFDOSS(+)
     AND (    REQ.GPIHEURE IS NULL 
           OR (    REQ.GPIHEURE = CANC.ANCREFDOSS 
               AND REQ.REFDOSS = CANC.REFDOSS ) )
     AND POL.REFPIECE(+) = REQ.LIBELLE_100_8
     AND POL.TYPPIECE(+) = 'POLICE'
     AND REQ.TYPEDOC IN ('O', 'G')
     AND GP.TYPPIECE = 'FACTOR'
     AND GP.GPIHEURE = REQ.GPITYPTRIB
     AND GP.REFPIECE = GD.REFPIECE(+)
     AND GD.TYPE(+) = 'POLICIES'
     AND GD.NB01(+) = '1'
     AND POL1.REFPIECE(+) = GD.STR1
     AND POL1.TYPPIECE(+) = 'POLICE'
     AND BU.REFINDIVIDU(+) = REQ.GPITYPTRIB
     AND BU.SOCIETE(+) = 'FACTOR_ID'
     AND MD.CONTRACT_NO(+) = REQ.GPIHEURE
     AND (    MD.CONTRACT_NO = REQ.GPIHEURE 
           OR REQ.GPIHEURE IS NULL )
     AND REQ.GPIDEVIS IS NULL;
/********************************New SQL*******************************************/
/********************************New Metrics***************************************/
/*
Plan hash value: 2404097198
--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                               | Name                        | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  | Writes |
--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
|   0 | INSERT STATEMENT                                        |                             |      1 |        |   610K(100)|      0 |00:02:23.69 |     419K|    123K|   1250 |
|   1 |  TEMP TABLE TRANSFORMATION                              |                             |      1 |        |            |      0 |00:02:23.69 |     419K|    123K|   1250 |
|   2 |   LOAD AS SELECT                                        | SYS_TEMP_0FD9D6903_D65D7942 |      1 |        |            |      0 |00:01:04.48 |     380K|    118K|     16 |
|   3 |    NESTED LOOPS                                         |                             |      1 |      1 | 42824   (1)|   4556 |00:01:04.46 |     380K|    118K|      0 |
|   4 |     NESTED LOOPS                                        |                             |      1 |      1 | 42823   (1)|   4556 |00:01:04.44 |     379K|    118K|      0 |
|   5 |      NESTED LOOPS                                       |                             |      1 |    995 | 42793   (1)|  22668 |00:00:52.64 |     288K|    105K|      0 |
|   6 |       NESTED LOOPS                                      |                             |      1 |    995 | 42773   (1)|  22668 |00:00:43.76 |     199K|  94436 |      0 |
|*  7 |        HASH JOIN                                        |                             |      1 |  30027 | 12746   (1)|  22668 |00:00:06.39 |   31418 |  10018 |      0 |
|*  8 |         INDEX SKIP SCAN                                 | INT_REFDOSS                 |      1 |    134K|   102   (0)|    675K|00:00:05.84 |    9917 |   9911 |      0 |
|   9 |         INLIST ITERATOR                                 |                             |      1 |        |            |  22668 |00:00:00.23 |   21501 |    107 |      0 |
|* 10 |          TABLE ACCESS BY INDEX ROWID BATCHED            | G_PIECE                     |      2 |    148K| 12189   (1)|  22668 |00:00:00.22 |   21501 |    107 |      0 |
|* 11 |           INDEX RANGE SCAN                              | PIECE_TYP_MT43_IDX          |      2 |   8027K|   327   (1)|  22668 |00:00:00.08 |     100 |     97 |      0 |
|  12 |        VIEW PUSHED PREDICATE                            |                             |  22668 |      1 |     1   (0)|  22668 |00:00:37.35 |     167K|  84418 |      0 |
|* 13 |         FILTER                                          |                             |  22668 |        |            |  22668 |00:00:37.33 |     167K|  84418 |      0 |
|  14 |          SORT AGGREGATE                                 |                             |  22668 |      1 |            |  22668 |00:00:37.29 |     167K|  84418 |      0 |
|  15 |           TABLE ACCESS BY INDEX ROWID BATCHED           | G_PIECEDET                  |  22668 |      1 |     1   (0)|  77491 |00:00:37.19 |     167K|  84418 |      0 |
|* 16 |            INDEX RANGE SCAN                             | G_PIECEDET_REFP             |  22668 |      1 |     1   (0)|  77491 |00:00:20.60 |   91164 |  24971 |      0 |
|  17 |       TABLE ACCESS BY INDEX ROWID                       | G_DOSSIER                   |  22668 |      1 |     1   (0)|  22668 |00:00:08.85 |   89799 |  10689 |      0 |
|* 18 |        INDEX UNIQUE SCAN                                | DOS_REFDOSS                 |  22668 |      1 |     1   (0)|  22668 |00:00:00.78 |   45147 |    777 |      0 |
|* 19 |      TABLE ACCESS BY INDEX ROWID                        | G_PIECEDET                  |  22668 |      1 |     1   (0)|   4556 |00:00:11.77 |   90328 |  13046 |      0 |
|* 20 |       INDEX UNIQUE SCAN                                 | PK_G_PIECEDET               |  22668 |      1 |     1   (0)|  22668 |00:00:11.61 |   67887 |  13046 |      0 |
|* 21 |     INDEX UNIQUE SCAN                                   | IND_REFINDIV                |   4556 |      1 |     1   (0)|   4556 |00:00:00.01 |    1614 |      0 |      0 |
|  22 |   LOAD AS SELECT                                        | SYS_TEMP_0FD9D6904_D65D7942 |      1 |        |            |      0 |00:00:05.95 |   35634 |   4413 |   1107 |
|  23 |    NESTED LOOPS                                         |                             |      1 |      1 |     5   (0)|    333K|00:00:05.76 |   34508 |   4413 |      0 |
|  24 |     NESTED LOOPS                                        |                             |      1 |      1 |     4   (0)|   6423 |00:00:01.55 |   18257 |   1101 |      0 |
|  25 |      NESTED LOOPS                                       |                             |      1 |      1 |     3   (0)|   4556 |00:00:00.11 |    9078 |     18 |      0 |
|  26 |       VIEW                                              |                             |      1 |      1 |     2   (0)|   4556 |00:00:00.01 |      20 |     16 |      0 |
|  27 |        TABLE ACCESS FULL                                | SYS_TEMP_0FD9D6903_D65D7942 |      1 |      1 |     2   (0)|   4556 |00:00:00.01 |      20 |     16 |      0 |
|  28 |       TABLE ACCESS BY INDEX ROWID BATCHED               | G_DOSSIER                   |   4556 |      1 |     1   (0)|   4556 |00:00:00.09 |    9058 |      2 |      0 |
|* 29 |        INDEX RANGE SCAN                                 | DOS_ANCREFDOSS              |   4556 |      5 |     1   (0)|   4556 |00:00:00.05 |    4574 |      0 |      0 |
|* 30 |      INDEX RANGE SCAN                                   | G_DOSSIER_RL_CD_RD_RF_IDX   |   4556 |      4 |     1   (0)|   6423 |00:00:01.44 |    9179 |   1083 |      0 |
|* 31 |     INDEX RANGE SCAN                                    | G_DOSSIER_RL_CD_RD_RF_IDX   |   6423 |      1 |     1   (0)|    333K|00:00:04.17 |   16251 |   3312 |      0 |
|  32 |   PX COORDINATOR                                        |                             |      1 |        |            |      8 |00:01:09.91 |     745 |     17 |      0 |
|  33 |    PX SEND QC (RANDOM)                                  | :TQ10000                    |      0 |   8027K|  3657K  (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|  34 |     LOAD AS SELECT (TEMP SEGMENT MERGE)                 | SYS_TEMP_0FD9D6905_D65D7942 |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
|  35 |      PX BLOCK ITERATOR                                  |                             |      0 |   8027K|  3657K  (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|* 36 |       TABLE ACCESS FULL                                 | G_PIECE                     |      0 |   8027K|  3657K  (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|  37 |   LOAD TABLE CONVENTIONAL                               | T_REPRISE_LIST              |      1 |        |            |      0 |00:00:03.32 |    2285 |   1107 |      0 |
|  38 |    UNION-ALL                                            |                             |      1 |        |            |      0 |00:00:03.32 |    2285 |   1107 |      0 |
|  39 |     PX COORDINATOR                                      |                             |      1 |        |            |      0 |00:00:02.11 |    1150 |   1107 |      0 |
|  40 |      PX SEND QC (RANDOM)                                | :TQ20006                    |      0 |      1 |   592K  (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|  41 |       NESTED LOOPS OUTER                                |                             |      0 |      1 |   592K  (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|  42 |        NESTED LOOPS                                     |                             |      0 |      1 |   592K  (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|* 43 |         FILTER                                          |                             |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
|  44 |          NESTED LOOPS OUTER                             |                             |      0 |      1 |   592K  (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|  45 |           NESTED LOOPS OUTER                            |                             |      0 |      1 |   592K  (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|* 46 |            FILTER                                       |                             |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
|* 47 |             HASH JOIN OUTER                             |                             |      0 |      1 |   592K  (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|  48 |              PX RECEIVE                                 |                             |      0 |      1 |   592K  (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|  49 |               PX SEND HASH                              | :TQ20005                    |      0 |      1 |   592K  (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|* 50 |                FILTER                                   |                             |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
|* 51 |                 HASH JOIN OUTER                         |                             |      0 |      1 |   592K  (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|  52 |                  PX RECEIVE                             |                             |      0 |      1 |   592K  (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|  53 |                   PX SEND HASH (NULL RANDOM)            | :TQ20004                    |      0 |      1 |   592K  (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|* 54 |                    HASH JOIN BUFFERED                   |                             |      0 |      1 |   592K  (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|  55 |                     PX RECEIVE                          |                             |      0 |   8027K| 12204   (2)|      0 |00:00:00.01 |       0 |      0 |      0 |
|  56 |                      PX SEND HASH                       | :TQ20002                    |      0 |   8027K| 12204   (2)|      0 |00:00:00.01 |       0 |      0 |      0 |
|* 57 |                       VIEW                              |                             |      0 |   8027K| 12204   (2)|      0 |00:00:00.01 |       0 |      0 |      0 |
|  58 |                        PX BLOCK ITERATOR                |                             |      0 |   8027K| 12204   (2)|      0 |00:00:00.01 |       0 |      0 |      0 |
|* 59 |                         TABLE ACCESS FULL               | SYS_TEMP_0FD9D6905_D65D7942 |      0 |   8027K| 12204   (2)|      0 |00:00:00.01 |       0 |      0 |      0 |
|  60 |                     PX RECEIVE                          |                             |      0 |   8027K| 12204   (2)|      0 |00:00:00.01 |       0 |      0 |      0 |
|  61 |                      PX SEND HASH                       | :TQ20003                    |      0 |   8027K| 12204   (2)|      0 |00:00:00.01 |       0 |      0 |      0 |
|* 62 |                       VIEW                              |                             |      0 |   8027K| 12204   (2)|      0 |00:00:00.01 |       0 |      0 |      0 |
|  63 |                        PX BLOCK ITERATOR                |                             |      0 |   8027K| 12204   (2)|      0 |00:00:00.01 |       0 |      0 |      0 |
|* 64 |                         TABLE ACCESS FULL               | SYS_TEMP_0FD9D6905_D65D7942 |      0 |   8027K| 12204   (2)|      0 |00:00:00.01 |       0 |      0 |      0 |
|  65 |                  BUFFER SORT                            |                             |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
|  66 |                   PX RECEIVE                            |                             |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|  67 |                    PX SEND HASH                         | :TQ20000                    |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|  68 |                     VIEW                                |                             |      1 |      1 |     2   (0)|   4556 |00:00:00.01 |      17 |      0 |      0 |
|  69 |                      TABLE ACCESS FULL                  | SYS_TEMP_0FD9D6903_D65D7942 |      1 |      1 |     2   (0)|   4556 |00:00:00.01 |      17 |      0 |      0 |
|  70 |              BUFFER SORT                                |                             |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
|  71 |               PX RECEIVE                                |                             |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|  72 |                PX SEND HASH                             | :TQ20001                    |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|  73 |                 VIEW                                    |                             |      1 |      1 |     2   (0)|    333K|00:00:00.08 |    1112 |   1107 |      0 |
|  74 |                  TABLE ACCESS FULL                      | SYS_TEMP_0FD9D6904_D65D7942 |      1 |      1 |     2   (0)|    333K|00:00:00.06 |    1112 |   1107 |      0 |
|* 75 |            TABLE ACCESS BY INDEX ROWID BATCHED          | T_INDIVIDU                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|* 76 |             INDEX RANGE SCAN                            | IX_T_INDIVIDU               |      0 |      4 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|* 77 |           TABLE ACCESS BY INDEX ROWID BATCHED           | G_PIECE                     |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|* 78 |            INDEX RANGE SCAN                             | PIE_REFPIECE                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|* 79 |         INDEX RANGE SCAN                                | G_PIECEDET_REFP             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|* 80 |        INDEX RANGE SCAN                                 | G_PIECEDET_REFP             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|  81 |     PX COORDINATOR                                      |                             |      1 |        |            |      0 |00:00:01.21 |    1135 |      0 |      0 |
|  82 |      PX SEND QC (RANDOM)                                | :TQ30005                    |      0 |      1 | 17303   (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|  83 |       NESTED LOOPS OUTER                                |                             |      0 |      1 | 17303   (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|  84 |        NESTED LOOPS OUTER                               |                             |      0 |      1 | 17302   (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|* 85 |         FILTER                                          |                             |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
|* 86 |          HASH JOIN OUTER                                |                             |      0 |      1 | 17301   (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|  87 |           PX RECEIVE                                    |                             |      0 |      1 | 17299   (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|  88 |            PX SEND HASH                                 | :TQ30004                    |      0 |      1 | 17299   (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|* 89 |             FILTER                                      |                             |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
|* 90 |              HASH JOIN OUTER                            |                             |      0 |      1 | 17299   (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|  91 |               PX RECEIVE                                |                             |      0 |      1 | 17296   (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|  92 |                PX SEND HASH (NULL RANDOM)               | :TQ30003                    |      0 |      1 | 17296   (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|* 93 |                 HASH JOIN                               |                             |      0 |      1 | 17296   (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|  94 |                  JOIN FILTER CREATE                     | :BF0000                     |      0 |  51312 |  5061   (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|  95 |                   PX RECEIVE                            |                             |      0 |  51312 |  5061   (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|  96 |                    PX SEND BROADCAST                    | :TQ30002                    |      0 |  51312 |  5061   (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|  97 |                     PX SELECTOR                         |                             |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
|  98 |                      TABLE ACCESS BY INDEX ROWID BATCHED| G_PIECE                     |      0 |  51312 |  5061   (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|* 99 |                       INDEX RANGE SCAN                  | GP_GRTYPE_MT_DT             |      0 |   2591K|   239   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*100 |                  VIEW                                   |                             |      0 |   8027K| 12204   (2)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 101 |                   JOIN FILTER USE                       | :BF0000                     |      0 |   8027K| 12204   (2)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 102 |                    PX BLOCK ITERATOR                    |                             |      0 |   8027K| 12204   (2)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*103 |                     TABLE ACCESS FULL                   | SYS_TEMP_0FD9D6905_D65D7942 |      0 |   8027K| 12204   (2)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 104 |               BUFFER SORT                               |                             |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
| 105 |                PX RECEIVE                               |                             |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 106 |                 PX SEND HASH                            | :TQ30000                    |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 107 |                  VIEW                                   |                             |      1 |      1 |     2   (0)|   4556 |00:00:00.01 |      17 |      0 |      0 |
| 108 |                   TABLE ACCESS FULL                     | SYS_TEMP_0FD9D6903_D65D7942 |      1 |      1 |     2   (0)|   4556 |00:00:00.01 |      17 |      0 |      0 |
| 109 |           BUFFER SORT                                   |                             |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
| 110 |            PX RECEIVE                                   |                             |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 111 |             PX SEND HASH                                | :TQ30001                    |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 112 |              VIEW                                       |                             |      1 |      1 |     2   (0)|    333K|00:00:00.05 |    1109 |      0 |      0 |
| 113 |               TABLE ACCESS FULL                         | SYS_TEMP_0FD9D6904_D65D7942 |      1 |      1 |     2   (0)|    333K|00:00:00.02 |    1109 |      0 |      0 |
|*114 |         INDEX RANGE SCAN                                | G_PIECEDET_REFP             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*115 |        TABLE ACCESS BY INDEX ROWID BATCHED              | T_INDIVIDU                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*116 |         INDEX RANGE SCAN                                | IX_T_INDIVIDU               |      0 |      4 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   7 - access("CL"."REFDOSS"="CONTR"."REFDOSS")
   8 - access("CL"."REFTYPE"='CL')
       filter("CL"."REFTYPE"='CL')
  10 - filter("CONTR"."REFDOSS" IS NOT NULL)
  11 - access(("CONTR"."TYPPIECE"='CONTRAT' OR "CONTR"."TYPPIECE"='CONTRAT REV'))
  13 - filter(COUNT(*)>0)
  16 - access("REFPIECE"="CONTR"."REFPIECE" AND "TYPE"='CONTRACT SITUATIONS')
  18 - access("CONTR"."REFDOSS"="DOS"."REFDOSS")
  19 - filter((("CONTR_SIT1"."STR1"='C' AND "DOS"."CATEGDOSS"='CONTRAT IMP PROSPET' AND TO_CHAR(INTERNAL_FUNCTION("CONTR_SIT1"."DT01_DT"),'YYYYMMDD')>='20220101') OR
              (INTERNAL_FUNCTION("CONTR_SIT1"."STR1") AND "DOS"."CATEGDOSS"<>'CONTRAT IMP PROSPET')))
  20 - access("CONTR_SIT1"."IMX_UN_ID"="CONTR_SIT"."ID")
  21 - access("BU"."REFINDIVIDU"="DOS"."REFFACTOR")
  29 - access("DOS"."CONTRACT_NO"="CONTR"."ANCREFDOSS")
       filter("CONTR"."ANCREFDOSS" IS NOT NULL)
  30 - access("CONTR"."REFDOSS"="DECOM"."REFLOT")
  31 - access("DECOM"."REFDOSS"="CLDB"."REFLOT")
       filter(("CLDB"."CATEGDOSS"='COMPTE' OR "CLDB"."CATEGDOSS"='COMPTE EXP' OR "CLDB"."CATEGDOSS"='COMPTE IMP'))
  36 - access(:Z>=:Z AND :Z<=:Z)
       filter(("P"."TYPPIECE"='PARAM_LIMITE' OR "P"."TYPPIECE"='REQUEST_LIMITE'))
  43 - filter((("P"."GPIDEPOT"='FIN' AND "P"."REFEXT"='COM' AND "P"."GPIBUREAU" IS NOT NULL AND "P"."GPIMARQUE" IS NOT NULL AND "REQ"."GPIHEURE" IS NOT NULL) OR
              ("P"."GPIDEPOT"='C' AND "P"."REFEXT"='COM' AND "P"."GPIBUREAU" IS NOT NULL AND "P"."GPIMARQUE" IS NOT NULL AND "REQ"."GPIHEURE" IS NOT NULL) OR ("P"."GPIDEPOT"='CI'
              AND "P"."REFEXT"='DB' AND "P"."GPIMARQUE" IS NOT NULL AND "POL"."REFEXT" IS NOT NULL)))
  46 - filter(("REQ"."GPIHEURE" IS NULL OR ("REQ"."GPIHEURE"="CANC"."ANCREFDOSS" AND "REQ"."REFDOSS"="CANC"."REFDOSS")))
  47 - access("REQ"."GPIHEURE"="CANC"."ANCREFDOSS" AND "REQ"."REFDOSS"="CANC"."REFDOSS")
  50 - filter(("MD"."CONTRACT_NO"="REQ"."GPIHEURE" OR "REQ"."GPIHEURE" IS NULL))
  51 - access("MD"."CONTRACT_NO"="REQ"."GPIHEURE")
  54 - access("P"."STR_20_1"="REQ"."REFPIECE")
  57 - filter(("P"."TYPPIECE"='PARAM_LIMITE' AND NVL("P"."FG01",'N')='N' AND (("P"."GPIDEPOT"='C' AND "P"."REFEXT"='COM') OR ("P"."GPIDEPOT"='CI' AND
              "P"."REFEXT"='DB') OR ("P"."GPIDEPOT"='FIN' AND "P"."REFEXT"='COM')) AND "P"."GPIDEVIS" IS NULL))
  59 - access(:Z>=:Z AND :Z<=:Z)
  62 - filter(("REQ"."TYPPIECE"='REQUEST_LIMITE' AND NVL("REQ"."FG05",'N')='O'))
  64 - access(:Z>=:Z AND :Z<=:Z)
  75 - filter("BU"."SOCIETE"='FACTOR_ID')
  76 - access("BU"."REFINDIVIDU"="REQ"."GPITYPTRIB")
  77 - filter("POL"."TYPPIECE"='POLICE')
  78 - access("POL"."REFPIECE"="REQ"."LIBELLE_100_8")
  79 - access("D"."REFPIECE"="P"."REFPIECE" AND "D"."TYPE"='DETAIL_LIMITE')
  80 - access("CF_PROP"."REFPIECE"="REQ"."REFPIECE" AND "CF_PROP"."TYPE"='REQUEST_CF_PROPOSAL')
  85 - filter(("REQ"."GPIHEURE" IS NULL OR ("REQ"."GPIHEURE"="CANC"."ANCREFDOSS" AND "REQ"."REFDOSS"="CANC"."REFDOSS")))
  86 - access("REQ"."GPIHEURE"="CANC"."ANCREFDOSS" AND "REQ"."REFDOSS"="CANC"."REFDOSS")
  89 - filter(("MD"."CONTRACT_NO"="REQ"."GPIHEURE" OR "REQ"."GPIHEURE" IS NULL))
  90 - access("MD"."CONTRACT_NO"="REQ"."GPIHEURE")
  93 - access("GP"."GPIHEURE"="REQ"."GPITYPTRIB")
  99 - access("GP"."TYPPIECE"='FACTOR')
       filter("GP"."GPIHEURE" IS NOT NULL)
 100 - filter(("REQ"."TYPPIECE"='REQUEST_LIMITE' AND NVL("REQ"."FG05",'N')='O' AND NVL("REQ"."GPIDTFIN_DT",TRUNC(SYSDATE@!))>=TRUNC(SYSDATE@!) AND
              INTERNAL_FUNCTION("REQ"."TYPEDOC") AND "REQ"."GPIDEVIS" IS NULL))
 103 - access(:Z>=:Z AND :Z<=:Z)
       filter(SYS_OP_BLOOM_FILTER(:BF0000,"C10"))
 114 - access("GP"."REFPIECE"="GD"."REFPIECE" AND "GD"."TYPE"='POLICIES' AND "GD"."NB01"=1)
       filter("GD"."NB01"=1)
 115 - filter("BU"."SOCIETE"='FACTOR_ID')
*/
/********************************New Metrics***************************************/

/********************************Index statistics**********************************/

/********************************Other SQLs****************************************/          
/*

*/ 
/********************************Other SQLs****************************************/              
