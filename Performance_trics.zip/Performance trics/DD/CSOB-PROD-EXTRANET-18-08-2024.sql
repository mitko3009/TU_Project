/********************************************************************************
*********       E-mail subject: CSOB-11064
*********             Instance: PROD
*********          Description: 
Problem:
Slow query was provided from CSOB PROD from the EXTRANET.

Analysis:
As it can be seen in the Old Metrics section below, the query starts from V_EXTR_DOM, where selects 7 rows through index TYPEABREV and after that for these rows 
it finds ~9.4 million rows in table T_INTERVENANTS and then starts looping the other tables for these millions rows. The solution that I can provide here is to 
add hint and force Oracle to start from table G_INDIVIDU from column NUMSS through index NUMSS_IDX, which seems to be the most selective predicate.

Suggestion:
Please add hint as it is shown in the New SQLs ection below.

*********               SQL_ID: 
*********      Program/Package: 
*********              Request: Svetoslav Getsov
*********               Author: Dimitar Dimitrov
********* Received e-mail date: 13/08/2024
*********      Resolution date: 16/08/2024
*********  Trace old file here: \\epox\specifs\performance\tmp\
*********  Trace new file here:
***********************************************************************************/

/********************************OLD SQL*******************************************/

SELECT *
  FROM (SELECT INN.*,
               ROWNUM RECORD_NO
          FROM ( SELECT DISTINCT COUNT(DISTINCT D.REFDOSS) OVER(PARTITION BY 'const') OUT_OF,
                                 D.EXT_REFERENCE_U1 UNIQUEREFERENCE,
                                 ( SELECT DTAR_DT
                                     FROM T_FILIERE
                                    WHERE REFDOSS = D.REFDOSS
                                      AND DTFIN_DT IS NULL
                                      AND ROWNUM = 1 ) ACKNOWLEDGEDATE,
                                 D.REFDOSS ID,
                                 D.ANCREFDOSS ANCREFDOSS,
                                 ( SELECT TI.REFDOSSEXT
                                     FROM T_INTERVENANTS TI,
                                          V_EXTR_DOM AUTH
                                    WHERE AUTH.TYPE = 'EXTR_GEST_CLIENT'
                                      AND AUTH.ABREV = TO_CHAR(132)
                                      AND TI.REFTYPE = AUTH.VALEUR_2
                                      AND TI.REFINDIVIDU = AUTH.VALEUR
                                      AND TI.REFDOSS = D.REFDOSS
                                      AND TI.REFDOSSEXT IS NOT NULL
                                      AND ROWNUM = 1 ) REFDOSSEXT,
                                  ( SELECT REFEXT
                                      FROM T_INDIVIDU TID
                                     WHERE IMX_UN_ID = ( SELECT MAX(IMX_UN_ID)
                                                           FROM T_INDIVIDU,
                                                                G_DOSSIER  CONTR,
                                                                G_DOSSIER  DECOMPTE
                                                          WHERE SOCIETE = 'CLIENT_NUMBER'
                                                            AND REFINDIVIDU = I.REFINDIVIDU
                                                            AND REFEXT2 = CLIENT.REFINDIVIDU
                                                            AND REFEXT3 = CONTR.ANCREFDOSS
                                                            AND DECOMPTE.CATEGDOSS LIKE
                                                                'DECOMPTE%'
                                                            AND DECOMPTE.REFDOSS = D.REFLOT
                                                            AND DECOMPTE.REFLOT = CONTR.REFDOSS ) ) YOURNUMBER,
                                TRIM(I.NOM || DECODE(I.PRENOM, NULL, '', ', ' || I.PRENOM ) ) AS DEBTORFULLNAME,
                                DECODE(I.ADR1, NULL, '', I.ADR1 || ', ') ||
                                DECODE(I.ADR2, NULL, '', I.ADR2 || ', ') ||
                                DECODE(I.VILLE, NULL, '', I.VILLE || ', ') ||
                                DECODE(I.CP, NULL, '', I.CP || ', ') ||
                                DECODE(NVL(VD_DIV.VALEUR_TRAD, VD_DIV.VALEUR), NULL, '', NVL(VD_DIV.VALEUR_TRAD, VD_DIV.VALEUR) || ', ') ||
                                NVL(VD.VALEUR_TRAD, VD.VALEUR) AS DEBTORFULLADDRESS,
                                I.CP DEBTORPC,
                                I.VILLE DEBTORCITY,
                                POLICY.STR1 POLICYNUMBER,
                                I.ADR1 DEBTORADR1,
                                I.DIVISION DEBTORSTATE,
                                NVL(VD.VALEUR_TRAD, VD.VALEUR) DEBTORCOUNTRY,
                                NVL(D.SOLDEDB_DOS, 0) BALANCE,
                                D.DT_DT_DT CASEDATE,
                                NVL( ( SELECT DECODE( ABREV,
                                                      'CLO',
                                                      'Closed',
                                                      'Active' )
                                         FROM V_DOMAINE
                                        WHERE TYPE = 'typencour'
                                          AND VALEUR = ( SELECT MAX(TA.TYPENCOUR)
                                                           FROM T_ATTENTE TA
                                                          WHERE TA.REFENTITE = D.REFDOSS ) ),
                                    'Active' ) CASE_TYPE,
                                D.DEVISE CURRENCY,
                                ( SELECT 1
                                    FROM T_INTERVENANTS SR
                                   WHERE SR.REFTYPE NOT IN ('DB', 'CL', 'XX')
                                     AND ROWNUM = 1
                                     AND SR.REFDOSS = D.REFDOSS ) THIRDPARTYINVOLVED,
                                DECODE( ( SELECT PIECE.REFPIECE
                                            FROM G_DOSSIER G, 
                                                 G_PIECE PIECE
                                           WHERE PIECE.TYPPIECE = 'DBT_VERIF_REQ'
                                             AND PIECE.REFDOSS = G.REFDOSS
                                             AND G.CATEGDOSS LIKE 'COLLECTION%'
                                             AND G.REFDOSS = D.REFDOSS
                                             AND ROWNUM = 1 ),
                                       NULL,
                                       'false',
                                       'true' ) AS ISDEBTVERIF,
                                SUM( NVL( D.SOLDEDB, 0 ) ) OVER() AS TOTAL_SUM
                  FROM G_DOSSIER D,
                       G_PIECE PIECECASE,
                       T_INTERVENANTS T,
                       ( SELECT PD.STR1 STR1, 
                                P.REFDOSS REFDOSS
                           FROM G_PIECE P, 
                                G_PIECEDET PD
                          WHERE P.TYPPIECE = 'CONTRAT'
                            AND PD.TYPE = 'CI CONTRACTS'
                            AND PD.REFPIECE = P.REFPIECE
                            AND PD.FG01 = 'O' ) POLICY,
                       G_INDIVIDU I,
                       T_INTERVENANTS CLIENT,
                       G_INDIVIDU ICL,
                       V_TDOMAINE VD,
                       T_INTERVENANTS T_INT,
                       LST_SCORE LST,
                       ( SELECT VALEUR
                           FROM V_DOMAINE
                          WHERE TYPE = 'categdoss'
                            AND ( ECRAN = 'X' 
                               OR EXISTS ( SELECT 1
                                             FROM G_ETUDE
                                            WHERE ACTIVITE_GPC IN ('G', 'T')))) VD_CAT,
                       V_TDOMAINE VD_DIV,
                       V_TDOMAINE VD_CATEGDOSS,
                       V_TDOMAINE VD_PIECEINIT,
                       V_EXTR_DOM AUTH
                 WHERE D.CATEGDOSS = VD_CAT.VALEUR
                   AND PIECECASE.REFDOSS = D.REFDOSS
                   AND PIECECASE.TYPPIECE = D.PIECEINIT
                   AND LST.REFDOSS(+) = D.REFDOSS
                   AND D.CATEGDOSS <> 'COMPTE DB CTR'
                   AND D.REFDOSS = T.REFDOSS
                   AND T.REFTYPE = 'DB'
                   AND T.REFINDIVIDU = I.REFINDIVIDU
                   AND D.REFDOSS NOT LIKE 'GL%'
                   AND D.REFDOSS = CLIENT.REFDOSS
                   AND CLIENT.REFTYPE IN ('CL', 'TC')
                   AND ICL.REFINDIVIDU = CLIENT.REFINDIVIDU
                   AND VD.TYPE(+) = 'pays'
                   AND VD.LANGUE(+) = 'AN'
                   AND VD.ABREV(+) = I.PAYS
                   AND VD_DIV.TYPE(+) = 'DIVISION TERRITORIALE'
                   AND VD_DIV.ECRAN(+) = I.PAYS
                   AND VD_DIV.LANGUE(+) = 'AN'
                   AND VD_DIV.ABREV(+) = I.DIVISION
                   AND NVL(D.FG_EXCL_FROM_EXTR, 'N') != 'O'
                   AND DECODE(D.REFHIERARCHIE,
                              NULL,
                              'N',
                              (SELECT NVL(FG_EXCL_FROM_EXTR, 'N')
                                 FROM G_DOSSIER
                                WHERE REFDOSS = D.REFHIERARCHIE)) = 'N'
                   AND DECODE(D.REFHIERARCHIE2,
                              NULL,
                              'N',
                              (SELECT NVL(FG_EXCL_FROM_EXTR, 'N')
                                 FROM G_DOSSIER
                                WHERE REFDOSS = D.REFHIERARCHIE2)) = 'N'
                   AND NVL(FG_FRM_INC, 'N') != 'O'
                   AND D.REFDOSS = T_INT.REFDOSS
                   AND VD_CATEGDOSS.VALEUR = D.CATEGDOSS
                   AND VD_CATEGDOSS.LANGUE = 'AN'
                   AND VD_PIECEINIT.VALEUR = D.PIECEINIT
                   AND VD_PIECEINIT.LANGUE = 'AN'
                   AND VD_PIECEINIT.CHAMP = 'pieceinit'
                   AND POLICY.REFDOSS(+) = D.REFHIERARCHIE
                   AND AUTH.TYPE = 'EXTR_GEST_CLIENT'
                   AND AUTH.ABREV = TO_CHAR(132)
                   AND T_INT.REFTYPE = AUTH.VALEUR_2
                   AND T_INT.REFINDIVIDU = AUTH.VALEUR
                   AND I.NUMSS LIKE UPPER('8101302770')
                 ORDER BY ID DESC NULLS FIRST) INN
         WHERE 1 = 1
           AND ROWNUM <= 11)
WHERE 1 = 1
   AND RECORD_NO >= 1;
/********************************OLD SQL*******************************************/
/********************************OLD Metrics***************************************/
/*
Plan hash value: 753559751
------------------------------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                                | Name                  | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  |
------------------------------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                                         |                       |      1 |        |    29 (100)|      3 |00:17:10.11 |      63M|   1129K|
|*  1 |  COUNT STOPKEY                                           |                       |      3 |        |            |      2 |00:00:00.01 |      16 |      6 |
|*  2 |   TABLE ACCESS BY INDEX ROWID BATCHED                    | T_FILIERE             |      3 |      1 |     1   (0)|      2 |00:00:00.01 |      16 |      6 |
|*  3 |    INDEX RANGE SCAN                                      | T_FIL_DTFINDEB        |      3 |      7 |     1   (0)|      4 |00:00:00.01 |      12 |      2 |
|*  4 |  COUNT STOPKEY                                           |                       |      3 |        |            |      3 |00:00:00.01 |      34 |      2 |
|   5 |   NESTED LOOPS                                           |                       |      3 |      1 |     2   (0)|      3 |00:00:00.01 |      34 |      2 |
|   6 |    NESTED LOOPS                                          |                       |      3 |      1 |     2   (0)|      3 |00:00:00.01 |      31 |      0 |
|*  7 |     TABLE ACCESS BY INDEX ROWID BATCHED                  | V_EXTR_DOM            |      3 |      1 |     1   (0)|      6 |00:00:00.01 |       9 |      0 |
|*  8 |      INDEX RANGE SCAN                                    | TYPEABREV             |      3 |      2 |     1   (0)|      6 |00:00:00.01 |       6 |      0 |
|*  9 |     INDEX RANGE SCAN                                     | INT_REFDOSS           |      6 |      1 |     1   (0)|      3 |00:00:00.01 |      22 |      0 |
|* 10 |    TABLE ACCESS BY INDEX ROWID                           | T_INTERVENANTS        |      3 |      1 |     1   (0)|      3 |00:00:00.01 |       3 |      2 |
|  11 |  TABLE ACCESS BY INDEX ROWID                             | T_INDIVIDU            |      1 |      1 |     1   (0)|      0 |00:00:00.01 |       1 |      0 |
|* 12 |   INDEX UNIQUE SCAN                                      | PK_T_INDIVIDU         |      1 |      1 |     1   (0)|      0 |00:00:00.01 |       1 |      0 |
|  13 |    SORT AGGREGATE                                        |                       |      1 |      1 |            |      1 |00:00:00.01 |       1 |      0 |
|  14 |     NESTED LOOPS                                         |                       |      1 |      1 |     3   (0)|      0 |00:00:00.01 |       1 |      0 |
|  15 |      NESTED LOOPS                                        |                       |      1 |      2 |     3   (0)|      0 |00:00:00.01 |       1 |      0 |
|  16 |       NESTED LOOPS                                       |                       |      1 |      1 |     2   (0)|      0 |00:00:00.01 |       1 |      0 |
|* 17 |        TABLE ACCESS BY INDEX ROWID BATCHED               | G_DOSSIER             |      1 |      1 |     1   (0)|      0 |00:00:00.01 |       1 |      0 |
|* 18 |         INDEX FULL SCAN                                  | DOSS_LOT              |      1 |      1 |     1   (0)|      0 |00:00:00.01 |       1 |      0 |
|  19 |        TABLE ACCESS BY INDEX ROWID                       | G_DOSSIER             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 20 |         INDEX UNIQUE SCAN                                | DOS_REFDOSS           |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 21 |       INDEX RANGE SCAN                                   | IX_T_INDIVIDU         |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 22 |      TABLE ACCESS BY INDEX ROWID                         | T_INDIVIDU            |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|  23 |  TABLE ACCESS BY INDEX ROWID BATCHED                     | V_DOMAINE             |      3 |      1 |     1   (0)|      2 |00:00:00.01 |      17 |      2 |
|* 24 |   INDEX RANGE SCAN                                       | DOM_TYPVAL            |      3 |      3 |     1   (0)|      2 |00:00:00.01 |      15 |      2 |
|  25 |    SORT AGGREGATE                                        |                       |      3 |      1 |            |      3 |00:00:00.01 |      10 |      2 |
|  26 |     TABLE ACCESS BY INDEX ROWID BATCHED                  | T_ATTENTE             |      3 |      1 |     1   (0)|      3 |00:00:00.01 |      10 |      2 |
|* 27 |      INDEX RANGE SCAN                                    | PK_ATTENTE            |      3 |      1 |     1   (0)|      3 |00:00:00.01 |       8 |      2 |
|* 28 |  COUNT STOPKEY                                           |                       |      3 |        |            |      1 |00:00:00.01 |      12 |      0 |
|* 29 |   INDEX RANGE SCAN                                       | INT_REFDOSS           |      3 |      3 |     1   (0)|      1 |00:00:00.01 |      12 |      0 |
|* 30 |  COUNT STOPKEY                                           |                       |      3 |        |            |      0 |00:00:00.01 |      12 |      0 |
|  31 |   NESTED LOOPS                                           |                       |      3 |      1 |     2   (0)|      0 |00:00:00.01 |      12 |      0 |
|* 32 |    TABLE ACCESS BY INDEX ROWID                           | G_DOSSIER             |      3 |      1 |     1   (0)|      0 |00:00:00.01 |      12 |      0 |
|* 33 |     INDEX UNIQUE SCAN                                    | DOS_REFDOSS           |      3 |      1 |     1   (0)|      3 |00:00:00.01 |       9 |      0 |
|  34 |    TABLE ACCESS BY INDEX ROWID BATCHED                   | G_PIECE               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 35 |     INDEX RANGE SCAN                                     | PIE_REFDOSS           |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 36 |  VIEW                                                    |                       |      1 |      1 |    29  (11)|      3 |00:17:10.11 |      63M|   1129K|
|* 37 |   COUNT STOPKEY                                          |                       |      1 |        |            |      3 |00:17:10.11 |      63M|   1129K|
|  38 |    VIEW                                                  |                       |      1 |      1 |    29  (11)|      3 |00:17:10.11 |      63M|   1129K|
|* 39 |     SORT UNIQUE STOPKEY                                  |                       |      1 |      1 |    28   (8)|      3 |00:17:10.11 |      63M|   1129K|
|  40 |      WINDOW SORT                                         |                       |      1 |      1 |    29  (11)|    571 |00:17:10.10 |      63M|   1129K|
|* 41 |       FILTER                                             |                       |      1 |        |            |    571 |00:17:10.10 |      63M|   1129K|
|  42 |        NESTED LOOPS                                      |                       |      1 |      1 |    16   (0)|    571 |00:17:10.10 |      63M|   1129K|
|* 43 |         HASH JOIN                                        |                       |      1 |      1 |    15   (0)|      3 |00:17:10.10 |      63M|   1129K|
|  44 |          JOIN FILTER CREATE                              | :BF0000               |      1 |      1 |    14   (0)|      3 |00:17:10.10 |      63M|   1129K|
|  45 |           NESTED LOOPS OUTER                             |                       |      1 |      1 |    14   (0)|      3 |00:17:10.10 |      63M|   1129K|
|  46 |            NESTED LOOPS OUTER                            |                       |      1 |      1 |    13   (0)|      3 |00:17:10.10 |      63M|   1129K|
|  47 |             NESTED LOOPS                                 |                       |      1 |      1 |    12   (0)|      3 |00:17:10.10 |      63M|   1129K|
|  48 |              NESTED LOOPS                                |                       |      1 |      1 |    11   (0)|      3 |00:17:10.10 |      63M|   1129K|
|  49 |               NESTED LOOPS                               |                       |      1 |      1 |    10   (0)|      3 |00:17:10.10 |      63M|   1129K|
|  50 |                NESTED LOOPS                              |                       |      1 |      1 |     9   (0)|      3 |00:17:10.10 |      63M|   1129K|
|  51 |                 NESTED LOOPS                             |                       |      1 |      1 |     8   (0)|   9225K|00:15:00.46 |      38M|   1046K|
|  52 |                  NESTED LOOPS                            |                       |      1 |      1 |     7   (0)|   9225K|00:14:34.90 |      32M|   1046K|
|  53 |                   NESTED LOOPS OUTER                     |                       |      1 |      1 |     6   (0)|   9410K|00:13:53.41 |      26M|   1046K|
|  54 |                    NESTED LOOPS OUTER                    |                       |      1 |      1 |     4   (0)|   9410K|00:12:44.18 |      22M|    999K|
|  55 |                     NESTED LOOPS                         |                       |      1 |      1 |     3   (0)|   9410K|00:12:36.72 |      22M|    999K|
|  56 |                      NESTED LOOPS                        |                       |      1 |      1 |     2   (0)|   9412K|00:00:37.86 |   50930 |  50835 |
|* 57 |                       TABLE ACCESS BY INDEX ROWID BATCHED| V_EXTR_DOM            |      1 |      1 |     1   (0)|      7 |00:00:00.01 |       5 |      4 |
|* 58 |                        INDEX RANGE SCAN                  | TYPEABREV             |      1 |      2 |     1   (0)|      7 |00:00:00.01 |       2 |      1 |
|* 59 |                       INDEX RANGE SCAN                   | INT_INDIV             |      7 |      1 |     1   (0)|   9412K|00:00:36.38 |   50925 |  50831 |
|* 60 |                      TABLE ACCESS BY INDEX ROWID         | G_DOSSIER             |   9412K|      1 |     1   (0)|   9410K|00:11:55.42 |      22M|    949K|
|* 61 |                       INDEX UNIQUE SCAN                  | DOS_REFDOSS           |   9412K|      1 |     1   (0)|   9410K|00:00:29.48 |    1104K|  23779 |
|* 62 |                     INDEX RANGE SCAN                     | LST_SCORE_REFDOSS_IDX |   9410K|      1 |     1   (0)|      0 |00:00:03.01 |       1 |      1 |
|  63 |                    VIEW PUSHED PREDICATE                 |                       |   9410K|      1 |     2   (0)|      0 |00:01:05.21 |    3787K|  46447 |
|  64 |                     NESTED LOOPS                         |                       |   9410K|      1 |     2   (0)|      0 |00:01:01.63 |    3787K|  46447 |
|  65 |                      NESTED LOOPS                        |                       |   9410K|      1 |     2   (0)|      0 |00:00:58.19 |    3787K|  46447 |
|  66 |                       TABLE ACCESS BY INDEX ROWID BATCHED| G_PIECE               |   9410K|      1 |     1   (0)|      0 |00:00:55.47 |    3787K|  46447 |
|* 67 |                        INDEX RANGE SCAN                  | PIE_REFDOSS           |   9410K|      1 |     1   (0)|      0 |00:00:50.75 |    3787K|  46447 |
|* 68 |                       INDEX RANGE SCAN                   | G_PIECEDET_REFP       |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 69 |                      TABLE ACCESS BY INDEX ROWID         | G_PIECEDET            |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 70 |                   TABLE ACCESS BY INDEX ROWID BATCHED    | V_DOMAINE             |   9410K|      1 |     1   (0)|   9225K|00:00:38.17 |    6660K|      0 |
|* 71 |                    INDEX RANGE SCAN                      | DOM_TYPVAL            |   9410K|      3 |     1   (0)|   9225K|00:00:28.80 |    6660K|      0 |
|* 72 |                    TABLE ACCESS FULL                     | G_ETUDE               |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 73 |                  INDEX RANGE SCAN                        | INT_REFDOSS           |   9225K|      1 |     1   (0)|   9225K|00:00:21.94 |    5634K|      3 |
|* 74 |                 TABLE ACCESS BY INDEX ROWID              | G_INDIVIDU            |   9225K|      1 |     1   (0)|      3 |00:02:07.75 |      24M|  83252 |
|* 75 |                  INDEX UNIQUE SCAN                       | IND_REFINDIV          |   9225K|      1 |     1   (0)|   9225K|00:00:30.75 |      16M|     91 |
|* 76 |                INDEX RANGE SCAN                          | INT_REFDOSS           |      3 |      1 |     1   (0)|      3 |00:00:00.01 |      11 |      0 |
|* 77 |               INDEX UNIQUE SCAN                          | IND_REFINDIV          |      3 |      1 |     1   (0)|      3 |00:00:00.01 |       8 |      0 |
|* 78 |              INDEX RANGE SCAN                            | PIE_REFDOSS           |      3 |      1 |     1   (0)|      3 |00:00:00.01 |       8 |      1 |
|  79 |             VIEW                                         | V_TDOMAINE            |      3 |      1 |     1   (0)|      3 |00:00:00.01 |      12 |      0 |
|  80 |              UNION ALL PUSHED PREDICATE                  |                       |      3 |        |            |      3 |00:00:00.01 |      12 |      0 |
|  81 |               TABLE ACCESS BY INDEX ROWID BATCHED        | V_DOMAINE             |      3 |      1 |     1   (0)|      3 |00:00:00.01 |      12 |      0 |
|* 82 |                INDEX RANGE SCAN                          | DOM_TYPABREV          |      3 |      2 |     1   (0)|      3 |00:00:00.01 |       9 |      0 |
|* 83 |               FILTER                                     |                       |      3 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  84 |                TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 85 |                 INDEX RANGE SCAN                         | DOM_TYPABREV          |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 86 |               FILTER                                     |                       |      3 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  87 |                TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 88 |                 INDEX RANGE SCAN                         | DOM_TYPABREV          |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 89 |               FILTER                                     |                       |      3 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  90 |                TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 91 |                 INDEX RANGE SCAN                         | DOM_TYPABREV          |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 92 |               FILTER                                     |                       |      3 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  93 |                TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 94 |                 INDEX RANGE SCAN                         | DOM_TYPABREV          |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 95 |               FILTER                                     |                       |      3 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  96 |                TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 97 |                 INDEX RANGE SCAN                         | DOM_TYPABREV          |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 98 |               FILTER                                     |                       |      3 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  99 |                TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*100 |                 INDEX RANGE SCAN                         | DOM_TYPABREV          |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*101 |               FILTER                                     |                       |      3 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 102 |                TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*103 |                 INDEX RANGE SCAN                         | DOM_TYPABREV          |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*104 |               FILTER                                     |                       |      3 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 105 |                TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*106 |                 INDEX RANGE SCAN                         | DOM_TYPABREV          |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*107 |               FILTER                                     |                       |      3 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 108 |                TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*109 |                 INDEX RANGE SCAN                         | DOM_TYPABREV          |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*110 |            VIEW                                          | V_TDOMAINE            |      3 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 111 |             UNION ALL PUSHED PREDICATE                   |                       |      3 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 112 |              TABLE ACCESS BY INDEX ROWID BATCHED         | V_DOMAINE             |      3 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*113 |               INDEX RANGE SCAN                           | DOM_TYPABREV          |      3 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*114 |              FILTER                                      |                       |      3 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 115 |               TABLE ACCESS BY INDEX ROWID BATCHED        | V_DOMAINE             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*116 |                INDEX RANGE SCAN                          | DOM_TYPABREV          |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*117 |              FILTER                                      |                       |      3 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 118 |               TABLE ACCESS BY INDEX ROWID BATCHED        | V_DOMAINE             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*119 |                INDEX RANGE SCAN                          | DOM_TYPABREV          |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*120 |              FILTER                                      |                       |      3 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 121 |               TABLE ACCESS BY INDEX ROWID BATCHED        | V_DOMAINE             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*122 |                INDEX RANGE SCAN                          | DOM_TYPABREV          |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*123 |              FILTER                                      |                       |      3 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 124 |               TABLE ACCESS BY INDEX ROWID BATCHED        | V_DOMAINE             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*125 |                INDEX RANGE SCAN                          | DOM_TYPABREV          |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*126 |              FILTER                                      |                       |      3 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 127 |               TABLE ACCESS BY INDEX ROWID BATCHED        | V_DOMAINE             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*128 |                INDEX RANGE SCAN                          | DOM_TYPABREV          |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*129 |              FILTER                                      |                       |      3 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 130 |               TABLE ACCESS BY INDEX ROWID BATCHED        | V_DOMAINE             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*131 |                INDEX RANGE SCAN                          | DOM_TYPABREV          |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*132 |              FILTER                                      |                       |      3 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 133 |               TABLE ACCESS BY INDEX ROWID BATCHED        | V_DOMAINE             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*134 |                INDEX RANGE SCAN                          | DOM_TYPABREV          |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*135 |              FILTER                                      |                       |      3 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 136 |               TABLE ACCESS BY INDEX ROWID BATCHED        | V_DOMAINE             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*137 |                INDEX RANGE SCAN                          | DOM_TYPABREV          |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*138 |              FILTER                                      |                       |      3 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 139 |               TABLE ACCESS BY INDEX ROWID BATCHED        | V_DOMAINE             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*140 |                INDEX RANGE SCAN                          | DOM_TYPABREV          |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 141 |          VIEW                                            | V_TDOMAINE            |      1 |     10 |     1   (0)|     20 |00:00:00.01 |      13 |      0 |
| 142 |           UNION-ALL                                      |                       |      1 |        |            |     20 |00:00:00.01 |      13 |      0 |
| 143 |            TABLE ACCESS BY INDEX ROWID BATCHED           | V_DOMAINE             |      1 |      1 |     1   (0)|     20 |00:00:00.01 |      13 |      0 |
|*144 |             INDEX RANGE SCAN                             | DOM_CHAMP             |      1 |      1 |     1   (0)|     20 |00:00:00.01 |       2 |      0 |
|*145 |            FILTER                                        |                       |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 146 |             JOIN FILTER USE                              | :BF0000               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 147 |              TABLE ACCESS BY INDEX ROWID BATCHED         | V_DOMAINE             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*148 |               INDEX RANGE SCAN                           | DOM_CHAMP             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*149 |            FILTER                                        |                       |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 150 |             JOIN FILTER USE                              | :BF0000               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 151 |              TABLE ACCESS BY INDEX ROWID BATCHED         | V_DOMAINE             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*152 |               INDEX RANGE SCAN                           | DOM_CHAMP             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*153 |            FILTER                                        |                       |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 154 |             JOIN FILTER USE                              | :BF0000               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 155 |              TABLE ACCESS BY INDEX ROWID BATCHED         | V_DOMAINE             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*156 |               INDEX RANGE SCAN                           | DOM_CHAMP             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*157 |            FILTER                                        |                       |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 158 |             JOIN FILTER USE                              | :BF0000               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 159 |              TABLE ACCESS BY INDEX ROWID BATCHED         | V_DOMAINE             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*160 |               INDEX RANGE SCAN                           | DOM_CHAMP             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*161 |            FILTER                                        |                       |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 162 |             JOIN FILTER USE                              | :BF0000               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 163 |              TABLE ACCESS BY INDEX ROWID BATCHED         | V_DOMAINE             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*164 |               INDEX RANGE SCAN                           | DOM_CHAMP             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*165 |            FILTER                                        |                       |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 166 |             JOIN FILTER USE                              | :BF0000               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 167 |              TABLE ACCESS BY INDEX ROWID BATCHED         | V_DOMAINE             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*168 |               INDEX RANGE SCAN                           | DOM_CHAMP             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*169 |            FILTER                                        |                       |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 170 |             JOIN FILTER USE                              | :BF0000               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 171 |              TABLE ACCESS BY INDEX ROWID BATCHED         | V_DOMAINE             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*172 |               INDEX RANGE SCAN                           | DOM_CHAMP             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*173 |            FILTER                                        |                       |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 174 |             JOIN FILTER USE                              | :BF0000               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 175 |              TABLE ACCESS BY INDEX ROWID BATCHED         | V_DOMAINE             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*176 |               INDEX RANGE SCAN                           | DOM_CHAMP             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*177 |            FILTER                                        |                       |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 178 |             JOIN FILTER USE                              | :BF0000               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 179 |              TABLE ACCESS BY INDEX ROWID BATCHED         | V_DOMAINE             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*180 |               INDEX RANGE SCAN                           | DOM_CHAMP             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 181 |         VIEW                                             | V_TDOMAINE            |      3 |      1 |     1   (0)|    571 |00:00:00.01 |      10 |      0 |
| 182 |          UNION ALL PUSHED PREDICATE                      |                       |      3 |        |            |    571 |00:00:00.01 |      10 |      0 |
|*183 |           FILTER                                         |                       |      3 |        |            |    571 |00:00:00.01 |      10 |      0 |
|*184 |            INDEX RANGE SCAN                              | DOM_TYPVAL            |      3 |      2 |     1   (0)|    571 |00:00:00.01 |      10 |      0 |
|*185 |           FILTER                                         |                       |      3 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*186 |            INDEX RANGE SCAN                              | DOM_TYPVAL            |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*187 |           FILTER                                         |                       |      3 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*188 |            INDEX RANGE SCAN                              | DOM_TYPVAL            |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*189 |           FILTER                                         |                       |      3 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*190 |            INDEX RANGE SCAN                              | DOM_TYPVAL            |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*191 |           FILTER                                         |                       |      3 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*192 |            INDEX RANGE SCAN                              | DOM_TYPVAL            |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*193 |           FILTER                                         |                       |      3 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*194 |            INDEX RANGE SCAN                              | DOM_TYPVAL            |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*195 |           FILTER                                         |                       |      3 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*196 |            INDEX RANGE SCAN                              | DOM_TYPVAL            |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*197 |           FILTER                                         |                       |      3 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*198 |            INDEX RANGE SCAN                              | DOM_TYPVAL            |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*199 |           FILTER                                         |                       |      3 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*200 |            INDEX RANGE SCAN                              | DOM_TYPVAL            |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*201 |           FILTER                                         |                       |      3 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*202 |            INDEX RANGE SCAN                              | DOM_TYPVAL            |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 203 |        TABLE ACCESS BY INDEX ROWID                       | G_DOSSIER             |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       6 |      0 |
|*204 |         INDEX UNIQUE SCAN                                | DOS_REFDOSS           |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |      0 |
| 205 |        TABLE ACCESS BY INDEX ROWID                       | G_DOSSIER             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*206 |         INDEX UNIQUE SCAN                                | DOS_REFDOSS           |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
------------------------------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   1 - filter(ROWNUM=1)
   2 - filter("DTFIN_DT" IS NULL)
   3 - access("REFDOSS"=:B1)
   4 - filter(ROWNUM=1)
   7 - filter("AUTH"."VALEUR_2" IS NOT NULL)
   8 - access("AUTH"."TYPE"='EXTR_GEST_CLIENT' AND "AUTH"."ABREV"='132')
   9 - access("TI"."REFDOSS"=:B1 AND "TI"."REFTYPE"="AUTH"."VALEUR_2" AND "TI"."REFINDIVIDU"="AUTH"."VALEUR")
  10 - filter("TI"."REFDOSSEXT" IS NOT NULL)
  12 - access("IMX_UN_ID"=)
  17 - filter(("DECOMPTE"."REFDOSS"=:B1 AND "DECOMPTE"."CATEGDOSS" LIKE 'DECOMPTE%'))
  18 - filter("DECOMPTE"."REFLOT" IS NOT NULL)
  20 - access("DECOMPTE"."REFLOT"="CONTR"."REFDOSS")
  21 - access("REFINDIVIDU"=:B1)
  22 - filter(("REFEXT3" IS NOT NULL AND "REFEXT3"="CONTR"."ANCREFDOSS" AND "REFEXT2"=:B1 AND "SOCIETE"='CLIENT_NUMBER'))
  24 - access("VALEUR"= AND "TYPE"='typencour')
  27 - access("TA"."REFENTITE"=:B1)
  28 - filter(ROWNUM=1)
  29 - access("SR"."REFDOSS"=:B1)
       filter(("SR"."REFTYPE"<>'DB' AND "SR"."REFTYPE"<>'CL' AND "SR"."REFTYPE"<>'XX'))
  30 - filter(ROWNUM=1)
  32 - filter("G"."CATEGDOSS" LIKE 'COLLECTION%')
  33 - access("G"."REFDOSS"=:B1)
  35 - access("PIECE"."REFDOSS"=:B1 AND "PIECE"."TYPPIECE"='DBT_VERIF_REQ')
  36 - filter("RECORD_NO">=1)
  37 - filter(ROWNUM<=11)
  39 - filter(ROWNUM<=11)
  41 - filter((DECODE("D"."REFHIERARCHIE",NULL,'N',)='N' AND DECODE("D"."REFHIERARCHIE2",NULL,'N',)='N'))
  43 - access("VD_PIECEINIT"."VALEUR"="D"."PIECEINIT")
  57 - filter("AUTH"."VALEUR_2" IS NOT NULL)
  58 - access("AUTH"."TYPE"='EXTR_GEST_CLIENT' AND "AUTH"."ABREV"='132')
  59 - access("T_INT"."REFINDIVIDU"="AUTH"."VALEUR" AND "T_INT"."REFTYPE"="AUTH"."VALEUR_2")
  60 - filter(("D"."CATEGDOSS"<>'COMPTE DB CTR' AND NVL("D"."FG_EXCL_FROM_EXTR",'N')<>'O' AND NVL("FG_FRM_INC",'N')<>'O'))
  61 - access("D"."REFDOSS"="T_INT"."REFDOSS")
       filter("D"."REFDOSS" NOT LIKE 'GL%')
  62 - access("LST"."REFDOSS"="D"."REFDOSS")
  67 - access("P"."REFDOSS"="D"."REFHIERARCHIE" AND "P"."TYPPIECE"='CONTRAT')
  68 - access("PD"."REFPIECE"="P"."REFPIECE" AND "PD"."TYPE"='CI CONTRACTS')
  69 - filter("PD"."FG01"='O')
  70 - filter(("ECRAN"='X' OR  IS NOT NULL))
  71 - access("D"."CATEGDOSS"="VALEUR" AND "TYPE"='categdoss')
       filter("VALEUR"<>'COMPTE DB CTR')
  72 - filter(("ACTIVITE_GPC"='G' OR "ACTIVITE_GPC"='T'))
  73 - access("D"."REFDOSS"="T"."REFDOSS" AND "T"."REFTYPE"='DB')
  74 - filter("I"."NUMSS"='8101302770')
  75 - access("T"."REFINDIVIDU"="I"."REFINDIVIDU")
  76 - access("D"."REFDOSS"="CLIENT"."REFDOSS")
       filter(("CLIENT"."REFTYPE"='CL' OR "CLIENT"."REFTYPE"='TC'))
  77 - access("ICL"."REFINDIVIDU"="CLIENT"."REFINDIVIDU")
  78 - access("PIECECASE"."REFDOSS"="D"."REFDOSS" AND "PIECECASE"."TYPPIECE"="D"."PIECEINIT")
  82 - access("TYPE"='pays' AND "ABREV"="I"."PAYS")
  83 - filter(NULL IS NOT NULL)
  85 - access("TYPE"='pays' AND "ABREV"="I"."PAYS")
  86 - filter(NULL IS NOT NULL)
  88 - access("TYPE"='pays' AND "ABREV"="I"."PAYS")
  89 - filter(NULL IS NOT NULL)
  91 - access("TYPE"='pays' AND "ABREV"="I"."PAYS")
  92 - filter(NULL IS NOT NULL)
  94 - access("TYPE"='pays' AND "ABREV"="I"."PAYS")
  95 - filter(NULL IS NOT NULL)
  97 - access("TYPE"='pays' AND "ABREV"="I"."PAYS")
  98 - filter(NULL IS NOT NULL)
100 - access("TYPE"='pays' AND "ABREV"="I"."PAYS")
101 - filter(NULL IS NOT NULL)
103 - access("TYPE"='pays' AND "ABREV"="I"."PAYS")
104 - filter(NULL IS NOT NULL)
106 - access("TYPE"='pays' AND "ABREV"="I"."PAYS")
107 - filter(NULL IS NOT NULL)
109 - access("TYPE"='pays' AND "ABREV"="I"."PAYS")
110 - filter("VD_DIV"."ECRAN"="I"."PAYS")
113 - access("TYPE"='DIVISION TERRITORIALE' AND "ABREV"="I"."DIVISION")
114 - filter(NULL IS NOT NULL)
116 - access("TYPE"='DIVISION TERRITORIALE' AND "ABREV"="I"."DIVISION")
117 - filter(NULL IS NOT NULL)
119 - access("TYPE"='DIVISION TERRITORIALE' AND "ABREV"="I"."DIVISION")
120 - filter(NULL IS NOT NULL)
122 - access("TYPE"='DIVISION TERRITORIALE' AND "ABREV"="I"."DIVISION")
123 - filter(NULL IS NOT NULL)
125 - access("TYPE"='DIVISION TERRITORIALE' AND "ABREV"="I"."DIVISION")
126 - filter(NULL IS NOT NULL)
128 - access("TYPE"='DIVISION TERRITORIALE' AND "ABREV"="I"."DIVISION")
129 - filter(NULL IS NOT NULL)
131 - access("TYPE"='DIVISION TERRITORIALE' AND "ABREV"="I"."DIVISION")
132 - filter(NULL IS NOT NULL)
134 - access("TYPE"='DIVISION TERRITORIALE' AND "ABREV"="I"."DIVISION")
135 - filter(NULL IS NOT NULL)
137 - access("TYPE"='DIVISION TERRITORIALE' AND "ABREV"="I"."DIVISION")
138 - filter(NULL IS NOT NULL)
140 - access("TYPE"='DIVISION TERRITORIALE' AND "ABREV"="I"."DIVISION")
144 - access("CHAMP"='pieceinit')
145 - filter(NULL IS NOT NULL)
148 - access("CHAMP"='pieceinit')
149 - filter(NULL IS NOT NULL)
152 - access("CHAMP"='pieceinit')
153 - filter(NULL IS NOT NULL)
156 - access("CHAMP"='pieceinit')
157 - filter(NULL IS NOT NULL)
160 - access("CHAMP"='pieceinit')
161 - filter(NULL IS NOT NULL)
164 - access("CHAMP"='pieceinit')
165 - filter(NULL IS NOT NULL)
168 - access("CHAMP"='pieceinit')
169 - filter(NULL IS NOT NULL)
172 - access("CHAMP"='pieceinit')
173 - filter(NULL IS NOT NULL)
176 - access("CHAMP"='pieceinit')
177 - filter(NULL IS NOT NULL)
180 - access("CHAMP"='pieceinit')
183 - filter("D"."CATEGDOSS"<>'COMPTE DB CTR')
184 - access("VALEUR"="D"."CATEGDOSS")
       filter("VALEUR"<>'COMPTE DB CTR')
185 - filter((NULL IS NOT NULL AND "D"."CATEGDOSS"<>'COMPTE DB CTR'))
186 - access("VALEUR"="D"."CATEGDOSS")
       filter("VALEUR"<>'COMPTE DB CTR')
187 - filter((NULL IS NOT NULL AND "D"."CATEGDOSS"<>'COMPTE DB CTR'))
188 - access("VALEUR"="D"."CATEGDOSS")
       filter("VALEUR"<>'COMPTE DB CTR')
189 - filter((NULL IS NOT NULL AND "D"."CATEGDOSS"<>'COMPTE DB CTR'))
190 - access("VALEUR"="D"."CATEGDOSS")
       filter("VALEUR"<>'COMPTE DB CTR')
191 - filter((NULL IS NOT NULL AND "D"."CATEGDOSS"<>'COMPTE DB CTR'))
192 - access("VALEUR"="D"."CATEGDOSS")
       filter("VALEUR"<>'COMPTE DB CTR')
193 - filter((NULL IS NOT NULL AND "D"."CATEGDOSS"<>'COMPTE DB CTR'))
194 - access("VALEUR"="D"."CATEGDOSS")
       filter("VALEUR"<>'COMPTE DB CTR')
195 - filter((NULL IS NOT NULL AND "D"."CATEGDOSS"<>'COMPTE DB CTR'))
196 - access("VALEUR"="D"."CATEGDOSS")
       filter("VALEUR"<>'COMPTE DB CTR')
197 - filter((NULL IS NOT NULL AND "D"."CATEGDOSS"<>'COMPTE DB CTR'))
198 - access("VALEUR"="D"."CATEGDOSS")
       filter("VALEUR"<>'COMPTE DB CTR')
199 - filter((NULL IS NOT NULL AND "D"."CATEGDOSS"<>'COMPTE DB CTR'))
200 - access("VALEUR"="D"."CATEGDOSS")
       filter("VALEUR"<>'COMPTE DB CTR')
201 - filter((NULL IS NOT NULL AND "D"."CATEGDOSS"<>'COMPTE DB CTR'))
202 - access("VALEUR"="D"."CATEGDOSS")
       filter("VALEUR"<>'COMPTE DB CTR')
204 - access("REFDOSS"=:B1)
206 - access("REFDOSS"=:B1)

*/
/********************************OLD Metrics***************************************/

/********************************New SQL*******************************************/

SELECT *
  FROM (SELECT INN.*,
               ROWNUM RECORD_NO
          FROM ( SELECT /*+ leading(I) index(I NUMSS_IDX) */
                        DISTINCT COUNT(DISTINCT D.REFDOSS) OVER(PARTITION BY 'const') OUT_OF,
                                 D.EXT_REFERENCE_U1 UNIQUEREFERENCE,
                                 ( SELECT DTAR_DT
                                     FROM T_FILIERE
                                    WHERE REFDOSS = D.REFDOSS
                                      AND DTFIN_DT IS NULL
                                      AND ROWNUM = 1 ) ACKNOWLEDGEDATE,
                                 D.REFDOSS ID,
                                 D.ANCREFDOSS ANCREFDOSS,
                                 ( SELECT TI.REFDOSSEXT
                                     FROM T_INTERVENANTS TI,
                                          V_EXTR_DOM AUTH
                                    WHERE AUTH.TYPE = 'EXTR_GEST_CLIENT'
                                      AND AUTH.ABREV = TO_CHAR(132)
                                      AND TI.REFTYPE = AUTH.VALEUR_2
                                      AND TI.REFINDIVIDU = AUTH.VALEUR
                                      AND TI.REFDOSS = D.REFDOSS
                                      AND TI.REFDOSSEXT IS NOT NULL
                                      AND ROWNUM = 1 ) REFDOSSEXT,
                                  ( SELECT REFEXT
                                      FROM T_INDIVIDU TID
                                     WHERE IMX_UN_ID = ( SELECT MAX(IMX_UN_ID)
                                                           FROM T_INDIVIDU,
                                                                G_DOSSIER  CONTR,
                                                                G_DOSSIER  DECOMPTE
                                                          WHERE SOCIETE = 'CLIENT_NUMBER'
                                                            AND REFINDIVIDU = I.REFINDIVIDU
                                                            AND REFEXT2 = CLIENT.REFINDIVIDU
                                                            AND REFEXT3 = CONTR.ANCREFDOSS
                                                            AND DECOMPTE.CATEGDOSS LIKE
                                                                'DECOMPTE%'
                                                            AND DECOMPTE.REFDOSS = D.REFLOT
                                                            AND DECOMPTE.REFLOT = CONTR.REFDOSS ) ) YOURNUMBER,
                                TRIM(I.NOM || DECODE(I.PRENOM, NULL, '', ', ' || I.PRENOM ) ) AS DEBTORFULLNAME,
                                DECODE(I.ADR1, NULL, '', I.ADR1 || ', ') ||
                                DECODE(I.ADR2, NULL, '', I.ADR2 || ', ') ||
                                DECODE(I.VILLE, NULL, '', I.VILLE || ', ') ||
                                DECODE(I.CP, NULL, '', I.CP || ', ') ||
                                DECODE(NVL(VD_DIV.VALEUR_TRAD, VD_DIV.VALEUR), NULL, '', NVL(VD_DIV.VALEUR_TRAD, VD_DIV.VALEUR) || ', ') ||
                                NVL(VD.VALEUR_TRAD, VD.VALEUR) AS DEBTORFULLADDRESS,
                                I.CP DEBTORPC,
                                I.VILLE DEBTORCITY,
                                POLICY.STR1 POLICYNUMBER,
                                I.ADR1 DEBTORADR1,
                                I.DIVISION DEBTORSTATE,
                                NVL(VD.VALEUR_TRAD, VD.VALEUR) DEBTORCOUNTRY,
                                NVL(D.SOLDEDB_DOS, 0) BALANCE,
                                D.DT_DT_DT CASEDATE,
                                NVL( ( SELECT DECODE( ABREV,
                                                      'CLO',
                                                      'Closed',
                                                      'Active' )
                                         FROM V_DOMAINE
                                        WHERE TYPE = 'typencour'
                                          AND VALEUR = ( SELECT MAX(TA.TYPENCOUR)
                                                           FROM T_ATTENTE TA
                                                          WHERE TA.REFENTITE = D.REFDOSS ) ),
                                    'Active' ) CASE_TYPE,
                                D.DEVISE CURRENCY,
                                ( SELECT 1
                                    FROM T_INTERVENANTS SR
                                   WHERE SR.REFTYPE NOT IN ('DB', 'CL', 'XX')
                                     AND ROWNUM = 1
                                     AND SR.REFDOSS = D.REFDOSS ) THIRDPARTYINVOLVED,
                                DECODE( ( SELECT PIECE.REFPIECE
                                            FROM G_DOSSIER G, 
                                                 G_PIECE PIECE
                                           WHERE PIECE.TYPPIECE = 'DBT_VERIF_REQ'
                                             AND PIECE.REFDOSS = G.REFDOSS
                                             AND G.CATEGDOSS LIKE 'COLLECTION%'
                                             AND G.REFDOSS = D.REFDOSS
                                             AND ROWNUM = 1 ),
                                       NULL,
                                       'false',
                                       'true' ) AS ISDEBTVERIF,
                                SUM( NVL( D.SOLDEDB, 0 ) ) OVER() AS TOTAL_SUM
                  FROM G_DOSSIER D,
                       G_PIECE PIECECASE,
                       T_INTERVENANTS T,
                       ( SELECT PD.STR1 STR1, 
                                P.REFDOSS REFDOSS
                           FROM G_PIECE P, 
                                G_PIECEDET PD
                          WHERE P.TYPPIECE = 'CONTRAT'
                            AND PD.TYPE = 'CI CONTRACTS'
                            AND PD.REFPIECE = P.REFPIECE
                            AND PD.FG01 = 'O' ) POLICY,
                       G_INDIVIDU I,
                       T_INTERVENANTS CLIENT,
                       G_INDIVIDU ICL,
                       V_TDOMAINE VD,
                       T_INTERVENANTS T_INT,
                       LST_SCORE LST,
                       ( SELECT VALEUR
                           FROM V_DOMAINE
                          WHERE TYPE = 'categdoss'
                            AND ( ECRAN = 'X' 
                               OR EXISTS ( SELECT 1
                                             FROM G_ETUDE
                                            WHERE ACTIVITE_GPC IN ('G', 'T')))) VD_CAT,
                       V_TDOMAINE VD_DIV,
                       V_TDOMAINE VD_CATEGDOSS,
                       V_TDOMAINE VD_PIECEINIT,
                       V_EXTR_DOM AUTH
                 WHERE D.CATEGDOSS = VD_CAT.VALEUR
                   AND PIECECASE.REFDOSS = D.REFDOSS
                   AND PIECECASE.TYPPIECE = D.PIECEINIT
                   AND LST.REFDOSS(+) = D.REFDOSS
                   AND D.CATEGDOSS <> 'COMPTE DB CTR'
                   AND D.REFDOSS = T.REFDOSS
                   AND T.REFTYPE = 'DB'
                   AND T.REFINDIVIDU = I.REFINDIVIDU
                   AND D.REFDOSS NOT LIKE 'GL%'
                   AND D.REFDOSS = CLIENT.REFDOSS
                   AND CLIENT.REFTYPE IN ('CL', 'TC')
                   AND ICL.REFINDIVIDU = CLIENT.REFINDIVIDU
                   AND VD.TYPE(+) = 'pays'
                   AND VD.LANGUE(+) = 'AN'
                   AND VD.ABREV(+) = I.PAYS
                   AND VD_DIV.TYPE(+) = 'DIVISION TERRITORIALE'
                   AND VD_DIV.ECRAN(+) = I.PAYS
                   AND VD_DIV.LANGUE(+) = 'AN'
                   AND VD_DIV.ABREV(+) = I.DIVISION
                   AND NVL(D.FG_EXCL_FROM_EXTR, 'N') != 'O'
                   AND DECODE(D.REFHIERARCHIE,
                              NULL,
                              'N',
                              (SELECT NVL(FG_EXCL_FROM_EXTR, 'N')
                                 FROM G_DOSSIER
                                WHERE REFDOSS = D.REFHIERARCHIE)) = 'N'
                   AND DECODE(D.REFHIERARCHIE2,
                              NULL,
                              'N',
                              (SELECT NVL(FG_EXCL_FROM_EXTR, 'N')
                                 FROM G_DOSSIER
                                WHERE REFDOSS = D.REFHIERARCHIE2)) = 'N'
                   AND NVL(FG_FRM_INC, 'N') != 'O'
                   AND D.REFDOSS = T_INT.REFDOSS
                   AND VD_CATEGDOSS.VALEUR = D.CATEGDOSS
                   AND VD_CATEGDOSS.LANGUE = 'AN'
                   AND VD_PIECEINIT.VALEUR = D.PIECEINIT
                   AND VD_PIECEINIT.LANGUE = 'AN'
                   AND VD_PIECEINIT.CHAMP = 'pieceinit'
                   AND POLICY.REFDOSS(+) = D.REFHIERARCHIE
                   AND AUTH.TYPE = 'EXTR_GEST_CLIENT'
                   AND AUTH.ABREV = TO_CHAR(132)
                   AND T_INT.REFTYPE = AUTH.VALEUR_2
                   AND T_INT.REFINDIVIDU = AUTH.VALEUR
                   AND I.NUMSS LIKE UPPER('8101302770')
                 ORDER BY ID DESC NULLS FIRST) INN
         WHERE 1 = 1
           AND ROWNUM <= 11)
WHERE 1 = 1
   AND RECORD_NO >= 1;
/********************************New SQL*******************************************/
/********************************New Metrics***************************************/
/*
Plan hash value: 2158131282
------------------------------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                                | Name                  | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  |
------------------------------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                                         |                       |      1 |        |    29 (100)|      3 |00:00:00.04 |    1432 |     15 |
|*  1 |  COUNT STOPKEY                                           |                       |      3 |        |            |      2 |00:00:00.01 |      16 |      5 |
|*  2 |   TABLE ACCESS BY INDEX ROWID BATCHED                    | T_FILIERE             |      3 |      1 |     1   (0)|      2 |00:00:00.01 |      16 |      5 |
|*  3 |    INDEX RANGE SCAN                                      | T_FIL_DTFINDEB        |      3 |      7 |     1   (0)|      4 |00:00:00.01 |      12 |      2 |
|*  4 |  COUNT STOPKEY                                           |                       |      3 |        |            |      3 |00:00:00.01 |      34 |      2 |
|   5 |   NESTED LOOPS                                           |                       |      3 |      1 |     2   (0)|      3 |00:00:00.01 |      34 |      2 |
|   6 |    NESTED LOOPS                                          |                       |      3 |      1 |     2   (0)|      3 |00:00:00.01 |      31 |      0 |
|*  7 |     TABLE ACCESS BY INDEX ROWID BATCHED                  | V_EXTR_DOM            |      3 |      1 |     1   (0)|      6 |00:00:00.01 |       9 |      0 |
|*  8 |      INDEX RANGE SCAN                                    | TYPEABREV             |      3 |      2 |     1   (0)|      6 |00:00:00.01 |       6 |      0 |
|*  9 |     INDEX RANGE SCAN                                     | INT_REFDOSS           |      6 |      1 |     1   (0)|      3 |00:00:00.01 |      22 |      0 |
|* 10 |    TABLE ACCESS BY INDEX ROWID                           | T_INTERVENANTS        |      3 |      1 |     1   (0)|      3 |00:00:00.01 |       3 |      2 |
|  11 |  TABLE ACCESS BY INDEX ROWID                             | T_INDIVIDU            |      1 |      1 |     1   (0)|      0 |00:00:00.01 |       1 |      0 |
|* 12 |   INDEX UNIQUE SCAN                                      | PK_T_INDIVIDU         |      1 |      1 |     1   (0)|      0 |00:00:00.01 |       1 |      0 |
|  13 |    SORT AGGREGATE                                        |                       |      1 |      1 |            |      1 |00:00:00.01 |       1 |      0 |
|  14 |     NESTED LOOPS                                         |                       |      1 |      1 |     3   (0)|      0 |00:00:00.01 |       1 |      0 |
|  15 |      NESTED LOOPS                                        |                       |      1 |      2 |     3   (0)|      0 |00:00:00.01 |       1 |      0 |
|  16 |       NESTED LOOPS                                       |                       |      1 |      1 |     2   (0)|      0 |00:00:00.01 |       1 |      0 |
|* 17 |        TABLE ACCESS BY INDEX ROWID BATCHED               | G_DOSSIER             |      1 |      1 |     1   (0)|      0 |00:00:00.01 |       1 |      0 |
|* 18 |         INDEX FULL SCAN                                  | DOSS_LOT              |      1 |      1 |     1   (0)|      0 |00:00:00.01 |       1 |      0 |
|  19 |        TABLE ACCESS BY INDEX ROWID                       | G_DOSSIER             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 20 |         INDEX UNIQUE SCAN                                | DOS_REFDOSS           |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 21 |       INDEX RANGE SCAN                                   | IX_T_INDIVIDU         |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 22 |      TABLE ACCESS BY INDEX ROWID                         | T_INDIVIDU            |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|  23 |  TABLE ACCESS BY INDEX ROWID BATCHED                     | V_DOMAINE             |      3 |      1 |     1   (0)|      2 |00:00:00.01 |      17 |      1 |
|* 24 |   INDEX RANGE SCAN                                       | DOM_TYPVAL            |      3 |      3 |     1   (0)|      2 |00:00:00.01 |      15 |      1 |
|  25 |    SORT AGGREGATE                                        |                       |      3 |      1 |            |      3 |00:00:00.01 |      10 |      1 |
|  26 |     TABLE ACCESS BY INDEX ROWID BATCHED                  | T_ATTENTE             |      3 |      1 |     1   (0)|      3 |00:00:00.01 |      10 |      1 |
|* 27 |      INDEX RANGE SCAN                                    | PK_ATTENTE            |      3 |      1 |     1   (0)|      3 |00:00:00.01 |       8 |      1 |
|* 28 |  COUNT STOPKEY                                           |                       |      3 |        |            |      1 |00:00:00.01 |      12 |      0 |
|* 29 |   INDEX RANGE SCAN                                       | INT_REFDOSS           |      3 |      3 |     1   (0)|      1 |00:00:00.01 |      12 |      0 |
|* 30 |  COUNT STOPKEY                                           |                       |      3 |        |            |      0 |00:00:00.01 |      12 |      0 |
|  31 |   NESTED LOOPS                                           |                       |      3 |      1 |     2   (0)|      0 |00:00:00.01 |      12 |      0 |
|* 32 |    TABLE ACCESS BY INDEX ROWID                           | G_DOSSIER             |      3 |      1 |     1   (0)|      0 |00:00:00.01 |      12 |      0 |
|* 33 |     INDEX UNIQUE SCAN                                    | DOS_REFDOSS           |      3 |      1 |     1   (0)|      3 |00:00:00.01 |       9 |      0 |
|  34 |    TABLE ACCESS BY INDEX ROWID BATCHED                   | G_PIECE               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 35 |     INDEX RANGE SCAN                                     | PIE_REFDOSS           |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 36 |  VIEW                                                    |                       |      1 |      1 |    29  (11)|      3 |00:00:00.04 |    1432 |     15 |
|* 37 |   COUNT STOPKEY                                          |                       |      1 |        |            |      3 |00:00:00.04 |    1432 |     15 |
|  38 |    VIEW                                                  |                       |      1 |      1 |    29  (11)|      3 |00:00:00.04 |    1432 |     15 |
|* 39 |     SORT UNIQUE STOPKEY                                  |                       |      1 |      1 |    28   (8)|      3 |00:00:00.04 |    1432 |     15 |
|  40 |      WINDOW SORT                                         |                       |      1 |      1 |    29  (11)|    571 |00:00:00.03 |    1340 |      7 |
|* 41 |       FILTER                                             |                       |      1 |        |            |    571 |00:00:00.03 |    1340 |      7 |
|  42 |        NESTED LOOPS OUTER                                |                       |      1 |      1 |    16   (0)|    571 |00:00:00.03 |    1334 |      7 |
|  43 |         NESTED LOOPS OUTER                               |                       |      1 |      1 |    15   (0)|    571 |00:00:00.02 |    1334 |      7 |
|  44 |          NESTED LOOPS                                    |                       |      1 |      1 |    14   (0)|    571 |00:00:00.01 |     182 |      7 |
|  45 |           NESTED LOOPS                                   |                       |      1 |      1 |    13   (0)|   1247 |00:00:00.01 |     173 |      5 |
|  46 |            NESTED LOOPS                                  |                       |      1 |      1 |    12   (0)|    571 |00:00:00.01 |     136 |      5 |
|  47 |             NESTED LOOPS                                 |                       |      1 |      1 |    11   (0)|    571 |00:00:00.01 |     110 |      4 |
|  48 |              NESTED LOOPS                                |                       |      1 |      1 |    10   (0)|    571 |00:00:00.01 |      96 |      4 |
|  49 |               NESTED LOOPS                               |                       |      1 |      1 |     9   (0)|    571 |00:00:00.01 |      59 |      4 |
|* 50 |                HASH JOIN                                 |                       |      1 |      1 |     8   (0)|      3 |00:00:00.01 |      49 |      4 |
|  51 |                 NESTED LOOPS                             |                       |      1 |      1 |     7   (0)|      3 |00:00:00.01 |      35 |      4 |
|  52 |                  NESTED LOOPS                            |                       |      1 |      3 |     7   (0)|      3 |00:00:00.01 |      34 |      4 |
|  53 |                   NESTED LOOPS OUTER                     |                       |      1 |      1 |     6   (0)|      3 |00:00:00.01 |      29 |      4 |
|  54 |                    NESTED LOOPS OUTER                    |                       |      1 |      1 |     4   (0)|      3 |00:00:00.01 |      26 |      3 |
|  55 |                     NESTED LOOPS                         |                       |      1 |      1 |     3   (0)|      3 |00:00:00.01 |      25 |      3 |
|  56 |                      NESTED LOOPS                        |                       |      1 |      1 |     2   (0)|      3 |00:00:00.01 |       9 |      3 |
|  57 |                       TABLE ACCESS BY INDEX ROWID BATCHED| G_INDIVIDU            |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       5 |      2 |
|* 58 |                        INDEX RANGE SCAN                  | NUMSS_IDX             |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |      1 |
|* 59 |                       INDEX RANGE SCAN                   | INT_INDIV             |      1 |      1 |     1   (0)|      3 |00:00:00.01 |       4 |      1 |
|* 60 |                      TABLE ACCESS BY INDEX ROWID         | G_DOSSIER             |      3 |      1 |     1   (0)|      3 |00:00:00.01 |      16 |      0 |
|* 61 |                       INDEX UNIQUE SCAN                  | DOS_REFDOSS           |      3 |      1 |     1   (0)|      3 |00:00:00.01 |       8 |      0 |
|* 62 |                     INDEX RANGE SCAN                     | LST_SCORE_REFDOSS_IDX |      3 |      1 |     1   (0)|      0 |00:00:00.01 |       1 |      0 |
|  63 |                    VIEW PUSHED PREDICATE                 |                       |      3 |      1 |     2   (0)|      0 |00:00:00.01 |       3 |      1 |
|  64 |                     NESTED LOOPS                         |                       |      3 |      1 |     2   (0)|      0 |00:00:00.01 |       3 |      1 |
|  65 |                      NESTED LOOPS                        |                       |      3 |      1 |     2   (0)|      0 |00:00:00.01 |       3 |      1 |
|  66 |                       TABLE ACCESS BY INDEX ROWID BATCHED| G_PIECE               |      3 |      1 |     1   (0)|      0 |00:00:00.01 |       3 |      1 |
|* 67 |                        INDEX RANGE SCAN                  | PIE_REFDOSS           |      3 |      1 |     1   (0)|      0 |00:00:00.01 |       3 |      1 |
|* 68 |                       INDEX RANGE SCAN                   | G_PIECEDET_REFP       |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 69 |                      TABLE ACCESS BY INDEX ROWID         | G_PIECEDET            |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 70 |                   INDEX RANGE SCAN                       | DOM_TYPVAL            |      3 |      3 |     1   (0)|      3 |00:00:00.01 |       5 |      0 |
|* 71 |                  TABLE ACCESS BY INDEX ROWID             | V_DOMAINE             |      3 |      1 |     1   (0)|      3 |00:00:00.01 |       1 |      0 |
|* 72 |                   TABLE ACCESS FULL                      | G_ETUDE               |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|  73 |                 VIEW                                     | V_TDOMAINE            |      1 |     10 |     1   (0)|     20 |00:00:00.01 |      14 |      0 |
|  74 |                  UNION-ALL                               |                       |      1 |        |            |     20 |00:00:00.01 |      14 |      0 |
|  75 |                   TABLE ACCESS BY INDEX ROWID BATCHED    | V_DOMAINE             |      1 |      1 |     1   (0)|     20 |00:00:00.01 |      14 |      0 |
|* 76 |                    INDEX RANGE SCAN                      | DOM_CHAMP             |      1 |      1 |     1   (0)|     20 |00:00:00.01 |       2 |      0 |
|* 77 |                   FILTER                                 |                       |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  78 |                    TABLE ACCESS BY INDEX ROWID BATCHED   | V_DOMAINE             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 79 |                     INDEX RANGE SCAN                     | DOM_CHAMP             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 80 |                   FILTER                                 |                       |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  81 |                    TABLE ACCESS BY INDEX ROWID BATCHED   | V_DOMAINE             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 82 |                     INDEX RANGE SCAN                     | DOM_CHAMP             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 83 |                   FILTER                                 |                       |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  84 |                    TABLE ACCESS BY INDEX ROWID BATCHED   | V_DOMAINE             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 85 |                     INDEX RANGE SCAN                     | DOM_CHAMP             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 86 |                   FILTER                                 |                       |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  87 |                    TABLE ACCESS BY INDEX ROWID BATCHED   | V_DOMAINE             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 88 |                     INDEX RANGE SCAN                     | DOM_CHAMP             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 89 |                   FILTER                                 |                       |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  90 |                    TABLE ACCESS BY INDEX ROWID BATCHED   | V_DOMAINE             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 91 |                     INDEX RANGE SCAN                     | DOM_CHAMP             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 92 |                   FILTER                                 |                       |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  93 |                    TABLE ACCESS BY INDEX ROWID BATCHED   | V_DOMAINE             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 94 |                     INDEX RANGE SCAN                     | DOM_CHAMP             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 95 |                   FILTER                                 |                       |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  96 |                    TABLE ACCESS BY INDEX ROWID BATCHED   | V_DOMAINE             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 97 |                     INDEX RANGE SCAN                     | DOM_CHAMP             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 98 |                   FILTER                                 |                       |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  99 |                    TABLE ACCESS BY INDEX ROWID BATCHED   | V_DOMAINE             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*100 |                     INDEX RANGE SCAN                     | DOM_CHAMP             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*101 |                   FILTER                                 |                       |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 102 |                    TABLE ACCESS BY INDEX ROWID BATCHED   | V_DOMAINE             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*103 |                     INDEX RANGE SCAN                     | DOM_CHAMP             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 104 |                VIEW                                      | V_TDOMAINE            |      3 |      1 |     1   (0)|    571 |00:00:00.01 |      10 |      0 |
| 105 |                 UNION ALL PUSHED PREDICATE               |                       |      3 |        |            |    571 |00:00:00.01 |      10 |      0 |
|*106 |                  FILTER                                  |                       |      3 |        |            |    571 |00:00:00.01 |      10 |      0 |
|*107 |                   INDEX RANGE SCAN                       | DOM_TYPVAL            |      3 |      2 |     1   (0)|    571 |00:00:00.01 |      10 |      0 |
|*108 |                  FILTER                                  |                       |      3 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*109 |                   INDEX RANGE SCAN                       | DOM_TYPVAL            |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*110 |                  FILTER                                  |                       |      3 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*111 |                   INDEX RANGE SCAN                       | DOM_TYPVAL            |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*112 |                  FILTER                                  |                       |      3 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*113 |                   INDEX RANGE SCAN                       | DOM_TYPVAL            |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*114 |                  FILTER                                  |                       |      3 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*115 |                   INDEX RANGE SCAN                       | DOM_TYPVAL            |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*116 |                  FILTER                                  |                       |      3 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*117 |                   INDEX RANGE SCAN                       | DOM_TYPVAL            |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*118 |                  FILTER                                  |                       |      3 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*119 |                   INDEX RANGE SCAN                       | DOM_TYPVAL            |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*120 |                  FILTER                                  |                       |      3 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*121 |                   INDEX RANGE SCAN                       | DOM_TYPVAL            |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*122 |                  FILTER                                  |                       |      3 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*123 |                   INDEX RANGE SCAN                       | DOM_TYPVAL            |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*124 |                  FILTER                                  |                       |      3 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*125 |                   INDEX RANGE SCAN                       | DOM_TYPVAL            |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*126 |               INDEX RANGE SCAN                           | INT_REFDOSS           |    571 |      1 |     1   (0)|    571 |00:00:00.01 |      37 |      0 |
|*127 |              INDEX UNIQUE SCAN                           | IND_REFINDIV          |    571 |      1 |     1   (0)|    571 |00:00:00.01 |      14 |      0 |
|*128 |             INDEX RANGE SCAN                             | PIE_REFDOSS           |    571 |      1 |     1   (0)|    571 |00:00:00.01 |      26 |      1 |
|*129 |            INDEX RANGE SCAN                              | INT_REFDOSS           |    571 |      3 |     1   (0)|   1247 |00:00:00.01 |      37 |      0 |
|*130 |           TABLE ACCESS BY INDEX ROWID BATCHED            | V_EXTR_DOM            |   1247 |      1 |     1   (0)|    571 |00:00:00.01 |       9 |      2 |
|*131 |            INDEX RANGE SCAN                              | TYPEABREV             |   1247 |      2 |     1   (0)|   1713 |00:00:00.01 |       8 |      1 |
| 132 |          VIEW                                            | V_TDOMAINE            |    571 |      1 |     1   (0)|    571 |00:00:00.01 |    1152 |      0 |
| 133 |           UNION ALL PUSHED PREDICATE                     |                       |    571 |        |            |    571 |00:00:00.01 |    1152 |      0 |
| 134 |            TABLE ACCESS BY INDEX ROWID BATCHED           | V_DOMAINE             |    571 |      1 |     1   (0)|    571 |00:00:00.01 |    1152 |      0 |
|*135 |             INDEX RANGE SCAN                             | DOM_TYPABREV          |    571 |      2 |     1   (0)|    571 |00:00:00.01 |     581 |      0 |
|*136 |            FILTER                                        |                       |    571 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 137 |             TABLE ACCESS BY INDEX ROWID BATCHED          | V_DOMAINE             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*138 |              INDEX RANGE SCAN                            | DOM_TYPABREV          |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*139 |            FILTER                                        |                       |    571 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 140 |             TABLE ACCESS BY INDEX ROWID BATCHED          | V_DOMAINE             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*141 |              INDEX RANGE SCAN                            | DOM_TYPABREV          |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*142 |            FILTER                                        |                       |    571 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 143 |             TABLE ACCESS BY INDEX ROWID BATCHED          | V_DOMAINE             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*144 |              INDEX RANGE SCAN                            | DOM_TYPABREV          |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*145 |            FILTER                                        |                       |    571 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 146 |             TABLE ACCESS BY INDEX ROWID BATCHED          | V_DOMAINE             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*147 |              INDEX RANGE SCAN                            | DOM_TYPABREV          |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*148 |            FILTER                                        |                       |    571 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 149 |             TABLE ACCESS BY INDEX ROWID BATCHED          | V_DOMAINE             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*150 |              INDEX RANGE SCAN                            | DOM_TYPABREV          |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*151 |            FILTER                                        |                       |    571 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 152 |             TABLE ACCESS BY INDEX ROWID BATCHED          | V_DOMAINE             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*153 |              INDEX RANGE SCAN                            | DOM_TYPABREV          |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*154 |            FILTER                                        |                       |    571 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 155 |             TABLE ACCESS BY INDEX ROWID BATCHED          | V_DOMAINE             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*156 |              INDEX RANGE SCAN                            | DOM_TYPABREV          |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*157 |            FILTER                                        |                       |    571 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 158 |             TABLE ACCESS BY INDEX ROWID BATCHED          | V_DOMAINE             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*159 |              INDEX RANGE SCAN                            | DOM_TYPABREV          |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*160 |            FILTER                                        |                       |    571 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 161 |             TABLE ACCESS BY INDEX ROWID BATCHED          | V_DOMAINE             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*162 |              INDEX RANGE SCAN                            | DOM_TYPABREV          |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*163 |         VIEW                                             | V_TDOMAINE            |    571 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 164 |          UNION ALL PUSHED PREDICATE                      |                       |    571 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 165 |           TABLE ACCESS BY INDEX ROWID BATCHED            | V_DOMAINE             |    571 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*166 |            INDEX RANGE SCAN                              | DOM_TYPABREV          |    571 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*167 |           FILTER                                         |                       |    571 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 168 |            TABLE ACCESS BY INDEX ROWID BATCHED           | V_DOMAINE             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*169 |             INDEX RANGE SCAN                             | DOM_TYPABREV          |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*170 |           FILTER                                         |                       |    571 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 171 |            TABLE ACCESS BY INDEX ROWID BATCHED           | V_DOMAINE             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*172 |             INDEX RANGE SCAN                             | DOM_TYPABREV          |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*173 |           FILTER                                         |                       |    571 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 174 |            TABLE ACCESS BY INDEX ROWID BATCHED           | V_DOMAINE             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*175 |             INDEX RANGE SCAN                             | DOM_TYPABREV          |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*176 |           FILTER                                         |                       |    571 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 177 |            TABLE ACCESS BY INDEX ROWID BATCHED           | V_DOMAINE             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*178 |             INDEX RANGE SCAN                             | DOM_TYPABREV          |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*179 |           FILTER                                         |                       |    571 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 180 |            TABLE ACCESS BY INDEX ROWID BATCHED           | V_DOMAINE             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*181 |             INDEX RANGE SCAN                             | DOM_TYPABREV          |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*182 |           FILTER                                         |                       |    571 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 183 |            TABLE ACCESS BY INDEX ROWID BATCHED           | V_DOMAINE             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*184 |             INDEX RANGE SCAN                             | DOM_TYPABREV          |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*185 |           FILTER                                         |                       |    571 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 186 |            TABLE ACCESS BY INDEX ROWID BATCHED           | V_DOMAINE             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*187 |             INDEX RANGE SCAN                             | DOM_TYPABREV          |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*188 |           FILTER                                         |                       |    571 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 189 |            TABLE ACCESS BY INDEX ROWID BATCHED           | V_DOMAINE             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*190 |             INDEX RANGE SCAN                             | DOM_TYPABREV          |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*191 |           FILTER                                         |                       |    571 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 192 |            TABLE ACCESS BY INDEX ROWID BATCHED           | V_DOMAINE             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*193 |             INDEX RANGE SCAN                             | DOM_TYPABREV          |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 194 |        TABLE ACCESS BY INDEX ROWID                       | G_DOSSIER             |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       6 |      0 |
|*195 |         INDEX UNIQUE SCAN                                | DOS_REFDOSS           |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |      0 |
| 196 |        TABLE ACCESS BY INDEX ROWID                       | G_DOSSIER             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*197 |         INDEX UNIQUE SCAN                                | DOS_REFDOSS           |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
------------------------------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   1 - filter(ROWNUM=1)
   2 - filter("DTFIN_DT" IS NULL)
   3 - access("REFDOSS"=:B1)
   4 - filter(ROWNUM=1)
   7 - filter("AUTH"."VALEUR_2" IS NOT NULL)
   8 - access("AUTH"."TYPE"='EXTR_GEST_CLIENT' AND "AUTH"."ABREV"='132')
   9 - access("TI"."REFDOSS"=:B1 AND "TI"."REFTYPE"="AUTH"."VALEUR_2" AND "TI"."REFINDIVIDU"="AUTH"."VALEUR")
  10 - filter("TI"."REFDOSSEXT" IS NOT NULL)
  12 - access("IMX_UN_ID"=)
  17 - filter(("DECOMPTE"."REFDOSS"=:B1 AND "DECOMPTE"."CATEGDOSS" LIKE 'DECOMPTE%'))
  18 - filter("DECOMPTE"."REFLOT" IS NOT NULL)
  20 - access("DECOMPTE"."REFLOT"="CONTR"."REFDOSS")
  21 - access("REFINDIVIDU"=:B1)
  22 - filter(("REFEXT3" IS NOT NULL AND "REFEXT3"="CONTR"."ANCREFDOSS" AND "REFEXT2"=:B1 AND "SOCIETE"='CLIENT_NUMBER'))
  24 - access("VALEUR"= AND "TYPE"='typencour')
  27 - access("TA"."REFENTITE"=:B1)
  28 - filter(ROWNUM=1)
  29 - access("SR"."REFDOSS"=:B1)
       filter(("SR"."REFTYPE"<>'DB' AND "SR"."REFTYPE"<>'CL' AND "SR"."REFTYPE"<>'XX'))
  30 - filter(ROWNUM=1)
  32 - filter("G"."CATEGDOSS" LIKE 'COLLECTION%')
  33 - access("G"."REFDOSS"=:B1)
  35 - access("PIECE"."REFDOSS"=:B1 AND "PIECE"."TYPPIECE"='DBT_VERIF_REQ')
  36 - filter("RECORD_NO">=1)
  37 - filter(ROWNUM<=11)
  39 - filter(ROWNUM<=11)
  41 - filter((DECODE("D"."REFHIERARCHIE",NULL,'N',)='N' AND DECODE("D"."REFHIERARCHIE2",NULL,'N',)='N'))
  50 - access("VD_PIECEINIT"."VALEUR"="D"."PIECEINIT")
  58 - access("I"."NUMSS"='8101302770')
  59 - access("T"."REFINDIVIDU"="I"."REFINDIVIDU" AND "T"."REFTYPE"='DB')
  60 - filter(("D"."CATEGDOSS"<>'COMPTE DB CTR' AND NVL("D"."FG_EXCL_FROM_EXTR",'N')<>'O' AND NVL("FG_FRM_INC",'N')<>'O'))
  61 - access("D"."REFDOSS"="T"."REFDOSS")
       filter("D"."REFDOSS" NOT LIKE 'GL%')
  62 - access("LST"."REFDOSS"="D"."REFDOSS")
  67 - access("P"."REFDOSS"="D"."REFHIERARCHIE" AND "P"."TYPPIECE"='CONTRAT')
  68 - access("PD"."REFPIECE"="P"."REFPIECE" AND "PD"."TYPE"='CI CONTRACTS')
  69 - filter("PD"."FG01"='O')
  70 - access("D"."CATEGDOSS"="VALEUR" AND "TYPE"='categdoss')
       filter("VALEUR"<>'COMPTE DB CTR')
  71 - filter(("ECRAN"='X' OR  IS NOT NULL))
  72 - filter(("ACTIVITE_GPC"='G' OR "ACTIVITE_GPC"='T'))
  76 - access("CHAMP"='pieceinit')
  77 - filter(NULL IS NOT NULL)
  79 - access("CHAMP"='pieceinit')
  80 - filter(NULL IS NOT NULL)
  82 - access("CHAMP"='pieceinit')
  83 - filter(NULL IS NOT NULL)
  85 - access("CHAMP"='pieceinit')
  86 - filter(NULL IS NOT NULL)
  88 - access("CHAMP"='pieceinit')
  89 - filter(NULL IS NOT NULL)
  91 - access("CHAMP"='pieceinit')
  92 - filter(NULL IS NOT NULL)
  94 - access("CHAMP"='pieceinit')
  95 - filter(NULL IS NOT NULL)
  97 - access("CHAMP"='pieceinit')
  98 - filter(NULL IS NOT NULL)
100 - access("CHAMP"='pieceinit')
101 - filter(NULL IS NOT NULL)
103 - access("CHAMP"='pieceinit')
106 - filter("D"."CATEGDOSS"<>'COMPTE DB CTR')
107 - access("VALEUR"="D"."CATEGDOSS")
       filter("VALEUR"<>'COMPTE DB CTR')
108 - filter((NULL IS NOT NULL AND "D"."CATEGDOSS"<>'COMPTE DB CTR'))
109 - access("VALEUR"="D"."CATEGDOSS")
       filter("VALEUR"<>'COMPTE DB CTR')
110 - filter((NULL IS NOT NULL AND "D"."CATEGDOSS"<>'COMPTE DB CTR'))
111 - access("VALEUR"="D"."CATEGDOSS")
       filter("VALEUR"<>'COMPTE DB CTR')
112 - filter((NULL IS NOT NULL AND "D"."CATEGDOSS"<>'COMPTE DB CTR'))
113 - access("VALEUR"="D"."CATEGDOSS")
       filter("VALEUR"<>'COMPTE DB CTR')
114 - filter((NULL IS NOT NULL AND "D"."CATEGDOSS"<>'COMPTE DB CTR'))
115 - access("VALEUR"="D"."CATEGDOSS")
       filter("VALEUR"<>'COMPTE DB CTR')
116 - filter((NULL IS NOT NULL AND "D"."CATEGDOSS"<>'COMPTE DB CTR'))
117 - access("VALEUR"="D"."CATEGDOSS")
       filter("VALEUR"<>'COMPTE DB CTR')
118 - filter((NULL IS NOT NULL AND "D"."CATEGDOSS"<>'COMPTE DB CTR'))
119 - access("VALEUR"="D"."CATEGDOSS")
       filter("VALEUR"<>'COMPTE DB CTR')
120 - filter((NULL IS NOT NULL AND "D"."CATEGDOSS"<>'COMPTE DB CTR'))
121 - access("VALEUR"="D"."CATEGDOSS")
       filter("VALEUR"<>'COMPTE DB CTR')
122 - filter((NULL IS NOT NULL AND "D"."CATEGDOSS"<>'COMPTE DB CTR'))
123 - access("VALEUR"="D"."CATEGDOSS")
       filter("VALEUR"<>'COMPTE DB CTR')
124 - filter((NULL IS NOT NULL AND "D"."CATEGDOSS"<>'COMPTE DB CTR'))
125 - access("VALEUR"="D"."CATEGDOSS")
       filter("VALEUR"<>'COMPTE DB CTR')
126 - access("D"."REFDOSS"="CLIENT"."REFDOSS")
       filter(("CLIENT"."REFTYPE"='CL' OR "CLIENT"."REFTYPE"='TC'))
127 - access("ICL"."REFINDIVIDU"="CLIENT"."REFINDIVIDU")
128 - access("PIECECASE"."REFDOSS"="D"."REFDOSS" AND "PIECECASE"."TYPPIECE"="D"."PIECEINIT")
129 - access("D"."REFDOSS"="T_INT"."REFDOSS")
130 - filter(("T_INT"."REFTYPE"="AUTH"."VALEUR_2" AND "AUTH"."VALEUR_2" IS NOT NULL))
131 - access("AUTH"."TYPE"='EXTR_GEST_CLIENT' AND "AUTH"."ABREV"='132' AND "T_INT"."REFINDIVIDU"="AUTH"."VALEUR")
135 - access("TYPE"='pays' AND "ABREV"="I"."PAYS")
136 - filter(NULL IS NOT NULL)
138 - access("TYPE"='pays' AND "ABREV"="I"."PAYS")
139 - filter(NULL IS NOT NULL)
141 - access("TYPE"='pays' AND "ABREV"="I"."PAYS")
142 - filter(NULL IS NOT NULL)
144 - access("TYPE"='pays' AND "ABREV"="I"."PAYS")
145 - filter(NULL IS NOT NULL)
147 - access("TYPE"='pays' AND "ABREV"="I"."PAYS")
148 - filter(NULL IS NOT NULL)
150 - access("TYPE"='pays' AND "ABREV"="I"."PAYS")
151 - filter(NULL IS NOT NULL)
153 - access("TYPE"='pays' AND "ABREV"="I"."PAYS")
154 - filter(NULL IS NOT NULL)
156 - access("TYPE"='pays' AND "ABREV"="I"."PAYS")
157 - filter(NULL IS NOT NULL)
159 - access("TYPE"='pays' AND "ABREV"="I"."PAYS")
160 - filter(NULL IS NOT NULL)
162 - access("TYPE"='pays' AND "ABREV"="I"."PAYS")
163 - filter("VD_DIV"."ECRAN"="I"."PAYS")
166 - access("TYPE"='DIVISION TERRITORIALE' AND "ABREV"="I"."DIVISION")
167 - filter(NULL IS NOT NULL)
169 - access("TYPE"='DIVISION TERRITORIALE' AND "ABREV"="I"."DIVISION")
170 - filter(NULL IS NOT NULL)
172 - access("TYPE"='DIVISION TERRITORIALE' AND "ABREV"="I"."DIVISION")
173 - filter(NULL IS NOT NULL)
175 - access("TYPE"='DIVISION TERRITORIALE' AND "ABREV"="I"."DIVISION")
176 - filter(NULL IS NOT NULL)
178 - access("TYPE"='DIVISION TERRITORIALE' AND "ABREV"="I"."DIVISION")
179 - filter(NULL IS NOT NULL)
181 - access("TYPE"='DIVISION TERRITORIALE' AND "ABREV"="I"."DIVISION")
182 - filter(NULL IS NOT NULL)
184 - access("TYPE"='DIVISION TERRITORIALE' AND "ABREV"="I"."DIVISION")
185 - filter(NULL IS NOT NULL)
187 - access("TYPE"='DIVISION TERRITORIALE' AND "ABREV"="I"."DIVISION")
188 - filter(NULL IS NOT NULL)
190 - access("TYPE"='DIVISION TERRITORIALE' AND "ABREV"="I"."DIVISION")
191 - filter(NULL IS NOT NULL)
193 - access("TYPE"='DIVISION TERRITORIALE' AND "ABREV"="I"."DIVISION")
195 - access("REFDOSS"=:B1)
197 - access("REFDOSS"=:B1)
*/
/********************************New Metrics***************************************/

/********************************Index statistics**********************************/

/********************************Other SQLs****************************************/          
/*

*/ 
/********************************Other SQLs****************************************/              
