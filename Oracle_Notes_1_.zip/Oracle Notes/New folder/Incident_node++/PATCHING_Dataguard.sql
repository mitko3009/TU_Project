sl05821
. oraenv
EMCF1P
dgmgrl /
edit database 'EMCF1PS' SET STATE='APPLY-OFF';
edit database 'EMCF1P' set state='LOG-TRANSPORT-OFF';
disable configuration;
sqlplus / as sysdba
shu immediate
lsnrctl stop LISTENER_EMCF1P_1522





Once the OS is upgraded, relink and startup:
ps -fu oracle
cd $ORACLE_HOME/bin
./relink all
lsnrctl start LISTENER_EMCF1P_1522
sqlplus / as sysdba
startup
dgmgrl /
enable configuration;
edit database 'EMCF1P' set state='TRANSPORT-ON';
edit database 'EMCF1PS' SET STATE='APPLY-ON';
show database 'EMCF1PS';
vi /etc/oratab
EMCF1P:/oracle/12.1.0.2_EMCF1P:Y



