/********************************************************************************
*********       E-mail subject: IMBWEB-7228
*********             Instance: UATR
*********          Description: 
Problem:
On 19/10/2023 service_bus.CheckCession('A70GRYCC'); took more that 8 minutes.

Analysis:
After the investigation, we found that the problem was from the SQLs 704gz4270y0sh and bmvm2ucnh7nvf. They took around 90% of the time.
The problem in both of them was that the queries were modified without modifying the hints and Oracle use inappropriate execution plan.

Suggestion:
Please change the hints in SQLs from ftr_fin_calc_item.pck as it is shown in the New SQL section below.

*********               SQL_ID: 704gz4270y0sh, bmvm2ucnh7nvf
*********      Program/Package: service_bus.CheckCession, ftr_fin_calc_item.pck
*********              Request: Binh Thanh Nguyen
*********               Author: Dimitar Dimitrov
********* Received e-mail date: 20/10/2023
*********      Resolution date: 23/10/2023
*********  Trace old file here: \\epox\specifs\performance\tmp\
*********  Trace new file here:
***********************************************************************************/

/********************************OLD SQL*******************************************/
-- 704gz4270y0sh

SELECT /*+ leading(I E P C S) use_nl(I E P C S) */
 E.REFDOSS REF_DBACCOUNT,
 S.REFDOSS REF_SUBCONTRACT,
 S.REFLOT REF_CONTRACT,
 E.REFELEM REF_ITEM,
 P.REFPIECE REF_ITEM_DOCUMENT,
 E.REFEXT REF_ITEM_EXTERNAL,
 P.ROWID G_PIECE_ROWID,
 E.ROWID G_ELEMFI_ROWID,
 D.ROWID G_DB_PTF_ITEM_ROWID,
 P.GPIDEPOT REF_CESSION,
 P.REFSTOCK REF_CI_POLICY,
 D.DBP_POLICY REF_DBP_POLICY,
 D.DGP_POLICY REF_DGP_POLICY,
 DECODE(V.FINANCING, 'F', :B6, 'N', :B5) ITEM_FINANCING_TYPE,
 E.TYPE ITEM_ELEMENT_TYPE,
 P.ST09 ITEM_STATUS,
 P.FG34 STOP_FINANCING_STATUS,
 P.ST04 COVERAGE_ID,
 P.ST06 ORIGIN_NOTE,
 NVL(P.STR_20_1, 'OK') INDEMNIFIED_NOTE,
 E.CREATEUR ITEM_CREATOR,
 P.FG95 VERIFICATION_STATUS,
 NVL(P.ST20, 'x') REASSIGNMENT_REASON,
 NVL(D.GUARANT_STATUS, 'x') GUARANTEE_STATUS,
 (SELECT COUNT(1) FROM G_ELEMFI_AGGR WHERE REFFACTURE = P.REFPIECE) BUNDLE_COUNT,
 D.FG_POST_FIN_ITEM POST_FINANCING_STATUS,
 D.LIMIT_ADDIT_INFO LIMIT_ADDITIONAL_INFO,
 NVL(P.GPIADR3, 'x') RECALCULATION_REASON,
 ACC_FLAG.FROM_CHAR(E.ACTIF) FLAG_ACTIVE,
 DECODE(P.ST09, 'PCF', 1, 'PFIN', 1, 0) FLAG_PRE_CALCFIN,
 ACC_FLAG.FROM_CHAR(P.FG01) FLAG_FINANCABLE,
 ACC_FLAG.FROM_CHAR(P.FG02) FLAG_COVERABLE,
 ACC_FLAG.FROM_CHAR(P.FG14) FLAG_MANUAL_COVERAGE,
 ACC_FLAG.FROM_CHAR(DECODE(:B4, 410, P.FG41, NVL(P.FG38, P.FG41))) FLAG_MANUAL_FINANCING,
 ACC_FLAG.FROM_CHAR(P.FG28) FLAG_DOCUMENT_RECEIVED,
 DECODE(E.FLAG_CTX, 'C', :B3, :B2) FLAG_ITEM_LEVEL_CTX,
 ACC_FLAG.FROM_CHAR(P.FG38) FLAG_IS_FUNDED,
 ACC_FLAG.FROM_CHAR(P.FG63) FLAG_IS_CONFIRMED_BY_SUPPLIER,
 ACC_FLAG.FROM_CHAR(P.FG44) FLAG_BUNDLE_FUNDING_REQUEST,
 DECODE(P.DT01_DT, NULL, :B3, :B2) FLAG_IS_FIRST_CALCULATION,
 (SELECT DECODE(COUNT(1), 0, :B2, :B3)
    FROM ELIGIB_CTRL C
   WHERE C.REFFACTURE = P.REFPIECE
     AND C.DT_RESOLVE IS NULL) FLAG_HAS_ELIGIBILITY_CONTROLS,
 CASE
   WHEN E.TYPE IN ('FINANCEMENT SUR BIEN',
                   'REEVALUATION DU BIEN - AUGM',
                   'REEVALUATION DU BIEN - DIM',
                   'BON DE COMMANDE',
                   'BC SUR BL',
                   'BON DE LIVRAISON',
                   'BL FACTURE',
                   'PURCHASE ORDER') THEN
    :B3
   ELSE
    :B2
 END FLAG_IS_ABL,
 CASE
   WHEN E.TYPE IN ('INVENTORY',
                   'INVENTORY REVALUATION UP',
                   'INVENTORY REVALUATION DOWN') THEN
    :B3
   ELSE
    :B2
 END FLAG_IS_INVENTORY,
 CASE
   WHEN E.TYPE IN ('BILL OF LADING') THEN
    :B3
   ELSE
    :B2
 END FLAG_IS_BILL_OF_LADING,
 CASE
   WHEN E.TYPE IN ('SALES ORDER') THEN
    :B3
   ELSE
    :B2
 END FLAG_IS_SALES_ORDER,
 (SELECT /*+ no_unnest */
   DECODE(COUNT(1), 0, :B2, :B3)
    FROM G_PIECEDET
   WHERE REFPIECE = P.REFPIECE
     AND TYPE = 'FAC_SO') FLAG_IS_SALES_INVOICE,
 E.DTJOUR_DT ENTRY_DATE,
 E.DT_EMIS_DT DOCUMENT_DATE,
 E.DTDEBUT_DT DUE_DATE,
 (SELECT /*+ no_unnest */
   MIN(DT02_DT)
    FROM G_PIECEDET
   WHERE REFPIECE = P.REFPIECE
     AND TYPE = 'PROROGATION'
     AND DT01_DT IS NOT NULL) ORIGINAL_DUE_DATE,
 P.DT03_DT DELIVERY_DATE,
 E.DTANNUL_DT CANCELLATION_DATE,
 P.DT12_DT EXPECTED_FUNDING_DATE,
 P.DT15_DT FUNDING_DATE,
 P.DT20_DT MINIMUM_FINANCING_DATE,
 FTR_UTIL.SELECTLIMITCONSIDERATIONDATE('C',
                                       P.MT01,
                                       P.DT03,
                                       E.DT_EMIS,
                                       P.DT04) CREDIT_LIMIT_CONSIDER_DATE,
 P.DTMINUTES_DT FIRST_LIMIT_CONSUMPTION_DATE,
 P.DT13_DT CALCULATED_DUE_DATE,
 D.DT_FINAL_DUE FINAL_DUE_DATE,
 D.DT_GUARANTEE_STATUS GUARANTEE_STATUS_DATE,
 P.DT02_DT VALIDATION_DATE,
 E.DEVISE_MVT CURRENCY_MVT,
 E.MONTANT_MVT FACE_AMOUNT_MVT,
 T.MNT_DCPT FACE_AMOUNT_DEC,
 FTR_BALANCES.GETITEMBALANCE(E.REFELEM, FTR_BALANCES.C_CASE_CURRENCY) BALANCE_MVT,
 FTR_BALANCES.GETITEMBALANCE(E.REFELEM, FTR_BALANCES.C_SUBCONTRACT_CURRENCY) BALANCE_DEC,
 P.MT09 PREV_BALANCE_MVT,
 P.MT24 PREV_BALANCE_DEC,
 NVL(P.MT01, 0) COVERED_AMOUNT_MVT,
 NVL(P.MT01, 0) COVERED_AMOUNT_MVT_OLD,
 NVL(P.MT12, 0) EXTERNAL_COVERAGE_MVT,
 NVL(P.MT42, 0) MANUAL_FINANCING_BASE_MVT,
 NVL(P.MT02, 0) PREV_FINANCING_BASE_MVT,
 P.MT23 PREV_FINANCING_BASE_DEC,
 P.MT90 FINANCING_BASE_FROZEN_MVT,
 P.MT11 PREV_DISPUTE_AMOUNT_MVT,
 P.MT10 OLD_DISPUTES_FINANCIBLE,
 P.MT31 OLD_DIRECT_PAYMENTS,
 NVL(P.MT48, 0) PURCHASED_AMOUNT_MVT,
 NVL(P.MT30, 0) INDEMNIFIED_AMOUNT_MVT,
 P.MT14 FINANCING_MVT,
 NVL(P.MT03, 0) FINANCING_FINAL_MVT,
 NVL(P.MT04, 0) INITIAL_RESERVE_MVT,
 NVL(P.MT44, 0) COLLATERAL_TOTAL_MVT,
 P.MT43 CACHED_BALANCE_AT_FUNDING_MVT,
 NVL(P.MT79, 0) BUNDLE_REQUESTED_AMOUNT_DEC,
 P.MT76 FINANCING_BUNDLE_DEC,
 D.REQUESTED_FINBASE_DCPT REQUESTED_AMOUNT_DEC,
 NVL(D.SUSPENDED_AMOUNT_COV, 0) SUSPENDED_AMOUNT_COV_MVT,
 NVL(D.SUSPENDED_AMOUNT_FIN, 0) SUSPENDED_AMOUNT_FIN_MVT,
 NVL(D.MT_SUSPENDED_DISPUTES, 0) SUSPENDED_DISPUTES_MVT,
 NVL((SELECT SUM(L.MT02)
       FROM G_PIECEDET L
      WHERE E.TYPE = 'PURCHASE ORDER'
        AND L.REFPIECE = E.REFPIECE3
        AND L.TYPE = 'PO_ITEMS'
        AND L.FG02 = 'O'),
     0) PO_NOT_FINANCIABLE_AMOUNT_MVT,
 P.TX16 / 100 RATE_CREDIT_COVERAGE,
 P.TX16 / 100 RATE_CREDIT_COVERAGE_OLD,
 P.TX10 / 100 RATE_COVERED,
 P.TX11 / 100 RATE_NOT_COVERED,
 P.TX12 / 100 RATE_BILL_OF_EXCHANGE,
 P.STR_5_2 RATE_CODE_COVERED,
 P.STR_5_3 RATE_CODE_NOT_COVERED,
 P.STR_5_4 RATE_CODE_BILL_OF_EXCHANGE,
 P.TX02 / 100 RATE_COVERED_OLD,
 P.TX03 / 100 RATE_NOT_COVERED_OLD,
 P.TX05 / 100 RATE_BILL_OF_EXCHANGE_OLD,
 P.ST01 RATE_CODE_COVERED_OLD,
 P.ST02 RATE_CODE_NOT_COVERED_OLD,
 P.ST03 RATE_CODE_BILL_OF_EXCHANGE_OLD
  FROM G_ELEMFI E,
       G_PIECE P,
       G_DOSSIER C,
       G_DOSSIER S,
       V_ELEMFI V,
       T_ECRDOS T,
       G_DB_PTF_ITEM D,
       (SELECT COLUMN_VALUE REFELEM FROM TABLE(CAST(:B1 AS REFLIST_T))) I
 WHERE P.REFPIECE = E.REFPIECE2
   AND P.TYPPIECE = 'FACTURE'
   AND E.REFELEM = I.REFELEM
   AND C.REFDOSS = E.REFDOSS
   AND S.REFDOSS = C.REFLOT
   AND V.TYPE = E.TYPE
   AND T.REFELEM(+) = E.REFELEM
   AND T.CODECR(+) IN ('PRIN', 'DPRIN')
   AND D.REFELEM = E.REFELEM;


-- bmvm2ucnh7nvf

SELECT /*+ leading(I) */
 E.REFELEM
  FROM G_ELEMFI E,
       G_PIECE P,
       V_ELEMFI V,
       G_DB_PTF_ITEM D,
       (SELECT /*+ cardinality(A 5) */
         ROWNUM ORDER_ID, COLUMN_VALUE REFELEM
          FROM TABLE(CAST(:B1 AS REFLIST_T))) I
 WHERE P.REFPIECE = E.REFPIECE2
   AND P.TYPPIECE = 'FACTURE'
   AND E.REFELEM = I.REFELEM
   AND V.TYPE = E.TYPE
   AND D.REFELEM = E.REFELEM
   FOR UPDATE OF P.MT09, P.MT24, E.ACTIF, D.SUSPENDED_AMOUNT_FIN NOWAIT
 ORDER BY ORDER_ID;

/********************************OLD SQL*******************************************/
/********************************OLD Metrics***************************************/
/*
MODULE                           SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
service_bus_server4BACB2C63144E8                                 519      31340 ON CPU               2023/10/19 16:09:15  2023/10/19 16:19:20          58                 7558 +000000000 00:10:04.992 40%
9B07E15B5F60D53818

imxbatch_StdSddDataPrepare                                       622      63469 ON CPU               2023/10/19 16:15:14  2023/10/19 16:19:51          14                   95 +000000000 00:04:36.864 10%
imxbatch_StdSddDataPrepare       6j5x0agtf4yb0 1305662031        622      63469 cell single block ph 2023/10/19 16:15:55  2023/10/19 16:18:39           9                    1 +000000000 00:02:44.223 6%
                                                        0                       ON CPU               2023/10/19 16:08:24  2023/10/19 16:19:41           6                      +000000000 00:11:16.672 4%
463129ADBEEBC9E71E136BC69F113066 gc2symxcx6hg8  322569057        158      18464 enq: TX - row lock c 2023/10/19 16:15:55  2023/10/19 16:16:47           6                    1 +000000000 00:00:51.584 4%



MODULE                           SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
service_bus_server4BACB2C63144E8 704gz4270y0sh 3162674154        519      31340 ON CPU               2023/10/19 16:09:56  2023/10/19 16:19:10          32                  122 +000000000 00:09:13.797 50%
9B07E15B5F60D53818

service_bus_server4BACB2C63144E8 bmvm2ucnh7nvf 1071232742        519      31340                      2023/10/19 16:09:26  2023/10/19 16:19:20          27                  124 +000000000 00:09:54.752 42%
9B07E15B5F60D53818

service_bus_serverC2B0110AD35D7C 86wxr3f2n1zxu 3112986893         59      52625 ON CPU               2023/10/19 16:11:29  2023/10/19 16:11:29           1                      +000000000 00:00:00.000 2%
A87DA4C5A8699ADBD3

service_bus_server4BACB2C63144E8 c7qk5jrznw98c          0        519      31340 ON CPU               2023/10/19 16:09:15  2023/10/19 16:09:15           1                    1 +000000000 00:00:00.000 2%
9B07E15B5F60D53818

service_bus_serverC2B0110AD35D7C 3ktss25tn0g1r  233454729        128       4562 ON CPU               2023/10/19 16:13:01  2023/10/19 16:13:01           1                    1 +000000000 00:00:00.000 2%
A87DA4C5A8699ADBD3

service_bus_serverC2B0110AD35D7C 4nbc8f6y2xrcn 2944514986         59      52625 ON CPU               2023/10/19 16:11:18  2023/10/19 16:11:18           1                      +000000000 00:00:00.000 2%
A87DA4C5A8699ADBD3

service_bus_serverC2B0110AD35D7C 704gz4270y0sh 3162674154        128       4562 ON CPU               2023/10/19 16:13:11  2023/10/19 16:13:11           1                    1 +000000000 00:00:00.000 2%
A87DA4C5A8699ADBD3


-- 704gz4270y0sh

SQL_ID        SQL_PLAN_HASH_VALUE SQL_PLAN_LINE_ID SQL_PLAN_OPERATION             SQL_PLAN_OPTIONS                   ACTIVE
------------- ------------------- ---------------- ------------------------------ ------------------------------ ----------
704gz4270y0sh                   0                                                                                         2
704gz4270y0sh                   0                  SELECT STATEMENT                                                       1
704gz4270y0sh          1097112161               31 INDEX                          STORAGE FAST FULL SCAN                  1
704gz4270y0sh          1231736859                  SELECT STATEMENT                                                       3
704gz4270y0sh          1231736859               29 TABLE ACCESS                   BY INDEX ROWID BATCHED                  1
704gz4270y0sh          1231736859                7 INDEX                          RANGE SCAN                              1
704gz4270y0sh          2698355731               29 TABLE ACCESS                   BY INDEX ROWID BATCHED                  3
704gz4270y0sh          2698355731                  SELECT STATEMENT                                                       2
704gz4270y0sh          2698355731               25 TABLE ACCESS                   BY INDEX ROWID BATCHED                  2
704gz4270y0sh          2698355731                9 INDEX                          RANGE SCAN                              1
704gz4270y0sh          2698355731               16 HASH JOIN                                                              1
704gz4270y0sh          3162674154               32 INDEX                          STORAGE FAST FULL SCAN                489
704gz4270y0sh          3162674154               16 HASH JOIN                      OUTER                                  72
704gz4270y0sh          3162674154               31 TABLE ACCESS                   STORAGE FULL                            9
704gz4270y0sh          3162674154                  SELECT STATEMENT                                                       3
704gz4270y0sh          3162674154                7 INDEX                          RANGE SCAN                              3
704gz4270y0sh          4101531723               31 TABLE ACCESS                   BY INDEX ROWID BATCHED                  8
704gz4270y0sh          4101531723                  SELECT STATEMENT                                                       5
704gz4270y0sh          4101531723                7 INDEX                          RANGE SCAN                              1
704gz4270y0sh          4101531723                2 INDEX                          RANGE SCAN                              1
704gz4270y0sh          4101531723               32 INDEX                          RANGE SCAN                              1


INSTANCE_NUMBER SQL_ID            ELAPSED MAX_WAIT_ON     PC_OF  WAIT_TIME            GETS      READS       ROWS  ELAP/EXEC       GETS/EXEC READS/EXEC  ROWS/EXEC       EXEC PLAN_HASH_VALUE
--------------- ------------- ----------- --------------- ----- ---------- --------------- ---------- ---------- ---------- --------------- ---------- ---------- ---------- ---------------
              1 704gz4270y0sh        5274 CPU             89%   4452.79362       416436845  206649604     123163       2.59          204436  101448.01      60.46       2037      3162674154
              1 704gz4270y0sh         115 CPU             80%    64.427059         7952138      10564     113660        .23           16229      21.56     231.96        490      2698355731
              1 704gz4270y0sh          29 CPU             78%    19.975475         2383124       6197      31621        .02            1444       3.76      19.16       1650      4101531723


Plan hash value: 3162674154
---------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                  | Name                   | Rows  | Bytes | Cost (%CPU)| Time     |
---------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                           |                        |       |       | 84540 (100)|          |
|   1 |  SORT AGGREGATE                            |                        |     1 |     9 |            |          |
|   2 |   INDEX RANGE SCAN                         | AK_KEY_2_G_ELEMFI      |     1 |     9 |     3   (0)| 00:00:01 |
|   3 |  SORT AGGREGATE                            |                        |     1 |    12 |            |          |
|   4 |   TABLE ACCESS BY INDEX ROWID BATCHED      | ELIGIB_CTRL            |     1 |    12 |     4   (0)| 00:00:01 |
|   5 |    INDEX RANGE SCAN                        | EC_REFFACTURE_IDX      |     1 |       |     3   (0)| 00:00:01 |
|   6 |  SORT AGGREGATE                            |                        |     1 |    24 |            |          |
|   7 |   INDEX RANGE SCAN                         | G_PIECEDET_REFP        |     1 |    24 |     4   (0)| 00:00:01 |
|   8 |  SORT AGGREGATE                            |                        |     1 |    32 |            |          |
|   9 |   INDEX RANGE SCAN                         | G_PIECEDET_REFP        |     1 |    32 |     4   (0)| 00:00:01 |
|  10 |  SORT AGGREGATE                            |                        |     1 |    29 |            |          |
|  11 |   FILTER                                   |                        |       |       |            |          |
|  12 |    TABLE ACCESS BY INDEX ROWID BATCHED     | G_PIECEDET             |     1 |    29 |     5   (0)| 00:00:01 |
|  13 |     INDEX RANGE SCAN                       | G_PIECEDET_REFP        |     1 |       |     4   (0)| 00:00:01 |
|  14 |  HASH JOIN                                 |                        |  4374 |  2421K| 51472   (5)| 00:00:03 |
|  15 |   INDEX FULL SCAN                          | VF_TYPE_FINANCING      |   146 |  3066 |     1   (0)| 00:00:01 |
|  16 |   HASH JOIN OUTER                          |                        |  4344 |  2316K| 51471   (5)| 00:00:03 |
|  17 |    HASH JOIN                               |                        |  4333 |  2234K| 46957   (4)| 00:00:02 |
|  18 |     JOIN FILTER CREATE                     | :BF0000                |  4333 |  1823K| 42904   (1)| 00:00:02 |
|  19 |      NESTED LOOPS                          |                        |  4333 |  1823K| 42904   (1)| 00:00:02 |
|  20 |       NESTED LOOPS                         |                        |  4344 |  1735K| 34202   (1)| 00:00:02 |
|  21 |        NESTED LOOPS                        |                        |  4553 |  1720K| 25082   (1)| 00:00:01 |
|  22 |         NESTED LOOPS                       |                        |  5000 |   664K| 10026   (1)| 00:00:01 |
|  23 |          COLLECTION ITERATOR PICKLER FETCH |                        |  5000 | 10000 |     5   (0)| 00:00:01 |
|  24 |          TABLE ACCESS BY INDEX ROWID       | G_ELEMFI               |     1 |   134 |     2   (0)| 00:00:01 |
|  25 |           INDEX UNIQUE SCAN                | EFI_REFELEM            |     1 |       |     1   (0)| 00:00:01 |
|  26 |         TABLE ACCESS BY INDEX ROWID BATCHED| G_PIECE                |     1 |   251 |     3   (0)| 00:00:01 |
|  27 |          INDEX RANGE SCAN                  | PIE_REFPIECE           |     1 |       |     2   (0)| 00:00:01 |
|  28 |        INDEX RANGE SCAN                    | DOS_REFDOSS_REFLOT_IDX |     1 |    22 |     2   (0)| 00:00:01 |
|  29 |       INDEX RANGE SCAN                     | DOS_REFDOSS_REFLOT_IDX |     1 |    22 |     2   (0)| 00:00:01 |
|  30 |     JOIN FILTER USE                        | :BF0000                |  3781K|   349M|  3974  (37)| 00:00:01 |
|  31 |      TABLE ACCESS STORAGE FULL             | G_DB_PTF_ITEM          |  3781K|   349M|  3974  (37)| 00:00:01 |
|  32 |    INDEX STORAGE FAST FULL SCAN            | IDX_FFSI_T_ECRDOS      |   362K|  6373K|  4506  (16)| 00:00:01 |
---------------------------------------------------------------------------------------------------------------------
Hint Report (identified by operation id / Query Block Name / Object Alias):
Total hints for statement: 1 (U - Unused (1))
---------------------------------------------------------------------------

  23 -  SEL$B3C83B60 / KOKBF$0@SEL$8
         U -  use_nl(I E P C S)


Plan hash value: 1231736859
--------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                 | Name                   | Rows  | Bytes | Cost (%CPU)| Time     |
--------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                          |                        |       |       |    54 (100)|          |
|   1 |  SORT AGGREGATE                           |                        |     1 |     9 |            |          |
|   2 |   INDEX RANGE SCAN                        | AK_KEY_2_G_ELEMFI      |     1 |     9 |     3   (0)| 00:00:01 |
|   3 |  SORT AGGREGATE                           |                        |     1 |    12 |            |          |
|   4 |   TABLE ACCESS BY INDEX ROWID BATCHED     | ELIGIB_CTRL            |     1 |    12 |     4   (0)| 00:00:01 |
|   5 |    INDEX RANGE SCAN                       | EC_REFFACTURE_IDX      |     1 |       |     3   (0)| 00:00:01 |
|   6 |  SORT AGGREGATE                           |                        |     1 |    23 |            |          |
|   7 |   INDEX RANGE SCAN                        | G_PIECEDET_REFP        |     1 |    23 |     4   (0)| 00:00:01 |
|   8 |  SORT AGGREGATE                           |                        |     1 |    31 |            |          |
|   9 |   INDEX RANGE SCAN                        | G_PIECEDET_REFP        |     1 |    31 |     4   (0)| 00:00:01 |
|  10 |  SORT AGGREGATE                           |                        |     1 |    28 |            |          |
|  11 |   FILTER                                  |                        |       |       |            |          |
|  12 |    TABLE ACCESS BY INDEX ROWID BATCHED    | G_PIECEDET             |     1 |    28 |     5   (0)| 00:00:01 |
|  13 |     INDEX RANGE SCAN                      | G_PIECEDET_REFP        |     2 |       |     4   (0)| 00:00:01 |
|  14 |  NESTED LOOPS                             |                        |     2 |  1144 |    34   (0)| 00:00:01 |
|  15 |   NESTED LOOPS OUTER                      |                        |     2 |   936 |    30   (0)| 00:00:01 |
|  16 |    HASH JOIN                              |                        |     2 |   900 |    24   (0)| 00:00:01 |
|  17 |     NESTED LOOPS                          |                        |     2 |   858 |    23   (0)| 00:00:01 |
|  18 |      NESTED LOOPS                         |                        |     2 |   814 |    19   (0)| 00:00:01 |
|  19 |       NESTED LOOPS                        |                        |     2 |   770 |    15   (0)| 00:00:01 |
|  20 |        NESTED LOOPS                       |                        |     2 |   272 |     9   (0)| 00:00:01 |
|  21 |         COLLECTION ITERATOR PICKLER FETCH |                        |     2 |     4 |     5   (0)| 00:00:01 |
|  22 |         TABLE ACCESS BY INDEX ROWID       | G_ELEMFI               |     1 |   134 |     2   (0)| 00:00:01 |
|  23 |          INDEX UNIQUE SCAN                | EFI_REFELEM            |     1 |       |     1   (0)| 00:00:01 |
|  24 |        TABLE ACCESS BY INDEX ROWID BATCHED| G_PIECE                |     1 |   249 |     3   (0)| 00:00:01 |
|  25 |         INDEX RANGE SCAN                  | PIE_REFPIECE           |     1 |       |     2   (0)| 00:00:01 |
|  26 |       INDEX RANGE SCAN                    | DOS_REFDOSS_REFLOT_IDX |     1 |    22 |     2   (0)| 00:00:01 |
|  27 |      INDEX RANGE SCAN                     | DOS_REFDOSS_REFLOT_IDX |     1 |    22 |     2   (0)| 00:00:01 |
|  28 |     INDEX FULL SCAN                       | VF_TYPE_FINANCING      |   146 |  3066 |     1   (0)| 00:00:01 |
|  29 |    TABLE ACCESS BY INDEX ROWID BATCHED    | T_ECRDOS               |     1 |    18 |     3   (0)| 00:00:01 |
|  30 |     INDEX RANGE SCAN                      | TECR_REFELEM           |     1 |       |     2   (0)| 00:00:01 |
|  31 |   TABLE ACCESS BY INDEX ROWID             | G_DB_PTF_ITEM          |     1 |   104 |     2   (0)| 00:00:01 |
|  32 |    INDEX UNIQUE SCAN                      | PK_G_DB_PTF_ITEM       |     1 |       |     1   (0)| 00:00:01 |
--------------------------------------------------------------------------------------------------------------------
Hint Report (identified by operation id / Query Block Name / Object Alias):
Total hints for statement: 1 (U - Unused (1))
---------------------------------------------------------------------------
  21 -  SEL$B3C83B60 / KOKBF$0@SEL$8
         U -  use_nl(I E P C S)


Plan hash value: 2698355731
--------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                 | Name                   | Rows  | Bytes | Cost (%CPU)| Time     |
--------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                          |                        |       |       |   697 (100)|          |
|   1 |  SORT AGGREGATE                           |                        |     1 |     9 |            |          |
|   2 |   INDEX RANGE SCAN                        | AK_KEY_2_G_ELEMFI      |     1 |     9 |     3   (0)| 00:00:01 |
|   3 |  SORT AGGREGATE                           |                        |     1 |    12 |            |          |
|   4 |   TABLE ACCESS BY INDEX ROWID BATCHED     | ELIGIB_CTRL            |     1 |    12 |     4   (0)| 00:00:01 |
|   5 |    INDEX RANGE SCAN                       | EC_REFFACTURE_IDX      |     1 |       |     3   (0)| 00:00:01 |
|   6 |  SORT AGGREGATE                           |                        |     1 |    23 |            |          |
|   7 |   INDEX RANGE SCAN                        | G_PIECEDET_REFP        |     1 |    23 |     4   (0)| 00:00:01 |
|   8 |  SORT AGGREGATE                           |                        |     1 |    31 |            |          |
|   9 |   INDEX RANGE SCAN                        | G_PIECEDET_REFP        |     1 |    31 |     4   (0)| 00:00:01 |
|  10 |  SORT AGGREGATE                           |                        |     1 |    28 |            |          |
|  11 |   FILTER                                  |                        |       |       |            |          |
|  12 |    TABLE ACCESS BY INDEX ROWID BATCHED    | G_PIECEDET             |     1 |    28 |     5   (0)| 00:00:01 |
|  13 |     INDEX RANGE SCAN                      | G_PIECEDET_REFP        |     2 |       |     4   (0)| 00:00:01 |
|  14 |  NESTED LOOPS                             |                        |    28 | 16016 |   414   (1)| 00:00:01 |
|  15 |   NESTED LOOPS OUTER                      |                        |    28 | 13104 |   360   (1)| 00:00:01 |
|  16 |    HASH JOIN                              |                        |    28 | 12600 |   276   (1)| 00:00:01 |
|  17 |     INDEX FULL SCAN                       | VF_TYPE_FINANCING      |   146 |  3066 |     1   (0)| 00:00:01 |
|  18 |     NESTED LOOPS                          |                        |    28 | 12012 |   275   (1)| 00:00:01 |
|  19 |      NESTED LOOPS                         |                        |    28 | 11396 |   219   (1)| 00:00:01 |
|  20 |       NESTED LOOPS                        |                        |    29 | 11165 |   161   (1)| 00:00:01 |
|  21 |        NESTED LOOPS                       |                        |    31 |  4216 |    67   (0)| 00:00:01 |
|  22 |         COLLECTION ITERATOR PICKLER FETCH |                        |    31 |    62 |     5   (0)| 00:00:01 |
|  23 |         TABLE ACCESS BY INDEX ROWID       | G_ELEMFI               |     1 |   134 |     2   (0)| 00:00:01 |
|  24 |          INDEX UNIQUE SCAN                | EFI_REFELEM            |     1 |       |     1   (0)| 00:00:01 |
|  25 |        TABLE ACCESS BY INDEX ROWID BATCHED| G_PIECE                |     1 |   249 |     3   (0)| 00:00:01 |
|  26 |         INDEX RANGE SCAN                  | PIE_REFPIECE           |     1 |       |     2   (0)| 00:00:01 |
|  27 |       INDEX RANGE SCAN                    | DOS_REFDOSS_REFLOT_IDX |     1 |    22 |     2   (0)| 00:00:01 |
|  28 |      INDEX RANGE SCAN                     | DOS_REFDOSS_REFLOT_IDX |     1 |    22 |     2   (0)| 00:00:01 |
|  29 |    TABLE ACCESS BY INDEX ROWID BATCHED    | T_ECRDOS               |     1 |    18 |     3   (0)| 00:00:01 |
|  30 |     INDEX RANGE SCAN                      | TECR_REFELEM           |     1 |       |     2   (0)| 00:00:01 |
|  31 |   TABLE ACCESS BY INDEX ROWID             | G_DB_PTF_ITEM          |     1 |   104 |     2   (0)| 00:00:01 |
|  32 |    INDEX UNIQUE SCAN                      | PK_G_DB_PTF_ITEM       |     1 |       |     1   (0)| 00:00:01 |
--------------------------------------------------------------------------------------------------------------------
Hint Report (identified by operation id / Query Block Name / Object Alias):
Total hints for statement: 1 (U - Unused (1))
---------------------------------------------------------------------------
  22 -  SEL$B3C83B60 / KOKBF$0@SEL$8
         U -  use_nl(I E P C S)


Plan hash value: 4101531723
--------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                 | Name                   | Rows  | Bytes | Cost (%CPU)| Time     |
--------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                          |                        |       |       |    40 (100)|          |
|   1 |  SORT AGGREGATE                           |                        |     1 |     9 |            |          |
|   2 |   INDEX RANGE SCAN                        | AK_KEY_2_G_ELEMFI      |     1 |     9 |     3   (0)| 00:00:01 |
|   3 |  SORT AGGREGATE                           |                        |     1 |    12 |            |          |
|   4 |   TABLE ACCESS BY INDEX ROWID BATCHED     | ELIGIB_CTRL            |     1 |    12 |     4   (0)| 00:00:01 |
|   5 |    INDEX RANGE SCAN                       | EC_REFFACTURE_IDX      |     1 |       |     3   (0)| 00:00:01 |
|   6 |  SORT AGGREGATE                           |                        |     1 |    23 |            |          |
|   7 |   INDEX RANGE SCAN                        | G_PIECEDET_REFP        |     1 |    23 |     4   (0)| 00:00:01 |
|   8 |  SORT AGGREGATE                           |                        |     1 |    31 |            |          |
|   9 |   INDEX RANGE SCAN                        | G_PIECEDET_REFP        |     1 |    31 |     4   (0)| 00:00:01 |
|  10 |  SORT AGGREGATE                           |                        |     1 |    28 |            |          |
|  11 |   FILTER                                  |                        |       |       |            |          |
|  12 |    TABLE ACCESS BY INDEX ROWID BATCHED    | G_PIECEDET             |     1 |    28 |     5   (0)| 00:00:01 |
|  13 |     INDEX RANGE SCAN                      | G_PIECEDET_REFP        |     2 |       |     4   (0)| 00:00:01 |
|  14 |  NESTED LOOPS OUTER                       |                        |     1 |   572 |    20   (0)| 00:00:01 |
|  15 |   NESTED LOOPS                            |                        |     1 |   554 |    17   (0)| 00:00:01 |
|  16 |    NESTED LOOPS                           |                        |     1 |   450 |    15   (0)| 00:00:01 |
|  17 |     NESTED LOOPS                          |                        |     1 |   429 |    14   (0)| 00:00:01 |
|  18 |      NESTED LOOPS                         |                        |     1 |   407 |    12   (0)| 00:00:01 |
|  19 |       NESTED LOOPS                        |                        |     1 |   385 |    10   (0)| 00:00:01 |
|  20 |        NESTED LOOPS                       |                        |     1 |   136 |     7   (0)| 00:00:01 |
|  21 |         COLLECTION ITERATOR PICKLER FETCH |                        |     1 |     2 |     5   (0)| 00:00:01 |
|  22 |         TABLE ACCESS BY INDEX ROWID       | G_ELEMFI               |     1 |   134 |     2   (0)| 00:00:01 |
|  23 |          INDEX UNIQUE SCAN                | EFI_REFELEM            |     1 |       |     1   (0)| 00:00:01 |
|  24 |        TABLE ACCESS BY INDEX ROWID BATCHED| G_PIECE                |     1 |   249 |     3   (0)| 00:00:01 |
|  25 |         INDEX RANGE SCAN                  | PIE_REFPIECE           |     1 |       |     2   (0)| 00:00:01 |
|  26 |       INDEX RANGE SCAN                    | DOS_REFDOSS_REFLOT_IDX |     1 |    22 |     2   (0)| 00:00:01 |
|  27 |      INDEX RANGE SCAN                     | DOS_REFDOSS_REFLOT_IDX |     1 |    22 |     2   (0)| 00:00:01 |
|  28 |     INDEX RANGE SCAN                      | VF_TYPE_FINANCING      |     1 |    21 |     1   (0)| 00:00:01 |
|  29 |    TABLE ACCESS BY INDEX ROWID            | G_DB_PTF_ITEM          |     1 |   104 |     2   (0)| 00:00:01 |
|  30 |     INDEX UNIQUE SCAN                     | PK_G_DB_PTF_ITEM       |     1 |       |     1   (0)| 00:00:01 |
|  31 |   TABLE ACCESS BY INDEX ROWID BATCHED     | T_ECRDOS               |     1 |    18 |     3   (0)| 00:00:01 |
|  32 |    INDEX RANGE SCAN                       | TECR_REFELEM           |     1 |       |     2   (0)| 00:00:01 |
--------------------------------------------------------------------------------------------------------------------
Hint Report (identified by operation id / Query Block Name / Object Alias):
Total hints for statement: 1 (U - Unused (1))
---------------------------------------------------------------------------
  21 -  SEL$B3C83B60 / KOKBF$0@SEL$8
         U -  use_nl(I E P C S)


-- bmvm2ucnh7nvf

INSTANCE_NUMBER SQL_ID            ELAPSED MAX_WAIT_ON     PC_OF  WAIT_TIME            GETS      READS       ROWS  ELAP/EXEC       GETS/EXEC READS/EXEC  ROWS/EXEC       EXEC PLAN_HASH_VALUE
--------------- ------------- ----------- --------------- ----- ---------- --------------- ---------- ---------- ---------- --------------- ---------- ---------- ---------- ---------------
              1 bmvm2ucnh7nvf        8440 CPU             76%   6965.84206       820103647   29133803     122938       4.29          416931   14811.29       62.5       1967      1071232742
              1 bmvm2ucnh7nvf           0 CPU             100%     .014785              46          0          2        .01              23          0          1          2      4047444194

SQL_ID        SQL_PLAN_HASH_VALUE SQL_PLAN_LINE_ID SQL_PLAN_OPERATION             SQL_PLAN_OPTIONS                   ACTIVE
------------- ------------------- ---------------- ------------------------------ ------------------------------ ----------
bmvm2ucnh7nvf          1071232742               12 TABLE ACCESS                   STORAGE FULL                          508
bmvm2ucnh7nvf          1071232742               13 TABLE ACCESS                   STORAGE FULL                          179
bmvm2ucnh7nvf          1071232742                8 HASH JOIN                                                            165
bmvm2ucnh7nvf          1071232742                7 HASH JOIN                                                             58
bmvm2ucnh7nvf          1071232742                3 HASH JOIN                                                              1
bmvm2ucnh7nvf          1071232742               14 INDEX                          RANGE SCAN                              1
bmvm2ucnh7nvf          1302990442                3 HASH JOIN                                                              1
bmvm2ucnh7nvf          3130452715               14 TABLE ACCESS                   BY INDEX ROWID                          1
bmvm2ucnh7nvf          3469079566               12 COLLECTION ITERATOR            PICKLER FETCH                           1
bmvm2ucnh7nvf          4047444194                2 SORT                           ORDER BY                                2
bmvm2ucnh7nvf          4047444194               11 TABLE ACCESS                   BY INDEX ROWID                          1
bmvm2ucnh7nvf          4047444194               17 TABLE ACCESS                   BY INDEX ROWID                          1
bmvm2ucnh7nvf          4047444194                1 FOR UPDATE                                                             1
bmvm2ucnh7nvf          4047444194               15 INDEX                          UNIQUE SCAN                             1



Plan hash value: 1071232742
------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                  | Name              | Rows  | Bytes |TempSpc| Cost (%CPU)| Time     |
------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                           |                   |       |       |       | 39546 (100)|          |
|   1 |  FOR UPDATE                                |                   |       |       |       |            |          |
|   2 |   SORT ORDER BY                            |                   |  7280 |    14M|    18M| 39546   (4)| 00:00:02 |
|   3 |    HASH JOIN                               |                   |  7280 |    14M|       | 37113   (5)| 00:00:02 |
|   4 |     INDEX FULL SCAN                        | VF_TYPE_FINANCING |   146 |  2774 |       |     1   (0)| 00:00:01 |
|   5 |     NESTED LOOPS                           |                   |  7230 |    14M|       | 37112   (5)| 00:00:02 |
|   6 |      NESTED LOOPS                          |                   |  7631 |    14M|       | 37112   (5)| 00:00:02 |
|   7 |       HASH JOIN                            |                   |  7631 |    14M|    16M| 14172  (11)| 00:00:01 |
|   8 |        HASH JOIN                           |                   |  8168 |    15M|    15M| 10339   (9)| 00:00:01 |
|   9 |         VIEW                               |                   |  8168 |    15M|       |     5   (0)| 00:00:01 |
|  10 |          COUNT                             |                   |       |       |       |            |          |
|  11 |           COLLECTION ITERATOR PICKLER FETCH|                   |  8168 | 16336 |       |     5   (0)| 00:00:01 |
|  12 |         TABLE ACCESS STORAGE FULL          | G_ELEMFI          |  4216K|   120M|       |  8656   (9)| 00:00:01 |
|  13 |        TABLE ACCESS STORAGE FULL           | G_DB_PTF_ITEM     |  3939K|    41M|       |  2836  (15)| 00:00:01 |
|  14 |       INDEX RANGE SCAN                     | PIE_REFPIECE      |     1 |       |       |     2   (0)| 00:00:01 |
|  15 |      TABLE ACCESS BY INDEX ROWID           | G_PIECE           |     1 |    25 |       |     3   (0)| 00:00:01 |
------------------------------------------------------------------------------------------------------------------------



Plan hash value: 4047444194
----------------------------------------------------------------------------------------------------------------
| Id  | Operation                                  | Name              | Rows  | Bytes | Cost (%CPU)| Time     |
----------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                           |                   |       |       |    14 (100)|          |
|   1 |  FOR UPDATE                                |                   |       |       |            |          |
|   2 |   SORT ORDER BY                            |                   |     1 |  2100 |    14   (8)| 00:00:01 |
|   3 |    NESTED LOOPS                            |                   |     1 |  2100 |    13   (0)| 00:00:01 |
|   4 |     NESTED LOOPS                           |                   |     1 |  2100 |    13   (0)| 00:00:01 |
|   5 |      NESTED LOOPS                          |                   |     1 |  2075 |    10   (0)| 00:00:01 |
|   6 |       NESTED LOOPS                         |                   |     1 |  2064 |     8   (0)| 00:00:01 |
|   7 |        NESTED LOOPS                        |                   |     1 |  2045 |     7   (0)| 00:00:01 |
|   8 |         VIEW                               |                   |     1 |  2015 |     5   (0)| 00:00:01 |
|   9 |          COUNT                             |                   |       |       |            |          |
|  10 |           COLLECTION ITERATOR PICKLER FETCH|                   |     1 |     2 |     5   (0)| 00:00:01 |
|  11 |         TABLE ACCESS BY INDEX ROWID        | G_ELEMFI          |     1 |    30 |     2   (0)| 00:00:01 |
|  12 |          INDEX UNIQUE SCAN                 | EFI_REFELEM       |     1 |       |     1   (0)| 00:00:01 |
|  13 |        INDEX RANGE SCAN                    | VF_TYPE_FINANCING |     1 |    19 |     1   (0)| 00:00:01 |
|  14 |       TABLE ACCESS BY INDEX ROWID          | G_DB_PTF_ITEM     |     1 |    11 |     2   (0)| 00:00:01 |
|  15 |        INDEX UNIQUE SCAN                   | PK_G_DB_PTF_ITEM  |     1 |       |     1   (0)| 00:00:01 |
|  16 |      INDEX RANGE SCAN                      | PIE_REFPIECE      |     1 |       |     2   (0)| 00:00:01 |
|  17 |     TABLE ACCESS BY INDEX ROWID            | G_PIECE           |     1 |    25 |     3   (0)| 00:00:01 |
----------------------------------------------------------------------------------------------------------------
         

*/
/********************************OLD Metrics***************************************/

/********************************New SQL*******************************************/
-- 704gz4270y0sh

SELECT /*+ leading(I E P C S V D T) use_nl(I E P C S V D T) */ 
 E.REFDOSS REF_DBACCOUNT,
 S.REFDOSS REF_SUBCONTRACT,
 S.REFLOT REF_CONTRACT,
 E.REFELEM REF_ITEM,
 P.REFPIECE REF_ITEM_DOCUMENT,
 E.REFEXT REF_ITEM_EXTERNAL,
 P.ROWID G_PIECE_ROWID,
 E.ROWID G_ELEMFI_ROWID,
 D.ROWID G_DB_PTF_ITEM_ROWID,
 P.GPIDEPOT REF_CESSION,
 P.REFSTOCK REF_CI_POLICY,
 D.DBP_POLICY REF_DBP_POLICY,
 D.DGP_POLICY REF_DGP_POLICY,
 DECODE(V.FINANCING, 'F', :B6, 'N', :B5) ITEM_FINANCING_TYPE,
 E.TYPE ITEM_ELEMENT_TYPE,
 P.ST09 ITEM_STATUS,
 P.FG34 STOP_FINANCING_STATUS,
 P.ST04 COVERAGE_ID,
 P.ST06 ORIGIN_NOTE,
 NVL(P.STR_20_1, 'OK') INDEMNIFIED_NOTE,
 E.CREATEUR ITEM_CREATOR,
 P.FG95 VERIFICATION_STATUS,
 NVL(P.ST20, 'x') REASSIGNMENT_REASON,
 NVL(D.GUARANT_STATUS, 'x') GUARANTEE_STATUS,
 (SELECT COUNT(1) FROM G_ELEMFI_AGGR WHERE REFFACTURE = P.REFPIECE) BUNDLE_COUNT,
 D.FG_POST_FIN_ITEM POST_FINANCING_STATUS,
 D.LIMIT_ADDIT_INFO LIMIT_ADDITIONAL_INFO,
 NVL(P.GPIADR3, 'x') RECALCULATION_REASON,
 ACC_FLAG.FROM_CHAR(E.ACTIF) FLAG_ACTIVE,
 DECODE(P.ST09, 'PCF', 1, 'PFIN', 1, 0) FLAG_PRE_CALCFIN,
 ACC_FLAG.FROM_CHAR(P.FG01) FLAG_FINANCABLE,
 ACC_FLAG.FROM_CHAR(P.FG02) FLAG_COVERABLE,
 ACC_FLAG.FROM_CHAR(P.FG14) FLAG_MANUAL_COVERAGE,
 ACC_FLAG.FROM_CHAR(DECODE(:B4, 410, P.FG41, NVL(P.FG38, P.FG41))) FLAG_MANUAL_FINANCING,
 ACC_FLAG.FROM_CHAR(P.FG28) FLAG_DOCUMENT_RECEIVED,
 DECODE(E.FLAG_CTX, 'C', :B3, :B2) FLAG_ITEM_LEVEL_CTX,
 ACC_FLAG.FROM_CHAR(P.FG38) FLAG_IS_FUNDED,
 ACC_FLAG.FROM_CHAR(P.FG63) FLAG_IS_CONFIRMED_BY_SUPPLIER,
 ACC_FLAG.FROM_CHAR(P.FG44) FLAG_BUNDLE_FUNDING_REQUEST,
 DECODE(P.DT01_DT, NULL, :B3, :B2) FLAG_IS_FIRST_CALCULATION,
 (SELECT DECODE(COUNT(1), 0, :B2, :B3)
    FROM ELIGIB_CTRL C
   WHERE C.REFFACTURE = P.REFPIECE
     AND C.DT_RESOLVE IS NULL) FLAG_HAS_ELIGIBILITY_CONTROLS,
 CASE
   WHEN E.TYPE IN ('FINANCEMENT SUR BIEN',
                   'REEVALUATION DU BIEN - AUGM',
                   'REEVALUATION DU BIEN - DIM',
                   'BON DE COMMANDE',
                   'BC SUR BL',
                   'BON DE LIVRAISON',
                   'BL FACTURE',
                   'PURCHASE ORDER') THEN
    :B3
   ELSE
    :B2
 END FLAG_IS_ABL,
 CASE
   WHEN E.TYPE IN ('INVENTORY',
                   'INVENTORY REVALUATION UP',
                   'INVENTORY REVALUATION DOWN') THEN
    :B3
   ELSE
    :B2
 END FLAG_IS_INVENTORY,
 CASE
   WHEN E.TYPE IN ('BILL OF LADING') THEN
    :B3
   ELSE
    :B2
 END FLAG_IS_BILL_OF_LADING,
 CASE
   WHEN E.TYPE IN ('SALES ORDER') THEN
    :B3
   ELSE
    :B2
 END FLAG_IS_SALES_ORDER,
 (SELECT /*+ no_unnest */
   DECODE(COUNT(1), 0, :B2, :B3)
    FROM G_PIECEDET
   WHERE REFPIECE = P.REFPIECE
     AND TYPE = 'FAC_SO') FLAG_IS_SALES_INVOICE,
 E.DTJOUR_DT ENTRY_DATE,
 E.DT_EMIS_DT DOCUMENT_DATE,
 E.DTDEBUT_DT DUE_DATE,
 (SELECT /*+ no_unnest */
   MIN(DT02_DT)
    FROM G_PIECEDET
   WHERE REFPIECE = P.REFPIECE
     AND TYPE = 'PROROGATION'
     AND DT01_DT IS NOT NULL) ORIGINAL_DUE_DATE,
 P.DT03_DT DELIVERY_DATE,
 E.DTANNUL_DT CANCELLATION_DATE,
 P.DT12_DT EXPECTED_FUNDING_DATE,
 P.DT15_DT FUNDING_DATE,
 P.DT20_DT MINIMUM_FINANCING_DATE,
 FTR_UTIL.SELECTLIMITCONSIDERATIONDATE('C',
                                       P.MT01,
                                       P.DT03,
                                       E.DT_EMIS,
                                       P.DT04) CREDIT_LIMIT_CONSIDER_DATE,
 P.DTMINUTES_DT FIRST_LIMIT_CONSUMPTION_DATE,
 P.DT13_DT CALCULATED_DUE_DATE,
 D.DT_FINAL_DUE FINAL_DUE_DATE,
 D.DT_GUARANTEE_STATUS GUARANTEE_STATUS_DATE,
 P.DT02_DT VALIDATION_DATE,
 E.DEVISE_MVT CURRENCY_MVT,
 E.MONTANT_MVT FACE_AMOUNT_MVT,
 T.MNT_DCPT FACE_AMOUNT_DEC,
 FTR_BALANCES.GETITEMBALANCE(E.REFELEM, FTR_BALANCES.C_CASE_CURRENCY) BALANCE_MVT,
 FTR_BALANCES.GETITEMBALANCE(E.REFELEM, FTR_BALANCES.C_SUBCONTRACT_CURRENCY) BALANCE_DEC,
 P.MT09 PREV_BALANCE_MVT,
 P.MT24 PREV_BALANCE_DEC,
 NVL(P.MT01, 0) COVERED_AMOUNT_MVT,
 NVL(P.MT01, 0) COVERED_AMOUNT_MVT_OLD,
 NVL(P.MT12, 0) EXTERNAL_COVERAGE_MVT,
 NVL(P.MT42, 0) MANUAL_FINANCING_BASE_MVT,
 NVL(P.MT02, 0) PREV_FINANCING_BASE_MVT,
 P.MT23 PREV_FINANCING_BASE_DEC,
 P.MT90 FINANCING_BASE_FROZEN_MVT,
 P.MT11 PREV_DISPUTE_AMOUNT_MVT,
 P.MT10 OLD_DISPUTES_FINANCIBLE,
 P.MT31 OLD_DIRECT_PAYMENTS,
 NVL(P.MT48, 0) PURCHASED_AMOUNT_MVT,
 NVL(P.MT30, 0) INDEMNIFIED_AMOUNT_MVT,
 P.MT14 FINANCING_MVT,
 NVL(P.MT03, 0) FINANCING_FINAL_MVT,
 NVL(P.MT04, 0) INITIAL_RESERVE_MVT,
 NVL(P.MT44, 0) COLLATERAL_TOTAL_MVT,
 P.MT43 CACHED_BALANCE_AT_FUNDING_MVT,
 NVL(P.MT79, 0) BUNDLE_REQUESTED_AMOUNT_DEC,
 P.MT76 FINANCING_BUNDLE_DEC,
 D.REQUESTED_FINBASE_DCPT REQUESTED_AMOUNT_DEC,
 NVL(D.SUSPENDED_AMOUNT_COV, 0) SUSPENDED_AMOUNT_COV_MVT,
 NVL(D.SUSPENDED_AMOUNT_FIN, 0) SUSPENDED_AMOUNT_FIN_MVT,
 NVL(D.MT_SUSPENDED_DISPUTES, 0) SUSPENDED_DISPUTES_MVT,
 NVL((SELECT SUM(L.MT02)
       FROM G_PIECEDET L
      WHERE E.TYPE = 'PURCHASE ORDER'
        AND L.REFPIECE = E.REFPIECE3
        AND L.TYPE = 'PO_ITEMS'
        AND L.FG02 = 'O'),
     0) PO_NOT_FINANCIABLE_AMOUNT_MVT,
 P.TX16 / 100 RATE_CREDIT_COVERAGE,
 P.TX16 / 100 RATE_CREDIT_COVERAGE_OLD,
 P.TX10 / 100 RATE_COVERED,
 P.TX11 / 100 RATE_NOT_COVERED,
 P.TX12 / 100 RATE_BILL_OF_EXCHANGE,
 P.STR_5_2 RATE_CODE_COVERED,
 P.STR_5_3 RATE_CODE_NOT_COVERED,
 P.STR_5_4 RATE_CODE_BILL_OF_EXCHANGE,
 P.TX02 / 100 RATE_COVERED_OLD,
 P.TX03 / 100 RATE_NOT_COVERED_OLD,
 P.TX05 / 100 RATE_BILL_OF_EXCHANGE_OLD,
 P.ST01 RATE_CODE_COVERED_OLD,
 P.ST02 RATE_CODE_NOT_COVERED_OLD,
 P.ST03 RATE_CODE_BILL_OF_EXCHANGE_OLD
  FROM G_ELEMFI E,
       G_PIECE P,
       G_DOSSIER C,
       G_DOSSIER S,
       V_ELEMFI V,
       T_ECRDOS T,
       G_DB_PTF_ITEM D,
       (SELECT COLUMN_VALUE REFELEM FROM TABLE(CAST(:B1 AS REFLIST_T))) I
 WHERE P.REFPIECE = E.REFPIECE2
   AND P.TYPPIECE = 'FACTURE'
   AND E.REFELEM = I.REFELEM
   AND C.REFDOSS = E.REFDOSS
   AND S.REFDOSS = C.REFLOT
   AND V.TYPE = E.TYPE
   AND T.REFELEM(+) = E.REFELEM
   AND T.CODECR(+) IN ('PRIN', 'DPRIN')
   AND D.REFELEM = E.REFELEM;


-- bmvm2ucnh7nvf

SELECT /*+ leading(I E P V D) index(E EFI_REFELEM) index(D PK_G_DB_PTF_ITEM ) use_nl(E P V D) index_rs(V VF_TYPE_FINANCING)*/
    E.REFELEM
  FROM G_ELEMFI E,
       G_PIECE P,
       V_ELEMFI V,
       G_DB_PTF_ITEM D,
       (SELECT /*+ cardinality(A 5)*/
         ROWNUM ORDER_ID, COLUMN_VALUE REFELEM
          FROM TABLE(CAST(:B1 AS REFLIST_T))) I
WHERE P.REFPIECE = E.REFPIECE2
   AND P.TYPPIECE = 'FACTURE'
   AND E.REFELEM = I.REFELEM
   AND V.TYPE = E.TYPE
   AND D.REFELEM = E.REFELEM
   FOR UPDATE OF P.MT09, P.MT24, E.ACTIF, D.SUSPENDED_AMOUNT_FIN NOWAIT
ORDER BY ORDER_ID;   
/********************************New SQL*******************************************/
/********************************New Metrics***************************************/
/*
-- 704gz4270y0sh


Plan hash value: 459493644
-------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                 | Name                   | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers |
-------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                          |                        |      1 |        |   106K(100)|      0 |00:00:00.01 |    3123 |
|   1 |  NESTED LOOPS OUTER                       |                        |      1 |   7297 |   106K  (1)|      0 |00:00:00.01 |    3123 |
|   2 |   NESTED LOOPS                            |                        |      1 |   7280 | 85021   (1)|      0 |00:00:00.01 |    3123 |
|   3 |    NESTED LOOPS                           |                        |      1 |   7280 | 70951   (1)|      0 |00:00:00.01 |    3123 |
|   4 |     NESTED LOOPS                          |                        |      1 |   7230 | 70676   (1)|      0 |00:00:00.01 |    3123 |
|   5 |      NESTED LOOPS                         |                        |      1 |   7247 | 56159   (1)|      0 |00:00:00.01 |    3123 |
|   6 |       NESTED LOOPS                        |                        |      1 |   7610 | 40915   (1)|    587 |00:00:00.01 |    3123 |
|   7 |        NESTED LOOPS                       |                        |      1 |   8168 | 16371   (1)|    587 |00:00:00.01 |    1404 |
|   8 |         COLLECTION ITERATOR PICKLER FETCH | SHOW_INVOICE_LIST      |      1 |   8168 |     5   (0)|    587 |00:00:00.01 |       0 |
|   9 |         TABLE ACCESS BY INDEX ROWID       | G_ELEMFI               |    587 |      1 |     2   (0)|    587 |00:00:00.01 |    1404 |
|* 10 |          INDEX UNIQUE SCAN                | EFI_REFELEM            |    587 |      1 |     1   (0)|    587 |00:00:00.01 |     817 |
|* 11 |        TABLE ACCESS BY INDEX ROWID BATCHED| G_PIECE                |    587 |      1 |     3   (0)|    587 |00:00:00.01 |    1719 |
|* 12 |         INDEX RANGE SCAN                  | PIE_REFPIECE           |    587 |      1 |     2   (0)|    587 |00:00:00.01 |     928 |
|* 13 |       INDEX RANGE SCAN                    | DOS_REFDOSS_REFLOT_IDX |    587 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |
|* 14 |      INDEX RANGE SCAN                     | DOS_REFDOSS_REFLOT_IDX |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |
|* 15 |     INDEX STORAGE FAST FULL SCAN          | VF_TYPE_FINANCING      |      0 |      1 |     0   (0)|      0 |00:00:00.01 |       0 |
|  16 |    TABLE ACCESS BY INDEX ROWID            | G_DB_PTF_ITEM          |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |
|* 17 |     INDEX UNIQUE SCAN                     | PK_G_DB_PTF_ITEM       |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 18 |   TABLE ACCESS BY INDEX ROWID BATCHED     | T_ECRDOS               |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|* 19 |    INDEX RANGE SCAN                       | TECR_REFELEM           |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |
-------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
  10 - access("E"."REFELEM"=VALUE(KOKBF$))
  11 - filter("P"."TYPPIECE"='FACTURE')
  12 - access("P"."REFPIECE"="E"."REFPIECE2")
  13 - access("C"."REFDOSS"="E"."REFDOSS")
  14 - access("S"."REFDOSS"="C"."REFLOT")
  15 - storage("V"."TYPE"="E"."TYPE")
       filter("V"."TYPE"="E"."TYPE")
  17 - access("D"."REFELEM"="E"."REFELEM")
  18 - filter(("T"."CODECR"='DPRIN' OR "T"."CODECR"='PRIN'))
  19 - access("T"."REFELEM"="E"."REFELEM")

Hint Report (identified by operation id / Query Block Name / Object Alias):
Total hints for statement: 9 (U - Unused (1))
---------------------------------------------------------------------------

   1 -  SEL$5C160134
           -  leading(I E P C S V D T)

   8 -  SEL$5C160134 / KOKBF$0@SEL$3
         U -  use_nl(I E P C S V D T)

   9 -  SEL$5C160134 / E@SEL$1
           -  use_nl(I E P C S V D T)

  11 -  SEL$5C160134 / P@SEL$1
           -  use_nl(I E P C S V D T)

  13 -  SEL$5C160134 / C@SEL$1
           -  use_nl(I E P C S V D T)

  14 -  SEL$5C160134 / S@SEL$1
           -  use_nl(I E P C S V D T)

  15 -  SEL$5C160134 / V@SEL$1
           -  use_nl(I E P C S V D T)

  16 -  SEL$5C160134 / D@SEL$1
           -  use_nl(I E P C S V D T)

  18 -  SEL$5C160134 / T@SEL$1
           -  use_nl(I E P C S V D T)


-- bmvm2ucnh7nvf


Plan hash value: 3609405363
---------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                  | Name              | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers |
---------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                           |                   |      1 |        | 65915 (100)|    587 |00:00:00.01 |    8082 |
|   1 |  FOR UPDATE                                |                   |      1 |        |            |    587 |00:00:00.01 |    8082 |
|   2 |   SORT ORDER BY                            |                   |      2 |   7663 | 65915   (1)|   1174 |00:00:00.01 |    5147 |
|   3 |    NESTED LOOPS                            |                   |      1 |   7663 | 63355   (1)|    587 |00:00:00.01 |    5147 |
|   4 |     NESTED LOOPS                           |                   |      1 |   7663 | 63355   (1)|    587 |00:00:00.01 |    4560 |
|   5 |      NESTED LOOPS                          |                   |      1 |   7663 | 48546   (1)|    587 |00:00:00.01 |    3747 |
|   6 |       NESTED LOOPS                         |                   |      1 |   7610 | 40924   (1)|    587 |00:00:00.01 |    3744 |
|   7 |        NESTED LOOPS                        |                   |      1 |   8168 | 16370   (1)|    587 |00:00:00.01 |    1404 |
|   8 |         VIEW                               |                   |      1 |   8168 |     5   (0)|    587 |00:00:00.01 |       0 |
|   9 |          COUNT                             |                   |      1 |        |            |    587 |00:00:00.01 |       0 |
|  10 |           COLLECTION ITERATOR PICKLER FETCH| SHOW_INVOICE_LIST |      1 |   8168 |     5   (0)|    587 |00:00:00.01 |       0 |
|  11 |         TABLE ACCESS BY INDEX ROWID        | G_ELEMFI          |    587 |      1 |     2   (0)|    587 |00:00:00.01 |    1404 |
|* 12 |          INDEX UNIQUE SCAN                 | EFI_REFELEM       |    587 |      1 |     1   (0)|    587 |00:00:00.01 |     817 |
|* 13 |        TABLE ACCESS BY INDEX ROWID BATCHED | G_PIECE           |    587 |      1 |     3   (0)|    587 |00:00:00.01 |    2340 |
|* 14 |         INDEX RANGE SCAN                   | PIE_REFPIECE      |    587 |      1 |     2   (0)|    587 |00:00:00.01 |     928 |
|* 15 |       INDEX RANGE SCAN                     | VF_TYPE_FINANCING |    587 |      1 |     1   (0)|    587 |00:00:00.01 |       3 |
|* 16 |      INDEX UNIQUE SCAN                     | PK_G_DB_PTF_ITEM  |    587 |      1 |     1   (0)|    587 |00:00:00.01 |     813 |
|  17 |     TABLE ACCESS BY INDEX ROWID            | G_DB_PTF_ITEM     |    587 |      1 |     2   (0)|    587 |00:00:00.01 |     587 |
---------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
  12 - access("E"."REFELEM"="I"."REFELEM")
  13 - filter("P"."TYPPIECE"='FACTURE')
  14 - access("P"."REFPIECE"="E"."REFPIECE2")
  15 - access("V"."TYPE"="E"."TYPE")
  16 - access("D"."REFELEM"="E"."REFELEM")

Hint Report (identified by operation id / Query Block Name / Object Alias):
Total hints for statement: 8
---------------------------------------------------------------------------

   1 -  SEL$1
           -  leading(I E P V D)

  11 -  SEL$1 / E@SEL$1
           -  index(E EFI_REFELEM)
           -  use_nl(E P V D)

  13 -  SEL$1 / P@SEL$1
           -  use_nl(E P V D)

  15 -  SEL$1 / V@SEL$1
           -  index_rs(V VF_TYPE_FINANCING)
           -  use_nl(E P V D)

  16 -  SEL$1 / D@SEL$1
           -  index(D PK_G_DB_PTF_ITEM )
           -  use_nl(E P V D)
         

*/
/********************************New Metrics***************************************/

/********************************Index statistics**********************************/

/********************************Other SQLs****************************************/          
/*

*/ 
/********************************Other SQLs****************************************/              
