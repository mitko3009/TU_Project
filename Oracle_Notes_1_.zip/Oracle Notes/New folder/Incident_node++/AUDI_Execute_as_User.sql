################################################
################################################

Hello colleagues,

we can't do this wit our L4 permissions.
Can you pls. execute the following on T_MSQP + P_MSQP an send us the results?

select name, value from v$parameter where name in ('parallel_degree_limit','cpu_count','parallel_threads_per_cpu');

Thanks 

--> selectvat ot v$parameter
     pushti go s as sysdba




########################################
#########################################
Ако трябва да го ексекютна като някой юзър


като A4MSQP  
ами най-добре е да се логнеш като А4 юзъра
geta -u A4MSQP -p
 


 
[‎5/‎4/‎2020 1:00 PM]  Shterev, Ivaylo:  
No Title 
APPLICATION_NAME     USER_NAME            SERVICE_NAME         SRV_INST_NAME USR_INST_NAME STAGE_NAME           PRIMARY_SE USR_APP_NAME         SRV_APP_NAME         DESCRIPTION
-------------------- -------------------- -------------------- ------------- ------------- -------------------- ---------- -------------------- -------------------- -----------------------------------
199_MSQP             A4MSQP               E_MSQP_1234          E60013        E60013        TuI                  iudb953    199_MSQP             199_MSQP             blank
199_MSQP             A4MSQP               P_MSQP_703           P60015        P60015        LIVE                 iudb921    199_MSQP             199_MSQP             blank
199_MSQP             A4MSQP               T_MSQP               T60010        T60010        PRELIVE              iudb952    199_MSQP             199_MSQP             blank
199_MSQP             A4MSQP               T_MSQP012014         T60014        T60014        PRELIVE              iudb953    199_MSQP             199_MSQP             blank



[oracle@ivmg700(Production)  ~]$ con -c P60015
 Please enter hpioshtv's password: 
 
[‎5/‎4/‎2020 1:00 PM]  Shterev, Ivaylo:  
No Title 
Connected.


HPIOSHTV@P60015 >set lines 512
set pages 1000
col USERNAME format A25
col ACCOUNT_STATUS format A17
col PASSWORD format A30
col PROFILE for a30
select USERNAME,ACCOUNT_STATUS,LOCK_DATE,CREATED,expiry_date, PASSWORD, PROFILE,expiry_date,DEFAULT_TABLESPACE,TEMPORARY_TABLESPACE from dba_users
where username like '%MSQP%'
--where account_status='OPEN'
--and USERNAME not like 'HP%'
  5  order by USERNAME,ACCOUNT_STATUS;

USERNAME                  ACCOUNT_STATUS    LOCK_DATE           CREATED             EXPIRY_DATE         PASSWORD                       PROFILE                        EXPIRY_DATE         DEFAULT_TABLESPACE             TEMPORARY_TABLESPACE
------------------------- ----------------- ------------------- ------------------- ------------------- ------------------------------ ------------------------------ ------------------- ------------------------------ ------------------------------
A4MSQP                    OPEN                                  09.07.2019 08:32:06 08.07.2020 08:32:06                                AUDI_TECHUSER_PROFILE          08.07.2020 08:32:06 MSQP_DAT_OBJ                   MSQP_TEMP
U4MSQP                    OPEN                                  09.07.2019 08:32:07                                                    AUDI_U4USER_PROFILE                                MSQP_DAT_OBJ                   MSQP_TEMP
U4MSQPREAD                OPEN                                  09.07.2019 08:32:22                                                    AUDI_U4USER_PROFILE                                MSQP_DAT_OBJ                   MSQP_TEMP 
 


[‎5/‎4/‎2020 1:01 PM]  Shterev, Ivaylo:  
te share-vat edin i sysht
v nai-loshiq slucahi shte e s U4MSQP
za da ti e spokoino i da zadalbaesh malko poveche 
 


 
[‎5/‎4/‎2020 1:02 PM]  Shterev, Ivaylo:  
a inache kogato se chudish koi adjeba ti e usera primerno
select * from (dadena tablica)
mojesh da vidish kato
 

 
sysdba > select owner,object_type,object_name from all_objects where object_name = 'dadenata tablica';
taka shte ti e nai-sigurno 
kakto kazah rqdko davat s koi user iskat da im se puskat neshtata
 

 ############################################
 #############################################
 
  как се рънва стейтмънт като друг юзър
 [oracle@ivmg700(Production)  ~]$ geta -n 366_WLTPV -d E60020 -p -u A4WLTPV1 

[oracle@ivmg700(Production)  ~]$ sqlplus A4WLTPV1@E60020 
i slagash parlata



Email was sent to the requestor.

There were errors in the insert statement I have correct it and executed it, please check from you’re your side.

A4WLTPV1@E60020 >select * from wltpv_conversion;

no rows selected

A4WLTPV1@E60020 > INSERT INTO wltpv_conversion (id, bid, iso_code, type_of_emission, type_of_fuel, unit, factor) VALUES (0, 180, 'DEU', 'CONSUMPTION', 'ELECTRICAL', 'kWh/100km', 0.1);
INSERT INTO wltpv_conversion (id, bid, iso_code, type_of_emission, type_of_fuel, unit, factor) VALUES (1, 180, 'DEU', 'CONSUMPTION', 'CNG', 'kg/100km', 0.6540000000);
INSERT INTO wltpv_conversion (id, bid, iso_code, type_of_emission, type_of_fuel, unit, factor) VALUES (2, 908, 'DEU', 'CONSUMPTION', 'ELECTRICAL', 'kWh/100km', 0.1);
INSERT INTO wltpv_conversion (id, bid, iso_code, type_of_emission, type_of_fuel, unit, factor) VALUES (3, 908, 'DEU', 'CONSUMPTION', 'CNG', 'kg/100km', 0.6540000000);

1 row created.

A4WLTPV1@E60020 >
1 row created.

A4WLTPV1@E60020 >
1 row created.

A4WLTPV1@E60020 >
1 row created.

A4WLTPV1@E60020 >
A4WLTPV1@E60020 >commit;

Commit complete.


A4WLTPV1@E60020 > select * from wltpv_conversion;

ID BID ISO_CODE TYPE_OF_EMISSION TYPE_OF_FUEL UNIT FACTOR
---------- -------------------- -------------------- -------------------- -------------------- -------------------- ----------
0 180 DEU CONSUMPTION ELECTRICAL kWh/100km .1
1 180 DEU CONSUMPTION CNG kg/100km .654
2 908 DEU CONSUMPTION ELECTRICAL kWh/100km .1
3 908 DEU CONSUMPTION CNG kg/100km .654

If the result is not satisfied we can revert it.


 

 
