/********************************************************************************
*********       E-mail subject: FGADEV-5301
*********             Instance: UAT
*********          Description: 
Problem:
Slow query on UAT from paytweak_integration.processSMSLienPmtCb function.

Analysis:
The provided query was slow.
The problem was that oracle use inappropriate execution plan and start from table v_domaine instead of table g_dossier.

Suggestion:
Please add hint as it is shown in the New SQL section below to navigate oracle to start from table g_dossier.

*********               SQL_ID: a6792e8ac3ad4b1e
*********      Program/Package: paytweak_integration
*********              Request: Truong Nguyen
*********               Author: Dimitar Dimitrov
********* Received e-mail date: 14/07/2023
*********      Resolution date: 14/07/2023
*********  Trace old file here: \\epox\specifs\performance\tmp\
*********  Trace new file here:
***********************************************************************************/

/********************************OLD SQL*******************************************/
SELECT v.valeur
      ,v.abrev1
      ,v.abrev2
  FROM v_domaine      v
      ,t_intervenants t
      ,g_dossier      d
 WHERE v.champ = 'PROD'
   AND v.ecran = 'API'
   AND v.type = 'TMPL_PMT_CB'
   AND v.abrev = t.refindividu
   AND t.reftype = 'CL'
   AND t.refdoss = d.refdoss
   AND d.categdoss = 'AUTEUR'
   AND d.ancrefdoss = '113661166';
/********************************OLD SQL*******************************************/
/********************************OLD Metrics***************************************/
/*
Plan hash value: 460999439
-----------------------------------------------------------------------------------------------------------------
| Id  | Operation                      | Name        | Starts | E-Rows | A-Rows |   A-Time   | Buffers | Reads  |
-----------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT               |             |      1 |        |      1 |00:05:30.48 |    3428K|    791K|
|   1 |  NESTED LOOPS                  |             |      1 |        |      1 |00:05:30.48 |    3428K|    791K|
|   2 |   NESTED LOOPS                 |             |      1 |      1 |   5285K|00:00:29.80 |     555K|  40162 |
|   3 |    NESTED LOOPS                |             |      1 |      1 |   5285K|00:00:07.98 |   56997 |   8529 |
|*  4 |     TABLE ACCESS BY INDEX ROWID| V_DOMAINE   |      1 |      1 |      9 |00:00:00.01 |      10 |      6 |
|*  5 |      INDEX RANGE SCAN          | DOM_CHAMP   |      1 |      6 |     21 |00:00:00.01 |       3 |      2 |
|*  6 |     INDEX RANGE SCAN           | INT_INDIV   |      9 |      1 |   5285K|00:00:05.85 |   56987 |   8523 |
|*  7 |    INDEX UNIQUE SCAN           | DOS_REFDOSS |   5285K|      1 |   5285K|00:00:17.17 |     498K|  31633 |
|*  8 |   TABLE ACCESS BY INDEX ROWID  | G_DOSSIER   |   5285K|      1 |      1 |00:04:57.74 |    2873K|    751K|
-----------------------------------------------------------------------------------------------------------------

Predicate Information (identified by operation id):
---------------------------------------------------
   4 - filter(("V"."ECRAN"='API' AND "V"."TYPE"='TMPL_PMT_CB' AND "V"."ABREV" IS NOT NULL))
   5 - access("V"."CHAMP"='PROD')
   6 - access("V"."ABREV"="T"."REFINDIVIDU" AND "T"."REFTYPE"='CL')
   7 - access("T"."REFDOSS"="D"."REFDOSS")
   8 - filter(("D"."ANCREFDOSS"='113661166' AND "D"."CATEGDOSS"='AUTEUR'))

*/
/********************************OLD Metrics***************************************/

/********************************New SQL*******************************************/
SELECT /*+ leading(d t) */ v.valeur
      ,v.abrev1
      ,v.abrev2
  FROM v_domaine      v
      ,t_intervenants t
      ,g_dossier      d
 WHERE v.champ = 'PROD'
   AND v.ecran = 'API'
   AND v.type = 'TMPL_PMT_CB'
   AND v.abrev = t.refindividu
   AND t.reftype = 'CL'
   AND t.refdoss = d.refdoss
   AND d.categdoss = 'AUTEUR'
   AND d.ancrefdoss = '113661166';
/********************************New SQL*******************************************/
/********************************New Metrics***************************************/
/*
Plan hash value: 1287248398
---------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                      | Name           | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  |
---------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT               |                |      1 |        |     3 (100)|      1 |00:00:00.01 |      16 |      1 |
|   1 |  NESTED LOOPS                  |                |      1 |        |            |      1 |00:00:00.01 |      16 |      1 |
|   2 |   NESTED LOOPS                 |                |      1 |      1 |     3   (0)|      4 |00:00:00.01 |      13 |      1 |
|   3 |    NESTED LOOPS                |                |      1 |      1 |     2   (0)|      1 |00:00:00.01 |      10 |      0 |
|*  4 |     TABLE ACCESS BY INDEX ROWID| G_DOSSIER      |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       5 |      0 |
|*  5 |      INDEX RANGE SCAN          | DOS_ANCREFDOSS |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       4 |      0 |
|*  6 |     INDEX RANGE SCAN           | INT_REFDOSS    |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       5 |      0 |
|*  7 |    INDEX RANGE SCAN            | DOM_TYPABREV   |      1 |      1 |     1   (0)|      4 |00:00:00.01 |       3 |      1 |
|*  8 |   TABLE ACCESS BY INDEX ROWID  | V_DOMAINE      |      4 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |      0 |
---------------------------------------------------------------------------------------------------------------------------------

Predicate Information (identified by operation id):
---------------------------------------------------
   4 - filter("D"."CATEGDOSS"='AUTEUR')
   5 - access("D"."ANCREFDOSS"='113661166')
   6 - access("T"."REFDOSS"="D"."REFDOSS" AND "T"."REFTYPE"='CL')
   7 - access("V"."TYPE"='TMPL_PMT_CB' AND "V"."ABREV"="T"."REFINDIVIDU")
       filter("V"."ABREV" IS NOT NULL)
   8 - filter(("V"."ECRAN"='API' AND "V"."CHAMP"='PROD'))
*/
/********************************New Metrics***************************************/

/********************************Index statistics**********************************/

/********************************Other SQLs****************************************/          
/*

*/ 
/********************************Other SQLs****************************************/              
