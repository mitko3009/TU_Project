/********************************************************************************
*********       E-mail subject: BMCEDEV-1877
*********             Instance: PROD
*********          Description: 
Problem:
SQLs dcswxspru70gc, 18tgpdw1qdrn8 and 9r3j63p6ss2jx were identified as slow from AWR Report and during meeting with the client.

Analysis:
These three SQLs were tested manually and it was found that they were executed with bad execution plans, which leads to starting the execution from not selective predicate and looping through the tables for a lot of rows unnecessary.
It looks like the refdoss is the most selective predicate in the queries, so we changed them and added some hints to force Oracle to start the execution from the refdoss column for the provided refdoss and then join the other tables in the correct order by the correct way.

Suggestion:
1. Please check the queries in the New SQL section below are they functionally correct and if they are, please change them as it is shown in the New SQL section below.
2. Please check the type of these SE variables, whether they cannot be cached so they are not executed more than once per call.

*********               SQL_ID: dcswxspru70gc, 18tgpdw1qdrn8, 9r3j63p6ss2jx
*********      Program/Package: 
*********              Request: Dimitare Ivanov
*********               Author: Dimitar Dimitrov
********* Received e-mail date: 01/11/2024
*********      Resolution date: 13/11/2024
*********  Trace old file here: \\epox\specifs\performance\tmp\
*********  Trace new file here:
***********************************************************************************/

/********************************OLD SQL*******************************************/

-- dcswxspru70gc

var REFDOS VARCHAR2(32);
exec :REFDOS := '2407053698';

select count(*)
  from t_elements
 where refdoss in ( select ddc.refdoss
                      from t_intervenants cr,
                           t_intervenants idc,
                           g_dossier      ddc,
                           g_dossier      gd
                     where cr.refdoss = :refdos
                       and gd.refdoss = cr.refdoss
                       and nvl(gd.categdoss, 'x') = 'COMPTE CLIENT'
                       and cr.reftype = 'DB'
                       and idc.refindividu = cr.refindividu
                       and idc.reftype = 'DB'
                       and ddc.refdoss = idc.refdoss
                       and ddc.refdoss != gd.refdoss
                       and nvl( ddc.categdoss, 'x' ) = 'COMPTE COURANT' )
   and nvl(typeelem, 'x') = 'in'
   and nvl(libelle, 'x') = 'debut GEL';


-- 18tgpdw1qdrn8

var REFDOS VARCHAR2(32);
exec :REFDOS := '2412122729';
var REFDOS VARCHAR2(32);
exec :REFDOS := '2411071601';

select decode(rating, '1', 1, '0', 0, 0)
  from ext_scoring_note n,
       v_domaine d
 where n.nature = d.abrev
   and d.type = 'DV_NATURE_SCORE'
   and n.dtcreation_dt = ( select max(n1.dtcreation_dt)
                             from ext_scoring_note n1,
                                  v_domaine d1
                            where n1.nature = d1.abrev
                              and d1.type = 'DV_NATURE_SCORE'
                              and (  (    n1.refindividu is not null
                                        and n1.refindividu in ( select refindividu
                                                                from t_intervenants
                                                               where refdoss = :refdos
                                                                 and reftype = 'DB' ) )
                                   or n1.refdoss = :refdos )
                              and d1.abrev = 'INPF' )
   and d.abrev = 'INPF'
   and ( (    n.refindividu is not null
             and n.refindividu in ( select refindividu
                                   from t_intervenants
                                  where refdoss = :refdos
                                    and reftype = 'DB' ) )
       or n.refdoss = :refdos );


-- 9r3j63p6ss2jx

var REFDOS VARCHAR2(32);
exec :REFDOS := '2407053698';

select count(*)
  from g_dossier D,
       g_piece P,
       v_domaine V
 where D.refdoss in ( select ddc.refdoss
                        from t_intervenants cr,
                             t_intervenants idc,
                             g_dossier      ddc,
                             g_dossier      ccl
                       where ccl.refdoss = :refdos
                         and nvl(ccl.categdoss, 'x') = 'COMPTE CLIENT'
                         and cr.refdoss = ccl.refdoss
                         and cr.reftype = 'DB'
                         and idc.refindividu = cr.refindividu
                         and ddc.refdoss = idc.refdoss
                         and idc.reftype = 'DB'
                         and nvl(ddc.categdoss, 'x') = 'CREDIT AMORTISSABLE'
                         and nvl(ddc.fg_realization_of_cash_outflow, 'x') <> 'O' )
   and P.typpiece = D.pieceinit
   and V.valeur = P.typpiece
   and P.refdoss = D.refdoss
   and V.type = 'piece'
   and V.abrev = P.libelle_20_14
   and V.commentaire = 'INVEST';
/********************************OLD SQL*******************************************/
/********************************OLD Metrics***************************************/
/*
MODULE       PROGRAM    SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
------------ ---------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
msgq_pilote  msg_q03                                                                        2024/11/12 15:00:01  2024/11/13 09:59:58        4744             16752698 +000000000 18:59:57.048 25%
msgq_pilote  msg_queue                                                                      2024/11/12 15:00:01  2024/11/13 09:59:28        4679             16762962 +000000000 18:59:27.043 25%
msgq_pilote  msg_q02                                                                        2024/11/12 15:00:01  2024/11/13 09:59:58        4649             16766204 +000000000 18:59:57.048 25%
msgq_pilote  msg_q04                                                                        2024/11/12 15:00:01  2024/11/13 09:59:48        4646             16767146 +000000000 18:59:47.050 25%



MODULE       PROGRAM    SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
------------ ---------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
msgq_pilote                                                            ON CPU               2024/11/12 15:00:01  2024/11/13 09:59:58       18305             16767186 +000000000 18:59:57.048 98%
msgq_pilote                                    0                       log file sync        2024/11/12 15:01:11  2024/11/13 09:59:58         266                      +000000000 18:58:46.986 1%
msgq_pilote                                                            db file sequential r 2024/11/12 16:22:33  2024/11/13 09:57:28          94             16370929 +000000000 17:34:55.322 1%
msgq_pilote                                                            PGA memory operation 2024/11/12 16:41:43  2024/11/13 08:43:17          14             12734908 +000000000 16:01:33.824 0%
msgq_pilote                                                            log file switch (che 2024/11/12 23:08:47  2024/11/13 09:31:57          12             11191927 +000000000 10:23:10.245 0%
msgq_pilote                                                            buffer busy waits    2024/11/12 15:27:11  2024/11/13 06:10:54           9             16098795 +000000000 14:43:42.961 0%
msgq_pilote                                    0                       cursor: pin S        2024/11/12 16:30:03  2024/11/13 09:26:47           6                      +000000000 16:56:44.813 0%
msgq_pilote                                                            latch: cache buffers 2024/11/12 19:48:04  2024/11/12 23:03:17           3             10776878 +000000000 03:15:12.629 0%
msgq_pilote                                    0                       SQL*Net message to c 2024/11/13 05:37:44  2024/11/13 05:50:34           2                      +000000000 00:12:50.074 0%
msgq_pilote  msg_queue  9fyzycp9a53r3 2202919740        793      63856 row cache mutex      2024/11/13 04:53:13  2024/11/13 04:53:13           1                    1 +000000000 00:00:00.000 0%
msgq_pilote  msg_q03    1hv1z0bsw76t4          0        785      25794 library cache: mutex 2024/11/13 01:50:00  2024/11/13 01:50:00           1                    1 +000000000 00:00:00.000 0%
msgq_pilote  msg_q03    49vu7vaactbbj 1444700491       1009        609 enq: TM - contention 2024/11/12 23:06:17  2024/11/12 23:06:17           1                    1 +000000000 00:00:00.000 0%
msgq_pilote  msg_q04    49vu7vaactbbj 1444700491        785      52750 enq: TX - allocate I 2024/11/12 17:03:53  2024/11/12 17:03:53           1                    1 +000000000 00:00:00.000 0%
msgq_pilote  msg_q02    06gwnxhm9y6fp  808428077        935       8937 latch: In memory und 2024/11/12 20:59:45  2024/11/12 20:59:45           1                    1 +000000000 00:00:00.000 0%
msgq_pilote  msg_q02    4gwpgprkg2bm5 3672832161        793      53115 log buffer space     2024/11/13 09:15:07  2024/11/13 09:15:07           1                    1 +000000000 00:00:00.000 0%
msgq_pilote  msg_q03    b71wk8s9agdpg  939636261       1009      39570 SQL*Net more data to 2024/11/12 23:36:18  2024/11/12 23:36:18           1                    1 +000000000 00:00:00.000 0%



MODULE       PROGRAM    SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
------------ ---------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
msgq_pilote             dcswxspru70gc                                                       2024/11/12 15:00:01  2024/11/13 09:59:58        6736               251353 +000000000 18:59:57.048 36%
msgq_pilote             18tgpdw1qdrn8 1781451968                       ON CPU               2024/11/12 15:00:51  2024/11/13 09:59:48        3427               251243 +000000000 18:58:57.029 18%
msgq_pilote             9r3j63p6ss2jx  142860177                       ON CPU               2024/11/12 15:00:31  2024/11/13 09:45:48        1243                32757 +000000000 18:45:16.875 7%
msgq_pilote             5q9kwfwy8jdnx 2435390809                                            2024/11/12 15:00:11  2024/11/13 09:59:28        1193              8747065 +000000000 18:59:17.045 6%
msgq_pilote                                    0                                            2024/11/12 15:01:11  2024/11/13 09:59:58         962                    1 +000000000 18:58:46.986 5%
msgq_pilote             06gwnxhm9y6fp                                                       2024/11/12 15:03:01  2024/11/13 09:56:18         714              9071777 +000000000 18:53:16.888 4%
msgq_pilote             cgufjhvr9ybun                                                       2024/11/12 15:00:31  2024/11/13 09:58:38         624             16725245 +000000000 18:58:07.014 3%
msgq_pilote             21aq3h13yj129  550758355                       ON CPU               2024/11/12 15:02:31  2024/11/13 09:50:08         438                79917 +000000000 18:47:36.830 2%
msgq_pilote             9fyzycp9a53r3 2202919740                                            2024/11/12 15:00:31  2024/11/13 09:53:38         312              5941049 +000000000 18:53:06.982 2%
msgq_pilote             9j00x7bvkbgdc                                  ON CPU               2024/11/12 15:11:01  2024/11/13 08:46:07         122             16543526 +000000000 17:35:05.477 1%



SQL_ID            ELAPSED MAX_WAIT_ON     PC_OF  WAIT_TIME            GETS      READS       ROWS  ELAP/EXEC       GETS/EXEC READS/EXEC  ROWS/EXEC       EXEC PLAN_HASH_VALUE
------------- ----------- --------------- ----- ---------- --------------- ---------- ---------- ---------- --------------- ---------- ---------- ---------- ---------------
dcswxspru70gc       68961 CPU             100%  21361.1132      1684481921      20527     250826        .27            6701        .08          1     251393      3894923543
18tgpdw1qdrn8       33550 CPU             100%  10109.2046      6892236908       2192          0        .13           27416        .01          0     251396      1781451968
9r3j63p6ss2jx       12152 CPU             100%  3771.07936       346487179          3      27159        .45           12750          0          1      27175       142860177
5q9kwfwy8jdnx       11832 CPU             100%  3669.25254        87411640          0    8742045          0              10          0          1    8744452      2435390809


-- dcswxspru70gc

Plan hash value: 3894923543
-------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                        | Name                   | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  |
-------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                 |                        |      1 |        |   697 (100)|      1 |00:00:00.91 |   14117 |     10 |
|   1 |  SORT AGGREGATE                  |                        |      1 |      1 |            |      1 |00:00:00.91 |   14117 |     10 |
|   2 |   NESTED LOOPS                   |                        |      1 |      1 |   697   (1)|      0 |00:00:00.91 |   14117 |     10 |
|   3 |    VIEW                          | VW_NSO_1               |      1 |      1 |   695   (1)|      4 |00:00:00.90 |   14100 |      1 |
|   4 |     HASH UNIQUE                  |                        |      1 |      1 |            |      4 |00:00:00.90 |   14100 |      1 |
|   5 |      NESTED LOOPS SEMI           |                        |      1 |      1 |   695   (1)|      4 |00:00:00.90 |   14100 |      1 |
|*  6 |       HASH JOIN RIGHT SEMI       |                        |      1 |      3 |   694   (1)|      7 |00:00:00.90 |   14077 |      1 |
|*  7 |        INDEX RANGE SCAN          | INT_REFDOSS            |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |      1 |
|   8 |        NESTED LOOPS              |                        |      1 |    425K|   691   (1)|   1610K|00:00:00.64 |   14074 |      0 |
|*  9 |         INDEX SKIP SCAN          | REFHIERARCHIE_IDX      |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       7 |      0 |
|* 10 |         INDEX SKIP SCAN          | INT_INDIV              |      1 |    425K|   690   (1)|   1610K|00:00:00.52 |   14067 |      0 |
|* 11 |       TABLE ACCESS BY INDEX ROWID| G_DOSSIER              |      7 |  55842 |     1   (0)|      4 |00:00:00.01 |      23 |      0 |
|* 12 |        INDEX UNIQUE SCAN         | DOS_REFDOSS            |      7 |      1 |     1   (0)|      7 |00:00:00.01 |      16 |      0 |
|* 13 |    INDEX RANGE SCAN              | ELE_DOSS_TYP_ASSOC_LIB |      4 |      1 |     1   (0)|      0 |00:00:00.01 |      17 |      9 |
-------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   6 - access("GD"."REFDOSS"="CR"."REFDOSS" AND "IDC"."REFINDIVIDU"="CR"."REFINDIVIDU")
   7 - access("CR"."REFDOSS"=:REFDOS AND "CR"."REFTYPE"='DB')
   9 - access("GD"."CATEGDOSS"='COMPTE CLIENT' AND "GD"."REFDOSS"=:REFDOS)
       filter(("GD"."REFDOSS"=:REFDOS AND "GD"."CATEGDOSS"='COMPTE CLIENT'))
  10 - access("IDC"."REFTYPE"='DB')
       filter(("IDC"."REFTYPE"='DB' AND "IDC"."REFDOSS"<>:REFDOS))
  11 - filter("DDC"."CATEGDOSS"='COMPTE COURANT')
  12 - access("DDC"."REFDOSS"="IDC"."REFDOSS")
       filter(("DDC"."REFDOSS"<>"GD"."REFDOSS" AND "DDC"."REFDOSS"<>:REFDOS))
  13 - access("REFDOSS"="REFDOSS")
       filter((NVL("LIBELLE",'x')='debut GEL' AND NVL("TYPEELEM",'x')='in'))


-- 18tgpdw1qdrn8

Plan hash value: 1781451968
---------------------------------------------------------------------------------------------------------------------
| Id  | Operation                 | Name             | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers |
---------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT          |                  |      1 |        | 12625 (100)|      0 |00:00:00.15 |   28596 |
|*  1 |  FILTER                   |                  |      1 |        |            |      0 |00:00:00.15 |   28596 |
|   2 |   MERGE JOIN CARTESIAN    |                  |      1 |      1 |  6313   (1)|      0 |00:00:00.15 |   28596 |
|*  3 |    TABLE ACCESS FULL      | EXT_SCORING_NOTE |      1 |      1 |  6312   (1)|      0 |00:00:00.15 |   28596 |
|   4 |     SORT AGGREGATE        |                  |      0 |      1 |            |      0 |00:00:00.01 |       0 |
|*  5 |      FILTER               |                  |      0 |        |            |      0 |00:00:00.01 |       0 |
|   6 |       MERGE JOIN CARTESIAN|                  |      0 |      1 |  6313   (1)|      0 |00:00:00.01 |       0 |
|*  7 |        TABLE ACCESS FULL  | EXT_SCORING_NOTE |      0 |      1 |  6312   (1)|      0 |00:00:00.01 |       0 |
|   8 |        BUFFER SORT        |                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|*  9 |         INDEX RANGE SCAN  | DOM_TYPABREV     |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 10 |       INDEX RANGE SCAN    | INT_REFDOSS      |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|  11 |    BUFFER SORT            |                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 12 |     INDEX RANGE SCAN      | DOM_TYPABREV     |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 13 |   INDEX RANGE SCAN        | INT_REFDOSS      |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
---------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   1 - filter(("N"."REFDOSS"=:REFDOS OR ("N"."REFINDIVIDU" IS NOT NULL AND  IS NOT NULL)))
   3 - filter(("N"."NATURE"='INPF' AND "N"."DTCREATION_DT"=))
   5 - filter(("N1"."REFDOSS"=:REFDOS OR ("N1"."REFINDIVIDU" IS NOT NULL AND  IS NOT NULL)))
   7 - filter("N1"."NATURE"='INPF')
   9 - access("D1"."TYPE"='DV_NATURE_SCORE' AND "D1"."ABREV"='INPF')
  10 - access("REFDOSS"=:REFDOS AND "REFTYPE"='DB' AND "REFINDIVIDU"=:B1)
  12 - access("D"."TYPE"='DV_NATURE_SCORE' AND "D"."ABREV"='INPF')
  13 - access("REFDOSS"=:REFDOS AND "REFTYPE"='DB' AND "REFINDIVIDU"=:B1)


-- 9r3j63p6ss2jx

Plan hash value: 944872713
---------------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                               | Name                    | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  |
---------------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                        |                         |      1 |        |    18 (100)|      1 |00:00:03.58 |     115K|   3986 |
|   1 |  SORT AGGREGATE                         |                         |      1 |      1 |            |      1 |00:00:03.58 |     115K|   3986 |
|   2 |   NESTED LOOPS SEMI                     |                         |      1 |      1 |    18   (0)|      0 |00:00:03.58 |     115K|   3986 |
|   3 |    NESTED LOOPS                         |                         |      1 |      1 |    14   (0)|   5651 |00:00:01.74 |   28351 |   2096 |
|   4 |     NESTED LOOPS                        |                         |      1 |      1 |    13   (0)|   5651 |00:00:01.64 |   11460 |   2069 |
|*  5 |      TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE               |      1 |      1 |     1   (0)|     98 |00:00:00.01 |     176 |      0 |
|*  6 |       INDEX RANGE SCAN                  | V_DOMAINE_TYPE_CODE_IDX |      1 |     53 |     1   (0)|   2836 |00:00:00.01 |      24 |      0 |
|*  7 |      TABLE ACCESS BY INDEX ROWID BATCHED| G_PIECE                 |     98 |      3 |    12   (0)|   5651 |00:00:01.64 |   11284 |   2069 |
|*  8 |       INDEX RANGE SCAN                  | GP_ST02_FUNC_IDX        |     98 |   4533 |     1   (0)|   5689 |00:00:00.06 |     253 |     61 |
|*  9 |     TABLE ACCESS BY INDEX ROWID         | G_DOSSIER               |   5651 |      1 |     1   (0)|   5651 |00:00:00.10 |   16891 |     27 |
|* 10 |      INDEX UNIQUE SCAN                  | DOS_REFDOSS             |   5651 |      1 |     1   (0)|   5651 |00:00:00.06 |   11286 |     27 |
|  11 |    VIEW PUSHED PREDICATE                | VW_NSO_1                |   5651 |      1 |     4   (0)|      0 |00:00:01.83 |   86840 |   1890 |
|  12 |     NESTED LOOPS SEMI                   |                         |   5651 |      1 |     4   (0)|      0 |00:00:01.83 |   86840 |   1890 |
|  13 |      NESTED LOOPS                       |                         |   5651 |      1 |     3   (0)|   5651 |00:00:01.75 |   86827 |   1890 |
|  14 |       NESTED LOOPS                      |                         |   5651 |      1 |     2   (0)|   5651 |00:00:00.30 |   75450 |      0 |
|* 15 |        INDEX SKIP SCAN                  | REFHIERARCHIE_IDX       |   5651 |      1 |     1   (0)|   5651 |00:00:00.22 |   39887 |      0 |
|* 16 |        TABLE ACCESS BY INDEX ROWID      | G_DOSSIER               |   5651 |      1 |     1   (0)|   5651 |00:00:00.08 |   35563 |      0 |
|* 17 |         INDEX UNIQUE SCAN               | DOS_REFDOSS             |   5651 |      1 |     1   (0)|   5651 |00:00:00.02 |   11286 |      0 |
|* 18 |       INDEX RANGE SCAN                  | INT_REFDOSS             |   5651 |      1 |     1   (0)|   5651 |00:00:01.44 |   11377 |   1890 |
|* 19 |      INDEX RANGE SCAN                   | INT_REFDOSS             |   5651 |      1 |     1   (0)|      0 |00:00:00.01 |      13 |      0 |
---------------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   5 - filter("V"."COMMENTAIRE"='INVEST')
   6 - access("V"."TYPE"='piece')
   7 - filter(("P"."LIBELLE_20_14" IS NOT NULL AND "V"."ABREV"="P"."LIBELLE_20_14"))
   8 - access("V"."VALEUR"="P"."TYPPIECE")
   9 - filter("P"."TYPPIECE"="D"."PIECEINIT")
  10 - access("P"."REFDOSS"="D"."REFDOSS")
  15 - access("CCL"."CATEGDOSS"='COMPTE CLIENT' AND "CCL"."REFDOSS"=:REFDOS)
       filter(("CCL"."REFDOSS"=:REFDOS AND "CCL"."CATEGDOSS"='COMPTE CLIENT'))
  16 - filter(("DDC"."CATEGDOSS"='CREDIT AMORTISSABLE' AND NVL("DDC"."FG_REALIZATION_OF_CASH_OUTFLOW",'x')<>'O'))
  17 - access("DDC"."REFDOSS"="D"."REFDOSS")
  18 - access("IDC"."REFDOSS"="D"."REFDOSS" AND "IDC"."REFTYPE"='DB')
  19 - access("CR"."REFDOSS"=:REFDOS AND "CR"."REFTYPE"='DB' AND "IDC"."REFINDIVIDU"="CR"."REFINDIVIDU")
*/
/********************************OLD Metrics***************************************/

/********************************New SQL*******************************************/

-- dcswxspru70gc

select count(*)
  from t_elements
 where refdoss in ( select /*+ leading(cr gd idc ddc) index(cr INT_REFDOSS) use_nl(gd idc ddc) */
                           ddc.refdoss
                      from t_intervenants cr,
                           t_intervenants idc,
                           g_dossier      ddc,
                           g_dossier      gd
                     where cr.refdoss = :refdos
                       and gd.refdoss = cr.refdoss
                       and nvl(gd.categdoss, 'x') = 'COMPTE CLIENT'
                       and cr.reftype = 'DB'
                       and idc.refindividu = cr.refindividu
                       and idc.reftype = 'DB'
                       and ddc.refdoss = idc.refdoss
                       and ddc.refdoss != gd.refdoss
                       and nvl( ddc.categdoss, 'x' ) = 'COMPTE COURANT' )
   and nvl(typeelem, 'x') = 'in'
   and nvl(libelle, 'x') = 'debut GEL'
   and rownum = 1;


-- 18tgpdw1qdrn8

select decode(rating, '1', 1, '0', 0, 0)
  from ( select n1.rating,
                n1.dtcreation_dt,
                max(n1.dtcreation_dt) over() as max_dtcreation_dt
           from ( select n.nature,
                         n.dtcreation_dt,
                         n.rating
                    from ext_scoring_note n
                   where n.refindividu in ( select refindividu
                                              from t_intervenants
                                             where refdoss = :refdos
                                               and reftype = 'DB' )
                   union
                  select n.nature,
                         n.dtcreation_dt,
                         n.rating
                    from ext_scoring_note n
                   where n.refdoss = :refdos ) n1,
                v_domaine d1
          where n1.nature = d1.abrev
            and d1.type = 'DV_NATURE_SCORE'
            and d1.abrev = 'INPF' )
 where dtcreation_dt = max_dtcreation_dt;


-- 9r3j63p6ss2jx

select /*+ leading(ccl cr idc ddc D P V) use_nl(cr idc ddc D P V) */
       count(*)
  from t_intervenants cr,
       t_intervenants idc,
       g_dossier      ddc,
       g_dossier      ccl,
       g_dossier D,
       g_piece P,
       v_domaine V
 where D.refdoss = ddc.refdoss
   and ccl.refdoss = :refdos
   and nvl(ccl.categdoss, 'x') = 'COMPTE CLIENT'
   and cr.refdoss = ccl.refdoss
   and cr.reftype = 'DB'
   and idc.refindividu = cr.refindividu
   and ddc.refdoss = idc.refdoss
   and idc.reftype = 'DB'
   and nvl(ddc.categdoss, 'x') = 'CREDIT AMORTISSABLE'
   and nvl(ddc.fg_realization_of_cash_outflow, 'x') <> 'O'
   and P.typpiece = D.pieceinit
   and V.valeur = P.typpiece
   and P.refdoss = D.refdoss
   and V.type = 'piece'
   and V.abrev = P.libelle_20_14
   and V.commentaire = 'INVEST'
   and rownum = 1;
/********************************New SQL*******************************************/
/********************************New Metrics***************************************/
/*
-- dcswxspru70gc

Plan hash value: 3685546492
--------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                            | Name                   | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers |
--------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                     |                        |      1 |        |  1862 (100)|      1 |00:00:00.01 |      50 |
|   1 |  SORT AGGREGATE                      |                        |      1 |      1 |            |      1 |00:00:00.01 |      50 |
|*  2 |   COUNT STOPKEY                      |                        |      1 |        |            |      0 |00:00:00.01 |      50 |
|   3 |    NESTED LOOPS                      |                        |      1 |      1 |  1862   (1)|      0 |00:00:00.01 |      50 |
|   4 |     VIEW                             | VW_NSO_1               |      1 |  22535 |  1183   (0)|      4 |00:00:00.01 |      34 |
|   5 |      HASH UNIQUE                     |                        |      1 |  22535 |            |      4 |00:00:00.01 |      34 |
|   6 |       NESTED LOOPS                   |                        |      1 |  22535 |  1183   (0)|      4 |00:00:00.01 |      34 |
|   7 |        NESTED LOOPS                  |                        |      1 |  58994 |  1183   (0)|      7 |00:00:00.01 |      27 |
|   8 |         NESTED LOOPS                 |                        |      1 |  58994 |     3   (0)|      7 |00:00:00.01 |      11 |
|   9 |          NESTED LOOPS                |                        |      1 |      1 |     2   (0)|      1 |00:00:00.01 |       7 |
|* 10 |           INDEX RANGE SCAN           | INT_REFDOSS            |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |
|* 11 |           TABLE ACCESS BY INDEX ROWID| G_DOSSIER              |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       4 |
|* 12 |            INDEX UNIQUE SCAN         | DOS_REFDOSS            |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |
|* 13 |          INDEX RANGE SCAN            | INT_INDIV              |      1 |  58710 |     1   (0)|      7 |00:00:00.01 |       4 |
|* 14 |         INDEX UNIQUE SCAN            | DOS_REFDOSS            |      7 |      1 |     1   (0)|      7 |00:00:00.01 |      16 |
|* 15 |        TABLE ACCESS BY INDEX ROWID   | G_DOSSIER              |      7 |      1 |     1   (0)|      4 |00:00:00.01 |       7 |
|* 16 |     INDEX RANGE SCAN                 | ELE_DOSS_TYP_ASSOC_LIB |      4 |      1 |     1   (0)|      0 |00:00:00.01 |      16 |
--------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   2 - filter(ROWNUM=1)
  10 - access("CR"."REFDOSS"=:REFDOS AND "CR"."REFTYPE"='DB')
  11 - filter("GD"."CATEGDOSS"='COMPTE CLIENT')
  12 - access("GD"."REFDOSS"=:REFDOS)
  13 - access("IDC"."REFINDIVIDU"="CR"."REFINDIVIDU" AND "IDC"."REFTYPE"='DB')
       filter("IDC"."REFDOSS"<>:REFDOS)
  14 - access("DDC"."REFDOSS"="IDC"."REFDOSS")
       filter(("DDC"."REFDOSS"<>"GD"."REFDOSS" AND "DDC"."REFDOSS"<>:REFDOS))
  15 - filter("DDC"."CATEGDOSS"='COMPTE COURANT')
  16 - access("REFDOSS"="REFDOSS")
       filter((NVL("LIBELLE",'x')='debut GEL' AND NVL("TYPEELEM",'x')='in'))


-- 18tgpdw1qdrn8

Plan hash value: 1084237876
--------------------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                 | Name                       | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  |
--------------------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                          |                            |      1 |        |     4 (100)|      0 |00:00:00.01 |       8 |      1 |
|*  1 |  VIEW                                     |                            |      1 |      2 |     4   (0)|      0 |00:00:00.01 |       8 |      1 |
|   2 |   WINDOW BUFFER                           |                            |      1 |      2 |     4   (0)|      0 |00:00:00.01 |       8 |      1 |
|   3 |    MERGE JOIN CARTESIAN                   |                            |      1 |      2 |     4   (0)|      0 |00:00:00.01 |       8 |      1 |
|   4 |     VIEW                                  |                            |      1 |      2 |     3   (0)|      0 |00:00:00.01 |       8 |      1 |
|   5 |      SORT UNIQUE                          |                            |      1 |      2 |     3   (0)|      0 |00:00:00.01 |       8 |      1 |
|   6 |       UNION-ALL                           |                            |      1 |        |            |      0 |00:00:00.01 |       8 |      1 |
|   7 |        NESTED LOOPS                       |                            |      1 |      1 |     2   (0)|      0 |00:00:00.01 |       7 |      1 |
|   8 |         NESTED LOOPS                      |                            |      1 |      3 |     2   (0)|      1 |00:00:00.01 |       6 |      1 |
|*  9 |          INDEX RANGE SCAN                 | INT_REFDOSS                |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |      0 |
|* 10 |          INDEX RANGE SCAN                 | EXSCORNOTE_REFINDIVIDU_IDX |      1 |      3 |     1   (0)|      1 |00:00:00.01 |       3 |      1 |
|* 11 |         TABLE ACCESS BY INDEX ROWID       | EXT_SCORING_NOTE           |      1 |      1 |     1   (0)|      0 |00:00:00.01 |       1 |      0 |
|* 12 |        TABLE ACCESS BY INDEX ROWID BATCHED| EXT_SCORING_NOTE           |      1 |      1 |     1   (0)|      0 |00:00:00.01 |       1 |      0 |
|* 13 |         INDEX RANGE SCAN                  | EXSCORNOTE_REFDOSS         |      1 |      1 |     1   (0)|      0 |00:00:00.01 |       1 |      0 |
|  14 |     BUFFER SORT                           |                            |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 15 |      INDEX RANGE SCAN                     | DOM_TYPABREV               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
--------------------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   1 - filter("DTCREATION_DT"="MAX_DTCREATION_DT")
   9 - access("REFDOSS"=:REFDOS AND "REFTYPE"='DB')
  10 - access("N"."REFINDIVIDU"="REFINDIVIDU")
  11 - filter("N"."NATURE"='INPF')
  12 - filter("N"."NATURE"='INPF')
  13 - access("N"."REFDOSS"=:REFDOS)
  15 - access("D1"."TYPE"='DV_NATURE_SCORE' AND "D1"."ABREV"='INPF')


-- 9r3j63p6ss2jx

Plan hash value: 499769477
-------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                | Name              | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers |
-------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                         |                   |      1 |        |  2149 (100)|      1 |00:00:00.01 |      62 |
|   1 |  SORT AGGREGATE                          |                   |      1 |      1 |            |      1 |00:00:00.01 |      62 |
|*  2 |   COUNT STOPKEY                          |                   |      1 |        |            |      0 |00:00:00.01 |      62 |
|   3 |    NESTED LOOPS                          |                   |      1 |      1 |  2149   (1)|      0 |00:00:00.01 |      62 |
|   4 |     NESTED LOOPS                         |                   |      1 |   9756 |  2149   (1)|      0 |00:00:00.01 |      62 |
|   5 |      NESTED LOOPS                        |                   |      1 |   9756 |  1954   (1)|      0 |00:00:00.01 |      62 |
|   6 |       NESTED LOOPS                       |                   |      1 |  15394 |  1492   (1)|      0 |00:00:00.01 |      62 |
|   7 |        NESTED LOOPS                      |                   |      1 |  15394 |  1184   (1)|      0 |00:00:00.01 |      62 |
|   8 |         NESTED LOOPS                     |                   |      1 |  58994 |     3   (0)|      8 |00:00:00.01 |      14 |
|   9 |          NESTED LOOPS                    |                   |      1 |      1 |     2   (0)|      1 |00:00:00.01 |      10 |
|* 10 |           INDEX SKIP SCAN                | REFHIERARCHIE_IDX |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       7 |
|* 11 |           INDEX RANGE SCAN               | INT_REFDOSS       |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |
|* 12 |          INDEX RANGE SCAN                | INT_INDIV         |      1 |  58710 |     1   (0)|      8 |00:00:00.01 |       4 |
|* 13 |         TABLE ACCESS BY INDEX ROWID      | G_DOSSIER         |      8 |      1 |     1   (0)|      0 |00:00:00.01 |      48 |
|* 14 |          INDEX UNIQUE SCAN               | DOS_REFDOSS       |      8 |      1 |     1   (0)|      8 |00:00:00.01 |      18 |
|  15 |        TABLE ACCESS BY INDEX ROWID       | G_DOSSIER         |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 16 |         INDEX UNIQUE SCAN                | DOS_REFDOSS       |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 17 |       TABLE ACCESS BY INDEX ROWID BATCHED| G_PIECE           |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 18 |        INDEX RANGE SCAN                  | PIE_REFDOSS       |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 19 |      INDEX RANGE SCAN                    | DOM_TYPABREV      |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 20 |     TABLE ACCESS BY INDEX ROWID          | V_DOMAINE         |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
-------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   2 - filter(ROWNUM=1)
  10 - access("CCL"."CATEGDOSS"='COMPTE CLIENT' AND "CCL"."REFDOSS"=:REFDOS)
       filter(("CCL"."REFDOSS"=:REFDOS AND "CCL"."CATEGDOSS"='COMPTE CLIENT'))
  11 - access("CR"."REFDOSS"=:REFDOS AND "CR"."REFTYPE"='DB')
  12 - access("IDC"."REFINDIVIDU"="CR"."REFINDIVIDU" AND "IDC"."REFTYPE"='DB')
  13 - filter(("DDC"."CATEGDOSS"='CREDIT AMORTISSABLE' AND NVL("DDC"."FG_REALIZATION_OF_CASH_OUTFLOW",'x')<>'O'))
  14 - access("DDC"."REFDOSS"="IDC"."REFDOSS")
  16 - access("D"."REFDOSS"="DDC"."REFDOSS")
  17 - filter("P"."LIBELLE_20_14" IS NOT NULL)
  18 - access("P"."REFDOSS"="D"."REFDOSS" AND "P"."TYPPIECE"="D"."PIECEINIT")
  19 - access("V"."TYPE"='piece' AND "V"."ABREV"="P"."LIBELLE_20_14" AND "V"."VALEUR"="P"."TYPPIECE")
  20 - filter("V"."COMMENTAIRE"='INVEST')

*/
/********************************New Metrics***************************************/

/********************************Index statistics**********************************/

/********************************Other SQLs****************************************/          
/*

*/ 
/********************************Other SQLs****************************************/              
