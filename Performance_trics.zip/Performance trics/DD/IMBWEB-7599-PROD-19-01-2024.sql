/********************************************************************************
*********       E-mail subject: IMBWEB-7599
*********             Instance: PROD
*********          Description: 
Problem:
Blocking calls on IMB PROD.

Analysis:
The problem in the provided query was selecting near 1 million rows from table G_VENFILIMIT and than accessing table 
G_VENRESTRICTION for each of the selected rows from table G_VENFILIMIT. The solution here is using hints to determine 
the way that the query should be executed. 

Suggestion:
Please add hints as it is shown in the New SQL section below.

*********               SQL_ID: 
*********      Program/Package: 
*********              Request: Dimitare Ivanov
*********               Author: Dimitar Dimitrov
********* Received e-mail date: 18/01/2024
*********      Resolution date: 19/01/2024
*********  Trace old file here: \\epox\specifs\performance\tmp\
*********  Trace new file here:
***********************************************************************************/

/********************************OLD SQL*******************************************/
var B5 VARCHAR2(32);
exec :B5 := 'A70I6NOK';
var B4 NUMBER;
exec :B4 := 2357708;
var B3 NUMBER;
exec :B3 := 1;
var B2 NUMBER;
exec :B2 := 1;
var B1 NUMBER;
exec :B1 := 2;

SELECT NVL( MIN( RN.REAL_AMOUNT_DEC + RO.REAL_AMOUNT_DEC ), 0 ) 
  FROM G_VENFILIMIT V , 
       G_VENRESTRICTION RN , 
       G_VENRESTRICTION RO 
 WHERE V.LIMIT_ID = :B5 
   AND V.LIMIT_DETAIL_ID = TO_CHAR( :B4 ) 
   AND RN.REFELEM = V.FI_ID 
   AND RN.RESTRICTION_CODE = 'NOP'
   AND RO.IMX_UN_ID != RN.IMX_UN_ID 
   AND RO.REFELEM = V.FI_ID 
   AND RO.RESTRICTION_CODE = CASE :B3 WHEN :B2 
                                      THEN 'FC' 
                                      WHEN :B1 THEN 'RBF' 
                              END;
/********************************OLD SQL*******************************************/
/********************************OLD Metrics***************************************/

SQL_ID        SQL_PLAN_HASH_VALUE SQL_PLAN_LINE_ID SQL_PLAN_OPERATION             SQL_PLAN_OPTIONS                   ACTIVE
------------- ------------------- ---------------- ------------------------------ ------------------------------ ----------
52f88v4p6gtpk          2141729987                7 INDEX                          RANGE SCAN                          41364
52f88v4p6gtpk          2141729987                5 INDEX                          RANGE SCAN                           6283
52f88v4p6gtpk          2141729987                6 TABLE ACCESS                   BY INDEX ROWID BATCHED               2090
52f88v4p6gtpk          2141729987                4 NESTED LOOPS                                                         142
52f88v4p6gtpk          2141729987                  SELECT STATEMENT                                                       7
52f88v4p6gtpk          2141729987                1 SORT                           AGGREGATE                               3

/*
Plan hash value: 2141729987
---------------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                               | Name                    | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  |
---------------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                        |                         |      1 |        |    16 (100)|      1 |00:00:04.85 |    3146K|   6367 |
|   1 |  SORT AGGREGATE                         |                         |      1 |      1 |            |      1 |00:00:04.85 |    3146K|   6367 |
|   2 |   NESTED LOOPS                          |                         |      1 |    247 |    16   (0)|      0 |00:00:04.85 |    3146K|   6367 |
|   3 |    NESTED LOOPS                         |                         |      1 |    247 |    16   (0)|      0 |00:00:04.85 |    3146K|   6367 |
|   4 |     NESTED LOOPS                        |                         |      1 |    247 |     8   (0)|      0 |00:00:04.85 |    3146K|   6367 |
|*  5 |      INDEX RANGE SCAN                   | GVFL_LIMDETROLE_IDX     |      1 |    247 |     1   (0)|    965K|00:00:02.57 |    6369 |   6367 |
|   6 |      TABLE ACCESS BY INDEX ROWID BATCHED| G_VENRESTRICTION        |    965K|      1 |     1   (0)|      0 |00:00:02.13 |    3140K|      0 |
|*  7 |       INDEX RANGE SCAN                  | G_VENREST_RESTC_REF_IDX |    965K|      1 |     1   (0)|      0 |00:00:01.90 |    3140K|      0 |
|*  8 |     INDEX RANGE SCAN                    | G_VENREST_RESTC_REF_IDX |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*  9 |    TABLE ACCESS BY INDEX ROWID          | G_VENRESTRICTION        |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
---------------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   5 - access("V"."LIMIT_ID"=:B5 AND "V"."LIMIT_DETAIL_ID"=TO_CHAR(:B4))
   7 - access("RN"."RESTRICTION_CODE"='NOP' AND "RN"."REFELEM"="V"."FI_ID")
   8 - access("RO"."RESTRICTION_CODE"=CASE :B3 WHEN :B2 THEN 'FC' WHEN :B1 THEN 'RBF' END  AND "RO"."REFELEM"="V"."FI_ID")
   9 - filter("RO"."IMX_UN_ID"<>"RN"."IMX_UN_ID")
*/
/********************************OLD Metrics***************************************/

/********************************New SQL*******************************************/
SELECT /*+ leading(RN V) use_nl(V) index(RN G_VENREST_RESTC_REF_IDX) index(V G_VENFILIMIT_PK) */
       NVL( MIN( RN.REAL_AMOUNT_DEC + RO.REAL_AMOUNT_DEC ), 0 ) 
  FROM G_VENFILIMIT V , 
       G_VENRESTRICTION RN , 
       G_VENRESTRICTION RO 
 WHERE V.LIMIT_ID = :B5 
   AND V.LIMIT_DETAIL_ID = TO_CHAR( :B4 ) 
   AND RN.REFELEM = V.FI_ID 
   AND RN.RESTRICTION_CODE = 'NOP'
   AND RO.IMX_UN_ID != RN.IMX_UN_ID 
   AND RO.REFELEM = V.FI_ID 
   AND RO.RESTRICTION_CODE = CASE :B3 WHEN :B2 
                                      THEN 'FC' 
                                      WHEN :B1 THEN 'RBF' 
                              END;
/********************************New SQL*******************************************/
/********************************New Metrics***************************************/
/*
Plan hash value: 3663568163
------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                               | Name                    | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers |
------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                        |                         |      1 |        |    73 (100)|      1 |00:00:00.01 |       4 |
|   1 |  SORT AGGREGATE                         |                         |      1 |      1 |            |      1 |00:00:00.01 |       4 |
|   2 |   NESTED LOOPS                          |                         |      1 |    247 |    73   (0)|      0 |00:00:00.01 |       4 |
|   3 |    NESTED LOOPS                         |                         |      1 |    247 |    73   (0)|      0 |00:00:00.01 |       4 |
|   4 |     NESTED LOOPS                        |                         |      1 |    247 |    65   (0)|      0 |00:00:00.01 |       4 |
|   5 |      TABLE ACCESS BY INDEX ROWID BATCHED| G_VENRESTRICTION        |      1 |   2567 |    14   (0)|      0 |00:00:00.01 |       4 |
|*  6 |       INDEX RANGE SCAN                  | G_VENREST_RESTC_REF_IDX |      1 |   2567 |     1   (0)|      0 |00:00:00.01 |       4 |
|*  7 |      INDEX UNIQUE SCAN                  | G_VENFILIMIT_PK         |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|*  8 |     INDEX RANGE SCAN                    | G_VENREST_RESTC_REF_IDX |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|*  9 |    TABLE ACCESS BY INDEX ROWID          | G_VENRESTRICTION        |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   6 - access("RN"."RESTRICTION_CODE"='NOP')
   7 - access("RN"."REFELEM"="V"."FI_ID" AND "V"."LIMIT_ID"=:B5 AND "V"."LIMIT_DETAIL_ID"=TO_CHAR(:B4))
   8 - access("RO"."RESTRICTION_CODE"=CASE :B3 WHEN :B2 THEN 'FC' WHEN :B1 THEN 'RBF' END  AND "RO"."REFELEM"="V"."FI_ID")
   9 - filter("RO"."IMX_UN_ID"<>"RN"."IMX_UN_ID")
*/
/********************************New Metrics***************************************/

/********************************Index statistics**********************************/

/********************************Other SQLs****************************************/          
/*

*/ 
/********************************Other SQLs****************************************/              
