/********************************************************************************
*********       E-mail subject: ACSTDWEB-1820
*********             Instance: SCOR-G
*********          Description: 
Problem:
The std_dc_migr_exp_case.export_ISSNV took over 10h on SCOR-G.

Analysis:
After the analyze, we found that the TOP SQL, which is responsible for 100% of the time is 5hyjtcx5mxhjg.
The problem in this query is the join between table MIGR_DC_FCEM_STMT MIG and table G_TEXTE G. The tables are joined using IN operator, which leads to thousands FULL SCANs 
of table MIGR_DC_FCEM_STMT. The solution here is to use UNION instead of the IN operator.

Suggestion:
Please change the query as it is shown in the New SQL section below.

*********               SQL_ID: 5hyjtcx5mxhjg
*********      Program/Package: 
*********              Request: Iva Zareva 
*********               Author: Dimitar Dimitrov
********* Received e-mail date: 04/09/2024
*********      Resolution date: 04/09/2024
*********  Trace old file here: \\epox\specifs\performance\tmp\
*********  Trace new file here:
***********************************************************************************/

/********************************OLD SQL*******************************************/

VAR B1 NUMBER;
EXEC :B1 := 1;
VAR B2 NUMBER;
EXEC :B2 := 2;

INSERT INTO MIGR_DC_ISSNV ( REFTEXTE,
                            DTCREAT,
                            DTCREAT_DT,
                             MANAGER,
                            TITLE,
                            REF_IND,
                            DTEDIT,
                            TYPE_PAPER,
                            TYPENVOI,
                            NB_COPIES,
                            ON_PRINTER,
                            ETAT,
                            PAGE_NB,
                            REFDOSS,
                            LANGUAGE,
                            CP,
                            DTEDIT_DT,
                            PARAGRAPHE,
                            COMMENTAIRE,
                            DTMODIFY,
                            REFMASTER,
                            EXPORT_FILENAME,
                            BARCODE,
                            BARCODE2,
                            CODE_ENVOI,
                            DTSTATUS_VAL,
                            FLAGS,
                            EXPORT_DIR )
SELECT G.REFTEXTE,
       G.DTCREAT,
       G.DTCREAT_DT,
       G.ECRAN,
       G.TITRE,
       G.REFDESTIN,
       G.DTEDIT,
       G.PAPIER,
       G.TYPENVOI,
       G.NBCOPIES,
       G.IMPRIMANTE,
       G.ETAT,
       G.NUMPAGE,
       G.REFDS,
       G.LANGUE,
       G.CP,
       G.DTEDIT_DT,
       G.PARAGRAPHE,
       G.COMMENTAIRE,
       G.DTMODIFY,
       G.REFMASTER,
       G.EXPORT_FILENAME,
       G.BARCODE,
       G.BARCODE2,
       G.CODE_ENVOI,
       G.DTSTATUS_VAL,
       G.FLAGS,
       G.EXPORT_DIR
  FROM G_TEXTE G,
       ( SELECT REFDOSS
           FROM MIGR_DC_DBCC
         UNION
         SELECT REFDOSS
           FROM MIGR_DC_CA ) MIGR_CASE
 WHERE EXISTS ( SELECT 1
                  FROM MIGR_DC_FCEM_STMT MIGR
                 WHERE G.REFTEXTE IN ( MIGR.ER_REFTXT, MIGR.ER_REFTXT_CPY ) )
   AND G.REFDS = MIGR_CASE.REFDOSS
   AND G.DTCREAT IS NOT NULL
   AND G.DTCREAT_DT IS NOT NULL
   AND G.REFDESTIN IS NOT NULL
   AND G.DTEDIT IS NOT NULL
   AND ORA_HASH(G.REFTEXTE, :B2 - 1) = :B1;
/********************************OLD SQL*******************************************/
/********************************OLD Metrics***************************************/
/*
MODULE                           PROGRAM                                            CLIENT_ID       SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- -------------------------------------------------- --------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
std_dc_migr_exp_case.export_ISSN std_migration_robot                                                5hyjtcx5mxhjg 1013134998        122      44206 ON CPU               2024/09/03 20:43:23  2024/09/04 07:30:14       38701                    1 +000000000 10:46:51.032 52%
V

std_dc_migr_exp_acc.export_TPI   std_migration_robot                                                                                242      37987 ON CPU               2024/09/03 20:53:03  2024/09/04 03:34:03       24019                    1 +000000000 06:40:59.873 32%
oracle                           oracle                                                                                                            direct path read     2024/09/03 20:41:19  2024/09/04 07:16:37         758                   60 +000000000 10:35:17.684 1%
oracle                           oracle                                                                                                            ON CPU               2024/09/03 20:41:17  2024/09/04 07:17:14         743                 6247 +000000000 10:35:56.696 1%
SQL*Plus                         sqlplus                                                                                                           db file sequential r 2024/09/03 20:31:01  2024/09/04 07:25:37         720                13480 +000000000 10:54:36.215 1%
python3                          python3                                                                                                           ON CPU               2024/09/03 20:31:22  2024/09/04 07:26:26         704              1656612 +000000000 10:55:04.259 1%





MODULE                           PROGRAM                                            CLIENT_ID       SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- -------------------------------------------------- --------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
std_dc_migr_exp_case.export_ISSN std_migration_robot                                                5hyjtcx5mxhjg 1013134998        122      44206 ON CPU               2024/09/03 20:43:23  2024/09/04 07:31:18       38765                    1 +000000000 10:47:55.043 100%
V

std_dc_migr_exp_case.export_ISSN std_migration_robot                                                5hyjtcx5mxhjg 1013134998        122      44206 db file parallel rea 2024/09/03 21:17:29  2024/09/04 07:18:50          56                    1 +000000000 10:01:20.715 0%
V

std_dc_migr_exp_case.export_ISSN std_migration_robot                                                5hyjtcx5mxhjg 1013134998        122      44206 db file sequential r 2024/09/03 21:05:41  2024/09/04 07:29:43          41                    1 +000000000 10:24:02.163 0%
V


MODULE                           PROGRAM                                            CLIENT_ID       SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- -------------------------------------------------- --------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
std_dc_migr_exp_case.export_ISSN std_migration_robot                                                5hyjtcx5mxhjg 1013134998        122      44206                      2024/09/03 20:43:23  2024/09/04 07:31:43       38887                    1 +000000000 10:48:20.058 100%
V

INSTANCE_NUMBER SQL_ID            ELAPSED MAX_WAIT_ON     PC_OF  WAIT_TIME            GETS      READS       ROWS  ELAP/EXEC       GETS/EXEC READS/EXEC  ROWS/EXEC       EXEC PLAN_HASH_VALUE
--------------- ------------- ----------- --------------- ----- ---------- --------------- ---------- ---------- ---------- --------------- ---------- ---------- ---------- ---------------
              1 5hyjtcx5mxhjg       37016 CPU             100%  15756.1353      3628288726     572160          0   37016.26      3628288726     572160          0          0      1013134998


SQL_ID        SQL_PLAN_HASH_VALUE SQL_PLAN_LINE_ID SQL_PLAN_OPERATION             SQL_PLAN_OPTIONS                   ACTIVE
------------- ------------------- ---------------- ------------------------------ ------------------------------ ----------
5hyjtcx5mxhjg          1013134998               12 TABLE ACCESS                   FULL                                 3860
5hyjtcx5mxhjg          1013134998               11 TABLE ACCESS                   BY INDEX ROWID                         10
5hyjtcx5mxhjg          1013134998               10 INDEX                          RANGE SCAN                             10


    SID SERIAL# PID         SPID       MODULE               EVENT                                    STATUS            SQL_ID        PLAN_HASH_VALUE CLIENT_ID    CLIENT_INFO      LOGON_TIME MACHINE    ACTION
------- ------- ----------- ---------- -------------------- ---------------------------------------- ----------------- ------------- --------------- ------------ ---------------- ---------- ---------- -------------------------
    122   44206 48103544    49021710   std_dc_migr_exp_case on cpu                                   ACTIVE-41078 sec. 5hyjtcx5mxhjg      1013134998              48103544@std_mig 03/09/24
    236   50786 53872138    5963874    PT_SNAP_SESSION      idle-PL/SQL lock timer                   ACTIVE-78686 sec. 316y9b9y63kgm               0                               03/09/24              SNAP_SESSION
      8   61183 1234        31195918   EXTRANET             idle-SQL*Net message from client         INACTIVE-40064 se                               WEBPRINTER                    03/09/24   ltwas001ap Login
    118   35273 40304808    64421960   std_migration_robot  idle-SQL*Net message from client         INACTIVE-41079 se                                            40304808@std_mig 03/09/24

Plan hash value: 1013134998
------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                      | Name              | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  |
------------------------------------------------------------------------------------------------------------------------------------
|   0 | INSERT STATEMENT               |                   |      1 |        |     8 (100)|      0 |00:00:00.01 |       0 |      0 |
|   1 |  LOAD TABLE CONVENTIONAL       | MIGR_DC_ISSNV     |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*  2 |   FILTER                       |                   |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
|   3 |    NESTED LOOPS                |                   |      1 |      1 |     6  (17)|   5927 |00:00:06.36 |   11109 |   5166 |
|   4 |     NESTED LOOPS               |                   |      1 |     28 |     6  (17)|  14533 |00:00:00.68 |    3917 |    334 |
|   5 |      VIEW                      |                   |      1 |      2 |     5  (20)|    528 |00:00:00.21 |    2812 |      0 |
|   6 |       SORT UNIQUE              |                   |      1 |      2 |     5  (20)|    528 |00:00:00.21 |    2812 |      0 |
|   7 |        UNION-ALL               |                   |      1 |        |            |    162K|00:00:00.07 |    2812 |      0 |
|   8 |         TABLE ACCESS FULL      | MIGR_DC_DBCC      |      1 |      1 |     2   (0)|    149K|00:00:00.03 |    2713 |      0 |
|   9 |         TABLE ACCESS FULL      | MIGR_DC_CA        |      1 |      1 |     2   (0)|  13158 |00:00:00.01 |      99 |      0 |
|* 10 |      INDEX RANGE SCAN          | TXT_REFDS         |    528 |     14 |     1   (0)|  14533 |00:00:00.45 |    1105 |    334 |
|* 11 |     TABLE ACCESS BY INDEX ROWID| G_TEXTE           |  14533 |      1 |     1   (0)|   5927 |00:00:05.63 |    7192 |   4832 |
|* 12 |    TABLE ACCESS FULL           | MIGR_DC_FCEM_STMT |   5927 |      1 |     2   (0)|      0 |00:05:08.96 |      26M|      0 |
------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   2 - filter( IS NOT NULL)
  10 - access("G"."REFDS"="MIGR_CASE"."REFDOSS")
  11 - filter(("G"."REFDESTIN" IS NOT NULL AND ORA_HASH("G"."REFTEXTE",:B2-1)=:B1 AND "G"."DTCREAT" IS NOT NULL AND
              "G"."DTCREAT_DT" IS NOT NULL AND "G"."DTEDIT" IS NOT NULL))
  12 - filter(("MIGR"."ER_REFTXT"=:B1 OR "MIGR"."ER_REFTXT_CPY"=:B2))

*/
/********************************OLD Metrics***************************************/

/********************************New SQL*******************************************/

INSERT INTO MIGR_DC_ISSNV ( REFTEXTE,
                            DTCREAT,
                            DTCREAT_DT,
                            MANAGER,
                            TITLE,
                            REF_IND,
                            DTEDIT,
                            TYPE_PAPER,
                            TYPENVOI,
                            NB_COPIES,
                            ON_PRINTER,
                            ETAT,
                            PAGE_NB,
                            REFDOSS,
                            LANGUAGE,
                            CP,
                            DTEDIT_DT,
                            PARAGRAPHE,
                            COMMENTAIRE,
                            DTMODIFY,
                            REFMASTER,
                            EXPORT_FILENAME,
                            BARCODE,
                            BARCODE2,
                            CODE_ENVOI,
                            DTSTATUS_VAL,
                            FLAGS,
                            EXPORT_DIR )
SELECT G.REFTEXTE,
       G.DTCREAT,
       G.DTCREAT_DT,
       G.ECRAN,
       G.TITRE,
       G.REFDESTIN,
       G.DTEDIT,
       G.PAPIER,
       G.TYPENVOI,
       G.NBCOPIES,
       G.IMPRIMANTE,
       G.ETAT,
       G.NUMPAGE,
       G.REFDS,
       G.LANGUE,
       G.CP,
       G.DTEDIT_DT,
       G.PARAGRAPHE,
       G.COMMENTAIRE,
       G.DTMODIFY,
       G.REFMASTER,
       G.EXPORT_FILENAME,
       G.BARCODE,
       G.BARCODE2,
       G.CODE_ENVOI,
       G.DTSTATUS_VAL,
       G.FLAGS,
       G.EXPORT_DIR
  FROM G_TEXTE G,
       ( SELECT REFDOSS
           FROM MIGR_DC_DBCC
         UNION
         SELECT REFDOSS
           FROM MIGR_DC_CA ) MIGR_CASE
 WHERE EXISTS ( SELECT 1
                  FROM MIGR_DC_FCEM_STMT MIGR
                 WHERE G.REFTEXTE = MIGR.ER_REFTXT
                UNION 
                SELECT 1
                  FROM MIGR_DC_FCEM_STMT MIGR
                 WHERE G.REFTEXTE = MIGR.ER_REFTXT_CPY )
   AND G.REFDS = MIGR_CASE.REFDOSS
   AND G.DTCREAT IS NOT NULL
   AND G.DTCREAT_DT IS NOT NULL
   AND G.REFDESTIN IS NOT NULL
   AND G.DTEDIT IS NOT NULL
   AND ORA_HASH(G.REFTEXTE, :B2 - 1) = :B1;
/********************************New SQL*******************************************/
/********************************New Metrics***************************************/
/*
Plan hash value: 391261811
------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                      | Name              | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  |
------------------------------------------------------------------------------------------------------------------------------------
|   0 | INSERT STATEMENT               |                   |      1 |        |     9 (100)|      0 |00:00:20.55 |     204K|  38089 |
|   1 |  LOAD TABLE CONVENTIONAL       | MIGR_DC_ISSNV     |      1 |        |            |      0 |00:00:20.55 |     204K|  38089 |
|*  2 |   HASH JOIN                    |                   |      1 |      1 |     9   (0)|  37121 |00:00:19.88 |     157K|  38042 |
|   3 |    NESTED LOOPS                |                   |      1 |      1 |     5   (0)|  37121 |00:00:19.06 |     155K|  35239 |
|   4 |     NESTED LOOPS               |                   |      1 |      2 |     5   (0)|  37121 |00:00:11.20 |     118K|  24350 |
|   5 |      VIEW                      | VW_SQ_1           |      1 |      2 |     4   (0)|  74551 |00:00:00.50 |    9070 |      0 |
|   6 |       SORT UNIQUE              |                   |      1 |      2 |     4   (0)|  74551 |00:00:00.48 |    9070 |      0 |
|   7 |        UNION-ALL               |                   |      1 |        |            |    411K|00:00:00.20 |    9070 |      0 |
|   8 |         TABLE ACCESS FULL      | MIGR_DC_FCEM_STMT |      1 |      1 |     2   (0)|    205K|00:00:00.05 |    4535 |      0 |
|   9 |         TABLE ACCESS FULL      | MIGR_DC_FCEM_STMT |      1 |      1 |     2   (0)|    205K|00:00:00.05 |    4535 |      0 |
|* 10 |      INDEX UNIQUE SCAN         | TXT_REFTEXTE      |  74551 |      1 |     1   (0)|  37121 |00:00:10.66 |     108K|  24350 |
|* 11 |     TABLE ACCESS BY INDEX ROWID| G_TEXTE           |  37121 |      1 |     1   (0)|  37121 |00:00:07.82 |   37121 |  10889 |
|  12 |    VIEW                        |                   |      1 |      2 |     4   (0)|    162K|00:00:00.47 |    2810 |   2803 |
|  13 |     SORT UNIQUE                |                   |      1 |      2 |     4   (0)|    162K|00:00:00.46 |    2810 |   2803 |
|  14 |      UNION-ALL                 |                   |      1 |        |            |    162K|00:00:00.27 |    2810 |   2803 |
|  15 |       TABLE ACCESS FULL        | MIGR_DC_DBCC      |      1 |      1 |     2   (0)|    149K|00:00:00.22 |    2712 |   2707 |
|  16 |       TABLE ACCESS FULL        | MIGR_DC_CA        |      1 |      1 |     2   (0)|  13158 |00:00:00.01 |      98 |     96 |
------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   2 - access("G"."REFDS"="MIGR_CASE"."REFDOSS")
  10 - access("G"."REFTEXTE"="VW_COL_1")
       filter(ORA_HASH("G"."REFTEXTE",:B2-1)=:B1)
  11 - filter(("G"."REFDESTIN" IS NOT NULL AND "G"."DTCREAT" IS NOT NULL AND "G"."DTCREAT_DT" IS NOT NULL AND "G"."DTEDIT"
              IS NOT NULL))
*/
/********************************New Metrics***************************************/

/********************************Index statistics**********************************/

/********************************Other SQLs****************************************/          
/*

*/ 
/********************************Other SQLs****************************************/              
