=====================================================================================================================
########################## Issue with server. FAILED BACKUP ##############################

dxcbella@sl72112:~> nsu

sl72112:~ # ps -ef | grep pmon
oracle     988     1  0 May18 ?        00:07:24 asm_pmon_+ASM
root      9170  9126  0 08:27 pts/0    00:00:00 grep pmon
oracle   14946     1  0 Jul18 ?        00:10:29 ora_pmon_MENAQ



sl72112:~ # su - oracle

oracle@sl72112:/oracle/home/oracle/ [+ASM] MENAQ                ########### Задаваме само името на базата и зареждаме енвайрмънта ###########

 WARNING: 4003018 =>  oraenv.tvdp : BEoevSetSidEnv : 11g: Could not set TS_ALERTLOG, the Alert Log Directory exists more than once. Please set the TS_ALERTLOG Variable for the actual Instance manually in sid.conf (command: vis)
----------------------------------------
DB_UNIQUE_NAME: MENAQ
STATUS        : OPEN
DATABASE_ROLE : PRIMARY
OPEN_MODE     : READ WRITE
FORCE_LOGGING : YES
FLASHBACK     : NO
----------------------------------------

=============================================================================
############# Aко трябва да сетваме енварманта на SSMGRE1 (.profile_mdm)   OSDOTOOLS
  ########### ls -la .profile*       и sлед това       . ./.profile_mdm
 =============================================================================== 
  
oracle@sl72112:/oracle/home/oracle/ [MENAQ] adrci                  ############ adrci - влизаме и търсим алерт мога ########

ADRCI: Release 12.1.0.2.0 - Production on Mon Jul 22 08:34:33 2019

Copyright (c) 1982, 2014, Oracle and/or its affiliates.  All rights reserved.

ADR base = "/oracle"
adrci> show alert                              ###### Търсим лога ################

Choose the home from which to view the alert log:

1: diag/rdbms/menaq2/MENAQ2
2: diag/rdbms/menaq/MENAQ
3: diag/rdbms/menap/MENAQ
4: diag/rdbms/menap/MENAP
5: diag/asm/+asm/+ASM
6: diag/crs/sl72112/crs
7: diag/tnslsnr/sl72112/listener_menaq_1522
8: diag/tnslsnr/sl72112/listener
9: diag/clients/user_root/host_268935873_82
10: diag/clients/user_oracle/host_268935873_82
Q: to quit

Please select option: 2            ####### Избираме на коя база искаме да четем (номер ) ############

Output the results to file: /tmp/alert_31693_1400_MENAQ_1.ado

Please select option: q      ####### q - По този начин излизаме от менюто #######
adrci> exit
oracle@sl72112:/oracle/home/oracle/ [MENAQ]
oracle@sl72112:/oracle/home/oracle/ [MENAQ]
oracle@sl72112:/oracle/home/oracle/ [MENAQ]
oracle@sl72112:/oracle/home/oracle/ [MENAQ] sq

SQL*Plus: Release 12.1.0.2.0 Production on Mon Jul 22 08:38:28 2019

Copyright (c) 1982, 2014, Oracle.  All rights reserved.


Connected to:
Oracle Database 12c Enterprise Edition Release 12.1.0.2.0 - 64bit Production
With the Partitioning, Automatic Storage Management, OLAP, Advanced Analytics
and Real Application Testing options

SQL> Disconnected from Oracle Database 12c Enterprise Edition Release 12.1.0.2.0 - 64bit Production
With the Partitioning, Automatic Storage Management, OLAP, Advanced Analytics
and Real Application Testing options

SQL>
SQL>
SQL>
SQL> set lines 400                                   ######## Check processes and sessions ###############
col TARGET for a15
SQL> SQL> col TARGET_DESC for a10
col UNITS for a10
col TIME_REMAINING for a20
SQL> SQL> SQL> col OPNAME for a35
col LAST_UPDATE_TIME for a20
SQL> SQL> col START_TIME for a20
SELECT inst_id,SID, SERIAL#,OPNAME, SQL_ID, to_char(START_TIME, 'YYYY/MON/DD HH24:MI:SS') "START_TIME",
to_char(LAST_UPDATE_TIME, 'YYYY/MON/DD HH24:MI:SS') "LAST_UPDATE_TIME",
SQL>   2    3  TIME_REMAINING/60 as "remaining mins",
TARGET, TARGET_DESC, SOFAR,
TOTALWORK, UNITS, ROUND(SOFAR/TOTALWORK*100,2) "%_COMPLETE"
FROM GV$SESSION_LONGOPS
WHERE
TOTALWORK != 0
AND SOFAR <> TOTALWORK
order by START_TIME;  4    5    6    7    8    9   10

no rows selected

SQL> select * from v$resource_limit
  2  ;

RESOURCE_NAME                  CURRENT_UTILIZATION MAX_UTILIZATION INITIAL_ALLOCATION                       LIMIT_VALUE                                  CON_ID
------------------------------ ------------------- --------------- ---------------------------------------- ---------------------------------------- ----------
processes                                      753             818       1500                                     1500                                        0
sessions                                       641             721       2272                                     2272                                        0


SQL> set lines 400 pages 100                            ##################### Running and completed backups #############################
col device for a8
col time_taken for a8
SQL> SQL> SQL> col START__TIME for a19
SQL> col END_TIME for a19
column TIME_TAKEN_DISPLAY format a40;
col status for a28
SQL> SQL> SQL> select command_id,TO_CHAR(start_time, 'MM/DD/YY HH24:MI:SS') as start__time,
TO_CHAR(end_time, 'MM/DD/YY HH24:MI:SS') as end_time, output_device_type as device,input_type,time_taken_display as time_taken, status
from V_$RMAN_BACKUP_JOB_DETAILS order by start_time;  2    3

COMMAND_ID                        START__TIME         END_TIME            DEVICE   INPUT_TYPE    TIME_TAK STATUS
--------------------------------- ------------------- ------------------- -------- ------------- -------- ----------------------------

Online_Arch_Backup                07/13/19 09:25:24                                ARCHIVELOG             FAILED
Online_Arch_Backup                07/14/19 22:00:49                                ARCHIVELOG             FAILED
Online_Arch_Backup                07/15/19 08:10:39   07/15/19 08:29:12   SBT_TAPE ARCHIVELOG    00:18:33 COMPLETED
Online_Incr0_Backup               07/16/19 08:03:20                                DB INCR                FAILED
Online_Arch_Backup                07/16/19 10:00:35   07/16/19 10:11:55   SBT_TAPE ARCHIVELOG    00:11:20 FAILED
Online_Incr0_Backup               07/16/19 13:32:34   07/16/19 22:19:28   SBT_TAPE DB INCR       08:46:54 COMPLETED
Online_Arch_Backup                07/16/19 14:00:26   07/16/19 14:06:34   SBT_TAPE ARCHIVELOG    00:06:08 COMPLETED WITH WARNINGS
Online_Arch_Backup                07/16/19 18:00:44   07/16/19 18:03:58   SBT_TAPE ARCHIVELOG    00:03:14 COMPLETED
Online_Arch_Backup                07/16/19 22:00:45   07/16/19 22:04:46   SBT_TAPE ARCHIVELOG    00:04:01 COMPLETED
Online_Arch_Backup                07/17/19 02:00:51   07/17/19 02:04:13   SBT_TAPE ARCHIVELOG    00:03:22 COMPLETED
Online_Incr1_Backup               07/17/19 03:00:39   07/17/19 06:10:59   SBT_TAPE DB INCR       03:10:20 COMPLETED
Online_Incr0_Backup               07/20/19 03:00:42   07/20/19 11:57:33   SBT_TAPE DB INCR       08:56:51 COMPLETED
Online_Arch_Backup                07/20/19 06:00:48   07/20/19 06:04:33   SBT_TAPE ARCHIVELOG    00:03:45 COMPLETED
Online_Arch_Backup                07/20/19 10:00:47   07/20/19 10:04:24   SBT_TAPE ARCHIVELOG    00:03:37 COMPLETED
Online_Arch_Backup                07/20/19 14:00:30   07/20/19 14:03:51   SBT_TAPE ARCHIVELOG    00:03:21 COMPLETED
Online_Arch_Backup                07/20/19 18:00:37   07/20/19 18:02:57   SBT_TAPE ARCHIVELOG    00:02:20 COMPLETED
Online_Arch_Backup                07/20/19 22:00:51   07/20/19 22:04:12   SBT_TAPE ARCHIVELOG    00:03:21 COMPLETED
Online_Arch_Backup                07/21/19 02:01:15   07/21/19 02:05:52   SBT_TAPE ARCHIVELOG    00:04:37 COMPLETED
Online_Incr1_Backup               07/21/19 03:00:33   07/21/19 06:06:41   SBT_TAPE DB INCR       03:06:08 COMPLETED
Online_Arch_Backup                07/21/19 06:01:00   07/21/19 06:04:21   SBT_TAPE ARCHIVELOG    00:03:21 COMPLETED
Online_Arch_Backup                07/21/19 10:00:42   07/21/19 10:04:12   SBT_TAPE ARCHIVELOG    00:03:30 COMPLETED

360 rows selected.


oracle@sl72112:/oracle/local/dba/ [MENAQ] locate omnib                            ################# Check omnib where is locate #########################
If 'locate' is not a typo you can run the following command to lookup the package that contains the binary:
    command-not-found locate
-bash: locate: command not found


oracle@sl72112:/oracle/local/dba/ [MENAQ] which omnib                          ########## check omnib does exist and where is locate #########################
which: no omnib in (/oracle/local/tvdperl-5.8.0_64/bin:/oracle/12.1.0.2/bin:/oracle/12.1.0.2/ctx/bin:/usr/bin:/usr/local/bin:/sbin:/usr/sbin:/oracle/local/dba/bin:/oracle/local/tvdusr/bin:/bin:/usr/X11R6/bin:/usr/games:/usr/lib/mit/bin:/usr/lib/mit/sbin)
72112_ora_test_MENAQ_daily_arch_del &NAQ] nohup /opt/omni/bin/omnib  -Oracle8 sl
[1] 30708


oracle@sl72112:/oracle/local/dba/ [MENAQ] nohup: ignoring input and appending output to `nohup.out'    ######## start archive backup from cell-server with nohub  #################


oracle@sl72112:/oracle/local/dba/ [MENAQ] tail -100f nohup.out                         ###### Да гледам аутпута от бекъпа ######





oracle@sl72112:/oracle/local/dba/ [MENAQ] omnistat -det       ####### Така се проверява дали някой процес е running,но в случая не работи,трябва да покажем целия път ##########
If 'omnistat' is not a typo you can run the following command to lookup the package that contains the binary:
    command-not-found omnistat
-bash: omnistat: command not found

oracle@sl72112:/oracle/local/dba/ [MENAQ] /opt/omni/bin/omnistat -det             ####### Описваме целия път за да извадим инфо #############

SessionID : 2019/07/22-543
        Session type        : Copy
        Session status      : In Progress
        User.Group@Host     : root.root@dexxdpc001.eu-gt.net
        Session started     : Mon 22 Jul 2019 07:27:04 CEST
        Backup Specification: Weekly_FS_LIN_Copy_17_to_Tape

SessionID : 2019/07/22-590
        Session type        : Backup
        Session status      : In Progress
        User.Group@Host     : oracle.oinstall@sl72112.eu-gt.net
        Session started     : Mon 22 Jul 2019 08:45:31 CEST
        Backup Specification: Oracle8 sl72112_ora_test_MENAQ_weekly_full

SessionID : 2019/07/22-593
        Session type        : Backup
        Session status      : In Progress
        User.Group@Host     : oracle.oinstall@sl72162.eu-gt.net
        Session started     : Mon 22 Jul 2019 08:52:03 CEST
        Backup Specification: Oracle8 sl72162_ora_test_OGENAVIT_daily_arch_del

oracle@sl72112:/oracle/local/dba/ [MENAQ] sq

SQL*Plus: Release 12.1.0.2.0 Production on Mon Jul 22 08:54:54 2019

Copyright (c) 1982, 2014, Oracle.  All rights reserved.


Connected to:
Oracle Database 12c Enterprise Edition Release 12.1.0.2.0 - 64bit Production
With the Partitioning, Automatic Storage Management, OLAP, Advanced Analytics
and Real Application Testing options

SQL>
SQL>
SQL>
SQL>
SQL>
SQL> set lines 400                                           ################ Check long ops ##############
col TARGET for a15
col TARGET_DESC for a10
col UNITS for a10
col TIME_REMAINING for a20
col OPNAME for a35
SQL> SQL> SQL> SQL> SQL> SQL> col LAST_UPDATE_TIME for a20
col START_TIME for a20
SELECT inst_id,SID, SERIAL#,OPNAME, SQL_ID, to_char(START_TIME, 'YYYY/MON/DD HH24:MI:SS') "START_TIME",
to_char(LAST_UPDATE_TIME, 'YYYY/MON/DD HH24:MI:SS') "LAST_UPDATE_TIME",
TIME_REMSQL> AINING/60 as "remaining mins",
TARGET, TARGET_DESC, SOFAR,
TOTALWORK, UNITS, ROUND(SOFAR/TOTALWORK*100,2) "%_COMPLETE"
FROM GV$SESSION_LONGOPS
WHERE
TOTALWORK != 0
AND SOFAR <> TOTALWORK
order by START_TIME;SQL>   2    3    4    5    6    7    8    9   10

   INST_ID        SID    SERIAL# OPNAME                              SQL_ID        START_TIME           LAST_UPDATE_TIME     remaining mins TARGET          TARGET_DES      SOFAR  TOTALWORK UNITS      %_COMPLETE
---------- ---------- ---------- ----------------------------------- ------------- -------------------- -------------------- -------------- --------------- ---------- ---------- ---------- ---------- ----------
         1        307      19284 RMAN: aggregate input               1k3u5np99ms4d 2019/JUL/22 08:45:58 2019/JUL/22 08:54:10     872.133333 34              backup        6862016  736683860 Blocks            .93
         1         19      26696 RMAN: incremental datafile backup                 2019/JUL/22 08:46:00 2019/JUL/22 08:55:07     643.733333 2701            Set Count     2058096  147380608 Blocks            1.4
         1        288      45120 RMAN: incremental datafile backup                 2019/JUL/22 08:46:01 2019/JUL/22 08:55:07     646.183333 2702            Set Count     2046576  147373184 Blocks           1.39
         1        377       4654 RMAN: incremental datafile backup                 2019/JUL/22 08:46:02 2019/JUL/22 08:55:07     639.183333 2703            Set Count     2064112  147313150 Blocks            1.4
         1        592       1482 RMAN: incremental datafile backup                 2019/JUL/22 08:46:03 2019/JUL/22 08:55:07     650.033333 2704            Set Count     2026352  147306878 Blocks           1.38

