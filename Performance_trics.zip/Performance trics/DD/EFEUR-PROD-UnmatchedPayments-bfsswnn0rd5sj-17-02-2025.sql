/********************************************************************************
*********       E-mail subject: EFEURDEV-6382
*********             Instance: PROD
*********          Description: 
Problem:
SQL bfsswnn0rd5sj was the TOP SQL in the UnmatchedPaymentsResource.

Analysis:
We manually executed this query on PROD and as it can be seen in its execution plan, the heaviest step is the FULL SCAN of table T_ELEMENTS ( the second UNION in the inline view tbl ). 
Instead of the FULL SCAN, it should be accessed through the refelem and the typeelem ( there is index on this columns ). I modified the hint to force Oracle to use the index instead of the FULL SCAN.


Suggestion:
Please change the hint as it is shown in the New SQL section below.

*********               SQL_ID: bfsswnn0rd5sj
*********      Program/Package: 
*********              Request: Dimitare Ivanov
*********               Author: Dimitar Dimitrov
********* Received e-mail date: 17/02/2025
*********      Resolution date: 17/02/2025
*********  Trace old file here: \\epox\specifs\performance\tmp\
*********  Trace new file here:
***********************************************************************************/

/********************************OLD SQL*******************************************/

var B1 VARCHAR2(32);
exec :B1 := 'i%';
var B2 NUMBER;
exec :B2 := 46;
var B3 NUMBER;
exec :B3 := 1;

SELECT *
  FROM (SELECT /*+ first_rows(46)*/
         foo.*, ROWNUM rnum
          FROM (SELECT tbl.refencaiss pmtRef,
                       tbl.receptionDate pmtDate,
                       tbl.bookCode bookCode,
                       tbl.montant_mvt pmtAmount,
                       tbl.devise_mvt pmtCurrency,
                       balance unmAmount,
                       tbl.communication pmtCommunication,
                       CL.nom clientName,
                       CL.prenom clientFstName,
                       CL.nom || ' ' || CL.prenom clientFullName,
                       tbl.refdoss caseRef,
                       tbl.comments intComment,
                       tbl.ext_comments extComment,
                       (SELECT refext
                          FROM t_individu
                         WHERE 1 = 1
                           AND societe = 'CLIENT_NUMBER'
                           AND refindividu = tbl.refpayeur
                           AND refext2 = CL.refindividu
                           AND rownum = 1) clclNumber,
                       DB.nom debtorName,
                       (SELECT G.nom
                          FROM g_piece P, g_individu G
                         WHERE 1 = 1
                           AND P.refdoss =
                               (SELECT reflot
                                  FROM g_dossier
                                 WHERE refdoss =
                                       (SELECT reflot
                                          FROM g_dossier
                                         WHERE refdoss = tbl.refdoss))
                           AND P.typpiece = 'CONTRAT'
                           AND P.str_20_1 = G.refindividu) thirdCtraManagerName,
                       (SELECT case
                                 when 0 <
                                      (select count(*)
                                         FROM g_dossier CMT,
                                              g_dossier DEC,
                                              g_dossier CTR,
                                              g_dossier REV
                                        WHERE 1 = 1
                                          AND CMT.refdoss = tbl.refdoss
                                          AND CMT.reflot = DEC.refdoss
                                          AND DEC.reflot = CTR.Refdoss
                                          AND CTR.refhierarchie = REV.refdoss
                                          AND REV.categdoss = 'COMPTE DB CTR') then
                                  'Reverse'
                                 else
                                  'Classical'
                               end
                          from dual) factoringType,
                       MAN.nom caseManagerName
                  FROM (SELECT /*+ leading(D TNMP) use_nl(TNMP) index(TNMP AGGREG_T_ECR_LIEUPAIMT_IDX) */
                         ENC.refencaiss,
                         ENC.comments,
                         ENC.ext_comments,
                         D.chemin AS bookCode,
                         ENC.devise_mvt,
                         NVL(ENC.dtencaiss_dt, ENC.dtreception_dt) AS receptionDate,
                         VENTIL.montant_mvt,
                         ENC.refpayeur,
                         ENC.comm || ENC.comm2 AS communication,
                         DECODE(NVL(VENTIL.matched_amt, 0),
                                0.0,
                                VENTIL.montant_mvt,
                                (select CH_TAUX.ConversDosMvt(ENC.dtjour,
                                                              VENTIL.refdoss,
                                                              VENTIL.montant_dos -
                                                              NVL(VENTIL.matched_amt,
                                                                  0),
                                                              ENC.devise_mvt,
                                                              'A')
                                   from dual)) AS BALANCE,
                         VENTIL.refdoss
                          FROM g_ventilenc         VENTIL,
                               g_encaissement      ENC,
                               nam_collecte        NC,
                               aggreg_t_ecrdos_nmp TNMP,
                               v_domaine           D
                         WHERE ENC.traite = '2'
                           AND NC.refer(+) = ENC.refencaiss
                           AND NC.compostage(+) = ENC.lieupaimt
                           AND ENC.typencaiss IN ('e_saencaiss', 'e_savirmt')
                           AND ENC.refencaiss = VENTIL.refencaiss
                           AND VENTIL.refencaiss = TNMP.refelem
                           AND VENTIL.refdoss = TNMP.refdoss
                           AND TNMP.balance_dcpt < 0
                           AND D.type(+) = 'NAM_COLLECTE'
                           AND SUBSTR(TNMP.lieupaimt, 1, 3) = D.abrev(+)
                           AND TNMP.lieupaimt like D.abrev(+) || '%'
                        UNION ALL
                        SELECT /*+ leading(VENTIL ENC) index(VENTIL G_VENTILENC_TRAITE_IDX) use_nl(ENC) */
                         ENC.refencaiss,
                         ENC.comments,
                         ENC.ext_comments,
                         D.chemin AS bookCode,
                         ENC.devise_mvt,
                         NVL(ENC.dtencaiss_dt, ENC.dtreception_dt) AS receptionDate,
                         VENTIL.montant_mvt,
                         ENC.refpayeur,
                         ENC.comm || ENC.comm2 AS communication,
                         DECODE(NVL(VENTIL.matched_amt, 0),
                                0.0,
                                VENTIL.montant_mvt,
                                (select CH_TAUX.ConversDosMvt(ENC.dtjour,
                                                              VENTIL.refdoss,
                                                              VENTIL.montant_dos -
                                                              NVL(VENTIL.matched_amt,
                                                                  0),
                                                              ENC.devise_mvt,
                                                              'A')
                                   from dual)) AS BALANCE,
                         VENTIL.refdoss
                          FROM g_ventilenc    VENTIL,
                               g_encaissement ENC,
                               nam_collecte   NC,
                               t_elements     E,
                               v_domaine      D
                         WHERE VENTIL.traite = '0'
                           AND NC.refer(+) = ENC.refencaiss
                           AND NC.compostage(+) = ENC.lieupaimt
                           AND ENC.typencaiss IN ('e_saencaiss', 'e_savirmt')
                           AND ENC.refencaiss = VENTIL.refencaiss
                           AND E.refdoss = VENTIL.refdoss
                           AND E.typeelem = 'en'
                           AND E.refelem = ENC.refencaiss
                           AND D.type(+) = 'NAM_COLLECTE'
                           AND SUBSTR(ENC.lieupaimt, 1, 3) = D.abrev(+)) tbl,
                       t_intervenants CLI,
                       g_individu CL,
                       g_dossier DOSS,
                       g_individu DB,
                       g_personnel USR,
                       g_individu MAN
                 WHERE 1 = 1
                   AND CLI.reftype = 'CL'
                   AND CLI.refdoss = tbl.refdoss
                   AND CLI.refindividu = CL.refindividu
                   AND DOSS.refdoss = tbl.refdoss
                   AND NVL(tbl.balance, 0) <> 0
                   AND DB.refindividu = tbl.refpayeur
                   AND USR.refperso = DOSS.rangmt
                   AND USR.refindividu = MAN.refindividu
                   AND tbl.bookCode like :B1 || '%'
                 ORDER BY pmtDate, pmtAmount DESC, bookCode, pmtRef) foo
         WHERE ROWNUM <= :B2)
 WHERE 1 = 1
   AND rnum >= :B3;
/********************************OLD SQL*******************************************/
/********************************OLD Metrics***************************************/
/*
MODULE                           SQL_ID         PLAN_HASH     SID SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- ------------- ---------- ------- ------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
                                                                          ON CPU               2025/02/17 09:00:00  2025/02/17 11:59:50       48634             16774749 +000000000 02:59:50.401 84%
                                                                          direct path read     2025/02/17 09:09:00  2025/02/17 11:59:50        2602              2350473 +000000000 02:50:49.606 5%
                                                                          enq: TX - row lock c 2025/02/17 09:00:00  2025/02/17 11:59:50        1571              2760584 +000000000 02:59:50.401 3%
                                                                          db file sequential r 2025/02/17 09:00:30  2025/02/17 11:59:50        1423             14607206 +000000000 02:59:20.354 2%
                                                                          cursor: pin S wait o 2025/02/17 09:03:30  2025/02/17 11:57:39        1357                    1 +000000000 02:54:09.536 2%
                                                        0                 log file sync        2025/02/17 09:00:30  2025/02/17 11:59:40         544                      +000000000 02:59:10.320 1%

MODULE                           ACTION                              SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                   PERC
-------------------------------- ----------------------------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
E711B68C1E5BBCFC8C0C6F5A9421ABD7 FAE08CA9FB7B2A42567C7701EC435B8D    bfsswnn0rd5sj 1953699496                       direct path read     2025/02/17 09:11:21  2025/02/17 11:59:50         681                   21 +000000000 02:48:29.358 26%
E711B68C1E5BBCFC8C0C6F5A9421ABD7 FAE08CA9FB7B2A42567C7701EC435B8D    a37h48fd590cq                                  direct path read     2025/02/17 09:23:32  2025/02/17 11:47:37         467                   16 +000000000 02:24:04.410 18%
E711B68C1E5BBCFC8C0C6F5A9421ABD7 FAE08CA9FB7B2A42567C7701EC435B8D    f5cpg2h1j888b                                  direct path read     2025/02/17 10:07:50  2025/02/17 11:59:40         366                   12 +000000000 01:51:50.263 14%
E711B68C1E5BBCFC8C0C6F5A9421ABD7 FAE08CA9FB7B2A42567C7701EC435B8D    f5kv8uahwg4tu                                  direct path read     2025/02/17 09:09:00  2025/02/17 11:59:10         279                    5 +000000000 02:50:09.457 11%
E711B68C1E5BBCFC8C0C6F5A9421ABD7 FAE08CA9FB7B2A42567C7701EC435B8D    6m86f6jtkfty9                                  direct path read     2025/02/17 09:23:12  2025/02/17 11:09:38         222                    8 +000000000 01:46:25.671 9%
E711B68C1E5BBCFC8C0C6F5A9421ABD7 FAE08CA9FB7B2A42567C7701EC435B8D    2x33hymq7xpvv                                  direct path read     2025/02/17 10:12:01  2025/02/17 11:59:40         185                    7 +000000000 01:47:39.318 7%
E711B68C1E5BBCFC8C0C6F5A9421ABD7 FAE08CA9FB7B2A42567C7701EC435B8D    dg3840m0aub7y 2832964388                       direct path read     2025/02/17 10:13:11  2025/02/17 10:46:00         120                    2 +000000000 00:32:49.291 5%
E711B68C1E5BBCFC8C0C6F5A9421ABD7 FAE08CA9FB7B2A42567C7701EC435B8D    83asz851tyhjd 1953699496                       direct path read     2025/02/17 09:31:13  2025/02/17 10:31:46          71                    3 +000000000 01:00:32.913 3%


SQL_ID              MODULE               ELAPSED MAX_WAIT        GETS      READS       ROWS   ELAP/EXEC  GETS/EXEC READS/EXEC  ROWS/EXEC       EXEC PLAN_HASH_VALUE
------------------- ----------------- ---------- --------- ---------- ---------- ---------- ----------- ---------- ---------- ---------- ---------- ---------------
bfsswnn0rd5sj       E711B68C1E5BBCFC8        472 45% cpu      7447213    7431761         21      117.90 1861803.25 1857940.25       5.25          4      1953699496


Plan hash value: 1953699496
--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                            | Name                           | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  | Writes |
--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                                     |                                |      1 |        |  2661K(100)|      0 |00:01:48.34 |    2389K|   2384K|  13307 |
|*  1 |  COUNT STOPKEY                                       |                                |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
|*  2 |   TABLE ACCESS BY INDEX ROWID BATCHED                | T_INDIVIDU                     |      0 |      1 |     5   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*  3 |    INDEX RANGE SCAN                                  | IX_T_INDIVIDU                  |      0 |      3 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|   4 |  NESTED LOOPS                                        |                                |      0 |      1 |     7   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|   5 |   NESTED LOOPS                                       |                                |      0 |      1 |     7   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*  6 |    TABLE ACCESS BY INDEX ROWID BATCHED               | G_PIECE                        |      0 |      1 |     5   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*  7 |     INDEX RANGE SCAN                                 | PIE_REFDOSS                    |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*  8 |      INDEX RANGE SCAN                                | DOS_REFDOSS_REFLOT_IDX         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*  9 |       INDEX RANGE SCAN                               | DOS_REFDOSS_REFLOT_IDX         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|* 10 |    INDEX UNIQUE SCAN                                 | IND_REFINDIV                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|  11 |   TABLE ACCESS BY INDEX ROWID                        | G_INDIVIDU                     |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|  12 |  NESTED LOOPS                                        |                                |      0 |      1 |     9   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|  13 |   NESTED LOOPS                                       |                                |      0 |      1 |     9   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|  14 |    NESTED LOOPS                                      |                                |      0 |      1 |     7   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|  15 |     NESTED LOOPS                                     |                                |      0 |      1 |     5   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|* 16 |      INDEX RANGE SCAN                                | DOS_REFDOSS_REFLOT_IDX         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|* 17 |      INDEX RANGE SCAN                                | DOS_REFDOSS_REFLOT_IDX         |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|* 18 |     TABLE ACCESS BY INDEX ROWID                      | G_DOSSIER                      |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|* 19 |      INDEX UNIQUE SCAN                               | DOS_REFDOSS                    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|* 20 |    INDEX UNIQUE SCAN                                 | DOS_REFDOSS                    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|* 21 |   TABLE ACCESS BY INDEX ROWID                        | G_DOSSIER                      |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|  22 |  FAST DUAL                                           |                                |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|* 23 |  VIEW                                                |                                |      1 |      1 |  2661K  (1)|      0 |00:01:48.34 |    2389K|   2384K|  13307 |
|* 24 |   COUNT STOPKEY                                      |                                |      1 |        |            |      0 |00:01:48.34 |    2389K|   2384K|  13307 |
|  25 |    VIEW                                              |                                |      1 |      1 |  2661K  (1)|      0 |00:01:48.34 |    2389K|   2384K|  13307 |
|* 26 |     SORT ORDER BY STOPKEY                            |                                |      1 |      1 |  2661K  (1)|      0 |00:01:48.34 |    2389K|   2384K|  13307 |
|  27 |      NESTED LOOPS                                    |                                |      1 |      1 |  2661K  (1)|      0 |00:01:48.34 |    2389K|   2384K|  13307 |
|  28 |       NESTED LOOPS                                   |                                |      1 |      1 |  2661K  (1)|      0 |00:01:48.34 |    2389K|   2384K|  13307 |
|  29 |        NESTED LOOPS                                  |                                |      1 |      1 |  2661K  (1)|      0 |00:01:48.34 |    2389K|   2384K|  13307 |
|  30 |         NESTED LOOPS                                 |                                |      1 |      1 |  2661K  (1)|      0 |00:01:48.34 |    2389K|   2384K|  13307 |
|  31 |          NESTED LOOPS                                |                                |      1 |      1 |  2661K  (1)|      0 |00:01:48.34 |    2389K|   2384K|  13307 |
|  32 |           NESTED LOOPS                               |                                |      1 |      1 |  2661K  (1)|      0 |00:01:48.34 |    2389K|   2384K|  13307 |
|* 33 |            VIEW                                      |                                |      1 |      2 |  2661K  (1)|      0 |00:01:48.34 |    2389K|   2384K|  13307 |
|  34 |             UNION-ALL                                |                                |      1 |        |            |      0 |00:01:48.34 |    2389K|   2384K|  13307 |
|  35 |              FAST DUAL                               |                                |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|  36 |              NESTED LOOPS                            |                                |      1 |      1 |    14   (0)|      0 |00:00:00.01 |     133 |      0 |      0 |
|  37 |               NESTED LOOPS                           |                                |      1 |      1 |    14   (0)|      0 |00:00:00.01 |     133 |      0 |      0 |
|  38 |                NESTED LOOPS                          |                                |      1 |      1 |    12   (0)|      0 |00:00:00.01 |     133 |      0 |      0 |
|  39 |                 NESTED LOOPS                         |                                |      1 |      1 |    10   (0)|      0 |00:00:00.01 |     133 |      0 |      0 |
|* 40 |                  TABLE ACCESS BY INDEX ROWID BATCHED | V_DOMAINE                      |      1 |      1 |     8   (0)|      0 |00:00:00.01 |     133 |      0 |      0 |
|* 41 |                   INDEX RANGE SCAN                   | V_DOMAINE_TYPE_CODE_IDX        |      1 |     39 |     2   (0)|   1578 |00:00:00.01 |      15 |      0 |      0 |
|* 42 |                  INDEX RANGE SCAN                    | AGGREG_T_ECR_LIEUPAIMT_IDX     |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|  43 |                 TABLE ACCESS BY INDEX ROWID          | G_VENTILENC                    |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|* 44 |                  INDEX UNIQUE SCAN                   | VENT_REFDOSS                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|* 45 |                INDEX UNIQUE SCAN                     | REFENCAISS                     |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|* 46 |               TABLE ACCESS BY INDEX ROWID            | G_ENCAISSEMENT                 |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|  47 |              FAST DUAL                               |                                |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|  48 |              NESTED LOOPS                            |                                |      1 |      1 |  2661K  (1)|      0 |00:01:48.34 |    2389K|   2384K|  13307 |
|  49 |               NESTED LOOPS                           |                                |      1 |      2 |  2661K  (1)|      0 |00:01:48.34 |    2389K|   2384K|  13307 |
|* 50 |                HASH JOIN                             |                                |      1 |      2 |  2661K  (1)|      0 |00:01:48.34 |    2389K|   2384K|  13307 |
|* 51 |                 TABLE ACCESS FULL                    | T_ELEMENTS                     |      1 |   3200K|   522K  (1)|   3589K|00:01:40.78 |    2389K|   2384K|      0 |
|  52 |                 NESTED LOOPS                         |                                |      1 |   1047K|  2128K  (1)|      0 |00:00:00.01 |       3 |      0 |      0 |
|  53 |                  NESTED LOOPS                        |                                |      1 |   1047K|  2128K  (1)|      0 |00:00:00.01 |       3 |      0 |      0 |
|  54 |                   TABLE ACCESS BY INDEX ROWID BATCHED| G_VENTILENC                    |      1 |   1047K| 32441   (1)|      0 |00:00:00.01 |       3 |      0 |      0 |
|* 55 |                    INDEX RANGE SCAN                  | G_VENTILENC_TRAITE_IDX         |      1 |   1047K|  2246   (1)|      0 |00:00:00.01 |       3 |      0 |      0 |
|* 56 |                   INDEX UNIQUE SCAN                  | REFENCAISS                     |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|* 57 |                  TABLE ACCESS BY INDEX ROWID         | G_ENCAISSEMENT                 |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|* 58 |                INDEX RANGE SCAN                      | DOM_TYPABREV                   |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|* 59 |               TABLE ACCESS BY INDEX ROWID            | V_DOMAINE                      |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|  60 |            TABLE ACCESS BY INDEX ROWID               | G_INDIVIDU                     |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|* 61 |             INDEX UNIQUE SCAN                        | IND_REFINDIV                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|* 62 |           INDEX RANGE SCAN                           | G_DOSSIER_REFDOSS_SOLDE_RANGMT |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|  63 |          TABLE ACCESS BY INDEX ROWID BATCHED         | G_PERSONNEL                    |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|* 64 |           INDEX RANGE SCAN                           | GPERSREFP                      |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|* 65 |         INDEX RANGE SCAN                             | INT_REFDOSS                    |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|  66 |        TABLE ACCESS BY INDEX ROWID                   | G_INDIVIDU                     |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|* 67 |         INDEX UNIQUE SCAN                            | IND_REFINDIV                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|  68 |       TABLE ACCESS BY INDEX ROWID                    | G_INDIVIDU                     |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|* 69 |        INDEX UNIQUE SCAN                             | IND_REFINDIV                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   1 - filter(ROWNUM=1)
   2 - filter(("REFEXT2"=:B1 AND "SOCIETE"='CLIENT_NUMBER'))
   3 - access("REFINDIVIDU"=:B1)
   6 - filter("P"."STR_20_1" IS NOT NULL)
   7 - access("P"."REFDOSS"= AND "P"."TYPPIECE"='CONTRAT')
   8 - access("REFDOSS"=)
   9 - access("REFDOSS"=:B1)
  10 - access("P"."STR_20_1"="G"."REFINDIVIDU")
  16 - access("CMT"."REFDOSS"=:B1)
  17 - access("CMT"."REFLOT"="DEC"."REFDOSS")
  18 - filter("CTR"."REFHIERARCHIE" IS NOT NULL)
  19 - access("DEC"."REFLOT"="CTR"."REFDOSS")
  20 - access("CTR"."REFHIERARCHIE"="REV"."REFDOSS")
  21 - filter("REV"."CATEGDOSS"='COMPTE DB CTR')
  23 - filter("RNUM">=:B3)
  24 - filter(ROWNUM<=:B2)
  26 - filter(ROWNUM<=:B2)
  33 - filter(NVL("TBL"."BALANCE",0)<>0)
  40 - filter("D"."CHEMIN" LIKE :B1||'%')
  41 - access("D"."TYPE"='NAM_COLLECTE')
  42 - access("TNMP"."LIEUPAIMT" LIKE "D"."ABREV"||'%' AND "TNMP"."BALANCE_DCPT"<0)
       filter(("D"."ABREV"=SUBSTR("TNMP"."LIEUPAIMT",1,3) AND "TNMP"."BALANCE_DCPT"<0 AND "TNMP"."LIEUPAIMT" LIKE "D"."ABREV"||'%'))
  44 - access("VENTIL"."REFDOSS"="TNMP"."REFDOSS" AND "VENTIL"."REFENCAISS"="TNMP"."REFELEM")
  45 - access("ENC"."REFENCAISS"="VENTIL"."REFENCAISS")
  46 - filter((INTERNAL_FUNCTION("ENC"."TYPENCAISS") AND "ENC"."TRAITE"='2'))
  50 - access("E"."REFDOSS"="VENTIL"."REFDOSS" AND "E"."REFELEM"="ENC"."REFENCAISS")
  51 - filter("E"."TYPEELEM"='en')
  55 - access("VENTIL"."TRAITE"='0')
  56 - access("ENC"."REFENCAISS"="VENTIL"."REFENCAISS")
  57 - filter(("ENC"."TYPENCAISS"='e_saencaiss' OR "ENC"."TYPENCAISS"='e_savirmt'))
  58 - access("D"."TYPE"='NAM_COLLECTE' AND "D"."ABREV"=SUBSTR("ENC"."LIEUPAIMT",1,3))
  59 - filter("D"."CHEMIN" LIKE :B1||'%')
  61 - access("DB"."REFINDIVIDU"="TBL"."REFPAYEUR")
  62 - access("DOSS"."REFDOSS"="TBL"."REFDOSS")
  64 - access("USR"."REFPERSO"="DOSS"."RANGMT")
  65 - access("CLI"."REFDOSS"="TBL"."REFDOSS" AND "CLI"."REFTYPE"='CL')
  67 - access("USR"."REFINDIVIDU"="MAN"."REFINDIVIDU")
  69 - access("CLI"."REFINDIVIDU"="CL"."REFINDIVIDU")
*/
/********************************OLD Metrics***************************************/

/********************************New SQL*******************************************/

SELECT *
  FROM (SELECT /*+ first_rows(46)*/
         foo.*, ROWNUM rnum
          FROM (SELECT tbl.refencaiss pmtRef,
                       tbl.receptionDate pmtDate,
                       tbl.bookCode bookCode,
                       tbl.montant_mvt pmtAmount,
                       tbl.devise_mvt pmtCurrency,
                       balance unmAmount,
                       tbl.communication pmtCommunication,
                       CL.nom clientName,
                       CL.prenom clientFstName,
                       CL.nom || ' ' || CL.prenom clientFullName,
                       tbl.refdoss caseRef,
                       tbl.comments intComment,
                       tbl.ext_comments extComment,
                       (SELECT refext
                          FROM t_individu
                         WHERE 1 = 1
                           AND societe = 'CLIENT_NUMBER'
                           AND refindividu = tbl.refpayeur
                           AND refext2 = CL.refindividu
                           AND rownum = 1) clclNumber,
                       DB.nom debtorName,
                       (SELECT G.nom
                          FROM g_piece P, g_individu G
                         WHERE 1 = 1
                           AND P.refdoss =
                               (SELECT reflot
                                  FROM g_dossier
                                 WHERE refdoss =
                                       (SELECT reflot
                                          FROM g_dossier
                                         WHERE refdoss = tbl.refdoss))
                           AND P.typpiece = 'CONTRAT'
                           AND P.str_20_1 = G.refindividu) thirdCtraManagerName,
                       (SELECT case
                                 when 0 <
                                      (select count(*)
                                         FROM g_dossier CMT,
                                              g_dossier DEC,
                                              g_dossier CTR,
                                              g_dossier REV
                                        WHERE 1 = 1
                                          AND CMT.refdoss = tbl.refdoss
                                          AND CMT.reflot = DEC.refdoss
                                          AND DEC.reflot = CTR.Refdoss
                                          AND CTR.refhierarchie = REV.refdoss
                                          AND REV.categdoss = 'COMPTE DB CTR') then
                                  'Reverse'
                                 else
                                  'Classical'
                               end
                          from dual) factoringType,
                       MAN.nom caseManagerName
                  FROM (SELECT /*+ leading(D TNMP) use_nl(TNMP) index(TNMP AGGREG_T_ECR_LIEUPAIMT_IDX) */
                         ENC.refencaiss,
                         ENC.comments,
                         ENC.ext_comments,
                         D.chemin AS bookCode,
                         ENC.devise_mvt,
                         NVL(ENC.dtencaiss_dt, ENC.dtreception_dt) AS receptionDate,
                         VENTIL.montant_mvt,
                         ENC.refpayeur,
                         ENC.comm || ENC.comm2 AS communication,
                         DECODE(NVL(VENTIL.matched_amt, 0),
                                0.0,
                                VENTIL.montant_mvt,
                                (select CH_TAUX.ConversDosMvt(ENC.dtjour,
                                                              VENTIL.refdoss,
                                                              VENTIL.montant_dos -
                                                              NVL(VENTIL.matched_amt,
                                                                  0),
                                                              ENC.devise_mvt,
                                                              'A')
                                   from dual)) AS BALANCE,
                         VENTIL.refdoss
                          FROM g_ventilenc         VENTIL,
                               g_encaissement      ENC,
                               nam_collecte        NC,
                               aggreg_t_ecrdos_nmp TNMP,
                               v_domaine           D
                         WHERE ENC.traite = '2'
                           AND NC.refer(+) = ENC.refencaiss
                           AND NC.compostage(+) = ENC.lieupaimt
                           AND ENC.typencaiss IN ('e_saencaiss', 'e_savirmt')
                           AND ENC.refencaiss = VENTIL.refencaiss
                           AND VENTIL.refencaiss = TNMP.refelem
                           AND VENTIL.refdoss = TNMP.refdoss
                           AND TNMP.balance_dcpt < 0
                           AND D.type(+) = 'NAM_COLLECTE'
                           AND SUBSTR(TNMP.lieupaimt, 1, 3) = D.abrev(+)
                           AND TNMP.lieupaimt like D.abrev(+) || '%'
                        UNION ALL
                        SELECT /*+ leading(VENTIL ENC E) index(VENTIL G_VENTILENC_TRAITE_IDX) use_nl(ENC) index(E ELE_ELEMTYPE) use_nl(E) */
                         ENC.refencaiss,
                         ENC.comments,
                         ENC.ext_comments,
                         D.chemin AS bookCode,
                         ENC.devise_mvt,
                         NVL(ENC.dtencaiss_dt, ENC.dtreception_dt) AS receptionDate,
                         VENTIL.montant_mvt,
                         ENC.refpayeur,
                         ENC.comm || ENC.comm2 AS communication,
                         DECODE(NVL(VENTIL.matched_amt, 0),
                                0.0,
                                VENTIL.montant_mvt,
                                (select CH_TAUX.ConversDosMvt(ENC.dtjour,
                                                              VENTIL.refdoss,
                                                              VENTIL.montant_dos -
                                                              NVL(VENTIL.matched_amt,
                                                                  0),
                                                              ENC.devise_mvt,
                                                              'A')
                                   from dual)) AS BALANCE,
                         VENTIL.refdoss
                          FROM g_ventilenc    VENTIL,
                               g_encaissement ENC,
                               nam_collecte   NC,
                               t_elements     E,
                               v_domaine      D
                         WHERE VENTIL.traite = '0'
                           AND NC.refer(+) = ENC.refencaiss
                           AND NC.compostage(+) = ENC.lieupaimt
                           AND ENC.typencaiss IN ('e_saencaiss', 'e_savirmt')
                           AND ENC.refencaiss = VENTIL.refencaiss
                           AND E.refdoss = VENTIL.refdoss
                           AND E.typeelem = 'en'
                           AND E.refelem = ENC.refencaiss
                           AND D.type(+) = 'NAM_COLLECTE'
                           AND SUBSTR(ENC.lieupaimt, 1, 3) = D.abrev(+)) tbl,
                       t_intervenants CLI,
                       g_individu CL,
                       g_dossier DOSS,
                       g_individu DB,
                       g_personnel USR,
                       g_individu MAN
                 WHERE 1 = 1
                   AND CLI.reftype = 'CL'
                   AND CLI.refdoss = tbl.refdoss
                   AND CLI.refindividu = CL.refindividu
                   AND DOSS.refdoss = tbl.refdoss
                   AND NVL(tbl.balance, 0) <> 0
                   AND DB.refindividu = tbl.refpayeur
                   AND USR.refperso = DOSS.rangmt
                   AND USR.refindividu = MAN.refindividu
                   AND tbl.bookCode like :B1 || '%'
                 ORDER BY pmtDate, pmtAmount DESC, bookCode, pmtRef) foo
         WHERE ROWNUM <= :B2)
 WHERE 1 = 1
   AND rnum >= :B3;
/********************************New SQL*******************************************/
/********************************New Metrics***************************************/
/*
Plan hash value: 4063993341
-------------------------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                           | Name                           | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers |
-------------------------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                                    |                                |      1 |        |  6320K(100)|      0 |00:00:00.01 |     136 |
|*  1 |  COUNT STOPKEY                                      |                                |      0 |        |            |      0 |00:00:00.01 |       0 |
|*  2 |   TABLE ACCESS BY INDEX ROWID BATCHED               | T_INDIVIDU                     |      0 |      1 |     5   (0)|      0 |00:00:00.01 |       0 |
|*  3 |    INDEX RANGE SCAN                                 | IX_T_INDIVIDU                  |      0 |      3 |     3   (0)|      0 |00:00:00.01 |       0 |
|   4 |  NESTED LOOPS                                       |                                |      0 |      1 |     7   (0)|      0 |00:00:00.01 |       0 |
|   5 |   NESTED LOOPS                                      |                                |      0 |      1 |     7   (0)|      0 |00:00:00.01 |       0 |
|*  6 |    TABLE ACCESS BY INDEX ROWID BATCHED              | G_PIECE                        |      0 |      1 |     5   (0)|      0 |00:00:00.01 |       0 |
|*  7 |     INDEX RANGE SCAN                                | PIE_REFDOSS                    |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|*  8 |      INDEX RANGE SCAN                               | DOS_REFDOSS_REFLOT_IDX         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*  9 |       INDEX RANGE SCAN                              | DOS_REFDOSS_REFLOT_IDX         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|* 10 |    INDEX UNIQUE SCAN                                | IND_REFINDIV                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|  11 |   TABLE ACCESS BY INDEX ROWID                       | G_INDIVIDU                     |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |
|  12 |  NESTED LOOPS                                       |                                |      0 |      1 |     9   (0)|      0 |00:00:00.01 |       0 |
|  13 |   NESTED LOOPS                                      |                                |      0 |      1 |     9   (0)|      0 |00:00:00.01 |       0 |
|  14 |    NESTED LOOPS                                     |                                |      0 |      1 |     7   (0)|      0 |00:00:00.01 |       0 |
|  15 |     NESTED LOOPS                                    |                                |      0 |      1 |     5   (0)|      0 |00:00:00.01 |       0 |
|* 16 |      INDEX RANGE SCAN                               | DOS_REFDOSS_REFLOT_IDX         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|* 17 |      INDEX RANGE SCAN                               | DOS_REFDOSS_REFLOT_IDX         |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |
|* 18 |     TABLE ACCESS BY INDEX ROWID                     | G_DOSSIER                      |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |
|* 19 |      INDEX UNIQUE SCAN                              | DOS_REFDOSS                    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 20 |    INDEX UNIQUE SCAN                                | DOS_REFDOSS                    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 21 |   TABLE ACCESS BY INDEX ROWID                       | G_DOSSIER                      |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |
|  22 |  FAST DUAL                                          |                                |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |
|* 23 |  VIEW                                               |                                |      1 |      1 |  6320K  (1)|      0 |00:00:00.01 |     136 |
|* 24 |   COUNT STOPKEY                                     |                                |      1 |        |            |      0 |00:00:00.01 |     136 |
|  25 |    VIEW                                             |                                |      1 |      1 |  6320K  (1)|      0 |00:00:00.01 |     136 |
|* 26 |     SORT ORDER BY STOPKEY                           |                                |      1 |      1 |  6320K  (1)|      0 |00:00:00.01 |     136 |
|  27 |      NESTED LOOPS                                   |                                |      1 |      1 |  6320K  (1)|      0 |00:00:00.01 |     136 |
|  28 |       NESTED LOOPS                                  |                                |      1 |      1 |  6320K  (1)|      0 |00:00:00.01 |     136 |
|  29 |        NESTED LOOPS                                 |                                |      1 |      1 |  6320K  (1)|      0 |00:00:00.01 |     136 |
|  30 |         NESTED LOOPS                                |                                |      1 |      1 |  6320K  (1)|      0 |00:00:00.01 |     136 |
|  31 |          NESTED LOOPS                               |                                |      1 |      1 |  6320K  (1)|      0 |00:00:00.01 |     136 |
|  32 |           NESTED LOOPS                              |                                |      1 |      1 |  6320K  (1)|      0 |00:00:00.01 |     136 |
|* 33 |            VIEW                                     |                                |      1 |      2 |  6320K  (1)|      0 |00:00:00.01 |     136 |
|  34 |             UNION-ALL                               |                                |      1 |        |            |      0 |00:00:00.01 |     136 |
|  35 |              FAST DUAL                              |                                |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |
|  36 |              NESTED LOOPS                           |                                |      1 |      1 |    14   (0)|      0 |00:00:00.01 |     133 |
|  37 |               NESTED LOOPS                          |                                |      1 |      1 |    14   (0)|      0 |00:00:00.01 |     133 |
|  38 |                NESTED LOOPS                         |                                |      1 |      1 |    12   (0)|      0 |00:00:00.01 |     133 |
|  39 |                 NESTED LOOPS                        |                                |      1 |      1 |    10   (0)|      0 |00:00:00.01 |     133 |
|* 40 |                  TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE                      |      1 |      1 |     8   (0)|      0 |00:00:00.01 |     133 |
|* 41 |                   INDEX RANGE SCAN                  | V_DOMAINE_TYPE_CODE_IDX        |      1 |     39 |     2   (0)|   1578 |00:00:00.01 |      15 |
|* 42 |                  INDEX RANGE SCAN                   | AGGREG_T_ECR_LIEUPAIMT_IDX     |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |
|  43 |                 TABLE ACCESS BY INDEX ROWID         | G_VENTILENC                    |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |
|* 44 |                  INDEX UNIQUE SCAN                  | VENT_REFDOSS                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 45 |                INDEX UNIQUE SCAN                    | REFENCAISS                     |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 46 |               TABLE ACCESS BY INDEX ROWID           | G_ENCAISSEMENT                 |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |
|  47 |              FAST DUAL                              |                                |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |
|  48 |              NESTED LOOPS                           |                                |      1 |      1 |  6320K  (1)|      0 |00:00:00.01 |       3 |
|  49 |               NESTED LOOPS                          |                                |      1 |      2 |  6320K  (1)|      0 |00:00:00.01 |       3 |
|  50 |                NESTED LOOPS                         |                                |      1 |      2 |  6320K  (1)|      0 |00:00:00.01 |       3 |
|  51 |                 NESTED LOOPS                        |                                |      1 |   1047K|  2128K  (1)|      0 |00:00:00.01 |       3 |
|  52 |                  TABLE ACCESS BY INDEX ROWID BATCHED| G_VENTILENC                    |      1 |   1047K| 32441   (1)|      0 |00:00:00.01 |       3 |
|* 53 |                   INDEX RANGE SCAN                  | G_VENTILENC_TRAITE_IDX         |      1 |   1047K|  2246   (1)|      0 |00:00:00.01 |       3 |
|* 54 |                  TABLE ACCESS BY INDEX ROWID        | G_ENCAISSEMENT                 |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |
|* 55 |                   INDEX UNIQUE SCAN                 | REFENCAISS                     |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 56 |                 TABLE ACCESS BY INDEX ROWID BATCHED | T_ELEMENTS                     |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|* 57 |                  INDEX RANGE SCAN                   | ELE_ELEMTYPE                   |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|* 58 |                INDEX RANGE SCAN                     | DOM_TYPABREV                   |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |
|* 59 |               TABLE ACCESS BY INDEX ROWID           | V_DOMAINE                      |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|  60 |            TABLE ACCESS BY INDEX ROWID              | G_INDIVIDU                     |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |
|* 61 |             INDEX UNIQUE SCAN                       | IND_REFINDIV                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 62 |           INDEX RANGE SCAN                          | G_DOSSIER_REFDOSS_SOLDE_RANGMT |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |
|  63 |          TABLE ACCESS BY INDEX ROWID BATCHED        | G_PERSONNEL                    |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |
|* 64 |           INDEX RANGE SCAN                          | GPERSREFP                      |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 65 |         INDEX RANGE SCAN                            | INT_REFDOSS                    |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |
|  66 |        TABLE ACCESS BY INDEX ROWID                  | G_INDIVIDU                     |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |
|* 67 |         INDEX UNIQUE SCAN                           | IND_REFINDIV                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|  68 |       TABLE ACCESS BY INDEX ROWID                   | G_INDIVIDU                     |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |
|* 69 |        INDEX UNIQUE SCAN                            | IND_REFINDIV                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
-------------------------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   1 - filter(ROWNUM=1)
   2 - filter(("REFEXT2"=:B1 AND "SOCIETE"='CLIENT_NUMBER'))
   3 - access("REFINDIVIDU"=:B1)
   6 - filter("P"."STR_20_1" IS NOT NULL)
   7 - access("P"."REFDOSS"= AND "P"."TYPPIECE"='CONTRAT')
   8 - access("REFDOSS"=)
   9 - access("REFDOSS"=:B1)
  10 - access("P"."STR_20_1"="G"."REFINDIVIDU")
  16 - access("CMT"."REFDOSS"=:B1)
  17 - access("CMT"."REFLOT"="DEC"."REFDOSS")
  18 - filter("CTR"."REFHIERARCHIE" IS NOT NULL)
  19 - access("DEC"."REFLOT"="CTR"."REFDOSS")
  20 - access("CTR"."REFHIERARCHIE"="REV"."REFDOSS")
  21 - filter("REV"."CATEGDOSS"='COMPTE DB CTR')
  23 - filter("RNUM">=:B3)
  24 - filter(ROWNUM<=:B2)
  26 - filter(ROWNUM<=:B2)
  33 - filter(NVL("TBL"."BALANCE",0)<>0)
  40 - filter("D"."CHEMIN" LIKE :B1||'%')
  41 - access("D"."TYPE"='NAM_COLLECTE')
  42 - access("TNMP"."LIEUPAIMT" LIKE "D"."ABREV"||'%' AND "TNMP"."BALANCE_DCPT"<0)
       filter(("D"."ABREV"=SUBSTR("TNMP"."LIEUPAIMT",1,3) AND "TNMP"."BALANCE_DCPT"<0 AND "TNMP"."LIEUPAIMT" LIKE "D"."ABREV"||'%'))
  44 - access("VENTIL"."REFDOSS"="TNMP"."REFDOSS" AND "VENTIL"."REFENCAISS"="TNMP"."REFELEM")
  45 - access("ENC"."REFENCAISS"="VENTIL"."REFENCAISS")
  46 - filter((INTERNAL_FUNCTION("ENC"."TYPENCAISS") AND "ENC"."TRAITE"='2'))
  53 - access("VENTIL"."TRAITE"='0')
  54 - filter(("ENC"."TYPENCAISS"='e_saencaiss' OR "ENC"."TYPENCAISS"='e_savirmt'))
  55 - access("ENC"."REFENCAISS"="VENTIL"."REFENCAISS")
  56 - filter("E"."REFDOSS"="VENTIL"."REFDOSS")
  57 - access("E"."REFELEM"="ENC"."REFENCAISS" AND "E"."TYPEELEM"='en')
  58 - access("D"."TYPE"='NAM_COLLECTE' AND "D"."ABREV"=SUBSTR("ENC"."LIEUPAIMT",1,3))
  59 - filter("D"."CHEMIN" LIKE :B1||'%')
  61 - access("DB"."REFINDIVIDU"="TBL"."REFPAYEUR")
  62 - access("DOSS"."REFDOSS"="TBL"."REFDOSS")
  64 - access("USR"."REFPERSO"="DOSS"."RANGMT")
  65 - access("CLI"."REFDOSS"="TBL"."REFDOSS" AND "CLI"."REFTYPE"='CL')
  67 - access("USR"."REFINDIVIDU"="MAN"."REFINDIVIDU")
  69 - access("CLI"."REFINDIVIDU"="CL"."REFINDIVIDU")  
*/
/********************************New Metrics***************************************/

/********************************Index statistics**********************************/

/********************************Other SQLs****************************************/          
/*

*/ 
/********************************Other SQLs****************************************/              
