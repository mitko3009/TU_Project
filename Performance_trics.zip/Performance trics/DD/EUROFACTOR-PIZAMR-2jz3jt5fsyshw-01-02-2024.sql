/********************************************************************************
*********       E-mail subject: EFDE2DEV-538
*********             Instance: PIZAMR
*********          Description: 
Problem:
Slowness in batch AggrFunding and in batch AutomaticFunding on PIZAMR.

Analysis:
From the trace files of the two batches, we found that they have similar problem. The problem is that function ftr_decompte.isContractValid(d.refdoss) 
is called in the WHERE clause of the cursor, which is not recomended by P&T because it leads to executing it many times unnecessarily. The solution here is to move the function in the SELECT part and it will not be executed 
will not be called more than once for one refdoss.

Suggestion:
Please modify the SQL texts of the two cursors as it is shown in the New SQL section below.

*********               SQL_ID: 2jz3jt5fsyshw, b33x4udhxtqd2
*********      Program/Package: AggrFunding  batch, AutomaticFunding  batch
*********              Request: Ivaylo Ivanov ( BM ) 
*********               Author: Dimitar Dimitrov
********* Received e-mail date: 01/02/2024
*********      Resolution date: 01/02/2024
*********  Trace old file here: \\epox\specifs\performance\tmp\
*********  Trace new file here:
***********************************************************************************/

/********************************OLD SQL*******************************************/
-- AggrFunding

SELECT  d.reffactor /* automatically injected */, d.refdoss            statement_ref,                                            
       nvl(sc.mt50, 0)      threshold,                                                
       nvl(sc.fg97, 'N')    auto_fund,                                                
       nvl(sc.fg38, 'N')    auto_credit_fiu,                                          
       nvl( f.nb48, 'N')    fuc_not_impc_avail,                                       
       nvl(sc.fg168, 'N')   fx_processing,                                            
       f.st04               req_fx_proc,                                              
       f.st05               not_req_fx_proc,                                          
       nvl(sc.fg193, 'N')   excl_ext_util,                                            
       nvl(f.fg16, 'N')     real_avail_exclude_clgr,                                  
       d.reflot             contract_ref,                                             
       d.devise             statement_curr                                            
  FROM g_dossier d, g_piece sc, g_piece f                                             
 WHERE d.categdoss like 'DECOMPTE%'                                                   
   AND DECODE(d.categdoss, 'DECOMPTE IMP', 'O', sc.fg09) = 'O'                              /* reffactor condition */
   AND d.reffactor IN ('INT00000') 
   AND sc.refdoss                          = d.refdoss                                
   AND sc.typpiece                         = 'SOUS-CONTRAT'                           
   AND sc.fg09                             = 'O'                                      
   AND NOT EXISTS (                                                                   
                    SELECT 1                                                          
                      FROM user_cntr_pref c_pref                                      
                     WHERE c_pref.refdoss            = d.refdoss                      
                       AND c_pref.fg_suppr_auto_fund = 'O'                            
                  )                                                                   
   AND ftr_decompte.isContractValid(d.refdoss) NOT IN (0, 2)                          
   AND f.gpiheure                          = d.reffactor                              
   AND f.typpiece                          = 'FACTOR'                                 
   AND (                                                                              
           sc.fg97 = 'O'                                                              
        OR sc.fg97 = 'F' AND sc.fg168 = 'O'           AND f.st04 IN ('EOD','BOTH')    
        OR sc.fg97 = 'F' AND nvl(sc.fg168, 'N') = 'N' AND f.st05 IN ('EOD','BOTH')    
        OR sc.fg38 = 'O'                                                              
        OR sc.fg38 = 'F' AND sc.fg168 = 'O'           AND f.st04 IN ('EOD','BOTH')    
        OR sc.fg38 = 'F' AND nvl(sc.fg168, 'N') = 'N' AND f.st05 IN ('EOD','BOTH')    
        );



-- AutomaticFunding 

SELECT  d.reffactor /* automatically injected */, d.refdoss            refdoss,                                                  
       nvl(sc.mt50, 0)      threshold,                                                
       nvl(sc.fg97, 'N')    auto_fund,                                                
       nvl(f.fg100, 'N')    curr_conversion,                                          
       nvl(sc.fg38, 'N')    auto_credit_fiu,                                          
       nvl( f.nb48, 'N')    fuc_not_impc_avail,                                       
       nvl(sc.fg168, 'N')   fx_processing,                                            
       f.st04               req_fx_proc,	                                             
       f.st05               not_req_fx_proc,                                           
       nvl(sc.fg193, 'N')   excl_ext_util                                             
  FROM g_dossier d, g_piece sc, g_etude e, g_piece f                                  
 WHERE d.categdoss like 'DECOMPTE%'                                                   
   AND DECODE(d.categdoss, 'DECOMPTE IMP', 'O', sc.fg09) = 'O'                              /* reffactor condition */
   AND d.reffactor IN ('INT00000') 
   AND sc.refdoss = d.refdoss                                                         
   AND sc.typpiece = 'SOUS-CONTRAT'                                                   
   AND sc.fg09 = 'O'                                                                  
   AND NOT EXISTS ( SELECT 1                                                          
                     FROM user_cntr_pref c_pref                                       
                    WHERE c_pref.refdoss            = d.refdoss                       
                      AND c_pref.fg_suppr_auto_fund = 'O'                             
                 )                                                                    
   AND ftr_decompte.isContractValid(d.refdoss) NOT IN (0, 2)                          
   AND (e.getdcli != 'C204' OR nvl(sc.fg121, 'N') != 'O')                             
   AND f.gpiheure = d.reffactor                                                       
   AND f.typpiece='FACTOR'                                                            
   AND (                                                                              
           sc.fg97 = 'O'                                                              
        OR sc.fg97 = 'F' AND sc.fg168 = 'O'           AND f.st04 IN ('EOD','BOTH')    
        OR sc.fg97 = 'F' AND nvl(sc.fg168, 'N') = 'N' AND f.st05 IN ('EOD','BOTH')    
        OR sc.fg38 = 'O'                                                              
        OR sc.fg38 = 'F' AND sc.fg168 = 'O'           AND f.st04 IN ('EOD','BOTH')    
        OR sc.fg38 = 'F' AND nvl(sc.fg168, 'N') = 'N' AND f.st05 IN ('EOD','BOTH')    
        );	

/********************************OLD SQL*******************************************/
/********************************OLD Metrics***************************************/
/*
-- AggrFunding 

Plan hash value: 713388387
---------------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                               | Name                    | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  |
---------------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                        |                         |      1 |        |     5 (100)|      4 |00:02:07.16 |     197K|  16497 |
|   1 |  NESTED LOOPS                           |                         |      1 |      1 |     5   (0)|      4 |00:02:07.16 |     197K|  16497 |
|   2 |   NESTED LOOPS                          |                         |      1 |      2 |     5   (0)|      4 |00:02:07.16 |     197K|  16497 |
|   3 |    NESTED LOOPS                         |                         |      1 |      1 |     4   (0)|      4 |00:02:07.16 |     197K|  16497 |
|   4 |     NESTED LOOPS ANTI                   |                         |      1 |      1 |     2   (0)|   4356 |00:02:07.02 |     172K|  16497 |
|*  5 |      TABLE ACCESS BY INDEX ROWID BATCHED| G_DOSSIER               |      1 |      1 |     1   (0)|   4356 |00:02:06.96 |     172K|  16497 |
|*  6 |       INDEX SKIP SCAN                   | REFHIERARCHIE_IDX       |      1 |      2 |     1   (0)|   4715 |00:02:06.85 |     161K|  16497 |
|*  7 |      TABLE ACCESS BY INDEX ROWID        | USER_CNTR_PREF          |   4356 |      1 |     1   (0)|      0 |00:00:00.03 |       7 |      0 |
|*  8 |       INDEX UNIQUE SCAN                 | AK_KEY_REFPIEC_USER_CTR |   4356 |      1 |     1   (0)|      2 |00:00:00.02 |       5 |      0 |
|*  9 |     TABLE ACCESS BY INDEX ROWID BATCHED | G_PIECE                 |   4356 |      1 |     2   (0)|      4 |00:00:00.13 |   25091 |      0 |
|* 10 |      INDEX RANGE SCAN                   | PIE_REFDOSS             |   4356 |    183 |     1   (0)|   4356 |00:00:00.05 |    8885 |      0 |
|* 11 |    INDEX RANGE SCAN                     | G_PIECE$GPIHEURE        |      4 |      2 |     1   (0)|      4 |00:00:00.01 |      11 |      0 |
|* 12 |   TABLE ACCESS BY INDEX ROWID           | G_PIECE                 |      4 |      1 |     1   (0)|      4 |00:00:00.01 |      10 |      0 |
---------------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   5 - filter("D"."REFFACTOR"='INT00000')
   6 - access("D"."CATEGDOSS" LIKE 'DECOMPTE%')
       filter(("D"."CATEGDOSS" LIKE 'DECOMPTE%' AND "FTR_DECOMPTE"."ISCONTRACTVALID"("D"."REFDOSS")<>0 AND
              "FTR_DECOMPTE"."ISCONTRACTVALID"("D"."REFDOSS")<>2))
   7 - filter("C_PREF"."FG_SUPPR_AUTO_FUND"='O')
   8 - access("C_PREF"."REFDOSS"="D"."REFDOSS")
       filter("C_PREF"."REFDOSS" IS NOT NULL)
   9 - filter(("SC"."FG09"='O' AND (INTERNAL_FUNCTION("SC"."FG38") OR INTERNAL_FUNCTION("SC"."FG97") OR ("SC"."FG38"='F' AND
              "SC"."FG168"='O') OR ("SC"."FG97"='F' AND "SC"."FG168"='O')) AND DECODE("D"."CATEGDOSS",'DECOMPTE IMP','O',"SC"."FG09")='O'))
  10 - access("SC"."REFDOSS"="D"."REFDOSS" AND "SC"."TYPPIECE"='SOUS-CONTRAT')
  11 - access("F"."GPIHEURE"='INT00000')
  12 - filter(("F"."TYPPIECE"='FACTOR' AND ("SC"."FG97"='O' OR ("SC"."FG97"='F' AND "SC"."FG168"='O' AND INTERNAL_FUNCTION("F"."ST04")) OR
              ("SC"."FG97"='F' AND NVL("SC"."FG168",'N')='N' AND INTERNAL_FUNCTION("F"."ST05")) OR "SC"."FG38"='O' OR ("SC"."FG38"='F' AND
              "SC"."FG168"='O' AND INTERNAL_FUNCTION("F"."ST04")) OR ("SC"."FG38"='F' AND NVL("SC"."FG168",'N')='N' AND INTERNAL_FUNCTION("F"."ST05")))))



-- AutomaticFunding 

Plan hash value: 3091717562
----------------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                | Name                    | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  |
----------------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                         |                         |      1 |        |     8 (100)|      4 |00:00:03.58 |     197K|    323 |
|   1 |  NESTED LOOPS                            |                         |      1 |      1 |     8   (0)|      4 |00:00:03.58 |     197K|    323 |
|   2 |   NESTED LOOPS                           |                         |      1 |      2 |     8   (0)|      4 |00:00:03.58 |     197K|    323 |
|   3 |    NESTED LOOPS                          |                         |      1 |      1 |     7   (0)|      4 |00:00:03.58 |     197K|    323 |
|   4 |     MERGE JOIN CARTESIAN                 |                         |      1 |      1 |     5   (0)|   4356 |00:00:03.54 |     172K|    323 |
|   5 |      NESTED LOOPS ANTI                   |                         |      1 |      1 |     2   (0)|   4356 |00:00:03.53 |     172K|    323 |
|*  6 |       TABLE ACCESS BY INDEX ROWID BATCHED| G_DOSSIER               |      1 |      1 |     1   (0)|   4356 |00:00:03.52 |     172K|    323 |
|*  7 |        INDEX SKIP SCAN                   | REFHIERARCHIE_IDX       |      1 |      2 |     1   (0)|   4715 |00:00:03.48 |     161K|    323 |
|*  8 |       TABLE ACCESS BY INDEX ROWID        | USER_CNTR_PREF          |   4356 |      1 |     1   (0)|      0 |00:00:00.01 |       7 |      0 |
|*  9 |        INDEX UNIQUE SCAN                 | AK_KEY_REFPIEC_USER_CTR |   4356 |      1 |     1   (0)|      2 |00:00:00.01 |       5 |      0 |
|  10 |      BUFFER SORT                         |                         |   4356 |      1 |     4   (0)|   4356 |00:00:00.01 |       6 |      0 |
|  11 |       TABLE ACCESS FULL                  | G_ETUDE                 |      1 |      1 |     3   (0)|      1 |00:00:00.01 |       6 |      0 |
|* 12 |     TABLE ACCESS BY INDEX ROWID BATCHED  | G_PIECE                 |   4356 |      1 |     2   (0)|      4 |00:00:00.04 |   25091 |      0 |
|* 13 |      INDEX RANGE SCAN                    | PIE_REFDOSS             |   4356 |    183 |     1   (0)|   4356 |00:00:00.01 |    8885 |      0 |
|* 14 |    INDEX RANGE SCAN                      | G_PIECE$GPIHEURE        |      4 |      2 |     1   (0)|      4 |00:00:00.01 |      11 |      0 |
|* 15 |   TABLE ACCESS BY INDEX ROWID            | G_PIECE                 |      4 |      1 |     1   (0)|      4 |00:00:00.01 |      10 |      0 |
----------------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   6 - filter("D"."REFFACTOR"='INT00000')
   7 - access("D"."CATEGDOSS" LIKE 'DECOMPTE%')
       filter(("D"."CATEGDOSS" LIKE 'DECOMPTE%' AND "FTR_DECOMPTE"."ISCONTRACTVALID"("D"."REFDOSS")<>0 AND
              "FTR_DECOMPTE"."ISCONTRACTVALID"("D"."REFDOSS")<>2))
   8 - filter("C_PREF"."FG_SUPPR_AUTO_FUND"='O')
   9 - access("C_PREF"."REFDOSS"="D"."REFDOSS")
       filter("C_PREF"."REFDOSS" IS NOT NULL)
  12 - filter(("SC"."FG09"='O' AND (INTERNAL_FUNCTION("SC"."FG38") OR INTERNAL_FUNCTION("SC"."FG97") OR ("SC"."FG38"='F' AND
              "SC"."FG168"='O') OR ("SC"."FG97"='F' AND "SC"."FG168"='O')) AND DECODE("D"."CATEGDOSS",'DECOMPTE IMP','O',"SC"."FG09")='O' AND
              ("E"."GETDCLI"<>'C204' OR NVL("SC"."FG121",'N')<>'O')))
  13 - access("SC"."REFDOSS"="D"."REFDOSS" AND "SC"."TYPPIECE"='SOUS-CONTRAT')
  14 - access("F"."GPIHEURE"='INT00000')
  15 - filter(("F"."TYPPIECE"='FACTOR' AND ("SC"."FG97"='O' OR ("SC"."FG97"='F' AND "SC"."FG168"='O' AND INTERNAL_FUNCTION("F"."ST04")) OR
              ("SC"."FG97"='F' AND NVL("SC"."FG168",'N')='N' AND INTERNAL_FUNCTION("F"."ST05")) OR "SC"."FG38"='O' OR ("SC"."FG38"='F' AND
              "SC"."FG168"='O' AND INTERNAL_FUNCTION("F"."ST04")) OR ("SC"."FG38"='F' AND NVL("SC"."FG168",'N')='N' AND INTERNAL_FUNCTION("F"."ST05")))))
*/
/********************************OLD Metrics***************************************/

/********************************New SQL*******************************************/
-- AggrFunding 

SELECT *
  FROM (
SELECT  d.reffactor /* automatically injected */, 
       d.refdoss            statement_ref,                                            
       nvl(sc.mt50, 0)      threshold,                                                
       nvl(sc.fg97, 'N')    auto_fund,                                                
       nvl(sc.fg38, 'N')    auto_credit_fiu,                                          
       nvl( f.nb48, 'N')    fuc_not_impc_avail,                                       
       nvl(sc.fg168, 'N')   fx_processing,                                            
       f.st04               req_fx_proc,                                              
       f.st05               not_req_fx_proc,                                          
       nvl(sc.fg193, 'N')   excl_ext_util,                                            
       nvl(f.fg16, 'N')     real_avail_exclude_clgr,                                  
       d.reflot             contract_ref,                                             
       d.devise             statement_curr,
       ( select ftr_decompte.isContractValid(d.refdoss) from dual ) isContractValid
  FROM g_dossier d, g_piece sc, g_piece f                                             
 WHERE d.categdoss like 'DECOMPTE%'                                                   
   AND DECODE(d.categdoss, 'DECOMPTE IMP', 'O', sc.fg09) = 'O'                              /* reffactor condition */
   AND d.reffactor IN ('INT00000') 
   AND sc.refdoss                          = d.refdoss                                
   AND sc.typpiece                         = 'SOUS-CONTRAT'                           
   AND sc.fg09                             = 'O'                                      
   AND NOT EXISTS (                                                                   
                    SELECT 1                                                          
                      FROM user_cntr_pref c_pref                                      
                     WHERE c_pref.refdoss            = d.refdoss                      
                       AND c_pref.fg_suppr_auto_fund = 'O'                            
                  )                                                                   
   AND f.gpiheure                          = d.reffactor                              
   AND f.typpiece                          = 'FACTOR'                                 
   AND (                                                                              
           sc.fg97 = 'O'                                                              
        OR sc.fg97 = 'F' AND sc.fg168 = 'O'           AND f.st04 IN ('EOD','BOTH')    
        OR sc.fg97 = 'F' AND nvl(sc.fg168, 'N') = 'N' AND f.st05 IN ('EOD','BOTH')    
        OR sc.fg38 = 'O'                                                              
        OR sc.fg38 = 'F' AND sc.fg168 = 'O'           AND f.st04 IN ('EOD','BOTH')    
        OR sc.fg38 = 'F' AND nvl(sc.fg168, 'N') = 'N' AND f.st05 IN ('EOD','BOTH')    
        ) )
 WHERE isContractValid NOT IN (0, 2);


-- AutomaticFunding 

SELECT *
  FROM(       	
SELECT  d.reffactor /* automatically injected */, 
       d.refdoss            refdoss,                                                  
       nvl(sc.mt50, 0)      threshold,                                                
       nvl(sc.fg97, 'N')    auto_fund,                                                
       nvl(f.fg100, 'N')    curr_conversion,                                          
       nvl(sc.fg38, 'N')    auto_credit_fiu,                                          
       nvl( f.nb48, 'N')    fuc_not_impc_avail,                                       
       nvl(sc.fg168, 'N')   fx_processing,                                            
       f.st04               req_fx_proc,	                                             
       f.st05               not_req_fx_proc,                                           
       nvl(sc.fg193, 'N')   excl_ext_util,
       ( select ftr_decompte.isContractValid(d.refdoss) from dual ) isContractValid                                             
  FROM g_dossier d, g_piece sc, g_etude e, g_piece f                                  
 WHERE d.categdoss like 'DECOMPTE%'                                                   
   AND DECODE(d.categdoss, 'DECOMPTE IMP', 'O', sc.fg09) = 'O'                              /* reffactor condition */
   AND d.reffactor IN ('INT00000') 
   AND sc.refdoss = d.refdoss                                                         
   AND sc.typpiece = 'SOUS-CONTRAT'                                                   
   AND sc.fg09 = 'O'                                                                  
   AND NOT EXISTS ( SELECT 1                                                          
                     FROM user_cntr_pref c_pref                                       
                    WHERE c_pref.refdoss            = d.refdoss                       
                      AND c_pref.fg_suppr_auto_fund = 'O'                             
                 )                         
   AND (e.getdcli != 'C204' OR nvl(sc.fg121, 'N') != 'O')                             
   AND f.gpiheure = d.reffactor                                                       
   AND f.typpiece='FACTOR'                                                            
   AND (                                                                              
           sc.fg97 = 'O'                                                              
        OR sc.fg97 = 'F' AND sc.fg168 = 'O'           AND f.st04 IN ('EOD','BOTH')    
        OR sc.fg97 = 'F' AND nvl(sc.fg168, 'N') = 'N' AND f.st05 IN ('EOD','BOTH')    
        OR sc.fg38 = 'O'                                                              
        OR sc.fg38 = 'F' AND sc.fg168 = 'O'           AND f.st04 IN ('EOD','BOTH')    
        OR sc.fg38 = 'F' AND nvl(sc.fg168, 'N') = 'N' AND f.st05 IN ('EOD','BOTH')    
        ))
     WHERE isContractValid NOT IN (0, 2);

/********************************New SQL*******************************************/
/********************************New Metrics***************************************/
/*
-- AggrFunding 

Plan hash value: 989609279
------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                               | Name                    | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers |
------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                        |                         |      1 |        |    55 (100)|      4 |00:00:00.03 |   18621 |
|   1 |  FAST DUAL                              |                         |      4 |      1 |     2   (0)|      4 |00:00:00.01 |       0 |
|*  2 |  VIEW                                   |                         |      1 |      1 |    55   (0)|      4 |00:00:00.03 |   18621 |
|   3 |   NESTED LOOPS ANTI                     |                         |      1 |      1 |    53   (0)|      4 |00:00:00.03 |   18553 |
|   4 |    NESTED LOOPS                         |                         |      1 |      1 |    52   (0)|      4 |00:00:00.03 |   18549 |
|   5 |     NESTED LOOPS                        |                         |      1 |      3 |    51   (0)|      4 |00:00:00.03 |   18528 |
|*  6 |      TABLE ACCESS BY INDEX ROWID BATCHED| G_PIECE                 |      1 |      1 |    50   (0)|     36 |00:00:00.03 |   18387 |
|*  7 |       INDEX RANGE SCAN                  | GP_ST02_FUNC_IDX        |      1 |  32059 |     2   (0)|   5092 |00:00:00.01 |      27 |
|*  8 |      TABLE ACCESS BY INDEX ROWID        | G_DOSSIER               |     36 |      1 |     1   (0)|      4 |00:00:00.01 |     141 |
|*  9 |       INDEX UNIQUE SCAN                 | DOS_REFDOSS             |     36 |      1 |     1   (0)|     36 |00:00:00.01 |      40 |
|* 10 |     TABLE ACCESS BY INDEX ROWID BATCHED | G_PIECE                 |      4 |      1 |     1   (0)|      4 |00:00:00.01 |      21 |
|* 11 |      INDEX RANGE SCAN                   | G_PIECE$GPIHEURE        |      4 |      2 |     1   (0)|      4 |00:00:00.01 |      11 |
|* 12 |    TABLE ACCESS BY INDEX ROWID          | USER_CNTR_PREF          |      4 |      1 |     1   (0)|      0 |00:00:00.01 |       4 |
|* 13 |     INDEX UNIQUE SCAN                   | AK_KEY_REFPIEC_USER_CTR |      4 |      1 |     1   (0)|      2 |00:00:00.01 |       2 |
------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   2 - filter(("ISCONTRACTVALID"<>0 AND "ISCONTRACTVALID"<>2))
   6 - filter(("SC"."FG09"='O' AND (INTERNAL_FUNCTION("SC"."FG38") OR INTERNAL_FUNCTION("SC"."FG97") OR ("SC"."FG38"='F' AND
              "SC"."FG168"='O') OR ("SC"."FG97"='F' AND "SC"."FG168"='O'))))
   7 - access("SC"."TYPPIECE"='SOUS-CONTRAT')
   8 - filter(("D"."REFFACTOR"='INT00000' AND "D"."CATEGDOSS" LIKE 'DECOMPTE%' AND DECODE("D"."CATEGDOSS",'DECOMPTE
              IMP','O',"SC"."FG09")='O'))
   9 - access("SC"."REFDOSS"="D"."REFDOSS")
  10 - filter(("F"."TYPPIECE"='FACTOR' AND ("SC"."FG97"='O' OR ("SC"."FG97"='F' AND "SC"."FG168"='O' AND
              INTERNAL_FUNCTION("F"."ST04")) OR ("SC"."FG97"='F' AND NVL("SC"."FG168",'N')='N' AND INTERNAL_FUNCTION("F"."ST05")) OR
              "SC"."FG38"='O' OR ("SC"."FG38"='F' AND "SC"."FG168"='O' AND INTERNAL_FUNCTION("F"."ST04")) OR ("SC"."FG38"='F' AND
              NVL("SC"."FG168",'N')='N' AND INTERNAL_FUNCTION("F"."ST05")))))
  11 - access("F"."GPIHEURE"='INT00000')
  12 - filter("C_PREF"."FG_SUPPR_AUTO_FUND"='O')
  13 - access("C_PREF"."REFDOSS"="D"."REFDOSS")
       filter("C_PREF"."REFDOSS" IS NOT NULL)


-- AutomaticFunding 

Plan hash value: 738950158
-------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                | Name                    | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers |
-------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                         |                         |      1 |        |    58 (100)|      4 |00:00:00.04 |   18649 |
|   1 |  FAST DUAL                               |                         |      4 |      1 |     2   (0)|      4 |00:00:00.01 |       0 |
|*  2 |  VIEW                                    |                         |      1 |      1 |    58   (0)|      4 |00:00:00.04 |   18649 |
|   3 |   NESTED LOOPS                           |                         |      1 |      1 |    56   (0)|      4 |00:00:00.03 |   18581 |
|   4 |    NESTED LOOPS ANTI                     |                         |      1 |      1 |    53   (0)|      4 |00:00:00.03 |   18553 |
|   5 |     NESTED LOOPS                         |                         |      1 |      1 |    52   (0)|      4 |00:00:00.03 |   18549 |
|   6 |      NESTED LOOPS                        |                         |      1 |      3 |    51   (0)|      4 |00:00:00.03 |   18528 |
|*  7 |       TABLE ACCESS BY INDEX ROWID BATCHED| G_PIECE                 |      1 |      1 |    50   (0)|     36 |00:00:00.03 |   18387 |
|*  8 |        INDEX RANGE SCAN                  | GP_ST02_FUNC_IDX        |      1 |  32059 |     2   (0)|   5092 |00:00:00.01 |      27 |
|*  9 |       TABLE ACCESS BY INDEX ROWID        | G_DOSSIER               |     36 |      1 |     1   (0)|      4 |00:00:00.01 |     141 |
|* 10 |        INDEX UNIQUE SCAN                 | DOS_REFDOSS             |     36 |      1 |     1   (0)|     36 |00:00:00.01 |      40 |
|* 11 |      TABLE ACCESS BY INDEX ROWID BATCHED | G_PIECE                 |      4 |      1 |     1   (0)|      4 |00:00:00.01 |      21 |
|* 12 |       INDEX RANGE SCAN                   | G_PIECE$GPIHEURE        |      4 |      2 |     1   (0)|      4 |00:00:00.01 |      11 |
|* 13 |     TABLE ACCESS BY INDEX ROWID          | USER_CNTR_PREF          |      4 |      1 |     1   (0)|      0 |00:00:00.01 |       4 |
|* 14 |      INDEX UNIQUE SCAN                   | AK_KEY_REFPIEC_USER_CTR |      4 |      1 |     1   (0)|      2 |00:00:00.01 |       2 |
|* 15 |    TABLE ACCESS FULL                     | G_ETUDE                 |      4 |      1 |     3   (0)|      4 |00:00:00.01 |      28 |
-------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   2 - filter(("ISCONTRACTVALID"<>0 AND "ISCONTRACTVALID"<>2))
   7 - filter(("SC"."FG09"='O' AND (INTERNAL_FUNCTION("SC"."FG38") OR INTERNAL_FUNCTION("SC"."FG97") OR ("SC"."FG38"='F' AND
              "SC"."FG168"='O') OR ("SC"."FG97"='F' AND "SC"."FG168"='O'))))
   8 - access("SC"."TYPPIECE"='SOUS-CONTRAT')
   9 - filter(("D"."REFFACTOR"='INT00000' AND "D"."CATEGDOSS" LIKE 'DECOMPTE%' AND DECODE("D"."CATEGDOSS",'DECOMPTE
              IMP','O',"SC"."FG09")='O'))
  10 - access("SC"."REFDOSS"="D"."REFDOSS")
  11 - filter(("F"."TYPPIECE"='FACTOR' AND ("SC"."FG97"='O' OR ("SC"."FG97"='F' AND "SC"."FG168"='O' AND
              INTERNAL_FUNCTION("F"."ST04")) OR ("SC"."FG97"='F' AND NVL("SC"."FG168",'N')='N' AND INTERNAL_FUNCTION("F"."ST05")) OR
              "SC"."FG38"='O' OR ("SC"."FG38"='F' AND "SC"."FG168"='O' AND INTERNAL_FUNCTION("F"."ST04")) OR ("SC"."FG38"='F' AND
              NVL("SC"."FG168",'N')='N' AND INTERNAL_FUNCTION("F"."ST05")))))
  12 - access("F"."GPIHEURE"='INT00000')
  13 - filter("C_PREF"."FG_SUPPR_AUTO_FUND"='O')
  14 - access("C_PREF"."REFDOSS"="D"."REFDOSS")
       filter("C_PREF"."REFDOSS" IS NOT NULL)
  15 - filter(("E"."GETDCLI"<>'C204' OR NVL("SC"."FG121",'N')<>'O'))
*/
/********************************New Metrics***************************************/

/********************************Index statistics**********************************/

/********************************Other SQLs****************************************/          
/*

*/ 
/********************************Other SQLs****************************************/              
