/********************************************************************************
*********       E-mail subject: VWGSWEB-607
*********             Instance: PROD
*********          Description: 
Problem:
Slowness in DWH interface on PROD.

Analysis:
After the analyze the TOP SQL for the provided period was 9futp22zm9vju. 
Oracle was making bad execution plan for it, by starting the execution from non selective part and selecting a lot of data unnecessary.
The big amount of data comes from the view v_wsx_costInvoice. The solution here is to modify the view to use index DF_CLIREL.


Suggestion:
1. Please check is it functionally correct to modify view v_wsx_costInvoice by adding "df_cli = rel.er_cli" as shown in the New SQL section below.
2. Please check is it functionally correct to remove the "upper" ( colored in green in the New SQL section ) from v_wsx_costInvoice.

*********               SQL_ID: 9futp22zm9vju. 
*********      Program/Package: DWH interface
*********              Request: Martin Kosev
*********               Author: Dimitar Dimitrov
********* Received e-mail date: 12/12/2023
*********      Resolution date: 13/12/2023
*********  Trace old file here: \\epox\specifs\performance\tmp\
*********  Trace new file here:
***********************************************************************************/

/********************************OLD SQL*******************************************/
-- 9futp22zm9vju

var B0 VARCHAR2(128);
exec :B0 := '20231211191007';
var B1 VARCHAR2(128);
exec :B1 := 'VWGS DWH';
var B2 VARCHAR2(128);
exec :B2 := 'costinv';

SELECT rel . er_num AS InvNumberImx,
       0 AS Action,
       TO_CHAR(rel . dw_timestamp, 'YYYYMMDDHH24MISS') AS ActionDateTime,
       0 AS StatusCode,
       fac . refindividu AS FactorCode,
       DECODE(InvType, 'F', 0, 'A', 1) AS Type,
       fac . nom AS FactorName,
       cl . refext As ClientCode,
       cl . nom AS ClientName,
       cl . tva AS ClientVATNumber,
       costInv . InvNumber AS InvNumber,
       TO_CHAR(costInv . InvoiceDate, 'YYYY-MM-DD') AS InvDate,
       TO_CHAR(costInv . DueDate, 'YYYY-MM-DD') AS DueDate,
       TO_CHAR(costInv . StartInvoiceDate, 'YYYY-MM-DD') AS StartCalcDate,
       TO_CHAR(costInv . EndInvoiceDate, 'YYYY-MM-DD') AS EndCalcDate,
       TO_CHAR(rel . dw_timestamp, 'YYYY-MM-DD') AS CostCalcDate,
       costInv . InvoiceOrgCCY AS CurrencyCode,
       rel . er_devise AS BaseCurrencyCode,
       costInv . TotalAmountOrgCCYWithVAT AS Amount,
       costInv . TotalAmountEURWithVAT AS AmountBaseCurrency,
       costInv . VATRate AS VATRate,
       costInv . TotalVATAmountOrgCCY AS VATAmount,
       costInv . TotalVATAmountEUR AS VATAmountBaseCurrency,
       costInv . TotalAmountOrgCCYWithoutVAT AS TotCostVATExcluded,
       costInv . TotalAmountEURWithoutVAT AS TotCostVATExcludedCurrency,
       costInv . FUCAmountOrgCCYwithoutVAT AS TotInterestAmount,
       costInv . FUCAmountEURwithoutVAT AS TotInterestAmountCurrency,
       costInv . MRGAmountOrgCCYwithoutVAT AS TotMarginAmount,
       costInv . MRGAmountEURwithoutVAT AS TotMarginAmountCurrency,
       costInv . DCRAmountOrgCCYwithoutVAT AS TotDelcredereAmount,
       costInv . DCRAmountEURwithoutVAT AS TotDelcredereAmountCurrency,
       costInv . FACAmountOrgCCYwithoutVAT AS TotServiceAmount,
       costInv . FACAmountEURwithoutVAT AS TotServiceAmountCurrency
  FROM v_wsx_costInvoice costInv,
       f_entrel          rel,
       g_individu        cl,
       g_individu        fac
 WHERE rel . er_num = costInv . er_num
   AND rel . dw_timestamp > TO_DATE(:b0, 'YYYYMMDDHH24MISS') - 40
   AND cl . refindividu = rel . er_cli
   AND fac . refindividu = costInv . FactorRefindividu
   AND NOT EXISTS (SELECT 1
          FROM g_connu_ext_dwh
         WHERE extsystem = :b1
           AND tablename = :b2
           AND reference = rel . er_num);


/********************************OLD SQL*******************************************/
/********************************OLD Metrics***************************************/
/*
MODULE                    SQL_ID         PLAN_HASH SID    SERIAL# EVENT                          FROM                           TO                                 ACTIVE NUMBER_OF_EXECUTIONS PERC
------------------------- ------------- ---------- ------ ------- ------------------------------ ------------------------------ ------------------------------ ---------- -------------------- ------
wsx_dwh_cost              9futp22zm9vju   97053267 306    9113    db file sequential read        2023/12/12 12:39:07            2023/12/12 12:46:37                   310                    1 34%
wsx_dwh_assfrm            3k8q6j9nzw984 2395842693 306    3980    db file sequential read        2023/12/12 12:30:57            2023/12/12 12:34:57                   250                    1 27%
wsx_dwh_cost              9futp22zm9vju   97053267 306    9113    db file parallel read          2023/12/12 12:38:57            2023/12/12 12:44:57                    90                    1 10%
wsx_dwh_finelem                                    306    34899   ON CPU                         2023/12/12 12:35:57            2023/12/12 12:38:27                    80                    1 9%
wsx_dwh_cost              9futp22zm9vju   97053267 306    9113    ON CPU                         2023/12/12 12:40:47            2023/12/12 12:46:07                    40                    1 4%
wsx_dwh_cost              9futp22zm9vju   97053267 306    9113    db file scattered read         2023/12/12 12:39:37            2023/12/12 12:45:47                    30                    1 3%
wsx_dwh_finelem           3urnd7fr82wqm 2618322136 306    34899   db file sequential read        2023/12/12 12:37:57            2023/12/12 12:38:17                    30                    1 3%
wsx_dwh_finelem           ghy18p3u409gq 1862653001 306    34899   direct path read               2023/12/12 12:36:17            2023/12/12 12:36:57                    30                    1 3%
wsx_dwh_finelem           ghy18p3u409gq 1862653001 306    34899   db file scattered read         2023/12/12 12:37:17            2023/12/12 12:37:27                    20                    1 2%
wsx_dwh_extpmtdt          5pstc5kvugjrz  667074742 306    20146   db file scattered read         2023/12/12 12:46:57            2023/12/12 12:46:57                    10                    1 1%
wsx_imx2sap2              a3r3z4twm2f1m 1715538367 869    3430    ON CPU                         2023/12/12 12:35:47            2023/12/12 12:35:47                    10                    1 1%
wsx_dwh_extpmtdt          5pstc5kvugjrz  667074742 306    20146   ON CPU                         2023/12/12 12:46:47            2023/12/12 12:46:47                    10                    1 1%


MODULE                    SQL_ID         PLAN_HASH SID    SERIAL# EVENT                          FROM                           TO                                 ACTIVE NUMBER_OF_EXECUTIONS PERC
------------------------- ------------- ---------- ------ ------- ------------------------------ ------------------------------ ------------------------------ ---------- -------------------- ------
wsx_dwh_cost              9futp22zm9vju   97053267 306    9113    db file sequential read        2023/12/12 12:39:07            2023/12/12 12:46:37                   310       1 34%
wsx_dwh_assfrm            3k8q6j9nzw984 2395842693 306    3980    db file sequential read        2023/12/12 12:30:57            2023/12/12 12:34:57                   250       1 28%
wsx_dwh_cost              9futp22zm9vju   97053267 306    9113    db file parallel read          2023/12/12 12:38:57            2023/12/12 12:44:57                    90       1 10%
wsx_dwh_finelem                                    306    34899   ON CPU                         2023/12/12 12:35:57            2023/12/12 12:38:27                    80       1 9%
wsx_dwh_cost              9futp22zm9vju   97053267 306    9113    ON CPU                         2023/12/12 12:40:47            2023/12/12 12:46:07                    40       1 4%
wsx_dwh_finelem           ghy18p3u409gq 1862653001 306    34899   direct path read               2023/12/12 12:36:17            2023/12/12 12:36:57                    30       1 3%
wsx_dwh_cost              9futp22zm9vju   97053267 306    9113    db file scattered read         2023/12/12 12:39:37            2023/12/12 12:45:47                    30       1 3%
wsx_dwh_finelem           3urnd7fr82wqm 2618322136 306    34899   db file sequential read        2023/12/12 12:37:57            2023/12/12 12:38:17                    30       1 3%
wsx_dwh_finelem           ghy18p3u409gq 1862653001 306    34899   db file scattered read         2023/12/12 12:37:17            2023/12/12 12:37:27                    20       1 2%
wsx_dwh_extpmtdt          5pstc5kvugjrz  667074742 306    20146   db file scattered read         2023/12/12 12:46:57            2023/12/12 12:46:57                    10       1 1%
wsx_dwh_extpmtdt          5pstc5kvugjrz  667074742 306    20146   ON CPU                         2023/12/12 12:46:47            2023/12/12 12:46:47                    10       1 1%


MODULE                    SQL_ID         PLAN_HASH SID    SERIAL# EVENT                          FROM                           TO                                 ACTIVE NUMBER_OF_EXECUTIONS PERC
------------------------- ------------- ---------- ------ ------- ------------------------------ ------------------------------ ------------------------------ ---------- -------------------- ------
wsx_dwh_cost              9futp22zm9vju   97053267 306    9113                                   2023/12/12 12:38:57            2023/12/12 12:46:37                   470       1 52%
wsx_dwh_assfrm            3k8q6j9nzw984 2395842693 306    3980    db file sequential read        2023/12/12 12:30:57            2023/12/12 12:34:57                   250       1 28%
wsx_dwh_finelem           ghy18p3u409gq 1862653001 306    34899                                  2023/12/12 12:35:57            2023/12/12 12:37:37                   110       1 12%
wsx_dwh_finelem           3urnd7fr82wqm 2618322136 306    34899                                  2023/12/12 12:37:47            2023/12/12 12:38:17                    40       1 4%
wsx_dwh_extpmtdt          5pstc5kvugjrz  667074742 306    20146                                  2023/12/12 12:46:47            2023/12/12 12:46:57                    20       1 2%
wsx_dwh_finelem           4rma6cxs7acsb 3455982703 306    34899   ON CPU                         2023/12/12 12:38:27            2023/12/12 12:38:27                    10       1 1%


-- 9futp22zm9vju

Plan hash value: 97053267
-------------------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                 | Name                      | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  |
-------------------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                          |                           |      1 |        | 30446 (100)|      0 |00:00:00.01 |       0 |      0 |
|   1 |  SORT AGGREGATE                           |                           |      0 |      1 |            |      0 |00:00:00.01 |       0 |      0 |
|*  2 |   TABLE ACCESS BY INDEX ROWID BATCHED     | F_DETFAC                  |      0 |    114 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*  3 |    INDEX SKIP SCAN                        | DF_CLIREL                 |      0 |     17 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|   4 |  SORT AGGREGATE                           |                           |      0 |      1 |            |      0 |00:00:00.01 |       0 |      0 |
|*  5 |   TABLE ACCESS BY INDEX ROWID BATCHED     | F_DETFAC                  |      0 |    114 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*  6 |    INDEX SKIP SCAN                        | DF_CLIREL                 |      0 |     17 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|   7 |  SORT AGGREGATE                           |                           |      0 |      1 |            |      0 |00:00:00.01 |       0 |      0 |
|*  8 |   TABLE ACCESS BY INDEX ROWID BATCHED     | F_DETFAC                  |      0 |    114 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*  9 |    INDEX SKIP SCAN                        | DF_CLIREL                 |      0 |     17 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|  10 |  SORT AGGREGATE                           |                           |      0 |      1 |            |      0 |00:00:00.01 |       0 |      0 |
|* 11 |   TABLE ACCESS BY INDEX ROWID BATCHED     | F_DETFAC                  |      0 |    114 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 12 |    INDEX SKIP SCAN                        | DF_CLIREL                 |      0 |     17 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|  13 |  SORT AGGREGATE                           |                           |      0 |      1 |            |      0 |00:00:00.01 |       0 |      0 |
|* 14 |   TABLE ACCESS BY INDEX ROWID BATCHED     | F_DETFAC                  |      0 |    114 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 15 |    INDEX SKIP SCAN                        | DF_CLIREL                 |      0 |     17 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|  16 |  SORT AGGREGATE                           |                           |      0 |      1 |            |      0 |00:00:00.01 |       0 |      0 |
|* 17 |   TABLE ACCESS BY INDEX ROWID BATCHED     | F_DETFAC                  |      0 |    114 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 18 |    INDEX SKIP SCAN                        | DF_CLIREL                 |      0 |     17 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|  19 |  SORT AGGREGATE                           |                           |      0 |      1 |            |      0 |00:00:00.01 |       0 |      0 |
|* 20 |   TABLE ACCESS BY INDEX ROWID BATCHED     | F_DETFAC                  |      0 |    114 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 21 |    INDEX SKIP SCAN                        | DF_CLIREL                 |      0 |     17 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|  22 |  SORT AGGREGATE                           |                           |      0 |      1 |            |      0 |00:00:00.01 |       0 |      0 |
|* 23 |   TABLE ACCESS BY INDEX ROWID BATCHED     | F_DETFAC                  |      0 |    114 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 24 |    INDEX SKIP SCAN                        | DF_CLIREL                 |      0 |     17 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|  25 |  HASH GROUP BY                            |                           |      1 |    606 | 30446   (1)|      0 |00:00:00.01 |       0 |      0 |
|  26 |   NESTED LOOPS                            |                           |      1 |    606 | 29989   (1)|      0 |00:00:00.01 |       0 |      0 |
|  27 |    NESTED LOOPS                           |                           |      1 |    606 | 29989   (1)|      0 |00:00:00.01 |       0 |      0 |
|  28 |     NESTED LOOPS                          |                           |      1 |    606 | 29983   (1)|      0 |00:00:00.01 |       0 |      0 |
|* 29 |      HASH JOIN RIGHT ANTI                 |                           |      1 |    607 | 29977   (1)|      0 |00:00:00.01 |       0 |      0 |
|* 30 |       INDEX RANGE SCAN                    | PK_G_CONNU_EXT_DWH        |      1 |    287K|    17   (0)|   7879 |00:00:00.01 |      49 |      0 |
|* 31 |       HASH JOIN                           |                           |      1 |  60696 | 28800   (1)|  26248 |00:03:04.17 |     589K|    353K|
|  32 |        TABLE ACCESS BY INDEX ROWID BATCHED| F_ENTREL                  |      1 |     50 |     1   (0)|     35 |00:00:00.01 |      22 |      0 |
|* 33 |         INDEX RANGE SCAN                  | F_ENTREL_DWT              |      1 |     50 |     1   (0)|     35 |00:00:00.01 |       2 |      0 |
|  34 |        NESTED LOOPS                       |                           |      1 |     10M| 28778   (1)|   5877K|00:03:03.29 |     589K|    354K|
|  35 |         NESTED LOOPS                      |                           |      1 |     44M| 28778   (1)|   6772K|00:00:11.19 |   22350 |  19207 |
|  36 |          INDEX FULL SCAN                  | G_DOSSIER_RL_CD_RD_RF_IDX |      1 |    884 |     1   (0)|    444 |00:00:00.01 |       5 |      2 |
|* 37 |          INDEX RANGE SCAN                 | FD_DF_DOS_DF_STAT_IDX     |    444 |  49783 |     2   (0)|   6772K|00:00:10.59 |   22345 |  19205 |
|* 38 |         TABLE ACCESS BY INDEX ROWID       | F_DETFAC                  |   6772K|  11908 |    33   (0)|   5877K|00:02:50.41 |     567K|    334K|
|  39 |      TABLE ACCESS BY INDEX ROWID          | G_INDIVIDU                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 40 |       INDEX UNIQUE SCAN                   | IND_REFINDIV              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 41 |     INDEX UNIQUE SCAN                     | IND_REFINDIV              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|  42 |    TABLE ACCESS BY INDEX ROWID            | G_INDIVIDU                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
-------------------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   2 - filter("DF_ANN_DT" IS NULL)
   3 - access("DF_REL"=:B1)
       filter(("DF_REL"=:B1 AND UPPER("DF_NOM") LIKE 'FUC%'))
   5 - filter("DF_ANN_DT" IS NULL)
   6 - access("DF_REL"=:B1)
       filter(("DF_REL"=:B1 AND UPPER("DF_NOM") LIKE 'FUC%'))
   8 - filter("DF_ANN_DT" IS NULL)
   9 - access("DF_REL"=:B1)
       filter(("DF_REL"=:B1 AND UPPER("DF_NOM") LIKE 'MRG%'))
  11 - filter("DF_ANN_DT" IS NULL)
  12 - access("DF_REL"=:B1)
       filter(("DF_REL"=:B1 AND UPPER("DF_NOM") LIKE 'MRG%'))
  14 - filter("DF_ANN_DT" IS NULL)
  15 - access("DF_REL"=:B1)
       filter(("DF_REL"=:B1 AND UPPER("DF_NOM") LIKE 'DCR%'))
  17 - filter("DF_ANN_DT" IS NULL)
  18 - access("DF_REL"=:B1)
       filter(("DF_REL"=:B1 AND UPPER("DF_NOM") LIKE 'DCR%'))
  20 - filter("DF_ANN_DT" IS NULL)
  21 - access("DF_REL"=:B1)
       filter(("DF_REL"=:B1 AND UPPER("DF_NOM") LIKE 'FAC%'))
  23 - filter("DF_ANN_DT" IS NULL)
  24 - access("DF_REL"=:B1)
       filter(("DF_REL"=:B1 AND UPPER("DF_NOM") LIKE 'FAC%'))
  29 - access("REFERENCE"="ER_NUM")
  30 - access("EXTSYSTEM"=:B1 AND "TABLENAME"=:B2)
  31 - access("DET"."DF_REL"="REL"."ER_NUM")
  33 - access("DW_TIMESTAMP">TO_DATE(:B0,'YYYYMMDDHH24MISS')-40)
  37 - access("DOS"."REFDOSS"="DET"."DF_DOS")
  38 - filter(("DET"."DF_REL" IS NOT NULL AND INTERNAL_FUNCTION("DET"."DF_NOM") AND "DET"."DF_ANN_DT" IS NULL))
  40 - access("FAC"."REFINDIVIDU"="DOS"."REFFACTOR")
  41 - access("CL"."REFINDIVIDU"="ER_CLI")
*/
/********************************OLD Metrics***************************************/

/********************************New SQL*******************************************/

-- No change in SQL 9futp22zm9vju, only change in V_WSX_COSTINVOICE view.

-- View V_WSX_COSTINVOICE

 CREATE OR REPLACE VIEW V_WSX_COSTINVOICE ("FACTORREFINDIVIDU", "ER_NUM", "INVTYPE", "INVNUMBER", "INVOICEDATE", "DUEDATE", "STARTINVOICEDATE", "ENDINVOICEDATE", "INVOICEORGCCY", "VATRATE", "TOTALAMOUNTORGCCYWITHVAT", "TOTALAMOUNTEURWITHVAT", "TOTALVATAMOUNTORGCCY", "TOTALVATAMOUNTEUR", "TOTALAMOUNTORGCCYWITHOUTVAT", "TOTALAMOUNTEURWITHOUTVAT", "MRGAMOUNTORGCCYWITHVAT", "MRGAMOUNTORGCCYWITHOUTVAT", "MRGAMOUNTEURWITHVAT", "MRGAMOUNTEURWITHOUTVAT", "FUCAMOUNTORGCCYWITHVAT", "FUCAMOUNTORGCCYWITHOUTVAT", "FUCAMOUNTEURWITHVAT", "FUCAMOUNTEURWITHOUTVAT", "FACAMOUNTORGCCYWITHVAT", "FACAMOUNTORGCCYWITHOUTVAT", "FACAMOUNTEURWITHVAT", "FACAMOUNTEURWITHOUTVAT", "DCRAMOUNTORGCCYWITHVAT", "DCRAMOUNTORGCCYWITHOUTVAT", "DCRAMOUNTEURWITHVAT", "DCRAMOUNTEURWITHOUTVAT", "EXCHANGERATE") AS
  SELECT             dos.reffactor as FactorRefindividu,
                   rel.er_num                                          AS er_Num,
                   rel.Er_Val                                          AS InvType,
                   --DECODE(rel.er_val, 'F', rel.er_refext1, 'A', rel.er_refext2)  AS InvNumber,
                   nvl(rel.er_refext1, rel.er_refext2) AS InvNumber,
                   rel.er_dat_dt                AS InvoiceDate,
                   rel.er_reg_dt                AS DueDate,
                   rel.er_dat_deb               AS StartInvoiceDate,
                   rel.er_dat_fin               AS EndInvoiceDate,
                   MAX(det.df_devise_con)                              AS InvoiceOrgCcy,
                   MAX(det.df_taux_tva)                                AS VATRate,
                   SUM(DECODE(det.DF_SEN, 'C', -1, 1)*det.df_monttc_con)                    AS TotalAmountOrgCCYwithVAT,
                   SUM(DECODE(det.DF_SEN, 'C', -1, 1)*det.df_monttc_mvt)                    AS TotalAmountEURwithVAT,
                   SUM(DECODE(det.DF_SEN, 'C', -1, 1)*det.df_monttc_con - DECODE(det.DF_SEN, 'C', -1, 1)*det.df_monht_con) AS TotalVATAmountOrgCCY,
                   SUM(DECODE(det.DF_SEN, 'C', -1, 1)*det.df_monttc_mvt - DECODE(det.DF_SEN, 'C', -1, 1)*det.df_monht_mvt) AS TotalVATAmountEUR,
                   SUM(DECODE(det.DF_SEN, 'C', -1, 1)*det.df_monht_con)                    AS TotalAmountOrgCCYwithoutVAT,
                   SUM(DECODE(det.DF_SEN, 'C', -1, 1)*det.df_monht)                        AS TotalAmountEURwithoutVAT,
                   (select  nvl(SUM(DECODE(DF_SEN, 'C', -1, 1)*df_monttc_con),0)  from f_detfac where upper(df_nom) like 'MRG%' AND df_ann_dt is null and df_rel = rel.er_num and df_cli = rel.er_cli ) as MRGAmountOrgCCYwithVAT,
                   (select  nvl(SUM(DECODE(DF_SEN, 'C', -1, 1)*df_monht_con),0)  from f_detfac where upper(df_nom) like 'MRG%' AND df_ann_dt is null and df_rel = rel.er_num and df_cli = rel.er_cli ) as MRGAmountOrgCCYwithoutVAT,
                   (select  nvl(SUM(DECODE(DF_SEN, 'C', -1, 1)*df_monttc_mvt),0)  from f_detfac where upper(df_nom) like 'MRG%' AND df_ann_dt is null and df_rel = rel.er_num and df_cli = rel.er_cli ) as MRGAmountEURwithVAT,
                   (select  nvl(SUM(DECODE(DF_SEN, 'C', -1, 1)*df_monht_mvt),0)  from f_detfac where upper(df_nom) like 'MRG%' AND df_ann_dt is null and df_rel = rel.er_num and df_cli = rel.er_cli ) as MRGAmountEURwithoutVAT,
                   (select  nvl(SUM(DECODE(DF_SEN, 'C', -1, 1)*df_monttc_con),0)  from f_detfac where upper(df_nom) like 'FUC%' AND df_ann_dt is null and df_rel = rel.er_num and df_cli = rel.er_cli ) as FUCAmountOrgCCYwithVAT,
                   (select  nvl(SUM(DECODE(DF_SEN, 'C', -1, 1)*df_monht_con),0)  from f_detfac where upper(df_nom) like 'FUC%' AND df_ann_dt is null and df_rel = rel.er_num and df_cli = rel.er_cli ) as FUCAmountOrgCCYwithoutVAT,
                   (select  nvl(SUM(DECODE(DF_SEN, 'C', -1, 1)*df_monttc_mvt),0)  from f_detfac where upper(df_nom) like 'FUC%' AND df_ann_dt is null and df_rel = rel.er_num and df_cli = rel.er_cli ) as FUCAmountEURwithVAT,
                   (select  nvl(SUM(DECODE(DF_SEN, 'C', -1, 1)*df_monht_mvt),0)  from f_detfac where upper(df_nom) like 'FUC%' AND df_ann_dt is null and df_rel = rel.er_num and df_cli = rel.er_cli ) as FUCAmountEURwithoutVAT,
                   (select  nvl(SUM(DECODE(DF_SEN, 'C', -1, 1)*df_monttc_con),0)  from f_detfac where upper(df_nom) like 'FAC%' AND df_ann_dt is null and df_rel = rel.er_num and df_cli = rel.er_cli ) as FACAmountOrgCCYwithVAT,
                   (select  nvl(SUM(DECODE(DF_SEN, 'C', -1, 1)*df_monht_con),0)  from f_detfac where upper(df_nom) like 'FAC%' AND df_ann_dt is null and df_rel = rel.er_num and df_cli = rel.er_cli ) as FACAmountOrgCCYwithoutVAT,
                   (select  nvl(SUM(DECODE(DF_SEN, 'C', -1, 1)*df_monttc_mvt),0)  from f_detfac where upper(df_nom) like 'FAC%' AND df_ann_dt is null and df_rel = rel.er_num and df_cli = rel.er_cli ) as FACAmountEURwithVAT,
                   (select  nvl(SUM(DECODE(DF_SEN, 'C', -1, 1)*df_monht_mvt),0)  from f_detfac where upper(df_nom) like 'FAC%' AND df_ann_dt is null and df_rel = rel.er_num and df_cli = rel.er_cli ) as FACAmountEURwithoutVAT,
                   (select  nvl(SUM(DECODE(DF_SEN, 'C', -1, 1)*df_monttc_con),0)  from f_detfac where upper(df_nom) like 'DCR%' AND df_ann_dt is null and df_rel = rel.er_num and df_cli = rel.er_cli ) as DCRAmountOrgCCYwithVAT,
                   (select  nvl(SUM(DECODE(DF_SEN, 'C', -1, 1)*df_monht_con),0)  from f_detfac where upper(df_nom) like 'DCR%' AND df_ann_dt is null and df_rel = rel.er_num and df_cli = rel.er_cli ) as DCRAmountOrgCCYwithoutVAT,
                   (select  nvl(SUM(DECODE(DF_SEN, 'C', -1, 1)*df_monttc_mvt),0)  from f_detfac where upper(df_nom) like 'DCR%' AND df_ann_dt is null and df_rel = rel.er_num and df_cli = rel.er_cli ) as DCRAmountEURwithVAT,
                   (select  nvl(SUM(DECODE(DF_SEN, 'C', -1, 1)*df_monht_mvt),0)  from f_detfac where upper(df_nom) like 'DCR%' AND df_ann_dt is null and df_rel = rel.er_num and df_cli = rel.er_cli ) as DCRAmountEURwithoutVAT,
                   (select  max(df_taux)  from f_detfac where  df_ann_dt is null and df_rel = rel.er_num and DF_SEN = 'D' and df_cli = rel.er_cli ) as ExchangeRate
                  --MAX(det.df_taux)  AS ExchangeRate
              FROM f_entrel    rel,
                   f_detfac    det,
                   g_dossier dos
             WHERE -- rel.er_num ='A9000566' AND
               det.df_rel = rel.er_num
               AND det.df_cli = rel.er_cli
               AND det.df_ann_dt is null
               AND det.df_nom IN ('MRG', 'FUC', 'FAC', 'DCRDF','mrg', 'fuc', 'fac', 'dcrdf','MRGC', 'FUCC', 'FACC', 'DCRC')
               AND dos.refdoss = det.df_dos
               GROUP BY rel.er_num,
                      rel.er_val,
                      rel.er_refext1,
                      rel.er_refext2,
                      rel.er_dat_dt,
                      rel.er_reg_dt,
                      rel.er_dat_deb,
                      rel.er_dat_fin,
                      rel.er_devise,
                      dos.reffactor,
                      rel.er_cli;
/********************************New SQL*******************************************/
/********************************New Metrics***************************************/
/*
Plan hash value: 108926468
-------------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                  | Name               | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  |
-------------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                           |                    |      1 |        |    74 (100)|      0 |00:00:00.01 |      57 |     14 |
|   1 |  SORT AGGREGATE                            |                    |      0 |      1 |            |      0 |00:00:00.01 |       0 |      0 |
|*  2 |   TABLE ACCESS BY INDEX ROWID BATCHED      | F_DETFAC           |      0 |      3 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*  3 |    INDEX RANGE SCAN                        | DF_CLIREL          |      0 |     31 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|   4 |  SORT AGGREGATE                            |                    |      0 |      1 |            |      0 |00:00:00.01 |       0 |      0 |
|*  5 |   TABLE ACCESS BY INDEX ROWID BATCHED      | F_DETFAC           |      0 |      3 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*  6 |    INDEX RANGE SCAN                        | DF_CLIREL          |      0 |     31 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|   7 |  SORT AGGREGATE                            |                    |      0 |      1 |            |      0 |00:00:00.01 |       0 |      0 |
|*  8 |   TABLE ACCESS BY INDEX ROWID BATCHED      | F_DETFAC           |      0 |      3 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*  9 |    INDEX RANGE SCAN                        | DF_CLIREL          |      0 |     31 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|  10 |  SORT AGGREGATE                            |                    |      0 |      1 |            |      0 |00:00:00.01 |       0 |      0 |
|* 11 |   TABLE ACCESS BY INDEX ROWID BATCHED      | F_DETFAC           |      0 |      3 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 12 |    INDEX RANGE SCAN                        | DF_CLIREL          |      0 |     31 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|  13 |  SORT AGGREGATE                            |                    |      0 |      1 |            |      0 |00:00:00.01 |       0 |      0 |
|* 14 |   TABLE ACCESS BY INDEX ROWID BATCHED      | F_DETFAC           |      0 |      3 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 15 |    INDEX RANGE SCAN                        | DF_CLIREL          |      0 |     31 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|  16 |  SORT AGGREGATE                            |                    |      0 |      1 |            |      0 |00:00:00.01 |       0 |      0 |
|* 17 |   TABLE ACCESS BY INDEX ROWID BATCHED      | F_DETFAC           |      0 |      3 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 18 |    INDEX RANGE SCAN                        | DF_CLIREL          |      0 |     31 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|  19 |  SORT AGGREGATE                            |                    |      0 |      1 |            |      0 |00:00:00.01 |       0 |      0 |
|* 20 |   TABLE ACCESS BY INDEX ROWID BATCHED      | F_DETFAC           |      0 |      3 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 21 |    INDEX RANGE SCAN                        | DF_CLIREL          |      0 |     31 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|  22 |  SORT AGGREGATE                            |                    |      0 |      1 |            |      0 |00:00:00.01 |       0 |      0 |
|* 23 |   TABLE ACCESS BY INDEX ROWID BATCHED      | F_DETFAC           |      0 |      3 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 24 |    INDEX RANGE SCAN                        | DF_CLIREL          |      0 |     31 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|  25 |  HASH GROUP BY                             |                    |      1 |     17 |    74   (2)|      0 |00:00:00.01 |      57 |     14 |
|  26 |   NESTED LOOPS                             |                    |      1 |     17 |     6   (0)|      0 |00:00:00.01 |      57 |     14 |
|  27 |    NESTED LOOPS                            |                    |      1 |     17 |     6   (0)|      0 |00:00:00.01 |      57 |     14 |
|  28 |     NESTED LOOPS                           |                    |      1 |     17 |     5   (0)|      0 |00:00:00.01 |      57 |     14 |
|  29 |      NESTED LOOPS                          |                    |      1 |     17 |     4   (0)|      0 |00:00:00.01 |      57 |     14 |
|  30 |       NESTED LOOPS                         |                    |      1 |      1 |     3   (0)|      0 |00:00:00.01 |      57 |     14 |
|  31 |        NESTED LOOPS ANTI                   |                    |      1 |      1 |     2   (0)|      0 |00:00:00.01 |      57 |     14 |
|  32 |         TABLE ACCESS BY INDEX ROWID BATCHED| F_ENTREL           |      1 |     50 |     1   (0)|     35 |00:00:00.01 |      22 |     10 |
|* 33 |          INDEX RANGE SCAN                  | F_ENTREL_DWT       |      1 |     50 |     1   (0)|     35 |00:00:00.01 |       2 |      2 |
|* 34 |         INDEX UNIQUE SCAN                  | PK_G_CONNU_EXT_DWH |     35 |    287K|     1   (0)|     35 |00:00:00.01 |      35 |      4 |
|  35 |        TABLE ACCESS BY INDEX ROWID         | G_INDIVIDU         |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 36 |         INDEX UNIQUE SCAN                  | IND_REFINDIV       |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 37 |       TABLE ACCESS BY INDEX ROWID BATCHED  | F_DETFAC           |      0 |     34 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 38 |        INDEX RANGE SCAN                    | DF_CLIREL          |      0 |    333 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|  39 |      TABLE ACCESS BY INDEX ROWID           | G_DOSSIER          |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 40 |       INDEX UNIQUE SCAN                    | DOS_REFDOSS        |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 41 |     INDEX UNIQUE SCAN                      | IND_REFINDIV       |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|  42 |    TABLE ACCESS BY INDEX ROWID             | G_INDIVIDU         |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
-------------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   2 - filter("DF_ANN_DT" IS NULL)
   3 - access("DF_CLI"=:B1 AND "DF_REL"=:B2)
       filter(UPPER("DF_NOM") LIKE 'FUC%')
   5 - filter("DF_ANN_DT" IS NULL)
   6 - access("DF_CLI"=:B1 AND "DF_REL"=:B2)
       filter(UPPER("DF_NOM") LIKE 'FUC%')
   8 - filter("DF_ANN_DT" IS NULL)
   9 - access("DF_CLI"=:B1 AND "DF_REL"=:B2)
       filter(UPPER("DF_NOM") LIKE 'MRG%')
  11 - filter("DF_ANN_DT" IS NULL)
  12 - access("DF_CLI"=:B1 AND "DF_REL"=:B2)
       filter(UPPER("DF_NOM") LIKE 'MRG%')
  14 - filter("DF_ANN_DT" IS NULL)
  15 - access("DF_CLI"=:B1 AND "DF_REL"=:B2)
       filter(UPPER("DF_NOM") LIKE 'DCR%')
  17 - filter("DF_ANN_DT" IS NULL)
  18 - access("DF_CLI"=:B1 AND "DF_REL"=:B2)
       filter(UPPER("DF_NOM") LIKE 'DCR%')
  20 - filter("DF_ANN_DT" IS NULL)
  21 - access("DF_CLI"=:B1 AND "DF_REL"=:B2)
       filter(UPPER("DF_NOM") LIKE 'FAC%')
  23 - filter("DF_ANN_DT" IS NULL)
  24 - access("DF_CLI"=:B1 AND "DF_REL"=:B2)
       filter(UPPER("DF_NOM") LIKE 'FAC%')
  33 - access("DW_TIMESTAMP">TO_DATE(:B0,'YYYYMMDDHH24MISS')-40)
  34 - access("EXTSYSTEM"=:B1 AND "TABLENAME"=:B2 AND "REFERENCE"="ER_NUM")
  36 - access("CL"."REFINDIVIDU"="ER_CLI")
  37 - filter("DET"."DF_ANN_DT" IS NULL)
  38 - access("DET"."DF_CLI"="REL"."ER_CLI" AND "DET"."DF_REL"="REL"."ER_NUM")
       filter(("DET"."DF_REL" IS NOT NULL AND INTERNAL_FUNCTION("DET"."DF_NOM")))
  40 - access("DOS"."REFDOSS"="DET"."DF_DOS")
  41 - access("FAC"."REFINDIVIDU"="DOS"."REFFACTOR")
*/
/********************************New Metrics***************************************/

/********************************Index statistics**********************************/

/********************************Other SQLs****************************************/          
/*

*/ 
/********************************Other SQLs****************************************/              
