/********************************************************************************
*********       E-mail subject: LBPDEV-7012
*********             Instance: LAGOVAL
*********          Description: 
Problem:
SQL query was provided as slow from the BE log.

Analysis:
After the manual execution of the query on LAGOVAL, we found that the query doesn't start from the date, which is the most selective part. Instead, it starts
from the montant column in table T_ELEMENTS and searches for some range between two values, which in this case leads to the selection over 50k rows. We added hints to force Oracle to start
the query execution from table g_encaissement from the date ( NVL(en.dtencaiss_dt, en.dtreception_dt) ), but please keep in mind that this optimization is only for this variant of the query,
so don't apply it in other variants.


Suggestion:
Please change the query as it is shown below, but please keep in mind that this optimization is only for this variant of the query.

*********               SQL_ID: 07c84bzcnk15k
*********      Program/Package: 
*********              Request: Moez Sokrati 
*********               Author: Dimitar Dimitrov
********* Received e-mail date: 19/08/2024
*********      Resolution date: 19/08/2024
*********  Trace old file here: \\epox\specifs\performance\tmp\
*********  Trace new file here:
***********************************************************************************/

/********************************OLD SQL*******************************************/

VAR B1 VARCHAR2(32);
EXEC :B1 := 'AN'; 
VAR B2 NUMBER;
EXEC :B2 := 2300; 
VAR B3 NUMBER;
EXEC :B3 := 4000; 
VAR B4 VARCHAR2(32);
EXEC :B4 := '2024-08-01';
VAR B5 VARCHAR2(32);
EXEC :B5 := '2024-08-08';
VAR B6 NUMBER;
EXEC :B6 := 201; 
VAR B7 NUMBER;
EXEC :B7 := 1; 
 
 
SELECT *
  FROM (SELECT /*+ first_rows(201)*/
         foo.*, ROWNUM rnum
          FROM (SELECT referEncaiss referEncaiss,
                       typeElem typeElem,
                       (SELECT chemin
                          FROM v_tdomaine
                         WHERE TYPE = 'NAM_COLLECTE'
                           AND abrev = SUBSTR(compostage, 1, 3)
                           AND langue = :B1
                           AND ROWNUM = 1) bookCode,
                       SUM(amountAllocatedPaymentAccount) OVER() totalAmountMouvements,
                       receptionDate receptionDate,
                       dtconfirm_dt dtconfirm_dt,
                       clientName clientName,
                       vcsNumber vcsNumber,
                       fg19 fg19,
                       slipNumber slipNumber,
                       externalCase externalCase,
                       paymentSource paymentSource,
                       encaissAmount encaissAmount,
                       displayPaymentType displayPaymentType,
                       additionalCommunication additionalCommunication,
                       algorithmResult algorithmResult,
                       paymentType paymentType,
                       paymentIdentification paymentIdentification,
                       amountAllocatedPayment amountAllocatedPayment,
                       internalCaseReference internalCaseReference,
                       COUNT(1) OVER() totalNumberMouvements,
                       balance balance,
                       payerReference payerReference,
                       imxUserId imxUserId,
                       payerName payerName,
                       caseManagerName caseManagerName,
                       batchSearch batchSearch,
                       transStatus transStatus,
                       paymentStatus paymentStatus,
                       cancelationDate cancelationDate,
                       comments comments,
                       amountAllocatedPaymentAccount amountAllocatedPaymentAccount,
                       paymentReference paymentReference,
                       stampingNumber stampingNumber,
                       crmManager crmManager,
                       masterStampingNumber masterStampingNumber,
                       paymentTitle paymentTitle,
                       initialAmount initialAmount,
                       displayPaymentMethod displayPaymentMethod,
                       paymentMethod paymentMethod,
                       messages messages,
                       paymentDate paymentDate,
                       paymentCurrency paymentCurrency,
                       secondComment secondComment,
                       dtcompt dtcompt,
                       balanceCurrency balanceCurrency
                  FROM (SELECT main_query.refer referEncaiss,
                               main_query.refdossier internalCaseReference,
                               main_query.montant_dos encaissAmount,
                               main_query.date1 paymentDate,
                               main_query.refindividu payerReference,
                               main_query.date2 receptionDate,
                               main_query.type_enc paymentType,
                               main_query.type_enc_aff displayPaymentType,
                               main_query.libelle paymentTitle,
                               main_query.nom_payeur payerName,
                               main_query.mont_mvt amountAllocatedPayment,
                               main_query.mont_enc amountAllocatedPaymentAccount,
                               main_query.mont_init initialAmount,
                               main_query.dev_init paymentCurrency,
                               main_query.slipNumber,
                               main_query.num_vcs vcsNumber,
                               main_query.moyp paymentMethod,
                               main_query.moyp_trad displayPaymentMethod,
                               main_query.num_cheque paymentReference,
                               main_query.annul_dt cancelationDate,
                               main_query.typeelem typeElem,
                               main_query.source_pmt paymentSource,
                               main_query.rangmt imxUserId,
                               main_query.monref,
                               main_query.dtconfirm_dt,
                               main_query.clientName,
                               main_query.fg19,
                               main_query.refer_doss externalCase,
                               main_query.dtcompt,
                               main_query.namcol_ref stampingNumber,
                               gp.login caseManagerName,
                               nc.dtlot batchSearch,
                               nc.comm paymentIdentification,
                               nc.comm2 secondComment,
                               nc.master_compostage masterStampingNumber,
                               nc.compostage,
                               nc.devise,
                               nc.etat transStatus,
                               v2.valeur_trad algorithmResult,
                               nc.comments,
                               DECODE(To_Char(nc.messages), NULL, 'N', 'O') additionalCommunication,
                               crm.login crmManager,
                               v3.valeur_trad paymentStatus,
                               bal.refelem refelemBal,
                               bal.refdoss refdossBal,
                               bal.typeelem typeelemBal,
                               bal.libelle libelleBal,
                               bal.montant_dos montant_dosBal,
                               nc.montant montantNc,
                               nc.messages messages,
                               CASE
                                 WHEN main_query.refdossier IS NULL THEN
                                  nc.montant
                                 WHEN upper(bal.libelle) LIKE
                                      'DELAI AVANT ENCAISSEMENT%' THEN
                                  (SELECT NVL(abs(bal.montant_dos), 0) -
                                          NVL((SELECT ftr_match.partprelettrpmt(bal.refelem,
                                                                               bal.refdoss,
                                                                               bal.typeelem)
                                                FROM dual),
                                              0)
                                     FROM dual)
                                 ELSE
                                  (SELECT NVL(ABS(bal.montant_dos), 0) -
                                          NVL((SELECT SUM(NVL(ABS(montant_dos), 0))
                                                FROM g_venelem
                                               WHERE refencaiss = bal.refelem
                                                 AND refdoss = bal.refdoss
                                                 AND typencaiss = bal.typeelem),
                                              0)
                                     FROM dual)
                               END balance,
                               DECODE(main_query.refdossier,
                                      NULL,
                                      nc.devise,
                                      (SELECT devise
                                         FROM g_dossier
                                        WHERE refdoss = main_query.refdossier)) balanceCurrency
                          FROM (SELECT en.refencaiss REFER,
                                       t.REFDOSS REFDOSSIER,
                                       ven.montant_dos montant_dos,
                                       t.dtassoc_dt DATE1,
                                       NVL(en.dtreception_dt, en.dtencaiss_dt) DATE2,
                                       'ENCAISSEMENT DEBITEUR' TYPE_ENC,
                                       'Debtor Collection' TYPE_ENC_AFF,
                                       NVL(v1.valeur_trad, EN.libelle) libelle,
                                       DECODE(i.prenom,
                                              NULL,
                                              i.nom,
                                              i.nom || ' ' || i.prenom) NOM_PAYEUR,
                                       I.refindividu,
                                       ven.montant_mvt MONT_MVT,
                                       t.montant MONT_ENC,
                                       NVL(DECODE(nc.signe, 1, -1, 1) *
                                           nc.montant,
                                           en.montant_mvt) MONT_INIT,
                                       NVL(nc.devise, en.devise_mvt) dev_INIT,
                                       EN.no_ordre slipNumber,
                                       EN.num_vcs num_vcs,
                                       EN.moyenpaimt MOYP,
                                       moy.valeur_trad MOYP_TRAD,
                                       EN.numchq NUM_CHEQUE,
                                       Nvl(en.dtannul_dt, en.dtimpaye_dt) annul_dt,
                                       t.TYPEELEM typeelem,
                                       'ENCAISS' source_pmt,
                                       d.rangmt rangmt,
                                       (SELECT ctr.monref
                                          FROM g_dossier ctr,
                                               g_dossier dcpt,
                                               g_dossier cpt
                                         WHERE ctr.refdoss = dcpt.reflot
                                           AND dcpt.refdoss = cpt.reflot
                                           AND cpt.refdoss = d.refdoss
                                        UNION
                                        SELECT ctr.monref
                                          FROM g_dossier ctr, g_dossier dcpt
                                         WHERE ctr.refdoss = dcpt.reflot
                                           AND dcpt.refdoss = d.refdoss
                                           AND dcpt.categdoss LIKE 'DECOMPTE%'
                                        UNION
                                        SELECT ctr.monref
                                          FROM g_dossier ctr
                                         WHERE ctr.refdoss = d.refdoss
                                           AND ctr.categdoss LIKE 'CONTRAT%') monref,
                                       en.DTCONFIRM_DT DTCONFIRM_DT,
                                       CL.nom clientName,
                                       ACL.fg19,
                                       Nvl(D.ancrefdoss, t.refdoss) refer_doss,
                                       t.dtsaisie dtcompt,
                                       en.lieupaimt namcol_ref,
                                       en.refrepres,
                                       en.dtimpaye_dt
                                  FROM T_ELEMENTS t,
                                       G_ENCAISSEMENT en,
                                       g_ventilenc ven,
                                       G_INDIVIDU i,
                                       g_dossier D,
                                       t_intervenants tcl,
                                       g_individu cl,
                                       g_accords acl,
                                       nam_collecte nc,
                                       (SELECT valeur,
                                               MAX(valeur_trad) valeur_trad
                                          FROM v_tdomaine
                                         WHERE type = 'libfds'
                                           AND langue = NVL(:B1, 'FR')
                                         GROUP BY valeur) v1,
                                       (SELECT valeur,
                                               MAX(valeur_trad) valeur_trad
                                          FROM v_tdomaine
                                         WHERE type = 'MOYENPAIMT'
                                           AND langue = :B1
                                         GROUP BY valeur) moy
                                 WHERE t.refelem = en.REFENCAISS
                                   AND t.refdoss = D.refdoss
                                   AND acl.refindividu(+) = cl.refindividu
                                   AND t.refelem = ven.refencaiss(+)
                                   AND t.refdoss = ven.refdoss(+)
                                   AND t.TYPEELEM in ('en', 'vd')
                                   AND en.traite NOT IN ('9')
                                   AND en.TYPENCAISS in
                                       ('e_saencaiss', 'e_savdirect')
                                   AND EN.lieupaimt = nc.compostage(+)
                                   AND EN.moyenpaimt = moy.valeur(+)
                                   AND EN.libelle = v1.valeur(+)
                                   AND EN.REFPAYEUR = I.REFINDIVIDU
                                   AND tcl.refdoss = D.refdoss
                                   AND tcl.reftype = 'CL'
                                   AND tcl.refindividu = cl.refindividu
                                   AND NOT exists
                                 (SELECT 1
                                          FROM aggreg_t_ecrdos_nmp tnmp
                                         WHERE TNMP.refelem = ven.refencaiss
                                           AND tnmp.refdoss = ven.refdoss
                                           AND tnmp.balance_dcpt < 0)
                                   AND t.montant BETWEEN :B2 AND :B3
                                   AND NVL(en.dtencaiss_dt, en.dtreception_dt) >= to_date(:B4, 'YYYY-MM-DD')
                                   AND NVL(en.dtencaiss_dt, en.dtreception_dt) <= to_date(:B5, 'YYYY-MM-DD')
                                UNION ALL
                                SELECT /*+ index(TNMP aggreg_t_ecrdos_nmp$bal) */
                                 EN.refencaiss REFER,
                                 VEN.refdoss REFDOSSIER,
                                 VEN.montant_dos montant_dos,
                                 t.dtassoc_dt DATE1,
                                 NVL(en.dtreception_dt, en.dtencaiss_dt) DATE2,
                                 'RECOUVREMENT DEBITEUR NON LETTRE' TYPE_ENC,
                                 'Debtor collection not fully matched' TYPE_ENC_AFF,
                                 NVL(v1.valeur_trad, EN.libelle) libelle,
                                 i.nom || ' ' || i.prenom NOM_PAYEUR,
                                 I.refindividu,
                                 VEN.montant_mvt MONT_MVT,
                                 t.montant MONT_ENC,
                                 NVL(DECODE(nc.signe, 1, -1, 1) * nc.montant,
                                     en.montant_mvt) MONT_INIT,
                                 NVL(nc.devise, en.devise_mvt) dev_INIT,
                                 EN.no_ordre slipNumber,
                                 EN.num_vcs num_vcs,
                                 EN.moyenpaimt MOYP,
                                 moy.valeur_trad MOYP_TRAD,
                                 EN.numchq NUM_CHEQUE,
                                 Nvl(en.dtannul_dt, en.dtimpaye_dt) annul_dt,
                                 t.TYPEELEM typeelem,
                                 'ENCAISS' source_pmt,
                                 d.rangmt rangmt,
                                 (SELECT ctr.monref
                                    FROM g_dossier ctr,
                                         g_dossier deco,
                                         g_dossier cpt
                                   WHERE ctr.refdoss = deco.reflot
                                     AND deco.refdoss = cpt.reflot
                                     AND cpt.refdoss = d.refdoss
                                     AND cpt.refdoss = nc.refdoss
                                  UNION
                                  SELECT ctr.monref
                                    FROM g_dossier ctr, g_dossier dcpt
                                   WHERE ctr.refdoss = dcpt.reflot
                                     AND dcpt.refdoss = nc.refdoss
                                     AND dcpt.categdoss LIKE 'DECOMPTE%'
                                  UNION
                                  SELECT ctr.monref
                                    FROM g_dossier ctr
                                   WHERE ctr.refdoss = nc.refdoss
                                     AND ctr.categdoss LIKE 'CONTRAT%') monref,
                                 en.DTCONFIRM_DT DTCONFIRM_DT,
                                 CL.nom clientName,
                                 ACL.fg19,
                                 Nvl(D.ancrefdoss, t.refdoss) refer_doss,
                                 t.dtsaisie dtcompt,
                                 en.lieupaimt namcol_ref,
                                 en.refrepres,
                                 en.dtimpaye_dt
                                  FROM g_ventilenc VEN,
                                       g_encaissement EN,
                                       nam_collecte NC,
                                       aggreg_t_ecrdos_nmp TNMP,
                                       g_dossier D,
                                       T_ELEMENTS t,
                                       G_INDIVIDU i,
                                       t_intervenants tcl,
                                       g_individu cl,
                                       g_accords acl,
                                       (SELECT valeur,
                                               MAX(valeur_trad) valeur_trad
                                          FROM v_tdomaine
                                         WHERE type = 'libfds'
                                           AND langue = NVL(:B1, 'FR')
                                         GROUP BY valeur) v1,
                                       (SELECT valeur,
                                               MAX(valeur_trad) valeur_trad
                                          FROM v_tdomaine
                                         WHERE type = 'MOYENPAIMT'
                                           AND langue = :B1
                                         GROUP BY valeur) moy
                                 WHERE t.refelem = en.REFENCAISS
                                   AND t.refdoss = D.refdoss
                                   AND acl.refindividu(+) = cl.refindividu
                                   AND t.refelem = ven.refencaiss(+)
                                   AND t.refdoss = ven.refdoss(+)
                                   AND EN.moyenpaimt = moy.valeur(+)
                                   AND EN.libelle = v1.valeur(+)
                                   AND EN.traite = '2'
                                   AND NC.refer(+) = EN.refencaiss
                                   AND NC.compostage(+) = EN.lieupaimt
                                   AND VEN.refencaiss = TNMP.refelem
                                   AND VEN.refdoss = TNMP.refdoss
                                   AND TNMP.balance_dcpt < 0
                                   AND t.typeelem in ('en', 'vd')
                                   AND en.traite NOT IN ('9')
                                   AND en.typencaiss in
                                       ('e_saencaiss', 'e_savirmt')
                                   AND EN.REFPAYEUR = I.REFINDIVIDU
                                   AND tcl.refdoss = D.refdoss
                                   AND tcl.reftype = 'CL'
                                   AND tcl.refindividu = cl.refindividu
                                   AND t.montant BETWEEN :B2 AND :B3
                                   AND NVL(en.dtencaiss_dt, en.dtreception_dt) >= to_date(:B4, 'YYYY-MM-DD')
                                   AND NVL(en.dtencaiss_dt, en.dtreception_dt) <= to_date(:B5, 'YYYY-MM-DD')
                                UNION ALL
                                SELECT e.ee_num refer,
                                       E.EE_DOS refdossier,
                                       NULL montant_dos,
                                       NVL(E.EE_findtech_DT, E.ee_dat_dt) date1,
                                       NULL date2,
                                       'DISPONIBLE' type_enc,
                                       'Availability' type_enc_aff,
                                       NULL libelle,
                                       DECODE(i.prenom,
                                              NULL,
                                              i.nom,
                                              i.nom || ' ' || i.prenom) NOM_PAYEUR,
                                       I.refindividu,
                                       DE_MONTTC_mvt MONT_MVT,
                                       DE_MONTTC MONT_ENC,
                                       EE_CHE_MVT MONT_INIT,
                                       EN.devise_mvt dev_INIT,
                                       EN.no_ordre slipNumber,
                                       E.num_vcs num_vcs,
                                       E.EE_REGL MOYP,
                                       moy.valeur_trad MOYP_TRAD,
                                       E.EE_NOC NUM_CHEQUE,
                                       E.ee_ann_dt annul_dt,
                                       NULL typeelem,
                                       'ENTENR_DOS' source_pmt,
                                       d.rangmt rangmt,
                                       (SELECT ctr.monref
                                          FROM g_dossier ctr,
                                               g_dossier dcpt,
                                               g_dossier cpt
                                         WHERE ctr.refdoss = dcpt.reflot
                                           AND dcpt.refdoss = cpt.reflot
                                           AND cpt.refdoss = d.refdoss
                                        UNION
                                        SELECT ctr.monref
                                          FROM g_dossier ctr, g_dossier dcpt
                                         WHERE ctr.refdoss = dcpt.reflot
                                           AND dcpt.refdoss = d.refdoss
                                           AND dcpt.categdoss LIKE 'DECOMPTE%'
                                        UNION
                                        SELECT ctr.monref
                                          FROM g_dossier ctr
                                         WHERE ctr.refdoss = d.refdoss
                                           AND ctr.categdoss LIKE 'CONTRAT%') monref,
                                       f_Detenr.dtconfirm_dt dtconfirm_dt,
                                       cl.nom clientName,
                                       acl.fg19,
                                       Nvl(D.ancrefdoss, t.refdoss) refer_doss,
                                       t.dtsaisie dtcompt,
                                       E.ee_finfact namcol_ref,
                                       en.refrepres,
                                       en.dtimpaye_dt
                                  FROM f_detenr,
                                       f_entenr E,
                                       G_INDIVIDU I,
                                       f_parenr,
                                       g_encaissement EN,
                                       g_dossier D,
                                       t_intervenants tcl,
                                       g_individu cl,
                                       g_accords acl,
                                       t_elements t,
                                       (SELECT valeur,
                                               MAX(valeur_trad) valeur_trad
                                          FROM v_tdomaine
                                         WHERE type = 'MOYENPAIMT'
                                           AND langue = :B1
                                         GROUP BY valeur) moy
                                 WHERE E.EE_NUM = DE_NUM
                                   AND EN.typencaiss = 'Enregistrement'
                                   AND EN.refpiece = E.ee_num
                                   AND en.refdoss = d.refdoss
                                   AND de_nom = pe_nom
                                   AND T.refelem = E.ee_num
                                   AND E.EE_REGL = moy.valeur(+)
                                   AND T.typeelem = 'eg'
                                   AND de_nte IS NOT NULL
                                   AND E.EE_REFTIE = I.REFINDIVIDU
                                   AND tcl.refdoss = D.refdoss
                                   AND tcl.reftype = 'CL'
                                   AND tcl.refindividu = cl.refindividu
                                   AND acl.refindividu(+) = cl.refindividu
                                   AND E.ee_maitre IS NULL
                                   AND pe_cpt like 'KMTR%'
                                   AND de_monttc BETWEEN :B2 AND :B3
                                   AND e.ee_findtech_dt >= to_date(:B4, 'YYYY-MM-DD')
                                   AND e.ee_findtech_dt <= to_date(:B5, 'YYYY-MM-DD')
                                UNION ALL
                                SELECT E.ee_num REFER,
                                       'REPART CHQ' REFDOSSIER,
                                       NULL montant_dos,
                                       E.ee_findtech_dt DATE1,
                                       NULL DATE2,
                                       'DISPONIBLE' TYPE_ENC,
                                       TRIM('Availability') TYPE_ENC_AFF,
                                       NULL libelle,
                                       TRIM(DECODE(i.prenom,
                                                   NULL,
                                                   i.nom,
                                                   i.nom || ' ' || i.prenom)) NOM_PAYEUR,
                                       I.refindividu,
                                       SUM(e_dos.ee_che_mvt) MONT_MVT,
                                       SUM(e_dos.ee_che) MONT_ENC,
                                       SUM(e_dos.ee_che_mvt) MONT_INIT,
                                       MAX(en.devise_mvt) dev_INIT,
                                       MAX(en.no_ordre) slipNumber,
                                       E.num_vcs num_vcs,
                                       E.ee_regl MOYP,
                                       moy.valeur_trad MOYP_TRAD,
                                       E.ee_noc NUM_CHEQUE,
                                       E.ee_ann_dt annul_dt,
                                       NULL typeelem,
                                       'ENTENR_GL' source_pmt,
                                       E.ee_refperso rangmt,
                                       ctr.monref monref,
                                       NULL DTCONFIRM_DT,
                                       'see_conf_cl' clientName,
                                       'see_cod_fg19' fg19,
                                       null refer_doss,
                                       MAX(t.dtsaisie) dtcompt,
                                       E.ee_finfact namcol_ref,
                                       en.refrepres,
                                       en.dtimpaye_dt
                                  FROM F_ENTENR E,
                                       F_ENTENR e_dos,
                                       G_INDIVIDU I,
                                       g_encaissement EN,
                                       t_elements t,
                                       (SELECT valeur,
                                               MAX(valeur_trad) valeur_trad
                                          FROM v_tdomaine
                                         WHERE type = 'MOYENPAIMT'
                                           AND langue = :B1
                                         GROUP BY valeur) moy,
                                       (SELECT cpt.refdoss, ctr.monref
                                          FROM g_dossier ctr,
                                               g_dossier dcpt,
                                               g_dossier cpt
                                         WHERE ctr.refdoss = dcpt.reflot
                                           AND dcpt.refdoss = cpt.reflot
                                        UNION
                                        SELECT dcpt.refdoss, ctr.monref
                                          FROM g_dossier ctr, g_dossier dcpt
                                         WHERE ctr.refdoss = dcpt.reflot
                                           AND dcpt.categdoss LIKE 'DECOMPTE%'
                                        UNION
                                        SELECT ctr.refdoss, ctr.monref
                                          FROM g_dossier ctr
                                         WHERE ctr.categdoss LIKE 'CONTRAT%') ctr
                                 WHERE NVL(E.ee_dos, '#') = 'GLOBAL'
                                   AND NVL(E.ee_maitre, '#') = 'REGLEMENT'
                                   AND E.ee_num = e_dos.ee_maitre
                                   AND en.refdoss = e_dos.ee_dos
                                   AND en.refpiece = e_dos.ee_num
                                   AND en.typencaiss = 'Enregistrement'
                                   AND e_dos.ee_dos = t.refdoss
                                   AND e_dos.ee_num = t.refelem
                                   AND E.ee_regl = moy.valeur(+)
                                   AND en.refdoss = ctr.refdoss
                                   AND T.typeelem = 'eg'
                                   AND e.ee_reftie = i.refindividu
                                   AND e.ee_findtech_dt >= to_date(:B4, 'YYYY-MM-DD')
                                   AND e.ee_findtech_dt <= to_date(:B5, 'YYYY-MM-DD')
                                 GROUP BY E.ee_num,
                                          'REPART CHQ',
                                          NULL,
                                          E.ee_findtech_dt,
                                          NULL,
                                          'DISPONIBLE',
                                          TRIM('Availability'),
                                          NULL,
                                          TRIM(DECODE(i.prenom,
                                                      NULL,
                                                      i.nom,
                                                      i.nom || ' ' || i.prenom)),
                                          I.refindividu,
                                          E.num_vcs,
                                          E.ee_regl,
                                          moy.valeur_trad,
                                          E.ee_noc,
                                          E.ee_ann_dt,
                                          NULL,
                                          'ENTENR_GL',
                                          E.ee_refperso,
                                          ctr.monref,
                                          NULL,
                                          'see_conf_cl',
                                          'see_cod_fg19',
                                          null,
                                          E.ee_finfact,
                                          en.refrepres,
                                          en.dtimpaye_dt
                                HAVING 1 = 1 AND SUM(e_dos.ee_che) >= :B2 AND SUM(e_dos.ee_che) <= :B3) main_query,
                               nam_collecte nc,
                               g_personnel gp,
                               t_elements bal,
                               (SELECT abrev, MAX(valeur_trad) valeur_trad
                                  FROM v_tdomaine
                                 WHERE type = 'DV_IDENT_CODES'
                                   AND langue = :B1
                                 GROUP BY abrev) v2,
                               (SELECT abrev, MAX(valeur_trad) valeur_trad
                                  FROM v_tdomaine
                                 WHERE type = 'STATUT_PAIEMENT'
                                   AND langue = :B1
                                 GROUP BY abrev) v3,
                               g_personnel crm
                         WHERE main_query.namcol_ref = nc.compostage(+)
                           AND main_query.rangmt = gp.refperso(+)
                           AND main_query.monref = crm.refperso(+)
                           AND nc.traite = v2.abrev(+)
                           AND main_query.refer = bal.refelem(+)
                           AND main_query.refdossier = bal.refdoss(+)
                           AND main_query.typeelem = bal.typeelem(+)
                           AND DECODE(main_query.refrepres,
                                      NULL,
                                      DECODE(main_query.dtimpaye_dt,
                                             NULL,
                                             'ENCAISSE',
                                             'IMPAYE'),
                                      'REPRESENTE') = v3.abrev(+))
                 WHERE 1 = 1
                 ORDER BY paymentType,
                          DECODE(internalCaseReference,
                                 'REPART CHQ',
                                 'REPART CHQ',
                                 TO_NUMBER(internalCaseReference)),
                          paymentDate,
                          internalCaseReference) foo
         WHERE ROWNUM <= :B6)
 WHERE 1 = 1
   AND rnum >= :B7;
/********************************OLD SQL*******************************************/
/********************************OLD Metrics***************************************/
/*
Plan hash value: 4067519299
------------------------------------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                                    | Name                    | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  |
------------------------------------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                                             |                         |      1 |        |   133 (100)|     13 |00:04:52.99 |     146K|  49529 |
|*  1 |  COUNT STOPKEY                                               |                         |     13 |        |            |     13 |00:00:00.01 |      36 |      0 |
|   2 |   VIEW                                                       | V_TDOMAINE              |     13 |      5 |     5   (0)|     13 |00:00:00.01 |      36 |      0 |
|   3 |    UNION-ALL                                                 |                         |     13 |        |            |     13 |00:00:00.01 |      36 |      0 |
|*  4 |     FILTER                                                   |                         |     13 |        |            |      0 |00:00:00.01 |       0 |      0 |
|   5 |      TABLE ACCESS BY INDEX ROWID BATCHED                     | V_DOMAINE               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*  6 |       INDEX RANGE SCAN                                       | DOM_TYPABREV            |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*  7 |     FILTER                                                   |                         |     13 |        |            |     13 |00:00:00.01 |      36 |      0 |
|   8 |      TABLE ACCESS BY INDEX ROWID BATCHED                     | V_DOMAINE               |     13 |      1 |     1   (0)|     13 |00:00:00.01 |      36 |      0 |
|*  9 |       INDEX RANGE SCAN                                       | DOM_TYPABREV            |     13 |      1 |     1   (0)|     13 |00:00:00.01 |      23 |      0 |
|* 10 |     FILTER                                                   |                         |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  11 |      TABLE ACCESS BY INDEX ROWID BATCHED                     | V_DOMAINE               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 12 |       INDEX RANGE SCAN                                       | DOM_TYPABREV            |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 13 |     FILTER                                                   |                         |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  14 |      TABLE ACCESS BY INDEX ROWID BATCHED                     | V_DOMAINE               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 15 |       INDEX RANGE SCAN                                       | DOM_TYPABREV            |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 16 |     FILTER                                                   |                         |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  17 |      TABLE ACCESS BY INDEX ROWID BATCHED                     | V_DOMAINE               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 18 |       INDEX RANGE SCAN                                       | DOM_TYPABREV            |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|  19 |  FAST DUAL                                                   |                         |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|  20 |  FAST DUAL                                                   |                         |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|  21 |   SORT AGGREGATE                                             |                         |     13 |      1 |            |     13 |00:00:00.01 |      23 |      3 |
|* 22 |    TABLE ACCESS BY INDEX ROWID BATCHED                       | G_VENELEM               |     13 |      1 |     1   (0)|      0 |00:00:00.01 |      23 |      3 |
|* 23 |     INDEX RANGE SCAN                                         | VEN_ENCAIS              |     13 |      1 |     1   (0)|      0 |00:00:00.01 |      23 |      3 |
|  24 |   FAST DUAL                                                  |                         |     13 |      1 |     2   (0)|     13 |00:00:00.01 |       0 |      0 |
|  25 |  TABLE ACCESS BY INDEX ROWID                                 | G_DOSSIER               |     13 |      1 |     1   (0)|     13 |00:00:00.01 |      48 |      0 |
|* 26 |   INDEX UNIQUE SCAN                                          | DOS_REFDOSS             |     13 |      1 |     1   (0)|     13 |00:00:00.01 |      22 |      0 |
|* 27 |  VIEW                                                        |                         |      1 |      4 |   133   (4)|     13 |00:04:52.99 |     146K|  49529 |
|* 28 |   COUNT STOPKEY                                              |                         |      1 |        |            |     13 |00:04:52.99 |     146K|  49529 |
|  29 |    VIEW                                                      |                         |      1 |      4 |   133   (4)|     13 |00:04:52.99 |     146K|  49529 |
|  30 |     WINDOW SORT                                              |                         |      1 |      4 |   133   (4)|     13 |00:04:52.98 |     146K|  49526 |
|* 31 |      HASH JOIN OUTER                                         |                         |      1 |      4 |   107   (4)|     13 |00:04:52.98 |     146K|  49526 |
|* 32 |       HASH JOIN OUTER                                        |                         |      1 |      4 |   101   (3)|     13 |00:04:52.98 |     146K|  49525 |
|  33 |        NESTED LOOPS OUTER                                    |                         |      1 |      4 |    95   (3)|     13 |00:04:52.95 |     146K|  49469 |
|  34 |         NESTED LOOPS OUTER                                   |                         |      1 |      4 |    94   (3)|     13 |00:04:52.89 |     146K|  49465 |
|  35 |          NESTED LOOPS OUTER                                  |                         |      1 |      4 |    93   (3)|     13 |00:04:52.89 |     146K|  49465 |
|  36 |           NESTED LOOPS OUTER                                 |                         |      1 |      4 |    92   (3)|     13 |00:04:52.89 |     146K|  49465 |
|  37 |            VIEW                                              |                         |      1 |      4 |    91   (3)|     13 |00:04:52.89 |     146K|  49465 |
|  38 |             UNION-ALL                                        |                         |      1 |        |            |     13 |00:04:52.89 |     146K|  49465 |
|  39 |              SORT UNIQUE                                     |                         |      0 |      3 |     6   (0)|      0 |00:00:00.01 |       0 |      0 |
|  40 |               UNION-ALL                                      |                         |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  41 |                NESTED LOOPS                                  |                         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|  42 |                 NESTED LOOPS                                 |                         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|  43 |                  NESTED LOOPS                                |                         |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 44 |                   INDEX RANGE SCAN                           | DOS_REFDOSS_REFLOT_IDX  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 45 |                   INDEX RANGE SCAN                           | DOS_REFDOSS_REFLOT_IDX  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 46 |                  INDEX UNIQUE SCAN                           | DOS_REFDOSS             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|  47 |                 TABLE ACCESS BY INDEX ROWID                  | G_DOSSIER               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|  48 |                NESTED LOOPS                                  |                         |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 49 |                 TABLE ACCESS BY INDEX ROWID                  | G_DOSSIER               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 50 |                  INDEX UNIQUE SCAN                           | DOS_REFDOSS             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|  51 |                 TABLE ACCESS BY INDEX ROWID                  | G_DOSSIER               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 52 |                  INDEX UNIQUE SCAN                           | DOS_REFDOSS             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 53 |                TABLE ACCESS BY INDEX ROWID                   | G_DOSSIER               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 54 |                 INDEX UNIQUE SCAN                            | DOS_REFDOSS             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 55 |              FILTER                                          |                         |      1 |        |            |      0 |00:03:38.25 |   75520 |  32665 |
|  56 |               NESTED LOOPS OUTER                             |                         |      1 |      1 |    20   (0)|      0 |00:03:38.25 |   75520 |  32665 |
|  57 |                NESTED LOOPS OUTER                            |                         |      1 |      1 |    15   (0)|      0 |00:03:38.25 |   75520 |  32665 |
|  58 |                 NESTED LOOPS OUTER                           |                         |      1 |      1 |    10   (0)|      0 |00:03:38.25 |   75520 |  32665 |
|  59 |                  NESTED LOOPS                                |                         |      1 |      1 |     9   (0)|      0 |00:03:38.25 |   75520 |  32665 |
|  60 |                   NESTED LOOPS                               |                         |      1 |      1 |     8   (0)|      0 |00:03:38.25 |   75520 |  32665 |
|  61 |                    NESTED LOOPS                              |                         |      1 |      3 |     7   (0)|      0 |00:03:38.25 |   75520 |  32665 |
|  62 |                     NESTED LOOPS                             |                         |      1 |      3 |     6   (0)|      0 |00:03:38.25 |   75520 |  32665 |
|  63 |                      NESTED LOOPS OUTER                      |                         |      1 |      3 |     5   (0)|      0 |00:03:38.25 |   75520 |  32665 |
|  64 |                       NESTED LOOPS                           |                         |      1 |      3 |     4   (0)|      0 |00:03:38.25 |   75520 |  32665 |
|  65 |                        NESTED LOOPS ANTI                     |                         |      1 |      3 |     3   (0)|   3882 |00:03:29.59 |   63894 |  31810 |
|  66 |                         NESTED LOOPS OUTER                   |                         |      1 |      5 |     2   (0)|   4079 |00:03:29.29 |   61687 |  31774 |
|* 67 |                          TABLE ACCESS BY INDEX ROWID BATCHED | T_ELEMENTS              |      1 |      5 |     1   (0)|   4079 |00:03:24.98 |   53544 |  31380 |
|* 68 |                           INDEX RANGE SCAN                   | TE_MONTANT              |      1 |     63 |     1   (0)|  56712 |00:00:01.91 |     175 |    175 |
|  69 |                          TABLE ACCESS BY INDEX ROWID         | G_VENTILENC             |   4079 |      1 |     1   (0)|   4079 |00:00:04.30 |    8143 |    394 |
|* 70 |                           INDEX UNIQUE SCAN                  | VENT_REFDOSS            |   4079 |      1 |     1   (0)|   4079 |00:00:01.14 |    4064 |    107 |
|* 71 |                         INDEX RANGE SCAN                     | PK_AGGREG_T_ECRDOS_NMP  |   4079 |   4219 |     1   (0)|    197 |00:00:00.29 |    2207 |     36 |
|* 72 |                        TABLE ACCESS BY INDEX ROWID           | G_ENCAISSEMENT          |   3882 |      1 |     1   (0)|      0 |00:00:08.66 |   11626 |    855 |
|* 73 |                         INDEX UNIQUE SCAN                    | REFENCAISS              |   3882 |      1 |     1   (0)|   3881 |00:00:02.03 |    7756 |    196 |
|  74 |                       TABLE ACCESS BY INDEX ROWID            | NAM_COLLECTE            |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 75 |                        INDEX UNIQUE SCAN                     | COLCOMPOSTAGE           |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|  76 |                      TABLE ACCESS BY INDEX ROWID             | G_INDIVIDU              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 77 |                       INDEX UNIQUE SCAN                      | IND_REFINDIV            |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|  78 |                     TABLE ACCESS BY INDEX ROWID              | G_DOSSIER               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 79 |                      INDEX UNIQUE SCAN                       | DOS_REFDOSS             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 80 |                    INDEX RANGE SCAN                          | INT_REFDOSS             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|  81 |                   TABLE ACCESS BY INDEX ROWID                | G_INDIVIDU              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 82 |                    INDEX UNIQUE SCAN                         | IND_REFINDIV            |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|  83 |                  TABLE ACCESS BY INDEX ROWID                 | G_ACCORDS               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 84 |                   INDEX UNIQUE SCAN                          | REF_ACCORD              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|  85 |                 VIEW PUSHED PREDICATE                        |                         |      0 |      1 |     5   (0)|      0 |00:00:00.01 |       0 |      0 |
|  86 |                  SORT GROUP BY                               |                         |      0 |      5 |     5   (0)|      0 |00:00:00.01 |       0 |      0 |
|  87 |                   VIEW                                       | V_TDOMAINE              |      0 |      5 |     5   (0)|      0 |00:00:00.01 |       0 |      0 |
|  88 |                    UNION-ALL                                 |                         |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|* 89 |                     FILTER                                   |                         |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  90 |                      TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 91 |                       INDEX RANGE SCAN                       | DOM_TYPVAL              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 92 |                     FILTER                                   |                         |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  93 |                      TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 94 |                       INDEX RANGE SCAN                       | DOM_TYPVAL              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 95 |                     FILTER                                   |                         |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  96 |                      TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 97 |                       INDEX RANGE SCAN                       | DOM_TYPVAL              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 98 |                     FILTER                                   |                         |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  99 |                      TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*100 |                       INDEX RANGE SCAN                       | DOM_TYPVAL              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*101 |                     FILTER                                   |                         |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 102 |                      TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*103 |                       INDEX RANGE SCAN                       | DOM_TYPVAL              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 104 |                VIEW PUSHED PREDICATE                         |                         |      0 |      1 |     5   (0)|      0 |00:00:00.01 |       0 |      0 |
| 105 |                 SORT GROUP BY                                |                         |      0 |      5 |     5   (0)|      0 |00:00:00.01 |       0 |      0 |
| 106 |                  VIEW                                        | V_TDOMAINE              |      0 |      5 |     5   (0)|      0 |00:00:00.01 |       0 |      0 |
| 107 |                   UNION-ALL                                  |                         |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*108 |                    FILTER                                    |                         |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 109 |                     TABLE ACCESS BY INDEX ROWID BATCHED      | V_DOMAINE               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*110 |                      INDEX RANGE SCAN                        | DOM_TYPVAL              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*111 |                    FILTER                                    |                         |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 112 |                     TABLE ACCESS BY INDEX ROWID BATCHED      | V_DOMAINE               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*113 |                      INDEX RANGE SCAN                        | DOM_TYPVAL              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*114 |                    FILTER                                    |                         |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 115 |                     TABLE ACCESS BY INDEX ROWID BATCHED      | V_DOMAINE               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*116 |                      INDEX RANGE SCAN                        | DOM_TYPVAL              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*117 |                    FILTER                                    |                         |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 118 |                     TABLE ACCESS BY INDEX ROWID BATCHED      | V_DOMAINE               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*119 |                      INDEX RANGE SCAN                        | DOM_TYPVAL              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*120 |                    FILTER                                    |                         |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 121 |                     TABLE ACCESS BY INDEX ROWID BATCHED      | V_DOMAINE               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*122 |                      INDEX RANGE SCAN                        | DOM_TYPVAL              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 123 |              SORT UNIQUE                                     |                         |     13 |      3 |     6   (0)|     13 |00:00:00.04 |     186 |     11 |
| 124 |               UNION-ALL                                      |                         |     13 |        |            |     13 |00:00:00.04 |     186 |     11 |
|*125 |                FILTER                                        |                         |     13 |        |            |     13 |00:00:00.04 |     101 |     11 |
| 126 |                 NESTED LOOPS                                 |                         |     13 |      1 |     3   (0)|     13 |00:00:00.04 |     101 |     11 |
| 127 |                  NESTED LOOPS                                |                         |     13 |      1 |     3   (0)|     13 |00:00:00.03 |      75 |      3 |
| 128 |                   NESTED LOOPS                               |                         |     13 |      1 |     2   (0)|     13 |00:00:00.03 |      52 |      3 |
|*129 |                    INDEX RANGE SCAN                          | DOS_REFDOSS_REFLOT_IDX  |     13 |      1 |     1   (0)|     13 |00:00:00.03 |      26 |      3 |
|*130 |                    INDEX RANGE SCAN                          | DOS_REFDOSS_REFLOT_IDX  |     13 |      1 |     1   (0)|     13 |00:00:00.01 |      26 |      0 |
|*131 |                   INDEX UNIQUE SCAN                          | DOS_REFDOSS             |     13 |      1 |     1   (0)|     13 |00:00:00.01 |      23 |      0 |
| 132 |                  TABLE ACCESS BY INDEX ROWID                 | G_DOSSIER               |     13 |      1 |     1   (0)|     13 |00:00:00.01 |      26 |      8 |
| 133 |                NESTED LOOPS                                  |                         |     13 |      1 |     2   (0)|      0 |00:00:00.01 |      49 |      0 |
|*134 |                 TABLE ACCESS BY INDEX ROWID                  | G_DOSSIER               |     13 |      1 |     1   (0)|      0 |00:00:00.01 |      49 |      0 |
|*135 |                  INDEX UNIQUE SCAN                           | DOS_REFDOSS             |     13 |      1 |     1   (0)|     13 |00:00:00.01 |      23 |      0 |
| 136 |                 TABLE ACCESS BY INDEX ROWID                  | G_DOSSIER               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*137 |                  INDEX UNIQUE SCAN                           | DOS_REFDOSS             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*138 |                TABLE ACCESS BY INDEX ROWID                   | G_DOSSIER               |     13 |      1 |     1   (0)|      0 |00:00:00.01 |      36 |      0 |
|*139 |                 INDEX UNIQUE SCAN                            | DOS_REFDOSS             |     13 |      1 |     1   (0)|     13 |00:00:00.01 |      23 |      0 |
|*140 |              FILTER                                          |                         |      1 |        |            |     13 |00:01:14.60 |   70594 |  16788 |
| 141 |               NESTED LOOPS OUTER                             |                         |      1 |      1 |    20   (0)|     13 |00:01:14.60 |   70594 |  16788 |
| 142 |                NESTED LOOPS OUTER                            |                         |      1 |      1 |    15   (0)|     13 |00:01:14.59 |   70571 |  16787 |
| 143 |                 NESTED LOOPS                                 |                         |      1 |      1 |    10   (0)|     13 |00:01:14.59 |   70535 |  16787 |
| 144 |                  NESTED LOOPS OUTER                          |                         |      1 |      1 |     9   (0)|     13 |00:01:14.08 |   69669 |  16719 |
| 145 |                   NESTED LOOPS                               |                         |      1 |      1 |     8   (0)|     13 |00:01:14.07 |   69665 |  16718 |
| 146 |                    NESTED LOOPS                              |                         |      1 |      1 |     7   (0)|     13 |00:01:13.99 |   69638 |  16711 |
| 147 |                     NESTED LOOPS                             |                         |      1 |      5 |     6   (0)|     13 |00:01:13.94 |   69610 |  16705 |
| 148 |                      NESTED LOOPS OUTER                      |                         |      1 |      5 |     5   (0)|     13 |00:01:13.93 |   69588 |  16701 |
| 149 |                       NESTED LOOPS                           |                         |      1 |      5 |     4   (0)|     13 |00:01:13.92 |   69566 |  16700 |
| 150 |                        NESTED LOOPS                          |                         |      1 |      5 |     3   (0)|     13 |00:01:13.81 |   69539 |  16690 |
| 151 |                         NESTED LOOPS                         |                         |      1 |      5 |     2   (0)|   4079 |00:01:09.68 |   57331 |  16184 |
|*152 |                          TABLE ACCESS BY INDEX ROWID BATCHED | T_ELEMENTS              |      1 |      5 |     1   (0)|   4079 |00:01:09.12 |   53546 |  16088 |
|*153 |                           INDEX RANGE SCAN                   | TE_MONTANT              |      1 |     63 |     1   (0)|  56712 |00:00:00.87 |     175 |    132 |
| 154 |                          TABLE ACCESS BY INDEX ROWID         | G_DOSSIER               |   4079 |      1 |     1   (0)|   4079 |00:00:00.55 |    3785 |     96 |
|*155 |                           INDEX UNIQUE SCAN                  | DOS_REFDOSS             |   4079 |      1 |     1   (0)|   4079 |00:00:00.02 |    2750 |      5 |
|*156 |                         TABLE ACCESS BY INDEX ROWID          | G_ENCAISSEMENT          |   4079 |      1 |     1   (0)|     13 |00:00:04.13 |   12208 |    506 |
|*157 |                          INDEX UNIQUE SCAN                   | REFENCAISS              |   4079 |      1 |     1   (0)|   4078 |00:00:01.22 |    8150 |    175 |
| 158 |                        TABLE ACCESS BY INDEX ROWID           | G_INDIVIDU              |     13 |      1 |     1   (0)|     13 |00:00:00.10 |      27 |     10 |
|*159 |                         INDEX UNIQUE SCAN                    | IND_REFINDIV            |     13 |      1 |     1   (0)|     13 |00:00:00.01 |      16 |      1 |
|*160 |                       TABLE ACCESS BY INDEX ROWID            | NAM_COLLECTE            |     13 |      1 |     1   (0)|     13 |00:00:00.01 |      22 |      1 |
|*161 |                        INDEX UNIQUE SCAN                     | COLCOMPOSTAGE           |     13 |      1 |     1   (0)|     13 |00:00:00.01 |       9 |      1 |
| 162 |                      TABLE ACCESS BY INDEX ROWID             | G_VENTILENC             |     13 |      1 |     1   (0)|     13 |00:00:00.01 |      22 |      4 |
|*163 |                       INDEX UNIQUE SCAN                      | VENT_REFDOSS            |     13 |      1 |     1   (0)|     13 |00:00:00.01 |       9 |      0 |
|*164 |                     INDEX RANGE SCAN                         | INT_REFDOSS             |     13 |      1 |     1   (0)|     13 |00:00:00.05 |      28 |      6 |
| 165 |                    TABLE ACCESS BY INDEX ROWID               | G_INDIVIDU              |     13 |      1 |     1   (0)|     13 |00:00:00.08 |      27 |      7 |
|*166 |                     INDEX UNIQUE SCAN                        | IND_REFINDIV            |     13 |      1 |     1   (0)|     13 |00:00:00.01 |      16 |      0 |
| 167 |                   TABLE ACCESS BY INDEX ROWID                | G_ACCORDS               |     13 |      1 |     1   (0)|      0 |00:00:00.01 |       4 |      1 |
|*168 |                    INDEX UNIQUE SCAN                         | REF_ACCORD              |     13 |      1 |     1   (0)|      0 |00:00:00.01 |       4 |      1 |
|*169 |                  INDEX RANGE SCAN                            | AGGREG_T_ECRDOS_NMP$BAL |     13 |      1 |     1   (0)|     13 |00:00:00.51 |     866 |     68 |
| 170 |                 VIEW PUSHED PREDICATE                        |                         |     13 |      1 |     5   (0)|     13 |00:00:00.01 |      36 |      0 |
| 171 |                  SORT GROUP BY                               |                         |     13 |      5 |     5   (0)|     13 |00:00:00.01 |      36 |      0 |
| 172 |                   VIEW                                       | V_TDOMAINE              |     13 |      5 |     5   (0)|     13 |00:00:00.01 |      36 |      0 |
| 173 |                    UNION-ALL                                 |                         |     13 |        |            |     13 |00:00:00.01 |      36 |      0 |
|*174 |                     FILTER                                   |                         |     13 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 175 |                      TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*176 |                       INDEX RANGE SCAN                       | DOM_TYPVAL              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*177 |                     FILTER                                   |                         |     13 |        |            |     13 |00:00:00.01 |      36 |      0 |
| 178 |                      TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE               |     13 |      1 |     1   (0)|     13 |00:00:00.01 |      36 |      0 |
|*179 |                       INDEX RANGE SCAN                       | DOM_TYPVAL              |     13 |      1 |     1   (0)|     13 |00:00:00.01 |      23 |      0 |
|*180 |                     FILTER                                   |                         |     13 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 181 |                      TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*182 |                       INDEX RANGE SCAN                       | DOM_TYPVAL              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*183 |                     FILTER                                   |                         |     13 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 184 |                      TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*185 |                       INDEX RANGE SCAN                       | DOM_TYPVAL              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*186 |                     FILTER                                   |                         |     13 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 187 |                      TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*188 |                       INDEX RANGE SCAN                       | DOM_TYPVAL              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 189 |                VIEW PUSHED PREDICATE                         |                         |     13 |      1 |     5   (0)|      0 |00:00:00.01 |      23 |      1 |
| 190 |                 SORT GROUP BY                                |                         |     13 |      5 |     5   (0)|      0 |00:00:00.01 |      23 |      1 |
| 191 |                  VIEW                                        | V_TDOMAINE              |     13 |      5 |     5   (0)|      0 |00:00:00.01 |      23 |      1 |
| 192 |                   UNION-ALL                                  |                         |     13 |        |            |      0 |00:00:00.01 |      23 |      1 |
|*193 |                    FILTER                                    |                         |     13 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 194 |                     TABLE ACCESS BY INDEX ROWID BATCHED      | V_DOMAINE               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*195 |                      INDEX RANGE SCAN                        | DOM_TYPVAL              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*196 |                    FILTER                                    |                         |     13 |        |            |      0 |00:00:00.01 |      23 |      1 |
| 197 |                     TABLE ACCESS BY INDEX ROWID BATCHED      | V_DOMAINE               |     13 |      1 |     1   (0)|      0 |00:00:00.01 |      23 |      1 |
|*198 |                      INDEX RANGE SCAN                        | DOM_TYPVAL              |     13 |      1 |     1   (0)|      0 |00:00:00.01 |      23 |      1 |
|*199 |                    FILTER                                    |                         |     13 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 200 |                     TABLE ACCESS BY INDEX ROWID BATCHED      | V_DOMAINE               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*201 |                      INDEX RANGE SCAN                        | DOM_TYPVAL              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*202 |                    FILTER                                    |                         |     13 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 203 |                     TABLE ACCESS BY INDEX ROWID BATCHED      | V_DOMAINE               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*204 |                      INDEX RANGE SCAN                        | DOM_TYPVAL              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*205 |                    FILTER                                    |                         |     13 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 206 |                     TABLE ACCESS BY INDEX ROWID BATCHED      | V_DOMAINE               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*207 |                      INDEX RANGE SCAN                        | DOM_TYPVAL              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 208 |              SORT UNIQUE                                     |                         |      0 |      3 |     6   (0)|      0 |00:00:00.01 |       0 |      0 |
| 209 |               UNION-ALL                                      |                         |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 210 |                NESTED LOOPS                                  |                         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
| 211 |                 NESTED LOOPS                                 |                         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
| 212 |                  NESTED LOOPS                                |                         |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*213 |                   INDEX RANGE SCAN                           | DOS_REFDOSS_REFLOT_IDX  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*214 |                   INDEX RANGE SCAN                           | DOS_REFDOSS_REFLOT_IDX  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*215 |                  INDEX UNIQUE SCAN                           | DOS_REFDOSS             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 216 |                 TABLE ACCESS BY INDEX ROWID                  | G_DOSSIER               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 217 |                NESTED LOOPS                                  |                         |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*218 |                 TABLE ACCESS BY INDEX ROWID                  | G_DOSSIER               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*219 |                  INDEX UNIQUE SCAN                           | DOS_REFDOSS             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 220 |                 TABLE ACCESS BY INDEX ROWID                  | G_DOSSIER               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*221 |                  INDEX UNIQUE SCAN                           | DOS_REFDOSS             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*222 |                TABLE ACCESS BY INDEX ROWID                   | G_DOSSIER               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*223 |                 INDEX UNIQUE SCAN                            | DOS_REFDOSS             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*224 |              FILTER                                          |                         |      1 |        |            |      0 |00:00:00.01 |       1 |      1 |
| 225 |               NESTED LOOPS OUTER                             |                         |      1 |      1 |    15   (0)|      0 |00:00:00.01 |       1 |      1 |
| 226 |                NESTED LOOPS                                  |                         |      1 |      1 |    14   (0)|      0 |00:00:00.01 |       1 |      1 |
| 227 |                 NESTED LOOPS                                 |                         |      1 |      1 |    13   (0)|      0 |00:00:00.01 |       1 |      1 |
| 228 |                  NESTED LOOPS                                |                         |      1 |      1 |    12   (0)|      0 |00:00:00.01 |       1 |      1 |
| 229 |                   NESTED LOOPS                               |                         |      1 |      1 |    11   (0)|      0 |00:00:00.01 |       1 |      1 |
| 230 |                    NESTED LOOPS                              |                         |      1 |      1 |    10   (0)|      0 |00:00:00.01 |       1 |      1 |
| 231 |                     NESTED LOOPS                             |                         |      1 |      1 |     9   (0)|      0 |00:00:00.01 |       1 |      1 |
| 232 |                      NESTED LOOPS                            |                         |      1 |      1 |     8   (0)|      0 |00:00:00.01 |       1 |      1 |
| 233 |                       NESTED LOOPS                           |                         |      1 |      1 |     7   (0)|      0 |00:00:00.01 |       1 |      1 |
| 234 |                        NESTED LOOPS OUTER                    |                         |      1 |      1 |     6   (0)|      0 |00:00:00.01 |       1 |      1 |
|*235 |                         TABLE ACCESS BY INDEX ROWID BATCHED  | F_ENTENR                |      1 |      1 |     1   (0)|      0 |00:00:00.01 |       1 |      1 |
|*236 |                          INDEX RANGE SCAN                    | FE_EE_FINDTECH_DT       |      1 |      3 |     1   (0)|      0 |00:00:00.01 |       1 |      1 |
| 237 |                         VIEW PUSHED PREDICATE                |                         |      0 |      1 |     5   (0)|      0 |00:00:00.01 |       0 |      0 |
| 238 |                          SORT GROUP BY                       |                         |      0 |      1 |     5   (0)|      0 |00:00:00.01 |       0 |      0 |
| 239 |                           VIEW                               | V_TDOMAINE              |      0 |      5 |     5   (0)|      0 |00:00:00.01 |       0 |      0 |
| 240 |                            UNION-ALL                         |                         |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*241 |                             FILTER                           |                         |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 242 | CHED                         TABLE ACCESS BY INDEX ROWID BAT | V_DOMAINE               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*243 |                               INDEX RANGE SCAN               | DOM_TYPVAL              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*244 |                             FILTER                           |                         |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 245 | CHED                         TABLE ACCESS BY INDEX ROWID BAT | V_DOMAINE               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*246 |                               INDEX RANGE SCAN               | DOM_TYPVAL              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*247 |                             FILTER                           |                         |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 248 | CHED                         TABLE ACCESS BY INDEX ROWID BAT | V_DOMAINE               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*249 |                               INDEX RANGE SCAN               | DOM_TYPVAL              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*250 |                             FILTER                           |                         |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 251 | CHED                         TABLE ACCESS BY INDEX ROWID BAT | V_DOMAINE               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*252 |                               INDEX RANGE SCAN               | DOM_TYPVAL              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*253 |                             FILTER                           |                         |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 254 | CHED                         TABLE ACCESS BY INDEX ROWID BAT | V_DOMAINE               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*255 |                               INDEX RANGE SCAN               | DOM_TYPVAL              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*256 |                        TABLE ACCESS BY INDEX ROWID BATCHED   | F_DETENR                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*257 |                         INDEX RANGE SCAN                     | DETENR_NUM              |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*258 |                       TABLE ACCESS BY INDEX ROWID            | F_PARENR                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*259 |                        INDEX UNIQUE SCAN                     | PARENR_CL1              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*260 |                      TABLE ACCESS BY INDEX ROWID BATCHED     | G_ENCAISSEMENT          |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*261 |                       INDEX RANGE SCAN                       | ENCAISSPIECE            |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 262 |                     TABLE ACCESS BY INDEX ROWID              | G_DOSSIER               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*263 |                      INDEX UNIQUE SCAN                       | DOS_REFDOSS             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*264 |                    INDEX RANGE SCAN                          | INT_REFDOSS             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 265 |                   TABLE ACCESS BY INDEX ROWID BATCHED        | T_ELEMENTS              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*266 |                    INDEX RANGE SCAN                          | ELE_ELEMTYPE            |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 267 |                  TABLE ACCESS BY INDEX ROWID                 | G_INDIVIDU              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*268 |                   INDEX UNIQUE SCAN                          | IND_REFINDIV            |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 269 |                 TABLE ACCESS BY INDEX ROWID                  | G_INDIVIDU              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*270 |                  INDEX UNIQUE SCAN                           | IND_REFINDIV            |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 271 |                TABLE ACCESS BY INDEX ROWID                   | G_ACCORDS               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*272 |                 INDEX UNIQUE SCAN                            | REF_ACCORD              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*273 |              FILTER                                          |                         |      1 |        |            |      0 |00:00:00.01 |       1 |      0 |
| 274 |               HASH GROUP BY                                  |                         |      1 |      1 |    18  (12)|      0 |00:00:00.01 |       1 |      0 |
|*275 |                FILTER                                        |                         |      1 |        |            |      0 |00:00:00.01 |       1 |      0 |
| 276 |                 NESTED LOOPS                                 |                         |      1 |      1 |    17   (6)|      0 |00:00:00.01 |       1 |      0 |
| 277 |                  NESTED LOOPS                                |                         |      1 |      1 |    17   (6)|      0 |00:00:00.01 |       1 |      0 |
| 278 |                   NESTED LOOPS                               |                         |      1 |      1 |    16   (7)|      0 |00:00:00.01 |       1 |      0 |
| 279 |                    NESTED LOOPS                              |                         |      1 |      1 |     9   (0)|      0 |00:00:00.01 |       1 |      0 |
| 280 |                     NESTED LOOPS                             |                         |      1 |      1 |     8   (0)|      0 |00:00:00.01 |       1 |      0 |
| 281 |                      NESTED LOOPS                            |                         |      1 |      1 |     7   (0)|      0 |00:00:00.01 |       1 |      0 |
| 282 |                       NESTED LOOPS OUTER                     |                         |      1 |      1 |     6   (0)|      0 |00:00:00.01 |       1 |      0 |
|*283 |                        TABLE ACCESS BY INDEX ROWID BATCHED   | F_ENTENR                |      1 |      1 |     1   (0)|      0 |00:00:00.01 |       1 |      0 |
|*284 |                         INDEX RANGE SCAN                     | FE_EE_FINDTECH_DT       |      1 |      3 |     1   (0)|      0 |00:00:00.01 |       1 |      0 |
| 285 |                        VIEW PUSHED PREDICATE                 |                         |      0 |      1 |     5   (0)|      0 |00:00:00.01 |       0 |      0 |
| 286 |                         SORT GROUP BY                        |                         |      0 |      5 |     5   (0)|      0 |00:00:00.01 |       0 |      0 |
| 287 |                          VIEW                                | V_TDOMAINE              |      0 |      5 |     5   (0)|      0 |00:00:00.01 |       0 |      0 |
| 288 |                           UNION-ALL                          |                         |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*289 |                            FILTER                            |                         |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 290 | HED                         TABLE ACCESS BY INDEX ROWID BATC | V_DOMAINE               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*291 |                              INDEX RANGE SCAN                | DOM_TYPVAL              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*292 |                            FILTER                            |                         |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 293 | HED                         TABLE ACCESS BY INDEX ROWID BATC | V_DOMAINE               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*294 |                              INDEX RANGE SCAN                | DOM_TYPVAL              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*295 |                            FILTER                            |                         |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 296 | HED                         TABLE ACCESS BY INDEX ROWID BATC | V_DOMAINE               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*297 |                              INDEX RANGE SCAN                | DOM_TYPVAL              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*298 |                            FILTER                            |                         |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 299 | HED                         TABLE ACCESS BY INDEX ROWID BATC | V_DOMAINE               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*300 |                              INDEX RANGE SCAN                | DOM_TYPVAL              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*301 |                            FILTER                            |                         |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 302 | HED                         TABLE ACCESS BY INDEX ROWID BATC | V_DOMAINE               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*303 |                              INDEX RANGE SCAN                | DOM_TYPVAL              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 304 |                       TABLE ACCESS BY INDEX ROWID            | G_INDIVIDU              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*305 |                        INDEX UNIQUE SCAN                     | IND_REFINDIV            |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 306 |                      TABLE ACCESS BY INDEX ROWID BATCHED     | F_ENTENR                |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*307 |                       INDEX RANGE SCAN                       | ENTENR_MAITRE           |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*308 |                     TABLE ACCESS BY INDEX ROWID BATCHED      | G_ENCAISSEMENT          |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*309 |                      INDEX RANGE SCAN                        | ENCAISSPIECE            |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 310 |                    VIEW                                      |                         |      0 |      1 |     7  (15)|      0 |00:00:00.01 |       0 |      0 |
| 311 |                     SORT UNIQUE                              |                         |      0 |      3 |     7  (15)|      0 |00:00:00.01 |       0 |      0 |
| 312 |                      UNION ALL PUSHED PREDICATE              |                         |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 313 |                       NESTED LOOPS                           |                         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
| 314 |                        NESTED LOOPS                          |                         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
| 315 |                         NESTED LOOPS                         |                         |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*316 |                          INDEX RANGE SCAN                    | DOS_REFDOSS_REFLOT_IDX  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*317 |                          INDEX RANGE SCAN                    | DOS_REFDOSS_REFLOT_IDX  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*318 |                         INDEX UNIQUE SCAN                    | DOS_REFDOSS             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 319 |                        TABLE ACCESS BY INDEX ROWID           | G_DOSSIER               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 320 |                       NESTED LOOPS                           |                         |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*321 |                        TABLE ACCESS BY INDEX ROWID           | G_DOSSIER               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*322 |                         INDEX UNIQUE SCAN                    | DOS_REFDOSS             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 323 |                        TABLE ACCESS BY INDEX ROWID           | G_DOSSIER               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*324 |                         INDEX UNIQUE SCAN                    | DOS_REFDOSS             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*325 |                       TABLE ACCESS BY INDEX ROWID            | G_DOSSIER               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*326 |                        INDEX UNIQUE SCAN                     | DOS_REFDOSS             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*327 |                   INDEX RANGE SCAN                           | ELE_ELEMTYPE            |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*328 |                  TABLE ACCESS BY INDEX ROWID                 | T_ELEMENTS              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 329 |            TABLE ACCESS BY INDEX ROWID                       | NAM_COLLECTE            |     13 |      1 |     1   (0)|     13 |00:00:00.01 |      22 |      0 |
|*330 |             INDEX UNIQUE SCAN                                | COLCOMPOSTAGE           |     13 |      1 |     1   (0)|     13 |00:00:00.01 |       9 |      0 |
| 331 |           TABLE ACCESS BY INDEX ROWID BATCHED                | G_PERSONNEL             |     13 |      1 |     1   (0)|     13 |00:00:00.01 |      14 |      0 |
|*332 |            INDEX RANGE SCAN                                  | GPERSREFP               |     13 |      1 |     1   (0)|     13 |00:00:00.01 |       3 |      0 |
| 333 |          TABLE ACCESS BY INDEX ROWID BATCHED                 | G_PERSONNEL             |     13 |      1 |     1   (0)|     13 |00:00:00.01 |      12 |      0 |
|*334 |           INDEX RANGE SCAN                                   | GPERSREFP               |     13 |      1 |     1   (0)|     13 |00:00:00.01 |       3 |      0 |
|*335 |         TABLE ACCESS BY INDEX ROWID BATCHED                  | T_ELEMENTS              |     13 |      1 |     1   (0)|     13 |00:00:00.06 |      31 |      4 |
|*336 |          INDEX RANGE SCAN                                    | ELE_ELEMTYPE            |     13 |      1 |     1   (0)|     13 |00:00:00.06 |      27 |      4 |
| 337 |        VIEW                                                  |                         |      1 |     36 |     6  (17)|    166 |00:00:00.03 |      78 |     56 |
| 338 |         HASH GROUP BY                                        |                         |      1 |     36 |     6  (17)|    166 |00:00:00.03 |      78 |     56 |
| 339 |          VIEW                                                | V_TDOMAINE              |      1 |    180 |     5   (0)|    166 |00:00:00.03 |      78 |     56 |
| 340 |           UNION-ALL                                          |                         |      1 |        |            |    166 |00:00:00.03 |      78 |     56 |
|*341 |            FILTER                                            |                         |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 342 |             TABLE ACCESS BY INDEX ROWID BATCHED              | V_DOMAINE               |      0 |     36 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*343 |              INDEX RANGE SCAN                                | V_DOMAINE_TYPE_CODE_IDX |      0 |     36 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*344 |            FILTER                                            |                         |      1 |        |            |    166 |00:00:00.03 |      78 |     56 |
| 345 |             TABLE ACCESS BY INDEX ROWID BATCHED              | V_DOMAINE               |      1 |     36 |     1   (0)|    166 |00:00:00.03 |      78 |     56 |
|*346 |              INDEX RANGE SCAN                                | V_DOMAINE_TYPE_CODE_IDX |      1 |     36 |     1   (0)|    166 |00:00:00.01 |       3 |      2 |
|*347 |            FILTER                                            |                         |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 348 |             TABLE ACCESS BY INDEX ROWID BATCHED              | V_DOMAINE               |      0 |     36 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*349 |              INDEX RANGE SCAN                                | V_DOMAINE_TYPE_CODE_IDX |      0 |     36 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*350 |            FILTER                                            |                         |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 351 |             TABLE ACCESS BY INDEX ROWID BATCHED              | V_DOMAINE               |      0 |     36 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*352 |              INDEX RANGE SCAN                                | V_DOMAINE_TYPE_CODE_IDX |      0 |     36 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*353 |            FILTER                                            |                         |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 354 |             TABLE ACCESS BY INDEX ROWID BATCHED              | V_DOMAINE               |      0 |     36 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*355 |              INDEX RANGE SCAN                                | V_DOMAINE_TYPE_CODE_IDX |      0 |     36 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 356 |       VIEW                                                   |                         |      1 |     36 |     6  (17)|      0 |00:00:00.01 |       2 |      1 |
| 357 |        HASH GROUP BY                                         |                         |      1 |     36 |     6  (17)|      0 |00:00:00.01 |       2 |      1 |
| 358 |         VIEW                                                 | V_TDOMAINE              |      1 |    180 |     5   (0)|      0 |00:00:00.01 |       2 |      1 |
| 359 |          UNION-ALL                                           |                         |      1 |        |            |      0 |00:00:00.01 |       2 |      1 |
|*360 |           FILTER                                             |                         |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 361 |            TABLE ACCESS BY INDEX ROWID BATCHED               | V_DOMAINE               |      0 |     36 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*362 |             INDEX RANGE SCAN                                 | V_DOMAINE_TYPE_CODE_IDX |      0 |     36 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*363 |           FILTER                                             |                         |      1 |        |            |      0 |00:00:00.01 |       2 |      1 |
| 364 |            TABLE ACCESS BY INDEX ROWID BATCHED               | V_DOMAINE               |      1 |     36 |     1   (0)|      0 |00:00:00.01 |       2 |      1 |
|*365 |             INDEX RANGE SCAN                                 | V_DOMAINE_TYPE_CODE_IDX |      1 |     36 |     1   (0)|      0 |00:00:00.01 |       2 |      1 |
|*366 |           FILTER                                             |                         |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 367 |            TABLE ACCESS BY INDEX ROWID BATCHED               | V_DOMAINE               |      0 |     36 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*368 |             INDEX RANGE SCAN                                 | V_DOMAINE_TYPE_CODE_IDX |      0 |     36 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*369 |           FILTER                                             |                         |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 370 |            TABLE ACCESS BY INDEX ROWID BATCHED               | V_DOMAINE               |      0 |     36 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*371 |             INDEX RANGE SCAN                                 | V_DOMAINE_TYPE_CODE_IDX |      0 |     36 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*372 |           FILTER                                             |                         |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 373 |            TABLE ACCESS BY INDEX ROWID BATCHED               | V_DOMAINE               |      0 |     36 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*374 |             INDEX RANGE SCAN                                 | V_DOMAINE_TYPE_CODE_IDX |      0 |     36 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
------------------------------------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   1 - filter(ROWNUM=1)
   4 - filter('AL'=:B1)
   6 - access("TYPE"='NAM_COLLECTE' AND "ABREV"=SUBSTR(:B1,1,3))
   7 - filter('AN'=:B1)
   9 - access("TYPE"='NAM_COLLECTE' AND "ABREV"=SUBSTR(:B1,1,3))
  10 - filter('ES'=:B1)
  12 - access("TYPE"='NAM_COLLECTE' AND "ABREV"=SUBSTR(:B1,1,3))
  13 - filter('FR'=:B1)
  15 - access("TYPE"='NAM_COLLECTE' AND "ABREV"=SUBSTR(:B1,1,3))
  16 - filter('IT'=:B1)
  18 - access("TYPE"='NAM_COLLECTE' AND "ABREV"=SUBSTR(:B1,1,3))
  22 - filter(("REFDOSS"=:B1 AND "TYPENCAISS"=:B2))
  23 - access("REFENCAISS"=:B1)
  26 - access("REFDOSS"=:B1)
  27 - filter("RNUM">=:B7)
  28 - filter(ROWNUM<=:B6)
  31 - access("V3"."ABREV"=DECODE("MAIN_QUERY"."REFREPRES",NULL,DECODE(INTERNAL_FUNCTION("MAIN_QUERY"."DTIMPAYE_DT"),NULL,'ENCAISSE','IMPAYE'),'REPRESENTE'))
  32 - access("NC"."TRAITE"=TO_NUMBER("V2"."ABREV"))
  44 - access("CPT"."REFDOSS"=:B1)
       filter("CPT"."REFLOT" IS NOT NULL)
  45 - access("DCPT"."REFDOSS"="CPT"."REFLOT")
       filter("DCPT"."REFLOT" IS NOT NULL)
  46 - access("CTR"."REFDOSS"="DCPT"."REFLOT")
  49 - filter(("DCPT"."CATEGDOSS" LIKE 'DECOMPTE%' AND "DCPT"."REFLOT" IS NOT NULL))
  50 - access("DCPT"."REFDOSS"=:B1)
  52 - access("CTR"."REFDOSS"="DCPT"."REFLOT")
  53 - filter("CTR"."CATEGDOSS" LIKE 'CONTRAT%')
  54 - access("CTR"."REFDOSS"=:B1)
  55 - filter((:B3>=:B2 AND TO_DATE(:B5,'YYYY-MM-DD')>=TO_DATE(:B4,'YYYY-MM-DD')))
  67 - filter(("T"."TYPEELEM"='en' OR "T"."TYPEELEM"='vd'))
  68 - access("T"."MONTANT">=:B2 AND "T"."MONTANT"<=:B3)
  70 - access("T"."REFDOSS"="VEN"."REFDOSS" AND "T"."REFELEM"="VEN"."REFENCAISS")
  71 - access("TNMP"."REFDOSS"="VEN"."REFDOSS" AND "TNMP"."REFELEM"="VEN"."REFENCAISS")
       filter("TNMP"."BALANCE_DCPT"<0)
  72 - filter((INTERNAL_FUNCTION("EN"."TYPENCAISS") AND NVL("DTENCAISS_DT","DTRECEPTION_DT")>=TO_DATE(:B4,'YYYY-MM-DD') AND "EN"."TRAITE"<>'9' AND
              NVL("DTENCAISS_DT","DTRECEPTION_DT")<=TO_DATE(:B5,'YYYY-MM-DD')))
  73 - access("T"."REFELEM"="EN"."REFENCAISS")
  75 - access("EN"."LIEUPAIMT"="NC"."COMPOSTAGE")
  77 - access("EN"."REFPAYEUR"="I"."REFINDIVIDU")
  79 - access("T"."REFDOSS"="D"."REFDOSS")
  80 - access("TCL"."REFDOSS"="D"."REFDOSS" AND "TCL"."REFTYPE"='CL')
  82 - access("TCL"."REFINDIVIDU"="CL"."REFINDIVIDU")
  84 - access("ACL"."REFINDIVIDU"="CL"."REFINDIVIDU")
  89 - filter('AL'=:B1)
  91 - access("VALEUR"="EN"."MOYENPAIMT" AND "TYPE"='MOYENPAIMT')
  92 - filter('AN'=:B1)
  94 - access("VALEUR"="EN"."MOYENPAIMT" AND "TYPE"='MOYENPAIMT')
  95 - filter('ES'=:B1)
  97 - access("VALEUR"="EN"."MOYENPAIMT" AND "TYPE"='MOYENPAIMT')
  98 - filter('FR'=:B1)
 100 - access("VALEUR"="EN"."MOYENPAIMT" AND "TYPE"='MOYENPAIMT')
 101 - filter('IT'=:B1)
 103 - access("VALEUR"="EN"."MOYENPAIMT" AND "TYPE"='MOYENPAIMT')
 108 - filter(NVL(:B1,'FR')='AL')
 110 - access("VALEUR"="EN"."LIBELLE" AND "TYPE"='libfds')
 111 - filter(NVL(:B1,'FR')='AN')
 113 - access("VALEUR"="EN"."LIBELLE" AND "TYPE"='libfds')
 114 - filter(NVL(:B1,'FR')='ES')
 116 - access("VALEUR"="EN"."LIBELLE" AND "TYPE"='libfds')
 117 - filter(NVL(:B1,'FR')='FR')
 119 - access("VALEUR"="EN"."LIBELLE" AND "TYPE"='libfds')
 120 - filter(NVL(:B1,'FR')='IT')
 122 - access("VALEUR"="EN"."LIBELLE" AND "TYPE"='libfds')
 125 - filter(:B1=:B2)
 129 - access("CPT"."REFDOSS"=:B1)
       filter("CPT"."REFLOT" IS NOT NULL)
 130 - access("DECO"."REFDOSS"="CPT"."REFLOT")
       filter("DECO"."REFLOT" IS NOT NULL)
 131 - access("CTR"."REFDOSS"="DECO"."REFLOT")
 134 - filter(("DCPT"."CATEGDOSS" LIKE 'DECOMPTE%' AND "DCPT"."REFLOT" IS NOT NULL))
 135 - access("DCPT"."REFDOSS"=:B1)
 137 - access("CTR"."REFDOSS"="DCPT"."REFLOT")
 138 - filter("CTR"."CATEGDOSS" LIKE 'CONTRAT%')
 139 - access("CTR"."REFDOSS"=:B1)
 140 - filter((TO_DATE(:B5,'YYYY-MM-DD')>=TO_DATE(:B4,'YYYY-MM-DD') AND :B3>=:B2))
 152 - filter(("T"."TYPEELEM"='en' OR "T"."TYPEELEM"='vd'))
 153 - access("T"."MONTANT">=:B2 AND "T"."MONTANT"<=:B3)
 155 - access("T"."REFDOSS"="D"."REFDOSS")
 156 - filter((INTERNAL_FUNCTION("EN"."TYPENCAISS") AND NVL("DTENCAISS_DT","DTRECEPTION_DT")>=TO_DATE(:B4,'YYYY-MM-DD') AND "EN"."TRAITE"='2' AND
              NVL("DTENCAISS_DT","DTRECEPTION_DT")<=TO_DATE(:B5,'YYYY-MM-DD')))
 157 - access("T"."REFELEM"="EN"."REFENCAISS")
 159 - access("EN"."REFPAYEUR"="I"."REFINDIVIDU")
 160 - filter(("NC"."REFER" IS NOT NULL AND "NC"."REFER"="EN"."REFENCAISS"))
 161 - access("NC"."COMPOSTAGE"="EN"."LIEUPAIMT")
 163 - access("T"."REFDOSS"="VEN"."REFDOSS" AND "T"."REFELEM"="VEN"."REFENCAISS")
 164 - access("TCL"."REFDOSS"="D"."REFDOSS" AND "TCL"."REFTYPE"='CL')
 166 - access("TCL"."REFINDIVIDU"="CL"."REFINDIVIDU")
 168 - access("ACL"."REFINDIVIDU"="CL"."REFINDIVIDU")
 169 - access("TNMP"."BALANCE_DCPT"<0)
       filter(("VEN"."REFENCAISS"="TNMP"."REFELEM" AND "VEN"."REFDOSS"="TNMP"."REFDOSS"))
 174 - filter('AL'=:B1)
 176 - access("VALEUR"="EN"."MOYENPAIMT" AND "TYPE"='MOYENPAIMT')
 177 - filter('AN'=:B1)
 179 - access("VALEUR"="EN"."MOYENPAIMT" AND "TYPE"='MOYENPAIMT')
 180 - filter('ES'=:B1)
 182 - access("VALEUR"="EN"."MOYENPAIMT" AND "TYPE"='MOYENPAIMT')
 183 - filter('FR'=:B1)
 185 - access("VALEUR"="EN"."MOYENPAIMT" AND "TYPE"='MOYENPAIMT')
 186 - filter('IT'=:B1)
 188 - access("VALEUR"="EN"."MOYENPAIMT" AND "TYPE"='MOYENPAIMT')
 193 - filter(NVL(:B1,'FR')='AL')
 195 - access("VALEUR"="EN"."LIBELLE" AND "TYPE"='libfds')
 196 - filter(NVL(:B1,'FR')='AN')
 198 - access("VALEUR"="EN"."LIBELLE" AND "TYPE"='libfds')
 199 - filter(NVL(:B1,'FR')='ES')
 201 - access("VALEUR"="EN"."LIBELLE" AND "TYPE"='libfds')
 202 - filter(NVL(:B1,'FR')='FR')
 204 - access("VALEUR"="EN"."LIBELLE" AND "TYPE"='libfds')
 205 - filter(NVL(:B1,'FR')='IT')
 207 - access("VALEUR"="EN"."LIBELLE" AND "TYPE"='libfds')
 213 - access("CPT"."REFDOSS"=:B1)
       filter("CPT"."REFLOT" IS NOT NULL)
 214 - access("DCPT"."REFDOSS"="CPT"."REFLOT")
       filter("DCPT"."REFLOT" IS NOT NULL)
 215 - access("CTR"."REFDOSS"="DCPT"."REFLOT")
 218 - filter(("DCPT"."CATEGDOSS" LIKE 'DECOMPTE%' AND "DCPT"."REFLOT" IS NOT NULL))
 219 - access("DCPT"."REFDOSS"=:B1)
 221 - access("CTR"."REFDOSS"="DCPT"."REFLOT")
 222 - filter("CTR"."CATEGDOSS" LIKE 'CONTRAT%')
 223 - access("CTR"."REFDOSS"=:B1)
 224 - filter((TO_DATE(:B5,'YYYY-MM-DD')>=TO_DATE(:B4,'YYYY-MM-DD') AND :B3>=:B2))
 235 - filter("E"."EE_MAITRE" IS NULL)
 236 - access("E"."EE_FINDTECH_DT">=TO_DATE(:B4,'YYYY-MM-DD') AND "E"."EE_FINDTECH_DT"<=TO_DATE(:B5,'YYYY-MM-DD'))
 241 - filter('AL'=:B1)
 243 - access("VALEUR"="E"."EE_REGL" AND "TYPE"='MOYENPAIMT')
 244 - filter('AN'=:B1)
 246 - access("VALEUR"="E"."EE_REGL" AND "TYPE"='MOYENPAIMT')
 247 - filter('ES'=:B1)
 249 - access("VALEUR"="E"."EE_REGL" AND "TYPE"='MOYENPAIMT')
 250 - filter('FR'=:B1)
 252 - access("VALEUR"="E"."EE_REGL" AND "TYPE"='MOYENPAIMT')
 253 - filter('IT'=:B1)
 255 - access("VALEUR"="E"."EE_REGL" AND "TYPE"='MOYENPAIMT')
 256 - filter(("DE_NTE" IS NOT NULL AND "DE_MONTTC"<=:B3 AND "DE_MONTTC">=:B2))
 257 - access("E"."EE_NUM"="DE_NUM")
 258 - filter("PE_CPT" LIKE 'KMTR%')
 259 - access("DE_NOM"="PE_NOM")
 260 - filter("EN"."TYPENCAISS"='Enregistrement')
 261 - access("EN"."REFPIECE"="E"."EE_NUM")
       filter("EN"."REFPIECE" IS NOT NULL)
 263 - access("EN"."REFDOSS"="D"."REFDOSS")
 264 - access("TCL"."REFDOSS"="D"."REFDOSS" AND "TCL"."REFTYPE"='CL')
 266 - access("T"."REFELEM"="E"."EE_NUM" AND "T"."TYPEELEM"='eg')
 268 - access("E"."EE_REFTIE"="I"."REFINDIVIDU")
 270 - access("TCL"."REFINDIVIDU"="CL"."REFINDIVIDU")
 272 - access("ACL"."REFINDIVIDU"="CL"."REFINDIVIDU")
 273 - filter((1=1 AND SUM("E_DOS"."EE_CHE")>=:B2 AND SUM("E_DOS"."EE_CHE")<=:B3))
 275 - filter(TO_DATE(:B5,'YYYY-MM-DD')>=TO_DATE(:B4,'YYYY-MM-DD'))
 283 - filter((NVL("E"."EE_MAITRE",'#')='REGLEMENT' AND NVL("E"."EE_DOS",'#')='GLOBAL'))
 284 - access("E"."EE_FINDTECH_DT">=TO_DATE(:B4,'YYYY-MM-DD') AND "E"."EE_FINDTECH_DT"<=TO_DATE(:B5,'YYYY-MM-DD'))
 289 - filter('AL'=:B1)
 291 - access("VALEUR"="E"."EE_REGL" AND "TYPE"='MOYENPAIMT')
 292 - filter('AN'=:B1)
 294 - access("VALEUR"="E"."EE_REGL" AND "TYPE"='MOYENPAIMT')
 295 - filter('ES'=:B1)
 297 - access("VALEUR"="E"."EE_REGL" AND "TYPE"='MOYENPAIMT')
 298 - filter('FR'=:B1)
 300 - access("VALEUR"="E"."EE_REGL" AND "TYPE"='MOYENPAIMT')
 301 - filter('IT'=:B1)
 303 - access("VALEUR"="E"."EE_REGL" AND "TYPE"='MOYENPAIMT')
 305 - access("E"."EE_REFTIE"="I"."REFINDIVIDU")
 307 - access("E"."EE_NUM"="E_DOS"."EE_MAITRE")
 308 - filter(("EN"."REFDOSS"="E_DOS"."EE_DOS" AND "EN"."TYPENCAISS"='Enregistrement'))
 309 - access("EN"."REFPIECE"="E_DOS"."EE_NUM")
       filter("EN"."REFPIECE" IS NOT NULL)
 316 - access("CPT"."REFDOSS"="EN"."REFDOSS")
       filter("CPT"."REFLOT" IS NOT NULL)
 317 - access("DCPT"."REFDOSS"="CPT"."REFLOT")
       filter("DCPT"."REFLOT" IS NOT NULL)
 318 - access("CTR"."REFDOSS"="DCPT"."REFLOT")
 321 - filter(("DCPT"."CATEGDOSS" LIKE 'DECOMPTE%' AND "DCPT"."REFLOT" IS NOT NULL))
 322 - access("DCPT"."REFDOSS"="EN"."REFDOSS")
 324 - access("CTR"."REFDOSS"="DCPT"."REFLOT")
 325 - filter("CTR"."CATEGDOSS" LIKE 'CONTRAT%')
 326 - access("CTR"."REFDOSS"="EN"."REFDOSS")
 327 - access("E_DOS"."EE_NUM"="T"."REFELEM" AND "T"."TYPEELEM"='eg')
 328 - filter("E_DOS"."EE_DOS"="T"."REFDOSS")
 330 - access("MAIN_QUERY"."NAMCOL_REF"="NC"."COMPOSTAGE")
 332 - access("MAIN_QUERY"."RANGMT"="GP"."REFPERSO")
 334 - access("MAIN_QUERY"."MONREF"="CRM"."REFPERSO")
 335 - filter("MAIN_QUERY"."REFDOSSIER"="BAL"."REFDOSS")
 336 - access("MAIN_QUERY"."REFER"="BAL"."REFELEM" AND "MAIN_QUERY"."TYPEELEM"="BAL"."TYPEELEM")
 341 - filter('AL'=:B1)
 343 - access("TYPE"='DV_IDENT_CODES')
 344 - filter('AN'=:B1)
 346 - access("TYPE"='DV_IDENT_CODES')
 347 - filter('ES'=:B1)
 349 - access("TYPE"='DV_IDENT_CODES')
 350 - filter('FR'=:B1)
 352 - access("TYPE"='DV_IDENT_CODES')
 353 - filter('IT'=:B1)
 355 - access("TYPE"='DV_IDENT_CODES')
 360 - filter('AL'=:B1)
 362 - access("TYPE"='STATUT_PAIEMENT')
 363 - filter('AN'=:B1)
 365 - access("TYPE"='STATUT_PAIEMENT')
 366 - filter('ES'=:B1)
 368 - access("TYPE"='STATUT_PAIEMENT')
 369 - filter('FR'=:B1)
 371 - access("TYPE"='STATUT_PAIEMENT')
 372 - filter('IT'=:B1) 
*/
/********************************OLD Metrics***************************************/

/********************************New SQL*******************************************/

SELECT *
  FROM (SELECT /*+ first_rows(201)*/
         foo.*, ROWNUM rnum
          FROM (SELECT referEncaiss referEncaiss,
                       typeElem typeElem,
                       (SELECT chemin
                          FROM v_tdomaine
                         WHERE TYPE = 'NAM_COLLECTE'
                           AND abrev = SUBSTR(compostage, 1, 3)
                           AND langue = :B1
                           AND ROWNUM = 1) bookCode,
                       SUM(amountAllocatedPaymentAccount) OVER() totalAmountMouvements,
                       receptionDate receptionDate,
                       dtconfirm_dt dtconfirm_dt,
                       clientName clientName,
                       vcsNumber vcsNumber,
                       fg19 fg19,
                       slipNumber slipNumber,
                       externalCase externalCase,
                       paymentSource paymentSource,
                       encaissAmount encaissAmount,
                       displayPaymentType displayPaymentType,
                       additionalCommunication additionalCommunication,
                       algorithmResult algorithmResult,
                       paymentType paymentType,
                       paymentIdentification paymentIdentification,
                       amountAllocatedPayment amountAllocatedPayment,
                       internalCaseReference internalCaseReference,
                       COUNT(1) OVER() totalNumberMouvements,
                       balance balance,
                       payerReference payerReference,
                       imxUserId imxUserId,
                       payerName payerName,
                       caseManagerName caseManagerName,
                       batchSearch batchSearch,
                       transStatus transStatus,
                       paymentStatus paymentStatus,
                       cancelationDate cancelationDate,
                       comments comments,
                       amountAllocatedPaymentAccount amountAllocatedPaymentAccount,
                       paymentReference paymentReference,
                       stampingNumber stampingNumber,
                       crmManager crmManager,
                       masterStampingNumber masterStampingNumber,
                       paymentTitle paymentTitle,
                       initialAmount initialAmount,
                       displayPaymentMethod displayPaymentMethod,
                       paymentMethod paymentMethod,
                       messages messages,
                       paymentDate paymentDate,
                       paymentCurrency paymentCurrency,
                       secondComment secondComment,
                       dtcompt dtcompt,
                       balanceCurrency balanceCurrency
                  FROM (SELECT main_query.refer referEncaiss,
                               main_query.refdossier internalCaseReference,
                               main_query.montant_dos encaissAmount,
                               main_query.date1 paymentDate,
                               main_query.refindividu payerReference,
                               main_query.date2 receptionDate,
                               main_query.type_enc paymentType,
                               main_query.type_enc_aff displayPaymentType,
                               main_query.libelle paymentTitle,
                               main_query.nom_payeur payerName,
                               main_query.mont_mvt amountAllocatedPayment,
                               main_query.mont_enc amountAllocatedPaymentAccount,
                               main_query.mont_init initialAmount,
                               main_query.dev_init paymentCurrency,
                               main_query.slipNumber,
                               main_query.num_vcs vcsNumber,
                               main_query.moyp paymentMethod,
                               main_query.moyp_trad displayPaymentMethod,
                               main_query.num_cheque paymentReference,
                               main_query.annul_dt cancelationDate,
                               main_query.typeelem typeElem,
                               main_query.source_pmt paymentSource,
                               main_query.rangmt imxUserId,
                               main_query.monref,
                               main_query.dtconfirm_dt,
                               main_query.clientName,
                               main_query.fg19,
                               main_query.refer_doss externalCase,
                               main_query.dtcompt,
                               main_query.namcol_ref stampingNumber,
                               gp.login caseManagerName,
                               nc.dtlot batchSearch,
                               nc.comm paymentIdentification,
                               nc.comm2 secondComment,
                               nc.master_compostage masterStampingNumber,
                               nc.compostage,
                               nc.devise,
                               nc.etat transStatus,
                               v2.valeur_trad algorithmResult,
                               nc.comments,
                               DECODE(To_Char(nc.messages), NULL, 'N', 'O') additionalCommunication,
                               crm.login crmManager,
                               v3.valeur_trad paymentStatus,
                               bal.refelem refelemBal,
                               bal.refdoss refdossBal,
                               bal.typeelem typeelemBal,
                               bal.libelle libelleBal,
                               bal.montant_dos montant_dosBal,
                               nc.montant montantNc,
                               nc.messages messages,
                               CASE
                                 WHEN main_query.refdossier IS NULL THEN
                                  nc.montant
                                 WHEN upper(bal.libelle) LIKE
                                      'DELAI AVANT ENCAISSEMENT%' THEN
                                  (SELECT NVL(abs(bal.montant_dos), 0) -
                                          NVL((SELECT ftr_match.partprelettrpmt(bal.refelem,
                                                                               bal.refdoss,
                                                                               bal.typeelem)
                                                FROM dual),
                                              0)
                                     FROM dual)
                                 ELSE
                                  (SELECT NVL(ABS(bal.montant_dos), 0) -
                                          NVL((SELECT SUM(NVL(ABS(montant_dos), 0))
                                                FROM g_venelem
                                               WHERE refencaiss = bal.refelem
                                                 AND refdoss = bal.refdoss
                                                 AND typencaiss = bal.typeelem),
                                              0)
                                     FROM dual)
                               END balance,
                               DECODE(main_query.refdossier,
                                      NULL,
                                      nc.devise,
                                      (SELECT devise
                                         FROM g_dossier
                                        WHERE refdoss = main_query.refdossier)) balanceCurrency
                          FROM (SELECT /*+ leading(en) index(en G_ENC_FUNC_DTREC_DTENC) use_nl(t) */
                                       en.refencaiss REFER,
                                       t.REFDOSS REFDOSSIER,
                                       ven.montant_dos montant_dos,
                                       t.dtassoc_dt DATE1,
                                       NVL(en.dtreception_dt, en.dtencaiss_dt) DATE2,
                                       'ENCAISSEMENT DEBITEUR' TYPE_ENC,
                                       'Debtor Collection' TYPE_ENC_AFF,
                                       NVL(v1.valeur_trad, EN.libelle) libelle,
                                       DECODE(i.prenom,
                                              NULL,
                                              i.nom,
                                              i.nom || ' ' || i.prenom) NOM_PAYEUR,
                                       I.refindividu,
                                       ven.montant_mvt MONT_MVT,
                                       t.montant MONT_ENC,
                                       NVL(DECODE(nc.signe, 1, -1, 1) *
                                           nc.montant,
                                           en.montant_mvt) MONT_INIT,
                                       NVL(nc.devise, en.devise_mvt) dev_INIT,
                                       EN.no_ordre slipNumber,
                                       EN.num_vcs num_vcs,
                                       EN.moyenpaimt MOYP,
                                       moy.valeur_trad MOYP_TRAD,
                                       EN.numchq NUM_CHEQUE,
                                       Nvl(en.dtannul_dt, en.dtimpaye_dt) annul_dt,
                                       t.TYPEELEM typeelem,
                                       'ENCAISS' source_pmt,
                                       d.rangmt rangmt,
                                       (SELECT ctr.monref
                                          FROM g_dossier ctr,
                                               g_dossier dcpt,
                                               g_dossier cpt
                                         WHERE ctr.refdoss = dcpt.reflot
                                           AND dcpt.refdoss = cpt.reflot
                                           AND cpt.refdoss = d.refdoss
                                        UNION
                                        SELECT ctr.monref
                                          FROM g_dossier ctr, g_dossier dcpt
                                         WHERE ctr.refdoss = dcpt.reflot
                                           AND dcpt.refdoss = d.refdoss
                                           AND dcpt.categdoss LIKE 'DECOMPTE%'
                                        UNION
                                        SELECT ctr.monref
                                          FROM g_dossier ctr
                                         WHERE ctr.refdoss = d.refdoss
                                           AND ctr.categdoss LIKE 'CONTRAT%') monref,
                                       en.DTCONFIRM_DT DTCONFIRM_DT,
                                       CL.nom clientName,
                                       ACL.fg19,
                                       Nvl(D.ancrefdoss, t.refdoss) refer_doss,
                                       t.dtsaisie dtcompt,
                                       en.lieupaimt namcol_ref,
                                       en.refrepres,
                                       en.dtimpaye_dt
                                  FROM T_ELEMENTS t,
                                       G_ENCAISSEMENT en,
                                       g_ventilenc ven,
                                       G_INDIVIDU i,
                                       g_dossier D,
                                       t_intervenants tcl,
                                       g_individu cl,
                                       g_accords acl,
                                       nam_collecte nc,
                                       (SELECT valeur,
                                               MAX(valeur_trad) valeur_trad
                                          FROM v_tdomaine
                                         WHERE type = 'libfds'
                                           AND langue = NVL(:B1, 'FR')
                                         GROUP BY valeur) v1,
                                       (SELECT valeur,
                                               MAX(valeur_trad) valeur_trad
                                          FROM v_tdomaine
                                         WHERE type = 'MOYENPAIMT'
                                           AND langue = :B1
                                         GROUP BY valeur) moy
                                 WHERE t.refelem = en.REFENCAISS
                                   AND t.refdoss = D.refdoss
                                   AND acl.refindividu(+) = cl.refindividu
                                   AND t.refelem = ven.refencaiss(+)
                                   AND t.refdoss = ven.refdoss(+)
                                   AND t.TYPEELEM in ('en', 'vd')
                                   AND en.traite NOT IN ('9')
                                   AND en.TYPENCAISS in
                                       ('e_saencaiss', 'e_savdirect')
                                   AND EN.lieupaimt = nc.compostage(+)
                                   AND EN.moyenpaimt = moy.valeur(+)
                                   AND EN.libelle = v1.valeur(+)
                                   AND EN.REFPAYEUR = I.REFINDIVIDU
                                   AND tcl.refdoss = D.refdoss
                                   AND tcl.reftype = 'CL'
                                   AND tcl.refindividu = cl.refindividu
                                   AND NOT exists
                                 (SELECT 1
                                          FROM aggreg_t_ecrdos_nmp tnmp
                                         WHERE TNMP.refelem = ven.refencaiss
                                           AND tnmp.refdoss = ven.refdoss
                                           AND tnmp.balance_dcpt < 0)
                                   AND t.montant BETWEEN :B2 AND :B3
                                   AND NVL(en.dtencaiss_dt, en.dtreception_dt) >= to_date(:B4, 'YYYY-MM-DD')
                                   AND NVL(en.dtencaiss_dt, en.dtreception_dt) <= to_date(:B5, 'YYYY-MM-DD')
                                UNION ALL
                                SELECT /*+ leading(en) index(en G_ENC_FUNC_DTREC_DTENC) use_nl(t) */
                                 EN.refencaiss REFER,
                                 VEN.refdoss REFDOSSIER,
                                 VEN.montant_dos montant_dos,
                                 t.dtassoc_dt DATE1,
                                 NVL(en.dtreception_dt, en.dtencaiss_dt) DATE2,
                                 'RECOUVREMENT DEBITEUR NON LETTRE' TYPE_ENC,
                                 'Debtor collection not fully matched' TYPE_ENC_AFF,
                                 NVL(v1.valeur_trad, EN.libelle) libelle,
                                 i.nom || ' ' || i.prenom NOM_PAYEUR,
                                 I.refindividu,
                                 VEN.montant_mvt MONT_MVT,
                                 t.montant MONT_ENC,
                                 NVL(DECODE(nc.signe, 1, -1, 1) * nc.montant,
                                     en.montant_mvt) MONT_INIT,
                                 NVL(nc.devise, en.devise_mvt) dev_INIT,
                                 EN.no_ordre slipNumber,
                                 EN.num_vcs num_vcs,
                                 EN.moyenpaimt MOYP,
                                 moy.valeur_trad MOYP_TRAD,
                                 EN.numchq NUM_CHEQUE,
                                 Nvl(en.dtannul_dt, en.dtimpaye_dt) annul_dt,
                                 t.TYPEELEM typeelem,
                                 'ENCAISS' source_pmt,
                                 d.rangmt rangmt,
                                 (SELECT ctr.monref
                                    FROM g_dossier ctr,
                                         g_dossier deco,
                                         g_dossier cpt
                                   WHERE ctr.refdoss = deco.reflot
                                     AND deco.refdoss = cpt.reflot
                                     AND cpt.refdoss = d.refdoss
                                     AND cpt.refdoss = nc.refdoss
                                  UNION
                                  SELECT ctr.monref
                                    FROM g_dossier ctr, g_dossier dcpt
                                   WHERE ctr.refdoss = dcpt.reflot
                                     AND dcpt.refdoss = nc.refdoss
                                     AND dcpt.categdoss LIKE 'DECOMPTE%'
                                  UNION
                                  SELECT ctr.monref
                                    FROM g_dossier ctr
                                   WHERE ctr.refdoss = nc.refdoss
                                     AND ctr.categdoss LIKE 'CONTRAT%') monref,
                                 en.DTCONFIRM_DT DTCONFIRM_DT,
                                 CL.nom clientName,
                                 ACL.fg19,
                                 Nvl(D.ancrefdoss, t.refdoss) refer_doss,
                                 t.dtsaisie dtcompt,
                                 en.lieupaimt namcol_ref,
                                 en.refrepres,
                                 en.dtimpaye_dt
                                  FROM g_ventilenc VEN,
                                       g_encaissement EN,
                                       nam_collecte NC,
                                       aggreg_t_ecrdos_nmp TNMP,
                                       g_dossier D,
                                       T_ELEMENTS t,
                                       G_INDIVIDU i,
                                       t_intervenants tcl,
                                       g_individu cl,
                                       g_accords acl,
                                       (SELECT valeur,
                                               MAX(valeur_trad) valeur_trad
                                          FROM v_tdomaine
                                         WHERE type = 'libfds'
                                           AND langue = NVL(:B1, 'FR')
                                         GROUP BY valeur) v1,
                                       (SELECT valeur,
                                               MAX(valeur_trad) valeur_trad
                                          FROM v_tdomaine
                                         WHERE type = 'MOYENPAIMT'
                                           AND langue = :B1
                                         GROUP BY valeur) moy
                                 WHERE t.refelem = en.REFENCAISS
                                   AND t.refdoss = D.refdoss
                                   AND acl.refindividu(+) = cl.refindividu
                                   AND t.refelem = ven.refencaiss(+)
                                   AND t.refdoss = ven.refdoss(+)
                                   AND EN.moyenpaimt = moy.valeur(+)
                                   AND EN.libelle = v1.valeur(+)
                                   AND EN.traite = '2'
                                   AND NC.refer(+) = EN.refencaiss
                                   AND NC.compostage(+) = EN.lieupaimt
                                   AND VEN.refencaiss = TNMP.refelem
                                   AND VEN.refdoss = TNMP.refdoss
                                   AND TNMP.balance_dcpt < 0
                                   AND t.typeelem in ('en', 'vd')
                                   AND en.traite NOT IN ('9')
                                   AND en.typencaiss in
                                       ('e_saencaiss', 'e_savirmt')
                                   AND EN.REFPAYEUR = I.REFINDIVIDU
                                   AND tcl.refdoss = D.refdoss
                                   AND tcl.reftype = 'CL'
                                   AND tcl.refindividu = cl.refindividu
                                   AND t.montant BETWEEN :B2 AND :B3
                                   AND NVL(en.dtencaiss_dt, en.dtreception_dt) >= to_date(:B4, 'YYYY-MM-DD')
                                   AND NVL(en.dtencaiss_dt, en.dtreception_dt) <= to_date(:B5, 'YYYY-MM-DD')
                                UNION ALL
                                SELECT e.ee_num refer,
                                       E.EE_DOS refdossier,
                                       NULL montant_dos,
                                       NVL(E.EE_findtech_DT, E.ee_dat_dt) date1,
                                       NULL date2,
                                       'DISPONIBLE' type_enc,
                                       'Availability' type_enc_aff,
                                       NULL libelle,
                                       DECODE(i.prenom,
                                              NULL,
                                              i.nom,
                                              i.nom || ' ' || i.prenom) NOM_PAYEUR,
                                       I.refindividu,
                                       DE_MONTTC_mvt MONT_MVT,
                                       DE_MONTTC MONT_ENC,
                                       EE_CHE_MVT MONT_INIT,
                                       EN.devise_mvt dev_INIT,
                                       EN.no_ordre slipNumber,
                                       E.num_vcs num_vcs,
                                       E.EE_REGL MOYP,
                                       moy.valeur_trad MOYP_TRAD,
                                       E.EE_NOC NUM_CHEQUE,
                                       E.ee_ann_dt annul_dt,
                                       NULL typeelem,
                                       'ENTENR_DOS' source_pmt,
                                       d.rangmt rangmt,
                                       (SELECT ctr.monref
                                          FROM g_dossier ctr,
                                               g_dossier dcpt,
                                               g_dossier cpt
                                         WHERE ctr.refdoss = dcpt.reflot
                                           AND dcpt.refdoss = cpt.reflot
                                           AND cpt.refdoss = d.refdoss
                                        UNION
                                        SELECT ctr.monref
                                          FROM g_dossier ctr, g_dossier dcpt
                                         WHERE ctr.refdoss = dcpt.reflot
                                           AND dcpt.refdoss = d.refdoss
                                           AND dcpt.categdoss LIKE 'DECOMPTE%'
                                        UNION
                                        SELECT ctr.monref
                                          FROM g_dossier ctr
                                         WHERE ctr.refdoss = d.refdoss
                                           AND ctr.categdoss LIKE 'CONTRAT%') monref,
                                       f_Detenr.dtconfirm_dt dtconfirm_dt,
                                       cl.nom clientName,
                                       acl.fg19,
                                       Nvl(D.ancrefdoss, t.refdoss) refer_doss,
                                       t.dtsaisie dtcompt,
                                       E.ee_finfact namcol_ref,
                                       en.refrepres,
                                       en.dtimpaye_dt
                                  FROM f_detenr,
                                       f_entenr E,
                                       G_INDIVIDU I,
                                       f_parenr,
                                       g_encaissement EN,
                                       g_dossier D,
                                       t_intervenants tcl,
                                       g_individu cl,
                                       g_accords acl,
                                       t_elements t,
                                       (SELECT valeur,
                                               MAX(valeur_trad) valeur_trad
                                          FROM v_tdomaine
                                         WHERE type = 'MOYENPAIMT'
                                           AND langue = :B1
                                         GROUP BY valeur) moy
                                 WHERE E.EE_NUM = DE_NUM
                                   AND EN.typencaiss = 'Enregistrement'
                                   AND EN.refpiece = E.ee_num
                                   AND en.refdoss = d.refdoss
                                   AND de_nom = pe_nom
                                   AND T.refelem = E.ee_num
                                   AND E.EE_REGL = moy.valeur(+)
                                   AND T.typeelem = 'eg'
                                   AND de_nte IS NOT NULL
                                   AND E.EE_REFTIE = I.REFINDIVIDU
                                   AND tcl.refdoss = D.refdoss
                                   AND tcl.reftype = 'CL'
                                   AND tcl.refindividu = cl.refindividu
                                   AND acl.refindividu(+) = cl.refindividu
                                   AND E.ee_maitre IS NULL
                                   AND pe_cpt like 'KMTR%'
                                   AND de_monttc BETWEEN :B2 AND :B3
                                   AND e.ee_findtech_dt >= to_date(:B4, 'YYYY-MM-DD')
                                   AND e.ee_findtech_dt <= to_date(:B5, 'YYYY-MM-DD')
                                UNION ALL
                                SELECT E.ee_num REFER,
                                       'REPART CHQ' REFDOSSIER,
                                       NULL montant_dos,
                                       E.ee_findtech_dt DATE1,
                                       NULL DATE2,
                                       'DISPONIBLE' TYPE_ENC,
                                       TRIM('Availability') TYPE_ENC_AFF,
                                       NULL libelle,
                                       TRIM(DECODE(i.prenom,
                                                   NULL,
                                                   i.nom,
                                                   i.nom || ' ' || i.prenom)) NOM_PAYEUR,
                                       I.refindividu,
                                       SUM(e_dos.ee_che_mvt) MONT_MVT,
                                       SUM(e_dos.ee_che) MONT_ENC,
                                       SUM(e_dos.ee_che_mvt) MONT_INIT,
                                       MAX(en.devise_mvt) dev_INIT,
                                       MAX(en.no_ordre) slipNumber,
                                       E.num_vcs num_vcs,
                                       E.ee_regl MOYP,
                                       moy.valeur_trad MOYP_TRAD,
                                       E.ee_noc NUM_CHEQUE,
                                       E.ee_ann_dt annul_dt,
                                       NULL typeelem,
                                       'ENTENR_GL' source_pmt,
                                       E.ee_refperso rangmt,
                                       ctr.monref monref,
                                       NULL DTCONFIRM_DT,
                                       'see_conf_cl' clientName,
                                       'see_cod_fg19' fg19,
                                       null refer_doss,
                                       MAX(t.dtsaisie) dtcompt,
                                       E.ee_finfact namcol_ref,
                                       en.refrepres,
                                       en.dtimpaye_dt
                                  FROM F_ENTENR E,
                                       F_ENTENR e_dos,
                                       G_INDIVIDU I,
                                       g_encaissement EN,
                                       t_elements t,
                                       (SELECT valeur,
                                               MAX(valeur_trad) valeur_trad
                                          FROM v_tdomaine
                                         WHERE type = 'MOYENPAIMT'
                                           AND langue = :B1
                                         GROUP BY valeur) moy,
                                       (SELECT cpt.refdoss, ctr.monref
                                          FROM g_dossier ctr,
                                               g_dossier dcpt,
                                               g_dossier cpt
                                         WHERE ctr.refdoss = dcpt.reflot
                                           AND dcpt.refdoss = cpt.reflot
                                        UNION
                                        SELECT dcpt.refdoss, ctr.monref
                                          FROM g_dossier ctr, g_dossier dcpt
                                         WHERE ctr.refdoss = dcpt.reflot
                                           AND dcpt.categdoss LIKE 'DECOMPTE%'
                                        UNION
                                        SELECT ctr.refdoss, ctr.monref
                                          FROM g_dossier ctr
                                         WHERE ctr.categdoss LIKE 'CONTRAT%') ctr
                                 WHERE NVL(E.ee_dos, '#') = 'GLOBAL'
                                   AND NVL(E.ee_maitre, '#') = 'REGLEMENT'
                                   AND E.ee_num = e_dos.ee_maitre
                                   AND en.refdoss = e_dos.ee_dos
                                   AND en.refpiece = e_dos.ee_num
                                   AND en.typencaiss = 'Enregistrement'
                                   AND e_dos.ee_dos = t.refdoss
                                   AND e_dos.ee_num = t.refelem
                                   AND E.ee_regl = moy.valeur(+)
                                   AND en.refdoss = ctr.refdoss
                                   AND T.typeelem = 'eg'
                                   AND e.ee_reftie = i.refindividu
                                   AND e.ee_findtech_dt >= to_date(:B4, 'YYYY-MM-DD')
                                   AND e.ee_findtech_dt <= to_date(:B5, 'YYYY-MM-DD')
                                 GROUP BY E.ee_num,
                                          'REPART CHQ',
                                          NULL,
                                          E.ee_findtech_dt,
                                          NULL,
                                          'DISPONIBLE',
                                          TRIM('Availability'),
                                          NULL,
                                          TRIM(DECODE(i.prenom,
                                                      NULL,
                                                      i.nom,
                                                      i.nom || ' ' || i.prenom)),
                                          I.refindividu,
                                          E.num_vcs,
                                          E.ee_regl,
                                          moy.valeur_trad,
                                          E.ee_noc,
                                          E.ee_ann_dt,
                                          NULL,
                                          'ENTENR_GL',
                                          E.ee_refperso,
                                          ctr.monref,
                                          NULL,
                                          'see_conf_cl',
                                          'see_cod_fg19',
                                          null,
                                          E.ee_finfact,
                                          en.refrepres,
                                          en.dtimpaye_dt
                                HAVING 1 = 1 AND SUM(e_dos.ee_che) >= :B2 AND SUM(e_dos.ee_che) <= :B3) main_query,
                               nam_collecte nc,
                               g_personnel gp,
                               t_elements bal,
                               (SELECT abrev, MAX(valeur_trad) valeur_trad
                                  FROM v_tdomaine
                                 WHERE type = 'DV_IDENT_CODES'
                                   AND langue = :B1
                                 GROUP BY abrev) v2,
                               (SELECT abrev, MAX(valeur_trad) valeur_trad
                                  FROM v_tdomaine
                                 WHERE type = 'STATUT_PAIEMENT'
                                   AND langue = :B1
                                 GROUP BY abrev) v3,
                               g_personnel crm
                         WHERE main_query.namcol_ref = nc.compostage(+)
                           AND main_query.rangmt = gp.refperso(+)
                           AND main_query.monref = crm.refperso(+)
                           AND nc.traite = v2.abrev(+)
                           AND main_query.refer = bal.refelem(+)
                           AND main_query.refdossier = bal.refdoss(+)
                           AND main_query.typeelem = bal.typeelem(+)
                           AND DECODE(main_query.refrepres,
                                      NULL,
                                      DECODE(main_query.dtimpaye_dt,
                                             NULL,
                                             'ENCAISSE',
                                             'IMPAYE'),
                                      'REPRESENTE') = v3.abrev(+))
                 WHERE 1 = 1
                 ORDER BY paymentType,
                          DECODE(internalCaseReference,
                                 'REPART CHQ',
                                 'REPART CHQ',
                                 TO_NUMBER(internalCaseReference)),
                          paymentDate,
                          internalCaseReference) foo
         WHERE ROWNUM <= :B6)
 WHERE 1 = 1
   AND rnum >= :B7;

/********************************New SQL*******************************************/
/********************************New Metrics***************************************/
/*
Plan hash value: 83030549
------------------------------------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                                    | Name                    | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  |
------------------------------------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                                             |                         |      1 |        |   544 (100)|     13 |00:00:01.00 |   11044 |    242 |
|*  1 |  COUNT STOPKEY                                               |                         |     13 |        |            |     13 |00:00:00.01 |      36 |      1 |
|   2 |   VIEW                                                       | V_TDOMAINE              |     13 |      5 |     5   (0)|     13 |00:00:00.01 |      36 |      1 |
|   3 |    UNION-ALL                                                 |                         |     13 |        |            |     13 |00:00:00.01 |      36 |      1 |
|*  4 |     FILTER                                                   |                         |     13 |        |            |      0 |00:00:00.01 |       0 |      0 |
|   5 |      TABLE ACCESS BY INDEX ROWID BATCHED                     | V_DOMAINE               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*  6 |       INDEX RANGE SCAN                                       | DOM_TYPABREV            |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*  7 |     FILTER                                                   |                         |     13 |        |            |     13 |00:00:00.01 |      36 |      1 |
|   8 |      TABLE ACCESS BY INDEX ROWID BATCHED                     | V_DOMAINE               |     13 |      1 |     1   (0)|     13 |00:00:00.01 |      36 |      1 |
|*  9 |       INDEX RANGE SCAN                                       | DOM_TYPABREV            |     13 |      1 |     1   (0)|     13 |00:00:00.01 |      23 |      1 |
|* 10 |     FILTER                                                   |                         |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  11 |      TABLE ACCESS BY INDEX ROWID BATCHED                     | V_DOMAINE               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 12 |       INDEX RANGE SCAN                                       | DOM_TYPABREV            |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 13 |     FILTER                                                   |                         |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  14 |      TABLE ACCESS BY INDEX ROWID BATCHED                     | V_DOMAINE               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 15 |       INDEX RANGE SCAN                                       | DOM_TYPABREV            |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 16 |     FILTER                                                   |                         |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  17 |      TABLE ACCESS BY INDEX ROWID BATCHED                     | V_DOMAINE               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 18 |       INDEX RANGE SCAN                                       | DOM_TYPABREV            |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|  19 |  FAST DUAL                                                   |                         |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|  20 |  FAST DUAL                                                   |                         |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|  21 |   SORT AGGREGATE                                             |                         |     13 |      1 |            |     13 |00:00:00.01 |      23 |      3 |
|* 22 |    TABLE ACCESS BY INDEX ROWID BATCHED                       | G_VENELEM               |     13 |      1 |     1   (0)|      0 |00:00:00.01 |      23 |      3 |
|* 23 |     INDEX RANGE SCAN                                         | VEN_ENCAIS              |     13 |      1 |     1   (0)|      0 |00:00:00.01 |      23 |      3 |
|  24 |   FAST DUAL                                                  |                         |     13 |      1 |     2   (0)|     13 |00:00:00.01 |       0 |      0 |
|  25 |  TABLE ACCESS BY INDEX ROWID                                 | G_DOSSIER               |     13 |      1 |     1   (0)|     13 |00:00:00.01 |      48 |      0 |
|* 26 |   INDEX UNIQUE SCAN                                          | DOS_REFDOSS             |     13 |      1 |     1   (0)|     13 |00:00:00.01 |      22 |      0 |
|* 27 |  VIEW                                                        |                         |      1 |      4 |   544   (1)|     13 |00:00:01.00 |   11044 |    242 |
|* 28 |   COUNT STOPKEY                                              |                         |      1 |        |            |     13 |00:00:01.00 |   11044 |    242 |
|  29 |    VIEW                                                      |                         |      1 |      4 |   544   (1)|     13 |00:00:01.00 |   11044 |    242 |
|  30 |     WINDOW SORT                                              |                         |      1 |      4 |   544   (1)|     13 |00:00:01.00 |   10937 |    238 |
|* 31 |      HASH JOIN OUTER                                         |                         |      1 |      4 |   518   (1)|     13 |00:00:01.00 |   10937 |    238 |
|* 32 |       HASH JOIN OUTER                                        |                         |      1 |      4 |   512   (1)|     13 |00:00:01.00 |   10935 |    237 |
|  33 |        NESTED LOOPS OUTER                                    |                         |      1 |      4 |   506   (1)|     13 |00:00:00.98 |   10857 |    176 |
|  34 |         NESTED LOOPS OUTER                                   |                         |      1 |      4 |   505   (1)|     13 |00:00:00.98 |   10826 |    176 |
|  35 |          NESTED LOOPS OUTER                                  |                         |      1 |      4 |   504   (1)|     13 |00:00:00.98 |   10813 |    176 |
|  36 |           NESTED LOOPS OUTER                                 |                         |      1 |      4 |   503   (1)|     13 |00:00:00.98 |   10803 |    176 |
|  37 |            VIEW                                              |                         |      1 |      4 |   502   (1)|     13 |00:00:00.98 |   10781 |    176 |
|  38 |             UNION-ALL                                        |                         |      1 |        |            |     13 |00:00:00.98 |   10781 |    176 |
|  39 |              SORT UNIQUE                                     |                         |      0 |      3 |     6   (0)|      0 |00:00:00.01 |       0 |      0 |
|  40 |               UNION-ALL                                      |                         |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  41 |                NESTED LOOPS                                  |                         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|  42 |                 NESTED LOOPS                                 |                         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|  43 |                  NESTED LOOPS                                |                         |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 44 |                   INDEX RANGE SCAN                           | DOS_REFDOSS_REFLOT_IDX  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 45 |                   INDEX RANGE SCAN                           | DOS_REFDOSS_REFLOT_IDX  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 46 |                  INDEX UNIQUE SCAN                           | DOS_REFDOSS             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|  47 |                 TABLE ACCESS BY INDEX ROWID                  | G_DOSSIER               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|  48 |                NESTED LOOPS                                  |                         |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 49 |                 TABLE ACCESS BY INDEX ROWID                  | G_DOSSIER               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 50 |                  INDEX UNIQUE SCAN                           | DOS_REFDOSS             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|  51 |                 TABLE ACCESS BY INDEX ROWID                  | G_DOSSIER               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 52 |                  INDEX UNIQUE SCAN                           | DOS_REFDOSS             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 53 |                TABLE ACCESS BY INDEX ROWID                   | G_DOSSIER               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 54 |                 INDEX UNIQUE SCAN                            | DOS_REFDOSS             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 55 |              FILTER                                          |                         |      1 |        |            |      0 |00:00:00.66 |    5201 |    133 |
|  56 |               NESTED LOOPS OUTER                             |                         |      1 |      1 |   226   (0)|      0 |00:00:00.66 |    5201 |    133 |
|  57 |                NESTED LOOPS OUTER                            |                         |      1 |      1 |   221   (0)|      0 |00:00:00.66 |    5201 |    133 |
|  58 |                 NESTED LOOPS                                 |                         |      1 |      1 |   216   (0)|      0 |00:00:00.66 |    5201 |    133 |
|  59 |                  NESTED LOOPS OUTER                          |                         |      1 |      1 |   215   (0)|      0 |00:00:00.66 |    5201 |    133 |
|  60 |                   NESTED LOOPS OUTER                         |                         |      1 |      1 |   214   (0)|      0 |00:00:00.66 |    5201 |    133 |
|  61 |                    NESTED LOOPS                              |                         |      1 |      1 |   213   (0)|      0 |00:00:00.66 |    5201 |    133 |
|  62 |                     NESTED LOOPS                             |                         |      1 |      1 |   212   (0)|      0 |00:00:00.66 |    5201 |    133 |
|  63 |                      NESTED LOOPS                            |                         |      1 |      3 |   211   (0)|      0 |00:00:00.66 |    5201 |    133 |
|  64 |                       NESTED LOOPS ANTI                      |                         |      1 |      3 |   210   (0)|      0 |00:00:00.66 |    5201 |    133 |
|  65 |                        NESTED LOOPS OUTER                    |                         |      1 |      5 |   209   (0)|     13 |00:00:00.66 |    5193 |    131 |
|  66 |                         NESTED LOOPS                         |                         |      1 |      5 |   208   (0)|     13 |00:00:00.63 |    5171 |    126 |
|* 67 |                          TABLE ACCESS BY INDEX ROWID BATCHED | G_ENCAISSEMENT          |      1 |   6175 |    22   (0)|   3047 |00:00:00.12 |    2158 |      4 |
|* 68 |                           INDEX RANGE SCAN                   | G_ENC_FUNC_DTREC_DTENC  |      1 |  40220 |     1   (0)|  40071 |00:00:00.01 |     158 |      0 |
|* 69 |                          TABLE ACCESS BY INDEX ROWID BATCHED | T_ELEMENTS              |   3047 |      1 |     1   (0)|     13 |00:00:00.51 |    3013 |    122 |
|* 70 |                           INDEX RANGE SCAN                   | ELE_ELEMTYPE            |   3047 |      1 |     1   (0)|   3051 |00:00:00.37 |    2688 |     24 |
|  71 |                         TABLE ACCESS BY INDEX ROWID          | G_VENTILENC             |     13 |      1 |     1   (0)|     13 |00:00:00.03 |      22 |      5 |
|* 72 |                          INDEX UNIQUE SCAN                   | VENT_REFDOSS            |     13 |      1 |     1   (0)|     13 |00:00:00.01 |       9 |      0 |
|* 73 |                        INDEX RANGE SCAN                      | PK_AGGREG_T_ECRDOS_NMP  |     13 |   4219 |     1   (0)|     13 |00:00:00.01 |       8 |      2 |
|  74 |                       TABLE ACCESS BY INDEX ROWID            | G_DOSSIER               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 75 |                        INDEX UNIQUE SCAN                     | DOS_REFDOSS             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 76 |                      INDEX RANGE SCAN                        | INT_REFDOSS             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|  77 |                     TABLE ACCESS BY INDEX ROWID              | G_INDIVIDU              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 78 |                      INDEX UNIQUE SCAN                       | IND_REFINDIV            |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|  79 |                    TABLE ACCESS BY INDEX ROWID               | G_ACCORDS               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 80 |                     INDEX UNIQUE SCAN                        | REF_ACCORD              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|  81 |                   TABLE ACCESS BY INDEX ROWID                | NAM_COLLECTE            |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 82 |                    INDEX UNIQUE SCAN                         | COLCOMPOSTAGE           |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|  83 |                  TABLE ACCESS BY INDEX ROWID                 | G_INDIVIDU              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 84 |                   INDEX UNIQUE SCAN                          | IND_REFINDIV            |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|  85 |                 VIEW PUSHED PREDICATE                        |                         |      0 |      1 |     5   (0)|      0 |00:00:00.01 |       0 |      0 |
|  86 |                  SORT GROUP BY                               |                         |      0 |      5 |     5   (0)|      0 |00:00:00.01 |       0 |      0 |
|  87 |                   VIEW                                       | V_TDOMAINE              |      0 |      5 |     5   (0)|      0 |00:00:00.01 |       0 |      0 |
|  88 |                    UNION-ALL                                 |                         |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|* 89 |                     FILTER                                   |                         |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  90 |                      TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 91 |                       INDEX RANGE SCAN                       | DOM_TYPVAL              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 92 |                     FILTER                                   |                         |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  93 |                      TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 94 |                       INDEX RANGE SCAN                       | DOM_TYPVAL              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 95 |                     FILTER                                   |                         |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  96 |                      TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 97 |                       INDEX RANGE SCAN                       | DOM_TYPVAL              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 98 |                     FILTER                                   |                         |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  99 |                      TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*100 |                       INDEX RANGE SCAN                       | DOM_TYPVAL              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*101 |                     FILTER                                   |                         |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 102 |                      TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*103 |                       INDEX RANGE SCAN                       | DOM_TYPVAL              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 104 |                VIEW PUSHED PREDICATE                         |                         |      0 |      1 |     5   (0)|      0 |00:00:00.01 |       0 |      0 |
| 105 |                 SORT GROUP BY                                |                         |      0 |      5 |     5   (0)|      0 |00:00:00.01 |       0 |      0 |
| 106 |                  VIEW                                        | V_TDOMAINE              |      0 |      5 |     5   (0)|      0 |00:00:00.01 |       0 |      0 |
| 107 |                   UNION-ALL                                  |                         |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*108 |                    FILTER                                    |                         |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 109 |                     TABLE ACCESS BY INDEX ROWID BATCHED      | V_DOMAINE               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*110 |                      INDEX RANGE SCAN                        | DOM_TYPVAL              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*111 |                    FILTER                                    |                         |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 112 |                     TABLE ACCESS BY INDEX ROWID BATCHED      | V_DOMAINE               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*113 |                      INDEX RANGE SCAN                        | DOM_TYPVAL              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*114 |                    FILTER                                    |                         |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 115 |                     TABLE ACCESS BY INDEX ROWID BATCHED      | V_DOMAINE               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*116 |                      INDEX RANGE SCAN                        | DOM_TYPVAL              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*117 |                    FILTER                                    |                         |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 118 |                     TABLE ACCESS BY INDEX ROWID BATCHED      | V_DOMAINE               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*119 |                      INDEX RANGE SCAN                        | DOM_TYPVAL              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*120 |                    FILTER                                    |                         |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 121 |                     TABLE ACCESS BY INDEX ROWID BATCHED      | V_DOMAINE               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*122 |                      INDEX RANGE SCAN                        | DOM_TYPVAL              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 123 |              SORT UNIQUE                                     |                         |     13 |      3 |     6   (0)|     13 |00:00:00.02 |     181 |      3 |
| 124 |               UNION-ALL                                      |                         |     13 |        |            |     13 |00:00:00.02 |     181 |      3 |
|*125 |                FILTER                                        |                         |     13 |        |            |     13 |00:00:00.02 |      98 |      3 |
| 126 |                 NESTED LOOPS                                 |                         |     13 |      1 |     3   (0)|     13 |00:00:00.02 |      98 |      3 |
| 127 |                  NESTED LOOPS                                |                         |     13 |      1 |     3   (0)|     13 |00:00:00.02 |      72 |      3 |
| 128 |                   NESTED LOOPS                               |                         |     13 |      1 |     2   (0)|     13 |00:00:00.02 |      50 |      3 |
|*129 |                    INDEX RANGE SCAN                          | DOS_REFDOSS_REFLOT_IDX  |     13 |      1 |     1   (0)|     13 |00:00:00.02 |      25 |      3 |
|*130 |                    INDEX RANGE SCAN                          | DOS_REFDOSS_REFLOT_IDX  |     13 |      1 |     1   (0)|     13 |00:00:00.01 |      25 |      0 |
|*131 |                   INDEX UNIQUE SCAN                          | DOS_REFDOSS             |     13 |      1 |     1   (0)|     13 |00:00:00.01 |      22 |      0 |
| 132 |                  TABLE ACCESS BY INDEX ROWID                 | G_DOSSIER               |     13 |      1 |     1   (0)|     13 |00:00:00.01 |      26 |      0 |
| 133 |                NESTED LOOPS                                  |                         |     13 |      1 |     2   (0)|      0 |00:00:00.01 |      48 |      0 |
|*134 |                 TABLE ACCESS BY INDEX ROWID                  | G_DOSSIER               |     13 |      1 |     1   (0)|      0 |00:00:00.01 |      48 |      0 |
|*135 |                  INDEX UNIQUE SCAN                           | DOS_REFDOSS             |     13 |      1 |     1   (0)|     13 |00:00:00.01 |      22 |      0 |
| 136 |                 TABLE ACCESS BY INDEX ROWID                  | G_DOSSIER               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*137 |                  INDEX UNIQUE SCAN                           | DOS_REFDOSS             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*138 |                TABLE ACCESS BY INDEX ROWID                   | G_DOSSIER               |     13 |      1 |     1   (0)|      0 |00:00:00.01 |      35 |      0 |
|*139 |                 INDEX UNIQUE SCAN                            | DOS_REFDOSS             |     13 |      1 |     1   (0)|     13 |00:00:00.01 |      22 |      0 |
|*140 |              FILTER                                          |                         |      1 |        |            |     13 |00:00:00.29 |    5397 |     39 |
| 141 |               NESTED LOOPS                                   |                         |      1 |      1 |   225   (0)|     13 |00:00:00.29 |    5397 |     39 |
| 142 |                NESTED LOOPS                                  |                         |      1 |      1 |   225   (0)|     13 |00:00:00.22 |    5387 |     32 |
| 143 |                 NESTED LOOPS OUTER                           |                         |      1 |      1 |   224   (0)|     13 |00:00:00.22 |    5372 |     32 |
| 144 |                  NESTED LOOPS OUTER                          |                         |      1 |      1 |   223   (0)|     13 |00:00:00.13 |    5350 |     18 |
| 145 |                   NESTED LOOPS OUTER                         |                         |      1 |      1 |   218   (0)|     13 |00:00:00.13 |    5314 |     18 |
| 146 |                    NESTED LOOPS OUTER                        |                         |      1 |      1 |   213   (0)|     13 |00:00:00.13 |    5291 |     17 |
| 147 |                     NESTED LOOPS                             |                         |      1 |      1 |   212   (0)|     13 |00:00:00.13 |    5287 |     16 |
| 148 |                      NESTED LOOPS                            |                         |      1 |      1 |   211   (0)|     13 |00:00:00.10 |    5260 |      6 |
| 149 |                       NESTED LOOPS                           |                         |      1 |      2 |   210   (0)|     13 |00:00:00.05 |    5232 |      0 |
| 150 |                        NESTED LOOPS                          |                         |      1 |      2 |   209   (0)|     13 |00:00:00.05 |    5206 |      0 |
| 151 |                         NESTED LOOPS                         |                         |      1 |      5 |   208   (0)|     13 |00:00:00.05 |    5198 |      0 |
| 152 |                          NESTED LOOPS                        |                         |      1 |      5 |   207   (0)|     13 |00:00:00.05 |    5176 |      0 |
|*153 | D                         TABLE ACCESS BY INDEX ROWID BATCHE | G_ENCAISSEMENT          |      1 |   6158 |    22   (0)|   3047 |00:00:00.04 |    2158 |      0 |
|*154 |                            INDEX RANGE SCAN                  | G_ENC_FUNC_DTREC_DTENC  |      1 |  40220 |     1   (0)|  40071 |00:00:00.01 |     158 |      0 |
|*155 | D                         TABLE ACCESS BY INDEX ROWID BATCHE | T_ELEMENTS              |   3047 |      1 |     1   (0)|     13 |00:00:00.01 |    3018 |      0 |
|*156 |                            INDEX RANGE SCAN                  | ELE_ELEMTYPE            |   3047 |      1 |     1   (0)|   3051 |00:00:00.01 |    2692 |      0 |
| 157 |                          TABLE ACCESS BY INDEX ROWID         | G_VENTILENC             |     13 |      1 |     1   (0)|     13 |00:00:00.01 |      22 |      0 |
|*158 |                           INDEX UNIQUE SCAN                  | VENT_REFDOSS            |     13 |      1 |     1   (0)|     13 |00:00:00.01 |       9 |      0 |
|*159 |                         INDEX RANGE SCAN                     | PK_AGGREG_T_ECRDOS_NMP  |     13 |      1 |     1   (0)|     13 |00:00:00.01 |       8 |      0 |
| 160 |                        TABLE ACCESS BY INDEX ROWID           | G_DOSSIER               |     13 |      1 |     1   (0)|     13 |00:00:00.01 |      26 |      0 |
|*161 |                         INDEX UNIQUE SCAN                    | DOS_REFDOSS             |     13 |      1 |     1   (0)|     13 |00:00:00.01 |      13 |      0 |
|*162 |                       INDEX RANGE SCAN                       | INT_REFDOSS             |     13 |      1 |     1   (0)|     13 |00:00:00.04 |      28 |      6 |
| 163 |                      TABLE ACCESS BY INDEX ROWID             | G_INDIVIDU              |     13 |      1 |     1   (0)|     13 |00:00:00.03 |      27 |     10 |
|*164 |                       INDEX UNIQUE SCAN                      | IND_REFINDIV            |     13 |      1 |     1   (0)|     13 |00:00:00.01 |      15 |      1 |
| 165 |                     TABLE ACCESS BY INDEX ROWID              | G_ACCORDS               |     13 |      1 |     1   (0)|      0 |00:00:00.01 |       4 |      1 |
|*166 |                      INDEX UNIQUE SCAN                       | REF_ACCORD              |     13 |      1 |     1   (0)|      0 |00:00:00.01 |       4 |      1 |
| 167 |                    VIEW PUSHED PREDICATE                     |                         |     13 |      1 |     5   (0)|      0 |00:00:00.01 |      23 |      1 |
| 168 |                     SORT GROUP BY                            |                         |     13 |      5 |     5   (0)|      0 |00:00:00.01 |      23 |      1 |
| 169 |                      VIEW                                    | V_TDOMAINE              |     13 |      5 |     5   (0)|      0 |00:00:00.01 |      23 |      1 |
| 170 |                       UNION-ALL                              |                         |     13 |        |            |      0 |00:00:00.01 |      23 |      1 |
|*171 |                        FILTER                                |                         |     13 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 172 |                         TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*173 |                          INDEX RANGE SCAN                    | DOM_TYPVAL              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*174 |                        FILTER                                |                         |     13 |        |            |      0 |00:00:00.01 |      23 |      1 |
| 175 |                         TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE               |     13 |      1 |     1   (0)|      0 |00:00:00.01 |      23 |      1 |
|*176 |                          INDEX RANGE SCAN                    | DOM_TYPVAL              |     13 |      1 |     1   (0)|      0 |00:00:00.01 |      23 |      1 |
|*177 |                        FILTER                                |                         |     13 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 178 |                         TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*179 |                          INDEX RANGE SCAN                    | DOM_TYPVAL              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*180 |                        FILTER                                |                         |     13 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 181 |                         TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*182 |                          INDEX RANGE SCAN                    | DOM_TYPVAL              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*183 |                        FILTER                                |                         |     13 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 184 |                         TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*185 |                          INDEX RANGE SCAN                    | DOM_TYPVAL              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 186 |                   VIEW PUSHED PREDICATE                      |                         |     13 |      1 |     5   (0)|     13 |00:00:00.01 |      36 |      0 |
| 187 |                    SORT GROUP BY                             |                         |     13 |      5 |     5   (0)|     13 |00:00:00.01 |      36 |      0 |
| 188 |                     VIEW                                     | V_TDOMAINE              |     13 |      5 |     5   (0)|     13 |00:00:00.01 |      36 |      0 |
| 189 |                      UNION-ALL                               |                         |     13 |        |            |     13 |00:00:00.01 |      36 |      0 |
|*190 |                       FILTER                                 |                         |     13 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 191 |                        TABLE ACCESS BY INDEX ROWID BATCHED   | V_DOMAINE               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*192 |                         INDEX RANGE SCAN                     | DOM_TYPVAL              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*193 |                       FILTER                                 |                         |     13 |        |            |     13 |00:00:00.01 |      36 |      0 |
| 194 |                        TABLE ACCESS BY INDEX ROWID BATCHED   | V_DOMAINE               |     13 |      1 |     1   (0)|     13 |00:00:00.01 |      36 |      0 |
|*195 |                         INDEX RANGE SCAN                     | DOM_TYPVAL              |     13 |      1 |     1   (0)|     13 |00:00:00.01 |      23 |      0 |
|*196 |                       FILTER                                 |                         |     13 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 197 |                        TABLE ACCESS BY INDEX ROWID BATCHED   | V_DOMAINE               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*198 |                         INDEX RANGE SCAN                     | DOM_TYPVAL              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*199 |                       FILTER                                 |                         |     13 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 200 |                        TABLE ACCESS BY INDEX ROWID BATCHED   | V_DOMAINE               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*201 |                         INDEX RANGE SCAN                     | DOM_TYPVAL              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*202 |                       FILTER                                 |                         |     13 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 203 |                        TABLE ACCESS BY INDEX ROWID BATCHED   | V_DOMAINE               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*204 |                         INDEX RANGE SCAN                     | DOM_TYPVAL              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*205 |                  TABLE ACCESS BY INDEX ROWID                 | NAM_COLLECTE            |     13 |      1 |     1   (0)|     13 |00:00:00.09 |      22 |     14 |
|*206 |                   INDEX UNIQUE SCAN                          | COLCOMPOSTAGE           |     13 |      1 |     1   (0)|     13 |00:00:00.01 |       9 |      2 |
|*207 |                 INDEX UNIQUE SCAN                            | IND_REFINDIV            |     13 |      1 |     1   (0)|     13 |00:00:00.01 |      15 |      0 |
| 208 |                TABLE ACCESS BY INDEX ROWID                   | G_INDIVIDU              |     13 |      1 |     1   (0)|     13 |00:00:00.07 |      10 |      7 |
| 209 |              SORT UNIQUE                                     |                         |      0 |      3 |     6   (0)|      0 |00:00:00.01 |       0 |      0 |
| 210 |               UNION-ALL                                      |                         |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 211 |                NESTED LOOPS                                  |                         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
| 212 |                 NESTED LOOPS                                 |                         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
| 213 |                  NESTED LOOPS                                |                         |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*214 |                   INDEX RANGE SCAN                           | DOS_REFDOSS_REFLOT_IDX  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*215 |                   INDEX RANGE SCAN                           | DOS_REFDOSS_REFLOT_IDX  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*216 |                  INDEX UNIQUE SCAN                           | DOS_REFDOSS             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 217 |                 TABLE ACCESS BY INDEX ROWID                  | G_DOSSIER               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 218 |                NESTED LOOPS                                  |                         |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*219 |                 TABLE ACCESS BY INDEX ROWID                  | G_DOSSIER               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*220 |                  INDEX UNIQUE SCAN                           | DOS_REFDOSS             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 221 |                 TABLE ACCESS BY INDEX ROWID                  | G_DOSSIER               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*222 |                  INDEX UNIQUE SCAN                           | DOS_REFDOSS             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*223 |                TABLE ACCESS BY INDEX ROWID                   | G_DOSSIER               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*224 |                 INDEX UNIQUE SCAN                            | DOS_REFDOSS             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*225 |              FILTER                                          |                         |      1 |        |            |      0 |00:00:00.01 |       1 |      1 |
| 226 |               NESTED LOOPS OUTER                             |                         |      1 |      1 |    15   (0)|      0 |00:00:00.01 |       1 |      1 |
| 227 |                NESTED LOOPS                                  |                         |      1 |      1 |    14   (0)|      0 |00:00:00.01 |       1 |      1 |
| 228 |                 NESTED LOOPS                                 |                         |      1 |      1 |    13   (0)|      0 |00:00:00.01 |       1 |      1 |
| 229 |                  NESTED LOOPS                                |                         |      1 |      1 |    12   (0)|      0 |00:00:00.01 |       1 |      1 |
| 230 |                   NESTED LOOPS                               |                         |      1 |      1 |    11   (0)|      0 |00:00:00.01 |       1 |      1 |
| 231 |                    NESTED LOOPS                              |                         |      1 |      1 |    10   (0)|      0 |00:00:00.01 |       1 |      1 |
| 232 |                     NESTED LOOPS                             |                         |      1 |      1 |     9   (0)|      0 |00:00:00.01 |       1 |      1 |
| 233 |                      NESTED LOOPS                            |                         |      1 |      1 |     8   (0)|      0 |00:00:00.01 |       1 |      1 |
| 234 |                       NESTED LOOPS                           |                         |      1 |      1 |     7   (0)|      0 |00:00:00.01 |       1 |      1 |
| 235 |                        NESTED LOOPS OUTER                    |                         |      1 |      1 |     6   (0)|      0 |00:00:00.01 |       1 |      1 |
|*236 |                         TABLE ACCESS BY INDEX ROWID BATCHED  | F_ENTENR                |      1 |      1 |     1   (0)|      0 |00:00:00.01 |       1 |      1 |
|*237 |                          INDEX RANGE SCAN                    | FE_EE_FINDTECH_DT       |      1 |      3 |     1   (0)|      0 |00:00:00.01 |       1 |      1 |
| 238 |                         VIEW PUSHED PREDICATE                |                         |      0 |      1 |     5   (0)|      0 |00:00:00.01 |       0 |      0 |
| 239 |                          SORT GROUP BY                       |                         |      0 |      1 |     5   (0)|      0 |00:00:00.01 |       0 |      0 |
| 240 |                           VIEW                               | V_TDOMAINE              |      0 |      5 |     5   (0)|      0 |00:00:00.01 |       0 |      0 |
| 241 |                            UNION-ALL                         |                         |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*242 |                             FILTER                           |                         |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 243 | CHED                         TABLE ACCESS BY INDEX ROWID BAT | V_DOMAINE               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*244 |                               INDEX RANGE SCAN               | DOM_TYPVAL              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*245 |                             FILTER                           |                         |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 246 | CHED                         TABLE ACCESS BY INDEX ROWID BAT | V_DOMAINE               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*247 |                               INDEX RANGE SCAN               | DOM_TYPVAL              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*248 |                             FILTER                           |                         |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 249 | CHED                         TABLE ACCESS BY INDEX ROWID BAT | V_DOMAINE               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*250 |                               INDEX RANGE SCAN               | DOM_TYPVAL              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*251 |                             FILTER                           |                         |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 252 | CHED                         TABLE ACCESS BY INDEX ROWID BAT | V_DOMAINE               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*253 |                               INDEX RANGE SCAN               | DOM_TYPVAL              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*254 |                             FILTER                           |                         |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 255 | CHED                         TABLE ACCESS BY INDEX ROWID BAT | V_DOMAINE               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*256 |                               INDEX RANGE SCAN               | DOM_TYPVAL              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*257 |                        TABLE ACCESS BY INDEX ROWID BATCHED   | F_DETENR                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*258 |                         INDEX RANGE SCAN                     | DETENR_NUM              |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*259 |                       TABLE ACCESS BY INDEX ROWID            | F_PARENR                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*260 |                        INDEX UNIQUE SCAN                     | PARENR_CL1              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*261 |                      TABLE ACCESS BY INDEX ROWID BATCHED     | G_ENCAISSEMENT          |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*262 |                       INDEX RANGE SCAN                       | ENCAISSPIECE            |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 263 |                     TABLE ACCESS BY INDEX ROWID              | G_DOSSIER               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*264 |                      INDEX UNIQUE SCAN                       | DOS_REFDOSS             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*265 |                    INDEX RANGE SCAN                          | INT_REFDOSS             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 266 |                   TABLE ACCESS BY INDEX ROWID BATCHED        | T_ELEMENTS              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*267 |                    INDEX RANGE SCAN                          | ELE_ELEMTYPE            |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 268 |                  TABLE ACCESS BY INDEX ROWID                 | G_INDIVIDU              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*269 |                   INDEX UNIQUE SCAN                          | IND_REFINDIV            |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 270 |                 TABLE ACCESS BY INDEX ROWID                  | G_INDIVIDU              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*271 |                  INDEX UNIQUE SCAN                           | IND_REFINDIV            |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 272 |                TABLE ACCESS BY INDEX ROWID                   | G_ACCORDS               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*273 |                 INDEX UNIQUE SCAN                            | REF_ACCORD              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*274 |              FILTER                                          |                         |      1 |        |            |      0 |00:00:00.01 |       1 |      0 |
| 275 |               HASH GROUP BY                                  |                         |      1 |      1 |    18  (12)|      0 |00:00:00.01 |       1 |      0 |
|*276 |                FILTER                                        |                         |      1 |        |            |      0 |00:00:00.01 |       1 |      0 |
| 277 |                 NESTED LOOPS                                 |                         |      1 |      1 |    17   (6)|      0 |00:00:00.01 |       1 |      0 |
| 278 |                  NESTED LOOPS                                |                         |      1 |      1 |    17   (6)|      0 |00:00:00.01 |       1 |      0 |
| 279 |                   NESTED LOOPS                               |                         |      1 |      1 |    16   (7)|      0 |00:00:00.01 |       1 |      0 |
| 280 |                    NESTED LOOPS                              |                         |      1 |      1 |     9   (0)|      0 |00:00:00.01 |       1 |      0 |
| 281 |                     NESTED LOOPS                             |                         |      1 |      1 |     8   (0)|      0 |00:00:00.01 |       1 |      0 |
| 282 |                      NESTED LOOPS                            |                         |      1 |      1 |     7   (0)|      0 |00:00:00.01 |       1 |      0 |
| 283 |                       NESTED LOOPS OUTER                     |                         |      1 |      1 |     6   (0)|      0 |00:00:00.01 |       1 |      0 |
|*284 |                        TABLE ACCESS BY INDEX ROWID BATCHED   | F_ENTENR                |      1 |      1 |     1   (0)|      0 |00:00:00.01 |       1 |      0 |
|*285 |                         INDEX RANGE SCAN                     | FE_EE_FINDTECH_DT       |      1 |      3 |     1   (0)|      0 |00:00:00.01 |       1 |      0 |
| 286 |                        VIEW PUSHED PREDICATE                 |                         |      0 |      1 |     5   (0)|      0 |00:00:00.01 |       0 |      0 |
| 287 |                         SORT GROUP BY                        |                         |      0 |      5 |     5   (0)|      0 |00:00:00.01 |       0 |      0 |
| 288 |                          VIEW                                | V_TDOMAINE              |      0 |      5 |     5   (0)|      0 |00:00:00.01 |       0 |      0 |
| 289 |                           UNION-ALL                          |                         |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*290 |                            FILTER                            |                         |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 291 | HED                         TABLE ACCESS BY INDEX ROWID BATC | V_DOMAINE               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*292 |                              INDEX RANGE SCAN                | DOM_TYPVAL              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*293 |                            FILTER                            |                         |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 294 | HED                         TABLE ACCESS BY INDEX ROWID BATC | V_DOMAINE               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*295 |                              INDEX RANGE SCAN                | DOM_TYPVAL              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*296 |                            FILTER                            |                         |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 297 | HED                         TABLE ACCESS BY INDEX ROWID BATC | V_DOMAINE               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*298 |                              INDEX RANGE SCAN                | DOM_TYPVAL              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*299 |                            FILTER                            |                         |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 300 | HED                         TABLE ACCESS BY INDEX ROWID BATC | V_DOMAINE               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*301 |                              INDEX RANGE SCAN                | DOM_TYPVAL              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*302 |                            FILTER                            |                         |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 303 | HED                         TABLE ACCESS BY INDEX ROWID BATC | V_DOMAINE               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*304 |                              INDEX RANGE SCAN                | DOM_TYPVAL              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 305 |                       TABLE ACCESS BY INDEX ROWID            | G_INDIVIDU              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*306 |                        INDEX UNIQUE SCAN                     | IND_REFINDIV            |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 307 |                      TABLE ACCESS BY INDEX ROWID BATCHED     | F_ENTENR                |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*308 |                       INDEX RANGE SCAN                       | ENTENR_MAITRE           |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*309 |                     TABLE ACCESS BY INDEX ROWID BATCHED      | G_ENCAISSEMENT          |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*310 |                      INDEX RANGE SCAN                        | ENCAISSPIECE            |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 311 |                    VIEW                                      |                         |      0 |      1 |     7  (15)|      0 |00:00:00.01 |       0 |      0 |
| 312 |                     SORT UNIQUE                              |                         |      0 |      3 |     7  (15)|      0 |00:00:00.01 |       0 |      0 |
| 313 |                      UNION ALL PUSHED PREDICATE              |                         |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 314 |                       NESTED LOOPS                           |                         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
| 315 |                        NESTED LOOPS                          |                         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
| 316 |                         NESTED LOOPS                         |                         |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*317 |                          INDEX RANGE SCAN                    | DOS_REFDOSS_REFLOT_IDX  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*318 |                          INDEX RANGE SCAN                    | DOS_REFDOSS_REFLOT_IDX  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*319 |                         INDEX UNIQUE SCAN                    | DOS_REFDOSS             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 320 |                        TABLE ACCESS BY INDEX ROWID           | G_DOSSIER               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 321 |                       NESTED LOOPS                           |                         |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*322 |                        TABLE ACCESS BY INDEX ROWID           | G_DOSSIER               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*323 |                         INDEX UNIQUE SCAN                    | DOS_REFDOSS             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 324 |                        TABLE ACCESS BY INDEX ROWID           | G_DOSSIER               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*325 |                         INDEX UNIQUE SCAN                    | DOS_REFDOSS             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*326 |                       TABLE ACCESS BY INDEX ROWID            | G_DOSSIER               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*327 |                        INDEX UNIQUE SCAN                     | DOS_REFDOSS             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*328 |                   INDEX RANGE SCAN                           | ELE_ELEMTYPE            |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*329 |                  TABLE ACCESS BY INDEX ROWID                 | T_ELEMENTS              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 330 |            TABLE ACCESS BY INDEX ROWID                       | NAM_COLLECTE            |     13 |      1 |     1   (0)|     13 |00:00:00.01 |      22 |      0 |
|*331 |             INDEX UNIQUE SCAN                                | COLCOMPOSTAGE           |     13 |      1 |     1   (0)|     13 |00:00:00.01 |       9 |      0 |
| 332 |           TABLE ACCESS BY INDEX ROWID BATCHED                | G_PERSONNEL             |     13 |      1 |     1   (0)|     13 |00:00:00.01 |      10 |      0 |
|*333 |            INDEX RANGE SCAN                                  | GPERSREFP               |     13 |      1 |     1   (0)|     13 |00:00:00.01 |       3 |      0 |
| 334 |          TABLE ACCESS BY INDEX ROWID BATCHED                 | G_PERSONNEL             |     13 |      1 |     1   (0)|     13 |00:00:00.01 |      13 |      0 |
|*335 |           INDEX RANGE SCAN                                   | GPERSREFP               |     13 |      1 |     1   (0)|     13 |00:00:00.01 |       3 |      0 |
|*336 |         TABLE ACCESS BY INDEX ROWID BATCHED                  | T_ELEMENTS              |     13 |      1 |     1   (0)|     13 |00:00:00.01 |      31 |      0 |
|*337 |          INDEX RANGE SCAN                                    | ELE_ELEMTYPE            |     13 |      1 |     1   (0)|     13 |00:00:00.01 |      27 |      0 |
| 338 |        VIEW                                                  |                         |      1 |     36 |     6  (17)|    166 |00:00:00.02 |      78 |     61 |
| 339 |         HASH GROUP BY                                        |                         |      1 |     36 |     6  (17)|    166 |00:00:00.02 |      78 |     61 |
| 340 |          VIEW                                                | V_TDOMAINE              |      1 |    180 |     5   (0)|    166 |00:00:00.02 |      78 |     61 |
| 341 |           UNION-ALL                                          |                         |      1 |        |            |    166 |00:00:00.02 |      78 |     61 |
|*342 |            FILTER                                            |                         |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 343 |             TABLE ACCESS BY INDEX ROWID BATCHED              | V_DOMAINE               |      0 |     36 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*344 |              INDEX RANGE SCAN                                | V_DOMAINE_TYPE_CODE_IDX |      0 |     36 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*345 |            FILTER                                            |                         |      1 |        |            |    166 |00:00:00.02 |      78 |     61 |
| 346 |             TABLE ACCESS BY INDEX ROWID BATCHED              | V_DOMAINE               |      1 |     36 |     1   (0)|    166 |00:00:00.02 |      78 |     61 |
|*347 |              INDEX RANGE SCAN                                | V_DOMAINE_TYPE_CODE_IDX |      1 |     36 |     1   (0)|    166 |00:00:00.01 |       3 |      2 |
|*348 |            FILTER                                            |                         |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 349 |             TABLE ACCESS BY INDEX ROWID BATCHED              | V_DOMAINE               |      0 |     36 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*350 |              INDEX RANGE SCAN                                | V_DOMAINE_TYPE_CODE_IDX |      0 |     36 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*351 |            FILTER                                            |                         |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 352 |             TABLE ACCESS BY INDEX ROWID BATCHED              | V_DOMAINE               |      0 |     36 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*353 |              INDEX RANGE SCAN                                | V_DOMAINE_TYPE_CODE_IDX |      0 |     36 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*354 |            FILTER                                            |                         |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 355 |             TABLE ACCESS BY INDEX ROWID BATCHED              | V_DOMAINE               |      0 |     36 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*356 |              INDEX RANGE SCAN                                | V_DOMAINE_TYPE_CODE_IDX |      0 |     36 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 357 |       VIEW                                                   |                         |      1 |     36 |     6  (17)|      0 |00:00:00.01 |       2 |      1 |
| 358 |        HASH GROUP BY                                         |                         |      1 |     36 |     6  (17)|      0 |00:00:00.01 |       2 |      1 |
| 359 |         VIEW                                                 | V_TDOMAINE              |      1 |    180 |     5   (0)|      0 |00:00:00.01 |       2 |      1 |
| 360 |          UNION-ALL                                           |                         |      1 |        |            |      0 |00:00:00.01 |       2 |      1 |
|*361 |           FILTER                                             |                         |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 362 |            TABLE ACCESS BY INDEX ROWID BATCHED               | V_DOMAINE               |      0 |     36 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*363 |             INDEX RANGE SCAN                                 | V_DOMAINE_TYPE_CODE_IDX |      0 |     36 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*364 |           FILTER                                             |                         |      1 |        |            |      0 |00:00:00.01 |       2 |      1 |
| 365 |            TABLE ACCESS BY INDEX ROWID BATCHED               | V_DOMAINE               |      1 |     36 |     1   (0)|      0 |00:00:00.01 |       2 |      1 |
|*366 |             INDEX RANGE SCAN                                 | V_DOMAINE_TYPE_CODE_IDX |      1 |     36 |     1   (0)|      0 |00:00:00.01 |       2 |      1 |
|*367 |           FILTER                                             |                         |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 368 |            TABLE ACCESS BY INDEX ROWID BATCHED               | V_DOMAINE               |      0 |     36 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*369 |             INDEX RANGE SCAN                                 | V_DOMAINE_TYPE_CODE_IDX |      0 |     36 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*370 |           FILTER                                             |                         |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 371 |            TABLE ACCESS BY INDEX ROWID BATCHED               | V_DOMAINE               |      0 |     36 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*372 |             INDEX RANGE SCAN                                 | V_DOMAINE_TYPE_CODE_IDX |      0 |     36 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*373 |           FILTER                                             |                         |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 374 |            TABLE ACCESS BY INDEX ROWID BATCHED               | V_DOMAINE               |      0 |     36 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*375 |             INDEX RANGE SCAN                                 | V_DOMAINE_TYPE_CODE_IDX |      0 |     36 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
------------------------------------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   1 - filter(ROWNUM=1)
   4 - filter('AL'=:B1)
   6 - access("TYPE"='NAM_COLLECTE' AND "ABREV"=SUBSTR(:B1,1,3))
   7 - filter('AN'=:B1)
   9 - access("TYPE"='NAM_COLLECTE' AND "ABREV"=SUBSTR(:B1,1,3))
  10 - filter('ES'=:B1)
  12 - access("TYPE"='NAM_COLLECTE' AND "ABREV"=SUBSTR(:B1,1,3))
  13 - filter('FR'=:B1)
  15 - access("TYPE"='NAM_COLLECTE' AND "ABREV"=SUBSTR(:B1,1,3))
  16 - filter('IT'=:B1)
  18 - access("TYPE"='NAM_COLLECTE' AND "ABREV"=SUBSTR(:B1,1,3))
  22 - filter(("REFDOSS"=:B1 AND "TYPENCAISS"=:B2))
  23 - access("REFENCAISS"=:B1)
  26 - access("REFDOSS"=:B1)
  27 - filter("RNUM">=:B7)
  28 - filter(ROWNUM<=:B6)
  31 - access("V3"."ABREV"=DECODE("MAIN_QUERY"."REFREPRES",NULL,DECODE(INTERNAL_FUNCTION("MAIN_QUERY"."DTIMPAYE_DT"),NULL,'ENCAISSE','IMPAYE'),'REPRESENTE'))
  32 - access("NC"."TRAITE"=TO_NUMBER("V2"."ABREV"))
  44 - access("CPT"."REFDOSS"=:B1)
       filter("CPT"."REFLOT" IS NOT NULL)
  45 - access("DCPT"."REFDOSS"="CPT"."REFLOT")
       filter("DCPT"."REFLOT" IS NOT NULL)
  46 - access("CTR"."REFDOSS"="DCPT"."REFLOT")
  49 - filter(("DCPT"."CATEGDOSS" LIKE 'DECOMPTE%' AND "DCPT"."REFLOT" IS NOT NULL))
  50 - access("DCPT"."REFDOSS"=:B1)
  52 - access("CTR"."REFDOSS"="DCPT"."REFLOT")
  53 - filter("CTR"."CATEGDOSS" LIKE 'CONTRAT%')
  54 - access("CTR"."REFDOSS"=:B1)
  55 - filter((:B3>=:B2 AND TO_DATE(:B5,'YYYY-MM-DD')>=TO_DATE(:B4,'YYYY-MM-DD')))
  67 - filter((INTERNAL_FUNCTION("EN"."TYPENCAISS") AND "EN"."TRAITE"<>'9'))
  68 - access("EN"."SYS_NC00237$">=TO_DATE(:B4,'YYYY-MM-DD') AND "EN"."SYS_NC00237$"<=TO_DATE(:B5,'YYYY-MM-DD'))
  69 - filter(("T"."MONTANT"<=:B3 AND "T"."MONTANT">=:B2))
  70 - access("T"."REFELEM"="EN"."REFENCAISS")
       filter(("T"."TYPEELEM"='en' OR "T"."TYPEELEM"='vd'))
  72 - access("T"."REFDOSS"="VEN"."REFDOSS" AND "T"."REFELEM"="VEN"."REFENCAISS")
  73 - access("TNMP"."REFDOSS"="VEN"."REFDOSS" AND "TNMP"."REFELEM"="VEN"."REFENCAISS")
       filter("TNMP"."BALANCE_DCPT"<0)
  75 - access("T"."REFDOSS"="D"."REFDOSS")
  76 - access("TCL"."REFDOSS"="D"."REFDOSS" AND "TCL"."REFTYPE"='CL')
  78 - access("TCL"."REFINDIVIDU"="CL"."REFINDIVIDU")
  80 - access("ACL"."REFINDIVIDU"="CL"."REFINDIVIDU")
  82 - access("EN"."LIEUPAIMT"="NC"."COMPOSTAGE")
  84 - access("EN"."REFPAYEUR"="I"."REFINDIVIDU")
  89 - filter(NVL(:B1,'FR')='AL')
  91 - access("VALEUR"="EN"."LIBELLE" AND "TYPE"='libfds')
  92 - filter(NVL(:B1,'FR')='AN')
  94 - access("VALEUR"="EN"."LIBELLE" AND "TYPE"='libfds')
  95 - filter(NVL(:B1,'FR')='ES')
  97 - access("VALEUR"="EN"."LIBELLE" AND "TYPE"='libfds')
  98 - filter(NVL(:B1,'FR')='FR')
 100 - access("VALEUR"="EN"."LIBELLE" AND "TYPE"='libfds')
 101 - filter(NVL(:B1,'FR')='IT')
 103 - access("VALEUR"="EN"."LIBELLE" AND "TYPE"='libfds')
 108 - filter('AL'=:B1)
 110 - access("VALEUR"="EN"."MOYENPAIMT" AND "TYPE"='MOYENPAIMT')
 111 - filter('AN'=:B1)
 113 - access("VALEUR"="EN"."MOYENPAIMT" AND "TYPE"='MOYENPAIMT')
 114 - filter('ES'=:B1)
 116 - access("VALEUR"="EN"."MOYENPAIMT" AND "TYPE"='MOYENPAIMT')
 117 - filter('FR'=:B1)
 119 - access("VALEUR"="EN"."MOYENPAIMT" AND "TYPE"='MOYENPAIMT')
 120 - filter('IT'=:B1)
 122 - access("VALEUR"="EN"."MOYENPAIMT" AND "TYPE"='MOYENPAIMT')
 125 - filter(:B1=:B2)
 129 - access("CPT"."REFDOSS"=:B1)
       filter("CPT"."REFLOT" IS NOT NULL)
 130 - access("DECO"."REFDOSS"="CPT"."REFLOT")
       filter("DECO"."REFLOT" IS NOT NULL)
 131 - access("CTR"."REFDOSS"="DECO"."REFLOT")
 134 - filter(("DCPT"."CATEGDOSS" LIKE 'DECOMPTE%' AND "DCPT"."REFLOT" IS NOT NULL))
 135 - access("DCPT"."REFDOSS"=:B1)
 137 - access("CTR"."REFDOSS"="DCPT"."REFLOT")
 138 - filter("CTR"."CATEGDOSS" LIKE 'CONTRAT%')
 139 - access("CTR"."REFDOSS"=:B1)
 140 - filter((TO_DATE(:B5,'YYYY-MM-DD')>=TO_DATE(:B4,'YYYY-MM-DD') AND :B3>=:B2))
 153 - filter((INTERNAL_FUNCTION("EN"."TYPENCAISS") AND "EN"."TRAITE"='2'))
 154 - access("EN"."SYS_NC00237$">=TO_DATE(:B4,'YYYY-MM-DD') AND "EN"."SYS_NC00237$"<=TO_DATE(:B5,'YYYY-MM-DD'))
 155 - filter(("T"."MONTANT"<=:B3 AND "T"."MONTANT">=:B2))
 156 - access("T"."REFELEM"="EN"."REFENCAISS")
       filter(("T"."TYPEELEM"='en' OR "T"."TYPEELEM"='vd'))
 158 - access("T"."REFDOSS"="VEN"."REFDOSS" AND "T"."REFELEM"="VEN"."REFENCAISS")
 159 - access("VEN"."REFDOSS"="TNMP"."REFDOSS" AND "VEN"."REFENCAISS"="TNMP"."REFELEM")
       filter("TNMP"."BALANCE_DCPT"<0)
 161 - access("T"."REFDOSS"="D"."REFDOSS")
 162 - access("TCL"."REFDOSS"="D"."REFDOSS" AND "TCL"."REFTYPE"='CL')
 164 - access("TCL"."REFINDIVIDU"="CL"."REFINDIVIDU")
 166 - access("ACL"."REFINDIVIDU"="CL"."REFINDIVIDU")
 171 - filter(NVL(:B1,'FR')='AL')
 173 - access("VALEUR"="EN"."LIBELLE" AND "TYPE"='libfds')
 174 - filter(NVL(:B1,'FR')='AN')
 176 - access("VALEUR"="EN"."LIBELLE" AND "TYPE"='libfds')
 177 - filter(NVL(:B1,'FR')='ES')
 179 - access("VALEUR"="EN"."LIBELLE" AND "TYPE"='libfds')
 180 - filter(NVL(:B1,'FR')='FR')
 182 - access("VALEUR"="EN"."LIBELLE" AND "TYPE"='libfds')
 183 - filter(NVL(:B1,'FR')='IT')
 185 - access("VALEUR"="EN"."LIBELLE" AND "TYPE"='libfds')
 190 - filter('AL'=:B1)
 192 - access("VALEUR"="EN"."MOYENPAIMT" AND "TYPE"='MOYENPAIMT')
 193 - filter('AN'=:B1)
 195 - access("VALEUR"="EN"."MOYENPAIMT" AND "TYPE"='MOYENPAIMT')
 196 - filter('ES'=:B1)
 198 - access("VALEUR"="EN"."MOYENPAIMT" AND "TYPE"='MOYENPAIMT')
 199 - filter('FR'=:B1)
 201 - access("VALEUR"="EN"."MOYENPAIMT" AND "TYPE"='MOYENPAIMT')
 202 - filter('IT'=:B1)
 204 - access("VALEUR"="EN"."MOYENPAIMT" AND "TYPE"='MOYENPAIMT')
 205 - filter(("NC"."REFER" IS NOT NULL AND "NC"."REFER"="EN"."REFENCAISS"))
 206 - access("NC"."COMPOSTAGE"="EN"."LIEUPAIMT")
 207 - access("EN"."REFPAYEUR"="I"."REFINDIVIDU")
 214 - access("CPT"."REFDOSS"=:B1)
       filter("CPT"."REFLOT" IS NOT NULL)
 215 - access("DCPT"."REFDOSS"="CPT"."REFLOT")
       filter("DCPT"."REFLOT" IS NOT NULL)
 216 - access("CTR"."REFDOSS"="DCPT"."REFLOT")
 219 - filter(("DCPT"."CATEGDOSS" LIKE 'DECOMPTE%' AND "DCPT"."REFLOT" IS NOT NULL))
 220 - access("DCPT"."REFDOSS"=:B1)
 222 - access("CTR"."REFDOSS"="DCPT"."REFLOT")
 223 - filter("CTR"."CATEGDOSS" LIKE 'CONTRAT%')
 224 - access("CTR"."REFDOSS"=:B1)
 225 - filter((TO_DATE(:B5,'YYYY-MM-DD')>=TO_DATE(:B4,'YYYY-MM-DD') AND :B3>=:B2))
 236 - filter("E"."EE_MAITRE" IS NULL)
 237 - access("E"."EE_FINDTECH_DT">=TO_DATE(:B4,'YYYY-MM-DD') AND "E"."EE_FINDTECH_DT"<=TO_DATE(:B5,'YYYY-MM-DD'))
 242 - filter('AL'=:B1)
 244 - access("VALEUR"="E"."EE_REGL" AND "TYPE"='MOYENPAIMT')
 245 - filter('AN'=:B1)
 247 - access("VALEUR"="E"."EE_REGL" AND "TYPE"='MOYENPAIMT')
 248 - filter('ES'=:B1)
 250 - access("VALEUR"="E"."EE_REGL" AND "TYPE"='MOYENPAIMT')
 251 - filter('FR'=:B1)
 253 - access("VALEUR"="E"."EE_REGL" AND "TYPE"='MOYENPAIMT')
 254 - filter('IT'=:B1)
 256 - access("VALEUR"="E"."EE_REGL" AND "TYPE"='MOYENPAIMT')
 257 - filter(("DE_NTE" IS NOT NULL AND "DE_MONTTC"<=:B3 AND "DE_MONTTC">=:B2))
 258 - access("E"."EE_NUM"="DE_NUM")
 259 - filter("PE_CPT" LIKE 'KMTR%')
 260 - access("DE_NOM"="PE_NOM")
 261 - filter("EN"."TYPENCAISS"='Enregistrement')
 262 - access("EN"."REFPIECE"="E"."EE_NUM")
       filter("EN"."REFPIECE" IS NOT NULL)
 264 - access("EN"."REFDOSS"="D"."REFDOSS")
 265 - access("TCL"."REFDOSS"="D"."REFDOSS" AND "TCL"."REFTYPE"='CL')
 267 - access("T"."REFELEM"="E"."EE_NUM" AND "T"."TYPEELEM"='eg')
 269 - access("E"."EE_REFTIE"="I"."REFINDIVIDU")
 271 - access("TCL"."REFINDIVIDU"="CL"."REFINDIVIDU")
 273 - access("ACL"."REFINDIVIDU"="CL"."REFINDIVIDU")
 274 - filter((1=1 AND SUM("E_DOS"."EE_CHE")>=:B2 AND SUM("E_DOS"."EE_CHE")<=:B3))
 276 - filter(TO_DATE(:B5,'YYYY-MM-DD')>=TO_DATE(:B4,'YYYY-MM-DD'))
 284 - filter((NVL("E"."EE_MAITRE",'#')='REGLEMENT' AND NVL("E"."EE_DOS",'#')='GLOBAL'))
 285 - access("E"."EE_FINDTECH_DT">=TO_DATE(:B4,'YYYY-MM-DD') AND "E"."EE_FINDTECH_DT"<=TO_DATE(:B5,'YYYY-MM-DD'))
 290 - filter('AL'=:B1)
 292 - access("VALEUR"="E"."EE_REGL" AND "TYPE"='MOYENPAIMT')
 293 - filter('AN'=:B1)
 295 - access("VALEUR"="E"."EE_REGL" AND "TYPE"='MOYENPAIMT')
 296 - filter('ES'=:B1)
 298 - access("VALEUR"="E"."EE_REGL" AND "TYPE"='MOYENPAIMT')
 299 - filter('FR'=:B1)
 301 - access("VALEUR"="E"."EE_REGL" AND "TYPE"='MOYENPAIMT')
 302 - filter('IT'=:B1)
 304 - access("VALEUR"="E"."EE_REGL" AND "TYPE"='MOYENPAIMT')
 306 - access("E"."EE_REFTIE"="I"."REFINDIVIDU")
 308 - access("E"."EE_NUM"="E_DOS"."EE_MAITRE")
 309 - filter(("EN"."REFDOSS"="E_DOS"."EE_DOS" AND "EN"."TYPENCAISS"='Enregistrement'))
 310 - access("EN"."REFPIECE"="E_DOS"."EE_NUM")
       filter("EN"."REFPIECE" IS NOT NULL)
 317 - access("CPT"."REFDOSS"="EN"."REFDOSS")
       filter("CPT"."REFLOT" IS NOT NULL)
 318 - access("DCPT"."REFDOSS"="CPT"."REFLOT")
       filter("DCPT"."REFLOT" IS NOT NULL)
 319 - access("CTR"."REFDOSS"="DCPT"."REFLOT")
 322 - filter(("DCPT"."CATEGDOSS" LIKE 'DECOMPTE%' AND "DCPT"."REFLOT" IS NOT NULL))
 323 - access("DCPT"."REFDOSS"="EN"."REFDOSS")
 325 - access("CTR"."REFDOSS"="DCPT"."REFLOT")
 326 - filter("CTR"."CATEGDOSS" LIKE 'CONTRAT%')
 327 - access("CTR"."REFDOSS"="EN"."REFDOSS")
 328 - access("E_DOS"."EE_NUM"="T"."REFELEM" AND "T"."TYPEELEM"='eg')
 329 - filter("E_DOS"."EE_DOS"="T"."REFDOSS")
 331 - access("MAIN_QUERY"."NAMCOL_REF"="NC"."COMPOSTAGE")
 333 - access("MAIN_QUERY"."RANGMT"="GP"."REFPERSO")
 335 - access("MAIN_QUERY"."MONREF"="CRM"."REFPERSO")
 336 - filter("MAIN_QUERY"."REFDOSSIER"="BAL"."REFDOSS")
 337 - access("MAIN_QUERY"."REFER"="BAL"."REFELEM" AND "MAIN_QUERY"."TYPEELEM"="BAL"."TYPEELEM")
 342 - filter('AL'=:B1)
 344 - access("TYPE"='DV_IDENT_CODES')
 345 - filter('AN'=:B1)
 347 - access("TYPE"='DV_IDENT_CODES')
 348 - filter('ES'=:B1)
 350 - access("TYPE"='DV_IDENT_CODES')
 351 - filter('FR'=:B1)
 353 - access("TYPE"='DV_IDENT_CODES')
 354 - filter('IT'=:B1)
 356 - access("TYPE"='DV_IDENT_CODES')
 361 - filter('AL'=:B1)
 363 - access("TYPE"='STATUT_PAIEMENT')
 364 - filter('AN'=:B1)
 366 - access("TYPE"='STATUT_PAIEMENT')
 367 - filter('ES'=:B1)
 369 - access("TYPE"='STATUT_PAIEMENT')
 370 - filter('FR'=:B1)
 372 - access("TYPE"='STATUT_PAIEMENT')
 373 - filter('IT'=:B1)
 375 - access("TYPE"='STATUT_PAIEMENT')
*/
/********************************New Metrics***************************************/

/********************************Index statistics**********************************/

/********************************Other SQLs****************************************/          
/*

*/ 
/********************************Other SQLs****************************************/              
