###############################################
###############################################
### Password cannot be reused workarround:

create profile chacha limit password_verify_function null;

alter profile CHACHA limit FAILED_LOGIN_ATTEMPTS UNLIMITED;

alter profile CHACHA limit PASSWORD_REUSE_MAX UNLIMITED;

alter profile CHACHA limit PASSWORD_REUSE_TIME UNLIMITED;

alter user A4ISAMCFG profile CHACHA;

alter user A4ISAMCFG  identified by "CVJMS_27774_edxxw_99422_dadjkc";

alter user A4ISAMCFG profile AUDI_TECHUSER_PROFILE;

drop profile chacha;


##############################################
#################################################


create user "DXAOPONI" identified by "y4n6zgDMJu" DEFAULT TABLESPACE TANGO_TABLES TEMPORARY TABLESPACE TEMP2 PROFILE ESL_PROFILE ACCOUNT UNLOCK;
GRANT CREATE SESSION TO DXAOPONI WITH ADMIN OPTION;
GRANT CREATE DATABASE LINK TO DXAOPONI;

iracs21.gre.omc.hp.com 


###############################################
###############################################

alter profile CHACHA limit FAILED_LOGIN_ATTEMPTS UNLIMITED;


### SEE ALL PROFILES IN A DATABASE:

set pagesize 400
set linesize 300
SELECT * FROM DBA_PROFILES ORDER BY PROFILE;



###############################################
###############################################
CHECKING USER ROLES AND PRIVILEGES:

select privilege 
from dba_sys_privs 
where grantee='ADI_ENDUSER' 
order by 1;



###############################################
###############################################
LISTING ROLES AND PRIVILEGES FOR GIVEN USER:


select granted_role from dba_role_privs where upper(grantee)='U4ARS4TS3MAN7';
select privilege from dba_sys_privs where upper(grantee)='U4GTOTM';
select PRIVILEGE from dba_tab_privs where upper(grantee)='U4GTOTM';
select PRIVILEGE from DBA_COL_PRIVS where upper(grantee)='U4GTOTM';

select * from role_sys_privs where ROLE like'%LCREP%'; order by 1;



###############################################
################################################
### CREATE USER

SELECT USERNAME, ACCOUNT_STATUS FROM DBA_USERS WHERE USERNAME='HPDBSPI';

set long 9999999999
select dbms_metadata.get_ddl('USER', username) || '/' usercreate from dba_users where username='SRV0028';
SQL>

USERCREATE
--------------------------------------------------------------------------------

   CREATE USER "TX2513" IDENTIFIED BY VALUES 'S:25C00DDBBC2FEF286D94C9D8D87F5EB



select 'alter user "'||username||'" identified by values '''||extract(xmltype(dbms_metadata.get_xml('USER',username)),'//USER_T/PASSWORD/text()').getStringVal()||''';'  old_password 
from dba_users where username = 'SRV0028';

SQL>
SQL> ALTER USER TX2513 ACCOUNT UNLOCK;
SQL>
SQL> alter user HP_DBSPI identified by "dbspi_MLPJaVa";
SQL>
SQL> ALTER USER HPDBSPI ACCOUNT UNLOCK;

User altered.

SQL>
SQL> SELECT USERNAME, ACCOUNT_STATUS FROM DBA_USERS WHERE USERNAME='TX2513';

USERNAME                       ACCOUNT_STATUS
------------------------------ --------------------------------
TX2513                         OPEN




###############################################
###############################################
COPPY A USER FROM ONE DATABASE TO ANOTHER:

SELECT dbms_metadata.get_ddl('USER','U4ARS4TS3MARK') FROM dual;
select dbms_metadata.get_granted_ddl( 'DEFAULT_ROLE', 'U4ARS4TS3MARK' ) from dual;
select dbms_metadata.get_granted_ddl( 'SYSTEM_GRANT', 'U4ARS4TS3MARK' ) from  dual;
select dbms_metadata.get_granted_ddl( 'OBJECT_GRANT', 'U4ARS4TS3MARK' ) from dual;
select dbms_metadata.get_granted_ddl( 'ROLE_GRANT', 'U4ARS4TS3MARK' ) from dual;
select dbms_metadata.get_granted_ddl( 'TABLESPACE_QUOTA', 'U4ARS4TS3MARK' ) from dual;



###############################################
###############################################

##############################################################################################################################################################
############################ USER ################## USER ###################### USER #################### USER #################### USER ####################

##### CHECK USER UNLOCK/LOCK USER #####

col USERNAME for a20
col PROFILE for a20
col ACCOUNT_STATUS for a20
select USERNAME, PROFILE, ACCOUNT_STATUS, DEFAULT_TABLESPACE, TEMPORARY_TABLESPACE from dba_users where username='HPDBSPI';    or  hp_dbspi   ### ? ????????? ?????????? ????? ?? ????? 


### To check privileges for PROFILE
set lines 999
col PROFILE for a30
col RESOURCE_NAME for a30
col LIMIT for a20
select PROFILE,RESOURCE_NAME,LIMIT from dba_profiles where PROFILE='DEFAULT';

col GRANTEE for a30
col GRANTED_ROLE for a30
SELECT * FROM DBA_SYS_PRIVS WHERE GRANTEE = 'SRV0028'; 

col GRANTEE for a30
col GRANTED_ROLE for a30
SELECT * FROM DBA_ROLE_PRIVS WHERE GRANTEE = 'SRV0028'; 


select USERNAME,ACCOUNT_STATUS from dba_users where username='HP_DBSPI';

set long 10000
select 'alter user '||username||' identified by values '||REGEXP_SUBSTR(DBMS_METADATA.get_ddl ('USER',USERNAME), '''[^'']+''')||';'
from dba_users
where username = 'SRV0028';


SET LONG 9999999;

select dbms_metadata.get_ddl('USER','SRV0028') from dual;



alter user SRV0028 identified by values 'S:965284B7315578C27C33089801EFE258ED5ABDB270BC8FA98C01B5962C39;T:898B90C97446AD4F628C0C862A5017AC8ADBAF9A8041F1B6586AB249679535CFE2BC9C7398A82B2B109E3744A9C1DB4D99E2123E812A52AACB1C0947687BD988D856BE0A5CE59528DD93CF2E56B05894;A9039491EE71836C';

### Unlock User 
ALTER USER <user_name> ACCOUNT UNLOCK;
ALTER USER srv0270 ACCOUNT UNLOCK;


##
set lines 999
col PROFILE for a30
col RESOURCE_NAME for a30
col LIMIT for a20
select PROFILE,RESOURCE_NAME,LIMIT from dba_profiles where PROFILE='BSOX_PROFILE'; 



select USERNAME,ACCOUNT_STATUS,PROFILE from dba_users where USERNAME in('SRV0269','SRV7202');



select 'alter user "'||username||'" identified by values '''||extract(xmltype(dbms_metadata.get_xml('USER',username)),'//USER_T/PASSWORD/text()').getStringVal()||''';' old_password from dba_users where username = '&USER';




######### DESCRIBE DBA_USERS ########

SQL> desc dba_users;

 Name                                      Null?    Type
 ----------------------------------------- -------- ----------------------------
 USERNAME                                  NOT NULL VARCHAR2(128)
 USER_ID                                   NOT NULL NUMBER
 PASSWORD                                           VARCHAR2(4000)
 ACCOUNT_STATUS                            NOT NULL VARCHAR2(32)
 LOCK_DATE                                          DATE
 EXPIRY_DATE                                        DATE
 DEFAULT_TABLESPACE                        NOT NULL VARCHAR2(30)
 TEMPORARY_TABLESPACE                      NOT NULL VARCHAR2(30)
 CREATED                                   NOT NULL DATE
 PROFILE                                   NOT NULL VARCHAR2(128)
 INITIAL_RSRC_CONSUMER_GROUP                        VARCHAR2(128)
 EXTERNAL_NAME                                      VARCHAR2(4000)
 PASSWORD_VERSIONS                                  VARCHAR2(17)
 EDITIONS_ENABLED                                   VARCHAR2(1)
 AUTHENTICATION_TYPE                                VARCHAR2(8)
 PROXY_ONLY_CONNECT                                 VARCHAR2(1)
 COMMON                                             VARCHAR2(3)
 LAST_LOGIN                                         TIMESTAMP(9) WITH TIME ZONE
 ORACLE_MAINTAINED                                  VARCHAR2(1)






########
select USERNAME,ACCOUNT_STATUS,PROFILE from dba_users where USERNAME in('BRAACK');




######
select profile from dba_profiles;





#### CHECK PROFILE LIMITS FOR GIVEN PROFILE  ########

set lines 999
col PROFILE for a30
col RESOURCE_NAME for a30
col LIMIT for a20
select PROFILE,RESOURCE_NAME,LIMIT from dba_profiles where PROFILE='&PROFILE'; 


#####
alter profile default limit password_life_time unlimited;



####################################################################
####################################################################

###### Za da izvadim hesha i da poilzvame syshtata parola

select 'alter user "'||username||'" identified by values '''||extract(xmltype(dbms_metadata.get_xml('USER',username)),'//USER_T/PASSWORD/text()').getStringVal()||''';' old_password from dba_users where username = '&USER';



SQL> select 'alter user "'||username||'" identified by values '''||extract(xmltype(dbms_metadata.get_xml('USER',username)),'//USER_T/PASSWORD/text()').getStringVal()||''';' old_password from dba_users where username = '&USER';
Enter value for user: SRV0269
old   1: select 'alter user "'||username||'" identified by values '''||extract(xmltype(dbms_metadata.get_xml('USER',username)),'//USER_T/PASSWORD/text()').getStringVal()||''';' old_password from dba_users where username = '&USER'
new   1: select 'alter user "'||username||'" identified by values '''||extract(xmltype(dbms_metadata.get_xml('USER',username)),'//USER_T/PASSWORD/text()').getStringVal()||''';' old_password from dba_users where username = 'SRV0269'


OLD_PASSWORD
---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
alter user "SRV0269" identified by values '87A9DAB987475BCA';

SQL> alter user "SRV0269" identified by values '87A9DAB987475BCA';

User altered.



SQL> select USERNAME,ACCOUNT_STATUS,PROFILE from dba_users where USERNAME in('D31096');

USERNAME     ACCOUNT_STATUS                   PROFILE
------------ -------------------------------- ------------------------------
SRV0269      OPEN                             BSOX_PROFILE



alter user hpdbspi identified by "mewa:hpspi2015"

#####################################################
#######################################################

###### Change the user profile if it's necessary 

alter user SRB1320 profile BSOX_PROFILE;



######################################################
######################################################

##### Check free memory in schema and schema
[?3/?20/?2020 6:43 PM]  Naydenova, Martina Krasimirova:  
No Title 
=====================================================================================================
Hello,

Regarding your service request here is the information:

Schema VDAT has objects in the following tablespaces:

TABLESPACE_NAME
------------------------------
VDAT
INDX


And here is the free memory for this schema:

Schema Size Gb
--------------
    1.07849121


owner(VDAT)=shema(VDAT)=user(VDAT) ima obekti v tablespace-i VDAT i INDX i v tqh ima FREE SIZE=1.07849121GB


***s tova query shte vidish kolko free size ima za tazi schema ostanalo:

select sum(bytes)/1024/1024/1024 "Schema Size Gb" from dba_segments where owner in ('VDAT'); 


***s tova shte vidish tazi schema v koi tablespace-i ima obekti:

col SEGMENT_NAME for a30
select tablespace_name from dba_segments 
where owner like 'VDAT'
group by tablespace_name;
 
TABLESPACE_NAME
------------------------------
VDAT
INDX  



#################################################################
##################################################################

############ CHECK IF RMAN HAS SYSDBA RIGHTS ##############

 SELECT * FROM v$pwfile_users WHERE sysdba='TRUE'; 
 
 ### IF NOT - DO THIS ###
 
 grant sysdba to RMAN
 

 
######################################################
######################################################
 
 ## dba_profiles

 col PROFILE for a25
col LIMIT for a40
set pages 50 linesize 700
select PROFILE,RESOURCE_NAME,LIMIT from dba_profiles where resource_name in ('PASSWORD_LIFE_TIME','PASSWORD_GRACE_TIME','PASSWORD_VERIFY_FUNCTION'); 
 


#######################################################
########################################################


[‎1/‎23/‎2020 6:45 PM]  Tsalov, Aleksandar Stefanov:  
.
 
[‎1/‎23/‎2020 6:45 PM]  Tsalov, Aleksandar Stefanov:  
No Title 
##routine dba 02
select 'alter user "'||username||'" identified by values '''||extract(xmltype(dbms_metadata.get_xml('USER',username)),'//USER_T/PASSWORD/text()').getStringVal()||''';' old_password from dba_users where username = '&USER'; 

### Change user passwords
col USERNAME for a15
col ACCOUNT_STATUS for a10
col PROFILE for a40
select USERNAME,USER_ID,ACCOUNT_STATUS,CREATED,PROFILE from dba_users where username = UPPER( '&ALL'); 


select username, account_status from dba_users where username = 


#### CHECK PROFILE LIMITS FOR GIVEN PROFILE  ########

set lines 999
col PROFILE for a30
col RESOURCE_NAME for a30
col LIMIT for a20
select PROFILE,RESOURCE_NAME,LIMIT from dba_profiles where PROFILE='&PROFILE';


### PASSWORD CANNOT BE REUSED WORKARROUND: or password expired dbspi

CREATE PROFILE CHACHA LIMIT PASSWORD_VERIFY_FUNCTION NULL;
ALTER PROFILE CHACHA LIMIT PASSWORD_REUSE_MAX UNLIMITED;
ALTER PROFILE CHACHA LIMIT PASSWORD_REUSE_TIME UNLIMITED;

ALTER USER <USERNAME>  PROFILE CHACHA;

ALTER USER <USERNAME>  IDENTIFIED BY "PASSWORD";

ALTER USER <USERNAME> PROFILE <OLDPROFILE>

DROP PROFILE CHACHA  
 

######
set linesize 500
SELECT USERNAME, PROFILE, ACCOUNT_STATUS, CREATED, PROFILE, EXPIRY_DATE, CREATED FROM DBA_USERS order by 1; 



#####################################################
######################################################

[?9/?3/?2019 4:45 PM]  Tsolev, Andrey (Oracle DBA):  
CREATE PROFILE "UNLIMITED_PWD_EXPIRATION" LIMIT
CPU_PER_SESSION UNLIMITED
CPU_PER_CALL UNLIMITED
CONNECT_TIME UNLIMITED
IDLE_TIME UNLIMITED
SESSIONS_PER_USER UNLIMITED
LOGICAL_READS_PER_SESSION UNLIMITED
LOGICAL_READS_PER_CALL UNLIMITED
PRIVATE_SGA UNLIMITED
COMPOSITE_LIMIT UNLIMITED
PASSWORD_LIFE_TIME UNLIMITED
PASSWORD_GRACE_TIME DEFAULT
PASSWORD_REUSE_MAX UNLIMITED
PASSWORD_REUSE_TIME UNLIMITED
PASSWORD_LOCK_TIME 1
FAILED_LOGIN_ATTEMPTS 10
PASSWORD_VERIFY_FUNCTION VERIFY_FUNCTION_11G; 
 


[?9/?3/?2019 4:45 PM]  Tsolev, Andrey (Oracle DBA):  
### No password verification -->

CREATE PROFILE "UNLIMITED_PWD_EXPIRATION" LIMIT
CPU_PER_SESSION UNLIMITED
CPU_PER_CALL UNLIMITED
CONNECT_TIME UNLIMITED
IDLE_TIME UNLIMITED
SESSIONS_PER_USER UNLIMITED
LOGICAL_READS_PER_SESSION UNLIMITED
LOGICAL_READS_PER_CALL UNLIMITED
PRIVATE_SGA UNLIMITED
COMPOSITE_LIMIT UNLIMITED
PASSWORD_LIFE_TIME UNLIMITED
PASSWORD_GRACE_TIME DEFAULT
PASSWORD_REUSE_MAX UNLIMITED
PASSWORD_REUSE_TIME UNLIMITED
PASSWORD_LOCK_TIME 1
FAILED_LOGIN_ATTEMPTS 10
PASSWORD_VERIFY_FUNCTION NULL; 
### Install the VERIFY_FUNCTION_11G -->


##################################
####################################
CREATE USER new_user IDENTIFIED BY password PROFILE "UNLIMITED_PWD_EXPIRATION";

ALTER USER existing_user PROFILE "UNLIMITED_PWD_EXPIRATION" IDENTIFIED BY new password;

ALTER USER HP_DBSPI PROFILE "UNLIMITED_PWD_EXPIRATION" IDENTIFIED BY "hp_dbspi_01." account unlock; 

alter user K61788 identified by "3sF3ge_8vUty7V" account unlock;
 


###################################################
####################################################

 #### Change password
###### DBSPI / HP_DBSPI USER - ? ??????,?? ?? ???? ?? ??????? ???????? ?? dbspi ????  alter user HP_DBSPI identified "hp_dbspi_123";  ?????? ??????????? ??????? ????

[?10/?29/?2019 3:22 AM]  Stoyanov, Evgeni:  
### Password cannot be reused workarround:

create profile CHACHA limit password_verify_function null;
alter profile CHACHA limit PASSWORD_REUSE_MAX UNLIMITED;
alter profile CHACHA limit PASSWORD_REUSE_TIME UNLIMITED;

alter user HP_DBSPI profile CHACHA;

alter user HP_DBSPI identified by "abc123";

alter user HP_DBSPI profile DEFAULT;

drop profile CHACHA; 
 
 

####################################################
####################################################

### CHECK SOURCE USER(S) SCHEMA(S) SIZE - SCHEMA SIZE ####

SELECT s.owner,SUM (s.BYTES) / (1024 * 1024) SIZE_IN_MB FROM dba_segments s GROUP BY s.owner;
select owner, tablespace_name, sum(bytes)/1024/1024 from dba_segments group by owner, tablespace_name;



################################################
################################################


SELECT s.owner,SUM (s.BYTES) / (1024 * 1024) SIZE_IN_MB FROM dba_segments s GROUP BY s.owner;
select owner, tablespace_name, sum(bytes)/1024/1024 from dba_segments group by owner, tablespace_name;


#################################################
##################################################

create or replace directory DDPP1 as '/var/opt/oracle/oradata1/ESLD/temp_exp';
grant read, write on directory DATA_PUMP_DIR to SYSTEM;

################################################
################################################

USER CREATE LIKE
----------
###SalOppenheim - create DB user - When he is able to login to the Oppenheim network and to get access with sudo to oracle machines:
create user ... profile EDS_ADMINS identified by "..." password expire;
GRANT "CONNECT" to ...;
GRANT "DBA" TO ...;
###SalOppenheim - create DB user

### Create new user DEVADAS mimic existing user KUMARG
### 'KUMARG'	- source user
### "DEVADAS"	- target user
set linesize 200;
select 'create user "BRIAN.KEATING" identified by changeme default tablespace '|| default_tablespace ||' temporary tablespace '|| temporary_tablespace ||' profile '|| profile ||' ;' from dba_users where upper(username)='KARTHIKEYAN.MUNNUDAYAR';

select 'grant '||granted_role||' to "BRIAN.KEATING";' from dba_role_privs where upper(grantee)='KARTHIKEYAN.MUNNUDAYAR';
select 'grant '||privilege||' to "BRIAN.KEATING";' from dba_sys_privs where upper(grantee)='KARTHIKEYAN.MUNNUDAYAR';
select 'grant '||PRIVILEGE||' on '|| TABLE_NAME||' to "BRIAN.KEATING";' from dba_tab_privs where upper(grantee)='KARTHIKEYAN.MUNNUDAYAR';


####################################################
#####################################################
--user creation
set long 2000
SELECT DBMS_METADATA.GET_DDL('USER','SQL_VOU') || ';' FROM dual;
or for 11g 
select password,spare4 from user$ where name='T5225';

--grant sysprivs
select 'grant '||a.privilege||' to "SQL_VAIOUN"'||decode(ADMIN_OPTION,'YES',' WITH ADMIN OPTION','')||';'
from dba_sys_privs a, dba_users b
where a.grantee=b.username
and b.username ='SQL_VAIOUN';

--grant role_rivs
select 'grant '||c.granted_role||' to "SQL_VAIOUN"'||decode(ADMIN_OPTION,'YES',' WITH ADMIN OPTION','')||';'
from dba_role_privs c, dba_users d
where d.username=c.grantee
and username ='SQL_VAIOUN';

--grant tab_privs
select 'grant '||e.privilege||' on '||e.owner||'.'||e.table_name||' to "SQL_VAIOUN"'||decode(grantable,'YES',' WITH ADMIN OPTION','')||';'
from dba_tab_privs e, dba_users f
where f.username=e.grantee
and username ='SQL_VAIOUN';

--alter quota
select 'alter user "SQL_VAIOUN" '||decode(MAX_BYTES,'-1',' quota unlimited',MAX_BYTES)||' on '||TABLESPACE_NAME||';'
from dba_ts_quotas where username ='SQL_VAIOUN';


#####################################################################################
#################### PRIV GRANTS REFERENCE ### JDETESTtt -> the new user which want to have the privileges !!!
--grant privs
set pages 1500
select 'grant '||a.privilege||' to "JDETESTtt"'||decode(ADMIN_OPTION,'YES',' WITH ADMIN OPTION','')||';'
from dba_sys_privs a, dba_users b
where a.grantee=b.username
and b.username in ('RMAN');

--grant role_rivs
select 'grant '||c.granted_role||' to "JDETESTttt"'||decode(ADMIN_OPTION,'YES',' WITH ADMIN OPTION','')||';'
from dba_role_privs c, dba_users d
where d.username=c.grantee
and username in ('RMAN');

--grant tab_privs
select 'grant '||e.privilege||' on '||e.owner||'.'||e.table_name||' to "JDETESTttt"'||decode(grantable,'YES',' WITH ADMIN OPTION','')||';'
from dba_tab_privs e, dba_users f
where f.username=e.grantee
and username in ('RMAN');


SELECT PRIVILEGE, TABLE_NAME from ROLE_TAB_PRIVS WHERE ROLE='RO_CTR'; 




##########################################
##########################################


‎9/‎24/‎2019 9:18 AM]  Stoyanov, Evgeni:  
No Title 
### USER CREATION WITH MIMIC WITH EXISTING USER ###
create user "ESLBATUSER" identified by "eSL20bat19" default tablespace "TANGO_TABLES" temporary tablespace "TEMP2" profile ESL_PROFILE;
GRANT CREATE SESSION TO SA_READ WITH ADMIN OPTION;
GRANT CREATE DATABASE LINK TO SA_READ;

set linesize 200;
select 'create user "DBSPI_USER" identified by "Avon123" default tablespace '|| default_tablespace ||' temporary tablespace '|| temporary_tablespace ||' profile '|| profile ||';' from dba_users where username='DBSPI_USER'; 


set pages 2000
set lines 400
select 'grant '||granted_role||' to "ESLBATUSER";' from dba_role_privs where grantee='ESLROUSER';
select 'grant '||privilege||' to "ESLBATUSER";' from dba_sys_privs where grantee='ESLROUSER';
select 'grant '||privilege||' on '|| table_name||' to "ESLBATUSER";' from dba_tab_privs where grantee='ESLROUSER';
GRANT CREATE SESSION TO ESLINTAPP11 WITH ADMIN OPTION;
GRANT CREATE DATABASE LINK TO ESLINTAPP11;

grant SELECT on ESLROUSER.CONTENT_STA to "SA_WRITE";
set linesize 200;
select 'create user "ONERUNNGDM" identified by "d9GzRtKV18" default tablespace '|| default_tablespace ||' temporary tablespace '|| temporary_tablespace ||' profile '|| profile ||';' from dba_users where username='ESLROUSER';  
 





#############################################
##############################################


##### za ROLE

[‎9/‎24/‎2019 11:53 AM]  Rangelov, Martin (Oracle DBA):  
No Title 
SELECT owner, table_name FROM dba_tables where table_name in ('AGRUPACIONES_RUTAS', 'ALBARANESC', 'ALBARANESC_T', 'ALBARANESL', 'ALBARANESL_T', 'ALBCOMISION_PRO', 'ALBCOMISION_PRO_L', 'ALBENP_CABECERA', 'ALBENP_DETALLE', 'AUDIT_MOVIMIENTOS_CLIENTE', 'CABECERAS_T', 'CLASIF_CLIENTES_2', 'CLASIF_CLIENTES_3', 'CLASIF_PUBLICACIONES_1', 'CLASIF_PUBLICACIONES_2', 'CLAVES_ALBARANES', 'CLIENTES', 'CLIENTES_ESTADO', 'CLIENTES_FINALES', 'CLIENTES_OPERATIVAS', 'CLIENTES_PRESENCIA', 'CLTES_DOCUMENTOS_FANDEXML', 'CONTADORES', 'COPIA_GARANTIZADA', 'DEVOLUCIONES_C_CB_L_HISTORICO', 'DEVOLUCIONES_SRG_C', 'DEVOLUCIONES_SRG_L', 'DISTRIBUCIONES', 'DOCUMENTOS_FANDEXML', 'ESCALA_CTO_COMPRA', 'ESCALAS_DESCUENTOS', 'ESTADISTICAS', 'FACTURAS_CABECERAS_T', 'FACTURAS_EXCESOS_C', 'FACTURAS_EXCESOS_L', 'FACTURAS_LINEAS_T', 'FACTURAS_PROV_CABECERA', 'FACTURAS_PROV_DETALLE', 'FACTURAS_PROV_INFO', 'MESAS_REPARTOS', 'MOVIMIENTOS_CLAVES', 'MOVIMIENTOS_STOCK', 'MPROVEDORESL', 'MPROVEEDORESL', 'NUMEROS', 'NUMEROS_GENERICOS_REDES', 'PARAMETROS_EMPRESA', 'PEDIDOS', 'PROVEEDORES', 'PUBLICACIONES_REGALOS', 'RECLAMACIONES', 'RECUPERACIONES', 'REF_DOCUMENTOS_FANDEXML', 'REPARTOSC', 'RESERVAS', 'RESERVAS_ESTADOS', 'RESERVAS_PUBLICACIONES', 'RESERVAS_SITUACIONES', 'RUTAS', 'RUTAS_CLIENTES', 'SECCIONES', 'SONDEOS_CABECERAS', 'SONDEOS_LINEAS', 'TIPOS_ESTADOS_PEDIDOS', 'TIPOS_RECLAMACION', 'COMUNIDADES_AUTONOMAS', 'DENEGACIONES_RECLAMACION', 'EDITORES', 'EMPRESAS', 'ESTADOS_CLIENTES', 'FAMILIAS', 'NUMEROS_CB', 'PAISES', 'PERIODICIDADES_GENERICAS', 'POBLACIONES', 'PROVINCIAS', 'PUBLICACIONES_MAIN', 'PUNTOS_INTERES', 'SUBFAMILIAS', 'TIPOS_IMPUESTOS', 'TIPOS_PUNTOS_INTERES', 'VIAS_PUBLICAS'); 
 
 
#### Така се създава дадената ролята

[‎9/‎24/‎2019 4:21 PM]  Rangelov, Martin (Oracle DBA):  
No Title 
BEGIN
   FOR R IN (SELECT owner, table_name FROM dba_tables where table_name in ('AGRUPACIONES_RUTAS', 'ALBARANESC', 'ALBARANESC_T', 'ALBARANESL', 'ALBARANESL_T', 'ALBCOMISION_PRO', 'ALBCOMISION_PRO_L', 'ALBENP_CABECERA', 'ALBENP_DETALLE', 'AUDIT_MOVIMIENTOS_CLIENTE', 'CABECERAS_T', 'CLASIF_CLIENTES_2', 'CLASIF_CLIENTES_3', 'CLASIF_PUBLICACIONES_1', 'CLASIF_PUBLICACIONES_2', 'CLAVES_ALBARANES', 'CLIENTES', 'CLIENTES_ESTADO', 'CLIENTES_FINALES', 'CLIENTES_OPERATIVAS', 'CLIENTES_PRESENCIA', 'CLTES_DOCUMENTOS_FANDEXML', 'CONTADORES', 'COPIA_GARANTIZADA', 'DEVOLUCIONES_C_CB_L_HISTORICO', 'DEVOLUCIONES_SRG_C', 'DEVOLUCIONES_SRG_L', 'DISTRIBUCIONES', 'DOCUMENTOS_FANDEXML', 'ESCALA_CTO_COMPRA', 'ESCALAS_DESCUENTOS', 'ESTADISTICAS', 'FACTURAS_CABECERAS_T', 'FACTURAS_EXCESOS_C', 'FACTURAS_EXCESOS_L', 'FACTURAS_LINEAS_T', 'FACTURAS_PROV_CABECERA', 'FACTURAS_PROV_DETALLE', 'FACTURAS_PROV_INFO', 'MESAS_REPARTOS', 'MOVIMIENTOS_CLAVES', 'MOVIMIENTOS_STOCK', 'MPROVEDORESL', 'MPROVEEDORESL', 'NUMEROS', 'NUMEROS_GENERICOS_REDES', 'PARAMETROS_EMPRESA', 'PEDIDOS', 'PROVEEDORES', 'PUBLICACIONES_REGALOS', 'RECLAMACIONES', 'RECUPERACIONES', 'REF_DOCUMENTOS_FANDEXML', 'REPARTOSC', 'RESERVAS', 'RESERVAS_ESTADOS', 'RESERVAS_PUBLICACIONES', 'RESERVAS_SITUACIONES', 'RUTAS', 'RUTAS_CLIENTES', 'SECCIONES', 'SONDEOS_CABECERAS', 'SONDEOS_LINEAS', 'TIPOS_ESTADOS_PEDIDOS', 'TIPOS_RECLAMACION', 'COMUNIDADES_AUTONOMAS', 'DENEGACIONES_RECLAMACION', 'EDITORES', 'EMPRESAS', 'ESTADOS_CLIENTES', 'FAMILIAS', 'NUMEROS_CB', 'PAISES', 'PERIODICIDADES_GENERICAS', 'POBLACIONES', 'PROVINCIAS', 'PUBLICACIONES_MAIN', 'PUNTOS_INTERES', 'SUBFAMILIAS', 'TIPOS_IMPUESTOS', 'TIPOS_PUNTOS_INTERES', 'VIAS_PUBLICAS')) LOOP
      EXECUTE IMMEDIATE 'grant select on '||R.owner||'.'||R.table_name||' to SAFE_RESTRICT_SELECTROLE';
   END LOOP;
END; 

/ 
 
 
               ИЛИ
			   
 
 #################### Procedure to grant access on tables to other user

BEGIN
   FOR R IN (SELECT owner, table_name FROM dba_tables where OWNER like 'SAFE_%') LOOP
      EXECUTE IMMEDIATE 'grant select on '||R.owner||'.'||R.table_name||' to SAFE_SELECTROLE';
   END LOOP;
END; 

/ 

================================


[‎9/‎24/‎2019 11:59 AM]  Rangelov, Martin (Oracle DBA):  
SAFE_RESTRICT_SELECTROLE - е ролята, която има всичко което му трябва на този
 


[‎9/‎24/‎2019 1:30 PM]  Rangelov, Martin (Oracle DBA):  
Изабел разчитам на теб за
RE: [LOGISTA] E-IM029108810 / Incidencia para DC_OPS 
чакаш да ти реплайне този с чейндж Ид и чак тогава му даваш ролята 
 
grant SAFE_RESTRICT_SELECTROLE to SA_QKSENSE;





saqliksense

SAQLIKSENSE



#@##### create user SAQLIKSENSE identified by CP5/IzcH4R4h5x89VLekA;

#### grant connect to SAQLIKSENSE;

SAFE_EMPRESA01, 
SAFE_EMPRESA07, 
SAFE_EMPRESA08, 
SAFE_EMPRESA26, 
SAFE_EMPRESA33, 
SAFE_EMPRESA36, 
SAFE_EMPRESA45, 
SAFE_EMPRESA47, 
SAFE_EMPRESA50, 
SAFE_EMPRESA63


With SELECT permission for these tables (for each of the previous schemas):", 

"AGRUPACIONES_RUTAS", 
"ALBARANESC", 
"ALBARANESC_T", 
"ALBARANESL", 
"ALBARANESL_T", 
"ALBCOMISION_PRO", 
"ALBCOMISION_PRO_L", 
"ALBENP_CABECERA", 
"ALBENP_DETALLE", 
"AUDIT_MOVIMIENTOS_CLIENTE", 
"CABECERAS_T", 
"CLASIF_CLIENTES_2", 
"CLASIF_CLIENTES_3", 
"CLASIF_PUBLICACIONES_1", 
"CLASIF_PUBLICACIONES_2", 
CLAVES_ALBARANES", 
"CLIENTES", 
"CLIENTES_ESTADO", 
"CLIENTES_FINALES", 
"CLIENTES_OPERATIVAS", 
"CLIENTES_PRESENCIA", 
"CLTES_DOCUMENTOS_FANDEXML", 
"CONTADORES", 
"COPIA_GARANTIZADA", 
"DEVOLUCIONES_C_CB_L_HISTORICO", 
"DEVOLUCIONES_SRG_C", 
"DEVOLUCIONES_SRG_L", 
"DISTRIBUCIONES", 
"DOCUMENTOS_FANDEXML", 
"ESCALA_CTO_COMPRA", 
"ESCALAS_DESCUENTOS", 
"ESTADISTICAS", 
"FACTURAS_CABECERAS_T", 
"FACTURAS_EXCESOS_C", 
"FACTURAS_EXCESOS_L", 
"FACTURAS_LINEAS_T", 
"FACTURAS_PROV_CABECERA", 
"FACTURAS_PROV_DETALLE", 
"FACTURAS_PROV_INFO", 
"MESAS_REPARTOS", 
"MOVIMIENTOS_CLAVES", 
"MOVIMIENTOS_STOCK", 
"MPROVEDORESL", 
"MPROVEEDORESL", 
"NUMEROS", 
"NUMEROS_GENERICOS_REDES", 
"PARAMETROS_EMPRESA", 
"PEDIDOS", 
"PROVEEDORES", 
"PUBLICACIONES_REGALOS", 
"RECLAMACIONES", 
"RECUPERACIONES", 
"REF_DOCUMENTOS_FANDEXML", 
"REPARTOSC", 
"RESERVAS", 
"RESERVAS_ESTADOS", 
"RESERVAS_PUBLICACIONES", 
"RESERVAS_SITUACIONES", 
"RUTAS", 
"RUTAS_CLIENTES", 
"SECCIONES", 
"SONDEOS_CABECERAS", 
"SONDEOS_LINEAS", 
"TIPOS_ESTADOS_PEDIDOS", 
"TIPOS_RECLAMACION"


Also for the schema SAFE_MAIN with SELECT permission to these tables

COMUNIDADES_AUTONOMAS", 
"DENEGACIONES_RECLAMACION", 
"EDITORES", 
"EMPRESAS", 
"ESTADOS_CLIENTES", 
"FAMILIAS", 
"NUMEROS_CB", 
"PAISES", 
"PERIODICIDADES_GENERICAS", 
"POBLACIONES", 
"PROVINCIAS", 
"PUBLICACIONES_MAIN", 
"PUNTOS_INTERES", 
"SUBFAMILIAS", 
"TIPOS_IMPUESTOS", 
"TIPOS_PUNTOS_INTERES", 
"VIAS_PUBLICAS"






################################################
#################################################
Logista user create


SQL> create user USERPUBP identified by uJn-32_aqB9LgPf;

SQL> grant connect to USERPUBP;

GRANT SELECT ON 
SAFE_EMPRESA01, 
SAFE_EMPRESA07, 
SAFE_EMPRESA08, 
SAFE_EMPRESA26, 
SAFE_EMPRESA33, 
SAFE_EMPRESA36, 
SAFE_EMPRESA45, 
SAFE_EMPRESA47, 
SAFE_EMPRESA50, 
SAFE_EMPRESA63
TO
USERPUBP;


SAFE_EMPRESA50
SAFE_EMPRESA36
SAFE_EMPRESA08
SAFE_EMPRESA33
SAFE_EMPRESA26
SAFE_EMPRESA63
SAFE_EMPRESA47
SAFE_EMPRESA01
SAFE_EMPRESA07
SAFE_EMPRESA45
SAFE_MAIN
SAFE_EMPRESA99


BEGIN
   FOR R IN (SELECT owner, table_name FROM dba_tables where OWNER like 'SAFE_EMP%') LOOP
      EXECUTE IMMEDIATE 'grant select on '||R.owner||'.'||R.table_name||' to SAFE_SELECTROLE';
   END LOOP;
END;

SELECT count(*) FROM dba_tables where OWNER like 'SAFE_EMP%'



===========================
======================From: CM-ITO-DO-BULGARIA-ORACLE <cm-ito-do-bulgaria-oracle@dxc.com> 
Sent: Monday, September 23, 2019 6:06 PM
To: ACRUZ@LOGISTA.ES
Cc: CM-ITO-DO-BULGARIA-ORACLE <cm-ito-do-bulgaria-oracle@dxc.com>; PDL-Bulgaria-South-Logista-Oracle <pdl-bulgaria-south-logista-oracle@dxc.com>
Subject: [LOGISTA] E-IM029108810 / Incidencia para DC_OPS

Hello,

The user USERPUBP has been created as requested . 
The password will be sent to the requestor via separate email.


Best regards,
Izabela Pehlivanska
Technical Support
iAction | Oracle Database Team
+359 889 820 093 Red Phone
CM-ITO-DO-BULGARIA-ORACLE@dxc.com
Business Park Sofia, Building 9
Sofia, Bulgaria
 
-----------------------------------------
----------------------------

From: CM-ITO-DO-BULGARIA-ORACLE 
Sent: Monday, September 23, 2019 6:11 PM
To: acruz@logista.es
Subject: [LOGISTA] E-IM029108810 / Incidencia para DC_OPS

Hello,

The password for user USERPUBP is : uJn-32_aqB9LgPf

The service request will be put in status resolved.

Best regards,
Izabela Pehlivanska
Technical Support
iAction | Oracle Database Team
+359 889 820 093 Red Phone
CM-ITO-DO-BULGARIA-ORACLE@dxc.com
Business Park Sofia, Building 9
Sofia, Bulgaria
 

================================
===============================


######################################################
##################################################3###

