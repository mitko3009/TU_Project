/********************************************************************************
*********       E-mail subject: AWBWEB-796
*********             Instance: PROD
*********          Description: 
Problem:
SQL 8z05y1djsrgst was considered as slow on AWB PROD.

Analysis:
Such problem was already investigated in LOCAMDEV-23186 and the solution in it is to add 
fi.actif = 'O' in the query. The same modification should be added here. Also, the shown hint 
in the New SQL section below should be added here.

Suggestion:
Please change the query as it is shown in the New SQL section below.

*********               SQL_ID: 8z05y1djsrgst
*********      Program/Package: 
*********              Request: Dimitare Ivanov
*********               Author: Dimitar Dimitrov
********* Received e-mail date: 02/05/2024
*********      Resolution date: 02/05/2024
*********  Trace old file here: \\epox\specifs\performance\tmp\
*********  Trace new file here:
***********************************************************************************/

/********************************OLD SQL*******************************************/

VAR B1 NUMBER;
EXEC :B1 := 99;

SELECT refUser, userName, invoicesState, COUNT(invoices) invoicesNumber
  FROM ( SELECT gest.refperso refUser,
                ind.nom userName,
                CASE
                  WHEN fi.dtdebut >= TO_CHAR(sysdate - 1, 'j') THEN
                   'NOT DUE'
                  WHEN fi.dtdebut < TO_CHAR(sysdate - 1, 'j') THEN
                   'DUE'
                END invoicesState,
                fi.refelem invoices
           FROM g_personnel gest,
                g_individu  ind,
                g_dossier   dos,
                g_elemfi    fi,
                v_elemfi    ve
          WHERE gest.refperso = :B1
            AND gest.refindividu = ind.refindividu
            AND gest.refperso = dos.rangmt
            AND dos.refdoss = fi.refdoss
            AND NVL(NVL(fi.mt_ouvert_mvt, fi.montant_dos), 0) <> 0
            AND fi.dtannul_dt IS NULL
            AND fi.type = ve.type )
 GROUP BY refUser, userName, invoicesState;
/********************************OLD SQL*******************************************/
/********************************OLD Metrics***************************************/
/*
Plan hash value: 893925470
---------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                 | Name                   | Starts | E-Rows | A-Rows |   A-Time   | Buffers | Reads  |
---------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                          |                        |      1 |        |      0 |00:00:05.35 |   19828 |  19290 |
|   1 |  HASH GROUP BY                            |                        |      1 |      9 |      0 |00:00:05.35 |   19828 |  19290 |
|   2 |   NESTED LOOPS                            |                        |      1 |      9 |      0 |00:00:05.35 |   19828 |  19290 |
|   3 |    NESTED LOOPS                           |                        |      1 |      9 |    240 |00:00:05.35 |   19772 |  19290 |
|   4 |     MERGE JOIN CARTESIAN                  |                        |      1 |      9 |    240 |00:00:05.35 |   19768 |  19290 |
|   5 |      NESTED LOOPS                         |                        |      1 |      1 |      1 |00:00:00.01 |       6 |      0 |
|   6 |       NESTED LOOPS                        |                        |      1 |      1 |      1 |00:00:00.01 |       5 |      0 |
|*  7 |        TABLE ACCESS BY INDEX ROWID BATCHED| G_PERSONNEL            |      1 |      1 |      1 |00:00:00.01 |       2 |      0 |
|*  8 |         INDEX RANGE SCAN                  | GPERSREFP              |      1 |      1 |      1 |00:00:00.01 |       1 |      0 |
|*  9 |        INDEX UNIQUE SCAN                  | IND_REFINDIV           |      1 |      1 |      1 |00:00:00.01 |       3 |      0 |
|  10 |       TABLE ACCESS BY INDEX ROWID         | G_INDIVIDU             |      1 |      1 |      1 |00:00:00.01 |       1 |      0 |
|  11 |      BUFFER SORT                          |                        |      1 |     11 |    240 |00:00:05.35 |   19762 |  19290 |
|* 12 |       TABLE ACCESS BY INDEX ROWID BATCHED | G_ELEMFI               |      1 |     11 |    240 |00:00:05.35 |   19762 |  19290 |
|* 13 |        INDEX SKIP SCAN                    | G_ELEMFI$REFDOSS_ACTIF |      1 |    227 |    240 |00:00:05.34 |   19529 |  19275 |
|* 14 |     INDEX UNIQUE SCAN                     | AK_KEY_V_ELEMFI_TYPE   |    240 |      1 |    240 |00:00:00.01 |       4 |      0 |
|* 15 |    INDEX RANGE SCAN                       | DOS_GEST               |    240 |      1 |      0 |00:00:00.01 |      56 |      0 |
---------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   7 - filter("GEST"."REFINDIVIDU" IS NOT NULL)
   8 - access("GEST"."REFPERSO"=TO_NUMBER(:B1))
   9 - access("GEST"."REFINDIVIDU"="IND"."REFINDIVIDU")
  12 - filter((NVL(NVL("FI"."MT_OUVERT_MVT","FI"."MONTANT_DOS"),0)<>0 AND "FI"."DTANNUL_DT" IS NULL))
  13 - access("FI"."ACTIF"='O')
       filter("FI"."ACTIF"='O')
  14 - access("FI"."TYPE"="VE"."TYPE")
  15 - access("DOS"."RANGMT"=TO_NUMBER(:B1) AND "DOS"."REFDOSS"="FI"."REFDOSS")
*/
/********************************OLD Metrics***************************************/

/********************************New SQL*******************************************/

SELECT refUser, userName, invoicesState, COUNT(invoices) invoicesNumber
  FROM ( SELECT /*+ leading(gest ind dos fi) use_nl(ind dos fi) */
                gest.refperso refUser,
                ind.nom userName,
                CASE
                  WHEN fi.dtdebut >= TO_CHAR(sysdate - 1, 'j') THEN
                   'NOT DUE'
                  WHEN fi.dtdebut < TO_CHAR(sysdate - 1, 'j') THEN
                   'DUE'
                END invoicesState,
                fi.refelem invoices
           FROM g_personnel gest,
                g_individu  ind,
                g_dossier   dos,
                g_elemfi    fi,
                v_elemfi    ve
          WHERE gest.refperso = :B1
            AND gest.refindividu = ind.refindividu
            AND gest.refperso = dos.rangmt
            AND dos.refdoss = fi.refdoss
            AND fi.actif = 'O'
            AND NVL(NVL(fi.mt_ouvert_mvt, fi.montant_dos), 0) <> 0
            AND fi.dtannul_dt IS NULL
            AND fi.type = ve.type )
 GROUP BY refUser, userName, invoicesState;
/********************************New SQL*******************************************/
/********************************New Metrics***************************************/
/*
Plan hash value: 647275401
-----------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                | Name                   | Starts | E-Rows | A-Rows |   A-Time   | Buffers |
-----------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                         |                        |      1 |        |      0 |00:00:00.01 |    1080 |
|   1 |  HASH GROUP BY                           |                        |      1 |      9 |      0 |00:00:00.01 |    1080 |
|   2 |   NESTED LOOPS                           |                        |      1 |      9 |      0 |00:00:00.01 |    1080 |
|   3 |    NESTED LOOPS                          |                        |      1 |      9 |      0 |00:00:00.01 |    1080 |
|   4 |     NESTED LOOPS                         |                        |      1 |   9679 |    536 |00:00:00.01 |      13 |
|   5 |      NESTED LOOPS                        |                        |      1 |      1 |      1 |00:00:00.01 |       6 |
|*  6 |       TABLE ACCESS BY INDEX ROWID BATCHED| G_PERSONNEL            |      1 |      1 |      1 |00:00:00.01 |       2 |
|*  7 |        INDEX RANGE SCAN                  | GPERSREFP              |      1 |      1 |      1 |00:00:00.01 |       1 |
|   8 |       TABLE ACCESS BY INDEX ROWID        | G_INDIVIDU             |      1 |      1 |      1 |00:00:00.01 |       4 |
|*  9 |        INDEX UNIQUE SCAN                 | IND_REFINDIV           |      1 |      1 |      1 |00:00:00.01 |       3 |
|* 10 |      INDEX RANGE SCAN                    | DOS_GEST               |      1 |  11756 |    536 |00:00:00.01 |       7 |
|* 11 |     TABLE ACCESS BY INDEX ROWID BATCHED  | G_ELEMFI               |    536 |      1 |      0 |00:00:00.01 |    1067 |
|* 12 |      INDEX RANGE SCAN                    | G_ELEMFI$REFDOSS_ACTIF |    536 |      1 |      0 |00:00:00.01 |    1067 |
|* 13 |    INDEX UNIQUE SCAN                     | AK_KEY_V_ELEMFI_TYPE   |      0 |      1 |      0 |00:00:00.01 |       0 |
-----------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   6 - filter("GEST"."REFINDIVIDU" IS NOT NULL)
   7 - access("GEST"."REFPERSO"=TO_NUMBER(:B1))
   9 - access("GEST"."REFINDIVIDU"="IND"."REFINDIVIDU")
  10 - access("DOS"."RANGMT"=TO_NUMBER(:B1))
  11 - filter((NVL(NVL("FI"."MT_OUVERT_MVT","FI"."MONTANT_DOS"),0)<>0 AND "FI"."DTANNUL_DT" IS NULL))
  12 - access("DOS"."REFDOSS"="FI"."REFDOSS" AND "FI"."ACTIF"='O')
  13 - access("FI"."TYPE"="VE"."TYPE")
*/
/********************************New Metrics***************************************/

/********************************Index statistics**********************************/

/********************************Other SQLs****************************************/          
/*

*/ 
/********************************Other SQLs****************************************/              
