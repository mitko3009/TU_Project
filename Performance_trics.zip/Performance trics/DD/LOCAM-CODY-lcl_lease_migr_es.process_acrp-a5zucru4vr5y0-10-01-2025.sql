/********************************************************************************
*********       E-mail subject: LOCAMDEV-26813
*********             Instance: CODY
*********          Description: 
Problem:
The lcl_lease_migr_es.process_acrp took over 8 minutes on CODY.

Analysis:
We checked which are the TOP SQLs for module lcl_lease_migr_es.process_acrp in the provided period and it looks like the time is separate between many SQLs, responsible for 2-8 % each.
I checked the first 6 TOP SQL and the problem looks the same in all of them and this are the FULL SCANs of table MIGRLEAS_ACRP. Because there are no indexes on this table, every time Oracle 
makes FULL SCAN of it. To avoid the FULL SCANs, it should be created index on (REFDOSS, CODE_ACTION) on table MIGRLEAS_ACRP ( these are the selective predicates to access the table ).

Suggestion:
Please create index on table MIGRLEAS_ACRP on (REFDOSS, CODE_ACTION) and discuss it with C&D should this index be made in the model or not.

*********               SQL_ID: a5zucru4vr5y0, fsjhsgmx2arzp, cfzhznan3argm, b26wk5ca11ass, 9t4j7ccvwt61t, bcy2vk55kuwn5
*********      Program/Package: 
*********              Request: Ivelin Palahanov 
*********               Author: Dimitar Dimitrov
********* Received e-mail date: 09/01/2025
*********      Resolution date: 10/01/2025
*********  Trace old file here: \\epox\specifs\performance\tmp\
*********  Trace new file here:
***********************************************************************************/

/********************************OLD SQL*******************************************/

-- a5zucru4vr5y0

VAR B1 VARCHAR2(32);
EXEC :B1 := 'DECLJ';
VAR B2 VARCHAR2(32);
EXEC :B2 := '2509207261';

SELECT COUNT(*)
  FROM MIGRLEAS_ACRP M
 WHERE M.REFDOSS = :B2
   AND M.CODE_ACTION = :B1
   AND NOT EXISTS ( SELECT 1
                      FROM MIGRLEAS_ACRP
                     WHERE REFDOSS = M.REFDOSS
                       AND CODE_ACTION = 'AVICON'
                       AND NVL( CODE_FIN, 'N' ) <> 'O' )
   AND NOT EXISTS ( SELECT 1
                      FROM MIGRLEAS_ACRP
                     WHERE REFDOSS = M.REFDOSS
                       AND (  CODE_ACTION IN ( 'PROREG', 'CBREL', 'NEGO' ) 
                           OR CODE_ACTION LIKE 'LIT%' ) )
   AND NOT EXISTS ( SELECT 1
                      FROM G_PERSONNEL
                     WHERE REFPERSO = M.REFPERSO
                       AND GROUPE IN ( 'SERVICE RECOUVREMENT CTX' ) )
   AND EXISTS ( SELECT 1
                  FROM G_PIECE
                 WHERE REFDOSS = M.REFDOSS
                   AND TYPPIECE = 'FINANCING REQUEST'
                   AND NVL( STR_20_1, 'x' ) <> 'TER' );



-- fsjhsgmx2arzp


VAR B1 VARCHAR2(32);
EXEC :B1 := 'DECLJ';
VAR B2 VARCHAR2(32);
EXEC :B2 := '2509207261';

SELECT COUNT(*)
  FROM MIGRLEAS_ACRP M
 WHERE M.REFDOSS = :B2
   AND M.CODE_ACTION = :B1
   AND EXISTS ( SELECT 1
                  FROM T_INTERVENANTS
                 WHERE REFDOSS = M.REFDOSS
                   AND REFTYPE IN ( 'MJ', 'RC' ) )
   AND EXISTS ( SELECT 1
                  FROM G_INDIVIDU I, 
                       T_INTERVENANTS T
                 WHERE T.REFDOSS = M.REFDOSS
                   AND T.REFTYPE = 'DB'
                   AND I.REFINDIVIDU = T.REFINDIVIDU
                   AND I.DT16_DT IS NULL
                   AND I.DT10_DT IS NULL
                   AND I.DTOUVTRJ_DT IS NOT NULL )
   AND (    NVL( M.CODE_ACTION, 'x' ) = 'SAUVRJ' 
       OR (    NVL( M.CODE_ACTION, 'x' ) = 'DECRJ' 
           AND NOT EXISTS ( SELECT 1
                              FROM MIGRLEAS_ACRP
                             WHERE REFDOSS = M.REFDOSS
                               AND NVL( CODE_ACTION, 'x' ) = 'SAUVGD' ) ) )
   AND NOT EXISTS ( SELECT 1
                      FROM MIGRLEAS_ACRP
                     WHERE REFDOSS = M.REFDOSS
                       AND NVL( CODE_ACTION, 'x' ) = 'DECLJ' )
   AND (  EXISTS ( SELECT 1
                     FROM MIGRLEAS_ACRP
                    WHERE REFDOSS = M.REFDOSS
                      AND CODE_ACTION = 'POURRJ'
                      AND ACTION_DT > ( SELECT MAX(ACTION_DT)
                                          FROM MIGRLEAS_ACRP
                                         WHERE REFDOSS = M.REFDOSS
                                           AND CODE_ACTION IN ( 'DECRJ', 'SAUVRJ' ) ) )
       OR NOT EXISTS ( SELECT 1
                         FROM MIGRLEAS_ACRP
                        WHERE REFDOSS = M.REFDOSS
                          AND CODE_ACTION IN ( 'POURRJ', 'RECMAT' ) ) )
   AND EXISTS ( SELECT 1
                 FROM G_PIECE P, 
                      G_PIECEDET PD
                WHERE P.REFDOSS = PD.REFDOSS
                  AND P.REFPIECE = PD.REFPIECE
                  AND P.REFDOSS = M.REFDOSS
                  AND P.TYPPIECE = 'FINANCING REQUEST'
                  AND PD.STR1 = 'CBR'
                  AND PD.TYPE = 'ANNEXE_DEMANDE_FIN'
                  AND PD.STR3 IN ( 'ECS', 'ACT' )
                  AND PD.STR5 = 'PCOLL' );


-- cfzhznan3argm


VAR B1 VARCHAR2(32);
EXEC :B1 := 'DECLJ';
VAR B2 VARCHAR2(32);
EXEC :B2 := '2509207261';

SELECT CASE
         WHEN EXISTS ( SELECT 1
                         FROM MIGRLEAS_ACRP
                        WHERE REFDOSS = :B1
                          AND CODE_ACTION = 'OSEO'
                          AND NVL( CODE_FIN, 'N' ) <> 'O' ) THEN 1
         WHEN EXISTS ( SELECT 1
                         FROM MIGRLEAS_ACRP M
                        WHERE REFDOSS = :B1
                          AND CODE_ACTION = 'MJOSEO'
                          AND NOT EXISTS ( SELECT 1
                                             FROM MIGRLEAS_ACRP
                                            WHERE REFDOSS = M.REFDOSS
                                              AND CODE_ACTION = 'TRFBPI'
                                              AND AGENDA_DT > M.AGENDA_DT ) ) THEN 2
         WHEN EXISTS ( SELECT 1
                         FROM MIGRLEAS_ACRP
                        WHERE REFDOSS = :B1
                          AND CODE_ACTION = 'TRFBPI'
                          AND NVL( CODE_FIN, 'N' ) <> 'O' ) THEN 3
         WHEN EXISTS ( SELECT 1
                         FROM MIGRLEAS_ACRP
                        WHERE REFDOSS = :B1
                          AND CODE_ACTION IN ( 'RGOSEO', 'RELBPI', 'COSEO' )
                          AND NVL( CODE_FIN, 'N' ) <> 'O'
                          AND EXISTS ( SELECT 1
                                         FROM T_ELEMENTS
                                        WHERE REFDOSS = :B1
                                          AND TYPEELEM = 'in'
                                          AND LIBELLE = 'DDE REGLEMENT EFFECTUE BPI' ) ) THEN 4                        
         ELSE 0
       END
  FROM DUAL;



-- b26wk5ca11ass

VAR B1 VARCHAR2(32);
EXEC :B1 := 'DECLJ';
VAR B2 VARCHAR2(32);
EXEC :B2 := '2509207261';


SELECT COUNT(*)
  FROM MIGRLEAS_ACRP M
 WHERE M.REFDOSS = :B2
   AND M.CODE_ACTION = :B1
   AND NOT EXISTS ( SELECT 1
                      FROM MIGRLEAS_ACRP
                     WHERE REFDOSS = M.REFDOSS
                       AND CODE_ACTION IN ( 'RELAPP', 'LITNR', 'LITCOM', 'LITECH', 'LITFRS' )
                       AND NVL( CODE_FIN, 'N' ) = 'N' )
   AND EXISTS ( SELECT 1
                  FROM MANAGEMENT_CRITERIA M1, 
                       G_PIECE P1
                 WHERE P1.REFDOSS = M.REFDOSS
                   AND P1.TYPPIECE = 'FINANCING REQUEST'
                   AND P1.REFPIECE = M1.REFPIECE
                   AND FG_REPUR_AGREE_LITIGATION IS NOT NULL
                   AND FG_REPUR_AGREE_LITIGATION = 'O' );


-- 9t4j7ccvwt61t

VAR B1 VARCHAR2(32);
EXEC :B1 := 'DECLJ';
VAR B2 VARCHAR2(32);
EXEC :B2 := '2509207261';

SELECT COUNT(*)
  FROM MIGRLEAS_ACRP M
 WHERE M.REFDOSS = :B2
   AND M.CODE_ACTION = :B1
   AND EXISTS ( SELECT 1
                  FROM MIGRLEAS_ACRP
                 WHERE REFDOSS = M.REFDOSS
                   AND CODE_ACTION = 'DECLJ'
                   AND CODE_FIN = 'O' )
   AND NOT EXISTS ( SELECT 1
                      FROM MIGRLEAS_ACRP
                     WHERE REFDOSS = M.REFDOSS
                       AND CODE_ACTION = 'DECLJ'
                       AND NVL( CODE_FIN, 'N' ) = 'N' );



-- bcy2vk55kuwn5

VAR B1 VARCHAR2(32);
EXEC :B1 := 'DECLJ';
VAR B2 VARCHAR2(32);
EXEC :B2 := '2509207261';

SELECT COUNT(*)
  FROM MIGRLEAS_ACRP M
 WHERE M.REFDOSS = :B2
   AND M.CODE_ACTION = :B1
   AND EXISTS ( SELECT 1
                  FROM T_LEAS_ASSETS T, 
                       G_PATRIMOINE P,
                       G_DOSSIER G
                 WHERE T.REFER_ASSET = P.REFPATRIMOINE
                   AND P.ETAT = 'ITNL'
                   AND T.REFDOSS_REQST = G.REFDOSS
                   AND G.REFDOSS = M.REFDOSS )
   AND EXISTS ( SELECT 1
                  FROM MIGRLEAS_ACRP
                 WHERE REFDOSS = M.REFDOSS
                   AND CODE_ACTION IN ( 'SAUVLJ', 'DECLJ' )
                   AND NVL( CODE_FIN, 'N' ) = 'N' );

/********************************OLD SQL*******************************************/
/********************************OLD Metrics***************************************/
/*

MODULE                           PROGRAM                                            CLIENT_ID       SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- -------------------------------------------------- --------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
lcl_lease_migr_es.process_acrp   std_migration_robot                                                                                               ON CPU               2025/01/09 16:07:57  2025/01/09 16:16:19        194                  7428 +000000000 00:08:21.760 53%
msgq_pilote                                                                                                                                        ON CPU               2025/01/09 16:09:50  2025/01/09 16:19:54         90               9275855 +000000000 00:10:04.160 24%
msgq_pilote                                                                                         8mk0mhw4mwdw5 3329449978                       direct path read     2025/01/09 16:09:39  2025/01/09 16:14:16         31                   261 +000000000 00:04:36.480 8%
msgq_pilote                                                                                                                                        db file sequential r 2025/01/09 16:09:39  2025/01/09 16:19:54         10                 12146 +000000000 00:10:14.400 3%


MODULE                           PROGRAM                                            CLIENT_ID       SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- -------------------------------------------------- --------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
lcl_lease_migr_es.process_acrp   std_migration_robot                                                                                                                    2025/01/09 16:07:57  2025/01/09 16:16:19        198                  7428 +000000000 00:08:21.760 100%


MODULE                           PROGRAM                                            CLIENT_ID       SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- -------------------------------------------------- --------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
lcl_lease_migr_es.process_acrp   std_migration_robot                                                                                               ON CPU               2025/01/09 16:07:57  2025/01/09 16:16:19        194                  7428 +000000000 00:08:21.760 98%
lcl_lease_migr_es.process_acrp   std_migration_robot                                                                                               db file sequential r 2025/01/09 16:08:18  2025/01/09 16:12:13          3                  1918 +000000000 00:03:55.519 2%
lcl_lease_migr_es.process_acrp   std_migration_robot                                                bcy2vk55kuwn5 1323022893        593      48641 latch: cache buffers 2025/01/09 16:13:15  2025/01/09 16:13:15          1                     1 +000000000 00:00:00.000 1%



MODULE                           PROGRAM                                            CLIENT_ID       SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- -------------------------------------------------- --------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
lcl_lease_migr_es.process_acrp   std_migration_robot                                                a5zucru4vr5y0 2525121979                       ON CPU               2025/01/09 16:08:48  2025/01/09 16:16:09         15                  3136 +000000000 00:07:20.320 8%
lcl_lease_migr_es.process_acrp   std_migration_robot                                                fsjhsgmx2arzp 3865875089                       ON CPU               2025/01/09 16:07:57  2025/01/09 16:15:58         14                  3633 +000000000 00:08:01.280 7%
lcl_lease_migr_es.process_acrp   std_migration_robot                                                cfzhznan3argm 2206726067                                            2025/01/09 16:08:18  2025/01/09 16:15:28         13                  3226 +000000000 00:07:10.079 7%
lcl_lease_migr_es.process_acrp   std_migration_robot                                                b26wk5ca11ass 1932356930                       ON CPU               2025/01/09 16:07:57  2025/01/09 16:16:09         11                  3690 +000000000 00:08:11.520 6%
lcl_lease_migr_es.process_acrp   std_migration_robot                                                9t4j7ccvwt61t 1335121589                       ON CPU               2025/01/09 16:08:59  2025/01/09 16:15:58         11                  2976 +000000000 00:06:59.840 6%
lcl_lease_migr_es.process_acrp   std_migration_robot                                                bcy2vk55kuwn5 1323022893                                            2025/01/09 16:07:57  2025/01/09 16:15:48          9                  3573 +000000000 00:07:51.040 5%
lcl_lease_migr_es.process_acrp   std_migration_robot                                                7yngnnwgms78y 2148766792                       ON CPU               2025/01/09 16:08:38  2025/01/09 16:14:47          7                  2756 +000000000 00:06:08.640 4%
lcl_lease_migr_es.process_acrp   std_migration_robot                                                3y58aq37jv65q 2087835472                       ON CPU               2025/01/09 16:10:41  2025/01/09 16:15:58          7                  2109 +000000000 00:05:17.440 4%
lcl_lease_migr_es.process_acrp   std_migration_robot                                                7hspmnk3tkb4d 2723009738                       ON CPU               2025/01/09 16:08:07  2025/01/09 16:14:16          7                  2842 +000000000 00:06:08.640 4%
lcl_lease_migr_es.process_acrp   std_migration_robot                                                bvctstkktvjs1 3545633249                       ON CPU               2025/01/09 16:10:00  2025/01/09 16:15:07          6                  2100 +000000000 00:05:07.198 3%
lcl_lease_migr_es.process_acrp   std_migration_robot                                                7f3jff1vp5vx1  462942679                       ON CPU               2025/01/09 16:08:07  2025/01/09 16:15:48          6                  3453 +000000000 00:07:40.800 3%
lcl_lease_migr_es.process_acrp   std_migration_robot                                                695hv281p5nr2 1132411390                       ON CPU               2025/01/09 16:09:50  2025/01/09 16:16:19          6                  2600 +000000000 00:06:29.120 3%
lcl_lease_migr_es.process_acrp   std_migration_robot                                                2bw5nwmqnxdjy  852916768                       ON CPU               2025/01/09 16:08:18  2025/01/09 16:13:04          6                  2263 +000000000 00:04:46.719 3%
lcl_lease_migr_es.process_acrp   std_migration_robot                                                0nd57ska2qx76 3477637290                       ON CPU               2025/01/09 16:07:57  2025/01/09 16:14:16          5                  2970 +000000000 00:06:18.880 3%
lcl_lease_migr_es.process_acrp   std_migration_robot                                                1tb7y5p2yk00n  438931248                       ON CPU               2025/01/09 16:09:19  2025/01/09 16:15:38          5                  2652 +000000000 00:06:18.880 3%
lcl_lease_migr_es.process_acrp   std_migration_robot                                                48k6g4shv75kg  153100076                       ON CPU               2025/01/09 16:08:07  2025/01/09 16:15:58          5                  3512 +000000000 00:07:51.040 3%
lcl_lease_migr_es.process_acrp   std_migration_robot                                                2vy6h8q78n29b   38289126                       ON CPU               2025/01/09 16:08:38  2025/01/09 16:15:28          5                  3012 +000000000 00:06:49.600 3%
lcl_lease_migr_es.process_acrp   std_migration_robot                                                bqd2w8zu4v6c4  519410738                       ON CPU               2025/01/09 16:12:23  2025/01/09 16:15:38          5                  1295 +000000000 00:03:14.559 3%
lcl_lease_migr_es.process_acrp   std_migration_robot                                                5xp6dv5v5mq76  630962092                       ON CPU               2025/01/09 16:11:01  2025/01/09 16:14:57          4                  1596 +000000000 00:03:55.520 2%


INSTANCE_NUMBER SQL_ID            ELAPSED MAX_WAIT_ON     PC_OF  WAIT_TIME            GETS      READS       ROWS  ELAP/EXEC       GETS/EXEC READS/EXEC  ROWS/EXEC       EXEC PLAN_HASH_VALUE
--------------- ------------- ----------- --------------- ----- ---------- --------------- ---------- ---------- ---------- --------------- ---------- ---------- ---------- ---------------
              1 9t4j7ccvwt61t         122 CPU             99%    77.842586        22852652          0       3819        .03            5984          0          1       3819      1335121589
              1 a5zucru4vr5y0         121 CPU             98%    74.300504        22134701         61       3819        .03            5797        .02          1       3818      2525121979
              1 b26wk5ca11ass          95 CPU             96%    58.733186        16593741        665       3818        .02            4347        .17          1       3817      1932356930
              1 bcy2vk55kuwn5          90 CPU             99%    56.650495        16584840          2       3819        .02            4345          0          1       3817      1323022893
              1 cfzhznan3argm         125 CPU             95%    81.645806        24169180        995       3819        .03            6332        .26          1       3817      2206726067
              1 fsjhsgmx2arzp          80 CPU             97%     51.53558        15307370        385       3819        .02            4008         .1          1       3819      3865875089


SQL_ID        SQL_PLAN_HASH_VALUE SQL_PLAN_LINE_ID SQL_PLAN_OPERATION             SQL_PLAN_OPTIONS                   ACTIVE
------------- ------------------- ---------------- ------------------------------ ------------------------------ ----------
bcy2vk55kuwn5          1323022893                5 TABLE ACCESS                   FULL                                    7
bcy2vk55kuwn5          1323022893                4 TABLE ACCESS                   FULL                                    2

SQL_ID        SQL_PLAN_HASH_VALUE SQL_PLAN_LINE_ID SQL_PLAN_OPERATION             SQL_PLAN_OPTIONS                   ACTIVE
------------- ------------------- ---------------- ------------------------------ ------------------------------ ----------
9t4j7ccvwt61t          1335121589                4 TABLE ACCESS                   FULL                                    6
9t4j7ccvwt61t          1335121589                5 TABLE ACCESS                   FULL                                    4
9t4j7ccvwt61t          1335121589                6 TABLE ACCESS                   FULL                                    1

SQL_ID        SQL_PLAN_HASH_VALUE SQL_PLAN_LINE_ID SQL_PLAN_OPERATION             SQL_PLAN_OPTIONS                   ACTIVE
------------- ------------------- ---------------- ------------------------------ ------------------------------ ----------
b26wk5ca11ass          1932356930                5 TABLE ACCESS                   FULL                                    8
b26wk5ca11ass          1932356930                3 HASH JOIN                      ANTI                                    2
b26wk5ca11ass          1932356930                4 TABLE ACCESS                   FULL                                    1

SQL_ID        SQL_PLAN_HASH_VALUE SQL_PLAN_LINE_ID SQL_PLAN_OPERATION             SQL_PLAN_OPTIONS                   ACTIVE
------------- ------------------- ---------------- ------------------------------ ------------------------------ ----------
cfzhznan3argm          2206726067                3 TABLE ACCESS                   FULL                                    6
cfzhznan3argm          2206726067                1 TABLE ACCESS                   FULL                                    3
cfzhznan3argm          2206726067                5 TABLE ACCESS                   FULL                                    2
cfzhznan3argm          2206726067                8 INDEX                          RANGE SCAN                              2

SQL_ID        SQL_PLAN_HASH_VALUE SQL_PLAN_LINE_ID SQL_PLAN_OPERATION             SQL_PLAN_OPTIONS                   ACTIVE
------------- ------------------- ---------------- ------------------------------ ------------------------------ ----------
a5zucru4vr5y0          2525121979                6 TABLE ACCESS                   FULL                                    6
a5zucru4vr5y0          2525121979                7 TABLE ACCESS                   FULL                                    5
a5zucru4vr5y0          2525121979                8 TABLE ACCESS                   FULL                                    4

SQL_ID        SQL_PLAN_HASH_VALUE SQL_PLAN_LINE_ID SQL_PLAN_OPERATION             SQL_PLAN_OPTIONS                   ACTIVE
------------- ------------------- ---------------- ------------------------------ ------------------------------ ----------
fsjhsgmx2arzp          3865875089                5 TABLE ACCESS                   FULL                                   10
fsjhsgmx2arzp          3865875089                6 TABLE ACCESS                   FULL                                    4


-- a5zucru4vr5y0

Plan hash value: 2525121979
----------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                              | Name          | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  |
----------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                       |               |      1 |        |   500 (100)|      1 |00:00:00.12 |    5288 |   1763 |
|   1 |  SORT AGGREGATE                        |               |      1 |      1 |            |      1 |00:00:00.12 |    5288 |   1763 |
|   2 |   NESTED LOOPS ANTI                    |               |      1 |      1 |   500   (1)|      1 |00:00:00.12 |    5288 |   1763 |
|   3 |    NESTED LOOPS SEMI                   |               |      1 |      1 |   499   (1)|      1 |00:00:00.12 |    5285 |   1760 |
|*  4 |     HASH JOIN ANTI                     |               |      1 |      1 |   498   (1)|      1 |00:00:00.11 |    5280 |   1757 |
|*  5 |      HASH JOIN ANTI                    |               |      1 |      1 |   332   (1)|      1 |00:00:00.11 |    3520 |   1757 |
|*  6 |       TABLE ACCESS FULL                | MIGRLEAS_ACRP |      1 |      1 |   166   (1)|      1 |00:00:00.11 |    1760 |   1757 |
|*  7 |       TABLE ACCESS FULL                | MIGRLEAS_ACRP |      1 |      1 |   166   (1)|      0 |00:00:00.01 |    1760 |      0 |
|*  8 |      TABLE ACCESS FULL                 | MIGRLEAS_ACRP |      1 |      1 |   166   (1)|      0 |00:00:00.01 |    1760 |      0 |
|*  9 |     TABLE ACCESS BY INDEX ROWID BATCHED| G_PIECE       |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       5 |      3 |
|* 10 |      INDEX RANGE SCAN                  | PIE_REFDOSS   |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |      2 |
|* 11 |    TABLE ACCESS BY INDEX ROWID BATCHED | G_PERSONNEL   |      1 |      1 |     1   (0)|      0 |00:00:00.01 |       3 |      3 |
|* 12 |     INDEX RANGE SCAN                   | GPERSREFP     |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       2 |      2 |
----------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   4 - access("REFDOSS"="M"."REFDOSS")
   5 - access("REFDOSS"="M"."REFDOSS")
   6 - filter(("M"."REFDOSS"=:B2 AND "M"."CODE_ACTION"=:B1))
   7 - filter(("REFDOSS"=:B2 AND (INTERNAL_FUNCTION("CODE_ACTION") OR "CODE_ACTION" LIKE 'LIT%')))
   8 - filter(("REFDOSS"=:B2 AND "CODE_ACTION"='AVICON' AND "CODE_FIN"<>'O'))
   9 - filter(NVL("STR_20_1",'x')<>'TER')
  10 - access("REFDOSS"=:B2 AND "TYPPIECE"='FINANCING REQUEST')
       filter("REFDOSS"="M"."REFDOSS")
  11 - filter("GROUPE"='SERVICE RECOUVREMENT CTX')
  12 - access("REFPERSO"="M"."REFPERSO")



-- fsjhsgmx2arzp

Plan hash value: 3865875089
---------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                              | Name            | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers |
---------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                       |                 |      1 |        |   668 (100)|      1 |00:00:00.01 |    1767 |
|   1 |  SORT AGGREGATE                        |                 |      1 |      1 |            |      1 |00:00:00.01 |    1767 |
|*  2 |   FILTER                               |                 |      1 |        |            |      0 |00:00:00.01 |    1767 |
|   3 |    NESTED LOOPS SEMI                   |                 |      1 |      1 |   333   (1)|      0 |00:00:00.01 |    1767 |
|*  4 |     HASH JOIN ANTI                     |                 |      1 |      1 |   332   (1)|      0 |00:00:00.01 |    1767 |
|*  5 |      TABLE ACCESS FULL                 | MIGRLEAS_ACRP   |      1 |      1 |   166   (1)|      1 |00:00:00.01 |    1761 |
|*  6 |      TABLE ACCESS FULL                 | MIGRLEAS_ACRP   |      1 |      1 |   166   (1)|      1 |00:00:00.01 |       6 |
|*  7 |     INDEX RANGE SCAN                   | INT_REFDOSS     |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|   8 |    NESTED LOOPS SEMI                   |                 |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |
|*  9 |     INDEX RANGE SCAN                   | INT_REFDOSS     |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 10 |     TABLE ACCESS BY INDEX ROWID        | G_INDIVIDU      |      0 |  10355 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 11 |      INDEX UNIQUE SCAN                 | IND_REFINDIV    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|  12 |    NESTED LOOPS SEMI                   |                 |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |
|  13 |     TABLE ACCESS BY INDEX ROWID BATCHED| G_PIECE         |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 14 |      INDEX RANGE SCAN                  | PIE_REFDOSS     |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 15 |     TABLE ACCESS BY INDEX ROWID BATCHED| G_PIECEDET      |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 16 |      INDEX RANGE SCAN                  | G_PIECEDET_REFP |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 17 |    FILTER                              |                 |      0 |        |            |      0 |00:00:00.01 |       0 |
|* 18 |     TABLE ACCESS FULL                  | MIGRLEAS_ACRP   |      0 |      1 |   166   (1)|      0 |00:00:00.01 |       0 |
|  19 |     SORT AGGREGATE                     |                 |      0 |      1 |            |      0 |00:00:00.01 |       0 |
|* 20 |      TABLE ACCESS FULL                 | MIGRLEAS_ACRP   |      0 |      2 |   166   (1)|      0 |00:00:00.01 |       0 |
|* 21 |    TABLE ACCESS FULL                   | MIGRLEAS_ACRP   |      0 |      2 |   158   (1)|      0 |00:00:00.01 |       0 |
|* 22 |    TABLE ACCESS FULL                   | MIGRLEAS_ACRP   |      0 |      1 |   166   (1)|      0 |00:00:00.01 |       0 |
---------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   2 - filter(( IS NOT NULL AND  IS NOT NULL AND ( IS NOT NULL OR  IS NULL) AND ("M"."CODE_ACTION"='SAUVRJ' OR
              ("M"."CODE_ACTION"='DECRJ' AND  IS NULL))))
   4 - access("REFDOSS"="M"."REFDOSS")
   5 - filter(("M"."REFDOSS"=:B2 AND "M"."CODE_ACTION"=:B1))
   6 - filter(("REFDOSS"=:B2 AND "CODE_ACTION"='DECLJ'))
   7 - access("REFDOSS"=:B2)
       filter(("REFDOSS"="M"."REFDOSS" AND INTERNAL_FUNCTION("REFTYPE")))
   9 - access("T"."REFDOSS"=:B1 AND "T"."REFTYPE"='DB')
  10 - filter(("I"."DTOUVTRJ_DT" IS NOT NULL AND "I"."DT10_DT" IS NULL AND "I"."DT16_DT" IS NULL))
  11 - access("I"."REFINDIVIDU"="T"."REFINDIVIDU")
  14 - access("P"."REFDOSS"=:B1 AND "P"."TYPPIECE"='FINANCING REQUEST')
  15 - filter(("PD"."REFDOSS"=:B1 AND "PD"."STR5"='PCOLL' AND "PD"."STR1"='CBR' AND INTERNAL_FUNCTION("PD"."STR3") AND
              "P"."REFDOSS"="PD"."REFDOSS"))
  16 - access("P"."REFPIECE"="PD"."REFPIECE" AND "PD"."TYPE"='ANNEXE_DEMANDE_FIN')
  17 - filter("ACTION_DT">)
  18 - filter(("REFDOSS"=:B1 AND "CODE_ACTION"='POURRJ'))
  20 - filter(("REFDOSS"=:B1 AND INTERNAL_FUNCTION("CODE_ACTION")))
  21 - filter(("REFDOSS"=:B1 AND INTERNAL_FUNCTION("CODE_ACTION")))
  22 - filter(("REFDOSS"=:B1 AND "CODE_ACTION"='SAUVGD'))



-- cfzhznan3argm

Plan hash value: 2206726067
-----------------------------------------------------------------------------------------------------------------------
| Id  | Operation             | Name                   | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers |
-----------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT      |                        |      1 |        |   832 (100)|      1 |00:00:00.01 |       0 |
|*  1 |  TABLE ACCESS FULL    | MIGRLEAS_ACRP          |      1 |      1 |   166   (1)|      0 |00:00:00.01 |    1761 |
|*  2 |   HASH JOIN ANTI      |                        |      1 |      1 |   332   (1)|      0 |00:00:00.01 |    1761 |
|*  3 |    TABLE ACCESS FULL  | MIGRLEAS_ACRP          |      1 |      1 |   166   (1)|      0 |00:00:00.01 |    1761 |
|*  4 |    TABLE ACCESS FULL  | MIGRLEAS_ACRP          |      0 |      1 |   166   (1)|      0 |00:00:00.01 |       0 |
|*  5 |    TABLE ACCESS FULL  | MIGRLEAS_ACRP          |      1 |      1 |   166   (1)|      0 |00:00:00.01 |    1761 |
|*  6 |     FILTER            |                        |      1 |        |            |      0 |00:00:00.01 |       3 |
|*  7 |      TABLE ACCESS FULL| MIGRLEAS_ACRP          |      0 |      1 |   166   (1)|      0 |00:00:00.01 |       0 |
|*  8 |      INDEX RANGE SCAN | ELE_DOSS_TYP_ASSOC_LIB |      1 |      1 |     1   (0)|      0 |00:00:00.01 |       3 |
|   9 |  FAST DUAL            |                        |      1 |      1 |     2   (0)|      1 |00:00:00.01 |       0 |
-----------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   1 - filter(("REFDOSS"=:B1 AND "CODE_ACTION"='OSEO' AND "CODE_FIN"<>'O'))
   2 - access("REFDOSS"="M"."REFDOSS")
       filter("AGENDA_DT">"M"."AGENDA_DT")
   3 - filter(("REFDOSS"=:B1 AND "CODE_ACTION"='MJOSEO'))
   4 - filter(("REFDOSS"=:B1 AND "CODE_ACTION"='TRFBPI'))
   5 - filter(("REFDOSS"=:B1 AND "CODE_ACTION"='TRFBPI' AND "CODE_FIN"<>'O'))
   6 - filter( IS NOT NULL)
   7 - filter(("REFDOSS"=:B1 AND "CODE_FIN"<>'O' AND INTERNAL_FUNCTION("CODE_ACTION")))
   8 - access("REFDOSS"=:B1 AND "TYPEELEM"='in' AND "LIBELLE"='DDE REGLEMENT EFFECTUE BPI')
       filter("LIBELLE"='DDE REGLEMENT EFFECTUE BPI')



-- b26wk5ca11ass

Plan hash value: 1932356930
-------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                              | Name                | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers |
-------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                       |                     |      1 |        |   334 (100)|      1 |00:00:00.01 |    3528 |
|   1 |  SORT AGGREGATE                        |                     |      1 |      1 |            |      1 |00:00:00.01 |    3528 |
|*  2 |   FILTER                               |                     |      1 |        |            |      0 |00:00:00.01 |    3528 |
|*  3 |    HASH JOIN ANTI                      |                     |      1 |      1 |   332   (1)|      1 |00:00:00.01 |    3522 |
|*  4 |     TABLE ACCESS FULL                  | MIGRLEAS_ACRP       |      1 |      1 |   166   (1)|      1 |00:00:00.01 |    1761 |
|*  5 |     TABLE ACCESS FULL                  | MIGRLEAS_ACRP       |      1 |      1 |   166   (1)|      0 |00:00:00.01 |    1761 |
|   6 |    NESTED LOOPS SEMI                   |                     |      1 |      1 |     2   (0)|      0 |00:00:00.01 |       6 |
|   7 |     TABLE ACCESS BY INDEX ROWID BATCHED| G_PIECE             |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       4 |
|*  8 |      INDEX RANGE SCAN                  | PIE_REFDOSS         |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |
|*  9 |     TABLE ACCESS BY INDEX ROWID BATCHED| MANAGEMENT_CRITERIA |      1 |      1 |     1   (0)|      0 |00:00:00.01 |       2 |
|* 10 |      INDEX RANGE SCAN                  | MC_REFPIECE_IDX     |      1 |      1 |     1   (0)|      0 |00:00:00.01 |       2 |
-------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   2 - filter( IS NOT NULL)
   3 - access("REFDOSS"="M"."REFDOSS")
   4 - filter(("M"."REFDOSS"=:B2 AND "M"."CODE_ACTION"=:B1))
   5 - filter(("REFDOSS"=:B2 AND "CODE_FIN"='N' AND INTERNAL_FUNCTION("CODE_ACTION")))
   8 - access("P1"."REFDOSS"=:B1 AND "P1"."TYPPIECE"='FINANCING REQUEST')
   9 - filter("FG_REPUR_AGREE_LITIGATION"='O')
  10 - access("P1"."REFPIECE"="M1"."REFPIECE")



-- 9t4j7ccvwt61t


Plan hash value: 1335121589
-------------------------------------------------------------------------------------------------------------
| Id  | Operation            | Name          | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers |
-------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT     |               |      1 |        |   498 (100)|      1 |00:00:00.01 |    3525 |
|   1 |  SORT AGGREGATE      |               |      1 |      1 |            |      1 |00:00:00.01 |    3525 |
|*  2 |   HASH JOIN SEMI     |               |      1 |      1 |   498   (1)|      1 |00:00:00.01 |    3525 |
|*  3 |    HASH JOIN ANTI    |               |      1 |      1 |   332   (1)|      1 |00:00:00.01 |    3520 |
|*  4 |     TABLE ACCESS FULL| MIGRLEAS_ACRP |      1 |      1 |   166   (1)|      1 |00:00:00.01 |    1760 |
|*  5 |     TABLE ACCESS FULL| MIGRLEAS_ACRP |      1 |      1 |   166   (1)|      0 |00:00:00.01 |    1760 |
|*  6 |    TABLE ACCESS FULL | MIGRLEAS_ACRP |      1 |      1 |   166   (1)|      1 |00:00:00.01 |       5 |
-------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   2 - access("REFDOSS"="M"."REFDOSS")
   3 - access("REFDOSS"="M"."REFDOSS")
   4 - filter(("M"."REFDOSS"=:B2 AND "M"."CODE_ACTION"=:B1))
   5 - filter(("REFDOSS"=:B2 AND "CODE_ACTION"='DECLJ' AND "CODE_FIN"='N'))
   6 - filter(("REFDOSS"=:B2 AND "CODE_ACTION"='DECLJ' AND "CODE_FIN"='O'))



-- bcy2vk55kuwn5


Plan hash value: 1323022893
-----------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                               | Name                         | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers |
-----------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                        |                              |      1 |        |   335 (100)|      1 |00:00:00.01 |    3522 |
|   1 |  SORT AGGREGATE                         |                              |      1 |      1 |            |      1 |00:00:00.01 |    3522 |
|*  2 |   FILTER                                |                              |      1 |        |            |      0 |00:00:00.01 |    3522 |
|*  3 |    HASH JOIN SEMI                       |                              |      1 |      1 |   332   (1)|      0 |00:00:00.01 |    3522 |
|*  4 |     TABLE ACCESS FULL                   | MIGRLEAS_ACRP                |      1 |      1 |   166   (1)|      1 |00:00:00.01 |    1761 |
|*  5 |     TABLE ACCESS FULL                   | MIGRLEAS_ACRP                |      1 |      1 |   166   (1)|      0 |00:00:00.01 |    1761 |
|   6 |    NESTED LOOPS SEMI                    |                              |      0 |      2 |     3   (0)|      0 |00:00:00.01 |       0 |
|   7 |     NESTED LOOPS                        |                              |      0 |      2 |     2   (0)|      0 |00:00:00.01 |       0 |
|*  8 |      INDEX UNIQUE SCAN                  | DOS_REFDOSS                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|   9 |      TABLE ACCESS BY INDEX ROWID BATCHED| T_LEAS_ASSETS                |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 10 |       INDEX RANGE SCAN                  | IDX_LEAS_ASSET_REFDOSS_REQST |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 11 |     TABLE ACCESS BY INDEX ROWID BATCHED | G_PATRIMOINE                 |      0 |  92506 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 12 |      INDEX RANGE SCAN                   | PATREFPATRIMOINE             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
-----------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   2 - filter( IS NOT NULL)
   3 - access("REFDOSS"="M"."REFDOSS")
   4 - filter(("M"."REFDOSS"=:B2 AND "M"."CODE_ACTION"=:B1))
   5 - filter(("REFDOSS"=:B2 AND "CODE_FIN"='N' AND INTERNAL_FUNCTION("CODE_ACTION")))
   8 - access("G"."REFDOSS"=:B1)
  10 - access("T"."REFDOSS_REQST"=:B1)
  11 - filter("P"."ETAT"='ITNL')
  12 - access("T"."REFER_ASSET"="P"."REFPATRIMOINE")

*/
/********************************OLD Metrics***************************************/

/********************************New SQL*******************************************/

-- No changes in the SQL texts.
/********************************New SQL*******************************************/
/********************************New Metrics***************************************/
/*
-- a5zucru4vr5y0

-- With index

Plan hash value: 1290743748
---------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                | Name          | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers |
---------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                         |               |      1 |        |     5 (100)|      1 |00:00:00.01 |      15 |
|   1 |  SORT AGGREGATE                          |               |      1 |      1 |            |      1 |00:00:00.01 |      15 |
|   2 |   NESTED LOOPS ANTI                      |               |      1 |      1 |     5   (0)|      1 |00:00:00.01 |      15 |
|   3 |    NESTED LOOPS ANTI                     |               |      1 |      1 |     4   (0)|      1 |00:00:00.01 |      13 |
|   4 |     NESTED LOOPS ANTI                    |               |      1 |      1 |     3   (0)|      1 |00:00:00.01 |      11 |
|   5 |      NESTED LOOPS SEMI                   |               |      1 |      1 |     2   (0)|      1 |00:00:00.01 |       8 |
|   6 |       TABLE ACCESS BY INDEX ROWID BATCHED| MIGRLEAS_ACRP |      1 |     25 |     1   (0)|      1 |00:00:00.01 |       3 |
|*  7 |        INDEX RANGE SCAN                  | TEST_DD_INDEX |      1 |     25 |     1   (0)|      1 |00:00:00.01 |       2 |
|*  8 |       TABLE ACCESS BY INDEX ROWID BATCHED| G_PIECE       |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       5 |
|*  9 |        INDEX RANGE SCAN                  | PIE_REFDOSS   |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |
|* 10 |      TABLE ACCESS BY INDEX ROWID BATCHED | G_PERSONNEL   |      1 |      1 |     1   (0)|      0 |00:00:00.01 |       3 |
|* 11 |       INDEX RANGE SCAN                   | GPERSREFP     |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       2 |
|* 12 |     INDEX RANGE SCAN                     | TEST_DD_INDEX |      1 |      1 |     1   (0)|      0 |00:00:00.01 |       2 |
|* 13 |    TABLE ACCESS BY INDEX ROWID BATCHED   | MIGRLEAS_ACRP |      1 |      1 |     1   (0)|      0 |00:00:00.01 |       2 |
|* 14 |     INDEX RANGE SCAN                     | TEST_DD_INDEX |      1 |     25 |     1   (0)|      0 |00:00:00.01 |       2 |
---------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   7 - access("M"."REFDOSS"=:B2 AND "M"."CODE_ACTION"=:B1)
   8 - filter(NVL("STR_20_1",'x')<>'TER')
   9 - access("REFDOSS"=:B2 AND "TYPPIECE"='FINANCING REQUEST')
       filter("REFDOSS"="M"."REFDOSS")
  10 - filter("GROUPE"='SERVICE RECOUVREMENT CTX')
  11 - access("REFPERSO"="M"."REFPERSO")
  12 - access("REFDOSS"=:B2)
       filter((INTERNAL_FUNCTION("CODE_ACTION") OR "CODE_ACTION" LIKE 'LIT%'))
  13 - filter("CODE_FIN"<>'O')
  14 - access("REFDOSS"=:B2 AND "CODE_ACTION"='AVICON')



-- fsjhsgmx2arzp

-- With index

Plan hash value: 3892305650
--------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                | Name            | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  |
--------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                         |                 |      1 |        |     9 (100)|      1 |00:00:00.01 |      11 |      7 |
|   1 |  SORT AGGREGATE                          |                 |      1 |      1 |            |      1 |00:00:00.01 |      11 |      7 |
|*  2 |   FILTER                                 |                 |      1 |        |            |      0 |00:00:00.01 |      11 |      7 |
|   3 |    NESTED LOOPS SEMI                     |                 |      1 |      1 |     5   (0)|      0 |00:00:00.01 |      11 |      7 |
|   4 |     NESTED LOOPS SEMI                    |                 |      1 |      1 |     3   (0)|      0 |00:00:00.01 |      11 |      7 |
|   5 |      NESTED LOOPS ANTI                   |                 |      1 |      1 |     2   (0)|      0 |00:00:00.01 |      11 |      7 |
|*  6 |       INDEX RANGE SCAN                   | TEST_DD_INDEX   |      1 |      1 |     1   (0)|      0 |00:00:00.01 |      11 |      7 |
|   7 |        NESTED LOOPS SEMI                 |                 |      1 |      1 |     2   (0)|      0 |00:00:00.01 |       9 |      7 |
|*  8 |         INDEX RANGE SCAN                 | INT_REFDOSS     |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |      3 |
|*  9 |         TABLE ACCESS BY INDEX ROWID      | G_INDIVIDU      |      1 |  10355 |     1   (0)|      0 |00:00:00.01 |       6 |      4 |
|* 10 |          INDEX UNIQUE SCAN               | IND_REFINDIV    |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |      2 |
|* 11 |       INDEX RANGE SCAN                   | TEST_DD_INDEX   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 12 |      INDEX RANGE SCAN                    | INT_REFDOSS     |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|  13 |     VIEW PUSHED PREDICATE                | VW_SQ_1         |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|  14 |      NESTED LOOPS SEMI                   |                 |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|  15 |       TABLE ACCESS BY INDEX ROWID BATCHED| G_PIECE         |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 16 |        INDEX RANGE SCAN                  | PIE_REFDOSS     |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 17 |       TABLE ACCESS BY INDEX ROWID BATCHED| G_PIECEDET      |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 18 |        INDEX RANGE SCAN                  | G_PIECEDET_REFP |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 19 |    FILTER                                |                 |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  20 |     TABLE ACCESS BY INDEX ROWID BATCHED  | MIGRLEAS_ACRP   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 21 |      INDEX RANGE SCAN                    | TEST_DD_INDEX   |      0 |     25 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|  22 |     SORT AGGREGATE                       |                 |      0 |      1 |            |      0 |00:00:00.01 |       0 |      0 |
|  23 |      TABLE ACCESS BY INDEX ROWID BATCHED | MIGRLEAS_ACRP   |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 24 |       INDEX RANGE SCAN                   | TEST_DD_INDEX   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|  25 |    INLIST ITERATOR                       |                 |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|* 26 |     INDEX RANGE SCAN                     | TEST_DD_INDEX   |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 27 |    INDEX RANGE SCAN                      | TEST_DD_INDEX   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
--------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   2 - filter((( IS NOT NULL OR  IS NULL) AND ("M"."CODE_ACTION"='SAUVRJ' OR ("M"."CODE_ACTION"='DECRJ' AND  IS NULL))))
   6 - access("M"."REFDOSS"=:B2 AND "M"."CODE_ACTION"=:B1)
       filter( IS NOT NULL)
   8 - access("T"."REFDOSS"=:B1 AND "T"."REFTYPE"='DB')
   9 - filter(("I"."DTOUVTRJ_DT" IS NOT NULL AND "I"."DT10_DT" IS NULL AND "I"."DT16_DT" IS NULL))
  10 - access("I"."REFINDIVIDU"="T"."REFINDIVIDU")
  11 - access("REFDOSS"=:B2 AND "CODE_ACTION"='DECLJ')
  12 - access("REFDOSS"=:B2)
       filter(("REFDOSS"="M"."REFDOSS" AND INTERNAL_FUNCTION("REFTYPE")))
  16 - access("P"."REFDOSS"="M"."REFDOSS" AND "P"."TYPPIECE"='FINANCING REQUEST')
  17 - filter(("PD"."REFDOSS"="M"."REFDOSS" AND "PD"."STR5"='PCOLL' AND "PD"."STR1"='CBR' AND INTERNAL_FUNCTION("PD"."STR3") AND
              "P"."REFDOSS"="PD"."REFDOSS"))
  18 - access("P"."REFPIECE"="PD"."REFPIECE" AND "PD"."TYPE"='ANNEXE_DEMANDE_FIN')
  19 - filter("ACTION_DT">)
  21 - access("REFDOSS"=:B1 AND "CODE_ACTION"='POURRJ')
  24 - access("REFDOSS"=:B1)
       filter(("CODE_ACTION"='DECRJ' OR "CODE_ACTION"='SAUVRJ'))
  26 - access("REFDOSS"=:B1 AND (("CODE_ACTION"='POURRJ' OR "CODE_ACTION"='RECMAT')))
  27 - access("REFDOSS"=:B1 AND "CODE_ACTION"='SAUVGD')



-- cfzhznan3argm

-- With index

Plan hash value: 3711900007
----------------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                 | Name                   | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  |
----------------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                          |                        |      1 |        |     8 (100)|      1 |00:00:00.01 |       0 |      0 |
|*  1 |  TABLE ACCESS BY INDEX ROWID BATCHED      | MIGRLEAS_ACRP          |      1 |      1 |     1   (0)|      0 |00:00:00.01 |       2 |      0 |
|*  2 |   INDEX RANGE SCAN                        | TEST_DD_INDEX          |      1 |      1 |     1   (0)|      0 |00:00:00.01 |       2 |      0 |
|   3 |   NESTED LOOPS ANTI                       |                        |      1 |      1 |     2   (0)|      0 |00:00:00.01 |       2 |      0 |
|   4 |    TABLE ACCESS BY INDEX ROWID BATCHED    | MIGRLEAS_ACRP          |      1 |      1 |     1   (0)|      0 |00:00:00.01 |       2 |      0 |
|*  5 |     INDEX RANGE SCAN                      | TEST_DD_INDEX          |      1 |      1 |     1   (0)|      0 |00:00:00.01 |       2 |      0 |
|*  6 |    TABLE ACCESS BY INDEX ROWID BATCHED    | MIGRLEAS_ACRP          |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*  7 |     INDEX RANGE SCAN                      | TEST_DD_INDEX          |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*  8 |     TABLE ACCESS BY INDEX ROWID BATCHED   | MIGRLEAS_ACRP          |      1 |      1 |     1   (0)|      0 |00:00:00.01 |       2 |      0 |
|*  9 |      INDEX RANGE SCAN                     | TEST_DD_INDEX          |      1 |      1 |     1   (0)|      0 |00:00:00.01 |       2 |      0 |
|* 10 |      FILTER                               |                        |      1 |        |            |      0 |00:00:00.01 |       3 |      3 |
|  11 |       INLIST ITERATOR                     |                        |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|* 12 |        TABLE ACCESS BY INDEX ROWID BATCHED| MIGRLEAS_ACRP          |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 13 |         INDEX SKIP SCAN                   | TEST_DD_INDEX          |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 14 |       INDEX RANGE SCAN                    | ELE_DOSS_TYP_ASSOC_LIB |      1 |      1 |     1   (0)|      0 |00:00:00.01 |       3 |      3 |
|  15 |  FAST DUAL                                |                        |      1 |      1 |     2   (0)|      1 |00:00:00.01 |       0 |      0 |
----------------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   1 - filter("CODE_FIN"<>'O')
   2 - access("REFDOSS"=:B1 AND "CODE_ACTION"='OSEO')
   5 - access("REFDOSS"=:B1 AND "CODE_ACTION"='MJOSEO')
   6 - filter("AGENDA_DT">"M"."AGENDA_DT")
   7 - access("REFDOSS"=:B1 AND "CODE_ACTION"='TRFBPI')
   8 - filter("CODE_FIN"<>'O')
   9 - access("REFDOSS"=:B1 AND "CODE_ACTION"='TRFBPI')
  10 - filter( IS NOT NULL)
  12 - filter("CODE_FIN"<>'O')
  13 - access("REFDOSS"=:B1 AND (("CODE_ACTION"='COSEO' OR "CODE_ACTION"='RELBPI' OR "CODE_ACTION"='RGOSEO')))
  14 - access("REFDOSS"=:B1 AND "TYPEELEM"='in' AND "LIBELLE"='DDE REGLEMENT EFFECTUE BPI')
       filter("LIBELLE"='DDE REGLEMENT EFFECTUE BPI')



-- b26wk5ca11ass


-- With index

Plan hash value: 47362811
------------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                | Name                | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  |
------------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                         |                     |      1 |        |     4 (100)|      1 |00:00:00.01 |       8 |      2 |
|   1 |  SORT AGGREGATE                          |                     |      1 |      1 |            |      1 |00:00:00.01 |       8 |      2 |
|   2 |   NESTED LOOPS ANTI                      |                     |      1 |      1 |     4   (0)|      0 |00:00:00.01 |       8 |      2 |
|*  3 |    HASH JOIN SEMI                        |                     |      1 |      1 |     3   (0)|      0 |00:00:00.01 |       8 |      2 |
|*  4 |     INDEX RANGE SCAN                     | TEST_DD_INDEX       |      1 |     25 |     1   (0)|      1 |00:00:00.01 |       2 |      0 |
|   5 |     VIEW                                 | VW_SQ_1             |      1 |      1 |     2   (0)|      0 |00:00:00.01 |       6 |      2 |
|   6 |      NESTED LOOPS SEMI                   |                     |      1 |      1 |     2   (0)|      0 |00:00:00.01 |       6 |      2 |
|   7 |       TABLE ACCESS BY INDEX ROWID BATCHED| G_PIECE             |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       4 |      0 |
|*  8 |        INDEX RANGE SCAN                  | PIE_REFDOSS         |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |      0 |
|*  9 |       TABLE ACCESS BY INDEX ROWID BATCHED| MANAGEMENT_CRITERIA |      1 |      1 |     1   (0)|      0 |00:00:00.01 |       2 |      2 |
|* 10 |        INDEX RANGE SCAN                  | MC_REFPIECE_IDX     |      1 |      1 |     1   (0)|      0 |00:00:00.01 |       2 |      2 |
|* 11 |    TABLE ACCESS BY INDEX ROWID BATCHED   | MIGRLEAS_ACRP       |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 12 |     INDEX RANGE SCAN                     | TEST_DD_INDEX       |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
------------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   3 - access("ITEM_1"="M"."REFDOSS")
   4 - access("M"."REFDOSS"=:B2 AND "M"."CODE_ACTION"=:B1)
   8 - access("P1"."REFDOSS"=:B2 AND "P1"."TYPPIECE"='FINANCING REQUEST')
   9 - filter("FG_REPUR_AGREE_LITIGATION"='O')
  10 - access("P1"."REFPIECE"="M1"."REFPIECE")
  11 - filter("CODE_FIN"='N')
  12 - access("REFDOSS"=:B2)
       filter(("CODE_ACTION"='LITCOM' OR "CODE_ACTION"='LITECH' OR "CODE_ACTION"='LITFRS' OR "CODE_ACTION"='LITNR' OR
              "CODE_ACTION"='RELAPP'))



-- 9t4j7ccvwt61t

-- With index

Plan hash value: 1842609560
-------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                              | Name          | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers |
-------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                       |               |      1 |        |     3 (100)|      1 |00:00:00.01 |       8 |
|   1 |  SORT AGGREGATE                        |               |      1 |      1 |            |      1 |00:00:00.01 |       8 |
|   2 |   NESTED LOOPS ANTI                    |               |      1 |      1 |     3   (0)|      1 |00:00:00.01 |       8 |
|*  3 |    HASH JOIN SEMI                      |               |      1 |      1 |     2   (0)|      1 |00:00:00.01 |       5 |
|*  4 |     INDEX RANGE SCAN                   | TEST_DD_INDEX |      1 |     25 |     1   (0)|      1 |00:00:00.01 |       2 |
|*  5 |     TABLE ACCESS BY INDEX ROWID BATCHED| MIGRLEAS_ACRP |      1 |     12 |     1   (0)|      1 |00:00:00.01 |       3 |
|*  6 |      INDEX RANGE SCAN                  | TEST_DD_INDEX |      1 |     25 |     1   (0)|      1 |00:00:00.01 |       2 |
|*  7 |    TABLE ACCESS BY INDEX ROWID BATCHED | MIGRLEAS_ACRP |      1 |      1 |     1   (0)|      0 |00:00:00.01 |       3 |
|*  8 |     INDEX RANGE SCAN                   | TEST_DD_INDEX |      1 |     25 |     1   (0)|      1 |00:00:00.01 |       2 |
-------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   3 - access("REFDOSS"="M"."REFDOSS")
   4 - access("M"."REFDOSS"=:B2 AND "M"."CODE_ACTION"=:B1)
   5 - filter("CODE_FIN"='O')
   6 - access("REFDOSS"=:B2 AND "CODE_ACTION"='DECLJ')
   7 - filter("CODE_FIN"='N')
   8 - access("REFDOSS"=:B2 AND "CODE_ACTION"='DECLJ')



-- bcy2vk55kuwn5


-- With index

Plan hash value: 1847145666
---------------------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                | Name                         | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  |
---------------------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                         |                              |      1 |        |     5 (100)|      1 |00:00:00.01 |       7 |      3 |
|   1 |  SORT AGGREGATE                          |                              |      1 |      1 |            |      1 |00:00:00.01 |       7 |      3 |
|   2 |   NESTED LOOPS SEMI                      |                              |      1 |      1 |     2   (0)|      0 |00:00:00.01 |       7 |      3 |
|*  3 |    INDEX RANGE SCAN                      | TEST_DD_INDEX                |      1 |      1 |     1   (0)|      0 |00:00:00.01 |       7 |      3 |
|   4 |     NESTED LOOPS SEMI                    |                              |      1 |      2 |     3   (0)|      0 |00:00:00.01 |       5 |      3 |
|   5 |      NESTED LOOPS                        |                              |      1 |      2 |     2   (0)|      0 |00:00:00.01 |       5 |      3 |
|*  6 |       INDEX UNIQUE SCAN                  | DOS_REFDOSS                  |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |      1 |
|   7 |       TABLE ACCESS BY INDEX ROWID BATCHED| T_LEAS_ASSETS                |      1 |      2 |     1   (0)|      0 |00:00:00.01 |       2 |      2 |
|*  8 |        INDEX RANGE SCAN                  | IDX_LEAS_ASSET_REFDOSS_REQST |      1 |      1 |     1   (0)|      0 |00:00:00.01 |       2 |      2 |
|*  9 |      TABLE ACCESS BY INDEX ROWID BATCHED | G_PATRIMOINE                 |      0 |  92506 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 10 |       INDEX RANGE SCAN                   | PATREFPATRIMOINE             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 11 |    TABLE ACCESS BY INDEX ROWID BATCHED   | MIGRLEAS_ACRP                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 12 |     INDEX RANGE SCAN                     | TEST_DD_INDEX                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
---------------------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   3 - access("M"."REFDOSS"=:B2 AND "M"."CODE_ACTION"=:B1)
       filter( IS NOT NULL)
   6 - access("G"."REFDOSS"=:B1)
   8 - access("T"."REFDOSS_REQST"=:B1)
   9 - filter("P"."ETAT"='ITNL')
  10 - access("T"."REFER_ASSET"="P"."REFPATRIMOINE")
  11 - filter("CODE_FIN"='N')
  12 - access("REFDOSS"=:B2)
       filter(("REFDOSS"="M"."REFDOSS" AND INTERNAL_FUNCTION("CODE_ACTION")))

*/
/********************************New Metrics***************************************/

/********************************Index statistics**********************************/

/********************************Other SQLs****************************************/          
/*

*/ 
/********************************Other SQLs****************************************/              
