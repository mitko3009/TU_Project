/********************************************************************************
*********       E-mail subject: IMBWEB-7658
*********             Instance: PROD
*********          Description: 
Problem:
Slow processing of 20 seconds per item by the limit_changed@ call on IMB PROD.

Analysis:
For module msgq_limit_changed for the provided SID 32 the TOP SQL which took 100% of the time was 5af3m3rc1s2yd.
The purpose of this SQL is to select the used memory, but instead of selecting it from table v$mystat, the query was using 
table V$SESSTAT, which took around 2 seconds per execution. The solution is to modify the query to use table v$mystat instead of table V$SESSTAT.

Suggestion:
Please modify the query as it is shown in the New SQL section below.

*********               SQL_ID: 5af3m3rc1s2yd
*********      Program/Package: msgq_limit_changed
*********              Request: Dimitare Ivanov
*********               Author: Dimitar Dimitrov
********* Received e-mail date: 26/02/2024
*********      Resolution date: 26/02/2024
*********  Trace old file here: \\epox\specifs\performance\tmp\
*********  Trace new file here:
***********************************************************************************/

/********************************OLD SQL*******************************************/

SELECT LISTAGG( ROUND( SS.VALUE/1024/1024, 2 ), ' | ' ) WITHIN 
 GROUP (ORDER BY SS.STATISTIC#) || ' MB' 
  FROM V$SESSTAT SS 
 WHERE SS.STATISTIC# IN ( 39, 40 ) 
   AND SS.SID = SYS_CONTEXT('USERENV', 'SID');
/********************************OLD SQL*******************************************/
/********************************OLD Metrics***************************************/
/*
MODULE                           SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL            PERC
-------------------------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
msgq_limit_changed               5af3m3rc1s2yd 2870574464         32      36475 ON CPU               2024/02/26 14:37:13  2024/02/26 15:33:16         324                 1842 +000000000 00:56:02.944 66%
msgq_calfidec                                                     32            ON CPU               2024/02/26 11:10:47  2024/02/26 15:40:37         112             16799786 +000000000 04:29:49.887 23%
                                                        0         32       3535 ON CPU               2024/02/26 10:53:27  2024/02/26 13:16:30           9                      +000000000 02:23:02.529 2%
msgq                             9h9hjc3u8j6wf                    32            ON CPU               2024/02/26 12:13:40  2024/02/26 15:38:24           7             16780527 +000000000 03:24:43.009 1%
484D1A4168F0449D1BF42A62072C4231 5j0ckdwh8mv4k 1181106023         32      31747 cell single block ph 2024/02/26 13:39:48  2024/02/26 13:40:49           6                    1 +000000000 00:01:01.440 1%
DBMS_SCHEDULER                                          0         32            JS kgl get object wa 2024/02/26 11:18:39  2024/02/26 13:52:54           2                      +000000000 02:34:14.711 0%
std_debtor2imx                                                    32      31412 ON CPU               2024/02/26 12:10:15  2024/02/26 12:10:46           2                11607 +000000000 00:00:30.719 0%
m


MODULE                           SQL_ID         PLAN_HASH     SID SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL            PERC
-------------------------------- ------------- ---------- ------- ------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
msgq_limit_changed                                             32   36475 ON CPU               2024/02/26 14:37:11  2024/02/26 15:33:18        3257               207494 +000000000 00:56:07.041 100%
msgq_limit_changed               dwt5bk927s4wg 3255309012      32   36475 gc current block 2-w 2024/02/26 15:22:20  2024/02/26 15:22:20           1                    1 +000000000 00:00:00.000 0%
msgq_limit_changed                                      0      32   36475 log file sync        2024/02/26 15:33:21  2024/02/26 15:33:21           1                      +000000000 00:00:00.000 0%
msgq_limit_changed               cjv14z7g0bcf6 3433385078      32   36475 gc cr block 2-way    2024/02/26 14:45:54  2024/02/26 14:45:54           1                    1 +000000000 00:00:00.000 0%


MODULE                           SQL_ID         PLAN_HASH     SID SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL            PERC
-------------------------------- ------------- ---------- ------- ------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
msgq_limit_changed               5af3m3rc1s2yd 2870574464      32   36475 ON CPU               2024/02/26 14:37:13  2024/02/26 15:33:18        3251                 1844 +000000000 00:56:04.993 100%
msgq_limit_changed                                      0      32   36475                      2024/02/26 14:57:39  2024/02/26 15:33:21           3                      +000000000 00:35:41.824 0%
msgq_limit_changed               cjv14z7g0bcf6 3433385078      32   36475 gc cr block 2-way    2024/02/26 14:45:54  2024/02/26 14:45:54           1                    1 +000000000 00:00:00.000 0%
msgq_limit_changed               dwt5bk927s4wg 3255309012      32   36475 gc current block 2-w 2024/02/26 15:22:20  2024/02/26 15:22:20           1                    1 +000000000 00:00:00.000 0%
msgq_limit_changed               70j8u0wvz2zxv 2920079658      32   36475 ON CPU               2024/02/26 14:39:33  2024/02/26 14:39:33           1                      +000000000 00:00:00.000 0%
msgq_limit_changed               9dr4u1uxvw4k3 1388734953      32   36475 ON CPU               2024/02/26 14:38:12  2024/02/26 14:38:12           1                    1 +000000000 00:00:00.000 0%
msgq_limit_changed               9yy1s182c7rk6 3293798335      32   36475 ON CPU               2024/02/26 14:37:11  2024/02/26 14:37:11           1                    1 +000000000 00:00:00.000 0%
msgq_limit_changed               agf5wfn35bzur 2920079658      32   36475 ON CPU               2024/02/26 15:04:08  2024/02/26 15:04:08           1                    1 +000000000 00:00:00.000 0%


INSTANCE_NUMBER SQL_ID            ELAPSED MAX_WAIT_ON     PC_OF  WAIT_TIME            GETS      READS       ROWS  ELAP/EXEC       GETS/EXEC READS/EXEC  ROWS/EXEC       EXEC PLAN_HASH_VALUE
--------------- ------------- ----------- --------------- ----- ---------- --------------- ---------- ---------- ---------- --------------- ---------- ---------- ---------- ---------------
              2 5af3m3rc1s2yd        8569 CPU             100%   8313.1097               0          0       4201       2.04               0          0          1       4196      2870574464
              1 5af3m3rc1s2yd        6963 CPU             100%  6771.15374               0          0       3499       1.99               0          0          1       3497      2870574464


Plan hash value: 2870574464
----------------------------------------------------------------------------------------------
| Id  | Operation          | Name       | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   |
----------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT   |            |      1 |        |   576 (100)|      1 |00:00:01.95 |
|   1 |  SORT GROUP BY     |            |      1 |      1 |            |      1 |00:00:01.95 |
|*  2 |   FIXED TABLE FULL | X$KSUSESTA |      1 |      1 |   576 (100)|      2 |00:00:01.95 |
|   3 |    FIXED TABLE FULL| X$KSUSGIF  |      1 |      1 |     0   (0)|      1 |00:00:00.01 |
----------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   2 - filter((INTERNAL_FUNCTION("KSUSESTN") AND BITAND("KSSPAFLG",1)<>0 AND
              BITAND("KSUSEFLG",1)<>0 AND "KSUSENUM"=TO_NUMBER(SYS_CONTEXT('USERENV','SID')) AND
              "INST_ID"=USERENV('INSTANCE') AND "KSUSESTN"<))

*/
/********************************OLD Metrics***************************************/

/********************************New SQL*******************************************/

SELECT LISTAGG( ROUND( SS.VALUE/1024/1024, 2 ), ' | ' ) WITHIN GROUP (ORDER BY SS.STATISTIC#) || ' MB'
  FROM v$mystat ss
 WHERE SS.STATISTIC# IN ( 39, 40 ) ;
/********************************New SQL*******************************************/
/********************************New Metrics***************************************/
/*
Plan hash value: 3297706896
----------------------------------------------------------------------------------------------
| Id  | Operation          | Name       | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   |
----------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT   |            |      1 |        |     1 (100)|      1 |00:00:00.01 |
|   1 |  SORT GROUP BY     |            |      1 |      1 |            |      1 |00:00:00.01 |
|*  2 |   FIXED TABLE FULL | X$KSUMYSTA |      1 |      1 |     0   (0)|      2 |00:00:00.01 |
|   3 |    FIXED TABLE FULL| X$KSUSGIF  |      1 |      1 |     0   (0)|      1 |00:00:00.01 |
----------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   2 - filter((INTERNAL_FUNCTION("KSUSESTN") AND "INST_ID"=USERENV('INSTANCE') AND
              BITAND("KSSPAFLG",1)<>0 AND BITAND("KSUSEFLG",1)<>0 AND "KSUSESTN"<))
*/
/********************************New Metrics***************************************/

/********************************Index statistics**********************************/

/********************************Other SQLs****************************************/          
/*

*/ 
/********************************Other SQLs****************************************/              
