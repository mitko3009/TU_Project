/********************************************************************************
*********       E-mail subject: EFEURDEV-6397
*********             Instance: PROD
*********          Description: 
Problem:
Step 2 in the limit processing calls took 2 minutes more than the previous dry run.

Analysis:
We checked the work of the msgq_ProcessLimit for the period between 18:00 on 11/10/2024 and 00:30 on 12/10/2024 on Patch2.
The TOP SQL, which was responsible for 24% of the time is brk8vnzj9gbkg. The execution plan of this query looks OK to us, but we added condition " and rownum = 1 " ( it was confirmed from
Invoicing team that we can add it ), which will save us some time. We can't provide other optimizations on SQL level here, but from what we saw, the MSGQ works in 32 processes, while for Patch2
there are only 18 CPUs, which means that in some moments we overload them and this is the reason why in the OLD Metrics section below, there is event " resmgr:cpu quantum ". To avoid this,
it can be discussed with the client is it possible to increase the CPU number from 18 to lets say 24. We received the complaint on 16/10/2024 and on 17/10/2024, we requested an AWR Report
for the period, which we hoped that will provide us more information, but it was not generated on time and the data in the AWR was lost, so we don't reveived AWR Report.
To avoid situations like this, the retention period of the AWR should be extended from the default 8 days to lets say 30 days on Patch2.


-- Update form 19/02/2025
The optimized verison of the query was again slow on PROD. We found that adding column FG36 to index G_PIECE$GPIHEURE on table G_PIECE significantly improve the performance of the query, 
so our suggestion this time is to add column FG36 to index G_PIECE$GPIHEURE.

Suggestion:
1. Please ask Invoicing team to change SQL brk8vnzj9gbkg as it is shown in the New SQL section below.
2. Please ask DBA to extend the AWR retention period to 30 days on Patch2.
3. Please ask the client to advice it is possible to extend the database parameter CPU_COUNT from 18 to 24 on Patch2.


-- Update form 19/02/2025
Please add column FG36 to index G_PIECE$GPIHEURE on table G_PIECE.

*********               SQL_ID: brk8vnzj9gbkg
*********      Program/Package: 
*********              Request: Dimitare Ivanov
*********               Author: Dimitar Dimitrov
********* Received e-mail date: 16/10/2024
*********      Resolution date: 06/10/2024
*********  Trace old file here: \\epox\specifs\performance\tmp\
*********  Trace new file here:
***********************************************************************************/

/********************************OLD SQL*******************************************/

VAR B1 VARCHAR2(32);
EXEC :B1 := '1301010174';
VAR B2 NUMBER;
EXEC :B2 := 2460595;

select COUNT(*)
  INTO :b0
  FROM g_piece P
 WHERE P.gpiheure = ( SELECT ancrefdoss 
                        FROM g_dossier 
                       WHERE refdoss = :b1 )
   AND P.typpiece = 'REQUEST_LIMITE'
   AND P.dt04 >= :b2
   AND P.gpirole IN ('DC', 'DT')
   AND P.gpityppiece IN ('AP', 'PA', 'CA', 'PCA', 'RF')
   AND EXISTS ( SELECT 'x'
                  FROM g_piecedet R
                 WHERE R.refpiece = P.refpiece
                   AND R.type = 'REQUEST_USER1_DECISION' )
   AND P.FG36 = 'F';
/********************************OLD SQL*******************************************/
/********************************OLD Metrics***************************************/
/*

-- Metrics from 19/02/2025

MODULE                           SQL_ID         PLAN_HASH     SID SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- ------------- ---------- ------- ------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
msgq_ProcessLimit                2vpzp4a9nu6v6 3778305307    1480   64927 ON CPU               2025/02/17 09:00:40  2025/02/17 09:55:08         143                  501 +000000000 00:54:27.950 45%

SESSION_ID SESSION_SERIAL# MODULE                           PROGRAM                                            SQL_ID        TOP_LEVEL_SQL   COUNT(*)
---------- --------------- -------------------------------- -------------------------------------------------- ------------- ------------- ----------
      1480           64927 msgq_ProcessLimit                msg_q24@LP097MID8532 (TNS V1-V3)                   2vpzp4a9nu6v6 2vpzp4a9nu6v6        143

SQL_ID            ELAPSED MAX_WAIT_ON     PC_OF  WAIT_TIME            GETS      READS       ROWS  ELAP/EXEC       GETS/EXEC READS/EXEC  ROWS/EXEC       EXEC PLAN_HASH_VALUE
------------- ----------- --------------- ----- ---------- --------------- ---------- ---------- ---------- --------------- ---------- ---------- ---------- ---------------
2vpzp4a9nu6v6        1112 CPU             100%  857.501827       108018435          4        424       2.62          254161        .01          1        425      3778305307

SQL_ID        SQL_PLAN_HASH_VALUE SQL_PLAN_LINE_ID SQL_PLAN_OPERATION             SQL_PLAN_OPTIONS                   ACTIVE
------------- ------------------- ---------------- ------------------------------ ------------------------------ ----------
2vpzp4a9nu6v6          3778305307                7 TABLE ACCESS                   BY INDEX ROWID BATCHED                139
2vpzp4a9nu6v6          3778305307                8 INDEX                          RANGE SCAN                             11

col gpiheure for a20
select P . gpiheure, count(*)
  from g_piece P
 where P . typpiece = 'REQUEST_LIMITE'
 group by P . gpiheure
 order by count(*) desc
 fetch first 20 rows only;

GPIHEURE COUNT(*)
-------- --------
PL06726    121408 <-- refdoss 2402120037
IT04021    102829
            91284
GB08881     59297
IT07741     40069
GB07261     37711
DE36824     32647
FR05741     32059
DE01662     27517
DE40163     27474
BE02681     23340
FR07821     19589
US00008     18798
LT36702     18796
PL37999     16124
DE00306     16010
NL38157     15370
FR02481     15342
GB02682     14837
FR07783     14490


col gpiheure for a20
select P . gpiheure, count(*)
  from g_piece P 
 where P . typpiece = 'REQUEST_LIMITE'
   and P . FG36 = 'F' 
 group by P . gpiheure
 order by count(*) desc
 fetch first 20 rows only;
 
 
GPIHEURE               COUNT(*)
-------------------- ----------
US07883                     119
CA03743                      12
DE01662                       9
US00008                       7
US00009                       5
US03747                       5
GB04102                       4
BE02681                       4
CA00007                       4
PT00651                       3
DE00011                       3
GB04421                       3
IT07741                       3
DE06730                       3
PT00563                       2
GB00004                       2
GB06501                       2
PT07021                       2
FR00001                       2
                              2 
 


Plan hash value: 3778305307
--------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                               | Name             | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  |
--------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                        |                  |      1 |        |     9 (100)|      1 |00:01:06.09 |     278K|  51995 |
|   1 |  SORT AGGREGATE                         |                  |      1 |      1 |            |      1 |00:01:06.09 |     278K|  51995 |
|*  2 |   COUNT STOPKEY                         |                  |      1 |        |            |      0 |00:01:06.09 |     278K|  51995 |
|   3 |    NESTED LOOPS SEMI                    |                  |      1 |      1 |     9   (0)|      0 |00:01:06.09 |     278K|  51995 |
|   4 |     NESTED LOOPS                        |                  |      1 |      1 |     6   (0)|      0 |00:01:06.09 |     278K|  51995 |
|*  5 |      TABLE ACCESS BY INDEX ROWID        | G_DOSSIER        |      1 |      1 |     3   (0)|      1 |00:00:00.01 |       4 |      0 |
|*  6 |       INDEX UNIQUE SCAN                 | DOS_REFDOSS      |      1 |      1 |     2   (0)|      1 |00:00:00.01 |       3 |      0 |
|*  7 |      TABLE ACCESS BY INDEX ROWID BATCHED| G_PIECE          |      1 |      1 |     3   (0)|      0 |00:01:06.09 |     278K|  51995 |
|*  8 |       INDEX RANGE SCAN                  | G_PIECE$GPIHEURE |      1 |      1 |     2   (0)|    108K|00:00:01.83 |     560 |    559 |
|*  9 |     INDEX RANGE SCAN                    | G_PIECEDET_REFP  |      0 |    775K|     3   (0)|      0 |00:00:00.01 |       0 |      0 |
--------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   2 - filter(ROWNUM=1)
   5 - filter("ANCREFDOSS" IS NOT NULL)
   6 - access("REFDOSS"=:B1)
   7 - filter(("P"."TYPPIECE"='REQUEST_LIMITE' AND "P"."FG36"='F' AND INTERNAL_FUNCTION("P"."GPIROLE") AND
              INTERNAL_FUNCTION("P"."GPITYPPIECE")))
   8 - access("P"."GPIHEURE"="ANCREFDOSS" AND "P"."DT04">=:B2 AND "P"."DT04" IS NOT NULL)
       filter("P"."GPIHEURE" IS NOT NULL)
   9 - access("R"."REFPIECE"="P"."REFPIECE" AND "R"."TYPE"='REQUEST_USER1_DECISION')




MODULE                           PROGRAM                                            CLIENT_ID       SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- -------------------------------------------------- --------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
msgq_ProcessLimit                msg_q13                                                                                                                                2024/10/11 18:18:20  2024/10/12 00:29:26        1665              2943883 +000000000 06:11:06.121 3%
msgq_ProcessLimit                msg_q29                                                                                                                                2024/10/11 18:18:40  2024/10/12 00:27:26        1653              4115506 +000000000 06:08:45.895 3%
msgq_ProcessLimit                msg_q20                                                                                                                                2024/10/11 18:18:40  2024/10/12 00:27:26        1648              3875404 +000000000 06:08:45.895 3%
msgq_ProcessLimit                msg_q02                                                                                                                                2024/10/11 18:18:10  2024/10/12 00:29:16        1632              4114932 +000000000 06:11:06.114 3%
msgq_ProcessLimit                msg_q30                                                                                                                                2024/10/11 18:18:50  2024/10/12 00:28:16        1631              4222396 +000000000 06:09:25.969 3%
msgq_ProcessLimit                msg_q25                                                                                                                                2024/10/11 18:18:30  2024/10/12 00:29:26        1628              4214959 +000000000 06:10:56.110 3%
msgq_ProcessLimit                msg_q23                                                                                                                                2024/10/11 18:18:50  2024/10/12 00:29:26        1624              3688853 +000000000 06:10:36.081 3%
msgq_ProcessLimit                msg_q06                                                                                                                                2024/10/11 18:18:10  2024/10/12 00:29:06        1623              3429276 +000000000 06:10:56.103 3%
msgq_ProcessLimit                msg_q16                                                                                                                                2024/10/11 18:18:20  2024/10/12 00:28:16        1623              3421908 +000000000 06:09:56.009 3%
msgq_ProcessLimit                msg_q07                                                                                                                                2024/10/11 18:18:10  2024/10/12 00:29:06        1620              3808940 +000000000 06:10:56.103 3%
msgq_ProcessLimit                msg_q32                                                                                                                                2024/10/11 18:18:40  2024/10/12 00:27:06        1620              4249477 +000000000 06:08:25.866 3%
msgq_ProcessLimit                msg_q11                                                                                                                                2024/10/11 18:18:20  2024/10/12 00:29:26        1617              3683162 +000000000 06:11:06.121 3%
msgq_ProcessLimit                msg_q14                                                                                                                                2024/10/11 18:18:30  2024/10/12 00:29:26        1616              3974052 +000000000 06:10:56.110 3%
msgq_ProcessLimit                msg_q27                                                                                                                                2024/10/11 18:18:30  2024/10/12 00:27:56        1616              3877194 +000000000 06:09:25.960 3%
msgq_ProcessLimit                msg_q04                                                                                                                                2024/10/11 18:18:10  2024/10/12 00:29:26        1616              4188950 +000000000 06:11:16.128 3%
msgq_ProcessLimit                msg_q15                                                                                                                                2024/10/11 18:18:20  2024/10/12 00:29:16        1615              3410700 +000000000 06:10:56.107 3%
msgq_ProcessLimit                msg_q21                                                                                                                                2024/10/11 18:18:30  2024/10/12 00:29:26        1610              4027567 +000000000 06:10:56.110 3%
msgq_ProcessLimit                msg_q28                                                                                                                                2024/10/11 18:18:40  2024/10/12 00:27:36        1603              3657937 +000000000 06:08:55.913 3%
msgq_ProcessLimit                msg_queue                                                                                                                              2024/10/11 18:18:50  2024/10/12 00:28:06        1603              4124790 +000000000 06:09:15.947 3%
msgq_ProcessLimit                msg_q03                                                                                                                                2024/10/11 18:18:10  2024/10/12 00:29:16        1601              4147352 +000000000 06:11:06.114 3%
msgq_ProcessLimit                msg_q08                                                                                                                                2024/10/11 18:18:30  2024/10/12 00:28:16        1598              4125200 +000000000 06:09:45.998 3%
msgq_ProcessLimit                msg_q26                                                                                                                                2024/10/11 18:18:30  2024/10/12 00:29:26        1598              3902300 +000000000 06:10:56.110 3%
msgq_ProcessLimit                msg_q22                                                                                                                                2024/10/11 18:18:50  2024/10/12 00:29:26        1598              4249159 +000000000 06:10:36.081 3%
msgq_ProcessLimit                msg_q18                                                                                                                                2024/10/11 18:18:30  2024/10/12 00:28:16        1597              3344541 +000000000 06:09:45.998 3%
msgq_ProcessLimit                msg_q19                                                                                                                                2024/10/11 18:18:30  2024/10/12 00:28:06        1597              4160153 +000000000 06:09:35.976 3%
msgq_ProcessLimit                msg_q31                                                                                                                                2024/10/11 18:18:40  2024/10/12 00:28:16        1596              4015401 +000000000 06:09:35.982 3%
msgq_ProcessLimit                msg_q05                                                                                                                                2024/10/11 18:18:10  2024/10/12 00:29:26        1595              4230532 +000000000 06:11:16.128 3%
msgq_ProcessLimit                msg_q09                                                                                                                                2024/10/11 18:18:40  2024/10/12 00:28:16        1592              4093301 +000000000 06:09:35.982 3%
msgq_ProcessLimit                msg_q12                                                                                                                                2024/10/11 18:18:20  2024/10/12 00:27:46        1590              3954471 +000000000 06:09:25.955 3%
msgq_ProcessLimit                msg_q10                                                                                                                                2024/10/11 18:18:20  2024/10/12 00:29:16        1588              4190828 +000000000 06:10:56.107 3%
msgq_ProcessLimit                msg_q24                                                                                                                                2024/10/11 18:18:50  2024/10/12 00:28:06        1586              4143891 +000000000 06:09:15.947 3%
msgq_ProcessLimit                msg_q17                                                                                                                                2024/10/11 18:18:30  2024/10/12 00:29:26        1565              3552435 +000000000 06:10:56.110 3%
 
 

MODULE                           PROGRAM                                            CLIENT_ID       SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- -------------------------------------------------- --------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
msgq_ProcessLimit                                                                                                                                  ON CPU               2024/10/11 18:18:10  2024/10/12 00:29:26       40461              4249271 +000000000 06:11:16.128 58%
PT_MIGR_STATS_CREATE                                                                                                                               ON CPU               2024/10/11 18:00:08  2024/10/12 00:59:59        7785               652883 +000000000 06:59:50.286 11%
msgq_ProcessLimit                                                                                                                                  resmgr:cpu quantum   2024/10/11 22:00:05  2024/10/12 00:28:06        5770              4250724 +000000000 02:28:00.560 8%
msgq                                                                                                                                               ON CPU               2024/10/11 18:18:20  2024/10/12 00:29:26        3565             11893819 +000000000 06:11:06.121 5%
msgq_ProcessLimit                                                                                                                                  cursor: pin S wait o 2024/10/11 18:18:10  2024/10/12 00:26:46        3236                      +000000000 06:08:35.870 5%
msgq                                                                                                                       0                       log file sync        2024/10/11 18:18:30  2024/10/12 00:29:26        2756                      +000000000 06:10:56.110 4%
msgq                                                                                                                                               resmgr:cpu quantum   2024/10/11 22:00:25  2024/10/12 00:28:06        1226              1245420 +000000000 02:27:40.519 2%
PT_MIGR_STATS_CREATE                                                                                                                               resmgr:cpu quantum   2024/10/11 22:09:17  2024/10/12 00:28:06         718                    9 +000000000 02:18:49.170 1%
msgq_ProcessLimit                                                                                                                                  buffer busy waits    2024/10/11 18:22:30  2024/10/12 00:27:46         695              2268655 +000000000 06:05:15.537 1%
msgq_ProcessLimit                                                                                                                                  library cache lock   2024/10/11 19:20:06  2024/10/12 00:25:26         558                      +000000000 05:05:19.624 1%


MODULE                           PROGRAM                                            CLIENT_ID       SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- -------------------------------------------------- --------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
msgq_ProcessLimit                                                                                                                                                       2024/10/11 18:18:10  2024/10/12 00:29:26       51564              4250725 +000000000 06:11:16.128 100%      
      
      
MODULE                           PROGRAM                                            CLIENT_ID       SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- -------------------------------------------------- --------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
msgq_ProcessLimit                                                                                                                                  ON CPU               2024/10/11 18:18:10  2024/10/12 00:29:26       40461              4249271 +000000000 06:11:16.128 78%
msgq_ProcessLimit                                                                                                                                  resmgr:cpu quantum   2024/10/11 22:00:05  2024/10/12 00:28:06        5770              4250724 +000000000 02:28:00.560 11%
msgq_ProcessLimit                                                                                                                                  cursor: pin S wait o 2024/10/11 18:18:10  2024/10/12 00:26:46        3236                      +000000000 06:08:35.870 6%
msgq_ProcessLimit                                                                                                                                  buffer busy waits    2024/10/11 18:22:30  2024/10/12 00:27:46         695              2268655 +000000000 06:05:15.537 1%
msgq_ProcessLimit                                                                                                                                  library cache lock   2024/10/11 19:20:06  2024/10/12 00:25:26         558                      +000000000 05:05:19.624 1%
msgq_ProcessLimit                                                                                                          0                       log file sync        2024/10/11 18:20:40  2024/10/12 00:13:54         407                      +000000000 05:53:13.753 1%
msgq_ProcessLimit                                                                                                                                  library cache: mutex 2024/10/11 18:25:41  2024/10/12 00:19:15          87              1185183 +000000000 05:53:33.909 0%
 
                                                                                                                                                                                                             
                                                                                                                                                                                                                       
MODULE                           PROGRAM                                            CLIENT_ID       SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- -------------------------------------------------- --------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
msgq_ProcessLimit                                                                                   brk8vnzj9gbkg                                                       2024/10/11 18:18:20  2024/10/12 00:14:24       12469               454202 +000000000 05:56:04.062 24%
msgq_ProcessLimit                                                                                                          0                                            2024/10/11 18:19:20  2024/10/12 00:29:06        6685               441140 +000000000 06:09:46.004 13%
msgq_ProcessLimit                                                                                   5zn8trvmr53md                                                       2024/10/11 18:18:40  2024/10/12 00:25:26        1961               230807 +000000000 06:06:45.695 4%
msgq_ProcessLimit                                                                                   cg1y8t92pa5mf                                                       2024/10/11 18:18:30  2024/10/12 00:10:33        1611               163884 +000000000 05:52:03.510 3%
msgq_ProcessLimit                                                                                   fqyncrwacvsd6                                                       2024/10/11 18:19:00  2024/10/11 23:56:41        1225               488371 +000000000 05:37:41.495 2%
msgq_ProcessLimit                                                                                   dh10tr4uuy225  603342543                                            2024/10/11 18:18:30  2024/10/12 00:10:43        1045               476149 +000000000 05:52:13.535 2%
msgq_ProcessLimit                                                                                   b29z6v182s32s                                                       2024/10/11 18:19:00  2024/10/12 00:14:24        1026               720050 +000000000 05:55:24.003 2%
msgq_ProcessLimit                                                                                   g1r6qmb5tm42b                                                       2024/10/11 18:19:30  2024/10/12 00:13:54         776               715827 +000000000 05:54:23.874 2%
msgq_ProcessLimit                                                                                   5p5ds8tcx05vz                                                       2024/10/11 18:19:10  2024/10/12 00:11:04         669               718470 +000000000 05:51:53.512 1%
    

INSTANCE_NUMBER SQL_ID            ELAPSED MAX_WAIT_ON     PC_OF  WAIT_TIME            GETS      READS       ROWS  ELAP/EXEC       GETS/EXEC READS/EXEC  ROWS/EXEC       EXEC PLAN_HASH_VALUE
--------------- ------------- ----------- --------------- ----- ---------- --------------- ---------- ---------- ---------- --------------- ---------- ---------- ---------- ---------------
              1 brk8vnzj9gbkg       50909 CPU             100%  29163.5547      1752942114       1368     166472        .31           10528        .01          1     166505  2646861525
              1 brk8vnzj9gbkg       19010 there are more                                                                                                                      0
                                          than one greate
                                          st values :)
              1 cg1y8t92pa5mf        6898 PLSQL           50%   8708.26407        22730544        410     990597         .1             325        .01      14.17      69909  3655072312
              1 dh10tr4uuy225       10452 CPU             100%  6503.91641       281122265        156     923510        .02             594          0       1.95     473358   603342543
              1 fqyncrwacvsd6        1252 CPU             67%   820.831102        23973001      13325     244161        .02             384        .21       3.91      62461  2693277919

                                            
                                            
SQL_ID        SQL_PLAN_HASH_VALUE SQL_PLAN_LINE_ID SQL_PLAN_OPERATION             SQL_PLAN_OPTIONS                   ACTIVE
------------- ------------------- ---------------- ------------------------------ ------------------------------ ----------
brk8vnzj9gbkg                   0                  SELECT STATEMENT                                                       4
brk8vnzj9gbkg          2646861525                6 TABLE ACCESS                   BY INDEX ROWID BATCHED              11014
brk8vnzj9gbkg          2646861525                7 INDEX                          RANGE SCAN                           1380
brk8vnzj9gbkg          2646861525                  SELECT STATEMENT                                                      42
brk8vnzj9gbkg          2646861525                                                                                        24
brk8vnzj9gbkg          2646861525                1 SORT                           AGGREGATE                               3
brk8vnzj9gbkg          2646861525                4 TABLE ACCESS                   BY INDEX ROWID                          1
brk8vnzj9gbkg          2646861525                2 NESTED LOOPS                   SEMI                                    1     


Plan hash value: 2646861525
-------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                              | Name             | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  |
-------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                       |                  |      1 |        |     9 (100)|      1 |00:00:00.18 |      81 |    144 |
|   1 |  SORT AGGREGATE                        |                  |      1 |      1 |            |      1 |00:00:00.18 |      81 |    144 |
|   2 |   NESTED LOOPS SEMI                    |                  |      1 |      1 |     9   (0)|      0 |00:00:00.18 |      81 |    144 |
|   3 |    NESTED LOOPS                        |                  |      1 |      1 |     6   (0)|      0 |00:00:00.18 |      81 |    144 |
|*  4 |     TABLE ACCESS BY INDEX ROWID        | G_DOSSIER        |      1 |      1 |     3   (0)|      1 |00:00:00.01 |       4 |      0 |
|*  5 |      INDEX UNIQUE SCAN                 | DOS_REFDOSS      |      1 |      1 |     2   (0)|      1 |00:00:00.01 |       3 |      0 |
|*  6 |     TABLE ACCESS BY INDEX ROWID BATCHED| G_PIECE          |      1 |      1 |     3   (0)|      0 |00:00:00.18 |      77 |    144 |
|*  7 |      INDEX RANGE SCAN                  | G_PIECE$GPIHEURE |      1 |      1 |     2   (0)|      0 |00:00:00.18 |      77 |    144 |
|*  8 |    INDEX RANGE SCAN                    | G_PIECEDET_REFP  |      0 |    618K|     3   (0)|      0 |00:00:00.01 |       0 |      0 |
-------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   4 - filter("ANCREFDOSS" IS NOT NULL)
   5 - access("REFDOSS"=:B1)
   6 - filter(("P"."TYPPIECE"='REQUEST_LIMITE' AND "P"."FG36"='F' AND INTERNAL_FUNCTION("P"."GPIROLE") AND
              INTERNAL_FUNCTION("P"."GPITYPPIECE")))
   7 - access("P"."GPIHEURE"="ANCREFDOSS" AND "P"."DT04">=:B2 AND "P"."DT04" IS NOT NULL)
       filter("P"."GPIHEURE" IS NOT NULL)
   8 - access("R"."REFPIECE"="P"."REFPIECE" AND "R"."TYPE"='REQUEST_USER1_DECISION')
*/
/********************************OLD Metrics***************************************/

/********************************New SQL*******************************************/

select COUNT(*)
  INTO :b0
  FROM g_piece P
 WHERE P.gpiheure = ( SELECT ancrefdoss 
                        FROM g_dossier 
                       WHERE refdoss = :b1 )
   AND P.typpiece = 'REQUEST_LIMITE'
   AND P.dt04 >= :b2
   AND P.gpirole IN ('DC', 'DT')
   AND P.gpityppiece IN ('AP', 'PA', 'CA', 'PCA', 'RF')
   AND EXISTS ( SELECT 'x'
                  FROM g_piecedet R
                 WHERE R.refpiece = P.refpiece
                   AND R.type = 'REQUEST_USER1_DECISION' )
   AND P.FG36 = 'F'
   AND ROWNUM = 1;
/********************************New SQL*******************************************/
/********************************New Metrics***************************************/
/*
Plan hash value: 3778305307
-----------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                               | Name             | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers |
-----------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                        |                  |      1 |        |     9 (100)|      1 |00:00:00.01 |       3 |
|   1 |  SORT AGGREGATE                         |                  |      1 |      1 |            |      1 |00:00:00.01 |       3 |
|*  2 |   COUNT STOPKEY                         |                  |      1 |        |            |      0 |00:00:00.01 |       3 |
|   3 |    NESTED LOOPS SEMI                    |                  |      1 |      1 |     9   (0)|      0 |00:00:00.01 |       3 |
|   4 |     NESTED LOOPS                        |                  |      1 |      1 |     6   (0)|      0 |00:00:00.01 |       3 |
|*  5 |      TABLE ACCESS BY INDEX ROWID        | G_DOSSIER        |      1 |      1 |     3   (0)|      0 |00:00:00.01 |       3 |
|*  6 |       INDEX UNIQUE SCAN                 | DOS_REFDOSS      |      1 |      1 |     2   (0)|      0 |00:00:00.01 |       3 |
|*  7 |      TABLE ACCESS BY INDEX ROWID BATCHED| G_PIECE          |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*  8 |       INDEX RANGE SCAN                  | G_PIECE$GPIHEURE |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |
|*  9 |     INDEX RANGE SCAN                    | G_PIECEDET_REFP  |      0 |    650K|     3   (0)|      0 |00:00:00.01 |       0 |
-----------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   2 - filter(ROWNUM=1)
   5 - filter("ANCREFDOSS" IS NOT NULL)
   6 - access("REFDOSS"=:B1)
   7 - filter(("P"."TYPPIECE"='REQUEST_LIMITE' AND "P"."FG36"='F' AND INTERNAL_FUNCTION("P"."GPIROLE") AND
              INTERNAL_FUNCTION("P"."GPITYPPIECE")))
   8 - access("P"."GPIHEURE"="ANCREFDOSS" AND "P"."DT04">=:B2 AND "P"."DT04" IS NOT NULL)
       filter("P"."GPIHEURE" IS NOT NULL)
   9 - access("R"."REFPIECE"="P"."REFPIECE" AND "R"."TYPE"='REQUEST_USER1_DECISION')
*/
/********************************New Metrics***************************************/

/********************************Index statistics**********************************/

/********************************Other SQLs****************************************/          
/*

*/ 
/********************************Other SQLs****************************************/              
