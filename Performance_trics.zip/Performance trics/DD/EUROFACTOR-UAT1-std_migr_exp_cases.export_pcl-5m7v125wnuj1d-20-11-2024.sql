/********************************************************************************
*********       E-mail subject: EFAGDEV-3566
*********             Instance: UAT1
*********          Description: 
Problem:
We were requested to check the performance of the std_migr_exp_cases.export_pcl on UAT1.

Analysis:
The two SQLs that were responsible for the time of the std_migr_exp_cases.export_pcl based on the information in the IPT were 5m7v125wnuj1d and 4g0s28621nhad.
Their full texts were not stored in the IPT, but it was provided from Spasiyan Todorov in the task.
The problem in both of them is similar - they were executed with bad execution plan, which instead of start from the migr tables, it start with INDEX FULL SCAN of index G_PIECEDET_LIB2_3 
on table G_PIECEDET. To force Oracle to start from the std_migr_dos table, we added hints to the queries.

Suggestion:
Please add hints as it is shown in the New SQL section below.

*********               SQL_ID: 5m7v125wnuj1d, 4g0s28621nhad
*********      Program/Package: 
*********              Request: Spasiyan Todorov
*********               Author: Dimitar Dimitrov
********* Received e-mail date: 19/11/2024
*********      Resolution date: 20/11/2024
*********  Trace old file here: \\epox\specifs\performance\tmp\
*********  Trace new file here:
***********************************************************************************/

/********************************OLD SQL*******************************************/

-- 5m7v125wnuj1d

SELECT paym.STR1            
     , paym.TX01            
     , paym.LIB2            
     , paym.refpiece
  FROM g_piecedet      paym,
       g_piece         pi,
       std_migr_dos    dos,
       std_migr_cba    cba,
       g_domiciliation dom
 WHERE paym.type     = 'PARAM_PM'
   AND paym.refpiece = pi.refpiece
   AND pi.refdoss    = dos.prc_refdoss
   AND pi.typpiece   IN ('CONTRAT', 'CONTRAT REV')
   AND paym.LIB2     = cba.refextind
   AND NVL(paym.str3,'X')      = NVL(dom.nocompte,'X')
   AND dom.imx_un_id = cba.refcba
   and paym.str6     = dom.imx_un_id
   AND ( paym.STR1       IS NULL
      OR paym.TX01       IS NULL
      OR paym.LIB2       IS NULL )
 UNION
 SELECT paym.STR1            
     , paym.TX01            
     , paym.LIB2            
     , paym.refpiece            
  FROM g_piecedet      paym,
       g_piece         pi,
       std_migr_dos    dos,
       std_migr_bba    bba,
       g_cptbq         dom,
       t_individu      co_fact
 WHERE paym.type     = 'PARAM_PM'
   AND paym.refpiece = pi.refpiece
   AND pi.refdoss    = dos.prc_refdoss
   AND pi.typpiece   IN ('CONTRAT', 'CONTRAT REV')
   AND dos.categdoss LIKE 'CONTRAT IMP%'
   AND co_fact.refext  = bba.refbu
   AND paym.lib2       = co_fact.refindividu
   AND co_fact.societe = 'FCI_FACTOR'
   AND NVL(paym.str3,'X')      = NVL(dom.numcpt,'X')
   AND dom.refcptbq  = bba.refext
   and paym.str7     = dom.refcptbq
   AND (paym.STR1       IS NULL
     OR paym.TX01       IS NULL
     OR paym.LIB2       IS NULL );


-- 4g0s28621nhad

INSERT INTO std_migr_pcl
      (
        CONTRACT_NO         
      , PAYMENT_MODE        
      , COUNTRY             
      , PAYMENT_PCT         
      , START_DATE          
      , END_DATE            
      , REFEXT_BENEF        
      , REFCBA              
      , URGENT              
      )  
SELECT dos.contract_no      
             , paym.STR1    
             , paym.STR4    
             , paym.TX01    
             , NVL(paym.DT03_DT, SYSDATE)
                                    
             , paym.DT01_DT         
             , paym.LIB2            
             , cba.REFCBA           
             , paym.FG04            
          FROM g_piecedet      paym,
               g_piece         pi,
               std_migr_dos    dos,
               std_migr_cba    cba,
               g_domiciliation dom
         WHERE paym.type     = 'PARAM_PM'
           AND paym.refpiece = pi.refpiece
           AND pi.refdoss    = dos.prc_refdoss
           AND pi.typpiece   IN ('CONTRAT', 'CONTRAT REV')
           AND paym.LIB2     = cba.refextind
           AND NVL(paym.str3,'X')      = NVL(dom.nocompte,'X')
           AND dom.imx_un_id = cba.refcba
           and paym.str6     = dom.imx_un_id
           AND paym.STR1       IS NOT NULL
           AND paym.TX01       IS NOT NULL
           AND paym.LIB2       IS NOT NULL
        UNION
        SELECT dos.contract_no      
             , paym.STR1            
             , paym.STR4            
             , paym.TX01            
             , NVL(paym.DT03_DT, SYSDATE)
                                    
             , paym.DT01_DT         
             , paym.LIB2            
             , bba.refext           
             , paym.FG04            
          FROM g_piecedet      paym,
               g_piece         pi,
               std_migr_dos    dos,
               std_migr_bba    bba,
               g_cptbq         dom,
               t_individu      co_fact
         WHERE paym.type     = 'PARAM_PM'
           AND paym.refpiece = pi.refpiece
           AND pi.refdoss    = dos.prc_refdoss
           AND pi.typpiece   IN ('CONTRAT', 'CONTRAT REV')
           AND dos.categdoss LIKE 'CONTRAT IMP%'
           AND co_fact.refext  = bba.refbu
           AND paym.lib2       = co_fact.refindividu
           AND co_fact.societe = 'FCI_FACTOR'
           AND NVL(paym.str3,'X')      = NVL(dom.numcpt,'X')
           AND dom.refcptbq  = bba.refext
           and paym.str7     = dom.refcptbq
           AND paym.STR1       IS NOT NULL
           AND paym.TX01       IS NOT NULL
           AND paym.LIB2       IS NOT NULL;
/********************************OLD SQL*******************************************/
/********************************OLD Metrics***************************************/
/*
MODULE                    SQL_ID         PLAN_HASH SID    SERIAL# EVENT                          FROM                           TO                                 ACTIVE NUMBER_OF_EXECUTIONS PERC
------------------------- ------------- ---------- ------ ------- ------------------------------ ------------------------------ ------------------------------ ---------- -------------------- ------
DCL_PURGE                                          1302   32105   ON CPU                         2024/11/07 17:00:16            2024/11/07 17:38:49                  1070                    4 12%
DCL_PURGE                                          1302   32105   db file scattered read         2024/11/07 17:00:06            2024/11/07 17:39:59                  1010                    4 11%
std_migr_exp_cases.export                          868    61417   db file sequential read        2024/11/07 17:10:06            2024/11/07 17:35:39                   970                    1 10%
std_migr_exp_cases.export                          916    21278   db file sequential read        2024/11/07 17:14:07            2024/11/07 17:30:28                   880                    1 9%
std_migr_exp_cases.export 5qxg0z82q52rc  880316280 442    29011   db file sequential read        2024/11/07 17:30:48            2024/11/07 17:39:59                   490                    1 5%
std_migr_exp_cases.export                          1062   6805    db file sequential read        2024/11/07 17:00:06            2024/11/07 17:09:36                   470                    1 5%
std_migr_exp_cases.export                          868    61417   ON CPU                         2024/11/07 17:11:56            2024/11/07 17:32:18                   380                    1 4%
DCL_PURGE                                          1302   32105   db file sequential read        2024/11/07 17:02:36            2024/11/07 17:38:59                   320                    3 3%
std_migr_exp_cases.export                          726    6068    ON CPU                         2024/11/07 17:14:07            2024/11/07 17:20:18                   240                    1 3%
std_migr_exp_cases.export                          537    22743   db file sequential read        2024/11/07 17:14:07            2024/11/07 17:19:07                   240                    1 3%



MODULE                              SQL_ID         PLAN_HASH SID    SERIAL# EVENT                          FROM                           TO                                 ACTIVE NUMBER_OF_EXECUTIONS PERC
----------------------------------- ------------- ---------- ------ ------- ------------------------------ ------------------------------ ------------------------------ ---------- -------------------- ------
std_migr_exp_cases.export_pcl                                868    61417                                  2024/11/07 17:10:06            2024/11/07 17:35:39                  1540                    1 100%


MODULE                              SQL_ID         PLAN_HASH SID    SERIAL# EVENT                          FROM                           TO                                 ACTIVE NUMBER_OF_EXECUTIONS PERC
----------------------------------- ------------- ---------- ------ ------- ------------------------------ ------------------------------ ------------------------------ ---------- -------------------- ------
std_migr_exp_cases.export_pcl                                868    61417   db file sequential read        2024/11/07 17:10:06            2024/11/07 17:35:39                   970                    1 63%
std_migr_exp_cases.export_pcl                                868    61417   ON CPU                         2024/11/07 17:11:56            2024/11/07 17:32:18                   380                    1 25%
std_migr_exp_cases.export_pcl                                868    61417   db file parallel read          2024/11/07 17:11:26            2024/11/07 17:22:58                   180                    1 12%
std_migr_exp_cases.export_pcl       5m7v125wnuj1d 1629406541 868    61417   db file scattered read         2024/11/07 17:23:08            2024/11/07 17:23:08                    10                    1 1%


MODULE                              SQL_ID         PLAN_HASH SID    SERIAL# EVENT                          FROM                           TO                                 ACTIVE NUMBER_OF_EXECUTIONS PERC
----------------------------------- ------------- ---------- ------ ------- ------------------------------ ------------------------------ ------------------------------ ---------- -------------------- ------
std_migr_exp_cases.export_pcl       5m7v125wnuj1d 1629406541 868    61417                                  2024/11/07 17:21:28            2024/11/07 17:35:39                   860                    1 56%
std_migr_exp_cases.export_pcl       4g0s28621nhad 3536305744 868    61417                                  2024/11/07 17:10:06            2024/11/07 17:21:18                   680                    1 44%


-- 5m7v125wnuj1d

Plan hash value: 1629406541
------------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                  | Name              | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  |
------------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                           |                   |      1 |        |   552 (100)|      0 |00:00:00.01 |       0 |      0 |
|   1 |  SORT UNIQUE                               |                   |      1 |      2 |   552   (1)|      0 |00:00:00.01 |       0 |      0 |
|   2 |   UNION-ALL                                |                   |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
|   3 |    NESTED LOOPS SEMI                       |                   |      1 |      1 |   308   (1)|      0 |00:02:03.19 |    1131K|    770K|
|   4 |     MERGE JOIN CARTESIAN                   |                   |      1 |     20 |   307   (1)|    141K|00:02:02.85 |    1116K|    770K|
|*  5 |      HASH JOIN                             |                   |      1 |      1 |   197   (0)|     31 |00:02:02.75 |    1111K|    770K|
|*  6 |       TABLE ACCESS BY INDEX ROWID BATCHED  | G_PIECEDET        |      1 |  11190 |   113   (0)|    990 |00:02:01.15 |    1097K|    767K|
|*  7 |        INDEX FULL SCAN                     | G_PIECEDET_LIB2_3 |      1 |   4157 |    93   (0)|   2238K|00:00:08.99 |    8977 |   8977 |
|   8 |       NESTED LOOPS                         |                   |      1 |   6337 |    83   (0)|   6757 |00:00:01.59 |   13609 |   2104 |
|   9 |        NESTED LOOPS                        |                   |      1 |   6337 |    83   (0)|   6757 |00:00:00.23 |    6851 |    319 |
|  10 |         TABLE ACCESS FULL                  | STD_MIGR_CBA      |      1 |   6337 |    20   (0)|   6757 |00:00:00.03 |     107 |    103 |
|* 11 |         INDEX UNIQUE SCAN                  | PK_G_DOMICIL      |   6757 |      1 |     1   (0)|   6757 |00:00:00.20 |    6744 |    216 |
|  12 |        TABLE ACCESS BY INDEX ROWID         | G_DOMICILIATION   |   6757 |      1 |     1   (0)|   6757 |00:00:01.35 |    6758 |   1785 |
|  13 |      BUFFER SORT                           |                   |     31 |   4374 |   193   (1)|    141K|00:00:00.08 |    5112 |    533 |
|  14 |       TABLE ACCESS FULL                    | STD_MIGR_DOS      |      1 |   4374 |   110   (1)|   4575 |00:00:00.04 |    5112 |    533 |
|* 15 |     TABLE ACCESS BY INDEX ROWID BATCHED    | G_PIECE           |    141K|   5535K|     1   (0)|      0 |00:00:00.29 |   15331 |     39 |
|* 16 |      INDEX RANGE SCAN                      | PIE_REFPIECE      |    141K|      1 |     1   (0)|    141K|00:00:00.17 |   15302 |     15 |
|* 17 |    HASH JOIN SEMI                          |                   |      1 |      1 |   244   (1)|      0 |00:00:00.01 |       0 |      0 |
|  18 |     NESTED LOOPS                           |                   |      1 |      1 |   240   (1)|      0 |00:00:00.01 |       0 |      0 |
|* 19 |      HASH JOIN SEMI                        |                   |      1 |      1 |   239   (1)|      0 |00:00:00.01 |       0 |      0 |
|  20 |       NESTED LOOPS                         |                   |      1 |      5 |   128   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 21 |        HASH JOIN                           |                   |      1 |      5 |   127   (0)|      0 |00:00:00.01 |       0 |      0 |
|  22 |         TABLE ACCESS FULL                  | G_CPTBQ           |      1 |   2184 |    14   (0)|   2184 |00:00:00.01 |      67 |     66 |
|* 23 |         TABLE ACCESS BY INDEX ROWID BATCHED| G_PIECEDET        |      1 |  11190 |   113   (0)|    990 |00:01:59.89 |     194K|    134K|
|* 24 |          INDEX FULL SCAN                   | G_PIECEDET_LIB2_3 |      1 |   4157 |    93   (0)|    479K|00:00:02.77 |    2567 |   2566 |
|* 25 |        TABLE ACCESS BY INDEX ROWID BATCHED | G_PIECE           |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 26 |         INDEX RANGE SCAN                   | PIE_REFPIECE      |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 27 |       TABLE ACCESS FULL                    | STD_MIGR_DOS      |      0 |   3880 |   110   (1)|      0 |00:00:00.01 |       0 |      0 |
|* 28 |      TABLE ACCESS BY INDEX ROWID BATCHED   | T_INDIVIDU        |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 29 |       INDEX RANGE SCAN                     | IX_T_INDIVIDU     |      0 |      4 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|  30 |     TABLE ACCESS FULL                      | STD_MIGR_BBA      |      0 |    843 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
------------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   5 - access("PAYM"."LIB2"="CBA"."REFEXTIND" AND NVL("PAYM"."STR3",'X')=NVL("DOM"."NOCOMPTE",'X') AND
              "DOM"."IMX_UN_ID"=TO_NUMBER("PAYM"."STR6"))
   6 - filter(("PAYM"."TYPE"='PARAM_PM' AND ("PAYM"."LIB2" IS NULL OR "PAYM"."TX01" IS NULL OR "PAYM"."STR1" IS NULL)))
   7 - filter("PAYM"."LIB2" IS NOT NULL)
  11 - access("DOM"."IMX_UN_ID"=TO_NUMBER("CBA"."REFCBA"))
  15 - filter(("PI"."REFDOSS"="DOS"."PRC_REFDOSS" AND "PI"."REFDOSS" IS NOT NULL AND INTERNAL_FUNCTION("PI"."TYPPIECE")))
  16 - access("PAYM"."REFPIECE"="PI"."REFPIECE")
  17 - access("CO_FACT"."REFEXT"="BBA"."REFBU" AND "DOM"."REFCPTBQ"=TO_NUMBER("BBA"."REFEXT"))
  19 - access("PI"."REFDOSS"="DOS"."PRC_REFDOSS")
  21 - access(NVL("PAYM"."STR3",'X')=NVL("DOM"."NUMCPT",'X') AND "DOM"."REFCPTBQ"=TO_NUMBER("PAYM"."STR7"))
  23 - filter(("PAYM"."TYPE"='PARAM_PM' AND ("PAYM"."LIB2" IS NULL OR "PAYM"."TX01" IS NULL OR "PAYM"."STR1" IS NULL)))
  24 - filter("PAYM"."LIB2" IS NOT NULL)
  25 - filter(("PI"."REFDOSS" IS NOT NULL AND INTERNAL_FUNCTION("PI"."TYPPIECE")))
  26 - access("PAYM"."REFPIECE"="PI"."REFPIECE")
  27 - filter("DOS"."CATEGDOSS" LIKE 'CONTRAT IMP%')
  28 - filter("CO_FACT"."SOCIETE"='FCI_FACTOR')
  29 - access("PAYM"."LIB2"="CO_FACT"."REFINDIVIDU")


-- 4g0s28621nhad

Plan hash value: 3536305744
---------------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                     | Name              | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  |
---------------------------------------------------------------------------------------------------------------------------------------------------
|   0 | INSERT STATEMENT                              |                   |      1 |        |   487 (100)|      0 |00:00:00.01 |       0 |      0 |
|   1 |  LOAD TABLE CONVENTIONAL                      | STD_MIGR_PCL      |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
|   2 |   SORT UNIQUE                                 |                   |      1 |      2 |   487   (1)|      0 |00:00:00.01 |       0 |      0 |
|   3 |    UNION-ALL                                  |                   |      1 |        |            |    254 |00:04:41.78 |    4106K|    572K|
|   4 |     NESTED LOOPS SEMI                         |                   |      1 |      1 |   247   (1)|    254 |00:04:41.78 |    4106K|    572K|
|   5 |      MERGE JOIN CARTESIAN                     |                   |      1 |      1 |   246   (1)|     86M|00:01:52.91 |    1235K|    555K|
|*  6 |       HASH JOIN                               |                   |      1 |      1 |   136   (0)|  18996 |00:01:22.03 |    1230K|    555K|
|   7 |        NESTED LOOPS                           |                   |      1 |      8 |   116   (0)|    109K|00:01:21.70 |    1230K|    555K|
|   8 |         NESTED LOOPS                          |                   |      1 |    248 |   116   (0)|    115K|00:01:21.47 |    1115K|    555K|
|*  9 |          TABLE ACCESS BY INDEX ROWID BATCHED  | G_PIECEDET        |      1 |    248 |   113   (0)|    144K|00:01:21.29 |    1100K|    555K|
|* 10 |           INDEX FULL SCAN                     | G_PIECEDET_LIB2_3 |      1 |   4157 |    93   (0)|   2238K|00:00:06.06 |    8977 |   6410 |
|* 11 |          INDEX UNIQUE SCAN                    | PK_G_DOMICIL      |    144K|      1 |     1   (0)|    115K|00:00:00.13 |   15032 |      0 |
|* 12 |         TABLE ACCESS BY INDEX ROWID           | G_DOMICILIATION   |    115K|      1 |     1   (0)|    109K|00:00:00.19 |     115K|     50 |
|  13 |        TABLE ACCESS FULL                      | STD_MIGR_CBA      |      1 |   6337 |    20   (0)|   2535 |00:00:00.02 |      40 |     43 |
|  14 |       BUFFER SORT                             |                   |  18996 |   4374 |   226   (1)|     86M|00:00:21.14 |    5112 |    532 |
|  15 |        TABLE ACCESS FULL                      | STD_MIGR_DOS      |      1 |   4374 |   110   (1)|   4575 |00:00:00.04 |    5112 |    532 |
|* 16 |      TABLE ACCESS BY INDEX ROWID BATCHED      | G_PIECE           |     86M|   5535K|     1   (0)|    254 |00:02:24.48 |    2877K|  16763 |
|* 17 |       INDEX RANGE SCAN                        | PIE_REFPIECE      |     86M|      1 |     1   (0)|     86M|00:01:25.58 |    2852K|   7075 |
|  18 |     NESTED LOOPS SEMI                         |                   |      0 |      1 |   240   (1)|      0 |00:00:00.01 |       0 |      0 |
|* 19 |      HASH JOIN                                |                   |      0 |      1 |   239   (1)|      0 |00:00:00.01 |       0 |      0 |
|  20 |       NESTED LOOPS                            |                   |      0 |      1 |   235   (1)|      0 |00:00:00.01 |       0 |      0 |
|  21 |        NESTED LOOPS                           |                   |      0 |      4 |   235   (1)|      0 |00:00:00.01 |       0 |      0 |
|* 22 |         HASH JOIN                             |                   |      0 |      1 |   234   (1)|      0 |00:00:00.01 |       0 |      0 |
|  23 |          NESTED LOOPS                         |                   |      0 |    248 |   123   (0)|      0 |00:00:00.01 |       0 |      0 |
|  24 |           NESTED LOOPS                        |                   |      0 |    248 |   123   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 25 |            TABLE ACCESS BY INDEX ROWID BATCHED| G_PIECEDET        |      0 |    248 |   113   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 26 |             INDEX FULL SCAN                   | G_PIECEDET_LIB2_3 |      0 |   4157 |    93   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 27 |            INDEX RANGE SCAN                   | PIE_REFPIECE      |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 28 |           TABLE ACCESS BY INDEX ROWID         | G_PIECE           |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 29 |          TABLE ACCESS FULL                    | STD_MIGR_DOS      |      0 |   3880 |   110   (1)|      0 |00:00:00.01 |       0 |      0 |
|* 30 |         INDEX RANGE SCAN                      | IX_T_INDIVIDU     |      0 |      4 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 31 |        TABLE ACCESS BY INDEX ROWID            | T_INDIVIDU        |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|  32 |       TABLE ACCESS FULL                       | STD_MIGR_BBA      |      0 |    843 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 33 |      TABLE ACCESS BY INDEX ROWID              | G_CPTBQ           |      0 |    541 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 34 |       INDEX UNIQUE SCAN                       | PK_CPTBQ_REFCPTBQ |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
---------------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   6 - access("PAYM"."LIB2"="CBA"."REFEXTIND" AND "DOM"."IMX_UN_ID"=TO_NUMBER("CBA"."REFCBA"))
   9 - filter(("PAYM"."TX01" IS NOT NULL AND "PAYM"."TYPE"='PARAM_PM' AND "PAYM"."STR1" IS NOT NULL))
  10 - filter("PAYM"."LIB2" IS NOT NULL)
  11 - access("DOM"."IMX_UN_ID"=TO_NUMBER("PAYM"."STR6"))
  12 - filter(NVL("PAYM"."STR3",'X')=NVL("DOM"."NOCOMPTE",'X'))
  16 - filter(("PI"."REFDOSS"="DOS"."PRC_REFDOSS" AND "PI"."REFDOSS" IS NOT NULL AND INTERNAL_FUNCTION("PI"."TYPPIECE")))
  17 - access("PAYM"."REFPIECE"="PI"."REFPIECE")
  19 - access("CO_FACT"."REFEXT"="BBA"."REFBU")
  22 - access("PI"."REFDOSS"="DOS"."PRC_REFDOSS")
  25 - filter(("PAYM"."TX01" IS NOT NULL AND "PAYM"."TYPE"='PARAM_PM' AND "PAYM"."STR1" IS NOT NULL))
  26 - filter("PAYM"."LIB2" IS NOT NULL)
  27 - access("PAYM"."REFPIECE"="PI"."REFPIECE")
  28 - filter(("PI"."REFDOSS" IS NOT NULL AND INTERNAL_FUNCTION("PI"."TYPPIECE")))
  29 - filter("DOS"."CATEGDOSS" LIKE 'CONTRAT IMP%')
  30 - access("PAYM"."LIB2"="CO_FACT"."REFINDIVIDU")
  31 - filter("CO_FACT"."SOCIETE"='FCI_FACTOR')
  33 - filter(NVL("PAYM"."STR3",'X')=NVL("DOM"."NUMCPT",'X'))
  34 - access("DOM"."REFCPTBQ"=TO_NUMBER("PAYM"."STR7"))
       filter("DOM"."REFCPTBQ"=TO_NUMBER("BBA"."REFEXT"))


*/
/********************************OLD Metrics***************************************/

/********************************New SQL*******************************************/

-- 5m7v125wnuj1d

SELECT /*+ leading(dos) cardinality(dos 5) opt_param('_OPTIMIZER_USE_FEEDBACK','FALSE') */
       paym.STR1            
     , paym.TX01            
     , paym.LIB2            
     , paym.refpiece
  FROM g_piecedet      paym,
       g_piece         pi,
       std_migr_dos    dos,
       std_migr_cba    cba,
       g_domiciliation dom
 WHERE paym.type     = 'PARAM_PM'
   AND paym.refpiece = pi.refpiece
   AND pi.refdoss    = dos.prc_refdoss
   AND pi.typpiece   IN ('CONTRAT', 'CONTRAT REV')
   AND paym.LIB2     = cba.refextind
   AND NVL(paym.str3,'X') = NVL(dom.nocompte,'X')
   AND dom.imx_un_id = cba.refcba
   and paym.str6     = dom.imx_un_id
   AND ( paym.STR1       IS NULL
      OR paym.TX01       IS NULL
      OR paym.LIB2       IS NULL )
 UNION
 SELECT /*+ leading(dos pi paym dom bba) cardinality(dos 5) use_hash(bba)*/
       paym.STR1            
     , paym.TX01            
     , paym.LIB2            
     , paym.refpiece            
  FROM g_piecedet      paym,
       g_piece         pi,
       std_migr_dos    dos,
       std_migr_bba    bba,
       g_cptbq         dom,
       t_individu      co_fact
 WHERE paym.type     = 'PARAM_PM'
   AND paym.refpiece = pi.refpiece
   AND pi.refdoss    = dos.prc_refdoss
   AND pi.typpiece   IN ('CONTRAT', 'CONTRAT REV')
   AND dos.categdoss LIKE 'CONTRAT IMP%'
   AND co_fact.refext  = bba.refbu
   AND paym.lib2       = co_fact.refindividu
   AND co_fact.societe = 'FCI_FACTOR'
   AND NVL(paym.str3,'X') = NVL(dom.numcpt,'X')
   AND dom.refcptbq  = bba.refext
   and paym.str7     = dom.refcptbq
   AND (paym.STR1       IS NULL
     OR paym.TX01       IS NULL
     OR paym.LIB2       IS NULL );


-- 4g0s28621nhad

INSERT INTO std_migr_pcl
      (
        CONTRACT_NO         
      , PAYMENT_MODE        
      , COUNTRY             
      , PAYMENT_PCT         
      , START_DATE          
      , END_DATE            
      , REFEXT_BENEF        
      , REFCBA              
      , URGENT              
      )  
SELECT /*+ leading(dos) cardinality(dos 5) opt_param('_OPTIMIZER_USE_FEEDBACK','FALSE') */
       dos.contract_no      
             , paym.STR1    
             , paym.STR4    
             , paym.TX01    
             , NVL(paym.DT03_DT, SYSDATE)
                                    
             , paym.DT01_DT         
             , paym.LIB2            
             , cba.REFCBA           
             , paym.FG04            
          FROM g_piecedet      paym,
               g_piece         pi,
               std_migr_dos    dos,
               std_migr_cba    cba,
               g_domiciliation dom
         WHERE paym.type     = 'PARAM_PM'
           AND paym.refpiece = pi.refpiece
           AND pi.refdoss    = dos.prc_refdoss
           AND pi.typpiece   IN ('CONTRAT', 'CONTRAT REV')
           AND paym.LIB2     = cba.refextind
           AND NVL(paym.str3,'X')      = NVL(dom.nocompte,'X')
           AND dom.imx_un_id = cba.refcba
           and paym.str6     = dom.imx_un_id
           AND paym.STR1       IS NOT NULL
           AND paym.TX01       IS NOT NULL
           AND paym.LIB2       IS NOT NULL
        UNION
        SELECT /*+ leading(dos pi paym dom bba) cardinality(dos 5) use_hash(bba)*/
               dos.contract_no      
             , paym.STR1            
             , paym.STR4            
             , paym.TX01            
             , NVL(paym.DT03_DT, SYSDATE)
                                    
             , paym.DT01_DT         
             , paym.LIB2            
             , bba.refext           
             , paym.FG04            
          FROM g_piecedet      paym,
               g_piece         pi,
               std_migr_dos    dos,
               std_migr_bba    bba,
               g_cptbq         dom,
               t_individu      co_fact
         WHERE paym.type     = 'PARAM_PM'
           AND paym.refpiece = pi.refpiece
           AND pi.refdoss    = dos.prc_refdoss
           AND pi.typpiece   IN ('CONTRAT', 'CONTRAT REV')
           AND dos.categdoss LIKE 'CONTRAT IMP%'
           AND co_fact.refext  = bba.refbu
           AND paym.lib2       = co_fact.refindividu
           AND co_fact.societe = 'FCI_FACTOR'
           AND NVL(paym.str3,'X')      = NVL(dom.numcpt,'X')
           AND dom.refcptbq  = bba.refext
           and paym.str7     = dom.refcptbq
           AND paym.STR1       IS NOT NULL
           AND paym.TX01       IS NOT NULL
           AND paym.LIB2       IS NOT NULL;
/********************************New SQL*******************************************/
/********************************New Metrics***************************************/
/*
-- 5m7v125wnuj1d

Plan hash value: 1789681670
------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                     | Name              | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers |
------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                              |                   |      1 |        |   259 (100)|      0 |00:00:00.30 |     108K|
|   1 |  SORT UNIQUE                                  |                   |      1 |      2 |   259   (1)|      0 |00:00:00.30 |     108K|
|   2 |   UNION-ALL                                   |                   |      1 |        |            |      0 |00:00:00.30 |     108K|
|*  3 |    HASH JOIN SEMI                             |                   |      1 |      1 |   137   (1)|      0 |00:00:00.16 |   57863 |
|   4 |     NESTED LOOPS                              |                   |      1 |      1 |   117   (1)|      0 |00:00:00.16 |   57863 |
|   5 |      NESTED LOOPS                             |                   |      1 |      1 |   117   (1)|      0 |00:00:00.16 |   57863 |
|   6 |       NESTED LOOPS                            |                   |      1 |      1 |   116   (1)|     54 |00:00:00.16 |   57863 |
|   7 |        NESTED LOOPS                           |                   |      1 |     41 |   113   (0)|   4575 |00:00:00.09 |   37089 |
|   8 |         TABLE ACCESS FULL                     | STD_MIGR_DOS      |      1 |      5 |   109   (0)|   4575 |00:00:00.01 |    5112 |
|   9 |         INLIST ITERATOR                       |                   |   4575 |        |            |   4575 |00:00:00.08 |   31977 |
|  10 |          TABLE ACCESS BY INDEX ROWID BATCHED  | G_PIECE           |   9150 |      8 |     1   (0)|   4575 |00:00:00.08 |   31977 |
|* 11 |           INDEX RANGE SCAN                    | PIE_REFDOSS       |   9150 |    138 |     1   (0)|   4575 |00:00:00.06 |   27458 |
|* 12 |        TABLE ACCESS BY INDEX ROWID BATCHED    | G_PIECEDET        |   4575 |      1 |     1   (0)|     54 |00:00:00.07 |   20774 |
|* 13 |         INDEX RANGE SCAN                      | G_PIECEDET_REFP   |   4575 |      1 |     1   (0)|   2696 |00:00:00.06 |   18762 |
|* 14 |       INDEX UNIQUE SCAN                       | PK_G_DOMICIL      |     54 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 15 |      TABLE ACCESS BY INDEX ROWID              | G_DOMICILIATION   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|  16 |     TABLE ACCESS FULL                         | STD_MIGR_CBA      |      0 |   6337 |    20   (0)|      0 |00:00:00.01 |       0 |
|  17 |    NESTED LOOPS                               |                   |      1 |      1 |   123   (2)|      0 |00:00:00.14 |   50566 |
|  18 |     NESTED LOOPS                              |                   |      1 |      1 |   123   (2)|      0 |00:00:00.14 |   50566 |
|* 19 |      HASH JOIN                                |                   |      1 |      1 |   122   (2)|      0 |00:00:00.14 |   50566 |
|  20 |       NESTED LOOPS                            |                   |      1 |      1 |   118   (2)|      0 |00:00:00.14 |   50566 |
|  21 |        NESTED LOOPS                           |                   |      1 |      1 |   118   (2)|      0 |00:00:00.14 |   50566 |
|  22 |         NESTED LOOPS                          |                   |      1 |      1 |   117   (2)|     54 |00:00:00.14 |   50566 |
|  23 |          NESTED LOOPS                         |                   |      1 |     41 |   114   (1)|   3967 |00:00:00.08 |   32825 |
|* 24 |           TABLE ACCESS FULL                   | STD_MIGR_DOS      |      1 |      5 |   110   (1)|   3967 |00:00:00.02 |    5112 |
|  25 |           INLIST ITERATOR                     |                   |   3967 |        |            |   3967 |00:00:00.07 |   27713 |
|  26 |            TABLE ACCESS BY INDEX ROWID BATCHED| G_PIECE           |   7934 |      8 |     1   (0)|   3967 |00:00:00.06 |   27713 |
|* 27 |             INDEX RANGE SCAN                  | PIE_REFDOSS       |   7934 |    138 |     1   (0)|   3967 |00:00:00.05 |   23800 |
|* 28 |          TABLE ACCESS BY INDEX ROWID BATCHED  | G_PIECEDET        |   3967 |      1 |     1   (0)|     54 |00:00:00.06 |   17741 |
|* 29 |           INDEX RANGE SCAN                    | G_PIECEDET_REFP   |   3967 |      1 |     1   (0)|   1949 |00:00:00.05 |   16324 |
|* 30 |         INDEX UNIQUE SCAN                     | PK_CPTBQ_REFCPTBQ |     54 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 31 |        TABLE ACCESS BY INDEX ROWID            | G_CPTBQ           |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|  32 |       TABLE ACCESS FULL                       | STD_MIGR_BBA      |      0 |    843 |     4   (0)|      0 |00:00:00.01 |       0 |
|* 33 |      INDEX RANGE SCAN                         | SOC_INDIV         |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 34 |     TABLE ACCESS BY INDEX ROWID               | T_INDIVIDU        |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   3 - access("PAYM"."LIB2"="CBA"."REFEXTIND" AND "DOM"."IMX_UN_ID"=TO_NUMBER("CBA"."REFCBA"))
  11 - access("PI"."REFDOSS"="DOS"."PRC_REFDOSS" AND (("PI"."TYPPIECE"='CONTRAT' OR "PI"."TYPPIECE"='CONTRAT REV')))
       filter("PI"."REFDOSS" IS NOT NULL)
  12 - filter(("PAYM"."LIB2" IS NOT NULL AND ("PAYM"."LIB2" IS NULL OR "PAYM"."TX01" IS NULL OR "PAYM"."STR1" IS NULL)))
  13 - access("PAYM"."REFPIECE"="PI"."REFPIECE" AND "PAYM"."TYPE"='PARAM_PM')
  14 - access("DOM"."IMX_UN_ID"=TO_NUMBER("PAYM"."STR6"))
  15 - filter(NVL("PAYM"."STR3",'X')=NVL("DOM"."NOCOMPTE",'X'))
  19 - access("DOM"."REFCPTBQ"=TO_NUMBER("BBA"."REFEXT"))
  24 - filter("DOS"."CATEGDOSS" LIKE 'CONTRAT IMP%')
  27 - access("PI"."REFDOSS"="DOS"."PRC_REFDOSS" AND (("PI"."TYPPIECE"='CONTRAT' OR "PI"."TYPPIECE"='CONTRAT REV')))
       filter("PI"."REFDOSS" IS NOT NULL)
  28 - filter(("PAYM"."LIB2" IS NOT NULL AND ("PAYM"."LIB2" IS NULL OR "PAYM"."TX01" IS NULL OR "PAYM"."STR1" IS NULL)))
  29 - access("PAYM"."REFPIECE"="PI"."REFPIECE" AND "PAYM"."TYPE"='PARAM_PM')
  30 - access("DOM"."REFCPTBQ"=TO_NUMBER("PAYM"."STR7"))
  31 - filter(NVL("PAYM"."STR3",'X')=NVL("DOM"."NUMCPT",'X'))
  33 - access("CO_FACT"."SOCIETE"='FCI_FACTOR' AND "CO_FACT"."REFEXT"="BBA"."REFBU")
  34 - filter("PAYM"."LIB2"="CO_FACT"."REFINDIVIDU")


-- 4g0s28621nhad

Plan hash value: 1492419134
----------------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                      | Name              | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  |
----------------------------------------------------------------------------------------------------------------------------------------------------
|   0 | INSERT STATEMENT                               |                   |      1 |        |   259 (100)|      0 |00:00:00.78 |     111K|    459 |
|   1 |  LOAD TABLE CONVENTIONAL                       | STD_MIGR_PCL      |      1 |        |            |      0 |00:00:00.78 |     111K|    459 |
|   2 |   SORT UNIQUE                                  |                   |      1 |      2 |   259   (1)|    933 |00:00:00.76 |     111K|    448 |
|   3 |    UNION-ALL                                   |                   |      1 |        |            |    933 |00:00:00.76 |     111K|    448 |
|*  4 |     HASH JOIN                                  |                   |      1 |      1 |   137   (1)|    723 |00:00:00.59 |   60594 |    433 |
|   5 |      NESTED LOOPS                              |                   |      1 |      1 |   117   (1)|   1654 |00:00:00.58 |   60487 |    418 |
|   6 |       NESTED LOOPS                             |                   |      1 |      1 |   117   (1)|   1657 |00:00:00.26 |   58828 |     95 |
|   7 |        NESTED LOOPS                            |                   |      1 |      1 |   116   (1)|   2319 |00:00:00.18 |   57870 |      0 |
|   8 |         NESTED LOOPS                           |                   |      1 |     41 |   113   (0)|   4575 |00:00:00.10 |   37089 |      0 |
|   9 |          TABLE ACCESS FULL                     | STD_MIGR_DOS      |      1 |      5 |   109   (0)|   4575 |00:00:00.01 |    5112 |      0 |
|  10 |          INLIST ITERATOR                       |                   |   4575 |        |            |   4575 |00:00:00.09 |   31977 |      0 |
|  11 |           TABLE ACCESS BY INDEX ROWID BATCHED  | G_PIECE           |   9150 |      8 |     1   (0)|   4575 |00:00:00.08 |   31977 |      0 |
|* 12 |            INDEX RANGE SCAN                    | PIE_REFDOSS       |   9150 |    138 |     1   (0)|   4575 |00:00:00.06 |   27458 |      0 |
|* 13 |         TABLE ACCESS BY INDEX ROWID BATCHED    | G_PIECEDET        |   4575 |      1 |     1   (0)|   2319 |00:00:00.07 |   20781 |      0 |
|* 14 |          INDEX RANGE SCAN                      | G_PIECEDET_REFP   |   4575 |      1 |     1   (0)|   2696 |00:00:00.06 |   18769 |      0 |
|* 15 |        INDEX UNIQUE SCAN                       | PK_G_DOMICIL      |   2319 |      1 |     1   (0)|   1657 |00:00:00.09 |     958 |     95 |
|* 16 |       TABLE ACCESS BY INDEX ROWID              | G_DOMICILIATION   |   1657 |      1 |     1   (0)|   1654 |00:00:00.31 |    1659 |    323 |
|  17 |      TABLE ACCESS FULL                         | STD_MIGR_CBA      |      1 |   6337 |    20   (0)|   6757 |00:00:00.01 |     107 |     15 |
|  18 |     NESTED LOOPS                               |                   |      1 |      1 |   123   (2)|    210 |00:00:00.17 |   51013 |     15 |
|  19 |      NESTED LOOPS                              |                   |      1 |      1 |   123   (2)|    210 |00:00:00.16 |   50983 |      8 |
|* 20 |       HASH JOIN                                |                   |      1 |      1 |   122   (2)|    210 |00:00:00.16 |   50921 |      8 |
|  21 |        NESTED LOOPS                            |                   |      1 |      1 |   118   (2)|    214 |00:00:00.16 |   50905 |      8 |
|  22 |         NESTED LOOPS                           |                   |      1 |      1 |   118   (2)|    216 |00:00:00.15 |   50689 |      5 |
|  23 |          NESTED LOOPS                          |                   |      1 |      1 |   117   (2)|   1604 |00:00:00.14 |   50569 |      0 |
|  24 |           NESTED LOOPS                         |                   |      1 |     41 |   114   (1)|   3967 |00:00:00.08 |   32827 |      0 |
|* 25 |            TABLE ACCESS FULL                   | STD_MIGR_DOS      |      1 |      5 |   110   (1)|   3967 |00:00:00.02 |    5112 |      0 |
|  26 |            INLIST ITERATOR                     |                   |   3967 |        |            |   3967 |00:00:00.07 |   27715 |      0 |
|  27 |             TABLE ACCESS BY INDEX ROWID BATCHED| G_PIECE           |   7934 |      8 |     1   (0)|   3967 |00:00:00.06 |   27715 |      0 |
|* 28 |              INDEX RANGE SCAN                  | PIE_REFDOSS       |   7934 |    138 |     1   (0)|   3967 |00:00:00.05 |   23802 |      0 |
|* 29 |           TABLE ACCESS BY INDEX ROWID BATCHED  | G_PIECEDET        |   3967 |      1 |     1   (0)|   1604 |00:00:00.06 |   17742 |      0 |
|* 30 |            INDEX RANGE SCAN                    | G_PIECEDET_REFP   |   3967 |      1 |     1   (0)|   1949 |00:00:00.05 |   16325 |      0 |
|* 31 |          INDEX UNIQUE SCAN                     | PK_CPTBQ_REFCPTBQ |   1604 |      1 |     1   (0)|    216 |00:00:00.01 |     120 |      5 |
|* 32 |         TABLE ACCESS BY INDEX ROWID            | G_CPTBQ           |    216 |      1 |     1   (0)|    214 |00:00:00.01 |     216 |      3 |
|  33 |        TABLE ACCESS FULL                       | STD_MIGR_BBA      |      1 |    843 |     4   (0)|    843 |00:00:00.01 |      16 |      0 |
|* 34 |       INDEX RANGE SCAN                         | SOC_INDIV         |    210 |      1 |     1   (0)|    210 |00:00:00.01 |      62 |      0 |
|* 35 |      TABLE ACCESS BY INDEX ROWID               | T_INDIVIDU        |    210 |      1 |     1   (0)|    210 |00:00:00.01 |      30 |      7 |
----------------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   4 - access("PAYM"."LIB2"="CBA"."REFEXTIND" AND "DOM"."IMX_UN_ID"=TO_NUMBER("CBA"."REFCBA"))
  12 - access("PI"."REFDOSS"="DOS"."PRC_REFDOSS" AND (("PI"."TYPPIECE"='CONTRAT' OR "PI"."TYPPIECE"='CONTRAT REV')))
       filter("PI"."REFDOSS" IS NOT NULL)
  13 - filter(("PAYM"."LIB2" IS NOT NULL AND "PAYM"."TX01" IS NOT NULL AND "PAYM"."STR1" IS NOT NULL))
  14 - access("PAYM"."REFPIECE"="PI"."REFPIECE" AND "PAYM"."TYPE"='PARAM_PM')
  15 - access("DOM"."IMX_UN_ID"=TO_NUMBER("PAYM"."STR6"))
  16 - filter(NVL("PAYM"."STR3",'X')=NVL("DOM"."NOCOMPTE",'X'))
  20 - access("DOM"."REFCPTBQ"=TO_NUMBER("BBA"."REFEXT"))
  25 - filter("DOS"."CATEGDOSS" LIKE 'CONTRAT IMP%')
  28 - access("PI"."REFDOSS"="DOS"."PRC_REFDOSS" AND (("PI"."TYPPIECE"='CONTRAT' OR "PI"."TYPPIECE"='CONTRAT REV')))
       filter("PI"."REFDOSS" IS NOT NULL)
  29 - filter(("PAYM"."LIB2" IS NOT NULL AND "PAYM"."TX01" IS NOT NULL AND "PAYM"."STR1" IS NOT NULL))
  30 - access("PAYM"."REFPIECE"="PI"."REFPIECE" AND "PAYM"."TYPE"='PARAM_PM')
  31 - access("DOM"."REFCPTBQ"=TO_NUMBER("PAYM"."STR7"))
  32 - filter(NVL("PAYM"."STR3",'X')=NVL("DOM"."NUMCPT",'X'))
  34 - access("CO_FACT"."SOCIETE"='FCI_FACTOR' AND "CO_FACT"."REFEXT"="BBA"."REFBU")
  35 - filter("PAYM"."LIB2"="CO_FACT"."REFINDIVIDU")
*/
/********************************New Metrics***************************************/

/********************************Index statistics**********************************/

/********************************Other SQLs****************************************/          
/*

*/ 
/********************************Other SQLs****************************************/              
