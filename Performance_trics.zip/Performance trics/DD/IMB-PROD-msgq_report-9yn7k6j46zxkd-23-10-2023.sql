/********************************************************************************
*********       E-mail subject: IMBDEV-11638
*********             Instance: PROD
*********          Description: 
Problem:
Slow query from msgq_report.

Analysis:
On 23/10/2023 in the period between 07:00:00 and 09:00:00 the forth TOP SQL in msgq was 9yn7k6j46zxkd from lst_pnp_ReportLetters.pc.
The problem with it wa that Oracle use inappropriate execution plan because of missing index on column LIBELLE_20_9 on table G_PIECE.

Suggestion:
1. Please create index on column LIBELLE_20_9 on table G_PIECE.

2. Please change the SQL as it is shown in the New SQL section below.

*********               SQL_ID: 9yn7k6j46zxkd
*********      Program/Package: lst_pnp_ReportLetters.pc
*********              Request: Dimitare Ivanov
*********               Author: Dimitar Dimitrov
********* Received e-mail date: 23/10/2023
*********      Resolution date: 23/10/2023
*********  Trace old file here: \\epox\specifs\performance\tmp\
*********  Trace new file here:
***********************************************************************************/

/********************************OLD SQL*******************************************/
var B1 varchar2(32);
exec :B1 := 'A40060RV';
select GPIDEPOT
  FROM G_PIECE
 WHERE TYPPIECE = 'FACTURE'
   AND LIBELLE_20_9||'' = :b1
   AND ROWNUM = 1;
/********************************OLD SQL*******************************************/
/********************************OLD Metrics***************************************/
/*
 MODULE                           PROGRAM                                            SQL_ID         PLAN_HASH     SID SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL        PERC
-------------------------------- -------------------------------------------------- ------------- ---------- ------- ------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
msgq_report                                                                         9yn7k6j46zxkd 3653493647                                      2023/10/23 07:18:00  2023/10/23 08:59:59        2831             16777219 +000000000 01:41:58.400 4%

INSTANCE_NUMBER SQL_ID            ELAPSED MAX_WAIT_ON     PC_OF  WAIT_TIME            GETS      READS       ROWS  ELAP/EXEC       GETS/EXEC READS/EXEC  ROWS/EXEC       EXEC PLAN_HASH_VALUE
--------------- ------------- ----------- --------------- ----- ---------- --------------- ---------- ---------- ---------- --------------- ---------- ---------- ---------- ---------------
              2 9yn7k6j46zxkd        1994 IO              80%    2214.9719        68672305    4393667          6     284.92         9810329  627666.71        .86          7      3653493647
              1 9yn7k6j46zxkd        1690 IO              77%   1903.22057        77430052    3575404          7     211.24         9678757   446925.5        .88          8      3653493647

-- From execution on IVKA

Plan hash value: 3966529180
-----------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                            | Name             | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  |
-----------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                     |                  |      1 |        |     1 (100)|      1 |00:00:31.76 |     150K|  12189 |
|*  1 |  COUNT STOPKEY                       |                  |      1 |        |            |      1 |00:00:31.76 |     150K|  12189 |
|*  2 |   TABLE ACCESS BY INDEX ROWID BATCHED| G_PIECE          |      1 |      1 |     1   (0)|      1 |00:00:31.76 |     150K|  12189 |
|*  3 |    INDEX RANGE SCAN                  | GP_ST02_FUNC_IDX |      1 |  13492 |     1   (0)|  91486 |00:00:02.64 |     370 |    369 |
-----------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   1 - filter(ROWNUM=1)
   2 - filter("LIBELLE_20_9"||''=:B1)
   3 - access("TYPPIECE"='FACTURE') 

*/
/********************************OLD Metrics***************************************/

/********************************New SQL*******************************************/

select /*+ index(G_PIECE IDX_FACTURE_LIBELLE_20_9) */ GPIDEPOT
  FROM G_PIECE
 WHERE TYPPIECE = 'FACTURE'
   AND LIBELLE_20_9||'' = :b1
   AND ROWNUM = 1;
/********************************New SQL*******************************************/
/********************************New Metrics***************************************/
/*
-- From execution on IVKA

Plan hash value: 536817035
-------------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                            | Name                     | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  |
-------------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                     |                          |      1 |        |     1 (100)|      1 |00:00:00.03 |       3 |      2 |
|*  1 |  COUNT STOPKEY                       |                          |      1 |        |            |      1 |00:00:00.03 |       3 |      2 |
|*  2 |   TABLE ACCESS BY INDEX ROWID BATCHED| G_PIECE                  |      1 |      1 |     1   (0)|      1 |00:00:00.03 |       3 |      2 |
|*  3 |    INDEX RANGE SCAN                  | IDX_FACTURE_LIBELLE_20_9 |      1 |   4695 |     1   (0)|      1 |00:00:00.03 |       2 |      2 |
-------------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   1 - filter(ROWNUM=1)
   2 - filter("TYPPIECE"='FACTURE')
   3 - access("G_PIECE"."SYS_NC00795$"=:B1)  
*/
/********************************New Metrics***************************************/

/********************************Index statistics**********************************/

/********************************Other SQLs****************************************/          
/*

*/ 
/********************************Other SQLs****************************************/              
