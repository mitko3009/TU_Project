﻿==============================================================================================================================
##### EXAMPLE - HOW TO CLOSE MAILS #####
==============================================================================================================================
=============================================================================================================================


### MAIL TO ***** FOR FS ###
	
	Hello team,

We've received an incident E-IM028649661 regarding Filesystem /oracle/EMP diskspace utilization exceeds 85 threshold on server sv1834.logista.local
After we performed checks we found out that there are no datafiles that could be shrunk, and no space left on the device, and therefore an extend should be requested:

+ASM1 0334 7.76 objext=DATA diskgroup=DATA free=1894664.00 total=24419840.00 instance=+APX1 ora_server_name=+ASM1


The Incident is currently in status “Pending” and it will be assigned to Spas Ushagelov.
Please check and request an extend in order to fix the issue, or consider the option to lower the threshold.
 

=================================
==============================================

##### MAIL TO EXTEND FOR FS #####

From: CM-ITO-DO-BULGARIA-ORACLE <cm-ito-do-bulgaria-oracle@dxc.com> 
Sent: Monday, September 23, 2019 5:02 PM
To: PDL-Bulgaria-South-Logista-Oracle <pdl-bulgaria-south-logista-oracle@dxc.com>
Cc: CM-ITO-DO-BULGARIA-ORACLE <cm-ito-do-bulgaria-oracle@dxc.com>
Subject: [LOGISTA][E-IM029109438] - UXMON: Filesystem /u02/app/oracle/oradata/IWCANP diskspace utilization exceeds 90 threshold. Check also these items: INODE:/u02/app/oracle/oradata/IWCANP

Hello team,

We've received an incident  E-IM029109438  regarding   Filesystem /u02/app/oracle/oradata/IWCANP diskspace utilization exceeds 90 threshold  on server  ra005.logista.local.
After our investigation we found that destination : /u02/app/oracle/oradata/IWCANP contains datafiles:


Filesystem            Size  Used Avail Use% Mounted on
/dev/asm/datiwcanp-37
                      130G  118G   13G  91% /u02/app/oracle/oradata/IWCANP
[root@ra005 IWCANP]# find . -xdev -size +100000c -type f -exec ls -la {} \; 2> /dev/null |  sort -nk5 | tail -2000

-rw-r----- 1 oracle asmadmin 5251072 Sep 23 15:05 ./IWCANP/datafile/o1_mf_users_fzhsc4q7_.dbf
-rw-r----- 1 oracle asmadmin 10493952 Sep 23 15:05 ./IWCANP/datafile/o1_mf_tbpsaudi_fzht0s2p_.dbf
-rw-r----- 1 oracle asmadmin 119939072 Sep 23 15:05 ./IWCANP/datafile/o1_mf_tool_g01wkrph_.dbf
-rw-r----- 1 oracle asmadmin 1073750016 Sep 23 15:05 ./IWCANP/datafile/o1_mf_xdb_g01wrl6x_.dbf
-rw-r----- 1 oracle asmadmin 1405100032 Sep 23 15:48 ./IWCANP/datafile/o1_mf_system_fzhrvgs5_.dbf
-rw-r----- 1 oracle asmadmin 2295341056 Sep 23 15:48 ./IWCANP/datafile/o1_mf_bew_gpy75lrs_.dbf
-rw-r----- 1 oracle asmadmin 4294975488 Sep 23 15:48 ./IWCANP/datafile/o1_mf_dat_g01wlwdo_.dbf
-rw-r----- 1 oracle asmadmin 4505739264 Sep 23 15:48 ./IWCANP/datafile/o1_mf_sysaux_fzhrw81b_.dbf
-rw-r----- 1 oracle asmadmin 7165976576 Sep 23 15:48 ./IWCANP/datafile/o1_mf_dat_idx_g01wn0kf_.dbf
-rw-r----- 1 oracle asmadmin 8589942784 Sep 23 15:05 ./IWCANP/datafile/o1_mf_iwf_g01wptgl_.dbf
-rw-r----- 1 oracle asmadmin 10737426432 Sep 23 15:05 ./IWCANP/datafile/o1_mf_iwf_idx_g01wqmrg_.dbf
-rw-r----- 1 oracle asmadmin 11135885312 Sep 23 15:48 ./IWCANP/datafile/o1_mf_temp_fzhryvhr_.tmp
-rw-r----- 1 oracle asmadmin 20902322176 Sep 23 15:48 ./IWCANP/datafile/o1_mf_bew_idx_g01worc2_.dbf
-rw-r----- 1 oracle asmadmin 21878546432 Sep 23 15:48 ./IWCANP/datafile/o1_mf_undotbs1_fzhrx16z_.dbf
-rw-r----- 1 oracle asmadmin 31195144192 Sep 23 15:48 ./IWCANP/datafile/o1_mf_bew_g01wnksn_.dbf


We have triggered HWM script to shrink datafile to ensure some free space but it did not help

Could you please consider for file system extend.
The ticket will be set in pending status and assigned to Spas Ushagelov.

Best regards,
Izabela Pehlivanska
Technical Support
iAction | Oracle Database Team
+359 889 820 093 Red Phone
CM-ITO-DO-BULGARIA-ORACLE@dxc.com
Business Park Sofia, Building 9
Sofia, Bulgaria
 


 
=====================================================
=====================================================
DOWNTIME CONTACTS to approval restart
======================================================

Dear  Downtime contacts,
 
We have received an incident regarding DBSPI11-03: Unable to connect to one or more databases (EORA,) configured in file local.cfg located in dbspi directory on server  eapp12.it.gefa.de
 
We need the approval to restart the EORA database to restore the normal functioning.
Here is an excerpt of the alert log :
 
Exception [type: SIGSEGV, Address not mapped to object] [ADDR:0x40] [PC:0xD1756A5, kghfrh_internal()+53] [flags: 0x0, count: 1]
Errors in file /ent/db/oracle/diag/rdbms/eora/EORA/trace/EORA_s001_8616.trc  (incident=359371):
ORA-07445: Exception aufgetreten: CORE Dump [kghfrh_internal()+53] [SIGSEGV] [ADDR:0x40] [PC:0xD1756A5] [Address not mapped to object] []
ORA-04031: 224 Byte des Shared Memorys konnten nicht zugewiesen werden ("large pool","unknown object","session heap","kolrugi: hd_kolrug")
Incident details in: /ent/db/oracle/diag/rdbms/eora/EORA/incident/incdir_359371/EORA_s001_8616_i359371.trc
Use ADRCI or Support Workbench to package the incident.
See Note 411.1 at My Oracle Support for error and packaging details.
Mon Mar 09 10:44:01 2020
Dumping diagnostic data in directory=[cdmp_20200309104401], requested by (instance=1, osid=8616 (S001)), summary=[incident=359371].
Mon Mar 09 10:44:04 2020
Sweep [inc][359371]: completed
Sweep [inc2][359371]: completed
Mon Mar 09 10:44:31 2020
found dead shared server 'S001', pid = (29, 1)
Mon Mar 09 10:47:00 2020
Use ADRCI or Support Workbench to package the incident.
See Note 411.1 at My Oracle Support for error and packaging details.
Mon Mar 09 10:49:00 2020
Errors in file /ent/db/oracle/diag/rdbms/eora/EORA/trace/EORA_s002_8618.trc  (incident=359343):
ORA-00600: Interner Fehlercode, Argumente: [kpotcgah-8], [1697700112], [▒▒▒▒], [], [], [], [], [], [], [], [], []
ORA-04031: 2072 Byte des Shared Memorys konnten nicht zugewiesen werden ("large pool","unknown object","koh-kghu sessi","kpplal dvoid")
Incident details in: /ent/db/oracle/diag/rdbms/eora/EORA/incident/incdir_359343/EORA_s002_8618_i359343.trc
Use ADRCI or Support Workbench to package the incident.
See Note 411.1 at My Oracle Support for error and packaging details.
Mon Mar 09 10:49:01 2020
Dumping diagnostic data in directory=[cdmp_20200309104901], requested by (instance=1, osid=8618 (S002)), summary=[incident=359343].
Mon Mar 09 10:49:04 2020
Sweep [inc][359343]: completed
Sweep [inc2][359343]: completed
DDE: Problem Key 'ORA 4031' was completely flood controlled (0x6)
Further messages for this problem key will be suppressed for up to 10 minutes
 
We an awaiting for your response.
The ticket will be put in status “Pending”.
 



===========================================================================================================================
==========================================================================================================================

######## Last received / apply  ######## 

Onderwerp: [VOBE]E-IM029720940*WISK7_PS:ERRORLOG: ORA-00354: corrupt redo log block header / E-IM029720751*DBSPI-0810: Database WISK7_PS has 1.00 standby archive destinations with errors. [Policy:DBMON-DBSPI-0811-ARM]

Hello,

We have received two incidents for:

E-IM029720940*WISK7_PS:ERRORLOG: ORA-00354: corrupt redo log block header
E-IM029720751*DBSPI-0810: Database WISK7_PS has 1.00 standby archive destinations with errors. [Policy:DBMON-DBSPI-0811-ARM]

Node          : uv163062-oob.vlaanderen.be

Database/Physical Standby/: WISK7_PS


The apply was terminated:

Tue Jan 07 06:00:28 2020
MRP0: Background Media Recovery process shutdown (WISK7_PS)


And started manually:

Tue Jan 07 06:34:22 2020


Currently logs are catching up, only 3 left, estimate time to complete is about 15min.


    Thread Last Sequence Received Last Sequence Applied Difference
---------- ---------------------- --------------------- ----------
         1                1077694               1077691          3


Please check from your side also. We will inform you when it finish.


//////////////////############################### Apply second mail

Subject: RE: [VOBE]E-IM029720940*WISK7_PS:ERRORLOG: ORA-00354: corrupt redo log block header / E-IM029720751*DBSPI-0810: Database WISK7_PS has 1.00 standby archive destinations with errors. [Policy:DBMON-DBSPI-0811-ARM]

Hello everybody,

We would like to inform you that the standby database is in sync with the primary.

        Thread    Last Sequence    Received Last Sequence Applied     Difference
--------------    ----------------------        ---------------------                          --------------
             1                1078105                  1078105                                          0

Could you please let us know after your check that we can close the service request.

Thank you!



===========================================================================================================================

#############  DB-SPI cannot connect to database ABAT_2, may be down;  AND LOCATED ON ANOTHER NODE #######################

From: CM-ITO-DO-BULGARIA-ORACLE 
Sent: Monday, July 15, 2019 8:36 PM
To: PDL-ITO-DO-Bulgaria-Database-FORTUM-Oracle <pdl-ito-do-bulgaria-database-fortum-oracle@dxc.com>
Cc: CM-ITO-DO-BULGARIA-ORACLE <cm-ito-do-bulgaria-oracle@dxc.com>
Subject: E2-IM020405547 - DB-SPI cannot connect to database ABAT_2, may be down;

Hello Team.

We received several incidents regarding DB-SPI cannot connect to database ABAT_2, may be down;

After we performed checks we found out that the database is relocated on node fivatx0236
We tried to relocate the database on the preferred node fivatx0237, but after a while the database is relocating again on fivatx0236 .
The alert log show the following error :

2019-07-15 16:26:07.852000 +00:00
Decreasing number of high priority LMS from 2 to 0
2019-07-15 16:40:30.854000 +00:00
Instance Critical Process (pid: 44, ospid: 9807, ASMB) died unexpectedly
PMON (ospid: 9705): terminating the instance due to error 486
Instance terminated by PMON, pid = 9705

Currently the database is running on the adoptive node fivatx0236.
Please be informed that according to ESL the database is not supported .

oracle rac instance:
  lookup details
unknown coverage
last detected on: 13 JUL 2019	    57%       

Instance Name:
ABAT_2
Software/Firmware Version:
12.2.0.1.190416
Discovered Version:
12.2.0.1.190416
Monitoring Full CI Name:
abat_2:ora:fivatx0237.adinfra.net



Please be aware that there is no monitoring for the database ABAT on node fivatx0236

root@fivatx0236 dbspi]# cat /var/opt/OV/dbspi/dbtab
ORACLE SIMPROD_1 /oracle/product/12.2.0/dbhome_1
ORA_ASM +ASM1 /grid/app/grid/18


The ticket will be closed.
=============================================================================================================================
=============================================================================================================================
=============================================================================================================================
###### SERVICE REQUEST , SENT EMAIL AND FINAL 2 SENTANSES IS INPORTANT. ##############################
=============================================================================================================================
Hello,

Regarding service request E2-IM020405686 / Delete File

We have deleted CAO_LABELLING.LOG as requested.

Your service request will be put on status Resolved. If you need any further assistance do not hesitate to contact us via e-mail or reopen the case.

=========================================================================================

Hello,

We performed a new check and we increased the size of the directory contains archive logs.
There aren’t error log messages in the alert log.
The archival process is running as normal and you shouldn’t be facing any related issue.

Your service request will be put on status Resolved.

==================================================================================
=============================================================================================================================
###  The current processes are bellow the threshold. ###

RESOURCE_NAME                  CURRENT_UTILIZATION MAX_UTILIZATION INITIAL_AL LIMIT_VALU     CON_ID
------------------------------ ------------------- --------------- ---------- ---------- ----------
processes                                      202             296        300        300          0
sessions                                        93             297        480        480          0
==============================================================================================================================
#### Downtime TEAM #####
=============================================================================================================================

From: CM-ITO-DO-BULGARIA-ORACLE 
Sent: Friday, July 12, 2019 3:56 PM
To: VPC-Frankfurt-INT-Robeco <vpc-frankfurt-int-robeco@dxc.com>; HMCO SM - Incident Mgt team <hmco-sm-incidentmgt@dxc.com>; Halop, Lolito Grullo <lolito.g.halop@dxc.com>
Cc: CM-ITO-DO-BULGARIA-ORACLE <cm-ito-do-bulgaria-oracle@dxc.com>; PDL-ITO-DO-Bulgaria-Database-ROBECO-Oracle <pdl-ito-do-bulgaria-database-robeco-oracle@dxc.com>
Subject: Incident on Server rbcdevesh005.3881.1405.ecs.hp.com, Case ID: E2-IM020385484 

Hello Downtime Team,
We received an incident P1 : 
ID : E2-IM020385484
Tittle: DBSPI-0058: Archive free space percentage 7.76% too low for archive device \u01\app\oracle\storage\OEMREP\orafra for OEMREP <=15%. [Policy:DBMON-DBSPI-0058-ARM]
Node   : rbcdevesh005.3881.1405.ecs.hp.com
After our check we found that archive log dest was 100% full and database was hanged.
We took actions  and at the current time the issue was fixed and the database is up and running.
Thank you a lot for your understanding of the issue.

Best regards,
Izabela Pehlivanska
Technical Support
iAction | Oracle Database Team
+359 889 820 093 Red Phone
CM-ITO-DO-BULGARIA-ORACLE@dxc.com
Business Park Sofia, Building 9
Sofia, Bulgaria
 
====================================================================================================================================
### Unlock account #####
====================================================================================================================================


From: CM-ITO-DO-BULGARIA-ORACLE 
Sent: Friday, July 12, 2019 5:53 PM
To: christian.lang@thyssenkrupp.com
Cc: CM-ITO-DO-BULGARIA-ORACLE <cm-ito-do-bulgaria-oracle@dxc.com>
Subject: [TK][E-IM028674697] - QCS_MESSAGEHISTORY_DOPRI Account gelockt

Hello Christian,

Your account (QCS_MESSAGEHISTORY_DOPRI)    was unlocked:

USERNAME                  ACCOUNT_STATUS                   LOCK_DATE           EXPIRY_DATE         PROFILE
------------------------- -------------------------------- ------------------- ------------------- ----------
QCS_MESSAGEHISTORY_DOPRI  OPEN                                                                     DEFAULT


Please check if everything is ok from your side.


Best regards,
Izabela Pehlivanska
Technical Support
iAction | Oracle Database Team
+359 889 820 093 Red Phone
CM-ITO-DO-BULGARIA-ORACLE@dxc.com
Business Park Sofia, Building 9
Sofia, Bulgaria


### V EMEA na SOLUTIONS:
############ RESOLVED ###########

### Request was completed. Account was unlocked.
 

====================================================================================================================================
#### Mail to application for check ####
====================================================================================================================================
Hello,

We are checking the service call,

E2-IM020383365

GAS-X QA MENAQDG No space left on device

for database: MENAQ

On server: sl72112.eu-gt.net


We killed successfully the inactive sessions from VNGSYS, but the inactive sessions from user VNGUS are generate repeatedly.


Could you please check, your application because it seems to be that something from the application side, makes successful connection to database and after that makes the connection repeatedly.

Please be advised, that if the sessions goes to maximum utilization (max 1500), the database will hang, and will be not available.

Thank you.


Best regards,
Izabela Pehlivanska
Technical Support
iAction | Oracle Database Team
+359 889 820 093 Red Phone
CM-ITO-DO-BULGARIA-ORACLE@dxc.com
Business Park Sofia, Building 9
Sofia, Bulgaria

===========================================================================================================
###### MAIL TO DOWNTIME #######
=============================================================================================================

Van: CM-ITO-DO-BULGARIA-ORACLE [mailto:cm-ito-do-bulgaria-oracle@dxc.com] 
Verzonden: dinsdag 10 september 2019 14:04
Aan: DL T&O MICT Business Applicaties BAS <DLTOMICTBusinessApplicatiesBAS@VRT.BE>; PDL-ITO-DO-Bulgaria-Database-FG-Oracle <pdl-ito-do-bulgaria-database-fg-oracle@dxc.com>
CC: Prokopiev, Stanislav (Unix AAT Engineer ( Capacity / Change Lead)) <prokopiev@dxc.com>; Ivanov, Alexander (Big Data & Analytics Engineer) <alexander.ivanov2@dxc.com>; CM-ITO-DO-BULGARIA-ORACLE <cm-ito-do-bulgaria-oracle@dxc.com>
Onderwerp: Incident on Server oradbprod2-oob.vrt.vlaanderen.be, Case ID: E-IM029030329

Hello Downtime Team,

We received an incident P2 :

ID : E-IM029030329

Tittle : DBSPI-0001.3: DB-SPI cannot connect to database BRIARPRD2, may be down; Oracle error [ORA-12514: TNS:listener does not currently know of service requested in connect descriptor]. 

After our check we found that the instances on node  oradbprod2-oob.vrt.vlaanderen.be,  have lost touch with the storage and they stopped work on this node. During this time frame instances on the other  node were up and running and now service interruption should be present to the application.

We took actions  and at the current time the issue was fixed and the instances are up and running.

Checking instance: 'ASTERPRD2' @ '/u01/app/oracle/product/11.2.0.4/dbhome_1':
        Connect:         OKAY
        Filter 6:        OKAY

Checking instance: 'BRIARPRD2' @ '/u01/app/oracle/product/11.2.0.4/dbhome_1':
        Connect:         OKAY
        Filter 6:        OKAY


Could you please check if everything is ok from the application side.

 
===========================================================================================================================
##### Answer for service request from backup team ######
==========================================================================================================================

From: CM-ITO-DO-BULGARIA-ORACLE 
Sent: Sunday, July 21, 2019 6:00 PM
To: RDC-BG-SMS-BURS-RST <ito-gdc-bulgaria-sms-burs-rst@dxc.com>
Cc: CM-ITO-DO-BULGARIA-ORACLE <cm-ito-do-bulgaria-oracle@dxc.com>; PDL-ITO-DO-Bulgaria-Database-OGE-Oracle <pdl-ito-do-bulgaria-database-oge-oracle@dxc.com>
Subject: E2-IM020447426 / [OGE] Issue with server: sl72951.eu-gt.net

Hello team,

Regarding service request E2-IM020447426 / [OGE] Issue with server: sl72951.eu-gt.net

We have checked the database, and we found out that the archive destination was full.

We successfully ran archive log backup and now the usage is in range .


Please check from your end .


Your service request will be put on status Resolved. If you need any further assistance do not hesitate to contact us via e-mail or reopen the case.

======================================================================================================================================
##### Answer for service request from backup team 
============================================================================================================================

Hello team,

Regarding service request E2-IM020450236 / [OGE] Issue with server: sl72112.eu-gt.net

We have checked the database, and we found out that the process usage was on 100%. 
After restart of the database we successfully ran archive log backup .
Currently full backup is running :

SessionID : 2019/07/22-590
        Session type        : Backup
        Session status      : In Progress
        User.Group@Host     : oracle.oinstall@sl72112.eu-gt.net
        Session started     : Mon 22 Jul 2019 08:45:31 CEST
        Backup Specification: Oracle8 sl72112_ora_test_MENAQ_weekly_full


Please check from your end .


Your service request will be put on status Resolved. If you need any further assistance do not hesitate to contact us via e-mail or reopen the case.


========================================================================================================================================

=============================================================================
#### EXTEND Filesystem #######
==============================================================================================================================
From: CM-ITO-DO-BULGARIA-ORACLE 
Sent: Friday, June 28, 2019 8:43 PM
To: PDL-Bulgaria-South-Logista-Oracle <pdl-bulgaria-south-logista-oracle@dxc.com>
Cc: CM-ITO-DO-BULGARIA-ORACLE <cm-ito-do-bulgaria-oracle@dxc.com>
Subject: [LOGISTA][E-IM028581600][EXTEND] - UXMON: Filesystem /u02/app/oracle/oradata/ALEP diskspace utilization exceeds 90 threshold. Check also these items: INODE:/u02/app/oracle/oradata/ALEP

Hello Team,

We have received a ticket, about LOGISTA

ID: E-IM028581600
Tittle: UXMON: Filesystem /u02/app/oracle/oradata/ALEP diskspace utilization exceeds 90 threshold.  Check also these items:   INODE:/u02/app/oracle/oradata/ALEP
Node          : ra003.logista.local



Filesystem            Size  Used Avail Use% Mounted on
/dev/asm/datalep-141  2.1T  1.9T  210G  91% /u02/app/oracle/oradata/ALEP

We have triggered HWM script to shrink datafile to ensure some free space:

Filesystem            Size  Used Avail Use% Mounted on
/dev/asm/datalep-141  2.1T  1.8T  335G  85% /u02/app/oracle/oradata/ALEP

Could you please check and consider for file system extend.

Thank you in advance!


==============================================================================================================================
##### AVON ONLY - MAIL FOR EXTEND #####
==============================================================================================================================
Hello Service Desk,
 
Please raise a ticket to UNIX Team about the below request. Thank you.


Hello Unix Team,
 
Please extend the following filesystems with 20%.

[root@ryelxtraxpdb2 omstrpr]# du -sh *
1.3G    archive42.dbf
1.2G    archive43.dbf
26G     axtab21.dbf
25G     axtab22.dbf
18G     undotbs01.dbf
17G     undotbs02.dbf
21G     undotbs03.dbf
32G     undotbs04.dbf

[root@ryelxtraxpdb2 omstrpr]# df -h .
Filesystem            Size  Used Avail Use% Mounted on
/dev/mapper/omstrprdatavg-omstrprdata05lv
                      146G  141G  5.4G  97% /omstrprdata05
					  
[root@ryelxtraxpdb2 omstrpr]# pwd
/omstrprdata05/omstrpr
[root@ryelxtraxpdb2 omstrpr]#

The filesystems are located on server: ryelxtraxpdb2.rye.avon.com
 
Thank you in advance!

==============================================================================================================================
##### REGULARE MAIL FOR EXTEND #####
==============================================================================================================================

Hi Team,

We received the incident:

UXMON: UXMON: Filesystem /datafiles/ORA0309 diskspace utilization exceeds 90 threshold.
CI	: ORA0309
Node: x0046-mgmt.srv.skf.net

After our check:

[root@x0046 ~]# df -h /datafiles/ORA0309
Filesystem            Size  Used Avail Use% Mounted on
/dev/mapper/vgorad0309-orad0309
                      118G  101G   11G  91% /datafiles/ORA0309

After execution of HWM script v2 we cannot free up enough free space:

SQL> !df -h /datafiles/ORA0309
Filesystem            Size  Used Avail Use% Mounted on
/dev/mapper/vgorad0309-orad0309
                      118G   99G   14G  89% /datafiles/ORA0309

The database storage needs to be extended.

<OR>
Could you please consider to extend the FS, thank you. 

The Incident is currently in status “Pending” and it will be assigned to Miroslav Marchev.

==============================================================================================================================
##### UXMON: Performance Alarm: CPU GBL_CPU_TOTAL_UTIL total exceeds threshold 35% #####
==============================================================================================================================

Hello,

We received CPU utilization incident from system porac212.it.gefa.de for database PORA2
E-IM027721804
[ARES_Diag] UXMON: Performance Alarm: CPU GBL_CPU_TOTAL_UTIL total exceeds threshold 35%EMEA_BARAM
Node          : porac212.it.gefa.de

After investigation we found that CPU is consumed by many oracle processes


GBL_NUM_CPU                       : 24
GBL_ACTIVE_CPU                    : 24
GBL_CPU_SYS_MODE_UTIL             : 2.81
GBL_CPU_USER_MODE_UTIL            : 87.46
GBL_CPU_TOTAL_UTIL                : 90.28
GBL_ACTIVE_CPU                    : 24
GBL_CPU_SYS_MODE_UTIL             : 2.81
GBL_CPU_USER_MODE_UTIL            : 87.46
GBL_CPU_TOTAL_UTIL                : 90.28
GBL_NUM_CPU                       : 24

oraprd   20391 71.2  0.2 8940736 283184 ?      Rs   17:33   0:27 oraclePNOR (LOCAL=NO)
oraprd    1795 48.0  8.6 63274012 8589828 ?    Ss   15:12  68:10 oraclePORA2 (LOCAL=NO)
oraprd    1917 47.4  8.6 63274008 8575384 ?    Ss   15:12  67:16 oraclePORA2 (LOCAL=NO)
oraprd    1785 47.1  8.6 63275032 8515400 ?    Ss   15:12  66:51 oraclePORA2 (LOCAL=NO)
oraprd    1801 47.0  8.4 63272984 8377444 ?    Ss   15:12  66:39 oraclePORA2 (LOCAL=NO)
oraprd    7725 46.7  8.3 63274008 8265460 ?    Ss   15:16  64:14 oraclePORA2 (LOCAL=NO)
oraprd    7723 46.5  8.3 63272924 8247892 ?    Ss   15:16  64:01 oraclePORA2 (LOCAL=NO)
oraprd    1779 46.1  8.5 63272928 8472076 ?    Ss   15:12  65:23 oraclePORA2 (LOCAL=NO)
oraprd    1777 46.0  8.7 63274008 8602732 ?    Ss   15:12  65:14 oraclePORA2 (LOCAL=NO)
oraprd    1758 45.9  8.2 63274012 8199348 ?    Ss   15:12  65:03 oraclePORA2 (LOCAL=NO)

Could you please check them.
Thank you.

==============================================================================================================================
##### DBSPI-0006 1.00 tablespaces with free space percentage too low in KFP =10%, most serious is PSAPSR3 at 10.00% #####
==============================================================================================================================

Hello Team,

We have received a case E-IM027349826 regard DBSPI-0006: 1.00 tablespaces with free space percentage too low in KFP <=10%, most serious is PSAPSR3 at 10.00%. After adding files we found that the free space on the aforementioned tablespace is not changing and is still near the threshold. 
Please check and consider requesting some additional storage.

Node                  : vcx0001q0c.kf.local
Instance Name : KFP

####Logs:

[root@vcx0001q0c ~]# dbspicao -m6 -r1

                                    DATA FILE        FREE       FILE SYSTEM
TABLESPACE_NAME                     SPACE (MB)       SPACE (MB) SPACE (MB)    PERCENT FREE   AUTOEXTEND
----------------------------------           ----------------         -----------       ------------            ------------             ----------
PSAPSR3                                         5776265.38         2568.56     650469.68           10.16                        YES

==============================================================================================================================
##### DBSPI-0334: Free space percentage 1.99 too low for DATA1 in database +ASM3 <=3%. Free space 1305288.00Mb, total space 65536000.00Mb #####

##### EVGENIIIIIIIII ################
==============================================================================================================================

Hello Team,

We have received an incident E2-IM020471255 regarding 1.00 tablespaces with free space percentage too low in OGEFPMP  on server : sl72851.eu-gt.net
After we performed checks we found out that there are no datafiles that could be shrunk, and no space left on the device, and therefore an extend should be requested:


TABLESPACE_NAME                     SPACE (MB)       SPACE (MB) SPACE (MB)    PERCENT FREE   AUTOEXTEND
---------------------------------- ---------------- ----------- ------------  ------------   ----------
MTR_TS                            228306.92        22627.06          0.00         9.91           NO


GROUP_NUMBER NAME                             TOTAL_MB    FREE_MB    USED_MB PCT_FREE
------------ ------------------------------ ---------- ---------- ---------- --------
           1 DATA                               409472      26552     382920     6.48


The Incident is currently in status “Pending” and it will be assigned to Andrey Tsolev .
Please check and request an extend in order to fix the issue, or consider the option to lower the threshold.
Thank you.

==============================================================================================================================
##### ORA-00600: internal error code, arguments: [Cursor not typechecked], [], [], [], [], [], [], [], [], [], [], [] #####
==============================================================================================================================

Hello Team,

We received a ticket E-IM027559138
ERFPRD_1:ERRORLOG: ORA-00600: internal error code, arguments: [Cursor not typechecked], [], [], [], [], [], [], [], [], [], [], []
Node          : sl-snp-db-006.2030.1815.ecs.hp.com

Currently the database is UP and RUNNING, 
DATABASE        HOSTED_ON                      STATUS LOGINS  DATABASE_STARTED       CURRENT_TIME           UPTIME
--------------- ------------------------------ ------ ------- ---------------------- ---------------------- ------------------------
ERFPRD_1        sl-snp-db-006                  OPEN   ALLOWED FEB/09/2019 21:47:12   FEB/10/2019 07:02:05   0d / 9h / 33m / 53s


but in the alert log, we saw the database generates 7 error ORA-600.


ORA-00600: internal error code, arguments: [Cursor not typechecked], [], [], [], [], [], [], [], [], [], [], []
Incident details in: /u01/app/oracle/diag/rdbms/erfsby/ERFPRD_1/incident/incdir_1473880/ERFPRD_1_ora_1915_i1473880.trc

ORA-00600: internal error code, arguments: [Cursor not typechecked], [], [], [], [], [], [], [], [], [], [], []
Incident details in: /u01/app/oracle/diag/rdbms/erfsby/ERFPRD_1/incident/incdir_1473088/ERFPRD_1_ora_29318_i1473088.trc

ORA-00600: internal error code, arguments: [Cursor not typechecked], [], [], [], [], [], [], [], [], [], [], []
Incident details in: /u01/app/oracle/diag/rdbms/erfsby/ERFPRD_1/incident/incdir_1473080/ERFPRD_1_ora_64620_i1473080.trc

ORA-00600: internal error code, arguments: [Cursor not typechecked], [], [], [], [], [], [], [], [], [], [], []
Incident details in: /u01/app/oracle/diag/rdbms/erfsby/ERFPRD_1/incident/incdir_1473881/ERFPRD_1_ora_4620_i1473881.trc

ORA-00600: internal error code, arguments: [Cursor not typechecked], [], [], [], [], [], [], [], [], [], [], []
Incident details in: /u01/app/oracle/diag/rdbms/erfsby/ERFPRD_1/incident/incdir_1473081/ERFPRD_1_ora_16466_i1473081.trc

ORA-00600: internal error code, arguments: [Cursor not typechecked], [], [], [], [], [], [], [], [], [], [], []
Incident details in: /u01/app/oracle/diag/rdbms/erfsby/ERFPRD_1/incident/incdir_1473082/ERFPRD_1_ora_21483_i1473082.trc

Errors in file /u01/app/oracle/diag/rdbms/erfsby/ERFPRD_1/trace/ERFPRD_1_ora_31784.trc  (incident=1473083):
ORA-00600: internal error code, arguments: [Cursor not typechecked], [], [], [], [], [], [], [], [], [], [], []

We want to inform you that we have checked MyOracleSupport.com.
You can find information, we found in the attached file.
Thanks

==============================================================================================================================
##### MAXIMUM PROCESSES #####
==============================================================================================================================

Hello,

We received incident: 
E-IM027570793
DBSPI-0087: Current processes percentage 96.33% too high for IFCP >=95%.[Policy:DBMON-DBSPI-0087-ARM]
Node          : sv2059.logista.local

We are writing you to inform you that the database IFCP cannot receive new processes at the time, because the database hit maximum processes, which are maximum 300 processes.
oracle@sv2059 @ (/home/oracle) # sqlplus / as sysdba
SQL*Plus: Release 11.2.0.4.0 Production on Tue Feb 12 00:40:28 2019
Copyright (c) 1982, 2013, Oracle.  All rights reserved.

ERROR:
ORA-00020: maximum number of processes (300) exceeded

Case will be put in status “Pending” until further update.
Thank you.

==============================================================================================================================
###################### MAIL FOR EXTEND FILESYSTEM #############################
================================================================================================================================
To: pdl-bulgaria-south-logista-oracle@dxc.com  
CC: CM-ITO-DO-BULGARIA-ORACLE <cm-ito-do-bulgaria-oracle@dxc.com>


Hello Team,

Please be informed that we have received an incident for: [ARES_Diag] UXMON: Filesystem /oracle/ETQ/oradbf1 diskspace utilization exceeds 95 threshold. /E-IM028349335/

After our investigation we found that destination :#/oracle/ETQ/oradbf1 contains datafiles:


sv799:#/oracle/ETQ/oradbf1# bdf .
Filesystem          kbytes    used   avail %used Mounted on
/dev/vg13/lvoraetqdbf1
                   41910272 40114248 1782120   96% /oracle/ETQ/oradbf1


sv799:#/oracle/ETQ/oradbf1# find . -xdev -size +1000000c -type f -exec ls -las {} \; 2> /dev/null | sort -n | tail -2000
2064 -rw-r--r--   1 oracle     dba        1056768 May 23 17:47 ./oradata/IDX_OTHER.dbf
2064 -rw-r--r--   1 oracle     dba        1056768 May 23 17:47 ./oradata/MONOVO.dbf
16400 -rw-r--r--   1 oracle     dba        8396800 May 23 17:47 ./oradata/DATA_STATIC.dbf
16400 -rw-r--r--   1 oracle     dba        8396800 May 23 17:47 ./oradata/IDX_STATIC.dbf
116912 -rw-r--r--   1 oracle     dba        59850752 May 23 19:05 ./ctrl/1/control01.ctl
116912 -rw-r--r--   1 oracle     dba        59850752 May 23 19:05 ./ctrl/1/control03.ctl
116912 -rw-r--r--   1 oracle     dba        59850752 May 23 19:05 ./ctrl/2/control02.ctl
262160 -rw-------   1 oracle     oinstall   134225920 May 23 17:47 ./TBPSAUDIT_DATOS_01.DBF
262160 -rw-r--r--   1 oracle     dba        134225920 May 23 17:47 ./oradata/IDX_INTERFACE.dbf
307216 -rw-------   1 oracle     oinstall   157294592 May 23 17:47 ./oradata/XDB.dbf
524320 -rw-------   1 oracle     oinstall   268443648 May 23 17:58 ./oradata/HSMCRTM_INDEX_01.dbf
524320 -rw-r--r--   1 oracle     dba        268443648 May 23 17:47 ./oradata/DATA_INTERFACE.dbf
716816 -rw-r--r--   1 oracle     dba        367009792 May 23 17:47 ./oradata/IDX_OP_LOW.dbf
1048592 -rw-------   1 oracle     oinstall   536879104 May 23 17:47 ./oradata/HSMCRTM_DATA_P_02.dbf
1228832 -rw-r--r--   1 oracle     dba        629153792 May 23 19:04 ./oradata/DATA_OTHER.dbf
1441824 -rw-------   1 oracle     oinstall   738205696 May 23 17:58 ./oradata/HSMCRTM_DATA_P_01.dbf
1466400 -rw-r--r--   1 oracle     dba        750788608 May 23 19:04 ./oradata/IDX_OP_HIGH.dbf
1579040 -rw-r--r--   1 oracle     dba        808460288 May 23 17:47 ./oradata/IDX_PINCODES.dbf
1581088 -rw-r--r--   1 oracle     dba        809508864 May 23 17:47 ./oradata/DATA_SALES.dbf
2097184 -rw-r--r--   1 oracle     dba        1073750016 May 23 17:47 ./oradata/DATA_PINCODES.dbf
3145760 -rw-r--r--   1 oracle     dba        1610620928 May 23 19:05 ./oradata/system01.dbf
3541024 -rw-r--r--   1 oracle     dba        1812996096 May 23 17:47 ./oradata/IDX_SALES.dbf
4098080 -rw-r--r--   1 oracle     dba        2098208768 May 23 19:04 ./oradata/undo.dbf
4230944 -rw-r--r--   1 oracle     dba        2166235136 May 23 19:05 ./oradata/undo_02.dbf
7168032 -rw-r--r--   1 oracle     dba        3670024192 May 23 19:05 ./oradata/DATA_OP_LOW.dbf
10485792 -rw-r--r--   1 oracle     dba        5368717312 May 23 19:04 ./oradata/DATA_OP_HIGH.dbf
12288032 -rw-r--r--   1 oracle     dba        6291464192 May 23 18:53 ./oradata/users01.dbf
21706784 -rw-r--r--   1 oracle     dba        11113865216 May 23 19:05 ./oradata/sysaux01.dbf


We have triggered HWM script to shrink datafile to ensure some free space but it did not help:


sv799:#/oracle/ETQ/oradbf1# bdf .
Filesystem          kbytes    used   avail %used Mounted on
/dev/vg13/lvoraetqdbf1
                   41910272 40114248 1782120   96% /oracle/ETQ/oradbf1



Could you please consider for file system extend.

The ticket will be set in pending status and assigned to Spas Ushagelov.


Thank you in advance!


Best Regards,
Martina Naydenova

Technical Support
iAction | Oracle Database Team
+359 889 820 093 Red Phone
CM-ITO-DO-BULGARIA-ORACLE@dxc.com
Business Park Sofia, Building 9
Sofia, Bulgaria
 

==============================================================================================================================
##### EMAIL FOR PENDING FROM CONVERSATION TO SOMEONE #####
==============================================================================================================================

Hello Stefan,

As per our conversation from skype, 

We are setting the ticket (E2-IM018659379) for pending state.


Best regards,
Borislav Botev
Technical Support @ iAction | Oracle Database Team
+359 889 820 093 Red Phone
CM-ITO-DO-BULGARIA-ORACLE@dxc.com
Business Park Sofia, Building 9
Sofia, Bulgaria

==============================================================================================================================
##### PENDING #####
==============================================================================================================================

[EON][E-IM027242787][PENDING] - UC4_BUR: TSM Event: Job: 'HA ORAUNIXIN1 Redolog GKPD_SL04109' failed with RC=1. Message: UC4 RunID 1458427998, ---:ORA-01034: ORACLE not available ORA-27101: shared memory realm does not exist RMAN-03002: failure of set command at 12/20/2018 07:08:05 RMAN-06403: could not obtain a fully authorized session Instance: GKPD Date: 2018-12-20 Time: 07:08:07


Hi Team,

We received the incident:
E-IM027242787
UC4_BUR: TSM Event: Job: 'HA ORAUNIXIN1 Redolog GKPD_SL04109' failed with RC=1. Message: UC4 RunID 1458427998, ---:ORA-01034: ORACLE not available ORA-27101: shared memory realm does not exist RMAN-03002: failure of set command at 12/20/2018 07:08:05 RMAN-06403: could not obtain a fully authorized session Instance: GKPD Date: 2018-12-20 Time: 07:08:07

After our investigation, in the log we see that the database is down and the monitoring is turned off.

Could you check why the database is down, and if there is any other reason to be in this status.

Case will be put in status “Pending” until further update.

Thank you.

===========================================================================================================================
###### Sessions and Processes ######
===========================================================================================================================
###First mail ####

Hello All,
We have received an incident : E2-IM020223091
DBSPI11-03: Unable to connect to one or more databases (ora0049) configured in file local.cfg located in dbspi directory.
Node          : ruex01.rue.skf.ne

Please be informed that after our check we found that the Database ora0049 reached max number of processes. In attached file are inactive sessions. Almost all sessions are used by this user: FISCAL
At that moment new connections to the database are not possible.

RESOURCE_NAME                  CURRENT_UTILIZATION MAX_UTILIZATION INITIAL_AL LIMIT_VALU
------------------------------ ------------------- --------------- ---------- ----------
processes                                      290             297        300        300
sessions                                       300             325        600        600
transactions                                     0              33        660  UNLIMITED


Could you please check, and give us permission to kill all inactive sessions.
Thank you!

#### Second mail #####

Inactive sessions were killed in database ora0049 and now the current utilization is back to normal.
 
RESOURCE_NAME                  CURRENT_UTILIZATION MAX_UTILIZATION INITIAL_AL LIMIT_VALU
------------------------------ ------------------- --------------- ---------- ----------
processes                                       98             300        300        300
sessions                                        95             325        600        600
 
Yes it is possible to configure oracle to kill the inactive sessions for more than 1 hour, but it should be procced via change request.
 
Thank you!

=========================================================================================================================================================
##### Diskspace utilization , database filesystem ######
==========================================================================================================================================================
Hello Team,

We received another incident for such case but this time for PHYSICAL STANDBY.

Incident ID: E2-IM020222388

[ARES_Diag] UXMON: Filesystem /oracle/OVERPDG/oradata diskspace utilization exceeds 97 threshold.

Node          : derlksb0043.omc.hpccell.com

After our check we saw that /oracle/OVERPDG/oradata is use 98% :

/dev/mapper/vg_oracle_OVERPDG_oradata-lv_oracle_OVERPDG_oradata
                       12T   11T  230G  98% /oracle/OVERPDG/oradata


We tried to run HWM on primary database but it failed. Current status on the primary database filesystem  OVERP  is :

/dev/mapper/vg_oracle_OVERP_oradata-lv_oracle_OVERP_oradata
                       12T   11T  217G  99% /oracle/OVERP/oradata

We will relate the ticket to the master E2-IM020181613.
===========================================================================================================================================================
##### Razreshenie da si trygna po-rano ot rabota ######
===========================================================================================================================================================
Hello colleagues,

Due to pre-recorded medical check-ups on 24.05 and  25.05(Friday and Saturday) , I have to leave at 17:30.

Thanks for understanding! 

================================================================================================================================================================
#### Mail example for extend na SWAP or Metric value ######
================================================================================================================================================================
Hi Team,

We received the incident:

E-IM028418431 - UXMON: Filesystem /var/run diskspace utilization exceeds 93 threshold.  Check also these items:   /etc/svc/volatile /tmp
Node          : v131822-oob.vlaanderen.be

After our check:

v131822# df -h /var/run
Filesystem             size   used  avail capacity  Mounted on
swap                    51G    47G   3.5G    94%    /var/run

The SWAP device needs to be extended or metric value to be changed.
Can you please check.
The Incident is currently in status “Pending” and it will be assigned to Dimitar Getovski.
==========================================================================================================================================================
==========================================================================================================================================================



