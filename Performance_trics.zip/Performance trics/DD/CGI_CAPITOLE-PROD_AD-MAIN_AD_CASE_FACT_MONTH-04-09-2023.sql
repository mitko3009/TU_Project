/********************************************************************************
*********       E-mail subject: BQEDEV-1444
*********             Instance: PROD AD
*********          Description: 
Problem:
Problem with loading of CALC_AD_CASE_FACT_MONTH.MAIN_AD_CASE_FACT_MONTH

Analysis:
The problem was from the cursor. A full scan of table g_dossier was made thousands of times and this was very slow.

Suggestion:
Please add no_merge(L) no_push_pred(L) hints in the main select clause and no_merge no_push_pred hint in the access of table g_dossier 
as it is shown in the New SQL section below.

*********               SQL_ID: 
*********      Program/Package: CALC_AD_CASE_FACT_MONTH
*********              Request: Nikolay Nikolov
*********               Author: Dimitar Dimitrov
********* Received e-mail date: 01/09/2023
*********      Resolution date: 04/09/2023
*********  Trace old file here: \\epox\specifs\performance\tmp\
*********  Trace new file here:
***********************************************************************************/

/********************************OLD SQL*******************************************/
SELECT/*+LEADING(L GD A DB CL) FULL(GD) USE_HASH(GD) USE_HASH(A) full(P) USE_HASH(P) full(L1) USE_HASH(L1)
                      index_ffs(CL T_INTERVE_IDX2) USE_HASH(CL) no_push_pred(T) USE_HASH(T)
                      index_ffs(DB T_INTERVE_IDX2) USE_HASH(DB) USE_HASH(F) USE_HASH(VD) USE_HASH(ET) USE_HASH(EN)
                      USE_HASH(TE) USE_HASH(TE2) INDEX_FFS(V DOM_TYPABREV) USE_HASH(V)*/
                     GD.REFDOSS                  REFDOSS              ,
                     GD.ANCREFDOSS               ANCREFDOSS           ,
                     GD.DT_DT_DT                 DT_DT_DT             ,
                     GD.DTCREATION_DT            DTCREATION_DT        ,
                     GD.CATEGDOSS                CATEGDOSS            ,
                     GD.CASE_TYPE                CASE_TYPE            ,
                     GD.PIECEINIT                PIECEINIT            ,
                     GD.REFLOT_DOS               REFLOT_DOS           ,
                     GD.DEVISE                   DEVISE_DOS           ,
                     GD.DEVISE_CPT               DEVISE               ,
                     GD.RANGMT                   MANAGER_ID           ,
                     GD.DTFINGEST_DT             DTFINGEST_DT         ,
                     GD.dt_dechterm_dt           dt_dechterm_dt       ,
                     GD.NUM_VCS                  NUM_VCS              ,
                     CL.REFINDIVIDU              CLIENT_ID            ,
                     DB.REFINDIVIDU              DEBTOR_ID            ,
                     GD.RANGMT                   RANGMT               ,
                     NVL(F.EXISTS_GE_EN_DTJOUR  , 0) EXISTS_GE_EN_DTJOUR ,
                     NVL(F.EXISTS_GE_VD_DTJOUR  , 0) EXISTS_GE_VD_DTJOUR ,
                     NVL(F.EXISTS_GE_EN_DTANNUL , 0) EXISTS_GE_EN_DTANNUL,
                     NVL(F.EXISTS_GE_VD_DTANNUL , 0) EXISTS_GE_VD_DTANNUL,
                     NVL(F.EXISTS_GE_VR_DTANNUL , 0) EXISTS_GE_VR_DTANNUL,
                     NVL(F.EXISTS_GE_TP_DTANNUL , 0) EXISTS_GE_TP_DTANNUL,
                     NVL(F.EXISTS_GE_VE_DTANNUL , 0) EXISTS_GE_VE_DTANNUL,
                     NVL(F.EXISTS_EN_REFREPRES  , 0) EXISTS_EN_REFREPRES ,
                     NVL(F.EXISTS_VD_REFREPRES  , 0) EXISTS_VD_REFREPRES ,
                     NVL(F.EXISTS_GE_EN_DTENC   , 0) EXISTS_GE_EN_DTENC  ,
                     NVL(F.EXISTS_GE_VD_DTENC   , 0) EXISTS_GE_VD_DTENC  ,
                     NVL(EN.EXISTS_TE_DTANNUL   , 0) EXISTS_TE_EN_DTANNUL,
                     NVL(ET.EXISTS_TE_DTANNUL   , 0) EXISTS_TE_ET_DTANNUL,
                     NVL(VD.EXISTS_TE_DTANNUL   , 0) EXISTS_TE_VD_DTANNUL,
                     NVL(T.EXISTS_T_ENGAG       , 0) EXISTS_T_ENGAG      ,
                     NVL(TE.EXISTS_ECRDOS       , 0) EXISTS_ECRDOS       ,
                     NVL(TE2.EXISTS_ECRDOS2     , 0) EXISTS_ECRDOS2
                FROM G_DOSSIER         GD,
                     T_INTERVENANTS    CL,
                     T_INTERVENANTS    DB,
                     ( SELECT/*+LEADING(E) USE_HASH(TE)*/
                              MAX(CASE WHEN DTJOUR    = 1 AND typeelem = 'en' AND libelle LIKE 'Delai avant%' THEN 1 ELSE 0 END) AS EXISTS_GE_EN_DTJOUR ,
                              MAX(CASE WHEN DTJOUR    = 1 AND typeelem = 'vd' AND libelle LIKE 'Delai avant%' THEN 1 ELSE 0 END) AS EXISTS_GE_VD_DTJOUR ,
                              MAX(CASE WHEN DTANNUL   = 1 AND typeelem = 'en'                                 THEN 1 ELSE 0 END) AS EXISTS_GE_EN_DTANNUL, 
                              MAX(CASE WHEN DTANNUL   = 1 AND typeelem = 'vd'                                 THEN 1 ELSE 0 END) AS EXISTS_GE_VD_DTANNUL,
                              MAX(CASE WHEN DTANNUL   = 1 AND typeelem = 'vr'                                 THEN 1 ELSE 0 END) AS EXISTS_GE_VR_DTANNUL,   
                              MAX(CASE WHEN DTANNUL   = 1 AND typeelem = 'tp'                                 THEN 1 ELSE 0 END) AS EXISTS_GE_TP_DTANNUL,   
                              MAX(CASE WHEN DTANNUL   = 1 AND typeelem = 've'                                 THEN 1 ELSE 0 END) AS EXISTS_GE_VE_DTANNUL, 
                              MAX(CASE WHEN DTENCAISS = 1 AND typeelem = 'en'                                 THEN 1 ELSE 0 END) AS EXISTS_GE_EN_DTENC  , 
                              MAX(CASE WHEN DTENCAISS = 1 AND typeelem = 'vd'                                 THEN 1 ELSE 0 END) AS EXISTS_GE_VD_DTENC  , 
                              MAX(CASE WHEN REFREPRES = 1 AND typeelem = 'en'                                 THEN 1 ELSE 0 END) AS EXISTS_EN_REFREPRES ,
                              MAX(CASE WHEN REFREPRES = 1 AND typeelem = 'vd'                                 THEN 1 ELSE 0 END) AS EXISTS_VD_REFREPRES ,
                              TE.REFDOSS  
                         FROM ( SELECT/*+INDEX_FFS(T_ELEMENTS_EN T_ELEMENTS_EN_RTRLAM_IDX)*/ 
                                       refelem, 'en' AS typeelem, libelle, refdoss
                                  FROM T_ELEMENTS_EN
                                 WHERE typeelem = 'en'
                                   AND ORA_HASH(refdoss, 4-1) = 0
                                 UNION ALL
                                SELECT/*+INDEX_FFS(T_ELEMENTS_VD T_ELEMENTS_VD_RTRLAM_IDX)*/ 
                                       refelem, 'vd' AS typeelem, libelle, refdoss
                                  FROM T_ELEMENTS_VD
                                 WHERE typeelem = 'vd'
                                   AND ORA_HASH(refdoss, 4-1) = 0
                                 UNION ALL
                                SELECT/*+INDEX_FFS(T_ELEMENTS_VR T_ELEMENTS_VR_RTRLAM_IDX)*/ 
                                       refelem, 'vr' AS typeelem, NULL AS libelle, refdoss
                                  FROM T_ELEMENTS_VR
                                 WHERE typeelem = 'an'
                                   AND abrev = 'vr'
                                   AND ORA_HASH(refdoss, 4-1) = 0
                                 UNION ALL
                                SELECT/*+INDEX_FFS(T_ELEMENTS_TP T_ELEMENTS_TP_RTRLAM_IDX)*/ 
                                       refelem, 'tp'  AS typeelem, NULL AS libelle, refdoss
                                  FROM T_ELEMENTS_TP
                                 WHERE typeelem = 'an'
                                   AND abrev = 'tp'
                                   AND ORA_HASH(refdoss, 4-1) = 0
                                 UNION ALL
                                SELECT/*+INDEX_FFS(T_ELEMENTS_VE T_ELEMENTS_VE_RTRLAM_IDX)*/ 
                                       refelem, 've' AS typeelem, NULL AS libelle, refdoss
                                  FROM T_ELEMENTS_VE
                                 WHERE typeelem = 'an'
                                   AND abrev = 've'
                                   AND ORA_HASH(refdoss, 4-1) = 0
                              ) TE,
                              ( SELECT/*+INDEX(G G_ENCAISSEMENT_DTJOUR_IDX)*/ 
                                       refencaiss AS REFENCAISS,
                                       1          AS DTJOUR    ,
                                       0          AS DTANNUL   ,
                                       0          AS DTENCAISS , 
                                       0          AS REFREPRES
                                  FROM G_ENCAISSEMENT G
                                 WHERE dtjour BETWEEN to_char(to_date('01/08/2023', 'dd/mm/yyyy'), 'J') AND to_char(to_date('31/08/2023', 'dd/mm/yyyy'), 'J')
                             UNION ALL
                             SELECT/*+INDEX(G IDX_ENCAISS_FFS)*/ 
                                       refencaiss AS REFENCAISS,
                                       0          AS DTJOUR    ,
                                       1           AS DTANNUL   ,
                                       0          AS DTENCAISS , 
                                       0          AS REFREPRES
                                  FROM G_ENCAISSEMENT G
                                 WHERE dtannul BETWEEN to_char(to_date('01/08/2023', 'dd/mm/yyyy'), 'J') AND to_char(to_date('31/08/2023', 'dd/mm/yyyy'), 'J')
                             UNION ALL
                                SELECT/*+INDEX_FFS(G G_ENCAISSEMENT_IDX1)*/ 
                                       refencaiss AS REFENCAISS,
                                       0          AS DTJOUR    ,
                                       0          AS DTANNUL   ,
                                       1          AS DTENCAISS ,
                                       0          AS REFREPRES
                                  FROM G_ENCAISSEMENT G
                                 WHERE DTENCAISS BETWEEN to_char(to_date('01/08/2023', 'dd/mm/yyyy'), 'J') AND to_char(to_date('31/08/2023', 'dd/mm/yyyy'), 'J')
                             UNION ALL
                                SELECT/*+INDEX(G G_ENCAISSEMENT_REFREPRES)*/ 
                                       REFENCAISS AS REFENCAISS,
                                       0          AS DTJOUR    ,
                                       0          AS DTANNUL   ,
                                       0          AS DTENCAISS ,
                                       1          AS REFREPRES
                                  FROM G_ENCAISSEMENT G
                                 WHERE REFREPRES IS NOT NULL
                              ) E
                        WHERE TE.refelem = E.refencaiss
                     GROUP BY TE.refdoss
                     ) F,
                     ( SELECT/*+INDEX(TP T_ELEMENTS_VD_DTANNUL_IDX)*/ 
                              MAX(1) EXISTS_TE_DTANNUL,
                              refdoss
                         FROM T_ELEMENTS_VD TP
                        WHERE typeelem = 'an'
                          AND abrev = 'vd'
                          AND dtannul IS NOT NULL
                          AND dtannul BETWEEN to_char(to_date('01/08/2023', 'dd/mm/yyyy'), 'J') AND to_char(to_date('31/08/2023', 'dd/mm/yyyy'), 'J')
                          AND ORA_HASH(refdoss, 4-1) = 0
                     GROUP BY refdoss
                     ) VD,
                     ( SELECT/*+INDEX(TP T_ELEMENTS_ET_DTANNUL_IDX)*/ 
                              MAX(1) EXISTS_TE_DTANNUL,
                              refdoss
                         FROM T_ELEMENTS_ET TP
                        WHERE typeelem = 'an'
                          AND abrev = 'et'
                          AND dtannul IS NOT NULL
                          AND dtannul BETWEEN to_char(to_date('01/08/2023', 'dd/mm/yyyy'), 'J') AND to_char(to_date('31/08/2023', 'dd/mm/yyyy'), 'J')
                          AND ORA_HASH(refdoss, 4-1) = 0
                     GROUP BY refdoss
                     ) ET,
                     ( SELECT/*+INDEX(TP T_ELEMENTS_EN_DTANNUL_IDX)*/ 
                              MAX(1) EXISTS_TE_DTANNUL,
                              refdoss
                         FROM T_ELEMENTS_EN TP
                        WHERE typeelem = 'an'
                          AND abrev = 'en'
                          AND dtannul IS NOT NULL
                          AND dtannul BETWEEN to_char(to_date('01/08/2023', 'dd/mm/yyyy'), 'J') AND to_char(to_date('31/08/2023', 'dd/mm/yyyy'), 'J')
                          AND ORA_HASH(refdoss, 4-1) = 0
                     GROUP BY refdoss
                     ) EN,
                     ( SELECT/*+INDEX(G G_T_ENGAGEMENT_USER_DATE_IDX)*/
                              MAX(1) EXISTS_T_ENGAG,
                              refdoss
                         FROM G_T_ENGAGEMENT G
                        WHERE user_date >= TO_DATE(to_char(to_date('01/08/2023', 'dd/mm/yyyy'), 'J'), 'J')
                          AND user_date < TO_DATE(to_char(to_date('31/08/2023', 'dd/mm/yyyy'), 'J'), 'J')+1
                          AND ORA_HASH(G.refdoss, 4-1) = 0
                     GROUP BY refdoss
                     )T,
                     ( SELECT/*+INDEX(M AD_T_ECRDOS_DTJOUR_IDX)*/ 
                              COUNT(*) EXISTS_ECRDOS,
                              refdoss
                         FROM AD_T_ECRDOS_MVIEW M
                        WHERE dtjour BETWEEN to_char(to_date('01/08/2023', 'dd/mm/yyyy'), 'J') AND to_char(to_date('31/08/2023', 'dd/mm/yyyy'), 'J')
                          AND SOMME  = 'SOLDEDB'
                          AND ORA_HASH(M.refdoss, 4-1) = 0
                     GROUP BY refdoss
                     ) TE,
                     ( SELECT/*+INDEX(T2 IDX_DTJOUR_ECRDOS)*/  
                              COUNT(*) EXISTS_ECRDOS2,
                              refdoss
                         FROM t_ecrdos T2
                        WHERE dtjour  BETWEEN to_char(to_date('01/08/2023', 'dd/mm/yyyy'), 'J') AND to_char(to_date('31/08/2023', 'dd/mm/yyyy'), 'J')
                           AND codecr IN ('DBET' , 'DBCL' , 'VIENC', 'CLDB' , 'ETDB' ,
                                          'PRIN' , 'DEBE' , 'HONOR', 'DPDB' , 'ACTE' ,
                                          'DBERH', 'APRIN', 'ADEBE', 'AHONO', 'ADPDB',
                                          'AACTE', 'ADBER')
                           AND ORA_HASH(T2.refdoss, 4-1) = 0
                     GROUP BY refdoss
                     ) TE2,
                     ( SELECT/*+FULL(G) */ 
                              refdoss
                         FROM g_dossier G
                        WHERE dtstratif <= to_char(to_date('31/08/2023', 'dd/mm/yyyy'), 'J')
                          AND NVL(to_char(G.DTCREATION_DT, 'J'), G.DT_DT)  <= to_char(to_date('31/08/2023', 'dd/mm/yyyy'), 'J')
                          AND ';' NOT LIKE '%;'||stratif||';%'
                          AND ORA_HASH(G.refdoss, 4-1) = 0
                    UNION ALL
                       SELECT refdoss
                         FROM ( SELECT/*+FULL(G) LEADING(G)*/ 
                                       C.refdoss,
                                       C.nom,
                                       ROW_NUMBER() OVER(PARTITION BY C.refdoss ORDER BY DTASSOC_DT DESC NULLS LAST) AS rnk
                                  FROM t_elements_ce C,
                                       g_dossier        G
                                 WHERE NVL(to_char(G.DTCREATION_DT, 'J'), G.DT_DT) <= to_char(to_date('31/08/2023', 'dd/mm/yyyy'), 'J')
                                   AND G.dtstratif > to_char(to_date('31/08/2023', 'dd/mm/yyyy'), 'J')
                                   AND C.refdoss = G.refdoss
                                   AND C.dtassoc <= to_char(to_date('31/08/2023', 'dd/mm/yyyy'), 'J')
                                   AND (   C.dtlimite IS NULL 
                                        OR C.dtlimite >= to_char(to_date('31/08/2023', 'dd/mm/yyyy'), 'J') )
                                   AND ORA_HASH(G.refdoss, 4-1) = 0
                              ) N
                        WHERE N.rnk = 1
                          AND (   ';' NOT LIKE '%;'||N.nom||';%'
                               OR (    1 = 1
                                   AND ';' LIKE '%;'||N.nom||';%'
                                   AND EXISTS ( SELECT 1
                                                  FROM t_elements_ce O
                                                 WHERE O.refdoss = N.refdoss
                                                   AND ';' NOT LIKE '%;'||O.nom||';%'
                                                   AND O.dtassoc <= to_char(to_date('31/08/2023', 'dd/mm/yyyy'), 'J')
                                                   AND O.dtlimite >= to_char(to_date('01/08/2023', 'dd/mm/yyyy'), 'J')
                                                   AND O.dtlimite <= to_char(to_date('31/08/2023', 'dd/mm/yyyy'), 'J')
                                              )
                                  ) 
                              )
                     ) L,
                     ( SELECT/*+FULL(TEMP_AD_CF_LOADED_ROWS)*/ 
                              refdoss                                                 AS refdoss,
                              MAX(CASE WHEN agregation_type = 1 THEN 1 ELSE NULL END) AS daily  ,
                              MAX(CASE WHEN agregation_type = 2 THEN 1 ELSE NULL END) AS monthly
                         FROM TEMP_AD_CF_LOADED_ROWS
                     GROUP BY refdoss
                     ) A,
                     V_DOMAINE V
               WHERE GD.refdoss = L.refdoss
                 AND GD.REFDOSS = CL.REFDOSS
                 AND CL.REFTYPE = 'CL'
                 AND ORA_HASH(CL.refdoss, 4-1) = 0
                 AND GD.REFDOSS = DB.REFDOSS
                 AND DB.REFTYPE = 'DB'
                 AND ORA_HASH(DB.refdoss, 4-1) = 0
                 AND nvl(to_char(GD.DTCREATION_DT,'J'),GD.DT_DT)<= to_char(to_date('31/08/2023', 'dd/mm/yyyy'), 'J')
                 AND GD.CATEGDOSS = V.VALEUR
                 AND V.TYPE  = 'categdoss'
                 AND A.refdoss(+) = GD.refdoss
                 AND (   (    1 = 0 
                          AND A.daily IS NULL )
                      OR (    1 = 1
                          AND A.monthly IS NULL )
                     )
                 AND F.refdoss(+) = GD.refdoss
                 AND EN.refdoss(+) = GD.refdoss
                 AND VD.refdoss(+) = GD.refdoss
                 AND ET.refdoss(+) = GD.refdoss
                 AND T.refdoss(+) = GD.refdoss
                 AND TE.refdoss(+) = GD.refdoss
                 AND TE2.refdoss(+) = GD.refdoss
                 AND ORA_HASH(gd.refdoss, 4-1) = 0;
/********************************OLD SQL*******************************************/
/********************************OLD Metrics***************************************/
/*
Plan hash value: 3696266547
----------------------------------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                             | Name                         | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  |
----------------------------------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                                      |                              |      1 |        | 99020 (100)|      0 |00:00:00.01 |       0 |      0 |
|*  1 |  HASH JOIN OUTER                                      |                              |      1 |      1 | 99020   (1)|      0 |00:00:00.01 |       0 |      0 |
|   2 |   JOIN FILTER CREATE                                  | :BF0000                      |      1 |      1 | 93126   (1)|      0 |00:00:00.01 |       0 |      0 |
|*  3 |    HASH JOIN OUTER                                    |                              |      1 |      1 | 93126   (1)|      0 |00:00:00.01 |       0 |      0 |
|   4 |     JOIN FILTER CREATE                                | :BF0001                      |      1 |      1 | 61481   (1)|      0 |00:00:00.01 |       0 |      0 |
|*  5 |      HASH JOIN                                        |                              |      1 |      1 | 61481   (1)|      0 |00:00:00.01 |       0 |      0 |
|*  6 |       HASH JOIN                                       |                              |      1 |      1 | 60397   (1)|      0 |00:00:00.01 |       0 |      0 |
|*  7 |        HASH JOIN OUTER                                |                              |      1 |      1 | 59314   (1)|      0 |00:00:00.01 |       0 |      0 |
|   8 |         JOIN FILTER CREATE                            | :BF0002                      |      1 |      1 |  7178   (1)|      0 |00:00:00.01 |       0 |      0 |
|*  9 |          HASH JOIN OUTER                              |                              |      1 |      1 |  7178   (1)|      0 |00:00:00.01 |       0 |      0 |
|  10 |           JOIN FILTER CREATE                          | :BF0003                      |      1 |      1 |  6749   (1)|  10486 |00:31:59.45 |     159M|    142M|
|  11 |            NESTED LOOPS                               |                              |      1 |      1 |  6749   (1)|  10486 |00:31:59.42 |     159M|    142M|
|* 12 |             FILTER                                    |                              |      1 |        |            |  10486 |00:00:00.31 |    7746 |   7736 |
|* 13 |              HASH JOIN OUTER                          |                              |      1 |      1 |  2285   (1)|  10486 |00:00:00.29 |    7746 |   7736 |
|* 14 |               HASH JOIN OUTER                         |                              |      1 |      1 |  2282   (1)|  49999 |00:00:00.23 |    7746 |   7736 |
|* 15 |                HASH JOIN OUTER                        |                              |      1 |      1 |  2273   (1)|  49999 |00:00:00.20 |    7737 |   7727 |
|* 16 |                 HASH JOIN OUTER                       |                              |      1 |      1 |  2266   (1)|  49999 |00:00:00.17 |    7733 |   7723 |
|* 17 |                  HASH JOIN                            |                              |      1 |      1 |  2263   (1)|  49999 |00:00:00.14 |    7732 |   7722 |
|* 18 |                   INDEX FAST FULL SCAN                | DOM_TYPABREV                 |      1 |     22 |    32   (0)|     22 |00:00:00.01 |     128 |    122 |
|* 19 |                   TABLE ACCESS FULL                   | G_DOSSIER                    |      1 |     99 |  2231   (1)|  49999 |00:00:00.12 |    7604 |   7600 |
|  20 |                  VIEW                                 |                              |      1 |      1 |     3  (34)|      0 |00:00:00.01 |       1 |      1 |
|  21 |                   HASH GROUP BY                       |                              |      1 |      1 |     3  (34)|      0 |00:00:00.01 |       1 |      1 |
|* 22 |                    TABLE ACCESS BY INDEX ROWID BATCHED| T_ELEMENTS_VD                |      1 |      1 |     2   (0)|      0 |00:00:00.01 |       1 |      1 |
|* 23 |                     INDEX RANGE SCAN                  | T_ELEMENTS_VD_DTANNUL_IDX    |      1 |      1 |     1   (0)|      0 |00:00:00.01 |       1 |      1 |
|  24 |                 VIEW                                  |                              |      1 |      1 |     7  (15)|      2 |00:00:00.01 |       4 |      4 |
|  25 |                  HASH GROUP BY                        |                              |      1 |      1 |     7  (15)|      2 |00:00:00.01 |       4 |      4 |
|* 26 |                   TABLE ACCESS BY INDEX ROWID BATCHED | T_ELEMENTS_ET                |      1 |      1 |     6   (0)|      2 |00:00:00.01 |       4 |      4 |
|* 27 |                    INDEX RANGE SCAN                   | T_ELEMENTS_ET_DTANNUL_IDX    |      1 |      5 |     1   (0)|      8 |00:00:00.01 |       1 |      1 |
|  28 |                VIEW                                   |                              |      1 |      1 |     9  (12)|      1 |00:00:00.01 |       9 |      9 |
|  29 |                 HASH GROUP BY                         |                              |      1 |      1 |     9  (12)|      1 |00:00:00.01 |       9 |      9 |
|* 30 |                  TABLE ACCESS BY INDEX ROWID BATCHED  | T_ELEMENTS_EN                |      1 |      1 |     8   (0)|      1 |00:00:00.01 |       9 |      9 |
|* 31 |                   INDEX RANGE SCAN                    | T_ELEMENTS_EN_DTANNUL_IDX    |      1 |     11 |     1   (0)|     12 |00:00:00.01 |       1 |      1 |
|  32 |               VIEW                                    |                              |      1 |      1 |     3  (34)|      0 |00:00:00.01 |       0 |      0 |
|  33 |                HASH GROUP BY                          |                              |      1 |      1 |     3  (34)|      0 |00:00:00.01 |       0 |      0 |
|  34 |                 TABLE ACCESS FULL                     | TEMP_AD_CF_LOADED_ROWS       |      1 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|  35 |             VIEW                                      |                              |  10486 |      1 |  4463   (1)|  10486 |00:31:59.22 |     159M|    142M|
|  36 |              UNION ALL PUSHED PREDICATE               |                              |  10486 |        |            |  10486 |00:31:59.20 |     159M|    142M|
|* 37 |               TABLE ACCESS FULL                       | G_DOSSIER                    |  10486 |      1 |  2230   (1)|  10428 |00:16:06.04 |      79M|     71M|
|* 38 |               FILTER                                  |                              |  10485 |        |            |     58 |00:15:53.00 |      79M|     71M|
|* 39 |                VIEW                                   |                              |  10485 |      1 |  2234   (1)|     58 |00:15:52.98 |      79M|     71M|
|* 40 |                 WINDOW SORT PUSHED RANK               |                              |  10485 |      1 |  2234   (1)|     58 |00:15:52.96 |      79M|     71M|
|  41 |                  NESTED LOOPS                         |                              |  10485 |      1 |  2233   (1)|     58 |00:15:52.79 |      79M|     71M|
|  42 |                   NESTED LOOPS                        |                              |  10485 |      1 |  2233   (1)|     58 |00:15:52.75 |      79M|     71M|
|* 43 |                    TABLE ACCESS FULL                  | G_DOSSIER                    |  10485 |      1 |  2230   (1)|     58 |00:15:52.63 |      79M|     71M|
|* 44 |                    INDEX RANGE SCAN                   | T_ELEMENTS_CE_RTDTAS_IDX     |     58 |      1 |     2   (0)|     58 |00:00:00.10 |     174 |     55 |
|* 45 |                   TABLE ACCESS BY INDEX ROWID         | T_ELEMENTS_CE                |     58 |      1 |     3   (0)|     58 |00:00:00.02 |      58 |     47 |
|* 46 |                TABLE ACCESS BY INDEX ROWID BATCHED    | T_ELEMENTS_CE                |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 47 |                 INDEX RANGE SCAN                      | T_ELEMENTS_CE_RTDTAS_IDX     |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|  48 |           VIEW                                        |                              |      0 |     49 |   429   (1)|      0 |00:00:00.01 |       0 |      0 |
|  49 |            HASH GROUP BY                              |                              |      0 |     49 |   429   (1)|      0 |00:00:00.01 |       0 |      0 |
|  50 |             JOIN FILTER USE                           | :BF0003                      |      0 |     49 |   428   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 51 |              TABLE ACCESS BY INDEX ROWID BATCHED      | G_T_ENGAGEMENT               |      0 |     49 |   428   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 52 |               INDEX RANGE SCAN                        | G_T_ENGAGEMENT_USER_DATE_IDX |      0 |   4900 |    11   (0)|      0 |00:00:00.01 |       0 |      0 |
|  53 |         VIEW                                          |                              |      0 |   1430 | 52136   (1)|      0 |00:00:00.01 |       0 |      0 |
|  54 |          HASH GROUP BY                                |                              |      0 |   1430 | 52136   (1)|      0 |00:00:00.01 |       0 |      0 |
|  55 |           JOIN FILTER USE                             | :BF0002                      |      0 |   1435 | 52135   (1)|      0 |00:00:00.01 |       0 |      0 |
|* 56 |            MAT_VIEW ACCESS BY INDEX ROWID BATCHED     | AD_T_ECRDOS_MVIEW            |      0 |   1435 | 52135   (1)|      0 |00:00:00.01 |       0 |      0 |
|* 57 |             INDEX RANGE SCAN                          | AD_T_ECRDOS_DTJOUR_IDX       |      0 |    481K|   577   (1)|      0 |00:00:00.01 |       0 |      0 |
|* 58 |        INDEX FAST FULL SCAN                           | T_INTERVE_IDX2               |      0 |   1974 |  1083   (1)|      0 |00:00:00.01 |       0 |      0 |
|* 59 |       INDEX FAST FULL SCAN                            | T_INTERVE_IDX2               |      0 |   1974 |  1083   (1)|      0 |00:00:00.01 |       0 |      0 |
|  60 |     VIEW                                              |                              |      0 |   2951 | 31645   (1)|      0 |00:00:00.01 |       0 |      0 |
|  61 |      HASH GROUP BY                                    |                              |      0 |   2951 | 31645   (1)|      0 |00:00:00.01 |       0 |      0 |
|  62 |       JOIN FILTER USE                                 | :BF0001                      |      0 |   2973 | 31644   (1)|      0 |00:00:00.01 |       0 |      0 |
|* 63 |        TABLE ACCESS BY INDEX ROWID BATCHED            | T_ECRDOS                     |      0 |   2973 | 31644   (1)|      0 |00:00:00.01 |       0 |      0 |
|* 64 |         INDEX RANGE SCAN                              | IDX_DTJOUR_ECRDOS            |      0 |    297K|  1145   (2)|      0 |00:00:00.01 |       0 |      0 |
|  65 |   VIEW                                                |                              |      0 |   6079 |  5894   (1)|      0 |00:00:00.01 |       0 |      0 |
|  66 |    HASH GROUP BY                                      |                              |      0 |   6079 |  5894   (1)|      0 |00:00:00.01 |       0 |      0 |
|  67 |     JOIN FILTER USE                                   | :BF0000                      |      0 |  11428 |  5595   (1)|      0 |00:00:00.01 |       0 |      0 |
|* 68 |      HASH JOIN                                        |                              |      0 |  11428 |  5595   (1)|      0 |00:00:00.01 |       0 |      0 |
|  69 |       VIEW                                            |                              |      0 |  81151 |  4067   (1)|      0 |00:00:00.01 |       0 |      0 |
|  70 |        UNION-ALL                                      |                              |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  71 |         TABLE ACCESS BY INDEX ROWID BATCHED           | G_ENCAISSEMENT               |      0 |  44418 |   942   (1)|      0 |00:00:00.01 |       0 |      0 |
|* 72 |          INDEX RANGE SCAN                             | G_ENCAISSEMENT_DTJOUR_IDX    |      0 |  44418 |    76   (0)|      0 |00:00:00.01 |       0 |      0 |
|  73 |         TABLE ACCESS BY INDEX ROWID BATCHED           | G_ENCAISSEMENT               |      0 |     14 |    10   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 74 |          INDEX SKIP SCAN                              | G_ENCAISSEMENT_REFPIECE_IDX  |      0 |     14 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 75 |         TABLE ACCESS FULL                             | G_ENCAISSEMENT               |      0 |  36718 |  3115   (1)|      0 |00:00:00.01 |       0 |      0 |
|  76 |         TABLE ACCESS BY INDEX ROWID BATCHED           | G_ENCAISSEMENT               |      0 |      1 |     0   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 77 |          INDEX FULL SCAN                              | G_ENCAISSEMENT_REFREPRES     |      0 |      1 |     0   (0)|      0 |00:00:00.01 |       0 |      0 |
|  78 |       VIEW                                            |                              |      0 |   6255 |  1354   (1)|      0 |00:00:00.01 |       0 |      0 |
|  79 |        UNION-ALL                                      |                              |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|* 80 |         INDEX FAST FULL SCAN                          | T_ELEMENTS_EN_RTRLAM_IDX     |      0 |     90 |    18   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 81 |         INDEX FAST FULL SCAN                          | T_ELEMENTS_VD_RTRLAM_IDX     |      0 |   6162 |  1330   (1)|      0 |00:00:00.01 |       0 |      0 |
|* 82 |         INDEX FAST FULL SCAN                          | T_ELEMENTS_VR_RTRLAM_IDX     |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 83 |         INDEX FAST FULL SCAN                          | T_ELEMENTS_TP_RTRLAM_IDX     |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 84 |         INDEX FAST FULL SCAN                          | T_ELEMENTS_VE_RTRLAM_IDX     |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
----------------------------------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   1 - access("F"."REFDOSS"="GD"."REFDOSS")
   3 - access("TE2"."REFDOSS"="GD"."REFDOSS")
   5 - access("GD"."REFDOSS"="DB"."REFDOSS")
   6 - access("GD"."REFDOSS"="CL"."REFDOSS")
   7 - access("TE"."REFDOSS"="GD"."REFDOSS")
   9 - access("T"."REFDOSS"="GD"."REFDOSS")
  12 - filter("A"."MONTHLY" IS NULL)
  13 - access("A"."REFDOSS"="GD"."REFDOSS")
  14 - access("EN"."REFDOSS"="GD"."REFDOSS")
  15 - access("ET"."REFDOSS"="GD"."REFDOSS")
  16 - access("VD"."REFDOSS"="GD"."REFDOSS")
  17 - access("GD"."CATEGDOSS"="V"."VALEUR")
  18 - filter("V"."TYPE"='categdoss')
  19 - filter((ORA_HASH("GD"."REFDOSS",3)=0 AND NVL(TO_CHAR(INTERNAL_FUNCTION("GD"."DTCREATION_DT"),'j'),TO_CHAR("GD"."DT_DT"))<='2460188'))
  22 - filter(("TYPEELEM"='an' AND "ABREV"='vd' AND ORA_HASH("REFDOSS",3)=0))
  23 - access("DTANNUL">=2460158 AND "DTANNUL"<=2460188)
  26 - filter(("ABREV"='et' AND "TYPEELEM"='an' AND ORA_HASH("REFDOSS",3)=0))
  27 - access("DTANNUL">=2460158 AND "DTANNUL"<=2460188)
  30 - filter(("TYPEELEM"='an' AND ORA_HASH("REFDOSS",3)=0 AND "ABREV"='en'))
  31 - access("DTANNUL">=2460158 AND "DTANNUL"<=2460188)
  37 - filter(("REFDOSS"="GD"."REFDOSS" AND ORA_HASH("G"."REFDOSS",3)=0 AND ';' NOT LIKE '%;'||"STRATIF"||';%' AND
              NVL(TO_CHAR(INTERNAL_FUNCTION("G"."DTCREATION_DT"),'j'),TO_CHAR("G"."DT_DT"))<='2460188' AND "DTSTRATIF"<=2460188))
  38 - filter((';' NOT LIKE '%;'||"N"."NOM"||';%' OR (';' LIKE '%;'||"N"."NOM"||';%' AND  IS NOT NULL)))
  39 - filter("N"."RNK"=1)
  40 - filter(ROW_NUMBER() OVER ( PARTITION BY "C"."REFDOSS" ORDER BY INTERNAL_FUNCTION("DTASSOC_DT") DESC  NULLS LAST)<=1)
  43 - filter(("G"."DTSTRATIF">2460188 AND "G"."REFDOSS"="GD"."REFDOSS" AND ORA_HASH("G"."REFDOSS",3)=0 AND
              NVL(TO_CHAR(INTERNAL_FUNCTION("G"."DTCREATION_DT"),'j'),TO_CHAR("G"."DT_DT"))<='2460188'))
  44 - access("C"."REFDOSS"="GD"."REFDOSS" AND "C"."DTASSOC"<=2460188)
       filter("C"."REFDOSS"="G"."REFDOSS")
  45 - filter(("C"."DTLIMITE" IS NULL OR "C"."DTLIMITE">=2460188))
  46 - filter(';' NOT LIKE '%;'||"O"."NOM"||';%')
  47 - access("O"."REFDOSS"=:B1 AND "O"."DTLIMITE">=2460158 AND "O"."DTASSOC"<=2460188 AND "O"."DTLIMITE"<=2460188)
       filter(("O"."DTLIMITE">=2460158 AND "O"."DTLIMITE"<=2460188))
  51 - filter(ORA_HASH("G"."REFDOSS",3)=0)
  52 - access("USER_DATE">=TO_DATE(' 2023-08-01 00:00:00', 'syyyy-mm-dd hh24:mi:ss') AND "USER_DATE"<TO_DATE(' 2023-09-01 00:00:00', 'syyyy-mm-dd
              hh24:mi:ss'))
  56 - filter(("SOMME"='SOLDEDB' AND ORA_HASH("M"."REFDOSS",3)=0))
  57 - access("DTJOUR">=2460158 AND "DTJOUR"<=2460188)
  58 - filter(("CL"."REFTYPE"='CL' AND ORA_HASH("CL"."REFDOSS",3)=0))
  59 - filter(("DB"."REFTYPE"='DB' AND ORA_HASH("DB"."REFDOSS",3)=0))
  63 - filter(ORA_HASH("T2"."REFDOSS",3)=0)
  64 - access("DTJOUR">=2460158 AND "DTJOUR"<=2460188)
       filter(("CODECR"='AACTE' OR "CODECR"='ACTE' OR "CODECR"='ADBER' OR "CODECR"='ADEBE' OR "CODECR"='ADPDB' OR "CODECR"='AHONO' OR "CODECR"='APRIN' OR
              "CODECR"='CLDB' OR "CODECR"='DBCL' OR "CODECR"='DBERH' OR "CODECR"='DBET' OR "CODECR"='DEBE' OR "CODECR"='DPDB' OR "CODECR"='ETDB' OR "CODECR"='HONOR' OR
              "CODECR"='PRIN' OR "CODECR"='VIENC'))
  68 - access("TE"."REFELEM"="E"."REFENCAISS")
  72 - access("DTJOUR">=2460158 AND "DTJOUR"<=2460188)
  74 - access("DTANNUL">=2460158 AND "DTANNUL"<=2460188)
       filter(("DTANNUL">=2460158 AND "DTANNUL"<=2460188))
  75 - filter(("DTENCAISS">=2460158 AND "DTENCAISS"<=2460188))
  77 - filter("REFREPRES" IS NOT NULL)
  80 - filter((ORA_HASH("REFDOSS",3)=0 AND "TYPEELEM"='en'))
  81 - filter((ORA_HASH("REFDOSS",3)=0 AND "TYPEELEM"='vd'))
  82 - filter(("TYPEELEM"='an' AND "ABREV"='vr' AND ORA_HASH("REFDOSS",3)=0))
  83 - filter(("TYPEELEM"='an' AND "ABREV"='tp' AND ORA_HASH("REFDOSS",3)=0))
  84 - filter(("ABREV"='ve' AND "TYPEELEM"='an' AND ORA_HASH("REFDOSS",3)=0))
*/
/********************************OLD Metrics***************************************/

/********************************New SQL*******************************************/

SELECT/*+LEADING(L GD A DB CL) FULL(GD) USE_HASH(GD) USE_HASH(A) full(P) USE_HASH(P) full(L1) USE_HASH(L1)
                      index_ffs(CL T_INTERVE_IDX2) USE_HASH(CL) no_push_pred(T) USE_HASH(T)
                      index_ffs(DB T_INTERVE_IDX2) USE_HASH(DB) USE_HASH(F) USE_HASH(VD) USE_HASH(ET) USE_HASH(EN)
                      USE_HASH(TE) USE_HASH(TE2) INDEX_FFS(V DOM_TYPABREV) USE_HASH(V) no_merge(L) no_push_pred(L)*/
                     GD.REFDOSS                  REFDOSS              ,
                     GD.ANCREFDOSS               ANCREFDOSS           ,
                     GD.DT_DT_DT                 DT_DT_DT             ,
                     GD.DTCREATION_DT            DTCREATION_DT        ,
                     GD.CATEGDOSS                CATEGDOSS            ,
                     GD.CASE_TYPE                CASE_TYPE            ,
                     GD.PIECEINIT                PIECEINIT            ,
                     GD.REFLOT_DOS               REFLOT_DOS           ,
                     GD.DEVISE                   DEVISE_DOS           ,
                     GD.DEVISE_CPT               DEVISE               ,
                     GD.RANGMT                   MANAGER_ID           ,
                     GD.DTFINGEST_DT             DTFINGEST_DT         ,
                     GD.dt_dechterm_dt           dt_dechterm_dt       ,
                     GD.NUM_VCS                  NUM_VCS              ,
                     CL.REFINDIVIDU              CLIENT_ID            ,
                     DB.REFINDIVIDU              DEBTOR_ID            ,
                     GD.RANGMT                   RANGMT               ,
                     NVL(F.EXISTS_GE_EN_DTJOUR  , 0) EXISTS_GE_EN_DTJOUR ,
                     NVL(F.EXISTS_GE_VD_DTJOUR  , 0) EXISTS_GE_VD_DTJOUR ,
                     NVL(F.EXISTS_GE_EN_DTANNUL , 0) EXISTS_GE_EN_DTANNUL,
                     NVL(F.EXISTS_GE_VD_DTANNUL , 0) EXISTS_GE_VD_DTANNUL,
                     NVL(F.EXISTS_GE_VR_DTANNUL , 0) EXISTS_GE_VR_DTANNUL,
                     NVL(F.EXISTS_GE_TP_DTANNUL , 0) EXISTS_GE_TP_DTANNUL,
                     NVL(F.EXISTS_GE_VE_DTANNUL , 0) EXISTS_GE_VE_DTANNUL,
                     NVL(F.EXISTS_EN_REFREPRES  , 0) EXISTS_EN_REFREPRES ,
                     NVL(F.EXISTS_VD_REFREPRES  , 0) EXISTS_VD_REFREPRES ,
                     NVL(F.EXISTS_GE_EN_DTENC   , 0) EXISTS_GE_EN_DTENC  ,
                     NVL(F.EXISTS_GE_VD_DTENC   , 0) EXISTS_GE_VD_DTENC  ,
                     NVL(EN.EXISTS_TE_DTANNUL   , 0) EXISTS_TE_EN_DTANNUL,
                     NVL(ET.EXISTS_TE_DTANNUL   , 0) EXISTS_TE_ET_DTANNUL,
                     NVL(VD.EXISTS_TE_DTANNUL   , 0) EXISTS_TE_VD_DTANNUL,
                     NVL(T.EXISTS_T_ENGAG       , 0) EXISTS_T_ENGAG      ,
                     NVL(TE.EXISTS_ECRDOS       , 0) EXISTS_ECRDOS       ,
                     NVL(TE2.EXISTS_ECRDOS2     , 0) EXISTS_ECRDOS2
                FROM G_DOSSIER         GD,
                     T_INTERVENANTS    CL,
                     T_INTERVENANTS    DB,
                     ( SELECT/*+LEADING(E) USE_HASH(TE)*/
                              MAX(CASE WHEN DTJOUR    = 1 AND typeelem = 'en' AND libelle LIKE 'Delai avant%' THEN 1 ELSE 0 END) AS EXISTS_GE_EN_DTJOUR ,
                              MAX(CASE WHEN DTJOUR    = 1 AND typeelem = 'vd' AND libelle LIKE 'Delai avant%' THEN 1 ELSE 0 END) AS EXISTS_GE_VD_DTJOUR ,
                              MAX(CASE WHEN DTANNUL   = 1 AND typeelem = 'en'                                 THEN 1 ELSE 0 END) AS EXISTS_GE_EN_DTANNUL, 
                              MAX(CASE WHEN DTANNUL   = 1 AND typeelem = 'vd'                                 THEN 1 ELSE 0 END) AS EXISTS_GE_VD_DTANNUL,
                              MAX(CASE WHEN DTANNUL   = 1 AND typeelem = 'vr'                                 THEN 1 ELSE 0 END) AS EXISTS_GE_VR_DTANNUL,   
                              MAX(CASE WHEN DTANNUL   = 1 AND typeelem = 'tp'                                 THEN 1 ELSE 0 END) AS EXISTS_GE_TP_DTANNUL,   
                              MAX(CASE WHEN DTANNUL   = 1 AND typeelem = 've'                                 THEN 1 ELSE 0 END) AS EXISTS_GE_VE_DTANNUL, 
                              MAX(CASE WHEN DTENCAISS = 1 AND typeelem = 'en'                                 THEN 1 ELSE 0 END) AS EXISTS_GE_EN_DTENC  , 
                              MAX(CASE WHEN DTENCAISS = 1 AND typeelem = 'vd'                                 THEN 1 ELSE 0 END) AS EXISTS_GE_VD_DTENC  , 
                              MAX(CASE WHEN REFREPRES = 1 AND typeelem = 'en'                                 THEN 1 ELSE 0 END) AS EXISTS_EN_REFREPRES ,
                              MAX(CASE WHEN REFREPRES = 1 AND typeelem = 'vd'                                 THEN 1 ELSE 0 END) AS EXISTS_VD_REFREPRES ,
                              TE.REFDOSS  
                         FROM ( SELECT/*+INDEX_FFS(T_ELEMENTS_EN T_ELEMENTS_EN_RTRLAM_IDX)*/ 
                                       refelem, 'en' AS typeelem, libelle, refdoss
                                  FROM T_ELEMENTS_EN
                                 WHERE typeelem = 'en'
                                   AND ORA_HASH(refdoss, 4-1) = 0
                                 UNION ALL
                                SELECT/*+INDEX_FFS(T_ELEMENTS_VD T_ELEMENTS_VD_RTRLAM_IDX)*/ 
                                       refelem, 'vd' AS typeelem, libelle, refdoss
                                  FROM T_ELEMENTS_VD
                                 WHERE typeelem = 'vd'
                                   AND ORA_HASH(refdoss, 4-1) = 0
                                 UNION ALL
                                SELECT/*+INDEX_FFS(T_ELEMENTS_VR T_ELEMENTS_VR_RTRLAM_IDX)*/ 
                                       refelem, 'vr' AS typeelem, NULL AS libelle, refdoss
                                  FROM T_ELEMENTS_VR
                                 WHERE typeelem = 'an'
                                   AND abrev = 'vr'
                                   AND ORA_HASH(refdoss, 4-1) = 0
                                 UNION ALL
                                SELECT/*+INDEX_FFS(T_ELEMENTS_TP T_ELEMENTS_TP_RTRLAM_IDX)*/ 
                                       refelem, 'tp'  AS typeelem, NULL AS libelle, refdoss
                                  FROM T_ELEMENTS_TP
                                 WHERE typeelem = 'an'
                                   AND abrev = 'tp'
                                   AND ORA_HASH(refdoss, 4-1) = 0
                                 UNION ALL
                                SELECT/*+INDEX_FFS(T_ELEMENTS_VE T_ELEMENTS_VE_RTRLAM_IDX)*/ 
                                       refelem, 've' AS typeelem, NULL AS libelle, refdoss
                                  FROM T_ELEMENTS_VE
                                 WHERE typeelem = 'an'
                                   AND abrev = 've'
                                   AND ORA_HASH(refdoss, 4-1) = 0
                              ) TE,
                              ( SELECT/*+INDEX(G G_ENCAISSEMENT_DTJOUR_IDX)*/ 
                                       refencaiss AS REFENCAISS,
                                       1          AS DTJOUR    ,
                                       0          AS DTANNUL   ,
                                       0          AS DTENCAISS , 
                                       0          AS REFREPRES
                                  FROM G_ENCAISSEMENT G
                                 WHERE dtjour BETWEEN to_char(to_date('01/08/2023', 'dd/mm/yyyy'), 'J') AND to_char(to_date('31/08/2023', 'dd/mm/yyyy'), 'J')
                             UNION ALL
                             SELECT/*+INDEX(G IDX_ENCAISS_FFS)*/ 
                                       refencaiss AS REFENCAISS,
                                       0          AS DTJOUR    ,
                                       1           AS DTANNUL   ,
                                       0          AS DTENCAISS , 
                                       0          AS REFREPRES
                                  FROM G_ENCAISSEMENT G
                                 WHERE dtannul BETWEEN to_char(to_date('01/08/2023', 'dd/mm/yyyy'), 'J') AND to_char(to_date('31/08/2023', 'dd/mm/yyyy'), 'J')
                             UNION ALL
                                SELECT/*+INDEX_FFS(G G_ENCAISSEMENT_IDX1)*/ 
                                       refencaiss AS REFENCAISS,
                                       0          AS DTJOUR    ,
                                       0          AS DTANNUL   ,
                                       1          AS DTENCAISS ,
                                       0          AS REFREPRES
                                  FROM G_ENCAISSEMENT G
                                 WHERE DTENCAISS BETWEEN to_char(to_date('01/08/2023', 'dd/mm/yyyy'), 'J') AND to_char(to_date('31/08/2023', 'dd/mm/yyyy'), 'J')
                             UNION ALL
                                SELECT/*+INDEX(G G_ENCAISSEMENT_REFREPRES)*/ 
                                       REFENCAISS AS REFENCAISS,
                                       0          AS DTJOUR    ,
                                       0          AS DTANNUL   ,
                                       0          AS DTENCAISS ,
                                       1          AS REFREPRES
                                  FROM G_ENCAISSEMENT G
                                 WHERE REFREPRES IS NOT NULL
                              ) E
                        WHERE TE.refelem = E.refencaiss
                     GROUP BY TE.refdoss
                     ) F,
                     ( SELECT/*+INDEX(TP T_ELEMENTS_VD_DTANNUL_IDX)*/ 
                              MAX(1) EXISTS_TE_DTANNUL,
                              refdoss
                         FROM T_ELEMENTS_VD TP
                        WHERE typeelem = 'an'
                          AND abrev = 'vd'
                          AND dtannul IS NOT NULL
                          AND dtannul BETWEEN to_char(to_date('01/08/2023', 'dd/mm/yyyy'), 'J') AND to_char(to_date('31/08/2023', 'dd/mm/yyyy'), 'J')
                          AND ORA_HASH(refdoss, 4-1) = 0
                     GROUP BY refdoss
                     ) VD,
                     ( SELECT/*+INDEX(TP T_ELEMENTS_ET_DTANNUL_IDX)*/ 
                              MAX(1) EXISTS_TE_DTANNUL,
                              refdoss
                         FROM T_ELEMENTS_ET TP
                        WHERE typeelem = 'an'
                          AND abrev = 'et'
                          AND dtannul IS NOT NULL
                          AND dtannul BETWEEN to_char(to_date('01/08/2023', 'dd/mm/yyyy'), 'J') AND to_char(to_date('31/08/2023', 'dd/mm/yyyy'), 'J')
                          AND ORA_HASH(refdoss, 4-1) = 0
                     GROUP BY refdoss
                     ) ET,
                     ( SELECT/*+INDEX(TP T_ELEMENTS_EN_DTANNUL_IDX)*/ 
                              MAX(1) EXISTS_TE_DTANNUL,
                              refdoss
                         FROM T_ELEMENTS_EN TP
                        WHERE typeelem = 'an'
                          AND abrev = 'en'
                          AND dtannul IS NOT NULL
                          AND dtannul BETWEEN to_char(to_date('01/08/2023', 'dd/mm/yyyy'), 'J') AND to_char(to_date('31/08/2023', 'dd/mm/yyyy'), 'J')
                          AND ORA_HASH(refdoss, 4-1) = 0
                     GROUP BY refdoss
                     ) EN,
                     ( SELECT/*+INDEX(G G_T_ENGAGEMENT_USER_DATE_IDX)*/
                              MAX(1) EXISTS_T_ENGAG,
                              refdoss
                         FROM G_T_ENGAGEMENT G
                        WHERE user_date >= TO_DATE(to_char(to_date('01/08/2023', 'dd/mm/yyyy'), 'J'), 'J')
                          AND user_date < TO_DATE(to_char(to_date('31/08/2023', 'dd/mm/yyyy'), 'J'), 'J')+1
                          AND ORA_HASH(G.refdoss, 4-1) = 0
                     GROUP BY refdoss
                     )T,
                     ( SELECT/*+INDEX(M AD_T_ECRDOS_DTJOUR_IDX)*/ 
                              COUNT(*) EXISTS_ECRDOS,
                              refdoss
                         FROM AD_T_ECRDOS_MVIEW M
                        WHERE dtjour BETWEEN to_char(to_date('01/08/2023', 'dd/mm/yyyy'), 'J') AND to_char(to_date('31/08/2023', 'dd/mm/yyyy'), 'J')
                          AND SOMME  = 'SOLDEDB'
                          AND ORA_HASH(M.refdoss, 4-1) = 0
                     GROUP BY refdoss
                     ) TE,
                     ( SELECT/*+INDEX(T2 IDX_DTJOUR_ECRDOS)*/  
                              COUNT(*) EXISTS_ECRDOS2,
                              refdoss
                         FROM t_ecrdos T2
                        WHERE dtjour  BETWEEN to_char(to_date('01/08/2023', 'dd/mm/yyyy'), 'J') AND to_char(to_date('31/08/2023', 'dd/mm/yyyy'), 'J')
                           AND codecr IN ('DBET' , 'DBCL' , 'VIENC', 'CLDB' , 'ETDB' ,
                                          'PRIN' , 'DEBE' , 'HONOR', 'DPDB' , 'ACTE' ,
                                          'DBERH', 'APRIN', 'ADEBE', 'AHONO', 'ADPDB',
                                          'AACTE', 'ADBER')
                           AND ORA_HASH(T2.refdoss, 4-1) = 0
                     GROUP BY refdoss
                     ) TE2,
                     ( SELECT/*+FULL(G) */ 
                              refdoss
                         FROM g_dossier G
                        WHERE dtstratif <= to_char(to_date('31/08/2023', 'dd/mm/yyyy'), 'J')
                          AND NVL(to_char(G.DTCREATION_DT, 'J'), G.DT_DT)  <= to_char(to_date('31/08/2023', 'dd/mm/yyyy'), 'J')
                          AND ';' NOT LIKE '%;'||stratif||';%'
                          AND ORA_HASH(G.refdoss, 4-1) = 0
                    UNION ALL
                       SELECT refdoss
                         FROM ( SELECT/*+FULL(G) LEADING(G) no_merge no_push_pred*/ 
                                       C.refdoss,
                                       C.nom,
                                       ROW_NUMBER() OVER(PARTITION BY C.refdoss ORDER BY DTASSOC_DT DESC NULLS LAST) AS rnk
                                  FROM t_elements_ce C,
                                       g_dossier        G
                                 WHERE NVL(to_char(G.DTCREATION_DT, 'J'), G.DT_DT) <= to_char(to_date('31/08/2023', 'dd/mm/yyyy'), 'J')
                                   AND G.dtstratif > to_char(to_date('31/08/2023', 'dd/mm/yyyy'), 'J')
                                   AND C.refdoss = G.refdoss
                                   AND C.dtassoc <= to_char(to_date('31/08/2023', 'dd/mm/yyyy'), 'J')
                                   AND (   C.dtlimite IS NULL 
                                        OR C.dtlimite >= to_char(to_date('31/08/2023', 'dd/mm/yyyy'), 'J') )
                                   AND ORA_HASH(G.refdoss, 4-1) = 0
                              ) N
                        WHERE N.rnk = 1
                          AND (   ';' NOT LIKE '%;'||N.nom||';%'
                               OR (    1 = 1
                                   AND ';' LIKE '%;'||N.nom||';%'
                                   AND EXISTS ( SELECT 1
                                                  FROM t_elements_ce O
                                                 WHERE O.refdoss = N.refdoss
                                                   AND ';' NOT LIKE '%;'||O.nom||';%'
                                                   AND O.dtassoc <= to_char(to_date('31/08/2023', 'dd/mm/yyyy'), 'J')
                                                   AND O.dtlimite >= to_char(to_date('01/08/2023', 'dd/mm/yyyy'), 'J')
                                                   AND O.dtlimite <= to_char(to_date('31/08/2023', 'dd/mm/yyyy'), 'J')
                                              )
                                  ) 
                              )
                     ) L,
                     ( SELECT/*+FULL(TEMP_AD_CF_LOADED_ROWS)*/ 
                              refdoss                                                 AS refdoss,
                              MAX(CASE WHEN agregation_type = 1 THEN 1 ELSE NULL END) AS daily  ,
                              MAX(CASE WHEN agregation_type = 2 THEN 1 ELSE NULL END) AS monthly
                         FROM TEMP_AD_CF_LOADED_ROWS
                     GROUP BY refdoss
                     ) A,
                     V_DOMAINE V
               WHERE GD.refdoss = L.refdoss
                 AND GD.REFDOSS = CL.REFDOSS
                 AND CL.REFTYPE = 'CL'
                 AND ORA_HASH(CL.refdoss, 4-1) = 0
                 AND GD.REFDOSS = DB.REFDOSS
                 AND DB.REFTYPE = 'DB'
                 AND ORA_HASH(DB.refdoss, 4-1) = 0
                 AND nvl(to_char(GD.DTCREATION_DT,'J'),GD.DT_DT)<= to_char(to_date('31/08/2023', 'dd/mm/yyyy'), 'J')
                 AND GD.CATEGDOSS = V.VALEUR
                 AND V.TYPE  = 'categdoss'
                 AND A.refdoss(+) = GD.refdoss
                 AND (   (    1 = 0 
                          AND A.daily IS NULL )
                      OR (    1 = 1
                          AND A.monthly IS NULL )
                     )
                 AND F.refdoss(+) = GD.refdoss
                 AND EN.refdoss(+) = GD.refdoss
                 AND VD.refdoss(+) = GD.refdoss
                 AND ET.refdoss(+) = GD.refdoss
                 AND T.refdoss(+) = GD.refdoss
                 AND TE.refdoss(+) = GD.refdoss
                 AND TE2.refdoss(+) = GD.refdoss
                 AND ORA_HASH(gd.refdoss, 4-1) = 0;
/********************************New SQL*******************************************/
/********************************New Metrics***************************************/
/*
Plan hash value: 857912289
-------------------------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                                 | Name                         | Starts | E-Rows | A-Rows |   A-Time   | Buffers | Reads  |
-------------------------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                                          |                              |      1 |        |      1 |00:00:05.38 |     122K|  59626 |
|   1 |  SORT AGGREGATE                                           |                              |      1 |      1 |      1 |00:00:05.38 |     122K|  59626 |
|   2 |   VIEW                                                    |                              |      1 |      1 |  49999 |00:00:05.38 |     122K|  59626 |
|*  3 |    HASH JOIN OUTER                                        |                              |      1 |      1 |  49999 |00:00:05.38 |     122K|  59626 |
|   4 |     JOIN FILTER CREATE                                    | :BF0000                      |      1 |      1 |  49999 |00:00:04.41 |     105K|  42806 |
|*  5 |      HASH JOIN OUTER                                      |                              |      1 |      1 |  49999 |00:00:04.40 |     105K|  42806 |
|   6 |       JOIN FILTER CREATE                                  | :BF0001                      |      1 |      1 |  49999 |00:00:02.26 |   82048 |  34070 |
|*  7 |        HASH JOIN OUTER                                    |                              |      1 |      1 |  49999 |00:00:02.26 |   82048 |  34070 |
|   8 |         JOIN FILTER CREATE                                | :BF0002                      |      1 |      1 |  49999 |00:00:01.51 |   33403 |  25646 |
|*  9 |          HASH JOIN OUTER                                  |                              |      1 |      1 |  49999 |00:00:01.50 |   33403 |  25646 |
|  10 |           JOIN FILTER CREATE                              | :BF0003                      |      1 |      1 |  49999 |00:00:01.46 |   32779 |  25535 |
|* 11 |            HASH JOIN                                      |                              |      1 |      1 |  49999 |00:00:01.45 |   32779 |  25535 |
|* 12 |             HASH JOIN OUTER                               |                              |      1 |      1 |  49999 |00:00:01.44 |   32651 |  25535 |
|* 13 |              HASH JOIN OUTER                              |                              |      1 |      1 |  49999 |00:00:01.43 |   32642 |  25535 |
|* 14 |               HASH JOIN OUTER                             |                              |      1 |      1 |  49999 |00:00:01.42 |   32638 |  25535 |
|* 15 |                HASH JOIN                                  |                              |      1 |      1 |  49999 |00:00:01.41 |   32637 |  25535 |
|* 16 |                 HASH JOIN                                 |                              |      1 |      1 |  49999 |00:00:01.32 |   28787 |  25535 |
|* 17 |                  FILTER                                   |                              |      1 |        |  49999 |00:00:00.77 |   24937 |  23128 |
|* 18 |                   HASH JOIN OUTER                         |                              |      1 |      1 |  49999 |00:00:00.77 |   24937 |  23128 |
|* 19 |                    HASH JOIN                              |                              |      1 |      1 |  49999 |00:00:00.75 |   24937 |  23128 |
|  20 |                     VIEW                                  |                              |      1 |      6 |  49999 |00:00:00.51 |   17333 |  15528 |
|  21 |                      UNION-ALL                            |                              |      1 |        |  49999 |00:00:00.51 |   17333 |  15528 |
|* 22 |                       TABLE ACCESS FULL                   | G_DOSSIER                    |      1 |      5 |  49265 |00:00:00.18 |    7604 |   7600 |
|* 23 |                       FILTER                              |                              |      1 |        |    734 |00:00:00.31 |    9729 |   7928 |
|* 24 |                        VIEW                               |                              |      1 |      1 |    734 |00:00:00.31 |    9729 |   7928 |
|* 25 |                         WINDOW SORT PUSHED RANK           |                              |      1 |      1 |    734 |00:00:00.31 |    9729 |   7928 |
|  26 |                          NESTED LOOPS                     |                              |      1 |      1 |    734 |00:00:00.31 |    9729 |   7928 |
|  27 |                           NESTED LOOPS                    |                              |      1 |      2 |    734 |00:00:00.22 |    9074 |   7782 |
|* 28 |                            TABLE ACCESS FULL              | G_DOSSIER                    |      1 |      1 |    734 |00:00:00.12 |    7604 |   7600 |
|* 29 |                            INDEX RANGE SCAN               | T_ELEMENTS_CE_RTDTAS_IDX     |    734 |      2 |    734 |00:00:00.09 |    1470 |    182 |
|* 30 |                           TABLE ACCESS BY INDEX ROWID     | T_ELEMENTS_CE                |    734 |      1 |    734 |00:00:00.09 |     655 |    146 |
|* 31 |                        TABLE ACCESS BY INDEX ROWID BATCHED| T_ELEMENTS_CE                |      0 |      1 |      0 |00:00:00.01 |       0 |      0 |
|* 32 |                         INDEX RANGE SCAN                  | T_ELEMENTS_CE_RTDTAS_IDX     |      0 |      1 |      0 |00:00:00.01 |       0 |      0 |
|* 33 |                     TABLE ACCESS FULL                     | G_DOSSIER                    |      1 |    101 |  49999 |00:00:00.20 |    7604 |   7600 |
|  34 |                    VIEW                                   |                              |      1 |      1 |      0 |00:00:00.01 |       0 |      0 |
|  35 |                     HASH GROUP BY                         |                              |      1 |      1 |      0 |00:00:00.01 |       0 |      0 |
|  36 |                      TABLE ACCESS FULL                    | TEMP_AD_CF_LOADED_ROWS       |      1 |      1 |      0 |00:00:00.01 |       0 |      0 |
|* 37 |                  INDEX FAST FULL SCAN                     | T_INTERVE_IDX2               |      1 |   2014 |  50337 |00:00:00.52 |    3850 |   2407 |
|* 38 |                 INDEX FAST FULL SCAN                      | T_INTERVE_IDX2               |      1 |   2014 |  50337 |00:00:00.07 |    3850 |      0 |
|  39 |                VIEW                                       |                              |      1 |      1 |      0 |00:00:00.01 |       1 |      0 |
|  40 |                 HASH GROUP BY                             |                              |      1 |      1 |      0 |00:00:00.01 |       1 |      0 |
|* 41 |                  TABLE ACCESS BY INDEX ROWID BATCHED      | T_ELEMENTS_VD                |      1 |      1 |      0 |00:00:00.01 |       1 |      0 |
|* 42 |                   INDEX RANGE SCAN                        | T_ELEMENTS_VD_DTANNUL_IDX    |      1 |      1 |      0 |00:00:00.01 |       1 |      0 |
|  43 |               VIEW                                        |                              |      1 |      1 |      2 |00:00:00.01 |       4 |      0 |
|  44 |                HASH GROUP BY                              |                              |      1 |      1 |      2 |00:00:00.01 |       4 |      0 |
|* 45 |                 TABLE ACCESS BY INDEX ROWID BATCHED       | T_ELEMENTS_ET                |      1 |      1 |      2 |00:00:00.01 |       4 |      0 |
|* 46 |                  INDEX RANGE SCAN                         | T_ELEMENTS_ET_DTANNUL_IDX    |      1 |      8 |      8 |00:00:00.01 |       1 |      0 |
|  47 |              VIEW                                         |                              |      1 |      1 |      1 |00:00:00.01 |       9 |      0 |
|  48 |               HASH GROUP BY                               |                              |      1 |      1 |      1 |00:00:00.01 |       9 |      0 |
|* 49 |                TABLE ACCESS BY INDEX ROWID BATCHED        | T_ELEMENTS_EN                |      1 |      1 |      1 |00:00:00.01 |       9 |      0 |
|* 50 |                 INDEX RANGE SCAN                          | T_ELEMENTS_EN_DTANNUL_IDX    |      1 |     11 |     12 |00:00:00.01 |       1 |      0 |
|* 51 |             INDEX FAST FULL SCAN                          | DOM_TYPABREV                 |      1 |     22 |     22 |00:00:00.01 |     128 |      0 |
|  52 |           VIEW                                            |                              |      1 |     59 |   1254 |00:00:00.03 |     624 |    111 |
|  53 |            HASH GROUP BY                                  |                              |      1 |     59 |   1254 |00:00:00.03 |     624 |    111 |
|  54 |             JOIN FILTER USE                               | :BF0003                      |      1 |     59 |   1427 |00:00:00.03 |     624 |    111 |
|* 55 |              TABLE ACCESS BY INDEX ROWID BATCHED          | G_T_ENGAGEMENT               |      1 |     59 |   1427 |00:00:00.03 |     624 |    111 |
|* 56 |               INDEX RANGE SCAN                            | G_T_ENGAGEMENT_USER_DATE_IDX |      1 |   5920 |   5783 |00:00:00.01 |      14 |     14 |
|  57 |         VIEW                                              |                              |      1 |   1357 |  10617 |00:00:00.73 |   48645 |   8424 |
|  58 |          HASH GROUP BY                                    |                              |      1 |   1357 |  10617 |00:00:00.73 |   48645 |   8424 |
|  59 |           JOIN FILTER USE                                 | :BF0002                      |      1 |   1362 |  33686 |00:00:00.72 |   48645 |   8424 |
|* 60 |            MAT_VIEW ACCESS BY INDEX ROWID BATCHED         | AD_T_ECRDOS_MVIEW            |      1 |   1362 |  33686 |00:00:00.71 |   48645 |   8424 |
|* 61 |             INDEX RANGE SCAN                              | AD_T_ECRDOS_DTJOUR_IDX       |      1 |    457K|    497K|00:00:00.19 |     584 |    503 |
|  62 |       VIEW                                                |                              |      1 |   3288 |  10572 |00:00:02.12 |   23508 |   8736 |
|  63 |        HASH GROUP BY                                      |                              |      1 |   3288 |  10572 |00:00:02.12 |   23508 |   8736 |
|  64 |         JOIN FILTER USE                                   | :BF0001                      |      1 |   3315 |  73129 |00:00:02.09 |   23508 |   8736 |
|* 65 |          TABLE ACCESS BY INDEX ROWID BATCHED              | T_ECRDOS                     |      1 |   3315 |  73129 |00:00:02.08 |   23508 |   8736 |
|* 66 |           INDEX RANGE SCAN                                | IDX_DTJOUR_ECRDOS            |      1 |    331K|    295K|00:00:00.48 |    1318 |   1318 |
|  67 |     VIEW                                                  |                              |      1 |   6194 |   6471 |00:00:00.95 |   16990 |  16820 |
|  68 |      HASH GROUP BY                                        |                              |      1 |   6194 |   6471 |00:00:00.95 |   16990 |  16820 |
|  69 |       JOIN FILTER USE                                     | :BF0000                      |      1 |  11923 |  24625 |00:00:00.92 |   16990 |  16820 |
|* 70 |        HASH JOIN                                          |                              |      1 |  11923 |  24625 |00:00:00.92 |   16990 |  16820 |
|  71 |         VIEW                                              |                              |      1 |  97978 |  99761 |00:00:00.47 |   11791 |  11656 |
|  72 |          UNION-ALL                                        |                              |      1 |        |  99761 |00:00:00.46 |   11791 |  11656 |
|  73 |           TABLE ACCESS BY INDEX ROWID BATCHED             | G_ENCAISSEMENT               |      1 |  52386 |  53671 |00:00:00.28 |    1114 |    993 |
|* 74 |            INDEX RANGE SCAN                               | G_ENCAISSEMENT_DTJOUR_IDX    |      1 |  52386 |  53671 |00:00:00.04 |      90 |     90 |
|  75 |           TABLE ACCESS BY INDEX ROWID BATCHED             | G_ENCAISSEMENT               |      1 |     28 |     28 |00:00:00.01 |      15 |      4 |
|* 76 |            INDEX SKIP SCAN                                | G_ENCAISSEMENT_REFPIECE_IDX  |      1 |     28 |     28 |00:00:00.01 |       4 |      4 |
|* 77 |           TABLE ACCESS FULL                               | G_ENCAISSEMENT               |      1 |  45563 |  46062 |00:00:00.16 |   10661 |  10658 |
|  78 |           TABLE ACCESS BY INDEX ROWID BATCHED             | G_ENCAISSEMENT               |      1 |      1 |      0 |00:00:00.01 |       1 |      1 |
|* 79 |            INDEX FULL SCAN                                | G_ENCAISSEMENT_REFREPRES     |      1 |      1 |      0 |00:00:00.01 |       1 |      1 |
|  80 |         VIEW                                              |                              |      1 |   6375 |    159K|00:00:00.38 |    5199 |   5164 |
|  81 |          UNION-ALL                                        |                              |      1 |        |    159K|00:00:00.36 |    5199 |   5164 |
|* 82 |           INDEX FAST FULL SCAN                            | T_ELEMENTS_EN_RTRLAM_IDX     |      1 |     94 |   2348 |00:00:00.01 |     121 |    110 |
|* 83 |           INDEX FAST FULL SCAN                            | T_ELEMENTS_VD_RTRLAM_IDX     |      1 |   6278 |    157K|00:00:00.32 |    5066 |   5048 |
|* 84 |           INDEX FAST FULL SCAN                            | T_ELEMENTS_VR_RTRLAM_IDX     |      1 |      1 |      0 |00:00:00.01 |       4 |      2 |
|* 85 |           INDEX FAST FULL SCAN                            | T_ELEMENTS_TP_RTRLAM_IDX     |      1 |      1 |      0 |00:00:00.01 |       4 |      2 |
|* 86 |           INDEX FAST FULL SCAN                            | T_ELEMENTS_VE_RTRLAM_IDX     |      1 |      1 |      0 |00:00:00.01 |       4 |      2 |
-------------------------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   3 - access("F"."REFDOSS"="GD"."REFDOSS")
   5 - access("TE2"."REFDOSS"="GD"."REFDOSS")
   7 - access("TE"."REFDOSS"="GD"."REFDOSS")
   9 - access("T"."REFDOSS"="GD"."REFDOSS")
  11 - access("GD"."CATEGDOSS"="V"."VALEUR")
  12 - access("EN"."REFDOSS"="GD"."REFDOSS")
  13 - access("ET"."REFDOSS"="GD"."REFDOSS")
  14 - access("VD"."REFDOSS"="GD"."REFDOSS")
  15 - access("GD"."REFDOSS"="CL"."REFDOSS")
  16 - access("GD"."REFDOSS"="DB"."REFDOSS")
  17 - filter("A"."MONTHLY" IS NULL)
  18 - access("A"."REFDOSS"="GD"."REFDOSS")
  19 - access("GD"."REFDOSS"="L"."REFDOSS")
  22 - filter((ORA_HASH("G"."REFDOSS",3)=0 AND ';' NOT LIKE '%;'||"STRATIF"||';%' AND
              NVL(TO_CHAR(INTERNAL_FUNCTION("G"."DTCREATION_DT"),'j'),TO_CHAR("G"."DT_DT"))<='2460188' AND "DTSTRATIF"<=2460188))
  23 - filter((';' NOT LIKE '%;'||"N"."NOM"||';%' OR (';' LIKE '%;'||"N"."NOM"||';%' AND  IS NOT NULL)))
  24 - filter("N"."RNK"=1)
  25 - filter(ROW_NUMBER() OVER ( PARTITION BY "C"."REFDOSS" ORDER BY INTERNAL_FUNCTION("DTASSOC_DT") DESC  NULLS LAST)<=1)
  28 - filter(("G"."DTSTRATIF">2460188 AND ORA_HASH("G"."REFDOSS",3)=0 AND
              NVL(TO_CHAR(INTERNAL_FUNCTION("G"."DTCREATION_DT"),'j'),TO_CHAR("G"."DT_DT"))<='2460188'))
  29 - access("C"."REFDOSS"="G"."REFDOSS" AND "C"."DTASSOC"<=2460188)
  30 - filter(("C"."DTLIMITE" IS NULL OR "C"."DTLIMITE">=2460188))
  31 - filter(';' NOT LIKE '%;'||"O"."NOM"||';%')
  32 - access("O"."REFDOSS"=:B1 AND "O"."DTLIMITE">=2460158 AND "O"."DTASSOC"<=2460188 AND "O"."DTLIMITE"<=2460188)
       filter(("O"."DTLIMITE">=2460158 AND "O"."DTLIMITE"<=2460188))
  33 - filter((ORA_HASH("GD"."REFDOSS",3)=0 AND NVL(TO_CHAR(INTERNAL_FUNCTION("GD"."DTCREATION_DT"),'j'),TO_CHAR("GD"."DT_DT"))<='2460188'))
  37 - filter(("DB"."REFTYPE"='DB' AND ORA_HASH("DB"."REFDOSS",3)=0))
  38 - filter(("CL"."REFTYPE"='CL' AND ORA_HASH("CL"."REFDOSS",3)=0))
  41 - filter(("TYPEELEM"='an' AND "ABREV"='vd' AND ORA_HASH("REFDOSS",3)=0))
  42 - access("DTANNUL">=2460158 AND "DTANNUL"<=2460188)
  45 - filter(("ABREV"='et' AND "TYPEELEM"='an' AND ORA_HASH("REFDOSS",3)=0))
  46 - access("DTANNUL">=2460158 AND "DTANNUL"<=2460188)
  49 - filter(("TYPEELEM"='an' AND ORA_HASH("REFDOSS",3)=0 AND "ABREV"='en'))
  50 - access("DTANNUL">=2460158 AND "DTANNUL"<=2460188)
  51 - filter("V"."TYPE"='categdoss')
  55 - filter(ORA_HASH("G"."REFDOSS",3)=0)
  56 - access("USER_DATE">=TO_DATE(' 2023-08-01 00:00:00', 'syyyy-mm-dd hh24:mi:ss') AND "USER_DATE"<TO_DATE(' 2023-09-01 00:00:00', 'syyyy-mm-dd
              hh24:mi:ss'))
  60 - filter(("SOMME"='SOLDEDB' AND ORA_HASH("M"."REFDOSS",3)=0))
  61 - access("DTJOUR">=2460158 AND "DTJOUR"<=2460188)
  65 - filter(ORA_HASH("T2"."REFDOSS",3)=0)
  66 - access("DTJOUR">=2460158 AND "DTJOUR"<=2460188)
       filter(("CODECR"='AACTE' OR "CODECR"='ACTE' OR "CODECR"='ADBER' OR "CODECR"='ADEBE' OR "CODECR"='ADPDB' OR "CODECR"='AHONO' OR
              "CODECR"='APRIN' OR "CODECR"='CLDB' OR "CODECR"='DBCL' OR "CODECR"='DBERH' OR "CODECR"='DBET' OR "CODECR"='DEBE' OR "CODECR"='DPDB' OR
              "CODECR"='ETDB' OR "CODECR"='HONOR' OR "CODECR"='PRIN' OR "CODECR"='VIENC'))
  70 - access("TE"."REFELEM"="E"."REFENCAISS")
  74 - access("DTJOUR">=2460158 AND "DTJOUR"<=2460188)
  76 - access("DTANNUL">=2460158 AND "DTANNUL"<=2460188)
       filter(("DTANNUL">=2460158 AND "DTANNUL"<=2460188))
  77 - filter(("DTENCAISS">=2460158 AND "DTENCAISS"<=2460188))
  79 - filter("REFREPRES" IS NOT NULL)
  82 - filter((ORA_HASH("REFDOSS",3)=0 AND "TYPEELEM"='en'))
  83 - filter((ORA_HASH("REFDOSS",3)=0 AND "TYPEELEM"='vd'))
  84 - filter(("TYPEELEM"='an' AND "ABREV"='vr' AND ORA_HASH("REFDOSS",3)=0))
  85 - filter(("TYPEELEM"='an' AND "ABREV"='tp' AND ORA_HASH("REFDOSS",3)=0))
  86 - filter(("ABREV"='ve' AND "TYPEELEM"='an' AND ORA_HASH("REFDOSS",3)=0))
*/
/********************************New Metrics***************************************/

/********************************Index statistics**********************************/

/********************************Other SQLs****************************************/          
/*

*/ 
/********************************Other SQLs****************************************/              
