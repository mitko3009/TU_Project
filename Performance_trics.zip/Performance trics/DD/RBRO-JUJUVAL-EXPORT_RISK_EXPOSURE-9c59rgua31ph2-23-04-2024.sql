/********************************************************************************
*********       E-mail subject: RBRODEV-3680
*********             Instance: JUJUVAL
*********          Description: 
Problem:
Slowness in script rbr_dwh_full.ksh.

Analysis:
I checked for the provided period on JUJUVAL and for module EXPORT_RISK_EXPOSURE the TOP SQL that took 57% of the time was 9c59rgua31ph2.
The main problem in this SQL is the accessing of table NAM_ECR_COMPTA_BAK a lot of times.
This SQL was analyzed before and was added hint for index_combine in it, which partially solves the problem, but is not the most optimal solution.
Unfortunately, on JUJUVAL we have Oracle Standard edition and the index_combine hint doesn't work, because it is Enterprise edition feature.
The solution that we can propose here is to create new index on table NAM_ECR_COMPTA_BAK on columns CODEOPER,EL3,EXTREF2 and rewrite the query as 
it is shown in the New SQL section below. This will improve the performance and will achieve the execution plan from the New Metrics section.

Suggestion:
Please check is it possible to create index on table NAM_ECR_COMPTA_BAK on columns CODEOPER,EL3,EXTREF2 and if it is, 
please rewrite the query as it is shown in the New SQL section below.

*********               SQL_ID: 9c59rgua31ph2
*********      Program/Package: rbr_dwh_full.ksh
*********              Request: Giao My Tran 
*********               Author: Dimitar Dimitrov
********* Received e-mail date: 23/04/2024
*********      Resolution date: 23/04/2024
*********  Trace old file here: \\epox\specifs\performance\tmp\
*********  Trace new file here:
***********************************************************************************/

/********************************OLD SQL*******************************************/

VAR B1 VARCHAR2(32);
EXEC :B1 := 'A6004L0T';
VAR B2 VARCHAR2(32);
EXEC :B2 := '1904180041';

SELECT 'Normal'
  FROM DUAL
 WHERE EXISTS
 (SELECT /*+ index_combine(ACC IDX6_NAM_ECR_COMPTA_BAK IDX2_NAM_ECR_COMPTA_BAK) */
         1
          FROM NAM_ECR_COMPTA_BAK ACC, 
               T_INTERVENANTS CLIENT
         WHERE ACC.EXTREF2 IN (SELECT :B2
                                 FROM DUAL
                               UNION
                               SELECT REFDOSS
                                 FROM G_DOSSIER
                                WHERE REFHIERARCHIE = :B2)
           AND ACC.CODEOPER = 'WRITE_OFF_FIU'
           AND ACC.EXTREF2 = CLIENT.REFDOSS
           AND ACC.EL3 = CLIENT.REFINDIVIDU
           AND CLIENT.REFTYPE = 'CL'
           AND CLIENT.REFINDIVIDU = :B1
        UNION
        SELECT 1
          FROM G_DOSSIER      CNTR,
               G_DOSSIER      DCMP,
               G_DOSSIER      CMP,
               G_ELEMFI       WRITE_OFF,
               T_INTERVENANTS DB
         WHERE CNTR.REFDOSS = :B2
           AND DCMP.REFLOT = CNTR.REFDOSS
           AND CMP.REFLOT = DCMP.REFDOSS
           AND WRITE_OFF.REFDOSS = CMP.REFDOSS
           AND WRITE_OFF.TYPE = 'WRITE OFF'
           AND DB.REFDOSS = CMP.REFDOSS
           AND DB.REFTYPE = 'DB'
           AND DB.REFINDIVIDU = :B1);
/********************************OLD SQL*******************************************/
/********************************OLD Metrics***************************************/
/*
MODULE                           SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
EXPORT_RISK_EXPOSURE                                            1918      17880 db file sequential r 2024/04/23 01:33:43  2024/04/23 04:17:51        5971               242688 +000000000 02:44:08.065 29%
SQL*Plus                                                                        ON CPU               2024/04/23 00:50:00  2024/04/23 04:28:31        5159               187931 +000000000 03:38:31.615 25%
EXPORT_RISK_EXPOSURE                                            1918      17880 db file parallel rea 2024/04/23 01:34:06  2024/04/23 04:17:53        1835                 5131 +000000000 02:43:47.584 9%
EXPORT_RISK_EXPOSURE                                            1918      17880 ON CPU               2024/04/23 01:34:01  2024/04/23 04:17:06        1430               112161 +000000000 02:43:05.601 7%
                                                        0        762      58444 log file parallel wr 2024/04/23 00:50:01  2024/04/23 04:27:26        1321                      +000000000 03:37:25.056 6%
                                                                                ON CPU               2024/04/23 00:50:56  2024/04/23 04:29:58         619                53294 +000000000 03:39:02.336 3%
EXPORT_LIMITS                                                   1918      17880 ON CPU               2024/04/23 00:59:42  2024/04/23 01:16:54         582               132553 +000000000 00:17:11.168 3%
erf_batch                                                        416      23605 db file sequential r 2024/04/23 00:50:00  2024/04/23 00:59:11         512                  406 +000000000 00:09:10.913 2%




MODULE                           SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
EXPORT_RISK_EXPOSURE                                            1918      17880                      2024/04/23 01:33:43  2024/04/23 04:17:53        9620               242688 +000000000 02:44:10.113 100%


MODULE                           SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
EXPORT_RISK_EXPOSURE                                            1918      17880 db file sequential r 2024/04/23 01:33:43  2024/04/23 04:17:51        5971               242688 +000000000 02:44:08.065 62%
EXPORT_RISK_EXPOSURE                                            1918      17880 db file parallel rea 2024/04/23 01:34:06  2024/04/23 04:17:53        1835                 5131 +000000000 02:43:47.584 19%
EXPORT_RISK_EXPOSURE                                            1918      17880 ON CPU               2024/04/23 01:34:01  2024/04/23 04:17:06        1430               112161 +000000000 02:43:05.601 15%
EXPORT_RISK_EXPOSURE             7jvvbqu566ctv  608508530       1918      17880 direct path read     2024/04/23 01:33:47  2024/04/23 01:37:57         213                    1 +000000000 00:04:09.858 2%
EXPORT_RISK_EXPOSURE                                            1918      17880 db file scattered re 2024/04/23 01:34:12  2024/04/23 04:13:47         171                 5131 +000000000 02:39:34.655 2%


MODULE                           SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
EXPORT_RISK_EXPOSURE             9c59rgua31ph2 2947619686       1918      17880                      2024/04/23 01:38:14  2024/04/23 04:05:38        5499                 5131 +000000000 02:27:24.479 57%
EXPORT_RISK_EXPOSURE             f488v1c6f2z9p 3391415704       1918      17880                      2024/04/23 01:38:46  2024/04/23 04:17:53         880                 2531 +000000000 02:39:07.009 9%
EXPORT_RISK_EXPOSURE             gjzdu6mdb82cx 2604568021       1918      17880                      2024/04/23 01:57:50  2024/04/23 04:17:17         794                 2528 +000000000 02:19:27.360 8%
EXPORT_RISK_EXPOSURE             b4uyncu1ftcuj 2604568021       1918      17880                      2024/04/23 01:57:07  2024/04/23 04:16:37         779                 2528 +000000000 02:19:29.409 8%


INSTANCE_NUMBER SQL_ID            ELAPSED MAX_WAIT_ON     PC_OF  WAIT_TIME            GETS      READS       ROWS  ELAP/EXEC       GETS/EXEC READS/EXEC  ROWS/EXEC       EXEC PLAN_HASH_VALUE
--------------- ------------- ----------- --------------- ----- ---------- --------------- ---------- ---------- ---------- --------------- ---------- ---------- ---------- ---------------
              1 9c59rgua31ph2        5324 IO              92%   5482.98212        29059712   15955564         18       1.04            5665    3110.25          0       5130      2947619686


SQL_ID        SQL_PLAN_HASH_VALUE SQL_PLAN_LINE_ID SQL_PLAN_OPERATION             SQL_PLAN_OPTIONS                   ACTIVE
------------- ------------------- ---------------- ------------------------------ ------------------------------ ----------
9c59rgua31ph2          2947619686               10 TABLE ACCESS                   BY INDEX ROWID                        536
9c59rgua31ph2          2947619686                9 INDEX                          RANGE SCAN                              8
9c59rgua31ph2          2947619686                6 NESTED LOOPS                                                           2


Plan hash value: 2947619686
---------------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                        | Name                           | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  |
---------------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                 |                                |      1 |        |    64 (100)|      0 |00:12:34.12 |    1236K|   1125K|
|*  1 |  FILTER                          |                                |      1 |        |            |      0 |00:12:34.12 |    1236K|   1125K|
|   2 |   FAST DUAL                      |                                |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|   3 |   SORT UNIQUE                    |                                |      1 |      2 |    62   (0)|      0 |00:12:34.12 |    1236K|   1125K|
|   4 |    UNION-ALL                     |                                |      1 |        |            |      0 |00:12:34.12 |    1236K|   1125K|
|*  5 |     FILTER                       |                                |      1 |        |            |      0 |00:12:34.12 |    1236K|   1125K|
|   6 |      NESTED LOOPS                |                                |      1 |      2 |    54   (0)|      0 |00:12:34.12 |    1236K|   1125K|
|   7 |       NESTED LOOPS               |                                |      1 |  33542 |    54   (0)|   9501K|00:00:11.22 |   26475 |  24204 |
|*  8 |        INDEX RANGE SCAN          | INT_INDIV                      |      1 |      1 |     1   (0)|     12 |00:00:00.01 |       2 |      0 |
|*  9 |        INDEX RANGE SCAN          | IDX2_NAM_ECR_COMPTA_BAK        |     12 |  33542 |     1   (0)|   9501K|00:00:10.16 |   26473 |  24204 |
|* 10 |       TABLE ACCESS BY INDEX ROWID| NAM_ECR_COMPTA_BAK             |   9501K|      2 |    53   (0)|      0 |00:12:20.76 |    1209K|   1100K|
|  11 |      SORT UNIQUE                 |                                |      0 |      2 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|  12 |       UNION-ALL                  |                                |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|* 13 |        FILTER                    |                                |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  14 |         FAST DUAL                |                                |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 15 |        INDEX RANGE SCAN          | REFHIERARCHIE_IDX              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|  16 |     NESTED LOOPS SEMI            |                                |      1 |      1 |     5   (0)|      0 |00:00:00.01 |       4 |      0 |
|  17 |      NESTED LOOPS SEMI           |                                |      1 |      1 |     4   (0)|      0 |00:00:00.01 |       4 |      0 |
|  18 |       NESTED LOOPS               |                                |      1 |      1 |     3   (0)|      0 |00:00:00.01 |       4 |      0 |
|  19 |        NESTED LOOPS              |                                |      1 |      1 |     2   (0)|      0 |00:00:00.01 |       4 |      0 |
|* 20 |         INDEX UNIQUE SCAN        | DOS_REFDOSS                    |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       2 |      0 |
|* 21 |         INDEX RANGE SCAN         | INT_INDIV                      |      1 |      1 |     1   (0)|      0 |00:00:00.01 |       2 |      0 |
|* 22 |        INDEX RANGE SCAN          | DOS_REFDOSS_REFLOT_IDX         |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 23 |       INDEX RANGE SCAN           | DOS_REFDOSS_REFLOT_IDX         |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 24 |      INDEX RANGE SCAN            | G_ELEMFI_DOS_TYP_FG02_CODE_IDX |      0 |   3462 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
---------------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   1 - filter( IS NOT NULL)
   5 - filter( IS NOT NULL)
   8 - access("CLIENT"."REFINDIVIDU"=:B1 AND "CLIENT"."REFTYPE"='CL')
   9 - access("ACC"."EL3"=:B1)
  10 - filter(("ACC"."EXTREF2"="CLIENT"."REFDOSS" AND "ACC"."CODEOPER"='WRITE_OFF_FIU'))
  13 - filter(:B1=:B2)
  15 - access("REFHIERARCHIE"=:B2 AND "REFDOSS"=:B1)
       filter("REFDOSS"=:B1)
  20 - access("CNTR"."REFDOSS"=:B2)
  21 - access("DB"."REFINDIVIDU"=:B1 AND "DB"."REFTYPE"='DB')
  22 - access("DB"."REFDOSS"="CMP"."REFDOSS")
       filter("CMP"."REFLOT" IS NOT NULL)
  23 - access("CMP"."REFLOT"="DCMP"."REFDOSS" AND "DCMP"."REFLOT"=:B2)
  24 - access("WRITE_OFF"."REFDOSS"="CMP"."REFDOSS" AND "WRITE_OFF"."TYPE"='WRITE OFF')
*/
/********************************OLD Metrics***************************************/

/********************************New SQL*******************************************/


SELECT 'Normal'
  FROM DUAL
 WHERE EXISTS ( SELECT 1
                  FROM ( SELECT :B2 REFDOSS
                           FROM DUAL
                          UNION
                         SELECT REFDOSS
                           FROM G_DOSSIER
                          WHERE REFHIERARCHIE = :B2 ) DOS,
                       T_INTERVENANTS CLIENT,
                       NAM_ECR_COMPTA_BAK ACC 
                 WHERE DOS.REFDOSS = CLIENT.REFDOSS
                   AND CLIENT.REFTYPE = 'CL'
                   AND CLIENT.REFINDIVIDU = :B1
                   AND ACC.CODEOPER = 'WRITE_OFF_FIU'
                   AND ACC.EL3 = CLIENT.REFINDIVIDU
                   AND ACC.EXTREF2 = CLIENT.REFDOSS 
                 UNION
                SELECT 1
                  FROM G_DOSSIER      CNTR,
                       G_DOSSIER      DCMP,
                       G_DOSSIER      CMP,
                       G_ELEMFI       WRITE_OFF,
                       T_INTERVENANTS DB
                 WHERE CNTR.REFDOSS = :B2
                   AND DCMP.REFLOT = CNTR.REFDOSS
                   AND CMP.REFLOT = DCMP.REFDOSS
                   AND WRITE_OFF.REFDOSS = CMP.REFDOSS
                   AND WRITE_OFF.TYPE = 'WRITE OFF'
                   AND DB.REFDOSS = CMP.REFDOSS
                   AND DB.REFTYPE = 'DB'
                   AND DB.REFINDIVIDU = :B1 );

/********************************New SQL*******************************************/
/********************************New Metrics***************************************/
/*
Plan hash value: 3555348398
-------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                | Name                           | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  |
-------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT         |                                |      1 |        |    14 (100)|      0 |00:00:00.01 |      12 |      1 |
|*  1 |  FILTER                  |                                |      1 |        |            |      0 |00:00:00.01 |      12 |      1 |
|   2 |   FAST DUAL              |                                |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|   3 |   SORT UNIQUE            |                                |      1 |      2 |    12  (17)|      0 |00:00:00.01 |      12 |      1 |
|   4 |    UNION-ALL             |                                |      1 |        |            |      0 |00:00:00.01 |      12 |      1 |
|   5 |     NESTED LOOPS SEMI    |                                |      1 |      1 |     7  (29)|      0 |00:00:00.01 |       8 |      0 |
|   6 |      NESTED LOOPS        |                                |      1 |      1 |     6  (34)|      1 |00:00:00.01 |       4 |      0 |
|   7 |       VIEW               |                                |      1 |      3 |     5  (40)|      1 |00:00:00.01 |       2 |      0 |
|   8 |        SORT UNIQUE       |                                |      1 |      3 |     5  (40)|      1 |00:00:00.01 |       2 |      0 |
|   9 |         UNION-ALL        |                                |      1 |        |            |      1 |00:00:00.01 |       2 |      0 |
|  10 |          FAST DUAL       |                                |      1 |      1 |     2   (0)|      1 |00:00:00.01 |       0 |      0 |
|* 11 |          INDEX RANGE SCAN| REFHIERARCHIE_IDX              |      1 |      2 |     1   (0)|      0 |00:00:00.01 |       2 |      0 |
|* 12 |       INDEX RANGE SCAN   | INT_REFDOSS                    |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       2 |      0 |
|* 13 |      INDEX RANGE SCAN    | TEST_DD_INDEX                  |      1 |   6319 |     1   (0)|      0 |00:00:00.01 |       4 |      0 |
|  14 |     NESTED LOOPS SEMI    |                                |      1 |      1 |     5   (0)|      0 |00:00:00.01 |       4 |      1 |
|  15 |      NESTED LOOPS SEMI   |                                |      1 |      1 |     4   (0)|      0 |00:00:00.01 |       4 |      1 |
|  16 |       NESTED LOOPS       |                                |      1 |      1 |     3   (0)|      0 |00:00:00.01 |       4 |      1 |
|  17 |        NESTED LOOPS      |                                |      1 |      1 |     2   (0)|      0 |00:00:00.01 |       4 |      1 |
|* 18 |         INDEX UNIQUE SCAN| DOS_REFDOSS                    |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       2 |      0 |
|* 19 |         INDEX RANGE SCAN | INT_INDIV                      |      1 |      1 |     1   (0)|      0 |00:00:00.01 |       2 |      1 |
|* 20 |        INDEX RANGE SCAN  | DOS_REFDOSS_REFLOT_IDX         |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 21 |       INDEX RANGE SCAN   | DOS_REFDOSS_REFLOT_IDX         |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 22 |      INDEX RANGE SCAN    | G_ELEMFI_DOS_TYP_FG02_CODE_IDX |      0 |   3462 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
-------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   1 - filter( IS NOT NULL)
  11 - access("REFHIERARCHIE"=:B2)
  12 - access("DOS"."REFDOSS"="CLIENT"."REFDOSS" AND "CLIENT"."REFTYPE"='CL' AND "CLIENT"."REFINDIVIDU"=:B1)
  13 - access("ACC"."CODEOPER"='WRITE_OFF_FIU' AND "ACC"."EL3"=:B1 AND "ACC"."EXTREF2"="CLIENT"."REFDOSS")
  18 - access("CNTR"."REFDOSS"=:B2)
  19 - access("DB"."REFINDIVIDU"=:B1 AND "DB"."REFTYPE"='DB')
  20 - access("DB"."REFDOSS"="CMP"."REFDOSS")
       filter("CMP"."REFLOT" IS NOT NULL)
  21 - access("CMP"."REFLOT"="DCMP"."REFDOSS" AND "DCMP"."REFLOT"=:B2)
  22 - access("WRITE_OFF"."REFDOSS"="CMP"."REFDOSS" AND "WRITE_OFF"."TYPE"='WRITE OFF')
*/
/********************************New Metrics***************************************/

/********************************Index statistics**********************************/

/********************************Other SQLs****************************************/          
/*

*/ 
/********************************Other SQLs****************************************/              
