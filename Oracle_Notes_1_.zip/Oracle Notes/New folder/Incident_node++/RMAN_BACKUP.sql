﻿#########RMAN COMMANDS#########

RMAN>SHOW ALL;			---WILL SHOW ALL PARAMETERS

RMAN>CONFIGURE RETENTION POLICY TO RECOVERY WINDOW OF 7 DAYS;		---AFTER 7 DAYS ALL BACKUPS WILL BE MARK AS OBSOLETE

RMAN>CONFIGURE CONTROLFILE AUTOBACKUP ON;			---WHILE WE ARE PERFORMING A BACKUP TO AUTOMATICALLY BACKUP THE CONTROLFILE

RMAN>BACKUP DATABASE;			---WILL BACKUP THE ENTIRE DATABASE

RMAN>BACKUP AS COPY DATABASE;			--- WILL BACKUP ONLY THE DATAFILES

RMAN>BACKUP CURRENT CONTROLFILE;

RMAN>BACKUP AS BACKUPSET DATAFILE			---WILL BACKUP ONLY THESE DATAFILES
				'ORACLE_HOME/oradata/users01.dbf',
				'ORACLE_HOME/oradata/tbs1.dbf';
				
RMAN>BACKUP ARCHIVELOG COMPLETION TIME BETWEEN 'SYSDATE-30' AND 'SYSDATE';	---WILL BACKUP ALL ARCHIVELOGS WHCIH WERE CREATED DURING THE LAST 30 DAYS

RMAN>BACKUP TABLESPACE SYSTEM, USERS, TBS1;		---WILL BACKUP ONLY THESE 3 TABLESPACES

RMAN>BACKUP SPFILE;			---WILL BACKUP ONLY THE SPFILE

RMAN>LIST BACKUP OF DATABASE;		---WILL LIST ALL BACKUPS WHICH WERE MADE RECENTLY

RMAN>BACKUP INCREMENTAL LEVEL 0 DATABASE;		---WILL START LEVEL 1 DIFFERENTIAL BACKUP

RMAN>BACKUP INCREMENTAL LEVEL 1 CUMULATIVE DATABASE;		---

RMAN>BACKUP INCREMENTAL LEVEL 1 TABLESPACE SYSTEM DATAFILE 'ora_home/oradata/trgt/tbs1.dbf';	
--OSVEN CHE SHTE NAPRAVI LEVEL 1 DIFFERENTIAL BACKUP DORI DA NQMA NIKAKVI PROMENI SHTE BACKUP-NE I TABLESPACE SYSTEM KAKTO I POSOCHENIQT DATAFILE!


### Information for all tablespace and structure
RMAN> report schema;


RMAN> sql 'alter system archive log current ';


rman full database backup script

configure backup optimization on; 
configure controlfile autobackup on; 
configure controlfile autobackup format for device type disk to '/archiva/backup/%F'; 
configure maxsetsize to unlimited; 
configure device type disk parallelism 4; 
run 
{ 
allocate channel c1 type disk format '/archiva/backup/%I-%Y%M%D-%U' maxpiecesize 3G; 
allocate channel c2 type disk format '/archiva/backup/%I-%Y%M%D-%U' maxpiecesize 3G; 
allocate channel c3 type disk format '/archiva/backup/%I-%Y%M%D-%U' maxpiecesize 3G; 
allocate channel c4 type disk format '/archiva/backup/%I-%Y%M%D-%U' maxpiecesize 3G; 
backup as compressed backupset incremental level 0 check logical database plus archivelog; 
release channel c1 ; 
release channel c2 ; 
release channel c3 ; 
release channel c4 ; 
}


RMAN> BACKUP VALIDATE DATABASE ARCHIVELOG ALL;
The process outputs the same information you would see during a backup, but no backup is created. Any block corruptions are visible in the V$DATABASE_BLOCK_CORRUPTION view, as well as in the RMAN output.

By default the command only checks for physical corruption. Add the CHECK LOGICAL clause to include checks for logical corruption.
RMAN> BACKUP VALIDATE CHECK LOGICAL DATABASE ARCHIVELOG ALL;

#####
DELETE FORCE NOPROMPT ARCHIVELOG ALL BACKED UP 1 TIMES TO DEVICE TYPE disk; 


delete archive older than 1 day

#####
DELETE ARCHIVELOG ALL COMPLETED BEFORE 'sysdate-1'; 
CROSSCHECK ARCHIVELOG ALL; 
DELETE EXPIRED ARCHIVELOG ALL;

#####
backup archivelogs using RMAN

---  Backup all archivelogs known to controlfile 

backup archivelog all; 

-- Backup all archivelogs known to controlfile and delete them once backed up 

backup archivelog all delete input ; 

-- Backup archivlogs known to controlfile and the logs which haven't backed up once also 

backup archivelog all not backed up 1 times;



Copy archive from ASM to Mount point

--- Copy archive log from ASM to regular mount point using RMAN: 
--- Connect to RMAN in RAC db 

RMAN> copy archivelog '+B2BSTARC/thread_2_seq_34.933' to '/data/thread_2_seq_34.933';


backup archive between 2 sequence number

--- For taking backup of archivelog between seq number 1000 to 1050 

RMAN> backup format '/archive/%d_%s_%p_%c_%t.arc.bkp' 
archivelog from sequence 1000 until sequence 1050; 

-- For RAC ,need to mention the thread number also 

RMAN> backup format '/archive/%d_%s_%p_%c_%t.arc.bkp' 
archivelog from sequence 1000 until sequence 1050 thread 2;

Monitor rman backup progress

SELECT SID, SERIAL#, CONTEXT, SOFAR, TOTALWORK, 
ROUND(SOFAR/TOTALWORK*100,2) "%_COMPLETE" 
FROM V$SESSION_LONGOPS 
WHERE OPNAME LIKE 'RMAN%' 
AND OPNAME NOT LIKE '%aggregate%' 
AND TOTALWORK != 0 
AND SOFAR <> TOTALWORK;




@@@@@@@@@@@@@@@@@@@@@@@@@----FULL------BACKUP----------@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@

rman target /
report schema;
show retention policy; --- ще ни покаже колко време пази бекъпите
delete obsolete; - ще изтрие бекъпи които повече не ни трябват
backup database; --- a complete full backup set of the database into one backup file if there are pluggable containers - they will also be included
list backup; --- show the different types of backups we have

backup as copy database plus archivelog delete input --- will backup everything and after than delete the archived logs to free space


@@@@@@@@@@@@@@@@@@@@@@@@@----PARTIAL------BACKUP----------@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@


IN PLUGGABLE DATABASE

RMAN TARGET SYS/PASSWORD@PDB1

BACKUP TABLESPACE HR_EMPLOYEES; --- WILL BACKUP JUST THIS TABLESPACE

IN ROOT CONTAINER:

RMAN TARGET /

BACKUP TABLESPACE PDB1:HR_EMPLOYEES; --- WILL BACKUP THIS TABLESPACE FROM PDB1


--------------------------------------------------

[oracle(WEBEDI_P)@clv100587:/home/oracle]
RMAN> CONFIGURE RETENTION POLICY TO RECOVERY WINDOW OF 10 DAYS;

old RMAN configuration parameters:
CONFIGURE RETENTION POLICY TO RECOVERY WINDOW OF 14 DAYS;
new RMAN configuration parameters:
CONFIGURE RETENTION POLICY TO RECOVERY WINDOW OF 10 DAYS;
new RMAN configuration parameters are successfully stored 

