#### SERVERS ##############

##INFRA

iracp31.ssn.entsvcs.com
iracp32.ssn.entsvcs.com
iracp33.ssn.entsvcs.com
iracp34.ssn.entsvcs.com


##### Catalog DB za OGE
Database : OGERP1PS
Catalog DB:
User_name: OGERP1PDG_RMAN
Password: pwd4DB_RMAN1234
Service: RCATDG2.WARLD