/********************************************************************************
*********       E-mail subject: LBPDEV-7024
*********             Instance: LAGOVAL
*********          Description: 
Problem:
It takes more than a minute to save a Assignment form on LAGOVAL.

Analysis:
According to the provided HAR file, we found in the V9 BE logs the service behind the slowness is the call of the service_bus.CheckCession.
We checked the in the ASH for session with the SID/SERIAL written in the BE log and found that the TOP 2 SQLs in this session are 7rh877vhwc18j, which is 
from SE variable ref_cpt1 and cg1g913p76cc8, which is from SE variable ref_cpt4.
These SQLs are responsible for ~ 29% of the time. The check for the refdoss in both of them is made using OR operators, which can be optimized by using union 
instead of the ORs as it is shown in the New SQLs section below.

Suggestion:
Please change the queries as it is shown in the New SQL section below.

*********               SQL_ID: 7rh877vhwc18j, cg1g913p76cc8
*********      Program/Package: 
*********              Request: Ivailo Vasiliev
*********               Author: Dimitar Dimitrov
********* Received e-mail date: 16/07/2024
*********      Resolution date: 16/07/2024
*********  Trace old file here: \\epox\specifs\performance\tmp\
*********  Trace new file here:
***********************************************************************************/

/********************************OLD SQL*******************************************/

-- 7rh877vhwc18j, 

var REFIND VARCHAR2(32);
exec :REFIND := 'A6007LVZ';
var REFDOS VARCHAR2(32);
exec :REFDOS := '2407160032';

select refcptbq 
  from ( select C.refcptbq 
            from g_piecedet D,
                 g_piece P, 
                 g_individu G, 
                 g_dossier V, 
                 g_cptbq C 
           where (    P.refdoss = ( select reflot 
                                      from g_dossier
                                     where ( refdoss = ( select reflot 
                                                           from g_dossier 
                                                          where refdoss = :refdos ) ) ) 
                   or P.refdoss = :refdos ) 
             and P.typpiece = 'CONTRAT' 
             and P.refpiece = D.refpiece 
             and D.type = 'AUTRE_COMPTES' 
             and G.refindividu = :refind  
             and C.refindivbq = D.str5 
             and nvl(G.pays, 'XX') = nvl(D.Str1, 'X') 
             and V.refdoss = :refdos  
             and V.devise = nvl(D.Str2, 'X') 
             and nvl(D.fg01,'N') = 'N' 
             and C.refcptbq = D.nb01 
             and C.etat = 'V' 
           order by D.imx_un_id )
 where rownum <2;


-- cg1g913p76cc8

var REFIND VARCHAR2(32);
exec :REFIND := 'A6007LVZ';
var REFDOS VARCHAR2(32);
exec :REFDOS := '2407160032';
  
select refcptbq
  from (select C.refcptbq
          from g_piecedet D, g_piece P, g_individu G, g_dossier V, g_cptbq C
         where (P.refdoss =
               (select reflot
                   from g_dossier
                  where (refdoss =
                        (select reflot from g_dossier where refdoss = :refdos))) or
               P.refdoss = :refdos)
           and P.typpiece = 'CONTRAT'
           and P.refpiece = D.refpiece
           and D.type = 'AUTRE_COMPTES'
           and G.refindividu = :refind
           and C.refindivbq = D.str5
           and D.Str1 is null
           and V.refdoss = :refdos
           and V.devise = nvl(D.Str2, 'X')
           and C.refcptbq = D.nb01
           and nvl(D.fg01, 'N') = 'N'
           and C.etat = 'V'
         order by D.imx_un_id)
 where rownum < 2;
/********************************OLD SQL*******************************************/
/********************************OLD Metrics***************************************/
/*
2024-07-16 13:43:30,950 DEBUG [ajp-nio-127.0.0.1-42623-exec-14] {URI=/svc/assignment-forms/entry/A70B5Z5J/validation-assignment-form, sid=fb99f9d8ad40, uid=Automation_User} StmtLog Cid:954|14960#@1, Query:["CALL service_bus.CheckCession(p_cession_reference => ? )"], Params:[(1=A70B5Z5J)] Time:57890


MODULE                           CLIENT_ID       ACTION                    SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- --------------- ------------------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
service_bus_serverC2B0110AD35D7C Automation_User 1/954/1641556                                             207      22172                      2024/07/16 13:42:34  2024/07/16 13:43:30          56                   80 +000000000 00:00:56.022 58%


MODULE                           CLIENT_ID       ACTION                    SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- --------------- ------------------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
service_bus_serverC2B0110AD35D7C Automation_User 1/954/1641556             7rh877vhwc18j 4017555910        207      22172 db file sequential r 2024/07/16 13:43:11  2024/07/16 13:43:20          10                    1 +000000000 00:00:09.011 18%
A87DA4C5A8699ADBD3

service_bus_serverC2B0110AD35D7C Automation_User 1/954/1641556             cg1g913p76cc8 3961138705        207      22172 db file sequential r 2024/07/16 13:43:21  2024/07/16 13:43:26           6                    1 +000000000 00:00:05.001 11%
A87DA4C5A8699ADBD3

service_bus_serverC2B0110AD35D7C Automation_User 1/954/1641556             f83d7mkuxx8jn          0        207      22172                      2024/07/16 13:42:47  2024/07/16 13:43:01           5                    2 +000000000 00:00:14.008 9%
A87DA4C5A8699ADBD3

service_bus_serverC2B0110AD35D7C Automation_User 1/954/1641556             726cc8gyachzh 2916664219        207      22172 ON CPU               2024/07/16 13:42:52  2024/07/16 13:42:53           2                      +000000000 00:00:01.003 4%
A87DA4C5A8699ADBD3

service_bus_serverC2B0110AD35D7C Automation_User 1/954/1641556             2md3c7wjxqtxt 3663398237        207      22172 db file sequential r 2024/07/16 13:43:07  2024/07/16 13:43:07           1                    1 +000000000 00:00:00.000 2%
A87DA4C5A8699ADBD3

service_bus_serverC2B0110AD35D7C Automation_User 1/954/1641556             2vbm5t04qkd80 1081584323        207      22172 ON CPU               2024/07/16 13:43:28  2024/07/16 13:43:28           1                      +000000000 00:00:00.000 2%
A87DA4C5A8699ADBD3

service_bus_serverC2B0110AD35D7C Automation_User 1/954/1641556             304zcz41juk8h 1829869798        207      22172 ON CPU               2024/07/16 13:42:38  2024/07/16 13:42:38           1                      +000000000 00:00:00.000 2%
A87DA4C5A8699ADBD3


-- 7rh877vhwc18j

Plan hash value: 4017555910
--------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                  | Name                   | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers |
--------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                           |                        |      1 |        |    13 (100)|      0 |00:00:00.01 |    4668 |
|*  1 |  COUNT STOPKEY                             |                        |      1 |        |            |      0 |00:00:00.01 |    4668 |
|   2 |   VIEW                                     |                        |      1 |      1 |    13   (8)|      0 |00:00:00.01 |    4668 |
|*  3 |    SORT ORDER BY STOPKEY                   |                        |      1 |      1 |    13   (8)|      0 |00:00:00.01 |    4668 |
|   4 |     NESTED LOOPS                           |                        |      1 |      1 |    12   (0)|      0 |00:00:00.01 |    4668 |
|   5 |      NESTED LOOPS                          |                        |      1 |      1 |    12   (0)|      0 |00:00:00.01 |    4668 |
|   6 |       NESTED LOOPS                         |                        |      1 |      1 |    11   (0)|      0 |00:00:00.01 |    4668 |
|   7 |        NESTED LOOPS                        |                        |      1 |      1 |    10   (0)|      1 |00:00:00.01 |    4664 |
|   8 |         NESTED LOOPS                       |                        |      1 |      1 |     2   (0)|      1 |00:00:00.01 |       7 |
|   9 |          TABLE ACCESS BY INDEX ROWID       | G_DOSSIER              |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       4 |
|* 10 |           INDEX UNIQUE SCAN                | DOS_REFDOSS            |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       2 |
|  11 |          TABLE ACCESS BY INDEX ROWID       | G_INDIVIDU             |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |
|* 12 |           INDEX UNIQUE SCAN                | IND_REFINDIV           |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       2 |
|* 13 |         TABLE ACCESS BY INDEX ROWID BATCHED| G_PIECE                |      1 |      1 |     8   (0)|      1 |00:00:00.01 |    4657 |
|* 14 |          INDEX RANGE SCAN                  | PIECE_TYP_MT43_IDX     |      1 |   5079 |     1   (0)|   5113 |00:00:00.01 |      27 |
|  15 |          NESTED LOOPS                      |                        |      1 |      1 |     2   (0)|      1 |00:00:00.01 |       4 |
|* 16 |           INDEX RANGE SCAN                 | DOS_REFDOSS_REFLOT_IDX |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       2 |
|* 17 |           INDEX RANGE SCAN                 | DOS_REFDOSS_REFLOT_IDX |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       2 |
|* 18 |        TABLE ACCESS BY INDEX ROWID BATCHED | G_PIECEDET             |      1 |      1 |     1   (0)|      0 |00:00:00.01 |       4 |
|* 19 |         INDEX RANGE SCAN                   | G_PIECEDET_REFP        |      1 |      1 |     1   (0)|      0 |00:00:00.01 |       4 |
|* 20 |       INDEX RANGE SCAN                     | PK_CPTBQ_REFCPTBQ      |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 21 |      TABLE ACCESS BY INDEX ROWID           | G_CPTBQ                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
--------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   1 - filter(ROWNUM<2)
   3 - filter(ROWNUM<2)
  10 - access("V"."REFDOSS"=:REFDOS)
  12 - access("G"."REFINDIVIDU"=:REFIND)
  13 - filter(("P"."REFDOSS"=:REFDOS OR "P"."REFDOSS"=))
  14 - access("P"."TYPPIECE"='CONTRAT')
  16 - access("REFDOSS"=:REFDOS)
       filter("REFLOT" IS NOT NULL)
  17 - access("REFDOSS"="REFLOT")
  18 - filter(("D"."STR5" IS NOT NULL AND "V"."DEVISE"=NVL("D"."STR2",'X') AND NVL("G"."PAYS",'XX')=NVL("D"."STR1",'X') AND
              NVL("D"."FG01",'N')='N'))
  19 - access("P"."REFPIECE"="D"."REFPIECE" AND "D"."TYPE"='AUTRE_COMPTES')
       filter("D"."NB01" IS NOT NULL)
  20 - access("C"."REFCPTBQ"="D"."NB01")
  21 - filter(("C"."REFINDIVBQ"="D"."STR5" AND "C"."ETAT"='V'))


-- cg1g913p76cc8

Plan hash value: 3961138705
-----------------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                  | Name                   | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  |
-----------------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                           |                        |      1 |        |    13 (100)|      0 |00:00:19.96 |    4667 |   3949 |
|*  1 |  COUNT STOPKEY                             |                        |      1 |        |            |      0 |00:00:19.96 |    4667 |   3949 |
|   2 |   VIEW                                     |                        |      1 |      1 |    13   (8)|      0 |00:00:19.96 |    4667 |   3949 |
|*  3 |    SORT ORDER BY STOPKEY                   |                        |      1 |      1 |    13   (8)|      0 |00:00:19.96 |    4667 |   3949 |
|   4 |     NESTED LOOPS                           |                        |      1 |      1 |    12   (0)|      0 |00:00:19.96 |    4667 |   3949 |
|   5 |      NESTED LOOPS                          |                        |      1 |      1 |    12   (0)|      0 |00:00:19.96 |    4667 |   3949 |
|   6 |       NESTED LOOPS                         |                        |      1 |      1 |    11   (0)|      0 |00:00:19.96 |    4667 |   3949 |
|   7 |        NESTED LOOPS                        |                        |      1 |      1 |    10   (0)|      1 |00:00:19.95 |    4663 |   3948 |
|   8 |         NESTED LOOPS                       |                        |      1 |      1 |     2   (0)|      1 |00:00:00.01 |       6 |      0 |
|   9 |          TABLE ACCESS BY INDEX ROWID       | G_DOSSIER              |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       4 |      0 |
|* 10 |           INDEX UNIQUE SCAN                | DOS_REFDOSS            |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       2 |      0 |
|* 11 |          INDEX UNIQUE SCAN                 | IND_REFINDIV           |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       2 |      0 |
|* 12 |         TABLE ACCESS BY INDEX ROWID BATCHED| G_PIECE                |      1 |      1 |     8   (0)|      1 |00:00:19.95 |    4657 |   3948 |
|* 13 |          INDEX RANGE SCAN                  | PIECE_TYP_MT43_IDX     |      1 |   5079 |     1   (0)|   5113 |00:00:00.23 |      27 |     26 |
|  14 |          NESTED LOOPS                      |                        |      1 |      1 |     2   (0)|      1 |00:00:00.01 |       4 |      0 |
|* 15 |           INDEX RANGE SCAN                 | DOS_REFDOSS_REFLOT_IDX |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       2 |      0 |
|* 16 |           INDEX RANGE SCAN                 | DOS_REFDOSS_REFLOT_IDX |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       2 |      0 |
|* 17 |        TABLE ACCESS BY INDEX ROWID BATCHED | G_PIECEDET             |      1 |      1 |     1   (0)|      0 |00:00:00.01 |       4 |      1 |
|* 18 |         INDEX RANGE SCAN                   | G_PIECEDET_REFP        |      1 |      1 |     1   (0)|      0 |00:00:00.01 |       4 |      1 |
|* 19 |       INDEX RANGE SCAN                     | PK_CPTBQ_REFCPTBQ      |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 20 |      TABLE ACCESS BY INDEX ROWID           | G_CPTBQ                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
-----------------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   1 - filter(ROWNUM<2)
   3 - filter(ROWNUM<2)
  10 - access("V"."REFDOSS"=:REFDOS)
  11 - access("G"."REFINDIVIDU"=:REFIND)
  12 - filter(("P"."REFDOSS"=:REFDOS OR "P"."REFDOSS"=))
  13 - access("P"."TYPPIECE"='CONTRAT')
  15 - access("REFDOSS"=:REFDOS)
       filter("REFLOT" IS NOT NULL)
  16 - access("REFDOSS"="REFLOT")
  17 - filter(("D"."STR5" IS NOT NULL AND "D"."STR1" IS NULL AND "V"."DEVISE"=NVL("D"."STR2",'X') AND NVL("D"."FG01",'N')='N'))
  18 - access("P"."REFPIECE"="D"."REFPIECE" AND "D"."TYPE"='AUTRE_COMPTES')
       filter("D"."NB01" IS NOT NULL)
  19 - access("C"."REFCPTBQ"="D"."NB01")
  20 - filter(("C"."REFINDIVBQ"="D"."STR5" AND "C"."ETAT"='V'))
*/
/********************************OLD Metrics***************************************/

/********************************New SQL*******************************************/

-- 7rh877vhwc18j

select refcptbq 
  from ( select C.refcptbq 
            from g_piecedet D,
                 g_piece P, 
                 g_individu G, 
                 g_dossier V, 
                 g_cptbq C 
           where P.refdoss in ( select reflot 
                                      from g_dossier
                                     where ( refdoss = ( select reflot 
                                                           from g_dossier 
                                                          where refdoss = :refdos ) )  
                   union 
                   select :refdos 
                     from dual ) 
             and P.typpiece = 'CONTRAT' 
             and P.refpiece = D.refpiece 
             and D.type = 'AUTRE_COMPTES' 
             and G.refindividu = :refind  
             and C.refindivbq = D.str5 
             and nvl(G.pays, 'XX') = nvl(D.Str1, 'X') 
             and V.refdoss = :refdos  
             and V.devise = nvl(D.Str2, 'X') 
             and nvl(D.fg01,'N') = 'N' 
             and C.refcptbq = D.nb01 
             and C.etat = 'V' 
           order by D.imx_un_id )
 where rownum <2;


-- cg1g913p76cc8

select refcptbq
  from (select C.refcptbq
          from g_piecedet D, 
               g_piece P, 
               g_individu G, 
               g_dossier V, 
               g_cptbq C
         where P.refdoss in ( select reflot
                                from g_dossier
                               where ( refdoss = ( select reflot 
                                                     from g_dossier 
                                                    where refdoss = :refdos ) )  
                union                                    
               select :refdos 
                 from dual )
           and P.typpiece = 'CONTRAT'
           and P.refpiece = D.refpiece
           and D.type = 'AUTRE_COMPTES'
           and G.refindividu = :refind
           and C.refindivbq = D.str5
           and D.Str1 is null
           and V.refdoss = :refdos
           and V.devise = nvl(D.Str2, 'X')
           and C.refcptbq = D.nb01
           and nvl(D.fg01, 'N') = 'N'
           and C.etat = 'V'
         order by D.imx_un_id)
 where rownum < 2;
/********************************New SQL*******************************************/
/********************************New Metrics***************************************/
/*

-- 7rh877vhwc18j

Plan hash value: 722405692
-----------------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                  | Name                   | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  |
-----------------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                           |                        |      1 |        |    11 (100)|      0 |00:00:00.06 |      22 |      5 |
|*  1 |  COUNT STOPKEY                             |                        |      1 |        |            |      0 |00:00:00.06 |      22 |      5 |
|   2 |   VIEW                                     |                        |      1 |      1 |    11  (19)|      0 |00:00:00.06 |      22 |      5 |
|*  3 |    SORT ORDER BY STOPKEY                   |                        |      1 |      1 |    11  (19)|      0 |00:00:00.06 |      22 |      5 |
|   4 |     NESTED LOOPS                           |                        |      1 |      1 |    10  (10)|      0 |00:00:00.06 |      22 |      5 |
|   5 |      NESTED LOOPS                          |                        |      1 |      1 |    10  (10)|      0 |00:00:00.06 |      22 |      5 |
|   6 |       NESTED LOOPS                         |                        |      1 |      1 |     9  (12)|      0 |00:00:00.06 |      22 |      5 |
|   7 |        NESTED LOOPS                        |                        |      1 |      1 |     8  (13)|      1 |00:00:00.05 |      18 |      4 |
|   8 |         NESTED LOOPS                       |                        |      1 |      2 |     7  (15)|      2 |00:00:00.02 |      11 |      2 |
|   9 |          NESTED LOOPS                      |                        |      1 |      1 |     2   (0)|      1 |00:00:00.01 |       7 |      1 |
|  10 |           TABLE ACCESS BY INDEX ROWID      | G_DOSSIER              |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       4 |      0 |
|* 11 |            INDEX UNIQUE SCAN               | DOS_REFDOSS            |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       2 |      0 |
|  12 |           TABLE ACCESS BY INDEX ROWID      | G_INDIVIDU             |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |      1 |
|* 13 |            INDEX UNIQUE SCAN               | IND_REFINDIV           |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       2 |      0 |
|  14 |          VIEW                              | VW_NSO_2               |      1 |      2 |     5  (20)|      2 |00:00:00.01 |       4 |      1 |
|  15 |           SORT UNIQUE                      |                        |      1 |      2 |     5  (20)|      2 |00:00:00.01 |       4 |      1 |
|  16 |            UNION-ALL                       |                        |      1 |        |            |      2 |00:00:00.01 |       4 |      1 |
|  17 |             NESTED LOOPS                   |                        |      1 |      1 |     2   (0)|      1 |00:00:00.01 |       4 |      1 |
|* 18 |              INDEX RANGE SCAN              | DOS_REFDOSS_REFLOT_IDX |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       2 |      1 |
|* 19 |              INDEX RANGE SCAN              | DOS_REFDOSS_REFLOT_IDX |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       2 |      0 |
|  20 |             FAST DUAL                      |                        |      1 |      1 |     2   (0)|      1 |00:00:00.01 |       0 |      0 |
|  21 |         TABLE ACCESS BY INDEX ROWID BATCHED| G_PIECE                |      2 |      1 |     1   (0)|      1 |00:00:00.03 |       7 |      2 |
|* 22 |          INDEX RANGE SCAN                  | PIE_REFDOSS            |      2 |      1 |     1   (0)|      1 |00:00:00.03 |       6 |      2 |
|* 23 |        TABLE ACCESS BY INDEX ROWID BATCHED | G_PIECEDET             |      1 |      1 |     1   (0)|      0 |00:00:00.01 |       4 |      1 |
|* 24 |         INDEX RANGE SCAN                   | G_PIECEDET_REFP        |      1 |      1 |     1   (0)|      0 |00:00:00.01 |       4 |      1 |
|* 25 |       INDEX RANGE SCAN                     | PK_CPTBQ_REFCPTBQ      |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 26 |      TABLE ACCESS BY INDEX ROWID           | G_CPTBQ                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
-----------------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   1 - filter(ROWNUM<2)
   3 - filter(ROWNUM<2)
  11 - access("V"."REFDOSS"=:REFDOS)
  13 - access("G"."REFINDIVIDU"=:REFIND)
  18 - access("REFDOSS"=:REFDOS)
       filter("REFLOT" IS NOT NULL)
  19 - access("REFDOSS"="REFLOT")
  22 - access("P"."REFDOSS"="REFLOT" AND "P"."TYPPIECE"='CONTRAT')
  23 - filter(("D"."STR5" IS NOT NULL AND "V"."DEVISE"=NVL("D"."STR2",'X') AND NVL("G"."PAYS",'XX')=NVL("D"."STR1",'X') AND
              NVL("D"."FG01",'N')='N'))
  24 - access("P"."REFPIECE"="D"."REFPIECE" AND "D"."TYPE"='AUTRE_COMPTES')
       filter("D"."NB01" IS NOT NULL)
  25 - access("C"."REFCPTBQ"="D"."NB01")
  26 - filter(("C"."REFINDIVBQ"="D"."STR5" AND "C"."ETAT"='V'))
  

-- cg1g913p76cc8

Plan hash value: 2694537133
-----------------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                  | Name                   | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  |
-----------------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                           |                        |      1 |        |    11 (100)|      0 |00:00:00.03 |      21 |      2 |
|*  1 |  COUNT STOPKEY                             |                        |      1 |        |            |      0 |00:00:00.03 |      21 |      2 |
|   2 |   VIEW                                     |                        |      1 |      1 |    11  (19)|      0 |00:00:00.03 |      21 |      2 |
|*  3 |    SORT ORDER BY STOPKEY                   |                        |      1 |      1 |    11  (19)|      0 |00:00:00.03 |      21 |      2 |
|   4 |     NESTED LOOPS                           |                        |      1 |      1 |    10  (10)|      0 |00:00:00.03 |      21 |      2 |
|   5 |      NESTED LOOPS                          |                        |      1 |      1 |    10  (10)|      0 |00:00:00.03 |      21 |      2 |
|   6 |       NESTED LOOPS                         |                        |      1 |      1 |     9  (12)|      0 |00:00:00.03 |      21 |      2 |
|   7 |        NESTED LOOPS                        |                        |      1 |      1 |     8  (13)|      1 |00:00:00.03 |      17 |      2 |
|   8 |         NESTED LOOPS                       |                        |      1 |      2 |     7  (15)|      2 |00:00:00.01 |      10 |      0 |
|   9 |          NESTED LOOPS                      |                        |      1 |      1 |     2   (0)|      1 |00:00:00.01 |       6 |      0 |
|  10 |           TABLE ACCESS BY INDEX ROWID      | G_DOSSIER              |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       4 |      0 |
|* 11 |            INDEX UNIQUE SCAN               | DOS_REFDOSS            |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       2 |      0 |
|* 12 |           INDEX UNIQUE SCAN                | IND_REFINDIV           |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       2 |      0 |
|  13 |          VIEW                              | VW_NSO_2               |      1 |      2 |     5  (20)|      2 |00:00:00.01 |       4 |      0 |
|  14 |           SORT UNIQUE                      |                        |      1 |      2 |     5  (20)|      2 |00:00:00.01 |       4 |      0 |
|  15 |            UNION-ALL                       |                        |      1 |        |            |      2 |00:00:00.01 |       4 |      0 |
|  16 |             NESTED LOOPS                   |                        |      1 |      1 |     2   (0)|      1 |00:00:00.01 |       4 |      0 |
|* 17 |              INDEX RANGE SCAN              | DOS_REFDOSS_REFLOT_IDX |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       2 |      0 |
|* 18 |              INDEX RANGE SCAN              | DOS_REFDOSS_REFLOT_IDX |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       2 |      0 |
|  19 |             FAST DUAL                      |                        |      1 |      1 |     2   (0)|      1 |00:00:00.01 |       0 |      0 |
|  20 |         TABLE ACCESS BY INDEX ROWID BATCHED| G_PIECE                |      2 |      1 |     1   (0)|      1 |00:00:00.03 |       7 |      2 |
|* 21 |          INDEX RANGE SCAN                  | PIE_REFDOSS            |      2 |      1 |     1   (0)|      1 |00:00:00.03 |       6 |      2 |
|* 22 |        TABLE ACCESS BY INDEX ROWID BATCHED | G_PIECEDET             |      1 |      1 |     1   (0)|      0 |00:00:00.01 |       4 |      0 |
|* 23 |         INDEX RANGE SCAN                   | G_PIECEDET_REFP        |      1 |      1 |     1   (0)|      0 |00:00:00.01 |       4 |      0 |
|* 24 |       INDEX RANGE SCAN                     | PK_CPTBQ_REFCPTBQ      |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 25 |      TABLE ACCESS BY INDEX ROWID           | G_CPTBQ                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
-----------------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   1 - filter(ROWNUM<2)
   3 - filter(ROWNUM<2)
  11 - access("V"."REFDOSS"=:REFDOS)
  12 - access("G"."REFINDIVIDU"=:REFIND)
  17 - access("REFDOSS"=:REFDOS)
       filter("REFLOT" IS NOT NULL)
  18 - access("REFDOSS"="REFLOT")
  21 - access("P"."REFDOSS"="REFLOT" AND "P"."TYPPIECE"='CONTRAT')
  22 - filter(("D"."STR5" IS NOT NULL AND "D"."STR1" IS NULL AND "V"."DEVISE"=NVL("D"."STR2",'X') AND NVL("D"."FG01",'N')='N'))
  23 - access("P"."REFPIECE"="D"."REFPIECE" AND "D"."TYPE"='AUTRE_COMPTES')
       filter("D"."NB01" IS NOT NULL)
  24 - access("C"."REFCPTBQ"="D"."NB01")
  25 - filter(("C"."REFINDIVBQ"="D"."STR5" AND "C"."ETAT"='V')) 
*/
/********************************New Metrics***************************************/

/********************************Index statistics**********************************/

/********************************Other SQLs****************************************/          
/*

*/ 
/********************************Other SQLs****************************************/              
