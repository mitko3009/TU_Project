################################################
SQL> select sql_text, executions from v$sql where cpu_time > 20000;   --- shte pokaje koi SQL natovarvat nai-mnogo CPU


############################################################################################
################################################ MAXIMUM CURSOR ############################
############################################################################################

OGE
DBSPI-0031: 1.00 users approaching maximum configured cursors for MENAP >=95% of max, most serious is VNGSYS at 100.00% of max. [Policy:DBMON-DBSPI-0031-ARM]

dbspicao -m31 -r1 -i MENAP  --- shte pokaje na nqkoi user 100% po negoviq sid tyrsim inactive sessions

inactive sessions check i po sql_id i pishem na downtime contacts dali mojem da kill-nem tazi sessiq





###############################################
CHECK DATABASE CURSORS limits

set linesize 333
col MAX_OPEN_CUR for a15
select max(a.value) as highest_open_cur, p.value as max_open_cur
  from v$sesstat a, v$statname b, v$parameter p
  where a.statistic# = b.statistic# 
  and b.name = 'opened cursors current'
  and p.name= 'open_cursors'
  group by p.value; 
  
  
  HIGHEST_OPEN_CUR MAX_OPEN_CUR
---------------- ---------------
              24 300



###############################################   dbspicao -m31 -r1  /// dbspicao -m31 -pv
CHECK CURSORS METRIC-31: GOOD GOOD GOOD GOOD GOOD GOOD

set linesize 200 
col PROGRAM for a40 
col MACHINE for a9 
col username for a10 
col TO_CHAR(LOGON_TIME,'YYYY/MM/DDHH24:MI:SS') for a45 
select inst_id,SID,SERIAL#,STATUS,USERNAME,MACHINE,PROGRAM,to_char(LOGON_TIME, 'YYYY/MM/DD HH24:MI:SS'),LOCKWAIT 
from gv$session where status='INACTIVE' order by SID;



#####
select SADDR, SID, USER_NAME from v$open_cursor;

#####
select USERNAME, STATUS, OSUSER, PROGRAM from v$session;

#####
select USERNAME, STATUS, SERVER, OSUSER, PROGRAM, count(1) from v$session, v$open_cursor;

####
select sid, count(1) from v$open_cursor group by sid having count(1) > 300;

       SID   COUNT(1)
---------- ----------
       845       1007
       
	   
	   

#####
!!!Cursors m31!!! Change in brackets username !!!

set linesize 200
col PROGRAM for a40
col MACHINE for a30
col username for a12
select inst_id,SID,SERIAL#,STATUS,USERNAME,MACHINE,PROGRAM,to_char(LOGON_TIME, 'YYYY/MM/DD HH24:MI:SS') AS LOGON_TIME ,
LOCKWAIT from gv$session where STATUS='INACTIVE' and USERNAME='DBSNMP' order by LOGON_TIME;



######
!!!Cursors m31!!!Change in brackets SID !!!!

select inst_id,SID,SERIAL#,STATUS,USERNAME,MACHINE,PROGRAM,LOGON_TIME,LOCKWAIT, SQL_ID  from gv$session where sid in (445) ; 

select program, username from v$session where sid = 1586;




##########
#### HOW TO KILL A SESSION:



#####
ALTER SYSTEM KILL SESSION 'sid,serial#';

ALTER SYSTEM KILL SESSION '445,4272' immediate;



##### Inactive open cursors
where v$session.sid = v$open_cursor.sid and USER_NAME='VNGSYS' and STATUS = 'INACTIVE';



##### Active open cursors / Change in brackets username !!!

SELECT v.value as numopencursors ,s.machine ,s.osuser,s.username
FROM V$SESSTAT v, V$SESSION s
WHERE v.statistic# = 3 and v.sid = s.sid and USERNAME='VNGSYS';


########
SELECT A.VALUE,B.NAME, S.USERNAME, S.SID, S.SERIAL# FROM V$SESSTAT A, V$STATNAME B, 
V$SESSION S WHERE A.STATISTIC# = B.STATISTIC# AND S.SID = A.SID AND B.NAME = 'opened cursors current' AND USERNAME = 'MAXIMOPRD76' AND A.SID='3106';


###### Find which user has max open cursor 
SELECT A.VALUE,B.NAME, S.USERNAME, S.SID, S.SERIAL# FROM V$SESSTAT A, V$STATNAME B, 
V$SESSION S WHERE A.STATISTIC# = B.STATISTIC# AND S.SID = A.SID AND B.NAME = 'opened cursors current';
 !!! ################################ GOOD QUERY
  
 select sum(a.value) total_cur, avg(a.value) avg_cur, max(a.value) max_cur, 
 s.username, s.machine
 from v$sesstat a, v$statname b, v$session s 
 where a.statistic# = b.statistic# and s.sid=a.sid
 and b.name = 'opened cursors current' 
 group by s.username, s.machine
 order by 1 desc; 
 
 
  TOTAL_CUR    AVG_CUR    MAX_CUR USERNAME   MACHINE
---------- ---------- ---------- ---------- ----------
       524 4.72072072         13 VNGUSR     sl72133
       436 5.01149425         14 VNGUSR     sl72131
       434  4.7173913         14 VNGUSR     sl72132
	   
	   
	   
	   
	   
	   



##########################################################################################
########################### MAXIMUM PROCESSES AND SESSIONS ###############################
##########################################################################################

dbspicao -m87 -pv



SQL> select * from v$resource_limit;

SQL> select count(1) from v$process;

  COUNT(1)
----------
       299

SQL> show parameter process;

NAME                                 TYPE        VALUE
------------------------------------ ----------- ------------------------------
aq_tm_processes                      integer     0
db_writer_processes                  integer     1
gcs_server_processes                 integer     2
job_queue_processes                  integer     4
log_archive_max_processes            integer     2
processes                            integer     300




###############################################
Velizar Style - BEST STYLE

col MACHINE for a10
col USERNAME for a10
col PROGRAM for a20
set linesize 500
select inst_id,SID,SERIAL#,STATUS,USERNAME,MACHINE,PROGRAM,to_char(LOGON_TIME, 'YYYY/MM/DD HH24:MI:SS'),LOCKWAIT, SQL_ID from gv$session
where SID='1586' inst_id, LOGON_TIME;

OR
where USERNAME='VNGSYS';


   INST_ID        SID    SERIAL# STATUS   USERNAME   MACHINE    PROGRAM              TO_CHAR(LOGON_TIME, LOCKWAIT    SQL_ID
---------- ---------- ---------- -------- ---------- ---------- -------------------- ------------------- ----------- -------------
         1       2242      29290 INACTIVE VNGUSR     sl72131    JDBC Thin Client     2020/04/13 15:50:00






###############################################
INACTIVE SESSIONS:

set linesize 400
set pages 500
col PROGRAM for a40
col MACHINE for a12
col username for a10
col TO_CHAR(LOGON_TIME,'YYYY/MM/DDHH24:MI:SS') for a45
col LOCKWAIT for a8
select sql_id,inst_id,SID,SERIAL#,STATUS,USERNAME,MACHINE,PROGRAM,to_char(LOGON_TIME, 'YYYY/MM/DD HH24:MI:SS'),LOCKWAIT from gv$session where status='INACTIVE' 
order by inst_id, LOGON_TIME;



###############################################
GET SQLTEXT FROM THE SESSIONS:

SELECT * FROM V$SQLTEXT WHERE SQL_ID='akas2b5kdvukb';




#######
set linesize 400
set pages 400
select SID,SERIAL#,USERNAME,STATUS,SCHEMANAME,PROGRAM,OSUSER,LOGON_TIME from gv$session where STATUS='INACTIVE' order by LOGON_TIME;

       SID    SERIAL# USERNAME        STATUS   SCHEMANAME                     PROGRAM                OSUSER      LOGON_TIM
---------- ---------- --------------- -------- ------------------------------ --------------------- ------------ ---------
       481       1543 DIANA           INACTIVE DIANA                          JDBC Thin Client      hpmidd        29-MAR-20
      2113        485 GEM             INACTIVE GEM                            JDBC Thin Client      hpmidd        29-MAR-20
       217       1165 GEM             INACTIVE GEM                            JDBC Thin Client      hpmidd        29-MAR-20



#####
***********************************************************************************************************************************************************************************************
set linesize 400
set pages 400
select inst_id,SID,SERIAL#,USERNAME,STATUS,MACHINE,SCHEMANAME,PROGRAM,OSUSER,to_char(LOGON_TIME, 'YYYY/MM/DD HH24:MI:SS'),LOCKWAIT from gv$session where STATUS='INACTIVE' order by LOGON_TIME;


#####
*****************************************************************************************************************************************************************************************
set linesize 400
set pages 400
select inst_id,SID,SERIAL#,USERNAME,STATUS,MACHINE,SCHEMANAME,PROGRAM,OSUSER,to_char(LOGON_TIME, 'YYYY/MM/DD HH24:MI:SS'),LOCKWAIT from gv$session where STATUS='INACTIVE' order by SID;
*****************************************************************************************************************************************************************************************






###############################################
INACTIVE AND ACTIVE SESSIONS - VERY GOOD ####


SET LINES 300
SELECT V.SERIAL#, V.SID, V.USERNAME, V.STATUS, V.SCHEMANAME, V.OSUSER, V.MACHINE, V.TERMINAL, V.PROGRAM, V.MODULE, V.CLIENT_INFO, V.BLOCKING_SESSION_STATUS,
       V.BLOCKING_INSTANCE, V.BLOCKING_SESSION, V.FINAL_BLOCKING_SESSION_STATUS,V.FINAL_BLOCKING_INSTANCE, V.FINAL_BLOCKING_SESSION, A.SQL_FULLTEXT, A.OPTIMIZER_MODE,
       A.OPTIMIZER_COST
  FROM V$SESSION V, V$SQLAREA A
WHERE V.SQL_ID = A.SQL_ID(+)
ORDER BY USERNAME,V.MACHINE;





###############################################
ACTIVE SESSIONS:

set linesize 200
set pages 1500
col PROGRAM for a40
col MACHINE for a9
col username for a10
col TO_CHAR(LOGON_TIME,'YYYY/MM/DDHH24:MI:SS') for a45
select sql_id,inst_id,SID,SERIAL#,STATUS,USERNAME,MACHINE,PROGRAM,to_char(LOGON_TIME, 'YYYY/MM/DD HH24:MI:SS'),LOCKWAIT from gv$session where status='ACTIVE' 
order by inst_id, LOGON_TIME;



###############################################
select username, count(*)   
from v$session
group by rollup(username);

USERNAME                         COUNT(*)
------------------------------ ----------
IBISDB                                 65
IBISLOGSDB                              2
PUBLIC                                  1
SYS                                     1
VNGSYS                                 16
VNGUSR                                333
                                       71
                                      489

8 rows selected.





###############################################
which machines/schemas are causing any potential process exhaustion

select distinct
        s.inst_id,
        s.username,
        s.machine,
        count(*)
from    gv$session s,
        gv$process p
where   s.paddr       =  p.addr
and     s.inst_id     =  p.inst_id
GROUP BY         s.inst_id,
        s.username,
        s.machine
ORDER BY 4 desc; 


   INST_ID USERNAME                       MACHINE                                                            COUNT(*)
---------- ------------------------------ ---------------------------------------------------------------- ----------
         1 VNGUSR                         sl72133                                                                 118
         1 VNGUSR                         sl72131                                                                 103
         1 VNGUSR                         sl72132                                                                  94
         1                                sl72111                                                                  74





############GOOD###################### innactive, username !!!!!!!
set linesize 200 
col PROGRAM for a40 
col MACHINE for a30 
col username for a12 
SELECT INST_ID,sid,serial#,status,username,machine,program,TO_CHAR(logon_time,'YYYY/MM/DD HH24:MI:SS'),LOCKWAIT from gv$session 
where STATUS='INACTIVE' and USERNAME='A4MBBCMGMT4USRA' order by LOGON_TIME;


select 'ALTER SYSTEM KILL SESSION '||''''||sid||','||serial#||',@'||inst_id||''' IMMEDIATE;' from gv$session where username='GEM' and STATUS='INACTIVE'; 




################################# active session check/all session 
set linesize 200 
col PROGRAM for a40 
col MACHINE for a30 
col username for a12 
select inst_id,SID,SERIAL#,STATUS,USERNAME,MACHINE,PROGRAM,to_char(LOGON_TIME, 'YYYY/MM/DD HH24:MI:SS'),LOCKWAIT from gv$session order by LOGON_TIME;
 



----------------------------------------po USERNAME all sessions 
set linesize 200 
col PROGRAM for a40 
col MACHINE for a30 
col username for a12 
select inst_id,SID,SERIAL#,STATUS,USERNAME,MACHINE,PROGRAM,to_char(LOGON_TIME, 'YYYY/MM/DD HH24:MI:SS'),LOCKWAIT from gv$session where USERNAME='DRMPOS';




###INACTIVE
set linesize 200
col PROGRAM for a40
col MACHINE for a30
col username for a12
select inst_id,SID,SERIAL#,STATUS,USERNAME,MACHINE,PROGRAM,to_char(LOGON_TIME, 'YYYY/MM/DD HH24:MI:SS'),LOCKWAIT from gv$session where STATUS='INACTIVE' order by LOGON_TIME 
/



##ACTIVE SES
select SID, SERIAL#, USERNAME, SCHEMANAME, MACHINE, PROGRAM, STATUS from gv$session;




###############################################
 
select sql_id from v$session where sid in (299,590);  
 
SQL_ID 
------------- 
gqbzggtxt6qhr 
8nk520rsk5n8x 




###############################################
select inst_id,SID,SERIAL#,STATUS,USERNAME,MACHINE,PROGRAM,to_char(LOGON_TIME, 'YYYY/MM/DD HH24:MI:SS'), LOCKWAIT, SQL_ID from gv$session where sid in (299,590) 
order by LOGON_TIME; - vreme na sesiqta  
 
 


#### Last SQL query for sql_id !!!!!!!!!!
set lines 300 
set pages 600 
set long 999 
select sql_fulltext from v$sqlarea where sql_id='0b0f3tqs6cfst';  
 





###################################################################################################
########################################## KILL  SESSIONS  ########################################
###################################################################################################



##########
#### HOW TO KILL A SESSION:



#####
ALTER SYSTEM KILL SESSION 'sid,serial#';

ALTER SYSTEM KILL SESSION '445,4272' immediate;



#####
ON A RAC:
#### ALTER SYSTEM KILL SESSION 'sid,serial#,@inst_id';

ALTER SYSTEM KILL SESSION '682,48157,@4';



##########
select 'ALTER SYSTEM KILL SESSION '||''''||sid||','||serial#||',@'||inst_id||''' IMMEDIATE;' from gv$session where STATUS='INACTIVE';
select 'ALTER SYSTEM KILL SESSION '||''''||sid||','||serial#||',@'||inst_id||''' IMMEDIATE;' from gv$session where SID=&sid;
select 'ALTER SYSTEM KILL SESSION '||''''||sid||','||serial#||',@'||inst_id||''' IMMEDIATE;' from gv$session where USERNAME='VNGUSR';



################################################
KILL ALL INACTIVE SESSONS SCRIPT:

set linesize 550;
col username for a11
col machine for a11
col lockwait for a11
col osuser for a10
col SCHEMANAME for a12
col WAIT_CLASS for a12
select 
'ALTER SYSTEM KILL SESSION '||''''||sid||','||serial#||''''||' IMMEDIATE;'
from gv$session where status='INACTIVE'; 


'ALTERSYSTEMKILLSESSION'||''''||SID||','||SERIAL#||''''||'IMMEDIATE;'
------------------------------------------------------------------------------------------------------------------------
ALTER SYSTEM KILL SESSION '2169,56525' IMMEDIATE;		              --- COPY THOSE ROWS AND PASTE THEM IMMEDIATELY !!!
ALTER SYSTEM KILL SESSION '2175,63153' IMMEDIATE;
ALTER SYSTEM KILL SESSION '2204,63463' IMMEDIATE;





###############################################
select 'ALTER SYSTEM KILL SESSION '||''''||sid||','||serial#||',@'||inst_id||''' IMMEDIATE;' from gv$session where STATUS='INACTIVE';

copy ot gore do dolu i paste pak v konzolata --- gotovo kill-nati sa!






###############################################
[‎25-‎Aug-‎19 11:48]  Tsalov, Aleksandar Stefanov: 
 
select 'ALTER SYSTEM KILL SESSION '||''''||sid||','||serial#||',@'||inst_id||''' IMMEDIATE;' 
from gv$session where STATUS='INACTIVE' and INST_ID=2; USERNAME="KLARA";
 



###############################################

ЕВЕНТУАЛНО МОЖЕ ДА СЕ KILL-НАТ ТЕЗИ INACTIVE SESSIONS, НО СЛЕД КАТО ПОЛУЧИМ APPROVAL: 
 
Dear Downtime Contacts, 
We have received incident for high Memory utilization for server sv2000.logista.local . 
We found that  there is ongoing export by project team which have risen memory utilization. 
Also we found that  there is also some inactive sessions on database DIAQ which use a lot of memory too: 
 
SPID              SID    SERIAL# EVENT                                                            USERNAME        MACHINE           LOGON_TIME                STATUS     PROGRAM               SQL_ID 
---------- ---------- ---------- ---------------------------------------------------------------- --------------- ----------------- ------------------------- ---------- --------------------- ------------- 
20580            1997         79 SQL*Net message from client                                      DIANA           sv1465.logista.lo 06/04/19 15:39:59         INACTIVE   JDBC Thin Client 
                                                                                                                  cal 
 
19811            2010       1577 SQL*Net message from client                                      DIANA           LOGISTA\ES0880WS0 06/05/19 09:13:56         INACTIVE   sqldeveloper.exe 
                                                                                                                  330 
 
21133             863        487 SQL*Net message from client                                      DIANA           sv1465.logista.lo 06/04/19 15:40:50         INACTIVE   JDBC Thin Client 
                                                                                                                  cal 
 
21158            2001        923 SQL*Net message from client                                      DIANA           sv1465.logista.lo 06/04/19 15:40:50         INACTIVE   JDBC Thin Client 
                                                                                                                  cal 
 
Could you please check them from application side and give us approval to kill them ?  
 

 





##########################################################################################################
 #########################################---AUDI---######################################################
##########################################################################################################


* Additional information and scripts for your reference.
 
A4 users are object owners

U4 users are only for conenctions


- Check users details

set lines 512
set pages 1000
col USERNAME format A25
col ACCOUNT_STATUS format A17
col PASSWORD format A30
col PROFILE for a30
select USERNAME,ACCOUNT_STATUS,LOCK_DATE,CREATED, PROFILE,DEFAULT_TABLESPACE,TEMPORARY_TABLESPACE from dba_users 
where username like '%4ASW%'
--where account_status='OPEN'
--and USERNAME not like 'HP%'
order by USERNAME,ACCOUNT_STATUS;




- Check active sessions from specific user


set lines 512;
set pagesize 4000
col username FORMAT A20
col machine FORMAT A35
col PROGRAM for a18
col SESSIONS clear
col SERVICE_NAME for a20
select count(*) as "Active Sessions", status, username, machine,
--SID,SERIAL#, 
inst_id,PROGRAM,SERVICE_NAME
from gv$session
where username like '%4ASW%'
-- status ='ACTIVE'
group by status,username, machine,
--SID,SERIAL#,
inst_id,PROGRAM,SERVICE_NAME order by INST_ID;


Active Sessions STATUS   USERNAME             MACHINE                                INST_ID PROGRAM            SERVICE_NAME
--------------- -------- -------------------- ----------------------------------- ---------- ------------------ --------------------
              8 INACTIVE A4ASWIKI             ivwb1989                                     2 JDBC Thin Client   P_ASWIKI_437
             22 INACTIVE A4ASWLIFERAY         iuwb1090                                     2 JDBC Thin Client   P_ASWLIFERAY_440
             18 INACTIVE A4ASWLIFERAY         iuwb1091                                     2 JDBC Thin Client   P_ASWLIFERAY_440












###################################################################################

#################################################################################### 
 
DBSPI11-03: Unable to connect to one or more databases (ORA0291,) configured in file local.cfg located in dbspi directory. 
 
select USERNAME, sid, serial#, status, from v$session order by 1; 
 
 
 
SQL> select sid, serial#, status from v$session order by 1; 
 
       SID    SERIAL# STATUS 
---------- ---------- -------- 
         1      63715 INACTIVE 
         2      29007 INACTIVE 
         3      28967 INACTIVE 
         4      24463 INACTIVE 
         5      21105 INACTIVE 
         6      19163 INACTIVE 
         7      13441 INACTIVE 
         8      60925 INACTIVE 
         9      22689 INACTIVE 
        10      15379 INACTIVE 
        11      20733 INACTIVE 
 
alter system kill session '18,656' immediate;  
 

да убия дадена session/backup/kill a session    very good!!!

select 'ALTER SYSTEM KILL SESSION '||''''||sid||','||serial#||',@'||inst_id||''' IMMEDIATE;' from gv$session where SID=&sid;  - ще ме пита за номера на сесията(sid-a)

SQL> select 'ALTER SYSTEM KILL SESSION '||''''||sid||','||serial#||',@'||inst_id||''' IMMEDIATE;' from gv$session where SID=&sid;
Enter value for sid: 656

'ALTERSYSTEMKILLSESSION'||''''||SID||','||SERIAL#||',@'||INST_ID||'''IMMEDIATE;'
------------------------------------------------------------------------------------------------------------------------------------------------------------------
ALTER SYSTEM KILL SESSION '656,64866,@1' IMMEDIATE;

SQL> ALTER SYSTEM KILL SESSION '656,64866,@1' IMMEDIATE;

System altered.




OR за по-лесно да листне всички Inactive sessions и да ги kill-не: 
 
select 'ALTER SYSTEM KILL SESSION '||''''||sid||','||serial#||',@'||inst_id||''' IMMEDIATE;' from gv$session where STATUS='INACTIVE'; 




