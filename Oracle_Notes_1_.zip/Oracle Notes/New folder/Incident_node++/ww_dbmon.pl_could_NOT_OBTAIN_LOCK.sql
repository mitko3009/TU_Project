######################## ww_dbmon.pl could not obtain the lock ###################

### Check the process ###

root@uv163062 # ps -ef |grep ww_dbmon.pl
    root   186   183   0 18:48:49 ?           0:00 /bin/ksh /var/opt/OV/bin/instrumentation/dbmonenv.sh cmd ww_dbmon.pl
    root   252   186   0 18:48:49 ?           0:00 /opt/OV/nonOV/perl/a/bin/perl /var/opt/OV/bin/instrumentation/ww_dbmon.pl
    root 12679  2638   0 19:15:31 pts/2       0:00 grep ww_dbmon.pl
	
root@uv163062 # cd /var/opt/OV/dbspi



### Check if process has a lock file ####

root@uv163062 # cd /var/opt/OV/dbspi


root@uv163062 # ls -la
total 305
drwxr-xr-x   6 root     root          24 May 27 19:13 .
dr-xr-xr-x  20 bin      bin           20 Sep  8  2016 ..
-rwxrwxr-x   1 oracle   oinstall   74786 Jun 12  2017 db_mon.cfg
-rw-rw-r--   1 root     root       10862 Mar 20 19:31 dbmon-event.cfg
-rw-------   1 root     root          29 Mar 20 19:31 dbmon-event.checksum
-rw-rw-r--   1 root     root       10073 May 12  2016 dbmon-event.old.20190320193120
-rw-r--r--   1 root     root         184 May 12 23:47 dbmon.defaults
-rw-r--r--   1 root     root         111 Mar  5 12:28 dbmon.listener.defaults
-rw-------   1 root     root          33 May 27 18:48 dbmon.lock.15m
-rw-------   1 root     root          34 May 27 18:53 dbmon.lock.30m
-rw-------   1 root     root          35 May 27 19:13 dbmon.lock.5m
-rw-------   1 root     root          36 May 27 19:13 dbmon.lock.ORACLE.1h.report
-rw-------   1 root     root          35 May 27 19:14 dbmon.lock.ORACLE.5m.report
-rw-rw-r--   1 root     root          13 May 27 19:12 dbmon.lock.event-health
-rw-------   1 root     root          43 May 27 19:14 dbmon.lock.measureware
-rw-rw-r--   1 root     root       23202 May 27 19:13 dbmon_save.store
-rw-r--r--   1 root     root         151 Mar 25 08:33 dbtab
-rw-------   1 root     root          57 May 27 18:48 defaults
drwxr-xr-x   6 root     root           6 Dec 10  2013 dsi
drwxr-xr-x   6 root     root           6 Dec 10  2013 history
-rw-------   1 root     root        1229 Mar 25 08:33 local.cfg
-rw-------   1 root     root           0 May 27 18:48 local.lck
drwxr-xr-x   2 root     root           6 Aug  5  2015 log
drwxr-xr-x   2 root     root         303 May 27 19:14 tmp


root@uv163062 # cat dbmon.lock.15m
LOCK 1
PID 252
PNAME ww_dbmon.pl


##### Check current date:  ####
root@uv163062 # date
Mon May 27 19:16:32 CEST 2019

#### process age is more than 15minutes ####

#### attempt to terminate the process #####

root@uv163062 # kill -9 252

##### delete old lock file  #####

root@uv163062 #
root@uv163062 # rm -f dbmon.lock.15m
root@uv163062 # 
 
 
 
########## HUNG PROCESS WAS TERMINATED MANUALLY ###########
