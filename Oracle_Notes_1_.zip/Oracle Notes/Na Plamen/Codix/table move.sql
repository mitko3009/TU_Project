LOCAMDEV-26073

1. Move + Index Rebuild




set timing on;
set serverout on;

alter table T_INTERVENANTS       move update indexes;





SELECT 'alter index '|| owner ||'.'||index_name||' rebuild tablespace '||tablespace_name ||';'
	FROM   dba_indexes
	WHERE  status = 'UNUSABLE' ;





2. Gather stats

BEGIN
  DBMS_STATS.GATHER_TABLE_STATS ( ownname          => 'IMXDB',
                                  tabname          => 'T_INTERVENANTS',
                                  estimate_percent => DBMS_STATS.AUTO_SAMPLE_SIZE,
                                  method_opt       => 'FOR ALL COLUMNS SIZE 1 FOR COLUMNS SIZE SKEWONLY REFINDIVIDU',
                                  degree           => 4,
                                  cascade          => TRUE,
                                  no_invalidate    => FALSE,
                                  force            => TRUE );
END;
/

 
 
 
 
 3.
 
 
 SET pagesize 300 
SET pagesize 300 
SET linesize 200 
COL "Resize Command" for a110 

SELECT 'alter database datafile '''||file_name||''' resize '||       DECODE(trunc(ceil( (nvl(hwm,1)*(size_db_block))/1024/1024 ) /10),0 ,10, ceil( (nvl(hwm,1)* (size_db_block))/1024/1024 )) ||'M;' "Resize Command",       AUTOEXTENSIBLE , bytes/1024/1024 "CurrentSize(Mb)" ,       ( (bytes/1024/1024) - ceil( (nvl(hwm,1)* (size_db_block))/1024/1024 ) ) "FreeSize(Mb)" 
  FROM dba_data_files a,       ( SELECT /*+ no_merge */ file_id, max(block_id+blocks-1) AS hwm FROM dba_extents GROUP BY file_id ) b ,       (SELECT /*+ no_merge */ TO_NUMBER(value) AS size_db_block FROM v$parameter WHERE name = 'db_block_size') c 
 WHERE a.file_id = b.file_id(+) AND tablespace_name in ('TS_IMXDATA','TS_IMXINDEX')   AND ceil(blocks*(c.size_db_block)/1024/1024)- ceil((nvl(hwm,1)*(c.size_db_block))/1024/1024 ) > 10 ORDER BY "FreeSize(Mb)" ASC;
 
 
 
 
col TABLE_NAME for a32
SELECT
   owner, table_name, TRUNC(sum(bytes)/1024/1024) Meg
FROM
(SELECT segment_name table_name, owner, bytes
 FROM dba_segments
 WHERE segment_type = 'TABLE'
 UNION ALL
 SELECT i.table_name, i.owner, s.bytes
 FROM dba_indexes i, dba_segments s
 WHERE s.segment_name = i.index_name
 AND s.owner = i.owner
 AND s.segment_type = 'INDEX'
 UNION ALL
 SELECT l.table_name, l.owner, s.bytes
 FROM dba_lobs l, dba_segments s
 WHERE s.segment_name = l.segment_name
 AND s.owner = l.owner
 AND s.segment_type = 'LOBSEGMENT'
 UNION ALL
 SELECT l.table_name, l.owner, s.bytes
 FROM dba_lobs l, dba_segments s
 WHERE s.segment_name = l.index_name
 AND s.owner = l.owner
 AND s.segment_type = 'LOBINDEX')
WHERE table_name in UPPER('&tablename')
GROUP BY table_name, owner
---HAVING SUM(bytes)/1024/1024 > 10 /* Ignore really small tables */
ORDER BY SUM(bytes) desc
; 


col TABLE_NAME for a32
col TOTAL_SIZE for a32
col ACTUAL_SIZE for a32
col FRAGMENTED_SPACE for a32
select table_name,avg_row_len,round(((blocks*16/1024)),2)||'MB' "TOTAL_SIZE",
round((num_rows*avg_row_len/1024/1024),2)||'Mb' "ACTUAL_SIZE",
round(((blocks*16/1024)-(num_rows*avg_row_len/1024/1024)),2) ||'MB' "FRAGMENTED_SPACE",
(round(((blocks*16/1024)-(num_rows*avg_row_len/1024/1024)),2)/round(((blocks*16/1024)),2))*100 "percentage"
from all_tables WHERE table_name='&TABLE_NAME';

