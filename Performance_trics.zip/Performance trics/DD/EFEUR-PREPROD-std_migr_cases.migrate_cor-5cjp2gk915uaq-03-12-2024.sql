/********************************************************************************
*********       E-mail subject: EFEUR
*********             Instance: PREPROD
*********          Description: 
Problem:
The std_migr_cases.migrate_cor took almost 30 minutes on PREPROD and we were requested to investigate for slow queries.

Analysis:
The TOP SQL in the std_migr_cases.migrate_cor, which was responsible for 55% of the time was 80n9d3qjz65d5.
Unfortunately, there is no data about its text in the AWR, so we can't do much for it ( I also searched it in the TTS by the sql_id, but I couldn't find its text ).
It looks like it is some PL/SQL, which was executed only once. The second TOP SQL for this module is 5cjp2gk915uaq, which was responsible for 15% of the time and it was executed 164 times 
based on the information in the AWR. We can suggest little improvement for it, which will save summary ~2 minutes. The TOP MODULE for the period between 11:30 and 12:00 on 26/11/2024 was 
PT_MIGR_STATS_CREATE, which as you can see in the OLD Metrics section below has 53k seconds activity on event ON CPU for the period. On PREPROD, we have 35 CPUs, which means that most of the 
CPU time for this period was spent from the PT_MIGR_STATS_CREATE and the CPUs were loaded. In the log of the PT_MIGR_STATS_CREATE, it can be seen that it was gathering statistics on tables 
like T_ENTMAIL and G_PIECE again and agin, which we fixed in EFDE2DEV-2050.


Suggestion:
Please add hint to SQL 5cjp2gk915uaq as it is shown in the New SQL section below.

*********               SQL_ID: 5cjp2gk915uaq
*********      Program/Package: 
*********              Request: Spasiyan Todorov 
*********               Author: Dimitar Dimitrov
********* Received e-mail date: 02/12/2024
*********      Resolution date: 03/12/2024
*********  Trace old file here: \\epox\specifs\performance\tmp\
*********  Trace new file here:
***********************************************************************************/

/********************************OLD SQL*******************************************/

-- 5cjp2gk915uaq

VAR B1 VARCHAR2(32);
EXEC :B1 := '0001010007';
VAR B2 VARCHAR2(32);
EXEC :B2 := 'A7062DKQ'

SELECT DISTINCT :B2, 
                C.REFDOSS, 
                DB.REFINDIVIDU
  FROM G_DOSSIER C, 
       G_DOSSIER D, 
       T_INTERVENANTS DB
 WHERE C.REFLOT = D.REFDOSS
   AND D.REFLOT = :B1
   AND DB.REFDOSS = C.REFDOSS
   AND DB.REFTYPE = 'DB'
   AND NOT EXISTS ( SELECT 1
                      FROM G_CONCENTRATION_SMALL_PF
                     WHERE LIMIT_ID = :B2
                       AND REFDOSS = C.REFDOSS );

/********************************OLD SQL*******************************************/
/********************************OLD Metrics***************************************/
/*
26/11/2024 11:03:08     Checking if there are modified tables that need new stats
26/11/2024 11:03:22        Delete stats on MSG_QUEUE
26/11/2024 11:04:04     Finish stats create pass
26/11/2024 11:06:01        Create stats on T_ENTMAIL
26/11/2024 11:06:05        Create stats on G_PIECE
26/11/2024 11:11:46        Create stats on T_ENTMAIL
26/11/2024 11:11:49        Create stats on G_PIECE
26/11/2024 11:17:23        Create stats on T_ENTMAIL
26/11/2024 11:17:25        Create stats on G_PIECE
26/11/2024 11:19:04     Checking if there are modified tables that need new stats
26/11/2024 11:19:17        Delete stats on MSG_QUEUE
26/11/2024 11:19:48     Finish stats create pass
26/11/2024 11:22:27        Create stats on T_ENTMAIL
26/11/2024 11:22:29        Create stats on G_PIECE
26/11/2024 11:27:47        Create stats on T_ENTMAIL
26/11/2024 11:27:49        Create stats on G_PIECE
26/11/2024 11:33:10        Create stats on T_ENTMAIL
26/11/2024 11:33:13        Create stats on G_PIECE
26/11/2024 11:34:48     Checking if there are modified tables that need new stats
26/11/2024 11:35:02        Delete stats on MSG_QUEUE
26/11/2024 11:35:35     Finish stats create pass
26/11/2024 11:38:38        Create stats on T_ENTMAIL
26/11/2024 11:38:40        Create stats on G_PIECE
26/11/2024 11:44:09        Create stats on STD_MIGR_COR
26/11/2024 11:44:10        Create stats on G_CONCENTR_SMALL_PF
26/11/2024 11:44:12        Create stats on G_CONCENTR_BIG_PF
26/11/2024 11:44:14        Create stats on G_CONCENTRATION_LIM_DEC
26/11/2024 11:44:14        Create stats on T_ENTMAIL
26/11/2024 11:44:17        Create stats on G_PIECE
26/11/2024 11:50:19        Create stats on T_ENTMAIL
26/11/2024 11:50:21        Create stats on G_PIECE
26/11/2024 11:50:35     Checking if there are modified tables that need new stats
26/11/2024 11:50:48        Delete stats on MSG_QUEUE
26/11/2024 11:51:51        Create stats on STD_MIGR_COR
26/11/2024 11:51:52        Create stats on G_CONCENTR_BIG_PF
26/11/2024 11:51:56        Create stats on G_CONCENTR_SMALL_PF
26/11/2024 11:52:04     Finish stats create pass
26/11/2024 11:57:00        Create stats on T_ENTMAIL
26/11/2024 11:57:02        Create stats on STD_MIGR_SIC
26/11/2024 11:57:03        Create stats on G_PIECE
26/11/2024 12:05:28        Create stats on T_ENTMAIL
26/11/2024 12:06:38        Create stats on STD_MIGR_INH
26/11/2024 12:06:46        Create stats on PRM_VALUES
26/11/2024 12:07:04     Checking if there are modified tables that need new stats
26/11/2024 12:07:15        Create stats on G_PIECE
26/11/2024 12:07:29        Delete stats on MSG_QUEUE
26/11/2024 12:08:02        Create stats on T_ENTMAIL


MODULE                           PROGRAM                                            CLIENT_ID       SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM     TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- -------------------------------------------------- --------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
PT_MIGR_STATS_CREATE                                                                                                                               ON CPU               2024/11/26 11:30:00  2024/11/26 11:59:54    5300              1114812 +000000000 00:29:53.834 93%
PT_MIGR_STATS_CREATE                                                                                                                               direct path read     2024/11/26 11:30:30  2024/11/26 11:59:54     337                   21 +000000000 00:29:23.785 6%
PT_MIGR_STATS_CREATE                                                                                                                               db file sequential r 2024/11/26 11:30:20  2024/11/26 11:59:54      36                   21 +000000000 00:29:33.807 1%

-- ~25 minutes of the time of each of the 35 CPUs was spent in the PT_MIGR_STATS_CREATE for the period of 30 minutes


MODULE                           PROGRAM                                            CLIENT_ID       SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- -------------------------------------------------- --------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
PT_MIGR_STATS_CREATE                                                                                                                               ON CPU               2024/11/26 11:30:00  2024/11/26 11:59:54        5300              1114812 +000000000 00:29:53.834 85%
PT_MIGR_STATS_CREATE                                                                                                                               direct path read     2024/11/26 11:30:30  2024/11/26 11:59:54         337                   21 +000000000 00:29:23.785 5%
std_migr_cases.migrate_inh       std_migration_robot                                                                                               latch: shared pool   2024/11/26 11:57:54  2024/11/26 11:59:34         152               139990 +000000000 00:01:40.382 2%
std_migr_cases.migrate_inh       std_migration_robot                                                                                               ON CPU               2024/11/26 11:57:54  2024/11/26 11:59:54         134             10618415 +000000000 00:02:00.441 2%
std_migr_cases.migrate_cor       std_migration_robot                                                                                546      34446 ON CPU               2024/11/26 11:38:21  2024/11/26 11:54:03          93               786336 +000000000 00:15:41.932 1%
std_migr_cases.migrate_inh       std_migration_robot                                                3bjwwfpdd1mh0          0                       buffer busy waits    2024/11/26 11:58:04  2024/11/26 11:59:54          75               179960 +000000000 00:01:50.413 1%
PT_MIGR_STATS_CREATE                                                                                                                               db file sequential r 2024/11/26 11:30:20  2024/11/26 11:59:54          36                   21 +000000000 00:29:33.807 1%
std_migr_cases.migrate_inh       std_migration_robot                                                3bjwwfpdd1mh0          0                       enq: TX - index cont 2024/11/26 11:59:04  2024/11/26 11:59:14          32                16071 +000000000 00:00:10.040 1%
std_migr_cases.migrate_inh       std_migration_robot                                                                                               row cache mutex      2024/11/26 11:58:14  2024/11/26 11:59:44          21                      +000000000 00:01:30.348 0%


MODULE                           PROGRAM                                            CLIENT_ID       SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- -------------------------------------------------- --------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
std_migr_cases.migrate_cor       std_migration_robot                                                                                546      34446                      2024/11/26 11:38:21  2024/11/26 11:54:03          95               786336 +000000000 00:15:41.932 100%


MODULE                           PROGRAM                                            CLIENT_ID       SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- -------------------------------------------------- --------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
std_migr_cases.migrate_cor       std_migration_robot                                                                                546      34446 ON CPU               2024/11/26 11:38:21  2024/11/26 11:54:03          93               786336 +000000000 00:15:41.932 98%
std_migr_cases.migrate_cor       std_migration_robot                                                                                546      34446 db file sequential r 2024/11/26 11:38:31  2024/11/26 11:40:12           2                   41 +000000000 00:01:40.165 2%



MODULE                           PROGRAM                                            CLIENT_ID       SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- -------------------------------------------------- --------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
std_migr_cases.migrate_cor       std_migration_robot                                                80n9d3qjz65d5          0        546      34446 ON CPU               2024/11/26 11:38:51  2024/11/26 11:53:33          52                    1 +000000000 00:14:41.840 55%
std_migr_cases.migrate_cor       std_migration_robot                                                5cjp2gk915uaq   92394199        546      34446                      2024/11/26 11:39:41  2024/11/26 11:53:23          14                  164 +000000000 00:13:41.727 15%
std_migr_cases.migrate_cor       std_migration_robot                                                344wskk6dqk2r  218428421        546      34446 ON CPU               2024/11/26 11:38:41  2024/11/26 11:53:43           7               766866 +000000000 00:15:01.868 7%
std_migr_cases.migrate_cor       std_migration_robot                                                3qj6qpxx4jqku 3079889875        546      34446 ON CPU               2024/11/26 11:41:52  2024/11/26 11:50:03           6               169564 +000000000 00:08:11.038 6%
std_migr_cases.migrate_cor       std_migration_robot                                                06dk39418u07t 1935655466        546      34446 ON CPU               2024/11/26 11:41:02  2024/11/26 11:49:33           5               111905 +000000000 00:08:31.079 5%
   
   

SQL_ID        SQL_PLAN_HASH_VALUE SQL_PLAN_LINE_ID SQL_PLAN_OPERATION             SQL_PLAN_OPTIONS                   ACTIVE
------------- ------------------- ---------------- ------------------------------ ------------------------------ ----------
5cjp2gk915uaq            92394199                9 INDEX                          FAST FULL SCAN                         11
5cjp2gk915uaq            92394199                5 HASH JOIN                                                              2
5cjp2gk915uaq            92394199                8 INDEX                          RANGE SCAN                              1
   
   
       
MODULE                         SQL_ID               IN_CONNECT IN_PARSE   IN_HARD_PA IN_SQL_EXE IN_PLSQL_E IN_PLSQL_R IN_PLSQL_C IN_JAVA_EX IN_BIND    IN_CURSOR_ IN_SEQUENC   COUNT(*)
------------------------------ -------------------- ---------- ---------- ---------- ---------- ---------- ---------- ---------- ---------- ---------- ---------- ---------- ----------
std_migr_cases.migrate_cor     80n9d3qjz65d5        N          N          N          Y          N          N          N          N          N          N          N           5
std_migr_cases.migrate_cor     80n9d3qjz65d5        N          N          N          Y          Y          N          N          N          N          N          N           47          
    

-- 5cjp2gk915uaq

Plan hash value: 92394199
------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                             | Name                      | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers |
------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                      |                           |      1 |        |  1735 (100)|    812 |00:00:00.31 |   11044 |
|   1 |  HASH UNIQUE                          |                           |      1 |    214 |  1735   (1)|    812 |00:00:00.31 |   11044 |
|*  2 |   HASH JOIN RIGHT ANTI                |                           |      1 |    214 |  1734   (1)|    812 |00:00:00.31 |   11044 |
|   3 |    TABLE ACCESS BY INDEX ROWID BATCHED| G_CONCENTR_SMALL_PF       |      1 |    288 |   210   (0)|   9320 |00:00:00.01 |    4239 |
|*  4 |     INDEX RANGE SCAN                  | GCSPF$LIMIT_ID$TUPLE_ID   |      1 |    288 |     5   (0)|   9320 |00:00:00.01 |     112 |
|*  5 |    HASH JOIN                          |                           |      1 |    214 |  1524   (1)|    812 |00:00:00.29 |    6805 |
|   6 |     NESTED LOOPS                      |                           |      1 |   1242 |    73   (0)|    812 |00:00:00.01 |      13 |
|*  7 |      INDEX RANGE SCAN                 | G_DOSSIER_RL_CD_RD_RF_IDX |      1 |     35 |     3   (0)|      1 |00:00:00.01 |       3 |
|*  8 |      INDEX RANGE SCAN                 | G_DOSSIER_RL_CD_RD_RF_IDX |      1 |     35 |     2   (0)|    812 |00:00:00.01 |      10 |
|*  9 |     INDEX FAST FULL SCAN              | INT_INDIV                 |      1 |  77610 |  1450   (1)|    450K|00:00:00.14 |    6792 |
------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   2 - access("REFDOSS"="C"."REFDOSS")
   4 - access("LIMIT_ID"=:B2)
   5 - access("DB"."REFDOSS"="C"."REFDOSS")
   7 - access("D"."REFLOT"=:B1)
   8 - access("C"."REFLOT"="D"."REFDOSS")
   9 - filter("DB"."REFTYPE"='DB')                                                                                                            
*/
/********************************OLD Metrics***************************************/

/********************************New SQL*******************************************/

SELECT /*+ index(D DOSS_LOT) cardinality(D 5) */
       DISTINCT :B2, 
                C.REFDOSS, 
                DB.REFINDIVIDU
  FROM G_DOSSIER C, 
       G_DOSSIER D, 
       T_INTERVENANTS DB
 WHERE C.REFLOT = D.REFDOSS
   AND D.REFLOT = :B1
   AND DB.REFDOSS = C.REFDOSS
   AND DB.REFTYPE = 'DB'
   AND NOT EXISTS ( SELECT 1
                      FROM G_CONCENTRATION_SMALL_PF
                     WHERE LIMIT_ID = :B2
                       AND REFDOSS = C.REFDOSS );
/********************************New SQL*******************************************/
/********************************New Metrics***************************************/
/*
Plan hash value: 539944507
--------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                               | Name                      | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers |
--------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                        |                           |      1 |        |   465 (100)|    812 |00:00:00.02 |    3301 |
|   1 |  HASH UNIQUE                            |                           |      1 |     30 |   465   (1)|    812 |00:00:00.02 |    3301 |
|   2 |   NESTED LOOPS ANTI                     |                           |      1 |     30 |   464   (0)|    812 |00:00:00.02 |    3301 |
|   3 |    NESTED LOOPS                         |                           |      1 |     30 |   385   (0)|    812 |00:00:00.01 |    1656 |
|   4 |     NESTED LOOPS                        |                           |      1 |    176 |    33   (0)|    812 |00:00:00.01 |      14 |
|   5 |      TABLE ACCESS BY INDEX ROWID BATCHED| G_DOSSIER                 |      1 |      5 |    23   (0)|      1 |00:00:00.01 |       4 |
|*  6 |       INDEX RANGE SCAN                  | DOSS_LOT                  |      1 |     35 |     3   (0)|      1 |00:00:00.01 |       3 |
|*  7 |      INDEX RANGE SCAN                   | G_DOSSIER_RL_CD_RD_RF_IDX |      1 |     35 |     2   (0)|    812 |00:00:00.01 |      10 |
|*  8 |     INDEX RANGE SCAN                    | INT_REFDOSS               |    812 |      1 |     2   (0)|    812 |00:00:00.01 |    1642 |
|*  9 |    TABLE ACCESS BY INDEX ROWID BATCHED  | G_CONCENTR_SMALL_PF       |    812 |      1 |     3   (0)|      0 |00:00:00.01 |    1645 |
|* 10 |     INDEX RANGE SCAN                    | G_CONC_SMALL_PF$REFDOSS   |    812 |      1 |     2   (0)|    812 |00:00:00.01 |    1634 |
--------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   6 - access("D"."REFLOT"=:B1)
   7 - access("C"."REFLOT"="D"."REFDOSS")
   8 - access("DB"."REFDOSS"="C"."REFDOSS" AND "DB"."REFTYPE"='DB')
   9 - filter("LIMIT_ID"=:B2)
  10 - access("REFDOSS"="C"."REFDOSS")

*/
/********************************New Metrics***************************************/

/********************************Index statistics**********************************/

/********************************Other SQLs****************************************/          
/*

*/ 
/********************************Other SQLs****************************************/              
