/********************************************************************************
*********       E-mail subject: SVBDEV-7385
*********             Instance: BRANVAL
*********          Description: 
Problem:
Slowness in msgq_pilote on BRANVAL.

Analysis:
From the analyze on BRANVAL we found that SQL 8fjsp327kcgzd from SE variable upd_A_FCTRold1_VALAN was executed with bad execution plan.
The problem in it is that the check for the refdoss is made using OR operator in the subquery, which doesn't allow the 
query to access the tables in the correct order.

Suggestion:
Please change the query as it is shown in the New SQL section below.

*********               SQL_ID: 8fjsp327kcgzd
*********      Program/Package: 
*********              Request: Ivaylo Tsvetkov 
*********               Author: Dimitar Dimitrov
********* Received e-mail date: 19/03/2024
*********      Resolution date: 19/03/2024
*********  Trace old file here: \\epox\specifs\performance\tmp\
*********  Trace new file here:
***********************************************************************************/

/********************************OLD SQL*******************************************/

var REFDOS VARCHAR2(32);
exec :REFDOS := '2403180081';

update g_piece
   set typpiece = 'A.' || substr(typpiece, 1, 28)
 where typpiece = 'FACTORINGCRITERIA'
   and (refdoss = :refdos or
       refdoss in
       (select refdoss
           from g_dossier
          where refhierarchie = :refdos
            and exists (select 1
                   from g_piece
                  where refdoss = g_dossier.refdoss
                    and typpiece = 'CONTRAT ANNEXE'
                    and nvl(gpiaccept, 'O') <> 'N')));
/********************************OLD SQL*******************************************/
/********************************OLD Metrics***************************************/
/*
Plan hash value: 688558025
---------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                              | Name               | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  |
---------------------------------------------------------------------------------------------------------------------------------------------
|   0 | UPDATE STATEMENT                       |                    |      1 |        |     4 (100)|      0 |00:00:08.12 |    6514 |    401 |
|   1 |  UPDATE                                | G_PIECE            |      1 |        |            |      0 |00:00:08.12 |    6514 |    401 |
|*  2 |   FILTER                               |                    |      1 |        |            |      1 |00:00:07.55 |    6394 |    374 |
|   3 |    TABLE ACCESS BY INDEX ROWID BATCHED | G_PIECE            |      1 |   1760 |     4   (0)|   1786 |00:00:07.53 |    4644 |    374 |
|*  4 |     INDEX RANGE SCAN                   | PIECE_TYP_MT43_IDX |      1 |   1760 |     1   (0)|   1786 |00:00:00.15 |      12 |      8 |
|   5 |    NESTED LOOPS SEMI                   |                    |   1745 |      1 |     2   (0)|      0 |00:00:00.01 |    1750 |      0 |
|*  6 |     INDEX RANGE SCAN                   | REFHIERARCHIE_IDX  |   1745 |      1 |     1   (0)|      0 |00:00:00.01 |    1750 |      0 |
|*  7 |     TABLE ACCESS BY INDEX ROWID BATCHED| G_PIECE            |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*  8 |      INDEX RANGE SCAN                  | PIE_REFDOSS        |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
---------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   2 - filter(("REFDOSS"=:REFDOS OR  IS NOT NULL))
   4 - access("TYPPIECE"='FACTORINGCRITERIA')
   6 - access("REFHIERARCHIE"=:REFDOS AND "REFDOSS"=:B1)
       filter("REFDOSS"=:B1)
   7 - filter(NVL("GPIACCEPT",'O')<>'N')
   8 - access("REFDOSS"=:B1 AND "TYPPIECE"='CONTRAT ANNEXE')
       filter("REFDOSS"="G_DOSSIER"."REFDOSS") 
*/
/********************************OLD Metrics***************************************/

/********************************New SQL*******************************************/

update g_piece
   set typpiece = 'A.' || substr(typpiece, 1, 28)
 where typpiece = 'FACTORINGCRITERIA'
   and refdoss in (select :refdos from dual
                    union all 
                   select refdoss
                     from g_dossier
                     where refhierarchie = :refdos
                       and exists (select 1
                                     from g_piece
                                    where refdoss = g_dossier.refdoss
                                      and typpiece = 'CONTRAT ANNEXE'
                                      and nvl(gpiaccept, 'O') <> 'N'));  
/********************************New SQL*******************************************/
/********************************New Metrics***************************************/
/*
Plan hash value: 3744640401
---------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                  | Name              | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers |
---------------------------------------------------------------------------------------------------------------------------------------
|   0 | UPDATE STATEMENT                           |                   |      1 |        |     5 (100)|      0 |00:00:00.01 |     127 |
|   1 |  UPDATE                                    | G_PIECE           |      1 |        |            |      0 |00:00:00.01 |     127 |
|   2 |   NESTED LOOPS                             |                   |      1 |      1 |     5   (0)|      1 |00:00:00.01 |       9 |
|   3 |    NESTED LOOPS                            |                   |      1 |      2 |     5   (0)|      1 |00:00:00.01 |       5 |
|   4 |     VIEW                                   | VW_NSO_1          |      1 |      2 |     4   (0)|      1 |00:00:00.01 |       2 |
|   5 |      SORT UNIQUE                           |                   |      1 |      2 |     4   (0)|      1 |00:00:00.01 |       2 |
|   6 |       UNION-ALL                            |                   |      1 |        |            |      1 |00:00:00.01 |       2 |
|   7 |        FAST DUAL                           |                   |      1 |      1 |     2   (0)|      1 |00:00:00.01 |       0 |
|   8 |        NESTED LOOPS SEMI                   |                   |      1 |      1 |     2   (0)|      0 |00:00:00.01 |       2 |
|*  9 |         INDEX RANGE SCAN                   | REFHIERARCHIE_IDX |      1 |      1 |     1   (0)|      0 |00:00:00.01 |       2 |
|* 10 |         TABLE ACCESS BY INDEX ROWID BATCHED| G_PIECE           |      0 |    269 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 11 |          INDEX RANGE SCAN                  | PIE_REFDOSS       |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 12 |     INDEX RANGE SCAN                       | PIE_REFDOSS       |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |
|  13 |    TABLE ACCESS BY INDEX ROWID             | G_PIECE           |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       4 |
---------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   9 - access("REFHIERARCHIE"=:REFDOS)
  10 - filter(NVL("GPIACCEPT",'O')<>'N')
  11 - access("REFDOSS"="G_DOSSIER"."REFDOSS" AND "TYPPIECE"='CONTRAT ANNEXE')
       filter("REFDOSS" IS NOT NULL)
  12 - access("REFDOSS"=":REFDOS" AND "TYPPIECE"='FACTORINGCRITERIA')
       filter("REFDOSS" IS NOT NULL)  
*/
/********************************New Metrics***************************************/

/********************************Index statistics**********************************/

/********************************Other SQLs****************************************/          
/*

*/ 
/********************************Other SQLs****************************************/              
