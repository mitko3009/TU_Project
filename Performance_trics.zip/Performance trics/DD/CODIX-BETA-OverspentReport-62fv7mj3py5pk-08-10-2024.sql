/********************************************************************************
*********       E-mail subject: CODIXCFDEV-2775
*********             Instance: BETA
*********          Description: 
Problem:
The provided SQL fail after ~20-30 sec with "ORA-20999: unable to extend temp segment by 128 in tablespace TEMP" on BETA after adding condition "AND A.reffactor = nvl(p_bu_reference, A.reffactor)".

Analysis:
We reproduced the query execution on BETA and found that when the condition "AND A.reffactor = nvl(p_bu_reference, A.reffactor)" is added to the query, the CBO choose 
bad execution plan, making MERGE JOIN CARTESIAN between table G_CONNU_EXT_DWH and table T_ECRDOS, which eates the TEMP. We added hint to help Oracle to choose good execution plan, where 
it starts from table G_CONNU_EXT_DWH and joins the other tables using NESTED LOOPS.

Suggestion:
Please add hint as it is shown in the New SQL section below.

*********               SQL_ID: 62fv7mj3py5pk
*********      Program/Package: 
*********              Request: Ilian Nedialkov
*********               Author: Dimitar Dimitrov
********* Received e-mail date: 08/10/2024
*********      Resolution date: 08/10/2024
*********  Trace old file here: \\epox\specifs\performance\tmp\
*********  Trace new file here:
***********************************************************************************/

/********************************OLD SQL*******************************************/
VAR B1 VARCHAR2(32);
EXEC :B1 := 'A60093IR';

WITH NEW_STATE AS ( SELECT I.TABLENAME STAT_TYPE,
                           S.REFDOSS SUBCONTRACT_ID,
                           MAX(S.DEVISE) SUBCONTRACT_CURRENCY,
                           SUM(T.MNT_DCPT) STAT_AMOUNT
                      FROM G_CONNU_EXT_DWH I,
                           G_ELEMFI        E,
                           V_ELEMFI        V,
                           T_ECRDOS        T,
                           G_DOSSIER       A,
                           G_DOSSIER       S
                     WHERE I.REFERENCE = E.REFELEM
                       AND I.EXTSYSTEM = 'FTR_OVERSP'
                       AND I.TABLENAME IN ( 'TOTAL_FUNDED_NOTDUE', 'TOTAL_NOTFUNDED_NOTDUE', 'TOTAL_NOTFUNDED_DUE' )
                       AND V.TYPE = E.TYPE
                       AND T.REFELEM = E.REFELEM
                       AND T.CODECR = V.COMMENTAIRE
                       AND A.REFDOSS = E.REFDOSS
                       AND S.REFDOSS = A.REFLOT
                       AND A.REFFACTOR = NVL(:B1, A.REFFACTOR)
                     GROUP BY I.TABLENAME, S.REFDOSS ),
     OLD_STATE AS ( SELECT IMX_UN_ID, 
                           STAT_TYPE, 
                           REFDOSS, 
                           STAT_AMOUNT, 
                           AMT_CURRENCY
                      FROM STAT_MEMO_EOD
                     WHERE STAT_TYPE IN ( 'TOTAL_FUNDED_NOTDUE', 'TOTAL_NOTFUNDED_NOTDUE', 'TOTAL_NOTFUNDED_DUE' )
                       AND REF_FACTOR = NVL( :B1, REF_FACTOR ) )
SELECT O.IMX_UN_ID IMX_UN_ID,
       NVL(O.STAT_TYPE, N.STAT_TYPE) STAT_TYPE,
       NVL(O.REFDOSS, N.SUBCONTRACT_ID) SUBCONTRACT_ID,
       NVL(O.AMT_CURRENCY, N.SUBCONTRACT_CURRENCY) SUBCONTRACT_CURRENCY,
       NVL(N.STAT_AMOUNT, 0) STAT_AMOUNT
  FROM NEW_STATE N
  FULL OUTER JOIN OLD_STATE O
    ON O.STAT_TYPE = N.STAT_TYPE
   AND O.REFDOSS = N.SUBCONTRACT_ID
 WHERE NVL(N.STAT_AMOUNT, 0) != NVL(O.STAT_AMOUNT, 0);
/********************************OLD SQL*******************************************/
/********************************OLD Metrics***************************************/
/*

MODULE                           PROGRAM                                            CLIENT_ID       SQL_ID         PLAN_HASH     SID SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- -------------------------------------------------- --------------- ------------- ---------- ------- ------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
PL/SQL Developer                 plsqldev.exe                                                       62fv7mj3py5pk 3244775844    2041   24079                      2024/10/08 10:32:18  2024/10/08 10:37:51         333   1 +000000000 00:05:32.462 85%
PL/SQL Developer                 plsqldev.exe                                                       9fyzycp9a53r3 4145146419    2041   24079 ON CPU               2024/10/08 10:25:03  2024/10/08 10:31:50          22       15800 +000000000 00:06:46.611 6%
PL/SQL Developer                 plsqldev.exe                                                       579pc27w27zjy  555409519    2041   24079 ON CPU               2024/10/08 10:24:45  2024/10/08 10:31:51          21       14819 +000000000 00:07:05.622 5%
PL/SQL Developer                 plsqldev.exe                                                       dzuavfqx137v2          0    2041   24079 ON CPU               2024/10/08 10:29:29  2024/10/08 10:31:46           3   9 +000000000 00:02:17.240 1%
PL/SQL Developer                 plsqldev.exe                                                                              0    2041   24079                      2024/10/08 10:29:46  2024/10/08 10:32:15           3     +000000000 00:02:29.287 1%
PL/SQL Developer                 plsqldev.exe                                                       10kcwf9b8kd5j   43251137    2041   24079 ON CPU               2024/10/08 10:30:15  2024/10/08 10:30:25           3  10 +000000000 00:00:10.009 1%
PL/SQL Developer                 plsqldev.exe                                                       9nuuv52uh4ht3 2800400087    2041   24079 ON CPU               2024/10/08 10:31:06  2024/10/08 10:32:17           2  37 +000000000 00:01:11.129 1%
PL/SQL Developer                 plsqldev.exe                                                       cryyukb4g0k3g 3689303362    2041   24079 ON CPU               2024/10/08 10:24:44  2024/10/08 10:24:44           1   1 +000000000 00:00:00.000 0%
PL/SQL Developer                 plsqldev.exe                                                       fmy3cfp7uc5gn  805264310    2041   24079 ON CPU               2024/10/08 10:25:05  2024/10/08 10:25:05           1   1 +000000000 00:00:00.000 0%
PL/SQL Developer                 plsqldev.exe                                                       4hkwy5hbsysct  573760036    2041   24079 ON CPU               2024/10/08 10:30:05  2024/10/08 10:30:05           1   1 +000000000 00:00:00.000 0%
PL/SQL Developer                 plsqldev.exe                                                       441af1x0p6386 3981068896    2041   24079 ON CPU               2024/10/08 10:25:06  2024/10/08 10:25:06           1   1 +000000000 00:00:00.000 0%
PL/SQL Developer                 plsqldev.exe                                                       33jxbcryk12hk 2900191050    2041   24079 ON CPU               2024/10/08 10:31:42  2024/10/08 10:31:42           1   1 +000000000 00:00:00.000 0%
PL/SQL Developer                 plsqldev.exe                                                       5vsya024mcg36 1661131830    2041   24079 db file sequential r 2024/10/08 10:28:56  2024/10/08 10:28:56           1   1 +000000000 00:00:00.000 0%


Plan hash value: 3244775844
----------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                 | Name                      | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers |
----------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                          |                           |      1 |        |    22 (100)|      0 |00:00:00.01 |       0 |
|*  1 |  VIEW                                     | VW_FOJ_0                  |      1 |      3 |    22  (10)|      0 |00:00:00.01 |       0 |
|*  2 |   HASH JOIN FULL OUTER                    |                           |      1 |      3 |    22  (10)|      0 |00:00:00.01 |       0 |
|   3 |    VIEW                                   |                           |      1 |      1 |    12  (17)|      0 |00:00:00.01 |       0 |
|   4 |     HASH GROUP BY                         |                           |      1 |      1 |    12  (17)|      0 |00:00:00.01 |       0 |
|   5 |      NESTED LOOPS                         |                           |      1 |      1 |    11  (10)|      0 |00:00:00.01 |       0 |
|   6 |       NESTED LOOPS                        |                           |      1 |     86 |    11  (10)|      0 |00:00:00.01 |       0 |
|*  7 |        HASH JOIN                          |                           |      1 |     86 |    10  (10)|      0 |00:00:00.01 |       0 |
|   8 |         TABLE ACCESS FULL                 | V_ELEMFI                  |      1 |    149 |     3   (0)|    152 |00:00:00.01 |       6 |
|*  9 |         HASH JOIN                         |                           |      1 |    695 |     6   (0)|      0 |00:00:00.01 |       0 |
|  10 |          MERGE JOIN CARTESIAN             |                           |      1 |  10711 |     2   (0)|     33M|00:00:17.79 |     246 |
|* 11 |           INDEX RANGE SCAN                | PK_G_CONNU_EXT_DWH        |      1 |      1 |     1   (0)|   1403 |00:00:00.02 |      16 |
|  12 |           BUFFER SORT                     |                           |   1403 |  17852 |     1   (0)|     33M|00:00:09.93 |     230 |
|  13 |            INDEX FULL SCAN                | IDX_FFSI_T_ECRDOS         |      1 |  17852 |     1   (0)|  24116 |00:00:00.01 |     230 |
|  14 |          VIEW                             | VW_JF_SET$087DA919        |      0 |   5489 |     4   (0)|      0 |00:00:00.01 |       0 |
|  15 |           UNION-ALL                       |                           |      0 |        |            |      0 |00:00:00.01 |       0 |
|* 16 |            FILTER                         |                           |      0 |        |            |      0 |00:00:00.01 |       0 |
|* 17 |             HASH JOIN                     |                           |      0 |   5485 |     2   (0)|      0 |00:00:00.01 |       0 |
|  18 |              INDEX FULL SCAN              | G_ELEMFI$REFDOSS_ACTIF    |      0 |   5648 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 19 |              INDEX FULL SCAN              | G_DOSSIER_RL_CD_RD_RF_IDX |      0 |   8252 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 20 |            FILTER                         |                           |      0 |        |            |      0 |00:00:00.01 |       0 |
|  21 |             NESTED LOOPS                  |                           |      0 |      4 |     2   (0)|      0 |00:00:00.01 |       0 |
|* 22 |              INDEX SKIP SCAN              | G_DOSSIER_RL_CD_RD_RF_IDX |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 23 |              INDEX RANGE SCAN             | G_ELEMFI$REFDOSS_ACTIF    |      0 |      4 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 24 |        INDEX UNIQUE SCAN                  | DOS_REFDOSS               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|  25 |       TABLE ACCESS BY INDEX ROWID         | G_DOSSIER                 |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|  26 |    VIEW                                   |                           |      0 |      2 |    10   (0)|      0 |00:00:00.01 |       0 |
|  27 |     VIEW                                  | VW_ORE_71773E43           |      0 |      2 |    10   (0)|      0 |00:00:00.01 |       0 |
|  28 |      UNION-ALL                            |                           |      0 |        |            |      0 |00:00:00.01 |       0 |
|* 29 |       FILTER                              |                           |      0 |        |            |      0 |00:00:00.01 |       0 |
|  30 |        TABLE ACCESS BY INDEX ROWID BATCHED| STAT_MEMO_EOD             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 31 |         INDEX RANGE SCAN                  | IDX_STAT_FACTOR_TYPE      |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 32 |       FILTER                              |                           |      0 |        |            |      0 |00:00:00.01 |       0 |
|* 33 |        TABLE ACCESS FULL                  | STAT_MEMO_EOD             |      0 |      1 |     9   (0)|      0 |00:00:00.01 |       0 |
----------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   1 - filter(NVL("N"."STAT_AMOUNT",0)<>NVL("O"."STAT_AMOUNT",0))
   2 - access("O"."STAT_TYPE"="N"."STAT_TYPE" AND "O"."REFDOSS"="N"."SUBCONTRACT_ID")
   7 - access("V"."TYPE"="ITEM_3" AND "T"."CODECR"="V"."COMMENTAIRE")
   9 - access("I"."REFERENCE"="ITEM_4" AND "T"."REFELEM"="ITEM_2")
  11 - access("I"."EXTSYSTEM"='FTR_OVERSP')
       filter(("I"."TABLENAME"='TOTAL_FUNDED_NOTDUE' OR "I"."TABLENAME"='TOTAL_NOTFUNDED_DUE' OR
              "I"."TABLENAME"='TOTAL_NOTFUNDED_NOTDUE'))
  16 - filter(:B1 IS NULL)
  17 - access("A"."REFDOSS"="E"."REFDOSS")
  19 - filter("A"."REFFACTOR" IS NOT NULL)
  20 - filter(:B1 IS NOT NULL)
  22 - access("A"."REFFACTOR"=:B1)
       filter("A"."REFFACTOR"=:B1)
  23 - access("A"."REFDOSS"="E"."REFDOSS")
  24 - access("S"."REFDOSS"="ITEM_1")
  29 - filter(:B1 IS NOT NULL)
  31 - access("REF_FACTOR"=:B1)
       filter(("STAT_TYPE"='TOTAL_FUNDED_NOTDUE' OR "STAT_TYPE"='TOTAL_NOTFUNDED_DUE' OR "STAT_TYPE"='TOTAL_NOTFUNDED_NOTDUE'))
  32 - filter(:B1 IS NULL)
  33 - filter(("REF_FACTOR" IS NOT NULL AND INTERNAL_FUNCTION("STAT_TYPE")))

*/
/********************************OLD Metrics***************************************/

/********************************New SQL*******************************************/

WITH NEW_STATE AS ( SELECT /*+ no_expand leading(I E) */
                           I.TABLENAME STAT_TYPE,
                           S.REFDOSS SUBCONTRACT_ID,
                           MAX(S.DEVISE) SUBCONTRACT_CURRENCY,
                           SUM(T.MNT_DCPT) STAT_AMOUNT
                      FROM G_CONNU_EXT_DWH I,
                           G_ELEMFI        E,
                           V_ELEMFI        V,
                           T_ECRDOS        T,
                           G_DOSSIER       A,
                           G_DOSSIER       S
                     WHERE I.REFERENCE = E.REFELEM
                       AND I.EXTSYSTEM = 'FTR_OVERSP'
                       AND I.TABLENAME IN ( 'TOTAL_FUNDED_NOTDUE', 'TOTAL_NOTFUNDED_NOTDUE', 'TOTAL_NOTFUNDED_DUE' )
                       AND V.TYPE = E.TYPE
                       AND T.REFELEM = E.REFELEM
                       AND T.CODECR = V.COMMENTAIRE
                       AND A.REFDOSS = E.REFDOSS
                       AND S.REFDOSS = A.REFLOT
                       AND A.REFFACTOR = NVL(:B1, A.REFFACTOR)
                     GROUP BY I.TABLENAME, S.REFDOSS ),
     OLD_STATE AS ( SELECT IMX_UN_ID, 
                           STAT_TYPE, 
                           REFDOSS, 
                           STAT_AMOUNT, 
                           AMT_CURRENCY
                      FROM STAT_MEMO_EOD
                     WHERE STAT_TYPE IN ( 'TOTAL_FUNDED_NOTDUE', 'TOTAL_NOTFUNDED_NOTDUE', 'TOTAL_NOTFUNDED_DUE' )
                       AND REF_FACTOR = NVL( :B1, REF_FACTOR ) )
SELECT O.IMX_UN_ID IMX_UN_ID,
       NVL(O.STAT_TYPE, N.STAT_TYPE) STAT_TYPE,
       NVL(O.REFDOSS, N.SUBCONTRACT_ID) SUBCONTRACT_ID,
       NVL(O.AMT_CURRENCY, N.SUBCONTRACT_CURRENCY) SUBCONTRACT_CURRENCY,
       NVL(N.STAT_AMOUNT, 0) STAT_AMOUNT
  FROM NEW_STATE N
  FULL OUTER JOIN OLD_STATE O
    ON O.STAT_TYPE = N.STAT_TYPE
   AND O.REFDOSS = N.SUBCONTRACT_ID
 WHERE NVL(N.STAT_AMOUNT, 0) != NVL(O.STAT_AMOUNT, 0);
/********************************New SQL*******************************************/
/********************************New Metrics***************************************/
/*
Plan hash value: 1257742683
------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                  | Name                 | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers |
------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                           |                      |      1 |        |    17 (100)|      0 |00:00:00.08 |    9991 |
|*  1 |  VIEW                                      | VW_FOJ_0             |      1 |      3 |    17   (6)|      0 |00:00:00.08 |    9991 |
|*  2 |   HASH JOIN FULL OUTER                     |                      |      1 |      3 |    17   (6)|      0 |00:00:00.08 |    9991 |
|   3 |    VIEW                                    |                      |      1 |      1 |     7  (15)|      0 |00:00:00.08 |    9978 |
|   4 |     HASH GROUP BY                          |                      |      1 |      1 |     7  (15)|      0 |00:00:00.08 |    9978 |
|   5 |      NESTED LOOPS                          |                      |      1 |      1 |     6   (0)|      0 |00:00:00.08 |    9978 |
|   6 |       NESTED LOOPS                         |                      |      1 |      1 |     6   (0)|      0 |00:00:00.08 |    9978 |
|   7 |        NESTED LOOPS                        |                      |      1 |      1 |     5   (0)|      0 |00:00:00.08 |    9978 |
|   8 |         NESTED LOOPS                       |                      |      1 |      1 |     4   (0)|      0 |00:00:00.08 |    9978 |
|   9 |          NESTED LOOPS                      |                      |      1 |      1 |     3   (0)|      0 |00:00:00.08 |    9978 |
|  10 |           NESTED LOOPS                     |                      |      1 |      1 |     2   (0)|   3156 |00:00:00.03 |    3326 |
|* 11 |            INDEX RANGE SCAN                | PK_G_CONNU_EXT_DWH   |      1 |      1 |     1   (0)|   3156 |00:00:00.01 |      36 |
|  12 |            TABLE ACCESS BY INDEX ROWID     | G_ELEMFI             |   3156 |      1 |     1   (0)|   3156 |00:00:00.02 |    3290 |
|* 13 |             INDEX UNIQUE SCAN              | EFI_REFELEM          |   3156 |      1 |     1   (0)|   3156 |00:00:00.01 |     134 |
|* 14 |           TABLE ACCESS BY INDEX ROWID      | G_DOSSIER            |   3156 |      1 |     1   (0)|      0 |00:00:00.04 |    6652 |
|* 15 |            INDEX UNIQUE SCAN               | DOS_REFDOSS          |   3156 |      1 |     1   (0)|   3156 |00:00:00.01 |     903 |
|  16 |          TABLE ACCESS BY INDEX ROWID       | G_DOSSIER            |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 17 |           INDEX UNIQUE SCAN                | DOS_REFDOSS          |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|  18 |         TABLE ACCESS BY INDEX ROWID BATCHED| T_ECRDOS             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 19 |          INDEX RANGE SCAN                  | TECR_REFELEM         |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 20 |        INDEX RANGE SCAN                    | VF_TYPE_FINANCING    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 21 |       TABLE ACCESS BY INDEX ROWID          | V_ELEMFI             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|  22 |    VIEW                                    |                      |      1 |      2 |    10   (0)|      0 |00:00:00.01 |      13 |
|  23 |     VIEW                                   | VW_ORE_71773E43      |      1 |      2 |    10   (0)|      0 |00:00:00.01 |      13 |
|  24 |      UNION-ALL                             |                      |      1 |        |            |      0 |00:00:00.01 |      13 |
|* 25 |       FILTER                               |                      |      1 |        |            |      0 |00:00:00.01 |      13 |
|  26 |        TABLE ACCESS BY INDEX ROWID BATCHED | STAT_MEMO_EOD        |      1 |      1 |     1   (0)|      0 |00:00:00.01 |      13 |
|* 27 |         INDEX RANGE SCAN                   | IDX_STAT_FACTOR_TYPE |      1 |      1 |     1   (0)|      0 |00:00:00.01 |      13 |
|* 28 |       FILTER                               |                      |      1 |        |            |      0 |00:00:00.01 |       0 |
|* 29 |        TABLE ACCESS FULL                   | STAT_MEMO_EOD        |      0 |      1 |     9   (0)|      0 |00:00:00.01 |       0 |
------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   1 - filter(NVL("N"."STAT_AMOUNT",0)<>NVL("O"."STAT_AMOUNT",0))
   2 - access("O"."STAT_TYPE"="N"."STAT_TYPE" AND "O"."REFDOSS"="N"."SUBCONTRACT_ID")
  11 - access("I"."EXTSYSTEM"='FTR_OVERSP')
       filter(("I"."TABLENAME"='TOTAL_FUNDED_NOTDUE' OR "I"."TABLENAME"='TOTAL_NOTFUNDED_DUE' OR
              "I"."TABLENAME"='TOTAL_NOTFUNDED_NOTDUE'))
  13 - access("I"."REFERENCE"="E"."REFELEM")
  14 - filter(("A"."REFLOT" IS NOT NULL AND "A"."REFFACTOR"=NVL(:B1,"A"."REFFACTOR")))
  15 - access("A"."REFDOSS"="E"."REFDOSS")
  17 - access("S"."REFDOSS"="A"."REFLOT")
  19 - access("T"."REFELEM"="E"."REFELEM")
  20 - access("V"."TYPE"="E"."TYPE")
  21 - filter("T"."CODECR"="V"."COMMENTAIRE")
  25 - filter(:B1 IS NOT NULL)
  27 - access("REF_FACTOR"=:B1)
       filter(("STAT_TYPE"='TOTAL_FUNDED_NOTDUE' OR "STAT_TYPE"='TOTAL_NOTFUNDED_DUE' OR "STAT_TYPE"='TOTAL_NOTFUNDED_NOTDUE'))
  28 - filter(:B1 IS NULL)
  29 - filter(("REF_FACTOR" IS NOT NULL AND INTERNAL_FUNCTION("STAT_TYPE")))       
*/
/********************************New Metrics***************************************/

/********************************Index statistics**********************************/

/********************************Other SQLs****************************************/          
/*

*/ 
/********************************Other SQLs****************************************/              
