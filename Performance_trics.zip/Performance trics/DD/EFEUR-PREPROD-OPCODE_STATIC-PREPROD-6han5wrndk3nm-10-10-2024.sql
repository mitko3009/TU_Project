/********************************************************************************
*********       E-mail subject: EFDE2DEV-1950
*********             Instance: PREPROD
*********          Description: 
Problem:
SQL 6han5wrndk3nm from FACTOR_INTEREST was responsible for the majority of the time of the OPCODE_STATIC.STD_OPCODE calls.

Analysis:
We manually executed SQL 6han5wrndk3nm on PIZAMR and found that it starts with INDEX FULL SCAN on index DOS_REFDOSS_REFLOT_IDX on table G_DOSSIER. This is because the CONNECT BY PRIOR.
We don't want to make INDEX FULL SCAN, because this will lead to selecting a lot of rows, so we added hint, which will to force Oracle to do INDEX RANGE SCAN in the CONNECT BY PRIOR instead of the INDEX FULL SCAN.

Suggestion:
Please add hint as it is shown in the New SQL section below.

*********               SQL_ID: 6han5wrndk3nm
*********      Program/Package: FACTOR_INTEREST 
*********              Request: Ngoc Le Mong 
*********               Author: Dimitar Dimitrov
********* Received e-mail date: 07/10/2024
*********      Resolution date: 10/10/2024
*********  Trace old file here: \\epox\specifs\performance\tmp\
*********  Trace new file here:
***********************************************************************************/

/********************************OLD SQL*******************************************/

var B1 NUMBER;
EXEC :B1 := 1;
var B2 NUMBER;
EXEC :B2 := 0;
var B3 VARCHAR2(32);
EXEC :B3 := "PMT";
var B4 VARCHAR2(32);
EXEC :B4 := "EUR";
var B5 NUMBER;
EXEC :B5 := 2460593;
var B6 VARCHAR2(32);
EXEC :B6 := "2011210010";

SELECT RATE, 
       MARGIN, 
       RATE_NAME, 
       MIN_RATE
  FROM ( SELECT DECODE(CTR.TYPPIECE, 'CONTRAT', 1, 0),
                FACTOR_INVFUNC.GETBASERATE(DSF.STR3, :B5, DOS.REFFACTOR) RATE,
                NVL(DSF.TX02, 0) MARGIN,
                DSF.STR3 RATE_NAME,
                NVL(DSF.TX05, 0) MIN_RATE
           FROM G_PIECE CTR, 
                G_PIECEDET DSF, 
                G_DOSSIER DOS
          WHERE DOS.REFDOSS IN ( SELECT REFDOSS
                                   FROM G_DOSSIER
                                  START WITH REFDOSS = :B6
                                 CONNECT BY PRIOR REFLOT = REFDOSS )
            AND CTR.REFDOSS = DOS.REFDOSS
            AND DSF.STR1 = 'C'
            AND DSF.STR2 = :B4
            AND DSF.TYPE = 'FACTORING FEE'
            AND (   DSF.STR5 = :B3 
                 OR (    NVL(:B3, 'X') = 'X' 
                     AND DSF.STR5 IS NULL ) 
                )
           AND ( (     DECODE( DSF.FG01, 'N', 0, 1 ) = :B1 
                   AND :B2 = 0 
                 ) 
               OR (    DECODE( DSF.FG02, 'O', 1, 0 ) = :B2 
                   AND :B1 = 0 ) )
            AND DSF.REFDOSS = CTR.REFDOSS
            AND CTR.REFPIECE = DSF.REFPIECE
            AND CTR.TYPPIECE IN ('SOUS-CONTRAT', 'CONTRAT')
            AND NVL( TO_CHAR( DSF.DT01_DT, 'j' ), 0 ) = ( SELECT MAX(NVL(TO_CHAR(LN1.DT01_DT, 'j'), 0) )
                                                            FROM G_PIECEDET LN1
                                                           WHERE NVL(TO_CHAR(LN1.DT01_DT, 'j'), 0) <= :B5
                                                             AND LN1.STR1 = 'C'
                                                             AND LN1.STR2 = DSF.STR2
                                                             AND NVL(LN1.STR5, 'X') = NVL(DSF.STR5, 'X')
                                                             AND LN1.TYPE = 'FACTORING FEE'
                                                             AND LN1.REFDOSS = CTR.REFDOSS
                                                             AND LN1.REFPIECE = CTR.REFPIECE )
          ORDER BY 1, DSF.IMX_UN_ID DESC)
 WHERE ROWNUM = 1;
/********************************OLD SQL*******************************************/
/********************************OLD Metrics***************************************/
/*
call     count       cpu    elapsed       disk      query    current        rows
------- ------  -------- ---------- ---------- ---------- ----------  ----------
Parse        1      0.00       0.00          0          0          0           0
Execute      2      0.02       0.02          0          0          0           0
Fetch        2      0.01       0.01          0        194          0           0
------- ------  -------- ---------- ---------- ---------- ----------  ----------
total        5      0.03       0.03          0        194          0           0

Misses in library cache during parse: 1
Misses in library cache during execute: 1
Optimizer mode: ALL_ROWS
Parsing user id: 76     (recursive depth: 1)

Plan hash value: 2093231902
----------------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                          | Name                   | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers |
----------------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                                   |                        |      1 |        |     7 (100)|      0 |00:00:00.01 |      67 |
|*  1 |  COUNT STOPKEY                                     |                        |      1 |        |            |      0 |00:00:00.01 |      67 |
|   2 |   VIEW                                             |                        |      1 |      1 |     7  (29)|      0 |00:00:00.01 |      67 |
|*  3 |    SORT ORDER BY STOPKEY                           |                        |      1 |      1 |     7  (29)|      0 |00:00:00.01 |      67 |
|*  4 |     FILTER                                         |                        |      1 |        |            |      0 |00:00:00.01 |      67 |
|   5 |      NESTED LOOPS                                  |                        |      1 |      1 |     5  (20)|      0 |00:00:00.01 |      67 |
|   6 |       NESTED LOOPS                                 |                        |      1 |      1 |     5  (20)|      0 |00:00:00.01 |      67 |
|   7 |        NESTED LOOPS                                |                        |      1 |      1 |     4  (25)|      0 |00:00:00.01 |      67 |
|   8 |         NESTED LOOPS                               |                        |      1 |      2 |     3  (34)|      0 |00:00:00.01 |      67 |
|   9 |          VIEW                                      | VW_NSO_1               |      1 |      2 |     2  (50)|      0 |00:00:00.01 |      67 |
|  10 |           HASH UNIQUE                              |                        |      1 |      2 |     2  (50)|      0 |00:00:00.01 |      67 |
|* 11 |            CONNECT BY NO FILTERING WITH SW (UNIQUE)|                        |      1 |        |            |      0 |00:00:00.01 |      67 |
|  12 |             INDEX FULL SCAN                        | DOS_REFDOSS_REFLOT_IDX |      1 |  15876 |     1   (0)|  15876 |00:00:00.01 |      67 |
|  13 |          TABLE ACCESS BY INDEX ROWID               | G_DOSSIER              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 14 |           INDEX UNIQUE SCAN                        | DOS_REFDOSS            |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|  15 |         INLIST ITERATOR                            |                        |      0 |        |            |      0 |00:00:00.01 |       0 |
|  16 |          TABLE ACCESS BY INDEX ROWID BATCHED       | G_PIECE                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 17 |           INDEX RANGE SCAN                         | PIE_REFDOSS            |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 18 |        INDEX RANGE SCAN                            | G_PIECEDET_REFP        |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 19 |       TABLE ACCESS BY INDEX ROWID                  | G_PIECEDET             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|  20 |      SORT AGGREGATE                                |                        |      0 |      1 |            |      0 |00:00:00.01 |       0 |
|* 21 |       TABLE ACCESS BY INDEX ROWID BATCHED          | G_PIECEDET             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 22 |        INDEX RANGE SCAN                            | G_PIECEDET_REFP        |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
----------------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   1 - filter(ROWNUM=1)
   3 - filter(ROWNUM=1)
   4 - filter(NVL(TO_CHAR(INTERNAL_FUNCTION("DSF"."DT01_DT"),'j'),'0')=)
  11 - access("REFDOSS"=PRIOR NULL)
       filter("REFDOSS"=:B6)
  14 - access("DOS"."REFDOSS"="REFDOSS")
  17 - access("CTR"."REFDOSS"="DOS"."REFDOSS" AND (("CTR"."TYPPIECE"='CONTRAT' OR "CTR"."TYPPIECE"='SOUS-CONTRAT')))
  18 - access("CTR"."REFPIECE"="DSF"."REFPIECE" AND "DSF"."TYPE"='FACTORING FEE')
  19 - filter(("DSF"."STR2"=:B4 AND "DSF"."STR1"='C' AND "DSF"."REFDOSS"="CTR"."REFDOSS" AND ((:B2=0 AND DECODE("DSF"."FG01",'N',0,1)=:B1)
              OR (:B1=0 AND DECODE("DSF"."FG02",'O',1,0)=:B2)) AND "DSF"."REFDOSS" IS NOT NULL AND (("DSF"."STR5" IS NULL AND NVL(:B3,'X')='X') OR
              "DSF"."STR5"=:B3)))
  21 - filter(("LN1"."STR1"='C' AND "LN1"."REFDOSS"=:B1 AND "LN1"."STR2"=:B2 AND NVL("LN1"."STR5",'X')=NVL(:B3,'X')))
  22 - access("LN1"."REFPIECE"=:B1 AND "LN1"."TYPE"='FACTORING FEE')
       filter(TO_NUMBER(NVL(TO_CHAR(INTERNAL_FUNCTION("LN1"."DT01_DT"),'j'),'0'))<=:B5)


*/
/********************************OLD Metrics***************************************/

/********************************New SQL*******************************************/

SELECT RATE, 
       MARGIN, 
       RATE_NAME, 
       MIN_RATE
  FROM ( SELECT DECODE(CTR.TYPPIECE, 'CONTRAT', 1, 0),
                FACTOR_INVFUNC.GETBASERATE(DSF.STR3, :B5, DOS.REFFACTOR) RATE,
                NVL(DSF.TX02, 0) MARGIN,
                DSF.STR3 RATE_NAME,
                NVL(DSF.TX05, 0) MIN_RATE
           FROM G_PIECE CTR, 
                G_PIECEDET DSF, 
                G_DOSSIER DOS
          WHERE DOS.REFDOSS IN ( SELECT /*+ CONNECT_BY_FILTERING */
                                        REFDOSS
                                   FROM G_DOSSIER
                                  START WITH REFDOSS = :B6
                                 CONNECT BY PRIOR REFLOT = REFDOSS )
            AND CTR.REFDOSS = DOS.REFDOSS
            AND DSF.STR1 = 'C'
            AND DSF.STR2 = :B4
            AND DSF.TYPE = 'FACTORING FEE'
            AND (   DSF.STR5 = :B3 
                 OR (    NVL(:B3, 'X') = 'X' 
                     AND DSF.STR5 IS NULL ) 
                )
           AND ( (     DECODE( DSF.FG01, 'N', 0, 1 ) = :B1 
                   AND :B2 = 0 
                 ) 
               OR (    DECODE( DSF.FG02, 'O', 1, 0 ) = :B2 
                   AND :B1 = 0 ) )
            AND DSF.REFDOSS = CTR.REFDOSS
            AND CTR.REFPIECE = DSF.REFPIECE
            AND CTR.TYPPIECE IN ('SOUS-CONTRAT', 'CONTRAT')
            AND NVL( TO_CHAR( DSF.DT01_DT, 'j' ), 0 ) = ( SELECT MAX(NVL(TO_CHAR(LN1.DT01_DT, 'j'), 0) )
                                                            FROM G_PIECEDET LN1
                                                           WHERE NVL(TO_CHAR(LN1.DT01_DT, 'j'), 0) <= :B5
                                                             AND LN1.STR1 = 'C'
                                                             AND LN1.STR2 = DSF.STR2
                                                             AND NVL(LN1.STR5, 'X') = NVL(DSF.STR5, 'X')
                                                             AND LN1.TYPE = 'FACTORING FEE'
                                                             AND LN1.REFDOSS = CTR.REFDOSS
                                                             AND LN1.REFPIECE = CTR.REFPIECE )
          ORDER BY 1, DSF.IMX_UN_ID DESC)
 WHERE ROWNUM = 1;
/********************************New SQL*******************************************/
/********************************New Metrics***************************************/
/*
Plan hash value: 2587649868
--------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                      | Name                   | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   |
--------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                               |                        |      1 |        |     9 (100)|      0 |00:00:00.01 |
|*  1 |  COUNT STOPKEY                                 |                        |      1 |        |            |      0 |00:00:00.01 |
|   2 |   VIEW                                         |                        |      1 |      1 |     9  (23)|      0 |00:00:00.01 |
|*  3 |    SORT ORDER BY STOPKEY                       |                        |      1 |      1 |     9  (23)|      0 |00:00:00.01 |
|*  4 |     FILTER                                     |                        |      1 |        |            |      0 |00:00:00.01 |
|   5 |      NESTED LOOPS                              |                        |      1 |      1 |     7  (15)|      0 |00:00:00.01 |
|   6 |       NESTED LOOPS                             |                        |      1 |      1 |     7  (15)|      0 |00:00:00.01 |
|   7 |        NESTED LOOPS                            |                        |      1 |      1 |     6  (17)|      0 |00:00:00.01 |
|   8 |         NESTED LOOPS                           |                        |      1 |      2 |     5  (20)|      0 |00:00:00.01 |
|   9 |          VIEW                                  | VW_NSO_1               |      1 |      2 |     4  (25)|      0 |00:00:00.01 |
|  10 |           HASH UNIQUE                          |                        |      1 |      2 |     4  (25)|      0 |00:00:00.01 |
|* 11 |            CONNECT BY WITH FILTERING (UNIQUE)  |                        |      1 |        |            |      0 |00:00:00.01 |
|  12 |             TABLE ACCESS BY INDEX ROWID BATCHED| G_DOSSIER              |      1 |      1 |     1   (0)|      0 |00:00:00.01 |
|* 13 |              INDEX RANGE SCAN                  | DOSS_CODESOC_IDX       |      1 |      1 |     1   (0)|      0 |00:00:00.01 |
|  14 |             NESTED LOOPS                       |                        |      0 |      1 |     2   (0)|      0 |00:00:00.01 |
|  15 |              CONNECT BY PUMP                   |                        |      0 |        |            |      0 |00:00:00.01 |
|* 16 |              INDEX RANGE SCAN                  | DOS_REFDOSS_REFLOT_IDX |      0 |      1 |     1   (0)|      0 |00:00:00.01 |
|  17 |          TABLE ACCESS BY INDEX ROWID           | G_DOSSIER              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |
|* 18 |           INDEX UNIQUE SCAN                    | DOS_REFDOSS            |      0 |      1 |     1   (0)|      0 |00:00:00.01 |
|  19 |         INLIST ITERATOR                        |                        |      0 |        |            |      0 |00:00:00.01 |
|  20 |          TABLE ACCESS BY INDEX ROWID BATCHED   | G_PIECE                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |
|* 21 |           INDEX RANGE SCAN                     | PIE_REFDOSS            |      0 |      1 |     1   (0)|      0 |00:00:00.01 |
|* 22 |        INDEX RANGE SCAN                        | G_PIECEDET_REFP        |      0 |      1 |     1   (0)|      0 |00:00:00.01 |
|* 23 |       TABLE ACCESS BY INDEX ROWID              | G_PIECEDET             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |
|  24 |      SORT AGGREGATE                            |                        |      0 |      1 |            |      0 |00:00:00.01 |
|* 25 |       TABLE ACCESS BY INDEX ROWID BATCHED      | G_PIECEDET             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |
|* 26 |        INDEX RANGE SCAN                        | G_PIECEDET_REFP        |      0 |      1 |     1   (0)|      0 |00:00:00.01 |
--------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   1 - filter(ROWNUM=1)
   3 - filter(ROWNUM=1)
   4 - filter(NVL(TO_CHAR(INTERNAL_FUNCTION("DSF"."DT01_DT"),'j'),'0')=)
  11 - access("REFDOSS"=PRIOR NULL)
  13 - access("REFDOSS"=:B6)
  16 - access("connect$_by$_pump$_006"."PRIOR REFLOT "="REFDOSS")
  18 - access("DOS"."REFDOSS"="REFDOSS")
  21 - access("CTR"."REFDOSS"="DOS"."REFDOSS" AND (("CTR"."TYPPIECE"='CONTRAT' OR "CTR"."TYPPIECE"='SOUS-CONTRAT')))
  22 - access("CTR"."REFPIECE"="DSF"."REFPIECE" AND "DSF"."TYPE"='FACTORING FEE')
  23 - filter(("DSF"."STR2"=:B4 AND "DSF"."STR1"='C' AND "DSF"."REFDOSS"="CTR"."REFDOSS" AND ((:B2=0 AND
              DECODE("DSF"."FG01",'N',0,1)=:B1) OR (:B1=0 AND DECODE("DSF"."FG02",'O',1,0)=:B2)) AND "DSF"."REFDOSS" IS NOT NULL AND
              (("DSF"."STR5" IS NULL AND NVL(:B3,'X')='X') OR "DSF"."STR5"=:B3)))
  25 - filter(("LN1"."STR1"='C' AND "LN1"."REFDOSS"=:B1 AND "LN1"."STR2"=:B2 AND NVL("LN1"."STR5",'X')=NVL(:B3,'X')))
  26 - access("LN1"."REFPIECE"=:B1 AND "LN1"."TYPE"='FACTORING FEE')
       filter(TO_NUMBER(NVL(TO_CHAR(INTERNAL_FUNCTION("LN1"."DT01_DT"),'j'),'0'))<=:B5)
*/
/********************************New Metrics***************************************/

/********************************Index statistics**********************************/

/********************************Other SQLs****************************************/          
/*

*/ 
/********************************Other SQLs****************************************/              
