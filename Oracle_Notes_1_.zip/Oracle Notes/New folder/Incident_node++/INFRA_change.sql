Task plane steps:

RFC Task#: E-C01853631-T??? will be visible when it gets to Implement Phase
RFC #:  E-C01853631

DB Details:
EMEA HPSM STAGING DATABASE INFORMATION
Nodes: frgreracs151.ssn.entsvcs.com - frgreracs154.ssn.entsvcs.com
Database Name: TSMGRE
DB Service Name: TSMGRE_SMEMRT_APPL

TSMGRE_SMEMRT_APPL =
  (DESCRIPTION =
    (ADDRESS = (PROTOCOL = TCP)(HOST = EMEA1STG-RAC2.ssn.entsvcs.com)(PORT = 1521))
    (CONNECT_DATA =
      (SERVER = SHARED)
      (SERVICE_NAME = TSMGRE_SMEMRT_APPL)
      (FAILOVER_MODE =
        (TYPE = NONE)
      )
    )
  )

NOTE: Refer to the E-C01853631|SRA EMEA| STAGING/ (RTE) | HPSM EMEA |Downtime| R5.0.0p82 Task Plan for more detail on the below tasks

Both procedures are attached "please ask confirmation/GO on each step you perform":

1. R5.0 HPSM CHANGE GUIDE.DOCX
2. Guaranteed DB flashbacksetup v3.2.docx

DBA scripts Phase 2 
None

Tasks
Phase 0 (in advance of upgrade)
None

Phase 1 (pre-outage)
Phase 1 Task 4 Confirm DB is OK to proceed with the change. Perform basic DB health check, Verify the DB is in sync, etc.

Phase 2 (outage)
Phase 2 Task 2   NOTE: these sub tasks . . . 
2a. Disable cron
2b. Disable automatic Oracle jobs
2c. Lock the read users: ‘%_READ’ and ‘SM_%’ and 'SMA%'
2d. Lock the RWS ID: 'FRAMEWORK_WSACCESS' 
2e. Shut down DB prior to setting Flashback point. This will clear active sessions
2f. Disconnect any inactive/active sessions for the locked users in 2c and 2d.
2g. Set the Flashback restore point

Phase 2 Task 36 
Unlock the read users: ‘%_READ’ and ‘SM_%’ and 'SMA%' 
Unlock the RWS ID: 'FRAMEWORK_WSACCESS'

Phase 3 (start-up and testing)
None (support issues as needed)

Phase 4 (Post outage)
Phase 4 Task 12

Oracle Maintenance jobs which were stopped prior to the upgrade should be reinstated.
14a. Enable cron
14b. Enable automatic Oracle jobs"

Task 8 Drop Flashback Restore Point

Phase 9 (ONLY In the event of a backout)
Phase 9 Task 20:

R5.0.0p82 MTP step 9.1.0.2 Restore Flashback Point

Phase 10 Task 1 Drop Flashback Restore Point
