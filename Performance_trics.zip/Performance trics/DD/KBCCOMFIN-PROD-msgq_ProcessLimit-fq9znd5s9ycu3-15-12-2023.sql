/********************************************************************************
*********       E-mail subject: KBCCFWEB-2193
*********             Instance: ACC1
*********          Description: 
Problem:
Slowness in msgq_ProcessLimit from ACC1.

Analysis:
The TOP sql for the provided periods was fq9znd5s9ycu3. It was executed with inappropriate execution plan. 
It was starting its execution from column GPIDEPOT on table G_PIECE, which is not selective. According to the model, 
we can use column GPILIBLIBRE, which combines the Debtor, Factor and Client. It is much more selective, which leads 
to selecting less data and using a good execution plan.


Suggestion:
Please modify the SQL fq9znd5s9ycu3 from ftr_request_limit.pck as it is shown in the New SQL section below.

*********               SQL_ID: fq9znd5s9ycu3
*********      Program/Package: ftr_request_limit.pck
*********              Request: Trung Cong Van 
*********               Author: Dimitar Dimitrov
********* Received e-mail date: 15/12/2023
*********      Resolution date: 15/12/2023
*********  Trace old file here: \\epox\specifs\performance\tmp\
*********  Trace new file here:
***********************************************************************************/

/********************************OLD SQL*******************************************/
var B5 VARCHAR2(128);
exec :B5 := 'F';
var B4 VARCHAR2(1000);
exec :B4 := 'D1261898';
var B3 VARCHAR2(32);
exec :B3 := 'D1028390';
var B2 VARCHAR2(32);
exec :B2 := 'INT00000';
var B1 VARCHAR2(32);
exec :B1 := 'O042LLMX';


SELECT GPIRESSORT
  FROM G_PIECE
 WHERE TYPPIECE = 'REQUEST_LIMITE'
   AND TYPEDOC = :B5
   AND GPIRESSORT IS NOT NULL
   AND GPIDEPOT = :B4
   AND GPIADR3 = :B3
   AND GPITYPTRIB = :B2
   AND REFPIECE != :B1
   AND ROWNUM = 1;
/********************************OLD SQL*******************************************/
/********************************OLD Metrics***************************************/
/*
BUFF           MSGSEQ REFDOSS    PROCESSEDB LOCKEDBY                                 DATETR_DT           DTPROCESS_DT        DT_ENDPROC_DT       PARENT_MSGSEQ
---------- ---------- ---------- ---------- ---------------------------------------- ------------------- ------------------- ------------------- -------------
ProcessLim  630579231 1508210230 msg_queue                                           2023-12-14 13:28:18 2023-12-14 13:29:34 2023-12-14 13:31:53
it@

ProcessLim  630582108 1406170219 msg_q02                                             2023-12-14 13:29:28 2023-12-14 13:30:49 2023-12-14 13:33:29
it@

ProcessLim  630582395 1406170219 msg_q02                                             2023-12-14 13:29:36 2023-12-14 14:10:46 2023-12-14 14:11:49
it@



INSTANCE_NUMBER SQL_ID            ELAPSED MAX_WAIT_ON     PC_OF  WAIT_TIME            GETS      READS       ROWS  ELAP/EXEC       GETS/EXEC READS/EXEC  ROWS/EXEC       EXEC PLAN_HASH_VALUE
--------------- ------------- ----------- --------------- ----- ---------- --------------- ---------- ---------- ---------- --------------- ---------- ---------- ---------- ---------------
              1 fq9znd5s9ycu3        2575 CPU             90%   2580.35535      1601772339     460468        762       2.17         1347159     387.27        .64       1189      2615056867



-- From 13:29:36  to 13:31:56  

MODULE                           SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
msgq_ProcessLimit                fq9znd5s9ycu3 2615056867                       db file sequential r 2023/12/14 13:29:36  2023/12/14 13:31:56          20                    2 +000000000 00:02:20.004 95%
msgq_ProcessLimit                64wwu4fd9jnsg 2998107965       1422      16620 ON CPU               2023/12/14 13:31:46  2023/12/14 13:31:46           1                    1 +000000000 00:00:00.000 5%


MODULE                           SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
msgq_ProcessLimit                fq9znd5s9ycu3 2615056867       1422      16620 db file sequential r 2023/12/14 13:29:36  2023/12/14 13:31:36          13                    1 +000000000 00:02:00.004 65%
msgq_ProcessLimit                fq9znd5s9ycu3 2615056867        279      46110 db file sequential r 2023/12/14 13:30:56  2023/12/14 13:31:56           7                    1 +000000000 00:01:00.001 35%

SQL_ID        SQL_PLAN_HASH_VALUE SQL_PLAN_LINE_ID SQL_PLAN_OPERATION             SQL_PLAN_OPTIONS                   ACTIVE
------------- ------------------- ---------------- ------------------------------ ------------------------------ ----------
fq9znd5s9ycu3          2615056867                2 TABLE ACCESS                   BY INDEX ROWID BATCHED                558
fq9znd5s9ycu3          2615056867                3 INDEX                          RANGE SCAN                             18

-- From 13:29:36 to 13:33:56 

MODULE                           SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
msgq_ProcessLimit                fq9znd5s9ycu3 2615056867       1422      16620                      2023/12/14 13:29:36  2023/12/14 13:33:56          21                   42 +000000000 00:04:20.006 47%
msgq_ProcessLimit                fq9znd5s9ycu3 2615056867        279      46110                      2023/12/14 13:30:56  2023/12/14 13:33:26          16                   28 +000000000 00:02:30.003 36%
msgq_ProcessLimit                64wwu4fd9jnsg 2998107965       1422      16620 ON CPU               2023/12/14 13:31:46  2023/12/14 13:33:26           3                    8 +000000000 00:01:40.002 7%
msgq_ProcessLimit                1a1kugm8kdj14          0       1422      16620 ON CPU               2023/12/14 13:32:26  2023/12/14 13:32:26           1                    1 +000000000 00:00:00.000 2%
msgq_ProcessLimit                64wwu4fd9jnsg 2998107965        279      46110 ON CPU               2023/12/14 13:33:46  2023/12/14 13:33:46           1                    1 +000000000 00:00:00.000 2%
msgq_ProcessLimit                g50p9r5qdps4k 2547837514        279      46110 db file sequential r 2023/12/14 13:33:36  2023/12/14 13:33:36           1                    1 +000000000 00:00:00.000 2%
msgq_ProcessLimit                6qdzu42dm9ymv 2615056867       1422      16620 ON CPU               2023/12/14 13:32:16  2023/12/14 13:32:16           1                    1 +000000000 00:00:00.000 2%
msgq_ProcessLimit                8nsxk09pwtpjh 2518490584        279      46110 ON CPU               2023/12/14 13:33:56  2023/12/14 13:33:56           1                    1 +000000000 00:00:00.000 2%


-- From 14:10:06 to 14:11:56 


MODULE                           SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
msgq_ProcessLimit                fq9znd5s9ycu3 2615056867       1422      16620 ON CPU               2023/12/14 14:10:06  2023/12/14 14:11:56          12                   78 +000000000 00:01:50.008 52%
msgq_ProcessLimit                fq9znd5s9ycu3 2615056867        279      46110 ON CPU               2023/12/14 14:10:16  2023/12/14 14:10:36           3                   22 +000000000 00:00:20.001 13%
msgq_ProcessLimit                26nc9m12xhuts 2903800507        279      46110 db file sequential r 2023/12/14 14:11:26  2023/12/14 14:11:26           1                    1 +000000000 00:00:00.000 4%
msgq_ProcessLimit                8nsxk09pwtpjh 2518490584        279      46110 ON CPU               2023/12/14 14:11:36  2023/12/14 14:11:36           1                    1 +000000000 00:00:00.000 4%
msgq_ProcessLimit                9kr03nnyr3pw3 3465093507        279      46110 ON CPU               2023/12/14 14:11:56  2023/12/14 14:11:56           1                    1 +000000000 00:00:00.000 4%
msgq_ProcessLimit                14m1tp9jw5xrq 4037593343        279      46110 ON CPU               2023/12/14 14:10:56  2023/12/14 14:10:56           1                    1 +000000000 00:00:00.000 4%
msgq_ProcessLimit                0m65wnnpmmj9y          0        279      46110 ON CPU               2023/12/14 14:11:46  2023/12/14 14:11:46           1                    1 +000000000 00:00:00.000 4%
msgq_ProcessLimit                1sswmkz38v4r0 1390029100        279      46110 db file sequential r 2023/12/14 14:11:06  2023/12/14 14:11:06           1                    1 +000000000 00:00:00.000 4%
msgq_ProcessLimit                1q3g1b8042p8k 3375136027        279      46110 ON CPU               2023/12/14 14:11:16  2023/12/14 14:11:16           1                      +000000000 00:00:00.000 4%
msgq_ProcessLimit                6qdzu42dm9ymv 3664023496        279      46110 db file sequential r 2023/12/14 14:10:06  2023/12/14 14:10:06           1                    1 +000000000 00:00:00.000 4%

-- fq9znd5s9ycu3 

Plan hash value: 2615056867
----------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                            | Name      | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  |
----------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                     |           |      1 |        |     1 (100)|      0 |00:00:05.69 |   44789 |  11306 |
|*  1 |  COUNT STOPKEY                       |           |      1 |        |            |      0 |00:00:05.69 |   44789 |  11306 |
|*  2 |   TABLE ACCESS BY INDEX ROWID BATCHED| G_PIECE   |      1 |      1 |     1   (0)|      0 |00:00:05.69 |   44789 |  11306 |
|*  3 |    INDEX RANGE SCAN                  | GP_GPIDEP |      1 |     42 |     1   (0)|  23122 |00:00:00.05 |     121 |    120 |
----------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   1 - filter(ROWNUM=1)
   2 - filter(("GPIRESSORT" IS NOT NULL AND "GPIADR3"=:B3 AND "TYPEDOC"=:B5 AND "TYPPIECE"='REQUEST_LIMITE' AND
              "GPITYPTRIB"=:B2 AND "REFPIECE"<>:B1))
   3 - access("GPIDEPOT"=:B4)

*/
/********************************OLD Metrics***************************************/

/********************************New SQL*******************************************/
SELECT /*+ index(G_PIECE PIE_GPILIBLIBRE) */
       GPIRESSORT
  FROM G_PIECE
 WHERE TYPPIECE = 'REQUEST_LIMITE'
   AND TYPEDOC = :B5
   AND GPIRESSORT IS NOT NULL
   AND GPILIBLIBRE like 'L1.'||:B3||'.'||:B4||'.'||:B2||'.%'
   AND REFPIECE != :B1
   AND ROWNUM = 1;
/********************************New SQL*******************************************/
/********************************New Metrics***************************************/
/*
Plan hash value: 1744533074
-------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                            | Name            | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers |
-------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                     |                 |      1 |        |     1 (100)|      0 |00:00:00.01 |      14 |
|*  1 |  COUNT STOPKEY                       |                 |      1 |        |            |      0 |00:00:00.01 |      14 |
|*  2 |   TABLE ACCESS BY INDEX ROWID BATCHED| G_PIECE         |      1 |      1 |     1   (0)|      0 |00:00:00.01 |      14 |
|*  3 |    INDEX RANGE SCAN                  | PIE_GPILIBLIBRE |      1 |      7 |     1   (0)|      5 |00:00:00.01 |       4 |
-------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   1 - filter(ROWNUM=1)
   2 - filter(("GPIRESSORT" IS NOT NULL AND "TYPEDOC"=:B5 AND "TYPPIECE"='REQUEST_LIMITE' AND "REFPIECE"<>:B1))
   3 - access("GPILIBLIBRE" LIKE 'L1.'||:B3||'.'||:B4||'.'||:B2||'.%')
       filter("GPILIBLIBRE" LIKE 'L1.'||:B3||'.'||:B4||'.'||:B2||'.%')
*/
/********************************New Metrics***************************************/

/********************************Index statistics**********************************/

/********************************Other SQLs****************************************/          
/*

*/ 
/********************************Other SQLs****************************************/              
