==============================================================
#### Check the  and start up ####

LSNR-0001:TNS check did not detect  _WISK7 oracle,  may be down; Error [Oracle  _WISK7 oracle process not running.].

=============================================================

root@uv158871 # ps -ef | grep pmon
  oracle 17806 14881   0   Jul 03 ?          20:12 ora_pmon_WISK7_P
  oracle 18417 14881   0   Jul 03 ?          18:00 ora_pmon_WISKI_P
    root 23147 22251   0 13:40:17 pts/2       0:00 grep pmon

 
root@uv158871 # ps -ef | grep tns
  oracle  1172 14881   0   Jul 03 ?          74:45 /oracle/product/12.1.0.2.161018_EE/bin/tnslsnr _WISK7P -inherit
    root 23507 22251   0 13:40:28 pts/2       0:00 grep tns
  oracle  1228 14881   0   Jul 03 ?          11:01 /oracle/product/11.2.0.4.161018_EE/bin/tnslsnr _WISKI -inherit
  oracle  2237 14881   0   Jul 03 ?           2:34 /oracle/product/12.1.0.2.161018_EE/bin/tnslsnr _OOB -inherit


root@uv158871 # su - oracle
Oracle Corporation      SunOS 5.10      Generic Patch   January 2005


$ . oraenv
ORACLE_SID = [WISKI_P] ? WISK7_P

$ env |grep ORA


$ cd $ORACLE_HOME/network/admin


$ ls -la
total 17
drwxr-xr-x   3 oracle   oinstall       5 Mar  6  2018 .
drwxr-xr-x  10 oracle   oinstall      10 Dec  7  2016 ..
drwxr-xr-x   2 oracle   oinstall       5 Dec  7  2016 samples
-rw-r--r--   1 oracle   oinstall     373 Mar 16  2014 shrept.lst
-rw-r--r--   1 oracle   oinstall    2504 Mar  6  2018 tnsnames.ora


$ env | grep tns                                                          ##### Това е в случай,че .ora не се намира в $ORACLE_HOME/network/admin #####
TNS_ADMIN=/oracle/admin/network


$ cd /oracle/admin/network

$ ls -la
total 32
drwxr-xr-x   2 oracle   oinstall       7 Jan 15  2018 .
drwxr-xr-x   6 oracle   oinstall       6 Feb 15  2018 ..
-rw-r--r--   1 oracle   oinstall    1477 Jan 15  2018 .ora
-rw-r--r--   1 oracle   oinstall    1095 Dec 16  2014 .ora_save_20161209
-rw-r--r--   1 oracle   oinstall    1255 Jan 16  2018 sqlnet.ora
-rw-r--r--   1 oracle   oinstall    2504 Jan 17  2018 tnsnames.ora
-rw-r--r--   1 oracle   oinstall    1532 Nov 26  2013 tnsnames.ora_save_20161209


$ cat .ora                                            ###### Лисънърите,които трябва да вървят  се намират в този файл ####
_WISKI =
  (DESCRIPTION_LIST =
      (DESCRIPTION =
         (ADDRESS = (PROTOCOL = TCP)(HOST = wiski-db.vlaanderen.be)(PORT = 1521)(IP=FIRST))
      )
  )
TRACE_LEVEL__WISKI = OFF
TRACE_DIRECTORY__WISKI = /oracle/admin/network/trace
TRACE_FILE__WISKI = _wiski.trc
LOG_DIRECTORY__WISKI = /oracle/diag/tnslsnr/uv158871/_wiski/trace
LOG_FILE__WISKI = _wiski.log
INBOUND_CONNECT_TIMEOUT__WISKI = 120


_WISK7P =
  (DESCRIPTION_LIST =
      (DESCRIPTION =
         (ADDRESS = (PROTOCOL = TCP)(HOST = wiski7_p-db.vlaanderen.be )(PORT = 1521)(IP=FIRST))
      )
  )
TRACE_LEVEL__WISK7P = OFF
TRACE_DIRECTORY__WISK7P = /oracle/admin/network/trace
TRACE_FILE__WISK7P = _wisk7p.trc
LOG_DIRECTORY__WISK7P = /oracle/diag/tnslsnr/uv158871/_wisk7p/trace
LOG_FILE__WISK7P = _wisk7p.log
INBOUND_CONNECT_TIMEOUT__WISK7P = 120


_OOB =
  (DESCRIPTION_LIST =
    (DESCRIPTION =
      (ADDRESS_LIST =
        (ADDRESS = (PROTOCOL = TCP)(HOST = uv158871-oob.vlaanderen.be)(PORT = 1521)(IP=FIRST))
      )
    )
  )
TRACE_LEVEL__OOB = OFF
TRACE_DIRECTORY__OOB = /oracle/diag/tnslsnr/uv158871/_oob/trace
TRACE_FILE__OOB = _oob.trc
LOG_DIRECTORY__OOB = /oracle/diag/tnslsnr/uv158871/_oob/log
LOG_FILE__OOB = _oob.log
INBOUND_CONNECT_TIMEOUT__OOB = 120


root@uv158871 # cd /var/opt/OV
root@uv158871 # ls -la
total 66
dr-xr-sr-x  21 bin      bin           22 Sep  8  2016 .
drwxr-xr-x  10 root     sys           10 Feb  9  2018 ..
-rw-r--r--   1 root     other          0 Feb 15  2012 5.9
drwxrwsr-x   3 root     bin            3 Sep  8  2016 HC
drwxrwsr-x   2 bin      bin            2 Feb 15  2012 SPISvcDisc
drwxr-xr-x   4 root     other          4 Feb 15  2012 bin
drwxrwsr-x   2 bin      bin            2 Feb 15  2012 certificates
drwxrwsr-x  11 bin      bin           13 Oct 31  2016 conf
drwxr-sr-x   8 bin      bin           15 Aug  4 00:00 datafiles
drwxr-sr-x   6 root     bin           30 Aug  7 13:03 dbspi
drwxr-sr-x   2 root     bin            2 Jun 20  2013 dsi2ddf
drwxrwsr-x   2 bin      bin            2 Feb 15  2012 images
drwxrwsr-x   7 bin      bin            7 Nov 20  2014 installation
drwxr-sr-x   4 bin      bin           18 Oct 17  2017 log
drwxrwsr-x   2 bin      bin            2 Feb 15  2012 osspi
drwxrwsr-x   2 bin      bin            2 Feb 15  2012 packages
drwxr-sr-x   3 root     root           3 Feb 15  2012 share
drwxrwsr-x   2 bin      bin            2 Feb 15  2012 shared
drwxr-sr-x   3 root     root           3 Feb 15  2012 sockets
drwxr-sr-x   8 bin      bin           18 Jul  3 12:09 tmp
drwxr-xr-x   3 root     other          3 Feb 15  2012 var
drwxrwsr-x   3 bin      bin            3 Feb 15  2012 www

root@uv158871 # cd dbspi


root@uv158871 # ls -la
total 324
drwxr-sr-x   6 root     bin           30 Aug  7 13:03 .
dr-xr-sr-x  21 bin      bin           22 Sep  8  2016 ..
-rwxr--r--   1 root     bin        79159 Aug  7 13:18 db_mon.cfg
-rw-rw-r--   1 root     bin        10723 Apr  4 22:11 dbmon-event.cfg
-rw-------   1 root     bin           29 Apr  4 22:11 dbmon-event.checksum
-rw-rw-r--   1 root     bin         9934 Apr 29  2016 dbmon-event.old.20190404221119
-rw-r--r--   1 root     bin           36 Jan 29  2018 dbmon.defaults
-rw-r--r--   1 root     bin           54 Jan 30  2018 dbmon..defaults
-rw-------   1 root     bin           35 Aug  7 13:28 dbmon.lock.15m
-rw-------   1 root     bin           35 Aug  7 13:23 dbmon.lock.1h
-rw-------   1 root     bin           35 Aug  7 12:48 dbmon.lock.30m
-rw-------   1 root     bin           35 Aug  7 13:23 dbmon.lock.3h
-rw-------   1 root     bin           35 Aug  7 13:48 dbmon.lock.5m
-rw-------   1 root     bin           33 Aug  6 15:13 dbmon.lock.7d
-rw-------   1 root     bin           34 Aug  6 18:46 dbmon.lock.ORACLE.1d.report
-rw-------   1 root     bin           35 Aug  7 13:13 dbmon.lock.ORACLE.1h.report
-rw-------   1 root     bin           35 Aug  7 12:10 dbmon.lock.ORACLE.4h.report
-rw-------   1 root     bin           36 Aug  7 13:49 dbmon.lock.ORACLE.5m.report
-rw-rw-r--   1 root     bin           13 Aug  7 13:49 dbmon.lock.event-health
-rw-------   1 root     bin           41 Aug  7 13:50 dbmon.lock.housekeeping
-rw-------   1 root     bin           44 Aug  7 13:49 dbmon.lock.measureware
-rw-rw-r--   1 root     bin        17279 Aug  7 13:48 dbmon_save.store
-rw-r--r--   1 root     bin          100 Mar  6  2018 dbtab
-rw-r--r--   1 root     bin           11 Jun 19 12:55 defaults
drwxr-sr-x   6 root     bin            6 Oct  1  2013 dsi
drwxr-sr-x   6 root     bin            6 Oct  1  2013 history
-rw-------   1 root     bin          689 Mar  6  2018 local.cfg
-rw-r--r--   1 root     bin            0 Oct  1  2013 local.lck
drwxr-sr-x   2 root     bin            7 Aug  7 13:03 log
drwxr-sr-x   2 root     bin          590 Aug  7 13:49 tmp

root@uv158871 # vi db_mon.cfg                                               ##### Четем конфигурационния файл, какво търси като име dbspi ####



######## КАТО ДАДЕМ / И СЛЕД ТОВА "N" ЗА ДА ПРЕЛИСТВАМЕ ПРЕЗ ФАЙЛА И ТРЯБВА ДА СТИГНЕМ ДО ТОВА ПО-ДОЛУ,КОЕТО НИ КАЗВА ИМЕТО НА ЛИСЪНЪРА,КОЙТО DBSPI-A ТЪРСИ

#---------------------------Oracle  monitoring----------------------
# EMEA default setting, adjust if necessary (examples and syntax above)
2=15m:Critical:TT:oracle:_WISK7:
#---------------------------End of Oracle  monitoring----------------------


##### АКО -A Е НАИСТИНА ДОЛУ ГО СТАРТИРАМЕ :

1. ГЛЕДАМ КОЙ Е ЮЗЪРА НА ЛИСЪНЪРА --->суитчвам се ---> сетвам енвайрманта (Ако всяка база е с различен лисънър,нейн си) ---> start <_NAME>
2. Ако юзъра е GRID ----> суитчвам на него и ----> env | grep ORA ----> ps -ef|grep pmon /tns ----> start <LISTEREN_NAME> 

 ### SHANO START  ###
 
srvctl start  - ora.EBSQ.lsnr