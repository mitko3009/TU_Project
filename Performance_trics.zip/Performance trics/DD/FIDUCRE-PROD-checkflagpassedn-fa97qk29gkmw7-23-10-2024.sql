/********************************************************************************
*********       E-mail subject: FIDWEB-4081
*********             Instance: PROD
*********          Description: 
Problem:
The FDR_INTERFACES_CASES.checkflagpassedn took over 3 hours on FIDUCRE PROD.

Analysis:
We checked for the period between 21:30 on 17/10/2024 and 01:30 on 18/10/2024 on PROD and based on what we saw in the provided AWR Report and 
in the analyze from the AWR ( from the dba_hist_active_sess_history table ) we found that the two TOP SQLs are 7k404ff4dtpg4 and fa97qk29gkmw7. They were 
responsible for over 80% of the time. The problem in them is that there is no index on column REFEXT_TA on table T_FIN_AMO, which leads to FULL SCAN on table T_FIN_AMO 
on every execution.

Suggestion:
Could you please check is it possible to create index on column REFEXT_TA on table T_FIN_AMO?

*********               SQL_ID: fa97qk29gkmw7, 7k404ff4dtpg4
*********      Program/Package: 
*********              Request: Dimitare Ivanov
*********               Author: Dimitar Dimitrov
********* Received e-mail date: 22/10/2024
*********      Resolution date: 23/10/2024
*********  Trace old file here: \\epox\specifs\performance\tmp\
*********  Trace new file here:
***********************************************************************************/

/********************************OLD SQL*******************************************/

-- fa97qk29gkmw7

SELECT COUNT(1) 
  FROM T_FIN_AMO 
 WHERE REFEXT_TA = :B1;


-- 7k404ff4dtpg4

SELECT REFDOSS_REQST, 
	     IMX_UN_ID 
	FROM T_FIN_AMO 
 WHERE IMX_UN_ID = ( SELECT MAX(IMX_UN_ID) 
                       FROM T_FIN_AMO 
                      WHERE REFEXT_TA = :B1 ) 
   AND REFEXT_TA = :B1;
/********************************OLD SQL*******************************************/
/********************************OLD Metrics***************************************/
/*
MODULE                           PROGRAM                                            CLIENT_ID       SQL_ID                                   PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO            ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                 PERC
-------------------------------- -------------------------------------------------- --------------- --------------------------------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
checkflagpassedn0                sqlplus                                            unknown                                                                                                       2024/10/17 21:30:04  2024/10/18 01:32:25      1352             13070068 +000000000 04:02:20.864 14%
checkflagpassedn3                sqlplus                                            unknown                                                                                                       2024/10/17 21:30:04  2024/10/18 01:32:25      1352             14973724 +000000000 04:02:20.864 14%
checkflagpassedn1                sqlplus                                            unknown                                                                   808      19599                      2024/10/17 21:45:36  2024/10/18 01:32:25      1330             15331136 +000000000 03:46:49.023 13%
checkflagpassedn2                sqlplus                                            unknown                                                                   544      18427                      2024/10/17 21:45:36  2024/10/18 01:32:25      1330             16486488 +000000000 03:46:49.023 13%
scsm.exe                         scsm.exe                                                                                                                                                         2024/10/17 21:30:56  2024/10/18 01:59:54       907                 7892 +000000000 04:28:58.365 9%
                                                                                                                                                     0                                            2024/10/17 21:30:04  2024/10/18 01:58:32       887                      +000000000 04:28:27.648 9%
exp_texte                        exp_texte                                                                                                                                                        2024/10/17 21:30:04  2024/10/18 01:59:23       502             12893917 +000000000 04:29:18.848 5%
restore incr datafile            rman                                                                                                                0                                            2024/10/18 00:12:33  2024/10/18 00:35:46       494                      +000000000 00:23:12.704 5%
msgq_pilote       



MODULE                           CLIENT_ID       SQL_ID                                   PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL     PERC
-------------------------------- --------------- --------------------------------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
                                 unknown         7k404ff4dtpg4                           1087304261                                            2024/10/17 21:30:15  2024/10/18 01:32:25        2252                58564 +000000000 04:02:10.623 42%
                                 unknown         fa97qk29gkmw7                           1953929474                                            2024/10/17 21:30:04  2024/10/18 01:32:25        2188                59413 +000000000 04:02:20.864 41%
                                 unknown         8agvdwgcqs5zx                           3827967622                                            2024/10/17 21:46:07  2024/10/18 01:31:44         587                57779 +000000000 03:45:37.345 11%
                                 unknown         g2c5cz9u2zjs1                           1629617147                                            2024/10/17 21:46:28  2024/10/18 01:32:05         128              2908651 +000000000 03:45:37.346 2%
                                 unknown         ckc9ytd1j3kb1                           2023583973                                            2024/10/17 21:46:17  2024/10/18 01:28:50          74              2907779 +000000000 03:42:33.026 1%
                                 unknown         9fyzycp9a53r3                           4145146419                       ON CPU               2024/10/17 21:46:07  2024/10/18 01:07:41          37              2830157 +000000000 03:21:33.504 1%
                                 unknown         apkny8tpk4ut5                           3290939490                                            2024/10/17 21:49:52  2024/10/18 00:00:26          14              2609124 +000000000 02:10:33.600 0%
                                 unknown         gtd0sv52nxs5z                            272002086                       ON CPU               2024/10/17 21:58:24  2024/10/17 23:46:47          12              6538043 +000000000 01:48:22.400 0%
checkflagpassedn2                unknown         dq7y8ur6fwq9k                                    0        544      18427                      2024/10/17 21:45:47  2024/10/18 01:07:10          12                    1 +000000000 03:21:23.263 0%
checkflagpassedn0                unknown         921uufnb3zujf                                    0       1077      55512                      2024/10/17 21:52:05  2024/10/17 22:43:58          11                    1 +000000000 00:51:52.966 0%
                                 unknown                                                          0                       ON CPU               2024/10/17 21:50:13  2024/10/17 23:38:45          10                      +000000000 01:48:32.640 0%
                                 unknown         3672wyaqu1nxh                                                            ON CPU               2024/10/17 22:01:29  2024/10/17 23:30:13           9              1906675 +000000000 01:28:44.798 0%
                                 unknown         5nz2kbbnwz2xc                           1285499833                                            2024/10/17 21:30:56  2024/10/18 01:13:08           8                    8 +000000000 03:42:12.540 0%
                                 unknown         b4k59zmmhx44y                            272002086                       ON CPU               2024/10/17 22:40:23  2024/10/17 23:48:19           7              1777630 +000000000 01:07:55.520 0%
checkflagpassedn1                unknown         0874mg7s021a7                                    0        808      19599 ON CPU               2024/10/17 21:59:56  2024/10/17 22:50:17           6                    1 +000000000 00:50:20.801 0%
checkflagpassedn3                unknown         d6z7102ybq0gp                                    0        817      16802                      2024/10/17 21:49:22  2024/10/17 22:46:12           4                    1 +000000000 00:56:49.919 0%
                                 unknown         bg490j15zyt4g                                                            ON CPU               2024/10/17 21:47:39  2024/10/17 22:22:08           2                    1 +000000000 00:34:28.475 0%
checkflagpassedn2                unknown         3n92vbvwhg5wp                             34689647        544      18427 ON CPU               2024/10/17 21:50:33  2024/10/17 21:50:33           1                    1 +000000000 00:00:00.000 0%
checkflagpassedn3                unknown         gn0808jvqks58                            341395321        818       8777 db file scattered re 2024/10/17 21:33:40  2024/10/17 21:33:40           1                    1 +000000000 00:00:00.000 0%
checkflagpassedn0                unknown         9wa7j8btmfq8f                           3154700513        812      56198 db file sequential r 2024/10/17 21:33:40  2024/10/17 21:33:40           1                    1 +000000000 00:00:00.000 0%
 
 
INSTANCE_NUMBER SQL_ID                                      ELAPSED MAX_WAIT_ON     PC_OF  WAIT_TIME            GETS      READS       ROWS  ELAP/EXEC       GETS/EXEC READS/EXEC  ROWS/EXEC       EXEC PLAN_HASH_VALUE
--------------- --------------------------------------- ----------- --------------- ----- ---------- --------------- ---------- ---------- ---------- --------------- ---------- ---------- ---------- ---------------
              1 fa97qk29gkmw7                                 23808 CPU             100%  23037.9837      2914761246          0      62424        .38           46422          0        .99      62788      1953929474
              1 7k404ff4dtpg4                                 23472 CPU             100%  22724.1256      2877271060        317      61165        .38           46842        .01          1      61425      1087304261
              1 8agvdwgcqs5zx                                  6543 CPU             98%   6381.65316       607537090     321917    3023076        .11            9800       5.19      48.77      61992      3827967622 

OWNER           TABLE_NAME   INDEX_NAME                     INFO        BLEVEL       ROWS   ROWS/KEY       KEYS     BLOCKS         CF  DATAB/KEY  LEAFB/KEY LAST_ANALYZED       COLUMNS
--------------- ------------ ------------------------------ ------- ---------- ---------- ---------- ---------- ---------- ---------- ---------- ---------- ------------------- ----------------------------------------
IMXBUFF         BUF_CASES_PL PK_BUF_CASES_PL                UNIQUE           2   14462176          1   14462176      30810          1          1          1 2024-10-23 06:04:35 IMX_UN_ID
IMXBUFF         BUF_CASES_PL BUF_CASES_PL_REF                                3   14462176 327.732415      44128      74931         38        320          1 2024-10-23 06:04:34 REF_TA
IMXDB           T_FIN_AMO    IX_REQST_ANNEX                                  0          0          0          0          0          0          0          0 2024-10-20 02:29:35 ANNEX_ID
IMXDB           T_FIN_AMO    T_FIN_AMO_DWT                                   2    3520984 22.1078461     159264      19192         18          5          1 2024-10-20 02:29:35 DW_TIMESTAMP
IMXDB           T_FIN_AMO    PK_T_FIN_AMO                   UNIQUE           2    3520984          1    3520984       8234         63          1          1 2024-10-20 02:29:35 IMX_UN_ID
IMXDB           T_FIN_AMO    TFA_REFDOSS_REQ_IDX                             2    3520984 13.7831329     255456      13081         75         13          1 2024-10-20 02:29:35 REFDOSS_REQST
IMXDB           T_FIN_AMO    IX_TAMO_REQST                                   2    3520984 13.7900426     255328      12008         75         13          1 2024-10-20 02:29:34 REFPIECE_REQST


-- fa97qk29gkmw7

Plan hash value: 1953929474
--------------------------------------------------------------
| Id  | Operation          | Name      | E-Rows | Cost (%CPU)|
--------------------------------------------------------------
|   0 | SELECT STATEMENT   |           |        |  9961 (100)|
|   1 |  SORT AGGREGATE    |           |      1 |            |
|   2 |   TABLE ACCESS FULL| T_FIN_AMO |      5 |  9961   (1)|
--------------------------------------------------------------

 
-- 7k404ff4dtpg4

Plan hash value: 1087304261
--------------------------------------------------------------------------
| Id  | Operation                   | Name         | E-Rows | Cost (%CPU)|
--------------------------------------------------------------------------
|   0 | SELECT STATEMENT            |              |        |  9962 (100)|
|   1 |  TABLE ACCESS BY INDEX ROWID| T_FIN_AMO    |      1 |     1   (0)|
|   2 |   INDEX UNIQUE SCAN         | PK_T_FIN_AMO |      1 |     1   (0)|
|   3 |    SORT AGGREGATE           |              |      1 |            |
|   4 |     TABLE ACCESS FULL       | T_FIN_AMO    |      5 |  9961   (1)|
--------------------------------------------------------------------------

*/
/********************************OLD Metrics***************************************/

/********************************New SQL*******************************************/

-- No change in the SQL Text.
/********************************New SQL*******************************************/
/********************************New Metrics***************************************/
/*

*/
/********************************New Metrics***************************************/

/********************************Index statistics**********************************/

/********************************Other SQLs****************************************/          
/*

*/ 
/********************************Other SQLs****************************************/              
