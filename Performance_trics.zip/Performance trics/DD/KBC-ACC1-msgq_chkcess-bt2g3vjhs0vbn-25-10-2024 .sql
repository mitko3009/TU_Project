/********************************************************************************
*********       E-mail subject: KBCCFDEV-6095
*********             Instance: ACC1
*********          Description: 
Problem:
The msgq_chkcess took ~3 hours on KBC ACC1.

Analysis:
We checked the msgq_chkcess module for the provided period and found that the TOP SQL was bt2g3vjhs0vbn, which was responsible for ~90% of the time.
We checked the execution plan of the query and it looks like the heaviest operation is the INDEX FULL SCAN on index G_DOSSIER_RL_CD_RD_RF_IDX on table G_DOSSIER.
This is because one of the DECODEs " WHERE REFDOSS = DECODE( CATEGDOSS, 'COMPTE DB CTR', D.REFDOSS, D.REFLOT ) ".
Depending on the CATEGDOSS column, is takes column REFDOSS or column REFLOT from table G_DOSSIER D and than access the other G_DOSSIER through REFDOSS column which makes INDEX FULL SCAN.
The solution that we can suggest here is to make the DECODE to UNION, which will allow us to make INDEX UNIQUE SCAN on table G_DOSSIER.
 

Suggestion:
Please change SQL bt2g3vjhs0vbn ( from ftr_alert_aux.pck ) as it is shown in the New SQL section below.

*********               SQL_ID: bt2g3vjhs0vbn
*********      Program/Package: ftr_alert_aux.pck
*********              Request: Lubomir Vladov 
*********               Author: Dimitar Dimitrov
********* Received e-mail date: 25/10/2024
*********      Resolution date: 25/10/2024
*********  Trace old file here: \\epox\specifs\performance\tmp\
*********  Trace new file here:
***********************************************************************************/

/********************************OLD SQL*******************************************/

VAR B1 VARCHAR2(32);
EXEC :B1 := '0001010123';

SELECT DECODE( SUBSTR(CATEGDOSS, 1, 6),
               'COMPTE',
               ( SELECT RANGMT
                   FROM G_DOSSIER DOS,
                        G_PERSONNEL PER
                  WHERE DOS.REFDOSS = ( SELECT DECODE( CATEGDOSS,
                                                       'COMPTE DB CTR',
                                                       REFDOSS,
                                                       REFLOT )
                                          FROM G_DOSSIER
                                         WHERE REFDOSS = DECODE( CATEGDOSS,
                                                                 'COMPTE DB CTR',
                                                                 D.REFDOSS,
                                                                 D.REFLOT ) )
                    AND PER.REFPERSO = DOS.RANGMT
                    AND NVL(PER.EXTRANET_ONLY, 'N') != 'O'
                    AND NVL(PER.DTFINVAL_DT, SYSDATE + 1) > SYSDATE ),
               'DECOMP',
                ( SELECT RANGMT
                    FROM G_DOSSIER DOS,
                         G_PERSONNEL PER
                   WHERE DOS.REFDOSS = D.REFLOT
                     AND PER.REFPERSO = DOS.RANGMT
                     AND NVL(PER.EXTRANET_ONLY, 'N') != 'O'
                     AND NVL(PER.DTFINVAL_DT, SYSDATE + 1) > SYSDATE ),
               'CONTRA',
               ( SELECT RANGMT
                   FROM G_DOSSIER DOS, 
                        G_PERSONNEL PER
                  WHERE REFDOSS = D.REFDOSS
                    AND PER.REFPERSO = DOS.RANGMT
                    AND NVL(PER.EXTRANET_ONLY, 'N') != 'O'
                    AND NVL(PER.DTFINVAL_DT, SYSDATE + 1) > SYSDATE ) ) "Rangmt"
  FROM G_DOSSIER D
 WHERE REFDOSS = :B1;
/********************************OLD SQL*******************************************/
/********************************OLD Metrics***************************************/
/*
MODULE                           PROGRAM                                            CLIENT_ID       SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                    ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- -------------------------------------------------- --------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
msgq_chkcess                     msg_q03                                                                                            784      42895 ON CPU               2024/10/25 10:00:05  2024/10/25 13:08:20     1021              9471935 +000000000 03:08:14.720 23%
DDFC203FA6222A291BF8C05095CEEF85 iMX BE                                             JA84503         cp9v56ag67t6s 2133805739        136      22374 ON CPU               2024/10/25 10:34:44  2024/10/25 13:09:52      899                    1 +000000000 02:35:08.160 21%
imx2creq                         soa_integration                                                                                                   db file sequential r 2024/10/25 10:00:05  2024/10/25 13:09:52      811                    4 +000000000 03:09:46.880 19%
al_engine.exe                    al_engine.exe                                                                                                     db file sequential r 2024/10/25 11:08:21  2024/10/25 13:09:52      552              8169038 +000000000 02:01:30.880 13%
imxbatch_ClientFunding           imxbatch                                                                                           400      17592 db file sequential r 2024/10/25 11:00:09  2024/10/25 11:51:21      230              7999379 +000000000 00:51:12.000 5%



MODULE                           PROGRAM                                            CLIENT_ID       SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- -------------------------------------------------- --------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
msgq_chkcess                     msg_q03                                                                                            784      42895                      2024/10/25 10:00:05  2024/10/25 13:08:20        1044              9471935 +000000000 03:08:14.720 100%

-- ~2.9h in the database

MODULE                           PROGRAM                                            CLIENT_ID       SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                     ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- -------------------------------------------------- --------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
msgq_chkcess                     msg_q03                                                                                            784      42895 ON CPU               2024/10/25 10:00:05  2024/10/25 13:08:20        1021              9471935 +000000000 03:08:14.720 98%
msgq_chkcess                     msg_q03                                                                                   0        784      42895 log file sync        2024/10/25 10:11:31  2024/10/25 12:48:42          14                      +000000000 02:37:11.040 1%
msgq_chkcess                     msg_q03                                                                                            784      42895 db file scattered re 2024/10/25 10:04:52  2024/10/25 13:06:48           5               253298 +000000000 03:01:55.840 0%
msgq_chkcess                     msg_q03                                                                                            784      42895 db file sequential r 2024/10/25 11:59:23  2024/10/25 13:07:28           3               443681 +000000000 01:08:05.760 0%
msgq_chkcess                     msg_q03                                                            30y3ykzp1c9a7          0        784      42895 db file parallel rea 2024/10/25 13:05:05  2024/10/25 13:05:05           1                    1 +000000000 00:00:00.000 0%


MODULE                           PROGRAM                                            CLIENT_ID       SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- -------------------------------------------------- --------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
msgq_chkcess                     msg_q03                                                            bt2g3vjhs0vbn  777268185        784      42895 ON CPU               2024/10/25 10:12:02  2024/10/25 13:00:39         927                32139 +000000000 02:48:37.120 89%
msgq_chkcess                     msg_q03                                                                                   0        784      42895                      2024/10/25 10:04:41  2024/10/25 12:48:42          15                      +000000000 02:44:00.640 1%
msgq_chkcess                     msg_q03                                                            579pc27w27zjy  555409519        784      42895 ON CPU               2024/10/25 10:05:22  2024/10/25 13:05:56           9               401346 +000000000 03:00:33.920 1%
msgq_chkcess                     msg_q03                                                            9nffg3gd8463j  485353734        784      42895                      2024/10/25 10:05:02  2024/10/25 10:10:09           6                19658 +000000000 00:05:07.200 1%


SQL_ID        SQL_PLAN_HASH_VALUE SQL_PLAN_LINE_ID SQL_PLAN_OPERATION             SQL_PLAN_OPTIONS                   ACTIVE
------------- ------------------- ---------------- ------------------------------ ------------------------------ ----------
bt2g3vjhs0vbn           777268185                4 INDEX                          FULL SCAN                             927


INSTANCE_NUMBER SQL_ID            ELAPSED MAX_WAIT_ON     PC_OF  WAIT_TIME            GETS      READS       ROWS  ELAP/EXEC       GETS/EXEC READS/EXEC  ROWS/EXEC       EXEC PLAN_HASH_VALUE
--------------- ------------- ----------- --------------- ----- ---------- --------------- ---------- ---------- ---------- --------------- ---------- ---------- ---------- ---------------
              1 bt2g3vjhs0vbn        9462 CPU             100%  9426.98696       616076009       4232      33548        .28           18363        .13          1      33549       777268185


Plan hash value: 777268185
---------------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                        | Name                           | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  |
---------------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                 |                                |      1 |        |     7 (100)|      1 |00:00:00.01 |       4 |      0 |
|   1 |  NESTED LOOPS                    |                                |      1 |      1 |     2   (0)|      0 |00:00:02.62 |   19166 |   4197 |
|   2 |   NESTED LOOPS                   |                                |      1 |      1 |     2   (0)|      1 |00:00:02.62 |   19165 |   4197 |
|*  3 |    INDEX RANGE SCAN              | G_DOSSIER_REFDOSS_SOLDE_RANGMT |      1 |      1 |     1   (0)|      1 |00:00:02.62 |   19163 |   4197 |
|*  4 |     INDEX FULL SCAN              | G_DOSSIER_RL_CD_RD_RF_IDX      |      1 |      1 |   192   (1)|      1 |00:00:02.62 |   19160 |   4197 |
|*  5 |    INDEX RANGE SCAN              | PK_G_PERSONNEL                 |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       2 |      0 |
|*  6 |   TABLE ACCESS BY INDEX ROWID    | G_PERSONNEL                    |      1 |      1 |     1   (0)|      0 |00:00:00.01 |       1 |      0 |
|   7 |    NESTED LOOPS                  |                                |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|   8 |     NESTED LOOPS                 |                                |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*  9 |      INDEX RANGE SCAN            | G_DOSSIER_REFDOSS_SOLDE_RANGMT |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 10 |      INDEX RANGE SCAN            | PK_G_PERSONNEL                 |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 11 |     TABLE ACCESS BY INDEX ROWID  | G_PERSONNEL                    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|  12 |      NESTED LOOPS                |                                |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|  13 |       NESTED LOOPS               |                                |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 14 |        INDEX RANGE SCAN          | G_DOSSIER_REFDOSS_SOLDE_RANGMT |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 15 |        INDEX RANGE SCAN          | PK_G_PERSONNEL                 |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 16 |       TABLE ACCESS BY INDEX ROWID| G_PERSONNEL                    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|  17 |  TABLE ACCESS BY INDEX ROWID     | G_DOSSIER                      |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       4 |      0 |
|* 18 |   INDEX UNIQUE SCAN              | DOS_REFDOSS                    |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |      0 |
---------------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   3 - access("DOS"."REFDOSS"=)
   4 - filter("REFDOSS"=DECODE("CATEGDOSS",'COMPTE DB CTR',:B1,:B2))
   5 - access("PER"."REFPERSO"="DOS"."RANGMT")
   6 - filter((NVL("PER"."EXTRANET_ONLY",'N')<>'O' AND NVL("PER"."DTFINVAL_DT",SYSDATE@!+1)>SYSDATE@!))
   9 - access("DOS"."REFDOSS"=:B1)
  10 - access("PER"."REFPERSO"="DOS"."RANGMT")
  11 - filter((NVL("PER"."EXTRANET_ONLY",'N')<>'O' AND NVL("PER"."DTFINVAL_DT",SYSDATE@!+1)>SYSDATE@!))
  14 - access("REFDOSS"=:B1)
  15 - access("PER"."REFPERSO"="DOS"."RANGMT")
  16 - filter((NVL("PER"."EXTRANET_ONLY",'N')<>'O' AND NVL("PER"."DTFINVAL_DT",SYSDATE@!+1)>SYSDATE@!))
  18 - access("REFDOSS"=:B1)

*/
/********************************OLD Metrics***************************************/

/********************************New SQL*******************************************/

SELECT DECODE( SUBSTR(CATEGDOSS, 1, 6),
               'COMPTE',
               ( SELECT RANGMT
                   FROM G_DOSSIER DOS,
                        G_PERSONNEL PER
                  WHERE DOS.REFDOSS = ( SELECT D.REFDOSS
                                          FROM DUAL
                                         WHERE D.CATEGDOSS = 'COMPTE DB CTR'
                                        UNION
                                        SELECT REFLOT 
                                          FROM G_DOSSIER
                                         WHERE REFDOSS = D.REFLOT
                                           AND CATEGDOSS != 'COMPTE DB CTR' )
                    AND PER.REFPERSO = DOS.RANGMT
                    AND NVL(PER.EXTRANET_ONLY, 'N') != 'O'
                    AND NVL(PER.DTFINVAL_DT, SYSDATE + 1) > SYSDATE ),
               'DECOMP',
                ( SELECT RANGMT
                    FROM G_DOSSIER DOS,
                         G_PERSONNEL PER
                   WHERE DOS.REFDOSS = D.REFLOT
                     AND PER.REFPERSO = DOS.RANGMT
                     AND NVL(PER.EXTRANET_ONLY, 'N') != 'O'
                     AND NVL(PER.DTFINVAL_DT, SYSDATE + 1) > SYSDATE ),
               'CONTRA',
               ( SELECT RANGMT
                   FROM G_DOSSIER DOS, 
                        G_PERSONNEL PER
                  WHERE REFDOSS = D.REFDOSS
                    AND PER.REFPERSO = DOS.RANGMT
                    AND NVL(PER.EXTRANET_ONLY, 'N') != 'O'
                    AND NVL(PER.DTFINVAL_DT, SYSDATE + 1) > SYSDATE ) ) "Rangmt"
  FROM G_DOSSIER D
 WHERE REFDOSS = :B1;
/********************************New SQL*******************************************/
/********************************New Metrics***************************************/
/*
Plan hash value: 2832541229
------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                        | Name                           | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers |
------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                 |                                |      1 |        |     7 (100)|      1 |00:00:00.01 |       4 |
|   1 |  NESTED LOOPS                    |                                |      1 |      1 |     2   (0)|      0 |00:00:00.01 |      10 |
|   2 |   NESTED LOOPS                   |                                |      1 |      1 |     2   (0)|      1 |00:00:00.01 |       9 |
|*  3 |    INDEX RANGE SCAN              | G_DOSSIER_REFDOSS_SOLDE_RANGMT |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       7 |
|   4 |     SORT UNIQUE                  |                                |      1 |      2 |     3   (0)|      1 |00:00:00.01 |       4 |
|   5 |      UNION-ALL                   |                                |      1 |        |            |      1 |00:00:00.01 |       4 |
|*  6 |       FILTER                     |                                |      1 |        |            |      0 |00:00:00.01 |       0 |
|   7 |        FAST DUAL                 |                                |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |
|*  8 |       TABLE ACCESS BY INDEX ROWID| G_DOSSIER                      |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       4 |
|*  9 |        INDEX UNIQUE SCAN         | DOS_REFDOSS                    |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |
|* 10 |    INDEX RANGE SCAN              | PK_G_PERSONNEL                 |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       2 |
|* 11 |   TABLE ACCESS BY INDEX ROWID    | G_PERSONNEL                    |      1 |      1 |     1   (0)|      0 |00:00:00.01 |       1 |
|  12 |    NESTED LOOPS                  |                                |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |
|  13 |     NESTED LOOPS                 |                                |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |
|* 14 |      INDEX RANGE SCAN            | G_DOSSIER_REFDOSS_SOLDE_RANGMT |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 15 |      INDEX RANGE SCAN            | PK_G_PERSONNEL                 |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 16 |     TABLE ACCESS BY INDEX ROWID  | G_PERSONNEL                    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|  17 |      NESTED LOOPS                |                                |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |
|  18 |       NESTED LOOPS               |                                |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |
|* 19 |        INDEX RANGE SCAN          | G_DOSSIER_REFDOSS_SOLDE_RANGMT |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 20 |        INDEX RANGE SCAN          | PK_G_PERSONNEL                 |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 21 |       TABLE ACCESS BY INDEX ROWID| G_PERSONNEL                    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|  22 |  TABLE ACCESS BY INDEX ROWID     | G_DOSSIER                      |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       4 |
|* 23 |   INDEX UNIQUE SCAN              | DOS_REFDOSS                    |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |
------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   3 - access("DOS"."REFDOSS"=)
   6 - filter(:B1='COMPTE DB CTR')
   8 - filter("CATEGDOSS"<>'COMPTE DB CTR')
   9 - access("REFDOSS"=:B1)
  10 - access("PER"."REFPERSO"="DOS"."RANGMT")
  11 - filter((NVL("PER"."EXTRANET_ONLY",'N')<>'O' AND NVL("PER"."DTFINVAL_DT",SYSDATE@!+1)>SYSDATE@!))
  14 - access("DOS"."REFDOSS"=:B1)
  15 - access("PER"."REFPERSO"="DOS"."RANGMT")
  16 - filter((NVL("PER"."EXTRANET_ONLY",'N')<>'O' AND NVL("PER"."DTFINVAL_DT",SYSDATE@!+1)>SYSDATE@!))
  19 - access("REFDOSS"=:B1)
  20 - access("PER"."REFPERSO"="DOS"."RANGMT")
  21 - filter((NVL("PER"."EXTRANET_ONLY",'N')<>'O' AND NVL("PER"."DTFINVAL_DT",SYSDATE@!+1)>SYSDATE@!))
  23 - access("REFDOSS"=:B1)

*/
/********************************New Metrics***************************************/

/********************************Index statistics**********************************/

/********************************Other SQLs****************************************/          
/*

*/ 
/********************************Other SQLs****************************************/              
