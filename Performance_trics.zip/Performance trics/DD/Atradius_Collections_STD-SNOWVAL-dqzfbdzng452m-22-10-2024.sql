/********************************************************************************
*********       E-mail subject: ACSTDDEV-3433
*********             Instance: SNOWVAL
*********          Description: 
Problem:
Loading paragraphs into shared memory took 3-5 minutes on SNOWVAL.

Analysis:
We checked in the ASH for the work of ini_par module and found that the TOP SQL in it, which is responsible for 100% of the time is dqzfbdzng452m.
This query was executed only once, but it took over 10 minutes and according to the ASH, the heaviest operation in it was the SELECT.
We made some tests and found that the reason for the slow fetch is because the query is using SUBSTR() on column "txt", which is from type CLOB.
We changed the query to use DBMS_LOB.SUBSTR() instead of the SUBSTR(), because the DBMS_LOB.SUBSTR() is special for columns from LOB type.
The reason that on SNOW it took less time is because in table t_paragr on SNOWVAL there are ~10k rows where column "txt" is longer that 4000 characters,
while on SNOW in table t_paragr there are ~600 rows where column "txt" is longer that 4000 characters.

Suggestion:
Please change the query as it is shown in the New SQL section below.

*********               SQL_ID: dqzfbdzng452m
*********      Program/Package: utl_se_shm.pcs
*********              Request: Ngo Trung Hai
*********               Author: Dimitar Dimitrov
********* Received e-mail date: 22/10/2024
*********      Resolution date: 22/10/2024
*********  Trace old file here: \\epox\specifs\performance\tmp\
*********  Trace new file here:
***********************************************************************************/

/********************************OLD SQL*******************************************/

var b0 number;
exec :b0 := 100;

SELECT TRIM(nom), 
       SUBSTR(txt, 1, :b0), 
       bindata_type
  FROM t_paragr
 WHERE TRIM(nom) IS NOT NULL
 ORDER BY TRIM(nom), nuligne;
/********************************OLD SQL*******************************************/
/********************************OLD Metrics***************************************/
/*
MODULE                           PROGRAM                                            CLIENT_ID       SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- -------------------------------------------------- --------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
ini_par                          ini_par                                                            dqzfbdzng452m 3014071762        594      63491 db file sequential r 2024/10/22 07:19:11  2024/10/22 07:23:59        269                     1 +000000000 00:04:48.355 82%
                                 oracle                                                                                    0       1710      15223 db file parallel wri 2024/10/22 07:18:12  2024/10/22 07:22:16         16                       +000000000 00:04:03.327 5%
ini_par                          ini_par                                                            dqzfbdzng452m 3014071762        594      63491 db file scattered re 2024/10/22 07:21:31  2024/10/22 07:23:29         11                     1 +000000000 00:01:58.141 3%
ini_par                          ini_par                                                            dqzfbdzng452m 3014071762        594      63491 ON CPU               2024/10/22 07:19:12  2024/10/22 07:21:17          9                     1 +000000000 00:02:05.162 3%
                                                                                                                           0                       control file sequent 2024/10/22 07:18:09  2024/10/22 07:23:18          5                       +000000000 00:05:08.399 2%
                                                                                                                           0                       ON CPU               2024/10/22 07:18:24  2024/10/22 07:23:21          5                       +000000000 00:04:56.382 2%
                                 oracle                                                                                    0          5      54451 log file parallel wr 2024/10/22 07:23:07  2024/10/22 07:23:50          3                       +000000000 00:00:43.050 1%

MODULE                           PROGRAM                                            CLIENT_ID       SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- -------------------------------------------------- --------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
ini_par                          ini_par                                                            dqzfbdzng452m 3014071762        594      63491 db file sequential r 2024/10/22 07:19:11  2024/10/22 07:31:39        617                     1 +000000000 00:12:27.984 82%
ini_par                          ini_par                                                            dqzfbdzng452m 3014071762        594      63491 db file scattered re 2024/10/22 07:21:31  2024/10/22 07:31:26        118                     1 +000000000 00:09:54.785 16%
ini_par                          ini_par                                                            dqzfbdzng452m                   594      63491 ON CPU               2024/10/22 07:19:12  2024/10/22 07:31:40         13                     1 +000000000 00:12:27.984 2%
ini_par                          ini_par                                                            dqzfbdzng452m 3014071762        594      63491 SQL*Net more data to 2024/10/22 07:25:13  2024/10/22 07:25:13          1                     1 +000000000 00:00:00.000 0%
                              

MODULE                           PROGRAM                                            CLIENT_ID       SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- -------------------------------------------------- --------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
ini_par                          ini_par                                                            dqzfbdzng452m 3014071762        594      63491                      2024/10/22 07:19:11  2024/10/22 07:31:39        748                     1 +000000000 00:12:27.984 100%
ini_par                          ini_par                                                                                   0        594      63491 ON CPU               2024/10/22 07:31:40  2024/10/22 07:31:40          1                       +000000000 00:00:00.000 0%                                
SQL_ID        SQL_PLAN_HASH_VALUE SQL_PLAN_LINE_ID SQL_PLAN_OPERATION             SQL_PLAN_OPTIONS                   ACTIVE
------------- ------------------- ---------------- ------------------------------ ------------------------------ ----------
dqzfbdzng452m          3014071762                  SELECT STATEMENT                                                      15
dqzfbdzng452m          3014071762                1 SORT                           ORDER BY                               14



INSTANCE_NUMBER SQL_ID            ELAPSED MAX_WAIT_ON     PC_OF  WAIT_TIME            GETS      READS       ROWS  ELAP/EXEC       GETS/EXEC READS/EXEC  ROWS/EXEC       EXEC PLAN_HASH_VALUE
--------------- ------------- ----------- --------------- ----- ---------- --------------- ---------- ---------- ---------- --------------- ---------- ---------- ---------- ---------------
              1 dqzfbdzng452m        3912 IO              98%   3928.88851         2017475     315813     129752     782.47          403495    63162.6    25950.4          5      3014071762
         

Plan hash value: 3014071762
---------------------------------------------------------------------------------------------------------------
| Id  | Operation          | Name     | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  |
---------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT   |          |      1 |        |  1207 (100)|  42380 |00:00:10.98 |   31683 |   1055 |
|   1 |  SORT ORDER BY     |          |      1 |   2119 |  1207   (1)|  42380 |00:00:10.98 |   31683 |   1055 |
|*  2 |   TABLE ACCESS FULL| T_PARAGR |      1 |   2119 |   913   (1)|  42380 |00:00:00.68 |    4158 |     72 |
---------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   2 - filter(TRIM("NOM") IS NOT NULL)



-- SNOWVAL

select count(*)
  from t_paragr
 where length(txt) > 4000;

  COUNT(*)
----------
      9994



-- SNOW

select count(*)
  from t_paragr
 where length(txt) > 4000;

  COUNT(*)
----------
       625

*/
/********************************OLD Metrics***************************************/

/********************************New SQL*******************************************/

SELECT TRIM(nom), 
       DBMS_LOB.SUBSTR(txt, :b0, 1) txt,
       bindata_type
  FROM t_paragr
 WHERE TRIM(nom) IS NOT NULL
 ORDER BY TRIM(nom), nuligne;
/********************************New SQL*******************************************/
/********************************New Metrics***************************************/
/*
Plan hash value: 3014071762
------------------------------------------------------------------------------------------------------
| Id  | Operation          | Name     | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers |
------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT   |          |      1 |        |  6738 (100)|  42380 |00:00:00.31 |   31683 |
|   1 |  SORT ORDER BY     |          |      1 |  42380 |  6738   (1)|  42380 |00:00:00.31 |   31683 |
|*  2 |   TABLE ACCESS FULL| T_PARAGR |      1 |  42380 |   913   (1)|  42380 |00:00:00.04 |    4158 |
------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   2 - filter(TRIM("NOM") IS NOT NULL)
*/
/********************************New Metrics***************************************/

/********************************Index statistics**********************************/

/********************************Other SQLs****************************************/          
/*

*/ 
/********************************Other SQLs****************************************/              
