/********************************************************************************
*********       E-mail subject: KBCCFDEV-5700
*********             Instance: NOTO
*********          Description: 
Problem:
Slow opening of screen e_aff_doscli1.

Analysis:
After we traced the screen opening on NOTO, from the TKPROF of the trace file we can see that for almost all of the time were
responsible SQL 6kv2d65wzph67. The problem in it was missing indexes on table G_PIECEDET on NOTO. I tried to create test index on NOTO,
but because table G_PIECEDET is too big there is no enough TEMP to create it. I tested the query on instances DEVI and DEVIVAL ( instance NOTO should be a copy of instance DEVI )
and on them this SQL uses index G_PIECEDET_REFP which and access table G_PIECEDET through REFPIECE and TYPE, so if this index is delivered to NOTO, it should solve the problem.

Suggestion:
Please deliver index G_PIECEDET_REFP and index G_PIECEDET_RDOS_TYPE_NB01 on table G_PIECEDET on instance NOTO and then return the task back to me to test is everything working as expected.

*********               SQL_ID: 6kv2d65wzph67
*********      Program/Package: e_aff_doscli1.
*********              Request: Adelina Gencheva 
*********               Author: Dimitar Dimitrov
********* Received e-mail date: 26/03/2024
*********      Resolution date: 26/03/2024
*********  Trace old file here: \\epox\specifs\performance\tmp\
*********  Trace new file here:
***********************************************************************************/

/********************************OLD SQL*******************************************/

VAR B1 VARCHAR2(32);
EXEC :B1 := '2208220005';

SELECT P.MT05, 
       P.MT08
  FROM G_PIECEDET P, 
       G_DOSSIER D
 WHERE D.REFDOSS = :B1
   AND P.REFPIECE = D.REFPIECE_DECOMPTE
   AND P.REFDOSS = D.REFDOSS
   AND P.TYPE = 'MEMO_DECOMPTE_STD';
/********************************OLD SQL*******************************************/
/********************************OLD Metrics***************************************/
/*
Plan hash value: 705044860
---------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                            | Name                 | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  |
---------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                     |                      |      1 |        |   150 (100)|      0 |00:00:00.01 |       0 |      0 |
|   1 |  NESTED LOOPS                        |                      |      1 |      1 |   150   (0)|      0 |00:00:00.01 |       0 |      0 |
|*  2 |   TABLE ACCESS BY INDEX ROWID        | G_DOSSIER            |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       5 |      0 |
|*  3 |    INDEX UNIQUE SCAN                 | DOS_REFDOSS          |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       2 |      0 |
|*  4 |   TABLE ACCESS BY INDEX ROWID BATCHED| G_PIECEDET           |      1 |      1 |   149   (0)|      0 |00:00:00.01 |       0 |      0 |
|*  5 |    INDEX RANGE SCAN                  | G_PIECEDET_TYPE_NB01 |      1 |    151K|     7   (0)|    287K|00:00:00.68 |    1205 |   1152 |
---------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   2 - filter("D"."REFPIECE_DECOMPTE" IS NOT NULL)
   3 - access("D"."REFDOSS"=:B1)
   4 - filter(("P"."REFDOSS"=:B1 AND "P"."REFPIECE"="D"."REFPIECE_DECOMPTE"))
   5 - access("P"."TYPE"='MEMO_DECOMPTE_STD')
*/
/********************************OLD Metrics***************************************/

/********************************New SQL*******************************************/

-- No changes in the SQL text.
/********************************New SQL*******************************************/
/********************************New Metrics***************************************/
/*
-- Execution plan from instance DEVIVAL, that I expect to be reached and on instance NOTO when the index is delivered

Plan hash value: 2653167096
-------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                            | Name            | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers |
-------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                     |                 |      1 |        |     2 (100)|      1 |00:00:00.01 |      11 |
|   1 |  NESTED LOOPS                        |                 |      1 |      1 |     2   (0)|      1 |00:00:00.01 |      11 |
|*  2 |   TABLE ACCESS BY INDEX ROWID        | G_DOSSIER       |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       5 |
|*  3 |    INDEX UNIQUE SCAN                 | DOS_REFDOSS     |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       2 |
|*  4 |   TABLE ACCESS BY INDEX ROWID BATCHED| G_PIECEDET      |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       6 |
|*  5 |    INDEX RANGE SCAN                  | G_PIECEDET_REFP |      1 |      4 |     1   (0)|      1 |00:00:00.01 |       5 |
-------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   2 - filter("D"."REFPIECE_DECOMPTE" IS NOT NULL)
   3 - access("D"."REFDOSS"=:B1)
   4 - filter("P"."REFDOSS"=:B1)
   5 - access("P"."REFPIECE"="D"."REFPIECE_DECOMPTE" AND "P"."TYPE"='MEMO_DECOMPTE_STD')   
*/
/********************************New Metrics***************************************/

/********************************Index statistics**********************************/

/********************************Other SQLs****************************************/          
/*

*/ 
/********************************Other SQLs****************************************/              
