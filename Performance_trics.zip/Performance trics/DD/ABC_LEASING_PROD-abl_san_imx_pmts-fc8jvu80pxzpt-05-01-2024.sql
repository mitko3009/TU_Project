/********************************************************************************
*********       E-mail subject: ABCLDEV-5215
*********             Instance: PROD
*********          Description: 
Problem:
Slow SQL from ABC LEASING PROD.

Analysis:
The problem is making a full scan of table G_PIECEDET because of missing index on column nb02.

Suggestion:
Please create index on column nb02 on table G_PIECEDET on ABC LEASING PROD.

*********               SQL_ID: fc8jvu80pxzpt
*********      Program/Package: 
*********              Request: Dimitare Ivanov
*********               Author: Dimitar Dimitrov
********* Received e-mail date: 04/01/2024
*********      Resolution date: 05/01/2024
*********  Trace old file here: \\epox\specifs\performance\tmp\
*********  Trace new file here:
***********************************************************************************/

/********************************OLD SQL*******************************************/
select decode(ca.type_config_item,
              'BP',
              decode(p.typbien,
                     'V',
                     P.VH_MARQUE,
                     'M',
                     P.EQP_BRAND,
                     'E',
                     (select it.brand
                        from g_bien_it it
                       where refpatrimoine = p.refpatrimoine)),
              (select valeur_trad
                 from v_tdomaine
                where abrev = ca.type_cat_item
                  and type = decode(ca.type_config_item,
                                    'FR',
                                    'FIN_TYPE_FRAIS',
                                    'AC',
                                    'TYPE_ACCESSOIRE',
                                    'EQ',
                                    'TYPE_EQUIPEMENT',
                                    'OE',
                                    'TYPE_EQUIPEMENT')
                  and langue = :egaclangue))
  from t_config_asset ca, g_patrimoine p, g_piecedet d
 where p.refpatrimoine = ca.refpatrimoine
   and d.nb02 = ca.imx_un_id
   and ca.imx_un_id = :refind;
/********************************OLD SQL*******************************************/
/********************************OLD Metrics***************************************/
/*
PLAN HASH VALUE  : 1902369340
--------------------------------------------------------------------------------------------------------
| Id  | Operation                               | Name              | Rows  | Bytes | Cost  | Time     |
--------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                        |                   |       |       |   112K|          |
|   1 |  TABLE ACCESS BY INDEX ROWID BATCHED    | G_BIEN_IT         |     1 |    19 |     1 | 00:00:01 |
|*  2 |   INDEX RANGE SCAN                      | IX_G_BIEN_IT_REFP |     1 |       |     1 | 00:00:01 |
|   3 |   VIEW                                  | V_TDOMAINE        |    20 | 10320 |    20 | 00:00:01 |
|   4 |    UNION-ALL                            |                   |       |       |       |          |
|*  5 |     FILTER                              |                   |       |       |       |          |
|   6 |      TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE         |     1 |    25 |     1 | 00:00:01 |
|*  7 |       INDEX RANGE SCAN                  | DOM_TYPABREV      |     1 |       |     1 | 00:00:01 |
|*  8 |     FILTER                              |                   |       |       |       |          |
|   9 |      TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE         |     1 |    38 |     1 | 00:00:01 |
|* 10 |       INDEX RANGE SCAN                  | DOM_TYPABREV      |     1 |       |     1 | 00:00:01 |
|* 11 |     FILTER                              |                   |       |       |       |          |
|  12 |      TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE         |     1 |    21 |     1 | 00:00:01 |
|* 13 |       INDEX RANGE SCAN                  | DOM_TYPABREV      |     1 |       |     1 | 00:00:01 |
|* 14 |     FILTER                              |                   |       |       |       |          |
|  15 |      TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE         |     1 |    21 |     1 | 00:00:01 |
|* 16 |       INDEX RANGE SCAN                  | DOM_TYPABREV      |     1 |       |     1 | 00:00:01 |
|* 17 |     FILTER                              |                   |       |       |       |          |
|  18 |      TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE         |     1 |    21 |     1 | 00:00:01 |
|* 19 |       INDEX RANGE SCAN                  | DOM_TYPABREV      |     1 |       |     1 | 00:00:01 |
|* 20 |     FILTER                              |                   |       |       |       |          |
|  21 |      TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE         |     1 |    21 |     1 | 00:00:01 |
|* 22 |       INDEX RANGE SCAN                  | DOM_TYPABREV      |     1 |       |     1 | 00:00:01 |
|* 23 |     FILTER                              |                   |       |       |       |          |
|  24 |      TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE         |     1 |    41 |     1 | 00:00:01 |
|* 25 |       INDEX RANGE SCAN                  | DOM_TYPABREV      |     1 |       |     1 | 00:00:01 |
|* 26 |     FILTER                              |                   |       |       |       |          |
|  27 |      TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE         |     1 |    21 |     1 | 00:00:01 |
|* 28 |       INDEX RANGE SCAN                  | DOM_TYPABREV      |     1 |       |     1 | 00:00:01 |
|* 29 |     FILTER                              |                   |       |       |       |          |
|  30 |      TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE         |     1 |    21 |     1 | 00:00:01 |
|* 31 |       INDEX RANGE SCAN                  | DOM_TYPABREV      |     1 |       |     1 | 00:00:01 |
|* 32 |     FILTER                              |                   |       |       |       |          |
|  33 |      TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE         |     1 |    49 |     1 | 00:00:01 |
|* 34 |       INDEX RANGE SCAN                  | DOM_TYPABREV      |     1 |       |     1 | 00:00:01 |
|* 35 |     FILTER                              |                   |       |       |       |          |
|  36 |      TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE         |     1 |    21 |     1 | 00:00:01 |
|* 37 |       INDEX RANGE SCAN                  | DOM_TYPABREV      |     1 |       |     1 | 00:00:01 |
|* 38 |     FILTER                              |                   |       |       |       |          |
|  39 |      TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE         |     1 |    21 |     1 | 00:00:01 |
|* 40 |       INDEX RANGE SCAN                  | DOM_TYPABREV      |     1 |       |     1 | 00:00:01 |
|* 41 |     FILTER                              |                   |       |       |       |          |
|  42 |      TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE         |     1 |    22 |     1 | 00:00:01 |
|* 43 |       INDEX RANGE SCAN                  | DOM_TYPABREV      |     1 |       |     1 | 00:00:01 |
|* 44 |     FILTER                              |                   |       |       |       |          |
|  45 |      TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE         |     1 |    21 |     1 | 00:00:01 |
|* 46 |       INDEX RANGE SCAN                  | DOM_TYPABREV      |     1 |       |     1 | 00:00:01 |
|* 47 |     FILTER                              |                   |       |       |       |          |
|  48 |      TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE         |     1 |    21 |     1 | 00:00:01 |
|* 49 |       INDEX RANGE SCAN                  | DOM_TYPABREV      |     1 |       |     1 | 00:00:01 |
|* 50 |     FILTER                              |                   |       |       |       |          |
|  51 |      TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE         |     1 |    21 |     1 | 00:00:01 |
|* 52 |       INDEX RANGE SCAN                  | DOM_TYPABREV      |     1 |       |     1 | 00:00:01 |
|* 53 |     FILTER                              |                   |       |       |       |          |
|  54 |      TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE         |     1 |    21 |     1 | 00:00:01 |
|* 55 |       INDEX RANGE SCAN                  | DOM_TYPABREV      |     1 |       |     1 | 00:00:01 |
|* 56 |     FILTER                              |                   |       |       |       |          |
|  57 |      TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE         |     1 |    21 |     1 | 00:00:01 |
|* 58 |       INDEX RANGE SCAN                  | DOM_TYPABREV      |     1 |       |     1 | 00:00:01 |
|* 59 |     FILTER                              |                   |       |       |       |          |
|  60 |      TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE         |     1 |    21 |     1 | 00:00:01 |
|* 61 |       INDEX RANGE SCAN                  | DOM_TYPABREV      |     1 |       |     1 | 00:00:01 |
|* 62 |     FILTER                              |                   |       |       |       |          |
|  63 |      TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE         |     1 |    21 |     1 | 00:00:01 |
|* 64 |       INDEX RANGE SCAN                  | DOM_TYPABREV      |     1 |       |     1 | 00:00:01 |
|  65 |  MERGE JOIN CARTESIAN                   |                   |     1 |    39 |   112K| 00:00:05 |
|  66 |   NESTED LOOPS                          |                   |     1 |    37 |     2 | 00:00:01 |
|  67 |    TABLE ACCESS BY INDEX ROWID          | T_CONFIG_ASSET    |     1 |    19 |     1 | 00:00:01 |
|* 68 |     INDEX UNIQUE SCAN                   | PK_T_CONFIG_ASSET |     1 |       |     1 | 00:00:01 |
|  69 |    TABLE ACCESS BY INDEX ROWID BATCHED  | G_PATRIMOINE      |     1 |    18 |     1 | 00:00:01 |
|* 70 |     INDEX RANGE SCAN                    | PATREFPATRIMOINE  |     1 |       |     1 | 00:00:01 |
|  71 |   BUFFER SORT                           |                   |     1 |     2 |   112K| 00:00:05 |
|* 72 |    TABLE ACCESS FULL                    | G_PIECEDET        |     1 |     2 |   112K| 00:00:05 |
--------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   2 - access("REFPATRIMOINE"=:B1)
   5 - filter('AL'=:EGACLANGUE)
   7 - access("TYPE"=DECODE(:B1,'FR','FIN_TYPE_FRAIS','AC','TYPE_ACCESSOIRE','EQ','TYPE_EQUIPEME
              NT','OE','TYPE_EQUIPEMENT') AND "ABREV"=:B2)
   8 - filter('AN'=:EGACLANGUE)
  10 - access("TYPE"=DECODE(:B1,'FR','FIN_TYPE_FRAIS','AC','TYPE_ACCESSOIRE','EQ','TYPE_EQUIPEME
              NT','OE','TYPE_EQUIPEMENT') AND "ABREV"=:B2)
  11 - filter('CE'=:EGACLANGUE)
  13 - access("TYPE"=DECODE(:B1,'FR','FIN_TYPE_FRAIS','AC','TYPE_ACCESSOIRE','EQ','TYPE_EQUIPEME
              NT','OE','TYPE_EQUIPEMENT') AND "ABREV"=:B2)
  14 - filter('CH'=:EGACLANGUE)
  16 - access("TYPE"=DECODE(:B1,'FR','FIN_TYPE_FRAIS','AC','TYPE_ACCESSOIRE','EQ','TYPE_EQUIPEME
              NT','OE','TYPE_EQUIPEMENT') AND "ABREV"=:B2)
  17 - filter('DA'=:EGACLANGUE)
  19 - access("TYPE"=DECODE(:B1,'FR','FIN_TYPE_FRAIS','AC','TYPE_ACCESSOIRE','EQ','TYPE_EQUIPEME
              NT','OE','TYPE_EQUIPEMENT') AND "ABREV"=:B2)
  20 - filter('EL'=:EGACLANGUE)
  22 - access("TYPE"=DECODE(:B1,'FR','FIN_TYPE_FRAIS','AC','TYPE_ACCESSOIRE','EQ','TYPE_EQUIPEME
              NT','OE','TYPE_EQUIPEMENT') AND "ABREV"=:B2)
  23 - filter('ES'=:EGACLANGUE)
  25 - access("TYPE"=DECODE(:B1,'FR','FIN_TYPE_FRAIS','AC','TYPE_ACCESSOIRE','EQ','TYPE_EQUIPEME
              NT','OE','TYPE_EQUIPEMENT') AND "ABREV"=:B2)
  26 - filter('FI'=:EGACLANGUE)
  28 - access("TYPE"=DECODE(:B1,'FR','FIN_TYPE_FRAIS','AC','TYPE_ACCESSOIRE','EQ','TYPE_EQUIPEME
              NT','OE','TYPE_EQUIPEMENT') AND "ABREV"=:B2)
  29 - filter('FL'=:EGACLANGUE)
  31 - access("TYPE"=DECODE(:B1,'FR','FIN_TYPE_FRAIS','AC','TYPE_ACCESSOIRE','EQ','TYPE_EQUIPEME
              NT','OE','TYPE_EQUIPEMENT') AND "ABREV"=:B2)
  32 - filter('FR'=:EGACLANGUE)
  34 - access("TYPE"=DECODE(:B1,'FR','FIN_TYPE_FRAIS','AC','TYPE_ACCESSOIRE','EQ','TYPE_EQUIPEME
              NT','OE','TYPE_EQUIPEMENT') AND "ABREV"=:B2)
  35 - filter('HU'=:EGACLANGUE)
  37 - access("TYPE"=DECODE(:B1,'FR','FIN_TYPE_FRAIS','AC','TYPE_ACCESSOIRE','EQ','TYPE_EQUIPEME
              NT','OE','TYPE_EQUIPEMENT') AND "ABREV"=:B2)
  38 - filter('IT'=:EGACLANGUE)
  40 - access("TYPE"=DECODE(:B1,'FR','FIN_TYPE_FRAIS','AC','TYPE_ACCESSOIRE','EQ','TYPE_EQUIPEME
              NT','OE','TYPE_EQUIPEMENT') AND "ABREV"=:B2)
  41 - filter('NL'=:EGACLANGUE)
  43 - access("TYPE"=DECODE(:B1,'FR','FIN_TYPE_FRAIS','AC','TYPE_ACCESSOIRE','EQ','TYPE_EQUIPEME
              NT','OE','TYPE_EQUIPEMENT') AND "ABREV"=:B2)
  44 - filter('NO'=:EGACLANGUE)
  46 - access("TYPE"=DECODE(:B1,'FR','FIN_TYPE_FRAIS','AC','TYPE_ACCESSOIRE','EQ','TYPE_EQUIPEME
              NT','OE','TYPE_EQUIPEMENT') AND "ABREV"=:B2)
  47 - filter('PL'=:EGACLANGUE)
  49 - access("TYPE"=DECODE(:B1,'FR','FIN_TYPE_FRAIS','AC','TYPE_ACCESSOIRE','EQ','TYPE_EQUIPEME
              NT','OE','TYPE_EQUIPEMENT') AND "ABREV"=:B2)
  50 - filter('PT'=:EGACLANGUE)
  52 - access("TYPE"=DECODE(:B1,'FR','FIN_TYPE_FRAIS','AC','TYPE_ACCESSOIRE','EQ','TYPE_EQUIPEME
              NT','OE','TYPE_EQUIPEMENT') AND "ABREV"=:B2)
  53 - filter('RO'=:EGACLANGUE)
  55 - access("TYPE"=DECODE(:B1,'FR','FIN_TYPE_FRAIS','AC','TYPE_ACCESSOIRE','EQ','TYPE_EQUIPEME
              NT','OE','TYPE_EQUIPEMENT') AND "ABREV"=:B2)
  56 - filter('SK'=:EGACLANGUE)
  58 - access("TYPE"=DECODE(:B1,'FR','FIN_TYPE_FRAIS','AC','TYPE_ACCESSOIRE','EQ','TYPE_EQUIPEME
              NT','OE','TYPE_EQUIPEMENT') AND "ABREV"=:B2)
  59 - filter('SV'=:EGACLANGUE)
  61 - access("TYPE"=DECODE(:B1,'FR','FIN_TYPE_FRAIS','AC','TYPE_ACCESSOIRE','EQ','TYPE_EQUIPEME
              NT','OE','TYPE_EQUIPEMENT') AND "ABREV"=:B2)
  62 - filter('US'=:EGACLANGUE)
  64 - access("TYPE"=DECODE(:B1,'FR','FIN_TYPE_FRAIS','AC','TYPE_ACCESSOIRE','EQ','TYPE_EQUIPEME
              NT','OE','TYPE_EQUIPEMENT') AND "ABREV"=:B2)
  68 - access("CA"."IMX_UN_ID"=TO_NUMBER(:REFIND))
  70 - access("P"."REFPATRIMOINE"="CA"."REFPATRIMOINE")
  72 - filter("D"."NB02"=TO_NUMBER(:REFIND))   
*/
/********************************OLD Metrics***************************************/

/********************************New SQL*******************************************/
-- No change in the SQL text, only create the index.
/********************************New SQL*******************************************/
/********************************New Metrics***************************************/
/*

*/
/********************************New Metrics***************************************/

/********************************Index statistics**********************************/

/********************************Other SQLs****************************************/          
/*

*/ 
/********************************Other SQLs****************************************/              
