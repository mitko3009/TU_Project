/********************************************************************************
*********       E-mail subject: LOCAMDEV-27558
*********             Instance: REFRCT1
*********          Description: 
Problem:
SQL 6k2mg6x02nsa7 was the TOP SQL in the msgq_pilote.

Analysis:
As you can see below, SQL 6k2mg6x02nsa7 ( from SE Variable ds_all_DF_are_active ) was executed ~550 times and was responsible for 17% of the time.
As it can be seen in its execution plan below, it makes FULL SCANs on table G_PIECE on every execution, because there is no appropriate index on column ST21 on table G_PIECE, which to be used.
After discussion with C&D, it was created functional index on ST21 || '' on table G_PIECE. We added || '' to the columns in the query to be able to use the index.

Suggestion:
Please add || '' as it is shown in the New SQL section below.

*********               SQL_ID: 6k2mg6x02nsa7
*********      Program/Package: SE VARIABLE ds_all_DF_are_active
*********              Request: Dimitare Ivanov
*********               Author: Dimitar Dimitrov
********* Received e-mail date: 19/03/2025
*********      Resolution date: 28/03/2025
*********  Trace old file here: \\epox\specifs\performance\tmp\
*********  Trace new file here:
***********************************************************************************/

/********************************OLD SQL*******************************************/

var refdos varchar2(32);
exec :refdos := '2012110094';

select count(*)
  from ( select count(*) allFRactstat
           from g_piece FR1, 
                g_piece FC
          where FC.refdoss = :refdos
            and FC.typpiece = 'FINANCING CONTRACT'
            and FR1.typpiece = 'FINANCING REQUEST'
            and FR1.st21 = FC.Refpiece
            and nvl( FR1.str_20_1, 'XXX' ) = 'ACT') ,
       ( select count(*) allFRstat
           from g_piece FR2, 
                g_piece FC
          where FC.refdoss = :refdos
            and FC.typpiece = 'FINANCING CONTRACT'
            and FR2.typpiece = 'FINANCING REQUEST'
            and FR2.st21 = FC.Refpiece
            and FR2.str_20_1 is not null )
 where allFRactstat = allFRstat
   and exists ( select 1
                  from g_piece FR1, 
                       g_piece FC
                 where FC.refdoss = :refdos
                   and FC.typpiece = 'FINANCING CONTRACT'
                   and FR1.typpiece = 'FINANCING REQUEST'
                   and FR1.st21 = FC.Refpiece
                   and nvl( FR1.str_20_1, 'XXX' ) = 'ACT' );

/********************************OLD SQL*******************************************/
/********************************OLD Metrics***************************************/
/*
MODULE       PROGRAM    SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE INTERVAL                PERC
------------ ---------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- ----------------------- ------
msgq_pilote  msg_q09                                                                        2025/03/17 04:39:39  2025/03/18 01:13:46        1367 +000000000 20:34:06.336 4%
msgq_pilote  msg_q12                                                                        2025/03/17 04:38:38  2025/03/18 01:13:35        1356 +000000000 20:34:57.536 4%
msgq_pilote  msg_q02                                                                        2025/03/17 04:37:57  2025/03/18 01:13:35        1345 +000000000 20:35:38.495 4%
msgq_pilote  msg_q05                                                                        2025/03/17 04:38:38  2025/03/18 01:13:46        1336 +000000000 20:35:07.776 4%
msgq_pilote  msg_q18                                                                        2025/03/17 04:38:07  2025/03/18 01:13:56        1334 +000000000 20:35:48.736 4%
msgq_pilote  msg_q08                                                                        2025/03/17 04:41:22  2025/03/18 01:12:24        1327 +000000000 20:31:01.824 4%
msgq_pilote  msg_q17                                                                        2025/03/17 04:40:20  2025/03/18 01:13:35        1323 +000000000 20:33:15.136 4%
msgq_pilote  msg_q07                                                                        2025/03/17 04:37:57  2025/03/18 01:10:31        1322 +000000000 20:32:33.733 4%
msgq_pilote  msg_q13                                                                        2025/03/17 04:39:19  2025/03/18 01:13:46        1321 +000000000 20:34:26.816 4%
msgq_pilote  msg_q21                                                                        2025/03/17 04:38:38  2025/03/18 01:13:25        1321 +000000000 20:34:47.297 4%
msgq_pilote  msg_q10                                                                        2025/03/17 04:38:38  2025/03/18 01:12:44        1320 +000000000 20:34:06.272 4%
msgq_pilote  msg_q23                                                                        2025/03/17 04:38:38  2025/03/18 01:13:46        1317 +000000000 20:35:07.776 4%
msgq_pilote  msg_queue                                                                      2025/03/17 04:39:29  2025/03/18 01:12:34        1316 +000000000 20:33:04.705 4%
msgq_pilote  msg_q22                                                                        2025/03/17 04:40:10  2025/03/18 01:13:25        1314 +000000000 20:33:15.136 4%
msgq_pilote  msg_q24                                                                        2025/03/17 04:40:00  2025/03/18 01:11:43        1313 +000000000 20:31:42.785 4%
msgq_pilote  msg_q19                                                                        2025/03/17 04:38:28  2025/03/18 01:13:56        1305 +000000000 20:35:28.256 4%
msgq_pilote  msg_q16                                                                        2025/03/17 04:38:48  2025/03/18 01:13:35        1304 +000000000 20:34:47.296 4%
msgq_pilote  msg_q14                                                                        2025/03/17 04:38:07  2025/03/18 01:13:35        1302 +000000000 20:35:28.256 4%
msgq_pilote  msg_q20                                                                        2025/03/17 04:38:28  2025/03/18 01:13:25        1301 +000000000 20:34:57.537 4%
msgq_pilote  msg_q04                                                                        2025/03/17 04:37:57  2025/03/18 01:12:34        1300 +000000000 20:34:36.864 4%
msgq_pilote  msg_q15                                                                        2025/03/17 04:40:51  2025/03/18 01:13:35        1297 +000000000 20:32:44.415 4%
msgq_pilote  msg_q03                                                                        2025/03/17 04:37:57  2025/03/18 01:11:32        1288 +000000000 20:33:35.423 4%
msgq_pilote  msg_q06                                                                        2025/03/17 04:37:57  2025/03/18 01:13:46        1268 +000000000 20:35:48.735 4%
msgq_pilote  msg_q11                                                                        2025/03/17 04:41:22  2025/03/18 01:13:25        1264 +000000000 20:32:03.457 4%

MODULE                           SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
msgq_pilote                                                                     ON CPU               2025/03/17 04:37:57  2025/03/18 01:13:56       20366             16760671 +000000000 20:35:58.975 65%
msgq_pilote                                                                     resmgr:cpu quantum   2025/03/17 04:48:01  2025/03/18 01:10:41        9278             16708172 +000000000 20:22:39.936 29%

-------------------------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
msgq_pilote                                             0                                            2025/03/17 04:39:19  2025/03/18 01:12:44        7158                    1 +000000000 20:33:25.312 23%
msgq_pilote                      6k2mg6x02nsa7 1647140769                                            2025/03/17 10:23:20  2025/03/17 11:03:37        5262                  548 +000000000 00:40:17.024 17%
msgq_pilote                      cgufjhvr9ybun                                                       2025/03/17 04:38:48  2025/03/18 01:13:35        1888             16731840 +000000000 20:34:47.296 6%
msgq_pilote                      4b68k5u2axt6a                                                       2025/03/17 05:24:13  2025/03/18 01:11:53        1651             12262690 +000000000 19:47:39.455 5%
msgq_pilote                      3z3xsjthu53f5                                                       2025/03/17 04:38:38  2025/03/18 01:11:32         992             16660589 +000000000 20:32:54.464 3%
msgq_pilote                      fajha0dg4qhmb 2289479253                                            2025/03/17 04:38:17  2025/03/17 10:22:39         896                 7765 +000000000 05:44:21.697 3%
msgq_pilote                      axyu9mury91rr                                                       2025/03/17 06:09:38  2025/03/18 01:13:46         640              4439183 +000000000 19:04:07.295 2%
msgq_pilote                      0y5acg49sv441                                                       2025/03/17 04:38:48  2025/03/18 01:13:25         605             16091919 +000000000 20:34:37.057 2%
msgq_pilote                      8mk0mhw4mwdw5 3329449978                                            2025/03/17 04:38:58  2025/03/17 11:02:16         364                20457 +000000000 06:23:17.120 1%
msgq_pilote                      75r7d07qf0xdt                                                       2025/03/17 04:40:31  2025/03/18 01:10:31         185             16320052 +000000000 20:30:00.134 1%
msgq_pilote                      cbfwz2kzjtq9w                                  ON CPU               2025/03/17 06:28:45  2025/03/18 01:13:46         168              1033315 +000000000 18:45:00.286 1%

STAT_NAME                                                                           VALUE  OSSTAT_ID COMMENTS                                                         CUMULATIVE       CON_ID
---------------------------------------------------------------- ------------------------ ---------- ---------------------------------------------------------------- ------------ ----------
NUM_CPUS                                                                               48          0 Number of active CPUs                                            NO                    0

NAME                                 TYPE                                         VALUE
------------------------------------ -------------------------------------------- ------------------------------
cpu_count                            integer                                      8


Plan hash value: 1647140769
---------------------------------------------------------------------------------------------------------
| Id  | Operation                                 | Name        | Rows  | Bytes | Cost (%CPU)| Time     |
---------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                          |             |       |       |   577K(100)|          |
|   1 |  SORT AGGREGATE                           |             |     1 |    26 |            |          |
|   2 |   FILTER                                  |             |       |       |            |          |
|   3 |    NESTED LOOPS                           |             |     1 |    26 |   385K  (1)| 00:00:16 |
|   4 |     VIEW                                  |             |     1 |    13 |   192K  (1)| 00:00:08 |
|   5 |      SORT AGGREGATE                       |             |     1 |    55 |            |          |
|   6 |       HASH JOIN                           |             |     1 |    55 |   192K  (1)| 00:00:08 |
|   7 |        TABLE ACCESS BY INDEX ROWID BATCHED| G_PIECE     |     1 |    35 |     4   (0)| 00:00:01 |
|   8 |         INDEX RANGE SCAN                  | PIE_REFDOSS |     1 |       |     3   (0)| 00:00:01 |
|   9 |        TABLE ACCESS FULL                  | G_PIECE     |   347K|  6780K|   192K  (1)| 00:00:08 |
|  10 |     VIEW                                  |             |     1 |    13 |   192K  (1)| 00:00:08 |
|  11 |      SORT AGGREGATE                       |             |     1 |    55 |            |          |
|  12 |       HASH JOIN                           |             |     1 |    55 |   192K  (1)| 00:00:08 |
|  13 |        TABLE ACCESS BY INDEX ROWID BATCHED| G_PIECE     |     1 |    35 |     4   (0)| 00:00:01 |
|  14 |         INDEX RANGE SCAN                  | PIE_REFDOSS |     1 |       |     3   (0)| 00:00:01 |
|  15 |        TABLE ACCESS FULL                  | G_PIECE     |   904K|    17M|   192K  (1)| 00:00:08 |
|  16 |    HASH JOIN SEMI                         |             |     1 |    55 |   192K  (1)| 00:00:08 |
|  17 |     TABLE ACCESS BY INDEX ROWID BATCHED   | G_PIECE     |     1 |    35 |     4   (0)| 00:00:01 |
|  18 |      INDEX RANGE SCAN                     | PIE_REFDOSS |     1 |       |     3   (0)| 00:00:01 |
|  19 |     TABLE ACCESS FULL                     | G_PIECE     |  1533 | 30660 |   192K  (1)| 00:00:08 |
---------------------------------------------------------------------------------------------------------
*/
/********************************OLD Metrics***************************************/

/********************************New SQL*******************************************/

select count(*)
  from ( select count(*) allFRactstat
           from g_piece FR1,
                g_piece FC
          where FC.refdoss = :refdos
            and FC.typpiece = 'FINANCING CONTRACT'
            and FR1.typpiece = 'FINANCING REQUEST'
            and FR1.st21 || '' = FC.Refpiece
            and nvl(FR1.str_20_1, 'XXX') = 'ACT' ),
       ( select count(*) allFRstat
           from g_piece FR2,
                g_piece FC
          where FC.refdoss = :refdos
            and FC.typpiece = 'FINANCING CONTRACT'
            and FR2.typpiece = 'FINANCING REQUEST'
            and FR2.st21 || '' = FC.Refpiece
            and FR2.str_20_1 is not null )
 where allFRactstat = allFRstat
   and exists ( select 1
                  from g_piece FR1,
                       g_piece FC
                 where FC.refdoss = :refdos
                   and FC.typpiece = 'FINANCING CONTRACT'
                   and FR1.typpiece = 'FINANCING REQUEST'
                   and FR1.st21 || '' = FC.Refpiece
                   and nvl(FR1.str_20_1, 'XXX') = 'ACT' );
/********************************New SQL*******************************************/
/********************************New Metrics***************************************/
/*
Plan hash value: 12287565
----------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                 | Name             | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  |
----------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                          |                  |      1 |        |     6 (100)|      1 |00:00:00.07 |       3 |      1 |
|   1 |  SORT AGGREGATE                           |                  |      1 |      1 |            |      1 |00:00:00.07 |       3 |      1 |
|*  2 |   FILTER                                  |                  |      1 |        |            |      0 |00:00:00.07 |       3 |      1 |
|   3 |    NESTED LOOPS                           |                  |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|   4 |     VIEW                                  |                  |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|   5 |      SORT AGGREGATE                       |                  |      0 |      1 |            |      0 |00:00:00.01 |       0 |      0 |
|   6 |       NESTED LOOPS                        |                  |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|   7 |        TABLE ACCESS BY INDEX ROWID BATCHED| G_PIECE          |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*  8 |         INDEX RANGE SCAN                  | PIE_REFDOSS      |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*  9 |        TABLE ACCESS BY INDEX ROWID BATCHED| G_PIECE          |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 10 |         INDEX RANGE SCAN                  | GP_ST21_FUNC_IDX |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 11 |     VIEW                                  |                  |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|  12 |      SORT AGGREGATE                       |                  |      0 |      1 |            |      0 |00:00:00.01 |       0 |      0 |
|  13 |       NESTED LOOPS                        |                  |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|  14 |        TABLE ACCESS BY INDEX ROWID BATCHED| G_PIECE          |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 15 |         INDEX RANGE SCAN                  | PIE_REFDOSS      |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 16 |        TABLE ACCESS BY INDEX ROWID BATCHED| G_PIECE          |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 17 |         INDEX RANGE SCAN                  | GP_ST21_FUNC_IDX |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|  18 |    NESTED LOOPS                           |                  |      1 |      1 |     2   (0)|      0 |00:00:00.07 |       3 |      1 |
|  19 |     TABLE ACCESS BY INDEX ROWID BATCHED   | G_PIECE          |      1 |      1 |     1   (0)|      0 |00:00:00.07 |       3 |      1 |
|* 20 |      INDEX RANGE SCAN                     | PIE_REFDOSS      |      1 |      1 |     1   (0)|      0 |00:00:00.07 |       3 |      1 |
|* 21 |     TABLE ACCESS BY INDEX ROWID BATCHED   | G_PIECE          |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 22 |      INDEX RANGE SCAN                     | GP_ST21_FUNC_IDX |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
----------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   2 - filter( IS NOT NULL)
   8 - access("FC"."REFDOSS"=:REFDOS AND "FC"."TYPPIECE"='FINANCING CONTRACT')
   9 - filter(("FR1"."TYPPIECE"='FINANCING REQUEST' AND NVL("FR1"."STR_20_1",'XXX')='ACT'))
  10 - access("FC"."REFPIECE"="FR1"."SYS_NC00799$")
  11 - filter("ALLFRACTSTAT"="ALLFRSTAT")
  15 - access("FC"."REFDOSS"=:REFDOS AND "FC"."TYPPIECE"='FINANCING CONTRACT')
  16 - filter(("FR2"."STR_20_1" IS NOT NULL AND "FR2"."TYPPIECE"='FINANCING REQUEST'))
  17 - access("FC"."REFPIECE"="FR2"."SYS_NC00799$")
  20 - access("FC"."REFDOSS"=:REFDOS AND "FC"."TYPPIECE"='FINANCING CONTRACT')
  21 - filter(("FR1"."TYPPIECE"='FINANCING REQUEST' AND NVL("FR1"."STR_20_1",'XXX')='ACT'))
  22 - access("FC"."REFPIECE"="FR1"."SYS_NC00799$")
*/
/********************************New Metrics***************************************/

/********************************Index statistics**********************************/

/********************************Other SQLs****************************************/          
/*

*/ 
/********************************Other SQLs****************************************/              
