/********************************************************************************
*********       E-mail subject: RBRODEV-4409
*********             Instance: JUJUVAL
*********          Description: 
Problem:
We noticed that SQL 7r5jqc68xyg9q from EXPORT_RISK_EXPOSURE can be improved.

Analysis:
We executed manually the query on JUJUVAL and noticed that is uses bad execution plan, starting from table DWH_RISK_EXPOSURE and making MERGE JOIN CARTESIANs with the other tables, which leads to selecting 
a lot of rows unnecessary and it is not selective. The most selective path here looks to start from table G_DOSSIER DECOMPTE from the REFLOT and then join the other tables. For this purpose, we rewrote the OR on G_DOSSIER DECOMPTE 
to UNION and added hints to force Oracle to start the execution from it. Also, table DWH_RISK_EXPOSURE is not directly joined to the other tables ( is it only joined by the bind :B1 ) and because 
there is no index on column CONTRACT_ID, it makes INDEX SKIP SCAN, which is not OK. To avoid this, we need from index on columns CONTRACT_ID and DATE_FROM on table RBR_DWH_RISK_EXPOSURE, which 
will allow to do INDEX RANGE SCAN instead of the INDEX SKIP SCAN.

Suggestion:
1. Please create index on (CONTRACT_ID, DATE_FROM) on table DWH_RISK_EXPOSURE.
2. Please change the query as it is shown in the New SQL section below.

*********               SQL_ID: 7r5jqc68xyg9q
*********      Program/Package: 
*********              Request: Dimitare Ivanov
*********               Author: Dimitar Dimitrov
********* Received e-mail date: 09/01/2025
*********      Resolution date: 09/01/2025
*********  Trace old file here: \\epox\specifs\performance\tmp\
*********  Trace new file here:
***********************************************************************************/

/********************************OLD SQL*******************************************/

-- 7r5jqc68xyg9q

VAR B1 VARCHAR2(32);
EXEC :B1 := '1903190061';
VAR B2 VARCHAR2(32);
EXEC :B2 := '01/08/2025';

SELECT 1 
  FROM DUAL 
 WHERE EXISTS ( SELECT 1 
                  FROM G_PIECE LIM_REQ , 
                       G_PIECE LIM_PAR , 
                       G_DOSSIER DECOMPTE , 
                       M_STATEMENT_LIMIT_FI_CONS MST , 
                       RBR_DWH_RISK_EXPOSURE RBR 
                 WHERE RBR.CONTRACT_ID = :B1 
                   AND RBR.DATE_FROM = TO_DATE(:B2, 'MM/DD/YYYY')
                   AND LIM_REQ.TYPPIECE = 'REQUEST_LIMITE' 
                   AND LIM_REQ.FG05 = 'O' 
                   AND LIM_REQ.TYPEDOC = 'C' 
                   AND LIM_PAR.TYPPIECE = 'PARAM_LIMITE' 
                   AND LIM_PAR.LIBELLE_20_1 = LIM_REQ.REFPIECE 
                   AND LIM_PAR.REFPIECE = MST.LIMIT_ID 
                   AND DECOMPTE.REFDOSS = MST.DECOMPTE_ID 
                   AND (    DECOMPTE.REFLOT = :B1 
                         OR DECOMPTE.REFLOT IN ( SELECT REFDOSS 
                                                   FROM G_DOSSIER 
                                                  WHERE REFHIERARCHIE = :B1 ) ) );
/********************************OLD SQL*******************************************/
/********************************OLD Metrics***************************************/
/*

MODULE                           PROGRAM                                            CLIENT_ID       SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- -------------------------------------------------- --------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
EXPORT_RISK_EXPOSURE             sqlplus                                            unknown                                        1928      52762                      2025/01/08 22:23:08  2025/01/08 23:20:08        335                 47999 +000000000 00:57:00.158 47%
EXPORT_LIMITS                    sqlplus                                            unknown                                        1928      52762                      2025/01/08 21:19:08  2025/01/08 21:35:41         98                 88532 +000000000 00:16:33.280 14%
EXPORT_INVOICES                  sqlplus                                            unknown                                        1928      52762                      2025/01/08 21:45:46  2025/01/08 21:59:14         80                242777 +000000000 00:13:28.961 11%
EXPORT_INSURANCE_POLICIES        sqlplus                                            unknown                                        1928      52762 db file sequential r 2025/01/08 22:07:16  2025/01/08 22:17:40         62                    12 +000000000 00:10:24.639 9%
EXPORT_CONTRACTS                 sqlplus                                            unknown                                        1928      52762                      2025/01/08 21:35:52  2025/01/08 21:42:41         41                233961 +000000000 00:06:49.599 6%
EXPORT_CL_DB_ACCOUNTS            sqlplus                                            unknown                                        1928      52762                      2025/01/08 22:17:51  2025/01/08 22:22:58         31                240103 +000000000 00:05:07.201 4%
EXPORT_EVENTS                    sqlplus                                            unknown                                        1928      52762                      2025/01/08 22:02:39  2025/01/08 22:07:06         27                 82334 +000000000 00:04:26.240 4%


MODULE                           PROGRAM                                            CLIENT_ID       SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- -------------------------------------------------- --------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
EXPORT_RISK_EXPOSURE             sqlplus                                            unknown                                        1928      52762 db file sequential r 2025/01/08 22:23:08  2025/01/08 23:19:38        102                 47999 +000000000 00:56:29.438 30%
EXPORT_RISK_EXPOSURE             sqlplus                                            unknown                                        1928      52762 ON CPU               2025/01/08 22:34:14  2025/01/08 23:20:08         94                  5115 +000000000 00:45:54.560 28%
EXPORT_RISK_EXPOSURE             sqlplus                                            unknown                                        1928      52762 db file parallel rea 2025/01/08 22:23:29  2025/01/08 23:18:57         89                  4732 +000000000 00:55:27.999 27%
EXPORT_RISK_EXPOSURE             sqlplus                                            unknown         a9g6byjwbk72x 1113796382       1928      52762 direct path read     2025/01/08 22:24:30  2025/01/08 22:37:38         50                     1 +000000000 00:13:08.480 15%



MODULE                           PROGRAM                                            CLIENT_ID       SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- -------------------------------------------------- --------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
EXPORT_RISK_EXPOSURE             sqlplus                                            unknown         a9g6byjwbk72x 1113796382       1928      52762                      2025/01/08 22:23:29  2025/01/08 22:37:38         84                     1 +000000000 00:14:09.919 25%
EXPORT_RISK_EXPOSURE             sqlplus                                            unknown         f488v1c6f2z9p 3391415704       1928      52762                      2025/01/08 22:41:03  2025/01/08 23:19:17         38                    40 +000000000 00:38:13.761 11%
EXPORT_RISK_EXPOSURE             sqlplus                                            unknown         06gp1pv9xfa9r 2945860215       1928      52762                      2025/01/08 22:37:49  2025/01/08 23:09:23         37                  5115 +000000000 00:31:34.400 11%
EXPORT_RISK_EXPOSURE             sqlplus                                            unknown         2rd5gw5wgz1hm 1472377725       1928      52762                      2025/01/08 22:39:52  2025/01/08 23:19:27         27                  5114 +000000000 00:39:35.680 8%
EXPORT_RISK_EXPOSURE             sqlplus                                            unknown         7r5jqc68xyg9q 2088163355       1928      52762                      2025/01/08 22:44:08  2025/01/08 23:19:48         20                    52 +000000000 00:35:40.160 6%
EXPORT_RISK_EXPOSURE             sqlplus                                            unknown         8kt66uw1m9256 3897645497       1928      52762                      2025/01/08 22:42:05  2025/01/08 23:18:57         19                  1559 +000000000 00:36:51.840 6%
EXPORT_RISK_EXPOSURE             sqlplus                                            unknown         0r5vq45pncfsz 2604568021       1928      52762                      2025/01/08 23:13:39  2025/01/08 23:16:23         17                     1 +000000000 00:02:43.840 5%



SQL_ID          Snap Id INSTANCE_NUMBER NAME                   POSITION DUP_POSITION DATATYPE_STRING      VALUE_STRING                             INTERVAL
------------- --------- --------------- -------------------- ---------- ------------ -------------------- ---------------------------------------- ----------------------------------------------------
7r5jqc68xyg9q     17009               1 :B1                           1              VARCHAR2(32)         1903190061                               2025/01/08 23
7r5jqc68xyg9q     17009               1 :B2                           2              DATE                 01/08/2025 00:00:00                      2025/01/08 23
7r5jqc68xyg9q     17009               1 :B1                           3              VARCHAR2(32)         1903190061                               2025/01/08 23
7r5jqc68xyg9q     17009               1 :B1                           4              VARCHAR2(32)         1903190061                               2025/01/08 23
7r5jqc68xyg9q     17010               1 :B1                           1              VARCHAR2(32)         2304110015                               2025/01/09 00
7r5jqc68xyg9q     17010               1 :B2                           2              DATE                 01/08/2025 00:00:00                      2025/01/09 00
7r5jqc68xyg9q     17010               1 :B1                           3              VARCHAR2(32)         2304110015                               2025/01/09 00
7r5jqc68xyg9q     17010               1 :B1                           4              VARCHAR2(32)         2304110015                               2025/01/09 00

INDEX_NAME                     INFO       BLEVEL       ROWS   ROWS/KEY       KEYS     BLOCKS   CF  DATAB/KEY  LEAFB/KEY LAST_ANALY COLUMNS
------------------------------ ------ ---------- ---------- ---------- ---------- ---------- ---- ---------- ---------- ---------- ------------------------------------------------------------
PK_DWH_RISK_EXPOSURE           UNIQUE          2      21005          1      21005        274    1          1          1 08/01/2025 EXPOSURE_ID,DATE_FROM,LIMIT_ID


Plan hash value: 2088163355
-----------------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                  | Name                   | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  |
-----------------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                           |                        |      1 |        |     9 (100)|      0 |00:00:51.07 |    7473K|  14573 |
|*  1 |  FILTER                                    |                        |      1 |        |            |      0 |00:00:51.07 |    7473K|  14573 |
|   2 |   FAST DUAL                                |                        |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*  3 |   FILTER                                   |                        |      1 |        |            |      0 |00:00:51.07 |    7473K|  14573 |
|   4 |    NESTED LOOPS                            |                        |      1 |      1 |     7   (0)|      0 |00:00:51.07 |    7473K|  14573 |
|   5 |     NESTED LOOPS SEMI                      |                        |      1 |      1 |     6   (0)|      0 |00:00:51.07 |    7473K|  14573 |
|   6 |      MERGE JOIN CARTESIAN                  |                        |      1 |     31 |     5   (0)|   2674K|00:00:12.80 |   12975 |  12372 |
|   7 |       MERGE JOIN CARTESIAN                 |                        |      1 |      1 |     4   (0)|    906 |00:00:12.10 |   12948 |  12347 |
|*  8 |        TABLE ACCESS BY INDEX ROWID BATCHED | DWH_RISK_EXPOSURE      |      1 |      1 |     3   (0)|      3 |00:00:01.36 |     336 |    314 |
|*  9 |         INDEX SKIP SCAN                    | PK_DWH_RISK_EXPOSURE   |      1 |    619 |     3   (0)|   5278 |00:00:01.19 |     153 |    153 |
|  10 |        BUFFER SORT                         |                        |      3 |      1 |     1   (0)|    906 |00:00:10.75 |   12612 |  12033 |
|* 11 |         TABLE ACCESS BY INDEX ROWID BATCHED| G_PIECE                |      1 |      1 |     1   (0)|    302 |00:00:10.75 |   12612 |  12033 |
|* 12 |          INDEX RANGE SCAN                  | GP_TYPEDOC             |      1 |     16 |     1   (0)|  20335 |00:00:01.41 |      84 |     83 |
|  13 |       BUFFER SORT                          |                        |    906 |   2950 |     4   (0)|   2674K|00:00:00.44 |      27 |     25 |
|  14 |        INDEX FULL SCAN                     | M_S_L_F_C_PK           |      1 |   2950 |     1   (0)|   2952 |00:00:00.16 |      27 |     25 |
|* 15 |      TABLE ACCESS BY INDEX ROWID BATCHED   | G_PIECE                |   2082K|      1 |     1   (0)|      0 |00:00:37.67 |    7460K|   2201 |
|* 16 |       INDEX RANGE SCAN                     | PIE_REFPIECE           |   2082K|      1 |     1   (0)|   2082K|00:00:06.49 |    3592K|    665 |
|* 17 |     INDEX RANGE SCAN                       | DOS_REFDOSS_REFLOT_IDX |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 18 |    INDEX RANGE SCAN                        | REFHIERARCHIE_IDX      |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
-----------------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   1 - filter( IS NOT NULL)
   3 - filter(("DECOMPTE"."REFLOT"=:B1 OR  IS NOT NULL))
   8 - filter("RBR"."CONTRACT_ID"=:B1)
   9 - access("RBR"."DATE_FROM"=TO_DATE(:B2,'MM/DD/YYYY'))
       filter("RBR"."DATE_FROM"=TO_DATE(:B2,'MM/DD/YYYY'))
  11 - filter("LIM_REQ"."FG05"='O')
  12 - access("LIM_REQ"."TYPEDOC"='C' AND "LIM_REQ"."TYPPIECE"='REQUEST_LIMITE')
  15 - filter(("LIM_PAR"."LIBELLE_20_1" IS NOT NULL AND "LIM_PAR"."TYPPIECE"='PARAM_LIMITE' AND
              "LIM_PAR"."LIBELLE_20_1"="LIM_REQ"."REFPIECE"))
  16 - access("LIM_PAR"."REFPIECE"="MST"."LIMIT_ID")
  17 - access("DECOMPTE"."REFDOSS"="MST"."DECOMPTE_ID")
  18 - access("REFHIERARCHIE"=:B1 AND "REFDOSS"=:B1)
       filter("REFDOSS"=:B1)

*/
/********************************OLD Metrics***************************************/

/********************************New SQL*******************************************/

SELECT 1 
  FROM DUAL 
 WHERE EXISTS ( SELECT /*+ no_merge(DECOMPTE) no_push_pred(DECOMPTE) LEADING(DECOMPTE MST LIM_PAR LIM_REQ) */
                       1 
                  FROM G_PIECE LIM_REQ , 
                       G_PIECE LIM_PAR , 
                       M_STATEMENT_LIMIT_FI_CONS MST , 
                       RBR_DWH_RISK_EXPOSURE RBR ,
                       ( SELECT REFDOSS
                           FROM G_DOSSIER
                          WHERE REFLOT = :B1
                          UNION
                         SELECT D.REFDOSS REFDOSS
                           FROM G_DOSSIER D,
                                G_DOSSIER RE
                          WHERE RE.REFHIERARCHIE = :B1
                            AND D.REFLOT = RE.REFDOSS ) DECOMPTE
                 WHERE RBR.CONTRACT_ID = :B1 
                   AND RBR.DATE_FROM = TO_DATE(:B2, 'MM/DD/YYYY')
                   AND LIM_REQ.TYPPIECE = 'REQUEST_LIMITE' 
                   AND LIM_REQ.FG05 = 'O' 
                   AND LIM_REQ.TYPEDOC = 'C' 
                   AND LIM_PAR.TYPPIECE = 'PARAM_LIMITE' 
                   AND LIM_PAR.LIBELLE_20_1 = LIM_REQ.REFPIECE 
                   AND LIM_PAR.REFPIECE = MST.LIMIT_ID 
                   AND DECOMPTE.REFDOSS = MST.DECOMPTE_ID );

/********************************New SQL*******************************************/
/********************************New Metrics***************************************/
/*
Plan hash value: 1719191805
----------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                 | Name                      | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers |
----------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                          |                           |      1 |        |    11 (100)|      0 |00:00:00.01 |      44 |
|*  1 |  FILTER                                   |                           |      1 |        |            |      0 |00:00:00.01 |      44 |
|   2 |   FAST DUAL                               |                           |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |
|   3 |   MERGE JOIN CARTESIAN                    |                           |      1 |      1 |     9  (23)|      0 |00:00:00.01 |      44 |
|   4 |    NESTED LOOPS                           |                           |      1 |      1 |     8  (25)|      0 |00:00:00.01 |      44 |
|   5 |     NESTED LOOPS                          |                           |      1 |      1 |     8  (25)|      4 |00:00:00.01 |      40 |
|   6 |      NESTED LOOPS                         |                           |      1 |      1 |     7  (29)|      4 |00:00:00.01 |      30 |
|   7 |       NESTED LOOPS                        |                           |      1 |     25 |     6  (34)|      4 |00:00:00.01 |      12 |
|   8 |        VIEW                               |                           |      1 |      4 |     5  (40)|      1 |00:00:00.01 |       6 |
|   9 |         SORT UNIQUE                       |                           |      1 |      4 |     5  (40)|      1 |00:00:00.01 |       6 |
|  10 |          UNION-ALL                        |                           |      1 |        |            |      1 |00:00:00.01 |       6 |
|* 11 |           INDEX RANGE SCAN                | G_DOSSIER_RL_CD_RD_RF_IDX |      1 |      1 |     1   (0)|      0 |00:00:00.01 |       2 |
|  12 |           NESTED LOOPS                    |                           |      1 |      3 |     2   (0)|      1 |00:00:00.01 |       4 |
|* 13 |            INDEX RANGE SCAN               | REFHIERARCHIE_IDX         |      1 |      2 |     1   (0)|      1 |00:00:00.01 |       2 |
|* 14 |            INDEX RANGE SCAN               | G_DOSSIER_RL_CD_RD_RF_IDX |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       2 |
|  15 |        TABLE ACCESS BY INDEX ROWID BATCHED| M_STATEMENT_LIMIT_FI_CONS |      1 |      6 |     1   (0)|      4 |00:00:00.01 |       6 |
|* 16 |         INDEX RANGE SCAN                  | LMT_FI_CONS_DCPT_ID_IDX   |      1 |      6 |     1   (0)|      4 |00:00:00.01 |       2 |
|* 17 |       TABLE ACCESS BY INDEX ROWID BATCHED | G_PIECE                   |      4 |      1 |     1   (0)|      4 |00:00:00.01 |      18 |
|* 18 |        INDEX RANGE SCAN                   | PIE_REFPIECE              |      4 |      1 |     1   (0)|      4 |00:00:00.01 |      10 |
|* 19 |      INDEX RANGE SCAN                     | PIE_REFPIECE              |      4 |      1 |     1   (0)|      4 |00:00:00.01 |      10 |
|* 20 |     TABLE ACCESS BY INDEX ROWID           | G_PIECE                   |      4 |      1 |     1   (0)|      0 |00:00:00.01 |       4 |
|  21 |    BUFFER SORT                            |                           |      0 |      1 |     8  (25)|      0 |00:00:00.01 |       0 |
|* 22 |     INDEX RANGE SCAN                      | TEST_DD_INDEX             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
----------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   1 - filter( IS NOT NULL)
  11 - access("REFLOT"=:B1)
  13 - access("RE"."REFHIERARCHIE"=:B1)
  14 - access("D"."REFLOT"="RE"."REFDOSS")
       filter("D"."REFLOT" IS NOT NULL)
  16 - access("DECOMPTE"."REFDOSS"="MST"."DECOMPTE_ID")
  17 - filter(("LIM_PAR"."LIBELLE_20_1" IS NOT NULL AND "LIM_PAR"."TYPPIECE"='PARAM_LIMITE'))
  18 - access("LIM_PAR"."REFPIECE"="MST"."LIMIT_ID")
  19 - access("LIM_PAR"."LIBELLE_20_1"="LIM_REQ"."REFPIECE")
  20 - filter(("LIM_REQ"."TYPPIECE"='REQUEST_LIMITE' AND "LIM_REQ"."TYPEDOC"='C' AND "LIM_REQ"."FG05"='O'))
  22 - access("RBR"."CONTRACT_ID"=:B1 AND "RBR"."DATE_FROM"=TO_DATE(:B2,'MM/DD/YYYY'))
*/
/********************************New Metrics***************************************/

/********************************Index statistics**********************************/

/********************************Other SQLs****************************************/          
/*

*/ 
/********************************Other SQLs****************************************/              
