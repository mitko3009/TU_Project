/********************************************************************************
*********       E-mail subject: EFDE2WEB-1204
*********             Instance: Patch 2
*********          Description: 
Problem:
The ftr_batch FTR_BATCH_INT_DAILY_JOBS took too long on Patch 2.

Analysis:
After the analyze, we found that the TOP SQL for this batch, which was responsible for 99% of the time is 1trgumn44gbja.
The problem with this query is that it doesn't use appropriate index to access table G_FCIMESSAGES. This problem was already discussed in EFAGDEV-2594, where it was suggested 
to create index on column BUYER_BUYERNR, which is the selective predicate. The index is created as requested, but it looks like someone added IMX_UPPER() to the column, which doesn't allow 
the use of the index. In this situation, we have several ways how to deal with the situation as it is described in the Suggestion section below.

Suggestion:
1. Please check is it possible to remove the IMX_UPPER() from column BUYER_BUYERNR as it is shown in the New SQL section below, which will allow the use of the index on column BUYER_BUYERNR .
2. If it is not possible to remove the IMX_UPPER(), please discuss with C&D to create new index, which should be on IMX_UPPER(BUYER_BUYERNR).

*********               SQL_ID: 1trgumn44gbja
*********      Program/Package: 
*********              Request: Ruslan Zafirov
*********               Author: Dimitar Dimitrov
********* Received e-mail date: 05/09/2024
*********      Resolution date: 05/09/2024
*********  Trace old file here: \\epox\specifs\performance\tmp\
*********  Trace new file here:
***********************************************************************************/

/********************************OLD SQL*******************************************/

VAR B1 VARCHAR2(32);
EXEC :B1 := 'A6062WVW';
VAR B2 VARCHAR2(32);
EXEC :B2 := 'TR01600';
VAR B3 VARCHAR2(32);
EXEC :B3 := '385132';
VAR B4 VARCHAR2(32);
EXEC :B4 := 'TR07127';
VAR B5 VARCHAR2(32);
EXEC :B5 := 'DE00900';
VAR B6 VARCHAR2(32);
EXEC :B6 := 'MSG06';

SELECT M.CREDITCOVERNR,
       M.CCD_CURRENCY,
       LPAD(:B2, 10, '0') || '.' || M.ORIGREQNR,
       M.ORIGREQDATE
  FROM G_INDIVIDU I, 
       G_FCIMESSAGES M
 WHERE M.REF_MESS_FCI = ( SELECT INLN.REF_MESS_FCI
                            FROM ( SELECT REF_MESS_FCI
                                     FROM G_FCIMESSAGES
                                    WHERE MESSAGETYPE = :B6
                                      AND MESSAGE_DIRECTION = 'O'
                                      AND IMX_UPPER(MSGINFO_SENDERCODE) = IMX_UPPER(:B5)
                                      AND IMX_UPPER(MSGINFO_RECIEVER_CODE) = IMX_UPPER(:B2)
                                      AND IMX_UPPER(IF_FACTORCODE) = IMX_UPPER(:B5)
                                      AND IMX_UPPER(EF_FACTORCODE) = IMX_UPPER(:B2)
                                      AND ( IMX_UPPER(SELLER_SELLERNR) = IMX_UPPER(:B4) 
                                         OR IMX_UPPER(SELLER_NEWSELLERNR) = IMX_UPPER(:B4))
                                      AND IMX_UPPER(BUYER_BUYERNR) = IMX_UPPER(:B3)
                                    ORDER BY DT_CREATION DESC ) INLN
                           WHERE ROWNUM = 1 )
   AND I.REFINDIVIDU = :B1
   AND ( NVL(IMX_UPPER(M.BUYER_BUYERNAME), ' ') != NVL(SUBSTR(IMX_UPPER(I.NOM), 1, 35), ' ')
      OR NVL(IMX_UPPER(M.BUYER_NAMECONT), ' ') != NVL(SUBSTR(IMX_UPPER(I.PRENOM), 1, 35), ' ') 
      OR NVL(IMX_UPPER(M.BUYER_STREET), ' ') != NVL(SUBSTR(IMX_UPPER(NVL(I.ADR1, I.ADR2)), 1, 35), ' ')
      OR NVL(IMX_UPPER(M.BUYER_STATE), ' ') != NVL(SUBSTR(IMX_UPPER(I.DIVISION), 1, 9), ' ') 
      OR NVL(IMX_UPPER(M.BUYER_CITY), ' ') != NVL(SUBSTR(IMX_UPPER(I.VILLE), 1, 35), ' ')
      OR NVL(IMX_UPPER(M.BUYER_POSTCODE), ' ') != NVL(SUBSTR(IMX_UPPER(I.CP), 1, 9), ' ')
      OR (    M.BUYER_RESPONSEAGENCY = 'VAT' 
          AND NVL(M.BUYER_BUYERCOMPANYREGNR, ' ') != NVL(I.TVA, ' '))
      OR (    M.BUYER_RESPONSEAGENCY = 'SIRET' 
          AND NVL(M.BUYER_BUYERCOMPANYREGNR, ' ') != NVL(I.SIRET, ' ')));
/********************************OLD SQL*******************************************/
/********************************OLD Metrics***************************************/
/*
MODULE                           PROGRAM                                            CLIENT_ID       SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                   ACTIVE     NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- -------------------------------------------------- --------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
ftr_batch_FTR_BATCH_INT_DAILY_JO ftr_batch                                                                                                         ON CPU               2024/09/04 00:46:34  2024/09/04 05:09:52   15441                   956614 +000000000 04:23:18.362 66%
BS

msgq_edite                                                                                                                                         ON CPU               2024/09/04 00:05:11  2024/09/04 04:55:01    1774                  8090530 +000000000 04:49:49.914 8%
msgq_pilote                                                                                                                                        ON CPU               2024/09/04 00:37:23  2024/09/04 05:09:32    1706                 16675425 +000000000 04:32:08.836 7%
msgq                                                                                                                                               ON CPU               2024/09/04 00:05:01  2024/09/04 05:08:42    1214                  2748570 +000000000 05:03:40.791 5%
bmx_alibatch                     bmx_alibatch                                                       crcgjv2y3kyrt                   696      22749 ON CPU               2024/09/04 00:05:01  2024/09/04 05:09:52     991                     4131 +000000000 05:04:50.866 4%
                                                                                                                                                                                                                                        

MODULE                           PROGRAM                                            CLIENT_ID       SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                   ACTIVE     NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- -------------------------------------------------- --------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
ftr_batch_FTR_BATCH_INT_DAILY_JO ftr_batch                                                                                                                              2024/09/04 00:46:34  2024/09/04 05:09:52   15443                   956614 +000000000 04:23:18.362 100%
BS


MODULE                           PROGRAM                                            CLIENT_ID       SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                   ACTIVE     NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- -------------------------------------------------- --------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
ftr_batch_FTR_BATCH_INT_DAILY_JO ftr_batch                                                                                                         ON CPU               2024/09/04 00:46:34  2024/09/04 05:09:52    5441                   956614 +000000000 04:23:18.362 100%
BS

ftr_batch_FTR_BATCH_INT_DAILY_JO ftr_batch                                                          1trgumn44gbja 3715613992        372       9788 db file parallel rea 2024/09/04 01:12:26  2024/09/04 01:12:26       1                        1 +000000000 00:00:00.000 0%
BS

ftr_batch_FTR_BATCH_INT_DAILY_JO ftr_batch                                                          1trgumn44gbja 3715613992        879      65385 log file switch (pri 2024/09/04 03:36:26  2024/09/04 03:36:26       1                        1 +000000000 00:00:00.000 0%
BS


MODULE                           PROGRAM                                            CLIENT_ID       SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                   ACTIVE     NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- -------------------------------------------------- --------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
ftr_batch_FTR_BATCH_INT_DAILY_JO ftr_batch                                                                                          545      30497 ON CPU               2024/09/04 00:46:44  2024/09/04 05:09:52  1555                      45016 +000000000 04:23:08.350 10%
BS                                                                                                                                                                                                                                         
                                                                                                                                                                                                                                           
ftr_batch_FTR_BATCH_INT_DAILY_JO ftr_batch                                                                                          532      63869 ON CPU               2024/09/04 00:46:34  2024/09/04 05:09:52  1551                      45005 +000000000 04:23:18.362 10%
BS                                                                                                                                                                                                                                         
                                                                                                                                                                                                                                           
ftr_batch_FTR_BATCH_INT_DAILY_JO ftr_batch                                                                                          193       9404 ON CPU               2024/09/04 00:46:44  2024/09/04 05:09:52  1550                     956609 +000000000 04:23:08.350 10%
BS                                                                                                                                                                                                                                         
                                                                                                                                                                                                                                           
ftr_batch_FTR_BATCH_INT_DAILY_JO ftr_batch                                                                                          365      31632 ON CPU               2024/09/04 00:46:44  2024/09/04 05:09:52  1546                     841068 +000000000 04:23:08.350 10%
BS                                                                                                                                                                                                                                         
                                                                                                                                                                                                                                           
ftr_batch_FTR_BATCH_INT_DAILY_JO ftr_batch                                                                                          884      36454 ON CPU               2024/09/04 00:46:34  2024/09/04 05:09:52  1542                     756185 +000000000 04:23:18.362 10%
BS                                                                                                                                                                                                                                         
                                                                                                                                                                                                                                           
ftr_batch_FTR_BATCH_INT_DAILY_JO ftr_batch                                                                                          538      44480 ON CPU               2024/09/04 00:46:34  2024/09/04 05:09:52  1542                      45008 +000000000 04:23:18.362 10%
BS                                                                                                                                                                                                                                         
                                                                                                                                                                                                                                           
ftr_batch_FTR_BATCH_INT_DAILY_JO ftr_batch                                                                                         1214      42493 ON CPU               2024/09/04 00:46:44  2024/09/04 05:09:52  1541                     853628 +000000000 04:23:08.350 10%
BS                                                                                                                                                                                                                                         
                                                                                                                                                                                                                                           
ftr_batch_FTR_BATCH_INT_DAILY_JO ftr_batch                                                                                          879      65385                      2024/09/04 00:46:44  2024/09/04 05:09:42  1540                     826228 +000000000 04:22:58.339 10%
BS                                                                                                                                                                                                                                         
                                                                                                                                                                                                                                           
ftr_batch_FTR_BATCH_INT_DAILY_JO ftr_batch                                                                                          372       9788                      2024/09/04 00:46:34  2024/09/04 05:09:52  1539                     139351 +000000000 04:23:18.362 10%
BS                                                                                                                                                                                                                                         
                                                                                                                                                                                                                                           
ftr_batch_FTR_BATCH_INT_DAILY_JO ftr_batch                                                                                         1051      10367 ON CPU               2024/09/04 00:46:44  2024/09/04 05:09:52  1537                     939104 +000000000 04:23:08.350 10%
BS                                                                                                                                                                                                                                         



MODULE                           PROGRAM                                            CLIENT_ID       SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                  TO                  ACTIVE     NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- -------------------------------------------------- --------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
ftr_batch_FTR_BATCH_INT_DAILY_JO ftr_batch                                                          1trgumn44gbja 3715613992        545      30497 ON CPU               2024/09/04 00:47:34  2024/09/04 05:09:52        1547                45015 +000000000 04:22:18.298 10%
BS                                                                                                                                                                                                                     
                                                                                                                                                                                                                       
ftr_batch_FTR_BATCH_INT_DAILY_JO ftr_batch                                                          1trgumn44gbja 3715613992        532      63869 ON CPU               2024/09/04 00:47:54  2024/09/04 05:09:52        1540                44993 +000000000 04:21:58.276 10%
BS                                                                                                                                                                                                                     
                                                                                                                                                                                                                       
ftr_batch_FTR_BATCH_INT_DAILY_JO ftr_batch                                                          1trgumn44gbja 3715613992        193       9404 ON CPU               2024/09/04 00:47:54  2024/09/04 05:09:52        1540                44994 +000000000 04:21:58.276 10%
BS                                                                                                                                                                                                                     
                                                                                                                                                                                                                       
ftr_batch_FTR_BATCH_INT_DAILY_JO ftr_batch                                                          1trgumn44gbja 3715613992        365      31632 ON CPU               2024/09/04 00:47:54  2024/09/04 05:09:52        1534                44993 +000000000 04:21:58.276 10%
BS                                                                                                                                                                                                                     
                                                                                                                                                                                                                       
ftr_batch_FTR_BATCH_INT_DAILY_JO ftr_batch                                                          1trgumn44gbja 3715613992        538      44480 ON CPU               2024/09/04 00:47:54  2024/09/04 05:09:52        1533                44990 +000000000 04:21:58.276 10%
BS                                                                                                                                                                                                                     
                                                                                                                                                                                                                       
ftr_batch_FTR_BATCH_INT_DAILY_JO ftr_batch                                                          1trgumn44gbja 3715613992        884      36454 ON CPU               2024/09/04 00:47:54  2024/09/04 05:09:52        1531                44985 +000000000 04:21:58.276 10%
BS                                                                                                                                                                                                                     
                                                                                                                                                                                                                       
ftr_batch_FTR_BATCH_INT_DAILY_JO ftr_batch                                                          1trgumn44gbja 3715613992       1214      42493 ON CPU               2024/09/04 00:47:34  2024/09/04 05:09:52        1531                45021 +000000000 04:22:18.298 10%
BS                                                                                                                                                                                                                     
                                                                                                                                                                                                                       
ftr_batch_FTR_BATCH_INT_DAILY_JO ftr_batch                                                          1trgumn44gbja 3715613992        372       9788                      2024/09/04 00:47:34  2024/09/04 05:09:52        1529                45018 +000000000 04:22:18.298 10%
BS                                                                                                                                                                                                                     
                                                                                                                                                                                                                       
ftr_batch_FTR_BATCH_INT_DAILY_JO ftr_batch                                                          1trgumn44gbja 3715613992       1051      10367 ON CPU               2024/09/04 00:47:54  2024/09/04 05:09:52        1528                44989 +000000000 04:21:58.276 10%
BS                                                                                                                                                                                                                     
                                                                                                                                                                                                                       
ftr_batch_FTR_BATCH_INT_DAILY_JO ftr_batch                                                          1trgumn44gbja 3715613992        879      65385                      2024/09/04 00:47:54  2024/09/04 05:09:42        1526                44962 +000000000 04:21:48.265 10%
BS


MODULE                           PROGRAM                                            CLIENT_ID       SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                   ACTIVE     NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- -------------------------------------------------- --------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
ftr_batch_FTR_BATCH_INT_DAILY_JO ftr_batch                                                          1trgumn44gbja 3715613992                                            2024/09/04 00:47:34  2024/09/04 05:09:52   15339                    45021 +000000000 04:22:18.298 99%
BS

ftr_batch_FTR_BATCH_INT_DAILY_JO ftr_batch                                                          3hrktnptnxrmn  472019096                       ON CPU               2024/09/04 00:46:44  2024/09/04 00:47:44      64                       10 +000000000 00:01:00.063 0%
BS

ftr_batch_FTR_BATCH_INT_DAILY_JO ftr_batch                                                          gjhq46vtxyym0          0                       ON CPU               2024/09/04 00:58:34  2024/09/04 04:53:41      14                       10 +000000000 03:55:06.466 0%
BS

ftr_batch_FTR_BATCH_INT_DAILY_JO ftr_batch                                                          c7qk5jrznw98c          0                       ON CPU               2024/09/04 01:36:47  2024/09/04 03:33:36      10                   266612 +000000000 01:56:48.322 0%
 
 
 
INSTANCE_NUMBER SQL_ID            ELAPSED MAX_WAIT_ON     PC_OF  WAIT_TIME            GETS      READS       ROWS  ELAP/EXEC       GETS/EXEC READS/EXEC  ROWS/EXEC       EXEC PLAN_HASH_VALUE
--------------- ------------- ----------- --------------- ----- ---------- --------------- ---------- ---------- ---------- --------------- ---------- ---------- ---------- ---------------
              1 1trgumn44gbja      132759 CPU             67%   195004.821      1014844628       7400      11938       3.06           23408        .17        .28      43354  3715613992
 


SQL_ID        SQL_PLAN_HASH_VALUE SQL_PLAN_LINE_ID SQL_PLAN_OPERATION             SQL_PLAN_OPTIONS                   ACTIVE
------------- ------------------- ---------------- ------------------------------ ------------------------------ ----------
1trgumn44gbja          3715613992               10 INDEX                          SKIP SCAN                           14651
1trgumn44gbja          3715613992                9 TABLE ACCESS                   BY INDEX ROWID BATCHED                684
1trgumn44gbja          3715613992                  SELECT STATEMENT                                                       2
1trgumn44gbja          3715613992                4 TABLE ACCESS                   BY INDEX ROWID                          2

Plan hash value: 3715613992
-------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                 | Name          | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  |
-------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                          |               |      1 |        |   653 (100)|      0 |00:00:01.73 |    2825 |      6 |
|   1 |  NESTED LOOPS                             |               |      1 |      1 |     4   (0)|      0 |00:00:01.73 |    2825 |      6 |
|   2 |   TABLE ACCESS BY INDEX ROWID             | G_INDIVIDU    |      1 |      1 |     3   (0)|      1 |00:00:00.01 |       6 |      0 |
|*  3 |    INDEX UNIQUE SCAN                      | IND_REFINDIV  |      1 |      1 |     2   (0)|      1 |00:00:00.01 |       3 |      0 |
|*  4 |   TABLE ACCESS BY INDEX ROWID             | G_FCIMESSAGES |      1 |      1 |     1   (0)|      0 |00:00:01.73 |    2819 |      6 |
|*  5 |    INDEX UNIQUE SCAN                      | FCIMSGM_PK    |      1 |      1 |     0   (0)|      0 |00:00:01.73 |    2819 |      6 |
|*  6 |     COUNT STOPKEY                         |               |      1 |        |            |      0 |00:00:01.73 |    2819 |      6 |
|   7 |      VIEW                                 |               |      1 |      1 |   649   (1)|      0 |00:00:01.73 |    2819 |      6 |
|*  8 |       SORT ORDER BY STOPKEY               |               |      1 |      1 |   649   (1)|      0 |00:00:01.73 |    2819 |      6 |
|*  9 |        TABLE ACCESS BY INDEX ROWID BATCHED| G_FCIMESSAGES |      1 |      1 |   648   (0)|      0 |00:00:01.73 |    2819 |      6 |
|* 10 |         INDEX SKIP SCAN                   | FCIMSG_ADR_I  |      1 |      2 |   647   (0)|  11391 |00:00:01.60 |    1111 |      6 |
-------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   3 - access("I"."REFINDIVIDU"=:B1)
   4 - filter((NVL("IMX_UPPER"("M"."BUYER_BUYERNAME"),' ')<>NVL(SUBSTR("IMX_UPPER"("I"."NOM"),1,35),' ') OR
              NVL("IMX_UPPER"("M"."BUYER_NAMECONT"),' ')<>NVL(SUBSTR("IMX_UPPER"("I"."PRENOM"),1,35),' ') OR
              NVL("IMX_UPPER"("M"."BUYER_STREET"),' ')<>NVL(SUBSTR("IMX_UPPER"(NVL("I"."ADR1","I"."ADR2")),1,35),' ') OR
              NVL("IMX_UPPER"("M"."BUYER_STATE"),' ')<>NVL(SUBSTR("IMX_UPPER"("I"."DIVISION"),1,9),' ') OR NVL("IMX_UPPER"("M"."BUYER_CITY"),'
              ')<>NVL(SUBSTR("IMX_UPPER"("I"."VILLE"),1,35),' ') OR NVL("IMX_UPPER"("M"."BUYER_POSTCODE"),'
              ')<>NVL(SUBSTR("IMX_UPPER"("I"."CP"),1,9),' ') OR ("M"."BUYER_RESPONSEAGENCY"='VAT' AND NVL("M"."BUYER_BUYERCOMPANYREGNR",'
              ')<>NVL("I"."TVA",' ')) OR ("M"."BUYER_RESPONSEAGENCY"='SIRET' AND NVL("M"."BUYER_BUYERCOMPANYREGNR",' ')<>NVL("I"."SIRET",' '))))
   5 - access("M"."REF_MESS_FCI"=)
   6 - filter(ROWNUM=1)
   8 - filter(ROWNUM=1)
   9 - filter(("MESSAGETYPE"=:B6 AND "IMX_UPPER"("IF_FACTORCODE")="IMX_UPPER"(:B5) AND
              "IMX_UPPER"("EF_FACTORCODE")="IMX_UPPER"(:B2) AND "IMX_UPPER"("BUYER_BUYERNR")="IMX_UPPER"(:B3) AND
              ("IMX_UPPER"("SELLER_SELLERNR")="IMX_UPPER"(:B4) OR "IMX_UPPER"("SELLER_NEWSELLERNR")="IMX_UPPER"(:B4))))
  10 - access("MESSAGE_DIRECTION"='O')
       filter(("MESSAGE_DIRECTION"='O' AND "IMX_UPPER"("MSGINFO_SENDERCODE")="IMX_UPPER"(:B5) AND
              "IMX_UPPER"("MSGINFO_RECIEVER_CODE")="IMX_UPPER"(:B2)))
*/
/********************************OLD Metrics***************************************/

/********************************New SQL*******************************************/

SELECT M.CREDITCOVERNR,
       M.CCD_CURRENCY,
       LPAD(:B2, 10, '0') || '.' || M.ORIGREQNR,
       M.ORIGREQDATE
  FROM G_INDIVIDU I, 
       G_FCIMESSAGES M
 WHERE M.REF_MESS_FCI = ( SELECT INLN.REF_MESS_FCI
                            FROM ( SELECT REF_MESS_FCI
                                     FROM G_FCIMESSAGES
                                    WHERE MESSAGETYPE = :B6
                                      AND MESSAGE_DIRECTION = 'O'
                                      AND IMX_UPPER(MSGINFO_SENDERCODE) = IMX_UPPER(:B5)
                                      AND IMX_UPPER(MSGINFO_RECIEVER_CODE) = IMX_UPPER(:B2)
                                      AND IMX_UPPER(IF_FACTORCODE) = IMX_UPPER(:B5)
                                      AND IMX_UPPER(EF_FACTORCODE) = IMX_UPPER(:B2)
                                      AND ( IMX_UPPER(SELLER_SELLERNR) = IMX_UPPER(:B4) 
                                         OR IMX_UPPER(SELLER_NEWSELLERNR) = IMX_UPPER(:B4))
                                      AND BUYER_BUYERNR = IMX_UPPER(:B3)
                                    ORDER BY DT_CREATION DESC ) INLN
                           WHERE ROWNUM = 1 )
   AND I.REFINDIVIDU = :B1
   AND ( NVL(IMX_UPPER(M.BUYER_BUYERNAME), ' ') != NVL(SUBSTR(IMX_UPPER(I.NOM), 1, 35), ' ')
      OR NVL(IMX_UPPER(M.BUYER_NAMECONT), ' ') != NVL(SUBSTR(IMX_UPPER(I.PRENOM), 1, 35), ' ') 
      OR NVL(IMX_UPPER(M.BUYER_STREET), ' ') != NVL(SUBSTR(IMX_UPPER(NVL(I.ADR1, I.ADR2)), 1, 35), ' ')
      OR NVL(IMX_UPPER(M.BUYER_STATE), ' ') != NVL(SUBSTR(IMX_UPPER(I.DIVISION), 1, 9), ' ') 
      OR NVL(IMX_UPPER(M.BUYER_CITY), ' ') != NVL(SUBSTR(IMX_UPPER(I.VILLE), 1, 35), ' ')
      OR NVL(IMX_UPPER(M.BUYER_POSTCODE), ' ') != NVL(SUBSTR(IMX_UPPER(I.CP), 1, 9), ' ')
      OR (    M.BUYER_RESPONSEAGENCY = 'VAT' 
          AND NVL(M.BUYER_BUYERCOMPANYREGNR, ' ') != NVL(I.TVA, ' '))
      OR (    M.BUYER_RESPONSEAGENCY = 'SIRET' 
          AND NVL(M.BUYER_BUYERCOMPANYREGNR, ' ') != NVL(I.SIRET, ' ')));
/********************************New SQL*******************************************/
/********************************New Metrics***************************************/
/*

Plan hash value: 905769745
----------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                 | Name                      | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers |
----------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                          |                           |      1 |        |     9 (100)|      0 |00:00:00.01 |       8 |
|   1 |  NESTED LOOPS                             |                           |      1 |      1 |     4   (0)|      0 |00:00:00.01 |       8 |
|   2 |   TABLE ACCESS BY INDEX ROWID             | G_INDIVIDU                |      1 |      1 |     3   (0)|      1 |00:00:00.01 |       6 |
|*  3 |    INDEX UNIQUE SCAN                      | IND_REFINDIV              |      1 |      1 |     2   (0)|      1 |00:00:00.01 |       3 |
|*  4 |   TABLE ACCESS BY INDEX ROWID             | G_FCIMESSAGES             |      1 |      1 |     1   (0)|      0 |00:00:00.01 |       2 |
|*  5 |    INDEX UNIQUE SCAN                      | FCIMSGM_PK                |      1 |      1 |     0   (0)|      0 |00:00:00.01 |       2 |
|*  6 |     COUNT STOPKEY                         |                           |      1 |        |            |      0 |00:00:00.01 |       2 |
|   7 |      VIEW                                 |                           |      1 |      1 |     5  (20)|      0 |00:00:00.01 |       2 |
|*  8 |       SORT ORDER BY STOPKEY               |                           |      1 |      1 |     5  (20)|      0 |00:00:00.01 |       2 |
|*  9 |        TABLE ACCESS BY INDEX ROWID BATCHED| G_FCIMESSAGES             |      1 |      1 |     4   (0)|      0 |00:00:00.01 |       2 |
|* 10 |         INDEX RANGE SCAN                  | FCIMESS_BUYER_BUYERNR_IDX |      1 |      4 |     1   (0)|      0 |00:00:00.01 |       2 |
----------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   3 - access("I"."REFINDIVIDU"=:B1)
   4 - filter((NVL("IMX_UPPER"("M"."BUYER_BUYERNAME"),' ')<>NVL(SUBSTR("IMX_UPPER"("I"."NOM"),1,35),' ') OR
              NVL("IMX_UPPER"("M"."BUYER_NAMECONT"),' ')<>NVL(SUBSTR("IMX_UPPER"("I"."PRENOM"),1,35),' ') OR NVL("IMX_UPPER"("M"."BUYER_STREET"),'
              ')<>NVL(SUBSTR("IMX_UPPER"(NVL("I"."ADR1","I"."ADR2")),1,35),' ') OR NVL("IMX_UPPER"("M"."BUYER_STATE"),'
              ')<>NVL(SUBSTR("IMX_UPPER"("I"."DIVISION"),1,9),' ') OR NVL("IMX_UPPER"("M"."BUYER_CITY"),'
              ')<>NVL(SUBSTR("IMX_UPPER"("I"."VILLE"),1,35),' ') OR NVL("IMX_UPPER"("M"."BUYER_POSTCODE"),'
              ')<>NVL(SUBSTR("IMX_UPPER"("I"."CP"),1,9),' ') OR ("M"."BUYER_RESPONSEAGENCY"='VAT' AND NVL("M"."BUYER_BUYERCOMPANYREGNR",'
              ')<>NVL("I"."TVA",' ')) OR ("M"."BUYER_RESPONSEAGENCY"='SIRET' AND NVL("M"."BUYER_BUYERCOMPANYREGNR",' ')<>NVL("I"."SIRET",' '))))
   5 - access("M"."REF_MESS_FCI"=)
   6 - filter(ROWNUM=1)
   8 - filter(ROWNUM=1)
   9 - filter(("MESSAGETYPE"=:B6 AND "MESSAGE_DIRECTION"='O' AND "IMX_UPPER"("MSGINFO_SENDERCODE")="IMX_UPPER"(:B5) AND
              "IMX_UPPER"("MSGINFO_RECIEVER_CODE")="IMX_UPPER"(:B2) AND "IMX_UPPER"("IF_FACTORCODE")="IMX_UPPER"(:B5) AND
              "IMX_UPPER"("EF_FACTORCODE")="IMX_UPPER"(:B2) AND ("IMX_UPPER"("SELLER_SELLERNR")="IMX_UPPER"(:B4) OR
              "IMX_UPPER"("SELLER_NEWSELLERNR")="IMX_UPPER"(:B4))))
  10 - access("BUYER_BUYERNR"=:B3)
*/
/********************************New Metrics***************************************/

/********************************Index statistics**********************************/

/********************************Other SQLs****************************************/          
/*

*/ 
/********************************Other SQLs****************************************/              
