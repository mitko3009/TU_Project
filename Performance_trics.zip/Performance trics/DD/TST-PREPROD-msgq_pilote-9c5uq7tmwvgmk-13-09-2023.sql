/********************************************************************************
*********       E-mail subject: TSTDEV-2188
*********             Instance: PREPROD
*********          Description: 
Problem:
msgq processing speed is less than 50 calls per hour on PREPROD.

Analysis:
In the period between 2023/09/09 01:49:04 and 2023/09/11 07:09:33, one of the top SQL from the msgq% modules, was 9c5uq7tmwvgmk

Suggestion:
Please remove the hint as it is shown in the New SQL section below.

*********               SQL_ID: 9c5uq7tmwvgmk
*********      Program/Package: module: msgq_pilote, source: ftr_limit_cache
*********              Request: Dimitare Ivanov
*********               Author: Dimitar Dimitrov
********* Received e-mail date: 12/09/2023
*********      Resolution date: 13/09/2023
*********  Trace old file here: \\epox\specifs\performance\tmp\
*********  Trace new file here:
***********************************************************************************/

/********************************OLD SQL*******************************************/
var QSTRREFDOSSCCC_RD VARCHAR2(32);
exec :QSTRREFDOSSCCC_RD := '0001279351';

SELECT /*+ INDEX(M MSG_DOSS) dynamic_sampling(0) */
       prty,
       buff,
       M.refdoss,
       login,
       TO_CHAR(datetr_dt, 'dd/mm/yyyy hh24:mi:ss'),
       master_reftxt,
       M.createur,
       JobTxt,
       refaux,
       msgseq,
       NVL(loop_count, 0),
       NVL(postpone_count, 0),
       NVL(TO_CHAR(DT_SIMUL_DT, 'dd/mm/yyyy'), 'NO_SIMUL'),
       NVL(D.pieceinit, 'NOPIECEINIT')
  FROM msg_queue M, 
       g_dossier D
 WHERE M.refdoss = :qstrRefdossCCC_RD
   AND M.refdoss = D.refdoss
   AND prty > 0
   AND (prty < 90 OR prty = 99 OR DT_SIMUL_DT IS NOT NULL)
   AND nvl(dtlock_dt, SYSDATE - 1000) < SYSDATE - 1 / (24 * 60)
   AND NOT
        ((M.buff LIKE 'procConctr%' OR M.buff LIKE 'calfidec%') AND EXISTS
         (SELECT 1
            FROM msg_queue, g_dossier
           WHERE msg_queue.refdoss = g_dossier.refdoss
             AND g_dossier.reflot = M.refdoss
             AND msg_queue.buff LIKE 'calculdoss@%'
             AND ((msg_queue.prty BETWEEN 1 AND 89) OR (msg_queue.prty = 99))))
   AND NOT (M.buff LIKE 'procLimitConctr%' AND EXISTS
         (SELECT 1
               FROM msg_queue mq, g_dossier gd, G_CONCENTRATION_LIM_DEC gc
              WHERE mq.refdoss = gd.refdoss
                AND mq.buff LIKE 'calculdoss@%'
                AND ((mq.prty BETWEEN 1 AND 89) OR (mq.prty = 99))
                AND gd.reflot = gc.refdoss
                AND gc.limit_id = M.refdoss))
   AND NOT (M.buff LIKE 'procLimitConctr%' AND EXISTS
         (SELECT 1
               FROM msg_queue mq, g_dossier gd, G_CONCENTRATION_LIM_DEC gc
              WHERE mq.refdoss = gd.refdoss
                AND gd.categdoss LIKE 'DECOMPTE%'
                AND mq.buff LIKE 'calfidec@%'
                AND ((mq.prty BETWEEN 1 AND 89) OR (mq.prty = 99))
                AND gd.refdoss = gc.refdoss
                AND gc.limit_id = M.refdoss))
   AND NOT (M.buff LIKE 'procLimitConctr%' AND EXISTS
         (SELECT 1
               FROM msg_queue               q_in,
                    G_CONCENTRATION_LIM_DEC gc_in,
                    G_CONCENTRATION_LIM_DEC gc_curr
              WHERE q_in.buff LIKE 'procLimitConctr%'
                AND q_in.msgseq <> M.msgseq
                AND q_in.prty = 99
                AND gc_curr.limit_id = M.refdoss
                AND gc_in.limit_id = q_in.refdoss
                AND gc_in.refdoss = gc_curr.refdoss))
   AND NOT ((M.buff LIKE 'memo_decompte%' OR M.buff LIKE 'bundlePayment%' OR
        M.buff LIKE 'processBundles%' OR M.buff LIKE 'pfdgforfi%' OR
        M.buff LIKE 'pfdgforaf%' OR M.buff LIKE 'pfdgcreate%') AND
        EXISTS (SELECT 1
                     FROM msg_queue mq, g_concentration_lim_dec ld
                    WHERE mq.refdoss = ld.limit_id
                      AND mq.buff LIKE 'procLimitConctr%'
                      AND ((mq.prty BETWEEN 1 AND 89) OR (mq.prty = 99))
                      AND ld.refdoss = M.refdoss))
   AND NOT
        (M.buff LIKE 'calfidec%' AND EXISTS
         (SELECT 1
            FROM msg_queue, g_dossier
           WHERE msg_queue.refdoss = g_dossier.refdoss
             AND g_dossier.reflot = M.refdoss
             AND g_dossier.fg_frm_inc is NULL
             AND msg_queue.buff LIKE 'pilote@%'
             AND ((msg_queue.prty = 99) OR (msg_queue.prty BETWEEN 1 AND 89))))
   AND NOT (m.buff LIKE 'edit%' AND EXISTS
         (SELECT /*+ leading(DC) use_nl(RC) index(RC (refdoss)) */
              1
               FROM msg_queue RC, g_dossier DC, g_dossier d
              WHERE RC.buff LIKE 'retrocederContrat%'
                AND RC.refdoss = DC.reflot
                AND DC.refdoss = d.reflot
                AND d.refdoss = m.refdoss) AND EXISTS
         (SELECT 1
               FROM t_notif
              WHERE refdoss = m.refdoss
                AND maitre = to_char(m.msgseq)))
   AND NOT
        (M.buff LIKE 'safupload%' AND EXISTS
         (SELECT 1
            FROM msg_queue, g_dossier
           WHERE msg_queue.refdoss = g_dossier.refdoss
             AND g_dossier.reflot = M.refdoss
             AND msg_queue.buff LIKE 'valcess@%'
             AND ((msg_queue.prty BETWEEN 1 AND 89) OR (msg_queue.prty = 99))))
   AND NOT (M.buff LIKE 'safstart%' AND EXISTS
         (SELECT 1
               FROM MSG_QUEUE MSQ, G_DOSSIER C, G_DOSSIER SC
              WHERE MSQ.REFDOSS = C.REFDOSS
                AND SC.REFDOSS = C.REFLOT
                AND SC.REFLOT = M.REFDOSS
                AND MSQ.BUFF LIKE 'pilote@%'
                AND ((MSQ.PRTY BETWEEN 1 AND 89) OR (MSQ.PRTY = 99))
                AND UPPER(NVL(C.FLAG_ENVOI, 'N')) = 'N'
                AND C.CREATEUR NOT IN ('CTRL22', 'REQUEST_LIMIT')))
 ORDER BY case
            WHEN buff LIKE 'deldos@%' then
             8
            WHEN buff LIKE 'variab%' then
             9
            WHEN buff LIKE 'ecrit%' then
             10
            WHEN buff LIKE 'facture%' then
             10
            WHEN buff LIKE 'edit%' then
             20
            WHEN buff LIKE 'pilote@%' then
             30
            WHEN buff LIKE 'chkcess@%' then
             50
            WHEN buff LIKE 'valcess@%' then
             50
            WHEN buff LIKE 'calfidec@%' then
             60
            WHEN buff LIKE 'calc_nmp@%' then
             60
            WHEN buff LIKE 'limit_changed@%' then
             60
            WHEN buff LIKE 'ProcessLimit@%' then
             60
            WHEN buff LIKE 'FinDec%' then
             60
            WHEN buff LIKE 'procConctr%' then
             70
            WHEN buff LIKE 'procLimitConctr%' then
             70
            WHEN buff LIKE 'processAPDR@%' then
             75
            WHEN buff LIKE 'resDue2Contras%' then
             70
            WHEN buff LIKE 'bundlePayment%' then
             80
            WHEN buff LIKE 'processBundles%' then
             80
            WHEN buff LIKE 'pfdgforfi%' then
             85
            WHEN buff LIKE 'pfdgforaf%' then
             85
            WHEN buff LIKE 'pfdgcreate%' then
             85
            WHEN buff LIKE 'memo_decompte%' then
             90
            WHEN buff LIKE 'memo_decompte_pmtval%' then
             90
            else
             900
          END,
          prty,
          msgseq
   FOR UPDATE OF msgseq SKIP LOCKED;
/********************************OLD SQL*******************************************/
/********************************OLD Metrics***************************************/
/*
Plan hash value: 2385179965
------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                | Name                   | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers |
------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                         |                        |      1 |        |    18 (100)|      1 |00:00:00.89 |   17045 |
|   1 |  FOR UPDATE                              |                        |      1 |        |            |      1 |00:00:00.89 |   17045 |
|   2 |   SORT ORDER BY                          |                        |      1 |      1 |    18   (6)|      1 |00:00:00.89 |   17044 |
|*  3 |    FILTER                                |                        |      1 |        |            |      1 |00:00:00.89 |   17044 |
|   4 |     NESTED LOOPS                         |                        |      1 |      1 |     7   (0)|      1 |00:00:00.01 |       8 |
|   5 |      TABLE ACCESS BY INDEX ROWID         | G_DOSSIER              |      1 |      1 |     3   (0)|      1 |00:00:00.01 |       4 |
|*  6 |       INDEX UNIQUE SCAN                  | DOS_REFDOSS            |      1 |      1 |     2   (0)|      1 |00:00:00.01 |       3 |
|*  7 |      TABLE ACCESS BY INDEX ROWID BATCHED | MSG_QUEUE              |      1 |      1 |     4   (0)|      1 |00:00:00.01 |       4 |
|*  8 |       INDEX RANGE SCAN                   | MSG_DOSS               |      1 |      1 |     2   (0)|      1 |00:00:00.01 |       3 |
|   9 |     NESTED LOOPS SEMI                    |                        |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|* 10 |      TABLE ACCESS BY INDEX ROWID BATCHED | MSG_QUEUE              |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|* 11 |       INDEX RANGE SCAN                   | MSG_QUEUE_BUFF_IDX     |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|* 12 |      INDEX UNIQUE SCAN                   | AK_KEY_1_G_CONCEN      |      0 |      1 |     0   (0)|      0 |00:00:00.01 |       0 |
|  13 |     NESTED LOOPS SEMI                    |                        |      0 |      1 |     6   (0)|      0 |00:00:00.01 |       0 |
|  14 |      NESTED LOOPS                        |                        |      0 |      1 |     6   (0)|      0 |00:00:00.01 |       0 |
|* 15 |       TABLE ACCESS BY INDEX ROWID BATCHED| MSG_QUEUE              |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|* 16 |        INDEX RANGE SCAN                  | MSG_QUEUE_BUFF_IDX     |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|* 17 |       INDEX RANGE SCAN                   | DOS_REFDOSS_REFLOT_IDX |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |
|* 18 |      INDEX UNIQUE SCAN                   | AK_KEY_1_G_CONCEN      |      0 |      1 |     0   (0)|      0 |00:00:00.01 |       0 |
|  19 |     NESTED LOOPS SEMI                    |                        |      0 |      1 |     6   (0)|      0 |00:00:00.01 |       0 |
|  20 |      NESTED LOOPS                        |                        |      0 |      1 |     6   (0)|      0 |00:00:00.01 |       0 |
|* 21 |       TABLE ACCESS BY INDEX ROWID BATCHED| MSG_QUEUE              |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|* 22 |        INDEX RANGE SCAN                  | MSG_QUEUE_BUFF_IDX     |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|* 23 |       TABLE ACCESS BY INDEX ROWID        | G_DOSSIER              |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |
|* 24 |        INDEX UNIQUE SCAN                 | DOS_REFDOSS            |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 25 |      INDEX UNIQUE SCAN                   | AK_KEY_1_G_CONCEN      |      0 |      1 |     0   (0)|      0 |00:00:00.01 |       0 |
|  26 |     NESTED LOOPS SEMI                    |                        |      0 |      1 |     5   (0)|      0 |00:00:00.01 |       0 |
|  27 |      MERGE JOIN CARTESIAN                |                        |      0 |      1 |     5   (0)|      0 |00:00:00.01 |       0 |
|* 28 |       TABLE ACCESS BY INDEX ROWID BATCHED| MSG_QUEUE              |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|* 29 |        INDEX RANGE SCAN                  | MSG_QUEUE_BUFF_IDX     |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|  30 |       BUFFER SORT                        |                        |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 31 |        INDEX RANGE SCAN                  | AK_KEY_1_G_CONCEN      |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 32 |      INDEX UNIQUE SCAN                   | AK_KEY_1_G_CONCEN      |      0 |      1 |     0   (0)|      0 |00:00:00.01 |       0 |
|  33 |     NESTED LOOPS SEMI                    |                        |      0 |      1 |     6   (0)|      0 |00:00:00.01 |       0 |
|* 34 |      TABLE ACCESS BY INDEX ROWID BATCHED | MSG_QUEUE              |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|* 35 |       INDEX RANGE SCAN                   | MSG_QUEUE_BUFF_IDX     |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|* 36 |      TABLE ACCESS BY INDEX ROWID         | G_DOSSIER              |      0 |     92 |     2   (0)|      0 |00:00:00.01 |       0 |
|* 37 |       INDEX UNIQUE SCAN                  | DOS_REFDOSS            |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|  38 |     NESTED LOOPS SEMI                    |                        |      0 |      1 |     6   (0)|      0 |00:00:00.01 |       0 |
|* 39 |      TABLE ACCESS BY INDEX ROWID BATCHED | MSG_QUEUE              |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|* 40 |       INDEX RANGE SCAN                   | MSG_QUEUE_BUFF_IDX     |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|* 41 |      INDEX RANGE SCAN                    | DOS_REFDOSS_REFLOT_IDX |      0 |     92 |     2   (0)|      0 |00:00:00.01 |       0 |
|  42 |     NESTED LOOPS SEMI                    |                        |      0 |      1 |     8   (0)|      0 |00:00:00.01 |       0 |
|  43 |      NESTED LOOPS                        |                        |      0 |      1 |     6   (0)|      0 |00:00:00.01 |       0 |
|* 44 |       TABLE ACCESS BY INDEX ROWID BATCHED| MSG_QUEUE              |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|* 45 |        INDEX RANGE SCAN                  | MSG_QUEUE_BUFF_IDX     |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|* 46 |       TABLE ACCESS BY INDEX ROWID        | G_DOSSIER              |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |
|* 47 |        INDEX UNIQUE SCAN                 | DOS_REFDOSS            |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 48 |      INDEX RANGE SCAN                    | DOS_REFDOSS_REFLOT_IDX |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |
|  49 |     NESTED LOOPS SEMI                    |                        |      0 |      1 |     6   (0)|      0 |00:00:00.01 |       0 |
|* 50 |      TABLE ACCESS BY INDEX ROWID BATCHED | MSG_QUEUE              |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|* 51 |       INDEX RANGE SCAN                   | MSG_QUEUE_BUFF_IDX     |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|* 52 |      INDEX RANGE SCAN                    | DOS_REFDOSS_REFLOT_IDX |      0 |     92 |     2   (0)|      0 |00:00:00.01 |       0 |
|  53 |     NESTED LOOPS SEMI                    |                        |      1 |      1 |  7003   (1)|      0 |00:00:00.89 |   17036 |
|* 54 |      HASH JOIN                           |                        |      1 |      1 |  6999   (1)|      1 |00:00:00.89 |   17033 |
|  55 |       INDEX FAST FULL SCAN               | DOS_REFDOSS_REFLOT_IDX |      1 |   2033K|  3716   (1)|   2033K|00:00:00.23 |   17030 |
|* 56 |       INDEX RANGE SCAN                   | DOS_REFDOSS_REFLOT_IDX |      1 |      1 |     3   (0)|      1 |00:00:00.01 |       3 |
|* 57 |      TABLE ACCESS BY INDEX ROWID BATCHED | MSG_QUEUE              |      1 |      1 |     4   (0)|      0 |00:00:00.01 |       3 |
|* 58 |       INDEX RANGE SCAN                   | MSG_DOSS               |      1 |      1 |     2   (0)|      0 |00:00:00.01 |       3 |
|* 59 |     TABLE ACCESS BY INDEX ROWID BATCHED  | T_NOTIF                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 60 |      INDEX RANGE SCAN                    | TNOT_MAITRE            |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   3 - filter(((("M"."BUFF" NOT LIKE 'memo_decompte%' AND "M"."BUFF" NOT LIKE 'bundlePayment%' AND "M"."BUFF" NOT LIKE
              'processBundles%' AND "M"."BUFF" NOT LIKE 'pfdgforfi%' AND "M"."BUFF" NOT LIKE 'pfdgforaf%' AND "M"."BUFF" NOT LIKE
              'pfdgcreate%') OR  IS NULL) AND ("M"."BUFF" NOT LIKE 'procLimitConctr%' OR  IS NULL) AND ("M"."BUFF" NOT LIKE 'procLimitConctr%'
              OR  IS NULL) AND ("M"."BUFF" NOT LIKE 'procLimitConctr%' OR  IS NULL) AND ("M"."BUFF" NOT LIKE 'calfidec%' OR  IS NULL) AND
              ("M"."BUFF" NOT LIKE 'safupload%' OR  IS NULL) AND ("M"."BUFF" NOT LIKE 'safstart%' OR  IS NULL) AND (("M"."BUFF" NOT LIKE
              'procConctr%' AND "M"."BUFF" NOT LIKE 'calfidec%') OR  IS NULL) AND ("M"."BUFF" NOT LIKE 'edit%' OR  IS NULL OR  IS NULL)))
   6 - access("D"."REFDOSS"=:QSTRREFDOSSCCC_RD)
   7 - filter(("PRTY">0 AND ("PRTY"<90 OR "PRTY"=99 OR "DT_SIMUL_DT" IS NOT NULL) AND
              NVL("DTLOCK_DT",SYSDATE@!-1000)<SYSDATE@!-.000694444444444444444444444444444444444444))
   8 - access("M"."REFDOSS"=:QSTRREFDOSSCCC_RD)
  10 - filter((("MQ"."PRTY">=1 AND "MQ"."PRTY"<=89) OR "MQ"."PRTY"=99))
  11 - access("MQ"."BUFF" LIKE 'procLimitConctr%')
       filter("MQ"."BUFF" LIKE 'procLimitConctr%')
  12 - access("MQ"."REFDOSS"="LD"."LIMIT_ID" AND "LD"."REFDOSS"=:B1)
  15 - filter((("MQ"."PRTY">=1 AND "MQ"."PRTY"<=89) OR "MQ"."PRTY"=99))
  16 - access("MQ"."BUFF" LIKE 'calculdoss@%')
       filter("MQ"."BUFF" LIKE 'calculdoss@%')
  17 - access("MQ"."REFDOSS"="GD"."REFDOSS")
  18 - access("GC"."LIMIT_ID"=:B1 AND "GD"."REFLOT"="GC"."REFDOSS")
  21 - filter((("MQ"."PRTY">=1 AND "MQ"."PRTY"<=89) OR "MQ"."PRTY"=99))
  22 - access("MQ"."BUFF" LIKE 'calfidec@%')
       filter("MQ"."BUFF" LIKE 'calfidec@%')
  23 - filter("GD"."CATEGDOSS" LIKE 'DECOMPTE%')
  24 - access("MQ"."REFDOSS"="GD"."REFDOSS")
  25 - access("GC"."LIMIT_ID"=:B1 AND "GD"."REFDOSS"="GC"."REFDOSS")
  28 - filter(("Q_IN"."PRTY"=99 AND "Q_IN"."MSGSEQ"<>:B1))
  29 - access("Q_IN"."BUFF" LIKE 'procLimitConctr%')
       filter("Q_IN"."BUFF" LIKE 'procLimitConctr%')
  31 - access("GC_CURR"."LIMIT_ID"=:B1)
  32 - access("GC_IN"."LIMIT_ID"="Q_IN"."REFDOSS" AND "GC_IN"."REFDOSS"="GC_CURR"."REFDOSS")
  34 - filter((("MSG_QUEUE"."PRTY">=1 AND "MSG_QUEUE"."PRTY"<=89) OR "MSG_QUEUE"."PRTY"=99))
  35 - access("MSG_QUEUE"."BUFF" LIKE 'pilote@%')
       filter("MSG_QUEUE"."BUFF" LIKE 'pilote@%')
  36 - filter(("G_DOSSIER"."REFLOT"=:B1 AND "G_DOSSIER"."FG_FRM_INC" IS NULL))
  37 - access("MSG_QUEUE"."REFDOSS"="G_DOSSIER"."REFDOSS")
  39 - filter((("MSG_QUEUE"."PRTY">=1 AND "MSG_QUEUE"."PRTY"<=89) OR "MSG_QUEUE"."PRTY"=99))
  40 - access("MSG_QUEUE"."BUFF" LIKE 'valcess@%')
       filter("MSG_QUEUE"."BUFF" LIKE 'valcess@%')
  41 - access("MSG_QUEUE"."REFDOSS"="G_DOSSIER"."REFDOSS" AND "G_DOSSIER"."REFLOT"=:B1)
  44 - filter((("MSQ"."PRTY">=1 AND "MSQ"."PRTY"<=89) OR "MSQ"."PRTY"=99))
  45 - access("MSQ"."BUFF" LIKE 'pilote@%')
       filter("MSQ"."BUFF" LIKE 'pilote@%')
  46 - filter(("C"."CREATEUR"<>'CTRL22' AND UPPER(NVL("C"."FLAG_ENVOI",'N'))='N' AND "C"."CREATEUR"<>'REQUEST_LIMIT'))
  47 - access("MSQ"."REFDOSS"="C"."REFDOSS")
  48 - access("SC"."REFDOSS"="C"."REFLOT" AND "SC"."REFLOT"=:B1)
  50 - filter((("MSG_QUEUE"."PRTY">=1 AND "MSG_QUEUE"."PRTY"<=89) OR "MSG_QUEUE"."PRTY"=99))
  51 - access("MSG_QUEUE"."BUFF" LIKE 'calculdoss@%')
       filter("MSG_QUEUE"."BUFF" LIKE 'calculdoss@%')
  52 - access("MSG_QUEUE"."REFDOSS"="G_DOSSIER"."REFDOSS" AND "G_DOSSIER"."REFLOT"=:B1)
  54 - access("DC"."REFDOSS"="D"."REFLOT")
  56 - access("D"."REFDOSS"=:B1)
  57 - filter("RC"."BUFF" LIKE 'retrocederContrat%')
  58 - access("RC"."REFDOSS"="DC"."REFLOT")
  59 - filter("REFDOSS"=:B1)
  60 - access("MAITRE"=TO_CHAR(:B1))
*/
/********************************OLD Metrics***************************************/

/********************************New SQL*******************************************/
var QSTRREFDOSSCCC_RD VARCHAR2(32);
exec :QSTRREFDOSSCCC_RD := '0001279351';

SELECT /*+ INDEX(M MSG_DOSS) dynamic_sampling(0) */
       prty,
       buff,
       M.refdoss,
       login,
       TO_CHAR(datetr_dt, 'dd/mm/yyyy hh24:mi:ss'),
       master_reftxt,
       M.createur,
       JobTxt,
       refaux,
       msgseq,
       NVL(loop_count, 0),
       NVL(postpone_count, 0),
       NVL(TO_CHAR(DT_SIMUL_DT, 'dd/mm/yyyy'), 'NO_SIMUL'),
       NVL(D.pieceinit, 'NOPIECEINIT')
  FROM msg_queue M, 
       g_dossier D
 WHERE M.refdoss = :qstrRefdossCCC_RD
   AND M.refdoss = D.refdoss
   AND prty > 0
   AND (prty < 90 OR prty = 99 OR DT_SIMUL_DT IS NOT NULL)
   AND nvl(dtlock_dt, SYSDATE - 1000) < SYSDATE - 1 / (24 * 60)
   AND NOT
        ((M.buff LIKE 'procConctr%' OR M.buff LIKE 'calfidec%') AND EXISTS
         (SELECT 1
            FROM msg_queue, g_dossier
           WHERE msg_queue.refdoss = g_dossier.refdoss
             AND g_dossier.reflot = M.refdoss
             AND msg_queue.buff LIKE 'calculdoss@%'
             AND ((msg_queue.prty BETWEEN 1 AND 89) OR (msg_queue.prty = 99))))
   AND NOT (M.buff LIKE 'procLimitConctr%' AND EXISTS
         (SELECT 1
               FROM msg_queue mq, g_dossier gd, G_CONCENTRATION_LIM_DEC gc
              WHERE mq.refdoss = gd.refdoss
                AND mq.buff LIKE 'calculdoss@%'
                AND ((mq.prty BETWEEN 1 AND 89) OR (mq.prty = 99))
                AND gd.reflot = gc.refdoss
                AND gc.limit_id = M.refdoss))
   AND NOT (M.buff LIKE 'procLimitConctr%' AND EXISTS
         (SELECT 1
               FROM msg_queue mq, g_dossier gd, G_CONCENTRATION_LIM_DEC gc
              WHERE mq.refdoss = gd.refdoss
                AND gd.categdoss LIKE 'DECOMPTE%'
                AND mq.buff LIKE 'calfidec@%'
                AND ((mq.prty BETWEEN 1 AND 89) OR (mq.prty = 99))
                AND gd.refdoss = gc.refdoss
                AND gc.limit_id = M.refdoss))
   AND NOT (M.buff LIKE 'procLimitConctr%' AND EXISTS
         (SELECT 1
               FROM msg_queue               q_in,
                    G_CONCENTRATION_LIM_DEC gc_in,
                    G_CONCENTRATION_LIM_DEC gc_curr
              WHERE q_in.buff LIKE 'procLimitConctr%'
                AND q_in.msgseq <> M.msgseq
                AND q_in.prty = 99
                AND gc_curr.limit_id = M.refdoss
                AND gc_in.limit_id = q_in.refdoss
                AND gc_in.refdoss = gc_curr.refdoss))
   AND NOT ((M.buff LIKE 'memo_decompte%' OR M.buff LIKE 'bundlePayment%' OR
        M.buff LIKE 'processBundles%' OR M.buff LIKE 'pfdgforfi%' OR
        M.buff LIKE 'pfdgforaf%' OR M.buff LIKE 'pfdgcreate%') AND
        EXISTS (SELECT 1
                     FROM msg_queue mq, g_concentration_lim_dec ld
                    WHERE mq.refdoss = ld.limit_id
                      AND mq.buff LIKE 'procLimitConctr%'
                      AND ((mq.prty BETWEEN 1 AND 89) OR (mq.prty = 99))
                      AND ld.refdoss = M.refdoss))
   AND NOT
        (M.buff LIKE 'calfidec%' AND EXISTS
         (SELECT 1
            FROM msg_queue, g_dossier
           WHERE msg_queue.refdoss = g_dossier.refdoss
             AND g_dossier.reflot = M.refdoss
             AND g_dossier.fg_frm_inc is NULL
             AND msg_queue.buff LIKE 'pilote@%'
             AND ((msg_queue.prty = 99) OR (msg_queue.prty BETWEEN 1 AND 89))))
   AND NOT (m.buff LIKE 'edit%' AND EXISTS
         (SELECT
              1
               FROM msg_queue RC, g_dossier DC, g_dossier d
              WHERE RC.buff LIKE 'retrocederContrat%'
                AND RC.refdoss = DC.reflot
                AND DC.refdoss = d.reflot
                AND d.refdoss = m.refdoss) AND EXISTS
         (SELECT 1
               FROM t_notif
              WHERE refdoss = m.refdoss
                AND maitre = to_char(m.msgseq)))
   AND NOT
        (M.buff LIKE 'safupload%' AND EXISTS
         (SELECT 1
            FROM msg_queue, g_dossier
           WHERE msg_queue.refdoss = g_dossier.refdoss
             AND g_dossier.reflot = M.refdoss
             AND msg_queue.buff LIKE 'valcess@%'
             AND ((msg_queue.prty BETWEEN 1 AND 89) OR (msg_queue.prty = 99))))
   AND NOT (M.buff LIKE 'safstart%' AND EXISTS
         (SELECT 1
               FROM MSG_QUEUE MSQ, G_DOSSIER C, G_DOSSIER SC
              WHERE MSQ.REFDOSS = C.REFDOSS
                AND SC.REFDOSS = C.REFLOT
                AND SC.REFLOT = M.REFDOSS
                AND MSQ.BUFF LIKE 'pilote@%'
                AND ((MSQ.PRTY BETWEEN 1 AND 89) OR (MSQ.PRTY = 99))
                AND UPPER(NVL(C.FLAG_ENVOI, 'N')) = 'N'
                AND C.CREATEUR NOT IN ('CTRL22', 'REQUEST_LIMIT')))
 ORDER BY case
            WHEN buff LIKE 'deldos@%' then
             8
            WHEN buff LIKE 'variab%' then
             9
            WHEN buff LIKE 'ecrit%' then
             10
            WHEN buff LIKE 'facture%' then
             10
            WHEN buff LIKE 'edit%' then
             20
            WHEN buff LIKE 'pilote@%' then
             30
            WHEN buff LIKE 'chkcess@%' then
             50
            WHEN buff LIKE 'valcess@%' then
             50
            WHEN buff LIKE 'calfidec@%' then
             60
            WHEN buff LIKE 'calc_nmp@%' then
             60
            WHEN buff LIKE 'limit_changed@%' then
             60
            WHEN buff LIKE 'ProcessLimit@%' then
             60
            WHEN buff LIKE 'FinDec%' then
             60
            WHEN buff LIKE 'procConctr%' then
             70
            WHEN buff LIKE 'procLimitConctr%' then
             70
            WHEN buff LIKE 'processAPDR@%' then
             75
            WHEN buff LIKE 'resDue2Contras%' then
             70
            WHEN buff LIKE 'bundlePayment%' then
             80
            WHEN buff LIKE 'processBundles%' then
             80
            WHEN buff LIKE 'pfdgforfi%' then
             85
            WHEN buff LIKE 'pfdgforaf%' then
             85
            WHEN buff LIKE 'pfdgcreate%' then
             85
            WHEN buff LIKE 'memo_decompte%' then
             90
            WHEN buff LIKE 'memo_decompte_pmtval%' then
             90
            else
             900
          END,
          prty,
          msgseq
   FOR UPDATE OF msgseq SKIP LOCKED;
/********************************New SQL*******************************************/
/********************************New Metrics***************************************/
/*
Plan hash value: 1182841180
-----------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                | Name                   | Starts | E-Rows | A-Rows |   A-Time   | Buffers |
-----------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                         |                        |      1 |        |      0 |00:00:00.01 |       7 |
|   1 |  FOR UPDATE                              |                        |      1 |        |      0 |00:00:00.01 |       7 |
|   2 |   SORT ORDER BY                          |                        |      1 |      1 |      0 |00:00:00.01 |       7 |
|*  3 |    FILTER                                |                        |      1 |        |      0 |00:00:00.01 |       7 |
|   4 |     NESTED LOOPS                         |                        |      1 |      1 |      0 |00:00:00.01 |       7 |
|   5 |      TABLE ACCESS BY INDEX ROWID         | G_DOSSIER              |      1 |      1 |      1 |00:00:00.01 |       4 |
|*  6 |       INDEX UNIQUE SCAN                  | DOS_REFDOSS            |      1 |      1 |      1 |00:00:00.01 |       3 |
|*  7 |      TABLE ACCESS BY INDEX ROWID BATCHED | MSG_QUEUE              |      1 |      1 |      0 |00:00:00.01 |       3 |
|*  8 |       INDEX RANGE SCAN                   | MSG_DOSS               |      1 |      1 |      0 |00:00:00.01 |       3 |
|   9 |     NESTED LOOPS SEMI                    |                        |      0 |      1 |      0 |00:00:00.01 |       0 |
|* 10 |      TABLE ACCESS BY INDEX ROWID BATCHED | MSG_QUEUE              |      0 |      1 |      0 |00:00:00.01 |       0 |
|* 11 |       INDEX RANGE SCAN                   | MSG_QUEUE_BUFF_IDX     |      0 |      1 |      0 |00:00:00.01 |       0 |
|* 12 |      INDEX UNIQUE SCAN                   | AK_KEY_1_G_CONCEN      |      0 |      1 |      0 |00:00:00.01 |       0 |
|  13 |     NESTED LOOPS SEMI                    |                        |      0 |      1 |      0 |00:00:00.01 |       0 |
|  14 |      NESTED LOOPS                        |                        |      0 |      1 |      0 |00:00:00.01 |       0 |
|* 15 |       TABLE ACCESS BY INDEX ROWID BATCHED| MSG_QUEUE              |      0 |      1 |      0 |00:00:00.01 |       0 |
|* 16 |        INDEX RANGE SCAN                  | MSG_QUEUE_BUFF_IDX     |      0 |      1 |      0 |00:00:00.01 |       0 |
|* 17 |       INDEX RANGE SCAN                   | DOS_REFDOSS_REFLOT_IDX |      0 |      1 |      0 |00:00:00.01 |       0 |
|* 18 |      INDEX UNIQUE SCAN                   | AK_KEY_1_G_CONCEN      |      0 |      1 |      0 |00:00:00.01 |       0 |
|  19 |     NESTED LOOPS SEMI                    |                        |      0 |      1 |      0 |00:00:00.01 |       0 |
|  20 |      NESTED LOOPS                        |                        |      0 |      1 |      0 |00:00:00.01 |       0 |
|* 21 |       TABLE ACCESS BY INDEX ROWID BATCHED| MSG_QUEUE              |      0 |      1 |      0 |00:00:00.01 |       0 |
|* 22 |        INDEX RANGE SCAN                  | MSG_QUEUE_BUFF_IDX     |      0 |      1 |      0 |00:00:00.01 |       0 |
|* 23 |       TABLE ACCESS BY INDEX ROWID        | G_DOSSIER              |      0 |      1 |      0 |00:00:00.01 |       0 |
|* 24 |        INDEX UNIQUE SCAN                 | DOS_REFDOSS            |      0 |      1 |      0 |00:00:00.01 |       0 |
|* 25 |      INDEX UNIQUE SCAN                   | AK_KEY_1_G_CONCEN      |      0 |      1 |      0 |00:00:00.01 |       0 |
|  26 |     NESTED LOOPS SEMI                    |                        |      0 |      1 |      0 |00:00:00.01 |       0 |
|  27 |      MERGE JOIN CARTESIAN                |                        |      0 |      1 |      0 |00:00:00.01 |       0 |
|* 28 |       TABLE ACCESS BY INDEX ROWID BATCHED| MSG_QUEUE              |      0 |      1 |      0 |00:00:00.01 |       0 |
|* 29 |        INDEX RANGE SCAN                  | MSG_QUEUE_BUFF_IDX     |      0 |      1 |      0 |00:00:00.01 |       0 |
|  30 |       BUFFER SORT                        |                        |      0 |      1 |      0 |00:00:00.01 |       0 |
|* 31 |        INDEX RANGE SCAN                  | AK_KEY_1_G_CONCEN      |      0 |      1 |      0 |00:00:00.01 |       0 |
|* 32 |      INDEX UNIQUE SCAN                   | AK_KEY_1_G_CONCEN      |      0 |      1 |      0 |00:00:00.01 |       0 |
|  33 |     NESTED LOOPS SEMI                    |                        |      0 |      1 |      0 |00:00:00.01 |       0 |
|* 34 |      TABLE ACCESS BY INDEX ROWID BATCHED | MSG_QUEUE              |      0 |      1 |      0 |00:00:00.01 |       0 |
|* 35 |       INDEX RANGE SCAN                   | MSG_QUEUE_BUFF_IDX     |      0 |      1 |      0 |00:00:00.01 |       0 |
|* 36 |      TABLE ACCESS BY INDEX ROWID         | G_DOSSIER              |      0 |     92 |      0 |00:00:00.01 |       0 |
|* 37 |       INDEX UNIQUE SCAN                  | DOS_REFDOSS            |      0 |      1 |      0 |00:00:00.01 |       0 |
|  38 |     NESTED LOOPS SEMI                    |                        |      0 |      1 |      0 |00:00:00.01 |       0 |
|* 39 |      TABLE ACCESS BY INDEX ROWID BATCHED | MSG_QUEUE              |      0 |      1 |      0 |00:00:00.01 |       0 |
|* 40 |       INDEX RANGE SCAN                   | MSG_QUEUE_BUFF_IDX     |      0 |      1 |      0 |00:00:00.01 |       0 |
|* 41 |      INDEX RANGE SCAN                    | DOS_REFDOSS_REFLOT_IDX |      0 |     92 |      0 |00:00:00.01 |       0 |
|  42 |     NESTED LOOPS SEMI                    |                        |      0 |      1 |      0 |00:00:00.01 |       0 |
|  43 |      NESTED LOOPS                        |                        |      0 |      1 |      0 |00:00:00.01 |       0 |
|* 44 |       TABLE ACCESS BY INDEX ROWID BATCHED| MSG_QUEUE              |      0 |      1 |      0 |00:00:00.01 |       0 |
|* 45 |        INDEX RANGE SCAN                  | MSG_QUEUE_BUFF_IDX     |      0 |      1 |      0 |00:00:00.01 |       0 |
|* 46 |       TABLE ACCESS BY INDEX ROWID        | G_DOSSIER              |      0 |      1 |      0 |00:00:00.01 |       0 |
|* 47 |        INDEX UNIQUE SCAN                 | DOS_REFDOSS            |      0 |      1 |      0 |00:00:00.01 |       0 |
|* 48 |      INDEX RANGE SCAN                    | DOS_REFDOSS_REFLOT_IDX |      0 |      1 |      0 |00:00:00.01 |       0 |
|  49 |     NESTED LOOPS SEMI                    |                        |      0 |      1 |      0 |00:00:00.01 |       0 |
|* 50 |      TABLE ACCESS BY INDEX ROWID BATCHED | MSG_QUEUE              |      0 |      1 |      0 |00:00:00.01 |       0 |
|* 51 |       INDEX RANGE SCAN                   | MSG_QUEUE_BUFF_IDX     |      0 |      1 |      0 |00:00:00.01 |       0 |
|* 52 |      INDEX RANGE SCAN                    | DOS_REFDOSS_REFLOT_IDX |      0 |     92 |      0 |00:00:00.01 |       0 |
|  53 |     NESTED LOOPS                         |                        |      0 |      1 |      0 |00:00:00.01 |       0 |
|  54 |      NESTED LOOPS                        |                        |      0 |      1 |      0 |00:00:00.01 |       0 |
|  55 |       NESTED LOOPS                       |                        |      0 |      1 |      0 |00:00:00.01 |       0 |
|* 56 |        INDEX RANGE SCAN                  | DOS_REFDOSS_REFLOT_IDX |      0 |      1 |      0 |00:00:00.01 |       0 |
|* 57 |        INDEX RANGE SCAN                  | DOS_REFDOSS_REFLOT_IDX |      0 |      1 |      0 |00:00:00.01 |       0 |
|* 58 |       INDEX RANGE SCAN                   | MSG_QUEUE_BUFF_IDX     |      0 |      1 |      0 |00:00:00.01 |       0 |
|* 59 |      TABLE ACCESS BY INDEX ROWID         | MSG_QUEUE              |      0 |      1 |      0 |00:00:00.01 |       0 |
|* 60 |     TABLE ACCESS BY INDEX ROWID BATCHED  | T_NOTIF                |      0 |      1 |      0 |00:00:00.01 |       0 |
|* 61 |      INDEX RANGE SCAN                    | TNOT_MAITRE            |      0 |      1 |      0 |00:00:00.01 |       0 |
-----------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   3 - filter(((("M"."BUFF" NOT LIKE 'memo_decompte%' AND "M"."BUFF" NOT LIKE 'bundlePayment%' AND "M"."BUFF" NOT
              LIKE 'processBundles%' AND "M"."BUFF" NOT LIKE 'pfdgforfi%' AND "M"."BUFF" NOT LIKE 'pfdgforaf%' AND "M"."BUFF" NOT
              LIKE 'pfdgcreate%') OR  IS NULL) AND ("M"."BUFF" NOT LIKE 'procLimitConctr%' OR  IS NULL) AND ("M"."BUFF" NOT LIKE
              'procLimitConctr%' OR  IS NULL) AND ("M"."BUFF" NOT LIKE 'procLimitConctr%' OR  IS NULL) AND ("M"."BUFF" NOT LIKE
              'calfidec%' OR  IS NULL) AND ("M"."BUFF" NOT LIKE 'safupload%' OR  IS NULL) AND ("M"."BUFF" NOT LIKE 'safstart%' OR
              IS NULL) AND (("M"."BUFF" NOT LIKE 'procConctr%' AND "M"."BUFF" NOT LIKE 'calfidec%') OR  IS NULL) AND ("M"."BUFF"
              NOT LIKE 'edit%' OR  IS NULL OR  IS NULL)))
   6 - access("D"."REFDOSS"=:QSTRREFDOSSCCC_RD)
   7 - filter(("PRTY">0 AND ("PRTY"<90 OR "PRTY"=99 OR "DT_SIMUL_DT" IS NOT NULL) AND
              NVL("DTLOCK_DT",SYSDATE@!-1000)<SYSDATE@!-.000694444444444444444444444444444444444444))
   8 - access("M"."REFDOSS"=:QSTRREFDOSSCCC_RD)
  10 - filter((("MQ"."PRTY">=1 AND "MQ"."PRTY"<=89) OR "MQ"."PRTY"=99))
  11 - access("MQ"."BUFF" LIKE 'procLimitConctr%')
       filter("MQ"."BUFF" LIKE 'procLimitConctr%')
  12 - access("MQ"."REFDOSS"="LD"."LIMIT_ID" AND "LD"."REFDOSS"=:B1)
  15 - filter((("MQ"."PRTY">=1 AND "MQ"."PRTY"<=89) OR "MQ"."PRTY"=99))
  16 - access("MQ"."BUFF" LIKE 'calculdoss@%')
       filter("MQ"."BUFF" LIKE 'calculdoss@%')
  17 - access("MQ"."REFDOSS"="GD"."REFDOSS")
  18 - access("GC"."LIMIT_ID"=:B1 AND "GD"."REFLOT"="GC"."REFDOSS")
  21 - filter((("MQ"."PRTY">=1 AND "MQ"."PRTY"<=89) OR "MQ"."PRTY"=99))
  22 - access("MQ"."BUFF" LIKE 'calfidec@%')
       filter("MQ"."BUFF" LIKE 'calfidec@%')
  23 - filter("GD"."CATEGDOSS" LIKE 'DECOMPTE%')
  24 - access("MQ"."REFDOSS"="GD"."REFDOSS")
  25 - access("GC"."LIMIT_ID"=:B1 AND "GD"."REFDOSS"="GC"."REFDOSS")
  28 - filter(("Q_IN"."PRTY"=99 AND "Q_IN"."MSGSEQ"<>:B1))
  29 - access("Q_IN"."BUFF" LIKE 'procLimitConctr%')
       filter("Q_IN"."BUFF" LIKE 'procLimitConctr%')
  31 - access("GC_CURR"."LIMIT_ID"=:B1)
  32 - access("GC_IN"."LIMIT_ID"="Q_IN"."REFDOSS" AND "GC_IN"."REFDOSS"="GC_CURR"."REFDOSS")
  34 - filter((("MSG_QUEUE"."PRTY">=1 AND "MSG_QUEUE"."PRTY"<=89) OR "MSG_QUEUE"."PRTY"=99))
  35 - access("MSG_QUEUE"."BUFF" LIKE 'pilote@%')
       filter("MSG_QUEUE"."BUFF" LIKE 'pilote@%')
  36 - filter(("G_DOSSIER"."REFLOT"=:B1 AND "G_DOSSIER"."FG_FRM_INC" IS NULL))
  37 - access("MSG_QUEUE"."REFDOSS"="G_DOSSIER"."REFDOSS")
  39 - filter((("MSG_QUEUE"."PRTY">=1 AND "MSG_QUEUE"."PRTY"<=89) OR "MSG_QUEUE"."PRTY"=99))
  40 - access("MSG_QUEUE"."BUFF" LIKE 'valcess@%')
       filter("MSG_QUEUE"."BUFF" LIKE 'valcess@%')
  41 - access("MSG_QUEUE"."REFDOSS"="G_DOSSIER"."REFDOSS" AND "G_DOSSIER"."REFLOT"=:B1)
  44 - filter((("MSQ"."PRTY">=1 AND "MSQ"."PRTY"<=89) OR "MSQ"."PRTY"=99))
  45 - access("MSQ"."BUFF" LIKE 'pilote@%')
       filter("MSQ"."BUFF" LIKE 'pilote@%')
  46 - filter(("C"."CREATEUR"<>'CTRL22' AND UPPER(NVL("C"."FLAG_ENVOI",'N'))='N' AND
              "C"."CREATEUR"<>'REQUEST_LIMIT'))
  47 - access("MSQ"."REFDOSS"="C"."REFDOSS")
  48 - access("SC"."REFDOSS"="C"."REFLOT" AND "SC"."REFLOT"=:B1)
  50 - filter((("MSG_QUEUE"."PRTY">=1 AND "MSG_QUEUE"."PRTY"<=89) OR "MSG_QUEUE"."PRTY"=99))
  51 - access("MSG_QUEUE"."BUFF" LIKE 'calculdoss@%')
       filter("MSG_QUEUE"."BUFF" LIKE 'calculdoss@%')
  52 - access("MSG_QUEUE"."REFDOSS"="G_DOSSIER"."REFDOSS" AND "G_DOSSIER"."REFLOT"=:B1)
  56 - access("D"."REFDOSS"=:B1)
  57 - access("DC"."REFDOSS"="D"."REFLOT")
  58 - access("RC"."BUFF" LIKE 'retrocederContrat%')
       filter("RC"."BUFF" LIKE 'retrocederContrat%')
  59 - filter("RC"."REFDOSS"="DC"."REFLOT")
  60 - filter("REFDOSS"=:B1)
  61 - access("MAITRE"=TO_CHAR(:B1))
*/
/********************************New Metrics***************************************/

/********************************Index statistics**********************************/

/********************************Other SQLs****************************************/          
/*

*/ 
/********************************Other SQLs****************************************/              
