/********************************************************************************
*********       E-mail subject: LOCAMDEV-20560, additional similar in LOCAMDEV-20560
*********             Instance: BIRD
*********          Description: 
Problem:
Slowness in std_imx_bk_iban on BIRD.

Analysis:
From the analyze of std_imx_bk_iban on BIRD, the TOP SQL was 2tyf3kjagsd6h and it was responsible for 92% of the time.
The problem in this SQL is that there is two datasets that are not joined and Oracle makes MERGE JOIN CARTESIAN which means that joins every row with every row.
The solution that we can propose her is to make one set from tables g_individu bu and t_intervenants t_bu and then second set with all other tables as you can see in the 
New SQL section below.

Suggestion:
If the proposed variant of the query in the New SQL section is functional correct, please change the SQL as it is shown in the New SQL section below.

*********               SQL_ID: 2tyf3kjagsd6h
*********      Program/Package: std_imx_bk_iban 
*********              Request: Loua Latrech 
*********               Author: Dimitar Dimitrov
********* Received e-mail date: 01/03/2024
*********      Resolution date: 05/03/2024
*********  Trace old file here: \\epox\specifs\performance\tmp\
*********  Trace new file here:
***********************************************************************************/

/********************************OLD SQL*******************************************/

select distinct bu.nom,
                decode(ba.moralphy, 'P', ba.prenom, 'M', ba.RAISSOC1),
                decode(ba.moralphy, 'P', NULL, ba.siret),
                ba.refindividu,
                fp.refdoss,
                dm.codebic,
                dm.numiban
  from g_individu      bu,
       t_intervenants  t_bu,
       g_individu      ba,
       t_intervenants  t_ba,
       g_dossier       fp,
       g_individu      bq,
       g_domiciliation dm
 where bq.refindividu = dm.refindivbq
   and dm.refindividu = ba.refindividu
   and bq.typautre = 'B'
   and ba.refindividu = t_ba.refindividu
   and t_ba.refdoss = fp.refdoss
   and fp.reffactor = t_bu.refindividu
   and t_bu.refindividu = bu.refindividu
   and t_bu.reftype = 'CL'
   and NVL(dm.etat, 'X') = 'V'
   and bu.refindividu = 'INT00000'
   and bq.codbanque = '30004'
   and bq.codguichet = '00003'
 ORDER BY 1;
/********************************OLD SQL*******************************************/
/********************************OLD Metrics***************************************/
/*
MODULE                           SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
std_imx_bk_iban                                                   37      11729 ON CPU               2024/03/01 16:48:45  2024/03/01 16:57:25         476                67480 +000000000 00:08:40.027 73%
iMX BE                                                                          db file sequential r 2024/03/01 16:49:34  2024/03/01 16:57:42          36                   25 +000000000 00:08:08.027 6%
                                                        0       1139      32812 log file parallel wr 2024/03/01 16:48:17  2024/03/01 16:57:28          31                      +000000000 00:09:11.029 5%
std_imx_bk_iban                                         0         37      11729 log file sync        2024/03/01 16:56:34  2024/03/01 16:57:28          27                      +000000000 00:00:54.007 4%
               


MODULE                           SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
std_imx_bk_iban                                                   37      11729 ON CPU               2024/03/01 16:48:45  2024/03/01 16:57:25         476                67480 +000000000 00:08:40.027 94%
std_imx_bk_iban                                         0         37      11729 log file sync        2024/03/01 16:56:34  2024/03/01 16:57:28          27                      +000000000 00:00:54.007 5%
std_imx_bk_iban                                                   37      11729 db file sequential r 2024/03/01 16:49:24  2024/03/01 16:57:26           5                 3409 +000000000 00:08:02.027 1%


MODULE                           SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
std_imx_bk_iban                  2tyf3kjagsd6h 3124697812         37      11729                      2024/03/01 16:48:45  2024/03/01 16:56:32         468                    1 +000000000 00:07:47.020 92%
std_imx_bk_iban                                         0         37      11729                      2024/03/01 16:56:33  2024/03/01 16:57:28          31                      +000000000 00:00:55.007 6%
std_imx_bk_iban                  41cx2navkn7np          0         37      11729                      2024/03/01 16:56:41  2024/03/01 16:57:26           3                 2808 +000000000 00:00:45.003 1%
std_imx_bk_iban                  71rdzj75v56qh 1351991909         37      11729 ON CPU               2024/03/01 16:57:10  2024/03/01 16:57:13           2                    1 +000000000 00:00:03.002 0%
std_imx_bk_iban                  6x6dat7rtqd21          0         37      11729 ON CPU               2024/03/01 16:56:56  2024/03/01 16:56:56           1                    1 +000000000 00:00:00.000 0%
std_imx_bk_iban                  4h0j0bg880ga4 2569075046         37      11729 ON CPU               2024/03/01 16:57:25  2024/03/01 16:57:25           1                      +000000000 00:00:00.000 0%
std_imx_bk_iban                  b50ffh5amabs1          0         37      11729 ON CPU               2024/03/01 16:56:35  2024/03/01 16:56:35           1                      +000000000 00:00:00.000 0%
std_imx_bk_iban                  43ughqv49hw1r  644658511         37      11729 ON CPU               2024/03/01 16:56:49  2024/03/01 16:56:49           1                    1 +000000000 00:00:00.000 0%

INSTANCE_NUMBER SQL_ID            ELAPSED MAX_WAIT_ON     PC_OF  WAIT_TIME            GETS      READS       ROWS  ELAP/EXEC       GETS/EXEC READS/EXEC  ROWS/EXEC       EXEC PLAN_HASH_VALUE
--------------- ------------- ----------- --------------- ----- ---------- --------------- ---------- ---------- ---------- --------------- ---------- ---------- ---------- ---------------
              1 2tyf3kjagsd6h         468 CPU             99%   467.720262          130707       1317       7491     467.93          130707       1317       7491          1      3124697812

SQL_ID        SQL_PLAN_HASH_VALUE SQL_PLAN_LINE_ID SQL_PLAN_OPERATION             SQL_PLAN_OPTIONS                   ACTIVE
------------- ------------------- ---------------- ------------------------------ ------------------------------ ----------
2tyf3kjagsd6h          3124697812                1 HASH                           UNIQUE                                433
2tyf3kjagsd6h          3124697812               20 BUFFER                         SORT                                   30
2tyf3kjagsd6h          3124697812               17 INDEX                          RANGE SCAN                              3
2tyf3kjagsd6h          3124697812               19 TABLE ACCESS                   BY INDEX ROWID                          1
2tyf3kjagsd6h          3124697812               18 INDEX                          UNIQUE SCAN                             1


Plan hash value: 3124697812
-----------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                   | Name            | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  |
-----------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                            |                 |      1 |        |     8 (100)|      0 |00:00:00.01 |       0 |      0 |
|   1 |  HASH UNIQUE                                |                 |      1 |      1 |     8  (13)|      0 |00:00:00.01 |       0 |      0 |
|   2 |   MERGE JOIN CARTESIAN                      |                 |      1 |      1 |     7   (0)|    239M|00:00:39.01 |   13230 |    122 |
|   3 |    NESTED LOOPS                             |                 |      1 |      1 |     6   (0)|  12081 |00:00:00.35 |   13128 |     78 |
|   4 |     NESTED LOOPS                            |                 |      1 |      1 |     6   (0)|  12090 |00:00:00.22 |     523 |     78 |
|   5 |      NESTED LOOPS                           |                 |      1 |      1 |     5   (0)|  12090 |00:00:00.15 |     150 |     78 |
|   6 |       NESTED LOOPS                          |                 |      1 |      1 |     4   (0)|     10 |00:00:00.02 |      50 |      4 |
|   7 |        NESTED LOOPS                         |                 |      1 |      1 |     3   (0)|     10 |00:00:00.02 |      19 |      2 |
|   8 |         NESTED LOOPS                        |                 |      1 |      1 |     2   (0)|      1 |00:00:00.01 |       6 |      1 |
|   9 |          TABLE ACCESS BY INDEX ROWID        | G_INDIVIDU      |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       4 |      0 |
|* 10 |           INDEX UNIQUE SCAN                 | IND_REFINDIV    |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |      0 |
|* 11 |          TABLE ACCESS BY INDEX ROWID BATCHED| G_INDIVIDU      |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       2 |      1 |
|* 12 |           INDEX RANGE SCAN                  | IND_GUICHET     |      1 |      3 |     1   (0)|      1 |00:00:00.01 |       1 |      1 |
|* 13 |         TABLE ACCESS BY INDEX ROWID BATCHED | G_DOMICILIATION |      1 |      2 |     1   (0)|     10 |00:00:00.01 |      13 |      1 |
|* 14 |          INDEX RANGE SCAN                   | DOM_REFBQCPT    |      1 |     12 |     1   (0)|     12 |00:00:00.01 |       2 |      1 |
|  15 |        TABLE ACCESS BY INDEX ROWID          | G_INDIVIDU      |     10 |      1 |     1   (0)|     10 |00:00:00.01 |      31 |      2 |
|* 16 |         INDEX UNIQUE SCAN                   | IND_REFINDIV    |     10 |      1 |     1   (0)|     10 |00:00:00.01 |      22 |      0 |
|* 17 |       INDEX RANGE SCAN                      | INT_INDIV       |     10 |      1 |     1   (0)|  12090 |00:00:00.13 |     100 |     74 |
|* 18 |      INDEX UNIQUE SCAN                      | DOS_REFDOSS     |  12090 |      1 |     1   (0)|  12090 |00:00:00.05 |     373 |      0 |
|* 19 |     TABLE ACCESS BY INDEX ROWID             | G_DOSSIER       |  12090 |      1 |     1   (0)|  12081 |00:00:00.12 |   12605 |      0 |
|  20 |    BUFFER SORT                              |                 |  12081 |    269 |     6   (0)|    239M|00:00:15.44 |     102 |     44 |
|* 21 |     INDEX RANGE SCAN                        | INT_INDIV       |      1 |    269 |     1   (0)|  19858 |00:00:00.04 |     102 |     44 |
-----------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
  10 - access("BU"."REFINDIVIDU"='INT00000')
  11 - filter(("BQ"."CODBANQUE"='30004' AND "BQ"."TYPAUTRE"='B'))
  12 - access("BQ"."CODGUICHET"='00003')
  13 - filter(NVL("DM"."ETAT",'X')='V')
  14 - access("BQ"."REFINDIVIDU"="DM"."REFINDIVBQ")
       filter("DM"."REFINDIVBQ" IS NOT NULL)
  16 - access("DM"."REFINDIVIDU"="BA"."REFINDIVIDU")
  17 - access("BA"."REFINDIVIDU"="T_BA"."REFINDIVIDU")
  18 - access("T_BA"."REFDOSS"="FP"."REFDOSS")
  19 - filter("FP"."REFFACTOR"='INT00000')
  21 - access("T_BU"."REFINDIVIDU"='INT00000' AND "T_BU"."REFTYPE"='CL')
*/
/********************************OLD Metrics***************************************/

/********************************New SQL*******************************************/

select distinct bu.nom,
                decode(ba.moralphy, 'P', ba.prenom, 'M', ba.RAISSOC1),
                decode(ba.moralphy, 'P', NULL, ba.siret),
                ba.refindividu,
                fp.refdoss,
                dm.codebic,
                dm.numiban
  from ( select bu.nom, 
                t_bu.refindividu
           from g_individu      bu,
                t_intervenants  t_bu
          where bu.refindividu = 'INT00000'
            and t_bu.refindividu = bu.refindividu
            and t_bu.reftype = 'CL'
            and rownum = 1 ) bu,      
       g_individu      ba,
       t_intervenants  t_ba,
       g_dossier       fp,
       g_individu      bq,
       g_domiciliation dm
 where bq.refindividu = dm.refindivbq
   and dm.refindividu = ba.refindividu
   and bq.typautre = 'B'
   and ba.refindividu = t_ba.refindividu
   and t_ba.refdoss = fp.refdoss
   and fp.reffactor = bu.refindividu
   and NVL(dm.etat, 'X') = 'V'
   and bq.codbanque = '30004'
   and bq.codguichet = '00003'
 ORDER BY 1;
/********************************New SQL*******************************************/
/********************************New Metrics***************************************/
/*
Plan hash value: 3227273689
----------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                  | Name            | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Writes |
----------------------------------------------------------------------------------------------------------------------------------------------
|   0 | CREATE TABLE STATEMENT                     |                 |      1 |        |     9 (100)|      0 |00:00:00.46 |   19253 |    134 |
|   1 |  LOAD AS SELECT                            | TEST_DD         |      1 |        |            |      0 |00:00:00.46 |   19253 |    134 |
|   2 |   SORT UNIQUE                              |                 |      1 |      1 |     8  (13)|   7491 |00:00:00.25 |   18597 |      0 |
|   3 |    NESTED LOOPS SEMI                       |                 |      1 |      1 |     7   (0)|    119K|00:00:00.09 |   18597 |      0 |
|   4 |     NESTED LOOPS                           |                 |      1 |      1 |     6   (0)|    119K|00:00:00.04 |     871 |      0 |
|   5 |      NESTED LOOPS                          |                 |      1 |      1 |     5   (0)|     18 |00:00:00.01 |      85 |      0 |
|   6 |       NESTED LOOPS                         |                 |      1 |      1 |     4   (0)|     18 |00:00:00.01 |      30 |      0 |
|   7 |        NESTED LOOPS                        |                 |      1 |      1 |     3   (0)|      1 |00:00:00.01 |       9 |      0 |
|   8 |         VIEW                               |                 |      1 |      1 |     2   (0)|      1 |00:00:00.01 |       7 |      0 |
|*  9 |          COUNT STOPKEY                     |                 |      1 |        |            |      1 |00:00:00.01 |       7 |      0 |
|  10 |           NESTED LOOPS                     |                 |      1 |    254 |     2   (0)|      1 |00:00:00.01 |       7 |      0 |
|  11 |            TABLE ACCESS BY INDEX ROWID     | G_INDIVIDU      |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       4 |      0 |
|* 12 |             INDEX UNIQUE SCAN              | IND_REFINDIV    |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |      0 |
|* 13 |            INDEX RANGE SCAN                | INT_INDIV       |      1 |    254 |     1   (0)|      1 |00:00:00.01 |       3 |      0 |
|* 14 |         TABLE ACCESS BY INDEX ROWID BATCHED| G_INDIVIDU      |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       2 |      0 |
|* 15 |          INDEX RANGE SCAN                  | IND_GUICHET     |      1 |      3 |     1   (0)|      1 |00:00:00.01 |       1 |      0 |
|* 16 |        TABLE ACCESS BY INDEX ROWID BATCHED | G_DOMICILIATION |      1 |      2 |     1   (0)|     18 |00:00:00.01 |      21 |      0 |
|* 17 |         INDEX RANGE SCAN                   | DOM_REFBQCPT    |      1 |     12 |     1   (0)|     21 |00:00:00.01 |       2 |      0 |
|  18 |       TABLE ACCESS BY INDEX ROWID          | G_INDIVIDU      |     18 |      1 |     1   (0)|     18 |00:00:00.01 |      55 |      0 |
|* 19 |        INDEX UNIQUE SCAN                   | IND_REFINDIV    |     18 |      1 |     1   (0)|     18 |00:00:00.01 |      38 |      0 |
|* 20 |      INDEX RANGE SCAN                      | INT_INDIV       |     18 |      1 |     1   (0)|    119K|00:00:00.02 |     786 |      0 |
|* 21 |     TABLE ACCESS BY INDEX ROWID            | G_DOSSIER       |   9048 |  21767 |     1   (0)|   8896 |00:00:00.03 |   17726 |      0 |
|* 22 |      INDEX UNIQUE SCAN                     | DOS_REFDOSS     |   9048 |      1 |     1   (0)|   9048 |00:00:00.01 |    2083 |      0 |
----------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   9 - filter(ROWNUM=1)
  12 - access("BU"."REFINDIVIDU"='INT00000')
  13 - access("T_BU"."REFINDIVIDU"='INT00000' AND "T_BU"."REFTYPE"='CL')
  14 - filter(("BQ"."CODBANQUE"='30004' AND "BQ"."TYPAUTRE"='B'))
  15 - access("BQ"."CODGUICHET"='00003')
  16 - filter(NVL("DM"."ETAT",'X')='V')
  17 - access("BQ"."REFINDIVIDU"="DM"."REFINDIVBQ")
       filter("DM"."REFINDIVBQ" IS NOT NULL)
  19 - access("DM"."REFINDIVIDU"="BA"."REFINDIVIDU")
  20 - access("BA"."REFINDIVIDU"="T_BA"."REFINDIVIDU")
  21 - filter("FP"."REFFACTOR"="BU"."REFINDIVIDU")
  22 - access("T_BA"."REFDOSS"="FP"."REFDOSS")
*/
/********************************New Metrics***************************************/

/********************************Index statistics**********************************/

/********************************Other SQLs****************************************/          
/*

*/ 
/********************************Other SQLs****************************************/              
