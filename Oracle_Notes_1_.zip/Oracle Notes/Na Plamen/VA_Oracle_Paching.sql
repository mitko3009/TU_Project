Има 3 вида oracle home във VA, затова ако инсталираш, внимавай да не объркаш параметъра. В тяхното уики примерът е само със SE2.
EE_19_17_0_2210
EE_NOOPTS_19_17_0_2210
SE2_19_17_0_2210
 

find / -type f -name alert_*.log

ps -ef |grep pmon
cd /oracle/RO_HOMES

2149APCBISTE02

###INACTIVE
set linesize 400
col PROGRAM for a45
col MACHINE for a30
col username for a18
col STATUS for a45
select inst_id,SID,SERIAL#,STATUS,USERNAME,MACHINE,PROGRAM,to_char(LOGON_TIME, 'YYYY/MM/DD HH24:MI:SS'),LOCKWAIT from gv$session where STATUS='INACTIVE' order by LOGON_TIME
/

inactive 111 sessions

###Invalid objects
set lines 200 pages 999
col "obj" format a40
select owner || '.' || object_name "obj",  
object_type, created
from dba_objects
where status = 'INVALID'
/

4 Invalid objects

@?/rdbms/admin/utlrp.sql



select status comp_name, status from dba_registry;

select description, action, STATUS from dba_registry_sqlpatch;

------ RO-Home installieren als ROOT---!!!!!:
curl -s http://2217dba03/dbadmin/dbsource/oracle/golden_image/installROOH.sh | sh -s -- -i SE2_19_18_0_2301


------ Patching als ORACLE:
curl -s http://2217dba03/dbadmin/dbsource/oracle/golden_image/patch_ROOH.sh  | sh -s -- -s LMSTST -h /oracle/RO_HOMES/SE2_19_16_0_2207


nohup curl -s http://2217dba03/dbadmin/dbsource/oracle/golden_image/patch_ROOH.sh  | sh -s -- -s LMSTST -h /oracle/RO_HOMES/SE2_19_18_0_2301 &

nohup curl -s http://2217dba03/dbadmin/dbsource/oracle/golden_image/patch_ROOH.sh  | sh -s -- -s GBD20DB -h /oracle/RO_HOMES/SE2_19_18_0_2301 &
nohup curl -s http://2217dba03/dbadmin/dbsource/oracle/golden_image/patch_ROOH.sh  | sh -s -- -s GBD20DBT -h /oracle/RO_HOMES/SE2_19_18_0_2301 &

--- Listener wo läuft als ROOT:
ps -ef |grep tns

--- Listener Home ändern als ROOT:
systemctl edit oracle-rdbms
контрол и Х и шифт и Y enter

--- SID setzen als ORACLE:
sid ZFPT19 als BEISPIEL (lokale SID verwenden)


--- Danach Listener im neuen Home starten als ORACLE:

lsnrctl status; ps -ef | grep [t]nsl; lsnrctl stop; lsnrctl start; for q in $(ps -ef | awk -F_ '$2=="pmon"{print $3}'); do (sid $q; echo "alter system register;" | sqlplus -l -s / as sysdba) & done; wait; lsnrctl status; ps -ef | grep [t]nsl
/


lsnrctl status; ps -ef | grep [t]nsl; lsnrctl stop LISTENER; lsnrctl start LISTENER; for q in $(ps -ef | awk -F_ '$2=="pmon"{print $3}'); do (sid $q; echo "alter system register;" | sqlplus -l -s / as sysdba) & done; wait; lsnrctl status; ps -ef | grep [t]nsl
/

lsnrctl status; ps -ef | grep [t]nsl; lsnrctl stop EXTPROC; lsnrctl start EXTPROC; for q in $(ps -ef | awk -F_ '$2=="pmon"{print $3}'); do (sid $q; echo "alter system register;" | sqlplus -l -s / as sysdba) & done; wait; lsnrctl status; ps -ef | grep [t]nsl
/

systemctl stop oracle-rdbms
systemctl start oracle-rdbms


set lines 300
select PATCH_ID, ACTION, STATUS, ACTION_TIME, DESCRIPTION from DBA_REGISTRY_SQLPATCH;


select value from v$diag_info where NAME='Diag Trace';
view /oracle/diag/rdbms/bd5832r2/BD5832R2/trace/alert_BD5832R2.log

grep -B2 ORA-00800 /oracle/diag/rdbms/bdzlvr2/BDZLVR2/trace/alert_BDZLVR2.log| more


/oracle/RO_HOMES/SE2_19_16_0_2207
shutdown immediate
startup

### UPTIME
select name, database_role, open_mode from v$database;


set linesize 300
col uptime for a24
col status for a6
col db_name for a10
col hosted_on for a15
col current_time for a22
col database_started for a22
col logins for a7
select instance_name as DATABASE,host_name as HOSTED_ON,status,logins,to_char(startup_time, 'MON/DD/YYYY hh24:mi:ss') as DATABASE_STARTED,to_char(sysdate, 'MON/DD/YYYY hh24:mm:ss') as CURRENT_TIME,floor(sysdate - startup_time) || 'd / ' ||trunc( 24*((sysdate-startup_time) - trunc(sysdate-startup_time))) || 'h / ' ||mod(trunc(1440*((sysdate-startup_time) - trunc(sysdate-startup_time))), 60) ||'m / ' ||mod(trunc(86400*((sysdate-startup_time) - trunc(sysdate-startup_time))), 60) ||'s' as UPTIME from sys.gv$instance; 
/

SELECT DATABASE_ROLE, DB_UNIQUE_NAME INSTANCE, OPEN_MODE, PROTECTION_MODE, PROTECTION_LEVEL, SWITCHOVER_STATUS FROM V$DATABASE; 
select comp_name, version, status from dba_registry;

ctrl :q!   -exit from vieu

--- Delete old Oracle HOMES:-- as ROOT
curl -s http://2217dba03/dbadmin/dbsource/oracle/golden_image/remove_OH.sh | sh -s -- -h /oracle/RO_HOMES/SE2_19_16_0_2207

set lines 1000
select action, status, action_time, description
from dba_registry_sqlpatch
order by action_time desc;


[root@lv9bde ~]# curl -s http://2217dba03/dbadmin/dbsource/oracle/golden_image/installROOH.sh | sh -s -- -i SE2_19_18_0_2301
orauser : oracle
orabase : /oracle
oraimage: SE2_19_18_0_2301
golden image http://2217dba03/GI/Linux.x86_64/SE2_19_18_0_2301.tgz not found.




[10:06 AM] Mitsov, Deyan
su - oracle

[10:06 AM] Mitsov, Deyan
sid <bazata>

[10:06 AM] Mitsov, Deyan
adrci

[10:06 AM] Mitsov, Deyan
show homes

[10:08 AM] Mitsov, Deyan
set homepath diag/tnslsnr/2236asf3bde/listener

[10:08 AM] Mitsov, Deyan
PURGE -age 0 -type ALERT

[10:08 AM] Mitsov, Deyan
PURGE -age 0 -type INCIDENT

[10:08 AM] Mitsov, Deyan
set homepath diag/rdbms/d20orm/D20ORM                         /oracle/diag/rdbms/d20orm/D20ORM

[10:08 AM] Mitsov, Deyan
PURGE -age 0 -type ALERT

[10:08 AM] Mitsov, Deyan
PURGE -age 0 -type INCIDENT

SQL> @$ORACLE_HOME/rdbms/admin/dbmsrman.sql
SQL> @$ORACLE_HOME/rdbms/admin/dbmsbkrs.sql
SQL> @$ORACLE_HOME/rdbms/admin/prvtrmns.plb
SQL> @$ORACLE_HOME/rdbms/admin/prvtbkrs.plb

[10:08 AM] Mitsov, Deyan
quit

[10:09 AM] Mitsov, Deyan
du -sh /oracle/diag/*









за VA, след дб рестарт особено, много често изскача ORA-00800: soft external error, arguments: [Set Priority Failed], [VKTM]

след пачинг изчакайте няколко минути, и проверявайте за тая грешка. засега Workaround e


[root ~]# echo 950000 > /sys/fs/cgroup/cpu,cpuacct/user.slice/cpu.rt_runtime_us

и после рестарт на базата


grep -B5 ORA-00800 alert_BDZLVR2.log| less






