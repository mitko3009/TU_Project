/********************************************************************************
*********       E-mail subject: KBCCFWEB-2186
*********             Instance: ACC1
*********          Description: 
Problem:
Slow query was provided from KBC ACC1.

Analysis:
From the analyze we found that the main problem in this with the access in v_pmtsaf_declared. Instead of accessing table T_ECRDOS 
through index TECR_REFELEM it was accessing it throuth index IDX_FFSI_T_ECRDOS. To make Oracle use the optimal way to access the data, we took out the result from the view in a WITH clause and then joined the with clause with the other tables.
By this way, using hints in the with clause, we pointed the path though which we want to acess the data.
Also, I can't see where table v_tdomaine d is joined to the other tables, so you can pay attention to it.

Suggestion:
Please change the SQL as it is shown in the New SQL section below.

*********               SQL_ID: cnr0p1bkw7a6m
*********      Program/Package: 
*********              Request: Petar Gichev 
*********               Author: Dimitar Dimitrov
********* Received e-mail date: 08/04/2024
*********      Resolution date: 09/04/2024
*********  Trace old file here: \\epox\specifs\performance\tmp\
*********  Trace new file here:
***********************************************************************************/

/********************************OLD SQL*******************************************/

VAR B1 VARCHAR2(32);
EXEC :B1 := '1506250354';
VAR B2 VARCHAR2(32);
EXEC :B2 := 'AN';
VAR B3 NUMBER;
EXEC :B3 := 2001;
VAR B4 NUMBER;
EXEC :B4 := 1;


SELECT *
  FROM (SELECT /*+ first_rows(:pageSize)*/
         foo.*, ROWNUM rnum
          FROM (SELECT v.refencaiss AS refEncaiss,
                       v.rec_grp_pmtsaf AS groupPmtSaf,
                       e.encodeur AS groupCreAdj,
                       nvl2(v.dtmarque_dt, 'true', 'false') AS selected,
                       v.typencaiss AS typeMvt,
                       v.tp AS tp,
                       v.pmt_dt AS datePmt,
                       (CASE
                         WHEN (d.valeur_trad IS NOT NULL) THEN
                          d.valeur_trad
                         WHEN v.typencaiss IN
                              ('e_saencaiss', 'exchange_diff_saf') AND
                              v.tp = 'E' THEN
                          'PD'
                         WHEN v.typencaiss IN
                              ('e_saencaiss', 'exchange_diff_saf') AND
                              v.tp = 'A' THEN
                          'PD_ANN'
                         WHEN (v.typencaiss = 'ptf_reconcil_saf' AND
                              e.libelle = 'De-allocated Payments') THEN
                          'DEALL_PMT'
                         WHEN (v.typencaiss = 'ptf_reconcil_saf' AND
                              e.libelle = 'Solde de Ptf suite Reconcil') THEN
                          'SOLDE_PTF'
                       END) AS portfolioPaymentType,
                       v.refdoss AS compteCaseReference,
                       v.MONTANT_DCMP AS portfolioPaymentAmount,
                       (SELECT i.nom
                          FROM t_intervenants t, g_individu i
                         WHERE t.refdoss = e.refdoss
                           AND t.reftype = 'DB'
                           AND t.refindividu = i.refindividu) AS dbName,
                       v.DTMARQUE_DT AS portfolioReconcilationDate,
                       e.dtmarque_dt AS dtmarque
                  FROM v_pmtsaf_declared v, 
                       g_encaissement e,
                       v_tdomaine d
                 WHERE 1 = 1
                   AND v.refdoss_dcmp = :B1
                   AND v.tp IN ('E', 'A')
                   AND e.refencaiss(+) = v.refencaiss
                   AND d.type(+) = 'MISC_TRANSLATIONS'
                   AND NVL(d.langue(+), 'FR') = :B2
                   AND d.abrev(+) = (CASE
                         WHEN v.typencaiss IN
                              ('e_saencaiss', 'exchange_diff_saf') AND
                              v.tp = 'E' THEN
                          'PD'
                         WHEN v.typencaiss IN
                              ('e_saencaiss', 'exchange_diff_saf') AND
                              v.tp = 'A' THEN
                          'PD_ANN'
                         WHEN (v.typencaiss = 'ptf_reconcil_saf' AND
                              e.libelle = 'De-allocated Payments') THEN
                          'DEALL_PMT'
                         WHEN (v.typencaiss = 'ptf_reconcil_saf' AND
                              e.libelle = 'Solde de Ptf suite Reconcil') THEN
                          'SOLDE_PTF'
                       END)
                   AND (v.dtmarque_dt IS NULL AND v.rec_grp_pmtsaf = 'NP')
                UNION
                SELECT v.refencaiss AS refEncaiss,
                       v.rec_grp_pmtsaf AS groupPmtSaf,
                       NULL AS groupCreAdj,
                       nvl2(v.dtmarque_dt, 'true', 'false') AS selected,
                       v.typencaiss AS typeMvt,
                       v.tp AS tp,
                       v.pmt_dt AS datePmt,
                       (CASE
                         WHEN (d.valeur_trad IS NOT NULL) THEN
                          d.valeur_trad
                         WHEN (v.tp = 'F' AND f.type = 'SAF CN COMP') THEN
                          'SAFCNCOMP'
                         WHEN (v.tp = 'F' AND f.type = 'SAF_NMP_CANCEL') THEN
                          'SAFNMPCANCEL'
                         WHEN (v.tp = 'F' AND
                              f.type = 'NON MATCHED PAYMENT ELEMENTS') THEN
                          'EPNL'
                         WHEN (v.tp = 'F' AND
                              f.type = 'POSITIVE LTL DECLARED PAYMENTS') THEN
                          'PDPL'
                         WHEN (v.tp = 'F' AND
                              f.type =
                              'ANNULATION DAVOIRS PAR DES REGLEMENTS') THEN
                          'AAVR'
                         WHEN (v.tp = 'F' AND
                              f.type = 'OPERATION DIVERSE CREDITRICE') THEN
                          'ODC'
                         WHEN (v.tp = 'C' AND f.type = 'SAF CN COMP') THEN
                          'ANN_SAF'
                         WHEN (v.tp = 'C' AND f.type = 'SAF_NMP_CANCEL') THEN
                          'ANN_SAFNMP'
                         WHEN (v.tp = 'C' AND f.type = 'DRAFT') THEN
                          'ANN_DRAFT'
                         ELSE
                          f.type
                       END) AS portfolioPaymentType,
                       v.refdoss AS compteCaseReference,
                       v.MONTANT_DCMP AS portfolioPaymentAmount,
                       (SELECT i.nom
                          FROM t_intervenants t, 
                               g_individu i
                         WHERE t.refdoss = f.refdoss
                           AND t.reftype = 'DB'
                           AND t.refindividu = i.refindividu) AS dbName,
                       v.dtmarque_dt AS portfolioReconcilationDate,
                       NULL AS dtmarque
                  FROM v_pmtsaf_declared v, 
                       g_elemfi f, 
                       v_tdomaine d
                 WHERE 1 = 1
                   AND v.refdoss_dcmp = :B1
                   AND v.tp IN ('F', 'C')
                   AND f.refelem(+) = v.refencaiss
                   AND d.type(+) = 'MISC_TRANSLATIONS'
                   AND NVL(d.langue(+), 'FR') = :B2
                   AND d.abrev(+) = (CASE
                         WHEN (v.tp = 'F' AND f.type = 'SAF CN COMP') THEN
                          'SAFCNCOMP'
                         WHEN (v.tp = 'F' AND f.type = 'SAF_NMP_CANCEL') THEN
                          'SAFNMPCANCEL'
                         WHEN (v.tp = 'F' AND
                              f.type = 'NON MATCHED PAYMENT ELEMENTS') THEN
                          'EPNL'
                         WHEN (v.tp = 'F' AND
                              f.type = 'POSITIVE LTL DECLARED PAYMENTS') THEN
                          'PDPL'
                         WHEN (v.tp = 'F' AND
                              f.type =
                              'ANNULATION DAVOIRS PAR DES REGLEMENTS') THEN
                          'AAVR'
                         WHEN (v.tp = 'F' AND
                              f.type = 'OPERATION DIVERSE CREDITRICE') THEN
                          'ODC'
                         WHEN (v.tp = 'C' AND f.type = 'SAF CN COMP') THEN
                          'ANN_SAF'
                         WHEN (v.tp = 'C' AND f.type = 'SAF_NMP_CANCEL') THEN
                          'ANN_SAFNMP'
                         WHEN (v.tp = 'C' AND f.type = 'DRAFT') THEN
                          'ANN_DRAFT'
                         ELSE
                          f.type
                       END)
                   AND (v.dtmarque_dt IS NULL AND v.rec_grp_pmtsaf = 'NP')
                 ORDER BY datePmt DESC, refencaiss) foo
         WHERE 1 = 1
           AND ROWNUM <= :B3)
 WHERE 1 = 1
   AND rnum >= :B4;
/********************************OLD SQL*******************************************/
/********************************OLD Metrics***************************************/
/*
MODULE                           SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL            PERC
-------------------------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
5F9B0D5AD87BE9F7A5B047114B155969                                                ON CPU               2024/04/08 11:31:39  2024/04/08 12:07:49         219                    2 +000000000 00:36:10.029 49%
imxbatch_ClientFunding                                           656      15186 db file sequential r 2024/04/08 11:20:29  2024/04/08 11:36:19          55             15052064 +000000000 00:15:50.029 12%
 
 
MODULE                           SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL            PERC
-------------------------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
5F9B0D5AD87BE9F7A5B047114B155969                                                ON CPU               2024/04/08 11:31:39  2024/04/08 12:07:49         219                    2 +000000000 00:36:10.029 100%
5F9B0D5AD87BE9F7A5B047114B155969 cnr0p1bkw7a6m  710768098       1285      65297 db file sequential r 2024/04/08 12:07:59  2024/04/08 12:07:59           1                    1 +000000000 00:00:00.000 0%
 

MODULE                           SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL            PERC
-------------------------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
5F9B0D5AD87BE9F7A5B047114B155969                                1285      65297                      2024/04/08 11:31:39  2024/04/08 12:07:59         219                    1 +000000000 00:36:20.029 100%
5F9B0D5AD87BE9F7A5B047114B155969 80wyk81z869df  686649940       1168      21028 ON CPU               2024/04/08 11:31:39  2024/04/08 11:31:39           1                    1 +000000000 00:00:00.000 0%

MODULE                           SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL            PERC
-------------------------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
5F9B0D5AD87BE9F7A5B047114B155969 cnr0p1bkw7a6m  710768098       1285      65297                      2024/04/08 11:31:49  2024/04/08 12:07:59         218                    1 +000000000 00:36:10.029 100%
5F9B0D5AD87BE9F7A5B047114B155969 80wyk81z869df  686649940       1285      65297 ON CPU               2024/04/08 11:31:39  2024/04/08 11:31:39           1                    1 +000000000 00:00:00.000 0%
 
 
 
SQL_ID        SQL_PLAN_HASH_VALUE SQL_PLAN_LINE_ID SQL_PLAN_OPERATION             SQL_PLAN_OPTIONS                   ACTIVE
------------- ------------------- ---------------- ------------------------------ ------------------------------ ----------
cnr0p1bkw7a6m           710768098               40 INDEX                          RANGE SCAN                            217
cnr0p1bkw7a6m           710768098              359 INDEX                          RANGE SCAN                              1
 
INSTANCE_NUMBER SQL_ID            ELAPSED MAX_WAIT_ON     PC_OF  WAIT_TIME            GETS      READS       ROWS  ELAP/EXEC       GETS/EXEC READS/EXEC  ROWS/EXEC       EXEC PLAN_HASH_VALUE
--------------- ------------- ----------- --------------- ----- ---------- --------------- ---------- ---------- ---------- --------------- ---------- ---------- ---------- ---------------
              1 cnr0p1bkw7a6m         458 CPU             98%   458.318769        33875964      22112       2001     457.94        33875964      22112       2001          0       710768098


Plan hash value: 710768098
--------------------------------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                              | Name                      | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  |
--------------------------------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                                       |                           |      1 |        |   372 (100)|      0 |00:00:00.01 |       0 |      0 |
|*  1 |  VIEW                                                  |                           |      1 |    264 |   372   (3)|      0 |00:00:00.01 |       0 |      0 |
|*  2 |   COUNT STOPKEY                                        |                           |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
|   3 |    VIEW                                                |                           |      1 |    264 |   372   (3)|      0 |00:00:00.01 |       0 |      0 |
|*  4 |     SORT UNIQUE STOPKEY                                |                           |      1 |    264 |   371   (2)|      0 |00:00:00.01 |       0 |      0 |
|   5 |      UNION-ALL                                         |                           |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
|   6 |       NESTED LOOPS                                     |                           |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|   7 |        NESTED LOOPS                                    |                           |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*  8 |         INDEX RANGE SCAN                               | INT_REFDOSS               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*  9 |         INDEX UNIQUE SCAN                              | IND_REFINDIV              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|  10 |        TABLE ACCESS BY INDEX ROWID                     | G_INDIVIDU                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 11 |       HASH JOIN OUTER                                  |                           |      1 |    132 |    44  (10)|      0 |00:00:00.01 |       0 |      0 |
|  12 |        NESTED LOOPS OUTER                              |                           |      1 |     12 |    33  (13)|  28309 |00:01:26.92 |    6794K|  21624 |
|  13 |         VIEW                                           | V_PMTSAF_DECLARED         |      1 |     12 |    32  (13)|  28309 |00:01:26.69 |    6690K|  21247 |
|  14 |          UNION-ALL                                     |                           |      1 |        |            |  28309 |00:01:26.68 |    6690K|  21247 |
|* 15 |           FILTER                                       |                           |      1 |        |            |  14993 |00:00:02.14 |   63706 |   4548 |
|  16 |            NESTED LOOPS OUTER                          |                           |      1 |      1 |     5   (0)|  29986 |00:00:02.13 |   63706 |   4548 |
|  17 |             NESTED LOOPS                               |                           |      1 |      1 |     4   (0)|  14993 |00:00:01.30 |   13958 |   2679 |
|  18 |              NESTED LOOPS                              |                           |      1 |      7 |     3   (0)|   1864 |00:00:00.01 |      22 |      0 |
|  19 |               NESTED LOOPS                             |                           |      1 |      1 |     2   (0)|      1 |00:00:00.01 |       7 |      0 |
|  20 |                TABLE ACCESS BY INDEX ROWID             | G_DOSSIER                 |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       4 |      0 |
|* 21 |                 INDEX UNIQUE SCAN                      | DOS_REFDOSS               |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |      0 |
|* 22 |                INDEX UNIQUE SCAN                       | DOS_REFDOSS               |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |      0 |
|* 23 |               INDEX RANGE SCAN                         | G_DOSSIER_RL_CD_RD_RF_IDX |      1 |      7 |     1   (0)|   1864 |00:00:00.01 |      15 |      0 |
|* 24 |              TABLE ACCESS BY INDEX ROWID BATCHED       | G_ENCAISSEMENT            |   1864 |      1 |     1   (0)|  14993 |00:00:01.30 |   13936 |   2679 |
|* 25 |               INDEX RANGE SCAN                         | G_ENC_REFDOSS_GRP_PMTSAF  |   1864 |      6 |     1   (0)|  14993 |00:00:00.65 |    5242 |   1199 |
|* 26 |             TABLE ACCESS BY INDEX ROWID BATCHED        | T_ECRDOS                  |  14993 |      1 |     1   (0)|  29986 |00:00:00.82 |   49748 |   1869 |
|* 27 |              INDEX RANGE SCAN                          | TECR_REFELEM              |  14993 |      2 |     1   (0)|  29986 |00:00:00.08 |   38966 |    129 |
|* 28 |           FILTER                                       |                           |      1 |        |            |  13316 |00:01:24.50 |    6626K|  16699 |
|  29 |            NESTED LOOPS OUTER                          |                           |      1 |      1 |     5   (0)|  53267 |00:01:24.49 |    6627K|  16700 |
|  30 |             NESTED LOOPS                               |                           |      1 |      1 |     4   (0)|  13317 |00:00:02.63 |    9551 |   6575 |
|  31 |              NESTED LOOPS                              |                           |      1 |      7 |     3   (0)|     36 |00:00:00.01 |      10 |      0 |
|  32 |               NESTED LOOPS                             |                           |      1 |      1 |     2   (0)|      1 |00:00:00.01 |       7 |      0 |
|  33 |                TABLE ACCESS BY INDEX ROWID             | G_DOSSIER                 |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       4 |      0 |
|* 34 |                 INDEX UNIQUE SCAN                      | DOS_REFDOSS               |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |      0 |
|* 35 |                INDEX UNIQUE SCAN                       | DOS_REFDOSS               |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |      0 |
|* 36 |               INDEX RANGE SCAN                         | G_DOSSIER_RL_CD_RD_RF_IDX |      1 |      7 |     1   (0)|     36 |00:00:00.01 |       3 |      0 |
|* 37 |              TABLE ACCESS BY INDEX ROWID BATCHED       | G_ENCAISSEMENT            |     36 |      1 |     1   (0)|  13317 |00:00:02.62 |    9541 |   6575 |
|* 38 |               INDEX RANGE SCAN                         | G_ENCREFD_TRAITE          |     36 |      1 |     1   (0)|  13935 |00:00:00.45 |    1391 |   1295 |
|* 39 |             TABLE ACCESS BY INDEX ROWID BATCHED        | T_ECRDOS                  |  13317 |      1 |     1   (0)|  53267 |00:01:21.85 |    6617K|  10125 |
|* 40 |              INDEX RANGE SCAN                          | IDX_FFSI_T_ECRDOS         |  13317 |      1 |     1   (0)|  53267 |00:01:17.58 |    6588K|   2529 |
|  41 |           NESTED LOOPS                                 |                           |      0 |      1 |     7   (0)|      0 |00:00:00.01 |       0 |      0 |
|  42 |            NESTED LOOPS                                |                           |      0 |      2 |     7   (0)|      0 |00:00:00.01 |       0 |      0 |
|  43 |             NESTED LOOPS                               |                           |      0 |      1 |     6   (0)|      0 |00:00:00.01 |       0 |      0 |
|  44 |              NESTED LOOPS OUTER                        |                           |      0 |      1 |     5   (0)|      0 |00:00:00.01 |       0 |      0 |
|  45 |               NESTED LOOPS                             |                           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|  46 |                NESTED LOOPS                            |                           |      0 |      7 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|  47 |                 NESTED LOOPS                           |                           |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 48 |                  INDEX RANGE SCAN                      | DOS_REFDOSS_REFLOT_IDX    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 49 |                  INDEX UNIQUE SCAN                     | DOS_REFDOSS               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 50 |                 INDEX RANGE SCAN                       | G_DOSSIER_RL_CD_RD_RF_IDX |      0 |      7 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 51 |                TABLE ACCESS BY INDEX ROWID BATCHED     | G_ENCAISSEMENT            |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 52 |                 INDEX RANGE SCAN                       | G_ENC_REFDOSS_GRP_PMTSAF  |      0 |      6 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 53 |               INDEX RANGE SCAN                         | IDX_FFSI_T_ECRDOS         |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|  54 |              TABLE ACCESS BY INDEX ROWID BATCHED       | F_DETFAC                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 55 |               INDEX RANGE SCAN                         | F_DETFAC_DF_REFINIT_IDX   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 56 |             INDEX RANGE SCAN                           | TECR_REFELEM              |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 57 |            TABLE ACCESS BY INDEX ROWID                 | T_ECRDOS                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|  58 |           NESTED LOOPS                                 |                           |      0 |      1 |     7   (0)|      0 |00:00:00.01 |       0 |      0 |
|  59 |            NESTED LOOPS                                |                           |      0 |      2 |     7   (0)|      0 |00:00:00.01 |       0 |      0 |
|  60 |             NESTED LOOPS                               |                           |      0 |      1 |     6   (0)|      0 |00:00:00.01 |       0 |      0 |
|  61 |              NESTED LOOPS OUTER                        |                           |      0 |      1 |     5   (0)|      0 |00:00:00.01 |       0 |      0 |
|  62 |               NESTED LOOPS                             |                           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|  63 |                NESTED LOOPS                            |                           |      0 |      7 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|  64 |                 NESTED LOOPS                           |                           |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 65 |                  INDEX RANGE SCAN                      | DOS_REFDOSS_REFLOT_IDX    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 66 |                  INDEX UNIQUE SCAN                     | DOS_REFDOSS               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 67 |                 INDEX RANGE SCAN                       | G_DOSSIER_RL_CD_RD_RF_IDX |      0 |      7 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 68 |                TABLE ACCESS BY INDEX ROWID BATCHED     | G_ENCAISSEMENT            |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 69 |                 INDEX RANGE SCAN                       | G_ENCREFD_TRAITE          |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 70 |               INDEX RANGE SCAN                         | IDX_FFSI_T_ECRDOS         |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|  71 |              TABLE ACCESS BY INDEX ROWID BATCHED       | F_DETFAC                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 72 |               INDEX RANGE SCAN                         | F_DETFAC_DF_REFINIT_IDX   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 73 |             INDEX RANGE SCAN                           | TECR_REFELEM              |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 74 |            TABLE ACCESS BY INDEX ROWID                 | T_ECRDOS                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 75 |           FILTER                                       |                           |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  76 |            NESTED LOOPS                                |                           |      0 |      1 |     5   (0)|      0 |00:00:00.01 |       0 |      0 |
|  77 |             NESTED LOOPS                               |                           |      0 |      2 |     5   (0)|      0 |00:00:00.01 |       0 |      0 |
|  78 |              NESTED LOOPS                              |                           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|  79 |               NESTED LOOPS                             |                           |      0 |      7 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|  80 |                NESTED LOOPS                            |                           |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 81 |                 INDEX RANGE SCAN                       | DOS_REFDOSS_REFLOT_IDX    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 82 |                 INDEX UNIQUE SCAN                      | DOS_REFDOSS               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 83 |                INDEX RANGE SCAN                        | G_DOSSIER_RL_CD_RD_RF_IDX |      0 |      7 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 84 |               TABLE ACCESS BY INDEX ROWID BATCHED      | G_ELEMFI                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 85 |                INDEX RANGE SCAN                        | G_ELEMFI_DOS_TYP_FG02     |      0 |      5 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 86 |              INDEX RANGE SCAN                          | TECR_REFELEM              |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 87 |             TABLE ACCESS BY INDEX ROWID                | T_ECRDOS                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 88 |           FILTER                                       |                           |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  89 |            NESTED LOOPS                                |                           |      0 |      1 |     5   (0)|      0 |00:00:00.01 |       0 |      0 |
|  90 |             NESTED LOOPS                               |                           |      0 |      2 |     5   (0)|      0 |00:00:00.01 |       0 |      0 |
|  91 |              NESTED LOOPS                              |                           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|  92 |               NESTED LOOPS                             |                           |      0 |      7 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|  93 |                NESTED LOOPS                            |                           |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 94 |                 INDEX RANGE SCAN                       | DOS_REFDOSS_REFLOT_IDX    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 95 |                 INDEX UNIQUE SCAN                      | DOS_REFDOSS               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 96 |                INDEX RANGE SCAN                        | G_DOSSIER_RL_CD_RD_RF_IDX |      0 |      7 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 97 |               TABLE ACCESS BY INDEX ROWID BATCHED      | G_ELEMFI                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 98 |                INDEX RANGE SCAN                        | GE_REFDOSS_DTANNUL_IDX    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 99 |              INDEX RANGE SCAN                          | TECR_REFELEM              |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*100 |             TABLE ACCESS BY INDEX ROWID                | T_ECRDOS                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*101 |           FILTER                                       |                           |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 102 |            NESTED LOOPS                                |                           |      0 |      8 |     5   (0)|      0 |00:00:00.01 |       0 |      0 |
| 103 |             NESTED LOOPS                               |                           |      0 |    350 |     5   (0)|      0 |00:00:00.01 |       0 |      0 |
| 104 |              NESTED LOOPS                              |                           |      0 |      7 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
| 105 |               NESTED LOOPS                             |                           |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
| 106 |                TABLE ACCESS BY INDEX ROWID             | G_DOSSIER                 |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*107 |                 INDEX UNIQUE SCAN                      | DOS_REFDOSS               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*108 |                INDEX UNIQUE SCAN                       | DOS_REFDOSS               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*109 |               INDEX RANGE SCAN                         | G_DOSSIER_RL_CD_RD_RF_IDX |      0 |      7 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*110 |              INDEX RANGE SCAN                          | G_ENCREFD_TRAITE          |      0 |     50 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*111 |             TABLE ACCESS BY INDEX ROWID                | G_ENCAISSEMENT            |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*112 |           FILTER                                       |                           |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 113 |            NESTED LOOPS                                |                           |      0 |      1 |     7   (0)|      0 |00:00:00.01 |       0 |      0 |
| 114 |             NESTED LOOPS                               |                           |      0 |      2 |     7   (0)|      0 |00:00:00.01 |       0 |      0 |
| 115 |              NESTED LOOPS                              |                           |      0 |      1 |     6   (0)|      0 |00:00:00.01 |       0 |      0 |
| 116 |               MERGE JOIN CARTESIAN                     |                           |      0 |      1 |     5   (0)|      0 |00:00:00.01 |       0 |      0 |
| 117 |                MERGE JOIN CARTESIAN                    |                           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
| 118 |                 NESTED LOOPS                           |                           |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
| 119 |                  NESTED LOOPS                          |                           |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*120 |                   INDEX RANGE SCAN                     | DOS_REFDOSS_REFLOT_IDX    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*121 |                   INDEX UNIQUE SCAN                    | DOS_REFDOSS               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*122 |                  INDEX RANGE SCAN                      | PK_G_ETUDE                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 123 |                 BUFFER SORT                            |                           |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*124 |                  TABLE ACCESS BY INDEX ROWID BATCHED   | G_PIECE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*125 |                   INDEX RANGE SCAN                     | PIE_REFDOSS               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 126 |                BUFFER SORT                             |                           |      0 |      7 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*127 |                 INDEX RANGE SCAN                       | G_DOSSIER_RL_CD_RD_RF_IDX |      0 |      7 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*128 |               TABLE ACCESS BY INDEX ROWID BATCHED      | G_ELEMFI                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*129 |                INDEX RANGE SCAN                        | EFI_DOS_DTEMIS_TYPE       |      0 |      5 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*130 |              INDEX RANGE SCAN                          | TECR_REFELEM              |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*131 |             TABLE ACCESS BY INDEX ROWID                | T_ECRDOS                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*132 |           FILTER                                       |                           |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 133 |            NESTED LOOPS                                |                           |      0 |      1 |     8   (0)|      0 |00:00:00.01 |       0 |      0 |
| 134 |             NESTED LOOPS                               |                           |      0 |      2 |     8   (0)|      0 |00:00:00.01 |       0 |      0 |
| 135 |              NESTED LOOPS                              |                           |      0 |      1 |     7   (0)|      0 |00:00:00.01 |       0 |      0 |
| 136 |               MERGE JOIN CARTESIAN                     |                           |      0 |      1 |     6   (0)|      0 |00:00:00.01 |       0 |      0 |
| 137 |                MERGE JOIN CARTESIAN                    |                           |      0 |      1 |     5   (0)|      0 |00:00:00.01 |       0 |      0 |
| 138 |                 NESTED LOOPS                           |                           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
| 139 |                  NESTED LOOPS                          |                           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
| 140 |                   NESTED LOOPS                         |                           |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
| 141 |                    NESTED LOOPS                        |                           |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*142 |                     INDEX RANGE SCAN                   | DOS_REFDOSS_REFLOT_IDX    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*143 |                     INDEX UNIQUE SCAN                  | DOS_REFDOSS               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 144 |                    TABLE ACCESS BY INDEX ROWID BATCHED | G_PIECE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*145 |                     INDEX RANGE SCAN                   | PIE_REFDOSS               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*146 |                   INDEX UNIQUE SCAN                    | REFPIECE_IDX              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*147 |                  TABLE ACCESS BY INDEX ROWID           | G_CF_CONTRACT             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 148 |                 BUFFER SORT                            |                           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*149 |                  INDEX RANGE SCAN                      | PK_G_ETUDE                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 150 |                BUFFER SORT                             |                           |      0 |      7 |     5   (0)|      0 |00:00:00.01 |       0 |      0 |
|*151 |                 INDEX RANGE SCAN                       | G_DOSSIER_RL_CD_RD_RF_IDX |      0 |      7 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*152 |               TABLE ACCESS BY INDEX ROWID BATCHED      | G_ELEMFI                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*153 |                INDEX RANGE SCAN                        | G_ELEMFI_DOS_TYP_FG02     |      0 |      3 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*154 |              INDEX RANGE SCAN                          | TECR_REFELEM              |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*155 |             TABLE ACCESS BY INDEX ROWID                | T_ECRDOS                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*156 |           FILTER                                       |                           |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 157 |            NESTED LOOPS                                |                           |      0 |      1 |     8   (0)|      0 |00:00:00.01 |       0 |      0 |
| 158 |             NESTED LOOPS                               |                           |      0 |      2 |     8   (0)|      0 |00:00:00.01 |       0 |      0 |
| 159 |              NESTED LOOPS                              |                           |      0 |      1 |     7   (0)|      0 |00:00:00.01 |       0 |      0 |
| 160 |               MERGE JOIN CARTESIAN                     |                           |      0 |      1 |     6   (0)|      0 |00:00:00.01 |       0 |      0 |
| 161 |                MERGE JOIN CARTESIAN                    |                           |      0 |      1 |     5   (0)|      0 |00:00:00.01 |       0 |      0 |
| 162 |                 NESTED LOOPS                           |                           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
| 163 |                  NESTED LOOPS                          |                           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
| 164 |                   NESTED LOOPS                         |                           |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
| 165 |                    NESTED LOOPS                        |                           |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*166 |                     INDEX RANGE SCAN                   | DOS_REFDOSS_REFLOT_IDX    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*167 |                     INDEX UNIQUE SCAN                  | DOS_REFDOSS               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 168 |                    TABLE ACCESS BY INDEX ROWID BATCHED | G_PIECE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*169 |                     INDEX RANGE SCAN                   | PIE_REFDOSS               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*170 |                   INDEX UNIQUE SCAN                    | REFPIECE_IDX              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*171 |                  TABLE ACCESS BY INDEX ROWID           | G_CF_CONTRACT             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 172 |                 BUFFER SORT                            |                           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*173 |                  INDEX RANGE SCAN                      | PK_G_ETUDE                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 174 |                BUFFER SORT                             |                           |      0 |      7 |     5   (0)|      0 |00:00:00.01 |       0 |      0 |
|*175 |                 INDEX RANGE SCAN                       | G_DOSSIER_RL_CD_RD_RF_IDX |      0 |      7 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*176 |               TABLE ACCESS BY INDEX ROWID BATCHED      | G_ELEMFI                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*177 |                INDEX RANGE SCAN                        | GE_REFDOSS_DTANNUL_IDX    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*178 |              INDEX RANGE SCAN                          | TECR_REFELEM              |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*179 |             TABLE ACCESS BY INDEX ROWID                | T_ECRDOS                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*180 |           FILTER                                       |                           |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 181 |            NESTED LOOPS                                |                           |      0 |      1 |     8   (0)|      0 |00:00:00.01 |       0 |      0 |
| 182 |             NESTED LOOPS                               |                           |      0 |      2 |     8   (0)|      0 |00:00:00.01 |       0 |      0 |
| 183 |              NESTED LOOPS                              |                           |      0 |      1 |     7   (0)|      0 |00:00:00.01 |       0 |      0 |
| 184 |               MERGE JOIN CARTESIAN                     |                           |      0 |      1 |     6   (0)|      0 |00:00:00.01 |       0 |      0 |
| 185 |                MERGE JOIN CARTESIAN                    |                           |      0 |      1 |     5   (0)|      0 |00:00:00.01 |       0 |      0 |
| 186 |                 NESTED LOOPS                           |                           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
| 187 |                  NESTED LOOPS                          |                           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
| 188 |                   NESTED LOOPS                         |                           |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
| 189 |                    NESTED LOOPS                        |                           |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*190 |                     INDEX RANGE SCAN                   | DOS_REFDOSS_REFLOT_IDX    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*191 |                     INDEX UNIQUE SCAN                  | DOS_REFDOSS               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 192 |                    TABLE ACCESS BY INDEX ROWID BATCHED | G_PIECE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*193 |                     INDEX RANGE SCAN                   | PIE_REFDOSS               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*194 |                   INDEX UNIQUE SCAN                    | REFPIECE_IDX              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*195 |                  TABLE ACCESS BY INDEX ROWID           | G_CF_CONTRACT             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 196 |                 BUFFER SORT                            |                           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*197 |                  INDEX RANGE SCAN                      | PK_G_ETUDE                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 198 |                BUFFER SORT                             |                           |      0 |      7 |     5   (0)|      0 |00:00:00.01 |       0 |      0 |
|*199 |                 INDEX RANGE SCAN                       | G_DOSSIER_RL_CD_RD_RF_IDX |      0 |      7 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*200 |               TABLE ACCESS BY INDEX ROWID BATCHED      | G_ELEMFI                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*201 |                INDEX RANGE SCAN                        | G_ELEMFI_DOS_TYP_FG02     |      0 |      3 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*202 |              INDEX RANGE SCAN                          | TECR_REFELEM              |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*203 |             TABLE ACCESS BY INDEX ROWID                | T_ECRDOS                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*204 |           FILTER                                       |                           |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 205 |            NESTED LOOPS                                |                           |      0 |      1 |     8   (0)|      0 |00:00:00.01 |       0 |      0 |
| 206 |             NESTED LOOPS                               |                           |      0 |      2 |     8   (0)|      0 |00:00:00.01 |       0 |      0 |
| 207 |              NESTED LOOPS                              |                           |      0 |      1 |     7   (0)|      0 |00:00:00.01 |       0 |      0 |
| 208 |               MERGE JOIN CARTESIAN                     |                           |      0 |      1 |     6   (0)|      0 |00:00:00.01 |       0 |      0 |
| 209 |                MERGE JOIN CARTESIAN                    |                           |      0 |      1 |     5   (0)|      0 |00:00:00.01 |       0 |      0 |
| 210 |                 NESTED LOOPS                           |                           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
| 211 |                  NESTED LOOPS                          |                           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
| 212 |                   NESTED LOOPS                         |                           |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
| 213 |                    NESTED LOOPS                        |                           |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*214 |                     INDEX RANGE SCAN                   | DOS_REFDOSS_REFLOT_IDX    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*215 |                     INDEX UNIQUE SCAN                  | DOS_REFDOSS               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 216 |                    TABLE ACCESS BY INDEX ROWID BATCHED | G_PIECE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*217 |                     INDEX RANGE SCAN                   | PIE_REFDOSS               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*218 |                   INDEX UNIQUE SCAN                    | REFPIECE_IDX              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*219 |                  TABLE ACCESS BY INDEX ROWID           | G_CF_CONTRACT             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 220 |                 BUFFER SORT                            |                           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*221 |                  INDEX RANGE SCAN                      | PK_G_ETUDE                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 222 |                BUFFER SORT                             |                           |      0 |      7 |     5   (0)|      0 |00:00:00.01 |       0 |      0 |
|*223 |                 INDEX RANGE SCAN                       | G_DOSSIER_RL_CD_RD_RF_IDX |      0 |      7 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*224 |               TABLE ACCESS BY INDEX ROWID BATCHED      | G_ELEMFI                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*225 |                INDEX RANGE SCAN                        | GE_REFDOSS_DTANNUL_IDX    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*226 |              INDEX RANGE SCAN                          | TECR_REFELEM              |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*227 |             TABLE ACCESS BY INDEX ROWID                | T_ECRDOS                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 228 |         TABLE ACCESS BY INDEX ROWID                    | G_ENCAISSEMENT            |  28309 |      1 |     1   (0)|  28309 |00:00:00.23 |     104K|    377 |
|*229 |          INDEX UNIQUE SCAN                             | REFENCAISS                |  28309 |      1 |     1   (0)|  28309 |00:00:00.19 |   76345 |    377 |
| 230 |        VIEW                                            | V_TDOMAINE                |      0 |    495 |    11   (0)|      0 |00:00:00.01 |       0 |      0 |
| 231 |         UNION-ALL                                      |                           |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*232 |          FILTER                                        |                           |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 233 |           TABLE ACCESS BY INDEX ROWID BATCHED          | V_DOMAINE                 |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*234 |            INDEX RANGE SCAN                            | V_DOMAINE_TYPE_CODE_IDX   |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*235 |          FILTER                                        |                           |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 236 |           TABLE ACCESS BY INDEX ROWID BATCHED          | V_DOMAINE                 |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*237 |            INDEX RANGE SCAN                            | V_DOMAINE_TYPE_CODE_IDX   |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*238 |          FILTER                                        |                           |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 239 |           TABLE ACCESS BY INDEX ROWID BATCHED          | V_DOMAINE                 |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*240 |            INDEX RANGE SCAN                            | V_DOMAINE_TYPE_CODE_IDX   |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*241 |          FILTER                                        |                           |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 242 |           TABLE ACCESS BY INDEX ROWID BATCHED          | V_DOMAINE                 |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*243 |            INDEX RANGE SCAN                            | V_DOMAINE_TYPE_CODE_IDX   |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*244 |          FILTER                                        |                           |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 245 |           TABLE ACCESS BY INDEX ROWID BATCHED          | V_DOMAINE                 |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*246 |            INDEX RANGE SCAN                            | V_DOMAINE_TYPE_CODE_IDX   |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*247 |          FILTER                                        |                           |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 248 |           TABLE ACCESS BY INDEX ROWID BATCHED          | V_DOMAINE                 |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*249 |            INDEX RANGE SCAN                            | V_DOMAINE_TYPE_CODE_IDX   |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*250 |          FILTER                                        |                           |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 251 |           TABLE ACCESS BY INDEX ROWID BATCHED          | V_DOMAINE                 |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*252 |            INDEX RANGE SCAN                            | V_DOMAINE_TYPE_CODE_IDX   |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*253 |          FILTER                                        |                           |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 254 |           TABLE ACCESS BY INDEX ROWID BATCHED          | V_DOMAINE                 |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*255 |            INDEX RANGE SCAN                            | V_DOMAINE_TYPE_CODE_IDX   |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*256 |          FILTER                                        |                           |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 257 |           TABLE ACCESS BY INDEX ROWID BATCHED          | V_DOMAINE                 |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*258 |            INDEX RANGE SCAN                            | V_DOMAINE_TYPE_CODE_IDX   |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*259 |          FILTER                                        |                           |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 260 |           TABLE ACCESS BY INDEX ROWID BATCHED          | V_DOMAINE                 |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*261 |            INDEX RANGE SCAN                            | V_DOMAINE_TYPE_CODE_IDX   |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*262 |          FILTER                                        |                           |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 263 |           TABLE ACCESS BY INDEX ROWID BATCHED          | V_DOMAINE                 |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*264 |            INDEX RANGE SCAN                            | V_DOMAINE_TYPE_CODE_IDX   |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 265 |       NESTED LOOPS                                     |                           |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
| 266 |        NESTED LOOPS                                    |                           |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*267 |         INDEX RANGE SCAN                               | INT_REFDOSS               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*268 |         INDEX UNIQUE SCAN                              | IND_REFINDIV              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 269 |        TABLE ACCESS BY INDEX ROWID                     | G_INDIVIDU                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*270 |       HASH JOIN OUTER                                  |                           |      0 |    132 |    60   (0)|      0 |00:00:00.01 |       0 |      0 |
| 271 |        NESTED LOOPS OUTER                              |                           |      0 |     12 |    49   (0)|      0 |00:00:00.01 |       0 |      0 |
| 272 |         VIEW                                           | V_PMTSAF_DECLARED         |      0 |     12 |    48   (0)|      0 |00:00:00.01 |       0 |      0 |
| 273 |          UNION-ALL                                     |                           |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*274 |           FILTER                                       |                           |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*275 |            FILTER                                      |                           |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 276 |             NESTED LOOPS OUTER                         |                           |      0 |      1 |     5   (0)|      0 |00:00:00.01 |       0 |      0 |
| 277 |              NESTED LOOPS                              |                           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
| 278 |               NESTED LOOPS                             |                           |      0 |      7 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
| 279 |                NESTED LOOPS                            |                           |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
| 280 |                 TABLE ACCESS BY INDEX ROWID            | G_DOSSIER                 |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*281 |                  INDEX UNIQUE SCAN                     | DOS_REFDOSS               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*282 |                 INDEX UNIQUE SCAN                      | DOS_REFDOSS               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*283 |                INDEX RANGE SCAN                        | G_DOSSIER_RL_CD_RD_RF_IDX |      0 |      7 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*284 |               TABLE ACCESS BY INDEX ROWID BATCHED      | G_ENCAISSEMENT            |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*285 |                INDEX RANGE SCAN                        | G_ENC_REFDOSS_GRP_PMTSAF  |      0 |      6 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*286 |              TABLE ACCESS BY INDEX ROWID BATCHED       | T_ECRDOS                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*287 |               INDEX RANGE SCAN                         | TECR_REFELEM              |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*288 |           FILTER                                       |                           |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*289 |            FILTER                                      |                           |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 290 |             NESTED LOOPS OUTER                         |                           |      0 |      1 |     5   (0)|      0 |00:00:00.01 |       0 |      0 |
| 291 |              NESTED LOOPS                              |                           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
| 292 |               NESTED LOOPS                             |                           |      0 |      7 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
| 293 |                NESTED LOOPS                            |                           |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
| 294 |                 TABLE ACCESS BY INDEX ROWID            | G_DOSSIER                 |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*295 |                  INDEX UNIQUE SCAN                     | DOS_REFDOSS               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*296 |                 INDEX UNIQUE SCAN                      | DOS_REFDOSS               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*297 |                INDEX RANGE SCAN                        | G_DOSSIER_RL_CD_RD_RF_IDX |      0 |      7 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*298 |               TABLE ACCESS BY INDEX ROWID BATCHED      | G_ENCAISSEMENT            |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*299 |                INDEX RANGE SCAN                        | G_ENCREFD_TRAITE          |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*300 |              TABLE ACCESS BY INDEX ROWID BATCHED       | T_ECRDOS                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*301 |               INDEX RANGE SCAN                         | IDX_FFSI_T_ECRDOS         |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*302 |           FILTER                                       |                           |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 303 |            NESTED LOOPS                                |                           |      0 |      1 |     7   (0)|      0 |00:00:00.01 |       0 |      0 |
| 304 |             NESTED LOOPS                               |                           |      0 |      2 |     7   (0)|      0 |00:00:00.01 |       0 |      0 |
| 305 |              NESTED LOOPS                              |                           |      0 |      1 |     6   (0)|      0 |00:00:00.01 |       0 |      0 |
| 306 |               NESTED LOOPS OUTER                       |                           |      0 |      1 |     5   (0)|      0 |00:00:00.01 |       0 |      0 |
| 307 |                NESTED LOOPS                            |                           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
| 308 |                 NESTED LOOPS                           |                           |      0 |      7 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
| 309 |                  NESTED LOOPS                          |                           |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*310 |                   INDEX RANGE SCAN                     | DOS_REFDOSS_REFLOT_IDX    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*311 |                   INDEX UNIQUE SCAN                    | DOS_REFDOSS               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*312 |                  INDEX RANGE SCAN                      | G_DOSSIER_RL_CD_RD_RF_IDX |      0 |      7 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*313 |                 TABLE ACCESS BY INDEX ROWID BATCHED    | G_ENCAISSEMENT            |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*314 |                  INDEX RANGE SCAN                      | G_ENC_REFDOSS_GRP_PMTSAF  |      0 |      6 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*315 |                INDEX RANGE SCAN                        | IDX_FFSI_T_ECRDOS         |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 316 |               TABLE ACCESS BY INDEX ROWID BATCHED      | F_DETFAC                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*317 |                INDEX RANGE SCAN                        | F_DETFAC_DF_REFINIT_IDX   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*318 |              INDEX RANGE SCAN                          | TECR_REFELEM              |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*319 |             TABLE ACCESS BY INDEX ROWID                | T_ECRDOS                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*320 |           FILTER                                       |                           |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 321 |            NESTED LOOPS                                |                           |      0 |      1 |     7   (0)|      0 |00:00:00.01 |       0 |      0 |
| 322 |             NESTED LOOPS                               |                           |      0 |      2 |     7   (0)|      0 |00:00:00.01 |       0 |      0 |
| 323 |              NESTED LOOPS                              |                           |      0 |      1 |     6   (0)|      0 |00:00:00.01 |       0 |      0 |
| 324 |               NESTED LOOPS OUTER                       |                           |      0 |      1 |     5   (0)|      0 |00:00:00.01 |       0 |      0 |
| 325 |                NESTED LOOPS                            |                           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
| 326 |                 NESTED LOOPS                           |                           |      0 |      7 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
| 327 |                  NESTED LOOPS                          |                           |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*328 |                   INDEX RANGE SCAN                     | DOS_REFDOSS_REFLOT_IDX    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*329 |                   INDEX UNIQUE SCAN                    | DOS_REFDOSS               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*330 |                  INDEX RANGE SCAN                      | G_DOSSIER_RL_CD_RD_RF_IDX |      0 |      7 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*331 |                 TABLE ACCESS BY INDEX ROWID BATCHED    | G_ENCAISSEMENT            |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*332 |                  INDEX RANGE SCAN                      | G_ENCREFD_TRAITE          |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*333 |                INDEX RANGE SCAN                        | IDX_FFSI_T_ECRDOS         |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 334 |               TABLE ACCESS BY INDEX ROWID BATCHED      | F_DETFAC                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*335 |                INDEX RANGE SCAN                        | F_DETFAC_DF_REFINIT_IDX   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*336 |              INDEX RANGE SCAN                          | TECR_REFELEM              |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*337 |             TABLE ACCESS BY INDEX ROWID                | T_ECRDOS                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 338 |           NESTED LOOPS                                 |                           |      0 |      1 |     5   (0)|      0 |00:00:00.01 |       0 |      0 |
| 339 |            NESTED LOOPS                                |                           |      0 |      2 |     5   (0)|      0 |00:00:00.01 |       0 |      0 |
| 340 |             NESTED LOOPS                               |                           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
| 341 |              NESTED LOOPS                              |                           |      0 |      7 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
| 342 |               NESTED LOOPS                             |                           |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*343 |                INDEX RANGE SCAN                        | DOS_REFDOSS_REFLOT_IDX    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*344 |                INDEX UNIQUE SCAN                       | DOS_REFDOSS               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*345 |               INDEX RANGE SCAN                         | G_DOSSIER_RL_CD_RD_RF_IDX |      0 |      7 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*346 |              TABLE ACCESS BY INDEX ROWID BATCHED       | G_ELEMFI                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*347 |               INDEX RANGE SCAN                         | G_ELEMFI_DOS_TYP_FG02     |      0 |      5 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*348 |             INDEX RANGE SCAN                           | TECR_REFELEM              |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*349 |            TABLE ACCESS BY INDEX ROWID                 | T_ECRDOS                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 350 |           NESTED LOOPS                                 |                           |      0 |      1 |     5   (0)|      0 |00:00:00.01 |       0 |      0 |
| 351 |            NESTED LOOPS                                |                           |      0 |      2 |     5   (0)|      0 |00:00:00.01 |       0 |      0 |
| 352 |             NESTED LOOPS                               |                           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
| 353 |              NESTED LOOPS                              |                           |      0 |      7 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
| 354 |               NESTED LOOPS                             |                           |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*355 |                INDEX RANGE SCAN                        | DOS_REFDOSS_REFLOT_IDX    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*356 |                INDEX UNIQUE SCAN                       | DOS_REFDOSS               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*357 |               INDEX RANGE SCAN                         | G_DOSSIER_RL_CD_RD_RF_IDX |      0 |      7 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*358 |              TABLE ACCESS BY INDEX ROWID BATCHED       | G_ELEMFI                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*359 |               INDEX RANGE SCAN                         | GE_REFDOSS_DTANNUL_IDX    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*360 |             INDEX RANGE SCAN                           | TECR_REFELEM              |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*361 |            TABLE ACCESS BY INDEX ROWID                 | T_ECRDOS                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*362 |           FILTER                                       |                           |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 363 |            NESTED LOOPS                                |                           |      0 |      8 |     5   (0)|      0 |00:00:00.01 |       0 |      0 |
| 364 |             NESTED LOOPS                               |                           |      0 |    350 |     5   (0)|      0 |00:00:00.01 |       0 |      0 |
| 365 |              NESTED LOOPS                              |                           |      0 |      7 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
| 366 |               NESTED LOOPS                             |                           |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
| 367 |                TABLE ACCESS BY INDEX ROWID             | G_DOSSIER                 |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*368 |                 INDEX UNIQUE SCAN                      | DOS_REFDOSS               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*369 |                INDEX UNIQUE SCAN                       | DOS_REFDOSS               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*370 |               INDEX RANGE SCAN                         | G_DOSSIER_RL_CD_RD_RF_IDX |      0 |      7 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*371 |              INDEX RANGE SCAN                          | G_ENCREFD_TRAITE          |      0 |     50 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*372 |             TABLE ACCESS BY INDEX ROWID                | G_ENCAISSEMENT            |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 373 |           NESTED LOOPS                                 |                           |      0 |      1 |     7   (0)|      0 |00:00:00.01 |       0 |      0 |
| 374 |            NESTED LOOPS                                |                           |      0 |      2 |     7   (0)|      0 |00:00:00.01 |       0 |      0 |
| 375 |             NESTED LOOPS                               |                           |      0 |      1 |     6   (0)|      0 |00:00:00.01 |       0 |      0 |
| 376 |              MERGE JOIN CARTESIAN                      |                           |      0 |      1 |     5   (0)|      0 |00:00:00.01 |       0 |      0 |
| 377 |               MERGE JOIN CARTESIAN                     |                           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
| 378 |                NESTED LOOPS                            |                           |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
| 379 |                 NESTED LOOPS                           |                           |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*380 |                  INDEX RANGE SCAN                      | DOS_REFDOSS_REFLOT_IDX    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*381 |                  INDEX UNIQUE SCAN                     | DOS_REFDOSS               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*382 |                 INDEX RANGE SCAN                       | PK_G_ETUDE                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 383 |                BUFFER SORT                             |                           |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*384 |                 TABLE ACCESS BY INDEX ROWID BATCHED    | G_PIECE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*385 |                  INDEX RANGE SCAN                      | PIE_REFDOSS               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 386 |               BUFFER SORT                              |                           |      0 |      7 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*387 |                INDEX RANGE SCAN                        | G_DOSSIER_RL_CD_RD_RF_IDX |      0 |      7 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*388 |              TABLE ACCESS BY INDEX ROWID BATCHED       | G_ELEMFI                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*389 |               INDEX RANGE SCAN                         | EFI_DOS_DTEMIS_TYPE       |      0 |      5 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*390 |             INDEX RANGE SCAN                           | TECR_REFELEM              |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*391 |            TABLE ACCESS BY INDEX ROWID                 | T_ECRDOS                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 392 |           NESTED LOOPS                                 |                           |      0 |      1 |     8   (0)|      0 |00:00:00.01 |       0 |      0 |
| 393 |            NESTED LOOPS                                |                           |      0 |      2 |     8   (0)|      0 |00:00:00.01 |       0 |      0 |
| 394 |             NESTED LOOPS                               |                           |      0 |      1 |     7   (0)|      0 |00:00:00.01 |       0 |      0 |
| 395 |              MERGE JOIN CARTESIAN                      |                           |      0 |      1 |     6   (0)|      0 |00:00:00.01 |       0 |      0 |
| 396 |               MERGE JOIN CARTESIAN                     |                           |      0 |      1 |     5   (0)|      0 |00:00:00.01 |       0 |      0 |
| 397 |                NESTED LOOPS                            |                           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
| 398 |                 NESTED LOOPS                           |                           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
| 399 |                  NESTED LOOPS                          |                           |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
| 400 |                   NESTED LOOPS                         |                           |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*401 |                    INDEX RANGE SCAN                    | DOS_REFDOSS_REFLOT_IDX    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*402 |                    INDEX UNIQUE SCAN                   | DOS_REFDOSS               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 403 |                   TABLE ACCESS BY INDEX ROWID BATCHED  | G_PIECE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*404 |                    INDEX RANGE SCAN                    | PIE_REFDOSS               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*405 |                  INDEX UNIQUE SCAN                     | REFPIECE_IDX              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*406 |                 TABLE ACCESS BY INDEX ROWID            | G_CF_CONTRACT             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 407 |                BUFFER SORT                             |                           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*408 |                 INDEX RANGE SCAN                       | PK_G_ETUDE                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 409 |               BUFFER SORT                              |                           |      0 |      7 |     5   (0)|      0 |00:00:00.01 |       0 |      0 |
|*410 |                INDEX RANGE SCAN                        | G_DOSSIER_RL_CD_RD_RF_IDX |      0 |      7 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*411 |              TABLE ACCESS BY INDEX ROWID BATCHED       | G_ELEMFI                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*412 |               INDEX RANGE SCAN                         | G_ELEMFI_DOS_TYP_FG02     |      0 |      3 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*413 |             INDEX RANGE SCAN                           | TECR_REFELEM              |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*414 |            TABLE ACCESS BY INDEX ROWID                 | T_ECRDOS                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 415 |           NESTED LOOPS                                 |                           |      0 |      1 |     8   (0)|      0 |00:00:00.01 |       0 |      0 |
| 416 |            NESTED LOOPS                                |                           |      0 |      2 |     8   (0)|      0 |00:00:00.01 |       0 |      0 |
| 417 |             NESTED LOOPS                               |                           |      0 |      1 |     7   (0)|      0 |00:00:00.01 |       0 |      0 |
| 418 |              MERGE JOIN CARTESIAN                      |                           |      0 |      1 |     6   (0)|      0 |00:00:00.01 |       0 |      0 |
| 419 |               MERGE JOIN CARTESIAN                     |                           |      0 |      1 |     5   (0)|      0 |00:00:00.01 |       0 |      0 |
| 420 |                NESTED LOOPS                            |                           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
| 421 |                 NESTED LOOPS                           |                           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
| 422 |                  NESTED LOOPS                          |                           |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
| 423 |                   NESTED LOOPS                         |                           |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*424 |                    INDEX RANGE SCAN                    | DOS_REFDOSS_REFLOT_IDX    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*425 |                    INDEX UNIQUE SCAN                   | DOS_REFDOSS               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 426 |                   TABLE ACCESS BY INDEX ROWID BATCHED  | G_PIECE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*427 |                    INDEX RANGE SCAN                    | PIE_REFDOSS               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*428 |                  INDEX UNIQUE SCAN                     | REFPIECE_IDX              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*429 |                 TABLE ACCESS BY INDEX ROWID            | G_CF_CONTRACT             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 430 |                BUFFER SORT                             |                           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*431 |                 INDEX RANGE SCAN                       | PK_G_ETUDE                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 432 |               BUFFER SORT                              |                           |      0 |      7 |     5   (0)|      0 |00:00:00.01 |       0 |      0 |
|*433 |                INDEX RANGE SCAN                        | G_DOSSIER_RL_CD_RD_RF_IDX |      0 |      7 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*434 |              TABLE ACCESS BY INDEX ROWID BATCHED       | G_ELEMFI                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*435 |               INDEX RANGE SCAN                         | GE_REFDOSS_DTANNUL_IDX    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*436 |             INDEX RANGE SCAN                           | TECR_REFELEM              |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*437 |            TABLE ACCESS BY INDEX ROWID                 | T_ECRDOS                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 438 |           MERGE JOIN CARTESIAN                         |                           |      0 |      2 |    15   (0)|      0 |00:00:00.01 |       0 |      0 |
| 439 |            VIEW                                        | VW_JF_SET$0C092750        |      0 |      2 |    14   (0)|      0 |00:00:00.01 |       0 |      0 |
| 440 |             UNION-ALL                                  |                           |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 441 |              NESTED LOOPS                              |                           |      0 |      1 |     7   (0)|      0 |00:00:00.01 |       0 |      0 |
| 442 |               NESTED LOOPS                             |                           |      0 |      2 |     7   (0)|      0 |00:00:00.01 |       0 |      0 |
| 443 |                NESTED LOOPS                            |                           |      0 |      1 |     6   (0)|      0 |00:00:00.01 |       0 |      0 |
| 444 |                 MERGE JOIN CARTESIAN                   |                           |      0 |      1 |     5   (0)|      0 |00:00:00.01 |       0 |      0 |
| 445 |                  NESTED LOOPS                          |                           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
| 446 |                   NESTED LOOPS                         |                           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
| 447 |                    NESTED LOOPS                        |                           |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
| 448 |                     NESTED LOOPS                       |                           |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*449 |                      INDEX RANGE SCAN                  | DOS_REFDOSS_REFLOT_IDX    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*450 |                      INDEX UNIQUE SCAN                 | DOS_REFDOSS               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 451 |                     TABLE ACCESS BY INDEX ROWID BATCHED| G_PIECE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*452 |                      INDEX RANGE SCAN                  | PIE_REFDOSS               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*453 |                    INDEX UNIQUE SCAN                   | REFPIECE_IDX              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*454 |                   TABLE ACCESS BY INDEX ROWID          | G_CF_CONTRACT             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 455 |                  BUFFER SORT                           |                           |      0 |      7 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*456 |                   INDEX RANGE SCAN                     | G_DOSSIER_RL_CD_RD_RF_IDX |      0 |      7 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*457 |                 TABLE ACCESS BY INDEX ROWID BATCHED    | G_ELEMFI                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*458 |                  INDEX RANGE SCAN                      | GE_REFDOSS_DTANNUL_IDX    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*459 |                INDEX RANGE SCAN                        | TECR_REFELEM              |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*460 |               TABLE ACCESS BY INDEX ROWID              | T_ECRDOS                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 461 |              NESTED LOOPS                              |                           |      0 |      1 |     7   (0)|      0 |00:00:00.01 |       0 |      0 |
| 462 |               NESTED LOOPS                             |                           |      0 |      2 |     7   (0)|      0 |00:00:00.01 |       0 |      0 |
| 463 |                NESTED LOOPS                            |                           |      0 |      1 |     6   (0)|      0 |00:00:00.01 |       0 |      0 |
| 464 |                 MERGE JOIN CARTESIAN                   |                           |      0 |      1 |     5   (0)|      0 |00:00:00.01 |       0 |      0 |
| 465 |                  NESTED LOOPS                          |                           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
| 466 |                   NESTED LOOPS                         |                           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
| 467 |                    NESTED LOOPS                        |                           |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
| 468 |                     NESTED LOOPS                       |                           |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*469 |                      INDEX RANGE SCAN                  | DOS_REFDOSS_REFLOT_IDX    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*470 |                      INDEX UNIQUE SCAN                 | DOS_REFDOSS               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 471 |                     TABLE ACCESS BY INDEX ROWID BATCHED| G_PIECE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*472 |                      INDEX RANGE SCAN                  | PIE_REFDOSS               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*473 |                    INDEX UNIQUE SCAN                   | REFPIECE_IDX              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*474 |                   TABLE ACCESS BY INDEX ROWID          | G_CF_CONTRACT             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 475 |                  BUFFER SORT                           |                           |      0 |      7 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*476 |                   INDEX RANGE SCAN                     | G_DOSSIER_RL_CD_RD_RF_IDX |      0 |      7 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*477 |                 TABLE ACCESS BY INDEX ROWID BATCHED    | G_ELEMFI                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*478 |                  INDEX RANGE SCAN                      | G_ELEMFI_DOS_TYP_FG02     |      0 |      3 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*479 |                INDEX RANGE SCAN                        | TECR_REFELEM              |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*480 |               TABLE ACCESS BY INDEX ROWID              | T_ECRDOS                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 481 |            BUFFER SORT                                 |                           |      0 |      1 |    15   (0)|      0 |00:00:00.01 |       0 |      0 |
|*482 |             INDEX RANGE SCAN                           | PK_G_ETUDE                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 483 |         TABLE ACCESS BY INDEX ROWID                    | G_ELEMFI                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*484 |          INDEX UNIQUE SCAN                             | EFI_REFELEM               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 485 |        VIEW                                            | V_TDOMAINE                |      0 |    495 |    11   (0)|      0 |00:00:00.01 |       0 |      0 |
| 486 |         UNION-ALL                                      |                           |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*487 |          FILTER                                        |                           |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 488 |           TABLE ACCESS BY INDEX ROWID BATCHED          | V_DOMAINE                 |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*489 |            INDEX RANGE SCAN                            | V_DOMAINE_TYPE_CODE_IDX   |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*490 |          FILTER                                        |                           |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 491 |           TABLE ACCESS BY INDEX ROWID BATCHED          | V_DOMAINE                 |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*492 |            INDEX RANGE SCAN                            | V_DOMAINE_TYPE_CODE_IDX   |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*493 |          FILTER                                        |                           |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 494 |           TABLE ACCESS BY INDEX ROWID BATCHED          | V_DOMAINE                 |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*495 |            INDEX RANGE SCAN                            | V_DOMAINE_TYPE_CODE_IDX   |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*496 |          FILTER                                        |                           |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 497 |           TABLE ACCESS BY INDEX ROWID BATCHED          | V_DOMAINE                 |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*498 |            INDEX RANGE SCAN                            | V_DOMAINE_TYPE_CODE_IDX   |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*499 |          FILTER                                        |                           |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 500 |           TABLE ACCESS BY INDEX ROWID BATCHED          | V_DOMAINE                 |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*501 |            INDEX RANGE SCAN                            | V_DOMAINE_TYPE_CODE_IDX   |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*502 |          FILTER                                        |                           |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 503 |           TABLE ACCESS BY INDEX ROWID BATCHED          | V_DOMAINE                 |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*504 |            INDEX RANGE SCAN                            | V_DOMAINE_TYPE_CODE_IDX   |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*505 |          FILTER                                        |                           |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 506 |           TABLE ACCESS BY INDEX ROWID BATCHED          | V_DOMAINE                 |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*507 |            INDEX RANGE SCAN                            | V_DOMAINE_TYPE_CODE_IDX   |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*508 |          FILTER                                        |                           |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 509 |           TABLE ACCESS BY INDEX ROWID BATCHED          | V_DOMAINE                 |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*510 |            INDEX RANGE SCAN                            | V_DOMAINE_TYPE_CODE_IDX   |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*511 |          FILTER                                        |                           |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 512 |           TABLE ACCESS BY INDEX ROWID BATCHED          | V_DOMAINE                 |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*513 |            INDEX RANGE SCAN                            | V_DOMAINE_TYPE_CODE_IDX   |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*514 |          FILTER                                        |                           |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 515 |           TABLE ACCESS BY INDEX ROWID BATCHED          | V_DOMAINE                 |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*516 |            INDEX RANGE SCAN                            | V_DOMAINE_TYPE_CODE_IDX   |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*517 |          FILTER                                        |                           |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 518 |           TABLE ACCESS BY INDEX ROWID BATCHED          | V_DOMAINE                 |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*519 |            INDEX RANGE SCAN                            | V_DOMAINE_TYPE_CODE_IDX   |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
--------------------------------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   1 - filter("RNUM">=:B4)
   2 - filter(ROWNUM<=:B3)
   4 - filter(ROWNUM<=:B3)
   8 - access("T"."REFDOSS"=:B1 AND "T"."REFTYPE"='DB')
   9 - access("T"."REFINDIVIDU"="I"."REFINDIVIDU")
  11 - access("D"."ABREV"=CASE  WHEN ((("V"."TYPENCAISS"='e_saencaiss') OR ("V"."TYPENCAISS"='exchange_diff_saf')) AND ("V"."TP"='E')) THEN 'PD' WHEN
              ((("V"."TYPENCAISS"='e_saencaiss') OR ("V"."TYPENCAISS"='exchange_diff_saf')) AND ("V"."TP"='A')) THEN 'PD_ANN' WHEN (("V"."TYPENCAISS"='ptf_reconcil_saf')
              AND ("E"."LIBELLE"='De-allocated Payments')) THEN 'DEALL_PMT' WHEN (("V"."TYPENCAISS"='ptf_reconcil_saf') AND ("E"."LIBELLE"='Solde de Ptf suite
              Reconcil')) THEN 'SOLDE_PTF' END )
  15 - filter(("ENC"."REFDOSS"=DECODE("ENC"."TYPENCAISS",'e_saencaiss',DECODE("ENC"."CREATEUR",'DB_POSITIONS',"ENC"."REFDOSS",'DB_POSITIONS_ABS',"ENC"."REFD
              OSS","AMTDCPT"."REFDOSS"),"ENC"."REFDOSS") AND (DECODE("ENC"."TYPENCAISS",'e_saencaiss',DECODE("ENC"."CREATEUR",'DB_POSITIONS','RFIN','DB_POSITIONS_ABS','RF
              IN',"AMTDCPT"."CODECR"),'RFIN')='RFIN' OR DECODE("ENC"."TYPENCAISS",'e_saencaiss',DECODE("ENC"."CREATEUR",'DB_POSITIONS','RFIN','DB_POSITIONS_ABS','RFIN',"A
              MTDCPT"."CODECR"),'RFIN')='ENCAT')))
  21 - access("DECO"."REFDOSS"=:B1)
  22 - access("DECO"."REFLOT"="CONTR"."REFDOSS")
  23 - access("CMP"."REFLOT"=:B1 AND "CMP"."CATEGDOSS" LIKE 'COMPTE%')
       filter("CMP"."CATEGDOSS" LIKE 'COMPTE%')
  24 - filter(("ENC"."DTMARQUE_DT" IS NULL AND INTERNAL_FUNCTION("ENC"."TYPENCAISS") AND
              DECODE("ENC"."TYPENCAISS",'e_saencaiss',"ENC"."MOYENPAIMT",'PAIEMENT DECLARE')='PAIEMENT DECLARE' AND TO_NUMBER("ENC"."TRAITE")=2 AND
              NVL("ENC"."CREATEUR",'x')<>'e_lettrage2_PTCX'))
  25 - access("ENC"."REFDOSS"="CMP"."REFDOSS" AND "ENC"."REC_GRP_PMTSAF"='NP')
  26 - filter(("AMTDCPT"."TYPELEM"=DECODE("ENC"."CREATEUR",'DB_POSITIONS','x','DB_POSITIONS_ABS','x','e') AND "AMTDCPT"."REJET" IS NULL))
  27 - access("AMTDCPT"."REFELEM"="ENC"."REFENCAISS")
  28 - filter((DECODE("ENC"."TYPENCAISS",'e_saencaiss',DECODE("ENC"."CREATEUR",'DB_POSITIONS','RFIN','DB_POSITIONS_ABS','RFIN',"AMTDCPT"."CODECR"),'RFIN')='
              RFIN' OR DECODE("ENC"."TYPENCAISS",'e_saencaiss',DECODE("ENC"."CREATEUR",'DB_POSITIONS','RFIN','DB_POSITIONS_ABS','RFIN',"AMTDCPT"."CODECR"),'RFIN')='ENCAT'
              ))
  34 - access("DECO"."REFDOSS"=:B1)
  35 - access("DECO"."REFLOT"="CONTR"."REFDOSS")
  36 - access("CMP"."REFLOT"=:B1 AND "CMP"."CATEGDOSS" LIKE 'COMPTE%')
       filter("CMP"."CATEGDOSS" LIKE 'COMPTE%')
  37 - filter(("ENC"."DTANNUL_DT" IS NOT NULL AND "ENC"."DTMARQUE_DT" IS NOT NULL AND "ENC"."REC_GRP_ANNSAF"='NP' AND
              DECODE("ENC"."TYPENCAISS",'e_saencaiss',"ENC"."MOYENPAIMT",'PAIEMENT DECLARE')='PAIEMENT DECLARE' AND "ENC"."DTMARQUE_AN_DT" IS NULL AND
              NVL("ENC"."CREATEUR",'x')<>'e_lettrage2_PTCX'))
  38 - access("ENC"."REFDOSS"="CMP"."REFDOSS")
       filter((INTERNAL_FUNCTION("ENC"."TYPENCAISS") AND TO_NUMBER("ENC"."TRAITE")=9))
  39 - filter("AMTDCPT"."REJET" IS NULL)
  40 - access("AMTDCPT"."REFDOSS"="ENC"."REFDOSS" AND "AMTDCPT"."TYPELEM"=DECODE("ENC"."CREATEUR",'DB_POSITIONS','x','DB_POSITIONS_ABS','x','e') AND
              "AMTDCPT"."REFELEM"="ENC"."REFENCAISS")
       filter("AMTDCPT"."REFELEM"="ENC"."REFENCAISS")
  48 - access("DECO"."REFDOSS"=:B1)
  49 - access("DECO"."REFLOT"="CONTR"."REFDOSS")
  50 - access("CMP"."REFLOT"=:B1 AND "CMP"."CATEGDOSS" LIKE 'COMPTE%')
       filter("CMP"."CATEGDOSS" LIKE 'COMPTE%')
  51 - filter(("ENC"."DTMARQUE_DT" IS NULL AND "ENC"."CREATEUR"='e_lettrage2_PTCX' AND "ENC"."MOYENPAIMT"='PAIEMENT DECLARE' AND
              "ENC"."TYPENCAISS"='e_saencaiss' AND TO_NUMBER("ENC"."TRAITE")=2))
  52 - access("ENC"."REFDOSS"="CMP"."REFDOSS" AND "ENC"."REC_GRP_PMTSAF"='NP')
  53 - access("AMTDCPT"."REFDOSS"="ENC"."REFDOSS" AND "AMTDCPT"."TYPELEM"='e' AND "AMTDCPT"."CODECR"='RFIN' AND "AMTDCPT"."REFELEM"="ENC"."REFENCAISS")
  55 - access("DBTFA"."DF_REFINIT"="ENC"."REFENCAISS" AND "DBTFA"."DF_NOM"='RINDS')
  56 - access("RINDS"."REFELEM"="DBTFA"."DF_NUM")
  57 - filter("RINDS"."CODECR"='RINDS')
  65 - access("DECO"."REFDOSS"=:B1)
  66 - access("DECO"."REFLOT"="CONTR"."REFDOSS")
  67 - access("CMP"."REFLOT"=:B1 AND "CMP"."CATEGDOSS" LIKE 'COMPTE%')
       filter("CMP"."CATEGDOSS" LIKE 'COMPTE%')
  68 - filter(("ENC"."DTANNUL_DT" IS NOT NULL AND "ENC"."DTMARQUE_DT" IS NOT NULL AND "ENC"."REC_GRP_ANNSAF"='NP' AND "ENC"."CREATEUR"='e_lettrage2_PTCX'
              AND "ENC"."MOYENPAIMT"='PAIEMENT DECLARE' AND "ENC"."DTMARQUE_AN_DT" IS NULL))
  69 - access("ENC"."REFDOSS"="CMP"."REFDOSS" AND "ENC"."TYPENCAISS"='e_saencaiss')
       filter(("ENC"."TYPENCAISS"='e_saencaiss' AND TO_NUMBER("ENC"."TRAITE")=9))
  70 - access("AMTDCPT"."REFDOSS"="ENC"."REFDOSS" AND "AMTDCPT"."TYPELEM"='e' AND "AMTDCPT"."CODECR"='RFIN' AND "AMTDCPT"."REFELEM"="ENC"."REFENCAISS")
  72 - access("DBTFA"."DF_REFINIT"="ENC"."REFENCAISS" AND "DBTFA"."DF_NOM"='RINDS')
  73 - access("RINDS"."REFELEM"="DBTFA"."DF_NUM")
  74 - filter("RINDS"."CODECR"='RINDS')
  75 - filter(NULL IS NOT NULL)
  81 - access("DECO"."REFDOSS"=:B1)
  82 - access("DECO"."REFLOT"="CONTR"."REFDOSS")
  83 - access("CMP"."REFLOT"=:B1 AND "CMP"."CATEGDOSS" LIKE 'COMPTE%')
       filter("CMP"."CATEGDOSS" LIKE 'COMPTE%')
  84 - filter(("FI"."REC_GRP_CNSAF"='NP' AND "FI"."DTMARQUE_DT" IS NULL AND DECODE(INTERNAL_FUNCTION("FI"."DTMARQUE_DT"),NULL,"FI"."DTANNUL_DT",NULL) IS
              NULL))
  85 - access("FI"."REFDOSS"="CMP"."REFDOSS")
       filter(("FI"."TYPE"='DRAFT' OR "FI"."TYPE"='SAF CN COMP' OR "FI"."TYPE"='SAF_NMP_CANCEL'))
  86 - access("AMTMEMO"."REFELEM"="FI"."REFELEM")
  87 - filter(("FI"."REFDOSS"="AMTMEMO"."REFDOSS" AND NVL("AMTMEMO"."CODECR",'x')='PRIN'))
  88 - filter(NULL IS NOT NULL)
  94 - access("DECO"."REFDOSS"=:B1)
  95 - access("DECO"."REFLOT"="CONTR"."REFDOSS")
  96 - access("CMP"."REFLOT"=:B1 AND "CMP"."CATEGDOSS" LIKE 'COMPTE%')
       filter("CMP"."CATEGDOSS" LIKE 'COMPTE%')
  97 - filter(("FI"."DTMARQUE_DT" IS NOT NULL AND "FI"."REC_GRP_ANSAF"='NP' AND INTERNAL_FUNCTION("FI"."TYPE") AND "FI"."DTMARQUE_AN_DT" IS NULL))
  98 - access("FI"."REFDOSS"="CMP"."REFDOSS")
       filter("FI"."DTANNUL_DT" IS NOT NULL)
  99 - access("AMTMEMO"."REFELEM"="FI"."REFELEM")
 100 - filter(("FI"."REFDOSS"="AMTMEMO"."REFDOSS" AND NVL("AMTMEMO"."CODECR",'x')='APRIN'))
 101 - filter(NULL IS NOT NULL)
 107 - access("DECO"."REFDOSS"=:B1)
 108 - access("DECO"."REFLOT"="CONTR"."REFDOSS")
 109 - access("CMP"."REFLOT"=:B1 AND "CMP"."CATEGDOSS" LIKE 'COMPTE%')
       filter("CMP"."CATEGDOSS" LIKE 'COMPTE%')
 110 - access("ENC"."REFDOSS"="CMP"."REFDOSS" AND "ENC"."TYPENCAISS"='ptf_reconcil_saf')
       filter(("ENC"."TYPENCAISS"='ptf_reconcil_saf' AND TO_NUMBER("ENC"."TRAITE")=2))
 111 - filter("ENC"."DTENCAISS_DT" IS NULL)
 112 - filter(NULL IS NOT NULL)
 120 - access("DECO"."REFDOSS"=:B1)
 121 - access("DECO"."REFLOT"="CONTR"."REFDOSS")
 122 - access("GETDCLI"='C519')
 124 - filter("SC"."FG227"='O')
 125 - access("SC"."REFDOSS"=:B1 AND "SC"."TYPPIECE"='SOUS-CONTRAT')
 127 - access("CMP"."REFLOT"=:B1 AND "CMP"."CATEGDOSS" LIKE 'COMPTE%')
       filter("CMP"."CATEGDOSS" LIKE 'COMPTE%')
 128 - filter(("FI"."REC_GRP_CNSAF"='NP' AND "FI"."DTMARQUE_DT" IS NULL))
 129 - access("FI"."REFDOSS"="CMP"."REFDOSS")
       filter(("FI"."TYPE"='ANNULATION DAVOIRS PAR DES REGLEMENTS' OR "FI"."TYPE"='NON MATCHED PAYMENT ELEMENTS' OR "FI"."TYPE"='POSITIVE LTL DECLARED
              PAYMENTS'))
 130 - access("AMTMEMO"."REFELEM"="FI"."REFELEM")
 131 - filter(("AMTMEMO"."REFDOSS"="FI"."REFDOSS" AND "AMTMEMO"."CODECR"='DPRIN'))
 132 - filter(NULL IS NOT NULL)
 142 - access("DECO"."REFDOSS"=:B1)
 143 - access("DECO"."REFLOT"="CONTR"."REFDOSS")
 145 - access("CTR"."REFDOSS"="CONTR"."REFDOSS" AND "CTR"."TYPPIECE"='CONTRAT')
       filter("CTR"."REFDOSS" IS NOT NULL)
 146 - access("CF"."REFPIECE"="CTR"."REFPIECE")
 147 - filter("CF"."FG_FINBAL"='O')
 149 - access("GETDCLI"='C519')
 151 - access("CMP"."REFLOT"=:B1 AND "CMP"."CATEGDOSS" LIKE 'COMPTE%')
       filter("CMP"."CATEGDOSS" LIKE 'COMPTE%')
 152 - filter(("FI"."REC_GRP_CNSAF"='NP' AND "FI"."DTMARQUE_DT" IS NULL AND DECODE(INTERNAL_FUNCTION("FI"."DTMARQUE_DT"),NULL,"FI"."DTANNUL_DT",NULL) IS
              NULL))
 153 - access("FI"."REFDOSS"="CMP"."REFDOSS")
       filter(("FI"."TYPE"='OPERATION DIVERSE CREDITRICE' OR "FI"."TYPE"='OPERATION DIVERSE DEBITRICE'))
 154 - access("AMTMEMO"."REFELEM"="FI"."REFELEM")
 155 - filter(("FI"."REFDOSS"="AMTMEMO"."REFDOSS" AND NVL("AMTMEMO"."CODECR",'x')='PRIN'))
 156 - filter(NULL IS NOT NULL)
 166 - access("DECO"."REFDOSS"=:B1)
 167 - access("DECO"."REFLOT"="CONTR"."REFDOSS")
 169 - access("CTR"."REFDOSS"="CONTR"."REFDOSS" AND "CTR"."TYPPIECE"='CONTRAT')
       filter("CTR"."REFDOSS" IS NOT NULL)
 170 - access("CF"."REFPIECE"="CTR"."REFPIECE")
 171 - filter("CF"."FG_FINBAL"='O')
 173 - access("GETDCLI"='C519')
 175 - access("CMP"."REFLOT"=:B1 AND "CMP"."CATEGDOSS" LIKE 'COMPTE%')
       filter("CMP"."CATEGDOSS" LIKE 'COMPTE%')
 176 - filter(("FI"."DTMARQUE_DT" IS NOT NULL AND "FI"."REC_GRP_ANSAF"='NP' AND INTERNAL_FUNCTION("FI"."TYPE") AND "FI"."DTMARQUE_AN_DT" IS NULL))
 177 - access("FI"."REFDOSS"="CMP"."REFDOSS")
       filter("FI"."DTANNUL_DT" IS NOT NULL)
 178 - access("AMTMEMO"."REFELEM"="FI"."REFELEM")
 179 - filter(("FI"."REFDOSS"="AMTMEMO"."REFDOSS" AND NVL("AMTMEMO"."CODECR",'x')='APRIN'))
 180 - filter(NULL IS NOT NULL)
 190 - access("DECO"."REFDOSS"=:B1)
 191 - access("DECO"."REFLOT"="CONTR"."REFDOSS")
 193 - access("CTR"."REFDOSS"="CONTR"."REFDOSS" AND "CTR"."TYPPIECE"='CONTRAT')
       filter("CTR"."REFDOSS" IS NOT NULL)
 194 - access("CF"."REFPIECE"="CTR"."REFPIECE")
 195 - filter("CF"."FG_FINBAL"='O')
 197 - access("GETDCLI"='C519')
 199 - access("CMP"."REFLOT"=:B1 AND "CMP"."CATEGDOSS" LIKE 'COMPTE%')
       filter("CMP"."CATEGDOSS" LIKE 'COMPTE%')
 200 - filter(("FI"."REC_GRP_CNSAF"='NP' AND "FI"."DTMARQUE_DT" IS NULL AND DECODE(INTERNAL_FUNCTION("FI"."DTMARQUE_DT"),NULL,"FI"."DTANNUL_DT",NULL) IS
              NULL))
 201 - access("FI"."REFDOSS"="CMP"."REFDOSS")
       filter(("FI"."TYPE"='ANNULATION ODC' OR "FI"."TYPE"='ANNULATION ODD'))
 202 - access("AMTMEMO"."REFELEM"="FI"."REFELEM")
 203 - filter(("FI"."REFDOSS"="AMTMEMO"."REFDOSS" AND NVL("AMTMEMO"."CODECR",'x')='DPRIN'))
 204 - filter(NULL IS NOT NULL)
 214 - access("DECO"."REFDOSS"=:B1)
 215 - access("DECO"."REFLOT"="CONTR"."REFDOSS")
 217 - access("CTR"."REFDOSS"="CONTR"."REFDOSS" AND "CTR"."TYPPIECE"='CONTRAT')
       filter("CTR"."REFDOSS" IS NOT NULL)
 218 - access("CF"."REFPIECE"="CTR"."REFPIECE")
 219 - filter("CF"."FG_FINBAL"='O')
 221 - access("GETDCLI"='C519')
 223 - access("CMP"."REFLOT"=:B1 AND "CMP"."CATEGDOSS" LIKE 'COMPTE%')
       filter("CMP"."CATEGDOSS" LIKE 'COMPTE%')
 224 - filter(("FI"."DTMARQUE_DT" IS NOT NULL AND "FI"."REC_GRP_ANSAF"='NP' AND INTERNAL_FUNCTION("FI"."TYPE") AND "FI"."DTMARQUE_AN_DT" IS NULL))
 225 - access("FI"."REFDOSS"="CMP"."REFDOSS")
       filter("FI"."DTANNUL_DT" IS NOT NULL)
 226 - access("AMTMEMO"."REFELEM"="FI"."REFELEM")
 227 - filter(("FI"."REFDOSS"="AMTMEMO"."REFDOSS" AND NVL("AMTMEMO"."CODECR",'x')='ADPRI'))
 229 - access("E"."REFENCAISS"="V"."REFENCAISS")
 232 - filter('AL'=:B2)
 234 - access("TYPE"='MISC_TRANSLATIONS')
 235 - filter('AN'=:B2)
 237 - access("TYPE"='MISC_TRANSLATIONS')
 238 - filter('DA'=:B2)
 240 - access("TYPE"='MISC_TRANSLATIONS')
 241 - filter('ES'=:B2)
 243 - access("TYPE"='MISC_TRANSLATIONS')
 244 - filter('FI'=:B2)
 246 - access("TYPE"='MISC_TRANSLATIONS')
 247 - filter('FR'=:B2)
 249 - access("TYPE"='MISC_TRANSLATIONS')
 250 - filter('HU'=:B2)
 252 - access("TYPE"='MISC_TRANSLATIONS')
 253 - filter('IT'=:B2)
 255 - access("TYPE"='MISC_TRANSLATIONS')
 256 - filter('NL'=:B2)
 258 - access("TYPE"='MISC_TRANSLATIONS')
 259 - filter('NO'=:B2)
 261 - access("TYPE"='MISC_TRANSLATIONS')
 262 - filter('PT'=:B2)
 264 - access("TYPE"='MISC_TRANSLATIONS')
 267 - access("T"."REFDOSS"=:B1 AND "T"."REFTYPE"='DB')
 268 - access("T"."REFINDIVIDU"="I"."REFINDIVIDU")
 270 - access("D"."ABREV"=CASE  WHEN (("V"."TP"='F') AND ("F"."TYPE"='SAF CN COMP')) THEN 'SAFCNCOMP' WHEN (("V"."TP"='F') AND
              ("F"."TYPE"='SAF_NMP_CANCEL')) THEN 'SAFNMPCANCEL' WHEN (("V"."TP"='F') AND ("F"."TYPE"='NON MATCHED PAYMENT ELEMENTS')) THEN 'EPNL' WHEN (("V"."TP"='F')
              AND ("F"."TYPE"='POSITIVE LTL DECLARED PAYMENTS')) THEN 'PDPL' WHEN (("V"."TP"='F') AND ("F"."TYPE"='ANNULATION DAVOIRS PAR DES REGLEMENTS')) THEN 'AAVR'
              WHEN (("V"."TP"='F') AND ("F"."TYPE"='OPERATION DIVERSE CREDITRICE')) THEN 'ODC' WHEN (("V"."TP"='C') AND ("F"."TYPE"='SAF CN COMP')) THEN 'ANN_SAF' WHEN
              (("V"."TP"='C') AND ("F"."TYPE"='SAF_NMP_CANCEL')) THEN 'ANN_SAFNMP' WHEN (("V"."TP"='C') AND ("F"."TYPE"='DRAFT')) THEN 'ANN_DRAFT' ELSE "F"."TYPE" END )
 274 - filter(NULL IS NOT NULL)
 275 - filter(("ENC"."REFDOSS"=DECODE("ENC"."TYPENCAISS",'e_saencaiss',DECODE("ENC"."CREATEUR",'DB_POSITIONS',"ENC"."REFDOSS",'DB_POSITIONS_ABS',"ENC"."REFD
              OSS","AMTDCPT"."REFDOSS"),"ENC"."REFDOSS") AND (DECODE("ENC"."TYPENCAISS",'e_saencaiss',DECODE("ENC"."CREATEUR",'DB_POSITIONS','RFIN','DB_POSITIONS_ABS','RF
              IN',"AMTDCPT"."CODECR"),'RFIN')='RFIN' OR DECODE("ENC"."TYPENCAISS",'e_saencaiss',DECODE("ENC"."CREATEUR",'DB_POSITIONS','RFIN','DB_POSITIONS_ABS','RFIN',"A
              MTDCPT"."CODECR"),'RFIN')='ENCAT')))
 281 - access("DECO"."REFDOSS"=:B1)
 282 - access("DECO"."REFLOT"="CONTR"."REFDOSS")
 283 - access("CMP"."REFLOT"=:B1 AND "CMP"."CATEGDOSS" LIKE 'COMPTE%')
       filter("CMP"."CATEGDOSS" LIKE 'COMPTE%')
 284 - filter(("ENC"."DTMARQUE_DT" IS NULL AND INTERNAL_FUNCTION("ENC"."TYPENCAISS") AND
              DECODE("ENC"."TYPENCAISS",'e_saencaiss',"ENC"."MOYENPAIMT",'PAIEMENT DECLARE')='PAIEMENT DECLARE' AND (TO_NUMBER("ENC"."TRAITE")=2 OR ("ENC"."DTANNUL_DT"
              IS NOT NULL AND TO_NUMBER("ENC"."TRAITE")=9)) AND NVL("ENC"."CREATEUR",'x')<>'e_lettrage2_PTCX'))
 285 - access("ENC"."REFDOSS"="CMP"."REFDOSS" AND "ENC"."REC_GRP_PMTSAF"='NP')
 286 - filter(("AMTDCPT"."TYPELEM"=DECODE("ENC"."CREATEUR",'DB_POSITIONS','x','DB_POSITIONS_ABS','x','e') AND "AMTDCPT"."REJET" IS NULL))
 287 - access("AMTDCPT"."REFELEM"="ENC"."REFENCAISS")
 288 - filter(NULL IS NOT NULL)
 289 - filter((DECODE("ENC"."TYPENCAISS",'e_saencaiss',DECODE("ENC"."CREATEUR",'DB_POSITIONS','RFIN','DB_POSITIONS_ABS','RFIN',"AMTDCPT"."CODECR"),'RFIN')='
              RFIN' OR DECODE("ENC"."TYPENCAISS",'e_saencaiss',DECODE("ENC"."CREATEUR",'DB_POSITIONS','RFIN','DB_POSITIONS_ABS','RFIN',"AMTDCPT"."CODECR"),'RFIN')='ENCAT'
              ))
 295 - access("DECO"."REFDOSS"=:B1)
 296 - access("DECO"."REFLOT"="CONTR"."REFDOSS")
 297 - access("CMP"."REFLOT"=:B1 AND "CMP"."CATEGDOSS" LIKE 'COMPTE%')
       filter("CMP"."CATEGDOSS" LIKE 'COMPTE%')
 298 - filter(("ENC"."DTANNUL_DT" IS NOT NULL AND "ENC"."DTMARQUE_DT" IS NOT NULL AND "ENC"."REC_GRP_ANNSAF"='NP' AND
              DECODE("ENC"."TYPENCAISS",'e_saencaiss',"ENC"."MOYENPAIMT",'PAIEMENT DECLARE')='PAIEMENT DECLARE' AND "ENC"."DTMARQUE_AN_DT" IS NULL AND
              NVL("ENC"."CREATEUR",'x')<>'e_lettrage2_PTCX'))
 299 - access("ENC"."REFDOSS"="CMP"."REFDOSS")
       filter((INTERNAL_FUNCTION("ENC"."TYPENCAISS") AND TO_NUMBER("ENC"."TRAITE")=9))
 300 - filter("AMTDCPT"."REJET" IS NULL)
 301 - access("AMTDCPT"."REFDOSS"="ENC"."REFDOSS" AND "AMTDCPT"."TYPELEM"=DECODE("ENC"."CREATEUR",'DB_POSITIONS','x','DB_POSITIONS_ABS','x','e') AND
              "AMTDCPT"."REFELEM"="ENC"."REFENCAISS")
       filter("AMTDCPT"."REFELEM"="ENC"."REFENCAISS")
 302 - filter(NULL IS NOT NULL)
 310 - access("DECO"."REFDOSS"=:B1)
 311 - access("DECO"."REFLOT"="CONTR"."REFDOSS")
 312 - access("CMP"."REFLOT"=:B1 AND "CMP"."CATEGDOSS" LIKE 'COMPTE%')
       filter("CMP"."CATEGDOSS" LIKE 'COMPTE%')
 313 - filter(("ENC"."DTMARQUE_DT" IS NULL AND "ENC"."CREATEUR"='e_lettrage2_PTCX' AND "ENC"."MOYENPAIMT"='PAIEMENT DECLARE' AND
              "ENC"."TYPENCAISS"='e_saencaiss' AND (TO_NUMBER("ENC"."TRAITE")=2 OR ("ENC"."DTANNUL_DT" IS NOT NULL AND TO_NUMBER("ENC"."TRAITE")=9))))
 314 - access("ENC"."REFDOSS"="CMP"."REFDOSS" AND "ENC"."REC_GRP_PMTSAF"='NP')
 315 - access("AMTDCPT"."REFDOSS"="ENC"."REFDOSS" AND "AMTDCPT"."TYPELEM"='e' AND "AMTDCPT"."CODECR"='RFIN' AND "AMTDCPT"."REFELEM"="ENC"."REFENCAISS")
 317 - access("DBTFA"."DF_REFINIT"="ENC"."REFENCAISS" AND "DBTFA"."DF_NOM"='RINDS')
 318 - access("RINDS"."REFELEM"="DBTFA"."DF_NUM")
 319 - filter("RINDS"."CODECR"='RINDS')
 320 - filter(NULL IS NOT NULL)
 328 - access("DECO"."REFDOSS"=:B1)
 329 - access("DECO"."REFLOT"="CONTR"."REFDOSS")
 330 - access("CMP"."REFLOT"=:B1 AND "CMP"."CATEGDOSS" LIKE 'COMPTE%')
       filter("CMP"."CATEGDOSS" LIKE 'COMPTE%')
 331 - filter(("ENC"."DTANNUL_DT" IS NOT NULL AND "ENC"."DTMARQUE_DT" IS NOT NULL AND "ENC"."REC_GRP_ANNSAF"='NP' AND "ENC"."CREATEUR"='e_lettrage2_PTCX'
              AND "ENC"."MOYENPAIMT"='PAIEMENT DECLARE' AND "ENC"."DTMARQUE_AN_DT" IS NULL))
 332 - access("ENC"."REFDOSS"="CMP"."REFDOSS" AND "ENC"."TYPENCAISS"='e_saencaiss')
       filter(("ENC"."TYPENCAISS"='e_saencaiss' AND TO_NUMBER("ENC"."TRAITE")=9))
 333 - access("AMTDCPT"."REFDOSS"="ENC"."REFDOSS" AND "AMTDCPT"."TYPELEM"='e' AND "AMTDCPT"."CODECR"='RFIN' AND "AMTDCPT"."REFELEM"="ENC"."REFENCAISS")
 335 - access("DBTFA"."DF_REFINIT"="ENC"."REFENCAISS" AND "DBTFA"."DF_NOM"='RINDS')
 336 - access("RINDS"."REFELEM"="DBTFA"."DF_NUM")
 337 - filter("RINDS"."CODECR"='RINDS')
 343 - access("DECO"."REFDOSS"=:B1)
 344 - access("DECO"."REFLOT"="CONTR"."REFDOSS")
 345 - access("CMP"."REFLOT"=:B1 AND "CMP"."CATEGDOSS" LIKE 'COMPTE%')
       filter("CMP"."CATEGDOSS" LIKE 'COMPTE%')
 346 - filter(("FI"."REC_GRP_CNSAF"='NP' AND "FI"."DTMARQUE_DT" IS NULL AND DECODE(INTERNAL_FUNCTION("FI"."DTMARQUE_DT"),NULL,"FI"."DTANNUL_DT",NULL) IS
              NULL))
 347 - access("FI"."REFDOSS"="CMP"."REFDOSS")
       filter(("FI"."TYPE"='DRAFT' OR "FI"."TYPE"='SAF CN COMP' OR "FI"."TYPE"='SAF_NMP_CANCEL'))
 348 - access("AMTMEMO"."REFELEM"="FI"."REFELEM")
 349 - filter(("FI"."REFDOSS"="AMTMEMO"."REFDOSS" AND NVL("AMTMEMO"."CODECR",'x')='PRIN'))
 355 - access("DECO"."REFDOSS"=:B1)
 356 - access("DECO"."REFLOT"="CONTR"."REFDOSS")
 357 - access("CMP"."REFLOT"=:B1 AND "CMP"."CATEGDOSS" LIKE 'COMPTE%')
       filter("CMP"."CATEGDOSS" LIKE 'COMPTE%')
 358 - filter(("FI"."DTMARQUE_DT" IS NOT NULL AND "FI"."REC_GRP_ANSAF"='NP' AND INTERNAL_FUNCTION("FI"."TYPE") AND "FI"."DTMARQUE_AN_DT" IS NULL))
 359 - access("FI"."REFDOSS"="CMP"."REFDOSS")
       filter("FI"."DTANNUL_DT" IS NOT NULL)
 360 - access("AMTMEMO"."REFELEM"="FI"."REFELEM")
 361 - filter(("FI"."REFDOSS"="AMTMEMO"."REFDOSS" AND NVL("AMTMEMO"."CODECR",'x')='APRIN'))
 362 - filter((NULL IS NOT NULL AND NULL IS NOT NULL))
 368 - access("DECO"."REFDOSS"=:B1)
 369 - access("DECO"."REFLOT"="CONTR"."REFDOSS")
 370 - access("CMP"."REFLOT"=:B1 AND "CMP"."CATEGDOSS" LIKE 'COMPTE%')
       filter("CMP"."CATEGDOSS" LIKE 'COMPTE%')
 371 - access("ENC"."REFDOSS"="CMP"."REFDOSS" AND "ENC"."TYPENCAISS"='ptf_reconcil_saf')
       filter(("ENC"."TYPENCAISS"='ptf_reconcil_saf' AND TO_NUMBER("ENC"."TRAITE")=2))
 372 - filter("ENC"."DTENCAISS_DT" IS NULL)
 380 - access("DECO"."REFDOSS"=:B1)
 381 - access("DECO"."REFLOT"="CONTR"."REFDOSS")
 382 - access("GETDCLI"='C519')
 384 - filter("SC"."FG227"='O')
 385 - access("SC"."REFDOSS"=:B1 AND "SC"."TYPPIECE"='SOUS-CONTRAT')
 387 - access("CMP"."REFLOT"=:B1 AND "CMP"."CATEGDOSS" LIKE 'COMPTE%')
       filter("CMP"."CATEGDOSS" LIKE 'COMPTE%')
 388 - filter(("FI"."REC_GRP_CNSAF"='NP' AND "FI"."DTMARQUE_DT" IS NULL))
 389 - access("FI"."REFDOSS"="CMP"."REFDOSS")
       filter(("FI"."TYPE"='ANNULATION DAVOIRS PAR DES REGLEMENTS' OR "FI"."TYPE"='NON MATCHED PAYMENT ELEMENTS' OR "FI"."TYPE"='POSITIVE LTL DECLARED
              PAYMENTS'))
 390 - access("AMTMEMO"."REFELEM"="FI"."REFELEM")
 391 - filter(("AMTMEMO"."REFDOSS"="FI"."REFDOSS" AND "AMTMEMO"."CODECR"='DPRIN'))
 401 - access("DECO"."REFDOSS"=:B1)
 402 - access("DECO"."REFLOT"="CONTR"."REFDOSS")
 404 - access("CTR"."REFDOSS"="CONTR"."REFDOSS" AND "CTR"."TYPPIECE"='CONTRAT')
       filter("CTR"."REFDOSS" IS NOT NULL)
 405 - access("CF"."REFPIECE"="CTR"."REFPIECE")
 406 - filter("CF"."FG_FINBAL"='O')
 408 - access("GETDCLI"='C519')
 410 - access("CMP"."REFLOT"=:B1 AND "CMP"."CATEGDOSS" LIKE 'COMPTE%')
       filter("CMP"."CATEGDOSS" LIKE 'COMPTE%')
 411 - filter(("FI"."REC_GRP_CNSAF"='NP' AND "FI"."DTMARQUE_DT" IS NULL AND DECODE(INTERNAL_FUNCTION("FI"."DTMARQUE_DT"),NULL,"FI"."DTANNUL_DT",NULL) IS
              NULL))
 412 - access("FI"."REFDOSS"="CMP"."REFDOSS")
       filter(("FI"."TYPE"='OPERATION DIVERSE CREDITRICE' OR "FI"."TYPE"='OPERATION DIVERSE DEBITRICE'))
 413 - access("AMTMEMO"."REFELEM"="FI"."REFELEM")
 414 - filter(("FI"."REFDOSS"="AMTMEMO"."REFDOSS" AND NVL("AMTMEMO"."CODECR",'x')='PRIN'))
 424 - access("DECO"."REFDOSS"=:B1)
 425 - access("DECO"."REFLOT"="CONTR"."REFDOSS")
 427 - access("CTR"."REFDOSS"="CONTR"."REFDOSS" AND "CTR"."TYPPIECE"='CONTRAT')
       filter("CTR"."REFDOSS" IS NOT NULL)
 428 - access("CF"."REFPIECE"="CTR"."REFPIECE")
 429 - filter("CF"."FG_FINBAL"='O')
 431 - access("GETDCLI"='C519')
 433 - access("CMP"."REFLOT"=:B1 AND "CMP"."CATEGDOSS" LIKE 'COMPTE%')
       filter("CMP"."CATEGDOSS" LIKE 'COMPTE%')
 434 - filter(("FI"."DTMARQUE_DT" IS NOT NULL AND "FI"."REC_GRP_ANSAF"='NP' AND INTERNAL_FUNCTION("FI"."TYPE") AND "FI"."DTMARQUE_AN_DT" IS NULL))
 435 - access("FI"."REFDOSS"="CMP"."REFDOSS")
       filter("FI"."DTANNUL_DT" IS NOT NULL)
 436 - access("AMTMEMO"."REFELEM"="FI"."REFELEM")
 437 - filter(("FI"."REFDOSS"="AMTMEMO"."REFDOSS" AND NVL("AMTMEMO"."CODECR",'x')='ADPRI'))
 449 - access("DECO"."REFDOSS"=:B1)
 450 - access("DECO"."REFLOT"="CONTR"."REFDOSS")
 452 - access("CTR"."REFDOSS"="CONTR"."REFDOSS" AND "CTR"."TYPPIECE"='CONTRAT')
       filter("CTR"."REFDOSS" IS NOT NULL)
 453 - access("CF"."REFPIECE"="CTR"."REFPIECE")
 454 - filter("CF"."FG_FINBAL"='O')
 456 - access("CMP"."REFLOT"=:B1 AND "CMP"."CATEGDOSS" LIKE 'COMPTE%')
       filter("CMP"."CATEGDOSS" LIKE 'COMPTE%')
 457 - filter(("FI"."DTMARQUE_DT" IS NOT NULL AND "FI"."REC_GRP_ANSAF"='NP' AND INTERNAL_FUNCTION("FI"."TYPE") AND "FI"."DTMARQUE_AN_DT" IS NULL))
 458 - access("FI"."REFDOSS"="CMP"."REFDOSS")
       filter("FI"."DTANNUL_DT" IS NOT NULL)
 459 - access("AMTMEMO"."REFELEM"="FI"."REFELEM")
 460 - filter(("FI"."REFDOSS"="AMTMEMO"."REFDOSS" AND NVL("AMTMEMO"."CODECR",'x')='APRIN'))
 469 - access("DECO"."REFDOSS"=:B1)
 470 - access("DECO"."REFLOT"="CONTR"."REFDOSS")
 472 - access("CTR"."REFDOSS"="CONTR"."REFDOSS" AND "CTR"."TYPPIECE"='CONTRAT')
       filter("CTR"."REFDOSS" IS NOT NULL)
 473 - access("CF"."REFPIECE"="CTR"."REFPIECE")
 474 - filter("CF"."FG_FINBAL"='O')
 476 - access("CMP"."REFLOT"=:B1 AND "CMP"."CATEGDOSS" LIKE 'COMPTE%')
       filter("CMP"."CATEGDOSS" LIKE 'COMPTE%')
 477 - filter(("FI"."REC_GRP_CNSAF"='NP' AND "FI"."DTMARQUE_DT" IS NULL AND DECODE(INTERNAL_FUNCTION("FI"."DTMARQUE_DT"),NULL,"FI"."DTANNUL_DT",NULL) IS
              NULL))
 478 - access("FI"."REFDOSS"="CMP"."REFDOSS")
       filter(("FI"."TYPE"='ANNULATION ODC' OR "FI"."TYPE"='ANNULATION ODD'))
 479 - access("AMTMEMO"."REFELEM"="FI"."REFELEM")
 480 - filter(("FI"."REFDOSS"="AMTMEMO"."REFDOSS" AND NVL("AMTMEMO"."CODECR",'x')='DPRIN'))
 482 - access("GETDCLI"='C519')
 484 - access("F"."REFELEM"="V"."REFENCAISS")
 487 - filter('AL'=:B2)
 489 - access("TYPE"='MISC_TRANSLATIONS')
 490 - filter('AN'=:B2)
 492 - access("TYPE"='MISC_TRANSLATIONS')
 493 - filter('DA'=:B2)
 495 - access("TYPE"='MISC_TRANSLATIONS')
 496 - filter('ES'=:B2)
 498 - access("TYPE"='MISC_TRANSLATIONS')
 499 - filter('FI'=:B2)
 501 - access("TYPE"='MISC_TRANSLATIONS')
 502 - filter('FR'=:B2)
 504 - access("TYPE"='MISC_TRANSLATIONS')
 505 - filter('HU'=:B2)
 507 - access("TYPE"='MISC_TRANSLATIONS')
 508 - filter('IT'=:B2)
 510 - access("TYPE"='MISC_TRANSLATIONS')
 511 - filter('NL'=:B2)
 513 - access("TYPE"='MISC_TRANSLATIONS')
 514 - filter('NO'=:B2)
 516 - access("TYPE"='MISC_TRANSLATIONS')
 517 - filter('PT'=:B2)
 519 - access("TYPE"='MISC_TRANSLATIONS')
*/
/********************************OLD Metrics***************************************/

/********************************New SQL*******************************************/

VAR B1 VARCHAR2(32);
EXEC :B1 := '1506250354';
VAR B2 VARCHAR2(32);
EXEC :B2 := 'AN';
VAR B3 NUMBER;
EXEC :B3 := 2001;
VAR B4 NUMBER;
EXEC :B4 := 1;
               
WITH v AS ( SELECT /*+ no_merge no_push_pred materialize index(@q_002 Enc G_ENC_REFDOSS_GRP_annSAF) index(@q_002 AmtDcpt TECR_REFELEM) index(@q_004 Enc G_ENC_REFDOSS_GRP_annSAF) index(@q_005 Fi ELEMFI_REFDOSS_GRP_CNSAF) */
                   *
              FROM v_pmtsaf_declared
             WHERE refdoss_dcmp = :B1
               AND dtmarque_dt IS NULL 
               AND rec_grp_pmtsaf = 'NP' )
SELECT *
  FROM (SELECT /*+ first_rows(:pageSize)*/
         foo.*, ROWNUM rnum
          FROM (SELECT v.refencaiss AS refEncaiss,
                       v.rec_grp_pmtsaf AS groupPmtSaf,
                       e.encodeur AS groupCreAdj,
                       nvl2(v.dtmarque_dt, 'true', 'false') AS selected,
                       v.typencaiss AS typeMvt,
                       v.tp AS tp,
                       v.pmt_dt AS datePmt,
                       (CASE
                         WHEN (d.valeur_trad IS NOT NULL) THEN
                          d.valeur_trad
                         WHEN v.typencaiss IN
                              ('e_saencaiss', 'exchange_diff_saf') AND
                              v.tp = 'E' THEN
                          'PD'
                         WHEN v.typencaiss IN
                              ('e_saencaiss', 'exchange_diff_saf') AND
                              v.tp = 'A' THEN
                          'PD_ANN'
                         WHEN (v.typencaiss = 'ptf_reconcil_saf' AND
                              e.libelle = 'De-allocated Payments') THEN
                          'DEALL_PMT'
                         WHEN (v.typencaiss = 'ptf_reconcil_saf' AND
                              e.libelle = 'Solde de Ptf suite Reconcil') THEN
                          'SOLDE_PTF'
                       END) AS portfolioPaymentType,
                       v.refdoss AS compteCaseReference,
                       v.MONTANT_DCMP AS portfolioPaymentAmount,
                       (SELECT i.nom
                          FROM t_intervenants t, g_individu i
                         WHERE t.refdoss = e.refdoss
                           AND t.reftype = 'DB'
                           AND t.refindividu = i.refindividu) AS dbName,
                       v.DTMARQUE_DT AS portfolioReconcilationDate,
                       e.dtmarque_dt AS dtmarque
                  FROM v, 
                       g_encaissement e,
                       v_tdomaine d
                 WHERE 1 = 1
                   AND v.refdoss_dcmp = :B1
                   AND v.tp IN ('E', 'A')
                   AND e.refencaiss(+) = v.refencaiss
                   AND d.type(+) = 'MISC_TRANSLATIONS'
                   AND NVL(d.langue(+), 'FR') = :B2
                   AND d.abrev(+) = (CASE
                         WHEN v.typencaiss IN
                              ('e_saencaiss', 'exchange_diff_saf') AND
                              v.tp = 'E' THEN
                          'PD'
                         WHEN v.typencaiss IN
                              ('e_saencaiss', 'exchange_diff_saf') AND
                              v.tp = 'A' THEN
                          'PD_ANN'
                         WHEN (v.typencaiss = 'ptf_reconcil_saf' AND
                              e.libelle = 'De-allocated Payments') THEN
                          'DEALL_PMT'
                         WHEN (v.typencaiss = 'ptf_reconcil_saf' AND
                              e.libelle = 'Solde de Ptf suite Reconcil') THEN
                          'SOLDE_PTF'
                       END)
                   AND (v.dtmarque_dt IS NULL AND v.rec_grp_pmtsaf = 'NP')
                UNION
                SELECT v.refencaiss AS refEncaiss,
                       v.rec_grp_pmtsaf AS groupPmtSaf,
                       NULL AS groupCreAdj,
                       nvl2(v.dtmarque_dt, 'true', 'false') AS selected,
                       v.typencaiss AS typeMvt,
                       v.tp AS tp,
                       v.pmt_dt AS datePmt,
                       (CASE
                         WHEN (d.valeur_trad IS NOT NULL) THEN
                          d.valeur_trad
                         WHEN (v.tp = 'F' AND f.type = 'SAF CN COMP') THEN
                          'SAFCNCOMP'
                         WHEN (v.tp = 'F' AND f.type = 'SAF_NMP_CANCEL') THEN
                          'SAFNMPCANCEL'
                         WHEN (v.tp = 'F' AND
                              f.type = 'NON MATCHED PAYMENT ELEMENTS') THEN
                          'EPNL'
                         WHEN (v.tp = 'F' AND
                              f.type = 'POSITIVE LTL DECLARED PAYMENTS') THEN
                          'PDPL'
                         WHEN (v.tp = 'F' AND
                              f.type =
                              'ANNULATION DAVOIRS PAR DES REGLEMENTS') THEN
                          'AAVR'
                         WHEN (v.tp = 'F' AND
                              f.type = 'OPERATION DIVERSE CREDITRICE') THEN
                          'ODC'
                         WHEN (v.tp = 'C' AND f.type = 'SAF CN COMP') THEN
                          'ANN_SAF'
                         WHEN (v.tp = 'C' AND f.type = 'SAF_NMP_CANCEL') THEN
                          'ANN_SAFNMP'
                         WHEN (v.tp = 'C' AND f.type = 'DRAFT') THEN
                          'ANN_DRAFT'
                         ELSE
                          f.type
                       END) AS portfolioPaymentType,
                       v.refdoss AS compteCaseReference,
                       v.MONTANT_DCMP AS portfolioPaymentAmount,
                       (SELECT i.nom
                          FROM t_intervenants t, 
                               g_individu i
                         WHERE t.refdoss = f.refdoss
                           AND t.reftype = 'DB'
                           AND t.refindividu = i.refindividu) AS dbName,
                       v.dtmarque_dt AS portfolioReconcilationDate,
                       NULL AS dtmarque
                  FROM v, 
                       g_elemfi f, 
                       v_tdomaine d
                 WHERE 1 = 1
                   AND v.refdoss_dcmp = :B1
                   AND v.tp IN ('F', 'C')
                   AND f.refelem(+) = v.refencaiss
                   AND d.type(+) = 'MISC_TRANSLATIONS'
                   AND NVL(d.langue(+), 'FR') = :B2
                   AND d.abrev(+) = (CASE
                         WHEN (v.tp = 'F' AND f.type = 'SAF CN COMP') THEN
                          'SAFCNCOMP'
                         WHEN (v.tp = 'F' AND f.type = 'SAF_NMP_CANCEL') THEN
                          'SAFNMPCANCEL'
                         WHEN (v.tp = 'F' AND
                              f.type = 'NON MATCHED PAYMENT ELEMENTS') THEN
                          'EPNL'
                         WHEN (v.tp = 'F' AND
                              f.type = 'POSITIVE LTL DECLARED PAYMENTS') THEN
                          'PDPL'
                         WHEN (v.tp = 'F' AND
                              f.type =
                              'ANNULATION DAVOIRS PAR DES REGLEMENTS') THEN
                          'AAVR'
                         WHEN (v.tp = 'F' AND
                              f.type = 'OPERATION DIVERSE CREDITRICE') THEN
                          'ODC'
                         WHEN (v.tp = 'C' AND f.type = 'SAF CN COMP') THEN
                          'ANN_SAF'
                         WHEN (v.tp = 'C' AND f.type = 'SAF_NMP_CANCEL') THEN
                          'ANN_SAFNMP'
                         WHEN (v.tp = 'C' AND f.type = 'DRAFT') THEN
                          'ANN_DRAFT'
                         ELSE
                          f.type
                       END)
                   AND (v.dtmarque_dt IS NULL AND v.rec_grp_pmtsaf = 'NP')
                 ORDER BY datePmt DESC, refencaiss) foo
         WHERE 1 = 1
           AND ROWNUM <= :B3)
 WHERE 1 = 1
   AND rnum >= :B4;
/********************************New SQL*******************************************/
/********************************New Metrics***************************************/
/*
Plan hash value: 1834354217
---------------------------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                       | Name                        | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  |
---------------------------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                                |                             |      1 |        |   618 (100)|   2001 |00:00:02.82 |    1177K|      2 |
|   1 |  TEMP TABLE TRANSFORMATION                      |                             |      1 |        |            |   2001 |00:00:02.82 |    1177K|      2 |
|   2 |   LOAD AS SELECT (CURSOR DURATION MEMORY)       | SYS_TEMP_0FD9D680D_1415B2C3 |      1 |        |            |      0 |00:00:02.28 |     801K|      0 |
|   3 |    VIEW                                         | V_PMTSAF_DECLARED           |      1 |     22 |   102  (12)|    118K|00:00:02.14 |     801K|      0 |
|   4 |     UNION-ALL                                   |                             |      1 |        |            |    118K|00:00:02.12 |     801K|      0 |
|   5 |      SORT UNIQUE                                |                             |  14993 |      1 |     4  (50)|  14993 |00:00:00.19 |     104K|      0 |
|   6 |       WINDOW SORT                               |                             |  14993 |      1 |     4  (50)|  14993 |00:00:00.17 |     104K|      0 |
|*  7 |        FILTER                                   |                             |  14993 |        |            |  14993 |00:00:00.13 |     104K|      0 |
|   8 |         NESTED LOOPS                            |                             |  14993 |      1 |     2   (0)|  14993 |00:00:00.12 |     104K|      0 |
|   9 |          NESTED LOOPS                           |                             |  14993 |      1 |     2   (0)|  14993 |00:00:00.09 |   89328 |      0 |
|* 10 |           TABLE ACCESS BY INDEX ROWID BATCHED   | G_VENELEM                   |  14993 |      1 |     1   (0)|  14993 |00:00:00.05 |   46143 |      0 |
|* 11 |            INDEX RANGE SCAN                     | VEN_ENCAIS                  |  14993 |      1 |     1   (0)|  14993 |00:00:00.03 |   37305 |      0 |
|* 12 |           INDEX UNIQUE SCAN                     | EFI_REFELEM                 |  14993 |      1 |     1   (0)|  14993 |00:00:00.03 |   43185 |      0 |
|  13 |          TABLE ACCESS BY INDEX ROWID            | G_ELEMFI                    |  14993 |      1 |     1   (0)|  14993 |00:00:00.03 |   14993 |      0 |
|* 14 |      FILTER                                     |                             |      1 |        |            |  14993 |00:00:00.14 |   63705 |      0 |
|  15 |       NESTED LOOPS OUTER                        |                             |      1 |      6 |     5   (0)|  29986 |00:00:00.13 |   63705 |      0 |
|  16 |        NESTED LOOPS                             |                             |      1 |      6 |     4   (0)|  14993 |00:00:00.05 |   13958 |      0 |
|  17 |         NESTED LOOPS                            |                             |      1 |      7 |     3   (0)|   1864 |00:00:00.01 |      23 |      0 |
|  18 |          NESTED LOOPS                           |                             |      1 |      1 |     2   (0)|      1 |00:00:00.01 |       8 |      0 |
|  19 |           TABLE ACCESS BY INDEX ROWID           | G_DOSSIER                   |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       4 |      0 |
|* 20 |            INDEX UNIQUE SCAN                    | DOS_REFDOSS                 |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |      0 |
|  21 |           TABLE ACCESS BY INDEX ROWID           | G_DOSSIER                   |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       4 |      0 |
|* 22 |            INDEX UNIQUE SCAN                    | DOS_REFDOSS                 |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |      0 |
|* 23 |          INDEX RANGE SCAN                       | G_DOSSIER_RL_CD_RD_RF_IDX   |      1 |      7 |     1   (0)|   1864 |00:00:00.01 |      15 |      0 |
|* 24 |         TABLE ACCESS BY INDEX ROWID BATCHED     | G_ENCAISSEMENT              |   1864 |      1 |     1   (0)|  14993 |00:00:00.04 |   13935 |      0 |
|* 25 |          INDEX RANGE SCAN                       | G_ENC_REFDOSS_GRP_PMTSAF    |   1864 |      6 |     1   (0)|  14993 |00:00:00.01 |    5242 |      0 |
|* 26 |        TABLE ACCESS BY INDEX ROWID BATCHED      | T_ECRDOS                    |  14993 |      1 |     1   (0)|  29986 |00:00:00.07 |   49747 |      0 |
|* 27 |         INDEX RANGE SCAN                        | TECR_REFELEM                |  14993 |      2 |     1   (0)|  29986 |00:00:00.04 |   38966 |      0 |
|  28 |      SORT UNIQUE                                |                             |    102K|      1 |     4  (50)|      0 |00:00:00.32 |   54900 |      0 |
|  29 |       WINDOW SORT                               |                             |    102K|      1 |     4  (50)|      0 |00:00:00.26 |   54900 |      0 |
|* 30 |        FILTER                                   |                             |    102K|        |            |      0 |00:00:00.17 |   54900 |      0 |
|  31 |         NESTED LOOPS                            |                             |    102K|      1 |     2   (0)|      0 |00:00:00.15 |   54900 |      0 |
|  32 |          NESTED LOOPS                           |                             |    102K|      1 |     2   (0)|      0 |00:00:00.13 |   54900 |      0 |
|* 33 |           TABLE ACCESS BY INDEX ROWID BATCHED   | G_VENELEM                   |    102K|      1 |     1   (0)|      0 |00:00:00.11 |   54900 |      0 |
|* 34 |            INDEX RANGE SCAN                     | VEN_ENCAIS                  |    102K|      1 |     1   (0)|      0 |00:00:00.09 |   54900 |      0 |
|* 35 |           INDEX UNIQUE SCAN                     | EFI_REFELEM                 |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|  36 |          TABLE ACCESS BY INDEX ROWID            | G_ELEMFI                    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 37 |      FILTER                                     |                             |      1 |        |            |    102K|00:00:01.13 |     507K|      0 |
|  38 |       NESTED LOOPS OUTER                        |                             |      1 |      6 |     7   (0)|    409K|00:00:01.06 |     507K|      0 |
|  39 |        NESTED LOOPS                             |                             |      1 |      6 |     6   (0)|    102K|00:00:00.23 |   38617 |      0 |
|  40 |         NESTED LOOPS                            |                             |      1 |      7 |     3   (0)|   1864 |00:00:00.01 |      23 |      0 |
|  41 |          NESTED LOOPS                           |                             |      1 |      1 |     2   (0)|      1 |00:00:00.01 |       8 |      0 |
|  42 |           TABLE ACCESS BY INDEX ROWID           | G_DOSSIER                   |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       4 |      0 |
|* 43 |            INDEX UNIQUE SCAN                    | DOS_REFDOSS                 |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |      0 |
|  44 |           TABLE ACCESS BY INDEX ROWID           | G_DOSSIER                   |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       4 |      0 |
|* 45 |            INDEX UNIQUE SCAN                    | DOS_REFDOSS                 |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |      0 |
|* 46 |          INDEX RANGE SCAN                       | G_DOSSIER_RL_CD_RD_RF_IDX   |      1 |      7 |     1   (0)|   1864 |00:00:00.01 |      15 |      0 |
|* 47 |         TABLE ACCESS BY INDEX ROWID BATCHED     | G_ENCAISSEMENT              |   1864 |      1 |     1   (0)|    102K|00:00:00.21 |   38594 |      0 |
|* 48 |          INDEX RANGE SCAN                       | G_ENC_REFDOSS_GRP_ANNSAF    |   1864 |     62 |     1   (0)|    102K|00:00:00.02 |    5452 |      0 |
|* 49 |        TABLE ACCESS BY INDEX ROWID BATCHED      | T_ECRDOS                    |    102K|      1 |     1   (0)|    409K|00:00:00.78 |     469K|      0 |
|* 50 |         INDEX RANGE SCAN                        | TECR_REFELEM                |    102K|      2 |     1   (0)|    409K|00:00:00.26 |     245K|      0 |
|  51 |      NESTED LOOPS                               |                             |      1 |      1 |     7   (0)|      0 |00:00:00.02 |   13958 |      0 |
|  52 |       NESTED LOOPS                              |                             |      1 |      2 |     7   (0)|      0 |00:00:00.02 |   13958 |      0 |
|  53 |        NESTED LOOPS                             |                             |      1 |      1 |     6   (0)|      0 |00:00:00.02 |   13958 |      0 |
|  54 |         NESTED LOOPS OUTER                      |                             |      1 |      1 |     5   (0)|      0 |00:00:00.02 |   13958 |      0 |
|  55 |          NESTED LOOPS                           |                             |      1 |      1 |     4   (0)|      0 |00:00:00.02 |   13958 |      0 |
|  56 |           NESTED LOOPS                          |                             |      1 |      7 |     3   (0)|   1864 |00:00:00.01 |      23 |      0 |
|  57 |            NESTED LOOPS                         |                             |      1 |      1 |     2   (0)|      1 |00:00:00.01 |       8 |      0 |
|  58 |             TABLE ACCESS BY INDEX ROWID         | G_DOSSIER                   |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       4 |      0 |
|* 59 |              INDEX UNIQUE SCAN                  | DOS_REFDOSS                 |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |      0 |
|  60 |             TABLE ACCESS BY INDEX ROWID         | G_DOSSIER                   |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       4 |      0 |
|* 61 |              INDEX UNIQUE SCAN                  | DOS_REFDOSS                 |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |      0 |
|* 62 |            INDEX RANGE SCAN                     | G_DOSSIER_RL_CD_RD_RF_IDX   |      1 |      7 |     1   (0)|   1864 |00:00:00.01 |      15 |      0 |
|* 63 |           TABLE ACCESS BY INDEX ROWID BATCHED   | G_ENCAISSEMENT              |   1864 |      1 |     1   (0)|      0 |00:00:00.02 |   13935 |      0 |
|* 64 |            INDEX RANGE SCAN                     | G_ENC_REFDOSS_GRP_PMTSAF    |   1864 |      6 |     1   (0)|  14993 |00:00:00.01 |    5242 |      0 |
|  65 |          TABLE ACCESS BY INDEX ROWID BATCHED    | T_ECRDOS                    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 66 |           INDEX RANGE SCAN                      | IDX_FFSI_T_ECRDOS           |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|  67 |         TABLE ACCESS BY INDEX ROWID BATCHED     | F_DETFAC                    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 68 |          INDEX RANGE SCAN                       | F_DETFAC_DF_REFINIT_IDX     |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 69 |        INDEX RANGE SCAN                         | TECR_REFELEM                |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 70 |       TABLE ACCESS BY INDEX ROWID               | T_ECRDOS                    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|  71 |      NESTED LOOPS                               |                             |      1 |      1 |     9   (0)|      0 |00:00:00.11 |   38617 |      0 |
|  72 |       NESTED LOOPS                              |                             |      1 |      2 |     9   (0)|      0 |00:00:00.11 |   38617 |      0 |
|  73 |        NESTED LOOPS                             |                             |      1 |      1 |     8   (0)|      0 |00:00:00.11 |   38617 |      0 |
|  74 |         NESTED LOOPS OUTER                      |                             |      1 |      1 |     7   (0)|      0 |00:00:00.11 |   38617 |      0 |
|  75 |          NESTED LOOPS                           |                             |      1 |      1 |     6   (0)|      0 |00:00:00.11 |   38617 |      0 |
|  76 |           NESTED LOOPS                          |                             |      1 |      7 |     3   (0)|   1864 |00:00:00.01 |      23 |      0 |
|  77 |            NESTED LOOPS                         |                             |      1 |      1 |     2   (0)|      1 |00:00:00.01 |       8 |      0 |
|  78 |             TABLE ACCESS BY INDEX ROWID         | G_DOSSIER                   |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       4 |      0 |
|* 79 |              INDEX UNIQUE SCAN                  | DOS_REFDOSS                 |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |      0 |
|  80 |             TABLE ACCESS BY INDEX ROWID         | G_DOSSIER                   |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       4 |      0 |
|* 81 |              INDEX UNIQUE SCAN                  | DOS_REFDOSS                 |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |      0 |
|* 82 |            INDEX RANGE SCAN                     | G_DOSSIER_RL_CD_RD_RF_IDX   |      1 |      7 |     1   (0)|   1864 |00:00:00.01 |      15 |      0 |
|* 83 |           TABLE ACCESS BY INDEX ROWID BATCHED   | G_ENCAISSEMENT              |   1864 |      1 |     1   (0)|      0 |00:00:00.11 |   38594 |      0 |
|* 84 |            INDEX RANGE SCAN                     | G_ENC_REFDOSS_GRP_ANNSAF    |   1864 |     62 |     1   (0)|    102K|00:00:00.02 |    5452 |      0 |
|  85 |          TABLE ACCESS BY INDEX ROWID BATCHED    | T_ECRDOS                    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 86 |           INDEX RANGE SCAN                      | IDX_FFSI_T_ECRDOS           |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|  87 |         TABLE ACCESS BY INDEX ROWID BATCHED     | F_DETFAC                    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 88 |          INDEX RANGE SCAN                       | F_DETFAC_DF_REFINIT_IDX     |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 89 |        INDEX RANGE SCAN                         | TECR_REFELEM                |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 90 |       TABLE ACCESS BY INDEX ROWID               | T_ECRDOS                    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|  91 |      NESTED LOOPS                               |                             |      1 |      1 |     5   (0)|   1290 |00:00:00.01 |    9652 |      0 |
|  92 |       NESTED LOOPS                              |                             |      1 |      2 |     5   (0)|   2496 |00:00:00.01 |    8157 |      0 |
|  93 |        NESTED LOOPS                             |                             |      1 |      1 |     4   (0)|   1290 |00:00:00.01 |    5615 |      0 |
|  94 |         NESTED LOOPS                            |                             |      1 |      7 |     3   (0)|   1864 |00:00:00.01 |      23 |      0 |
|  95 |          NESTED LOOPS                           |                             |      1 |      1 |     2   (0)|      1 |00:00:00.01 |       8 |      0 |
|  96 |           TABLE ACCESS BY INDEX ROWID           | G_DOSSIER                   |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       4 |      0 |
|* 97 |            INDEX UNIQUE SCAN                    | DOS_REFDOSS                 |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |      0 |
|  98 |           TABLE ACCESS BY INDEX ROWID           | G_DOSSIER                   |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       4 |      0 |
|* 99 |            INDEX UNIQUE SCAN                    | DOS_REFDOSS                 |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |      0 |
|*100 |          INDEX RANGE SCAN                       | G_DOSSIER_RL_CD_RD_RF_IDX   |      1 |      7 |     1   (0)|   1864 |00:00:00.01 |      15 |      0 |
|*101 |         TABLE ACCESS BY INDEX ROWID BATCHED     | G_ELEMFI                    |   1864 |      1 |     1   (0)|   1290 |00:00:00.01 |    5592 |      0 |
|*102 |          INDEX RANGE SCAN                       | ELEMFI_REFDOSS_GRP_CNSAF    |   1864 |     33 |     1   (0)|   1290 |00:00:00.01 |    5159 |      0 |
|*103 |        INDEX RANGE SCAN                         | TECR_REFELEM                |   1290 |      2 |     1   (0)|   2496 |00:00:00.01 |    2542 |      0 |
|*104 |       TABLE ACCESS BY INDEX ROWID               | T_ECRDOS                    |   2496 |      1 |     1   (0)|   1290 |00:00:00.01 |    1495 |      0 |
| 105 |      NESTED LOOPS                               |                             |      1 |      1 |     5   (0)|      0 |00:00:00.07 |    8821 |      0 |
| 106 |       NESTED LOOPS                              |                             |      1 |      2 |     5   (0)|      0 |00:00:00.07 |    8821 |      0 |
| 107 |        NESTED LOOPS                             |                             |      1 |      1 |     4   (0)|      0 |00:00:00.07 |    8821 |      0 |
| 108 |         NESTED LOOPS                            |                             |      1 |      7 |     3   (0)|   1864 |00:00:00.01 |      23 |      0 |
| 109 |          NESTED LOOPS                           |                             |      1 |      1 |     2   (0)|      1 |00:00:00.01 |       8 |      0 |
| 110 |           TABLE ACCESS BY INDEX ROWID           | G_DOSSIER                   |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       4 |      0 |
|*111 |            INDEX UNIQUE SCAN                    | DOS_REFDOSS                 |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |      0 |
| 112 |           TABLE ACCESS BY INDEX ROWID           | G_DOSSIER                   |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       4 |      0 |
|*113 |            INDEX UNIQUE SCAN                    | DOS_REFDOSS                 |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |      0 |
|*114 |          INDEX RANGE SCAN                       | G_DOSSIER_RL_CD_RD_RF_IDX   |      1 |      7 |     1   (0)|   1864 |00:00:00.01 |      15 |      0 |
|*115 |         TABLE ACCESS BY INDEX ROWID BATCHED     | G_ELEMFI                    |   1864 |      1 |     1   (0)|      0 |00:00:00.06 |    8798 |      0 |
|*116 |          INDEX RANGE SCAN                       | GE_REFDOSS_DTANNUL_IDX      |   1864 |      1 |     1   (0)|   2734 |00:00:00.06 |    8026 |      0 |
|*117 |        INDEX RANGE SCAN                         | TECR_REFELEM                |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*118 |       TABLE ACCESS BY INDEX ROWID               | T_ECRDOS                    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*119 |      FILTER                                     |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 120 |       NESTED LOOPS                              |                             |      0 |      8 |     5   (0)|      0 |00:00:00.01 |       0 |      0 |
| 121 |        NESTED LOOPS                             |                             |      0 |    350 |     5   (0)|      0 |00:00:00.01 |       0 |      0 |
| 122 |         NESTED LOOPS                            |                             |      0 |      7 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
| 123 |          NESTED LOOPS                           |                             |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
| 124 |           TABLE ACCESS BY INDEX ROWID           | G_DOSSIER                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*125 |            INDEX UNIQUE SCAN                    | DOS_REFDOSS                 |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 126 |           TABLE ACCESS BY INDEX ROWID           | G_DOSSIER                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*127 |            INDEX UNIQUE SCAN                    | DOS_REFDOSS                 |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*128 |          INDEX RANGE SCAN                       | G_DOSSIER_RL_CD_RD_RF_IDX   |      0 |      7 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*129 |         INDEX RANGE SCAN                        | G_ENCREFD_TRAITE            |      0 |     50 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*130 |        TABLE ACCESS BY INDEX ROWID              | G_ENCAISSEMENT              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 131 |      NESTED LOOPS                               |                             |      1 |      1 |     7   (0)|      0 |00:00:00.01 |       9 |      0 |
| 132 |       NESTED LOOPS                              |                             |      1 |      2 |     7   (0)|      0 |00:00:00.01 |       9 |      0 |
| 133 |        NESTED LOOPS                             |                             |      1 |      1 |     6   (0)|      0 |00:00:00.01 |       9 |      0 |
| 134 |         MERGE JOIN CARTESIAN                    |                             |      1 |      1 |     5   (0)|      0 |00:00:00.01 |       9 |      0 |
| 135 |          MERGE JOIN CARTESIAN                   |                             |      1 |      1 |     4   (0)|      0 |00:00:00.01 |       9 |      0 |
| 136 |           NESTED LOOPS                          |                             |      1 |      1 |     3   (0)|      0 |00:00:00.01 |       9 |      0 |
| 137 |            NESTED LOOPS                         |                             |      1 |      1 |     2   (0)|      1 |00:00:00.01 |       8 |      0 |
| 138 |             TABLE ACCESS BY INDEX ROWID         | G_DOSSIER                   |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       4 |      0 |
|*139 |              INDEX UNIQUE SCAN                  | DOS_REFDOSS                 |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |      0 |
| 140 |             TABLE ACCESS BY INDEX ROWID         | G_DOSSIER                   |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       4 |      0 |
|*141 |              INDEX UNIQUE SCAN                  | DOS_REFDOSS                 |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |      0 |
|*142 |            INDEX RANGE SCAN                     | PK_G_ETUDE                  |      1 |      1 |     1   (0)|      0 |00:00:00.01 |       1 |      0 |
| 143 |           BUFFER SORT                           |                             |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*144 |            TABLE ACCESS BY INDEX ROWID BATCHED  | G_PIECE                     |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*145 |             INDEX RANGE SCAN                    | PIE_REFDOSS                 |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 146 |          BUFFER SORT                            |                             |      0 |      7 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*147 |           INDEX RANGE SCAN                      | G_DOSSIER_RL_CD_RD_RF_IDX   |      0 |      7 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*148 |         TABLE ACCESS BY INDEX ROWID BATCHED     | G_ELEMFI                    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*149 |          INDEX RANGE SCAN                       | EFI_DOS_DTEMIS_TYPE         |      0 |      5 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*150 |        INDEX RANGE SCAN                         | TECR_REFELEM                |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*151 |       TABLE ACCESS BY INDEX ROWID               | T_ECRDOS                    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 152 |      NESTED LOOPS                               |                             |      1 |      1 |     8   (0)|      0 |00:00:00.01 |      16 |      0 |
| 153 |       NESTED LOOPS                              |                             |      1 |      2 |     8   (0)|      0 |00:00:00.01 |      16 |      0 |
| 154 |        NESTED LOOPS                             |                             |      1 |      1 |     7   (0)|      0 |00:00:00.01 |      16 |      0 |
| 155 |         MERGE JOIN CARTESIAN                    |                             |      1 |      1 |     6   (0)|      0 |00:00:00.01 |      16 |      0 |
| 156 |          MERGE JOIN CARTESIAN                   |                             |      1 |      1 |     5   (0)|      0 |00:00:00.01 |      16 |      0 |
| 157 |           NESTED LOOPS                          |                             |      1 |      1 |     4   (0)|      0 |00:00:00.01 |      16 |      0 |
| 158 |            NESTED LOOPS                         |                             |      1 |      1 |     4   (0)|      1 |00:00:00.01 |      15 |      0 |
| 159 |             NESTED LOOPS                        |                             |      1 |      1 |     3   (0)|      1 |00:00:00.01 |      13 |      0 |
| 160 |              NESTED LOOPS                       |                             |      1 |      1 |     2   (0)|      1 |00:00:00.01 |       8 |      0 |
| 161 |               TABLE ACCESS BY INDEX ROWID       | G_DOSSIER                   |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       4 |      0 |
|*162 |                INDEX UNIQUE SCAN                | DOS_REFDOSS                 |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |      0 |
| 163 |               TABLE ACCESS BY INDEX ROWID       | G_DOSSIER                   |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       4 |      0 |
|*164 |                INDEX UNIQUE SCAN                | DOS_REFDOSS                 |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |      0 |
| 165 |              TABLE ACCESS BY INDEX ROWID BATCHED| G_PIECE                     |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       5 |      0 |
|*166 |               INDEX RANGE SCAN                  | PIE_REFDOSS                 |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       4 |      0 |
|*167 |             INDEX UNIQUE SCAN                   | REFPIECE_IDX                |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       2 |      0 |
|*168 |            TABLE ACCESS BY INDEX ROWID          | G_CF_CONTRACT               |      1 |      1 |     1   (0)|      0 |00:00:00.01 |       1 |      0 |
| 169 |           BUFFER SORT                           |                             |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*170 |            INDEX RANGE SCAN                     | PK_G_ETUDE                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 171 |          BUFFER SORT                            |                             |      0 |      7 |     5   (0)|      0 |00:00:00.01 |       0 |      0 |
|*172 |           INDEX RANGE SCAN                      | G_DOSSIER_RL_CD_RD_RF_IDX   |      0 |      7 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*173 |         TABLE ACCESS BY INDEX ROWID BATCHED     | G_ELEMFI                    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*174 |          INDEX RANGE SCAN                       | G_ELEMFI_DOS_TYP_FG02       |      0 |      3 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*175 |        INDEX RANGE SCAN                         | TECR_REFELEM                |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*176 |       TABLE ACCESS BY INDEX ROWID               | T_ECRDOS                    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 177 |      NESTED LOOPS                               |                             |      1 |      1 |     8   (0)|      0 |00:00:00.01 |      16 |      0 |
| 178 |       NESTED LOOPS                              |                             |      1 |      2 |     8   (0)|      0 |00:00:00.01 |      16 |      0 |
| 179 |        NESTED LOOPS                             |                             |      1 |      1 |     7   (0)|      0 |00:00:00.01 |      16 |      0 |
| 180 |         MERGE JOIN CARTESIAN                    |                             |      1 |      1 |     6   (0)|      0 |00:00:00.01 |      16 |      0 |
| 181 |          MERGE JOIN CARTESIAN                   |                             |      1 |      1 |     5   (0)|      0 |00:00:00.01 |      16 |      0 |
| 182 |           NESTED LOOPS                          |                             |      1 |      1 |     4   (0)|      0 |00:00:00.01 |      16 |      0 |
| 183 |            NESTED LOOPS                         |                             |      1 |      1 |     4   (0)|      1 |00:00:00.01 |      15 |      0 |
| 184 |             NESTED LOOPS                        |                             |      1 |      1 |     3   (0)|      1 |00:00:00.01 |      13 |      0 |
| 185 |              NESTED LOOPS                       |                             |      1 |      1 |     2   (0)|      1 |00:00:00.01 |       8 |      0 |
| 186 |               TABLE ACCESS BY INDEX ROWID       | G_DOSSIER                   |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       4 |      0 |
|*187 |                INDEX UNIQUE SCAN                | DOS_REFDOSS                 |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |      0 |
| 188 |               TABLE ACCESS BY INDEX ROWID       | G_DOSSIER                   |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       4 |      0 |
|*189 |                INDEX UNIQUE SCAN                | DOS_REFDOSS                 |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |      0 |
| 190 |              TABLE ACCESS BY INDEX ROWID BATCHED| G_PIECE                     |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       5 |      0 |
|*191 |               INDEX RANGE SCAN                  | PIE_REFDOSS                 |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       4 |      0 |
|*192 |             INDEX UNIQUE SCAN                   | REFPIECE_IDX                |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       2 |      0 |
|*193 |            TABLE ACCESS BY INDEX ROWID          | G_CF_CONTRACT               |      1 |      1 |     1   (0)|      0 |00:00:00.01 |       1 |      0 |
| 194 |           BUFFER SORT                           |                             |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*195 |            INDEX RANGE SCAN                     | PK_G_ETUDE                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 196 |          BUFFER SORT                            |                             |      0 |      7 |     5   (0)|      0 |00:00:00.01 |       0 |      0 |
|*197 |           INDEX RANGE SCAN                      | G_DOSSIER_RL_CD_RD_RF_IDX   |      0 |      7 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*198 |         TABLE ACCESS BY INDEX ROWID BATCHED     | G_ELEMFI                    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*199 |          INDEX RANGE SCAN                       | GE_REFDOSS_DTANNUL_IDX      |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*200 |        INDEX RANGE SCAN                         | TECR_REFELEM                |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*201 |       TABLE ACCESS BY INDEX ROWID               | T_ECRDOS                    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 202 |      NESTED LOOPS                               |                             |      1 |      1 |     8   (0)|      0 |00:00:00.01 |      16 |      0 |
| 203 |       NESTED LOOPS                              |                             |      1 |      2 |     8   (0)|      0 |00:00:00.01 |      16 |      0 |
| 204 |        NESTED LOOPS                             |                             |      1 |      1 |     7   (0)|      0 |00:00:00.01 |      16 |      0 |
| 205 |         MERGE JOIN CARTESIAN                    |                             |      1 |      1 |     6   (0)|      0 |00:00:00.01 |      16 |      0 |
| 206 |          MERGE JOIN CARTESIAN                   |                             |      1 |      1 |     5   (0)|      0 |00:00:00.01 |      16 |      0 |
| 207 |           NESTED LOOPS                          |                             |      1 |      1 |     4   (0)|      0 |00:00:00.01 |      16 |      0 |
| 208 |            NESTED LOOPS                         |                             |      1 |      1 |     4   (0)|      1 |00:00:00.01 |      15 |      0 |
| 209 |             NESTED LOOPS                        |                             |      1 |      1 |     3   (0)|      1 |00:00:00.01 |      13 |      0 |
| 210 |              NESTED LOOPS                       |                             |      1 |      1 |     2   (0)|      1 |00:00:00.01 |       8 |      0 |
| 211 |               TABLE ACCESS BY INDEX ROWID       | G_DOSSIER                   |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       4 |      0 |
|*212 |                INDEX UNIQUE SCAN                | DOS_REFDOSS                 |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |      0 |
| 213 |               TABLE ACCESS BY INDEX ROWID       | G_DOSSIER                   |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       4 |      0 |
|*214 |                INDEX UNIQUE SCAN                | DOS_REFDOSS                 |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |      0 |
| 215 |              TABLE ACCESS BY INDEX ROWID BATCHED| G_PIECE                     |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       5 |      0 |
|*216 |               INDEX RANGE SCAN                  | PIE_REFDOSS                 |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       4 |      0 |
|*217 |             INDEX UNIQUE SCAN                   | REFPIECE_IDX                |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       2 |      0 |
|*218 |            TABLE ACCESS BY INDEX ROWID          | G_CF_CONTRACT               |      1 |      1 |     1   (0)|      0 |00:00:00.01 |       1 |      0 |
| 219 |           BUFFER SORT                           |                             |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*220 |            INDEX RANGE SCAN                     | PK_G_ETUDE                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 221 |          BUFFER SORT                            |                             |      0 |      7 |     5   (0)|      0 |00:00:00.01 |       0 |      0 |
|*222 |           INDEX RANGE SCAN                      | G_DOSSIER_RL_CD_RD_RF_IDX   |      0 |      7 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*223 |         TABLE ACCESS BY INDEX ROWID BATCHED     | G_ELEMFI                    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*224 |          INDEX RANGE SCAN                       | G_ELEMFI_DOS_TYP_FG02       |      0 |      3 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*225 |        INDEX RANGE SCAN                         | TECR_REFELEM                |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*226 |       TABLE ACCESS BY INDEX ROWID               | T_ECRDOS                    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 227 |      NESTED LOOPS                               |                             |      1 |      1 |     8   (0)|      0 |00:00:00.01 |      16 |      0 |
| 228 |       NESTED LOOPS                              |                             |      1 |      2 |     8   (0)|      0 |00:00:00.01 |      16 |      0 |
| 229 |        NESTED LOOPS                             |                             |      1 |      1 |     7   (0)|      0 |00:00:00.01 |      16 |      0 |
| 230 |         MERGE JOIN CARTESIAN                    |                             |      1 |      1 |     6   (0)|      0 |00:00:00.01 |      16 |      0 |
| 231 |          MERGE JOIN CARTESIAN                   |                             |      1 |      1 |     5   (0)|      0 |00:00:00.01 |      16 |      0 |
| 232 |           NESTED LOOPS                          |                             |      1 |      1 |     4   (0)|      0 |00:00:00.01 |      16 |      0 |
| 233 |            NESTED LOOPS                         |                             |      1 |      1 |     4   (0)|      1 |00:00:00.01 |      15 |      0 |
| 234 |             NESTED LOOPS                        |                             |      1 |      1 |     3   (0)|      1 |00:00:00.01 |      13 |      0 |
| 235 |              NESTED LOOPS                       |                             |      1 |      1 |     2   (0)|      1 |00:00:00.01 |       8 |      0 |
| 236 |               TABLE ACCESS BY INDEX ROWID       | G_DOSSIER                   |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       4 |      0 |
|*237 |                INDEX UNIQUE SCAN                | DOS_REFDOSS                 |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |      0 |
| 238 |               TABLE ACCESS BY INDEX ROWID       | G_DOSSIER                   |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       4 |      0 |
|*239 |                INDEX UNIQUE SCAN                | DOS_REFDOSS                 |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |      0 |
| 240 |              TABLE ACCESS BY INDEX ROWID BATCHED| G_PIECE                     |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       5 |      0 |
|*241 |               INDEX RANGE SCAN                  | PIE_REFDOSS                 |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       4 |      0 |
|*242 |             INDEX UNIQUE SCAN                   | REFPIECE_IDX                |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       2 |      0 |
|*243 |            TABLE ACCESS BY INDEX ROWID          | G_CF_CONTRACT               |      1 |      1 |     1   (0)|      0 |00:00:00.01 |       1 |      0 |
| 244 |           BUFFER SORT                           |                             |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*245 |            INDEX RANGE SCAN                     | PK_G_ETUDE                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 246 |          BUFFER SORT                            |                             |      0 |      7 |     5   (0)|      0 |00:00:00.01 |       0 |      0 |
|*247 |           INDEX RANGE SCAN                      | G_DOSSIER_RL_CD_RD_RF_IDX   |      0 |      7 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*248 |         TABLE ACCESS BY INDEX ROWID BATCHED     | G_ELEMFI                    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*249 |          INDEX RANGE SCAN                       | GE_REFDOSS_DTANNUL_IDX      |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*250 |        INDEX RANGE SCAN                         | TECR_REFELEM                |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*251 |       TABLE ACCESS BY INDEX ROWID               | T_ECRDOS                    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*252 |   VIEW                                          |                             |      1 |    484 |   516   (1)|   2001 |00:00:00.54 |     375K|      2 |
|*253 |    COUNT STOPKEY                                |                             |      1 |        |            |   2001 |00:00:00.54 |     375K|      2 |
| 254 |     VIEW                                        |                             |      1 |    484 |   516   (1)|   2001 |00:00:00.54 |     375K|      2 |
|*255 |      SORT UNIQUE STOPKEY                        |                             |      1 |    484 |   515   (1)|   2001 |00:00:00.54 |     375K|      2 |
| 256 |       UNION-ALL                                 |                             |      1 |        |            |    118K|00:00:00.51 |     375K|      2 |
| 257 |        NESTED LOOPS                             |                             |    582 |      1 |     2   (0)|    582 |00:00:00.01 |    2521 |      1 |
| 258 |         NESTED LOOPS                            |                             |    582 |      1 |     2   (0)|    582 |00:00:00.01 |    1972 |      1 |
|*259 |          INDEX RANGE SCAN                       | INT_REFDOSS                 |    582 |      1 |     1   (0)|    582 |00:00:00.01 |     829 |      1 |
|*260 |          INDEX UNIQUE SCAN                      | IND_REFINDIV                |    582 |      1 |     1   (0)|    582 |00:00:00.01 |    1143 |      0 |
| 261 |         TABLE ACCESS BY INDEX ROWID             | G_INDIVIDU                  |    582 |      1 |     1   (0)|    582 |00:00:00.01 |     549 |      0 |
|*262 |        HASH JOIN OUTER                          |                             |      1 |    242 |    14   (0)|    117K|00:00:00.43 |     368K|      0 |
| 263 |         NESTED LOOPS OUTER                      |                             |      1 |     22 |     3   (0)|    117K|00:00:00.34 |     368K|      0 |
|*264 |          VIEW                                   |                             |      1 |     22 |     2   (0)|    117K|00:00:00.05 |       0 |      0 |
| 265 |           TABLE ACCESS FULL                     | SYS_TEMP_0FD9D680D_1415B2C3 |      1 |     22 |     2   (0)|    118K|00:00:00.03 |       0 |      0 |
| 266 |          TABLE ACCESS BY INDEX ROWID            | G_ENCAISSEMENT              |    117K|      1 |     1   (0)|    117K|00:00:00.26 |     368K|      0 |
|*267 |           INDEX UNIQUE SCAN                     | REFENCAISS                  |    117K|      1 |     1   (0)|    117K|00:00:00.12 |     251K|      0 |
| 268 |         VIEW                                    | V_TDOMAINE                  |      1 |    495 |    11   (0)|     10 |00:00:00.01 |       9 |      0 |
| 269 |          UNION-ALL                              |                             |      1 |        |            |     10 |00:00:00.01 |       9 |      0 |
|*270 |           FILTER                                |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 271 |            TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE                   |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*272 |             INDEX RANGE SCAN                    | V_DOMAINE_TYPE_CODE_IDX     |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*273 |           FILTER                                |                             |      1 |        |            |     10 |00:00:00.01 |       9 |      0 |
| 274 |            TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE                   |      1 |     45 |     1   (0)|     10 |00:00:00.01 |       9 |      0 |
|*275 |             INDEX RANGE SCAN                    | V_DOMAINE_TYPE_CODE_IDX     |      1 |     45 |     1   (0)|     10 |00:00:00.01 |       2 |      0 |
|*276 |           FILTER                                |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 277 |            TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE                   |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*278 |             INDEX RANGE SCAN                    | V_DOMAINE_TYPE_CODE_IDX     |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*279 |           FILTER                                |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 280 |            TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE                   |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*281 |             INDEX RANGE SCAN                    | V_DOMAINE_TYPE_CODE_IDX     |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*282 |           FILTER                                |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 283 |            TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE                   |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*284 |             INDEX RANGE SCAN                    | V_DOMAINE_TYPE_CODE_IDX     |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*285 |           FILTER                                |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 286 |            TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE                   |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*287 |             INDEX RANGE SCAN                    | V_DOMAINE_TYPE_CODE_IDX     |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*288 |           FILTER                                |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 289 |            TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE                   |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*290 |             INDEX RANGE SCAN                    | V_DOMAINE_TYPE_CODE_IDX     |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*291 |           FILTER                                |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 292 |            TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE                   |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*293 |             INDEX RANGE SCAN                    | V_DOMAINE_TYPE_CODE_IDX     |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*294 |           FILTER                                |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 295 |            TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE                   |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*296 |             INDEX RANGE SCAN                    | V_DOMAINE_TYPE_CODE_IDX     |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*297 |           FILTER                                |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 298 |            TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE                   |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*299 |             INDEX RANGE SCAN                    | V_DOMAINE_TYPE_CODE_IDX     |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*300 |           FILTER                                |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 301 |            TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE                   |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*302 |             INDEX RANGE SCAN                    | V_DOMAINE_TYPE_CODE_IDX     |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 303 |        NESTED LOOPS                             |                             |    178 |      1 |     2   (0)|    178 |00:00:00.01 |     807 |      0 |
| 304 |         NESTED LOOPS                            |                             |    178 |      1 |     2   (0)|    178 |00:00:00.01 |     639 |      0 |
|*305 |          INDEX RANGE SCAN                       | INT_REFDOSS                 |    178 |      1 |     1   (0)|    178 |00:00:00.01 |     281 |      0 |
|*306 |          INDEX UNIQUE SCAN                      | IND_REFINDIV                |    178 |      1 |     1   (0)|    178 |00:00:00.01 |     358 |      0 |
| 307 |         TABLE ACCESS BY INDEX ROWID             | G_INDIVIDU                  |    178 |      1 |     1   (0)|    178 |00:00:00.01 |     168 |      0 |
|*308 |        HASH JOIN OUTER                          |                             |      1 |    242 |    14   (0)|   1290 |00:00:00.03 |    3754 |      1 |
| 309 |         NESTED LOOPS OUTER                      |                             |      1 |     22 |     3   (0)|   1290 |00:00:00.03 |    3745 |      1 |
|*310 |          VIEW                                   |                             |      1 |     22 |     2   (0)|   1290 |00:00:00.03 |       0 |      0 |
| 311 |           TABLE ACCESS FULL                     | SYS_TEMP_0FD9D680D_1415B2C3 |      1 |     22 |     2   (0)|    118K|00:00:00.01 |       0 |      0 |
| 312 |          TABLE ACCESS BY INDEX ROWID            | G_ELEMFI                    |   1290 |      1 |     1   (0)|   1290 |00:00:00.01 |    3745 |      1 |
|*313 |           INDEX UNIQUE SCAN                     | EFI_REFELEM                 |   1290 |      1 |     1   (0)|   1290 |00:00:00.01 |    2455 |      1 |
| 314 |         VIEW                                    | V_TDOMAINE                  |      1 |    495 |    11   (0)|     10 |00:00:00.01 |       9 |      0 |
| 315 |          UNION-ALL                              |                             |      1 |        |            |     10 |00:00:00.01 |       9 |      0 |
|*316 |           FILTER                                |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 317 |            TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE                   |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*318 |             INDEX RANGE SCAN                    | V_DOMAINE_TYPE_CODE_IDX     |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*319 |           FILTER                                |                             |      1 |        |            |     10 |00:00:00.01 |       9 |      0 |
| 320 |            TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE                   |      1 |     45 |     1   (0)|     10 |00:00:00.01 |       9 |      0 |
|*321 |             INDEX RANGE SCAN                    | V_DOMAINE_TYPE_CODE_IDX     |      1 |     45 |     1   (0)|     10 |00:00:00.01 |       2 |      0 |
|*322 |           FILTER                                |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 323 |            TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE                   |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*324 |             INDEX RANGE SCAN                    | V_DOMAINE_TYPE_CODE_IDX     |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*325 |           FILTER                                |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 326 |            TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE                   |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*327 |             INDEX RANGE SCAN                    | V_DOMAINE_TYPE_CODE_IDX     |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*328 |           FILTER                                |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 329 |            TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE                   |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*330 |             INDEX RANGE SCAN                    | V_DOMAINE_TYPE_CODE_IDX     |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*331 |           FILTER                                |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 332 |            TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE                   |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*333 |             INDEX RANGE SCAN                    | V_DOMAINE_TYPE_CODE_IDX     |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*334 |           FILTER                                |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 335 |            TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE                   |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*336 |             INDEX RANGE SCAN                    | V_DOMAINE_TYPE_CODE_IDX     |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*337 |           FILTER                                |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 338 |            TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE                   |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*339 |             INDEX RANGE SCAN                    | V_DOMAINE_TYPE_CODE_IDX     |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*340 |           FILTER                                |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 341 |            TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE                   |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*342 |             INDEX RANGE SCAN                    | V_DOMAINE_TYPE_CODE_IDX     |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*343 |           FILTER                                |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 344 |            TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE                   |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*345 |             INDEX RANGE SCAN                    | V_DOMAINE_TYPE_CODE_IDX     |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*346 |           FILTER                                |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 347 |            TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE                   |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*348 |             INDEX RANGE SCAN                    | V_DOMAINE_TYPE_CODE_IDX     |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
---------------------------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   7 - filter(:B1='SAF_PROC')
  10 - filter(("V"."TYPENCAISS"='en' AND "V"."TYPELEM"='fi'))
  11 - access("V"."REFENCAISS"=:B1)
  12 - access("FI"."REFELEM"="V"."REFELEM")
  14 - filter(("ENC"."REFDOSS"=DECODE("ENC"."TYPENCAISS",'e_saencaiss',DECODE("ENC"."CREATEUR",'DB_POSITIONS',"ENC"."REFDOSS",'DB_POSITIONS_ABS',"ENC".
              "REFDOSS","AMTDCPT"."REFDOSS"),"ENC"."REFDOSS") AND (DECODE("ENC"."TYPENCAISS",'e_saencaiss',DECODE("ENC"."CREATEUR",'DB_POSITIONS','RFIN','DB_POSITION
              S_ABS','RFIN',"AMTDCPT"."CODECR"),'RFIN')='RFIN' OR DECODE("ENC"."TYPENCAISS",'e_saencaiss',DECODE("ENC"."CREATEUR",'DB_POSITIONS','RFIN','DB_POSITIONS
              _ABS','RFIN',"AMTDCPT"."CODECR"),'RFIN')='ENCAT')))
  20 - access("DECO"."REFDOSS"=:B1)
  22 - access("DECO"."REFLOT"="CONTR"."REFDOSS")
  23 - access("CMP"."REFLOT"=:B1 AND "CMP"."CATEGDOSS" LIKE 'COMPTE%')
       filter("CMP"."CATEGDOSS" LIKE 'COMPTE%')
  24 - filter(("ENC"."DTMARQUE_DT" IS NULL AND INTERNAL_FUNCTION("ENC"."TYPENCAISS") AND
              DECODE("ENC"."TYPENCAISS",'e_saencaiss',"ENC"."MOYENPAIMT",'PAIEMENT DECLARE')='PAIEMENT DECLARE' AND TO_NUMBER("ENC"."TRAITE")=2 AND
              NVL("ENC"."CREATEUR",'x')<>'e_lettrage2_PTCX'))
  25 - access("ENC"."REFDOSS"="CMP"."REFDOSS" AND "ENC"."REC_GRP_PMTSAF"='NP')
  26 - filter(("AMTDCPT"."TYPELEM"=DECODE("ENC"."CREATEUR",'DB_POSITIONS','x','DB_POSITIONS_ABS','x','e') AND "AMTDCPT"."REJET" IS NULL))
  27 - access("AMTDCPT"."REFELEM"="ENC"."REFENCAISS")
  30 - filter(:B1='SAF_PROC')
  33 - filter(("V"."TYPENCAISS"='en' AND "V"."TYPELEM"='fi'))
  34 - access("V"."REFENCAISS"=:B1)
  35 - access("FI"."REFELEM"="V"."REFELEM")
  37 - filter((DECODE("ENC"."TYPENCAISS",'e_saencaiss',DECODE("ENC"."CREATEUR",'DB_POSITIONS','RFIN','DB_POSITIONS_ABS','RFIN',"AMTDCPT"."CODECR"),'RFI
              N')='RFIN' OR DECODE("ENC"."TYPENCAISS",'e_saencaiss',DECODE("ENC"."CREATEUR",'DB_POSITIONS','RFIN','DB_POSITIONS_ABS','RFIN',"AMTDCPT"."CODECR"),'RFIN
              ')='ENCAT'))
  43 - access("DECO"."REFDOSS"=:B1)
  45 - access("DECO"."REFLOT"="CONTR"."REFDOSS")
  46 - access("CMP"."REFLOT"=:B1 AND "CMP"."CATEGDOSS" LIKE 'COMPTE%')
       filter("CMP"."CATEGDOSS" LIKE 'COMPTE%')
  47 - filter(("ENC"."DTANNUL_DT" IS NOT NULL AND "ENC"."DTMARQUE_DT" IS NOT NULL AND INTERNAL_FUNCTION("ENC"."TYPENCAISS") AND
              TO_NUMBER("ENC"."TRAITE")=9 AND DECODE("ENC"."TYPENCAISS",'e_saencaiss',"ENC"."MOYENPAIMT",'PAIEMENT DECLARE')='PAIEMENT DECLARE' AND
              "ENC"."DTMARQUE_AN_DT" IS NULL AND NVL("ENC"."CREATEUR",'x')<>'e_lettrage2_PTCX'))
  48 - access("ENC"."REFDOSS"="CMP"."REFDOSS" AND "ENC"."REC_GRP_ANNSAF"='NP')
  49 - filter(("AMTDCPT"."REFDOSS"="ENC"."REFDOSS" AND "AMTDCPT"."TYPELEM"=DECODE("ENC"."CREATEUR",'DB_POSITIONS','x','DB_POSITIONS_ABS','x','e') AND
              "AMTDCPT"."REJET" IS NULL))
  50 - access("AMTDCPT"."REFELEM"="ENC"."REFENCAISS")
  59 - access("DECO"."REFDOSS"=:B1)
  61 - access("DECO"."REFLOT"="CONTR"."REFDOSS")
  62 - access("CMP"."REFLOT"=:B1 AND "CMP"."CATEGDOSS" LIKE 'COMPTE%')
       filter("CMP"."CATEGDOSS" LIKE 'COMPTE%')
  63 - filter(("ENC"."DTMARQUE_DT" IS NULL AND "ENC"."CREATEUR"='e_lettrage2_PTCX' AND "ENC"."MOYENPAIMT"='PAIEMENT DECLARE' AND
              "ENC"."TYPENCAISS"='e_saencaiss' AND TO_NUMBER("ENC"."TRAITE")=2))
  64 - access("ENC"."REFDOSS"="CMP"."REFDOSS" AND "ENC"."REC_GRP_PMTSAF"='NP')
  66 - access("AMTDCPT"."REFDOSS"="ENC"."REFDOSS" AND "AMTDCPT"."TYPELEM"='e' AND "AMTDCPT"."CODECR"='RFIN' AND "AMTDCPT"."REFELEM"="ENC"."REFENCAISS")
  68 - access("DBTFA"."DF_REFINIT"="ENC"."REFENCAISS" AND "DBTFA"."DF_NOM"='RINDS')
  69 - access("RINDS"."REFELEM"="DBTFA"."DF_NUM")
  70 - filter("RINDS"."CODECR"='RINDS')
  79 - access("DECO"."REFDOSS"=:B1)
  81 - access("DECO"."REFLOT"="CONTR"."REFDOSS")
  82 - access("CMP"."REFLOT"=:B1 AND "CMP"."CATEGDOSS" LIKE 'COMPTE%')
       filter("CMP"."CATEGDOSS" LIKE 'COMPTE%')
  83 - filter(("ENC"."DTANNUL_DT" IS NOT NULL AND "ENC"."DTMARQUE_DT" IS NOT NULL AND "ENC"."CREATEUR"='e_lettrage2_PTCX' AND
              "ENC"."MOYENPAIMT"='PAIEMENT DECLARE' AND "ENC"."TYPENCAISS"='e_saencaiss' AND TO_NUMBER("ENC"."TRAITE")=9 AND "ENC"."DTMARQUE_AN_DT" IS NULL))
  84 - access("ENC"."REFDOSS"="CMP"."REFDOSS" AND "ENC"."REC_GRP_ANNSAF"='NP')
  86 - access("AMTDCPT"."REFDOSS"="ENC"."REFDOSS" AND "AMTDCPT"."TYPELEM"='e' AND "AMTDCPT"."CODECR"='RFIN' AND "AMTDCPT"."REFELEM"="ENC"."REFENCAISS")
  88 - access("DBTFA"."DF_REFINIT"="ENC"."REFENCAISS" AND "DBTFA"."DF_NOM"='RINDS')
  89 - access("RINDS"."REFELEM"="DBTFA"."DF_NUM")
  90 - filter("RINDS"."CODECR"='RINDS')
  97 - access("DECO"."REFDOSS"=:B1)
  99 - access("DECO"."REFLOT"="CONTR"."REFDOSS")
 100 - access("CMP"."REFLOT"=:B1 AND "CMP"."CATEGDOSS" LIKE 'COMPTE%')
       filter("CMP"."CATEGDOSS" LIKE 'COMPTE%')
 101 - filter((INTERNAL_FUNCTION("FI"."TYPE") AND "FI"."DTMARQUE_DT" IS NULL AND
              DECODE(INTERNAL_FUNCTION("FI"."DTMARQUE_DT"),NULL,"FI"."DTANNUL_DT",NULL) IS NULL))
 102 - access("FI"."REFDOSS"="CMP"."REFDOSS" AND "FI"."REC_GRP_CNSAF"='NP')
 103 - access("AMTMEMO"."REFELEM"="FI"."REFELEM")
 104 - filter(("FI"."REFDOSS"="AMTMEMO"."REFDOSS" AND NVL("AMTMEMO"."CODECR",'x')='PRIN'))
 111 - access("DECO"."REFDOSS"=:B1)
 113 - access("DECO"."REFLOT"="CONTR"."REFDOSS")
 114 - access("CMP"."REFLOT"=:B1 AND "CMP"."CATEGDOSS" LIKE 'COMPTE%')
       filter("CMP"."CATEGDOSS" LIKE 'COMPTE%')
 115 - filter(("FI"."DTMARQUE_DT" IS NOT NULL AND "FI"."REC_GRP_ANSAF"='NP' AND INTERNAL_FUNCTION("FI"."TYPE") AND "FI"."DTMARQUE_AN_DT" IS NULL))
 116 - access("FI"."REFDOSS"="CMP"."REFDOSS")
       filter("FI"."DTANNUL_DT" IS NOT NULL)
 117 - access("AMTMEMO"."REFELEM"="FI"."REFELEM")
 118 - filter(("FI"."REFDOSS"="AMTMEMO"."REFDOSS" AND NVL("AMTMEMO"."CODECR",'x')='APRIN'))
 119 - filter(NULL IS NOT NULL)
 125 - access("DECO"."REFDOSS"=:B1)
 127 - access("DECO"."REFLOT"="CONTR"."REFDOSS")
 128 - access("CMP"."REFLOT"=:B1 AND "CMP"."CATEGDOSS" LIKE 'COMPTE%')
       filter("CMP"."CATEGDOSS" LIKE 'COMPTE%')
 129 - access("ENC"."REFDOSS"="CMP"."REFDOSS" AND "ENC"."TYPENCAISS"='ptf_reconcil_saf')
       filter(("ENC"."TYPENCAISS"='ptf_reconcil_saf' AND TO_NUMBER("ENC"."TRAITE")=2))
 130 - filter("ENC"."DTENCAISS_DT" IS NULL)
 139 - access("DECO"."REFDOSS"=:B1)
 141 - access("DECO"."REFLOT"="CONTR"."REFDOSS")
 142 - access("GETDCLI"='C519')
 144 - filter("SC"."FG227"='O')
 145 - access("SC"."REFDOSS"=:B1 AND "SC"."TYPPIECE"='SOUS-CONTRAT')
 147 - access("CMP"."REFLOT"=:B1 AND "CMP"."CATEGDOSS" LIKE 'COMPTE%')
       filter("CMP"."CATEGDOSS" LIKE 'COMPTE%')
 148 - filter(("FI"."REC_GRP_CNSAF"='NP' AND "FI"."DTMARQUE_DT" IS NULL))
 149 - access("FI"."REFDOSS"="CMP"."REFDOSS")
       filter(("FI"."TYPE"='ANNULATION DAVOIRS PAR DES REGLEMENTS' OR "FI"."TYPE"='NON MATCHED PAYMENT ELEMENTS' OR "FI"."TYPE"='POSITIVE LTL DECLARED
              PAYMENTS'))
 150 - access("AMTMEMO"."REFELEM"="FI"."REFELEM")
 151 - filter(("AMTMEMO"."REFDOSS"="FI"."REFDOSS" AND "AMTMEMO"."CODECR"='DPRIN'))
 162 - access("DECO"."REFDOSS"=:B1)
 164 - access("DECO"."REFLOT"="CONTR"."REFDOSS")
 166 - access("CTR"."REFDOSS"="CONTR"."REFDOSS" AND "CTR"."TYPPIECE"='CONTRAT')
       filter("CTR"."REFDOSS" IS NOT NULL)
 167 - access("CF"."REFPIECE"="CTR"."REFPIECE")
 168 - filter("CF"."FG_FINBAL"='O')
 170 - access("GETDCLI"='C519')
 172 - access("CMP"."REFLOT"=:B1 AND "CMP"."CATEGDOSS" LIKE 'COMPTE%')
       filter("CMP"."CATEGDOSS" LIKE 'COMPTE%')
 173 - filter(("FI"."REC_GRP_CNSAF"='NP' AND "FI"."DTMARQUE_DT" IS NULL AND DECODE(INTERNAL_FUNCTION("FI"."DTMARQUE_DT"),NULL,"FI"."DTANNUL_DT",NULL)
              IS NULL))
 174 - access("FI"."REFDOSS"="CMP"."REFDOSS")
       filter(("FI"."TYPE"='OPERATION DIVERSE CREDITRICE' OR "FI"."TYPE"='OPERATION DIVERSE DEBITRICE'))
 175 - access("AMTMEMO"."REFELEM"="FI"."REFELEM")
 176 - filter(("FI"."REFDOSS"="AMTMEMO"."REFDOSS" AND NVL("AMTMEMO"."CODECR",'x')='PRIN'))
 187 - access("DECO"."REFDOSS"=:B1)
 189 - access("DECO"."REFLOT"="CONTR"."REFDOSS")
 191 - access("CTR"."REFDOSS"="CONTR"."REFDOSS" AND "CTR"."TYPPIECE"='CONTRAT')
       filter("CTR"."REFDOSS" IS NOT NULL)
 192 - access("CF"."REFPIECE"="CTR"."REFPIECE")
 193 - filter("CF"."FG_FINBAL"='O')
 195 - access("GETDCLI"='C519')
 197 - access("CMP"."REFLOT"=:B1 AND "CMP"."CATEGDOSS" LIKE 'COMPTE%')
       filter("CMP"."CATEGDOSS" LIKE 'COMPTE%')
 198 - filter(("FI"."DTMARQUE_DT" IS NOT NULL AND "FI"."REC_GRP_ANSAF"='NP' AND INTERNAL_FUNCTION("FI"."TYPE") AND "FI"."DTMARQUE_AN_DT" IS NULL))
 199 - access("FI"."REFDOSS"="CMP"."REFDOSS")
       filter("FI"."DTANNUL_DT" IS NOT NULL)
 200 - access("AMTMEMO"."REFELEM"="FI"."REFELEM")
 201 - filter(("FI"."REFDOSS"="AMTMEMO"."REFDOSS" AND NVL("AMTMEMO"."CODECR",'x')='APRIN'))
 212 - access("DECO"."REFDOSS"=:B1)
 214 - access("DECO"."REFLOT"="CONTR"."REFDOSS")
 216 - access("CTR"."REFDOSS"="CONTR"."REFDOSS" AND "CTR"."TYPPIECE"='CONTRAT')
       filter("CTR"."REFDOSS" IS NOT NULL)
 217 - access("CF"."REFPIECE"="CTR"."REFPIECE")
 218 - filter("CF"."FG_FINBAL"='O')
 220 - access("GETDCLI"='C519')
 222 - access("CMP"."REFLOT"=:B1 AND "CMP"."CATEGDOSS" LIKE 'COMPTE%')
       filter("CMP"."CATEGDOSS" LIKE 'COMPTE%')
 223 - filter(("FI"."REC_GRP_CNSAF"='NP' AND "FI"."DTMARQUE_DT" IS NULL AND DECODE(INTERNAL_FUNCTION("FI"."DTMARQUE_DT"),NULL,"FI"."DTANNUL_DT",NULL)
              IS NULL))
 224 - access("FI"."REFDOSS"="CMP"."REFDOSS")
       filter(("FI"."TYPE"='ANNULATION ODC' OR "FI"."TYPE"='ANNULATION ODD'))
 225 - access("AMTMEMO"."REFELEM"="FI"."REFELEM")
 226 - filter(("FI"."REFDOSS"="AMTMEMO"."REFDOSS" AND NVL("AMTMEMO"."CODECR",'x')='DPRIN'))
 237 - access("DECO"."REFDOSS"=:B1)
 239 - access("DECO"."REFLOT"="CONTR"."REFDOSS")
 241 - access("CTR"."REFDOSS"="CONTR"."REFDOSS" AND "CTR"."TYPPIECE"='CONTRAT')
       filter("CTR"."REFDOSS" IS NOT NULL)
 242 - access("CF"."REFPIECE"="CTR"."REFPIECE")
 243 - filter("CF"."FG_FINBAL"='O')
 245 - access("GETDCLI"='C519')
 247 - access("CMP"."REFLOT"=:B1 AND "CMP"."CATEGDOSS" LIKE 'COMPTE%')
       filter("CMP"."CATEGDOSS" LIKE 'COMPTE%')
 248 - filter(("FI"."DTMARQUE_DT" IS NOT NULL AND "FI"."REC_GRP_ANSAF"='NP' AND INTERNAL_FUNCTION("FI"."TYPE") AND "FI"."DTMARQUE_AN_DT" IS NULL))
 249 - access("FI"."REFDOSS"="CMP"."REFDOSS")
       filter("FI"."DTANNUL_DT" IS NOT NULL)
 250 - access("AMTMEMO"."REFELEM"="FI"."REFELEM")
 251 - filter(("FI"."REFDOSS"="AMTMEMO"."REFDOSS" AND NVL("AMTMEMO"."CODECR",'x')='ADPRI'))
 252 - filter("RNUM">=:B4)
 253 - filter(ROWNUM<=:B3)
 255 - filter(ROWNUM<=:B3)
 259 - access("T"."REFDOSS"=:B1 AND "T"."REFTYPE"='DB')
 260 - access("T"."REFINDIVIDU"="I"."REFINDIVIDU")
 262 - access("D"."ABREV"=CASE  WHEN ((("V"."TYPENCAISS"='e_saencaiss') OR ("V"."TYPENCAISS"='exchange_diff_saf')) AND ("V"."TP"='E')) THEN 'PD' WHEN
              ((("V"."TYPENCAISS"='e_saencaiss') OR ("V"."TYPENCAISS"='exchange_diff_saf')) AND ("V"."TP"='A')) THEN 'PD_ANN' WHEN
              (("V"."TYPENCAISS"='ptf_reconcil_saf') AND ("E"."LIBELLE"='De-allocated Payments')) THEN 'DEALL_PMT' WHEN (("V"."TYPENCAISS"='ptf_reconcil_saf') AND
              ("E"."LIBELLE"='Solde de Ptf suite Reconcil')) THEN 'SOLDE_PTF' END )
 264 - filter(("V"."REFDOSS_DCMP"=:B1 AND INTERNAL_FUNCTION("V"."TP") AND "V"."DTMARQUE_DT" IS NULL AND "V"."REC_GRP_PMTSAF"='NP'))
 267 - access("E"."REFENCAISS"="V"."REFENCAISS")
 270 - filter('AL'=:B2)
 272 - access("TYPE"='MISC_TRANSLATIONS')
 273 - filter('AN'=:B2)
 275 - access("TYPE"='MISC_TRANSLATIONS')
 276 - filter('DA'=:B2)
 278 - access("TYPE"='MISC_TRANSLATIONS')
 279 - filter('ES'=:B2)
 281 - access("TYPE"='MISC_TRANSLATIONS')
 282 - filter('FI'=:B2)
 284 - access("TYPE"='MISC_TRANSLATIONS')
 285 - filter('FR'=:B2)
 287 - access("TYPE"='MISC_TRANSLATIONS')
 288 - filter('HU'=:B2)
 290 - access("TYPE"='MISC_TRANSLATIONS')
 291 - filter('IT'=:B2)
 293 - access("TYPE"='MISC_TRANSLATIONS')
 294 - filter('NL'=:B2)
 296 - access("TYPE"='MISC_TRANSLATIONS')
 297 - filter('NO'=:B2)
 299 - access("TYPE"='MISC_TRANSLATIONS')
 300 - filter('PT'=:B2)
 302 - access("TYPE"='MISC_TRANSLATIONS')
 305 - access("T"."REFDOSS"=:B1 AND "T"."REFTYPE"='DB')
 306 - access("T"."REFINDIVIDU"="I"."REFINDIVIDU")
 308 - access("D"."ABREV"=CASE  WHEN (("V"."TP"='F') AND ("F"."TYPE"='SAF CN COMP')) THEN 'SAFCNCOMP' WHEN (("V"."TP"='F') AND
              ("F"."TYPE"='SAF_NMP_CANCEL')) THEN 'SAFNMPCANCEL' WHEN (("V"."TP"='F') AND ("F"."TYPE"='NON MATCHED PAYMENT ELEMENTS')) THEN 'EPNL' WHEN
              (("V"."TP"='F') AND ("F"."TYPE"='POSITIVE LTL DECLARED PAYMENTS')) THEN 'PDPL' WHEN (("V"."TP"='F') AND ("F"."TYPE"='ANNULATION DAVOIRS PAR DES
              REGLEMENTS')) THEN 'AAVR' WHEN (("V"."TP"='F') AND ("F"."TYPE"='OPERATION DIVERSE CREDITRICE')) THEN 'ODC' WHEN (("V"."TP"='C') AND ("F"."TYPE"='SAF
              CN COMP')) THEN 'ANN_SAF' WHEN (("V"."TP"='C') AND ("F"."TYPE"='SAF_NMP_CANCEL')) THEN 'ANN_SAFNMP' WHEN (("V"."TP"='C') AND ("F"."TYPE"='DRAFT'))
              THEN 'ANN_DRAFT' ELSE "F"."TYPE" END )
 310 - filter(("V"."REFDOSS_DCMP"=:B1 AND INTERNAL_FUNCTION("V"."TP") AND "V"."DTMARQUE_DT" IS NULL AND "V"."REC_GRP_PMTSAF"='NP'))
 313 - access("F"."REFELEM"="V"."REFENCAISS")
 316 - filter('AL'=:B2)
 318 - access("TYPE"='MISC_TRANSLATIONS')
 319 - filter('AN'=:B2)
 321 - access("TYPE"='MISC_TRANSLATIONS')
 322 - filter('DA'=:B2)
 324 - access("TYPE"='MISC_TRANSLATIONS')
 325 - filter('ES'=:B2)
 327 - access("TYPE"='MISC_TRANSLATIONS')
 328 - filter('FI'=:B2)
 330 - access("TYPE"='MISC_TRANSLATIONS')
 331 - filter('FR'=:B2)
 333 - access("TYPE"='MISC_TRANSLATIONS')
 334 - filter('HU'=:B2)
 336 - access("TYPE"='MISC_TRANSLATIONS')
 337 - filter('IT'=:B2)
 339 - access("TYPE"='MISC_TRANSLATIONS')
 340 - filter('NL'=:B2)
 342 - access("TYPE"='MISC_TRANSLATIONS')
 343 - filter('NO'=:B2)
 345 - access("TYPE"='MISC_TRANSLATIONS')
 346 - filter('PT'=:B2)
 348 - access("TYPE"='MISC_TRANSLATIONS')
*/
/********************************New Metrics***************************************/

/********************************Index statistics**********************************/

/********************************Other SQLs****************************************/          
/*

*/ 
/********************************Other SQLs****************************************/              
