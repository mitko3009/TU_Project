/********************************************************************************
*********       E-mail subject: EFEURDEV-6197
*********             Instance: PIZAVAL
*********          Description: 
Problem:
The query below was provided as slow from the backend logs.

Analysis:
We executed manually the provided query on PIZAVAL and the heaviest part in the execution plan is the FULL SCAN of table T_ELEMENTS. 
The reason for the FULL SCAN is the OR operator in the WHERE clause, which should be replaced with UNION to avoid the FULL SCAN. This will solve the main problem 
in the query, but we see several other things that are not optimal from performance point of view and we want to optimize it. In the New SQL section below, we prepared 
sample version of the provided query, where we moved the SUBSELECT for the docType from the SELECT part to the FROM clause. The idea is to not execute it for every selected row. 
Also, we moved the SUBSELECT for the check of the chemin into inline view, because we want to access the tables only once.

Suggestion:
Please check is the query in the New SQL section below functionaly correct and if it is, please implement it.

*********               SQL_ID: 
*********      Program/Package: 
*********              Request: Nina Dimitrova V9
*********               Author: Dimitar Dimitrov
********* Received e-mail date: 16/01/2025
*********      Resolution date: 17/01/2025
*********  Trace old file here: \\epox\specifs\performance\tmp\
*********  Trace new file here:
***********************************************************************************/

/********************************OLD SQL*******************************************/

VAR B1 VARCHAR2(32);
EXEC :B1 := 'A706POYR';
VAR B2 VARCHAR2(32);
EXEC :B2 := 'AN';
VAR B3 VARCHAR2(32);
EXEC :B3 := '2211070036';

SELECT refelem AS docRef,
       refdoss AS caseRef,
       typeelem AS typeElem,
       reason_annul AS cancelReason,
       dtannul_dt AS cancelDate,
       ( select valeur_trad
           from ( SELECT valeur_trad,
                         row_number() over(ORDER BY DECODE(chemin, 'OTHER', 1, 0))
                    FROM v_tdomaine
                   WHERE type = 'PMT_REQ_CHANNEL'
                     AND ( chemin = ( SELECT SUBSTR(createur, 1, LENGTH(chemin))
                                        FROM g_pendingpmt
                                       WHERE refpmt = :B1
                                      UNION
                                      SELECT SUBSTR(createur, 1, LENGTH(chemin))
                                        FROM g_pendingpmt_EXEC
                                       WHERE refpmt = :B1
                                         AND ROWNUM = 1 ) 
                        OR chemin = 'OTHER' )
                     AND Nvl( langue, 'FR' ) = :B2
                     AND ROWNUM = 1
                   ORDER BY DECODE( chemin, 'OTHER', 1, 0 ) ) ) AS docType,
       TRUNC( dtassoc_dt, 'DD' ) AS creationDate,
       TO_CHAR( dtassoc_dt, 'DD/MM/YYYY HH24:MI:SS' ) AS creationDateTime,
       montant AS entredAmt,
       montant_dos AS caseAmt,
       DECODE( LENGTH( libelle ), 0, libelle, imx.FTRANSLATE_STR( te.libelle, :B2, te.typeelem ) ) AS title,
       te.rowid
  FROM t_elements te
 WHERE (   refelem = :B1 
       AND refdoss = :B3 
       AND typeelem in ( 're', 'pp', 'st' ) )
    OR  (te.refelem = ( SELECT te.refelem
                          FROM ( select * 
                                   from nam_ecr_compta_bak ) ecb,
                               g_outpmt gout,
                               g_encaissement ge,
                               t_elements te
                         WHERE ecb.refmvt = gout.refoutpmt
                           AND gout.refer = ge.refencaiss
                           AND ge.refencaiss = te.refelem
                           and refmvt = :B1
                           and ecb.typmvt = 'd'
                           and ecb.refdoss = :B3 ) )
   AND rownum = 1;

/********************************OLD SQL*******************************************/
/********************************OLD Metrics***************************************/
/*

Plan hash value: 4117404881
------------------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                  | Name                    | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  |
------------------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                           |                         |      1 |        |   174K(100)|      2 |00:01:27.44 |     828K|    827K|
|   1 |  VIEW                                      |                         |      1 |      1 |    36   (0)|      1 |00:00:00.02 |      12 |      5 |
|   2 |   WINDOW SORT                              |                         |      1 |      1 |    36   (0)|      1 |00:00:00.02 |      12 |      5 |
|*  3 |    COUNT STOPKEY                           |                         |      1 |        |            |      1 |00:00:00.02 |      12 |      5 |
|*  4 |     FILTER                                 |                         |      1 |        |            |      1 |00:00:00.02 |      12 |      5 |
|   5 |      VIEW                                  | V_TDOMAINE              |      1 |   1332 |    36   (0)|      4 |00:00:00.01 |       3 |      2 |
|   6 |       UNION-ALL                            |                         |      1 |        |            |      4 |00:00:00.01 |       3 |      2 |
|*  7 |        FILTER                              |                         |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
|   8 |         TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE               |      0 |     37 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*  9 |          INDEX RANGE SCAN                  | V_DOMAINE_TYPE_CODE_IDX |      0 |     37 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 10 |        FILTER                              |                         |      1 |        |            |      4 |00:00:00.01 |       3 |      2 |
|  11 |         TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE               |      1 |     37 |     1   (0)|      4 |00:00:00.01 |       3 |      2 |
|* 12 |          INDEX RANGE SCAN                  | V_DOMAINE_TYPE_CODE_IDX |      1 |     37 |     1   (0)|      4 |00:00:00.01 |       2 |      1 |
|* 13 |        FILTER                              |                         |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  14 |         TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE               |      0 |     37 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 15 |          INDEX RANGE SCAN                  | V_DOMAINE_TYPE_CODE_IDX |      0 |     37 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 16 |        FILTER                              |                         |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  17 |         TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE               |      0 |     37 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 18 |          INDEX RANGE SCAN                  | V_DOMAINE_TYPE_CODE_IDX |      0 |     37 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 19 |        FILTER                              |                         |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  20 |         TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE               |      0 |     37 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 21 |          INDEX RANGE SCAN                  | V_DOMAINE_TYPE_CODE_IDX |      0 |     37 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 22 |        FILTER                              |                         |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  23 |         TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE               |      0 |     37 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 24 |          INDEX RANGE SCAN                  | V_DOMAINE_TYPE_CODE_IDX |      0 |     37 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 25 |        FILTER                              |                         |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  26 |         TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE               |      0 |     37 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 27 |          INDEX RANGE SCAN                  | V_DOMAINE_TYPE_CODE_IDX |      0 |     37 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 28 |        FILTER                              |                         |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  29 |         TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE               |      0 |     37 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 30 |          INDEX RANGE SCAN                  | V_DOMAINE_TYPE_CODE_IDX |      0 |     37 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 31 |        FILTER                              |                         |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  32 |         TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE               |      0 |     37 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 33 |          INDEX RANGE SCAN                  | V_DOMAINE_TYPE_CODE_IDX |      0 |     37 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 34 |        FILTER                              |                         |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  35 |         TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE               |      0 |     37 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 36 |          INDEX RANGE SCAN                  | V_DOMAINE_TYPE_CODE_IDX |      0 |     37 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 37 |        FILTER                              |                         |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  38 |         TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE               |      0 |     37 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 39 |          INDEX RANGE SCAN                  | V_DOMAINE_TYPE_CODE_IDX |      0 |     37 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 40 |        FILTER                              |                         |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  41 |         TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE               |      0 |     37 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 42 |          INDEX RANGE SCAN                  | V_DOMAINE_TYPE_CODE_IDX |      0 |     37 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 43 |        FILTER                              |                         |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  44 |         TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE               |      0 |     37 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 45 |          INDEX RANGE SCAN                  | V_DOMAINE_TYPE_CODE_IDX |      0 |     37 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 46 |        FILTER                              |                         |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  47 |         TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE               |      0 |     37 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 48 |          INDEX RANGE SCAN                  | V_DOMAINE_TYPE_CODE_IDX |      0 |     37 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 49 |        FILTER                              |                         |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  50 |         TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE               |      0 |     37 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 51 |          INDEX RANGE SCAN                  | V_DOMAINE_TYPE_CODE_IDX |      0 |     37 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 52 |        FILTER                              |                         |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  53 |         TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE               |      0 |     37 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 54 |          INDEX RANGE SCAN                  | V_DOMAINE_TYPE_CODE_IDX |      0 |     37 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 55 |        FILTER                              |                         |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  56 |         TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE               |      0 |     37 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 57 |          INDEX RANGE SCAN                  | V_DOMAINE_TYPE_CODE_IDX |      0 |     37 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 58 |        FILTER                              |                         |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  59 |         TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE               |      0 |     37 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 60 |          INDEX RANGE SCAN                  | V_DOMAINE_TYPE_CODE_IDX |      0 |     37 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 61 |        FILTER                              |                         |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  62 |         TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE               |      0 |     37 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 63 |          INDEX RANGE SCAN                  | V_DOMAINE_TYPE_CODE_IDX |      0 |     37 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 64 |        FILTER                              |                         |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  65 |         TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE               |      0 |     37 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 66 |          INDEX RANGE SCAN                  | V_DOMAINE_TYPE_CODE_IDX |      0 |     37 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 67 |        FILTER                              |                         |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  68 |         TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE               |      0 |     37 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 69 |          INDEX RANGE SCAN                  | V_DOMAINE_TYPE_CODE_IDX |      0 |     37 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 70 |        FILTER                              |                         |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  71 |         TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE               |      0 |     37 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 72 |          INDEX RANGE SCAN                  | V_DOMAINE_TYPE_CODE_IDX |      0 |     37 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 73 |        FILTER                              |                         |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  74 |         TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE               |      0 |     37 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 75 |          INDEX RANGE SCAN                  | V_DOMAINE_TYPE_CODE_IDX |      0 |     37 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 76 |        FILTER                              |                         |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  77 |         TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE               |      0 |     37 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 78 |          INDEX RANGE SCAN                  | V_DOMAINE_TYPE_CODE_IDX |      0 |     37 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 79 |        FILTER                              |                         |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  80 |         TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE               |      0 |     37 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 81 |          INDEX RANGE SCAN                  | V_DOMAINE_TYPE_CODE_IDX |      0 |     37 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 82 |        FILTER                              |                         |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  83 |         TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE               |      0 |     37 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 84 |          INDEX RANGE SCAN                  | V_DOMAINE_TYPE_CODE_IDX |      0 |     37 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 85 |        FILTER                              |                         |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  86 |         TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE               |      0 |     37 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 87 |          INDEX RANGE SCAN                  | V_DOMAINE_TYPE_CODE_IDX |      0 |     37 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 88 |        FILTER                              |                         |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  89 |         TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE               |      0 |     37 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 90 |          INDEX RANGE SCAN                  | V_DOMAINE_TYPE_CODE_IDX |      0 |     37 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 91 |        FILTER                              |                         |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  92 |         TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE               |      0 |     37 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 93 |          INDEX RANGE SCAN                  | V_DOMAINE_TYPE_CODE_IDX |      0 |     37 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 94 |        FILTER                              |                         |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  95 |         TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE               |      0 |     37 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 96 |          INDEX RANGE SCAN                  | V_DOMAINE_TYPE_CODE_IDX |      0 |     37 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 97 |        FILTER                              |                         |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  98 |         TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE               |      0 |     37 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 99 |          INDEX RANGE SCAN                  | V_DOMAINE_TYPE_CODE_IDX |      0 |     37 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*100 |        FILTER                              |                         |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 101 |         TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE               |      0 |     37 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*102 |          INDEX RANGE SCAN                  | V_DOMAINE_TYPE_CODE_IDX |      0 |     37 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*103 |        FILTER                              |                         |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 104 |         TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE               |      0 |     37 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*105 |          INDEX RANGE SCAN                  | V_DOMAINE_TYPE_CODE_IDX |      0 |     37 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*106 |        FILTER                              |                         |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 107 |         TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE               |      0 |     37 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*108 |          INDEX RANGE SCAN                  | V_DOMAINE_TYPE_CODE_IDX |      0 |     37 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*109 |        FILTER                              |                         |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 110 |         TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE               |      0 |     37 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*111 |          INDEX RANGE SCAN                  | V_DOMAINE_TYPE_CODE_IDX |      0 |     37 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*112 |        FILTER                              |                         |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 113 |         TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE               |      0 |     37 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*114 |          INDEX RANGE SCAN                  | V_DOMAINE_TYPE_CODE_IDX |      0 |     37 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 115 |      SORT UNIQUE                           |                         |      3 |      2 |     2   (0)|      0 |00:00:00.01 |       9 |      3 |
| 116 |       UNION-ALL                            |                         |      3 |        |            |      0 |00:00:00.01 |       9 |      3 |
| 117 |        TABLE ACCESS BY INDEX ROWID         | G_PENDINGPMT            |      3 |      1 |     1   (0)|      0 |00:00:00.01 |       3 |      1 |
|*118 |         INDEX UNIQUE SCAN                  | PK_G_PENDINGPMT         |      3 |      1 |     1   (0)|      0 |00:00:00.01 |       3 |      1 |
|*119 |        COUNT STOPKEY                       |                         |      3 |        |            |      0 |00:00:00.01 |       6 |      2 |
| 120 |         TABLE ACCESS BY INDEX ROWID        | G_PENDINGPMT_EXEC       |      3 |      1 |     1   (0)|      0 |00:00:00.01 |       6 |      2 |
|*121 |          INDEX UNIQUE SCAN                 | PK_G_PENDINGPMT_EXEC    |      3 |      1 |     1   (0)|      0 |00:00:00.01 |       6 |      2 |
| 122 |  COUNT                                     |                         |      1 |        |            |      2 |00:01:27.44 |     828K|    827K|
|*123 |   FILTER                                   |                         |      1 |        |            |      2 |00:01:27.44 |     828K|    827K|
| 124 |    TABLE ACCESS FULL                       | T_ELEMENTS              |      1 |     19M|   174K  (1)|     21M|00:01:24.18 |     828K|    827K|
| 125 |    MERGE JOIN CARTESIAN                    |                         |      1 |      1 |     4   (0)|      0 |00:00:00.02 |       2 |      2 |
| 126 |     NESTED LOOPS                           |                         |      1 |      1 |     3   (0)|      0 |00:00:00.02 |       2 |      2 |
| 127 |      NESTED LOOPS                          |                         |      1 |      1 |     2   (0)|      0 |00:00:00.02 |       2 |      2 |
|*128 |       TABLE ACCESS BY INDEX ROWID          | G_OUTPMT                |      1 |      1 |     1   (0)|      0 |00:00:00.02 |       2 |      2 |
|*129 |        INDEX UNIQUE SCAN                   | G_OUTPMT$REFOUTPMT      |      1 |      1 |     1   (0)|      0 |00:00:00.02 |       2 |      2 |
|*130 |       INDEX UNIQUE SCAN                    | REFENCAISS              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*131 |      INDEX RANGE SCAN                      | ELE_ELEMTYPE            |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 132 |     BUFFER SORT                            |                         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*133 |      TABLE ACCESS BY INDEX ROWID BATCHED   | NAM_ECR_COMPTA_BAK      |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*134 |       INDEX RANGE SCAN                     | NAMECR_REFMVT_BAK       |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
------------------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   3 - filter(ROWNUM=1)
   4 - filter(("CHEMIN"='OTHER' OR "CHEMIN"=))
   7 - filter('AL'=:B2)
   9 - access("TYPE"='PMT_REQ_CHANNEL')
  10 - filter('AN'=:B2)
  12 - access("TYPE"='PMT_REQ_CHANNEL')
  13 - filter('AR'=:B2)
  15 - access("TYPE"='PMT_REQ_CHANNEL')
  16 - filter('BG'=:B2)
  18 - access("TYPE"='PMT_REQ_CHANNEL')
  19 - filter('BR'=:B2)
  21 - access("TYPE"='PMT_REQ_CHANNEL')
  22 - filter('CE'=:B2)
  24 - access("TYPE"='PMT_REQ_CHANNEL')
  25 - filter('CH'=:B2)
  27 - access("TYPE"='PMT_REQ_CHANNEL')
  28 - filter('CS'=:B2)
  30 - access("TYPE"='PMT_REQ_CHANNEL')
  31 - filter('DA'=:B2)
  33 - access("TYPE"='PMT_REQ_CHANNEL')
  34 - filter('EL'=:B2)
  36 - access("TYPE"='PMT_REQ_CHANNEL')
  37 - filter('ES'=:B2)
  39 - access("TYPE"='PMT_REQ_CHANNEL')
  40 - filter('ET'=:B2)
  42 - access("TYPE"='PMT_REQ_CHANNEL')
  43 - filter('FI'=:B2)
  45 - access("TYPE"='PMT_REQ_CHANNEL')
  46 - filter('FR'=:B2)
  48 - access("TYPE"='PMT_REQ_CHANNEL')
  49 - filter('HR'=:B2)
  51 - access("TYPE"='PMT_REQ_CHANNEL')
  52 - filter('HU'=:B2)
  54 - access("TYPE"='PMT_REQ_CHANNEL')
  55 - filter('IT'=:B2)
  57 - access("TYPE"='PMT_REQ_CHANNEL')
  58 - filter('IW'=:B2)
  60 - access("TYPE"='PMT_REQ_CHANNEL')
  61 - filter('JA'=:B2)
  63 - access("TYPE"='PMT_REQ_CHANNEL')
  64 - filter('LT'=:B2)
  66 - access("TYPE"='PMT_REQ_CHANNEL')
  67 - filter('LV'=:B2)
  69 - access("TYPE"='PMT_REQ_CHANNEL')
  70 - filter('MX'=:B2)
  72 - access("TYPE"='PMT_REQ_CHANNEL')
  73 - filter('NL'=:B2)
  75 - access("TYPE"='PMT_REQ_CHANNEL')
  76 - filter('NO'=:B2)
  78 - access("TYPE"='PMT_REQ_CHANNEL')
  79 - filter('PL'=:B2)
  81 - access("TYPE"='PMT_REQ_CHANNEL')
  82 - filter('PT'=:B2)
  84 - access("TYPE"='PMT_REQ_CHANNEL')
  85 - filter('RO'=:B2)
  87 - access("TYPE"='PMT_REQ_CHANNEL')
  88 - filter('RU'=:B2)
  90 - access("TYPE"='PMT_REQ_CHANNEL')
  91 - filter('SK'=:B2)
  93 - access("TYPE"='PMT_REQ_CHANNEL')
  94 - filter('SL'=:B2)
  96 - access("TYPE"='PMT_REQ_CHANNEL')
  97 - filter('SR'=:B2)
  99 - access("TYPE"='PMT_REQ_CHANNEL')
 100 - filter('SV'=:B2)
 102 - access("TYPE"='PMT_REQ_CHANNEL')
 103 - filter('TR'=:B2)
 105 - access("TYPE"='PMT_REQ_CHANNEL')
 106 - filter('US'=:B2)
 108 - access("TYPE"='PMT_REQ_CHANNEL')
 109 - filter('VI'=:B2)
 111 - access("TYPE"='PMT_REQ_CHANNEL')
 112 - filter('ZH'=:B2)
 114 - access("TYPE"='PMT_REQ_CHANNEL')
 118 - access("REFPMT"=:B1)
 119 - filter(ROWNUM=1)
 121 - access("REFPMT"=:B1)
 123 - filter((("TE"."REFELEM"=:B1 AND "REFDOSS"=:B3 AND INTERNAL_FUNCTION("TYPEELEM")) OR (ROWNUM=1 AND "TE"."REFELEM"=)))
 128 - filter("GOUT"."REFER" IS NOT NULL)
 129 - access("GOUT"."REFOUTPMT"=:B1)
 130 - access("GOUT"."REFER"="GE"."REFENCAISS")
 131 - access("GE"."REFENCAISS"="TE"."REFELEM")
 133 - filter(("NAM_ECR_COMPTA_BAK"."REFDOSS"=:B3 AND "NAM_ECR_COMPTA_BAK"."TYPMVT"='d'))
 134 - access("NAM_ECR_COMPTA_BAK"."REFMVT"=:B1)

*/
/********************************OLD Metrics***************************************/

/********************************New SQL*******************************************/
SELECT /*+ leading(te) use_merge(dom) no_merge(dom) */
       refelem AS docRef,
       refdoss AS caseRef,
       typeelem AS typeElem,
       reason_annul AS cancelReason,
       dtannul_dt AS cancelDate,
       dom.docType,
       TRUNC( dtassoc_dt, 'DD' ) AS creationDate,
       TO_CHAR( dtassoc_dt, 'DD/MM/YYYY HH24:MI:SS' ) AS creationDateTime,
       montant AS entredAmt,
       montant_dos AS caseAmt,
       DECODE( LENGTH( libelle ), 0, libelle, ( select imx.FTRANSLATE_STR( te.libelle, :B2, te.typeelem ) from dual ) ) AS title,
       te.rid
  FROM ( SELECT e.rowid rid,
                e.*
           FROM t_elements e
          WHERE refelem = :B1 
            AND refdoss = :B3 
            AND typeelem in ( 're', 'pp', 'st' )
            AND rownum = 1
          UNION 
         SELECT e.rowid rid,
                e.*
           FROM t_elements e,
                nam_ecr_compta_bak ecb,
                g_outpmt gout,
                g_encaissement ge
          WHERE ecb.typmvt = 'd'
            AND ecb.refdoss = :B3
            AND ecb.refmvt = :B1
            AND ecb.refmvt = gout.refoutpmt
            AND gout.refer = ge.refencaiss
            AND ge.refencaiss = e.refelem
            AND rownum = 1 ) te,
       ( select valeur_trad AS docType
           from ( SELECT valeur_trad,
                         row_number() over(ORDER BY DECODE(chemin, 'OTHER', 1, 0))
                    FROM v_tdomaine,
                         ( SELECT createur
                             FROM g_pendingpmt
                            WHERE refpmt = :B1
                           UNION
                           SELECT createur
                             FROM g_pendingpmt_EXEC
                            WHERE refpmt = :B1
                              AND ROWNUM = 1 ) cr
                   WHERE type = 'PMT_REQ_CHANNEL'
                     AND ( chemin = SUBSTR(cr.createur, 1, LENGTH(chemin)) 
                        OR chemin = 'OTHER' )
                     AND Nvl(langue, 'FR' ) = :B2
                     AND ROWNUM = 1
                   ORDER BY DECODE( chemin, 'OTHER', 1, 0 ) ) ) dom 
 WHERE rownum = 1;

/********************************New SQL*******************************************/
/********************************New Metrics***************************************/
/*
Plan hash value: 3390317247
----------------------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                      | Name                    | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  |
----------------------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                               |                         |      1 |        |    81 (100)|      0 |00:00:00.03 |       9 |      6 |
|   1 |  FAST DUAL                                     |                         |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*  2 |  COUNT STOPKEY                                 |                         |      1 |        |            |      0 |00:00:00.03 |       9 |      6 |
|   3 |   MERGE JOIN CARTESIAN                         |                         |      1 |      1 |    79   (3)|      0 |00:00:00.03 |       9 |      6 |
|   4 |    VIEW                                        |                         |      1 |      1 |     4  (25)|      1 |00:00:00.03 |       6 |      3 |
|   5 |     SORT UNIQUE                                |                         |      1 |      2 |     6  (17)|      1 |00:00:00.03 |       6 |      3 |
|   6 |      UNION-ALL                                 |                         |      1 |        |            |      1 |00:00:00.03 |       6 |      3 |
|*  7 |       COUNT STOPKEY                            |                         |      1 |        |            |      1 |00:00:00.01 |       4 |      1 |
|*  8 |        TABLE ACCESS BY INDEX ROWID BATCHED     | T_ELEMENTS              |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       4 |      1 |
|*  9 |         INDEX RANGE SCAN                       | ELE_ELEMTYPE            |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |      0 |
|* 10 |       COUNT STOPKEY                            |                         |      1 |        |            |      0 |00:00:00.03 |       2 |      2 |
|  11 |        MERGE JOIN CARTESIAN                    |                         |      1 |      1 |     4   (0)|      0 |00:00:00.03 |       2 |      2 |
|  12 |         NESTED LOOPS                           |                         |      1 |      1 |     3   (0)|      0 |00:00:00.03 |       2 |      2 |
|  13 |          NESTED LOOPS                          |                         |      1 |      1 |     2   (0)|      0 |00:00:00.03 |       2 |      2 |
|* 14 |           TABLE ACCESS BY INDEX ROWID          | G_OUTPMT                |      1 |      1 |     1   (0)|      0 |00:00:00.03 |       2 |      2 |
|* 15 |            INDEX UNIQUE SCAN                   | G_OUTPMT$REFOUTPMT      |      1 |      1 |     1   (0)|      0 |00:00:00.03 |       2 |      2 |
|* 16 |           INDEX UNIQUE SCAN                    | REFENCAISS              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|  17 |          TABLE ACCESS BY INDEX ROWID BATCHED   | T_ELEMENTS              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 18 |           INDEX RANGE SCAN                     | ELE_ELEMTYPE            |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|  19 |         BUFFER SORT                            |                         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 20 |          TABLE ACCESS BY INDEX ROWID BATCHED   | NAM_ECR_COMPTA_BAK      |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 21 |           INDEX RANGE SCAN                     | NAMECR_REFMVT_BAK       |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|  22 |    BUFFER SORT                                 |                         |      1 |      1 |    79   (3)|      0 |00:00:00.01 |       3 |      3 |
|  23 |     VIEW                                       |                         |      1 |      1 |    75   (2)|      0 |00:00:00.01 |       3 |      3 |
|  24 |      VIEW                                      |                         |      1 |      1 |    75   (2)|      0 |00:00:00.01 |       3 |      3 |
|  25 |       WINDOW SORT                              |                         |      1 |      1 |    75   (2)|      0 |00:00:00.01 |       3 |      3 |
|* 26 |        COUNT STOPKEY                           |                         |      1 |        |            |      0 |00:00:00.01 |       3 |      3 |
|  27 |         NESTED LOOPS                           |                         |      1 |      1 |    75   (2)|      0 |00:00:00.01 |       3 |      3 |
|  28 |          VIEW                                  |                         |      1 |      2 |     3  (34)|      0 |00:00:00.01 |       3 |      3 |
|  29 |           SORT UNIQUE                          |                         |      1 |      2 |     3  (34)|      0 |00:00:00.01 |       3 |      3 |
|  30 |            UNION-ALL                           |                         |      1 |        |            |      0 |00:00:00.01 |       3 |      3 |
|  31 |             TABLE ACCESS BY INDEX ROWID        | G_PENDINGPMT            |      1 |      1 |     1   (0)|      0 |00:00:00.01 |       1 |      1 |
|* 32 |              INDEX UNIQUE SCAN                 | PK_G_PENDINGPMT         |      1 |      1 |     1   (0)|      0 |00:00:00.01 |       1 |      1 |
|* 33 |             COUNT STOPKEY                      |                         |      1 |        |            |      0 |00:00:00.01 |       2 |      2 |
|  34 |              TABLE ACCESS BY INDEX ROWID       | G_PENDINGPMT_EXEC       |      1 |      1 |     1   (0)|      0 |00:00:00.01 |       2 |      2 |
|* 35 |               INDEX UNIQUE SCAN                | PK_G_PENDINGPMT_EXEC    |      1 |      1 |     1   (0)|      0 |00:00:00.01 |       2 |      2 |
|* 36 |          VIEW                                  | V_TDOMAINE              |      0 |      1 |    36   (0)|      0 |00:00:00.01 |       0 |      0 |
|  37 |           UNION-ALL                            |                         |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|* 38 |            FILTER                              |                         |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  39 |             TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE               |      0 |     37 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 40 |              INDEX RANGE SCAN                  | V_DOMAINE_TYPE_CODE_IDX |      0 |     37 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 41 |            FILTER                              |                         |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  42 |             TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE               |      0 |     37 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 43 |              INDEX RANGE SCAN                  | V_DOMAINE_TYPE_CODE_IDX |      0 |     37 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 44 |            FILTER                              |                         |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  45 |             TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE               |      0 |     37 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 46 |              INDEX RANGE SCAN                  | V_DOMAINE_TYPE_CODE_IDX |      0 |     37 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 47 |            FILTER                              |                         |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  48 |             TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE               |      0 |     37 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 49 |              INDEX RANGE SCAN                  | V_DOMAINE_TYPE_CODE_IDX |      0 |     37 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 50 |            FILTER                              |                         |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  51 |             TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE               |      0 |     37 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 52 |              INDEX RANGE SCAN                  | V_DOMAINE_TYPE_CODE_IDX |      0 |     37 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 53 |            FILTER                              |                         |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  54 |             TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE               |      0 |     37 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 55 |              INDEX RANGE SCAN                  | V_DOMAINE_TYPE_CODE_IDX |      0 |     37 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 56 |            FILTER                              |                         |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  57 |             TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE               |      0 |     37 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 58 |              INDEX RANGE SCAN                  | V_DOMAINE_TYPE_CODE_IDX |      0 |     37 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 59 |            FILTER                              |                         |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  60 |             TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE               |      0 |     37 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 61 |              INDEX RANGE SCAN                  | V_DOMAINE_TYPE_CODE_IDX |      0 |     37 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 62 |            FILTER                              |                         |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  63 |             TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE               |      0 |     37 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 64 |              INDEX RANGE SCAN                  | V_DOMAINE_TYPE_CODE_IDX |      0 |     37 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 65 |            FILTER                              |                         |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  66 |             TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE               |      0 |     37 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 67 |              INDEX RANGE SCAN                  | V_DOMAINE_TYPE_CODE_IDX |      0 |     37 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 68 |            FILTER                              |                         |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  69 |             TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE               |      0 |     37 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 70 |              INDEX RANGE SCAN                  | V_DOMAINE_TYPE_CODE_IDX |      0 |     37 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 71 |            FILTER                              |                         |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  72 |             TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE               |      0 |     37 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 73 |              INDEX RANGE SCAN                  | V_DOMAINE_TYPE_CODE_IDX |      0 |     37 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 74 |            FILTER                              |                         |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  75 |             TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE               |      0 |     37 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 76 |              INDEX RANGE SCAN                  | V_DOMAINE_TYPE_CODE_IDX |      0 |     37 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 77 |            FILTER                              |                         |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  78 |             TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE               |      0 |     37 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 79 |              INDEX RANGE SCAN                  | V_DOMAINE_TYPE_CODE_IDX |      0 |     37 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 80 |            FILTER                              |                         |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  81 |             TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE               |      0 |     37 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 82 |              INDEX RANGE SCAN                  | V_DOMAINE_TYPE_CODE_IDX |      0 |     37 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 83 |            FILTER                              |                         |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  84 |             TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE               |      0 |     37 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 85 |              INDEX RANGE SCAN                  | V_DOMAINE_TYPE_CODE_IDX |      0 |     37 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 86 |            FILTER                              |                         |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  87 |             TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE               |      0 |     37 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 88 |              INDEX RANGE SCAN                  | V_DOMAINE_TYPE_CODE_IDX |      0 |     37 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 89 |            FILTER                              |                         |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  90 |             TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE               |      0 |     37 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 91 |              INDEX RANGE SCAN                  | V_DOMAINE_TYPE_CODE_IDX |      0 |     37 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 92 |            FILTER                              |                         |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  93 |             TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE               |      0 |     37 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 94 |              INDEX RANGE SCAN                  | V_DOMAINE_TYPE_CODE_IDX |      0 |     37 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 95 |            FILTER                              |                         |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  96 |             TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE               |      0 |     37 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 97 |              INDEX RANGE SCAN                  | V_DOMAINE_TYPE_CODE_IDX |      0 |     37 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 98 |            FILTER                              |                         |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  99 |             TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE               |      0 |     37 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*100 |              INDEX RANGE SCAN                  | V_DOMAINE_TYPE_CODE_IDX |      0 |     37 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*101 |            FILTER                              |                         |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 102 |             TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE               |      0 |     37 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*103 |              INDEX RANGE SCAN                  | V_DOMAINE_TYPE_CODE_IDX |      0 |     37 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*104 |            FILTER                              |                         |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 105 |             TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE               |      0 |     37 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*106 |              INDEX RANGE SCAN                  | V_DOMAINE_TYPE_CODE_IDX |      0 |     37 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*107 |            FILTER                              |                         |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 108 |             TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE               |      0 |     37 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*109 |              INDEX RANGE SCAN                  | V_DOMAINE_TYPE_CODE_IDX |      0 |     37 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*110 |            FILTER                              |                         |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 111 |             TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE               |      0 |     37 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*112 |              INDEX RANGE SCAN                  | V_DOMAINE_TYPE_CODE_IDX |      0 |     37 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*113 |            FILTER                              |                         |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 114 |             TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE               |      0 |     37 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*115 |              INDEX RANGE SCAN                  | V_DOMAINE_TYPE_CODE_IDX |      0 |     37 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*116 |            FILTER                              |                         |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 117 |             TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE               |      0 |     37 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*118 |              INDEX RANGE SCAN                  | V_DOMAINE_TYPE_CODE_IDX |      0 |     37 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*119 |            FILTER                              |                         |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 120 |             TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE               |      0 |     37 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*121 |              INDEX RANGE SCAN                  | V_DOMAINE_TYPE_CODE_IDX |      0 |     37 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*122 |            FILTER                              |                         |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 123 |             TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE               |      0 |     37 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*124 |              INDEX RANGE SCAN                  | V_DOMAINE_TYPE_CODE_IDX |      0 |     37 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*125 |            FILTER                              |                         |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 126 |             TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE               |      0 |     37 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*127 |              INDEX RANGE SCAN                  | V_DOMAINE_TYPE_CODE_IDX |      0 |     37 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*128 |            FILTER                              |                         |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 129 |             TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE               |      0 |     37 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*130 |              INDEX RANGE SCAN                  | V_DOMAINE_TYPE_CODE_IDX |      0 |     37 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*131 |            FILTER                              |                         |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 132 |             TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE               |      0 |     37 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*133 |              INDEX RANGE SCAN                  | V_DOMAINE_TYPE_CODE_IDX |      0 |     37 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*134 |            FILTER                              |                         |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 135 |             TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE               |      0 |     37 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*136 |              INDEX RANGE SCAN                  | V_DOMAINE_TYPE_CODE_IDX |      0 |     37 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*137 |            FILTER                              |                         |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 138 |             TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE               |      0 |     37 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*139 |              INDEX RANGE SCAN                  | V_DOMAINE_TYPE_CODE_IDX |      0 |     37 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*140 |            FILTER                              |                         |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 141 |             TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE               |      0 |     37 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*142 |              INDEX RANGE SCAN                  | V_DOMAINE_TYPE_CODE_IDX |      0 |     37 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*143 |            FILTER                              |                         |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 144 |             TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE               |      0 |     37 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*145 |              INDEX RANGE SCAN                  | V_DOMAINE_TYPE_CODE_IDX |      0 |     37 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
----------------------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   2 - filter(ROWNUM=1)
   7 - filter(ROWNUM=1)
   8 - filter("REFDOSS"=:B3)
   9 - access("REFELEM"=:B1)
       filter(("TYPEELEM"='pp' OR "TYPEELEM"='re' OR "TYPEELEM"='st'))
  10 - filter(ROWNUM=1)
  14 - filter("GOUT"."REFER" IS NOT NULL)
  15 - access("GOUT"."REFOUTPMT"=:B1)
  16 - access("GOUT"."REFER"="GE"."REFENCAISS")
  18 - access("GE"."REFENCAISS"="E"."REFELEM")
  20 - filter(("ECB"."REFDOSS"=:B3 AND "ECB"."TYPMVT"='d'))
  21 - access("ECB"."REFMVT"=:B1)
  26 - filter(ROWNUM=1)
  32 - access("REFPMT"=:B1)
  33 - filter(ROWNUM=1)
  35 - access("REFPMT"=:B1)
  36 - filter(("CHEMIN"=SUBSTR("CR"."CREATEUR",1,LENGTH("CHEMIN")) OR "CHEMIN"='OTHER'))
  38 - filter('AL'=:B2)
  40 - access("TYPE"='PMT_REQ_CHANNEL')
  41 - filter('AN'=:B2)
  43 - access("TYPE"='PMT_REQ_CHANNEL')
  44 - filter('AR'=:B2)
  46 - access("TYPE"='PMT_REQ_CHANNEL')
  47 - filter('BG'=:B2)
  49 - access("TYPE"='PMT_REQ_CHANNEL')
  50 - filter('BR'=:B2)
  52 - access("TYPE"='PMT_REQ_CHANNEL')
  53 - filter('CE'=:B2)
  55 - access("TYPE"='PMT_REQ_CHANNEL')
  56 - filter('CH'=:B2)
  58 - access("TYPE"='PMT_REQ_CHANNEL')
  59 - filter('CS'=:B2)
  61 - access("TYPE"='PMT_REQ_CHANNEL')
  62 - filter('DA'=:B2)
  64 - access("TYPE"='PMT_REQ_CHANNEL')
  65 - filter('EL'=:B2)
  67 - access("TYPE"='PMT_REQ_CHANNEL')
  68 - filter('ES'=:B2)
  70 - access("TYPE"='PMT_REQ_CHANNEL')
  71 - filter('ET'=:B2)
  73 - access("TYPE"='PMT_REQ_CHANNEL')
  74 - filter('FI'=:B2)
  76 - access("TYPE"='PMT_REQ_CHANNEL')
  77 - filter('FR'=:B2)
  79 - access("TYPE"='PMT_REQ_CHANNEL')
  80 - filter('HR'=:B2)
  82 - access("TYPE"='PMT_REQ_CHANNEL')
  83 - filter('HU'=:B2)
  85 - access("TYPE"='PMT_REQ_CHANNEL')
  86 - filter('IT'=:B2)
  88 - access("TYPE"='PMT_REQ_CHANNEL')
  89 - filter('IW'=:B2)
  91 - access("TYPE"='PMT_REQ_CHANNEL')
  92 - filter('JA'=:B2)
  94 - access("TYPE"='PMT_REQ_CHANNEL')
  95 - filter('LT'=:B2)
  97 - access("TYPE"='PMT_REQ_CHANNEL')
  98 - filter('LV'=:B2)
 100 - access("TYPE"='PMT_REQ_CHANNEL')
 101 - filter('MX'=:B2)
 103 - access("TYPE"='PMT_REQ_CHANNEL')
 104 - filter('NL'=:B2)
 106 - access("TYPE"='PMT_REQ_CHANNEL')
 107 - filter('NO'=:B2)
 109 - access("TYPE"='PMT_REQ_CHANNEL')
 110 - filter('PL'=:B2)
 112 - access("TYPE"='PMT_REQ_CHANNEL')
 113 - filter('PT'=:B2)
 115 - access("TYPE"='PMT_REQ_CHANNEL')
 116 - filter('RO'=:B2)
 118 - access("TYPE"='PMT_REQ_CHANNEL')
 119 - filter('RU'=:B2)
 121 - access("TYPE"='PMT_REQ_CHANNEL')
 122 - filter('SK'=:B2)
 124 - access("TYPE"='PMT_REQ_CHANNEL')
 125 - filter('SL'=:B2)
 127 - access("TYPE"='PMT_REQ_CHANNEL')
 128 - filter('SR'=:B2)
 130 - access("TYPE"='PMT_REQ_CHANNEL')
 131 - filter('SV'=:B2)
 133 - access("TYPE"='PMT_REQ_CHANNEL')
 134 - filter('TR'=:B2)
 136 - access("TYPE"='PMT_REQ_CHANNEL')
 137 - filter('US'=:B2)
 139 - access("TYPE"='PMT_REQ_CHANNEL')
 140 - filter('VI'=:B2)
 142 - access("TYPE"='PMT_REQ_CHANNEL')
 143 - filter('ZH'=:B2)
 145 - access("TYPE"='PMT_REQ_CHANNEL')
*/
/********************************New Metrics***************************************/

/********************************Index statistics**********************************/

/********************************Other SQLs****************************************/          
/*

*/ 
/********************************Other SQLs****************************************/              
