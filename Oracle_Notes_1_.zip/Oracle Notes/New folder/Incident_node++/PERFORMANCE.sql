[10:51 AM] Stefanov, Simeon (Oracle DBA)
    1. Tunning i Diagnostic PAC license
2.
@?/rdbms/admin/awrrpt.sql            AWR report
@?/rdbms/admin/ashrpt.sql            ASH report
@?/rdbms/admin/addmrpt.sql   Automatic Database Diagnostic Monitor (ADDM) in Oracle Database 10g
@$ORACLE_HOME/rdbms/admin/ashrpt.sql
<https://teams.microsoft.com/l/message/19:030390b56c0147aea60aa0b3e2ac6300@thread.tacv2/1590133881751?tenantId=93f33571-550f-43cf-b09f-cd331338d086&amp;groupId=1303c506-c9e6-463f-853d-cc879ee59515&amp;parentMessageId=1589976023369&amp;teamName=Oracle Academy 2020&amp;channelName=Oracle&amp;createdTime=1590133881751>


##FInd PID for blockinck sessions user
set lines 400
set pages 1000
col pid for a25
SQL> SQL> SQL> --col sid for a25
SQL> --col ser# for a16
col box for a15
col username for a25
col os_user for a15
SQL> SQL> SQL> SQL> col program for a35
select
       a.spid "PID",
       b.sid "SID",
       b.serial# "SERIAL#",
SQL>   2    3    4    5         b.machine "MACHINE",
       b.username "USERNAME",
       b.osuser "OS_USER",
       b.program PROGRAM
from v$session b, v$process a
where
b.paddr = a.addr
and type='USER'
order by spid;


desc dba_jobs;

select job from dba_jobs;

##Scheduler
set lines 200
select owner,job_name, LAST_START_DATE, NEXT_RUN_DATE from dba_scheduler_jobs;
 
## desc dba_scheduler_jobs;


============================
============================
==============================

Performance- CASE Bazata mi raboti bavno
Free -m
top
Sesii
network/tnsping
disk usage
Natovarvaneto v bazata
alert log
statistics
sga/pga  
swap


1. Tunning i Diagnostic PAC license
2. 
@?/rdbms/admin/awrrpt.sql                                  AWR report
@?/rdbms/admin/ashrpt.sql                                  ASH report
STATSPACK 

@$ORACLE_HOME/rdbms/admin/ashrpt.sql

set lines 200
col username for a15
col machine for a40
col module for a50
col service_name for a30
select USERNAME,MACHINE,status,SERVICE_NAME, count(*) from  v$session group by USERNAME,MACHINE,status,SERVICE_NAME order by username;


###BLOCKING -- IMA problem
set linesize 400
col USERNAME for a10
col LOGON_TIME for a20
col IS_BLOCKING for a15
col PROGRAM for a27
select
l1.INST_ID, l1.sid, a.serial#, a.USERNAME, a.PROGRAM, TO_CHAR(a.logon_time, 'MM/DD/YY HH24:MI:SS') as logon_time, 'IS_BLOCKING' as IS_BLOCKING,
l2.INST_ID, l2.sid, b.serial#, b.USERNAME, b.PROGRAM, TO_CHAR(b.logon_time, 'MM/DD/YY HH24:MI:SS') as logon_time
from gv$lock l1, gv$lock l2, gv$session a, gv$session b
where l1.id1=l2.id1 and l1.id2=l2.id2 and a.SID=l1.sid and b.SID=l2.sid
and l1.inst_id=l2.inst_id and l2.inst_id=a.inst_id and a.inst_id=b.inst_id and l1.sid! = l2.sid
and l1.block =1 and l2.request > 0 order by a.LOGON_TIME;


##########Long running jobs
set lines 200
col username for a15
col opname for a50
col sqltext for a40
SELECT sl.sid,
       sl.serial#,
       sl.opname,
       sl.username,  
       to_char(vs.logon_time, 'DDMMYYYY HH24:MI:SS') logon_time,
       substr(s.sql_text, 1, 30) sqltext,
       round((sl.elapsed_seconds/60), 2) elap_min,
       round((sl.sofar / sl.totalwork) * 100, 2) perc_done,
       round((sl.time_remaining / 60), 2) time_remaining
  FROM v$session_longops sl, v$session vs, v$sql s
WHERE sl.sofar <> sl.totalwork
   AND sl.totalwork <> 0
   AND sl.sid = vs.sid
   AND sl.serial#(+) = vs.serial#
   AND s.address(+) = vs.sql_address
   AND s.hash_value(+) = vs.sql_hash_value
GROUP BY sl.sid,
         sl.serial#,
         sl.opname,
         sl.username,  
         to_char(vs.logon_time, 'DDMMYYYY HH24:MI:SS'),
         s.sql_text,         
         round((sl.elapsed_seconds/60), 2),
         round((sl.sofar / sl.totalwork) * 100, 2),
         round((sl.time_remaining / 60), 2)
--ORDER BY sl.opname
ORDER BY 8 desc;

######waiters
set lines 240
set pages 200
alter session set nls_date_format='MM/DD/YYYY HH24:MI:SS';
col event for a40
col P1TEXT for a9
col P2TEXT for a10
col P3TEXT for a10
col WAIT_CLASS for a10
col SID for 99999
col machine for a30
col USERNAME for a20
select username,P1text,p1,p2text,p2,machine,sql_Id ,status, event, wait_class,sid,wait_time,SQL_EXEC_START from gv$session where WAIT_CLASS <> 'Idle' order by SQL_EXEC_START;

####Script to find PID from SID
set lines 400
set pages 1000
col pid for a25
--col sid for a25
--col ser# for a16
col box for a15
col username for a25
col os_user for a15
col program for a35
select
       a.spid "PID",
       b.sid "SID",
       b.serial# "SERIAL#",
                 b.machine "MACHINE",
       b.username "USERNAME",
       b.osuser "OS_USER",
       b.program PROGRAM
from v$session b, v$process a
where
b.paddr = a.addr
and type='USER'
order by spid;



########SCHEDULER
set lines 200
select owner,job_name,LAST_START_DATE,NEXT_RUN_DATE from dba_scheduler_jobs;

###Session 1
update kamen.customers set customer_name='KAMEN3' where customer_id=1;
update kamen.customers set income=3000 where customer_id=20;

###Session 2
update kamen.customers set income=4000 where customer_id=20;
update kamen.customers set customer_name='KAMEN8' where customer_id=1;

SQL> select * from kamen.customers;

CUSTOMER_ID CUSTOMER_NAME                                          INCOME CITY
----------- -------------------------------------------------- ---------- --------------------------------------------------
          1 Kamen                                                 1350000 Cape Town
         20 Todor                                                   50000 Plovdiv
        300 Vanya                                                   25000 Varna
       4000 Petya                                                  120000 Burgas






