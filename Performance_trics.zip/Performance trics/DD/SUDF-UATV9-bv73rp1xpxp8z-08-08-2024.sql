/********************************************************************************
*********       E-mail subject: SUDFDEV-7139
*********             Instance: UAT V9
*********          Description: 
Problem:
Slowness in limit processing on UAT V9.

Analysis:
After the analyze, we found that the second TOP SQL, which was responsible for 36% of the time was bv73rp1xpxp8z ( from ftr_request_limit.pck ).
The problem in it is that it access table G_PIECE through index G_PIECE$ID_VENTE, where selects almost 2 million rows.
We added hint to force Oracle to access table G_PIECE through index G_PIECE$ADR3, where it selects only 25 rows and it is much more selective.

Suggestion:
Please add hint as it is shown in the New SQL section below.

*********               SQL_ID: bv73rp1xpxp8z
*********      Program/Package: ftr_request_limit.pck
*********              Request: Nikolay Minev
*********               Author: Dimitar Dimitrov
********* Received e-mail date: 08/08/2024
*********      Resolution date: 08/08/2024
*********  Trace old file here: \\epox\specifs\performance\tmp\
*********  Trace new file here:
***********************************************************************************/

/********************************OLD SQL*******************************************/

VAR B1 VARCHAR2(32);
EXEC :B1 := 'Primary=2';
VAR B2 VARCHAR2(32);
EXEC :B2 := 'A60144E9';
VAR B3 VARCHAR2(32);
EXEC :B3 := 'B3';

SELECT NVL(SUM(CH_TAUX.CONV_ORIG_DEST_TX(TO_CHAR(SYSDATE,'j'), MT02, CODE, :B3 , 'MR', FTR_FIN_FACTOR.GETCURRENCY(:B1 ), FTR_FIN_FACTOR.GETPAYS(:B1 ))), 0) 
  FROM G_PIECE LIM 
 WHERE TYPPIECE = 'REQUEST_LIMITE' 
   AND TYPEDOC IN ('C', 'D') 
   AND GPIADR3 = :B2 
   AND GPITYPTRIB = :B1 
   AND FG05 = 'O' 
   AND GPIROLE IN ('DC', 'DT');
/********************************OLD SQL*******************************************/
/********************************OLD Metrics***************************************/
/*
MODULE                           CLIENT_ID       SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- --------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
BCA46E732AB6B71AE5EB637D444318C2 petekn                                                                              2024/08/07 16:38:01  2024/08/07 16:44:39         131                  866 +000000000 00:06:38.189 97%
699264288D62D7CCD8E041A7392BBB6E petekn                                                         ON CPU               2024/08/07 16:40:26  2024/08/07 16:43:32           4                   31 +000000000 00:03:06.072 3%

MODULE                           CLIENT_ID       SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- --------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
BCA46E732AB6B71AE5EB637D444318C2 petekn                                          509       2799                      2024/08/07 16:38:18  2024/08/07 16:43:17          69                  865 +000000000 00:04:59.115 48%
BCA46E732AB6B71AE5EB637D444318C2 petekn                                          996      28795                      2024/08/07 16:39:59  2024/08/07 16:44:29          29                   77 +000000000 00:04:30.121 20%
BCA46E732AB6B71AE5EB637D444318C2 petekn                                          930      39848 ON CPU               2024/08/07 16:41:58  2024/08/07 16:44:39          12                   54 +000000000 00:02:41.108 8%
BCA46E732AB6B71AE5EB637D444318C2 petekn                                         1356      56357 ON CPU               2024/08/07 16:38:12  2024/08/07 16:41:47           8                  732 +000000000 00:03:35.071 6%
BCA46E732AB6B71AE5EB637D444318C2 petekn                                          722      17907                      2024/08/07 16:38:01  2024/08/07 16:41:39           7                    1 +000000000 00:03:38.085 5%
prm_pack                         pericm                                         1281      11010 ON CPU               2024/08/07 16:46:30  2024/08/07 16:46:32           3                    1 +000000000 00:00:01.999 2%
BCA46E732AB6B71AE5EB637D444318C2 petekn          8v2drfk0wypvt 2835276436       1281      11010 db file sequential r 2024/08/07 16:43:47  2024/08/07 16:43:49           3                    1 +000000000 00:00:01.999 2%
BCA46E732AB6B71AE5EB637D444318C2 petekn                                          433      48097 ON CPU               2024/08/07 16:41:47  2024/08/07 16:42:46           3                    1 +000000000 00:00:59.053 2%
699264288D62D7CCD8E041A7392BBB6E petekn          2ckh595dcmpm0                  1356      56357 ON CPU               2024/08/07 16:41:41  2024/08/07 16:41:42           2                      +000000000 00:00:00.999 1%
699264288D62D7CCD8E041A7392BBB6E petekn                                          996      28795 ON CPU               2024/08/07 16:40:26  2024/08/07 16:43:32           2                   31 +000000000 00:03:06.072 1%
D48E32DA90A1CB878CAC20755DB0A108 pericm          cxdvbhbqzrs15 1411476048        509       2799 ON CPU               2024/08/07 16:42:35  2024/08/07 16:42:35           1                    1 +000000000 00:00:00.000 1%
D48E32DA90A1CB878CAC20755DB0A108 pericm          cxdvbhbqzrs15 1411476048        722      51111 ON CPU               2024/08/07 16:45:00  2024/08/07 16:45:00           1                    1 +000000000 00:00:00.000 1%
D48E32DA90A1CB878CAC20755DB0A108 pericm          cxdvbhbqzrs15 1411476048        930      39848 ON CPU               2024/08/07 16:44:04  2024/08/07 16:44:04           1                    1 +000000000 00:00:00.000 1%
D48E32DA90A1CB878CAC20755DB0A108 pericm          cxdvbhbqzrs15 1411476048        996      28795 ON CPU               2024/08/07 16:41:54  2024/08/07 16:41:54           1                    1 +000000000 00:00:00.000 1%
D48E32DA90A1CB878CAC20755DB0A108 pericm          cxdvbhbqzrs15 1411476048       1356      56357 ON CPU               2024/08/07 16:38:08  2024/08/07 16:38:08           1                    1 +000000000 00:00:00.000 1%
DC7CE34F24D2F0BBEFD636BC4AD9D647 pericm          093jm1sv91ua1  536876756       1281      11010 db file sequential r 2024/08/07 16:46:29  2024/08/07 16:46:29           1                    1 +000000000 00:00:00.000 1%


MODULE                           CLIENT_ID       SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- --------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
BCA46E732AB6B71AE5EB637D444318C2 petekn                                                         ON CPU               2024/08/07 16:38:01  2024/08/07 16:44:39          71                  734 +000000000 00:06:38.189 53%
BCA46E732AB6B71AE5EB637D444318C2 petekn                                                         db file sequential r 2024/08/07 16:40:10  2024/08/07 16:44:29          54                  816 +000000000 00:04:19.101 40%
699264288D62D7CCD8E041A7392BBB6E petekn                                                         ON CPU               2024/08/07 16:40:26  2024/08/07 16:43:32           4                   31 +000000000 00:03:06.072 3%
BCA46E732AB6B71AE5EB637D444318C2 petekn          8v2drfk0wypvt 2835276436        509       2799 db file parallel rea 2024/08/07 16:41:03  2024/08/07 16:41:06           4                    1 +000000000 00:00:02.998 3%
BCA46E732AB6B71AE5EB637D444318C2 petekn          1m7zmjz77xad7          0        722      17907 cursor: pin S wait o 2024/08/07 16:41:36  2024/08/07 16:41:36           1                      +000000000 00:00:00.000 1%
BCA46E732AB6B71AE5EB637D444318C2 petekn                                 0        509       2799 log file sync        2024/08/07 16:41:49  2024/08/07 16:41:49           1                      +000000000 00:00:00.000 1%

MODULE                           CLIENT_ID       SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- --------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
BCA46E732AB6B71AE5EB637D444318C2 petekn          8v2drfk0wypvt 2835276436                                            2024/08/07 16:40:10  2024/08/07 16:44:29          60                   31 +000000000 00:04:19.101 44%
BCA46E732AB6B71AE5EB637D444318C2 petekn          bv73rp1xpxp8z  230518406                       ON CPU               2024/08/07 16:38:01  2024/08/07 16:44:39          49                    9 +000000000 00:06:38.189 36%

INSTANCE_NUMBER SQL_ID            ELAPSED MAX_WAIT_ON     PC_OF  WAIT_TIME            GETS      READS       ROWS  ELAP/EXEC       GETS/EXEC READS/EXEC  ROWS/EXEC       EXEC PLAN_HASH_VALUE
--------------- ------------- ----------- --------------- ----- ---------- --------------- ---------- ---------- ---------- --------------- ---------- ---------- ---------- ---------------
              1 8v2drfk0wypvt         105 IO              97%   101.675641          455842     125614        114        .92            3999    1101.88          1        114      2835276436
              1 bv73rp1xpxp8z          85 CPU             100%   23.068434        18945519          1         16       5.32         1184095        .06          1         16       230518406

Plan hash value: 230518406
------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                             | Name             | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  |
------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                      |                  |      1 |        |     1 (100)|      1 |00:00:46.56 |    1193K|    236K|
|   1 |  SORT AGGREGATE                       |                  |      1 |      1 |            |      1 |00:00:46.56 |    1193K|    236K|
|   2 |   INLIST ITERATOR                     |                  |      1 |        |            |      0 |00:00:46.56 |    1193K|    236K|
|*  3 |    TABLE ACCESS BY INDEX ROWID BATCHED| G_PIECE          |      2 |      1 |     1   (0)|      0 |00:00:46.56 |    1193K|    236K|
|*  4 |     INDEX RANGE SCAN                  | G_PIECE$ID_VENTE |      2 |      1 |     1   (0)|   1917K|00:00:03.86 |    8038 |   3920 |
------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   3 - filter(("GPIADR3"=:B2 AND "GPITYPTRIB"=:B1 AND "FG05"='O' AND INTERNAL_FUNCTION("TYPEDOC")))
   4 - access((("GPIROLE"='DC' OR "GPIROLE"='DT')) AND "TYPPIECE"='REQUEST_LIMITE')
*/
/********************************OLD Metrics***************************************/

/********************************New SQL*******************************************/

SELECT /*+ index(LIM G_PIECE$ADR3) */
       NVL(SUM(CH_TAUX.CONV_ORIG_DEST_TX(TO_CHAR(SYSDATE,'j'), MT02, CODE, :B3 , 'MR', FTR_FIN_FACTOR.GETCURRENCY(:B1 ), FTR_FIN_FACTOR.GETPAYS(:B1 ))), 0) 
  FROM G_PIECE LIM 
 WHERE TYPPIECE = 'REQUEST_LIMITE' 
   AND TYPEDOC IN ('C', 'D') 
   AND GPIADR3 = :B2 
   AND GPITYPTRIB = :B1 
   AND FG05 = 'O' 
   AND GPIROLE IN ('DC', 'DT');
/********************************New SQL*******************************************/
/********************************New Metrics***************************************/
/*
Plan hash value: 3032484933
-------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                            | Name         | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  |
-------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                     |              |      1 |        |     1 (100)|      1 |00:00:00.01 |      25 |      2 |
|   1 |  SORT AGGREGATE                      |              |      1 |      1 |            |      1 |00:00:00.01 |      25 |      2 |
|*  2 |   TABLE ACCESS BY INDEX ROWID BATCHED| G_PIECE      |      1 |      1 |     1   (0)|      0 |00:00:00.01 |      25 |      2 |
|*  3 |    INDEX RANGE SCAN                  | G_PIECE$ADR3 |      1 |    177 |     1   (0)|     25 |00:00:00.01 |       4 |      2 |
-------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   2 - filter(("TYPPIECE"='REQUEST_LIMITE' AND "GPITYPTRIB"=:B1 AND "FG05"='O' AND INTERNAL_FUNCTION("GPIROLE") AND
              INTERNAL_FUNCTION("TYPEDOC")))
   3 - access("GPIADR3"=:B2)

*/
/********************************New Metrics***************************************/

/********************************Index statistics**********************************/

/********************************Other SQLs****************************************/          
/*

*/ 
/********************************Other SQLs****************************************/              
