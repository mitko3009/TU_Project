/********************************************************************************
*********       E-mail subject: ARVALDEV-1988 
*********             Instance: PROD
*********          Description: 
Problem:
SQL fx1nj5xpuska1 from ES Variable:ds_maitre was identified as heavy on ARVAL PROD.

Analysis:
I executed SQL fx1nj5xpuska1 on bongval and I received the same execution plan as on PROD. The slowness comes from this that the query makes a full scan 
of table g_dossier, because in the second part of the OR ( exists (select 1 from g_dossier where refdoss_maitre = :refdos) ) the table g_dossier in the exists 
is not joined with table g_dossier in the main select. On bongval, the full scan is fast, because the data volumes are very small ( in table g_dossier on bongval 
there are 974 rows ), but on PROD where the data volumes are much bigger the full scan will take time. In the New SQL section below, we rewrite the query as we think 
it should be. Could you please check is it OK? If it is not, please think how this query should be changed to skip the full scan of table g_dossier.

Suggestion:
Please check the variant of the query in the New SQL section below and if it is OK to you, change ES Variable:ds_maitre as it is shown in the New SQl section below.

*********               SQL_ID: fx1nj5xpuska1
*********      Program/Package: ES Variable:ds_maitre
*********              Request: Dimitare Ivanov
*********               Author: Dimitar Dimitrov
********* Received e-mail date: 07/06/2024
*********      Resolution date: 10/06/2024
*********  Trace old file here: \\epox\specifs\performance\tmp\
*********  Trace new file here:
***********************************************************************************/

/********************************OLD SQL*******************************************/

VAR refdos VARCHAR2(32);
EXEC :refdos := '1901300010';

select count(*)
  from g_dossier
 where (refdoss = :refdos and refdoss_maitre is null)
    or exists (select 1 from g_dossier where refdoss_maitre = :refdos);
/********************************OLD SQL*******************************************/
/********************************OLD Metrics***************************************/
/*

Plan hash value: 1801647163
------------------------------------------------------------------------------------------------------------------
| Id  | Operation          | Name                 | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers |
------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT   |                      |      1 |        |    29 (100)|      1 |00:00:00.02 |    1109 |
|   1 |  SORT AGGREGATE    |                      |      1 |      1 |            |      1 |00:00:00.02 |    1109 |
|*  2 |   TABLE ACCESS FULL| G_DOSSIER            |      1 |     50 |    29   (0)|    974 |00:00:00.02 |    1109 |
|*  3 |    INDEX RANGE SCAN| DOS_REFDS_MAITRE_IDX |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       1 |
------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   2 - filter((("REFDOSS"=:B1 AND "REFDOSS_MAITRE" IS NULL) OR  IS NOT NULL))
   3 - access("REFDOSS_MAITRE"=:B1)
*/
/********************************OLD Metrics***************************************/

/********************************New SQL*******************************************/

VAR refdos VARCHAR2(32);
EXEC :refdos := '1901300010';

select count(*)
  from dual 
 where exists ( select 1
                  from g_dossier 
                 where refdoss = :refdos  
                   and refdoss_maitre is null
                 union all
                select 1
                  from g_dossier 
                 where refdoss_maitre = :refdos );
/********************************New SQL*******************************************/
/********************************New Metrics***************************************/
/*
Plan hash value: 740764707
------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                      | Name                 | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers |
------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT               |                      |      1 |        |     5 (100)|      1 |00:00:00.01 |       4 |
|   1 |  SORT AGGREGATE                |                      |      1 |      1 |            |      1 |00:00:00.01 |       4 |
|*  2 |   FILTER                       |                      |      1 |        |            |      1 |00:00:00.01 |       4 |
|   3 |    FAST DUAL                   |                      |      1 |      1 |     2   (0)|      1 |00:00:00.01 |       0 |
|   4 |    UNION-ALL                   |                      |      1 |        |            |      1 |00:00:00.01 |       4 |
|*  5 |     TABLE ACCESS BY INDEX ROWID| G_DOSSIER            |      1 |      1 |     2   (0)|      1 |00:00:00.01 |       4 |
|*  6 |      INDEX UNIQUE SCAN         | DOS_REFDOSS          |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       2 |
|*  7 |     INDEX RANGE SCAN           | DOS_REFDS_MAITRE_IDX |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |
------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   2 - filter( IS NOT NULL)
   5 - filter("REFDOSS_MAITRE" IS NULL)
   6 - access("REFDOSS"=:REFDOS)
   7 - access("REFDOSS_MAITRE"=:REFDOS)
*/
/********************************New Metrics***************************************/

/********************************Index statistics**********************************/

/********************************Other SQLs****************************************/          
/*

*/ 
/********************************Other SQLs****************************************/              
