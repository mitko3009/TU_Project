============================================================================
###### EXOTIC / Informix /VOBE ######################
==================================================================================

Zabravih da kaja che ot root pravish : su – Informix I sled tova check-vash/puskash backup

=============================================================================================================================================================================================
########### Exotic Log backup 1065 metrika ############
=============================================================================================================================================================================================
 su – Informix I sled tova check-vash/puskash backup
 
onstat -l         ---> проверява логовете дали са бекъпирани
ontape -a -d          ----> пуска бекъп на лоджикъл логове
 
 
[informix@clv100430 ~]$ onstat -l
 
IBM Informix Dynamic Server Version 12.10.FC8W2 -- On-Line -- Up 9 days 12:37:54 -- 1320164 Kbytes
 
Physical Logging
Buffer bufused  bufsize  numpages   numwrits   pages/io
  P-1  59       64       123843     3491       35.47
      phybegin         physize    phypos     phyused    %used
      16:53            375000     276368     635        0.17
 
Logical Logging
Buffer bufused  bufsize  numrecs    numpages   numwrits   recs/pages pages/io
  L-1  1        32       1700672    197192     152163     8.6        1.3
        Subsystem    numrecs    Log Space used
        OLDRSAM      1697686    171881904
        SBLOB        20         1872
        HA           2746       120824
        DDL          220        70460
 
address          number   flags    uniqid   begin                size     used    %used    ---- sled backup, sled U trqbva da vijdash B
45afef88         4        U------  6984     3:53                25000    25000   100.00
4579af68         5        U------  6985     3:25053             25000    25000   100.00
45853f40         6        U------  6986     3:50053             25000    25000   100.00
45853fa8         7        U------  6987     3:75053             25000    25000   100.00
45ae2c50         8        U---C-L  6988     3:100053            25000    17409    69.64  ---- C oznachava Current(demek nqma da go backup-ira tozi, a samo gornite)
5 active, 5 total
 
[informix@clv100430 ~]$ ontape -a -d     ---- taka shte startirash backup-a
 
Performing automatic backup of logical logs.
 
File created: /u03/ifxbck/sbw_ol/bck_log/clv100430_28_Log0000006984
File created: /u03/ifxbck/sbw_ol/bck_log/clv100430_28_Log0000006985
File created: /u03/ifxbck/sbw_ol/bck_log/clv100430_28_Log0000006986
File created: /u03/ifxbck/sbw_ol/bck_log/clv100430_28_Log0000006987
Do you want to back up the current logical log? (y/n) n
 
Program over.
[informix@clv100430 ~]$ cd /u03/ifxbck/sbw_ol/bck_log/
[informix@clv100430 bck_log]$ ls -lrt
total 200320
-rw-rw----. 1 informix informix 51281920 Mar 13 07:34 clv100430_28_Log0000006984
-rw-rw----. 1 informix informix 51281920 Mar 13 07:34 clv100430_28_Log0000006985
-rw-rw----. 1 informix informix 51281920 Mar 13 07:34 clv100430_28_Log0000006986
-rw-rw----. 1 informix informix 51281920 Mar 13 07:34 clv100430_28_Log0000006987
 
