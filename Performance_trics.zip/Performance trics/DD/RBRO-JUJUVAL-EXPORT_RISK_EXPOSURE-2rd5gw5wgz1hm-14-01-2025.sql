/********************************************************************************
*********       E-mail subject: RBRODEV-4416
*********             Instance: JUJUVAL
*********          Description: 
Problem:
SQL 2rd5gw5wgz1hm was responsible for 7% of the time of the EXPORT_RISK_EXPOSURE on JUJUVAL.

Analysis:
We checked the execution plan of SQL 2rd5gw5wgz1hm and noticed that it can be improved. The current execution plan access table G_PIECE DB_C_LIM through the TYPEDOC column, which leads to selecting 
~ 20k rows and then make filter on the other conditions. The more selective path is to access table G_PIECE DB_C_LIM through the GPIADR3 column, which can be achieved by adding hint to the query. Also, 
it looks like tables G_DOSSIER DCMP and G_DOSSIER CMP in the EXISTS are the same as in the main FROM clause, so we think that they can be removed from the EXISTS and we can join directly table 
T_INTERVENANTS DB ( in the EXISTS ) with table CMP.REFDOSS ( from the main FROM clause ) as it is shown in the New SQL section below.
                       
Suggestion:
Please check is the SQL in the New SQL section below functionally correct and if it is, please change SQL 2rd5gw5wgz1hm as it is shown in the New SQL section below.

*********               SQL_ID: 2rd5gw5wgz1hm 
*********      Program/Package: 
*********              Request: Dimitare Ivanov
*********               Author: Dimitar Dimitrov
********* Received e-mail date: 14/01/2025
*********      Resolution date: 14/01/2025
*********  Trace old file here: \\epox\specifs\performance\tmp\
*********  Trace new file here:
***********************************************************************************/

/********************************OLD SQL*******************************************/

VAR B1 VARCHAR2(32);
EXEC :B1 := '1811280021';
VAR B2 VARCHAR2(32);
EXEC :B2 := 'DB';
var B9 varchar2(32);
exec :B9 := 'INT00000';
exec utl_app_date.cacheAppDate(:B9);

SELECT CASE WHEN :B2 = 'CL' 
            THEN SUM(ITEM.DF_MON) - ABS(SUM(WRITE_OFF.MONTANT)) 
            WHEN :B2 IN ('DB', 'DB_LEAD') 
            THEN SUM(WRITE_OFF.MONTANT) 
        END 
  FROM G_DOSSIER DCMP , 
       G_DOSSIER CMP , 
       F_DETFAC ITEM , 
       G_ELEMFI WRITE_OFF 
 WHERE DCMP.REFLOT = :B1 
   AND CMP.REFLOT = DCMP.REFDOSS 
   AND ITEM.DF_DOS (+)= DCMP.REFDOSS 
   AND ITEM.DF_NOM (+)= 'WFIU'
   AND WRITE_OFF.REFDOSS = CMP.REFDOSS 
   AND WRITE_OFF.TYPE = 'WRITE OFF'
   AND EXISTS ( SELECT 1 
                  FROM G_PIECE FACTURE 
                 WHERE CMP.REFDOSS = FACTURE.REFDOSS 
                   AND FACTURE.TYPPIECE = 'FACTURE' 
                   AND FACTURE.MT01 > 0 ) 
   AND EXISTS ( SELECT 1 
                  FROM T_INTERVENANTS DB, 
                       G_DOSSIER DCMP, 
                       G_DOSSIER CMP 
                 WHERE DCMP.REFLOT = :B1 
                   AND CMP.REFLOT = DCMP.REFDOSS 
                   AND DB.REFDOSS = CMP.REFDOSS 
                   AND DB.REFTYPE = 'DB' 
                   AND EXISTS ( SELECT 1 
                                  FROM G_PIECE DB_C_LIM 
                                 WHERE DB_C_LIM.TYPEDOC = 'C' 
                                   AND DB_C_LIM.TYPPIECE = 'REQUEST_LIMITE'
                                   AND DB_C_LIM.GPIADR3 = DB.REFINDIVIDU 
                                   AND DB_C_LIM.GPIDATE6_DT < UTL_APP_DATE.GETAPPDATE + 1 
                                   AND NVL(DB_C_LIM.GPIDTFIN_DT, TRUNC(SYSDATE + 1)) > UTL_APP_DATE.GETAPPDATE 
                                   AND DB_C_LIM.MT02 > 0.0 ) );
/********************************OLD SQL*******************************************/
/********************************OLD Metrics***************************************/
/*
MODULE                              SID    SERIAL# EVENT                FROM                 TO                       ACTIVE INTERVAL                PERC
-------------------------------- ------ ---------- -------------------- -------------------- -------------------- ---------- ----------------------- ------
EXPORT_USERS                        782      23511 db file sequential r 2025/01/13 21:24:05  2025/01/13 21:24:05           1 +000000000 00:00:00.000 0%
EXPORT_PRODUCT_TYPES                782      23511 db file sequential r 2025/01/13 21:24:06  2025/01/13 21:24:06           1 +000000000 00:00:00.000 0%
EXPORT_ACC_EVENTS                   782      23511 ON CPU               2025/01/13 21:24:07  2025/01/13 21:24:07           1 +000000000 00:00:00.000 0%
EXPORT_LIMIT_TYPES                  782      23511 db file sequential r 2025/01/13 21:24:08  2025/01/13 21:24:08           1 +000000000 00:00:00.000 0%
EXPORT_LIMITS                       782      23511                      2025/01/13 21:24:09  2025/01/13 21:42:05        1051 +000000000 00:17:55.200 14%
EXPORT_CONTRACTS                    782      23511                      2025/01/13 21:42:06  2025/01/13 21:48:25         372 +000000000 00:06:19.904 5%
EXPORT_FINANCING                    782      23511                      2025/01/13 21:48:26  2025/01/13 21:48:38          12 +000000000 00:00:11.263 0%
EXPORT_INTEREST                     782      23511                      2025/01/13 21:48:39  2025/01/13 21:49:53          73 +000000000 00:01:13.723 1%
EXPORT_BANK_ACCOUNTS                782      23511                      2025/01/13 21:49:54  2025/01/13 21:51:20          85 +000000000 00:01:26.016 1%
EXPORT_CONTRACT_ACCNT_LINK          782      23511 db file sequential r 2025/01/13 21:51:21  2025/01/13 21:51:21           1 +000000000 00:00:00.000 0%
EXPORT_LIM_CON_ACC_DEB_LINK         782      23511                      2025/01/13 21:51:22  2025/01/13 21:51:32          11 +000000000 00:00:10.240 0%
EXPORT_INVOICES                     782      23511                      2025/01/13 21:51:33  2025/01/13 22:15:23        1398 +000000000 00:23:50.527 19%
EXPORT_BUNDLES                      782      23511                      2025/01/13 22:15:36  2025/01/13 22:47:12        1853 +000000000 00:31:36.448 26%
EXPORT_CREDIT_FEES                  782      23511                      2025/01/13 22:47:13  2025/01/13 22:47:29          16 +000000000 00:00:15.360 0%
EXPORT_EVENTS                       782      23511                      2025/01/13 22:47:30  2025/01/13 22:49:49         137 +000000000 00:02:19.264 2%
EXPORT_INSURANCE_POLICIES           782      23511                      2025/01/13 22:49:50  2025/01/13 22:51:50         118 +000000000 00:01:59.808 2%
EXPORT_CL_DB_ACCOUNTS               782      23511                      2025/01/13 22:51:51  2025/01/13 22:54:36         162 +000000000 00:02:44.865 2%
EXPORT_RISK_EXPOSURE                782      23511                      2025/01/13 22:54:37  2025/01/13 23:25:43        1823 +000000000 00:31:06.752 25%
EXPORT_ALL_DWH_PART2                794      40212 db file parallel rea 2025/01/13 23:28:23  2025/01/13 23:28:23           1 +000000000 00:00:00.000 0%
EXPORT_ACCOUNTING_MOVEMENTS         794      40212                      2025/01/13 23:28:24  2025/01/13 23:30:40         134 +000000000 00:02:16.191 2%


MODULE                           SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
EXPORT_RISK_EXPOSURE             a9g6byjwbk72x 1113796382        782      23511                      2025/01/13 22:54:43  2025/01/13 23:04:54         598                    1 +000000000 00:10:11.328 33%
EXPORT_RISK_EXPOSURE             06gp1pv9xfa9r                   782      23511                      2025/01/13 23:04:55  2025/01/13 23:25:41         303                 3745 +000000000 00:20:46.209 17%
EXPORT_RISK_EXPOSURE             7r5jqc68xyg9q 2088163355        782      23511                      2025/01/13 23:08:34  2025/01/13 23:25:37         208                   54 +000000000 00:17:02.977 11%
EXPORT_RISK_EXPOSURE             2rd5gw5wgz1hm 1472377725        782      23511                      2025/01/13 23:06:25  2025/01/13 23:25:42         120                 3648 +000000000 00:19:17.120 7%
EXPORT_RISK_EXPOSURE             5zmp1taqfhdha 4190204471        782      23511                      2025/01/13 23:07:11  2025/01/13 23:25:07          95                 3450 +000000000 00:17:56.224 5%
EXPORT_RISK_EXPOSURE             8kt66uw1m9256 3897645497        782      23511                      2025/01/13 23:07:09  2025/01/13 23:24:48          84                  119 +000000000 00:17:38.816 5%


SQL_ID            ELAPSED MAX_WAIT_ON     PC_OF  WAIT_TIME            GETS      READS       ROWS  ELAP/EXEC       GETS/EXEC READS/EXEC  ROWS/EXEC       EXEC PLAN_HASH_VALUE
------------- ----------- --------------- ----- ---------- --------------- ---------- ---------- ---------- --------------- ---------- ---------- ---------- ---------------
2rd5gw5wgz1hm         134 CPU             76%   136.596423        46545719       4857       3654        .04           12738       1.33          1       3654      1472377725


SQL_ID        SQL_PLAN_HASH_VALUE SQL_PLAN_LINE_ID SQL_PLAN_OPERATION             SQL_PLAN_OPTIONS                   ACTIVE
------------- ------------------- ---------------- ------------------------------ ------------------------------ ----------
2rd5gw5wgz1hm          1472377725               21 TABLE ACCESS                   BY INDEX ROWID BATCHED                 97
2rd5gw5wgz1hm          1472377725                9 TABLE ACCESS                   BY INDEX ROWID BATCHED                 14
2rd5gw5wgz1hm          1472377725               22 INDEX                          RANGE SCAN                              6
2rd5gw5wgz1hm          1472377725               20 SORT                           UNIQUE                                  2
2rd5gw5wgz1hm          1472377725               12 INDEX                          RANGE SCAN                              1



Plan hash value: 1472377725
-------------------------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                  | Name                           | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  |
-------------------------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                           |                                |      1 |        |     9 (100)|      1 |00:00:10.19 |   12694 |  12011 |
|   1 |  SORT AGGREGATE                            |                                |      1 |      1 |            |      1 |00:00:10.19 |   12694 |  12011 |
|*  2 |   FILTER                                   |                                |      1 |        |            |      0 |00:00:10.19 |   12694 |  12011 |
|   3 |    NESTED LOOPS OUTER                      |                                |      1 |     11 |     5   (0)|      0 |00:00:00.02 |      17 |      4 |
|   4 |     NESTED LOOPS                           |                                |      1 |      5 |     4   (0)|      0 |00:00:00.02 |      17 |      4 |
|   5 |      NESTED LOOPS SEMI                     |                                |      1 |      2 |     3   (0)|      0 |00:00:00.02 |      17 |      4 |
|   6 |       NESTED LOOPS                         |                                |      1 |      2 |     2   (0)|      3 |00:00:00.01 |       4 |      0 |
|*  7 |        INDEX RANGE SCAN                    | G_DOSSIER_RL_CD_RD_RF_IDX      |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       2 |      0 |
|*  8 |        INDEX RANGE SCAN                    | G_DOSSIER_RL_CD_RD_RF_IDX      |      1 |      1 |     1   (0)|      3 |00:00:00.01 |       2 |      0 |
|*  9 |       TABLE ACCESS BY INDEX ROWID BATCHED  | G_PIECE                        |      3 |  20357 |     1   (0)|      0 |00:00:00.02 |      13 |      4 |
|* 10 |        INDEX RANGE SCAN                    | PIE_REFDOSS                    |      3 |      1 |     1   (0)|      2 |00:00:00.01 |      11 |      2 |
|  11 |      TABLE ACCESS BY INDEX ROWID BATCHED   | G_ELEMFI                       |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 12 |       INDEX RANGE SCAN                     | G_ELEMFI_DOS_TYP_FG02_CODE_IDX |      0 |     84 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|  13 |     TABLE ACCESS BY INDEX ROWID BATCHED    | F_DETFAC                       |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 14 |      INDEX RANGE SCAN                      | DETFAC_DOS                     |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|  15 |    NESTED LOOPS                            |                                |      1 |      1 |     4   (0)|      1 |00:00:10.17 |   12677 |  12007 |
|  16 |     NESTED LOOPS                           |                                |      1 |      1 |     3   (0)|     43 |00:00:10.17 |   12632 |  12007 |
|  17 |      MERGE JOIN CARTESIAN                  |                                |      1 |      1 |     2   (0)|     14 |00:00:10.15 |   12615 |  12005 |
|* 18 |       INDEX RANGE SCAN                     | G_DOSSIER_RL_CD_RD_RF_IDX      |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       2 |      0 |
|  19 |       BUFFER SORT                          |                                |      1 |      1 |     1   (0)|     14 |00:00:10.15 |   12613 |  12005 |
|  20 |        SORT UNIQUE                         |                                |      1 |      1 |     1   (0)|    294 |00:00:10.15 |   12613 |  12005 |
|* 21 |         TABLE ACCESS BY INDEX ROWID BATCHED| G_PIECE                        |      1 |      1 |     1   (0)|    517 |00:00:10.15 |   12613 |  12005 |
|* 22 |          INDEX RANGE SCAN                  | GP_TYPEDOC                     |      1 |     16 |     1   (0)|  20336 |00:00:01.16 |      84 |     83 |
|* 23 |      INDEX RANGE SCAN                      | INT_INDIV                      |     14 |      1 |     1   (0)|     43 |00:00:00.02 |      17 |      2 |
|* 24 |     INDEX RANGE SCAN                       | DOS_REFDOSS_REFLOT_IDX         |     43 |      1 |     1   (0)|      1 |00:00:00.01 |      45 |      0 |
-------------------------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   2 - filter( IS NOT NULL)
   7 - access("DCMP"."REFLOT"=:B1)
   8 - access("CMP"."REFLOT"="DCMP"."REFDOSS")
       filter("CMP"."REFLOT" IS NOT NULL)
   9 - filter("FACTURE"."MT01">0)
  10 - access("CMP"."REFDOSS"="FACTURE"."REFDOSS" AND "FACTURE"."TYPPIECE"='FACTURE')
  12 - access("WRITE_OFF"."REFDOSS"="CMP"."REFDOSS" AND "WRITE_OFF"."TYPE"='WRITE OFF')
  14 - access("ITEM"."DF_DOS"="DCMP"."REFDOSS" AND "ITEM"."DF_NOM"='WFIU')
  18 - access("DCMP"."REFLOT"=:B1)
  21 - filter(("DB_C_LIM"."GPIADR3" IS NOT NULL AND "DB_C_LIM"."GPIDATE6_DT"<"UTL_APP_DATE"."GETAPPDATE"()+1 AND
              NVL("DB_C_LIM"."GPIDTFIN_DT",TRUNC(SYSDATE@!+1))>"UTL_APP_DATE"."GETAPPDATE"() AND "DB_C_LIM"."MT02">0))
  22 - access("DB_C_LIM"."TYPEDOC"='C' AND "DB_C_LIM"."TYPPIECE"='REQUEST_LIMITE')
  23 - access("DB_C_LIM"."GPIADR3"="DB"."REFINDIVIDU" AND "DB"."REFTYPE"='DB')
  24 - access("DB"."REFDOSS"="CMP"."REFDOSS" AND "CMP"."REFLOT"="DCMP"."REFDOSS")
       filter("CMP"."REFLOT" IS NOT NULL)
*/
/********************************OLD Metrics***************************************/

/********************************New SQL*******************************************/

SELECT CASE WHEN :B2 = 'CL' 
            THEN SUM(ITEM.DF_MON) - ABS(SUM(WRITE_OFF.MONTANT)) 
            WHEN :B2 IN ('DB', 'DB_LEAD') 
            THEN SUM(WRITE_OFF.MONTANT) 
        END 
  FROM G_DOSSIER DCMP , 
       G_DOSSIER CMP , 
       F_DETFAC ITEM , 
       G_ELEMFI WRITE_OFF 
 WHERE DCMP.REFLOT = :B1 
   AND CMP.REFLOT = DCMP.REFDOSS 
   AND ITEM.DF_DOS (+)= DCMP.REFDOSS 
   AND ITEM.DF_NOM (+)= 'WFIU'
   AND WRITE_OFF.REFDOSS = CMP.REFDOSS 
   AND WRITE_OFF.TYPE = 'WRITE OFF'
   AND EXISTS ( SELECT 1 
                  FROM G_PIECE FACTURE 
                 WHERE CMP.REFDOSS = FACTURE.REFDOSS 
                   AND FACTURE.TYPPIECE = 'FACTURE' 
                   AND FACTURE.MT01 > 0 ) 
   AND EXISTS ( SELECT /*+ index(DB_C_LIM G_PIECE$ADR3) */
                       1 
                  FROM T_INTERVENANTS DB, 
                       G_PIECE DB_C_LIM 
                 WHERE DB.REFDOSS = CMP.REFDOSS 
                   AND DB.REFTYPE = 'DB' 
                   AND DB_C_LIM.TYPEDOC  = 'C'
                   AND DB_C_LIM.TYPPIECE = 'REQUEST_LIMITE'
                   AND DB_C_LIM.GPIADR3 = DB.REFINDIVIDU 
                   AND DB_C_LIM.GPIDATE6_DT < UTL_APP_DATE.GETAPPDATE + 1 
                   AND NVL(DB_C_LIM.GPIDTFIN_DT, TRUNC(SYSDATE + 1)) > UTL_APP_DATE.GETAPPDATE 
                   AND DB_C_LIM.MT02 > 0.0 ) ;
/********************************New SQL*******************************************/
/********************************New Metrics***************************************/
/*
Plan hash value: 3985772556
----------------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                  | Name                           | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers |
----------------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                           |                                |      1 |        |     8 (100)|      1 |00:00:00.01 |      36 |
|   1 |  SORT AGGREGATE                            |                                |      1 |      1 |            |      1 |00:00:00.01 |      36 |
|   2 |   VIEW                                     | VM_NWVW_2                      |      1 |      1 |     8  (13)|      0 |00:00:00.01 |      36 |
|   3 |    HASH UNIQUE                             |                                |      1 |      1 |     8  (13)|      0 |00:00:00.01 |      36 |
|   4 |     NESTED LOOPS SEMI                      |                                |      1 |      1 |     7   (0)|      0 |00:00:00.01 |      36 |
|   5 |      NESTED LOOPS                          |                                |      1 |      1 |     6   (0)|      0 |00:00:00.01 |      36 |
|   6 |       NESTED LOOPS OUTER                   |                                |      1 |      1 |     5   (0)|      2 |00:00:00.01 |      30 |
|   7 |        NESTED LOOPS                        |                                |      1 |      1 |     4   (0)|      2 |00:00:00.01 |      24 |
|   8 |         NESTED LOOPS                       |                                |      1 |      1 |     3   (0)|      3 |00:00:00.01 |       9 |
|   9 |          NESTED LOOPS                      |                                |      1 |      2 |     2   (0)|      3 |00:00:00.01 |       4 |
|* 10 |           INDEX RANGE SCAN                 | G_DOSSIER_RL_CD_RD_RF_IDX      |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       2 |
|* 11 |           INDEX RANGE SCAN                 | G_DOSSIER_RL_CD_RD_RF_IDX      |      1 |      1 |     1   (0)|      3 |00:00:00.01 |       2 |
|* 12 |          INDEX RANGE SCAN                  | INT_REFDOSS                    |      3 |      1 |     1   (0)|      3 |00:00:00.01 |       5 |
|* 13 |         TABLE ACCESS BY INDEX ROWID BATCHED| G_PIECE                        |      3 |      1 |     1   (0)|      2 |00:00:00.01 |      15 |
|* 14 |          INDEX RANGE SCAN                  | G_PIECE$ADR3                   |      3 |     30 |     1   (0)|     12 |00:00:00.01 |       5 |
|  15 |        TABLE ACCESS BY INDEX ROWID BATCHED | F_DETFAC                       |      2 |      2 |     1   (0)|      0 |00:00:00.01 |       6 |
|* 16 |         INDEX RANGE SCAN                   | DETFAC_DOS                     |      2 |      2 |     1   (0)|      0 |00:00:00.01 |       6 |
|  17 |       TABLE ACCESS BY INDEX ROWID BATCHED  | G_ELEMFI                       |      2 |      5 |     1   (0)|      0 |00:00:00.01 |       6 |
|* 18 |        INDEX RANGE SCAN                    | G_ELEMFI_DOS_TYP_FG02_CODE_IDX |      2 |     84 |     1   (0)|      0 |00:00:00.01 |       6 |
|* 19 |      TABLE ACCESS BY INDEX ROWID BATCHED   | G_PIECE                        |      0 |  20357 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 20 |       INDEX RANGE SCAN                     | PIE_REFDOSS                    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
----------------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
  10 - access("DCMP"."REFLOT"=:B1)
  11 - access("CMP"."REFLOT"="DCMP"."REFDOSS")
       filter("CMP"."REFLOT" IS NOT NULL)
  12 - access("DB"."REFDOSS"="CMP"."REFDOSS" AND "DB"."REFTYPE"='DB')
  13 - filter(("DB_C_LIM"."TYPPIECE"='REQUEST_LIMITE' AND "DB_C_LIM"."TYPEDOC"='C' AND
              "DB_C_LIM"."GPIDATE6_DT"<"UTL_APP_DATE"."GETAPPDATE"()+1 AND NVL("DB_C_LIM"."GPIDTFIN_DT",TRUNC(SYSDATE@!+1))>"UTL_APP_DATE"."GETAPPDATE"()
              AND "DB_C_LIM"."MT02">0))
  14 - access("DB_C_LIM"."GPIADR3"="DB"."REFINDIVIDU")
       filter("DB_C_LIM"."GPIADR3" IS NOT NULL)
  16 - access("ITEM"."DF_DOS"="DCMP"."REFDOSS" AND "ITEM"."DF_NOM"='WFIU')
  18 - access("WRITE_OFF"."REFDOSS"="CMP"."REFDOSS" AND "WRITE_OFF"."TYPE"='WRITE OFF')
  19 - filter("FACTURE"."MT01">0)
  20 - access("CMP"."REFDOSS"="FACTURE"."REFDOSS" AND "FACTURE"."TYPPIECE"='FACTURE')
*/
/********************************New Metrics***************************************/

/********************************Index statistics**********************************/

/********************************Other SQLs****************************************/          
/*

*/ 
/********************************Other SQLs****************************************/              
