sl06693:~ # ps -ef | grep [p]mon
oracle     302     1  0 Feb14 ?        00:19:51 ora_pmon_EDISCLKQ
oracle     791     1  0 Feb14 ?        00:21:55 ora_pmon_ARIPHSA
oracle    2093     1  0 Jun19 ?        00:00:51 ora_pmon_EDINETQ
oracle    8149     1  0 21:27 ?        00:00:00 ora_pmon_MFV2T
oracle   30450     1  0 Feb14 ?        00:21:58 ora_pmon_FDWH1T
sl06693:~ # dbspicao -pdvf
Checking instance: 'FDWH1T' @ '/oracle/11.2.0.4_FDWH1T':
        Connect:         OKAY
        Filter 4:        OKAY
        Filter 6:        OKAY

Checking instance: 'MFV2T' @ '/oracle/11.2.0.4_MFV2T':
2020-06-24T21:32:35 ERROR dbspicao(10) MFV2T [cola:ora_util.pc:411]: DBSPI10-23: Unable to connect to database 'MFV2T' [ORA-01033: ORACLE initialization or                                                    shutdown in progress]. See Instruction text or User's Guide for details.
        Connect:         FAILED

Checking instance: 'EDISCLKQ' @ '/oracle/11.2.0.4_EDISCLKQ':
        Connect:         OKAY
        Filter 4:        OKAY
        Filter 6:        OKAY

Checking instance: 'ARIPHSA' @ '/oracle/11.2.0.4_ARIPHSA':
        Connect:         OKAY
        Filter 4:        OKAY
        Filter 6:        OKAY

Checking instance: 'EDINETQ' @ '/oracle/11.2.0.3_EDINETQ':
        Connect:         OKAY
        Filter 4:        OKAY
        Filter 6:        OKAY

sl06693:~ # w
 21:32:56 up 131 days, 10:44,  6 users,  load average: 3.21, 2.89, 2.69
USER     TTY        LOGIN@   IDLE   JCPU   PCPU WHAT
dxnickd  pts/0     21:11    1:28   0.08s  0.01s sshd: dxnickd [priv]
dxmtyumr pts/1     21:12    6:00   0.04s  0.01s sshd: dxmtyumr [priv]
dxmtyumr pts/2     21:14    6:48   0.04s  0.01s sshd: dxmtyumr [priv]
dxcbella pts/3     21:21    5:52   0.05s  0.01s sshd: dxcbella [priv]
dxcbella pts/4     21:23    6:40   0.03s  0.00s sshd: dxcbella [priv]
dxcbella pts/5     21:32    0.00s  0.04s  0.01s sshd: dxcbella [priv]
sl06693:~ #
sl06693:~ #
sl06693:~ #
sl06693:~ #
sl06693:~ # df -h
Filesystem                                               Size  Used Avail Use% Mounted on
/dev/mapper/vg00-rootvol                                 7.2G  4.3G  2.6G  63% /
udev                                                      63G  2.0M   63G   1% /dev
tmpfs                                                    110G  8.1G  102G   8% /dev/shm
/dev/sdel1                                               510M   61M  424M  13% /boot
/dev/mapper/vg00-homevol                                 2.0G   13M  1.9G   1% /home
/dev/mapper/vg00-tmpvol                                  5.0G  1.3G  3.4G  28% /tmp
/dev/mapper/vg00-varvol                                  4.0G  1.4G  2.4G  37% /var
/dev/mapper/vg00-crashvol                                 26G  173M   25G   1% /var/crash
/dev/mapper/vg00-auditvol                                248M   11M  226M   5% /var/log/audit
/dev/mapper/vg00-optvol                                  3.0G  2.2G  699M  76% /opt
/dev/mapper/all_orabase-all_oracle                        99G   42G   57G  43% /oracle
/dev/mapper/all_orabase-all_export                       493G   29G  464G   6% /oracle/export
/dev/mapper/fdwh1t_oradata-fdwh1t_od                     493G  148G  346G  30% /oracle/FDWH1T/oradata
/dev/mapper/fdwh1t_oradata-fdwh1t_ra                     148G  510M  148G   1% /oracle/FDWH1T/recovery_area
/dev/mapper/mfv2t_oradata-mfv2t_od                       148G  5.2G  143G   4% /oracle/MFV2T/oradata
/dev/mapper/mfv2t_oradata-mfv2t_ra                        50G  494M   49G   1% /oracle/MFV2T/recovery_area
/dev/mapper/edisclkq_oradata-edisclkq_od                  60G   27G   30G  47% /oracle/EDISCLKQ/oradata
/dev/mapper/edisclkq_oradata-edisclkq_ra                  30G  184M   28G   1% /oracle/EDISCLKQ/recovery_area
/dev/mapper/ariphsa_oradata-ariphsa_oradata--ariphsa_od   50G   11G   39G  22% /oracle/ARIPHSA/oradata
/dev/mapper/ariphsa_oradata-ariphsa_oradata--ariphsa_ra  9.9G  465M  9.4G   5% /oracle/ARIPHSA/recovery_area
/dev/mapper/edinetq_oradata-edinetq_od                   552G  158G  394G  29% /oracle/EDINETQ/oradata
/dev/mapper/edinetq_oradata-edinetq_ra                    55G  1.7G   53G   4% /oracle/EDINETQ/recovery_area
sl06693:~ # cat /etc/oratab
#
#
FDWH1T:/oracle/11.2.0.4_FDWH1T:N
MFV2T:/oracle/11.2.0.4_MFV2T:N
MON1T:/oracle/11.2.0.4_MON1T:N
EDISCLKQ:/oracle/11.2.0.4_EDISCLKQ:N
ARIPHSA:/oracle/11.2.0.4_ARIPHSA:N
EDINETQ:/oracle/11.2.0.3_EDINETQ:N



###### pfile and spfile #####
sl06693:~ # cd /oracle/11.2.0.4_MFV2T/dbs
sl06693:/oracle/11.2.0.4_MFV2T/dbs # ls -la
total 13700
drwxr-xr-x  2 oracle oinstall     4096 Jun 24 21:27 .
drwxr-xr-x 77 oracle oinstall     4096 Sep  9  2016 ..
-rw-rw----  1 oracle oinstall     1544 Jun 24 21:27 hc_MFV2T.dat
-rw-r--r--  1 oracle oinstall     2851 May 15  2009 init.ora
-rw-r--r--  1 oracle oinstall     1350 Sep  9  2016 initMFV2T.ora      -----> pfile
-rw-r-----  1 oracle oinstall       24 Sep  9  2016 lkMFV2T
-rw-r-----  1 oracle oinstall     1536 Sep  9  2016 orapwMFV2T
-rw-r-----  1 oracle oinstall 13975552 Jun 24 20:15 snapcf_MFV2T.f
-rw-r-----  1 oracle oinstall     3584 Feb 14 10:13 spfileMFV2T.ora    ----->spfile

oracle@sl06693:/oracle/11.2.0.4_MFV2T/dbs> cat initMFV2T.ora
MFV2T.__db_cache_size=205520896
MFV2T.__java_pool_size=25165824
MFV2T.__large_pool_size=20971520
MFV2T.__oracle_base='/oracle'#ORACLE_BASE set from environment
MFV2T.__pga_aggregate_target=629145600
MFV2T.__sga_target=473956352
MFV2T.__shared_io_pool_size=0
MFV2T.__shared_pool_size=209715200
MFV2T.__streams_pool_size=0
*.aq_tm_processes=9
*.archive_lag_target=1800
*.audit_file_dest='/oracle/admin/MFV2T/adump'
*.audit_trail='DB'
*.backup_tape_io_slaves=TRUE
*.compatible='11.2.0.2.0'
*.control_files='/oracle/MFV2T/oradata/MFV2T/controlfile/o1_mf_cx5d86b4_.ctl','/oracle/MFV2T/recovery_area/MFV2T/controlfile/o1_mf_cx5d86cp_.ctl'
*.db_block_size=8192
*.db_create_file_dest='/oracle/MFV2T/oradata'
*.db_domain='WORLD'
*.db_name='MFV2T'
*.db_recovery_file_dest='/oracle/MFV2T/recovery_area'
*.db_recovery_file_dest_size=4194304000
*.diagnostic_dest='/oracle'
*.dispatchers='(PROTOCOL=TCP) (SERVICE=MFV2TXDB)'
*.filesystemio_options='setall'
*.java_pool_size=25165824
*.job_queue_processes=10
*.large_pool_size=20971520
*.local_listener='LISTENER_MFV2T_1530'
*.log_archive_dest_1='location=USE_DB_RECOVERY_FILE_DEST'
*.log_archive_format='MFV2T_%t_%s_%r.dbf'
*.memory_max_target=2621440000
*.memory_target=2097152000
*.open_cursors=300
*.processes=500
*.remote_login_passwordfile='EXCLUSIVE'
*.shared_pool_size=262144000
*.undo_tablespace='UNDOTBS1'

###############
############### string na spfile da sravnq parametrite
oracle@sl06693:/oracle/11.2.0.4_MFV2T/dbs> strings spfileMFV2T.ora
MFV2T.__db_cache_size=369098752
MFV2T.__java_pool_size=33554432
MFV2T.__large_pool_size=33554432
MFV2T.__oracle_base='/oracle'#ORACLE_BASE set from environment
MFV2T.__pga_aggregate_target=721420288
MFV2T.__sga_target=1375731712
MFV2T.__shared_io_pool_size=0
MFV2T.__shared_pool_size=872415232
MFV2T.__streams_pool_size=33554432
*.aq_tm_processes=9
*.archive_lag_target=1800
*.audit_file_dest='/oracle/admin/MFV2T/adump'
*.audit_trail='DB'
*.backup_tape_io_slaves=TRUE
*.compatible='11.2.
0.2.0'
*.control_files='/oracle/MFV2T/oradata/MFV2T/controlfile/o1_mf_cx5d86b4_.ctl','/oracle/MFV2T/recovery_area/MFV2T/controlfile/o1_mf_cx5d86cp_.ctl'
*.db_block_size=8192
*.db_create_file_dest='/oracle/MFV2T/oradata'
*.db_domain='WORLD'
*.db_name='MFV2T'
*.db_recovery_file_dest='/oracle/MFV2T/recovery_area'
*.db_recovery_file_dest_size=51539607552
*.diagnostic_dest='/oracle'
*.dispatchers='(PROTOCOL=TCP) (SERVICE=MFV2TXDB)'
*.filesystemio_options='setall'
*.java_pool_size=25165824
*.job_queue_processes=10
*.large_pool_size=20971520
*.local_listener='LISTENER_MFV2T_1530'
*.log_archive_dest_1='location=USE_DB_RECOVERY_FILE_DEST'
*.log_archive_format='MFV2T_%t_%s_%r.dbf'
*.memory_max_target=2621440000
*.memory_target=2097152000
*.open_cursors=300
*.processes=500
*.remote_login_passwordfile='EXCLUSIVE'
*.shared_pool_size=262144000
*.undo_tablespace='UNDOTBS1'

#######3#
##########
SQL> select * from v$instance;

INSTANCE_NUMBER INSTANCE_NAME
--------------- ----------------
HOST_NAME
----------------------------------------------------------------
VERSION           STARTUP_T STATUS       PAR    THREAD# ARCHIVE LOG_SWITCH_WAIT
----------------- --------- ------------ --- ---------- ------- ---------------
LOGINS     SHU DATABASE_STATUS   INSTANCE_ROLE      ACTIVE_ST BLO
---------- --- ----------------- ------------------ --------- ---
              1 MFV2T
sl06693
11.2.0.4.0        24-JUN-20 STARTED      NO           0 STOPPED
ALLOWED    NO  ACTIVE            UNKNOWN            NORMAL    NO


#############
############

SQL> select name, open_mode from v$database;
select name, open_mode from v$database
                            *
ERROR at line 1:
ORA-01507: database not mounted


##############
#############
SQL> show parameter name;

NAME                                 TYPE        VALUE
------------------------------------ ----------- ------------------------------
cell_offloadgroup_name               string
db_file_name_convert                 string
db_name                              string      MFV2T
db_unique_name                       string      MFV2T
global_names                         boolean     FALSE
instance_name                        string      MFV2T
lock_name_space                      string
log_file_name_convert                string
processor_group_name                 string
service_names                        string      MFV2T.WORLD
SQL>

################
###############
SQL> show parameter spfile;

NAME                                 TYPE        VALUE
------------------------------------ ----------- ------------------------------
spfile                               string      /oracle/11.2.0.4_MFV2T/dbs/spf
                                                 ileMFV2T.ora



##################
#################### Да видим къде се намират контролните файлове!!!

SQL> show parameter control;

NAME                                 TYPE        VALUE
------------------------------------ ----------- ------------------------------
control_file_record_keep_time        integer     7
control_files                        string      /oracle/MFV2T/oradata/MFV2T/co
                                                 ntrolfile/o1_mf_cx5d86b4_.ctl,
                                                  /oracle/MFV2T/recovery_area/M
                                                 FV2T/controlfile/o1_mf_cx5d86c
                                                 p_.ctl
control_management_pack_access       string      DIAGNOSTIC+TUNING


##############
############## Проверяваме дали ги има на OS ниво

sl06693:/oracle/11.2.0.4_MFV2T/dbs # cd /oracle/MFV2T/oradata/MFV2T/controlfile
sl06693:/oracle/MFV2T/oradata/MFV2T/controlfile # ls -la
total 13676
drwxr-x--- 2 oracle oinstall     4096 Sep  9  2016 .
drwxr-x--- 5 oracle oinstall     4096 Sep  9  2016 ..
-rw-r----- 1 oracle oinstall 13975552 Jun 24 20:57 o1_mf_cx5d86b4_.ctl
sl06693:/oracle/MFV2T/oradata/MFV2T/controlfile # ll o1_mf_cx5d86b4_.ctl
-rw-r----- 1 oracle oinstall 13975552 Jun 24 20:57 o1_mf_cx5d86b4_.ctl


sl06693:/oracle/MFV2T/oradata/MFV2T/controlfile # ll /oracle/MFV2T/recovery_area/MFV2T/controlfile/o1_mf_cx5d86cp_.ctl
-rw-r----- 1 oracle oinstall 13975552 Jun 24 20:57 /oracle/MFV2T/recovery_area/MFV2T/controlfile/o1_mf_cx5d86cp_.ctl



sl06693:/oracle/MFV2T/oradata/MFV2T/controlfile # cd /oracle/MFV2T/recovery_area/MFV2T/controlfile
-bash: cd: /oracle/MFV2T/recovery_area/MFV2T/controlfile: No such file or directory



Дали нещо го ползва .Мисля,че трябва да сме заредили oracle променливите
sl06693:/oracle/MFV2T/oradata/MFV2T/controlfile #
sl06693:/oracle/MFV2T/oradata/MFV2T/controlfile #
sl06693:/oracle/MFV2T/oradata/MFV2T/controlfile # fuser o1_mf_cx5d86b4_.ctl
sl06693:/oracle/MFV2T/oradata/MFV2T/controlfile #




###############
############### Да видим какви файлови са маунтнати 

oracle@sl06693:/oracle/home/oracle> mount
/dev/mapper/vg00-rootvol on / type ext3 (rw,acl,user_xattr)
proc on /proc type proc (rw)
sysfs on /sys type sysfs (rw)
debugfs on /sys/kernel/debug type debugfs (rw)
udev on /dev type tmpfs (rw,mode=0755)
tmpfs on /dev/shm type tmpfs (rw,size=111783M)
devpts on /dev/pts type devpts (rw,mode=0620,gid=5)
/dev/sdel1 on /boot type ext3 (rw,acl,user_xattr)
/dev/mapper/vg00-homevol on /home type ext3 (rw,acl,user_xattr)
/dev/mapper/vg00-tmpvol on /tmp type ext3 (rw,acl,user_xattr)
/dev/mapper/vg00-varvol on /var type ext3 (rw,acl,user_xattr)
/dev/mapper/vg00-crashvol on /var/crash type ext3 (rw,acl,user_xattr)
/dev/mapper/vg00-auditvol on /var/log/audit type ext3 (rw,acl,user_xattr)
/dev/mapper/vg00-optvol on /opt type ext3 (rw,acl,user_xattr)
/dev/mapper/all_orabase-all_oracle on /oracle type ext3 (rw,acl,user_xattr)
/dev/mapper/all_orabase-all_export on /oracle/export type ext3 (rw,acl,user_xattr)
/dev/mapper/fdwh1t_oradata-fdwh1t_od on /oracle/FDWH1T/oradata type ext3 (rw,acl,user_xattr)
/dev/mapper/fdwh1t_oradata-fdwh1t_ra on /oracle/FDWH1T/recovery_area type ext3 (rw,acl,user_xattr)
/dev/mapper/mfv2t_oradata-mfv2t_od on /oracle/MFV2T/oradata type ext3 (rw,acl,user_xattr)
/dev/mapper/edisclkq_oradata-edisclkq_od on /oracle/EDISCLKQ/oradata type ext3 (rw)
/dev/mapper/edisclkq_oradata-edisclkq_ra on /oracle/EDISCLKQ/recovery_area type ext3 (rw)
/dev/mapper/ariphsa_oradata-ariphsa_oradata--ariphsa_od on /oracle/ARIPHSA/oradata type ext3 (rw,acl,user_xattr)
/dev/mapper/ariphsa_oradata-ariphsa_oradata--ariphsa_ra on /oracle/ARIPHSA/recovery_area type ext3 (rw,acl,user_xattr)
/dev/mapper/edinetq_oradata-edinetq_od on /oracle/EDINETQ/oradata type ext3 (rw,acl,user_xattr)
/dev/mapper/edinetq_oradata-edinetq_ra on /oracle/EDINETQ/recovery_area type ext3 (rw,acl,user_xattr)
none on /proc/sys/fs/binfmt_misc type binfmt_misc (rw)



#####################
##################### Проверявам този пат с какви пърмишъни е 

oracle@sl06693:/oracle/home/oracle> cd /oracle/MFV2T/oradata/MFV2T/controlfile
oracle@sl06693:/oracle/MFV2T/oradata/MFV2T/controlfile>
oracle@sl06693:/oracle/MFV2T/oradata/MFV2T/controlfile>
oracle@sl06693:/oracle/MFV2T/oradata/MFV2T/controlfile>
oracle@sl06693:/oracle/MFV2T/oradata/MFV2T/controlfile>
oracle@sl06693:/oracle/MFV2T/oradata/MFV2T/controlfile> df -h .
Filesystem                          Size  Used Avail Use% Mounted on
/dev/mapper/mfv2t_oradata-mfv2t_od  148G  5.2G  143G   4% /oracle/MFV2T/oradata
oracle@sl06693:/oracle/MFV2T/oradata/MFV2T/controlfile>
oracle@sl06693:/oracle/MFV2T/oradata/MFV2T/controlfile> mount | grep /dev/mapper/mfv2t_oradata-mfv2t_od
/dev/mapper/mfv2t_oradata-mfv2t_od on /oracle/MFV2T/oradata type ext3 (rw,acl,user_xattr)


#####################
##################### Проблем няма нищо вътре !!!!!!!!!
oracle@sl06693:/oracle/MFV2T/oradata/MFV2T/controlfile> cd /oracle/MFV2T/recovery_area/MFV2T/controlfile
-ksh: cd: /oracle/MFV2T/recovery_area/MFV2T/controlfile: [No such file or directory]
oracle@sl06693:/oracle/MFV2T/oradata/MFV2T/controlfile>
oracle@sl06693:/oracle/MFV2T/oradata/MFV2T/controlfile>
oracle@sl06693:/oracle/MFV2T/oradata/MFV2T/controlfile> cd /oracle/MFV2T/recovery_area
oracle@sl06693:/oracle/MFV2T/recovery_area>
oracle@sl06693:/oracle/MFV2T/recovery_area>
oracle@sl06693:/oracle/MFV2T/recovery_area>
oracle@sl06693:/oracle/MFV2T/recovery_area> ls -la
total 8
drwxr-xr-x 2 root   root     4096 Jun 24 22:00 .
drwxr-xr-x 4 oracle oinstall 4096 Aug 24  2016 ..
oracle@sl06693:/oracle/MFV2T/recovery_area>
oracle@sl06693:/oracle/MFV2T/recovery_area>
oracle@sl06693:/oracle/MFV2T/recovery_area>
oracle@sl06693:/oracle/MFV2T/recovery_area> sqlplus / as sysdba


SQL>
SQL> show parameter recovery;

NAME                                 TYPE        VALUE
------------------------------------ ----------- ------------------------------
db_recovery_file_dest                string      /oracle/MFV2T/recovery_area
db_recovery_file_dest_size           big integer 48G
recovery_parallelism                 integer     0
SQL>
SQL>
SQL>




oracle@sl06693:/oracle/MFV2T/recovery_area> ls -la
total 8
drwxr-xr-x 2 root   root     4096 Jun 24 22:00 .
drwxr-xr-x 4 oracle oinstall 4096 Aug 24  2016 ..
oracle@sl06693:/oracle/MFV2T/recovery_area>
oracle@sl06693:/oracle/MFV2T/recovery_area> df -h .
Filesystem                          Size  Used Avail Use% Mounted on
/dev/mapper/all_orabase-all_oracle   99G   42G   57G  43% /oracle
oracle@sl06693:/oracle/MFV2T/recovery_area>
oracle@sl06693:/oracle/MFV2T/recovery_area>
oracle@sl06693:/oracle/MFV2T/recovery_area> mount | grep /dev/mapper/all_orabase-all_oracle
/dev/mapper/all_orabase-all_oracle on /oracle type ext3 (rw,acl,user_xattr)


###################
################### Гледам кой е бил на сървъра и какво е правил
wtmp begins Sat Feb  2 19:43:59 2019
oracle@sl06693:/oracle/MFV2T/recovery_area> last -50
dxcbella pts/5        eonssh01.emea.om Wed Jun 24 21:32   still logged in
hpvaerm  pts/5        eonssh01.emea.om Wed Jun 24 21:25 - 21:26  (00:00)
dxcbella pts/4        eonssh01.emea.om Wed Jun 24 21:23   still logged in
dxcbella pts/3        eonssh01.emea.om Wed Jun 24 21:21   still logged in
dxmtyumr pts/2        eonssh01.emea.om Wed Jun 24 21:14 - 22:09  (00:54)
dxmtyumr pts/1        eonssh01.emea.om Wed Jun 24 21:12   still logged in
dxnickd  pts/0        eonssh01.emea.om Wed Jun 24 21:11   still logged in
dxeidimv pts/1        eonssh01.emea.om Wed Jun 24 15:01 - 15:17  (00:15)
dxeidimv pts/1        eonssh01.emea.om Wed Jun 24 14:42 - 14:44  (00:01)
hpvelich pts/0        eonssh01.emea.om Wed Jun 24 14:42 - 16:57  (02:15)


wtmp begins Sat Feb  2 19:43:59 2019
oracle@sl06693:/oracle/MFV2T/recovery_area> cat /etc/passwd | grep dxeidimv
dxeidimv:x:8437933:45005:Evgeni Dimitrov,,personal,edimitrov4@dxc.com:/home/ERMsupport/dxeidimv:/bin/bash





oracle@sl06693:/oracle/MFV2T/oradata/MFV2T/controlfile> history | grep rm
1040    history | grep rm
oracle@sl06693:/oracle/MFV2T/oradata/MFV2T/controlfile>


sl06693:/oracle/MFV2T/oradata/MFV2T/controlfile # history | grep rm
   24  2020-06-24 22:24:22 history | grep rm
sl06693:/oracle/MFV2T/oradata/MFV2T/controlfile # cd ~
sl06693:~ #
sl06693:~ #

sl06693:~ # ls -lart
total 75208

-rw-------  1 root root      637 Feb 14 09:37 .sh_history.dxeidimv.202002140915
-rw-------  1 root root      294 Feb 14 10:19 .sh_history.dxeidimv.202002140957
-rw-------  1 root root      161 Feb 14 10:21 .sh_history.dxcbella.202002141008
-rw-------  1 root root       89 Feb 14 18:22 .sh_history.dxbvbov.202002141751
-rw-------  1 root root       59 Feb 14 20:47 .sh_history.dxbvbov.202002142008
-rw-------  1 root root      155 Apr 16 22:01 .sh_history.hpevgeny.202004162156
-rw-------  1 root root      526 May  2 10:03 .sh_history.hpvaerm.202005021000
-rw-------  1 root root       27 Jun 10 14:26 .sh_history.hpvelich.202006101359
-rw-------  1 root root      256 Jun 10 14:51 .sh_history.hpplasv.202006101410
-rw-------  1 root root    38462 Jun 11 08:21 .bash_history
drwxr-xr-x 29 root root    16384 Jun 24 01:01 ..
-rw-------  1 root root       57 Jun 24 14:13 .sh_history.hpplasv.202006241347
-rw-------  1 root root      129 Jun 24 14:44 .sh_history.dxeidimv.202006241442
-rwxr-xr-x  1 root root      565 Jun 24 15:16 eject.sh
-rw-------  1 root root     2688 Jun 24 15:17 .sh_history.dxeidimv.202006241501
-rw-------  1 root root       62 Jun 24 16:57 .sh_history.hpvelich.202006241442
-rw-------  1 root root    16577 Jun 24 21:26 .viminfo
-rw-------  1 root root      754 Jun 24 21:26 .sh_history.hpvaerm.202006242125
-rw-------  1 root root      370 Jun 24 21:56 .sh_history.dxmtyumr.202006242115
drwxr-xr-x 19 root root    20480 Jun 24 21:56 .

########
#######3 Cat-vam history-tata koito iskam da vidq
sl06693:~ # cat .sh_history.hpvelich.202006241442
#1593002543
export TMOUT=0
#1593002557
df -Ph | grep -i Mon1T
sl06693:~ #
sl06693:~ #
sl06693:~ #
sl06693:~ #
sl06693:~ # cat .sh_history.dxeidimv.202006241442
#1593002567
df -h
#1593002594
lsof +f -- /oracle/MON1T/oradata/oracle/MON1T/oradata
#1593002611
lsof +f -- /oracle/MON1T/oradata



###################
################### Да видя хисторито на oracle user-a
sl06693:~ # su - oracle
oracle@sl06693:/oracle/home/oracle> ls -la | grep history
-rw------- 1 oracle oinstall     0 Aug 24  2016 .bash_history
-rw------- 1 oracle oinstall 22076 Jun 24 22:27 .kshrc_history
oracle@sl06693:/oracle/home/oracle>
oracle@sl06693:/oracle/home/oracle>
oracle@sl06693:/oracle/home/oracle>
oracle@sl06693:/oracle/home/oracle>
oracle@sl06693:/oracle/home/oracle> cat .bash_history
oracle@sl06693:/oracle/home/oracle>
oracle@sl06693:/oracle/home/oracle>
oracle@sl06693:/oracle/home/oracle> cat .kshrc_history



oracle@sl06693:/oracle/home/oracle> cat .kshrc_history | grep rm
Binary file (standard input) matches
oracle@sl06693:/oracle/home/oracle>




oracle@sl06693:/oracle/MFV2T/recovery_area> cd $ORACLE_HOME/dbs
oracle@sl06693:/oracle/11.2.0.4_MFV2T/dbs>

oracle@sl06693:/oracle/11.2.0.4_MFV2T/dbs>
oracle@sl06693:/oracle/11.2.0.4_MFV2T/dbs> ls -la
total 13700
drwxr-xr-x  2 oracle oinstall     4096 Jun 24 21:48 .
drwxr-xr-x 77 oracle oinstall     4096 Sep  9  2016 ..
-rw-rw----  1 oracle oinstall     1544 Jun 24 21:48 hc_MFV2T.dat
-rw-r--r--  1 oracle oinstall     1350 Sep  9  2016 initMFV2T.ora
-rw-r--r--  1 oracle oinstall     2851 May 15  2009 init.ora
-rw-r-----  1 oracle oinstall       24 Sep  9  2016 lkMFV2T
-rw-r-----  1 oracle oinstall     1536 Sep  9  2016 orapwMFV2T
-rw-r-----  1 oracle oinstall 13975552 Jun 24 20:15 snapcf_MFV2T.f
-rw-r-----  1 oracle oinstall     3584 Feb 14 10:13 spfileMFV2T.ora



############################
############################ Create pfile from spfile 

DATABASE         HOSTED_ON                      STATUS LOGINS  DATABASE_STARTED       CURRENT_TIME           UPTIME
---------------- ------------------------------ ------ ------- ---------------------- ---------------------- ------------------------
MFV2T            sl06693                        STARTE ALLOWED JUN/24/2020 21:48:29   JUN/24/2020 22:06:17   0d / 0h / 49m / 47s
                                                D


SQL> create pfile='missing_control.ora' from spfile;

File created.


SQL> shu immediate;
ORA-01507: database not mounted


ORACLE instance shut down.
SQL>

oracle@sl06693:/oracle/11.2.0.4_MFV2T/dbs> ls -la
total 13704
drwxr-xr-x  2 oracle oinstall     4096 Jun 24 22:39 .
drwxr-xr-x 77 oracle oinstall     4096 Sep  9  2016 ..
-rw-rw----  1 oracle oinstall     1544 Jun 24 22:38 hc_MFV2T.dat
-rw-r--r--  1 oracle oinstall     1350 Sep  9  2016 initMFV2T.ora
-rw-r--r--  1 oracle oinstall     2851 May 15  2009 init.ora
-rw-r-----  1 oracle oinstall       24 Sep  9  2016 lkMFV2T
-rw-r--r--  1 oracle oinstall     1359 Jun 24 22:37 missing_control.ora   ----> параметър файла който създадохме
-rw-r-----  1 oracle oinstall     1536 Sep  9  2016 orapwMFV2T
-rw-r-----  1 oracle oinstall 13975552 Jun 24 20:15 snapcf_MFV2T.f
-rw-r-----  1 oracle oinstall     3584 Feb 14 10:13 spfileMFV2T.ora

###########
########### Редактирам го като премахвам единия контролен файл,който липсва да не го търси и след което създавам spfile По този pfile
oracle@sl06693:/oracle/11.2.0.4_MFV2T/dbs> vi missing_control.ora
oracle@sl06693:/oracle/11.2.0.4_MFV2T/dbs>

#################
################## backup na spfile-a
oracle@sl06693:/oracle/11.2.0.4_MFV2T/dbs> mv spfileMFV2T.ora spfileMFV2T.ora.bkp   ------> правя бекъп на psfile-a
oracle@sl06693:/oracle/11.2.0.4_MFV2T/dbs>


##############
############## Криейтвам spfile от pfile-a новия
SQL> create spfile from pfile='missing_control.ora';

File created.

SQL>
SQL>
SQL> startup;
ORACLE instance started.

Total System Global Area 2622255104 bytes
Fixed Size                  2256112 bytes
Variable Size            2231370512 bytes
Database Buffers          369098752 bytes
Redo Buffers               19529728 bytes
Database mounted.
Database opened.


####################
##################### Пробвам да суитчна лог и не става
SQL> alter system archive log current;
alter system archive log current
*
ERROR at line 1:
ORA-16014: log 3 sequence# 69201 not archived, no available destinations
ORA-00312: online log 3 thread 1:
'/oracle/MFV2T/oradata/MFV2T/onlinelog/o1_mf_3_cx5d88nl_.log'
ORA-00312: online log 3 thread 1:
'/oracle/MFV2T/recovery_area/MFV2T/onlinelog/o1_mf_3_cx5d8970_.log'


SQL> show parameter reco

NAME                                 TYPE        VALUE
------------------------------------ ----------- ------------------------------
control_file_record_keep_time        integer     7
db_recovery_file_dest                string      /oracle/MFV2T/recovery_area
db_recovery_file_dest_size           big integer 48G
db_unrecoverable_scn_tracking        boolean     TRUE
recovery_parallelism                 integer     0
SQL>
SQL>
SQL> alter system set db_recovery_file_dest='/oracle/MFV2T/recovery_area' scope=both;

System altered.

SQL>
SQL>
SQL> alter system archive log current;
alter system archive log current
*
ERROR at line 1:
ORA-16014: log 3 sequence# 69201 not archived, no available destinations
ORA-00312: online log 3 thread 1:
'/oracle/MFV2T/oradata/MFV2T/onlinelog/o1_mf_3_cx5d88nl_.log'
ORA-00312: online log 3 thread 1:
'/oracle/MFV2T/recovery_area/MFV2T/onlinelog/o1_mf_3_cx5d8970_.log'


SQL> shu immediate;

oracle@sl06693:/oracle/11.2.0.4_MFV2T/dbs> cd /oracle/MFV2T/recovery_area/
oracle@sl06693:/oracle/MFV2T/recovery_area> ls -la
total 8
drwxr-xr-x 2 root   root     4096 Jun 24 22:00 .
drwxr-xr-x 4 oracle oinstall 4096 Aug 24  2016 ..
oracle@sl06693:/oracle/MFV2T/recovery_area> mkdir MFV2T
mkdir: cannot create directory `MFV2T': Permission denied  ----------------->  Опа ето го проблема оунършипа е root:root
oracle@sl06693:/oracle/MFV2T/recovery_area> cd ..
oracle@sl06693:/oracle/MFV2T> ll
total 8
drwxr-xr-x 4 oracle oinstall 4096 Oct 20  2016 oradata
drwxr-xr-x 2 root   root     4096 Jun 24 22:00 recovery_area
oracle@sl06693:/oracle/MFV2T> cd ..
oracle@sl06693:/oracle> ll
total 108
drwxr-xr-x  2 oracle   oinstall  4096 Aug 26  2016 11.0.2.5
drwxr-xr-x 75 oracle   oinstall  4096 Aug 28  2017 11.2.0.3_EDINETQ
drwxr-xr-x 77 oracle   oinstall  4096 May 30  2017 11.2.0.4_ARIPHSA
drwxr-xr-x 79 oracle   oinstall  4096 Jan 23  2017 11.2.0.4_EDISCLKQ
drwxr-xr-x 77 oracle   oinstall  4096 Aug 26  2016 11.2.0.4_FDWH1T
drwxr-xr-x 77 oracle   oinstall  4096 Sep  9  2016 11.2.0.4_MFV2T
drwxr-xr-x 77 oracle   oinstall  4096 Dec  7  2016 11.2.0.4_MON1T
drwxr-xr-x  8 oracle   oinstall  4096 Aug 28  2017 admin
drwxr-xr-x  4 oracle   oinstall  4096 May 30  2017 ARIPHSA
drwxr-x---  7 oracle   oinstall  4096 Jan 23  2017 cfgtoollogs
drwxr-xr-x  2 oracle   oinstall  4096 Aug 28  2017 checkpoints
drwxrwxr-x 11 oracle   oinstall  4096 Aug 26  2016 diag
drwxr-xr-x  4 oracle   oinstall  4096 Aug 25  2017 EDINETQ
drwxr-xr-x  4 oracle   oinstall  4096 Jan 16  2017 EDISCLKQ
drwxrwxrwx  9 oracle   oinstall  4096 Feb 14 10:13 export
lrwxrwxrwx  1 fdwhproc staff       14 Sep  9  2016 FDWH -> /oracle/FDWH1T
drwxrwxrwx  6 oracle   oinstall  4096 Sep  9  2016 FDWH1T
drwxrwxrwx  4 oracle   oinstall  4096 Sep  7  2016 FDWH_backup
drwxr-xr-x  3 oracle   oinstall  4096 Aug 24  2016 home
drwxr-xr-x  3 oracle   oinstall  4096 Jan 17  2017 install
drwx------  2 oracle   oinstall 16384 Aug 24  2016 lost+found
drwxr-xr-x  4 oracle   oinstall  4096 Aug 24  2016 MFV2T
drwxr-xr-x  4 oracle   oinstall  4096 Aug 24  2016 MON1T
drwxrwx---  6 oracle   oinstall  4096 Aug 28  2017 oraInventory
drwxrwxr-x  5 oracle   oinstall  4096 Aug 28  2017 sw



###############
############## Гася базата ,и пиша мейл Има файлова,която Unix-ите не могат да маунтнат и трябва рибуут

SQL> shu immediate;
Database closed.
Database dismounted.
ORACLE instance shut down.



oracle@sl06693:/oracle/MFV2T>
oracle@sl06693:/oracle/MFV2T> ll /oracle/MFV2T/recovery_area/MFV2T/controlfile/o1_mf_cx5d86cp_.ctl
/bin/ls: cannot access /oracle/MFV2T/recovery_area/MFV2T/controlfile/o1_mf_cx5d86cp_.ctl: No such file or directory
oracle@sl06693:/oracle/MFV2T>
oracle@sl06693:/oracle/MFV2T>

oracle@sl06693:/oracle/MFV2T>
oracle@sl06693:/oracle/MFV2T>
oracle@sl06693:/oracle/MFV2T> mount
/dev/mapper/vg00-rootvol on / type ext3 (rw,acl,user_xattr)
proc on /proc type proc (rw)
sysfs on /sys type sysfs (rw)
debugfs on /sys/kernel/debug type debugfs (rw)
udev on /dev type tmpfs (rw,mode=0755)
tmpfs on /dev/shm type tmpfs (rw,size=111783M)
devpts on /dev/pts type devpts (rw,mode=0620,gid=5)
/dev/sdel1 on /boot type ext3 (rw,acl,user_xattr)
/dev/mapper/vg00-homevol on /home type ext3 (rw,acl,user_xattr)
/dev/mapper/vg00-tmpvol on /tmp type ext3 (rw,acl,user_xattr)
/dev/mapper/vg00-varvol on /var type ext3 (rw,acl,user_xattr)
/dev/mapper/vg00-crashvol on /var/crash type ext3 (rw,acl,user_xattr)
/dev/mapper/vg00-auditvol on /var/log/audit type ext3 (rw,acl,user_xattr)
/dev/mapper/vg00-optvol on /opt type ext3 (rw,acl,user_xattr)
/dev/mapper/all_orabase-all_oracle on /oracle type ext3 (rw,acl,user_xattr)
/dev/mapper/all_orabase-all_export on /oracle/export type ext3 (rw,acl,user_xattr)
/dev/mapper/fdwh1t_oradata-fdwh1t_od on /oracle/FDWH1T/oradata type ext3 (rw,acl,user_xattr)
/dev/mapper/fdwh1t_oradata-fdwh1t_ra on /oracle/FDWH1T/recovery_area type ext3 (rw,acl,user_xattr)
/dev/mapper/mfv2t_oradata-mfv2t_od on /oracle/MFV2T/oradata type ext3 (rw,acl,user_xattr)
/dev/mapper/edisclkq_oradata-edisclkq_od on /oracle/EDISCLKQ/oradata type ext3 (rw)
/dev/mapper/edisclkq_oradata-edisclkq_ra on /oracle/EDISCLKQ/recovery_area type ext3 (rw)
/dev/mapper/ariphsa_oradata-ariphsa_oradata--ariphsa_od on /oracle/ARIPHSA/oradata type ext3 (rw,acl,user_xattr)
/dev/mapper/ariphsa_oradata-ariphsa_oradata--ariphsa_ra on /oracle/ARIPHSA/recovery_area type ext3 (rw,acl,user_xattr)
/dev/mapper/edinetq_oradata-edinetq_od on /oracle/EDINETQ/oradata type ext3 (rw,acl,user_xattr)
/dev/mapper/edinetq_oradata-edinetq_ra on /oracle/EDINETQ/recovery_area type ext3 (rw,acl,user_xattr)
none on /proc/sys/fs/binfmt_misc type binfmt_misc (rw)
oracle@sl06693:/oracle/MFV2T>
oracle@sl06693:/oracle/MFV2T>
oracle@sl06693:/oracle/MFV2T>
oracle@sl06693:/oracle/MFV2T>
oracle@sl06693:/oracle/MFV2T> mount | grep /oracle/MFV2T/recovery_area/
oracle@sl06693:/oracle/MFV2T>

