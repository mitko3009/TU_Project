/********************************************************************************
*********       E-mail subject: UDC-25359
*********             Instance: CADRE-S
*********          Description: 
Problem:
SQL 01gkfscnmfmhm was considered as slow on UNEDIC CADRE-S.

Analysis:
From the analyze, we found that SQL 01gkfscnmfmhm with top_level_sql 85fg10p7zcazd was using bad execution plan, which make 
a lot of buffer gets and takes unacceptable long time. The main problem in this SQL is that table F_PARENR is not used and it is not joined, which 
leads to scanning a lot of data unnecessarily. The other problem is that the tables are not accessed in the best order from performance point of view, so 
we added a hint to specify the correct order of accessing the tables. Also, we added aliases to the columns where they were missing, because it is difficult to read 
the query without them.

Suggestion:
Please modify the query as it is shown in the New SQL section below.

*********               SQL_ID: 01gkfscnmfmhm
*********      Program/Package: unedic_inc2072289
*********              Request: Dimitare Ivanov
*********               Author: Dimitar Dimitrov
********* Received e-mail date: 01/03/2024
*********      Resolution date: 01/03/2023
*********  Trace old file here: \\epox\specifs\performance\tmp\
*********  Trace new file here:
***********************************************************************************/

/********************************OLD SQL*******************************************/

var B3 number;
exec :B3 := 1;
var B2 varchar2(32);
exec :B2 := '1311202203';
var B1 varchar2(32);
exec :B1 := '1311203233';

SELECT SUM ( NVL( DECODE( GPIDEVIS, 'FRF', 1/6.55957 , 1 ) * DE_PAYE_MVT, 0 ) ) 
  FROM G_PIECE G, 
       F_ENTENR F, 
       F_DETENR D, 
       F_PARENR P 
 WHERE TYPPIECE = 'AVANCE' 
   AND G.REFPIECE = F.EE_REF 
   AND G.PAGE = :B3 
   AND F.EE_DOS = 'GLOBAL' 
   AND F.EE_FINMODE = 'D' 
   AND F.EE_MAITRE||'' = 'PMT' 
   AND G.REFDOSS = :B2 
   AND DE_MAITRE = F.EE_NUM 
   AND DE_DOS = :B1 
   AND SUBSTR( DE_NOM , 1, 1 ) = 'A';
/********************************OLD SQL*******************************************/
/********************************OLD Metrics***************************************/
/*

MODULE                           SQL_ID                PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- -------------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
SQL Developer                                                           796      10408                      2024/02/29 15:11:23  2024/02/29 15:50:46         213               153491 +000000000 00:39:22.887 26%
SQL Developer                                                           827      51515                      2024/02/29 13:44:28  2024/02/29 15:08:03         187               152757 +000000000 01:23:35.235 23%
SQL Developer                    7zjhsgjfkd5rq        1024781755         59      15983                      2024/02/29 13:58:48  2024/02/29 14:28:30         179                    1 +000000000 00:29:42.024 22%

MODULE                           SQL_ID                PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- -------------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
SQL Developer                    7zjhsgjfkd5rq        1024781755         59      15983                      2024/02/29 13:58:48  2024/02/29 14:28:30         179                    1 +000000000 00:29:42.024 30%
SQL Developer                    01gkfscnmfmhm         317934794        796      10408 ON CPU               2024/02/29 15:21:24  2024/02/29 15:50:46         175                  653 +000000000 00:29:22.325 29%

MODULE                           SQL_ID                PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- -------------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
SQL Developer                                                           796      10408                      2024/02/29 15:11:23  2024/02/29 15:50:46         213               153491 +000000000 00:39:22.887 100%

MODULE                           SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
SQL Developer                                                    796      10408 ON CPU               2024/02/29 15:11:53  2024/02/29 15:50:46         182               153491 +000000000 00:38:52.864 85%
SQL Developer                                                    796      10408 db file sequential r 2024/02/29 15:11:23  2024/02/29 15:21:14          31                    2 +000000000 00:09:50.555 15%

MODULE                           SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
SQL Developer                    01gkfscnmfmhm  317934794        796      10408 ON CPU               2024/02/29 15:21:24  2024/02/29 15:50:46         175                  653 +000000000 00:29:22.325 82%
SQL Developer                    5htmttbkacysp 1166261430        796      10408                      2024/02/29 15:19:03  2024/02/29 15:21:14          14                    1 +000000000 00:02:10.128 7%
SQL Developer                    7847cpftgswmd 1166261430        796      10408                      2024/02/29 15:15:13  2024/02/29 15:17:23          14                    1 +000000000 00:02:10.099 7%
SQL Developer                    bxtptv3fztng2  946989678        796      10408                      2024/02/29 15:11:23  2024/02/29 15:12:33           8                    1 +000000000 00:01:10.058 4%
SQL Developer                    fc11k0hwx77cd 1593630923        796      10408 ON CPU               2024/02/29 15:33:04  2024/02/29 15:37:25           2                   95 +000000000 00:04:20.369 1%

INSTANCE_NUMBER SQL_ID            ELAPSED MAX_WAIT_ON     PC_OF  WAIT_TIME            GETS      READS       ROWS  ELAP/EXEC       GETS/EXEC READS/EXEC  ROWS/EXEC       EXEC PLAN_HASH_VALUE PERIOD
--------------- ------------- ----------- --------------- ----- ---------- --------------- ---------- ---------- ---------- --------------- ---------- ---------- ---------- --------------- ---------------
              1 01gkfscnmfmhm           1 CPU             81%     1.418046          219554        743         90        .02            2439       8.26          1         90       317934794 2024/02/07 10
              1 01gkfscnmfmhm          47 CPU             100%   45.106716         9776145         21        191        .25           51184        .11          1        191       317934794 2024/02/07 11
              1 01gkfscnmfmhm           3 CPU             100%    3.343553          767284         12         34         .1           22567        .35          1         34       317934794 2024/02/07 15
              1 01gkfscnmfmhm           1 CPU             99%     1.164202          385974         13         82        .01            4707        .16          1         82       317934794 2024/02/07 16
              1 01gkfscnmfmhm           3 CPU             100%    2.903304          971030         15        116        .03            8371        .13          1        116       317934794 2024/02/08 09
              1 01gkfscnmfmhm           1 CPU             100%    1.307602          459864          0         54        .03            8516          0          1         54       317934794 2024/02/08 10
              1 01gkfscnmfmhm          12 CPU             100%   11.805118         2775261          7        157        .08           17677        .04          1        157       317934794 2024/02/08 11
              1 01gkfscnmfmhm          14 CPU             100%   13.424711         3275420         16        216        .06           15164        .07          1        216       317934794 2024/02/09 09
              1 01gkfscnmfmhm           3 CPU             100%    2.981245         1377276          0      68474          0              20          0          1      68474       317934794 2024/02/16 17
              1 01gkfscnmfmhm          14 CPU             100%   13.593323         3505514         49        428        .03            8190        .11          1        428       317934794 2024/02/20 16
              1 01gkfscnmfmhm           2 CPU             98%     1.441824          397631         44         87        .02            4570        .51          1         87       317934794 2024/02/26 13
              1 01gkfscnmfmhm           4 CPU             99%     3.630015          850048         42         71        .05           11973        .59          1         71       317934794 2024/02/26 17
              1 01gkfscnmfmhm           2 CPU             100%    2.268341          817378          0         94        .02            8696          0          1         94       317934794 2024/02/29 11
              1 01gkfscnmfmhm         121 CPU             99%   115.980799        24765741       1450      46510          0             532        .03          1      46510       317934794 2024/02/29 14
              1 01gkfscnmfmhm        1928 CPU             100%  1889.52389       373263086        144        908       2.12          410179        .16          1        910       317934794 2024/02/29 15
              1 01gkfscnmfmhm          71 CPU             100%   68.722169        13469206          0         26       2.73          518046          0          1         26       317934794 2024/02/29 16

SQL_ID        CHILD_NUMBER SENSI AWARE SHARE MODULE_AT_PARSE_TIME FIRST_LOAD_TIME      LAST_LOAD_TIME       PROGRAM_NAME                   PROGRAM_TYPE                   PROGRAM_LINE# PLAN_HASH_VALUE
------------- ------------ ----- ----- ----- -------------------- -------------------- -------------------- ------------------------------ ------------------------------ ------------- ---------------
01gkfscnmfmhm            0 N     N     Y     A390796BAE8CAEBCB87D 2024-01-29/08:39:16  2024-02-29/14:07:36  CALCULE_PLAFOND_SOLDE          PROCEDURE                                119       317934794
01gkfscnmfmhm            3 Y     N     Y     A390796BAE8CAEBCB87D 2024-01-29/08:39:16  2024-02-29/10:21:09  CALCULE_PLAFOND_SOLDE          PROCEDURE                                119       317934794


Plan hash value: 317934794
---------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                 | Name                     | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers |
---------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                          |                          |      1 |        |     4 (100)|      1 |00:00:32.57 |     513K|
|   1 |  SORT AGGREGATE                           |                          |      1 |      1 |            |      1 |00:00:32.57 |     513K|
|   2 |   NESTED LOOPS                            |                          |      1 |      1 |     4   (0)|    572 |00:00:32.57 |     513K|
|   3 |    NESTED LOOPS                           |                          |      1 |      9 |     4   (0)|   7981K|00:00:11.79 |   24758 |
|   4 |     MERGE JOIN CARTESIAN                  |                          |      1 |      1 |     3   (0)|  29887 |00:00:00.06 |    1281 |
|   5 |      NESTED LOOPS                         |                          |      1 |      1 |     2   (0)|    209 |00:00:00.02 |    1280 |
|   6 |       NESTED LOOPS                        |                          |      1 |      1 |     2   (0)|    462 |00:00:00.01 |     818 |
|*  7 |        TABLE ACCESS BY INDEX ROWID BATCHED| G_PIECE                  |      1 |      1 |     1   (0)|    209 |00:00:00.01 |     185 |
|*  8 |         INDEX RANGE SCAN                  | PIE_REFDOSS              |      1 |      2 |     1   (0)|    209 |00:00:00.01 |       4 |
|*  9 |        INDEX RANGE SCAN                   | ENTENR_EE_DOS_EE_REF_IDX |    209 |      1 |     1   (0)|    462 |00:00:00.01 |     633 |
|* 10 |       TABLE ACCESS BY INDEX ROWID         | F_ENTENR                 |    462 |      1 |     1   (0)|    209 |00:00:00.01 |     462 |
|  11 |      BUFFER SORT                          |                          |    209 |    143 |     2   (0)|  29887 |00:00:00.02 |       1 |
|  12 |       INDEX FULL SCAN                     | PK_PE_NOM                |      1 |    143 |     1   (0)|    143 |00:00:00.01 |       1 |
|* 13 |     INDEX RANGE SCAN                      | F_DETENR$DE_MAITRE       |  29887 |      9 |     1   (0)|   7981K|00:00:04.45 |   23477 |
|* 14 |    TABLE ACCESS BY INDEX ROWID            | F_DETENR                 |   7981K|      1 |     1   (0)|    572 |00:00:09.59 |     488K|
---------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   7 - filter(("G"."PAGE"=:B3 AND "G"."REFPIECE" IS NOT NULL))
   8 - access("G"."REFDOSS"=:B2 AND "TYPPIECE"='AVANCE')
   9 - access("F"."EE_DOS"='GLOBAL' AND "G"."REFPIECE"="F"."EE_REF")
       filter("F"."EE_REF" IS NOT NULL)
  10 - filter(("F"."EE_FINMODE"='D' AND "F"."EE_MAITRE"||''='PMT'))
  13 - access("DE_MAITRE"="F"."EE_NUM")
       filter("DE_MAITRE" IS NOT NULL)
  14 - filter(("DE_DOS"=:B1 AND SUBSTR("DE_NOM",1,1)='A'))

*/
/********************************OLD Metrics***************************************/

/********************************New SQL*******************************************/

SELECT /*+ leading(D F G) */
       SUM ( NVL( DECODE( G.GPIDEVIS, 'FRF', 1/6.55957 , 1 ) * D.DE_PAYE_MVT, 0 ) ) 
  FROM G_PIECE G, 
       F_ENTENR F, 
       F_DETENR D
 WHERE G.TYPPIECE = 'AVANCE' 
   AND G.REFPIECE = F.EE_REF 
   AND G.PAGE = :B3 
   AND F.EE_DOS = 'GLOBAL' 
   AND F.EE_FINMODE = 'D' 
   AND F.EE_MAITRE||'' = 'PMT' 
   AND G.REFDOSS = :B2 
   AND D.DE_MAITRE = F.EE_NUM 
   AND D.DE_DOS = :B1 
   AND SUBSTR( D.DE_NOM , 1, 1 ) = 'A';
/********************************New SQL*******************************************/
/********************************New Metrics***************************************/
/*
Plan hash value: 3242355601
-----------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                               | Name       | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers |
-----------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                        |            |      1 |        |     3 (100)|      1 |00:00:00.01 |      60 |
|   1 |  SORT AGGREGATE                         |            |      1 |      1 |            |      1 |00:00:00.01 |      60 |
|   2 |   NESTED LOOPS                          |            |      1 |      1 |     3   (0)|      4 |00:00:00.01 |      60 |
|   3 |    NESTED LOOPS                         |            |      1 |      1 |     3   (0)|      4 |00:00:00.01 |      57 |
|   4 |     NESTED LOOPS                        |            |      1 |      1 |     2   (0)|      4 |00:00:00.01 |      47 |
|*  5 |      TABLE ACCESS BY INDEX ROWID BATCHED| F_DETENR   |      1 |      1 |     1   (0)|      8 |00:00:00.01 |      23 |
|*  6 |       INDEX RANGE SCAN                  | DETENR_DOS |      1 |     11 |     1   (0)|     26 |00:00:00.01 |       4 |
|*  7 |      TABLE ACCESS BY INDEX ROWID BATCHED| F_ENTENR   |      8 |      1 |     1   (0)|      4 |00:00:00.01 |      24 |
|*  8 |       INDEX RANGE SCAN                  | ENTENR_CL1 |      8 |      1 |     1   (0)|      8 |00:00:00.01 |      18 |
|*  9 |     INDEX RANGE SCAN                    | PK_G_PIECE |      4 |      1 |     1   (0)|      4 |00:00:00.01 |      10 |
|* 10 |    TABLE ACCESS BY INDEX ROWID          | G_PIECE    |      4 |      1 |     1   (0)|      4 |00:00:00.01 |       3 |
-----------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   5 - filter(("D"."DE_MAITRE" IS NOT NULL AND SUBSTR("D"."DE_NOM",1,1)='A'))
   6 - access("D"."DE_DOS"=:B1)
   7 - filter(("F"."EE_REF" IS NOT NULL AND "F"."EE_DOS"='GLOBAL' AND "F"."EE_FINMODE"='D' AND
              "F"."EE_MAITRE"||''='PMT'))
   8 - access("D"."DE_MAITRE"="F"."EE_NUM")
   9 - access("G"."REFPIECE"="F"."EE_REF")
       filter("G"."REFPIECE" IS NOT NULL)
  10 - filter(("G"."REFDOSS"=:B2 AND "G"."PAGE"=:B3 AND "G"."TYPPIECE"='AVANCE'))
*/
/********************************New Metrics***************************************/

/********************************Index statistics**********************************/

/********************************Other SQLs****************************************/          
/*

*/ 
/********************************Other SQLs****************************************/              
