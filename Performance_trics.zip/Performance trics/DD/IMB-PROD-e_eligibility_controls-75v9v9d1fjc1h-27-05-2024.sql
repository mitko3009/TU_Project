/********************************************************************************
*********       E-mail subject: IMBDEV-11991
*********             Instance: PROD
*********          Description: 
Problem:
SQL was found in the V9 logs from screen e_eligibility_controls

Analysis:
We analyzed SQL 75v9v9d1fjc1h which based on the V9 logs was associated with the slowness in screen e_eligibility_controls.
The problem in this query is that we search for ancrefdoss with % in front ( GD_CONTRAT.ancrefdoss LIKE '%' || :B1 || '%' ), which is not selective.
The solution here is to remove the % in front and leave only the % behind, as it is shown in the New SQL section below.

Suggestion:
Please change the SQL text as it is shown in the New SQL section below.

*********               SQL_ID: 75v9v9d1fjc1h
*********      Program/Package: 
*********              Request: Dimitare Ivanov
*********               Author: Dimitar Dimitrov
********* Received e-mail date: 23/05/2024
*********      Resolution date: 27/05/2024
*********  Trace old file here: \\epox\specifs\performance\tmp\
*********  Trace new file here:
***********************************************************************************/

/********************************OLD SQL*******************************************/

VAR B1 VARCHAR2(32);
EXEC :B1 := 'AT03639';
VAR B2 NUMBER;
EXEC :B2 := 2001;
VAR B3 NUMBER;
EXEC :B3 := 1;

SELECT *
  FROM (SELECT /*+ first_rows(2001)*/
         foo.*, ROWNUM rnum
          FROM (SELECT montant_mvt amount,
                       refpiece    docRef,
                       color       color,
                       refdoss     clAccount,
                       refext      invNumber,
                       nom         debtorName,
                       devise_mvt  currency,
                       ancrefdoss  cntNumber,
                       refelem     refElem,
                       clDbAccount clDbAccount
                  FROM (SELECT 'NO COLOR' AS color,
                               GD_DECOMPTE.refdoss,
                               GD_CONTRAT.ancrefdoss,
                               GD_COMPTE.refdoss clDbAccount,
                               GP_FACT.refpiece,
                               ELEMFI.refelem,
                               ELEMFI.refext,
                               ELEMFI.montant_mvt,
                               GD_COMPTE.nom,
                               ELEMFI.devise_mvt
                          FROM g_dossier GD_DECOMPTE,
                               g_dossier GD_CONTRAT,
                               g_piece GP_FACT,
                               g_elemfi ELEMFI,
                               (SELECT GD_COMPTE.reflot,
                                       GD_COMPTE.refdoss,
                                       gi.nom
                                  FROM g_dossier      GD_COMPTE,
                                       t_intervenants TI_COMPTE,
                                       g_individu     GI
                                 WHERE TI_COMPTE.refdoss = GD_COMPTE.refdoss
                                   AND GD_COMPTE.categdoss LIKE 'COMPTE%'
                                   AND gi.refindividu = TI_COMPTE.refindividu
                                   AND TI_COMPTE.reftype = 'DB') GD_COMPTE
                         WHERE 1 = 1
                           AND GD_DECOMPTE.reflot = GD_CONTRAT.refdoss
                           AND GD_CONTRAT.categdoss LIKE 'CONTRAT%'
                           AND GD_COMPTE.reflot = GD_DECOMPTE.refdoss
                           AND GP_FACT.refdoss = GD_COMPTE.refdoss
                           AND GP_FACT.typpiece = 'FACTURE'
                           AND GP_FACT.gpiheure = ELEMFI.refelem
                           AND ELEMFI.dttraite_dt IS NULL
                           AND 0 <>
                               DECODE(GP_FACT.dt10,
                                      NULL,
                                      GP_FACT.mt24,
                                      ftr_util.SoldeF_DCPT(ELEMFI.refelem))
                           AND EXISTS
                         (SELECT 1
                                  FROM eligib_ctrl
                                 WHERE dt_resolve IS NULL
                                   AND reffacture = GP_FACT.refpiece
                                   AND ROWNUM = 1)
                           AND GD_CONTRAT.ancrefdoss LIKE '%' || :B1 || '%')
                 WHERE 1 = 1
                 ORDER BY refelem, refelem) foo
         WHERE ROWNUM <= :B2)
WHERE 1 = 1
   AND rnum >= :B3;
/********************************OLD SQL*******************************************/
/********************************OLD Metrics***************************************/
/*
Plan hash value: 1181106023
---------------------------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                         | Name                      | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  |
---------------------------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                                  |                           |      1 |        | 26947 (100)|      0 |00:00:00.01 |       0 |      0 |
|*  1 |  VIEW                                             |                           |      1 |      1 | 26947   (1)|      0 |00:00:00.01 |       0 |      0 |
|*  2 |   COUNT STOPKEY                                   |                           |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
|   3 |    VIEW                                           |                           |      1 |      1 | 26947   (1)|      0 |00:00:00.01 |       0 |      0 |
|*  4 |     SORT ORDER BY STOPKEY                         |                           |      1 |      1 | 26947   (1)|      0 |00:00:00.01 |       0 |      0 |
|   5 |      NESTED LOOPS                                 |                           |      1 |   1496 |  3589   (1)|      0 |00:00:00.01 |       0 |      0 |
|   6 |       NESTED LOOPS                                |                           |      1 |   1496 |  3589   (1)|      0 |00:00:00.01 |       0 |      0 |
|   7 |        NESTED LOOPS                               |                           |      1 |   1496 |  3559   (1)|      0 |00:00:00.01 |       0 |      0 |
|   8 |         NESTED LOOPS                              |                           |      1 |   1493 |  3529   (1)|      0 |00:00:00.01 |       0 |      0 |
|*  9 |          HASH JOIN                                |                           |      1 |  34770 |  2834   (1)|      0 |00:00:00.01 |       0 |      0 |
|* 10 |           TABLE ACCESS BY INDEX ROWID BATCHED     | G_DOSSIER                 |      1 |   2413 |     1   (0)|      1 |00:00:00.01 |       4 |      0 |
|* 11 |            INDEX RANGE SCAN                       | DOS_ANCREFDOSS            |      1 |     22 |     1   (0)|      1 |00:00:00.01 |       3 |      0 |
|* 12 |           HASH JOIN                               |                           |      1 |  34860 |  2832   (1)|      0 |00:00:00.01 |       0 |      0 |
|* 13 |            HASH JOIN                              |                           |      1 |  34939 |  2812   (1)|    303K|00:00:24.29 |    4746K|  51166 |
|* 14 |             INDEX SKIP SCAN                       | G_DOSSIER_RL_CD_RD_RF_IDX |      1 |  48263 |    28   (0)|    240K|00:00:00.43 |    2838 |      0 |
|* 15 |             TABLE ACCESS BY INDEX ROWID BATCHED   | G_PIECE                   |      1 |    176K|  2783   (1)|    303K|00:00:23.62 |    4743K|  51166 |
|* 16 |              INDEX SKIP SCAN                      | GP_REFEXT_IDX             |      1 |    380K|  1341   (0)|    303K|00:00:08.86 |    4048K|    140 |
|* 17 |               COUNT STOPKEY                       |                           |   3286K|        |            |    303K|00:00:06.20 |    4008K|      0 |
|* 18 |                TABLE ACCESS BY INDEX ROWID BATCHED| ELIGIB_CTRL               |   3286K|      1 |     1   (0)|    303K|00:00:04.92 |    4008K|      0 |
|* 19 |                 INDEX RANGE SCAN                  | EC_REFFACTURE_IDX         |   3286K|      1 |     1   (0)|    463K|00:00:03.22 |    3425K|      0 |
|  20 |            INDEX FULL SCAN                        | DOS_REFDOSS_REFLOT_IDX    |      0 |    241K|    20   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 21 |          TABLE ACCESS BY INDEX ROWID              | G_ELEMFI                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 22 |           INDEX UNIQUE SCAN                       | EFI_REFELEM               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 23 |         INDEX RANGE SCAN                          | INT_REFDOSS               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 24 |        INDEX UNIQUE SCAN                          | IND_REFINDIV              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|  25 |       TABLE ACCESS BY INDEX ROWID                 | G_INDIVIDU                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
---------------------------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   1 - filter("RNUM">=:B3)
   2 - filter(ROWNUM<=:B2)
   4 - filter(ROWNUM<=:B2)
   9 - access("GD_DECOMPTE"."REFLOT"="GD_CONTRAT"."REFDOSS")
  10 - filter("GD_CONTRAT"."CATEGDOSS" LIKE 'CONTRAT%')
  11 - access("GD_CONTRAT"."ANCREFDOSS" LIKE '%'||:B1||'%')
       filter("GD_CONTRAT"."ANCREFDOSS" LIKE '%'||:B1||'%')
  12 - access("GD_COMPTE"."REFLOT"="GD_DECOMPTE"."REFDOSS")
  13 - access("GP_FACT"."REFDOSS"="GD_COMPTE"."REFDOSS")
  14 - access("GD_COMPTE"."CATEGDOSS" LIKE 'COMPTE%')
       filter("GD_COMPTE"."CATEGDOSS" LIKE 'COMPTE%')
  15 - filter(("GP_FACT"."GPIHEURE" IS NOT NULL AND "GP_FACT"."REFDOSS" IS NOT NULL))
  16 - access("GP_FACT"."TYPPIECE"='FACTURE')
       filter(("GP_FACT"."TYPPIECE"='FACTURE' AND  IS NOT NULL))
  17 - filter(ROWNUM=1)
  18 - filter("DT_RESOLVE" IS NULL)
  19 - access("REFFACTURE"=:B1)
  21 - filter("ELEMFI"."DTTRAITE_DT" IS NULL)
  22 - access("GP_FACT"."GPIHEURE"="ELEMFI"."REFELEM")
       filter(DECODE(TO_CHAR("GP_FACT"."DT10"),NULL,"GP_FACT"."MT24","FTR_UTIL"."SOLDEF_DCPT"("ELEMFI"."REFELEM"))<>0)
  23 - access("TI_COMPTE"."REFDOSS"="GD_COMPTE"."REFDOSS" AND "TI_COMPTE"."REFTYPE"='DB')
  24 - access("GI"."REFINDIVIDU"="TI_COMPTE"."REFINDIVIDU")
*/
/********************************OLD Metrics***************************************/

/********************************New SQL*******************************************/

SELECT *
  FROM (SELECT /*+ first_rows(2001)*/
         foo.*, ROWNUM rnum
          FROM (SELECT montant_mvt amount,
                       refpiece    docRef,
                       color       color,
                       refdoss     clAccount,
                       refext      invNumber,
                       nom         debtorName,
                       devise_mvt  currency,
                       ancrefdoss  cntNumber,
                       refelem     refElem,
                       clDbAccount clDbAccount
                  FROM (SELECT 'NO COLOR' AS color,
                               GD_DECOMPTE.refdoss,
                               GD_CONTRAT.ancrefdoss,
                               GD_COMPTE.refdoss clDbAccount,
                               GP_FACT.refpiece,
                               ELEMFI.refelem,
                               ELEMFI.refext,
                               ELEMFI.montant_mvt,
                               GD_COMPTE.nom,
                               ELEMFI.devise_mvt
                          FROM g_dossier GD_DECOMPTE,
                               g_dossier GD_CONTRAT,
                               g_piece GP_FACT,
                               g_elemfi ELEMFI,
                               (SELECT GD_COMPTE.reflot,
                                       GD_COMPTE.refdoss,
                                       gi.nom
                                  FROM g_dossier      GD_COMPTE,
                                       t_intervenants TI_COMPTE,
                                       g_individu     GI
                                 WHERE TI_COMPTE.refdoss = GD_COMPTE.refdoss
                                   AND GD_COMPTE.categdoss LIKE 'COMPTE%'
                                   AND gi.refindividu = TI_COMPTE.refindividu
                                   AND TI_COMPTE.reftype = 'DB') GD_COMPTE
                         WHERE 1 = 1
                           AND GD_DECOMPTE.reflot = GD_CONTRAT.refdoss
                           AND GD_CONTRAT.categdoss LIKE 'CONTRAT%'
                           AND GD_COMPTE.reflot = GD_DECOMPTE.refdoss
                           AND GP_FACT.refdoss = GD_COMPTE.refdoss
                           AND GP_FACT.typpiece = 'FACTURE'
                           AND GP_FACT.gpiheure = ELEMFI.refelem
                           AND ELEMFI.dttraite_dt IS NULL
                           AND 0 <>
                               DECODE(GP_FACT.dt10,
                                      NULL,
                                      GP_FACT.mt24,
                                      ftr_util.SoldeF_DCPT(ELEMFI.refelem))
                           AND EXISTS
                         (SELECT 1
                                  FROM eligib_ctrl
                                 WHERE dt_resolve IS NULL
                                   AND reffacture = GP_FACT.refpiece
                                   AND ROWNUM = 1)
                           AND GD_CONTRAT.ancrefdoss LIKE :B1 || '%')
                 WHERE 1 = 1
                 ORDER BY refelem, refelem) foo
         WHERE ROWNUM <= :B2)
WHERE 1 = 1
   AND rnum >= :B3;
/********************************New SQL*******************************************/
/********************************New Metrics***************************************/
/*
Plan hash value: 2897031121
-------------------------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                       | Name                      | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  |
-------------------------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                                |                           |      1 |        |    14 (100)|      1 |00:00:00.62 |   58324 |   1552 |
|*  1 |  VIEW                                           |                           |      1 |      1 |    14   (8)|      1 |00:00:00.62 |   58324 |   1552 |
|*  2 |   COUNT STOPKEY                                 |                           |      1 |        |            |      1 |00:00:00.62 |   58324 |   1552 |
|   3 |    VIEW                                         |                           |      1 |      1 |    14   (8)|      1 |00:00:00.62 |   58324 |   1552 |
|*  4 |     SORT ORDER BY STOPKEY                       |                           |      1 |      1 |    14   (8)|      1 |00:00:00.62 |   58324 |   1552 |
|*  5 |      FILTER                                     |                           |      1 |        |            |      1 |00:00:00.62 |   58324 |   1552 |
|   6 |       NESTED LOOPS                              |                           |      1 |      7 |    10   (0)|    582 |00:00:00.61 |   56484 |   1552 |
|   7 |        NESTED LOOPS                             |                           |      1 |      7 |    10   (0)|    582 |00:00:00.58 |   56382 |   1519 |
|   8 |         NESTED LOOPS                            |                           |      1 |      7 |     9   (0)|    582 |00:00:00.58 |   55734 |   1519 |
|   9 |          NESTED LOOPS                           |                           |      1 |      7 |     8   (0)|    582 |00:00:00.57 |   55398 |   1519 |
|  10 |           NESTED LOOPS                          |                           |      1 |    153 |     4   (0)|  11312 |00:00:00.36 |   31053 |   1239 |
|  11 |            NESTED LOOPS                         |                           |      1 |     11 |     3   (0)|   1149 |00:00:00.01 |      22 |      0 |
|  12 |             NESTED LOOPS                        |                           |      1 |     53 |     2   (0)|      1 |00:00:00.01 |       6 |      0 |
|* 13 |              TABLE ACCESS BY INDEX ROWID BATCHED| G_DOSSIER                 |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |      0 |
|* 14 |               INDEX RANGE SCAN                  | DOS_ANCREFDOSS            |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       2 |      0 |
|* 15 |              INDEX RANGE SCAN                   | G_DOSSIER_RL_CD_RD_RF_IDX |      1 |    264 |     1   (0)|      1 |00:00:00.01 |       3 |      0 |
|* 16 |             INDEX RANGE SCAN                    | G_DOSSIER_RL_CD_RD_RF_IDX |      1 |      1 |     1   (0)|   1149 |00:00:00.01 |      16 |      0 |
|* 17 |            TABLE ACCESS BY INDEX ROWID BATCHED  | G_PIECE                   |   1149 |     14 |     1   (0)|  11312 |00:00:00.36 |   31031 |   1239 |
|* 18 |             INDEX RANGE SCAN                    | PIE_REFDOSS               |   1149 |     22 |     1   (0)|  11312 |00:00:00.05 |    1344 |     98 |
|* 19 |           TABLE ACCESS BY INDEX ROWID           | G_ELEMFI                  |  11312 |      1 |     1   (0)|    582 |00:00:00.21 |   24345 |    280 |
|* 20 |            INDEX UNIQUE SCAN                    | EFI_REFELEM               |  11312 |      1 |     1   (0)|    582 |00:00:00.18 |   23763 |    229 |
|* 21 |          INDEX RANGE SCAN                       | INT_REFDOSS               |    582 |      1 |     1   (0)|    582 |00:00:00.01 |     336 |      0 |
|* 22 |         INDEX UNIQUE SCAN                       | IND_REFINDIV              |    582 |      1 |     1   (0)|    582 |00:00:00.01 |     648 |      0 |
|  23 |        TABLE ACCESS BY INDEX ROWID              | G_INDIVIDU                |    582 |      1 |     1   (0)|    582 |00:00:00.03 |     102 |     33 |
|* 24 |       COUNT STOPKEY                             |                           |    582 |        |            |      1 |00:00:00.01 |    1840 |      0 |
|* 25 |        TABLE ACCESS BY INDEX ROWID BATCHED      | ELIGIB_CTRL               |    582 |      1 |     1   (0)|      1 |00:00:00.01 |    1840 |      0 |
|* 26 |         INDEX RANGE SCAN                        | EC_REFFACTURE_IDX         |    582 |      1 |     1   (0)|    152 |00:00:00.01 |    1688 |      0 |
-------------------------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   1 - filter("RNUM">=:B3)
   2 - filter(ROWNUM<=:B2)
   4 - filter(ROWNUM<=:B2)
   5 - filter( IS NOT NULL)
  13 - filter("GD_CONTRAT"."CATEGDOSS" LIKE 'CONTRAT%')
  14 - access("GD_CONTRAT"."ANCREFDOSS" LIKE :B1||'%')
       filter("GD_CONTRAT"."ANCREFDOSS" LIKE :B1||'%')
  15 - access("GD_DECOMPTE"."REFLOT"="GD_CONTRAT"."REFDOSS")
  16 - access("GD_COMPTE"."REFLOT"="GD_DECOMPTE"."REFDOSS" AND "GD_COMPTE"."CATEGDOSS" LIKE 'COMPTE%')
       filter("GD_COMPTE"."CATEGDOSS" LIKE 'COMPTE%')
  17 - filter("GP_FACT"."GPIHEURE" IS NOT NULL)
  18 - access("GP_FACT"."REFDOSS"="GD_COMPTE"."REFDOSS" AND "GP_FACT"."TYPPIECE"='FACTURE')
       filter("GP_FACT"."REFDOSS" IS NOT NULL)
  19 - filter("ELEMFI"."DTTRAITE_DT" IS NULL)
  20 - access("GP_FACT"."GPIHEURE"="ELEMFI"."REFELEM")
       filter(DECODE(TO_CHAR("GP_FACT"."DT10"),NULL,"GP_FACT"."MT24","FTR_UTIL"."SOLDEF_DCPT"("ELEMFI"."REFELEM"))<>0)
  21 - access("TI_COMPTE"."REFDOSS"="GD_COMPTE"."REFDOSS" AND "TI_COMPTE"."REFTYPE"='DB')
  22 - access("GI"."REFINDIVIDU"="TI_COMPTE"."REFINDIVIDU")
  24 - filter(ROWNUM=1)
  25 - filter("DT_RESOLVE" IS NULL)
  26 - access("REFFACTURE"=:B1)
*/
/********************************New Metrics***************************************/

/********************************Index statistics**********************************/

/********************************Other SQLs****************************************/          
/*

*/ 
/********************************Other SQLs****************************************/              
