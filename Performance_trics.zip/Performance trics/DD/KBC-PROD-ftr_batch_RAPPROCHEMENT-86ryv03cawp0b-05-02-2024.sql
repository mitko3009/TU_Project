/********************************************************************************
*********       E-mail subject: KBCCFWEB-2020
*********             Instance: PROD
*********          Description: 
Problem:
SQL 86ryv03cawp0b took around 98% of the time of ftr_batch_RAPPROCHEMENT batch on 23/01/2024 on KBC PROD.

Analysis:
From the analyze we found that SQL 86ryv03cawp0b took around 98% of the time of ftr_batch_RAPPROCHEMENT batch on KBC PROD.
There was not suitable index for this SQL and it was doing a bad execution plan. After discussion with C&D, the solution here is to add 
column COMM of table g_encaissement to index G_ENC_FG_RECONC_FUNC_IDX and add MOYENPAIMT = 'BANK TRANSFER' in the query.

Suggestion:
Please modify the query as it is shown in the New SQL section below.

*********               SQL_ID: 86ryv03cawp0b
*********      Program/Package: 
*********              Request: Dimitare Ivanov
*********               Author: Dimitar Dimitrov
********* Received e-mail date: 23/01/2024
*********      Resolution date: 05/02/2024
*********  Trace old file here: \\epox\specifs\performance\tmp\
*********  Trace new file here:
***********************************************************************************/

/********************************OLD SQL*******************************************/
-- Binds from ACC1

var b3 number;
exec :B3 := 13412.12;
var b4 varchar2(32);
exec :b4 := 'EUR';
var b5 varchar2(128);
exec :b5 := 'TYEPZ0F4LBSIPBBEONTVA';

select MAX ( refencaiss ) ,
       MAX ( refdoss ) ,
       count ( * )
  FROM g_encaissement
 WHERE montant_mvt = :b3
   AND devise_mvt = :b4
   AND typencaiss in ( 'e_saencaiss' , 'Enregistrement' )
   AND NVL ( flag_reconciliation , 'N' ) = 'N'
   AND dtannul is NULL
   AND createur IN ( 'UPLOAD_PMT' , 'UPLOAD_PMT_CL' )
   AND traite IN ( '0' , '3' )
   AND comm LIKE '%' || :b5 || '%';

/********************************OLD SQL*******************************************/
/********************************OLD Metrics***************************************/

MODULE                           SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
ftr_batch_RAPPROCHEMENT          86ryv03cawp0b 3320854666        633      28566 ON CPU               2024/01/23 06:12:20  2024/01/23 20:31:15        4988                19374 +000000000 14:18:55.429 98%

/*
SQL_ID        SQL_PLAN_HASH_VALUE SQL_PLAN_LINE_ID SQL_PLAN_OPERATION             SQL_PLAN_OPTIONS                   ACTIVE
------------- ------------------- ---------------- ------------------------------ ------------------------------ ----------
86ryv03cawp0b          3320854666                3 INDEX                          RANGE SCAN                           4988

Plan hash value: 3320854666
-----------------------------------------------------------------------------------------------
| Id  | Operation                            | Name                     | E-Rows | Cost (%CPU)|
-----------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                     |                          |        |  4830 (100)|
|   1 |  SORT AGGREGATE                      |                          |      1 |            |
|*  2 |   TABLE ACCESS BY INDEX ROWID BATCHED| G_ENCAISSEMENT           |      1 |  4830   (1)|
|*  3 |    INDEX RANGE SCAN                  | G_ENC_FG_RECONC_FUNC_IDX |     68 |  4829   (1)|
-----------------------------------------------------------------------------------------------
*/
/********************************OLD Metrics***************************************/

/********************************New SQL*******************************************/
select MAX ( refencaiss ) ,
       MAX ( refdoss ) ,
       count ( * )
  FROM g_encaissement
 WHERE montant_mvt = :b3
   AND devise_mvt = :b4
   AND typencaiss in ( 'e_saencaiss' , 'Enregistrement' )
   AND NVL ( flag_reconciliation , 'N' ) = 'N'
   AND dtannul is NULL
   AND createur IN ( 'UPLOAD_PMT' , 'UPLOAD_PMT_CL' )
   AND traite IN ( '0' , '3' )
   AND comm = :b5
   AND MOYENPAIMT = 'VIREMENT BANCAIRE';

/********************************New SQL*******************************************/
/********************************New Metrics***************************************/
/*
-- This plan is from the test of the New SQL on ACC1

Plan hash value: 2253493759
-----------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                             | Name            | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  |
-----------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                      |                 |      1 |        |     1 (100)|      1 |00:00:00.01 |      14 |      7 |
|   1 |  SORT AGGREGATE                       |                 |      1 |      1 |            |      1 |00:00:00.01 |      14 |      7 |
|   2 |   INLIST ITERATOR                     |                 |      1 |        |            |      0 |00:00:00.01 |      14 |      7 |
|*  3 |    TABLE ACCESS BY INDEX ROWID BATCHED| G_ENCAISSEMENT  |      4 |      1 |     1   (0)|      0 |00:00:00.01 |      14 |      7 |
|*  4 |     INDEX RANGE SCAN                  | TEST_DD_GE_IDX1 |      4 |      1 |     1   (0)|      0 |00:00:00.01 |      14 |      7 |
-----------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   3 - filter(("MONTANT_MVT"=:B3 AND "DEVISE_MVT"=:B4 AND INTERNAL_FUNCTION("CREATEUR") AND "DTANNUL" IS NULL))
   4 - access("G_ENCAISSEMENT"."SYS_NC00254$"='N' AND "MOYENPAIMT"='VIREMENT BANCAIRE' AND (("TYPENCAISS"='Enregistrement' OR
              "TYPENCAISS"='e_saencaiss')) AND (("TRAITE"='0' OR "TRAITE"='3')) AND "COMM"=:B5)
*/
/********************************New Metrics***************************************/

/********************************Index statistics**********************************/

/********************************Other SQLs****************************************/          
/*

*/ 
/********************************Other SQLs****************************************/              
