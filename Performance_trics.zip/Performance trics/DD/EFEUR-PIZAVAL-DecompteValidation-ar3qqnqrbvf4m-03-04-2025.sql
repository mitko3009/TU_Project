/********************************************************************************
*********       E-mail subject: EFEURDEV-6649
*********             Instance: PIZAVAL
*********          Description: 
Problem:
The cursor of the DecompteValidation batch has function in the where clause, which is not good from performance point of view.

Analysis:
In EFEURDEV-6529 it was found that there is a function in the WHERE clause in the cursor of the DecompteValidation batch. Based on what we see in the execution plan 
on PIZAVAL, it looks like this is the slowest step of the execution. We moved the function call outside in the SELECT clause using the select from dual trick ( the scalar subquery caching ).
Also, we added some hints to make sure that Oracle will join the tables in the correct order every time.

Suggestion:
Please change the cursor of the DecompteValidation batch as it is shown in the New SQL section below.

*********               SQL_ID: ar3qqnqrbvf4m
*********      Program/Package: 
*********              Request: Branimir Lalev 
*********               Author: Dimitar Dimitrov
********* Received e-mail date: 03/04/2025
*********      Resolution date: 03/04/2025
*********  Trace old file here: \\epox\specifs\performance\tmp\
*********  Trace new file here:
***********************************************************************************/

/********************************OLD SQL*******************************************/

SELECT d.reffactor /* automatically injected */, 
       d.refdoss, 
       newref.f_get_new_reference('piece')
  FROM g_dossier d, 
       g_piece sc, 
       g_etude e
 WHERE d.categdoss like 'DECOMPTE%%%'
    /* reffactor condition */
   AND d.reffactor IN ('INT00000')
   AND sc.refdoss = d.refdoss
   AND sc.typpiece = 'SOUS-CONTRAT'
   AND(   'all' != 'autofund' 
       OR sc.fg97 = 'O'
       OR sc.fg38 = 'O' )
   AND ftr_decompte.isContractValid( d.refdoss ) NOT IN ( 0, 2 )
   AND (   e.getdcli != 'C204' 
        OR nvl(sc.fg121, 'N' ) != 'O' )
    /* multi-process condition */
   AND ORA_HASH( d.refdoss, 7 ) = 6
 ORDER BY d.refdoss;
/********************************OLD SQL*******************************************/
/********************************OLD Metrics***************************************/
/*
Plan hash value: 1952441965
------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                      | Name        | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  |
------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT               |             |      1 |        |    10 (100)|   1544 |00:01:17.68 |     322K|  20615 |
|   1 |  NESTED LOOPS                  |             |      1 |      1 |    10   (0)|   1544 |00:01:17.68 |     322K|  20615 |
|   2 |   NESTED LOOPS                 |             |      1 |      1 |    10   (0)|   1544 |00:01:17.67 |     317K|  20615 |
|   3 |    MERGE JOIN CARTESIAN        |             |      1 |      1 |     9   (0)|   1544 |00:01:17.64 |     312K|  20615 |
|*  4 |     TABLE ACCESS BY INDEX ROWID| G_DOSSIER   |      1 |      1 |     6   (0)|   1544 |00:01:17.62 |     312K|  20615 |
|*  5 |      INDEX FULL SCAN           | DOS_REFDOSS |      1 |      5 |     6   (0)|   1588 |00:01:15.41 |     309K|  19241 |
|   6 |     BUFFER SORT                |             |   1544 |      1 |     3   (0)|   1544 |00:00:00.01 |       2 |      0 |
|   7 |      TABLE ACCESS FULL         | G_ETUDE     |      1 |      1 |     3   (0)|      1 |00:00:00.01 |       2 |      0 |
|*  8 |    INDEX RANGE SCAN            | PIE_REFDOSS |   1544 |      1 |     1   (0)|   1544 |00:00:00.03 |    4882 |      0 |
|*  9 |   TABLE ACCESS BY INDEX ROWID  | G_PIECE     |   1544 |      1 |     1   (0)|   1544 |00:00:00.01 |    4647 |      0 |
------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   4 - filter(("D"."REFFACTOR"='INT00000' AND "D"."CATEGDOSS" LIKE 'DECOMPTE%%%'))
   5 - filter((ORA_HASH("D"."REFDOSS",7)=6 AND "FTR_DECOMPTE"."ISCONTRACTVALID"("D"."REFDOSS")<>0 AND
              "FTR_DECOMPTE"."ISCONTRACTVALID"("D"."REFDOSS")<>2))
   8 - access("SC"."REFDOSS"="D"."REFDOSS" AND "SC"."TYPPIECE"='SOUS-CONTRAT')
       filter("SC"."REFDOSS" IS NOT NULL)
   9 - filter(("E"."GETDCLI"<>'C204' OR NVL("SC"."FG121",'N')<>'O'))
*/
/********************************OLD Metrics***************************************/

/********************************New SQL*******************************************/

SELECT reffactor,
       refdoss,
       reference
  FROM ( SELECT /*+ leading(d sc e) use_nl(sc) index(d DOS_CATDOSS) */
                d.reffactor /* automatically injected */, 
                d.refdoss, 
                newref.f_get_new_reference('piece') reference,
                ( select ftr_decompte.isContractValid( d.refdoss ) from dual ) isValid
           FROM g_dossier d, 
                g_piece sc, 
                g_etude e
          WHERE d.categdoss like 'DECOMPTE%%%'
             /* reffactor condition */
            AND d.reffactor IN ('INT00000')
            AND sc.refdoss = d.refdoss
            AND sc.typpiece = 'SOUS-CONTRAT'
            AND(   'all' != 'autofund' 
                OR sc.fg97 = 'O'
                OR sc.fg38 = 'O' ) 
            AND (   e.getdcli != 'C204' 
                 OR nvl(sc.fg121, 'N' ) != 'O' ) )
 WHERE isValid NOT IN ( 0, 2 )
   AND ORA_HASH( refdoss, 7 ) = 6
 ORDER BY refdoss;
/********************************New SQL*******************************************/
/********************************New Metrics***************************************/
/*
Plan hash value: 228687641
---------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                               | Name        | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  |
---------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                        |             |      1 |        |    32 (100)|   1544 |00:00:19.72 |   65841 |  16636 |
|   1 |  SORT ORDER BY                          |             |      1 |      1 |    32   (4)|   1544 |00:00:19.72 |   65841 |  16636 |
|   2 |   FAST DUAL                             |             |   1609 |      1 |     2   (0)|   1609 |00:00:00.01 |       0 |      0 |
|*  3 |   VIEW                                  |             |      1 |      1 |    31   (0)|   1544 |00:00:19.71 |   65841 |  16636 |
|   4 |    NESTED LOOPS                         |             |      1 |      1 |    29   (0)|   1609 |00:00:06.06 |   34218 |   9170 |
|   5 |     NESTED LOOPS                        |             |      1 |      1 |    26   (0)|   1609 |00:00:06.01 |   29391 |   9170 |
|*  6 |      TABLE ACCESS BY INDEX ROWID BATCHED| G_DOSSIER   |      1 |     17 |    25   (0)|   1609 |00:00:01.33 |   19659 |   5914 |
|*  7 |       INDEX RANGE SCAN                  | DOS_CATDOSS |      1 |  11851 |     1   (0)|  12980 |00:00:00.05 |      40 |     40 |
|   8 |      TABLE ACCESS BY INDEX ROWID BATCHED| G_PIECE     |   1609 |      1 |     1   (0)|   1609 |00:00:04.68 |    9732 |   3256 |
|*  9 |       INDEX RANGE SCAN                  | PIE_REFDOSS |   1609 |      1 |     1   (0)|   1609 |00:00:02.87 |    4883 |   1718 |
|* 10 |     TABLE ACCESS FULL                   | G_ETUDE     |   1609 |      1 |     3   (0)|   1609 |00:00:00.05 |    4827 |      0 |
---------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   3 - filter(("ISVALID"<>0 AND "ISVALID"<>2))
   6 - filter(("D"."REFFACTOR"='INT00000' AND ORA_HASH("D"."REFDOSS",7)=6))
   7 - access("D"."CATEGDOSS" LIKE 'DECOMPTE%%%')
       filter("D"."CATEGDOSS" LIKE 'DECOMPTE%%%')
   9 - access("SC"."REFDOSS"="D"."REFDOSS" AND "SC"."TYPPIECE"='SOUS-CONTRAT')
       filter("SC"."REFDOSS" IS NOT NULL)
  10 - filter(("E"."GETDCLI"<>'C204' OR NVL("SC"."FG121",'N')<>'O'))
*/
/********************************New Metrics***************************************/

/********************************Index statistics**********************************/

/********************************Other SQLs****************************************/          
/*

*/ 
/********************************Other SQLs****************************************/              
