##############################################################################################################################################
################################# BACKUPS ################### RECOVERY_AREA ############### BACKUPS ############################# RECOVERY_AREA ################


####### BACKUPS TYPE ########
=================================================
1.НАЧИН - В ESL в Backup tab
2.НАЧИН - В crontab -l като user oracle
3.НАЧИН - Backup pieces -> ВЗИМАМЕ СИ СПЕЦИВИКАЗИЯТА ЗА BACKUP-A (BCK_DC2_ARCH_pkDIPdbadm_DIAP) -> locate omnib или which omnib -> nohup /opt/omni/bin/omnib -Oracle8 plwaws0004_ZDPS_archivelog_delete_on &
4.НАЧИН - СКРИПТ



################## Check backups and start archive backup ###############

crontab -l ----> proverka na bekupite
omnistat -det --> check for BACKUPS
Run backUP : nohup /opt/omni/bin/omnib  -Oracle8 KF_SESKVKF013_ORA_SDWD_DAILY_ARC_DEL &
nohup  ./arch1.sql > arch1.log 2>&1 &
nohup /opt/omni/bin/omnib  -Oracle8 sl70185_ora_prod_OGERP1P_daily_arch_del &



#######################################
########################################
да убия дадена session/backup/kill a session    very good!!!

select 'ALTER SYSTEM KILL SESSION '||''''||sid||','||serial#||',@'||inst_id||''' IMMEDIATE;' from gv$session where SID=&sid;  - ще ме пита за ном




#################### ARCHIVE DEST SPACE UTILIZATION: ###########################

####### RESIZE FS +FRA

show parameter recovery ---> pokazva info za FRA




####### Vzimame parametyra na FRA i go resize-vame s tova query:

alter system set db_recovery_file_dest_size=1200G; 



######
show parameter reco
show parameter dest
archive log list;


###### TO SWITCH ARCHIVE DEST #####

##Check from controlniq file Къде трябва да е деста
SQL> archive log list;


alter system set db_recovery_file_dest='/oracle/FINCUBE1/oradata';
alter system switch logfile;
alter system archive log current;  #### best practice za RAC, така свитчваш на всички инстанси,Изчаква да си приключи писането в реду лог файла

alter system set log_archive_dest_1='LOCATION=/u02/oraarch/WSEOBI_A'; 




##### Change size and destination through RMAN #####

[‎3/‎26/‎2020 11:06 AM]  Vodenicharova, Velichka (Oracle DBA):  
RMAN>SQL "alter system set db_recovery_file_dest=''/oracle/export/EOIBPM1P/''";
RMAN>SQL "alter system set db_recovery_file_dest=''+RECO''";
RMAN>SQL "alter system set db_recovery_file_dest_size=120G";
RMAN> SQL "alter system set log_archive_dest_1=''LOCATION=/oracle/export/PU5ZS'' scope=memory";




######
set linesize 300
select * from v$flash_recovery_area_usage;

######
set linesize 300
show parameter db_recovery_file_dest;




###### Show me the Backup pieces ######

SET LINESIZE 400
SET PAGESIZE 9999 
COLUMN bs_key FORMAT 9999 HEADING 'BS|Key'
COLUMN piece# FORMAT 99999 HEADING 'Piece|#'
COLUMN copy# FORMAT 9999 HEADING 'Copy|#'
COLUMN bp_key FORMAT 9999 HEADING 'BP|Key'
COLUMN status FORMAT a9 HEADING 'Status'
COLUMN handle FORMAT a65 HEADING 'Handle'
COLUMN start_time FORMAT a17 HEADING 'Start|Time'
COLUMN completion_time FORMAT a17 HEADING 'End|Time'
COLUMN elapsed_seconds FORMAT 999,999 HEADING 'Elapsed|Seconds'
COLUMN deleted FORMAT a8 HEADING 'Deleted?'
BREAK ON bs_key
prompt
prompt Available backup pieces contained in the control file.
prompt Includes available and expired backup sets.
prompt 
SELECT
bs.recid bs_key
, bp.piece# piece#
, bp.copy# copy#
, bp.recid bp_key
, DECODE( status
, 'A', 'Available'
, 'D', 'Deleted'
, 'X', 'Expired') status
, handle handle
, TO_CHAR(bp.start_time, 'mm/dd/yy HH24:MI:SS') start_time
, TO_CHAR(bp.completion_time, 'mm/dd/yy HH24:MI:SS') completion_time
, bp.elapsed_seconds elapsed_seconds
FROM
v$backup_set bs
, v$backup_piece bp
WHERE
bs.set_stamp = bp.set_stamp
AND bs.set_count = bp.set_count
AND bp.status IN ('A', 'X')
ORDER BY
bs.recid
, piece#
/





######
PROMPT Archivelog Space Report

col limit format 999,999,999 heading "Limit (mb)";
col used format 999,999,999 heading "Space Used (mb)";
col free format 999,999,999 heading "Space Free (mb)";
select space_limit/(1024*1024) limit
, (space_used + space_reclaimable)/(1024*1024) used
, (space_limit-(space_used+space_reclaimable))/(1024*1024) free
,number_of_files
from v$recovery_file_dest
/



### PRIMARY OR STANDBY  ####
 
### from primary
 
set pages 1000
set lines 120
column DEST_NAME format a20
column DESTINATION format a35
column ARCHIVER format a10
column TARGET format a15
column status format a10
column error format a15
select DEST_ID,DEST_NAME,DESTINATION,TARGET,STATUS,ERROR from v$archive_dest
where DESTINATION is NOT NULL
/

   DEST_ID DEST_NAME		DESTINATION			    TARGET	    STATUS     ERROR
---------- -------------------- ----------------------------------- --------------- ---------- ---------------
	 1 LOG_ARCHIVE_DEST_1	USE_DB_RECOVERY_FILE_DEST	    PRIMARY	    VALID
	 2 LOG_ARCHIVE_DEST_2	aramphys			    STANDBY	    VALID 
	 
	 
	 
	 
	 
	 
##################################################################
######################   Start BACKUPS  ##########################
##################################################################
	 
############################ START BACKUP THROUGH SKRIPT / EON ########################

set env
cd /tsm
cd /<DB_name>         ###Trqbva da ima direktoriq s imeto na bazata
Start.Redolog.sh      ###Tyrsq tozi script 
./StartRedolog.sh &   ###Taka go execute-vam i ouskam backup-a 
tail -100f <pytq na loga>  ###Da vidq dali trygva

!!!!! Ako scrip-ta ne trygne !!!!!!!!
---> cat na scrip-ta [Start.Redolog.sh] i ima /tsm/EOIBPM1P/rman/Redolog.rcv

---> [oracle@sl07277]:EOIBPM1P:/tsm/EOIBPM1P# cat /tsm/EOIBPM1P/rman/Redolog.rcv
run {
  set duplex = 2;
    allocate channel t1 type 'sbt_tape' parms 'ENV=(TDPO_OPTFILE=/tsm/EOIBPM1P/conf/tdpo.opt)';
    backup
      recovery area
      not backed up 2 times
      format 'redolog_%d_%t_%T_%s_%c.rman';
    release channel t1;
}



#### Connect to catalog DB. Ако пуснем бекъп през рмана,не през каталог базата се прави бекъп и отива където трябва
     но заобикаля каталог базата и ако трябва рестор трябва да се взима от бекъпите на контролните файлове,но те се пазят само месец
	 
$ rman target / catalog rman/f9354XZS_uX@REPODG7.WORLD

$ cat /tsm/EMCF1P/rman/Redolog.rcv
run {
    set duplex = 2;
    allocate channel t1 type 'sbt_tape' parms 'ENV=(TDPO_OPTFILE=/tsm/EMCF1P/conf/tdpo.opt)';
    backup
      recovery area
      not backed up 2 times
      format 'redolog_%d_%t_%T_%s_%c.rman';
    release channel t1;
}





[6:52 AM] Naydenova, Martina Krasimirova
    
######## EON BACKUPS MANUALLY START #####################


sl03266:~ #   su - oracle


oracle@sl03266:/oracle/home/oracle> cd /oracle/backup/STRSRV1P


oracle@sl03266:/oracle/backup/STRSRV1P> ls -larth
               
oracle@sl03266:/oracle/backup/STRSRV1P> ./backup_arch.sh
 







TOVA GO PUSKAM LOCALNO PREZ RMAN
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

##### ???? ?? EON ####

rman target /
list backup



#############################
######################## HUS ###

Скриптовете за бекъпа може да сса тук,ако няма кронтаб,спецификация в ESL и ли нещо друго
/orasoft/oracle/backup
helmeilnx84t.hus.fi


########################Logista workaround ############
##Logista workaround-a backups


оказа се , че каталог базата е паднала и нямало мониторинг там та за това не сме разбрали...оправили са я

а workaround-a е:

ako backup-ite ne rabotqt kato workaround moje da se pusne ot RMAN:

RMAN>
run {
allocate channel 'dev_0' type 'sbt_tape'
parms 'SBT_LIBRARY=/opt/omni/lib/libob2oracle8_64bit.so';
send device type 'sbt_tape' 'OB2BARHOSTNAME=ra005.logista.local';
send channel 'dev_0' 'OB2BARTYPE=Oracle8';
send channel 'dev_0' 'OB2APPNAME=IWCANP';
send channel 'dev_0' 'OB2BARLIST=BCK_DC1_ORACLE_RA005_IWCANP_ARCH';
backup
format 'BCK_DC1_ORACLE_RA005_IWCANP_ARCH<IWCANP_%s:%t:%p>.dbf'
archivelog all
delete input;
}





######## Start backup UMICOR ####
/usr/openv/netbackup/scripts/Oracle/archive_log_backup_ADSP1_od.sh



######################### START BACKUP --->  MEWA ####################

Puska se prez RMAN:
rman target /

run {
allocate channel 'dev_0' type 'sbt_tape' parms 'ENV=(OB2BARTYPE=Oracle8,OB2APPNAME=AAA1,OB2BARLIST=mewa_derusdb048_ora_AAA1_arch_del)';
backup
 format 'mewa_derusdb048_ora_AAA1_arch_del<mks_%s:%t:%p>.dbf'
 archivelog all
 delete input;
} 



################## START BACKUP ----> TK - crontab (archive log backup) ########


/orabase/admin/scripts/rmanctl ECMA ARCHIVE BARLIST=TK_CORP_E43_SRV2221_ECMA_ORA_LOG   -   ORA_LOG-nakraq  ,puska se chisto nez nohup

/orabase1/admin/scripts/rmanctl PO28 ARCHIVE BARLIST=ORA_PO28_hac1117_2Disk_LOG




############### PHYSICAL STANDBY recovery_area usage full ##########
==========================================================================================

su - oracle
sqlplus / as sysdba

SQL> select database_role from v$database;

DATABASE_ROLE
----------------
PHYSICAL STANDBY


### CHECK LAST RECEIVED LAST APPLY ##

PROMPT  Last log received and last applied
select al.thread#,
        al.last_rec "Last Recd",
        la.last_app "Last Applied"
from
  (select thread#, max(sequence#) last_rec
    from v$archived_log
    group by thread#) al,
Last log received and last applied
SQL>   2    3    4    5    6    7    8    (select thread#, max(sequence#) last_app
    from v$archived_log
    where applied='YES' and registrar='RFS'
    group by thread#) la
  9   10   11   12  where al.thread#=la.thread#
and   al.thread# != 0
order by al.thread#
/
 13   14   15
   THREAD#  Last Recd Last Applied
---------- ---------- ------------
         1      96480        96480




rman target /


RMAN> delete noprompt archivelog until logseq 96475;   --------> Vinagi ostavqme pone po 5 broiki


Filesystem                              Size  Used Avail Use% Mounted on
/dev/mapper/emcf1ps_oradata-emcf1ps_ra  200G   27G  174G  14% /oracle/EMCF1PS/recovery_area
oracle@sl05822:/oracle/home/oracle>


###########################################################
###########################################################










