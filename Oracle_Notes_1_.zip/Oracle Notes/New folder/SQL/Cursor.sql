
[root@ra005 ~]# dbspicao -m31 -r1 -i IWCANP


set linesize 333
col MAX_OPEN_CUR for a15
select max(a.value) as highest_open_cur, p.value as max_open_cur
from v$sesstat a, v$statname b, v$parameter p
where a.statistic# = b.statistic#
and b.name = 'opened cursors current'
and p.name= 'open_cursors'
group by p.value;

HIGHEST_OPEN_CUR MAX_OPEN_CUR
---------------- ---------------
            1432 1500




### Може да се променя на въчно и ACTIVE или изцяло да се махне и да ви вади и двете
set linesize 200
col PROGRAM for a40
col MACHINE for a9
col username for a10
col TO_CHAR(LOGON_TIME,'YYYY/MM/DDHH24:MI:SS') for a45
select inst_id,SID,SERIAL#,STATUS,USERNAME,MACHINE,PROGRAM,to_char(LOGON_TIME, 'YYYY/MM/DD HH24:MI:SS'),LOCKWAIT
from gv$session where status='INACTIVE' order by SID; 



SQL> select SADDR, SID, USER_NAME from v$open_cursor;


SQL> select USERNAME, STATUS, OSUSER, PROGRAM from v$session;





№##### Заместваш SQL_ID
set long 20000
set pages 500
select SQL_FULLTEXT from v$sql where sql_id='gzy6vjuvv9f5c';

SQL_FULLTEXT
--------------------------------------------------------------------------------
BEGIN pkg_serv.main_loop('AUSWSRV','auswert_srv',0); END;




set linesize 400
set pages 500
col PROGRAM for a40
col MACHINE for a12
col username for a10
col TO_CHAR(LOGON_TIME,'YYYY/MM/DDHH24:MI:SS') for a45
col LOCKWAIT for a8
select sql_id,inst_id,SID,SERIAL#,STATUS,USERNAME,MACHINE,PROGRAM,to_char(LOGON_TIME, 'YYYY/MM/DD HH24:MI:SS'),LOCKWAIT from gv$session where username='INWMS'
order by inst_id, LOGON_TIME;




SQL> select SID,count(SID) from v$open_cursor group by SID;


SQL> select inst_id,SID,SERIAL#,STATUS,USERNAME,MACHINE,PROGRAM,LOGON_TIME, WAIT_TIME, LOCKWAIT, SQL_ID  from gv$session where sid in (179) ;

   INST_ID    SID    SERIAL# STATUS   USERNAME   MACHINE      PROGRAM                                  LOGON_TIM  WAIT_TIME LOCKWAIT SQL_ID
---------- ------ ---------- -------- ---------- ------------ ---------------------------------------- --------- ---------- -------- -------------
         1    179       8108 ACTIVE   INWMS      sv3124       sqlplus@sv3124 (TNS V1-V3)               13-JUL-20          0          gzy6vjuvv9f5c





SQL> ALTER SYSTEM KILL SESSION '179,8108' immediate;
ALTER SYSTEM KILL SESSION '179,8108' immediate
*
ERROR at line 1:
ORA-00031: session marked for kill


SQL> select inst_id,SID,SERIAL#,STATUS,USERNAME,MACHINE,PROGRAM,LOGON_TIME, WAIT_TIME, LOCKWAIT, SQL_ID  from gv$session where sid in (179) ;

   INST_ID    SID    SERIAL# STATUS   USERNAME   MACHINE      PROGRAM                                  LOGON_TIM  WAIT_TIME LOCKWAIT SQL_ID
---------- ------ ---------- -------- ---------- ------------ ---------------------------------------- --------- ---------- -------- -------------
         1    179      61839 ACTIVE   INWMS      sv3124       sqlplus@sv3124 (TNS V1-V3)               18-JUL-20          0          gzy6vjuvv9f5c

SQL>
