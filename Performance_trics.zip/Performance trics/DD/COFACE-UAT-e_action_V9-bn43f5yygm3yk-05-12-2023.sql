/********************************************************************************
*********       E-mail subject: COFAWEB-6492
*********             Instance: UAT
*********          Description: 
Problem:
SQL query was provided as slow from UAT.

Analysis:
The provided SQL with sql_id bn43f5yygm3yk takes more than 4 minutes on COFACE UAT.
Because of the inappropriate execution plan lot of rows were unnecessary processed, 
which makes the query execution slow.

Suggestion:
Please add hint and modify the query as it is shown in the New SQL section below.

*********               SQL_ID: bn43f5yygm3yk
*********      Program/Package: e_action v9
*********              Request: Petar Gichev 
*********               Author: Dimitar Dimitrov
********* Received e-mail date: 05/12/2023
*********      Resolution date: 05/12/2023
*********  Trace old file here: \\epox\specifs\performance\tmp\
*********  Trace new file here:
***********************************************************************************/

/********************************OLD SQL*******************************************/
var B1 VARCHAR2(128);
exec :B1 := 'AN';
var B2 VARCHAR2(128);
exec :B2 := 'AN';
var B3 VARCHAR2(128);
exec :B3 := 'AN';
var B4 VARCHAR2(128);
exec :B4 := 'AN';
var B5 VARCHAR2(128);
exec :B5 := 'categdoss';
var B6 VARCHAR2(128);
exec :B6 := 'SP';
var B7 VARCHAR2(128);
exec :B7 := 'intervenant';
var B8 VARCHAR2(128);
exec :B8 := 'AN';
var B9 VARCHAR2(128);
exec :B9 := 'SP';
var B10 VARCHAR2(128);
exec :B10 := 'INTBUPRT';
var B11 VARCHAR2(128);
exec :B11 := 'DB';
var B12 VARCHAR2(128);
exec :B12 := 'A63SKL5I';
var B13 VARCHAR2(128);
exec :B13 := 'AN';
var B14 VARCHAR2(128);
exec :B14 := 'active';
var B15 VARCHAR2(32);
exec :B15 := '6';
var B16 NUMBER;
exec :B16 := 201;
var B17 NUMBER;
exec :B17 := 1;

WITH tpncr AS
 (SELECT /*+ materialize */
   *
    FROM (SELECT /*+ no_merge(pfx) leading(pfx) use_hash(v) */
           pfx.valeur || v.valeur pfx_valeur,
           pfx.valeur || v.valeur_trad valeur_trad
            FROM (SELECT 'PB: A.' valeur, 'f' f
                    FROM dual
                  UNION ALL
                  SELECT 'PB: ' valeur, 'f' f
                    FROM dual
                  UNION ALL
                  SELECT 'A.' valeur, 'f' f
                    FROM dual
                  UNION ALL
                  SELECT '' valeur, 'f' f
                    FROM dual) pfx,
                 (SELECT /*+ no_merge no_push_pred */
                   valeur, valeur_trad, 'f' f
                    FROM v_tdomaine
                   WHERE type = 'typencour'
                     AND langue = :B1) v
           WHERE v.f = pfx.f) fooo
   WHERE 1 = 1)
SELECT *
  FROM (SELECT /*+ first_rows(201)*/
         foo.*, ROWNUM rnum
          FROM (SELECT (SELECT CMI.nom
                          FROM g_individu CMI, g_personnel CMP
                         WHERE CMP.refperso = D.rangmt
                           AND CMI.refindividu = CMP.refindividu
                           AND rownum = 1) caseManagerDisplay,
                       D.dtfingest_dt managementEndDate,
                       D.rangmt caseManager,
                       ATT.typencour caseStatus,
                       ATT.dtdeclench_dt dueDate,
                       (SELECT DECODE(COUNT(*), 0, 'false', 'true')
                          FROM DUAL
                         WHERE EXISTS
                         (SELECT 1
                                  FROM t_element_se
                                 WHERE refdoss = D.refdoss
                                   AND libelle IN
                                       (SELECT vt.valeur
                                          FROM v_domaine vt, v_domaine vf
                                         WHERE vt.type = 'typencour'
                                           AND vf.abrev16 = 'O'
                                           AND vf.type = 'filiere'
                                           AND vf.ecran = vt.abrev))) forbProcessFound,
                       (SELECT SMI.nom
                          FROM g_individu SMI, g_personnel SMP
                         WHERE SMP.refperso = ATT.catperso
                           AND SMI.refindividu = SMP.refindividu
                           AND rownum = 1) statusManagerDisplay,
                       D.refdoss internalCaseReference,
                       IDB.nom debtor,
                       D.soldedb caseBalance,
                       ICL.nom client,
                       (SELECT tpncr.valeur_trad
                          FROM tpncr
                         WHERE tpncr.pfx_valeur = ATT.typencour) caseStatusDisplay,
                       D.devise caseCurrency,
                       IMX.get_valeur('TYPE_MANDAT', D.typeOfMandate, :B2) typeOfMandate,
                       IMX.get_valeur('PHASE', D.phase, :B3) phase,
                       D.reflot_dos reflot_dos,
                       ATT.catperso statusManager,
                       D.pieceinit product,
                       D.ancrefdoss externalCaseReference,
                       IDB.siret debtorNrn,
                       D.initialAmount initialAmount,
                       (SELECT IMX.transl_valeur('piece', D.pieceinit, :B4)
                          FROM dual) productDisplay,
                       (count(D.refdoss) OVER()) totalRealCases,
                       D.caseManagerSu caseManagerSu,
                       (SUM(D.soldedb) OVER()) sumBalanceReal
                  FROM (SELECT D.rangmt,
                               D.ancrefdoss,
                               D.refdoss,
                               D.devise,
                               D.soldedb,
                               D.soldedb_dos,
                               D.dtfingest_dt,
                               D.reflot_dos,
                               D.reflot,
                               D.principal,
                               D.segment,
                               D.pieceinit,
                               D.monref,
                               D.dt_dt_dt,
                               D.dtcreation_dt,
                               D.categdoss,
                               D.stratif,
                               D.dt_dechterm_dt,
                               (SELECT ISU.nom
                                  FROM g_personnel PSU, g_individu ISU
                                 WHERE PSU.refperso = D.monref
                                   AND ISU.refindividu = PSU.refindividu) as caseManagerSu,
                               D.phase phase,
                               (SELECT SUM(FI.montant)
                                  FROM g_elemfi FI
                                 WHERE FI.refdoss = D.refdoss
                                   AND ((D.mig_reference IS NULL AND
                                       TRUNC(dtjour_dt) =
                                       NVL(TRUNC(D.dtcreation_dt),
                                             TRUNC(D.dt_dt_dt))) OR
                                       (D.mig_reference IS NOT NULL AND
                                       FI.createur = 'cfc_migration'))) as initialAmount,
                               (SELECT st24
                                  FROM g_piece
                                 WHERE refdoss = D.refdoss
                                   AND typpiece = 'RECOUVREMENT'
                                   AND ROWNUM = 1) as typeOfMandate,
                               (select decode((select count(*) flag_true
                                                from (select nvl(max(FG_INCL_NOT_DUE_ELEM_CASE_BAL),
                                                                 'N') flag
                                                        from g_bu
                                                       where refindividu =
                                                             (select refindividu
                                                                from t_intervenants
                                                               where refdoss =
                                                                     D.refdoss
                                                                 and reftype = 'BU')) g_bu_flag,
                                                     (select nvl(max(FG_TREAT_ALL_ELEMENTS_AS_DUE),
                                                                 'N') flag
                                                        from g_dossier
                                                       where refdoss = D.refdoss) g_doss_flag
                                               where g_bu_flag.flag = 'N'
                                                 and g_doss_flag.flag = 'N'),
                                              0,
                                              (select sum(nvl(mt_ouvert_mvt,
                                                              montant_dos))
                                                 from g_elemfi
                                                where refdoss = D.refdoss
                                                  and dtdebut <
                                                      to_char(sysdate, 'j')),
                                              (select cpt_util.getPostSum(D.refdoss,
                                                                          'SOLDEDB',
                                                                          (select dt_dt
                                                                             from g_dossier
                                                                            where refdoss =
                                                                                  D.refdoss),
                                                                          'ECR',
                                                                          'DOS')
                                                 from dual))
                                  from dual) AS totalAmtDebt
                          FROM g_dossier D
                         WHERE 1 = 1) D,
                       t_intervenants TDB,
                       g_individu IDB,
                       t_intervenants TCL,
                       g_individu ICL,
                       t_attente ATT,
                       (SELECT /*+ cardinality(T 0) */
                        DISTINCT gd.refdoss
                          FROM t_intervenants T, g_dossier GD
                         WHERE 1 = 1
                           AND T.reftype <> 'XX'
                           AND GD.refdoss = T.refdoss
                           AND (EXISTS
                                (SELECT 1
                                   FROM v_intervenants
                                  WHERE (categdoss =
                                        (SELECT abrev
                                            FROM v_domaine
                                           WHERE valeur = GD.categdoss
                                             AND TYPE = :B5) OR categdoss IS NULL)
                                    AND reftype_bd = t.reftype
                                    AND reftype_aff LIKE :B6) OR EXISTS
                                (SELECT 1
                                   FROM v_tdomaine
                                  WHERE type = :B7
                                    AND langue = :B8
                                    AND abrev_trad LIKE :B9
                                    AND abrev = T.reftype))
                           AND t.refindividu = :B10) DF
                 WHERE 1 = 1
                   AND TDB.refdoss(+) = D.refdoss
                   AND IDB.refindividu(+) = TDB.refindividu
                   AND TDB.reftype(+) = :B11
                   AND TCL.refdoss(+) = D.refdoss
                   AND ICL.refindividu(+) = TCL.refindividu
                   AND ATT.refentite = D.refdoss
                   AND tcl.reftype(+) = 'CL'
                   AND d.refdoss = DF.refdoss
                   AND (idb.str36 IS NULL OR EXISTS
                        (SELECT 1
                           FROM g_indivparam
                          WHERE refindividu = :B12
                            AND type = 'type_indiv'
                            AND str1 = idb.str36))
                   AND EXISTS (SELECT 1
                          FROM v_tdomaine
                         WHERE type = 'STRAT'
                           AND langue = :B3
                           AND abrev = d.stratif
                           AND valeur_trad LIKE :B14)
                   AND typeOfMandate = :B15
                 ORDER BY D.refdoss, D.refdoss) foo
         WHERE ROWNUM <= :B16)
 WHERE 1 = 1
   AND rnum >= :B17;
/********************************OLD SQL*******************************************/
/********************************OLD Metrics***************************************/
/*
Plan hash value: 172206395
--------------------------------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                            | Name                        | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  |
--------------------------------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                                     |                             |      1 |        |  5431K(100)|    151 |00:04:23.79 |    6571K|    714K|
|*  1 |  COUNT STOPKEY                                       |                             |      4 |        |            |      4 |00:00:00.01 |      28 |   2 |
|   2 |   NESTED LOOPS                                       |                             |      4 |      1 |     2   (0)|      4 |00:00:00.01 |      28 |   2 |
|   3 |    NESTED LOOPS                                      |                             |      4 |      1 |     2   (0)|      4 |00:00:00.01 |      24 |   1 |
|   4 |     TABLE ACCESS BY INDEX ROWID BATCHED              | G_PERSONNEL                 |      4 |      1 |     1   (0)|      4 |00:00:00.01 |      12 |   1 |
|*  5 |      INDEX RANGE SCAN                                | PK_G_PERSONNEL              |      4 |      1 |     1   (0)|      4 |00:00:00.01 |       8 |   0 |
|*  6 |     INDEX UNIQUE SCAN                                | IND_REFINDIV                |      4 |      1 |     1   (0)|      4 |00:00:00.01 |      12 |   0 |
|   7 |    TABLE ACCESS BY INDEX ROWID                       | G_INDIVIDU                  |      4 |      1 |     1   (0)|      4 |00:00:00.01 |       4 |   1 |
|   8 |  SORT AGGREGATE                                      |                             |    151 |      1 |            |    151 |00:00:00.21 |   11313 |    200 |
|*  9 |   FILTER                                             |                             |    151 |        |            |      0 |00:00:00.21 |   11313 |    200 |
|  10 |    FAST DUAL                                         |                             |    151 |      1 |     2   (0)|    151 |00:00:00.01 |       0 |   0 |
|  11 |    NESTED LOOPS                                      |                             |    151 |      1 |     3   (0)|      0 |00:00:00.21 |   11313 |    200 |
|  12 |     MERGE JOIN CARTESIAN                             |                             |    151 |      1 |     2   (0)|    226 |00:00:00.20 |   11154 |    199 |
|* 13 |      TABLE ACCESS BY INDEX ROWID BATCHED             | V_DOMAINE                   |    151 |      1 |     1   (0)|    151 |00:00:00.02 |   10580 |   0 |
|* 14 |       INDEX RANGE SCAN                               | V_DOMAINE_TYPE_CODE_IDX     |    151 |     77 |     1   (0)|   8909 |00:00:00.01 |     161 |   0 |
|  15 |      BUFFER SORT                                     |                             |    151 |      2 |     1   (0)|    226 |00:00:00.18 |     574 |    199 |
|  16 |       TABLE ACCESS BY INDEX ROWID BATCHED            | T_ELEMENT_SE                |    151 |      2 |     1   (0)|    226 |00:00:00.18 |     574 |    199 |
|* 17 |        INDEX RANGE SCAN                              | ELESE_DOSELEM               |    151 |      2 |     1   (0)|    226 |00:00:00.10 |     419 |  96 |
|* 18 |     INDEX RANGE SCAN                                 | DOM_TYPABREV                |    226 |      1 |     1   (0)|      0 |00:00:00.01 |     159 |   1 |
|* 19 |  COUNT STOPKEY                                       |                             |      5 |        |            |      5 |00:00:00.01 |      35 |   0 |
|  20 |   NESTED LOOPS                                       |                             |      5 |      1 |     2   (0)|      5 |00:00:00.01 |      35 |   0 |
|  21 |    NESTED LOOPS                                      |                             |      5 |      1 |     2   (0)|      5 |00:00:00.01 |      30 |   0 |
|  22 |     TABLE ACCESS BY INDEX ROWID BATCHED              | G_PERSONNEL                 |      5 |      1 |     1   (0)|      5 |00:00:00.01 |      15 |   0 |
|* 23 |      INDEX RANGE SCAN                                | PK_G_PERSONNEL              |      5 |      1 |     1   (0)|      5 |00:00:00.01 |      10 |   0 |
|* 24 |     INDEX UNIQUE SCAN                                | IND_REFINDIV                |      5 |      1 |     1   (0)|      5 |00:00:00.01 |      15 |   0 |
|  25 |    TABLE ACCESS BY INDEX ROWID                       | G_INDIVIDU                  |      5 |      1 |     1   (0)|      5 |00:00:00.01 |       5 |   0 |
|* 26 |  VIEW                                                |                             |     28 |      1 |     1   (0)|     28 |00:00:00.02 |       0 |   0 |
|  27 |   TABLE ACCESS FULL                                  | SYS_TEMP_0FD9E015B_D8F21C32 |     28 |    114 |     5   (0)|    123K|00:00:00.01 |       0 |   0 |
|* 28 |  COUNT STOPKEY                                       |                             |    545K|        |            |    406K|00:01:26.24 |    2459K|    166K|
|  29 |   TABLE ACCESS BY INDEX ROWID BATCHED                | G_PIECE                     |    545K|      1 |     1   (0)|    406K|00:01:25.08 |    2459K|    166K|
|* 30 |    INDEX RANGE SCAN                                  | PIE_REFDOSS                 |    545K|      1 |     1   (0)|    406K|00:00:34.20 |    1608K|  64319 |
|  31 |  SORT AGGREGATE                                      |                             |    545K|      1 |            |    545K|00:01:49.76 |    2388K|    257K|
|* 32 |   TABLE ACCESS BY INDEX ROWID BATCHED                | G_ELEMFI                    |    545K|      1 |     1   (0)|   2542K|00:01:48.32 |    2388K|    257K|
|* 33 |    INDEX RANGE SCAN                                  | EFI_DOS_DTEMIS_TYPE         |    545K|      8 |     1   (0)|   3281K|00:00:17.54 |     863K|  32140 |
|  34 |  FAST DUAL                                           |                             |      1 |      1 |     2   (0)|      1 |00:00:00.01 |       0 |   0 |
|  35 |  NESTED LOOPS                                        |                             |    131K|      1 |     2   (0)|    131K|00:00:02.42 |     403K|    134 |
|  36 |   NESTED LOOPS                                       |                             |    131K|      1 |     2   (0)|    131K|00:00:01.74 |     304K|  88 |
|  37 |    TABLE ACCESS BY INDEX ROWID BATCHED               | G_PERSONNEL                 |    131K|      1 |     1   (0)|    131K|00:00:01.11 |     166K|  49 |
|* 38 |     INDEX RANGE SCAN                                 | PK_G_PERSONNEL              |    131K|      1 |     1   (0)|    131K|00:00:00.60 |   60820 |   7 |
|* 39 |    INDEX UNIQUE SCAN                                 | IND_REFINDIV                |    131K|      1 |     1   (0)|    131K|00:00:00.47 |     138K|  39 |
|  40 |   TABLE ACCESS BY INDEX ROWID                        | G_INDIVIDU                  |    131K|      1 |     1   (0)|    131K|00:00:00.49 |   99172 |  46 |
|  41 |  TEMP TABLE TRANSFORMATION                           |                             |      1 |        |            |    151 |00:04:23.79 |    6571K|    714K|
|  42 |   LOAD AS SELECT (CURSOR DURATION MEMORY)            | SYS_TEMP_0FD9E015B_D8F21C32 |      1 |        |            |      0 |00:00:00.08 |     198 |  81 |
|* 43 |    HASH JOIN                                         |                             |      1 |    114 |    45   (0)|   4396 |00:00:00.07 |     197 |  81 |
|  44 |     VIEW                                             |                             |      1 |      4 |     8   (0)|      4 |00:00:00.01 |       0 |   0 |
|  45 |      UNION-ALL                                       |                             |      1 |        |            |      4 |00:00:00.01 |       0 |   0 |
|  46 |       FAST DUAL                                      |                             |      1 |      1 |     2   (0)|      1 |00:00:00.01 |       0 |   0 |
|  47 |       FAST DUAL                                      |                             |      1 |      1 |     2   (0)|      1 |00:00:00.01 |       0 |   0 |
|  48 |       FAST DUAL                                      |                             |      1 |      1 |     2   (0)|      1 |00:00:00.01 |       0 |   0 |
|  49 |       FAST DUAL                                      |                             |      1 |      1 |     2   (0)|      1 |00:00:00.01 |       0 |   0 |
|  50 |     VIEW                                             |                             |      1 |   2849 |    37   (0)|   1099 |00:00:00.07 |     197 |  81 |
|  51 |      VIEW                                            | V_TDOMAINE                  |      1 |   2849 |    37   (0)|   1099 |00:00:00.07 |     197 |  81 |
|  52 |       UNION-ALL                                      |                             |      1 |        |            |   1099 |00:00:00.07 |     197 |  81 |
|* 53 |        FILTER                                        |                             |      1 |        |            |      0 |00:00:00.01 |       0 |   0 |
|  54 |         TABLE ACCESS BY INDEX ROWID BATCHED          | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|* 55 |          INDEX RANGE SCAN                            | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|* 56 |        FILTER                                        |                             |      1 |        |            |   1099 |00:00:00.07 |     197 |  81 |
|  57 |         TABLE ACCESS BY INDEX ROWID BATCHED          | V_DOMAINE                   |      1 |     77 |     1   (0)|   1099 |00:00:00.07 |     197 |  81 |
|* 58 |          INDEX RANGE SCAN                            | V_DOMAINE_TYPE_CODE_IDX     |      1 |     77 |     1   (0)|   1099 |00:00:00.01 |      17 |   7 |
|* 59 |        FILTER                                        |                             |      1 |        |            |      0 |00:00:00.01 |       0 |   0 |
|  60 |         TABLE ACCESS BY INDEX ROWID BATCHED          | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|* 61 |          INDEX RANGE SCAN                            | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|* 62 |        FILTER                                        |                             |      1 |        |            |      0 |00:00:00.01 |       0 |   0 |
|  63 |         TABLE ACCESS BY INDEX ROWID BATCHED          | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|* 64 |          INDEX RANGE SCAN                            | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|* 65 |        FILTER                                        |                             |      1 |        |            |      0 |00:00:00.01 |       0 |   0 |
|  66 |         TABLE ACCESS BY INDEX ROWID BATCHED          | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|* 67 |          INDEX RANGE SCAN                            | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|* 68 |        FILTER                                        |                             |      1 |        |            |      0 |00:00:00.01 |       0 |   0 |
|  69 |         TABLE ACCESS BY INDEX ROWID BATCHED          | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|* 70 |          INDEX RANGE SCAN                            | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|* 71 |        FILTER                                        |                             |      1 |        |            |      0 |00:00:00.01 |       0 |   0 |
|  72 |         TABLE ACCESS BY INDEX ROWID BATCHED          | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|* 73 |          INDEX RANGE SCAN                            | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|* 74 |        FILTER                                        |                             |      1 |        |            |      0 |00:00:00.01 |       0 |   0 |
|  75 |         TABLE ACCESS BY INDEX ROWID BATCHED          | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|* 76 |          INDEX RANGE SCAN                            | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|* 77 |        FILTER                                        |                             |      1 |        |            |      0 |00:00:00.01 |       0 |   0 |
|  78 |         TABLE ACCESS BY INDEX ROWID BATCHED          | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|* 79 |          INDEX RANGE SCAN                            | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|* 80 |        FILTER                                        |                             |      1 |        |            |      0 |00:00:00.01 |       0 |   0 |
|  81 |         TABLE ACCESS BY INDEX ROWID BATCHED          | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|* 82 |          INDEX RANGE SCAN                            | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|* 83 |        FILTER                                        |                             |      1 |        |            |      0 |00:00:00.01 |       0 |   0 |
|  84 |         TABLE ACCESS BY INDEX ROWID BATCHED          | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|* 85 |          INDEX RANGE SCAN                            | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|* 86 |        FILTER                                        |                             |      1 |        |            |      0 |00:00:00.01 |       0 |   0 |
|  87 |         TABLE ACCESS BY INDEX ROWID BATCHED          | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|* 88 |          INDEX RANGE SCAN                            | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|* 89 |        FILTER                                        |                             |      1 |        |            |      0 |00:00:00.01 |       0 |   0 |
|  90 |         TABLE ACCESS BY INDEX ROWID BATCHED          | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|* 91 |          INDEX RANGE SCAN                            | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|* 92 |        FILTER                                        |                             |      1 |        |            |      0 |00:00:00.01 |       0 |   0 |
|  93 |         TABLE ACCESS BY INDEX ROWID BATCHED          | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|* 94 |          INDEX RANGE SCAN                            | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|* 95 |        FILTER                                        |                             |      1 |        |            |      0 |00:00:00.01 |       0 |   0 |
|  96 |         TABLE ACCESS BY INDEX ROWID BATCHED          | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|* 97 |          INDEX RANGE SCAN                            | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|* 98 |        FILTER                                        |                             |      1 |        |            |      0 |00:00:00.01 |       0 |   0 |
|  99 |         TABLE ACCESS BY INDEX ROWID BATCHED          | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|*100 |          INDEX RANGE SCAN                            | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|*101 |        FILTER                                        |                             |      1 |        |            |      0 |00:00:00.01 |       0 |   0 |
| 102 |         TABLE ACCESS BY INDEX ROWID BATCHED          | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|*103 |          INDEX RANGE SCAN                            | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|*104 |        FILTER                                        |                             |      1 |        |            |      0 |00:00:00.01 |       0 |   0 |
| 105 |         TABLE ACCESS BY INDEX ROWID BATCHED          | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|*106 |          INDEX RANGE SCAN                            | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|*107 |        FILTER                                        |                             |      1 |        |            |      0 |00:00:00.01 |       0 |   0 |
| 108 |         TABLE ACCESS BY INDEX ROWID BATCHED          | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|*109 |          INDEX RANGE SCAN                            | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|*110 |        FILTER                                        |                             |      1 |        |            |      0 |00:00:00.01 |       0 |   0 |
| 111 |         TABLE ACCESS BY INDEX ROWID BATCHED          | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|*112 |          INDEX RANGE SCAN                            | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|*113 |        FILTER                                        |                             |      1 |        |            |      0 |00:00:00.01 |       0 |   0 |
| 114 |         TABLE ACCESS BY INDEX ROWID BATCHED          | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|*115 |          INDEX RANGE SCAN                            | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|*116 |        FILTER                                        |                             |      1 |        |            |      0 |00:00:00.01 |       0 |   0 |
| 117 |         TABLE ACCESS BY INDEX ROWID BATCHED          | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|*118 |          INDEX RANGE SCAN                            | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|*119 |        FILTER                                        |                             |      1 |        |            |      0 |00:00:00.01 |       0 |   0 |
| 120 |         TABLE ACCESS BY INDEX ROWID BATCHED          | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|*121 |          INDEX RANGE SCAN                            | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|*122 |        FILTER                                        |                             |      1 |        |            |      0 |00:00:00.01 |       0 |   0 |
| 123 |         TABLE ACCESS BY INDEX ROWID BATCHED          | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|*124 |          INDEX RANGE SCAN                            | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|*125 |        FILTER                                        |                             |      1 |        |            |      0 |00:00:00.01 |       0 |   0 |
| 126 |         TABLE ACCESS BY INDEX ROWID BATCHED          | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|*127 |          INDEX RANGE SCAN                            | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|*128 |        FILTER                                        |                             |      1 |        |            |      0 |00:00:00.01 |       0 |   0 |
| 129 |         TABLE ACCESS BY INDEX ROWID BATCHED          | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|*130 |          INDEX RANGE SCAN                            | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|*131 |        FILTER                                        |                             |      1 |        |            |      0 |00:00:00.01 |       0 |   0 |
| 132 |         TABLE ACCESS BY INDEX ROWID BATCHED          | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|*133 |          INDEX RANGE SCAN                            | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|*134 |        FILTER                                        |                             |      1 |        |            |      0 |00:00:00.01 |       0 |   0 |
| 135 |         TABLE ACCESS BY INDEX ROWID BATCHED          | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|*136 |          INDEX RANGE SCAN                            | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|*137 |        FILTER                                        |                             |      1 |        |            |      0 |00:00:00.01 |       0 |   0 |
| 138 |         TABLE ACCESS BY INDEX ROWID BATCHED          | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|*139 |          INDEX RANGE SCAN                            | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|*140 |        FILTER                                        |                             |      1 |        |            |      0 |00:00:00.01 |       0 |   0 |
| 141 |         TABLE ACCESS BY INDEX ROWID BATCHED          | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|*142 |          INDEX RANGE SCAN                            | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|*143 |        FILTER                                        |                             |      1 |        |            |      0 |00:00:00.01 |       0 |   0 |
| 144 |         TABLE ACCESS BY INDEX ROWID BATCHED          | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|*145 |          INDEX RANGE SCAN                            | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|*146 |        FILTER                                        |                             |      1 |        |            |      0 |00:00:00.01 |       0 |   0 |
| 147 |         TABLE ACCESS BY INDEX ROWID BATCHED          | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|*148 |          INDEX RANGE SCAN                            | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|*149 |        FILTER                                        |                             |      1 |        |            |      0 |00:00:00.01 |       0 |   0 |
| 150 |         TABLE ACCESS BY INDEX ROWID BATCHED          | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|*151 |          INDEX RANGE SCAN                            | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|*152 |        FILTER                                        |                             |      1 |        |            |      0 |00:00:00.01 |       0 |   0 |
| 153 |         TABLE ACCESS BY INDEX ROWID BATCHED          | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|*154 |          INDEX RANGE SCAN                            | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|*155 |        FILTER                                        |                             |      1 |        |            |      0 |00:00:00.01 |       0 |   0 |
| 156 |         TABLE ACCESS BY INDEX ROWID BATCHED          | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|*157 |          INDEX RANGE SCAN                            | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|*158 |        FILTER                                        |                             |      1 |        |            |      0 |00:00:00.01 |       0 |   0 |
| 159 |         TABLE ACCESS BY INDEX ROWID BATCHED          | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|*160 |          INDEX RANGE SCAN                            | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|*161 |        FILTER                                        |                             |      1 |        |            |      0 |00:00:00.01 |       0 |   0 |
| 162 |         TABLE ACCESS BY INDEX ROWID BATCHED          | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|*163 |          INDEX RANGE SCAN                            | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|*164 |   VIEW                                               |                             |      1 |      1 |  5431K  (1)|    151 |00:04:23.71 |    6571K|    714K|
|*165 |    COUNT STOPKEY                                     |                             |      1 |        |            |    151 |00:04:23.71 |    6571K|    714K|
| 166 |     VIEW                                             |                             |      1 |      1 |  5431K  (1)|    151 |00:04:23.71 |    6571K|    714K|
| 167 |      WINDOW SORT                                     |                             |      1 |      1 |  5431K  (1)|    151 |00:04:23.31 |    6554K|    714K|
|*168 |       FILTER                                         |                             |      1 |        |            |    151 |00:04:23.31 |    6554K|    714K|
| 169 |        NESTED LOOPS SEMI                             |                             |      1 |      1 |  5431K  (1)|    151 |00:04:23.31 |    6554K|    714K|
| 170 |         NESTED LOOPS OUTER                           |                             |      1 |      1 |  5431K  (1)|    538 |00:04:23.27 |    6552K|    714K|
| 171 |          NESTED LOOPS OUTER                          |                             |      1 |      1 |  5431K  (1)|    538 |00:04:23.25 |    6551K|    714K|
| 172 |           NESTED LOOPS                               |                             |      1 |      1 |  5431K  (1)|    538 |00:04:21.97 |    6549K|    713K|
| 173 |            NESTED LOOPS OUTER                        |                             |      1 |      1 |  5431K  (1)|    538 |00:04:21.53 |    6548K|    712K|
| 174 |             NESTED LOOPS OUTER                       |                             |      1 |      1 |  5431K  (1)|    538 |00:04:21.52 |    6547K|    712K|
|*175 |              HASH JOIN                               |                             |      1 |      1 |  5431K  (1)|    538 |00:04:21.40 |    6546K|    712K|
| 176 |               VIEW                                   | V_TDOMAINE                  |      1 |     40 |    37   (0)|      1 |00:00:00.01 |      12 |   4 |
| 177 |                HASH UNIQUE                           |                             |      1 |      1 |    37   (0)|      1 |00:00:00.01 |      12 |   4 |
| 178 |                 UNION-ALL                            |                             |      1 |        |            |      1 |00:00:00.01 |      12 |   4 |
|*179 |                  FILTER                              |                             |      1 |        |            |      0 |00:00:00.01 |       0 |   0 |
|*180 |                   TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|*181 |                    INDEX RANGE SCAN                  | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|*182 |                  FILTER                              |                             |      1 |        |            |      1 |00:00:00.01 |      12 |   4 |
|*183 |                   TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE                   |      1 |      1 |     1   (0)|      1 |00:00:00.01 |      12 |   4 |
|*184 |                    INDEX RANGE SCAN                  | V_DOMAINE_TYPE_CODE_IDX     |      1 |     77 |     1   (0)|      5 |00:00:00.01 |       3 |   1 |
|*185 |                  FILTER                              |                             |      1 |        |            |      0 |00:00:00.01 |       0 |   0 |
|*186 |                   TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|*187 |                    INDEX RANGE SCAN                  | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|*188 |                  FILTER                              |                             |      1 |        |            |      0 |00:00:00.01 |       0 |   0 |
|*189 |                   TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|*190 |                    INDEX RANGE SCAN                  | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|*191 |                  FILTER                              |                             |      1 |        |            |      0 |00:00:00.01 |       0 |   0 |
|*192 |                   TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|*193 |                    INDEX RANGE SCAN                  | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|*194 |                  FILTER                              |                             |      1 |        |            |      0 |00:00:00.01 |       0 |   0 |
|*195 |                   TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|*196 |                    INDEX RANGE SCAN                  | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|*197 |                  FILTER                              |                             |      1 |        |            |      0 |00:00:00.01 |       0 |   0 |
|*198 |                   TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|*199 |                    INDEX RANGE SCAN                  | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|*200 |                  FILTER                              |                             |      1 |        |            |      0 |00:00:00.01 |       0 |   0 |
|*201 |                   TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|*202 |                    INDEX RANGE SCAN                  | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|*203 |                  FILTER                              |                             |      1 |        |            |      0 |00:00:00.01 |       0 |   0 |
|*204 |                   TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|*205 |                    INDEX RANGE SCAN                  | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|*206 |                  FILTER                              |                             |      1 |        |            |      0 |00:00:00.01 |       0 |   0 |
|*207 |                   TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|*208 |                    INDEX RANGE SCAN                  | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|*209 |                  FILTER                              |                             |      1 |        |            |      0 |00:00:00.01 |       0 |   0 |
|*210 |                   TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|*211 |                    INDEX RANGE SCAN                  | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|*212 |                  FILTER                              |                             |      1 |        |            |      0 |00:00:00.01 |       0 |   0 |
|*213 |                   TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|*214 |                    INDEX RANGE SCAN                  | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|*215 |                  FILTER                              |                             |      1 |        |            |      0 |00:00:00.01 |       0 |   0 |
|*216 |                   TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|*217 |                    INDEX RANGE SCAN                  | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|*218 |                  FILTER                              |                             |      1 |        |            |      0 |00:00:00.01 |       0 |   0 |
|*219 |                   TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|*220 |                    INDEX RANGE SCAN                  | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|*221 |                  FILTER                              |                             |      1 |        |            |      0 |00:00:00.01 |       0 |   0 |
|*222 |                   TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE                   |      0 |      4 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|*223 |                    INDEX RANGE SCAN                  | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|*224 |                  FILTER                              |                             |      1 |        |            |      0 |00:00:00.01 |       0 |   0 |
|*225 |                   TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|*226 |                    INDEX RANGE SCAN                  | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|*227 |                  FILTER                              |                             |      1 |        |            |      0 |00:00:00.01 |       0 |   0 |
|*228 |                   TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|*229 |                    INDEX RANGE SCAN                  | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|*230 |                  FILTER                              |                             |      1 |        |            |      0 |00:00:00.01 |       0 |   0 |
|*231 |                   TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|*232 |                    INDEX RANGE SCAN                  | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|*233 |                  FILTER                              |                             |      1 |        |            |      0 |00:00:00.01 |       0 |   0 |
|*234 |                   TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|*235 |                    INDEX RANGE SCAN                  | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|*236 |                  FILTER                              |                             |      1 |        |            |      0 |00:00:00.01 |       0 |   0 |
|*237 |                   TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|*238 |                    INDEX RANGE SCAN                  | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|*239 |                  FILTER                              |                             |      1 |        |            |      0 |00:00:00.01 |       0 |   0 |
|*240 |                   TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|*241 |                    INDEX RANGE SCAN                  | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|*242 |                  FILTER                              |                             |      1 |        |            |      0 |00:00:00.01 |       0 |   0 |
|*243 |                   TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|*244 |                    INDEX RANGE SCAN                  | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|*245 |                  FILTER                              |                             |      1 |        |            |      0 |00:00:00.01 |       0 |   0 |
|*246 |                   TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|*247 |                    INDEX RANGE SCAN                  | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|*248 |                  FILTER                              |                             |      1 |        |            |      0 |00:00:00.01 |       0 |   0 |
|*249 |                   TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|*250 |                    INDEX RANGE SCAN                  | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|*251 |                  FILTER                              |                             |      1 |        |            |      0 |00:00:00.01 |       0 |   0 |
|*252 |                   TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|*253 |                    INDEX RANGE SCAN                  | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|*254 |                  FILTER                              |                             |      1 |        |            |      0 |00:00:00.01 |       0 |   0 |
|*255 |                   TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|*256 |                    INDEX RANGE SCAN                  | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|*257 |                  FILTER                              |                             |      1 |        |            |      0 |00:00:00.01 |       0 |   0 |
|*258 |                   TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|*259 |                    INDEX RANGE SCAN                  | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|*260 |                  FILTER                              |                             |      1 |        |            |      0 |00:00:00.01 |       0 |   0 |
|*261 |                   TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|*262 |                    INDEX RANGE SCAN                  | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|*263 |                  FILTER                              |                             |      1 |        |            |      0 |00:00:00.01 |       0 |   0 |
|*264 |                   TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|*265 |                    INDEX RANGE SCAN                  | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|*266 |                  FILTER                              |                             |      1 |        |            |      0 |00:00:00.01 |       0 |   0 |
|*267 |                   TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|*268 |                    INDEX RANGE SCAN                  | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|*269 |                  FILTER                              |                             |      1 |        |            |      0 |00:00:00.01 |       0 |   0 |
|*270 |                   TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|*271 |                    INDEX RANGE SCAN                  | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|*272 |                  FILTER                              |                             |      1 |        |            |      0 |00:00:00.01 |       0 |   0 |
|*273 |                   TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|*274 |                    INDEX RANGE SCAN                  | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|*275 |                  FILTER                              |                             |      1 |        |            |      0 |00:00:00.01 |       0 |   0 |
|*276 |                   TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|*277 |                    INDEX RANGE SCAN                  | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|*278 |                  FILTER                              |                             |      1 |        |            |      0 |00:00:00.01 |       0 |   0 |
|*279 |                   TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|*280 |                    INDEX RANGE SCAN                  | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|*281 |                  FILTER                              |                             |      1 |        |            |      0 |00:00:00.01 |       0 |   0 |
|*282 |                   TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|*283 |                    INDEX RANGE SCAN                  | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|*284 |                  FILTER                              |                             |      1 |        |            |      0 |00:00:00.01 |       0 |   0 |
|*285 |                   TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|*286 |                    INDEX RANGE SCAN                  | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|*287 |                  FILTER                              |                             |      1 |        |            |      0 |00:00:00.01 |       0 |   0 |
|*288 |                   TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|*289 |                    INDEX RANGE SCAN                  | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|*290 |               VIEW                                   |                             |      1 |    545K|  5431K  (1)|   8119 |00:04:21.38 |    6546K|    712K|
| 291 |                TABLE ACCESS FULL                     | G_DOSSIER                   |      1 |    545K| 20533   (1)|    545K|00:01:00.69 |    1293K|    288K|
|*292 |              INDEX RANGE SCAN                        | INT_REFDOSS                 |    538 |      1 |     1   (0)|    537 |00:00:00.13 |    1047 |    190 |
|*293 |             INDEX RANGE SCAN                         | INT_REFDOSS                 |    538 |      1 |     1   (0)|    538 |00:00:00.01 |    1047 |   0 |
| 294 |            TABLE ACCESS BY INDEX ROWID BATCHED       | T_ATTENTE                   |    538 |      1 |     1   (0)|    538 |00:00:00.44 |    1427 |    567 |
|*295 |             INDEX RANGE SCAN                         | PK_ATTENTE                  |    538 |      1 |     1   (0)|    538 |00:00:00.24 |    1007 |    274 |
| 296 |           TABLE ACCESS BY INDEX ROWID                | G_INDIVIDU                  |    538 |      1 |     1   (0)|    537 |00:00:01.29 |    2230 |   1087 |
|*297 |            INDEX UNIQUE SCAN                         | IND_REFINDIV                |    538 |      1 |     1   (0)|    537 |00:00:00.54 |    1076 |    480 |
| 298 |          TABLE ACCESS BY INDEX ROWID                 | G_INDIVIDU                  |    538 |      1 |     1   (0)|    538 |00:00:00.02 |     536 |  11 |
|*299 |           INDEX UNIQUE SCAN                          | IND_REFINDIV                |    538 |      1 |     1   (0)|    538 |00:00:00.01 |     337 |   2 |
| 300 |         VIEW PUSHED PREDICATE                        |                             |    538 |      1 |     5   (0)|    151 |00:00:00.04 |    2550 |  65 |
|*301 |          FILTER                                      |                             |    538 |        |            |    151 |00:00:00.04 |    2550 |  65 |
| 302 |           NESTED LOOPS                               |                             |    538 |      1 |     2   (0)|    305 |00:00:00.03 |    2528 |  59 |
| 303 |            TABLE ACCESS BY INDEX ROWID               | G_DOSSIER                   |    538 |      1 |     1   (0)|    538 |00:00:00.02 |    1460 |  49 |
|*304 |             INDEX UNIQUE SCAN                        | DOS_REFDOSS                 |    538 |      1 |     1   (0)|    538 |00:00:00.01 |    1021 |   0 |
|*305 |            INDEX RANGE SCAN                          | INT_REFDOSS                 |    538 |      1 |     1   (0)|    305 |00:00:00.01 |    1068 |  10 |
|*306 |           FILTER                                     |                             |      2 |        |            |      0 |00:00:00.01 |      14 |   6 |
|*307 |            TABLE ACCESS FULL                         | V_INTERVENANTS              |      2 |      1 |     3   (0)|      0 |00:00:00.01 |      14 |   6 |
| 308 |            TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|*309 |             INDEX RANGE SCAN                         | DOM_TYPVAL                  |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
| 310 |           VIEW                                       | V_TDOMAINE                  |      2 |     37 |    37   (0)|      1 |00:00:00.01 |       8 |   0 |
| 311 |            UNION-ALL                                 |                             |      2 |        |            |      1 |00:00:00.01 |       8 |   0 |
|*312 |             FILTER                                   |                             |      2 |        |            |      0 |00:00:00.01 |       0 |   0 |
|*313 |              TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|*314 |               INDEX RANGE SCAN                       | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|*315 |             FILTER                                   |                             |      2 |        |            |      1 |00:00:00.01 |       8 |   0 |
|*316 |              TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE                   |      2 |      1 |     1   (0)|      1 |00:00:00.01 |       8 |   0 |
|*317 |               INDEX RANGE SCAN                       | DOM_TYPABREV                |      2 |      1 |     1   (0)|      2 |00:00:00.01 |       6 |   0 |
|*318 |             FILTER                                   |                             |      1 |        |            |      0 |00:00:00.01 |       0 |   0 |
|*319 |              TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|*320 |               INDEX RANGE SCAN                       | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|*321 |             FILTER                                   |                             |      1 |        |            |      0 |00:00:00.01 |       0 |   0 |
|*322 |              TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|*323 |               INDEX RANGE SCAN                       | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|*324 |             FILTER                                   |                             |      1 |        |            |      0 |00:00:00.01 |       0 |   0 |
|*325 |              TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|*326 |               INDEX RANGE SCAN                       | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|*327 |             FILTER                                   |                             |      1 |        |            |      0 |00:00:00.01 |       0 |   0 |
|*328 |              TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|*329 |               INDEX RANGE SCAN                       | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|*330 |             FILTER                                   |                             |      1 |        |            |      0 |00:00:00.01 |       0 |   0 |
|*331 |              TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|*332 |               INDEX RANGE SCAN                       | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|*333 |             FILTER                                   |                             |      1 |        |            |      0 |00:00:00.01 |       0 |   0 |
|*334 |              TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|*335 |               INDEX RANGE SCAN                       | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|*336 |             FILTER                                   |                             |      1 |        |            |      0 |00:00:00.01 |       0 |   0 |
|*337 |              TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|*338 |               INDEX RANGE SCAN                       | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|*339 |             FILTER                                   |                             |      1 |        |            |      0 |00:00:00.01 |       0 |   0 |
|*340 |              TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|*341 |               INDEX RANGE SCAN                       | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|*342 |             FILTER                                   |                             |      1 |        |            |      0 |00:00:00.01 |       0 |   0 |
|*343 |              TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|*344 |               INDEX RANGE SCAN                       | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|*345 |             FILTER                                   |                             |      1 |        |            |      0 |00:00:00.01 |       0 |   0 |
|*346 |              TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|*347 |               INDEX RANGE SCAN                       | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|*348 |             FILTER                                   |                             |      1 |        |            |      0 |00:00:00.01 |       0 |   0 |
|*349 |              TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|*350 |               INDEX RANGE SCAN                       | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|*351 |             FILTER                                   |                             |      1 |        |            |      0 |00:00:00.01 |       0 |   0 |
|*352 |              TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|*353 |               INDEX RANGE SCAN                       | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|*354 |             FILTER                                   |                             |      1 |        |            |      0 |00:00:00.01 |       0 |   0 |
|*355 |              TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|*356 |               INDEX RANGE SCAN                       | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|*357 |             FILTER                                   |                             |      1 |        |            |      0 |00:00:00.01 |       0 |   0 |
|*358 |              TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|*359 |               INDEX RANGE SCAN                       | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|*360 |             FILTER                                   |                             |      1 |        |            |      0 |00:00:00.01 |       0 |   0 |
|*361 |              TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|*362 |               INDEX RANGE SCAN                       | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|*363 |             FILTER                                   |                             |      1 |        |            |      0 |00:00:00.01 |       0 |   0 |
|*364 |              TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|*365 |               INDEX RANGE SCAN                       | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|*366 |             FILTER                                   |                             |      1 |        |            |      0 |00:00:00.01 |       0 |   0 |
|*367 |              TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|*368 |               INDEX RANGE SCAN                       | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|*369 |             FILTER                                   |                             |      1 |        |            |      0 |00:00:00.01 |       0 |   0 |
|*370 |              TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|*371 |               INDEX RANGE SCAN                       | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|*372 |             FILTER                                   |                             |      1 |        |            |      0 |00:00:00.01 |       0 |   0 |
|*373 |              TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|*374 |               INDEX RANGE SCAN                       | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|*375 |             FILTER                                   |                             |      1 |        |            |      0 |00:00:00.01 |       0 |   0 |
|*376 |              TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|*377 |               INDEX RANGE SCAN                       | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|*378 |             FILTER                                   |                             |      1 |        |            |      0 |00:00:00.01 |       0 |   0 |
|*379 |              TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|*380 |               INDEX RANGE SCAN                       | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|*381 |             FILTER                                   |                             |      1 |        |            |      0 |00:00:00.01 |       0 |   0 |
|*382 |              TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|*383 |               INDEX RANGE SCAN                       | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|*384 |             FILTER                                   |                             |      1 |        |            |      0 |00:00:00.01 |       0 |   0 |
|*385 |              TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|*386 |               INDEX RANGE SCAN                       | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|*387 |             FILTER                                   |                             |      1 |        |            |      0 |00:00:00.01 |       0 |   0 |
|*388 |              TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|*389 |               INDEX RANGE SCAN                       | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|*390 |             FILTER                                   |                             |      1 |        |            |      0 |00:00:00.01 |       0 |   0 |
|*391 |              TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|*392 |               INDEX RANGE SCAN                       | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|*393 |             FILTER                                   |                             |      1 |        |            |      0 |00:00:00.01 |       0 |   0 |
|*394 |              TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|*395 |               INDEX RANGE SCAN                       | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|*396 |             FILTER                                   |                             |      1 |        |            |      0 |00:00:00.01 |       0 |   0 |
|*397 |              TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|*398 |               INDEX RANGE SCAN                       | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|*399 |             FILTER                                   |                             |      1 |        |            |      0 |00:00:00.01 |       0 |   0 |
|*400 |              TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|*401 |               INDEX RANGE SCAN                       | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|*402 |             FILTER                                   |                             |      1 |        |            |      0 |00:00:00.01 |       0 |   0 |
|*403 |              TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|*404 |               INDEX RANGE SCAN                       | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|*405 |             FILTER                                   |                             |      1 |        |            |      0 |00:00:00.01 |       0 |   0 |
|*406 |              TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|*407 |               INDEX RANGE SCAN                       | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|*408 |             FILTER                                   |                             |      1 |        |            |      0 |00:00:00.01 |       0 |   0 |
|*409 |              TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|*410 |               INDEX RANGE SCAN                       | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|*411 |             FILTER                                   |                             |      1 |        |            |      0 |00:00:00.01 |       0 |   0 |
|*412 |              TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|*413 |               INDEX RANGE SCAN                       | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|*414 |             FILTER                                   |                             |      1 |        |            |      0 |00:00:00.01 |       0 |   0 |
|*415 |              TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|*416 |               INDEX RANGE SCAN                       | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|*417 |             FILTER                                   |                             |      1 |        |            |      0 |00:00:00.01 |       0 |   0 |
|*418 |              TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|*419 |               INDEX RANGE SCAN                       | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|*420 |             FILTER                                   |                             |      1 |        |            |      0 |00:00:00.01 |       0 |   0 |
|*421 |              TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|*422 |               INDEX RANGE SCAN                       | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
|*423 |        INDEX RANGE SCAN                              | G_INDIVPARAM_REFIND         |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |   0 |
--------------------------------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   1 - filter(ROWNUM=1)
   5 - access("CMP"."REFPERSO"=:B1)
   6 - access("CMI"."REFINDIVIDU"="CMP"."REFINDIVIDU")
   9 - filter( IS NOT NULL)
  13 - filter(("VF"."ECRAN" IS NOT NULL AND "VF"."ABREV16"='O'))
  14 - access("VF"."TYPE"='filiere')
  17 - access("REFDOSS"=:B1)
  18 - access("VT"."TYPE"='typencour' AND "VF"."ECRAN"="VT"."ABREV" AND "LIBELLE"="VT"."VALEUR")
       filter(("VT"."VALEUR" IS NOT NULL AND "VT"."ABREV" IS NOT NULL))
  19 - filter(ROWNUM=1)
  23 - access("SMP"."REFPERSO"=TO_NUMBER(:B1))
  24 - access("SMI"."REFINDIVIDU"="SMP"."REFINDIVIDU")
  26 - filter("TPNCR"."PFX_VALEUR"=:B1)
  28 - filter(ROWNUM=1)
  30 - access("REFDOSS"=:B1 AND "TYPPIECE"='RECOUVREMENT')
  32 - filter(((:B1 IS NOT NULL AND "FI"."CREATEUR"='cfc_migration') OR (:B2 IS NULL AND TRUNC(INTERNAL_FUNCTION("DTJOUR_DT"))=NVL(TRUNC(:B3),TRUNC(:B4)))))
  33 - access("FI"."REFDOSS"=:B1)
  38 - access("PSU"."REFPERSO"=:B1)
  39 - access("ISU"."REFINDIVIDU"="PSU"."REFINDIVIDU")
  43 - access("V"."F"="PFX"."F")
  53 - filter('AL'=:B1)
  55 - access("TYPE"='typencour')
  56 - filter('AN'=:B1)
  58 - access("TYPE"='typencour')
  59 - filter('AR'=:B1)
  61 - access("TYPE"='typencour')
  62 - filter('BG'=:B1)
  64 - access("TYPE"='typencour')
  65 - filter('BR'=:B1)
  67 - access("TYPE"='typencour')
  68 - filter('CE'=:B1)
  70 - access("TYPE"='typencour')
  71 - filter('CH'=:B1)
  73 - access("TYPE"='typencour')
  74 - filter('CS'=:B1)
  76 - access("TYPE"='typencour')
  77 - filter('DA'=:B1)
  79 - access("TYPE"='typencour')
  80 - filter('EL'=:B1)
  82 - access("TYPE"='typencour')
  83 - filter('ES'=:B1)
  85 - access("TYPE"='typencour')
  86 - filter('ET'=:B1)
  88 - access("TYPE"='typencour')
  89 - filter('FI'=:B1)
  91 - access("TYPE"='typencour')
  92 - filter('FL'=:B1)
  94 - access("TYPE"='typencour')
  95 - filter('FR'=:B1)
  97 - access("TYPE"='typencour')
  98 - filter('HR'=:B1)
 100 - access("TYPE"='typencour')
 101 - filter('HU'=:B1)
 103 - access("TYPE"='typencour')
 104 - filter('IT'=:B1)
 106 - access("TYPE"='typencour')
 107 - filter('IW'=:B1)
 109 - access("TYPE"='typencour')
 110 - filter('JA'=:B1)
 112 - access("TYPE"='typencour')
 113 - filter('LT'=:B1)
 115 - access("TYPE"='typencour')
 116 - filter('LV'=:B1)
 118 - access("TYPE"='typencour')
 119 - filter('MX'=:B1)
 121 - access("TYPE"='typencour')
 122 - filter('NL'=:B1)
 124 - access("TYPE"='typencour')
 125 - filter('NO'=:B1)
 127 - access("TYPE"='typencour')
 128 - filter('PL'=:B1)
 130 - access("TYPE"='typencour')
 131 - filter('PT'=:B1)
 133 - access("TYPE"='typencour')
 134 - filter('RO'=:B1)
 136 - access("TYPE"='typencour')
 137 - filter('RU'=:B1)
 139 - access("TYPE"='typencour')
 140 - filter('SK'=:B1)
 142 - access("TYPE"='typencour')
 143 - filter('SL'=:B1)
 145 - access("TYPE"='typencour')
 146 - filter('SR'=:B1)
 148 - access("TYPE"='typencour')
 149 - filter('SV'=:B1)
 151 - access("TYPE"='typencour')
 152 - filter('TR'=:B1)
 154 - access("TYPE"='typencour')
 155 - filter('US'=:B1)
 157 - access("TYPE"='typencour')
 158 - filter('VI'=:B1)
 160 - access("TYPE"='typencour')
 161 - filter('ZH'=:B1)
 163 - access("TYPE"='typencour')
 164 - filter("RNUM">=:B17)
 165 - filter(ROWNUM<=:B16)
 168 - filter(("IDB"."STR36" IS NULL OR  IS NOT NULL))
 175 - access("ABREV"="D"."STRATIF")
 179 - filter('AL'=:B3)
 180 - filter("VALEUR_AL" LIKE :B14)
 181 - access("TYPE"='STRAT')
 182 - filter('AN'=:B3)
 183 - filter("VALEUR_AN" LIKE :B14)
 184 - access("TYPE"='STRAT')
 185 - filter('AR'=:B3)
 186 - filter("VALEUR_AR" LIKE :B14)
 187 - access("TYPE"='STRAT')
 188 - filter('BG'=:B3)
 189 - filter("VALEUR_BG" LIKE :B14)
 190 - access("TYPE"='STRAT')
 191 - filter('BR'=:B3)
 192 - filter("VALEUR_BR" LIKE :B14)
 193 - access("TYPE"='STRAT')
 194 - filter('CE'=:B3)
 195 - filter("VALEUR_CE" LIKE :B14)
 196 - access("TYPE"='STRAT')
 197 - filter('CH'=:B3)
 198 - filter("VALEUR_CH" LIKE :B14)
 199 - access("TYPE"='STRAT')
 200 - filter('CS'=:B3)
 201 - filter("VALEUR_CS" LIKE :B14)
 202 - access("TYPE"='STRAT')
 203 - filter('DA'=:B3)
 204 - filter("VALEUR_DA" LIKE :B14)
 205 - access("TYPE"='STRAT')
 206 - filter('EL'=:B3)
 207 - filter("VALEUR_EL" LIKE :B14)
 208 - access("TYPE"='STRAT')
 209 - filter('ES'=:B3)
 210 - filter("VALEUR_ES" LIKE :B14)
 211 - access("TYPE"='STRAT')
 212 - filter('ET'=:B3)
 213 - filter("VALEUR_ET" LIKE :B14)
 214 - access("TYPE"='STRAT')
 215 - filter('FI'=:B3)
 216 - filter("VALEUR_FI" LIKE :B14)
 217 - access("TYPE"='STRAT')
 218 - filter('FL'=:B3)
 219 - filter("VALEUR_FL" LIKE :B14)
 220 - access("TYPE"='STRAT')
 221 - filter('FR'=:B3)
 222 - filter(NVL("VALEUR_FR","VALEUR") LIKE :B14)
 223 - access("TYPE"='STRAT')
 224 - filter('HR'=:B3)
 225 - filter("VALEUR_HR" LIKE :B14)
 226 - access("TYPE"='STRAT')
 227 - filter('HU'=:B3)
 228 - filter("VALEUR_HU" LIKE :B14)
 229 - access("TYPE"='STRAT')
 230 - filter('IT'=:B3)
 231 - filter("VALEUR_IT" LIKE :B14)
 232 - access("TYPE"='STRAT')
 233 - filter('IW'=:B3)
 234 - filter("VALEUR_IW" LIKE :B14)
 235 - access("TYPE"='STRAT')
 236 - filter('JA'=:B3)
 237 - filter("VALEUR_JA" LIKE :B14)
 238 - access("TYPE"='STRAT')
 239 - filter('LT'=:B3)
 240 - filter("VALEUR_LT" LIKE :B14)
 241 - access("TYPE"='STRAT')
 242 - filter('LV'=:B3)
 243 - filter("VALEUR_LV" LIKE :B14)
 244 - access("TYPE"='STRAT')
 245 - filter('MX'=:B3)
 246 - filter("VALEUR_MX" LIKE :B14)
 247 - access("TYPE"='STRAT')
 248 - filter('NL'=:B3)
 249 - filter("VALEUR_NL" LIKE :B14)
 250 - access("TYPE"='STRAT')
 251 - filter('NO'=:B3)
 252 - filter("VALEUR_NO" LIKE :B14)
 253 - access("TYPE"='STRAT')
 254 - filter('PL'=:B3)
 255 - filter("VALEUR_PL" LIKE :B14)
 256 - access("TYPE"='STRAT')
 257 - filter('PT'=:B3)
 258 - filter("VALEUR_PT" LIKE :B14)
 259 - access("TYPE"='STRAT')
 260 - filter('RO'=:B3)
 261 - filter("VALEUR_RO" LIKE :B14)
 262 - access("TYPE"='STRAT')
 263 - filter('RU'=:B3)
 264 - filter("VALEUR_RU" LIKE :B14)
 265 - access("TYPE"='STRAT')
 266 - filter('SK'=:B3)
 267 - filter("VALEUR_SK" LIKE :B14)
 268 - access("TYPE"='STRAT')
 269 - filter('SL'=:B3)
 270 - filter("VALEUR_SL" LIKE :B14)
 271 - access("TYPE"='STRAT')
 272 - filter('SR'=:B3)
 273 - filter("VALEUR_SR" LIKE :B14)
 274 - access("TYPE"='STRAT')
 275 - filter('SV'=:B3)
 276 - filter("VALEUR_SV" LIKE :B14)
 277 - access("TYPE"='STRAT')
 278 - filter('TR'=:B3)
 279 - filter("VALEUR_TR" LIKE :B14)
 280 - access("TYPE"='STRAT')
 281 - filter('US'=:B3)
 282 - filter("VALEUR_US" LIKE :B14)
 283 - access("TYPE"='STRAT')
 284 - filter('VI'=:B3)
 285 - filter("VALEUR_VI" LIKE :B14)
 286 - access("TYPE"='STRAT')
 287 - filter('ZH'=:B3)
 288 - filter("VALEUR_ZH" LIKE :B14)
 289 - access("TYPE"='STRAT')
 290 - filter("TYPEOFMANDATE"=:B15)
 292 - access("TDB"."REFDOSS"="D"."REFDOSS" AND "TDB"."REFTYPE"=:B11)
 293 - access("TCL"."REFDOSS"="D"."REFDOSS" AND "TCL"."REFTYPE"='CL')
 295 - access("ATT"."REFENTITE"="D"."REFDOSS")
 297 - access("IDB"."REFINDIVIDU"="TDB"."REFINDIVIDU")
 299 - access("ICL"."REFINDIVIDU"="TCL"."REFINDIVIDU")
 301 - filter(( IS NOT NULL OR  IS NOT NULL))
 304 - access("GD"."REFDOSS"="D"."REFDOSS")
 305 - access("T"."REFDOSS"="D"."REFDOSS" AND "T"."REFINDIVIDU"=:B10)
       filter(("T"."REFINDIVIDU"=:B10 AND "T"."REFTYPE"<>'XX'))
 306 - filter(("CATEGDOSS" IS NULL OR "CATEGDOSS"=))
 307 - filter(("REFTYPE_BD"=:B1 AND "REFTYPE_AFF" LIKE :B6))
 309 - access("VALEUR"=:B1 AND "TYPE"=:B5)
 312 - filter('AL'=:B8)
 313 - filter("ABREV_AL" LIKE :B9)
 314 - access("TYPE"=:B7 AND "ABREV"=:B1)
 315 - filter('AN'=:B8)
 316 - filter("ABREV_AN" LIKE :B9)
 317 - access("TYPE"=:B7 AND "ABREV"=:B1)
 318 - filter('AR'=:B8)
 319 - filter("ABREV_AR" LIKE :B9)
 320 - access("TYPE"=:B7 AND "ABREV"=:B1)
 321 - filter('BG'=:B8)
 322 - filter("ABREV_BG" LIKE :B9)
 323 - access("TYPE"=:B7 AND "ABREV"=:B1)
 324 - filter('BR'=:B8)
 325 - filter("ABREV_BR" LIKE :B9)
 326 - access("TYPE"=:B7 AND "ABREV"=:B1)
 327 - filter('CE'=:B8)
 328 - filter("ABREV_CE" LIKE :B9)
 329 - access("TYPE"=:B7 AND "ABREV"=:B1)
 330 - filter('CH'=:B8)
 331 - filter("ABREV_CH" LIKE :B9)
 332 - access("TYPE"=:B7 AND "ABREV"=:B1)
 333 - filter('CS'=:B8)
 334 - filter("ABREV_CS" LIKE :B9)
 335 - access("TYPE"=:B7 AND "ABREV"=:B1)
 336 - filter('DA'=:B8)
 337 - filter("ABREV_DA" LIKE :B9)
 338 - access("TYPE"=:B7 AND "ABREV"=:B1)
 339 - filter('EL'=:B8)
 340 - filter("ABREV_EL" LIKE :B9)
 341 - access("TYPE"=:B7 AND "ABREV"=:B1)
 342 - filter('ES'=:B8)
 343 - filter("ABREV_ES" LIKE :B9)
 344 - access("TYPE"=:B7 AND "ABREV"=:B1)
 345 - filter('ET'=:B8)
 346 - filter("ABREV_ET" LIKE :B9)
 347 - access("TYPE"=:B7 AND "ABREV"=:B1)
 348 - filter('FI'=:B8)
 349 - filter("ABREV_FI" LIKE :B9)
 350 - access("TYPE"=:B7 AND "ABREV"=:B1)
 351 - filter('FL'=:B8)
 352 - filter("ABREV_FL" LIKE :B9)
 353 - access("TYPE"=:B7 AND "ABREV"=:B1)
 354 - filter('FR'=:B8)
 355 - filter(NVL("ABREV_FR","ABREV") LIKE :B9)
 356 - access("TYPE"=:B7 AND "ABREV"=:B1)
 357 - filter('HR'=:B8)
 358 - filter("ABREV_HR" LIKE :B9)
 359 - access("TYPE"=:B7 AND "ABREV"=:B1)
 360 - filter('HU'=:B8)
 361 - filter("ABREV_HU" LIKE :B9)
 362 - access("TYPE"=:B7 AND "ABREV"=:B1)
 363 - filter('IT'=:B8)
 364 - filter("ABREV_IT" LIKE :B9)
 365 - access("TYPE"=:B7 AND "ABREV"=:B1)
 366 - filter('IW'=:B8)
 367 - filter("ABREV_IW" LIKE :B9)
 368 - access("TYPE"=:B7 AND "ABREV"=:B1)
 369 - filter('JA'=:B8)
 370 - filter("ABREV_JA" LIKE :B9)
 371 - access("TYPE"=:B7 AND "ABREV"=:B1)
 372 - filter('LT'=:B8)
 373 - filter("ABREV_LT" LIKE :B9)
 374 - access("TYPE"=:B7 AND "ABREV"=:B1)
 375 - filter('LV'=:B8)
 376 - filter("ABREV_LV" LIKE :B9)
 377 - access("TYPE"=:B7 AND "ABREV"=:B1)
 378 - filter('MX'=:B8)
 379 - filter("ABREV_MX" LIKE :B9)
 380 - access("TYPE"=:B7 AND "ABREV"=:B1)
 381 - filter('NL'=:B8)
 382 - filter("ABREV_NL" LIKE :B9)
 383 - access("TYPE"=:B7 AND "ABREV"=:B1)
 384 - filter('NO'=:B8)
 385 - filter("ABREV_NO" LIKE :B9)
 386 - access("TYPE"=:B7 AND "ABREV"=:B1)
 387 - filter('PL'=:B8)
 388 - filter("ABREV_PL" LIKE :B9)
 389 - access("TYPE"=:B7 AND "ABREV"=:B1)
 390 - filter('PT'=:B8)
 391 - filter("ABREV_PT" LIKE :B9)
 392 - access("TYPE"=:B7 AND "ABREV"=:B1)
 393 - filter('RO'=:B8)
 394 - filter("ABREV_RO" LIKE :B9)
 395 - access("TYPE"=:B7 AND "ABREV"=:B1)
 396 - filter('RU'=:B8)
 397 - filter("ABREV_RU" LIKE :B9)
 398 - access("TYPE"=:B7 AND "ABREV"=:B1)
 399 - filter('SK'=:B8)
 400 - filter("ABREV_SK" LIKE :B9)
 401 - access("TYPE"=:B7 AND "ABREV"=:B1)
 402 - filter('SL'=:B8)
 403 - filter("ABREV_SL" LIKE :B9)
 404 - access("TYPE"=:B7 AND "ABREV"=:B1)
 405 - filter('SR'=:B8)
 406 - filter("ABREV_SR" LIKE :B9)
 407 - access("TYPE"=:B7 AND "ABREV"=:B1)
 408 - filter('SV'=:B8)
 409 - filter("ABREV_SV" LIKE :B9)
 410 - access("TYPE"=:B7 AND "ABREV"=:B1)
 411 - filter('TR'=:B8)
 412 - filter("ABREV_TR" LIKE :B9)
 413 - access("TYPE"=:B7 AND "ABREV"=:B1)
 414 - filter('US'=:B8)
 415 - filter("ABREV_US" LIKE :B9)
 416 - access("TYPE"=:B7 AND "ABREV"=:B1)
 417 - filter('VI'=:B8)
 418 - filter("ABREV_VI" LIKE :B9)
 419 - access("TYPE"=:B7 AND "ABREV"=:B1)
 420 - filter('ZH'=:B8)
 421 - filter("ABREV_ZH" LIKE :B9)
 422 - access("TYPE"=:B7 AND "ABREV"=:B1)
 423 - access("REFINDIVIDU"=:B12 AND "TYPE"='type_indiv' AND "STR1"=:B1)
       filter("STR1"=:B1)
*/
/********************************OLD Metrics***************************************/

/********************************New SQL*******************************************/
WITH tpncr AS
 (SELECT /*+ materialize */
   *
    FROM (SELECT /*+ no_merge(pfx) leading(pfx) use_hash(v) */
           pfx.valeur || v.valeur pfx_valeur,
           pfx.valeur || v.valeur_trad valeur_trad
            FROM (SELECT 'PB: A.' valeur, 'f' f
                    FROM dual
                  UNION ALL
                  SELECT 'PB: ' valeur, 'f' f
                    FROM dual
                  UNION ALL
                  SELECT 'A.' valeur, 'f' f
                    FROM dual
                  UNION ALL
                  SELECT '' valeur, 'f' f
                    FROM dual) pfx,
                 (SELECT /*+ no_merge no_push_pred */
                   valeur, valeur_trad, 'f' f
                    FROM v_tdomaine
                   WHERE type = 'typencour'
                     AND langue = :B1) v
           WHERE v.f = pfx.f) fooo
   WHERE 1 = 1)
SELECT *
  FROM (SELECT /*+ first_rows(201)*/
         foo.*, ROWNUM rnum
          FROM (SELECT (SELECT CMI.nom
                          FROM g_individu CMI, g_personnel CMP
                         WHERE CMP.refperso = D.rangmt
                           AND CMI.refindividu = CMP.refindividu
                           AND rownum = 1) caseManagerDisplay,
                       D.dtfingest_dt managementEndDate,
                       D.rangmt caseManager,
                       ATT.typencour caseStatus,
                       ATT.dtdeclench_dt dueDate,
                       (SELECT DECODE(COUNT(*), 0, 'false', 'true')
                          FROM DUAL
                         WHERE EXISTS
                         (SELECT 1
                                  FROM t_element_se
                                 WHERE refdoss = D.refdoss
                                   AND libelle IN
                                       (SELECT vt.valeur
                                          FROM v_domaine vt, v_domaine vf
                                         WHERE vt.type = 'typencour'
                                           AND vf.abrev16 = 'O'
                                           AND vf.type = 'filiere'
                                           AND vf.ecran = vt.abrev))) forbProcessFound,
                       (SELECT SMI.nom
                          FROM g_individu SMI, g_personnel SMP
                         WHERE SMP.refperso = ATT.catperso
                           AND SMI.refindividu = SMP.refindividu
                           AND rownum = 1) statusManagerDisplay,
                       D.refdoss internalCaseReference,
                       IDB.nom debtor,
                       D.soldedb caseBalance,
                       ICL.nom client,
                       tpncr.valeur_trad caseStatusDisplay,
                       D.devise caseCurrency,
                       IMX.get_valeur('TYPE_MANDAT', GP.st24, :B2) typeOfMandate,
                       IMX.get_valeur('PHASE', D.phase, :B3) phase,
                       D.reflot_dos reflot_dos,
                       ATT.catperso statusManager,
                       D.pieceinit product,
                       D.ancrefdoss externalCaseReference,
                       IDB.siret debtorNrn,
                       D.initialAmount initialAmount,
                       (SELECT IMX.transl_valeur('piece', D.pieceinit, :B4)
                          FROM dual) productDisplay,
                       (count(D.refdoss) OVER()) totalRealCases,
                       D.caseManagerSu caseManagerSu,
                       (SUM(D.soldedb) OVER()) sumBalanceReal
                  FROM  tpncr,
                       (SELECT D.rangmt,
                               D.ancrefdoss,
                               D.refdoss,
                               D.devise,
                               D.soldedb,
                               D.soldedb_dos,
                               D.dtfingest_dt,
                               D.reflot_dos,
                               D.reflot,
                               D.principal,
                               D.segment,
                               D.pieceinit,
                               D.monref,
                               D.dt_dt_dt,
                               D.dtcreation_dt,
                               D.categdoss,
                               D.stratif,
                               D.dt_dechterm_dt,
                               (SELECT ISU.nom
                                  FROM g_personnel PSU, g_individu ISU
                                 WHERE PSU.refperso = D.monref
                                   AND ISU.refindividu = PSU.refindividu) as caseManagerSu,
                               D.phase phase,
                               (SELECT SUM(FI.montant)
                                  FROM g_elemfi FI
                                 WHERE FI.refdoss = D.refdoss
                                   AND ((D.mig_reference IS NULL AND
                                       TRUNC(dtjour_dt) =
                                       NVL(TRUNC(D.dtcreation_dt),
                                             TRUNC(D.dt_dt_dt))) OR
                                       (D.mig_reference IS NOT NULL AND
                                       FI.createur = 'cfc_migration'))) as initialAmount,                               
                               (select decode((select count(*) flag_true
                                                from (select nvl(max(FG_INCL_NOT_DUE_ELEM_CASE_BAL),
                                                                 'N') flag
                                                        from g_bu
                                                       where refindividu =
                                                             (select refindividu
                                                                from t_intervenants
                                                               where refdoss =
                                                                     D.refdoss
                                                                 and reftype = 'BU')) g_bu_flag,
                                                     (select nvl(max(FG_TREAT_ALL_ELEMENTS_AS_DUE),
                                                                 'N') flag
                                                        from g_dossier
                                                       where refdoss = D.refdoss) g_doss_flag
                                               where g_bu_flag.flag = 'N'
                                                 and g_doss_flag.flag = 'N'),
                                              0,
                                              (select sum(nvl(mt_ouvert_mvt,
                                                              montant_dos))
                                                 from g_elemfi
                                                where refdoss = D.refdoss
                                                  and dtdebut <
                                                      to_char(sysdate, 'j')),
                                              (select cpt_util.getPostSum(D.refdoss,
                                                                          'SOLDEDB',
                                                                          (select dt_dt
                                                                             from g_dossier
                                                                            where refdoss =
                                                                                  D.refdoss),
                                                                          'ECR',
                                                                          'DOS')
                                                 from dual))
                                  from dual) AS totalAmtDebt
                          FROM g_dossier D
                         WHERE 1 = 1) D,
                       t_intervenants TDB,
                       g_individu IDB,
                       t_intervenants TCL,
                       g_individu ICL,
                       t_attente ATT,
                       g_piece GP,
                       (SELECT /*+ cardinality(T 0) */
                        DISTINCT gd.refdoss 
                          FROM t_intervenants T,
                               g_dossier GD
                         WHERE 1 = 1                 
                           AND T.reftype <> 'XX'
                           AND GD.refdoss = T.refdoss
                           AND (EXISTS
                                (SELECT 1
                                   FROM v_intervenants
                                  WHERE (categdoss =
                                        (SELECT abrev
                                            FROM v_domaine
                                           WHERE valeur = GD.categdoss
                                             AND TYPE = :B5) OR categdoss IS NULL)
                                    AND reftype_bd = t.reftype
                                    AND reftype_aff LIKE :B6) OR EXISTS
                                (SELECT 1
                                   FROM v_tdomaine
                                  WHERE type = :B7
                                    AND langue = :B8
                                    AND abrev_trad LIKE :B9
                                    AND abrev = T.reftype))
                           AND t.refindividu = :B10) DF
                 WHERE 1 = 1
                   AND tpncr.pfx_valeur(+) = ATT.typencour
                   AND TDB.refdoss(+) = D.refdoss
                   AND IDB.refindividu(+) = TDB.refindividu
                   AND TDB.reftype(+) = :B11
                   AND TCL.refdoss(+) = D.refdoss
                   AND ICL.refindividu(+) = TCL.refindividu
                   AND ATT.refentite = D.refdoss
                   AND tcl.reftype(+) = 'CL'
                   AND D.refdoss = DF.refdoss
                   AND GP.refdoss = D.refdoss
                   AND GP.typpiece = 'RECOUVREMENT'
                   AND GP.st24 = :B15
                   AND (idb.str36 IS NULL OR EXISTS
                        (SELECT 1
                           FROM g_indivparam
                          WHERE refindividu = :B12
                            AND type = 'type_indiv'
                            AND str1 = idb.str36))
                   AND EXISTS (SELECT 1
                          FROM v_tdomaine
                         WHERE type = 'STRAT'
                           AND langue = :B3
                           AND abrev = d.stratif
                           AND valeur_trad LIKE :B14)
                 ORDER BY D.refdoss, D.refdoss) foo
         WHERE ROWNUM <= :B16)
 WHERE 1 = 1
   AND rnum >= :B17;
/********************************New SQL*******************************************/
/********************************New Metrics***************************************/
/*
Plan hash value: 2005589111
------------------------------------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                                | Name                        | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  |
------------------------------------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                                         |                             |      1 |        |   115 (100)|    151 |00:00:10.69 |     147K|  12855 |
|*  1 |  COUNT STOPKEY                                           |                             |      4 |        |            |      4 |00:00:00.01 |      28 |      0 |
|   2 |   NESTED LOOPS                                           |                             |      4 |      1 |     2   (0)|      4 |00:00:00.01 |      28 |      0 |
|   3 |    NESTED LOOPS                                          |                             |      4 |      1 |     2   (0)|      4 |00:00:00.01 |      24 |      0 |
|   4 |     TABLE ACCESS BY INDEX ROWID BATCHED                  | G_PERSONNEL                 |      4 |      1 |     1   (0)|      4 |00:00:00.01 |      12 |      0 |
|*  5 |      INDEX RANGE SCAN                                    | PK_G_PERSONNEL              |      4 |      1 |     1   (0)|      4 |00:00:00.01 |       8 |      0 |
|*  6 |     INDEX UNIQUE SCAN                                    | IND_REFINDIV                |      4 |      1 |     1   (0)|      4 |00:00:00.01 |      12 |      0 |
|   7 |    TABLE ACCESS BY INDEX ROWID                           | G_INDIVIDU                  |      4 |      1 |     1   (0)|      4 |00:00:00.01 |       4 |      0 |
|   8 |  SORT AGGREGATE                                          |                             |    151 |      1 |            |    151 |00:00:00.13 |   11615 |    110 |
|*  9 |   FILTER                                                 |                             |    151 |        |            |      0 |00:00:00.13 |   11615 |    110 |
|  10 |    FAST DUAL                                             |                             |    151 |      1 |     2   (0)|    151 |00:00:00.01 |       0 |      0 |
|  11 |    NESTED LOOPS                                          |                             |    151 |      1 |     3   (0)|      0 |00:00:00.13 |   11615 |    110 |
|  12 |     MERGE JOIN CARTESIAN                                 |                             |    151 |      1 |     2   (0)|    226 |00:00:00.12 |   11456 |    109 |
|* 13 |      TABLE ACCESS BY INDEX ROWID BATCHED                 | V_DOMAINE                   |    151 |      1 |     1   (0)|    151 |00:00:00.03 |   10882 |     13 |
|* 14 |       INDEX RANGE SCAN                                   | V_DOMAINE_TYPE_CODE_IDX     |    151 |     77 |     1   (0)|   8909 |00:00:00.01 |     161 |      1 |
|  15 |      BUFFER SORT                                         |                             |    151 |      2 |     1   (0)|    226 |00:00:00.09 |     574 |     96 |
|  16 |       TABLE ACCESS BY INDEX ROWID BATCHED                | T_ELEMENT_SE                |    151 |      2 |     1   (0)|    226 |00:00:00.09 |     574 |     96 |
|* 17 |        INDEX RANGE SCAN                                  | ELESE_DOSELEM               |    151 |      2 |     1   (0)|    226 |00:00:00.09 |     419 |     96 |
|* 18 |     INDEX RANGE SCAN                                     | DOM_TYPABREV                |    226 |      1 |     1   (0)|      0 |00:00:00.01 |     159 |      1 |
|* 19 |  COUNT STOPKEY                                           |                             |      5 |        |            |      5 |00:00:00.01 |      35 |      0 |
|  20 |   NESTED LOOPS                                           |                             |      5 |      1 |     2   (0)|      5 |00:00:00.01 |      35 |      0 |
|  21 |    NESTED LOOPS                                          |                             |      5 |      1 |     2   (0)|      5 |00:00:00.01 |      30 |      0 |
|  22 |     TABLE ACCESS BY INDEX ROWID BATCHED                  | G_PERSONNEL                 |      5 |      1 |     1   (0)|      5 |00:00:00.01 |      15 |      0 |
|* 23 |      INDEX RANGE SCAN                                    | PK_G_PERSONNEL              |      5 |      1 |     1   (0)|      5 |00:00:00.01 |      10 |      0 |
|* 24 |     INDEX UNIQUE SCAN                                    | IND_REFINDIV                |      5 |      1 |     1   (0)|      5 |00:00:00.01 |      15 |      0 |
|  25 |    TABLE ACCESS BY INDEX ROWID                           | G_INDIVIDU                  |      5 |      1 |     1   (0)|      5 |00:00:00.01 |       5 |      0 |
|  26 |  SORT AGGREGATE                                          |                             |    151 |      1 |            |    151 |00:00:00.39 |    1941 |    690 |
|* 27 |   TABLE ACCESS BY INDEX ROWID BATCHED                    | G_ELEMFI                    |    151 |      1 |     1   (0)|    542 |00:00:00.39 |    1941 |    690 |
|* 28 |    INDEX RANGE SCAN                                      | EFI_DOS_DTEMIS_TYPE         |    151 |      8 |     1   (0)|   2501 |00:00:00.17 |     300 |    145 |
|  29 |  FAST DUAL                                               |                             |      1 |      1 |     2   (0)|      1 |00:00:00.01 |       0 |      0 |
|  30 |  NESTED LOOPS                                            |                             |      4 |      1 |     2   (0)|      4 |00:00:00.01 |      26 |      0 |
|  31 |   NESTED LOOPS                                           |                             |      4 |      1 |     2   (0)|      4 |00:00:00.01 |      22 |      0 |
|  32 |    TABLE ACCESS BY INDEX ROWID BATCHED                   | G_PERSONNEL                 |      4 |      1 |     1   (0)|      4 |00:00:00.01 |      11 |      0 |
|* 33 |     INDEX RANGE SCAN                                     | PK_G_PERSONNEL              |      4 |      1 |     1   (0)|      4 |00:00:00.01 |       7 |      0 |
|* 34 |    INDEX UNIQUE SCAN                                     | IND_REFINDIV                |      4 |      1 |     1   (0)|      4 |00:00:00.01 |      11 |      0 |
|  35 |   TABLE ACCESS BY INDEX ROWID                            | G_INDIVIDU                  |      4 |      1 |     1   (0)|      4 |00:00:00.01 |       4 |      0 |
|  36 |  TEMP TABLE TRANSFORMATION                               |                             |      1 |        |            |    151 |00:00:10.69 |     147K|  12855 |
|  37 |   LOAD AS SELECT (CURSOR DURATION MEMORY)                | SYS_TEMP_0FD9E0415_D8F21C32 |      1 |        |            |      0 |00:00:00.01 |     187 |      0 |
|* 38 |    HASH JOIN                                             |                             |      1 |    114 |    45   (0)|   4396 |00:00:00.01 |     186 |      0 |
|  39 |     VIEW                                                 |                             |      1 |      4 |     8   (0)|      4 |00:00:00.01 |       0 |      0 |
|  40 |      UNION-ALL                                           |                             |      1 |        |            |      4 |00:00:00.01 |       0 |      0 |
|  41 |       FAST DUAL                                          |                             |      1 |      1 |     2   (0)|      1 |00:00:00.01 |       0 |      0 |
|  42 |       FAST DUAL                                          |                             |      1 |      1 |     2   (0)|      1 |00:00:00.01 |       0 |      0 |
|  43 |       FAST DUAL                                          |                             |      1 |      1 |     2   (0)|      1 |00:00:00.01 |       0 |      0 |
|  44 |       FAST DUAL                                          |                             |      1 |      1 |     2   (0)|      1 |00:00:00.01 |       0 |      0 |
|  45 |     VIEW                                                 |                             |      1 |   2849 |    37   (0)|   1099 |00:00:00.01 |     186 |      0 |
|  46 |      VIEW                                                | V_TDOMAINE                  |      1 |   2849 |    37   (0)|   1099 |00:00:00.01 |     186 |      0 |
|  47 |       UNION-ALL                                          |                             |      1 |        |            |   1099 |00:00:00.01 |     186 |      0 |
|* 48 |        FILTER                                            |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  49 |         TABLE ACCESS BY INDEX ROWID BATCHED              | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 50 |          INDEX RANGE SCAN                                | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 51 |        FILTER                                            |                             |      1 |        |            |   1099 |00:00:00.01 |     186 |      0 |
|  52 |         TABLE ACCESS BY INDEX ROWID BATCHED              | V_DOMAINE                   |      1 |     77 |     1   (0)|   1099 |00:00:00.01 |     186 |      0 |
|* 53 |          INDEX RANGE SCAN                                | V_DOMAINE_TYPE_CODE_IDX     |      1 |     77 |     1   (0)|   1099 |00:00:00.01 |      17 |      0 |
|* 54 |        FILTER                                            |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  55 |         TABLE ACCESS BY INDEX ROWID BATCHED              | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 56 |          INDEX RANGE SCAN                                | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 57 |        FILTER                                            |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  58 |         TABLE ACCESS BY INDEX ROWID BATCHED              | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 59 |          INDEX RANGE SCAN                                | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 60 |        FILTER                                            |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  61 |         TABLE ACCESS BY INDEX ROWID BATCHED              | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 62 |          INDEX RANGE SCAN                                | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 63 |        FILTER                                            |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  64 |         TABLE ACCESS BY INDEX ROWID BATCHED              | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 65 |          INDEX RANGE SCAN                                | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 66 |        FILTER                                            |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  67 |         TABLE ACCESS BY INDEX ROWID BATCHED              | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 68 |          INDEX RANGE SCAN                                | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 69 |        FILTER                                            |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  70 |         TABLE ACCESS BY INDEX ROWID BATCHED              | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 71 |          INDEX RANGE SCAN                                | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 72 |        FILTER                                            |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  73 |         TABLE ACCESS BY INDEX ROWID BATCHED              | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 74 |          INDEX RANGE SCAN                                | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 75 |        FILTER                                            |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  76 |         TABLE ACCESS BY INDEX ROWID BATCHED              | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 77 |          INDEX RANGE SCAN                                | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 78 |        FILTER                                            |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  79 |         TABLE ACCESS BY INDEX ROWID BATCHED              | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 80 |          INDEX RANGE SCAN                                | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 81 |        FILTER                                            |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  82 |         TABLE ACCESS BY INDEX ROWID BATCHED              | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 83 |          INDEX RANGE SCAN                                | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 84 |        FILTER                                            |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  85 |         TABLE ACCESS BY INDEX ROWID BATCHED              | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 86 |          INDEX RANGE SCAN                                | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 87 |        FILTER                                            |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  88 |         TABLE ACCESS BY INDEX ROWID BATCHED              | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 89 |          INDEX RANGE SCAN                                | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 90 |        FILTER                                            |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  91 |         TABLE ACCESS BY INDEX ROWID BATCHED              | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 92 |          INDEX RANGE SCAN                                | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 93 |        FILTER                                            |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  94 |         TABLE ACCESS BY INDEX ROWID BATCHED              | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 95 |          INDEX RANGE SCAN                                | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 96 |        FILTER                                            |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  97 |         TABLE ACCESS BY INDEX ROWID BATCHED              | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 98 |          INDEX RANGE SCAN                                | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 99 |        FILTER                                            |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 100 |         TABLE ACCESS BY INDEX ROWID BATCHED              | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*101 |          INDEX RANGE SCAN                                | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*102 |        FILTER                                            |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 103 |         TABLE ACCESS BY INDEX ROWID BATCHED              | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*104 |          INDEX RANGE SCAN                                | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*105 |        FILTER                                            |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 106 |         TABLE ACCESS BY INDEX ROWID BATCHED              | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*107 |          INDEX RANGE SCAN                                | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*108 |        FILTER                                            |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 109 |         TABLE ACCESS BY INDEX ROWID BATCHED              | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*110 |          INDEX RANGE SCAN                                | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*111 |        FILTER                                            |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 112 |         TABLE ACCESS BY INDEX ROWID BATCHED              | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*113 |          INDEX RANGE SCAN                                | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*114 |        FILTER                                            |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 115 |         TABLE ACCESS BY INDEX ROWID BATCHED              | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*116 |          INDEX RANGE SCAN                                | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*117 |        FILTER                                            |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 118 |         TABLE ACCESS BY INDEX ROWID BATCHED              | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*119 |          INDEX RANGE SCAN                                | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*120 |        FILTER                                            |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 121 |         TABLE ACCESS BY INDEX ROWID BATCHED              | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*122 |          INDEX RANGE SCAN                                | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*123 |        FILTER                                            |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 124 |         TABLE ACCESS BY INDEX ROWID BATCHED              | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*125 |          INDEX RANGE SCAN                                | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*126 |        FILTER                                            |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 127 |         TABLE ACCESS BY INDEX ROWID BATCHED              | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*128 |          INDEX RANGE SCAN                                | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*129 |        FILTER                                            |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 130 |         TABLE ACCESS BY INDEX ROWID BATCHED              | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*131 |          INDEX RANGE SCAN                                | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*132 |        FILTER                                            |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 133 |         TABLE ACCESS BY INDEX ROWID BATCHED              | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*134 |          INDEX RANGE SCAN                                | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*135 |        FILTER                                            |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 136 |         TABLE ACCESS BY INDEX ROWID BATCHED              | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*137 |          INDEX RANGE SCAN                                | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*138 |        FILTER                                            |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 139 |         TABLE ACCESS BY INDEX ROWID BATCHED              | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*140 |          INDEX RANGE SCAN                                | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*141 |        FILTER                                            |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 142 |         TABLE ACCESS BY INDEX ROWID BATCHED              | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*143 |          INDEX RANGE SCAN                                | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*144 |        FILTER                                            |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 145 |         TABLE ACCESS BY INDEX ROWID BATCHED              | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*146 |          INDEX RANGE SCAN                                | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*147 |        FILTER                                            |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 148 |         TABLE ACCESS BY INDEX ROWID BATCHED              | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*149 |          INDEX RANGE SCAN                                | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*150 |        FILTER                                            |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 151 |         TABLE ACCESS BY INDEX ROWID BATCHED              | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*152 |          INDEX RANGE SCAN                                | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*153 |        FILTER                                            |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 154 |         TABLE ACCESS BY INDEX ROWID BATCHED              | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*155 |          INDEX RANGE SCAN                                | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*156 |        FILTER                                            |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 157 |         TABLE ACCESS BY INDEX ROWID BATCHED              | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*158 |          INDEX RANGE SCAN                                | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*159 |   VIEW                                                   |                             |      1 |      1 |    70   (2)|    151 |00:00:10.68 |     146K|  12855 |
|*160 |    COUNT STOPKEY                                         |                             |      1 |        |            |    151 |00:00:10.68 |     146K|  12855 |
| 161 |     VIEW                                                 |                             |      1 |      1 |    70   (2)|    151 |00:00:10.68 |     146K|  12855 |
| 162 |      WINDOW SORT                                         |                             |      1 |      1 |    70   (2)|    151 |00:00:10.06 |     128K|  12045 |
|*163 |       FILTER                                             |                             |      1 |        |            |    151 |00:00:10.06 |     128K|  12045 |
| 164 |        NESTED LOOPS SEMI                                 |                             |      1 |      1 |    56   (2)|    151 |00:00:10.06 |     128K|  12045 |
|*165 |         HASH JOIN OUTER                                  |                             |      1 |      1 |    19   (6)|   1740 |00:00:10.02 |     123K|  12039 |
| 166 |          NESTED LOOPS OUTER                              |                             |      1 |      1 |    14   (8)|   1740 |00:00:10.00 |     123K|  12039 |
| 167 |           NESTED LOOPS OUTER                             |                             |      1 |      1 |    13   (8)|   1740 |00:00:08.78 |     115K|  10693 |
| 168 |            NESTED LOOPS                                  |                             |      1 |      1 |    12   (9)|   1740 |00:00:08.76 |     115K|  10692 |
| 169 |             NESTED LOOPS OUTER                           |                             |      1 |      1 |    11  (10)|   1740 |00:00:08.57 |     110K|  10341 |
| 170 |              NESTED LOOPS OUTER                          |                             |      1 |      1 |    10  (10)|   1740 |00:00:08.55 |     107K|  10335 |
| 171 |               NESTED LOOPS                               |                             |      1 |      1 |     9  (12)|   1740 |00:00:08.30 |     103K|   9988 |
| 172 |                NESTED LOOPS                              |                             |      1 |      1 |     8  (13)|   6623 |00:00:00.63 |   76373 |    771 |
| 173 |                 VIEW                                     |                             |      1 |      1 |     7  (15)|   6623 |00:00:00.50 |   40253 |    771 |
| 174 |                  HASH UNIQUE                             |                             |      1 |      1 |     7  (15)|   6623 |00:00:00.50 |   40253 |    771 |
|*175 |                   FILTER                                 |                             |      1 |        |            |   6623 |00:00:00.49 |   40253 |    771 |
| 176 |                    NESTED LOOPS                          |                             |      1 |      1 |     3   (0)|  24024 |00:00:00.47 |   40146 |    759 |
| 177 |                     NESTED LOOPS                         |                             |      1 |      1 |     3   (0)|  24024 |00:00:00.13 |   17657 |    139 |
|*178 |                      INDEX RANGE SCAN                    | INT_INDIV                   |      1 |      1 |     2   (0)|  24024 |00:00:00.09 |     137 |    137 |
|*179 |                      INDEX UNIQUE SCAN                   | DOS_REFDOSS                 |  24024 |      1 |     1   (0)|  24024 |00:00:00.03 |   17520 |      2 |
| 180 |                     TABLE ACCESS BY INDEX ROWID          | G_DOSSIER                   |  24024 |      1 |     1   (0)|  24024 |00:00:00.33 |   22489 |    620 |
|*181 |                    FILTER                                |                             |     13 |        |            |      0 |00:00:00.01 |      91 |      6 |
|*182 |                     TABLE ACCESS FULL                    | V_INTERVENANTS              |     13 |      1 |     3   (0)|      0 |00:00:00.01 |      91 |      6 |
| 183 |                     TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*184 |                      INDEX RANGE SCAN                    | DOM_TYPVAL                  |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 185 |                    VIEW                                  | V_TDOMAINE                  |      4 |     37 |    37   (0)|      1 |00:00:00.01 |      16 |      6 |
| 186 |                     UNION-ALL                            |                             |      4 |        |            |      1 |00:00:00.01 |      16 |      6 |
|*187 |                      FILTER                              |                             |      4 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*188 |                       TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*189 |                        INDEX RANGE SCAN                  | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*190 |                      FILTER                              |                             |      4 |        |            |      1 |00:00:00.01 |      16 |      6 |
|*191 |                       TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE                   |      4 |      1 |     1   (0)|      1 |00:00:00.01 |      16 |      6 |
|*192 |                        INDEX RANGE SCAN                  | DOM_TYPABREV                |      4 |      1 |     1   (0)|      4 |00:00:00.01 |      12 |      2 |
|*193 |                      FILTER                              |                             |      3 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*194 |                       TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*195 |                        INDEX RANGE SCAN                  | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*196 |                      FILTER                              |                             |      3 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*197 |                       TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*198 |                        INDEX RANGE SCAN                  | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*199 |                      FILTER                              |                             |      3 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*200 |                       TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*201 |                        INDEX RANGE SCAN                  | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*202 |                      FILTER                              |                             |      3 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*203 |                       TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*204 |                        INDEX RANGE SCAN                  | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*205 |                      FILTER                              |                             |      3 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*206 |                       TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*207 |                        INDEX RANGE SCAN                  | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*208 |                      FILTER                              |                             |      3 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*209 |                       TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*210 |                        INDEX RANGE SCAN                  | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*211 |                      FILTER                              |                             |      3 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*212 |                       TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*213 |                        INDEX RANGE SCAN                  | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*214 |                      FILTER                              |                             |      3 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*215 |                       TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*216 |                        INDEX RANGE SCAN                  | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*217 |                      FILTER                              |                             |      3 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*218 |                       TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*219 |                        INDEX RANGE SCAN                  | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*220 |                      FILTER                              |                             |      3 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*221 |                       TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*222 |                        INDEX RANGE SCAN                  | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*223 |                      FILTER                              |                             |      3 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*224 |                       TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*225 |                        INDEX RANGE SCAN                  | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*226 |                      FILTER                              |                             |      3 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*227 |                       TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*228 |                        INDEX RANGE SCAN                  | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*229 |                      FILTER                              |                             |      3 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*230 |                       TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*231 |                        INDEX RANGE SCAN                  | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*232 |                      FILTER                              |                             |      3 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*233 |                       TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*234 |                        INDEX RANGE SCAN                  | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*235 |                      FILTER                              |                             |      3 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*236 |                       TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*237 |                        INDEX RANGE SCAN                  | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*238 |                      FILTER                              |                             |      3 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*239 |                       TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*240 |                        INDEX RANGE SCAN                  | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*241 |                      FILTER                              |                             |      3 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*242 |                       TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*243 |                        INDEX RANGE SCAN                  | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*244 |                      FILTER                              |                             |      3 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*245 |                       TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*246 |                        INDEX RANGE SCAN                  | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*247 |                      FILTER                              |                             |      3 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*248 |                       TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*249 |                        INDEX RANGE SCAN                  | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*250 |                      FILTER                              |                             |      3 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*251 |                       TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*252 |                        INDEX RANGE SCAN                  | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*253 |                      FILTER                              |                             |      3 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*254 |                       TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*255 |                        INDEX RANGE SCAN                  | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*256 |                      FILTER                              |                             |      3 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*257 |                       TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*258 |                        INDEX RANGE SCAN                  | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*259 |                      FILTER                              |                             |      3 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*260 |                       TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*261 |                        INDEX RANGE SCAN                  | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*262 |                      FILTER                              |                             |      3 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*263 |                       TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*264 |                        INDEX RANGE SCAN                  | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*265 |                      FILTER                              |                             |      3 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*266 |                       TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*267 |                        INDEX RANGE SCAN                  | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*268 |                      FILTER                              |                             |      3 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*269 |                       TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*270 |                        INDEX RANGE SCAN                  | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*271 |                      FILTER                              |                             |      3 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*272 |                       TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*273 |                        INDEX RANGE SCAN                  | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*274 |                      FILTER                              |                             |      3 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*275 |                       TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*276 |                        INDEX RANGE SCAN                  | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*277 |                      FILTER                              |                             |      3 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*278 |                       TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*279 |                        INDEX RANGE SCAN                  | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*280 |                      FILTER                              |                             |      3 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*281 |                       TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*282 |                        INDEX RANGE SCAN                  | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*283 |                      FILTER                              |                             |      3 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*284 |                       TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*285 |                        INDEX RANGE SCAN                  | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*286 |                      FILTER                              |                             |      3 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*287 |                       TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*288 |                        INDEX RANGE SCAN                  | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*289 |                      FILTER                              |                             |      3 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*290 |                       TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*291 |                        INDEX RANGE SCAN                  | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*292 |                      FILTER                              |                             |      3 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*293 |                       TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*294 |                        INDEX RANGE SCAN                  | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*295 |                      FILTER                              |                             |      3 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*296 |                       TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*297 |                        INDEX RANGE SCAN                  | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 298 |                 TABLE ACCESS BY INDEX ROWID              | G_DOSSIER                   |   6623 |      1 |     1   (0)|   6623 |00:00:00.12 |   36120 |      0 |
|*299 |                  INDEX UNIQUE SCAN                       | DOS_REFDOSS                 |   6623 |      1 |     1   (0)|   6623 |00:00:00.05 |   13025 |      0 |
|*300 |                TABLE ACCESS BY INDEX ROWID BATCHED       | G_PIECE                     |   6623 |      1 |     1   (0)|   1740 |00:00:07.66 |   27242 |   9217 |
|*301 |                 INDEX RANGE SCAN                         | PIE_REFDOSS                 |   6623 |      1 |     1   (0)|   6623 |00:00:03.18 |   13594 |   4058 |
|*302 |               INDEX RANGE SCAN                           | INT_REFDOSS                 |   1740 |      1 |     1   (0)|   1740 |00:00:00.25 |    3497 |    347 |
|*303 |              INDEX RANGE SCAN                            | INT_REFDOSS                 |   1740 |      1 |     1   (0)|   1740 |00:00:00.01 |    3496 |      6 |
| 304 |             TABLE ACCESS BY INDEX ROWID BATCHED          | T_ATTENTE                   |   1740 |      1 |     1   (0)|   1740 |00:00:00.19 |    4951 |    351 |
|*305 |              INDEX RANGE SCAN                            | PK_ATTENTE                  |   1740 |      1 |     1   (0)|   1740 |00:00:00.18 |    3355 |    351 |
| 306 |            TABLE ACCESS BY INDEX ROWID                   | G_INDIVIDU                  |   1740 |      1 |     1   (0)|   1740 |00:00:00.01 |      17 |      1 |
|*307 |             INDEX UNIQUE SCAN                            | IND_REFINDIV                |   1740 |      1 |     1   (0)|   1740 |00:00:00.01 |      14 |      0 |
| 308 |           TABLE ACCESS BY INDEX ROWID                    | G_INDIVIDU                  |   1740 |      1 |     1   (0)|   1740 |00:00:01.22 |    7522 |   1346 |
|*309 |            INDEX UNIQUE SCAN                             | IND_REFINDIV                |   1740 |      1 |     1   (0)|   1740 |00:00:00.34 |    3483 |    515 |
| 310 |          VIEW                                            |                             |      1 |    114 |     5   (0)|   4396 |00:00:00.01 |       0 |      0 |
| 311 |           TABLE ACCESS FULL                              | SYS_TEMP_0FD9E0415_D8F21C32 |      1 |    114 |     5   (0)|   4396 |00:00:00.01 |       0 |      0 |
| 312 |         VIEW                                             | V_TDOMAINE                  |   1740 |     21 |    37   (0)|    151 |00:00:00.05 |    5230 |      6 |
| 313 |          UNION ALL PUSHED PREDICATE                      |                             |   1740 |        |            |    151 |00:00:00.04 |    5230 |      6 |
|*314 |           FILTER                                         |                             |   1740 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*315 |            TABLE ACCESS BY INDEX ROWID BATCHED           | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*316 |             INDEX RANGE SCAN                             | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*317 |           FILTER                                         |                             |   1740 |        |            |    151 |00:00:00.01 |    5230 |      6 |
|*318 |            TABLE ACCESS BY INDEX ROWID BATCHED           | V_DOMAINE                   |   1740 |      1 |     1   (0)|    151 |00:00:00.01 |    5230 |      6 |
|*319 |             INDEX RANGE SCAN                             | DOM_TYPABREV                |   1740 |      1 |     1   (0)|   1740 |00:00:00.01 |    1750 |      3 |
|*320 |           FILTER                                         |                             |   1589 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*321 |            TABLE ACCESS BY INDEX ROWID BATCHED           | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*322 |             INDEX RANGE SCAN                             | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*323 |           FILTER                                         |                             |   1589 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*324 |            TABLE ACCESS BY INDEX ROWID BATCHED           | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*325 |             INDEX RANGE SCAN                             | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*326 |           FILTER                                         |                             |   1589 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*327 |            TABLE ACCESS BY INDEX ROWID BATCHED           | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*328 |             INDEX RANGE SCAN                             | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*329 |           FILTER                                         |                             |   1589 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*330 |            TABLE ACCESS BY INDEX ROWID BATCHED           | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*331 |             INDEX RANGE SCAN                             | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*332 |           FILTER                                         |                             |   1589 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*333 |            TABLE ACCESS BY INDEX ROWID BATCHED           | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*334 |             INDEX RANGE SCAN                             | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*335 |           FILTER                                         |                             |   1589 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*336 |            TABLE ACCESS BY INDEX ROWID BATCHED           | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*337 |             INDEX RANGE SCAN                             | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*338 |           FILTER                                         |                             |   1589 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*339 |            TABLE ACCESS BY INDEX ROWID BATCHED           | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*340 |             INDEX RANGE SCAN                             | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*341 |           FILTER                                         |                             |   1589 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*342 |            TABLE ACCESS BY INDEX ROWID BATCHED           | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*343 |             INDEX RANGE SCAN                             | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*344 |           FILTER                                         |                             |   1589 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*345 |            TABLE ACCESS BY INDEX ROWID BATCHED           | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*346 |             INDEX RANGE SCAN                             | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*347 |           FILTER                                         |                             |   1589 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*348 |            TABLE ACCESS BY INDEX ROWID BATCHED           | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*349 |             INDEX RANGE SCAN                             | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*350 |           FILTER                                         |                             |   1589 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*351 |            TABLE ACCESS BY INDEX ROWID BATCHED           | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*352 |             INDEX RANGE SCAN                             | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*353 |           FILTER                                         |                             |   1589 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*354 |            TABLE ACCESS BY INDEX ROWID BATCHED           | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*355 |             INDEX RANGE SCAN                             | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*356 |           FILTER                                         |                             |   1589 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*357 |            TABLE ACCESS BY INDEX ROWID BATCHED           | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*358 |             INDEX RANGE SCAN                             | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*359 |           FILTER                                         |                             |   1589 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*360 |            TABLE ACCESS BY INDEX ROWID BATCHED           | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*361 |             INDEX RANGE SCAN                             | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*362 |           FILTER                                         |                             |   1589 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*363 |            TABLE ACCESS BY INDEX ROWID BATCHED           | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*364 |             INDEX RANGE SCAN                             | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*365 |           FILTER                                         |                             |   1589 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*366 |            TABLE ACCESS BY INDEX ROWID BATCHED           | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*367 |             INDEX RANGE SCAN                             | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*368 |           FILTER                                         |                             |   1589 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*369 |            TABLE ACCESS BY INDEX ROWID BATCHED           | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*370 |             INDEX RANGE SCAN                             | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*371 |           FILTER                                         |                             |   1589 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*372 |            TABLE ACCESS BY INDEX ROWID BATCHED           | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*373 |             INDEX RANGE SCAN                             | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*374 |           FILTER                                         |                             |   1589 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*375 |            TABLE ACCESS BY INDEX ROWID BATCHED           | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*376 |             INDEX RANGE SCAN                             | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*377 |           FILTER                                         |                             |   1589 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*378 |            TABLE ACCESS BY INDEX ROWID BATCHED           | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*379 |             INDEX RANGE SCAN                             | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*380 |           FILTER                                         |                             |   1589 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*381 |            TABLE ACCESS BY INDEX ROWID BATCHED           | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*382 |             INDEX RANGE SCAN                             | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*383 |           FILTER                                         |                             |   1589 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*384 |            TABLE ACCESS BY INDEX ROWID BATCHED           | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*385 |             INDEX RANGE SCAN                             | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*386 |           FILTER                                         |                             |   1589 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*387 |            TABLE ACCESS BY INDEX ROWID BATCHED           | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*388 |             INDEX RANGE SCAN                             | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*389 |           FILTER                                         |                             |   1589 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*390 |            TABLE ACCESS BY INDEX ROWID BATCHED           | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*391 |             INDEX RANGE SCAN                             | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*392 |           FILTER                                         |                             |   1589 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*393 |            TABLE ACCESS BY INDEX ROWID BATCHED           | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*394 |             INDEX RANGE SCAN                             | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*395 |           FILTER                                         |                             |   1589 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*396 |            TABLE ACCESS BY INDEX ROWID BATCHED           | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*397 |             INDEX RANGE SCAN                             | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*398 |           FILTER                                         |                             |   1589 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*399 |            TABLE ACCESS BY INDEX ROWID BATCHED           | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*400 |             INDEX RANGE SCAN                             | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*401 |           FILTER                                         |                             |   1589 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*402 |            TABLE ACCESS BY INDEX ROWID BATCHED           | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*403 |             INDEX RANGE SCAN                             | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*404 |           FILTER                                         |                             |   1589 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*405 |            TABLE ACCESS BY INDEX ROWID BATCHED           | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*406 |             INDEX RANGE SCAN                             | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*407 |           FILTER                                         |                             |   1589 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*408 |            TABLE ACCESS BY INDEX ROWID BATCHED           | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*409 |             INDEX RANGE SCAN                             | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*410 |           FILTER                                         |                             |   1589 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*411 |            TABLE ACCESS BY INDEX ROWID BATCHED           | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*412 |             INDEX RANGE SCAN                             | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*413 |           FILTER                                         |                             |   1589 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*414 |            TABLE ACCESS BY INDEX ROWID BATCHED           | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*415 |             INDEX RANGE SCAN                             | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*416 |           FILTER                                         |                             |   1589 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*417 |            TABLE ACCESS BY INDEX ROWID BATCHED           | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*418 |             INDEX RANGE SCAN                             | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*419 |           FILTER                                         |                             |   1589 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*420 |            TABLE ACCESS BY INDEX ROWID BATCHED           | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*421 |             INDEX RANGE SCAN                             | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*422 |           FILTER                                         |                             |   1589 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*423 |            TABLE ACCESS BY INDEX ROWID BATCHED           | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*424 |             INDEX RANGE SCAN                             | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*425 |        INDEX RANGE SCAN                                  | G_INDIVPARAM_REFIND         |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
------------------------------------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   1 - filter(ROWNUM=1)
   5 - access("CMP"."REFPERSO"=:B1)
   6 - access("CMI"."REFINDIVIDU"="CMP"."REFINDIVIDU")
   9 - filter( IS NOT NULL)
  13 - filter(("VF"."ECRAN" IS NOT NULL AND "VF"."ABREV16"='O'))
  14 - access("VF"."TYPE"='filiere')
  17 - access("REFDOSS"=:B1)
  18 - access("VT"."TYPE"='typencour' AND "VF"."ECRAN"="VT"."ABREV" AND "LIBELLE"="VT"."VALEUR")
       filter(("VT"."VALEUR" IS NOT NULL AND "VT"."ABREV" IS NOT NULL))
  19 - filter(ROWNUM=1)
  23 - access("SMP"."REFPERSO"=TO_NUMBER(:B1))
  24 - access("SMI"."REFINDIVIDU"="SMP"."REFINDIVIDU")
  27 - filter(((:B1 IS NOT NULL AND "FI"."CREATEUR"='cfc_migration') OR (:B2 IS NULL AND TRUNC(INTERNAL_FUNCTION("DTJOUR_DT"))=NVL(TRUNC(:B3),TRUNC(:B4)))))
  28 - access("FI"."REFDOSS"=:B1)
  33 - access("PSU"."REFPERSO"=:B1)
  34 - access("ISU"."REFINDIVIDU"="PSU"."REFINDIVIDU")
  38 - access("V"."F"="PFX"."F")
  48 - filter('AL'=:B1)
  50 - access("TYPE"='typencour')
  51 - filter('AN'=:B1)
  53 - access("TYPE"='typencour')
  54 - filter('AR'=:B1)
  56 - access("TYPE"='typencour')
  57 - filter('BG'=:B1)
  59 - access("TYPE"='typencour')
  60 - filter('BR'=:B1)
  62 - access("TYPE"='typencour')
  63 - filter('CE'=:B1)
  65 - access("TYPE"='typencour')
  66 - filter('CH'=:B1)
  68 - access("TYPE"='typencour')
  69 - filter('CS'=:B1)
  71 - access("TYPE"='typencour')
  72 - filter('DA'=:B1)
  74 - access("TYPE"='typencour')
  75 - filter('EL'=:B1)
  77 - access("TYPE"='typencour')
  78 - filter('ES'=:B1)
  80 - access("TYPE"='typencour')
  81 - filter('ET'=:B1)
  83 - access("TYPE"='typencour')
  84 - filter('FI'=:B1)
  86 - access("TYPE"='typencour')
  87 - filter('FL'=:B1)
  89 - access("TYPE"='typencour')
  90 - filter('FR'=:B1)
  92 - access("TYPE"='typencour')
  93 - filter('HR'=:B1)
  95 - access("TYPE"='typencour')
  96 - filter('HU'=:B1)
  98 - access("TYPE"='typencour')
  99 - filter('IT'=:B1)
 101 - access("TYPE"='typencour')
 102 - filter('IW'=:B1)
 104 - access("TYPE"='typencour')
 105 - filter('JA'=:B1)
 107 - access("TYPE"='typencour')
 108 - filter('LT'=:B1)
 110 - access("TYPE"='typencour')
 111 - filter('LV'=:B1)
 113 - access("TYPE"='typencour')
 114 - filter('MX'=:B1)
 116 - access("TYPE"='typencour')
 117 - filter('NL'=:B1)
 119 - access("TYPE"='typencour')
 120 - filter('NO'=:B1)
 122 - access("TYPE"='typencour')
 123 - filter('PL'=:B1)
 125 - access("TYPE"='typencour')
 126 - filter('PT'=:B1)
 128 - access("TYPE"='typencour')
 129 - filter('RO'=:B1)
 131 - access("TYPE"='typencour')
 132 - filter('RU'=:B1)
 134 - access("TYPE"='typencour')
 135 - filter('SK'=:B1)
 137 - access("TYPE"='typencour')
 138 - filter('SL'=:B1)
 140 - access("TYPE"='typencour')
 141 - filter('SR'=:B1)
 143 - access("TYPE"='typencour')
 144 - filter('SV'=:B1)
 146 - access("TYPE"='typencour')
 147 - filter('TR'=:B1)
 149 - access("TYPE"='typencour')
 150 - filter('US'=:B1)
 152 - access("TYPE"='typencour')
 153 - filter('VI'=:B1)
 155 - access("TYPE"='typencour')
 156 - filter('ZH'=:B1)
 158 - access("TYPE"='typencour')
 159 - filter("RNUM">=:B17)
 160 - filter(ROWNUM<=:B16)
 163 - filter(("IDB"."STR36" IS NULL OR  IS NOT NULL))
 165 - access("TPNCR"."PFX_VALEUR"="ATT"."TYPENCOUR")
 175 - filter(( IS NOT NULL OR  IS NOT NULL))
 178 - access("T"."REFINDIVIDU"=:B10)
       filter("T"."REFTYPE"<>'XX')
 179 - access("GD"."REFDOSS"="T"."REFDOSS")
 181 - filter(("CATEGDOSS" IS NULL OR "CATEGDOSS"=))
 182 - filter(("REFTYPE_BD"=:B1 AND "REFTYPE_AFF" LIKE :B6))
 184 - access("VALEUR"=:B1 AND "TYPE"=:B5)
 187 - filter('AL'=:B8)
 188 - filter("ABREV_AL" LIKE :B9)
 189 - access("TYPE"=:B7 AND "ABREV"=:B1)
 190 - filter('AN'=:B8)
 191 - filter("ABREV_AN" LIKE :B9)
 192 - access("TYPE"=:B7 AND "ABREV"=:B1)
 193 - filter('AR'=:B8)
 194 - filter("ABREV_AR" LIKE :B9)
 195 - access("TYPE"=:B7 AND "ABREV"=:B1)
 196 - filter('BG'=:B8)
 197 - filter("ABREV_BG" LIKE :B9)
 198 - access("TYPE"=:B7 AND "ABREV"=:B1)
 199 - filter('BR'=:B8)
 200 - filter("ABREV_BR" LIKE :B9)
 201 - access("TYPE"=:B7 AND "ABREV"=:B1)
 202 - filter('CE'=:B8)
 203 - filter("ABREV_CE" LIKE :B9)
 204 - access("TYPE"=:B7 AND "ABREV"=:B1)
 205 - filter('CH'=:B8)
 206 - filter("ABREV_CH" LIKE :B9)
 207 - access("TYPE"=:B7 AND "ABREV"=:B1)
 208 - filter('CS'=:B8)
 209 - filter("ABREV_CS" LIKE :B9)
 210 - access("TYPE"=:B7 AND "ABREV"=:B1)
 211 - filter('DA'=:B8)
 212 - filter("ABREV_DA" LIKE :B9)
 213 - access("TYPE"=:B7 AND "ABREV"=:B1)
 214 - filter('EL'=:B8)
 215 - filter("ABREV_EL" LIKE :B9)
 216 - access("TYPE"=:B7 AND "ABREV"=:B1)
 217 - filter('ES'=:B8)
 218 - filter("ABREV_ES" LIKE :B9)
 219 - access("TYPE"=:B7 AND "ABREV"=:B1)
 220 - filter('ET'=:B8)
 221 - filter("ABREV_ET" LIKE :B9)
 222 - access("TYPE"=:B7 AND "ABREV"=:B1)
 223 - filter('FI'=:B8)
 224 - filter("ABREV_FI" LIKE :B9)
 225 - access("TYPE"=:B7 AND "ABREV"=:B1)
 226 - filter('FL'=:B8)
 227 - filter("ABREV_FL" LIKE :B9)
 228 - access("TYPE"=:B7 AND "ABREV"=:B1)
 229 - filter('FR'=:B8)
 230 - filter(NVL("ABREV_FR","ABREV") LIKE :B9)
 231 - access("TYPE"=:B7 AND "ABREV"=:B1)
 232 - filter('HR'=:B8)
 233 - filter("ABREV_HR" LIKE :B9)
 234 - access("TYPE"=:B7 AND "ABREV"=:B1)
 235 - filter('HU'=:B8)
 236 - filter("ABREV_HU" LIKE :B9)
 237 - access("TYPE"=:B7 AND "ABREV"=:B1)
 238 - filter('IT'=:B8)
 239 - filter("ABREV_IT" LIKE :B9)
 240 - access("TYPE"=:B7 AND "ABREV"=:B1)
 241 - filter('IW'=:B8)
 242 - filter("ABREV_IW" LIKE :B9)
 243 - access("TYPE"=:B7 AND "ABREV"=:B1)
 244 - filter('JA'=:B8)
 245 - filter("ABREV_JA" LIKE :B9)
 246 - access("TYPE"=:B7 AND "ABREV"=:B1)
 247 - filter('LT'=:B8)
 248 - filter("ABREV_LT" LIKE :B9)
 249 - access("TYPE"=:B7 AND "ABREV"=:B1)
 250 - filter('LV'=:B8)
 251 - filter("ABREV_LV" LIKE :B9)
 252 - access("TYPE"=:B7 AND "ABREV"=:B1)
 253 - filter('MX'=:B8)
 254 - filter("ABREV_MX" LIKE :B9)
 255 - access("TYPE"=:B7 AND "ABREV"=:B1)
 256 - filter('NL'=:B8)
 257 - filter("ABREV_NL" LIKE :B9)
 258 - access("TYPE"=:B7 AND "ABREV"=:B1)
 259 - filter('NO'=:B8)
 260 - filter("ABREV_NO" LIKE :B9)
 261 - access("TYPE"=:B7 AND "ABREV"=:B1)
 262 - filter('PL'=:B8)
 263 - filter("ABREV_PL" LIKE :B9)
 264 - access("TYPE"=:B7 AND "ABREV"=:B1)
 265 - filter('PT'=:B8)
 266 - filter("ABREV_PT" LIKE :B9)
 267 - access("TYPE"=:B7 AND "ABREV"=:B1)
 268 - filter('RO'=:B8)
 269 - filter("ABREV_RO" LIKE :B9)
 270 - access("TYPE"=:B7 AND "ABREV"=:B1)
 271 - filter('RU'=:B8)
 272 - filter("ABREV_RU" LIKE :B9)
 273 - access("TYPE"=:B7 AND "ABREV"=:B1)
 274 - filter('SK'=:B8)
 275 - filter("ABREV_SK" LIKE :B9)
 276 - access("TYPE"=:B7 AND "ABREV"=:B1)
 277 - filter('SL'=:B8)
 278 - filter("ABREV_SL" LIKE :B9)
 279 - access("TYPE"=:B7 AND "ABREV"=:B1)
 280 - filter('SR'=:B8)
 281 - filter("ABREV_SR" LIKE :B9)
 282 - access("TYPE"=:B7 AND "ABREV"=:B1)
 283 - filter('SV'=:B8)
 284 - filter("ABREV_SV" LIKE :B9)
 285 - access("TYPE"=:B7 AND "ABREV"=:B1)
 286 - filter('TR'=:B8)
 287 - filter("ABREV_TR" LIKE :B9)
 288 - access("TYPE"=:B7 AND "ABREV"=:B1)
 289 - filter('US'=:B8)
 290 - filter("ABREV_US" LIKE :B9)
 291 - access("TYPE"=:B7 AND "ABREV"=:B1)
 292 - filter('VI'=:B8)
 293 - filter("ABREV_VI" LIKE :B9)
 294 - access("TYPE"=:B7 AND "ABREV"=:B1)
 295 - filter('ZH'=:B8)
 296 - filter("ABREV_ZH" LIKE :B9)
 297 - access("TYPE"=:B7 AND "ABREV"=:B1)
 299 - access("D"."REFDOSS"="DF"."REFDOSS")
 300 - filter("GP"."ST24"=:B15)
 301 - access("GP"."REFDOSS"="D"."REFDOSS" AND "GP"."TYPPIECE"='RECOUVREMENT')
 302 - access("TCL"."REFDOSS"="D"."REFDOSS" AND "TCL"."REFTYPE"='CL')
 303 - access("TDB"."REFDOSS"="D"."REFDOSS" AND "TDB"."REFTYPE"=:B11)
 305 - access("ATT"."REFENTITE"="D"."REFDOSS")
 307 - access("ICL"."REFINDIVIDU"="TCL"."REFINDIVIDU")
 309 - access("IDB"."REFINDIVIDU"="TDB"."REFINDIVIDU")
 314 - filter('AL'=:B3)
 315 - filter("VALEUR_AL" LIKE :B14)
 316 - access("TYPE"='STRAT' AND "ABREV"="D"."STRATIF")
 317 - filter('AN'=:B3)
 318 - filter("VALEUR_AN" LIKE :B14)
 319 - access("TYPE"='STRAT' AND "ABREV"="D"."STRATIF")
 320 - filter('AR'=:B3)
 321 - filter("VALEUR_AR" LIKE :B14)
 322 - access("TYPE"='STRAT' AND "ABREV"="D"."STRATIF")
 323 - filter('BG'=:B3)
 324 - filter("VALEUR_BG" LIKE :B14)
 325 - access("TYPE"='STRAT' AND "ABREV"="D"."STRATIF")
 326 - filter('BR'=:B3)
 327 - filter("VALEUR_BR" LIKE :B14)
 328 - access("TYPE"='STRAT' AND "ABREV"="D"."STRATIF")
 329 - filter('CE'=:B3)
 330 - filter("VALEUR_CE" LIKE :B14)
 331 - access("TYPE"='STRAT' AND "ABREV"="D"."STRATIF")
 332 - filter('CH'=:B3)
 333 - filter("VALEUR_CH" LIKE :B14)
 334 - access("TYPE"='STRAT' AND "ABREV"="D"."STRATIF")
 335 - filter('CS'=:B3)
 336 - filter("VALEUR_CS" LIKE :B14)
 337 - access("TYPE"='STRAT' AND "ABREV"="D"."STRATIF")
 338 - filter('DA'=:B3)
 339 - filter("VALEUR_DA" LIKE :B14)
 340 - access("TYPE"='STRAT' AND "ABREV"="D"."STRATIF")
 341 - filter('EL'=:B3)
 342 - filter("VALEUR_EL" LIKE :B14)
 343 - access("TYPE"='STRAT' AND "ABREV"="D"."STRATIF")
 344 - filter('ES'=:B3)
 345 - filter("VALEUR_ES" LIKE :B14)
 346 - access("TYPE"='STRAT' AND "ABREV"="D"."STRATIF")
 347 - filter('ET'=:B3)
 348 - filter("VALEUR_ET" LIKE :B14)
 349 - access("TYPE"='STRAT' AND "ABREV"="D"."STRATIF")
 350 - filter('FI'=:B3)
 351 - filter("VALEUR_FI" LIKE :B14)
 352 - access("TYPE"='STRAT' AND "ABREV"="D"."STRATIF")
 353 - filter('FL'=:B3)
 354 - filter("VALEUR_FL" LIKE :B14)
 355 - access("TYPE"='STRAT' AND "ABREV"="D"."STRATIF")
 356 - filter('FR'=:B3)
 357 - filter(NVL("VALEUR_FR","VALEUR") LIKE :B14)
 358 - access("TYPE"='STRAT' AND "ABREV"="D"."STRATIF")
 359 - filter('HR'=:B3)
 360 - filter("VALEUR_HR" LIKE :B14)
 361 - access("TYPE"='STRAT' AND "ABREV"="D"."STRATIF")
 362 - filter('HU'=:B3)
 363 - filter("VALEUR_HU" LIKE :B14)
 364 - access("TYPE"='STRAT' AND "ABREV"="D"."STRATIF")
 365 - filter('IT'=:B3)
 366 - filter("VALEUR_IT" LIKE :B14)
 367 - access("TYPE"='STRAT' AND "ABREV"="D"."STRATIF")
 368 - filter('IW'=:B3)
 369 - filter("VALEUR_IW" LIKE :B14)
 370 - access("TYPE"='STRAT' AND "ABREV"="D"."STRATIF")
 371 - filter('JA'=:B3)
 372 - filter("VALEUR_JA" LIKE :B14)
 373 - access("TYPE"='STRAT' AND "ABREV"="D"."STRATIF")
 374 - filter('LT'=:B3)
 375 - filter("VALEUR_LT" LIKE :B14)
 376 - access("TYPE"='STRAT' AND "ABREV"="D"."STRATIF")
 377 - filter('LV'=:B3)
 378 - filter("VALEUR_LV" LIKE :B14)
 379 - access("TYPE"='STRAT' AND "ABREV"="D"."STRATIF")
 380 - filter('MX'=:B3)
 381 - filter("VALEUR_MX" LIKE :B14)
 382 - access("TYPE"='STRAT' AND "ABREV"="D"."STRATIF")
 383 - filter('NL'=:B3)
 384 - filter("VALEUR_NL" LIKE :B14)
 385 - access("TYPE"='STRAT' AND "ABREV"="D"."STRATIF")
 386 - filter('NO'=:B3)
 387 - filter("VALEUR_NO" LIKE :B14)
 388 - access("TYPE"='STRAT' AND "ABREV"="D"."STRATIF")
 389 - filter('PL'=:B3)
 390 - filter("VALEUR_PL" LIKE :B14)
 391 - access("TYPE"='STRAT' AND "ABREV"="D"."STRATIF")
 392 - filter('PT'=:B3)
 393 - filter("VALEUR_PT" LIKE :B14)
 394 - access("TYPE"='STRAT' AND "ABREV"="D"."STRATIF")
 395 - filter('RO'=:B3)
 396 - filter("VALEUR_RO" LIKE :B14)
 397 - access("TYPE"='STRAT' AND "ABREV"="D"."STRATIF")
 398 - filter('RU'=:B3)
 399 - filter("VALEUR_RU" LIKE :B14)
 400 - access("TYPE"='STRAT' AND "ABREV"="D"."STRATIF")
 401 - filter('SK'=:B3)
 402 - filter("VALEUR_SK" LIKE :B14)
 403 - access("TYPE"='STRAT' AND "ABREV"="D"."STRATIF")
 404 - filter('SL'=:B3)
 405 - filter("VALEUR_SL" LIKE :B14)
 406 - access("TYPE"='STRAT' AND "ABREV"="D"."STRATIF")
 407 - filter('SR'=:B3)
 408 - filter("VALEUR_SR" LIKE :B14)
 409 - access("TYPE"='STRAT' AND "ABREV"="D"."STRATIF")
 410 - filter('SV'=:B3)
 411 - filter("VALEUR_SV" LIKE :B14)
 412 - access("TYPE"='STRAT' AND "ABREV"="D"."STRATIF")
 413 - filter('TR'=:B3)
 414 - filter("VALEUR_TR" LIKE :B14)
 415 - access("TYPE"='STRAT' AND "ABREV"="D"."STRATIF")
 416 - filter('US'=:B3)
 417 - filter("VALEUR_US" LIKE :B14)
 418 - access("TYPE"='STRAT' AND "ABREV"="D"."STRATIF")
 419 - filter('VI'=:B3)
 420 - filter("VALEUR_VI" LIKE :B14)
 421 - access("TYPE"='STRAT' AND "ABREV"="D"."STRATIF")
 422 - filter('ZH'=:B3)
 423 - filter("VALEUR_ZH" LIKE :B14)
 424 - access("TYPE"='STRAT' AND "ABREV"="D"."STRATIF")
 425 - access("REFINDIVIDU"=:B12 AND "TYPE"='type_indiv' AND "STR1"=:B1)
       filter("STR1"=:B1)
*/
/********************************New Metrics***************************************/

/********************************Index statistics**********************************/

/********************************Other SQLs****************************************/          
/*

*/ 
/********************************Other SQLs****************************************/              
