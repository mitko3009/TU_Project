dbspicfg -e

opctemplate -l


           FILTER 16 "TABLESPACE_NAME not like '%UNDO%' and TABLESPACE_NAME not like '%TEMP%' and TABLESPACE_NAME not like '%TMP%'"
		   


[root@sebmmx0004 ~]#
[root@sebmmx0004 ~]#
[root@sebmmx0004 ~]# ps -ef | grep pmon
grid      4406     1  0 Apr24 ?        00:08:15 asm_pmon_+ASM
oracle   18727     1  0 Apr24 ?        00:10:57 ora_pmon_GISPROD
root     22510 22470  0 17:12 pts/1    00:00:00 grep --color=auto pmon
[root@sebmmx0004 ~]#
[root@sebmmx0004 ~]#
[root@sebmmx0004 ~]# dbspicao -pdvf
Checking instance: 'GISPROD' @ '/u01/app/oracle/product/12.2.0':
        Connect:         OKAY
        Filter 6:        OKAY

[root@sebmmx0004 ~]# opctemplate -l
       * List installed policies for host 'localhost'.

  Type              Name                        Status     Version
 --------------------------------------------------------------------
CONFIGSETTINGS      "OVO settings"              enabled    1
LOGFILE             "UXMON_SelfCheck_Logfile"   enabled    0001.0000
LOGFILE             "UXMON_actmon_PRE"          enabled    0001.0000
LOGFILE             "UXMON_bondmon_DFT"         enabled    0001.0000
LOGFILE             "UXMON_bootmon_DFT"         enabled    0001.0001
LOGFILE             "UXMON_cronmon_PRE"         enabled    0001.0000
LOGFILE             "UXMON_dfmon_PRE"           enabled    0001.0001
LOGFILE             "UXMON_dmsg_LINUX_PRE"      enabled    0001.0002
LOGFILE             "UXMON_hwmon_DFT"           enabled    0001.0000
LOGFILE             "UXMON_ktsmon_PRE"          enabled    0001.0000
LOGFILE             "UXMON_loopmon_DFT"         enabled    0001.0001
LOGFILE             "UXMON_lpmon_DFT"           enabled    0001.0000
LOGFILE             "UXMON_lx_hw_syslog_PRE"    enabled    0001.0004
LOGFILE             "UXMON_lx_rhcluster_syslog_PRE"   enabled    0001.0000
LOGFILE             "UXMON_mdmon_DFT"           enabled    0001.0000
LOGFILE             "UXMON_mpmon_DFT"           enabled    0001.0000
LOGFILE             "UXMON_nfsmon_PRE"          enabled    0001.0000
LOGFILE             "UXMON_nicmon_DFT"          enabled    0001.0000
LOGFILE             "UXMON_ntpmon_DFT"          enabled    0001.0000
LOGFILE             "UXMON_perfmon_PRE"         enabled    0001.0002
LOGFILE             "UXMON_psmon_PRE"           enabled    0001.0000
LOGFILE             "UXMON_rcmon_DFT"           enabled    0001.0000
LOGFILE             "UXMON_scmon_PRE"           enabled    0001.0000
LOGFILE             "UXMON_sgmon_PRE"           enabled    0001.0000
LOGFILE             "UXMON_sshdmon_DFT"         enabled    0001.0000
LOGFILE             "UXMON_swapmon_PRE"         enabled    0001.0000
LOGFILE             "UXMON_tdfmon_DFT"          enabled    0001.0000
LOGFILE             "UXMON_vcmon_DFT"           enabled    0001.0000
LOGFILE             "UX_CheckIfLocalConfigFilesExist"   enabled    0001.0000
LOGFILE             "WW-DBMON ODR Monitoring"   enabled    0001.0000
LOGFILE             "WW-DBMON Oracle Alert Log"   enabled    0001.0000
LOGFILE             "WW-DBMON Self Monitoring Logfile"   enabled    0001.0000
LOGFILE             "lddt-stamp-parser-agent"   enabled    0001.0000
  mgrconf           "OVO authorization"         enabled    1
MONITOR             "WW-DBMON-OPCMON-CATCHER"   enabled    0001.0000
OPCMSG              "HC-Msg_1"                  enabled    0001.0000
OPCMSG              "OpC-internal"              enabled    0011.0001
OPCMSG              "UXMON_SelfCheck_DFT"       enabled    0001.0000
OPCMSG              "WW-DBMON-METRICS"          enabled    0001.0000
OPCMSG              "WW-DBMON-Messages"         enabled    0001.0000
OPCMSG              "WW-DBMON-STATUS"           enabled    0001.0000
OPCMSG              "opcmsg-general"            enabled    0011.0001
SCHEDULE            "(UX) Run Ora ww_dbmon"     enabled    0001.0000
SCHEDULE            "(UX) WW-DBMON-Sync-UDM"    enabled    0001.0000
SCHEDULE            "HC:1h"                     enabled    0001.0000
SCHEDULE            "NODE-SYNC-CHECK-UX-INSTRUMENTATION-MD5-GENERATE"   enabled    0003.0007
SCHEDULE            "NODE-SYNC-CHECK-UX-POLICY-INFO-GENERATE"   enabled    0003.0007
SCHEDULE            "SPI_DC_Create_Links"       enabled    0001.0001
SCHEDULE            "UXMON_SCHEDULE_KTSMON"     enabled    0001.0000
SCHEDULE            "UXMON_SCHEDULE_LOOPMON"    enabled    0001.0000
SCHEDULE            "UXMON_SCHEDULE_PRE"        enabled    0001.0001
SCHEDULE            "UXMON_SCHEDULE_RCMON"      enabled    0001.0000
SCHEDULE            "UXMON_SCHEDULE_SELFCLEAN"   enabled    0001.0000
SCHEDULE            "UXMON_SCHEDULE_cronmon_PRE"   enabled    0001.0000
SCHEDULE            "UXMON_SCHEDULE_lpmon_DFT"   enabled    0001.0000
SCHEDULE            "UXMON_SCHEDULE_nfsmon_PRE"   enabled    0001.0000
SCHEDULE            "UXMON_SCHEDULE_nicmon_DFT"   enabled    0001.0000
SCHEDULE            "UXMON_SCHEDULE_scmon_PRE"   enabled    0001.0000
SCHEDULE            "UXMON_SCHEDULE_sgmon_PRE"   enabled    0001.0000
SCHEDULE            "UXMON_SCHEDULE_sshdmon_DFT"   enabled    0001.0000
SCHEDULE            "UXMON_SCHEDULE_vcmon_DFT"   enabled    0001.0000
SCHEDULE            "UXMON_SelfCheck_Activity"   enabled    0001.0000
SCHEDULE            "WW-DBConChk_DBSPI"         enabled    0001.0000
SNMPTRAP            "SIM-Steamagt-1521"         enabled    0001.0001
SNMPTRAP            "SIM-btAgent-1127"          enabled    0001.0001
SNMPTRAP            "SIM-generic-232"           enabled    0001.0001

[root@sebmmx0004 ~]# cat /etc/oratab
#Backup file is  /u01/app/grid/product/12.2.0/grid/srvm/admin/oratab.bak.sebmmx0004 line added by Agent
#



# This file is used by ORACLE utilities.  It is created by root.sh
# and updated by either Database Configuration Assistant while creating
# a database or ASM Configuration Assistant while creating ASM instance.

# A colon, ':', is used as the field terminator.  A new line terminates
# the entry.  Lines beginning with a pound sign, '#', are comments.
#
# Entries are of the form:
#   $ORACLE_SID:$ORACLE_HOME:<N|Y>:
#
# The first and second fields are the system identifier and home
# directory of the database respectively.  The third field indicates
# to the dbstart utility that the database should , "Y", or should not,
# "N", be brought up at system boot time.
#
# Multiple entries with the same $ORACLE_SID are not allowed.
#
#
+ASM:/u01/app/grid/product/12.2.0/grid:N                # line added by Agent
GISPROD:/u01/app/oracle/product/12.2.0:N
[root@sebmmx0004 ~]#
[root@sebmmx0004 ~]#
[root@sebmmx0004 ~]# vi /etc/oratab
[root@sebmmx0004 ~]# cat /etc/oratab
#Backup file is  /u01/app/grid/product/12.2.0/grid/srvm/admin/oratab.bak.sebmmx0004 line added by Agent
#



# This file is used by ORACLE utilities.  It is created by root.sh
# and updated by either Database Configuration Assistant while creating
# a database or ASM Configuration Assistant while creating ASM instance.

# A colon, ':', is used as the field terminator.  A new line terminates
# the entry.  Lines beginning with a pound sign, '#', are comments.
#
# Entries are of the form:
#   $ORACLE_SID:$ORACLE_HOME:<N|Y>:
#
# The first and second fields are the system identifier and home
# directory of the database respectively.  The third field indicates
# to the dbstart utility that the database should , "Y", or should not,
# "N", be brought up at system boot time.
#
# Multiple entries with the same $ORACLE_SID are not allowed.
#
#
+ASM:/u01/app/grid/product/12.2.0/grid:Y                # line added by Agent
GISPROD:/u01/app/oracle/product/12.2.0:Y
[root@sebmmx0004 ~]#
[root@sebmmx0004 ~]#
[root@sebmmx0004 ~]#
[root@sebmmx0004 ~]# su - oracle
Last login: Mon Sep  9 05:32:50 CEST 2019
[oracle@sebmmx0004 ~]$ . oraenv
ORACLE_SID = [GISPROD] ? GISPROD
The Oracle base has been set to /u01/app/oracle
[oracle@sebmmx0004 ~]$
[oracle@sebmmx0004 ~]$
[oracle@sebmmx0004 ~]$ env | grep ORA
ORACLE_SID=GISPROD
ORACLE_BASE=/u01/app/oracle
ORACLE_HOME=/u01/app/oracle/product/12.2.0
[oracle@sebmmx0004 ~]$
[oracle@sebmmx0004 ~]$
[oracle@sebmmx0004 ~]$
[oracle@sebmmx0004 ~]$ sqlplus / as sysdba

SQL*Plus: Release 12.1.0.2.0 Production on Mon Sep 9 17:21:19 2019

Copyright (c) 1982, 2014, Oracle.  All rights reserved.


Connected to:
Oracle Database 12c Enterprise Edition Release 12.2.0.1.0 - 64bit Production

SQL>
SQL>
SQL>
SQL> show parameter uniqie
SQL> show parameter unique

NAME                                 TYPE        VALUE
------------------------------------ ----------- ------------------------------
db_unique_name                       string      GISPROD
SQL> select database_role from v$database;

DATABASE_ROLE
----------------
PRIMARY

SQL> exit
Disconnected from Oracle Database 12c Enterprise Edition Release 12.2.0.1.0 - 64bit Production
[oracle@sebmmx0004 ~]$ dbspicfg -e
-bash: dbspicfg: command not found
[oracle@sebmmx0004 ~]$ exit
logout
[root@sebmmx0004 ~]# dbspicfg -e
SYNTAX_VERSION 4

ORACLE

  HOME "/u01/app/oracle/product/12.2.0"
    DATABASE "GISPROD" CONNECT "HP_DBSPI/hp_dbspi@GISPROD"
           LOGFILE "/u01/app/oracle/product/12.2.0/rdbms/log/alert_GISPROD.log"
           FILTER 6 "TABLESPACE_NAME not like '%UNDO%' and TABLESPACE_NAME not like '%TEMP%' and TABLESPACE_NAME not like '%TMP%'"
[root@sebmmx0004 ~]# dbspicfg.sh
EDITOR variable not set - using vi ...
Save configuration to "/var/opt/OV/dbspi/local.cfg"? [yes]
Configuration accepted.

Verifying connection and filter definitions ...

Verifying Oracle ...
Checking instance: 'GISPROD' @ '/u01/app/oracle/product/12.2.0':
        Connect:         OKAY
        Filter 6:        OKAY
        Filter 16:       OKAY

Verification was successful

Do you want to enable graphing and reporting data collections now? [yes]

Performing graphing data logging integration for Oracle


Data logging integration complete(Graphs)

****************

If you are using the HP Performance Agent (PA) to store the DB-SPI data, you
must restart PA before the DB-SPI data can be viewed by Graphing or Reporting tools.

****************


Performing Reporter data logging integration for Oracle


Data logging integration complete(Reports)

****************

If you are using the HP Performance Agent (PA) to store the DB-SPI data, you
must restart PA before the DB-SPI data can be viewed by Graphing or Reporting tools.

****************


Please press [RETURN] to continue ...
[root@sebmmx0004 ~]#
[root@sebmmx0004 ~]#
[root@sebmmx0004 ~]#
[root@sebmmx0004 ~]# dbspicao -vdfp
Checking instance: 'GISPROD' @ '/u01/app/oracle/product/12.2.0':
        Connect:         OKAY
        Filter 6:        OKAY
        Filter 16:       OKAY

[root@sebmmx0004 ~]#
[root@sebmmx0004 ~]#
[root@sebmmx0004 ~]#
[root@sebmmx0004 ~]#
[root@sebmmx0004 ~]#
[root@sebmmx0004 ~]# cat /var/opt/OV/dbspi/db_mon.cfg | grep -v ^#
GLOBAL-NOTIFICATION=TT
DEBUG=FALSE
DEBUG_LOG=/var/opt/OV/dbspi/log/ww_dbmon.log
RUNTIME_LOG=TRUE
RUNTIME_LOG_HOUSE_KEEPING=OVERWRITE_MONTHLY
REARM=FALSE
DupEventResendInterval=3600
CHECK-COLLECTION=Major:TT
LISTENER2=15m:Critical:TT:oracle:LISTENER:
Oracle  5m      1       -       -       Critical                TT      0       0000-2400 * # Oracle Database Down
Oracle  5m      2       -       -       Critical                TT      0       0000-2400 * # Oracle processes
Oracle  1h      7       -       -       Critical                TT      0       0000-2400 * # Nbr of tablespaces not ONLINE
Oracle  1h      28      95      Max     Critical                TT      0       0000-2400 * # % of DML locks used to total configured
Oracle  1h      31      95      Max     Critical                TT      0       0000-2400 * # Nbr of users with % of open cursors to maximum configured
Oracle  15m     58      15      Min     Critical                TT      0       0000-2400 * # % of free space on archivelog devices - Critical level
Oracle  3h      62      98      Max     Critical                TT      0       0000-2400 * # % of space used on background dump device
Oracle  3h      64      98      Max     Critical                TT      0       0000-2400 * # % of space used on user dump device
Oracle  3h      65      98      Max     Critical                TT      0       0000-2400 * # % of space used on core dump device
Oracle  7d      66      20      Max     Minor           TT      0       0000-2400 * # Size in MB of alert Log file
Oracle  30m     85      95      Max     Minor           TT      0       0000-2400 * # % of current transactions to configured
Oracle  30m     87      95      Max     Minor           TT      0       0000-2400 * # % of current processes to configured
Oracle  30m     89      95      Max     Minor           TT      0       0000-2400 * # % of current enqueues to configured
Oracle  1h      700     7       Cmd     Minor           TT      0       0000-2400 * # Oracle database that are still in Online backup for more than 7(threshold) hours
Oracle  7d      4       -       -       Critical                TT      0       0000-2400 * # Nbr of users w/default tablespace set to SYSTEM
Oracle  15m     6       10      Min     Critical                TT      0       0000-2400 * # Nbr of table spaces with low free space percentage
Oracle  1h      9       90      Max     Minor           TT      0       0000-2400 * # Nbr of tablespaces with high use of temp segments to total
Oracle  30m     16      1       Min     Critical                TT      0       0000-2400 * # Nbr of segments (DB objects) that cannot extend in <threshold> time - Critical Level
Oracle  1h      17      90      Max     Critical                TT      0       0000-2400 * # Nbr of segments approaching <threshold %> max extent
Oracle  1h      48      20      Max     Minor           TT      0       0000-2400 * # % of chained rows fetched compared to <threshold>
Oracle  3h      81      -       -       Critical                TT      0       0000-2400 * # Nbr of snapshot errors
Oracle  7d      730     1       Max     Warning         TT      0       0000-2400 * # Oracle users with default password
Oracle  7d      731     1       Cmd     Warning         TT      0       0000-2400 * # Number of Users with 'ALTER SYSTEM' privilege too high
Oracle  7d      732     -       -       Warning         TT      0       0000-2400 * # No password quality in compliance with Password Policy
Oracle  7d      733     1       Cmd     Warning         TT      0       0000-2400 * # Number of Users with 'DBA' privilege too high
Oracle  7d      735     1       Cmd     Warning         TT      0       0000-2400 * # Number of External password files allowing SYSTEM privilege connection too high
Oracle  7d      736     -       -       Warning         None    0       0000-2400 * # DB version for MW
[root@sebmmx0004 ~]# su - oracle
Last login: Mon Sep  9 17:20:57 CEST 2019 on pts/1
[oracle@sebmmx0004 ~]$
[oracle@sebmmx0004 ~]$
[oracle@sebmmx0004 ~]$
[oracle@sebmmx0004 ~]$
[oracle@sebmmx0004 ~]$
[oracle@sebmmx0004 ~]$ . oraenv
ORACLE_SID = [GISPROD] ? GISPROD
The Oracle base has been set to /u01/app/oracle
[oracle@sebmmx0004 ~]$
[oracle@sebmmx0004 ~]$ sqlplus

SQL*Plus: Release 12.1.0.2.0 Production on Mon Sep 9 17:36:51 2019

Copyright (c) 1982, 2014, Oracle.  All rights reserved.

Enter user-name: / as sysdba

Connected to:
Oracle Database 12c Enterprise Edition Release 12.2.0.1.0 - 64bit Production

SQL> show parameter dest

NAME                                 TYPE        VALUE
------------------------------------ ----------- ------------------------------
audit_file_dest                      string      /u01/app/oracle/product/12.2.0
                                                 /rdbms/audit
background_dump_dest                 string      /u01/app/oracle/product/12.2.0
                                                 /rdbms/log
core_dump_dest                       string      /u01/app/oracle/diag/rdbms/gis
                                                 prod/GISPROD/cdump
cursor_bind_capture_destination      string      memory+disk
db_create_file_dest                  string      +DATA
db_create_online_log_dest_1          string      +DATA
db_create_online_log_dest_2          string
db_create_online_log_dest_3          string

NAME                                 TYPE        VALUE
------------------------------------ ----------- ------------------------------
db_create_online_log_dest_4          string
db_create_online_log_dest_5          string
db_recovery_file_dest                string      +FRA
db_recovery_file_dest_size           big integer 98G
diagnostic_dest                      string      /u01/app/oracle
log_archive_dest                     string
log_archive_dest_1                   string
log_archive_dest_10                  string
log_archive_dest_11                  string
log_archive_dest_12                  string
log_archive_dest_13                  string

NAME                                 TYPE        VALUE
------------------------------------ ----------- ------------------------------
log_archive_dest_14                  string
log_archive_dest_15                  string
log_archive_dest_16                  string
log_archive_dest_17                  string
log_archive_dest_18                  string
log_archive_dest_19                  string
log_archive_dest_2                   string
log_archive_dest_20                  string
log_archive_dest_21                  string
log_archive_dest_22                  string
log_archive_dest_23                  string

NAME                                 TYPE        VALUE
------------------------------------ ----------- ------------------------------
log_archive_dest_24                  string
log_archive_dest_25                  string
log_archive_dest_26                  string
log_archive_dest_27                  string
log_archive_dest_28                  string
log_archive_dest_29                  string
log_archive_dest_3                   string
log_archive_dest_30                  string
log_archive_dest_31                  string
log_archive_dest_4                   string
log_archive_dest_5                   string

NAME                                 TYPE        VALUE
------------------------------------ ----------- ------------------------------
log_archive_dest_6                   string
log_archive_dest_7                   string
log_archive_dest_8                   string
log_archive_dest_9                   string
log_archive_dest_state_1             string      enable
log_archive_dest_state_10            string      enable
log_archive_dest_state_11            string      enable
log_archive_dest_state_12            string      enable
log_archive_dest_state_13            string      enable
log_archive_dest_state_14            string      enable
log_archive_dest_state_15            string      enable

NAME                                 TYPE        VALUE
------------------------------------ ----------- ------------------------------
log_archive_dest_state_16            string      enable
log_archive_dest_state_17            string      enable
log_archive_dest_state_18            string      enable
log_archive_dest_state_19            string      enable
log_archive_dest_state_2             string      enable
log_archive_dest_state_20            string      enable
log_archive_dest_state_21            string      enable
log_archive_dest_state_22            string      enable
log_archive_dest_state_23            string      enable
log_archive_dest_state_24            string      enable
log_archive_dest_state_25            string      enable

NAME                                 TYPE        VALUE
------------------------------------ ----------- ------------------------------
log_archive_dest_state_26            string      enable
log_archive_dest_state_27            string      enable
log_archive_dest_state_28            string      enable
log_archive_dest_state_29            string      enable
log_archive_dest_state_3             string      enable
log_archive_dest_state_30            string      enable
log_archive_dest_state_31            string      enable
log_archive_dest_state_4             string      enable
log_archive_dest_state_5             string      enable
log_archive_dest_state_6             string      enable
log_archive_dest_state_7             string      enable

NAME                                 TYPE        VALUE
------------------------------------ ----------- ------------------------------
log_archive_dest_state_8             string      enable
log_archive_dest_state_9             string      enable
log_archive_duplex_dest              string
log_archive_min_succeed_dest         integer     1
remote_recovery_file_dest            string
standby_archive_dest                 string      ?#/dbs/arch
user_dump_dest                       string      /u01/app/oracle/product/12.2.0
                                                 /rdbms/log
SQL>
