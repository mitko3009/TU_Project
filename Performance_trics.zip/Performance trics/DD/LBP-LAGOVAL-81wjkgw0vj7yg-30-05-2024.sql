/********************************************************************************
*********       E-mail subject: LBPWEB-5366
*********             Instance: LAGOVAL
*********          Description: 
Problem:
This SQL was provided in LBPWEB-5366 as slow on LAGOVAL.

Analysis:
We executed the query on LAGOVAL as it was sent and it took over 3 minutes to finish its execution. The main reason why this query take so much time
is because it searched for user IMX ( v_extr_dom.abrev = to_char(1) ), which is authorized for ~ 87k dossiers, so to check for so much data takes time.
From performance point of view we can achieve some improvement by accessing table t_intervenants direct from table v_extr_dom instead accessing table g_individu first by changing condition
from "i.refindividu = v_extr_dom.valeur" to "t1.refindividu = v_extr_dom.valeur". This change plus adding some hints will force Oracle to make a good execution
plan and achieve better performance. Also, in the provided variant of the query, we noticed that there are duplicate rows in the result, so we added distinct to the query.
Suggestion:
Please change the query as it is shown in the New SQL section below.

*********               SQL_ID: 81wjkgw0vj7yg-
*********      Program/Package: 
*********              Request: Kiril Zdravkov 
*********               Author: Dimitar Dimitrov
********* Received e-mail date: 29/05/2024
*********      Resolution date: 30/05/2024
*********  Trace old file here: \\epox\specifs\performance\tmp\
*********  Trace new file here:
***********************************************************************************/

/********************************OLD SQL*******************************************/

SELECT nvl(d.ancrefdoss, t1.refdoss) || ' - ' || i.nom "label",
       t1.refdoss || ';' || t1.refindividu || ';' || d.categdoss "value",
       t1.refdoss "refdoss",
       nvl(d.ancrefdoss, t1.refdoss) "ancrefdoss"
  FROM t_intervenants t1, 
       g_dossier d, 
       g_individu i, 
       v_extr_dom
 WHERE t1.refdoss = d.refdoss
   AND d.categdoss = DECODE(t1.reftype,
                            'DB',
                            'COMPTE DB CTR',
                            'ACH',
                            'COMPTE DB CTR',
                            'CL',
                            'CONTRAT')
   AND t1.refindividu = i.refindividu
   AND i.refindividu = v_extr_dom.valeur
   AND v_extr_dom.TYPE = 'EXTR_GEST_CLIENT'
   AND (v_extr_dom.valeur_2 IS NULL 
   	 OR v_extr_dom.valeur_2 = t1.reftype)
   AND v_extr_dom.abrev = to_char(1)
   AND NOT EXISTS( SELECT 1
                     FROM g_piecedet
                    WHERE imx_un_id = (SELECT max(pd.imx_un_id)
                                         FROM g_piece pc, 
                                              g_piecedet pd
                                        WHERE pc.refdoss = d.refdoss
                                          AND pc.typpiece = 'CONTRAT'
                                          AND pd.refdoss = pc.refdoss
                                          AND pd.refpiece = pc.refpiece
                                          AND pd.type = 'CONTRACT SITUATIONS'
                                          AND pd.dt01_dt <= SYSDATE)
                      AND str1 = 'F')
 ORDER BY 1;
/********************************OLD SQL*******************************************/
/********************************OLD Metrics***************************************/
/*
Plan hash value: 3968301233
-------------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                    | Name             | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  |
-------------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                             |                  |      1 |        |     6 (100)|   3774 |00:03:28.80 |     295K|  56682 |
|   1 |  SORT ORDER BY                               |                  |      1 |      1 |     6  (17)|   3774 |00:03:28.80 |     295K|  56682 |
|   2 |   NESTED LOOPS                               |                  |      1 |      1 |     4   (0)|   3774 |00:03:28.75 |     295K|  56682 |
|   3 |    NESTED LOOPS                              |                  |      1 |      2 |     4   (0)|  87030 |00:02:53.66 |     249K|  46051 |
|   4 |     NESTED LOOPS                             |                  |      1 |      2 |     3   (0)|  87069 |00:00:11.52 |   34873 |   3303 |
|   5 |      NESTED LOOPS                            |                  |      1 |     14 |     2   (0)|  23033 |00:00:08.37 |   28987 |   3004 |
|   6 |       TABLE ACCESS BY INDEX ROWID BATCHED    | V_EXTR_DOM       |      1 |     14 |     1   (0)|  23033 |00:00:00.57 |   19996 |    319 |
|*  7 |        INDEX RANGE SCAN                      | TYPEABREV        |      1 |     14 |     1   (0)|  23033 |00:00:00.35 |     172 |    172 |
|   8 |       TABLE ACCESS BY INDEX ROWID            | G_INDIVIDU       |  23033 |      1 |     1   (0)|  23033 |00:00:07.78 |    8991 |   2685 |
|*  9 |        INDEX UNIQUE SCAN                     | IND_REFINDIV     |  23033 |      1 |     1   (0)|  23033 |00:00:00.16 |    1663 |    115 |
|* 10 |      INDEX RANGE SCAN                        | INT_INDIV        |  23033 |      1 |     1   (0)|  87069 |00:00:03.11 |    5886 |    299 |
|* 11 |     INDEX UNIQUE SCAN                        | DOS_REFDOSS      |  87069 |      1 |     1   (0)|  87030 |00:02:42.06 |     214K|  42748 |
|* 12 |      TABLE ACCESS BY INDEX ROWID             | G_PIECEDET       |  84420 |      1 |     1   (0)|     35 |00:02:41.48 |     185K|  42609 |
|* 13 |       INDEX UNIQUE SCAN                      | PK_G_PIECEDET_PK |  84420 |      1 |     1   (0)|   8555 |00:02:41.38 |     177K|  42609 |
|  14 |        SORT AGGREGATE                        |                  |  84416 |      1 |            |  84416 |00:02:28.33 |     151K|  38618 |
|  15 |         NESTED LOOPS                         |                  |  84416 |      1 |     2   (0)|  20390 |00:02:28.09 |     151K|  38618 |
|  16 |          NESTED LOOPS                        |                  |  84416 |      1 |     2   (0)|  20390 |00:01:59.00 |     131K|  23695 |
|  17 |           TABLE ACCESS BY INDEX ROWID BATCHED| G_PIECE          |  84416 |      1 |     1   (0)|   8557 |00:01:27.41 |     105K|  16363 |
|* 18 |            INDEX RANGE SCAN                  | PIE_REFDOSS      |  84416 |      1 |     1   (0)|   8557 |00:00:54.77 |   97569 |  10518 |
|* 19 |           INDEX RANGE SCAN                   | G_PIECEDET_REFP  |   8557 |      1 |     1   (0)|  20390 |00:00:31.51 |   25829 |   7332 |
|* 20 |          TABLE ACCESS BY INDEX ROWID         | G_PIECEDET       |  20390 |      1 |     1   (0)|  20390 |00:00:28.96 |   20036 |  14923 |
|* 21 |    TABLE ACCESS BY INDEX ROWID               | G_DOSSIER        |  87030 |      1 |     1   (0)|   3774 |00:00:35.03 |   45664 |  10631 |
-------------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   7 - access("V_EXTR_DOM"."TYPE"='EXTR_GEST_CLIENT' AND "V_EXTR_DOM"."ABREV"='1')
   9 - access("I"."REFINDIVIDU"="V_EXTR_DOM"."VALEUR")
  10 - access("T1"."REFINDIVIDU"="I"."REFINDIVIDU")
       filter(("V_EXTR_DOM"."VALEUR_2" IS NULL OR "V_EXTR_DOM"."VALEUR_2"="T1"."REFTYPE"))
  11 - access("T1"."REFDOSS"="D"."REFDOSS")
       filter( IS NULL)
  12 - filter("STR1"='F')
  13 - access("IMX_UN_ID"=)
  18 - access("PC"."REFDOSS"=:B1 AND "PC"."TYPPIECE"='CONTRAT')
  19 - access("PD"."REFPIECE"="PC"."REFPIECE" AND "PD"."TYPE"='CONTRACT SITUATIONS' AND "PD"."DT01_DT"<=SYSDATE@!)
  20 - filter(("PD"."REFDOSS"=:B1 AND "PD"."REFDOSS"="PC"."REFDOSS"))
  21 - filter("D"."CATEGDOSS"=DECODE("T1"."REFTYPE",'DB','COMPTE DB CTR','ACH','COMPTE DB CTR','CL','CONTRAT'))
*/
/********************************OLD Metrics***************************************/

/********************************New SQL*******************************************/

SELECT /*+ leading(v_extr_dom t1 d i) use_nl(t1 d i) index(v_extr_dom TYPEABREV) */
       DISTINCT nvl(d.ancrefdoss, t1.refdoss) || ' - ' || i.nom           "label",
                t1.refdoss || ';' || t1.refindividu || ';' || d.categdoss "value",
                t1.refdoss                                                "refdoss",
                nvl(d.ancrefdoss, t1.refdoss)                             "ancrefdoss"
  FROM t_intervenants t1,
       g_dossier d,
       g_individu i,
       v_extr_dom
 WHERE t1.refdoss = d.refdoss
   AND d.categdoss = DECODE(t1.reftype, 'DB', 'COMPTE DB CTR', 'ACH', 'COMPTE DB CTR', 'CL', 'CONTRAT')
   AND t1.refindividu = i.refindividu
   AND t1.refindividu = v_extr_dom.valeur
   AND v_extr_dom.TYPE = 'EXTR_GEST_CLIENT'
   AND (    v_extr_dom.valeur_2 IS NULL 
         OR v_extr_dom.valeur_2 = t1.reftype )
   AND v_extr_dom.abrev = to_char(1)
   AND NOT EXISTS ( SELECT /*+ no_push_subq */
                           1
                      FROM g_piecedet
                     WHERE imx_un_id = ( SELECT max(pd.imx_un_id)
                                           FROM g_piece pc,
                                                g_piecedet pd
                                          WHERE pc.refdoss = d.refdoss
                                            AND pc.typpiece = 'CONTRAT'
                                            AND pd.refdoss = pc.refdoss
                                            AND pd.refpiece = pc.refpiece
                                            AND pd.type = 'CONTRACT SITUATIONS'
                                            AND pd.dt01_dt <= SYSDATE )
                       AND str1 = 'F' );
/********************************New SQL*******************************************/
/********************************New Metrics***************************************/
/*
Plan hash value: 3761638663
-----------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                  | Name             | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  |
-----------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                           |                  |      1 |        |     6 (100)|   3771 |00:02:22.29 |     148K|  28094 |
|   1 |  HASH UNIQUE                               |                  |      1 |      1 |     6  (17)|   3771 |00:02:22.29 |     148K|  28094 |
|*  2 |   FILTER                                   |                  |      1 |        |            |   3774 |00:02:22.22 |     148K|  28094 |
|   3 |    NESTED LOOPS                            |                  |      1 |      1 |     4   (0)|   3791 |00:00:29.13 |     103K|   9171 |
|   4 |     NESTED LOOPS                           |                  |      1 |      1 |     4   (0)|   3791 |00:00:26.10 |     100K|   8525 |
|   5 |      NESTED LOOPS                          |                  |      1 |      1 |     3   (0)|   3791 |00:00:26.07 |     100K|   8512 |
|   6 |       NESTED LOOPS                         |                  |      1 |      2 |     2   (0)|  87076 |00:00:02.68 |   25742 |    557 |
|   7 |        TABLE ACCESS BY INDEX ROWID BATCHED | V_EXTR_DOM       |      1 |     14 |     1   (0)|  23033 |00:00:00.60 |   19994 |    321 |
|*  8 |         INDEX RANGE SCAN                   | TYPEABREV        |      1 |     14 |     1   (0)|  23033 |00:00:00.26 |     172 |    172 |
|*  9 |        INDEX RANGE SCAN                    | INT_INDIV        |  23033 |      1 |     1   (0)|  87076 |00:00:02.04 |    5748 |    236 |
|* 10 |       TABLE ACCESS BY INDEX ROWID          | G_DOSSIER        |  87076 |      1 |     1   (0)|   3791 |00:00:23.36 |   74462 |   7955 |
|* 11 |        INDEX UNIQUE SCAN                   | DOS_REFDOSS      |  87076 |      1 |     1   (0)|  87076 |00:00:00.28 |   28697 |    107 |
|* 12 |      INDEX UNIQUE SCAN                     | IND_REFINDIV     |   3791 |      1 |     1   (0)|   3791 |00:00:00.02 |     427 |     13 |
|  13 |     TABLE ACCESS BY INDEX ROWID            | G_INDIVIDU       |   3791 |      1 |     1   (0)|   3791 |00:00:03.03 |    2376 |    646 |
|* 14 |    TABLE ACCESS BY INDEX ROWID             | G_PIECEDET       |   3790 |      1 |     1   (0)|     17 |00:01:53.02 |   45325 |  18923 |
|* 15 |     INDEX UNIQUE SCAN                      | PK_G_PIECEDET_PK |   3790 |      1 |     1   (0)|   3617 |00:01:52.99 |   41708 |  18923 |
|  16 |      SORT AGGREGATE                        |                  |   3790 |      1 |            |   3790 |00:01:40.07 |   30836 |  16855 |
|  17 |       NESTED LOOPS                         |                  |   3790 |      1 |     2   (0)|   9020 |00:01:40.02 |   30836 |  16855 |
|  18 |        NESTED LOOPS                        |                  |   3790 |      1 |     2   (0)|   9020 |00:01:06.70 |   21995 |   9332 |
|  19 |         TABLE ACCESS BY INDEX ROWID BATCHED| G_PIECE          |   3790 |      1 |     1   (0)|   3618 |00:00:41.79 |   11044 |   5672 |
|* 20 |          INDEX RANGE SCAN                  | PIE_REFDOSS      |   3790 |      1 |     1   (0)|   3618 |00:00:22.24 |    7584 |   3507 |
|* 21 |         INDEX RANGE SCAN                   | G_PIECEDET_REFP  |   3618 |      1 |     1   (0)|   9020 |00:00:24.89 |   10951 |   3660 |
|* 22 |        TABLE ACCESS BY INDEX ROWID         | G_PIECEDET       |   9020 |      1 |     1   (0)|   9020 |00:00:33.28 |    8841 |   7523 |
-----------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   2 - filter( IS NULL)
   8 - access("V_EXTR_DOM"."TYPE"='EXTR_GEST_CLIENT' AND "V_EXTR_DOM"."ABREV"='1')
   9 - access("T1"."REFINDIVIDU"="V_EXTR_DOM"."VALEUR")
       filter(("V_EXTR_DOM"."VALEUR_2" IS NULL OR "V_EXTR_DOM"."VALEUR_2"="T1"."REFTYPE"))
  10 - filter("D"."CATEGDOSS"=DECODE("T1"."REFTYPE",'DB','COMPTE DB CTR','ACH','COMPTE DB CTR','CL','CONTRAT'))
  11 - access("T1"."REFDOSS"="D"."REFDOSS")
  12 - access("T1"."REFINDIVIDU"="I"."REFINDIVIDU")
  14 - filter("STR1"='F')
  15 - access("IMX_UN_ID"=)
  20 - access("PC"."REFDOSS"=:B1 AND "PC"."TYPPIECE"='CONTRAT')
  21 - access("PD"."REFPIECE"="PC"."REFPIECE" AND "PD"."TYPE"='CONTRACT SITUATIONS' AND "PD"."DT01_DT"<=SYSDATE@!)
  22 - filter(("PD"."REFDOSS"=:B1 AND "PD"."REFDOSS"="PC"."REFDOSS"))                       
*/
/********************************New Metrics***************************************/

/********************************Index statistics**********************************/

/********************************Other SQLs****************************************/          
/*

*/ 
/********************************Other SQLs****************************************/              
