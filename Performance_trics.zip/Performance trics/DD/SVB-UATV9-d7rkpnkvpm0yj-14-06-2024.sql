/********************************************************************************
*********       E-mail subject: SVBDEV-7753 
*********             Instance: UAT V9
*********          Description: 
Problem:
Slowness in reprise_g_piece_g_db_ptf_item.sql on SVB UAT V9.

Analysis:
After the analyze, we found the the slowness of reprise_g_piece_g_db_ptf_item.sql comes from SQL d7rkpnkvpm0yj, which is prat of the reprise_g_piece_g_db_ptf_item.sql.
The problem in this SQL is that Oracle can't choose good execution plan for SQL d7rkpnkvpm0yj, because it expects only one row from table g_db_ptf_item. The solution 
here is to add hints in SQL d7rkpnkvpm0yj, which will force Oracle to choose a good execution plan. 

Suggestion:
Please add hint as it is shown in the New SQLs ection below.

*********               SQL_ID: d7rkpnkvpm0yj
*********      Program/Package: 
*********              Request: Borislav Iliev
*********               Author: Dimitar Dimitrov
********* Received e-mail date: 14/06/2024
*********      Resolution date: 14/06/2024
*********  Trace old file here: \\epox\specifs\performance\tmp\
*********  Trace new file here:
***********************************************************************************/

/********************************OLD SQL*******************************************/

SELECT /*+ FULL(P) INDEX_FFS(F EFI_REFELEM) USE_HASH(P F) */
       P.GPIHEURE
  FROM  G_PIECE P, 
       G_ELEMFI F
 WHERE P.GPIHEURE = F.REFELEM
   AND P.TYPPIECE = 'FACTURE'
   AND NOT EXISTS (SELECT /*+ FULL(I) */
                          1
                     FROM G_DB_PTF_ITEM I
                    WHERE I.REFELEM = P.GPIHEURE);
/********************************OLD SQL*******************************************/
/********************************OLD Metrics***************************************/
/*

INST_ID     SID SERIAL# PID         SPID       MODULE               EVENT                                    STATUS            SQL_ID        PLAN_HASH_VALUE CLIENT_ID    CLIENT_INFO          LOGON_TIME MACHINE    ACTION
------- ------- ------- ----------- ---------- -------------------- ---------------------------------------- ----------------- ------------- --------------- ------------ ---------------- ---------- ---------- -------------------------
1          1369   61873 646946      24046      pt                   on cpu                                   ACTIVE-180 sec.   dzxvj85zyp8fy      3199895862 pt_dd        pt_dd        05:10:15
1           732   50342 479104      24211      SQL*Plus             direct path read                         ACTIVE-75113 sec. d7rkpnkvpm0yj      3199895862 unknown      unknown      13/06/24
1             2   13820 25406       25406      DBMS_SCHEDULER       idle-Streams AQ: waiting for messages in ACTIVE-165 sec.   59p1yadp2g6mb               0                  05:11:28   dfw-scpz-i AQ$_PLSQL_NTFN_1244968364
1           136   44387 3379        8384       oraagent.bin         idle-SQL*Net message from client         INACTIVE-740031 s                                                05/06/24   dfw-scpz-i





MODULE                           SQL_ID         PLAN_HASH     SID SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS SQL_EXEC_ID INTERVAL                PERC
-------------------------------- ------------- ---------- ------- ------- -------------------- -------------------- -------------------- ---------- -------------------- ----------- ----------------------- ------
SQL*Plus                         d7rkpnkvpm0yj 3199895862     732   50342                      2024/06/13 08:22:21  2024/06/14 05:48:06       77006                    1    16777217 +000000000 21:25:44.674 100%



Plan hash value: 3199895862
---------------------------------------------------------
| Id  | Operation              | Name          | E-Rows |
---------------------------------------------------------
|   0 | SELECT STATEMENT       |               |        |
|*  1 |  FILTER                |               |        |
|*  2 |   HASH JOIN            |               |     18M|
|   3 |    INDEX FAST FULL SCAN| EFI_REFELEM   |     24M|
|*  4 |    TABLE ACCESS FULL   | G_PIECE       |     19M|
|*  5 |   TABLE ACCESS FULL    | G_DB_PTF_ITEM |      1 |
---------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   1 - filter( IS NULL)
   2 - access("P"."GPIHEURE"="F"."REFELEM")
   4 - filter(("P"."GPIHEURE" IS NOT NULL AND "P"."TYPPIECE"='FACTURE'))
   5 - filter("I"."REFELEM"=:B1)
*/
/********************************OLD Metrics***************************************/

/********************************New SQL*******************************************/

SELECT /*+ FULL(P) INDEX_FFS(F EFI_REFELEM) USE_HASH(P F) */
       P.GPIHEURE
  FROM G_PIECE P, 
       G_ELEMFI F
 WHERE P.GPIHEURE = F.REFELEM
   AND P.TYPPIECE = 'FACTURE'
   AND NOT EXISTS (SELECT /*+ unnest use_hash(I) FULL(I) */
                          1
                     FROM G_DB_PTF_ITEM I
                    WHERE I.REFELEM = P.GPIHEURE);   
/********************************New SQL*******************************************/
/********************************New Metrics***************************************/
/*

Plan hash value: 3758045953
---------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation              | Name          | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  | Writes |
---------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT       |               |      1 |        |  1750K(100)|      0 |00:01:54.83 |      14M|   6397K|    179K|
|*  1 |  HASH JOIN RIGHT ANTI  |               |      1 |     18M|  1750K  (1)|      0 |00:01:54.83 |      14M|   6397K|    179K|
|   2 |   TABLE ACCESS FULL    | G_DB_PTF_ITEM |      1 |      1 |     2   (0)|     23M|00:00:03.99 |   45942 |  43569 |      0 |
|*  3 |   HASH JOIN            |               |      1 |     18M|  1750K  (1)|     23M|00:01:29.16 |      14M|   6264K|  89683 |
|   4 |    INDEX FAST FULL SCAN| EFI_REFELEM   |      1 |     24M| 17969   (2)|     24M|00:00:01.89 |   66359 |      0 |      0 |
|*  5 |    TABLE ACCESS FULL   | G_PIECE       |      1 |     19M|  1678K  (1)|     23M|00:00:57.50 |      13M|   6174K|      0 |
---------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   1 - access("I"."REFELEM"="P"."GPIHEURE")
   3 - access("P"."GPIHEURE"="F"."REFELEM")
   5 - filter(("P"."GPIHEURE" IS NOT NULL AND "P"."TYPPIECE"='FACTURE'))
*/
/********************************New Metrics***************************************/

/********************************Index statistics**********************************/

/********************************Other SQLs****************************************/          
/*

*/ 
/********************************Other SQLs****************************************/              
