/********************************************************************************
*********       E-mail subject: AMIWEB-200
*********             Instance: AMB_PROD
*********          Description: 
Problem:
The crd_upload2facture took 2 hours on AMB_PROD

Analysis:
We checked the work of the crd_upload2facture module for the provided period on AMB_PROD and found that the TOP four SQLs are responsible for ~78% of the time.
The problem in both of them is that Oracle doesn't use appropriate index to access the tables, which leads to more buffer gets, which costs more time.
We found that the last time when the statistics were gathered on this instance was 06/10/2024, when tables like G_ELEMFI and T_INVLOT_ITEM were empty ( 0 rows ).
This is the reason why Oracle can't make real calculation which index to use, because it thinks that the tables are empty, but on 09/10/2024 they were not empty.
We added hints to help Oracle to use the appropriate index for every table regardless of statistics, so please add hints as it is shown in the New SQL section below.

Suggestion:
Please add hints as it is shown in the New SQL section below.

*********               SQL_ID: 5jxhrbmqdbn0u, du4zvvhbhzvcu, gfbgdvqb427xq, cazqv8wmf2f6k
*********      Program/Package: 
*********              Request: Alain Nivelle 
*********               Author: Dimitar Dimitrov
********* Received e-mail date: 09/10/2024
*********      Resolution date: 09/10/2024
*********  Trace old file here: \\epox\specifs\performance\tmp\
*********  Trace new file here:
***********************************************************************************/

/********************************OLD SQL*******************************************/

-- 5jxhrbmqdbn0u

var B1 NUMBER;
exec :B1 := '22211';
var B2 VARCHAR2(32);
exec :B2 := '7473836_1';

SELECT * 
  FROM T_INVLOT_ITEM 
 WHERE LOT_ID = :B2 
   AND SEQNUM = :B1 ;


-- du4zvvhbhzvcu

var B1 NUMBER;
exec :B1 := '22210';
var B2 VARCHAR2(32);
exec :B2 := '7473836_1';
var B3 VARCHAR2(32);
exec :B3 := '74738';
var B4 VARCHAR2(32);
exec :B4 := '74738';

UPDATE T_INVLOT_ITEM
   SET IMX_REFERENCE    = NVL(:B4, :B3),
       IMX_PROCESSED    = NVL(IMX_PROCESSED, 0) + 1,
       IMX_RETRY        = 0,
       IMX_DATE_PROCESS = SYSDATE
 WHERE LOT_ID = :B2
   AND SEQNUM = :B1;


-- gfbgdvqb427xq

var B1 VARCHAR2(32);
exec :B1 := '2410065497';

SELECT NVL(SUM(NVL(T.MNT_DCPT, 0) *
               DECODE(P.ELEMENT,
                      'dbdu',
                      DECODE(P.SENS, '-', -1, 1),
                      DECODE(P.SENS, '+', -1, 1))),
           0)
  FROM V_CALDOS P, T_ECRDOS T, G_ELEMFI E, V_ELEMFI V
 WHERE P.SOMME = 'IMMINENTCAP'
   AND T.CODECR = P.CODECR
   AND T.REFDOSS = :B1
   AND T.TYPELEM = 'f'
   AND E.REFELEM = T.REFELEM
   AND V.TYPE = E.TYPE
   AND NVL(V.FG_EXCLUDE_IMMINENT_CAPITAL, 'N') != 'O';


-- cazqv8wmf2f6k

var TLOGID VARCHAR2(32);
exec :TLOGID := '7479169_1';

SELECT NVL(MAX(SEQNUM), 0) + 1 
  FROM t_invlot_ITEM 
 WHERE LOT_ID = :tLogId;


/********************************OLD SQL*******************************************/
/********************************OLD Metrics***************************************/
/*

MODULE                    SQL_ID         PLAN_HASH SID    SERIAL# EVENT                          FROM                           TO                                 ACTIVE NUMBER_OF_EXECUTIONS PERC
------------------------- ------------- ---------- ------ ------- ------------------------------ ------------------------------ ------------------------------ ---------- -------------------- ------
crd_upload2facture                                                ON CPU                         2024/10/09 10:23:11            2024/10/09 12:19:11                  6060              1367722 93%
crd_upload2facture        NULL                                    log file sync                  2024/10/09 10:25:41            2024/10/09 10:51:11                   310                      5%
SQL*Plus                                                          ON CPU                         2024/10/09 10:15:52            2024/10/09 11:40:21                    30                23350 0%
EXTRANET                  925ttpa9q4v9k          0 573    61886   ON CPU                         2024/10/09 10:03:41            2024/10/09 10:07:31                    30                24704 0%



MODULE                    SQL_ID         PLAN_HASH SID    SERIAL# EVENT                          FROM                           TO                                 ACTIVE NUMBER_OF_EXECUTIONS PERC
------------------------- ------------- ---------- ------ ------- ------------------------------ ------------------------------ ------------------------------ ---------- -------------------- ------
crd_upload2facture                                                ON CPU                         2024/10/09 10:23:11            2024/10/09 12:19:11                  6060              1367722 95%
crd_upload2facture        NULL                                    log file sync                  2024/10/09 10:25:41            2024/10/09 10:51:11                   310                      5%


MODULE                    SQL_ID         PLAN_HASH SID    SERIAL# EVENT                          FROM                           TO                                 ACTIVE NUMBER_OF_EXECUTIONS PERC
------------------------- ------------- ---------- ------ ------- ------------------------------ ------------------------------ ------------------------------ ---------- -------------------- ------
crd_upload2facture                                 2230   4479                                   2024/10/09 10:23:11            2024/10/09 12:19:11                  6160              1367722 100%

MODULE                    SQL_ID         PLAN_HASH SID    SERIAL# EVENT                          FROM                           TO                                 ACTIVE NUMBER_OF_EXECUTIONS PERC
------------------------- ------------- ---------- ------ ------- ------------------------------ ------------------------------ ------------------------------ ---------- -------------------- ------
crd_upload2facture                                 2230   4479                                   2024/10/09 10:23:11            2024/10/09 12:19:11                  6160              1367722 97%
crd_upload2facture        NULL                     1486   58755                                  2024/10/09 10:25:41            2024/10/09 10:49:01                   210                      3%


MODULE                    SQL_ID         PLAN_HASH SID    SERIAL# EVENT                          FROM                           TO                                 ACTIVE NUMBER_OF_EXECUTIONS PERC
------------------------- ------------- ---------- ------ ------- ------------------------------ ------------------------------ ------------------------------ ---------- -------------------- ------
crd_upload2facture        5jxhrbmqdbn0u 4025834423 2230   4479    ON CPU                         2024/10/09 10:51:51            2024/10/09 11:57:01                  1440                47562 23%
crd_upload2facture        du4zvvhbhzvcu 1042475483 2230   4479    ON CPU                         2024/10/09 10:51:41            2024/10/09 11:57:41                  1390                48110 23%
crd_upload2facture        gfbgdvqb427xq 1702749504 2230   4479    ON CPU                         2024/10/09 11:58:01            2024/10/09 12:19:11                  1270                11176 21%
crd_upload2facture        cazqv8wmf2f6k 2984129496 2230   4479    ON CPU                         2024/10/09 10:27:31            2024/10/09 10:51:21                   690                42150 11%
crd_upload2facture        NULL                     2230   4479                                   2024/10/09 10:28:31            2024/10/09 11:43:41                   160                      3%
crd_upload2facture        579pc27w27zjy 2226248902 2230   4479    ON CPU                         2024/10/09 11:06:41            2024/10/09 11:56:51                    90               184773 1%



SQL_ID           ELAPSED                     GETS      READS       ROWS  ELAP/EXEC  GETS/EXEC READS/EXEC  ROWS/EXEC       EXEC PLAN_HASH_VALUE
------------- ---------- ------------------------ ---------- ---------- ---------- ---------- ---------- ---------- ---------- ---------------
gfbgdvqb427xq 121.483646                 93644309          0        748        .16  125025.78          0          1        749      1702749504
du4zvvhbhzvcu 1488.55639               1163824695          0      48420        .03   24036.03          0          1      48420      1042475483
5jxhrbmqdbn0u  1449.5526               1163631152          0      48420        .03   24032.04          0          1      48420      4025834423
cazqv8wmf2f6k 624.171139                535442945          0      48422        .01   11057.84          0          1      48422      2984129496


OWNER           TABLE_NAME                         BLOCKS   NUM_ROWS AVG_ROW_LEN   MB_AS_IS   MB_TO_BE LAST_ANALYZED       SAMPLE_SIZE    INSERTS    UPDATES    DELETES PERC_MODIFIED
--------------- ------------------------------ ---------- ---------- ----------- ---------- ---------- ------------------- ----------- ---------- ---------- ---------- -------------
IMXDB           G_ELEMFI                                0          0           0         33          0 2024-10-06 10:21:44           0     114777        618          0      11539500
IMXDB           T_INVLOT_ITEM                           0          0           0         25          0 2024-10-06 10:18:29           0     145269     114777      48423      30846900

select count(*) from G_ELEMFI;

  COUNT(*)
----------
     48423
     
select count(*) from T_INVLOT_ITEM;

  COUNT(*)
----------
     96846


-- 5jxhrbmqdbn0u

Plan hash value: 4025834423
--------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                           | Name              | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers |
--------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                    |                   |      1 |        |     1 (100)|      1 |00:00:00.04 |   24361 |
|*  1 |  TABLE ACCESS BY INDEX ROWID BATCHED| T_INVLOT_ITEM     |      1 |      1 |     1   (0)|      1 |00:00:00.04 |   24361 |
|*  2 |   INDEX RANGE SCAN                  | INVLOT_ITEM_LOTID |      1 |      1 |     1   (0)|  48423 |00:00:00.01 |     281 |
--------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   1 - filter("SEQNUM"=:B1)
   2 - access("LOT_ID"=:B2)
 

-- du4zvvhbhzvcu

Plan hash value: 1042475483
---------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                            | Name              | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers |
---------------------------------------------------------------------------------------------------------------------------------
|   0 | UPDATE STATEMENT                     |                   |      1 |        |     1 (100)|      0 |00:00:00.07 |   24376 |
|   1 |  UPDATE                              | T_INVLOT_ITEM     |      1 |        |            |      0 |00:00:00.07 |   24376 |
|*  2 |   TABLE ACCESS BY INDEX ROWID BATCHED| T_INVLOT_ITEM     |      1 |      1 |     1   (0)|      1 |00:00:00.07 |   24359 |
|*  3 |    INDEX RANGE SCAN                  | INVLOT_ITEM_LOTID |      1 |      1 |     1   (0)|  48423 |00:00:00.01 |     280 |
---------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   2 - filter("SEQNUM"=:B1)
   3 - access("LOT_ID"=:B2)


-- gfbgdvqb427xq

Plan hash value: 1702749504
-----------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                | Name                        | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers |
-----------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                         |                             |      1 |        |     3 (100)|      1 |00:00:00.09 |     606 |
|   1 |  SORT AGGREGATE                          |                             |      1 |      1 |            |      1 |00:00:00.09 |     606 |
|   2 |   NESTED LOOPS                           |                             |      1 |      1 |     3   (0)|      0 |00:00:00.09 |     606 |
|   3 |    NESTED LOOPS                          |                             |      1 |      1 |     3   (0)|      0 |00:00:00.09 |     606 |
|   4 |     NESTED LOOPS                         |                             |      1 |      1 |     2   (0)|      3 |00:00:00.09 |     601 |
|   5 |      NESTED LOOPS                        |                             |      1 |      1 |     2   (0)|      3 |00:00:00.09 |     598 |
|   6 |       INDEX FULL SCAN                    | G_ELEMFI$REFDOSS_ACTIF      |      1 |      1 |     1   (0)|  48423 |00:00:00.01 |     584 |
|*  7 |       TABLE ACCESS BY INDEX ROWID BATCHED| T_ECRDOS                    |  48423 |      1 |     1   (0)|      3 |00:00:00.07 |      14 |
|*  8 |        INDEX RANGE SCAN                  | TECR$REFDOSS_CODECR_DTINTER |  48423 |      1 |     1   (0)|    145K|00:00:00.05 |      13 |
|*  9 |      TABLE ACCESS BY INDEX ROWID BATCHED | V_ELEMFI                    |      3 |      1 |     1   (0)|      3 |00:00:00.01 |       3 |
|* 10 |       INDEX RANGE SCAN                   | VF_TYPE_FINANCING           |      3 |      1 |     1   (0)|      3 |00:00:00.01 |       2 |
|* 11 |     INDEX RANGE SCAN                     | VCALDOS_SC                  |      3 |      1 |     1   (0)|      0 |00:00:00.01 |       5 |
|  12 |    TABLE ACCESS BY INDEX ROWID           | V_CALDOS                    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
-----------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   7 - filter(("E"."REFELEM"="T"."REFELEM" AND "T"."TYPELEM"='f'))
   8 - access("T"."REFDOSS"=:B1)
   9 - filter(NVL("V"."FG_EXCLUDE_IMMINENT_CAPITAL",'N')<>'O')
  10 - access("V"."TYPE"="E"."TYPE")
  11 - access("T"."CODECR"="P"."CODECR" AND "P"."SOMME"='IMMINENTCAP')



-- cazqv8wmf2f6k

Plan hash value: 2984129496
---------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                            | Name              | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers |
---------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                     |                   |      1 |        |     1 (100)|      1 |00:00:00.01 |       3 |
|   1 |  SORT AGGREGATE                      |                   |      1 |      1 |            |      1 |00:00:00.01 |       3 |
|   2 |   TABLE ACCESS BY INDEX ROWID BATCHED| T_INVLOT_ITEM     |      1 |      1 |     1   (0)|      0 |00:00:00.01 |       3 |
|*  3 |    INDEX RANGE SCAN                  | INVLOT_ITEM_LOTID |      1 |      1 |     1   (0)|      0 |00:00:00.01 |       3 |
---------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   3 - access("LOT_ID"=:TLOGID)
*/
/********************************OLD Metrics***************************************/

/********************************New SQL*******************************************/
-- 5jxhrbmqdbn0u

SELECT /*+ index(T_INVLOT_ITEM INVLOT_ITEM_PK) */
       * 
  FROM T_INVLOT_ITEM 
 WHERE LOT_ID = :B2 
   AND SEQNUM = :B1 ;


-- du4zvvhbhzvcu

UPDATE /*+ index(T_INVLOT_ITEM INVLOT_ITEM_PK) */
       T_INVLOT_ITEM
   SET IMX_REFERENCE    = NVL(:B4, :B3),
       IMX_PROCESSED    = NVL(IMX_PROCESSED, 0) + 1,
       IMX_RETRY        = 0,
       IMX_DATE_PROCESS = SYSDATE
 WHERE LOT_ID = :B2
   AND SEQNUM = :B1;


-- gfbgdvqb427xq

SELECT /*+ leading(T E) index(T IDX_FFSI_T_ECRDOS) index(E EFI_REFELEM)*/
       NVL(SUM(NVL(T.MNT_DCPT, 0) *
               DECODE(P.ELEMENT,
                      'dbdu',
                      DECODE(P.SENS, '-', -1, 1),
                      DECODE(P.SENS, '+', -1, 1))),
           0)
  FROM V_CALDOS P, 
       T_ECRDOS T, 
       G_ELEMFI E, 
       V_ELEMFI V
 WHERE P.SOMME = 'IMMINENTCAP'
   AND T.CODECR = P.CODECR
   AND T.REFDOSS = :B1
   AND T.TYPELEM = 'f'
   AND E.REFELEM = T.REFELEM
   AND V.TYPE = E.TYPE
   AND NVL(V.FG_EXCLUDE_IMMINENT_CAPITAL, 'N') != 'O';


-- cazqv8wmf2f6k

SELECT /*+ index(t_invlot_ITEM INVLOT_ITEM_PK)*/
       NVL(MAX(SEQNUM), 0) + 1 
  FROM t_invlot_ITEM 
 WHERE LOT_ID = :tLogId;
/********************************New SQL*******************************************/
/********************************New Metrics***************************************/
/*
-- 5jxhrbmqdbn0u

Plan hash value: 1820427261
---------------------------------------------------------------------------------------------------------------------
| Id  | Operation                   | Name           | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers |
---------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT            |                |      1 |        |     1 (100)|      1 |00:00:00.01 |       4 |
|   1 |  TABLE ACCESS BY INDEX ROWID| T_INVLOT_ITEM  |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       4 |
|*  2 |   INDEX UNIQUE SCAN         | INVLOT_ITEM_PK |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |
---------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   2 - access("LOT_ID"=:B2 AND "SEQNUM"=:B1)



-- du4zvvhbhzvcu

Plan hash value: 4021889093
------------------------------------------------------------------------------------------------------------
| Id  | Operation          | Name           | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers |
------------------------------------------------------------------------------------------------------------
|   0 | UPDATE STATEMENT   |                |      1 |        |     1 (100)|      0 |00:00:00.01 |      10 |
|   1 |  UPDATE            | T_INVLOT_ITEM  |      1 |        |            |      0 |00:00:00.01 |      10 |
|*  2 |   INDEX UNIQUE SCAN| INVLOT_ITEM_PK |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |
------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   2 - access("LOT_ID"=:B2 AND "SEQNUM"=:B1)



-- gfbgdvqb427xq

Plan hash value: 3861647839
------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                               | Name              | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers |
------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                        |                   |      1 |        |     4 (100)|      1 |00:00:00.01 |      19 |
|   1 |  SORT AGGREGATE                         |                   |      1 |      1 |            |      1 |00:00:00.01 |      19 |
|   2 |   NESTED LOOPS                          |                   |      1 |      1 |     4   (0)|      0 |00:00:00.01 |      19 |
|   3 |    NESTED LOOPS                         |                   |      1 |      1 |     4   (0)|      0 |00:00:00.01 |      19 |
|   4 |     NESTED LOOPS                        |                   |      1 |      1 |     3   (0)|      3 |00:00:00.01 |      14 |
|   5 |      NESTED LOOPS                       |                   |      1 |      1 |     2   (0)|      3 |00:00:00.01 |      11 |
|*  6 |       INDEX RANGE SCAN                  | IDX_FFSI_T_ECRDOS |      1 |      1 |     1   (0)|      3 |00:00:00.01 |       3 |
|   7 |       TABLE ACCESS BY INDEX ROWID       | G_ELEMFI          |      3 |      1 |     1   (0)|      3 |00:00:00.01 |       8 |
|*  8 |        INDEX UNIQUE SCAN                | EFI_REFELEM       |      3 |      1 |     1   (0)|      3 |00:00:00.01 |       5 |
|*  9 |      TABLE ACCESS BY INDEX ROWID BATCHED| V_ELEMFI          |      3 |      1 |     1   (0)|      3 |00:00:00.01 |       3 |
|* 10 |       INDEX RANGE SCAN                  | VF_TYPE_FINANCING |      3 |      1 |     1   (0)|      3 |00:00:00.01 |       2 |
|* 11 |     INDEX RANGE SCAN                    | VCALDOS_SC        |      3 |      1 |     1   (0)|      0 |00:00:00.01 |       5 |
|  12 |    TABLE ACCESS BY INDEX ROWID          | V_CALDOS          |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   6 - access("T"."REFDOSS"=:B1 AND "T"."TYPELEM"='f')
   8 - access("E"."REFELEM"="T"."REFELEM")
   9 - filter(NVL("V"."FG_EXCLUDE_IMMINENT_CAPITAL",'N')<>'O')
  10 - access("V"."TYPE"="E"."TYPE")
  11 - access("T"."CODECR"="P"."CODECR" AND "P"."SOMME"='IMMINENTCAP')   



-- cazqv8wmf2f6k

Plan hash value: 221948905
----------------------------------------------------------------------------------------------------------------------
| Id  | Operation                    | Name           | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers |
----------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT             |                |      1 |        |     1 (100)|      1 |00:00:00.01 |       3 |
|   1 |  SORT AGGREGATE              |                |      1 |      1 |            |      1 |00:00:00.01 |       3 |
|   2 |   FIRST ROW                  |                |      1 |      1 |     1   (0)|      0 |00:00:00.01 |       3 |
|*  3 |    INDEX RANGE SCAN (MIN/MAX)| INVLOT_ITEM_PK |      1 |      1 |     1   (0)|      0 |00:00:00.01 |       3 |
----------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   3 - access("LOT_ID"=:TLOGID)   
*/
/********************************New Metrics***************************************/

/********************************Index statistics**********************************/

/********************************Other SQLs****************************************/          
/*

*/ 
/********************************Other SQLs****************************************/              
