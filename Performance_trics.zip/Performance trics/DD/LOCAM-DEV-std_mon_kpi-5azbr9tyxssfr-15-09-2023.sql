/********************************************************************************
*********       E-mail subject: LOCAMDEV-21547
*********             Instance: DEV
*********          Description: 
Problem:
On 14/09/2023 there was a slowness on instance YONEVAL.

Analysis:
After the investigation we found that the top SQL from module std_mon_kpi matches with the provided 
SQL in the task description. The problem is that there is no index on columns call_type and dt_endproc_dt 
on table msg_queue_hist and that's why Oracle makes a full scan of table msg_queue_hist.


Suggestion:
Please create index on columns call_type and dt_endproc_dt on table msg_queue_hist.

*********               SQL_ID: 5azbr9tyxssfr
*********      Program/Package: std_mon_kpi
*********              Request: Ivelin Palahanov
*********               Author: Dimitar Dimitrov
********* Received e-mail date: 15/09/2023
*********      Resolution date: 15/09/2023
*********  Trace old file here: \\epox\specifs\performance\tmp\
*********  Trace new file here:
***********************************************************************************/

/********************************OLD SQL*******************************************/

select nvl(ROUND(AVG((msgq . dt_endproc_dt - msgq . dtprocess_dt) *
                     (24 * 60 * 60)),
                 2),
           0),
       to_char(sysdate, 'ddmmyyyy hh24:mi:ss')
  INTO :b0, :b1
  FROM msg_queue_hist msgq
 WHERE msgq . call_type = substr(:b2, 6)
   AND msgq . dt_endproc_dt >= to_date(:b3, 'ddmmyyyy hh24:mi:ss');

/********************************OLD SQL*******************************************/
/********************************OLD Metrics***************************************/
/*
 MODULE                           SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
std_mon_kpi                                    3938332083                       direct path read     2023/09/14 12:51:25  2023/09/14 12:51:45          21                  564 +000000000 00:00:20.000 100%


MODULE                           SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
std_mon_kpi                      5azbr9tyxssfr 3938332083                       direct path read     2023/09/14 12:51:25  2023/09/14 12:51:45          20                    8 +000000000 00:00:20.000 95%
std_mon_kpi                      8yv96h5bgh3pq 3938332083         49      38393 direct path read     2023/09/14 12:51:25  2023/09/14 12:51:25           1                    1 +000000000 00:00:00.000 5%


Plan hash value: 3938332083
--------------------------------------------------------------------------------------------------------
| Id  | Operation          | Name           | Starts | E-Rows | A-Rows |   A-Time   | Buffers | Reads  |
--------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT   |                |      1 |        |      1 |00:00:06.89 |   62509 |  62499 |
|   1 |  SORT AGGREGATE    |                |      1 |      1 |      1 |00:00:06.89 |   62509 |  62499 |
|*  2 |   TABLE ACCESS FULL| MSG_QUEUE_HIST |      1 |      1 |  15710 |00:00:06.89 |   62509 |  62499 |
--------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   2 - filter(("MSGQ"."CALL_TYPE"=SUBSTR(:B2,6) AND
              "MSGQ"."DT_ENDPROC_DT">=TO_DATE(:B3,'ddmmyyyy hh24:mi:ss'))) 
*/
/********************************OLD Metrics***************************************/

/********************************New SQL*******************************************/

/********************************New SQL*******************************************/
/********************************New Metrics***************************************/
/*
Plan hash value: 1149345995
--------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                            | Name           | Starts | E-Rows | A-Rows |   A-Time   | Buffers | Reads  |
--------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                     |                |      1 |        |      1 |00:00:00.12 |   12155 |    378 |
|   1 |  SORT AGGREGATE                      |                |      1 |      1 |      1 |00:00:00.12 |   12155 |    378 |
|   2 |   TABLE ACCESS BY INDEX ROWID BATCHED| MSG_QUEUE_HIST |      1 |      1 |  15710 |00:00:00.11 |   12155 |    378 |
|*  3 |    INDEX RANGE SCAN                  | TESD_DI_IDX    |      1 |      1 |  15710 |00:00:00.02 |      60 |     59 |
--------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   3 - access("MSGQ"."CALL_TYPE"=SUBSTR(:B2,6) AND "MSGQ"."DT_ENDPROC_DT">=TO_DATE(:B3,'ddmmyyyy hh24:mi:ss') AND
              "MSGQ"."DT_ENDPROC_DT" IS NOT NULL) 
*/
/********************************New Metrics***************************************/

/********************************Index statistics**********************************/

/********************************Other SQLs****************************************/          
/*

*/ 
/********************************Other SQLs****************************************/              
