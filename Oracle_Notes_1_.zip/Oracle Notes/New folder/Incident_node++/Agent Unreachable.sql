========================================================================================

########## Agent Unreachable (REASON = Unable to connect to the agent at https://srv5201.thyssen.com:1840/emd/main/ [Connection establishment timed out]). Host is Unreachable (REASON = Ping timed out.). Event Type: OEM

========================================================================================



[root@srv5201 ~]# cd /oraagent
[root@srv5201 oraagent]# ls -la
total 4
drwxr-xr-x.  3 oracle dba    21 May 14  2018 .
dr-xr-xr-x. 28 root   root 4096 Jul 17  2018 ..
drwxr-xr-x.  3 oracle dba    19 May 14  2018 product


[root@srv5201 oraagent]# cd product
[root@srv5201 product]# ls -la
total 0
drwxr-xr-x. 3 oracle dba  19 May 14  2018 .
drwxr-xr-x. 3 oracle dba  21 May 14  2018 ..
drwxr-xr-x. 6 oracle dba 137 May 15  2018 agent


[root@srv5201 product]# cd agent
[root@srv5201 agent]# ls -la
total 16
drwxr-xr-x. 6 oracle dba  137 May 15  2018 .
drwxr-xr-x. 3 oracle dba   19 May 14  2018 ..
-rw-rw-r--. 1 oracle dba  178 May 24  2014 agentimage.properties
drwxr-xr-x. 7 oracle dba   74 Jul 17  2018 agent_inst
drwxr-xr-x. 3 oracle dba   24 May 15  2018 core
drwxr-xr-x. 8 oracle dba 4096 May 15  2018 plugins
-rwxr-xr-x. 1 oracle dba  223 May 15  2018 plugins.txt
-rw-r--r--. 1 oracle dba  298 May 15  2018 plugins.txt.status
drwxr-xr-x. 5 oracle dba  246 May 15  2018 sbin


[root@srv5201 agent]# cd sbin
[root@srv5201 sbin]# ls -la
total 2636
drwxr-xr-x.  5 oracle dba    246 May 15  2018 .
drwxr-xr-x.  6 oracle dba    137 May 15  2018 ..
drwxr-xr-x.  3 oracle dba     17 May 15  2018 cfgtoollogs
drwxr-xr-x.  3 oracle dba     28 May 24  2014 install
drwxrwx---. 11 oracle dba    205 May 24  2014 inventory
-rws--x---.  1 root   dba  22754 May 15  2018 nmb
-rwx--x--x.  1 oracle dba  22754 May 24  2014 nmb.0
-rwxr-xr-x.  1 root   dba  43494 May 15  2018 nmgsshe
-rwx--x--x.  1 oracle dba  43494 May 24  2014 nmgsshe.0
-rws--x---.  1 root   dba  57835 May 15  2018 nmhs
-rwx--x--x.  1 oracle dba  57835 May 24  2014 nmhs.0
-rws--x---.  1 root   dba  41060 May 15  2018 nmo
-rwx--x--x.  1 oracle dba  41060 May 24  2014 nmo.0
-rwxr-xr-x.  1 root   dba 585242 May 15  2018 nmopdpx
-rwx--x--x.  1 oracle dba 585242 May 24  2014 nmopdpx.0
-rwxr-xr-x.  1 root   dba 585242 May 15  2018 nmosudo
-rwx--x--x.  1 oracle dba 585242 May 24  2014 nmosudo.0
-rw-r-----.  1 oracle dba     51 Apr 30  2018 oraInst.loc


[root@srv5201 sbin]# locate emctl
/oraagent/product/agent/agent_inst/bin/emctl
/oraagent/product/agent/agent_inst/sysman/log/emctl.log
/oraagent/product/agent/agent_inst/sysman/log/emctlLockFile.lck
/oraagent/product/agent/core/12.1.0.4.0/bin/emctl
/oraagent/product/agent/core/12.1.0.4.0/bin/emctl.ouibak
/oraagent/product/agent/core/12.1.0.4.0/bin/emctl.pl
/oraagent/product/agent/core/12.1.0.4.0/bin/emctl.pl.ouibak
/oraagent/product/agent/core/12.1.0.4.0/bin/emctl.template
/oraagent/product/agent/core/12.1.0.4.0/bin/emctl.template.ouibak
/oraagent/product/agent/core/12.1.0.4.0/bin/emctl_old
/oraagent/product/agent/core/12.1.0.4.0/inventory/Templates/bin/emctl.pl.template
/oraagent/product/agent/core/12.1.0.4.0/inventory/Templates/bin/emctl.template
/usr/bin/systemctl
/usr/share/bash-completion/completions/systemctl
/usr/share/man/man1/systemctl.1.gz
/usr/share/zsh/site-functions/_systemctl


[root@srv5201 sbin]# su - oracle
Last login: Tue Aug  6 05:33:05 CEST 2019

oracle@srv5201:/home/oracle:> cd /oraagent/product/agent/core/12.1.0.4.0/bin           #### Отиваме в директорията,където е локиран emctl ###
oracle@srv5201:/oraagent/product/agent/core/12.1.0.4.0/bin:>
oracle@srv5201:/oraagent/product/agent/core/12.1.0.4.0/bin:>
oracle@srv5201:/oraagent/product/agent/core/12.1.0.4.0/bin:>
oracle@srv5201:/oraagent/product/agent/core/12.1.0.4.0/bin:>

oracle@srv5201:/oraagent/product/agent/core/12.1.0.4.0/bin:> ./emctl status agent
Oracle Enterprise Manager Cloud Control 12c Release 4
Copyright (c) 1996, 2014 Oracle Corporation.  All rights reserved.
---------------------------------------------------------------
Agent Version          : 12.1.0.4.0
OMS Version            : 12.1.0.4.0
Protocol Version       : 12.1.0.1.0
Agent Home             : /oraagent/product/agent/agent_inst
Agent Log Directory    : /oraagent/product/agent/agent_inst/sysman/log
Agent Binaries         : /oraagent/product/agent/core/12.1.0.4.0
Agent Process ID       : 26892
Parent Process ID      : 26461
Agent URL              : https://srv5201.thyssen.com:1840/emd/main/
Local Agent URL in NAT : https://srv5201.thyssen.com:1840/emd/main/
Repository URL         : https://absemp.thyssen.com:4900/empbs/upload
Started at             : 2018-07-17 16:44:53
Started by user        : oracle
Operating System       : Linux version 3.10.0-862.el7.x86_64 (amd64)
Last Reload            : 2018-07-17 17:09:47
Last successful upload                       : 2019-08-06 12:45:04
Last attempted upload                        : 2019-08-06 12:45:04
Total Megabytes of XML files uploaded so far : 1,073.99
Number of XML files pending upload           : 0
Size of XML files pending upload(MB)         : 0
Available disk space on upload filesystem    : 65.83%
Collection Status                            : Collections enabled
Heartbeat Status                             : Ok
Last attempted heartbeat to OMS              : 2019-08-06 12:44:10
Last successful heartbeat to OMS             : 2019-08-06 12:44:10
Next scheduled heartbeat to OMS              : 2019-08-06 12:45:10

---------------------------------------------------------------
Agent is Running and Ready
oracle@srv5201:/oraagent/product/agent/core/12.1.0.4.0/bin:>

######## Agent-a e running затваряме кейса, ако не е правим: ./emctl start agent ######

