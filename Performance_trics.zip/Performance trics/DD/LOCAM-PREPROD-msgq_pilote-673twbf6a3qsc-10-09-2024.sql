/********************************************************************************
*********       E-mail subject: LOCAMWEB-10108
*********             Instance: PREPROD
*********          Description: 
Problem:
SE variable upd_cot1 took over 15 minutes on PREPROD.

Analysis:
We checked in the AWR for the provided SID from the log in the task and found that SE Variable upd_cot1 was executed with sql_id 673twbf6a3qsc.
The main problem in this SQL are the ORs, which doesn't allow Oracle to choose good execution plan.
The solution here is to rewrite the ORs into UNIONs.

Suggestion:
Please change the query as it is shown in the New SQL section below.

*********               SQL_ID: 673twbf6a3qsc
*********      Program/Package: SE variable upd_cot1
*********              Request: Radka Zdravkova
*********               Author: Dimitar Dimitrov
********* Received e-mail date: 10/09/2024
*********      Resolution date: 10/09/2024
*********  Trace old file here: \\epox\specifs\performance\tmp\
*********  Trace new file here:
***********************************************************************************/

/********************************OLD SQL*******************************************/
var refdos varchar2(32);
exec :refdos := '2407230186';

update t_scor_res
   set ext_cotation = ( select p.str2
                          from g_individu g, 
                               t_intervenants t,
                               g_indivparam p
                         where t.refdoss = :refdos
                           and t.reftype = 'DB'
                           and p.type = 'COTE FACTOR'
                           and p.refindividu = g.refindividu
                           and p.str1 = 'ELLISPHERE'
                           and (  t.refindividu = g.refindividu 
                               or exists ( select 1
                                             from g_societe soc
                                            where ( (     soc.refsoc = t.refindividu 
                                                      and nvl(g.fg_head_office, 'N') = 'O' ) 
                                                  or soc.refindividu = t.refindividu )
                                              and ( (     soc.refsoc = g.refindividu
                                                      and nvl(g.fg_head_office, 'N' ) = 'O' ) 
                                                  or soc.refindividu = g.refindividu ) ) )
                           and nvl(p.dt11_dt, utl_app_date.getAppDate) = ( select nvl(max(dt11_dt), utl_app_date.getAppDate)
                                                                             from g_indivparam soc1
                                                                            where soc1.refindividu = p.refindividu
                                                                              and soc1.type = 'COTE FACTOR'
                                                                              and soc1.str1 = 'ELLISPHERE' )
                           and rownum = 1)
 where reffr = :refdos
   and imx_un_id = ( select max(imx_un_id) 
                       from t_scor_res 
                      where reffr = :refdos );
/********************************OLD SQL*******************************************/
/********************************OLD Metrics***************************************/
/*

MODULE                           PROGRAM                                            CLIENT_ID       SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- -------------------------------------------------- --------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
msgq_pilote                      msg_q04                                                                                           1074      41902 ON CPU               2024/09/06 10:00:06  2024/09/06 11:14:22        149                     2 +000000000 01:14:16.255 100%


MODULE                           PROGRAM                                            CLIENT_ID       SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- -------------------------------------------------- --------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
msgq_pilote                      msg_q04                                                            673twbf6a3qsc 3163291324       1074      41902 ON CPU               2024/09/06 10:00:06  2024/09/06 10:28:37        147                     2 +000000000 00:28:30.911 99%
msgq_pilote                      msg_q04                                                            77b6rncs68tum 2207822937       1074      41902 ON CPU               2024/09/06 11:14:22  2024/09/06 11:14:22          1                       +000000000 00:00:00.000 1%
msgq_pilote                      msg_q04                                                            c2fujsufmr9xf   86149342       1074      41902 ON CPU               2024/09/06 10:10:30  2024/09/06 10:10:30          1                       +000000000 00:00:00.000 1%


SQL_ID        SQL_PLAN_HASH_VALUE SQL_PLAN_LINE_ID SQL_PLAN_OPERATION             SQL_PLAN_OPTIONS                   ACTIVE
------------- ------------------- ---------------- ------------------------------ ------------------------------ ----------
673twbf6a3qsc          3163291324               20 INDEX                          SKIP SCAN                             464
673twbf6a3qsc          3163291324               19 TABLE ACCESS                   BY INDEX ROWID                          1
673twbf6a3qsc          3163291324               16 TABLE ACCESS                   BY INDEX ROWID BATCHED                  1
673twbf6a3qsc          3163291324               18 INDEX                          UNIQUE SCAN                             1



INSTANCE_NUMBER SQL_ID            ELAPSED MAX_WAIT_ON     PC_OF  WAIT_TIME            GETS      READS       ROWS  ELAP/EXEC       GETS/EXEC READS/EXEC  ROWS/EXEC       EXEC PLAN_HASH_VALUE
--------------- ------------- ----------- --------------- ----- ---------- --------------- ---------- ---------- ---------- --------------- ---------- ---------- ---------- ---------------
              1 673twbf6a3qsc         506 CPU             100%  503.239498        10597137          0          0     506.14        10597137          0          0          0      3163291324
              1 673twbf6a3qsc           0 CPU             100%     .001241               0          0          0          0               0          0          0          0               0


Plan hash value: 3163291324
----------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                    | Name                 | E-Rows |E-Bytes| Cost (%CPU)| E-Time   |
----------------------------------------------------------------------------------------------------------------------
|   0 | UPDATE STATEMENT                             |                      |        |       |   178 (100)|          |
|   1 |  UPDATE                                      | T_SCOR_RES           |        |       |            |          |
|   2 |   TABLE ACCESS BY INDEX ROWID                | T_SCOR_RES           |      1 |   165 |     1   (0)| 00:00:01 |
|   3 |    INDEX UNIQUE SCAN                         | PK_T_SCOR_RES        |      1 |       |     1   (0)| 00:00:01 |
|   4 |     SORT AGGREGATE                           |                      |      1 |    16 |            |          |
|   5 |      TABLE ACCESS BY INDEX ROWID BATCHED     | T_SCOR_RES           |      1 |    16 |     1   (0)| 00:00:01 |
|   6 |       INDEX RANGE SCAN                       | TSR_REFFR_IDX        |      1 |       |     1   (0)| 00:00:01 |
|   7 |   COUNT STOPKEY                              |                      |        |       |            |          |
|   8 |    VIEW                                      | VW_ORE_B272A5F8      |      2 |   324 |   176   (0)| 00:00:01 |
|   9 |     UNION-ALL                                |                      |        |       |            |          |
|  10 |      FILTER                                  |                      |        |       |            |          |
|  11 |       NESTED LOOPS                           |                      |    322 | 24472 |     8   (0)| 00:00:01 |
|  12 |        NESTED LOOPS                          |                      |    322 | 24472 |     8   (0)| 00:00:01 |
|  13 |         MERGE JOIN CARTESIAN                 |                      |    322 | 20930 |     2   (0)| 00:00:01 |
|  14 |          INDEX RANGE SCAN                    | INT_REFDOSS          |      1 |    24 |     1   (0)| 00:00:01 |
|  15 |          BUFFER SORT                         |                      |    322 | 13202 |     1   (0)| 00:00:01 |
|  16 |           TABLE ACCESS BY INDEX ROWID BATCHED| G_INDIVPARAM         |    322 | 13202 |     1   (0)| 00:00:01 |
|  17 |            INDEX RANGE SCAN                  | G_INDPAR_TYPSTR1_IDX |    322 |       |     1   (0)| 00:00:01 |
|  18 |         INDEX UNIQUE SCAN                    | IND_REFINDIV         |      1 |       |     1   (0)| 00:00:01 |
|  19 |        TABLE ACCESS BY INDEX ROWID           | G_INDIVIDU           |      1 |    11 |     1   (0)| 00:00:01 |
|  20 |       INDEX SKIP SCAN                        | REF_SOC              |      1 |    18 |     1   (0)| 00:00:01 |
|  21 |       SORT AGGREGATE                         |                      |      1 |    38 |            |          |
|  22 |        TABLE ACCESS BY INDEX ROWID BATCHED   | G_INDIVPARAM         |      1 |    38 |     1   (0)| 00:00:01 |
|  23 |         INDEX RANGE SCAN                     | G_INDIVPARAM_REFIND  |      1 |       |     1   (0)| 00:00:01 |
|  24 |      FILTER                                  |                      |        |       |            |          |
|  25 |       NESTED LOOPS                           |                      |      1 |    76 |     3   (0)| 00:00:01 |
|  26 |        NESTED LOOPS                          |                      |      1 |    76 |     3   (0)| 00:00:01 |
|  27 |         NESTED LOOPS                         |                      |      1 |    35 |     2   (0)| 00:00:01 |
|  28 |          INDEX RANGE SCAN                    | INT_REFDOSS          |      1 |    24 |     1   (0)| 00:00:01 |
|  29 |          TABLE ACCESS BY INDEX ROWID         | G_INDIVIDU           |      1 |    11 |     1   (0)| 00:00:01 |
|  30 |           INDEX UNIQUE SCAN                  | IND_REFINDIV         |      1 |       |     1   (0)| 00:00:01 |
|  31 |         INDEX RANGE SCAN                     | G_INDIVPARAM_REFIND  |      1 |       |     1   (0)| 00:00:01 |
|  32 |        TABLE ACCESS BY INDEX ROWID           | G_INDIVPARAM         |      1 |    41 |     1   (0)| 00:00:01 |
|  33 |       SORT AGGREGATE                         |                      |      1 |    38 |            |          |
|  34 |        TABLE ACCESS BY INDEX ROWID BATCHED   | G_INDIVPARAM         |      1 |    38 |     1   (0)| 00:00:01 |
|  35 |         INDEX RANGE SCAN                     | G_INDIVPARAM_REFIND  |      1 |       |     1   (0)| 00:00:01 |
|  36 |       INDEX SKIP SCAN                        | REF_SOC              |      1 |    18 |     1   (0)| 00:00:01 |
----------------------------------------------------------------------------------------------------------------------



*/
/********************************OLD Metrics***************************************/

/********************************New SQL*******************************************/

update t_scor_res 
   set ext_cotation = ( select  p.str2 
                          from ( select g.refindividu
                                   from t_intervenants t,
                                        g_individu g
                                  where t.refdoss = :refdos
                                    and t.reftype = 'DB'
                                    and t.refindividu = g.refindividu
                                  union
                                 select g.refindividu
                                   from t_intervenants t,
                                        g_individu g,
                                        g_societe soc
                                  where t.refdoss = :refdos 
                                    and t.reftype = 'DB'
                                    and soc.refsoc = t.refindividu 
                                    and soc.refsoc = g.refindividu 
                                    and nvl(g.fg_head_office, 'N') = 'O'
                                  union
                                 select g.refindividu
                                   from t_intervenants t,
                                        g_individu g,
                                        g_societe soc
                                  where t.refdoss = :refdos
                                    and t.reftype = 'DB'
                                    and soc.refsoc = t.refindividu
                                    and nvl(g.fg_head_office, 'N') = 'O'
                                    and soc.refindividu = g.refindividu
                                  union
                                 select g.refindividu
                                   from t_intervenants t,
                                        g_individu g,
                                        g_societe soc
                                  where t.refdoss = :refdos
                                    and t.reftype = 'DB'
                                    and soc.refindividu = t.refindividu
                                    and soc.refsoc = g.refindividu
                                    and nvl(g.fg_head_office, 'N') = 'O'
                                  union
                                 select g.refindividu
                                   from t_intervenants t,
                                        g_individu g,
                                        g_societe soc
                                  where t.refdoss = :refdos
                                    and t.reftype = 'DB'
                                    and soc.refindividu = t.refindividu
                                    and soc.refindividu = g.refindividu ) gt,
                               g_indivparam p 
                         where p.type = 'COTE FACTOR' 
                           and p.refindividu = gt.refindividu 
                           and p.str1 = 'ELLISPHERE' 
                           and nvl(p.dt11_dt,sysdate) = ( select nvl(max(dt11_dt),sysdate) 
                                                            from g_indivparam soc1 
                                                           where soc1.refindividu = p.refindividu 
                                                             and soc1.type = 'COTE FACTOR' 
                                                             and soc1.str1 = 'ELLISPHERE' )
                           and rownum = 1 )
 where reffr = :refdos
   and imx_un_id = ( select max(imx_un_id)
                       from t_scor_res
                      where reffr = :refdos );  
/********************************New SQL*******************************************/
/********************************New Metrics***************************************/
/*
Plan hash value: 628746078
--------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                     | Name                | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers |
--------------------------------------------------------------------------------------------------------------------------------------------
|   0 | UPDATE STATEMENT                              |                     |      1 |        |    21 (100)|      0 |00:00:00.01 |      48 |
|   1 |  UPDATE                                       | T_SCOR_RES          |      1 |        |            |      0 |00:00:00.01 |      48 |
|*  2 |   TABLE ACCESS BY INDEX ROWID                 | T_SCOR_RES          |      1 |      1 |     1   (0)|      1 |00:00:00.01 |      15 |
|*  3 |    INDEX UNIQUE SCAN                          | PK_T_SCOR_RES       |      1 |      1 |     1   (0)|      1 |00:00:00.01 |      14 |
|   4 |     SORT AGGREGATE                            |                     |      1 |      1 |            |      1 |00:00:00.01 |      12 |
|   5 |      TABLE ACCESS BY INDEX ROWID BATCHED      | T_SCOR_RES          |      1 |      1 |     1   (0)|     14 |00:00:00.01 |      12 |
|*  6 |       INDEX RANGE SCAN                        | TSR_REFFR_IDX       |      1 |      1 |     1   (0)|     14 |00:00:00.01 |       2 |
|*  7 |   COUNT STOPKEY                               |                     |      1 |        |            |      0 |00:00:00.01 |      26 |
|*  8 |    FILTER                                     |                     |      1 |        |            |      0 |00:00:00.01 |      26 |
|   9 |     NESTED LOOPS                              |                     |      1 |      1 |    17  (18)|      0 |00:00:00.01 |      26 |
|  10 |      NESTED LOOPS                             |                     |      1 |     11 |    17  (18)|      0 |00:00:00.01 |      26 |
|  11 |       VIEW                                    |                     |      1 |     11 |    16  (19)|      1 |00:00:00.01 |      23 |
|  12 |        SORT UNIQUE                            |                     |      1 |     11 |    16  (19)|      1 |00:00:00.01 |      23 |
|  13 |         UNION-ALL                             |                     |      1 |        |            |      1 |00:00:00.01 |      23 |
|* 14 |          INDEX RANGE SCAN                     | INT_REFDOSS         |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |
|  15 |          NESTED LOOPS SEMI                    |                     |      1 |      1 |     3   (0)|      0 |00:00:00.01 |       5 |
|  16 |           NESTED LOOPS                        |                     |      1 |      1 |     2   (0)|      0 |00:00:00.01 |       5 |
|* 17 |            INDEX RANGE SCAN                   | INT_REFDOSS         |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |
|* 18 |            INDEX RANGE SCAN                   | G_SOCIETE$REFSOC    |      1 |      1 |     1   (0)|      0 |00:00:00.01 |       2 |
|* 19 |           TABLE ACCESS BY INDEX ROWID         | G_INDIVIDU          |      0 |  82317 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 20 |            INDEX UNIQUE SCAN                  | IND_REFINDIV        |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|  21 |          NESTED LOOPS SEMI                    |                     |      1 |      1 |     3   (0)|      0 |00:00:00.01 |       5 |
|  22 |           NESTED LOOPS                        |                     |      1 |      1 |     2   (0)|      0 |00:00:00.01 |       5 |
|* 23 |            INDEX RANGE SCAN                   | INT_REFDOSS         |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |
|  24 |            TABLE ACCESS BY INDEX ROWID BATCHED| G_SOCIETE           |      1 |      1 |     1   (0)|      0 |00:00:00.01 |       2 |
|* 25 |             INDEX RANGE SCAN                  | G_SOCIETE$REFSOC    |      1 |      1 |     1   (0)|      0 |00:00:00.01 |       2 |
|* 26 |           TABLE ACCESS BY INDEX ROWID         | G_INDIVIDU          |      0 |  82317 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 27 |            INDEX UNIQUE SCAN                  | IND_REFINDIV        |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|  28 |          NESTED LOOPS SEMI                    |                     |      1 |      4 |     3   (0)|      0 |00:00:00.01 |       5 |
|  29 |           NESTED LOOPS                        |                     |      1 |      4 |     2   (0)|      0 |00:00:00.01 |       5 |
|* 30 |            INDEX RANGE SCAN                   | INT_REFDOSS         |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |
|* 31 |            INDEX RANGE SCAN                   | REF_SOC             |      1 |      4 |     1   (0)|      0 |00:00:00.01 |       2 |
|* 32 |           TABLE ACCESS BY INDEX ROWID         | G_INDIVIDU          |      0 |  82317 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 33 |            INDEX UNIQUE SCAN                  | IND_REFINDIV        |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|  34 |          NESTED LOOPS SEMI                    |                     |      1 |      4 |     3   (0)|      0 |00:00:00.01 |       5 |
|  35 |           NESTED LOOPS                        |                     |      1 |      4 |     2   (0)|      0 |00:00:00.01 |       5 |
|* 36 |            INDEX RANGE SCAN                   | INT_REFDOSS         |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |
|* 37 |            INDEX RANGE SCAN                   | REF_SOC             |      1 |      4 |     1   (0)|      0 |00:00:00.01 |       2 |
|* 38 |           INDEX UNIQUE SCAN                   | IND_REFINDIV        |      0 |    426K|     1   (0)|      0 |00:00:00.01 |       0 |
|* 39 |       INDEX RANGE SCAN                        | G_INDIVPARAM_REFIND |      1 |      1 |     1   (0)|      0 |00:00:00.01 |       3 |
|  40 |      TABLE ACCESS BY INDEX ROWID              | G_INDIVPARAM        |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|  41 |     SORT AGGREGATE                            |                     |      0 |      1 |            |      0 |00:00:00.01 |       0 |
|* 42 |      TABLE ACCESS BY INDEX ROWID BATCHED      | G_INDIVPARAM        |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 43 |       INDEX RANGE SCAN                        | G_INDIVPARAM_REFIND |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
--------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   2 - filter("REFFR"=:REFDOS)
   3 - access("IMX_UN_ID"=)
   6 - access("REFFR"=:REFDOS)
   7 - filter(ROWNUM=1)
   8 - filter(NVL("P"."DT11_DT",SYSDATE@!)=)
  14 - access("T"."REFDOSS"=:REFDOS AND "T"."REFTYPE"='DB')
  17 - access("T"."REFDOSS"=:REFDOS AND "T"."REFTYPE"='DB')
  18 - access("SOC"."REFSOC"="T"."REFINDIVIDU")
  19 - filter(NVL("G"."FG_HEAD_OFFICE",'N')='O')
  20 - access("SOC"."REFSOC"="G"."REFINDIVIDU")
  23 - access("T"."REFDOSS"=:REFDOS AND "T"."REFTYPE"='DB')
  25 - access("SOC"."REFSOC"="T"."REFINDIVIDU")
  26 - filter(NVL("G"."FG_HEAD_OFFICE",'N')='O')
  27 - access("SOC"."REFINDIVIDU"="G"."REFINDIVIDU")
  30 - access("T"."REFDOSS"=:REFDOS AND "T"."REFTYPE"='DB')
  31 - access("SOC"."REFINDIVIDU"="T"."REFINDIVIDU")
  32 - filter(NVL("G"."FG_HEAD_OFFICE",'N')='O')
  33 - access("SOC"."REFSOC"="G"."REFINDIVIDU")
  36 - access("T"."REFDOSS"=:REFDOS AND "T"."REFTYPE"='DB')
  37 - access("SOC"."REFINDIVIDU"="T"."REFINDIVIDU")
  38 - access("SOC"."REFINDIVIDU"="G"."REFINDIVIDU")
  39 - access("P"."REFINDIVIDU"="GT"."REFINDIVIDU" AND "P"."TYPE"='COTE FACTOR' AND "P"."STR1"='ELLISPHERE')
       filter("P"."STR1"='ELLISPHERE')
  42 - filter("DT11_DT" IS NOT NULL)
  43 - access("SOC1"."REFINDIVIDU"=:B1 AND "SOC1"."TYPE"='COTE FACTOR' AND "SOC1"."STR1"='ELLISPHERE')
       filter("SOC1"."STR1"='ELLISPHERE')

*/
/********************************New Metrics***************************************/

/********************************Index statistics**********************************/

/********************************Other SQLs****************************************/          
/*

*/ 
/********************************Other SQLs****************************************/              
