/********************************************************************************
*********       E-mail subject: IMBWEB-7511
*********             Instance: ADPROD
*********          Description: 
Problem:
Slowness in ADv2 ADG module on IMB ADPROD.

Analysis:
We found two SQLs with common problem. The problem was that there was no appropriate index on AD_REQUEST_LIMIT_MVIEW 
and a lot of data was unnecessary selected. The solution here is to create index on AD_REQUEST_LIMIT_MVIEW on columns GPIADR3, GPIDEPOT and TYPEDOC.

Suggestion:
Please create index on AD_REQUEST_LIMIT_MVIEW on columns GPIADR3, GPIDEPOT and TYPEDOC.

*********               SQL_ID: 6fshnsd4ctqmz, 81y3pxkbbdmf7
*********      Program/Package: ADv2 ADG 
*********              Request: Julia Tasheva 
*********               Author: Dimitar Dimitrov
********* Received e-mail date: 29/12/2023
*********      Resolution date: 02/01/2024
*********  Trace old file here: \\epox\specifs\performance\tmp\
*********  Trace new file here:
***********************************************************************************/

/********************************OLD SQL*******************************************/

-- 6fshnsd4ctqmz

select *
  from (SELECT /*+no_merge no_push_pred LEADING(cldb lim pol ci cr_i pre_lim ci_lim limcicf fi ext) FULL(cldb)
                INDEX(lim GP_TYPEDOC) INDEX(pol TYPPIECE_LASTLOAD_IND) USE_NL(pol) FULL(ci) USE_HASH(ci) INDEX(cr_i SOC_INDIV)
                FULL(pre_lim) FULL(ci_lim) USE_HASH(ci_lim) INDEX(limcicf GPDET_TYP_REF_IDX) FULL(fi)*/
         lov_ci.ABREV as "Insurance code",
         pol.REFEXT as "Policy number",
         cldb.ANCREFDOSS as "Contract number",
         ext.REFEXT as "CLI_CLI_number",
         db.DEBTOR_REFINDIVIDU as "Debtor number",
         db.DEBTOR_NOM as "Debtor name",
         db.DEBTOR_PAYS as "Debtor country code",
         pay.VALEUR_AL as "Debtor country",
         decode(db.DEBTOR_PAYS, 'AUT', 'Inland', 'Ausland') as "In-/ Ausland",
         TO_CHAR(ADD_MONTHS(SYSDATE, -1), 'MON.YY') as "Month of turnover",
         lim.GPIDTDEB_DT as "Start date of Delkrederelimit",
         NVL(lim.GPIDATE1_DT, lim.GPIDTFIN_DT) as "End date of Delkrederelimit",
         --
         MAX(lim."MT02") as "Delkrederelimit in original currency",
         lim.GPIDEVIS as "Limit currency",
         (CASE
           WHEN (ci_lim.STR2_CI IS NOT NULL OR ci_lim.STR2_CIC IS NOT NULL) THEN
            'SE'
           ELSE
            'GE'
         END) as "Approved Limit/Self decision Limit",
         SUM(CH_TAUX.CONV_ORIG_DEST_TX(AD_JULLIAN_DATE(to_char(TRUNC(SYSDATE,'mm') - 1,'dd/mm/rrrr')),
                                       fi.FI_OPEN_AMOUNT,
                                       fi.FI_DEVISE_MVT,
                                       lim.GPIDEVIS,
                                       'MR',
                                       '')) as "Turnover of previous month for CL/DB in Limit currency",
         SUM(CH_TAUX.CONV_ORIG_DEST_TX(AD_JULLIAN_DATE(to_char(TRUNC(SYSDATE,'mm') - 1,'dd/mm/rrrr')),
                                       fi.FI_AMT_COVERED,
                                       fi.FI_DEVISE_DOS,
                                       lim.GPIDEVIS,
                                       'MR',
                                       '')) as "Insured CL/DB turnover in the limit currency",
         MAX(pre_lim."MT02") as "Previous Delkrederelimit in original limit currency",
         NVL(pre_lim.GPIDATE1_DT, pre_lim.GPIDTFIN_DT) as "End date of previous Delkrederelimit",
         pre_lim.GPIDEVIS as "Previous limit currency",
         MAX(CH_TAUX.CONV_ORIG_DEST_TX(AD_JULLIAN_DATE(to_char(TRUNC(SYSDATE,'mm') - 1,'dd/mm/rrrr')),
                                       f_lim.mt02,
                                       f_lim.GPIDEVIS,
                                       'EUR',
                                       'MR',
                                       '')) as "F Limit in EUR",
         MAX(f_lim.gpidevis) as "F Limit currency"
        --
          FROM G_PIECE lim,
               AD_ACCOUNT_DEBTOR_CLIENT cldb,
               G_PIECE pol,
               (SELECT /*+no_merge no_push_pred*/
                 REFINDIVIDU, REFEXT3, LISTAGG(REFEXT, ', ') as REFEXT
                  FROM (SELECT /*+no_merge no_push_pred FULL(T_INDIVIDU)*/
                         REFINDIVIDU,
                         REFEXT3,
                         REFEXT,
                         ROW_NUMBER() OVER(PARTITION BY REFINDIVIDU, REFEXT3 ORDER BY IMX_UN_ID DESC) rn
                          FROM T_INDIVIDU
                         WHERE SOCIETE = 'CLIENT_NUMBER'
                           AND REFEXT IS NOT NULL)
                 WHERE rn <= 10
                 GROUP BY REFINDIVIDU, REFEXT3) ext,
               AD_DEBTORS db,
               V_DOMAINE pay,
               (SELECT /*+no_merge no_push_pred FULL(AD_FINELEM_3NF) */
                 FI_REFDOSS,
                 SUM(FI_MONTANT_MVT) AS FI_MONTANT_MVT,
                 SUM(AMT_COVERED) AS FI_AMT_COVERED,
                 SUM(FI_OPEN_AMOUNT) AS FI_OPEN_AMOUNT,
                 FI_DEVISE_MVT,
                 FI_DEVISE_DOS
                  FROM AD_FINELEM_3NF
                 WHERE FI_DTJOUR BETWEEN
                       TO_CHAR(TRUNC(TRUNC(SYSDATE, 'mm') - 1, 'mm'), 'j') AND
                       TO_CHAR(TRUNC(SYSDATE, 'mm') - 1, 'j')
                   AND FI_DTANNUL IS NULL
                   AND FI_TYPE IN
                       ('FACTURE', 'NOTE DE CREDIT', 'OTHER DEBIT (SAF)')
                   AND FI_ACTIF IN ('O', 'N')
                   AND INV_STATUS != 'REASSIGNED'
                 GROUP BY FI_REFDOSS, FI_DEVISE_MVT, FI_DEVISE_DOS) fi,
               T_INTERVENANTS ci,
               T_INDIVIDU cr_i,
               AD_REQUEST_LIMIT_MVIEW pre_lim,
               /*( SELECT \*+INDEX(AD_REQUEST_LIMIT_MVIEW AD_REQ_LIMIT_LIBELL_IDX)*\REFPIECE,
                        GPIDEPOT,
                        GPIADR3 ,
                        GPIHEURE,
                        SUM(NVL(mt02, 0)) as mt02
                   FROM AD_REQUEST_LIMIT_MVIEW
                  WHERE typedoc IN ('CI','CIC')
                    AND fg05 = 'O'
               GROUP BY REFPIECE, GPIDEPOT, GPIADR3 , GPIHEURE
               )ci_lim,*/
               (SELECT /*+no_merge no_push_pred*/
                 NVL(ci_lim.GPIHEURE, cldb.ANCREFDOSS) GPIHEURE,
                 ci_lim.GPIADR3,
                 NVL(ci_lim.GPIDEPOT, cldb.CLIENT) GPIDEPOT,
                 MAX(CASE
                       WHEN ci_lim.typedoc = 'CI' THEN
                        ci_lim.MT02
                       else
                        null
                     END) MT02,
                 MAX(CASE
                       WHEN ci_lim.typedoc = 'CI' THEN
                        limcicf.STR2
                     END) STR2_CI,
                 MAX(CASE
                       WHEN ci_lim.typedoc = 'CIC' THEN
                        limcicf.STR2
                     END) STR2_CIC
                  FROM AD_REQUEST_LIMIT_MVIEW ci_lim,
                       G_PIECE pol,
                       AD_ACCOUNT_DEBTOR_CLIENT cldb,
                       (SELECT /*+no_merge no_push_pred INDEX(G_PIECEDET G_PIECEDET_TYPE_LASTLOAD_IDX)*/
                         REFPIECE,
                         STR2,
                         ROW_NUMBER() OVER(PARTITION BY REFPIECE ORDER BY IMX_UN_ID DESC) rn
                          FROM G_PIECEDET
                         WHERE TYPE = 'REQUEST_CF_PROPOSAL'
                           AND STR2 = 'ULA') limcicf
                 WHERE ci_lim.typedoc IN ('CI', 'CIC')
                   AND ci_lim.fg05 = 'O'
                   AND ci_lim.GPIADR3 = cldb.DEBTOR
                   AND limcicf.REFPIECE(+) = ci_lim.REFPIECE
                   AND limcicf.rn(+) = 1
                   AND pol.REFPIECE = ci_lim.LIBELLE_100_8
                   AND pol.TYPPIECE = 'POLICE'
                 GROUP BY NVL(ci_lim.GPIHEURE, cldb.ANCREFDOSS),
                          ci_lim.GPIADR3,
                          NVL(ci_lim.GPIDEPOT, cldb.CLIENT)) ci_lim,
               (SELECT /*+no_merge no_push_pred*/
                 MAX(CASE
                       WHEN a.cnt = 1 THEN
                        ABREV
                       WHEN a.cnt_ctx <> 1 THEN
                        NULL
                       ELSE
                        CASE
                          WHEN a.rn = 1 THEN
                           a.ABREV
                          ELSE
                           NULL
                        END
                     END) ABREV,
                 a.VALEUR
                  FROM (SELECT /*+no_merge no_push_pred*/
                         valeur,
                         abrev,
                         contexte,
                         row_number() over(partition by valeur order by contexte desc NULLS LAST) rn,
                         count(*) over(partition by valeur) cnt,
                         count(DECODE(CONTEXTE, 'O', 1, NULL)) over(partition by valeur) cnt_ctx
                          FROM V_DOMAINE
                         WHERE TYPE = 'CI_IDENT_DBUPLD') a
                 GROUP BY a.VALEUR) lov_ci,
               (select GPIADR3, mt02, gpidevis, GPIDEPOT
                  from AD_REQUEST_LIMIT_MVIEW
                 where typedoc = 'F'
                   and fg05 = 'O') f_lim
         WHERE lim.TYPPIECE = 'REQUEST_LIMITE'
           AND lim.GPIADR3 = cldb.DEBTOR
           AND lim.GPIDEPOT = cldb.CLIENT
           AND lim.GPITYPTRIB = cldb.FACTOR
              --AND lim.GPIHEURE = cldb.ANCREFDOSS
              --AND lim.GPIDEVIS = cldb.DEVISE
           AND lim.FG05 = 'O'
           AND lim.TYPEDOC IN ('C')
           AND pol.TYPPIECE = 'POLICE'
           AND pol.REFPIECE = lim.LIBELLE_100_8
           AND ext.REFINDIVIDU(+) = cldb.DEBTOR
           AND ext.REFEXT3(+) = cldb.ANCREFDOSS
           AND db.DEBTOR_REFINDIVIDU = cldb.DEBTOR
           AND pay.TYPE(+) = 'pays'
           AND pay.ABREV(+) = db.DEBTOR_PAYS
           AND fi.FI_REFDOSS(+) = cldb.REFDOSS
              --AND limcicf.rn(+) = 1
              --AND limcicf.REFPIECE(+) = ci_lim.REFPIECE
           AND ci.reftype(+) = 'DB'
           AND ci.refdoss(+) = pol.refdoss
           AND cr_i.societe(+) = 'CR_INSURER'
           AND cr_i.refindividu(+) = ci.refindividu
           AND lov_ci.VALEUR(+) = cr_i.REFEXT
           AND pre_lim.REFPIECE(+) = lim.ST04
              --
           AND ci_lim.GPIADR3(+) = cldb.DEBTOR
           AND ci_lim.GPIDEPOT(+) = cldb.CLIENT
           AND ci_lim.GPIHEURE(+) = cldb.ANCREFDOSS
              --
           AND ('%' in ('%') or pol.REFEXT IN ('%'))
           AND f_lim.GPIADR3(+) = cldb.DEBTOR
           and f_lim.GPIDEPOT(+) = cldb.CLIENT
         GROUP BY lov_ci.ABREV,
                  pol.REFEXT,
                  cldb.ANCREFDOSS,
                  ext.REFEXT,
                  db.DEBTOR_REFINDIVIDU,
                  db.DEBTOR_NOM,
                  db.DEBTOR_PAYS,
                  pay.VALEUR_AL,
                  lim.GPIDTDEB_DT,
                  lim.GPIDEVIS,
                  pre_lim.GPIDEVIS,
                  NVL(lim.GPIDATE1_DT, lim.GPIDTFIN_DT),
                  NVL(pre_lim.GPIDATE1_DT, pre_lim.GPIDTFIN_DT),
                  CASE
                    WHEN (ci_lim.STR2_CI IS NOT NULL OR
                         ci_lim.STR2_CIC IS NOT NULL) THEN
                     'SE'
                    ELSE
                     'GE'
                  END
         ORDER BY pol.REFEXT, db.DEBTOR_NOM);


-- 81y3pxkbbdmf7

select *
  from (SELECT lov_ci.ABREV as "Insurance code",
               pol.REFEXT as "Policy number",
              ci_lim.MT02 as "Amount of Credit Insurer limit in the original currency",
               cldb.ANCREFDOSS as "Contract number",
               ext.REFEXT as "CLI_CLI_number",
               db.DEBTOR_REFINDIVIDU as "Debtor number",
               db.DEBTOR_NOM as "Debtor name",
               db.DEBTOR_PAYS as "Debtor country code",
               pay.VALEUR_AL as "Debtor country",
               decode(db.DEBTOR_PAYS, 'AUT', 'Inland', 'Ausland') as "In-/ Ausland",
               SUM(CH_TAUX.CONV_ORIG_DEST_TX(AD_JULLIAN_DATE(to_char(TRUNC(SYSDATE,'mm') - 1,'dd/mm/rrrr')),
                                             fi.FI_OPEN_AMOUNT,
                                             fi.FI_DEVISE_DOS,
                                             'EUR',
                                             'MR',
                                             '')) as "Outstanding Balance CL/DB in EUR",
               SUM(CH_TAUX.CONV_ORIG_DEST_TX(AD_JULLIAN_DATE(to_char(TRUNC(SYSDATE,'mm') - 1,'dd/mm/rrrr')),
                                             fi.FI_OPEN_AMOUNT,
                                             fi.FI_DEVISE_DOS,
                                             cldb.DEVISE,
                                             'MR',
                                             '')) as "Outstanding Balance CL/DB in CL/DB currency",
               cldb.DEVISE as "CL/DB Currency",
               MAX(CH_TAUX.CONV_ORIG_DEST_TX(AD_JULLIAN_DATE(to_char(TRUNC(SYSDATE,'mm') - 1,'dd/mm/rrrr')),
                                             DECODE(lim.TYPEDOC,
                                                    'C',
                                                    lim."MT02",
                                                    NULL),
                                             DECODE(lim.TYPEDOC,
                                                    'C',
                                                    lim."GPIDEVIS",
                                                    NULL),
                                             'EUR',
                                             'MR',
                                             '')) as "Active Delcrederelimit in EUR",
               MAX(DECODE(lim.TYPEDOC, 'C', lim.MT02, NULL)) as "Delcrederelimit in original currency",
               MAX(DECODE(lim.TYPEDOC, 'C', lim.GPIDEVIS, NULL)) as "Limit currency",
               lim.REFPIECE as "Limit reference",
               SUM(CH_TAUX.CONV_ORIG_DEST_TX(AD_JULLIAN_DATE(to_char(TRUNC(SYSDATE,'mm') - 1,'dd/mm/rrrr')),
                                             lim_consmp.CONSUMED_AMT,
                                             lim_consmp.LIMIT_CCY,
                                             'EUR',
                                             'MR',
                                             '')) as "Insured outstanding balance CL/DB in EUR",
               SUM(CH_TAUX.CONV_ORIG_DEST_TX(AD_JULLIAN_DATE(to_char(TRUNC(SYSDATE,'mm') - 1,'dd/mm/rrrr')),
                                             lim_consmp.CONSUMED_AMT,
                                             lim_consmp.LIMIT_CCY,
                                             cldb.DEVISE,
                                             'MR',
                                             '')) as "Insured outstanding balance CL/DB in CL/DB currency",
               cldb.DEVISE as "CL/DB currency",
               SUM(CH_TAUX.CONV_ORIG_DEST_TX(AD_JULLIAN_DATE(to_char(TRUNC(SYSDATE,'mm') - 1,'dd/mm/rrrr')),
                                             lim_consmp.CONSUMED_AMT,
                                             lim_consmp.LIMIT_CCY,
                                             lim.GPIDEVIS,
                                             'MR',
                                             '')) as "Insured outstanding balance CL/DB in limit currency",
               MAX(DECODE(pre_lim.TYPEDOC, 'C', pre_lim.MT02, NULL)) as "Previous Delcrederelimit in original limit currency",
               MAX(DECODE(pre_lim.TYPEDOC, 'C', pre_lim."GPIDEVIS", NULL)) as "Previous limit currency",
               MAX(DECODE(pre_lim.TYPEDOC,
                          'C',
                          NVL(pre_lim.GPIDATE1_DT, pre_lim.GPIDTFIN_DT),
                          NULL)) as "End date of Previous Delcrederlimit",
               (CASE
                 WHEN (ci_lim.STR2_CI IS NOT NULL OR
                      ci_lim.STR2_CIC IS NOT NULL) THEN
                  'SE'
                 ELSE
                  'GE'
               END) as "Approved Limit/Self decision Limit",
               MAX(CH_TAUX.CONV_ORIG_DEST_TX(AD_JULLIAN_DATE(to_char(TRUNC(SYSDATE,'mm') - 1,'dd/mm/rrrr')),
                                             f_lim.mt02,
                                             f_lim.GPIDEVIS,
                                             'EUR',
                                             'MR',
                                             '')) as "F Limit in EUR",
               MAX(f_lim.gpidevis) as "F Limit currency"
          FROM G_PIECE lim,
               (select /*+no_merge no_push_pred LEADING(ge gv lim_con) FULL(ge) FULL(gv) USE_HASH(gv) FULL(lim_con) USE_HASH(lim_con)*/
                 ge.refdoss refdoss,
                 lim_con.limit_ccy,
                 lim_con.str_20_1,
                 sum(gv.consumed_lim) CONSUMED_AMT
                  from AD_LIMITS_CONSUMATION lim_con,
                       g_venfilimit          gv,
                       g_elemfi              ge
                 where gv.limit_id = lim_con.refpiece
                   and lim_con.limit_type = 'C'
                   and gv.limit_role = 'COVERAGE'
                   and ge.refelem = gv.fi_id
                 group by ge.refdoss, lim_con.limit_ccy, lim_con.str_20_1
                having sum(gv.consumed_lim) <> 0) lim_consmp,
               AD_ACCOUNT_DEBTOR_CLIENT cldb,
               G_PIECE pol,
              (SELECT /*+no_merge no_push_pred*/
                 REFINDIVIDU, REFEXT3, LISTAGG(REFEXT, ', ') as REFEXT
                  FROM (SELECT /*+no_merge no_push_pred FULL(T_INDIVIDU)*/
                         REFINDIVIDU,
                         REFEXT3,
                         REFEXT,
                         ROW_NUMBER() OVER(PARTITION BY REFINDIVIDU, REFEXT3 ORDER BY IMX_UN_ID DESC) rn
                          FROM T_INDIVIDU
                         WHERE SOCIETE = 'CLIENT_NUMBER'
                           AND REFEXT IS NOT NULL)
                 WHERE rn <= 10
                 GROUP BY REFINDIVIDU, REFEXT3) ext,
               AD_DEBTORS db,
               V_DOMAINE pay,
               (SELECT /*+no_merge no_push_pred*/
                 FI_REFDOSS,
                 SUM(FI_OPEN_AMOUNT) AS FI_OPEN_AMOUNT,
                 SUM(AMT_COVERED) AS AMT_COVERED,
                 FI_DEVISE_DOS
                  FROM AD_FINELEM_3NF
                 WHERE FI_DTJOUR <= TO_CHAR(TRUNC(SYSDATE, 'mm') - 1, 'j')
                   AND FI_ACTIF = 'O'
                 GROUP BY FI_REFDOSS, FI_DEVISE_DOS) fi,
               T_INTERVENANTS ci,
               T_INDIVIDU cr_i,
               AD_REQUEST_LIMIT_MVIEW pre_lim,
               (SELECT /*+no_merge no_push_pred*/
                 NVL(ci_lim.GPIHEURE, cldb.ANCREFDOSS) GPIHEURE,
                 ci_lim.GPIADR3,
                 NVL(ci_lim.GPIDEPOT, cldb.CLIENT) GPIDEPOT,
                 pol.REFEXT,
                 MAX(CASE
                       WHEN ci_lim.typedoc = 'CI' THEN
                        ci_lim.MT02
                       else
                        null
                     END) MT02,
                 MAX(CASE
                       WHEN ci_lim.typedoc = 'CI' THEN
                        limcicf.STR2
                     END) STR2_CI,
                 MAX(CASE
                       WHEN ci_lim.typedoc = 'CIC' THEN
                        limcicf.STR2
                     END) STR2_CIC
                  FROM AD_REQUEST_LIMIT_MVIEW ci_lim,
                       G_PIECE pol,
                       AD_ACCOUNT_DEBTOR_CLIENT cldb,
                       (SELECT /*+no_merge no_push_pred INDEX(G_PIECEDET G_PIECEDET_TYPE_LASTLOAD_IDX)*/
                         REFPIECE,
                         STR2,
                         ROW_NUMBER() OVER(PARTITION BY REFPIECE ORDER BY IMX_UN_ID DESC) rn
                          FROM G_PIECEDET
                         WHERE TYPE = 'REQUEST_CF_PROPOSAL'
                           AND STR2 = 'ULA') limcicf
                 WHERE ci_lim.typedoc IN ('CI', 'CIC')
                   AND ci_lim.fg05 = 'O'
                   AND ci_lim.GPIADR3 = cldb.DEBTOR
                   AND limcicf.REFPIECE(+) = ci_lim.REFPIECE
                   AND limcicf.rn(+) = 1
                   AND pol.REFPIECE = ci_lim.LIBELLE_100_8
                   AND pol.TYPPIECE = 'POLICE'
                GROUP BY NVL(ci_lim.GPIHEURE, cldb.ANCREFDOSS),
                          ci_lim.GPIADR3,
                          pol.REFEXT,
                          NVL(ci_lim.GPIDEPOT, cldb.CLIENT)) ci_lim,
               (SELECT /*+no_merge no_push_pred*/
                 MAX(CASE
                       WHEN a.cnt = 1 THEN
                        ABREV
                       WHEN a.cnt_ctx <> 1 THEN
                        NULL
                       ELSE
                        CASE
                          WHEN a.rn = 1 THEN
                           a.ABREV
                          ELSE
                           NULL
                        END
                     END) ABREV,
                 a.VALEUR
                  FROM (SELECT /*+no_merge no_push_pred*/
                         valeur,
                         abrev,
                         contexte,
                         row_number() over(partition by valeur order by contexte desc NULLS LAST) rn,
                         count(*) over(partition by valeur) cnt,
                         count(DECODE(CONTEXTE, 'O', 1, NULL)) over(partition by valeur) cnt_ctx
                          FROM V_DOMAINE
                         WHERE TYPE = 'CI_IDENT_DBUPLD') a
                 GROUP BY a.VALEUR) lov_ci,
               (select GPIADR3, mt02, gpidevis, GPIDEPOT
                  from AD_REQUEST_LIMIT_MVIEW
                 where typedoc = 'F'
                   and fg05 = 'O') f_lim
         WHERE lim.TYPPIECE = 'REQUEST_LIMITE'
           AND lim.GPIADR3 = cldb.DEBTOR
           AND lim.GPIDEPOT = cldb.CLIENT
           AND lim.GPITYPTRIB = cldb.FACTOR
           AND lim.FG05 = 'O'
           AND lim.TYPEDOC IN ('C')
              --
           AND lim_consmp.REFDOSS(+) = cldb.REFDOSS
              ----IMBWEB-6292 - 23.11.2022
           AND lim_consmp.STR_20_1(+) = lim.REFPIECE
              --
           AND pol.TYPPIECE = 'POLICE'
           AND pol.REFPIECE = lim.LIBELLE_100_8
           AND ext.REFINDIVIDU(+) = cldb.DEBTOR
           AND ext.REFEXT3(+) = cldb.ANCREFDOSS
           AND db.DEBTOR_REFINDIVIDU = cldb.DEBTOR
           AND pay.TYPE(+) = 'pays'
           AND pay.ABREV(+) = db.DEBTOR_PAYS
           AND fi.FI_REFDOSS(+) = cldb.REFDOSS
           AND ci.REFTYPE(+) = 'DB'
           AND ci.REFDOSS(+) = pol.REFDOSS
           AND cr_i.SOCIETE(+) = 'CR_INSURER'
           AND cr_i.REFINDIVIDU(+) = ci.REFINDIVIDU
           AND lov_ci.VALEUR(+) = cr_i.REFEXT
           AND pre_lim.REFPIECE(+) = lim.ST04
              --
           AND ci_lim.GPIADR3(+) = cldb.DEBTOR
           AND ci_lim.GPIDEPOT(+) = cldb.CLIENT
           AND ci_lim.GPIHEURE(+) = cldb.ANCREFDOSS
              --IMBWEB-6292 - A600ERLS
           AND ci_lim.REFEXT(+) = pol.REFEXT
              --
           AND ('%' in ('%') or pol.REFEXT IN ('%'))
           AND f_lim.GPIADR3(+) = cldb.DEBTOR
           AND f_lim.GPIDEPOT(+) = cldb.CLIENT
         GROUP BY lov_ci.ABREV,
                  pol.REFEXT,
                  cldb.ANCREFDOSS,
                  ext.REFEXT,
                  db.DEBTOR_REFINDIVIDU,
                  db.DEBTOR_NOM,
                  db.DEBTOR_PAYS,
                  pay.VALEUR_AL,
                  cldb.DEVISE,
                  lim.REFPIECE,
                  ci_lim.MT02,
                  CASE
                    WHEN (ci_lim.STR2_CI IS NOT NULL OR
                         ci_lim.STR2_CIC IS NOT NULL) THEN
                     'SE'
                    ELSE
                     'GE'
                  END
        HAVING SUM(CH_TAUX.CONV_ORIG_DEST_TX(AD_JULLIAN_DATE(to_char(TRUNC(SYSDATE,'mm') - 1,'dd/mm/rrrr')), fi.FI_OPEN_AMOUNT, fi.FI_DEVISE_DOS, 'EUR', 'MR', '')) > NVL('1000', 0)
         ORDER BY pol.REFEXT, db.DEBTOR_NOM, lim.REFPIECE);



/********************************OLD SQL*******************************************/
/********************************OLD Metrics***************************************/
/*
MODULE                           SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL            PERC
-------------------------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
ADv2 ADG                                                                        ON CPU               2023/12/04 13:20:06  2023/12/04 14:14:57         625             17891189 +000000000 00:54:51.456 100%
ADv2 ADG                         81y3pxkbbdmf7 3353507447        100      41884 cell smart table sca 2023/12/04 13:46:54  2023/12/04 13:47:04           2                    1 +000000000 00:00:10.239 0%


MODULE                           SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL            PERC
-------------------------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
ADv2 ADG                                                         100      41884                      2023/12/04 13:22:07  2023/12/04 14:11:20         289                    1 +000000000 00:49:12.640 46%
ADv2 ADG                                                         110      53974 ON CPU               2023/12/04 13:22:19  2023/12/04 14:14:57         279              2703328 +000000000 00:52:37.953 44%
ADv2 ADG                                                          92      26207 ON CPU               2023/12/04 13:20:06  2023/12/04 13:25:54          23               712948 +000000000 00:05:48.544 4%
ADv2 ADG                                                        2414      57134 ON CPU               2023/12/04 13:24:00  2023/12/04 13:31:00          21              1109401 +000000000 00:07:00.224 3%
ADv2 ADG                         6ubfz055w4mby 2970089855       2435      29530 ON CPU               2023/12/04 13:20:14  2023/12/04 13:21:57           8                 5284 +000000000 00:01:42.400 1%
ADv2 ADG                                                        2430      20133 ON CPU               2023/12/04 13:23:00  2023/12/04 14:10:00           4                17314 +000000000 00:46:59.584 1%
ADv2 ADG                                                        2426      60557 ON CPU               2023/12/04 13:50:00  2023/12/04 14:10:00           2                19799 +000000000 00:19:59.616 0%
ADv2 ADG                         30cnmrxq4mjgr 2999432095         84      19863 ON CPU               2023/12/04 14:10:00  2023/12/04 14:10:00           1                    1 +000000000 00:00:00.000 0%


MODULE                           SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL            PERC
-------------------------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
ADv2 ADG                         63daxjgwb9p59                                  ON CPU               2023/12/04 13:20:06  2023/12/04 14:14:57         216             17889148 +000000000 00:54:51.456 34%
ADv2 ADG                         81y3pxkbbdmf7 3353507447        100      41884                      2023/12/04 13:22:07  2023/12/04 13:47:14         148                    1 +000000000 00:25:06.815 24%
ADv2 ADG                         6fshnsd4ctqmz 2987332299        100      41884 ON CPU               2023/12/04 13:47:25  2023/12/04 14:11:20         141                    1 +000000000 00:23:55.200 22%
ADv2 ADG                         8y06a91zzxywu 1663975267                       ON CPU               2023/12/04 13:20:26  2023/12/04 14:14:47          71             16790942 +000000000 00:54:20.736 11%
ADv2 ADG                         6ubfz055w4mby 2970089855                       ON CPU               2023/12/04 13:20:14  2023/12/04 13:30:19          34             17087630 +000000000 00:10:04.991 5%


-- 6fshnsd4ctqmz

INSTANCE_NUMBER SQL_ID            ELAPSED MAX_WAIT_ON     PC_OF  WAIT_TIME            GETS      READS       ROWS  ELAP/EXEC       GETS/EXEC READS/EXEC  ROWS/EXEC       EXEC PLAN_HASH_VALUE
--------------- ------------- ----------- --------------- ----- ---------- --------------- ---------- ---------- ---------- --------------- ---------- ---------- ---------- ---------------
              2 6fshnsd4ctqmz        1444 CPU             100%  1419.88513       163315190     496788      27747    1443.54       163315190     496788      27747          1      2987332299

SQL_ID        SQL_PLAN_HASH_VALUE SQL_PLAN_LINE_ID SQL_PLAN_OPERATION             SQL_PLAN_OPTIONS                   ACTIVE
------------- ------------------- ---------------- ------------------------------ ------------------------------ ----------
6fshnsd4ctqmz          2987332299               56 MAT_VIEW ACCESS                BY INDEX ROWID BATCHED                 99
6fshnsd4ctqmz          2987332299               57 INDEX                          SKIP SCAN                              42


Plan hash value: 2987332299
----------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                             | Name                         | Rows  | Bytes |TempSpc| Cost (%CPU)| Time     |
----------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                                      |                              |       |       |       |   407K(100)|          |
|   1 |  VIEW                                                 |                              |     1 |  3926 |       |   407K  (1)| 00:00:16 |
|   2 |   SORT GROUP BY                                       |                              |     1 |  6998 |       |   407K  (1)| 00:00:16 |
|*  3 |    HASH JOIN OUTER                                    |                              |     1 |  6998 |       |   407K  (1)| 00:00:16 |
|   4 |     JOIN FILTER CREATE                                | :BF0000                      |     1 |  4983 |       |   401K  (1)| 00:00:16 |
|   5 |      NESTED LOOPS OUTER                               |                              |     1 |  4983 |       |   401K  (1)| 00:00:16 |
|   6 |       NESTED LOOPS                                    |                              |     1 |  4951 |       |   401K  (1)| 00:00:16 |
|   7 |        NESTED LOOPS OUTER                             |                              |     1 |  4912 |       |   401K  (1)| 00:00:16 |
|*  8 |         HASH JOIN OUTER                               |                              |     1 |  4886 |       |   396K  (1)| 00:00:16 |
|*  9 |          HASH JOIN OUTER                              |                              |     1 |  4837 |       |   396K  (1)| 00:00:16 |
|* 10 |           HASH JOIN OUTER                             |                              |     1 |  4773 |       |   305K  (1)| 00:00:12 |
|* 11 |            HASH JOIN OUTER                            |                              |     1 |   216 |       |   276K  (1)| 00:00:11 |
|  12 |             JOIN FILTER CREATE                        | :BF0001                      |     1 |   187 |       |   253K  (1)| 00:00:10 |
|  13 |              NESTED LOOPS OUTER                       |                              |     1 |   187 |       |   253K  (1)| 00:00:10 |
|* 14 |               HASH JOIN OUTER                         |                              |     1 |   155 |       |   253K  (1)| 00:00:10 |
|  15 |                JOIN FILTER CREATE                     | :BF0002                      |     1 |   131 |       |   250K  (1)| 00:00:10 |
|  16 |                 NESTED LOOPS                          |                              |     1 |   131 |       |   250K  (1)| 00:00:10 |
|  17 |                  NESTED LOOPS                         |                              |   645K|   131 |       |   250K  (1)| 00:00:10 |
|* 18 |                   HASH JOIN                           |                              |  5713 |   552K|    12M|  5145   (1)| 00:00:01 |
|  19 |                    TABLE ACCESS STORAGE FULL          | AD_ACCOUNT_DEBTOR_CLIENT     |   221K|  9967K|       |  1847   (1)| 00:00:01 |
|* 20 |                    TABLE ACCESS BY INDEX ROWID BATCHED| G_PIECE                      |  5713 |   295K|       |  2737   (1)| 00:00:01 |
|* 21 |                     INDEX RANGE SCAN                  | GP_TYPEDOC                   | 10449 |       |       |    71   (0)| 00:00:01 |
|* 22 |                   INDEX RANGE SCAN                    | TYPPIECE_LASTLOAD_IND        |   113 |       |       |     4   (0)| 00:00:01 |
|* 23 |                  TABLE ACCESS BY INDEX ROWID          | G_PIECE                      |     1 |    32 |       |    43   (0)| 00:00:01 |
|  24 |                JOIN FILTER USE                        | :BF0002                      |   222K|  5223K|       |  3018   (1)| 00:00:01 |
|* 25 |                 TABLE ACCESS STORAGE FULL             | T_INTERVENANTS               |   222K|  5223K|       |  3018   (1)| 00:00:01 |
|* 26 |               TABLE ACCESS BY INDEX ROWID BATCHED     | T_INDIVIDU                   |     1 |    32 |       |    12   (0)| 00:00:01 |
|* 27 |                INDEX RANGE SCAN                       | SOC_INDIV                    |    10 |       |       |     2   (0)| 00:00:01 |
|  28 |             JOIN FILTER USE                           | :BF0001                      |  2046K|    56M|       | 22393   (1)| 00:00:01 |
|* 29 |              MAT_VIEW ACCESS STORAGE FULL             | AD_REQUEST_LIMIT_MVIEW       |  2046K|    56M|       | 22393   (1)| 00:00:01 |
|  30 |            VIEW                                       |                              |  1232 |  5482K|       | 29628   (1)| 00:00:02 |
|  31 |             HASH GROUP BY                             |                              |  1232 |  2533K|  3296K| 29628   (1)| 00:00:02 |
|* 32 |              HASH JOIN                                |                              |  1232 |  2533K|       | 29121   (1)| 00:00:02 |
|  33 |               JOIN FILTER CREATE                      | :BF0003                      |   799 |  1622K|       | 27274   (1)| 00:00:02 |
|* 34 |                HASH JOIN OUTER                        |                              |   799 |  1622K|       | 27274   (1)| 00:00:02 |
|* 35 |                 HASH JOIN                             |                              |   799 | 44744 |       | 22417   (1)| 00:00:01 |
|  36 |                  JOIN FILTER CREATE                   | :BF0004                      |   113 |  2373 |       |     4   (0)| 00:00:01 |
|* 37 |                   INDEX RANGE SCAN                    | G_PIECE_TYPE_REFPIECE_INX    |   113 |  2373 |       |     4   (0)| 00:00:01 |
|  38 |                  JOIN FILTER USE                      | :BF0004                      |   799 | 27965 |       | 22413   (1)| 00:00:01 |
|* 39 |                   MAT_VIEW ACCESS STORAGE FULL        | AD_REQUEST_LIMIT_MVIEW       |   799 | 27965 |       | 22413   (1)| 00:00:01 |
|* 40 |                 VIEW                                  |                              |   190 |   375K|       |  4858   (1)| 00:00:01 |
|* 41 |                  WINDOW SORT PUSHED RANK              |                              |   190 |  6460 |       |  4858   (1)| 00:00:01 |
|* 42 |                   TABLE ACCESS BY INDEX ROWID BATCHED | G_PIECEDET                   |   190 |  6460 |       |  4857   (1)| 00:00:01 |
|* 43 |                    INDEX RANGE SCAN                   | G_PIECEDET_TYPE_LASTLOAD_IDX | 50178 |       |       |   387   (0)| 00:00:01 |
|  44 |               JOIN FILTER USE                         | :BF0003                      |   221K|  5633K|       |  1847   (1)| 00:00:01 |
|* 45 |                TABLE ACCESS STORAGE FULL              | AD_ACCOUNT_DEBTOR_CLIENT     |   221K|  5633K|       |  1847   (1)| 00:00:01 |
|  46 |           VIEW                                        |                              |     1 |    64 |       | 90381   (1)| 00:00:04 |
|  47 |            HASH GROUP BY                              |                              |     1 |   319 |       | 90381   (1)| 00:00:04 |
|* 48 |             FILTER                                    |                              |       |       |       |            |          |
|* 49 |              TABLE ACCESS STORAGE FULL                | AD_FINELEM_3NF               |     1 |   319 |       | 90380   (1)| 00:00:04 |
|  50 |          VIEW                                         |                              |    13 |   637 |       |    11  (10)| 00:00:01 |
|  51 |           HASH GROUP BY                               |                              |    13 |  1144 |       |    11  (10)| 00:00:01 |
|  52 |            VIEW                                       |                              |    13 |  1144 |       |    11  (10)| 00:00:01 |
|  53 |             WINDOW SORT                               |                              |    13 |   507 |       |    11  (10)| 00:00:01 |
|  54 |              TABLE ACCESS BY INDEX ROWID BATCHED      | V_DOMAINE                    |    13 |   507 |       |    10   (0)| 00:00:01 |
|* 55 |               INDEX RANGE SCAN                        | V_DOMAINE_IND                |    13 |       |       |     2   (0)| 00:00:01 |
|* 56 |         MAT_VIEW ACCESS BY INDEX ROWID BATCHED        | AD_REQUEST_LIMIT_MVIEW       |     1 |    26 |       |  5242   (1)| 00:00:01 |
|* 57 |          INDEX SKIP SCAN                              | AD_REQ_LIMIT_IND             | 69221 |       |       |  1103   (1)| 00:00:01 |
|  58 |        TABLE ACCESS BY INDEX ROWID BATCHED            | AD_DEBTORS                   |     1 |    39 |       |     2   (0)| 00:00:01 |
|* 59 |         INDEX RANGE SCAN                              | AD_DEBTORS_PK                |     1 |       |       |     1   (0)| 00:00:01 |
|  60 |       TABLE ACCESS BY INDEX ROWID BATCHED             | V_DOMAINE                    |     1 |    32 |       |     2   (0)| 00:00:01 |
|* 61 |        INDEX RANGE SCAN                               | V_DOMAINE_IND                |     1 |       |       |     1   (0)| 00:00:01 |
|  62 |     VIEW                                              |                              |   255K|   490M|       |  5899   (1)| 00:00:01 |
|  63 |      HASH GROUP BY                                    |                              |   255K|    74M|       |  5899   (1)| 00:00:01 |
|* 64 |       VIEW                                            |                              |   255K|    74M|       |  5899   (1)| 00:00:01 |
|  65 |        JOIN FILTER USE                                | :BF0000                      |   255K|    10M|       |  5899   (1)| 00:00:01 |
|* 66 |         WINDOW SORT PUSHED RANK                       |                              |   255K|    10M|    13M|  5899   (1)| 00:00:01 |
|* 67 |          TABLE ACCESS STORAGE FULL                    | T_INDIVIDU                   |   255K|    10M|       |  3331   (1)| 00:00:01 |
----------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   3 - access("EXT"."REFINDIVIDU"="CLDB"."DEBTOR" AND "EXT"."REFEXT3"="CLDB"."ANCREFDOSS")
   8 - access("LOV_CI"."VALEUR"="CR_I"."REFEXT")
   9 - access("FI"."FI_REFDOSS"="CLDB"."REFDOSS")
  10 - access("CI_LIM"."GPIADR3"="CLDB"."DEBTOR" AND "CI_LIM"."GPIDEPOT"="CLDB"."CLIENT" AND "CI_LIM"."GPIHEURE"="CLDB"."ANCREFDOSS")
  11 - access("PRE_LIM"."REFPIECE"="LIM"."ST04")
  14 - access("CI"."REFDOSS"="POL"."REFDOSS")
  18 - access("LIM"."GPIADR3"="CLDB"."DEBTOR" AND "LIM"."GPIDEPOT"="CLDB"."CLIENT" AND "LIM"."GPITYPTRIB"="CLDB"."FACTOR")
  20 - filter(("LIM"."GPIDEPOT" IS NOT NULL AND "LIM"."LIBELLE_100_8" IS NOT NULL AND "LIM"."GPITYPTRIB" IS NOT NULL AND
              "LIM"."FG05"='O'))
  21 - access("LIM"."TYPEDOC"='C' AND "LIM"."TYPPIECE"='REQUEST_LIMITE')
  22 - access("POL"."TYPPIECE"='POLICE')
  23 - filter("POL"."REFPIECE"="LIM"."LIBELLE_100_8")
  25 - storage(("CI"."REFTYPE"='DB' AND SYS_OP_BLOOM_FILTER(:BF0002,"CI"."REFDOSS")))
       filter(("CI"."REFTYPE"='DB' AND SYS_OP_BLOOM_FILTER(:BF0002,"CI"."REFDOSS")))
  26 - filter("CR_I"."REFINDIVIDU"="CI"."REFINDIVIDU")
  27 - access("CR_I"."SOCIETE"='CR_INSURER')
  29 - storage(SYS_OP_BLOOM_FILTER(:BF0001,"PRE_LIM"."REFPIECE"))
       filter(SYS_OP_BLOOM_FILTER(:BF0001,"PRE_LIM"."REFPIECE"))
  32 - access("CI_LIM"."GPIADR3"="CLDB"."DEBTOR")
  34 - access("LIMCICF"."REFPIECE"="CI_LIM"."REFPIECE")
  35 - access("POL"."REFPIECE"="CI_LIM"."LIBELLE_100_8")
  37 - access("POL"."TYPPIECE"='POLICE')
  39 - storage(("CI_LIM"."LIBELLE_100_8" IS NOT NULL AND "CI_LIM"."GPIADR3" IS NOT NULL AND "CI_LIM"."FG05"='O' AND
              INTERNAL_FUNCTION("CI_LIM"."TYPEDOC") AND SYS_OP_BLOOM_FILTER(:BF0004,"CI_LIM"."LIBELLE_100_8")))
      filter(("CI_LIM"."LIBELLE_100_8" IS NOT NULL AND "CI_LIM"."GPIADR3" IS NOT NULL AND "CI_LIM"."FG05"='O' AND
              INTERNAL_FUNCTION("CI_LIM"."TYPEDOC") AND SYS_OP_BLOOM_FILTER(:BF0004,"CI_LIM"."LIBELLE_100_8")))
  40 - filter("LIMCICF"."RN"=1)
  41 - filter(ROW_NUMBER() OVER ( PARTITION BY "REFPIECE" ORDER BY INTERNAL_FUNCTION("IMX_UN_ID") DESC )<=1)
  42 - filter("STR2"='ULA')
  43 - access("TYPE"='REQUEST_CF_PROPOSAL')
  45 - storage(SYS_OP_BLOOM_FILTER(:BF0003,"CLDB"."DEBTOR"))
       filter(SYS_OP_BLOOM_FILTER(:BF0003,"CLDB"."DEBTOR"))
  48 - filter(TO_NUMBER(TO_CHAR(TRUNC(SYSDATE@!,'fmmm')-1,'j'))>=TO_NUMBER(TO_CHAR(TRUNC(TRUNC(SYSDATE@!,'fmmm')-1,'fmmm'),'j')))
  49 - storage(("FI_DTANNUL" IS NULL AND INTERNAL_FUNCTION("FI_ACTIF") AND INTERNAL_FUNCTION("FI_TYPE") AND
              "FI_DTJOUR"<=TO_NUMBER(TO_CHAR(TRUNC(SYSDATE@!,'fmmm')-1,'j')) AND
              "FI_DTJOUR">=TO_NUMBER(TO_CHAR(TRUNC(TRUNC(SYSDATE@!,'fmmm')-1,'fmmm'),'j')) AND "INV_STATUS"<>'REASSIGNED'))
       filter(("FI_DTANNUL" IS NULL AND INTERNAL_FUNCTION("FI_ACTIF") AND INTERNAL_FUNCTION("FI_TYPE") AND
              "FI_DTJOUR"<=TO_NUMBER(TO_CHAR(TRUNC(SYSDATE@!,'fmmm')-1,'j')) AND
              "FI_DTJOUR">=TO_NUMBER(TO_CHAR(TRUNC(TRUNC(SYSDATE@!,'fmmm')-1,'fmmm'),'j')) AND "INV_STATUS"<>'REASSIGNED'))
  55 - access("TYPE"='CI_IDENT_DBUPLD')
  56 - filter(("GPIADR3" IS NOT NULL AND "GPIADR3"="CLDB"."DEBTOR" AND "GPIDEPOT"="CLDB"."CLIENT" AND "GPIDEPOT" IS NOT NULL AND
              "FG05"='O'))
  57 - access("TYPEDOC"='F')
       filter("TYPEDOC"='F')
  59 - access("DB"."DEBTOR_REFINDIVIDU"="CLDB"."DEBTOR")
  61 - access("PAY"."TYPE"='pays' AND "PAY"."ABREV"="DB"."DEBTOR_PAYS")
  64 - filter("RN"<=10)
  66 - filter(ROW_NUMBER() OVER ( PARTITION BY "REFINDIVIDU","REFEXT3" ORDER BY INTERNAL_FUNCTION("IMX_UN_ID") DESC )<=10)
  67 - storage(("SOCIETE"='CLIENT_NUMBER' AND "REFEXT" IS NOT NULL))
       filter(("SOCIETE"='CLIENT_NUMBER' AND "REFEXT" IS NOT NULL))


-- 81y3pxkbbdmf7

INSTANCE_NUMBER SQL_ID            ELAPSED MAX_WAIT_ON     PC_OF  WAIT_TIME            GETS      READS       ROWS  ELAP/EXEC       GETS/EXEC READS/EXEC  ROWS/EXEC       EXEC PLAN_HASH_VALUE
--------------- ------------- ----------- --------------- ----- ---------- --------------- ---------- ---------- ---------- --------------- ---------- ---------- ---------- ---------------
              2 81y3pxkbbdmf7        1511 CPU             99%   1489.69671       169641611    8435961       6630    1510.92       169641611    8435961       6630          1      3353507447

SQL_ID        SQL_PLAN_HASH_VALUE SQL_PLAN_LINE_ID SQL_PLAN_OPERATION             SQL_PLAN_OPTIONS                   ACTIVE
------------- ------------------- ---------------- ------------------------------ ------------------------------ ----------
81y3pxkbbdmf7          3353507447               47 MAT_VIEW ACCESS                BY INDEX ROWID BATCHED                 98
81y3pxkbbdmf7          3353507447               48 INDEX                          SKIP SCAN                              47
81y3pxkbbdmf7          3353507447               76 TABLE ACCESS                   STORAGE FULL                            1
81y3pxkbbdmf7          3353507447               75 TABLE ACCESS                   STORAGE FULL                            1
81y3pxkbbdmf7          3353507447                3 SORT                           GROUP BY                                1


Plan hash value: 3353507447
---------------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                                  | Name                         | Rows  | Bytes |TempSpc| Cost (%CPU)| Time     |
---------------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                                           |                              |       |       |       |  2885K(100)|          |
|   1 |  VIEW                                                      |                              |     1 |  4006 |       |  2885K  (1)| 00:01:53 |
|*  2 |   FILTER                                                   |                              |       |       |       |            |          |
|   3 |    SORT GROUP BY                                           |                              |     1 |  7099 |       |  2885K  (1)| 00:01:53 |
|*  4 |     HASH JOIN OUTER                                        |                              |     1 |  7099 |       |  2885K  (1)| 00:01:53 |
|   5 |      JOIN FILTER CREATE                                    | :BF0000                      |     1 |  7065 |       |  2863K  (1)| 00:01:52 |
|*  6 |       HASH JOIN OUTER                                      |                              |     1 |  7065 |       |  2863K  (1)| 00:01:52 |
|   7 |        JOIN FILTER CREATE                                  | :BF0001                      |     1 |  6970 |       |   131K  (1)| 00:00:06 |
|*  8 |         HASH JOIN OUTER                                    |                              |     1 |  6970 |       |   131K  (1)| 00:00:06 |
|   9 |          JOIN FILTER CREATE                                | :BF0002                      |     1 |  4955 |       |   125K  (1)| 00:00:05 |
|* 10 |           HASH JOIN OUTER                                  |                              |     1 |  4955 |       |   125K  (1)| 00:00:05 |
|  11 |            NESTED LOOPS OUTER                              |                              |     1 |  4906 |       |   125K  (1)| 00:00:05 |
|  12 |             NESTED LOOPS OUTER                             |                              |     1 |  4874 |       |   125K  (1)| 00:00:05 |
|  13 |              NESTED LOOPS OUTER                            |                              |     1 |  4850 |       |   125K  (1)| 00:00:05 |
|  14 |               NESTED LOOPS                                 |                              |     1 |  4818 |       |   125K  (1)| 00:00:05 |
|  15 |                NESTED LOOPS OUTER                          |                              |     1 |  4779 |       |   125K  (1)| 00:00:05 |
|* 16 |                 HASH JOIN OUTER                            |                              |     1 |  4753 |       |   120K  (1)| 00:00:05 |
|* 17 |                  HASH JOIN OUTER                           |                              |     1 |   180 |       | 91056   (1)| 00:00:04 |
|  18 |                   NESTED LOOPS                             |                              |     1 |   137 |       |  2927   (1)| 00:00:01 |
|  19 |                    NESTED LOOPS                            |                              |     1 |   137 |       |  2927   (1)| 00:00:01 |
|* 20 |                     HASH JOIN                              |                              |     1 |    87 |       |  2924   (1)| 00:00:01 |
|  21 |                      TABLE ACCESS BY INDEX ROWID BATCHED   | G_PIECE                      |   113 |  3616 |       |    42   (0)| 00:00:01 |
|* 22 |                       INDEX RANGE SCAN                     | GP_TYPPLIB_IDX               |   113 |       |       |     4   (0)| 00:00:01 |
|* 23 |                      TABLE ACCESS BY INDEX ROWID BATCHED   | G_PIECE                      |  5705 |   306K|       |  2882   (1)| 00:00:01 |
|* 24 |                       INDEX RANGE SCAN                     | GP_TYPEDOC                   | 10502 |       |       |    71   (0)| 00:00:01 |
|* 25 |                     INDEX RANGE SCAN                       | AD_ACCOUNT_DBCL_DBCL_IND     |     1 |       |       |     2   (0)| 00:00:01 |
|* 26 |                    TABLE ACCESS BY INDEX ROWID             | AD_ACCOUNT_DEBTOR_CLIENT     |     1 |    50 |       |     3   (0)| 00:00:01 |
|  27 |                   VIEW                                     |                              |     1 |    43 |       | 88129   (1)| 00:00:04 |
|  28 |                    HASH GROUP BY                           |                              |     1 |    73 |       | 88129   (1)| 00:00:04 |
|* 29 |                     TABLE ACCESS STORAGE FULL              | AD_FINELEM_3NF               |  3040 |   216K|       | 88128   (1)| 00:00:04 |
|  30 |                  VIEW                                      |                              |  1192 |  5323K|       | 29558   (1)| 00:00:02 |
|  31 |                   HASH GROUP BY                            |                              |  1192 |  2455K|  3192K| 29558   (1)| 00:00:02 |
|* 32 |                    HASH JOIN                               |                              |  1192 |  2455K|       | 29066   (1)| 00:00:02 |
|  33 |                     JOIN FILTER CREATE                     | :BF0003                      |   780 |  1586K|       | 27253   (1)| 00:00:02 |
|* 34 |                      HASH JOIN OUTER                       |                              |   780 |  1586K|       | 27253   (1)| 00:00:02 |
|* 35 |                       HASH JOIN                            |                              |   780 | 46020 |       | 22446   (1)| 00:00:01 |
|  36 |                        JOIN FILTER CREATE                  | :BF0004                      |   113 |  2712 |       |    42   (0)| 00:00:01 |
|  37 |                         TABLE ACCESS BY INDEX ROWID BATCHED| G_PIECE                      |   113 |  2712 |       |    42   (0)| 00:00:01 |
|* 38 |                          INDEX RANGE SCAN                  | GP_TYPPLIB_IDX               |   113 |       |       |     4   (0)| 00:00:01 |
|  39 |                        JOIN FILTER USE                     | :BF0004                      |   780 | 27300 |       | 22404   (1)| 00:00:01 |
|* 40 |                         MAT_VIEW ACCESS STORAGE FULL       | AD_REQUEST_LIMIT_MVIEW       |   780 | 27300 |       | 22404   (1)| 00:00:01 |
|* 41 |                       VIEW                                 |                              |   188 |   371K|       |  4807   (1)| 00:00:01 |
|* 42 |                        WINDOW SORT PUSHED RANK             |                              |   188 |  6392 |       |  4807   (1)| 00:00:01 |
|* 43 |                         TABLE ACCESS BY INDEX ROWID BATCHED| G_PIECEDET                   |   188 |  6392 |       |  4806   (1)| 00:00:01 |
|* 44 |                          INDEX RANGE SCAN                  | G_PIECEDET_TYPE_LASTLOAD_IDX | 49797 |       |       |   383   (0)| 00:00:01 |
|  45 |                     JOIN FILTER USE                        | :BF0003                      |   219K|  5584K|       |  1813   (1)| 00:00:01 |
|* 46 |                      TABLE ACCESS STORAGE FULL             | AD_ACCOUNT_DEBTOR_CLIENT     |   219K|  5584K|       |  1813   (1)| 00:00:01 |
|* 47 |                 MAT_VIEW ACCESS BY INDEX ROWID BATCHED     | AD_REQUEST_LIMIT_MVIEW       |     1 |    26 |       |  4591   (1)| 00:00:01 |
|* 48 |                  INDEX SKIP SCAN                           | AD_REQ_LIMIT_IND             | 69166 |       |       |  1125   (1)| 00:00:01 |
|  49 |                TABLE ACCESS BY INDEX ROWID BATCHED         | AD_DEBTORS                   |     1 |    39 |       |     1   (0)| 00:00:01 |
|* 50 |                 INDEX RANGE SCAN                           | AD_DEBTORS_PK                |     1 |       |       |     0   (0)|          |
|  51 |               TABLE ACCESS BY INDEX ROWID BATCHED          | V_DOMAINE                    |     1 |    32 |       |     2   (0)| 00:00:01 |
|* 52 |                INDEX RANGE SCAN                            | V_DOMAINE_IND                |     1 |       |       |     1   (0)| 00:00:01 |
|* 53 |              INDEX RANGE SCAN                              | INT_REFDOSS                  |     1 |    24 |       |     2   (0)| 00:00:01 |
|  54 |             TABLE ACCESS BY INDEX ROWID BATCHED            | T_INDIVIDU                   |     1 |    32 |       |     3   (0)| 00:00:01 |
|* 55 |              INDEX RANGE SCAN                              | T_INDIVIDU_RSR_IDX           |     1 |       |       |     2   (0)| 00:00:01 |
|  56 |            VIEW                                            |                              |    12 |   588 |       |    11  (10)| 00:00:01 |
|  57 |             HASH GROUP BY                                  |                              |    12 |  1056 |       |    11  (10)| 00:00:01 |
|  58 |              VIEW                                          |                              |    12 |  1056 |       |    11  (10)| 00:00:01 |
|  59 |               WINDOW SORT                                  |                              |    12 |   468 |       |    11  (10)| 00:00:01 |
|  60 |                TABLE ACCESS BY INDEX ROWID BATCHED         | V_DOMAINE                    |    12 |   468 |       |    10   (0)| 00:00:01 |
|* 61 |                 INDEX RANGE SCAN                           | V_DOMAINE_IND                |    12 |       |       |     2   (0)| 00:00:01 |
|  62 |          VIEW                                              |                              |   252K|   485M|       |  5877   (1)| 00:00:01 |
|  63 |           HASH GROUP BY                                    |                              |   252K|    74M|       |  5877   (1)| 00:00:01 |
|* 64 |            VIEW                                            |                              |   252K|    74M|       |  5877   (1)| 00:00:01 |
|  65 |             JOIN FILTER USE                                | :BF0002                      |   252K|    10M|       |  5877   (1)| 00:00:01 |
|* 66 |              WINDOW SORT PUSHED RANK                       |                              |   252K|    10M|    13M|  5877   (1)| 00:00:01 |
|* 67 |               TABLE ACCESS STORAGE FULL                    | T_INDIVIDU                   |   252K|    10M|       |  3331   (1)| 00:00:01 |
|  68 |        VIEW                                                |                              |   732K|    66M|       |  2732K  (1)| 00:01:47 |
|* 69 |         FILTER                                             |                              |       |       |       |            |          |
|  70 |          HASH GROUP BY                                     |                              |   732K|    54M|  1301M|  2732K  (1)| 00:01:47 |
|  71 |           JOIN FILTER USE                                  | :BF0001                      |    14M|  1090M|       |  2647K  (1)| 00:01:44 |
|* 72 |            HASH JOIN                                       |                              |    14M|  1090M|    12M|  2647K  (1)| 00:01:44 |
|* 73 |             TABLE ACCESS STORAGE FULL                      | AD_LIMITS_CONSUMATION        |   349K|  8884K|       |  2643   (1)| 00:00:01 |
|* 74 |             HASH JOIN                                      |                              |   115M|  5725M|   185M|  2331K  (1)| 00:01:32 |
|  75 |              TABLE ACCESS STORAGE FULL                     | G_ELEMFI                     |  6085K|   116M|       | 54237   (1)| 00:00:03 |
|* 76 |              TABLE ACCESS STORAGE FULL                     | G_VENFILIMIT                 |   115M|  3523M|       |  2053K  (1)| 00:01:21 |
|  77 |      JOIN FILTER USE                                       | :BF0000                      |  2043K|    66M|       | 22401   (1)| 00:00:01 |
|* 78 |       MAT_VIEW ACCESS STORAGE FULL                         | AD_REQUEST_LIMIT_MVIEW       |  2043K|    66M|       | 22401   (1)| 00:00:01 |
---------------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   2 - filter(SUM("CH_TAUX"."CONV_ORIG_DEST_TX"("AD_JULLIAN_DATE"(TRUNC(SYSDATE@!,'fmmm')-1),"FI"."FI_OPEN_AMOUNT","FI"."FI_DEVISE_DOS",'EU
              R','MR',''))>1000)
   4 - access("PRE_LIM"."REFPIECE"="LIM"."ST04")
   6 - access("LIM_CONSMP"."REFDOSS"="CLDB"."REFDOSS" AND "LIM_CONSMP"."STR_20_1"="LIM"."REFPIECE")
   8 - access("EXT"."REFINDIVIDU"="CLDB"."DEBTOR" AND "EXT"."REFEXT3"="CLDB"."ANCREFDOSS")
  10 - access("LOV_CI"."VALEUR"="CR_I"."REFEXT")
  16 - access("CI_LIM"."GPIADR3"="CLDB"."DEBTOR" AND "CI_LIM"."GPIDEPOT"="CLDB"."CLIENT" AND "CI_LIM"."GPIHEURE"="CLDB"."ANCREFDOSS" AND
             "CI_LIM"."REFEXT"="POL"."REFEXT")
  17 - access("FI"."FI_REFDOSS"="CLDB"."REFDOSS")
  20 - access("POL"."REFPIECE"="LIM"."LIBELLE_100_8")
  22 - access("POL"."TYPPIECE"='POLICE')
  23 - filter(("LIM"."GPIDEPOT" IS NOT NULL AND "LIM"."LIBELLE_100_8" IS NOT NULL AND "LIM"."GPITYPTRIB" IS NOT NULL AND "LIM"."FG05"='O'))
  24 - access("LIM"."TYPEDOC"='C' AND "LIM"."TYPPIECE"='REQUEST_LIMITE')
  25 - access("LIM"."GPIADR3"="CLDB"."DEBTOR" AND "LIM"."GPIDEPOT"="CLDB"."CLIENT")
  26 - filter("LIM"."GPITYPTRIB"="CLDB"."FACTOR")
  29 - storage(("FI_ACTIF"='O' AND "FI_DTJOUR"<=TO_NUMBER(TO_CHAR(TRUNC(SYSDATE@!,'fmmm')-1,'j'))))
       filter(("FI_ACTIF"='O' AND "FI_DTJOUR"<=TO_NUMBER(TO_CHAR(TRUNC(SYSDATE@!,'fmmm')-1,'j'))))
  32 - access("CI_LIM"."GPIADR3"="CLDB"."DEBTOR")
  34 - access("LIMCICF"."REFPIECE"="CI_LIM"."REFPIECE")
  35 - access("POL"."REFPIECE"="CI_LIM"."LIBELLE_100_8")
  38 - access("POL"."TYPPIECE"='POLICE')
  40 - storage(("CI_LIM"."LIBELLE_100_8" IS NOT NULL AND "CI_LIM"."GPIADR3" IS NOT NULL AND "CI_LIM"."FG05"='O' AND
              INTERNAL_FUNCTION("CI_LIM"."TYPEDOC") AND SYS_OP_BLOOM_FILTER(:BF0004,"CI_LIM"."LIBELLE_100_8")))
       filter(("CI_LIM"."LIBELLE_100_8" IS NOT NULL AND "CI_LIM"."GPIADR3" IS NOT NULL AND "CI_LIM"."FG05"='O' AND
              INTERNAL_FUNCTION("CI_LIM"."TYPEDOC") AND SYS_OP_BLOOM_FILTER(:BF0004,"CI_LIM"."LIBELLE_100_8")))
  41 - filter("LIMCICF"."RN"=1)
  42 - filter(ROW_NUMBER() OVER ( PARTITION BY "REFPIECE" ORDER BY INTERNAL_FUNCTION("IMX_UN_ID") DESC )<=1)
  43 - filter("STR2"='ULA')
  44 - access("TYPE"='REQUEST_CF_PROPOSAL')
  46 - storage(SYS_OP_BLOOM_FILTER(:BF0003,"CLDB"."DEBTOR"))
       filter(SYS_OP_BLOOM_FILTER(:BF0003,"CLDB"."DEBTOR"))
  47 - filter(("GPIADR3" IS NOT NULL AND "GPIADR3"="CLDB"."DEBTOR" AND "GPIDEPOT"="CLDB"."CLIENT" AND "GPIDEPOT" IS NOT NULL AND
              "FG05"='O'))
  48 - access("TYPEDOC"='F')
       filter("TYPEDOC"='F')
  50 - access("DB"."DEBTOR_REFINDIVIDU"="CLDB"."DEBTOR")
  52 - access("PAY"."TYPE"='pays' AND "PAY"."ABREV"="DB"."DEBTOR_PAYS")
  53 - access("CI"."REFDOSS"="POL"."REFDOSS" AND "CI"."REFTYPE"='DB')
  55 - access("CR_I"."REFINDIVIDU"="CI"."REFINDIVIDU" AND "CR_I"."SOCIETE"='CR_INSURER')
  61 - access("TYPE"='CI_IDENT_DBUPLD')
  64 - filter("RN"<=10)
  66 - filter(ROW_NUMBER() OVER ( PARTITION BY "REFINDIVIDU","REFEXT3" ORDER BY INTERNAL_FUNCTION("IMX_UN_ID") DESC )<=10)
  67 - storage(("SOCIETE"='CLIENT_NUMBER' AND "REFEXT" IS NOT NULL))
       filter(("SOCIETE"='CLIENT_NUMBER' AND "REFEXT" IS NOT NULL))
  69 - filter(SUM("GV"."CONSUMED_LIM")<>0)
  72 - access("GV"."LIMIT_ID"="LIM_CON"."REFPIECE")
  73 - storage("LIM_CON"."LIMIT_TYPE"='C')
       filter("LIM_CON"."LIMIT_TYPE"='C')
  74 - access("GE"."REFELEM"="GV"."FI_ID")
  76 - storage("GV"."LIMIT_ROLE"='COVERAGE')
       filter("GV"."LIMIT_ROLE"='COVERAGE')
  78 - storage(SYS_OP_BLOOM_FILTER(:BF0000,"PRE_LIM"."REFPIECE"))
       filter(SYS_OP_BLOOM_FILTER(:BF0000,"PRE_LIM"."REFPIECE"))

*/
/********************************OLD Metrics***************************************/

/********************************New SQL*******************************************/
-- No need to change anything in the SQL texts, only create the index.
/********************************New SQL*******************************************/
/********************************New Metrics***************************************/
/*

-- 6fshnsd4ctqmz

Plan hash value: 332245174
----------------------------------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                             | Name                         | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  |
----------------------------------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                                      |                              |      1 |        |   420K(100)|  27966 |00:00:07.91 |    2983K|    519K|
|   1 |  VIEW                                                 |                              |      1 |      1 |   420K  (1)|  27966 |00:00:07.91 |    2983K|    519K|
|   2 |   SORT GROUP BY                                       |                              |      1 |      1 |   420K  (1)|  27966 |00:00:07.89 |    2983K|    519K|
|*  3 |    HASH JOIN OUTER                                    |                              |      1 |      1 |   420K  (1)|  30375 |00:00:06.83 |    2959K|    519K|
|   4 |     JOIN FILTER CREATE                                | :BF0000                      |      1 |      1 |   414K  (1)|  30375 |00:00:05.83 |    2946K|    519K|
|   5 |      NESTED LOOPS OUTER                               |                              |      1 |      1 |   414K  (1)|  30375 |00:00:05.82 |    2946K|    519K|
|   6 |       NESTED LOOPS                                    |                              |      1 |      1 |   414K  (1)|  30375 |00:00:05.75 |    2913K|    519K|
|   7 |        NESTED LOOPS OUTER                             |                              |      1 |      1 |   414K  (1)|  30375 |00:00:05.57 |    2822K|    519K|
|*  8 |         HASH JOIN OUTER                               |                              |      1 |      1 |   414K  (1)|  30375 |00:00:04.73 |    2695K|    519K|
|*  9 |          HASH JOIN OUTER                              |                              |      1 |      1 |   414K  (1)|  30375 |00:00:04.70 |    2695K|    519K|
|* 10 |           HASH JOIN OUTER                             |                              |      1 |      1 |   316K  (1)|  30375 |00:00:04.30 |    2342K|    166K|
|* 11 |            HASH JOIN OUTER                            |                              |      1 |      1 |   285K  (1)|  30375 |00:00:03.83 |    2239K|  83327 |
|  12 |             JOIN FILTER CREATE                        | :BF0001                      |      1 |      1 |   263K  (1)|  30375 |00:00:03.59 |    2155K|      0 |
|  13 |              NESTED LOOPS OUTER                       |                              |      1 |      1 |   263K  (1)|  30375 |00:00:03.59 |    2155K|      0 |
|* 14 |               HASH JOIN OUTER                         |                              |      1 |      1 |   263K  (1)|  30375 |00:00:03.49 |    2155K|      0 |
|  15 |                JOIN FILTER CREATE                     | :BF0002                      |      1 |      1 |   260K  (1)|  30375 |00:00:03.41 |    2144K|      0 |
|  16 |                 NESTED LOOPS                          |                              |      1 |      1 |   260K  (1)|  30375 |00:00:03.40 |    2144K|      0 |
|  17 |                  NESTED LOOPS                         |                              |      1 |    666K|   260K  (1)|   3493K|00:00:01.07 |     170K|      0 |
|* 18 |                   HASH JOIN                           |                              |      1 |   5793 |  5154   (1)|  30375 |00:00:00.35 |     109K|      0 |
|  19 |                    TABLE ACCESS STORAGE FULL          | AD_ACCOUNT_DEBTOR_CLIENT     |      1 |    223K|  1847   (1)|    223K|00:00:00.05 |    6805 |      0 |
|* 20 |                    TABLE ACCESS BY INDEX ROWID BATCHED| G_PIECE                      |      1 |   5793 |  2741   (1)|  27966 |00:00:00.18 |     102K|      0 |
|* 21 |                     INDEX RANGE SCAN                  | GP_TYPEDOC                   |      1 |  10463 |    70   (0)|  61652 |00:00:00.02 |    2323 |      0 |
|* 22 |                   INDEX RANGE SCAN                    | TYPPIECE_LASTLOAD_IND        |  30375 |    115 |     4   (0)|   3493K|00:00:00.44 |   60856 |      0 |
|* 23 |                  TABLE ACCESS BY INDEX ROWID          | G_PIECE                      |   3493K|      1 |    44   (0)|  30375 |00:00:01.80 |    1974K|      0 |
|  24 |                JOIN FILTER USE                        | :BF0002                      |      1 |    224K|  3018   (1)|    205 |00:00:00.05 |   11036 |      0 |
|* 25 |                 TABLE ACCESS STORAGE FULL             | T_INTERVENANTS               |      1 |    224K|  3018   (1)|    205 |00:00:00.05 |   11036 |      0 |
|* 26 |               TABLE ACCESS BY INDEX ROWID BATCHED     | T_INDIVIDU                   |  30375 |      1 |    12   (0)|  28945 |00:00:00.10 |      14 |      0 |
|* 27 |                INDEX RANGE SCAN                       | SOC_INDIV                    |  30375 |     10 |     2   (0)|    303K|00:00:00.05 |      13 |      0 |
|  28 |             JOIN FILTER USE                           | :BF0001                      |      1 |   2079K| 22749   (1)|    410K|00:00:00.17 |   83333 |  83327 |
|* 29 |              MAT_VIEW ACCESS STORAGE FULL             | AD_REQUEST_LIMIT_MVIEW       |      1 |   2079K| 22749   (1)|    410K|00:00:00.16 |   83333 |  83327 |
|  30 |            VIEW                                       |                              |      1 |   1555 | 30301   (1)|  28227 |00:00:00.43 |     103K|  83327 |
|  31 |             HASH GROUP BY                             |                              |      1 |   1555 | 30301   (1)|  28227 |00:00:00.43 |     103K|  83327 |
|* 32 |              HASH JOIN                                |                              |      1 |   1555 | 29661   (1)|  69188 |00:00:00.22 |     103K|  83327 |
|  33 |               JOIN FILTER CREATE                      | :BF0003                      |      1 |   1000 | 27814   (1)|  23447 |00:00:00.12 |   96645 |  83327 |
|* 34 |                HASH JOIN OUTER                        |                              |      1 |   1000 | 27814   (1)|  23447 |00:00:00.12 |   96645 |  83327 |
|* 35 |                 HASH JOIN                             |                              |      1 |   1000 | 22773   (1)|  23447 |00:00:00.06 |   83338 |  83327 |
|  36 |                  JOIN FILTER CREATE                   | :BF0004                      |      1 |    115 |     4   (0)|    115 |00:00:00.01 |       5 |      0 |
|* 37 |                   INDEX RANGE SCAN                    | G_PIECE_TYPE_REFPIECE_INX    |      1 |    115 |     4   (0)|    115 |00:00:00.01 |       5 |      0 |
|  38 |                  JOIN FILTER USE                      | :BF0004                      |      1 |   1009 | 22769   (1)|  23447 |00:00:00.05 |   83333 |  83327 |
|* 39 |                   MAT_VIEW ACCESS STORAGE FULL        | AD_REQUEST_LIMIT_MVIEW       |      1 |   1009 | 22769   (1)|  23447 |00:00:00.05 |   83333 |  83327 |
|* 40 |                 VIEW                                  |                              |      1 |    196 |  5041   (1)|   1382 |00:00:00.05 |   13307 |      0 |
|* 41 |                  WINDOW SORT PUSHED RANK              |                              |      1 |    196 |  5041   (1)|   1382 |00:00:00.05 |   13307 |      0 |
|* 42 |                   TABLE ACCESS BY INDEX ROWID BATCHED | G_PIECEDET                   |      1 |    196 |  5040   (1)|   1382 |00:00:00.05 |   13307 |      0 |
|* 43 |                    INDEX RANGE SCAN                   | G_PIECEDET_TYPE_LASTLOAD_IDX |      1 |  51743 |   396   (0)|  51755 |00:00:00.01 |     457 |      0 |
|  44 |               JOIN FILTER USE                         | :BF0003                      |      1 |    223K|  1847   (1)|  98718 |00:00:00.06 |    6805 |      0 |
|* 45 |                TABLE ACCESS STORAGE FULL              | AD_ACCOUNT_DEBTOR_CLIENT     |      1 |    223K|  1847   (1)|  98718 |00:00:00.06 |    6805 |      0 |
|  46 |           VIEW                                        |                              |      1 |      1 | 98013   (1)|  40892 |00:00:00.36 |     352K|    352K|
|  47 |            HASH GROUP BY                              |                              |      1 |      1 | 98013   (1)|  40892 |00:00:00.36 |     352K|    352K|
|* 48 |             FILTER                                    |                              |      1 |        |            |    300K|00:00:00.26 |     352K|    352K|
|* 49 |              TABLE ACCESS STORAGE FULL                | AD_FINELEM_3NF               |      1 |      1 | 98012   (1)|    300K|00:00:00.24 |     352K|    352K|
|  50 |          VIEW                                         |                              |      1 |     13 |    11  (10)|     11 |00:00:00.01 |      15 |      0 |
|  51 |           HASH GROUP BY                               |                              |      1 |     13 |    11  (10)|     11 |00:00:00.01 |      15 |      0 |
|  52 |            VIEW                                       |                              |      1 |     13 |    11  (10)|     14 |00:00:00.01 |      15 |      0 |
|  53 |             WINDOW SORT                               |                              |      1 |     13 |    11  (10)|     14 |00:00:00.01 |      15 |      0 |
|  54 |              TABLE ACCESS BY INDEX ROWID BATCHED      | V_DOMAINE                    |      1 |     13 |    10   (0)|     14 |00:00:00.01 |      15 |      0 |
|* 55 |               INDEX RANGE SCAN                        | V_DOMAINE_IND                |      1 |     13 |     2   (0)|     14 |00:00:00.01 |       2 |      0 |
|* 56 |         MAT_VIEW ACCESS BY INDEX ROWID BATCHED        | AD_REQUEST_LIMIT_MVIEW       |  30375 |      1 |     3   (0)|  29384 |00:00:00.83 |     127K|      0 |
|* 57 |          INDEX RANGE SCAN                             | TEST_DD_INDEX                |  30375 |      1 |     2   (0)|  70242 |00:00:00.67 |   61037 |      0 |
|  58 |        TABLE ACCESS BY INDEX ROWID BATCHED            | AD_DEBTORS                   |  30375 |      1 |     2   (0)|  30375 |00:00:00.16 |   91219 |      0 |
|* 59 |         INDEX RANGE SCAN                              | AD_DEBTORS_PK                |  30375 |      1 |     1   (0)|  30375 |00:00:00.09 |   60852 |      0 |
|  60 |       TABLE ACCESS BY INDEX ROWID BATCHED             | V_DOMAINE                    |  30375 |      1 |     2   (0)|  30375 |00:00:00.07 |   33098 |      0 |
|* 61 |        INDEX RANGE SCAN                               | V_DOMAINE_IND                |  30375 |      1 |     1   (0)|  30375 |00:00:00.04 |   14075 |      0 |
|  62 |     VIEW                                              |                              |      1 |    257K|  5922   (1)|  92956 |00:00:00.91 |   12275 |      0 |
|  63 |      HASH GROUP BY                                    |                              |      1 |    257K|  5922   (1)|  92956 |00:00:00.90 |   12275 |      0 |
|* 64 |       VIEW                                            |                              |      1 |    257K|  5922   (1)|    105K|00:00:00.67 |   12275 |      0 |
|  65 |        JOIN FILTER USE                                | :BF0000                      |      1 |    257K|  5922   (1)|    105K|00:00:00.66 |   12275 |      0 |
|* 66 |         WINDOW SORT PUSHED RANK                       |                              |      1 |    257K|  5922   (1)|    244K|00:00:00.64 |   12275 |      0 |
|* 67 |          TABLE ACCESS STORAGE FULL                    | T_INDIVIDU                   |      1 |    257K|  3331   (1)|    257K|00:00:00.07 |   12275 |      0 |
----------------------------------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   3 - access("EXT"."REFINDIVIDU"="CLDB"."DEBTOR" AND "EXT"."REFEXT3"="CLDB"."ANCREFDOSS")
   8 - access("LOV_CI"."VALEUR"="CR_I"."REFEXT")
   9 - access("FI"."FI_REFDOSS"="CLDB"."REFDOSS")
  10 - access("CI_LIM"."GPIADR3"="CLDB"."DEBTOR" AND "CI_LIM"."GPIDEPOT"="CLDB"."CLIENT" AND "CI_LIM"."GPIHEURE"="CLDB"."ANCREFDOSS")
  11 - access("PRE_LIM"."REFPIECE"="LIM"."ST04")
  14 - access("CI"."REFDOSS"="POL"."REFDOSS")
  18 - access("LIM"."GPIADR3"="CLDB"."DEBTOR" AND "LIM"."GPIDEPOT"="CLDB"."CLIENT" AND "LIM"."GPITYPTRIB"="CLDB"."FACTOR")
  20 - filter(("LIM"."GPIDEPOT" IS NOT NULL AND "LIM"."LIBELLE_100_8" IS NOT NULL AND "LIM"."GPITYPTRIB" IS NOT NULL AND "LIM"."FG05"='O'))
  21 - access("LIM"."TYPEDOC"='C' AND "LIM"."TYPPIECE"='REQUEST_LIMITE')
  22 - access("POL"."TYPPIECE"='POLICE')
  23 - filter("POL"."REFPIECE"="LIM"."LIBELLE_100_8")
  25 - storage(("CI"."REFTYPE"='DB' AND SYS_OP_BLOOM_FILTER(:BF0002,"CI"."REFDOSS")))
       filter(("CI"."REFTYPE"='DB' AND SYS_OP_BLOOM_FILTER(:BF0002,"CI"."REFDOSS")))
  26 - filter("CR_I"."REFINDIVIDU"="CI"."REFINDIVIDU")
  27 - access("CR_I"."SOCIETE"='CR_INSURER')
  29 - storage(SYS_OP_BLOOM_FILTER(:BF0001,"PRE_LIM"."REFPIECE"))
       filter(SYS_OP_BLOOM_FILTER(:BF0001,"PRE_LIM"."REFPIECE"))
  32 - access("CI_LIM"."GPIADR3"="CLDB"."DEBTOR")
  34 - access("LIMCICF"."REFPIECE"="CI_LIM"."REFPIECE")
  35 - access("POL"."REFPIECE"="CI_LIM"."LIBELLE_100_8")
  37 - access("POL"."TYPPIECE"='POLICE')
  39 - storage(("CI_LIM"."LIBELLE_100_8" IS NOT NULL AND "CI_LIM"."GPIADR3" IS NOT NULL AND "CI_LIM"."FG05"='O' AND INTERNAL_FUNCTION("CI_LIM"."TYPEDOC") AND
              SYS_OP_BLOOM_FILTER(:BF0004,"CI_LIM"."LIBELLE_100_8")))
       filter(("CI_LIM"."LIBELLE_100_8" IS NOT NULL AND "CI_LIM"."GPIADR3" IS NOT NULL AND "CI_LIM"."FG05"='O' AND INTERNAL_FUNCTION("CI_LIM"."TYPEDOC") AND
              SYS_OP_BLOOM_FILTER(:BF0004,"CI_LIM"."LIBELLE_100_8")))
  40 - filter("LIMCICF"."RN"=1)
  41 - filter(ROW_NUMBER() OVER ( PARTITION BY "REFPIECE" ORDER BY INTERNAL_FUNCTION("IMX_UN_ID") DESC )<=1)
  42 - filter("STR2"='ULA')
  43 - access("TYPE"='REQUEST_CF_PROPOSAL')
  45 - storage(SYS_OP_BLOOM_FILTER(:BF0003,"CLDB"."DEBTOR"))
       filter(SYS_OP_BLOOM_FILTER(:BF0003,"CLDB"."DEBTOR"))
  48 - filter(TO_NUMBER(TO_CHAR(TRUNC(SYSDATE@!,'fmmm')-1,'j'))>=TO_NUMBER(TO_CHAR(TRUNC(TRUNC(SYSDATE@!,'fmmm')-1,'fmmm'),'j')))
  49 - storage(("FI_DTANNUL" IS NULL AND INTERNAL_FUNCTION("FI_ACTIF") AND INTERNAL_FUNCTION("FI_TYPE") AND
              "FI_DTJOUR"<=TO_NUMBER(TO_CHAR(TRUNC(SYSDATE@!,'fmmm')-1,'j')) AND "FI_DTJOUR">=TO_NUMBER(TO_CHAR(TRUNC(TRUNC(SYSDATE@!,'fmmm')-1,'fmmm'),'j')) AND
              "INV_STATUS"<>'REASSIGNED'))
       filter(("FI_DTANNUL" IS NULL AND INTERNAL_FUNCTION("FI_ACTIF") AND INTERNAL_FUNCTION("FI_TYPE") AND
              "FI_DTJOUR"<=TO_NUMBER(TO_CHAR(TRUNC(SYSDATE@!,'fmmm')-1,'j')) AND "FI_DTJOUR">=TO_NUMBER(TO_CHAR(TRUNC(TRUNC(SYSDATE@!,'fmmm')-1,'fmmm'),'j')) AND
              "INV_STATUS"<>'REASSIGNED'))
  55 - access("TYPE"='CI_IDENT_DBUPLD')
  56 - filter("FG05"='O')
  57 - access("GPIADR3"="CLDB"."DEBTOR" AND "GPIDEPOT"="CLDB"."CLIENT" AND "TYPEDOC"='F')
       filter(("GPIADR3" IS NOT NULL AND "GPIDEPOT" IS NOT NULL))
  59 - access("DB"."DEBTOR_REFINDIVIDU"="CLDB"."DEBTOR")
  61 - access("PAY"."TYPE"='pays' AND "PAY"."ABREV"="DB"."DEBTOR_PAYS")
  64 - filter("RN"<=10)
  66 - filter(ROW_NUMBER() OVER ( PARTITION BY "REFINDIVIDU","REFEXT3" ORDER BY INTERNAL_FUNCTION("IMX_UN_ID") DESC )<=10)
  67 - storage(("SOCIETE"='CLIENT_NUMBER' AND "REFEXT" IS NOT NULL))
       filter(("SOCIETE"='CLIENT_NUMBER' AND "REFEXT" IS NOT NULL))



-- 81y3pxkbbdmf7

Plan hash value: 1098692232
------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                                  | Name                         | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  | Writes |
------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                                           |                              |      1 |        |  2896K(100)|   6075 |00:00:14.02 |    9390K|   8865K|  29464 |
|   1 |  VIEW                                                      |                              |      1 |      1 |  2896K  (1)|   6075 |00:00:14.02 |    9390K|   8865K|  29464 |
|*  2 |   FILTER                                                   |                              |      1 |        |            |   6075 |00:00:14.01 |    9390K|   8865K|  29464 |
|   3 |    SORT GROUP BY                                           |                              |      1 |      1 |  2896K  (1)|  29591 |00:00:14.01 |    9390K|   8865K|  29464 |
|*  4 |     HASH JOIN OUTER                                        |                              |      1 |      1 |  2896K  (1)|  30375 |00:00:11.59 |    9330K|   8865K|  29464 |
|   5 |      JOIN FILTER CREATE                                    | :BF0000                      |      1 |      1 |   159K  (1)|  30375 |00:00:03.60 |    1011K|    519K|      0 |
|*  6 |       HASH JOIN OUTER                                      |                              |      1 |      1 |   159K  (1)|  30375 |00:00:03.60 |    1011K|    519K|      0 |
|   7 |        JOIN FILTER CREATE                                  | :BF0001                      |      1 |      1 |   137K  (1)|  30375 |00:00:03.37 |     928K|    435K|      0 |
|*  8 |         HASH JOIN OUTER                                    |                              |      1 |      1 |   137K  (1)|  30375 |00:00:03.37 |     928K|    435K|      0 |
|   9 |          JOIN FILTER CREATE                                | :BF0002                      |      1 |      1 |   131K  (1)|  30375 |00:00:02.49 |     915K|    435K|      0 |
|* 10 |           HASH JOIN OUTER                                  |                              |      1 |      1 |   131K  (1)|  30375 |00:00:02.49 |     915K|    435K|      0 |
|  11 |            NESTED LOOPS OUTER                              |                              |      1 |      1 |   131K  (1)|  30375 |00:00:02.45 |     915K|    435K|      0 |
|  12 |             NESTED LOOPS OUTER                             |                              |      1 |      1 |   131K  (1)|  30375 |00:00:02.40 |     910K|    435K|      0 |
|  13 |              NESTED LOOPS OUTER                            |                              |      1 |      1 |   131K  (1)|  30375 |00:00:02.34 |     878K|    435K|      0 |
|  14 |               NESTED LOOPS                                 |                              |      1 |      1 |   131K  (1)|  30375 |00:00:02.26 |     857K|    435K|      0 |
|  15 |                NESTED LOOPS OUTER                          |                              |      1 |      1 |   131K  (1)|  30375 |00:00:02.09 |     771K|    435K|      0 |
|* 16 |                 HASH JOIN OUTER                            |                              |      1 |      1 |   131K  (1)|  30375 |00:00:01.28 |     644K|    435K|      0 |
|* 17 |                  HASH JOIN OUTER                           |                              |      1 |      1 |   100K  (1)|  30375 |00:00:00.75 |     540K|    352K|      0 |
|  18 |                   NESTED LOOPS                             |                              |      1 |      1 |  2785   (1)|  30375 |00:00:00.32 |     188K|      0 |      0 |
|  19 |                    NESTED LOOPS                            |                              |      1 |      1 |  2785   (1)|  30375 |00:00:00.26 |     159K|      0 |      0 |
|* 20 |                     HASH JOIN                              |                              |      1 |      1 |  2782   (1)|  27966 |00:00:00.18 |     102K|      0 |      0 |
|  21 |                      TABLE ACCESS BY INDEX ROWID BATCHED   | G_PIECE                      |      1 |    115 |    41   (0)|    115 |00:00:00.01 |     184 |      0 |      0 |
|* 22 |                       INDEX RANGE SCAN                     | GP_TYPPLIB_IDX               |      1 |    115 |     4   (0)|    115 |00:00:00.01 |       5 |      0 |      0 |
|* 23 |                      TABLE ACCESS BY INDEX ROWID BATCHED   | G_PIECE                      |      1 |   5793 |  2741   (1)|  27966 |00:00:00.17 |     102K|      0 |      0 |
|* 24 |                       INDEX RANGE SCAN                     | GP_TYPEDOC                   |      1 |  10463 |    70   (0)|  61652 |00:00:00.02 |    2323 |      0 |      0 |
|* 25 |                     INDEX RANGE SCAN                       | AD_ACCOUNT_DBCL_DBCL_IND     |  27966 |      1 |     2   (0)|  30375 |00:00:00.07 |   56057 |      0 |      0 |
|* 26 |                    TABLE ACCESS BY INDEX ROWID             | AD_ACCOUNT_DEBTOR_CLIENT     |  30375 |      1 |     3   (0)|  30375 |00:00:00.05 |   29242 |      0 |      0 |
|  27 |                   VIEW                                     |                              |      1 |      1 | 97979   (1)|  42238 |00:00:00.39 |     352K|    352K|      0 |
|  28 |                    HASH GROUP BY                           |                              |      1 |      1 | 97979   (1)|  42238 |00:00:00.39 |     352K|    352K|      0 |
|* 29 |                     TABLE ACCESS STORAGE FULL              | AD_FINELEM_3NF               |      1 |   3311 | 97978   (1)|    474K|00:00:00.28 |     352K|    352K|      0 |
|  30 |                  VIEW                                      |                              |      1 |   1555 | 30339   (1)|  29072 |00:00:00.47 |     103K|  83327 |      0 |
|  31 |                   HASH GROUP BY                            |                              |      1 |   1555 | 30339   (1)|  29072 |00:00:00.46 |     103K|  83327 |      0 |
|* 32 |                    HASH JOIN                               |                              |      1 |   1555 | 29698   (1)|  69188 |00:00:00.23 |     103K|  83327 |      0 |
|  33 |                     JOIN FILTER CREATE                     | :BF0003                      |      1 |   1000 | 27851   (1)|  23447 |00:00:00.12 |   96824 |  83327 |      0 |
|* 34 |                      HASH JOIN OUTER                       |                              |      1 |   1000 | 27851   (1)|  23447 |00:00:00.12 |   96824 |  83327 |      0 |
|* 35 |                       HASH JOIN                            |                              |      1 |   1000 | 22810   (1)|  23447 |00:00:00.06 |   83517 |  83327 |      0 |
|  36 |                        JOIN FILTER CREATE                  | :BF0004                      |      1 |    115 |    41   (0)|    115 |00:00:00.01 |     184 |      0 |      0 |
|  37 |                         TABLE ACCESS BY INDEX ROWID BATCHED| G_PIECE                      |      1 |    115 |    41   (0)|    115 |00:00:00.01 |     184 |      0 |      0 |
|* 38 |                          INDEX RANGE SCAN                  | GP_TYPPLIB_IDX               |      1 |    115 |     4   (0)|    115 |00:00:00.01 |       5 |      0 |      0 |
|  39 |                        JOIN FILTER USE                     | :BF0004                      |      1 |   1009 | 22769   (1)|  23447 |00:00:00.05 |   83333 |  83327 |      0 |
|* 40 |                         MAT_VIEW ACCESS STORAGE FULL       | AD_REQUEST_LIMIT_MVIEW       |      1 |   1009 | 22769   (1)|  23447 |00:00:00.05 |   83333 |  83327 |      0 |
|* 41 |                       VIEW                                 |                              |      1 |    196 |  5041   (1)|   1382 |00:00:00.05 |   13307 |      0 |      0 |
|* 42 |                        WINDOW SORT PUSHED RANK             |                              |      1 |    196 |  5041   (1)|   1382 |00:00:00.05 |   13307 |      0 |      0 |
|* 43 |                         TABLE ACCESS BY INDEX ROWID BATCHED| G_PIECEDET                   |      1 |    196 |  5040   (1)|   1382 |00:00:00.05 |   13307 |      0 |      0 |
|* 44 |                          INDEX RANGE SCAN                  | G_PIECEDET_TYPE_LASTLOAD_IDX |      1 |  51743 |   396   (0)|  51755 |00:00:00.01 |     457 |      0 |      0 |
|  45 |                     JOIN FILTER USE                        | :BF0003                      |      1 |    223K|  1847   (1)|  98718 |00:00:00.06 |    6805 |      0 |      0 |
|* 46 |                      TABLE ACCESS STORAGE FULL             | AD_ACCOUNT_DEBTOR_CLIENT     |      1 |    223K|  1847   (1)|  98718 |00:00:00.06 |    6805 |      0 |      0 |
|* 47 |                 MAT_VIEW ACCESS BY INDEX ROWID BATCHED     | AD_REQUEST_LIMIT_MVIEW       |  30375 |      1 |     3   (0)|  29384 |00:00:00.80 |     126K|      0 |      0 |
|* 48 |                  INDEX RANGE SCAN                          | TEST_DD_INDEX                |  30375 |      1 |     2   (0)|  70242 |00:00:00.64 |   60925 |      0 |      0 |
|  49 |                TABLE ACCESS BY INDEX ROWID BATCHED         | AD_DEBTORS                   |  30375 |      1 |     2   (0)|  30375 |00:00:00.16 |   86953 |      0 |      0 |
|* 50 |                 INDEX RANGE SCAN                           | AD_DEBTORS_PK                |  30375 |      1 |     1   (0)|  30375 |00:00:00.09 |   59517 |      0 |      0 |
|  51 |               TABLE ACCESS BY INDEX ROWID BATCHED          | V_DOMAINE                    |  30375 |      1 |     2   (0)|  30375 |00:00:00.06 |   20256 |      0 |      0 |
|* 52 |                INDEX RANGE SCAN                            | V_DOMAINE_IND                |  30375 |      1 |     1   (0)|  30375 |00:00:00.03 |   10045 |      0 |      0 |
|* 53 |              INDEX RANGE SCAN                              | INT_REFDOSS                  |  30375 |      1 |     2   (0)|  30375 |00:00:00.05 |   32674 |      0 |      0 |
|  54 |             TABLE ACCESS BY INDEX ROWID BATCHED            | T_INDIVIDU                   |  30375 |      1 |     3   (0)|  28945 |00:00:00.04 |    4881 |      0 |      0 |
|* 55 |              INDEX RANGE SCAN                              | T_INDIVIDU_RSR_IDX           |  30375 |      1 |     2   (0)|  28945 |00:00:00.03 |    4880 |      0 |      0 |
|  56 |            VIEW                                            |                              |      1 |     13 |    11  (10)|     11 |00:00:00.01 |      15 |      0 |      0 |
|  57 |             HASH GROUP BY                                  |                              |      1 |     13 |    11  (10)|     11 |00:00:00.01 |      15 |      0 |      0 |
|  58 |              VIEW                                          |                              |      1 |     13 |    11  (10)|     14 |00:00:00.01 |      15 |      0 |      0 |
|  59 |               WINDOW SORT                                  |                              |      1 |     13 |    11  (10)|     14 |00:00:00.01 |      15 |      0 |      0 |
|  60 |                TABLE ACCESS BY INDEX ROWID BATCHED         | V_DOMAINE                    |      1 |     13 |    10   (0)|     14 |00:00:00.01 |      15 |      0 |      0 |
|* 61 |                 INDEX RANGE SCAN                           | V_DOMAINE_IND                |      1 |     13 |     2   (0)|     14 |00:00:00.01 |       2 |      0 |      0 |
|  62 |          VIEW                                              |                              |      1 |    257K|  5922   (1)|  92956 |00:00:00.84 |   12275 |      0 |      0 |
|  63 |           HASH GROUP BY                                    |                              |      1 |    257K|  5922   (1)|  92956 |00:00:00.84 |   12275 |      0 |      0 |
|* 64 |            VIEW                                            |                              |      1 |    257K|  5922   (1)|    105K|00:00:00.63 |   12275 |      0 |      0 |
|  65 |             JOIN FILTER USE                                | :BF0002                      |      1 |    257K|  5922   (1)|    105K|00:00:00.62 |   12275 |      0 |      0 |
|* 66 |              WINDOW SORT PUSHED RANK                       |                              |      1 |    257K|  5922   (1)|    244K|00:00:00.61 |   12275 |      0 |      0 |
|* 67 |               TABLE ACCESS STORAGE FULL                    | T_INDIVIDU                   |      1 |    257K|  3331   (1)|    257K|00:00:00.07 |   12275 |      0 |      0 |
|  68 |        JOIN FILTER USE                                     | :BF0001                      |      1 |   2079K| 22767   (1)|    410K|00:00:00.15 |   83333 |  83327 |      0 |
|* 69 |         MAT_VIEW ACCESS STORAGE FULL                       | AD_REQUEST_LIMIT_MVIEW       |      1 |   2079K| 22767   (1)|    410K|00:00:00.14 |   83333 |  83327 |      0 |
|  70 |      VIEW                                                  |                              |      1 |   2081K|  2736K  (1)|   8173 |00:00:07.93 |    8318K|   8346K|  29464 |
|* 71 |       FILTER                                               |                              |      1 |        |            |   8173 |00:00:07.93 |    8318K|   8346K|  29464 |
|  72 |        HASH GROUP BY                                       |                              |      1 |   2081K|  2736K  (1)|  21868 |00:00:07.93 |    8318K|   8346K|  29464 |
|  73 |         JOIN FILTER USE                                    | :BF0000                      |      1 |     41M|  2496K  (1)|   2911K|00:00:07.14 |    8318K|   8346K|  29464 |
|* 74 |          HASH JOIN                                         |                              |      1 |     41M|  2496K  (1)|   2911K|00:00:07.09 |    8318K|   8346K|  29464 |
|* 75 |           TABLE ACCESS STORAGE FULL                        | AD_LIMITS_CONSUMATION        |      1 |  67511 |   445   (1)|  28184 |00:00:00.01 |    1660 |      0 |      0 |
|* 76 |           HASH JOIN                                        |                              |      1 |    123M|  2495K  (1)|   2912K|00:00:06.32 |    8317K|   8346K|  29464 |
|  77 |            TABLE ACCESS STORAGE FULL                       | G_ELEMFI                     |      1 |   6624K| 58675   (1)|   6624K|00:00:00.73 |     215K|    215K|      0 |
|* 78 |            TABLE ACCESS STORAGE FULL                       | G_VENFILIMIT                 |      1 |    123M|  2197K  (1)|   2912K|00:00:01.74 |    8101K|   8101K|    127 |
------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   2 - filter(SUM("CH_TAUX"."CONV_ORIG_DEST_TX"("AD_JULLIAN_DATE"(TO_CHAR(TRUNC(SYSDATE@!,'fmmm')-1,'dd/mm/rrrr')),"FI"."FI_OPEN_AMOUNT","FI"."FI_DEVISE_DOS",'EUR','MR','')
              )>1000)
  4 - access("LIM_CONSMP"."REFDOSS"="CLDB"."REFDOSS" AND "LIM_CONSMP"."STR_20_1"="LIM"."REFPIECE")
   6 - access("PRE_LIM"."REFPIECE"="LIM"."ST04")
   8 - access("EXT"."REFINDIVIDU"="CLDB"."DEBTOR" AND "EXT"."REFEXT3"="CLDB"."ANCREFDOSS")
  10 - access("LOV_CI"."VALEUR"="CR_I"."REFEXT")
  16 - access("CI_LIM"."GPIADR3"="CLDB"."DEBTOR" AND "CI_LIM"."GPIDEPOT"="CLDB"."CLIENT" AND "CI_LIM"."GPIHEURE"="CLDB"."ANCREFDOSS" AND "CI_LIM"."REFEXT"="POL"."REFEXT")
  17 - access("FI"."FI_REFDOSS"="CLDB"."REFDOSS")
  20 - access("POL"."REFPIECE"="LIM"."LIBELLE_100_8")
  22 - access("POL"."TYPPIECE"='POLICE')
  23 - filter(("LIM"."GPIDEPOT" IS NOT NULL AND "LIM"."LIBELLE_100_8" IS NOT NULL AND "LIM"."GPITYPTRIB" IS NOT NULL AND "LIM"."FG05"='O'))
  24 - access("LIM"."TYPEDOC"='C' AND "LIM"."TYPPIECE"='REQUEST_LIMITE')
  25 - access("LIM"."GPIADR3"="CLDB"."DEBTOR" AND "LIM"."GPIDEPOT"="CLDB"."CLIENT")
  26 - filter("LIM"."GPITYPTRIB"="CLDB"."FACTOR")
  29 - storage(("FI_ACTIF"='O' AND "FI_DTJOUR"<=TO_NUMBER(TO_CHAR(TRUNC(SYSDATE@!,'fmmm')-1,'j'))))
       filter(("FI_ACTIF"='O' AND "FI_DTJOUR"<=TO_NUMBER(TO_CHAR(TRUNC(SYSDATE@!,'fmmm')-1,'j'))))
  32 - access("CI_LIM"."GPIADR3"="CLDB"."DEBTOR")
  34 - access("LIMCICF"."REFPIECE"="CI_LIM"."REFPIECE")
  35 - access("POL"."REFPIECE"="CI_LIM"."LIBELLE_100_8")
  38 - access("POL"."TYPPIECE"='POLICE')
  40 - storage(("CI_LIM"."LIBELLE_100_8" IS NOT NULL AND "CI_LIM"."GPIADR3" IS NOT NULL AND "CI_LIM"."FG05"='O' AND INTERNAL_FUNCTION("CI_LIM"."TYPEDOC") AND
              SYS_OP_BLOOM_FILTER(:BF0004,"CI_LIM"."LIBELLE_100_8")))
       filter(("CI_LIM"."LIBELLE_100_8" IS NOT NULL AND "CI_LIM"."GPIADR3" IS NOT NULL AND "CI_LIM"."FG05"='O' AND INTERNAL_FUNCTION("CI_LIM"."TYPEDOC") AND
              SYS_OP_BLOOM_FILTER(:BF0004,"CI_LIM"."LIBELLE_100_8")))
  41 - filter("LIMCICF"."RN"=1)
  42 - filter(ROW_NUMBER() OVER ( PARTITION BY "REFPIECE" ORDER BY INTERNAL_FUNCTION("IMX_UN_ID") DESC )<=1)
  43 - filter("STR2"='ULA')
  44 - access("TYPE"='REQUEST_CF_PROPOSAL')
  46 - storage(SYS_OP_BLOOM_FILTER(:BF0003,"CLDB"."DEBTOR"))
       filter(SYS_OP_BLOOM_FILTER(:BF0003,"CLDB"."DEBTOR"))
  47 - filter("FG05"='O')
  48 - access("GPIADR3"="CLDB"."DEBTOR" AND "GPIDEPOT"="CLDB"."CLIENT" AND "TYPEDOC"='F')
       filter(("GPIADR3" IS NOT NULL AND "GPIDEPOT" IS NOT NULL))
  50 - access("DB"."DEBTOR_REFINDIVIDU"="CLDB"."DEBTOR")
  52 - access("PAY"."TYPE"='pays' AND "PAY"."ABREV"="DB"."DEBTOR_PAYS")
  53 - access("CI"."REFDOSS"="POL"."REFDOSS" AND "CI"."REFTYPE"='DB')
  55 - access("CR_I"."REFINDIVIDU"="CI"."REFINDIVIDU" AND "CR_I"."SOCIETE"='CR_INSURER')
  61 - access("TYPE"='CI_IDENT_DBUPLD')
  64 - filter("RN"<=10)
  66 - filter(ROW_NUMBER() OVER ( PARTITION BY "REFINDIVIDU","REFEXT3" ORDER BY INTERNAL_FUNCTION("IMX_UN_ID") DESC )<=10)
  67 - storage(("SOCIETE"='CLIENT_NUMBER' AND "REFEXT" IS NOT NULL))
       filter(("SOCIETE"='CLIENT_NUMBER' AND "REFEXT" IS NOT NULL))
  69 - storage(SYS_OP_BLOOM_FILTER(:BF0001,"PRE_LIM"."REFPIECE"))
       filter(SYS_OP_BLOOM_FILTER(:BF0001,"PRE_LIM"."REFPIECE"))
  71 - filter(SUM("GV"."CONSUMED_LIM")<>0)
  74 - access("GV"."LIMIT_ID"="LIM_CON"."REFPIECE")
  75 - storage("LIM_CON"."LIMIT_TYPE"='C')
       filter("LIM_CON"."LIMIT_TYPE"='C')
  76 - access("GE"."REFELEM"="GV"."FI_ID")
  78 - storage("GV"."LIMIT_ROLE"='COVERAGE')
       filter("GV"."LIMIT_ROLE"='COVERAGE')


*/
/********************************New Metrics***************************************/

/********************************Index statistics**********************************/

/********************************Other SQLs****************************************/          
/*

*/ 
/********************************Other SQLs****************************************/              
