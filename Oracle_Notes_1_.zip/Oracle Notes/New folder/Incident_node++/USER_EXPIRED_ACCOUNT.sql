########### expired account, change password, account unlock ####################

Eto tuk sa ti samo komandite, koito ti trqbvat:

[root@x0044 ~]# su - oracle
x0044::~$ . oraenv
ORACLE_SID = [oracle] ? ORA0317
x0044:ORA0317:~$ sqlplus / as sysdba
SQL> show parameter db_name
SQL> SELECT USERNAME, ACCOUNT_STATUS FROM DBA_USERS WHERE USERNAME='TX2513';

USERNAME                       ACCOUNT_STATUS
------------------------------ --------------------------------
TX2513                         EXPIRED

SQL>
SQL> set long 9999999999
select dbms_metadata.get_ddl('USER', username) || '/' usercreate from dba_users where username='CPAMEMOTECH';SP2-0268: long option not a valid number
SQL>

USERCREATE
--------------------------------------------------------------------------------

   CREATE USER "TX2513" IDENTIFIED BY VALUES 'S:25C00DDBBC2FEF286D94C9D8D87F5EB


SQL>
SQL> ALTER USER TX2513 ACCOUNT UNLOCK;
SQL>
SQL> alter user TX2513 identified by "Pa$$word_2019";
SQL>
SQL> ALTER USER TX2513 ACCOUNT UNLOCK;

User altered.

SQL>
SQL> SELECT USERNAME, ACCOUNT_STATUS FROM DBA_USERS WHERE USERNAME='TX2513';

USERNAME                       ACCOUNT_STATUS
------------------------------ --------------------------------
TX2513                         OPEN

================================================================================================================================
================================================================================================================================

Tuk e celiqt output ot putty terminal-a


[root@x0044 ~]# su - oracle
x0044::~$
x0044::~$
x0044::~$ . oraenv
ORACLE_SID = [oracle] ? ORA0317
The Oracle base remains unchanged with value /u01/app/oracle
x0044:ORA0317:~$
x0044:ORA0317:~$
x0044:ORA0317:~$
x0044:ORA0317:~$
x0044:ORA0317:~$ sqlplus / as sysdba

SQL*Plus: Release 11.2.0.4.0 Production on Thu Jun 27 20:26:28 2019

Copyright (c) 1982, 2013, Oracle.  All rights reserved.


Connected to:
Oracle Database 11g Enterprise Edition Release 11.2.0.4.0 - 64bit Production
With the Partitioning, OLAP, Data Mining and Real Application Testing options

SQL>
SQL>
SQL>
SQL> show parameter db_name

NAME                                 TYPE
------------------------------------ --------------------------------
VALUE
------------------------------
db_name                              string
ORA0317
SQL>
SQL>
SQL>
SQL> set lines 200
SQL> show parameter db_name
.
NAME                                 TYPE                             VALUE
------------------------------------ -------------------------------- ------------------------------
db_name                              string                           ORA0317
SQL>
SQL>
SQL>
SQL>
SQL>
SQL>
SQL> SELECT USERNAME, ACCOUNT_STATUS FROM DBA_USERS WHERE USERNAME='GCT';

no rows selected

SQL> SELECT USERNAME, ACCOUNT_STATUS FROM DBA_USERS WHERE USERNAME='EDS5092';

USERNAME                       ACCOUNT_STATUS
------------------------------ --------------------------------
TX2513                         EXPIRED

SQL>
SQL>
SQL>
SQL>
SQL>
SQL> set line 9999999999
select dbms_metadata.get_ddl('USER', username) || '/' usercreate from dba_users where username='EDS5092';
SQL>

USERCREATE
--------------------------------------------------------------------------------

   CREATE USER "TX2513" IDENTIFIED BY VALUES 'S:25C00DDBBC2FEF286D94C9D8D87F5EB


SQL>
SQL>
SQL>
SQL>
SQL>
SQL>  ALTER USER 'TX2513' ACCOUNT UNLOCK;
ALTER USER 'TX2513' ACCOUNT UNLOCK
            *
ERROR at line 1:
ORA-01935: missing user or role name


SQL> ALTER USER TX2513 ACCOUNT UNLOCK;

User altered.

SQL>
SQL>
SQL>
SQL> SELECT USERNAME, ACCOUNT_STATUS FROM DBA_USERS WHERE USERNAME='TX2513';

USERNAME                       ACCOUNT_STATUS
------------------------------ --------------------------------
TX2513                         EXPIRED

SQL>
SQL>
SQL>
SQL>
SQL> alter user TX2513 identified by "Pa$$word_2019";

User altered.

SQL>
SQL>
SQL>
SQL>
SQL> ALTER USER TX2513 ACCOUNT UNLOCK;

User altered.

SQL>
SQL>
SQL>
SQL>
SQL> SELECT USERNAME, ACCOUNT_STATUS FROM DBA_USERS WHERE USERNAME='TX2513';

USERNAME                       ACCOUNT_STATUS
------------------------------ --------------------------------
TX2513                         OPEN

SQL>
============================================================================================================================
===========================================================================================================================