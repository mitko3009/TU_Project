/********************************************************************************
*********       E-mail subject: SUDFWEB-2084
*********             Instance: PROD V9
*********          Description: 
Problem:
Slowness in bq_imx_stmt_iso_v02 interface on PROD V9.

Analysis:
After the analyze, we found that the TOP 4 SQL are responsible for 20-25% of the load of bq_imx_stmt_iso_v02 from 15:00 to 15:40 on 12/06/2024.
The problem in the TOP SQL 6s640d4hvvj05 and the second TOP SQL cba3bu200d0s4 is missing appropriate index. We tested the queries with creating indexes 
for this two queries and as you can see in the New Metrics section below, the indexes helps, so please contact C&D and ask to create indexes on column(MESSAGE_ID) on table NAM_COLLECTE 
and on columns(INTERFACE, SCHEMATYPE, DT_CREATION_DT) on table BUF_STD_ENTRYTR. For the third and the forth SQLs ( 0wtgby70z9tpb and 18yarjkpsq7h8), the problem is that column createur on table t_reprise_list is used 
for search, which leads to FULL SCAN of table t_reprise_list, because column createur is not indexed. Coumn createur is not selective, so it could not be indexed. Please use another 
indexed column on table t_reprise_list ( the listed columns below ).


-- Indexed columns on table t_reprise_list  that you can use instead of column createur.

INDEX_NAME                     INFO       BLEVEL       ROWS   ROWS/KEY       KEYS     BLOCKS   CF  DATAB/KEY  LEAFB/KEY LAST_ANALY COLUMNS
------------------------------ ------ ---------- ---------- ---------- ---------- ---------- ---- ---------- ---------- ---------- ---------
T_REPLIST_MAITRE                               0          0          0          0          0    0          0          0 12/02/2020 MAITRE
T_REPLIST_REFCL                                0          0          0          0          0    0          0          0 12/02/2020 REFCL
T_REPLIST_REFDB                                0          0          0          0          0    0          0          0 12/02/2020 REFDB


Suggestion:
1. For SQLs 6s640d4hvvj05 and cba3bu200d0s4, please ask C&D to create indexes as it is shown in the New Metrics section below.
2. For SQLs 0wtgby70z9tpb and 18yarjkpsq7h8, please use another column for access table t_reprise_list, because column createur is not selective and it is not indexed.

*********               SQL_ID: 6s640d4hvvj05, cba3bu200d0s4, 0wtgby70z9tpb, 18yarjkpsq7h8
*********      Program/Package: 
*********              Request: Dimitare Ivanov
*********               Author: Dimitar Dimitrov
********* Received e-mail date: 13/06/2024
*********      Resolution date: 14/06/2024
*********  Trace old file here: \\epox\specifs\performance\tmp\
*********  Trace new file here:
***********************************************************************************/

/********************************OLD SQL*******************************************/

-- 6s640d4hvvj05

var B1 number;
exec :B1 := 2527;
var B2 varchar2(128);
-- exec :B2 := '4466331545-0000010';
exec :B2 := 'BAP2024-05-21-09.20.14.898117000017';

SELECT COUNT(1) 
  FROM NAM_COLLECTE NAM , 
       G_LOTCOLL LOT 
 WHERE NAM.MESSAGE_ID = :B2 
   AND NAM.DTLOT = LOT.DTLOT 
   AND LOT.REFCPTBQ = :B1;

-- cba3bu200d0s4

var B1 varchar2(32);
exec :B1 := '06/13/2024 11:53:38';
var B2 varchar2(32);
exec :B2 := 'bq_imx_stmt_iso_v08';
var B3 varchar2(32);
exec :B3 := '08';
var B4 number;
exec :B4 := 2527;

UPDATE BUF_STD_ENTRYTR 
   SET FILE_ID = :B4 
 WHERE FILE_ID IS NULL 
   AND SCHEMATYPE = :B3 
   AND INTERFACE = :B2 
   AND DT_CREATION_DT >= :B1;


-- 0wtgby70z9tpb

var interfaceName varchar2(32);
exec :interfaceName := 'bq_imx_stmt_iso_v08';

SELECT client 
  FROM t_reprise_list 
 WHERE createur = :interfaceName;


-- 18yarjkpsq7h8
DELETE 
  FROM t_reprise_list
 WHERE createur = :interfaceName;

/********************************OLD SQL*******************************************/
/********************************OLD Metrics***************************************/
/*
MODULE              SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
------------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
bq_imx_stmt_iso_v02                                2116       4003                      2024/06/12 14:59:11  2024/06/12 15:39:50        2307              8976829 +000000000 00:40:38.528 53%
                    
MODULE              SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
------------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
bq_imx_stmt_iso_v02                                2116       4003 ON CPU               2024/06/12 14:59:11  2024/06/12 15:39:50        1932              8976829 +000000000 00:40:38.528 84%
bq_imx_stmt_iso_v02                                2116       4003 db file sequential r 2024/06/12 14:59:21  2024/06/12 15:39:33         296               458140 +000000000 00:40:11.529 13%
bq_imx_stmt_iso_v02 6s640d4hvvj05 1244372466       2116       4003 db file parallel rea 2024/06/12 15:00:28  2024/06/12 15:39:18          69                 3048 +000000000 00:38:49.497 3%
bq_imx_stmt_iso_v02                        0       2116       4003 log file sync        2024/06/12 15:06:08  2024/06/12 15:36:46          10                      +000000000 00:30:37.439 0%
                    
MODULE              SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
------------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
bq_imx_stmt_iso_v02 6s640d4hvvj05 1244372466       2116       4003                      2024/06/12 14:59:21  2024/06/12 15:39:33         599                 3107 +000000000 00:40:11.529 26%
bq_imx_stmt_iso_v02 cba3bu200d0s4 1894419433       2116       4003 ON CPU               2024/06/12 14:59:12  2024/06/12 15:39:46         486                  262 +000000000 00:40:33.528 21%
bq_imx_stmt_iso_v02 0wtgby70z9tpb 1868996192       2116       4003 ON CPU               2024/06/12 14:59:14  2024/06/12 15:39:49         448                  262 +000000000 00:40:34.530 19%
bq_imx_stmt_iso_v02 18yarjkpsq7h8 1593223865       2116       4003 ON CPU               2024/06/12 14:59:16  2024/06/12 15:39:50         436                  262 +000000000 00:40:33.531 19%

-- on PROD V8
INSTANCE_NUMBER SQL_ID            ELAPSED MAX_WAIT_ON     PC_OF  WAIT_TIME            GETS      READS       ROWS  ELAP/EXEC       GETS/EXEC READS/EXEC  ROWS/EXEC       EXEC PLAN_HASH_VALUE PERIOD
--------------- ------------- ----------- --------------- ----- ---------- --------------- ---------- ---------- ---------- --------------- ---------- ---------- ---------- --------------- ---------------
              1 0wtgby70z9tpb          36 IO              51%    16.506593         3758802     197809         19       1.88          197832      10411          1         19      1868996192 2024/06/13 10
              1 cba3bu200d0s4          53 IO              70%    30.570254         4425375     232737        652       2.77          232914   12249.32      34.32         19      1894419433 2024/06/13 10

-- on PROD V9
INSTANCE_NUMBER SQL_ID            ELAPSED MAX_WAIT_ON     PC_OF  WAIT_TIME            GETS      READS       ROWS  ELAP/EXEC       GETS/EXEC READS/EXEC  ROWS/EXEC       EXEC PLAN_HASH_VALUE PERIOD
--------------- ------------- ----------- --------------- ----- ---------- --------------- ---------- ---------- ---------- --------------- ---------- ---------- ---------- --------------- ---------------
              1 0wtgby70z9tpb         326 CPU             90%   102.863122        49682563     271465        183       1.78          271489    1483.42          1        183      1868996192 2024/06/13 12
              1 6s640d4hvvj05         401 IO              83%   292.342352        67639341     342541       1806        .22           37453     189.67          1       1806      1244372466 2024/06/13 12
              1 cba3bu200d0s4         351 CPU             81%   118.117282        42604851     232741       1887       1.92          232813    1271.81      10.31        183      1894419433 2024/06/13 12

SQL_ID           SNAP_ID INSTANCE_NUMBER NAME                   POSITION DUP_POSITION DATATYPE_STRING      VALUE_STRING                             INTERVAL
------------- ---------- --------------- -------------------- ---------- ------------ -------------------- ---------------------------------------- -----------------------
0wtgby70z9tpb      77865               1 :INTERFACENAME                1              VARCHAR2(128)        bq_imx_stmt_iso_v02                      2024/06/13 12
6s640d4hvvj05      77865               1 :B2                           1              VARCHAR2(2000)       4466331545-0000010                       2024/06/13 12
6s640d4hvvj05      77865               1 :B1                           2              NUMBER               2527                                     2024/06/13 12
cba3bu200d0s4      77865               1 :B4                           1              NUMBER                                                        2024/06/13 12
cba3bu200d0s4      77865               1 :B3                           2              VARCHAR2(32)         02                                       2024/06/13 12
cba3bu200d0s4      77865               1 :B2                           3              VARCHAR2(128)        bq_imx_stmt_iso_v02                      2024/06/13 12
cba3bu200d0s4      77865               1 :B1                           4              DATE                 06/13/2024 11:53:38                      2024/06/13 12



-- 6s640d4hvvj05 

Plan hash value: 1244372466
-----------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                              | Name                 | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  |
-----------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                       |                      |      1 |        |    34 (100)|      1 |00:00:00.33 |     107K|     10 |
|   1 |  SORT AGGREGATE                        |                      |      1 |      1 |            |      1 |00:00:00.33 |     107K|     10 |
|   2 |   NESTED LOOPS                         |                      |      1 |      1 |    34   (0)|      0 |00:00:00.33 |     107K|     10 |
|   3 |    NESTED LOOPS                        |                      |      1 |   9478 |    34   (0)|    249K|00:00:00.05 |    3947 |      0 |
|   4 |     TABLE ACCESS BY INDEX ROWID BATCHED| G_LOTCOLL            |      1 |    677 |     7   (0)|    851 |00:00:00.01 |     856 |      0 |
|*  5 |      INDEX RANGE SCAN                  | LOTCOLL_REFCPTBQ_IDX |      1 |    677 |     1   (0)|    851 |00:00:00.01 |       5 |      0 |
|*  6 |     INDEX RANGE SCAN                   | NAM_DTLOT            |    851 |     14 |     1   (0)|    249K|00:00:00.03 |    3091 |      0 |
|*  7 |    TABLE ACCESS BY INDEX ROWID         | NAM_COLLECTE         |    249K|      1 |     1   (0)|      0 |00:00:00.26 |     103K|     10 |
-----------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   5 - access("LOT"."REFCPTBQ"=:B1)
   6 - access("NAM"."DTLOT"="LOT"."DTLOT")
   7 - filter("NAM"."MESSAGE_ID"=:B2)


-- cba3bu200d0s4

Plan hash value: 1894419433
-------------------------------------------------------------------------------------------------------------
| Id  | Operation          | Name            | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers |
-------------------------------------------------------------------------------------------------------------
|   0 | UPDATE STATEMENT   |                 |      1 |        | 51346 (100)|      0 |00:00:01.67 |     232K|
|   1 |  UPDATE            | BUF_STD_ENTRYTR |      1 |        |            |      0 |00:00:01.67 |     232K|
|*  2 |   TABLE ACCESS FULL| BUF_STD_ENTRYTR |      1 |      1 | 51346   (1)|      0 |00:00:01.67 |     232K|
-------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   2 - filter(("FILE_ID" IS NULL AND "SCHEMATYPE"=:B3 AND "INTERFACE"=:B2 AND "DT_CREATION_DT">=:B1))



-- 0wtgby70z9tpb

Plan hash value: 1868996192
------------------------------------------------------------------------------------
| Id  | Operation         | Name           | Rows  | Bytes | Cost (%CPU)| Time     |
------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT  |                |       |       | 60233 (100)|          |
|   1 |  TABLE ACCESS FULL| T_REPRISE_LIST |   563K|    20M| 60233   (2)| 00:00:03 |
------------------------------------------------------------------------------------


-- 18yarjkpsq7h8

Plan hash value: 1593223865
-------------------------------------------------------------------------------------
| Id  | Operation          | Name           | Rows  | Bytes | Cost (%CPU)| Time     |
-------------------------------------------------------------------------------------
|   0 | DELETE STATEMENT   |                |       |       | 60236 (100)|          |
|   1 |  DELETE            | T_REPRISE_LIST |       |       |            |          |
|   2 |   TABLE ACCESS FULL| T_REPRISE_LIST |   563K|    53M| 60236   (2)| 00:00:03 |
-------------------------------------------------------------------------------------
*/
/********************************OLD Metrics***************************************/

/********************************New SQL*******************************************/

-- No changes in the SQL texts.

/********************************New SQL*******************************************/
/********************************New Metrics***************************************/
/*
-- 6s640d4hvvj05

DROP INDEX TEST_DD_INDEX;
CREATE INDEX TEST_DD_INDEX ON NAM_COLLECTE(MESSAGE_ID) parallel 4;
ALTER INDEX TEST_DD_INDEX NOPARALLEL;
exec DBMS_STATS.GATHER_INDEX_STATS(ownname => user, indname => 'TEST_DD_INDEX', ESTIMATE_PERCENT => dbms_stats.auto_sample_size, degree => 2, force => true, no_invalidate => false);


Plan hash value: 1552248832
----------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                              | Name          | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  |
----------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                       |               |      1 |        |     2 (100)|      1 |00:00:00.01 |      12 |      6 |
|   1 |  SORT AGGREGATE                        |               |      1 |      1 |            |      1 |00:00:00.01 |      12 |      6 |
|   2 |   NESTED LOOPS                         |               |      1 |      1 |     2   (0)|      0 |00:00:00.01 |      12 |      6 |
|   3 |    NESTED LOOPS                        |               |      1 |      1 |     2   (0)|      2 |00:00:00.01 |      10 |      4 |
|   4 |     TABLE ACCESS BY INDEX ROWID BATCHED| NAM_COLLECTE  |      1 |      1 |     1   (0)|      2 |00:00:00.01 |       4 |      0 |
|*  5 |      INDEX RANGE SCAN                  | TEST_DD_INDEX |      1 |      1 |     1   (0)|      2 |00:00:00.01 |       2 |      0 |
|*  6 |     INDEX UNIQUE SCAN                  | G_LOTCOLL_PK  |      2 |      1 |     1   (0)|      2 |00:00:00.01 |       6 |      4 |
|*  7 |    TABLE ACCESS BY INDEX ROWID         | G_LOTCOLL     |      2 |      1 |     1   (0)|      0 |00:00:00.01 |       2 |      2 |
----------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   5 - access("NAM"."MESSAGE_ID"=:B2)
   6 - access("NAM"."DTLOT"="LOT"."DTLOT")
   7 - filter("LOT"."REFCPTBQ"=:B1)


-- cba3bu200d0s4

DROP INDEX TEST_DD_INDEX;
CREATE INDEX TEST_DD_INDEX ON BUF_STD_ENTRYTR(INTERFACE, SCHEMATYPE, DT_CREATION_DT) parallel 4;
ALTER INDEX TEST_DD_INDEX NOPARALLEL;
exec DBMS_STATS.GATHER_INDEX_STATS(ownname => user, indname => 'TEST_DD_INDEX', ESTIMATE_PERCENT => dbms_stats.auto_sample_size, degree => 2, force => true, no_invalidate => false);


Plan hash value: 2957579407
---------------------------------------------------------------------------------------------------------------------
| Id  | Operation                            | Name            | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   |
---------------------------------------------------------------------------------------------------------------------
|   0 | UPDATE STATEMENT                     |                 |      1 |        |     1 (100)|      0 |00:00:00.01 |
|   1 |  UPDATE                              | BUF_STD_ENTRYTR |      1 |        |            |      0 |00:00:00.01 |
|*  2 |   TABLE ACCESS BY INDEX ROWID BATCHED| BUF_STD_ENTRYTR |      1 |      1 |     1   (0)|      0 |00:00:00.01 |
|*  3 |    INDEX RANGE SCAN                  | TEST_DD_INDEX   |      1 |     47 |     1   (0)|      0 |00:00:00.01 |
---------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   2 - filter("FILE_ID" IS NULL)
   3 - access("INTERFACE"=:B2 AND "SCHEMATYPE"=:B3 AND "DT_CREATION_DT">=:B1 AND "DT_CREATION_DT" IS NOT
              NULL)

*/
/********************************New Metrics***************************************/

/********************************Index statistics**********************************/

/********************************Other SQLs****************************************/          
/*

*/ 
/********************************Other SQLs****************************************/              
