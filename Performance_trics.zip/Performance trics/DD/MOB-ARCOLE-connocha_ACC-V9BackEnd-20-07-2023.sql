/********************************************************************************
*********       E-mail subject: MOBARCWEB-613
*********             Instance: connocha ACC
*********          Description: 
Problem:
Slow query on connocha ACC.

Analysis:
On 20/07/2023 the provided query was slow.
The problem was that in this case the bind for column refindividu was 'INT00000' and 
oracle use inappropriate execution plan and start from table t_intervenants instead of table g_dossier.


Suggestion:
Please add hint as it is shown in the New SQL section below to navigate oracle to start from table g_dossier.


*********               SQL_ID: 
*********      Program/Package: V9 BackEnd
*********              Request: Lachezar Parvov
*********               Author: Dimitar Dimitrov
********* Received e-mail date: 20/07/2023
*********      Resolution date: 20/07/2023
*********  Trace old file here: \\epox\specifs\performance\tmp\
*********  Trace new file here:
***********************************************************************************/

/********************************OLD SQL*******************************************/
var bind1 varchar2(32);
exec :bind1 := 'INT00000'
var bind2 varchar2(32);
exec :bind2 := '1.140242'
var bind3 number;
exec :bind3 := 2001
var bind4 number;
exec :bind4 := 1

SELECT *
  FROM (SELECT /*+ first_rows(2001)*/
         foo.*, ROWNUM rnum
          FROM (SELECT dueDate       dueDate,
                       customerCode  customerCode,
                       newDate       newDate,
                       invoiceId     invoiceId,
                       numberInvoice numberInvoice,
                       openAmount    openAmount,
                       fullAmount    fullAmount,
                       invCaseRef    invCaseRef
                  FROM (SELECT NVL(fi.libelle_100_15, fi.refelem) numberInvoice,
                               d.ancrefdoss customerCode,
                               fi.mt_ouvert_mvt openAmount,
                               fi.montant_mvt fullAmount,
                               fi.dt_emis_dt newDate,
                               fi.dtdebut_dt dueDate,
                               fi.refelem invoiceId,
                               fi.devise_mvt,
                               fi.refdoss invCaseRef
                          FROM g_elemfi fi, g_dossier d, t_intervenants t
                         WHERE fi.refdoss = t.refdoss
                           AND t.refindividu = :bind1
                           AND t.reftype = 'CL'
                           AND fi.montant_dos > 0
                           AND fi.mt_ouvert_mvt + 0 > 0
                           AND fi.dtannul IS NULL
                           AND fi.dttraite IS NULL
                           AND d.refdoss = t.refdoss
                           AND d.ancrefdoss LIKE :bind2)
                 WHERE 1 = 1
                 ORDER BY customerCode,
                          openAmount,
                          fullAmount,
                          newDate,
                          dueDate,
                          numberInvoice) foo
         WHERE ROWNUM <= :bind3)
 WHERE 1 = 1
   AND rnum >= :bind4;
/********************************OLD SQL*******************************************/
/********************************OLD Metrics***************************************/
/*
Plan hash value: 2834054458
----------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                          | Name                     | Starts | E-Rows | A-Rows |   A-Time   | Buffers | Reads  |
----------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                   |                          |      1 |        |      0 |00:00:48.00 |    3993K|    801K|
|*  1 |  VIEW                              |                          |      1 |      3 |      0 |00:00:48.00 |    3993K|    801K|
|*  2 |   COUNT STOPKEY                    |                          |      1 |        |      0 |00:00:48.00 |    3993K|    801K|
|   3 |    VIEW                            |                          |      1 |      3 |      0 |00:00:48.00 |    3993K|    801K|
|*  4 |     SORT ORDER BY STOPKEY          |                          |      1 |      3 |      0 |00:00:48.00 |    3993K|    801K|
|   5 |      NESTED LOOPS                  |                          |      1 |      3 |      0 |00:00:48.00 |    3993K|    801K|
|   6 |       NESTED LOOPS                 |                          |      1 |     33 |    116 |00:00:47.99 |    3993K|    801K|
|   7 |        NESTED LOOPS                |                          |      1 |      1 |      1 |00:00:47.99 |    3993K|    801K|
|*  8 |         INDEX RANGE SCAN           | INT_INDIV                |      1 |      1 |   8818K|00:00:03.71 |   44518 |  44516 |
|*  9 |         TABLE ACCESS BY INDEX ROWID| G_DOSSIER                |   8818K|      1 |      1 |00:00:40.21 |    3948K|    756K|
|* 10 |          INDEX UNIQUE SCAN         | DOS_REFDOSS              |   8818K|      1 |   8818K|00:00:09.25 |     308K|  25724 |
|* 11 |        INDEX RANGE SCAN            | ELEMFI_REFDOSS_GRP_ANSAF |      1 |     33 |    116 |00:00:00.01 |       5 |      4 |
|* 12 |       TABLE ACCESS BY INDEX ROWID  | G_ELEMFI                 |    116 |     16 |      0 |00:00:00.01 |     117 |    113 |
----------------------------------------------------------------------------------------------------------------------------------

Predicate Information (identified by operation id):
---------------------------------------------------
   1 - filter("RNUM">=:BIND4)
   2 - filter(ROWNUM<=:BIND3)
   4 - filter(ROWNUM<=:BIND3)
   8 - access("T"."REFINDIVIDU"=:BIND1 AND "T"."REFTYPE"='CL')
   9 - filter("D"."ANCREFDOSS" LIKE :BIND2)
  10 - access("D"."REFDOSS"="T"."REFDOSS")
  11 - access("FI"."REFDOSS"="T"."REFDOSS")
  12 - filter(("FI"."MONTANT_DOS">0 AND "FI"."DTANNUL" IS NULL AND "FI"."MT_OUVERT_MVT"+0>0 AND "FI"."DTTRAITE" IS NULL))

*/
/********************************OLD Metrics***************************************/

/********************************New SQL*******************************************/
var bind1 varchar2(32);
exec :bind1 := 'INT00000'
var bind2 varchar2(32);
exec :bind2 := '1.140242'
var bind3 number;
exec :bind3 := 2001
var bind4 number;
exec :bind4 := 1

SELECT *
  FROM (SELECT /*+ first_rows(2001)*/
         foo.*, ROWNUM rnum
          FROM (SELECT dueDate       dueDate,
                       customerCode  customerCode,
                       newDate       newDate,
                       invoiceId     invoiceId,
                       numberInvoice numberInvoice,
                       openAmount    openAmount,
                       fullAmount    fullAmount,
                       invCaseRef    invCaseRef
                  FROM (SELECT /*+ leading(d)*/ NVL(fi.libelle_100_15, fi.refelem) numberInvoice,
                               d.ancrefdoss customerCode,
                               fi.mt_ouvert_mvt openAmount,
                               fi.montant_mvt fullAmount,
                               fi.dt_emis_dt newDate,
                               fi.dtdebut_dt dueDate,
                               fi.refelem invoiceId,
                               fi.devise_mvt,
                               fi.refdoss invCaseRef
                          FROM g_elemfi fi, g_dossier d, t_intervenants t
                         WHERE fi.refdoss = t.refdoss
                           AND t.refindividu = :bind1
                           AND t.reftype = 'CL'
                           AND fi.montant_dos > 0
                           AND fi.mt_ouvert_mvt + 0 > 0
                           AND fi.dtannul IS NULL
                           AND fi.dttraite IS NULL
                           AND d.refdoss = t.refdoss
                           AND d.ancrefdoss LIKE :bind2)
                 WHERE 1 = 1
                 ORDER BY customerCode,
                          openAmount,
                          fullAmount,
                          newDate,
                          dueDate,
                          numberInvoice) foo
         WHERE ROWNUM <= :bind3)
 WHERE 1 = 1
   AND rnum >= :bind4;

/********************************New SQL*******************************************/
/********************************New Metrics***************************************/
/*
Plan hash value: 1776212870
------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                  | Name                     | Starts | E-Rows | A-Rows |   A-Time   | Buffers | Reads  |
------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                           |                          |      1 |        |      0 |00:00:00.01 |     128 |    120 |
|*  1 |  VIEW                                      |                          |      1 |      3 |      0 |00:00:00.01 |     128 |    120 |
|*  2 |   COUNT STOPKEY                            |                          |      1 |        |      0 |00:00:00.01 |     128 |    120 |
|   3 |    VIEW                                    |                          |      1 |      3 |      0 |00:00:00.01 |     128 |    120 |
|*  4 |     SORT ORDER BY STOPKEY                  |                          |      1 |      3 |      0 |00:00:00.01 |     128 |    120 |
|   5 |      NESTED LOOPS                          |                          |      1 |      3 |      0 |00:00:00.01 |     128 |    120 |
|   6 |       NESTED LOOPS                         |                          |      1 |     33 |    116 |00:00:00.01 |      12 |      8 |
|   7 |        NESTED LOOPS                        |                          |      1 |      1 |      1 |00:00:00.01 |       7 |      6 |
|   8 |         TABLE ACCESS BY INDEX ROWID BATCHED| G_DOSSIER                |      1 |      1 |      1 |00:00:00.01 |       4 |      3 |
|*  9 |          INDEX RANGE SCAN                  | DOS_ANCREFDOSS           |      1 |      1 |      1 |00:00:00.01 |       3 |      3 |
|* 10 |         INDEX RANGE SCAN                   | INT_REFDOSS              |      1 |      1 |      1 |00:00:00.01 |       3 |      3 |
|* 11 |        INDEX RANGE SCAN                    | ELEMFI_REFDOSS_GRP_ANSAF |      1 |     33 |    116 |00:00:00.01 |       5 |      2 |
|* 12 |       TABLE ACCESS BY INDEX ROWID          | G_ELEMFI                 |    116 |     16 |      0 |00:00:00.01 |     116 |    112 |
------------------------------------------------------------------------------------------------------------------------------------------

Predicate Information (identified by operation id):
---------------------------------------------------
   1 - filter("RNUM">=:BIND4)
   2 - filter(ROWNUM<=:BIND3)
   4 - filter(ROWNUM<=:BIND3)
   9 - access("D"."ANCREFDOSS" LIKE :BIND2)
       filter("D"."ANCREFDOSS" LIKE :BIND2)
  10 - access("D"."REFDOSS"="T"."REFDOSS" AND "T"."REFTYPE"='CL' AND "T"."REFINDIVIDU"=:BIND1)
  11 - access("FI"."REFDOSS"="T"."REFDOSS")
  12 - filter(("FI"."MONTANT_DOS">0 AND "FI"."DTANNUL" IS NULL AND "FI"."MT_OUVERT_MVT"+0>0 AND "FI"."DTTRAITE" IS NULL))

*/
/********************************New Metrics***************************************/

/********************************Index statistics**********************************/

/********************************Other SQLs****************************************/          
/*

*/ 
/********************************Other SQLs****************************************/              
