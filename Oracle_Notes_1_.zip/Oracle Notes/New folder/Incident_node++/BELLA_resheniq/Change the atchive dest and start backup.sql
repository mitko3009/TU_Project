﻿==============================================================================

######## Change the atchive dest and start backup #####

==============================================================================


sv364:#/root# ps -ef | grep pmon
  oracle  7611     1  0  Jun 29  ?        59:19 ora_pmon_DIAP
    root 27648 27606  0 23:17:05 pts/0     0:00 grep pmon


sv364:#/root# bdf /oracle/DIAP/oraarch
Filesystem          kbytes    used   avail %used Mounted on
/dev/vg07/lvoracleDIAPoraarch
                   35848192 31645419 4001510   89% /oracle/DIAP/oraarch



sv364:#/root# su - oracle

##### Set environment ####


oracle@sv364 @ (/home/oracle) # sqlplus / as sysdba


SQL> show parameter unique

NAME                                 TYPE        VALUE
------------------------------------ ----------- ------------------------------
db_unique_name                       string      DIAP


###### ###Show me the Backup pieces###

SET LINESIZE 400
SET PAGESIZE 9999 
COLUMN bs_key FORMAT 9999 HEADING 'BS|Key'
COLUMN piece# FORMAT 99999 HEADING 'Piece|#'
COLUMN copy# FORMAT 9999 HEADING 'Copy|#'
COLUMN bp_key FORMAT 9999 HEADING 'BP|Key'
COLUMN status FORMAT a9 HEADING 'Status'
COLUMN handle FORMAT a65 HEADING 'Handle'
COLUMN start_time FORMAT a17 HEADING 'Start|Time'
COLUMN completion_time FORMAT a17 HEADING 'End|Time'
COLUMN elapsed_seconds FORMAT 999,999 HEADING 'Elapsed|Seconds'
COLUMN deleted FORMAT a8 HEADING 'Deleted?'
BREAK ON bs_key
prompt
prompt Available backup pieces contained in the control file.
prompt Includes available and expired backup sets.
prompt 
SELECT
bs.recid bs_key
, bp.piece# piece#
, bp.copy# copy#
, bp.recid bp_key
, DECODE( status
, 'A', 'Available'
, 'D', 'Deleted'
, 'X', 'Expired') status
, handle handle
, TO_CHAR(bp.start_time, 'mm/dd/yy HH24:MI:SS') start_time
, TO_CHAR(bp.completion_time, 'mm/dd/yy HH24:MI:SS') completion_time
, bp.elapsed_seconds elapsed_seconds
FROM
v$backup_set bs
, v$backup_piece bp
WHERE
bs.set_stamp = bp.set_stamp
AND bs.set_count = bp.set_count
AND bp.status IN ('A', 'X')
ORDER BY
bs.recid
, piece#
/ 


   BS  Piece  Copy    BP                                                                             Start             End                Elapsed
  Key      #     #   Key Status    Handle                                                            Time              Time               Seconds
----- ------ ----- ----- --------- ----------------------------------------------------------------- ----------------- ----------------- --------
#####      1     1 ##### Available BCK_DC2_ARCH_pkDIPdbadm_DIAP<DIAP_251088:1015099629:1>.al         07/31/19 20:07:09 07/31/19 20:11:08      239
#####      1     1 ##### Available c-1713899410-20190731-11                                          07/31/19 20:11:19 07/31/19 20:11:21        2
#####      1     1 ##### Available BCK_DC2_ARCH_pkDIPdbadm_DIAP<DIAP_251090:1015100295:1>.al         07/31/19 20:18:15 07/31/19 20:21:17      182
#####      1     1 ##### Available c-1713899410-20190731-12                                          07/31/19 20:21:22 07/31/19 20:21:24        2
#####      1     1 ##### Available BCK_DC2_ARCH_pkDIPdbadm_DIAP<DIAP_251092:1015103897:1>.al         07/31/19 21:18:18 07/31/19 21:23:41      323
#####      1     1 ##### Available c-1713899410-20190731-13                                          07/31/19 21:23:47 07/31/19 21:23:50        3

1009 filas seleccionadas.


SQL> exit


oracle@sv364 @ (/home/oracle) # locate omnib
oracle@sv364 @ (/home/oracle) # which omnib

oracle@sv364 @ (/home/oracle) # nohup /opt/omni/bin/omnib -Oracle8 BCK_DC2_ARCH_pkDIPdbadm_DIAP &
                ### или гледаме crontab -l или ESL ###
				
[1]     915
oracle@sv364 @ (/home/oracle) # Sending output to nohup.out


oracle@sv364 @ (/home/oracle) # sql


SQL> set lines 400

SQL> show parameter reco

NAME                                 TYPE        VALUE
------------------------------------ ----------- ------------------------------
control_file_record_keep_time        integer     7
db_recovery_file_dest                string
db_recovery_file_dest_size           big integer 0
db_unrecoverable_scn_tracking        boolean     TRUE
recovery_parallelism                 integer     0
SQL> archive log list
Modo log de la base de datos              Modo de Archivado
Archivado automático             Activado
Destino del archivo            /oracle/DIAP/oraarch
Secuencia de log en línea más antigua     545615
Siguiente secuencia de log para archivar   545646
Secuencia de log actual           545646


SQL> !bdf /oracle/DIAP/oraarch
Filesystem          kbytes    used   avail %used Mounted on
/dev/vg07/lvoracleDIAPoraarch
                   35848192 35818780   29412  100% /oracle/DIAP/oraarch



SQL> !bdf
Filesystem          kbytes    used   avail %used Mounted on                   #### Проверяваме коя оракълска директория има най-свободно място за да прехвърлим дестинейшъна ###
/dev/vg00/lvol3    2097152  964504 1124000   46% /
/dev/vg00/lvol1    2097152  598536 1486952   29% /stand
/dev/vg00/lvol9    9437184 7918128 1507376   84% /var
/dev/vg00/lvol7    6291456 2485159 3568512   41% /var/adm/crash
/dev/vg00/lvol6    8388608 3517704 4832992   42% /usr
/dev/vg00/lvol5    2097152  962454 1063838   47% /tmp
/dev/vg01/lvproducts
                   1048576   19744  964656    2% /products
/dev/vg01/lvvtom   1048576   17749  966408    2% /products/vtom
/dev/vg01/lvtools  1048576   36209  949215    4% /products/tools
/dev/vg01/lvomni   2097152 1142613  894882   56% /products/omni
/dev/vg01/lvlogs   1048576   17749  966408    2% /products/logs
/dev/vg01/lvapps   1048576   17749  966408    2% /products/apps
/dev/vg01/lvovo    2097152  923832 1100071   46% /products/OV
/dev/vgoracle/lvoracle
                   10420224 6429424 3974728   62% /oracle
/dev/vg00/lvol4    8388608 6958112 1419336   83% /opt
/dev/vg00/lvol8    2097152 1377400  714184   66% /home
/dev/vg03/lvoracleadmin
                   16777216 1776400 14895456   11% /oracle/admin
/dev/vg03/lvtransfer
                   1048576   17672 1022864    2% /transfer
/dev/vg03/lvstar   2097152   18992 2062056    1% /products/star
/dev/vg03/lvoracle11204
                   19922944 14367078 5513826   72% /oracle/11204
/dev/vg04/lvoracleDIAPoriglogA
                   5177344 4012479 1092065   79% /oracle/DIAP/origlogA
/dev/vg04/lvoracleDIAPoriglogB
                   5177344 4934106  228039   96% /oracle/DIAP/origlogB
/dev/vg05/lvoracleDIAPmirrlogA
                   5177344 4934106  228039   96% /oracle/DIAP/mirrlogA
/dev/vg05/lvoracleDIAPmirrlogB
                   5177344 4934106  228039   96% /oracle/DIAP/mirrlogB
/dev/vg07/lvoracleDIAPoraarch
                   35848192 35818780   29412  100% /oracle/DIAP/oraarch
/dev/vg08/lvoracleDIAPoradbf7
                   902692864 843977600 58256672   94% /oracle/DIAP/oradbf7
/dev/vg09/lvoracleDIAPoradbf8
                   1570766848 1355362024 213722080   86% /oracle/DIAP/oradbf8
/dev/vg14/lvoracleDIAPoradbf10
                   209715200 161934433 44794473   78% /oracle/DIAP/oradbf10
/dev/vg14/lvoracleDIAPoradbf11
                   246284288 209201394 34765219   86% /oracle/DIAP/oradbf11
/dev/vg14/lvoracleDIAPoradbf12
                   492601344 434405743 54558380   89% /oracle/DIAP/oradbf12
/dev/vg15/lvoracleDIAPoradbf13
                   974946304 884894107 84424052   91% /oracle/DIAP/oradbf13
/dev/vg15/lvoracleDIAPoradbf14
                   262078464 223694632 35984846   86% /oracle/DIAP/oradbf14
/dev/vg15/lvoracleDIAPoradbf15
                   1341882368 1069538500 255322497   81% /oracle/DIAP/oradbf15
/dev/vg15/lvoracleDIAPoradbf16
                   156794880 132461862 22812330   85% /oracle/DIAP/oradbf16




SQL> show parameter dest

NAME                                 TYPE        VALUE
------------------------------------ ----------- ------------------------------
audit_file_dest                      string      /oracle/11204/rdbms/audit
background_dump_dest                 string      /oracle/admin/diag/rdbms/diap/
                                                 DIAP/trace
core_dump_dest                       string      /oracle/admin/diag/rdbms/diap/
                                                 DIAP/cdump
cursor_bind_capture_destination      string      memory+disk
db_create_file_dest                  string
db_create_online_log_dest_1          string
db_create_online_log_dest_2          string
db_create_online_log_dest_3          string
db_create_online_log_dest_4          string
db_create_online_log_dest_5          string
db_recovery_file_dest                string
db_recovery_file_dest_size           big integer 0
diagnostic_dest                      string      /oracle/admin
log_archive_dest                     string
log_archive_dest_state_1             string      enable
log_archive_dest_state_10            string      enable
log_archive_dest_state_11            string      enable
log_archive_dest_state_12            string      enable
log_archive_dest_state_13            string      enable
log_archive_dest_state_14            string      enable
log_archive_dest_state_15            string      enable
log_archive_dest_state_16            string      enable
log_archive_dest_state_17            string      enable
log_archive_dest_state_18            string      enable
log_archive_dest_state_19            string      enable
log_archive_dest_state_2             string      enable
log_archive_dest_state_20            string      enable
log_archive_dest_state_21            string      enable
log_archive_dest_state_22            string      enable
log_archive_dest_state_23            string      enable
log_archive_dest_state_24            string      enable
log_archive_dest_state_25            string      enable
log_archive_dest_state_26            string      enable
log_archive_dest_state_27            string      enable
log_archive_dest_state_28            string      enable
log_archive_dest_state_29            string      enable
log_archive_dest_state_3             string      enable
log_archive_dest_state_30            string      enable
log_archive_dest_state_31            string      enable
log_archive_dest_state_4             string      enable
log_archive_dest_state_5             string      enable
log_archive_dest_state_6             string      enable
log_archive_dest_state_7             string      enable
log_archive_dest_state_8             string      enable
log_archive_dest_state_9             string      enable
log_archive_dest_1                   string      LOCATION=/oracle/DIAP/oraarch
log_archive_dest_10                  string
log_archive_dest_11                  string
log_archive_dest_12                  string
log_archive_dest_13                  string
log_archive_dest_14                  string
log_archive_dest_15                  string
log_archive_dest_16                  string
log_archive_dest_17                  string
log_archive_dest_18                  string
log_archive_dest_19                  string
log_archive_dest_2                   string
log_archive_dest_20                  string
log_archive_dest_21                  string
log_archive_dest_22                  string
log_archive_dest_23                  string
log_archive_dest_24                  string
log_archive_dest_25                  string
log_archive_dest_26                  string
log_archive_dest_27                  string
log_archive_dest_28                  string
log_archive_dest_29                  string
log_archive_dest_3                   string
log_archive_dest_30                  string
log_archive_dest_31                  string
log_archive_dest_4                   string
log_archive_dest_5                   string
log_archive_dest_6                   string
log_archive_dest_7                   string
log_archive_dest_8                   string
log_archive_dest_9                   string
log_archive_duplex_dest              string
log_archive_min_succeed_dest         integer     1
standby_archive_dest                 string      ?/dbs/arch
user_dump_dest                       string      /oracle/admin/diag/rdbms/diap/
                                                 DIAP/trace



SQL> alter system set log_archive_dest_1='LOCATION=/oracle/DIAP/oradbf15';     ##### Сменяме деста като внимаваме във синтаксиса ####



SQL> alter system switch logfile ;                             #### Проверяваме дали свуитчва логове ###

Sistema modificado.

SQL> /

Sistema modificado.

SQL> /

Sistema modificado.



SQL> archive log list                                        #### Проверяваме архайв деста дали се е сменил ####

Modo log de la base de datos              Modo de Archivado
Archivado automático             Activado
Destino del archivo            /oracle/DIAP/oradbf15
Secuencia de log en línea más antigua     545623
Siguiente secuencia de log para archivar   545647
Secuencia de log actual           545654


oracle@sv364 @ (/home/oracle) # tail -100f nohup.out


oracle@sv364 @ (/home/oracle) # sql


###### LONG OPS ######

set lines 400
col TARGET for a15
col TARGET_DESC for a10
col UNITS for a10
col TIME_REMAINING for a20
col OPNAME for a35
col LAST_UPDATE_TIME for a20
col START_TIME for a20
SELECT inst_id,SID, SERIAL#,OPNAME, SQL_ID, to_char(START_TIME, 'YYYY/MON/DD HH24:MI:SS') "START_TIME",
to_char(LAST_UPDATE_TIME, 'YYYY/MON/DD HH24:MI:SS') "LAST_UPDATE_TIME",
TIME_REMAINING/60 as "remaining mins",
TARGET, TARGET_DESC, SOFAR,
TOTALWORK, UNITS, ROUND(SOFAR/TOTALWORK*100,2) "%_COMPLETE"
FROM GV$SESSION_LONGOPS
WHERE
TOTALWORK != 0
AND SOFAR <> TOTALWORK
order by START_TIME;






SQL> /

   INST_ID        SID    SERIAL# OPNAME                              SQL_ID        START_TIME           LAST_UPDATE_TIME     remaining mins TARGET          TARGET_DES      SOFAR  TOTALWORK UNITS      %_COMPLETE
---------- ---------- ---------- ----------------------------------- ------------- -------------------- -------------------- -------------- --------------- ---------- ---------- ---------- ---------- ----------
         1       1541      54017 Sort Output                         0pvfvdj4gx6hu 2019/AGO/01 00:12:20 2019/AGO/01 00:21:28     8,88333333                                  2904       5730 Blocks          50,68
         1        483      39733 RMAN: aggregate input               1k3u5np99ms4d 2019/JUL/31 21:45:21 2019/AGO/01 00:19:55     129,983333 33              backup      353715916  651188612 Blocks          54,32
         1         97      50547 RMAN: incremental datafile backup                 2019/JUL/31 21:45:28 2019/AGO/01 00:21:29     31,8666667 251094          Set Count    67603312   81410376 Blocks          83,04
         1        347      61905 RMAN: incremental datafile backup                 2019/JUL/31 21:45:29 2019/AGO/01 00:21:29     2607,51667 251095          Set Count     4594928   81398294 Blocks           5,64
         1        722      44695 RMAN: incremental datafile backup                 2019/JUL/31 21:45:33 2019/AGO/01 00:21:29     328,433333 251098          Set Count    26204592   81396998 Blocks          32,19
         1        937       1005 RMAN: incremental datafile backup                 2019/JUL/31 21:45:34 2019/AGO/01 00:21:28     1890,16667 251099          Set Count     6201968   81396142 Blocks           7,62
         1       1495      43489 RMAN: incremental datafile backup                 2019/JUL/31 21:45:35 2019/AGO/01 00:21:29         362,25 251100          Set Count    24490032   81395966 Blocks          30,09
         1       2142      48429 RMAN: incremental datafile backup                 2019/JUL/31 21:45:36 2019/AGO/01 00:21:29     36,6833333 251101          Set Count    65888942   81395710 Blocks          80,95

8 filas seleccionadas.



SQL> show parameter dest

NAME                                 TYPE        VALUE
------------------------------------ ----------- ------------------------------
audit_file_dest                      string      /oracle/11204/rdbms/audit
background_dump_dest                 string      /oracle/admin/diag/rdbms/diap/
                                                 DIAP/trace
core_dump_dest                       string      /oracle/admin/diag/rdbms/diap/
                                                 DIAP/cdump
cursor_bind_capture_destination      string      memory+disk
db_create_file_dest                  string
db_create_online_log_dest_1          string
db_create_online_log_dest_2          string
db_create_online_log_dest_3          string
db_create_online_log_dest_4          string
db_create_online_log_dest_5          string
db_recovery_file_dest                string
db_recovery_file_dest_size           big integer 0
diagnostic_dest                      string      /oracle/admin
log_archive_dest                     string
log_archive_dest_state_1             string      enable
log_archive_dest_state_10            string      enable
log_archive_dest_state_11            string      enable
log_archive_dest_state_12            string      enable
log_archive_dest_state_13            string      enable
log_archive_dest_state_14            string      enable
log_archive_dest_state_15            string      enable
log_archive_dest_state_16            string      enable
log_archive_dest_state_17            string      enable
log_archive_dest_state_18            string      enable
log_archive_dest_state_19            string      enable
log_archive_dest_state_2             string      enable
log_archive_dest_state_20            string      enable
log_archive_dest_state_21            string      enable
log_archive_dest_state_22            string      enable
log_archive_dest_state_23            string      enable
log_archive_dest_state_24            string      enable
log_archive_dest_state_25            string      enable
log_archive_dest_state_26            string      enable
log_archive_dest_state_27            string      enable
log_archive_dest_state_28            string      enable
log_archive_dest_state_29            string      enable
log_archive_dest_state_3             string      enable
log_archive_dest_state_30            string      enable
log_archive_dest_state_31            string      enable
log_archive_dest_state_4             string      enable
log_archive_dest_state_5             string      enable
log_archive_dest_state_6             string      enable
log_archive_dest_state_7             string      enable
log_archive_dest_state_8             string      enable
log_archive_dest_state_9             string      enable
log_archive_dest_1                   string      LOCATION=/oracle/DIAP/oradbf15
log_archive_dest_10                  string
log_archive_dest_11                  string
log_archive_dest_12                  string
log_archive_dest_13                  string
log_archive_dest_14                  string
log_archive_dest_15                  string
log_archive_dest_16                  string
log_archive_dest_17                  string
log_archive_dest_18                  string
log_archive_dest_19                  string
log_archive_dest_2                   string
log_archive_dest_20                  string
log_archive_dest_21                  string
log_archive_dest_22                  string
log_archive_dest_23                  string
log_archive_dest_24                  string
log_archive_dest_25                  string
log_archive_dest_26                  string
log_archive_dest_27                  string
log_archive_dest_28                  string
log_archive_dest_29                  string
log_archive_dest_3                   string
log_archive_dest_30                  string
log_archive_dest_31                  string
log_archive_dest_4                   string
log_archive_dest_5                   string
log_archive_dest_6                   string
log_archive_dest_7                   string
log_archive_dest_8                   string
log_archive_dest_9                   string
log_archive_duplex_dest              string
log_archive_min_succeed_dest         integer     1
standby_archive_dest                 string      ?/dbs/arch
user_dump_dest                       string      /oracle/admin/diag/rdbms/diap/
                                                 DIAP/trace
												 
												 
SQL> alter system set log_archive_dest_1='LOCATION=/oracle/DIAP/oraarch';

Sistema modificado.



SQL> alter system switch logfile ;

Sistema modificado.

SQL> /

Sistema modificado.

SQL> /

Sistema modificado.



SQL> show parameter dest

NAME                                 TYPE        VALUE
------------------------------------ ----------- ------------------------------
audit_file_dest                      string      /oracle/11204/rdbms/audit
background_dump_dest                 string      /oracle/admin/diag/rdbms/diap/
                                                 DIAP/trace
core_dump_dest                       string      /oracle/admin/diag/rdbms/diap/
                                                 DIAP/cdump
cursor_bind_capture_destination      string      memory+disk
db_create_file_dest                  string
db_create_online_log_dest_1          string
db_create_online_log_dest_2          string
db_create_online_log_dest_3          string
db_create_online_log_dest_4          string
db_create_online_log_dest_5          string
db_recovery_file_dest                string
db_recovery_file_dest_size           big integer 0
diagnostic_dest                      string      /oracle/admin
log_archive_dest                     string
log_archive_dest_state_1             string      enable
log_archive_dest_state_10            string      enable
log_archive_dest_state_11            string      enable
log_archive_dest_state_12            string      enable
log_archive_dest_state_13            string      enable
log_archive_dest_state_14            string      enable
log_archive_dest_state_15            string      enable
log_archive_dest_state_16            string      enable
log_archive_dest_state_17            string      enable
log_archive_dest_state_18            string      enable
log_archive_dest_state_19            string      enable
log_archive_dest_state_2             string      enable
log_archive_dest_state_20            string      enable
log_archive_dest_state_21            string      enable
log_archive_dest_state_22            string      enable
log_archive_dest_state_23            string      enable
log_archive_dest_state_24            string      enable
log_archive_dest_state_25            string      enable
log_archive_dest_state_26            string      enable
log_archive_dest_state_27            string      enable
log_archive_dest_state_28            string      enable
log_archive_dest_state_29            string      enable
log_archive_dest_state_3             string      enable
log_archive_dest_state_30            string      enable
log_archive_dest_state_31            string      enable
log_archive_dest_state_4             string      enable
log_archive_dest_state_5             string      enable
log_archive_dest_state_6             string      enable
log_archive_dest_state_7             string      enable
log_archive_dest_state_8             string      enable
log_archive_dest_state_9             string      enable
log_archive_dest_1                   string      LOCATION=/oracle/DIAP/oraarch
log_archive_dest_10                  string
log_archive_dest_11                  string
log_archive_dest_12                  string
log_archive_dest_13                  string
log_archive_dest_14                  string
log_archive_dest_15                  string
log_archive_dest_16                  string
log_archive_dest_17                  string
log_archive_dest_18                  string
log_archive_dest_19                  string
log_archive_dest_2                   string
log_archive_dest_20                  string
log_archive_dest_21                  string
log_archive_dest_22                  string
log_archive_dest_23                  string
log_archive_dest_24                  string
log_archive_dest_25                  string
log_archive_dest_26                  string
log_archive_dest_27                  string
log_archive_dest_28                  string
log_archive_dest_29                  string
log_archive_dest_3                   string
log_archive_dest_30                  string
log_archive_dest_31                  string
log_archive_dest_4                   string
log_archive_dest_5                   string
log_archive_dest_6                   string
log_archive_dest_7                   string
log_archive_dest_8                   string
log_archive_dest_9                   string
log_archive_duplex_dest              string
log_archive_min_succeed_dest         integer     1
standby_archive_dest                 string      ?/dbs/arch
user_dump_dest                       string      /oracle/admin/diag/rdbms/diap/
                                                 DIAP/trace






[1] +  Done(12)                nohup /opt/omni/bin/omnib -Oracle8 BCK_DC2_ARCH_pkDIPdbadm_DIAP &

 
oracle@sv364 @ (/home/oracle) # bdf /oracle/DIAP/oraarch
Filesystem          kbytes    used   avail %used Mounted on
/dev/vg07/lvoracleDIAPoraarch
                   35848192 2382237 31435769    7% /oracle/DIAP/oraarch
				   
				   


