/********************************************************************************
*********       E-mail subject: SUDFDEV-6610
*********             Instance: UAT_V9
*********          Description: 
Problem:
SQL 60dbq7nu1jh7c was considered as slow from a trace file on SUDF_UAT_V9.

Analysis:
The problem was that inappropriate execution plan was used for SQL 60dbq7nu1jh7c.
The solution here is to start execution from table G_DOSSIER and then to join table T_ECRDOS. This is the most selective way to access the data.
Also use column DTJOUR in table T_ECRDOS instead of column DTJOUR_DT, because column DTJOUR is indexed.

Suggestion:
Please modify the query as it is shown in the New SQL section below.

*********               SQL_ID: 60dbq7nu1jh7c
*********      Program/Package: ftr_consolidation.pck
*********              Request: Dimitare Ivanov
*********               Author: Dimitar Dimitrov
********* Received e-mail date: 11/01/2024
*********      Resolution date: 11/01/2024
*********  Trace old file here: \\epox\specifs\performance\tmp\
*********  Trace new file here:
***********************************************************************************/

/********************************OLD SQL*******************************************/

var B1 VARCHAR2(128);
exec :B1 := '1/10/2024';
var B2 VARCHAR2(128);
exec :B2 := '1/1/2024';
var B3 VARCHAR2(128);
exec :B3 := '0001010397';

SELECT NVL(ABS(SUM(T.MNT_DCPT)), 0)
  FROM V_ELEMFI V, 
       G_ELEMFI E, 
       T_ECRDOS T
 WHERE V.ABREV LIKE 'ODC%'
   AND E.TYPE = V.TYPE
   AND E.REFDOSS IN ( SELECT REFDOSS 
                        FROM G_DOSSIER 
                       WHERE REFLOT = :B3 )
   AND E.DTTRAITE_DT IS NULL
   AND T.REFELEM = E.REFELEM
   AND T.CODECR = V.COMMENTAIRE
   AND TRUNC(T.DTJOUR_DT) BETWEEN to_date(:B2, 'DD-MM-YY') AND to_date(:B1,'DD-MM-YY');
/********************************OLD SQL*******************************************/
/********************************OLD Metrics***************************************/
/*
Plan hash value: 896079178
------------------------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                 | Name                           | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  |
------------------------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                          |                                |      1 |        |    70 (100)|      1 |00:00:00.14 |    6463 |    222 |
|   1 |  SORT AGGREGATE                           |                                |      1 |      1 |            |      1 |00:00:00.14 |    6463 |    222 |
|*  2 |   FILTER                                  |                                |      1 |        |            |      0 |00:00:00.14 |    6463 |    222 |
|   3 |    NESTED LOOPS                           |                                |      1 |      1 |    70   (0)|      0 |00:00:00.14 |    6463 |    222 |
|   4 |     NESTED LOOPS                          |                                |      1 |    276 |    70   (0)|      0 |00:00:00.14 |    6463 |    222 |
|   5 |      NESTED LOOPS                         |                                |      1 |    276 |    59   (0)|      0 |00:00:00.14 |    6463 |    222 |
|   6 |       MERGE JOIN CARTESIAN                |                                |      1 |    163 |     2   (0)|   3282 |00:00:00.01 |      19 |     13 |
|   7 |        TABLE ACCESS BY INDEX ROWID BATCHED| V_ELEMFI                       |      1 |      1 |     1   (0)|      3 |00:00:00.01 |       3 |      1 |
|*  8 |         INDEX RANGE SCAN                  | AK_KEY_V_ELEMFI_ABREV          |      1 |      1 |     1   (0)|      3 |00:00:00.01 |       1 |      1 |
|   9 |        BUFFER SORT                        |                                |      3 |    163 |     1   (0)|   3282 |00:00:00.01 |      16 |     12 |
|* 10 |         INDEX RANGE SCAN                  | G_DOSSIER_RL_CD_RD_RF_IDX      |      1 |    163 |     1   (0)|   1094 |00:00:00.01 |      16 |     12 |
|* 11 |       TABLE ACCESS BY INDEX ROWID BATCHED | G_ELEMFI                       |   3282 |      2 |     1   (0)|      0 |00:00:00.13 |    6444 |    209 |
|* 12 |        INDEX RANGE SCAN                   | G_ELEMFI_DOS_TYP_FG02_CODE_IDX |   3282 |     92 |     1   (0)|      0 |00:00:00.13 |    6444 |    209 |
|* 13 |      INDEX RANGE SCAN                     | TECR_REFELEM                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 14 |     TABLE ACCESS BY INDEX ROWID           | T_ECRDOS                       |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
------------------------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   2 - filter(TO_DATE(:B1,'DD-MM-YY')>=TO_DATE(:B2,'DD-MM-YY'))
   8 - access("V"."ABREV" LIKE 'ODC%')
       filter("V"."ABREV" LIKE 'ODC%')
  10 - access("REFLOT"=:B3)
  11 - filter("E"."DTTRAITE_DT" IS NULL)
  12 - access("E"."REFDOSS"="REFDOSS" AND "E"."TYPE"="V"."TYPE")
  13 - access("T"."REFELEM"="E"."REFELEM")
  14 - filter(("T"."CODECR"="V"."COMMENTAIRE" AND "T"."MNT_DCPT" IS NOT NULL AND TRUNC(INTERNAL_FUNCTION("T"."DTJOUR_DT"))>=TO_DATE(:B2,'DD-MM-YY')
              AND TRUNC(INTERNAL_FUNCTION("T"."DTJOUR_DT"))<=TO_DATE(:B1,'DD-MM-YY')))
*/
/********************************OLD Metrics***************************************/

/********************************New SQL*******************************************/
SELECT /*+ leading(GD T E V) */
       NVL(ABS(SUM(T.MNT_DCPT)), 0)
  FROM V_ELEMFI V, 
       G_ELEMFI E, 
       T_ECRDOS T,
       G_DOSSIER GD
 WHERE GD.REFLOT = :B3 
   AND V.ABREV LIKE 'ODC%'
   AND E.TYPE = V.TYPE
   AND E.DTTRAITE_DT IS NULL
   AND T.REFELEM = E.REFELEM
   AND GD.REFDOSS = T.REFDOSS
   AND T.CODECR = V.COMMENTAIRE
   AND T.DTJOUR BETWEEN to_char(to_date(:B2, 'DD-MM-YY'), 'j')AND to_char(to_date(:B1, 'DD-MM-YY'), 'j');
select * from table(dbms_xplan.display_cursor(null, null, 'RUNSTATS_LAST +COST +HINT_REPORT')); 
/********************************New SQL*******************************************/
/********************************New Metrics***************************************/
/*
Plan hash value: 3730856312
----------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                 | Name                      | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers |
----------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                          |                           |      1 |        |    13 (100)|      1 |00:00:00.01 |    3170 |
|   1 |  SORT AGGREGATE                           |                           |      1 |      1 |            |      1 |00:00:00.01 |    3170 |
|*  2 |   FILTER                                  |                           |      1 |        |            |      0 |00:00:00.01 |    3170 |
|*  3 |    HASH JOIN                              |                           |      1 |      1 |    13   (0)|      0 |00:00:00.01 |    3170 |
|   4 |     TABLE ACCESS BY INDEX ROWID BATCHED   | V_ELEMFI                  |      1 |      1 |     1   (0)|      3 |00:00:00.01 |       3 |
|*  5 |      INDEX RANGE SCAN                     | AK_KEY_V_ELEMFI_ABREV     |      1 |      1 |     1   (0)|      3 |00:00:00.01 |       1 |
|   6 |     NESTED LOOPS                          |                           |      1 |    204 |    12   (0)|      0 |00:00:00.01 |    3167 |
|   7 |      NESTED LOOPS                         |                           |      1 |    204 |    12   (0)|      0 |00:00:00.01 |    3167 |
|   8 |       NESTED LOOPS                        |                           |      1 |    204 |     8   (0)|      0 |00:00:00.01 |    3167 |
|*  9 |        INDEX RANGE SCAN                   | G_DOSSIER_RL_CD_RD_RF_IDX |      1 |    163 |     1   (0)|   1094 |00:00:00.01 |      16 |
|* 10 |        TABLE ACCESS BY INDEX ROWID BATCHED| T_ECRDOS                  |   1094 |      1 |     1   (0)|      0 |00:00:00.01 |    3151 |
|* 11 |         INDEX RANGE SCAN                  | TECR_REFDOSS_DTJOUR       |   1094 |      1 |     1   (0)|      0 |00:00:00.01 |    3151 |
|* 12 |       INDEX UNIQUE SCAN                   | EFI_REFELEM               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 13 |      TABLE ACCESS BY INDEX ROWID          | G_ELEMFI                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
----------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   2 - filter(TO_NUMBER(TO_CHAR(TO_DATE(:B1,'DD-MM-YY'),'j'))>=TO_NUMBER(TO_CHAR(TO_DATE(:B2,'DD-MM-YY'),'j')))
   3 - access("E"."TYPE"="V"."TYPE" AND "T"."CODECR"="V"."COMMENTAIRE")
   5 - access("V"."ABREV" LIKE 'ODC%')
       filter("V"."ABREV" LIKE 'ODC%')
   9 - access("GD"."REFLOT"=:B3)
  10 - filter("T"."MNT_DCPT" IS NOT NULL)
  11 - access("GD"."REFDOSS"="T"."REFDOSS" AND "T"."DTJOUR">=TO_NUMBER(TO_CHAR(TO_DATE(:B2,'DD-MM-YY'),'j')) AND
              "T"."DTJOUR"<=TO_NUMBER(TO_CHAR(TO_DATE(:B1,'DD-MM-YY'),'j')))
  12 - access("T"."REFELEM"="E"."REFELEM")
  13 - filter("E"."DTTRAITE_DT" IS NULL)
*/
/********************************New Metrics***************************************/

/********************************Index statistics**********************************/

/********************************Other SQLs****************************************/          
/*

*/ 
/********************************Other SQLs****************************************/              
