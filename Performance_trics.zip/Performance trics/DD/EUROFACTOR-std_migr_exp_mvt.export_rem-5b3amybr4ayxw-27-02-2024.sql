/********************************************************************************
*********       E-mail subject: EFAGDEV-3170
*********             Instance: UAT1
*********          Description: 
Problem:
Slowness in REM on UAT1 on 24/02/2024 from 18:02:51 till 18:28:06.

Analysis:
The TOP SQL in std_migr_exp_mvt.export_rem for the provided period was 5b3amybr4ayxw. It took around 83% of the time.
The problem is that this SQL was using inappropriate hint, which confuse Oracle and use bad execution plan.


Suggestion:
Please change the hints as it is shown in the New SQL section below

*********               SQL_ID: 5b3amybr4ayxw
*********      Program/Package: std_migr_exp_mvt.export_rem 
*********              Request: Ognyan Tonev 
*********               Author: Dimitar Dimitrov
********* Received e-mail date: 27-02-2024
*********      Resolution date: 27-02-2024
*********  Trace old file here: \\epox\specifs\performance\tmp\
*********  Trace new file here:
***********************************************************************************/

/********************************OLD SQL*******************************************/
SELECT /*+ leading(CCD INTER CMPT ELEMFI FNC FACTURE CESSION)
                          use_nl(INTER CMPT ELEMFI FACTURE CESSION)
                          use_hash(FNC) */
DISTINCT CESSION.REFPIECE, CESSION.GPIDEVIS
  FROM T_INTERVENANTS INTER,
       G_ELEMFI       ELEMFI,
       STD_MIGR_CCD   CCD,
       STD_MIGR_FNC   FNC,
       G_PIECE        FACTURE,
       G_PIECE        CESSION
 WHERE CCD.SUBCONTRACT_REF = INTER.REFDOSS
   AND INTER.REFTYPE = 'CL'
   AND CCD.ACCOUNT_ID = ELEMFI.REFDOSS
   AND ELEMFI.REFDOSS = FNC.ID_DEBTOR
   AND ELEMFI.REFELEM = FNC.ID_DOCUMENT
   AND ELEMFI.REFELEM = FACTURE.GPIHEURE
   AND FACTURE.TYPPIECE = 'FACTURE'
   AND FACTURE.GPIDEPOT = CESSION.REFPIECE
   AND CCD.SUBCONTRACT_REF = CESSION.REFDOSS
   AND CESSION.TYPPIECE = 'CESSION'
   AND CESSION.GPIDEVIS IS NULL;
/********************************OLD SQL*******************************************/
/********************************OLD Metrics***************************************/
/*
MODULE                           SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
std_migr_exp_mvt.export_rem                                      148      55006 ON CPU               2024/02/24 18:02:58  2024/02/24 18:27:58          92                    1 +000000000 00:25:00.415 55%
std_migr_exp_mvt.export_rem                                      148      55006 db file sequential r 2024/02/24 18:03:08  2024/02/24 18:27:38          59                    1 +000000000 00:24:30.413 35%
                                                        0       1057      25649 log file parallel wr 2024/02/24 18:06:18  2024/02/24 18:29:29           2                      +000000000 00:23:10.397 1%
DBMS_SCHEDULER                   b6usrg82hwsa3          0        246      54306 ON CPU               2024/02/24 18:06:08  2024/02/24 18:06:18           2                    1 +000000000 00:00:10.002 1% 


MODULE                           SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
std_migr_exp_mvt.export_rem                                      148      55006 ON CPU               2024/02/24 18:02:58  2024/02/24 18:27:58          92                    1 +000000000 00:25:00.415 61%
std_migr_exp_mvt.export_rem                                      148      55006 db file sequential r 2024/02/24 18:03:08  2024/02/24 18:27:38          59                    1 +000000000 00:24:30.413 39%


MODULE                           SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
std_migr_exp_mvt.export_rem      5b3amybr4ayxw 3470081298        148      55006                      2024/02/24 18:07:08  2024/02/24 18:27:58         126                    1 +000000000 00:20:50.254 83%
std_migr_exp_mvt.export_rem      092691ywgnyzv   53573607        148      55006                      2024/02/24 18:02:58  2024/02/24 18:06:58          25                    1 +000000000 00:04:00.146 17%


INSTANCE_NUMBER SQL_ID            ELAPSED MAX_WAIT_ON     PC_OF  WAIT_TIME            GETS      READS       ROWS  ELAP/EXEC       GETS/EXEC READS/EXEC  ROWS/EXEC       EXEC PLAN_HASH_VALUE
--------------- ------------- ----------- --------------- ----- ---------- --------------- ---------- ---------- ---------- --------------- ---------- ---------- ---------- ---------------
              1 092691ywgnyzv         247 IO              89%   216.572055         4432638     638233      22424     247.29         4432638     638233      22424          1        53573607
              1 5b3amybr4ayxw        1262 IO              59%   674.348324       455294883     565752          0    1262.16       455294883     565752          0          1      3470081298


SQL_ID        SQL_PLAN_HASH_VALUE SQL_PLAN_LINE_ID SQL_PLAN_OPERATION             SQL_PLAN_OPTIONS                   ACTIVE
------------- ------------------- ---------------- ------------------------------ ------------------------------ ----------
5b3amybr4ayxw          3470081298               10 TABLE ACCESS                   BY INDEX ROWID BATCHED               1196
5b3amybr4ayxw          3470081298               11 INDEX                          RANGE SCAN                             65
5b3amybr4ayxw          3470081298                9 INDEX                          RANGE SCAN                              1   	


 
Plan hash value: 3470081298
--------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                 | Name           | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  |
--------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                          |                |      1 |        |   196K(100)|      0 |00:00:00.01 |       0 |      0 |
|   1 |  HASH UNIQUE                              |                |      1 |      1 |   196K  (1)|      0 |00:00:00.01 |       0 |      0 |
|*  2 |   HASH JOIN SEMI                          |                |      1 |      1 |   196K  (1)|      0 |00:00:00.01 |       0 |      0 |
|   3 |    NESTED LOOPS                           |                |      1 |      8 |   196K  (1)|      0 |00:00:00.01 |       0 |      0 |
|   4 |     NESTED LOOPS                          |                |      1 |   4806K|   196K  (1)|      0 |00:00:00.01 |       0 |      0 |
|   5 |      NESTED LOOPS                         |                |      1 |   4806K| 51866   (1)|      0 |00:00:00.01 |       0 |      0 |
|   6 |       NESTED LOOPS                        |                |      1 |    296K| 16283   (1)|      0 |00:00:00.01 |       0 |      0 |
|   7 |        NESTED LOOPS SEMI                  |                |      1 |    244K|  6483   (1)|    905 |00:00:00.01 |      41 |      1 |
|   8 |         TABLE ACCESS FULL                 | STD_MIGR_CCD   |      1 |    244K|  1583   (1)|    905 |00:00:00.01 |      31 |      0 |
|*  9 |         INDEX RANGE SCAN                  | INT_REFDOSS    |      4 |    128K|     1   (0)|      4 |00:00:00.01 |      10 |      1 |
|* 10 |        TABLE ACCESS BY INDEX ROWID BATCHED| G_PIECE        |    905 |      1 |     1   (0)|      0 |00:00:14.81 |    5253K|   6155 |
|* 11 |         INDEX RANGE SCAN                  | PIE_REFDOSS    |    905 |      1 |     1   (0)|   5227K|00:00:01.20 |   32668 |     50 |
|* 12 |       TABLE ACCESS BY INDEX ROWID BATCHED | G_PIECE        |      0 |     16 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 13 |        INDEX RANGE SCAN                   | GP_GPIDEP      |      0 |     42 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 14 |      INDEX UNIQUE SCAN                    | EFI_REFELEM    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 15 |     TABLE ACCESS BY INDEX ROWID           | G_ELEMFI       |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|  16 |    INDEX FULL SCAN                        | IDX_FNC_DOC_DB |      0 |    812K|   101   (0)|      0 |00:00:00.01 |       0 |      0 |
--------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   2 - access("ELEMFI"."REFDOSS"="FNC"."ID_DEBTOR" AND "ELEMFI"."REFELEM"="FNC"."ID_DOCUMENT")
   9 - access("CCD"."SUBCONTRACT_REF"="INTER"."REFDOSS" AND "INTER"."REFTYPE"='CL')
  10 - filter("CESSION"."GPIDEVIS" IS NULL)
  11 - access("CCD"."SUBCONTRACT_REF"="CESSION"."REFDOSS" AND "CESSION"."TYPPIECE"='CESSION')
       filter("CESSION"."REFDOSS" IS NOT NULL)
  12 - filter(("FACTURE"."GPIHEURE" IS NOT NULL AND "FACTURE"."TYPPIECE"='FACTURE'))
  13 - access("FACTURE"."GPIDEPOT"="CESSION"."REFPIECE")
       filter("FACTURE"."GPIDEPOT" IS NOT NULL)
  14 - access("ELEMFI"."REFELEM"="FACTURE"."GPIHEURE")
  15 - filter(("ELEMFI"."REFDOSS" IS NOT NULL AND "CCD"."ACCOUNT_ID"="ELEMFI"."REFDOSS"))

*/
/********************************OLD Metrics***************************************/

/********************************New SQL*******************************************/
SELECT /*+ leading(CCD INTER ELEMFI FNC FACTURE CESSION)
             use_nl(INTER ELEMFI FACTURE CESSION)
      use_hash(FNC) */
DISTINCT CESSION.REFPIECE, CESSION.GPIDEVIS
  FROM T_INTERVENANTS INTER,
       G_ELEMFI       ELEMFI,
       STD_MIGR_CCD   CCD,
       STD_MIGR_FNC   FNC,
       G_PIECE        FACTURE,
       G_PIECE        CESSION
 WHERE CCD.SUBCONTRACT_REF = INTER.REFDOSS
   AND INTER.REFTYPE = 'CL'
   AND CCD.ACCOUNT_ID = ELEMFI.REFDOSS
   AND ELEMFI.REFDOSS = FNC.ID_DEBTOR
   AND ELEMFI.REFELEM = FNC.ID_DOCUMENT
   AND ELEMFI.REFELEM = FACTURE.GPIHEURE
   AND FACTURE.TYPPIECE = 'FACTURE'
   AND FACTURE.GPIDEPOT = CESSION.REFPIECE
   AND CCD.SUBCONTRACT_REF = CESSION.REFDOSS
   AND CESSION.TYPPIECE = 'CESSION'
   AND CESSION.GPIDEVIS IS NULL;
/********************************New SQL*******************************************/
/********************************New Metrics***************************************/
/*

Plan hash value: 3675100683
-----------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                               | Name                   | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers |
-----------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                        |                        |      1 |        |   353K(100)|      0 |00:00:24.66 |    4367K|
|   1 |  HASH UNIQUE                            |                        |      1 |      1 |   353K  (1)|      0 |00:00:24.66 |    4367K|
|   2 |   NESTED LOOPS                          |                        |      1 |      1 |   353K  (1)|      0 |00:00:24.66 |    4367K|
|   3 |    NESTED LOOPS                         |                        |      1 |    264K|   353K  (1)|    783K|00:00:23.78 |    4192K|
|   4 |     NESTED LOOPS                        |                        |      1 |    264K|   342K  (1)|    783K|00:00:21.94 |    3133K|
|*  5 |      HASH JOIN                          |                        |      1 |    657K|   316K  (1)|    783K|00:00:17.80 |    1251K|
|   6 |       INDEX FULL SCAN                   | IDX_FNC_DOC_DB         |      1 |    812K|   101   (0)|    783K|00:00:00.12 |    9538 |
|   7 |       NESTED LOOPS                      |                        |      1 |     42M| 19556   (1)|     36M|00:00:09.83 |    1241K|
|   8 |        NESTED LOOPS                     |                        |      1 |    261K|  6483   (1)|    278K|00:00:00.56 |   85105 |
|   9 |         TABLE ACCESS FULL               | STD_MIGR_CCD           |      1 |    244K|  1583   (1)|    278K|00:00:00.12 |    8106 |
|* 10 |         INDEX RANGE SCAN                | INT_REFDOSS            |    278K|      1 |     1   (0)|    278K|00:00:00.37 |   76999 |
|* 11 |        INDEX RANGE SCAN                 | G_ELEMFI$REFDOSS_ACTIF |    278K|    164 |     1   (0)|     36M|00:00:06.57 |    1156K|
|* 12 |      TABLE ACCESS BY INDEX ROWID BATCHED| G_PIECE                |    783K|      1 |     1   (0)|    783K|00:00:03.92 |    1881K|
|* 13 |       INDEX RANGE SCAN                  | GP_GRTYPE_MT_DT        |    783K|      1 |     1   (0)|    783K|00:00:02.37 |    1376K|
|* 14 |     INDEX RANGE SCAN                    | PIE_REFPIECE           |    783K|      1 |     1   (0)|    783K|00:00:01.65 |    1059K|
|* 15 |    TABLE ACCESS BY INDEX ROWID          | G_PIECE                |    783K|      1 |     1   (0)|      0 |00:00:00.75 |     175K|
-----------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   5 - access("ELEMFI"."REFDOSS"="FNC"."ID_DEBTOR" AND "ELEMFI"."REFELEM"="FNC"."ID_DOCUMENT")
  10 - access("CCD"."SUBCONTRACT_REF"="INTER"."REFDOSS" AND "INTER"."REFTYPE"='CL')
  11 - access("CCD"."ACCOUNT_ID"="ELEMFI"."REFDOSS")
       filter("ELEMFI"."REFDOSS" IS NOT NULL)
  12 - filter("FACTURE"."GPIDEPOT" IS NOT NULL)
  13 - access("FACTURE"."TYPPIECE"='FACTURE' AND "ELEMFI"."REFELEM"="FACTURE"."GPIHEURE")
       filter("FACTURE"."GPIHEURE" IS NOT NULL)
  14 - access("FACTURE"."GPIDEPOT"="CESSION"."REFPIECE")
  15 - filter(("CCD"."SUBCONTRACT_REF"="CESSION"."REFDOSS" AND "CESSION"."TYPPIECE"='CESSION' AND "CESSION"."REFDOSS" IS NOT
              NULL AND "CESSION"."GPIDEVIS" IS NULL))         
*/
/********************************New Metrics***************************************/

/********************************Index statistics**********************************/

/********************************Other SQLs****************************************/          
/*

*/ 
/********************************Other SQLs****************************************/              
