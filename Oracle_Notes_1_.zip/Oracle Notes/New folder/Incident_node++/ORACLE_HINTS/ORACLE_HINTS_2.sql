##### FOR SERVICE CALL FRO ROBECCO: ictservicedesk-robeco@hpe.com

=======================================================================================================

CHECK DATAFILES IN TABLESPACE:

set lines 300
col FILE_NAME for a60
select FILE_ID,FILE_NAME,TABLESPACE_NAME,BYTES/1024/1024 "MB",MAXBYTES/1024/1024 "MAX MB",AUTOEXTENSIBLE from dba_data_files where TABLESPACE_NAME='&TABLESPACE_NAME';
=================================================================================================================================
################ Settings for Oracle DB monitoring ###################

dbspi_mw_int && dbspi_mw_int -osm && dbspi_mw_int -udm && ovpa restart coda

ovcodautil -obj | grep -i data
==================================================================================================================================
################ Stopping monitoring ###################
ITO-GDC-Bulgaria-OSL@hpe.com 

dbmoncol database oracle ERFPRD_1 OFF
dbmoncol database oracle webeencp ON 
dbspicol ON 
dbspicol OFF

/var/opt/OV/dbspi/db_mon.cfg
=================================================================================================================================
####db-spi collection OFF

CHECK-COLLECTION=Major:TT 

##### SCP EXAMPLES ######

scp your_username@remotehost.edu:~/\{foo.txt,bar.txt\} 

scp hpmnrang@deheremcln347:/opt/oracle/orasave/DMT_20170814_*.dmp .

scp hpmnrang@deheremcln347:/opt/oracle/orasave/REQ0155077_RMA_26*.dmp .

scp 192.161.1.1:/direktoriqta pulen put do faila /putq където искаш да се свали на машината 
=====================================================================================================================================
######################## ROBECCO ############

cmviewcl -> CHECK PACKAGES
disable auto run --> cmmodpkg -d pakage_name 
stop the pakacge --> cmhaltpkg package_name 
start the package --> cmrunpkg -n nodename package_name  
cmmodpkg -e package_name - enable switching  

(always in ROOT)

до колкото аз знам преди да се пре се спира autorun --> cmmodpkg -d pakage_name за да не релокира
после се спира с cmhaltpkg package_name 
правиш какворо правиш пускаш с cmrunpkg -n nodename package_name на определения нод
я си разрешаваш релокацията cmmodpkg -e package_name 
те тия пакети с базата местят и файлови системи и тн заедно
и затова не можеш да пуснеш базата със startup защото и няма нещата
със list packages --> cmviewcl 
с таз игледаш кой пакет къде е

######################### WIN SCP Direct connection #################
connector.ssh:ryelxphperm1.rye.avon.com:cbylxwebepbt1.uk.avon.com:cbylxwebepbt1:avon:0:0:x:0:1:22 -> edit first 0 to winscp
connector.ssh:ryelxphperm1.rye.avon.com:cbylxwebepbt1.uk.avon.com:cbylxwebepbt1:avon:winscp:0:x:0:1:22

connector.ssh:145.16.254.28:defrcpw1.de.eds.com:defrcpw1:edsfrk:winscp:0:x:0:1:22
connector.ssh:207.169.206.155:derucpw3.de.eds.com:derucpw3:edsfrk:winscp:0:x:0:1:22
connector.ssh:207.169.203.31:derucpw3.de.eds.com:derucpw3:edsfrk:0:0:x:0:1:22

ps -ef |egrep 'pmon|tns' | grep -v egrep;TMOUT=0 

When adding additional datafiles keep in mind the following points:

1.	Use the same location as the other datafiles in the tbs defined by the FILE_NAME column in dba_data_files (in Adecco these are symbolic links to the actual FS).
2.	Pay attention to whether the previous datafiles are with or without the AUTOEXTEND option and copy the same setting.
3.	When creating an autoextendable datafile ALWAYS define the increment size. The INCREMENT_BY column gives you the increment value of the other datafiles in blocks. The below select gives you the increment size in kbytes ready to be used in the NEXT clause (ex: …AUTOEXTEND ON NEXT 5120K…):
   
### Checking the incremental step for datafile   
select file_id, file_name, tablespace_name, (increment_by*(bytes/blocks))/1024 increment_by_kb from dba_data_files where TABLESPACE_NAME='&tablespace_name';

   FILE_ID FILE_NAME                                                              TABLESPACE_NAME                INCREMENT_BY_KB
---------- ---------------------------------------------------------------------- ------------------------------ ---------------
         6 /local/HRPSSPP0/group01/gpapp01.dbf                                    GPAPP                                   102400 

### dbspicao -m6 -r1 -pv
		 
###Examples:
				  
 alter tablespace [tablespace name] add datafile '[filename path .dbf]' size 100M autoextend on next 1024K maxsize 10000M;
 
 alter database datafile 1 autoextend on maxsize 10000M;
 
 alter database datafile 1 resize 10000M;
 
### show parameter create - checking if this is oracle managed file [db_create_file_dest] -> ASM+
 alter tablespace FOAPP add datafile 'from VALUE "db_create_file_dest" ' size [initial size] autoextend on next 1024K maxsize 10000M;
  alter tablespace SB_DWH_INTEGRATION add datafile '+DATA' size 1024M autoextend on next 102400K maxsize unlimited;
 
 alter tablespace GCA_TBS add datafile '/oracle/OSLTP/oradata1/gca_tbs_tsOSLTP.dbf45' size 100M autoextend on maxsize unlimited;
 alter tablespace CDW_DATA add datafile size 10240M autoextend on next 102400K maxsize 32768M;
 alter tablespace STOCKTRANSTAB add datafile '/gkz1ddata01/gkz1d/stocktranstab/stocktranstab05.dbf' size 512M autoextend on next 512000K maxsize 2000M;
 alter tablespace PDATA add datafile '+DATA' size 100M autoextend on next 102400K maxsize 200M;
 
 alter tablespace RF_DATA_2014 add datafile '/oracle/oradata/OVEDWR_P/dbfiles1/rf_data_2014_04.dbf' size 100M autoextend on next 102400K maxsize 20480;
 alter database datafile 7 autoextend on maxsize 200M;
 
dbspicao -m6 -r1 -pv -i [INSTANCE] | egrep 'TABLESPACE_NAME|[NAME_OF_THE_TABLESPACE]|-' | grep -v 'TABLESPACE_NAME:  Name of the tablespace'
dbspicao -m6 -r1 -pv -i webecep | egrep 'TABLESPACE_NAME|ORDDETL_KZ_DATA|-' | grep -v 'TABLESPACE_NAME:  Name of the tablespace'
dbspicao -m6 -r1 -pv -i SDWP | egrep 'TABLESPACE_NAME|IXTBS_TSDW_LAGERSALDOBUTIK|-' | grep -v 'TABLESPACE_NAME:  Name of the tablespace'

set linesize 400
col FILE_NAME for a70
select file_id,FILE_NAME, TABLESPACE_NAME, BYTES/1024/1024, MAXBYTES/1024/1024, AUTOEXTENSIBLE from 	dba_data_files where TABLESPACE_NAME='&tablespace_name';

_____________________________________________________________________________________________________________________________________________________________________________________________________
 
ps -ef |egrep 'pmon|tns' | grep -v egrep;TMOUT=0 

 ________________________________________________________________________________________________________________________________
 
 ### TEMP size ### - check the usage "Hint: unable to extend temp segment"
 
SELECT A.tablespace_name tablespace, D.mb_total,
SUM (A.used_blocks * D.block_size) / 1024 / 1024 mb_used,
D.mb_total - SUM (A.used_blocks * D.block_size) / 1024 / 1024 mb_free
FROM v$sort_segment A,
(
SELECT B.name, C.block_size, SUM (C.bytes) / 1024 / 1024 mb_total
FROM v$tablespace B, v$tempfile C
WHERE B.ts#= C.ts#
GROUP BY B.name, C.block_size
) D
WHERE A.tablespace_name = D.name
GROUP by A.tablespace_name, D.mb_total;   
_________________________________________________________________________________________________________________________________

###################################### DBSPI-0087: Current processes percentage ********** ######################################

### Checking the current usage/utilization on the server with command:
dbspicao -m87 -pv
(TNS:listener could not find available handler for requested type of server] - may be the system cannot create the process)

root@hx004105: /var/opt/OV/bin/instrumentation # stty columns 200

----------------------------------------------------------------------------------------------------------------------------------------
UXMON: Too few instances: tnslsnr .

cd $ORACLE_HOME/network/admin ---> tnsnames.ora (file is on thids location)
ls -la
cat listener.ora

----------------------------------------------------------------------------------------------------------------------------------------
OSDOTOOLS - INFRA
VOBE - Flemish
Recordbank - Panayot
Fortum - 
----------------------------------------------------------------------------------------------------------------------------------------

dbspicao -vdfp - check database connections
--------------------------------------------------------------------------------------------------------------------------------------------
ALERT LOG / TRC Files:
show parameter back -> background_dump_dest
cat /etc/oratab ---> check which database are running on this machine
------------------------------------------------------------------------------------------------------
alter system swith logfile;
---------------------------------------------
INFRA server login to database:
ls -lart | grep profile
-----------------------------------------------------------------------
lsnrctl - res
cat /etc/oratab -- checking ORACLE_HOME
asmcmd - > lsdg -- checking asm discs if they are MOUNT 
select * from v$resource_limit; -- gives you utilization of the databases
select * from v$flash_recovery_area_usage -- gives you flash recevory

--------------------------------------------------------------------------------------------
######################## DBSPI-0334: Free space percentage 4.98 too low for RECO in database +ASM1 <=5% ##################################

### Check ASM SPACE/STORAGE:

column pct_free format 99.99
select group_number, name, total_mb, free_mb, total_mb -free_mb used_mb,
case when total_mb=0 then 0 else  free_mb/total_mb *100 end pct_free
from v$asm_diskgroup
/

#### ASM long #### -- Which database utilization the DISKGROUP in ASM

SQL> show parameter fal

NAME                                 TYPE                             VALUE
------------------------------------ -------------------------------- ------------------------------
fal_client                           string                           WISK7_PS.MVG.BE
fal_server                           string                           WISK7_P.MVG.BE 

#### Check the state of the database if it STANDBY
### check last apply standby ###
select database_role from v$database; 

select * from v$flash_recovery_area_usage; 

select al.thread#,
        al.last_rec "Last Recd",
        la.last_app "Last Applied"
from
  (select thread#, max(sequence#) last_rec
    from v$archived_log
    group by thread#) al,
  (select thread#, max(sequence#) last_app
    from v$archived_log
    where applied='YES' and registrar='RFS'
    group by thread#) la
where al.thread#=la.thread#
and al.thread# != 0
order by al.thread#
/ 

### delete archivelog ###
rman target /
delete noprompt archivelog until sequence 173811 thread 1; 

delete noprompt archivelog until sequence 43086 thread 1;
delete noprompt archivelog until sequence 44651 thread 2;
delete noprompt archivelog until sequence 42729 thread 3;
delete noprompt archivelog until sequence 43365 thread 4;


################################ RESTORE ARCHIVE LOG  ################################
RMAN-> ON THE PRIMARY DATABASE
restore archivelog sequence between 388 and 388; 
restore archivelog sequence between 176629 and 176629;

################################ ADIDAS BACKUPS - DBSPI-0334: Free space percentage 18.96 too low for DG_OSTEM211_FRA in database +ASM2 <=20%
RUN -> cdrman
REPLACE THE PART BELOW WITH NESSARY BACKUP

rman cmdfile=backup_online_arch_SPMMG1.rman log=backup_online_arch_`date +%Y%m%d%H%M`.log

### Check fo running backup
set linesize 400
col TARGET for a28
col TARGET_DESC for a16
col UNITS for a10
col TIME_REMAINING for a20
col START_TIME for a20
col LAST_UPDATE_TIME for a20
col SOFAR for c13
col TOTALWORK for c13
SELECT inst_id,SID, SERIAL#, to_char(START_TIME, 'YYYY/MON/DD HH:MI:SS') "START_TIME", to_char(LAST_UPDATE_TIME, 'YYYY/MON/DD HH:MI:SS') "LAST_UPDATE_TIME", TIME_REMAINING/60 as "remaining mins", TARGET, TARGET_DESC, SOFAR, TOTALWORK, UNITS, ROUND(SOFAR/TOTALWORK*100,2) "%_COMPLETE" FROM GV$SESSION_LONGOPS WHERE TOTALWORK != 0 AND SOFAR <> TOTALWORK order by START_TIME;

backup_online_arch_OSTEM211.rman

################################ Reset DBSPI password

dbspicfg -e

################################ DBSPI-0058: Archive free space percentage 22.72% too low for archive device \oracle\RMAN112\fra for RMAN112 <=30%. [Policy:DBMON-DBSPI-0058-ARM] ################
omnistat -det --> check for BACKUPS

Run backUP : /opt/omni/bin/omnib  -oracle8 fivatx0011_CTECAB_archivelog_delete_on &

/opt/omni/bin/omnib -oracle8 BCK_DC2_ARCH_sv2059_IFCP

oracle8_copy/prod_fivaora002_ora_hpcsa_daily_logs_on

C:\Program Files\OmniBack\bin\omnib -oracle8 clintfr10656_AGOLFRP0_ARC 
C:\Program Files\OmniBack\bin -oracle8 mewa_defradb811_ora_MIDSYS35_arch_del
"C:\Program Files\OmniBack\bin\omnib.exe" -oracle8 clintfr10480_AGOLFRS1_ARC

/opt/omni/bin/omnib  -oracle8  IDA_VALEO_lis9-shrd51_ORA_VALHRREC_ARCHIVE        valhrrec

/opt/omni/bin/omnib -oracle8 ryelxtraxpdbc2_Mon011602H00Momstrc2_af_OMSTRC2_31765_1.bus

RMAN> list backup of archivelog all
RMAN> list backup of database summary;
RMAN> list backup of database completed after 'sysdate-15';

rman cmdfile=backup_online_arch_.rman log=backup_online_arch_`date +%Y%m%d%H%M`.log
example: rman cmdfile=backup_online_arch_OSTST.rman log=backup_online_arch_OSTST`date +%Y%m%d%H%M`.log -> backup_online_arch_OSTST.rman (example)

EON SPECIFIC backup : cd /tsm/TCTSP01/StartRedolog.sh

/oracle/backup/STRSRV1P
C:\Programs\Tivoli\TSM\<DATABASE_NAME>\rman  

NETBACKUP -> cd /tsm/

EON privilege request team:
eonprivreq@hpe.com
EON UAM team:
uam.eon@dxc.com
на тези пишете за да ви направят KID-ве ако нямате, както и на нови колеги, с бланката прикачена също към мейла (на Марто Рангелов). 


ARCHIVE DEST SPACE UTILIZATION:

PROMPT Archivelog Space Report
col limit format 999,999,999 heading "Limit (mb)";
col used format 999,999,999 heading "Space Used (mb)";
col free format 999,999,999 heading "Space Free (mb)";
select space_limit/(1024*1024) limit
, (space_used + space_reclaimable)/(1024*1024) used
, (space_limit-(space_used+space_reclaimable))/(1024*1024) free
,number_of_files
from v$recovery_file_dest
/

set linesize 300
select * from v$flash_recovery_area_usage;

set linesize 300
show parameter db_recovery_file_dest;
 

alter system set log_archive_dest=[the new space]
alter system set log_archive_dest_1='LOCATION=/ce1parch01/ce1p';
alter system set log_archive_dest_1='LOCATION=/ce1pdata01/ce1p_arch';


RMAN> delete noprompt archivelog all backed up 1 times to SBT; 
delete noprompt archivelog all backed up 1 times to DISK;
--- delete all backed up 1 time to tape

### IF DATABASE HANG -> SQL> alter system set db_recovery_file_dest='+LEADG_M0' (some location that have space)

select log_mode,flashback_on from v$database;
---> If FLASHBACK_LOGS -> alter database flashback off; AND THEN ->> alter database flashback on;

select database_role from v$database; - check if the databaseFault is not on STANDBY !!! ------ DBSPICAO813

set lines 400
select TIMESTAMP, MESSAGE FROM v$dataguard_status; -> 813 METRIC check for ERRORS
alter system archive log current; -> SWITCH ARCHIVELOG so much times which is nessary for cleaning 813 metric

################################ UXMON: Filesystem /oracle/RGDRD1P/oradata diskspace utilization exceeds 90 threshold. ###############

### AT CORRESPONDANT DIRECTORY:
find . -xdev -size +100000000c -type f -exec ls -la {} \; 2> /dev/null |  sort -nk5 | tail -2000
find . -xdev -size +10000000c -type f -name "*.trc" -exec ls -lt {} \; 2> /dev/null |  sort -nk5 | tail -2000
find . -xdev -size +10000000c -type f -name "*.trc*" -exec ls -lt {} \; 2> /dev/null |  sort -nk5 | tail -2000
find . -name "*.trm" -exec rm {} \; && find . -name "*.trc" -exec rm {} \; && find . -name "*.aud" -exec rm {} \; && find . -name "log_*.xml" -exec gzip -9f {} \; > redirection &
find . -name "*.trm" -exec rm {} \; && find . -name "*.trc" -exec rm {} \; && find . -name "*.aud" -exec rm {} \; > redirection &
find . -name "*.trm" -mtime +1 -exec rm {} \; && find . -name "*.trc" -mtime +1 -exec rm {} \; && find . -name "*.aud" -exec rm {} \; && find . -name "listener_scan*.log" -mtime +30 -exec rm {} \; & 
find . -name "*.trm" -mtime +1 -exec rm {} \; && find . -name "*.trc" -mtime +1 -exec rm {} \; && find . -name "*.aud" -mtime +1 -exec rm {} \; && find . -name "log_*.xml" -exec gzip -9f {} \; > redirection &
find . -name "*.trm" -mtime +1 -exec rm {} \; && find . -name "*.aud" -exec rm {} \; && find . -name "listener_scan*.log" -mtime +30 -exec rm {} \; > redirection &
find . -name "log_*.xml" -exec gzip -9f {} \; > redirection &
find . -mtime +3 -exec rm -f {} \;
find . -mtime +5 -exec rm -f {} \;
find . -mtime +400 -exec rm -f {} \;

find . -type f -size +1000000c -name "core" -exec rm -f {} \; 
find . -name "*.sql" -mtime +80 -exec rm {} \;


## For fs like /u04 and so on .............. /u04/orabck/EJUDOQ_P/rman -> delete all backups to lv0(without lv0) (save 1 week)

gzip -9vc run_1484265094.log > run_1484265094.log.`date +%Y%m%d`.gz;>run_1484265094.log

gzip -9vc run_1484616697.log > run_1484616697.log.`date +%Y%m%d`.gz;>run_1484616697.log
gzip -9vc run_1484550998.log > run_1484550998.log.`date +%Y%m%d`.gz;>run_1484550998.log
gzip -9vc run_1484876199.log > run_1484876199.log.`date +%Y%m%d`.gz;>run_1484876199.log
gzip -9vc run_1484255794.log > run_1484255794.log.`date +%Y%m%d`.gz;>run_1484255794.log
gzip -9vc run_1484285195.log > run_1484285195.log.`date +%Y%m%d`.gz;>run_1484285195.log
gzip -9vc run_1484567797.log > run_1484567797.log.`date +%Y%m%d`.gz;>run_1484567797.log
gzip -9vc run_1484250995.log > run_1484250995.log.`date +%Y%m%d`.gz;>run_1484250995.log
gzip -9vc run_1484376697.log > run_1484376697.log.`date +%Y%m%d`.gz;>run_1484376697.log
gzip -9vc run_1484273495.log > run_1484273495.log.`date +%Y%m%d`.gz;>run_1484273495.log
gzip -9vc run_1484265695.log > run_1484265695.log.`date +%Y%m%d`.gz;>run_1484265695.log
gzip -9vc run_1484256394.log > run_1484256394.log.`date +%Y%m%d`.gz;>run_1484256394.log
gzip -9vc run_1484300495.log > run_1484300495.log.`date +%Y%m%d`.gz;>run_1484300495.log
gzip -9vc run_1484558495.log > run_1484558495.log.`date +%Y%m%d`.gz;>run_1484558495.log
gzip -9vc run_1484250394.log > run_1484250394.log.`date +%Y%m%d`.gz;>run_1484250394.log
gzip -9vc run_1484265694.log > run_1484265694.log.`date +%Y%m%d`.gz;>run_1484265694.log
gzip -9vc run_1484730397.log > run_1484730397.log.`date +%Y%m%d`.gz;>run_1484730397.log
gzip -9vc run_1484271096.log > run_1484271096.log.`date +%Y%m%d`.gz;>run_1484271096.log
gzip -9vc run_1484292995.log > run_1484292995.log.`date +%Y%m%d`.gz;>run_1484292995.log
gzip -9vc run_1484346095.log > run_1484346095.log.`date +%Y%m%d`.gz;>run_1484346095.log
gzip -9vc run_1484253994.log > run_1484253994.log.`date +%Y%m%d`.gz;>run_1484253994.log
gzip -9vc run_1484268395.log > run_1484268395.log.`date +%Y%m%d`.gz;>run_1484268395.log
gzip -9vc run_1484245894.log > run_1484245894.log.`date +%Y%m%d`.gz;>run_1484245894.log
gzip -9vc run_1484281295.log > run_1484281295.log.`date +%Y%m%d`.gz;>run_1484281295.log
gzip -9vc run_1484256395.log > run_1484256395.log.`date +%Y%m%d`.gz;>run_1484256395.log
gzip -9vc run_1484256995.log > run_1484256995.log.`date +%Y%m%d`.gz;>run_1484256995.log
gzip -9vc run_1484311297.log > run_1484311297.log.`date +%Y%m%d`.gz;>run_1484311297.log

log_104****** - can be deleted
./diag/tnslsnr/cgrep-db-0001/listener_scan2/trace/listener_scan2.log
./diag/tnslsnr/cgrep-db-0001/listener_scan2/alert/log_1.xml

gzip -9cv diagnostic*.log> diagnostic*.log.log.`date +%Y%m%d`.log.gz && > diagnostic*.log
gzip -9cv listener_repo.log> listener_repo.log.`date +%Y%m%d`.log.gz && > listener_repo.log
gzip -9cv log_*.xml>

gzip -9cv alert_ERFTST_1.log> alert_ERFTST_1.log`date +%Y%m%d`.log.gz && > alert_ERFTST_1.log

gzip -9cv listener.log> listener.log`date +%Y%m%d`.log.gz && > listener.log


find . -name "*" -mtime +60 -exec rm {} \;

gzip -9cv messages-20181007> messages-20181007.gz && > messages-20181007

############################# ROBECCO ###########################

[oracle@rbcdeesh735 home]$ df -h .
Filesystem            Size  Used Avail Use% Mounted on
/dev/mapper/vg00-homevol
                      992M  334M  607M  36% /home 
gzipped log_*xml files older than 3days 
./oracle/oradiag_oracle/diag/clients/user_oracle/host_1551266901_76/alert/ 

############################## MEWA ###############################

Service Desk -> E-INCFLS-CDO-REUWS-SD-FG-SF

############################## MEWA ##############################

run {
allocate channel 'dev_0' type 'sbt_tape' parms 'ENV=(OB2BARTYPE=Oracle8,OB2APPNAME=MIDSYS15,OB2BARLIST=mewa_defradb806_ora_MIDSYS15_arch_del)';
backup
 format 'mewa_defradb806_ora_MIDSYS15_arch_del<MIDSYS01_%s:%t:%p>.dbf'
 archivelog all
 delete input;
}  

################################ DBSPI-0031: 1.00 users approaching maximum configured cursors for FMAXTRN >=95% of max, most....

################## FOR ADIDAS THERE ARE SCHEDULED JOBS WHICH ARE KILLING AUTOMATICALLY THE SESSIONS
################## ADDIDAS BACKUPS CHECK THE ALLIAS for current user. From there list backups and:
su - oracle user
cdrman
rman cmdfile=backup_online_arch_OSLTP.rman log=backup_online_arch_OSLTP.log & 

### select SID,count(SID) from v$open_cursor group by SID;

show parameter open_cursors

alter system set open_cursors = 600 scope=both;

set linesize 200 
col PROGRAM for a40 
col MACHINE for a13 
col username for a10 
col TO_CHAR(LOGON_TIME,'YYYY/MM/DDHH24:MI:SS') for a45 
set linesize 300
select inst_id,SID,SERIAL#,STATUS,USERNAME,MACHINE,PROGRAM,to_char(LOGON_TIME, 'YYYY/MM/DD HH24:MI:SS'), LOCKWAIT, SQL_ID from gv$session where sid in (
6      
 ) order by LOGON_TIME;
 
select SID, SERIAL#, USERNAME, SCHEMANAME, MACHINE, PROGRAM, STATUS, LAST_CALL_ET from gv$session where STATUS='INACTIVE';

CHECK CURSORS METRIC-31:

set linesize 200 
col PROGRAM for a25 
col MACHINE for a15 
col username for a10 
col LOCKWAIT for a10 
col TO_CHAR(LOGON_TIME,'YYYY/MM/DDHH24:MI:SS') for a45 
select inst_id,SID,SERIAL#,STATUS,USERNAME,MACHINE,PROGRAM,to_char(LOGON_TIME, 'YYYY/MM/DD HH24:MI:SS'),LOCKWAIT from gv$session where status='INACTIVE' order by SID;

INACTIVE SESSIONS:

set linesize 200
col PROGRAM for a40
col MACHINE for a9
col username for a10
col TO_CHAR(LOGON_TIME,'YYYY/MM/DDHH24:MI:SS') for a45
select sql_id,inst_id,SID,SERIAL#,STATUS,USERNAME,MACHINE,PROGRAM,to_char(LOGON_TIME, 'YYYY/MM/DD HH24:MI:SS'),LOCKWAIT from gv$session where status='INACTIVE' order by inst_id, LOGON_TIME;

alter system set open_cursors = 2000 scope=both;
 
Hi Team,

Please be informed that the database FMAXTRN on machine fivatx0173.adinfra.net reached maximum cursors.
Please advise us if we can kill the session with SID 2422 due to above information.

USER_NAME                      SID        # CURSORS  PERCENTAGE
------------------------------ ---------- ---------- ----------
MAXIMOTRN                            2422        300     100.00


   INST_ID        SID    SERIAL# STATUS   USERNAME                       MACHINE                                                          PROGRAM                                          TO_CHAR(LOGON_TIME, LOCKWAIT         SQL_ID
---------- ---------- ---------- -------- ------------------------------ ---------------------------------------------------------------- ------------------------------------------------ ------------------- ---------------- -------------
         1       2422      10958 INACTIVE MAXIMOTRN                      FIESPV1388                                                       JDBC Thin Client                                 2017/01/30 13:25:40

Please be informed that due to this issue the database cannot opens new cursors from which the correspondent program above can have some issues. Thank you for your time.


############################### DBSPI-0810: Database ua1p has 1.00 standby archive destinations with errors...............

### Check the database if it PRIMARY or STANDBY - select database_role from v$database;

#### Check the state of the database if it STANDBY
### check last apply standby ###
select database_role from v$database; 

set linesize 300
select * from v$flash_recovery_area_usage; 

select al.thread#,
        al.last_rec "Last Recd",
        la.last_app "Last Applied"
from
  (select thread#, max(sequence#) last_rec
    from v$archived_log
    group by thread#) al,
  (select thread#, max(sequence#) last_app
    from v$archived_log
    where applied='YES' and registrar='RFS'
    group by thread#) la
where al.thread#=la.thread#
and al.thread# != 0
order by al.thread#
/  

##### ORACLE 12C - LAST RECEIVED LAST APPLY

select al.thrd "Thread", almax "Last Seq Received", lhmax "Last Seq Applied"
from (select thread# thrd, max(sequence#) almax
      from v$archived_log
      where resetlogs_change#=(select resetlogs_change# from v$database)
      group by thread#) al,
     (select thread# thrd, max(sequence#) lhmax
      from v$log_history
      where first_time=(select max(first_time) from v$log_history)
      group by thread#) lh
where al.thrd = lh.thrd;

### delete archivelog ###
rman target /
delete noprompt archivelog until sequence 135800 thread 1; 
delete noprompt archivelog until sequence 119540 thread 2;
delete noprompt archivelog until sequence 98380 thread 3;
delete noprompt archivelog until sequence 102600 thread 4;

############################### Check SYSTEM Utilization ####################

Select 
owner,
segment_name,
segment_type, /* TABLE,INDEX */
extents, /* No. of extents in the segment*/
blocks, /* No. of db blocks in the segment*/
bytes /* No. of bytes in the segment*/
From dba_segments
where tablespace_name='SYSTEM'
Order By bytes desc;

###################### Check TABLE SIZE #######################

select segment_name,segment_type,bytes/1024/1024 MB
 from dba_segments
 where segment_type='TABLE' and segment_name='&SEGMENT_NAME';
 
###################### Grand permissions to tables #############
### GRANT [permission which we want] ON [table name] TO [SCHEME NAME]

GRANT DELETE, SELECT ON BMSSA.AVINCENTIVETOTAL TO PURGING;


########################## UNDO RETENTION #####################################

col "UNDO RETENTION [Sec]" for a20
SELECT d.undo_size/1024/1024 as "ACTUAL UNDO SIZE [MByte]", SUBSTR(e.value,1,25) as "UNDO RETENTION [Sec]",
(TO_NUMBER(e.value) * TO_NUMBER(f.value) * g.undo_block_per_sec) / (1024*1024) as "NEEDED UNDO SIZE [MByte]"
FROM (SELECT SUM(a.bytes) undo_size FROM v$datafile a, v$tablespace b, dba_tablespaces c
WHERE c.contents = 'UNDO' AND c.status = 'ONLINE' AND b.name = c.tablespace_name AND a.ts# = b.ts#) d,
v$parameter e, v$parameter f,
(SELECT MAX(undoblks/((end_time-begin_time)*3600*24)) undo_block_per_sec FROM v$undostat) g
WHERE e.name = 'undo_retention' AND f.name = 'db_block_size'
/ 

############ strings - open binary file

########################## MEWA ############################

show pdbs
show con_name


########################### +ASM HINTS################################

1. Login to ASM user
2. type asmcmd to log in
3. asmdsk


######## CODA ######## coda
perfstat
ovcodautil -status
opcagt -status
ovcodautil -dumpds DBSPI_ORA_REPORT
ovcodautil -dumpds ORADB_METRICS
ovcodautil -dumpds ORAUDM_METRICS

root@uv163079 # /opt/OV/bin/ovcodautil -status
ovpa restart coda
ovcodautil -obj | grep -i data  

### IF THERE NO RUNNING [METRIC] ask --- fernando.pereira@hpe.com 


############ CHECK DISKUSAGE

du -h --max-depth=1 | sort -n 

############ CHECK DATABASE FRA / ARCHIVE

SELECT flashback_on, log_mode FROM v$database;

################################### DBSPI40-1: Unable to fetch data from table 'SYS.GV_' [ORA-01013: user requested cancel of current operation].

Check OBJECT VALUE

############## Reject queue for ROUTINE CHANGES FOR ADECCO !!!!!!!!!

E-CHGIMP-ADECCO-REJECT-CE

################ Adecco user passwords --> cd /local/outils/fp
cisadm [WWRWPR11] - RwpSsp_v132 ; C1ssCRum1!
hrsys [HRPSWWP0] - hrwwg0 ; S2R:bxq6
hrsys [HRPSDEP0] - 4jLH8:vh
hrsys [HRPSWWR1] - Hu87zsq9 ; eJW1:Ncg
sysadm [FIPSFRP0] - C:4Hs9oH ;NEW PASS- ms:4w4vs
NOVA [NOVATEST] - PIAF6545
#### ADECCO WINDOWS ROUTINE CHANGES 
ITECFRP0 SYSTEM PASSWORD -> !QAZ2wsx
ITECFRR1 SYSTEM PASSWORD -> pl!er53f
DB -> ITECFRP0 

olecenter - GuepElou1539


#############################

SQL Developer instructions:

username/password:
rman/rman04bkp 

servers:

UAT:    ntintfr06092.emea.adecco.net                  D:\local\sqldeveloper\sqldeveloper.exe              - for requests for databases like xxxxRx
PROD:   ntintfr06093.emea.adecco.net                  D:\local\sqldeveloper\sqldeveloper.exe              - for requests for databases 

#################### ADECCO SYSTEM PASSWORD : !QAZ2wsx


################ ADECCO SQL DEVELOPER

username/password:
rman/rman04bkp 

servers:

UAT:    ntintfr06092.emea.adecco.net                  D:\local\sqldeveloper\sqldeveloper.exe              - for requests for databases like xxxxRx
PROD:   ntintfr06093.emea.adecco.net                  D:\local\sqldeveloper\sqldeveloper.exe              - for requests for databases like xxxxPx 

alter session set current_schema="NL_CORE_ESB_TRANSCO";
alter session set current_schema="EMEA_TIBCO_FUNCTIONAL";
alter session set current_schema="EMEA_CORE_ESB_TRANSCO";
alter session set current_schema="CH_CORE_ESB_TRANSCO";
alter session set current_schema="OPE_OWNER";

GMCUKP_2019_PARTITIONS.sql


############################################### DBSPI-0814: Database GIPPAP media recovery hasn't occurred in the last 8.26 hours. [Policy:DBMON-DBSPI-0814-ARM]
Check the attachment
#### Check alert log for failed sequence !!!

[oracle@sl03059]:GIPPAPS:/oracle/home/oracle# rman target /

Recovery Manager: Release 11.2.0.4.0 - Production on Wed Mar 8 05:19:37 2017

Copyright (c) 1982, 2011, Oracle and/or its affiliates.  All rights reserved.

connected to target database: GIPPAP (DBID=2237916566)

RMAN> restore archivelog sequence 164638; -> AT PRIMARY DATABASE !!!

Starting restore at 30-APR-17
using target database control file instead of recovery catalog
allocated channel: ORA_SBT_TAPE_1
channel ORA_SBT_TAPE_1: SID=37 device type=SBT_TAPE
channel ORA_SBT_TAPE_1: Data Protection for Oracle: version 6.3.0.0
allocated channel: ORA_DISK_1
channel ORA_DISK_1: SID=101 device type=DISK

channel ORA_SBT_TAPE_1: starting archived log restore to default destination
channel ORA_SBT_TAPE_1: restoring archived log
archived log thread=1 sequence=102367
channel ORA_SBT_TAPE_1: reading from backup piece redolog_GIPPAP_942637414_20170430_84740_1.rman
channel ORA_SBT_TAPE_1: piece handle=redolog_GIPPAP_942637414_20170430_84740_1.rman tag=TAG20170430T034333
channel ORA_SBT_TAPE_1: restored backup piece 1
channel ORA_SBT_TAPE_1: restore complete, elapsed time: 00:00:07
Finished restore at 30-APR-17


SQL> alter database recover managed standby database disconnect from session;  -> EXECUTE THE COMMAND ON PHYSICAL STANDBY DATABASE
SQL> alter database recover managed standby database cancel;  -> EXECUTE THE COMMAND ON STANDBY DATABASE IF THE FIRST COMMAND DONT FINISHED, EXECUTE AFTER THAT 1ST AGAIN

############################################### DBSPI-0029: 11.00 sessions waiting for release of a lock for ORTP1_1 >=10. [Policy:DBMON-DBSPI-0029-ARM]

SESSIONS BLOCKING EACHOTHER:

select	'SID ' || l1.sid ||' is blocking  ' || l2.sid blocking
from	v$lock l1, v$lock l2
where	l1.block =1 and l2.request > 0
and	l1.id1=l2.id1
and	l1.id2=l2.id2
/

SHOWS ALL BLOCKING SESSIONS: THIS IS VERY GOOD - BLOCK SESSIONS

select 
   blocking_session, 
   sid, 
   serial#, 
   wait_class,
   seconds_in_wait
from 
   v$session
where 
   blocking_session is not NULL
order by 
   blocking_session;

####### Check the HOLDER reason and when you find it write mail for kill inactive corressondent session.

SHOWW BLOCKING SESSIONS - :)

 set linesize 400
 col MACHINE for a15
 col USERNAME for a10
 col LOGON_TIME for a20 
 col IS_BLOCKING for a15
 col PROGRAM for a15
 select  l1.INST_ID, l1.sid, a.serial#, a.USERNAME, a.PROGRAM,a.MACHINE, TO_CHAR(a.logon_time, 'MM/DD/YY HH24:MI:SS') as logon_time, 'IS_BLOCKING' as IS_BLOCKING,
l2.INST_ID, l2.sid, b.serial#, b.USERNAME, b.PROGRAM, TO_CHAR(b.logon_time, 'MM/DD/YY HH24:MI:SS') as logon_time
     from gv$lock l1, gv$lock l2, gv$session a, gv$session b
    where l1.id1=l2.id1 and l1.id2=l2.id2 and a.SID=l1.sid and b.SID=l2.sid
    and l1.inst_id=l2.inst_id and l2.inst_id=a.inst_id and a.inst_id=b.inst_id  and l1.sid! = l2.sid
    and l1.block =1 and l2.request > 0 order by a.LOGON_TIME; 


##################################################################################################################################################

ORACLE USERNAME

cat /etc/passwd

############################

check dbspicao user 

dbspicfg -e | grep ECOSW

##############################################################################################
############# TNS-12637: Packet receive failed ###############

Sqlnet.ora: SQLNET.INBOUND_CONNECT_TIMEOUT=180
Listener.ora: INBOUND_CONNECT_TIMEOUT_listener_name=120
lsnrctl reload

##################### aon checks ##########

Check calendar ORACLE for procedure

################### AVON - Matthew Sheen/CBY/GB' matthew.sheen@avon.com Richard Thomson/CBY/GB richard.thomson@avon.com

E-CUSTINCSSP-AVON-INFOPS-TECHNICAL-OPS-EMEA
W-INCSSP-AVON-BUR-AAT - BACKUP Team itogdc_avonbackup@dxc.com
dxcavonappdba@dxc.com - AVON APPL DBA
Vempati, Lalitha Manohar <lvempati2@csc.com>; Chapman, Michael <mchapman9@csc.com>  ---> AVON ARLs

################### CANON

E-INCSSP-APPS-DB-ORACLE-CANONNLAIS ---> CANON TAM DB

env | grep CONT ----> CHECK 

BI and BIPST for CAPGEMINI not AT OUR SUPPORT LEVEL !!!! ---> cgoracle

########################## SGA INFORMATION #####################

The following Oracle Database views provide information about the SGA components and their dynamic resizing:

v$sga - Displays summary information about the system global area (SGA).

v$sgainfo - Displays size information about the SGA, including the sizes of different SGA components, the granule size, and free memory.

v$sgastat - Displays detailed information about the SGA.

v$sga_dynamic_components - Displays information about the dynamic SGA components. This view summarizes information based on all completed SGA resize operations since instance startup.

v$sga_dynamic_free_memory - Displays information about the amount of SGA memory available for future dynamic SGA resize operations.

v$sga_resize_ops - Displays information about the last 100 completed SGA resize operations.

v$sga_current_resize_ops - Displays information about SGA resize operations which are currently in progress. An operation can be a grow or a shrink of a dynamic SGA component.
There are simple v$sga scripts to display SGA information:

show parameter sga

SQL> select * from v$sga;

NAME                   VALUE
-------------------- ----------
Fixed Size              456424
Variable Size        503316480
Database Buffers     134217728
Redo Buffers            679936

#### Shared pool
SET LINESIZE 145
SET PAGESIZE 9999
SELECT 'Shared Pool' area, name, sum(bytes)/1024
FROM v$sgastat
WHERE pool = 'shared pool' and
name in ('library cache','dictionary cache','free memory','sql area')
group by name
union all
SELECT 'Shared Pool' area, 'miscellaneous', sum(bytes)/1024
FROM v$sgastat
WHERE pool = 'shared pool' and
name not in ('library cache','dictionary cache','free memory','sql area')
group by pool
order by 3 desc;
/ 

#################### SWAP CHECK ################

ovcodautil -support | grep -i swap

GBL_SWAP_SPACE_UTIL               : 96.00
GBL_SWAP_SPACE_AVAIL              : 16383


####################### 

alter sysyem checkpoint;   --> push DBWn LGWR 

######################## INFRA SPECIFIC

ls -lart .profile_*  --> TO SET ENV VAR

#################### PRIV GRANTS REFERENCE ### JDETESTtt -> the new user which want to have the privileges !!!
--grant privs
set pages 1500
select 'grant '||a.privilege||' to "USERPUBP"'||decode(ADMIN_OPTION,'YES',' WITH ADMIN OPTION','')||';'
from dba_sys_privs a, dba_users b
where a.grantee=b.username
and b.username in ('SAFE_MAIN');

--grant role_rivs
select 'grant '||c.granted_role||' to "USERPUBP"'||decode(ADMIN_OPTION,'YES',' WITH ADMIN OPTION','')||';'
from dba_role_privs c, dba_users d
where d.username=c.grantee
and username in ('SAFE_MAIN');

--grant tab_privs
select 'grant '||e.privilege||' on '||e.owner||'.'||e.table_name||' to "USERPUBP"'||decode(grantable,'YES',' WITH ADMIN OPTION','')||';'
from dba_tab_privs e, dba_users f
where f.username=e.grantee
and username in ('SAFE_MAIN');


SELECT PRIVILEGE, TABLE_NAME from ROLE_TAB_PRIVS WHERE ROLE='RO_CTR';


---QUOTAS
select 'alter user "S_UDI_UCMDB_HPDEX" '||decode(MAX_BYTES,'-1',' quota unlimited',MAX_BYTES)||' on '||TABLESPACE_NAME||';'
from dba_ts_quotas where username in ('UCMDB'); 

################## CHECKING FREE SPACE WINDOWS

fsutil volume diskfree I:



##########################DBA26 template:

CREATE USER "SQL_DGHOSH1"		
IDENTIFIED BY "password_db_2019"
DEFAULT TABLESPACE USERS
TEMPORARY TABLESPACE PSTEMP
PROFILE SOX_USER;

GRANT CONNECT TO "SQL_DGHOSH1";
GRANT CREATE SESSION TO "SQL_DGHOSH1";
GRANT R_SELECT_APPLI to "SQL_DGHOSH1";


SELECT TABLESPACE_NAME, STATUS, CONTENTS FROM DBA_TABLESPACES;
select default_tablespace from dba_users where username like 'SQL_%'; -> CHECK TABLESPACE USE FOR USER

SELECT username FROM dba_users; -> CHECK IF SCHEMA EXIST

set linesize 300
col PROFILE for a9
col RESOURCE_NAME for a25
col RESOURCE for a10
col LIMIT for a15
SELECT * FROM DBA_PROFILES ORDER BY PROFILE;


############################# DBSPI-0065: Core dump device used percentage 99.00% too high for SASCST_P >=98%
############################# DBSPI-0064: User dump device used percentage 99.00% too high for QUOVISPS >=98%

Like UXMON need to free up space. Check the metric for full device.
show parameter dest -> if you dont find the metric
var/spool/clientmqueue/...... -> trancate files NOT_OK


############## RMAN CROSSCHEKED

CROSSCHECK ARCHIVELOG ALL;

list expired archivelog all;

delete expaired archivelog all;

############## AUDI TICKETS

ismg34

##############CHECK QUERY - ORA-01555 

set long 20000
set pages 500
select SQL_FULLTEXT from v$sql where sql_id='88a1qvsh1npy8';
select SQL_TEXT from v$sqltext where SQL_ID='88a1qvsh1npy8';

############## AVON backups
/u84/home/oracle/scripts/rmanscripts/rman_backup11g.ksh gmcgce2p ARCH E

ARCH I - 

############## STOP VAULT 

su - oracle
cd vault
--- stop start sql scripts (inside deicretories)

stop sql - disable vault

from vault user from ESL get vault user (dvowner) (this is a database user !!!)

############## dgmgrl / -> DataGuard login 

DGMGRL> disable configuration
DGMGRL> enable configuration

edit database 'SOSSBY' set state='apply-off';

srvctl status service -d SOSDEV1
srvctl config service -d SOSDEV1 

srvctl stop database -d HGQASE && srvctl start database -d HGQASE -n fivatxa02dbadm01 -o mount
srvctl start database -d BIPRD -n plprdodb202
srvctl start database -d DEMDVS -n pl-snn-db-013 -o mount

srvctl stop instance -d E909 -i E909_1
srvctl start instance -d E909 -i E909_1

srvctl stop database -d FMW2PRD1 && srvctl start database -d FMW2PRD1 -n plprdodb103

srvctl stop instance -d CPQPRD -i CPQPRD1
srvctl stop instance -d SCMD2GRE -i SCMD2GRE2 && srvctl start instance -d SCMD2GRE -i SCMD2GRE2
srvctl start instance -d FMAXPRD -i FMAXPRD1
srvctl remove instance -d CPQPRD -i CPQPRD1


srvctl stop database -d WPSLPRD && srvctl start database -d WPSLPRD -n plprdodb102

srvctl modify database -d EMDMPTI –e cgreofdb04npd,cgreofdb05npd,cgreofdb07npd      (check the inventory if the home is attached to the node)

srvctl relocate service -d A55000 -service T_MBBCDISPAUTHB_2256 -c A55000_2 -n A55000_1
srvctl relocate service -d cdbrac -service JAVA_SERVICE -c cdbrac2 -n cdbrac1

crsctl stop has
crsctl start has

srvctl remove database -d CTECAB

srvctl add database -d CTECAB -oraclehome $ORACLE_HOME -role PRIMARY -spfile "+RAID10/CTECAB/spfileCTECAB.ora" -dbname CTECAB -startoption open -stopoption immediate -instance CTECAB -y AUTOMATIC -a "RAID10,FUSION"

###

dgmgrl
connect /
show configuration -> CHECKING WHICH DATABASES ARE PRIMARY AND STANDBY
show database verbose 'SESLGRE'; -> CHECKING STANBY NODE CURRETLY APPLYING / CHECK NODE NAME

alter system set db_recovery_file_dest_size=750G scope=both sid='*';

############### SQL> show parameter local_listener -> check local listener 

############## nmon
c = CPU
m = Memory
d = Disks
r = RESOURCE
k = kernel
h = more options
l = CPU Long-term
j = Filesystems
n = Network
N = NFS
t = Top-processes
V = Virtual Memory
. = only disds/procs

prstat -u oracle -a -s cpu 0 1 | sed -e '/^$/d;/sleep/d;/Total/d'

########### RELINK

$ORACLE_HOME/bin/relink all


########### PASSWORD REUSED

create profile BOK limit password_verify_function null; 
alter profile BOK limit PASSWORD_REUSE_MAX UNLIMITED; 
alter user HP_DBSPI profile BOK; 
alter user "HP_DBSPI" identified by values '7F455C061214D71B'; 
alter user HP_DBSPI profile DEFAULT;
drop profile BOK; 

create profile BOK limit password_verify_function null; 
alter profile BOK limit PASSWORD_REUSE_MAX UNLIMITED; 
alter profile BOK limit PASSWORD_REUSE_MAX UNLIMITED; 
alter user DBSPI_USER profile BOK; 
alter user "DBSPI_USER" identified by values '4A6D9163FF1B19B1'; 
alter user DBSPI_USER profile DEFAULT;
drop profile BOK; 

########### ADIDAS - DBADMIN RIGHTS NFS

grant read,write,execute on directory GK_PROD to GK_RU_C44X_BO;

########### AWR REPORTS

@$ORACLE_HOME/rdbms/admin/awrrpt.sql


########### STATS PACK:

@$ORACLE_HOME/rdbms/admin/spreport.sql 

########### ash report

@$ORACLE_HOME/rdbms/admin/ashrpt.sql

########### ASH REPORTS

@$ORACLE_HOME/rdbms/admin/ashrpt.sql

########### Oracle DISABLE SCHEDULED JOBS

select 
   job_name, 
   owner, 
   enabled 
from 
   dba_scheduler_jobs;

execute dbms_scheduler.disable('owner.job')

dbms_scheduler.disable (job_name => 'xxxx'); end; /

############ ORACLE JOBS - dba_jobs
select JOB, LOG_USER, PRIV_USER, SCHEMA_USER, BROKEN, FAILURES, WHAT from dba_jobs where JOB='224';

select JOB, LOG_USER, PRIV_USER, SCHEMA_USER, BROKEN, FAILURES, WHAT from dba_jobs where LOG_USER='XAL_SRA'; ---> Check ID which you want to enable or disable
exec dbms_ijob.broken(224); ---> Disable job 1
exec dbms_ijob.broken(224,false); ---> Enable job 1
select ‘exec dbms_ijob.broken(‘||job||’,true);’ from dba_jobs; ---> DISABLE ALL JOBS - DBA_JOBS
select ‘exec dbms_ijob.broken(‘||job||’,false);’ from dba_jobs; ---> ENABLE ALL JOBS - DBA_JOBS
exec dbms_job.run(64); 

exec DBMS_SCHEDULER.DISABLE(name => 'XAL_SRA.AUTOBANK_RUNNER', force => true);


################## AVON FS EXTEND

Current size    Next
0-100     GB          50%
100-300 GB          30%
300-500 GB          20%
500-1000 GB       15%
1000-1500 GB     10%

################## addm reports

rac
@?/rdbms/admin/addmrpti.sql 
@?/rdbms/admin/awrgrpt.sql 

################### ORACLE JOBS

execute dbms_scheduler.disable('XAL_SRA.AUTOBANK_RUNNER')
execute dbms_scheduler.stop_job('XAL_SRA.AUTOBANK_RUNNER')
execute DBMS_SCHEDULER.STOP_JOB

################### ALERT LOG 

##gzip and truncate file
gzip -9cv listener_ddcrepp.log > listener_ddcrepp.log`date +%Y%m%d`.gz && > listener_ddcrepp.log

find . -name "PLS_*.txt" -mtime +131 -exec rm {} \;
find . -name "*.txt" -mtime +160

find /u01/app/product/11.2.0/dbhome_trxp/incident_logs -mtime +5 -exec rm {} \;

#######################
####################### WINDOWS VARAIBLES #############

C:\Users\Rangema>set ORACLE_HOME=d:\o114p064\product\12.2.0\se\

C:\Users\Rangema>set ORACLE_SID=ELWNPRD

C:\Users\Rangema>set PATH=%ORACLE_HOME%/bin;%PATH%

set PATH=%ORACLE_HOME%\bin;%PATH%

#######################
####################### AUDI TRANSFERING TO GERMAN QUEUE

AUDI MSSQL QUEUES:
OPS WEB-EXT-MSSQL-BUL Advanced Support AUDI – Incident handling
OPS WEB-SR-EXT-MSSQL-BUL Advanced Support AUDI – Service Request (and Standard Changes) handling
### GERMANS :
OPS WEB-EXT-DB-GER Advanced Support AUDI ---- PDL SWS GER DB Audi <sws.ger.db.audi@dxc.com> 

OPS WEB EXT TS Rollout AUDI - Developers ?

btw, on future emergency changes, always include audi.morgenrunde@hpe.com  and 'AUDI IN FP-842 Web-Middleware' (Web-Systeme@AUDI.DE) 

ivmg700
con -c P55015 -u hpioshtv

2Start:123456789

====AUDI==
 P951 APEX
 iudb729
 
 ivmg700
su - oracle
geta -u "A4ASWKONAKART" -p  ---> check application, where is running 
geta -s "E_ASWIKI_1648"


[‎3/‎4/‎2019 2:33 PM] Georgiev, Victor (Oracle DBA): 
CHECK Applications:


[oracle@ivmg700(Production) (master) change_passwords]$ geta
2018/06/25 13:10:53 WARNING: run: /dbteam/scripts/connect/get_service_username_for_application.bash -i application_id -n application_name
2018/06/25 13:10:53 WARNING:    -i - give application_id
2018/06/25 13:10:53 WARNING:    -n - give application_name
2018/06/25 13:10:53 WARNING: only one of the parameter have to set
[oracle@ivmg700(Production) (master) change_passwords]$ geta -i 585  
[‎3/‎4/‎2019 2:33 PM] Georgiev, Victor (Oracle DBA): 
No Title
[oracle@ivmg700(Production)  ~]$ geta -help
2019/03/04 13:33:20 WARNING: run: /dbteam/scripts/connect/get_service_username_for_application.bash -i application_id [-n user_application_name] [-s service_name] [-p]
2019/03/04 13:33:20 WARNING:    -n - give user application_name
2019/03/04 13:33:20 WARNING:    -N - give service application_name
2019/03/04 13:33:20 WARNING:    -s - give service name
2019/03/04 13:33:20 WARNING:    -u - give user name
2019/03/04 13:33:20 WARNING:    -p - show the password of user
2019/03/04 13:33:20 WARNING:    -d - show all for db
2019/03/04 13:33:20 WARNING:    -v - show column and ignore AUDI_LOCKEDUSER_PROFILE, Accout_status
2019/03/04 13:33:20 WARNING:
2019/03/04 13:33:20 WARNING: eg:
2019/03/04 13:33:20 WARNING:    /dbteam/scripts/connect/get_service_username_for_application.bash -n '%VIMP%'
2019/03/04 13:33:20 WARNING: one of the parameter have to set
2019/03/04 13:33:20 WARNING: Invalid option: -h
2019/03/04 13:33:20 WARNING: run: /dbteam/scripts/connect/get_service_username_for_application.bash -i application_id [-n user_application_name] [-s service_name] [-p]
2019/03/04 13:33:20 WARNING:    -n - give user application_name
2019/03/04 13:33:20 WARNING:    -N - give service application_name
2019/03/04 13:33:20 WARNING:    -s - give service name
2019/03/04 13:33:20 WARNING:    -u - give user name
2019/03/04 13:33:20 WARNING:    -p - show the password of user
2019/03/04 13:33:20 WARNING:    -d - show all for db
2019/03/04 13:33:20 WARNING:    -v - show column and ignore AUDI_LOCKEDUSER_PROFILE, Accout_status
2019/03/04 13:33:20 WARNING:
2019/03/04 13:33:20 WARNING: eg:
2019/03/04 13:33:20 WARNING:    /dbteam/scripts/connect/get_service_username_for_application.bash -n '%VIMP%'
2019/03/04 13:33:20 WARNING: one of the parameter have to set 


 
 AUDI QUERY --> INCIDENTS

####################### EXECUTION with other USER - adecco

alter session set current_schema =

######################## Procedura pri expired pass na DBSPI monitoringa:

(sl05589:~ # dbspicao -vpdf
Checking instance: 'REX1P' @ '/oracle/11.2.0.4':
2016-02-16T10:14:45 ERROR dbspicao(10) REX1P [cola:ora_util.pc:414]: DBSPI10-23: 
 Unable to connect to database 'REX1P' [ORA-28001: the password has expired])

Proverqvame usera i parolata na monitoringa s dbspicfg -e:
sled koeto se logvame na bazata : sqlplus / as sysdba:
alter user hp_dbspi identified by pass;

proverqvame otnovo s dbspicao -fpdv

Pri nevazmojnost za polzvane na starata parola:

trqbva da se vidi koi mu e profila:
select USERNAME, ACCOUNT_STATUS, DEFAULT_TABLESPACE, TEMPORARY_TABLESPACE, PROFILE from dba_users where USERNAME='HP_DBSPI';

!!!!switch profile to set new pass and revert back to old one.

create profile BOK limit password_verify_function null;
alter profile BOK limit PASSWORD_REUSE_TIME UNLIMITED;
alter profile BOK limit PASSWORD_REUSE_MAX unlimited;
alter profile BOK limit FAILED_LOGIN_ATTEMPTS UNLIMITED;

alter user HP_DBSPI  profile BOK;
alter user HP_DBSPI identified by "hp_dbspi123";
drop profile BOK; 


######################### Check SESSION - progress import

impdp USERID=\"/ as sysdba\" attach="SYSTEM"."SYS_IMPORT_SCHEMA_03" -> change "SYSTEM"."SYS_IMPORT_SCHEMA_03" to NEW VALUE


######################### AVON

Corey, Chris <chris.corey@hpe.com> --- Database Global  
Boronski, Radek <radoslaw.boronski@hpe.com> --- APPLICATION DBA
dxcavonappdba@dxc.com --------> APPLICATION DBA
E-CUSTINCSSP-AVON-DATABASE-SUPT-RU -> AVON ORACLE DBA
E-CUSTINCSSP-AVON-DATABASE-SUPT-RU -> AVON RUSSIA DBA

######################## CHECK ORA

1. with oracle user - SQL> show parameter diag

NAME                                 TYPE                             VALUE
------------------------------------ -------------------------------- ------------------------------
diagnostic_dest                      string                           /u01/app/oracle

1. WRITE with oracle user - adrci


adrci> set base /u01/app/oracle
adrci> show home
ADR Homes:
diag/tnslsnr/cbylxdceomsdb1/listener_1
diag/tnslsnr/cbylxdceomsdb1/listener
diag/tnslsnr/cbylxdceomsdb1/listener_ru2d
diag/tnslsnr/cbylxdceomsdb1/listener_3
diag/tnslsnr/cbylxdceomsdb1/listener_4
diag/tnslsnr/cbylxdceomsdb1/listner_3
diag/tnslsnr/cbylxdceomsdb1/listener_2
diag/clients/user_oracle/host_1606519389_11
diag/clients/user_oracle/host_1606519389_80
diag/rdbms/ce1c/ce1c
diag/rdbms/pl1d/pl1d
diag/rdbms/ce1d/ce1d
adrci> set homepath diag/rdbms/ce1c/ce1c
adrci> show incident -all

######################## ALERT LOG LOCATION -12c

select value from v$diag_info where NAME='Diag Trace';


[oratrxq@husexa2dbadm01 trace]$ pwd
/u01/app/diag/rdbms/trxp/TRXP1/trace
[oratrxq@husexa2dbadm01 trace]$ cd /u01/app/product/11.2.0/dbhome_trxp/rdbms/log

/ua1qarch01/ua1q/standby/
######################## ORACLE 12C - PLUGGABLE

SQL> ALTER SESSION SET container = pdb1;

Session altered.

SQL> SHOW CON_NAME

CON_NAME
------------------------------
PDB1

######################## CHECK TABLE FROM WHICH TABLESPACE 

col owner for a15
col tablespace_name for a15
col table_name for a15
select owner, table_name, tablespace_name from dba_tables where table_name='F0911';

######################## rman
112:ERRORLOG: ORACLE Instance RMAN112

ALTER SYSTEM ARCHIVE LOG ALL;

Connected to:
Oracle Database 11g Enterprise Edition Release 11.2.0.3.0 - 64bit Production
With the Partitioning option

SQL> ALTER SYSTEM ARCHIVE LOG ALL;
SQL> ALTER SYSTEM ARCHIVE LOG ALL
*
ERROR at line 1:
ORA-00271: there are no logs that need archiving

######################### LINUX COMMANDS

free -t -m --> check memory
ps aux  | awk '{print $6/1024 " MB\t\t" $11}'  | sort -n --> check which proccess draining memory

######################### EXPDB 

expdp schemas='PDMUSER','PDMINT','PDM2CBD' directory=DATAPUMP_DIR1 dumpfile=RFC270274_10-12-16_%U.dmp filesize=4G logfile=RFC270274_10-12-16.log parallel=8 FLASHBACK_SCN=803261927 COMPRESSION=ALL 

expdp schemas='TORONTOFC' directory=DATA_PUMP_DIR dumpfile=TORONTOFC_07-12-17_%U.dmp filesize=4G logfile=RFC267658_07-12-17.log parallel=8 FLASHBACK_SCN=803261927 COMPRESSION=ALL 
expdp schemas='COLORADORAPIDS' directory=DATA_PUMP_DIR dumpfile=RFC269920_COLORADORAPIDS_07-12-17_%U.dmp filesize=4G logfile=RFC269920_COLORADORAPIDS_07-12-17.log parallel=8 FLASHBACK_SCN=2111325345 COMPRESSION=ALL
expdp schemas='DCUNITED' directory=DATA_PUMP_DIR dumpfile=RFC270075_DCUNITED_07-12-17_%U.dmp filesize=4G logfile=RFC270075_DCUNITED_07-12-17.log parallel=8 FLASHBACK_SCN=732201268 COMPRESSION=ALL
expdp schemas='VANCOUVERWHITECAPS' directory=DATA_PUMP_DIR dumpfile=RFC270075_VANCOUVERWHITECAPS_07-12-17_%U.dmp filesize=4G logfile=RFC270075_VANCOUVERWHITECAPS_07-12-17.log parallel=8 FLASHBACK_SCN=732201268 COMPRESSION=ALL
expdp schemas='SPORTINGKANSASCITY' directory=DATA_PUMP_DIR dumpfile=RFC270075_SPORTINGKANSASCITY_07-12-17_%U.dmp filesize=4G logfile=RFC270075_SPORTINGKANSASCITY_07-12-17.log parallel=8 FLASHBACK_SCN=1960288754 COMPRESSION=ALL
expdp schemas='ADIDAS17' directory=DATA_PUMP_DIR dumpfile=RFC270075_ADIDAS17_07-12-17_%U.dmp filesize=4G logfile=RFC270075_ADIDAS17_07-12-17.log parallel=8 FLASHBACK_SCN=781746754 COMPRESSION=ALL
expdp tables=TRGW.CARD_TR directory=DATA_PUMP_DIR dumpfile=exp_CARD_TR_102618.dmp logfile=exp_CARD_TR_102618.log 

impdp directory=DATA_PUMP_DIR dumpfile=BMSSA_AVSALESLINE_TABLE_DUMP_08222017.dmp sqlfile=script.sql CONTENT=metadata_only JOB_NAME=imp_BMSSA logfile=BMSSA_AVSALESLINE_TABLE_DUMP_08232017.log 

expdp directory=directory_object_name dumpfile=N-C00990910_%U.dmp TABLES=table_names|TABLESPACES=tablespace_names|FULL=y \ CONTENT=metadata_only

#######ADECCO:
create or replace directory DBEXPORT as '/dbexport/ESB'; ---> FIRST AFTER CHECK !!!
expdp userid=\"/ as sysdba\" full=y directory=DBEXPORT dumpfile=IMESEMR1_%U.dmp logfile=IMESEMR1.log cluster=n parallel=8  

expdp schemas='MDADM' directory=DATA_PUMP_DIR dumpfile=TORONTOFC_07-12-17_%U.dmp filesize=4G logfile=RFC267658_07-12-17.log parallel=8 FLASHBACK_SCN=803261927 COMPRESSION=ALL 


impdp userid=\"/ as sysdba\" DIRECTORY=DATA_PUMP_DIR DUMPFILE=278374_exp_RMA_%U.dmp LOGFILE=imp2_278374_exp_RMA.log SCHEMAS=RMA JOB_NAME=imp_RMA
TABLES:"IN ('TB_ARCH_AREA_ART_TIME_PERIOD', 'TB_ARCH_ART_AREA_SALES_PRICE', 'TB_ARCH_ART_LOCAL_SEL_SIZE', 'TB_ARCH_ARTI_CNTRY_SALES_PRICE', 'TB_ARCH_ARTI_CNTRY_SEL_SIZES', 'TB_ARCH_ARTICLE_FOB_PRICE',  'TB_ARCH_ARTICLE_REGION_SP', 'TB_ARCH_CNTRY_ART_TIME_PERIOD', 'TB_ARCH_CUST_ARTICLE_SELECTION', 'TB_ARCH_CUST_CHANNEL_ARTICLE', 'TB_ARCH_CUST_EXCLUSIVE_ARTICLE', 'TB_ARCH_CUST_SALES_PRICE', 'TB_ARCH_ERROR', 'TB_ARCH_MOD_AREA_TIME_PERIOD', 'TB_ARCH_MOD_LOCAL_SEL_SIZES', 'TB_ARCH_MODEL_CNTRY_SEL_SIZE', 'TB_ARCH_REGION_ARTICLE_TP', 'TB_ARCHIVAL_DATE_UPDATES')" EXCLUDE=STATISTICS parallel=10

select owner, table_name, tablespace_name from dba_tables where owner in &owner order by owner, tablespace_name, table_name;

########## LISTENER CHECK

$ORACLE_HOME/network/admin -> CHECK LISTENER NAME

## WORKGROUPS ##
A-INCFLS-GDO-OVO-GDX - OVO	
E-INCSSP-DINF-OVO - OVO
E-INCSSP-DINF-ESAR - ESAR TEAM QUE
E-INCSSP-VOBE_BHV-TOE-AMOS - AMOS TEAM QUE
E-INCFLS-VOBE_PRIMARY SUPPORT  - VOBE SERVICE DESK 

########## AVON BATCH

E-INCFLS-AVON-BATCH-BLR

################ CHECK CLUSTER RESOURCES

From grid user:

./crsctl stat res -t
ps -ef | grep crs 
cd /u01/app/12.2.0.1/grid/bin

[root@iudb803(Staging) ~]# cd /u01/app/12.2.0.1/grid
[root@iudb803(Staging) grid]# cd bin
[root@iudb803(Staging) bin]# ./crsctl check cluster -all

################## 817 metirc

###LOGICAL STANDBY HOW TO###																
###LOGICAL STANDBY APPLY CHECK ###!!                                                                                                                                        
set lines 300
col REALTIME_APPLY for a15
select * from V$LOGSTDBY_STATE;	


###LOGICAL STANDBY LOG GAP CHECK###
set linesize 400
set pages 600
COL DICT_BEGIN FORMAT A10
col FILE_NAME for a70
col TIMESTAMP for a25
SET NUMF 9999999999999
SELECT FILE_NAME, SEQUENCE# AS SEQ#, NEXT_CHANGE#, to_char(TIMESTAMP, 'YYYY/MON/DD HH24:MI:SS') as TIMESTAMP,
DICT_BEGIN AS BEG, DICT_END AS END, THREAD# AS THR#, APPLIED FROM DBA_LOGSTDBY_LOG
ORDER BY SEQUENCE#; 

### CHECKING SCN IF THEY ARE CHANGING ###
set lines 300
set pages 300
col TYPE for a20
col SID for 4
col SPID for a10
col STATUS for a30
col HIGH_SCN for 9999999999999
select * from V$LOGSTDBY_PROCESS;


    
###LOGICAL STANDBY APPLY RESTART ###	
ALTER DATABASE START LOGICAL STANDBY APPLY IMMEDIATE;

###STOP LOGICAL STANDY BY
ALTER DATABASE STOP LOGICAL STANDBY APPLY;

###START LOGICAL STANDBY
ALTER DATABASE START LOGICAL STANDBY APPLY IMMEDIATE;

###LOGICAL STANDBY SKIP FAILED TRANSACTION ###	
ALTER DATABASE START LOGICAL STANDBY APPLY IMMEDIATE SKIP FAILED TRANSACTION;

ALTER DATABASE START LOGICAL STANDBY APPLY SKIP FAILED TRANSACTION;

 
########## PROMPT  Report archive gaps
 
select thread#, low_sequence#, high_sequence#
from  v$archive_gap
/ 


###LOGICAL STANDBY FAILED TRANSACTIONS CHECK###
SET LINESIZE 200
SET LONG 400 
SET PAGESIZE 999
column EVENT_TIME FORMAT A20 
column STATUS FORMAT A70
column EVENT FORMAT A100
SELECT TO_CHAR(EVENT_TIME,'YYYY/MM/DD HH24:MI:SS') "EVENT_TIME", STATUS, EVENT FROM DBA_LOGSTDBY_EVENTS where EVENT_TIME > sysdate -1 ORDER BY EVENT_TIME; 

####### CHECK FOR ARCHIVELOG GAPHS

select * from v$archive_gap; 

####### DDL Extract

select dbms_metadata.get_ddl('TRIGGER','TR_554311','PRODDTA') from dual;
									   (trigger_name),(schema)

######## GATHER STATISTICS

EXEC dbms_stats.gather_table_stats('ASLF_SA','AVLATTRIBVALUES',cascade=>TRUE);

ASLF_SA.AVLATTRIBVALUES


######## OGE Service Desk GERMAN - E-INCFLS-OGE-GSD


###### dba_sys_privs , dba_role_privs, dba_tab_privs ---> user privs


######## CHECK FLASHBACK_LOGS

select log_mode,flashback_on from v$database;

-->If FLASHBACK_LOGS -> alter database flashback off; AND THEN ->> alter database flashback on;

######## DBSPICO ASM CHECK

dbspicao -m334

######## DBSPICAO TEMP EXCLUDE

/var/opt/OV/bin/instrumentation/dbmon-event.cfg -> !ORA-<<#> -eq 1652>
!ORA-<<#> -eq 1652>
!ORA-<<#> -eq 01652>
!ORA-1652
!ORA-01652

deheremcln304
deheremcln347.emea.adsint.biz
deheremcln220.emea.adsint.biz
deheremcln260.emea.adsint.biz
deheremcln312.emea.adsint.biz

############
#######################################################
Server : ryelxwebeqfdbc1:     (old not usable-ryelxwebeddb2)

ps -ef |grep pmon|grep webeceqf
oracle    1114     1  0  2016 ?        00:31:59 ora_pmon_webeceqf
[root@ryelxwebeqfdbc1 ~]# ps -ef |grep pmon|grep webeplqf
oracle   11823     1  0  2016 ?        00:30:30 ora_pmon_webeplqf
[root@ryelxwebeqfdbc1 ~]# ps -ef |grep pmon|grep weberuqf
oracle   14188     1  0  2016 ?        00:25:28 ora_pmon_weberuqf
[root@ryelxwebeqfdbc1 ~]# ps -ef |grep pmon|grep webetrqf
oracle   22304     1  0  2016 ?        00:28:52 ora_pmon_webetrqf
[root@ryelxwebeqfdbc1 ~]# ps -ef |grep pmon|grep webeukqf
oracle   21342     1  0  2016 ?        00:29:14 ora_pmon_webeukqf
[root@ryelxwebeqfdbc1 ~]# ps -ef |grep pmon|grep webgceqf
oracle   20497     1  0  2016 ?        00:58:11 ora_pmon_webgceqf
[root@ryelxwebeqfdbc1 ~]# ps -ef |grep pmon|grep webgplqf
oracle    8874     1  0  2016 ?        00:41:52 ora_pmon_webgplqf
[root@ryelxwebeqfdbc1 ~]# ps -ef |grep pmon|grep webgruqf
oracle   23822     1  0  2016 ?        00:30:37 ora_pmon_webgruqf
[root@ryelxwebeqfdbc1 ~]# ps -ef |grep pmon|grep webgtrqf
oracle    7133     1  0  2016 ?        00:32:15 ora_pmon_webgtrqf
[root@ryelxwebeqfdbc1 ~]# ps -ef |grep pmon|grep webgukqf
oracle    5685     1  0  2016 ?        00:45:39 ora_pmon_webgukqf

######################################################## - MIGRATED
Server: ryelxwebeddbc1 (old not usable-ryelxwebeddb1):

[root@ryelxwebeddbc1 ~]# ps -ef |grep pmon|grep webeeud
oracle    3193     1  0 Feb23 ?        00:08:36 ora_pmon_webeeud
[root@ryelxwebeddbc1 ~]# ps -ef |grep pmon|grep weberud
oracle   10309     1  0 Feb23 ?        00:06:23 ora_pmon_weberud

#######################################################
Server: dlslxwebecmpdb1 (old not usable-ryelxwebeqdb1):

[root@dlslxwebecmpdb1 ~]# ps -ef |grep pmon|grep webeeuc
oracle   16482     1  0  2016 ?        00:12:00 ora_pmon_webeeuc
[root@dlslxwebecmpdb1 ~]# ps -ef |grep pmon|grep webgeuc
oracle   29770     1  0 Feb10 ?        00:16:01 ora_pmon_webgeuc
[root@dlslxwebecmpdb1 ~]# ps -ef |grep pmon|grep webgruc
oracle     612     1  0  2016 ?        00:13:47 ora_pmon_webgruc
[root@dlslxwebecmpdb1 ~]# ps -ef |grep pmon|grep weberuc
oracle    9305     1  0  2016 ?        00:11:11 ora_pmon_weberuc

#######################################################
Server: dlslxwebeeuqdb1.dc.avon.net 
[root@dlslxwebeeuqdb1 ~]# ps -ef |grep pmon|grep webeukqp
oracle   14675     1  0 Mar05 ?        00:04:19 ora_pmon_webeukqp
[root@dlslxwebeeuqdb1 ~]# ps -ef |grep pmon|grep webeplqp
oracle   21051     1  0  2016 ?        00:07:05 ora_pmon_webeplqp

#######################################################
Server: dlslxwebeeuqdb2.dc.avon.net 
[root@dlslxwebeeuqdb2 ~]# ps -ef |grep pmon|grep webeceqp
oracle   21498     1  0  2016 ?        00:10:35 ora_pmon_webeceqp
[root@dlslxwebeeuqdb2 ~]# ps -ef |grep pmon|grep webetrqp
oracle   11493     1  0 Apr26 ?        00:01:59 ora_pmon_webetrqp


[root@ryelxwebeqdb1 ~]# ps -ef |grep pmon|grep weberuqp
oracle   13697     1  0  2016 ?        00:15:01 ora_pmon_weberuqp


### USER CREATION WITH MIMIC WITH EXISTING USER ###
create user "SA_READ" identified by "FgtYEv5Dtj" default tablespace "TANGO_TABLES" temporary tablespace "TEMP2" profile ESL_PROFILE;
GRANT CREATE SESSION TO SA_READ WITH ADMIN OPTION;
GRANT CREATE DATABASE LINK TO SA_READ;

set linesize 200;
select 'create user "ESLINTAPP11" identified by "DjV59VYzI9" default tablespace '|| default_tablespace ||' temporary tablespace '|| temporary_tablespace ||' profile '|| profile ||';' from dba_users where username='ESLROUSER'; 


set pages 2000
set lines 400
select 'grant '||granted_role||' to "SA_READ";' from dba_role_privs where grantee='ESLROUSER';
select 'grant '||privilege||' to "SA_READ";' from dba_sys_privs where grantee='ESLROUSER';
select 'grant '||privilege||' on '|| table_name||' to "SA_READ";' from dba_tab_privs where grantee='ESLROUSER';
GRANT CREATE SESSION TO ESLINTAPP11 WITH ADMIN OPTION;
GRANT CREATE DATABASE LINK TO ESLINTAPP11; 


############################## AUDI

P -> LiVe
T -> PreLive
E/TUI/DEV -> Development

############################# MOUNT DRIVE - WINDOWS

mount -t cifs  "//cbymspwefs1/Finance/Tax 08012008/Invoice" /mnt -o username=rangemar

Run the following command to map the shared folder: net use [LocalFolder] \\[CIFSServer]\[ShareFolder] [{Password | *}] /user:[DomainName\][UserName] /persistent:yes

############################# MOUNT DRIVE - LINUX
#On the 'server' add an entry into your /etc/exports to share the directory e.g.

/directory/with/data secondserver.tld(rw)
#which allows secondserver read/write access to the directory/with/data
#then use exportfs to share the directory

exportfs -r

#and you can verify your export with

exportfs
/directory/with/data    secondserver.tld

#You can now mount your directory on secondserver

mount server:/directory/with/data /mnt

#and you can verify the mount

mount -t nfs
server:/directory/with/data on /mnt type nfs (rw,addr=192.168.254.196)

mount -t cifs  "//cbymspwefs1/Finance/Tax 08012008/Invoice" /mnt -o username=rangemar


################# HOW TO RESTORE #####################

SQL> SQL> SELECT name FROM v$datafile WHERE file#=32;

NAME
--------------------------------------------------------------------------------
/emc03/oradata/IMAN/kingfisher_data01.dbf

/emc03/oradata/IMAN/kingfisher_data02.dbf
/emc03/oradata/IMAN/users01.dbf
/emc03/oradata/IMAN/biadmin_01.dbf
/emc03/oradata/IMAN/tb_admin_01.dbf

ALTER DATABASE DATAFILE '/emc03/oradata/IMAN/tb_admin_01.dbf' OFFLINE;

cd /tmp/rman

vi restore_chetiri.rcv ---> WRITE THE INFORMATION BELOW TO THE FILE

run {
    allocate channel ch1 type = 'SBT_TAPE';
    send 'NSR_ENV=(NSR_SERVER=nsrhost,NSR_GROUP=AVON Weekly group 2,NSR_DATA_VOLUME_POOL=AVON Weekly 2,NSR_SAVESET_RETENTION=30 DAYS,NSR_SAVESET_EXPIRATION=30 DAYS)';
    RESTORE DATAFILE '/emc03/oradata/IMAN/tb_admin_01.dbf';
    RECOVER DATAFILE '/emc03/oradata/IMAN/tb_admin_01.dbf';
}


nohup rman target / CMDFILE=/tmp/rman/restore_full2.rcv LOG=restore_full2.log & 
nohup /usr/openv/netbackup/scripts/Oracle/archive_log_backup_od.sh &


vi restore_full2.rcv


run {
    allocate channel ch1 type = 'SBT_TAPE';
    send 'NSR_ENV=(NSR_SERVER=nsrhost,NSR_GROUP=AVON Weekly group 2,NSR_DATA_VOLUME_POOL=AVON Weekly 2,NSR_SAVESET_RETENTION=30 DAYS,NSR_SAVESET_EXPIRATION=30 DAYS)';
    RESTORE DATABASE;
	RECOVER DATABASE;
}


send 'NSR_ENV=(NSR_SERVER=nsrhost,NSR_GROUP=AVON Weekly group 2,NSR_DATA_VOLUME_POOL=AVON Weekly 2,NSR_SAVESET_RETENTION=30 DAYS,NSR_SAVESET_EXPIRATION=30 DAYS)'; 

###################### CHECK TAPE ##################

mminfo -s nsrhost -avot | grep -i PL1P | grep HOTW_PL1P_k0st84kq ----> find backup pieces with name "HOTW_PL1P_m3stb3a8" (backup piece was foudn with name 009667L4 and was used with below command !!!)

mminfo -avot -s nsrhost -q volume=007768L4 -r location -----> if OUTPUT is OFFSITE the casette is not there


#################### RESTORE #######################

SQL> SELECT GROUP#, STATUS, MEMBER FROM V$LOGFILE;
   GROUP# STATUS  MEMBER

SQL> recover database until cancel

alter database open resetlogs;

#################### UNIX Utilization #####################

UNIX95= ps -e -o pcpu -o ruser -o args|sort -nr|grep -v %CPU|head -10 
/opt/OV/bin/ovcodautil -support
/opt/OV/bin/ovcodautil -support |grep -i cpu
/opt/OV/bin/ovcodautil -support |grep -i swap
/opt/OV/bin/ovcodautil -support | grep -i mem 

[oracle@iudb928(Production) ~]$ uname -a
Linux iudb928 4.1.12-124.17.2.el7uek.x86_64 #2 SMP Tue Jul 17 20:28:07 PDT 2018 x86_64 x86_64 x86_64 GNU/Linux



########################### CHECK USER PRIVIGLIES ########################

set long 5000
SELECT dbms_metadata.get_ddl('USER','ctm') FROM dual;
SELECT DBMS_METADATA.GET_GRANTED_DDL('ROLE_GRANT','ctm') from dual;
SELECT DBMS_METADATA.GET_GRANTED_DDL('OBJECT_GRANT','ctm') from dual;
SELECT DBMS_METADATA.GET_GRANTED_DDL('SYSTEM_GRANT','ctm') from dual; 



############################## ACTIVE DUBLICATE ##################

TARGET = Source

Auxilary = Destination

############################# ORACLE JOBS #############

select * from dba_jobs_running where job = 48;


############################ PUBLIC LINK
CREATE PUBLIC DATABASE LINK "EDWHTOETLPRD" connect to "BI_DACREP" identified by "tgv_876TGB" using '(DESCRIPTION = (ADDRESS = (PROTOCOL = TCP)(HOST = odb-prd-2.canonhosted.net)(PORT = 1542)) (CONNECT_DATA = (SERVER = DEDICATED) (SERVICE_NAME = ETLPRD)))';

############################## LOGISTA - pdl-bulgaria-south-logista-oracle@dxc.com

To set the environment : /home/oracle/scripts and run . setsid.sh 

###################### LISTENER MANUAL START FOR CLUSTER

srvctl start SCAN

srvctl start nodeapps -n [node]

###################### AUDI - T906 cannot remove invalid objects

######################

Such requests are logged in via service catalogue request.
Below you may find procedure on how to open such:
http://shareit.global.avon.com/sites/GNCS/HP/Shared%20Documents/Internal%20Controls%20and%20Access%20Lists/DB_Account_Management/DB_Account_Access_Request_Procedure_HPE_Service_Catalog_ReadMe.rtf 

###################### MEMORY UTILIZATION

free | awk '/Mem/{print ("Used memory is"),($3/$2)*100,("%")}' ; free | awk '/Swap/{print ("Used swap is"),($3/$2)*100,("%")}' 

/opt/OV/bin/ovcodautil -support | grep -i mem

###################### WAHT UTILIZAE MEMORY

UNIX95= ps -e -o vsz,uid,pid,ruser,args |sort -rn| head -10

####################### LOGICAL

Bug 21893235 - SQL apply slow with reader ORA-16127 preparer ORA-16117 (Doc ID 21893235.8) 


###### HUBS #######

Galia - Flemish, Adecco


############################## sftp example ################################

lxintfr10381.fr.adecco.net(oralea):RAC(AGOLFRR1)/local/AGOLFRR1/admin/migration > sftp mnt_lea@lx008093.lcedmz.adecco.net
mnt_lea@lx008093.lcedmz.adecco.net's password: Zm9TGC3n
Connected to lx008093.lcedmz.adecco.net.
sftp> ls
2017                                                                                          ADHOC

###########################

SELECT DBMS_METADATA.GET_DDL('PROCEDURE','OBR_ARQMAG_NFE_BH_EXP','SYNCHRO') FROM dual;

########################### EXTRACT DDL


set long 9999999;

select dbms_metadata.get_ddl('PACKAGE','PA_ServiceReporting','OPE_OWNER') from dual;

select dbms_metadata.get_ddl('PACKAGE','XMLPARSER','SYS') from dual;

select dbms_metadata.get_ddl('PACKAGE_BODY','STATSPACK','PERFSTAT') from dual;

select dbms_metadata.get_ddl('PROCEDURE','ORA$_SYS_REP_AUTH','SYSTEM') from dual;

select dbms_metadata.get_ddl('SEQUENCE','STATS$SNAPSHOT_ID','PERFSTAT') from dual;

select dbms_metadata.get_ddl('SYNONYM','/2fddc42_paintARGB_PRE_ONTO_S5','PUBLIC') from dual;

select dbms_metadata.get_ddl('TABLE','SQLEXPERT_PLAN1','SYSTEM') from dual;

select dbms_metadata.get_ddl('TABLESPACE','EPB_TABLES') from dual;

select dbms_metadata.get_ddl('TRIGGER','DEF$_PROPAGATOR_TRIG','SYSTEM') from dual;

select dbms_metadata.get_ddl('TYPE','XMLSEQ_IMP_T','SYS') from dual;

select dbms_metadata.get_ddl('TYPE_BODY','ORACLE_LOADER','SYS') from dual;

select dbms_metadata.get_ddl('VIEW','DBA_PROPAGATION','SYS') from dual;

select dbms_metadata.get_ddl('USER','DCTM_EFILE') from dual;
select dbms_metadata.get_granted_ddl('SYSTEM_GRANT','DCTM_EFILE') from dual;
select dbms_metadata.get_granted_ddl('OBJECT_GRANT','DCTM_EFILE') from dual;
select dbms_metadata.get_granted_ddl('ROLE_GRANT','DCTM_EFILE') from dual; 

SELECT dbms_metadata.get_ddl('ROLE','role') FROM dual;
SELECT DBMS_METADATA.GET_GRANTED_DDL('ROLE_GRANT', 'role') FROM dual;
SELECT DBMS_METADATA.GET_GRANTED_DDL('SYSTEM_GRANT', 'role') FROM dual;
SELECT DBMS_METADATA.GET_GRANTED_DDL('OBJECT_GRANT', 'role') FROM dual;

SELECT DBMS_METADATA.GET_DDL('INDEX','IDX_IOS_001','ESL') from dual;
SELECT DBMS_METADATA.GET_DDL('PROFILE','PROFILE_NAME') from dual;  

###########################################################check FS usage HP-UX
df -Pk | awk '
BEGIN {print "Filesystem                   \t Total GB  \t Avail GB \t Used GB\t Used%\t Mount Point"
       print "-------------------------------\t ------------\t ------------\t ------------\t ------\t -----------------------------"}
END {print ""}
/dev/ || /^[0-9a-zA-Z.]*:\// {
printf ("%-25s\t %10.2fG\t %10.2fG\t %10.2fG\t %4.0f%%\t %-25s\n",$1,$2/1024/1024,$4/1024/1024,$3/1024/1024,$5,$6)
}' 


############################################################## how ot check if there are free space available on the disk

df -h -> take volume group

vgs 

lsvg -> HP-UX , AIX


root@sv930 @ (/root) # /usr/sbin/cmviewcl

CLUSTER        STATUS
cl_infop       up

  NODE           STATUS       STATE
  sv929          up           running
  sv930          up           running

    PACKAGE        STATUS        STATE         AUTO_RUN     NODE
    pkg_infop      up            running       enabled      sv930


############################################################### ALTER SYSDATE

alter session set nls_date_format="dd-mm-yyyy"

############################################################### The configuration file /var/opt/OV/dbspi/dbtab does not exist. Please configure this node.

[‎10/‎3/‎2018 12:21 PM] Getovski, Dimitar (Oracle South Hub DBA): 
dbspicfg.sh
triesh vsi4ko bez
SYNTAX_VERSION 4 
i save

############################################ AVON-BATCH-BLR

ryelxwebeddbc1.dc.avon.net 
All GI3 DEV DBs are now running in Dallas on ryelxwebeddbc1.dc.avon.net/ ryelxwebeddbc1.rye.avon.com (both these names are pointing to the same Dallas IP: 10.200.130.112) 

############################################ DATAGURAD CHECK
SQL> show parameter fal

NAME                                 TYPE        VALUE
------------------------------------ ----------- ------------------------------
fal_client                           string
fal_server                           string      bisby

######################################## FCC

. setenvdb

ROOT -> Fl19plbt#

################### FORTUM FMAXPRD SMAXTRN

root:  udevadm trigger

################### ADECCO APPLY STOP START LEADG_M0 - > AGOLFRP0(PROD) / AGOLFRR1(UAT) -- LEA

"Before sorry pages to be deactivated DB team must execute the following commands:
exec dbms_apply_adm.stop_apply('OLEADM_QUICK_QUEUE_APPLY');
exec dbms_apply_adm.start_apply('OLEADM_QUICK_QUEUE_APPLY');"

################### FS POWERSHELL

Clear-Host
Get-WmiObject Win32_logicaldisk -ComputerName LocalHost `
| Format-Table DeviceID, MediaType, `
@{Name=" Size(GB)";Expression={"{0,9:N2}" -f(($_.size/1gb).tostring("0.00"))}}, `
@{Name="Free Space(GB)";Expression={"{0,14:N2}" -f(($_.freespace/1gb).tostring("0.00"))}}, `
@{Name="   Free (%)";Expression={"   {0,6:P2}" -f(($_.freespace/1gb) / ($_.size/1gb))}} `
-AutoSize

########## DELETION OF ARCHIVELOG MANUALLY
crosscheck archivelog all;
list expired archivelog all;
delete expired archivelog all;
list expired archivelog all;
list archivelog all; 

########## NET BACKUP - SIDEL

C:\Program Files\VERITAS\NetBackup\scripts\Oracle -> START script from here

########## REFRESH PROGRESS

SELECT decode(context,1,'This Task:',2,'Agregate:','?') Context, sofar, totalwork, round(sofar/totalwork*100,2) "% Complete"
FROM v$session_longops
WHERE opname LIKE 'RMAN%'
AND opname LIKE '%aggregate%'
AND totalwork != 0
AND sofar <> totalwork
UNION
SELECT decode(context,1,'This Task:',2,'Agregate:','?') Context, sofar, totalwork, round(sofar/totalwork*100,2) "% Complete"
FROM v$session_longops
WHERE opname LIKE 'RMAN%'
AND opname NOT LIKE '%aggregate%'
AND totalwork != 0
AND sofar <> totalwork; 

########### SKF 

x0045
/home/oracle/scripts/hauzer/Marco
scripta se kazva run_marco.sh
(database=airora02) - schema VISIO325

############ nmtui -> LAN/Network configuration GRAPHIC


############ set define off


############ FIND ASM SPFILE

[grid@fivatx0206 bin]$ crsctl stat res ora.asm -p | egrep "ASM_DISKSTRING|SPFILE"
ASM_DISKSTRING=AFD:*
SPFILE=+FLASH/ASM/ASMPARAMETERFILE/registry.253.961855501


[‎3/‎14/‎2019 4:23 AM] Argirov, Stoyan (RDC Bulgaria Shift Manager): 
а от кой eNote ти идват, че аз не съм си правил да ми идват 
ams, apj, emea? 
чакай ти ги дам и трите и се орпавяй :D 
https://ap.svcs.entsvcs.net/enote/Default.aspx - apj 
[‎3/‎14/‎2019 4:24 AM] Argirov, Stoyan (RDC Bulgaria Shift Manager): 
https://eu.svcs.entsvcs.net/enote/Default.aspx  - emea
https://am.svcs.entsvcs.net/enote/Default.aspx  - ams 


#################### UPDATE OR CREATE VIEW

CREATE or REPLACE VIEW FLASHREPORTS.RDB_DEBTABLEMIN AS
SELECT
.............
FROM
.............
WHERE....................;

