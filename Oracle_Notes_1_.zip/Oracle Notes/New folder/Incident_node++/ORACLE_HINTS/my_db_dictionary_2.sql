=============================================================================================================
 CLEARING THE FILE SYSTEM
=============================================================================================================

[‎11/‎1/‎2018 11:35 AM]  Asenov, Pavel (Oracle TS):  
gzip -9cv oramgw-BILL_AGENT-sehdcx0008.adinfra.net-20180825092327-6587.log> oramgw-BILL_AGENT-sehdcx0008.adinfra.net-20180825092327-6587.log`date +%Y%m%d`.gz && >oramgw-BILL_AGENT-sehdcx0008.adinfra.net-20180825092327-6587.log
gzip -9cv alert_PUBP.log> alert_PUBP.log.`date +%Y%m%d`.gz && >alert_PUBP.log  ----> gzip na alert loga
gzip -9cv werknemer.log> werknemer.log.`date +%Y%m%d`.gz && >werknemer.log
gzip -9cv arbeidsrelatie.log>arbeidsrelatie.log.`date +%Y%m%d`.gz && >arbeidsrelatie.log
gzip -9cv listener_scan1.log>listener_scan1.log.`date +%Y%m%d`.gz && >listener_scan1.log
gzip -9cv listener_scan2.log>listener_scan2.log.`date +%Y%m%d`.gz && >listener_scan2.log
gzip -9cv listener.log>listener.log.`date +%Y%m%d`.gz && >listener.log
gzip -9cv mw_status>mw_status.`date +%Y%m%d`.gz && >mw_status 
gzip -9cv alert_iiqPP2.log>alert_iiqPP2.log.`date +%Y%m%d`.gz && >alert_iiqPP2.log
 
 find . -xdev -mtime +1 -name "*.hprof" -type f -exec gzip -9f {} \;
 find . -xdev -mtime +3 -name "log_*.xml*" -type f -exec rm {} \;
nohup find . -xdev -mtime +1 -name "*.aud*" -type f -exec rm {} \; &
nohup  find . -xdev -mtime +1 -name "*.trc*" -type f -exec rm {} \; &
 nohup  find . -xdev -mtime +1 -name "*.trc*" -type f -exec rm {} \; &
find . -xdev -mtime +1 -name "log_*.xml" -type f -exec gzip -9f {} \;
find . -xdev -mtime +1 -name "core_*" -type f -exec rm -rf  {} \;
 find . -xdev -mtime -1  -exec ls -la {} \; 
 
=============================================================================================================
 CREATING NEW DATAFILE
=============================================================================================================

df -a,h,k, and more ----> file system disk space check

tablespace TABLESPACENAME add datafile '/db/SM920/dat/sm08.dbf' size 100m autoextend on;

=============================================================================================================
 RESIZING DATAFILE
=============================================================================================================

df -a,h,k, and more ----> file system disk space check

alter database datafile '/db/SM920/dat/sm01.dbf' resize 23G;

=============================================================================================================
 FILESYSTEM CHECK SPACE
=============================================================================================================

df -Pk | awk '
BEGIN {print "Filesystem                   \t Total GB  \t Avail GB \t Used GB\t Used%\t Mount Point"
       print "-------------------------------\t ------------\t ------------\t ------------\t ------\t -----------------------------"}
END {print ""}
/dev/ || /^[0-9a-zA-Z.]*:\// {
printf ("%-25s\t %10.2fG\t %10.2fG\t %10.2fG\t %4.0f%%\t %-25s\n",$1,$2/1024/1024,$4/1024/1024,$3/1024/1024,$5,$6)
}'

=============================================================================================================
 TABLESPACENAME INFO 
=============================================================================================================

set linesize 400
set pages 500
col FILE_NAME for a72
col TABLESPACE_NAME for a20
select file_id,FILE_NAME, TABLESPACE_NAME, (increment_by*(bytes/blocks))/1024 increment_by_kb, BYTES/1024/1024, MAXBYTES/1024/1024, 
AUTOEXTENSIBLE from dba_data_files where TABLESPACE_NAME='&tablespace_name';

--------------------------------------------------------------------------------------------------------------

set linesize 400
col FILE_NAME for a70
select file_id,FILE_NAME, TABLESPACE_NAME, BYTES/1024/1024, MAXBYTES/1024/1024, AUTOEXTENSIBLE, 
(increment_by*(bytes/blocks))/1024 increment_by_kb from 	dba_data_files where TABLESPACE_NAME='&tablespace_name' order by 1;

--------------------------------------------------------------------------------------------------------------

set linesize 400             
col FILE_NAME for a70
select file_id,FILE_NAME, TABLESPACE_NAME, BYTES/1024/1024, MAXBYTES/1024/1024, AUTOEXTENSIBLE, (increment_by*(bytes/blocks))/1024 increment_by_kb from 	
dba_data_files where TABLESPACE_NAME='ALERTRAN_DATOS' order by 1;
	
=============================================================================================================
 DBSPICAO Monitoring tool
=============================================================================================================

dbspicao -m(metrika) -r1 -i(instance)    ------> proverqva dadenata metrika
dbspicao -vdfp   ------> check connectivity
dbspicao -e    ------> check the filtered tablespaces

=============================================================================================================
 CHECK FOR STANDBY
=============================================================================================================

show parameter file
show parameter fal

=============================================================================================================
 DBSPI-0058
=============================================================================================================

1. Running the metric: dbspicao -m58 -r1 -i <db_name>
2. Checking in ESL for backup specifications,
3. In another terminal/putty checking for backup specifications: crontab -l, or in rman target / type: list backup of archivelog all;






## If the backup did not clear the fs, on which is bachup located, use this:
DELETE FORCE NOPROMPT ARCHIVELOG ALL BACKED UP 1 TIMES TO DEVICE TYPE sbt;



set linesize 400
set pages 500
col FILE_NAME for a72
col TABLESPACE_NAME for a20
select file_id,FILE_NAME, TABLESPACE_NAME, (increment_by*(bytes/blocks))/1024 increment_by_kb, BYTES/1024/1024, MAXBYTES/1024/1024, AUTOEXTENSIBLE from dba_data_files where TABLESPACE_NAME='&tablespace_name'; 
 
 
################################ DBSPI-0058: Archive free space percentage 22.72% too low for archive device \oracle\RMAN112\fra for RMAN112 <=30%. [Policy:DBMON-DBSPI-0058-ARM] ################

crontab -l ----> proverka na bekupite

omnistat -det --> check for BACKUPS

Run backUP : nohup /opt/omni/bin/omnib  -Oracle8 sl72112_ora_test_MENAQ_daily_arch_del &

nohup  ./arch1.sql > arch1.log 2>&1 &

LOCATION=/wisk7_p/orabck/temp_arch_dest VALID_FOR=(ALL_LOGFILES,PRIMARY_ROLE) DB_UNIQUE_NAME=WISK7_P


windows

C:\Program Files\OmniBack\bin\omnib> -oracle8 clintfr10656_AGOLFRP0_ARC 
"C:\Program Files\OmniBack\bin> -oracle8 mewa_defradb811_ora_MIDSYS35_arch_del
"C:\Program Files\OmniBack\bin\omnib.exe" -oracle8 fivats0063_ELWNPRD_archivelog_on

RMAN> list backup of archivelog all  -------> pokazva vsichki vidove backup-i
RMAN> list backup of database summary;
RMAN> list backup of database completed after 'sysdate-15';

rman cmdfile=backup_online_arch_.rman log=backup_online_arch_`date +%Y%m%d%H%M`.log
example: rman cmdfile=backup_online_arch_OSTST.rman log=backup_online_arch_OSTST`date +%Y%m%d%H%M`.log -> backup_online_arch_OSTST.rman (example)

EON SPECIFIC backup : cd /tsm/TCTSP01/StartRedolog.sh

ARCHIVE DEST SPACE UTILIZATION:

PROMPT Archivelog Space Report
col limit format 999,999,999 heading "Limit (mb)";
col used format 999,999,999 heading "Space Used (mb)";
col free format 999,999,999 heading "Space Free (mb)";
select space_limit/(1024*1024) limit
, (space_used + space_reclaimable)/(1024*1024) used
, (space_limit-(space_used+space_reclaimable))/(1024*1024) free
,number_of_files
from v$recovery_file_dest
/

set linesize 300
select * from v$flash_recovery_area_usage;

set linesize 300
show parameter db_recovery_file_dest;
 

alter system set log_archive_dest=[the new space]

alter system set log_archive_dest_1='location="/oracle/GIWCCP/oraarch", valid_for=(ALL_LOGFILES,ALL_ROLES)'; -----> desta vaji za WISK7_P

alter system set log_archive_dest_1='LOCATION=/oracle/oraarch/HRSOA_P'; -----> 

alter system set log_archive_dest_1='LOCATION=/wisk7_p/orabck/temp_arch_dest VALID_FOR=(ALL_LOGFILES,PRIMARY_ROLE) DB_UNIQUE_NAME=WISK7_P';  ------> switch 
alter system set log_archive_dest_1='LOCATION=/wisk7_p/oraarch VALID_FOR=(ALL_LOGFILES,PRIMARY_ROLE) DB_UNIQUE_NAME=WISK7_P'; -----> originalen des


RMAN> delete noprompt archivelog all backed up 1 times to SBT; 
delete noprompt archivelog all backed up 1 times to DISK;
--- delete all backed up 1 time to tape

alter system set db_recovery_file_dest_size=1200G scope=both sid='*'; ----> vdigame size-a na FRA-to 

### IF DATABASE HANG -> SQL> alter system set db_recovery_file_dest='+LEADG_M0' (some location that have space)

select log_mode,flashback_on from v$database;
---> If FLASHBACK_LOGS -> alter database flashback off; AND THEN ->> alter database flashback on;

select database_role from v$database; - check if the databaseFault is not on STANDBY !!! ------ DBSPICAO813

select * from v$flash_recovery_area_usage;

select TIMESTAMP, MESSAGE FROM v$dataguard_status; -> 813 METRIC check for ERRORS
alter system archive log current; -> SWITCH ARCHIVELOG so much times which is nessary for cleaning 813 metric 


crosscheck archivelog all;   ------> crosscheck markva expired archivelog-ovete
list expired archivelog all;
delete expired archivelog all;
list expired archivelog all;
list archivelog all;
delete archivelog all;
 
==========================================================================================================================
 ############ FIND LARGE FILES ############
==========================================================================================================================

find . -xdev -size +1000000c -type f -exec ls -la {} \; 2> /dev/null |  sort -nk5 | tail -2000 
 
==========================================================================================================================
 ############ DELETE JUNK: ################
==========================================================================================================================

find . -name "*.trm" -exec rm {} \; && find . -name "*.trc" -exec rm {} \; && find . -name "*.aud" -exec rm {} \; && find . -name "log_*.xml" -exec gzip -9f {} \; > redirection &

==========================================================================================================================
################ Stopping monitoring ###################
==========================================================================================================================

dbmoncol database oracle ERFPRD_1 OFF
dbmoncol database oracle webeencp ON 
dbspicol ON                           ----> startup the whole monitoring
dbspicol OFF                          ----> shutdown the whole monitoring 

===========================================================================================================================
##### Shared Pool view #####
===========================================================================================================================

SET LINES 333
SET LINESIZE 145
SET PAGESIZE 9999
SELECT 'Shared Pool' area, name, sum(bytes)/1024
FROM v$sgastat
WHERE pool = 'shared pool' and
name in ('library cache','dictionary cache','free memory','sql area')
group by name
union all
SELECT 'Shared Pool' area, 'miscellaneous', sum(bytes)/1024
FROM v$sgastat
WHERE pool = 'shared pool' and
name not in ('library cache','dictionary cache','free memory','sql area')
group by pool
order by 3 desc; 

===========================================================================================================================
##### ASH REPORT #####
===========================================================================================================================

$ORACLE_HOME/rdbms/admin/ashrpt.sql

===========================================================================================================================
##### TRANSACTIONS PER HOUR DETAILED INFO #####
===========================================================================================================================

set pages 9999; 
column c1 heading "Start|Time" format a30; 
column c2 heading "End|Time" format a15; 
column c3 heading "Total|Undo|Blocks|Used" format 9,999,999; 
column c4 heading "Total|Number of|Transactions|Executed" format 999,999; 
column c5 heading "Longest|Query|(sec)" format 999,999; 
column c6 heading "Highest|Concurrent|Transaction|Count" format 9,999; 

select 
TO_CHAR( TO_DATE(TO_CHAR(Begin_Time,'DD-MON-YY HH24'), 
'DD-MON-YY HH24') , 'DD-MON-YY HH24') c1, 
-- TO_CHAR(End_Time,'DD-MON-YY HH24') c2, 
SUM(Undoblks) c3, 
SUM(Txncount) c4, 
MAX(Maxquerylen) c5, 
MAX(Maxconcurrency) c6 
from v$undostat 
group by TO_CHAR( TO_DATE(TO_CHAR(Begin_Time,'DD-MON-YY HH24'), 
'DD-MON-YY HH24') , 'DD-MON-YY HH24') 
order by 1 asc 
; 

===========================================================================================================================
##### PROCESSES AND SESSIONS CHECK #####
===========================================================================================================================

select * from v$resource_limit where RESOURCE_NAME in ('transactions','processes','sessions');
select * from v$resource_limit where RESOURCE_NAME in ('transactions','processes','sessions');

===========================================================================================================================
##### FILE SIZE IN MB AND GB #####
===========================================================================================================================

File Size in MB

ls -l --b=M  filename | cut -d " " -f5

File Size in GB

ls -l --b=G  filename | cut -d " " -f5

===========================================================================================================================
##### CLEANING FILESYSTEM ######
===========================================================================================================================

find . -name "*.trm" -exec rm {} \; && find . -name "*.trc" -exec rm {} \; && find . -name "*.aud" -exec rm {} \; && find . -name "log_*.xml" -exec gzip -9f {} \; > redirection & 

find . -name "*.trm" -mtime +1 -exec rm {} \; && find . -name "*.trc" -mtime +1 -exec rm {} \; && find . -name "*.aud" -mtime +1 -exec rm {} \; && find . -name "log_*.xml" -mtime +1 -exec gzip -9f {} \;

find . -name "*.trm" -mtime +1 -exec rm {} \; && find . -name "*.trc" -mtime +1 -exec rm {} \; && find . -name "*.aud" -mtime +1 -exec rm {} \; find . -name "log_*.xml" -exec gzip -9f {} \; > redirection &

find . -name "*.trm" -mtime +1 -exec rm {} \; && find . -name "*.trc" -mtime +1 -exec rm {} \; && find . -name "*.aud" -mtime +5 -exec rm {} \; &
 
find . -name "*.trm" -mtime +2 -exec rm {} \; && find . -name "*.trc" -mtime +2 -exec rm {} \; && find . -name "*.aud" -mtime +2 -exec rm {} \; && find . -name "log_*.xml" -exec gzip -9f {} \; > redirection &



===========================================================================================================================
##### SHOW BIG FILES #####
===========================================================================================================================

find . -xdev -size +1000000c -type f -exec ls -las {} \; 2> /dev/null | sort -n | tail -200 

===========================================================================================================================
##### Redo log groups and members #####
===========================================================================================================================

set linesize 400
col MEMBER for a70
SELECT a.type, a.group#, b.status, a.member, b.bytes FROM v$logfile a, v$log b WHERE a.group# = b.group#(+); 

============================================================================================================================
##### DBSPICAO PARAMETERS #####
============================================================================================================================

grep -v ^# /var/opt/OV/dbspi/db_mon.cfg 

============================================================================================================================
##### CHANGE USER SQL #####
============================================================================================================================

ALTER SESSION SET CURRENT_SCHEMA=SAFE_MAIN;

============================================================================================================================
##### DATABASE UPTIME #####
============================================================================================================================

set linesize 300
col uptime for a24
col status for a6
col db_name for a10
col DATABASE for a15
col hosted_on for a30
col current_time for a22
col database_started for a22
col logins for a7
select
instance_name as DATABASE,
host_name as HOSTED_ON,
status,
logins,
to_char(startup_time, 'MON/DD/YYYY hh24:mi:ss') as DATABASE_STARTED,
to_char(sysdate, 'MON/DD/YYYY hh24:mm:ss') as CURRENT_TIME,
floor(sysdate - startup_time) || 'd / ' ||
trunc( 24*((sysdate-startup_time) - trunc(sysdate-startup_time))) || 'h / ' ||
mod(trunc(1440*((sysdate-startup_time) - trunc(sysdate-startup_time))), 60) ||'m / ' ||
mod(trunc(86400*((sysdate-startup_time) - trunc(sysdate-startup_time))), 60) ||'s' as UPTIME
from v$instance;

alter system switch logfile; ----> proverka dali bazata priema (switch-va logove)

Gledame alert-loga, kato go otvarqme v nova sessiq.

tail -200f <alert log path>

==============================================================================================================================
##### AVON ONLY Export oraenv #####
==============================================================================================================================

export ORAENV_ASK=YES

==============================================================================================================================
##### POWER SHELL DISC UTILIZATION #####
==============================================================================================================================

Clear-Host
Get-WmiObject Win32_logicaldisk -ComputerName LocalHost `
| Format-Table DeviceID, MediaType, `
@{Name=" Size(GB)";Expression={"{0,9:N2}" -f(($_.size/1gb).tostring("0.00"))}}, `
@{Name="Free Space(GB)";Expression={"{0,14:N2}" -f(($_.freespace/1gb).tostring("0.00"))}}, `
@{Name="   Free (%)";Expression={"   {0,6:P2}" -f(($_.freespace/1gb) / ($_.size/1gb))}} `
-AutoSize

==============================================================================================================================
##### DBSPI-0810: Database ua1p has 1.00 standby archive destinations with errors #####
==============================================================================================================================

### Check the database if it PRIMARY or STANDBY - select database_role from v$database;  !!!!!!!!!!

#### Check the state of the database if it STANDBY
### check last apply standby ###
select database_role from v$database; 

set linesize 300
select * from v$flash_recovery_area_usage; 

select al.thread#,
        al.last_rec "Last Recd",
        la.last_app "Last Applied"
from
  (select thread#, max(sequence#) last_rec
    from v$archived_log
    group by thread#) al,
  (select thread#, max(sequence#) last_app
    from v$archived_log
    where applied='YES' and registrar='RFS'
    group by thread#) la
where al.thread#=la.thread#
and al.thread# != 0
order by al.thread#
/  

##### ORACLE 12C - LAST RECEIVED LAST APPLY

select al.thrd "Thread", almax "Last Seq Received", lhmax "Last Seq Applied"
from (select thread# thrd, max(sequence#) almax
      from v$archived_log
      where resetlogs_change#=(select resetlogs_change# from v$database)
      group by thread#) al,
     (select thread# thrd, max(sequence#) lhmax
      from v$log_history
      where first_time=(select max(first_time) from v$log_history)
      group by thread#) lh
where al.thrd = lh.thrd;

### delete archivelog ###
rman target /
delete noprompt archivelog until sequence 26075 thread 1; 
delete noprompt archivelog until sequence 24850 thread 2;  


### STOP APPLY 
ALTER DATABASE RECOVER MANAGED STANDBY DATABASE CANCEL; 

### START APPLY 
ALTER DATABASE RECOVER MANAGED STANDBY DATABASE DISCONNECT FROM SESSION; 

### CHECKING FOR MRP Process for apply
select process, client_process, sequence#, status, DELAY_MINS from V$managed_standby;
select GUARD_STATUS,OPEN_MODE,DATABASE_ROLE from v$database;  


##### Check physical stanby apply status
col RECOVERY_MODE for a25;
col SRL for a3;
col TYPE for a8;
col STATUS   for a8;
col DEST_NAME for a20;
select DEST_ID,dest_name,status,type,srl,recovery_mode from v$archive_dest_status where dest_id=1; 

============================================================================================================
##### DATABASE CHECH FOR STANDBY #####
============================================================================================================

select database_role from v$database;

============================================================================================================
##### Guide unable to connect #####
============================================================================================================

1. Check DBSPICAO if dbspicao -pdfv -i (instence) hangs on execution step 2
2. Check ALERT LOG (dbspicao -l) ; ---> if dbspicao doesnt reply, loggon the database and write SHOW PARAMETER BACK (11G) 
ALERT LOG LOCATION -12c select value from v$diag_info where NAME='Diag Trace';
*2.1 Listener check ---> ps -ef | grep tns 
*2.2 If the above command doesnt report enithing there is no running listener ---> from oracle with loaded oraenv var. execute cd :E/network/admin
3. If the database is not responding ---> find the alert log     find / -name alert_*
4. open alert log with vi tap (shift+G) 
5. if we found arch dest error ---> relation to m058 above 95% switch the dest and start backup
5.1 if we found max session exceeded ---> ps -ef | grep (DBname) after that kill -9 PID (LOCAL NO) (kill 5,6 PID's to connect) 


####lsnrctl status ORA0317LSNR ---> proverka na listener-a (moje i izvun sql)TMOUT=0 

####ora env | grep ORA ----> pokazva setnatiq env.

============================================================================================================
##### Guide [ORA-28001: the password has expired] unable to connect #####
============================================================================================================

1. Login with su - oracle  .oraenv  sqlplus / as sysdba ----> kachvane na bazata
2.
set lines 400
select username, account_status, profile from dba_users where username='HP_DBSPI'; ----> ako user-a ne e HP_DBSPI togava polzvame DBSPI_USER

dbspicfg -e ----> proverka na usera i pass-a


select username, account_status, profile from dba_users where username like '%DB%';
3.
#### EXTRACT OLD PASSWORD - REUSE #### ---> with the below query we will reuse the old password (for expired acc.)

####
CREATE PROFILE NIKI LIMIT   
   PASSWORD_LIFE_TIME UNLIMITED
   PASSWORD_REUSE_TIME UNLIMITED
   PASSWORD_REUSE_MAX UNLIMITED
   PASSWORD_VERIFY_FUNCTION null;

   alter user hp_dbspi profile NIKI;


 alter USER hp_dbspi IDENTIFIED BY "hp_dbspi12345" ;
      alter user hp_dbspi profile DEFAULT;
	  drop profile Niki;
####

select 
'alter user "'||username||'" identified by values '''||extract(xmltype(dbms_metadata.get_xml('USER',username)),'//USER_T/PASSWORD/text()').getStringVal()||''';'  old_password 
from dba_users where username = '&Username';

DBSPI_USER		HP_DBSPI
4. kogato poluchim greshka " cannot reuse the old password" izpolzvame BOK:

create profile BOK limit password_verify_function null; 
alter profile BOK limit PASSWORD_REUSE_MAX UNLIMITED; 
alter profile BOK limit PASSWORD_REUSE_TIME UNLIMITED;
alter user DBSPI_USER profile BOK; 						--->  #### user-a se smenqva na provereniq po gore
alter user "DBSPI_USER" identified by values '4A6D9163FF1B19B1';   --->  #### user-a se smenq na provereniq po gore, values sushto (ot OLD PASSWORD)
alter user DBSPI_USER profile DEFAULT;      --->  #### user-a i profila se smenq na provereniq po gore
drop profile BOK;

=============================================================================================================
##### PROCESSES CHECK #####
=============================================================================================================

set linesize 300
col RESOURCE_NAME for a26
col INITIAL_ALLOCATION for a18
col LIMIT_VALUE for a12
select * from v$resource_limit; 

============================================================================================================
##### STANDBY INFO #####
============================================================================================================

dgmgrl /

============================================================================================================
##### ADECCO #####
============================================================================================================

############################## sftp example ################################

lxintfr10381.fr.adecco.net(oralea):RAC(AGOLFRR1)/local/AGOLFRR1/admin/migration > sftp mnt_lea@lx008093.lcedmz.adecco.net  mnt_lea ---> Zm9TGC3n

============================================================================================================
##### FORTUM FMAXPRD SMAXTRN #####
============================================================================================================

root:  udevadm trigger 

============================================================================================================
#####  DBSPI-813 #####
============================================================================================================

select TIMESTAMP, MESSAGE FROM v$dataguard_status; -> 813 METRIC check for ERRORS
alter system archive log current; -> SWITCH ARCHIVELOG so much times which is nessary for cleaning 813 metric

=============================================================================================================
##### ORA-01033 ##### INFO
=============================================================================================================

ORA-01033: ORACLE initialization or shutdown in progress -----> most of the time this error will occur when the database is switched to STANDBY MODE. Standby database witch script !

=============================================================================================================
##### PASSWORDS ######
=============================================================================================================

################ Adecco user passwords --> cd /local/outils/fp
cisadm [WWRWPR11] - RwpSsp_v132 ; C1ssCRum1!
hrsys [HRPSWWP0] - hrwwg0 ; S2R:bxq6
hrsys [HRPSDEP0] - 4jLH8:vh
hrsys [HRPSWWR1] - Hu87zsq9 ; eJW1:Ncg
sysadm [FIPSFRP0] - C:4Hs9oH ;NEW PASS- ms:4w4vs
NOVA [NOVATEST] - PIAF6545
#### ADECCO WINDOWS ROUTINE CHANGES 
ITECFRP0 SYSTEM PASSWORD -> !QAZ2wsx
ITECFRR1 SYSTEM PASSWORD -> pl!er53f
DB -> ITECFRP0 

olecenter - GuepElou1539 

=============================================================================================================
##### CHECKING USER UNLOCK/LOCK USER #####
=============================================================================================================

col USERNAME for a20
col PROFILE for a20
col ACCOUNT_STATUS for a20
select USERNAME, PROFILE, ACCOUNT_STATUS, DEFAULT_TABLESPACE, TEMPORARY_TABLESPACE from dba_users where username='C##HPDBSPI';  hp_dbspi

set long 10000
select 'alter user '||username||' identified by values '||REGEXP_SUBSTR(DBMS_METADATA.get_ddl ('USER',USERNAME), '''[^'']+''')||';'
from dba_users
where username = 'HP_DBSPI';

ALTER USER user_name ACCOUNT UNLOCK;

==============================================================================================================
##### WINDOWS HOP mspsc
==============================================================================================================

mstsc ---> connectora

==============================================================================================================
##### za HP-UX - uxmon command
==============================================================================================================

bdf /oradata ------> kato df ---> no raboti v HP-UX

==============================================================================================================
##### AVONNA za change na password #####
==============================================================================================================

https://avonaccess.na.avon.com/dana-na/auth/url_default/welcome.cgi

==============================================================================================================
##### Windows backup #####
==============================================================================================================

C:\Program Files\OmniBack\bin\omnib.exe -oracle8 plwaws0004_ZDPS_archivelog_delete_on

==============================================================================================================
##### Void, Resolve, Save, Close #####
==============================================================================================================

==============================================================================================================
##### Different ways to find oracle home #####
==============================================================================================================

++++++++ Za povecheto OS-i +++++++++

$ env|grep -i ORACLE_HOME

/u01/app/oracle/product/10gR2/db_1

$ echo ORACLE_HOME

/u01/app/oracle/product/10gR2/db_1


++++++++ AIX: Display ORACLE_HOME ++++++++

$ ps -ef | grep pmon

ora1024   262366        1   0   Mar 23      -  0:12 ora_pmon_mysid
 
ORACLE_SID is mysid
 
$ ls -l /proc/262366/cwd

lr-x------   2 ora1024  dba  0 Mar 23 19:31 cwd -> /data/opt/app/product/10.2.0.4/db_1/dbs/
 
ORACLE_HOME is /data/opt/app/product/10.2.0.4/db_1

+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

+++++++++++ Linux & Solaris:Display ORACLE_HOME +++++++++++++++

$ pgrep  -lf _pmon_

12546 ora_pmon_mysid
 
ORACLE_SID is mysid
 
$ pwdx 12546

12586: /u01/oracle/10.2.0.4/ee1/dbs

+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

Linux & Solaris:Display ORACLE_HOME

$ pgrep  -lf _pmon_

12546 ora_pmon_mysid
 
ORACLE_SID is mysid
 
$ pwdx 12546

12586: /u01/oracle/10.2.0.4/ee1/dbs

=========================================================================================================================
##### DBSPICAO LOCATION #####
=========================================================================================================================

locate dbspicao -----> otkrivame kyde e putq kum dbspicao ako ne e zadaden

=========================================================================================================================
##### Check for alert log dest #####
=========================================================================================================================

select value from v$diag_info where NAME='Diag Trace';

=========================================================================================================================
##### Check za Inactive sessions ######
=========================================================================================================================

select SID, SERIAL#, USERNAME, SCHEMANAME, MACHINE, PROGRAM, STATUS from gv$session where STATUS='INACTIVE';
select SID, SERIAL#, USERNAME, SCHEMANAME, MACHINE, PROGRAM, STATUS from gv$session where username='VNGSYS' and STATUS='INACTIVE';
=========================================================================================================================
##### For user password change ######
=========================================================================================================================

col USERNAME for a15
col ACCOUNT_STATUS for a10
col PROFILE for a40
select USERNAME,USER_ID,ACCOUNT_STATUS,CREATED,PROFILE from dba_users where username = UPPER( '&USER'); 

=========================================================================================================================
##### GZIP na logove #####
=========================================================================================================================

gzip -9vc syslog.log > /var/adm/crash/syslog.log.`date +%Y%m%d`.gz;>syslog.log;fuser syslog.log

=========================================================================================================================
##### Creating new user #####
=========================================================================================================================

### Create new user "DEVADAS" with password "changeme" mimic existing user "KUMARG"
### 'KUMARG' - source user
### "DEVADAS" - target user
set linesize 200;
select 'create user "CANDEM_TMP" identified by "changeme" default tablespace '|| default_tablespace ||' temporary tablespace '|| temporary_tablespace ||' profile '|| profile ||';' from dba_users where username='CANDEM'; 
select 'grant '||granted_role||' to "CANDEM_TMP";' from dba_role_privs where grantee='CANDEM';
select 'grant '||privilege||' to "CANDEM_TMP";' from dba_sys_privs where grantee='CANDEM';
select 'grant '||privilege||' on '|| table_name||' to "CANDEM_TMP";' from dba_tab_privs where grantee='CANDEM'; 

==========================================================================================================================
###### Dataguard ######
==========================================================================================================================

oracle/> tnsping ime_na_bazata --------> pokazva kude vurvi dadenata baza

==========================================================================================================================
###### CPU monitoring #####
==========================================================================================================================

### Monitor CPU utilization ( LINUX)
watch "ps aux | sort -nrk 3,3 | head -n 5" 

/opt/OV/bin/ovcodautil -support|grep -i cpu

==========================================================================================================================
###### Killing inactive sessions ######
==========================================================================================================================

-------------------Kill innactive sessions----------------------------------
select 'ALTER SYSTEM KILL SESSION '||''''||sid||','||serial#||',@'||inst_id||''' IMMEDIATE;' from gv$session where STATUS='INACTIVE' and INST_ID=2;


select 'ALTER SYSTEM KILL SESSION '||''''||sid||','||serial#||',@'||inst_id||''' IMMEDIATE;' from gv$session where STATUS='INACTIVE' and USERNAME='VNGSYS';


===========================================================================================================================
###### Cluster node ####### 
===========================================================================================================================

srvctl status database -d ----> pokazva status na bazata
srvctl start database -d -name of the DB		  ### start database
srvctl status database -n - name of the node      ### status the working nodes
srvctl stop database - -i - name of the instace   ### stop instance


===========================================================================================================================
##### DBSPI spirane na monitoring ######
===========================================================================================================================

/var/opt/OV/conf/OpC/df_mon.cfg   ------> monitoring na failovata sistema

/var/opt/OV/dbspi/db_mon.cfg  ----------> monitoring na incident errors

============================================================================================================================
##### AVON export env #####
============================================================================================================================

export ORAENV_ASK=YES

============================================================================================================================
###### Rejected guide ######
============================================================================================================================

Status: ready

Assignment Group: E-CHGIMP-ADECCO-REJECT-CE

Clousure Code: 
Clousure Comments: 

New Update: text, desc

## There are no update objective description for exexution for our power shell.

From the DROP-DOWN menu -> show parent change -> abondon -> clousure code: cancelled -> clousure comment: text -> finish

DESCR: Change will be rejected due to: different output

Change will be REJECTED due to: different output (execution error

===========================================================================================================================
###### Dbspi - configuration ######
===========================================================================================================================

dbspicfg -e -----> proverka na konfiguraciqta i pass-a

===========================================================================================================================
###### +ASM disk space check ######
===========================================================================================================================

set linesize 333
column pct_free format 99.99
select group_number, name, total_mb, free_mb, total_mb -free_mb used_mb, case when total_mb=0 then 0 else  free_mb/total_mb *100 end pct_free from v$asm_diskgroup
/


alter tablespace PAR_DWF_G_06 add datafile size 100m autoextend ON NEXT 1048576K maxsize 65535M; ---------> za 6-ta metrika ASM 
alter tablespace PAR_DWF_G_07 add datafile autoextend ON next 1048576K maxsize unlimited;
===========================================================================================================================
####### ASM unable to connect #######
===========================================================================================================================

dbspicao -m334 -pv -----> pokazva dali diskovite grupi sa ok

===========================================================================================================================
####### Create DBSPI user #######
===========================================================================================================================

напиши като роот dbspicfg.sh
там ще видиш ентрито за тази база
запиши си в нотпад името на юзъра и паролата
това ти е скрипта който ще го направи   ---->  @/var/opt/OV/bin/instrumentation/dbspiocr_nw.sql USERS TEMP hp_dbspi hp_dbsp -----> tova se izpulnqva sled kato se proverqt po-dolnite parametri
първо гледаш USERS е за кой тейбълспейс да запишеш към юзъра   логваш се в базата и пускаш ----> select tablespace_name from dba_tablespaces;  по принцип USERS го има навсякъде, ако няма някъде USERS ще има TOOLS,
но ако има USERS задължително него избираш.
2-рото ентри е TEMP, това е за темп тейбълспейса ------> select distinct tablespace_name from dba_temp_files; така ще видиш как са им имената. 
Kато се увериш, че USERS и TEMP са правилните имена, следващите 2 ентрита са ти USER | PASSWORD трябва да ги замениш с тези които изкара по рано от dbspicfg.sh заместваме ги по скрипта @/var/opt/OV/bin/instrumentation/dbspiocr_nw.sql USERS TEMP dbspi_user <--(това е юзъра слагаме интервал м/у юзър и пасс) Avon123 <--(паролата)

============================================================================================================================
####### Ако хитне базата MAXIMUM SESSIONS - се килват се проверяват и килват определена сесия.
============================================================================================================================
ps -ef | grep oracle

kill -9 64463 && "sqlplus / " as sysdba 

============================================================================================================================
####### Connecting to a hung database with the -prelim option
============================================================================================================================
$sqlplus /nolog
SQL> set _prelim on
SQL> conn / as sysdba
Prelim connection established
SQL> shutdown abort

sqlplus -prelim / as sysdba

============================================================================================================================
####### DB size GB
============================================================================================================================

col "Database Size" format a20
col "Free space" format a20
col "Used space" format a20
select    round(sum(used.bytes) / 1024 / 1024 / 1024   ) || ' GB' "Database Size"
,         round(sum(used.bytes) / 1024 / 1024 / 1024 ) - 
          round(free.p / 1024 / 1024 / 1024  ) || ' GB' "Used space"
,         round(free.p / 1024 / 1024 / 1024 ) || ' GB' "Free space"
from    (select     bytes
          from      v$datafile
          union     all
          select    bytes
          from      v$tempfile
          union     all
          select    bytes
          from      v$log) used
,         (select sum(bytes) as p
          from dba_free_space) free
group by free.p
/ 

============================================================================================================================
####### If the database is in MOUNT status, we must check if there are running backups (COLD BACKUP)
============================================================================================================================

ps -ef|grep rman
============================================================================================================================
####### s tova query pravi drugi queryta za kill-vane na neaktivni sesii na tozi potrebitel
============================================================================================================================

select 'ALTER SYSTEM KILL SESSION '||''''||sid||','||serial#||',@'||inst_id||''' IMMEDIATE;' from gv$session where USERNAME='BASE_V14' and STATUS='INACTIVE';
============================================================================================================================
####### (58 METRIC)(FROM SQL_DB) Show me the Backup pieces###
============================================================================================================================

SET LINESIZE 145
SET PAGESIZE 9999 
COLUMN bs_key FORMAT 9999 HEADING 'BS|Key'
COLUMN piece# FORMAT 99999 HEADING 'Piece|#'
COLUMN copy# FORMAT 9999 HEADING 'Copy|#'
COLUMN bp_key FORMAT 9999 HEADING 'BP|Key'
COLUMN status FORMAT a9 HEADING 'Status'
COLUMN handle FORMAT a65 HEADING 'Handle'
COLUMN start_time FORMAT a17 HEADING 'Start|Time'
COLUMN completion_time FORMAT a17 HEADING 'End|Time'
COLUMN elapsed_seconds FORMAT 999,999 HEADING 'Elapsed|Seconds'
COLUMN deleted FORMAT a8 HEADING 'Deleted?'
BREAK ON bs_key
prompt
prompt Available backup pieces contained in the control file.
prompt Includes available and expired backup sets.
prompt 
SELECT
bs.recid bs_key
, bp.piece# piece#
, bp.copy# copy#
, bp.recid bp_key
, DECODE( status
, 'A', 'Available'
, 'D', 'Deleted'
, 'X', 'Expired') status
, handle handle
, TO_CHAR(bp.start_time, 'mm/dd/yy HH24:MI:SS') start_time
, TO_CHAR(bp.completion_time, 'mm/dd/yy HH24:MI:SS') completion_time
, bp.elapsed_seconds elapsed_seconds
FROM
v$backup_set bs
, v$backup_piece bp
WHERE
bs.set_stamp = bp.set_stamp
AND bs.set_count = bp.set_count
AND bp.status IN ('A', 'X')
ORDER BY
bs.recid
, piece#
/ 

============================================================================================================================
####### (58 METRIC)(FROM RMAN)List of RMAN backups - run with sys as sysdba
============================================================================================================================
 
set lines 400 pages 100
col device for a8
col time_taken for a8
column TIME_TAKEN_DISPLAY format a40;
col status for a28
select command_id,TO_CHAR(start_time, 'MM/DD/YY HH24:MI:SS') as start__time,
TO_CHAR(end_time, 'MM/DD/YY HH24:MI:SS') as end_time, output_device_type as device,input_type,time_taken_display as time_taken, status 
from V_$RMAN_BACKUP_JOB_DETAILS order by start_time; 

============================================================================================================================
####### (58 METRIC)(FROM RMAN) deletes old archive logs
============================================================================================================================

DELETE FORCE NOPROMPT ARCHIVELOG ALL BACKED UP 1 TIMES TO DEVICE TYPE sbt;
DELETE FORCE NOPROMPT ARCHIVELOG ALL BACKED UP 1 TIMES TO DEVICE TYPE disk;

============================================================================================================================
####### checking for backups (cold backup) if the monitoring is OFF
============================================================================================================================

ps -ef|grep rman

or longops (Long Running Operation) query

============================================================================================================================
####### 58 METRIC GUIDE
################################ DBSPI-0058: Archive free space percentage 22.72% too low for archive device \oracle\RMAN112\fra for RMAN112 <=30%. [Policy:DBMON-DBSPI-0058-ARM] ################
============================================================================================================================

omnistat -det --> check for BACKUPS

Run backUP : /opt/omni/bin/omnib  -Oracle8 espx0152_PDSP_archivelog_delete_on

/opt/omni/bin/omnib  -Oracle8 /USGD_IDA_CANON_plnpdodb302-b_ORA_CPQTST_ARC 

<or>

/opt/omni/bin/omnib  -Oracle8 sl72026_ora_prod_OGEEGP_daily_arch_del &


/opt/omni/bin/omnib  -Oracle8 espx0248_ZAIDEV_archivelog_delete_on

/opt/omni/bin/omnib  -Oracle8 gefa_dev_test_aorac151_linux_ora_AORA3_arc_del_auto

/opt/omni/bin/omnib  -Oracle8 prod_fivaora002_ora_hpsa_daily_logs_on

/opt/omni/bin/omnib  -Oracle8 sl72841_ora_prod_OGEDHTP_daily_arch_del

/u83/home/oracle/scripts/rmanscripts/rman_backup11g.ksh gmcgce2p ARCH E



/sap_ora_tsm/ora_hp/backup/bin/db_backup.sh all arch > /dev/null 2>&1




nohup  ./arch1.sql > arch1.log 2>&1 &


##### Zamryznala baza, ubivame vsichki procesi na RMAN (KILL ALL RMAN PROCESSES)
select 'ALTER SYSTEM KILL SESSION'|| chr(39) || s.sid || ',' || s.serial# || chr(39) || ' immediate' ||';'
FROM v$session s, v$process p
WHERE s.paddr = p.addr
AND s.program LIKE '%rman%'; 

LOCATION=/wisk7_p/orabck/temp_arch_dest VALID_FOR=(ALL_LOGFILES,PRIMARY_ROLE) DB_UNIQUE_NAME=WISK7_P


windows

C:\Program Files\OmniBack\bin\omnib> -oracle8 clintfr10656_AGOLFRP0_ARC 
C:\Program Files\OmniBack\bin> -oracle8 mewa_defradb811_ora_MIDSYS35_arch_del
"C:\Program Files\OmniBack\bin\omnib.exe" -oracle8 fivats0063_ELWNPRD_archivelog_on

RMAN> list backup of archivelog all;  -------> pokazva vsichki vidove backup-i
RMAN> list backup of database summary;
RMAN> list backup of database completed after 'sysdate-15';

rman cmdfile=backup_online_arch_.rman log=backup_online_arch_`date +%Y%m%d%H%M`.log
example: rman cmdfile=backup_online_arch_OSTST.rman log=backup_online_arch_OSTST`date +%Y%m%d%H%M`.log -> backup_online_arch_OSTST.rman (example)

EON SPECIFIC backup : cd /tsm/TCTSP01/StartRedolog.sh

ARCHIVE DEST SPACE UTILIZATION:

PROMPT Archivelog Space Report
col limit format 999,999,999 heading "Limit (mb)";
col used format 999,999,999 heading "Space Used (mb)";
col free format 999,999,999 heading "Space Free (mb)";
select space_limit/(1024*1024) limit
, (space_used + space_reclaimable)/(1024*1024) used
, (space_limit-(space_used+space_reclaimable))/(1024*1024) free
,number_of_files
from v$recovery_file_dest
/

set linesize 300
select * from v$flash_recovery_area_usage;

set linesize 300
show parameter db_recovery_file_dest;


alter system set log_archive_dest=[the new space]
alter system set log_archive_dest_1='LOCATION=/ce1parch01/ce1p';
alter system set log_archive_dest_1='LOCATION=/ce1pdata01/ce1p_arch';


RMAN> delete noprompt archivelog all backed up 1 times to SBT; 
delete noprompt archivelog all backed up 1 times to DISK;
--- delete all backed up 1 time to tape

### IF DATABASE HANG -> SQL> alter system set db_recovery_file_dest='+LEADG_M0' (some location that have space)

select log_mode,flashback_on from v$database;
---> If FLASHBACK_LOGS -> alter database flashback off; AND THEN ->> alter database flashback on;

select database_role from v$database; - check if the databaseFault is not on STANDBY !!! ------ DBSPICAO813


select TIMESTAMP, MESSAGE FROM v$dataguard_status; -> 813 METRIC check for ERRORS
alter system archive log current; -> SWITCH ARCHIVELOG so much times which is nessary for cleaning 813 metric

============================================================================================================================
####### (показва използвано, свободно, общ размер, и свободно място в проценти.), List groups statistics:
## Proverqvame kolko mqsto ima na FRA s tova query:
============================================================================================================================

column pct_free format 99.99
select group_number, name, total_mb, free_mb, total_mb -free_mb used_mb,
case when total_mb=0 then 0 else free_mb/total_mb *100 end pct_free
from v$asm_diskgroup
/

============================================================================================================================
####### RESIZE FS +FRA

show parameter recovery ---> pokazva info za FRA

Vzimame parametyra na FRA i go resize-vame s tova query:

alter system set db_recovery_file_dest_size=800G;

============================================================================================================================
####### listva nai-golemi filove (by A.Mihov)

find . -xdev -mtime 0 -size +10000c -type f -exec ls -al {} \; |sort -k5nr |head -90 

============================================================================================================================
####### Switch na dest(ination)

alter system set log_archive_dest_1='LOCATION=/oracle/oracle_PSHARE2/archlog';


============================================================================================================================
####### INODE

df -i	-----> check za inod-i	
find . -xdev -mtime 0 -size +1000c -type f -exec ls -al {} \; |sort -k5nr |head -90  -----> tursachka za failove zapulvashti inod-i Al. Mihov															
find . -xdev -name "*.aud" -type f -mtime +30 -exec rm -f {} ;		###           Triqt se stari audit file-ove             ###
find . -mtime +20 \( -name "*.aud" \) -exec rm {} \; 

## tyrkachka za Inode, trm, trc

nohup find . \( -name "*trc" -o -name "*trm" \) -exec rm -f {} \; 

============================================================================================================================
####### AUDI CHECK TABLESPACES

set lines 250
set pages 40
col 1 noprint;
break on 1
compute sum of megs_alloc on 1
compute sum of megs_free on 1
compute sum of megs_used on 1
compute sum of megs_max on 1
select  1, a.tablespace_name,
       round(a.bytes_alloc / 1024 / 1024, 2) megs_alloc,
       round(nvl(b.bytes_free, 0) / 1024 / 1024, 2) megs_free,
       round((a.bytes_alloc - nvl(b.bytes_free, 0)) / 1024 / 1024, 2) megs_used,
       round((nvl(b.bytes_free, 0) / a.bytes_alloc) * 100,2) Pct_Free,
       100 - round((nvl(b.bytes_free, 0) / a.bytes_alloc) * 100,2) Pct_used,
       round(maxbytes/1048576,2) Megs_max,
      round(100*(round((a.bytes_alloc - nvl(b.bytes_free, 0)) / 1024 / 1024, 2))/(round(maxbytes/1048576,2)),2) pct_used_max
from  ( select  f.tablespace_name,
               sum(f.bytes) bytes_alloc,
               sum(decode(f.autoextensible, 'YES', CASE WHEN f.maxbytes >= f.bytes THEN f.maxbytes ELSE f.bytes END, 'NO', f.bytes)) maxbytes
        from dba_data_files f
        group by tablespace_name) a,
      ( select  f.tablespace_name,
               sum(f.bytes)  bytes_free
        from dba_free_space f
        group by tablespace_name) b
where a.tablespace_name = b.tablespace_name (+)
union
select 1, h.tablespace_name,
       round(sum(h.bytes_free + h.bytes_used) / 1048576, 2),
       round(sum((h.bytes_free + h.bytes_used) - nvl(p.bytes_used, 0)) / 1048576, 2),
       round(sum(nvl(p.bytes_used, 0))/ 1048576, 2) megs_used,
       round((sum((h.bytes_free + h.bytes_used) - nvl(p.bytes_used, 0)) / sum(h.bytes_used + h.bytes_free)) * 100,2),
       100 - round((sum((h.bytes_free + h.bytes_used) - nvl(p.bytes_used, 0)) / sum(h.bytes_used + h.bytes_free)) * 100,2),
       round(sum(decode(f.autoextensible, 'YES', CASE WHEN f.maxbytes >= (h.bytes_used + h.bytes_free) THEN f.maxbytes ELSE (h.bytes_used + h.bytes_free) END, 'NO', f.bytes)) / 1048576, 2) Max,
       round(100*(round(sum(nvl(p.bytes_used, 0))/ 1048576, 2))/(round(sum(decode(f.autoextensible, 'YES', CASE WHEN f.maxbytes >= (h.bytes_used + h.bytes_free) THEN f.maxbytes ELSE (h.bytes_used + h.bytes_free) END, 'NO', f.bytes)) / 1048576, 2)),2)
from   sys.v_$TEMP_SPACE_HEADER h, sys.v_$Temp_extent_pool p, dba_temp_files f
where  p.file_id(+) = h.file_id
and    p.tablespace_name(+) = h.tablespace_name
and    h.file_id = f.file_id
and    h.tablespace_name = f.tablespace_name
group by h.tablespace_name
ORDER BY PCT_USED_MAX desc;

#### 
## For which tablespace?

set linesize 400
col FILE_NAME for a70
select FILE_ID, FILE_NAME, TABLESPACE_NAME, BYTES/1024/1024, MAXBYTES/1024/1024, AUTOEXTENSIBLE from dba_DATA_files where TABLESPACE_NAME='&tablespace_name';

============================================================================================================================
####### Summary of time, total MB from RMAN

set lines 300
column TIME_TAKEN_DISPLAY format a20;
column INPUT_BYTES_DISPLAY format a10;
column OUTPUT_BYTES_DISPLAY format a10;
select INPUT_BYTES_DISPLAY,OUTPUT_BYTES_DISPLAY,command_id,start_time, end_time, output_device_type,input_type,time_taken_display, status from V_$RMAN_BACKUP_JOB_DETAILS where start_time > sysdate -5 order by end_time; 

============================================================================================================================
####### 6 METRIC GUIDE #######

nsu -> password -> ps -ef|grep pmon -> dbspicao -m6 -r1 -i -> su - oracle -> . oraenv -> (db_name) -> sqlplus / as sysdba

dbspicao -m6 -r1 -pv -i [INSTANCE] | egrep 'TABLESPACE_NAME|[NAME_OF_THE_TABLESPACE]|-' | grep -v 'TABLESPACE_NAME:  Name of the tablespace'
dbspicao -m6 -r1 -pv -i webecep | egrep 'TABLESPACE_NAME|ORDDETL_KZ_DATA|-' | grep -v 'TABLESPACE_NAME:  Name of the tablespace'

####### SHOW TABLESPACE FILES

set linesize 555
set pagesize 555
col TABLESPACE_NAME for a21
col FILE_NAME for a70
select file_id,FILE_NAME, TABLESPACE_NAME, BYTES/1024/1024 MB_Used, MAXBYTES/1024/1024 Max_size_MB, (increment_by*(bytes/blocks))/1024 increment_by_kb , AUTOEXTENSIBLE from dba_data_files where
TABLESPACE_NAME='&tablespace_name';



####### 6 METRIC (df) - +ASM +DATA - !Checking free space. 

set linesize 333
column pct_free format 99.99
select group_number, name, total_mb, free_mb, total_mb -free_mb used_mb, case when total_mb=0 then 0 else  free_mb/total_mb *100 end pct_free from v$asm_diskgroup
/

### Check ASM SPACE/STORAGE:

column pct_free format 99.99
select group_number, name, total_mb, free_mb, total_mb -free_mb used_mb,
case when total_mb=0 then 0 else  free_mb/total_mb *100 end pct_free
from v$asm_diskgroup
/

### pattern, view abot +ASM, +DATA
set long 10000
select dbms_metadata.get_ddl('TABLESPACE','TBS_EXPEDICIONES_IND') from dual; 

####### CREATING NEW .dbf FILES

#### When autoextend is NO ####
alter tablespace ABACUS360_TBS add datafile '/prd/PMEL/ora_data/abacus360_tbs_55.dbf' size 65535M;

alter tablespace MBBCLOGACCUSA_DAT_OBJ add datafile size 64000;

alter tablespace ZTM_DATA add datafile size 32000M;
alter tablespace ZTM_DATA add datafile size 32000M;

alter tablespace ZTM_DATA add datafile 'T:\ORACLE\ORADATA1\MIAP2\ZTM_DATA15.DBF' size 32000M;


alter tablespace INTERFACE_LOBDATA add datafile '/oracle/DIAP/oradbf15/INTERFACE_LOBDATA_16.dbf' size 50M autoextend on next 8K maxsize 32767M;

alter tablespace ABACUS360_TBS add datafile '/prd/PMEL/ora_data/abacus360_tbs_41.dbf' size 65535M;
alter tablespace [tablespace name] add datafile '[filename path .dbf]' size 100M autoextend on next 1024K maxsize 10000M;
alter tablespace GCA_TBS add datafile '/oracle/OSLTP/oradata1/gca_tbs_tsOSLTP.dbf45' size 100M autoextend on maxsize unlimited;
alter tablespace DOM1_TIMESERIES_BINDATA add datafile '+DATA' size 100M autoextend on next 102400K maxsize 32765M;


alter tablespace PAR_DWF_G_04 add datafile size 50M autoextend on next 1048576K maxsize 32000M;




alter tablespace IDOCDATA_TS add datafile 'T:\ORACLE\ORADATA1\MIDSYS23\MEWA04\IDOCDATA_TS_1.ORA' size 50M autoextend on next 50000K maxsize 8000M;



ALTER TABLESPACE TEMP ADD TEMPFILE '+DATA' SIZE 50M AUTOEXTEND ON NEXT 100M MAXSIZE 32767M;


SQL> ALTER DATABASE datafile 59 autoextend ON maxsize 40000M;


### SCRIPT FOR CHECK TABLESPACES ####

---For TEMP files

#### Current Temp Datafiles State ####

set pages 999
set lines 400
col FILE_NAME format a75
select d.TABLESPACE_NAME, d.FILE_NAME, d.BYTES/1024/1024 SIZE_MB, d.AUTOEXTENSIBLE, d.MAXBYTES/1024/1024 MAXSIZE_MB, d.INCREMENT_BY*(v.BLOCK_SIZE/1024)/1024 INCREMENT_BY_MB
from dba_temp_files d,
 v$tempfile v
where d.FILE_ID = v.FILE#
order by d.TABLESPACE_NAME, d.FILE_NAME;



col file_name form a75
set lines 300
select FILE_ID,file_name, bytes/1024/1024 "MB",MAXBYTES/1024/1024 "MAXBYTES",AUTOEXTENSIBLE from dba_temp_files; 



####### RESIZING .dbf FILES
alter database datafile 245 resize 20480M;

####### RESIZING TEMP FILE
alter database tempfile 1 resize 16000M;

####### EXTEND AUTOEXTEND ONLY SYSTEM AND SYSAUX
alter database datafile 2 autoextend on next 51200K maxsize 10000M;

alter database datafile 91 autoextend on maxsize 32000M;



============================================================================================================================
####### ako direktoriqta e napravena s root, a e trqbvalo s oracle, se chown-va po sledniq nachin:

chown -R oracle:dba temp_arch

============================================================================================================================
####### ACCOUNT UNLOCK

col USERNAME for a15
col ACCOUNT_STATUS for a10
col PROFILE for a40
select USERNAME,USER_ID,ACCOUNT_STATUS,CREATED,PROFILE from dba_users where username = UPPER( '&USER'); 

alter user SQL_ECARRER identified  by "Welcome_12"; 

alter user SQL_ECARRER account unlock; 


============================================================================================================================
####### CREATE / GRANT A USER

CREATE USER books_admin IDENTIFIED BY MyPassword;

GRANT CONNECT TO books_admin;

GRANT CONNECT, RESOURCE, DBA TO books_admin;

GRANT CREATE SESSION GRANT ANY PRIVILEGE TO books_admin;

GRANT UNLIMITED TABLESPACE TO books_admin;

GRANT
  SELECT,
  INSERT,
  UPDATE,
  DELETE
ON
  schema.books
TO
  books_admin;
  
  
<--- FOR READ ONLY -->
GRANT CREATE SESSION, RESOURCE to SQL_kpalagiri; 



CREATE USER "SQL_kpalagiri"
IDENTIFIED BY "Pa$$word_2019"
DEFAULT TABLESPACE USERS
TEMPORARY TABLESPACE TEMP
PROFILE SOX_USER;

grant R_SELECT_APPLI to SQL_kpalagiri;

============================================================================================================================
####### FOR LOGISTA - IF THERE ARE MORE THAN ONE DATABASE, A SCRIPT MUST BE EXECUTED
IN ORACLE USER

cd /home/oracle/scripts
 . setsid.sh

============================================================================================================================
####### Summary of time, total MB from RMAN - show

set lines 300
column TIME_TAKEN_DISPLAY format a20;
column INPUT_BYTES_DISPLAY format a10;
column OUTPUT_BYTES_DISPLAY format a10;
select INPUT_BYTES_DISPLAY,OUTPUT_BYTES_DISPLAY,command_id,start_time, end_time, output_device_type,input_type,time_taken_display, status from V_$RMAN_BACKUP_JOB_DETAILS where start_time > sysdate -5 order by end_time; 

============================================================================================================================
####### RESIZE ON temp FILES (IN TABLESPACE)

## WITH THIS WE SEE THE TABLESPACES AND HOW MUCH WE CAN RESIZE THEM.
set linesize 400
col FILE_NAME for a70
col TABLESPACE_NAME for a25
set pages 500
select d.file_id,d.FILE_NAME, d.TABLESPACE_NAME, d.BYTES/1024/1024, d.MAXBYTES/1024/1024, d.AUTOEXTENSIBLE, 
(d.INCREMENT_BY*(bytes/blocks))/1024 Increment_by_KB, d.bytes/blocks block_size, d.RELATIVE_FNO, i.ASYNCH_IO from dba_temp_files d, v$iostat_file i
where d.file_id = i.file_no
and i.filetype_name='Data File'
order by 1; 


## use this command to resize the tempfile

alter database tempfile 3 resize 7G; 

============================================================================================================================
####### HEALTH CHECK

linux:

server uptime: uptime

cpu: top

Physical memory available in MB: (ram): echo $(($(getconf _PHYS_PAGES) * $(getconf PAGE_SIZE) / (1024 * 1024)))

Virtual memory available in MB: - echo $(($(getconf _AVPHYS_PAGES) * $(getconf PAGE_SIZE) / (1024 * 1024)))

..or use /proc/meminfo: grep MemTotal /proc/meminfo | awk '{print $2 / 1024}'


To see the physical chip information
sudo dmidecode -t 17

sudo dmidecode -t memory


============================================================================================================================
####### MOST USEFULL LINUX COMMANDS FOP PROCESSES:

top - The top command is the traditional way to view your system’s resource usage and see the processes that are taking up the most system resources. Top displays a list of processes, with the ones using the most CPU at the top.

ps - The ps command lists running processes.
PS -A - The following command lists all processes running on your system.
ps -A | grep firefox  -  You could also pipe the output through grep to search for a specific process without using any other commands. The following command would search for the Firefox process:
ps -ef - Shows up all running and active processes.
pstree - The pstree command is another way of visualizing processes. It displays them in tree format. So, for example, your X server and graphical environment would appear under the display manager that spawned them.
kill  OR  kill -9  -  The kill command can kill a process, given its process ID. You can get this information from the ps -A, top or pgrep commands.

ps au  OR  ps axu  -  Display all processes in BSD format.
ps -x  -  You can select all processes owned by you (runner of the ps command, root in this case)
$ ps -fp <process id>  -  Display Processes by PID and PPID
$ ps -fp 2226,1154,1146  -  Make selection using PID list.
$ ps -eo pid,ppid,user,cmd  -  The command below allows you to view the PID, PPID, user name and command of a process.
$ ps -p 1154 -o pid,ppid,fgroup,ni,lstart,etime  -  Below is another example of a custom output format showing file system group, nice value, start time and elapsed time of a process.
$ ps -p 1154 -o comm=   -   To find a process name using its PID.


============================================================================================================================
####### 

HPSM ERROR:
HEMETEST:ERRORLOG: ORA-00312: online log 1 thread 1: '+DATA/hemetest/onlinelog/group_1.364.954491771'

ALERT LOG ERROR:
Errors in file /u01/app/oracle/diag/rdbms/hemetest/HEMETEST/trace/HEMETEST_ora_7282.trc:
ORA-15025: could not open disk "/dev/xvdn1"
ORA-27041: unable to open file
Linux-x86_64 Error: 13: Permission denied
Additional information: 3


### COMMANDS TO USE.

cmviewcl -> as root (service guard HP-UX)

#######

AS ROOT FOR FORTUM (+ASM disk groups dissconnected) (CONNECT WITH TEODORA PESHEVA UNIX)

udevadm trigger

============================================================================================================================
####### - pokazva primary i standby database name

show parameter fal

============================================================================================================================
####### - IMPORTANT!! - ONLY FOR VOBE (FLEMISH GOVERMANT)

ALLAYS AFTER DATABASE ISSUE, CONTACT WITH THE AMOS TEAM! THEY ARE THE CONNECTION WITH THE GOVERMANT!

============================================================================================================================
####### STARTING LISTENER

ps -ef | grep tns ## checking TNS listener
lsnrctl status <Listener_name> ## - Get listener port

su - oracle
. oraenv
cd $ORACLE_HOME/network/admin
listener.ora

lsnrctl start LISTENER_EAGR2C1T_1524

============================================================================================================================
####### for GZIP-ing syslog.log and alert_log.log (by Sasho Mihov)

gzip -9vc alert_T60018_1.log > alert_T60018_1.log.`date +%Y%m%d`.gz;>alert_T60018_1.log;fuser alert_T60018_1.log 
============================================================================================================================
####### for GZIP-ing .xml files, which are not used at this moment.

for f in `ls *.xml`; do
PROC=`fuser $f`
if [ -n "$PROC" ]; then
echo Skipping file $f. Running process $PROC
continue
fi
gzip -9v $f
done 

============================================================================================================================
####### FORTUM - Register database to catalogue

set ORACLE_SID= (# Database Name)
set ORACLE_HOME= (# HOME directory can be seen, when we type "dbspicao -pdfv")

## For windows - need to add to "Computer Management" 

rman target /
connect RCVCAT rmanuser11204/fortumuser@RCVCAT 

and we type
register database or database register ## To register the database in the Catalogue

============================================================================================================================
####### ONLY FOR AUDI
## to set the environment, type as oracle user:

dbset

============================================================================================================================
####### dbspicfg -e
## to see username/password, home dir

============================================================================================================================
####### dgmgrl / - DATA GUARD 

## Info: Mojeme da proverime dali bazata ima standby s komandata "show configuration"

dgmgrl /

## show primary or standby database and shows dataguard.
show configuration

## show if the database appli is on or off
show database verbose 'ogezmsis';

## command for turning on or off the apply.
edit database 'ogezmsis' set state='apply-off';
edit database 'ogezmsis' set state='apply-on';

============================================================================================================================
####### shows where directories are located: trace, alert, cdump...

select * from v$diag_info;

============================================================================================================================
####### BACKUP FOR LINUX EON

ESL
crontab -l

(as oracle user) - ls -la 
/oracle/home/oracle/tsm -> <dir_db_name> -> script_for_backup.sh


============================================================================================================================
####### Check for HOST_NAME (host name)

select host_name from v$instance;

============================================================================================================================
####### Show service name

show parameter service_name

============================================================================================================================
####### FIND SID BY PID

select sid from v$session, v$process
      where paddr = addr
      and spid = '18864'; 

============================================================================================================================
####### CHECK TEMP SEGMENT tablespace (ORA-1652)

SELECT A.tablespace_name tablespace, D.mb_total,
   SUM (A.used_blocks * D.block_size) / 1024 / 1024 mb_used,
   D.mb_total - SUM (A.used_blocks * D.block_size) / 1024 / 1024 mb_free
  FROM v$sort_segment A,
   (
  SELECT B.name, C.block_size, SUM (C.bytes) / 1024 / 1024 mb_total
   FROM v$tablespace B, v$tempfile C
    WHERE B.ts#= C.ts#
     GROUP BY B.name, C.block_size) D
   WHERE A.tablespace_name = D.name
   GROUP by A.tablespace_name, D.mb_total;
============================================================================================================================
####### KILL ALL ACTIVE AND INACTIVE SESSIONS FOR USER

BEGIN
  FOR r IN (select sid,serial# from v$session where username='<user-name>')
  LOOP
      EXECUTE IMMEDIATE 'alter system kill session ''' || r.sid  || ',' 
        || r.serial# || ''' immediate';
  END LOOP;
END;
============================================================================================================================
####### ONLY FOR AVON
#### If account is disabled/locked

The service call must be transferred to /

Related Records -> Interactions -> Owning Workgroup -> (Paste in Assinging Group)

### If activation of locked/disabled account is needed, do not raise a service request, do it from the link below.

Service Catalogue Request 

http://shareit.global.avon.com/sites/GNCS/HP/Shared%20Documents/Internal%20Controls%20and%20Access%20Lists/DB_Account_Management/DB_Account_Access_Request_Procedure_HPE_Service_Catalog_ReadMe.rtf
============================================================================================================================
####### ORACLE BACKUP ON WINDOWS MACHINE (58 metric)

1st step: hop or rdp
2nd step: rdp -> connection to the server
3rd step: checking if we are registered on the server -> Start button -> Administrative Tools -> Computer Management
4th step: Command Prompt: we are typing the following commands: dbspicao -pdfv (to see the path to the ORACLE_HOME) and dbspicao -m58 -r1 -i <db_name>
5th step: In new Command Prompt window we are typing: set ORACLE_SID=<db_name> and set ORACLE_HOME=<db_name>
6th step: To login in RMAN we need to type: "cd <ORACLE_HOME>\bin" and then to login in RMAN to type "rman target /"
7th step: To start backup on oracle hosted on windows machine, to get the backup script we need to go to this folder: "C:\Programs\Tivoli\tsm\<db_name>\rman" and to choose the script for which is the case.
8th step: Wait the backup to complete and close the ticket :)

============================================================================================================================
####### List all database parameters.


SET PAUSE ON
SET PAUSE 'Press Return to Continue'
SET PAGESIZE 60
SET LINESIZE 300
 
COLUMN name  FORMAT A30
COLUMN value FORMAT A70
COLUMN ses_mod FORMAT a10
COLUMN sys_mod FORMAT a10
COLUMN ins_mod FORMAT a10
 
SELECT p.name,
       p.type,
       p.value,
       p.isses_modifiable as SES_MOD,
       p.issys_modifiable as SYS_MOD,
       p.isinstance_modifiable as INS_MOD
FROM   v$parameter p
ORDER BY p.name
/

============================================================================================================================
####### UXMON: Filesystem /var diskspace utilization exceeds 90 threshold.

1/ as root going to /tmp/oradiag_root/diag/clients/user_root/host_344946746_80/trace/sqlnet.log and tail the sqlnet.log

find / -name sqlnet*

2/ going to /u01/app/oracle/product/11.2.0/udi_11204/log and list all directories

3/ create in all directories in /log/diag/ and create new dir clients.

4/ tail the sqlnet.log and wait and check to see if there are new errors generated.

5/ going to cd /var/tmp/ and remove oradiag_root with command rm -rf oradiag_root

6/ check the free space in /var (df -h . or df -h /var)

7/ close the case

============================================================================================================================
####### CHECK FOR GRP - (GUARANTEE RESTORE POINT)

set lines 300 
col NAME for a30 
col time for a40 
SELECT NAME, SCN, TIME,GUARANTEE_FLASHBACK_DATABASE,STORAGE_SIZE 
FROM V$RESTORE_POINT;  

============================================================================================================================
####### Terminal too wide

stty columns 160
============================================================================================================================
####### LIST DISK GROUP, FILEPATH STATUS (ASM)

set pages 1000
col path format a40
set lines 200
col failgroup format a30
col path format a40
select GROUP_NUMBER,NAME, STATE, MOUNT_STATUS,MODE_STATUS, HEADER_STATUS, FAILGROUP,PATH, TOTAL_MB,FREE_MB,OS_MB, MOUNT_DATE from v$asm_disk; 

============================================================================================================================
#######
============================================================================================================================
#######
============================================================================================================================
#######
============================================================================================================================
#######
============================================================================================================================
#######
============================================================================================================================
#######