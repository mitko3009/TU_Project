/********************************************************************************
*********       E-mail subject: IMBDEV-11989
*********             Instance: PROD
*********          Description: 
Problem:
SQL 3hgxvdu4wjffh was found in the V9 logs from screen e_pmtalettrer

Analysis:
We analyzed SQL 3hgxvdu4wjffh, which based on the V9 logs was associated with the slowness in screen e_pmtalettrer.
There are two problems in this SQL. The first one is that index G_VENTILENC_TRAITE_IDX on table G_VENTILENC is missing on IMB PROD and 
the second problem is that inappropriate hint was used. To improve the performance, we need index G_VENTILENC_TRAITE_IDX to be delivered from REFBG2 to IMB PROD
and the hint to be changed as it is shown in the New SQL section below.

Suggestion:
1. Please ask DBA to deliver the missing index G_VENTILENC_TRAITE_IDX on table G_VENTILENC from REFBG2 to IMB PROD.
2. Please ask Apps and Services team to change the hint as it is shown in the New SQL section below.

*********               SQL_ID: 3hgxvdu4wjffh
*********      Program/Package: 
*********              Request: Dimitare Ivanov
*********               Author: Dimitar Dimitrov
********* Received e-mail date: 23/05/2024
*********      Resolution date: 27/05/2024
*********  Trace old file here: \\epox\specifs\performance\tmp\
*********  Trace new file here:
***********************************************************************************/

/********************************OLD SQL*******************************************/

VAR B1 VARCHAR2(128);
EXEC :B1 := 'WO&WO SONNENLICHTDESIGN GMBH & CO KG%';
VAR B2 NUMBER;
EXEC :B2 := 2001;
VAR B3 NUMBER;
EXEC :B3 := 1;


SELECT *
  FROM (SELECT /*+ first_rows(2001)*/
         foo.*, ROWNUM rnum
          FROM (SELECT tbl.refencaiss pmtRef,
                       tbl.receptionDate pmtDate,
                       tbl.bookCode bookCode,
                       tbl.montant_mvt pmtAmount,
                       tbl.devise_mvt pmtCurrency,
                       balance unmAmount,
                       tbl.communication pmtCommunication,
                       CL.nom clientName,
                       CL.prenom clientFstName,
                       CL.nom || ' ' || CL.prenom clientFullName,
                       tbl.refdoss caseRef,
                       tbl.comments intComment,
                       tbl.ext_comments extComment,
                       (SELECT refext
                          FROM t_individu
                         WHERE 1 = 1
                           AND societe = 'CLIENT_NUMBER'
                           AND refindividu = tbl.refpayeur
                           AND refext2 = CL.refindividu
                           AND rownum = 1) clclNumber,
                       DB.nom debtorName,
                       (SELECT G.nom
                          FROM g_piece P, g_individu G
                         WHERE 1 = 1
                           AND P.refdoss =
                               (SELECT reflot
                                  FROM g_dossier
                                 WHERE refdoss =
                                       (SELECT reflot
                                          FROM g_dossier
                                         WHERE refdoss = tbl.refdoss))
                           AND P.typpiece = 'CONTRAT'
                           AND P.str_20_1 = G.refindividu) thirdCtraManagerName,
                       (SELECT case
                                 when 0 <
                                      (select count(*)
                                         FROM g_dossier CMT,
                                              g_dossier DEC,
                                              g_dossier CTR,
                                              g_dossier REV
                                        WHERE 1 = 1
                                          AND CMT.refdoss = tbl.refdoss
                                          AND CMT.reflot = DEC.refdoss
                                          AND DEC.reflot = CTR.Refdoss
                                          AND CTR.refhierarchie = REV.refdoss
                                          AND REV.categdoss = 'COMPTE DB CTR') then
                                  'Reverse'
                                 else
                                  'Classical'
                               end
                          from dual) factoringType,
                       MAN.nom caseManagerName
                  FROM (SELECT /*+ leading(TNMP) index(TNMP aggreg_t_ecrdos_nmp$bal) */
                         ENC.refencaiss,
                         ENC.comments,
                         ENC.ext_comments,
                         D.chemin AS bookCode,
                         ENC.devise_mvt,
                         NVL(ENC.dtencaiss_dt, ENC.dtreception_dt) AS receptionDate,
                         VENTIL.montant_mvt,
                         ENC.refpayeur,
                         ENC.comm || ENC.comm2 AS communication,
                         DECODE(FTR_MATCH.PartieLettrePmt(VENTIL.refencaiss,
                                                          VENTIL.refdoss,
                                                          'en'),
                                0.0,
                                VENTIL.montant_mvt,
                                CH_TAUX.ConversDosMvt(ENC.dtjour,
                                                      VENTIL.refdoss,
                                                      VENTIL.montant_dos -
                                                      FTR_MATCH.PartieLettrePmt(VENTIL.refencaiss,
                                                                                VENTIL.refdoss,
                                                                                'en'),
                                                      ENC.devise_mvt,
                                                      'A')) AS BALANCE,
                         VENTIL.refdoss
                          FROM g_ventilenc         VENTIL,
                               g_encaissement      ENC,
                               nam_collecte        NC,
                               aggreg_t_ecrdos_nmp TNMP,
                               v_domaine           D
                         WHERE ENC.traite = '2'
                           AND NC.refer(+) = ENC.refencaiss
                           AND NC.compostage(+) = ENC.lieupaimt
                           AND ENC.typencaiss IN ('e_saencaiss', 'e_savirmt')
                           AND ENC.refencaiss = VENTIL.refencaiss
                           AND VENTIL.refencaiss = TNMP.refelem
                           AND VENTIL.refdoss = TNMP.refdoss
                           AND TNMP.balance_dcpt < 0
                           AND D.type(+) = 'NAM_COLLECTE'
                           AND SUBSTR(ENC.lieupaimt, 1, 3) = D.abrev(+)
                        UNION ALL
                        SELECT /*+ leading(VENTIL) index(VENTIL G_VENTILENC_REFDOSS_TRAITE) */
                         ENC.refencaiss,
                         ENC.comments,
                         ENC.ext_comments,
                         D.chemin AS bookCode,
                         ENC.devise_mvt,
                         NVL(ENC.dtencaiss_dt, ENC.dtreception_dt) AS receptionDate,
                         VENTIL.montant_mvt,
                         ENC.refpayeur,
                         ENC.comm || ENC.comm2 AS communication,
                         DECODE(FTR_MATCH.PartPreLettrPmt(VENTIL.refencaiss,
                                                          VENTIL.refdoss,
                                                          'en'),
                                0.0,
                                VENTIL.montant_mvt,
                                CH_TAUX.ConversDosMvt(ENC.dtjour,
                                                      VENTIL.refdoss,
                                                      VENTIL.montant_dos -
                                                      FTR_MATCH.PartPreLettrPmt(VENTIL.refencaiss,
                                                                                VENTIL.refdoss,
                                                                                'en'),
                                                      ENC.devise_mvt,
                                                      'A')) AS BALANCE,
                         VENTIL.refdoss
                          FROM g_ventilenc    VENTIL,
                               g_encaissement ENC,
                               nam_collecte   NC,
                               t_elements     E,
                               v_domaine      D
                         WHERE VENTIL.traite = '0'
                           AND NC.refer(+) = ENC.refencaiss
                           AND NC.compostage(+) = ENC.lieupaimt
                           AND ENC.typencaiss IN ('e_saencaiss', 'e_savirmt')
                           AND ENC.refencaiss = VENTIL.refencaiss
                           AND E.refdoss = VENTIL.refdoss
                           AND E.typeelem = 'en'
                           AND E.refelem = ENC.refencaiss
                           AND D.type(+) = 'NAM_COLLECTE'
                           AND SUBSTR(ENC.lieupaimt, 1, 3) = D.abrev(+)) tbl,
                       t_intervenants CLI,
                       g_individu CL,
                       g_dossier DOSS,
                       g_individu DB,
                       g_personnel USR,
                       g_individu MAN
                 WHERE 1 = 1
                   AND CLI.reftype = 'CL'
                   AND CLI.refdoss = tbl.refdoss
                   AND CLI.refindividu = CL.refindividu
                   AND DOSS.refdoss = tbl.refdoss
                   AND DB.refindividu = tbl.refpayeur
                   AND USR.refperso = DOSS.rangmt
                   AND USR.refindividu = MAN.refindividu
                   AND CL.nom || ' ' || CL.prenom like :B1 || '%'
                 ORDER BY pmtDate, pmtAmount DESC, bookCode, pmtRef) foo
         WHERE ROWNUM <= :B2)
WHERE 1 = 1
   AND rnum >= :B3;
/********************************OLD SQL*******************************************/
/********************************OLD Metrics***************************************/
/*
Plan hash value: 1906507587
----------------------------------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                           | Name                           | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  |
----------------------------------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                                    |                                |      1 |        | 57780 (100)|      0 |00:00:00.01 |       0 |      0 |
|*  1 |  COUNT STOPKEY                                      |                                |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*  2 |   TABLE ACCESS BY INDEX ROWID BATCHED               | T_INDIVIDU                     |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*  3 |    INDEX RANGE SCAN                                 | IX_T_INDIVIDU                  |      0 |      5 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|   4 |  NESTED LOOPS                                       |                                |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|   5 |   NESTED LOOPS                                      |                                |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*  6 |    TABLE ACCESS BY INDEX ROWID BATCHED              | G_PIECE                        |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*  7 |     INDEX RANGE SCAN                                | PIE_REFDOSS                    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*  8 |      INDEX RANGE SCAN                               | DOS_REFDOSS_REFLOT_IDX         |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*  9 |       INDEX RANGE SCAN                              | DOS_REFDOSS_REFLOT_IDX         |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 10 |    INDEX UNIQUE SCAN                                | IND_REFINDIV                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|  11 |   TABLE ACCESS BY INDEX ROWID                       | G_INDIVIDU                     |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|  12 |  NESTED LOOPS                                       |                                |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|  13 |   NESTED LOOPS                                      |                                |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|  14 |    NESTED LOOPS                                     |                                |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|  15 |     NESTED LOOPS                                    |                                |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 16 |      INDEX RANGE SCAN                               | DOS_REFDOSS_REFLOT_IDX         |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 17 |      INDEX RANGE SCAN                               | DOS_REFDOSS_REFLOT_IDX         |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 18 |     TABLE ACCESS BY INDEX ROWID                     | G_DOSSIER                      |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 19 |      INDEX UNIQUE SCAN                              | DOS_REFDOSS                    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 20 |    INDEX UNIQUE SCAN                                | DOS_REFDOSS                    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 21 |   TABLE ACCESS BY INDEX ROWID                       | G_DOSSIER                      |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|  22 |  FAST DUAL                                          |                                |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 23 |  VIEW                                               |                                |      1 |    415 | 57780   (1)|      0 |00:00:00.01 |       0 |      0 |
|* 24 |   COUNT STOPKEY                                     |                                |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  25 |    VIEW                                             |                                |      1 |    415 | 57780   (1)|      0 |00:00:00.01 |       0 |      0 |
|* 26 |     SORT ORDER BY STOPKEY                           |                                |      1 |    415 | 57780   (1)|      0 |00:00:00.01 |       0 |      0 |
|  27 |      NESTED LOOPS                                   |                                |      1 |    415 | 55572   (1)|      3 |00:00:00.43 |   51628 |      1 |
|  28 |       NESTED LOOPS                                  |                                |      1 |    422 | 55563   (1)|      3 |00:00:00.43 |   51619 |      1 |
|  29 |        NESTED LOOPS                                 |                                |      1 |    422 | 55555   (1)|      3 |00:00:00.43 |   51613 |      1 |
|  30 |         NESTED LOOPS                                |                                |      1 |    422 | 55546   (1)|      3 |00:00:00.43 |   51605 |      1 |
|  31 |          NESTED LOOPS                               |                                |      1 |    432 | 55538   (1)|      3 |00:00:00.43 |   51594 |      1 |
|* 32 |           HASH JOIN                                 |                                |      1 |    653 | 55525   (1)|   3142 |00:00:00.44 |   49595 |      1 |
|* 33 |            INDEX SKIP SCAN                          | INT_INDIV                      |      1 |  48259 |    36   (0)|    241K|00:00:00.11 |    3564 |      0 |
|  34 |            VIEW                                     |                                |      1 |   2005 | 55489   (1)|   3142 |00:00:00.26 |   46031 |      1 |
|  35 |             UNION-ALL                               |                                |      1 |        |            |   3142 |00:00:00.26 |   46031 |      1 |
|* 36 |              HASH JOIN RIGHT OUTER                  |                                |      1 |   2002 |   197   (0)|   3142 |00:00:00.05 |   18684 |      1 |
|  37 |               TABLE ACCESS BY INDEX ROWID BATCHED   | V_DOMAINE                      |      1 |     45 |     1   (0)|    604 |00:00:00.01 |      65 |      0 |
|* 38 |                INDEX RANGE SCAN                     | V_DOMAINE_TYPE_CODE_IDX        |      1 |     45 |     1   (0)|    604 |00:00:00.01 |      20 |      0 |
|  39 |               NESTED LOOPS                          |                                |      1 |   2002 |   196   (0)|   3142 |00:00:00.05 |   18619 |      1 |
|  40 |                NESTED LOOPS                         |                                |      1 |   4863 |   196   (0)|   3142 |00:00:00.03 |   15657 |      0 |
|  41 |                 NESTED LOOPS                        |                                |      1 |   4863 |    98   (0)|   3142 |00:00:00.02 |    9443 |      0 |
|* 42 |                  INDEX RANGE SCAN                   | AGGREG_T_ECRDOS_NMP$BAL        |      1 |   4863 |     1   (0)|   3142 |00:00:00.01 |      84 |      0 |
|  43 |                  TABLE ACCESS BY INDEX ROWID        | G_VENTILENC                    |   3142 |      1 |     1   (0)|   3142 |00:00:00.02 |    9359 |      0 |
|* 44 |                   INDEX UNIQUE SCAN                 | VENT_REFDOSS                   |   3142 |      1 |     1   (0)|   3142 |00:00:00.01 |    6214 |      0 |
|* 45 |                 INDEX UNIQUE SCAN                   | REFENCAISS                     |   3142 |      1 |     1   (0)|   3142 |00:00:00.01 |    6214 |      0 |
|* 46 |                TABLE ACCESS BY INDEX ROWID          | G_ENCAISSEMENT                 |   3142 |      1 |     1   (0)|   3142 |00:00:00.01 |    2962 |      1 |
|  47 |              NESTED LOOPS OUTER                     |                                |      1 |      3 | 55292   (1)|      0 |00:00:00.01 |       0 |      0 |
|* 48 |               HASH JOIN                             |                                |      1 |      3 | 55291   (1)|      0 |00:00:00.01 |       0 |      0 |
|  49 |                TABLE ACCESS BY INDEX ROWID BATCHED  | T_ELEMENTS                     |      1 |   1226K|  5099   (1)|   2087K|00:00:48.61 |     186K|    137K|
|* 50 |                 INDEX SKIP SCAN                     | TE_DTASSOC_DT                  |      1 |   1226K|  1491   (1)|   2087K|00:00:18.18 |   46267 |  46265 |
|  51 |                NESTED LOOPS                         |                                |      0 |   1676K| 40987   (1)|      0 |00:00:00.01 |       0 |      0 |
|  52 |                 NESTED LOOPS                        |                                |      0 |   1676K| 40987   (1)|      0 |00:00:00.01 |       0 |      0 |
|  53 |                  TABLE ACCESS BY INDEX ROWID BATCHED| G_VENTILENC                    |      0 |   1676K|  7452   (1)|      0 |00:00:00.01 |       0 |      0 |
|* 54 |                   INDEX SKIP SCAN                   | G_VENTILENC_REFDOSS_TRAITE     |      0 |   1676K|   269   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 55 |                  INDEX UNIQUE SCAN                  | REFENCAISS                     |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 56 |                 TABLE ACCESS BY INDEX ROWID         | G_ENCAISSEMENT                 |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|  57 |               TABLE ACCESS BY INDEX ROWID BATCHED   | V_DOMAINE                      |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 58 |                INDEX RANGE SCAN                     | DOM_TYPABREV                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 59 |           TABLE ACCESS BY INDEX ROWID               | G_INDIVIDU                     |   3142 |      1 |     1   (0)|      3 |00:00:00.01 |    8726 |      0 |
|* 60 |            INDEX UNIQUE SCAN                        | IND_REFINDIV                   |   3142 |      1 |     1   (0)|   3142 |00:00:00.01 |    6128 |      0 |
|  61 |          TABLE ACCESS BY INDEX ROWID                | G_INDIVIDU                     |      3 |      1 |     1   (0)|      3 |00:00:00.01 |      11 |      0 |
|* 62 |           INDEX UNIQUE SCAN                         | IND_REFINDIV                   |      3 |      1 |     1   (0)|      3 |00:00:00.01 |       8 |      0 |
|* 63 |         INDEX RANGE SCAN                            | G_DOSSIER_REFDOSS_SOLDE_RANGMT |      3 |      1 |     1   (0)|      3 |00:00:00.01 |       8 |      0 |
|  64 |        TABLE ACCESS BY INDEX ROWID BATCHED          | G_PERSONNEL                    |      3 |      1 |     1   (0)|      3 |00:00:00.01 |       6 |      0 |
|* 65 |         INDEX RANGE SCAN                            | GPERSREFP                      |      3 |      1 |     1   (0)|      3 |00:00:00.01 |       5 |      0 |
|  66 |       TABLE ACCESS BY INDEX ROWID                   | G_INDIVIDU                     |      3 |      1 |     1   (0)|      3 |00:00:00.01 |       9 |      0 |
|* 67 |        INDEX UNIQUE SCAN                            | IND_REFINDIV                   |      3 |      1 |     1   (0)|      3 |00:00:00.01 |       8 |      0 |
----------------------------------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   1 - filter(ROWNUM=1)
   2 - filter(("REFEXT2"=:B1 AND "SOCIETE"='CLIENT_NUMBER'))
   3 - access("REFINDIVIDU"=:B1)
   6 - filter("P"."STR_20_1" IS NOT NULL)
   7 - access("P"."REFDOSS"= AND "P"."TYPPIECE"='CONTRAT')
   8 - access("REFDOSS"=)
   9 - access("REFDOSS"=:B1)
  10 - access("P"."STR_20_1"="G"."REFINDIVIDU")
  16 - access("CMT"."REFDOSS"=:B1)
  17 - access("CMT"."REFLOT"="DEC"."REFDOSS")
  18 - filter("CTR"."REFHIERARCHIE" IS NOT NULL)
  19 - access("DEC"."REFLOT"="CTR"."REFDOSS")
  20 - access("CTR"."REFHIERARCHIE"="REV"."REFDOSS")
  21 - filter("REV"."CATEGDOSS"='COMPTE DB CTR')
  23 - filter("RNUM">=:B3)
  24 - filter(ROWNUM<=:B2)
  26 - filter(ROWNUM<=:B2)
  32 - access("CLI"."REFDOSS"="TBL"."REFDOSS")
  33 - access("CLI"."REFTYPE"='CL')
       filter("CLI"."REFTYPE"='CL')
  36 - access("D"."ABREV"=SUBSTR("ENC"."LIEUPAIMT",1,3))
  38 - access("D"."TYPE"='NAM_COLLECTE')
  42 - access("TNMP"."BALANCE_DCPT"<0)
  44 - access("VENTIL"."REFDOSS"="TNMP"."REFDOSS" AND "VENTIL"."REFENCAISS"="TNMP"."REFELEM")
  45 - access("ENC"."REFENCAISS"="VENTIL"."REFENCAISS")
  46 - filter((INTERNAL_FUNCTION("ENC"."TYPENCAISS") AND "ENC"."TRAITE"='2'))
  48 - access("E"."REFDOSS"="VENTIL"."REFDOSS" AND "E"."REFELEM"="ENC"."REFENCAISS")
  50 - access("E"."TYPEELEM"='en')
       filter("E"."TYPEELEM"='en')
  54 - access("VENTIL"."TRAITE"='0')
       filter("VENTIL"."TRAITE"='0')
  55 - access("ENC"."REFENCAISS"="VENTIL"."REFENCAISS")
  56 - filter(("ENC"."TYPENCAISS"='e_saencaiss' OR "ENC"."TYPENCAISS"='e_savirmt'))
  58 - access("D"."TYPE"='NAM_COLLECTE' AND "D"."ABREV"=SUBSTR("ENC"."LIEUPAIMT",1,3))
  59 - filter("CL"."NOM"||' '||"CL"."PRENOM" LIKE :B1||'%')
  60 - access("CLI"."REFINDIVIDU"="CL"."REFINDIVIDU")
  62 - access("DB"."REFINDIVIDU"="TBL"."REFPAYEUR")
  63 - access("DOSS"."REFDOSS"="TBL"."REFDOSS")
  65 - access("USR"."REFPERSO"="DOSS"."RANGMT")
  67 - access("USR"."REFINDIVIDU"="MAN"."REFINDIVIDU")

*/
/********************************OLD Metrics***************************************/

/********************************New SQL*******************************************/

SELECT *
  FROM (SELECT /*+ first_rows(2001)*/
         foo.*, ROWNUM rnum
          FROM (SELECT tbl.refencaiss pmtRef,
                       tbl.receptionDate pmtDate,
                       tbl.bookCode bookCode,
                       tbl.montant_mvt pmtAmount,
                       tbl.devise_mvt pmtCurrency,
                       balance unmAmount,
                       tbl.communication pmtCommunication,
                       CL.nom clientName,
                       CL.prenom clientFstName,
                       CL.nom || ' ' || CL.prenom clientFullName,
                       tbl.refdoss caseRef,
                       tbl.comments intComment,
                       tbl.ext_comments extComment,
                       (SELECT refext
                          FROM t_individu
                         WHERE 1 = 1
                           AND societe = 'CLIENT_NUMBER'
                           AND refindividu = tbl.refpayeur
                           AND refext2 = CL.refindividu
                           AND rownum = 1) clclNumber,
                       DB.nom debtorName,
                       (SELECT G.nom
                          FROM g_piece P, g_individu G
                         WHERE 1 = 1
                           AND P.refdoss =
                               (SELECT reflot
                                  FROM g_dossier
                                 WHERE refdoss =
                                       (SELECT reflot
                                          FROM g_dossier
                                        WHERE refdoss = tbl.refdoss))
                           AND P.typpiece = 'CONTRAT'
                           AND P.str_20_1 = G.refindividu) thirdCtraManagerName,
                       (SELECT case
                                 when 0 <
                                      (select count(*)
                                         FROM g_dossier CMT,
                                              g_dossier DEC,
                                              g_dossier CTR,
                                              g_dossier REV
                                        WHERE 1 = 1
                                          AND CMT.refdoss = tbl.refdoss
                                          AND CMT.reflot = DEC.refdoss
                                          AND DEC.reflot = CTR.Refdoss
                                          AND CTR.refhierarchie = REV.refdoss
                                          AND REV.categdoss = 'COMPTE DB CTR') then
                                  'Reverse'
                                 else
                                  'Classical'
                               end
                          from dual) factoringType,
                       MAN.nom caseManagerName
                  FROM (SELECT /*+ leading(TNMP) index(TNMP aggreg_t_ecrdos_nmp$bal) */
                         ENC.refencaiss,
                         ENC.comments,
                         ENC.ext_comments,
                         D.chemin AS bookCode,
                         ENC.devise_mvt,
                         NVL(ENC.dtencaiss_dt, ENC.dtreception_dt) AS receptionDate,
                         VENTIL.montant_mvt,
                         ENC.refpayeur,
                         ENC.comm || ENC.comm2 AS communication,
                         DECODE(FTR_MATCH.PartieLettrePmt(VENTIL.refencaiss,
                                                          VENTIL.refdoss,
                                                          'en'),
                                0.0,
                                VENTIL.montant_mvt,
                                CH_TAUX.ConversDosMvt(ENC.dtjour,
                                                      VENTIL.refdoss,
                                                      VENTIL.montant_dos -
                                                      FTR_MATCH.PartieLettrePmt(VENTIL.refencaiss,
                                                                                VENTIL.refdoss,
                                                                                'en'),
                                                      ENC.devise_mvt,
                                                      'A')) AS BALANCE,
                         VENTIL.refdoss
                          FROM g_ventilenc         VENTIL,
                               g_encaissement      ENC,
                               nam_collecte        NC,
                               aggreg_t_ecrdos_nmp TNMP,
                               v_domaine           D
                         WHERE ENC.traite = '2'
                           AND NC.refer(+) = ENC.refencaiss
                           AND NC.compostage(+) = ENC.lieupaimt
                           AND ENC.typencaiss IN ('e_saencaiss', 'e_savirmt')
                           AND ENC.refencaiss = VENTIL.refencaiss
                           AND VENTIL.refencaiss = TNMP.refelem
                           AND VENTIL.refdoss = TNMP.refdoss
                           AND TNMP.balance_dcpt < 0
                           AND D.type(+) = 'NAM_COLLECTE'
                           AND SUBSTR(ENC.lieupaimt, 1, 3) = D.abrev(+)
                        UNION ALL
                        SELECT /*+ leading(VENTIL) index(VENTIL G_VENTILENC_TRAITE_IDX) use_nl(e)*/
                         ENC.refencaiss,
                         ENC.comments,
                         ENC.ext_comments,
                         D.chemin AS bookCode,
                         ENC.devise_mvt,
                         NVL(ENC.dtencaiss_dt, ENC.dtreception_dt) AS receptionDate,
                         VENTIL.montant_mvt,
                         ENC.refpayeur,
                         ENC.comm || ENC.comm2 AS communication,
                         DECODE(FTR_MATCH.PartPreLettrPmt(VENTIL.refencaiss,
                                                          VENTIL.refdoss,
                                                          'en'),
                                0.0,
                                VENTIL.montant_mvt,
                                CH_TAUX.ConversDosMvt(ENC.dtjour,
                                                      VENTIL.refdoss,
                                                      VENTIL.montant_dos -
                                                      FTR_MATCH.PartPreLettrPmt(VENTIL.refencaiss,
                                                                                VENTIL.refdoss,
                                                                                'en'),
                                                      ENC.devise_mvt,
                                                      'A')) AS BALANCE,
                         VENTIL.refdoss
                          FROM g_ventilenc    VENTIL,
                               g_encaissement ENC,
                               nam_collecte   NC,
                               t_elements     E,
                               v_domaine      D
                         WHERE VENTIL.traite = '0'
                           AND NC.refer(+) = ENC.refencaiss
                           AND NC.compostage(+) = ENC.lieupaimt
                           AND ENC.typencaiss IN ('e_saencaiss', 'e_savirmt')
                           AND ENC.refencaiss = VENTIL.refencaiss
                           AND E.refdoss = VENTIL.refdoss
                           AND E.typeelem = 'en'
                           AND E.refelem = ENC.refencaiss
                           AND D.type(+) = 'NAM_COLLECTE'
                           AND SUBSTR(ENC.lieupaimt, 1, 3) = D.abrev(+)) tbl,
                       t_intervenants CLI,
                       g_individu CL,
                       g_dossier DOSS,
                       g_individu DB,
                       g_personnel USR,
                       g_individu MAN
                 WHERE 1 = 1
                   AND CLI.reftype = 'CL'
                   AND CLI.refdoss = tbl.refdoss
                   AND CLI.refindividu = CL.refindividu
                   AND DOSS.refdoss = tbl.refdoss
                   AND DB.refindividu = tbl.refpayeur
                   AND USR.refperso = DOSS.rangmt
                   AND USR.refindividu = MAN.refindividu
                   AND CL.nom || ' ' || CL.prenom like :B1 || '%'
                 ORDER BY pmtDate, pmtAmount DESC, bookCode, pmtRef) foo
         WHERE ROWNUM <= :B2)
WHERE 1 = 1
   AND rnum >= :B3;
/********************************New SQL*******************************************/
/********************************New Metrics***************************************/
/*
Plan hash value: 1698593910
------------------------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                          | Name                           | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers |
------------------------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                                   |                                |      1 |        |   103K(100)|      0 |00:00:00.42 |   58282 |
|*  1 |  COUNT STOPKEY                                     |                                |      0 |        |            |      0 |00:00:00.01 |       0 |
|*  2 |   TABLE ACCESS BY INDEX ROWID BATCHED              | T_INDIVIDU                     |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|*  3 |    INDEX RANGE SCAN                                | IX_T_INDIVIDU                  |      0 |      5 |     1   (0)|      0 |00:00:00.01 |       0 |
|   4 |  NESTED LOOPS                                      |                                |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |
|   5 |   NESTED LOOPS                                     |                                |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |
|*  6 |    TABLE ACCESS BY INDEX ROWID BATCHED             | G_PIECE                        |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|*  7 |     INDEX RANGE SCAN                               | PIE_REFDOSS                    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|*  8 |      INDEX RANGE SCAN                              | DOS_REFDOSS_REFLOT_IDX         |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|*  9 |       INDEX RANGE SCAN                             | DOS_REFDOSS_REFLOT_IDX         |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 10 |    INDEX UNIQUE SCAN                               | IND_REFINDIV                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|  11 |   TABLE ACCESS BY INDEX ROWID                      | G_INDIVIDU                     |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|  12 |  NESTED LOOPS                                      |                                |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|  13 |   NESTED LOOPS                                     |                                |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|  14 |    NESTED LOOPS                                    |                                |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|  15 |     NESTED LOOPS                                   |                                |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |
|* 16 |      INDEX RANGE SCAN                              | DOS_REFDOSS_REFLOT_IDX         |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 17 |      INDEX RANGE SCAN                              | DOS_REFDOSS_REFLOT_IDX         |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 18 |     TABLE ACCESS BY INDEX ROWID                    | G_DOSSIER                      |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 19 |      INDEX UNIQUE SCAN                             | DOS_REFDOSS                    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 20 |    INDEX UNIQUE SCAN                               | DOS_REFDOSS                    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 21 |   TABLE ACCESS BY INDEX ROWID                      | G_DOSSIER                      |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|  22 |  FAST DUAL                                         |                                |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |
|* 23 |  VIEW                                              |                                |      1 |    415 |   103K  (1)|      0 |00:00:00.42 |   58282 |
|* 24 |   COUNT STOPKEY                                    |                                |      1 |        |            |      0 |00:00:00.42 |   58282 |
|  25 |    VIEW                                            |                                |      1 |    415 |   103K  (1)|      0 |00:00:00.42 |   58282 |
|* 26 |     SORT ORDER BY STOPKEY                          |                                |      1 |    415 |   103K  (1)|      0 |00:00:00.42 |   58282 |
|  27 |      NESTED LOOPS                                  |                                |      1 |    415 |   101K  (1)|      0 |00:00:00.42 |   58282 |
|  28 |       NESTED LOOPS                                 |                                |      1 |    422 |   101K  (1)|      0 |00:00:00.42 |   58282 |
|  29 |        NESTED LOOPS                                |                                |      1 |    422 |   101K  (1)|      0 |00:00:00.42 |   58282 |
|  30 |         NESTED LOOPS                               |                                |      1 |    422 |   101K  (1)|      0 |00:00:00.42 |   58282 |
|  31 |          NESTED LOOPS                              |                                |      1 |    432 |   101K  (1)|      0 |00:00:00.42 |   58282 |
|* 32 |           HASH JOIN                                |                                |      1 |    653 |   101K  (1)|   3142 |00:00:00.41 |   49556 |
|* 33 |            INDEX SKIP SCAN                         | INT_INDIV                      |      1 |  48259 |    36   (0)|    241K|00:00:00.14 |    3564 |
|  34 |            VIEW                                    |                                |      1 |   2005 |   101K  (1)|   3142 |00:00:00.16 |   45992 |
|  35 |             UNION-ALL                              |                                |      1 |        |            |   3142 |00:00:00.16 |   45992 |
|* 36 |              HASH JOIN RIGHT OUTER                 |                                |      1 |   2002 |   197   (0)|   3142 |00:00:00.05 |   18684 |
|  37 |               TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE                      |      1 |     45 |     1   (0)|    604 |00:00:00.01 |      65 |
|* 38 |                INDEX RANGE SCAN                    | V_DOMAINE_TYPE_CODE_IDX        |      1 |     45 |     1   (0)|    604 |00:00:00.01 |      20 |
|  39 |               NESTED LOOPS                         |                                |      1 |   2002 |   196   (0)|   3142 |00:00:00.05 |   18619 |
|  40 |                NESTED LOOPS                        |                                |      1 |   4863 |   196   (0)|   3142 |00:00:00.04 |   15657 |
|  41 |                 NESTED LOOPS                       |                                |      1 |   4863 |    98   (0)|   3142 |00:00:00.02 |    9443 |
|* 42 |                  INDEX RANGE SCAN                  | AGGREG_T_ECRDOS_NMP$BAL        |      1 |   4863 |     1   (0)|   3142 |00:00:00.01 |      84 |
|  43 |                  TABLE ACCESS BY INDEX ROWID       | G_VENTILENC                    |   3142 |      1 |     1   (0)|   3142 |00:00:00.02 |    9359 |
|* 44 |                   INDEX UNIQUE SCAN                | VENT_REFDOSS                   |   3142 |      1 |     1   (0)|   3142 |00:00:00.01 |    6214 |
|* 45 |                 INDEX UNIQUE SCAN                  | REFENCAISS                     |   3142 |      1 |     1   (0)|   3142 |00:00:00.01 |    6214 |
|* 46 |                TABLE ACCESS BY INDEX ROWID         | G_ENCAISSEMENT                 |   3142 |      1 |     1   (0)|   3142 |00:00:00.01 |    2962 |
|  47 |              NESTED LOOPS OUTER                    |                                |      1 |      3 |   101K  (1)|      0 |00:00:00.01 |       3 |
|  48 |               NESTED LOOPS                         |                                |      1 |      3 |   101K  (1)|      0 |00:00:00.01 |       3 |
|  49 |                NESTED LOOPS                        |                                |      1 |   1676K| 34066   (1)|      0 |00:00:00.01 |       3 |
|  50 |                 TABLE ACCESS BY INDEX ROWID BATCHED| G_VENTILENC                    |      1 |   1676K|   531   (0)|      0 |00:00:00.01 |       3 |
|* 51 |                  INDEX RANGE SCAN                  | G_VENTILENC_TRAITE_IDX         |      1 |   1686K|    31   (0)|      0 |00:00:00.01 |       3 |
|* 52 |                 TABLE ACCESS BY INDEX ROWID        | G_ENCAISSEMENT                 |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 53 |                  INDEX UNIQUE SCAN                 | REFENCAISS                     |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 54 |                TABLE ACCESS BY INDEX ROWID BATCHED | T_ELEMENTS                     |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 55 |                 INDEX RANGE SCAN                   | ELE_ELEMTYPE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|  56 |               TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE                      |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 57 |                INDEX RANGE SCAN                    | DOM_TYPABREV                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 58 |           TABLE ACCESS BY INDEX ROWID              | G_INDIVIDU                     |   3142 |      1 |     1   (0)|      0 |00:00:00.01 |    8726 |
|* 59 |            INDEX UNIQUE SCAN                       | IND_REFINDIV                   |   3142 |      1 |     1   (0)|   3142 |00:00:00.01 |    6128 |
|  60 |          TABLE ACCESS BY INDEX ROWID               | G_INDIVIDU                     |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 61 |           INDEX UNIQUE SCAN                        | IND_REFINDIV                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 62 |         INDEX RANGE SCAN                           | G_DOSSIER_REFDOSS_SOLDE_RANGMT |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|  63 |        TABLE ACCESS BY INDEX ROWID BATCHED         | G_PERSONNEL                    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 64 |         INDEX RANGE SCAN                           | GPERSREFP                      |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|  65 |       TABLE ACCESS BY INDEX ROWID                  | G_INDIVIDU                     |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 66 |        INDEX UNIQUE SCAN                           | IND_REFINDIV                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
------------------------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   1 - filter(ROWNUM=1)
   2 - filter(("REFEXT2"=:B1 AND "SOCIETE"='CLIENT_NUMBER'))
   3 - access("REFINDIVIDU"=:B1)
   6 - filter("P"."STR_20_1" IS NOT NULL)
   7 - access("P"."REFDOSS"= AND "P"."TYPPIECE"='CONTRAT')
   8 - access("REFDOSS"=)
   9 - access("REFDOSS"=:B1)
  10 - access("P"."STR_20_1"="G"."REFINDIVIDU")
  16 - access("CMT"."REFDOSS"=:B1)
  17 - access("CMT"."REFLOT"="DEC"."REFDOSS")
  18 - filter("CTR"."REFHIERARCHIE" IS NOT NULL)
  19 - access("DEC"."REFLOT"="CTR"."REFDOSS")
  20 - access("CTR"."REFHIERARCHIE"="REV"."REFDOSS")
  21 - filter("REV"."CATEGDOSS"='COMPTE DB CTR')
  23 - filter("RNUM">=:B3)
  24 - filter(ROWNUM<=:B2)
  26 - filter(ROWNUM<=:B2)
  32 - access("CLI"."REFDOSS"="TBL"."REFDOSS")
  33 - access("CLI"."REFTYPE"='CL')
       filter("CLI"."REFTYPE"='CL')
  36 - access("D"."ABREV"=SUBSTR("ENC"."LIEUPAIMT",1,3))
  38 - access("D"."TYPE"='NAM_COLLECTE')
  42 - access("TNMP"."BALANCE_DCPT"<0)
  44 - access("VENTIL"."REFDOSS"="TNMP"."REFDOSS" AND "VENTIL"."REFENCAISS"="TNMP"."REFELEM")
  45 - access("ENC"."REFENCAISS"="VENTIL"."REFENCAISS")
  46 - filter((INTERNAL_FUNCTION("ENC"."TYPENCAISS") AND "ENC"."TRAITE"='2'))
  51 - access("VENTIL"."TRAITE"='0')
  52 - filter(("ENC"."TYPENCAISS"='e_saencaiss' OR "ENC"."TYPENCAISS"='e_savirmt'))
  53 - access("ENC"."REFENCAISS"="VENTIL"."REFENCAISS")
  54 - filter("E"."REFDOSS"="VENTIL"."REFDOSS")
  55 - access("E"."REFELEM"="ENC"."REFENCAISS" AND "E"."TYPEELEM"='en')
  57 - access("D"."TYPE"='NAM_COLLECTE' AND "D"."ABREV"=SUBSTR("ENC"."LIEUPAIMT",1,3))
  58 - filter("CL"."NOM"||' '||"CL"."PRENOM" LIKE :B1||'%')
  59 - access("CLI"."REFINDIVIDU"="CL"."REFINDIVIDU")
  61 - access("DB"."REFINDIVIDU"="TBL"."REFPAYEUR")
  62 - access("DOSS"."REFDOSS"="TBL"."REFDOSS")
  64 - access("USR"."REFPERSO"="DOSS"."RANGMT")
  66 - access("USR"."REFINDIVIDU"="MAN"."REFINDIVIDU")
*/
/********************************New Metrics***************************************/

/********************************Index statistics**********************************/

/********************************Other SQLs****************************************/          
/*

*/ 
/********************************Other SQLs****************************************/              
