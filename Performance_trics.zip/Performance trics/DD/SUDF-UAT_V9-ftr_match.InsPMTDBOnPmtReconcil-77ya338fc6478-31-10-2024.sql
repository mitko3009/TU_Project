/********************************************************************************
*********       E-mail subject: SUDFWEB-2346
*********             Instance: UAT V9
*********          Description: 
Problem:
The call of ftr_match.InsPMTDBOnPmtReconcil took ~15 minutes on UAT V9 based on what was provided from the BE log.

Analysis:
We checked in the AWR for session with the SID and Serial from the provided BE log. The TOP SQL in this session was 77ya338fc6478 ( inv_bundle.pck ), which was responsible for 100% of the time.
The main problem for the inappropriate execution plan is the condition " DF_NOM IN ('FUBL', 'FUBO', 'FUBS', 'FUBD') " where DF_NOM is column from table F_DETFAC but it is 
written inside the IN operator, which makes Oracle to start the query execution with INDEX FULL SCAN of index AK_DFNUM_DFNOM_F_DETFAC. To avoid this, we made the query on two UNIONs 
and check separate in each of them which is the value of the DF_NOM column. By this way, the CBO starts the execution from the BINDs, which are the most selective predicates.

Suggestion:
Please change the query as it is shown in the New SQL section below.

*********               SQL_ID: 77ya338fc6478
*********      Program/Package: inv_bundle.pck 
*********              Request: Georgi Georgiev 
*********               Author: Dimitar Dimitrov
********* Received e-mail date: 30/10/2024
*********      Resolution date: 31/10/2024
*********  Trace old file here: \\epox\specifs\performance\tmp\
*********  Trace new file here:
***********************************************************************************/

/********************************OLD SQL*******************************************/

VAR B1 VARCHAR2(32);
EXEC :B1 := 'CDPR';
VAR B2 VARCHAR2(32);
EXEC :B2 := 'A70SCJGY';

SELECT DF_NUM, 
       DF_REFINIT, 
       DF_NOM, 
       DF_DOS, 
       DF_CLI, 
       DF_DEB
  FROM F_DETFAC
 WHERE DF_REFINIT IN ( SELECT REFAGGR REFER
                         FROM G_ELEMFI_AGGR
                        WHERE REFFACTURE = ( SELECT REFPIECE2
                                               FROM G_ELEMFI
                                              WHERE REFELEM = :B2
                                                AND NVL( NON_PERFORM_STAT, 'N' ) = 'O' )
                          AND DF_NOM IN ('FUBL', 'FUBO', 'FUBS', 'FUBD')
                          AND NVL(:B1, 'x') = 'x'
                       UNION
                       SELECT :B2 REFER
                         FROM DUAL
                        WHERE DF_NOM = 'CDPR'
                          AND :B1 = 'CDPR' )
   AND DF_ANN IS NULL
 ORDER BY DF_NUM;
/********************************OLD SQL*******************************************/
/********************************OLD Metrics***************************************/
/*
MODULE                           PROGRAM                                            CLIENT_ID       SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- -------------------------------------------------- --------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
89D260E64FC8986D4033BA6880BF8079 iMX BE                                             slomkak         77ya338fc6478  937340137       1288      57613                      2024/10/28 13:12:41  2024/10/28 13:26:32          84                    1 +000000000 00:13:50.388 100%
 
 
MODULE                           PROGRAM                                            CLIENT_ID       SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- -------------------------------------------------- --------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
89D260E64FC8986D4033BA6880BF8079 iMX BE                                             slomkak         77ya338fc6478  937340137       1288      57613 db file sequential r 2024/10/28 13:13:01  2024/10/28 13:26:32          73                    1 +000000000 00:13:30.379 87%
89D260E64FC8986D4033BA6880BF8079 iMX BE                                             slomkak         77ya338fc6478  937340137       1288      57613 ON CPU               2024/10/28 13:12:41  2024/10/28 13:21:12          11                    1 +000000000 00:08:30.235 13%
 
 
MODULE                           PROGRAM                                            CLIENT_ID       SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- -------------------------------------------------- --------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
89D260E64FC8986D4033BA6880BF8079 iMX BE                                             slomkak         77ya338fc6478  937340137       1288      57613                      2024/10/28 13:12:41  2024/10/28 13:26:32          84                    1 +000000000 00:13:50.388 100%
 
 
 
SQL_ID        SQL_PLAN_HASH_VALUE SQL_PLAN_LINE_ID SQL_PLAN_OPERATION             SQL_PLAN_OPTIONS                   ACTIVE
------------- ------------------- ---------------- ------------------------------ ------------------------------ ----------
77ya338fc6478           937340137                2 TABLE ACCESS                   BY INDEX ROWID                         67
77ya338fc6478           937340137                3 INDEX                          FULL SCAN                              10
77ya338fc6478           937340137                4 SORT                           UNIQUE                                  4
77ya338fc6478           937340137                1 FILTER                                                                 2
77ya338fc6478           937340137                6 FILTER                                                                 1


SQL_ID           SNAP_ID INSTANCE_NUMBER NAME                   POSITION DUP_POSITION DATATYPE_STRING      VALUE_STRING                             INTERVAL
------------- ---------- --------------- -------------------- ---------- ------------ -------------------- ---------------------------------------- -----------------------
77ya338fc6478      81265               1 :B2                           1              VARCHAR2(32)         A70SCJGY                                 2024/10/28 12
77ya338fc6478      81265               1 :B1                           2              VARCHAR2(32)         CDPR                                     2024/10/28 12
77ya338fc6478      81265               1 :B2                           3              VARCHAR2(32)         A70SCJGY                                 2024/10/28 12
77ya338fc6478      81265               1 :B1                           4              VARCHAR2(32)         CDPR                                     2024/10/28 12
77ya338fc6478      81277               1 :B2                           1              VARCHAR2(32)         A70SCJH3                                 2024/10/29 00
77ya338fc6478      81277               1 :B1                           2              VARCHAR2(32)         CDPR                                     2024/10/29 00
77ya338fc6478      81277               1 :B2                           3              VARCHAR2(32)         A70SCJH3                                 2024/10/29 00
77ya338fc6478      81277               1 :B1                           4              VARCHAR2(32)         CDPR                                     2024/10/29 00


INSTANCE_NUMBER SQL_ID            ELAPSED MAX_WAIT_ON     PC_OF  WAIT_TIME            GETS      READS       ROWS  ELAP/EXEC       GETS/EXEC READS/EXEC  ROWS/EXEC       EXEC PLAN_HASH_VALUE
--------------- ------------- ----------- --------------- ----- ---------- --------------- ---------- ---------- ---------- --------------- ---------- ---------- ---------- ---------------
              1 77ya338fc6478        2146 IO              92%   1841.75626        28940462    2201275          0     357.73         4823410  366879.17          0          6       937340137


Plan hash value: 937340137
---------------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                               | Name                    | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  |
---------------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                        |                         |      1 |        |   103M(100)|      0 |00:04:45.36 |    5056K|   1199K|
|*  1 |  FILTER                                 |                         |      1 |        |            |      0 |00:04:45.36 |    5056K|   1199K|
|*  2 |   TABLE ACCESS BY INDEX ROWID           | F_DETFAC                |      1 |     25M| 51176   (1)|     25M|00:12:00.81 |    5056K|   1199K|
|   3 |    INDEX FULL SCAN                      | AK_DFNUM_DFNOM_F_DETFAC |      1 |     26M|  1729   (1)|     26M|00:01:38.83 |     172K|    153K|
|   4 |   SORT UNIQUE                           |                         |     25M|      2 |     4   (0)|      0 |00:00:45.85 |       0 |      0 |
|   5 |    UNION-ALL                            |                         |     25M|        |            |      0 |00:00:25.74 |       0 |      0 |
|*  6 |     FILTER                              |                         |     25M|        |            |      0 |00:00:06.37 |       0 |      0 |
|*  7 |      TABLE ACCESS BY INDEX ROWID BATCHED| G_ELEMFI_AGGR           |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*  8 |       INDEX RANGE SCAN                  | ELEMFIAGGR_FK1          |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*  9 |        TABLE ACCESS BY INDEX ROWID      | G_ELEMFI                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 10 |         INDEX UNIQUE SCAN               | EFI_REFELEM             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 11 |     FILTER                              |                         |     25M|        |            |      0 |00:00:03.73 |       0 |      0 |
|  12 |      FAST DUAL                          |                         |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
---------------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   1 - filter( IS NOT NULL)
   2 - filter("DF_ANN" IS NULL)
   6 - filter(((:B1='FUBD' OR :B2='FUBL' OR :B3='FUBO' OR :B4='FUBS') AND NVL(:B1,'x')='x'))
   7 - filter("REFAGGR"=:B1)
   8 - access("REFFACTURE"=)
   9 - filter(NVL("NON_PERFORM_STAT",'N')='O')
  10 - access("REFELEM"=:B2)
  11 - filter((:B1='CDPR' AND :B1='CDPR' AND :B2=:B2))


*/
/********************************OLD Metrics***************************************/

/********************************New SQL*******************************************/

SELECT DF_NUM, 
       DF_REFINIT, 
       DF_NOM, 
       DF_DOS, 
       DF_CLI, 
       DF_DEB
  FROM F_DETFAC,
       ( SELECT REFAGGR REFER
           FROM G_ELEMFI_AGGR
          WHERE REFFACTURE = ( SELECT REFPIECE2
                                 FROM G_ELEMFI
                                WHERE REFELEM = :B2
                                  AND NVL( NON_PERFORM_STAT, 'N' ) = 'O' )
            
            AND NVL(:B1, 'x') = 'x' ) GE
 WHERE DF_REFINIT = GE.REFER
   AND DF_NOM IN ('FUBL', 'FUBO', 'FUBS', 'FUBD')
   AND DF_ANN IS NULL
UNION
SELECT DF_NUM, 
       DF_REFINIT, 
       DF_NOM, 
       DF_DOS, 
       DF_CLI, 
       DF_DEB
  FROM F_DETFAC
 WHERE DF_REFINIT = :B2
   AND DF_NOM = 'CDPR'
   AND :B1 = 'CDPR'
   AND DF_ANN IS NULL
 ORDER BY DF_NUM; 
/********************************New SQL*******************************************/
/********************************New Metrics***************************************/
/*
Plan hash value: 2527580749
--------------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                              | Name                    | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  |
--------------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                       |                         |      1 |        |     5 (100)|      0 |00:00:00.01 |       3 |      1 |
|   1 |  SORT UNIQUE                           |                         |      1 |      2 |     4   (0)|      0 |00:00:00.01 |       3 |      1 |
|   2 |   UNION-ALL                            |                         |      1 |        |            |      0 |00:00:00.01 |       3 |      1 |
|*  3 |    FILTER                              |                         |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
|   4 |     NESTED LOOPS                       |                         |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|   5 |      NESTED LOOPS                      |                         |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*  6 |       INDEX RANGE SCAN                 | AK_KEY_2_G_ELEMFI       |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*  7 |        TABLE ACCESS BY INDEX ROWID     | G_ELEMFI                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*  8 |         INDEX UNIQUE SCAN              | EFI_REFELEM             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*  9 |       INDEX RANGE SCAN                 | F_DETFAC_DF_REFINIT_IDX |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 10 |      TABLE ACCESS BY INDEX ROWID       | F_DETFAC                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 11 |    FILTER                              |                         |      1 |        |            |      0 |00:00:00.01 |       3 |      1 |
|* 12 |     TABLE ACCESS BY INDEX ROWID BATCHED| F_DETFAC                |      1 |      1 |     1   (0)|      0 |00:00:00.01 |       3 |      1 |
|* 13 |      INDEX RANGE SCAN                  | F_DETFAC_DF_REFINIT_IDX |      1 |      1 |     1   (0)|      0 |00:00:00.01 |       3 |      1 |
--------------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   3 - filter(NVL(:B1,'x')='x')
   6 - access("REFFACTURE"=)
   7 - filter(NVL("NON_PERFORM_STAT",'N')='O')
   8 - access("REFELEM"=:B2)
   9 - access("DF_REFINIT"="REFAGGR")
       filter(("DF_NOM"='FUBD' OR "DF_NOM"='FUBL' OR "DF_NOM"='FUBO' OR "DF_NOM"='FUBS'))
  10 - filter("DF_ANN" IS NULL)
  11 - filter(:B1='CDPR')
  12 - filter("DF_ANN" IS NULL)
  13 - access("DF_REFINIT"=:B2 AND "DF_NOM"='CDPR')
*/
/********************************New Metrics***************************************/

/********************************Index statistics**********************************/

/********************************Other SQLs****************************************/          
/*

*/ 
/********************************Other SQLs****************************************/              
