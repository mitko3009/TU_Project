/********************************************************************************
*********       E-mail subject: BANKINTDEV-5511
*********             Instance: DLV
*********          Description: 
Problem:
SQL from DLV instance was provided as slow.

Analysis:
We executed the provided SQL in DLV but we were unable to reproduce the problem, but we found that in the second UNION table t_intervenants TI_DECOMPTE 
is not joined to the other tables which leads to a full scan. Also, function ftr_util.SoldeF() is not called everywhere as it is written in the model.
The call of function ftr_util.SoldeF() should be changed as it is in the first UNION for example: DECODE(GP_FACT.DT10, NULL, GP_FACT.MT09, FTR_UTIL.SOLDEF(GE.REFELEM)).

Suggestion:
1. Please join table t_intervenants TI_DECOMPTE with the other tables in the second UNION.
2. Please change the query to call ftr_util.SoldeF() as it is written in the model and as 
it is made in the first UNION for example: DECODE(GP_FACT.DT10, NULL, GP_FACT.MT09, FTR_UTIL.SOLDEF(GE.REFELEM))

*********               SQL_ID: 5xt7n77zu700w
*********      Program/Package: 
*********              Request: Dimitare Ivanov
*********               Author: Dimitar Dimitrov
********* Received e-mail date: 11/03/2024
*********      Resolution date: 11/03/2024
*********  Trace old file here: \\epox\specifs\performance\tmp\
*********  Trace new file here:
***********************************************************************************/

/********************************OLD SQL*******************************************/
var B1 VARCHAR2(32);
exec :B1 := 'EUR';
var B2 VARCHAR2(128);
exec :B2 := '01280988970790000444';
var B3 NUMBER;
exec :B3 := 2001;
var B4 NUMBER;
exec :B4 := 1;

SELECT *
  FROM (SELECT /*+ first_rows(2001)*/
         foo.*, ROWNUM rnum
          FROM (SELECT V_FACT.elemType             elemType,
                       V_FACT.docRef               docRef,
                       V_FACT.docNumber            docNumber,
                       V_FACT.dateOfEntry          dateOfEntry,
                       V_FACT.actBalanceFi         actBalanceFi,
                       V_FACT.purchAmtMvtCurr      purchAmtMvtCurr,
                       V_FACT.docDate              docDate,
                       V_FACT.dueDate              dueDate,
                       V_FACT.extensionDate        extensionDate,
                       V_FACT.pmtDate              pmtDate,
                       V_FACT.currency             currency,
                       V_FACT.totalAmount          totalAmount,
                       V_FACT.accAmount            accAmount,
                       V_FACT.currencyCase         currencyCase,
                       V_FACT.statementCurr        statementCurr,
                       V_FACT.payment              payment,
                       V_FACT.docStatus            docStatus,
                       V_FACT.rcvdReinsuranceIndem rcvdReinsuranceIndem,
                       V_FACT.prorogInterests      prorogInterests,
                       V_FACT.coveredAmt           coveredAmt,
                       V_FACT.defPeriodStart       defPeriodStart,
                       V_FACT.initAmount           initAmount,
                       V_FACT.factAssignFormNum    factAssignFormNum,
                       V_FACT.comments             comments,
                       V_FACT.onHold               onHold,
                       V_FACT.elementRef           elementRef,
                       V_FACT.caseRef              caseRef,
                       V_FACT.debtorRef            debtorRef,
                       V_FACT.debtorName           debtorName,
                       V_FACT.debtorCountry        debtorCountry,
                       V_FACT.contractNum          contractNum,
                       V_FACT.clientRef            clientRef,
                       V_FACT.clientName           clientName,
                       V_FACT.cessAssignFormNum    cessAssignFormNum,
                       V_FACT.clientAssignFormNum  clientAssignFormNum,
                       V_FACT.statementCaseRef     statementCaseRef,
                       V_FACT.isFinanced           isFinanced,
                       V_FACT.isVouchersChecked    isVouchersChecked,
                       V_FACT.totalNetPortfolio    totalNetPortfolio,
                       V_FACT.dtNextClStmt         dtNextClStmt,
                       V_FACT.flagCtx              flagCtx,
                       V_FACT.lpiInterests         lpiInterests,
                       V_FACT.globalizedDuplicate  globalizedDuplicate,
                       V_FACT.covAmtBeforeRate     covAmtBeforeRate,
                       V_FACT.fundAmtBeforeRate    fundAmtBeforeRate,
                       V_FACT.fundAmt              fundAmt,
                       V_FACT.financingBase        financingBase,
                       V_FACT.extPmtDate           extPmtDate,
                       V_FACT.anticipateDateOfFund anticipateDateOfFund,
                       V_FACT.letterOfdiscont      letterOfdiscont,
                       V_FACT.chngLetterOfdiscont  chngLetterOfdiscont,
                       V_FACT.inclReqCertCopy      inclReqCertCopy,
                       V_FACT.chngReqCertCopy      chngReqCertCopy,
                       V_FACT.procCaseRef          procCaseRef,
                       V_FACT.guarantieStatus      guarantieStatus,
                       V_FACT.clientNum            clientNum,
                       V_FACT.debtTransferStatus   debtTransferStatus,
                       V_FACT.cr                   cr,
                       V_FACT.typeDisplay          typeDisplay,
                       V_FACT.notReconcilFlag      notReconcilFlag,
                       V_FACT.pmtMethod            pmtMethod,
                       V_FACT.notifDate            notifDate,
                       V_FACT.covNotFundMvtCurr    covNotFundMvtCurr,
                       V_FACT.notCovNotFundMvt     notCovNotFundMvt,
                       V_FACT.contractCaseRef      contractCaseRef,
                       V_FACT.contractExtRef       contractExtRef,
                       V_FACT.contractType         contractType,
                       V_FACT.debtorCaseRef        debtorCaseRef,
                       V_FACT.debtorFactorRef      debtorFactorRef,
                       V_FACT.matchedAmount        matchedAmount,
                       V_FACT.debitAccountBIC      debitAccountBIC,
                       V_FACT.revInvInDefault      revInvInDefault,
                       V_FACT.fundingDate          fundingDate,
                       V_FACT.debitAccountIBAN     debitAccountIBAN,
                       V_FACT.accNumber            accNumber,
                       V_FACT.cifClient            cifClient,
                       V_FACT.elementOpen          elementOpen,
                       V_FACT.retrocessionReason   retrocessionReason
                  FROM (SELECT GE.TYPE ELEMTYPE,
                               GE.REFEXT DOCNUMBER,
                               GP_FACT.REFPIECE docRef,
                               TRUNC(GE.DTJOUR_DT) DATEOFENTRY,
                               GP_FACT.MT09 ACTBALANCEFI,
                               GP_FACT.MT48 PURCHAMTMVTCURR,
                               TRUNC(GE.DT_EMIS_DT) DOCDATE,
                               TRUNC(GE.DTDEBUT_DT) DUEDATE,
                               (SELECT MAX(DT01_DT)
                                  FROM G_PIECEDET
                                 WHERE REFPIECE = GP_FACT.REFPIECE
                                   AND TYPE = 'PROROGATION') EXTENSIONDATE,
                               TO_DATE(FTR_MATCH.DTDERNPMTSURDETTE(GE.REFELEM,
                                                                   'fi',
                                                                   NULL,
                                                                   GP_FACT.REFDOSS),
                                       'j') PMTDATE,
                               GE.DEVISE_MVT CURRENCY,
                               GE.MONTANT_MVT TOTALAMOUNT,
                               GE.MONTANT ACCAMOUNT,
                               GE.DEVISE_DOS CURRENCYCASE,
                               GD_DECOMPTE.DEVISE STATEMENTCURR,
                               DECODE(GP_FACT.DT10,
                                      NULL,
                                      GP_FACT.MT09,
                                      FTR_UTIL.SOLDEF(GE.REFELEM)) PAYMENT,
                               GP_FACT.ST09 DOCSTATUS,
                               GP_FACT.FG27 RCVDREINSURANCEINDEM,
                               GP_FACT.MT05 PROROGINTERESTS,
                               GP_FACT.MT01 COVEREDAMT,
                               GP_FACT.NB01 DEFPERIODSTART,
                               GE.MONTANT_DOS INITAMOUNT,
                               GP_FACT.GPIDEPOT FACTASSIGNFORMNUM,
                               GP_FACT.COMMENTAIRE COMMENTS,
                               GP_FACT.FG09 ONHOLD,
                               GE.REFELEM ELEMENTREF,
                               GP_FACT.REFDOSS CASEREF,
                               TI_COMPTE.REFINDIVIDU DEBTORREF,
                               TI_COMPTE.NOM DEBTORNAME,
                               G_INDIV.PAYS DEBTORCOUNTRY,
                               GP_CESS.ST04 CONTRACTNUM,
                               TI_DECOMPTE.REFINDIVIDU CLIENTREF,
                               TI_DECOMPTE.NOM CLIENTNAME,
                               GP_CESS.GPIDEPOT CESSASSIGNFORMNUM,
                               GP_CESS.GPIROLE CLIENTASSIGNFORMNUM,
                               GD_DECOMPTE.REFDOSS STATEMENTCASEREF,
                               GP_FACT.FG01 ISFINANCED,
                               GP_FACT.FG02 ISVOUCHERSCHECKED,
                               GD_COMPTE.SOLDEDB TOTALNETPORTFOLIO,
                               GD_DECOMPTE.DT10_DT DTNEXTCLSTMT,
                               GE.FLAG_CTX FLAGCTX,
                               GP_FACT.MT06 LPIINTERESTS,
                               GP_FACT.FG62 GLOBALIZEDDUPLICATE,
                               GP_FACT.MT50 COVAMTBEFORERATE,
                               GP_FACT.MT51 FUNDAMTBEFORERATE,
                               GP_FACT.MT14 FUNDAMT,
                               GP_FACT.MT02 FINANCINGBASE,
                               GP_FACT.DT14_DT EXTPMTDATE,
                               PI.DT_ANTICIP_DT_FUND ANTICIPATEDATEOFFUND,
                               PI.INCL_LETTER_OF_DISC LETTEROFDISCONT,
                               PI.CHNG_LETTER_DISC_DT CHNGLETTEROFDISCONT,
                               PI.INCL_REQ_CERT_COPY INCLREQCERTCOPY,
                               PI.CHNG_REQ_CERT_COPY CHNGREQCERTCOPY,
                               GE.REFDOSS_MARCHE PROCCASEREF,
                               PI.GUARANT_STATUS GUARANTIESTATUS,
                               PI.CLIENT_NUM CLIENTNUM,
                               PI.ST_DEBT_TRANSFER DEBTTRANSFERSTATUS,
                               PI.FG_CR CR,
                               NVL(VE.abrev_AN, VE.abrev) AS typeDisplay,
                               0 NOTRECONCILFLAG,
                               GP_FACT.STR_5_1 PMTMETHOD,
                               GP_FACT.DT17_DT NOTIFDATE,
                               GP_FACT.MT63 COVNOTFUNDMVTCURR,
                               GP_FACT.MT65 NOTCOVNOTFUNDMVT,
                               GD_DECOMPTE.REFLOT CONTRACTCASEREF,
                               (SELECT ancrefdoss
                                  FROM g_dossier
                                 WHERE refdoss IN
                                       (SELECT refhierarchie
                                          FROM g_dossier
                                         WHERE refdoss = GD_DECOMPTE.REFLOT)) CONTRACTEXTREF,
                               (SELECT categdoss
                                  FROM g_dossier
                                 WHERE refdoss = GD_DECOMPTE.REFLOT) CONTRACTTYPE,
                               GD_COMPTE.REFDOSS DEBTORCASEREF,
                               GD_COMPTE.REFFACTOR DEBTORFACTORREF,
                               DECODE('EUR',
                                      GD_COMPTE.DEVISE,
                                      DECODE(GP_FACT.DT10,
                                             NULL,
                                             GP_FACT.MT09,
                                             FTR_UTIL.SOLDEF(GE.REFELEM)),
                                      GD_DECOMPTE.DEVISE,
                                      DECODE(GP_FACT.DT10,
                                             NULL,
                                             GP_FACT.MT24,
                                             FTR_UTIL.SOLDEF_DCPT(GE.REFELEM)),
                                      CH_TAUX.CONV_ORIG_DEST_TX(TO_CHAR(SYSDATE,
                                                                        'j'),
                                                                NVL(DECODE(GP_FACT.DT10,
                                                                           NULL,
                                                                           GP_FACT.MT09,
                                                                           FTR_UTIL.SOLDEF(GE.REFELEM)),
                                                                    0),
                                                                GD_COMPTE.DEVISE,
                                                                'EUR',
                                                                'MER',
                                                                FTR_FIN_FACTOR.GETCURRENCY(GD_COMPTE.REFFACTOR),
                                                                FTR_FIN_FACTOR.GETPAYS(GD_COMPTE.REFFACTOR))) MATCHEDAMOUNT,
                               GP_FACT.ST38 DEBITACCOUNTBIC,
                               GP_FACT.ST35 DEBITACCOUNTIBAN,
                               GP_FACT.ST42 ACCNUMBER,
                               GP_FACT.ST20 RETROCESSIONREASON,
                               PI.FG_REV_INV_DEF REVINVINDEFAULT,
                               GP_FACT.DT15_DT FUNDINGDATE,
                               (SELECT tva
                                  FROM g_individu
                                 WHERE refindividu = TI_DECOMPTE.REFINDIVIDU) CIFCLIENT,
                               GE.ACTIF ELEMENTOPEN
                          FROM g_piece        GP_FACT,
                               g_elemfi       GE,
                               g_db_ptf_item  PI,
                               g_dossier      GD_COMPTE,
                               g_dossier      GD_DECOMPTE,
                               g_piece        GP_CESS,
                               t_intervenants TI_COMPTE,
                               t_intervenants TI_DECOMPTE,
                               g_individu     G_INDIV,
                               v_elemfi       VE
                         WHERE 1 = 1
                           AND GP_FACT.typpiece = 'FACTURE'
                           AND GP_FACT.gpiheure = GE.refelem
                           AND GE.refelem = PI.refelem
                           AND GE.dttraite_dt IS NULL
                           AND GE.dtannul_dt IS NULL
                           AND GE.refdoss = GD_COMPTE.refdoss
                           AND GD_COMPTE.categdoss LIKE 'COMPTE%'
                           AND GE.type = VE.type(+)
                           AND NVL(VE.fg_parent_invoice, 'N') <> 'O'
                           AND TI_COMPTE.refindividu = G_INDIV.refindividu
                           AND GD_COMPTE.refdoss = TI_COMPTE.refdoss
                           AND VE.abrev IN ('FA', 'CN')
                           AND TI_COMPTE.reftype = 'DB'
                           AND GD_COMPTE.reflot = GD_DECOMPTE.refdoss
                           AND GD_DECOMPTE.categdoss LIKE 'DECOMPTE%'
                           AND GP_FACT.gpidepot = GP_CESS.refpiece(+)
                           AND GP_CESS.typpiece(+) = 'CESSION'
                           AND GD_DECOMPTE.refdoss = TI_DECOMPTE.refdoss
                           AND TI_DECOMPTE.reftype =
                               DECODE(GD_DECOMPTE.categdoss,
                                      'DECOMPTE IMP',
                                      'TC',
                                      'CL')
                        UNION ALL
                        SELECT *
                          FROM (SELECT /*+ index(GE (refdoss,type))*/
                                 GE.type AS elemType,
                                 GE.refext AS docNumber,
                                 NULL AS docRef,
                                 GE.dtjour_dt AS dateOfEntry,
                                 NULL AS actBalanceFi,
                                 NULL AS purchAmtMvtCurr,
                                 GE.dt_emis_dt AS docDate,
                                 GE.dtdebut_dt AS dueDate,
                                 NULL AS extensionDate,
                                 NULL AS pmtDate,
                                 GE.devise_mvt AS currency,
                                 GE.montant_mvt AS totalAmount,
                                 GE.montant AS accAmount,
                                 GE.devise_dos AS currencyCase,
                                 GD_DECOMPTE.DEVISE AS statementCurr,
                                 ftr_util.SoldeF(GE.refelem) AS payment,
                                 NULL AS docStatus,
                                 NULL AS rcvdReinsuranceIndem,
                                 NULL AS prorogInterests,
                                 NULL AS coveredAmt,
                                 NULL AS defPeriodStart,
                                 GE.montant_dos AS initAmount,
                                 NULL AS factAssignFormNum,
                                 NULL AS comments,
                                 NULL AS onHold,
                                 GE.refelem AS elementRef,
                                 GE.refdoss AS caseRef,
                                 TI_COMPTE.refindividu AS debtorRef,
                                 TI_COMPTE.nom AS debtorName,
                                 G_INDIV.pays AS debtorCountry,
                                 NULL AS contractNum,
                                 TI_DECOMPTE.refindividu AS clientRef,
                                 TI_DECOMPTE.nom AS clientName,
                                 NULL AS cessAssignFormNum,
                                 NULL AS clientAssignFormNum,
                                 GD_DECOMPTE.refdoss AS statementCaseRef,
                                 NULL AS isFinanced,
                                 NULL AS isVouchersChecked,
                                 GD_COMPTE.soldedb AS totalNetPortfolio,
                                 GD_DECOMPTE.dt10_dt AS dtNextClStmt,
                                 GE.flag_ctx AS flagCtx,
                                 NULL AS lpiInterests,
                                 NULL AS globalizedDuplicate,
                                 NULL AS covAmtBeforeRate,
                                 NULL AS fundAmtBeforeRate,
                                 NULL AS fundAmt,
                                 NULL AS financingBase,
                                 NULL AS extPmtDate,
                                 NULL AS anticipateDateOfFund,
                                 NULL AS letterOfdiscont,
                                 NULL AS chngLetterOfdiscont,
                                 NULL AS inclReqCertCopy,
                                 NULL AS chngReqCertCopy,
                                 GE.refdoss_marche AS procCaseRef,
                                 NULL AS guarantieStatus,
                                 NULL AS clientNum,
                                 NULL AS debtTransferStatus,
                                 NULL AS cr,
                                 NVL(VE.abrev_AN, VE.abrev) AS typeDisplay,
                                 0 AS notReconcilFlag,
                                 NULL AS pmtMethod,
                                 NULL AS notifDate,
                                 NULL AS covNotFundMvtCurr,
                                 NULL AS notCovNotFundMvt,
                                 GD_DECOMPTE.reflot AS caseRefContract,
                                 (SELECT ancrefdoss
                                    FROM g_dossier
                                   WHERE refdoss IN
                                         (SELECT refhierarchie
                                            FROM g_dossier
                                           WHERE refdoss = GD_DECOMPTE.REFLOT)) AS contractextref,
                                 (SELECT categdoss
                                    FROM g_dossier
                                   WHERE refdoss = GD_DECOMPTE.REFLOT) AS contractType,
                                 GD_COMPTE.refdoss AS debtorCaseRef,
                                 GD_COMPTE.reffactor AS debtorFactorRef,
                                 DECODE(:B1,
                                        GD_COMPTE.devise,
                                        ftr_util.SoldeF(GE.refelem),
                                        GD_DECOMPTE.devise,
                                        ftr_util.SoldeF_DCPT(GE.refelem),
                                        Ch_Taux.Conv_Orig_Dest_Tx(TO_CHAR(SYSDATE,
                                                                          'j'),
                                                                  NVL('l_solde_DOS',
                                                                      0),
                                                                  GD_COMPTE.devise,
                                                                  NVL(:B1, 'EUR'),
                                                                  'MER',
                                                                  ftr_fin_factor.getCurrency(GD_COMPTE.reffactor),
                                                                  ftr_fin_factor.getPays(GD_COMPTE.reffactor))) AS matchedAmount,
                                 NULL AS DEBITACCOUNTBIC,
                                 NULL AS DEBITACCOUNTIBAN,
                                 NULL AS ACCNUMBER,
                                 NULL AS RETROCESSIONREASON,
                                 NULL AS REVINVINDEFAULT,
                                 NULL AS FUNDINGDATE,
                                 (SELECT tva
                                    FROM g_individu
                                   WHERE refindividu = TI_DECOMPTE.REFINDIVIDU) CIFCLIENT,
                                 GE.ACTIF ELEMENTOPEN
                                  FROM g_elemfi       GE,
                                       g_dossier      GD_COMPTE,
                                       g_dossier      GD_DECOMPTE,
                                       g_individu     G_INDIV,
                                       t_intervenants TI_COMPTE,
                                       t_intervenants TI_DECOMPTE,
                                       v_elemfi       VE
                                 WHERE GE.dttraite_dt IS NULL
                                   AND GE.dtannul_dt IS NULL
                                   AND GE.refdoss = GD_COMPTE.refdoss
                                   AND TI_COMPTE.refindividu = G_INDIV.refindividu
                                   AND GE.type = VE.type
                                   AND GE.type IN ('NOTE DE DEBIT',
                                                   'BULK DEDUCTION',
                                                   'FACT NON RECUE')
                                   AND DECODE(GE.type,
                                              'NOTE DE DEBIT',
                                              1,
                                              'FACT NON RECUE',
                                              1,
                                              -1) * GE.montant_mvt > 0
                                   AND GD_COMPTE.categdoss LIKE 'COMPTE%'
                                   AND GD_COMPTE.refdoss = TI_COMPTE.refdoss
                                   AND VE.abrev IN ('FA', 'CN'))) V_FACT
                 WHERE 1 = 1
                   AND V_FACT.notifDate IS NULL
                   AND V_FACT.contractCaseRef IN
                       (SELECT refdoss
                          FROM g_dossier
                         WHERE refhierarchie =
                               (SELECT refdoss
                                  FROM g_dossier
                                 WHERE ancrefdoss = :B2))
                 ORDER BY duedate ASC, clientname ASC, docRef) foo
         WHERE ROWNUM <= :B3)
 WHERE 1 = 1
   AND rnum >= :B4;
/********************************OLD SQL*******************************************/
/********************************OLD Metrics***************************************/
/*
PLAN HASH VALUE  : 2994553474
-----------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                            | Name                      | Rows  | Bytes | Cost  | Time     |
-----------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                                     |                           |       |       |  3006K|          |
|*  1 |  VIEW                                                |                           |  2001 |    13M|  3006K| 00:01:58 |
|*  2 |   COUNT STOPKEY                                      |                           |       |       |       |          |
|*  3 |    VIEW                                              |                           |  6729 |    45M|  3006K| 00:01:58 |
|   4 |     SORT ORDER BY                                    |                           |  6729 |    45M|  3006K| 00:01:58 |
|   5 |      NESTED LOOPS                                    |                           |  6729 |    45M|  2996K| 00:01:58 |
|   6 |       INDEX FULL SCAN                                | REFHIERARCHIE_IDX         |  1345 | 18830 |     1 | 00:00:01 |
|   7 |       VIEW                                           |                           |     4 | 28428 |  2228 | 00:00:01 |
|   8 |        UNION ALL PUSHED PREDICATE                    |                           |       |       |       |          |
|   9 |         NESTED LOOPS                                 |                           |     1 |    30 |     2 | 00:00:01 |
|* 10 |          TABLE ACCESS BY INDEX ROWID                 | G_DOSSIER                 |     1 |    14 |     1 | 00:00:01 |
|* 11 |           INDEX UNIQUE SCAN                          | DOS_REFDOSS               |     1 |       |     1 | 00:00:01 |
|  12 |          TABLE ACCESS BY INDEX ROWID                 | G_DOSSIER                 |     1 |    16 |     1 | 00:00:01 |
|* 13 |           INDEX UNIQUE SCAN                          | DOS_REFDOSS               |     1 |       |     1 | 00:00:01 |
|  14 |         TABLE ACCESS BY INDEX ROWID                  | G_DOSSIER                 |     1 |    20 |     1 | 00:00:01 |
|* 15 |          INDEX UNIQUE SCAN                           | DOS_REFDOSS               |     1 |       |     1 | 00:00:01 |
|  16 |         TABLE ACCESS BY INDEX ROWID                  | G_INDIVIDU                |     1 |    11 |     1 | 00:00:01 |
|* 17 |          INDEX UNIQUE SCAN                           | IND_REFINDIV              |     1 |       |     1 | 00:00:01 |
|  18 |         NESTED LOOPS                                 |                           |     1 |   574 |    11 | 00:00:01 |
|  19 |          NESTED LOOPS                                |                           |     1 |   561 |    10 | 00:00:01 |
|  20 |           NESTED LOOPS OUTER                         |                           |     1 |   469 |     9 | 00:00:01 |
|  21 |            NESTED LOOPS OUTER                        |                           |     1 |   439 |     8 | 00:00:01 |
|  22 |             NESTED LOOPS                             |                           |     1 |   428 |     7 | 00:00:01 |
|  23 |              NESTED LOOPS                            |                           |     1 |   314 |     6 | 00:00:01 |
|  24 |               NESTED LOOPS                           |                           |     1 |   285 |     5 | 00:00:01 |
|  25 |                NESTED LOOPS                          |                           |     1 |   159 |     4 | 00:00:01 |
|  26 |                 NESTED LOOPS                         |                           |     1 |   118 |     3 | 00:00:01 |
|  27 |                  NESTED LOOPS                        |                           |     1 |    75 |     2 | 00:00:01 |
|  28 |                   TABLE ACCESS BY INDEX ROWID BATCHED| G_DOSSIER                 |     1 |    34 |     1 | 00:00:01 |
|* 29 |                    INDEX RANGE SCAN                  | G_DOSSIER_RL_CD_RD_RF_IDX |     1 |       |     1 | 00:00:01 |
|  30 |                   TABLE ACCESS BY INDEX ROWID BATCHED| T_INTERVENANTS            |     1 |    41 |     1 | 00:00:01 |
|* 31 |                    INDEX RANGE SCAN                  | INT_REFDOSS               |     1 |       |     1 | 00:00:01 |
|  32 |                  TABLE ACCESS BY INDEX ROWID BATCHED | G_DOSSIER                 |     1 |    43 |     1 | 00:00:01 |
|* 33 |                   INDEX RANGE SCAN                   | G_DOSSIER_RL_CD_RD_RF_IDX |     1 |       |     1 | 00:00:01 |
|  34 |                 TABLE ACCESS BY INDEX ROWID BATCHED  | T_INTERVENANTS            |     1 |    41 |     1 | 00:00:01 |
|* 35 |                  INDEX RANGE SCAN                    | INT_REFDOSS               |     1 |       |     1 | 00:00:01 |
|* 36 |                TABLE ACCESS BY INDEX ROWID BATCHED   | G_ELEMFI                  |    36 |  4536 |     1 | 00:00:01 |
|* 37 |                 INDEX RANGE SCAN                     | GE_REFDOSS_DTANNUL_IDX    |    38 |       |     1 | 00:00:01 |
|* 38 |               TABLE ACCESS BY INDEX ROWID BATCHED    | V_ELEMFI                  |     1 |    29 |     1 | 00:00:01 |
|* 39 |                INDEX RANGE SCAN                      | AK_KEY_V_ELEMFI_TYPE      |     1 |       |     1 | 00:00:01 |
|* 40 |              TABLE ACCESS BY INDEX ROWID BATCHED     | G_PIECE                   |     1 |   114 |     1 | 00:00:01 |
|* 41 |               INDEX RANGE SCAN                       | GP_GRTYPE_MT_DT           |     1 |       |     1 | 00:00:01 |
|  42 |             VIEW PUSHED PREDICATE                    | VW_SSQ_1                  |     1 |    11 |     1 | 00:00:01 |
|  43 |              SORT GROUP BY                           |                           |     1 |    30 |     1 | 00:00:01 |
|* 44 |               INDEX RANGE SCAN                       | G_PIECEDET_REFP           |     1 |    30 |     1 | 00:00:01 |
|* 45 |            TABLE ACCESS BY INDEX ROWID BATCHED       | G_PIECE                   |     1 |    30 |     1 | 00:00:01 |
|* 46 |             INDEX RANGE SCAN                         | PIE_REFPIECE              |     1 |       |     1 | 00:00:01 |
|  47 |           TABLE ACCESS BY INDEX ROWID                | G_DB_PTF_ITEM             |     1 |    92 |     1 | 00:00:01 |
|* 48 |            INDEX UNIQUE SCAN                         | PK_G_DB_PTF_ITEM          |     1 |       |     1 | 00:00:01 |
|  49 |          TABLE ACCESS BY INDEX ROWID                 | G_INDIVIDU                |     1 |    13 |     1 | 00:00:01 |
|* 50 |           INDEX UNIQUE SCAN                          | IND_REFINDIV              |     1 |       |     1 | 00:00:01 |
|  51 |         NESTED LOOPS                                 |                           |     1 |    30 |     2 | 00:00:01 |
|* 52 |          TABLE ACCESS BY INDEX ROWID                 | G_DOSSIER                 |     1 |    14 |     1 | 00:00:01 |
|* 53 |           INDEX UNIQUE SCAN                          | DOS_REFDOSS               |     1 |       |     1 | 00:00:01 |
|  54 |          TABLE ACCESS BY INDEX ROWID                 | G_DOSSIER                 |     1 |    16 |     1 | 00:00:01 |
|* 55 |           INDEX UNIQUE SCAN                          | DOS_REFDOSS               |     1 |       |     1 | 00:00:01 |
|  56 |         TABLE ACCESS BY INDEX ROWID                  | G_DOSSIER                 |     1 |    20 |     1 | 00:00:01 |
|* 57 |          INDEX UNIQUE SCAN                           | DOS_REFDOSS               |     1 |       |     1 | 00:00:01 |
|  58 |         TABLE ACCESS BY INDEX ROWID                  | G_INDIVIDU                |     1 |    11 |     1 | 00:00:01 |
|* 59 |          INDEX UNIQUE SCAN                           | IND_REFINDIV              |     1 |       |     1 | 00:00:01 |
|  60 |         NESTED LOOPS                                 |                           |  4734 |  1326K|    29 | 00:00:01 |
|  61 |          NESTED LOOPS                                |                           |     2 |   522 |     7 | 00:00:01 |
|  62 |           NESTED LOOPS                               |                           |     2 |   472 |     6 | 00:00:01 |
|  63 |            NESTED LOOPS                              |                           |     2 |   220 |     5 | 00:00:01 |
|  64 |             NESTED LOOPS                             |                           |     2 |   194 |     4 | 00:00:01 |
|  65 |              NESTED LOOPS                            |                           |    13 |   806 |     3 | 00:00:01 |
|  66 |               TABLE ACCESS BY INDEX ROWID BATCHED    | G_DOSSIER                 |     1 |    25 |     1 | 00:00:01 |
|* 67 |                INDEX RANGE SCAN                      | DOSS_LOT                  |     1 |       |     1 | 00:00:01 |
|  68 |               TABLE ACCESS FULL                      | T_INTERVENANTS            |    12 |   444 |     2 | 00:00:01 |
|* 69 |              TABLE ACCESS BY INDEX ROWID             | G_DOSSIER                 |     1 |    35 |     1 | 00:00:01 |
|* 70 |               INDEX UNIQUE SCAN                      | DOS_REFDOSS               |     1 |       |     1 | 00:00:01 |
|  71 |             TABLE ACCESS BY INDEX ROWID              | G_INDIVIDU                |     1 |    13 |     1 | 00:00:01 |
|* 72 |              INDEX UNIQUE SCAN                       | IND_REFINDIV              |     1 |       |     1 | 00:00:01 |
|* 73 |            TABLE ACCESS BY INDEX ROWID BATCHED       | G_ELEMFI                  |     1 |   126 |     1 | 00:00:01 |
|* 74 |             INDEX RANGE SCAN                         | G_ELEMFI_DOS_TYP_FG02     |    14 |       |     1 | 00:00:01 |
|* 75 |           TABLE ACCESS BY INDEX ROWID BATCHED        | V_ELEMFI                  |     1 |    25 |     1 | 00:00:01 |
|* 76 |            INDEX RANGE SCAN                          | AK_KEY_V_ELEMFI_TYPE      |     1 |       |     1 | 00:00:01 |
|  77 |          TABLE ACCESS FULL                           | T_INTERVENANTS            |  2002 | 52052 |    11 | 00:00:01 |
|  78 |     TABLE ACCESS BY INDEX ROWID BATCHED              | G_DOSSIER                 |     1 |    16 |     1 | 00:00:01 |
|* 79 |      INDEX RANGE SCAN                                | DOS_ANCREFDOSS            |     1 |       |     1 | 00:00:01 |
-----------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
1 - filter("RNUM">=:5)
2 - filter(ROWNUM<=:4)
3 - filter("REFHIERARCHIE"=)
10 - filter("REFHIERARCHIE" IS NOT NULL)
11 - access("REFDOSS"=:B1)
13 - access("REFDOSS"="REFHIERARCHIE")
15 - access("REFDOSS"=:B1)
17 - access("REFINDIVIDU"=:B1)
29 - access("GD_DECOMPTE"."REFLOT"="REFDOSS" AND "GD_DECOMPTE"."CATEGDOSS" LIKE 'DECOMPTE%')
filter("GD_DECOMPTE"."CATEGDOSS" LIKE 'DECOMPTE%')
31 - access("GD_DECOMPTE"."REFDOSS"="TI_DECOMPTE"."REFDOSS" AND
"TI_DECOMPTE"."REFTYPE"=DECODE("GD_DECOMPTE"."CATEGDOSS",'DECOMPTE IMP','TC','CL'))
33 - access("GD_COMPTE"."REFLOT"="GD_DECOMPTE"."REFDOSS" AND "GD_COMPTE"."CATEGDOSS" LIKE 'COMPTE%')
filter(("GD_COMPTE"."REFLOT" IS NOT NULL AND "GD_COMPTE"."CATEGDOSS" LIKE 'COMPTE%'))
35 - access("GD_COMPTE"."REFDOSS"="TI_COMPTE"."REFDOSS" AND "TI_COMPTE"."REFTYPE"='DB')
36 - filter("GE"."DTTRAITE_DT" IS NULL)
37 - access("GE"."REFDOSS"="GD_COMPTE"."REFDOSS" AND "GE"."DTANNUL_DT" IS NULL)
38 - filter((INTERNAL_FUNCTION("VE"."ABREV") AND NVL("VE"."FG_PARENT_INVOICE",'N')<>'O'))
39 - access("GE"."TYPE"="VE"."TYPE")
40 - filter("GP_FACT"."DT17_DT" IS NULL)
41 - access("GP_FACT"."TYPPIECE"='FACTURE' AND "GP_FACT"."GPIHEURE"="GE"."REFELEM")
filter("GP_FACT"."GPIHEURE" IS NOT NULL)
44 - access("REFPIECE"="GP_FACT"."REFPIECE" AND "TYPE"='PROROGATION')
45 - filter("GP_CESS"."TYPPIECE"='CESSION')
46 - access("GP_FACT"."GPIDEPOT"="GP_CESS"."REFPIECE")
48 - access("GE"."REFELEM"="PI"."REFELEM")
50 - access("TI_COMPTE"."REFINDIVIDU"="G_INDIV"."REFINDIVIDU")
52 - filter("REFHIERARCHIE" IS NOT NULL)
53 - access("REFDOSS"=:B1)
55 - access("REFDOSS"="REFHIERARCHIE")
57 - access("REFDOSS"=:B1)
59 - access("REFINDIVIDU"=:B1)
67 - access("GD_DECOMPTE"."REFLOT"="REFDOSS")
69 - filter("GD_COMPTE"."CATEGDOSS" LIKE 'COMPTE%')
70 - access("GD_COMPTE"."REFDOSS"="TI_COMPTE"."REFDOSS")
72 - access("TI_COMPTE"."REFINDIVIDU"="G_INDIV"."REFINDIVIDU")
73 - filter((DECODE("GE"."TYPE",'NOTE DE DEBIT',1,'FACT NON RECUE',1,(-1))*"GE"."MONTANT_MVT">0 AND
"GE"."DTTRAITE_DT" IS NULL AND "GE"."DTANNUL_DT" IS NULL))
74 - access("GE"."REFDOSS"="GD_COMPTE"."REFDOSS")
filter(("GE"."TYPE"='BULK DEDUCTION' OR "GE"."TYPE"='FACT NON RECUE' OR "GE"."TYPE"='NOTE DE DEBIT'))
75 - filter(("VE"."ABREV"='CN' OR "VE"."ABREV"='FA'))
76 - access("GE"."TYPE"="VE"."TYPE")
filter(("VE"."TYPE"='BULK DEDUCTION' OR "VE"."TYPE"='FACT NON RECUE' OR "VE"."TYPE"='NOTE DE DEBIT'))
79 - access("ANCREFDOSS"=:3)
*/
/********************************OLD Metrics***************************************/

/********************************New SQL*******************************************/

;
/********************************New SQL*******************************************/
/********************************New Metrics***************************************/
/*

*/
/********************************New Metrics***************************************/

/********************************Index statistics**********************************/

/********************************Other SQLs****************************************/          
/*

*/ 
/********************************Other SQLs****************************************/              
