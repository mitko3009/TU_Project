/********************************************************************************
*********       E-mail subject: KBCCFWEB-2045
*********             Instance: PROD
*********          Description: 
Problem:
There was a problem with query in ui_e_cptdv.get_cts_list function.

Analysis:
The problematic SQL was 4m1jfbmqwg6ut. When we execute the sql with :B2 = NULL and after that we replace the NULL with 
a specific value for example :B2 = 'O0A5P32X' and don't change the text of the query Oracle doesn't recognize that :B2 is not NULL and use the same execution plan. 
In that case Oracle use T_ECRDOS_REFJOUR_IDX index which leads to performance problem when :B2 is not null.

Suggestion:
Please add hints as it is shown in the New SQL section below.

*********               SQL_ID: 4m1jfbmqwg6ut
*********      Program/Package: 
*********              Request: Dimitare Ivanov
*********               Author: Dimitar Dimitrov
********* Received e-mail date: 11/10/2023
*********      Resolution date: 11/10/2023
*********  Trace old file here: \\epox\specifs\performance\tmp\
*********  Trace new file here:
***********************************************************************************/

/********************************OLD SQL*******************************************/
var B1 VARCHAR2(128);
exec :B1 := '2212160380';
var B2 VARCHAR2(128);
--exec :B2 := 'O0A5P32X';
exec :B2 := '';
var B3 VARCHAR2(128);
exec :B3 := '';
var B4 VARCHAR2(128);
exec :B4 := '';
var B5 VARCHAR2(128);
exec :B5 := '';
var B6 VARCHAR2(128);
exec :B6 := '';
var B7 VARCHAR2(128);
exec :B7 := '';
var B8 VARCHAR2(128);
exec :B8 := '';
var B9 VARCHAR2(128);
exec :B9 := '';
var B10 VARCHAR2(128);
exec :B10 := '';
var B11 VARCHAR2(128);
exec :B11 := '';
var B12 VARCHAR2(128);
exec :B12 := 'AN';

SELECT  ELEMCTX,
       TYPETRAD,
       DTCPTMVT,
       DTGESTMVT,
       CODEMVT,
       REFMVT,
       TYPMVT,
       REFECRIT,
       MNTTOTAL,
       MNTCTX,
       COMPTEUR,
       MNTSOLDEDB,
       MNTIMMINENTFACT,
       MNTIMMINENTCL,
       MNTCAPITCVTFACT,
       MNTCAPITCVTCL,
       MNTCOURTCOSTSFACT,
       MNTCOURTCOSTSCL,
       MNTLAWYERCOSTSFACT,
       MNTLAWYERCOSTSCL,
       MNTNONAFF,
       AVAILFORALLOC,
       MNTINDARESEV,
       MNTINDREVERS,
       MNTREMBCHEZCI,
       MNTDISPO,
       0                  PROFIT_CL,
       0                  PROFIT_FACTOR,
       FLAGCVT,
       REFDOSS
  FROM (SELECT STR1 ELEMCTX,
               'REP' AS TYPETRAD,
               DT02_DT DTCPTMVT,
               DT01_DT DTGESTMVT,
               'REP' CODEMVT,
               REFELEM REFMVT,
               'r' TYPMVT,
               STR10 REFECRIT,
               MT01 MNTTOTAL,
               MT02 MNTCTX,
               'REPRISE' COMPTEUR,
               DECODE(STR1,
                      'REPRISE FRAIS REPETIBLES',
                      MT02,
                      'REPRISE FRAIS DIVERS DB',
                      MT02,
                      0) MNTSOLDEDB,
               0 MNTIMMINENTFACT,
               0 MNTIMMINENTCL,
               0 MNTCAPITCVTFACT,
               0 MNTCAPITCVTCL,
               MT03 MNTCOURTCOSTSFACT,
               MT04 MNTCOURTCOSTSCL,
               MT05 MNTLAWYERCOSTSFACT,
               MT06 MNTLAWYERCOSTSCL,
               0 MNTNONAFF,
               0 AVAILFORALLOC,
               MT07 MNTINDARESEV,
               MT08 MNTINDREVERS,
               0 MNTREMBCHEZCI,
               MT09 MNTDISPO,
               1 FLAGCVT,
               REFDOSS
          FROM G_ELEMFIDET
         WHERE REFDOSS = :B1
           AND TYPE = 'MVT_REPRISE'
        UNION ALL
        SELECT T.LIBELLE || E.STR1 || ' ' || F.REFEXT ELEMCTX,
               T.CODECR AS TYPETRAD,
               T.DTJOUR_DT DTCPTMVT,
               T.DATECR_DT DTGESTMVT,
               T.CODECR CODEMVT,
               T.REFELEM REFMVT,
               T.TYPELEM TYPMVT,
               NVL(T.REFJOUR, ' ') REFECRIT,
               T.DBDU_DOS MNTTOTAL,
               DECODE(T.CODECR,
                      'PRIN0',
                      E.MT10,
                      E.MT01 + E.MT02 + E.MT03 + E.MT04) MNTCTX,
               'PRINCIPAL' COMPTEUR,
               DECODE(T.CODECR,
                      'PRIN0',
                      E.MT10,
                      E.MT01 + E.MT02 + E.MT03 + E.MT04) MNTSOLDEDB,
               E.MT01 MNTIMMINENTFACT,
               E.MT02 MNTIMMINENTCL,
               E.MT03 MNTCAPITCVTFACT,
               E.MT04 MNTCAPITCVTCL,
               0 MNTCOURTCOSTSFACT,
               0 MNTCOURTCOSTSCL,
               0 MNTLAWYERCOSTSFACT,
               0 MNTLAWYERCOSTSCL,
               0 MNTNONAFF,
               0 AVAILFORALLOC,
               E.MT06 MNTINDARESEV,
               0 MNTINDREVERS,
               0 MNTREMBCHEZCI,
               0 MNTDISPO,
               1 FLAGCVT,
               E.REFDOSS REFDOSS
          FROM G_ELEMFIDET E, T_ECRDOS T, G_ELEMFI F
         WHERE T.CODECR IN ('PRIN', 'DPDB', 'PRIN0', 'DPRIN')
           AND T.REFDOSS = E.REFDOSS
           AND T.REFELEM = E.REFELEM
           AND F.REFELEM = E.REFELEM
           AND E.REFDOSS = :B1
           AND E.TYPE = 'PASS_FACT_CTX'
        UNION ALL
        SELECT MAX(E.STR1) ELEMCTX,
               'NMP' AS TYPETRAD,
               MAX(E.DT02_DT) DTCPTMVT,
               MAX(E.DT01_DT) DTGESTMVT,
               'NMP' CODEMVT,
               MAX(E.REFELEM) REFMVT,
               'e' TYPMVT,
               MAX(E.STR10) REFECRIT,
               MAX(E.MT01) MNTTOTAL,
               MAX(E.MT02) MNTCTX,
               'ACOMPT' COMPTEUR,
               -MAX(E.MT02) MNTSOLDEDB,
               NVL(SUM(T.PLDP9_DOS), 0) MNTIMMINENTFACT,
               NVL(SUM(T.PLDP12_DOS), 0) MNTIMMINENTCL,
               NVL(SUM(T.DBDU_DOS), 0) MNTCAPITCVTFACT,
               NVL(SUM(T.DBDEDUC_DOS), 0) MNTCAPITCVTCL,
               NVL(SUM(T.ETDBRSREM_DOS), 0) MNTCOURTCOSTSFACT,
               NVL(SUM(T.ETDEBRSDU_DOS), 0) MNTCOURTCOSTSCL,
               NVL(SUM(T.CLDU_DOS), 0) MNTLAWYERCOSTSFACT,
               NVL(SUM(T.CLRETRAIT_DOS), 0) MNTLAWYERCOSTSCL,
               MAX(E.MT02) + NVL(SUM(T.PLDP9_DOS), 0) +
               NVL(SUM(T.PLDP12_DOS), 0) +
               NVL(SUM(T.CLDEPOT_DOS + T.DBDEDUC_DOS), 0) MNTNONAFF,
               0 AVAILFORALLOC,
               0 MNTINDARESEV,
               0 MNTINDREVERS,
               0 MNTREMBCHEZCI,
               MAX(E.MT02) MNTDISPO,
               1 FLAGCVT,
               E.REFDOSS REFDOSS
          FROM G_ELEMFIDET E, T_ECRDOS T
         WHERE T.CODECR(+) = 'RCTX'
           AND T.REFDOSS(+) = E.REFDOSS
           AND T.REFELEM(+) = E.REFELEM
           AND E.REFDOSS = :B1
           AND E.TYPE = 'PASS_NMP_CTX'
         GROUP BY E.REFELEM, E.REFDOSS
        UNION ALL
        SELECT E.STR1 || ': ' || F.TYPE || ' ' || F.REFEXT ELEMCTX,
               'PUG' AS TYPETRAD,
               E.DT03_DT DTCPTMVT,
               E.DT03_DT DTGESTMVT,
               'PUG' CODEMVT,
               'x' REFMVT,
               'f' TYPMVT,
               E.STR10 REFECRIT,
               E.MT01 + E.MT02 MNTTOTAL,
               E.MT01 + E.MT02 MNTCTX,
               'PRINCIPAL' COMPTEUR,
               0 MNTSOLDEDB,
               -E.MT01 MNTIMMINENTFACT,
               -E.MT02 MNTIMMINENTCL,
               NVL(E.MT10, E.MT01) MNTCAPITCVTFACT,
               DECODE(E.MT10, NULL, E.MT02, E.MT01 + E.MT02 - E.MT10) MNTCAPITCVTCL,
               0 MNTCOURTCOSTSFACT,
               0 MNTCOURTCOSTSCL,
               0 MNTLAWYERCOSTSFACT,
               0 MNTLAWYERCOSTSCL,
               0 MNTNONAFF,
               0 AVAILFORALLOC,
               0 MNTINDARESEV,
               0 MNTINDREVERS,
               0 MNTREMBCHEZCI,
               0 MNTDISPO,
               1 FLAGCVT,
               E.REFDOSS REFDOSS
          FROM G_ELEMFIDET E, G_ELEMFI F
         WHERE F.REFELEM = E.REFELEM
           AND ABS(E.MT01 + E.MT02) > 0
           AND E.FG01 = 'O'
           AND NOT EXISTS (SELECT 1
                  FROM G_ELEMFIDET P
                 WHERE P.TYPE = 'PUG_FACTOR'
                   AND P.REFDOSS = :B1)
           AND E.REFDOSS = :B1
           AND E.TYPE = 'SOLDES_FACT_CTX'
        UNION ALL
        SELECT STR1 ELEMCTX,
               'PUG' AS TYPETRAD,
               DT01_DT DTCPTMVT,
               DT01_DT DTGESTMVT,
               'PUG' CODEMVT,
               'x' REFMVT,
               'f' TYPMVT,
               STR10 REFECRIT,
               E.MT03 + E.MT04 MNTTOTAL,
               E.MT03 + E.MT04 MNTCTX,
               'PRINCIPAL' COMPTEUR,
               0.0 MNTSOLDEDB,
               E.MT01 MNTIMMINENTFACT,
               E.MT02 MNTIMMINENTCL,
               E.MT03 MNTCAPITCVTFACT,
               E.MT04 MNTCAPITCVTCL,
               0 MNTCOURTCOSTSFACT,
               0 MNTCOURTCOSTSCL,
               0 MNTLAWYERCOSTSFACT,
               0 MNTLAWYERCOSTSCL,
               0 MNTNONAFF,
               0 AVAILFORALLOC,
               0 MNTINDARESEV,
               0 MNTINDREVERS,
               0 MNTREMBCHEZCI,
               0 MNTDISPO,
               1 FLAGCVT,
               E.REFDOSS REFDOSS
          FROM G_ELEMFIDET E
         WHERE E.REFDOSS = :B1
           AND E.TYPE = 'PUG_FACTOR'
        UNION ALL
        SELECT T.LIBELLE ELEMCTX,
               T.CODECR TYPETRAD,
               T.DTJOUR_DT DTCPTMVT,
               T.DATECR_DT DTGESTMVT,
               T.CODECR CODEMVT,
               T.REFELEM REFMVT,
               T.TYPELEM TYPMVT,
               T.REFJOUR REFECRIT,
               GREATEST(ABS(T.DBDU_DOS), ABS(T.DBDEDUC_DOS)) MNTTOTAL,
               GREATEST(ABS(T.DBDU_DOS), ABS(T.DBDEDUC_DOS)) MNTCTX,
               'DISPO' COMPTEUR,
               0 MNTSOLDEDB,
               0 MNTIMMINENTFACT,
               0 MNTIMMINENTCL,
               0 MNTCAPITCVTFACT,
               0 MNTCAPITCVTCL,
               0 MNTCOURTCOSTSFACT,
               0 MNTCOURTCOSTSCL,
               0 MNTLAWYERCOSTSFACT,
               0 MNTLAWYERCOSTSCL,
               0 MNTNONAFF,
               0 AVAILFORALLOC,
               DBDU_DOS MNTINDARESEV,
               DBDEDUC_DOS MNTINDREVERS,
               0 MNTREMBCHEZCI,
               T.CLDEPOT_DOS MNTDISPO,
               1 FLAGCVT,
               T.REFDOSS REFDOSS
          FROM T_ECRDOS T
         WHERE T.CODECR = 'RINCI'
           AND NVL(T.REFJOUR, NULL) > :B2
           AND T.REFDOSS = :B1
        UNION ALL
        SELECT STR1 ELEMCTX,
               NULL TYPETRAD,
               DT02_DT DTCPTMVT,
               DT01_DT DTGESTMVT,
               'CLAIM' CODEMVT,
               'x' REFMVT,
               'f' TYPMVT,
               STR10 REFECRIT,
               0 MNTTOTAL,
               0 MNTCTX,
               'PRINCIPAL' COMPTEUR,
               0 MNTSOLDEDB,
               0 MNTIMMINENTFACT,
               0 MNTIMMINENTCL,
               0 MNTCAPITCVTFACT,
               0 MNTCAPITCVTCL,
               0 MNTCOURTCOSTSFACT,
               0 MNTCOURTCOSTSCL,
               0 MNTLAWYERCOSTSFACT,
               0 MNTLAWYERCOSTSCL,
               0 MNTNONAFF,
               0 AVAILFORALLOC,
               MT05 MNTINDARESEV,
               MT06 MNTINDREVERS,
               0 MNTREMBCHEZCI,
               MT07 MNTDISPO,
               1 FLAGCVT,
               REFDOSS
          FROM G_ELEMFIDET
         WHERE TYPE = 'TOTAL_CLAIM_CI'
           AND REFDOSS = :B1
        UNION ALL
        SELECT T.LIBELLE ELEMCTX,
               T.CODECR TYPETRAD,
               T.DTJOUR_DT DTCPTMVT,
               T.DATECR_DT DTGESTMVT,
               T.CODECR CODEMVT,
               T.REFELEM REFMVT,
               T.TYPELEM TYPMVT,
               T.REFJOUR REFECRIT,
               DECODE(V.ELEMENT,
                      'dbdu',
                      T.DBDU_DOS,
                      'dbdeduc',
                      T.DBDEDUC_DOS,
                      'cldu',
                      T.CLDU_DOS,
                      'clretrait',
                      T.CLRETRAIT_DOS,
                      'cldepot',
                      T.CLDEPOT_DOS,
                      0) MNTTOTAL,
               DECODE(V.ELEMENT,
                      'dbdu',
                      T.DBDU_DOS,
                      'dbdeduc',
                      T.DBDEDUC_DOS,
                      'cldu',
                      T.CLDU_DOS,
                      'clretrait',
                      T.CLRETRAIT_DOS,
                      'cldepot',
                      T.CLDEPOT_DOS,
                      0) MNTCTX,
               V.SOMME COMPTEUR,
               0 MNTSOLDEDB,
               0 MNTIMMINENTFACT,
               0 MNTIMMINENTCL,
               DECODE(V.SOMME, 'PERTE', DBDU_DOS, 0) MNTCAPITCVTFACT,
               DECODE(V.SOMME, 'PERTE', DBDEDUC_DOS, 0) MNTCAPITCVTCL,
               DECODE(V.SOMME, 'PERTE', ETDBRSREM_DOS, 0) MNTCOURTCOSTSFACT,
               DECODE(V.SOMME, 'PERTE', ETDEBRSDU_DOS, 0) MNTCOURTCOSTSCL,
               DECODE(V.SOMME, 'PERTE', CLDU_DOS, 0) MNTLAWYERCOSTSFACT,
               DECODE(V.SOMME, 'PERTE', CLRETRAIT_DOS, 0) MNTLAWYERCOSTSCL,
               0 MNTNONAFF,
               0 AVAILFORALLOC,
               0 MNTINDARESEV,
               0 MNTINDREVERS,
               0 MNTREMBCHEZCI,
               0 MNTDISPO,
               0 FLAGCVT,
               T.REFDOSS REFDOSS
          FROM T_ECRDOS T, V_CALDOS V
         WHERE T.CODECR = V.CODECR
           AND V.CODECR NOT IN ('PRIN', 'DPDB', 'RINCI', 'DPRIN')
           AND V.CODECR NOT IN
               (SELECT VALEUR FROM V_DOMAINE WHERE TYPE = 'DV_ECRIT_CVT')
           AND V.CODECR NOT IN
               (SELECT VALEUR_AN FROM V_DOMAINE WHERE TYPE = 'DV_ECRIT_CVT')
           AND V.SOMME IN ('PRINCIPAL',
                           'TDEBS',
                           'UHONOR',
                           'FACDP',
                           'TTFRAI',
                           'THDEBS',
                           'ACOMPT',
                           'DISPO',
                           'TFRAI',
                           'PERTE',
                           'ZERODB')
           AND NVL(T.REFJOUR, NULL) > :B2
           AND T.REFDOSS = :B1)
 WHERE 1 = 1
   AND (NVL(:B11, '~~!!~~') = '~~!!~~' OR CASE
         WHEN TYPETRAD IS NULL THEN
          IMX.TRANSL_VALEUR('MISC_TRANSLATIONS', ELEMCTX, :B12)
         ELSE
          IMX.FTRANSLATE_STR(ELEMCTX, :B12, TYPETRAD)
       END LIKE '%' || :B11 || '%')
   AND DTCPTMVT BETWEEN NVL(:B10, DTCPTMVT) AND NVL(:B9, DTCPTMVT)
   AND DTGESTMVT BETWEEN NVL(:B8, DTGESTMVT) AND NVL(:B7, DTGESTMVT)
   AND REFMVT = NVL(:B6, REFMVT)
   AND TYPMVT = NVL(:B5, TYPMVT)
   AND CODEMVT = NVL(:B4, CODEMVT)
   AND REFECRIT = NVL(:B3, REFECRIT)
 ORDER BY REFECRIT, REFMVT;

/********************************OLD SQL*******************************************/
/********************************OLD Metrics***************************************/
/*

-- With :B2 = 'O0A5P32X'

Plan hash value: 888755973
------------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                     | Name                        | Starts | E-Rows | A-Rows |   A-Time   | Buffers | Reads  |
------------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                              |                             |      1 |        |      2 |00:06:23.71 |      19M|   1507K|
|   1 |  SORT ORDER BY                                |                             |      1 |     11 |      2 |00:06:23.71 |      19M|   1507K|
|*  2 |   VIEW                                        |                             |      1 |     11 |      2 |00:06:23.71 |      19M|   1507K|
|   3 |    UNION-ALL                                  |                             |      1 |        |      2 |00:06:23.71 |      19M|   1507K|
|*  4 |     FILTER                                    |                             |      1 |        |      0 |00:00:00.01 |       4 |      0 |
|   5 |      VIEW                                     | VW_ORE_792AB197             |      1 |      2 |      0 |00:00:00.01 |       4 |      0 |
|   6 |       UNION-ALL                               |                             |      1 |        |      0 |00:00:00.01 |       4 |      0 |
|*  7 |        FILTER                                 |                             |      1 |        |      0 |00:00:00.01 |       0 |      0 |
|*  8 |         TABLE ACCESS BY INDEX ROWID BATCHED   | G_ELEMFIDET                 |      0 |      1 |      0 |00:00:00.01 |       0 |      0 |
|*  9 |          INDEX RANGE SCAN                     | EFIDET_REFELEM              |      0 |      1 |      0 |00:00:00.01 |       0 |      0 |
|* 10 |        FILTER                                 |                             |      1 |        |      0 |00:00:00.01 |       4 |      0 |
|* 11 |         TABLE ACCESS BY INDEX ROWID BATCHED   | G_ELEMFIDET                 |      1 |      1 |      0 |00:00:00.01 |       4 |      0 |
|* 12 |          INDEX RANGE SCAN                     | EFIDET_REFDOSS              |      1 |     25 |      0 |00:00:00.01 |       4 |      0 |
|  13 |     NESTED LOOPS                              |                             |      1 |      1 |      1 |00:00:00.01 |      14 |      0 |
|  14 |      NESTED LOOPS                             |                             |      1 |      2 |      1 |00:00:00.01 |      13 |      0 |
|  15 |       VIEW                                    | VW_JF_SET$7EC80C17          |      1 |      2 |      1 |00:00:00.01 |       9 |      0 |
|  16 |        UNION-ALL                              |                             |      1 |        |      1 |00:00:00.01 |       9 |      0 |
|* 17 |         FILTER                                |                             |      1 |        |      1 |00:00:00.01 |       9 |      0 |
|  18 |          NESTED LOOPS                         |                             |      1 |      1 |      1 |00:00:00.01 |       9 |      0 |
|  19 |           NESTED LOOPS                        |                             |      1 |      1 |      1 |00:00:00.01 |       8 |      0 |
|* 20 |            TABLE ACCESS BY INDEX ROWID BATCHED| T_ECRDOS                    |      1 |      1 |      1 |00:00:00.01 |       5 |      0 |
|* 21 |             INDEX RANGE SCAN                  | TECR_REFDOSS_DTJOUR         |      1 |      1 |      1 |00:00:00.01 |       4 |      0 |
|* 22 |            INDEX RANGE SCAN                   | EFIDET_REFELEM              |      1 |      1 |      1 |00:00:00.01 |       3 |      0 |
|* 23 |           TABLE ACCESS BY INDEX ROWID         | G_ELEMFIDET                 |      1 |      1 |      1 |00:00:00.01 |       1 |      0 |
|* 24 |         FILTER                                |                             |      1 |        |      0 |00:00:00.01 |       0 |      0 |
|  25 |          NESTED LOOPS                         |                             |      0 |      1 |      0 |00:00:00.01 |       0 |      0 |
|  26 |           NESTED LOOPS                        |                             |      0 |      1 |      0 |00:00:00.01 |       0 |      0 |
|* 27 |            TABLE ACCESS BY INDEX ROWID BATCHED| T_ECRDOS                    |      0 |      1 |      0 |00:00:00.01 |       0 |      0 |
|* 28 |             INDEX RANGE SCAN                  | TECR$REFDOSS_CODECR_DTINTER |      0 |      1 |      0 |00:00:00.01 |       0 |      0 |
|* 29 |            INDEX RANGE SCAN                   | EFIDET_REFELEM              |      0 |      1 |      0 |00:00:00.01 |       0 |      0 |
|* 30 |           TABLE ACCESS BY INDEX ROWID         | G_ELEMFIDET                 |      0 |      1 |      0 |00:00:00.01 |       0 |      0 |
|* 31 |       INDEX UNIQUE SCAN                       | EFI_REFELEM                 |      1 |      1 |      1 |00:00:00.01 |       4 |      0 |
|* 32 |      TABLE ACCESS BY INDEX ROWID              | G_ELEMFI                    |      1 |      1 |      1 |00:00:00.01 |       1 |      0 |
|* 33 |     FILTER                                    |                             |      1 |        |      0 |00:00:00.01 |       4 |      0 |
|  34 |      HASH GROUP BY                            |                             |      1 |      1 |      0 |00:00:00.01 |       4 |      0 |
|* 35 |       FILTER                                  |                             |      1 |        |      0 |00:00:00.01 |       4 |      0 |
|* 36 |        HASH JOIN OUTER                        |                             |      1 |     25 |      0 |00:00:00.01 |       4 |      0 |
|  37 |         TABLE ACCESS BY INDEX ROWID BATCHED   | G_ELEMFIDET                 |      1 |     25 |      0 |00:00:00.01 |       4 |      0 |
|* 38 |          INDEX RANGE SCAN                     | EFIDET_REFDOSS              |      1 |     25 |      0 |00:00:00.01 |       4 |      0 |
|  39 |         TABLE ACCESS BY INDEX ROWID BATCHED   | T_ECRDOS                    |      0 |      3 |      0 |00:00:00.01 |       0 |      0 |
|* 40 |          INDEX RANGE SCAN                     | TECR$REFDOSS_CODECR_DTINTER |      0 |      3 |      0 |00:00:00.01 |       0 |      0 |
|* 41 |     FILTER                                    |                             |      1 |        |      1 |00:00:00.01 |      14 |      0 |
|  42 |      NESTED LOOPS                             |                             |      1 |      1 |      1 |00:00:00.01 |      10 |      0 |
|  43 |       NESTED LOOPS                            |                             |      1 |      1 |      1 |00:00:00.01 |       9 |      0 |
|* 44 |        TABLE ACCESS BY INDEX ROWID BATCHED    | G_ELEMFIDET                 |      1 |      1 |      1 |00:00:00.01 |       5 |      0 |
|* 45 |         INDEX RANGE SCAN                      | EFIDET_REFDOSS              |      1 |     25 |      1 |00:00:00.01 |       4 |      0 |
|* 46 |        INDEX UNIQUE SCAN                      | EFI_REFELEM                 |      1 |      1 |      1 |00:00:00.01 |       4 |      0 |
|* 47 |       TABLE ACCESS BY INDEX ROWID             | G_ELEMFI                    |      1 |      1 |      1 |00:00:00.01 |       1 |      0 |
|* 48 |      INDEX RANGE SCAN                         | EFIDET_REFDOSS              |      1 |      2 |      0 |00:00:00.01 |       4 |      0 |
|* 49 |     FILTER                                    |                             |      1 |        |      0 |00:00:00.01 |       4 |      0 |
|* 50 |      TABLE ACCESS BY INDEX ROWID BATCHED      | G_ELEMFIDET                 |      1 |      1 |      0 |00:00:00.01 |       4 |      0 |
|* 51 |       INDEX RANGE SCAN                        | EFIDET_REFDOSS              |      1 |     25 |      0 |00:00:00.01 |       4 |      0 |
|  52 |     VIEW                                      | VW_ORE_6F90719D             |      1 |      2 |      0 |00:06:04.61 |    9536K|   1507K|
|  53 |      UNION-ALL                                |                             |      1 |        |      0 |00:06:04.61 |    9536K|   1507K|
|* 54 |       FILTER                                  |                             |      1 |        |      0 |00:00:00.01 |       0 |      0 |
|* 55 |        TABLE ACCESS BY INDEX ROWID BATCHED    | T_ECRDOS                    |      0 |      1 |      0 |00:00:00.01 |       0 |      0 |
|* 56 |         INDEX RANGE SCAN                      | T_ECRDOS_REFJOUR_IDX        |      0 |      1 |      0 |00:00:00.01 |       0 |      0 |
|* 57 |       FILTER                                  |                             |      1 |        |      0 |00:06:04.61 |    9536K|   1507K|
|* 58 |        TABLE ACCESS BY INDEX ROWID BATCHED    | T_ECRDOS                    |      1 |      1 |      0 |00:06:04.61 |    9536K|   1507K|
|* 59 |         INDEX RANGE SCAN                      | T_ECRDOS_REFJOUR_IDX        |      1 |      1 |     29M|00:00:18.21 |   83261 |  49729 |
|* 60 |     FILTER                                    |                             |      1 |        |      0 |00:00:00.01 |       4 |      0 |
|* 61 |      TABLE ACCESS BY INDEX ROWID BATCHED      | G_ELEMFIDET                 |      1 |      1 |      0 |00:00:00.01 |       4 |      0 |
|* 62 |       INDEX RANGE SCAN                        | EFIDET_REFDOSS              |      1 |      2 |      0 |00:00:00.01 |       4 |      0 |
|* 63 |     VIEW                                      | VW_ORE_D4815FD5             |      1 |      2 |      0 |00:00:19.11 |    9984K|      0 |
|  64 |      UNION-ALL                                |                             |      1 |        |      0 |00:00:19.11 |    9984K|      0 |
|* 65 |       FILTER                                  |                             |      1 |        |      0 |00:00:00.01 |       0 |      0 |
|  66 |        NESTED LOOPS ANTI SNA                  |                             |      0 |      1 |      0 |00:00:00.01 |       0 |      0 |
|  67 |         NESTED LOOPS ANTI SNA                 |                             |      0 |      1 |      0 |00:00:00.01 |       0 |      0 |
|  68 |          NESTED LOOPS                         |                             |      0 |      1 |      0 |00:00:00.01 |       0 |      0 |
|* 69 |           TABLE ACCESS BY INDEX ROWID BATCHED | T_ECRDOS                    |      0 |      1 |      0 |00:00:00.01 |       0 |      0 |
|* 70 |            INDEX RANGE SCAN                   | T_ECRDOS_REFJOUR_IDX        |      0 |      1 |      0 |00:00:00.01 |       0 |      0 |
|  71 |           TABLE ACCESS BY INDEX ROWID BATCHED | V_CALDOS                    |      0 |      1 |      0 |00:00:00.01 |       0 |      0 |
|* 72 |            INDEX RANGE SCAN                   | VCALDOS_SC                  |      0 |      1 |      0 |00:00:00.01 |       0 |      0 |
|* 73 |          INDEX RANGE SCAN                     | DOM_TYPVAL                  |      0 |     21 |      0 |00:00:00.01 |       0 |      0 |
|* 74 |         TABLE ACCESS BY INDEX ROWID BATCHED   | V_DOMAINE                   |      0 |     45 |      0 |00:00:00.01 |       0 |      0 |
|* 75 |          INDEX RANGE SCAN                     | V_DOMAINE_TYPE_CODE_IDX     |      0 |     45 |      0 |00:00:00.01 |       0 |      0 |
|* 76 |        TABLE ACCESS BY INDEX ROWID BATCHED    | V_DOMAINE                   |      0 |      1 |      0 |00:00:00.01 |       0 |      0 |
|* 77 |         INDEX RANGE SCAN                      | V_DOMAINE_TYPE_CODE_IDX     |      0 |     45 |      0 |00:00:00.01 |       0 |      0 |
|* 78 |        INDEX RANGE SCAN                       | DOM_TYPVAL                  |      0 |      1 |      0 |00:00:00.01 |       0 |      0 |
|* 79 |       FILTER                                  |                             |      1 |        |      0 |00:00:19.11 |    9984K|      0 |
|  80 |        NESTED LOOPS ANTI SNA                  |                             |      1 |      1 |      0 |00:00:19.11 |    9984K|      0 |
|  81 |         NESTED LOOPS ANTI SNA                 |                             |      1 |      1 |      0 |00:00:19.11 |    9984K|      0 |
|  82 |          NESTED LOOPS                         |                             |      1 |      1 |      2 |00:00:19.11 |    9984K|      0 |
|* 83 |           TABLE ACCESS BY INDEX ROWID BATCHED | T_ECRDOS                    |      1 |      1 |      2 |00:00:19.11 |    9984K|      0 |
|* 84 |            INDEX RANGE SCAN                   | T_ECRDOS_REFJOUR_IDX        |      1 |      1 |     29M|00:00:04.40 |   83260 |      0 |
|  85 |           TABLE ACCESS BY INDEX ROWID BATCHED | V_CALDOS                    |      2 |      1 |      2 |00:00:00.01 |       5 |      0 |
|* 86 |            INDEX RANGE SCAN                   | VCALDOS_SC                  |      2 |      1 |      2 |00:00:00.01 |       4 |      0 |
|* 87 |          INDEX RANGE SCAN                     | DOM_TYPVAL                  |      2 |     21 |      2 |00:00:00.01 |       6 |      0 |
|* 88 |         TABLE ACCESS BY INDEX ROWID BATCHED   | V_DOMAINE                   |      0 |     45 |      0 |00:00:00.01 |       0 |      0 |
|* 89 |          INDEX RANGE SCAN                     | V_DOMAINE_TYPE_CODE_IDX     |      0 |     45 |      0 |00:00:00.01 |       0 |      0 |
|* 90 |        TABLE ACCESS BY INDEX ROWID BATCHED    | V_DOMAINE                   |      1 |      1 |      0 |00:00:00.01 |       4 |      0 |
|* 91 |         INDEX RANGE SCAN                      | V_DOMAINE_TYPE_CODE_IDX     |      1 |     45 |      7 |00:00:00.01 |       2 |      0 |
|* 92 |        INDEX RANGE SCAN                       | DOM_TYPVAL                  |      1 |      1 |      0 |00:00:00.01 |       3 |      0 |
------------------------------------------------------------------------------------------------------------------------------------------------

Predicate Information (identified by operation id):
---------------------------------------------------
   2 - filter(("DTCPTMVT">=NVL(:B10,INTERNAL_FUNCTION("DTCPTMVT")) AND "DTCPTMVT"<=NVL(:B9,INTERNAL_FUNCTION("DTCPTMVT")) AND
              "DTGESTMVT">=NVL(:B8,INTERNAL_FUNCTION("DTGESTMVT")) AND "DTGESTMVT"<=NVL(:B7,INTERNAL_FUNCTION("DTGESTMVT")) AND
              "REFMVT"=NVL(:B6,"REFMVT") AND "TYPMVT"=NVL(:B5,"TYPMVT") AND "CODEMVT"=NVL(:B4,"CODEMVT") AND "REFECRIT"=NVL(:B3,"REFECRIT") AND
              (NVL(:B11,'~~!!~~')='~~!!~~' OR CASE  WHEN "TYPETRAD" IS NULL THEN "IMX"."TRANSL_VALEUR"('MISC_TRANSLATIONS',"ELEMCTX",:B12) ELSE
              "IMX"."FTRANSLATE_STR"("ELEMCTX",:B12,"TYPETRAD") END  LIKE '%'||:B11||'%')))
   4 - filter(('r'=NVL(:B5,'r') AND 'REP'=NVL(:B4,'REP')))
   7 - filter((:B6 IS NOT NULL AND NVL(:B4,'REP')='REP' AND NVL(:B5,'r')='r'))
   8 - filter(("REFDOSS"=:B1 AND "STR10"=NVL(:B3,"STR10") AND "DT02_DT">=NVL(:B10,INTERNAL_FUNCTION("DT02_DT")) AND
              "DT02_DT"<=NVL(:B9,INTERNAL_FUNCTION("DT02_DT")) AND "DT01_DT">=NVL(:B8,INTERNAL_FUNCTION("DT01_DT")) AND
              "DT01_DT"<=NVL(:B7,INTERNAL_FUNCTION("DT01_DT")) AND (NVL(:B11,'~~!!~~')='~~!!~~' OR CASE  WHEN 'REP' IS NULL THEN
              "IMX"."TRANSL_VALEUR"('MISC_TRANSLATIONS',"STR1",:B12) ELSE "IMX"."FTRANSLATE_STR"("STR1",:B12,'REP') END  LIKE '%'||:B11||'%')))
   9 - access("REFELEM"=:B6 AND "TYPE"='MVT_REPRISE')
       filter(NVL(:B6,"REFELEM")=:B6)
  10 - filter((NVL(:B4,'REP')='REP' AND NVL(:B5,'r')='r' AND :B6 IS NULL))
  11 - filter(("STR10"=NVL(:B3,"STR10") AND "DT02_DT">=NVL(:B10,INTERNAL_FUNCTION("DT02_DT")) AND
              "DT02_DT"<=NVL(:B9,INTERNAL_FUNCTION("DT02_DT")) AND "DT01_DT">=NVL(:B8,INTERNAL_FUNCTION("DT01_DT")) AND
              "DT01_DT"<=NVL(:B7,INTERNAL_FUNCTION("DT01_DT")) AND (NVL(:B11,'~~!!~~')='~~!!~~' OR CASE  WHEN 'REP' IS NULL THEN
              "IMX"."TRANSL_VALEUR"('MISC_TRANSLATIONS',"STR1",:B12) ELSE "IMX"."FTRANSLATE_STR"("STR1",:B12,'REP') END  LIKE '%'||:B11||'%') AND
              "REFELEM" IS NOT NULL AND "REFELEM"=NVL(:B6,"REFELEM")))
  12 - access("REFDOSS"=:B1 AND "TYPE"='MVT_REPRISE')
  17 - filter(:B4 IS NULL)
  20 - filter((NVL("T"."REFJOUR",' ')=NVL(:B3,NVL("T"."REFJOUR",' ')) AND "T"."DATECR_DT"<=NVL(:B7,INTERNAL_FUNCTION("T"."DATECR_DT"))
              AND "T"."DATECR_DT">=NVL(:B8,INTERNAL_FUNCTION("T"."DATECR_DT")) AND "T"."DTJOUR_DT"<=NVL(:B9,INTERNAL_FUNCTION("T"."DTJOUR_DT")) AND
              "T"."DTJOUR_DT">=NVL(:B10,INTERNAL_FUNCTION("T"."DTJOUR_DT")) AND "T"."REFELEM"=NVL(:B6,"T"."REFELEM") AND
              "T"."TYPELEM"=NVL(:B5,"T"."TYPELEM")))
  21 - access("T"."REFDOSS"=:B1)
       filter((INTERNAL_FUNCTION("T"."CODECR") AND (NVL(:B4,"T"."CODECR")='DPDB' OR NVL(:B4,"T"."CODECR")='DPRIN' OR
              NVL(:B4,"T"."CODECR")='PRIN' OR NVL(:B4,"T"."CODECR")='PRIN0') AND "T"."CODECR"=NVL(:B4,"T"."CODECR")))
  22 - access("T"."REFELEM"="E"."REFELEM" AND "E"."TYPE"='PASS_FACT_CTX')
  23 - filter("E"."REFDOSS"=:B1)
  24 - filter((:B4 IS NOT NULL AND ('DPDB'=:B4 OR 'DPRIN'=:B4 OR 'PRIN'=:B4 OR 'PRIN0'=:B4)))
  27 - filter((NVL("T"."REFJOUR",' ')=NVL(:B3,NVL("T"."REFJOUR",' ')) AND "T"."DATECR_DT"<=NVL(:B7,INTERNAL_FUNCTION("T"."DATECR_DT"))
              AND "T"."DATECR_DT">=NVL(:B8,INTERNAL_FUNCTION("T"."DATECR_DT")) AND "T"."DTJOUR_DT"<=NVL(:B9,INTERNAL_FUNCTION("T"."DTJOUR_DT")) AND
              "T"."DTJOUR_DT">=NVL(:B10,INTERNAL_FUNCTION("T"."DTJOUR_DT")) AND "T"."REFELEM"=NVL(:B6,"T"."REFELEM") AND
              "T"."TYPELEM"=NVL(:B5,"T"."TYPELEM")))
  28 - access("T"."REFDOSS"=:B1 AND "T"."CODECR"=:B4)
       filter((INTERNAL_FUNCTION("T"."CODECR") AND NVL(:B4,"T"."CODECR")=:B4 AND (NVL(:B4,"T"."CODECR")='DPDB' OR
              NVL(:B4,"T"."CODECR")='DPRIN' OR NVL(:B4,"T"."CODECR")='PRIN' OR NVL(:B4,"T"."CODECR")='PRIN0')))
  29 - access("T"."REFELEM"="E"."REFELEM" AND "E"."TYPE"='PASS_FACT_CTX')
  30 - filter("E"."REFDOSS"=:B1)
  31 - access("F"."REFELEM"="ITEM_1")
  32 - filter((NVL(:B11,'~~!!~~')='~~!!~~' OR CASE  WHEN "ITEM_4" IS NULL THEN
              "IMX"."TRANSL_VALEUR"('MISC_TRANSLATIONS',"ITEM_2"||"ITEM_3"||' '||"F"."REFEXT",:B12) ELSE "IMX"."FTRANSLATE_STR"("ITEM_2"||"ITEM_3"||'
              '||"F"."REFEXT",:B12,"ITEM_4") END  LIKE '%'||:B11||'%'))
  33 - filter((MAX("E"."DT02_DT")>=NVL(:B10,MAX("E"."DT02_DT")) AND MAX("E"."DT02_DT")<=NVL(:B9,MAX("E"."DT02_DT")) AND
              MAX("E"."DT01_DT")>=NVL(:B8,MAX("E"."DT01_DT")) AND MAX("E"."DT01_DT")<=NVL(:B7,MAX("E"."DT01_DT")) AND
              MAX("E"."REFELEM")=NVL(:B6,MAX("E"."REFELEM")) AND MAX("E"."STR10")=NVL(:B3,MAX("E"."STR10")) AND (NVL(:B11,'~~!!~~')='~~!!~~' OR CASE
              WHEN 'NMP' IS NULL THEN "IMX"."TRANSL_VALEUR"('MISC_TRANSLATIONS',MAX("E"."STR1"),:B12) ELSE
              "IMX"."FTRANSLATE_STR"(MAX("E"."STR1"),:B12,'NMP') END  LIKE '%'||:B11||'%') AND MAX("E"."STR10")=NVL(:B3,MAX("E"."STR10")) AND
              MAX("E"."REFELEM")=NVL(:B6,MAX("E"."REFELEM")) AND MAX("E"."DT01_DT")<=NVL(:B7,MAX("E"."DT01_DT")) AND
              MAX("E"."DT01_DT")>=NVL(:B8,MAX("E"."DT01_DT")) AND MAX("E"."DT02_DT")<=NVL(:B9,MAX("E"."DT02_DT")) AND
              MAX("E"."DT02_DT")>=NVL(:B10,MAX("E"."DT02_DT"))))
  35 - filter((NVL(:B4,'NMP')='NMP' AND NVL(:B5,'e')='e'))
  36 - access("T"."REFDOSS"="E"."REFDOSS" AND "T"."REFELEM"="E"."REFELEM")
  38 - access("E"."REFDOSS"=:B1 AND "E"."TYPE"='PASS_NMP_CTX')
  40 - access("T"."REFDOSS"=:B1 AND "T"."CODECR"='RCTX')
  41 - filter((NVL(:B4,'PUG')='PUG' AND NVL(:B5,'f')='f' AND NVL(:B6,'x')='x' AND  IS NULL))
  44 - filter(("E"."FG01"='O' AND ABS("E"."MT01"+"E"."MT02")>0 AND "E"."STR10"=NVL(:B3,"E"."STR10") AND
              "E"."DT03_DT">=NVL(:B10,INTERNAL_FUNCTION("E"."DT03_DT")) AND "E"."DT03_DT"<=NVL(:B9,INTERNAL_FUNCTION("E"."DT03_DT")) AND
              "E"."DT03_DT">=NVL(:B8,INTERNAL_FUNCTION("E"."DT03_DT")) AND "E"."DT03_DT"<=NVL(:B7,INTERNAL_FUNCTION("E"."DT03_DT"))))
  45 - access("E"."REFDOSS"=:B1 AND "E"."TYPE"='SOLDES_FACT_CTX')
  46 - access("F"."REFELEM"="E"."REFELEM")
  47 - filter((NVL(:B11,'~~!!~~')='~~!!~~' OR CASE  WHEN 'PUG' IS NULL THEN "IMX"."TRANSL_VALEUR"('MISC_TRANSLATIONS',"E"."STR1"||':
              '||"F"."TYPE"||' '||"F"."REFEXT",:B12) ELSE "IMX"."FTRANSLATE_STR"("E"."STR1"||': '||"F"."TYPE"||' '||"F"."REFEXT",:B12,'PUG') END
              LIKE '%'||:B11||'%'))
  48 - access("P"."REFDOSS"=:B1 AND "P"."TYPE"='PUG_FACTOR')
  49 - filter((NVL(:B4,'PUG')='PUG' AND NVL(:B5,'f')='f' AND NVL(:B6,'x')='x'))
  50 - filter(("STR10"=NVL(:B3,"STR10") AND "DT01_DT">=NVL(:B10,INTERNAL_FUNCTION("DT01_DT")) AND
              "DT01_DT"<=NVL(:B9,INTERNAL_FUNCTION("DT01_DT")) AND "DT01_DT">=NVL(:B8,INTERNAL_FUNCTION("DT01_DT")) AND
              "DT01_DT"<=NVL(:B7,INTERNAL_FUNCTION("DT01_DT")) AND (NVL(:B11,'~~!!~~')='~~!!~~' OR CASE  WHEN 'PUG' IS NULL THEN
              "IMX"."TRANSL_VALEUR"('MISC_TRANSLATIONS',"STR1",:B12) ELSE "IMX"."FTRANSLATE_STR"("STR1",:B12,'PUG') END  LIKE '%'||:B11||'%')))
  51 - access("E"."REFDOSS"=:B1 AND "E"."TYPE"='PUG_FACTOR')
  54 - filter(:B3 IS NOT NULL)
  55 - filter(("T"."REFDOSS"=:B1 AND "T"."CODECR"='RINCI' AND NVL(:B4,"T"."CODECR")='RINCI' AND
              "T"."DTJOUR_DT">=NVL(:B10,INTERNAL_FUNCTION("T"."DTJOUR_DT")) AND "T"."DTJOUR_DT"<=NVL(:B9,INTERNAL_FUNCTION("T"."DTJOUR_DT")) AND
              "T"."DATECR_DT">=NVL(:B8,INTERNAL_FUNCTION("T"."DATECR_DT")) AND "T"."DATECR_DT"<=NVL(:B7,INTERNAL_FUNCTION("T"."DATECR_DT")) AND
             (NVL(:B11,'~~!!~~')='~~!!~~' OR CASE  WHEN "T"."CODECR" IS NULL THEN "IMX"."TRANSL_VALEUR"('MISC_TRANSLATIONS',"T"."LIBELLE",:B12) ELSE
              "IMX"."FTRANSLATE_STR"("T"."LIBELLE",:B12,"T"."CODECR") END  LIKE '%'||:B11||'%') AND "T"."REFELEM"=NVL(:B6,"T"."REFELEM") AND
              "T"."TYPELEM"=NVL(:B5,"T"."TYPELEM")))
  56 - access("T"."REFJOUR"=:B3)
       filter(("T"."REFJOUR">:B2 AND NVL(:B3,"T"."REFJOUR")=:B3))
  57 - filter(:B3 IS NULL)
  58 - filter(("T"."REFDOSS"=:B1 AND "T"."CODECR"='RINCI' AND NVL(:B4,"T"."CODECR")='RINCI' AND
              "T"."DTJOUR_DT">=NVL(:B10,INTERNAL_FUNCTION("T"."DTJOUR_DT")) AND "T"."DTJOUR_DT"<=NVL(:B9,INTERNAL_FUNCTION("T"."DTJOUR_DT")) AND
              "T"."DATECR_DT">=NVL(:B8,INTERNAL_FUNCTION("T"."DATECR_DT")) AND "T"."DATECR_DT"<=NVL(:B7,INTERNAL_FUNCTION("T"."DATECR_DT")) AND
              (NVL(:B11,'~~!!~~')='~~!!~~' OR CASE  WHEN "T"."CODECR" IS NULL THEN "IMX"."TRANSL_VALEUR"('MISC_TRANSLATIONS',"T"."LIBELLE",:B12) ELSE
              "IMX"."FTRANSLATE_STR"("T"."LIBELLE",:B12,"T"."CODECR") END  LIKE '%'||:B11||'%') AND "T"."REFELEM"=NVL(:B6,"T"."REFELEM") AND
              "T"."TYPELEM"=NVL(:B5,"T"."TYPELEM")))
  59 - access("T"."REFJOUR">:B2)
       filter("T"."REFJOUR"=NVL(:B3,"T"."REFJOUR"))
  60 - filter((NVL(:B4,'CLAIM')='CLAIM' AND NVL(:B5,'f')='f' AND NVL(:B6,'x')='x'))
  61 - filter(("STR10"=NVL(:B3,"STR10") AND "DT02_DT">=NVL(:B10,INTERNAL_FUNCTION("DT02_DT")) AND
              "DT02_DT"<=NVL(:B9,INTERNAL_FUNCTION("DT02_DT")) AND "DT01_DT">=NVL(:B8,INTERNAL_FUNCTION("DT01_DT")) AND
              "DT01_DT"<=NVL(:B7,INTERNAL_FUNCTION("DT01_DT")) AND (NVL(:B11,'~~!!~~')='~~!!~~' OR CASE  WHEN NULL IS NULL THEN
              "IMX"."TRANSL_VALEUR"('MISC_TRANSLATIONS',"STR1",:B12) ELSE "IMX"."FTRANSLATE_STR"("STR1",:B12,NULL) END  LIKE '%'||:B11||'%')))
  62 - access("REFDOSS"=:B1 AND "TYPE"='TOTAL_CLAIM_CI')
  63 - filter((NVL(:B11,'~~!!~~')='~~!!~~' OR CASE  WHEN "ITEM_2" IS NULL THEN "IMX"."TRANSL_VALEUR"('MISC_TRANSLATIONS',"ITEM_1",:B12)
              ELSE "IMX"."FTRANSLATE_STR"("ITEM_1",:B12,"ITEM_2") END  LIKE '%'||:B11||'%'))
  65 - filter((:B3 IS NOT NULL AND  IS NULL AND  IS NULL))
  69 - filter(("T"."REFDOSS"=:B1 AND "T"."DTJOUR_DT">=NVL(:B10,INTERNAL_FUNCTION("T"."DTJOUR_DT")) AND
              "T"."DTJOUR_DT"<=NVL(:B9,INTERNAL_FUNCTION("T"."DTJOUR_DT")) AND "T"."DATECR_DT">=NVL(:B8,INTERNAL_FUNCTION("T"."DATECR_DT")) AND
              "T"."DATECR_DT"<=NVL(:B7,INTERNAL_FUNCTION("T"."DATECR_DT")) AND "T"."REFELEM"=NVL(:B6,"T"."REFELEM") AND
              "T"."TYPELEM"=NVL(:B5,"T"."TYPELEM") AND "T"."CODECR"=NVL(:B4,"T"."CODECR") AND "T"."CODECR"<>'PRIN' AND "T"."CODECR"<>'DPDB' AND
              "T"."CODECR"<>'RINCI' AND "T"."CODECR"<>'DPRIN' AND NVL(:B4,"T"."CODECR")<>'PRIN' AND NVL(:B4,"T"."CODECR")<>'DPDB' AND
              NVL(:B4,"T"."CODECR")<>'RINCI' AND NVL(:B4,"T"."CODECR")<>'DPRIN'))
  70 - access("T"."REFJOUR"=:B3)
       filter(("T"."REFJOUR">:B2 AND NVL(:B3,"T"."REFJOUR")=:B3))
  72 - access("T"."CODECR"="V"."CODECR")
       filter((INTERNAL_FUNCTION("V"."SOMME") AND "V"."CODECR"<>'PRIN' AND "V"."CODECR"<>'DPDB' AND "V"."CODECR"<>'RINCI' AND
              "V"."CODECR"<>'DPRIN'))
  73 - access("V"."CODECR"="VALEUR" AND "TYPE"='DV_ECRIT_CVT')
  74 - filter("V"."CODECR"="VALEUR_AN")
  75 - access("TYPE"='DV_ECRIT_CVT')
  76 - filter("VALEUR_AN" IS NULL)
  77 - access("TYPE"='DV_ECRIT_CVT')
  78 - access("VALEUR" IS NULL AND "TYPE"='DV_ECRIT_CVT')
       filter("TYPE"='DV_ECRIT_CVT')
  79 - filter(( IS NULL AND  IS NULL AND :B3 IS NULL))
  83 - filter(("T"."REFDOSS"=:B1 AND "T"."DTJOUR_DT">=NVL(:B10,INTERNAL_FUNCTION("T"."DTJOUR_DT")) AND
              "T"."DTJOUR_DT"<=NVL(:B9,INTERNAL_FUNCTION("T"."DTJOUR_DT")) AND "T"."DATECR_DT">=NVL(:B8,INTERNAL_FUNCTION("T"."DATECR_DT")) AND
              "T"."DATECR_DT"<=NVL(:B7,INTERNAL_FUNCTION("T"."DATECR_DT")) AND "T"."REFELEM"=NVL(:B6,"T"."REFELEM") AND
              "T"."TYPELEM"=NVL(:B5,"T"."TYPELEM") AND "T"."CODECR"=NVL(:B4,"T"."CODECR") AND "T"."CODECR"<>'PRIN' AND "T"."CODECR"<>'DPDB' AND
              "T"."CODECR"<>'RINCI' AND "T"."CODECR"<>'DPRIN' AND NVL(:B4,"T"."CODECR")<>'PRIN' AND NVL(:B4,"T"."CODECR")<>'DPDB' AND
              NVL(:B4,"T"."CODECR")<>'RINCI' AND NVL(:B4,"T"."CODECR")<>'DPRIN'))
  84 - access("T"."REFJOUR">:B2)
       filter("T"."REFJOUR"=NVL(:B3,"T"."REFJOUR"))
  86 - access("T"."CODECR"="V"."CODECR")
       filter((INTERNAL_FUNCTION("V"."SOMME") AND "V"."CODECR"<>'PRIN' AND "V"."CODECR"<>'DPDB' AND "V"."CODECR"<>'RINCI' AND
              "V"."CODECR"<>'DPRIN'))
  87 - access("V"."CODECR"="VALEUR" AND "TYPE"='DV_ECRIT_CVT')
  88 - filter("V"."CODECR"="VALEUR_AN")
  89 - access("TYPE"='DV_ECRIT_CVT')
  90 - filter("VALEUR_AN" IS NULL)
  91 - access("TYPE"='DV_ECRIT_CVT')
  92 - access("VALEUR" IS NULL AND "TYPE"='DV_ECRIT_CVT')
       filter("TYPE"='DV_ECRIT_CVT')

*/
/********************************OLD Metrics***************************************/

/********************************New SQL*******************************************/
SELECT  ELEMCTX,
       TYPETRAD,
       DTCPTMVT,
       DTGESTMVT,
       CODEMVT,
       REFMVT,
       TYPMVT,
       REFECRIT,
       MNTTOTAL,
       MNTCTX,
       COMPTEUR,
       MNTSOLDEDB,
       MNTIMMINENTFACT,
       MNTIMMINENTCL,
       MNTCAPITCVTFACT,
       MNTCAPITCVTCL,
       MNTCOURTCOSTSFACT,
       MNTCOURTCOSTSCL,
       MNTLAWYERCOSTSFACT,
       MNTLAWYERCOSTSCL,
       MNTNONAFF,
       AVAILFORALLOC,
       MNTINDARESEV,
       MNTINDREVERS,
       MNTREMBCHEZCI,
       MNTDISPO,
       0                  PROFIT_CL,
       0                  PROFIT_FACTOR,
       FLAGCVT,
       REFDOSS
  FROM (SELECT STR1 ELEMCTX,
               'REP' AS TYPETRAD,
               DT02_DT DTCPTMVT,
               DT01_DT DTGESTMVT,
               'REP' CODEMVT,
               REFELEM REFMVT,
               'r' TYPMVT,
               STR10 REFECRIT,
               MT01 MNTTOTAL,
               MT02 MNTCTX,
               'REPRISE' COMPTEUR,
               DECODE(STR1,
                      'REPRISE FRAIS REPETIBLES',
                      MT02,
                      'REPRISE FRAIS DIVERS DB',
                      MT02,
                      0) MNTSOLDEDB,
               0 MNTIMMINENTFACT,
               0 MNTIMMINENTCL,
               0 MNTCAPITCVTFACT,
               0 MNTCAPITCVTCL,
               MT03 MNTCOURTCOSTSFACT,
               MT04 MNTCOURTCOSTSCL,
               MT05 MNTLAWYERCOSTSFACT,
               MT06 MNTLAWYERCOSTSCL,
               0 MNTNONAFF,
               0 AVAILFORALLOC,
               MT07 MNTINDARESEV,
               MT08 MNTINDREVERS,
               0 MNTREMBCHEZCI,
               MT09 MNTDISPO,
               1 FLAGCVT,
               REFDOSS
          FROM G_ELEMFIDET
         WHERE REFDOSS = :B1
           AND TYPE = 'MVT_REPRISE'
        UNION ALL
        SELECT T.LIBELLE || E.STR1 || ' ' || F.REFEXT ELEMCTX,
               T.CODECR AS TYPETRAD,
               T.DTJOUR_DT DTCPTMVT,
               T.DATECR_DT DTGESTMVT,
               T.CODECR CODEMVT,
               T.REFELEM REFMVT,
               T.TYPELEM TYPMVT,
               NVL(T.REFJOUR, ' ') REFECRIT,
               T.DBDU_DOS MNTTOTAL,
               DECODE(T.CODECR,
                      'PRIN0',
                      E.MT10,
                      E.MT01 + E.MT02 + E.MT03 + E.MT04) MNTCTX,
               'PRINCIPAL' COMPTEUR,
               DECODE(T.CODECR,
                      'PRIN0',
                      E.MT10,
                      E.MT01 + E.MT02 + E.MT03 + E.MT04) MNTSOLDEDB,
               E.MT01 MNTIMMINENTFACT,
               E.MT02 MNTIMMINENTCL,
               E.MT03 MNTCAPITCVTFACT,
               E.MT04 MNTCAPITCVTCL,
               0 MNTCOURTCOSTSFACT,
               0 MNTCOURTCOSTSCL,
               0 MNTLAWYERCOSTSFACT,
               0 MNTLAWYERCOSTSCL,
               0 MNTNONAFF,
               0 AVAILFORALLOC,
               E.MT06 MNTINDARESEV,
               0 MNTINDREVERS,
               0 MNTREMBCHEZCI,
               0 MNTDISPO,
               1 FLAGCVT,
               E.REFDOSS REFDOSS
          FROM G_ELEMFIDET E, T_ECRDOS T, G_ELEMFI F
         WHERE T.CODECR IN ('PRIN', 'DPDB', 'PRIN0', 'DPRIN')
           AND T.REFDOSS = E.REFDOSS
           AND T.REFELEM = E.REFELEM
           AND F.REFELEM = E.REFELEM
           AND E.REFDOSS = :B1
           AND E.TYPE = 'PASS_FACT_CTX'
        UNION ALL
        SELECT MAX(E.STR1) ELEMCTX,
               'NMP' AS TYPETRAD,
               MAX(E.DT02_DT) DTCPTMVT,
               MAX(E.DT01_DT) DTGESTMVT,
               'NMP' CODEMVT,
               MAX(E.REFELEM) REFMVT,
               'e' TYPMVT,
               MAX(E.STR10) REFECRIT,
               MAX(E.MT01) MNTTOTAL,
               MAX(E.MT02) MNTCTX,
               'ACOMPT' COMPTEUR,
               -MAX(E.MT02) MNTSOLDEDB,
               NVL(SUM(T.PLDP9_DOS), 0) MNTIMMINENTFACT,
               NVL(SUM(T.PLDP12_DOS), 0) MNTIMMINENTCL,
               NVL(SUM(T.DBDU_DOS), 0) MNTCAPITCVTFACT,
               NVL(SUM(T.DBDEDUC_DOS), 0) MNTCAPITCVTCL,
               NVL(SUM(T.ETDBRSREM_DOS), 0) MNTCOURTCOSTSFACT,
               NVL(SUM(T.ETDEBRSDU_DOS), 0) MNTCOURTCOSTSCL,
               NVL(SUM(T.CLDU_DOS), 0) MNTLAWYERCOSTSFACT,
               NVL(SUM(T.CLRETRAIT_DOS), 0) MNTLAWYERCOSTSCL,
               MAX(E.MT02) + NVL(SUM(T.PLDP9_DOS), 0) +
               NVL(SUM(T.PLDP12_DOS), 0) +
               NVL(SUM(T.CLDEPOT_DOS + T.DBDEDUC_DOS), 0) MNTNONAFF,
               0 AVAILFORALLOC,
               0 MNTINDARESEV,
               0 MNTINDREVERS,
               0 MNTREMBCHEZCI,
               MAX(E.MT02) MNTDISPO,
               1 FLAGCVT,
               E.REFDOSS REFDOSS
          FROM G_ELEMFIDET E, T_ECRDOS T
         WHERE T.CODECR(+) = 'RCTX'
           AND T.REFDOSS(+) = E.REFDOSS
           AND T.REFELEM(+) = E.REFELEM
           AND E.REFDOSS = :B1
           AND E.TYPE = 'PASS_NMP_CTX'
         GROUP BY E.REFELEM, E.REFDOSS
        UNION ALL
        SELECT E.STR1 || ': ' || F.TYPE || ' ' || F.REFEXT ELEMCTX,
               'PUG' AS TYPETRAD,
               E.DT03_DT DTCPTMVT,
               E.DT03_DT DTGESTMVT,
               'PUG' CODEMVT,
               'x' REFMVT,
               'f' TYPMVT,
               E.STR10 REFECRIT,
               E.MT01 + E.MT02 MNTTOTAL,
               E.MT01 + E.MT02 MNTCTX,
               'PRINCIPAL' COMPTEUR,
               0 MNTSOLDEDB,
               -E.MT01 MNTIMMINENTFACT,
               -E.MT02 MNTIMMINENTCL,
               NVL(E.MT10, E.MT01) MNTCAPITCVTFACT,
               DECODE(E.MT10, NULL, E.MT02, E.MT01 + E.MT02 - E.MT10) MNTCAPITCVTCL,
               0 MNTCOURTCOSTSFACT,
               0 MNTCOURTCOSTSCL,
               0 MNTLAWYERCOSTSFACT,
               0 MNTLAWYERCOSTSCL,
               0 MNTNONAFF,
               0 AVAILFORALLOC,
               0 MNTINDARESEV,
               0 MNTINDREVERS,
               0 MNTREMBCHEZCI,
               0 MNTDISPO,
               1 FLAGCVT,
               E.REFDOSS REFDOSS
          FROM G_ELEMFIDET E, G_ELEMFI F
         WHERE F.REFELEM = E.REFELEM
           AND ABS(E.MT01 + E.MT02) > 0
           AND E.FG01 = 'O'
           AND NOT EXISTS (SELECT 1
                  FROM G_ELEMFIDET P
                 WHERE P.TYPE = 'PUG_FACTOR'
                   AND P.REFDOSS = :B1)
           AND E.REFDOSS = :B1
           AND E.TYPE = 'SOLDES_FACT_CTX'
        UNION ALL
        SELECT STR1 ELEMCTX,
               'PUG' AS TYPETRAD,
               DT01_DT DTCPTMVT,
               DT01_DT DTGESTMVT,
               'PUG' CODEMVT,
               'x' REFMVT,
               'f' TYPMVT,
               STR10 REFECRIT,
               E.MT03 + E.MT04 MNTTOTAL,
               E.MT03 + E.MT04 MNTCTX,
               'PRINCIPAL' COMPTEUR,
               0.0 MNTSOLDEDB,
               E.MT01 MNTIMMINENTFACT,
               E.MT02 MNTIMMINENTCL,
               E.MT03 MNTCAPITCVTFACT,
               E.MT04 MNTCAPITCVTCL,
               0 MNTCOURTCOSTSFACT,
               0 MNTCOURTCOSTSCL,
               0 MNTLAWYERCOSTSFACT,
               0 MNTLAWYERCOSTSCL,
               0 MNTNONAFF,
               0 AVAILFORALLOC,
               0 MNTINDARESEV,
               0 MNTINDREVERS,
               0 MNTREMBCHEZCI,
               0 MNTDISPO,
               1 FLAGCVT,
               E.REFDOSS REFDOSS
          FROM G_ELEMFIDET E
         WHERE E.REFDOSS = :B1
           AND E.TYPE = 'PUG_FACTOR'
        UNION ALL
        SELECT /*+ INDEX(t TECR_REFDOSS_DTJOUR) */
               T.LIBELLE ELEMCTX,
               T.CODECR TYPETRAD,
               T.DTJOUR_DT DTCPTMVT,
               T.DATECR_DT DTGESTMVT,
               T.CODECR CODEMVT,
               T.REFELEM REFMVT,
               T.TYPELEM TYPMVT,
               T.REFJOUR REFECRIT,
               GREATEST(ABS(T.DBDU_DOS), ABS(T.DBDEDUC_DOS)) MNTTOTAL,
               GREATEST(ABS(T.DBDU_DOS), ABS(T.DBDEDUC_DOS)) MNTCTX,
               'DISPO' COMPTEUR,
               0 MNTSOLDEDB,
               0 MNTIMMINENTFACT,
               0 MNTIMMINENTCL,
               0 MNTCAPITCVTFACT,
               0 MNTCAPITCVTCL,
               0 MNTCOURTCOSTSFACT,
               0 MNTCOURTCOSTSCL,
               0 MNTLAWYERCOSTSFACT,
               0 MNTLAWYERCOSTSCL,
               0 MNTNONAFF,
               0 AVAILFORALLOC,
               DBDU_DOS MNTINDARESEV,
               DBDEDUC_DOS MNTINDREVERS,
               0 MNTREMBCHEZCI,
               T.CLDEPOT_DOS MNTDISPO,
               1 FLAGCVT,
               T.REFDOSS REFDOSS
          FROM T_ECRDOS T
         WHERE T.CODECR = 'RINCI'
           AND NVL(T.REFJOUR, NULL) > :B2
           AND T.REFDOSS = :B1
        UNION ALL
        SELECT STR1 ELEMCTX,
               NULL TYPETRAD,
               DT02_DT DTCPTMVT,
               DT01_DT DTGESTMVT,
               'CLAIM' CODEMVT,
               'x' REFMVT,
               'f' TYPMVT,
               STR10 REFECRIT,
               0 MNTTOTAL,
               0 MNTCTX,
               'PRINCIPAL' COMPTEUR,
               0 MNTSOLDEDB,
               0 MNTIMMINENTFACT,
               0 MNTIMMINENTCL,
               0 MNTCAPITCVTFACT,
               0 MNTCAPITCVTCL,
               0 MNTCOURTCOSTSFACT,
               0 MNTCOURTCOSTSCL,
               0 MNTLAWYERCOSTSFACT,
               0 MNTLAWYERCOSTSCL,
               0 MNTNONAFF,
               0 AVAILFORALLOC,
               MT05 MNTINDARESEV,
               MT06 MNTINDREVERS,
               0 MNTREMBCHEZCI,
               MT07 MNTDISPO,
               1 FLAGCVT,
               REFDOSS
          FROM G_ELEMFIDET
         WHERE TYPE = 'TOTAL_CLAIM_CI'
           AND REFDOSS = :B1
        UNION ALL
        SELECT /*+ INDEX(t TECR_REFDOSS_DTJOUR) */
               T.LIBELLE ELEMCTX,
               T.CODECR TYPETRAD,
               T.DTJOUR_DT DTCPTMVT,
               T.DATECR_DT DTGESTMVT,
               T.CODECR CODEMVT,
               T.REFELEM REFMVT,
               T.TYPELEM TYPMVT,
               T.REFJOUR REFECRIT,
               DECODE(V.ELEMENT,
                      'dbdu',
                      T.DBDU_DOS,
                      'dbdeduc',
                      T.DBDEDUC_DOS,
                      'cldu',
                      T.CLDU_DOS,
                      'clretrait',
                      T.CLRETRAIT_DOS,
                      'cldepot',
                      T.CLDEPOT_DOS,
                      0) MNTTOTAL,
               DECODE(V.ELEMENT,
                      'dbdu',
                      T.DBDU_DOS,
                      'dbdeduc',
                      T.DBDEDUC_DOS,
                      'cldu',
                      T.CLDU_DOS,
                      'clretrait',
                      T.CLRETRAIT_DOS,
                      'cldepot',
                      T.CLDEPOT_DOS,
                      0) MNTCTX,
               V.SOMME COMPTEUR,
               0 MNTSOLDEDB,
               0 MNTIMMINENTFACT,
               0 MNTIMMINENTCL,
               DECODE(V.SOMME, 'PERTE', DBDU_DOS, 0) MNTCAPITCVTFACT,
               DECODE(V.SOMME, 'PERTE', DBDEDUC_DOS, 0) MNTCAPITCVTCL,
               DECODE(V.SOMME, 'PERTE', ETDBRSREM_DOS, 0) MNTCOURTCOSTSFACT,
               DECODE(V.SOMME, 'PERTE', ETDEBRSDU_DOS, 0) MNTCOURTCOSTSCL,
               DECODE(V.SOMME, 'PERTE', CLDU_DOS, 0) MNTLAWYERCOSTSFACT,
               DECODE(V.SOMME, 'PERTE', CLRETRAIT_DOS, 0) MNTLAWYERCOSTSCL,
               0 MNTNONAFF,
               0 AVAILFORALLOC,
               0 MNTINDARESEV,
               0 MNTINDREVERS,
               0 MNTREMBCHEZCI,
               0 MNTDISPO,
               0 FLAGCVT,
               T.REFDOSS REFDOSS
          FROM T_ECRDOS T, V_CALDOS V
         WHERE T.CODECR = V.CODECR
           AND V.CODECR NOT IN ('PRIN', 'DPDB', 'RINCI', 'DPRIN')
           AND V.CODECR NOT IN
               (SELECT VALEUR FROM V_DOMAINE WHERE TYPE = 'DV_ECRIT_CVT')
           AND V.CODECR NOT IN
               (SELECT VALEUR_AN FROM V_DOMAINE WHERE TYPE = 'DV_ECRIT_CVT')
           AND V.SOMME IN ('PRINCIPAL',
                           'TDEBS',
                           'UHONOR',
                           'FACDP',
                           'TTFRAI',
                           'THDEBS',
                           'ACOMPT',
                           'DISPO',
                           'TFRAI',
                           'PERTE',
                           'ZERODB')
           AND NVL(T.REFJOUR, NULL) > :B2
           AND T.REFDOSS = :B1)
 WHERE 1 = 1
   AND (NVL(:B11, '~~!!~~') = '~~!!~~' OR CASE
         WHEN TYPETRAD IS NULL THEN
          IMX.TRANSL_VALEUR('MISC_TRANSLATIONS', ELEMCTX, :B12)
         ELSE
          IMX.FTRANSLATE_STR(ELEMCTX, :B12, TYPETRAD)
       END LIKE '%' || :B11 || '%')
   AND DTCPTMVT BETWEEN NVL(:B10, DTCPTMVT) AND NVL(:B9, DTCPTMVT)
   AND DTGESTMVT BETWEEN NVL(:B8, DTGESTMVT) AND NVL(:B7, DTGESTMVT)
   AND REFMVT = NVL(:B6, REFMVT)
   AND TYPMVT = NVL(:B5, TYPMVT)
   AND CODEMVT = NVL(:B4, CODEMVT)
   AND REFECRIT = NVL(:B3, REFECRIT)
 ORDER BY REFECRIT, REFMVT;
/********************************New SQL*******************************************/
/********************************New Metrics***************************************/
/*
Plan hash value: 3284728182
---------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                     | Name                        | Starts | E-Rows | A-Rows |   A-Time   | Buffers |
---------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                              |                             |      1 |        |      2 |00:00:00.01 |      71 |
|   1 |  SORT ORDER BY                                |                             |      1 |     11 |      2 |00:00:00.01 |      71 |
|*  2 |   VIEW                                        |                             |      1 |     11 |      2 |00:00:00.01 |      71 |
|   3 |    UNION-ALL                                  |                             |      1 |        |      2 |00:00:00.01 |      71 |
|*  4 |     FILTER                                    |                             |      1 |        |      0 |00:00:00.01 |       4 |
|   5 |      VIEW                                     | VW_ORE_792AB197             |      1 |      2 |      0 |00:00:00.01 |       4 |
|   6 |       UNION-ALL                               |                             |      1 |        |      0 |00:00:00.01 |       4 |
|*  7 |        FILTER                                 |                             |      1 |        |      0 |00:00:00.01 |       0 |
|*  8 |         TABLE ACCESS BY INDEX ROWID BATCHED   | G_ELEMFIDET                 |      0 |      1 |      0 |00:00:00.01 |       0 |
|*  9 |          INDEX RANGE SCAN                     | EFIDET_REFELEM              |      0 |      1 |      0 |00:00:00.01 |       0 |
|* 10 |        FILTER                                 |                             |      1 |        |      0 |00:00:00.01 |       4 |
|* 11 |         TABLE ACCESS BY INDEX ROWID BATCHED   | G_ELEMFIDET                 |      1 |      1 |      0 |00:00:00.01 |       4 |
|* 12 |          INDEX RANGE SCAN                     | EFIDET_REFDOSS              |      1 |     25 |      0 |00:00:00.01 |       4 |
|  13 |     NESTED LOOPS                              |                             |      1 |      1 |      1 |00:00:00.01 |      14 |
|  14 |      NESTED LOOPS                             |                             |      1 |      2 |      1 |00:00:00.01 |      13 |
|  15 |       VIEW                                    | VW_JF_SET$7EC80C17          |      1 |      2 |      1 |00:00:00.01 |       9 |
|  16 |        UNION-ALL                              |                             |      1 |        |      1 |00:00:00.01 |       9 |
|* 17 |         FILTER                                |                             |      1 |        |      1 |00:00:00.01 |       9 |
|  18 |          NESTED LOOPS                         |                             |      1 |      1 |      1 |00:00:00.01 |       9 |
|  19 |           NESTED LOOPS                        |                             |      1 |      1 |      1 |00:00:00.01 |       8 |
|* 20 |            TABLE ACCESS BY INDEX ROWID BATCHED| T_ECRDOS                    |      1 |      1 |      1 |00:00:00.01 |       5 |
|* 21 |             INDEX RANGE SCAN                  | TECR_REFDOSS_DTJOUR         |      1 |      1 |      1 |00:00:00.01 |       4 |
|* 22 |            INDEX RANGE SCAN                   | EFIDET_REFELEM              |      1 |      1 |      1 |00:00:00.01 |       3 |
|* 23 |           TABLE ACCESS BY INDEX ROWID         | G_ELEMFIDET                 |      1 |      1 |      1 |00:00:00.01 |       1 |
|* 24 |         FILTER                                |                             |      1 |        |      0 |00:00:00.01 |       0 |
|  25 |          NESTED LOOPS                         |                             |      0 |      1 |      0 |00:00:00.01 |       0 |
|  26 |           NESTED LOOPS                        |                             |      0 |      1 |      0 |00:00:00.01 |       0 |
|* 27 |            TABLE ACCESS BY INDEX ROWID BATCHED| T_ECRDOS                    |      0 |      1 |      0 |00:00:00.01 |       0 |
|* 28 |             INDEX RANGE SCAN                  | TECR$REFDOSS_CODECR_DTINTER |      0 |      1 |      0 |00:00:00.01 |       0 |
|* 29 |            INDEX RANGE SCAN                   | EFIDET_REFELEM              |      0 |      1 |      0 |00:00:00.01 |       0 |
|* 30 |           TABLE ACCESS BY INDEX ROWID         | G_ELEMFIDET                 |      0 |      1 |      0 |00:00:00.01 |       0 |
|* 31 |       INDEX UNIQUE SCAN                       | EFI_REFELEM                 |      1 |      1 |      1 |00:00:00.01 |       4 |
|* 32 |      TABLE ACCESS BY INDEX ROWID              | G_ELEMFI                    |      1 |      1 |      1 |00:00:00.01 |       1 |
|* 33 |     FILTER                                    |                             |      1 |        |      0 |00:00:00.01 |       4 |
|  34 |      HASH GROUP BY                            |                             |      1 |      1 |      0 |00:00:00.01 |       4 |
|* 35 |       FILTER                                  |                             |      1 |        |      0 |00:00:00.01 |       4 |
|* 36 |        HASH JOIN OUTER                        |                             |      1 |     25 |      0 |00:00:00.01 |       4 |
|  37 |         TABLE ACCESS BY INDEX ROWID BATCHED   | G_ELEMFIDET                 |      1 |     25 |      0 |00:00:00.01 |       4 |
|* 38 |          INDEX RANGE SCAN                     | EFIDET_REFDOSS              |      1 |     25 |      0 |00:00:00.01 |       4 |
|  39 |         TABLE ACCESS BY INDEX ROWID BATCHED   | T_ECRDOS                    |      0 |      3 |      0 |00:00:00.01 |       0 |
|* 40 |          INDEX RANGE SCAN                     | TECR$REFDOSS_CODECR_DTINTER |      0 |      3 |      0 |00:00:00.01 |       0 |
|* 41 |     FILTER                                    |                             |      1 |        |      1 |00:00:00.01 |      14 |
|  42 |      NESTED LOOPS                             |                             |      1 |      1 |      1 |00:00:00.01 |      10 |
|  43 |       NESTED LOOPS                            |                             |      1 |      1 |      1 |00:00:00.01 |       9 |
|* 44 |        TABLE ACCESS BY INDEX ROWID BATCHED    | G_ELEMFIDET                 |      1 |      1 |      1 |00:00:00.01 |       5 |
|* 45 |         INDEX RANGE SCAN                      | EFIDET_REFDOSS              |      1 |     25 |      1 |00:00:00.01 |       4 |
|* 46 |        INDEX UNIQUE SCAN                      | EFI_REFELEM                 |      1 |      1 |      1 |00:00:00.01 |       4 |
|* 47 |       TABLE ACCESS BY INDEX ROWID             | G_ELEMFI                    |      1 |      1 |      1 |00:00:00.01 |       1 |
|* 48 |      INDEX RANGE SCAN                         | EFIDET_REFDOSS              |      1 |      2 |      0 |00:00:00.01 |       4 |
|* 49 |     FILTER                                    |                             |      1 |        |      0 |00:00:00.01 |       4 |
|* 50 |      TABLE ACCESS BY INDEX ROWID BATCHED      | G_ELEMFIDET                 |      1 |      1 |      0 |00:00:00.01 |       4 |
|* 51 |       INDEX RANGE SCAN                        | EFIDET_REFDOSS              |      1 |     25 |      0 |00:00:00.01 |       4 |
|  52 |     VIEW                                      | VW_ORE_6F90719D             |      1 |      2 |      0 |00:00:00.01 |       4 |
|  53 |      UNION-ALL                                |                             |      1 |        |      0 |00:00:00.01 |       4 |
|* 54 |       FILTER                                  |                             |      1 |        |      0 |00:00:00.01 |       0 |
|* 55 |        TABLE ACCESS BY INDEX ROWID BATCHED    | T_ECRDOS                    |      0 |      1 |      0 |00:00:00.01 |       0 |
|* 56 |         INDEX RANGE SCAN                      | TECR_REFDOSS_DTJOUR         |      0 |      1 |      0 |00:00:00.01 |       0 |
|* 57 |       FILTER                                  |                             |      1 |        |      0 |00:00:00.01 |       4 |
|* 58 |        TABLE ACCESS BY INDEX ROWID BATCHED    | T_ECRDOS                    |      1 |      1 |      0 |00:00:00.01 |       4 |
|* 59 |         INDEX RANGE SCAN                      | TECR_REFDOSS_DTJOUR         |      1 |      1 |      0 |00:00:00.01 |       4 |
|* 60 |     FILTER                                    |                             |      1 |        |      0 |00:00:00.01 |       4 |
|* 61 |      TABLE ACCESS BY INDEX ROWID BATCHED      | G_ELEMFIDET                 |      1 |      1 |      0 |00:00:00.01 |       4 |
|* 62 |       INDEX RANGE SCAN                        | EFIDET_REFDOSS              |      1 |      2 |      0 |00:00:00.01 |       4 |
|* 63 |     VIEW                                      | VW_ORE_D4815FD5             |      1 |      2 |      0 |00:00:00.01 |      23 |
|  64 |      UNION-ALL                                |                             |      1 |        |      0 |00:00:00.01 |      23 |
|* 65 |       FILTER                                  |                             |      1 |        |      0 |00:00:00.01 |       0 |
|  66 |        NESTED LOOPS ANTI SNA                  |                             |      0 |      1 |      0 |00:00:00.01 |       0 |
|  67 |         NESTED LOOPS ANTI SNA                 |                             |      0 |      1 |      0 |00:00:00.01 |       0 |
|  68 |          NESTED LOOPS                         |                             |      0 |      1 |      0 |00:00:00.01 |       0 |
|* 69 |           TABLE ACCESS BY INDEX ROWID BATCHED | T_ECRDOS                    |      0 |      1 |      0 |00:00:00.01 |       0 |
|* 70 |            INDEX RANGE SCAN                   | TECR_REFDOSS_DTJOUR         |      0 |    203 |      0 |00:00:00.01 |       0 |
|  71 |           TABLE ACCESS BY INDEX ROWID BATCHED | V_CALDOS                    |      0 |      1 |      0 |00:00:00.01 |       0 |
|* 72 |            INDEX RANGE SCAN                   | VCALDOS_SC                  |      0 |      1 |      0 |00:00:00.01 |       0 |
|* 73 |          INDEX RANGE SCAN                     | DOM_TYPVAL                  |      0 |     21 |      0 |00:00:00.01 |       0 |
|* 74 |         TABLE ACCESS BY INDEX ROWID BATCHED   | V_DOMAINE                   |      0 |     45 |      0 |00:00:00.01 |       0 |
|* 75 |          INDEX RANGE SCAN                     | V_DOMAINE_TYPE_CODE_IDX     |      0 |     45 |      0 |00:00:00.01 |       0 |
|* 76 |        TABLE ACCESS BY INDEX ROWID BATCHED    | V_DOMAINE                   |      0 |      1 |      0 |00:00:00.01 |       0 |
|* 77 |         INDEX RANGE SCAN                      | V_DOMAINE_TYPE_CODE_IDX     |      0 |     45 |      0 |00:00:00.01 |       0 |
|* 78 |        INDEX RANGE SCAN                       | DOM_TYPVAL                  |      0 |      1 |      0 |00:00:00.01 |       0 |
|* 79 |       FILTER                                  |                             |      1 |        |      0 |00:00:00.01 |      23 |
|  80 |        NESTED LOOPS ANTI SNA                  |                             |      1 |      1 |      0 |00:00:00.01 |      16 |
|  81 |         NESTED LOOPS ANTI SNA                 |                             |      1 |      1 |      0 |00:00:00.01 |      16 |
|  82 |          NESTED LOOPS                         |                             |      1 |      1 |      2 |00:00:00.01 |      10 |
|* 83 |           TABLE ACCESS BY INDEX ROWID BATCHED | T_ECRDOS                    |      1 |      1 |      2 |00:00:00.01 |       5 |
|* 84 |            INDEX RANGE SCAN                   | TECR_REFDOSS_DTJOUR         |      1 |    203 |      2 |00:00:00.01 |       4 |
|  85 |           TABLE ACCESS BY INDEX ROWID BATCHED | V_CALDOS                    |      2 |      1 |      2 |00:00:00.01 |       5 |
|* 86 |            INDEX RANGE SCAN                   | VCALDOS_SC                  |      2 |      1 |      2 |00:00:00.01 |       4 |
|* 87 |          INDEX RANGE SCAN                     | DOM_TYPVAL                  |      2 |     21 |      2 |00:00:00.01 |       6 |
|* 88 |         TABLE ACCESS BY INDEX ROWID BATCHED   | V_DOMAINE                   |      0 |     45 |      0 |00:00:00.01 |       0 |
|* 89 |          INDEX RANGE SCAN                     | V_DOMAINE_TYPE_CODE_IDX     |      0 |     45 |      0 |00:00:00.01 |       0 |
|* 90 |        TABLE ACCESS BY INDEX ROWID BATCHED    | V_DOMAINE                   |      1 |      1 |      0 |00:00:00.01 |       4 |
|* 91 |         INDEX RANGE SCAN                      | V_DOMAINE_TYPE_CODE_IDX     |      1 |     45 |      7 |00:00:00.01 |       2 |
|* 92 |        INDEX RANGE SCAN                       | DOM_TYPVAL                  |      1 |      1 |      0 |00:00:00.01 |       3 |
---------------------------------------------------------------------------------------------------------------------------------------

Predicate Information (identified by operation id):
---------------------------------------------------
   2 - filter(("DTCPTMVT">=NVL(:B10,INTERNAL_FUNCTION("DTCPTMVT")) AND "DTCPTMVT"<=NVL(:B9,INTERNAL_FUNCTION("DTCPTMVT")) AND
              "DTGESTMVT">=NVL(:B8,INTERNAL_FUNCTION("DTGESTMVT")) AND "DTGESTMVT"<=NVL(:B7,INTERNAL_FUNCTION("DTGESTMVT")) AND
              "REFMVT"=NVL(:B6,"REFMVT") AND "TYPMVT"=NVL(:B5,"TYPMVT") AND "CODEMVT"=NVL(:B4,"CODEMVT") AND "REFECRIT"=NVL(:B3,"REFECRIT")
              AND (NVL(:B11,'~~!!~~')='~~!!~~' OR CASE  WHEN "TYPETRAD" IS NULL THEN
              "IMX"."TRANSL_VALEUR"('MISC_TRANSLATIONS',"ELEMCTX",:B12) ELSE "IMX"."FTRANSLATE_STR"("ELEMCTX",:B12,"TYPETRAD") END  LIKE
              '%'||:B11||'%')))
   4 - filter(('r'=NVL(:B5,'r') AND 'REP'=NVL(:B4,'REP')))
   7 - filter((:B6 IS NOT NULL AND NVL(:B4,'REP')='REP' AND NVL(:B5,'r')='r'))
   8 - filter(("REFDOSS"=:B1 AND "STR10"=NVL(:B3,"STR10") AND "DT02_DT">=NVL(:B10,INTERNAL_FUNCTION("DT02_DT")) AND
              "DT02_DT"<=NVL(:B9,INTERNAL_FUNCTION("DT02_DT")) AND "DT01_DT">=NVL(:B8,INTERNAL_FUNCTION("DT01_DT")) AND
              "DT01_DT"<=NVL(:B7,INTERNAL_FUNCTION("DT01_DT")) AND (NVL(:B11,'~~!!~~')='~~!!~~' OR CASE  WHEN 'REP' IS NULL THEN
              "IMX"."TRANSL_VALEUR"('MISC_TRANSLATIONS',"STR1",:B12) ELSE "IMX"."FTRANSLATE_STR"("STR1",:B12,'REP') END  LIKE
              '%'||:B11||'%')))
   9 - access("REFELEM"=:B6 AND "TYPE"='MVT_REPRISE')
       filter(NVL(:B6,"REFELEM")=:B6)
  10 - filter((NVL(:B4,'REP')='REP' AND NVL(:B5,'r')='r' AND :B6 IS NULL))
  11 - filter(("STR10"=NVL(:B3,"STR10") AND "DT02_DT">=NVL(:B10,INTERNAL_FUNCTION("DT02_DT")) AND
              "DT02_DT"<=NVL(:B9,INTERNAL_FUNCTION("DT02_DT")) AND "DT01_DT">=NVL(:B8,INTERNAL_FUNCTION("DT01_DT")) AND
              "DT01_DT"<=NVL(:B7,INTERNAL_FUNCTION("DT01_DT")) AND (NVL(:B11,'~~!!~~')='~~!!~~' OR CASE  WHEN 'REP' IS NULL THEN
              "IMX"."TRANSL_VALEUR"('MISC_TRANSLATIONS',"STR1",:B12) ELSE "IMX"."FTRANSLATE_STR"("STR1",:B12,'REP') END  LIKE
              '%'||:B11||'%') AND "REFELEM" IS NOT NULL AND "REFELEM"=NVL(:B6,"REFELEM")))
  12 - access("REFDOSS"=:B1 AND "TYPE"='MVT_REPRISE')
  17 - filter(:B4 IS NULL)
  20 - filter((NVL("T"."REFJOUR",' ')=NVL(:B3,NVL("T"."REFJOUR",' ')) AND
              "T"."DATECR_DT"<=NVL(:B7,INTERNAL_FUNCTION("T"."DATECR_DT")) AND "T"."DATECR_DT">=NVL(:B8,INTERNAL_FUNCTION("T"."DATECR_DT"))
              AND "T"."DTJOUR_DT"<=NVL(:B9,INTERNAL_FUNCTION("T"."DTJOUR_DT")) AND
              "T"."DTJOUR_DT">=NVL(:B10,INTERNAL_FUNCTION("T"."DTJOUR_DT")) AND "T"."REFELEM"=NVL(:B6,"T"."REFELEM") AND
              "T"."TYPELEM"=NVL(:B5,"T"."TYPELEM")))
  21 - access("T"."REFDOSS"=:B1)
       filter((INTERNAL_FUNCTION("T"."CODECR") AND (NVL(:B4,"T"."CODECR")='DPDB' OR NVL(:B4,"T"."CODECR")='DPRIN' OR
              NVL(:B4,"T"."CODECR")='PRIN' OR NVL(:B4,"T"."CODECR")='PRIN0') AND "T"."CODECR"=NVL(:B4,"T"."CODECR")))
  22 - access("T"."REFELEM"="E"."REFELEM" AND "E"."TYPE"='PASS_FACT_CTX')
  23 - filter("E"."REFDOSS"=:B1)
  24 - filter((:B4 IS NOT NULL AND ('DPDB'=:B4 OR 'DPRIN'=:B4 OR 'PRIN'=:B4 OR 'PRIN0'=:B4)))
  27 - filter((NVL("T"."REFJOUR",' ')=NVL(:B3,NVL("T"."REFJOUR",' ')) AND
              "T"."DATECR_DT"<=NVL(:B7,INTERNAL_FUNCTION("T"."DATECR_DT")) AND "T"."DATECR_DT">=NVL(:B8,INTERNAL_FUNCTION("T"."DATECR_DT"))
              AND "T"."DTJOUR_DT"<=NVL(:B9,INTERNAL_FUNCTION("T"."DTJOUR_DT")) AND
              "T"."DTJOUR_DT">=NVL(:B10,INTERNAL_FUNCTION("T"."DTJOUR_DT")) AND "T"."REFELEM"=NVL(:B6,"T"."REFELEM") AND
              "T"."TYPELEM"=NVL(:B5,"T"."TYPELEM")))
  28 - access("T"."REFDOSS"=:B1 AND "T"."CODECR"=:B4)
       filter((INTERNAL_FUNCTION("T"."CODECR") AND NVL(:B4,"T"."CODECR")=:B4 AND (NVL(:B4,"T"."CODECR")='DPDB' OR
              NVL(:B4,"T"."CODECR")='DPRIN' OR NVL(:B4,"T"."CODECR")='PRIN' OR NVL(:B4,"T"."CODECR")='PRIN0')))
  29 - access("T"."REFELEM"="E"."REFELEM" AND "E"."TYPE"='PASS_FACT_CTX')
  30 - filter("E"."REFDOSS"=:B1)
  31 - access("F"."REFELEM"="ITEM_1")
  32 - filter((NVL(:B11,'~~!!~~')='~~!!~~' OR CASE  WHEN "ITEM_4" IS NULL THEN
              "IMX"."TRANSL_VALEUR"('MISC_TRANSLATIONS',"ITEM_2"||"ITEM_3"||' '||"F"."REFEXT",:B12) ELSE
              "IMX"."FTRANSLATE_STR"("ITEM_2"||"ITEM_3"||' '||"F"."REFEXT",:B12,"ITEM_4") END  LIKE '%'||:B11||'%'))
  33 - filter((MAX("E"."DT02_DT")>=NVL(:B10,MAX("E"."DT02_DT")) AND MAX("E"."DT02_DT")<=NVL(:B9,MAX("E"."DT02_DT")) AND
              MAX("E"."DT01_DT")>=NVL(:B8,MAX("E"."DT01_DT")) AND MAX("E"."DT01_DT")<=NVL(:B7,MAX("E"."DT01_DT")) AND
              MAX("E"."REFELEM")=NVL(:B6,MAX("E"."REFELEM")) AND MAX("E"."STR10")=NVL(:B3,MAX("E"."STR10")) AND (NVL(:B11,'~~!!~~')='~~!!~~'
              OR CASE  WHEN 'NMP' IS NULL THEN "IMX"."TRANSL_VALEUR"('MISC_TRANSLATIONS',MAX("E"."STR1"),:B12) ELSE
              "IMX"."FTRANSLATE_STR"(MAX("E"."STR1"),:B12,'NMP') END  LIKE '%'||:B11||'%') AND MAX("E"."STR10")=NVL(:B3,MAX("E"."STR10"))
              AND MAX("E"."REFELEM")=NVL(:B6,MAX("E"."REFELEM")) AND MAX("E"."DT01_DT")<=NVL(:B7,MAX("E"."DT01_DT")) AND
              MAX("E"."DT01_DT")>=NVL(:B8,MAX("E"."DT01_DT")) AND MAX("E"."DT02_DT")<=NVL(:B9,MAX("E"."DT02_DT")) AND
              MAX("E"."DT02_DT")>=NVL(:B10,MAX("E"."DT02_DT"))))
  35 - filter((NVL(:B4,'NMP')='NMP' AND NVL(:B5,'e')='e'))
  36 - access("T"."REFDOSS"="E"."REFDOSS" AND "T"."REFELEM"="E"."REFELEM")
  38 - access("E"."REFDOSS"=:B1 AND "E"."TYPE"='PASS_NMP_CTX')
  40 - access("T"."REFDOSS"=:B1 AND "T"."CODECR"='RCTX')
  41 - filter((NVL(:B4,'PUG')='PUG' AND NVL(:B5,'f')='f' AND NVL(:B6,'x')='x' AND  IS NULL))
  44 - filter(("E"."FG01"='O' AND ABS("E"."MT01"+"E"."MT02")>0 AND "E"."STR10"=NVL(:B3,"E"."STR10") AND
              "E"."DT03_DT">=NVL(:B10,INTERNAL_FUNCTION("E"."DT03_DT")) AND "E"."DT03_DT"<=NVL(:B9,INTERNAL_FUNCTION("E"."DT03_DT")) AND
              "E"."DT03_DT">=NVL(:B8,INTERNAL_FUNCTION("E"."DT03_DT")) AND "E"."DT03_DT"<=NVL(:B7,INTERNAL_FUNCTION("E"."DT03_DT"))))
  45 - access("E"."REFDOSS"=:B1 AND "E"."TYPE"='SOLDES_FACT_CTX')
  46 - access("F"."REFELEM"="E"."REFELEM")
  47 - filter((NVL(:B11,'~~!!~~')='~~!!~~' OR CASE  WHEN 'PUG' IS NULL THEN
              "IMX"."TRANSL_VALEUR"('MISC_TRANSLATIONS',"E"."STR1"||': '||"F"."TYPE"||' '||"F"."REFEXT",:B12) ELSE
              "IMX"."FTRANSLATE_STR"("E"."STR1"||': '||"F"."TYPE"||' '||"F"."REFEXT",:B12,'PUG') END  LIKE '%'||:B11||'%'))
  48 - access("P"."REFDOSS"=:B1 AND "P"."TYPE"='PUG_FACTOR')
  49 - filter((NVL(:B4,'PUG')='PUG' AND NVL(:B5,'f')='f' AND NVL(:B6,'x')='x'))
  50 - filter(("STR10"=NVL(:B3,"STR10") AND "DT01_DT">=NVL(:B10,INTERNAL_FUNCTION("DT01_DT")) AND
              "DT01_DT"<=NVL(:B9,INTERNAL_FUNCTION("DT01_DT")) AND "DT01_DT">=NVL(:B8,INTERNAL_FUNCTION("DT01_DT")) AND
              "DT01_DT"<=NVL(:B7,INTERNAL_FUNCTION("DT01_DT")) AND (NVL(:B11,'~~!!~~')='~~!!~~' OR CASE  WHEN 'PUG' IS NULL THEN
              "IMX"."TRANSL_VALEUR"('MISC_TRANSLATIONS',"STR1",:B12) ELSE "IMX"."FTRANSLATE_STR"("STR1",:B12,'PUG') END  LIKE
              '%'||:B11||'%')))
  51 - access("E"."REFDOSS"=:B1 AND "E"."TYPE"='PUG_FACTOR')
  54 - filter(:B3 IS NOT NULL)
  55 - filter(("T"."REFJOUR"=:B3 AND "T"."REFJOUR">:B2 AND NVL(:B3,"T"."REFJOUR")=:B3 AND
              "T"."DTJOUR_DT">=NVL(:B10,INTERNAL_FUNCTION("T"."DTJOUR_DT")) AND "T"."DTJOUR_DT"<=NVL(:B9,INTERNAL_FUNCTION("T"."DTJOUR_DT"))
              AND "T"."DATECR_DT">=NVL(:B8,INTERNAL_FUNCTION("T"."DATECR_DT")) AND
              "T"."DATECR_DT"<=NVL(:B7,INTERNAL_FUNCTION("T"."DATECR_DT")) AND (NVL(:B11,'~~!!~~')='~~!!~~' OR CASE  WHEN "T"."CODECR" IS
              NULL THEN "IMX"."TRANSL_VALEUR"('MISC_TRANSLATIONS',"T"."LIBELLE",:B12) ELSE
              "IMX"."FTRANSLATE_STR"("T"."LIBELLE",:B12,"T"."CODECR") END  LIKE '%'||:B11||'%') AND "T"."REFELEM"=NVL(:B6,"T"."REFELEM") AND
              "T"."TYPELEM"=NVL(:B5,"T"."TYPELEM")))
  56 - access("T"."REFDOSS"=:B1 AND "T"."CODECR"='RINCI')
       filter(("T"."CODECR"='RINCI' AND NVL(:B4,"T"."CODECR")='RINCI'))
  57 - filter(:B3 IS NULL)
  58 - filter(("T"."REFJOUR">:B2 AND "T"."DTJOUR_DT">=NVL(:B10,INTERNAL_FUNCTION("T"."DTJOUR_DT")) AND
              "T"."DTJOUR_DT"<=NVL(:B9,INTERNAL_FUNCTION("T"."DTJOUR_DT")) AND "T"."DATECR_DT">=NVL(:B8,INTERNAL_FUNCTION("T"."DATECR_DT"))
              AND "T"."DATECR_DT"<=NVL(:B7,INTERNAL_FUNCTION("T"."DATECR_DT")) AND (NVL(:B11,'~~!!~~')='~~!!~~' OR CASE  WHEN "T"."CODECR"
              IS NULL THEN "IMX"."TRANSL_VALEUR"('MISC_TRANSLATIONS',"T"."LIBELLE",:B12) ELSE
              "IMX"."FTRANSLATE_STR"("T"."LIBELLE",:B12,"T"."CODECR") END  LIKE '%'||:B11||'%') AND "T"."REFJOUR"=NVL(:B3,"T"."REFJOUR") AND
              "T"."REFELEM"=NVL(:B6,"T"."REFELEM") AND "T"."TYPELEM"=NVL(:B5,"T"."TYPELEM")))
  59 - access("T"."REFDOSS"=:B1 AND "T"."CODECR"='RINCI')
       filter(("T"."CODECR"='RINCI' AND NVL(:B4,"T"."CODECR")='RINCI'))
  60 - filter((NVL(:B4,'CLAIM')='CLAIM' AND NVL(:B5,'f')='f' AND NVL(:B6,'x')='x'))
  61 - filter(("STR10"=NVL(:B3,"STR10") AND "DT02_DT">=NVL(:B10,INTERNAL_FUNCTION("DT02_DT")) AND
              "DT02_DT"<=NVL(:B9,INTERNAL_FUNCTION("DT02_DT")) AND "DT01_DT">=NVL(:B8,INTERNAL_FUNCTION("DT01_DT")) AND
              "DT01_DT"<=NVL(:B7,INTERNAL_FUNCTION("DT01_DT")) AND (NVL(:B11,'~~!!~~')='~~!!~~' OR CASE  WHEN NULL IS NULL THEN
              "IMX"."TRANSL_VALEUR"('MISC_TRANSLATIONS',"STR1",:B12) ELSE "IMX"."FTRANSLATE_STR"("STR1",:B12,NULL) END  LIKE
              '%'||:B11||'%')))
  62 - access("REFDOSS"=:B1 AND "TYPE"='TOTAL_CLAIM_CI')
  63 - filter((NVL(:B11,'~~!!~~')='~~!!~~' OR CASE  WHEN "ITEM_2" IS NULL THEN
              "IMX"."TRANSL_VALEUR"('MISC_TRANSLATIONS',"ITEM_1",:B12) ELSE "IMX"."FTRANSLATE_STR"("ITEM_1",:B12,"ITEM_2") END  LIKE
              '%'||:B11||'%'))
  65 - filter((:B3 IS NOT NULL AND  IS NULL AND  IS NULL))
  69 - filter(("T"."REFJOUR"=:B3 AND "T"."REFJOUR">:B2 AND NVL(:B3,"T"."REFJOUR")=:B3 AND
              "T"."DTJOUR_DT">=NVL(:B10,INTERNAL_FUNCTION("T"."DTJOUR_DT")) AND "T"."DTJOUR_DT"<=NVL(:B9,INTERNAL_FUNCTION("T"."DTJOUR_DT"))
              AND "T"."DATECR_DT">=NVL(:B8,INTERNAL_FUNCTION("T"."DATECR_DT")) AND
              "T"."DATECR_DT"<=NVL(:B7,INTERNAL_FUNCTION("T"."DATECR_DT")) AND "T"."REFELEM"=NVL(:B6,"T"."REFELEM") AND
              "T"."TYPELEM"=NVL(:B5,"T"."TYPELEM")))
  70 - access("T"."REFDOSS"=:B1)
       filter(("T"."CODECR"=NVL(:B4,"T"."CODECR") AND "T"."CODECR"<>'PRIN' AND "T"."CODECR"<>'DPDB' AND "T"."CODECR"<>'RINCI'
              AND "T"."CODECR"<>'DPRIN' AND NVL(:B4,"T"."CODECR")<>'PRIN' AND NVL(:B4,"T"."CODECR")<>'DPDB' AND
              NVL(:B4,"T"."CODECR")<>'RINCI' AND NVL(:B4,"T"."CODECR")<>'DPRIN'))
  72 - access("T"."CODECR"="V"."CODECR")
       filter((INTERNAL_FUNCTION("V"."SOMME") AND "V"."CODECR"<>'PRIN' AND "V"."CODECR"<>'DPDB' AND "V"."CODECR"<>'RINCI' AND
              "V"."CODECR"<>'DPRIN'))
  73 - access("V"."CODECR"="VALEUR" AND "TYPE"='DV_ECRIT_CVT')
  74 - filter("V"."CODECR"="VALEUR_AN")
  75 - access("TYPE"='DV_ECRIT_CVT')
  76 - filter("VALEUR_AN" IS NULL)
  77 - access("TYPE"='DV_ECRIT_CVT')
  78 - access("VALEUR" IS NULL AND "TYPE"='DV_ECRIT_CVT')
       filter("TYPE"='DV_ECRIT_CVT')
  79 - filter(( IS NULL AND  IS NULL AND :B3 IS NULL))
  83 - filter(("T"."REFJOUR">:B2 AND "T"."DTJOUR_DT">=NVL(:B10,INTERNAL_FUNCTION("T"."DTJOUR_DT")) AND
              "T"."DTJOUR_DT"<=NVL(:B9,INTERNAL_FUNCTION("T"."DTJOUR_DT")) AND "T"."DATECR_DT">=NVL(:B8,INTERNAL_FUNCTION("T"."DATECR_DT"))
              AND "T"."DATECR_DT"<=NVL(:B7,INTERNAL_FUNCTION("T"."DATECR_DT")) AND "T"."REFJOUR"=NVL(:B3,"T"."REFJOUR") AND
              "T"."REFELEM"=NVL(:B6,"T"."REFELEM") AND "T"."TYPELEM"=NVL(:B5,"T"."TYPELEM")))
  84 - access("T"."REFDOSS"=:B1)
       filter(("T"."CODECR"=NVL(:B4,"T"."CODECR") AND "T"."CODECR"<>'PRIN' AND "T"."CODECR"<>'DPDB' AND "T"."CODECR"<>'RINCI'
              AND "T"."CODECR"<>'DPRIN' AND NVL(:B4,"T"."CODECR")<>'PRIN' AND NVL(:B4,"T"."CODECR")<>'DPDB' AND
              NVL(:B4,"T"."CODECR")<>'RINCI' AND NVL(:B4,"T"."CODECR")<>'DPRIN'))
  86 - access("T"."CODECR"="V"."CODECR")
       filter((INTERNAL_FUNCTION("V"."SOMME") AND "V"."CODECR"<>'PRIN' AND "V"."CODECR"<>'DPDB' AND "V"."CODECR"<>'RINCI' AND
              "V"."CODECR"<>'DPRIN'))
  87 - access("V"."CODECR"="VALEUR" AND "TYPE"='DV_ECRIT_CVT')
  88 - filter("V"."CODECR"="VALEUR_AN")
  89 - access("TYPE"='DV_ECRIT_CVT')
  90 - filter("VALEUR_AN" IS NULL)
  91 - access("TYPE"='DV_ECRIT_CVT')
  92 - access("VALEUR" IS NULL AND "TYPE"='DV_ECRIT_CVT')
       filter("TYPE"='DV_ECRIT_CVT')
*/
/********************************New Metrics***************************************/

/********************************Index statistics**********************************/

/********************************Other SQLs****************************************/          
/*

*/ 
/********************************Other SQLs****************************************/              
