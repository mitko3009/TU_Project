              LINUX FUNDAMENTALS TRAINING
-----------------------------------------------------------
cd            (връща те началната директория)
cd -          (връща те в предишната директория в която сме били)
cd ..
cd ../..      (връща две директории назад)
cd ~          (връща те в хома на юзъра) или cd ~ име_юзър
cd /          (влиза в root директорията)
cd /bin       (отива в дир.bin независимо къде се намираме в момента
cd ./1/2/3    (релативен път до 3)
cd /opt/1/2/3 (спрямо Root-а абсолютен път до 3)
ls -la        (Показва всички фаилове в дадена дир. + скритите)
ls -l ~       (показва всичко в ~ )
ls -ali       (вади списък с линковете на inod-a)
ls -ld        (Показва инфо за директорията ,прав аи т.н.)
ls -lh        (Показва всичко в дир. в human readable format
pwd           (показва директорията,в която сме в момента,рекативен път)
df -h         (Показва инфо за системата колко е запълнена)
du -h
whoami        (Показва инфо за юзъра)    root
who am i      (info за юзъра)     root     pts/0        2019-03-03 01:08 (192.168.178.1)
w    (много подробна инфо за юзъра )      01:17:27 up  9:56,  2 users,  load average: 0.01, 0.02, 0.05
                                        USER     TTY      FROM             LOGIN@   IDLE   JCPU   PCPU WHAT
                                        root     pts/0    192.168.178.1    01:08    7.00s  0.04s  0.00s w
                                        root     pts/1    192.168.178.1    Fri03   44:12m  0.05s  0.05s -bash

id           (дава инфо за юзъра)

vi Или vim   име_файл   (отваря файл в текстов редактор)
mount                   (дава инфо за файловите системи,които са закачени към диска)
cat /proc/mount         (Прави същото като mount)
df                  (показва инфо за мястото на диска,гледа в мета данните.Ако файла е изтрит докато процес го ползва Inode-а му остава и df продължава
                      да мисли,че мястото е заето,а то не е......Работи на база цялата файлова система)
du                  (Показва инфо за мястото на диска,ходи директно по директория и гледа какво има вътре.Може да се пусне за една директория или за 
                     цяла файлова система)
ln  име_файл  нов_име_файл  (прави хард линк с ново име)
in -s пътя до файла,който искаме да референцираме/пътя където искаме да сложим линка     (прави символинк линк)
more символик линка     (ще прочете файла)
ln –s <file> <new soft_link of file>

useradd - creating users
useradd -m -d /home/hpedu -c "HPEdu comment" hpedu     (за добавяне на юзър)
usermod  - modifying users
usermod -g             (сменяме Primary group name)
usermod -G             (слагаме secondary group На юзъра)
userdel   name_user    (трием юзър)
/etc/passwd            (там сазаписани всички акаунти)
/etc/shadow            (Там са криптирани паролите на вс юзъри.Може само root да го чете)
passwd name_user       (Сетваме парола на дадения юзър)
chage -l name_user     (показва инфо кога изтича паролата на юзъра и кога е сменяна)
chage -d 0 user_name    (форсва юзъра да си сменя паролата след първия логин)
su -                    (суитчваме се като юзър)

groupadd <groupname> - creates group
groupdel <groupname> - deletes group
usermod -a -G <groups..><username> - adds secondary groups to existing user_name
usermod -g <group><username> - change user primary group

chmod g+wr something    (сменя правата на файла something ,за групата)
Chmod g-rw something    (Премахва тези права за групана на файла)
chmod 777 something     (слага тези права за файла)
chmod -R <mode><file>/<directory>     същото
chmod u=rwx,g=,o=rx file 
chmod -R 744 directory1
chmod u+s <filename>     (когато се изпълни файла ще се изпълни с юзър Id-То на този,който го е създал,а не на този,който е логнат в система)
chmod 4655 <filename>     (същото като chmod u+s само,че на бинарни файлове)
chmod g+s <filename>/<directory>     (при създаване на файла няма да вземе групата на този,който го създава ,а на директорията в която се създава
                                     файла.Ако се изпълни файла ще има права на групата....)
chmod 2755 <filename>/<directory>    (същото като при chmod g+s само,че за бинарни файлове)
chmod +t <dirctory>       (стики бит Sticky-bit/save text bit.Когато се сетне за дадена директория,само който притежава файла в тази дир.може да го изтрие)
chmod 1755 <directory>     (прави същото като chmod +t)		
chgrp root име_файл        (сменя групата на файла на root)
chown root име_файл        (сменя оунъра на файла на root)
chown root:izabela         (смена оунъра на root  и групата на izabel
ls -l – list files
ls -ld – list directory
chgrp <new group> <file> - change group
chown <new owner> <file> - change owner

umask -S                   (показва какви са ни дефолтните права когато създаваме)
getfacl                    (показва какво има в acl access control lists)
getfacl <file>/dirctory> - get file access control lists
setfacl -m u:izabela:rwx acl.txt  (Дибавя юзър в acl за файла acl.txt.Автоматично слага плюсче,ако има вече друг юзър,който има достъп до този файл)
setfacl -x u:izabela acl.txt      (Маха юзъра от ацл-а за този файл)

chmod g+wr something    (сменя правата на файла something ,за групата)
Chmod g-rw something    (Премахва тези права за групана на файла)
chmod 777 something     (слага тези права за файла)
chmod -R <mode><file>/<directory>     същото
chmod u=rwx,g=,o=rx file 
chmod -R 744 directory1
chmod u+s <filename>     (когато се изпълни файла ще се изпълни с юзър Id-То на този,който го е създал,а не на този,който е логнат в система)
chmod 4655 <filename>     (същото като chmod u+s само,че на бинарни файлове)
chmod g+s <filename>/<directory>     (при създаване на файла няма да вземе групата на този,който го създава ,а на директорията в която се създава
                                     файла.Ако се изпълни файла ще има права на групата....)
chmod 2755 <filename>/<directory>    (същото като при chmod g+s само,че за бинарни файлове)
chmod +t <dirctory>       (стики бит Sticky-bit/save text bit.Когато се сетне за дадена директория,само който притежава файла в тази дир.може да го изтрие)
chmod 1755 <directory>     (прави същото като chmod +t)		
chgrp root име_файл        (сменя групата на файла на root)
chown root име_файл        (сменя оунъра на файла на root)
chown root:izabela         (смена оунъра на root  и групата на izabel
umask -S                   (показва какви са ни дефолтните права когато създаваме)
getfacl                    (показва какво има в acl access control lists)
setfacl -m u:izabela:rwx acl.txt  (Дибавя юзър в acl за файла acl.txt.Автоматично слага плюсче,ако има вече друг юзър,който има достъп до този файл)
setfacl -x u:izabela acl.txt      (Маха юзъра от ацл-а за този файл)

mkdir  - създаваш директория
mkdir -p
rmdir   - премахваш директория
rmdir -p

touch 	   		- create
rm [-rfi] <filename> 	- delete
cp [-pr]  <src> <dst>	- copy
mv	 <src> <dst>	- move/rename

tac <file>
wc <file>

uptime – shows how long the system has been running



   SHELL,INPUT/OUTPUT,PIPES,REDIRECTS
--------------------------------------------------------------------
  Asterisk (*) wildcard - this can represent any number of characters
	[root@hpedu ~]# ls /dev/sd*
	/dev/sda  /dev/sda1  /dev/sda2  /dev/sdb
Question mark (?) wildcard - this can represent any single character
	[root@hpedu ~]# ls /dev/sd?
	/dev/sda  /dev/sdb
Aliases 
	[root@hpedu ~]# alias u=uptime
	[root@hpedu ~]# u
 	19:46:25 up  4:30,  2 users,  load average: 0.00, 0.01, 0.05
Escape character (\)
	[root@hpedu ~]# echo a\{d,c,b\}e
	a{d,c,b}e
 
The current directory where you currently are is always referred as ./   
The root filesystem is referred as / 
The directory one level up is referred as ../  so if we are in /etc/sysconfig/network-scripts/ and we wish to go to /etc, we can do that by:
[root@hpedu network-scripts]# cd ../../
[root@hpedu etc]#
 
 !! - repeats the last command
 
 stin - 0  -standart input
 stdout -1 -standart output
 stderr - 2 -standart error
 
 ls -l file_name 2>/dev/null  (Праща грешките в /dev/null и не ги плюе)
ll file.txt file222 2>errors.txt    (Така ще запише резултата във файла.Същото може да се прави и с outputa,ако вместо 2 сложим 1.Ако файла,в който ще пише не съществува ще си го създаде)
cat install.log1 > new_file.txt 2>&1   (Така пренасочваме output_а към фаила new_file и грешките към output-а и така ще пише в един файл)
sort < file_list.txt          (като изпълни командата ще върне това,което е във файла)
sort <file_list.txt > sorted_file_list.txt   (сортира инфото от единия файл и записва резултата в другия.По дифолт ги подрежда по азбучен ред)
sar -f sa12 | sort -k8 | head-sar   (Командата показва перформанс на системата.sa12 казва,че иска за 12-ти да даде инфо,sort -k8 казва да сортира по 8-ма колона,head казва първите 10 реда да покаже)
sort -r                     (показва отзад напред(обръща посоката на реда ,в който показва резултата)
set                        (показва всички променливи в системата)
$PATH                      (Показва пътя до екзекютабъл файловете)
PATH="$PATH:/root/test"    (Добавя папка test в списъка с папки,в който има ексекютабъл файлове и файловете,които са вътре и може да се изпълнят ще се листват като команди в цялата система.Трябва фаила да му дадем x права за да може да се изпълни.Само докато сесията е активна работи.Ако искаме да остане постоянно се пише в конф. файл)

Redirecting stdout
--------------------
If we need to save the output of a command into a file, or the output is not needed at all, it can be redirected to a file or to the /dev/null device.
[root@hpedu ~]# cat install.log1 > new_file.txt
cat: install.log1: No such file or directory	---> stderr

Redirecting stdout and stderr
------------------------------
If we want to redirect both errors and output:
[root@hpedu ~]# cat install.log1 > new_file.txt 2>&1		
The 2>&1construct redirects stderr (2) to the same place stdout (1) is redirected.
The same thing can be accomplished in different ways, all are equivalent:

	cat install.log1 > new_file.txt 2>&1
	cat install.log1 2> new_file.txt 1>&2
	cat install.log1 &> new_file.txt	-> non-POSIX
	cat install.log1 >& new_file.txt	-> non-POSIX

If you want to empty a file (also called “truncate a file”), you can do:
	[root@hpedu ~]# > newfile.txt

Redirecting stdin
------------------------
The input to a command can also be redirected. This is very convenient when we need to pass a a lot of lines to the standard input. 
[root@hpedu ~]# sort < file_list.txt

whereis + command-a        (показва къде сенамира командата
which + command-a          (Показва къде се намира командата)
ls | grep ^d               (Изкарва всички файлове,които започват с d. ^ осначава начало на реда)
ls | grep ^mail -i         (За да търси без да е case sensitive)
grep conf$                 (Изкарва всички файлове,които завършвт на Conf
grep -v conf               (Търси всичко,което няма conf )
cat dracut.conf | grep -v ^# | -v ^$    (Показва всичко във фаЙла dracut.conf,което не започва с # или нов ред)
cat /var/log/messages | grep "^Feb 12 18"   (В кавички за да приеме целия текст като нещо за търсене.Вади от лога всички редове,които започват с Feb 12 18)
uptime && date              (когато се напишат така означава,че втората команда ще се пусне,ако първата се изпълни успешно)
echo$?                     (Показва ритърн кода от последната команда.Ако е 0 всичко е ок,правилна е,ако показва друго значи е грешна)
uptime || date             (Командата се изпълнява само,ако първата фелне)
  
  FIND, AWK, SED
	-----------------
	
pesho="file 1"             (декларираме променлива)
find ./ -name $pesho       (Търси в конкретната дир. фсички фаилове с име каквото пише в променливата)
ls -latrh                (t-сортира файловете по врем,r-reverce последните да ги изкара отпред,h-human readable format)
find /etc/ -name host* -exec ls -latrh {}\;   (Ако искаме за вс,които намери да екзекютне командата (в случая ls)завършваме с {}\; И преди командата да сложим -exec)
hostname                 (показва кой е хоста)
zcat                     Да видим какво имам в гзипнат файл)
locate                  (търсим файлове)
uname                   (Показва инфо за системата)
rm -rf ../testdir       (Така трябва да махнем директорията testdir,ако сме в нея)
awk -F: '{print $1}'/etc/passwd   
cat /etc/passwd | awk -F: '{print $1}'   (Вади първата колона от passwd като делиметъра е : )
cat /etc/passwd | awk -F: '{print $NF}'  (Вади последната колона)
cat /etc/passwd | awk -F: '{print $1,$2}'  (Вади колона 1 и 2)
awk -F: '{print $5}' /etc/passwd           (Вади 5-тата колона)
awk '{$5="adam";print$0}'file         ($print0 принтира целия ред.С този израз заменяме 5-тата колона с adam)
awk -F: '{print $1"maslini"}'/etc/passwd    (Така залепя текст за колоната)
awk -F: '{print "user is" $1}'/etc/passwd   (Така залепя текст преди колоната)
awk -F: '{print"user is"$1}'/etc/passwd | awk '{print 3}'
awk '{print $NF}' sysstat.txt | sort | grep ^[0-9] | tail -1
tail -3/etc/hosts | head -2 | awk '{print $1,$2".naselo.bg"}'
awk -F: 'BEGIN{print "USERS ARE"}{print $1}'/etc/passwd      (Слага текст преди да листне инфото (като заглавие на колоната)
awk -F: '{print $1}END{print"THE END"}'/etc/passwd           (Слага текст след като листне инфото
sed 's/pesho/gosho/'01          (Така променя petko na gosho като променя на всеки ред,където го намери като първа позиция)
sed -i's/pesho/gosho/' 01       (i казва да запише промените във файла)
sed 's/\<petko\>/gosho/' 01     (Така търси точно този стринг)
sed -i.bkp 's/pesho/gosho/' 01   (Така прави бекъп на файла преди да го запише)
sed -n '5,10p' /etc/passwd       (ПОказва резултат от линия 5 до линия 10)
sed G /etc/passwd                (Слага празен ред след всеки ред)
sed '/operator/s/root/USER/' passwd.txt    (Ще смени само на реда,на който има operator в реда)
which vi                (Показва къде се намира програмата)

  APPENDIX. USEFUL COMMANDS
-----------------------------------

  echo			awk			whereis
sort			sed			locate
cat		 	pwd			which
zcat			cd			man
gzip			ls			df
less			mv			wc
grep			rm			du 
head			mkdir		uname
tail			rmdir		history
strings		touch		find

example:

1.Find all files in /etc/ that end on “conf” and put them in a file /tmp/conf.txt, error messages(if any) should be recorded in /tmp/error.log, use chained commands. (hint: use find) 
find /etc/ -name *conf > /tmp/conf.txt 2>/tmp/error.log

2. Create directory in your home folder named “testdir” and navigate to it. Use chained commands for each of the following:
	a. create a file passwd.txt containing the last 10 lines of /etc/passwd. 
	b. create a file path.txt containing the current working directory 
	c. get the kernel release of your system and append it to path.txt without deleting the existing content
	d. get the date, replace the month abbreviation with the full month name and append to path.txt
	e. create 10 files named file1,file2,file3…..file10
mkdir testdir
ls
cd testdir
cd
cat /etc/passwd
cd /testdir
touch passwd.txt
tail -10 /etc/passwd > passwd.txt
uname -r >> path.txt
touch file{1..10}

3. While still in the testdir directory, delete it using its relative path..
rm -rf ../testdir

4.Use a chained command to view the file /etc/nsswitch.conf, but get only the lines that are not empty, not starting with # and do not contain the word “files” 
cat /etc/nsswitch.conf | grep -v ^$ | grep -v ^# | grep -v file

5. Use chained command to get all users on the system and store them into /tmp/users.txt.
	a. Pass /tmp/users.txt to stdin of the “sort” command 
	b. Emtpy the file /tmp/users.txt and verify it is empty
cat /etc/passwd > /tmp/users.txt
sort < /tmp/users.txt
> /tmp/users.txt
cat /tmp/users.txt

	VI, VIM
-----------------------------

U - UNDO
i - insert:добавя текст преди кърсора
a - append :добавя текст след курсора
o - new line
h - мести курсора наляво
l - мести курсора надясно
j - мести курсора надолу
k - мести курсора нагоре
w - мести дума напред
b - мести дума назад
$ - отива накрая на реда
shift+6 - отива в началото на реда
shift+c - изтрива всичко след курсора
x - трие символ по символ
gg - отива най-горе във фаЙла
shift + g - Отива най-долу във файла
:q! - излиза без да запише промените 
:wq или :x - Излиза и записва
vimtutor - Показва как се работи с vim
:set num - слага номер на редовете
:help
:colorscheme - сменя цветовете
info man - показва повече инфо за командата
apropos man - показва мановете къде са
yy - copy
yw - копира до първия
6yy - копира следващите 6 реда
dd - cut
P или p - paste  (да копира напред или назад )
dG - трие всичко надолу
dgg - трие всичко нагоре

    TAR, GZIP, BZIP2
---------------------------------
tar - архивиране без компресиране
zip, gzip, bzip2 - винаги архивира и компресира	
tar -cvf archive.tar ./*  : v - когато е сложено ще показва на конзолата какво прави докато архивира
 c- create, v- verbose(плюй на конзолата), f-file   ./* - и какво да прави с нея
tar -cvf test.archive file1.txt file4.txt file7.txt - архивира няколко файла.
tar -cvf test.archive ./{1,4,7}.txt - архивира няколко файла.
tar -cvf test.archive2 ./[1,4,7].txt - архивира няколко файла.
tar --add-file=FILE -f DIGITS !!!!!! NE !!!!!!
tar -f archive --delete ime na faila - трие файл от архива
tar -Af DIGITS arhiv - добавя друг архив към архива
tar -rf DIGITS file добавя файл към тар-а
tar -tf DIGITS - виждаме какво има в архива.Листва архива
gzip -9v archive.tar  - компресира с най-голяма степен
gunzip archive.gz - разкомпресира файла без да го разархивира. Търси окончание .gz на края.
tar -cvzf archive.tgz ./*  : v -  когато е сложено ще показва на конзолата какво прави докато компресира. Прави архив и gzip
tar -xvzf archive.tgz - разархивира и разкомпресира gzip
tar -cvjf archive.tgz ./*  : v -||- Прави архив и bzip
tar -cvjf archive.tgz {1..7}
tar -xvjf archive.tgz - разархивира и разкомпресира bzip
file archive.tgz - така може да видим с какво е компресиран файла, за да знаем как да го разкомпресираме.
tar --exclude {my_dir,file1.log} -cvzf test.tar ./*
tar -tvzf archive.tgz - ще покаже какво има във файла.
tar -xvf archive.tgz file.txt екстрактва само този файл от архива.
locate messages - има създадена база данни с файловете и locate търси в тази база данни. Ако базата не е ъпдейтната няма да намери нищо. Трябва да се избягва ползването, защото не винаги е актуална информацията
updatedb - ъпдейтва базата на locate..
$SHELL - показва кой шел
uname -a  - показва каква е системата
echo $? - показва дали предишната команнда е вярна
grep weblogic /etc/*/* - grep работи със стрингове. Търси в етц и поддиректориите му

   FIND
------------------------------

find - търси активно в директорията,търси само файл и директория
find /var/log -type f -name messages    (/var/log -къде да търси, -type f- за файл или -d за директория, -name messages- име Messages
   
 find direktoriq -type f -name messages Търси в директория (в случая тип файл с име messages). Трябва да се изпълнява като root за да може да търси на всякъде. Търси само файлове или директории и връща файл, а не стринг.
find /var -type d -name log - директория
find / -type f -name *ssh_config*
find / -type f -name "*" | grep ssh_config*
find / -type f -perm 0777 - търси всички файлове които са с права 777. 0-та е за стикибит ... suid също ще може да се сложи на мястото на 0-та
find / -type f ! -perm 0777 - ! означава да не вади тези с права 777
find /etc/ -name host* -exec ls -latrh {} \; - ако искаме за всички които намери да екзекютнем команда(в случая ls ) трябва да завърши с  {} \; и преди командата да сложим -exec . Винаги първо ползваме ls преди да екзекютнем друга команда за да видим на какво ще изпълним командата.  -exec komanda {} \; -така се икзекютва команда към find-a
find /etc/ -type f -mtime 0  - работи в дни  0-днес са редактирани, +50 от 50-ти ден натам, -50 последните 50 дни
find /etc/ -type f mmin 10 - работи в минути -||-

mtime - modification time
atime - access time
ctime - create time?/change time
mmin - modification in minutes
amin - access in minutes
cmin - create in minutes

find /etc/ -xdev -type f -size +100М - по големина търси. + (повече от 100М) - (по-малко от 100М) . Точна цифра си е 100М примерно .. xdev - да не търси в други файлови системи а само в текущата

find /var/ -mtime 0 -type f -size +100М -exec ls -la {} \; 2>/dev/null | sort -n -k5 | tail -50


Тези трябва да ги знаем за find
size
mtime
ctime
owner -> -user root
type
name
perm
-exec komanda {} \; 
+50 -50 50 
0 - Точно време
+50 - преди дадено време (от 50 по-стари)
-50 - след дадено време

grep -R 'httpd' /etc -  търси стринг рекрусивно в директорията
grep /etc -type f -name *ssh_config* (защото ни интересува всичко преди и след ,за да видя дали има и backup

-exec "ls -la" {} \;  -  {}-това казва,работи на файловете,които излезнат от find-a, \- слага се за да не се зачетат ; като знак за следваща команда, ;- чаръктър към exec,означава край

  JOB SCHEDULERS / CRON and AT /CRONTAB
------------------------------------------------------

 Job scheduler – is software that controls unattended program execution in background. 
This is also called batch processing. 
cron - Може да се дефинира кога точно да се изпълни(час,мин,ден от седмицата и т.н.)да изпълни дадени команди

CRON
-   So the crontab examples would read like
01 * * * * root run-parts /etc/cron.hourly  - At the : (first minute) (of each hour) (of each day) ( of each month ) (of each year) (as root) (run the following command: “run-parts /etc/cron.hourly”

02 4 * * * root run-parts /etc/cron.daily  - at the : (minute 2) (at 04 am) (on each day) (of each month) (and each year) (as root) (run command “run-parts /etc/cron.daily“

How would the rest read?
22 4 * * 0 root run-parts /etc/cron.weekly 
42 4 1 * * root run-parts /etc/cron.monthly

Крон синтаксис
0, 15, 30, 45 на всеки 15 мин
*/15 - на всеки 15 мин
15, 30 В 15 и в 30
5-10 - от до(рейндж)

crontab -u kakamara -l -листва кронтаба на какамара
01 * * * * run-parts /etc/cron.hourly В тази папка ще сложим скриптове и executables които да се изпълняват на всеки час. run-parts се ползва когато трябва да зададем подобна директория. В случая на всеки час ще изпълни в 01 минута всичко което е в тази директория. С опциите на run-parts може да казваме в каква поредност ще се ипълняват скриптовете.
01 * * * * run-parts /etc/cron.daily
01 * * * * run-parts /etc/cron.weekly
01 * * * * run-parts /etc/cron.monthly
/etc/cron.allow - ако има този файл само хората вътре ще имат достъп до кронтаба. Първо се гледа за този файл. Всяко име се пише на нов ред
/etc/cron.deny - Ако няма cron.allow и ако има този файл само хората вътре няма да имат достъп до кронтаба. Ако имаме празен deny файл всички юзъри ще имат достъп до кронтаба
Ако и двата не съществуват само root може да ползва кронтаба.

-User crontabs
 -Each user can create and edit their own crontab.
crontab –l     	- list
crontab –e	- edit
crontab –r 	- remove
crontab –u	- specify the user who’s crontab is in context of the command.
crontab -u име_юзър -l  -  Да видя crontab-а на даден юзър

-User crontabs are stored in:
/var/spool/cron/crontabs   	- Linux, HP-UX, AIX
/var/spool/cron/tabs		- Soalris
 
 !!!!!!!!!!!!
 cron.allow - само тези,които са вътре имат права за execute Ако го няма отива на cron.deny да търси
 cron.deny - Всички могат,освен тези,които са вътре
 Cron.none - само root може,ако ги няма двата горни файла
 
 Пример:
 Преди всичко трябва да проверим къде се намира командата,която искаме да ни се изпълни в crontab
 с which име_команда,в слъчая е date
 
  В crontab -e (пише се вътре какво да извършва)
  
 #displaying date each minute for testing purposes
 
 ***** /bin/date >> /root/aclfile
 
  cat /etc/crontab
  
  crontab -l - Листва нещата,които сме записали в Crontab да се извършат автоматично
  
 ЗАДАЧА!!!!!!!!!!!!!
--------------------------------------

Commands stat и ls -la issued to appuser1/file1, should produce output which should be redirected to /appuser1/info
-Every 10 minutes
-Every Friday 22:53
-Every day 21:42
-Every 9-th sept. 10:00 AM
-Every Thusday 18:30

За да видим командите къде са:
which stat и  which ls -la

crontab -e и пишем вътре:

#stat and ls -la
*/10 **** /bin/stat /home/appuser1/file1 >> /home/appuser1/info && /bin/ls -la /home/appuser1/file1 >> /home/appuser1/info
53 22 * * fri ---------същото като горе
42 21 * * * -----------
00 10 9 sep * -----------
30 18 * * thu -----------

И за да видя outputa - cat /home/appuser1/info
 
 !!!!!!!!!!!!!!!!!
 
 at - Използваме го,когато искаме да изпълни задача вместо нас  и да я запише във файл само веднъж,без да се повтаря
 
 Синтаксиса му е:
 
 at 1145 jan31  (1145-час и мин)
 
 Опашката от задачи се проверята с atq!!!!!
 
 1-ви начин за исползване:
 
 echo "echo "this happened" > /home/appuser1/attest" | at 1621 feb 20
 
 И проверката я правим с : cat /home/appuser1/attest
 
 2-ри начин за използване: 
 
 date (виждам колко в часа)
 at 1630 feb 20
 at > ls -la /home/appuser1 > /home/appuser1/interactive
 at > ctrl + d  (за да приключа командата)
 
 проверка: atq
 
 Ако искам да изтрия опашката: atrm И номера на опашката
 at -c 4 | more  -  показва инфо за дадения джоб
 
  NETWORKING
----------------------------------
!!!!!!!!!!!!
what is socket - комбинацията от ip И Port (за да стигнеш до апартамента ти трябва блок:)))
n на брой апликации да работят на един сървър  

Преди да сменяме МАК адрес трябва да спрем NetworkManager
systemctl stop NetworkManager
systemctl disable NetworkManager
systemctl status NetworkManager

systemctl service                 start
/etc/init.d/service               stop
service service                   status
rcservice

systemctl stop NetworkManager 
systemctl disable NetworkManager

за system D
systemctl  start, stop, status, disable, enable, isolate  servise

за system5
/etc/init.d service start, stop или status
service service  start, stop или status
rc service  start, stop или status


ip neigh = arp -a - показва кои са ни съседите в мрежата

ip link set down , up
ip link set dev ens40 address 00:00:22:55:66:44 сменяме мака
на другата виртуалка правим преобучаване на арп таблицата с 
arping -I ens58 192.168.189.134 - излизаме през девайс енс58 и пингва ип-то от другия сървър за да си обнови мака, който знае че е за него.




ifcfg-ens33
TYPE=Ethernet
BOOTPROTO=none
DEFROUTE=yes
NAME=ens33
DEVICE=ens33
ONBOOT=yes
IPADDR=192.168.189.128
PREFIX=24

ifcfg-ens38
TYPE=Ethernet
BOOTPROTO=none
DEFROUTE=yes
NAME=ens38
DEVICE=ens38
ONBOOT=yes
IPADDR=192.168.189.129
PREFIX=24


vim ifcfg-ens37 - NAT
TYPE=Ethernet
BOOTPROTO=none
DEFROUTE=yes
NAME=ens37
DEVICE=ens37
ONBOOT=yes
IPADDR=192.168.40.118
PREFIX=24
GATEWAY=192.168.40.2
DNS1=192.168.40.2
DNS2=8.8.8.8

MAC addresses and port states/negotiation
---------------------
Datalink network protocols.
---------------------------------------------
mii-tool - не се ползва
ethtool - Комуникира чрез драйвъра в желязото. Дава информация за мрежата. WoL wake on lan - пали лаптопа през нета. 
ethtool ens33 - вади информация и може да се сетва информацията за мрежовия адаптер.
arp -a - може да си изкараме кой ип адрес на кой мак отговаря.
arping -I - Проверяваме дали имаме връзка с даден ip адрес. рефрешва arp таблицата. В нея са записани ip-tata и маковете, които са към тях
brctl - в момента няма да го учим. Връзка м/у два отделни мрежови сегмента.
/sbin/ip link show 
ip link set dev <interface_name> address XX:XX:XX:XX:XX:XX - софтуерно казва на смени мак адреса.
ethtool -i ens33 - показва инфо за адаптера
netstat -tupan (t-tcp, u-udp, p-program, a-all, n-not resolving(изписва порт не име)
netstat -ltn - Листва TCP портове кой слуша
python -m SimpleHTTPServer 80 - Отваряме така порт 80
telnet 127.0.0.1 80 - Така проверяваме дали порта е отворен

IP layer
-----------------------------------------
Package counters
ip –s link
ip -s link show dev eth0

ip route може да се провери и да се сетне раутинга. Може да покаже текущата конфигурация на сървъра.
ip route del default
ip route show – show the routing table
ip rule show – show routing policy database (list routing tables)
ip route add default via <IP_address> - set default routing table.
ip route add default via 10.0.2.2
ip route get <destination IP> - gets the outgoing direction of a package according to the routing table
ip r - default gw

route add default gw 10.0.2.2
route -n - показва рутинг таблицата


ip -4 a s - показва ip-tata от версия 4
loopback devise - lo - вътрешен интерфейс само за нашата машина. Не комуникира с външния свят. Става за тестове. 127.0.0.1/8

ip addr {add|del|replace} dev <ifname> – Add/Remove IP address   - добавяме или махаме ip адарес
ip addr add 20.20.20.20/20 dev lo

ip addr flush dev <ifname> - Removes all IP addresses - трие ип-тата в таблицата.
dhclient [-vr] – set ip address via DHCP
dhclient -v ens33

BOND!!!!
-----------------------------------------
bond !!не е команда!!- това са две карти вързани да работят заедно за редъндънси и ако едната падне другата почва да работи. Бонда има собствен мак и отделно има макове на различните карти, но реално се излзиа през този на бонда.
nslookup 

  Bonding !!!!!!!!!

modprobe bonding

cd /etc/sysconfig/network-scripts/

vim ifcfg-ens33
NAME=ens33
DEVICE=ens33
USERCTL=no
ONBOOT=yes
NM_CONTROLLED=no
MASTER=bond0
SLAVE=yes
BOOTPROTO=none

ifdown ens33
ifup ens33


vim ifcfg-bond0 
DEVICE=bond0
NAME=bond0
BONDING_OPTS="mode=active-backup miimon=100" или BONDING_OPTS="mode=1 miimon=100"  (1 e active-backup)
IPADDR=192.168.189.135
PREFIX=24
NM_CONTROLLED=no
BOOTPROTO=none
ONBOOT=yes
USERCTL=no


ifdown bond0
ifup bond0

Проверка за бонда!!!!
---------------------------
root@cet64 ~]# cat /proc/net/bonding/bond0
Ethernet Channel Bonding Driver: v3.6.0 (September 26, 2009)

Bonding Mode: load balancing (round-robin)
MII Status: down
MII Polling Interval (ms): 0
Up Delay (ms): 0
Down Delay (ms): 0
---------------------------------
hostnamectl set-hostname host1

modinfo bonding - дава информация за модула.
lsmod  листва всички модули
depmod - показва какви са депенданситата за модулите. да се провери в мана как работи


round robin - 0 - две карти работят едновременно като се запълва трафика колкото е нужно. Използва се когато не трябва да ползваме капацитета на 100% а имаме промяна на трафика и трябва да имаме буфер който да се покрива при увеличаване на трафика. Ако падне едната почва да предава с по-малък капацитет.
link agregation - 4 - двете карти работят на 100% непрекъснато. Използва се при нужда от постоянен висок трафик. Примерно да се вържат две карти по 10 гигабита и да бълват трафик 20гига бита непрекъснато. Ако падне едната почва да предава с по-малък капацитет.
active-backup -1 - за редънданси. Работи само едната и ако падне трафика се пуска през другата.
Ако не пишем нищо в конфиг.файла по дифолт ще бъде round robin


ping [-RIM] <ip> (ICMP traffik)
telnet <ip> <port>  - проверяваме дали порта е отворен.  От 0 до 1023 портовете са резервирани. от 0 - 65500 е реинджа на портовете.

export http_proxy='http://proxy.sdc.hp.com:8080'
export https_proxy='http://proxy.sdc.hp.com:8080'
export ftp_proxy='http://proxy.sdc.hp.com:8080'


vi /etc/selinux/config
disabled
sestatus -- > check status of selinux

firewall-cmd --list-all листва firewall-a 
iptables -L листва iptables
python -m SimpleHTTPServer 80 - отваряме SimpleHTTPServer на порт 80

  ЗАДАЧА!!
  ------------------
Сменям МАК адрес:
ip link set dev ens37 address 00:00:22:55:66:44
Виждам ip адреса:
ip a  или ip -4 a
За да му покажа промените:
arping -I ens38 ip_address  (ens38-име от който) (Ip_address-на който,от др хост,от който ще проверявам)
Ping ip_address (Пиша ip-то на дивайса,където сме променяли)
да рефрешнем ip table:
ip neigh
---------------------------------
cd /etc/sysconfig/network-scripts/
vim ifcfg-ens33
ifdown
ifup
------------------------------
host1:  ip neigh
host2:  ip link set dev ens33 address 00:01:02:03:04:05
host1:  arping -I ens37 ip_address(ip-то на ens33) Така проверяваме дали имат връзка
-----------------------------------------

    REMOTE CONNECTIONS
-----------------------------------------------------------------
SSH and SSH tunneling
SSL/TLS
SCP
FTP/SFTP
NTP
NFS/Samba
Automount

SSH- secure shell (направен за да достъпва секюрити отдалечено)

симетрично криптиране е unsecure (с един ключ)
асиметрично криптиране е secure )с частен и публичен ключ)
 Изпраща се нещо криптирано с public key (след като сме си ги разменили) и се разклиптира с private key
 
 1 от Host1 - generate key - ssh-keygen -t rsa
 2 от Host1 - upload public key to server - ssh-copy-id ~/.ssh/id_rsa.pub root@192.168.178.40(тук се пише ip-то на сървъра)
 3 от Host1 - ssh root@192.168.178.40
 и въвеждам паролата на сървъра
 -----------------------------------------
 
 SSL - паспорт (сертификат,който се инсталира  при размяна на информация да се потвърди,че е вярна и не се променя)
 SCP - secure copy protocol - Местим файлове чрез SSH От място А до Б ,ако нямаш SSH нямаш SCP
 
 FTP - file transfer protocol - seper unsecure transfer protocol
 SFTP - secure file transfer protocol(криптирана информация и използва SCP)
 
 NTP - network time protocol*(чрез него NTP server, синхронизира всички сървъри в средата на време,което му назначиш)
 ntpq -p (Показва NTP demon)
 systemctl start ntpd
 
    SCP
----------------------
client - Създаваме файл в tmp - touch file{1..4} /tmp
client - Прехвърляме файловете към server - scp ./file* root@ip_na server: /tmp (/tmp - казваме да ги сложи там)
client - Ако искаме да ги дръпнем пак стоейки на цлиент хост - scp root@ip_na server:/tmp/file* /home  (/home - че искам да ги сложим там)

С командата - ssh -v root@ip-то на сървъра - така проверяваме какъв е прблема,ако не можем да се качим на сървъра
	