/********************************************************************************
*********       E-mail subject: BELFWEB-797
*********             Instance: PTPV9
*********          Description: 
Problem:
There was a slowness on PTPV9 on 11/10/2023.

Analysis:
From the information in provided HAR file, we found in the V9 logs the problematic SQL.
For this SQL Oracle was using an inappropriate execution plan, because table g_encaissement was not 
joined with the other tables in the second and the third part of the query.
This leads to full scan of table g_encaissement and after that sorting a lot of data, which is slow.

Suggestion:
Please join table g_encaissement with the other tables.

*********               SQL_ID: bmus6t76z4c7a
*********      Program/Package: 
*********              Request: Dahin Julien
*********               Author: Dimitar Dimitrov
********* Received e-mail date: 11/10/2023
*********      Resolution date: 12/10/2023
*********  Trace old file here: \\epox\specifs\performance\tmp\
*********  Trace new file here:
***********************************************************************************/

/********************************OLD SQL*******************************************/
var B1 VARCHAR2(128);
exec :B1 := 'A80KFUN4';
var B2 VARCHAR2(128);
exec :B2 := '1903180046';
var B3 VARCHAR2(128);
exec :B3 := 'A80KFUN4';
var B4 VARCHAR2(128);
exec :B4 := 'A80KFUN4';

SELECT *
  FROM (SELECT 1 AS displayValidationDetailsBtn,
               1 AS prio,
               gout.nocompte_benef AS benefAccountNb,
               gout.nom_benef AS benefName,
               gout.MOYENPAIMT,
               gout.refbenef AS benefRef,
               gout.IBAN_BENEF AS ibanBenefRef,
               goute.DTEXECUTION_DT AS executionDate,
               goute.dtcreation_dt AS creationDate,
               goute.id AS refId,
               gout.additional_ref AS additionalRef,
               gout.refoutpmt AS refOutPayment,
               ge.MONTANT_MVT AS amountMovement,
               ge.DEVISE_MVT AS currencyMovement,
               (select gp.login
                  from g_personnel gp
                 where gp.refperso = gout.refperso
                   and rownum = 1) AS username
          FROM g_outpmt gout, g_outpmt_exec goute, g_encaissement ge
         WHERE gout.refOutPmt = goute.refoutpmt(+)
           AND gout.refer = ge.refencaiss
           AND ge.refencaiss = :B1
           AND ge.refdoss = :B2
           AND ge.typencaiss = 'Releve'
        UNION
        SELECT 1 AS displayValidationDetailsBtn,
               2 AS prio,
               gout.nocompte_benef AS benefAccountNb,
               gout.nom_benef AS benefName,
               gout.MOYENPAIMT,
               gout.refbenef AS benefRef,
               gout.IBAN_BENEF AS ibanBenefRef,
               goute.DTEXECUTION_DT AS executionDate,
               goute.dtcreation_dt AS creationDate,
               goute.id AS refId,
               gout.additional_ref AS additionalRef,
               gout.refoutpmt AS refOutPayment,
               ge.MONTANT_MVT AS amountMovement,
               ge.DEVISE_MVT AS currencyMovement,
               (select gp.login
                  from g_personnel gp
                 where gp.refperso = gout.refperso
                   and rownum = 1) AS username
          FROM g_outpmt gout, g_outpmt_exec goute, g_encaissement ge
         WHERE gout.refOutPmt = goute.refoutpmt(+)
           AND gout.refer = :B3
        UNION
        SELECT 1 AS displayValidationDetailsBtn,
               3 AS prio,
               gout.nocompte_benef AS benefAccountNb,
               gout.nom_benef AS benefName,
               gout.MOYENPAIMT,
               gout.refbenef AS benefRef,
               gout.IBAN_BENEF AS ibanBenefRef,
               goute.DTEXECUTION_DT AS executionDate,
               goute.dtcreation_dt AS creationDate,
               goute.id AS refId,
               gout.additional_ref AS additionalRef,
               gout.refoutpmt AS refOutPayment,
               ge.MONTANT_MVT AS amountMovement,
               ge.DEVISE_MVT AS currencyMovement,
               (select gp.login
                  from g_personnel gp
                 where gp.refperso = gout.refperso
                   and rownum = 1) AS username
          FROM g_outpmt gout, g_outpmt_exec goute, g_encaissement ge
         WHERE gout.refOutPmt = goute.refoutpmt(+)
           AND gout.refOutPmt = :B4) FETCH FIRST 1 ROWS ONLY;
/********************************OLD SQL*******************************************/
/********************************OLD Metrics***************************************/
/*

Plan hash value: 1171150906
-------------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                 | Name                    | Starts | E-Rows | A-Rows |   A-Time   | Buffers | Reads  | Writes |
-------------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                          |                         |      1 |        |      1 |00:01:46.08 |    1307K|   1357K|    195K|
|*  1 |  VIEW                                     |                         |      1 |      1 |      1 |00:01:46.08 |    1307K|   1357K|    195K|
|*  2 |   WINDOW NOSORT STOPKEY                   |                         |      1 |     48M|      1 |00:01:46.08 |    1307K|   1357K|    195K|
|   3 |    VIEW                                   |                         |      1 |     48M|      1 |00:01:46.08 |    1307K|   1357K|    195K|
|   4 |     SORT UNIQUE                           |                         |      1 |     48M|      1 |00:01:46.08 |    1307K|   1357K|    195K|
|   5 |      UNION-ALL                            |                         |      1 |        |     24M|00:00:16.60 |    1307K|   1354K|  47541 |
|*  6 |       COUNT STOPKEY                       |                         |      1 |        |      1 |00:00:00.01 |       3 |      0 |      0 |
|   7 |        TABLE ACCESS BY INDEX ROWID BATCHED| G_PERSONNEL             |      1 |      1 |      1 |00:00:00.01 |       3 |      0 |      0 |
|*  8 |         INDEX RANGE SCAN                  | GPERSREFP               |      1 |      1 |      1 |00:00:00.01 |       2 |      0 |      0 |
|   9 |       NESTED LOOPS OUTER                  |                         |      1 |      1 |      1 |00:00:00.03 |      12 |      3 |      0 |
|  10 |        NESTED LOOPS                       |                         |      1 |      1 |      1 |00:00:00.03 |       8 |      2 |      0 |
|* 11 |         TABLE ACCESS BY INDEX ROWID       | G_ENCAISSEMENT          |      1 |      1 |      1 |00:00:00.02 |       4 |      1 |      0 |
|* 12 |          INDEX UNIQUE SCAN                | REFENCAISS              |      1 |      1 |      1 |00:00:00.01 |       3 |      0 |      0 |
|  13 |         TABLE ACCESS BY INDEX ROWID       | G_OUTPMT                |      1 |      1 |      1 |00:00:00.01 |       4 |      1 |      0 |
|* 14 |          INDEX RANGE SCAN                 | G_OUTPMT_REFER_IDX      |      1 |      1 |      1 |00:00:00.01 |       3 |      0 |      0 |
|  15 |        TABLE ACCESS BY INDEX ROWID        | G_OUTPMT_EXEC           |      1 |      1 |      1 |00:00:00.01 |       4 |      1 |      0 |
|* 16 |         INDEX UNIQUE SCAN                 | G_OUTPMT_EXEC$REFOUTPMT |      1 |      1 |      1 |00:00:00.01 |       3 |      0 |      0 |
|* 17 |       COUNT STOPKEY                       |                         |      1 |        |      1 |00:00:00.01 |       3 |      0 |      0 |
|  18 |        TABLE ACCESS BY INDEX ROWID BATCHED| G_PERSONNEL             |      1 |      1 |      1 |00:00:00.01 |       3 |      0 |      0 |
|* 19 |         INDEX RANGE SCAN                  | GPERSREFP               |      1 |      1 |      1 |00:00:00.01 |       2 |      0 |      0 |
|  20 |       MERGE JOIN CARTESIAN                |                         |      1 |     24M|     24M|00:00:08.71 |    1307K|   1354K|  47541 |
|  21 |        NESTED LOOPS OUTER                 |                         |      1 |      1 |      1 |00:00:00.01 |       8 |      0 |      0 |
|  22 |         TABLE ACCESS BY INDEX ROWID       | G_OUTPMT                |      1 |      1 |      1 |00:00:00.01 |       4 |      0 |      0 |
|* 23 |          INDEX RANGE SCAN                 | G_OUTPMT_REFER_IDX      |      1 |      1 |      1 |00:00:00.01 |       3 |      0 |      0 |
|  24 |         TABLE ACCESS BY INDEX ROWID       | G_OUTPMT_EXEC           |      1 |      1 |      1 |00:00:00.01 |       4 |      0 |      0 |
|* 25 |          INDEX UNIQUE SCAN                | G_OUTPMT_EXEC$REFOUTPMT |      1 |      1 |      1 |00:00:00.01 |       3 |      0 |      0 |
|  26 |        BUFFER SORT                        |                         |      1 |     24M|     24M|00:00:06.86 |    1307K|   1354K|  47541 |
|  27 |         TABLE ACCESS STORAGE FULL         | G_ENCAISSEMENT          |      1 |     24M|     24M|00:00:00.47 |    1307K|   1307K|      0 |
|* 28 |       COUNT STOPKEY                       |                         |      0 |        |      0 |00:00:00.01 |       0 |      0 |      0 |
|  29 |        TABLE ACCESS BY INDEX ROWID BATCHED| G_PERSONNEL             |      0 |      1 |      0 |00:00:00.01 |       0 |      0 |      0 |
|* 30 |         INDEX RANGE SCAN                  | GPERSREFP               |      0 |      1 |      0 |00:00:00.01 |       0 |      0 |      0 |
|  31 |       NESTED LOOPS                        |                         |      1 |     24M|      0 |00:00:00.01 |       3 |      0 |      0 |
|  32 |        NESTED LOOPS OUTER                 |                         |      1 |      1 |      0 |00:00:00.01 |       3 |      0 |      0 |
|  33 |         TABLE ACCESS BY INDEX ROWID       | G_OUTPMT                |      1 |      1 |      0 |00:00:00.01 |       3 |      0 |      0 |
|* 34 |          INDEX UNIQUE SCAN                | G_OUTPMT$REFOUTPMT      |      1 |      1 |      0 |00:00:00.01 |       3 |      0 |      0 |
|  35 |         TABLE ACCESS BY INDEX ROWID       | G_OUTPMT_EXEC           |      0 |      1 |      0 |00:00:00.01 |       0 |      0 |      0 |
|* 36 |          INDEX UNIQUE SCAN                | G_OUTPMT_EXEC$REFOUTPMT |      0 |      1 |      0 |00:00:00.01 |       0 |      0 |      0 |
|  37 |        TABLE ACCESS STORAGE FULL          | G_ENCAISSEMENT          |      0 |     24M|      0 |00:00:00.01 |       0 |      0 |      0 |
-------------------------------------------------------------------------------------------------------------------------------------------------

Predicate Information (identified by operation id):
---------------------------------------------------
   1 - filter("from$_subquery$_014"."rowlimit_$$_rownumber"<=1)
   2 - filter(ROW_NUMBER() OVER ( ORDER BY  NULL )<=1)
   6 - filter(ROWNUM=1)
   8 - access("GP"."REFPERSO"=:B1)
  11 - filter(("GE"."REFDOSS"=:B2 AND "GE"."TYPENCAISS"='Releve'))
  12 - access("GE"."REFENCAISS"=:B1)
  14 - access("GOUT"."REFER"=:B1)
  16 - access("GOUT"."REFOUTPMT"="GOUTE"."REFOUTPMT")
  17 - filter(ROWNUM=1)
  19 - access("GP"."REFPERSO"=:B1)
  23 - access("GOUT"."REFER"=:B3)
  25 - access("GOUT"."REFOUTPMT"="GOUTE"."REFOUTPMT")
  28 - filter(ROWNUM=1)
  30 - access("GP"."REFPERSO"=:B1)
  34 - access("GOUT"."REFOUTPMT"=:B4)
  36 - access("GOUTE"."REFOUTPMT"=:B4)
*/
/********************************OLD Metrics***************************************/

/********************************New SQL*******************************************/

;
/********************************New SQL*******************************************/
/********************************New Metrics***************************************/
/*

*/
/********************************New Metrics***************************************/

/********************************Index statistics**********************************/

/********************************Other SQLs****************************************/          
/*

*/ 
/********************************Other SQLs****************************************/              
