FIDDEV-4307




                  
 



If possible – encrypt also IMXPARAM

This is to make VAL instance compliant with the same TDE setup at the client side



DEUS /deus/intra/rdbms/19.3
DEUSAD /deus/ad/rdbms/19.3
DEUSVAL /deusval/intra/rdbms/19.3



II. Steps

1.Configure Wallet Root • INIT.ORA

mkdir -p $ORACLE_BASE/admin/$ORACLE_SID}/wallet/tde




mkdir -p  $ORACLE_HOME/wallet/tde


cd $ORACLE_HOME/dbs

#TDE
WALLET_ROOT="/deushf/intra/rdbms/19.3/wallet" 
TDE_CONFIGURATION="KEYSTORE_CONFIGURATION=FILE"
  
  
--- alter system set WALLET_ROOT="/deus/intra/rdbms/19.3/wallet/tde"   scope=spfile;
--- alter system set TDE_CONFIGURATION="KEYSTORE_CONFIGURATION=FILE"  ;
  restart database 
  
  
 sho parameter wallet
  sho parameter TDE_CONFIGURATION
 



 
 
2.Create the keystore


sqlplus / as sysdba


administer key management create keystore '/deus/intra/rdbms/19.3/wallet/tde'    identified by wl0102678;


administer key management create keystore '/deusval/intra/rdbms/19.3/wallet/tde'    identified by wl0664249;




set lines 300
column WRL_PARAMETER format a40
select WRL_TYPE, WRL_PARAMETER, STATUS, CON_ID from v$encryption_wallet;



3.Open the keystore


administer key management set keystore open force keystore identified by wl0102678;

administer key management set keystore open force keystore identified by wl0664249;


set lines 300
column WRL_PARAMETER format a40
select WRL_TYPE, WRL_PARAMETER, STATUS, CON_ID from v$encryption_wallet;

--To switch over to opening the password-protected software keystore when an auto-login keystore is configured and is currently open, specify the FORCE KEYSTORE clause as follows.




4.Create the master key - Set the Keystore TDE Encryption Master Key 



administer key management set key FORCE KEYSTORE identified by wl0102678 with backup; 

administer key management set key FORCE KEYSTORE identified by wl0664249 with backup; 


set lines 300
column WRL_PARAMETER format a40
 SELECT * FROM v$encryption_wallet;
 


--As you can see autologin wallet is open and enabled, now there is no overhead of opening or closing the wallet. Once you will restart the database, wallet will be automatically opened. 



5.Create autologin keystore
Configure Auto Login Keystore and check the status



administer key management create auto_login keystore from keystore '/deus/intra/rdbms/19.3/wallet/tde' identified by wl0102678;

administer key management create auto_login keystore from keystore '/deusval/intra/rdbms/19.3/wallet/tde' identified by wl0664249;




 SELECT * FROM v$encryption_wallet;



Restart the database





WRL_TYPE             WRL_PARAMETER                            STATUS                         WALLET_TYPE          WALLET_OR KEYSTORE FULLY_BAC 
-------------------- ---------------------------------------- ------------------------------ -------------------- --------- -------- --------- 
FILE                 /deus/intra/rdbms/19.3/wallet/tde/      OPEN                           AUTOLOGIN            SINGLE    NONE     NO        




6.Encrypt tablespaces


IMXINDEX   
IMXDATA    

--- ALTER TABLESPACE GEI6_DATA_01            ENCRYPTION onLINE ENCRYPT; 
 





select TABLESPACE_NAME, STATUS, ENCRYPTED from DBA_TABLESPACES;

								 
 ALTER TABLESPACE IMXINDEX   OFFLINE NORMAL;
 ALTER TABLESPACE IMXINDEX  ENCRYPTION OFFLINE ENCRYPT; 
 ALTER TABLESPACE IMXINDEX   ONLINE;
 
 ALTER TABLESPACE IMXDATA     OFFLINE NORMAL;
 ALTER TABLESPACE IMXDATA    ENCRYPTION OFFLINE ENCRYPT; 
 ALTER TABLESPACE IMXDATA     ONLINE;



 

--- ALTER TABLESPACE SYSAUX ENCRYPTION ONLINE FINISH ENCRYPT ; 
--- alter tablespace SYSAUX encryption offline decrypt;
---alter tablespace SYSAUX encryption online encrypt;





select TABLESPACE_NAME, STATUS, ENCRYPTED from DBA_TABLESPACES;

select * from V$ENCRYPTED_TABLESPACES;



TABLESPACE_NAME                STATUS    ENC
------------------------------ --------- ---
GEI6_ARCH_DATA_01              ONLINE    YES
GEI6_ARCH_INDEX_01             ONLINE    YES
GEI6_DATA_01                   ONLINE    YES
GEI6_IAS_OPSS                  ONLINE    YES
GEI6_IAU                       ONLINE    YES
GEI6_INDEX_01                  ONLINE    YES
GEI6_STB                       ONLINE    YES
GEI6_WLS                       ONLINE    YES
IMXBUFFTBS                     ONLINE    YES




set lines 300
column WRL_PARAMETER format a40
 SELECT * FROM v$encryption_wallet;


--- ALTER TABLESPACE IMXDATA ENCRYPTION OFFLINE  decrypt;
--- ALTER TABLESPACE IMXDATA ONLINE;


WRL_TYPE     WRL_PARAMETER                            STATUS     WALLET_TYPE  WALLET_OR 
------------ ---------------------------------------- ---------- ------------ --------- 
FILE         /deus/intra/rdbms/19.3/wallet/tde/ OPEN       AUTOLOGIN    SINGLE    














