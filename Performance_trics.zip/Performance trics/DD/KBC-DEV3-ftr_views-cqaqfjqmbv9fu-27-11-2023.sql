/********************************************************************************
*********       E-mail subject: KBCCFWEB-2185
*********             Instance: DEV3
*********          Description: 
Problem:

Analysis:

Suggestion:

*********               SQL_ID: cqaqfjqmbv9fu
*********      Program/Package: ftr_views.v_client_current_acc
*********              Request: Dimitare Ivanov
*********               Author: Dimitar Dimitrov
********* Received e-mail date: 22/11/2023
*********      Resolution date: 27/11/2023
*********  Trace old file here: \\epox\specifs\performance\tmp\
*********  Trace new file here:
***********************************************************************************/

/********************************OLD SQL*******************************************/
var B13 VARCHAR2(128);
exec :B13 := '';
var B12 VARCHAR2(128);
exec :B12 := 'INT00000';
var B11 VARCHAR2(128);
exec :B11 := 'AN';
var B10 VARCHAR2(128);
exec :B10 := '';
var B9 VARCHAR2(128);
exec :B9 := 'GBR';
var B8 VARCHAR2(128);
exec :B8 := '0001020130';
var B7 VARCHAR2(128);
exec :B7 := 'O041DEWX';
var B6 VARCHAR2(128);
exec :B6 := '';
var B5 VARCHAR2(128);
exec :B5 := '';
var B4 VARCHAR2(128);
exec :B4 := '';
var B3 VARCHAR2(128);
exec :B3 := '';
var B2 NUMBER;
exec :B2 := 9999999;
var B1 NUMBER;
exec :B1 := 9999999;


SELECT *
  FROM (SELECT DECODE(TYPMVT,
                      'pmtSAF_ajust',
                      TRUNC(DTVENTIL_DT),
                      'pmtSAF_sd_deduc',
                      TRUNC(DTVENTIL_DT),
                      TRUNC(DTEXTRAIT_DT)) TRANSACTION_DT,
               DECODE(TYPMVT,
                      'pmtSAF_ajust',
                      TRUNC(DTVENTIL_DT),
                      'pmtSAF_sd_deduc',
                      TRUNC(DTVENTIL_DT),
                      TRUNC(DT_RECONCILIATION_DT)) VALUE_DT,
               NULL LABEL,
               :B10 LABEL_DESC,
               DECODE(SIGNE, 1, -1, 1) *
               DECODE(TYPMVT, 'pmtSAF_ajust', -1, 'pmtSAF_sd_deduc', -1, 1) * CASE
                 WHEN MONTANT_MVT IS NOT NULL AND DEVISE_MVT = :B9 THEN
                  MONTANT_MVT
                 WHEN MONTANT_MVT_BQ IS NOT NULL AND DEVISE_MVT_BQ = :B9 THEN
                  MONTANT_MVT_BQ
                 WHEN MONTANT3 IS NOT NULL AND DEVISE3 = :B9 THEN
                  MONTANT3
                 WHEN DEVISE = :B9 THEN
                  NVL(MONTANT, 0)
                 ELSE
                  CH_TAUX.CONVERSMVTDOS(DTEXTRAIT,
                                        REFDOSS,
                                        NVL(MONTANT, 0),
                                        DEVISE,
                                        'A')
               END AMOUNT_DCMP,
               1 NB,
               COMPOSTAGE REFELEM,
               REFDOSS REFDOSS_DCMP,
               'CIT' || TYPMVT CODECR,
               NULL REFEXT,
               NULL RETENTIONINDIC,
               MEMO_DECOMPTE MEMO_DECOMPTE
          FROM NAM_COLLECTE
         WHERE REFDOSS = :B8
           AND (:B7 IS NULL AND :B6 IS NULL OR
               MEMO_DECOMPTE BETWEEN NVL(:B6, :B7) AND NVL(:B7, :B6))
           AND TYPMVT IN ('encSAF',
                          'encSAF_col',
                          'encSAF_derec',
                          'SAF',
                          'pmtSAF_ajust',
                          'pmtSAF_sd_deduc')
           AND (CODOP IS NULL OR
               CODOP NOT IN
               (SELECT CHEMIN || LPAD(PLACE, 2, '0') ||
                        LPAD(COMMENTAIRE, 2, '0') || LPAD(ECRAN, 3, '0')
                   FROM V_DOMAINE
                  WHERE TYPE = 'OPCODE_COMBINATIONS'
                    AND OBL = 'O'
                    AND ABREV2 IS NULL
                    AND CHAMP != 'DO NOT PROCESS'))
           AND ETAT IN ('RCI', 'RCP')
           AND (MEMO_DECOMPTE = :B5 OR
               :B4 IS NULL AND :B3 IS NULL AND
               DECODE(TYPMVT,
                       'pmtSAF_ajust',
                       DTVENTIL,
                       'pmtSAF_sd_deduc',
                       DTVENTIL,
                       DTEXTRAIT) <=
               NVL(:B2,
                    DECODE(TYPMVT,
                           'pmtSAF_ajust',
                           DTVENTIL,
                           'pmtSAF_sd_deduc',
                           DTVENTIL,
                           DTEXTRAIT)) AND
               DECODE(TYPMVT,
                       'pmtSAF_ajust',
                       DTVENTIL,
                       'pmtSAF_sd_deduc',
                       DTVENTIL,
                       TO_CHAR(DT_RECONCILIATION_DT, 'j')) <=
               NVL(:B1,
                    DECODE(TYPMVT,
                           'pmtSAF_ajust',
                           DTVENTIL,
                           'pmtSAF_sd_deduc',
                           DTVENTIL,
                           TO_CHAR(DT_RECONCILIATION_DT, 'j'))) OR
               :B4 = 'CIT' || TYPMVT AND :B3 IS NULL AND
               DECODE(TYPMVT,
                       'pmtSAF_ajust',
                       DTVENTIL,
                       'pmtSAF_sd_deduc',
                       DTVENTIL,
                       DTEXTRAIT) =
               NVL(:B2,
                    DECODE(TYPMVT,
                           'pmtSAF_ajust',
                           DTVENTIL,
                           'pmtSAF_sd_deduc',
                           DTVENTIL,
                           DTEXTRAIT)) AND
               DECODE(TYPMVT,
                       'pmtSAF_ajust',
                       DTVENTIL,
                       'pmtSAF_sd_deduc',
                       DTVENTIL,
                       TO_CHAR(DT_RECONCILIATION_DT, 'j')) =
               NVL(:B1,
                    DECODE(TYPMVT,
                           'pmtSAF_ajust',
                           DTVENTIL,
                           'pmtSAF_sd_deduc',
                           DTVENTIL,
                           TO_CHAR(DT_RECONCILIATION_DT, 'j'))))
        UNION ALL
        SELECT TRUNC(T.DTJOUR_DT) TRANSACTION_DT,
               TRUNC(T.DTINTER_DT) VALUE_DT,
               T.LIBELLE LABEL,
               (SELECT IMX.FTRANSLATE_STR(T.LIBELLE, :B11, T.CODECR)
                  FROM DUAL) LABEL_DESC,
               T.MNT_DCPT AMOUNT_DCMP,
               1 NB,
               T.REFELEM REFELEM,
               C.REFLOT REFDOSS_DCMP,
               'CIT' || T.CODECR CODECR,
               NULL REFEXT,
               NULL RETENTIONINDIC,
               DECODE(T.ORIG_REFLOT,
                      T.REFDOSS,
                      NVL2(M.REFJOUR, M.ORIG_REFLOT, 'NP'),
                      T.ORIG_REFLOT) MEMO_DECOMPTE
          FROM G_DOSSIER C, T_ECRDOS T, G_ENCAISSEMENT E, T_ECRDOS_TEMP M
         WHERE C.REFLOT = :B8
           AND T.REFDOSS = C.REFDOSS
           AND (:B7 IS NULL AND :B6 IS NULL OR
               DECODE(T.ORIG_REFLOT,
                       T.REFDOSS,
                       NVL2(M.REFJOUR, :B5, 'NP'),
                       T.ORIG_REFLOT) BETWEEN NVL(:B6, :B7) AND
               NVL(:B7, :B6))
           AND T.CODECR IN ('ENCAT', 'AENAT', 'RFIN', 'ARFIN')
           AND E.REFENCAISS = T.REFELEM
           AND E.TYPENCAISS = 'e_saencaiss'
           AND E.MOYENPAIMT = 'PAIEMENT 
  DECLARE'
           AND (M.ORIG_REFLOT = :B3 AND T.ORIG_REFLOT = T.REFDOSS OR
               :B5 = 'NP' AND M.ORIG_REFLOT IS NULL AND
               T.ORIG_REFLOT = T.REFDOSS OR
               :B4 IS NULL AND :B3 IS NULL AND
               T.DTJOUR <= NVL(:B2, T.DTJOUR) AND
               T.DTINTER <= NVL(:B1, T.DTINTER) OR
               :B4 = 'CIT' || T.CODECR AND :B3 IS NULL AND
               T.DTJOUR = NVL(:B2, T.DTJOUR) AND
               T.DTINTER = NVL(:B1, T.DTINTER))
           AND M.REFJOUR(+) = T.REFJOUR
        UNION ALL
        SELECT TRUNC(T.DTJOUR_DT) TRANSACTION_DT,
               TRUNC(T.DTINTER_DT) VALUE_DT,
               T.LIBELLE LABEL,
               (SELECT DISTINCT FIRST_VALUE(PF_LIB_TRAD) OVER(ORDER BY PF_REFFACTOR NULLS LAST)
                  FROM V_FPARFAC
                 WHERE PF_NOM = T.CODECR
                   AND (PF_REFFACTOR IS NULL OR PF_REFFACTOR = :B12)
                   AND LANGUE = :B11) LABEL_DESC,
               -T.MNT_DCPT AMOUNT_DCMP,
               1 NB,
               T.REFELEM REFELEM,
               T.REFDOSS REFDOSS_DCMP,
               'CIT' || T.CODECR CODECR,
               NULL REFEXT,
               NULL RETENTIONINDIC,
               T.MEMO_DECOMPTE MEMO_DECOMPTE
          FROM T_ECRDOS T
         WHERE T.REFDOSS = :B8
           AND (:B7 IS NULL AND :B6 IS NULL OR
               T.MEMO_DECOMPTE BETWEEN NVL(:B6, :B7) AND NVL(:B7, :B6))
           AND T.CODECR IN ('RINDS', 'CRINS')
           AND (T.MEMO_DECOMPTE = :B5 OR :B4 IS NULL AND :B3 IS NULL AND
               T.DTJOUR <= NVL(:B2, T.DTJOUR) AND
               T.DTINTER <= NVL(:B1, T.DTINTER) OR
               :B4 = 'CIT' || CODECR AND :B3 IS NULL AND
               T.DTJOUR = NVL(:B2, T.DTJOUR) AND
               T.DTINTER = NVL(:B1, T.DTINTER))
        UNION ALL
        SELECT TRANSACTION_DT TRANSACTION_DT,
               VALUE_DT VALUE_DT,
               LABEL LABEL,
               (SELECT IMX.FTRANSLATE_STR(LIB_A, :B11, CODECR_F) FROM DUAL) ||
               LIB_B LABEL_DESC,
               AMOUNT_DCMP AMOUNT_DCMP,
               NB NB,
               REFELEM REFELEM,
               REFDOSS_DCMP REFDOSS_DCMP,
               CODECR CODECR,
               REFEXT REFEXT,
               RETENTIONINDIC RETENTIONINDIC,
               MEMO_DECOMPTE MEMO_DECOMPTE
          FROM (SELECT /*+ leading(C G T) index(G 
                  G_ELEMFI_DOS_TYP_FG02) NO_MERGE */
                 TRUNC(T.DTJOUR_DT) TRANSACTION_DT,
                 TRUNC(T.DTINTER_DT) VALUE_DT,
                 T.LIBELLE LABEL,
                 T.CODECR CODECR_F,
                 SUBSTR(T.LIBELLE,
                        1,
                        DECODE(INSTR(T.LIBELLE, ':'),
                               0,
                               60,
                               (INSTR(T.LIBELLE, ':')) - 1)) LIB_A,
                 DECODE(INSTR(T.LIBELLE, ':'),
                        0,
                        '',
                        SUBSTR(T.LIBELLE, INSTR(T.LIBELLE, ':'))) LIB_B,
                 T.MNT_DCPT AMOUNT_DCMP,
                 1 NB,
                 T.REFELEM REFELEM,
                 C.REFLOT REFDOSS_DCMP,
                 'CIT' || T.CODECR CODECR,
                 NULL REFEXT,
                 NULL RETENTIONINDIC,
                 DECODE(T.ORIG_REFLOT,
                        T.REFDOSS,
                        NVL2(M.REFJOUR, M.ORIG_REFLOT, 'NP'),
                        T.ORIG_REFLOT) MEMO_DECOMPTE
                  FROM G_DOSSIER C, T_ECRDOS T, G_ELEMFI G, T_ECRDOS_TEMP M
                 WHERE C.REFLOT = :B8
                   AND T.REFDOSS = C.REFDOSS
                   AND (:B7 IS NULL AND :B6 IS NULL OR
                       DECODE(T.ORIG_REFLOT,
                               T.REFDOSS,
                               NVL2(M.REFJOUR, :B5, 'NP'),
                               T.ORIG_REFLOT) BETWEEN NVL(:B6, :B7) AND
                       NVL(:B7, :B6))
                   AND T.CODECR IN ('PRIN', 'APRIN')
                   AND G.REFELEM = T.REFELEM
                   AND G.REFDOSS = C.REFDOSS
                   AND G.TYPE IN ('SAF CN COMP', 'DRAFT')
                   AND (M.ORIG_REFLOT = :B3 AND T.ORIG_REFLOT = T.REFDOSS OR
                       :B5 = 'NP' AND M.ORIG_REFLOT IS NULL AND
                       T.ORIG_REFLOT = T.REFDOSS OR
                       :B4 IS NULL AND :B3 IS NULL AND
                       T.DTJOUR <= NVL(:B2, T.DTJOUR) AND
                       T.DTINTER <= NVL(:B1, T.DTINTER) OR
                       :B4 = 'CIT' || T.CODECR AND :B3 IS NULL AND
                       T.DTJOUR = NVL(:B2, T.DTJOUR) AND
                       T.DTINTER = NVL(:B1, T.DTINTER))
                   AND M.REFJOUR(+) = T.REFJOUR)
        UNION ALL
        SELECT TRANSACTION_DT TRANSACTION_DT,
               VALUE_DT VALUE_DT,
               LABEL LABEL,
               (SELECT IMX.FTRANSLATE_STR(LIB_A, :B11, CODECR_F) FROM DUAL) ||
               LIB_B LABEL_DESC,
               AMOUNT_DCMP AMOUNT_DCMP,
               NB NB,
               REFELEM REFELEM,
               REFDOSS_DCMP REFDOSS_DCMP,
               CODECR CODECR,
               REFEXT REFEXT,
               RETENTIONINDIC RETENTIONINDIC,
               MEMO_DECOMPTE MEMO_DECOMPTE
          FROM (SELECT
                /*+ leading(C G T) index(G G_ELEMFI_DOS_TYP_FG02) NO_MERGE */
                 TRUNC(T.DTJOUR_DT) TRANSACTION_DT,
                 TRUNC(T.DTINTER_DT) VALUE_DT,
                 T.LIBELLE LABEL,
                 T.CODECR CODECR_F,
                 SUBSTR(T.LIBELLE,
                        1,
                        DECODE(INSTR(T.LIBELLE, ':'),
                               0,
                               60,
                               (INSTR(T.LIBELLE, ':')) - 1)) LIB_A,
                 DECODE(INSTR(T.LIBELLE, ':'),
                        0,
                        '',
                        SUBSTR(T.LIBELLE, INSTR(T.LIBELLE, ':'))) LIB_B,
                 T.MNT_DCPT AMOUNT_DCMP,
                 1 NB,
                 T.REFELEM REFELEM,
                 C.REFLOT REFDOSS_DCMP,
                 'CIT' || T.CODECR CODECR,
                 NULL REFEXT,
                 NULL RETENTIONINDIC,
                 DECODE(T.ORIG_REFLOT,
                        T.REFDOSS,
                        NVL2(M.REFJOUR, M.ORIG_REFLOT, 'NP'),
                        T.ORIG_REFLOT) MEMO_DECOMPTE
                  FROM G_DOSSIER C, T_ECRDOS T, G_ELEMFI G, T_ECRDOS_TEMP M
                 WHERE :B13 = 'O'
                   AND C.REFLOT = :B8
                   AND T.REFDOSS = C.REFDOSS
                   AND (:B7 IS NULL AND :B6 IS NULL OR
                       DECODE(T.ORIG_REFLOT,
                               T.REFDOSS,
                               NVL2(M.REFJOUR, :B5, 'NP'),
                               T.ORIG_REFLOT) BETWEEN NVL(:B6, :B7) AND
                       NVL(:B7, :B6))
                   AND T.CODECR IN ('PRIN', 'APRIN')
                   AND G.REFELEM = T.REFELEM
                   AND G.REFDOSS = C.REFDOSS
                   AND G.TYPE IN ('OPERATION DIVERSE 
  CREDITRICE',
                                  'OPERATION DIVERSE DEBITRICE')
                   AND (M.ORIG_REFLOT = :B3 AND T.ORIG_REFLOT = T.REFDOSS OR
                       :B5 = 'NP' AND M.ORIG_REFLOT IS NULL AND
                       T.ORIG_REFLOT = T.REFDOSS OR
                       :B4 IS NULL AND :B3 IS NULL AND
                       T.DTJOUR <= NVL(:B2, T.DTJOUR) AND
                       T.DTINTER <= NVL(:B1, T.DTINTER) OR
                       :B4 = 'CIT' || T.CODECR AND :B3 IS NULL AND
                       T.DTJOUR = NVL(:B2, T.DTJOUR) AND
                       T.DTINTER = NVL(:B1, T.DTINTER))
                   AND M.REFJOUR(+) = T.REFJOUR)
        UNION ALL
        SELECT TRANSACTION_DT TRANSACTION_DT,
               VALUE_DT VALUE_DT,
               LABEL LABEL,
               (SELECT IMX.FTRANSLATE_STR(LIB_A, :B11, CODECR_F) FROM DUAL) ||
               LIB_B LABEL_DESC,
               AMOUNT_DCMP AMOUNT_DCMP,
               NB NB,
               REFELEM REFELEM,
               REFDOSS_DCMP REFDOSS_DCMP,
               CODECR CODECR,
               REFEXT REFEXT,
               RETENTIONINDIC RETENTIONINDIC,
               MEMO_DECOMPTE MEMO_DECOMPTE
          FROM (SELECT /*+ leading(C G T) index(G 
                  G_ELEMFI_DOS_TYP_FG02) NO_MERGE */
                 TRUNC(T.DTJOUR_DT) TRANSACTION_DT,
                 TRUNC(T.DTINTER_DT) VALUE_DT,
                 T.LIBELLE LABEL,
                 T.CODECR CODECR_F,
                 SUBSTR(T.LIBELLE,
                        1,
                        DECODE(INSTR(T.LIBELLE, ':'),
                               0,
                               60,
                               (INSTR(T.LIBELLE, ':')) - 1)) LIB_A,
                 DECODE(INSTR(T.LIBELLE, ':'),
                        0,
                        '',
                        SUBSTR(T.LIBELLE, INSTR(T.LIBELLE, ':'))) LIB_B,
                 T.MNT_DCPT AMOUNT_DCMP,
                 1 NB,
                 T.REFELEM REFELEM,
                 C.REFLOT REFDOSS_DCMP,
                 'CIT' || T.CODECR CODECR,
                 NULL REFEXT,
                 NULL RETENTIONINDIC,
                 DECODE(T.ORIG_REFLOT,
                        T.REFDOSS,
                        NVL2(M.REFJOUR, M.ORIG_REFLOT, 'NP'),
                        T.ORIG_REFLOT) MEMO_DECOMPTE
                  FROM G_DOSSIER C, T_ECRDOS T, G_ELEMFI G, T_ECRDOS_TEMP M
                 WHERE :B13 = 'O'
                   AND C.REFLOT = :B8
                   AND T.REFDOSS = C.REFDOSS
                   AND (:B7 IS NULL AND :B6 IS NULL OR
                       DECODE(T.ORIG_REFLOT,
                               T.REFDOSS,
                               NVL2(M.REFJOUR, :B5, 'NP'),
                               T.ORIG_REFLOT) BETWEEN NVL(:B6, :B7) AND
                       NVL(:B7, :B6))
                   AND T.CODECR IN ('DPRIN', 'ADPRI')
                   AND G.REFELEM = T.REFELEM
                   AND G.REFDOSS = C.REFDOSS
                   AND G.TYPE IN ('ANNULATION ODC', 'ANNULATION ODD')
                   AND (M.ORIG_REFLOT = :B3 AND T.ORIG_REFLOT = T.REFDOSS OR
                       :B5 = 'NP' AND M.ORIG_REFLOT IS NULL AND
                       T.ORIG_REFLOT = T.REFDOSS OR
                       :B4 IS NULL AND :B3 IS NULL AND
                       T.DTJOUR <= NVL(:B2, T.DTJOUR) AND
                       T.DTINTER <= NVL(:B1, T.DTINTER) OR
                       :B4 = 'CIT' || T.CODECR AND :B3 IS NULL AND
                       T.DTJOUR = NVL(:B2, T.DTJOUR) AND
                       T.DTINTER = NVL(:B1, T.DTINTER))
                   AND M.REFJOUR(+) = T.REFJOUR)
        UNION ALL
        SELECT ARCH.MAX_ARCH_TRANS_DATE TRANSACTION_DT,
               ARCH.MAX_ARCH_VALUE_DATE VALUE_DT,
               'ARCHIVED CIT BALANCE' LABEL,
               (SELECT IMX.FTRANSLATE_STR('ARCHIVED CIT BALANCE',
                                          :B11,
                                          ARCH.TYPE_BALANCE)
                  FROM DUAL) LABEL_DESC,
               ARCH.AMOUNT_ARCH_PART_BAL AMOUNT_DCMP,
               ARCH.ARCH_COUNTER NB,
               NULL REFELEM,
               ARCH.REFDOSS REFDOSS_DCMP,
               'CITARCHBAL' CODECR,
               NULL REFEXT,
               NULL RETENTIONINDIC,
               ARCH.MAX_MEMO_DECOMPTE MEMO_DECOMPTE
          FROM T_ARCH_DCPT_BALANCES ARCH
         WHERE TYPE_BALANCE = 'CIT'
           AND REFDOSS = :B8
           AND (:B4 IS NULL AND
               TO_CHAR(ARCH.MAX_ARCH_TRANS_DATE, 'j') <=
               NVL(:B2, TO_CHAR(ARCH.MAX_ARCH_TRANS_DATE, 'j')) AND
               TO_CHAR(ARCH.MAX_ARCH_VALUE_DATE, 'j') <=
               NVL(:B1, TO_CHAR(ARCH.MAX_ARCH_VALUE_DATE, 'j')) OR
               :B4 = 'CITARCHBAL' AND
               TO_CHAR(ARCH.MAX_ARCH_TRANS_DATE, 'j') =
               NVL(:B2, TO_CHAR(ARCH.MAX_ARCH_TRANS_DATE, 'j')) AND
               TO_CHAR(ARCH.MAX_ARCH_VALUE_DATE, 'j') =
               NVL(:B1, TO_CHAR(ARCH.MAX_ARCH_VALUE_DATE, 'j')))
           AND ARCH.MAX_MEMO_DECOMPTE = :B5
           AND (:B7 IS NULL AND :B6 IS NULL OR
               ARCH.MAX_MEMO_DECOMPTE BETWEEN NVL(:B6, :B7) AND
               NVL(:B7, :B6)))
 ORDER BY CASE
            WHEN MEMO_DECOMPTE = 'NP' THEN
             3
            WHEN LENGTH(MEMO_DECOMPTE) = 8 THEN
             2
            ELSE
             1
          END,
          DECODE(LENGTH(MEMO_DECOMPTE), 8, MEMO_DECOMPTE),
          TRANSACTION_DT,
          DECODE(CODECR,
                 'CIT' || 'pmtSAF_ajust',
                 2,
                 'CIT' || 'pmtSAF_sd_deduc',
                 2,
                 'CITARCHBAL',
                 2,
                 1),
          DECODE(SIGN(AMOUNT_DCMP), 1, 2, 1),
          REFELEM;
/********************************OLD SQL*******************************************/
/********************************OLD Metrics***************************************/
/*
Plan hash value: 2131740291
-------------------------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                     | Name                        | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  |
-------------------------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                              |                             |      1 |        |   259 (100)|      0 |00:00:12.21 |     113K|  23664 |
|   1 |  SORT ORDER BY                                |                             |      1 |    128 |   259   (2)|      0 |00:00:12.21 |     113K|  23664 |
|   2 |   VIEW                                        |                             |      1 |    128 |   258   (2)|      0 |00:00:12.21 |     113K|  23664 |
|   3 |    UNION-ALL                                  |                             |      1 |        |            |      0 |00:00:12.21 |     113K|  23664 |
|*  4 |     FILTER                                    |                             |      1 |        |            |      0 |00:00:00.08 |    4576 |    778 |
|*  5 |      TABLE ACCESS BY INDEX ROWID BATCHED      | NAM_COLLECTE                |      1 |      1 |     1   (0)|      0 |00:00:00.08 |    4576 |    778 |
|*  6 |       INDEX RANGE SCAN                        | NAM_COLLECTE_DTEXTR_IDX     |      1 |    121 |     1   (0)|   7772 |00:00:00.01 |      35 |     35 |
|*  7 |      TABLE ACCESS BY INDEX ROWID BATCHED      | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*  8 |       INDEX RANGE SCAN                        | V_DOMAINE_TYPE_CODE_IDX     |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|   9 |     FAST DUAL                                 |                             |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 10 |     FILTER                                    |                             |      1 |        |            |      0 |00:00:11.73 |     106K|  22179 |
|  11 |      NESTED LOOPS OUTER                       |                             |      1 |    122 |    24   (0)|      0 |00:00:11.73 |     106K|  22179 |
|  12 |       NESTED LOOPS                            |                             |      1 |    122 |    23   (0)|      0 |00:00:11.73 |     106K|  22179 |
|  13 |        NESTED LOOPS                           |                             |      1 |    400 |    11   (0)|  46765 |00:00:03.98 |   12588 |   7732 |
|* 14 |         INDEX RANGE SCAN                      | G_DOSSIER_RL_CD_RD_RF_IDX   |      1 |    120 |     1   (0)|    143 |00:00:00.01 |       4 |      3 |
|  15 |         TABLE ACCESS BY INDEX ROWID BATCHED   | T_ECRDOS                    |    143 |      3 |     1   (0)|  46765 |00:00:03.97 |   12584 |   7729 |
|* 16 |          INDEX RANGE SCAN                     | TECR_REFDOSS_DTJOUR         |    143 |     11 |     1   (0)|  46765 |00:00:00.25 |     936 |    686 |
|* 17 |        TABLE ACCESS BY INDEX ROWID            | G_ENCAISSEMENT              |  46765 |      1 |     1   (0)|      0 |00:00:07.74 |   94200 |  14447 |
|* 18 |         INDEX UNIQUE SCAN                     | REFENCAISS                  |  46765 |      1 |     1   (0)|  46765 |00:00:01.15 |   47435 |   2015 |
|  19 |       TABLE ACCESS BY INDEX ROWID             | T_ECRDOS_TEMP               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 20 |        INDEX UNIQUE SCAN                      | T_ECRDOS_TEMP_PK            |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|  21 |     SORT UNIQUE                               |                             |      0 |     22 |    24   (9)|      0 |00:00:00.01 |       0 |      0 |
|  22 |      WINDOW SORT                              |                             |      0 |     22 |    24   (9)|      0 |00:00:00.01 |       0 |      0 |
|  23 |       VIEW                                    | V_FPARFAC                   |      0 |     22 |    22   (0)|      0 |00:00:00.01 |       0 |      0 |
|  24 |        UNION-ALL                              |                             |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  25 |         VIEW                                  | VW_ORE_5BE70045             |      0 |      2 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|  26 |          UNION-ALL                            |                             |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|* 27 |           FILTER                              |                             |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  28 |            TABLE ACCESS BY INDEX ROWID BATCHED| F_PARFAC                    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 29 |             INDEX RANGE SCAN                  | PARFAC_CL1                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 30 |           FILTER                              |                             |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  31 |            TABLE ACCESS BY INDEX ROWID        | F_PARFAC                    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 32 |             INDEX UNIQUE SCAN                 | PARFAC_CL1                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|  33 |         VIEW                                  | VW_ORE_68712886             |      0 |      2 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|  34 |          UNION-ALL                            |                             |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|* 35 |           FILTER                              |                             |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  36 |            TABLE ACCESS BY INDEX ROWID BATCHED| F_PARFAC                    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 37 |             INDEX RANGE SCAN                  | PARFAC_CL1                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 38 |           FILTER                              |                             |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  39 |            TABLE ACCESS BY INDEX ROWID        | F_PARFAC                    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 40 |             INDEX UNIQUE SCAN                 | PARFAC_CL1                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|  41 |         VIEW                                  | VW_ORE_75F612E2             |      0 |      2 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|  42 |          UNION-ALL                            |                             |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|* 43 |           FILTER                              |                             |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  44 |            TABLE ACCESS BY INDEX ROWID BATCHED| F_PARFAC                    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 45 |             INDEX RANGE SCAN                  | PARFAC_CL1                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 46 |           FILTER                              |                             |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  47 |            TABLE ACCESS BY INDEX ROWID        | F_PARFAC                    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 48 |             INDEX UNIQUE SCAN                 | PARFAC_CL1                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|  49 |         VIEW                                  | VW_ORE_711C0EE8             |      0 |      2 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|  50 |          UNION-ALL                            |                             |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|* 51 |           FILTER                              |                             |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  52 |            TABLE ACCESS BY INDEX ROWID BATCHED| F_PARFAC                    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 53 |             INDEX RANGE SCAN                  | PARFAC_CL1                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 54 |           FILTER                              |                             |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  55 |            TABLE ACCESS BY INDEX ROWID        | F_PARFAC                    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 56 |             INDEX UNIQUE SCAN                 | PARFAC_CL1                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|  57 |         VIEW                                  | VW_ORE_51F005CD             |      0 |      2 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|  58 |          UNION-ALL                            |                             |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|* 59 |           FILTER                              |                             |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  60 |            TABLE ACCESS BY INDEX ROWID BATCHED| F_PARFAC                    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 61 |             INDEX RANGE SCAN                  | PARFAC_CL1                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 62 |           FILTER                              |                             |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  63 |            TABLE ACCESS BY INDEX ROWID        | F_PARFAC                    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 64 |             INDEX UNIQUE SCAN                 | PARFAC_CL1                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|  65 |         VIEW                                  | VW_ORE_A152B67F             |      0 |      2 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|  66 |          UNION-ALL                            |                             |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|* 67 |           FILTER                              |                             |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  68 |            TABLE ACCESS BY INDEX ROWID BATCHED| F_PARFAC                    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 69 |             INDEX RANGE SCAN                  | PARFAC_CL1                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 70 |           FILTER                              |                             |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  71 |            TABLE ACCESS BY INDEX ROWID        | F_PARFAC                    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 72 |             INDEX UNIQUE SCAN                 | PARFAC_CL1                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|  73 |         VIEW                                  | VW_ORE_6C302822             |      0 |      2 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|  74 |          UNION-ALL                            |                             |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|* 75 |           FILTER                              |                             |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  76 |            TABLE ACCESS BY INDEX ROWID BATCHED| F_PARFAC                    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 77 |             INDEX RANGE SCAN                  | PARFAC_CL1                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 78 |           FILTER                              |                             |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  79 |            TABLE ACCESS BY INDEX ROWID        | F_PARFAC                    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 80 |             INDEX UNIQUE SCAN                 | PARFAC_CL1                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|  81 |         VIEW                                  | VW_ORE_5DB9CF8E             |      0 |      2 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|  82 |          UNION-ALL                            |                             |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|* 83 |           FILTER                              |                             |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  84 |            TABLE ACCESS BY INDEX ROWID BATCHED| F_PARFAC                    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 85 |             INDEX RANGE SCAN                  | PARFAC_CL1                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 86 |           FILTER                              |                             |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  87 |            TABLE ACCESS BY INDEX ROWID        | F_PARFAC                    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 88 |             INDEX UNIQUE SCAN                 | PARFAC_CL1                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|  89 |         VIEW                                  | VW_ORE_06F77713             |      0 |      2 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|  90 |          UNION-ALL                            |                             |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|* 91 |           FILTER                              |                             |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  92 |            TABLE ACCESS BY INDEX ROWID BATCHED| F_PARFAC                    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 93 |             INDEX RANGE SCAN                  | PARFAC_CL1                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 94 |           FILTER                              |                             |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  95 |            TABLE ACCESS BY INDEX ROWID        | F_PARFAC                    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 96 |             INDEX UNIQUE SCAN                 | PARFAC_CL1                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|  97 |         VIEW                                  | VW_ORE_31A15E1C             |      0 |      2 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|  98 |          UNION-ALL                            |                             |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|* 99 |           FILTER                              |                             |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 100 |            TABLE ACCESS BY INDEX ROWID BATCHED| F_PARFAC                    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*101 |             INDEX RANGE SCAN                  | PARFAC_CL1                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*102 |           FILTER                              |                             |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 103 |            TABLE ACCESS BY INDEX ROWID        | F_PARFAC                    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*104 |             INDEX UNIQUE SCAN                 | PARFAC_CL1                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 105 |         VIEW                                  | VW_ORE_76C38685             |      0 |      2 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
| 106 |          UNION-ALL                            |                             |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*107 |           FILTER                              |                             |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 108 |            TABLE ACCESS BY INDEX ROWID BATCHED| F_PARFAC                    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*109 |             INDEX RANGE SCAN                  | PARFAC_CL1                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*110 |           FILTER                              |                             |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 111 |            TABLE ACCESS BY INDEX ROWID        | F_PARFAC                    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*112 |             INDEX UNIQUE SCAN                 | PARFAC_CL1                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 113 |     INLIST ITERATOR                           |                             |      1 |        |            |      0 |00:00:00.01 |       8 |      6 |
|*114 |      TABLE ACCESS BY INDEX ROWID BATCHED      | T_ECRDOS                    |      2 |      1 |     1   (0)|      0 |00:00:00.01 |       8 |      6 |
|*115 |       INDEX RANGE SCAN                        | TECR$REFDOSS_CODECR_DTINTER |      2 |      6 |     1   (0)|      0 |00:00:00.01 |       8 |      6 |
| 116 |     FAST DUAL                                 |                             |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
| 117 |     VIEW                                      |                             |      1 |      1 |    26   (0)|      0 |00:00:00.39 |    1800 |    701 |
|*118 |      FILTER                                   |                             |      1 |        |            |      0 |00:00:00.39 |    1800 |    701 |
| 119 |       NESTED LOOPS OUTER                      |                             |      1 |      1 |    26   (0)|    268 |00:00:00.39 |    1800 |    701 |
| 120 |        NESTED LOOPS                           |                             |      1 |      1 |    25   (0)|    268 |00:00:00.39 |    1791 |    699 |
| 121 |         NESTED LOOPS                          |                             |      1 |    354 |     7   (0)|    268 |00:00:00.29 |     669 |    542 |
|*122 |          INDEX RANGE SCAN                     | G_DOSSIER_RL_CD_RD_RF_IDX   |      1 |    120 |     1   (0)|    143 |00:00:00.01 |       4 |      0 |
| 123 |          TABLE ACCESS BY INDEX ROWID BATCHED  | G_ELEMFI                    |    143 |      3 |     1   (0)|    268 |00:00:00.29 |     665 |    542 |
|*124 |           INDEX RANGE SCAN                    | G_ELEMFI_DOS_TYP_FG02       |    143 |      3 |     1   (0)|    268 |00:00:00.19 |     499 |    381 |
|*125 |         TABLE ACCESS BY INDEX ROWID BATCHED   | T_ECRDOS                    |    268 |      1 |     1   (0)|    268 |00:00:00.10 |    1122 |    157 |
|*126 |          INDEX RANGE SCAN                     | TECR_REFELEM                |    268 |      2 |     1   (0)|    657 |00:00:00.05 |     635 |     76 |
| 127 |        TABLE ACCESS BY INDEX ROWID            | T_ECRDOS_TEMP               |    268 |      1 |     1   (0)|      0 |00:00:00.01 |       9 |      2 |
|*128 |         INDEX UNIQUE SCAN                     | T_ECRDOS_TEMP_PK            |    268 |      1 |     1   (0)|      0 |00:00:00.01 |       9 |      2 |
| 129 |     FAST DUAL                                 |                             |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
| 130 |     VIEW                                      |                             |      1 |      1 |    26   (0)|      0 |00:00:00.01 |       0 |      0 |
|*131 |      FILTER                                   |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*132 |       FILTER                                  |                             |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 133 |        NESTED LOOPS OUTER                     |                             |      0 |      1 |    26   (0)|      0 |00:00:00.01 |       0 |      0 |
| 134 |         NESTED LOOPS                          |                             |      0 |      1 |    25   (0)|      0 |00:00:00.01 |       0 |      0 |
| 135 |          NESTED LOOPS                         |                             |      0 |    354 |     7   (0)|      0 |00:00:00.01 |       0 |      0 |
|*136 |           INDEX RANGE SCAN                    | G_DOSSIER_RL_CD_RD_RF_IDX   |      0 |    120 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 137 |           TABLE ACCESS BY INDEX ROWID BATCHED | G_ELEMFI                    |      0 |      3 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*138 |            INDEX RANGE SCAN                   | G_ELEMFI_DOS_TYP_FG02       |      0 |      3 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*139 |          TABLE ACCESS BY INDEX ROWID BATCHED  | T_ECRDOS                    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*140 |           INDEX RANGE SCAN                    | TECR_REFELEM                |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 141 |         TABLE ACCESS BY INDEX ROWID           | T_ECRDOS_TEMP               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*142 |          INDEX UNIQUE SCAN                    | T_ECRDOS_TEMP_PK            |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 143 |     FAST DUAL                                 |                             |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
| 144 |     VIEW                                      |                             |      1 |      1 |    26   (0)|      0 |00:00:00.01 |       0 |      0 |
|*145 |      FILTER                                   |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*146 |       FILTER                                  |                             |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 147 |        NESTED LOOPS OUTER                     |                             |      0 |      1 |    26   (0)|      0 |00:00:00.01 |       0 |      0 |
| 148 |         NESTED LOOPS                          |                             |      0 |      1 |    25   (0)|      0 |00:00:00.01 |       0 |      0 |
| 149 |          NESTED LOOPS                         |                             |      0 |    354 |     7   (0)|      0 |00:00:00.01 |       0 |      0 |
|*150 |           INDEX RANGE SCAN                    | G_DOSSIER_RL_CD_RD_RF_IDX   |      0 |    120 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 151 |           TABLE ACCESS BY INDEX ROWID BATCHED | G_ELEMFI                    |      0 |      3 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*152 |            INDEX RANGE SCAN                   | G_ELEMFI_DOS_TYP_FG02       |      0 |      3 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*153 |          TABLE ACCESS BY INDEX ROWID BATCHED  | T_ECRDOS                    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*154 |           INDEX RANGE SCAN                    | TECR_REFELEM                |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 155 |         TABLE ACCESS BY INDEX ROWID           | T_ECRDOS_TEMP               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*156 |          INDEX UNIQUE SCAN                    | T_ECRDOS_TEMP_PK            |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 157 |     FAST DUAL                                 |                             |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*158 |     TABLE ACCESS BY INDEX ROWID BATCHED       | T_ARCH_DCPT_BALANCES        |      1 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*159 |      INDEX RANGE SCAN                         | T_ARCH_D_MAX_DCMPT_IDX      |      1 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
-------------------------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   4 - filter(("CODOP" IS NULL OR  IS NULL))
   5 - filter((((:B4 IS NULL AND :B3 IS NULL AND DECODE("TYPMVT",'pmtSAF_ajust',"DTVENTIL",'pmtSAF_sd_deduc',"DTVENTIL","DTEXTRAIT")<=NVL(:B2,DECODE(
              "TYPMVT",'pmtSAF_ajust',"DTVENTIL",'pmtSAF_sd_deduc',"DTVENTIL","DTEXTRAIT")) AND
              DECODE("TYPMVT",'pmtSAF_ajust',"DTVENTIL",'pmtSAF_sd_deduc',"DTVENTIL",TO_NUMBER(TO_CHAR(INTERNAL_FUNCTION("DT_RECONCILIATION_DT"),'j')))<=NVL(:B1,DE
              CODE("TYPMVT",'pmtSAF_ajust',"DTVENTIL",'pmtSAF_sd_deduc',"DTVENTIL",TO_NUMBER(TO_CHAR(INTERNAL_FUNCTION("DT_RECONCILIATION_DT"),'j'))))) OR (:B3 IS
              NULL AND 'CIT'||"TYPMVT"=:B4 AND DECODE("TYPMVT",'pmtSAF_ajust',"DTVENTIL",'pmtSAF_sd_deduc',"DTVENTIL","DTEXTRAIT")=NVL(:B2,DECODE("TYPMVT",'pmtSAF_
              ajust',"DTVENTIL",'pmtSAF_sd_deduc',"DTVENTIL","DTEXTRAIT")) AND DECODE("TYPMVT",'pmtSAF_ajust',"DTVENTIL",'pmtSAF_sd_deduc',"DTVENTIL",TO_NUMBER(TO_
              CHAR(INTERNAL_FUNCTION("DT_RECONCILIATION_DT"),'j')))=NVL(:B1,DECODE("TYPMVT",'pmtSAF_ajust',"DTVENTIL",'pmtSAF_sd_deduc',"DTVENTIL",TO_NUMBER(TO_CHA
              R(INTERNAL_FUNCTION("DT_RECONCILIATION_DT"),'j'))))) OR "MEMO_DECOMPTE"=:B5) AND INTERNAL_FUNCTION("ETAT") AND ((:B7 IS NULL AND :B6 IS NULL) OR
              ("MEMO_DECOMPTE">=NVL(:B6,:B7) AND "MEMO_DECOMPTE"<=NVL(:B7,:B6))) AND INTERNAL_FUNCTION("TYPMVT")))
   6 - access("REFDOSS"=:B8)
   7 - filter(("OBL"='O' AND "ABREV2" IS NULL AND "CHAMP"<>'DO NOT PROCESS' AND
              LNNVL("CHEMIN"||LPAD(TO_CHAR("PLACE"),2,'0')||LPAD("COMMENTAIRE",2,'0')||LPAD("ECRAN",3,'0')<>:B1)))
   8 - access("TYPE"='OPCODE_COMBINATIONS')
  10 - filter((((:B7 IS NULL AND :B6 IS NULL) OR (DECODE("T"."ORIG_REFLOT","T"."REFDOSS",NVL2("M"."REFJOUR",:B5,'NP'),"T"."ORIG_REFLOT")>=NVL(:B6,:B7
              ) AND DECODE("T"."ORIG_REFLOT","T"."REFDOSS",NVL2("M"."REFJOUR",:B5,'NP'),"T"."ORIG_REFLOT")<=NVL(:B7,:B6))) AND (("M"."ORIG_REFLOT"=:B3 AND
              "T"."ORIG_REFLOT"="T"."REFDOSS") OR (:B5='NP' AND "M"."ORIG_REFLOT" IS NULL AND "T"."ORIG_REFLOT"="T"."REFDOSS") OR (:B4 IS NULL AND :B3 IS NULL AND
              "T"."DTJOUR"<=NVL(:B2,"T"."DTJOUR") AND "T"."DTINTER"<=NVL(:B1,"T"."DTINTER")) OR ('CIT'||"T"."CODECR"=:B4 AND :B3 IS NULL AND
              "T"."DTJOUR"=NVL(:B2,"T"."DTJOUR") AND "T"."DTINTER"=NVL(:B1,"T"."DTINTER")))))
  14 - access("C"."REFLOT"=:B8)
  16 - access("T"."REFDOSS"="C"."REFDOSS")
       filter(("T"."CODECR"='AENAT' OR "T"."CODECR"='ARFIN' OR "T"."CODECR"='ENCAT' OR "T"."CODECR"='RFIN'))
  17 - filter(("E"."MOYENPAIMT"='PAIEMENT   DECLARE' AND "E"."TYPENCAISS"='e_saencaiss'))
  18 - access("E"."REFENCAISS"="T"."REFELEM")
  20 - access("M"."REFJOUR"="T"."REFJOUR")
  27 - filter('AL'=:B11)
  29 - access("PF_NOM"=:B1 AND "PF_REFFACTOR" IS NULL)
  30 - filter('AL'=:B11)
  32 - access("PF_NOM"=:B1 AND "PF_REFFACTOR"=:B12)
       filter(LNNVL("PF_REFFACTOR" IS NULL))
  35 - filter('AN'=:B11)
  37 - access("PF_NOM"=:B1 AND "PF_REFFACTOR" IS NULL)
  38 - filter('AN'=:B11)
  40 - access("PF_NOM"=:B1 AND "PF_REFFACTOR"=:B12)
       filter(LNNVL("PF_REFFACTOR" IS NULL))
  43 - filter('DA'=:B11)
  45 - access("PF_NOM"=:B1 AND "PF_REFFACTOR" IS NULL)
  46 - filter('DA'=:B11)
  48 - access("PF_NOM"=:B1 AND "PF_REFFACTOR"=:B12)
       filter(LNNVL("PF_REFFACTOR" IS NULL))
  51 - filter('ES'=:B11)
  53 - access("PF_NOM"=:B1 AND "PF_REFFACTOR" IS NULL)
  54 - filter('ES'=:B11)
  56 - access("PF_NOM"=:B1 AND "PF_REFFACTOR"=:B12)
       filter(LNNVL("PF_REFFACTOR" IS NULL))
  59 - filter('FI'=:B11)
  61 - access("PF_NOM"=:B1 AND "PF_REFFACTOR" IS NULL)
  62 - filter('FI'=:B11)
  64 - access("PF_NOM"=:B1 AND "PF_REFFACTOR"=:B12)
       filter(LNNVL("PF_REFFACTOR" IS NULL))
  67 - filter('FR'=:B11)
  69 - access("PF_NOM"=:B1 AND "PF_REFFACTOR" IS NULL)
  70 - filter('FR'=:B11)
  72 - access("PF_NOM"=:B1 AND "PF_REFFACTOR"=:B12)
       filter(LNNVL("PF_REFFACTOR" IS NULL))
  75 - filter('HU'=:B11)
  77 - access("PF_NOM"=:B1 AND "PF_REFFACTOR" IS NULL)
  78 - filter('HU'=:B11)
  80 - access("PF_NOM"=:B1 AND "PF_REFFACTOR"=:B12)
       filter(LNNVL("PF_REFFACTOR" IS NULL))
  83 - filter('IT'=:B11)
  85 - access("PF_NOM"=:B1 AND "PF_REFFACTOR" IS NULL)
  86 - filter('IT'=:B11)
  88 - access("PF_NOM"=:B1 AND "PF_REFFACTOR"=:B12)
       filter(LNNVL("PF_REFFACTOR" IS NULL))
  91 - filter('NL'=:B11)
  93 - access("PF_NOM"=:B1 AND "PF_REFFACTOR" IS NULL)
  94 - filter('NL'=:B11)
  96 - access("PF_NOM"=:B1 AND "PF_REFFACTOR"=:B12)
       filter(LNNVL("PF_REFFACTOR" IS NULL))
  99 - filter('NO'=:B11)
 101 - access("PF_NOM"=:B1 AND "PF_REFFACTOR" IS NULL)
 102 - filter('NO'=:B11)
 104 - access("PF_NOM"=:B1 AND "PF_REFFACTOR"=:B12)
       filter(LNNVL("PF_REFFACTOR" IS NULL))
 107 - filter('PT'=:B11)
 109 - access("PF_NOM"=:B1 AND "PF_REFFACTOR" IS NULL)
 110 - filter('PT'=:B11)
 112 - access("PF_NOM"=:B1 AND "PF_REFFACTOR"=:B12)
       filter(LNNVL("PF_REFFACTOR" IS NULL))
 114 - filter((((:B4 IS NULL AND :B3 IS NULL AND "T"."DTINTER"<=NVL(:B1,"T"."DTINTER") AND "T"."DTJOUR"<=NVL(:B2,"T"."DTJOUR")) OR (:B3 IS NULL AND
              'CIT'||"CODECR"=:B4 AND "T"."DTJOUR"=NVL(:B2,"T"."DTJOUR") AND "T"."DTINTER"=NVL(:B1,"T"."DTINTER")) OR "T"."MEMO_DECOMPTE"=:B5) AND ((:B7 IS NULL
              AND :B6 IS NULL) OR ("T"."MEMO_DECOMPTE">=NVL(:B6,:B7) AND "T"."MEMO_DECOMPTE"<=NVL(:B7,:B6)))))
 115 - access("T"."REFDOSS"=:B8 AND (("T"."CODECR"='CRINS' OR "T"."CODECR"='RINDS')))
 118 - filter((((:B7 IS NULL AND :B6 IS NULL) OR (DECODE("T"."ORIG_REFLOT","T"."REFDOSS",NVL2("M"."REFJOUR",:B5,'NP'),"T"."ORIG_REFLOT")>=NVL(:B6,:B7
              ) AND DECODE("T"."ORIG_REFLOT","T"."REFDOSS",NVL2("M"."REFJOUR",:B5,'NP'),"T"."ORIG_REFLOT")<=NVL(:B7,:B6))) AND (("M"."ORIG_REFLOT"=:B3 AND
              "T"."ORIG_REFLOT"="T"."REFDOSS") OR (:B5='NP' AND "M"."ORIG_REFLOT" IS NULL AND "T"."ORIG_REFLOT"="T"."REFDOSS") OR (:B4 IS NULL AND :B3 IS NULL AND
              "T"."DTJOUR"<=NVL(:B2,"T"."DTJOUR") AND "T"."DTINTER"<=NVL(:B1,"T"."DTINTER")) OR ('CIT'||"T"."CODECR"=:B4 AND :B3 IS NULL AND
              "T"."DTJOUR"=NVL(:B2,"T"."DTJOUR") AND "T"."DTINTER"=NVL(:B1,"T"."DTINTER")))))
 122 - access("C"."REFLOT"=:B8)
 124 - access("G"."REFDOSS"="C"."REFDOSS")
       filter(("G"."TYPE"='DRAFT' OR "G"."TYPE"='SAF CN COMP'))
 125 - filter(("T"."REFDOSS"="C"."REFDOSS" AND INTERNAL_FUNCTION("T"."CODECR")))
 126 - access("G"."REFELEM"="T"."REFELEM")
 128 - access("M"."REFJOUR"="T"."REFJOUR")
 131 - filter(:B13='O')
 132 - filter((((:B7 IS NULL AND :B6 IS NULL) OR (DECODE("T"."ORIG_REFLOT","T"."REFDOSS",NVL2("M"."REFJOUR",:B5,'NP'),"T"."ORIG_REFLOT")>=NVL(:B6,:B7
              ) AND DECODE("T"."ORIG_REFLOT","T"."REFDOSS",NVL2("M"."REFJOUR",:B5,'NP'),"T"."ORIG_REFLOT")<=NVL(:B7,:B6))) AND (("M"."ORIG_REFLOT"=:B3 AND
              "T"."ORIG_REFLOT"="T"."REFDOSS") OR (:B5='NP' AND "M"."ORIG_REFLOT" IS NULL AND "T"."ORIG_REFLOT"="T"."REFDOSS") OR (:B4 IS NULL AND :B3 IS NULL AND
              "T"."DTJOUR"<=NVL(:B2,"T"."DTJOUR") AND "T"."DTINTER"<=NVL(:B1,"T"."DTINTER")) OR ('CIT'||"T"."CODECR"=:B4 AND :B3 IS NULL AND
              "T"."DTJOUR"=NVL(:B2,"T"."DTJOUR") AND "T"."DTINTER"=NVL(:B1,"T"."DTINTER")))))
 136 - access("C"."REFLOT"=:B8)
 138 - access("G"."REFDOSS"="C"."REFDOSS")
       filter(("G"."TYPE"='OPERATION DIVERSE   CREDITRICE' OR "G"."TYPE"='OPERATION DIVERSE DEBITRICE'))
 139 - filter(("T"."REFDOSS"="C"."REFDOSS" AND INTERNAL_FUNCTION("T"."CODECR")))
 140 - access("G"."REFELEM"="T"."REFELEM")
 142 - access("M"."REFJOUR"="T"."REFJOUR")
 145 - filter(:B13='O')
 146 - filter((((:B7 IS NULL AND :B6 IS NULL) OR (DECODE("T"."ORIG_REFLOT","T"."REFDOSS",NVL2("M"."REFJOUR",:B5,'NP'),"T"."ORIG_REFLOT")>=NVL(:B6,:B7
              ) AND DECODE("T"."ORIG_REFLOT","T"."REFDOSS",NVL2("M"."REFJOUR",:B5,'NP'),"T"."ORIG_REFLOT")<=NVL(:B7,:B6))) AND (("M"."ORIG_REFLOT"=:B3 AND
              "T"."ORIG_REFLOT"="T"."REFDOSS") OR (:B5='NP' AND "M"."ORIG_REFLOT" IS NULL AND "T"."ORIG_REFLOT"="T"."REFDOSS") OR (:B4 IS NULL AND :B3 IS NULL AND
              "T"."DTJOUR"<=NVL(:B2,"T"."DTJOUR") AND "T"."DTINTER"<=NVL(:B1,"T"."DTINTER")) OR ('CIT'||"T"."CODECR"=:B4 AND :B3 IS NULL AND
              "T"."DTJOUR"=NVL(:B2,"T"."DTJOUR") AND "T"."DTINTER"=NVL(:B1,"T"."DTINTER")))))
 150 - access("C"."REFLOT"=:B8)
 152 - access("G"."REFDOSS"="C"."REFDOSS")
       filter(("G"."TYPE"='ANNULATION ODC' OR "G"."TYPE"='ANNULATION ODD'))
 153 - filter(("T"."REFDOSS"="C"."REFDOSS" AND INTERNAL_FUNCTION("T"."CODECR")))
 154 - access("G"."REFELEM"="T"."REFELEM")
 156 - access("M"."REFJOUR"="T"."REFJOUR")
 158 - filter(("REFDOSS"=:B8 AND "TYPE_BALANCE"='CIT' AND ((:B4 IS NULL AND
              TO_NUMBER(TO_CHAR(INTERNAL_FUNCTION("ARCH"."MAX_ARCH_TRANS_DATE"),'j'))<=NVL(:B2,TO_NUMBER(TO_CHAR(INTERNAL_FUNCTION("ARCH"."MAX_ARCH_TRANS_DATE"),'j
              '))) AND TO_NUMBER(TO_CHAR(INTERNAL_FUNCTION("ARCH"."MAX_ARCH_VALUE_DATE"),'j'))<=NVL(:B1,TO_NUMBER(TO_CHAR(INTERNAL_FUNCTION("ARCH"."MAX_ARCH_VALUE_
              DATE"),'j')))) OR (:B4='CITARCHBAL' AND TO_NUMBER(TO_CHAR(INTERNAL_FUNCTION("ARCH"."MAX_ARCH_TRANS_DATE"),'j'))=NVL(:B2,TO_NUMBER(TO_CHAR(INTERNAL_FU
              NCTION("ARCH"."MAX_ARCH_TRANS_DATE"),'j'))) AND TO_NUMBER(TO_CHAR(INTERNAL_FUNCTION("ARCH"."MAX_ARCH_VALUE_DATE"),'j'))=NVL(:B1,TO_NUMBER(TO_CHAR(INT
              ERNAL_FUNCTION("ARCH"."MAX_ARCH_VALUE_DATE"),'j'))))) AND (("ARCH"."MAX_MEMO_DECOMPTE">=NVL(:B6,:B7) AND "ARCH"."MAX_MEMO_DECOMPTE"<=NVL(:B7,:B6))
              OR (:B7 IS NULL AND :B6 IS NULL))))
 159 - access("ARCH"."MAX_MEMO_DECOMPTE"=:B5)
*/
/********************************OLD Metrics***************************************/

/********************************New SQL*******************************************/
SELECT *
  FROM (SELECT DECODE(TYPMVT,
                      'pmtSAF_ajust',
                      TRUNC(DTVENTIL_DT),
                      'pmtSAF_sd_deduc',
                      TRUNC(DTVENTIL_DT),
                      TRUNC(DTEXTRAIT_DT)) TRANSACTION_DT,
               DECODE(TYPMVT,
                      'pmtSAF_ajust',
                      TRUNC(DTVENTIL_DT),
                      'pmtSAF_sd_deduc',
                      TRUNC(DTVENTIL_DT),
                      TRUNC(DT_RECONCILIATION_DT)) VALUE_DT,
               NULL LABEL,
               :B10 LABEL_DESC,
               DECODE(SIGNE, 1, -1, 1) *
               DECODE(TYPMVT, 'pmtSAF_ajust', -1, 'pmtSAF_sd_deduc', -1, 1) * CASE
                 WHEN MONTANT_MVT IS NOT NULL AND DEVISE_MVT = :B9 THEN
                  MONTANT_MVT
                 WHEN MONTANT_MVT_BQ IS NOT NULL AND DEVISE_MVT_BQ = :B9 THEN
                  MONTANT_MVT_BQ
                 WHEN MONTANT3 IS NOT NULL AND DEVISE3 = :B9 THEN
                  MONTANT3
                 WHEN DEVISE = :B9 THEN
                  NVL(MONTANT, 0)
                 ELSE
                  CH_TAUX.CONVERSMVTDOS(DTEXTRAIT,
                                        REFDOSS,
                                        NVL(MONTANT, 0),
                                        DEVISE,
                                        'A')
               END AMOUNT_DCMP,
               1 NB,
               COMPOSTAGE REFELEM,
               REFDOSS REFDOSS_DCMP,
               'CIT' || TYPMVT CODECR,
               NULL REFEXT,
               NULL RETENTIONINDIC,
               MEMO_DECOMPTE MEMO_DECOMPTE
          FROM NAM_COLLECTE
         WHERE REFDOSS = :B8
           AND (:B7 IS NULL AND :B6 IS NULL OR
               MEMO_DECOMPTE BETWEEN NVL(:B6, :B7) AND NVL(:B7, :B6))
           AND TYPMVT IN ('encSAF',
                          'encSAF_col',
                          'encSAF_derec',
                          'SAF',
                          'pmtSAF_ajust',
                          'pmtSAF_sd_deduc')
           AND (CODOP IS NULL OR
               CODOP NOT IN
               (SELECT CHEMIN || LPAD(PLACE, 2, '0') ||
                        LPAD(COMMENTAIRE, 2, '0') || LPAD(ECRAN, 3, '0')
                   FROM V_DOMAINE
                  WHERE TYPE = 'OPCODE_COMBINATIONS'
                    AND OBL = 'O'
                    AND ABREV2 IS NULL
                    AND CHAMP != 'DO NOT PROCESS'))
           AND ETAT IN ('RCI', 'RCP')
           AND (MEMO_DECOMPTE = :B5 OR
               :B4 IS NULL AND :B3 IS NULL AND
               DECODE(TYPMVT,
                       'pmtSAF_ajust',
                       DTVENTIL,
                       'pmtSAF_sd_deduc',
                       DTVENTIL,
                       DTEXTRAIT) <=
               NVL(:B2,
                    DECODE(TYPMVT,
                           'pmtSAF_ajust',
                           DTVENTIL,
                           'pmtSAF_sd_deduc',
                           DTVENTIL,
                           DTEXTRAIT)) AND
               DECODE(TYPMVT,
                       'pmtSAF_ajust',
                       DTVENTIL,
                       'pmtSAF_sd_deduc',
                       DTVENTIL,
                       TO_CHAR(DT_RECONCILIATION_DT, 'j')) <=
               NVL(:B1,
                    DECODE(TYPMVT,
                           'pmtSAF_ajust',
                           DTVENTIL,
                           'pmtSAF_sd_deduc',
                           DTVENTIL,
                           TO_CHAR(DT_RECONCILIATION_DT, 'j'))) OR
               :B4 = 'CIT' || TYPMVT AND :B3 IS NULL AND
               DECODE(TYPMVT,
                       'pmtSAF_ajust',
                       DTVENTIL,
                       'pmtSAF_sd_deduc',
                       DTVENTIL,
                       DTEXTRAIT) =
               NVL(:B2,
                    DECODE(TYPMVT,
                           'pmtSAF_ajust',
                           DTVENTIL,
                           'pmtSAF_sd_deduc',
                           DTVENTIL,
                           DTEXTRAIT)) AND
               DECODE(TYPMVT,
                       'pmtSAF_ajust',
                       DTVENTIL,
                       'pmtSAF_sd_deduc',
                       DTVENTIL,
                       TO_CHAR(DT_RECONCILIATION_DT, 'j')) =
               NVL(:B1,
                    DECODE(TYPMVT,
                           'pmtSAF_ajust',
                           DTVENTIL,
                           'pmtSAF_sd_deduc',
                           DTVENTIL,
                           TO_CHAR(DT_RECONCILIATION_DT, 'j'))))
        UNION ALL
        
        SELECT /*+ use_concat */
       TRUNC(T.DTJOUR_DT) TRANSACTION_DT,
       TRUNC(T.DTINTER_DT) VALUE_DT,
       T.LIBELLE LABEL,
       (SELECT IMX.FTRANSLATE_STR(T.LIBELLE, :B11, T.CODECR)
          FROM DUAL) LABEL_DESC,
       T.MNT_DCPT AMOUNT_DCMP,
       1 NB,
       T.REFELEM REFELEM,
       C.REFLOT REFDOSS_DCMP,
       'CIT' || T.CODECR CODECR,
       NULL REFEXT,
       NULL RETENTIONINDIC,
       DECODE(T.ORIG_REFLOT,
              T.REFDOSS,
              NVL2(M.REFJOUR, M.ORIG_REFLOT, 'NP'),
              T.ORIG_REFLOT) MEMO_DECOMPTE
  FROM G_DOSSIER C, T_ECRDOS T, G_ENCAISSEMENT E, T_ECRDOS_TEMP M
 WHERE C.REFLOT = :B8
   AND T.REFDOSS = C.REFDOSS
   AND (     (     :B7 IS NULL 
               AND :B6 IS NULL )
          OR (    (     T.ORIG_REFLOT = T.REFDOSS
                    AND NVL2(M.REFJOUR, :B5, 'NP') BETWEEN NVL(:B6, :B7) AND NVL(:B7, :B6)
                    AND (    :B5 BETWEEN NVL(:B6, :B7) AND NVL(:B7, :B6)
                          OR 'NP' BETWEEN NVL(:B6, :B7) AND NVL(:B7, :B6) ) )
               OR (     NVL(T.ORIG_REFLOT,'xXx') != NVL(T.REFDOSS,'xXx')
                    AND T.ORIG_REFLOT BETWEEN NVL(:B6, :B7) AND NVL(:B7, :B6) ) ) )
   AND T.CODECR IN ('ENCAT', 'AENAT', 'RFIN', 'ARFIN')
   AND E.REFENCAISS = T.REFELEM
   AND E.TYPENCAISS = 'e_saencaiss'
   AND E.MOYENPAIMT = 'PAIEMENT DECLARE'
   AND (     :B3 IS NOT NULL
         AND M.ORIG_REFLOT = :B3 
         AND T.ORIG_REFLOT = T.REFDOSS 
          
          OR :B5 = 'NP' 
         AND M.ORIG_REFLOT IS NULL 
         AND T.ORIG_REFLOT = T.REFDOSS 
         
          OR :B4 IS NULL 
         AND :B3 IS NULL 
         AND T.DTJOUR <= NVL(:B2, T.DTJOUR) 
         AND T.DTINTER <= NVL(:B1, T.DTINTER) 
          
          OR :B4 = 'CIT' || T.CODECR
         AND :B4 IS NOT NULL 
         AND :B3 IS NULL 
         AND T.DTJOUR = NVL(:B2, T.DTJOUR) 
         AND T.DTINTER = NVL(:B1, T.DTINTER) )
   AND M.REFJOUR(+) = T.REFJOUR
   
        UNION ALL
        SELECT TRUNC(T.DTJOUR_DT) TRANSACTION_DT,
               TRUNC(T.DTINTER_DT) VALUE_DT,
               T.LIBELLE LABEL,
               (SELECT DISTINCT FIRST_VALUE(PF_LIB_TRAD) OVER(ORDER BY PF_REFFACTOR NULLS LAST)
                  FROM V_FPARFAC
                 WHERE PF_NOM = T.CODECR
                   AND (PF_REFFACTOR IS NULL OR PF_REFFACTOR = :B12)
                   AND LANGUE = :B11) LABEL_DESC,
               -T.MNT_DCPT AMOUNT_DCMP,
               1 NB,
               T.REFELEM REFELEM,
               T.REFDOSS REFDOSS_DCMP,
               'CIT' || T.CODECR CODECR,
               NULL REFEXT,
               NULL RETENTIONINDIC,
               T.MEMO_DECOMPTE MEMO_DECOMPTE
          FROM T_ECRDOS T
         WHERE T.REFDOSS = :B8
           AND (:B7 IS NULL AND :B6 IS NULL OR
               T.MEMO_DECOMPTE BETWEEN NVL(:B6, :B7) AND NVL(:B7, :B6))
           AND T.CODECR IN ('RINDS', 'CRINS')
           AND (T.MEMO_DECOMPTE = :B5 OR :B4 IS NULL AND :B3 IS NULL AND
               T.DTJOUR <= NVL(:B2, T.DTJOUR) AND
               T.DTINTER <= NVL(:B1, T.DTINTER) OR
               :B4 = 'CIT' || CODECR AND :B3 IS NULL AND
               T.DTJOUR = NVL(:B2, T.DTJOUR) AND
               T.DTINTER = NVL(:B1, T.DTINTER))
        UNION ALL
        SELECT TRANSACTION_DT TRANSACTION_DT,
               VALUE_DT VALUE_DT,
               LABEL LABEL,
               (SELECT IMX.FTRANSLATE_STR(LIB_A, :B11, CODECR_F) FROM DUAL) ||
               LIB_B LABEL_DESC,
               AMOUNT_DCMP AMOUNT_DCMP,
               NB NB,
               REFELEM REFELEM,
               REFDOSS_DCMP REFDOSS_DCMP,
               CODECR CODECR,
               REFEXT REFEXT,
               RETENTIONINDIC RETENTIONINDIC,
               MEMO_DECOMPTE MEMO_DECOMPTE
          FROM (SELECT /*+ leading(C G T) index(G G_ELEMFI_DOS_TYP_FG02) NO_MERGE */
                 TRUNC(T.DTJOUR_DT) TRANSACTION_DT,
                 TRUNC(T.DTINTER_DT) VALUE_DT,
                 T.LIBELLE LABEL,
                 T.CODECR CODECR_F,
                 SUBSTR(T.LIBELLE,
                        1,
                        DECODE(INSTR(T.LIBELLE, ':'),
                               0,
                               60,
                               (INSTR(T.LIBELLE, ':')) - 1)) LIB_A,
                 DECODE(INSTR(T.LIBELLE, ':'),
                        0,
                        '',
                        SUBSTR(T.LIBELLE, INSTR(T.LIBELLE, ':'))) LIB_B,
                 T.MNT_DCPT AMOUNT_DCMP,
                 1 NB,
                 T.REFELEM REFELEM,
                 C.REFLOT REFDOSS_DCMP,
                 'CIT' || T.CODECR CODECR,
                 NULL REFEXT,
                 NULL RETENTIONINDIC,
                 DECODE(T.ORIG_REFLOT,
                        T.REFDOSS,
                        NVL2(M.REFJOUR, M.ORIG_REFLOT, 'NP'),
                        T.ORIG_REFLOT) MEMO_DECOMPTE
                  FROM G_DOSSIER C, T_ECRDOS T, G_ELEMFI G, T_ECRDOS_TEMP M
                 WHERE C.REFLOT = :B8
                   AND T.REFDOSS = C.REFDOSS
                   AND (:B7 IS NULL AND :B6 IS NULL OR
                       DECODE(T.ORIG_REFLOT,
                               T.REFDOSS,
                               NVL2(M.REFJOUR, :B5, 'NP'),
                               T.ORIG_REFLOT) BETWEEN NVL(:B6, :B7) AND
                       NVL(:B7, :B6))
                   AND T.CODECR IN ('PRIN', 'APRIN')
                   AND G.REFELEM = T.REFELEM
                   AND G.REFDOSS = C.REFDOSS
                   AND G.TYPE IN ('SAF CN COMP', 'DRAFT')
                   AND (M.ORIG_REFLOT = :B3 AND T.ORIG_REFLOT = T.REFDOSS OR
                       :B5 = 'NP' AND M.ORIG_REFLOT IS NULL AND
                       T.ORIG_REFLOT = T.REFDOSS OR
                       :B4 IS NULL AND :B3 IS NULL AND
                       T.DTJOUR <= NVL(:B2, T.DTJOUR) AND
                       T.DTINTER <= NVL(:B1, T.DTINTER) OR
                       :B4 = 'CIT' || T.CODECR AND :B3 IS NULL AND
                       T.DTJOUR = NVL(:B2, T.DTJOUR) AND
                       T.DTINTER = NVL(:B1, T.DTINTER))
                   AND M.REFJOUR(+) = T.REFJOUR)
        UNION ALL
        SELECT TRANSACTION_DT TRANSACTION_DT,
               VALUE_DT VALUE_DT,
               LABEL LABEL,
               (SELECT IMX.FTRANSLATE_STR(LIB_A, :B11, CODECR_F) FROM DUAL) ||
               LIB_B LABEL_DESC,
               AMOUNT_DCMP AMOUNT_DCMP,
               NB NB,
               REFELEM REFELEM,
               REFDOSS_DCMP REFDOSS_DCMP,
               CODECR CODECR,
               REFEXT REFEXT,
               RETENTIONINDIC RETENTIONINDIC,
               MEMO_DECOMPTE MEMO_DECOMPTE
          FROM (SELECT
                /*+ leading(C G T) index(G G_ELEMFI_DOS_TYP_FG02) NO_MERGE */
                 TRUNC(T.DTJOUR_DT) TRANSACTION_DT,
                 TRUNC(T.DTINTER_DT) VALUE_DT,
                 T.LIBELLE LABEL,
                 T.CODECR CODECR_F,
                 SUBSTR(T.LIBELLE,
                        1,
                        DECODE(INSTR(T.LIBELLE, ':'),
                               0,
                               60,
                               (INSTR(T.LIBELLE, ':')) - 1)) LIB_A,
                 DECODE(INSTR(T.LIBELLE, ':'),
                        0,
                        '',
                        SUBSTR(T.LIBELLE, INSTR(T.LIBELLE, ':'))) LIB_B,
                 T.MNT_DCPT AMOUNT_DCMP,
                 1 NB,
                 T.REFELEM REFELEM,
                 C.REFLOT REFDOSS_DCMP,
                 'CIT' || T.CODECR CODECR,
                 NULL REFEXT,
                 NULL RETENTIONINDIC,
                 DECODE(T.ORIG_REFLOT,
                        T.REFDOSS,
                        NVL2(M.REFJOUR, M.ORIG_REFLOT, 'NP'),
                        T.ORIG_REFLOT) MEMO_DECOMPTE
                  FROM G_DOSSIER C, T_ECRDOS T, G_ELEMFI G, T_ECRDOS_TEMP M
                 WHERE :B13 = 'O'
                   AND C.REFLOT = :B8
                   AND T.REFDOSS = C.REFDOSS
                   AND (:B7 IS NULL AND :B6 IS NULL OR
                       DECODE(T.ORIG_REFLOT,
                               T.REFDOSS,
                               NVL2(M.REFJOUR, :B5, 'NP'),
                               T.ORIG_REFLOT) BETWEEN NVL(:B6, :B7) AND
                       NVL(:B7, :B6))
                   AND T.CODECR IN ('PRIN', 'APRIN')
                   AND G.REFELEM = T.REFELEM
                   AND G.REFDOSS = C.REFDOSS
                   AND G.TYPE IN ('OPERATION DIVERSE 
  CREDITRICE',
                                  'OPERATION DIVERSE DEBITRICE')
                   AND (M.ORIG_REFLOT = :B3 AND T.ORIG_REFLOT = T.REFDOSS OR
                       :B5 = 'NP' AND M.ORIG_REFLOT IS NULL AND
                       T.ORIG_REFLOT = T.REFDOSS OR
                       :B4 IS NULL AND :B3 IS NULL AND
                       T.DTJOUR <= NVL(:B2, T.DTJOUR) AND
                       T.DTINTER <= NVL(:B1, T.DTINTER) OR
                       :B4 = 'CIT' || T.CODECR AND :B3 IS NULL AND
                       T.DTJOUR = NVL(:B2, T.DTJOUR) AND
                       T.DTINTER = NVL(:B1, T.DTINTER))
                   AND M.REFJOUR(+) = T.REFJOUR)
        UNION ALL
        SELECT TRANSACTION_DT TRANSACTION_DT,
               VALUE_DT VALUE_DT,
               LABEL LABEL,
               (SELECT IMX.FTRANSLATE_STR(LIB_A, :B11, CODECR_F) FROM DUAL) ||
               LIB_B LABEL_DESC,
               AMOUNT_DCMP AMOUNT_DCMP,
               NB NB,
               REFELEM REFELEM,
               REFDOSS_DCMP REFDOSS_DCMP,
               CODECR CODECR,
               REFEXT REFEXT,
               RETENTIONINDIC RETENTIONINDIC,
               MEMO_DECOMPTE MEMO_DECOMPTE
          FROM (SELECT /*+ leading(C G T) index(G 
                  G_ELEMFI_DOS_TYP_FG02) NO_MERGE */
                 TRUNC(T.DTJOUR_DT) TRANSACTION_DT,
                 TRUNC(T.DTINTER_DT) VALUE_DT,
                 T.LIBELLE LABEL,
                 T.CODECR CODECR_F,
                 SUBSTR(T.LIBELLE,
                        1,
                        DECODE(INSTR(T.LIBELLE, ':'),
                               0,
                               60,
                               (INSTR(T.LIBELLE, ':')) - 1)) LIB_A,
                 DECODE(INSTR(T.LIBELLE, ':'),
                        0,
                        '',
                        SUBSTR(T.LIBELLE, INSTR(T.LIBELLE, ':'))) LIB_B,
                 T.MNT_DCPT AMOUNT_DCMP,
                 1 NB,
                 T.REFELEM REFELEM,
                 C.REFLOT REFDOSS_DCMP,
                 'CIT' || T.CODECR CODECR,
                 NULL REFEXT,
                 NULL RETENTIONINDIC,
                 DECODE(T.ORIG_REFLOT,
                        T.REFDOSS,
                        NVL2(M.REFJOUR, M.ORIG_REFLOT, 'NP'),
                        T.ORIG_REFLOT) MEMO_DECOMPTE
                  FROM G_DOSSIER C, T_ECRDOS T, G_ELEMFI G, T_ECRDOS_TEMP M
                 WHERE :B13 = 'O'
                   AND C.REFLOT = :B8
                   AND T.REFDOSS = C.REFDOSS
                   AND (:B7 IS NULL AND :B6 IS NULL OR
                       DECODE(T.ORIG_REFLOT,
                               T.REFDOSS,
                               NVL2(M.REFJOUR, :B5, 'NP'),
                               T.ORIG_REFLOT) BETWEEN NVL(:B6, :B7) AND
                       NVL(:B7, :B6))
                   AND T.CODECR IN ('DPRIN', 'ADPRI')
                   AND G.REFELEM = T.REFELEM
                   AND G.REFDOSS = C.REFDOSS
                   AND G.TYPE IN ('ANNULATION ODC', 'ANNULATION ODD')
                   AND (M.ORIG_REFLOT = :B3 AND T.ORIG_REFLOT = T.REFDOSS OR
                       :B5 = 'NP' AND M.ORIG_REFLOT IS NULL AND
                       T.ORIG_REFLOT = T.REFDOSS OR
                       :B4 IS NULL AND :B3 IS NULL AND
                       T.DTJOUR <= NVL(:B2, T.DTJOUR) AND
                       T.DTINTER <= NVL(:B1, T.DTINTER) OR
                       :B4 = 'CIT' || T.CODECR AND :B3 IS NULL AND
                       T.DTJOUR = NVL(:B2, T.DTJOUR) AND
                       T.DTINTER = NVL(:B1, T.DTINTER))
                   AND M.REFJOUR(+) = T.REFJOUR)
        UNION ALL
        SELECT ARCH.MAX_ARCH_TRANS_DATE TRANSACTION_DT,
               ARCH.MAX_ARCH_VALUE_DATE VALUE_DT,
               'ARCHIVED CIT BALANCE' LABEL,
               (SELECT IMX.FTRANSLATE_STR('ARCHIVED CIT BALANCE',
                                          :B11,
                                          ARCH.TYPE_BALANCE)
                  FROM DUAL) LABEL_DESC,
               ARCH.AMOUNT_ARCH_PART_BAL AMOUNT_DCMP,
               ARCH.ARCH_COUNTER NB,
               NULL REFELEM,
               ARCH.REFDOSS REFDOSS_DCMP,
               'CITARCHBAL' CODECR,
               NULL REFEXT,
               NULL RETENTIONINDIC,
               ARCH.MAX_MEMO_DECOMPTE MEMO_DECOMPTE
          FROM T_ARCH_DCPT_BALANCES ARCH
         WHERE TYPE_BALANCE = 'CIT'
           AND REFDOSS = :B8
           AND (:B4 IS NULL AND
               TO_CHAR(ARCH.MAX_ARCH_TRANS_DATE, 'j') <=
               NVL(:B2, TO_CHAR(ARCH.MAX_ARCH_TRANS_DATE, 'j')) AND
               TO_CHAR(ARCH.MAX_ARCH_VALUE_DATE, 'j') <=
               NVL(:B1, TO_CHAR(ARCH.MAX_ARCH_VALUE_DATE, 'j')) OR
               :B4 = 'CITARCHBAL' AND
               TO_CHAR(ARCH.MAX_ARCH_TRANS_DATE, 'j') =
               NVL(:B2, TO_CHAR(ARCH.MAX_ARCH_TRANS_DATE, 'j')) AND
               TO_CHAR(ARCH.MAX_ARCH_VALUE_DATE, 'j') =
               NVL(:B1, TO_CHAR(ARCH.MAX_ARCH_VALUE_DATE, 'j')))
           AND ARCH.MAX_MEMO_DECOMPTE = :B5
           AND (:B7 IS NULL AND :B6 IS NULL OR
               ARCH.MAX_MEMO_DECOMPTE BETWEEN NVL(:B6, :B7) AND
               NVL(:B7, :B6)))
 ORDER BY CASE
            WHEN MEMO_DECOMPTE = 'NP' THEN
             3
            WHEN LENGTH(MEMO_DECOMPTE) = 8 THEN
             2
            ELSE
             1
          END,
          DECODE(LENGTH(MEMO_DECOMPTE), 8, MEMO_DECOMPTE),
          TRANSACTION_DT,
          DECODE(CODECR,
                 'CIT' || 'pmtSAF_ajust',
                 2,
                 'CIT' || 'pmtSAF_sd_deduc',
                 2,
                 'CITARCHBAL',
                 2,
                 1),
          DECODE(SIGN(AMOUNT_DCMP), 1, 2, 1),
          REFELEM;
/********************************New SQL*******************************************/
/********************************New Metrics***************************************/
/*
Plan hash value: 2969990
-------------------------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                     | Name                        | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  |
-------------------------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                              |                             |      1 |        |   362 (100)|      0 |00:00:00.10 |    6389 |     79 |
|   1 |  SORT ORDER BY                                |                             |      1 |    138 |   362   (1)|      0 |00:00:00.10 |    6389 |     79 |
|   2 |   VIEW                                        |                             |      1 |    138 |   361   (1)|      0 |00:00:00.10 |    6389 |     79 |
|   3 |    UNION-ALL                                  |                             |      1 |        |            |      0 |00:00:00.10 |    6389 |     79 |
|*  4 |     FILTER                                    |                             |      1 |        |            |      0 |00:00:00.05 |    4576 |     34 |
|*  5 |      TABLE ACCESS BY INDEX ROWID BATCHED      | NAM_COLLECTE                |      1 |      1 |     1   (0)|      0 |00:00:00.05 |    4576 |     34 |
|*  6 |       INDEX RANGE SCAN                        | NAM_COLLECTE_DTEXTR_IDX     |      1 |    121 |     1   (0)|   7772 |00:00:00.01 |      35 |      0 |
|*  7 |      TABLE ACCESS BY INDEX ROWID BATCHED      | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*  8 |       INDEX RANGE SCAN                        | V_DOMAINE_TYPE_CODE_IDX     |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|   9 |     FAST DUAL                                 |                             |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|  10 |     CONCATENATION                             |                             |      1 |        |            |      0 |00:00:00.01 |       4 |      0 |
|* 11 |      FILTER                                   |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  12 |       NESTED LOOPS                            |                             |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|  13 |        NESTED LOOPS                           |                             |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|  14 |         NESTED LOOPS                          |                             |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|  15 |          NESTED LOOPS OUTER                   |                             |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 16 |           TABLE ACCESS BY INDEX ROWID BATCHED | T_ECRDOS                    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 17 |            INDEX RANGE SCAN                   | T_ECRDOS$ORIG_REFLOT        |      0 |    157 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|  18 |           TABLE ACCESS BY INDEX ROWID         | T_ECRDOS_TEMP               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 19 |            INDEX UNIQUE SCAN                  | T_ECRDOS_TEMP_PK            |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 20 |          INDEX RANGE SCAN                     | DOS_REFDOSS_REFLOT_IDX      |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 21 |         INDEX UNIQUE SCAN                     | REFENCAISS                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 22 |        TABLE ACCESS BY INDEX ROWID            | G_ENCAISSEMENT              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 23 |      FILTER                                   |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  24 |       NESTED LOOPS                            |                             |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|  25 |        NESTED LOOPS                           |                             |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|  26 |         NESTED LOOPS                          |                             |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|  27 |          NESTED LOOPS OUTER                   |                             |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 28 |           TABLE ACCESS BY INDEX ROWID BATCHED | T_ECRDOS                    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 29 |            INDEX RANGE SCAN                   | T_ECRDOS$ORIG_REFLOT        |      0 |    157 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|  30 |           TABLE ACCESS BY INDEX ROWID         | T_ECRDOS_TEMP               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 31 |            INDEX UNIQUE SCAN                  | T_ECRDOS_TEMP_PK            |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 32 |          INDEX RANGE SCAN                     | DOS_REFDOSS_REFLOT_IDX      |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 33 |         INDEX UNIQUE SCAN                     | REFENCAISS                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 34 |        TABLE ACCESS BY INDEX ROWID            | G_ENCAISSEMENT              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 35 |      FILTER                                   |                             |      1 |        |            |      0 |00:00:00.01 |       4 |      0 |
|  36 |       NESTED LOOPS                            |                             |      1 |      1 |     4   (0)|      0 |00:00:00.01 |       4 |      0 |
|  37 |        NESTED LOOPS                           |                             |      1 |      1 |     4   (0)|      0 |00:00:00.01 |       4 |      0 |
|  38 |         NESTED LOOPS                          |                             |      1 |      1 |     3   (0)|      0 |00:00:00.01 |       4 |      0 |
|  39 |          NESTED LOOPS OUTER                   |                             |      1 |      1 |     2   (0)|      0 |00:00:00.01 |       4 |      0 |
|* 40 |           TABLE ACCESS BY INDEX ROWID BATCHED | T_ECRDOS                    |      1 |      1 |     1   (0)|      0 |00:00:00.01 |       4 |      0 |
|* 41 |            INDEX RANGE SCAN                   | T_ECRDOS$ORIG_REFLOT        |      1 |    157 |     1   (0)|      0 |00:00:00.01 |       4 |      0 |
|  42 |           TABLE ACCESS BY INDEX ROWID         | T_ECRDOS_TEMP               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 43 |            INDEX UNIQUE SCAN                  | T_ECRDOS_TEMP_PK            |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 44 |          INDEX RANGE SCAN                     | DOS_REFDOSS_REFLOT_IDX      |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 45 |         INDEX UNIQUE SCAN                     | REFENCAISS                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 46 |        TABLE ACCESS BY INDEX ROWID            | G_ENCAISSEMENT              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 47 |      FILTER                                   |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  48 |       NESTED LOOPS                            |                             |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|  49 |        NESTED LOOPS                           |                             |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|  50 |         NESTED LOOPS                          |                             |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 51 |          FILTER                               |                             |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  52 |           NESTED LOOPS OUTER                  |                             |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 53 |            TABLE ACCESS BY INDEX ROWID BATCHED| T_ECRDOS                    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 54 |             INDEX RANGE SCAN                  | T_ECRDOS$ORIG_REFLOT        |      0 |    157 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|  55 |            TABLE ACCESS BY INDEX ROWID        | T_ECRDOS_TEMP               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 56 |             INDEX UNIQUE SCAN                 | T_ECRDOS_TEMP_PK            |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 57 |          INDEX RANGE SCAN                     | DOS_REFDOSS_REFLOT_IDX      |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 58 |         INDEX UNIQUE SCAN                     | REFENCAISS                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 59 |        TABLE ACCESS BY INDEX ROWID            | G_ENCAISSEMENT              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 60 |      FILTER                                   |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  61 |       NESTED LOOPS                            |                             |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|  62 |        NESTED LOOPS                           |                             |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|  63 |         NESTED LOOPS                          |                             |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 64 |          FILTER                               |                             |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  65 |           NESTED LOOPS OUTER                  |                             |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 66 |            TABLE ACCESS BY INDEX ROWID BATCHED| T_ECRDOS                    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 67 |             INDEX RANGE SCAN                  | T_ECRDOS$ORIG_REFLOT        |      0 |    157 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|  68 |            TABLE ACCESS BY INDEX ROWID        | T_ECRDOS_TEMP               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 69 |             INDEX UNIQUE SCAN                 | T_ECRDOS_TEMP_PK            |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 70 |          INDEX RANGE SCAN                     | DOS_REFDOSS_REFLOT_IDX      |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 71 |         INDEX UNIQUE SCAN                     | REFENCAISS                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 72 |        TABLE ACCESS BY INDEX ROWID            | G_ENCAISSEMENT              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 73 |      FILTER                                   |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  74 |       NESTED LOOPS                            |                             |      0 |      1 |     8   (0)|      0 |00:00:00.01 |       0 |      0 |
|  75 |        NESTED LOOPS                           |                             |      0 |      1 |     8   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 76 |         FILTER                                |                             |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  77 |          NESTED LOOPS OUTER                   |                             |      0 |      1 |     7   (0)|      0 |00:00:00.01 |       0 |      0 |
|  78 |           NESTED LOOPS                        |                             |      0 |      1 |     6   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 79 |            INDEX RANGE SCAN                   | G_DOSSIER_RL_CD_RD_RF_IDX   |      0 |    120 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 80 |            TABLE ACCESS BY INDEX ROWID BATCHED| T_ECRDOS                    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 81 |             INDEX RANGE SCAN                  | TECR_REFDOSS_DTJOUR         |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|  82 |           TABLE ACCESS BY INDEX ROWID         | T_ECRDOS_TEMP               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 83 |            INDEX UNIQUE SCAN                  | T_ECRDOS_TEMP_PK            |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 84 |         INDEX UNIQUE SCAN                     | REFENCAISS                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 85 |        TABLE ACCESS BY INDEX ROWID            | G_ENCAISSEMENT              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 86 |      FILTER                                   |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  87 |       NESTED LOOPS                            |                             |      0 |      1 |     8   (0)|      0 |00:00:00.01 |       0 |      0 |
|  88 |        NESTED LOOPS                           |                             |      0 |      1 |     8   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 89 |         FILTER                                |                             |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  90 |          NESTED LOOPS OUTER                   |                             |      0 |      1 |     7   (0)|      0 |00:00:00.01 |       0 |      0 |
|  91 |           NESTED LOOPS                        |                             |      0 |      1 |     6   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 92 |            INDEX RANGE SCAN                   | G_DOSSIER_RL_CD_RD_RF_IDX   |      0 |    120 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 93 |            TABLE ACCESS BY INDEX ROWID BATCHED| T_ECRDOS                    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 94 |             INDEX RANGE SCAN                  | TECR_REFDOSS_DTJOUR         |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|  95 |           TABLE ACCESS BY INDEX ROWID         | T_ECRDOS_TEMP               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 96 |            INDEX UNIQUE SCAN                  | T_ECRDOS_TEMP_PK            |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 97 |         INDEX UNIQUE SCAN                     | REFENCAISS                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 98 |        TABLE ACCESS BY INDEX ROWID            | G_ENCAISSEMENT              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 99 |      FILTER                                   |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 100 |       NESTED LOOPS                            |                             |      0 |      1 |    13   (0)|      0 |00:00:00.01 |       0 |      0 |
| 101 |        NESTED LOOPS                           |                             |      0 |      1 |    13   (0)|      0 |00:00:00.01 |       0 |      0 |
|*102 |         FILTER                                |                             |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 103 |          NESTED LOOPS OUTER                   |                             |      0 |      1 |    12   (0)|      0 |00:00:00.01 |       0 |      0 |
| 104 |           NESTED LOOPS                        |                             |      0 |      1 |    11   (0)|      0 |00:00:00.01 |       0 |      0 |
|*105 |            INDEX RANGE SCAN                   | G_DOSSIER_RL_CD_RD_RF_IDX   |      0 |    120 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*106 |            TABLE ACCESS BY INDEX ROWID BATCHED| T_ECRDOS                    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*107 |             INDEX RANGE SCAN                  | TECR_REFDOSS_DTJOUR         |      0 |     11 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 108 |           TABLE ACCESS BY INDEX ROWID         | T_ECRDOS_TEMP               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*109 |            INDEX UNIQUE SCAN                  | T_ECRDOS_TEMP_PK            |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*110 |         INDEX UNIQUE SCAN                     | REFENCAISS                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*111 |        TABLE ACCESS BY INDEX ROWID            | G_ENCAISSEMENT              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*112 |      FILTER                                   |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 113 |       NESTED LOOPS                            |                             |      0 |      1 |    13   (0)|      0 |00:00:00.01 |       0 |      0 |
| 114 |        NESTED LOOPS                           |                             |      0 |      1 |    13   (0)|      0 |00:00:00.01 |       0 |      0 |
|*115 |         FILTER                                |                             |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 116 |          NESTED LOOPS OUTER                   |                             |      0 |      1 |    12   (0)|      0 |00:00:00.01 |       0 |      0 |
| 117 |           NESTED LOOPS                        |                             |      0 |      1 |    11   (0)|      0 |00:00:00.01 |       0 |      0 |
|*118 |            INDEX RANGE SCAN                   | G_DOSSIER_RL_CD_RD_RF_IDX   |      0 |    120 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*119 |            TABLE ACCESS BY INDEX ROWID BATCHED| T_ECRDOS                    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*120 |             INDEX RANGE SCAN                  | TECR_REFDOSS_DTJOUR         |      0 |     11 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 121 |           TABLE ACCESS BY INDEX ROWID         | T_ECRDOS_TEMP               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*122 |            INDEX UNIQUE SCAN                  | T_ECRDOS_TEMP_PK            |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*123 |         INDEX UNIQUE SCAN                     | REFENCAISS                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*124 |        TABLE ACCESS BY INDEX ROWID            | G_ENCAISSEMENT              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*125 |      FILTER                                   |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 126 |       NESTED LOOPS                            |                             |      0 |      1 |     8   (0)|      0 |00:00:00.01 |       0 |      0 |
| 127 |        NESTED LOOPS                           |                             |      0 |      1 |     8   (0)|      0 |00:00:00.01 |       0 |      0 |
|*128 |         FILTER                                |                             |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 129 |          NESTED LOOPS OUTER                   |                             |      0 |      1 |     7   (0)|      0 |00:00:00.01 |       0 |      0 |
| 130 |           NESTED LOOPS                        |                             |      0 |      1 |     6   (0)|      0 |00:00:00.01 |       0 |      0 |
|*131 |            INDEX RANGE SCAN                   | G_DOSSIER_RL_CD_RD_RF_IDX   |      0 |    120 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*132 |            TABLE ACCESS BY INDEX ROWID BATCHED| T_ECRDOS                    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*133 |             INDEX RANGE SCAN                  | TECR_REFDOSS_DTJOUR         |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 134 |           TABLE ACCESS BY INDEX ROWID         | T_ECRDOS_TEMP               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*135 |            INDEX UNIQUE SCAN                  | T_ECRDOS_TEMP_PK            |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*136 |         INDEX UNIQUE SCAN                     | REFENCAISS                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*137 |        TABLE ACCESS BY INDEX ROWID            | G_ENCAISSEMENT              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*138 |      FILTER                                   |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 139 |       NESTED LOOPS                            |                             |      0 |    120 |    10   (0)|      0 |00:00:00.01 |       0 |      0 |
| 140 |        NESTED LOOPS                           |                             |      0 |    120 |    10   (0)|      0 |00:00:00.01 |       0 |      0 |
|*141 |         FILTER                                |                             |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 142 |          NESTED LOOPS OUTER                   |                             |      0 |    120 |     7   (0)|      0 |00:00:00.01 |       0 |      0 |
| 143 |           NESTED LOOPS                        |                             |      0 |    120 |     6   (0)|      0 |00:00:00.01 |       0 |      0 |
|*144 |            INDEX RANGE SCAN                   | G_DOSSIER_RL_CD_RD_RF_IDX   |      0 |    120 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*145 |            TABLE ACCESS BY INDEX ROWID BATCHED| T_ECRDOS                    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*146 |             INDEX RANGE SCAN                  | TECR_REFDOSS_DTJOUR         |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 147 |           TABLE ACCESS BY INDEX ROWID         | T_ECRDOS_TEMP               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*148 |            INDEX UNIQUE SCAN                  | T_ECRDOS_TEMP_PK            |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*149 |         INDEX UNIQUE SCAN                     | REFENCAISS                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*150 |        TABLE ACCESS BY INDEX ROWID            | G_ENCAISSEMENT              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*151 |      FILTER                                   |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 152 |       NESTED LOOPS                            |                             |      0 |      1 |    13   (0)|      0 |00:00:00.01 |       0 |      0 |
| 153 |        NESTED LOOPS                           |                             |      0 |      1 |    13   (0)|      0 |00:00:00.01 |       0 |      0 |
|*154 |         FILTER                                |                             |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 155 |          NESTED LOOPS OUTER                   |                             |      0 |      1 |    12   (0)|      0 |00:00:00.01 |       0 |      0 |
| 156 |           NESTED LOOPS                        |                             |      0 |      1 |    11   (0)|      0 |00:00:00.01 |       0 |      0 |
|*157 |            INDEX RANGE SCAN                   | G_DOSSIER_RL_CD_RD_RF_IDX   |      0 |    120 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*158 |            TABLE ACCESS BY INDEX ROWID BATCHED| T_ECRDOS                    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*159 |             INDEX RANGE SCAN                  | TECR_REFDOSS_DTJOUR         |      0 |     11 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 160 |           TABLE ACCESS BY INDEX ROWID         | T_ECRDOS_TEMP               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*161 |            INDEX UNIQUE SCAN                  | T_ECRDOS_TEMP_PK            |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*162 |         INDEX UNIQUE SCAN                     | REFENCAISS                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*163 |        TABLE ACCESS BY INDEX ROWID            | G_ENCAISSEMENT              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*164 |      FILTER                                   |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 165 |       NESTED LOOPS                            |                             |      0 |      1 |    13   (0)|      0 |00:00:00.01 |       0 |      0 |
| 166 |        NESTED LOOPS                           |                             |      0 |      1 |    13   (0)|      0 |00:00:00.01 |       0 |      0 |
|*167 |         FILTER                                |                             |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 168 |          NESTED LOOPS OUTER                   |                             |      0 |      1 |    12   (0)|      0 |00:00:00.01 |       0 |      0 |
| 169 |           NESTED LOOPS                        |                             |      0 |      1 |    11   (0)|      0 |00:00:00.01 |       0 |      0 |
|*170 |            INDEX RANGE SCAN                   | G_DOSSIER_RL_CD_RD_RF_IDX   |      0 |    120 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*171 |            TABLE ACCESS BY INDEX ROWID BATCHED| T_ECRDOS                    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*172 |             INDEX RANGE SCAN                  | TECR_REFDOSS_DTJOUR         |      0 |     11 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 173 |           TABLE ACCESS BY INDEX ROWID         | T_ECRDOS_TEMP               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*174 |            INDEX UNIQUE SCAN                  | T_ECRDOS_TEMP_PK            |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*175 |         INDEX UNIQUE SCAN                     | REFENCAISS                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*176 |        TABLE ACCESS BY INDEX ROWID            | G_ENCAISSEMENT              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 177 |     SORT UNIQUE                               |                             |      0 |     22 |    24   (9)|      0 |00:00:00.01 |       0 |      0 |
| 178 |      WINDOW SORT                              |                             |      0 |     22 |    24   (9)|      0 |00:00:00.01 |       0 |      0 |
| 179 |       VIEW                                    | V_FPARFAC                   |      0 |     22 |    22   (0)|      0 |00:00:00.01 |       0 |      0 |
| 180 |        UNION-ALL                              |                             |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 181 |         VIEW                                  | VW_ORE_5BE70045             |      0 |      2 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
| 182 |          UNION-ALL                            |                             |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*183 |           FILTER                              |                             |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 184 |            TABLE ACCESS BY INDEX ROWID BATCHED| F_PARFAC                    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*185 |             INDEX RANGE SCAN                  | PARFAC_CL1                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*186 |           FILTER                              |                             |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 187 |            TABLE ACCESS BY INDEX ROWID        | F_PARFAC                    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*188 |             INDEX UNIQUE SCAN                 | PARFAC_CL1                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 189 |         VIEW                                  | VW_ORE_68712886             |      0 |      2 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
| 190 |          UNION-ALL                            |                             |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*191 |           FILTER                              |                             |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 192 |            TABLE ACCESS BY INDEX ROWID BATCHED| F_PARFAC                    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*193 |             INDEX RANGE SCAN                  | PARFAC_CL1                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*194 |           FILTER                              |                             |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 195 |            TABLE ACCESS BY INDEX ROWID        | F_PARFAC                    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*196 |             INDEX UNIQUE SCAN                 | PARFAC_CL1                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 197 |         VIEW                                  | VW_ORE_75F612E2             |      0 |      2 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
| 198 |          UNION-ALL                            |                             |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*199 |           FILTER                              |                             |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 200 |            TABLE ACCESS BY INDEX ROWID BATCHED| F_PARFAC                    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*201 |             INDEX RANGE SCAN                  | PARFAC_CL1                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*202 |           FILTER                              |                             |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 203 |            TABLE ACCESS BY INDEX ROWID        | F_PARFAC                    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*204 |             INDEX UNIQUE SCAN                 | PARFAC_CL1                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 205 |         VIEW                                  | VW_ORE_711C0EE8             |      0 |      2 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
| 206 |          UNION-ALL                            |                             |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*207 |           FILTER                              |                             |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 208 |            TABLE ACCESS BY INDEX ROWID BATCHED| F_PARFAC                    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*209 |             INDEX RANGE SCAN                  | PARFAC_CL1                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*210 |           FILTER                              |                             |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 211 |            TABLE ACCESS BY INDEX ROWID        | F_PARFAC                    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*212 |             INDEX UNIQUE SCAN                 | PARFAC_CL1                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 213 |         VIEW                                  | VW_ORE_51F005CD             |      0 |      2 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
| 214 |          UNION-ALL                            |                             |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*215 |           FILTER                              |                             |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 216 |            TABLE ACCESS BY INDEX ROWID BATCHED| F_PARFAC                    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*217 |             INDEX RANGE SCAN                  | PARFAC_CL1                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*218 |           FILTER                              |                             |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 219 |            TABLE ACCESS BY INDEX ROWID        | F_PARFAC                    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*220 |             INDEX UNIQUE SCAN                 | PARFAC_CL1                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 221 |         VIEW                                  | VW_ORE_A152B67F             |      0 |      2 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
| 222 |          UNION-ALL                            |                             |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*223 |           FILTER                              |                             |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 224 |            TABLE ACCESS BY INDEX ROWID BATCHED| F_PARFAC                    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*225 |             INDEX RANGE SCAN                  | PARFAC_CL1                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*226 |           FILTER                              |                             |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 227 |            TABLE ACCESS BY INDEX ROWID        | F_PARFAC                    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*228 |             INDEX UNIQUE SCAN                 | PARFAC_CL1                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 229 |         VIEW                                  | VW_ORE_6C302822             |      0 |      2 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
| 230 |          UNION-ALL                            |                             |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*231 |           FILTER                              |                             |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 232 |            TABLE ACCESS BY INDEX ROWID BATCHED| F_PARFAC                    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*233 |             INDEX RANGE SCAN                  | PARFAC_CL1                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*234 |           FILTER                              |                             |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 235 |            TABLE ACCESS BY INDEX ROWID        | F_PARFAC                    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*236 |             INDEX UNIQUE SCAN                 | PARFAC_CL1                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 237 |         VIEW                                  | VW_ORE_5DB9CF8E             |      0 |      2 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
| 238 |          UNION-ALL                            |                             |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*239 |           FILTER                              |                             |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 240 |            TABLE ACCESS BY INDEX ROWID BATCHED| F_PARFAC                    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*241 |             INDEX RANGE SCAN                  | PARFAC_CL1                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*242 |           FILTER                              |                             |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 243 |            TABLE ACCESS BY INDEX ROWID        | F_PARFAC                    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*244 |             INDEX UNIQUE SCAN                 | PARFAC_CL1                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 245 |         VIEW                                  | VW_ORE_06F77713             |      0 |      2 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
| 246 |          UNION-ALL                            |                             |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*247 |           FILTER                              |                             |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 248 |            TABLE ACCESS BY INDEX ROWID BATCHED| F_PARFAC                    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*249 |             INDEX RANGE SCAN                  | PARFAC_CL1                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*250 |           FILTER                              |                             |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 251 |            TABLE ACCESS BY INDEX ROWID        | F_PARFAC                    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*252 |             INDEX UNIQUE SCAN                 | PARFAC_CL1                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 253 |         VIEW                                  | VW_ORE_31A15E1C             |      0 |      2 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
| 254 |          UNION-ALL                            |                             |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*255 |           FILTER                              |                             |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 256 |            TABLE ACCESS BY INDEX ROWID BATCHED| F_PARFAC                    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*257 |             INDEX RANGE SCAN                  | PARFAC_CL1                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*258 |           FILTER                              |                             |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 259 |            TABLE ACCESS BY INDEX ROWID        | F_PARFAC                    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*260 |             INDEX UNIQUE SCAN                 | PARFAC_CL1                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 261 |         VIEW                                  | VW_ORE_76C38685             |      0 |      2 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
| 262 |          UNION-ALL                            |                             |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*263 |           FILTER                              |                             |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 264 |            TABLE ACCESS BY INDEX ROWID BATCHED| F_PARFAC                    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*265 |             INDEX RANGE SCAN                  | PARFAC_CL1                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*266 |           FILTER                              |                             |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 267 |            TABLE ACCESS BY INDEX ROWID        | F_PARFAC                    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*268 |             INDEX UNIQUE SCAN                 | PARFAC_CL1                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 269 |     INLIST ITERATOR                           |                             |      1 |        |            |      0 |00:00:00.01 |       8 |      0 |
|*270 |      TABLE ACCESS BY INDEX ROWID BATCHED      | T_ECRDOS                    |      2 |      1 |     1   (0)|      0 |00:00:00.01 |       8 |      0 |
|*271 |       INDEX RANGE SCAN                        | TECR$REFDOSS_CODECR_DTINTER |      2 |      6 |     1   (0)|      0 |00:00:00.01 |       8 |      0 |
| 272 |     FAST DUAL                                 |                             |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
| 273 |     VIEW                                      |                             |      1 |      1 |    26   (0)|      0 |00:00:00.05 |    1801 |     45 |
|*274 |      FILTER                                   |                             |      1 |        |            |      0 |00:00:00.05 |    1801 |     45 |
| 275 |       NESTED LOOPS OUTER                      |                             |      1 |      1 |    26   (0)|    268 |00:00:00.05 |    1801 |     45 |
| 276 |        NESTED LOOPS                           |                             |      1 |      1 |    25   (0)|    268 |00:00:00.05 |    1792 |     45 |
| 277 |         NESTED LOOPS                          |                             |      1 |    354 |     7   (0)|    268 |00:00:00.01 |     669 |      0 |
|*278 |          INDEX RANGE SCAN                     | G_DOSSIER_RL_CD_RD_RF_IDX   |      1 |    120 |     1   (0)|    143 |00:00:00.01 |       4 |      0 |
| 279 |          TABLE ACCESS BY INDEX ROWID BATCHED  | G_ELEMFI                    |    143 |      3 |     1   (0)|    268 |00:00:00.01 |     665 |      0 |
|*280 |           INDEX RANGE SCAN                    | G_ELEMFI_DOS_TYP_FG02       |    143 |      3 |     1   (0)|    268 |00:00:00.01 |     499 |      0 |
|*281 |         TABLE ACCESS BY INDEX ROWID BATCHED   | T_ECRDOS                    |    268 |      1 |     1   (0)|    268 |00:00:00.04 |    1123 |     45 |
|*282 |          INDEX RANGE SCAN                     | TECR_REFELEM                |    268 |      2 |     1   (0)|    657 |00:00:00.01 |     635 |     10 |
| 283 |        TABLE ACCESS BY INDEX ROWID            | T_ECRDOS_TEMP               |    268 |      1 |     1   (0)|      0 |00:00:00.01 |       9 |      0 |
|*284 |         INDEX UNIQUE SCAN                     | T_ECRDOS_TEMP_PK            |    268 |      1 |     1   (0)|      0 |00:00:00.01 |       9 |      0 |
| 285 |     FAST DUAL                                 |                             |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
| 286 |     VIEW                                      |                             |      1 |      1 |    26   (0)|      0 |00:00:00.01 |       0 |      0 |
|*287 |      FILTER                                   |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*288 |       FILTER                                  |                             |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 289 |        NESTED LOOPS OUTER                     |                             |      0 |      1 |    26   (0)|      0 |00:00:00.01 |       0 |      0 |
| 290 |         NESTED LOOPS                          |                             |      0 |      1 |    25   (0)|      0 |00:00:00.01 |       0 |      0 |
| 291 |          NESTED LOOPS                         |                             |      0 |    354 |     7   (0)|      0 |00:00:00.01 |       0 |      0 |
|*292 |           INDEX RANGE SCAN                    | G_DOSSIER_RL_CD_RD_RF_IDX   |      0 |    120 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 293 |           TABLE ACCESS BY INDEX ROWID BATCHED | G_ELEMFI                    |      0 |      3 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*294 |            INDEX RANGE SCAN                   | G_ELEMFI_DOS_TYP_FG02       |      0 |      3 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*295 |          TABLE ACCESS BY INDEX ROWID BATCHED  | T_ECRDOS                    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*296 |           INDEX RANGE SCAN                    | TECR_REFELEM                |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 297 |         TABLE ACCESS BY INDEX ROWID           | T_ECRDOS_TEMP               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*298 |          INDEX UNIQUE SCAN                    | T_ECRDOS_TEMP_PK            |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 299 |     FAST DUAL                                 |                             |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
| 300 |     VIEW                                      |                             |      1 |      1 |    26   (0)|      0 |00:00:00.01 |       0 |      0 |
|*301 |      FILTER                                   |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*302 |       FILTER                                  |                             |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 303 |        NESTED LOOPS OUTER                     |                             |      0 |      1 |    26   (0)|      0 |00:00:00.01 |       0 |      0 |
| 304 |         NESTED LOOPS                          |                             |      0 |      1 |    25   (0)|      0 |00:00:00.01 |       0 |      0 |
| 305 |          NESTED LOOPS                         |                             |      0 |    354 |     7   (0)|      0 |00:00:00.01 |       0 |      0 |
|*306 |           INDEX RANGE SCAN                    | G_DOSSIER_RL_CD_RD_RF_IDX   |      0 |    120 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 307 |           TABLE ACCESS BY INDEX ROWID BATCHED | G_ELEMFI                    |      0 |      3 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*308 |            INDEX RANGE SCAN                   | G_ELEMFI_DOS_TYP_FG02       |      0 |      3 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*309 |          TABLE ACCESS BY INDEX ROWID BATCHED  | T_ECRDOS                    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*310 |           INDEX RANGE SCAN                    | TECR_REFELEM                |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 311 |         TABLE ACCESS BY INDEX ROWID           | T_ECRDOS_TEMP               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*312 |          INDEX UNIQUE SCAN                    | T_ECRDOS_TEMP_PK            |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 313 |     FAST DUAL                                 |                             |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*314 |     TABLE ACCESS BY INDEX ROWID BATCHED       | T_ARCH_DCPT_BALANCES        |      1 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*315 |      INDEX RANGE SCAN                         | T_ARCH_D_MAX_DCMPT_IDX      |      1 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
-------------------------------------------------------------------------------------------------------------------------------------------------------------

Predicate Information (identified by operation id):
---------------------------------------------------
   4 - filter(("CODOP" IS NULL OR  IS NULL))
   5 - filter((((:B4 IS NULL AND :B3 IS NULL AND DECODE("TYPMVT",'pmtSAF_ajust',"DTVENTIL",'pmtSAF_sd_deduc',"DTVENTIL","DTEXTRAIT")<=NVL(:B2,DECODE(
              "TYPMVT",'pmtSAF_ajust',"DTVENTIL",'pmtSAF_sd_deduc',"DTVENTIL","DTEXTRAIT")) AND
              DECODE("TYPMVT",'pmtSAF_ajust',"DTVENTIL",'pmtSAF_sd_deduc',"DTVENTIL",TO_NUMBER(TO_CHAR(INTERNAL_FUNCTION("DT_RECONCILIATION_DT"),'j')))<=NVL(:B1,DE
              CODE("TYPMVT",'pmtSAF_ajust',"DTVENTIL",'pmtSAF_sd_deduc',"DTVENTIL",TO_NUMBER(TO_CHAR(INTERNAL_FUNCTION("DT_RECONCILIATION_DT"),'j'))))) OR (:B3 IS
              NULL AND 'CIT'||"TYPMVT"=:B4 AND DECODE("TYPMVT",'pmtSAF_ajust',"DTVENTIL",'pmtSAF_sd_deduc',"DTVENTIL","DTEXTRAIT")=NVL(:B2,DECODE("TYPMVT",'pmtSAF_
              ajust',"DTVENTIL",'pmtSAF_sd_deduc',"DTVENTIL","DTEXTRAIT")) AND DECODE("TYPMVT",'pmtSAF_ajust',"DTVENTIL",'pmtSAF_sd_deduc',"DTVENTIL",TO_NUMBER(TO_
              CHAR(INTERNAL_FUNCTION("DT_RECONCILIATION_DT"),'j')))=NVL(:B1,DECODE("TYPMVT",'pmtSAF_ajust',"DTVENTIL",'pmtSAF_sd_deduc',"DTVENTIL",TO_NUMBER(TO_CHA
              R(INTERNAL_FUNCTION("DT_RECONCILIATION_DT"),'j'))))) OR "MEMO_DECOMPTE"=:B5) AND INTERNAL_FUNCTION("ETAT") AND ((:B7 IS NULL AND :B6 IS NULL) OR
              ("MEMO_DECOMPTE">=NVL(:B6,:B7) AND "MEMO_DECOMPTE"<=NVL(:B7,:B6))) AND INTERNAL_FUNCTION("TYPMVT")))
   6 - access("REFDOSS"=:B8)
   7 - filter(("OBL"='O' AND "ABREV2" IS NULL AND "CHAMP"<>'DO NOT PROCESS' AND
              LNNVL("CHEMIN"||LPAD(TO_CHAR("PLACE"),2,'0')||LPAD("COMMENTAIRE",2,'0')||LPAD("ECRAN",3,'0')<>:B1)))
   8 - access("TYPE"='OPCODE_COMBINATIONS')
  11 - filter((:B4 IS NOT NULL AND :B3 IS NULL AND :B1 IS NULL))
  16 - filter(('CIT'||"T"."CODECR"=:B4 AND INTERNAL_FUNCTION("T"."CODECR") AND "T"."DTJOUR"=NVL(:B2,"T"."DTJOUR") AND
              NVL("T"."ORIG_REFLOT",'xXx')<>"T"."REFDOSS" AND "T"."DTINTER" IS NOT NULL))
  17 - access("T"."ORIG_REFLOT">=NVL(:B6,:B7) AND "T"."ORIG_REFLOT"<=NVL(:B7,:B6))
  19 - access("M"."REFJOUR"="T"."REFJOUR")
  20 - access("T"."REFDOSS"="C"."REFDOSS" AND "C"."REFLOT"=:B8)
  21 - access("E"."REFENCAISS"="T"."REFELEM")
  22 - filter(("E"."MOYENPAIMT"='PAIEMENT DECLARE' AND "E"."TYPENCAISS"='e_saencaiss'))
  23 - filter((:B4 IS NOT NULL AND :B3 IS NULL AND :B1 IS NOT NULL))
  28 - filter(("T"."DTINTER"=:B1 AND 'CIT'||"T"."CODECR"=:B4 AND INTERNAL_FUNCTION("T"."CODECR") AND "T"."DTJOUR"=NVL(:B2,"T"."DTJOUR") AND
              NVL("T"."ORIG_REFLOT",'xXx')<>"T"."REFDOSS"))
  29 - access("T"."ORIG_REFLOT">=NVL(:B6,:B7) AND "T"."ORIG_REFLOT"<=NVL(:B7,:B6))
  31 - access("M"."REFJOUR"="T"."REFJOUR")
  32 - access("T"."REFDOSS"="C"."REFDOSS" AND "C"."REFLOT"=:B8)
  33 - access("E"."REFENCAISS"="T"."REFELEM")
  34 - filter(("E"."MOYENPAIMT"='PAIEMENT DECLARE' AND "E"."TYPENCAISS"='e_saencaiss'))
  35 - filter((:B3 IS NULL AND :B4 IS NULL))
  40 - filter((INTERNAL_FUNCTION("T"."CODECR") AND "T"."DTJOUR"<=NVL(:B2,"T"."DTJOUR") AND "T"."DTINTER"<=NVL(:B1,"T"."DTINTER") AND
              NVL("T"."ORIG_REFLOT",'xXx')<>"T"."REFDOSS" AND (LNNVL('CIT'||"T"."CODECR"=:B4) OR LNNVL(:B3 IS NULL) OR LNNVL("T"."DTJOUR"=NVL(:B2,"T"."DTJOUR"))
              OR LNNVL("T"."DTINTER"=NVL(:B1,"T"."DTINTER")) OR LNNVL(:B4 IS NOT NULL))))
  41 - access("T"."ORIG_REFLOT">=NVL(:B6,:B7) AND "T"."ORIG_REFLOT"<=NVL(:B7,:B6))
  43 - access("M"."REFJOUR"="T"."REFJOUR")
  44 - access("T"."REFDOSS"="C"."REFDOSS" AND "C"."REFLOT"=:B8)
  45 - access("E"."REFENCAISS"="T"."REFELEM")
  46 - filter(("E"."MOYENPAIMT"='PAIEMENT DECLARE' AND "E"."TYPENCAISS"='e_saencaiss'))
  47 - filter(:B5='NP')
  51 - filter("M"."ORIG_REFLOT" IS NULL)
  53 - filter(("T"."ORIG_REFLOT"="T"."REFDOSS" AND INTERNAL_FUNCTION("T"."CODECR") AND NVL("T"."ORIG_REFLOT",'xXx')<>"T"."REFDOSS" AND (LNNVL(:B4 IS
              NULL) OR LNNVL(:B3 IS NULL) OR LNNVL("T"."DTJOUR"<=NVL(:B2,"T"."DTJOUR")) OR LNNVL("T"."DTINTER"<=NVL(:B1,"T"."DTINTER"))) AND
              (LNNVL('CIT'||"T"."CODECR"=:B4) OR LNNVL(:B3 IS NULL) OR LNNVL("T"."DTJOUR"=NVL(:B2,"T"."DTJOUR")) OR LNNVL("T"."DTINTER"=NVL(:B1,"T"."DTINTER")) OR
              LNNVL(:B4 IS NOT NULL))))
  54 - access("T"."ORIG_REFLOT">=NVL(:B6,:B7) AND "T"."ORIG_REFLOT"<=NVL(:B7,:B6))
  56 - access("M"."REFJOUR"="T"."REFJOUR")
  57 - access("T"."REFDOSS"="C"."REFDOSS" AND "C"."REFLOT"=:B8)
  58 - access("E"."REFENCAISS"="T"."REFELEM")
  59 - filter(("E"."MOYENPAIMT"='PAIEMENT DECLARE' AND "E"."TYPENCAISS"='e_saencaiss'))
  60 - filter(:B3 IS NOT NULL)
  64 - filter(("M"."ORIG_REFLOT"=:B3 AND (LNNVL(:B5='NP') OR LNNVL("M"."ORIG_REFLOT" IS NULL) OR LNNVL("T"."ORIG_REFLOT"="T"."REFDOSS"))))
  66 - filter(("T"."ORIG_REFLOT"="T"."REFDOSS" AND INTERNAL_FUNCTION("T"."CODECR") AND NVL("T"."ORIG_REFLOT",'xXx')<>"T"."REFDOSS" AND (LNNVL(:B4 IS
              NULL) OR LNNVL(:B3 IS NULL) OR LNNVL("T"."DTJOUR"<=NVL(:B2,"T"."DTJOUR")) OR LNNVL("T"."DTINTER"<=NVL(:B1,"T"."DTINTER"))) AND
              (LNNVL('CIT'||"T"."CODECR"=:B4) OR LNNVL(:B3 IS NULL) OR LNNVL("T"."DTJOUR"=NVL(:B2,"T"."DTJOUR")) OR LNNVL("T"."DTINTER"=NVL(:B1,"T"."DTINTER")) OR
              LNNVL(:B4 IS NOT NULL))))
  67 - access("T"."ORIG_REFLOT">=NVL(:B6,:B7) AND "T"."ORIG_REFLOT"<=NVL(:B7,:B6))
  69 - access("M"."REFJOUR"="T"."REFJOUR")
  70 - access("T"."REFDOSS"="C"."REFDOSS" AND "C"."REFLOT"=:B8)
  71 - access("E"."REFENCAISS"="T"."REFELEM")
  72 - filter(("E"."MOYENPAIMT"='PAIEMENT DECLARE' AND "E"."TYPENCAISS"='e_saencaiss'))
  73 - filter((((NVL(:B6,:B7)<=:B5 AND NVL(:B7,:B6)>=:B5) OR (NVL(:B6,:B7)<='NP' AND NVL(:B7,:B6)>='NP')) AND :B4 IS NOT NULL AND :B3 IS NULL))
  76 - filter((NVL2("M"."REFJOUR",:B5,'NP')>=NVL(:B6,:B7) AND NVL2("M"."REFJOUR",:B5,'NP')<=NVL(:B7,:B6)))
  79 - access("C"."REFLOT"=:B8)
  80 - filter(("T"."ORIG_REFLOT"="T"."REFDOSS" AND "T"."DTINTER"=NVL(:B1,"T"."DTINTER") AND (LNNVL("T"."ORIG_REFLOT">=NVL(:B6,:B7)) OR
              LNNVL("T"."ORIG_REFLOT"<=NVL(:B7,:B6)) OR LNNVL(NVL("T"."ORIG_REFLOT",'xXx')<>"T"."REFDOSS"))))
  81 - access("T"."REFDOSS"="C"."REFDOSS")
       filter(('CIT'||"T"."CODECR"=:B4 AND INTERNAL_FUNCTION("T"."CODECR") AND "T"."DTJOUR"=NVL(:B2,"T"."DTJOUR")))
  83 - access("M"."REFJOUR"="T"."REFJOUR")
  84 - access("E"."REFENCAISS"="T"."REFELEM")
  85 - filter(("E"."MOYENPAIMT"='PAIEMENT DECLARE' AND "E"."TYPENCAISS"='e_saencaiss'))
  86 - filter((((NVL(:B6,:B7)<=:B5 AND NVL(:B7,:B6)>=:B5) OR (NVL(:B6,:B7)<='NP' AND NVL(:B7,:B6)>='NP')) AND :B3 IS NULL AND :B4 IS NULL))
  89 - filter((NVL2("M"."REFJOUR",:B5,'NP')>=NVL(:B6,:B7) AND NVL2("M"."REFJOUR",:B5,'NP')<=NVL(:B7,:B6)))
  92 - access("C"."REFLOT"=:B8)
  93 - filter(("T"."ORIG_REFLOT"="T"."REFDOSS" AND "T"."DTINTER"<=NVL(:B1,"T"."DTINTER") AND (LNNVL('CIT'||"T"."CODECR"=:B4) OR LNNVL(:B3 IS NULL)
              OR LNNVL("T"."DTJOUR"=NVL(:B2,"T"."DTJOUR")) OR LNNVL("T"."DTINTER"=NVL(:B1,"T"."DTINTER")) OR LNNVL(:B4 IS NOT NULL)) AND
              (LNNVL("T"."ORIG_REFLOT">=NVL(:B6,:B7)) OR LNNVL("T"."ORIG_REFLOT"<=NVL(:B7,:B6)) OR LNNVL(NVL("T"."ORIG_REFLOT",'xXx')<>"T"."REFDOSS"))))
  94 - access("T"."REFDOSS"="C"."REFDOSS")
       filter((INTERNAL_FUNCTION("T"."CODECR") AND "T"."DTJOUR"<=NVL(:B2,"T"."DTJOUR")))
  96 - access("M"."REFJOUR"="T"."REFJOUR")
  97 - access("E"."REFENCAISS"="T"."REFELEM")
  98 - filter(("E"."MOYENPAIMT"='PAIEMENT DECLARE' AND "E"."TYPENCAISS"='e_saencaiss'))
  99 - filter((((NVL(:B6,:B7)<=:B5 AND NVL(:B7,:B6)>=:B5) OR (NVL(:B6,:B7)<='NP' AND NVL(:B7,:B6)>='NP')) AND :B5='NP'))
 102 - filter(("M"."ORIG_REFLOT" IS NULL AND NVL2("M"."REFJOUR",:B5,'NP')>=NVL(:B6,:B7) AND NVL2("M"."REFJOUR",:B5,'NP')<=NVL(:B7,:B6)))
 105 - access("C"."REFLOT"=:B8)
 106 - filter(("T"."ORIG_REFLOT"="T"."REFDOSS" AND "T"."ORIG_REFLOT"="T"."REFDOSS" AND (LNNVL(:B4 IS NULL) OR LNNVL(:B3 IS NULL) OR
              LNNVL("T"."DTJOUR"<=NVL(:B2,"T"."DTJOUR")) OR LNNVL("T"."DTINTER"<=NVL(:B1,"T"."DTINTER"))) AND (LNNVL('CIT'||"T"."CODECR"=:B4) OR LNNVL(:B3 IS
              NULL) OR LNNVL("T"."DTJOUR"=NVL(:B2,"T"."DTJOUR")) OR LNNVL("T"."DTINTER"=NVL(:B1,"T"."DTINTER")) OR LNNVL(:B4 IS NOT NULL)) AND
              (LNNVL("T"."ORIG_REFLOT">=NVL(:B6,:B7)) OR LNNVL("T"."ORIG_REFLOT"<=NVL(:B7,:B6)) OR LNNVL(NVL("T"."ORIG_REFLOT",'xXx')<>"T"."REFDOSS"))))
 107 - access("T"."REFDOSS"="C"."REFDOSS")
       filter(("T"."CODECR"='AENAT' OR "T"."CODECR"='ARFIN' OR "T"."CODECR"='ENCAT' OR "T"."CODECR"='RFIN'))
 109 - access("M"."REFJOUR"="T"."REFJOUR")
 110 - access("E"."REFENCAISS"="T"."REFELEM")
 111 - filter(("E"."MOYENPAIMT"='PAIEMENT DECLARE' AND "E"."TYPENCAISS"='e_saencaiss'))
 112 - filter((((NVL(:B6,:B7)<=:B5 AND NVL(:B7,:B6)>=:B5) OR (NVL(:B6,:B7)<='NP' AND NVL(:B7,:B6)>='NP')) AND :B3 IS NOT NULL))
 115 - filter(("M"."ORIG_REFLOT"=:B3 AND NVL2("M"."REFJOUR",:B5,'NP')>=NVL(:B6,:B7) AND NVL2("M"."REFJOUR",:B5,'NP')<=NVL(:B7,:B6) AND
              (LNNVL(:B5='NP') OR LNNVL("M"."ORIG_REFLOT" IS NULL) OR LNNVL("T"."ORIG_REFLOT"="T"."REFDOSS"))))
 118 - access("C"."REFLOT"=:B8)
 119 - filter(("T"."ORIG_REFLOT"="T"."REFDOSS" AND "T"."ORIG_REFLOT"="T"."REFDOSS" AND (LNNVL(:B4 IS NULL) OR LNNVL(:B3 IS NULL) OR
              LNNVL("T"."DTJOUR"<=NVL(:B2,"T"."DTJOUR")) OR LNNVL("T"."DTINTER"<=NVL(:B1,"T"."DTINTER"))) AND (LNNVL('CIT'||"T"."CODECR"=:B4) OR LNNVL(:B3 IS
              NULL) OR LNNVL("T"."DTJOUR"=NVL(:B2,"T"."DTJOUR")) OR LNNVL("T"."DTINTER"=NVL(:B1,"T"."DTINTER")) OR LNNVL(:B4 IS NOT NULL)) AND
              (LNNVL("T"."ORIG_REFLOT">=NVL(:B6,:B7)) OR LNNVL("T"."ORIG_REFLOT"<=NVL(:B7,:B6)) OR LNNVL(NVL("T"."ORIG_REFLOT",'xXx')<>"T"."REFDOSS"))))
 120 - access("T"."REFDOSS"="C"."REFDOSS")
       filter(("T"."CODECR"='AENAT' OR "T"."CODECR"='ARFIN' OR "T"."CODECR"='ENCAT' OR "T"."CODECR"='RFIN'))
 122 - access("M"."REFJOUR"="T"."REFJOUR")
 123 - access("E"."REFENCAISS"="T"."REFELEM")
 124 - filter(("E"."MOYENPAIMT"='PAIEMENT DECLARE' AND "E"."TYPENCAISS"='e_saencaiss'))
 125 - filter((:B6 IS NULL AND :B7 IS NULL AND :B4 IS NOT NULL AND :B3 IS NULL))
 128 - filter((LNNVL("T"."ORIG_REFLOT"="T"."REFDOSS") OR LNNVL(NVL2("M"."REFJOUR",:B5,'NP')>=NVL(:B6,:B7)) OR
              LNNVL(NVL2("M"."REFJOUR",:B5,'NP')<=NVL(:B7,:B6)) OR ((LNNVL(NVL(:B6,:B7)<=:B5) OR LNNVL(NVL(:B7,:B6)>=:B5)) AND (LNNVL(NVL(:B6,:B7)<='NP') OR
              LNNVL(NVL(:B7,:B6)>='NP')))))
 131 - access("C"."REFLOT"=:B8)
 132 - filter(("T"."DTINTER"=NVL(:B1,"T"."DTINTER") AND (LNNVL("T"."ORIG_REFLOT">=NVL(:B6,:B7)) OR LNNVL("T"."ORIG_REFLOT"<=NVL(:B7,:B6)) OR
              LNNVL(NVL("T"."ORIG_REFLOT",'xXx')<>"T"."REFDOSS"))))
 133 - access("T"."REFDOSS"="C"."REFDOSS")
       filter(('CIT'||"T"."CODECR"=:B4 AND INTERNAL_FUNCTION("T"."CODECR") AND "T"."DTJOUR"=NVL(:B2,"T"."DTJOUR")))
 135 - access("M"."REFJOUR"="T"."REFJOUR")
 136 - access("E"."REFENCAISS"="T"."REFELEM")
 137 - filter(("E"."MOYENPAIMT"='PAIEMENT DECLARE' AND "E"."TYPENCAISS"='e_saencaiss'))
 138 - filter((:B6 IS NULL AND :B7 IS NULL AND :B3 IS NULL AND :B4 IS NULL))
 141 - filter((LNNVL("T"."ORIG_REFLOT"="T"."REFDOSS") OR LNNVL(NVL2("M"."REFJOUR",:B5,'NP')>=NVL(:B6,:B7)) OR
              LNNVL(NVL2("M"."REFJOUR",:B5,'NP')<=NVL(:B7,:B6)) OR ((LNNVL(NVL(:B6,:B7)<=:B5) OR LNNVL(NVL(:B7,:B6)>=:B5)) AND (LNNVL(NVL(:B6,:B7)<='NP') OR
              LNNVL(NVL(:B7,:B6)>='NP')))))
 144 - access("C"."REFLOT"=:B8)
 145 - filter(("T"."DTINTER"<=NVL(:B1,"T"."DTINTER") AND (LNNVL('CIT'||"T"."CODECR"=:B4) OR LNNVL(:B3 IS NULL) OR
              LNNVL("T"."DTJOUR"=NVL(:B2,"T"."DTJOUR")) OR LNNVL("T"."DTINTER"=NVL(:B1,"T"."DTINTER")) OR LNNVL(:B4 IS NOT NULL)) AND
              (LNNVL("T"."ORIG_REFLOT">=NVL(:B6,:B7)) OR LNNVL("T"."ORIG_REFLOT"<=NVL(:B7,:B6)) OR LNNVL(NVL("T"."ORIG_REFLOT",'xXx')<>"T"."REFDOSS"))))
 146 - access("T"."REFDOSS"="C"."REFDOSS")
       filter((INTERNAL_FUNCTION("T"."CODECR") AND "T"."DTJOUR"<=NVL(:B2,"T"."DTJOUR")))
 148 - access("M"."REFJOUR"="T"."REFJOUR")
 149 - access("E"."REFENCAISS"="T"."REFELEM")
 150 - filter(("E"."MOYENPAIMT"='PAIEMENT DECLARE' AND "E"."TYPENCAISS"='e_saencaiss'))
 151 - filter((:B6 IS NULL AND :B7 IS NULL AND :B5='NP'))
 154 - filter(("M"."ORIG_REFLOT" IS NULL AND (LNNVL("T"."ORIG_REFLOT"="T"."REFDOSS") OR LNNVL(NVL2("M"."REFJOUR",:B5,'NP')>=NVL(:B6,:B7)) OR
              LNNVL(NVL2("M"."REFJOUR",:B5,'NP')<=NVL(:B7,:B6)) OR ((LNNVL(NVL(:B6,:B7)<=:B5) OR LNNVL(NVL(:B7,:B6)>=:B5)) AND (LNNVL(NVL(:B6,:B7)<='NP') OR
              LNNVL(NVL(:B7,:B6)>='NP'))))))
 157 - access("C"."REFLOT"=:B8)
 158 - filter(("T"."ORIG_REFLOT"="T"."REFDOSS" AND (LNNVL(:B4 IS NULL) OR LNNVL(:B3 IS NULL) OR LNNVL("T"."DTJOUR"<=NVL(:B2,"T"."DTJOUR")) OR
              LNNVL("T"."DTINTER"<=NVL(:B1,"T"."DTINTER"))) AND (LNNVL('CIT'||"T"."CODECR"=:B4) OR LNNVL(:B3 IS NULL) OR LNNVL("T"."DTJOUR"=NVL(:B2,"T"."DTJOUR"))
              OR LNNVL("T"."DTINTER"=NVL(:B1,"T"."DTINTER")) OR LNNVL(:B4 IS NOT NULL)) AND (LNNVL("T"."ORIG_REFLOT">=NVL(:B6,:B7)) OR
              LNNVL("T"."ORIG_REFLOT"<=NVL(:B7,:B6)) OR LNNVL(NVL("T"."ORIG_REFLOT",'xXx')<>"T"."REFDOSS"))))
 159 - access("T"."REFDOSS"="C"."REFDOSS")
       filter(("T"."CODECR"='AENAT' OR "T"."CODECR"='ARFIN' OR "T"."CODECR"='ENCAT' OR "T"."CODECR"='RFIN'))
 161 - access("M"."REFJOUR"="T"."REFJOUR")
 162 - access("E"."REFENCAISS"="T"."REFELEM")
 163 - filter(("E"."MOYENPAIMT"='PAIEMENT DECLARE' AND "E"."TYPENCAISS"='e_saencaiss'))
 164 - filter((:B6 IS NULL AND :B7 IS NULL AND :B3 IS NOT NULL))
 167 - filter(("M"."ORIG_REFLOT"=:B3 AND (LNNVL(:B5='NP') OR LNNVL("M"."ORIG_REFLOT" IS NULL) OR LNNVL("T"."ORIG_REFLOT"="T"."REFDOSS")) AND
              (LNNVL("T"."ORIG_REFLOT"="T"."REFDOSS") OR LNNVL(NVL2("M"."REFJOUR",:B5,'NP')>=NVL(:B6,:B7)) OR LNNVL(NVL2("M"."REFJOUR",:B5,'NP')<=NVL(:B7,:B6)) OR
              ((LNNVL(NVL(:B6,:B7)<=:B5) OR LNNVL(NVL(:B7,:B6)>=:B5)) AND (LNNVL(NVL(:B6,:B7)<='NP') OR LNNVL(NVL(:B7,:B6)>='NP'))))))
 170 - access("C"."REFLOT"=:B8)
 171 - filter(("T"."ORIG_REFLOT"="T"."REFDOSS" AND (LNNVL(:B4 IS NULL) OR LNNVL(:B3 IS NULL) OR LNNVL("T"."DTJOUR"<=NVL(:B2,"T"."DTJOUR")) OR
              LNNVL("T"."DTINTER"<=NVL(:B1,"T"."DTINTER"))) AND (LNNVL('CIT'||"T"."CODECR"=:B4) OR LNNVL(:B3 IS NULL) OR LNNVL("T"."DTJOUR"=NVL(:B2,"T"."DTJOUR"))
              OR LNNVL("T"."DTINTER"=NVL(:B1,"T"."DTINTER")) OR LNNVL(:B4 IS NOT NULL)) AND (LNNVL("T"."ORIG_REFLOT">=NVL(:B6,:B7)) OR
              LNNVL("T"."ORIG_REFLOT"<=NVL(:B7,:B6)) OR LNNVL(NVL("T"."ORIG_REFLOT",'xXx')<>"T"."REFDOSS"))))
 172 - access("T"."REFDOSS"="C"."REFDOSS")
       filter(("T"."CODECR"='AENAT' OR "T"."CODECR"='ARFIN' OR "T"."CODECR"='ENCAT' OR "T"."CODECR"='RFIN'))
 174 - access("M"."REFJOUR"="T"."REFJOUR")
 175 - access("E"."REFENCAISS"="T"."REFELEM")
 176 - filter(("E"."MOYENPAIMT"='PAIEMENT DECLARE' AND "E"."TYPENCAISS"='e_saencaiss'))
 183 - filter('AL'=:B11)
 185 - access("PF_NOM"=:B1 AND "PF_REFFACTOR" IS NULL)
 186 - filter('AL'=:B11)
 188 - access("PF_NOM"=:B1 AND "PF_REFFACTOR"=:B12)
       filter(LNNVL("PF_REFFACTOR" IS NULL))
 191 - filter('AN'=:B11)
 193 - access("PF_NOM"=:B1 AND "PF_REFFACTOR" IS NULL)
 194 - filter('AN'=:B11)
 196 - access("PF_NOM"=:B1 AND "PF_REFFACTOR"=:B12)
       filter(LNNVL("PF_REFFACTOR" IS NULL))
 199 - filter('DA'=:B11)
 201 - access("PF_NOM"=:B1 AND "PF_REFFACTOR" IS NULL)
 202 - filter('DA'=:B11)
 204 - access("PF_NOM"=:B1 AND "PF_REFFACTOR"=:B12)
       filter(LNNVL("PF_REFFACTOR" IS NULL))
 207 - filter('ES'=:B11)
 209 - access("PF_NOM"=:B1 AND "PF_REFFACTOR" IS NULL)
 210 - filter('ES'=:B11)
 212 - access("PF_NOM"=:B1 AND "PF_REFFACTOR"=:B12)
       filter(LNNVL("PF_REFFACTOR" IS NULL))
 215 - filter('FI'=:B11)
 217 - access("PF_NOM"=:B1 AND "PF_REFFACTOR" IS NULL)
 218 - filter('FI'=:B11)
 220 - access("PF_NOM"=:B1 AND "PF_REFFACTOR"=:B12)
       filter(LNNVL("PF_REFFACTOR" IS NULL))
 223 - filter('FR'=:B11)
 225 - access("PF_NOM"=:B1 AND "PF_REFFACTOR" IS NULL)
 226 - filter('FR'=:B11)
 228 - access("PF_NOM"=:B1 AND "PF_REFFACTOR"=:B12)
       filter(LNNVL("PF_REFFACTOR" IS NULL))
 231 - filter('HU'=:B11)
 233 - access("PF_NOM"=:B1 AND "PF_REFFACTOR" IS NULL)
 234 - filter('HU'=:B11)
 236 - access("PF_NOM"=:B1 AND "PF_REFFACTOR"=:B12)
       filter(LNNVL("PF_REFFACTOR" IS NULL))
 239 - filter('IT'=:B11)
 241 - access("PF_NOM"=:B1 AND "PF_REFFACTOR" IS NULL)
 242 - filter('IT'=:B11)
 244 - access("PF_NOM"=:B1 AND "PF_REFFACTOR"=:B12)
       filter(LNNVL("PF_REFFACTOR" IS NULL))
 247 - filter('NL'=:B11)
 249 - access("PF_NOM"=:B1 AND "PF_REFFACTOR" IS NULL)
 250 - filter('NL'=:B11)
 252 - access("PF_NOM"=:B1 AND "PF_REFFACTOR"=:B12)
       filter(LNNVL("PF_REFFACTOR" IS NULL))
 255 - filter('NO'=:B11)
 257 - access("PF_NOM"=:B1 AND "PF_REFFACTOR" IS NULL)
 258 - filter('NO'=:B11)
 260 - access("PF_NOM"=:B1 AND "PF_REFFACTOR"=:B12)
       filter(LNNVL("PF_REFFACTOR" IS NULL))
 263 - filter('PT'=:B11)
 265 - access("PF_NOM"=:B1 AND "PF_REFFACTOR" IS NULL)
 266 - filter('PT'=:B11)
 268 - access("PF_NOM"=:B1 AND "PF_REFFACTOR"=:B12)
       filter(LNNVL("PF_REFFACTOR" IS NULL))
 270 - filter((((:B4 IS NULL AND :B3 IS NULL AND "T"."DTINTER"<=NVL(:B1,"T"."DTINTER") AND "T"."DTJOUR"<=NVL(:B2,"T"."DTJOUR")) OR (:B3 IS NULL AND
              'CIT'||"CODECR"=:B4 AND "T"."DTJOUR"=NVL(:B2,"T"."DTJOUR") AND "T"."DTINTER"=NVL(:B1,"T"."DTINTER")) OR "T"."MEMO_DECOMPTE"=:B5) AND ((:B7 IS NULL
              AND :B6 IS NULL) OR ("T"."MEMO_DECOMPTE">=NVL(:B6,:B7) AND "T"."MEMO_DECOMPTE"<=NVL(:B7,:B6)))))
 271 - access("T"."REFDOSS"=:B8 AND (("T"."CODECR"='CRINS' OR "T"."CODECR"='RINDS')))
 274 - filter((((:B7 IS NULL AND :B6 IS NULL) OR (DECODE("T"."ORIG_REFLOT","T"."REFDOSS",NVL2("M"."REFJOUR",:B5,'NP'),"T"."ORIG_REFLOT")>=NVL(:B6,:B7
              ) AND DECODE("T"."ORIG_REFLOT","T"."REFDOSS",NVL2("M"."REFJOUR",:B5,'NP'),"T"."ORIG_REFLOT")<=NVL(:B7,:B6))) AND (("M"."ORIG_REFLOT"=:B3 AND
              "T"."ORIG_REFLOT"="T"."REFDOSS") OR (:B5='NP' AND "M"."ORIG_REFLOT" IS NULL AND "T"."ORIG_REFLOT"="T"."REFDOSS") OR (:B4 IS NULL AND :B3 IS NULL AND
              "T"."DTJOUR"<=NVL(:B2,"T"."DTJOUR") AND "T"."DTINTER"<=NVL(:B1,"T"."DTINTER")) OR ('CIT'||"T"."CODECR"=:B4 AND :B3 IS NULL AND
              "T"."DTJOUR"=NVL(:B2,"T"."DTJOUR") AND "T"."DTINTER"=NVL(:B1,"T"."DTINTER")))))
 278 - access("C"."REFLOT"=:B8)
 280 - access("G"."REFDOSS"="C"."REFDOSS")
       filter(("G"."TYPE"='DRAFT' OR "G"."TYPE"='SAF CN COMP'))
 281 - filter(("T"."REFDOSS"="C"."REFDOSS" AND INTERNAL_FUNCTION("T"."CODECR")))
 282 - access("G"."REFELEM"="T"."REFELEM")
 284 - access("M"."REFJOUR"="T"."REFJOUR")
 287 - filter(:B13='O')
 288 - filter((((:B7 IS NULL AND :B6 IS NULL) OR (DECODE("T"."ORIG_REFLOT","T"."REFDOSS",NVL2("M"."REFJOUR",:B5,'NP'),"T"."ORIG_REFLOT")>=NVL(:B6,:B7
              ) AND DECODE("T"."ORIG_REFLOT","T"."REFDOSS",NVL2("M"."REFJOUR",:B5,'NP'),"T"."ORIG_REFLOT")<=NVL(:B7,:B6))) AND (("M"."ORIG_REFLOT"=:B3 AND
              "T"."ORIG_REFLOT"="T"."REFDOSS") OR (:B5='NP' AND "M"."ORIG_REFLOT" IS NULL AND "T"."ORIG_REFLOT"="T"."REFDOSS") OR (:B4 IS NULL AND :B3 IS NULL AND
              "T"."DTJOUR"<=NVL(:B2,"T"."DTJOUR") AND "T"."DTINTER"<=NVL(:B1,"T"."DTINTER")) OR ('CIT'||"T"."CODECR"=:B4 AND :B3 IS NULL AND
              "T"."DTJOUR"=NVL(:B2,"T"."DTJOUR") AND "T"."DTINTER"=NVL(:B1,"T"."DTINTER")))))
 292 - access("C"."REFLOT"=:B8)
 294 - access("G"."REFDOSS"="C"."REFDOSS")
       filter(("G"."TYPE"='OPERATION DIVERSE   CREDITRICE' OR "G"."TYPE"='OPERATION DIVERSE DEBITRICE'))
 295 - filter(("T"."REFDOSS"="C"."REFDOSS" AND INTERNAL_FUNCTION("T"."CODECR")))
 296 - access("G"."REFELEM"="T"."REFELEM")
 298 - access("M"."REFJOUR"="T"."REFJOUR")
 301 - filter(:B13='O')
 302 - filter((((:B7 IS NULL AND :B6 IS NULL) OR (DECODE("T"."ORIG_REFLOT","T"."REFDOSS",NVL2("M"."REFJOUR",:B5,'NP'),"T"."ORIG_REFLOT")>=NVL(:B6,:B7
              ) AND DECODE("T"."ORIG_REFLOT","T"."REFDOSS",NVL2("M"."REFJOUR",:B5,'NP'),"T"."ORIG_REFLOT")<=NVL(:B7,:B6))) AND (("M"."ORIG_REFLOT"=:B3 AND
              "T"."ORIG_REFLOT"="T"."REFDOSS") OR (:B5='NP' AND "M"."ORIG_REFLOT" IS NULL AND "T"."ORIG_REFLOT"="T"."REFDOSS") OR (:B4 IS NULL AND :B3 IS NULL AND
              "T"."DTJOUR"<=NVL(:B2,"T"."DTJOUR") AND "T"."DTINTER"<=NVL(:B1,"T"."DTINTER")) OR ('CIT'||"T"."CODECR"=:B4 AND :B3 IS NULL AND
              "T"."DTJOUR"=NVL(:B2,"T"."DTJOUR") AND "T"."DTINTER"=NVL(:B1,"T"."DTINTER")))))
 306 - access("C"."REFLOT"=:B8)
 308 - access("G"."REFDOSS"="C"."REFDOSS")
       filter(("G"."TYPE"='ANNULATION ODC' OR "G"."TYPE"='ANNULATION ODD'))
 309 - filter(("T"."REFDOSS"="C"."REFDOSS" AND INTERNAL_FUNCTION("T"."CODECR")))
 310 - access("G"."REFELEM"="T"."REFELEM")
 312 - access("M"."REFJOUR"="T"."REFJOUR")
 314 - filter(("REFDOSS"=:B8 AND "TYPE_BALANCE"='CIT' AND ((:B4 IS NULL AND
              TO_NUMBER(TO_CHAR(INTERNAL_FUNCTION("ARCH"."MAX_ARCH_TRANS_DATE"),'j'))<=NVL(:B2,TO_NUMBER(TO_CHAR(INTERNAL_FUNCTION("ARCH"."MAX_ARCH_TRANS_DATE"),'j
              '))) AND TO_NUMBER(TO_CHAR(INTERNAL_FUNCTION("ARCH"."MAX_ARCH_VALUE_DATE"),'j'))<=NVL(:B1,TO_NUMBER(TO_CHAR(INTERNAL_FUNCTION("ARCH"."MAX_ARCH_VALUE_
              DATE"),'j')))) OR (:B4='CITARCHBAL' AND TO_NUMBER(TO_CHAR(INTERNAL_FUNCTION("ARCH"."MAX_ARCH_TRANS_DATE"),'j'))=NVL(:B2,TO_NUMBER(TO_CHAR(INTERNAL_FU
              NCTION("ARCH"."MAX_ARCH_TRANS_DATE"),'j'))) AND TO_NUMBER(TO_CHAR(INTERNAL_FUNCTION("ARCH"."MAX_ARCH_VALUE_DATE"),'j'))=NVL(:B1,TO_NUMBER(TO_CHAR(INT
              ERNAL_FUNCTION("ARCH"."MAX_ARCH_VALUE_DATE"),'j'))))) AND (("ARCH"."MAX_MEMO_DECOMPTE">=NVL(:B6,:B7) AND "ARCH"."MAX_MEMO_DECOMPTE"<=NVL(:B7,:B6))
              OR (:B7 IS NULL AND :B6 IS NULL))))
 315 - access("ARCH"."MAX_MEMO_DECOMPTE"=:B5)
*/
/********************************New Metrics***************************************/

/********************************Index statistics**********************************/

/********************************Other SQLs****************************************/          
/*

*/ 
/********************************Other SQLs****************************************/              
