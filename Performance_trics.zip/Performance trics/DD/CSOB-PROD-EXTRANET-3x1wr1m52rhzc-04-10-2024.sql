/********************************************************************************
*********       E-mail subject: CSOB-11064
*********             Instance: PROD
*********          Description: 
Problem:
Two queries from the EXTRANET on CSOB PROD were provided as slow.

Analysis:
We checked for the period in which the queries were executed, and found that they are with SQL_IDs 3x1wr1m52rhzc and 5531653ds9d4k.
We checked in the AWR for their execution plans and found that they were executed with two execution plans each. The first plan was the good plan, but the second plan was because of the 
Statistics Feedback, which plan was not optimal from performance point of view. We added hint to disable the Statistics Feedback and also some hints to stabilize the queries to be 
executed with good execution plan. Please use this hints only in these variant of the queries, where it is searching by ancrefdoss ( AND d.ancrefdoss = UPPER(:B3) ) in SQL 3x1wr1m52rhzc 
and by numss ( AND i.numss LIKE UPPER(:B3) ) in SQL 5531653ds9d4k.

Suggestion:
Please add hints only for this variant of the queries as it is shown in the New SQL section below.

*********               SQL_ID: 3x1wr1m52rhzc, 5531653ds9d4k
*********      Program/Package: 
*********              Request: Svetoslav Getsov
*********               Author: Dimitar Dimitrov
********* Received e-mail date: 01/10/2024
*********      Resolution date: 04/10/2024
*********  Trace old file here: \\epox\specifs\performance\tmp\
*********  Trace new file here:
***********************************************************************************/

/********************************OLD SQL*******************************************/

-- 3x1wr1m52rhzc

VAR B1 NUMBER;
EXEC :B1 := 403;
VAR B2 VARCHAR2(32);
EXEC :B2 := 'AN';
VAR B3 VARCHAR2(32);
EXEC :B3 := '226721900';
VAR B4 NUMBER;
EXEC :B4 := 11;
VAR B5 NUMBER;
EXEC :B5 := 1;

SELECT *
  FROM (SELECT inn.*, ROWNUM record_no
          FROM (SELECT DISTINCT COUNT(DISTINCT d.refdoss) OVER(PARTITION BY 'const') out_of,
                                d.ext_reference_u1 uniqueReference,
                                ( SELECT dtar_dt
                                    FROM t_filiere
                                   WHERE refdoss = D.refdoss
                                     AND dtfin_dt IS NULL
                                     AND ROWNUM = 1 ) acknowledgeDate,
                                d.refdoss id,
                                d.ancrefdoss ancrefdoss,
                                ( select ti.refdossext
                                    from t_intervenants ti, 
                                         v_extr_dom auth
                                   WHERE AUTH.TYPE = 'EXTR_GEST_CLIENT'
                                     AND AUTH.ABREV = TO_CHAR(:B1)
                                     AND ti.REFTYPE = AUTH.VALEUR_2
                                     AND ti.REFINDIVIDU = AUTH.VALEUR
                                     and ti.refdoss = d.refdoss
                                     AND ti.refdossext IS NOT NULL
                                     AND ROWNUM = 1 ) refdossext,
                                ( SELECT refext
                                    FROM t_individu tid
                                   WHERE imx_un_id = ( SELECT max(imx_un_id)
                                           FROM t_individu,
                                                g_dossier  contr,
                                                g_dossier  decompte
                                          WHERE societe = 'CLIENT_NUMBER'
                                            AND refindividu = i.refindividu
                                            AND refext2 = client.refindividu
                                            AND refext3 = contr.ancrefdoss
                                            AND decompte.categdoss LIKE
                                                'DECOMPTE%'
                                            AND decompte.refdoss = d.reflot
                                            AND decompte.reflot = contr.refdoss)) yourNumber,
                                decode(i.moralphy,
                                       'P',
                                       '',
                                       (TRIM(i.nom ||
                                             decode(i.prenom,
                                                    null,
                                                    '',
                                                    ', ' || i.prenom)))) debtorFullName,
                                decode(i.moralphy,
                                       'P',
                                       '',
                                       (decode(i.adr1,
                                               null,
                                               '',
                                               i.adr1 || ', ') ||
                                       decode(i.adr2,
                                               null,
                                               '',
                                               i.adr2 || ', ') ||
                                       decode(i.ville,
                                               null,
                                               '',
                                               i.ville || ', ') ||
                                       decode(i.cp, null, '', i.cp || ', ') ||
                                       decode(NVL(vd_div.valeur_trad,
                                                   vd_div.valeur),
                                               null,
                                               '',
                                               NVL(vd_div.valeur_trad,
                                                   vd_div.valeur) || ', ') ||
                                       nvl(vd.valeur_trad, vd.valeur))) debtorFullAddress,
                                i.cp debtorPC,
                                i.ville debtorCity,
                                policy.str1 policyNumber,
                                i.adr1 debtorAdr1,
                                i.division debtorState,
                                nvl(vd.valeur_trad, vd.valeur) debtorCountry,
                                nvl(d.soldedb_dos, 0) balance,
                                d.dt_dt_dt caseDate,
                                NVL((SELECT DECODE(abrev,
                                                  'CLO',
                                                  'Closed',
                                                  'Active')
                                      FROM v_domaine
                                     where type = 'typencour'
                                       AND valeur =
                                           (SELECT MAX(ta.typencour)
                                              FROM t_attente ta
                                             WHERE ta.refentite = d.refdoss)),
                                    'Active') case_type,
                                d.devise currency,
                                (SELECT 1
                                   FROM t_intervenants sr
                                  WHERE sr.reftype NOT IN ('DB', 'CL', 'XX')
                                    AND rownum = 1
                                    AND sr.refdoss = d.refdoss) thirdPartyInvolved,
                                DECODE((SELECT piece.refpiece
                                         FROM g_dossier g, g_piece piece
                                        WHERE piece.typpiece =
                                              'DBT_VERIF_REQ'
                                          AND piece.refdoss = g.refdoss
                                          AND g.categdoss like 'COLLECTION%'
                                          AND g.refdoss = d.refdoss
                                          and rownum = 1),
                                       null,
                                       'false',
                                       'true') AS isDebtVerif,
                                SUM(nvl(d.soldedb, 0)) over() AS TOTAL_SUM
                  FROM g_dossier d,
                       g_piece pieceCase,
                       t_intervenants t,
                       (select pd.str1 str1, p.refdoss refdoss
                          from g_piece p, g_piecedet pd
                         WHERE p.typpiece = 'CONTRAT'
                           AND pd.type = 'CI CONTRACTS'
                           AND pd.refpiece = p.refpiece
                           AND pd.fg01 = 'O') policy,
                       g_individu i,
                       t_intervenants client,
                       g_individu icl,
                       v_tdomaine vd,
                       t_intervenants t_int,
                       LST_SCORE lst,
                       (SELECT valeur
                          FROM v_domaine
                         WHERE TYPE = 'categdoss'
                           AND (ecran = 'X' OR EXISTS
                                (SELECT 1
                                   FROM g_etude
                                  WHERE activite_gpc IN ('G', 'T')))) vd_cat,
                       v_tdomaine vd_div,
                       v_tdomaine vd_categdoss,
                       v_tdomaine vd_pieceinit,
                       v_extr_dom auth
                 WHERE d.categdoss = vd_cat.valeur
                   AND pieceCase.refdoss = d.refdoss
                   and pieceCase.typpiece = d.pieceinit
                   AND lst.refdoss(+) = d.refdoss
                   AND d.categdoss <> 'COMPTE DB CTR'
                   AND d.refdoss = t.refdoss
                   AND t.reftype = 'DB'
                   AND t.refindividu = i.refindividu
                   AND d.refdoss not like 'GL%'
                   AND d.refdoss = client.refdoss
                   AND client.reftype in ('CL', 'TC')
                   AND icl.refindividu = client.refindividu
                   AND vd.type(+) = 'pays'
                   AND vd.langue(+) = :B2
                   AND vd.abrev(+) = i.pays
                   AND vd_div.TYPE(+) = 'DIVISION TERRITORIALE'
                   AND vd_div.ecran(+) = i.pays
                   AND vd_div.langue(+) = :B2
                   AND vd_div.abrev(+) = i.division
                   AND NVL(d.fg_excl_from_extr, 'N') != 'O'
                   AND decode(d.refhierarchie,
                              null,
                              'N',
                              (SELECT NVL(FG_EXCL_FROM_EXTR, 'N')
                                 from g_dossier
                                where refdoss = d.refhierarchie)) = 'N'
                   AND decode(d.refhierarchie2,
                              null,
                              'N',
                              (SELECT NVL(FG_EXCL_FROM_EXTR, 'N')
                                 from g_dossier
                                where refdoss = d.refhierarchie2)) = 'N'
                   AND NVL(FG_FRM_INC, 'N') != 'O'
                   AND d.refdoss = t_int.refdoss
                   AND vd_categdoss.valeur = d.categdoss
                   AND vd_categdoss.langue = :B2
                   AND vd_pieceinit.valeur = d.pieceinit
                   AND vd_pieceinit.langue = :B2
                   AND vd_pieceinit.champ = 'pieceinit'
                   AND policy.refdoss(+) = d.refhierarchie
                   AND auth.type = 'EXTR_GEST_CLIENT'
                   AND auth.abrev = to_char(:B1)
                   AND t_int.reftype = auth.valeur_2
                   AND t_int.refindividu = auth.valeur
                   AND d.ancrefdoss = UPPER(:B3)
                 ORDER BY id DESC NULLS FIRST) inn
         WHERE 1 = 1
           AND ROWNUM <= :B4)
 WHERE 1 = 1
   AND record_no >= :B5;



-- 5531653ds9d4k

VAR B1 NUMBER;
EXEC :B1 := 403;
VAR B2 VARCHAR2(32);
EXEC :B2 := 'AN';
VAR B3 VARCHAR2(32);
EXEC :B3 := '455228112';
VAR B4 NUMBER;
EXEC :B4 := 11;
VAR B5 NUMBER;
EXEC :B5 := 1;

SELECT *
  FROM (SELECT inn.*, ROWNUM record_no
          FROM (SELECT /*+ leading(I) index(I NUMSS_IDX) */
                DISTINCT COUNT(DISTINCT d.refdoss) OVER(PARTITION BY 'const') out_of,
                         d.ext_reference_u1 uniqueReference,
                         (SELECT dtar_dt
                            FROM t_filiere
                           WHERE refdoss = D.refdoss
                             AND dtfin_dt IS NULL
                             AND ROWNUM = 1) acknowledgeDate,
                         d.refdoss id,
                         d.ancrefdoss ancrefdoss,
                         (select ti.refdossext
                            from t_intervenants ti, v_extr_dom auth
                           WHERE AUTH.TYPE = 'EXTR_GEST_CLIENT'
                             AND AUTH.ABREV = TO_CHAR(:B1)
                             AND ti.REFTYPE = AUTH.VALEUR_2
                             AND ti.REFINDIVIDU = AUTH.VALEUR
                             and ti.refdoss = d.refdoss
                             AND ti.refdossext IS NOT NULL
                             AND ROWNUM = 1) refdossext,
                         (SELECT refext
                            FROM t_individu tid
                           WHERE imx_un_id =
                                 (SELECT max(imx_un_id)
                                    FROM t_individu,
                                         g_dossier  contr,
                                         g_dossier  decompte
                                   WHERE societe = 'CLIENT_NUMBER'
                                     AND refindividu = i.refindividu
                                     AND refext2 = client.refindividu
                                     AND refext3 = contr.ancrefdoss
                                     AND decompte.categdoss LIKE 'DECOMPTE%'
                                     AND decompte.refdoss = d.reflot
                                     AND decompte.reflot = contr.refdoss)) yourNumber,
                         decode(i.moralphy,
                                'P',
                                '',
                                (TRIM(i.nom ||
                                      decode(i.prenom,
                                             null,
                                             '',
                                             ', ' || i.prenom)))) debtorFullName,
                         decode(i.moralphy,
                                'P',
                                '',
                                (decode(i.adr1, null, '', i.adr1 || ', ') ||
                                decode(i.adr2, null, '', i.adr2 || ', ') ||
                                decode(i.ville, null, '', i.ville || ', ') ||
                                decode(i.cp, null, '', i.cp || ', ') ||
                                decode(NVL(vd_div.valeur_trad, vd_div.valeur),
                                        null,
                                        '',
                                        NVL(vd_div.valeur_trad, vd_div.valeur) || ', ') ||
                                nvl(vd.valeur_trad, vd.valeur))) debtorFullAddress,
                         i.cp debtorPC,
                         i.ville debtorCity,
                         policy.str1 policyNumber,
                         i.adr1 debtorAdr1,
                         i.division debtorState,
                         nvl(vd.valeur_trad, vd.valeur) debtorCountry,
                         nvl(d.soldedb_dos, 0) balance,
                         d.dt_dt_dt caseDate,
                         NVL((SELECT DECODE(abrev, 'CLO', 'Closed', 'Active')
                               FROM v_domaine
                              where type = 'typencour'
                                AND valeur =
                                    (SELECT MAX(ta.typencour)
                                       FROM t_attente ta
                                      WHERE ta.refentite = d.refdoss)),
                             'Active') case_type,
                         d.devise currency,
                         (SELECT 1
                            FROM t_intervenants sr
                           WHERE sr.reftype NOT IN ('DB', 'CL', 'XX')
                             AND rownum = 1
                             AND sr.refdoss = d.refdoss) thirdPartyInvolved,
                         DECODE((SELECT piece.refpiece
                                  FROM g_dossier g, g_piece piece
                                 WHERE piece.typpiece = 'DBT_VERIF_REQ'
                                   AND piece.refdoss = g.refdoss
                                   AND g.categdoss like 'COLLECTION%'
                                   AND g.refdoss = d.refdoss
                                   and rownum = 1),
                                null,
                                'false',
                                'true') AS isDebtVerif,
                         SUM(nvl(d.soldedb, 0)) over() AS TOTAL_SUM
                  FROM g_dossier d,
                       g_piece pieceCase,
                       t_intervenants t,
                       (select pd.str1 str1, p.refdoss refdoss
                          from g_piece p, g_piecedet pd
                         WHERE p.typpiece = 'CONTRAT'
                           AND pd.type = 'CI CONTRACTS'
                           AND pd.refpiece = p.refpiece
                           AND pd.fg01 = 'O') policy,
                       g_individu i,
                       t_intervenants client,
                       g_individu icl,
                       v_tdomaine vd,
                       t_intervenants t_int,
                       LST_SCORE lst,
                       (SELECT valeur
                          FROM v_domaine
                         WHERE TYPE = 'categdoss'
                           AND (ecran = 'X' OR EXISTS
                                (SELECT 1
                                   FROM g_etude
                                  WHERE activite_gpc IN ('G', 'T')))) vd_cat,
                       v_tdomaine vd_div,
                       v_tdomaine vd_categdoss,
                       v_tdomaine vd_pieceinit,
                       v_extr_dom auth
                 WHERE d.categdoss = vd_cat.valeur
                   AND pieceCase.refdoss = d.refdoss
                   and pieceCase.typpiece = d.pieceinit
                   AND lst.refdoss(+) = d.refdoss
                   AND d.categdoss <> 'COMPTE DB CTR'
                   AND d.refdoss = t.refdoss
                   AND t.reftype = 'DB'
                   AND t.refindividu = i.refindividu
                   AND d.refdoss not like 'GL%'
                   AND d.refdoss = client.refdoss
                   AND client.reftype in ('CL', 'TC')
                   AND icl.refindividu = client.refindividu
                   AND vd.type(+) = 'pays'
                   AND vd.langue(+) = :B2
                   AND vd.abrev(+) = i.pays
                   AND vd_div.TYPE(+) = 'DIVISION TERRITORIALE'
                   AND vd_div.ecran(+) = i.pays
                   AND vd_div.langue(+) = :B2
                   AND vd_div.abrev(+) = i.division
                   AND NVL(d.fg_excl_from_extr, 'N') != 'O'
                   AND decode(d.refhierarchie,
                              null,
                              'N',
                              (SELECT NVL(FG_EXCL_FROM_EXTR, 'N')
                                 from g_dossier
                                where refdoss = d.refhierarchie)) = 'N'
                   AND decode(d.refhierarchie2,
                              null,
                              'N',
                              (SELECT NVL(FG_EXCL_FROM_EXTR, 'N')
                                 from g_dossier
                                where refdoss = d.refhierarchie2)) = 'N'
                   AND NVL(FG_FRM_INC, 'N') != 'O'
                   AND d.refdoss = t_int.refdoss
                   AND vd_categdoss.valeur = d.categdoss
                   AND vd_categdoss.langue = :B2
                   AND vd_pieceinit.valeur = d.pieceinit
                   AND vd_pieceinit.langue = :B2
                   AND vd_pieceinit.champ = 'pieceinit'
                   AND policy.refdoss(+) = d.refhierarchie
                   AND auth.type = 'EXTR_GEST_CLIENT'
                   AND auth.abrev = to_char(:B1)
                   AND t_int.reftype = auth.valeur_2
                   AND t_int.refindividu = auth.valeur
                   AND i.numss LIKE UPPER(:B3)
                 ORDER BY id DESC NULLS FIRST) inn
         WHERE 1 = 1
           AND ROWNUM <= :B4)
 WHERE 1 = 1
   AND record_no >= :B5;
/********************************OLD SQL*******************************************/
/********************************OLD Metrics***************************************/
/*
MODULE                           PROGRAM                                            CLIENT_ID       SQL_ID                                   PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC                                                                                                        
-------------------------------- -------------------------------------------------- --------------- --------------------------------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------                                                                                                      
EXTRANET                         EXTRANET                                           IMX_AM          3x1wr1m52rhzc                           1071044379       1811      31467                      2024/09/25 08:48:00  2024/09/25 08:51:50          24                    1 +000000000 00:03:50.128 73%                                                                                                         
EXTRANET                         EXTRANET                                                           5531653ds9d4k                           1705484302       1375      63384                      2024/09/25 08:50:00  2024/09/25 08:51:20           9                    1 +000000000 00:01:20.065 27%                                                                                                         



INSTANCE_NUMBER SQL_ID                                      ELAPSED MAX_WAIT_ON     PC_OF  WAIT_TIME            GETS      READS       ROWS  ELAP/EXEC       GETS/EXEC READS/EXEC  ROWS/EXEC       EXEC PLAN_HASH_VALUE
--------------- --------------------------------------- ----------- --------------- ----- ---------- --------------- ---------- ---------- ---------- --------------- ---------- ---------- ---------- ---------------
              1 3x1wr1m52rhzc                                   566 IO              93%   543.246374        12979661     989015          0     566.49        12979661     989015          0          1      1071044379
              1 3x1wr1m52rhzc                                     1 CPU             97%      .579233             375         22          1        1.3             375         22          1          1      3515275443
              1 5531653ds9d4k                                    85 IO              90%    78.411223          173198     143930          6      84.63          173198     143930          6          1      1705484302
              1 5531653ds9d4k                                     4 CPU             98%     1.824396            1000         35          4       4.13            1000         35          4          1      1996081953


SQL_ID                                     SNAP_ID INSTANCE_NUMBER NAME                   POSITION DUP_POSITION DATATYPE_STRING      VALUE_STRING                             INTERVAL
--------------------------------------- ---------- --------------- -------------------- ---------- ------------ -------------------- ---------------------------------------- ----------------------------------------------------
3x1wr1m52rhzc                                16756               1 :1                            1              NUMBER               403                                      2024/09/25 09
3x1wr1m52rhzc                                16756               1 :2                            2              VARCHAR2(32)         AN                                       2024/09/25 09
3x1wr1m52rhzc                                16756               1 :3                            3              VARCHAR2(32)         AN                                       2024/09/25 09
3x1wr1m52rhzc                                16756               1 :4                            4              VARCHAR2(32)         AN                                       2024/09/25 09
3x1wr1m52rhzc                                16756               1 :5                            5              VARCHAR2(32)         AN                                       2024/09/25 09
3x1wr1m52rhzc                                16756               1 :6                            6              NUMBER               403                                      2024/09/25 09
3x1wr1m52rhzc                                16756               1 :7                            7              VARCHAR2(32)         219021092                                2024/09/25 09
3x1wr1m52rhzc                                16756               1 :7                            7              VARCHAR2(32)         226721900                                2024/09/25 09
3x1wr1m52rhzc                                16756               1 :8                            8              NUMBER               11                                       2024/09/25 09
3x1wr1m52rhzc                                16756               1 :9                            9              NUMBER               1                                        2024/09/25 09

5531653ds9d4k                                16756               1 :1                            1              NUMBER               403                                      2024/09/25 09
5531653ds9d4k                                16756               1 :2                            2              VARCHAR2(32)         AN                                       2024/09/25 09
5531653ds9d4k                                16756               1 :3                            3              VARCHAR2(32)         AN                                       2024/09/25 09
5531653ds9d4k                                16756               1 :4                            4              VARCHAR2(32)         AN                                       2024/09/25 09
5531653ds9d4k                                16756               1 :5                            5              VARCHAR2(32)         AN                                       2024/09/25 09
5531653ds9d4k                                16756               1 :6                            6              NUMBER               403                                      2024/09/25 09
5531653ds9d4k                                16756               1 :7                            7              VARCHAR2(32)         455228112                                2024/09/25 09
5531653ds9d4k                                16756               1 :7                            7              VARCHAR2(32)         7507141235                               2024/09/25 09
5531653ds9d4k                                16756               1 :8                            8              NUMBER               11                                       2024/09/25 09
5531653ds9d4k                                16756               1 :9                            9              NUMBER               1                                        2024/09/25 09


SQL_ID                                  SQL_PLAN_HASH_VALUE SQL_PLAN_LINE_ID SQL_PLAN_OPERATION             SQL_PLAN_OPTIONS                   ACTIVE
--------------------------------------- ------------------- ---------------- ------------------------------ ------------------------------ ----------
3x1wr1m52rhzc                                    1071044379               61 TABLE ACCESS                   BY INDEX ROWID                         57
5531653ds9d4k                                    1705484302              100 INDEX                          SKIP SCAN                               8
5531653ds9d4k                                    1705484302                                                                                         1
3x1wr1m52rhzc                                    3515275443                                                                                         1


-- 3x1wr1m52rhzc

Plan hash value: 1071044379
-----------------------------------------------------------------------------------------------------------------
| Id  | Operation                                                 | Name                  | E-Rows | Cost (%CPU)|
-----------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                                          |                       |        |    65 (100)|
|*  1 |  COUNT STOPKEY                                            |                       |        |            |
|*  2 |   TABLE ACCESS BY INDEX ROWID BATCHED                     | T_FILIERE             |      1 |     1   (0)|
|*  3 |    INDEX RANGE SCAN                                       | T_FIL_DTFINDEB        |      7 |     1   (0)|
|*  4 |  COUNT STOPKEY                                            |                       |        |            |
|   5 |   NESTED LOOPS                                            |                       |      1 |     2   (0)|
|   6 |    NESTED LOOPS                                           |                       |      1 |     2   (0)|
|*  7 |     TABLE ACCESS BY INDEX ROWID BATCHED                   | V_EXTR_DOM            |      1 |     1   (0)|
|*  8 |      INDEX RANGE SCAN                                     | TYPEABREV             |      2 |     1   (0)|
|*  9 |     INDEX RANGE SCAN                                      | INT_REFDOSS           |      1 |     1   (0)|
|* 10 |    TABLE ACCESS BY INDEX ROWID                            | T_INTERVENANTS        |      1 |     1   (0)|
|  11 |  TABLE ACCESS BY INDEX ROWID                              | T_INDIVIDU            |      1 |     1   (0)|
|* 12 |   INDEX UNIQUE SCAN                                       | PK_T_INDIVIDU         |      1 |     1   (0)|
|  13 |    SORT AGGREGATE                                         |                       |      1 |            |
|  14 |     NESTED LOOPS                                          |                       |      1 |     3   (0)|
|  15 |      NESTED LOOPS                                         |                       |      2 |     3   (0)|
|  16 |       NESTED LOOPS                                        |                       |      1 |     2   (0)|
|* 17 |        TABLE ACCESS BY INDEX ROWID BATCHED                | G_DOSSIER             |      1 |     1   (0)|
|* 18 |         INDEX FULL SCAN                                   | DOSS_LOT              |      1 |     1   (0)|
|  19 |        TABLE ACCESS BY INDEX ROWID                        | G_DOSSIER             |      1 |     1   (0)|
|* 20 |         INDEX UNIQUE SCAN                                 | DOS_REFDOSS           |      1 |     1   (0)|
|* 21 |       INDEX RANGE SCAN                                    | IX_T_INDIVIDU         |      2 |     1   (0)|
|* 22 |      TABLE ACCESS BY INDEX ROWID                          | T_INDIVIDU            |      1 |     1   (0)|
|  23 |  TABLE ACCESS BY INDEX ROWID BATCHED                      | V_DOMAINE             |      1 |     1   (0)|
|* 24 |   INDEX RANGE SCAN                                        | DOM_TYPVAL            |      3 |     1   (0)|
|  25 |    SORT AGGREGATE                                         |                       |      1 |            |
|  26 |     TABLE ACCESS BY INDEX ROWID BATCHED                   | T_ATTENTE             |      1 |     1   (0)|
|* 27 |      INDEX RANGE SCAN                                     | PK_ATTENTE            |      1 |     1   (0)|
|* 28 |  COUNT STOPKEY                                            |                       |        |            |
|* 29 |   INDEX RANGE SCAN                                        | INT_REFDOSS           |      3 |     1   (0)|
|* 30 |  COUNT STOPKEY                                            |                       |        |            |
|  31 |   NESTED LOOPS                                            |                       |      1 |     2   (0)|
|* 32 |    TABLE ACCESS BY INDEX ROWID                            | G_DOSSIER             |      1 |     1   (0)|
|* 33 |     INDEX UNIQUE SCAN                                     | DOS_REFDOSS           |      1 |     1   (0)|
|  34 |    TABLE ACCESS BY INDEX ROWID BATCHED                    | G_PIECE               |      1 |     1   (0)|
|* 35 |     INDEX RANGE SCAN                                      | PIE_REFDOSS           |      1 |     1   (0)|
|* 36 |  VIEW                                                     |                       |      1 |    65   (5)|
|* 37 |   COUNT STOPKEY                                           |                       |        |            |
|  38 |    VIEW                                                   |                       |      1 |    65   (5)|
|* 39 |     SORT ORDER BY STOPKEY                                 |                       |      1 |    65   (5)|
|  40 |      HASH UNIQUE                                          |                       |      1 |    64   (4)|
|  41 |       WINDOW SORT                                         |                       |      1 |    65   (5)|
|* 42 |        FILTER                                             |                       |        |            |
|* 43 |         HASH JOIN                                         |                       |      1 |    52   (0)|
|  44 |          JOIN FILTER CREATE                               | :BF0000               |      1 |    42   (0)|
|  45 |           NESTED LOOPS                                    |                       |      1 |    42   (0)|
|  46 |            NESTED LOOPS OUTER                             |                       |      1 |    32   (0)|
|  47 |             NESTED LOOPS OUTER                            |                       |      1 |    22   (0)|
|  48 |              NESTED LOOPS                                 |                       |      1 |    12   (0)|
|  49 |               NESTED LOOPS                                |                       |      1 |    11   (0)|
|  50 |                NESTED LOOPS                               |                       |      1 |    10   (0)|
|  51 |                 NESTED LOOPS                              |                       |      1 |     9   (0)|
|  52 |                  NESTED LOOPS                             |                       |      1 |     8   (0)|
|  53 |                   NESTED LOOPS                            |                       |      1 |     7   (0)|
|  54 |                    NESTED LOOPS OUTER                     |                       |      1 |     6   (0)|
|  55 |                     NESTED LOOPS OUTER                    |                       |      1 |     4   (0)|
|  56 |                      NESTED LOOPS                         |                       |      1 |     3   (0)|
|  57 |                       NESTED LOOPS                        |                       |      1 |     2   (0)|
|* 58 |                        TABLE ACCESS BY INDEX ROWID BATCHED| V_EXTR_DOM            |      1 |     1   (0)|
|* 59 |                         INDEX RANGE SCAN                  | TYPEABREV             |      2 |     1   (0)|
|* 60 |                        INDEX RANGE SCAN                   | INT_INDIV             |      1 |     1   (0)|
|* 61 |                       TABLE ACCESS BY INDEX ROWID         | G_DOSSIER             |      1 |     1   (0)|
|* 62 |                        INDEX UNIQUE SCAN                  | DOS_REFDOSS           |      1 |     1   (0)|
|* 63 |                      INDEX RANGE SCAN                     | LST_SCORE_REFDOSS_IDX |      1 |     1   (0)|
|  64 |                     VIEW PUSHED PREDICATE                 |                       |      1 |     2   (0)|
|  65 |                      NESTED LOOPS                         |                       |      1 |     2   (0)|
|  66 |                       NESTED LOOPS                        |                       |      1 |     2   (0)|
|  67 |                        TABLE ACCESS BY INDEX ROWID BATCHED| G_PIECE               |      1 |     1   (0)|
|* 68 |                         INDEX RANGE SCAN                  | PIE_REFDOSS           |      1 |     1   (0)|
|* 69 |                        INDEX RANGE SCAN                   | G_PIECEDET_REFP       |      1 |     1   (0)|
|* 70 |                       TABLE ACCESS BY INDEX ROWID         | G_PIECEDET            |      1 |     1   (0)|
|* 71 |                    TABLE ACCESS BY INDEX ROWID BATCHED    | V_DOMAINE             |      1 |     1   (0)|
|* 72 |                     INDEX RANGE SCAN                      | DOM_TYPVAL            |      3 |     1   (0)|
|* 73 |                     TABLE ACCESS FULL                     | G_ETUDE               |      1 |     2   (0)|
|* 74 |                   INDEX RANGE SCAN                        | INT_REFDOSS           |      1 |     1   (0)|
|* 75 |                  INDEX RANGE SCAN                         | INT_REFDOSS           |      1 |     1   (0)|
|  76 |                 TABLE ACCESS BY INDEX ROWID               | G_INDIVIDU            |      1 |     1   (0)|
|* 77 |                  INDEX UNIQUE SCAN                        | IND_REFINDIV          |      1 |     1   (0)|
|* 78 |                INDEX UNIQUE SCAN                          | IND_REFINDIV          |      1 |     1   (0)|
|* 79 |               INDEX RANGE SCAN                            | PIE_REFDOSS           |      1 |     1   (0)|
|* 80 |              VIEW                                         | V_TDOMAINE            |      1 |    10   (0)|
|  81 |               UNION ALL PUSHED PREDICATE                  |                       |        |            |
|* 82 |                FILTER                                     |                       |        |            |
|  83 |                 TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE             |      1 |     1   (0)|
|* 84 |                  INDEX RANGE SCAN                         | DOM_TYPABREV          |      2 |     1   (0)|
|* 85 |                FILTER                                     |                       |        |            |
|  86 |                 TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE             |      1 |     1   (0)|
|* 87 |                  INDEX RANGE SCAN                         | DOM_TYPABREV          |      2 |     1   (0)|
|* 88 |                FILTER                                     |                       |        |            |
|  89 |                 TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE             |      1 |     1   (0)|
|* 90 |                  INDEX RANGE SCAN                         | DOM_TYPABREV          |      2 |     1   (0)|
|* 91 |                FILTER                                     |                       |        |            |
|  92 |                 TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE             |      1 |     1   (0)|
|* 93 |                  INDEX RANGE SCAN                         | DOM_TYPABREV          |      2 |     1   (0)|
|* 94 |                FILTER                                     |                       |        |            |
|  95 |                 TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE             |      1 |     1   (0)|
|* 96 |                  INDEX RANGE SCAN                         | DOM_TYPABREV          |      2 |     1   (0)|
|* 97 |                FILTER                                     |                       |        |            |
|  98 |                 TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE             |      1 |     1   (0)|
|* 99 |                  INDEX RANGE SCAN                         | DOM_TYPABREV          |      2 |     1   (0)|
|*100 |                FILTER                                     |                       |        |            |
| 101 |                 TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE             |      1 |     1   (0)|
|*102 |                  INDEX RANGE SCAN                         | DOM_TYPABREV          |      2 |     1   (0)|
|*103 |                FILTER                                     |                       |        |            |
| 104 |                 TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE             |      1 |     1   (0)|
|*105 |                  INDEX RANGE SCAN                         | DOM_TYPABREV          |      2 |     1   (0)|
|*106 |                FILTER                                     |                       |        |            |
| 107 |                 TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE             |      1 |     1   (0)|
|*108 |                  INDEX RANGE SCAN                         | DOM_TYPABREV          |      2 |     1   (0)|
|*109 |                FILTER                                     |                       |        |            |
| 110 |                 TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE             |      1 |     1   (0)|
|*111 |                  INDEX RANGE SCAN                         | DOM_TYPABREV          |      2 |     1   (0)|
| 112 |             VIEW                                          | V_TDOMAINE            |      1 |    10   (0)|
| 113 |              UNION ALL PUSHED PREDICATE                   |                       |        |            |
|*114 |               FILTER                                      |                       |        |            |
| 115 |                TABLE ACCESS BY INDEX ROWID BATCHED        | V_DOMAINE             |      1 |     1   (0)|
|*116 |                 INDEX RANGE SCAN                          | DOM_TYPABREV          |      2 |     1   (0)|
|*117 |               FILTER                                      |                       |        |            |
| 118 |                TABLE ACCESS BY INDEX ROWID BATCHED        | V_DOMAINE             |      1 |     1   (0)|
|*119 |                 INDEX RANGE SCAN                          | DOM_TYPABREV          |      2 |     1   (0)|
|*120 |               FILTER                                      |                       |        |            |
| 121 |                TABLE ACCESS BY INDEX ROWID BATCHED        | V_DOMAINE             |      1 |     1   (0)|
|*122 |                 INDEX RANGE SCAN                          | DOM_TYPABREV          |      2 |     1   (0)|
|*123 |               FILTER                                      |                       |        |            |
| 124 |                TABLE ACCESS BY INDEX ROWID BATCHED        | V_DOMAINE             |      1 |     1   (0)|
|*125 |                 INDEX RANGE SCAN                          | DOM_TYPABREV          |      2 |     1   (0)|
|*126 |               FILTER                                      |                       |        |            |
| 127 |                TABLE ACCESS BY INDEX ROWID BATCHED        | V_DOMAINE             |      1 |     1   (0)|
|*128 |                 INDEX RANGE SCAN                          | DOM_TYPABREV          |      2 |     1   (0)|
|*129 |               FILTER                                      |                       |        |            |
| 130 |                TABLE ACCESS BY INDEX ROWID BATCHED        | V_DOMAINE             |      1 |     1   (0)|
|*131 |                 INDEX RANGE SCAN                          | DOM_TYPABREV          |      2 |     1   (0)|
|*132 |               FILTER                                      |                       |        |            |
| 133 |                TABLE ACCESS BY INDEX ROWID BATCHED        | V_DOMAINE             |      1 |     1   (0)|
|*134 |                 INDEX RANGE SCAN                          | DOM_TYPABREV          |      2 |     1   (0)|
|*135 |               FILTER                                      |                       |        |            |
| 136 |                TABLE ACCESS BY INDEX ROWID BATCHED        | V_DOMAINE             |      1 |     1   (0)|
|*137 |                 INDEX RANGE SCAN                          | DOM_TYPABREV          |      2 |     1   (0)|
|*138 |               FILTER                                      |                       |        |            |
| 139 |                TABLE ACCESS BY INDEX ROWID BATCHED        | V_DOMAINE             |      1 |     1   (0)|
|*140 |                 INDEX RANGE SCAN                          | DOM_TYPABREV          |      2 |     1   (0)|
|*141 |               FILTER                                      |                       |        |            |
| 142 |                TABLE ACCESS BY INDEX ROWID BATCHED        | V_DOMAINE             |      1 |     1   (0)|
|*143 |                 INDEX RANGE SCAN                          | DOM_TYPABREV          |      2 |     1   (0)|
| 144 |            VIEW                                           | V_TDOMAINE            |      1 |    10   (0)|
| 145 |             UNION ALL PUSHED PREDICATE                    |                       |        |            |
|*146 |              FILTER                                       |                       |        |            |
|*147 |               INDEX RANGE SCAN                            | DOM_TYPVAL            |      2 |     1   (0)|
|*148 |              FILTER                                       |                       |        |            |
|*149 |               INDEX RANGE SCAN                            | DOM_TYPVAL            |      2 |     1   (0)|
|*150 |              FILTER                                       |                       |        |            |
|*151 |               INDEX RANGE SCAN                            | DOM_TYPVAL            |      2 |     1   (0)|
|*152 |              FILTER                                       |                       |        |            |
|*153 |               INDEX RANGE SCAN                            | DOM_TYPVAL            |      2 |     1   (0)|
|*154 |              FILTER                                       |                       |        |            |
|*155 |               INDEX RANGE SCAN                            | DOM_TYPVAL            |      2 |     1   (0)|
|*156 |              FILTER                                       |                       |        |            |
|*157 |               INDEX RANGE SCAN                            | DOM_TYPVAL            |      2 |     1   (0)|
|*158 |              FILTER                                       |                       |        |            |
|*159 |               INDEX RANGE SCAN                            | DOM_TYPVAL            |      2 |     1   (0)|
|*160 |              FILTER                                       |                       |        |            |
|*161 |               INDEX RANGE SCAN                            | DOM_TYPVAL            |      2 |     1   (0)|
|*162 |              FILTER                                       |                       |        |            |
|*163 |               INDEX RANGE SCAN                            | DOM_TYPVAL            |      2 |     1   (0)|
|*164 |              FILTER                                       |                       |        |            |
|*165 |               INDEX RANGE SCAN                            | DOM_TYPVAL            |      2 |     1   (0)|
| 166 |          VIEW                                             | V_TDOMAINE            |     29 |    10   (0)|
| 167 |           UNION-ALL                                       |                       |        |            |
|*168 |            FILTER                                         |                       |        |            |
| 169 |             JOIN FILTER USE                               | :BF0000               |      1 |     1   (0)|
| 170 |              TABLE ACCESS BY INDEX ROWID BATCHED          | V_DOMAINE             |      1 |     1   (0)|
|*171 |               INDEX RANGE SCAN                            | DOM_CHAMP             |      1 |     1   (0)|
|*172 |            FILTER                                         |                       |        |            |
| 173 |             JOIN FILTER USE                               | :BF0000               |     20 |     1   (0)|
| 174 |              TABLE ACCESS BY INDEX ROWID BATCHED          | V_DOMAINE             |     20 |     1   (0)|
|*175 |               INDEX RANGE SCAN                            | DOM_CHAMP             |      9 |     1   (0)|
|*176 |            FILTER                                         |                       |        |            |
| 177 |             JOIN FILTER USE                               | :BF0000               |      1 |     1   (0)|
| 178 |              TABLE ACCESS BY INDEX ROWID BATCHED          | V_DOMAINE             |      1 |     1   (0)|
|*179 |               INDEX RANGE SCAN                            | DOM_CHAMP             |      1 |     1   (0)|
|*180 |            FILTER                                         |                       |        |            |
| 181 |             JOIN FILTER USE                               | :BF0000               |      1 |     1   (0)|
| 182 |              TABLE ACCESS BY INDEX ROWID BATCHED          | V_DOMAINE             |      1 |     1   (0)|
|*183 |               INDEX RANGE SCAN                            | DOM_CHAMP             |      1 |     1   (0)|
|*184 |            FILTER                                         |                       |        |            |
| 185 |             JOIN FILTER USE                               | :BF0000               |      1 |     1   (0)|
| 186 |              TABLE ACCESS BY INDEX ROWID BATCHED          | V_DOMAINE             |      1 |     1   (0)|
|*187 |               INDEX RANGE SCAN                            | DOM_CHAMP             |      1 |     1   (0)|
|*188 |            FILTER                                         |                       |        |            |
| 189 |             JOIN FILTER USE                               | :BF0000               |      1 |     1   (0)|
| 190 |              TABLE ACCESS BY INDEX ROWID BATCHED          | V_DOMAINE             |      1 |     1   (0)|
|*191 |               INDEX RANGE SCAN                            | DOM_CHAMP             |      1 |     1   (0)|
|*192 |            FILTER                                         |                       |        |            |
| 193 |             JOIN FILTER USE                               | :BF0000               |      1 |     1   (0)|
| 194 |              TABLE ACCESS BY INDEX ROWID BATCHED          | V_DOMAINE             |      1 |     1   (0)|
|*195 |               INDEX RANGE SCAN                            | DOM_CHAMP             |      1 |     1   (0)|
|*196 |            FILTER                                         |                       |        |            |
| 197 |             JOIN FILTER USE                               | :BF0000               |      1 |     1   (0)|
| 198 |              TABLE ACCESS BY INDEX ROWID BATCHED          | V_DOMAINE             |      1 |     1   (0)|
|*199 |               INDEX RANGE SCAN                            | DOM_CHAMP             |      1 |     1   (0)|
|*200 |            FILTER                                         |                       |        |            |
| 201 |             JOIN FILTER USE                               | :BF0000               |      1 |     1   (0)|
| 202 |              TABLE ACCESS BY INDEX ROWID BATCHED          | V_DOMAINE             |      1 |     1   (0)|
|*203 |               INDEX RANGE SCAN                            | DOM_CHAMP             |      1 |     1   (0)|
|*204 |            FILTER                                         |                       |        |            |
| 205 |             JOIN FILTER USE                               | :BF0000               |      1 |     1   (0)|
| 206 |              TABLE ACCESS BY INDEX ROWID BATCHED          | V_DOMAINE             |      1 |     1   (0)|
|*207 |               INDEX RANGE SCAN                            | DOM_CHAMP             |      1 |     1   (0)|
| 208 |         TABLE ACCESS BY INDEX ROWID                       | G_DOSSIER             |      1 |     1   (0)|
|*209 |          INDEX UNIQUE SCAN                                | DOS_REFDOSS           |      1 |     1   (0)|
| 210 |         TABLE ACCESS BY INDEX ROWID                       | G_DOSSIER             |      1 |     1   (0)|
|*211 |          INDEX UNIQUE SCAN                                | DOS_REFDOSS           |      1 |     1   (0)|
-----------------------------------------------------------------------------------------------------------------

Peeked Binds (identified by position):
--------------------------------------

   1 - :1 (NUMBER): 403
   6 - :6 (NUMBER): 403
   7 - :7 (VARCHAR2(30), CSID=871): '215790169'
   8 - :8 (NUMBER): 11

Predicate Information (identified by operation id):
---------------------------------------------------
   1 - filter(ROWNUM=1)
   2 - filter("DTFIN_DT" IS NULL)
   3 - access("REFDOSS"=:B1)
   4 - filter(ROWNUM=1)
   7 - filter("AUTH"."VALEUR_2" IS NOT NULL)
   8 - access("AUTH"."TYPE"='EXTR_GEST_CLIENT' AND "AUTH"."ABREV"=TO_CHAR(:1))
   9 - access("TI"."REFDOSS"=:B1 AND "TI"."REFTYPE"="AUTH"."VALEUR_2" AND
              "TI"."REFINDIVIDU"="AUTH"."VALEUR")
  10 - filter("TI"."REFDOSSEXT" IS NOT NULL)
  12 - access("IMX_UN_ID"=)
  17 - filter(("DECOMPTE"."REFDOSS"=:B1 AND "DECOMPTE"."CATEGDOSS" LIKE 'DECOMPTE%'))
  18 - filter("DECOMPTE"."REFLOT" IS NOT NULL)
  20 - access("DECOMPTE"."REFLOT"="CONTR"."REFDOSS")
  21 - access("REFINDIVIDU"=:B1)
  22 - filter(("REFEXT3" IS NOT NULL AND "REFEXT3"="CONTR"."ANCREFDOSS" AND "REFEXT2"=:B1 AND
              "SOCIETE"='CLIENT_NUMBER'))
  24 - access("VALEUR"= AND "TYPE"='typencour')
  27 - access("TA"."REFENTITE"=:B1)
  28 - filter(ROWNUM=1)
  29 - access("SR"."REFDOSS"=:B1)
       filter(("SR"."REFTYPE"<>'DB' AND "SR"."REFTYPE"<>'CL' AND "SR"."REFTYPE"<>'XX'))
  30 - filter(ROWNUM=1)
  32 - filter("G"."CATEGDOSS" LIKE 'COLLECTION%')
  33 - access("G"."REFDOSS"=:B1)
  35 - access("PIECE"."REFDOSS"=:B1 AND "PIECE"."TYPPIECE"='DBT_VERIF_REQ')
  36 - filter("RECORD_NO">=:9)
  37 - filter(ROWNUM<=:8)
  39 - filter(ROWNUM<=:8)
  42 - filter((DECODE("D"."REFHIERARCHIE",NULL,'N',)='N' AND DECODE("D"."REFHIERARCHIE2",NULL,'N',)='N'))
  43 - access("VD_PIECEINIT"."VALEUR"="D"."PIECEINIT")
  58 - filter("AUTH"."VALEUR_2" IS NOT NULL)
  59 - access("AUTH"."TYPE"='EXTR_GEST_CLIENT' AND "AUTH"."ABREV"=TO_CHAR(:6))
  60 - access("T_INT"."REFINDIVIDU"="AUTH"."VALEUR" AND "T_INT"."REFTYPE"="AUTH"."VALEUR_2")
  61 - filter(("D"."ANCREFDOSS"=UPPER(:7) AND "D"."CATEGDOSS"<>'COMPTE DB CTR' AND
              NVL("D"."FG_EXCL_FROM_EXTR",'N')<>'O' AND NVL("FG_FRM_INC",'N')<>'O'))
  62 - access("D"."REFDOSS"="T_INT"."REFDOSS")
       filter("D"."REFDOSS" NOT LIKE 'GL%')
  63 - access("LST"."REFDOSS"="D"."REFDOSS")
  68 - access("P"."REFDOSS"="D"."REFHIERARCHIE" AND "P"."TYPPIECE"='CONTRAT')
  69 - access("PD"."REFPIECE"="P"."REFPIECE" AND "PD"."TYPE"='CI CONTRACTS')
  70 - filter("PD"."FG01"='O')
  71 - filter(("ECRAN"='X' OR  IS NOT NULL))
  72 - access("D"."CATEGDOSS"="VALEUR" AND "TYPE"='categdoss')
       filter("VALEUR"<>'COMPTE DB CTR')
  73 - filter(("ACTIVITE_GPC"='G' OR "ACTIVITE_GPC"='T'))
  74 - access("D"."REFDOSS"="T"."REFDOSS" AND "T"."REFTYPE"='DB')
  75 - access("D"."REFDOSS"="CLIENT"."REFDOSS")
       filter(("CLIENT"."REFTYPE"='CL' OR "CLIENT"."REFTYPE"='TC'))
  77 - access("T"."REFINDIVIDU"="I"."REFINDIVIDU")
  78 - access("ICL"."REFINDIVIDU"="CLIENT"."REFINDIVIDU")
  79 - access("PIECECASE"."REFDOSS"="D"."REFDOSS" AND "PIECECASE"."TYPPIECE"="D"."PIECEINIT")
  80 - filter("VD_DIV"."ECRAN"="I"."PAYS")
  82 - filter('AN'=:3)
  84 - access("TYPE"='DIVISION TERRITORIALE' AND "ABREV"="I"."DIVISION")
  85 - filter('CS'=:3)
  87 - access("TYPE"='DIVISION TERRITORIALE' AND "ABREV"="I"."DIVISION")
  88 - filter('FR'=:3)
  90 - access("TYPE"='DIVISION TERRITORIALE' AND "ABREV"="I"."DIVISION")
  91 - filter('HU'=:3)
  93 - access("TYPE"='DIVISION TERRITORIALE' AND "ABREV"="I"."DIVISION")
  94 - filter('NL'=:3)
  96 - access("TYPE"='DIVISION TERRITORIALE' AND "ABREV"="I"."DIVISION")
  97 - filter('PL'=:3)
  99 - access("TYPE"='DIVISION TERRITORIALE' AND "ABREV"="I"."DIVISION")
100 - filter('RU'=:3)
102 - access("TYPE"='DIVISION TERRITORIALE' AND "ABREV"="I"."DIVISION")
103 - filter('SK'=:3)
105 - access("TYPE"='DIVISION TERRITORIALE' AND "ABREV"="I"."DIVISION")
106 - filter('VI'=:3)
108 - access("TYPE"='DIVISION TERRITORIALE' AND "ABREV"="I"."DIVISION")
109 - filter('ZH'=:3)
111 - access("TYPE"='DIVISION TERRITORIALE' AND "ABREV"="I"."DIVISION")
114 - filter('AN'=:2)
116 - access("TYPE"='pays' AND "ABREV"="I"."PAYS")
117 - filter('CS'=:2)
119 - access("TYPE"='pays' AND "ABREV"="I"."PAYS")
120 - filter('FR'=:2)
122 - access("TYPE"='pays' AND "ABREV"="I"."PAYS")
123 - filter('HU'=:2)
125 - access("TYPE"='pays' AND "ABREV"="I"."PAYS")
126 - filter('NL'=:2)
128 - access("TYPE"='pays' AND "ABREV"="I"."PAYS")
129 - filter('PL'=:2)
131 - access("TYPE"='pays' AND "ABREV"="I"."PAYS")
132 - filter('RU'=:2)
134 - access("TYPE"='pays' AND "ABREV"="I"."PAYS")
135 - filter('SK'=:2)
137 - access("TYPE"='pays' AND "ABREV"="I"."PAYS")
138 - filter('VI'=:2)
140 - access("TYPE"='pays' AND "ABREV"="I"."PAYS")
141 - filter('ZH'=:2)
143 - access("TYPE"='pays' AND "ABREV"="I"."PAYS")
146 - filter(("D"."CATEGDOSS"<>'COMPTE DB CTR' AND 'AN'=:4))
147 - access("VALEUR"="D"."CATEGDOSS")
       filter("VALEUR"<>'COMPTE DB CTR')
148 - filter(("D"."CATEGDOSS"<>'COMPTE DB CTR' AND 'CS'=:4))
149 - access("VALEUR"="D"."CATEGDOSS")
       filter("VALEUR"<>'COMPTE DB CTR')
150 - filter(("D"."CATEGDOSS"<>'COMPTE DB CTR' AND 'FR'=:4))
151 - access("VALEUR"="D"."CATEGDOSS")
       filter("VALEUR"<>'COMPTE DB CTR')
152 - filter(("D"."CATEGDOSS"<>'COMPTE DB CTR' AND 'HU'=:4))
153 - access("VALEUR"="D"."CATEGDOSS")
       filter("VALEUR"<>'COMPTE DB CTR')
154 - filter(("D"."CATEGDOSS"<>'COMPTE DB CTR' AND 'NL'=:4))
155 - access("VALEUR"="D"."CATEGDOSS")
       filter("VALEUR"<>'COMPTE DB CTR')
156 - filter(("D"."CATEGDOSS"<>'COMPTE DB CTR' AND 'PL'=:4))
157 - access("VALEUR"="D"."CATEGDOSS")
       filter("VALEUR"<>'COMPTE DB CTR')
158 - filter(("D"."CATEGDOSS"<>'COMPTE DB CTR' AND 'RU'=:4))
159 - access("VALEUR"="D"."CATEGDOSS")
       filter("VALEUR"<>'COMPTE DB CTR')
160 - filter(("D"."CATEGDOSS"<>'COMPTE DB CTR' AND 'SK'=:4))
161 - access("VALEUR"="D"."CATEGDOSS")
       filter("VALEUR"<>'COMPTE DB CTR')
162 - filter(("D"."CATEGDOSS"<>'COMPTE DB CTR' AND 'VI'=:4))
163 - access("VALEUR"="D"."CATEGDOSS")
       filter("VALEUR"<>'COMPTE DB CTR')
164 - filter(("D"."CATEGDOSS"<>'COMPTE DB CTR' AND 'ZH'=:4))
165 - access("VALEUR"="D"."CATEGDOSS")
       filter("VALEUR"<>'COMPTE DB CTR')
168 - filter('AN'=:5)
171 - access("CHAMP"='pieceinit')
172 - filter('CS'=:5)
175 - access("CHAMP"='pieceinit')
176 - filter('FR'=:5)
179 - access("CHAMP"='pieceinit')
180 - filter('HU'=:5)
183 - access("CHAMP"='pieceinit')
184 - filter('NL'=:5)
187 - access("CHAMP"='pieceinit')
188 - filter('PL'=:5)
191 - access("CHAMP"='pieceinit')
192 - filter('RU'=:5)
195 - access("CHAMP"='pieceinit')
196 - filter('SK'=:5)
199 - access("CHAMP"='pieceinit')
200 - filter('VI'=:5)
203 - access("CHAMP"='pieceinit')
204 - filter('ZH'=:5)
207 - access("CHAMP"='pieceinit')
209 - access("REFDOSS"=:B1)
211 - access("REFDOSS"=:B1)



-- 5531653ds9d4k

Plan hash value: 1705484302
-----------------------------------------------------------------------------------------------------------------
| Id  | Operation                                               | Name                    | E-Rows | Cost (%CPU)|
-----------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                                        |                         |        |  9617 (100)|
|*  1 |  COUNT STOPKEY                                          |                         |        |            |
|*  2 |   TABLE ACCESS BY INDEX ROWID BATCHED                   | T_FILIERE               |      1 |     1   (0)|
|*  3 |    INDEX RANGE SCAN                                     | T_FIL_DTFINDEB          |      7 |     1   (0)|
|*  4 |  COUNT STOPKEY                                          |                         |        |            |
|   5 |   NESTED LOOPS                                          |                         |      1 |     2   (0)|
|   6 |    NESTED LOOPS                                         |                         |      1 |     2   (0)|
|*  7 |     TABLE ACCESS BY INDEX ROWID BATCHED                 | V_EXTR_DOM              |      1 |     1   (0)|
|*  8 |      INDEX RANGE SCAN                                   | TYPEABREV               |      2 |     1   (0)|
|*  9 |     INDEX RANGE SCAN                                    | INT_REFDOSS             |      1 |     1   (0)|
|* 10 |    TABLE ACCESS BY INDEX ROWID                          | T_INTERVENANTS          |      1 |     1   (0)|
|  11 |  TABLE ACCESS BY INDEX ROWID                            | T_INDIVIDU              |      1 |     1   (0)|
|* 12 |   INDEX UNIQUE SCAN                                     | PK_T_INDIVIDU           |      1 |     1   (0)|
|  13 |    SORT AGGREGATE                                       |                         |      1 |            |
|  14 |     NESTED LOOPS                                        |                         |      1 |     3   (0)|
|  15 |      NESTED LOOPS                                       |                         |      2 |     3   (0)|
|  16 |       NESTED LOOPS                                      |                         |      1 |     2   (0)|
|* 17 |        TABLE ACCESS BY INDEX ROWID BATCHED              | G_DOSSIER               |      1 |     1   (0)|
|* 18 |         INDEX FULL SCAN                                 | DOSS_LOT                |      1 |     1   (0)|
|  19 |        TABLE ACCESS BY INDEX ROWID                      | G_DOSSIER               |      1 |     1   (0)|
|* 20 |         INDEX UNIQUE SCAN                               | DOS_REFDOSS             |      1 |     1   (0)|
|* 21 |       INDEX RANGE SCAN                                  | IX_T_INDIVIDU           |      2 |     1   (0)|
|* 22 |      TABLE ACCESS BY INDEX ROWID                        | T_INDIVIDU              |      1 |     1   (0)|
|  23 |  TABLE ACCESS BY INDEX ROWID BATCHED                    | V_DOMAINE               |      1 |     1   (0)|
|* 24 |   INDEX RANGE SCAN                                      | DOM_TYPVAL              |      3 |     1   (0)|
|  25 |    SORT AGGREGATE                                       |                         |      1 |            |
|  26 |     TABLE ACCESS BY INDEX ROWID BATCHED                 | T_ATTENTE               |      1 |     1   (0)|
|* 27 |      INDEX RANGE SCAN                                   | PK_ATTENTE              |      1 |     1   (0)|
|* 28 |  COUNT STOPKEY                                          |                         |        |            |
|* 29 |   INDEX RANGE SCAN                                      | INT_REFDOSS             |      3 |     1   (0)|
|* 30 |  COUNT STOPKEY                                          |                         |        |            |
|  31 |   NESTED LOOPS                                          |                         |      1 |     2   (0)|
|* 32 |    TABLE ACCESS BY INDEX ROWID                          | G_DOSSIER               |      1 |     1   (0)|
|* 33 |     INDEX UNIQUE SCAN                                   | DOS_REFDOSS             |      1 |     1   (0)|
|  34 |    TABLE ACCESS BY INDEX ROWID BATCHED                  | G_PIECE                 |      1 |     1   (0)|
|* 35 |     INDEX RANGE SCAN                                    | PIE_REFDOSS             |      1 |     1   (0)|
|* 36 |  VIEW                                                   |                         |      1 |  9617   (1)|
|* 37 |   COUNT STOPKEY                                         |                         |        |            |
|  38 |    VIEW                                                 |                         |      1 |  9617   (1)|
|* 39 |     SORT UNIQUE STOPKEY                                 |                         |      1 |  9616   (1)|
|  40 |      WINDOW SORT                                        |                         |      1 |  9617   (1)|
|* 41 |       FILTER                                            |                         |        |            |
|* 42 |        HASH JOIN OUTER                                  |                         |      1 |  9604   (1)|
|* 43 |         HASH JOIN OUTER                                 |                         |      1 |  9594   (1)|
|  44 |          NESTED LOOPS                                   |                         |      1 |  9584   (1)|
|  45 |           NESTED LOOPS                                  |                         |      1 |  9583   (1)|
|  46 |            NESTED LOOPS                                 |                         |      1 |  9582   (1)|
|  47 |             NESTED LOOPS                                |                         |      1 |  9581   (1)|
|  48 |              NESTED LOOPS                               |                         |      1 |  9580   (1)|
|* 49 |               HASH JOIN                                 |                         |      1 |  9579   (1)|
|* 50 |                HASH JOIN                                |                         |      1 |  9552   (1)|
|  51 |                 VIEW                                    | V_TDOMAINE              |     10 |    10   (0)|
|  52 |                  UNION-ALL                              |                         |        |            |
|* 53 |                   FILTER                                |                         |        |            |
|  54 |                    TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE               |      1 |     1   (0)|
|* 55 |                     INDEX RANGE SCAN                    | DOM_CHAMP               |      1 |     1   (0)|
|* 56 |                   FILTER                                |                         |        |            |
|  57 |                    TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE               |      1 |     1   (0)|
|* 58 |                     INDEX RANGE SCAN                    | DOM_CHAMP               |      1 |     1   (0)|
|* 59 |                   FILTER                                |                         |        |            |
|  60 |                    TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE               |      1 |     1   (0)|
|* 61 |                     INDEX RANGE SCAN                    | DOM_CHAMP               |      1 |     1   (0)|
|* 62 |                   FILTER                                |                         |        |            |
|  63 |                    TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE               |      1 |     1   (0)|
|* 64 |                     INDEX RANGE SCAN                    | DOM_CHAMP               |      1 |     1   (0)|
|* 65 |                   FILTER                                |                         |        |            |
|  66 |                    TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE               |      1 |     1   (0)|
|* 67 |                     INDEX RANGE SCAN                    | DOM_CHAMP               |      1 |     1   (0)|
|* 68 |                   FILTER                                |                         |        |            |
|  69 |                    TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE               |      1 |     1   (0)|
|* 70 |                     INDEX RANGE SCAN                    | DOM_CHAMP               |      1 |     1   (0)|
|* 71 |                   FILTER                                |                         |        |            |
|  72 |                    TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE               |      1 |     1   (0)|
|* 73 |                     INDEX RANGE SCAN                    | DOM_CHAMP               |      1 |     1   (0)|
|* 74 |                   FILTER                                |                         |        |            |
|  75 |                    TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE               |      1 |     1   (0)|
|* 76 |                     INDEX RANGE SCAN                    | DOM_CHAMP               |      1 |     1   (0)|
|* 77 |                   FILTER                                |                         |        |            |
|  78 |                    TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE               |      1 |     1   (0)|
|* 79 |                     INDEX RANGE SCAN                    | DOM_CHAMP               |      1 |     1   (0)|
|* 80 |                   FILTER                                |                         |        |            |
|  81 |                    TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE               |      1 |     1   (0)|
|* 82 |                     INDEX RANGE SCAN                    | DOM_CHAMP               |      1 |     1   (0)|
|* 83 |                 HASH JOIN                               |                         |    115K|  9541   (1)|
|* 84 |                  TABLE ACCESS BY INDEX ROWID BATCHED    | V_DOMAINE               |      4 |     1   (0)|
|* 85 |                   INDEX RANGE SCAN                      | V_DOMAINE_TYPE_CODE_IDX |    100 |     1   (0)|
|* 86 |                   TABLE ACCESS FULL                     | G_ETUDE                 |      1 |     2   (0)|
|* 87 |                  HASH JOIN RIGHT OUTER                  |                         |    321K|  9538   (1)|
|  88 |                   VIEW                                  |                         |      1 |     2   (0)|
|  89 |                    NESTED LOOPS                         |                         |      1 |     2   (0)|
|  90 |                     NESTED LOOPS                        |                         |      1 |     2   (0)|
|  91 |                      TABLE ACCESS BY INDEX ROWID BATCHED| G_PIECE                 |      1 |     1   (0)|
|* 92 |                       INDEX RANGE SCAN                  | PIECE_TYP_MT43_IDX      |      1 |     1   (0)|
|* 93 |                      INDEX RANGE SCAN                   | G_PIECEDET_REFP         |      1 |     1   (0)|
|* 94 |                     TABLE ACCESS BY INDEX ROWID         | G_PIECEDET              |      1 |     1   (0)|
|  95 |                   NESTED LOOPS OUTER                    |                         |    321K|  9533   (1)|
|  96 |                    NESTED LOOPS                         |                         |    321K|  9532   (1)|
|* 97 |                     HASH JOIN                           |                         |    321K|  3099   (1)|
|  98 |                      TABLE ACCESS BY INDEX ROWID BATCHED| G_INDIVIDU              |    305K|   458   (1)|
|* 99 |                       INDEX RANGE SCAN                  | NUMSS_IDX               |  45787 |     2   (0)|
|*100 |                      INDEX SKIP SCAN                    | INT_REFDOSS             |    607K|  1697   (1)|
|*101 |                     TABLE ACCESS BY INDEX ROWID         | G_DOSSIER               |      1 |     1   (0)|
|*102 |                      INDEX UNIQUE SCAN                  | DOS_REFDOSS             |      1 |     1   (0)|
|*103 |                    INDEX RANGE SCAN                     | LST_SCORE_REFDOSS_IDX   |      1 |     1   (0)|
| 104 |                VIEW                                     | V_TDOMAINE              |    326K|    24   (0)|
| 105 |                 UNION-ALL                               |                         |        |            |
|*106 |                  FILTER                                 |                         |        |            |
|*107 |                   INDEX FULL SCAN                       | DOM_TYPVAL              |  32696 |     2   (0)|
|*108 |                  FILTER                                 |                         |        |            |
|*109 |                   INDEX FULL SCAN                       | DOM_TYPVAL              |  32696 |     2   (0)|
|*110 |                  FILTER                                 |                         |        |            |
|*111 |                   INDEX FULL SCAN                       | DOM_TYPVAL              |  32696 |     2   (0)|
|*112 |                  FILTER                                 |                         |        |            |
|*113 |                   INDEX FULL SCAN                       | DOM_TYPVAL              |  32696 |     2   (0)|
|*114 |                  FILTER                                 |                         |        |            |
|*115 |                   INDEX FULL SCAN                       | DOM_TYPVAL              |  32696 |     2   (0)|
|*116 |                  FILTER                                 |                         |        |            |
|*117 |                   INDEX FULL SCAN                       | DOM_TYPVAL              |  32696 |     2   (0)|
|*118 |                  FILTER                                 |                         |        |            |
|*119 |                   INDEX FULL SCAN                       | DOM_TYPVAL              |  32696 |     2   (0)|
|*120 |                  FILTER                                 |                         |        |            |
|*121 |                   INDEX FULL SCAN                       | DOM_TYPVAL              |  32696 |     2   (0)|
|*122 |                  FILTER                                 |                         |        |            |
|*123 |                   INDEX FULL SCAN                       | DOM_TYPVAL              |  32696 |     2   (0)|
|*124 |                  FILTER                                 |                         |        |            |
|*125 |                   INDEX FULL SCAN                       | DOM_TYPVAL              |  32696 |     2   (0)|
|*126 |               INDEX RANGE SCAN                          | INT_REFDOSS             |      1 |     1   (0)|
|*127 |              INDEX UNIQUE SCAN                          | IND_REFINDIV            |      1 |     1   (0)|
|*128 |             INDEX RANGE SCAN                            | PIE_REFDOSS             |      1 |     1   (0)|
|*129 |            INDEX RANGE SCAN                             | INT_REFDOSS             |      3 |     1   (0)|
|*130 |           TABLE ACCESS BY INDEX ROWID BATCHED           | V_EXTR_DOM              |        |            |
|*131 |            INDEX RANGE SCAN                             | TYPEABREV               |      2 |     1   (0)|
| 132 |          VIEW                                           | V_TDOMAINE              |   1000 |    10   (0)|
| 133 |           UNION-ALL                                     |                         |        |            |
|*134 |            FILTER                                       |                         |        |            |
| 135 |             TABLE ACCESS BY INDEX ROWID BATCHED         | V_DOMAINE               |    100 |     1   (0)|
|*136 |              INDEX RANGE SCAN                           | V_DOMAINE_TYPE_CODE_IDX |    100 |     1   (0)|
|*137 |            FILTER                                       |                         |        |            |
| 138 |             TABLE ACCESS BY INDEX ROWID BATCHED         | V_DOMAINE               |    100 |     1   (0)|
|*139 |              INDEX RANGE SCAN                           | V_DOMAINE_TYPE_CODE_IDX |    100 |     1   (0)|
|*140 |            FILTER                                       |                         |        |            |
| 141 |             TABLE ACCESS BY INDEX ROWID BATCHED         | V_DOMAINE               |    100 |     1   (0)|
|*142 |              INDEX RANGE SCAN                           | V_DOMAINE_TYPE_CODE_IDX |    100 |     1   (0)|
|*143 |            FILTER                                       |                         |        |            |
| 144 |             TABLE ACCESS BY INDEX ROWID BATCHED         | V_DOMAINE               |    100 |     1   (0)|
|*145 |              INDEX RANGE SCAN                           | V_DOMAINE_TYPE_CODE_IDX |    100 |     1   (0)|
|*146 |            FILTER                                       |                         |        |            |
| 147 |             TABLE ACCESS BY INDEX ROWID BATCHED         | V_DOMAINE               |    100 |     1   (0)|
|*148 |              INDEX RANGE SCAN                           | V_DOMAINE_TYPE_CODE_IDX |    100 |     1   (0)|
|*149 |            FILTER                                       |                         |        |            |
| 150 |             TABLE ACCESS BY INDEX ROWID BATCHED         | V_DOMAINE               |    100 |     1   (0)|
|*151 |              INDEX RANGE SCAN                           | V_DOMAINE_TYPE_CODE_IDX |    100 |     1   (0)|
|*152 |            FILTER                                       |                         |        |            |
| 153 |             TABLE ACCESS BY INDEX ROWID BATCHED         | V_DOMAINE               |    100 |     1   (0)|
|*154 |              INDEX RANGE SCAN                           | V_DOMAINE_TYPE_CODE_IDX |    100 |     1   (0)|
|*155 |            FILTER                                       |                         |        |            |
| 156 |             TABLE ACCESS BY INDEX ROWID BATCHED         | V_DOMAINE               |    100 |     1   (0)|
|*157 |              INDEX RANGE SCAN                           | V_DOMAINE_TYPE_CODE_IDX |    100 |     1   (0)|
|*158 |            FILTER                                       |                         |        |            |
| 159 |             TABLE ACCESS BY INDEX ROWID BATCHED         | V_DOMAINE               |    100 |     1   (0)|
|*160 |              INDEX RANGE SCAN                           | V_DOMAINE_TYPE_CODE_IDX |    100 |     1   (0)|
|*161 |            FILTER                                       |                         |        |            |
| 162 |             TABLE ACCESS BY INDEX ROWID BATCHED         | V_DOMAINE               |    100 |     1   (0)|
|*163 |              INDEX RANGE SCAN                           | V_DOMAINE_TYPE_CODE_IDX |    100 |     1   (0)|
| 164 |         VIEW                                            | V_TDOMAINE              |   1000 |    10   (0)|
| 165 |          UNION-ALL                                      |                         |        |            |
|*166 |           FILTER                                        |                         |        |            |
| 167 |            TABLE ACCESS BY INDEX ROWID BATCHED          | V_DOMAINE               |    100 |     1   (0)|
|*168 |             INDEX RANGE SCAN                            | V_DOMAINE_TYPE_CODE_IDX |    100 |     1   (0)|
|*169 |           FILTER                                        |                         |        |            |
| 170 |            TABLE ACCESS BY INDEX ROWID BATCHED          | V_DOMAINE               |    100 |     1   (0)|
|*171 |             INDEX RANGE SCAN                            | V_DOMAINE_TYPE_CODE_IDX |    100 |     1   (0)|
|*172 |           FILTER                                        |                         |        |            |
| 173 |            TABLE ACCESS BY INDEX ROWID BATCHED          | V_DOMAINE               |    100 |     1   (0)|
|*174 |             INDEX RANGE SCAN                            | V_DOMAINE_TYPE_CODE_IDX |    100 |     1   (0)|
|*175 |           FILTER                                        |                         |        |            |
| 176 |            TABLE ACCESS BY INDEX ROWID BATCHED          | V_DOMAINE               |    100 |     1   (0)|
|*177 |             INDEX RANGE SCAN                            | V_DOMAINE_TYPE_CODE_IDX |    100 |     1   (0)|
|*178 |           FILTER                                        |                         |        |            |
| 179 |            TABLE ACCESS BY INDEX ROWID BATCHED          | V_DOMAINE               |    100 |     1   (0)|
|*180 |             INDEX RANGE SCAN                            | V_DOMAINE_TYPE_CODE_IDX |    100 |     1   (0)|
|*181 |           FILTER                                        |                         |        |            |
| 182 |            TABLE ACCESS BY INDEX ROWID BATCHED          | V_DOMAINE               |    100 |     1   (0)|
|*183 |             INDEX RANGE SCAN                            | V_DOMAINE_TYPE_CODE_IDX |    100 |     1   (0)|
|*184 |           FILTER                                        |                         |        |            |
| 185 |            TABLE ACCESS BY INDEX ROWID BATCHED          | V_DOMAINE               |    100 |     1   (0)|
|*186 |             INDEX RANGE SCAN                            | V_DOMAINE_TYPE_CODE_IDX |    100 |     1   (0)|
|*187 |           FILTER                                        |                         |        |            |
| 188 |            TABLE ACCESS BY INDEX ROWID BATCHED          | V_DOMAINE               |    100 |     1   (0)|
|*189 |             INDEX RANGE SCAN                            | V_DOMAINE_TYPE_CODE_IDX |    100 |     1   (0)|
|*190 |           FILTER                                        |                         |        |            |
| 191 |            TABLE ACCESS BY INDEX ROWID BATCHED          | V_DOMAINE               |    100 |     1   (0)|
|*192 |             INDEX RANGE SCAN                            | V_DOMAINE_TYPE_CODE_IDX |    100 |     1   (0)|
|*193 |           FILTER                                        |                         |        |            |
| 194 |            TABLE ACCESS BY INDEX ROWID BATCHED          | V_DOMAINE               |    100 |     1   (0)|
|*195 |             INDEX RANGE SCAN                            | V_DOMAINE_TYPE_CODE_IDX |    100 |     1   (0)|
| 196 |        TABLE ACCESS BY INDEX ROWID                      | G_DOSSIER               |      1 |     1   (0)|
|*197 |         INDEX UNIQUE SCAN                               | DOS_REFDOSS             |      1 |     1   (0)|
| 198 |        TABLE ACCESS BY INDEX ROWID                      | G_DOSSIER               |      1 |     1   (0)|
|*199 |         INDEX UNIQUE SCAN                               | DOS_REFDOSS             |      1 |     1   (0)|
-----------------------------------------------------------------------------------------------------------------

Peeked Binds (identified by position):
--------------------------------------

   1 - :1 (NUMBER): 403
   6 - :6 (NUMBER): 403
   7 - :7 (VARCHAR2(30), CSID=871): '8559260798'
   8 - :8 (NUMBER): 11

Predicate Information (identified by operation id):
---------------------------------------------------
   1 - filter(ROWNUM=1)
   2 - filter("DTFIN_DT" IS NULL)
   3 - access("REFDOSS"=:B1)
   4 - filter(ROWNUM=1)
   7 - filter("AUTH"."VALEUR_2" IS NOT NULL)
   8 - access("AUTH"."TYPE"='EXTR_GEST_CLIENT' AND "AUTH"."ABREV"=TO_CHAR(:1))
   9 - access("TI"."REFDOSS"=:B1 AND "TI"."REFTYPE"="AUTH"."VALEUR_2" AND
              "TI"."REFINDIVIDU"="AUTH"."VALEUR")
  10 - filter("TI"."REFDOSSEXT" IS NOT NULL)
  12 - access("IMX_UN_ID"=)
  17 - filter(("DECOMPTE"."REFDOSS"=:B1 AND "DECOMPTE"."CATEGDOSS" LIKE 'DECOMPTE%'))
  18 - filter("DECOMPTE"."REFLOT" IS NOT NULL)
  20 - access("DECOMPTE"."REFLOT"="CONTR"."REFDOSS")
  21 - access("REFINDIVIDU"=:B1)
  22 - filter(("REFEXT3" IS NOT NULL AND "REFEXT3"="CONTR"."ANCREFDOSS" AND "REFEXT2"=:B1 AND
              "SOCIETE"='CLIENT_NUMBER'))
  24 - access("VALEUR"= AND "TYPE"='typencour')
  27 - access("TA"."REFENTITE"=:B1)
  28 - filter(ROWNUM=1)
  29 - access("SR"."REFDOSS"=:B1)
       filter(("SR"."REFTYPE"<>'DB' AND "SR"."REFTYPE"<>'CL' AND "SR"."REFTYPE"<>'XX'))
  30 - filter(ROWNUM=1)
  32 - filter("G"."CATEGDOSS" LIKE 'COLLECTION%')
  33 - access("G"."REFDOSS"=:B1)
  35 - access("PIECE"."REFDOSS"=:B1 AND "PIECE"."TYPPIECE"='DBT_VERIF_REQ')
  36 - filter("RECORD_NO">=:9)
  37 - filter(ROWNUM<=:8)
  39 - filter(ROWNUM<=:8)
  41 - filter((DECODE("D"."REFHIERARCHIE",NULL,'N',)='N' AND DECODE("D"."REFHIERARCHIE2",NULL,'N',)='N'))
  42 - access("VD_DIV"."ECRAN"="I"."PAYS" AND "VD_DIV"."ABREV"="I"."DIVISION")
  43 - access("VD"."ABREV"="I"."PAYS")
  49 - access("VD_CATEGDOSS"."VALEUR"="D"."CATEGDOSS")
  50 - access("VD_PIECEINIT"."VALEUR"="D"."PIECEINIT")
  53 - filter('AN'=:5)
  55 - access("CHAMP"='pieceinit')
  56 - filter('CS'=:5)
  58 - access("CHAMP"='pieceinit')
  59 - filter('FR'=:5)
  61 - access("CHAMP"='pieceinit')
  62 - filter('HU'=:5)
  64 - access("CHAMP"='pieceinit')
  65 - filter('NL'=:5)
  67 - access("CHAMP"='pieceinit')
  68 - filter('PL'=:5)
  70 - access("CHAMP"='pieceinit')
  71 - filter('RU'=:5)
  73 - access("CHAMP"='pieceinit')
  74 - filter('SK'=:5)
  76 - access("CHAMP"='pieceinit')
  77 - filter('VI'=:5)
  79 - access("CHAMP"='pieceinit')
  80 - filter('ZH'=:5)
  82 - access("CHAMP"='pieceinit')
  83 - access("D"."CATEGDOSS"="VALEUR")
  84 - filter(("VALEUR"<>'COMPTE DB CTR' AND ("ECRAN"='X' OR  IS NOT NULL)))
  85 - access("TYPE"='categdoss')
  86 - filter(("ACTIVITE_GPC"='G' OR "ACTIVITE_GPC"='T'))
  87 - access("POLICY"."REFDOSS"="D"."REFHIERARCHIE")
  92 - access("P"."TYPPIECE"='CONTRAT')
  93 - access("PD"."REFPIECE"="P"."REFPIECE" AND "PD"."TYPE"='CI CONTRACTS')
  94 - filter("PD"."FG01"='O')
  97 - access("T"."REFINDIVIDU"="I"."REFINDIVIDU")
  99 - access("I"."NUMSS" LIKE UPPER(:7))
       filter("I"."NUMSS" LIKE UPPER(:7))
100 - access("T"."REFTYPE"='DB')
       filter("T"."REFTYPE"='DB')
101 - filter(("D"."CATEGDOSS"<>'COMPTE DB CTR' AND NVL("D"."FG_EXCL_FROM_EXTR",'N')<>'O' AND
              NVL("FG_FRM_INC",'N')<>'O'))
102 - access("D"."REFDOSS"="T"."REFDOSS")
       filter("D"."REFDOSS" NOT LIKE 'GL%')
103 - access("LST"."REFDOSS"="D"."REFDOSS")
106 - filter('AN'=:4)
107 - filter("VALEUR"<>'COMPTE DB CTR')
108 - filter('CS'=:4)
109 - filter("VALEUR"<>'COMPTE DB CTR')
110 - filter('FR'=:4)
111 - filter("VALEUR"<>'COMPTE DB CTR')
112 - filter('HU'=:4)
113 - filter("VALEUR"<>'COMPTE DB CTR')
114 - filter('NL'=:4)
115 - filter("VALEUR"<>'COMPTE DB CTR')
116 - filter('PL'=:4)
117 - filter("VALEUR"<>'COMPTE DB CTR')
118 - filter('RU'=:4)
119 - filter("VALEUR"<>'COMPTE DB CTR')
120 - filter('SK'=:4)
121 - filter("VALEUR"<>'COMPTE DB CTR')
122 - filter('VI'=:4)
123 - filter("VALEUR"<>'COMPTE DB CTR')
124 - filter('ZH'=:4)
125 - filter("VALEUR"<>'COMPTE DB CTR')
126 - access("D"."REFDOSS"="CLIENT"."REFDOSS")
       filter(("CLIENT"."REFTYPE"='CL' OR "CLIENT"."REFTYPE"='TC'))
127 - access("ICL"."REFINDIVIDU"="CLIENT"."REFINDIVIDU")
128 - access("PIECECASE"."REFDOSS"="D"."REFDOSS" AND "PIECECASE"."TYPPIECE"="D"."PIECEINIT")
129 - access("D"."REFDOSS"="T_INT"."REFDOSS")
130 - filter(("T_INT"."REFTYPE"="AUTH"."VALEUR_2" AND "AUTH"."VALEUR_2" IS NOT NULL))
131 - access("AUTH"."TYPE"='EXTR_GEST_CLIENT' AND "AUTH"."ABREV"=TO_CHAR(:6) AND
              "T_INT"."REFINDIVIDU"="AUTH"."VALEUR")
134 - filter('AN'=:2)
136 - access("TYPE"='pays')
137 - filter('CS'=:2)
139 - access("TYPE"='pays')
140 - filter('FR'=:2)
142 - access("TYPE"='pays')
143 - filter('HU'=:2)
145 - access("TYPE"='pays')
146 - filter('NL'=:2)
148 - access("TYPE"='pays')
149 - filter('PL'=:2)
151 - access("TYPE"='pays')
152 - filter('RU'=:2)
154 - access("TYPE"='pays')
155 - filter('SK'=:2)
157 - access("TYPE"='pays')
158 - filter('VI'=:2)
160 - access("TYPE"='pays')
161 - filter('ZH'=:2)
163 - access("TYPE"='pays')
166 - filter('AN'=:3)
168 - access("TYPE"='DIVISION TERRITORIALE')
169 - filter('CS'=:3)
171 - access("TYPE"='DIVISION TERRITORIALE')
172 - filter('FR'=:3)
174 - access("TYPE"='DIVISION TERRITORIALE')
175 - filter('HU'=:3)
177 - access("TYPE"='DIVISION TERRITORIALE')
178 - filter('NL'=:3)
180 - access("TYPE"='DIVISION TERRITORIALE')
181 - filter('PL'=:3)
183 - access("TYPE"='DIVISION TERRITORIALE')
184 - filter('RU'=:3)
186 - access("TYPE"='DIVISION TERRITORIALE')
187 - filter('SK'=:3)
189 - access("TYPE"='DIVISION TERRITORIALE')
190 - filter('VI'=:3)
192 - access("TYPE"='DIVISION TERRITORIALE')
193 - filter('ZH'=:3)
195 - access("TYPE"='DIVISION TERRITORIALE')
197 - access("REFDOSS"=:B1)
199 - access("REFDOSS"=:B1)


*/
/********************************OLD Metrics***************************************/

/********************************New SQL*******************************************/

-- 3x1wr1m52rhzc

VAR B1 NUMBER;
EXEC :B1 := 403;
VAR B2 VARCHAR2(32);
EXEC :B2 := 'AN';
VAR B3 VARCHAR2(32);
EXEC :B3 := '219021092';
VAR B4 NUMBER;
EXEC :B4 := 11;
VAR B5 NUMBER;
EXEC :B5 := 1;

SELECT *
  FROM (SELECT inn.*, ROWNUM record_no
          FROM (SELECT /*+ leading(d t) use_nl(t) opt_param('_optimizer_use_feedback' 'false') */
                       DISTINCT COUNT(DISTINCT d.refdoss) OVER(PARTITION BY 'const') out_of,
                                d.ext_reference_u1 uniqueReference,
                                ( SELECT dtar_dt
                                    FROM t_filiere
                                   WHERE refdoss = D.refdoss
                                     AND dtfin_dt IS NULL
                                     AND ROWNUM = 1 ) acknowledgeDate,
                                d.refdoss id,
                                d.ancrefdoss ancrefdoss,
                                ( select ti.refdossext
                                    from t_intervenants ti, 
                                         v_extr_dom auth
                                   WHERE AUTH.TYPE = 'EXTR_GEST_CLIENT'
                                     AND AUTH.ABREV = TO_CHAR(:B1)
                                     AND ti.REFTYPE = AUTH.VALEUR_2
                                     AND ti.REFINDIVIDU = AUTH.VALEUR
                                     and ti.refdoss = d.refdoss
                                     AND ti.refdossext IS NOT NULL
                                     AND ROWNUM = 1 ) refdossext,
                                ( SELECT refext
                                    FROM t_individu tid
                                   WHERE imx_un_id = ( SELECT max(imx_un_id)
                                           FROM t_individu,
                                                g_dossier  contr,
                                                g_dossier  decompte
                                          WHERE societe = 'CLIENT_NUMBER'
                                            AND refindividu = i.refindividu
                                            AND refext2 = client.refindividu
                                            AND refext3 = contr.ancrefdoss
                                            AND decompte.categdoss LIKE
                                                'DECOMPTE%'
                                            AND decompte.refdoss = d.reflot
                                            AND decompte.reflot = contr.refdoss)) yourNumber,
                                decode(i.moralphy,
                                       'P',
                                       '',
                                       (TRIM(i.nom ||
                                             decode(i.prenom,
                                                    null,
                                                    '',
                                                    ', ' || i.prenom)))) debtorFullName,
                                decode(i.moralphy,
                                       'P',
                                       '',
                                       (decode(i.adr1,
                                               null,
                                               '',
                                               i.adr1 || ', ') ||
                                       decode(i.adr2,
                                               null,
                                               '',
                                               i.adr2 || ', ') ||
                                       decode(i.ville,
                                               null,
                                               '',
                                               i.ville || ', ') ||
                                       decode(i.cp, null, '', i.cp || ', ') ||
                                       decode(NVL(vd_div.valeur_trad,
                                                   vd_div.valeur),
                                               null,
                                               '',
                                               NVL(vd_div.valeur_trad,
                                                   vd_div.valeur) || ', ') ||
                                       nvl(vd.valeur_trad, vd.valeur))) debtorFullAddress,
                                i.cp debtorPC,
                                i.ville debtorCity,
                                policy.str1 policyNumber,
                                i.adr1 debtorAdr1,
                                i.division debtorState,
                                nvl(vd.valeur_trad, vd.valeur) debtorCountry,
                                nvl(d.soldedb_dos, 0) balance,
                                d.dt_dt_dt caseDate,
                                NVL((SELECT DECODE(abrev,
                                                  'CLO',
                                                  'Closed',
                                                  'Active')
                                      FROM v_domaine
                                     where type = 'typencour'
                                       AND valeur =
                                           (SELECT MAX(ta.typencour)
                                              FROM t_attente ta
                                             WHERE ta.refentite = d.refdoss)),
                                    'Active') case_type,
                                d.devise currency,
                                (SELECT 1
                                   FROM t_intervenants sr
                                  WHERE sr.reftype NOT IN ('DB', 'CL', 'XX')
                                    AND rownum = 1
                                    AND sr.refdoss = d.refdoss) thirdPartyInvolved,
                                DECODE((SELECT piece.refpiece
                                         FROM g_dossier g, g_piece piece
                                        WHERE piece.typpiece =
                                              'DBT_VERIF_REQ'
                                          AND piece.refdoss = g.refdoss
                                          AND g.categdoss like 'COLLECTION%'
                                          AND g.refdoss = d.refdoss
                                          and rownum = 1),
                                       null,
                                       'false',
                                       'true') AS isDebtVerif,
                                SUM(nvl(d.soldedb, 0)) over() AS TOTAL_SUM
                  FROM g_dossier d,
                       g_piece pieceCase,
                       t_intervenants t,
                       (select pd.str1 str1, p.refdoss refdoss
                          from g_piece p, g_piecedet pd
                         WHERE p.typpiece = 'CONTRAT'
                           AND pd.type = 'CI CONTRACTS'
                           AND pd.refpiece = p.refpiece
                           AND pd.fg01 = 'O') policy,
                       g_individu i,
                       t_intervenants client,
                       g_individu icl,
                       v_tdomaine vd,
                       t_intervenants t_int,
                       LST_SCORE lst,
                       (SELECT valeur
                          FROM v_domaine
                         WHERE TYPE = 'categdoss'
                           AND (ecran = 'X' OR EXISTS
                                (SELECT 1
                                   FROM g_etude
                                  WHERE activite_gpc IN ('G', 'T')))) vd_cat,
                       v_tdomaine vd_div,
                       v_tdomaine vd_categdoss,
                       v_tdomaine vd_pieceinit,
                       v_extr_dom auth
                 WHERE d.categdoss = vd_cat.valeur
                   AND pieceCase.refdoss = d.refdoss
                   and pieceCase.typpiece = d.pieceinit
                   AND lst.refdoss(+) = d.refdoss
                   AND d.categdoss <> 'COMPTE DB CTR'
                   AND d.refdoss = t.refdoss
                   AND t.reftype = 'DB'
                   AND t.refindividu = i.refindividu
                   AND d.refdoss not like 'GL%'
                   AND d.refdoss = client.refdoss
                   AND client.reftype in ('CL', 'TC')
                   AND icl.refindividu = client.refindividu
                   AND vd.type(+) = 'pays'
                   AND vd.langue(+) = :B2
                   AND vd.abrev(+) = i.pays
                   AND vd_div.TYPE(+) = 'DIVISION TERRITORIALE'
                   AND vd_div.ecran(+) = i.pays
                   AND vd_div.langue(+) = :B2
                   AND vd_div.abrev(+) = i.division
                   AND NVL(d.fg_excl_from_extr, 'N') != 'O'
                   AND decode(d.refhierarchie,
                              null,
                              'N',
                              (SELECT NVL(FG_EXCL_FROM_EXTR, 'N')
                                 from g_dossier
                                where refdoss = d.refhierarchie)) = 'N'
                   AND decode(d.refhierarchie2,
                              null,
                              'N',
                              (SELECT NVL(FG_EXCL_FROM_EXTR, 'N')
                                 from g_dossier
                                where refdoss = d.refhierarchie2)) = 'N'
                   AND NVL(FG_FRM_INC, 'N') != 'O'
                   AND d.refdoss = t_int.refdoss
                   AND vd_categdoss.valeur = d.categdoss
                   AND vd_categdoss.langue = :B2
                   AND vd_pieceinit.valeur = d.pieceinit
                   AND vd_pieceinit.langue = :B2
                   AND vd_pieceinit.champ = 'pieceinit'
                   AND policy.refdoss(+) = d.refhierarchie
                   AND auth.type = 'EXTR_GEST_CLIENT'
                   AND auth.abrev = to_char(:B1)
                   AND t_int.reftype = auth.valeur_2
                   AND t_int.refindividu = auth.valeur
                   AND d.ancrefdoss = UPPER(:B3)
                 ORDER BY id DESC NULLS FIRST) inn
         WHERE 1 = 1
           AND ROWNUM <= :B4)
 WHERE 1 = 1
   AND record_no >= :B5;



-- 5531653ds9d4k

VAR B1 NUMBER;
EXEC :B1 := 403;
VAR B2 VARCHAR2(32);
EXEC :B2 := 'AN';
VAR B3 VARCHAR2(32);
EXEC :B3 := '455228112';
VAR B4 NUMBER;
EXEC :B4 := 11;
VAR B5 NUMBER;
EXEC :B5 := 1;

SELECT *
  FROM (SELECT inn.*, ROWNUM record_no
          FROM (SELECT /*+ leading(i t d t_int) use_nl(t) opt_param('_optimizer_use_feedback' 'false') */
                DISTINCT COUNT(DISTINCT d.refdoss) OVER(PARTITION BY 'const') out_of,
                         d.ext_reference_u1 uniqueReference,
                         (SELECT dtar_dt
                            FROM t_filiere
                           WHERE refdoss = D.refdoss
                             AND dtfin_dt IS NULL
                             AND ROWNUM = 1) acknowledgeDate,
                         d.refdoss id,
                         d.ancrefdoss ancrefdoss,
                         (select ti.refdossext
                            from t_intervenants ti, v_extr_dom auth
                           WHERE AUTH.TYPE = 'EXTR_GEST_CLIENT'
                             AND AUTH.ABREV = TO_CHAR(:B1)
                             AND ti.REFTYPE = AUTH.VALEUR_2
                             AND ti.REFINDIVIDU = AUTH.VALEUR
                             and ti.refdoss = d.refdoss
                             AND ti.refdossext IS NOT NULL
                             AND ROWNUM = 1) refdossext,
                         (SELECT refext
                            FROM t_individu tid
                           WHERE imx_un_id =
                                 (SELECT max(imx_un_id)
                                    FROM t_individu,
                                         g_dossier  contr,
                                         g_dossier  decompte
                                   WHERE societe = 'CLIENT_NUMBER'
                                     AND refindividu = i.refindividu
                                     AND refext2 = client.refindividu
                                     AND refext3 = contr.ancrefdoss
                                     AND decompte.categdoss LIKE 'DECOMPTE%'
                                     AND decompte.refdoss = d.reflot
                                     AND decompte.reflot = contr.refdoss)) yourNumber,
                         decode(i.moralphy,
                                'P',
                                '',
                                (TRIM(i.nom ||
                                      decode(i.prenom,
                                             null,
                                             '',
                                             ', ' || i.prenom)))) debtorFullName,
                         decode(i.moralphy,
                                'P',
                                '',
                                (decode(i.adr1, null, '', i.adr1 || ', ') ||
                                decode(i.adr2, null, '', i.adr2 || ', ') ||
                                decode(i.ville, null, '', i.ville || ', ') ||
                                decode(i.cp, null, '', i.cp || ', ') ||
                                decode(NVL(vd_div.valeur_trad, vd_div.valeur),
                                        null,
                                        '',
                                        NVL(vd_div.valeur_trad, vd_div.valeur) || ', ') ||
                                nvl(vd.valeur_trad, vd.valeur))) debtorFullAddress,
                         i.cp debtorPC,
                         i.ville debtorCity,
                         policy.str1 policyNumber,
                         i.adr1 debtorAdr1,
                         i.division debtorState,
                         nvl(vd.valeur_trad, vd.valeur) debtorCountry,
                         nvl(d.soldedb_dos, 0) balance,
                         d.dt_dt_dt caseDate,
                         NVL((SELECT DECODE(abrev, 'CLO', 'Closed', 'Active')
                               FROM v_domaine
                              where type = 'typencour'
                                AND valeur =
                                    (SELECT MAX(ta.typencour)
                                       FROM t_attente ta
                                      WHERE ta.refentite = d.refdoss)),
                             'Active') case_type,
                         d.devise currency,
                         (SELECT 1
                            FROM t_intervenants sr
                           WHERE sr.reftype NOT IN ('DB', 'CL', 'XX')
                             AND rownum = 1
                             AND sr.refdoss = d.refdoss) thirdPartyInvolved,
                         DECODE((SELECT piece.refpiece
                                  FROM g_dossier g, g_piece piece
                                 WHERE piece.typpiece = 'DBT_VERIF_REQ'
                                   AND piece.refdoss = g.refdoss
                                   AND g.categdoss like 'COLLECTION%'
                                   AND g.refdoss = d.refdoss
                                   and rownum = 1),
                                null,
                                'false',
                                'true') AS isDebtVerif,
                         SUM(nvl(d.soldedb, 0)) over() AS TOTAL_SUM
                  FROM g_dossier d,
                       g_piece pieceCase,
                       t_intervenants t,
                       (select pd.str1 str1, p.refdoss refdoss
                          from g_piece p, g_piecedet pd
                         WHERE p.typpiece = 'CONTRAT'
                           AND pd.type = 'CI CONTRACTS'
                           AND pd.refpiece = p.refpiece
                           AND pd.fg01 = 'O') policy,
                       g_individu i,
                       t_intervenants client,
                       g_individu icl,
                       v_tdomaine vd,
                       t_intervenants t_int,
                       LST_SCORE lst,
                       (SELECT valeur
                          FROM v_domaine
                         WHERE TYPE = 'categdoss'
                           AND (ecran = 'X' OR EXISTS
                                (SELECT 1
                                   FROM g_etude
                                  WHERE activite_gpc IN ('G', 'T')))) vd_cat,
                       v_tdomaine vd_div,
                       v_tdomaine vd_categdoss,
                       v_tdomaine vd_pieceinit,
                       v_extr_dom auth
                 WHERE d.categdoss = vd_cat.valeur
                   AND pieceCase.refdoss = d.refdoss
                   and pieceCase.typpiece = d.pieceinit
                   AND lst.refdoss(+) = d.refdoss
                   AND d.categdoss <> 'COMPTE DB CTR'
                   AND d.refdoss = t.refdoss
                   AND t.reftype = 'DB'
                   AND t.refindividu = i.refindividu
                   AND d.refdoss not like 'GL%'
                   AND d.refdoss = client.refdoss
                   AND client.reftype in ('CL', 'TC')
                   AND icl.refindividu = client.refindividu
                   AND vd.type(+) = 'pays'
                   AND vd.langue(+) = :B2
                   AND vd.abrev(+) = i.pays
                   AND vd_div.TYPE(+) = 'DIVISION TERRITORIALE'
                   AND vd_div.ecran(+) = i.pays
                   AND vd_div.langue(+) = :B2
                   AND vd_div.abrev(+) = i.division
                   AND NVL(d.fg_excl_from_extr, 'N') != 'O'
                   AND decode(d.refhierarchie,
                              null,
                              'N',
                              (SELECT NVL(FG_EXCL_FROM_EXTR, 'N')
                                 from g_dossier
                                where refdoss = d.refhierarchie)) = 'N'
                   AND decode(d.refhierarchie2,
                              null,
                              'N',
                              (SELECT NVL(FG_EXCL_FROM_EXTR, 'N')
                                 from g_dossier
                                where refdoss = d.refhierarchie2)) = 'N'
                   AND NVL(FG_FRM_INC, 'N') != 'O'
                   AND d.refdoss = t_int.refdoss
                   AND vd_categdoss.valeur = d.categdoss
                   AND vd_categdoss.langue = :B2
                   AND vd_pieceinit.valeur = d.pieceinit
                   AND vd_pieceinit.langue = :B2
                   AND vd_pieceinit.champ = 'pieceinit'
                   AND policy.refdoss(+) = d.refhierarchie
                   AND auth.type = 'EXTR_GEST_CLIENT'
                   AND auth.abrev = to_char(:B1)
                   AND t_int.reftype = auth.valeur_2
                   AND t_int.refindividu = auth.valeur
                   AND i.numss LIKE UPPER(:B3)
                 ORDER BY id DESC NULLS FIRST) inn
         WHERE 1 = 1
           AND ROWNUM <= :B4)
 WHERE 1 = 1
   AND record_no >= :B5;
/********************************New SQL*******************************************/
/********************************New Metrics***************************************/
/*
-- 3x1wr1m52rhzc

Plan hash value: 2833679844
------------------------------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                                | Name                  | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  |
------------------------------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                                         |                       |      1 |        |    65 (100)|      1 |00:00:00.10 |     216 |    117 |
|*  1 |  COUNT STOPKEY                                           |                       |      1 |        |            |      1 |00:00:00.09 |     111 |    106 |
|*  2 |   TABLE ACCESS BY INDEX ROWID BATCHED                    | T_FILIERE             |      1 |      1 |     1   (0)|      1 |00:00:00.09 |     111 |    106 |
|*  3 |    INDEX RANGE SCAN                                      | T_FIL_DTFINDEB        |      1 |      7 |     1   (0)|    138 |00:00:00.01 |       5 |      3 |
|*  4 |  COUNT STOPKEY                                           |                       |      1 |        |            |      1 |00:00:00.01 |       8 |      1 |
|   5 |   NESTED LOOPS                                           |                       |      1 |      1 |     2   (0)|      1 |00:00:00.01 |       8 |      1 |
|   6 |    NESTED LOOPS                                          |                       |      1 |      1 |     2   (0)|      1 |00:00:00.01 |       7 |      0 |
|*  7 |     TABLE ACCESS BY INDEX ROWID BATCHED                  | V_EXTR_DOM            |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |      0 |
|*  8 |      INDEX RANGE SCAN                                    | TYPEABREV             |      1 |      2 |     1   (0)|      1 |00:00:00.01 |       2 |      0 |
|*  9 |     INDEX RANGE SCAN                                     | INT_REFDOSS           |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       4 |      0 |
|* 10 |    TABLE ACCESS BY INDEX ROWID                           | T_INTERVENANTS        |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       1 |      1 |
|  11 |  TABLE ACCESS BY INDEX ROWID                             | T_INDIVIDU            |      1 |      1 |     1   (0)|      0 |00:00:00.01 |       1 |      0 |
|* 12 |   INDEX UNIQUE SCAN                                      | PK_T_INDIVIDU         |      1 |      1 |     1   (0)|      0 |00:00:00.01 |       1 |      0 |
|  13 |    SORT AGGREGATE                                        |                       |      1 |      1 |            |      1 |00:00:00.01 |       1 |      0 |
|  14 |     NESTED LOOPS                                         |                       |      1 |      1 |     3   (0)|      0 |00:00:00.01 |       1 |      0 |
|  15 |      NESTED LOOPS                                        |                       |      1 |      2 |     3   (0)|      0 |00:00:00.01 |       1 |      0 |
|  16 |       NESTED LOOPS                                       |                       |      1 |      1 |     2   (0)|      0 |00:00:00.01 |       1 |      0 |
|* 17 |        TABLE ACCESS BY INDEX ROWID BATCHED               | G_DOSSIER             |      1 |      1 |     1   (0)|      0 |00:00:00.01 |       1 |      0 |
|* 18 |         INDEX FULL SCAN                                  | DOSS_LOT              |      1 |      1 |     1   (0)|      0 |00:00:00.01 |       1 |      0 |
|  19 |        TABLE ACCESS BY INDEX ROWID                       | G_DOSSIER             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 20 |         INDEX UNIQUE SCAN                                | DOS_REFDOSS           |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 21 |       INDEX RANGE SCAN                                   | IX_T_INDIVIDU         |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 22 |      TABLE ACCESS BY INDEX ROWID                         | T_INDIVIDU            |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|  23 |  TABLE ACCESS BY INDEX ROWID BATCHED                     | V_DOMAINE             |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       7 |      2 |
|* 24 |   INDEX RANGE SCAN                                       | DOM_TYPVAL            |      1 |      3 |     1   (0)|      1 |00:00:00.01 |       6 |      2 |
|  25 |    SORT AGGREGATE                                        |                       |      1 |      1 |            |      1 |00:00:00.01 |       4 |      2 |
|  26 |     TABLE ACCESS BY INDEX ROWID BATCHED                  | T_ATTENTE             |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       4 |      2 |
|* 27 |      INDEX RANGE SCAN                                    | PK_ATTENTE            |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |      1 |
|* 28 |  COUNT STOPKEY                                           |                       |      1 |        |            |      1 |00:00:00.01 |       4 |      0 |
|* 29 |   INDEX RANGE SCAN                                       | INT_REFDOSS           |      1 |      3 |     1   (0)|      1 |00:00:00.01 |       4 |      0 |
|* 30 |  COUNT STOPKEY                                           |                       |      1 |        |            |      0 |00:00:00.01 |       4 |      0 |
|  31 |   NESTED LOOPS                                           |                       |      1 |      1 |     2   (0)|      0 |00:00:00.01 |       4 |      0 |
|* 32 |    TABLE ACCESS BY INDEX ROWID                           | G_DOSSIER             |      1 |      1 |     1   (0)|      0 |00:00:00.01 |       4 |      0 |
|* 33 |     INDEX UNIQUE SCAN                                    | DOS_REFDOSS           |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |      0 |
|  34 |    TABLE ACCESS BY INDEX ROWID BATCHED                   | G_PIECE               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 35 |     INDEX RANGE SCAN                                     | PIE_REFDOSS           |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 36 |  VIEW                                                    |                       |      1 |      1 |    65   (5)|      1 |00:00:00.10 |     216 |    117 |
|* 37 |   COUNT STOPKEY                                          |                       |      1 |        |            |      1 |00:00:00.10 |     216 |    117 |
|  38 |    VIEW                                                  |                       |      1 |      1 |    65   (5)|      1 |00:00:00.10 |     216 |    117 |
|* 39 |     SORT ORDER BY STOPKEY                                |                       |      1 |      1 |    65   (5)|      1 |00:00:00.10 |     216 |    117 |
|  40 |      HASH UNIQUE                                         |                       |      1 |      1 |    64   (4)|      1 |00:00:00.10 |     216 |    117 |
|  41 |       WINDOW SORT                                        |                       |      1 |      1 |    65   (5)|      1 |00:00:00.01 |      81 |      8 |
|* 42 |        FILTER                                            |                       |      1 |        |            |      1 |00:00:00.01 |      81 |      8 |
|  43 |         NESTED LOOPS                                     |                       |      1 |      1 |    52   (0)|      1 |00:00:00.01 |      70 |      8 |
|  44 |          NESTED LOOPS OUTER                              |                       |      1 |      1 |    42   (0)|      1 |00:00:00.01 |      68 |      8 |
|  45 |           NESTED LOOPS OUTER                             |                       |      1 |      1 |    32   (0)|      1 |00:00:00.01 |      64 |      8 |
|  46 |            NESTED LOOPS OUTER                            |                       |      1 |      1 |    30   (0)|      1 |00:00:00.01 |      61 |      7 |
|* 47 |             HASH JOIN                                    |                       |      1 |      1 |    20   (0)|      1 |00:00:00.01 |      61 |      7 |
|  48 |              NESTED LOOPS                                |                       |      1 |      1 |    10   (0)|      1 |00:00:00.01 |      50 |      7 |
|  49 |               NESTED LOOPS                               |                       |      1 |      1 |     9   (0)|      1 |00:00:00.01 |      47 |      7 |
|  50 |                NESTED LOOPS                              |                       |      1 |      1 |     8   (0)|      1 |00:00:00.01 |      42 |      5 |
|  51 |                 NESTED LOOPS                             |                       |      1 |      1 |     7   (0)|      1 |00:00:00.01 |      38 |      5 |
|  52 |                  NESTED LOOPS                            |                       |      1 |      1 |     6   (0)|      1 |00:00:00.01 |      35 |      3 |
|  53 |                   NESTED LOOPS OUTER                     |                       |      1 |      1 |     5   (0)|      1 |00:00:00.01 |      32 |      3 |
|  54 |                    NESTED LOOPS                          |                       |      1 |      1 |     4   (0)|      1 |00:00:00.01 |      31 |      3 |
|  55 |                     MERGE JOIN CARTESIAN                 |                       |      1 |      1 |     3   (0)|     11 |00:00:00.01 |      13 |      3 |
|  56 |                      NESTED LOOPS                        |                       |      1 |      1 |     2   (0)|      1 |00:00:00.01 |      10 |      2 |
|* 57 |                       TABLE ACCESS BY INDEX ROWID BATCHED| G_DOSSIER             |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       6 |      1 |
|* 58 |                        INDEX RANGE SCAN                  | DOS_ANCREFDOSS        |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |      1 |
|* 59 |                       INDEX RANGE SCAN                   | INT_REFDOSS           |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       4 |      1 |
|  60 |                      BUFFER SORT                         |                       |      1 |      1 |     2   (0)|     11 |00:00:00.01 |       3 |      1 |
|* 61 |                       TABLE ACCESS BY INDEX ROWID BATCHED| V_EXTR_DOM            |      1 |      1 |     1   (0)|     11 |00:00:00.01 |       3 |      1 |
|* 62 |                        INDEX RANGE SCAN                  | TYPEABREV             |      1 |      2 |     1   (0)|     11 |00:00:00.01 |       2 |      1 |
|* 63 |                     INDEX RANGE SCAN                     | INT_REFDOSS           |     11 |      1 |     1   (0)|      1 |00:00:00.01 |      18 |      0 |
|* 64 |                    INDEX RANGE SCAN                      | LST_SCORE_REFDOSS_IDX |      1 |      1 |     1   (0)|      0 |00:00:00.01 |       1 |      0 |
|* 65 |                   TABLE ACCESS BY INDEX ROWID BATCHED    | V_DOMAINE             |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |      0 |
|* 66 |                    INDEX RANGE SCAN                      | DOM_TYPVAL            |      1 |      3 |     1   (0)|      1 |00:00:00.01 |       2 |      0 |
|* 67 |                    TABLE ACCESS FULL                     | G_ETUDE               |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 68 |                  INDEX RANGE SCAN                        | PIE_REFDOSS           |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |      2 |
|* 69 |                 INDEX RANGE SCAN                         | INT_REFDOSS           |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       4 |      0 |
|  70 |                TABLE ACCESS BY INDEX ROWID               | G_INDIVIDU            |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       5 |      2 |
|* 71 |                 INDEX UNIQUE SCAN                        | IND_REFINDIV          |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |      1 |
|* 72 |               INDEX UNIQUE SCAN                          | IND_REFINDIV          |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |      0 |
|  73 |              VIEW                                        | V_TDOMAINE            |      1 |     10 |    10   (0)|     20 |00:00:00.01 |      11 |      0 |
|  74 |               UNION-ALL                                  |                       |      1 |        |            |     20 |00:00:00.01 |      11 |      0 |
|* 75 |                FILTER                                    |                       |      1 |        |            |     20 |00:00:00.01 |      11 |      0 |
|  76 |                 TABLE ACCESS BY INDEX ROWID BATCHED      | V_DOMAINE             |      1 |      1 |     1   (0)|     20 |00:00:00.01 |      11 |      0 |
|* 77 |                  INDEX RANGE SCAN                        | DOM_CHAMP             |      1 |      1 |     1   (0)|     20 |00:00:00.01 |       2 |      0 |
|* 78 |                FILTER                                    |                       |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  79 |                 TABLE ACCESS BY INDEX ROWID BATCHED      | V_DOMAINE             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 80 |                  INDEX RANGE SCAN                        | DOM_CHAMP             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 81 |                FILTER                                    |                       |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  82 |                 TABLE ACCESS BY INDEX ROWID BATCHED      | V_DOMAINE             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 83 |                  INDEX RANGE SCAN                        | DOM_CHAMP             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 84 |                FILTER                                    |                       |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  85 |                 TABLE ACCESS BY INDEX ROWID BATCHED      | V_DOMAINE             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 86 |                  INDEX RANGE SCAN                        | DOM_CHAMP             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 87 |                FILTER                                    |                       |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  88 |                 TABLE ACCESS BY INDEX ROWID BATCHED      | V_DOMAINE             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 89 |                  INDEX RANGE SCAN                        | DOM_CHAMP             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 90 |                FILTER                                    |                       |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  91 |                 TABLE ACCESS BY INDEX ROWID BATCHED      | V_DOMAINE             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 92 |                  INDEX RANGE SCAN                        | DOM_CHAMP             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 93 |                FILTER                                    |                       |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  94 |                 TABLE ACCESS BY INDEX ROWID BATCHED      | V_DOMAINE             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 95 |                  INDEX RANGE SCAN                        | DOM_CHAMP             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 96 |                FILTER                                    |                       |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  97 |                 TABLE ACCESS BY INDEX ROWID BATCHED      | V_DOMAINE             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 98 |                  INDEX RANGE SCAN                        | DOM_CHAMP             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 99 |                FILTER                                    |                       |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 100 |                 TABLE ACCESS BY INDEX ROWID BATCHED      | V_DOMAINE             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*101 |                  INDEX RANGE SCAN                        | DOM_CHAMP             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*102 |                FILTER                                    |                       |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 103 |                 TABLE ACCESS BY INDEX ROWID BATCHED      | V_DOMAINE             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*104 |                  INDEX RANGE SCAN                        | DOM_CHAMP             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*105 |             VIEW                                         | V_TDOMAINE            |      1 |      1 |    10   (0)|      0 |00:00:00.01 |       0 |      0 |
| 106 |              UNION ALL PUSHED PREDICATE                  |                       |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*107 |               FILTER                                     |                       |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 108 |                TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE             |      1 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*109 |                 INDEX RANGE SCAN                         | DOM_TYPABREV          |      1 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*110 |               FILTER                                     |                       |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 111 |                TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*112 |                 INDEX RANGE SCAN                         | DOM_TYPABREV          |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*113 |               FILTER                                     |                       |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 114 |                TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*115 |                 INDEX RANGE SCAN                         | DOM_TYPABREV          |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*116 |               FILTER                                     |                       |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 117 |                TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*118 |                 INDEX RANGE SCAN                         | DOM_TYPABREV          |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*119 |               FILTER                                     |                       |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 120 |                TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*121 |                 INDEX RANGE SCAN                         | DOM_TYPABREV          |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*122 |               FILTER                                     |                       |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 123 |                TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*124 |                 INDEX RANGE SCAN                         | DOM_TYPABREV          |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*125 |               FILTER                                     |                       |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 126 |                TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*127 |                 INDEX RANGE SCAN                         | DOM_TYPABREV          |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*128 |               FILTER                                     |                       |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 129 |                TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*130 |                 INDEX RANGE SCAN                         | DOM_TYPABREV          |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*131 |               FILTER                                     |                       |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 132 |                TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*133 |                 INDEX RANGE SCAN                         | DOM_TYPABREV          |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*134 |               FILTER                                     |                       |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 135 |                TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*136 |                 INDEX RANGE SCAN                         | DOM_TYPABREV          |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 137 |            VIEW PUSHED PREDICATE                         |                       |      1 |      1 |     2   (0)|      0 |00:00:00.01 |       3 |      1 |
| 138 |             NESTED LOOPS                                 |                       |      1 |      1 |     2   (0)|      0 |00:00:00.01 |       3 |      1 |
| 139 |              NESTED LOOPS                                |                       |      1 |      1 |     2   (0)|      0 |00:00:00.01 |       3 |      1 |
| 140 |               TABLE ACCESS BY INDEX ROWID BATCHED        | G_PIECE               |      1 |      1 |     1   (0)|      0 |00:00:00.01 |       3 |      1 |
|*141 |                INDEX RANGE SCAN                          | PIE_REFDOSS           |      1 |      1 |     1   (0)|      0 |00:00:00.01 |       3 |      1 |
|*142 |               INDEX RANGE SCAN                           | G_PIECEDET_REFP       |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*143 |              TABLE ACCESS BY INDEX ROWID                 | G_PIECEDET            |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 144 |           VIEW                                           | V_TDOMAINE            |      1 |      1 |    10   (0)|      1 |00:00:00.01 |       4 |      0 |
| 145 |            UNION ALL PUSHED PREDICATE                    |                       |      1 |        |            |      1 |00:00:00.01 |       4 |      0 |
|*146 |             FILTER                                       |                       |      1 |        |            |      1 |00:00:00.01 |       4 |      0 |
| 147 |              TABLE ACCESS BY INDEX ROWID BATCHED         | V_DOMAINE             |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       4 |      0 |
|*148 |               INDEX RANGE SCAN                           | DOM_TYPABREV          |      1 |      2 |     1   (0)|      1 |00:00:00.01 |       3 |      0 |
|*149 |             FILTER                                       |                       |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 150 |              TABLE ACCESS BY INDEX ROWID BATCHED         | V_DOMAINE             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*151 |               INDEX RANGE SCAN                           | DOM_TYPABREV          |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*152 |             FILTER                                       |                       |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 153 |              TABLE ACCESS BY INDEX ROWID BATCHED         | V_DOMAINE             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*154 |               INDEX RANGE SCAN                           | DOM_TYPABREV          |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*155 |             FILTER                                       |                       |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 156 |              TABLE ACCESS BY INDEX ROWID BATCHED         | V_DOMAINE             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*157 |               INDEX RANGE SCAN                           | DOM_TYPABREV          |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*158 |             FILTER                                       |                       |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 159 |              TABLE ACCESS BY INDEX ROWID BATCHED         | V_DOMAINE             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*160 |               INDEX RANGE SCAN                           | DOM_TYPABREV          |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*161 |             FILTER                                       |                       |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 162 |              TABLE ACCESS BY INDEX ROWID BATCHED         | V_DOMAINE             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*163 |               INDEX RANGE SCAN                           | DOM_TYPABREV          |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*164 |             FILTER                                       |                       |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 165 |              TABLE ACCESS BY INDEX ROWID BATCHED         | V_DOMAINE             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*166 |               INDEX RANGE SCAN                           | DOM_TYPABREV          |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*167 |             FILTER                                       |                       |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 168 |              TABLE ACCESS BY INDEX ROWID BATCHED         | V_DOMAINE             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*169 |               INDEX RANGE SCAN                           | DOM_TYPABREV          |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*170 |             FILTER                                       |                       |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 171 |              TABLE ACCESS BY INDEX ROWID BATCHED         | V_DOMAINE             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*172 |               INDEX RANGE SCAN                           | DOM_TYPABREV          |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*173 |             FILTER                                       |                       |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 174 |              TABLE ACCESS BY INDEX ROWID BATCHED         | V_DOMAINE             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*175 |               INDEX RANGE SCAN                           | DOM_TYPABREV          |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 176 |          VIEW                                            | V_TDOMAINE            |      1 |      1 |    10   (0)|      1 |00:00:00.01 |       2 |      0 |
| 177 |           UNION ALL PUSHED PREDICATE                     |                       |      1 |        |            |      1 |00:00:00.01 |       2 |      0 |
|*178 |            FILTER                                        |                       |      1 |        |            |      1 |00:00:00.01 |       2 |      0 |
|*179 |             INDEX RANGE SCAN                             | DOM_TYPVAL            |      1 |      2 |     1   (0)|      1 |00:00:00.01 |       2 |      0 |
|*180 |            FILTER                                        |                       |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*181 |             INDEX RANGE SCAN                             | DOM_TYPVAL            |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*182 |            FILTER                                        |                       |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*183 |             INDEX RANGE SCAN                             | DOM_TYPVAL            |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*184 |            FILTER                                        |                       |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*185 |             INDEX RANGE SCAN                             | DOM_TYPVAL            |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*186 |            FILTER                                        |                       |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*187 |             INDEX RANGE SCAN                             | DOM_TYPVAL            |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*188 |            FILTER                                        |                       |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*189 |             INDEX RANGE SCAN                             | DOM_TYPVAL            |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*190 |            FILTER                                        |                       |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*191 |             INDEX RANGE SCAN                             | DOM_TYPVAL            |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*192 |            FILTER                                        |                       |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*193 |             INDEX RANGE SCAN                             | DOM_TYPVAL            |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*194 |            FILTER                                        |                       |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*195 |             INDEX RANGE SCAN                             | DOM_TYPVAL            |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*196 |            FILTER                                        |                       |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*197 |             INDEX RANGE SCAN                             | DOM_TYPVAL            |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 198 |         TABLE ACCESS BY INDEX ROWID                      | G_DOSSIER             |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       6 |      0 |
|*199 |          INDEX UNIQUE SCAN                               | DOS_REFDOSS           |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |      0 |
| 200 |         TABLE ACCESS BY INDEX ROWID                      | G_DOSSIER             |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       5 |      0 |
|*201 |          INDEX UNIQUE SCAN                               | DOS_REFDOSS           |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |      0 |
------------------------------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   1 - filter(ROWNUM=1)
   2 - filter("DTFIN_DT" IS NULL)
   3 - access("REFDOSS"=:B1)
   4 - filter(ROWNUM=1)
   7 - filter("AUTH"."VALEUR_2" IS NOT NULL)
   8 - access("AUTH"."TYPE"='EXTR_GEST_CLIENT' AND "AUTH"."ABREV"=TO_CHAR(:B1))
   9 - access("TI"."REFDOSS"=:B1 AND "TI"."REFTYPE"="AUTH"."VALEUR_2" AND "TI"."REFINDIVIDU"="AUTH"."VALEUR")
  10 - filter("TI"."REFDOSSEXT" IS NOT NULL)
  12 - access("IMX_UN_ID"=)
  17 - filter(("DECOMPTE"."REFDOSS"=:B1 AND "DECOMPTE"."CATEGDOSS" LIKE 'DECOMPTE%'))
  18 - filter("DECOMPTE"."REFLOT" IS NOT NULL)
  20 - access("DECOMPTE"."REFLOT"="CONTR"."REFDOSS")
  21 - access("REFINDIVIDU"=:B1)
  22 - filter(("REFEXT3" IS NOT NULL AND "REFEXT3"="CONTR"."ANCREFDOSS" AND "REFEXT2"=:B1 AND "SOCIETE"='CLIENT_NUMBER'))
  24 - access("VALEUR"= AND "TYPE"='typencour')
  27 - access("TA"."REFENTITE"=:B1)
  28 - filter(ROWNUM=1)
  29 - access("SR"."REFDOSS"=:B1)
       filter(("SR"."REFTYPE"<>'DB' AND "SR"."REFTYPE"<>'CL' AND "SR"."REFTYPE"<>'XX'))
  30 - filter(ROWNUM=1)
  32 - filter("G"."CATEGDOSS" LIKE 'COLLECTION%')
  33 - access("G"."REFDOSS"=:B1)
  35 - access("PIECE"."REFDOSS"=:B1 AND "PIECE"."TYPPIECE"='DBT_VERIF_REQ')
  36 - filter("RECORD_NO">=:B5)
  37 - filter(ROWNUM<=:B4)
  39 - filter(ROWNUM<=:B4)
  42 - filter((DECODE("D"."REFHIERARCHIE",NULL,'N',)='N' AND DECODE("D"."REFHIERARCHIE2",NULL,'N',)='N'))
  47 - access("VD_PIECEINIT"."VALEUR"="D"."PIECEINIT")
  57 - filter(("D"."CATEGDOSS"<>'COMPTE DB CTR' AND "D"."REFDOSS" NOT LIKE 'GL%' AND NVL("D"."FG_EXCL_FROM_EXTR",'N')<>'O' AND
              NVL("FG_FRM_INC",'N')<>'O'))
  58 - access("D"."ANCREFDOSS"=UPPER(:B3))
  59 - access("D"."REFDOSS"="T"."REFDOSS" AND "T"."REFTYPE"='DB')
  61 - filter("AUTH"."VALEUR_2" IS NOT NULL)
  62 - access("AUTH"."TYPE"='EXTR_GEST_CLIENT' AND "AUTH"."ABREV"=TO_CHAR(:B1))
  63 - access("D"."REFDOSS"="T_INT"."REFDOSS" AND "T_INT"."REFTYPE"="AUTH"."VALEUR_2" AND "T_INT"."REFINDIVIDU"="AUTH"."VALEUR")
  64 - access("LST"."REFDOSS"="D"."REFDOSS")
  65 - filter(("ECRAN"='X' OR  IS NOT NULL))
  66 - access("D"."CATEGDOSS"="VALEUR" AND "TYPE"='categdoss')
       filter("VALEUR"<>'COMPTE DB CTR')
  67 - filter(("ACTIVITE_GPC"='G' OR "ACTIVITE_GPC"='T'))
  68 - access("PIECECASE"."REFDOSS"="D"."REFDOSS" AND "PIECECASE"."TYPPIECE"="D"."PIECEINIT")
  69 - access("D"."REFDOSS"="CLIENT"."REFDOSS")
       filter(("CLIENT"."REFTYPE"='CL' OR "CLIENT"."REFTYPE"='TC'))
  71 - access("T"."REFINDIVIDU"="I"."REFINDIVIDU")
  72 - access("ICL"."REFINDIVIDU"="CLIENT"."REFINDIVIDU")
  75 - filter('AN'=:B2)
  77 - access("CHAMP"='pieceinit')
  78 - filter('CS'=:B2)
  80 - access("CHAMP"='pieceinit')
  81 - filter('FR'=:B2)
  83 - access("CHAMP"='pieceinit')
  84 - filter('HU'=:B2)
  86 - access("CHAMP"='pieceinit')
  87 - filter('NL'=:B2)
  89 - access("CHAMP"='pieceinit')
  90 - filter('PL'=:B2)
  92 - access("CHAMP"='pieceinit')
  93 - filter('RU'=:B2)
  95 - access("CHAMP"='pieceinit')
  96 - filter('SK'=:B2)
  98 - access("CHAMP"='pieceinit')
  99 - filter('VI'=:B2)
101 - access("CHAMP"='pieceinit')
102 - filter('ZH'=:B2)
104 - access("CHAMP"='pieceinit')
105 - filter("VD_DIV"."ECRAN"="I"."PAYS")
107 - filter('AN'=:B2)
109 - access("TYPE"='DIVISION TERRITORIALE' AND "ABREV"="I"."DIVISION")
110 - filter('CS'=:B2)
112 - access("TYPE"='DIVISION TERRITORIALE' AND "ABREV"="I"."DIVISION")
113 - filter('FR'=:B2)
115 - access("TYPE"='DIVISION TERRITORIALE' AND "ABREV"="I"."DIVISION")
116 - filter('HU'=:B2)
118 - access("TYPE"='DIVISION TERRITORIALE' AND "ABREV"="I"."DIVISION")
119 - filter('NL'=:B2)
121 - access("TYPE"='DIVISION TERRITORIALE' AND "ABREV"="I"."DIVISION")
122 - filter('PL'=:B2)
124 - access("TYPE"='DIVISION TERRITORIALE' AND "ABREV"="I"."DIVISION")
125 - filter('RU'=:B2)
127 - access("TYPE"='DIVISION TERRITORIALE' AND "ABREV"="I"."DIVISION")
128 - filter('SK'=:B2)
130 - access("TYPE"='DIVISION TERRITORIALE' AND "ABREV"="I"."DIVISION")
131 - filter('VI'=:B2)
133 - access("TYPE"='DIVISION TERRITORIALE' AND "ABREV"="I"."DIVISION")
134 - filter('ZH'=:B2)
136 - access("TYPE"='DIVISION TERRITORIALE' AND "ABREV"="I"."DIVISION")
141 - access("P"."REFDOSS"="D"."REFHIERARCHIE" AND "P"."TYPPIECE"='CONTRAT')
142 - access("PD"."REFPIECE"="P"."REFPIECE" AND "PD"."TYPE"='CI CONTRACTS')
143 - filter("PD"."FG01"='O')
146 - filter('AN'=:B2)
148 - access("TYPE"='pays' AND "ABREV"="I"."PAYS")
149 - filter('CS'=:B2)
151 - access("TYPE"='pays' AND "ABREV"="I"."PAYS")
152 - filter('FR'=:B2)
154 - access("TYPE"='pays' AND "ABREV"="I"."PAYS")
155 - filter('HU'=:B2)
157 - access("TYPE"='pays' AND "ABREV"="I"."PAYS")
158 - filter('NL'=:B2)
160 - access("TYPE"='pays' AND "ABREV"="I"."PAYS")
161 - filter('PL'=:B2)
163 - access("TYPE"='pays' AND "ABREV"="I"."PAYS")
164 - filter('RU'=:B2)
166 - access("TYPE"='pays' AND "ABREV"="I"."PAYS")
167 - filter('SK'=:B2)
169 - access("TYPE"='pays' AND "ABREV"="I"."PAYS")
170 - filter('VI'=:B2)
172 - access("TYPE"='pays' AND "ABREV"="I"."PAYS")
173 - filter('ZH'=:B2)
175 - access("TYPE"='pays' AND "ABREV"="I"."PAYS")
178 - filter(("D"."CATEGDOSS"<>'COMPTE DB CTR' AND 'AN'=:B2))
179 - access("VALEUR"="D"."CATEGDOSS")
       filter("VALEUR"<>'COMPTE DB CTR')
180 - filter(("D"."CATEGDOSS"<>'COMPTE DB CTR' AND 'CS'=:B2))
181 - access("VALEUR"="D"."CATEGDOSS")
       filter("VALEUR"<>'COMPTE DB CTR')
182 - filter(("D"."CATEGDOSS"<>'COMPTE DB CTR' AND 'FR'=:B2))
183 - access("VALEUR"="D"."CATEGDOSS")
       filter("VALEUR"<>'COMPTE DB CTR')
184 - filter(("D"."CATEGDOSS"<>'COMPTE DB CTR' AND 'HU'=:B2))
185 - access("VALEUR"="D"."CATEGDOSS")
       filter("VALEUR"<>'COMPTE DB CTR')
186 - filter(("D"."CATEGDOSS"<>'COMPTE DB CTR' AND 'NL'=:B2))
187 - access("VALEUR"="D"."CATEGDOSS")
       filter("VALEUR"<>'COMPTE DB CTR')
188 - filter(("D"."CATEGDOSS"<>'COMPTE DB CTR' AND 'PL'=:B2))
189 - access("VALEUR"="D"."CATEGDOSS")
       filter("VALEUR"<>'COMPTE DB CTR')
190 - filter(("D"."CATEGDOSS"<>'COMPTE DB CTR' AND 'RU'=:B2))
191 - access("VALEUR"="D"."CATEGDOSS")
       filter("VALEUR"<>'COMPTE DB CTR')
192 - filter(("D"."CATEGDOSS"<>'COMPTE DB CTR' AND 'SK'=:B2))
193 - access("VALEUR"="D"."CATEGDOSS")
       filter("VALEUR"<>'COMPTE DB CTR')
194 - filter(("D"."CATEGDOSS"<>'COMPTE DB CTR' AND 'VI'=:B2))
195 - access("VALEUR"="D"."CATEGDOSS")
       filter("VALEUR"<>'COMPTE DB CTR')
196 - filter(("D"."CATEGDOSS"<>'COMPTE DB CTR' AND 'ZH'=:B2))
197 - access("VALEUR"="D"."CATEGDOSS")
       filter("VALEUR"<>'COMPTE DB CTR')
199 - access("REFDOSS"=:B1)
201 - access("REFDOSS"=:B1)




-- 5531653ds9d4k

Plan hash value: 2060978238
-----------------------------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                               | Name                  | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads   |
-----------------------------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                                        |                       |      1 |        | 25832 (100)|      6 |00:00:00.11 |      653 |    127 |
|*  1 |  COUNT STOPKEY                                          |                       |      6 |        |            |      6 |00:00:00.09 |      296 |    107 |
|*  2 |   TABLE ACCESS BY INDEX ROWID BATCHED                   | T_FILIERE             |      6 |      1 |     1   (0)|      6 |00:00:00.09 |      296 |    107 |
|*  3 |    INDEX RANGE SCAN                                     | T_FIL_DTFINDEB        |      6 |      7 |     1   (0)|    345 |00:00:00.01 |       27 |      7 |
|*  4 |  COUNT STOPKEY                                          |                       |      6 |        |            |      6 |00:00:00.01 |       70 |      3 |
|   5 |   NESTED LOOPS                                          |                       |      6 |      1 |     2   (0)|      6 |00:00:00.01 |       70 |      3 |
|   6 |    NESTED LOOPS                                         |                       |      6 |      1 |     2   (0)|      6 |00:00:00.01 |       64 |      0 |
|*  7 |     TABLE ACCESS BY INDEX ROWID BATCHED                 | V_EXTR_DOM            |      6 |      1 |     1   (0)|     18 |00:00:00.01 |       17 |      0 |
|*  8 |      INDEX RANGE SCAN                                   | TYPEABREV             |      6 |      2 |     1   (0)|     18 |00:00:00.01 |       11 |      0 |
|*  9 |     INDEX RANGE SCAN                                    | INT_REFDOSS           |     18 |      1 |     1   (0)|      6 |00:00:00.01 |       47 |      0 |
|* 10 |    TABLE ACCESS BY INDEX ROWID                          | T_INTERVENANTS        |      6 |      1 |     1   (0)|      6 |00:00:00.01 |        6 |      3 |
|  11 |  TABLE ACCESS BY INDEX ROWID                            | T_INDIVIDU            |      2 |      1 |     1   (0)|      0 |00:00:00.01 |        1 |      0 |
|* 12 |   INDEX UNIQUE SCAN                                     | PK_T_INDIVIDU         |      2 |      1 |     1   (0)|      0 |00:00:00.01 |        1 |      0 |
|  13 |    SORT AGGREGATE                                       |                       |      2 |      1 |            |      2 |00:00:00.01 |        1 |      0 |
|  14 |     NESTED LOOPS                                        |                       |      2 |      1 |     3   (0)|      0 |00:00:00.01 |        1 |      0 |
|  15 |      NESTED LOOPS                                       |                       |      2 |      2 |     3   (0)|      0 |00:00:00.01 |        1 |      0 |
|  16 |       NESTED LOOPS                                      |                       |      2 |      1 |     2   (0)|      0 |00:00:00.01 |        1 |      0 |
|* 17 |        TABLE ACCESS BY INDEX ROWID BATCHED              | G_DOSSIER             |      2 |      1 |     1   (0)|      0 |00:00:00.01 |        1 |      0 |
|* 18 |         INDEX FULL SCAN                                 | DOSS_LOT              |      2 |      1 |     1   (0)|      0 |00:00:00.01 |        1 |      0 |
|  19 |        TABLE ACCESS BY INDEX ROWID                      | G_DOSSIER             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |        0 |      0 |
|* 20 |         INDEX UNIQUE SCAN                               | DOS_REFDOSS           |      0 |      1 |     1   (0)|      0 |00:00:00.01 |        0 |      0 |
|* 21 |       INDEX RANGE SCAN                                  | IX_T_INDIVIDU         |      0 |      2 |     1   (0)|      0 |00:00:00.01 |        0 |      0 |
|* 22 |      TABLE ACCESS BY INDEX ROWID                        | T_INDIVIDU            |      0 |      1 |     1   (0)|      0 |00:00:00.01 |        0 |      0 |
|  23 |  TABLE ACCESS BY INDEX ROWID BATCHED                    | V_DOMAINE             |      6 |      1 |     1   (0)|      6 |00:00:00.01 |       31 |      7 |
|* 24 |   INDEX RANGE SCAN                                      | DOM_TYPVAL            |      6 |      3 |     1   (0)|      6 |00:00:00.01 |       27 |      7 |
|  25 |    SORT AGGREGATE                                       |                       |      6 |      1 |            |      6 |00:00:00.01 |       19 |      7 |
|  26 |     TABLE ACCESS BY INDEX ROWID BATCHED                 | T_ATTENTE             |      6 |      1 |     1   (0)|      6 |00:00:00.01 |       19 |      7 |
|* 27 |      INDEX RANGE SCAN                                   | PK_ATTENTE            |      6 |      1 |     1   (0)|      6 |00:00:00.01 |       14 |      4 |
|* 28 |  COUNT STOPKEY                                          |                       |      6 |        |            |      5 |00:00:00.01 |       24 |      0 |
|* 29 |   INDEX RANGE SCAN                                      | INT_REFDOSS           |      6 |      3 |     1   (0)|      5 |00:00:00.01 |       24 |      0 |
|* 30 |  COUNT STOPKEY                                          |                       |      6 |        |            |      0 |00:00:00.01 |       24 |      0 |
|  31 |   NESTED LOOPS                                          |                       |      6 |      1 |     2   (0)|      0 |00:00:00.01 |       24 |      0 |
|* 32 |    TABLE ACCESS BY INDEX ROWID                          | G_DOSSIER             |      6 |      1 |     1   (0)|      0 |00:00:00.01 |       24 |      0 |
|* 33 |     INDEX UNIQUE SCAN                                   | DOS_REFDOSS           |      6 |      1 |     1   (0)|      6 |00:00:00.01 |       18 |      0 |
|  34 |    TABLE ACCESS BY INDEX ROWID BATCHED                  | G_PIECE               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |        0 |      0 |
|* 35 |     INDEX RANGE SCAN                                    | PIE_REFDOSS           |      0 |      1 |     1   (0)|      0 |00:00:00.01 |        0 |      0 |
|* 36 |  VIEW                                                   |                       |      1 |      1 | 25832   (1)|      6 |00:00:00.11 |      653 |    127 |
|* 37 |   COUNT STOPKEY                                         |                       |      1 |        |            |      6 |00:00:00.11 |      653 |    127 |
|  38 |    VIEW                                                 |                       |      1 |      1 | 25832   (1)|      6 |00:00:00.11 |      653 |    127 |
|* 39 |     SORT UNIQUE STOPKEY                                 |                       |      1 |      1 | 25831   (1)|      6 |00:00:00.11 |      653 |    127 |
|  40 |      WINDOW SORT                                        |                       |      1 |      1 | 25832   (1)|    782 |00:00:00.01 |      207 |     10 |
|* 41 |       FILTER                                            |                       |      1 |        |            |    782 |00:00:00.01 |      207 |     10 |
|  42 |        NESTED LOOPS                                     |                       |      1 |      1 | 25819   (1)|    782 |00:00:00.01 |      191 |     10 |
|  43 |         NESTED LOOPS OUTER                              |                       |      1 |      1 | 25809   (1)|      6 |00:00:00.01 |      172 |     10 |
|  44 |          NESTED LOOPS OUTER                             |                       |      1 |      1 | 25799   (1)|      6 |00:00:00.01 |      150 |     10 |
|  45 |           NESTED LOOPS                                  |                       |      1 |      1 | 25797   (1)|      6 |00:00:00.01 |      138 |     10 |
|  46 |            NESTED LOOPS                                 |                       |      1 |      1 | 25796   (1)|      6 |00:00:00.01 |      125 |     10 |
|  47 |             NESTED LOOPS                                |                       |      1 |      1 | 25795   (1)|      6 |00:00:00.01 |      105 |     10 |
|  48 |              NESTED LOOPS                               |                       |      1 |      1 | 25794   (1)|      6 |00:00:00.01 |       91 |      7 |
|  49 |               NESTED LOOPS                              |                       |      1 |      1 | 25793   (1)|      6 |00:00:00.01 |       81 |      7 |
|  50 |                NESTED LOOPS OUTER                       |                       |      1 |      1 | 25792   (1)|     26 |00:00:00.01 |       72 |      7 |
|  51 |                 NESTED LOOPS OUTER                      |                       |      1 |      1 | 25782   (1)|     26 |00:00:00.01 |       72 |      7 |
|* 52 |                  HASH JOIN                              |                       |      1 |      1 | 25781   (1)|     26 |00:00:00.01 |       71 |      7 |
|  53 |                   VIEW                                  | V_TDOMAINE            |      1 |     10 |    10   (0)|     20 |00:00:00.01 |       11 |      0 |
|  54 |                    UNION-ALL                            |                       |      1 |        |            |     20 |00:00:00.01 |       11 |      0 |
|* 55 |                     FILTER                              |                       |      1 |        |            |     20 |00:00:00.01 |       11 |      0 |
|  56 |                      TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE             |      1 |      1 |     1   (0)|     20 |00:00:00.01 |       11 |      0 |
|* 57 |                       INDEX RANGE SCAN                  | DOM_CHAMP             |      1 |      1 |     1   (0)|     20 |00:00:00.01 |        2 |      0 |
|* 58 |                     FILTER                              |                       |      1 |        |            |      0 |00:00:00.01 |        0 |      0 |
|  59 |                      TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |        0 |      0 |
|* 60 |                       INDEX RANGE SCAN                  | DOM_CHAMP             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |        0 |      0 |
|* 61 |                     FILTER                              |                       |      1 |        |            |      0 |00:00:00.01 |        0 |      0 |
|  62 |                      TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |        0 |      0 |
|* 63 |                       INDEX RANGE SCAN                  | DOM_CHAMP             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |        0 |      0 |
|* 64 |                     FILTER                              |                       |      1 |        |            |      0 |00:00:00.01 |        0 |      0 |
|  65 |                      TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |        0 |      0 |
|* 66 |                       INDEX RANGE SCAN                  | DOM_CHAMP             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |        0 |      0 |
|* 67 |                     FILTER                              |                       |      1 |        |            |      0 |00:00:00.01 |        0 |      0 |
|  68 |                      TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |        0 |      0 |
|* 69 |                       INDEX RANGE SCAN                  | DOM_CHAMP             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |        0 |      0 |
|* 70 |                     FILTER                              |                       |      1 |        |            |      0 |00:00:00.01 |        0 |      0 |
|  71 |                      TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |        0 |      0 |
|* 72 |                       INDEX RANGE SCAN                  | DOM_CHAMP             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |        0 |      0 |
|* 73 |                     FILTER                              |                       |      1 |        |            |      0 |00:00:00.01 |        0 |      0 |
|  74 |                      TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |        0 |      0 |
|* 75 |                       INDEX RANGE SCAN                  | DOM_CHAMP             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |        0 |      0 |
|* 76 |                     FILTER                              |                       |      1 |        |            |      0 |00:00:00.01 |        0 |      0 |
|  77 |                      TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |        0 |      0 |
|* 78 |                       INDEX RANGE SCAN                  | DOM_CHAMP             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |        0 |      0 |
|* 79 |                     FILTER                              |                       |      1 |        |            |      0 |00:00:00.01 |        0 |      0 |
|  80 |                      TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |        0 |      0 |
|* 81 |                       INDEX RANGE SCAN                  | DOM_CHAMP             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |        0 |      0 |
|* 82 |                     FILTER                              |                       |      1 |        |            |      0 |00:00:00.01 |        0 |      0 |
|  83 |                      TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |        0 |      0 |
|* 84 |                       INDEX RANGE SCAN                  | DOM_CHAMP             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |        0 |      0 |
|  85 |                   NESTED LOOPS                          |                       |      1 |    931K| 25764   (1)|     26 |00:00:00.01 |       60 |      7 |
|  86 |                    NESTED LOOPS                         |                       |      1 |    322K| 16094   (1)|      6 |00:00:00.01 |       40 |      3 |
|  87 |                     NESTED LOOPS                        |                       |      1 |    322K|  9644   (1)|      6 |00:00:00.01 |        9 |      3 |
|  88 |                      TABLE ACCESS BY INDEX ROWID BATCHED| G_INDIVIDU            |      1 |    306K|   459   (1)|      1 |00:00:00.01 |        5 |      2 |
|* 89 |                       INDEX RANGE SCAN                  | NUMSS_IDX             |      1 |  45890 |     2   (0)|      1 |00:00:00.01 |        3 |      2 |
|* 90 |                      INDEX RANGE SCAN                   | INT_INDIV             |      1 |      1 |     1   (0)|      6 |00:00:00.01 |        4 |      1 |
|* 91 |                     TABLE ACCESS BY INDEX ROWID         | G_DOSSIER             |      6 |      1 |     1   (0)|      6 |00:00:00.01 |       31 |      0 |
|* 92 |                      INDEX UNIQUE SCAN                  | DOS_REFDOSS           |      6 |      1 |     1   (0)|      6 |00:00:00.01 |       14 |      0 |
|* 93 |                    INDEX RANGE SCAN                     | INT_REFDOSS           |      6 |      3 |     1   (0)|     26 |00:00:00.01 |       20 |      4 |
|* 94 |                  INDEX RANGE SCAN                       | LST_SCORE_REFDOSS_IDX |     26 |      1 |     1   (0)|      0 |00:00:00.01 |        1 |      0 |
|* 95 |                 VIEW                                    | V_TDOMAINE            |     26 |      1 |    10   (0)|      0 |00:00:00.01 |        0 |      0 |
|  96 |                  UNION ALL PUSHED PREDICATE             |                       |     26 |        |            |      0 |00:00:00.01 |        0 |      0 |
|* 97 |                   FILTER                                |                       |     26 |        |            |      0 |00:00:00.01 |        0 |      0 |
|  98 |                    TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE             |     26 |      1 |     1   (0)|      0 |00:00:00.01 |        0 |      0 |
|* 99 |                     INDEX RANGE SCAN                    | DOM_TYPABREV          |     26 |      2 |     1   (0)|      0 |00:00:00.01 |        0 |      0 |
|*100 |                   FILTER                                |                       |     26 |        |            |      0 |00:00:00.01 |        0 |      0 |
| 101 |                    TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |        0 |      0 |
|*102 |                     INDEX RANGE SCAN                    | DOM_TYPABREV          |      0 |      2 |     1   (0)|      0 |00:00:00.01 |        0 |      0 |
|*103 |                   FILTER                                |                       |     26 |        |            |      0 |00:00:00.01 |        0 |      0 |
| 104 |                    TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |        0 |      0 |
|*105 |                     INDEX RANGE SCAN                    | DOM_TYPABREV          |      0 |      2 |     1   (0)|      0 |00:00:00.01 |        0 |      0 |
|*106 |                   FILTER                                |                       |     26 |        |            |      0 |00:00:00.01 |        0 |      0 |
| 107 |                    TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |        0 |      0 |
|*108 |                     INDEX RANGE SCAN                    | DOM_TYPABREV          |      0 |      2 |     1   (0)|      0 |00:00:00.01 |        0 |      0 |
|*109 |                   FILTER                                |                       |     26 |        |            |      0 |00:00:00.01 |        0 |      0 |
| 110 |                    TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |        0 |      0 |
|*111 |                     INDEX RANGE SCAN                    | DOM_TYPABREV          |      0 |      2 |     1   (0)|      0 |00:00:00.01 |        0 |      0 |
|*112 |                   FILTER                                |                       |     26 |        |            |      0 |00:00:00.01 |        0 |      0 |
| 113 |                    TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |        0 |      0 |
|*114 |                     INDEX RANGE SCAN                    | DOM_TYPABREV          |      0 |      2 |     1   (0)|      0 |00:00:00.01 |        0 |      0 |
|*115 |                   FILTER                                |                       |     26 |        |            |      0 |00:00:00.01 |        0 |      0 |
| 116 |                    TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |        0 |      0 |
|*117 |                     INDEX RANGE SCAN                    | DOM_TYPABREV          |      0 |      2 |     1   (0)|      0 |00:00:00.01 |        0 |      0 |
|*118 |                   FILTER                                |                       |     26 |        |            |      0 |00:00:00.01 |        0 |      0 |
| 119 |                    TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |        0 |      0 |
|*120 |                     INDEX RANGE SCAN                    | DOM_TYPABREV          |      0 |      2 |     1   (0)|      0 |00:00:00.01 |        0 |      0 |
|*121 |                   FILTER                                |                       |     26 |        |            |      0 |00:00:00.01 |        0 |      0 |
| 122 |                    TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |        0 |      0 |
|*123 |                     INDEX RANGE SCAN                    | DOM_TYPABREV          |      0 |      2 |     1   (0)|      0 |00:00:00.01 |        0 |      0 |
|*124 |                   FILTER                                |                       |     26 |        |            |      0 |00:00:00.01 |        0 |      0 |
| 125 |                    TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |        0 |      0 |
|*126 |                     INDEX RANGE SCAN                    | DOM_TYPABREV          |      0 |      2 |     1   (0)|      0 |00:00:00.01 |        0 |      0 |
|*127 |                TABLE ACCESS BY INDEX ROWID BATCHED      | V_EXTR_DOM            |     26 |      1 |     1   (0)|      6 |00:00:00.01 |        9 |      0 |
|*128 |                 INDEX RANGE SCAN                        | TYPEABREV             |     26 |      2 |     1   (0)|     20 |00:00:00.01 |        8 |      0 |
|*129 |               TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE             |      6 |      1 |     1   (0)|      6 |00:00:00.01 |       10 |      0 |
|*130 |                INDEX RANGE SCAN                         | DOM_TYPVAL            |      6 |      3 |     1   (0)|      6 |00:00:00.01 |        9 |      0 |
|*131 |                TABLE ACCESS FULL                        | G_ETUDE               |      0 |      1 |     2   (0)|      0 |00:00:00.01 |        0 |      0 |
|*132 |              INDEX RANGE SCAN                           | PIE_REFDOSS           |      6 |      1 |     1   (0)|      6 |00:00:00.01 |       14 |      3 |
|*133 |             INDEX RANGE SCAN                            | INT_REFDOSS           |      6 |      1 |     1   (0)|      6 |00:00:00.01 |       20 |      0 |
|*134 |            INDEX UNIQUE SCAN                            | IND_REFINDIV          |      6 |      1 |     1   (0)|      6 |00:00:00.01 |       13 |      0 |
| 135 |           VIEW PUSHED PREDICATE                         |                       |      6 |      1 |     2   (0)|      0 |00:00:00.01 |       12 |      0 |
| 136 |            NESTED LOOPS                                 |                       |      6 |      1 |     2   (0)|      0 |00:00:00.01 |       12 |      0 |
| 137 |             NESTED LOOPS                                |                       |      6 |      1 |     2   (0)|      0 |00:00:00.01 |       12 |      0 |
| 138 |              TABLE ACCESS BY INDEX ROWID BATCHED        | G_PIECE               |      6 |      1 |     1   (0)|      0 |00:00:00.01 |       12 |      0 |
|*139 |               INDEX RANGE SCAN                          | PIE_REFDOSS           |      6 |      1 |     1   (0)|      0 |00:00:00.01 |       12 |      0 |
|*140 |              INDEX RANGE SCAN                           | G_PIECEDET_REFP       |      0 |      1 |     1   (0)|      0 |00:00:00.01 |        0 |      0 |
|*141 |             TABLE ACCESS BY INDEX ROWID                 | G_PIECEDET            |      0 |      1 |     1   (0)|      0 |00:00:00.01 |        0 |      0 |
| 142 |          VIEW                                           | V_TDOMAINE            |      6 |      1 |    10   (0)|      6 |00:00:00.01 |       22 |      0 |
| 143 |           UNION ALL PUSHED PREDICATE                    |                       |      6 |        |            |      6 |00:00:00.01 |       22 |      0 |
|*144 |            FILTER                                       |                       |      6 |        |            |      6 |00:00:00.01 |       22 |      0 |
| 145 |             TABLE ACCESS BY INDEX ROWID BATCHED         | V_DOMAINE             |      6 |      1 |     1   (0)|      6 |00:00:00.01 |       22 |      0 |
|*146 |              INDEX RANGE SCAN                           | DOM_TYPABREV          |      6 |      2 |     1   (0)|      6 |00:00:00.01 |       16 |      0 |
|*147 |            FILTER                                       |                       |      6 |        |            |      0 |00:00:00.01 |        0 |      0 |
| 148 |             TABLE ACCESS BY INDEX ROWID BATCHED         | V_DOMAINE             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |        0 |      0 |
|*149 |              INDEX RANGE SCAN                           | DOM_TYPABREV          |      0 |      2 |     1   (0)|      0 |00:00:00.01 |        0 |      0 |
|*150 |            FILTER                                       |                       |      6 |        |            |      0 |00:00:00.01 |        0 |      0 |
| 151 |             TABLE ACCESS BY INDEX ROWID BATCHED         | V_DOMAINE             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |        0 |      0 |
|*152 |              INDEX RANGE SCAN                           | DOM_TYPABREV          |      0 |      2 |     1   (0)|      0 |00:00:00.01 |        0 |      0 |
|*153 |            FILTER                                       |                       |      6 |        |            |      0 |00:00:00.01 |        0 |      0 |
| 154 |             TABLE ACCESS BY INDEX ROWID BATCHED         | V_DOMAINE             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |        0 |      0 |
|*155 |              INDEX RANGE SCAN                           | DOM_TYPABREV          |      0 |      2 |     1   (0)|      0 |00:00:00.01 |        0 |      0 |
|*156 |            FILTER                                       |                       |      6 |        |            |      0 |00:00:00.01 |        0 |      0 |
| 157 |             TABLE ACCESS BY INDEX ROWID BATCHED         | V_DOMAINE             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |        0 |      0 |
|*158 |              INDEX RANGE SCAN                           | DOM_TYPABREV          |      0 |      2 |     1   (0)|      0 |00:00:00.01 |        0 |      0 |
|*159 |            FILTER                                       |                       |      6 |        |            |      0 |00:00:00.01 |        0 |      0 |
| 160 |             TABLE ACCESS BY INDEX ROWID BATCHED         | V_DOMAINE             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |        0 |      0 |
|*161 |              INDEX RANGE SCAN                           | DOM_TYPABREV          |      0 |      2 |     1   (0)|      0 |00:00:00.01 |        0 |      0 |
|*162 |            FILTER                                       |                       |      6 |        |            |      0 |00:00:00.01 |        0 |      0 |
| 163 |             TABLE ACCESS BY INDEX ROWID BATCHED         | V_DOMAINE             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |        0 |      0 |
|*164 |              INDEX RANGE SCAN                           | DOM_TYPABREV          |      0 |      2 |     1   (0)|      0 |00:00:00.01 |        0 |      0 |
|*165 |            FILTER                                       |                       |      6 |        |            |      0 |00:00:00.01 |        0 |      0 |
| 166 |             TABLE ACCESS BY INDEX ROWID BATCHED         | V_DOMAINE             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |        0 |      0 |
|*167 |              INDEX RANGE SCAN                           | DOM_TYPABREV          |      0 |      2 |     1   (0)|      0 |00:00:00.01 |        0 |      0 |
|*168 |            FILTER                                       |                       |      6 |        |            |      0 |00:00:00.01 |        0 |      0 |
| 169 |             TABLE ACCESS BY INDEX ROWID BATCHED         | V_DOMAINE             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |        0 |      0 |
|*170 |              INDEX RANGE SCAN                           | DOM_TYPABREV          |      0 |      2 |     1   (0)|      0 |00:00:00.01 |        0 |      0 |
|*171 |            FILTER                                       |                       |      6 |        |            |      0 |00:00:00.01 |        0 |      0 |
| 172 |             TABLE ACCESS BY INDEX ROWID BATCHED         | V_DOMAINE             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |        0 |      0 |
|*173 |              INDEX RANGE SCAN                           | DOM_TYPABREV          |      0 |      2 |     1   (0)|      0 |00:00:00.01 |        0 |      0 |
| 174 |         VIEW                                            | V_TDOMAINE            |      6 |      1 |    10   (0)|    782 |00:00:00.01 |       19 |      0 |
| 175 |          UNION ALL PUSHED PREDICATE                     |                       |      6 |        |            |    782 |00:00:00.01 |       19 |      0 |
|*176 |           FILTER                                        |                       |      6 |        |            |    782 |00:00:00.01 |       19 |      0 |
|*177 |            INDEX RANGE SCAN                             | DOM_TYPVAL            |      6 |      2 |     1   (0)|    782 |00:00:00.01 |       19 |      0 |
|*178 |           FILTER                                        |                       |      6 |        |            |      0 |00:00:00.01 |        0 |      0 |
|*179 |            INDEX RANGE SCAN                             | DOM_TYPVAL            |      0 |      2 |     1   (0)|      0 |00:00:00.01 |        0 |      0 |
|*180 |           FILTER                                        |                       |      6 |        |            |      0 |00:00:00.01 |        0 |      0 |
|*181 |            INDEX RANGE SCAN                             | DOM_TYPVAL            |      0 |      2 |     1   (0)|      0 |00:00:00.01 |        0 |      0 |
|*182 |           FILTER                                        |                       |      6 |        |            |      0 |00:00:00.01 |        0 |      0 |
|*183 |            INDEX RANGE SCAN                             | DOM_TYPVAL            |      0 |      2 |     1   (0)|      0 |00:00:00.01 |        0 |      0 |
|*184 |           FILTER                                        |                       |      6 |        |            |      0 |00:00:00.01 |        0 |      0 |
|*185 |            INDEX RANGE SCAN                             | DOM_TYPVAL            |      0 |      2 |     1   (0)|      0 |00:00:00.01 |        0 |      0 |
|*186 |           FILTER                                        |                       |      6 |        |            |      0 |00:00:00.01 |        0 |      0 |
|*187 |            INDEX RANGE SCAN                             | DOM_TYPVAL            |      0 |      2 |     1   (0)|      0 |00:00:00.01 |        0 |      0 |
|*188 |           FILTER                                        |                       |      6 |        |            |      0 |00:00:00.01 |        0 |      0 |
|*189 |            INDEX RANGE SCAN                             | DOM_TYPVAL            |      0 |      2 |     1   (0)|      0 |00:00:00.01 |        0 |      0 |
|*190 |           FILTER                                        |                       |      6 |        |            |      0 |00:00:00.01 |        0 |      0 |
|*191 |            INDEX RANGE SCAN                             | DOM_TYPVAL            |      0 |      2 |     1   (0)|      0 |00:00:00.01 |        0 |      0 |
|*192 |           FILTER                                        |                       |      6 |        |            |      0 |00:00:00.01 |        0 |      0 |
|*193 |            INDEX RANGE SCAN                             | DOM_TYPVAL            |      0 |      2 |     1   (0)|      0 |00:00:00.01 |        0 |      0 |
|*194 |           FILTER                                        |                       |      6 |        |            |      0 |00:00:00.01 |        0 |      0 |
|*195 |            INDEX RANGE SCAN                             | DOM_TYPVAL            |      0 |      2 |     1   (0)|      0 |00:00:00.01 |        0 |      0 |
| 196 |        TABLE ACCESS BY INDEX ROWID                      | G_DOSSIER             |      1 |      1 |     1   (0)|      1 |00:00:00.01 |        6 |      0 |
|*197 |         INDEX UNIQUE SCAN                               | DOS_REFDOSS           |      1 |      1 |     1   (0)|      1 |00:00:00.01 |        3 |      0 |
| 198 |        TABLE ACCESS BY INDEX ROWID                      | G_DOSSIER             |      2 |      1 |     1   (0)|      2 |00:00:00.01 |       10 |      0 |
|*199 |         INDEX UNIQUE SCAN                               | DOS_REFDOSS           |      2 |      1 |     1   (0)|      2 |00:00:00.01 |        6 |      0 |
-----------------------------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   1 - filter(ROWNUM=1)
   2 - filter("DTFIN_DT" IS NULL)
   3 - access("REFDOSS"=:B1)
   4 - filter(ROWNUM=1)
   7 - filter("AUTH"."VALEUR_2" IS NOT NULL)
   8 - access("AUTH"."TYPE"='EXTR_GEST_CLIENT' AND "AUTH"."ABREV"=TO_CHAR(:B1))
   9 - access("TI"."REFDOSS"=:B1 AND "TI"."REFTYPE"="AUTH"."VALEUR_2" AND "TI"."REFINDIVIDU"="AUTH"."VALEUR")
  10 - filter("TI"."REFDOSSEXT" IS NOT NULL)
  12 - access("IMX_UN_ID"=)
  17 - filter(("DECOMPTE"."REFDOSS"=:B1 AND "DECOMPTE"."CATEGDOSS" LIKE 'DECOMPTE%'))
  18 - filter("DECOMPTE"."REFLOT" IS NOT NULL)
  20 - access("DECOMPTE"."REFLOT"="CONTR"."REFDOSS")
  21 - access("REFINDIVIDU"=:B1)
  22 - filter(("REFEXT3" IS NOT NULL AND "REFEXT3"="CONTR"."ANCREFDOSS" AND "REFEXT2"=:B1 AND "SOCIETE"='CLIENT_NUMBER'))
  24 - access("VALEUR"= AND "TYPE"='typencour')
  27 - access("TA"."REFENTITE"=:B1)
  28 - filter(ROWNUM=1)
  29 - access("SR"."REFDOSS"=:B1)
       filter(("SR"."REFTYPE"<>'DB' AND "SR"."REFTYPE"<>'CL' AND "SR"."REFTYPE"<>'XX'))
  30 - filter(ROWNUM=1)
  32 - filter("G"."CATEGDOSS" LIKE 'COLLECTION%')
  33 - access("G"."REFDOSS"=:B1)
  35 - access("PIECE"."REFDOSS"=:B1 AND "PIECE"."TYPPIECE"='DBT_VERIF_REQ')
  36 - filter("RECORD_NO">=:B5)
  37 - filter(ROWNUM<=:B4)
  39 - filter(ROWNUM<=:B4)
  41 - filter((DECODE("D"."REFHIERARCHIE",NULL,'N',)='N' AND DECODE("D"."REFHIERARCHIE2",NULL,'N',)='N'))
  52 - access("VD_PIECEINIT"."VALEUR"="D"."PIECEINIT")
  55 - filter('AN'=:B2)
  57 - access("CHAMP"='pieceinit')
  58 - filter('CS'=:B2)
  60 - access("CHAMP"='pieceinit')
  61 - filter('FR'=:B2)
  63 - access("CHAMP"='pieceinit')
  64 - filter('HU'=:B2)
  66 - access("CHAMP"='pieceinit')
  67 - filter('NL'=:B2)
  69 - access("CHAMP"='pieceinit')
  70 - filter('PL'=:B2)
  72 - access("CHAMP"='pieceinit')
  73 - filter('RU'=:B2)
  75 - access("CHAMP"='pieceinit')
  76 - filter('SK'=:B2)
  78 - access("CHAMP"='pieceinit')
  79 - filter('VI'=:B2)
  81 - access("CHAMP"='pieceinit')
  82 - filter('ZH'=:B2)
  84 - access("CHAMP"='pieceinit')
  89 - access("I"."NUMSS" LIKE UPPER(:B3))
       filter("I"."NUMSS" LIKE UPPER(:B3))
  90 - access("T"."REFINDIVIDU"="I"."REFINDIVIDU" AND "T"."REFTYPE"='DB')
  91 - filter(("D"."CATEGDOSS"<>'COMPTE DB CTR' AND NVL("D"."FG_EXCL_FROM_EXTR",'N')<>'O' AND NVL("FG_FRM_INC",'N')<>'O'))
  92 - access("D"."REFDOSS"="T"."REFDOSS")
       filter("D"."REFDOSS" NOT LIKE 'GL%')
  93 - access("D"."REFDOSS"="T_INT"."REFDOSS")
  94 - access("LST"."REFDOSS"="D"."REFDOSS")
  95 - filter("VD_DIV"."ECRAN"="I"."PAYS")
  97 - filter('AN'=:B2)
  99 - access("TYPE"='DIVISION TERRITORIALE' AND "ABREV"="I"."DIVISION")
100 - filter('CS'=:B2)
102 - access("TYPE"='DIVISION TERRITORIALE' AND "ABREV"="I"."DIVISION")
103 - filter('FR'=:B2)
105 - access("TYPE"='DIVISION TERRITORIALE' AND "ABREV"="I"."DIVISION")
106 - filter('HU'=:B2)
108 - access("TYPE"='DIVISION TERRITORIALE' AND "ABREV"="I"."DIVISION")
109 - filter('NL'=:B2)
111 - access("TYPE"='DIVISION TERRITORIALE' AND "ABREV"="I"."DIVISION")
112 - filter('PL'=:B2)
114 - access("TYPE"='DIVISION TERRITORIALE' AND "ABREV"="I"."DIVISION")
115 - filter('RU'=:B2)
117 - access("TYPE"='DIVISION TERRITORIALE' AND "ABREV"="I"."DIVISION")
118 - filter('SK'=:B2)
120 - access("TYPE"='DIVISION TERRITORIALE' AND "ABREV"="I"."DIVISION")
121 - filter('VI'=:B2)
123 - access("TYPE"='DIVISION TERRITORIALE' AND "ABREV"="I"."DIVISION")
124 - filter('ZH'=:B2)
126 - access("TYPE"='DIVISION TERRITORIALE' AND "ABREV"="I"."DIVISION")
127 - filter(("T_INT"."REFTYPE"="AUTH"."VALEUR_2" AND "AUTH"."VALEUR_2" IS NOT NULL))
128 - access("AUTH"."TYPE"='EXTR_GEST_CLIENT' AND "AUTH"."ABREV"=TO_CHAR(:B1) AND "T_INT"."REFINDIVIDU"="AUTH"."VALEUR")
129 - filter(("ECRAN"='X' OR  IS NOT NULL))
130 - access("D"."CATEGDOSS"="VALEUR" AND "TYPE"='categdoss')
       filter("VALEUR"<>'COMPTE DB CTR')
131 - filter(("ACTIVITE_GPC"='G' OR "ACTIVITE_GPC"='T'))
132 - access("PIECECASE"."REFDOSS"="D"."REFDOSS" AND "PIECECASE"."TYPPIECE"="D"."PIECEINIT")
133 - access("D"."REFDOSS"="CLIENT"."REFDOSS")
       filter(("CLIENT"."REFTYPE"='CL' OR "CLIENT"."REFTYPE"='TC'))
134 - access("ICL"."REFINDIVIDU"="CLIENT"."REFINDIVIDU")
139 - access("P"."REFDOSS"="D"."REFHIERARCHIE" AND "P"."TYPPIECE"='CONTRAT')
140 - access("PD"."REFPIECE"="P"."REFPIECE" AND "PD"."TYPE"='CI CONTRACTS')
141 - filter("PD"."FG01"='O')
144 - filter('AN'=:B2)
146 - access("TYPE"='pays' AND "ABREV"="I"."PAYS")
147 - filter('CS'=:B2)
149 - access("TYPE"='pays' AND "ABREV"="I"."PAYS")
150 - filter('FR'=:B2)
152 - access("TYPE"='pays' AND "ABREV"="I"."PAYS")
153 - filter('HU'=:B2)
155 - access("TYPE"='pays' AND "ABREV"="I"."PAYS")
156 - filter('NL'=:B2)
158 - access("TYPE"='pays' AND "ABREV"="I"."PAYS")
159 - filter('PL'=:B2)
161 - access("TYPE"='pays' AND "ABREV"="I"."PAYS")
162 - filter('RU'=:B2)
164 - access("TYPE"='pays' AND "ABREV"="I"."PAYS")
165 - filter('SK'=:B2)
167 - access("TYPE"='pays' AND "ABREV"="I"."PAYS")
168 - filter('VI'=:B2)
170 - access("TYPE"='pays' AND "ABREV"="I"."PAYS")
171 - filter('ZH'=:B2)
173 - access("TYPE"='pays' AND "ABREV"="I"."PAYS")
176 - filter(("D"."CATEGDOSS"<>'COMPTE DB CTR' AND 'AN'=:B2))
177 - access("VALEUR"="D"."CATEGDOSS")
       filter("VALEUR"<>'COMPTE DB CTR')
178 - filter(("D"."CATEGDOSS"<>'COMPTE DB CTR' AND 'CS'=:B2))
179 - access("VALEUR"="D"."CATEGDOSS")
       filter("VALEUR"<>'COMPTE DB CTR')
180 - filter(("D"."CATEGDOSS"<>'COMPTE DB CTR' AND 'FR'=:B2))
181 - access("VALEUR"="D"."CATEGDOSS")
       filter("VALEUR"<>'COMPTE DB CTR')
182 - filter(("D"."CATEGDOSS"<>'COMPTE DB CTR' AND 'HU'=:B2))
183 - access("VALEUR"="D"."CATEGDOSS")
       filter("VALEUR"<>'COMPTE DB CTR')
184 - filter(("D"."CATEGDOSS"<>'COMPTE DB CTR' AND 'NL'=:B2))
185 - access("VALEUR"="D"."CATEGDOSS")
       filter("VALEUR"<>'COMPTE DB CTR')
186 - filter(("D"."CATEGDOSS"<>'COMPTE DB CTR' AND 'PL'=:B2))
187 - access("VALEUR"="D"."CATEGDOSS")
       filter("VALEUR"<>'COMPTE DB CTR')
188 - filter(("D"."CATEGDOSS"<>'COMPTE DB CTR' AND 'RU'=:B2))
189 - access("VALEUR"="D"."CATEGDOSS")
       filter("VALEUR"<>'COMPTE DB CTR')
190 - filter(("D"."CATEGDOSS"<>'COMPTE DB CTR' AND 'SK'=:B2))
191 - access("VALEUR"="D"."CATEGDOSS")
       filter("VALEUR"<>'COMPTE DB CTR')
192 - filter(("D"."CATEGDOSS"<>'COMPTE DB CTR' AND 'VI'=:B2))
193 - access("VALEUR"="D"."CATEGDOSS")
       filter("VALEUR"<>'COMPTE DB CTR')
194 - filter(("D"."CATEGDOSS"<>'COMPTE DB CTR' AND 'ZH'=:B2))
195 - access("VALEUR"="D"."CATEGDOSS")
       filter("VALEUR"<>'COMPTE DB CTR')
197 - access("REFDOSS"=:B1)
199 - access("REFDOSS"=:B1)
*/
/********************************New Metrics***************************************/

/********************************Index statistics**********************************/

/********************************Other SQLs****************************************/          
/*

*/ 
/********************************Other SQLs****************************************/              
