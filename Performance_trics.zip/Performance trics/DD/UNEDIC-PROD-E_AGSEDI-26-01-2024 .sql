/********************************************************************************
*********       E-mail subject: UDCWEB-1746
*********             Instance: PROD
*********          Description: 
Problem:
Slow query was provided from E_AGSEDI screen from UNEDIC PROD.

Analysis:
It looks like there is a mistake in the SQL text and instead of joining table�g_piece with table�g_dossier it joins table�g_dossier 
with table�g_dossier and table�g_piece remains unjoined, which from performance point of view leads to selecting to a lot of data and bad execution plan.


Suggestion:
Please change�D.refdoss = D.refdoss to�P.refdoss = D.refdoss as it is shown in the New SQL section below.

*********               SQL_ID: 
*********      Program/Package: E_AGSEDI 
*********              Request: Yancho Yanchev 
*********               Author: Dimitar Dimitrov
********* Received e-mail date: 26/01/2024
*********      Resolution date: 26/01/2024
*********  Trace old file here: \\epox\specifs\performance\tmp\
*********  Trace new file here:
***********************************************************************************/

/********************************OLD SQL*******************************************/
var B1 VARCHAR2(128);
exec :B1 := '814%';
var B2 VARCHAR2(128);
exec :B2 := '2023-11-23';
var B3 VARCHAR2(128);
exec :B3 := '2024-01-24';
var B4 NUMBER;
exec :B4 := 2001;
var B5 NUMBER;
exec :B5 := 1;
 
 
 SELECT *
  FROM (SELECT /*+ first_rows(2001)*/
         foo.*, ROWNUM rnum
          FROM (SELECT recycleLock      recycleLock,
                       fichier          fileName,
                       siren            siren,
                       dt_file_creat_dt receptionDate,
                       dt_file_proc_dt  dt_file_proc_dt,
                       id_enr1          lineId1,
                       id_enr2          lineId2,
                       erreur           error,
                       no_chrono_av     historyNo,
                       ancrefdoss       noAgs,
                       code_mj_origine  codeMj,
                       caseRef          caseRef,
                       rai_soc          socialReason,
                       file_id          fileId,
                       status           status
                  FROM (SELECT F.dt_file_creat_dt,
                               F.dt_file_proc_dt,
                               B.rai_soc,
                               B.siren,
                               A.code_mj_origine,
                               CASE
                                 WHEN B.erreur IS NULL THEN
                                  (SELECT erreur
                                     FROM t_err_avance ta
                                    WHERE (file_id = F.file_id OR
                                          id_enr1 = B.id_enr1)
                                      AND erreur IS NOT NULL)
                                 ELSE
                                  B.erreur
                               END AS erreur,
                               CASE
                                 WHEN B.id_enr2 IS NULL THEN
                                  (SELECT LTRIM(RTRIM(no_chrono_av)) no_chrono_av
                                     FROM t_err_avance
                                    WHERE id_enr1 = B.id_enr1)
                                 ELSE
                                  B.no_chrono_av
                               END AS no_chrono_av,
                               T.fichier,
                               B.id_enr1,
                               B.id_enr2,
                               F.file_id,
                               B.cgea,
                               F.status status,
                               F.recycle_lock recycleLock,
                               CASE
                                 WHEN (SELECT count(1)
                                         FROM t_intervenants T,
                                              g_individu     I,
                                              g_dossier      D
                                        WHERE T.reftype = 'DB'
                                          AND I.refindividu = T.refindividu
                                          AND I.siret = B.siren
                                          AND D.refdoss = T.refdoss
                                          AND D.refspe = 'AFFAIRE') <= 1 THEN
                                  (SELECT D.ancrefdoss
                                     FROM t_intervenants T,
                                          g_individu     I,
                                          g_dossier      D
                                    WHERE T.reftype = 'DB'
                                      AND I.refindividu = T.refindividu
                                      AND I.siret = B.siren
                                      AND D.refdoss = T.refdoss
                                      AND D.refspe = 'AFFAIRE')
                                 ELSE
                                  (SELECT D.ancrefdoss
                                     FROM t_intervenants T,
                                          g_individu     I,
                                          g_dossier      D,
                                          t_err_avance   EA,
                                          g_piece        P
                                    WHERE T.reftype = 'DB'
                                      AND I.refindividu = T.refindividu
                                      AND I.siret = B.siren
                                      AND D.refdoss = T.refdoss
                                      AND D.refspe = 'AFFAIRE'
                                      AND EA.id_enr1 = B.id_enr1
                                      AND P.typpiece = 'PROCEDURE'
                                      AND P.gpitypjug IN
                                          (SELECT abrev
                                             FROM v_domaine
                                            WHERE TYPE = 'TYPEJUGT'
                                              AND contexte = 'O')
                                      AND D.refdoss = D.refdoss
                                      AND EA.dt_pc1_dt =
                                          TO_CHAR(P.gpidtdeb_dt, 'RRRRMMDD')
                                    ORDER BY P.nbpage FETCH FIRST 1 ROWS ONLY)
                               END AS ancrefdoss,
                               CASE
                                 WHEN (SELECT count(1)
                                         FROM t_intervenants T,
                                              g_individu     I,
                                              g_dossier      D
                                        WHERE T.reftype = 'DB'
                                          AND I.refindividu = T.refindividu
                                          AND I.siret = B.siren
                                          AND D.refdoss = T.refdoss
                                          AND D.refspe = 'AFFAIRE') <= 1 THEN
                                  (SELECT D.refdoss
                                     FROM t_intervenants T,
                                          g_individu     I,
                                          g_dossier      D
                                    WHERE T.reftype = 'DB'
                                      AND I.refindividu = T.refindividu
                                      AND I.siret = B.siren
                                      AND D.refdoss = T.refdoss
                                      AND D.refspe = 'AFFAIRE')
                                 ELSE
                                  (SELECT D.refdoss
                                     FROM t_intervenants T,
                                          g_individu     I,
                                          g_dossier      D,
                                          t_err_avance   EA,
                                          g_piece        P
                                    WHERE T.reftype = 'DB'
                                      AND I.refindividu = T.refindividu
                                      AND I.siret = B.siren
                                      AND D.refdoss = T.refdoss
                                      AND D.refspe = 'AFFAIRE'
                                      AND EA.id_enr1 = B.id_enr1
                                      AND P.typpiece = 'PROCEDURE'
                                      AND P.gpitypjug IN
                                          (SELECT abrev
                                             FROM v_domaine
                                            WHERE TYPE = 'TYPEJUGT'
                                              AND contexte = 'O')
                                      AND D.refdoss = D.refdoss
                                      AND EA.dt_pc1_dt =
                                          TO_CHAR(P.gpidtdeb_dt, 'RRRRMMDD')
                                    ORDER BY P.nbpage FETCH FIRST 1 ROWS ONLY)
                               END AS caseRef
                          FROM t_err_file F,
                               t_log T,
                               (SELECT file_id,
                                       MIN(CODE_MJ_ORIGINE) CODE_MJ_ORIGINE
                                  FROM (SELECT file_id, CODE_MJ_ORIGINE
                                          FROM t_err_avance
                                        UNION
                                        SELECT af.file_id, av.CODE_MJ_ORIGINE
                                          FROM t_err_affaire af, t_err_avance av
                                         WHERE af.id_enr1 = av.id_enr1)
                                 GROUP BY file_id) A,
                               (SELECT erreur,
                                       file_id,
                                       id_enr1,
                                       NULL AS id_enr2,
                                       LTRIM(RTRIM(cgea)) cgea,
                                       LTRIM(RTRIM(no_chrono_av)) no_chrono_av,
                                       LTRIM(RTRIM(rai_soc)) rai_soc,
                                       LTRIM(RTRIM(siren)) siren,
                                       champ,
                                       LTRIM(RTRIM(code_orig_ags)) code_orig_ags
                                  FROM t_err_affaire
                                UNION
                                SELECT erreur,
                                       file_id,
                                       id_enr1,
                                       id_enr2,
                                       LTRIM(RTRIM(cgea)) cgea,
                                       LTRIM(RTRIM(no_chrono_av)) no_chrono_av,
                                       LTRIM(RTRIM(rai_soc)) rai_soc,
                                       LTRIM(RTRIM(siren)) siren,
                                       champ,
                                       LTRIM(RTRIM(code_orig_ags)) code_orig_ags
                                  FROM t_err_avance) B
                         WHERE 1 = 1
                           AND T.id = F.log_id
                           AND NVL(F.status, 'DONE') IN ('DONE', 'CHANGED')
                           AND A.file_id = F.file_id
                           AND T.emetteur LIKE :B1
                           AND TO_CHAR(NVL(F.dt_file_creat_dt, SYSDATE), 'j') BETWEEN
                               TO_CHAR(TO_DATE(:B2, 'YYYY-MM-DD'), 'j') AND TO_CHAR(TO_DATE(:B3, 'YYYY-MM-DD'), 'j')
                           AND B.file_id = F.file_id)
                 WHERE 1 = 1
                 ORDER BY DECODE(dt_file_proc_dt,
                                 NULL,
                                 DECODE(recycleLock, 'O', 1, 0),
                                 1),
                          receptionDate desc) foo
         WHERE ROWNUM <= :B4)
 WHERE 1 = 1
   AND rnum >= :B5;
/********************************OLD SQL*******************************************/
/********************************OLD Metrics***************************************/
/*
Plan hash value: 588630762
--------------------------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                          | Name                    | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  |
--------------------------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                                   |                         |      1 |        |  3362 (100)|     62 |00:01:22.72 |    1215K|  10219 |
|*  1 |  TABLE ACCESS BY INDEX ROWID BATCHED               | T_ERR_AVANCE            |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|   2 |   BITMAP CONVERSION TO ROWIDS                      |                         |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|   3 |    BITMAP OR                                       |                         |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|   4 |     BITMAP CONVERSION FROM ROWIDS                  |                         |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*  5 |      INDEX RANGE SCAN                              | IX_ERR_AV_FILE_ID       |      0 |        |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|   6 |     BITMAP CONVERSION FROM ROWIDS                  |                         |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*  7 |      INDEX RANGE SCAN                              | IX_ERR_AV_ID_ENR1       |      0 |        |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|   8 |  TABLE ACCESS BY INDEX ROWID BATCHED               | T_ERR_AVANCE            |     31 |      1 |     1   (0)|     31 |00:00:00.01 |      38 |      0 |
|*  9 |   INDEX RANGE SCAN                                 | IX_ERR_AV_ID_ENR1       |     31 |      1 |     1   (0)|     31 |00:00:00.01 |       9 |      0 |
|  10 |  SORT AGGREGATE                                    |                         |     30 |      1 |            |     30 |00:00:00.07 |     383 |    126 |
|  11 |   NESTED LOOPS                                     |                         |     30 |      1 |     3   (0)|     36 |00:00:00.07 |     383 |    126 |
|  12 |    NESTED LOOPS                                    |                         |     30 |      1 |     3   (0)|     65 |00:00:00.05 |     319 |     84 |
|  13 |     NESTED LOOPS                                   |                         |     30 |      1 |     2   (0)|     65 |00:00:00.04 |     186 |     66 |
|  14 |      TABLE ACCESS BY INDEX ROWID BATCHED           | G_INDIVIDU              |     30 |      1 |     1   (0)|     30 |00:00:00.02 |      93 |     38 |
|* 15 |       INDEX RANGE SCAN                             | GINDSIRET               |     30 |      1 |     1   (0)|     30 |00:00:00.02 |      63 |     28 |
|* 16 |      INDEX RANGE SCAN                              | INT_INDIV               |     30 |      1 |     1   (0)|     65 |00:00:00.02 |      93 |     28 |
|* 17 |     INDEX RANGE SCAN                               | DOS_REFDOSS             |     65 |      1 |     1   (0)|     65 |00:00:00.01 |     133 |     18 |
|* 18 |    TABLE ACCESS BY INDEX ROWID                     | G_DOSSIER               |     65 |      1 |     1   (0)|     36 |00:00:00.02 |      64 |     42 |
|  19 |     NESTED LOOPS                                   |                         |     25 |      1 |     3   (0)|     25 |00:00:00.01 |     282 |      0 |
|  20 |      NESTED LOOPS                                  |                         |     25 |      1 |     3   (0)|     41 |00:00:00.01 |     241 |      0 |
|  21 |       NESTED LOOPS                                 |                         |     25 |      1 |     2   (0)|     41 |00:00:00.01 |     156 |      0 |
|  22 |        TABLE ACCESS BY INDEX ROWID BATCHED         | G_INDIVIDU              |     25 |      1 |     1   (0)|     25 |00:00:00.01 |      78 |      0 |
|* 23 |         INDEX RANGE SCAN                           | GINDSIRET               |     25 |      1 |     1   (0)|     25 |00:00:00.01 |      53 |      0 |
|* 24 |        INDEX RANGE SCAN                            | INT_INDIV               |     25 |      1 |     1   (0)|     41 |00:00:00.01 |      78 |      0 |
|* 25 |       INDEX RANGE SCAN                             | DOS_REFDOSS             |     41 |      1 |     1   (0)|     41 |00:00:00.01 |      85 |      0 |
|* 26 |      TABLE ACCESS BY INDEX ROWID                   | G_DOSSIER               |     41 |      1 |     1   (0)|     25 |00:00:00.01 |      41 |      0 |
|* 27 |       VIEW                                         |                         |     11 |      1 |   898   (2)|     10 |00:00:43.43 |     605K|  10018 |
|* 28 |        WINDOW SORT PUSHED RANK                     |                         |     11 |      1 |   898   (2)|     10 |00:00:43.43 |     605K|  10018 |
|  29 |         NESTED LOOPS                               |                         |     11 |      1 |   897   (2)|   1854 |00:00:43.43 |     605K|  10018 |
|  30 |          NESTED LOOPS                              |                         |     11 |      1 |   897   (2)|   3679 |00:00:43.42 |     601K|  10018 |
|  31 |           NESTED LOOPS                             |                         |     11 |      1 |   896   (2)|   3679 |00:00:43.41 |     594K|  10018 |
|  32 |            MERGE JOIN CARTESIAN                    |                         |     11 |      1 |   895   (2)|    839 |00:00:43.41 |     594K|  10018 |
|  33 |             NESTED LOOPS                           |                         |     11 |      1 |   894   (2)|    839 |00:00:43.41 |     594K|  10018 |
|  34 |              MERGE JOIN CARTESIAN                  |                         |     11 |      1 |     2   (0)|     60 |00:00:00.01 |      47 |      0 |
|  35 |               TABLE ACCESS BY INDEX ROWID BATCHED  | T_ERR_AVANCE            |     11 |      2 |     1   (0)|     10 |00:00:00.01 |      18 |      0 |
|* 36 |                INDEX RANGE SCAN                    | IX_ERR_AV_ID_ENR1       |     11 |      1 |     1   (0)|     10 |00:00:00.01 |       9 |      0 |
|  37 |               BUFFER SORT                          |                         |     10 |      1 |     1   (0)|     60 |00:00:00.01 |      29 |      0 |
|  38 |                SORT UNIQUE                         |                         |     10 |      1 |     1   (0)|     60 |00:00:00.01 |      29 |      0 |
|* 39 |                 TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE               |     10 |      1 |     1   (0)|     60 |00:00:00.01 |      29 |      0 |
|* 40 |                  INDEX RANGE SCAN                  | V_DOMAINE_TYPE_CODE_IDX |     10 |     31 |     1   (0)|    210 |00:00:00.01 |       9 |      0 |
|* 41 |              TABLE ACCESS BY INDEX ROWID BATCHED   | G_PIECE                 |     60 |      1 |   892   (2)|    839 |00:00:43.41 |     594K|  10018 |
|* 42 |               INDEX RANGE SCAN                     | GP_ST02_FUNC_IDX        |     60 |    784 |   853   (2)|  12882 |00:00:43.22 |     583K|   9725 |
|  43 |             BUFFER SORT                            |                         |    839 |      1 |     3   (0)|    839 |00:00:00.01 |      27 |      0 |
|  44 |              TABLE ACCESS BY INDEX ROWID BATCHED   | G_INDIVIDU              |     10 |      1 |     1   (0)|     10 |00:00:00.01 |      27 |      0 |
|* 45 |               INDEX RANGE SCAN                     | GINDSIRET               |     10 |      1 |     1   (0)|     10 |00:00:00.01 |      23 |      0 |
|* 46 |            INDEX RANGE SCAN                        | INT_INDIV               |    839 |      1 |     1   (0)|   3679 |00:00:00.01 |      68 |      0 |
|* 47 |           INDEX RANGE SCAN                         | DOS_REFDOSS             |   3679 |      1 |     1   (0)|   3679 |00:00:00.01 |    7361 |      0 |
|* 48 |          TABLE ACCESS BY INDEX ROWID               | G_DOSSIER               |   3679 |      1 |     1   (0)|   1854 |00:00:00.01 |    3503 |      0 |
|  49 |  SORT AGGREGATE                                    |                         |     30 |      1 |            |     30 |00:00:00.01 |     383 |      0 |
|  50 |   NESTED LOOPS                                     |                         |     30 |      1 |     3   (0)|     36 |00:00:00.01 |     383 |      0 |
|  51 |    NESTED LOOPS                                    |                         |     30 |      1 |     3   (0)|     65 |00:00:00.01 |     319 |      0 |
|  52 |     NESTED LOOPS                                   |                         |     30 |      1 |     2   (0)|     65 |00:00:00.01 |     186 |      0 |
|  53 |      TABLE ACCESS BY INDEX ROWID BATCHED           | G_INDIVIDU              |     30 |      1 |     1   (0)|     30 |00:00:00.01 |      93 |      0 |
|* 54 |       INDEX RANGE SCAN                             | GINDSIRET               |     30 |      1 |     1   (0)|     30 |00:00:00.01 |      63 |      0 |
|* 55 |      INDEX RANGE SCAN                              | INT_INDIV               |     30 |      1 |     1   (0)|     65 |00:00:00.01 |      93 |      0 |
|* 56 |     INDEX RANGE SCAN                               | DOS_REFDOSS             |     65 |      1 |     1   (0)|     65 |00:00:00.01 |     133 |      0 |
|* 57 |    TABLE ACCESS BY INDEX ROWID                     | G_DOSSIER               |     65 |      1 |     1   (0)|     36 |00:00:00.01 |      64 |      0 |
|  58 |     NESTED LOOPS                                   |                         |     25 |      1 |     3   (0)|     25 |00:00:00.01 |     282 |      0 |
|  59 |      NESTED LOOPS                                  |                         |     25 |      1 |     3   (0)|     41 |00:00:00.01 |     241 |      0 |
|  60 |       NESTED LOOPS                                 |                         |     25 |      1 |     2   (0)|     41 |00:00:00.01 |     156 |      0 |
|  61 |        TABLE ACCESS BY INDEX ROWID BATCHED         | G_INDIVIDU              |     25 |      1 |     1   (0)|     25 |00:00:00.01 |      78 |      0 |
|* 62 |         INDEX RANGE SCAN                           | GINDSIRET               |     25 |      1 |     1   (0)|     25 |00:00:00.01 |      53 |      0 |
|* 63 |        INDEX RANGE SCAN                            | INT_INDIV               |     25 |      1 |     1   (0)|     41 |00:00:00.01 |      78 |      0 |
|* 64 |       INDEX RANGE SCAN                             | DOS_REFDOSS             |     41 |      1 |     1   (0)|     41 |00:00:00.01 |      85 |      0 |
|* 65 |      TABLE ACCESS BY INDEX ROWID                   | G_DOSSIER               |     41 |      1 |     1   (0)|     25 |00:00:00.01 |      41 |      0 |
|* 66 |       VIEW                                         |                         |     11 |      1 |   898   (2)|     10 |00:00:39.12 |     605K|      0 |
|* 67 |        WINDOW SORT PUSHED RANK                     |                         |     11 |      1 |   898   (2)|     10 |00:00:39.12 |     605K|      0 |
|  68 |         NESTED LOOPS                               |                         |     11 |      1 |   897   (2)|   1854 |00:00:39.12 |     605K|      0 |
|  69 |          NESTED LOOPS                              |                         |     11 |      1 |   897   (2)|   3679 |00:00:39.11 |     601K|      0 |
|  70 |           NESTED LOOPS                             |                         |     11 |      1 |   896   (2)|   3679 |00:00:39.10 |     594K|      0 |
|  71 |            MERGE JOIN CARTESIAN                    |                         |     11 |      1 |   895   (2)|    839 |00:00:39.10 |     594K|      0 |
|  72 |             NESTED LOOPS                           |                         |     11 |      1 |   894   (2)|    839 |00:00:39.10 |     594K|      0 |
|  73 |              MERGE JOIN CARTESIAN                  |                         |     11 |      1 |     2   (0)|     60 |00:00:00.01 |      47 |      0 |
|  74 |               TABLE ACCESS BY INDEX ROWID BATCHED  | T_ERR_AVANCE            |     11 |      2 |     1   (0)|     10 |00:00:00.01 |      18 |      0 |
|* 75 |                INDEX RANGE SCAN                    | IX_ERR_AV_ID_ENR1       |     11 |      1 |     1   (0)|     10 |00:00:00.01 |       9 |      0 |
|  76 |               BUFFER SORT                          |                         |     10 |      1 |     1   (0)|     60 |00:00:00.01 |      29 |      0 |
|  77 |                SORT UNIQUE                         |                         |     10 |      1 |     1   (0)|     60 |00:00:00.01 |      29 |      0 |
|* 78 |                 TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE               |     10 |      1 |     1   (0)|     60 |00:00:00.01 |      29 |      0 |
|* 79 |                  INDEX RANGE SCAN                  | V_DOMAINE_TYPE_CODE_IDX |     10 |     31 |     1   (0)|    210 |00:00:00.01 |       9 |      0 |
|* 80 |              TABLE ACCESS BY INDEX ROWID BATCHED   | G_PIECE                 |     60 |      1 |   892   (2)|    839 |00:00:39.09 |     594K|      0 |
|* 81 |               INDEX RANGE SCAN                     | GP_ST02_FUNC_IDX        |     60 |    784 |   853   (2)|  12882 |00:00:39.06 |     583K|      0 |
|  82 |             BUFFER SORT                            |                         |    839 |      1 |     3   (0)|    839 |00:00:00.01 |      27 |      0 |
|  83 |              TABLE ACCESS BY INDEX ROWID BATCHED   | G_INDIVIDU              |     10 |      1 |     1   (0)|     10 |00:00:00.01 |      27 |      0 |
|* 84 |               INDEX RANGE SCAN                     | GINDSIRET               |     10 |      1 |     1   (0)|     10 |00:00:00.01 |      23 |      0 |
|* 85 |            INDEX RANGE SCAN                        | INT_INDIV               |    839 |      1 |     1   (0)|   3679 |00:00:00.01 |      68 |      0 |
|* 86 |           INDEX RANGE SCAN                         | DOS_REFDOSS             |   3679 |      1 |     1   (0)|   3679 |00:00:00.01 |    7361 |      0 |
|* 87 |          TABLE ACCESS BY INDEX ROWID               | G_DOSSIER               |   3679 |      1 |     1   (0)|   1854 |00:00:00.01 |    3503 |      0 |
|* 88 |  VIEW                                              |                         |      1 |    254 |  3362  (15)|     62 |00:01:22.72 |    1215K|  10219 |
|* 89 |   COUNT STOPKEY                                    |                         |      1 |        |            |     62 |00:01:22.72 |    1215K|  10219 |
|  90 |    VIEW                                            |                         |      1 |    254 |  3362  (15)|     62 |00:01:22.72 |    1215K|  10219 |
|* 91 |     SORT ORDER BY STOPKEY                          |                         |      1 |    254 |  3362  (15)|     62 |00:00:00.09 |    3803 |     75 |
|  92 |      NESTED LOOPS                                  |                         |      1 |    254 |  1289  (37)|     62 |00:00:00.09 |    3803 |     75 |
|  93 |       NESTED LOOPS                                 |                         |      1 |     94 |   819  (24)|     62 |00:00:00.09 |    3563 |     75 |
|  94 |        NESTED LOOPS                                |                         |      1 |     63 |   441   (2)|     62 |00:00:00.06 |    3256 |     22 |
|* 95 |         TABLE ACCESS FULL                          | T_ERR_FILE              |      1 |     63 |   422   (2)|    629 |00:00:00.04 |    1509 |      0 |
|* 96 |         TABLE ACCESS BY INDEX ROWID BATCHED        | T_LOG                   |    629 |      1 |     1   (0)|     62 |00:00:00.02 |    1747 |     22 |
|* 97 |          INDEX RANGE SCAN                          | LOG_ID                  |    629 |      1 |     1   (0)|    629 |00:00:00.01 |    1252 |     22 |
|  98 |        VIEW PUSHED PREDICATE                       |                         |     62 |      1 |     6  (50)|     62 |00:00:00.03 |     307 |     53 |
|* 99 |         FILTER                                     |                         |     62 |        |            |     62 |00:00:00.03 |     307 |     53 |
| 100 |          SORT AGGREGATE                            |                         |     62 |      1 |            |     62 |00:00:00.03 |     307 |     53 |
|*101 |           FILTER                                   |                         |     62 |        |            |     62 |00:00:00.03 |     307 |     53 |
| 102 |            VIEW                                    |                         |     62 |      5 |     6  (50)|     62 |00:00:00.03 |     307 |     53 |
| 103 |             SORT UNIQUE                            |                         |     62 |      5 |     6  (50)|     62 |00:00:00.03 |     307 |     53 |
| 104 |              UNION-ALL                             |                         |     62 |        |            |     62 |00:00:00.03 |     307 |     53 |
| 105 |               TABLE ACCESS BY INDEX ROWID BATCHED  | T_ERR_AVANCE            |     62 |      2 |     1   (0)|     31 |00:00:00.01 |     142 |     14 |
|*106 |                INDEX RANGE SCAN                    | IX_ERR_AV_FILE_ID       |     62 |      1 |     1   (0)|     31 |00:00:00.01 |     111 |      0 |
| 107 |               NESTED LOOPS                         |                         |     62 |      3 |     2   (0)|     31 |00:00:00.02 |     165 |     39 |
| 108 |                NESTED LOOPS                        |                         |     62 |      3 |     2   (0)|     31 |00:00:00.02 |     134 |     24 |
| 109 |                 TABLE ACCESS BY INDEX ROWID BATCHED| T_ERR_AFFAIRE           |     62 |      3 |     1   (0)|     31 |00:00:00.02 |      98 |     24 |
|*110 |                  INDEX RANGE SCAN                  | IX_ERR_AFF_FILE_ID      |     62 |      3 |     1   (0)|     31 |00:00:00.01 |      67 |      0 |
|*111 |                 INDEX RANGE SCAN                   | IX_ERR_AV_ID_ENR1       |     31 |      1 |     1   (0)|     31 |00:00:00.01 |      36 |      0 |
| 112 |                TABLE ACCESS BY INDEX ROWID         | T_ERR_AVANCE            |     31 |      1 |     1   (0)|     31 |00:00:00.01 |      31 |     15 |
| 113 |       VIEW                                         |                         |     62 |      1 |     5  (60)|     62 |00:00:00.01 |     240 |      0 |
| 114 |        SORT UNIQUE                                 |                         |     62 |      5 |     5  (60)|     62 |00:00:00.01 |     240 |      0 |
| 115 |         UNION ALL PUSHED PREDICATE                 |                         |     62 |        |            |     62 |00:00:00.01 |     240 |      0 |
| 116 |          TABLE ACCESS BY INDEX ROWID BATCHED       | T_ERR_AFFAIRE           |     62 |      3 |     1   (0)|     31 |00:00:00.01 |      98 |      0 |
|*117 |           INDEX RANGE SCAN                         | IX_ERR_AFF_FILE_ID      |     62 |      3 |     1   (0)|     31 |00:00:00.01 |      67 |      0 |
| 118 |          TABLE ACCESS BY INDEX ROWID BATCHED       | T_ERR_AVANCE            |     62 |      2 |     1   (0)|     31 |00:00:00.01 |     142 |      0 |
|*119 |           INDEX RANGE SCAN                         | IX_ERR_AV_FILE_ID       |     62 |      1 |     1   (0)|     31 |00:00:00.01 |     111 |      0 |
--------------------------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   1 - filter("ERREUR" IS NOT NULL)
   5 - access("FILE_ID"=:B1)
   7 - access("ID_ENR1"=:B1)
   9 - access("ID_ENR1"=:B1)
  15 - access("I"."SIRET"=:B1)
  16 - access("I"."REFINDIVIDU"="T"."REFINDIVIDU" AND "T"."REFTYPE"='DB')
  17 - access("D"."REFDOSS"="T"."REFDOSS")
  18 - filter("D"."REFSPE"='AFFAIRE')
  23 - access("I"."SIRET"=:B1)
  24 - access("I"."REFINDIVIDU"="T"."REFINDIVIDU" AND "T"."REFTYPE"='DB')
  25 - access("D"."REFDOSS"="T"."REFDOSS")
  26 - filter("D"."REFSPE"='AFFAIRE')
  27 - filter("from$_subquery$_018"."rowlimit_$$_rownumber"<=1)
  28 - filter(ROW_NUMBER() OVER ( ORDER BY "P"."NBPAGE")<=1)
  36 - access("EA"."ID_ENR1"=:B1)
  39 - filter(("CONTEXTE"='O' AND "ABREV" IS NOT NULL))
  40 - access("TYPE"='TYPEJUGT')
  41 - filter(("P"."GPITYPJUG" IS NOT NULL AND "P"."GPITYPJUG"="ABREV"))
  42 - access("P"."TYPPIECE"='PROCEDURE')
       filter("EA"."DT_PC1_DT"=TO_CHAR(INTERNAL_FUNCTION("P"."GPIDTDEB_DT"),'RRRRMMDD'))
  45 - access("I"."SIRET"=:B1)
  46 - access("I"."REFINDIVIDU"="T"."REFINDIVIDU" AND "T"."REFTYPE"='DB')
  47 - access("D"."REFDOSS"="T"."REFDOSS")
  48 - filter("D"."REFSPE"='AFFAIRE')
  54 - access("I"."SIRET"=:B1)
  55 - access("I"."REFINDIVIDU"="T"."REFINDIVIDU" AND "T"."REFTYPE"='DB')
  56 - access("D"."REFDOSS"="T"."REFDOSS")
  57 - filter("D"."REFSPE"='AFFAIRE')
  62 - access("I"."SIRET"=:B1)
  63 - access("I"."REFINDIVIDU"="T"."REFINDIVIDU" AND "T"."REFTYPE"='DB')
  64 - access("D"."REFDOSS"="T"."REFDOSS")
  65 - filter("D"."REFSPE"='AFFAIRE')
  66 - filter("from$_subquery$_031"."rowlimit_$$_rownumber"<=1)
  67 - filter(ROW_NUMBER() OVER ( ORDER BY "P"."NBPAGE")<=1)
  75 - access("EA"."ID_ENR1"=:B1)
  78 - filter(("CONTEXTE"='O' AND "ABREV" IS NOT NULL))
  79 - access("TYPE"='TYPEJUGT')
  80 - filter(("P"."GPITYPJUG" IS NOT NULL AND "P"."GPITYPJUG"="ABREV"))
  81 - access("P"."TYPPIECE"='PROCEDURE')
       filter("EA"."DT_PC1_DT"=TO_CHAR(INTERNAL_FUNCTION("P"."GPIDTDEB_DT"),'RRRRMMDD'))
  84 - access("I"."SIRET"=:B1)
  85 - access("I"."REFINDIVIDU"="T"."REFINDIVIDU" AND "T"."REFTYPE"='DB')
  86 - access("D"."REFDOSS"="T"."REFDOSS")
  87 - filter("D"."REFSPE"='AFFAIRE')
  88 - filter("RNUM">=:B5)
  89 - filter(ROWNUM<=:B4)
  91 - filter(ROWNUM<=:B4)
  95 - filter(((NVL("F"."STATUS",'DONE')='DONE' OR NVL("F"."STATUS",'DONE')='CHANGED') AND 
              TO_CHAR(NVL("F"."DT_FILE_CREAT_DT",SYSDATE@!),'j')>=TO_CHAR(TO_DATE(:B2,'YYYY-MM-DD'),'j') AND 
              TO_CHAR(NVL("F"."DT_FILE_CREAT_DT",SYSDATE@!),'j')<=TO_CHAR(TO_DATE(:B3,'YYYY-MM-DD'),'j')))
  96 - filter("T"."EMETTEUR" LIKE :B1)
  97 - access("T"."ID"="F"."LOG_ID")
  99 - filter((COUNT(*)>0 AND TO_CHAR(TO_DATE(:B3,'YYYY-MM-DD'),'j')>=TO_CHAR(TO_DATE(:B2,'YYYY-MM-DD'),'j')))
 101 - filter(TO_CHAR(TO_DATE(:B3,'YYYY-MM-DD'),'j')>=TO_CHAR(TO_DATE(:B2,'YYYY-MM-DD'),'j'))
 106 - access("FILE_ID"="F"."FILE_ID")
 110 - access("AF"."FILE_ID"="F"."FILE_ID")
 111 - access("AF"."ID_ENR1"="AV"."ID_ENR1")
       filter("AV"."ID_ENR1" IS NOT NULL)
 117 - access("FILE_ID"="F"."FILE_ID")
 119 - access("FILE_ID"="F"."FILE_ID")
 
*/
/********************************OLD Metrics***************************************/

/********************************New SQL*******************************************/
SELECT *
  FROM (SELECT /*+ first_rows(2001)*/
         foo.*, ROWNUM rnum
          FROM (SELECT recycleLock      recycleLock,
                       fichier          fileName,
                       siren            siren,
                       dt_file_creat_dt receptionDate,
                       dt_file_proc_dt  dt_file_proc_dt,
                       id_enr1          lineId1,
                       id_enr2          lineId2,
                       erreur           error,
                       no_chrono_av     historyNo,
                       ancrefdoss       noAgs,
                       code_mj_origine  codeMj,
                       caseRef          caseRef,
                       rai_soc          socialReason,
                       file_id          fileId,
                       status           status
                  FROM (SELECT F.dt_file_creat_dt,
                               F.dt_file_proc_dt,
                               B.rai_soc,
                               B.siren,
                               A.code_mj_origine,
                               CASE
                                 WHEN B.erreur IS NULL THEN
                                  (SELECT erreur
                                     FROM t_err_avance ta
                                    WHERE (file_id = F.file_id OR
                                          id_enr1 = B.id_enr1)
                                      AND erreur IS NOT NULL)
                                 ELSE
                                  B.erreur
                               END AS erreur,
                               CASE
                                 WHEN B.id_enr2 IS NULL THEN
                                  (SELECT LTRIM(RTRIM(no_chrono_av)) no_chrono_av
                                     FROM t_err_avance
                                    WHERE id_enr1 = B.id_enr1)
                                 ELSE
                                  B.no_chrono_av
                               END AS no_chrono_av,
                               T.fichier,
                               B.id_enr1,
                               B.id_enr2,
                               F.file_id,
                               B.cgea,
                               F.status status,
                               F.recycle_lock recycleLock,
                               CASE
                                 WHEN (SELECT count(1)
                                         FROM t_intervenants T,
                                              g_individu     I,
                                              g_dossier      D
                                        WHERE T.reftype = 'DB'
                                          AND I.refindividu = T.refindividu
                                          AND I.siret = B.siren
                                          AND D.refdoss = T.refdoss
                                          AND D.refspe = 'AFFAIRE') <= 1 THEN
                                  (SELECT D.ancrefdoss
                                     FROM t_intervenants T,
                                          g_individu     I,
                                          g_dossier      D
                                    WHERE T.reftype = 'DB'
                                      AND I.refindividu = T.refindividu
                                      AND I.siret = B.siren
                                      AND D.refdoss = T.refdoss
                                      AND D.refspe = 'AFFAIRE')
                                 ELSE
                                  (SELECT D.ancrefdoss
                                     FROM t_intervenants T,
                                          g_individu     I,
                                          g_dossier      D,
                                          t_err_avance   EA,
                                          g_piece        P
                                    WHERE T.reftype = 'DB'
                                      AND I.refindividu = T.refindividu
                                      AND I.siret = B.siren
                                      AND D.refdoss = T.refdoss
                                      AND D.refspe = 'AFFAIRE'
                                      AND EA.id_enr1 = B.id_enr1
                                      AND P.typpiece = 'PROCEDURE'
                                      AND P.gpitypjug IN
                                          (SELECT abrev
                                             FROM v_domaine
                                            WHERE TYPE = 'TYPEJUGT'
                                              AND contexte = 'O')
                                      AND P.refdoss = D.refdoss
                                      AND EA.dt_pc1_dt =
                                          TO_CHAR(P.gpidtdeb_dt, 'RRRRMMDD')
                                    ORDER BY P.nbpage FETCH FIRST 1 ROWS ONLY)
                               END AS ancrefdoss,
                               CASE
                                 WHEN (SELECT count(1)
                                         FROM t_intervenants T,
                                              g_individu     I,
                                              g_dossier      D
                                        WHERE T.reftype = 'DB'
                                          AND I.refindividu = T.refindividu
                                          AND I.siret = B.siren
                                          AND D.refdoss = T.refdoss
                                          AND D.refspe = 'AFFAIRE') <= 1 THEN
                                  (SELECT D.refdoss
                                     FROM t_intervenants T,
                                          g_individu     I,
                                          g_dossier      D
                                    WHERE T.reftype = 'DB'
                                      AND I.refindividu = T.refindividu
                                      AND I.siret = B.siren
                                      AND D.refdoss = T.refdoss
                                      AND D.refspe = 'AFFAIRE')
                                 ELSE
                                  (SELECT D.refdoss
                                     FROM t_intervenants T,
                                          g_individu     I,
                                          g_dossier      D,
                                          t_err_avance   EA,
                                          g_piece        P
                                    WHERE T.reftype = 'DB'
                                      AND I.refindividu = T.refindividu
                                      AND I.siret = B.siren
                                      AND D.refdoss = T.refdoss
                                      AND D.refspe = 'AFFAIRE'
                                      AND EA.id_enr1 = B.id_enr1
                                      AND P.typpiece = 'PROCEDURE'
                                      AND P.gpitypjug IN
                                          (SELECT abrev
                                             FROM v_domaine
                                            WHERE TYPE = 'TYPEJUGT'
                                              AND contexte = 'O')
                                      AND P.refdoss = D.refdoss
                                      AND EA.dt_pc1_dt =
                                          TO_CHAR(P.gpidtdeb_dt, 'RRRRMMDD')
                                    ORDER BY P.nbpage FETCH FIRST 1 ROWS ONLY)
                               END AS caseRef
                          FROM t_err_file F,
                               t_log T,
                               (SELECT file_id,
                                       MIN(CODE_MJ_ORIGINE) CODE_MJ_ORIGINE
                                  FROM (SELECT file_id, CODE_MJ_ORIGINE
                                          FROM t_err_avance
                                        UNION
                                        SELECT af.file_id, av.CODE_MJ_ORIGINE
                                          FROM t_err_affaire af, t_err_avance av
                                         WHERE af.id_enr1 = av.id_enr1)
                                 GROUP BY file_id) A,
                               (SELECT erreur,
                                       file_id,
                                       id_enr1,
                                       NULL AS id_enr2,
                                       LTRIM(RTRIM(cgea)) cgea,
                                       LTRIM(RTRIM(no_chrono_av)) no_chrono_av,
                                       LTRIM(RTRIM(rai_soc)) rai_soc,
                                       LTRIM(RTRIM(siren)) siren,
                                       champ,
                                       LTRIM(RTRIM(code_orig_ags)) code_orig_ags
                                  FROM t_err_affaire
                                UNION
                                SELECT erreur,
                                       file_id,
                                       id_enr1,
                                       id_enr2,
                                       LTRIM(RTRIM(cgea)) cgea,
                                       LTRIM(RTRIM(no_chrono_av)) no_chrono_av,
                                       LTRIM(RTRIM(rai_soc)) rai_soc,
                                       LTRIM(RTRIM(siren)) siren,
                                       champ,
                                       LTRIM(RTRIM(code_orig_ags)) code_orig_ags
                                  FROM t_err_avance) B
                         WHERE 1 = 1
                           AND T.id = F.log_id
                           AND NVL(F.status, 'DONE') IN ('DONE', 'CHANGED')
                           AND A.file_id = F.file_id
                           AND T.emetteur LIKE :B1
                           AND TO_CHAR(NVL(F.dt_file_creat_dt, SYSDATE), 'j') BETWEEN
                               TO_CHAR(TO_DATE(:B2, 'YYYY-MM-DD'), 'j') AND TO_CHAR(TO_DATE(:B3, 'YYYY-MM-DD'), 'j')
                           AND B.file_id = F.file_id)
                 WHERE 1 = 1
                 ORDER BY DECODE(dt_file_proc_dt,
                                 NULL,
                                 DECODE(recycleLock, 'O', 1, 0),
                                 1),
                          receptionDate desc) foo
         WHERE ROWNUM <= :B4)
 WHERE 1 = 1
   AND rnum >= :B5;
/********************************New SQL*******************************************/
/********************************New Metrics***************************************/
/*
Plan hash value: 2292348773
---------------------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                          | Name               | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  |
---------------------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                                   |                    |      1 |        |  1580 (100)|     62 |00:00:00.37 |    5975 |    512 |
|*  1 |  TABLE ACCESS BY INDEX ROWID BATCHED               | T_ERR_AVANCE       |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|   2 |   BITMAP CONVERSION TO ROWIDS                      |                    |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|   3 |    BITMAP OR                                       |                    |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|   4 |     BITMAP CONVERSION FROM ROWIDS                  |                    |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*  5 |      INDEX RANGE SCAN                              | IX_ERR_AV_FILE_ID  |      0 |        |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|   6 |     BITMAP CONVERSION FROM ROWIDS                  |                    |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*  7 |      INDEX RANGE SCAN                              | IX_ERR_AV_ID_ENR1  |      0 |        |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|   8 |  TABLE ACCESS BY INDEX ROWID BATCHED               | T_ERR_AVANCE       |     31 |      1 |     1   (0)|     31 |00:00:00.01 |      38 |      0 |
|*  9 |   INDEX RANGE SCAN                                 | IX_ERR_AV_ID_ENR1  |     31 |      1 |     1   (0)|     31 |00:00:00.01 |       9 |      0 |
|  10 |  SORT AGGREGATE                                    |                    |     30 |      1 |            |     30 |00:00:00.06 |     383 |    103 |
|  11 |   NESTED LOOPS                                     |                    |     30 |      1 |     3   (0)|     36 |00:00:00.06 |     383 |    103 |
|  12 |    NESTED LOOPS                                    |                    |     30 |      1 |     3   (0)|     65 |00:00:00.05 |     319 |     87 |
|  13 |     NESTED LOOPS                                   |                    |     30 |      1 |     2   (0)|     65 |00:00:00.05 |     186 |     79 |
|  14 |      TABLE ACCESS BY INDEX ROWID BATCHED           | G_INDIVIDU         |     30 |      1 |     1   (0)|     30 |00:00:00.03 |      93 |     55 |
|* 15 |       INDEX RANGE SCAN                             | GINDSIRET          |     30 |      1 |     1   (0)|     30 |00:00:00.02 |      63 |     27 |
|* 16 |      INDEX RANGE SCAN                              | INT_INDIV          |     30 |      1 |     1   (0)|     65 |00:00:00.01 |      93 |     24 |
|* 17 |     INDEX RANGE SCAN                               | DOS_REFDOSS        |     65 |      1 |     1   (0)|     65 |00:00:00.01 |     133 |      8 |
|* 18 |    TABLE ACCESS BY INDEX ROWID                     | G_DOSSIER          |     65 |      1 |     1   (0)|     36 |00:00:00.01 |      64 |     16 |
|  19 |     NESTED LOOPS                                   |                    |     25 |      1 |     3   (0)|     25 |00:00:00.01 |     282 |      0 |
|  20 |      NESTED LOOPS                                  |                    |     25 |      1 |     3   (0)|     41 |00:00:00.01 |     241 |      0 |
|  21 |       NESTED LOOPS                                 |                    |     25 |      1 |     2   (0)|     41 |00:00:00.01 |     156 |      0 |
|  22 |        TABLE ACCESS BY INDEX ROWID BATCHED         | G_INDIVIDU         |     25 |      1 |     1   (0)|     25 |00:00:00.01 |      78 |      0 |
|* 23 |         INDEX RANGE SCAN                           | GINDSIRET          |     25 |      1 |     1   (0)|     25 |00:00:00.01 |      53 |      0 |
|* 24 |        INDEX RANGE SCAN                            | INT_INDIV          |     25 |      1 |     1   (0)|     41 |00:00:00.01 |      78 |      0 |
|* 25 |       INDEX RANGE SCAN                             | DOS_REFDOSS        |     41 |      1 |     1   (0)|     41 |00:00:00.01 |      85 |      0 |
|* 26 |      TABLE ACCESS BY INDEX ROWID                   | G_DOSSIER          |     41 |      1 |     1   (0)|     25 |00:00:00.01 |      41 |      0 |
|* 27 |       VIEW                                         |                    |     11 |      1 |     7  (15)|     10 |00:00:00.02 |     402 |     26 |
|* 28 |        WINDOW SORT PUSHED RANK                     |                    |     11 |      1 |     7  (15)|     10 |00:00:00.02 |     402 |     26 |
|  29 |         NESTED LOOPS SEMI                          |                    |     11 |      1 |     6   (0)|     10 |00:00:00.02 |     402 |     26 |
|  30 |          NESTED LOOPS                              |                    |     11 |      1 |     5   (0)|     10 |00:00:00.02 |     387 |     26 |
|  31 |           NESTED LOOPS                             |                    |     11 |      2 |     4   (0)|     58 |00:00:00.02 |     369 |     26 |
|  32 |            NESTED LOOPS                            |                    |     11 |      1 |     3   (0)|     26 |00:00:00.01 |     260 |      0 |
|  33 |             NESTED LOOPS                           |                    |     11 |      1 |     2   (0)|     65 |00:00:00.01 |      66 |      0 |
|  34 |              TABLE ACCESS BY INDEX ROWID BATCHED   | G_INDIVIDU         |     11 |      1 |     1   (0)|     11 |00:00:00.01 |      30 |      0 |
|* 35 |               INDEX RANGE SCAN                     | GINDSIRET          |     11 |      1 |     1   (0)|     11 |00:00:00.01 |      25 |      0 |
|* 36 |              INDEX RANGE SCAN                      | INT_INDIV          |     11 |      1 |     1   (0)|     65 |00:00:00.01 |      36 |      0 |
|* 37 |             TABLE ACCESS BY INDEX ROWID BATCHED    | G_DOSSIER          |     65 |      1 |     1   (0)|     26 |00:00:00.01 |     194 |      0 |
|* 38 |              INDEX RANGE SCAN                      | DOS_REFDOSS        |     65 |      1 |     1   (0)|     65 |00:00:00.01 |     133 |      0 |
|* 39 |            TABLE ACCESS BY INDEX ROWID BATCHED     | G_PIECE            |     26 |      1 |     1   (0)|     58 |00:00:00.02 |     109 |     26 |
|* 40 |             INDEX RANGE SCAN                       | PIE_REFDOSS        |     26 |      1 |     1   (0)|     58 |00:00:00.01 |      59 |      8 |
|* 41 |           TABLE ACCESS BY INDEX ROWID BATCHED      | T_ERR_AVANCE       |     58 |      1 |     1   (0)|     10 |00:00:00.01 |      18 |      0 |
|* 42 |            INDEX RANGE SCAN                        | IX_ERR_AV_ID_ENR1  |     58 |      1 |     1   (0)|     52 |00:00:00.01 |       9 |      0 |
|* 43 |          TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE          |     10 |      1 |     1   (0)|     10 |00:00:00.01 |      15 |      0 |
|* 44 |           INDEX RANGE SCAN                         | DOM_TYPABREV       |     10 |      1 |     1   (0)|     10 |00:00:00.01 |      13 |      0 |
|  45 |  SORT AGGREGATE                                    |                    |     30 |      1 |            |     30 |00:00:00.01 |     383 |      0 |
|  46 |   NESTED LOOPS                                     |                    |     30 |      1 |     3   (0)|     36 |00:00:00.01 |     383 |      0 |
|  47 |    NESTED LOOPS                                    |                    |     30 |      1 |     3   (0)|     65 |00:00:00.01 |     319 |      0 |
|  48 |     NESTED LOOPS                                   |                    |     30 |      1 |     2   (0)|     65 |00:00:00.01 |     186 |      0 |
|  49 |      TABLE ACCESS BY INDEX ROWID BATCHED           | G_INDIVIDU         |     30 |      1 |     1   (0)|     30 |00:00:00.01 |      93 |      0 |
|* 50 |       INDEX RANGE SCAN                             | GINDSIRET          |     30 |      1 |     1   (0)|     30 |00:00:00.01 |      63 |      0 |
|* 51 |      INDEX RANGE SCAN                              | INT_INDIV          |     30 |      1 |     1   (0)|     65 |00:00:00.01 |      93 |      0 |
|* 52 |     INDEX RANGE SCAN                               | DOS_REFDOSS        |     65 |      1 |     1   (0)|     65 |00:00:00.01 |     133 |      0 |
|* 53 |    TABLE ACCESS BY INDEX ROWID                     | G_DOSSIER          |     65 |      1 |     1   (0)|     36 |00:00:00.01 |      64 |      0 |
|  54 |     NESTED LOOPS                                   |                    |     25 |      1 |     3   (0)|     25 |00:00:00.01 |     282 |      0 |
|  55 |      NESTED LOOPS                                  |                    |     25 |      1 |     3   (0)|     41 |00:00:00.01 |     241 |      0 |
|  56 |       NESTED LOOPS                                 |                    |     25 |      1 |     2   (0)|     41 |00:00:00.01 |     156 |      0 |
|  57 |        TABLE ACCESS BY INDEX ROWID BATCHED         | G_INDIVIDU         |     25 |      1 |     1   (0)|     25 |00:00:00.01 |      78 |      0 |
|* 58 |         INDEX RANGE SCAN                           | GINDSIRET          |     25 |      1 |     1   (0)|     25 |00:00:00.01 |      53 |      0 |
|* 59 |        INDEX RANGE SCAN                            | INT_INDIV          |     25 |      1 |     1   (0)|     41 |00:00:00.01 |      78 |      0 |
|* 60 |       INDEX RANGE SCAN                             | DOS_REFDOSS        |     41 |      1 |     1   (0)|     41 |00:00:00.01 |      85 |      0 |
|* 61 |      TABLE ACCESS BY INDEX ROWID                   | G_DOSSIER          |     41 |      1 |     1   (0)|     25 |00:00:00.01 |      41 |      0 |
|* 62 |       VIEW                                         |                    |     11 |      1 |     7  (15)|     10 |00:00:00.01 |     402 |      0 |
|* 63 |        WINDOW SORT PUSHED RANK                     |                    |     11 |      1 |     7  (15)|     10 |00:00:00.01 |     402 |      0 |
|  64 |         NESTED LOOPS SEMI                          |                    |     11 |      1 |     6   (0)|     10 |00:00:00.01 |     402 |      0 |
|  65 |          NESTED LOOPS                              |                    |     11 |      1 |     5   (0)|     10 |00:00:00.01 |     387 |      0 |
|  66 |           NESTED LOOPS                             |                    |     11 |      2 |     4   (0)|     58 |00:00:00.01 |     369 |      0 |
|  67 |            NESTED LOOPS                            |                    |     11 |      1 |     3   (0)|     26 |00:00:00.01 |     260 |      0 |
|  68 |             NESTED LOOPS                           |                    |     11 |      1 |     2   (0)|     65 |00:00:00.01 |      66 |      0 |
|  69 |              TABLE ACCESS BY INDEX ROWID BATCHED   | G_INDIVIDU         |     11 |      1 |     1   (0)|     11 |00:00:00.01 |      30 |      0 |
|* 70 |               INDEX RANGE SCAN                     | GINDSIRET          |     11 |      1 |     1   (0)|     11 |00:00:00.01 |      25 |      0 |
|* 71 |              INDEX RANGE SCAN                      | INT_INDIV          |     11 |      1 |     1   (0)|     65 |00:00:00.01 |      36 |      0 |
|* 72 |             TABLE ACCESS BY INDEX ROWID BATCHED    | G_DOSSIER          |     65 |      1 |     1   (0)|     26 |00:00:00.01 |     194 |      0 |
|* 73 |              INDEX RANGE SCAN                      | DOS_REFDOSS        |     65 |      1 |     1   (0)|     65 |00:00:00.01 |     133 |      0 |
|* 74 |            TABLE ACCESS BY INDEX ROWID BATCHED     | G_PIECE            |     26 |      1 |     1   (0)|     58 |00:00:00.01 |     109 |      0 |
|* 75 |             INDEX RANGE SCAN                       | PIE_REFDOSS        |     26 |      1 |     1   (0)|     58 |00:00:00.01 |      59 |      0 |
|* 76 |           TABLE ACCESS BY INDEX ROWID BATCHED      | T_ERR_AVANCE       |     58 |      1 |     1   (0)|     10 |00:00:00.01 |      18 |      0 |
|* 77 |            INDEX RANGE SCAN                        | IX_ERR_AV_ID_ENR1  |     58 |      1 |     1   (0)|     52 |00:00:00.01 |       9 |      0 |
|* 78 |          TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE          |     10 |      1 |     1   (0)|     10 |00:00:00.01 |      15 |      0 |
|* 79 |           INDEX RANGE SCAN                         | DOM_TYPABREV       |     10 |      1 |     1   (0)|     10 |00:00:00.01 |      13 |      0 |
|* 80 |  VIEW                                              |                    |      1 |    254 |  1580  (31)|     62 |00:00:00.37 |    5975 |    512 |
|* 81 |   COUNT STOPKEY                                    |                    |      1 |        |            |     62 |00:00:00.37 |    5975 |    512 |
|  82 |    VIEW                                            |                    |      1 |    254 |  1580  (31)|     62 |00:00:00.37 |    5975 |    512 |
|* 83 |     SORT ORDER BY STOPKEY                          |                    |      1 |    254 |  1580  (31)|     62 |00:00:00.29 |    3803 |    383 |
|  84 |      NESTED LOOPS                                  |                    |      1 |    254 |  1289  (37)|     62 |00:00:00.29 |    3803 |    383 |
|  85 |       NESTED LOOPS                                 |                    |      1 |     94 |   819  (24)|     62 |00:00:00.28 |    3563 |    383 |
|  86 |        NESTED LOOPS                                |                    |      1 |     63 |   441   (2)|     62 |00:00:00.24 |    3256 |    323 |
|* 87 |         TABLE ACCESS FULL                          | T_ERR_FILE         |      1 |     63 |   422   (2)|    629 |00:00:00.03 |    1509 |      0 |
|* 88 |         TABLE ACCESS BY INDEX ROWID BATCHED        | T_LOG              |    629 |      1 |     1   (0)|     62 |00:00:00.21 |    1747 |    323 |
|* 89 |          INDEX RANGE SCAN                          | LOG_ID             |    629 |      1 |     1   (0)|    629 |00:00:00.20 |    1252 |    323 |
|  90 |        VIEW PUSHED PREDICATE                       |                    |     62 |      1 |     6  (50)|     62 |00:00:00.05 |     307 |     60 |
|* 91 |         FILTER                                     |                    |     62 |        |            |     62 |00:00:00.05 |     307 |     60 |
|  92 |          SORT AGGREGATE                            |                    |     62 |      1 |            |     62 |00:00:00.05 |     307 |     60 |
|* 93 |           FILTER                                   |                    |     62 |        |            |     62 |00:00:00.05 |     307 |     60 |
|  94 |            VIEW                                    |                    |     62 |      5 |     6  (50)|     62 |00:00:00.05 |     307 |     60 |
|  95 |             SORT UNIQUE                            |                    |     62 |      5 |     6  (50)|     62 |00:00:00.05 |     307 |     60 |
|  96 |              UNION-ALL                             |                    |     62 |        |            |     62 |00:00:00.05 |     307 |     60 |
|  97 |               TABLE ACCESS BY INDEX ROWID BATCHED  | T_ERR_AVANCE       |     62 |      2 |     1   (0)|     31 |00:00:00.01 |     142 |     19 |
|* 98 |                INDEX RANGE SCAN                    | IX_ERR_AV_FILE_ID  |     62 |      1 |     1   (0)|     31 |00:00:00.01 |     111 |      0 |
|  99 |               NESTED LOOPS                         |                    |     62 |      3 |     2   (0)|     31 |00:00:00.03 |     165 |     41 |
| 100 |                NESTED LOOPS                        |                    |     62 |      3 |     2   (0)|     31 |00:00:00.02 |     134 |     24 |
| 101 |                 TABLE ACCESS BY INDEX ROWID BATCHED| T_ERR_AFFAIRE      |     62 |      3 |     1   (0)|     31 |00:00:00.02 |      98 |     24 |
|*102 |                  INDEX RANGE SCAN                  | IX_ERR_AFF_FILE_ID |     62 |      3 |     1   (0)|     31 |00:00:00.01 |      67 |      0 |
|*103 |                 INDEX RANGE SCAN                   | IX_ERR_AV_ID_ENR1  |     31 |      1 |     1   (0)|     31 |00:00:00.01 |      36 |      0 |
| 104 |                TABLE ACCESS BY INDEX ROWID         | T_ERR_AVANCE       |     31 |      1 |     1   (0)|     31 |00:00:00.01 |      31 |     17 |
| 105 |       VIEW                                         |                    |     62 |      1 |     5  (60)|     62 |00:00:00.01 |     240 |      0 |
| 106 |        SORT UNIQUE                                 |                    |     62 |      5 |     5  (60)|     62 |00:00:00.01 |     240 |      0 |
| 107 |         UNION ALL PUSHED PREDICATE                 |                    |     62 |        |            |     62 |00:00:00.01 |     240 |      0 |
| 108 |          TABLE ACCESS BY INDEX ROWID BATCHED       | T_ERR_AFFAIRE      |     62 |      3 |     1   (0)|     31 |00:00:00.01 |      98 |      0 |
|*109 |           INDEX RANGE SCAN                         | IX_ERR_AFF_FILE_ID |     62 |      3 |     1   (0)|     31 |00:00:00.01 |      67 |      0 |
| 110 |          TABLE ACCESS BY INDEX ROWID BATCHED       | T_ERR_AVANCE       |     62 |      2 |     1   (0)|     31 |00:00:00.01 |     142 |      0 |
|*111 |           INDEX RANGE SCAN                         | IX_ERR_AV_FILE_ID  |     62 |      1 |     1   (0)|     31 |00:00:00.01 |     111 |      0 |
---------------------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   1 - filter("ERREUR" IS NOT NULL)
   5 - access("FILE_ID"=:B1)
   7 - access("ID_ENR1"=:B1)
   9 - access("ID_ENR1"=:B1)
  15 - access("I"."SIRET"=:B1)
  16 - access("I"."REFINDIVIDU"="T"."REFINDIVIDU" AND "T"."REFTYPE"='DB')
  17 - access("D"."REFDOSS"="T"."REFDOSS")
  18 - filter("D"."REFSPE"='AFFAIRE')
  23 - access("I"."SIRET"=:B1)
  24 - access("I"."REFINDIVIDU"="T"."REFINDIVIDU" AND "T"."REFTYPE"='DB')
  25 - access("D"."REFDOSS"="T"."REFDOSS")
  26 - filter("D"."REFSPE"='AFFAIRE')
  27 - filter("from$_subquery$_018"."rowlimit_$$_rownumber"<=1)
  28 - filter(ROW_NUMBER() OVER ( ORDER BY "P"."NBPAGE")<=1)
  35 - access("I"."SIRET"=:B1)
  36 - access("I"."REFINDIVIDU"="T"."REFINDIVIDU" AND "T"."REFTYPE"='DB')
  37 - filter("D"."REFSPE"='AFFAIRE')
  38 - access("D"."REFDOSS"="T"."REFDOSS")
  39 - filter("P"."GPITYPJUG" IS NOT NULL)
  40 - access("P"."REFDOSS"="D"."REFDOSS" AND "P"."TYPPIECE"='PROCEDURE')
  41 - filter("EA"."DT_PC1_DT"=TO_CHAR(INTERNAL_FUNCTION("P"."GPIDTDEB_DT"),'RRRRMMDD'))
  42 - access("EA"."ID_ENR1"=:B1)
  43 - filter("CONTEXTE"='O')
  44 - access("TYPE"='TYPEJUGT' AND "P"."GPITYPJUG"="ABREV")
       filter("ABREV" IS NOT NULL)
  50 - access("I"."SIRET"=:B1)
  51 - access("I"."REFINDIVIDU"="T"."REFINDIVIDU" AND "T"."REFTYPE"='DB')
  52 - access("D"."REFDOSS"="T"."REFDOSS")
  53 - filter("D"."REFSPE"='AFFAIRE')
  58 - access("I"."SIRET"=:B1)
  59 - access("I"."REFINDIVIDU"="T"."REFINDIVIDU" AND "T"."REFTYPE"='DB')
  60 - access("D"."REFDOSS"="T"."REFDOSS")
  61 - filter("D"."REFSPE"='AFFAIRE')
  62 - filter("from$_subquery$_031"."rowlimit_$$_rownumber"<=1)
  63 - filter(ROW_NUMBER() OVER ( ORDER BY "P"."NBPAGE")<=1)
  70 - access("I"."SIRET"=:B1)
  71 - access("I"."REFINDIVIDU"="T"."REFINDIVIDU" AND "T"."REFTYPE"='DB')
  72 - filter("D"."REFSPE"='AFFAIRE')
  73 - access("D"."REFDOSS"="T"."REFDOSS")
  74 - filter("P"."GPITYPJUG" IS NOT NULL)
  75 - access("P"."REFDOSS"="D"."REFDOSS" AND "P"."TYPPIECE"='PROCEDURE')
  76 - filter("EA"."DT_PC1_DT"=TO_CHAR(INTERNAL_FUNCTION("P"."GPIDTDEB_DT"),'RRRRMMDD'))
  77 - access("EA"."ID_ENR1"=:B1)
  78 - filter("CONTEXTE"='O')
  79 - access("TYPE"='TYPEJUGT' AND "P"."GPITYPJUG"="ABREV")
       filter("ABREV" IS NOT NULL)
  80 - filter("RNUM">=:B5)
  81 - filter(ROWNUM<=:B4)
  83 - filter(ROWNUM<=:B4)
  87 - filter(((NVL("F"."STATUS",'DONE')='DONE' OR NVL("F"."STATUS",'DONE')='CHANGED') AND 
              TO_CHAR(NVL("F"."DT_FILE_CREAT_DT",SYSDATE@!),'j')>=TO_CHAR(TO_DATE(:B2,'YYYY-MM-DD'),'j') AND 
              TO_CHAR(NVL("F"."DT_FILE_CREAT_DT",SYSDATE@!),'j')<=TO_CHAR(TO_DATE(:B3,'YYYY-MM-DD'),'j')))
  88 - filter("T"."EMETTEUR" LIKE :B1)
  89 - access("T"."ID"="F"."LOG_ID")
  91 - filter((COUNT(*)>0 AND TO_CHAR(TO_DATE(:B3,'YYYY-MM-DD'),'j')>=TO_CHAR(TO_DATE(:B2,'YYYY-MM-DD'),'j')))
  93 - filter(TO_CHAR(TO_DATE(:B3,'YYYY-MM-DD'),'j')>=TO_CHAR(TO_DATE(:B2,'YYYY-MM-DD'),'j'))
  98 - access("FILE_ID"="F"."FILE_ID")
 102 - access("AF"."FILE_ID"="F"."FILE_ID")
 103 - access("AF"."ID_ENR1"="AV"."ID_ENR1")
       filter("AV"."ID_ENR1" IS NOT NULL)
 109 - access("FILE_ID"="F"."FILE_ID")
 111 - access("FILE_ID"="F"."FILE_ID") 
*/
/********************************New Metrics***************************************/

/********************************Index statistics**********************************/

/********************************Other SQLs****************************************/          
/*

*/ 
/********************************Other SQLs****************************************/              
