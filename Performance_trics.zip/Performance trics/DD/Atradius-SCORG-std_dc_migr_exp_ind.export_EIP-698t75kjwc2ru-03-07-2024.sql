/********************************************************************************
*********       E-mail subject: ACPDEV-4747
*********             Instance: SCORG
*********          Description: 
Problem:
std_dc_migr_exp_ind.export_EIP took more that 3 hours on instance SCORG on 02/07/2024.

Analysis:
After the analyze of std_dc_migr_exp_ind.export_EIP, I found that the load is separated between two SQLs => 698t75kjwc2ru and 58srr4t7gb4rf.
Each of them was responsible for 50% of the time. The problem in both of them is when accessing table V_EXTR_DOM through index TYPEABREV, which is on
columns TYPE,ABREV,VALEUR. Table V_EXTR_DOM is joined with table MIGR_DC_USE on condition REFPERSO = V.ABREV, the column REFPERSO on table
MIGR_DC_USE is from type number, but the column ABREV on table V_EXTR_DOM is from type varchar2, which doesn't allow accessing table V_EXTR_DOM through columns
TYPE and ABREV and Oracle accessed table V_EXTR_DOM only through column TYPE and then makes filter on column ABREV. The solution here is to add to_char() on column
REFPERSO on table MIGR_DC_USE, which will allow Oracle to access table V_EXTR_DOM through TYPE and ABREV.

Suggestion:
Please change the queries as it is shown in the New SQL section below.

*********               SQL_ID: 698t75kjwc2ru, 58srr4t7gb4rf
*********      Program/Package: 
*********              Request: Iva Zareva 
*********               Author: Dimitar Dimitrov
********* Received e-mail date: 02/07/2024
*********      Resolution date: 03/07/2024
*********  Trace old file here: \\epox\specifs\performance\tmp\
*********  Trace new file here:
***********************************************************************************/

/********************************OLD SQL*******************************************/

-- 698t75kjwc2ru

SELECT V.ABREV, 
       P.LOGIN, 
       V.VALEUR
  FROM V_EXTR_DOM V, 
       G_PERSONNEL P
 WHERE V.TYPE IN ('EXTR_GEST_CLIENT', 'EXTR_GEST_CLIENT_ALL')
   AND V.ABREV = P.REFPERSO
   AND EXISTS ( SELECT 1 
                  FROM MIGR_DC_USE 
                 WHERE REFPERSO = V.ABREV )
   AND (P.LOGIN IS NULL OR V.VALEUR IS NULL)
   AND NOT EXISTS ( SELECT 1
                      FROM V_EXTR_DOM V2
                     WHERE V2.TYPE = 'EXTR_GEST_CLIENT'
                       AND V2.TYPE = V.TYPE
                       AND V2.ABREV = V.ABREV
                       AND V2.VALEUR_2 IN ('SR', 'ASR', 'CT1')
                       AND NVL(V.VALEUR_2, 'X') NOT IN ('SR', 'ASR', 'CT1')
                       AND NVL(V.VALEUR_2, 'X') != V2.VALEUR_2 );


-- 58srr4t7gb4rf

INSERT INTO MIGR_DC_EIP( TYPE, 
                         REF_USER, 
                         LOGIN, 
                         REFEXT, 
                         INV_PARTY_TYPE )
     SELECT V.TYPE, 
            V.ABREV, 
            P.LOGIN, 
            V.VALEUR, 
            V.VALEUR_2
       FROM V_EXTR_DOM V, 
            G_PERSONNEL P
      WHERE V.TYPE IN ('EXTR_GEST_CLIENT', 'EXTR_GEST_CLIENT_ALL')
        AND V.ABREV = P.REFPERSO
        AND EXISTS ( SELECT 1 
                       FROM MIGR_DC_USE 
                      WHERE REFPERSO = V.ABREV )
       AND P.LOGIN IS NOT NULL
       AND V.VALEUR IS NOT NULL
       AND NOT EXISTS ( SELECT 1
                          FROM V_EXTR_DOM V2
                         WHERE V2.TYPE = 'EXTR_GEST_CLIENT'
                           AND V2.TYPE = V.TYPE
                           AND V2.ABREV = V.ABREV
                           AND V2.VALEUR_2 IN ('SR', 'ASR', 'CT1')
                           AND NVL(V.VALEUR_2, 'X') NOT IN ('SR', 'ASR', 'CT1')
                           AND NVL(V.VALEUR_2, 'X') != V2.VALEUR_2 );       

/********************************OLD SQL*******************************************/
/********************************OLD Metrics***************************************/
/*
MODULE                           PROGRAM                                            SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- -------------------------------------------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
std_dc_migr_exp_inv.export_FCEM_ std_migration_robot                                dc5nu5vpar7kq 2697293673        811       2894 ON CPU               2024/07/02 10:40:04  2024/07/02 13:59:50        1199                    1 +000000000 03:19:46.483 33%
STMT

std_dc_migr_exp_ind.export_EIP   std_migration_robot                                              3550170199        577      13883 ON CPU               2024/07/02 10:44:34  2024/07/02 13:57:50        1148                    1 +000000000 03:13:16.187 31%
std_dc_migr_exp_case.export_SLD  std_migration_robot                                669vcnugdyb01 3854816944        349       7556 db file sequential r 2024/07/02 13:19:18  2024/07/02 13:59:40         216                    1 +000000000 00:40:22.116 6%


MODULE                           PROGRAM                                            SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- -------------------------------------------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
std_dc_migr_exp_ind.export_EIP   std_migration_robot                                              3550170199        577      13883 ON CPU               2024/07/02 10:44:34  2024/07/02 13:57:50        1148                    1 +000000000 03:13:16.187 99%
std_dc_migr_exp_ind.export_EIP   std_migration_robot                                              3550170199        577      13883 db file sequential r 2024/07/02 11:07:54  2024/07/02 13:21:08          12                    1 +000000000 02:13:13.735 1%

          

MODULE                           PROGRAM                                            SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- -------------------------------------------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
std_dc_migr_exp_ind.export_EIP   std_migration_robot                                698t75kjwc2ru 3550170199        577      13883                      2024/07/02 12:20:26  2024/07/02 13:57:50         585                    1 +000000000 01:37:23.785 50%
std_dc_migr_exp_ind.export_EIP   std_migration_robot                                58srr4t7gb4rf 3550170199        577      13883                      2024/07/02 10:44:34  2024/07/02 12:20:16         575                    1 +000000000 01:35:42.381 50%


INSTANCE_NUMBER SQL_ID            ELAPSED MAX_WAIT_ON     PC_OF  WAIT_TIME            GETS      READS       ROWS  ELAP/EXEC       GETS/EXEC READS/EXEC  ROWS/EXEC       EXEC PLAN_HASH_VALUE
--------------- ------------- ----------- --------------- ----- ---------- --------------- ---------- ---------- ---------- --------------- ---------- ---------- ---------- ---------------
              1 58srr4t7gb4rf        5746 CPU             100%  2421.84233       650114706       9836      13337    5746.06       650114706       9836      13337          1      3550170199
              1 698t75kjwc2ru        5858 CPU             95%   2525.22335       650298002     260533          0    5858.19       650298002     260533          0          1      3550170199


SQL_ID        SQL_PLAN_HASH_VALUE SQL_PLAN_LINE_ID SQL_PLAN_OPERATION             SQL_PLAN_OPTIONS                   ACTIVE
------------- ------------------- ---------------- ------------------------------ ------------------------------ ----------
698t75kjwc2ru          3550170199                8 INDEX                          RANGE SCAN                            584
58srr4t7gb4rf          3550170199                9 INDEX                          RANGE SCAN                            573
58srr4t7gb4rf          3550170199               10 TABLE ACCESS                   BY INDEX ROWID BATCHED                  1
58srr4t7gb4rf          3550170199                8 TABLE ACCESS                   BY INDEX ROWID BATCHED                  1
698t75kjwc2ru          3550170199                7 TABLE ACCESS                   BY INDEX ROWID BATCHED                  1


Plan hash value: 3550170199
------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                               | Name           | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  |
------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                        |                |      1 |        |    23 (100)|      0 |00:00:00.01 |       0 |      0 |
|   1 |  NESTED LOOPS ANTI                      |                |      1 |      1 |    23   (5)|      0 |00:00:00.01 |       0 |      0 |
|   2 |   NESTED LOOPS                          |                |      1 |      1 |    22   (5)|      0 |00:00:00.01 |       0 |      0 |
|   3 |    NESTED LOOPS                         |                |      1 |      1 |    21   (5)|    202 |00:01:00.10 |    2093K|  55302 |
|   4 |     SORT UNIQUE                         |                |      1 |      1 |     2   (0)|     39 |00:00:00.06 |     206 |    203 |
|   5 |      TABLE ACCESS FULL                  | MIGR_DC_USE    |      1 |      1 |     2   (0)|  11808 |00:00:00.05 |     206 |    203 |
|   6 |     INLIST ITERATOR                     |                |     39 |        |            |    202 |00:01:00.04 |    2092K|  55099 |
|   7 |      TABLE ACCESS BY INDEX ROWID BATCHED| V_EXTR_DOM     |     77 |      2 |    18   (0)|    202 |00:01:00.04 |    2092K|  55099 |
|*  8 |       INDEX RANGE SCAN                  | TYPEABREV      |     77 |      2 |    18   (0)|    202 |00:00:59.99 |    2092K|  55065 |
|*  9 |    TABLE ACCESS BY INDEX ROWID BATCHED  | G_PERSONNEL    |    202 |      1 |     1   (0)|      0 |00:00:00.03 |      38 |     28 |
|* 10 |     INDEX RANGE SCAN                    | PK_G_PERSONNEL |    202 |      1 |     1   (0)|    202 |00:00:00.01 |      11 |      2 |
|* 11 |   VIEW PUSHED PREDICATE                 | VW_SQ_1        |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 12 |    FILTER                               |                |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|* 13 |     TABLE ACCESS BY INDEX ROWID BATCHED | V_EXTR_DOM     |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 14 |      INDEX RANGE SCAN                   | TYPEABREV      |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   8 - access(("V"."TYPE"='EXTR_GEST_CLIENT' OR "V"."TYPE"='EXTR_GEST_CLIENT_ALL'))
       filter("REFPERSO"=TO_NUMBER("V"."ABREV"))
   9 - filter(("P"."LOGIN" IS NULL OR "V"."VALEUR" IS NULL))
  10 - access("P"."REFPERSO"=TO_NUMBER("V"."ABREV"))
  11 - filter(("ITEM_3"<>NVL("V"."VALEUR_2",'X') AND "ITEM_4"<>NVL("V"."VALEUR_2",'X') AND "ITEM_5"<>NVL("V"."VALEUR_2",'X')))
  12 - filter("V"."TYPE"='EXTR_GEST_CLIENT')
  13 - filter((INTERNAL_FUNCTION("V2"."VALEUR_2") AND "V2"."VALEUR_2"<>NVL("V"."VALEUR_2",'X')))
  14 - access("V2"."TYPE"='EXTR_GEST_CLIENT' AND "V2"."ABREV"="V"."ABREV")
*/
/********************************OLD Metrics***************************************/

/********************************New SQL*******************************************/
-- 698t75kjwc2ru

SELECT V.ABREV, 
       P.LOGIN, 
       V.VALEUR
  FROM V_EXTR_DOM V, 
       G_PERSONNEL P
 WHERE V.TYPE IN ('EXTR_GEST_CLIENT', 'EXTR_GEST_CLIENT_ALL')
   AND V.ABREV = P.REFPERSO
   AND EXISTS ( SELECT 1 
                  FROM MIGR_DC_USE 
                 WHERE to_char(REFPERSO) = V.ABREV )
   AND (P.LOGIN IS NULL OR V.VALEUR IS NULL)
   AND NOT EXISTS ( SELECT 1
                      FROM V_EXTR_DOM V2
                     WHERE V2.TYPE = 'EXTR_GEST_CLIENT'
                       AND V2.TYPE = V.TYPE
                       AND V2.ABREV = V.ABREV
                       AND V2.VALEUR_2 IN ('SR', 'ASR', 'CT1')
                       AND NVL(V.VALEUR_2, 'X') NOT IN ('SR', 'ASR', 'CT1')
                       AND NVL(V.VALEUR_2, 'X') != V2.VALEUR_2 );


-- 58srr4t7gb4rf


INSERT INTO MIGR_DC_EIP( TYPE, 
                         REF_USER, 
                         LOGIN, 
                         REFEXT, 
                         INV_PARTY_TYPE )
     SELECT V.TYPE, 
            V.ABREV, 
            P.LOGIN, 
            V.VALEUR, 
            V.VALEUR_2
       FROM V_EXTR_DOM V, 
            G_PERSONNEL P
      WHERE V.TYPE IN ('EXTR_GEST_CLIENT', 'EXTR_GEST_CLIENT_ALL')
        AND V.ABREV = P.REFPERSO
        AND EXISTS ( SELECT 1 
                       FROM MIGR_DC_USE 
                      WHERE to_char(REFPERSO) = V.ABREV )
       AND P.LOGIN IS NOT NULL
       AND V.VALEUR IS NOT NULL
       AND NOT EXISTS ( SELECT 1
                          FROM V_EXTR_DOM V2
                         WHERE V2.TYPE = 'EXTR_GEST_CLIENT'
                           AND V2.TYPE = V.TYPE
                           AND V2.ABREV = V.ABREV
                           AND V2.VALEUR_2 IN ('SR', 'ASR', 'CT1')
                           AND NVL(V.VALEUR_2, 'X') NOT IN ('SR', 'ASR', 'CT1')
                           AND NVL(V.VALEUR_2, 'X') != V2.VALEUR_2 );
/********************************New SQL*******************************************/
/********************************New Metrics***************************************/
/*
Plan hash value: 3550170199
------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                               | Name           | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  |
------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                        |                |      1 |        |     6 (100)|      0 |00:00:06.58 |   90202 |  10319 |
|   1 |  NESTED LOOPS ANTI                      |                |      1 |      1 |     6  (17)|      0 |00:00:06.58 |   90202 |  10319 |
|   2 |   NESTED LOOPS                          |                |      1 |      1 |     5  (20)|      0 |00:00:06.58 |   90202 |  10319 |
|   3 |    NESTED LOOPS                         |                |      1 |      2 |     4  (25)|  13515 |00:00:04.27 |   81165 |   6065 |
|   4 |     SORT UNIQUE                         |                |      1 |  11808 |     2   (0)|  11808 |00:00:00.08 |     206 |    203 |
|   5 |      TABLE ACCESS FULL                  | MIGR_DC_USE    |      1 |  11808 |     2   (0)|  11808 |00:00:00.06 |     206 |    203 |
|   6 |     INLIST ITERATOR                     |                |  11808 |        |            |  13515 |00:00:04.17 |   80959 |   5862 |
|   7 |      TABLE ACCESS BY INDEX ROWID BATCHED| V_EXTR_DOM     |  23616 |      2 |     1   (0)|  13515 |00:00:04.15 |   80959 |   5862 |
|*  8 |       INDEX RANGE SCAN                  | TYPEABREV      |  23616 |      2 |     1   (0)|  13515 |00:00:00.98 |   71019 |   1177 |
|*  9 |    TABLE ACCESS BY INDEX ROWID BATCHED  | G_PERSONNEL    |  13515 |      1 |     1   (0)|      0 |00:00:02.30 |    9037 |   4254 |
|* 10 |     INDEX RANGE SCAN                    | PK_G_PERSONNEL |  13515 |      1 |     1   (0)|  13515 |00:00:00.11 |    1809 |     95 |
|* 11 |   VIEW PUSHED PREDICATE                 | VW_SQ_1        |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 12 |    FILTER                               |                |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|* 13 |     TABLE ACCESS BY INDEX ROWID BATCHED | V_EXTR_DOM     |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 14 |      INDEX RANGE SCAN                   | TYPEABREV      |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   8 - access((("V"."TYPE"='EXTR_GEST_CLIENT' OR "V"."TYPE"='EXTR_GEST_CLIENT_ALL')) AND "V"."ABREV"=TO_CHAR("REFPERSO"))
   9 - filter(("P"."LOGIN" IS NULL OR "V"."VALEUR" IS NULL))
  10 - access("P"."REFPERSO"=TO_NUMBER("V"."ABREV"))
  11 - filter(("ITEM_3"<>NVL("V"."VALEUR_2",'X') AND "ITEM_4"<>NVL("V"."VALEUR_2",'X') AND "ITEM_5"<>NVL("V"."VALEUR_2",'X')))
  12 - filter("V"."TYPE"='EXTR_GEST_CLIENT')
  13 - filter((INTERNAL_FUNCTION("V2"."VALEUR_2") AND "V2"."VALEUR_2"<>NVL("V"."VALEUR_2",'X')))
  14 - access("V2"."TYPE"='EXTR_GEST_CLIENT' AND "V2"."ABREV"="V"."ABREV")
*/
/********************************New Metrics***************************************/

/********************************Index statistics**********************************/

/********************************Other SQLs****************************************/          
/*

*/ 
/********************************Other SQLs****************************************/              
