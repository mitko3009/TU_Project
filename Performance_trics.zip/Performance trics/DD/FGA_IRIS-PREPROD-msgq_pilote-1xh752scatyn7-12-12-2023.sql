/********************************************************************************
*********       E-mail subject: FGWEB-3371
*********             Instance: PREPROD
*********          Description: 
Problem:
Screen E_DOSSIER2_REGL is waiting when call user_exit(pilote) on PREPROD.

Analysis:
We analyzed and found that the module E_DOSSIER2_REGL is locked by the msgq_pilote.
E_DOSSIER2_REGL is executing SQL fdxq1mytamjsp but it is locked by SQL 1xh752scatyn7 from msgq_pilote.
The problem in SQL 1xh752scatyn7 is missing index on column recovery_account on table g_dossier on PREPROD.

Suggestion:
Please deliver to PREPROD the missing index DOS_REC_ACC_IDX on column recovery_account on table g_dossier.

*********               SQL_ID: 1xh752scatyn7
*********      Program/Package: msgq_pilote
*********              Request: Ruslan Zafirov 
*********               Author: Dimitar Dimitrov
********* Received e-mail date: 12/12/2023
*********      Resolution date: 12/12/2023
*********  Trace old file here: \\epox\specifs\performance\tmp\
*********  Trace new file here:
***********************************************************************************/

/********************************OLD SQL*******************************************/
-- fdxq1mytamjsp

update t_attente 
   SET refresultat = '  SE' 
 WHERE typentite = :b0 
   AND refentite = :b1 
   AND typencour != 'Controle reversement' ;


-- 1xh752scatyn7

var refdos varchar2(32);
exec :refdos := '2310170010';

update t_filiere 
   set dtfin_dt = sysdate,
       fin_filiere = 'P',
       ( solde_fin, solde_fin_dos, restprin_fin, restprin_fin_dos ) = ( select g.soldedb, g.soldedb_dos, g.restprin, g.restprin_dos 
                                                                          from g_dossier g 
                                                                         where g.refdoss = :refdos ),
       consolidated_solde_fin_conf = ( select nvl(sum(soldedb),0) 
                                         from g_dossier 
                                        where recovery_account = :refdos ) 
 where refdoss = :refdos 
   and nom = 'PLIDW' 
   and dtfin is null;
/********************************OLD SQL*******************************************/
/********************************OLD Metrics***************************************/
/*
MODULE                    SQL_ID         PLAN_HASH SID    SERIAL# CLIENT_ID    EVENT                          FROM                           TO                                 ACTIVE NUMBER_OF_EXECUTIONS PERC
------------------------- ------------- ---------- ------ ------- ------------ ------------------------------ ------------------------------ ------------------------------ ---------- -------------------- ------
msgq_pilote               1xh752scatyn7 2946343214                                                            2023/11/29 08:43:01            2023/11/29 08:46:02                    80                    2 67%
E_DOSSIER2_REGL           fdxq1mytamjsp 1667112649 178    16953   ROBIN        enq: TX - row lock contention  2023/11/29 08:45:41            2023/11/29 08:46:02                    30                    1 25%
E_AGENDA_MANUEL           bksu7q9gwtsmp 1913623585 178    16953   ROBIN        ON CPU                         2023/11/29 08:43:01            2023/11/29 08:43:01                    10                    1 8%

MODULE                    SQL_ID         PLAN_HASH SID    SERIAL# BLOCKING_SESSION CLIENT_ID    EVENT                          FROM                           TO                                 ACTIVE NUMBER_OF_EXECUTIONS PERC
------------------------- ------------- ---------- ------ ------- ---------------- ------------ ------------------------------ ------------------------------ ------------------------------ ---------- -------------------- ------
msgq_pilote               1xh752scatyn7 2946343214 206    19237                                                                2023/11/29 08:43:01            2023/11/29 08:43:31                    40                    1 33%
msgq_pilote               1xh752scatyn7 2946343214 234    9495                                                                 2023/11/29 08:45:31            2023/11/29 08:46:02                    40                    1 33%
E_DOSSIER2_REGL           fdxq1mytamjsp 1667112649 178    16953                234 ROBIN        enq: TX - row lock contention  2023/11/29 08:45:41            2023/11/29 08:46:02                    30                    1 25%
E_AGENDA_MANUEL           bksu7q9gwtsmp 1913623585 178    16953                    ROBIN        ON CPU                         2023/11/29 08:43:01            2023/11/29 08:43:01                    10                    1 8%


-- 1xh752scatyn7

Plan hash value: 2946343214
----------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                    | Name        | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  |
----------------------------------------------------------------------------------------------------------------------------
|   0 | UPDATE STATEMENT             |             |      1 |        |   113K(100)|      0 |00:00:25.87 |    6167K|    205K|
|   1 |  UPDATE                      | T_FILIERE   |      1 |        |            |      0 |00:00:25.87 |    6167K|    205K|
|   2 |   TABLE ACCESS BY INDEX ROWID| T_FILIERE   |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       4 |      1 |
|*  3 |    INDEX RANGE SCAN          | TIND_FIL    |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |      0 |
|   4 |   TABLE ACCESS BY INDEX ROWID| G_DOSSIER   |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       5 |      0 |
|*  5 |    INDEX UNIQUE SCAN         | DOS_REFDOSS |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |      0 |
|   6 |   SORT AGGREGATE             |             |      1 |      1 |            |      1 |00:00:25.86 |    6167K|    205K|
|*  7 |    TABLE ACCESS FULL         | G_DOSSIER   |      1 |      1 |   113K  (4)|      0 |00:00:25.86 |    6167K|    205K|
----------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   3 - access("REFDOSS"=:REFDOS AND "NOM"='PLIDW')
   5 - access("G"."REFDOSS"=:REFDOS)
   7 - filter("RECOVERY_ACCOUNT"=:REFDOS)
*/
/********************************OLD Metrics***************************************/

/********************************New SQL*******************************************/
-- No changes in the SQL text.
/********************************New SQL*******************************************/
/********************************New Metrics***************************************/
/*

*/
/********************************New Metrics***************************************/

/********************************Index statistics**********************************/

/********************************Other SQLs****************************************/          
/*

*/ 
/********************************Other SQLs****************************************/              
