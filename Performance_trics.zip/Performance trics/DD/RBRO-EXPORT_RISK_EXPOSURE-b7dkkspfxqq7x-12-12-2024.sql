/********************************************************************************
*********       E-mail subject: RBRO
*********             Instance: JUJU
*********          Description: 
Problem:
SQL b7dkkspfxqq7x was the third TOP SQL in EXPORT_RISK_EXPOSURE batch on JUJU.

Analysis:
From what we see in the execution plan, the query access table G_PIECE through the GP_TYPEDOC column, which is not so heavy on JUJU, but it might be haevy on other instances.
The selective way here to access the tables is to start from table G_PIECE REQ ( REQ.REFPIECE = :B1 ) and join the other G_PIECEs through the GPILIBLIBRE column in the first union and 
thorugh ST41 column in the other UNIONs. For this purpose, we should remove the NVLs from column GPILIBLIBRE and change the NVLs on column ST41 to be able to use the functional index.
Also, we added some hint to force Oracle to join the tables in the correct order using the correct columns and indexes.

Suggestion:
Please change SQL b7dkkspfxqq7x as it is shown in the New SQL section below.

*********               SQL_ID: b7dkkspfxqq7x
*********      Program/Package: 
*********              Request: Adrian Petrov
*********               Author: Dimitar Dimitrov
********* Received e-mail date: 05/11/2024
*********      Resolution date: 12/12/2024
*********  Trace old file here: \\epox\specifs\performance\tmp\
*********  Trace new file here:
***********************************************************************************/

/********************************OLD SQL*******************************************/
VAR B1 VARCHAR2(32);
EXEC :B1 := 'A7058OGE';
VAR B2 VARCHAR2(32);
EXEC :B2 := 'C';

SELECT MT02,
       DT04_DT,
       GPIDTFIN_DT
  FROM ( SELECT OLD_DES_DATE.MT02        MT02,
                OLD_DES_DATE.DT04_DT     DT04_DT,
                OLD_DES_DATE.GPIDTFIN_DT GPIDTFIN_DT
           FROM G_PIECE REQ,
                G_PIECE OLD_DES_DATE
          WHERE :B2 = 'C'
            AND REQ.TYPPIECE = 'REQUEST_LIMITE'
            AND REQ.REFPIECE = :B1
            AND OLD_DES_DATE.TYPEDOC = 'C'
            AND OLD_DES_DATE.TYPPIECE = 'REQUEST_LIMITE'
            AND NVL(OLD_DES_DATE.GPILIBLIBRE, 'XXX') = NVL(REQ.GPILIBLIBRE, 'XXX')
            AND OLD_DES_DATE.DT04_DT = ( SELECT MIN(DT04_DT)
                                           FROM G_PIECE
                                          WHERE TYPPIECE = 'REQUEST_LIMITE'
                                            AND TYPEDOC = 'C'
                                            AND NVL(GPILIBLIBRE, 'XXX') = NVL(REQ.GPILIBLIBRE, 'XXX') )
          UNION ALL
         SELECT OLD_DES_DATE.MT02        MT02,
                OLD_DES_DATE.DT04_DT     DT04_DT,
                OLD_DES_DATE.GPIDTFIN_DT GPIDTFIN_DT
           FROM G_PIECE REQ, G_PIECE OLD_DES_DATE
          WHERE :B2 = 'DGCF'
            AND REQ.TYPPIECE = 'REQUEST_LIMITE'
            AND REQ.REFPIECE = :B1
            AND OLD_DES_DATE.TYPEDOC = 'DGCF'
            AND OLD_DES_DATE.TYPPIECE = 'REQUEST_LIMITE'
            AND NVL(OLD_DES_DATE.GPITYPTRIB, 'XXX') = NVL(REQ.GPITYPTRIB, 'XXX')
            AND NVL(OLD_DES_DATE.GPIDEPOT, 'XXX') = NVL(REQ.GPIDEPOT, 'XXX')
            AND NVL(OLD_DES_DATE.ST41, 'XXX') = NVL(REQ.ST41, 'XXX')
            AND OLD_DES_DATE.DT04_DT = ( SELECT MIN(DT04_DT)
                                           FROM G_PIECE
                                          WHERE TYPPIECE = 'REQUEST_LIMITE'
                                            AND TYPEDOC = 'DGCF'
                                            AND NVL(GPITYPTRIB, 'XXX') = NVL(REQ.GPITYPTRIB, 'XXX')
                                            AND NVL(GPIDEPOT, 'XXX') = NVL(REQ.GPIDEPOT, 'XXX')
                                            AND NVL(ST41, 'XXX') = NVL(REQ.ST41, 'XXX') )
          UNION ALL
         SELECT OLD_DES_DATE.MT02        MT02,
                OLD_DES_DATE.DT04_DT     DT04_DT,
                OLD_DES_DATE.GPIDTFIN_DT GPIDTFIN_DT
           FROM G_PIECE REQ,
                G_PIECE OLD_DES_DATE
          WHERE :B2 = 'DGCGF'
            AND REQ.TYPPIECE = 'REQUEST_LIMITE'
            AND REQ.REFPIECE = :B1
            AND OLD_DES_DATE.TYPEDOC = :B2
            AND OLD_DES_DATE.TYPPIECE = 'REQUEST_LIMITE'
            AND NVL(OLD_DES_DATE.GPITYPTRIB, 'XXX') = NVL(REQ.GPITYPTRIB, 'XXX')
            AND NVL(OLD_DES_DATE.ST24, 'XXX') = NVL(REQ.ST24, 'XXX')
            AND NVL(OLD_DES_DATE.ST41, 'XXX') = NVL(REQ.ST41, 'XXX')
            AND OLD_DES_DATE.DT04_DT = ( SELECT MIN(DT04_DT)
                                           FROM G_PIECE
                                          WHERE TYPPIECE = 'REQUEST_LIMITE'
                                            AND TYPEDOC = :B2
                                            AND NVL(GPITYPTRIB, 'XXX') = NVL(REQ.GPITYPTRIB, 'XXX')
                                            AND NVL(ST24, 'XXX') = NVL(REQ.ST24, 'XXX')
                                            AND NVL(ST41, 'XXX') = NVL(REQ.ST41, 'XXX') ) ) LIM;
/********************************OLD SQL*******************************************/
/********************************OLD Metrics***************************************/
/*
MODULE                           SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
EXPORT_RISK_EXPOSURE                                            1530      63483                      2024/11/04 22:22:24  2024/11/04 23:19:14         334               270324 +000000000 00:56:49.984 56%

MODULE                           SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
EXPORT_RISK_EXPOSURE                                            1530      63483 ON CPU               2024/11/04 22:24:17  2024/11/04 23:18:33         119               216296 +000000000 00:54:16.321 36%
EXPORT_RISK_EXPOSURE                                            1530      63483 db file sequential r 2024/11/04 22:22:24  2024/11/04 23:19:14          76               270324 +000000000 00:56:49.984 23%
EXPORT_RISK_EXPOSURE                                            1530      63483 db file parallel rea 2024/11/04 22:23:05  2024/11/04 23:19:04          73                 2455 +000000000 00:55:58.784 22%
EXPORT_RISK_EXPOSURE             7fh5vznmr62km 3358219523       1530      63483 direct path read     2024/11/04 22:22:34  2024/11/04 22:40:29          64                    1 +000000000 00:17:55.200 19%
EXPORT_RISK_EXPOSURE                                            1530      63483 db file scattered re 2024/11/04 22:25:08  2024/11/04 23:16:20           2                   42 +000000000 00:51:12.000 1%

MODULE                           SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
EXPORT_RISK_EXPOSURE             7fh5vznmr62km 3358219523       1530      63483                      2024/11/04 22:22:34  2024/11/04 22:40:29         106                    1 +000000000 00:17:55.200 32%
EXPORT_RISK_EXPOSURE             2zzchcgxg1btv  197384675       1530      63483                      2024/11/04 22:41:10  2024/11/04 23:19:14          45                   60 +000000000 00:38:03.584 13%
EXPORT_RISK_EXPOSURE             b7dkkspfxqq7x  545253794       1530      63483 ON CPU               2024/11/04 22:43:03  2024/11/04 23:18:33          44                 9841 +000000000 00:35:29.921 13%

SQL_ID            ELAPSED MAX_WAIT_ON     PC_OF  WAIT_TIME            GETS      READS       ROWS  ELAP/EXEC       GETS/EXEC READS/EXEC  ROWS/EXEC       EXEC PLAN_HASH_VALUE
------------- ----------- --------------- ----- ---------- --------------- ---------- ---------- ---------- --------------- ---------- ---------- ---------- ---------------
7fh5vznmr62km        1086 IO              98%   1088.64495         3870752    3517148       6400    1086.18         3870752    3517148       6400          1      3358219523
2zzchcgxg1btv         430 IO              98%   433.146893          448055     222941         65       6.62            6893    3429.86          1         65       197384675
b7dkkspfxqq7x         442 CPU             99%   438.548787       243003958       4897       9849        .04           24425        .49        .99       9949       545253794     



SQL_ID        SQL_PLAN_HASH_VALUE SQL_PLAN_LINE_ID SQL_PLAN_OPERATION             SQL_PLAN_OPTIONS                   ACTIVE
------------- ------------------- ---------------- ------------------------------ ------------------------------ ----------
b7dkkspfxqq7x           545253794               12 TABLE ACCESS                   BY INDEX ROWID BATCHED                 22
b7dkkspfxqq7x           545253794               10 TABLE ACCESS                   BY INDEX ROWID                         19
b7dkkspfxqq7x           545253794                5 NESTED LOOPS                                                           1
b7dkkspfxqq7x           545253794                9 INDEX                          RANGE SCAN                              1
b7dkkspfxqq7x           545253794               13 INDEX                          RANGE SCAN                              1

Plan hash value: 545253794
----------------------------------------------------------------------------------------------------------
| Id  | Operation                                 | Name         | Rows  | Bytes | Cost (%CPU)| Time     |
----------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                          |              |       |       |     9 (100)|          |
|   1 |  VIEW                                     |              |     3 |    93 |     9   (0)| 00:00:01 |
|   2 |   UNION-ALL                               |              |       |       |            |          |
|   3 |    FILTER                                 |              |       |       |            |          |
|   4 |     FILTER                                |              |       |       |            |          |
|   5 |      NESTED LOOPS                         |              |     1 |    72 |     2   (0)| 00:00:01 |
|   6 |       NESTED LOOPS                        |              |    14 |    72 |     2   (0)| 00:00:01 |
|   7 |        TABLE ACCESS BY INDEX ROWID BATCHED| G_PIECE      |     1 |    33 |     1   (0)| 00:00:01 |
|   8 |         INDEX RANGE SCAN                  | PIE_REFPIECE |     1 |       |     1   (0)| 00:00:01 |
|   9 |        INDEX RANGE SCAN                   | GP_TYPEDOC   |    14 |       |     1   (0)| 00:00:01 |
|  10 |       TABLE ACCESS BY INDEX ROWID         | G_PIECE      |     1 |    39 |     1   (0)| 00:00:01 |
|  11 |     SORT AGGREGATE                        |              |     1 |    34 |            |          |
|  12 |      TABLE ACCESS BY INDEX ROWID BATCHED  | G_PIECE      |     1 |    34 |     1   (0)| 00:00:01 |
|  13 |       INDEX RANGE SCAN                    | GP_TYPEDOC   |    14 |       |     1   (0)| 00:00:01 |
|  14 |    FILTER                                 |              |       |       |            |          |
|  15 |     FILTER                                |              |       |       |            |          |
|  16 |      NESTED LOOPS                         |              |     1 |    64 |     2   (0)| 00:00:01 |
|  17 |       NESTED LOOPS                        |              |    14 |    64 |     2   (0)| 00:00:01 |
|  18 |        TABLE ACCESS BY INDEX ROWID BATCHED| G_PIECE      |     1 |    29 |     1   (0)| 00:00:01 |
|  19 |         INDEX RANGE SCAN                  | PIE_REFPIECE |     1 |       |     1   (0)| 00:00:01 |
|  20 |        INDEX RANGE SCAN                   | GP_TYPEDOC   |    14 |       |     1   (0)| 00:00:01 |
|  21 |       TABLE ACCESS BY INDEX ROWID         | G_PIECE      |    13 |   455 |     1   (0)| 00:00:01 |
|  22 |     SORT AGGREGATE                        |              |     1 |    30 |            |          |
|  23 |      TABLE ACCESS BY INDEX ROWID BATCHED  | G_PIECE      |     1 |    30 |     1   (0)| 00:00:01 |
|  24 |       INDEX RANGE SCAN                    | GP_TYPEDOC   |    14 |       |     1   (0)| 00:00:01 |
|  25 |    FILTER                                 |              |       |       |            |          |
|  26 |     FILTER                                |              |       |       |            |          |
|  27 |      NESTED LOOPS                         |              |     1 |    64 |     2   (0)| 00:00:01 |
|  28 |       NESTED LOOPS                        |              |    14 |    64 |     2   (0)| 00:00:01 |
|  29 |        TABLE ACCESS BY INDEX ROWID BATCHED| G_PIECE      |     1 |    29 |     1   (0)| 00:00:01 |
|  30 |         INDEX RANGE SCAN                  | PIE_REFPIECE |     1 |       |     1   (0)| 00:00:01 |
|  31 |        INDEX RANGE SCAN                   | GP_TYPEDOC   |    14 |       |     1   (0)| 00:00:01 |
|  32 |       TABLE ACCESS BY INDEX ROWID         | G_PIECE      |    13 |   455 |     1   (0)| 00:00:01 |
|  33 |     SORT AGGREGATE                        |              |     1 |    30 |            |          |
|  34 |      TABLE ACCESS BY INDEX ROWID BATCHED  | G_PIECE      |     1 |    30 |     1   (0)| 00:00:01 |
|  35 |       INDEX RANGE SCAN                    | GP_TYPEDOC   |    14 |       |     1   (0)| 00:00:01 |
----------------------------------------------------------------------------------------------------------
*/
/********************************OLD Metrics***************************************/

/********************************New SQL*******************************************/

SELECT MT02, DT04_DT, GPIDTFIN_DT
  FROM ( SELECT /*+ leading(REQ OLD_DES_DATE) index(OLD_DES_DATE PIE_GPILIBLIBRE) */
                OLD_DES_DATE.MT02        MT02,
                OLD_DES_DATE.DT04_DT     DT04_DT,
                OLD_DES_DATE.GPIDTFIN_DT GPIDTFIN_DT
           FROM G_PIECE REQ, 
                G_PIECE OLD_DES_DATE
          WHERE :B2 = 'C'
            AND REQ.TYPPIECE = 'REQUEST_LIMITE'
            AND REQ.REFPIECE = :B1
            AND OLD_DES_DATE.TYPEDOC = 'C'
            AND OLD_DES_DATE.TYPPIECE = 'REQUEST_LIMITE'
            AND OLD_DES_DATE.GPILIBLIBRE = REQ.GPILIBLIBRE
            AND OLD_DES_DATE.DT04_DT = ( SELECT /*+ index(G_PIECE PIE_GPILIBLIBRE) */
                                                MIN(DT04_DT)
                                           FROM G_PIECE
                                          WHERE TYPPIECE = 'REQUEST_LIMITE'
                                            AND TYPEDOC = 'C'
                                            AND GPILIBLIBRE =  REQ.GPILIBLIBRE )
         UNION ALL
         SELECT /*+ leading(REQ OLD_DES_DATE) index(OLD_DES_DATE PIE_ST41_FUNC_IDX) */
                OLD_DES_DATE.MT02        MT02,
                OLD_DES_DATE.DT04_DT     DT04_DT,
                OLD_DES_DATE.GPIDTFIN_DT GPIDTFIN_DT
           FROM G_PIECE REQ, 
                G_PIECE OLD_DES_DATE
          WHERE :B2 = 'DGCF'
            AND REQ.TYPPIECE = 'REQUEST_LIMITE'
            AND REQ.REFPIECE = :B1
            AND OLD_DES_DATE.TYPEDOC = 'DGCF'
            AND OLD_DES_DATE.TYPPIECE = 'REQUEST_LIMITE'
            AND NVL( OLD_DES_DATE.GPITYPTRIB, 'XXX' ) = NVL(REQ.GPITYPTRIB, 'XXX')
            AND NVL( OLD_DES_DATE.GPIDEPOT, 'XXX' ) = NVL(REQ.GPIDEPOT, 'XXX')
            AND NVL( OLD_DES_DATE.ST41, NULL ) = REQ.ST41
            AND OLD_DES_DATE.DT04_DT = ( SELECT /*+ index(G_PIECE PIE_ST41_FUNC_IDX) */
                                                MIN(DT04_DT)
                                           FROM G_PIECE
                                          WHERE TYPPIECE = 'REQUEST_LIMITE'
                                            AND TYPEDOC = 'DGCF'
                                            AND NVL( GPITYPTRIB, 'XXX' ) = NVL( REQ.GPITYPTRIB, 'XXX' )
                                            AND NVL( GPIDEPOT, 'XXX' ) = NVL( REQ.GPIDEPOT, 'XXX' )
                                            AND NVL( ST41, NULL ) = REQ.ST41 )
         UNION ALL
         SELECT /*+ leading(REQ OLD_DES_DATE) index(OLD_DES_DATE PIE_ST41_FUNC_IDX) */
                OLD_DES_DATE.MT02        MT02,
                OLD_DES_DATE.DT04_DT     DT04_DT,
                OLD_DES_DATE.GPIDTFIN_DT GPIDTFIN_DT
           FROM G_PIECE REQ, 
                G_PIECE OLD_DES_DATE
          WHERE :B2 = 'DGCGF'
            AND REQ.TYPPIECE = 'REQUEST_LIMITE'
            AND REQ.REFPIECE = :B1
            AND OLD_DES_DATE.TYPEDOC = :B2
            AND OLD_DES_DATE.TYPPIECE = 'REQUEST_LIMITE'
            AND NVL( OLD_DES_DATE.GPITYPTRIB, 'XXX' ) = NVL( REQ.GPITYPTRIB, 'XXX' )
            AND NVL( OLD_DES_DATE.ST24, 'XXX' ) = NVL( REQ.ST24, 'XXX' )
            AND NVL( OLD_DES_DATE.ST41, NULL ) = REQ.ST41
            AND OLD_DES_DATE.DT04_DT = ( SELECT /*+ index(G_PIECE PIE_ST41_FUNC_IDX) */
                                                MIN(DT04_DT)
                                           FROM G_PIECE
                                          WHERE TYPPIECE = 'REQUEST_LIMITE'
                                            AND TYPEDOC = :B2
                                            AND NVL( GPITYPTRIB, 'XXX' ) = NVL( REQ.GPITYPTRIB, 'XXX' )
                                            AND NVL( ST24, 'XXX' ) = NVL( REQ.ST24, 'XXX' )
                                            AND NVL( ST41, NULL ) = REQ.ST41 ) ) LIM;
/********************************New SQL*******************************************/
/********************************New Metrics***************************************/
/*
Plan hash value: 366981529
-----------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                 | Name              | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  |
-----------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                          |                   |      1 |        |    10 (100)|      1 |00:00:00.09 |     564 |     39 |
|   1 |  VIEW                                     |                   |      1 |      3 |    10  (10)|      1 |00:00:00.09 |     564 |     39 |
|   2 |   UNION-ALL                               |                   |      1 |        |            |      1 |00:00:00.09 |     564 |     39 |
|*  3 |    VIEW                                   | VW_WIF_1          |      1 |      1 |     4  (25)|      1 |00:00:00.09 |     564 |     39 |
|   4 |     WINDOW SORT                           |                   |      1 |      1 |     4  (25)|    550 |00:00:00.09 |     564 |     39 |
|*  5 |      FILTER                               |                   |      1 |        |            |    550 |00:00:00.09 |     564 |     39 |
|   6 |       NESTED LOOPS                        |                   |      1 |      1 |     3   (0)|    550 |00:00:00.09 |     564 |     39 |
|*  7 |        TABLE ACCESS BY INDEX ROWID BATCHED| G_PIECE           |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       4 |      0 |
|*  8 |         INDEX RANGE SCAN                  | PIE_REFPIECE      |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |      0 |
|*  9 |        TABLE ACCESS BY INDEX ROWID BATCHED| G_PIECE           |      1 |        |            |    550 |00:00:00.09 |     560 |     39 |
|* 10 |         INDEX RANGE SCAN                  | PIE_GPILIBLIBRE   |      1 |   1714 |     1   (0)|    555 |00:00:00.05 |       6 |      5 |
|* 11 |    FILTER                                 |                   |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
|* 12 |     FILTER                                |                   |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  13 |      NESTED LOOPS                         |                   |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 14 |       TABLE ACCESS BY INDEX ROWID BATCHED | G_PIECE           |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 15 |        INDEX RANGE SCAN                   | PIE_REFPIECE      |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 16 |       TABLE ACCESS BY INDEX ROWID BATCHED | G_PIECE           |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 17 |        INDEX RANGE SCAN                   | PIE_ST41_FUNC_IDX |      0 |     16 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|  18 |     SORT AGGREGATE                        |                   |      0 |      1 |            |      0 |00:00:00.01 |       0 |      0 |
|* 19 |      TABLE ACCESS BY INDEX ROWID BATCHED  | G_PIECE           |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 20 |       INDEX RANGE SCAN                    | PIE_ST41_FUNC_IDX |      0 |     16 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 21 |    FILTER                                 |                   |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
|* 22 |     FILTER                                |                   |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  23 |      NESTED LOOPS                         |                   |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 24 |       TABLE ACCESS BY INDEX ROWID BATCHED | G_PIECE           |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 25 |        INDEX RANGE SCAN                   | PIE_REFPIECE      |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 26 |       TABLE ACCESS BY INDEX ROWID BATCHED | G_PIECE           |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 27 |        INDEX RANGE SCAN                   | PIE_ST41_FUNC_IDX |      0 |     16 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|  28 |     SORT AGGREGATE                        |                   |      0 |      1 |            |      0 |00:00:00.01 |       0 |      0 |
|* 29 |      TABLE ACCESS BY INDEX ROWID BATCHED  | G_PIECE           |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 30 |       INDEX RANGE SCAN                    | PIE_ST41_FUNC_IDX |      0 |     16 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
-----------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   3 - filter("VW_COL_4" IS NOT NULL)
   5 - filter(:B2='C')
   7 - filter("REQ"."TYPPIECE"='REQUEST_LIMITE')
   8 - access("REQ"."REFPIECE"=:B1)
   9 - filter(("OLD_DES_DATE"."TYPPIECE"='REQUEST_LIMITE' AND "OLD_DES_DATE"."TYPEDOC"='C'))
  10 - access("OLD_DES_DATE"."GPILIBLIBRE"="REQ"."GPILIBLIBRE")
  11 - filter("OLD_DES_DATE"."DT04_DT"=)
  12 - filter(:B2='DGCF')
  14 - filter(("REQ"."ST41" IS NOT NULL AND "REQ"."TYPPIECE"='REQUEST_LIMITE'))
  15 - access("REQ"."REFPIECE"=:B1)
  16 - filter(("OLD_DES_DATE"."TYPPIECE"='REQUEST_LIMITE' AND "OLD_DES_DATE"."TYPEDOC"='DGCF' AND
              NVL("OLD_DES_DATE"."GPIDEPOT",'XXX')=NVL("REQ"."GPIDEPOT",'XXX') AND
              NVL("OLD_DES_DATE"."GPITYPTRIB",'XXX')=NVL("REQ"."GPITYPTRIB",'XXX')))
  17 - access("OLD_DES_DATE"."SYS_NC00793$"="REQ"."ST41")
       filter("OLD_DES_DATE"."SYS_NC00793$" IS NOT NULL)
  19 - filter(("TYPPIECE"='REQUEST_LIMITE' AND "TYPEDOC"='DGCF' AND "DT04_DT" IS NOT NULL AND NVL("GPIDEPOT",'XXX')=NVL(:B1,'XXX') AND
              NVL("GPITYPTRIB",'XXX')=NVL(:B2,'XXX')))
  20 - access("G_PIECE"."SYS_NC00793$"=:B1)
  21 - filter("OLD_DES_DATE"."DT04_DT"=)
  22 - filter(:B2='DGCGF')
  24 - filter(("REQ"."ST41" IS NOT NULL AND "REQ"."TYPPIECE"='REQUEST_LIMITE'))
  25 - access("REQ"."REFPIECE"=:B1)
  26 - filter(("OLD_DES_DATE"."TYPPIECE"='REQUEST_LIMITE' AND "OLD_DES_DATE"."TYPEDOC"=:B2 AND
              NVL("OLD_DES_DATE"."GPITYPTRIB",'XXX')=NVL("REQ"."GPITYPTRIB",'XXX') AND NVL("OLD_DES_DATE"."ST24",'XXX')=NVL("REQ"."ST24",'XXX')))
  27 - access("OLD_DES_DATE"."SYS_NC00793$"="REQ"."ST41")
       filter("OLD_DES_DATE"."SYS_NC00793$" IS NOT NULL)
  29 - filter(("TYPPIECE"='REQUEST_LIMITE' AND "TYPEDOC"=:B2 AND "DT04_DT" IS NOT NULL AND NVL("ST24",'XXX')=NVL(:B1,'XXX') AND
              NVL("GPITYPTRIB",'XXX')=NVL(:B2,'XXX')))
  30 - access("G_PIECE"."SYS_NC00793$"=:B1)

*/
/********************************New Metrics***************************************/

/********************************Index statistics**********************************/

/********************************Other SQLs****************************************/          
/*

*/ 
/********************************Other SQLs****************************************/              
