/********************************************************************************
*********       E-mail subject: EFEURDEV-6368
*********             Instance: UAT_AD
*********          Description: 
Problem:
SQL g8fqt4xyg1au9 was working over 25h on UAT_AD.

Analysis:
I checked the work of SQL g8fqt4xyg1au9 in the ETL_AD module and as it can be seen in its execution plan, the heaviest part is accessing AD_REQUEST_LIMIT_MVIEW through index AD_REQ_LIMIT_IND 
using NESTED LOOPS. The better way here is to use FULL SCAN and HASH JOIN for AD_REQUEST_LIMIT_MVIEW instead of the NESTED LOOPS. I added hint to force Oracle to do it and the query finished 
under 1 minute.

Suggestion:
Please add hint as it is shown in the New SQL section below.

*********               SQL_ID: g8fqt4xyg1au9
*********      Program/Package: 
*********              Request: Elena Vasileva
*********               Author: Dimitar Dimitrov
********* Received e-mail date: 14/02/2025
*********      Resolution date: 14/02/2025
*********  Trace old file here: \\epox\specifs\performance\tmp\
*********  Trace new file here:
***********************************************************************************/

/********************************OLD SQL*******************************************/

CREATE MATERIALIZED VIEW AD_POLICE_CONTRACT_MVIEW
REFRESH FORCE ON DEMAND
DISABLE QUERY REWRITE
AS
SELECT DISTINCT debtor.debtor_refindividu AS debtor_ref,
                debtor.debtor_refext AS debtor_refext,
                (CASE
                  WHEN request.typedoc = 'G' THEN
                   NULL
                  ELSE
                   client.client_refindividu
                END) AS client_ref,
                (CASE
                  WHEN request.typedoc = 'G' THEN
                   NULL
                  ELSE
                   client.client_nom
                END) AS client_name,
                debtor.debtor_nom AS debtor_name,
                debtor.debtor_pays AS debtor_country,
                (CASE
                  WHEN request.typedoc = 'G' THEN
                   NULL
                  ELSE
                   db_cl.ancrefdoss
                END) AS contract_number,
                (CASE
                  WHEN request.typedoc = 'G' THEN
                   NULL
                  ELSE
                   db_cl.contract
                END) AS contract_case,
                (CASE
                  WHEN request.typedoc = 'G' THEN
                   NULL
                  ELSE
                   case_contract.contract_type
                END) AS contract_type,
                nvl(police.gpidevis, ad_get_sys_ccy()) AS police_ccy,
                police.refext AS police_number,
                police.refdoss AS police_case,
                police.str_20_1 AS police_type,
                police.refpiece || debtor.debtor_pays AS ref_country,
                factor.pays AS factor_country,
                request.libelle_20_7 AS credit_insurer,
                police.refpiece AS ref_policy,
                request.dt04_dt AS dtdecision_dt,
                request.gpidate1_dt AS dtcancel_dt,
                request.mt02 AS app_limit,
                request.code AS app_limit_ccy,
                request.typedoc AS limit_type,
                request.gpidtdeb_dt AS limit_start_validity_date,
                request.gpidtfin_dt AS limit_end_validity_date
  FROM ad_account_debtor_client db_cl,
       ad_debtors               debtor,
       ad_clients               client,
       ad_factors               factor,
       ad_case_contrat          case_contract,
       ad_request_limit_mview   request,
       g_piece                  police
 WHERE debtor.debtor_refindividu = db_cl.debtor
   AND case_contract.refdoss = db_cl.contract
   AND client.client_refindividu = db_cl.client
   AND factor.refindividu = db_cl.factor
   AND case_contract.fg_coverage = 'O'
   AND debtor.debtor_refindividu = request.gpiadr3
   AND request.libelle_100_8 = police.refpiece
   AND police.typpiece = 'POLICE'
   AND request.gpirole IN ('DC', 'DT')
   AND request.gpityppiece IN ('AP', 'PA', 'CA', 'PCA')
   AND request.typedoc IN ('C', 'G')
   AND ( CASE WHEN   request.typedoc = 'C' 
               AND ( request.gpiliblibre LIKE 'L1.' || debtor.debtor_refindividu || '.' || client.client_refindividu || '.' || factor.refindividu || '%') 
              THEN 1
              WHEN   request.typedoc = 'G' 
               AND ( request.gpiliblibre LIKE 'L1.' || debtor.debtor_refindividu || '..' || factor.refindividu || '%') 
              THEN  1
           ELSE 0
          END ) = 1;
/********************************OLD SQL*******************************************/
/********************************OLD Metrics***************************************/
/*

MODULE                           PROGRAM                                            CLIENT_ID       SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- -------------------------------------------------- --------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
ETL_AD                           sqlplus                                                            g8fqt4xyg1au9          0        282      32472 ON CPU               2025/02/13 08:00:03  2025/02/14 09:00:11        8998                    1 +000000001 01:00:07.967 85%
ADv2 DASHBOARD                                                                                                                                     ON CPU               2025/02/13 08:04:43  2025/02/14 08:55:51        1507                15671 +000000001 00:51:07.743 14%
MMON_SLAVE                                                                                                                                         ON CPU               2025/02/13 08:06:23  2025/02/14 08:07:59          34                  283 +000000001 00:01:36.110 0%


MODULE                           PROGRAM                                            CLIENT_ID       SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- -------------------------------------------------- --------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
ETL_AD                           sqlplus                                                            g8fqt4xyg1au9          0        282      32472 ON CPU               2025/02/13 08:00:03  2025/02/14 09:00:11        8998                    1 +000000001 01:00:07.967 100%


MODULE                           PROGRAM                                            CLIENT_ID       SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM     TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- -------------------------------------------------- --------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
ETL_AD                           sqlplus                                                            g8fqt4xyg1au9          0        282      32472 ON CPU               2025/02/13 08:00:03  2025/02/14 09:00:11    8998                    1 +000000001 01:00:07.967 100%


INSTANCE_NUMBER SQL_ID            ELAPSED MAX_WAIT_ON     PC_OF  WAIT_TIME            GETS      READS       ROWS  ELAP/EXEC       GETS/EXEC READS/EXEC  ROWS/EXEC       EXEC PLAN_HASH_VALUE
--------------- ------------- ----------- --------------- ----- ---------- --------------- ---------- ---------- ---------- --------------- ---------- ---------- ---------- ---------------
              1 g8fqt4xyg1au9       90015 CPU             100%  89481.8367      2453848889       1320          0   90014.82      2453848889       1320          0          0   0



Plan hash value: 1837301075
--------------------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                   | Name                     | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  |
--------------------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                            |                          |      1 |        | 61068 (100)|      0 |00:00:00.01 |       0 |      0 |
|   1 |  HASH UNIQUE                                |                          |      1 |     57 | 61068   (1)|      0 |00:00:00.01 |       0 |      0 |
|   2 |   NESTED LOOPS                              |                          |      1 |     57 | 61067   (1)|   1117 |00:06:01.21 |      10M|   6780 |
|   3 |    NESTED LOOPS                             |                          |      1 |     66 | 61067   (1)|   1117 |00:06:01.19 |      10M|   6780 |
|   4 |     NESTED LOOPS                            |                          |      1 |     66 | 60935   (1)|   1119 |00:06:01.17 |      10M|   6780 |
|*  5 |      HASH JOIN                              |                          |      1 |   5973 |  1446   (1)|    280 |00:00:02.74 |    7178 |   6780 |
|   6 |       TABLE ACCESS FULL                     | AD_CLIENTS               |      1 |   1217 |    12   (0)|   5049 |00:00:00.01 |      93 |      0 |
|*  7 |       HASH JOIN                             |                          |      1 |   5973 |  1434   (1)|    280 |00:00:02.73 |    7085 |   6780 |
|   8 |        TABLE ACCESS FULL                    | AD_FACTORS               |      1 |     12 |     4   (0)|     12 |00:00:00.01 |       6 |      0 |
|*  9 |        HASH JOIN                            |                          |      1 |   5973 |  1430   (1)|    280 |00:00:02.73 |    7079 |   6780 |
|* 10 |         HASH JOIN                           |                          |      1 |   5984 |   808   (1)|    439K|00:00:02.09 |    7073 |   6775 |
|* 11 |          TABLE ACCESS FULL                  | AD_CASE_CONTRAT          |      1 |     60 |    79   (0)|   5540 |00:00:00.01 |     212 |      1 |
|  12 |          TABLE ACCESS FULL                  | AD_ACCOUNT_DEBTOR_CLIENT |      1 |    127K|   728   (1)|    451K|00:00:01.78 |    6861 |   6774 |
|  13 |         TABLE ACCESS FULL                   | AD_DEBTORS               |      1 |  96392 |   622   (1)|    231 |00:00:00.01 |       6 |      5 |
|  14 |      INLIST ITERATOR                        |                          |    280 |        |            |   1119 |00:05:58.43 |      10M|      0 |
|* 15 |       MAT_VIEW ACCESS BY INDEX ROWID BATCHED| AD_REQUEST_LIMIT_MVIEW   |   2233 |      1 |    10   (0)|   1119 |00:05:58.42 |      10M|      0 |
|* 16 |        INDEX RANGE SCAN                     | AD_REQ_LIMIT_IND         |   2233 |      1 |     9   (0)|    204M|00:01:48.06 |     515K|      0 |
|* 17 |     INDEX UNIQUE SCAN                       | G_PIECE_PK               |   1119 |      1 |     1   (0)|   1117 |00:00:00.02 |     995 |      0 |
|* 18 |    TABLE ACCESS BY INDEX ROWID              | G_PIECE                  |   1117 |      1 |     2   (0)|   1117 |00:00:00.02 |    1311 |      0 |
--------------------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   5 - access("CLIENT"."CLIENT_REFINDIVIDU"="DB_CL"."CLIENT")
   7 - access("FACTOR"."REFINDIVIDU"="DB_CL"."FACTOR")
   9 - access("DEBTOR"."DEBTOR_REFINDIVIDU"="DB_CL"."DEBTOR")
  10 - access("CASE_CONTRACT"."REFDOSS"="DB_CL"."CONTRACT")
  11 - filter("CASE_CONTRACT"."FG_COVERAGE"='O')
  15 - filter(("DEBTOR"."DEBTOR_REFINDIVIDU"="REQUEST"."GPIADR3" AND CASE  WHEN ("REQUEST"."TYPEDOC"='C' AND "REQUEST"."GPILIBLIBRE" LIKE
              'L1.'||"DEBTOR"."DEBTOR_REFINDIVIDU"||'.'||"CLIENT"."CLIENT_REFINDIVIDU"||'.'||"FACTOR"."REFINDIVIDU"||'%') THEN 1 WHEN
              ("REQUEST"."TYPEDOC"='G' AND "REQUEST"."GPILIBLIBRE" LIKE 'L1.'||"DEBTOR"."DEBTOR_REFINDIVIDU"||'..'||"FACTOR"."REFINDIVIDU"||'%') THEN 1 ELSE
              0 END =1))
  16 - access((("REQUEST"."GPIROLE"='DC' OR "REQUEST"."GPIROLE"='DT')) AND (("REQUEST"."GPITYPPIECE"='AP' OR "REQUEST"."GPITYPPIECE"='CA' OR
              "REQUEST"."GPITYPPIECE"='PA' OR "REQUEST"."GPITYPPIECE"='PCA')))
       filter(("REQUEST"."TYPEDOC"='C' OR "REQUEST"."TYPEDOC"='G'))
  17 - access("REQUEST"."LIBELLE_100_8"="POLICE"."REFPIECE")
  18 - filter("POLICE"."TYPPIECE"='POLICE')
*/
/********************************OLD Metrics***************************************/

/********************************New SQL*******************************************/

CREATE MATERIALIZED VIEW AD_POLICE_CONTRACT_MVIEW
REFRESH FORCE ON DEMAND
DISABLE QUERY REWRITE
AS
SELECT /*+ full(request) use_hash(request) use_hash(police)*/
       DISTINCT debtor.debtor_refindividu AS debtor_ref,
                debtor.debtor_refext AS debtor_refext,
                (CASE
                  WHEN request.typedoc = 'G' THEN
                   NULL
                  ELSE
                   client.client_refindividu
                END) AS client_ref,
                (CASE
                  WHEN request.typedoc = 'G' THEN
                   NULL
                  ELSE
                   client.client_nom
                END) AS client_name,
                debtor.debtor_nom AS debtor_name,
                debtor.debtor_pays AS debtor_country,
                (CASE
                  WHEN request.typedoc = 'G' THEN
                   NULL
                  ELSE
                   db_cl.ancrefdoss
                END) AS contract_number,
                (CASE
                  WHEN request.typedoc = 'G' THEN
                   NULL
                  ELSE
                   db_cl.contract
                END) AS contract_case,
                (CASE
                  WHEN request.typedoc = 'G' THEN
                   NULL
                  ELSE
                   case_contract.contract_type
                END) AS contract_type,
                nvl(police.gpidevis, ad_get_sys_ccy()) AS police_ccy,
                police.refext AS police_number,
                police.refdoss AS police_case,
                police.str_20_1 AS police_type,
                police.refpiece || debtor.debtor_pays AS ref_country,
                factor.pays AS factor_country,
                request.libelle_20_7 AS credit_insurer,
                police.refpiece AS ref_policy,
                request.dt04_dt AS dtdecision_dt,
                request.gpidate1_dt AS dtcancel_dt,
                request.mt02 AS app_limit,
                request.code AS app_limit_ccy,
                request.typedoc AS limit_type,
                request.gpidtdeb_dt AS limit_start_validity_date,
                request.gpidtfin_dt AS limit_end_validity_date
  FROM ad_account_debtor_client db_cl,
       ad_debtors               debtor,
       ad_clients               client,
       ad_factors               factor,
       ad_case_contrat          case_contract,
       ad_request_limit_mview   request,
       g_piece                  police
 WHERE debtor.debtor_refindividu = db_cl.debtor
   AND case_contract.refdoss = db_cl.contract
   AND client.client_refindividu = db_cl.client
   AND factor.refindividu = db_cl.factor
   AND case_contract.fg_coverage = 'O'
   AND debtor.debtor_refindividu = request.gpiadr3
   AND request.libelle_100_8 = police.refpiece
   AND police.typpiece = 'POLICE'
   AND request.gpirole IN ('DC', 'DT')
   AND request.gpityppiece IN ('AP', 'PA', 'CA', 'PCA')
   AND request.typedoc IN ('C', 'G')
   AND ( CASE WHEN   request.typedoc = 'C' 
               AND ( request.gpiliblibre LIKE 'L1.' || debtor.debtor_refindividu || '.' || client.client_refindividu || '.' || factor.refindividu || '%') 
              THEN 1
              WHEN   request.typedoc = 'G' 
               AND ( request.gpiliblibre LIKE 'L1.' || debtor.debtor_refindividu || '..' || factor.refindividu || '%') 
              THEN  1
           ELSE 0
          END ) = 1;
/********************************New SQL*******************************************/
/********************************New Metrics***************************************/
/*
Plan hash value: 3694914065
------------------------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                              | Name                     | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  | Writes |
------------------------------------------------------------------------------------------------------------------------------------------------------------
|   0 | CREATE TABLE STATEMENT                 |                          |      1 |        |   144K(100)|      0 |00:00:52.79 |    4951K|   1363 |  11880 |
|   1 |  LOAD AS SELECT                        | TEST_DD_TEMP_TABLE       |      1 |        |            |      0 |00:00:52.79 |    4951K|   1363 |  11880 |
|   2 |   HASH UNIQUE                          |                          |      1 |     57 |   144K  (1)|    683K|00:00:48.43 |    4903K|   1358 |   1358 |
|*  3 |    HASH JOIN                           |                          |      1 |     57 |   144K  (1)|    809K|00:00:10.37 |   49362 |      0 |      0 |
|   4 |     TABLE ACCESS BY INDEX ROWID BATCHED| G_PIECE                  |      1 |   2301 |   347   (1)|   2301 |00:00:00.01 |    3160 |      0 |      0 |
|*  5 |      INDEX RANGE SCAN                  | TYPPIECE_LASTLOAD_IND    |      1 |   2301 |    14   (0)|   2301 |00:00:00.01 |      17 |      0 |      0 |
|*  6 |     HASH JOIN                          |                          |      1 |     66 |   144K  (1)|    821K|00:00:09.67 |   46202 |      0 |      0 |
|   7 |      TABLE ACCESS FULL                 | AD_CLIENTS               |      1 |   1217 |    12   (0)|   5049 |00:00:00.01 |      93 |      0 |      0 |
|*  8 |      HASH JOIN                         |                          |      1 |  66188 |   144K  (1)|   1516K|00:00:06.10 |   46109 |      0 |      0 |
|   9 |       TABLE ACCESS FULL                | AD_FACTORS               |      1 |     12 |     4   (0)|     12 |00:00:00.01 |       6 |      0 |      0 |
|* 10 |       HASH JOIN                        |                          |      1 |  66188 |   144K  (1)|   1516K|00:00:05.13 |   46103 |      0 |      0 |
|* 11 |        HASH JOIN                       |                          |      1 |   5973 |  1430   (1)|    439K|00:00:01.28 |   11844 |      0 |      0 |
|* 12 |         HASH JOIN                      |                          |      1 |   5984 |   808   (1)|    439K|00:00:00.38 |    7073 |      0 |      0 |
|* 13 |          TABLE ACCESS FULL             | AD_CASE_CONTRAT          |      1 |     60 |    79   (0)|   5540 |00:00:00.01 |     212 |      0 |      0 |
|  14 |          TABLE ACCESS FULL             | AD_ACCOUNT_DEBTOR_CLIENT |      1 |    127K|   728   (1)|    451K|00:00:00.16 |    6861 |      0 |      0 |
|  15 |         TABLE ACCESS FULL              | AD_DEBTORS               |      1 |  96392 |   622   (1)|    310K|00:00:00.08 |    4771 |      0 |      0 |
|* 16 |        MAT_VIEW ACCESS FULL            | AD_REQUEST_LIMIT_MVIEW   |      1 |    817K| 12892   (1)|    733K|00:00:01.53 |   34259 |      0 |      0 |
------------------------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   3 - access("REQUEST"."LIBELLE_100_8"="POLICE"."REFPIECE")
   5 - access("POLICE"."TYPPIECE"='POLICE')
   6 - access("CLIENT"."CLIENT_REFINDIVIDU"="DB_CL"."CLIENT")
       filter(CASE  WHEN ("REQUEST"."TYPEDOC"='C' AND "REQUEST"."GPILIBLIBRE" LIKE
              'L1.'||"DEBTOR"."DEBTOR_REFINDIVIDU"||'.'||"CLIENT"."CLIENT_REFINDIVIDU"||'.'||"FACTOR"."REFINDIVIDU"||'%') THEN 1 WHEN ("REQUEST"."TYPEDOC"='G'
              AND "REQUEST"."GPILIBLIBRE" LIKE 'L1.'||"DEBTOR"."DEBTOR_REFINDIVIDU"||'..'||"FACTOR"."REFINDIVIDU"||'%') THEN 1 ELSE 0 END =1)
   8 - access("FACTOR"."REFINDIVIDU"="DB_CL"."FACTOR")
  10 - access("DEBTOR"."DEBTOR_REFINDIVIDU"="REQUEST"."GPIADR3")
  11 - access("DEBTOR"."DEBTOR_REFINDIVIDU"="DB_CL"."DEBTOR")
  12 - access("CASE_CONTRACT"."REFDOSS"="DB_CL"."CONTRACT")
  13 - filter("CASE_CONTRACT"."FG_COVERAGE"='O')
  16 - filter((INTERNAL_FUNCTION("REQUEST"."GPIROLE") AND INTERNAL_FUNCTION("REQUEST"."GPITYPPIECE") AND INTERNAL_FUNCTION("REQUEST"."TYPEDOC")))
*/
/********************************New Metrics***************************************/

/********************************Index statistics**********************************/

/********************************Other SQLs****************************************/          
/*

*/ 
/********************************Other SQLs****************************************/              
