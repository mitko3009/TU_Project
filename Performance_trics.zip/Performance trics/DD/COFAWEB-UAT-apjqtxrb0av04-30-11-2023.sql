/********************************************************************************
*********       E-mail subject: COFAWEB-7001
*********             Instance: UAT
*********          Description: 
Problem:
Slow SQL query was provided from COFACE UAT on 30/11/2023.

Analysis:
The problem was that Oracle was "afraid" to start the execution from I.nom LIKE :B21, because :B21 was equals to "YO%".
When using only two letters and % for search ( in this case "YO%") Oracle thinks that this will return a lot of rows and prefer to not start the execution from it.
The solution is to make some refactorization of the query and add hint to make Oracle start from I.nom LIKE :B21 and use a good execution plan.

Suggestion:
Please modify the query and add hint as it is shown in the New SQL section below.

*********               SQL_ID: apjqtxrb0av04
*********      Program/Package: 
*********              Request: Petar Gichev 
*********               Author: Dimitar Dimitrov
********* Received e-mail date: 30/11/2023
*********      Resolution date: 30/11/2023
*********  Trace old file here: \\epox\specifs\performance\tmp\
*********  Trace new file here:
***********************************************************************************/

/********************************OLD SQL*******************************************/
var B1 VARCHAR2(128);
exec :B1 := 'AN';
var B2 VARCHAR2(128);
exec :B2 := 'AN';
var B3 VARCHAR2(128);
exec :B3 := 'AN';
var B4 VARCHAR2(128);
exec :B4 := 'AN';
var B5 VARCHAR2(128);
exec :B5 := 'typencour';
var B6 VARCHAR2(128);
exec :B6 := 'AN';
var B7 VARCHAR2(521);
exec :B7 := 'APP;ARB;BAL;BP;CBRDB;CC;CL;CLO;COLLF;CONO1;CPR;CRM;CRNC;CTR;DELR;DIS;DP;ECA;ECAL;ENF;EOP;FCA;FN;FOR;FPAB;FPPDB;FPUDB;FRCL;FRDB;GPH;INR;INS;INS2;INVER;LSO;LTM;MWLA;OFP;OPI;ORP;PEND;PPI;RCP;RCT;REH;SLC;SPB;SPL;SPP;SPTSU;SPU;SUCL;SUSP;SUTSP;THC;UC;UP;WUP;YMF';
var B8 VARCHAR2(521);
exec :B8 := 'APP;ARB;BAL;BP;CBRDB;CC;CL;CLO;COLLF;CONO1;CPR;CRM;CRNC;CTR;DELR;DIS;DP;ECA;ECAL;ENF;EOP;FCA;FN;FOR;FPAB;FPPDB;FPUDB;FRCL;FRDB;GPH;INR;INS;INS2;INVER;LSO;LTM;MWLA;OFP;OPI;ORP;PEND;PPI;RCP;RCT;REH;SLC;SPB;SPL;SPP;SPTSU;SPU;SUCL;SUSP;SUTSP;THC;UC;UP;WUP;YMF';  
var B9 VARCHAR2(521);
exec :B9 := 'APP;ARB;BAL;BP;CBRDB;CC;CL;CLO;COLLF;CONO1;CPR;CRM;CRNC;CTR;DELR;DIS;DP;ECA;ECAL;ENF;EOP;FCA;FN;FOR;FPAB;FPPDB;FPUDB;FRCL;FRDB;GPH;INR;INS;INS2;INVER;LSO;LTM;MWLA;OFP;OPI;ORP;PEND;PPI;RCP;RCT;REH;SLC;SPB;SPL;SPP;SPTSU;SPU;SUCL;SUSP;SUTSP;THC;UC;UP;WUP;YMF';   
var B10 VARCHAR2(521);
exec :B10 := 'APP;ARB;BAL;BP;CBRDB;CC;CL;CLO;COLLF;CONO1;CPR;CRM;CRNC;CTR;DELR;DIS;DP;ECA;ECAL;ENF;EOP;FCA;FN;FOR;FPAB;FPPDB;FPUDB;FRCL;FRDB;GPH;INR;INS;INS2;INVER;LSO;LTM;MWLA;OFP;OPI;ORP;PEND;PPI;RCP;RCT;REH;SLC;SPB;SPL;SPP;SPTSU;SPU;SUCL;SUSP;SUTSP;THC;UC;UP;WUP;YMF'; 
var B11 VARCHAR2(128);
exec :B11 := 'categdoss'; 
var B12 VARCHAR2(128);
exec :B12 := 'SP';
var B13 VARCHAR2(128);
exec :B13 := 'intervenant'; 
var B14 VARCHAR2(128);
exec :B14 := 'SP';
var B15 VARCHAR2(128);
exec :B15 := 'SP';
var B16 VARCHAR2(128);
exec :B16 := 'PER'; 
var B17 VARCHAR2(128);
exec :B17 := 'DB';
var B18 VARCHAR2(128);
exec :B18 := '96000693';
var B19 VARCHAR2(128);
exec :B19 := '2023-01-01';
var B20 VARCHAR2(128);
exec :B20 := '2023-04-30';
var B21 VARCHAR2(128);
exec :B21 := 'YO%';
var B22 NUMBER;
exec :B22 := 2001;
var B23 NUMBER;
exec :B23 := 1;


WITH tpncr AS
 (SELECT /*+ materialize */
   *
    FROM (SELECT /*+ no_merge(pfx) leading(pfx) use_hash(v) */
           pfx.valeur || v.valeur pfx_valeur,
           pfx.valeur || v.valeur_trad valeur_trad
            FROM (SELECT 'PB: A.' valeur, 'f' f
                    FROM dual
                  UNION ALL
                  SELECT 'PB: ' valeur, 'f' f
                    FROM dual
                  UNION ALL
                  SELECT 'A.' valeur, 'f' f
                    FROM dual
                  UNION ALL
                  SELECT '' valeur, 'f' f
                    FROM dual) pfx,
                 (SELECT /*+ no_merge no_push_pred */
                   valeur, valeur_trad, 'f' f
                    FROM v_tdomaine
                   WHERE type = 'typencour'
                     AND langue = :B1) v
           WHERE v.f = pfx.f) fooo
   WHERE 1 = 1)
SELECT *
  FROM (SELECT /*+ first_rows(2001)*/
         foo.*, ROWNUM rnum
          FROM (SELECT (SELECT CMI.nom
                          FROM g_individu CMI, g_personnel CMP
                         WHERE CMP.refperso = D.rangmt
                           AND CMI.refindividu = CMP.refindividu
                           AND rownum = 1) caseManagerDisplay,
                       D.dtfingest_dt managementEndDate,
                       D.rangmt caseManager,
                       ATT.typencour caseStatus,
                       ATT.dtdeclench_dt dueDate,
                       (SELECT DECODE(COUNT(*), 0, 'false', 'true')
                          FROM DUAL
                         WHERE EXISTS
                         (SELECT 1
                                  FROM t_element_se
                                 WHERE refdoss = D.refdoss
                                   AND libelle IN
                                       (SELECT vt.valeur
                                          FROM v_domaine vt, v_domaine vf
                                         WHERE vt.type = 'typencour'
                                           AND vf.abrev16 = 'O'
                                           AND vf.type = 'filiere'
                                           AND vf.ecran = vt.abrev))) forbProcessFound,
                       (SELECT SMI.nom
                          FROM g_individu SMI, g_personnel SMP
                         WHERE SMP.refperso = ATT.catperso
                           AND SMI.refindividu = SMP.refindividu
                           AND rownum = 1) statusManagerDisplay,
                       D.refdoss internalCaseReference,
                       IDB.nom debtor,
                       D.soldedb caseBalance,
                       ICL.nom client,
                       (SELECT tpncr.valeur_trad
                          FROM tpncr
                         WHERE tpncr.pfx_valeur = ATT.typencour) caseStatusDisplay,
                       D.devise caseCurrency,
                       IMX.get_valeur('TYPE_MANDAT', D.typeOfMandate, :B2) typeOfMandate,
                       IMX.get_valeur('PHASE', D.phase, :B3) phase,
                       D.reflot_dos reflot_dos,
                       ATT.catperso statusManager,
                       D.pieceinit product,
                       D.ancrefdoss externalCaseReference,
                       IDB.siret debtorNrn,
                       D.initialAmount initialAmount,
                       (SELECT IMX.transl_valeur('piece', D.pieceinit, :B4)
                          FROM dual) productDisplay,
                       (count(D.refdoss) OVER()) totalRealCases,
                       D.caseManagerSu caseManagerSu,
                       (SUM(D.soldedb) OVER()) sumBalanceReal
                  FROM (SELECT D.rangmt,
                               D.ancrefdoss,
                               D.refdoss,
                               D.devise,
                               D.soldedb,
                               D.soldedb_dos,
                               D.dtfingest_dt,
                               D.reflot_dos,
                               D.reflot,
                               D.principal,
                               D.segment,
                               D.pieceinit,
                               D.monref,
                               D.dt_dt_dt,
                               D.dtcreation_dt,
                               D.categdoss,
                               D.stratif,
                               D.dt_dechterm_dt,
                               (SELECT ISU.nom
                                  FROM g_personnel PSU, g_individu ISU
                                 WHERE PSU.refperso = D.monref
                                   AND ISU.refindividu = PSU.refindividu) as caseManagerSu,
                               D.phase phase,
                               (SELECT SUM(FI.montant)
                                  FROM g_elemfi FI
                                 WHERE FI.refdoss = D.refdoss
                                   AND ((D.mig_reference IS NULL AND
                                       TRUNC(dtjour_dt) =
                                       NVL(TRUNC(D.dtcreation_dt),
                                             TRUNC(D.dt_dt_dt))) OR
                                       (D.mig_reference IS NOT NULL AND
                                       FI.createur = 'cfc_migration'))) as initialAmount,
                               (SELECT st24
                                  FROM g_piece
                                 WHERE refdoss = D.refdoss
                                   AND typpiece = 'RECOUVREMENT'
                                   AND ROWNUM = 1) as typeOfMandate,
                               (select decode((select count(*) flag_true
                                                from (select nvl(max(FG_INCL_NOT_DUE_ELEM_CASE_BAL),
                                                                 'N') flag
                                                        from g_bu
                                                       where refindividu =
                                                             (select refindividu
                                                                from t_intervenants
                                                               where refdoss =
                                                                     D.refdoss
                                                                 and reftype = 'BU')) g_bu_flag,
                                                     (select nvl(max(FG_TREAT_ALL_ELEMENTS_AS_DUE),
                                                                 'N') flag
                                                        from g_dossier
                                                       where refdoss = D.refdoss) g_doss_flag
                                               where g_bu_flag.flag = 'N'
                                                 and g_doss_flag.flag = 'N'),
                                              0,
                                              (select sum(nvl(mt_ouvert_mvt,
                                                              montant_dos))
                                                 from g_elemfi
                                                where refdoss = D.refdoss
                                                  and dtdebut <
                                                      to_char(sysdate, 'j')),
                                              (select cpt_util.getPostSum(D.refdoss,
                                                                          'SOLDEDB',
                                                                          (select dt_dt
                                                                             from g_dossier
                                                                            where refdoss =
                                                                                  D.refdoss),
                                                                          'ECR',
                                                                          'DOS')
                                                 from dual))
                                  from dual) AS totalAmtDebt
                          FROM g_dossier D, t_filiere TF
                         WHERE 1 = 1
                           AND TF.refdoss = D.refdoss
                           AND TF.dtfin IS NULL
                           AND TF.nom IN
                               (SELECT DISTINCT abrev
                                  FROM v_tdomaine
                                 WHERE type = :B5
                                   AND langue = :B6
                                   AND abrev_trad IN
                                       (SELECT regexp_substr(:B7,
                                                             '[^;]+',
                                                             1,
                                                             level)
                                          FROM dual
                                        CONNECT BY regexp_substr(:B8,
                                                                 '[^;]+',
                                                                 1,
                                                                 level) IS NOT NULL)
                                UNION (SELECT regexp_substr(:B9, '[^;]+', 1, level)
                                        FROM dual
                                      CONNECT BY regexp_substr(:B10,
                                                               '[^;]+',
                                                               1,
                                                               level) IS NOT NULL))) D,
                       t_intervenants TDB,
                       g_individu IDB,
                       t_intervenants TCL,
                       g_individu ICL,
                       t_attente ATT,
                       (SELECT DISTINCT gd.refdoss
                          FROM t_intervenants T, g_individu G, g_dossier GD
                         WHERE 1 = 1
                           AND G.refindividu = T.refindividu
                           AND T.reftype <> 'XX'
                           AND GD.refdoss = T.refdoss
                           AND (EXISTS
                                (SELECT 1
                                   FROM v_intervenants
                                  WHERE (categdoss =
                                        (SELECT abrev
                                            FROM v_domaine
                                           WHERE valeur = GD.categdoss
                                             AND TYPE = :B11) OR categdoss IS NULL)
                                    AND reftype_bd = t.reftype
                                    AND reftype_aff LIKE :B12) OR EXISTS
                                (SELECT 1
                                   FROM v_tdomaine
                                  WHERE type = :B13
                                    AND langue = :B14
                                    AND abrev_trad LIKE :B15
                                    AND abrev = T.reftype))
                           AND G.pays = :B16) DF
                 WHERE 1 = 1
                   AND TDB.refdoss(+) = D.refdoss
                   AND IDB.refindividu(+) = TDB.refindividu
                   AND TDB.reftype(+) = :B17
                   AND TCL.refdoss(+) = D.refdoss
                   AND ICL.refindividu(+) = TCL.refindividu
                   AND ATT.refentite = D.refdoss
                   AND tcl.reftype(+) = 'CL'
                   AND d.refdoss = DF.refdoss
                   AND (idb.str36 IS NULL OR EXISTS
                        (SELECT 1
                           FROM g_indivparam
                          WHERE refindividu = :B18
                            AND type = 'type_indiv'
                            AND str1 = idb.str36))
                   AND EXISTS
                 (SELECT 1
                          FROM g_elemfi E
                         WHERE E.refdoss = D.refdoss
                           AND E.dtannul IS NULL
                           AND TRUNC(E.dtdebut_dt) BETWEEN TRUNC(to_date(:B19,'yyyy-mm-dd')) AND
                               TRUNC(to_date(:B20,'yyyy-mm-dd'))
                           AND NOT EXISTS
                         (SELECT 1
                                  FROM g_elemfi E2
                                 WHERE E2.refdoss = D.refdoss
                                   AND E2.dtdebut > E.dtdebut
                                   AND E.dtannul IS NULL))
                   AND D.rangmt IN (SELECT P.refperso
                                      FROM g_personnel P, g_individu I
                                     WHERE P.refindividu = I.refindividu
                                       AND I.nom LIKE :B21)
                 ORDER BY D.refdoss, D.refdoss) foo
         WHERE ROWNUM <= :B22)
 WHERE 1 = 1
   AND rnum >= :B23;
/********************************OLD SQL*******************************************/
/********************************OLD Metrics***************************************/
/*
Plan hash value: 3900498374
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                                 | Name                        | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads | Writes |
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                                          |                             |      1 |        | 51784 (100)|      0 |00:03:40.73 |  2966K|    516K|  32111 |
|*  1 |  COUNT STOPKEY                                            |                             |      0 |        |            |      0 |00:00:00.01 |     0 |      0 |      0 |
|   2 |   NESTED LOOPS                                            |                             |      0 |      1 |     2   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|   3 |    NESTED LOOPS                                           |                             |      0 |      1 |     2   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|   4 |     TABLE ACCESS BY INDEX ROWID BATCHED                   | G_PERSONNEL                 |      0 |      1 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*  5 |      INDEX RANGE SCAN                                     | PK_G_PERSONNEL              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*  6 |     INDEX UNIQUE SCAN                                     | IND_REFINDIV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|   7 |    TABLE ACCESS BY INDEX ROWID                            | G_INDIVIDU                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|   8 |  SORT AGGREGATE                                           |                             |      0 |      1 |            |      0 |00:00:00.01 |     0 |      0 |      0 |
|*  9 |   FILTER                                                  |                             |      0 |        |            |      0 |00:00:00.01 |     0 |      0 |      0 |
|  10 |    FAST DUAL                                              |                             |      0 |      1 |     2   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|  11 |    NESTED LOOPS                                           |                             |      0 |      1 |     3   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|  12 |     MERGE JOIN CARTESIAN                                  |                             |      0 |      1 |     2   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|* 13 |      TABLE ACCESS BY INDEX ROWID BATCHED                  | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|* 14 |       INDEX RANGE SCAN                                    | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|  15 |      BUFFER SORT                                          |                             |      0 |      2 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|  16 |       TABLE ACCESS BY INDEX ROWID BATCHED                 | T_ELEMENT_SE                |      0 |      2 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|* 17 |        INDEX RANGE SCAN                                   | ELESE_DOSELEM               |      0 |      2 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|* 18 |     INDEX RANGE SCAN                                      | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|* 19 |  COUNT STOPKEY                                            |                             |      0 |        |            |      0 |00:00:00.01 |     0 |      0 |      0 |
|  20 |   NESTED LOOPS                                            |                             |      0 |      1 |     2   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|  21 |    NESTED LOOPS                                           |                             |      0 |      1 |     2   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|  22 |     TABLE ACCESS BY INDEX ROWID BATCHED                   | G_PERSONNEL                 |      0 |      1 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|* 23 |      INDEX RANGE SCAN                                     | PK_G_PERSONNEL              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|* 24 |     INDEX UNIQUE SCAN                                     | IND_REFINDIV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|  25 |    TABLE ACCESS BY INDEX ROWID                            | G_INDIVIDU                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|* 26 |  VIEW                                                     |                             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|  27 |   TABLE ACCESS FULL                                       | SYS_TEMP_0FD9E078A_89CD96E0 |      0 |    114 |     5   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|* 28 |  COUNT STOPKEY                                            |                             |      0 |        |            |      0 |00:00:00.01 |     0 |      0 |      0 |
|  29 |   TABLE ACCESS BY INDEX ROWID BATCHED                     | G_PIECE                     |      0 |      1 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|* 30 |    INDEX RANGE SCAN                                       | PIE_REFDOSS                 |      0 |      1 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|  31 |  SORT AGGREGATE                                           |                             |      0 |      1 |            |      0 |00:00:00.01 |     0 |      0 |      0 |
|* 32 |   TABLE ACCESS BY INDEX ROWID BATCHED                     | G_ELEMFI                    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|* 33 |    INDEX RANGE SCAN                                       | EFI_DOS_DTEMIS_TYPE         |      0 |      8 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|  34 |  FAST DUAL                                                |                             |      0 |      1 |     2   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|  35 |  NESTED LOOPS                                             |                             |      0 |      1 |     2   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|  36 |   NESTED LOOPS                                            |                             |      0 |      1 |     2   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|  37 |    TABLE ACCESS BY INDEX ROWID BATCHED                    | G_PERSONNEL                 |      0 |      1 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|* 38 |     INDEX RANGE SCAN                                      | PK_G_PERSONNEL              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|* 39 |    INDEX UNIQUE SCAN                                      | IND_REFINDIV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|  40 |   TABLE ACCESS BY INDEX ROWID                             | G_INDIVIDU                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|  41 |  TEMP TABLE TRANSFORMATION                                |                             |      1 |        |            |      0 |00:03:40.73 |  2966K|    516K|  32111 |
|  42 |   LOAD AS SELECT (CURSOR DURATION MEMORY)                 | SYS_TEMP_0FD9E078A_89CD96E0 |      1 |        |            |      0 |00:00:00.08 |   191 |     94 |      0 |
|* 43 |    HASH JOIN                                              |                             |      1 |    114 |    45   (0)|   4396 |00:00:00.07 |   189 |     94 |      0 |
|  44 |     VIEW                                                  |                             |      1 |      4 |     8   (0)|      4 |00:00:00.01 |     0 |      0 |      0 |
|  45 |      UNION-ALL                                            |                             |      1 |        |            |      4 |00:00:00.01 |     0 |      0 |      0 |
|  46 |       FAST DUAL                                           |                             |      1 |      1 |     2   (0)|      1 |00:00:00.01 |     0 |      0 |      0 |
|  47 |       FAST DUAL                                           |                             |      1 |      1 |     2   (0)|      1 |00:00:00.01 |     0 |      0 |      0 |
|  48 |       FAST DUAL                                           |                             |      1 |      1 |     2   (0)|      1 |00:00:00.01 |     0 |      0 |      0 |
|  49 |       FAST DUAL                                           |                             |      1 |      1 |     2   (0)|      1 |00:00:00.01 |     0 |      0 |      0 |
|  50 |     VIEW                                                  |                             |      1 |   2849 |    37   (0)|   1099 |00:00:00.07 |   189 |     94 |      0 |
|  51 |      VIEW                                                 | V_TDOMAINE                  |      1 |   2849 |    37   (0)|   1099 |00:00:00.07 |   189 |     94 |      0 |
|  52 |       UNION-ALL                                           |                             |      1 |        |            |   1099 |00:00:00.07 |   189 |     94 |      0 |
|* 53 |        FILTER                                             |                             |      1 |        |            |      0 |00:00:00.01 |     0 |      0 |      0 |
|  54 |         TABLE ACCESS BY INDEX ROWID BATCHED               | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|* 55 |          INDEX RANGE SCAN                                 | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|* 56 |        FILTER                                             |                             |      1 |        |            |   1099 |00:00:00.07 |   189 |     94 |      0 |
|  57 |         TABLE ACCESS BY INDEX ROWID BATCHED               | V_DOMAINE                   |      1 |     77 |     1   (0)|   1099 |00:00:00.07 |   189 |     94 |      0 |
|* 58 |          INDEX RANGE SCAN                                 | V_DOMAINE_TYPE_CODE_IDX     |      1 |     77 |     1   (0)|   1099 |00:00:00.01 |    17 |     11 |      0 |
|* 59 |        FILTER                                             |                             |      1 |        |            |      0 |00:00:00.01 |     0 |      0 |      0 |
|  60 |         TABLE ACCESS BY INDEX ROWID BATCHED               | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|* 61 |          INDEX RANGE SCAN                                 | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|* 62 |        FILTER                                             |                             |      1 |        |            |      0 |00:00:00.01 |     0 |      0 |      0 |
|  63 |         TABLE ACCESS BY INDEX ROWID BATCHED               | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|* 64 |          INDEX RANGE SCAN                                 | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|* 65 |        FILTER                                             |                             |      1 |        |            |      0 |00:00:00.01 |     0 |      0 |      0 |
|  66 |         TABLE ACCESS BY INDEX ROWID BATCHED               | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|* 67 |          INDEX RANGE SCAN                                 | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|* 68 |        FILTER                                             |                             |      1 |        |            |      0 |00:00:00.01 |     0 |      0 |      0 |
|  69 |         TABLE ACCESS BY INDEX ROWID BATCHED               | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|* 70 |          INDEX RANGE SCAN                                 | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|* 71 |        FILTER                                             |                             |      1 |        |            |      0 |00:00:00.01 |     0 |      0 |      0 |
|  72 |         TABLE ACCESS BY INDEX ROWID BATCHED               | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|* 73 |          INDEX RANGE SCAN                                 | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|* 74 |        FILTER                                             |                             |      1 |        |            |      0 |00:00:00.01 |     0 |      0 |      0 |
|  75 |         TABLE ACCESS BY INDEX ROWID BATCHED               | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|* 76 |          INDEX RANGE SCAN                                 | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|* 77 |        FILTER                                             |                             |      1 |        |            |      0 |00:00:00.01 |     0 |      0 |      0 |
|  78 |         TABLE ACCESS BY INDEX ROWID BATCHED               | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|* 79 |          INDEX RANGE SCAN                                 | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|* 80 |        FILTER                                             |                             |      1 |        |            |      0 |00:00:00.01 |     0 |      0 |      0 |
|  81 |         TABLE ACCESS BY INDEX ROWID BATCHED               | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|* 82 |          INDEX RANGE SCAN                                 | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|* 83 |        FILTER                                             |                             |      1 |        |            |      0 |00:00:00.01 |     0 |      0 |      0 |
|  84 |         TABLE ACCESS BY INDEX ROWID BATCHED               | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|* 85 |          INDEX RANGE SCAN                                 | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|* 86 |        FILTER                                             |                             |      1 |        |            |      0 |00:00:00.01 |     0 |      0 |      0 |
|  87 |         TABLE ACCESS BY INDEX ROWID BATCHED               | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|* 88 |          INDEX RANGE SCAN                                 | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|* 89 |        FILTER                                             |                             |      1 |        |            |      0 |00:00:00.01 |     0 |      0 |      0 |
|  90 |         TABLE ACCESS BY INDEX ROWID BATCHED               | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|* 91 |          INDEX RANGE SCAN                                 | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|* 92 |        FILTER                                             |                             |      1 |        |            |      0 |00:00:00.01 |     0 |      0 |      0 |
|  93 |         TABLE ACCESS BY INDEX ROWID BATCHED               | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|* 94 |          INDEX RANGE SCAN                                 | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|* 95 |        FILTER                                             |                             |      1 |        |            |      0 |00:00:00.01 |     0 |      0 |      0 |
|  96 |         TABLE ACCESS BY INDEX ROWID BATCHED               | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|* 97 |          INDEX RANGE SCAN                                 | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|* 98 |        FILTER                                             |                             |      1 |        |            |      0 |00:00:00.01 |     0 |      0 |      0 |
|  99 |         TABLE ACCESS BY INDEX ROWID BATCHED               | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*100 |          INDEX RANGE SCAN                                 | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*101 |        FILTER                                             |                             |      1 |        |            |      0 |00:00:00.01 |     0 |      0 |      0 |
| 102 |         TABLE ACCESS BY INDEX ROWID BATCHED               | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*103 |          INDEX RANGE SCAN                                 | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*104 |        FILTER                                             |                             |      1 |        |            |      0 |00:00:00.01 |     0 |      0 |      0 |
| 105 |         TABLE ACCESS BY INDEX ROWID BATCHED               | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*106 |          INDEX RANGE SCAN                                 | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*107 |        FILTER                                             |                             |      1 |        |            |      0 |00:00:00.01 |     0 |      0 |      0 |
| 108 |         TABLE ACCESS BY INDEX ROWID BATCHED               | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*109 |          INDEX RANGE SCAN                                 | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*110 |        FILTER                                             |                             |      1 |        |            |      0 |00:00:00.01 |     0 |      0 |      0 |
| 111 |         TABLE ACCESS BY INDEX ROWID BATCHED               | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*112 |          INDEX RANGE SCAN                                 | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*113 |        FILTER                                             |                             |      1 |        |            |      0 |00:00:00.01 |     0 |      0 |      0 |
| 114 |         TABLE ACCESS BY INDEX ROWID BATCHED               | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*115 |          INDEX RANGE SCAN                                 | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*116 |        FILTER                                             |                             |      1 |        |            |      0 |00:00:00.01 |     0 |      0 |      0 |
| 117 |         TABLE ACCESS BY INDEX ROWID BATCHED               | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*118 |          INDEX RANGE SCAN                                 | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*119 |        FILTER                                             |                             |      1 |        |            |      0 |00:00:00.01 |     0 |      0 |      0 |
| 120 |         TABLE ACCESS BY INDEX ROWID BATCHED               | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*121 |          INDEX RANGE SCAN                                 | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*122 |        FILTER                                             |                             |      1 |        |            |      0 |00:00:00.01 |     0 |      0 |      0 |
| 123 |         TABLE ACCESS BY INDEX ROWID BATCHED               | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*124 |          INDEX RANGE SCAN                                 | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*125 |        FILTER                                             |                             |      1 |        |            |      0 |00:00:00.01 |     0 |      0 |      0 |
| 126 |         TABLE ACCESS BY INDEX ROWID BATCHED               | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*127 |          INDEX RANGE SCAN                                 | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*128 |        FILTER                                             |                             |      1 |        |            |      0 |00:00:00.01 |     0 |      0 |      0 |
| 129 |         TABLE ACCESS BY INDEX ROWID BATCHED               | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*130 |          INDEX RANGE SCAN                                 | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*131 |        FILTER                                             |                             |      1 |        |            |      0 |00:00:00.01 |     0 |      0 |      0 |
| 132 |         TABLE ACCESS BY INDEX ROWID BATCHED               | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*133 |          INDEX RANGE SCAN                                 | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*134 |        FILTER                                             |                             |      1 |        |            |      0 |00:00:00.01 |     0 |      0 |      0 |
| 135 |         TABLE ACCESS BY INDEX ROWID BATCHED               | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*136 |          INDEX RANGE SCAN                                 | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*137 |        FILTER                                             |                             |      1 |        |            |      0 |00:00:00.01 |     0 |      0 |      0 |
| 138 |         TABLE ACCESS BY INDEX ROWID BATCHED               | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*139 |          INDEX RANGE SCAN                                 | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*140 |        FILTER                                             |                             |      1 |        |            |      0 |00:00:00.01 |     0 |      0 |      0 |
| 141 |         TABLE ACCESS BY INDEX ROWID BATCHED               | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*142 |          INDEX RANGE SCAN                                 | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*143 |        FILTER                                             |                             |      1 |        |            |      0 |00:00:00.01 |     0 |      0 |      0 |
| 144 |         TABLE ACCESS BY INDEX ROWID BATCHED               | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*145 |          INDEX RANGE SCAN                                 | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*146 |        FILTER                                             |                             |      1 |        |            |      0 |00:00:00.01 |     0 |      0 |      0 |
| 147 |         TABLE ACCESS BY INDEX ROWID BATCHED               | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*148 |          INDEX RANGE SCAN                                 | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*149 |        FILTER                                             |                             |      1 |        |            |      0 |00:00:00.01 |     0 |      0 |      0 |
| 150 |         TABLE ACCESS BY INDEX ROWID BATCHED               | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*151 |          INDEX RANGE SCAN                                 | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*152 |        FILTER                                             |                             |      1 |        |            |      0 |00:00:00.01 |     0 |      0 |      0 |
| 153 |         TABLE ACCESS BY INDEX ROWID BATCHED               | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*154 |          INDEX RANGE SCAN                                 | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*155 |        FILTER                                             |                             |      1 |        |            |      0 |00:00:00.01 |     0 |      0 |      0 |
| 156 |         TABLE ACCESS BY INDEX ROWID BATCHED               | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*157 |          INDEX RANGE SCAN                                 | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*158 |        FILTER                                             |                             |      1 |        |            |      0 |00:00:00.01 |     0 |      0 |      0 |
| 159 |         TABLE ACCESS BY INDEX ROWID BATCHED               | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*160 |          INDEX RANGE SCAN                                 | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*161 |        FILTER                                             |                             |      1 |        |            |      0 |00:00:00.01 |     0 |      0 |      0 |
| 162 |         TABLE ACCESS BY INDEX ROWID BATCHED               | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*163 |          INDEX RANGE SCAN                                 | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*164 |   VIEW                                                    |                             |      1 |      1 | 51739   (1)|      0 |00:03:40.65 |  2966K|    516K|  32111 |
|*165 |    COUNT STOPKEY                                          |                             |      1 |        |            |      0 |00:03:40.65 |  2966K|    516K|  32111 |
| 166 |     VIEW                                                  |                             |      1 |      1 | 51739   (1)|      0 |00:03:40.65 |  2966K|    516K|  32111 |
| 167 |      WINDOW SORT                                          |                             |      1 |      1 | 51739   (1)|      0 |00:03:40.65 |  2966K|    516K|  32111 |
|*168 |       FILTER                                              |                             |      1 |        |            |      0 |00:03:40.65 |  2966K|    516K|  32111 |
|*169 |        HASH JOIN                                          |                             |      1 |      5 | 51614   (1)|      0 |00:03:40.65 |  2966K|    516K|  32111 |
| 170 |         NESTED LOOPS                                      |                             |      1 |     10 | 51570   (1)|      0 |00:03:40.65 |  2966K|    516K|  32111 |
|*171 |          HASH JOIN SEMI                                   |                             |      1 |      6 | 51569   (1)|      0 |00:03:40.65 |  2966K|    516K|  32111 |
| 172 |           NESTED LOOPS                                    |                             |      1 |     16 | 51566   (1)|      0 |00:03:40.65 |  2966K|    516K|  32111 |
| 173 |            NESTED LOOPS                                   |                             |      1 |     16 | 51566   (1)|      0 |00:03:40.65 |  2966K|    516K|  32111 |
| 174 |             NESTED LOOPS OUTER                            |                             |      1 |     16 | 51565   (1)|      0 |00:03:40.65 |  2966K|    516K|  32111 |
| 175 |              NESTED LOOPS OUTER                           |                             |      1 |     16 | 51564   (1)|      0 |00:03:40.65 |  2966K|    516K|  32111 |
| 176 |               NESTED LOOPS OUTER                          |                             |      1 |     15 | 51563   (1)|      0 |00:03:40.65 |  2966K|    516K|  32111 |
| 177 |                NESTED LOOPS OUTER                         |                             |      1 |     15 | 51562   (1)|      0 |00:03:40.65 |  2966K|    516K|  32111 |
| 178 |                 NESTED LOOPS                              |                             |      1 |     14 | 51561   (1)|      0 |00:03:40.65 |  2966K|    516K|  32111 |
| 179 |                  VIEW                                     |                             |      1 |    289 | 51555   (1)|      0 |00:03:40.65 |  2966K|    516K|  32111 |
| 180 |                   HASH UNIQUE                             |                             |      1 |    289 | 51555   (1)|      0 |00:03:40.65 |  2966K|    516K|  32111 |
|*181 |                    FILTER                                 |                             |      1 |        |            |      0 |00:03:40.65 |  2966K|    516K|  32111 |
|*182 |                     HASH JOIN                             |                             |      1 |  76043 | 51347   (1)|   5763 |00:03:40.64 |  2965K|    516K|  32111 |
| 183 |                      MERGE JOIN                           |                             |      1 |  77853 | 50220   (1)|   5763 |00:03:38.68 |  2961K|    512K|  32111 |
|*184 |                       TABLE ACCESS BY INDEX ROWID         | G_INDIVIDU                  |      1 |  12583 | 29387   (1)|   2971 |00:03:28.65 |  2944K|    468K|      0 |
| 185 |                        INDEX FULL SCAN                    | IND_REFINDIV                |      1 |   4494K|   188   (1)|   4494K|00:00:08.39 | 18415 |  18375 |      0 |
|*186 |                       SORT JOIN                           |                             |   2971 |   2946K| 20833   (1)|   5763 |00:00:10.03 | 17297 |  44134 |  32111 |
|*187 |                        INDEX FULL SCAN                    | INT_REFDOSS                 |      1 |   2946K|   176   (1)|   2953K|00:00:06.11 | 17292 |  13383 |      0 |
| 188 |                      INDEX FULL SCAN                      | REFHIERARCHIE_IDX           |      1 |    545K|    40   (0)|    545K|00:00:01.78 |  4010 |   4010 |      0 |
|*189 |                     FILTER                                |                             |     84 |        |            |      0 |00:00:00.01 |   588 |      6 |      0 |
|*190 |                      TABLE ACCESS FULL                    | V_INTERVENANTS              |     84 |      1 |     3   (0)|      0 |00:00:00.01 |   588 |      6 |      0 |
| 191 |                      TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*192 |                       INDEX RANGE SCAN                    | DOM_TYPVAL                  |      0 |      2 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
| 193 |                     VIEW                                  | V_TDOMAINE                  |     13 |     37 |    37   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
| 194 |                      UNION-ALL                            |                             |     13 |        |            |      0 |00:00:00.01 |     0 |      0 |      0 |
|*195 |                       FILTER                              |                             |     13 |        |            |      0 |00:00:00.01 |     0 |      0 |      0 |
|*196 |                        TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*197 |                         INDEX RANGE SCAN                  | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*198 |                       FILTER                              |                             |     13 |        |            |      0 |00:00:00.01 |     0 |      0 |      0 |
|*199 |                        TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*200 |                         INDEX RANGE SCAN                  | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*201 |                       FILTER                              |                             |     13 |        |            |      0 |00:00:00.01 |     0 |      0 |      0 |
|*202 |                        TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*203 |                         INDEX RANGE SCAN                  | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*204 |                       FILTER                              |                             |     13 |        |            |      0 |00:00:00.01 |     0 |      0 |      0 |
|*205 |                        TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*206 |                         INDEX RANGE SCAN                  | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*207 |                       FILTER                              |                             |     13 |        |            |      0 |00:00:00.01 |     0 |      0 |      0 |
|*208 |                        TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*209 |                         INDEX RANGE SCAN                  | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*210 |                       FILTER                              |                             |     13 |        |            |      0 |00:00:00.01 |     0 |      0 |      0 |
|*211 |                        TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*212 |                         INDEX RANGE SCAN                  | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*213 |                       FILTER                              |                             |     13 |        |            |      0 |00:00:00.01 |     0 |      0 |      0 |
|*214 |                        TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*215 |                         INDEX RANGE SCAN                  | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*216 |                       FILTER                              |                             |     13 |        |            |      0 |00:00:00.01 |     0 |      0 |      0 |
|*217 |                        TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*218 |                         INDEX RANGE SCAN                  | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*219 |                       FILTER                              |                             |     13 |        |            |      0 |00:00:00.01 |     0 |      0 |      0 |
|*220 |                        TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*221 |                         INDEX RANGE SCAN                  | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*222 |                       FILTER                              |                             |     13 |        |            |      0 |00:00:00.01 |     0 |      0 |      0 |
|*223 |                        TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*224 |                         INDEX RANGE SCAN                  | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*225 |                       FILTER                              |                             |     13 |        |            |      0 |00:00:00.01 |     0 |      0 |      0 |
|*226 |                        TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*227 |                         INDEX RANGE SCAN                  | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*228 |                       FILTER                              |                             |     13 |        |            |      0 |00:00:00.01 |     0 |      0 |      0 |
|*229 |                        TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*230 |                         INDEX RANGE SCAN                  | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*231 |                       FILTER                              |                             |     13 |        |            |      0 |00:00:00.01 |     0 |      0 |      0 |
|*232 |                        TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*233 |                         INDEX RANGE SCAN                  | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*234 |                       FILTER                              |                             |     13 |        |            |      0 |00:00:00.01 |     0 |      0 |      0 |
|*235 |                        TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*236 |                         INDEX RANGE SCAN                  | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*237 |                       FILTER                              |                             |     13 |        |            |      0 |00:00:00.01 |     0 |      0 |      0 |
|*238 |                        TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*239 |                         INDEX RANGE SCAN                  | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*240 |                       FILTER                              |                             |     13 |        |            |      0 |00:00:00.01 |     0 |      0 |      0 |
|*241 |                        TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*242 |                         INDEX RANGE SCAN                  | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*243 |                       FILTER                              |                             |     13 |        |            |      0 |00:00:00.01 |     0 |      0 |      0 |
|*244 |                        TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*245 |                         INDEX RANGE SCAN                  | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*246 |                       FILTER                              |                             |     13 |        |            |      0 |00:00:00.01 |     0 |      0 |      0 |
|*247 |                        TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*248 |                         INDEX RANGE SCAN                  | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*249 |                       FILTER                              |                             |     13 |        |            |      0 |00:00:00.01 |     0 |      0 |      0 |
|*250 |                        TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*251 |                         INDEX RANGE SCAN                  | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*252 |                       FILTER                              |                             |     13 |        |            |      0 |00:00:00.01 |     0 |      0 |      0 |
|*253 |                        TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*254 |                         INDEX RANGE SCAN                  | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*255 |                       FILTER                              |                             |     13 |        |            |      0 |00:00:00.01 |     0 |      0 |      0 |
|*256 |                        TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*257 |                         INDEX RANGE SCAN                  | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*258 |                       FILTER                              |                             |     13 |        |            |      0 |00:00:00.01 |     0 |      0 |      0 |
|*259 |                        TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*260 |                         INDEX RANGE SCAN                  | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*261 |                       FILTER                              |                             |     13 |        |            |      0 |00:00:00.01 |     0 |      0 |      0 |
|*262 |                        TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*263 |                         INDEX RANGE SCAN                  | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*264 |                       FILTER                              |                             |     13 |        |            |      0 |00:00:00.01 |     0 |      0 |      0 |
|*265 |                        TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*266 |                         INDEX RANGE SCAN                  | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*267 |                       FILTER                              |                             |     13 |        |            |      0 |00:00:00.01 |     0 |      0 |      0 |
|*268 |                        TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*269 |                         INDEX RANGE SCAN                  | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*270 |                       FILTER                              |                             |     13 |        |            |      0 |00:00:00.01 |     0 |      0 |      0 |
|*271 |                        TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*272 |                         INDEX RANGE SCAN                  | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*273 |                       FILTER                              |                             |     13 |        |            |      0 |00:00:00.01 |     0 |      0 |      0 |
|*274 |                        TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*275 |                         INDEX RANGE SCAN                  | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*276 |                       FILTER                              |                             |     13 |        |            |      0 |00:00:00.01 |     0 |      0 |      0 |
|*277 |                        TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*278 |                         INDEX RANGE SCAN                  | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*279 |                       FILTER                              |                             |     13 |        |            |      0 |00:00:00.01 |     0 |      0 |      0 |
|*280 |                        TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*281 |                         INDEX RANGE SCAN                  | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*282 |                       FILTER                              |                             |     13 |        |            |      0 |00:00:00.01 |     0 |      0 |      0 |
|*283 |                        TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*284 |                         INDEX RANGE SCAN                  | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*285 |                       FILTER                              |                             |     13 |        |            |      0 |00:00:00.01 |     0 |      0 |      0 |
|*286 |                        TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*287 |                         INDEX RANGE SCAN                  | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*288 |                       FILTER                              |                             |     13 |        |            |      0 |00:00:00.01 |     0 |      0 |      0 |
|*289 |                        TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*290 |                         INDEX RANGE SCAN                  | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*291 |                       FILTER                              |                             |     13 |        |            |      0 |00:00:00.01 |     0 |      0 |      0 |
|*292 |                        TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*293 |                         INDEX RANGE SCAN                  | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*294 |                       FILTER                              |                             |     13 |        |            |      0 |00:00:00.01 |     0 |      0 |      0 |
|*295 |                        TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*296 |                         INDEX RANGE SCAN                  | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*297 |                       FILTER                              |                             |     13 |        |            |      0 |00:00:00.01 |     0 |      0 |      0 |
|*298 |                        TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*299 |                         INDEX RANGE SCAN                  | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*300 |                       FILTER                              |                             |     13 |        |            |      0 |00:00:00.01 |     0 |      0 |      0 |
|*301 |                        TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*302 |                         INDEX RANGE SCAN                  | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*303 |                       FILTER                              |                             |     13 |        |            |      0 |00:00:00.01 |     0 |      0 |      0 |
|*304 |                        TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*305 |                         INDEX RANGE SCAN                  | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
| 306 |                  TABLE ACCESS BY INDEX ROWID              | G_DOSSIER                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*307 |                   INDEX UNIQUE SCAN                       | DOS_REFDOSS                 |      0 |      1 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*308 |                    FILTER                                 |                             |      0 |        |            |      0 |00:00:00.01 |     0 |      0 |      0 |
|*309 |                     FILTER                                |                             |      0 |        |            |      0 |00:00:00.01 |     0 |      0 |      0 |
|*310 |                      TABLE ACCESS BY INDEX ROWID BATCHED  | G_ELEMFI                    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*311 |                       INDEX RANGE SCAN                    | EFI_DOS_DTEMIS_TYPE         |      0 |      8 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*312 |                     FILTER                                |                             |      0 |        |            |      0 |00:00:00.01 |     0 |      0 |      0 |
|*313 |                      TABLE ACCESS BY INDEX ROWID BATCHED  | G_ELEMFI                    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*314 |                       INDEX RANGE SCAN                    | EFI_DOS_DTEMIS_TYPE         |      0 |      8 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*315 |                 INDEX RANGE SCAN                          | INT_REFDOSS                 |      0 |      1 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
| 316 |                TABLE ACCESS BY INDEX ROWID                | G_INDIVIDU                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*317 |                 INDEX UNIQUE SCAN                         | IND_REFINDIV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*318 |               INDEX RANGE SCAN                            | INT_REFDOSS                 |      0 |      1 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
| 319 |              TABLE ACCESS BY INDEX ROWID                  | G_INDIVIDU                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*320 |               INDEX UNIQUE SCAN                           | IND_REFINDIV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*321 |             INDEX RANGE SCAN                              | PK_ATTENTE                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
| 322 |            TABLE ACCESS BY INDEX ROWID                    | T_ATTENTE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
| 323 |           VIEW                                            | VW_NSO_2                    |      0 |     83 |     3   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
| 324 |            NESTED LOOPS                                   |                             |      0 |     83 |     3   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
| 325 |             NESTED LOOPS                                  |                             |      0 |     83 |     3   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
| 326 |              TABLE ACCESS BY INDEX ROWID BATCHED          | G_INDIVIDU                  |      0 |     78 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*327 |               INDEX RANGE SCAN                            | G_INDIV_NOM_PROF            |      0 |     78 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*328 |              INDEX RANGE SCAN                             | GPERS_REFIN_IDX             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
| 329 |             TABLE ACCESS BY INDEX ROWID                   | G_PERSONNEL                 |      0 |      1 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*330 |          INDEX RANGE SCAN                                 | TIND_FIL                    |      0 |      2 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
| 331 |         VIEW                                              | VW_NSO_3                    |      0 |     29 |    44   (7)|      0 |00:00:00.01 |     0 |      0 |      0 |
| 332 |          SORT UNIQUE                                      |                             |      0 |     29 |    44   (7)|      0 |00:00:00.01 |     0 |      0 |      0 |
| 333 |           UNION-ALL                                       |                             |      0 |        |            |      0 |00:00:00.01 |     0 |      0 |      0 |
|*334 |            HASH JOIN                                      |                             |      0 |     28 |    40   (3)|      0 |00:00:00.01 |     0 |      0 |      0 |
| 335 |             VIEW                                          | VW_NSO_1                    |      0 |      1 |     3  (34)|      0 |00:00:00.01 |     0 |      0 |      0 |
| 336 |              HASH UNIQUE                                  |                             |      0 |      1 |     3  (34)|      0 |00:00:00.01 |     0 |      0 |      0 |
| 337 |               CONNECT BY WITHOUT FILTERING (UNIQUE)       |                             |      0 |        |            |      0 |00:00:00.01 |     0 |      0 |      0 |
| 338 |                FAST DUAL                                  |                             |      0 |      1 |     2   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
| 339 |             VIEW                                          | V_TDOMAINE                  |      0 |   2849 |    37   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
| 340 |              UNION-ALL                                    |                             |      0 |        |            |      0 |00:00:00.01 |     0 |      0 |      0 |
|*341 |               FILTER                                      |                             |      0 |        |            |      0 |00:00:00.01 |     0 |      0 |      0 |
| 342 |                TABLE ACCESS BY INDEX ROWID BATCHED        | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*343 |                 INDEX RANGE SCAN                          | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*344 |               FILTER                                      |                             |      0 |        |            |      0 |00:00:00.01 |     0 |      0 |      0 |
| 345 |                TABLE ACCESS BY INDEX ROWID BATCHED        | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*346 |                 INDEX RANGE SCAN                          | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*347 |               FILTER                                      |                             |      0 |        |            |      0 |00:00:00.01 |     0 |      0 |      0 |
| 348 |                TABLE ACCESS BY INDEX ROWID BATCHED        | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*349 |                 INDEX RANGE SCAN                          | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*350 |               FILTER                                      |                             |      0 |        |            |      0 |00:00:00.01 |     0 |      0 |      0 |
| 351 |                TABLE ACCESS BY INDEX ROWID BATCHED        | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*352 |                 INDEX RANGE SCAN                          | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*353 |               FILTER                                      |                             |      0 |        |            |      0 |00:00:00.01 |     0 |      0 |      0 |
| 354 |                TABLE ACCESS BY INDEX ROWID BATCHED        | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*355 |                 INDEX RANGE SCAN                          | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*356 |               FILTER                                      |                             |      0 |        |            |      0 |00:00:00.01 |     0 |      0 |      0 |
| 357 |                TABLE ACCESS BY INDEX ROWID BATCHED        | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*358 |                 INDEX RANGE SCAN                          | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*359 |               FILTER                                      |                             |      0 |        |            |      0 |00:00:00.01 |     0 |      0 |      0 |
| 360 |                TABLE ACCESS BY INDEX ROWID BATCHED        | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*361 |                 INDEX RANGE SCAN                          | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*362 |               FILTER                                      |                             |      0 |        |            |      0 |00:00:00.01 |     0 |      0 |      0 |
| 363 |                TABLE ACCESS BY INDEX ROWID BATCHED        | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*364 |                 INDEX RANGE SCAN                          | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*365 |               FILTER                                      |                             |      0 |        |            |      0 |00:00:00.01 |     0 |      0 |      0 |
| 366 |                TABLE ACCESS BY INDEX ROWID BATCHED        | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*367 |                 INDEX RANGE SCAN                          | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*368 |               FILTER                                      |                             |      0 |        |            |      0 |00:00:00.01 |     0 |      0 |      0 |
| 369 |                TABLE ACCESS BY INDEX ROWID BATCHED        | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*370 |                 INDEX RANGE SCAN                          | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*371 |               FILTER                                      |                             |      0 |        |            |      0 |00:00:00.01 |     0 |      0 |      0 |
| 372 |                TABLE ACCESS BY INDEX ROWID BATCHED        | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*373 |                 INDEX RANGE SCAN                          | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*374 |               FILTER                                      |                             |      0 |        |            |      0 |00:00:00.01 |     0 |      0 |      0 |
| 375 |                TABLE ACCESS BY INDEX ROWID BATCHED        | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*376 |                 INDEX RANGE SCAN                          | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*377 |               FILTER                                      |                             |      0 |        |            |      0 |00:00:00.01 |     0 |      0 |      0 |
| 378 |                TABLE ACCESS BY INDEX ROWID BATCHED        | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*379 |                 INDEX RANGE SCAN                          | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*380 |               FILTER                                      |                             |      0 |        |            |      0 |00:00:00.01 |     0 |      0 |      0 |
| 381 |                TABLE ACCESS BY INDEX ROWID BATCHED        | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*382 |                 INDEX RANGE SCAN                          | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*383 |               FILTER                                      |                             |      0 |        |            |      0 |00:00:00.01 |     0 |      0 |      0 |
| 384 |                TABLE ACCESS BY INDEX ROWID BATCHED        | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*385 |                 INDEX RANGE SCAN                          | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*386 |               FILTER                                      |                             |      0 |        |            |      0 |00:00:00.01 |     0 |      0 |      0 |
| 387 |                TABLE ACCESS BY INDEX ROWID BATCHED        | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*388 |                 INDEX RANGE SCAN                          | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*389 |               FILTER                                      |                             |      0 |        |            |      0 |00:00:00.01 |     0 |      0 |      0 |
| 390 |                TABLE ACCESS BY INDEX ROWID BATCHED        | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*391 |                 INDEX RANGE SCAN                          | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*392 |               FILTER                                      |                             |      0 |        |            |      0 |00:00:00.01 |     0 |      0 |      0 |
| 393 |                TABLE ACCESS BY INDEX ROWID BATCHED        | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*394 |                 INDEX RANGE SCAN                          | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*395 |               FILTER                                      |                             |      0 |        |            |      0 |00:00:00.01 |     0 |      0 |      0 |
| 396 |                TABLE ACCESS BY INDEX ROWID BATCHED        | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*397 |                 INDEX RANGE SCAN                          | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*398 |               FILTER                                      |                             |      0 |        |            |      0 |00:00:00.01 |     0 |      0 |      0 |
| 399 |                TABLE ACCESS BY INDEX ROWID BATCHED        | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*400 |                 INDEX RANGE SCAN                          | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*401 |               FILTER                                      |                             |      0 |        |            |      0 |00:00:00.01 |     0 |      0 |      0 |
| 402 |                TABLE ACCESS BY INDEX ROWID BATCHED        | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*403 |                 INDEX RANGE SCAN                          | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*404 |               FILTER                                      |                             |      0 |        |            |      0 |00:00:00.01 |     0 |      0 |      0 |
| 405 |                TABLE ACCESS BY INDEX ROWID BATCHED        | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*406 |                 INDEX RANGE SCAN                          | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*407 |               FILTER                                      |                             |      0 |        |            |      0 |00:00:00.01 |     0 |      0 |      0 |
| 408 |                TABLE ACCESS BY INDEX ROWID BATCHED        | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*409 |                 INDEX RANGE SCAN                          | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*410 |               FILTER                                      |                             |      0 |        |            |      0 |00:00:00.01 |     0 |      0 |      0 |
| 411 |                TABLE ACCESS BY INDEX ROWID BATCHED        | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*412 |                 INDEX RANGE SCAN                          | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*413 |               FILTER                                      |                             |      0 |        |            |      0 |00:00:00.01 |     0 |      0 |      0 |
| 414 |                TABLE ACCESS BY INDEX ROWID BATCHED        | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*415 |                 INDEX RANGE SCAN                          | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*416 |               FILTER                                      |                             |      0 |        |            |      0 |00:00:00.01 |     0 |      0 |      0 |
| 417 |                TABLE ACCESS BY INDEX ROWID BATCHED        | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*418 |                 INDEX RANGE SCAN                          | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*419 |               FILTER                                      |                             |      0 |        |            |      0 |00:00:00.01 |     0 |      0 |      0 |
| 420 |                TABLE ACCESS BY INDEX ROWID BATCHED        | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*421 |                 INDEX RANGE SCAN                          | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*422 |               FILTER                                      |                             |      0 |        |            |      0 |00:00:00.01 |     0 |      0 |      0 |
| 423 |                TABLE ACCESS BY INDEX ROWID BATCHED        | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*424 |                 INDEX RANGE SCAN                          | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*425 |               FILTER                                      |                             |      0 |        |            |      0 |00:00:00.01 |     0 |      0 |      0 |
| 426 |                TABLE ACCESS BY INDEX ROWID BATCHED        | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*427 |                 INDEX RANGE SCAN                          | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*428 |               FILTER                                      |                             |      0 |        |            |      0 |00:00:00.01 |     0 |      0 |      0 |
| 429 |                TABLE ACCESS BY INDEX ROWID BATCHED        | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*430 |                 INDEX RANGE SCAN                          | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*431 |               FILTER                                      |                             |      0 |        |            |      0 |00:00:00.01 |     0 |      0 |      0 |
| 432 |                TABLE ACCESS BY INDEX ROWID BATCHED        | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*433 |                 INDEX RANGE SCAN                          | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*434 |               FILTER                                      |                             |      0 |        |            |      0 |00:00:00.01 |     0 |      0 |      0 |
| 435 |                TABLE ACCESS BY INDEX ROWID BATCHED        | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*436 |                 INDEX RANGE SCAN                          | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*437 |               FILTER                                      |                             |      0 |        |            |      0 |00:00:00.01 |     0 |      0 |      0 |
| 438 |                TABLE ACCESS BY INDEX ROWID BATCHED        | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*439 |                 INDEX RANGE SCAN                          | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*440 |               FILTER                                      |                             |      0 |        |            |      0 |00:00:00.01 |     0 |      0 |      0 |
| 441 |                TABLE ACCESS BY INDEX ROWID BATCHED        | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*442 |                 INDEX RANGE SCAN                          | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*443 |               FILTER                                      |                             |      0 |        |            |      0 |00:00:00.01 |     0 |      0 |      0 |
| 444 |                TABLE ACCESS BY INDEX ROWID BATCHED        | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*445 |                 INDEX RANGE SCAN                          | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*446 |               FILTER                                      |                             |      0 |        |            |      0 |00:00:00.01 |     0 |      0 |      0 |
| 447 |                TABLE ACCESS BY INDEX ROWID BATCHED        | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*448 |                 INDEX RANGE SCAN                          | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*449 |               FILTER                                      |                             |      0 |        |            |      0 |00:00:00.01 |     0 |      0 |      0 |
| 450 |                TABLE ACCESS BY INDEX ROWID BATCHED        | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*451 |                 INDEX RANGE SCAN                          | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
| 452 |            CONNECT BY WITHOUT FILTERING (UNIQUE)          |                             |      0 |        |            |      0 |00:00:00.01 |     0 |      0 |      0 |
| 453 |             FAST DUAL                                     |                             |      0 |      1 |     2   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
|*454 |        INDEX RANGE SCAN                                   | G_INDIVPARAM_REFIND         |      0 |      1 |     1   (0)|      0 |00:00:00.01 |     0 |      0 |      0 |
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   1 - filter(ROWNUM=1)
   5 - access("CMP"."REFPERSO"=:B1)
   6 - access("CMI"."REFINDIVIDU"="CMP"."REFINDIVIDU")
   9 - filter( IS NOT NULL)
  13 - filter(("VF"."ECRAN" IS NOT NULL AND "VF"."ABREV16"='O'))
  14 - access("VF"."TYPE"='filiere')
  17 - access("REFDOSS"=:B1)
  18 - access("VT"."TYPE"='typencour' AND "VF"."ECRAN"="VT"."ABREV" AND "LIBELLE"="VT"."VALEUR")
       filter(("VT"."VALEUR" IS NOT NULL AND "VT"."ABREV" IS NOT NULL))
  19 - filter(ROWNUM=1)
  23 - access("SMP"."REFPERSO"=TO_NUMBER(:B1))
  24 - access("SMI"."REFINDIVIDU"="SMP"."REFINDIVIDU")
  26 - filter("TPNCR"."PFX_VALEUR"=:B1)
  28 - filter(ROWNUM=1)
  30 - access("REFDOSS"=:B1 AND "TYPPIECE"='RECOUVREMENT')
  32 - filter(((:B1 IS NOT NULL AND "FI"."CREATEUR"='cfc_migration') OR (:B2 IS NULL AND TRUNC(INTERNAL_FUNCTION("DTJOUR_DT"))=NVL(TRUNC(:B3),TRUNC(:B4)))))
  33 - access("FI"."REFDOSS"=:B1)
  38 - access("PSU"."REFPERSO"=:B1)
  39 - access("ISU"."REFINDIVIDU"="PSU"."REFINDIVIDU")
  43 - access("V"."F"="PFX"."F")
  53 - filter('AL'=:B1)
  55 - access("TYPE"='typencour')
  56 - filter('AN'=:B1)
  58 - access("TYPE"='typencour')
  59 - filter('AR'=:B1)
  61 - access("TYPE"='typencour')
  62 - filter('BG'=:B1)
  64 - access("TYPE"='typencour')
  65 - filter('BR'=:B1)
  67 - access("TYPE"='typencour')
  68 - filter('CE'=:B1)
  70 - access("TYPE"='typencour')
  71 - filter('CH'=:B1)
  73 - access("TYPE"='typencour')
  74 - filter('CS'=:B1)
  76 - access("TYPE"='typencour')
  77 - filter('DA'=:B1)
  79 - access("TYPE"='typencour')
  80 - filter('EL'=:B1)
  82 - access("TYPE"='typencour')
  83 - filter('ES'=:B1)
  85 - access("TYPE"='typencour')
  86 - filter('ET'=:B1)
  88 - access("TYPE"='typencour')
  89 - filter('FI'=:B1)
  91 - access("TYPE"='typencour')
  92 - filter('FL'=:B1)
  94 - access("TYPE"='typencour')
  95 - filter('FR'=:B1)
  97 - access("TYPE"='typencour')
  98 - filter('HR'=:B1)
 100 - access("TYPE"='typencour')
 101 - filter('HU'=:B1)
 103 - access("TYPE"='typencour')
 104 - filter('IT'=:B1)
 106 - access("TYPE"='typencour')
 107 - filter('IW'=:B1)
 109 - access("TYPE"='typencour')
 110 - filter('JA'=:B1)
 112 - access("TYPE"='typencour')
 113 - filter('LT'=:B1)
 115 - access("TYPE"='typencour')
 116 - filter('LV'=:B1)
 118 - access("TYPE"='typencour')
 119 - filter('MX'=:B1)
 121 - access("TYPE"='typencour')
 122 - filter('NL'=:B1)
 124 - access("TYPE"='typencour')
 125 - filter('NO'=:B1)
 127 - access("TYPE"='typencour')
 128 - filter('PL'=:B1)
 130 - access("TYPE"='typencour')
 131 - filter('PT'=:B1)
 133 - access("TYPE"='typencour')
 134 - filter('RO'=:B1)
 136 - access("TYPE"='typencour')
 137 - filter('RU'=:B1)
 139 - access("TYPE"='typencour')
 140 - filter('SK'=:B1)
 142 - access("TYPE"='typencour')
 143 - filter('SL'=:B1)
 145 - access("TYPE"='typencour')
 146 - filter('SR'=:B1)
 148 - access("TYPE"='typencour')
 149 - filter('SV'=:B1)
 151 - access("TYPE"='typencour')
 152 - filter('TR'=:B1)
 154 - access("TYPE"='typencour')
 155 - filter('US'=:B1)
 157 - access("TYPE"='typencour')
 158 - filter('VI'=:B1)
 160 - access("TYPE"='typencour')
 161 - filter('ZH'=:B1)
 163 - access("TYPE"='typencour')
 164 - filter("RNUM">=:B23)
 165 - filter(ROWNUM<=:B22)
 168 - filter(("IDB"."STR36" IS NULL OR  IS NOT NULL))
 169 - access("TF"."NOM"="ABREV")
 171 - access("D"."RANGMT"="REFPERSO")
 181 - filter(( IS NOT NULL OR  IS NOT NULL))
 182 - access("GD"."REFDOSS"="T"."REFDOSS")
 184 - filter("G"."PAYS"=:B16)
 186 - access("G"."REFINDIVIDU"="T"."REFINDIVIDU")
       filter("G"."REFINDIVIDU"="T"."REFINDIVIDU")
 187 - filter("T"."REFTYPE"<>'XX')
 189 - filter(("CATEGDOSS" IS NULL OR "CATEGDOSS"=))
 190 - filter(("REFTYPE_BD"=:B1 AND "REFTYPE_AFF" LIKE :B12))
 192 - access("VALEUR"=:B1 AND "TYPE"=:B11)
 195 - filter('AL'=:B14)
 196 - filter("ABREV_AL" LIKE :B15)
 197 - access("TYPE"=:B13 AND "ABREV"=:B1)
 198 - filter('AN'=:B14)
 199 - filter("ABREV_AN" LIKE :B15)
 200 - access("TYPE"=:B13 AND "ABREV"=:B1)
 201 - filter('AR'=:B14)
 202 - filter("ABREV_AR" LIKE :B15)
 203 - access("TYPE"=:B13 AND "ABREV"=:B1)
 204 - filter('BG'=:B14)
 205 - filter("ABREV_BG" LIKE :B15)
 206 - access("TYPE"=:B13 AND "ABREV"=:B1)
 207 - filter('BR'=:B14)
 208 - filter("ABREV_BR" LIKE :B15)
 209 - access("TYPE"=:B13 AND "ABREV"=:B1)
 210 - filter('CE'=:B14)
 211 - filter("ABREV_CE" LIKE :B15)
 212 - access("TYPE"=:B13 AND "ABREV"=:B1)
 213 - filter('CH'=:B14)
 214 - filter("ABREV_CH" LIKE :B15)
 215 - access("TYPE"=:B13 AND "ABREV"=:B1)
 216 - filter('CS'=:B14)
 217 - filter("ABREV_CS" LIKE :B15)
 218 - access("TYPE"=:B13 AND "ABREV"=:B1)
 219 - filter('DA'=:B14)
 220 - filter("ABREV_DA" LIKE :B15)
 221 - access("TYPE"=:B13 AND "ABREV"=:B1)
 222 - filter('EL'=:B14)
 223 - filter("ABREV_EL" LIKE :B15)
 224 - access("TYPE"=:B13 AND "ABREV"=:B1)
 225 - filter('ES'=:B14)
 226 - filter("ABREV_ES" LIKE :B15)
 227 - access("TYPE"=:B13 AND "ABREV"=:B1)
 228 - filter('ET'=:B14)
 229 - filter("ABREV_ET" LIKE :B15)
 230 - access("TYPE"=:B13 AND "ABREV"=:B1)
 231 - filter('FI'=:B14)
 232 - filter("ABREV_FI" LIKE :B15)
 233 - access("TYPE"=:B13 AND "ABREV"=:B1)
 234 - filter('FL'=:B14)
 235 - filter("ABREV_FL" LIKE :B15)
 236 - access("TYPE"=:B13 AND "ABREV"=:B1)
 237 - filter('FR'=:B14)
 238 - filter(NVL("ABREV_FR","ABREV") LIKE :B15)
 239 - access("TYPE"=:B13 AND "ABREV"=:B1)
 240 - filter('HR'=:B14)
 241 - filter("ABREV_HR" LIKE :B15)
 242 - access("TYPE"=:B13 AND "ABREV"=:B1)
 243 - filter('HU'=:B14)
 244 - filter("ABREV_HU" LIKE :B15)
 245 - access("TYPE"=:B13 AND "ABREV"=:B1)
 246 - filter('IT'=:B14)
 247 - filter("ABREV_IT" LIKE :B15)
 248 - access("TYPE"=:B13 AND "ABREV"=:B1)
 249 - filter('IW'=:B14)
 250 - filter("ABREV_IW" LIKE :B15)
 251 - access("TYPE"=:B13 AND "ABREV"=:B1)
 252 - filter('JA'=:B14)
 253 - filter("ABREV_JA" LIKE :B15)
 254 - access("TYPE"=:B13 AND "ABREV"=:B1)
 255 - filter('LT'=:B14)
 256 - filter("ABREV_LT" LIKE :B15)
 257 - access("TYPE"=:B13 AND "ABREV"=:B1)
 258 - filter('LV'=:B14)
 259 - filter("ABREV_LV" LIKE :B15)
 260 - access("TYPE"=:B13 AND "ABREV"=:B1)
 261 - filter('MX'=:B14)
 262 - filter("ABREV_MX" LIKE :B15)
 263 - access("TYPE"=:B13 AND "ABREV"=:B1)
 264 - filter('NL'=:B14)
 265 - filter("ABREV_NL" LIKE :B15)
 266 - access("TYPE"=:B13 AND "ABREV"=:B1)
 267 - filter('NO'=:B14)
 268 - filter("ABREV_NO" LIKE :B15)
 269 - access("TYPE"=:B13 AND "ABREV"=:B1)
 270 - filter('PL'=:B14)
 271 - filter("ABREV_PL" LIKE :B15)
 272 - access("TYPE"=:B13 AND "ABREV"=:B1)
 273 - filter('PT'=:B14)
 274 - filter("ABREV_PT" LIKE :B15)
 275 - access("TYPE"=:B13 AND "ABREV"=:B1)
 276 - filter('RO'=:B14)
 277 - filter("ABREV_RO" LIKE :B15)
 278 - access("TYPE"=:B13 AND "ABREV"=:B1)
 279 - filter('RU'=:B14)
 280 - filter("ABREV_RU" LIKE :B15)
 281 - access("TYPE"=:B13 AND "ABREV"=:B1)
 282 - filter('SK'=:B14)
 283 - filter("ABREV_SK" LIKE :B15)
 284 - access("TYPE"=:B13 AND "ABREV"=:B1)
 285 - filter('SL'=:B14)
 286 - filter("ABREV_SL" LIKE :B15)
 287 - access("TYPE"=:B13 AND "ABREV"=:B1)
 288 - filter('SR'=:B14)
 289 - filter("ABREV_SR" LIKE :B15)
 290 - access("TYPE"=:B13 AND "ABREV"=:B1)
 291 - filter('SV'=:B14)
 292 - filter("ABREV_SV" LIKE :B15)
 293 - access("TYPE"=:B13 AND "ABREV"=:B1)
 294 - filter('TR'=:B14)
 295 - filter("ABREV_TR" LIKE :B15)
 296 - access("TYPE"=:B13 AND "ABREV"=:B1)
 297 - filter('US'=:B14)
 298 - filter("ABREV_US" LIKE :B15)
 299 - access("TYPE"=:B13 AND "ABREV"=:B1)
 300 - filter('VI'=:B14)
 301 - filter("ABREV_VI" LIKE :B15)
 302 - access("TYPE"=:B13 AND "ABREV"=:B1)
 303 - filter('ZH'=:B14)
 304 - filter("ABREV_ZH" LIKE :B15)
 305 - access("TYPE"=:B13 AND "ABREV"=:B1)
 307 - access("D"."REFDOSS"="DF"."REFDOSS")
       filter( IS NOT NULL)
 308 - filter( IS NULL)
 309 - filter(TRUNC(TO_DATE(:B20,'yyyy-mm-dd'))>=TRUNC(TO_DATE(:B19,'yyyy-mm-dd')))
 310 - filter(("E"."DTANNUL" IS NULL AND TRUNC(INTERNAL_FUNCTION("E"."DTDEBUT_DT"))>=TRUNC(TO_DATE(:B19,'yyyy-mm-dd')) AND
              TRUNC(INTERNAL_FUNCTION("E"."DTDEBUT_DT"))<=TRUNC(TO_DATE(:B20,'yyyy-mm-dd'))))
 311 - access("E"."REFDOSS"=:B1)
 312 - filter(:B1 IS NULL)
 313 - filter("E2"."DTDEBUT">:B1)
 314 - access("E2"."REFDOSS"=:B1)
 315 - access("TCL"."REFDOSS"="D"."REFDOSS" AND "TCL"."REFTYPE"='CL')
 317 - access("ICL"."REFINDIVIDU"="TCL"."REFINDIVIDU")
 318 - access("TDB"."REFDOSS"="D"."REFDOSS" AND "TDB"."REFTYPE"=:B17)
 320 - access("IDB"."REFINDIVIDU"="TDB"."REFINDIVIDU")
 321 - access("ATT"."REFENTITE"="D"."REFDOSS")
 327 - access("I"."NOM" LIKE :B21)
       filter("I"."NOM" LIKE :B21)
 328 - access("P"."REFINDIVIDU"="I"."REFINDIVIDU")
 330 - access("TF"."REFDOSS"="D"."REFDOSS" AND "TF"."DTFIN" IS NULL)
       filter("TF"."DTFIN" IS NULL)
 334 - access("ABREV_TRAD"="REGEXP_SUBSTR(:B7,'[^;]+',1,LEVEL)")
 341 - filter('AL'=:B6)
 343 - access("TYPE"=:B5)
 344 - filter('AN'=:B6)
 346 - access("TYPE"=:B5)
 347 - filter('AR'=:B6)
 349 - access("TYPE"=:B5)
 350 - filter('BG'=:B6)
 352 - access("TYPE"=:B5)
 353 - filter('BR'=:B6)
 355 - access("TYPE"=:B5)
 356 - filter('CE'=:B6)
 358 - access("TYPE"=:B5)
 359 - filter('CH'=:B6)
 361 - access("TYPE"=:B5)
 362 - filter('CS'=:B6)
 364 - access("TYPE"=:B5)
 365 - filter('DA'=:B6)
 367 - access("TYPE"=:B5)
 368 - filter('EL'=:B6)
 370 - access("TYPE"=:B5)
 371 - filter('ES'=:B6)
 373 - access("TYPE"=:B5)
 374 - filter('ET'=:B6)
 376 - access("TYPE"=:B5)
 377 - filter('FI'=:B6)
 379 - access("TYPE"=:B5)
 380 - filter('FL'=:B6)
 382 - access("TYPE"=:B5)
 383 - filter('FR'=:B6)
 385 - access("TYPE"=:B5)
 386 - filter('HR'=:B6)
 388 - access("TYPE"=:B5)
 389 - filter('HU'=:B6)
 391 - access("TYPE"=:B5)
 392 - filter('IT'=:B6)
 394 - access("TYPE"=:B5)
 395 - filter('IW'=:B6)
 397 - access("TYPE"=:B5)
 398 - filter('JA'=:B6)
 400 - access("TYPE"=:B5)
 401 - filter('LT'=:B6)
 403 - access("TYPE"=:B5)
 404 - filter('LV'=:B6)
 406 - access("TYPE"=:B5)
 407 - filter('MX'=:B6)
 409 - access("TYPE"=:B5)
 410 - filter('NL'=:B6)
 412 - access("TYPE"=:B5)
 413 - filter('NO'=:B6)
 415 - access("TYPE"=:B5)
 416 - filter('PL'=:B6)
 418 - access("TYPE"=:B5)
 419 - filter('PT'=:B6)
 421 - access("TYPE"=:B5)
 422 - filter('RO'=:B6)
 424 - access("TYPE"=:B5)
 425 - filter('RU'=:B6)
 427 - access("TYPE"=:B5)
 428 - filter('SK'=:B6)
 430 - access("TYPE"=:B5)
 431 - filter('SL'=:B6)
 433 - access("TYPE"=:B5)
 434 - filter('SR'=:B6)
 436 - access("TYPE"=:B5)
 437 - filter('SV'=:B6)
 439 - access("TYPE"=:B5)
 440 - filter('TR'=:B6)
 442 - access("TYPE"=:B5)
 443 - filter('US'=:B6)
 445 - access("TYPE"=:B5)
 446 - filter('VI'=:B6)
 448 - access("TYPE"=:B5)
 449 - filter('ZH'=:B6)
 451 - access("TYPE"=:B5)
 454 - access("REFINDIVIDU"=:B18 AND "TYPE"='type_indiv' AND "STR1"=:B1)
       filter("STR1"=:B1)
*/
/********************************OLD Metrics***************************************/

/********************************New SQL*******************************************/
WITH tpncr AS
 (SELECT /*+ materialize */
   *
    FROM (SELECT /*+ no_merge(pfx) leading(pfx) use_hash(v) */
           pfx.valeur || v.valeur pfx_valeur,
           pfx.valeur || v.valeur_trad valeur_trad
            FROM (SELECT 'PB: A.' valeur, 'f' f
                    FROM dual
                  UNION ALL
                  SELECT 'PB: ' valeur, 'f' f
                    FROM dual
                  UNION ALL
                  SELECT 'A.' valeur, 'f' f
                    FROM dual
                  UNION ALL
                  SELECT '' valeur, 'f' f
                    FROM dual) pfx,
                 (SELECT /*+ no_merge no_push_pred */
                   valeur, valeur_trad, 'f' f
                    FROM v_tdomaine
                   WHERE type = 'typencour'
                     AND langue = :B1) v
           WHERE v.f = pfx.f) fooo
   WHERE 1 = 1)
SELECT *
  FROM (SELECT /*+ first_rows(2001)*/
         foo.*, ROWNUM rnum
          FROM (SELECT (SELECT CMI.nom
                          FROM g_individu CMI, g_personnel CMP
                         WHERE CMP.refperso = D.rangmt
                           AND CMI.refindividu = CMP.refindividu
                           AND rownum = 1) caseManagerDisplay,
                       D.dtfingest_dt managementEndDate,
                       D.rangmt caseManager,
                       ATT.typencour caseStatus,
                       ATT.dtdeclench_dt dueDate,
                       (SELECT DECODE(COUNT(*), 0, 'false', 'true')
                          FROM DUAL
                         WHERE EXISTS
                         (SELECT 1
                                  FROM t_element_se
                                 WHERE refdoss = D.refdoss
                                   AND libelle IN
                                       (SELECT vt.valeur
                                          FROM v_domaine vt, v_domaine vf
                                         WHERE vt.type = 'typencour'
                                           AND vf.abrev16 = 'O'
                                           AND vf.type = 'filiere'
                                           AND vf.ecran = vt.abrev))) forbProcessFound,
                       (SELECT SMI.nom
                          FROM g_individu SMI, g_personnel SMP
                         WHERE SMP.refperso = ATT.catperso
                           AND SMI.refindividu = SMP.refindividu
                           AND rownum = 1) statusManagerDisplay,
                       D.refdoss internalCaseReference,
                       IDB.nom debtor,
                       D.soldedb caseBalance,
                       ICL.nom client,
                       (SELECT tpncr.valeur_trad
                          FROM tpncr
                         WHERE tpncr.pfx_valeur = ATT.typencour) caseStatusDisplay,
                       D.devise caseCurrency,
                       IMX.get_valeur('TYPE_MANDAT', D.typeOfMandate, :B2) typeOfMandate,
                       IMX.get_valeur('PHASE', D.phase, :B3) phase,
                       D.reflot_dos reflot_dos,
                       ATT.catperso statusManager,
                       D.pieceinit product,
                       D.ancrefdoss externalCaseReference,
                       IDB.siret debtorNrn,
                       D.initialAmount initialAmount,
                       (SELECT IMX.transl_valeur('piece', D.pieceinit, :B4)
                          FROM dual) productDisplay,
                       (count(D.refdoss) OVER()) totalRealCases,
                       D.caseManagerSu caseManagerSu,
                       (SUM(D.soldedb) OVER()) sumBalanceReal
                  FROM (SELECT D.rangmt,
                               D.ancrefdoss,
                               D.refdoss,
                               D.devise,
                               D.soldedb,
                               D.soldedb_dos,
                               D.dtfingest_dt,
                               D.reflot_dos,
                               D.reflot,
                               D.principal,
                               D.segment,
                               D.pieceinit,
                               D.monref,
                               D.dt_dt_dt,
                               D.dtcreation_dt,
                               D.categdoss,
                               D.stratif,
                               D.dt_dechterm_dt,
                               (SELECT ISU.nom
                                  FROM g_personnel PSU, g_individu ISU
                                 WHERE PSU.refperso = D.monref
                                   AND ISU.refindividu = PSU.refindividu) as caseManagerSu,
                               D.phase phase,
                               (SELECT SUM(FI.montant)
                                  FROM g_elemfi FI
                                 WHERE FI.refdoss = D.refdoss
                                   AND ((D.mig_reference IS NULL AND
                                       TRUNC(dtjour_dt) =
                                       NVL(TRUNC(D.dtcreation_dt),
                                             TRUNC(D.dt_dt_dt))) OR
                                       (D.mig_reference IS NOT NULL AND
                                       FI.createur = 'cfc_migration'))) as initialAmount,
                               (SELECT st24
                                  FROM g_piece
                                 WHERE refdoss = D.refdoss
                                   AND typpiece = 'RECOUVREMENT'
                                   AND ROWNUM = 1) as typeOfMandate,
                               (select decode((select count(*) flag_true
                                                from (select nvl(max(FG_INCL_NOT_DUE_ELEM_CASE_BAL),
                                                                 'N') flag
                                                        from g_bu
                                                       where refindividu =
                                                             (select refindividu
                                                                from t_intervenants
                                                               where refdoss =
                                                                     D.refdoss
                                                                 and reftype = 'BU')) g_bu_flag,
                                                     (select nvl(max(FG_TREAT_ALL_ELEMENTS_AS_DUE),
                                                                 'N') flag
                                                        from g_dossier
                                                       where refdoss = D.refdoss) g_doss_flag
                                               where g_bu_flag.flag = 'N'
                                                 and g_doss_flag.flag = 'N'),
                                              0,
                                              (select sum(nvl(mt_ouvert_mvt,
                                                              montant_dos))
                                                 from g_elemfi
                                                where refdoss = D.refdoss
                                                  and dtdebut <
                                                      to_char(sysdate, 'j')),
                                              (select cpt_util.getPostSum(D.refdoss,
                                                                          'SOLDEDB',
                                                                          (select dt_dt
                                                                             from g_dossier
                                                                            where refdoss =
                                                                                  D.refdoss),
                                                                          'ECR',
                                                                          'DOS')
                                                 from dual))
                                  from dual) AS totalAmtDebt
                          FROM g_dossier D, t_filiere TF
                         WHERE 1 = 1
                           AND TF.refdoss = D.refdoss
                           AND TF.dtfin IS NULL
                           AND TF.nom IN
                               (SELECT DISTINCT abrev
                                  FROM v_tdomaine
                                 WHERE type = :B5
                                   AND langue = :B6
                                   AND abrev_trad IN
                                       (SELECT regexp_substr(:B7,
                                                             '[^;]+',
                                                             1,
                                                             level)
                                          FROM dual
                                        CONNECT BY regexp_substr(:B8,
                                                                 '[^;]+',
                                                                 1,
                                                                 level) IS NOT NULL)
                                UNION (SELECT regexp_substr(:B9, '[^;]+', 1, level)
                                        FROM dual
                                      CONNECT BY regexp_substr(:B10,
                                                               '[^;]+',
                                                               1,
                                                               level) IS NOT NULL))) D,
                       t_intervenants TDB,
                       g_individu IDB,
                       t_intervenants TCL,
                       g_individu ICL,
                       t_attente ATT,
                       (SELECT /*+ no_expand */
                         DISTINCT gd.refdoss
                             FROM t_intervenants T,
                                  g_individu G,
                                  g_dossier GD
                            WHERE 1 = 1
                              AND G.refindividu = T.refindividu
                              AND T.reftype <> 'XX'
                              AND GD.refdoss = T.refdoss
                              AND (    EXISTS ( SELECT 1
                                                  FROM v_intervenants
                                                 WHERE (    categdoss = ( SELECT abrev
                                                                            FROM v_domaine
                                                                           WHERE valeur = GD.categdoss
                                                                             AND TYPE = :B11 )
                                                         OR categdoss IS NULL )
                                                   AND reftype_bd = t.reftype
                                                   AND reftype_aff LIKE :B12 )
                                    OR EXISTS ( SELECT 1
                                                  FROM v_tdomaine
                                                 WHERE type = :B13
                                                   AND langue = :B14
                                                   AND abrev_trad LIKE :B15
                                                   AND abrev = T.reftype ) )
                              AND G.pays = :B16
                              AND GD.rangmt IN (SELECT P.refperso
                                                  FROM g_personnel P, g_individu I
                                      WHERE P.refindividu = I.refindividu
                                       AND I.nom LIKE :B21 )) DF
                 WHERE 1 = 1
                   AND TDB.refdoss(+) = D.refdoss
                   AND IDB.refindividu(+) = TDB.refindividu
                   AND TDB.reftype(+) = :B17
                   AND TCL.refdoss(+) = D.refdoss
                   AND ICL.refindividu(+) = TCL.refindividu
                   AND ATT.refentite = D.refdoss
                   AND tcl.reftype(+) = 'CL'
                   AND d.refdoss = DF.refdoss
                   AND (idb.str36 IS NULL OR EXISTS
                        (SELECT 1
                           FROM g_indivparam
                          WHERE refindividu = :B18
                            AND type = 'type_indiv'
                            AND str1 = idb.str36))
                   AND EXISTS
                 (SELECT 1
                          FROM g_elemfi E
                         WHERE E.refdoss = D.refdoss
                           AND E.dtannul IS NULL
                           AND TRUNC(E.dtdebut_dt) BETWEEN TRUNC(to_date(:B19,'yyyy-mm-dd')) AND
                               TRUNC(to_date(:B20,'yyyy-mm-dd'))
                           AND NOT EXISTS
                         (SELECT 1
                                  FROM g_elemfi E2
                                 WHERE E2.refdoss = D.refdoss
                                   AND E2.dtdebut > E.dtdebut
                                   AND E.dtannul IS NULL))                   
                 ORDER BY D.refdoss, D.refdoss) foo
         WHERE ROWNUM <= :B22)
 WHERE 1 = 1
   AND rnum >= :B23;  
/********************************New SQL*******************************************/
/********************************New Metrics***************************************/
/*
Plan hash value: 2786517603
-------------------------------------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                                 | Name                        | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads        |
-------------------------------------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                                          |                             |      1 |        |  2148 (100)|      0 |00:00:03.44 |   29199 |   7670 |
|*  1 |  COUNT STOPKEY                                            |                             |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|   2 |   NESTED LOOPS                                            |                             |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|   3 |    NESTED LOOPS                                           |                             |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|   4 |     TABLE ACCESS BY INDEX ROWID BATCHED                   | G_PERSONNEL                 |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*  5 |      INDEX RANGE SCAN                                     | PK_G_PERSONNEL              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*  6 |     INDEX UNIQUE SCAN                                     | IND_REFINDIV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|   7 |    TABLE ACCESS BY INDEX ROWID                            | G_INDIVIDU                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|   8 |  SORT AGGREGATE                                           |                             |      0 |      1 |            |      0 |00:00:00.01 |       0 |      0 |
|*  9 |   FILTER                                                  |                             |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  10 |    FAST DUAL                                              |                             |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|  11 |    NESTED LOOPS                                           |                             |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|  12 |     MERGE JOIN CARTESIAN                                  |                             |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 13 |      TABLE ACCESS BY INDEX ROWID BATCHED                  | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 14 |       INDEX RANGE SCAN                                    | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|  15 |      BUFFER SORT                                          |                             |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|  16 |       TABLE ACCESS BY INDEX ROWID BATCHED                 | T_ELEMENT_SE                |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 17 |        INDEX RANGE SCAN                                   | ELESE_DOSELEM               |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 18 |     INDEX RANGE SCAN                                      | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 19 |  COUNT STOPKEY                                            |                             |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  20 |   NESTED LOOPS                                            |                             |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|  21 |    NESTED LOOPS                                           |                             |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|  22 |     TABLE ACCESS BY INDEX ROWID BATCHED                   | G_PERSONNEL                 |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 23 |      INDEX RANGE SCAN                                     | PK_G_PERSONNEL              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 24 |     INDEX UNIQUE SCAN                                     | IND_REFINDIV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|  25 |    TABLE ACCESS BY INDEX ROWID                            | G_INDIVIDU                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 26 |  VIEW                                                     |                             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|  27 |   TABLE ACCESS FULL                                       | SYS_TEMP_0FD9DFF91_D8F21C32 |      0 |    114 |     5   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 28 |  COUNT STOPKEY                                            |                             |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  29 |   TABLE ACCESS BY INDEX ROWID BATCHED                     | G_PIECE                     |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 30 |    INDEX RANGE SCAN                                       | PIE_REFDOSS                 |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|  31 |  SORT AGGREGATE                                           |                             |      0 |      1 |            |      0 |00:00:00.01 |       0 |      0 |
|* 32 |   TABLE ACCESS BY INDEX ROWID BATCHED                     | G_ELEMFI                    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 33 |    INDEX RANGE SCAN                                       | EFI_DOS_DTEMIS_TYPE         |      0 |      8 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|  34 |  FAST DUAL                                                |                             |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|  35 |  NESTED LOOPS                                             |                             |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|  36 |   NESTED LOOPS                                            |                             |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|  37 |    TABLE ACCESS BY INDEX ROWID BATCHED                    | G_PERSONNEL                 |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 38 |     INDEX RANGE SCAN                                      | PK_G_PERSONNEL              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 39 |    INDEX UNIQUE SCAN                                      | IND_REFINDIV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|  40 |   TABLE ACCESS BY INDEX ROWID                             | G_INDIVIDU                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|  41 |  TEMP TABLE TRANSFORMATION                                |                             |      1 |        |            |      0 |00:00:03.44 |   29199 |   7670 |
|  42 |   LOAD AS SELECT (CURSOR DURATION MEMORY)                 | SYS_TEMP_0FD9DFF91_D8F21C32 |      1 |        |            |      0 |00:00:00.01 |     190 |      0 |
|* 43 |    HASH JOIN                                              |                             |      1 |    114 |    45   (0)|   4396 |00:00:00.01 |     189 |      0 |
|  44 |     VIEW                                                  |                             |      1 |      4 |     8   (0)|      4 |00:00:00.01 |       0 |      0 |
|  45 |      UNION-ALL                                            |                             |      1 |        |            |      4 |00:00:00.01 |       0 |      0 |
|  46 |       FAST DUAL                                           |                             |      1 |      1 |     2   (0)|      1 |00:00:00.01 |       0 |      0 |
|  47 |       FAST DUAL                                           |                             |      1 |      1 |     2   (0)|      1 |00:00:00.01 |       0 |      0 |
|  48 |       FAST DUAL                                           |                             |      1 |      1 |     2   (0)|      1 |00:00:00.01 |       0 |      0 |
|  49 |       FAST DUAL                                           |                             |      1 |      1 |     2   (0)|      1 |00:00:00.01 |       0 |      0 |
|  50 |     VIEW                                                  |                             |      1 |   2849 |    37   (0)|   1099 |00:00:00.01 |     189 |      0 |
|  51 |      VIEW                                                 | V_TDOMAINE                  |      1 |   2849 |    37   (0)|   1099 |00:00:00.01 |     189 |      0 |
|  52 |       UNION-ALL                                           |                             |      1 |        |            |   1099 |00:00:00.01 |     189 |      0 |
|* 53 |        FILTER                                             |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  54 |         TABLE ACCESS BY INDEX ROWID BATCHED               | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 55 |          INDEX RANGE SCAN                                 | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 56 |        FILTER                                             |                             |      1 |        |            |   1099 |00:00:00.01 |     189 |      0 |
|  57 |         TABLE ACCESS BY INDEX ROWID BATCHED               | V_DOMAINE                   |      1 |     77 |     1   (0)|   1099 |00:00:00.01 |     189 |      0 |
|* 58 |          INDEX RANGE SCAN                                 | V_DOMAINE_TYPE_CODE_IDX     |      1 |     77 |     1   (0)|   1099 |00:00:00.01 |      17 |      0 |
|* 59 |        FILTER                                             |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  60 |         TABLE ACCESS BY INDEX ROWID BATCHED               | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 61 |          INDEX RANGE SCAN                                 | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 62 |        FILTER                                             |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  63 |         TABLE ACCESS BY INDEX ROWID BATCHED               | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 64 |          INDEX RANGE SCAN                                 | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 65 |        FILTER                                             |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  66 |         TABLE ACCESS BY INDEX ROWID BATCHED               | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 67 |          INDEX RANGE SCAN                                 | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 68 |        FILTER                                             |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  69 |         TABLE ACCESS BY INDEX ROWID BATCHED               | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 70 |          INDEX RANGE SCAN                                 | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 71 |        FILTER                                             |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  72 |         TABLE ACCESS BY INDEX ROWID BATCHED               | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 73 |          INDEX RANGE SCAN                                 | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 74 |        FILTER                                             |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  75 |         TABLE ACCESS BY INDEX ROWID BATCHED               | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 76 |          INDEX RANGE SCAN                                 | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 77 |        FILTER                                             |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  78 |         TABLE ACCESS BY INDEX ROWID BATCHED               | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 79 |          INDEX RANGE SCAN                                 | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 80 |        FILTER                                             |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  81 |         TABLE ACCESS BY INDEX ROWID BATCHED               | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 82 |          INDEX RANGE SCAN                                 | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 83 |        FILTER                                             |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  84 |         TABLE ACCESS BY INDEX ROWID BATCHED               | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 85 |          INDEX RANGE SCAN                                 | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 86 |        FILTER                                             |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  87 |         TABLE ACCESS BY INDEX ROWID BATCHED               | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 88 |          INDEX RANGE SCAN                                 | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 89 |        FILTER                                             |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  90 |         TABLE ACCESS BY INDEX ROWID BATCHED               | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 91 |          INDEX RANGE SCAN                                 | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 92 |        FILTER                                             |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  93 |         TABLE ACCESS BY INDEX ROWID BATCHED               | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 94 |          INDEX RANGE SCAN                                 | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 95 |        FILTER                                             |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  96 |         TABLE ACCESS BY INDEX ROWID BATCHED               | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 97 |          INDEX RANGE SCAN                                 | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 98 |        FILTER                                             |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  99 |         TABLE ACCESS BY INDEX ROWID BATCHED               | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*100 |          INDEX RANGE SCAN                                 | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*101 |        FILTER                                             |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 102 |         TABLE ACCESS BY INDEX ROWID BATCHED               | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*103 |          INDEX RANGE SCAN                                 | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*104 |        FILTER                                             |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 105 |         TABLE ACCESS BY INDEX ROWID BATCHED               | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*106 |          INDEX RANGE SCAN                                 | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*107 |        FILTER                                             |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 108 |         TABLE ACCESS BY INDEX ROWID BATCHED               | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*109 |          INDEX RANGE SCAN                                 | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*110 |        FILTER                                             |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 111 |         TABLE ACCESS BY INDEX ROWID BATCHED               | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*112 |          INDEX RANGE SCAN                                 | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*113 |        FILTER                                             |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 114 |         TABLE ACCESS BY INDEX ROWID BATCHED               | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*115 |          INDEX RANGE SCAN                                 | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*116 |        FILTER                                             |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 117 |         TABLE ACCESS BY INDEX ROWID BATCHED               | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*118 |          INDEX RANGE SCAN                                 | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*119 |        FILTER                                             |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 120 |         TABLE ACCESS BY INDEX ROWID BATCHED               | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*121 |          INDEX RANGE SCAN                                 | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*122 |        FILTER                                             |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 123 |         TABLE ACCESS BY INDEX ROWID BATCHED               | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*124 |          INDEX RANGE SCAN                                 | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*125 |        FILTER                                             |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 126 |         TABLE ACCESS BY INDEX ROWID BATCHED               | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*127 |          INDEX RANGE SCAN                                 | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*128 |        FILTER                                             |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 129 |         TABLE ACCESS BY INDEX ROWID BATCHED               | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*130 |          INDEX RANGE SCAN                                 | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*131 |        FILTER                                             |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 132 |         TABLE ACCESS BY INDEX ROWID BATCHED               | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*133 |          INDEX RANGE SCAN                                 | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*134 |        FILTER                                             |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 135 |         TABLE ACCESS BY INDEX ROWID BATCHED               | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*136 |          INDEX RANGE SCAN                                 | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*137 |        FILTER                                             |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 138 |         TABLE ACCESS BY INDEX ROWID BATCHED               | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*139 |          INDEX RANGE SCAN                                 | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*140 |        FILTER                                             |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 141 |         TABLE ACCESS BY INDEX ROWID BATCHED               | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*142 |          INDEX RANGE SCAN                                 | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*143 |        FILTER                                             |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 144 |         TABLE ACCESS BY INDEX ROWID BATCHED               | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*145 |          INDEX RANGE SCAN                                 | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*146 |        FILTER                                             |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 147 |         TABLE ACCESS BY INDEX ROWID BATCHED               | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*148 |          INDEX RANGE SCAN                                 | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*149 |        FILTER                                             |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 150 |         TABLE ACCESS BY INDEX ROWID BATCHED               | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*151 |          INDEX RANGE SCAN                                 | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*152 |        FILTER                                             |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 153 |         TABLE ACCESS BY INDEX ROWID BATCHED               | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*154 |          INDEX RANGE SCAN                                 | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*155 |        FILTER                                             |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 156 |         TABLE ACCESS BY INDEX ROWID BATCHED               | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*157 |          INDEX RANGE SCAN                                 | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*158 |        FILTER                                             |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 159 |         TABLE ACCESS BY INDEX ROWID BATCHED               | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*160 |          INDEX RANGE SCAN                                 | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*161 |        FILTER                                             |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 162 |         TABLE ACCESS BY INDEX ROWID BATCHED               | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*163 |          INDEX RANGE SCAN                                 | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*164 |   VIEW                                                    |                             |      1 |      1 |  2103   (1)|      0 |00:00:03.44 |   29008 |   7670 |
|*165 |    COUNT STOPKEY                                          |                             |      1 |        |            |      0 |00:00:03.44 |   29008 |   7670 |
| 166 |     VIEW                                                  |                             |      1 |      1 |  2103   (1)|      0 |00:00:03.44 |   29008 |   7670 |
| 167 |      WINDOW SORT                                          |                             |      1 |      1 |  2103   (1)|      0 |00:00:03.44 |   29008 |   7670 |
|*168 |       FILTER                                              |                             |      1 |        |            |      0 |00:00:03.44 |   29008 |   7670 |
| 169 |        NESTED LOOPS OUTER                                 |                             |      1 |      1 |  2085   (1)|      0 |00:00:03.44 |   29008 |   7670 |
| 170 |         NESTED LOOPS OUTER                                |                             |      1 |      1 |  2084   (1)|      0 |00:00:03.44 |   29008 |   7670 |
| 171 |          NESTED LOOPS                                     |                             |      1 |      1 |  2083   (1)|      0 |00:00:03.44 |   29008 |   7670 |
|*172 |           HASH JOIN                                       |                             |      1 |      1 |  2082   (1)|      0 |00:00:03.44 |   29008 |   7670 |
| 173 |            NESTED LOOPS                                   |                             |      1 |      1 |  2038   (1)|      0 |00:00:03.44 |   29008 |   7670 |
| 174 |             NESTED LOOPS OUTER                            |                             |      1 |      1 |  2037   (1)|      0 |00:00:03.44 |   29008 |   7670 |
| 175 |              NESTED LOOPS OUTER                           |                             |      1 |      1 |  2036   (1)|      0 |00:00:03.44 |   29008 |   7670 |
| 176 |               NESTED LOOPS                                |                             |      1 |      1 |  2035   (1)|      0 |00:00:03.44 |   29008 |   7670 |
| 177 |                VIEW                                       |                             |      1 |      3 |  2034   (1)|      0 |00:00:03.44 |   29008 |   7670 |
| 178 |                 HASH UNIQUE                               |                             |      1 |      3 |  2034   (1)|      0 |00:00:03.44 |   29008 |   7670 |
|*179 |                  FILTER                                   |                             |      1 |        |            |      0 |00:00:03.44 |   29008 |   7670 |
| 180 |                   NESTED LOOPS                            |                             |      1 |    717 |  1826   (0)|   1448 |00:00:03.43 |   28812 |   7664 |
| 181 |                    NESTED LOOPS                           |                             |      1 |  27134 |  1826   (0)|   6587 |00:00:01.31 |   22297 |   5843 |
| 182 |                     NESTED LOOPS                          |                             |      1 |  27134 |  1283   (0)|   6587 |00:00:00.72 |    9121 |   4853 |
| 183 |                      NESTED LOOPS                         |                             |      1 |   5138 |  1181   (1)|   1154 |00:00:00.43 |    6833 |   4286 |
| 184 |                       NESTED LOOPS                        |                             |      1 |     83 |     3   (0)|      4 |00:00:00.37 |    5702 |   4135 |
| 185 |                        TABLE ACCESS BY INDEX ROWID BATCHED| G_INDIVIDU                  |      1 |     78 |     1   (0)|   4430 |00:00:00.33 |    4232 |   4115 |
|*186 |                         INDEX RANGE SCAN                  | G_INDIV_NOM_PROF            |      1 |     78 |     1   (0)|   4430 |00:00:00.01 |      21 |     21 |
| 187 |                        TABLE ACCESS BY INDEX ROWID BATCHED| G_PERSONNEL                 |   4430 |      1 |     1   (0)|      4 |00:00:00.03 |    1470 |     20 |
|*188 |                         INDEX RANGE SCAN                  | GPERS_REFIN_IDX             |   4430 |      1 |     1   (0)|      4 |00:00:00.03 |    1466 |     20 |
| 189 |                       TABLE ACCESS BY INDEX ROWID BATCHED | G_DOSSIER                   |      4 |     62 |    14   (0)|   1154 |00:00:00.06 |    1131 |    151 |
|*190 |                        INDEX RANGE SCAN                   | DOS_GEST                    |      4 |   1564 |     1   (0)|   1154 |00:00:00.03 |      17 |     16 |
|*191 |                      INDEX RANGE SCAN                     | INT_REFDOSS                 |   1154 |      5 |     1   (0)|   6587 |00:00:00.29 |    2288 |    567 |
|*192 |                     INDEX UNIQUE SCAN                     | IND_REFINDIV                |   6587 |      1 |     1   (0)|   6587 |00:00:00.58 |   13176 |    990 |
|*193 |                    TABLE ACCESS BY INDEX ROWID            | G_INDIVIDU                  |   6587 |      1 |     1   (0)|   1448 |00:00:02.12 |    6515 |   1821 |
|*194 |                   FILTER                                  |                             |     28 |        |            |      0 |00:00:00.01 |     196 |      6 |
|*195 |                    TABLE ACCESS FULL                      | V_INTERVENANTS              |     28 |      1 |     3   (0)|      0 |00:00:00.01 |     196 |      6 |
| 196 |                    TABLE ACCESS BY INDEX ROWID BATCHED    | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*197 |                     INDEX RANGE SCAN                      | DOM_TYPVAL                  |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 198 |                   VIEW                                    | V_TDOMAINE                  |     13 |     37 |    37   (0)|      0 |00:00:00.01 |       0 |      0 |
| 199 |                    UNION-ALL                              |                             |     13 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*200 |                     FILTER                                |                             |     13 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*201 |                      TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*202 |                       INDEX RANGE SCAN                    | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*203 |                     FILTER                                |                             |     13 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*204 |                      TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*205 |                       INDEX RANGE SCAN                    | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*206 |                     FILTER                                |                             |     13 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*207 |                      TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*208 |                       INDEX RANGE SCAN                    | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*209 |                     FILTER                                |                             |     13 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*210 |                      TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*211 |                       INDEX RANGE SCAN                    | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*212 |                     FILTER                                |                             |     13 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*213 |                      TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*214 |                       INDEX RANGE SCAN                    | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*215 |                     FILTER                                |                             |     13 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*216 |                      TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*217 |                       INDEX RANGE SCAN                    | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*218 |                     FILTER                                |                             |     13 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*219 |                      TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*220 |                       INDEX RANGE SCAN                    | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*221 |                     FILTER                                |                             |     13 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*222 |                      TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*223 |                       INDEX RANGE SCAN                    | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*224 |                     FILTER                                |                             |     13 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*225 |                      TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*226 |                       INDEX RANGE SCAN                    | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*227 |                     FILTER                                |                             |     13 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*228 |                      TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*229 |                       INDEX RANGE SCAN                    | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*230 |                     FILTER                                |                             |     13 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*231 |                      TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*232 |                       INDEX RANGE SCAN                    | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*233 |                     FILTER                                |                             |     13 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*234 |                      TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*235 |                       INDEX RANGE SCAN                    | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*236 |                     FILTER                                |                             |     13 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*237 |                      TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*238 |                       INDEX RANGE SCAN                    | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*239 |                     FILTER                                |                             |     13 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*240 |                      TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*241 |                       INDEX RANGE SCAN                    | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*242 |                     FILTER                                |                             |     13 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*243 |                      TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*244 |                       INDEX RANGE SCAN                    | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*245 |                     FILTER                                |                             |     13 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*246 |                      TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*247 |                       INDEX RANGE SCAN                    | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*248 |                     FILTER                                |                             |     13 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*249 |                      TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*250 |                       INDEX RANGE SCAN                    | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*251 |                     FILTER                                |                             |     13 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*252 |                      TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*253 |                       INDEX RANGE SCAN                    | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*254 |                     FILTER                                |                             |     13 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*255 |                      TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*256 |                       INDEX RANGE SCAN                    | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*257 |                     FILTER                                |                             |     13 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*258 |                      TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*259 |                       INDEX RANGE SCAN                    | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*260 |                     FILTER                                |                             |     13 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*261 |                      TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*262 |                       INDEX RANGE SCAN                    | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*263 |                     FILTER                                |                             |     13 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*264 |                      TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*265 |                       INDEX RANGE SCAN                    | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*266 |                     FILTER                                |                             |     13 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*267 |                      TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*268 |                       INDEX RANGE SCAN                    | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*269 |                     FILTER                                |                             |     13 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*270 |                      TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*271 |                       INDEX RANGE SCAN                    | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*272 |                     FILTER                                |                             |     13 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*273 |                      TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*274 |                       INDEX RANGE SCAN                    | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*275 |                     FILTER                                |                             |     13 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*276 |                      TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*277 |                       INDEX RANGE SCAN                    | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*278 |                     FILTER                                |                             |     13 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*279 |                      TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*280 |                       INDEX RANGE SCAN                    | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*281 |                     FILTER                                |                             |     13 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*282 |                      TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*283 |                       INDEX RANGE SCAN                    | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*284 |                     FILTER                                |                             |     13 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*285 |                      TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*286 |                       INDEX RANGE SCAN                    | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*287 |                     FILTER                                |                             |     13 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*288 |                      TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*289 |                       INDEX RANGE SCAN                    | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*290 |                     FILTER                                |                             |     13 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*291 |                      TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*292 |                       INDEX RANGE SCAN                    | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*293 |                     FILTER                                |                             |     13 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*294 |                      TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*295 |                       INDEX RANGE SCAN                    | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*296 |                     FILTER                                |                             |     13 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*297 |                      TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*298 |                       INDEX RANGE SCAN                    | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*299 |                     FILTER                                |                             |     13 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*300 |                      TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*301 |                       INDEX RANGE SCAN                    | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*302 |                     FILTER                                |                             |     13 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*303 |                      TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*304 |                       INDEX RANGE SCAN                    | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*305 |                     FILTER                                |                             |     13 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*306 |                      TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*307 |                       INDEX RANGE SCAN                    | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*308 |                     FILTER                                |                             |     13 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*309 |                      TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*310 |                       INDEX RANGE SCAN                    | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 311 |                TABLE ACCESS BY INDEX ROWID                | G_DOSSIER                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*312 |                 INDEX UNIQUE SCAN                         | DOS_REFDOSS                 |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*313 |                  FILTER                                   |                             |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*314 |                   FILTER                                  |                             |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*315 |                    TABLE ACCESS BY INDEX ROWID BATCHED    | G_ELEMFI                    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*316 |                     INDEX SKIP SCAN                       | ELEMFI_REFDOSS_GRP_ANSAF    |      0 |      8 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*317 |                   FILTER                                  |                             |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*318 |                    TABLE ACCESS BY INDEX ROWID BATCHED    | G_ELEMFI                    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*319 |                     INDEX SKIP SCAN                       | ELEMFI_REFDOSS_GRP_ANSAF    |      0 |      8 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*320 |               INDEX RANGE SCAN                            | INT_REFDOSS                 |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*321 |              INDEX RANGE SCAN                             | INT_REFDOSS                 |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*322 |             INDEX RANGE SCAN                              | TIND_FIL                    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 323 |            VIEW                                           | VW_NSO_2                    |      0 |     29 |    44   (7)|      0 |00:00:00.01 |       0 |      0 |
| 324 |             SORT UNIQUE                                   |                             |      0 |     29 |    44   (7)|      0 |00:00:00.01 |       0 |      0 |
| 325 |              UNION-ALL                                    |                             |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*326 |               HASH JOIN                                   |                             |      0 |     28 |    40   (3)|      0 |00:00:00.01 |       0 |      0 |
| 327 |                VIEW                                       | VW_NSO_1                    |      0 |      1 |     3  (34)|      0 |00:00:00.01 |       0 |      0 |
| 328 |                 HASH UNIQUE                               |                             |      0 |      1 |     3  (34)|      0 |00:00:00.01 |       0 |      0 |
| 329 |                  CONNECT BY WITHOUT FILTERING (UNIQUE)    |                             |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 330 |                   FAST DUAL                               |                             |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
| 331 |                VIEW                                       | V_TDOMAINE                  |      0 |   2849 |    37   (0)|      0 |00:00:00.01 |       0 |      0 |
| 332 |                 UNION-ALL                                 |                             |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*333 |                  FILTER                                   |                             |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 334 |                   TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*335 |                    INDEX RANGE SCAN                       | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*336 |                  FILTER                                   |                             |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 337 |                   TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*338 |                    INDEX RANGE SCAN                       | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*339 |                  FILTER                                   |                             |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 340 |                   TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*341 |                    INDEX RANGE SCAN                       | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*342 |                  FILTER                                   |                             |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 343 |                   TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*344 |                    INDEX RANGE SCAN                       | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*345 |                  FILTER                                   |                             |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 346 |                   TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*347 |                    INDEX RANGE SCAN                       | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*348 |                  FILTER                                   |                             |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 349 |                   TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*350 |                    INDEX RANGE SCAN                       | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*351 |                  FILTER                                   |                             |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 352 |                   TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*353 |                    INDEX RANGE SCAN                       | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*354 |                  FILTER                                   |                             |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 355 |                   TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*356 |                    INDEX RANGE SCAN                       | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*357 |                  FILTER                                   |                             |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 358 |                   TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*359 |                    INDEX RANGE SCAN                       | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*360 |                  FILTER                                   |                             |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 361 |                   TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*362 |                    INDEX RANGE SCAN                       | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*363 |                  FILTER                                   |                             |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 364 |                   TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*365 |                    INDEX RANGE SCAN                       | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*366 |                  FILTER                                   |                             |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 367 |                   TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*368 |                    INDEX RANGE SCAN                       | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*369 |                  FILTER                                   |                             |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 370 |                   TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*371 |                    INDEX RANGE SCAN                       | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*372 |                  FILTER                                   |                             |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 373 |                   TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*374 |                    INDEX RANGE SCAN                       | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*375 |                  FILTER                                   |                             |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 376 |                   TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*377 |                    INDEX RANGE SCAN                       | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*378 |                  FILTER                                   |                             |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 379 |                   TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*380 |                    INDEX RANGE SCAN                       | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*381 |                  FILTER                                   |                             |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 382 |                   TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*383 |                    INDEX RANGE SCAN                       | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*384 |                  FILTER                                   |                             |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 385 |                   TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*386 |                    INDEX RANGE SCAN                       | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*387 |                  FILTER                                   |                             |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 388 |                   TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*389 |                    INDEX RANGE SCAN                       | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*390 |                  FILTER                                   |                             |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 391 |                   TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*392 |                    INDEX RANGE SCAN                       | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*393 |                  FILTER                                   |                             |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 394 |                   TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*395 |                    INDEX RANGE SCAN                       | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*396 |                  FILTER                                   |                             |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 397 |                   TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*398 |                    INDEX RANGE SCAN                       | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*399 |                  FILTER                                   |                             |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 400 |                   TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*401 |                    INDEX RANGE SCAN                       | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*402 |                  FILTER                                   |                             |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 403 |                   TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*404 |                    INDEX RANGE SCAN                       | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*405 |                  FILTER                                   |                             |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 406 |                   TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*407 |                    INDEX RANGE SCAN                       | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*408 |                  FILTER                                   |                             |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 409 |                   TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*410 |                    INDEX RANGE SCAN                       | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*411 |                  FILTER                                   |                             |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 412 |                   TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*413 |                    INDEX RANGE SCAN                       | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*414 |                  FILTER                                   |                             |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 415 |                   TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*416 |                    INDEX RANGE SCAN                       | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*417 |                  FILTER                                   |                             |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 418 |                   TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*419 |                    INDEX RANGE SCAN                       | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*420 |                  FILTER                                   |                             |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 421 |                   TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*422 |                    INDEX RANGE SCAN                       | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*423 |                  FILTER                                   |                             |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 424 |                   TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*425 |                    INDEX RANGE SCAN                       | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*426 |                  FILTER                                   |                             |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 427 |                   TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*428 |                    INDEX RANGE SCAN                       | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*429 |                  FILTER                                   |                             |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 430 |                   TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*431 |                    INDEX RANGE SCAN                       | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*432 |                  FILTER                                   |                             |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 433 |                   TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*434 |                    INDEX RANGE SCAN                       | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*435 |                  FILTER                                   |                             |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 436 |                   TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*437 |                    INDEX RANGE SCAN                       | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*438 |                  FILTER                                   |                             |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 439 |                   TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*440 |                    INDEX RANGE SCAN                       | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*441 |                  FILTER                                   |                             |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 442 |                   TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*443 |                    INDEX RANGE SCAN                       | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 444 |               CONNECT BY WITHOUT FILTERING (UNIQUE)       |                             |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 445 |                FAST DUAL                                  |                             |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
| 446 |           TABLE ACCESS BY INDEX ROWID BATCHED             | T_ATTENTE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*447 |            INDEX RANGE SCAN                               | PK_ATTENTE                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 448 |          TABLE ACCESS BY INDEX ROWID                      | G_INDIVIDU                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*449 |           INDEX UNIQUE SCAN                               | IND_REFINDIV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 450 |         TABLE ACCESS BY INDEX ROWID                       | G_INDIVIDU                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*451 |          INDEX UNIQUE SCAN                                | IND_REFINDIV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*452 |        INDEX RANGE SCAN                                   | G_INDIVPARAM_REFIND         |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
-------------------------------------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   1 - filter(ROWNUM=1)
   5 - access("CMP"."REFPERSO"=:B1)
   6 - access("CMI"."REFINDIVIDU"="CMP"."REFINDIVIDU")
   9 - filter( IS NOT NULL)
  13 - filter(("VF"."ECRAN" IS NOT NULL AND "VF"."ABREV16"='O'))
  14 - access("VF"."TYPE"='filiere')
  17 - access("REFDOSS"=:B1)
  18 - access("VT"."TYPE"='typencour' AND "VF"."ECRAN"="VT"."ABREV" AND "LIBELLE"="VT"."VALEUR")
       filter(("VT"."VALEUR" IS NOT NULL AND "VT"."ABREV" IS NOT NULL))
  19 - filter(ROWNUM=1)
  23 - access("SMP"."REFPERSO"=TO_NUMBER(:B1))
  24 - access("SMI"."REFINDIVIDU"="SMP"."REFINDIVIDU")
  26 - filter("TPNCR"."PFX_VALEUR"=:B1)
  28 - filter(ROWNUM=1)
  30 - access("REFDOSS"=:B1 AND "TYPPIECE"='RECOUVREMENT')
  32 - filter(((:B1 IS NOT NULL AND "FI"."CREATEUR"='cfc_migration') OR (:B2 IS NULL AND TRUNC(INTERNAL_FUNCTION("DTJOUR_DT"))=NVL(TRUNC(:B3),TRUNC(:B4)))))
  33 - access("FI"."REFDOSS"=:B1)
  38 - access("PSU"."REFPERSO"=:B1)
  39 - access("ISU"."REFINDIVIDU"="PSU"."REFINDIVIDU")
  43 - access("V"."F"="PFX"."F")
  53 - filter('AL'=:B1)
  55 - access("TYPE"='typencour')
  56 - filter('AN'=:B1)
  58 - access("TYPE"='typencour')
  59 - filter('AR'=:B1)
  61 - access("TYPE"='typencour')
  62 - filter('BG'=:B1)
  64 - access("TYPE"='typencour')
  65 - filter('BR'=:B1)
  67 - access("TYPE"='typencour')
  68 - filter('CE'=:B1)
  70 - access("TYPE"='typencour')
  71 - filter('CH'=:B1)
  73 - access("TYPE"='typencour')
  74 - filter('CS'=:B1)
  76 - access("TYPE"='typencour')
  77 - filter('DA'=:B1)
  79 - access("TYPE"='typencour')
  80 - filter('EL'=:B1)
  82 - access("TYPE"='typencour')
  83 - filter('ES'=:B1)
  85 - access("TYPE"='typencour')
  86 - filter('ET'=:B1)
  88 - access("TYPE"='typencour')
  89 - filter('FI'=:B1)
  91 - access("TYPE"='typencour')
  92 - filter('FL'=:B1)
  94 - access("TYPE"='typencour')
  95 - filter('FR'=:B1)
  97 - access("TYPE"='typencour')
  98 - filter('HR'=:B1)
 100 - access("TYPE"='typencour')
 101 - filter('HU'=:B1)
 103 - access("TYPE"='typencour')
 104 - filter('IT'=:B1)
 106 - access("TYPE"='typencour')
 107 - filter('IW'=:B1)
 109 - access("TYPE"='typencour')
 110 - filter('JA'=:B1)
 112 - access("TYPE"='typencour')
 113 - filter('LT'=:B1)
 115 - access("TYPE"='typencour')
 116 - filter('LV'=:B1)
 118 - access("TYPE"='typencour')
 119 - filter('MX'=:B1)
 121 - access("TYPE"='typencour')
 122 - filter('NL'=:B1)
 124 - access("TYPE"='typencour')
 125 - filter('NO'=:B1)
 127 - access("TYPE"='typencour')
 128 - filter('PL'=:B1)
 130 - access("TYPE"='typencour')
 131 - filter('PT'=:B1)
 133 - access("TYPE"='typencour')
 134 - filter('RO'=:B1)
 136 - access("TYPE"='typencour')
 137 - filter('RU'=:B1)
 139 - access("TYPE"='typencour')
 140 - filter('SK'=:B1)
 142 - access("TYPE"='typencour')
 143 - filter('SL'=:B1)
 145 - access("TYPE"='typencour')
 146 - filter('SR'=:B1)
 148 - access("TYPE"='typencour')
 149 - filter('SV'=:B1)
 151 - access("TYPE"='typencour')
 152 - filter('TR'=:B1)
 154 - access("TYPE"='typencour')
 155 - filter('US'=:B1)
 157 - access("TYPE"='typencour')
 158 - filter('VI'=:B1)
 160 - access("TYPE"='typencour')
 161 - filter('ZH'=:B1)
 163 - access("TYPE"='typencour')
 164 - filter("RNUM">=:B23)
 165 - filter(ROWNUM<=:B22)
 168 - filter(("IDB"."STR36" IS NULL OR  IS NOT NULL))
 172 - access("TF"."NOM"="ABREV")
 179 - filter(( IS NOT NULL OR  IS NOT NULL))
 186 - access("I"."NOM" LIKE :B21)
       filter("I"."NOM" LIKE :B21)
 188 - access("P"."REFINDIVIDU"="I"."REFINDIVIDU")
 190 - access("GD"."RANGMT"="P"."REFPERSO")
 191 - access("GD"."REFDOSS"="T"."REFDOSS")
       filter("T"."REFTYPE"<>'XX')
 192 - access("G"."REFINDIVIDU"="T"."REFINDIVIDU")
 193 - filter("G"."PAYS"=:B16)
 194 - filter(("CATEGDOSS" IS NULL OR "CATEGDOSS"=))
 195 - filter(("REFTYPE_BD"=:B1 AND "REFTYPE_AFF" LIKE :B12))
 197 - access("VALEUR"=:B1 AND "TYPE"=:B11)
 200 - filter('AL'=:B14)
 201 - filter("ABREV_AL" LIKE :B15)
 202 - access("TYPE"=:B13 AND "ABREV"=:B1)
 203 - filter('AN'=:B14)
 204 - filter("ABREV_AN" LIKE :B15)
 205 - access("TYPE"=:B13 AND "ABREV"=:B1)
 206 - filter('AR'=:B14)
 207 - filter("ABREV_AR" LIKE :B15)
 208 - access("TYPE"=:B13 AND "ABREV"=:B1)
 209 - filter('BG'=:B14)
 210 - filter("ABREV_BG" LIKE :B15)
 211 - access("TYPE"=:B13 AND "ABREV"=:B1)
 212 - filter('BR'=:B14)
 213 - filter("ABREV_BR" LIKE :B15)
 214 - access("TYPE"=:B13 AND "ABREV"=:B1)
 215 - filter('CE'=:B14)
 216 - filter("ABREV_CE" LIKE :B15)
 217 - access("TYPE"=:B13 AND "ABREV"=:B1)
 218 - filter('CH'=:B14)
 219 - filter("ABREV_CH" LIKE :B15)
 220 - access("TYPE"=:B13 AND "ABREV"=:B1)
 221 - filter('CS'=:B14)
 222 - filter("ABREV_CS" LIKE :B15)
 223 - access("TYPE"=:B13 AND "ABREV"=:B1)
 224 - filter('DA'=:B14)
 225 - filter("ABREV_DA" LIKE :B15)
 226 - access("TYPE"=:B13 AND "ABREV"=:B1)
 227 - filter('EL'=:B14)
 228 - filter("ABREV_EL" LIKE :B15)
 229 - access("TYPE"=:B13 AND "ABREV"=:B1)
 230 - filter('ES'=:B14)
 231 - filter("ABREV_ES" LIKE :B15)
 232 - access("TYPE"=:B13 AND "ABREV"=:B1)
 233 - filter('ET'=:B14)
 234 - filter("ABREV_ET" LIKE :B15)
 235 - access("TYPE"=:B13 AND "ABREV"=:B1)
 236 - filter('FI'=:B14)
 237 - filter("ABREV_FI" LIKE :B15)
 238 - access("TYPE"=:B13 AND "ABREV"=:B1)
 239 - filter('FL'=:B14)
 240 - filter("ABREV_FL" LIKE :B15)
 241 - access("TYPE"=:B13 AND "ABREV"=:B1)
 242 - filter('FR'=:B14)
 243 - filter(NVL("ABREV_FR","ABREV") LIKE :B15)
 244 - access("TYPE"=:B13 AND "ABREV"=:B1)
 245 - filter('HR'=:B14)
 246 - filter("ABREV_HR" LIKE :B15)
 247 - access("TYPE"=:B13 AND "ABREV"=:B1)
 248 - filter('HU'=:B14)
 249 - filter("ABREV_HU" LIKE :B15)
 250 - access("TYPE"=:B13 AND "ABREV"=:B1)
 251 - filter('IT'=:B14)
 252 - filter("ABREV_IT" LIKE :B15)
 253 - access("TYPE"=:B13 AND "ABREV"=:B1)
 254 - filter('IW'=:B14)
 255 - filter("ABREV_IW" LIKE :B15)
 256 - access("TYPE"=:B13 AND "ABREV"=:B1)
 257 - filter('JA'=:B14)
 258 - filter("ABREV_JA" LIKE :B15)
 259 - access("TYPE"=:B13 AND "ABREV"=:B1)
 260 - filter('LT'=:B14)
 261 - filter("ABREV_LT" LIKE :B15)
 262 - access("TYPE"=:B13 AND "ABREV"=:B1)
 263 - filter('LV'=:B14)
 264 - filter("ABREV_LV" LIKE :B15)
 265 - access("TYPE"=:B13 AND "ABREV"=:B1)
 266 - filter('MX'=:B14)
 267 - filter("ABREV_MX" LIKE :B15)
 268 - access("TYPE"=:B13 AND "ABREV"=:B1)
 269 - filter('NL'=:B14)
 270 - filter("ABREV_NL" LIKE :B15)
 271 - access("TYPE"=:B13 AND "ABREV"=:B1)
 272 - filter('NO'=:B14)
 273 - filter("ABREV_NO" LIKE :B15)
 274 - access("TYPE"=:B13 AND "ABREV"=:B1)
 275 - filter('PL'=:B14)
 276 - filter("ABREV_PL" LIKE :B15)
 277 - access("TYPE"=:B13 AND "ABREV"=:B1)
 278 - filter('PT'=:B14)
 279 - filter("ABREV_PT" LIKE :B15)
 280 - access("TYPE"=:B13 AND "ABREV"=:B1)
 281 - filter('RO'=:B14)
 282 - filter("ABREV_RO" LIKE :B15)
 283 - access("TYPE"=:B13 AND "ABREV"=:B1)
 284 - filter('RU'=:B14)
 285 - filter("ABREV_RU" LIKE :B15)
 286 - access("TYPE"=:B13 AND "ABREV"=:B1)
 287 - filter('SK'=:B14)
 288 - filter("ABREV_SK" LIKE :B15)
 289 - access("TYPE"=:B13 AND "ABREV"=:B1)
 290 - filter('SL'=:B14)
 291 - filter("ABREV_SL" LIKE :B15)
 292 - access("TYPE"=:B13 AND "ABREV"=:B1)
 293 - filter('SR'=:B14)
 294 - filter("ABREV_SR" LIKE :B15)
 295 - access("TYPE"=:B13 AND "ABREV"=:B1)
 296 - filter('SV'=:B14)
 297 - filter("ABREV_SV" LIKE :B15)
 298 - access("TYPE"=:B13 AND "ABREV"=:B1)
 299 - filter('TR'=:B14)
 300 - filter("ABREV_TR" LIKE :B15)
 301 - access("TYPE"=:B13 AND "ABREV"=:B1)
 302 - filter('US'=:B14)
 303 - filter("ABREV_US" LIKE :B15)
 304 - access("TYPE"=:B13 AND "ABREV"=:B1)
 305 - filter('VI'=:B14)
 306 - filter("ABREV_VI" LIKE :B15)
 307 - access("TYPE"=:B13 AND "ABREV"=:B1)
 308 - filter('ZH'=:B14)
 309 - filter("ABREV_ZH" LIKE :B15)
 310 - access("TYPE"=:B13 AND "ABREV"=:B1)
 312 - access("D"."REFDOSS"="DF"."REFDOSS")
       filter( IS NOT NULL)
 313 - filter( IS NULL)
 314 - filter(TRUNC(TO_DATE(:B20,'yyyy-mm-dd'))>=TRUNC(TO_DATE(:B19,'yyyy-mm-dd')))
 315 - filter(("E"."DTANNUL" IS NULL AND TRUNC(INTERNAL_FUNCTION("E"."DTDEBUT_DT"))>=TRUNC(TO_DATE(:B19,'yyyy-mm-dd')) AND
              TRUNC(INTERNAL_FUNCTION("E"."DTDEBUT_DT"))<=TRUNC(TO_DATE(:B20,'yyyy-mm-dd'))))
 316 - access("E"."REFDOSS"=:B1)
 317 - filter(:B1 IS NULL)
 318 - filter("E2"."DTDEBUT">:B1)
 319 - access("E2"."REFDOSS"=:B1)
 320 - access("TDB"."REFDOSS"="D"."REFDOSS" AND "TDB"."REFTYPE"=:B17)
 321 - access("TCL"."REFDOSS"="D"."REFDOSS" AND "TCL"."REFTYPE"='CL')
 322 - access("TF"."REFDOSS"="D"."REFDOSS" AND "TF"."DTFIN" IS NULL)
       filter("TF"."DTFIN" IS NULL)
 326 - access("ABREV_TRAD"="REGEXP_SUBSTR(:B7,'[^;]+',1,LEVEL)")
 333 - filter('AL'=:B6)
 335 - access("TYPE"=:B5)
 336 - filter('AN'=:B6)
 338 - access("TYPE"=:B5)
 339 - filter('AR'=:B6)
 341 - access("TYPE"=:B5)
 342 - filter('BG'=:B6)
 344 - access("TYPE"=:B5)
 345 - filter('BR'=:B6)
 347 - access("TYPE"=:B5)
 348 - filter('CE'=:B6)
 350 - access("TYPE"=:B5)
 351 - filter('CH'=:B6)
 353 - access("TYPE"=:B5)
 354 - filter('CS'=:B6)
 356 - access("TYPE"=:B5)
 357 - filter('DA'=:B6)
 359 - access("TYPE"=:B5)
 360 - filter('EL'=:B6)
 362 - access("TYPE"=:B5)
 363 - filter('ES'=:B6)
 365 - access("TYPE"=:B5)
 366 - filter('ET'=:B6)
 368 - access("TYPE"=:B5)
 369 - filter('FI'=:B6)
 371 - access("TYPE"=:B5)
 372 - filter('FL'=:B6)
 374 - access("TYPE"=:B5)
 375 - filter('FR'=:B6)
 377 - access("TYPE"=:B5)
 378 - filter('HR'=:B6)
 380 - access("TYPE"=:B5)
 381 - filter('HU'=:B6)
 383 - access("TYPE"=:B5)
 384 - filter('IT'=:B6)
 386 - access("TYPE"=:B5)
 387 - filter('IW'=:B6)
 389 - access("TYPE"=:B5)
 390 - filter('JA'=:B6)
 392 - access("TYPE"=:B5)
 393 - filter('LT'=:B6)
 395 - access("TYPE"=:B5)
 396 - filter('LV'=:B6)
 398 - access("TYPE"=:B5)
 399 - filter('MX'=:B6)
 401 - access("TYPE"=:B5)
 402 - filter('NL'=:B6)
 404 - access("TYPE"=:B5)
 405 - filter('NO'=:B6)
 407 - access("TYPE"=:B5)
 408 - filter('PL'=:B6)
 410 - access("TYPE"=:B5)
 411 - filter('PT'=:B6)
 413 - access("TYPE"=:B5)
 414 - filter('RO'=:B6)
 416 - access("TYPE"=:B5)
 417 - filter('RU'=:B6)
 419 - access("TYPE"=:B5)
 420 - filter('SK'=:B6)
 422 - access("TYPE"=:B5)
 423 - filter('SL'=:B6)
 425 - access("TYPE"=:B5)
 426 - filter('SR'=:B6)
 428 - access("TYPE"=:B5)
 429 - filter('SV'=:B6)
 431 - access("TYPE"=:B5)
 432 - filter('TR'=:B6)
 434 - access("TYPE"=:B5)
 435 - filter('US'=:B6)
 437 - access("TYPE"=:B5)
 438 - filter('VI'=:B6)
 440 - access("TYPE"=:B5)
 441 - filter('ZH'=:B6)
 443 - access("TYPE"=:B5)
 447 - access("ATT"."REFENTITE"="D"."REFDOSS")
 449 - access("IDB"."REFINDIVIDU"="TDB"."REFINDIVIDU")
 451 - access("ICL"."REFINDIVIDU"="TCL"."REFINDIVIDU")
 452 - access("REFINDIVIDU"=:B18 AND "TYPE"='type_indiv' AND "STR1"=:B1)
       filter("STR1"=:B1)
*/
/********************************New Metrics***************************************/

/********************************Index statistics**********************************/

/********************************Other SQLs****************************************/          
/*

*/ 
/********************************Other SQLs****************************************/              
