/********************************************************************************
*********       E-mail subject: KBCCFWEB-2258
*********             Instance: PROD
*********          Description: 
Problem:
Slowness in SQL 9yuw3p3ahrm7t on KBC PROD.

Analysis:
After the investigation, SQL 9yuw3p3ahrm7t was considered as slow. This problem was already discussed in KBCCFDEV-4880.
The problem is that Oracle choose execution plan ( Plan hash value: 932470534 ) where makes UNION ALL PUSHED PREDICATE into the EXISTS, which is not such a big problem when we have specific value for :B2
and "dtlot LIKE :B2" will return only a few lines, but when be use for example :B2 = 'KBC%', it returns a lot of rows from "dtlot LIKE :B2" and enters into the EXISTS
for every row. I reproduced it on KBC ACC1. First, I executed the SQL with :B2 = 'VIY-00-02/11/23%' several times in row to make oracle choose execution plan with Plan hash value: 932470534
and after that changed :B2 := 'KBC%'. In this case, Oracle doesn't know that "dtlot LIKE :B2" will return a lot of rows and choose the same execution plan, which leaded to
selecting over 7k rows from g_lotcoll and enter in the EXISTS for every row. The SQL should start from the EXISTS and then go through table g_lotcoll,
which can be achieved by removing "dtlot LIKE :B2". Is it possible to remove "dtlot LIKE :B2" as it is shown in the New SQL section below?

Suggestion:
Please remove the "dtlot LIKE :B2" if it is possible as it is shown in the New SQL section below.

*********               SQL_ID: 9yuw3p3ahrm7t
*********      Program/Package: 
*********              Request: Dimitare Ivanov
*********               Author: Dimitar Dimitrov
********* Received e-mail date: 19/02/2024
*********      Resolution date: 20/02/2024
*********  Trace old file here: \\epox\specifs\performance\tmp\
*********  Trace new file here:
***********************************************************************************/

/********************************OLD SQL*******************************************/

var B1 varchar2(32);
exec :B1 := 'DD/MM/RR';
var B2 varchar2(32);
exec :B2 := 'KBC%';
--exec :B2 := 'VIY-00-02/11/23%';
var B3 number;
exec :B3 := 0;
var B4 number;
exec :B4 := 2001;

SELECT g.nbr nbr,
       g.nbr encodedNbr,
       SUBSTR(nbr, 1, LENGTH(nbr) - 8) ||
       TO_CHAR(TO_DATE(SUBSTR(nbr, -8), 'DD/MM/RR'), :B1) displayNbr,
       NVL(vd.chemin, gc.code_journal) bookCode,
       g.unidentifiedTransNb + g.identifiedTransNb + g.tempTransNb +
       g.extraApplTransNb totalNb,
       g.unidentifiedTransNb unidentifiedTransNb,
       g.unidentifiedTransAmt unidentifiedTransAmt,
       g.identifiedTransNb identifiedTransNb,
       g.identifiedTransAmt identifiedTransAmt,
       g.tempTransNb tempTransNb,
       g.tempTransAmt tempTransAmt,
       g.extraApplTransNb extraApplTransNb,
       g.extraApplTransAmt extraApplTransAmt,
       g.splitTransNb splitTransNb,
       glot.createur creator,
       glot.totmont totalamt,
       glot.ancsolde ancBalance,
       glot.numcpt accountNb,
       glot.reffactor factorReference,
       glot.refcptbq bankaccRef,
       glot.traite processed,
       glot.valide validated
  FROM g_lotcoll glot,
       (SELECT DTLOT nbr,
               MAX(NB_RCN) unidentifiedTransNb,
               MAX(MT_RCN) unidentifiedTransAmt,
               MAX(NB_RCI) identifiedTransNb,
               MAX(MT_RCI) identifiedTransAmt,
               MAX(NB_RCP) tempTransNb,
               MAX(MT_RCP) tempTransAmt,
               MAX(NB_RCH) extraApplTransNb,
               MAX(MT_RCH) extraApplTransAmt,
               MAX(NB_SPLIT) splitTransNb
          FROM (SELECT gl.dtlot dtlot,
                       nam.etat,
                       SUM(DECODE(nam.etat,
                                  'RCN',
                                  DECODE(NVL(nam.signe, 0),
                                         1,
                                         -nam.montant,
                                         nam.montant),
                                  'RCK',
                                  DECODE(NVL(nam.signe, 0),
                                         1,
                                         -nam.montant,
                                         nam.montant),
                                  0)) OVER(PARTITION BY nam.dtlot) AS MT_RCN,
                       SUM(DECODE(nam.etat, 'RCN', 1, 'RCK', 1, 0)) OVER(PARTITION BY nam.dtlot) AS NB_RCN,
                       SUM(DECODE(nam.etat,
                                  'RCI',
                                  DECODE(NVL(nam.fg_non_bank_payment, '#'),
                                         '#',
                                         DECODE(NVL(nam.signe, 0),
                                                1,
                                                -nam.montant,
                                                nam.montant),
                                         0),
                                  'RCN',
                                  DECODE(NVL(nam.fg_non_bank_payment, '#'),
                                         '#',
                                         0,
                                         (SELECT SUM(DECODE(NVL(signe, 0),
                                                            1,
                                                            montant,
                                                            -montant))
                                            FROM nam_collecte
                                           WHERE etat = 'RCI'
                                             AND compostage =
                                                 nam.master_compostage)),
                                  0)) OVER(PARTITION BY nam.dtlot) AS MT_RCI,
                       SUM(DECODE(nam.etat,
                                  'RCI',
                                  DECODE(NVL(nam.fg_non_bank_payment, '#'),
                                         '#',
                                         1,
                                         0),
                                  0)) OVER(PARTITION BY nam.dtlot) AS NB_RCI,
                       SUM(DECODE(nam.etat,
                                  'RCP',
                                  DECODE(NVL(nam.fg_non_bank_payment, '#'),
                                         '#',
                                         DECODE(NVL(nam.signe, 0),
                                                1,
                                                -nam.montant,
                                                nam.montant),
                                         0),
                                  'RCN',
                                  DECODE(NVL(nam.fg_non_bank_payment, '#'),
                                         '#',
                                         0,
                                         (SELECT SUM(DECODE(NVL(signe, 0),
                                                            1,
                                                            montant,
                                                            -montant))
                                            FROM nam_collecte
                                           WHERE etat = 'RCP'
                                             AND compostage =
                                                 nam.master_compostage)),
                                  0)) OVER(PARTITION BY nam.dtlot) AS MT_RCP,
                       SUM(DECODE(nam.etat,
                                  'RCP',
                                  DECODE(NVL(nam.fg_non_bank_payment, '#'),
                                         '#',
                                         1,
                                         0),
                                  0)) OVER(PARTITION BY nam.dtlot) AS NB_RCP,
                       SUM(DECODE(nam.etat,
                                  'RCH',
                                  DECODE(NVL(nam.fg_non_bank_payment, '#'),
                                         '#',
                                         DECODE(NVL(nam.traite, '9999'),
                                                '75',
                                                DECODE(NVL(nam.refer, '#'),
                                                       '#',
                                                       1,
                                                       0),
                                                1) *
                                         DECODE(NVL(nam.signe, 0),
                                                1,
                                                -nam.montant,
                                                nam.montant),
                                         0),
                                  0)) OVER(PARTITION BY nam.dtlot) AS MT_RCH,
                       SUM(DECODE(nam.etat,
                                  'RCH',
                                  DECODE(NVL(nam.fg_non_bank_payment, '#'),
                                         '#',
                                         DECODE(NVL(nam.traite, '9999'),
                                                '75',
                                                DECODE(NVL(nam.refer, '#'),
                                                       '#',
                                                       1,
                                                       0),
                                                1),
                                         0),
                                  0)) OVER(PARTITION BY nam.dtlot) AS NB_RCH,
                       0 AS NB_SPLIT
                  FROM nam_collecte nam,
                       (SELECT dtlot
                          FROM g_lotcoll
                         WHERE 1 = 1
                           AND dtlot LIKE :B2
                           AND EXISTS (SELECT /*+ index(nam_collecte NAMCOLL_REFER_ETAT_TRA_DTL) */
                                       1
                                  FROM nam_collecte
                                 WHERE dtlot = g_lotcoll.dtlot
                                   AND dtlot LIKE :B2
                                   AND etat IN ('RCK', 'RCN')
                                   AND refer IS NULL
                                UNION
                                SELECT 1
                                  FROM nam_collecte
                                 WHERE dtlot = g_lotcoll.dtlot
                                   AND dtlot LIKE :B2
                                   AND etat = 'RCB'
                                UNION
                                SELECT /*+ index(nam_collecte NAMCOLL_REFER_ETAT_TRA_DTL) */
                                 1
                                  FROM nam_collecte
                                 WHERE dtlot = g_lotcoll.dtlot
                                   AND dtlot LIKE :B2
                                   AND etat = 'RCH'
                                   AND refer IS NULL)
                         ORDER BY SUBSTR(dtlot, 1, 3),
                                  TO_DATE(SUBSTR(dtlot, -8), 'dd/mm/yy') DESC,
                                  TO_NUMBER(SUBSTR(dtlot, 5, 2)) OFFSET :B3 ROWS FETCH NEXT :B4 ROWS ONLY) gl
                 WHERE nam.dtlot(+) = gl.dtlot)
         GROUP BY dtlot) g,
       v_domaine vd,
       g_cptbq gc
 WHERE glot.dtlot = g.nbr
   AND SUBSTR(glot.dtlot, 1, 3) = vd.abrev(+)
   AND 'NAM_COLLECTE' = vd.type(+)
   AND glot.refcptbq = gc.refcptbq(+)
 ORDER BY SUBSTR(dtlot, 1, 3),
          TO_DATE(SUBSTR(dtlot, -8), 'dd/mm/yy') DESC,
          TO_NUMBER(SUBSTR(dtlot, 5, 2));
/********************************OLD SQL*******************************************/
/********************************OLD Metrics***************************************/
/*
Plan hash value: 932470534
-----------------------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                    | Name                       | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  |
-----------------------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                             |                            |      1 |        |   348 (100)|   1578 |00:00:55.76 |    4439K|   3093 |
|   1 |  SORT AGGREGATE                              |                            |      0 |      1 |            |      0 |00:00:00.01 |       0 |      0 |
|*  2 |   TABLE ACCESS BY INDEX ROWID BATCHED        | NAM_COLLECTE               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*  3 |    INDEX RANGE SCAN                          | COLCOMPOSTAGE              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|   4 |  SORT AGGREGATE                              |                            |      0 |      1 |            |      0 |00:00:00.01 |       0 |      0 |
|*  5 |   TABLE ACCESS BY INDEX ROWID BATCHED        | NAM_COLLECTE               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*  6 |    INDEX RANGE SCAN                          | COLCOMPOSTAGE              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|   7 |  SORT ORDER BY                               |                            |      1 |     24 |   348   (2)|   1578 |00:00:55.76 |    4439K|   3093 |
|   8 |   NESTED LOOPS OUTER                         |                            |      1 |     24 |   347   (2)|   1578 |00:00:55.75 |    4439K|   3093 |
|   9 |    NESTED LOOPS OUTER                        |                            |      1 |     24 |   346   (2)|   1578 |00:00:55.75 |    4439K|   3093 |
|  10 |     NESTED LOOPS                             |                            |      1 |     24 |   345   (2)|   1578 |00:00:55.75 |    4439K|   3093 |
|  11 |      VIEW                                    |                            |      1 |     24 |   344   (2)|   1578 |00:00:55.74 |    4435K|   3093 |
|  12 |       HASH GROUP BY                          |                            |      1 |     24 |   344   (2)|   1578 |00:00:55.74 |    4435K|   3093 |
|  13 |        VIEW                                  |                            |      1 |     24 |   343   (2)|    170K|00:00:55.71 |    4435K|   3093 |
|  14 |         WINDOW SORT                          |                            |      1 |     24 |   343   (2)|    170K|00:00:55.69 |    4435K|   3093 |
|  15 |          NESTED LOOPS OUTER                  |                            |      1 |     24 |   318   (1)|    170K|00:00:55.39 |    4435K|   3093 |
|  16 |           VIEW                               |                            |      1 |      1 |   317   (1)|   1578 |00:00:55.24 |    4393K|   3093 |
|  17 |            SORT ORDER BY                     |                            |      1 |      1 |   317   (1)|   1578 |00:00:55.24 |    4393K|   3093 |
|* 18 |             VIEW                             |                            |      1 |      1 |   316   (1)|   1578 |00:00:55.24 |    4393K|   3093 |
|* 19 |              WINDOW SORT PUSHED RANK         |                            |      1 |      1 |   316   (1)|   1578 |00:00:55.24 |    4393K|   3093 |
|* 20 |               FILTER                         |                            |      1 |        |            |   1578 |00:00:55.23 |    4393K|   3093 |
|  21 |                NESTED LOOPS                  |                            |      1 |      1 |   315   (1)|   1578 |00:00:55.23 |    4393K|   3093 |
|* 22 |                 INDEX RANGE SCAN             | G_LOTCOLL_PK               |      1 |      1 |     1   (0)|   7376 |00:00:00.01 |      30 |      0 |
|  23 |                 VIEW                         | VW_SQ_1                    |   7376 |      1 |   314   (1)|   1578 |00:00:55.22 |    4393K|   3093 |
|  24 |                  SORT UNIQUE                 |                            |   7376 |      3 |   314   (1)|   1578 |00:00:55.22 |    4393K|   3093 |
|  25 |                   UNION ALL PUSHED PREDICATE |                            |   7376 |        |            |   1973 |00:00:55.19 |    4393K|   3093 |
|* 26 |                    FILTER                    |                            |   7376 |        |            |   1959 |00:00:46.70 |    3865K|      0 |
|  27 |                     INLIST ITERATOR          |                            |   7376 |        |            |   1959 |00:00:46.69 |    3865K|      0 |
|* 28 |                      INDEX RANGE SCAN        | NAMCOLL_REFER_ETAT_TRA_DTL |  14752 |      1 |     4   (0)|   1959 |00:00:46.69 |    3865K|      0 |
|* 29 |                    FILTER                    |                            |   7376 |        |            |      0 |00:00:01.21 |   19409 |   3093 |
|* 30 |                     INDEX RANGE SCAN         | DTLOT_ETAT_IND             |   7376 |      1 |     1   (0)|      0 |00:00:01.20 |   19409 |   3093 |
|* 31 |                    FILTER                    |                            |   7376 |        |            |     14 |00:00:07.27 |     508K|      0 |
|* 32 |                     INDEX RANGE SCAN         | NAMCOLL_REFER_ETAT_TRA_DTL |   7376 |      1 |   308   (1)|     14 |00:00:07.26 |     508K|      0 |
|  33 |           TABLE ACCESS BY INDEX ROWID BATCHED| NAM_COLLECTE               |   1578 |     24 |     1   (0)|    170K|00:00:00.14 |   42234 |      0 |
|* 34 |            INDEX RANGE SCAN                  | NAM_DTLOT                  |   1578 |     24 |     1   (0)|    170K|00:00:00.02 |    5379 |      0 |
|  35 |      TABLE ACCESS BY INDEX ROWID             | G_LOTCOLL                  |   1578 |      1 |     1   (0)|   1578 |00:00:00.01 |    3694 |      0 |
|* 36 |       INDEX UNIQUE SCAN                      | G_LOTCOLL_PK               |   1578 |      1 |     1   (0)|   1578 |00:00:00.01 |    2116 |      0 |
|  37 |     TABLE ACCESS BY INDEX ROWID BATCHED      | G_CPTBQ                    |   1578 |      1 |     1   (0)|   1578 |00:00:00.01 |       9 |      0 |
|* 38 |      INDEX RANGE SCAN                        | PK_CPTBQ_REFCPTBQ          |   1578 |      1 |     1   (0)|   1578 |00:00:00.01 |       8 |      0 |
|  39 |    TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE                  |   1578 |      1 |     1   (0)|   1578 |00:00:00.01 |       9 |      0 |
|* 40 |     INDEX RANGE SCAN                         | DOM_TYPABREV               |   1578 |      1 |     1   (0)|   1578 |00:00:00.01 |       8 |      0 |
-----------------------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   2 - filter("ETAT"='RCI')
   3 - access("COMPOSTAGE"=:B1)
   5 - filter("ETAT"='RCP')
   6 - access("COMPOSTAGE"=:B1)
  18 - filter(("from$_subquery$_012"."rowlimit_$$_rownumber"<=GREATEST(FLOOR(TO_NUMBER(TO_CHAR(:B3))),0)+:B4 AND
              "from$_subquery$_012"."rowlimit_$$_rownumber">:B3))
  19 - filter(ROW_NUMBER() OVER ( ORDER BY SUBSTR("DTLOT",1,3),TO_DATE(SUBSTR("DTLOT",(-8)),'dd/mm/yy') DESC
              ,TO_NUMBER(SUBSTR("DTLOT",5,2)))<=GREATEST(FLOOR(TO_NUMBER(TO_CHAR(:B3))),0)+:B4)
  20 - filter(:B3<GREATEST(FLOOR(TO_NUMBER(TO_CHAR(:B3))),0)+:B4)
  22 - access("DTLOT" LIKE :B2)
       filter("DTLOT" LIKE :B2)
  26 - filter("G_LOTCOLL"."DTLOT" LIKE :B2)
  28 - access((("ETAT"='RCK' OR "ETAT"='RCN')) AND "REFER" IS NULL AND "DTLOT"="G_LOTCOLL"."DTLOT")
       filter(("DTLOT"="G_LOTCOLL"."DTLOT" AND "DTLOT" LIKE :B2))
  29 - filter("G_LOTCOLL"."DTLOT" LIKE :B2)
  30 - access("DTLOT"="G_LOTCOLL"."DTLOT" AND "ETAT"='RCB')
       filter("DTLOT" LIKE :B2)
  31 - filter("G_LOTCOLL"."DTLOT" LIKE :B2)
  32 - access("ETAT"='RCH' AND "REFER" IS NULL AND "DTLOT"="G_LOTCOLL"."DTLOT")
       filter(("DTLOT"="G_LOTCOLL"."DTLOT" AND "DTLOT" LIKE :B2))
  34 - access("NAM"."DTLOT"="GL"."DTLOT")
  36 - access("GLOT"."DTLOT"="G"."NBR")
  38 - access("GLOT"."REFCPTBQ"="GC"."REFCPTBQ")
  40 - access("VD"."TYPE"='NAM_COLLECTE' AND "VD"."ABREV"=SUBSTR("GLOT"."DTLOT",1,3))
*/
/********************************OLD Metrics***************************************/

/********************************New SQL*******************************************/

SELECT g.nbr nbr,
       g.nbr encodedNbr,
       SUBSTR(nbr, 1, LENGTH(nbr) - 8) ||
       TO_CHAR(TO_DATE(SUBSTR(nbr, -8), 'DD/MM/RR'), :B1) displayNbr,
       NVL(vd.chemin, gc.code_journal) bookCode,
       g.unidentifiedTransNb + g.identifiedTransNb + g.tempTransNb +
       g.extraApplTransNb totalNb,
       g.unidentifiedTransNb unidentifiedTransNb,
       g.unidentifiedTransAmt unidentifiedTransAmt,
       g.identifiedTransNb identifiedTransNb,
       g.identifiedTransAmt identifiedTransAmt,
       g.tempTransNb tempTransNb,
       g.tempTransAmt tempTransAmt,
       g.extraApplTransNb extraApplTransNb,
       g.extraApplTransAmt extraApplTransAmt,
       g.splitTransNb splitTransNb,
       glot.createur creator,
       glot.totmont totalamt,
       glot.ancsolde ancBalance,
       glot.numcpt accountNb,
       glot.reffactor factorReference,
       glot.refcptbq bankaccRef,
       glot.traite processed,
       glot.valide validated
  FROM g_lotcoll glot,
       (SELECT DTLOT nbr,
               MAX(NB_RCN) unidentifiedTransNb,
               MAX(MT_RCN) unidentifiedTransAmt,
               MAX(NB_RCI) identifiedTransNb,
               MAX(MT_RCI) identifiedTransAmt,
               MAX(NB_RCP) tempTransNb,
               MAX(MT_RCP) tempTransAmt,
               MAX(NB_RCH) extraApplTransNb,
               MAX(MT_RCH) extraApplTransAmt,
               MAX(NB_SPLIT) splitTransNb
          FROM (SELECT gl.dtlot dtlot,
                       nam.etat,
                       SUM(DECODE(nam.etat,
                                  'RCN',
                                  DECODE(NVL(nam.signe, 0),
                                         1,
                                         -nam.montant,
                                         nam.montant),
                                  'RCK',
                                  DECODE(NVL(nam.signe, 0),
                                         1,
                                         -nam.montant,
                                         nam.montant),
                                  0)) OVER(PARTITION BY nam.dtlot) AS MT_RCN,
                       SUM(DECODE(nam.etat, 'RCN', 1, 'RCK', 1, 0)) OVER(PARTITION BY nam.dtlot) AS NB_RCN,
                       SUM(DECODE(nam.etat,
                                  'RCI',
                                  DECODE(NVL(nam.fg_non_bank_payment, '#'),
                                         '#',
                                         DECODE(NVL(nam.signe, 0),
                                                1,
                                                -nam.montant,
                                                nam.montant),
                                         0),
                                  'RCN',
                                  DECODE(NVL(nam.fg_non_bank_payment, '#'),
                                         '#',
                                         0,
                                         (SELECT SUM(DECODE(NVL(signe, 0),
                                                            1,
                                                            montant,
                                                            -montant))
                                            FROM nam_collecte
                                           WHERE etat = 'RCI'
                                             AND compostage =
                                                 nam.master_compostage)),
                                  0)) OVER(PARTITION BY nam.dtlot) AS MT_RCI,
                       SUM(DECODE(nam.etat,
                                  'RCI',
                                  DECODE(NVL(nam.fg_non_bank_payment, '#'),
                                         '#',
                                         1,
                                         0),
                                  0)) OVER(PARTITION BY nam.dtlot) AS NB_RCI,
                       SUM(DECODE(nam.etat,
                                  'RCP',
                                  DECODE(NVL(nam.fg_non_bank_payment, '#'),
                                         '#',
                                         DECODE(NVL(nam.signe, 0),
                                                1,
                                                -nam.montant,
                                                nam.montant),
                                         0),
                                  'RCN',
                                  DECODE(NVL(nam.fg_non_bank_payment, '#'),
                                         '#',
                                         0,
                                         (SELECT SUM(DECODE(NVL(signe, 0),
                                                            1,
                                                            montant,
                                                            -montant))
                                            FROM nam_collecte
                                           WHERE etat = 'RCP'
                                             AND compostage =
                                                 nam.master_compostage)),
                                  0)) OVER(PARTITION BY nam.dtlot) AS MT_RCP,
                       SUM(DECODE(nam.etat,
                                  'RCP',
                                  DECODE(NVL(nam.fg_non_bank_payment, '#'),
                                         '#',
                                         1,
                                         0),
                                  0)) OVER(PARTITION BY nam.dtlot) AS NB_RCP,
                       SUM(DECODE(nam.etat,
                                  'RCH',
                                  DECODE(NVL(nam.fg_non_bank_payment, '#'),
                                         '#',
                                         DECODE(NVL(nam.traite, '9999'),
                                                '75',
                                                DECODE(NVL(nam.refer, '#'),
                                                       '#',
                                                       1,
                                                       0),
                                                1) *
                                         DECODE(NVL(nam.signe, 0),
                                                1,
                                                -nam.montant,
                                                nam.montant),
                                         0),
                                  0)) OVER(PARTITION BY nam.dtlot) AS MT_RCH,
                       SUM(DECODE(nam.etat,
                                  'RCH',
                                  DECODE(NVL(nam.fg_non_bank_payment, '#'),
                                         '#',
                                         DECODE(NVL(nam.traite, '9999'),
                                                '75',
                                                DECODE(NVL(nam.refer, '#'),
                                                       '#',
                                                       1,
                                                       0),
                                                1),
                                         0),
                                  0)) OVER(PARTITION BY nam.dtlot) AS NB_RCH,
                       0 AS NB_SPLIT
                  FROM nam_collecte nam,
                       (SELECT dtlot
                          FROM g_lotcoll
                         WHERE 1 = 1
                           AND EXISTS (SELECT /*+ index(nam_collecte NAMCOLL_REFER_ETAT_TRA_DTL) */
                                       1
                                  FROM nam_collecte
                                 WHERE dtlot = g_lotcoll.dtlot
                                   AND dtlot LIKE :B2
                                   AND etat IN ('RCK', 'RCN')
                                   AND refer IS NULL
                                UNION
                                SELECT 1
                                  FROM nam_collecte
                                 WHERE dtlot = g_lotcoll.dtlot
                                   AND dtlot LIKE :B2
                                   AND etat = 'RCB'
                                UNION
                                SELECT /*+ index(nam_collecte NAMCOLL_REFER_ETAT_TRA_DTL) */
                                 1
                                  FROM nam_collecte
                                 WHERE dtlot = g_lotcoll.dtlot
                                   AND dtlot LIKE :B2
                                   AND etat = 'RCH'
                                   AND refer IS NULL)
                         ORDER BY SUBSTR(dtlot, 1, 3),
                                  TO_DATE(SUBSTR(dtlot, -8), 'dd/mm/yy') DESC,
                                  TO_NUMBER(SUBSTR(dtlot, 5, 2)) OFFSET :B3 ROWS FETCH NEXT :B4 ROWS ONLY) gl
                 WHERE nam.dtlot(+) = gl.dtlot)
         GROUP BY dtlot) g,
       v_domaine vd,
       g_cptbq gc
 WHERE glot.dtlot = g.nbr
   AND SUBSTR(glot.dtlot, 1, 3) = vd.abrev(+)
   AND 'NAM_COLLECTE' = vd.type(+)
   AND glot.refcptbq = gc.refcptbq(+)
 ORDER BY SUBSTR(dtlot, 1, 3),
          TO_DATE(SUBSTR(dtlot, -8), 'dd/mm/yy') DESC,
          TO_NUMBER(SUBSTR(dtlot, 5, 2));
/********************************New SQL*******************************************/
/********************************New Metrics***************************************/
/*
Plan hash value: 3481095074
-----------------------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                    | Name                       | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  |
-----------------------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                             |                            |      1 |        |   518 (100)|   1578 |00:00:09.80 |   53472 |  30418 |
|   1 |  SORT AGGREGATE                              |                            |      0 |      1 |            |      0 |00:00:00.01 |       0 |      0 |
|*  2 |   TABLE ACCESS BY INDEX ROWID BATCHED        | NAM_COLLECTE               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*  3 |    INDEX RANGE SCAN                          | COLCOMPOSTAGE              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|   4 |  SORT AGGREGATE                              |                            |      0 |      1 |            |      0 |00:00:00.01 |       0 |      0 |
|*  5 |   TABLE ACCESS BY INDEX ROWID BATCHED        | NAM_COLLECTE               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*  6 |    INDEX RANGE SCAN                          | COLCOMPOSTAGE              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|   7 |  SORT ORDER BY                               |                            |      1 |      8 |   518   (2)|   1578 |00:00:09.80 |   53472 |  30418 |
|   8 |   NESTED LOOPS OUTER                         |                            |      1 |      8 |   517   (2)|   1578 |00:00:09.79 |   53472 |  30418 |
|   9 |    NESTED LOOPS OUTER                        |                            |      1 |      8 |   516   (2)|   1578 |00:00:09.79 |   53463 |  30418 |
|  10 |     NESTED LOOPS                             |                            |      1 |      8 |   515   (2)|   1578 |00:00:09.79 |   53454 |  30418 |
|  11 |      VIEW                                    |                            |      1 |      8 |   514   (2)|   1578 |00:00:09.25 |   49760 |  29314 |
|  12 |       HASH GROUP BY                          |                            |      1 |      8 |   514   (2)|   1578 |00:00:09.25 |   49760 |  29314 |
|  13 |        VIEW                                  |                            |      1 |    193 |   513   (1)|    170K|00:00:09.22 |   49760 |  29314 |
|  14 |         WINDOW SORT                          |                            |      1 |    193 |   513   (1)|    170K|00:00:09.20 |   49760 |  29314 |
|  15 |          NESTED LOOPS OUTER                  |                            |      1 |    193 |   319   (2)|    170K|00:00:08.88 |   49760 |  29314 |
|  16 |           VIEW                               |                            |      1 |      8 |   318   (2)|   1578 |00:00:00.02 |     933 |      0 |
|  17 |            SORT ORDER BY                     |                            |      1 |      8 |   318   (2)|   1578 |00:00:00.02 |     933 |      0 |
|* 18 |             VIEW                             |                            |      1 |      8 |   317   (1)|   1578 |00:00:00.02 |     933 |      0 |
|* 19 |              WINDOW SORT PUSHED RANK         |                            |      1 |      8 |   317   (1)|   1578 |00:00:00.02 |     933 |      0 |
|* 20 |               FILTER                         |                            |      1 |        |            |   1578 |00:00:00.01 |     933 |      0 |
|  21 |                NESTED LOOPS                  |                            |      1 |      8 |   316   (1)|   1578 |00:00:00.01 |     933 |      0 |
|  22 |                 VIEW                         | VW_SQ_1                    |      1 |      8 |   315   (1)|   1578 |00:00:00.01 |     601 |      0 |
|  23 |                  SORT UNIQUE                 |                            |      1 |      8 |   315   (1)|   1578 |00:00:00.01 |     601 |      0 |
|  24 |                   UNION-ALL                  |                            |      1 |        |            |   1973 |00:00:00.01 |     601 |      0 |
|  25 |                    INLIST ITERATOR           |                            |      1 |        |            |   1959 |00:00:00.01 |     525 |      0 |
|* 26 |                     INDEX RANGE SCAN         | NAMCOLL_REFER_ETAT_TRA_DTL |      2 |      1 |     4   (0)|   1959 |00:00:00.01 |     525 |      0 |
|* 27 |                    INDEX RANGE SCAN          | NAMCOLL_REFER_ETAT_TRA_DTL |      1 |      1 |     1   (0)|      0 |00:00:00.01 |       4 |      0 |
|* 28 |                    INDEX RANGE SCAN          | NAMCOLL_REFER_ETAT_TRA_DTL |      1 |      6 |   308   (1)|     14 |00:00:00.01 |      72 |      0 |
|* 29 |                 INDEX UNIQUE SCAN            | G_LOTCOLL_PK               |   1578 |      1 |     1   (0)|   1578 |00:00:00.01 |     332 |      0 |
|  30 |           TABLE ACCESS BY INDEX ROWID BATCHED| NAM_COLLECTE               |   1578 |     24 |     1   (0)|    170K|00:00:08.84 |   48827 |  29314 |
|* 31 |            INDEX RANGE SCAN                  | NAM_DTLOT                  |   1578 |     24 |     1   (0)|    170K|00:00:00.04 |    5379 |      0 |
|  32 |      TABLE ACCESS BY INDEX ROWID             | G_LOTCOLL                  |   1578 |      1 |     1   (0)|   1578 |00:00:00.54 |    3694 |   1104 |
|* 33 |       INDEX UNIQUE SCAN                      | G_LOTCOLL_PK               |   1578 |      1 |     1   (0)|   1578 |00:00:00.01 |    2116 |      0 |
|  34 |     TABLE ACCESS BY INDEX ROWID BATCHED      | G_CPTBQ                    |   1578 |      1 |     1   (0)|   1578 |00:00:00.01 |       9 |      0 |
|* 35 |      INDEX RANGE SCAN                        | PK_CPTBQ_REFCPTBQ          |   1578 |      1 |     1   (0)|   1578 |00:00:00.01 |       8 |      0 |
|  36 |    TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE                  |   1578 |      1 |     1   (0)|   1578 |00:00:00.01 |       9 |      0 |
|* 37 |     INDEX RANGE SCAN                         | DOM_TYPABREV               |   1578 |      1 |     1   (0)|   1578 |00:00:00.01 |       8 |      0 |
-----------------------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   2 - filter("ETAT"='RCI')
   3 - access("COMPOSTAGE"=:B1)
   5 - filter("ETAT"='RCP')
   6 - access("COMPOSTAGE"=:B1)
  18 - filter(("from$_subquery$_012"."rowlimit_$$_rownumber"<=GREATEST(FLOOR(TO_NUMBER(TO_CHAR(:B3))),0)+:B4 AND
              "from$_subquery$_012"."rowlimit_$$_rownumber">:B3))
  19 - filter(ROW_NUMBER() OVER ( ORDER BY SUBSTR("DTLOT",1,3),TO_DATE(SUBSTR("DTLOT",(-8)),'dd/mm/yy') DESC
              ,TO_NUMBER(SUBSTR("DTLOT",5,2)))<=GREATEST(FLOOR(TO_NUMBER(TO_CHAR(:B3))),0)+:B4)
  20 - filter(:B3<GREATEST(FLOOR(TO_NUMBER(TO_CHAR(:B3))),0)+:B4)
  26 - access((("ETAT"='RCK' OR "ETAT"='RCN')) AND "REFER" IS NULL AND "DTLOT" LIKE :B2)
       filter("DTLOT" LIKE :B2)
  27 - access("ETAT"='RCB' AND "DTLOT" LIKE :B2)
       filter("DTLOT" LIKE :B2)
  28 - access("ETAT"='RCH' AND "REFER" IS NULL AND "DTLOT" LIKE :B2)
       filter("DTLOT" LIKE :B2)
  29 - access("VW_COL_1"="G_LOTCOLL"."DTLOT")
  31 - access("NAM"."DTLOT"="GL"."DTLOT")
  33 - access("GLOT"."DTLOT"="G"."NBR")
  35 - access("GLOT"."REFCPTBQ"="GC"."REFCPTBQ")
  37 - access("VD"."TYPE"='NAM_COLLECTE' AND "VD"."ABREV"=SUBSTR("GLOT"."DTLOT",1,3))
*/
/********************************New Metrics***************************************/

/********************************Index statistics**********************************/

/********************************Other SQLs****************************************/          
/*

*/ 
/********************************Other SQLs****************************************/              
