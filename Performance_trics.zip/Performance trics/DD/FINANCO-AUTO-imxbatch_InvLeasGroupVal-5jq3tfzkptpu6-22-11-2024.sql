/********************************************************************************
*********       E-mail subject: FINANCODEV-114
*********             Instance: AUTO
*********          Description: 
Problem:
The imxbatch_InvLeasGroupVal batch took over 1h during the NJ.

Analysis:
We checked the work of the imxbatch_InvLeasGroupVal and found that the TOP SQL in it, which was responsible for 73% of the time was 5jq3tfzkptpu6.
This is simple SELECT statement from table F_DETFAC, which was executed ~1500 times and makes FULL SCAN on table F_DETFAC on every execution, because there is 
TO_CHAR() on column IMX_UN_ID, which doesn't allow Oracle to use the index of the column and makes FULL SCAN. To avoid the FULL SCAN, the TO_CHAR() from column IMX_UN_ID 
should be removed.

Suggestion:
Please remove the TO_CHAR() from column IMX_UN_ID and add TO_NUMBER() on the bind variable as it is shown in the New SQL section below 
or remove the TO_CHAR() from column IMX_UN_ID and use bind variable from type NUMBER.

*********               SQL_ID: 5jq3tfzkptpu6
*********      Program/Package: 
*********              Request: Giao My Tran 
*********               Author: Dimitar Dimitrov
********* Received e-mail date: 21/11/2024
*********      Resolution date: 22/11/2024
*********  Trace old file here: \\epox\specifs\performance\tmp\
*********  Trace new file here:
***********************************************************************************/

/********************************OLD SQL*******************************************/

VAR B1 VARCHAR2(32);
EXEC :B1 := '3464603';
VAR B2 VARCHAR2(32);
EXEC :B2 := 'YYYY';

SELECT TO_CHAR(DT_DUE_DT, :B2 ) 
  FROM F_DETFAC 
 WHERE TO_CHAR(IMX_UN_ID) = :B1;
/********************************OLD SQL*******************************************/
/********************************OLD Metrics***************************************/
/*

MODULE                           PROGRAM                                            CLIENT_ID       SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- -------------------------------------------------- --------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
imxbatch_InvLeasGroupVal         imxbatch                                                                                          1175      11514 direct path read     2024/11/22 01:40:35  2024/11/22 02:43:33       2424                  1490 +000000000 01:02:58.625 19%
msgq_pilote                                                                                                                                        ON CPU               2024/11/22 01:37:06  2024/11/22 02:49:56       2264              16755818 +000000000 01:12:50.498 18%
msgq_pilote                                                                                                                                        db file sequential r 2024/11/22 01:37:07  2024/11/22 02:49:59       1124                291597 +000000000 01:12:52.544 9%
imxbatch_InvLeasGroupVal         imxbatch                                                                                                          ON CPU               2024/11/22 01:37:02  2024/11/22 02:45:04       1050               1091980 +000000000 01:08:02.752 8%


MODULE                           PROGRAM                                            CLIENT_ID       SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- -------------------------------------------------- --------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
imxbatch_InvLeasGroupVal         imxbatch                                                                                                                               2024/11/22 01:37:01  2024/11/22 02:45:08       3931               1091980 +000000000 01:08:07.871 100%



MODULE                           PROGRAM                                            CLIENT_ID       SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- -------------------------------------------------- --------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
imxbatch_InvLeasGroupVal         imxbatch                                                                                          1175      11514 direct path read     2024/11/22 01:40:35  2024/11/22 02:43:33       2424                  1490 +000000000 01:02:58.625 62%
imxbatch_InvLeasGroupVal         imxbatch                                                                                                          ON CPU               2024/11/22 01:37:02  2024/11/22 02:45:04       1050               1091980 +000000000 01:08:02.752 27%
imxbatch_InvLeasGroupVal         imxbatch                                                                                                          db file sequential r 2024/11/22 01:37:01  2024/11/22 02:45:08        388                 75134 +000000000 01:08:07.871 10%
imxbatch_InvLeasGroupVal         imxbatch                                                           1bw1kaq8g659k 3532947879       1175      11514 enq: TX - row lock c 2024/11/22 02:09:18  2024/11/22 02:10:17         41                    24 +000000000 00:00:59.392 1%
imxbatch_InvLeasGroupVal         imxbatch                                                                                          1175      11514 db file parallel rea 2024/11/22 01:38:31  2024/11/22 02:44:07         11                168361 +000000000 01:05:36.319 0%


MODULE                           PROGRAM                                            CLIENT_ID       SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- -------------------------------------------------- --------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
imxbatch_InvLeasGroupVal         imxbatch                                                           5jq3tfzkptpu6 3236947827       1175      11514                      2024/11/22 01:40:35  2024/11/22 02:43:33       2880                  1490 +000000000 01:02:58.625 73%
imxbatch_InvLeasGroupVal         imxbatch                                                           cpr8041p0xpxw 4210369732                                            2024/11/22 01:37:11  2024/11/22 02:45:04        161                   564 +000000000 01:07:53.536 4%
imxbatch_InvLeasGroupVal         imxbatch                                                           5dabz1pvatgs0 3792502790                                            2024/11/22 01:37:09  2024/11/22 02:45:07         96                  1605 +000000000 01:07:58.655 2%
imxbatch_InvLeasGroupVal         imxbatch                                                           f83d7mkuxx8jn          0       1175      11514 ON CPU               2024/11/22 01:37:50  2024/11/22 02:45:01         92                  3933 +000000000 01:07:11.554 2%
imxbatch_InvLeasGroupVal         imxbatch                                                           du5h5ntyzunpx          0       1175      11514 ON CPU               2024/11/22 01:38:50  2024/11/22 02:41:21         76                   237 +000000000 01:02:30.975 2%
imxbatch_InvLeasGroupVal         imxbatch                                                           dwvr7yzdy3thj 2107938818       1175      11514                      2024/11/22 01:37:06  2024/11/22 02:44:36         54                   343 +000000000 01:07:29.985 1%



INSTANCE_NUMBER SQL_ID            ELAPSED MAX_WAIT_ON     PC_OF  WAIT_TIME            GETS      READS       ROWS  ELAP/EXEC       GETS/EXEC READS/EXEC  ROWS/EXEC       EXEC PLAN_HASH_VALUE
--------------- ------------- ----------- --------------- ----- ---------- --------------- ---------- ---------- ---------- --------------- ---------- ---------- ---------- ---------------
              1 5dabz1pvatgs0          48 IO              94%    49.963004          100642      32897       3281         .1             205      66.86       6.67        492      3792502790
              1 5jq3tfzkptpu6         950 IO              82%   959.592249        10848833   10843219        490       1.93           22095   22083.95          1        491      3236947827
              1 cpr8041p0xpxw          65 CPU             98%    64.312521        56464965       4998        246        .26          224960      19.91        .98        251      4210369732


Plan hash value: 3236947827
--------------------------------------------------------------------------------------------------------------
| Id  | Operation         | Name     | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  |
--------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT  |          |      1 |        |  4680 (100)|      1 |00:00:02.40 |   22235 |  22231 |
|*  1 |  TABLE ACCESS FULL| F_DETFAC |      1 |      1 |  4680   (1)|      1 |00:00:02.40 |   22235 |  22231 |
--------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   1 - filter(TO_CHAR("IMX_UN_ID")=:B1)


*/
/********************************OLD Metrics***************************************/

/********************************New SQL*******************************************/


SELECT TO_CHAR(DT_DUE_DT, :B2 ) 
  FROM F_DETFAC 
 WHERE IMX_UN_ID = TO_NUMBER(:B1);

/********************************New SQL*******************************************/
/********************************New Metrics***************************************/
/*

Plan hash value: 1808589731
---------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                   | Name        | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  |
---------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT            |             |      1 |        |     1 (100)|      1 |00:00:00.02 |       3 |      3 |
|   1 |  TABLE ACCESS BY INDEX ROWID| F_DETFAC    |      1 |      1 |     1   (0)|      1 |00:00:00.02 |       3 |      3 |
|*  2 |   INDEX UNIQUE SCAN         | PK_F_DETFAC |      1 |      1 |     1   (0)|      1 |00:00:00.02 |       2 |      2 |
---------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   2 - access("IMX_UN_ID"=TO_NUMBER(:B1))
*/
/********************************New Metrics***************************************/

/********************************Index statistics**********************************/

/********************************Other SQLs****************************************/          
/*

*/ 
/********************************Other SQLs****************************************/              
