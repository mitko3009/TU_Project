
ssh -i /etc/session/.ssh/eh/hosts/id_rsa opc@10.8.247.7	



/home/sftpm/transfer/IMXPROD_RMAN/rman_20241117



Hello team, 



Someone from SA should store the PROD backup on Sunday under
/home/sftpm/transfer/rman_xxxxxx

Then, on Monday morning DBA team should :

1.	Stop UATM Instance, crontab is already disabled
2.	After the RMAN import please apply preservation tasks on UATM
3.	Apply attached sql statement(keep log just for sure if EH request it) 
4.	Return to system.support to restart Extranet and Intranet applications on UATM and uncomment crontab

Re-installation of the patches will not be needed, as now UATM and PROD are on the same patch level. 

Thank you 


The queries that have to be run after: uat_queries_after_restore_2022_04_Updated.sql 

Please also run the following query after refreshing for UAT printer setting for France:

SQL> update t_imprimante set code_optique='1' where imprimante='P24';

SQL> commit;
''

uat_queries_after_restore_2022_04_Updated.sql
 

/imxprod/intra/RMAN/rman_20241117




---- UATM 
scp

P@ssForC0dix

P@ssForC0dix	

scp -r rman_20241117 oracle@10.8.247.7:/home/sftpm/transfer/IMXPROD_RMAN/

/home/sftpm/transfer


1. Check the backup


/home/sftpm/transfer 

670600

IMXUATM




2. Ceck the file systems

/dev/mapper/vg_hotfix-UATM_DBS         778G  654G   93G  88% /imxuatm/intra/dbs

/imxuatm/intra/dbs/
/imxuatm/intra/dbs/



3. Generate the rman script





--------
SET pages 1000 lines 1000
SELECT 'SET NEWNAME FOR DATAFILE ''' || NAME || ''' TO ''' ||
       REPLACE(NAME, '/imxprod/intra/dbs/', '/imxuatm/intra/dbs/') || ''';'
  FROM v$datafile
  UNION ALL
SELECT 'SET NEWNAME FOR TEMPFILE ''' || NAME || ''' TO ''' ||
       REPLACE(NAME, '/imxprod/intra/dbs/', '/imxuatm/intra/dbs/') || ''';'
  FROM v$tempfile;


  
  
  set line 300
col MEMBER for a50
select l.group#, l.thread#,
f.member,
l.archived,
l.status,
(bytes/1024/1024) fsize_MB
from
v$log l, v$logfile f
where f.group# = l.group#
order by 1,2;




export ORACLE_SID=IMXPROD
export ORACLE_HOME=/imxuatm/intra/rdbms/12.1
export PATH=$ORACLE_HOME/bin:$PATH

rman target / nocatalog <<EOF
RUN
{
allocate channel 'dev_0' device type disk;
allocate channel 'dev_1' device type disk;
allocate channel 'dev_2' device type disk;
allocate channel 'dev_3' device type disk;
allocate channel 'dev_4' device type disk;
allocate channel 'dev_5' device type disk;
allocate channel 'dev_6' device type disk;
allocate channel 'dev_7' device type disk;
allocate channel 'dev_8' device type disk;
allocate channel 'dev_9' device type disk;
SET NEWNAME FOR DATAFILE '/imxprod/intra/dbs/SYSTEM/system01.dbf' TO '/imxuatm/intra/dbs/SYSTEM/system01.dbf';
SET NEWNAME FOR DATAFILE '/imxprod/intra/dbs/SYSTEM/sysaux01.dbf' TO '/imxuatm/intra/dbs/SYSTEM/sysaux01.dbf';
SET NEWNAME FOR DATAFILE '/imxprod/intra/dbs/UNDO/undotbs01.dbf' TO '/imxuatm/intra/dbs/UNDO/undotbs01.dbf';
SET NEWNAME FOR DATAFILE '/imxprod/intra/dbs/SYSTEM/tbs_1.dbf' TO '/imxuatm/intra/dbs/SYSTEM/tbs_1.dbf';
SET NEWNAME FOR DATAFILE '/imxprod/intra/dbs/DATA/CODTD01.dbf' TO '/imxuatm/intra/dbs/DATA/CODTD01.dbf';
SET NEWNAME FOR DATAFILE '/imxprod/intra/dbs/INDEX/CODTX01.dbf' TO '/imxuatm/intra/dbs/INDEX/CODTX01.dbf';
SET NEWNAME FOR DATAFILE '/imxprod/intra/dbs/DATA/IMXBUFFTBS01.dbf' TO '/imxuatm/intra/dbs/DATA/IMXBUFFTBS01.dbf';
SET NEWNAME FOR DATAFILE '/imxprod/intra/dbs/DATA/ARCHDATA01.dbf' TO '/imxuatm/intra/dbs/DATA/ARCHDATA01.dbf';
SET NEWNAME FOR DATAFILE '/imxprod/intra/dbs/INDEX/ARCHINDEX01.dbf' TO '/imxuatm/intra/dbs/INDEX/ARCHINDEX01.dbf';
SET NEWNAME FOR DATAFILE '/imxprod/intra/dbs/RCU/IMXDB_STB.dbf' TO '/imxuatm/intra/dbs/RCU/IMXDB_STB.dbf';
SET NEWNAME FOR DATAFILE '/imxprod/intra/dbs/RCU/IMXDB_IAS_OPSS.dbf' TO '/imxuatm/intra/dbs/RCU/IMXDB_IAS_OPSS.dbf';
SET NEWNAME FOR DATAFILE '/imxprod/intra/dbs/RCU/IMXDB_IAU.dbf' TO '/imxuatm/intra/dbs/RCU/IMXDB_IAU.dbf';
SET NEWNAME FOR DATAFILE '/imxprod/intra/dbs/RCU/IMXDB_WLS.dbf' TO '/imxuatm/intra/dbs/RCU/IMXDB_WLS.dbf';
SET NEWNAME FOR DATAFILE '/imxprod/intra/dbs/LOB/LOB.dbf' TO '/imxuatm/intra/dbs/LOB/LOB.dbf';
SET NEWNAME FOR DATAFILE '/imxprod/intra/dbs/DATA/CODTD02.dbf' TO '/imxuatm/intra/dbs/DATA/CODTD02.dbf';
SET NEWNAME FOR DATAFILE '/imxprod/intra/dbs/DATA/CODTD03.dbf' TO '/imxuatm/intra/dbs/DATA/CODTD03.dbf';
SET NEWNAME FOR DATAFILE '/imxprod/intra/dbs/DATA/CODTD04.dbf' TO '/imxuatm/intra/dbs/DATA/CODTD04.dbf';
SET NEWNAME FOR DATAFILE '/imxprod/intra/dbs/DATA/CODTD05.dbf' TO '/imxuatm/intra/dbs/DATA/CODTD05.dbf';
SET NEWNAME FOR DATAFILE '/imxprod/intra/dbs/DATA/CODTD06.dbf' TO '/imxuatm/intra/dbs/DATA/CODTD06.dbf';
SET NEWNAME FOR DATAFILE '/imxprod/intra/dbs/DATA/CODTD07.dbf' TO '/imxuatm/intra/dbs/DATA/CODTD07.dbf';
SET NEWNAME FOR DATAFILE '/imxprod/intra/dbs/DATA/CODTD08.dbf' TO '/imxuatm/intra/dbs/DATA/CODTD08.dbf';
SET NEWNAME FOR DATAFILE '/imxprod/intra/dbs/DATA/CODTD09.dbf' TO '/imxuatm/intra/dbs/DATA/CODTD09.dbf';
SET NEWNAME FOR DATAFILE '/imxprod/intra/dbs/INDEX/CODTX02.dbf' TO '/imxuatm/intra/dbs/INDEX/CODTX02.dbf';
SET NEWNAME FOR DATAFILE '/imxprod/intra/dbs/INDEX/CODTX03.dbf' TO '/imxuatm/intra/dbs/INDEX/CODTX03.dbf';
SET NEWNAME FOR DATAFILE '/imxprod/intra/dbs/INDEX/CODTX04.dbf' TO '/imxuatm/intra/dbs/INDEX/CODTX04.dbf';
SET NEWNAME FOR DATAFILE '/imxprod/intra/dbs/INDEX/CODTX05.dbf' TO '/imxuatm/intra/dbs/INDEX/CODTX05.dbf';
SET NEWNAME FOR DATAFILE '/imxprod/intra/dbs/INDEX/CODTX06.dbf' TO '/imxuatm/intra/dbs/INDEX/CODTX06.dbf';
SET NEWNAME FOR DATAFILE '/imxprod/intra/dbs/INDEX/CODTX07.dbf' TO '/imxuatm/intra/dbs/INDEX/CODTX07.dbf';
SET NEWNAME FOR DATAFILE '/imxprod/intra/dbs/LOB/LOB01.dbf' TO '/imxuatm/intra/dbs/LOB/LOB01.dbf';
SET NEWNAME FOR DATAFILE '/imxprod/intra/dbs/LOB/LOB02.dbf' TO '/imxuatm/intra/dbs/LOB/LOB02.dbf';
SET NEWNAME FOR DATAFILE '/imxprod/intra/dbs/LOB/LOB03.dbf' TO '/imxuatm/intra/dbs/LOB/LOB03.dbf';
SET NEWNAME FOR DATAFILE '/imxprod/intra/dbs/UNDO/undotbs02.dbf' TO '/imxuatm/intra/dbs/UNDO/undotbs02.dbf';
SET NEWNAME FOR DATAFILE '/imxprod/intra/dbs/LOB/LOB05.dbf' TO '/imxuatm/intra/dbs/LOB/LOB05.dbf';
SET NEWNAME FOR DATAFILE '/imxprod/intra/dbs/DATA/statspack_data01.dbf' TO '/imxuatm/intra/dbs/DATA/statspack_data01.dbf';
SET NEWNAME FOR DATAFILE '/imxprod/intra/dbs/LOB/LOB06.dbf' TO '/imxuatm/intra/dbs/LOB/LOB06.dbf';
SET NEWNAME FOR DATAFILE '/imxprod/intra/dbs/DATA/CODTD10.dbf' TO '/imxuatm/intra/dbs/DATA/CODTD10.dbf';
SET NEWNAME FOR TEMPFILE '/imxprod/intra/dbs/TEMP/temp01.dbf' TO '/imxuatm/intra/dbs/TEMP/temp01.dbf';
SET NEWNAME FOR TEMPFILE '/imxprod/intra/dbs/TEMP/IMXUITEMP01.dbf' TO '/imxuatm/intra/dbs/TEMP/IMXUITEMP01.dbf';
SET NEWNAME FOR TEMPFILE '/imxprod/intra/dbs/RCU/IMXDB_IAS_TEMP.dbf' TO '/imxuatm/intra/dbs/RCU/IMXDB_IAS_TEMP.dbf';
SET NEWNAME FOR TEMPFILE '/imxprod/intra/dbs/TEMP/temp02.dbf' TO '/imxuatm/intra/dbs/TEMP/temp02.dbf';
SET NEWNAME FOR TEMPFILE '/imxprod/intra/dbs/TEMP/temp03.dbf' TO '/imxuatm/intra/dbs/TEMP/temp03.dbf';
SET NEWNAME FOR TEMPFILE '/imxprod/intra/dbs/TEMP/temp04.dbf' TO '/imxuatm/intra/dbs/TEMP/temp04.dbf';
SET NEWNAME FOR TEMPFILE '/imxprod/intra/dbs/TEMP/temp05.dbf' TO '/imxuatm/intra/dbs/TEMP/temp05.dbf';
SQL "ALTER DATABASE RENAME FILE ''/imxprod/intra/dbs/REDO/redo01.log'' TO ''/imxuatm/intra/dbs/REDO/redo01.log''";
SQL "ALTER DATABASE RENAME FILE ''/imxprod/intra/dbs/REDO/redo02.log'' TO ''/imxuatm/intra/dbs/REDO/redo02.log''";
SQL "ALTER DATABASE RENAME FILE ''/imxprod/intra/dbs/REDO/redo03.log'' TO ''/imxuatm/intra/dbs/REDO/redo03.log''";
RESTORE DATABASE;
SWITCH DATAFILE ALL;
SWITCH TEMPFILE ALL;
recover database;
}
exit;
EOF






4. Stop the UATM database.


shu immediate ;

5. Start the dummy instance



unset ORACLE_SID
export ORACLE_SID=IMXPROD

sqlplus / as sysdba
startup nomount ;
exit ;


6. Restore thhe control file:


rman target /
restore controlfile FROM '/home/sftpm/transfer/IMXPROD_RMAN/rman_20241117/c-4293504228-20241117-00.ctl.autobackup';
alter database mount;

7. Delete expired backups.

crosscheck backup ;
delete noprompt expired backup;





8. Catalog the backup files.


catalog START WITH '/home/sftpm/transfer/IMXPROD_RMAN/rman_20241117/' NOPROMPT;


---






9. Start the  rman restore


chmod 777 Restore.sh 

nohup ./Restore.sh > 18112024Restore_shel.log 2>&1&




alter database open resetlogs ;



10 . recreate temp files



---- recreate temp files

alter database tempfile  '/imxuatm/intra/dbs/TEMP/temp01.dbf' drop including datafiles;

ALTER TABLESPACE TEMP ADD TEMPFILE '/imxuatm/intra/dbs/TEMP/temp01.dbf'  SIZE 100M  REUSE AUTOEXTEND on maxsize 32000M;      


--- temp
alter database tempfile '/imxuatm/intra/dbs/TEMP/temp02.dbf'        drop including datafiles;              
ALTER TABLESPACE TEMP ADD TEMPFILE '/imxuatm/intra/dbs/TEMP/temp02.dbf'         SIZE 100M  REUSE AUTOEXTEND on maxsize 32000M;       
 
alter database tempfile '/imxuatm/intra/dbs/TEMP/temp03.dbf'        drop including datafiles;              
ALTER TABLESPACE TEMP ADD TEMPFILE '/imxuatm/intra/dbs/TEMP/temp03.dbf'          SIZE 100M  REUSE AUTOEXTEND on maxsize 32000M;         
 
 alter database tempfile '/imxuatm/intra/dbs/TEMP/temp04.dbf'        drop including datafiles;              
ALTER TABLESPACE TEMP ADD TEMPFILE '/imxuatm/intra/dbs/TEMP/temp04.dbf'          SIZE 100M  REUSE AUTOEXTEND on maxsize 32000M;      
 
  alter database tempfile '/imxuatm/intra/dbs/TEMP/temp05.dbf'        drop including datafiles;              
ALTER TABLESPACE TEMP ADD TEMPFILE  '/imxuatm/intra/dbs/TEMP/temp05.dbf' SIZE 100M  REUSE AUTOEXTEND on maxsize 2000M;      
 --------------------------------------- ---------------------------- ---------------
alter database tempfile '/imxuatm/intra/dbs/RCU/IMXDB_IAS_TEMP.dbf' drop including datafiles; 
ALTER TABLESPACE IMXDB_IAS_TEMP ADD TEMPFILE '/imxuatm/intra/dbs/RCU/IMXDB_IAS_TEMP.dbf'  SIZE 100M  REUSE AUTOEXTEND on maxsize unlimited;        


 -----   
alter database tempfile '/imxuatm/intra/dbs/TEMP/IMXUITEMP01.dbf'   drop including datafiles;      
ALTER TABLESPACE IMXUITEMP      ADD TEMPFILE '/imxuatm/intra/dbs/TEMP/IMXUITEMP01.dbf'    SIZE 2000M  REUSE AUTOEXTEND OFF;           



 
  
	set linesize 400
	col FILE_NAME for a39
	col TABLESPACE_NAME for a15
	select file_id,FILE_NAME, STATUS, TABLESPACE_NAME, BYTES/1024/1024, MAXBYTES/1024/1024, AUTOEXTENSIBLE,file_id,(increment_by*(bytes/blocks))/1024 increment_by_kb from dba_temp_files order by TABLESPACE_NAME;
	
	



11. Recreate the control files and Rename the database	
----


alter database backup controlfile to trace as '/home/sftpm/transfer/IMXPROD_RMAN/rman_20241117/ControlFileTrace.trc';


shu immediate ;



---



cd /imxuatm/intra/dbs/SYSTEM

rm control01.ctl_back
rm control02.ctl_back
rm control03.ctl_back

mv control01.ctl control01.ctl_back
mv control02.ctl control02.ctl_back
mv control03.ctl control03.ctl_back

---rename the database 


unset ORACLE_SID
export ORACLE_SID=IMXUATM


-----


cat /home/sftpm/transfer/IMXPROD_RMAN/rman_20241117/ControlFileTrace.trc


-- hitns

The database hoyld be in NOARCHIVELOG


13. Restore the IMXDB passowrd


--- 

alter user IMXDB identified by manager;


14 . RECREATE MONITORING ALER 


conn STDBYPERF/manager

drop database link STDBY_LINK_IMXPROD_STBY2 ;



set serverout on
BEGIN
  dbms_scheduler.drop_job(job_name => 'SP_SNAPSHOT');
END;
/

exec dbms_scheduler.drop_job(job_name => 'STDBYPERF_PURGE_JOB',FORCE=>TRUE);





---- install  Alert log proc
as sysdba 

@install_alert_log_monitor_DBA.sql

as IMXDB 
Hljl2kXJmL649Zq7

@install_alert_log_monitor.sql


15 . Preservation tasks	
	
	! check for th new uat_queries_after_restore_*.sql script
	
	
	
	
nohup sqlplus `get_oracle_name.sh`/`get_oracle_password.sh`  @preservation.sql > preservationTasks.out 2>&1 &
 
 
 
nohup sqlplus imxdb/manager  @preservation.sql > LOGpreservation.out 2>&1 &




nohup sqlplus imxdb/manager  @uat_queries_after_restore_2022_04_Updated.sql > LOG_uat_queries_after_restore_2022_04_Updated.out 2>&1 &



uat_queries_after_restore_2022_04_Updated.sql
uat_queries_after_restore_2022_04_Updated.sql



SQL> update t_imprimante set code_optique='1' where imprimante='P24';

1 row updated.

SQL>  commit;

Commit complete.






16. Post refresh checks




set serverout on
EXEC DBMS_STATS.GATHER_DICTIONARY_STATS;

---



set lines 400
column OBJECT_NAME format a60
col owner for a10
SELECT OWNER,OBJECT_TYPE,OBJECT_NAME FROM DBA_OBJECTS WHERE STATUS= 'INVALID';


set lines 400
column OBJECT_NAME format a60
col owner for a10
SELECT count (*) FROM DBA_OBJECTS WHERE STATUS= 'INVALID';


 set lines 300
col COMP_NAME for a36
select comp_name,version,status from dba_registry;



----

@$ORACLE_HOME/rdbms/admin/utlrp.sql










