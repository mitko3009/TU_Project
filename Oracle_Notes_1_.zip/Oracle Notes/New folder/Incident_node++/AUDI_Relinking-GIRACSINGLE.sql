﻿#####################################################################################
crsctl disable crs


Grid 12.2 relink:

As root user:

/u01/app/12.2.0.1/grid/crs/install/rootcrs.sh -unlock

As the Oracle Grid Infrastructure for a cluster owner:  su - grid

$GRID_HOME/bin/relink

Relink the Ora homes:

DB HOME


su - oracle

ORA12C
export ORACLE_HOME=/u01/app/oracle/product/rdbms/12.1.0.2

$ORACLE_HOME/bin/relink all

export ORACLE_HOME=/u01/app/oracle/product/rdbms/12.2.0.1

$ORACLE_HOME/bin/relink all

ORA11G
export ORACLE_HOME=/u01/app/oracle/product/rdbms/11.2.0.4

$ORACLE_HOME/bin/relink all

Now finish the relinking of the ASM

As root again:

/u01/app/12.2.0.1/grid/rdbms/install/rootadd_rdbms.sh
/u01/app/12.2.0.1/grid/crs/install/rootcrs.sh -lock

crsctl enable crs
crsctl start crs


DB HOME


su - oracle

ORA12C
export ORACLE_HOME=/u01/app/oracle/product/rdbms/12.1.0.2

$ORACLE_HOME/bin/relink all

export ORACLE_HOME=/u01/app/oracle/product/rdbms/12.2.0.1

$ORACLE_HOME/bin/relink all

ORA11G
export ORACLE_HOME=/u01/app/oracle/product/rdbms/11.2.0.4

$ORACLE_HOME/bin/relink all





#######################################################################################

Grid 12.1 relink guide:


GRID HOME

as root

cd /u01/app/oracle/product/grid/12.1.0.2/crs/install
 
perl rootcrs.sh -unlock
 
su - grid
 
$GRID_HOME/bin/relink
  

as root
  
cd /u01/app/oracle/product/grid/12.1.0.2/rdbms/install/

./rootadd_rdbms.sh


as root


cd /u01/app/oracle/product/grid/12.1.0.2/crs/install

perl rootcrs.sh -patch


#############################################################


DB HOME


su - oracle

ORA12C
export ORACLE_HOME=/u01/app/oracle/product/rdbms/12.1.0.2

$ORACLE_HOME/bin/relink all

ORA11G
export ORACLE_HOME=/u01/app/oracle/product/rdbms/11.2.0.4

$ORACLE_HOME/bin/relink all




############################################################################

Connect to ivmg704

*AS ROOT*

ssh <ERM>@ivsv1515.sec-mgm.web.audi.vwg

Personal ERM password

*Once connected to ivsv1515*

nsu

ERM ROOT PASSWORD

su - oracle

*Check which is the default ORACLE_SID, but dont do . oraenv, because it will mess up your paths and won’t be able to login with sqlplus*

env | grep ORA

[oracle@ivsv1515(Production) ~]$ env | grep ORA
ORACLE_SID=REPO
ORACLE_BASE=/var/apphome/oracle
ORACLE_HOME=/var/apphome/oracle/product/11.2.0/db_1

sqlplus / as sysdba

SQL> show parameter db_name

NAME                                 TYPE        VALUE
------------------------------------ ----------- ------------------------------
db_name                              string      REPO


shutdown immediate;


*At that point notify the Unix team that the database is stopped and they may proceed with the patching*

*Once the patching is done, connect again to the server, relink and start the database and the listener*

su - oracle

env | grep ORA

[oracle@ivsv1515(Production) ~]$ env | grep ORA
ORACLE_SID=REPO
ORACLE_BASE=/var/apphome/oracle
ORACLE_HOME=/var/apphome/oracle/product/11.2.0/db_1



-RELINK COMMAND

$ORACLE_HOME/bin/relink all



sqlplus / as sysdba

startup

exit

lsnrctl start LISTENER_REPO

############################################################
In case the JEE colleague tells you the app doesn't start automatically:

/etc/init.d/oid 
/etc/init.d/oid  start 

su - oid -c "opmnctl startall" - execute it as root

> sqlplus / as sysdba
SQL> startup
Start Listener:
> lsnrctl start LISTENER_REPO                            (starts not automaticaly after host restart)
Als User oid:
su - oid
> opmnctl startall              maybe do before:    opmnctl stopall
 opmnctl startall: starting opmn and all managed processes...
Check status
> opmnctl status
Erwartete Ausgabe:
[oid@ivsv1515(Production) ~]$ opmnctl status
Processes in Instance: asinst_1
---------------------------------+--------------------+---------+---------
ias-component                    | process-type       |     pid | status
---------------------------------+--------------------+---------+---------
ovd1                             | OVD                |   34736 | Alive
oid1                             | oidldapd           |   38662 | Alive
oid1                             | oidldapd           |   38656 | Alive
oid1                             | oidmon             |   38647 | Alive
EMAGENT                          | EMAGENT            |   34735 | Alive
