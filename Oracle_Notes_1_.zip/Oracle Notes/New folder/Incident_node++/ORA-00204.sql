=============================================================================================
FMAXPRD2:ERRORLOG:ORA-00204 - error in reading (block 40,#block1) of control file  -  Za FORTUM e mnogo vajno 

#### Outputa ot alert loga ######

Errors in file /u01/app/oracle/diag/rdbms/fmaxprd/FMAXPRD2/trace/FMAXPRD2_ora_26103.trc:
ORA-15025: levyn /dev/oracle_asm/ASM_DISK_DATA_023 avaus ei onnistunut
ORA-27041: tiedostoa ei voi avata
Linux-x86_64 Error: 13: Permission denied
Additional information: 3
WARNING: Read Failed. group:1 disk:22 AU:31299 offset:352256 size:8192
path:Unknown disk
         incarnation:0x0 synchronous result:'I/O error'
         subsys:Unknown library krq:0x7f62b150ff58 bufp:0x10e3e94000 osderr1:0x0 osderr2:0x0
         IO elapsed time: 0 usec Time waited on I/O: 0 usec
WARNING: failed to read mirror side 1 of virtual extent 20888 logical extent 0 of file 311 in group [1.352866531] from disk DATA_0023  allocation unit 31299 reason error; if possible, will try another mirror side
Mon Jun 10 16:33:50 2019
Errors in file /u01/app/oracle/diag/rdbms/fmaxprd/FMAXPRD2/trace/FMAXPRD2_ora_26103.trc:
ORA-15025: levyn /dev/oracle_asm/ASM_DISK_DATA_023 avaus ei onnistunut
ORA-27041: tiedostoa ei voi avata
Linux-x86_64 Error: 13: Permission denied
Additional information: 3
WARNING: Read Failed. group:1 disk:22 AU:31299 offset:352256 size:8192
path:Unknown disk
         incarnation:0x0 synchronous result:'I/O error'
         subsys:Unknown library krq:0x7f62b150ff58 bufp:0xdb1cec000 osderr1:0x0 osderr2:0x0
         IO elapsed time: 0 usec Time waited on I/O: 0 usec
WARNING: failed to read mirror side 1 of virtual extent 20888 logical extent 0 of file 311 in group [1.352866531] from dis

1. #####  AS ROOT USER: Изпълнявам следната команда
udevadm trigger

AS ROOT FOR FORTUM (+ASM disk groups dissconnected) (CONNECT WITH TEODORA PESHEVA UNIX)

udevadm trigger


- суитчваме логове
-може рестарт на лисънъра
srvctl status listener
srvctl stop/start listener

пиша мейл !!!!
