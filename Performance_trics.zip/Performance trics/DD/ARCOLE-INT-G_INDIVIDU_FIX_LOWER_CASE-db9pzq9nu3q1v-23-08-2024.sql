/********************************************************************************
*********       E-mail subject: ARCOLE-6637
*********             Instance: INT
*********          Description: 
Problem:
The fix_lower_case_g_individu.sql was running too long on INT instance.

Analysis:
After the analyze, we found that the TOP SQL for this module was db9pzq9nu3q1v. This is the select statement that selects on every iteration of the loop ( in which loop table g_individu 
is updated using SQL cvuq7jfd2f43n ) how many rows more need to be updated. As it was decribed in comment ( https://tts.codix.eu/jira/browse/ARCOLE-6637?focusedCommentId=16947659&page=com.atlassian.jira.plugin.system.issuetabpanels:comment-tabpanel#comment-16947659 ) 
this select can be removed and instead of it to be used SQL%ROWCOUNT to check is there more rows that need to be updated.

Suggestion:
Please check is it possible to remove the loop and directly update all rows and if it is not, please remove the select statement db9pzq9nu3q1v and use the SQL%ROWCOUNT.
Also, if you use loop, please update more rows on iteration ( now it is 50000 rows, please change it to lets say 500000 rows ).

*********               SQL_ID: db9pzq9nu3q1v
*********      Program/Package: 
*********              Request: Borislav Iliev
*********               Author: Dimitar Dimitrov
********* Received e-mail date: 22/08/2024
*********      Resolution date: 22/08/2024
*********  Trace old file here: \\epox\specifs\performance\tmp\
*********  Trace new file here:
***********************************************************************************/

/********************************OLD SQL*******************************************/

-- db9pzq9nu3q1v

SELECT COUNT(*)
  FROM G_INDIVIDU
 WHERE (ADR1 != IMX_UPPER(ADR1) OR ADR2 != IMX_UPPER(ADR2) OR
       ADR3 != IMX_UPPER(ADR3) OR ADR4 != IMX_UPPER(ADR4) OR
       CEDEX != IMX_UPPER(CEDEX) OR CODBANQUE != IMX_UPPER(CODBANQUE) OR
       CODEBIC != IMX_UPPER(CODEBIC) OR
       CODGUICHET != IMX_UPPER(CODGUICHET) OR CP != IMX_UPPER(CP) OR
       EMAIL != IMX_UPPER(EMAIL) OR GINDCPTNUM != IMX_UPPER(GINDCPTNUM) OR
       NOM != IMX_UPPER(NOM) OR NOMCOMPL != IMX_UPPER(NOMCOMPL) OR
       NOMCONTACT != IMX_UPPER(NOMCONTACT) OR
       NOMDIVORC != IMX_UPPER(NOMDIVORC) OR NOMJF != IMX_UPPER(NOMJF) OR
       NO_FRGN_ID != IMX_UPPER(NO_FRGN_ID) OR
       NUMIDENT != IMX_UPPER(NUMIDENT) OR NUMSS != IMX_UPPER(NUMSS) OR
       PHON_ENSEIGNE != IMX_UPPER(PHON_ENSEIGNE) OR
       PHON_RAISSOC != IMX_UPPER(PHON_RAISSOC) OR
       PRENOM != IMX_UPPER(PRENOM) OR PROFESSION != IMX_UPPER(PROFESSION) OR
       RAISSOC1 != IMX_UPPER(RAISSOC1) OR RAISSOC2 != IMX_UPPER(RAISSOC2) OR
       REGCOMM != IMX_UPPER(REGCOMM) OR SIRET != IMX_UPPER(SIRET) OR
       SITFAMILLE != IMX_UPPER(SITFAMILLE) OR STR22 != IMX_UPPER(STR22) OR
       TEL1 != IMX_UPPER(TEL1) OR TEL2 != IMX_UPPER(TEL2) OR
       TEL3 != IMX_UPPER(TEL3) OR TELECOP != IMX_UPPER(TELECOP) OR
       TVA != IMX_UPPER(TVA) OR VILLE != IMX_UPPER(VILLE) OR
       VILLE_CEDEX != IMX_UPPER(VILLE_CEDEX));


-- cvuq7jfd2f43n

UPDATE G_INDIVIDU
   SET ADR1          = IMX_UPPER(ADR1),
       ADR2          = IMX_UPPER(ADR2),
       ADR3          = IMX_UPPER(ADR3),
       ADR4          = IMX_UPPER(ADR4),
       CEDEX         = IMX_UPPER(CEDEX),
       CODBANQUE     = IMX_UPPER(CODBANQUE),
       CODEBIC       = IMX_UPPER(CODEBIC),
       CODGUICHET    = IMX_UPPER(CODGUICHET),
       CP            = IMX_UPPER(CP),
       EMAIL         = IMX_UPPER(EMAIL),
       GINDCPTNUM    = IMX_UPPER(GINDCPTNUM),
       NOM           = IMX_UPPER(NOM),
       NOMCOMPL      = IMX_UPPER(NOMCOMPL),
       NOMCONTACT    = IMX_UPPER(NOMCONTACT),
       NOMDIVORC     = IMX_UPPER(NOMDIVORC),
       NOMJF         = IMX_UPPER(NOMJF),
       NO_FRGN_ID    = IMX_UPPER(NO_FRGN_ID),
       NUMIDENT      = IMX_UPPER(NUMIDENT),
       NUMSS         = IMX_UPPER(NUMSS),
       PHON_ENSEIGNE = IMX_UPPER(PHON_ENSEIGNE),
       PHON_RAISSOC  = IMX_UPPER(PHON_RAISSOC),
       PRENOM        = IMX_UPPER(PRENOM),
       PROFESSION    = IMX_UPPER(PROFESSION),
       RAISSOC1      = IMX_UPPER(RAISSOC1),
       RAISSOC2      = IMX_UPPER(RAISSOC2),
       REGCOMM       = IMX_UPPER(REGCOMM),
       SIRET         = IMX_UPPER(SIRET),
       SITFAMILLE    = IMX_UPPER(SITFAMILLE),
       STR22         = IMX_UPPER(STR22),
       TEL1          = IMX_UPPER(TEL1),
       TEL2          = IMX_UPPER(TEL2),
       TEL3          = IMX_UPPER(TEL3),
       TELECOP       = IMX_UPPER(TELECOP),
       TVA           = IMX_UPPER(TVA),
       VILLE         = IMX_UPPER(VILLE),
       VILLE_CEDEX   = IMX_UPPER(VILLE_CEDEX)
 WHERE (ADR1 != IMX_UPPER(ADR1) OR ADR2 != IMX_UPPER(ADR2) OR
       ADR3 != IMX_UPPER(ADR3) OR ADR4 != IMX_UPPER(ADR4) OR
       CEDEX != IMX_UPPER(CEDEX) OR CODBANQUE != IMX_UPPER(CODBANQUE) OR
       CODEBIC != IMX_UPPER(CODEBIC) OR
       CODGUICHET != IMX_UPPER(CODGUICHET) OR CP != IMX_UPPER(CP) OR
       EMAIL != IMX_UPPER(EMAIL) OR GINDCPTNUM != IMX_UPPER(GINDCPTNUM) OR
       NOM != IMX_UPPER(NOM) OR NOMCOMPL != IMX_UPPER(NOMCOMPL) OR
       NOMCONTACT != IMX_UPPER(NOMCONTACT) OR
       NOMDIVORC != IMX_UPPER(NOMDIVORC) OR NOMJF != IMX_UPPER(NOMJF) OR
       NO_FRGN_ID != IMX_UPPER(NO_FRGN_ID) OR
       NUMIDENT != IMX_UPPER(NUMIDENT) OR NUMSS != IMX_UPPER(NUMSS) OR
       PHON_ENSEIGNE != IMX_UPPER(PHON_ENSEIGNE) OR
       PHON_RAISSOC != IMX_UPPER(PHON_RAISSOC) OR
       PRENOM != IMX_UPPER(PRENOM) OR PROFESSION != IMX_UPPER(PROFESSION) OR
       RAISSOC1 != IMX_UPPER(RAISSOC1) OR RAISSOC2 != IMX_UPPER(RAISSOC2) OR
       REGCOMM != IMX_UPPER(REGCOMM) OR SIRET != IMX_UPPER(SIRET) OR
       SITFAMILLE != IMX_UPPER(SITFAMILLE) OR STR22 != IMX_UPPER(STR22) OR
       TEL1 != IMX_UPPER(TEL1) OR TEL2 != IMX_UPPER(TEL2) OR
       TEL3 != IMX_UPPER(TEL3) OR TELECOP != IMX_UPPER(TELECOP) OR
       TVA != IMX_UPPER(TVA) OR VILLE != IMX_UPPER(VILLE) OR
       VILLE_CEDEX != IMX_UPPER(VILLE_CEDEX))
   AND ROWNUM < 50000;

/********************************OLD SQL*******************************************/
/********************************OLD Metrics***************************************/
/*

MODULE                           PROGRAM                                            CLIENT_ID       SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM     TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- -------------------------------------------------- --------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
G_INDIVIDU_FIX_LOWER_CASE        sqlplus                                                                                            402      15377 ON CPU               2024/08/22 08:49:11  2024/08/22 14:21:05       19798                  3727572 +000000000 05:31:54.687 90%
                                                                                                                                                   ON CPU               2024/08/22 08:49:27  2024/08/22 14:20:40    1475               134695 +000000000 05:31:13.650 7%
MMON_SLAVE                                                                                                                                         ON CPU               2024/08/22 08:49:16  2024/08/22 14:20:22     308                29437 +000000000 05:31:06.645 1%
                                                                                                                           0                       oracle thread bootst 2024/08/22 08:49:34  2024/08/22 14:19:24     156                      +000000000 05:29:50.579 1%
G_INDIVIDU_FIX_LOWER_CASE        sqlplus                                                                                            402      15377 db file sequential r 2024/08/22 09:05:54  2024/08/22 14:16:56      80              3729616 +000000000 05:11:02.449 0%
PT_SNAP_SESSION                  sqlplus                                                                                                           ON CPU               2024/08/22 09:00:04  2024/08/22 14:14:10      67                 2106 +000000000 05:14:05.743 0%
                                 oracle                                                                                    0          1      31548 os thread creation   2024/08/22 08:51:02  2024/08/22 14:14:22      53                      +000000000 05:23:20.250 0%
                                 oracle                                                                                    0        767      51257 db file parallel wri 2024/08/22 09:39:11  2024/08/22 14:20:01      34                      +000000000 04:40:49.772 0%
                                 oracle                                                                                    0       1149      21695 log file parallel wr 2024/08/22 09:45:46  2024/08/22 14:16:29      15                      +000000000 04:30:43.230 0%
                                 oracle                                                                                    0          2      52390 latch free           2024/08/22 09:08:24  2024/08/22 13:22:39      13                      +000000000 04:14:15.352 0%
G_INDIVIDU_FIX_LOWER_CASE        sqlplus                                                            db9pzq9nu3q1v 2309871334        402      15377 enq: KO - fast objec 2024/08/22 09:07:55  2024/08/22 14:17:16      11                   22 +000000000 05:09:21.367 0%
KTSJ                                                                                                9x2prazfz86dz                                  ON CPU               2024/08/22 09:46:40  2024/08/22 13:29:59      11                   22 +000000000 03:43:18.633 0%
                                 oracle                                                                                    0          5      14038 control file paralle 2024/08/22 09:59:04  2024/08/22 14:18:03       9                      +000000000 04:18:59.595 0%
PT_SNAP_SESSION                  sqlplus                                                                                            415      57854 PGA memory operation 2024/08/22 09:05:55  2024/08/22 12:00:27       6                 1304 +000000000 02:54:32.787 0%



MODULE                           PROGRAM                                            CLIENT_ID       SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM     TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- -------------------------------------------------- --------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
G_INDIVIDU_FIX_LOWER_CASE        sqlplus                                                                                            402      15377 ON CPU               2024/08/22 08:50:10  2024/08/22 14:22:01       19795                  3727572 +000000000 05:31:51.683 90%
                                                                                                                                                   ON CPU               2024/08/22 08:50:29  2024/08/22 14:21:42    1476               134695 +000000000 05:31:13.650 7%
MMON_SLAVE                                                                                                                                         ON CPU               2024/08/22 08:50:56  2024/08/22 14:20:22     307                29437 +000000000 05:29:26.554 1%
                                                                                                                           0                       oracle thread bootst 2024/08/22 08:51:02  2024/08/22 14:21:25     156                      +000000000 05:30:23.604 1%
                                                                                                                           

MODULE                           PROGRAM                                            CLIENT_ID       SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- -------------------------------------------------- --------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
G_INDIVIDU_FIX_LOWER_CASE        sqlplus                                                            db9pzq9nu3q1v 2309871334        402      15377                      2024/08/22 08:50:30  2024/08/22 14:22:22       15024                   24 +000000000 05:31:52.684 68%
G_INDIVIDU_FIX_LOWER_CASE        sqlplus                                                            cvuq7jfd2f43n 3265366298        402      15377                      2024/08/22 08:51:39  2024/08/22 14:17:15        3487                   23 +000000000 05:25:36.355 16%
                                                                                                                           0                                            2024/08/22 08:50:44  2024/08/22 14:22:04        1748                      +000000000 05:31:20.655 8%
G_INDIVIDU_FIX_LOWER_CASE        sqlplus                                                            4r7tsr9ggdb0f 2460740891        402      15377 ON CPU               2024/08/22 08:51:52  2024/08/22 14:17:14         663              1148292 +000000000 05:25:22.343 3%
G_INDIVIDU_FIX_LOWER_CASE        sqlplus                                                            433npv30fk704                   402      15377                      2024/08/22 08:51:57  2024/08/22 14:17:11         455              3420034 +000000000 05:25:14.337 2%
G_INDIVIDU_FIX_LOWER_CASE        sqlplus                                                            9fyzycp9a53r3                   402      15377 ON CPU               2024/08/22 08:52:11  2024/08/22 14:17:02         187              1137107 +000000000 05:24:51.320 1%
MMON_SLAVE                                                                                                                 0                       ON CPU               2024/08/22 08:51:47  2024/08/22 14:20:22         165                      +000000000 05:28:35.508 1%


INSTANCE_NUMBER SQL_ID            ELAPSED MAX_WAIT_ON     PC_OF  WAIT_TIME            GETS      READS       ROWS  ELAP/EXEC       GETS/EXEC READS/EXEC  ROWS/EXEC       EXEC PLAN_HASH_VALUE
--------------- ------------- ----------- --------------- ----- ---------- --------------- ---------- ---------- ---------- --------------- ---------- ---------- ---------- ---------------
              1 cvuq7jfd2f43n        4824 CPU             71%   6669.17219        63924496    2112709    1149977     209.73         2779326   91856.91      49999         23  3265366298
              1 db9pzq9nu3q1v       15330 CPU             58%   26209.5035       231123883   19471304         23     666.51        10048864  846578.43          1         23  2309871334


ARCOLE-INT-G_INDIVIDU_FIX_LOWER_CASE-db9pzq9nu3q1v-23-08-2024



INSTANCE_NUMBER    SNAP_ID BEGIN_INTERVAL_TIME            END_INTERVAL_TIME              EVENT                          TOTAL_WAITS TIME_WAITED AVG_DISK_RESP_TIME_MS READ_DELTA_VALUE WRITE_DELTA_VALUE
--------------- ---------- ------------------------------ ------------------------------ ------------------------------ ----------- ----------- --------------------- ---------------- -----------------              1      45254 2024/08/14 11:04:31            2024/08/14 11:14:38            db file sequential read                                                                1                  1
              1      45440 2024/08/22 04:00:23            2024/08/22 05:00:48            db file sequential read                355       46323                    .1           1                  1
              1      45441 2024/08/22 05:00:48            2024/08/22 06:00:15            db file sequential read                395       77765                    .2           1                  1
              1      45442 2024/08/22 06:00:15            2024/08/22 07:00:42            db file sequential read                356       56368                    .2           1                  1
              1      45443 2024/08/22 07:00:42            2024/08/22 08:00:10            db file sequential read                360       60944                    .2           1                  1
              1      45444 2024/08/22 08:00:10            2024/08/22 09:00:39            db file sequential read              53272    17702472                    .3          18                  2
              1      45445 2024/08/22 09:00:39            2024/08/22 10:00:10            db file sequential read              77868    23179087                    .3          30                  2
              1      45446 2024/08/22 10:00:10            2024/08/22 11:00:42            db file sequential read              45391    14940427                    .3          30                  2
              1      45447 2024/08/22 11:00:42            2024/08/22 12:00:12            db file sequential read              59808    15748679                    .3          30                  2
              1      45448 2024/08/22 12:00:12            2024/08/22 13:00:44            db file sequential read              49077    10983216                    .2          31                  2
              1      45449 2024/08/22 13:00:44            2024/08/22 14:00:14            db file sequential read              49194    13202150                    .3          31                  2


-- db9pzq9nu3q1v

Plan hash value: 2309871334
---------------------------------------------------------------------------------
| Id  | Operation          | Name       | Rows  | Bytes | Cost (%CPU)| Time     |
---------------------------------------------------------------------------------
|   0 | SELECT STATEMENT   |            |       |       |   157K(100)|          |
|   1 |  SORT AGGREGATE    |            |     1 |   439 |            |          |
|   2 |   TABLE ACCESS FULL| G_INDIVIDU |  9198K|  3851M|   157K  (7)| 00:00:07 |
---------------------------------------------------------------------------------



-- cvuq7jfd2f43n

Plan hash value: 3265366298
----------------------------------------------------------------------------------
| Id  | Operation           | Name       | Rows  | Bytes | Cost (%CPU)| Time     |
----------------------------------------------------------------------------------
|   0 | UPDATE STATEMENT    |            |       |       |   161K(100)|          |
|   1 |  UPDATE             | G_INDIVIDU |       |       |            |          |
|   2 |   COUNT STOPKEY     |            |       |       |            |          |
|   3 |    TABLE ACCESS FULL| G_INDIVIDU |  9198K|  3851M|   161K  (9)| 00:00:07 |
----------------------------------------------------------------------------------    

*/
/********************************OLD Metrics***************************************/

/********************************New SQL*******************************************/

;
/********************************New SQL*******************************************/
/********************************New Metrics***************************************/
/*

*/
/********************************New Metrics***************************************/

/********************************Index statistics**********************************/

/********************************Other SQLs****************************************/          
/*

*/ 
/********************************Other SQLs****************************************/              
