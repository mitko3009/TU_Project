/********************************************************************************
*********       E-mail subject: IMBWEB-7872
*********             Instance: UATHFAD
*********          Description: 
Problem:
This SQL was provided as slow on UATHFAD.

Analysis:
The problem in this query was the use of inappropriate hints, based on which the CBO choose bad execution plan.
We changed the hints as it is shown in the New SQL section below and forced oracle to make full scans on table NAM_ECR_COMPTA_BAK, 
which is the fastest way to access the data from this table at this case.

Suggestion:
Please change the hints as it is shown in the New SQLs section below.

*********               SQL_ID: 
*********      Program/Package: 
*********              Request: Thuy Le Mong 
*********               Author: Dimitar Dimitrov
********* Received e-mail date: 05/06/2024
*********      Resolution date: 06/06/2024
*********  Trace old file here: \\epox\specifs\performance\tmp\
*********  Trace new file here:
***********************************************************************************/

/********************************OLD SQL*******************************************/

SELECT /*+no_merge no_push_pred LEADING(ctr_case ctr lov_cnt dbcl db gi cl cl_acc) FULL(ctr_case) INDEX(ctr G_PIECE_TYPE_REFDOSS_IDX) USE_NL(ctr) FULL(lov_cnt) USE_HASH(lov_cnt) FULL(dbcl) USE_HASH(dbcl) FULL(db) 
       USE_HASH(db) FULL(gi) USE_HASH(gi) FULL(cl) USE_HASH(cl) FULL(cl_acc) USE_HASH(cl_acc) USE_HASH(port_dbcl) USE_HASH(redec_amt) USE_HASH(redebtor_amt) USE_HASH(max_overdue) USE_HASH(police) 
       USE_HASH(ins_quality) USE_HASH(ebv) FULL(recei) USE_HASH(recei) USE_HASH(t1) USE_HASH(ext) USE_HASH(gfl) USE_HASH(neu_gru) USE_HASH(compte_rate) USE_HASH(cnt_rate) USE_HASH(udf_indiv) 
       USE_HASH(compta_bak) USE_HASH(cl_hist) FULL(v) USE_HASH(v) USE_HASH(rate_dbcl) USE_HASH(rate_contr)*/
       DISTINCT 
       t1.NOneNB                                as "OeNB ID Nr.",
       grpnew.GOneNB                            as "OeNB-Gr.ID.Nr",
       grpnew.GOneNBN                           as "Name Gruppe",
       db.DEBTOR_REFINDIVIDU                    as "Poolnummer",
       RTRIM(LTRIM(db.DEBTOR_PRENOM || ' ' || db.DEBTOR_NOM)) as "Individual Name",
       db.DEBTOR_PAYS                           as "Land",
       db.DEBTOR_CP                             as "PLZ",
       db.DEBTOR_VILLE                          as "Ort",
       --IMBWEB-6448
       ksv_ebs_rate.KSV_RATE                    as "KSV-Rating",
       ksv_ebs_rate.EBS_RATE                    as "KSV Rating – EB Rating",
       db.STR15                                 as "Nace Code 1- KSV",
       gi.STR44                                 as "EB Nace Code",
       gi.DRI_INDUSTRY_CODE                     as "Nace Code 2",
       --IMBDEV-10690
       COALESCE(CASE WHEN NVL(gi.DRI_INDUSTRY_CODE,'_UNBEK') != '_UNBEK' THEN gi.DRI_INDUSTRY_CODE ELSE NULL END,
                CASE WHEN NVL(gi.STR44,'_UNBEK') NOT IN ('_UNBEKANNT','_UNBEK') THEN gi.STR44 ELSE NULL END,db.STR15) as "Final Nace",
       SUBSTR(COALESCE(CASE WHEN NVL(gi.DRI_INDUSTRY_CODE,'_UNBEK') != '_UNBEK' THEN gi.DRI_INDUSTRY_CODE ELSE NULL END,
                CASE WHEN NVL(gi.STR44,'_UNBEK') NOT IN ('_UNBEKANNT','_UNBEK') THEN gi.STR44 ELSE NULL END,db.STR15), 1, 1) as "Industry Nace Code",
       (CASE WHEN v.TYPE = 'T.NAF' THEN v.VALEUR
             WHEN v.TYPE IN ('DRI_INDUSTRY', 'DRI_NACE_CODE') THEN v.ABREV1
         END)                                    as "Industry Segment",
       ext."EB Rating"                           as "EB Rating",
       ext."EBS Rating Datum"                    as "EBS Rating Datum",
       cl.CLIENT_REFINDIVIDU                         as "Client ID",
       RTRIM(LTRIM(cl.CLIENT_PRENOM || ' ' || cl.CLIENT_NOM))      as "Client Name",
       dbcl.ANCREFDOSS                               as "Vkf.Nr",
       --
       cl_acc.REFDOSSEXT                            as "Contract NR-SAP-FI",       
       cl_acc.REFDOSS                                as "Subcontract Reference",
       cl_acc.DEVISE                                 as "Subcontract Currency",
       NVL(port_dbcl.PORTFOLIO_DBCL,0)               as "Saldo",
       NVL(compte_rate.MT01,cnt_rate.MT01)           as "Vkf.BV",
       ext."Client Financial Rating"                 as "Client Financial Rating",
       recei.DEFAULT_EVENT                           as "Ereignis Code",
       NVL(lov_cnt.VALEUR_AN,ctr.GPIOBJET)                 as "Qualitat",
       ins_quality.LIB3                                    as "Insurance Quality",
       (CASE WHEN police.POLICE_HODER = dbcl.FACTOR 
              AND police.REF_INSURER = dbcl.FACTOR THEN 'J'  
        ELSE 'N' END)                                      as "Haftung IMB",                                  
       NULL                                                as "Syndication",
       gfl.MT03                                            as "Erste group guarantee",
       NULL                                                as "Foreign Bank (guarantee)",
       100 - NVL(rate_dbcl.MT01,rate_contr.MT01)           as "SB",
       redebtor_amt.REDEBTOR_AMT                           as "Debtor Limit",
       (CH_TAUX.Conv_Orig_Dest_Tx(ad_jullian_date(Sysdate),    --IMBWEB-6367- change from :Date to sysdate
                                   port_dbcl.PORTFOLIO_DBCL,
                                   port_dbcl.FI_DEVISE_DOS, 
                                   AD_GET_SYS_CCY, 
                                   'MR',
                                   ''))                      as "Portfolio in EUR",
       (CH_TAUX.Conv_Orig_Dest_Tx(ad_jullian_date(Sysdate),
                                 NVL(cl_hist.Retention_NBV, 0),
                                 cl_hist.currency, 
                                 AD_GET_SYS_CCY, 
                                 'MR',
                                 ''))                      as "Retention NBV in EUR",
      police.NOM_INSURER                                   as "Versicherer",
      --IMBDEV-10690
      '1'                                                  as "Riskexposure Level",
      compta_bak.RISK_EUR_NOEX                             as "Riskexposure",
      compta_bak.RISK_EUR                                  as "Riskexposure in EUR",
      NVL(ex_rate.TAUX,1.0)                                as "Wechselkurs",
      ex_rate.CRDATE4I_DT                                  as "Wechselkurs Datum",      
      udf_indiv.VALUE                                      as "FINREP",
      compta_bak.GL_AMT                                    as "GL Account",
      t1.KUKURZ                                            as "KuKurz",
      gi.IFRS_9_STAGE                                      as "Stage",
      neu_gru.NEU_SUB_gruppen                              as "NEU / SUB_gruppen, wenn vorhanden",
      RTRIM(LTRIM((CASE WHEN grpnew.GOneNBN IS NOT NULL THEN grpnew.GOneNBN
                   ELSE db.DEBTOR_PRENOM || ' ' || db.DEBTOR_NOM END)))                                        as "Gruppe / Name für Pivot",
      --IMBDEV-10690
      (CASE WHEN grpnew.GOneNB IS NOT NULL THEN grpnew.Gruppe_DRI_Rating ELSE NULL END) as "Gruppe DRI-Rating",
      --
      (CASE 
         WHEN grpnew.GOneNB IS NOT NULL AND grpnew.Gruppe_KSV_Rating > 0 THEN grpnew.Gruppe_KSV_Rating 
         WHEN grpnew.GOneNB IS NOT NULL AND NVL(grpnew.Gruppe_KSV_Rating,0) = 0 AND grpnew.GKVS_HRISK > 0 THEN grpnew.GKVS_HRISK 
         WHEN grpnew.GOneNB IS NOT NULL AND NVL(grpnew.GKVS_HRISK,0) = 0 THEN ksv_ebs_rate.KSV_RATE
       END    
      ) as "Gruppe KSV-Rating",
      -- 
      (CASE 
         WHEN grpnew.GOneNB IS NOT NULL AND grpnew.Gruppe_KSV_Rating > 0 THEN 'Group' 
         WHEN grpnew.GOneNB IS NOT NULL AND NVL(grpnew.Gruppe_KSV_Rating,0) = 0 AND grpnew.GKVS_HRISK > 0 THEN 'Riskexposure' 
         WHEN grpnew.GOneNB IS NOT NULL AND NVL(grpnew.GKVS_HRISK,0) = 0 THEN 'Debtor'
       END    
      ) as "Gruppe KSV-Rating Level", 
      --   
      (CASE WHEN grpnew.GOneNB IS NOT NULL THEN grpnew.Gruppe_RICOS ELSE NULL END) as "Gruppe RICOS",
      --  
      compta_bak.CR_LOSS  as "Expected Loss Betrag in EUR",
      --
      (-1)*compta_bak.RISK_EUR*NVL(pd_lgd.pd,AD_PD_LGD_DEFAULT.AD_GET_PD_DEFAULT)*AD_PD_LGD_DEFAULT.AD_GET_LGD_BU    as "Kalkulierter Expected Loss Betrag in EUR",
      --
      DECODE(c_limit.c_flag, 1, dbcl.CREDIT_LIMIT, null)  as "Versicherungssumme",
      (CH_TAUX.Conv_Orig_Dest_Tx(ad_jullian_date(Sysdate),
                                 decode(c_limit.c_flag, 1, dbcl.CREDIT_LIMIT, null),
                                 dbcl.DEVISE, 
                                 AD_GET_SYS_CCY, 
                                 'MR',
                                 ''))                      as "Versicherungssumme in EUR",
      (CH_TAUX.Conv_Orig_Dest_Tx(ad_jullian_date(Sysdate),
                                 redec_amt.REDEC_AMT,
                                 redec_amt.GPIDEVIS, 
                                 AD_GET_SYS_CCY, 
                                 'MR',
                                 ''))                      as "Abbausaldo in EUR",
      max_overdue.MAX_OVERDUE                              as "Max. Überfällig in Tagen",
      (CH_TAUX.Conv_Orig_Dest_Tx(ad_jullian_date(Sysdate),
                                 max_overdue.SUM_OVER,
                                 max_overdue.FI_DEVISE_DOS, 
                                 AD_GET_SYS_CCY, 
                                 'MR',
                                 ''))                      as "Summe Überfällig in EUR",
      (CH_TAUX.Conv_Orig_Dest_Tx(ad_jullian_date(Sysdate),
                                 max_overdue.SUM_OVER_RISK,
                                 max_overdue.FI_DEVISE_DOS, 
                                 AD_GET_SYS_CCY, 
                                 'MR',
                                 ''))                      as "Summe Überfällig Riskexposure in EUR",
      NULL as "NPL-Unlikely to pay, not past-due or <= 90 days",
      NULL as "NPL-Past due greater than 90 days up to 180 days",
      NULL as "NPL-Past due greater than 180 days up to 1 year",
      NULL as "NPL-Past due greater than 1 year up to 5 years",
      NULL as "NPL-Past due greater than 5 years",
      (CASE  WHEN max_overdue.MAX_OVERDUE <= 0 THEN '0 - 0' 
             WHEN max_overdue.MAX_OVERDUE <= 30 THEN '1 - up to 30 days'
             WHEN max_overdue.MAX_OVERDUE BETWEEN 31 AND 60 THEN '2 - 31 to 60 days' 
             WHEN max_overdue.MAX_OVERDUE BETWEEN 61 AND 90 THEN '3 - 61 to 90 days'
             WHEN max_overdue.MAX_OVERDUE BETWEEN 91 AND 180 THEN '4 - 91 to 180 days'
             WHEN max_overdue.MAX_OVERDUE BETWEEN 181 AND 360 THEN '5 - 181  days to 1 year'
             WHEN max_overdue.MAX_OVERDUE BETWEEN 361 AND 720 THEN '6 - 1 year to 2 years'
             WHEN max_overdue.MAX_OVERDUE BETWEEN 721 AND 1800 THEN '7 - 2 years to 5 years'
             WHEN max_overdue.MAX_OVERDUE > 1801 THEN '8 - greater than 7 years' 
       END) as "PL/NPL-Type",
       CASE WHEN ebv.total_ebv > 0 THEN ebv.total_ebv ELSE NULL END  AS "Total EBV >0"
  FROM AD_ACCOUNT_DEBTOR_CLIENT dbcl,
       AD_DEBTORS               db,
       AD_CLIENTS               cl,
       AD_CASE_CONTRAT          ctr_case,
       G_PIECE                  ctr,
       AD_ACCOUNT_CLIENT_MVIEW  cl_acc,
       (SELECT /*+no_merge no_push_pred*/debtor, contract_number, client,c_flag
          FROM (SELECT /*+index( a AD_LIMIT_DEBTOR_IND)*/
                 a.debtor,
                 a.client,
                 a.contract_number,
                 1 c_flag,
                 row_number() over(PARTITION BY debtor, contract_number ORDER BY imx_un_id DESC) rn
                  FROM ad_limits a
                 WHERE a.limit_type = 'C'
                   AND a.refext = 'COM')
         WHERE rn = 1
       )c_limit,
       --IMBDEV-10690 - to modify sub query ti
      (SELECT /*+ no_merge no_push_pred */
               REFINDIVIDU,MAX(NOneNB) NOneNB,MAX(KUKURZ) KUKURZ
         FROM (SELECT /*+FULL(ti)*/  
                       ti.REFINDIVIDU,
                       (CASE WHEN ti.SOCIETE = 'National bank code ID OeNB' THEN ti.REFEXT ELSE NULL END) as NOneNB, 
                       (CASE WHEN ti.SOCIETE = 'KUKURZ' THEN ti.REFEXT ELSE NULL END) as KUKURZ,
                       ROW_NUMBER() OVER (PARTITION BY ti.REFINDIVIDU,ti.SOCIETE  ORDER BY ti.IMX_UN_ID DESC) rnk
                  FROM T_INDIVIDU ti
                 WHERE ti.SOCIETE IN ('National bank code ID OeNB','KUKURZ') 
               )a                     
        WHERE a.rnk =1
        GROUP BY REFINDIVIDU
       )t1,
       --IMBDEV-10690
      (SELECT /*+no_merge no_push_pred LEADING(gnumber)*/
             gnumber.DEBTOR,
             gnumber.GNUMBER   AS GOneNB,
             gnumber.GNOM      AS GOneNBN,
             gidet.GDRI_RATE   AS Gruppe_DRI_Rating, 
             gidet.GKSV_RATE   AS Gruppe_KSV_Rating,
             gricos.LMIT_RICOS AS Gruppe_RICOS,
             grisk.GKVS_HRISK  AS GKVS_HRISK
       FROM (SELECT /*+LEADING(gprdet grp gext) INDEX(gprdet G_GROUPINDIVDET_RFTRPE_IDX)*/
                     gprdet.REF1 AS DEBTOR,
                     grp.REFGROUPE,
                     CASE WHEN grp.DTDEACT_DT IS NULL THEN gext.REFEXT ELSE NULL END AS GNUMBER,
                     CASE WHEN grp.DTDEACT_DT IS NULL THEN grp.NOM ELSE NULL END AS GNOM
                FROM G_GROUPINDIVDET gprdet,
                     G_GROUPINDIV grp,
                     G_GROUP_REFEXT gext
               WHERE 1=1
                 AND gprdet.TYPE ='LIST'
                 AND gprdet.REFGROUPE = grp.REFGROUPE
                 AND grp.TYPE ='DEBITEURS'
                 AND gext.REFGROUPE = grp.REFGROUPE
                 AND gext.REFEXT_TYPE = 'OeNB group number' 
                 AND grp.DTDEACT_DT IS NULL
               )gnumber,
              (SELECT /*+ no_merge no_push_pred*/
                      lea.REFINDIVIDU AS LEADER,
                      lea.REFGROUPE,
                      gprdet.REF1 AS DEBROR,
                      MAX(DRI_RATE) AS GDRI_RATE,
                      MAX(KSV_RATE) AS GKSV_RATE
                 FROM(SELECT gi.REFINDIVIDU,grl.REFGROUPE,
                             CASE WHEN gi.STR1 ='DRI' THEN gi.STR2 ELSE NULL END as DRI_RATE, 
                             CASE WHEN gi.STR1 ='KSV' AND TRUNC(sysdate) BETWEEN gi.dt09_dt AND NVL(gi.dt07_dt, SYSDATE) 
                                  THEN gi.STR2 ELSE NULL END as KSV_RATE,
                             ROW_NUMBER() OVER (PARTITION BY gi.REFINDIVIDU,gi.STR1  ORDER BY gi.IMX_UN_ID DESC) rnk
                        FROM G_GROUPINDIV grl,
                             G_INDIVPARAM gi
                      WHERE grl.MAITRE = gi.REFINDIVIDU -- from leader
                        AND grL.type = 'DEBITEURS'
                        AND gi.TYPE IN ('COTE FACTOR','COTE FACTOR HIS')
                        AND gi.STR1 IN ('DRI','KSV')
                      )lea,
                      G_GROUPINDIVDET gprdet 
                WHERE lea.rnk =1
                  AND lea.REFGROUPE = gprdet.REFGROUPE
                  AND gprdet.TYPE ='LIST'
                GROUP BY lea.REFINDIVIDU,lea.REFGROUPE,gprdet.REF1
              )gidet,
              (SELECT /*+ no_merge no_push_pred*/
                       hrisk.REFGROUPE, hrisk.DEBTOR,gi.GKVS_HRISK
                  FROM (SELECT gi.REFINDIVIDU,
                               gi.STR2 as GKVS_HRISK,
                               ROW_NUMBER() OVER (PARTITION BY gi.REFINDIVIDU,gi.STR1  ORDER BY gi.IMX_UN_ID DESC) rnk
                          FROM G_INDIVPARAM gi
                         WHERE 1=1
                           AND gi.TYPE IN ('COTE FACTOR','COTE FACTOR HIS')
                           AND gi.STR1 = 'KSV'
                       ) gi,
                      (SELECT /*+ no_merge no_push_pred*/
                               REFGROUPE,DEBTOR,
                               ROW_NUMBER() OVER (PARTITION BY REFGROUPE ORDER BY RISK_EUR DESC) rnk
                          FROM(SELECT /*+ no_merge no_push_pred LEADING(compte)*/
                                        gprdet.REFGROUPE,
                                        compte.DEBTOR,
                                        SUM(CASE WHEN substr(dbop.compte, 1, 1) = '1' 
                                                 THEN DECODE(dbop.sens, 'd', dbop.montant_mvt, dbop.montant_mvt * -1) 
                                        ELSE NULL END) RISK_EUR
                                   FROM NAM_ECR_COMPTA_BAK dbop,
                                        AD_ACCOUNT_DEBTOR_CLIENT compte,
                                        G_GROUPINDIVDET gprdet,
                                        G_GROUPINDIV gpr
                                  WHERE dbop.DTJOUR = TRUNC(sysdate)
                                    AND dbop.refdoss is not null
                                    AND dbop.codeoper IN ('DB_CLDB_COV', 'DB_CLDB_PRS') 
                                    AND dbop.REFDOSS = compte.REFDOSS
                                    AND compte.DEBTOR = gprdet.REF1
                                    AND gprdet.TYPE ='LIST'
                                    AND gpr.REFGROUPE = gprdet.REFGROUPE
                                    AND gpr.type = 'DEBITEURS'
                                  GROUP BY gprdet.REFGROUPE,compte.DEBTOR
                               )
                        )hrisk
                WHERE 1=1
                  AND hrisk.DEBTOR = gi.REFINDIVIDU
                  AND hrisk.RNK =1
                  AND gi.RNK =1
                )grisk,
                (SELECT /*+ no_merge no_push_pred INDEX(B G_GROUPINDIVDET_RFTRPE_IDX)*/
                      B.REFGROUPE,
                      SUM(B.MT01) LMIT_RICOS
                 FROM G_GROUPINDIVDET B
                WHERE 1=1
                  AND B.TYPE ='DEBTOR_GRP_DGGFL_LIM_PARAM'
                GROUP BY B.REFGROUPE
              )gricos
         WHERE gnumber.REFGROUPE = gidet.REFGROUPE(+)
           AND gnumber.DEBTOR =  gidet.DEBROR(+)
           AND gnumber.REFGROUPE = grisk.REFGROUPE(+) 
           AND gnumber.REFGROUPE = gricos.REFGROUPE(+)
       )grpnew,   
       (SELECT /*+ no_merge no_push_pred LEADING(cofact b) FULL(b) USE_HASH(b) FULL(c) USE_HASH(c)*/
               NVL(b.refdoss, c.refdoss) as refdoss,
               MAX(cofact."EB Rating")                             as "EB Rating",
               MAX(cofact."EBS Rating Datum")                      as "EBS Rating Datum",
               MAX(cofact."Client Financial Rating")               as "Client Financial Rating"
          FROM (SELECT /*+INDEX(a G_INDPAR_TYPSTR1_IDX)*/
                       a.REFINDIVIDU,a.STR1,
                       -- IMBWEB-6448     
                       (CASE WHEN a.STR1 ='DRI' THEN a.STR2 ELSE NULL END) as "EB Rating",
                       (CASE WHEN a.STR1 ='DRI' THEN a.DT01_DT ELSE NULL END) as "EBS Rating Datum",
                       --
                       (CASE WHEN a.STR1 ='FIN' THEN a.STR2 ELSE NULL END)      as "Client Financial Rating",          
                       ROW_NUMBER() OVER(PARTITION BY a.REFINDIVIDU,STR1 ORDER BY a.IMX_UN_ID DESC) rnk
                  FROM G_INDIVPARAM a               
                 WHERE a.TYPE IN ('COTE FACTOR','COTE FACTOR HIS')
                   AND a.STR1 IN ('FIN','DRI')   
                )cofact,
                ad_cases b,
                ad_cases c  
          WHERE cofact.rnk =1
            AND b.client_ref(+) = DECODE(cofact.STR1, 'FIN', cofact.REFINDIVIDU, NULL)
            AND b.categdoss(+) = 'COMPTE'
            AND c.debtor_ref(+) = DECODE(cofact.STR1, 'FIN', NULL, cofact.REFINDIVIDU)
            AND c.categdoss(+) = 'COMPTE'
         GROUP BY NVL(b.refdoss, c.refdoss)
       )ext,
       --IMBWEB-6448
       (SELECT /*+ no_merge no_push_pred*/
               REFINDIVIDU,
               MAX(KSV_RATE) KSV_RATE,
               MAX(EBS_RATE) EBS_RATE
        FROM (SELECT /*+INDEX(ksv G_INDPAR_TYPSTR1_IDX)*/ 
                     ksv.REFINDIVIDU,
                     (CASE WHEN ksv.STR1 ='KSV' THEN ksv.STR2 ELSE NULL END)  KSV_RATE,  
                     (CASE WHEN ksv.STR1 ='EBS' THEN ksv.STR2 ELSE NULL END)  EBS_RATE,            
                     ROW_NUMBER() OVER(PARTITION BY ksv.REFINDIVIDU,ksv.STR1 ORDER BY ksv.imx_un_id DESC) rnk
                FROM G_INDIVPARAM ksv
               WHERE ksv.TYPE IN ('COTE FACTOR','COTE FACTOR HIS')
                 AND ksv.STR1 IN ('KSV','EBS')
                 AND TRUNC(sysdate) BETWEEN ksv.DT09_DT AND NVL(ksv.DT07_DT,SYSDATE)
              )ksv_ebs
        WHERE ksv_ebs.rnk =1
        GROUP BY REFINDIVIDU
       )ksv_ebs_rate,
       G_INDIVIDU               gi,
       (SELECT /*+ no_merge no_push_pred*/
               REFINDIVIDU,MT03
          FROM (SELECT /*+INDEX(c G_INDPAR_TYPSTR1_IDX)*/
                       c.REFINDIVIDU, 
                       c.MT03,
                       row_number() over(PARTITION BY c.refindividu ORDER BY c.imx_un_id DESC) rnk
                  FROM G_INDIVPARAM c
                 WHERE c.TYPE = 'DEBTOR_GFL_LIM_PARAM'
                 )comm
           WHERE comm.rnk =1
       )gfl,
       (SELECT/*+FULL(G_GROUPINDIVDET)*/ 
               DISTINCT REF1,
               'Excluded from group guarantee' as NEU_SUB_gruppen
             FROM G_GROUPINDIVDET
            WHERE FG04 = 'O'
       )neu_gru,     
       V_DOMAINE               v,
       G_RECEIVERSHIP          recei,
       (SELECT  /*+ no_merge no_push_pred LEADING(gp) INDEX(gp G_PIECEDET_STR1_IDX) INDEX(compte AD_CASES_PK) USE_NL(compte)*/
               compte.REFDOSS,gp.MT01,
               ROW_NUMBER() OVER(PARTITION BY gp.REFDOSS ORDER BY gp.IMX_UN_ID DESC ) rnk
          FROM G_PIECEDET gp,
               AD_CASES compte
          WHERE gp.TYPE ='COVERAGE_RATE'
            AND gp.REFDOSS = compte.REFDOSS
            AND compte.CATEGDOSS LIKE 'COMPTE%'
       ) rate_dbcl,   
       (SELECT  /*+ no_merge no_push_pred LEADING(gp) INDEX(gp G_PIECEDET_STR1_IDX) INDEX(compte AD_CASES_PK) USE_NL(compte)*/
               cnt.CONTRACT_CASE,gp.MT01,
               ROW_NUMBER() OVER(PARTITION BY gp.REFDOSS ORDER BY gp.IMX_UN_ID DESC ) rnk
          FROM G_PIECEDET gp,
               AD_CASES cnt
          WHERE gp.TYPE ='COVERAGE_RATE'
            AND gp.REFDOSS = cnt.CONTRACT_CASE
            AND cnt.CATEGDOSS LIKE 'CONTRAT%'
       )rate_contr,
       ( SELECT/*+INDEX(INDEX(AD_CLIENT_STATEMENT_HISTORY PK_AD_CL_HISTORY)*/ 
                        CL_ACCOUNT_CASE,
                        BLOCKED_AMOUNT + RETENTIONS Retention_NBV,
                        CURRENCY
                   FROM AD_CLIENT_STATEMENT_HISTORY
                  WHERE date_id = TO_CHAR(sysdate,'J')
                    AND memo_source in ('A', 'E')
                    AND memo_source = DECODE(exist_eom_data, 1, 'E', 'A')
        ) cl_hist,
        (SELECT/*+INDEX(fi AD_FINELEM_PK)*/ 
                fi.FI_REFDOSS REFDOSS,fi.FI_DEVISE_DOS,
                SUM(fi.FI_OPEN_AMOUNT) PORTFOLIO_DBCL
           FROM AD_FINELEM fi
           WHERE fi.DATE_ID = TO_CHAR(sysdate,'J')
             AND fi.FI_TYPE IN ('FACTURE','OTHER DEBIT (SAF)','NOTE DE CREDIT')
             AND fi.FI_ACTIF ='O'
          GROUP BY fi.FI_REFDOSS,fi.FI_DEVISE_DOS
        )port_dbcl,
        (SELECT  /*+ no_merge no_push_pred LEADING(gp) INDEX(gp G_PIECEDET_STR1_IDX) INDEX(compte AD_CASES_PK) USE_NL(compte)*/
                 compte.REFDOSS,gp.MT01,
                 ROW_NUMBER() OVER(PARTITION BY gp.REFDOSS ORDER BY gp.IMX_UN_ID DESC ) rnk
          FROM G_PIECEDET gp,
               AD_CASES compte
          WHERE gp.TYPE ='FINRATE'
            AND gp.REFDOSS = compte.REFDOSS
            AND compte.CATEGDOSS LIKE 'COMPTE%'
            AND MT01 IS NOT NULL 
            AND gp.STR2 ='PDEF'
        ) compte_rate,
        (SELECT /*+ no_merge no_push_pred LEADING(gp) INDEX(gp G_PIECEDET_STR1_IDX) INDEX_FFS(cnt AD_CASES_IDX) USE_NL(cnt)*/
                 cnt.CONTRACT_CASE,gp.MT01,
                 ROW_NUMBER() OVER(PARTITION BY gp.REFDOSS ORDER BY gp.IMX_UN_ID DESC ) rnk
          FROM G_PIECEDET gp,
               AD_CASES cnt
          WHERE gp.TYPE ='FINRATE'
            AND gp.REFDOSS = cnt.CONTRACT_CASE
            AND cnt.CATEGDOSS LIKE 'CONTRAT%' 
            AND MT01 IS NOT NULL
            AND gp.STR2 ='PDEF' 
        ) cnt_rate, 
        (SELECT /*+ no_merge no_push_pred LEADING(gl_amt) FULL(gl_amt)*/
                 gl_amt.REFDOSS, opdb.CR_LOSS, opdb.RISK_EUR,opdb.RISK_EUR_NOEX,
                 LISTAGG(DISTINCT CASE WHEN substr(gl_amt.EXTREF18, 1, 1) = 1 
                                        AND decode(gl_amt.sens, 'd', gl_amt.montant_mvt, gl_amt.montant_mvt * -1)>0 
                                        AND trunc(gl_amt.DTJOUR) = TRUNC(sysdate)
                                   THEN gl_amt.EXTREF18 ELSE NULL END,',')GL_AMT
           FROM NAM_ECR_COMPTA_BAK gl_amt,
                (SELECT /*+ no_merge no_push_pred*/
                        REFDOSS,EXTREF9,op.RISK_EUR as RISK_EUR_NOEX,
                        (CH_TAUX.Conv_Orig_Dest_Tx(ad_jullian_date(sysdate),
                                                   op.CR_LOSS,
                                                   op.EL2, 
                                                   AD_GET_SYS_CCY, 
                                                   'MR',
                                                   ''))CR_LOSS,
                        (CH_TAUX.Conv_Orig_Dest_Tx(ad_jullian_date(sysdate),
                                                   op.RISK_EUR,
                                                   op.EL2, 
                                                   AD_GET_SYS_CCY, 
                                                   'MR',
                                                   ''))RISK_EUR
                  FROM (SELECT /*+ no_merge no_push_pred INDEX(NAM_ECR_COMPTA_BAK NAM_ECR_COMPTA_BAK_DTJOUR_IDX)*/
                                REFDOSS,
                                EXTREF9,
                                EL2,
                                SUM(CASE WHEN codeoper IN ('DB_CLDB_COV', 'DB_CLDB_PRS') 
                                          AND substr(compte, 1, 1) = '1' AND TRUNC(DTJOUR) = TRUNC(sysdate) 
                                         THEN DECODE(sens, 'd', montant_mvt, montant_mvt * -1) 
                                ELSE NULL END) RISK_EUR,
                                SUM(CASE WHEN codeoper IN ('PROV_DB_IN', 'PROV_DB_REV') 
                                              AND substr(compte, 1, 1) = '2'  
                                         THEN DECODE(sens, 'd', montant_mvt, montant_mvt * -1) 
                                ELSE NULL END) CR_LOSS,
                                ROW_NUMBER() OVER(PARTITION BY REFDOSS ORDER BY EXTREF9 ASC) rnk    
                           FROM NAM_ECR_COMPTA_BAK
                          WHERE DTJOUR < sysdate+1
                            AND refdoss is not null
                            AND codeoper IN ('PROV_DB_IN', 'PROV_DB_REV','DB_CLDB_COV', 'DB_CLDB_PRS') 
                          GROUP BY REFDOSS,EXTREF9,EL2
                        )op
                  WHERE op.rnk =1
                  )opdb
          WHERE gl_amt.REFDOSS = opdb.REFDOSS(+)
            AND gl_amt.DTJOUR < sysdate+1 
            AND gl_amt.REFDOSS is not null
          GROUP BY gl_amt.REFDOSS, opdb.CR_LOSS, opdb.RISK_EUR,opdb.RISK_EUR_NOEX   
        )compta_bak,
        (SELECT /*+no_merge no_push_pred*/
                refindividu,str2,pd
            FROM( SELECT /*+no_merge no_push_pred LEADING(gparam pd) FULL(gparam) FULL(pd) USE_HASH(pd)*/
                         gparam.refindividu, gparam.str2, 
                         pd.valeur/100 pd, 
                         row_number() over(partition by gparam.refindividu ORDER BY gparam.imx_un_id DESC) rnk
                    FROM g_indivparam gparam, 
                         ad_ksv_to_pd_mview pd
                   WHERE gparam.type IN ('COTE FACTOR', 'COTE FACTOR HIS')
                     AND gparam.str1 = 'KSV'
                     AND TRUNC(sysdate) BETWEEN gparam.dt09_dt AND NVL(gparam.dt07_dt, SYSDATE)
                     AND nvl(gparam.str2,0) = pd.detnum(+)
                ) 
          WHERE rnk =1 
        )pd_lgd,
        (SELECT /*+ no_merge no_push_pred FULL(UDF_INDIV)*/
                 REFINDIVIDU,
                 VALUE_C||VALUE_N||VALUE_D VALUE,
                 ROW_NUMBER() OVER(PARTITION BY REFINDIVIDU ORDER BY DT_MAJ_DT DESC) rnk
          FROM UDF_INDIV
          WHERE VALEUR_REF_INDIV ='FINREP COUNTERPARTY'
        )udf_indiv,
        (SELECT /*+ no_merge no_push_pred LEADING(B) FULL(B) FULL(A) USE_HASH(A)*/
                B.REFDOSS,B.GPIDEVIS,
                decode(sign(SUM(B.MT02 - A.CONSUMED_AMT)), -1, (-1)*SUM(B.MT02 - A.CONSUMED_AMT), NULL) REDEC_AMT /*overspending means consumed amt > lim. amt*/
           FROM AD_LIMITS_CONSUMATION A,
                AD_REQUEST_LIMIT_MVIEW B
          WHERE A.REFPIECE = B.LIBELLE_20_12
            AND B.FG05 ='O'
            AND B.TYPEDOC ='C'
          GROUP BY B.REFDOSS,B.GPIDEVIS
        )redec_amt,
        (SELECT /*+ no_merge no_push_pred FULL(B)*/
                B.GPIADR3,
                SUM(B.MT02) REDEBTOR_AMT
           FROM AD_REQUEST_LIMIT_MVIEW B
          WHERE B.FG05 ='O'
            AND B.TYPEDOC ='GFL'
          GROUP BY B.GPIADR3
        )redebtor_amt,
        (SELECT /*+no_merge no_push_pred*/
               FI_REFDOSS,FI_DEVISE_DOS,SUM_OVER,SUM_OVER_RISK,
               CASE WHEN FI_DTDEBUT_OVERDUE < AD_JULLIAN_DATE(sysdate) 
                    THEN AD_JULLIAN_DATE(sysdate) - FI_DTDEBUT_OVERDUE
               ELSE (-1)*(FI_DTDEBUT_OVERDUE - AD_JULLIAN_DATE(sysdate)) END MAX_OVERDUE     
         FROM(SELECT /*+no_merge no_push_pred*/
                     fic.FI_REFDOSS,fic.FI_DEVISE_DOS,
                     SUM(fic.SUM_OVER) SUM_OVER,
                     SUM(fic.SUM_OVER_RISK) SUM_OVER_RISK,
                     MIN(FI_DTDEBUT_OVERDUE)FI_DTDEBUT_OVERDUE
              FROM(SELECT /*+no_merge no_push_pred FULL(fi) FULL(rent_amt) USE_HASH(rent_amt)*/ 
                          fic.FI_REFDOSS,fic.FI_DTDEBUT,rent_amt.REAL_AMOUNT_DEC,fic.FI_OPEN_AMOUNT,fic.FI_DEVISE_DOS,
                          fi_refelem,
                          (CASE WHEN (AD_JULLIAN_DATE(sysdate) - fic.FI_DTDEBUT) >= 90 
                                THEN fic.FI_MONTANT_DOS ELSE NULL END) SUM_OVER,
                          (CASE WHEN fic.FI_OPEN_AMOUNT - NVL(rent_amt.REAL_AMOUNT_DEC,0) > 0
                                 AND (AD_JULLIAN_DATE(sysdate) - fic.FI_DTDEBUT) >= 90 
                                THEN fic.FI_OPEN_AMOUNT - NVL(rent_amt.REAL_AMOUNT_DEC,0) ELSE NULL END) SUM_OVER_RISK,
                          (CASE WHEN (FI_OPEN_AMOUNT - NVL(REAL_AMOUNT_DEC,0) > 0) THEN fic.FI_DTDEBUT ELSE NULL END) FI_DTDEBUT_OVERDUE
                     FROM AD_FINELEM_3NF fic,
                          (SELECT /*+FULL(G_VENRESTRICTION)*/ 
                                  REFELEM, SUM(REAL_AMOUNT_DEC) REAL_AMOUNT_DEC
                             FROM G_VENRESTRICTION GROUP BY REFELEM
                           )rent_amt
                     WHERE fic.FI_TYPE in ('FACTURE','OTHER DEBIT (SAF)')
                       AND fic.FI_ACTIF ='O'
                       AND fic.FI_REFELEM = rent_amt.REFELEM(+)
                   )fic 
               GROUP BY  fic.FI_REFDOSS,fic.FI_DEVISE_DOS)
         )max_overdue,
         (SELECT /*+no_merge no_push_pred*/COMPTE_CASE,
                 NVL(POLICE_HODER_DBCL,POLICE_HODER_CON)  POLICE_HODER,
                 NVL(REF_INSURER_DBCL,REF_INSURER_CON)  REF_INSURER,
                 NVL(NOM_INSURER_DBCL,NOM_INSURER_CON)  NOM_INSURER 
            FROM (SELECT /*+no_merge no_push_pred*/ COMPTE_CASE,
                         max(POLICE_HODER_DBCL) POLICE_HODER_DBCL,
                         max(POLICE_HODER_CON)  POLICE_HODER_CON,
                         max(REF_INSURER_DBCL) REF_INSURER_DBCL,
                         max(REF_INSURER_CON) REF_INSURER_CON,
                         max(NOM_INSURER_DBCL) NOM_INSURER_DBCL,
                         max(NOM_INSURER_CON) NOM_INSURER_CON
                   FROM (SELECT /*+LEADING(B C D E dbcl F) INDEX(B TYPPIECE_LASTLOAD_IND) INDEX(C GPDET_TYP_REF_IDX) USE_NL(C) 
                               INDEX(D G_PIECE_TYPE_REFPIECE_INX) USE_NL(D) INDEX(E AD_CASE_POLICE_PK) USE_NL(E) 
                               FULL(dbcl) USE_HASH(dbcl) FULL(F) USE_HASH(F)*/
                               B.REFDOSS COMPTE_CASE,
                               D.ST02 POLICE_HODER_DBCL,
                               E.DB_REF REF_INSURER_DBCL,
                               E.DB_NOM NOM_INSURER_DBCL,
                               NULL POLICE_HODER_CON,
                               NULL REF_INSURER_CON,
                               NULL NOM_INSURER_CON
                          FROM G_PIECE B,
                               G_PIECEDET C,
                               G_PIECE D,
                               AD_CASE_POLICE E,
                               AD_ACCOUNT_DEBTOR_CLIENT dbcl,
                               AD_DEBTORS F
                          WHERE B.TYPPIECE ='COMPTE'
                            AND B.REFPIECE = C.REFPIECE
                            AND C.TYPE = 'ASSURANCE_CREDIT'
                            AND NVL(C.STR7,C.STR9) = D.REFPIECE
                            AND D.TYPPIECE ='POLICE'
                            AND D.REFDOSS = E.REFDOSS
                            AND SYSDATE BETWEEN C.DT01_DT AND NVL(C.DT02_DT,SYSDATE)
                            AND dbcl.REFDOSS = B.REFDOSS
                            AND dbcl.DEBTOR = F.DEBTOR_REFINDIVIDU
                            AND F.DEBTOR_PAYS = C.STR1
                            UNION
                            SELECT /*+LEADING(B C D E dbcl F) INDEX(B TYPPIECE_LASTLOAD_IND) INDEX(C GPDET_TYP_REF_IDX) USE_NL(C) 
                                     INDEX(D G_PIECE_TYPE_REFPIECE_INX) USE_NL(D) INDEX(E AD_CASE_POLICE_PK) USE_NL(E) 
                                     FULL(dbcl) USE_HASH(dbcl) FULL(F) USE_HASH(F)*/
                                 dbcl.REFDOSS COMPTE_CASE,
                                 NULL POLICE_HODER_DBCL,
                                 NULL REF_INSURER_DBCL,
                                 NULL NOM_INSURER_DBCL,
                                 D.ST02 POLICE_HODER_CON,
                                 E.DB_REF REF_INSURER_CON,
                                 E.DB_NOM NOM_INSURER_CON
                          FROM G_PIECE B,
                               G_PIECEDET C,
                               G_PIECE D,
                               AD_CASE_POLICE E,
                               AD_CASES dbcl,
                               AD_DEBTORS F
                          WHERE B.TYPPIECE ='CONTRAT'
                            AND B.REFPIECE = C.REFPIECE
                            AND C.TYPE = 'ASSURANCE_CREDIT'
                            AND NVL(C.STR7,C.STR9) = D.REFPIECE
                            AND D.TYPPIECE ='POLICE'
                            AND D.REFDOSS = E.REFDOSS
                            AND B.REFDOSS = dbcl.CONTRACT_CASE
                            AND dbcl.CATEGDOSS ='COMPTE'
                            AND SYSDATE BETWEEN C.DT01_DT AND NVL(C.DT02_DT,SYSDATE)
                            AND dbcl.DEBTOR_REF = F.DEBTOR_REFINDIVIDU
                            AND F.DEBTOR_PAYS = C.STR1
                      )group by COMPTE_CASE
                 )
       )police,
       (SELECT /*+ no_merge no_push_pred*/
               a.REFDOSS,LISTAGG(a.LIB3) WITHIN GROUP(ORDER BY a.ord) LIB3
          FROM (SELECT /*+ no_merge no_push_pred INDEX(gp G_PIECEDET_TYPE_LASTLOAD_IDX)*/
                        gp.REFDOSS,
                        gp.LIB3,
                        DECODE(gp.LIB2,'VERSITAT',1,2) ord,
                        row_number() over(partition by gp.REFDOSS,gp.LIB2 order by IMX_UN_ID desc) rn 
                  FROM G_PIECEDET gp
                  WHERE gp.type ='UDF'
                    AND gp.LIB2 in ('VERSITAT','INSUR')
                 )a
          WHERE a.rn =1
          GROUP BY a.REFDOSS
      )ins_quality,
      (SELECT /*+ no_merge no_push_pred FULL(T_EXTERN_CALC_PROV)*/
               REFINDIVIDU, SUM(NVL(EWB_ALLOCATION,0) - NVL(EWB_RELEASE,0) - NVL(EWB_USAGE,0)) total_ebv
          FROM T_EXTERN_CALC_PROV
         GROUP BY REFINDIVIDU
       )ebv,
       V_DOMAINE lov_cnt,
       (SELECT /*+ no_merge no_push_pred */ origine,taux,CRDATE4I_DT 
         FROM (SELECT /*+ INDEX_DESC(T T_DEVISE_IX3)*/ 
                    origine,destination,NVL(taux,1.0)taux,TRUNC(CRDATE4I_DT) CRDATE4I_DT,
                    row_number() over (partition by origine order by DTDEBUT_DT desc) rnk
                FROM t_devise T
               WHERE T.dtdebut_dt <= sysdate
                 AND T.TYPE = 'MR'
                 AND T.place = 'AUT'
                 AND NVL( T.Destination, 'EUR' ) = 'EUR'
             )
        WHERE rnk =1
       )ex_rate  
 WHERE dbcl.DEBTOR = db.DEBTOR_REFINDIVIDU
   AND dbcl.CLIENT = cl.CLIENT_REFINDIVIDU
   AND dbcl.CONTRACT = ctr_case.REFDOSS
   AND ctr.REFDOSS = ctr_case.REFDOSS
   AND ctr.TYPPIECE = 'CONTRAT'
   AND dbcl.REFLOT = cl_acc.REFDOSS   
   AND t1.REFINDIVIDU(+) = db.DEBTOR_REFINDIVIDU
   AND ext.REFDOSS(+) = dbcl.REFDOSS
   --IMBWEB-6448
   AND ksv_ebs_rate.REFINDIVIDU(+) = db.DEBTOR_REFINDIVIDU
   AND v.TYPE(+) IN ('T.NAF', 'DRI_INDUSTRY', 'DRI_NACE_CODE')
   -- IMBWEB-6583
   AND v.ABREV(+) = COALESCE(CASE WHEN NVL(gi.DRI_INDUSTRY_CODE,'_UNBEK') != '_UNBEK' THEN gi.DRI_INDUSTRY_CODE ELSE NULL END,
                             CASE WHEN NVL(gi.STR44,'_UNBEK') NOT IN ('_UNBEKANNT','_UNBEK') THEN gi.STR44 ELSE NULL END,db.STR15)   
   AND recei.REFINDIVIDU(+) = cl.CLIENT_REFINDIVIDU
   AND rate_dbcl.REFDOSS(+) = dbcl.REFDOSS
   AND rate_dbcl.rnk(+) =1
   AND rate_contr.CONTRACT_CASE(+) = ctr.REFDOSS
   AND rate_contr.rnk(+) =1
   --
   AND cl_hist.CL_ACCOUNT_CASE(+) = dbcl.REFLOT
   AND compta_bak.REFDOSS(+) = dbcl.REFDOSS
   AND port_dbcl.REFDOSS = dbcl.REFDOSS
   AND compte_rate.REFDOSS(+) = dbcl.REFDOSS
   AND compte_rate.rnk(+) =1
   AND cnt_rate.CONTRACT_CASE(+) = ctr.REFDOSS
   AND cnt_rate.rnk(+) =1
   AND udf_indiv.REFINDIVIDU(+) = db.DEBTOR_REFINDIVIDU
   AND udf_indiv.rnk(+) =1
   AND gi.REFINDIVIDU = dbcl.DEBTOR
   AND gfl.REFINDIVIDU(+) = db.DEBTOR_REFINDIVIDU
   AND neu_gru.REF1(+) = db.DEBTOR_REFINDIVIDU
   AND redec_amt.REFDOSS(+) = dbcl.REFDOSS
   AND redebtor_amt.GPIADR3(+) = db.DEBTOR_REFINDIVIDU
   AND max_overdue.FI_REFDOSS(+) = dbcl.REFDOSS 
   AND police.COMPTE_CASE(+) = dbcl.REFDOSS
   AND ins_quality.REFDOSS(+) = ctr_case.REFDOSS
   AND ebv.REFINDIVIDU(+) = dbcl.DEBTOR
   AND lov_cnt.TYPE(+) ='CONTRTYP'
   AND lov_cnt.ABREV(+) = ctr.GPIOBJET
   AND dbcl.DEBTOR = c_limit.DEBTOR(+)
   AND dbcl.CLIENT = c_limit.CLIENT(+)
   AND dbcl.ANCREFDOSS = c_limit.CONTRACT_NUMBER(+)
   AND pd_lgd.REFINDIVIDU(+) = dbcl.DEBTOR
   AND ex_rate.ORIGINE(+) = dbcl.DEVISE
   AND db.DEBTOR_REFINDIVIDU = grpnew.DEBTOR(+)
UNION ALL
SELECT /*+no_merge no_push_pred LEADING(ctr_case ctr cl_acc dec tcl) FULL(ctr_case) INDEX(ctr G_PIECE_TYPE_REFDOSS_IDX) USE_NL(ctr) FULL(cl_acc) USE_HASH(cl_acc) INDEX(dec G_PIECE_TYPE_REFDOSS_IDX) USE_NL(dec) 
        FULL(tcl) USE_HASH(tcl) FULL(cl) USE_HASH(cl) USE_HASH(cl_porf) USE_HASH(ins_quality) USE_HASH(ext) USE_HASH(ebv) FULL(recei) USE_HASH(recei) FULL(lov_cnt) USE_HASH(lov_cnt)
        USE_HASH(Risk_EUR) USE_HASH(compta_bak)*/ 
       t1.NOneNB                           as "OeNB ID Nr.",
       grpnew.GOneNB                           as "OeNB-Gr.ID.Nr",
       grpnew.GOneNBN                          as "Name Gruppe",
       cl.CLIENT_REFINDIVIDU               as "Poolnummer",
       --IMBDEV-10690
       RTRIM(LTRIM(cl.CLIENT_PRENOM || ' ' || cl.CLIENT_NOM)) as "Individual Name",
       cl.CLIENT_PAYS                      as "Land",
       cl.CLIENT_CP                        as "PLZ",
       cl.CLIENT_VILLE                     as "Ort",
       --
       ksv_ebs_rate.KSV_RATE               as "KSV-Rating",
       ksv_ebs_rate.EBS_RATE               as "KSV Rating – EB Rating",
       cl.STR15                            as "Nace Code 1- KSV",
       gi.STR44                            as "EB Nace Code",
       gi.DRI_INDUSTRY_CODE                as "Nace Code 2",
       COALESCE(CASE WHEN NVL(gi.DRI_INDUSTRY_CODE,'_UNBEK') != '_UNBEK' THEN gi.DRI_INDUSTRY_CODE ELSE NULL END,
                CASE WHEN NVL(gi.STR44,'_UNBEK') NOT IN ('_UNBEKANNT','_UNBEK') THEN gi.STR44 ELSE NULL END,cl.STR15) as "Final Nace",
       SUBSTR(COALESCE(CASE WHEN NVL(gi.DRI_INDUSTRY_CODE,'_UNBEK') != '_UNBEK' THEN gi.DRI_INDUSTRY_CODE ELSE NULL END,
                CASE WHEN NVL(gi.STR44,'_UNBEK') NOT IN ('_UNBEKANNT','_UNBEK') THEN gi.STR44 ELSE NULL END,cl.STR15), 1, 1) as "Industry Nace Code",
       (CASE WHEN v.TYPE = 'T.NAF' THEN v.VALEUR
             WHEN v.TYPE IN ('DRI_INDUSTRY', 'DRI_NACE_CODE') THEN v.ABREV1
         END)                               as "Industry Segment",
       --  
       ebdri.EB_Rating                      as "EB Rating",
       ebdri.EBS_Rating_Datum               as "EBS Rating Datum",
       --
       cl.CLIENT_REFINDIVIDU                as "Client ID",
       RTRIM(LTRIM(cl.CLIENT_PRENOM || ' ' || cl.CLIENT_NOM)) as "Client Name",
       cl_acc.CONTRACT_NUMBER                                 as "Vkf.Nr",
       tcl.refdossext                                         as "Contract NR-SAP-FI",
       cl_acc.REFDOSS                                as "Subcontract Reference",
       cl_acc.DEVISE                                 as "Subcontract Currency",
       cl_porf.PORTFOLIO                             as "Saldo",
       NULL                                          as "Vkf.BV",
       ext.STR2                                      as "Client Financial Rating",
       recei.DEFAULT_EVENT                           as "Ereignis Code",
       NVL(lov_cnt.VALEUR_AN,ctr.GPIOBJET)            as "Qualitat",
       ins_quality.LIB3                              as "Insurance Quality",
       NULL                                          as "Haftung IMB",
       NULL                                          as "Syndication",
       NULL                                          as "Erste group guarantee",
       NULL                                          as "Foreign Bank (guarantee)",
       NULL                                          as "SB",       
       NULL                                          as "Debtor Limit",
      (CH_TAUX.Conv_Orig_Dest_Tx(ad_jullian_date(Sysdate),
                                 cl_porf.PORTFOLIO,
                                 cl_porf.currency, 
                                 AD_GET_SYS_CCY, 
                                 'MR',
                                 ''))                as "Portfolio in EUR",
      (CH_TAUX.Conv_Orig_Dest_Tx(ad_jullian_date(Sysdate),
                                 NVL(cl_porf.BLOCKED_AMOUNT + cl_porf.RETENTIONS, 0),
                                 cl_porf.currency, 
                                 AD_GET_SYS_CCY, 
                                 'MR',
                                 ''))                as "Retention NBV in EUR",
      NULL                                           as "Versicherer",
      --IMBDEV-10690
      '2'                                            as "Riskexposure Level", 
      (CASE WHEN NVL(dec.libelle_20_3,'N') = 'O'  
           THEN NVL(compta_bak.SUPPLIER_AMT_NOEX,0) + NVL(Risk_EUR.df_monttc_noexdf,0)
           ELSE NVL(compta_bak.SUPPLIER_AMT_NOEX,0) + NVL(Risk_EUR.df_monttc_noexndf,0) 
      END)                                           as "Riskexposure",         
      (CASE WHEN NVL(dec.libelle_20_3,'N') = 'N'  
           THEN NVL(compta_bak.SUPPLIER_AMT,0) + NVL(Risk_EUR.df_monttc_evo,0)
           ELSE NVL(compta_bak.SUPPLIER_AMT,0) + NVL(Risk_EUR.df_monttc,0) 
      END)                                           as "Riskexposure in EUR", 
      NVL(ex_rate.TAUX,1.0)                          as "Wechselkurs", 
      ex_rate.CRDATE4I_DT                            as "Wechselkurs Datum",
      --                            
      NULL                                           as "FINREP",
      compta_bak.GL_AMT                              as "GL Account",
      NULL                                           as "KuKurz",
      NULL                                           as "Stage",
      NULL                                           as "NEU / SUB_gruppen, wenn vorhanden",
      RTRIM(LTRIM((CASE WHEN grpnew.GOneNBN IS NOT NULL THEN grpnew.GOneNBN
            ELSE cl.CLIENT_PRENOM || ' ' || cl.CLIENT_NOM END)))  as "Gruppe / Name für Pivot",
      --IMBDEV-10690
 /*     NULL     as "Gruppe DRI-Rating",
      NULL     as "Gruppe KSV-Rating",   
      NULL     as "Gruppe KSV-Rating Level",
      NULL     as "Gruppe RICOS",*/
      (CASE WHEN grpnew.GOneNB IS NOT NULL THEN grpnew.Gruppe_DRI_Rating ELSE NULL END) as "Gruppe DRI-Rating",
      --
      (CASE 
         WHEN grpnew.GOneNB IS NOT NULL AND grpnew.Gruppe_KSV_Rating > 0 THEN grpnew.Gruppe_KSV_Rating 
         WHEN grpnew.GOneNB IS NOT NULL AND NVL(grpnew.Gruppe_KSV_Rating,0) = 0 AND grpnew.GKVS_HRISK > 0 THEN grpnew.GKVS_HRISK 
         WHEN grpnew.GOneNB IS NOT NULL AND NVL(grpnew.GKVS_HRISK,0) = 0 THEN ksv_ebs_rate.KSV_RATE
       END    
      ) as "Gruppe KSV-Rating",
      -- 
      (CASE 
         WHEN grpnew.GOneNB IS NOT NULL AND grpnew.Gruppe_KSV_Rating > 0 THEN 'Group' 
         WHEN grpnew.GOneNB IS NOT NULL AND NVL(grpnew.Gruppe_KSV_Rating,0) = 0 AND grpnew.GKVS_HRISK > 0 THEN 'Riskexposure' 
         WHEN grpnew.GOneNB IS NOT NULL AND NVL(grpnew.GKVS_HRISK,0) = 0 THEN 'Debtor'
       END    
      ) as "Gruppe KSV-Rating Level", 
      --   
      (CASE WHEN grpnew.GOneNB IS NOT NULL THEN grpnew.Gruppe_RICOS ELSE NULL END) as "Gruppe RICOS",      
      --          
      compta_bak.CR_LOSS                             as "Expected Loss Betrag in EUR",
      --
      (-1)*(CASE WHEN ebv.total_ebv >0 THEN 0 ELSE 
            NVL(compta_bak.SUPPLIER_AMT,0)*NVL(pd_lgd.pd,AD_PD_LGD_DEFAULT.AD_GET_PD_DEFAULT)*AD_PD_LGD_DEFAULT.AD_GET_LGD_BU 
       END)                                              as "Kalkulierter Expected Loss Betrag in EUR",
      --
      NULL                                           as "Versicherungssumme",
      NULL                                           as "Versicherungssumme in EUR",
      NULL                                           as "Abbausaldo in EUR",  
      ext.MAX_OVERDUE                                as "Max. Überfällig in Tagen" ,
      NULL                                           as "Summe Überfällig",
      NULL                                           as "Summe Überfällig Riskexposure in EUR",
      TO_NUMBER(DECODE(ext.npl_level,'<90_days',NVL(compta_bak.SUPPLIER_AMT,0) + NVL(Risk_EUR.df_monttc,0),NULL))  as "NPL-Unlikely to pay, not past-due or <= 90 days" ,
      TO_NUMBER(DECODE(ext.npl_level,'91_180'  ,NVL(compta_bak.SUPPLIER_AMT,0) + NVL(Risk_EUR.df_monttc,0),NULL))  as "NPL-Past due greater than 90 days up to 180 days",
      TO_NUMBER(DECODE(ext.npl_level,'181_360' ,NVL(compta_bak.SUPPLIER_AMT,0) + NVL(Risk_EUR.df_monttc,0),NULL))  as "NPL-Past due greater than 180 days up to 1 year", 
      TO_NUMBER(DECODE(ext.npl_level,'5_years' ,NVL(compta_bak.SUPPLIER_AMT,0) + NVL(Risk_EUR.df_monttc,0),NULL))  as "NPL-Past due greater than 1 year up to 5 years", 
      TO_NUMBER(DECODE(ext.npl_level,'over_5years',NVL(compta_bak.SUPPLIER_AMT,0) + NVL(Risk_EUR.df_monttc,0),NULL))  as "NPL-Past due greater than 5 years",
     (CASE WHEN ext.MAX_OVERDUE <= 0 THEN '0 - 0' 
           WHEN ext.MAX_OVERDUE <=30 THEN '1 - up to 30 days'
           WHEN ext.MAX_OVERDUE BETWEEN 31 AND 60 THEN '2 - 31 to 60 days' 
           WHEN ext.MAX_OVERDUE BETWEEN 61 AND 90 THEN '3 - 61 to 90 days'
           WHEN ext.MAX_OVERDUE BETWEEN 91 AND 180 THEN '4 - 91 to 180 days'
           WHEN ext.MAX_OVERDUE BETWEEN 181 AND 360 THEN '5 - 181  days to 1 year'
           WHEN ext.MAX_OVERDUE BETWEEN 361 AND 720 THEN '6 - 1 year to 2 years'
           WHEN ext.MAX_OVERDUE BETWEEN 721 AND 1800 THEN '7 - 2 years to 5 years'
           WHEN ext.MAX_OVERDUE > 1801 THEN '8 - greater than 7 years' 
      END) as "PL/NPL-Type",
      CASE WHEN ebv.total_ebv > 0 THEN ebv.total_ebv ELSE NULL END  AS "Total EBV >0"                                                                                                                                                                                                                                                                                                                                                
FROM AD_ACCOUNT_CLIENT_MVIEW  cl_acc,
     g_piece                  dec,
     AD_CLIENTS               cl,
     AD_CASE_CONTRAT          ctr_case,
     G_PIECE                  ctr,
     G_RECEIVERSHIP           recei,
     G_INDIVIDU               gi,
     V_DOMAINE               v,
     (SELECT REFDOSS,EXTREF9,GL_AMT,op.SUPPLIER_AMT as SUPPLIER_AMT_NOEX,
             (CH_TAUX.Conv_Orig_Dest_Tx(ad_jullian_date(sysdate),
                                           op.CR_LOSS,
                                           op.EL2, 
                                           AD_GET_SYS_CCY, 
                                           'MR',
                                           ''))CR_LOSS,
             (CH_TAUX.Conv_Orig_Dest_Tx(ad_jullian_date(sysdate),
                                           op.SUPPLIER_AMT,
                                           op.EL2, 
                                           AD_GET_SYS_CCY, 
                                           'MR',
                                           '')) SUPPLIER_AMT
        FROM (SELECT /*+ no_merge no_push_pred FULL(NAM_ECR_COMPTA_BAK)*/
                        REFDOSS,
                        EXTREF9,
                        EL2,
                        LISTAGG(DISTINCT CASE WHEN substr(EXTREF18, 1, 1) = 1 
                                     AND decode(sens, 'd', montant_mvt, montant_mvt * -1)>0
                                     AND trunc(DTJOUR) = TRUNC(sysdate)
                                     THEN EXTREF18 ELSE NULL END,',')GL_AMT,  
                        SUM(CASE WHEN codeoper IN ('PROV_CL_IN', 'PROV_CL_REV') 
                                      AND substr(compte, 1, 1) = '2'  
                                 THEN DECODE(sens, 'd', montant_mvt, montant_mvt * -1) 
                        ELSE NULL END) CR_LOSS,
                        SUM(CASE WHEN codeoper IN ('ASSET_SUPPLIER') 
                                 AND substr(compte, 1, 1) = '1' AND trunc(DTJOUR) = TRUNC(sysdate)
                                 THEN DECODE(sens, 'd', montant_mvt, montant_mvt * -1) 
                        ELSE NULL END)SUPPLIER_AMT,  
                        ROW_NUMBER() OVER(PARTITION BY REFDOSS ORDER BY EXTREF9 ASC) rnk    
                   FROM NAM_ECR_COMPTA_BAK
                   WHERE DTJOUR < sysdate+1
                     AND refdoss is not null
                  GROUP BY REFDOSS,EXTREF9,EL2
             )op
        WHERE op.rnk =1
      )compta_bak,
      (SELECT /*+no_merge no_push_pred*/
                refindividu,str2,pd
            FROM( SELECT /*+no_merge no_push_pred LEADING(gparam pd) FULL(gparam) FULL(pd) USE_HASH(pd)*/
                         gparam.refindividu, gparam.str2, 
                         pd.valeur/100 pd, 
                         row_number() over(partition by gparam.refindividu ORDER BY gparam.imx_un_id DESC) rnk
                    FROM g_indivparam gparam, 
                         ad_ksv_to_pd_mview pd
                   WHERE gparam.type IN ('COTE FACTOR', 'COTE FACTOR HIS')
                     AND gparam.str1 = 'KSV'
                     AND TRUNC(sysdate) BETWEEN gparam.dt09_dt AND NVL(gparam.dt07_dt, SYSDATE)
                     AND nvl(gparam.str2,0) = pd.detnum(+)
                ) 
          WHERE rnk =1 
      )pd_lgd,
      (SELECT /*+ no_merge no_push_pred LEADING(fd) FULL(fd) FULL(fp) USE_HASH(fp) USE_HASH(cl_struct)*/
             cl_struct.decompte_refdoss,--SUM(fd.df_monttc_mvt) df_monttc_mvt,
             SUM(CASE WHEN cl_struct.VCSOURCE IN ('1','2','3') 
                      THEN DECODE(fd.df_sen,'D',(fd.df_monttc_mvt - NVL(fd.df_paye_mvt, 0)),(fd.df_monttc_mvt - NVL(fd.df_paye_mvt, 0))*(-1)) ELSE 0 END)df_monttc_noexdf,
             SUM(CASE WHEN cl_struct.VCSOURCE IN ('1','3') 
                      THEN DECODE(fd.df_sen,'D',(fd.df_monttc_mvt - NVL(fd.df_paye_mvt, 0)),(fd.df_monttc_mvt - NVL(fd.df_paye_mvt, 0))*(-1)) ELSE 0 END)df_monttc_noexndf,           
             SUM(CASE WHEN cl_struct.VCSOURCE IN ('1','2','3')
                      THEN CH_TAUX.Conv_Orig_Dest_Tx(ad_jullian_date(sysdate),
                                       NVL(DECODE(fd.df_sen,'D',(fd.df_monttc_mvt - NVL(fd.df_paye_mvt, 0)),(fd.df_monttc_mvt - NVL(fd.df_paye_mvt, 0))*(-1)), 0),
                                       fd.df_devise_mvt, 
                                       AD_GET_SYS_CCY, 
                                       'MR',
                                       '') ELSE 0 END) df_monttc,
             SUM(CASE WHEN cl_struct.VCSOURCE IN ('1','3')
                      THEN CH_TAUX.Conv_Orig_Dest_Tx(ad_jullian_date(sysdate),
                                       NVL(DECODE(fd.df_sen,'D',(fd.df_monttc_mvt - NVL(fd.df_paye_mvt, 0)),(fd.df_monttc_mvt - NVL(fd.df_paye_mvt, 0))*(-1)), 0),
                                       fd.df_devise_mvt, 
                                       AD_GET_SYS_CCY, 
                                       'MR',
                                       '') ELSE 0 END) df_monttc_evo                          
        FROM f_detfac fd,
             (select distinct pf_nom from f_parfac where nvl(pf_fg_tech_item, 'N') = 'N' ) fp, 
             (select/*+FULL(ad_cases)*/ 
                     refdoss, client_ref,
                     decode(categdoss, 'COMPTE', decompte_ref, refdoss) decompte_refdoss, 
                     decode(categdoss, 'COMPTE', '3', '1') VCSOURCE
                from ad_cases 
               where categdoss in ('COMPTE', 'DECOMPTE')
             union all
              select/*+FULL(ad_cases)*/ 
                     contract_case,client_ref, -- contract level
                     refdoss decompte_refdoss, '2' VCSOURCE
                from ad_cases  
               where categdoss = 'DECOMPTE'
                 and default_decompte = 'O'
             ) cl_struct
       WHERE NVL(fd.df_ann, 0) = 0 
         AND fd.df_monttc_mvt - NVL(fd.df_paye_mvt, 0) > 0 
         AND fd.df_rel IS NOT NULL
         AND fd.df_dos = cl_struct.refdoss
         AND fd.df_cli = cl_struct.client_ref
         AND upper(fd.df_nom) = fp.pf_nom
         AND DF_DAT <=  TO_CHAR(sysdate,'J')
      group by cl_struct.decompte_refdoss
      )Risk_EUR,
      (SELECT /*+ no_merge no_push_pred */
             CL_ACCOUNT_CASE,
             CURRENCY,
             PORTFOLIO,
             BLOCKED_AMOUNT,
             RETENTIONS,
             FIU_EUR
      FROM (SELECT /*+ no_merge no_push_pred INDEX(PK_AD_CL_HISTORY)*/
                       DATE_ID,
                       CL_ACCOUNT_CASE, 
                       PORTFOLIO,
                       BLOCKED_AMOUNT, 
                       RETENTIONS,
                       FIU_EUR,
                       CURRENCY,
                       ROW_NUMBER() OVER(PARTITION BY CL_ACCOUNT_CASE,DATE_ID,CURRENCY ORDER BY DATE_ID DESC) rnk
                  FROM AD_CLIENT_STATEMENT_HISTORY
                WHERE MEMO_SOURCE ='A'
                 AND DATE_ID = TO_CHAR(sysdate,'J')
             ) 
      WHERE rnk =1 
     )cl_porf,
     (SELECT /*+ no_merge no_push_pred*/
             a.REFDOSS,LISTAGG(a.LIB3) WITHIN GROUP(ORDER BY a.ord) LIB3
        FROM (SELECT /*+ no_merge no_push_pred INDEX(gp G_PIECEDET_TYPE_LASTLOAD_IDX)*/
                      gp.REFDOSS,
                      gp.LIB3,
                      DECODE(gp.LIB2,'VERSITAT',1,2) ord,
                      row_number() over(partition by gp.REFDOSS,gp.LIB2 order by IMX_UN_ID desc) rn 
                FROM G_PIECEDET gp
               WHERE gp.type ='UDF'
                 AND gp.LIB2 in ('VERSITAT','INSUR')
               )a
        WHERE a.rn =1
        GROUP BY a.REFDOSS
    )ins_quality,
    (SELECT /*+INDEX(G_INDIVPARAM G_INDPAR_TYPSTR1_IDX)*/
             REFINDIVIDU,DT02_DT ,STR2,
             (CASE WHEN STR2 ='R' AND  (TO_CHAR(sysdate,'J') - TO_CHAR(DT02_DT,'J')) BETWEEN  0 AND 90 THEN  '<90_days' 
                   WHEN STR2 ='R' AND  (TO_CHAR(sysdate,'J') - TO_CHAR(DT02_DT,'J')) BETWEEN 91 AND 180 THEN '91_180' 
                   WHEN STR2 ='R' AND  (TO_CHAR(sysdate,'J') - TO_CHAR(DT02_DT,'J')) BETWEEN 181 AND 360 THEN '181_360' 
                   WHEN STR2 ='R' AND  (TO_CHAR(sysdate,'J') - TO_CHAR(DT02_DT,'J')) BETWEEN 361 AND 1800 THEN '5_years'
                   WHEN STR2 ='R' AND  (TO_CHAR(sysdate,'J') - TO_CHAR(DT02_DT,'J')) > 1800 THEN 'over_5years' 
                   ELSE NULL  END) npl_level,
             (CASE WHEN STR2 ='R' AND TO_CHAR(sysdate,'J') > TO_CHAR(DT02_DT,'J')
                  THEN (TO_CHAR(sysdate,'J') - TO_CHAR(DT02_DT,'J')) ELSE NULL END) MAX_OVERDUE,      
             ROW_NUMBER() OVER(PARTITION BY REFINDIVIDU ORDER BY IMX_UN_ID DESC) rnk
        FROM G_INDIVPARAM
       WHERE TYPE IN ('COTE FACTOR','COTE FACTOR HIS')
         AND STR1 ='FIN'
    )ext,
   --IMBDEV-10690
   (SELECT /*+ no_merge no_push_pred*/
           REFINDIVIDU,
           MAX(KSV_RATE) KSV_RATE,
           MAX(EBS_RATE) EBS_RATE
    FROM (SELECT /*+INDEX(ksv G_INDPAR_TYPSTR1_IDX)*/ 
                 ksv.REFINDIVIDU,
                 (CASE WHEN ksv.STR1 ='KSV' THEN ksv.STR2 ELSE NULL END)  KSV_RATE,  
                 (CASE WHEN ksv.STR1 ='EBS' THEN ksv.STR2 ELSE NULL END)  EBS_RATE,            
                 ROW_NUMBER() OVER(PARTITION BY ksv.REFINDIVIDU,ksv.STR1 ORDER BY ksv.imx_un_id DESC) rnk
            FROM G_INDIVPARAM ksv
           WHERE ksv.TYPE IN ('COTE FACTOR','COTE FACTOR HIS')
             AND ksv.STR1 IN ('KSV','EBS')
             AND TRUNC(sysdate) BETWEEN ksv.DT09_DT AND NVL(ksv.DT07_DT,SYSDATE)
          )ksv_ebs
    WHERE ksv_ebs.rnk =1
    GROUP BY REFINDIVIDU
   )ksv_ebs_rate,   
  (SELECT /*+ no_merge no_push_pred FULL(T_EXTERN_CALC_PROV)*/
           REFINDIVIDU, SUM(NVL(EWB_ALLOCATION,0) - NVL(EWB_RELEASE,0) - NVL(EWB_USAGE,0)) total_ebv
      FROM T_EXTERN_CALC_PROV
     GROUP BY REFINDIVIDU       
   )ebv,
   V_DOMAINE lov_cnt,
   --IMBWEB-6520
    (SELECT /*+ no_merge no_push_pred */
             REFINDIVIDU,MAX(NOneNB) NOneNB,MAX(KUKURZ) KUKURZ
       FROM (SELECT /*+FULL(ti)*/  
                     ti.REFINDIVIDU,
                     (CASE WHEN ti.SOCIETE = 'National bank code ID OeNB' THEN ti.REFEXT ELSE NULL END) as NOneNB, 
                     (CASE WHEN ti.SOCIETE = 'KUKURZ' THEN ti.REFEXT ELSE NULL END) as KUKURZ,
                     ROW_NUMBER() OVER (PARTITION BY ti.REFINDIVIDU,ti.SOCIETE  ORDER BY ti.IMX_UN_ID DESC) rnk
                FROM T_INDIVIDU ti
               WHERE ti.SOCIETE IN ('National bank code ID OeNB','KUKURZ') 
             )a                     
      WHERE a.rnk =1
      GROUP BY REFINDIVIDU
     )t1,
    (SELECT /*+no_merge no_push_pred LEADING(gnumber)*/
           gnumber.REFINDIVIDU,
           gnumber.GNUMBER   AS GOneNB,
           gnumber.GNOM      AS GOneNBN,
           gidet.GDRI_RATE   AS Gruppe_DRI_Rating, 
           gidet.GKSV_RATE   AS Gruppe_KSV_Rating,
           gricos.LMIT_RICOS AS Gruppe_RICOS,
           grisk.GKVS_HRISK  AS GKVS_HRISK
     FROM (SELECT /*+LEADING(gprdet grp gext) INDEX(gprdet G_GROUPINDIVDET_RFTRPE_IDX)*/
                   gprdet.REF1 AS REFINDIVIDU,
                   grp.REFGROUPE,
                   CASE WHEN grp.DTDEACT_DT IS NULL THEN gext.REFEXT ELSE NULL END AS GNUMBER,
                   CASE WHEN grp.DTDEACT_DT IS NULL THEN grp.NOM ELSE NULL END AS GNOM
              FROM G_GROUPINDIVDET gprdet,
                   G_GROUPINDIV grp,
                   G_GROUP_REFEXT gext
             WHERE 1=1
               AND gprdet.TYPE ='LIST'
               AND gprdet.REFGROUPE = grp.REFGROUPE
               AND grp.TYPE ='DEBITEURS'
               AND gext.REFGROUPE = grp.REFGROUPE
               AND gext.REFEXT_TYPE = 'OeNB group number' 
               AND grp.DTDEACT_DT IS NULL
             )gnumber,
            (SELECT /*+ no_merge no_push_pred*/
                    lea.REFINDIVIDU AS LEADER,
                    lea.REFGROUPE,
                    gprdet.REF1 AS DEBROR,
                    MAX(DRI_RATE) AS GDRI_RATE,
                    MAX(KSV_RATE) AS GKSV_RATE
               FROM(SELECT gi.REFINDIVIDU,grl.REFGROUPE,
                           CASE WHEN gi.STR1 ='DRI' THEN gi.STR2 ELSE NULL END as DRI_RATE, 
                           CASE WHEN gi.STR1 ='KSV' AND TRUNC(sysdate) BETWEEN gi.dt09_dt AND NVL(gi.dt07_dt, SYSDATE) 
                                THEN gi.STR2 ELSE NULL END as KSV_RATE,
                           ROW_NUMBER() OVER (PARTITION BY gi.REFINDIVIDU,gi.STR1  ORDER BY gi.IMX_UN_ID DESC) rnk
                      FROM G_GROUPINDIV grl,
                           G_INDIVPARAM gi
                    WHERE grl.MAITRE = gi.REFINDIVIDU -- from leader
                      AND grL.type = 'DEBITEURS'
                      AND gi.TYPE IN ('COTE FACTOR','COTE FACTOR HIS')
                      AND gi.STR1 IN ('DRI','KSV')
                    )lea,
                    G_GROUPINDIVDET gprdet 
              WHERE lea.rnk =1
                AND lea.REFGROUPE = gprdet.REFGROUPE
                AND gprdet.TYPE ='LIST'
              GROUP BY lea.REFINDIVIDU,lea.REFGROUPE,gprdet.REF1
            )gidet,
            (SELECT /*+ no_merge no_push_pred*/
                     hrisk.REFGROUPE, hrisk.DEBTOR,gi.GKVS_HRISK
                FROM (SELECT gi.REFINDIVIDU,
                             gi.STR2 as GKVS_HRISK,
                             ROW_NUMBER() OVER (PARTITION BY gi.REFINDIVIDU,gi.STR1  ORDER BY gi.IMX_UN_ID DESC) rnk
                        FROM G_INDIVPARAM gi
                       WHERE 1=1
                         AND gi.TYPE IN ('COTE FACTOR','COTE FACTOR HIS')
                         AND gi.STR1 = 'KSV'
                     ) gi,
                    (SELECT /*+ no_merge no_push_pred*/
                             REFGROUPE,DEBTOR,
                             ROW_NUMBER() OVER (PARTITION BY REFGROUPE ORDER BY RISK_EUR DESC) rnk
                        FROM(SELECT /*+ no_merge no_push_pred LEADING(compte)*/
                                      gprdet.REFGROUPE,
                                      compte.DEBTOR,
                                      SUM(CASE WHEN substr(dbop.compte, 1, 1) = '1' 
                                               THEN DECODE(dbop.sens, 'd', dbop.montant_mvt, dbop.montant_mvt * -1) 
                                      ELSE NULL END) RISK_EUR
                                 FROM NAM_ECR_COMPTA_BAK dbop,
                                      AD_ACCOUNT_DEBTOR_CLIENT compte,
                                      G_GROUPINDIVDET gprdet,
                                      G_GROUPINDIV gpr
                                WHERE dbop.DTJOUR = TRUNC(sysdate)
                                  AND dbop.refdoss is not null
                                  AND dbop.codeoper IN ('DB_CLDB_COV', 'DB_CLDB_PRS') 
                                  AND dbop.REFDOSS = compte.REFDOSS
                                  AND compte.DEBTOR = gprdet.REF1
                                  AND gprdet.TYPE ='LIST'
                                  AND gpr.REFGROUPE = gprdet.REFGROUPE
                                  AND gpr.type = 'DEBITEURS'
                                GROUP BY gprdet.REFGROUPE,compte.DEBTOR
                             )
                      )hrisk
              WHERE 1=1
                AND hrisk.DEBTOR = gi.REFINDIVIDU
                AND hrisk.RNK =1
                AND gi.RNK =1
              )grisk,
              (SELECT /*+ no_merge no_push_pred INDEX(B G_GROUPINDIVDET_RFTRPE_IDX)*/
                    B.REFGROUPE,
                    SUM(B.MT01) LMIT_RICOS
               FROM G_GROUPINDIVDET B
              WHERE 1=1
                AND B.TYPE ='DEBTOR_GRP_DGGFL_LIM_PARAM'
              GROUP BY B.REFGROUPE
            )gricos
       WHERE gnumber.REFGROUPE = gidet.REFGROUPE(+)
         AND gnumber.REFINDIVIDU =  gidet.DEBROR(+)
         AND gnumber.REFGROUPE = grisk.REFGROUPE(+)   
         AND gnumber.REFGROUPE = gricos.REFGROUPE(+)
     )grpnew,
     t_intervenants tcl,
     --IMBDEV-10690
    (SELECT /*+ no_merge no_push_pred LEADING(cofact b) FULL(b) USE_HASH(b) FULL(c) USE_HASH(c)*/
           REFINDIVIDU                           as REFINDIVIDU,
           EB_Rating                             as EB_Rating,
           EBS_Rating_Datum                      as EBS_Rating_Datum
      FROM (SELECT /*+INDEX(a G_INDPAR_TYPSTR1_IDX)*/
                   a.REFINDIVIDU,a.STR1,
                   (CASE WHEN a.STR1 ='DRI' THEN a.STR2 ELSE NULL END) as EB_Rating,
                   (CASE WHEN a.STR1 ='DRI' THEN a.DT01_DT ELSE NULL END) as EBS_Rating_Datum,       
                   ROW_NUMBER() OVER(PARTITION BY a.REFINDIVIDU,STR1 ORDER BY a.IMX_UN_ID DESC) rnk
              FROM G_INDIVPARAM a               
             WHERE a.TYPE IN ('COTE FACTOR','COTE FACTOR HIS')
               AND a.STR1 IN ('DRI')   
            )cofact
       WHERE cofact.rnk =1      
      )ebdri,
     (SELECT /*+ no_merge no_push_pred */ origine,taux, CRDATE4I_DT
         FROM (SELECT /*+ INDEX_DESC(T T_DEVISE_IX3)*/ 
                    origine,destination,NVL(taux,1.0)taux,TRUNC(CRDATE4I_DT) CRDATE4I_DT,
                    row_number() over (partition by origine order by DTDEBUT_DT desc) rnk
                FROM t_devise T
               WHERE T.dtdebut_dt <= sysdate
                 AND T.TYPE = 'MR'
                 AND T.place = 'AUT'
                 AND NVL( T.Destination, 'EUR' ) = 'EUR'
             )
        WHERE rnk =1
      )ex_rate
WHERE cl.CLIENT_REFINDIVIDU = cl_acc.CLIENT
  AND tcl.refdoss(+) = cl_acc.REFDOSS
  AND tcl.refindividu(+) = cl_acc.CLIENT
  AND tcl.reftype(+) = 'CL'
  AND dec.refdoss = cl_acc.REFDOSS
  AND dec.typpiece = 'SOUS-CONTRAT'
  AND compta_bak.REFDOSS(+) = cl_acc.REFDOSS
  AND cl_porf.CL_ACCOUNT_CASE = cl_acc.REFDOSS
  AND ctr_case.REFDOSS = cl_acc.REFLOT
  AND ctr.REFDOSS = ctr_case.REFDOSS
  AND ctr.TYPPIECE = 'CONTRAT'
  AND ext.rnk(+) =1
  AND ext.REFINDIVIDU(+) = cl_acc.CLIENT
  AND recei.REFINDIVIDU(+) = cl_acc.CLIENT
  AND ins_quality.REFDOSS(+) = ctr_case.REFDOSS
  AND ebv.REFINDIVIDU(+) = cl_acc.CLIENT
  AND Risk_EUR.decompte_refdoss(+) = cl_acc.REFDOSS
  AND lov_cnt.TYPE(+) ='CONTRTYP'
  AND lov_cnt.ABREV(+) = ctr.GPIOBJET
  --
  AND t1.REFINDIVIDU(+) = cl.CLIENT_REFINDIVIDU
  AND grpnew.REFINDIVIDU(+) = cl.CLIENT_REFINDIVIDU
  AND pd_lgd.REFINDIVIDU(+) = cl_acc.CLIENT
  AND ksv_ebs_rate.REFINDIVIDU(+) = cl.CLIENT_REFINDIVIDU
  AND gi.REFINDIVIDU(+) = cl.CLIENT_REFINDIVIDU
  AND v.TYPE(+) IN ('T.NAF', 'DRI_INDUSTRY', 'DRI_NACE_CODE')
  AND v.ABREV(+) = COALESCE(CASE WHEN NVL(gi.DRI_INDUSTRY_CODE,'_UNBEK') != '_UNBEK' THEN gi.DRI_INDUSTRY_CODE ELSE NULL END,
                             CASE WHEN NVL(gi.STR44,'_UNBEK') NOT IN ('_UNBEKANNT','_UNBEK') THEN gi.STR44 ELSE NULL END,cl.STR15) 
  AND ebdri.REFINDIVIDU(+) = cl.CLIENT_REFINDIVIDU
  AND ex_rate.ORIGINE(+) =  cl_acc.DEVISE                            
;
/********************************OLD SQL*******************************************/
/********************************OLD Metrics***************************************/
/*
Plan hash value: 559636452
---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                                    | Name                          | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  | Writes |
---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                                             |                               |      1 |        |  1695M(100)|      0 |00:00:00.01 |       0 |      0 |      0 |
|   1 |  UNION-ALL                                                   |                               |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
|   2 |   HASH UNIQUE                                                |                               |      1 |    194M|  1693M  (7)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*  3 |    HASH JOIN RIGHT OUTER                                     |                               |      1 |    194M|  1342M  (9)|      0 |00:00:00.01 |       0 |      0 |      0 |
|   4 |     VIEW                                                     |                               |      1 |  12481 | 10728   (1)|     32 |00:00:00.08 |   10718 |    153 |      0 |
|*  5 |      VIEW                                                    |                               |      1 |  12481 | 10728   (1)|     32 |00:00:00.08 |   10718 |    153 |      0 |
|*  6 |       WINDOW NOSORT                                          |                               |      1 |  12481 | 10728   (1)|  12510 |00:00:00.07 |   10718 |    153 |      0 |
|*  7 |        TABLE ACCESS BY INDEX ROWID                           | T_DEVISE                      |      1 |  12481 | 10728   (1)|  12510 |00:00:00.07 |   10718 |    153 |      0 |
|*  8 |         INDEX SKIP SCAN DESCENDING                           | T_DEVISE_IX3                  |      1 |  12510 |    34   (3)|  12510 |00:00:00.01 |      42 |     32 |      0 |
|*  9 |     HASH JOIN OUTER                                          |                               |      1 |   9040K|  1342M  (9)|      0 |00:00:00.01 |       0 |      0 |      0 |
|* 10 |      HASH JOIN RIGHT OUTER                                   |                               |      1 |   8342 |  1248M (10)|      0 |00:00:00.01 |       0 |      0 |      0 |
|  11 |       VIEW                                                   |                               |      1 |      2 |   818K  (1)|  47698 |00:00:16.98 |     840K|    163K|  51345 |
|  12 |        VIEW                                                  |                               |      1 |      2 |   818K  (1)|  47698 |00:00:16.98 |     840K|    163K|  51345 |
|  13 |         HASH GROUP BY                                        |                               |      1 |      2 |   818K  (1)|  47698 |00:00:16.97 |     840K|    163K|  51345 |
|  14 |          VIEW                                                |                               |      1 |      2 |   818K  (1)|  63688 |00:00:16.73 |     840K|    161K|  48699 |
|  15 |           SORT UNIQUE                                        |                               |      1 |      2 |   818K  (1)|  63688 |00:00:16.72 |     840K|    161K|  48699 |
|  16 |            UNION-ALL                                         |                               |      1 |        |            |  63689 |00:00:16.58 |     840K|    161K|  48699 |
|* 17 |             HASH JOIN                                        |                               |      1 |      1 |   816K  (1)|  16045 |00:00:12.63 |     818K|    106K|      0 |
|  18 |              JOIN FILTER CREATE                              | :BF0000                       |      1 |      1 |   815K  (1)|  16048 |00:00:12.58 |     814K|    106K|      0 |
|* 19 |               HASH JOIN                                      |                               |      1 |      1 |   815K  (1)|  16048 |00:00:12.58 |     814K|    106K|      0 |
|  20 |                JOIN FILTER CREATE                            | :BF0001                       |      1 |      1 |   815K  (1)|  16048 |00:00:12.51 |     806K|    106K|      0 |
|  21 |                 NESTED LOOPS                                 |                               |      1 |      1 |   815K  (1)|  16048 |00:00:12.50 |     806K|    106K|      0 |
|  22 |                  NESTED LOOPS                                |                               |      1 |      1 |   815K  (1)|  16048 |00:00:12.47 |     790K|    106K|      0 |
|  23 |                   NESTED LOOPS                               |                               |      1 |      1 |   815K  (1)|  16048 |00:00:12.45 |     790K|    106K|      0 |
|  24 |                    NESTED LOOPS                              |                               |      1 |  20534 |   753K  (1)|  16108 |00:00:12.37 |     784K|    106K|      0 |
|* 25 |                     TABLE ACCESS BY INDEX ROWID BATCHED      | G_PIECE                       |      1 |    169K| 92748   (1)|    240K|00:00:10.56 |     130K|    104K|      0 |
|* 26 |                      INDEX RANGE SCAN                        | TYPPIECE_LASTLOAD_IND         |      1 |    240K|  1009   (2)|    240K|00:00:00.53 |     882 |    882 |      0 |
|* 27 |                     TABLE ACCESS BY INDEX ROWID BATCHED      | G_PIECEDET                    |    240K|      1 |     4   (0)|  16108 |00:00:01.76 |     654K|   2169 |      0 |
|* 28 |                      INDEX RANGE SCAN                        | GPDET_TYP_REF_IDX             |    240K|      1 |     3   (0)|  16279 |00:00:01.01 |     638K|    764 |      0 |
|* 29 |                    TABLE ACCESS BY INDEX ROWID BATCHED       | G_PIECE                       |  16108 |      1 |     3   (0)|  16048 |00:00:00.07 |    6164 |     45 |      0 |
|* 30 |                     INDEX RANGE SCAN                         | G_PIECE_TYPE_REFPIECE_INX     |  16108 |      1 |     2   (0)|  16048 |00:00:00.03 |     257 |      4 |      0 |
|* 31 |                   INDEX UNIQUE SCAN                          | AD_CASE_POLICE_PK             |  16048 |      1 |     0   (0)|  16048 |00:00:00.01 |       4 |      1 |      0 |
|  32 |                  TABLE ACCESS BY INDEX ROWID                 | AD_CASE_POLICE                |  16048 |      1 |     1   (0)|  16048 |00:00:00.02 |   16048 |      3 |      0 |
|  33 |                JOIN FILTER USE                               | :BF0001                       |      1 |    240K|   280  (15)|  63395 |00:00:00.04 |    7517 |      0 |      0 |
|* 34 |                 TABLE ACCESS STORAGE FULL                    | AD_ACCOUNT_DEBTOR_CLIENT      |      1 |    240K|   280  (15)|  63395 |00:00:00.04 |    7517 |      0 |      0 |
|  35 |              JOIN FILTER USE                                 | :BF0000                       |      1 |    148K|   161  (10)|  40484 |00:00:00.03 |    4536 |      0 |      0 |
|* 36 |               TABLE ACCESS STORAGE FULL                      | AD_DEBTORS                    |      1 |    148K|   161  (10)|  40484 |00:00:00.03 |    4536 |      0 |      0 |
|* 37 |             HASH JOIN                                        |                               |      1 |      1 |  2641   (3)|  47644 |00:00:03.93 |   22252 |  54260 |  48699 |
|  38 |              JOIN FILTER CREATE                              | :BF0002                       |      1 |      1 |  2477   (2)|   3285K|00:00:01.26 |   17716 |   5561 |      0 |
|* 39 |               HASH JOIN                                      |                               |      1 |      1 |  2477   (2)|   3285K|00:00:01.09 |   17716 |   5561 |      0 |
|  40 |                JOIN FILTER CREATE                            | :BF0003                       |      1 |      1 |  2293   (1)|   7957 |00:00:00.44 |   13054 |    939 |      0 |
|  41 |                 NESTED LOOPS                                 |                               |      1 |      1 |  2293   (1)|   7957 |00:00:00.44 |   13054 |    939 |      0 |
|  42 |                  NESTED LOOPS                                |                               |      1 |      1 |  2293   (1)|   7957 |00:00:00.43 |    5097 |    939 |      0 |
|  43 |                   NESTED LOOPS                               |                               |      1 |      1 |  2292   (1)|   7957 |00:00:00.42 |    5093 |    939 |      0 |
|  44 |                    NESTED LOOPS                              |                               |      1 |    308 |  1366   (1)|   7957 |00:00:00.40 |    2802 |    916 |      0 |
|* 45 |                     TABLE ACCESS BY INDEX ROWID BATCHED      | G_PIECE                       |      1 |    307 |   170   (0)|    436 |00:00:00.01 |     432 |      3 |      0 |
|* 46 |                      INDEX RANGE SCAN                        | TYPPIECE_LASTLOAD_IND         |      1 |    436 |     4   (0)|    436 |00:00:00.01 |       5 |      3 |      0 |
|* 47 |                     TABLE ACCESS BY INDEX ROWID BATCHED      | G_PIECEDET                    |    436 |      1 |     4   (0)|   7957 |00:00:00.39 |    2370 |    913 |      0 |
|* 48 |                      INDEX RANGE SCAN                        | GPDET_TYP_REF_IDX             |    436 |      1 |     3   (0)|   8267 |00:00:00.02 |    1322 |     51 |      0 |
|* 49 |                    TABLE ACCESS BY INDEX ROWID BATCHED       | G_PIECE                       |   7957 |      1 |     3   (0)|   7957 |00:00:00.03 |    2291 |     23 |      0 |
|* 50 |                     INDEX RANGE SCAN                         | G_PIECE_TYPE_REFPIECE_INX     |   7957 |      1 |     2   (0)|   7957 |00:00:00.01 |     356 |      0 |      0 |
|* 51 |                   INDEX UNIQUE SCAN                          | AD_CASE_POLICE_PK             |   7957 |      1 |     0   (0)|   7957 |00:00:00.01 |       4 |      0 |      0 |
|  52 |                  TABLE ACCESS BY INDEX ROWID                 | AD_CASE_POLICE                |   7957 |      1 |     1   (0)|   7957 |00:00:00.01 |    7957 |      0 |      0 |
|  53 |                JOIN FILTER USE                               | :BF0003                       |      1 |    240K|   179  (17)|  47722 |00:00:00.23 |    4662 |   4622 |      0 |
|* 54 |                 TABLE ACCESS STORAGE FULL                    | AD_CASES                      |      1 |    240K|   179  (17)|  47722 |00:00:00.23 |    4662 |   4622 |      0 |
|  55 |              JOIN FILTER USE                                 | :BF0002                       |      1 |    148K|   161  (10)|    148K|00:00:00.04 |    4536 |      0 |      0 |
|* 56 |               TABLE ACCESS STORAGE FULL                      | AD_DEBTORS                    |      1 |    148K|   161  (10)|    148K|00:00:00.03 |    4536 |      0 |      0 |
|* 57 |       HASH JOIN OUTER                                        |                               |      1 |   8342 |  1247M (10)|      0 |00:00:00.01 |       0 |      0 |      0 |
|  58 |        JOIN FILTER CREATE                                    | :BF0004                       |      1 |   3431 |  1247M (10)|      0 |00:00:00.01 |       0 |      0 |      0 |
|* 59 |         HASH JOIN OUTER                                      |                               |      1 |   3431 |  1247M (10)|      0 |00:00:00.01 |       0 |      0 |      0 |
|* 60 |          HASH JOIN RIGHT OUTER                               |                               |      1 |   1301 |  1247M (10)|      0 |00:00:00.01 |       0 |      0 |      0 |
|  61 |           VIEW                                               |                               |      1 |    147K| 26252   (1)|    147K|00:00:05.50 |   31751 |  27818 |      0 |
|* 62 |            VIEW                                              |                               |      1 |    147K| 26252   (1)|    147K|00:00:05.50 |   31751 |  27818 |      0 |
|* 63 |             WINDOW SORT PUSHED RANK                          |                               |      1 |    147K| 26252   (1)|    147K|00:00:05.50 |   31751 |  27818 |      0 |
|  64 |              TABLE ACCESS BY INDEX ROWID BATCHED             | G_INDIVPARAM                  |      1 |    147K| 25247   (1)|    147K|00:00:05.09 |   31751 |  27818 |      0 |
|* 65 |               INDEX RANGE SCAN                               | G_INDPAR_TYPSTR1_IDX          |      1 |    147K|   634   (2)|    147K|00:00:00.33 |     690 |    690 |      0 |
|* 66 |           HASH JOIN OUTER                                    |                               |      1 |    866 |  1247M (10)|      0 |00:00:00.01 |       0 |      0 |      0 |
|* 67 |            HASH JOIN OUTER                                   |                               |      1 |    629 |  1247M (10)|      0 |00:00:00.01 |       0 |      0 |      0 |
|  68 |             JOIN FILTER CREATE                               | :BF0005                       |      1 |    629 |  1246M (10)|      0 |00:00:00.01 |       0 |      0 |      0 |
|* 69 |              HASH JOIN OUTER                                 |                               |      1 |    629 |  1246M (10)|      0 |00:00:00.01 |       0 |      0 |      0 |
|  70 |               JOIN FILTER CREATE                             | :BF0006                       |      1 |    629 |  1246M (10)|      0 |00:00:00.01 |       0 |      0 |      0 |
|* 71 |                HASH JOIN OUTER                               |                               |      1 |    629 |  1246M (10)|      0 |00:00:00.01 |       0 |      0 |      0 |
|* 72 |                 HASH JOIN                                    |                               |      1 |    428 |  1246M (10)|      0 |00:00:00.01 |       0 |      0 |      0 |
|  73 |                  JOIN FILTER CREATE                          | :BF0007                       |      1 |    668 |  1246M (10)|      0 |00:00:00.01 |       0 |      0 |      0 |
|* 74 |                   HASH JOIN RIGHT OUTER                      |                               |      1 |    668 |  1246M (10)|      0 |00:00:00.01 |       0 |      0 |      0 |
|* 75 |                    VIEW                                      |                               |      1 |   4007 | 10065   (1)|    120 |00:00:02.69 |   18674 |  12150 |      0 |
|* 76 |                     WINDOW SORT PUSHED RANK                  |                               |      1 |   4007 | 10065   (1)|    120 |00:00:02.69 |   18674 |  12150 |      0 |
|* 77 |                      HASH JOIN                               |                               |      1 |   4007 | 10064   (1)|   1237 |00:00:02.69 |   18674 |  12150 |      0 |
|  78 |                       TABLE ACCESS BY INDEX ROWID BATCHED    | G_PIECEDET                    |      1 |  20885 | 10050   (1)|  27893 |00:00:02.66 |   18580 |  12144 |      0 |
|* 79 |                        INDEX RANGE SCAN                      | G_PIECEDET_STR1_IDX           |      1 |  20885 |   157   (2)|  27893 |00:00:00.10 |     147 |    147 |      0 |
|  80 |                       TABLE ACCESS BY INDEX ROWID BATCHED    | AD_CASES                      |      1 |    436 |    13   (0)|    436 |00:00:00.01 |      94 |      6 |      0 |
|* 81 |                        INDEX RANGE SCAN                      | AD_CASES_CATEGDOSS_IDX        |      1 |    436 |     4   (0)|    436 |00:00:00.01 |       6 |      6 |      0 |
|* 82 |                    HASH JOIN OUTER                           |                               |      1 |    413 |  1246M (10)|      0 |00:00:00.01 |       0 |      0 |      0 |
|  83 |                     JOIN FILTER CREATE                       | :BF0008                       |      1 |    413 |   127K  (3)|      0 |00:00:00.01 |       0 |      0 |      0 |
|* 84 |                      HASH JOIN OUTER                         |                               |      1 |    413 |   127K  (3)|      0 |00:00:00.01 |       0 |      0 |      0 |
|  85 |                       JOIN FILTER CREATE                     | :BF0009                       |      1 |    413 |   123K  (2)|      0 |00:00:00.01 |       0 |      0 |      0 |
|* 86 |                        HASH JOIN OUTER                       |                               |      1 |    413 |   123K  (2)|      0 |00:00:00.01 |       0 |      0 |      0 |
|  87 |                         JOIN FILTER CREATE                   | :BF0010                       |      1 |    413 |   115K  (2)|      0 |00:00:00.01 |       0 |      0 |      0 |
|* 88 |                          HASH JOIN OUTER                     |                               |      1 |    413 |   115K  (2)|      0 |00:00:00.01 |       0 |      0 |      0 |
|* 89 |                           HASH JOIN OUTER                    |                               |      1 |    411 | 63182   (4)|      0 |00:00:00.01 |       0 |      0 |      0 |
|  90 |                            JOIN FILTER CREATE                | :BF0011                       |      1 |    411 | 63164   (4)|      0 |00:00:00.01 |       0 |      0 |      0 |
|* 91 |                             HASH JOIN RIGHT OUTER            |                               |      1 |    411 | 63164   (4)|      0 |00:00:00.01 |       0 |      0 |      0 |
|  92 |                              VIEW                            |                               |      1 |   4714 |  3783  (22)|  28948 |00:00:00.37 |   94509 |  94468 |      0 |
|  93 |                               HASH GROUP BY                  |                               |      1 |   4714 |  3783  (22)|  28948 |00:00:00.37 |   94509 |  94468 |      0 |
|* 94 |                                HASH JOIN                     |                               |      1 |   4714 |  3782  (22)|  28948 |00:00:00.36 |   94509 |  94468 |      0 |
|  95 |                                 JOIN FILTER CREATE           | :BF0012                       |      1 |  18069 |  3687  (22)|  28949 |00:00:00.22 |   92414 |  92409 |      0 |
|* 96 | L                                MAT_VIEW ACCESS STORAGE FUL | AD_REQUEST_LIMIT_MVIEW        |      1 |  18069 |  3687  (22)|  28949 |00:00:00.22 |   92414 |  92409 |      0 |
|  97 |                                 JOIN FILTER USE              | :BF0012                       |      1 |    332K|    87  (22)|  45136 |00:00:00.12 |    2066 |   2059 |      0 |
|* 98 |                                  TABLE ACCESS STORAGE FULL   | AD_LIMITS_CONSUMATION         |      1 |    332K|    87  (22)|  45136 |00:00:00.12 |    2066 |   2059 |      0 |
|* 99 |                              HASH JOIN RIGHT OUTER           |                               |      1 |    411 | 59381   (3)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*100 |                               VIEW                           |                               |      1 |     16 | 13024   (7)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*101 |                                WINDOW SORT PUSHED RANK       |                               |      1 |     16 | 13024   (7)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 102 |                                 NESTED LOOPS                 |                               |      1 |     16 | 13023   (7)|   6331 |00:01:31.61 |      19M|   9194 |      0 |
|*103 |  BATCHED                         TABLE ACCESS BY INDEX ROWID | G_PIECEDET                    |      1 |     83 |  8640   (1)|  13960 |00:00:04.06 |   10295 |   7847 |      0 |
|*104 |                                   INDEX RANGE SCAN           | G_PIECEDET_STR1_IDX           |      1 |  17953 |   135   (1)|  21908 |00:00:00.08 |      99 |     98 |      0 |
|*105 | N                                INDEX STORAGE FAST FULL SCA | AD_CASES_IDX                  |  13960 |      1 |    53  (21)|   6331 |00:02:47.85 |      19M|   1355 |      0 |
|*106 |                               HASH JOIN RIGHT OUTER          |                               |      0 |    410 | 46357   (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*107 |                                VIEW                          |                               |      0 |     83 |  8807   (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*108 |                                 WINDOW SORT PUSHED RANK      |                               |      0 |     83 |  8807   (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 109 |                                  NESTED LOOPS                |                               |      0 |     83 |  8806   (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 110 |                                   NESTED LOOPS               |                               |      0 |     83 |  8806   (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*111 | ID BATCHED                         TABLE ACCESS BY INDEX ROW | G_PIECEDET                    |      0 |     83 |  8640   (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*112 |                                     INDEX RANGE SCAN         | G_PIECEDET_STR1_IDX           |      0 |  17953 |   135   (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*113 |                                    INDEX UNIQUE SCAN         | AD_CASES_PK                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*114 | D                                 TABLE ACCESS BY INDEX ROWI | AD_CASES                      |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*115 |                                HASH JOIN RIGHT OUTER         |                               |      0 |    410 | 37549   (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 116 |                                 VIEW                         |                               |      0 |      8 |     3  (34)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 117 |                                  HASH GROUP BY               |                               |      0 |      8 |     3  (34)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 118 |                                   TABLE ACCESS STORAGE FULL  | T_EXTERN_CALC_PROV            |      0 |     81 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*119 |                                 HASH JOIN OUTER              |                               |      0 |    410 | 37546   (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*120 |                                  HASH JOIN RIGHT OUTER       |                               |      0 |    410 |  2486  (10)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 121 |                                   TABLE ACCESS STORAGE FULL  | G_RECEIVERSHIP                |      0 |   1954 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*122 |                                   HASH JOIN RIGHT OUTER      |                               |      0 |    410 |  2484  (10)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*123 |                                    TABLE ACCESS STORAGE FULL | AD_CLIENT_STATEMENT_HISTORY   |      0 |     70 |   120  (20)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*124 |                                    HASH JOIN RIGHT OUTER     |                               |      0 |    407 |  2363  (10)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*125 | L                                   TABLE ACCESS STORAGE FUL | V_DOMAINE                     |      0 |   3096 |    67  (11)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*126 |                                     HASH JOIN                |                               |      0 |    407 |  2297  (10)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 127 |  FULL                                MAT_VIEW ACCESS STORAGE | AD_ACCOUNT_CLIENT_MVIEW       |      0 |    489 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*128 |                                      HASH JOIN               |                               |      0 |    396 |  2294  (10)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*129 |                                       HASH JOIN              |                               |      0 |    396 |  2292  (10)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 130 |                                        JOIN FILTER CREATE    | :BF0013                       |      0 |    396 |  1842   (5)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*131 |                                         HASH JOIN            |                               |      0 |    396 |  1842   (5)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 132 |                                          JOIN FILTER CREATE  | :BF0014                       |      0 |    396 |  1671   (4)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*133 |                                           HASH JOIN          |                               |      0 |    396 |  1671   (4)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 134 | E                                          JOIN FILTER CREAT | :BF0015                       |      0 |      1 |  1378   (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*135 |                                             HASH JOIN OUTER  |                               |      0 |      1 |  1378   (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 136 | ATE                                          JOIN FILTER CRE | :BF0016                       |      0 |      1 |  1313   (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 137 |                                               NESTED LOOPS   |                               |      0 |      1 |  1313   (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 138 |                                                NESTED LOOPS  |                               |      0 |    436 |  1313   (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 139 |  STORAGE FULL                                   TABLE ACCESS | AD_CASE_CONTRAT               |      0 |    436 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*140 | SCAN                                            INDEX RANGE  | G_PIECE_TYPE_REFDOSS_IDX      |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 141 | BY INDEX ROWID                                 TABLE ACCESS  | G_PIECE                       |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 142 |                                              JOIN FILTER USE | :BF0016                       |      0 |     13 |    65   (8)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*143 | TORAGE FULL                                   TABLE ACCESS S | V_DOMAINE                     |      0 |     13 |    65   (8)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 144 |                                            JOIN FILTER USE   | :BF0015                       |      0 |    240K|   288  (17)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*145 | RAGE FULL                                   TABLE ACCESS STO | AD_ACCOUNT_DEBTOR_CLIENT      |      0 |    240K|   288  (17)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 146 |                                          JOIN FILTER USE     | :BF0014                       |      0 |    148K|   167  (14)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*147 | GE FULL                                   TABLE ACCESS STORA | AD_DEBTORS                    |      0 |    148K|   167  (14)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 148 |                                        JOIN FILTER USE       | :BF0013                       |      0 |    156K|   447  (29)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*149 |  FULL                                   TABLE ACCESS STORAGE | G_INDIVIDU                    |      0 |    156K|   447  (29)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 150 | ULL                                   TABLE ACCESS STORAGE F | AD_CLIENTS                    |      0 |    423 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 151 |                                  VIEW                        |                               |      0 |   9361 | 35060   (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*152 |                                   VIEW                       |                               |      0 |   9361 | 35060   (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*153 |                                    WINDOW SORT PUSHED RANK   |                               |      0 |   9361 | 35060   (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*154 | WID BATCHED                         TABLE ACCESS BY INDEX RO | AD_LIMITS                     |      0 |   9361 | 35058   (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*155 |                                      INDEX RANGE SCAN        | AD_LIMIT_DEBTOR_IND           |      0 |  62418 |   231   (2)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 156 |                            VIEW                              |                               |      0 |   7307 |    17  (36)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 157 |                             HASH UNIQUE                      |                               |      0 |   7307 |    17  (36)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 158 |                              JOIN FILTER USE                 | :BF0011                       |      0 |   8114 |    15  (27)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*159 |                               TABLE ACCESS STORAGE FULL      | G_GROUPINDIVDET               |      0 |   8114 |    15  (27)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*160 |                           VIEW                               |                               |      0 |  20865 | 52105   (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*161 |                            WINDOW SORT PUSHED RANK           |                               |      0 |  20865 | 52105   (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 162 |                             NESTED LOOPS                     |                               |      0 |  20865 | 51892   (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 163 |                              NESTED LOOPS                    |                               |      0 |  20885 | 51892   (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 164 | TCHED                         TABLE ACCESS BY INDEX ROWID BA | G_PIECEDET                    |      0 |  20885 | 10050   (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*165 |                                INDEX RANGE SCAN              | G_PIECEDET_STR1_IDX           |      0 |  20885 |   157   (2)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*166 |                               INDEX UNIQUE SCAN              | AD_CASES_PK                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*167 |                              TABLE ACCESS BY INDEX ROWID     | AD_CASES                      |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 168 |                         VIEW                                 |                               |      0 |  52278 |  7781   (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 169 |                          SORT GROUP BY                       |                               |      0 |  52278 |  7781   (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*170 |                           VIEW                               |                               |      0 |  58912 |  7781   (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 171 |                            JOIN FILTER USE                   | :BF0010                       |      0 |  58912 |  7781   (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*172 |                             WINDOW SORT PUSHED RANK          |                               |      0 |  58912 |  7781   (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*173 | CHED                         TABLE ACCESS BY INDEX ROWID BAT | G_PIECEDET                    |      0 |  58912 |  7346   (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*174 |                               INDEX RANGE SCAN               | G_PIECEDET_TYPE_LASTLOAD_IDX  |      0 |  70276 |   353   (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 175 |                       VIEW                                   |                               |      0 |    138K|  4390  (19)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 176 |                        HASH GROUP BY                         |                               |      0 |    138K|  4390  (19)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 177 |                         JOIN FILTER USE                      | :BF0009                       |      0 |    320K|  3666  (21)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*178 |                          MAT_VIEW ACCESS STORAGE FULL        | AD_REQUEST_LIMIT_MVIEW        |      0 |    320K|  3666  (21)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 179 |                     VIEW                                     |                               |      0 |    151K|  1246M (10)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 180 |                      SORT GROUP BY                           |                               |      0 |    151K|  1246M (10)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 181 |                       JOIN FILTER USE                        | :BF0008                       |      0 |    254G|    11M (46)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*182 |                        HASH JOIN OUTER                       |                               |      0 |    254G|    11M (46)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*183 |                         TABLE ACCESS STORAGE FULL            | NAM_ECR_COMPTA_BAK            |      0 |    107M|   269K (23)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 184 |                         VIEW                                 |                               |      0 |     42M|  6332K  (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*185 |                          VIEW                                |                               |      0 |     42M|  6332K  (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*186 |                           WINDOW NOSORT                      |                               |      0 |     42M|  6332K  (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 187 |                            SORT GROUP BY                     |                               |      0 |     42M|  6332K  (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*188 |                             TABLE ACCESS BY INDEX ROWID      | NAM_ECR_COMPTA_BAK            |      0 |     42M|  5819K  (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*189 |                              INDEX RANGE SCAN                | NAM_ECR_COMPTA_BAK_DTJOUR_IDX |      0 |     43M|   559K  (2)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 190 |                  VIEW                                        |                               |      0 |    154K|   152K  (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 191 |                   HASH GROUP BY                              |                               |      0 |    154K|   152K  (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 192 |                    JOIN FILTER USE                           | :BF0007                       |      0 |    154K|   151K  (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*193 |                     TABLE ACCESS BY INDEX ROWID BATCHED      | AD_FINELEM                    |      0 |    154K|   151K  (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*194 |                      INDEX RANGE SCAN                        | AD_FINELEM_PK                 |      0 |    160K|   207   (4)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*195 |                 VIEW                                         |                               |      0 |    128K|  2511  (10)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*196 |                  WINDOW SORT PUSHED RANK                     |                               |      0 |    128K|  2511  (10)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*197 |                   TABLE ACCESS STORAGE FULL                  | UDF_INDIV                     |      0 |    128K|  1384  (15)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 198 |               VIEW                                           |                               |      0 |    113K|  1868   (6)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 199 |                HASH GROUP BY                                 |                               |      0 |    113K|  1868   (6)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*200 |                 VIEW                                         |                               |      0 |    184K|  1868   (6)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 201 |                  JOIN FILTER USE                             | :BF0006                       |      0 |    184K|  1868   (6)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*202 |                   WINDOW SORT PUSHED RANK                    |                               |      0 |    184K|  1868   (6)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*203 |                    TABLE ACCESS STORAGE FULL                 | T_INDIVIDU                    |      0 |    184K|   458  (15)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 204 |             VIEW                                             |                               |      0 |    139K|   149K  (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 205 |              HASH GROUP BY                                   |                               |      0 |    139K|   149K  (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*206 |               VIEW                                           |                               |      0 |    308K|   149K  (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 207 |                JOIN FILTER USE                               | :BF0005                       |      0 |    308K|   149K  (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*208 |                 WINDOW SORT PUSHED RANK                      |                               |      0 |    308K|   149K  (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 209 |                  INLIST ITERATOR                             |                               |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
|*210 |                   TABLE ACCESS BY INDEX ROWID BATCHED        | G_INDIVPARAM                  |      0 |    308K|   146K  (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*211 |                    INDEX RANGE SCAN                          | G_INDPAR_TYPSTR1_IDX          |      0 |    861K|  3328   (2)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 212 |            VIEW                                              |                               |      0 |    156K|  4612  (22)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*213 |             VIEW                                             |                               |      0 |    156K|  4612  (22)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*214 |              WINDOW SORT PUSHED RANK                         |                               |      0 |    156K|  4612  (22)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*215 |               HASH JOIN OUTER                                |                               |      0 |    156K|  2945  (34)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*216 |                TABLE ACCESS STORAGE FULL                     | G_INDIVPARAM                  |      0 |    156K|  2862  (34)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 217 |                MAT_VIEW ACCESS STORAGE FULL                  | AD_KSV_TO_PD_MVIEW            |      0 |    601 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 218 |          VIEW                                                |                               |      0 |    217K|   333K  (8)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*219 |           HASH JOIN OUTER                                    |                               |      0 |    217K|   333K  (8)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*220 |            HASH JOIN RIGHT OUTER                             |                               |      0 |  15608 | 23092   (3)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 221 |             VIEW                                             |                               |      0 |   3176 |  3849   (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 222 |              HASH GROUP BY                                   |                               |      0 |   3176 |  3849   (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 223 |               TABLE ACCESS BY INDEX ROWID BATCHED            | G_GROUPINDIVDET               |      0 |   4736 |  3849   (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*224 |                INDEX FULL SCAN                               | G_GROUPINDIVDET_RFTRPE_IDX    |      0 |   4736 |   108   (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*225 |             HASH JOIN OUTER                                  |                               |      0 |  15608 | 19242   (3)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 226 |              JOIN FILTER CREATE                              | :BF0017                       |      0 |  15608 | 12545   (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*227 |               HASH JOIN                                      |                               |      0 |  15608 | 12545   (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*228 |                TABLE ACCESS STORAGE FULL                     | G_GROUP_REFEXT                |      0 |   4727 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*229 |                HASH JOIN                                     |                               |      0 |  14728 | 12541   (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 230 |                 TABLE ACCESS BY INDEX ROWID BATCHED          | G_GROUPINDIVDET               |      0 |  15736 | 12535   (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*231 |                  INDEX FULL SCAN                             | G_GROUPINDIVDET_RFTRPE_IDX    |      0 |  15736 |   108   (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*232 |                 TABLE ACCESS STORAGE FULL                    | G_GROUPINDIV                  |      0 |   4412 |     5  (20)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 233 |              VIEW                                            |                               |      0 |  67010 |  6695   (8)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 234 |               HASH GROUP BY                                  |                               |      0 |  67010 |  6695   (8)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 235 |                JOIN FILTER USE                               | :BF0017                       |      0 |  67010 |  2637  (18)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*236 |                 HASH JOIN                                    |                               |      0 |  67010 |  2637  (18)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 237 |                  VIEW                                        | VW_GBF_10                     |      0 |  15736 |    10  (40)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 238 |                   HASH GROUP BY                              |                               |      0 |  15736 |    10  (40)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*239 |                    INDEX STORAGE FAST FULL SCAN              | G_GROUPINDIVDET_REF1_IDX      |      0 |  15736 |     7  (15)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*240 |                  VIEW                                        |                               |      0 |  20172 |  2624  (18)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*241 |                   WINDOW SORT PUSHED RANK                    |                               |      0 |  20172 |  2624  (18)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*242 |                    HASH JOIN                                 |                               |      0 |  20172 |  2350  (20)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 243 |                     JOIN FILTER CREATE                       | :BF0018                       |      0 |   4735 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*244 |                      TABLE ACCESS STORAGE FULL               | G_GROUPINDIV                  |      0 |   4735 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 245 |                     JOIN FILTER USE                          | :BF0018                       |      0 |    708K|  2330  (19)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*246 |                      TABLE ACCESS STORAGE FULL               | G_INDIVPARAM                  |      0 |    708K|  2330  (19)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 247 |            VIEW                                              |                               |      0 |  68323 |   310K  (9)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 248 |             NESTED LOOPS                                     |                               |      0 |  68323 |   310K  (9)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*249 |              VIEW                                            |                               |      0 |  25110 |  8697   (2)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*250 |               WINDOW SORT PUSHED RANK                        |                               |      0 |  25110 |  8697   (2)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 251 |                VIEW                                          |                               |      0 |  25110 |  8495   (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 252 |                 HASH GROUP BY                                |                               |      0 |  25110 |  8495   (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*253 |                  HASH JOIN                                   |                               |      0 |  25110 |  8490   (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*254 |                   HASH JOIN                                  |                               |      0 |  21206 |   364  (15)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*255 |                    TABLE ACCESS STORAGE FULL                 | G_GROUPINDIV                  |      0 |   4735 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*256 |                    HASH JOIN                                 |                               |      0 |  21205 |   359  (14)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 257 |                     TABLE ACCESS STORAGE FULL                | AD_ACCOUNT_DEBTOR_CLIENT      |      0 |    240K|   280  (15)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*258 |                     INDEX STORAGE FAST FULL SCAN             | G_GROUPINDIVDET_REF1_IDX      |      0 |  12713 |     7  (15)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 259 |                   INLIST ITERATOR                            |                               |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
|*260 |                    TABLE ACCESS BY INDEX ROWID BATCHED       | NAM_ECR_COMPTA_BAK            |      0 |  62639 |  8124   (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*261 |                     INDEX RANGE SCAN                         | NAM_ECR_COMPTA_BAK_DTJOUR_IDX |      0 |  64589 |   328   (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*262 |              VIEW PUSHED PREDICATE                           |                               |      0 |      1 |    12   (9)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 263 |               WINDOW SORT                                    |                               |      0 |      3 |    12   (9)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*264 |                TABLE ACCESS BY INDEX ROWID BATCHED           | G_INDIVPARAM                  |      0 |      3 |    11   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*265 |                 INDEX RANGE SCAN                             | G_INDIVPARAM_REFIND           |      0 |     10 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 266 |        VIEW                                                  |                               |      0 |    509K| 19990  (10)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 267 |         VIEW                                                 |                               |      0 |    509K| 19990  (10)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 268 |          HASH GROUP BY                                       |                               |      0 |    509K| 19990  (10)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 269 |           VIEW                                               |                               |      0 |    509K| 14768  (12)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 270 |            JOIN FILTER USE                                   | :BF0004                       |      0 |    509K| 14768  (12)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*271 |             HASH JOIN RIGHT OUTER                            |                               |      0 |    509K| 14768  (12)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 272 |              VIEW                                            |                               |      0 |  21372 |    23  (27)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 273 |               HASH GROUP BY                                  |                               |      0 |  21372 |    23  (27)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 274 |                TABLE ACCESS STORAGE FULL                     | G_VENRESTRICTION              |      0 |  21372 |    19  (11)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*275 |              TABLE ACCESS STORAGE FULL                       | AD_FINELEM_3NF                |      0 |    509K| 14734  (12)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 276 |      VIEW                                                    |                               |      0 |    260M|    93M  (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 277 |       HASH GROUP BY                                          |                               |      0 |    260M|    93M  (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*278 |        HASH JOIN RIGHT OUTER                                 |                               |      0 |    260M|  2375K  (2)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*279 |         TABLE ACCESS STORAGE FULL                            | AD_CASES                      |      0 |    240K|   179  (17)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*280 |         HASH JOIN OUTER                                      |                               |      0 |    156M| 56609   (7)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*281 |          VIEW                                                |                               |      0 |    274K| 49093   (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*282 |           WINDOW SORT PUSHED RANK                            |                               |      0 |    274K| 49093   (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 283 |            INLIST ITERATOR                                   |                               |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
| 284 |             TABLE ACCESS BY INDEX ROWID BATCHED              | G_INDIVPARAM                  |      0 |    274K| 46757   (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*285 |              INDEX RANGE SCAN                                | G_INDPAR_TYPSTR1_IDX          |      0 |    274K|  1137   (2)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*286 |          TABLE ACCESS STORAGE FULL                           | AD_CASES                      |      0 |    240K|   178  (17)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*287 |   HASH JOIN RIGHT OUTER                                      |                               |      0 |   2038K|  2349K  (6)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*288 |    TABLE ACCESS STORAGE FULL                                 | V_DOMAINE                     |      0 |   3096 |    67  (11)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*289 |    HASH JOIN RIGHT OUTER                                     |                               |      0 |   2038K|  2349K  (6)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 290 |     VIEW                                                     |                               |      0 |  12481 | 10728   (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*291 |      VIEW                                                    |                               |      0 |  12481 | 10728   (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*292 |       WINDOW NOSORT                                          |                               |      0 |  12481 | 10728   (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*293 |        TABLE ACCESS BY INDEX ROWID                           | T_DEVISE                      |      0 |  12481 | 10728   (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*294 |         INDEX SKIP SCAN DESCENDING                           | T_DEVISE_IX3                  |      0 |  12510 |    34   (3)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*295 |     HASH JOIN OUTER                                          |                               |      0 |   5227 |  2338K  (6)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*296 |      HASH JOIN OUTER                                         |                               |      0 |      8 |   556K  (6)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 297 |       JOIN FILTER CREATE                                     | :BF0019                       |      0 |      1 |   548K  (6)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*298 |        HASH JOIN OUTER                                       |                               |      0 |      1 |   548K  (6)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*299 |         HASH JOIN OUTER                                      |                               |      0 |      1 |   215K  (2)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 300 |          NESTED LOOPS OUTER                                  |                               |      0 |      1 |   166K  (2)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*301 |           HASH JOIN OUTER                                    |                               |      0 |      1 |   166K  (2)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 302 |            JOIN FILTER CREATE                                | :BF0020                       |      0 |      1 | 16501   (8)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*303 |             HASH JOIN OUTER                                  |                               |      0 |      1 | 16501   (8)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 304 |              JOIN FILTER CREATE                              | :BF0021                       |      0 |      1 | 14630   (8)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*305 |               HASH JOIN                                      |                               |      0 |      1 | 14630   (8)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 306 |                JOIN FILTER CREATE                            | :BF0022                       |      0 |      1 | 14628   (8)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*307 |                 HASH JOIN OUTER                              |                               |      0 |      1 | 14628   (8)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 308 |                  JOIN FILTER CREATE                          | :BF0023                       |      0 |      1 | 14625   (8)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*309 |                   HASH JOIN OUTER                            |                               |      0 |      1 | 14625   (8)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*310 |                    HASH JOIN                                 |                               |      0 |      1 | 10010   (2)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*311 |                     HASH JOIN OUTER                          |                               |      0 |      1 |  9897   (2)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 312 |                      JOIN FILTER CREATE                      | :BF0024                       |      0 |      1 |  9832   (2)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*313 |                       HASH JOIN OUTER                        |                               |      0 |      1 |  9832   (2)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 314 |                        JOIN FILTER CREATE                    | :BF0025                       |      0 |      1 |  2050   (3)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*315 |                         HASH JOIN OUTER                      |                               |      0 |      1 |  2050   (3)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 316 |                          JOIN FILTER CREATE                  | :BF0026                       |      0 |      1 |  2047   (3)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*317 |                           HASH JOIN OUTER                    |                               |      0 |      1 |  2047   (3)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*318 |                            HASH JOIN OUTER                   |                               |      0 |      1 |  1723   (4)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 319 |                             JOIN FILTER CREATE               | :BF0027                       |      0 |      1 |  1318   (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 320 |                              NESTED LOOPS                    |                               |      0 |      1 |  1318   (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 321 |                               NESTED LOOPS                   |                               |      0 |      1 |  1318   (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*322 |                                HASH JOIN                     |                               |      0 |      1 |  1315   (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 323 |                                 JOIN FILTER CREATE           | :BF0028                       |      0 |      1 |  1313   (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 324 |                                  NESTED LOOPS                |                               |      0 |      1 |  1313   (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 325 |                                   NESTED LOOPS               |                               |      0 |    436 |  1313   (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 326 |                                    TABLE ACCESS STORAGE FULL | AD_CASE_CONTRAT               |      0 |    436 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*327 |                                    INDEX RANGE SCAN          | G_PIECE_TYPE_REFDOSS_IDX      |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 328 | D                                 TABLE ACCESS BY INDEX ROWI | G_PIECE                       |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 329 |                                 JOIN FILTER USE              | :BF0028                       |      0 |    489 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*330 | L                                MAT_VIEW ACCESS STORAGE FUL | AD_ACCOUNT_CLIENT_MVIEW       |      0 |    489 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*331 |                                INDEX RANGE SCAN              | G_PIECE_TYPE_REFDOSS_IDX      |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 332 |                               TABLE ACCESS BY INDEX ROWID    | G_PIECE                       |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 333 |                             JOIN FILTER USE                  | :BF0027                       |      0 |    241K|   399  (12)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*334 |                              TABLE ACCESS STORAGE FULL       | T_INTERVENANTS                |      0 |    241K|   399  (12)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*335 |                            VIEW                              |                               |      0 |   1878 |   324   (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*336 |                             WINDOW SORT PUSHED RANK          |                               |      0 |   1878 |   324   (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 337 |                              INLIST ITERATOR                 |                               |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
| 338 | TCHED                         TABLE ACCESS BY INDEX ROWID BA | G_INDIVPARAM                  |      0 |   1878 |   323   (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*339 |                                INDEX RANGE SCAN              | G_INDPAR_TYPSTR1_IDX          |      0 |   1878 |    10   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 340 |                          VIEW                                |                               |      0 |      8 |     3  (34)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 341 |                           HASH GROUP BY                      |                               |      0 |      8 |     3  (34)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 342 |                            JOIN FILTER USE                   | :BF0026                       |      0 |     81 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*343 |                             TABLE ACCESS STORAGE FULL        | T_EXTERN_CALC_PROV            |      0 |     81 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 344 |                        VIEW                                  |                               |      0 |  52278 |  7781   (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 345 |                         SORT GROUP BY                        |                               |      0 |  52278 |  7781   (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*346 |                          VIEW                                |                               |      0 |  58912 |  7781   (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 347 |                           JOIN FILTER USE                    | :BF0025                       |      0 |  58912 |  7781   (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*348 |                            WINDOW SORT PUSHED RANK           |                               |      0 |  58912 |  7781   (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*349 | HED                         TABLE ACCESS BY INDEX ROWID BATC | G_PIECEDET                    |      0 |  58912 |  7346   (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*350 |                              INDEX RANGE SCAN                | G_PIECEDET_TYPE_LASTLOAD_IDX  |      0 |  70276 |   353   (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 351 |                      JOIN FILTER USE                         | :BF0024                       |      0 |     13 |    65   (8)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*352 |                       TABLE ACCESS STORAGE FULL              | V_DOMAINE                     |      0 |     13 |    65   (8)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 353 |                     VIEW                                     |                               |      0 |    203 |   113  (15)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*354 |                      VIEW                                    |                               |      0 |    203 |   113  (15)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*355 |                       WINDOW SORT PUSHED RANK                |                               |      0 |    203 |   113  (15)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*356 |                        TABLE ACCESS STORAGE FULL             | AD_CLIENT_STATEMENT_HISTORY   |      0 |    203 |   112  (14)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 357 |                    VIEW                                      |                               |      0 |    156K|  4612  (22)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*358 |                     VIEW                                     |                               |      0 |    156K|  4612  (22)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*359 |                      WINDOW SORT PUSHED RANK                 |                               |      0 |    156K|  4612  (22)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*360 |                       HASH JOIN OUTER                        |                               |      0 |    156K|  2945  (34)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*361 |                        TABLE ACCESS STORAGE FULL             | G_INDIVPARAM                  |      0 |    156K|  2862  (34)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 362 |                        MAT_VIEW ACCESS STORAGE FULL          | AD_KSV_TO_PD_MVIEW            |      0 |    601 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 363 |                  JOIN FILTER USE                             | :BF0023                       |      0 |   1954 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*364 |                   TABLE ACCESS STORAGE FULL                  | G_RECEIVERSHIP                |      0 |   1954 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 365 |                JOIN FILTER USE                               | :BF0022                       |      0 |    423 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*366 |                 TABLE ACCESS STORAGE FULL                    | AD_CLIENTS                    |      0 |    423 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 367 |              VIEW                                            |                               |      0 |    113K|  1868   (6)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 368 |               HASH GROUP BY                                  |                               |      0 |    113K|  1868   (6)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*369 |                VIEW                                          |                               |      0 |    184K|  1868   (6)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 370 |                 JOIN FILTER USE                              | :BF0021                       |      0 |    184K|  1868   (6)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*371 |                  WINDOW SORT PUSHED RANK                     |                               |      0 |    184K|  1868   (6)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*372 |                   TABLE ACCESS STORAGE FULL                  | T_INDIVIDU                    |      0 |    184K|   458  (15)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 373 |            VIEW                                              |                               |      0 |    139K|   149K  (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 374 |             HASH GROUP BY                                    |                               |      0 |    139K|   149K  (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*375 |              VIEW                                            |                               |      0 |    308K|   149K  (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 376 |               JOIN FILTER USE                                | :BF0020                       |      0 |    308K|   149K  (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*377 |                WINDOW SORT PUSHED RANK                       |                               |      0 |    308K|   149K  (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 378 |                 INLIST ITERATOR                              |                               |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
|*379 |                  TABLE ACCESS BY INDEX ROWID BATCHED         | G_INDIVPARAM                  |      0 |    308K|   146K  (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*380 |                   INDEX RANGE SCAN                           | G_INDPAR_TYPSTR1_IDX          |      0 |    861K|  3328   (2)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 381 |           TABLE ACCESS BY INDEX ROWID                        | G_INDIVIDU                    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*382 |            INDEX UNIQUE SCAN                                 | G_INDIVIDU_PK                 |      0 |      1 |     0   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 383 |          VIEW                                                |                               |      0 |    272K| 48774   (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*384 |           VIEW                                               |                               |      0 |    272K| 48774   (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*385 |            WINDOW SORT PUSHED RANK                           |                               |      0 |    272K| 48774   (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 386 |             INLIST ITERATOR                                  |                               |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
| 387 |              TABLE ACCESS BY INDEX ROWID BATCHED             | G_INDIVPARAM                  |      0 |    272K| 46455   (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*388 |               INDEX RANGE SCAN                               | G_INDPAR_TYPSTR1_IDX          |      0 |    272K|  1148   (2)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 389 |         VIEW                                                 |                               |      0 |    217K|   333K  (8)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*390 |          HASH JOIN OUTER                                     |                               |      0 |    217K|   333K  (8)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*391 |           HASH JOIN RIGHT OUTER                              |                               |      0 |  15608 | 23092   (3)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 392 |            VIEW                                              |                               |      0 |   3176 |  3849   (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 393 |             HASH GROUP BY                                    |                               |      0 |   3176 |  3849   (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 394 |              TABLE ACCESS BY INDEX ROWID BATCHED             | G_GROUPINDIVDET               |      0 |   4736 |  3849   (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*395 |               INDEX FULL SCAN                                | G_GROUPINDIVDET_RFTRPE_IDX    |      0 |   4736 |   108   (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*396 |            HASH JOIN OUTER                                   |                               |      0 |  15608 | 19242   (3)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 397 |             JOIN FILTER CREATE                               | :BF0029                       |      0 |  15608 | 12545   (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*398 |              HASH JOIN                                       |                               |      0 |  15608 | 12545   (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*399 |               TABLE ACCESS STORAGE FULL                      | G_GROUP_REFEXT                |      0 |   4727 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*400 |               HASH JOIN                                      |                               |      0 |  14728 | 12541   (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 401 |                TABLE ACCESS BY INDEX ROWID BATCHED           | G_GROUPINDIVDET               |      0 |  15736 | 12535   (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*402 |                 INDEX FULL SCAN                              | G_GROUPINDIVDET_RFTRPE_IDX    |      0 |  15736 |   108   (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*403 |                TABLE ACCESS STORAGE FULL                     | G_GROUPINDIV                  |      0 |   4412 |     5  (20)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 404 |             VIEW                                             |                               |      0 |  67010 |  6695   (8)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 405 |              HASH GROUP BY                                   |                               |      0 |  67010 |  6695   (8)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 406 |               JOIN FILTER USE                                | :BF0029                       |      0 |  67010 |  2637  (18)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*407 |                HASH JOIN                                     |                               |      0 |  67010 |  2637  (18)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 408 |                 VIEW                                         | VW_GBF_20                     |      0 |  15736 |    10  (40)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 409 |                  HASH GROUP BY                               |                               |      0 |  15736 |    10  (40)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*410 |                   INDEX STORAGE FAST FULL SCAN               | G_GROUPINDIVDET_REF1_IDX      |      0 |  15736 |     7  (15)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*411 |                 VIEW                                         |                               |      0 |  20172 |  2624  (18)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*412 |                  WINDOW SORT PUSHED RANK                     |                               |      0 |  20172 |  2624  (18)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*413 |                   HASH JOIN                                  |                               |      0 |  20172 |  2350  (20)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 414 |                    JOIN FILTER CREATE                        | :BF0030                       |      0 |   4735 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*415 |                     TABLE ACCESS STORAGE FULL                | G_GROUPINDIV                  |      0 |   4735 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 416 |                    JOIN FILTER USE                           | :BF0030                       |      0 |    708K|  2330  (19)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*417 |                     TABLE ACCESS STORAGE FULL                | G_INDIVPARAM                  |      0 |    708K|  2330  (19)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 418 |           VIEW                                               |                               |      0 |  68323 |   310K  (9)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 419 |            NESTED LOOPS                                      |                               |      0 |  68323 |   310K  (9)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*420 |             VIEW                                             |                               |      0 |  25110 |  8697   (2)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*421 |              WINDOW SORT PUSHED RANK                         |                               |      0 |  25110 |  8697   (2)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 422 |               VIEW                                           |                               |      0 |  25110 |  8495   (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 423 |                HASH GROUP BY                                 |                               |      0 |  25110 |  8495   (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*424 |                 HASH JOIN                                    |                               |      0 |  25110 |  8490   (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*425 |                  HASH JOIN                                   |                               |      0 |  21206 |   364  (15)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*426 |                   TABLE ACCESS STORAGE FULL                  | G_GROUPINDIV                  |      0 |   4735 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*427 |                   HASH JOIN                                  |                               |      0 |  21205 |   359  (14)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 428 |                    TABLE ACCESS STORAGE FULL                 | AD_ACCOUNT_DEBTOR_CLIENT      |      0 |    240K|   280  (15)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*429 |                    INDEX STORAGE FAST FULL SCAN              | G_GROUPINDIVDET_REF1_IDX      |      0 |  12713 |     7  (15)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 430 |                  INLIST ITERATOR                             |                               |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
|*431 |                   TABLE ACCESS BY INDEX ROWID BATCHED        | NAM_ECR_COMPTA_BAK            |      0 |  62639 |  8124   (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*432 |                    INDEX RANGE SCAN                          | NAM_ECR_COMPTA_BAK_DTJOUR_IDX |      0 |  64589 |   328   (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*433 |             VIEW PUSHED PREDICATE                            |                               |      0 |      1 |    12   (9)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 434 |              WINDOW SORT                                     |                               |      0 |      3 |    12   (9)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*435 |               TABLE ACCESS BY INDEX ROWID BATCHED            | G_INDIVPARAM                  |      0 |      3 |    11   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*436 |                INDEX RANGE SCAN                              | G_INDIVPARAM_REFIND           |      0 |     10 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 437 |       VIEW                                                   |                               |      0 |    209K|  7251  (22)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 438 |        HASH GROUP BY                                         |                               |      0 |    209K|  7251  (22)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 439 |         JOIN FILTER USE                                      | :BF0019                       |      0 |    209K|  7215  (22)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*440 |          HASH JOIN                                           |                               |      0 |    209K|  7215  (22)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 441 |           VIEW                                               |                               |      0 |    418 |     3  (34)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 442 |            HASH UNIQUE                                       |                               |      0 |    418 |     3  (34)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*443 |             TABLE ACCESS STORAGE FULL                        | F_PARFAC                      |      0 |    552 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*444 |           HASH JOIN                                          |                               |      0 |    217K|  7207  (22)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*445 |            TABLE ACCESS STORAGE FULL                         | F_DETFAC                      |      0 |    217K|  6583  (23)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 446 |            VIEW                                              |                               |      0 |    241K|   369  (20)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 447 |             UNION-ALL                                        |                               |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
|*448 |              TABLE ACCESS STORAGE FULL                       | AD_CASES                      |      0 |    241K|   184  (20)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*449 |              TABLE ACCESS STORAGE FULL                       | AD_CASES                      |      0 |     28 |   185  (20)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 450 |      VIEW                                                    |                               |      0 |    107M|  1780K  (6)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*451 |       VIEW                                                   |                               |      0 |    107M|  1780K  (6)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*452 |        WINDOW NOSORT                                         |                               |      0 |    107M|  1780K  (6)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 453 |         SORT GROUP BY                                        |                               |      0 |    107M|  1780K  (6)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*454 |          TABLE ACCESS STORAGE FULL                           | NAM_ECR_COMPTA_BAK            |      0 |    107M|   272K (24)|      0 |00:00:00.01 |       0 |      0 |      0 |
---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   3 - access("EX_RATE"."ORIGINE"="DBCL"."DEVISE")
   5 - filter("RNK"=1)
   6 - filter(ROW_NUMBER() OVER ( PARTITION BY "ORIGINE" ORDER BY INTERNAL_FUNCTION("T"."DTDEBUT_DT") DESC )<=1)
   7 - filter(("T"."TYPE"='MR' AND "T"."PLACE"='AUT' AND NVL("T"."DESTINATION",'EUR')='EUR'))
   8 - access("T"."DTDEBUT_DT"<=SYSDATE@!)
       filter("T"."DTDEBUT_DT"<=SYSDATE@!)
   9 - access("EXT"."REFDOSS"="DBCL"."REFDOSS")
  10 - access("POLICE"."COMPTE_CASE"="DBCL"."REFDOSS")
  17 - access("DBCL"."DEBTOR"="F"."DEBTOR_REFINDIVIDU" AND "F"."DEBTOR_PAYS"="C"."STR1")
  19 - access("DBCL"."REFDOSS"="B"."REFDOSS")
  25 - filter("B"."REFDOSS" IS NOT NULL)
  26 - access("B"."TYPPIECE"='COMPTE')
  27 - filter(("C"."STR1" IS NOT NULL AND NVL("C"."DT02_DT",SYSDATE@!)>=SYSDATE@!))
  28 - access("C"."TYPE"='ASSURANCE_CREDIT' AND "B"."REFPIECE"="C"."REFPIECE" AND "C"."DT01_DT"<=SYSDATE@!)
  29 - filter("D"."REFDOSS" IS NOT NULL)
  30 - access("D"."TYPPIECE"='POLICE' AND "D"."REFPIECE"=NVL("C"."STR7","C"."STR9"))
  31 - access("D"."REFDOSS"="E"."REFDOSS")
  34 - storage(SYS_OP_BLOOM_FILTER(:BF0001,"DBCL"."REFDOSS"))
       filter(SYS_OP_BLOOM_FILTER(:BF0001,"DBCL"."REFDOSS"))
  36 - storage(SYS_OP_BLOOM_FILTER(:BF0000,"F"."DEBTOR_REFINDIVIDU","F"."DEBTOR_PAYS"))
       filter(SYS_OP_BLOOM_FILTER(:BF0000,"F"."DEBTOR_REFINDIVIDU","F"."DEBTOR_PAYS"))
  37 - access("DBCL"."DEBTOR_REF"="F"."DEBTOR_REFINDIVIDU" AND "F"."DEBTOR_PAYS"="C"."STR1")
  39 - access("B"."REFDOSS"="DBCL"."CONTRACT_CASE")
  45 - filter("B"."REFDOSS" IS NOT NULL)
  46 - access("B"."TYPPIECE"='CONTRAT')
  47 - filter(("C"."STR1" IS NOT NULL AND NVL("C"."DT02_DT",SYSDATE@!)>=SYSDATE@!))
  48 - access("C"."TYPE"='ASSURANCE_CREDIT' AND "B"."REFPIECE"="C"."REFPIECE" AND "C"."DT01_DT"<=SYSDATE@!)
  49 - filter("D"."REFDOSS" IS NOT NULL)
  50 - access("D"."TYPPIECE"='POLICE' AND "D"."REFPIECE"=NVL("C"."STR7","C"."STR9"))
  51 - access("D"."REFDOSS"="E"."REFDOSS")
  54 - storage(("DBCL"."CATEGDOSS"='COMPTE' AND SYS_OP_BLOOM_FILTER(:BF0003,"DBCL"."CONTRACT_CASE")))
       filter(("DBCL"."CATEGDOSS"='COMPTE' AND SYS_OP_BLOOM_FILTER(:BF0003,"DBCL"."CONTRACT_CASE")))
  56 - storage(SYS_OP_BLOOM_FILTER(:BF0002,"F"."DEBTOR_REFINDIVIDU","F"."DEBTOR_PAYS"))
       filter(SYS_OP_BLOOM_FILTER(:BF0002,"F"."DEBTOR_REFINDIVIDU","F"."DEBTOR_PAYS"))
  57 - access("MAX_OVERDUE"."FI_REFDOSS"="DBCL"."REFDOSS")
  59 - access("DB"."DEBTOR_REFINDIVIDU"="GRPNEW"."DEBTOR")
  60 - access("GFL"."REFINDIVIDU"="DB"."DEBTOR_REFINDIVIDU")
  62 - filter("COMM"."RNK"=1)
  63 - filter(ROW_NUMBER() OVER ( PARTITION BY "C"."REFINDIVIDU" ORDER BY INTERNAL_FUNCTION("C"."IMX_UN_ID") DESC )<=1)
  65 - access("C"."TYPE"='DEBTOR_GFL_LIM_PARAM')
  66 - access("PD_LGD"."REFINDIVIDU"="DBCL"."DEBTOR")
  67 - access("KSV_EBS_RATE"."REFINDIVIDU"="DB"."DEBTOR_REFINDIVIDU")
  69 - access("T1"."REFINDIVIDU"="DB"."DEBTOR_REFINDIVIDU")
  71 - access("UDF_INDIV"."REFINDIVIDU"="DB"."DEBTOR_REFINDIVIDU")
  72 - access("PORT_DBCL"."REFDOSS"="DBCL"."REFDOSS")
  74 - access("RATE_CONTR"."CONTRACT_CASE"="CTR"."REFDOSS")
  75 - filter("RATE_CONTR"."RNK"=1)
  76 - filter(ROW_NUMBER() OVER ( PARTITION BY "GP"."REFDOSS" ORDER BY INTERNAL_FUNCTION("GP"."IMX_UN_ID") DESC )<=1)
  77 - access("GP"."REFDOSS"="CNT"."CONTRACT_CASE")
  79 - access("GP"."TYPE"='COVERAGE_RATE')
       filter("GP"."REFDOSS" IS NOT NULL)
  81 - access("CNT"."CATEGDOSS" LIKE 'CONTRAT%')
       filter("CNT"."CATEGDOSS" LIKE 'CONTRAT%')
  82 - access("COMPTA_BAK"."REFDOSS"="DBCL"."REFDOSS")
  84 - access("REDEBTOR_AMT"."GPIADR3"="DB"."DEBTOR_REFINDIVIDU")
  86 - access("INS_QUALITY"."REFDOSS"="CTR_CASE"."REFDOSS")
  88 - access("RATE_DBCL"."REFDOSS"="DBCL"."REFDOSS")
  89 - access("NEU_GRU"."REF1"="DB"."DEBTOR_REFINDIVIDU")
  91 - access("REDEC_AMT"."REFDOSS"="DBCL"."REFDOSS")
  94 - access("A"."REFPIECE"="B"."LIBELLE_20_12")
  96 - storage(("B"."LIBELLE_20_12" IS NOT NULL AND "B"."TYPEDOC"='C' AND "B"."FG05"='O'))
       filter(("B"."LIBELLE_20_12" IS NOT NULL AND "B"."TYPEDOC"='C' AND "B"."FG05"='O'))
  98 - storage(SYS_OP_BLOOM_FILTER(:BF0012,"A"."REFPIECE"))
       filter(SYS_OP_BLOOM_FILTER(:BF0012,"A"."REFPIECE"))
  99 - access("CNT_RATE"."CONTRACT_CASE"="CTR"."REFDOSS")
100 - filter("CNT_RATE"."RNK"=1)
101 - filter(ROW_NUMBER() OVER ( PARTITION BY "GP"."REFDOSS" ORDER BY INTERNAL_FUNCTION("GP"."IMX_UN_ID") DESC )<=1)
103 - filter(("GP"."STR2"='PDEF' AND "MT01" IS NOT NULL))
104 - access("GP"."TYPE"='FINRATE')
       filter("GP"."REFDOSS" IS NOT NULL)
105 - storage(("GP"."REFDOSS"="CNT"."CONTRACT_CASE" AND "CNT"."CATEGDOSS" LIKE 'CONTRAT%'))
       filter(("GP"."REFDOSS"="CNT"."CONTRACT_CASE" AND "CNT"."CATEGDOSS" LIKE 'CONTRAT%'))
106 - access("COMPTE_RATE"."REFDOSS"="DBCL"."REFDOSS")
107 - filter("COMPTE_RATE"."RNK"=1)
108 - filter(ROW_NUMBER() OVER ( PARTITION BY "GP"."REFDOSS" ORDER BY INTERNAL_FUNCTION("GP"."IMX_UN_ID") DESC )<=1)
111 - filter(("GP"."STR2"='PDEF' AND "MT01" IS NOT NULL))
112 - access("GP"."TYPE"='FINRATE')
       filter("GP"."REFDOSS" IS NOT NULL)
113 - access("GP"."REFDOSS"="COMPTE"."REFDOSS")
114 - filter("COMPTE"."CATEGDOSS" LIKE 'COMPTE%')
115 - access("EBV"."REFINDIVIDU"="DBCL"."DEBTOR")
119 - access("DBCL"."DEBTOR"="C_LIMIT"."DEBTOR" AND "DBCL"."CLIENT"="C_LIMIT"."CLIENT" AND "DBCL"."ANCREFDOSS"="C_LIMIT"."CONTRACT_NUMBER")
120 - access("RECEI"."REFINDIVIDU"="CL"."CLIENT_REFINDIVIDU")
122 - access("CL_ACCOUNT_CASE"="DBCL"."REFLOT")
123 - storage(("DATE_ID"=TO_NUMBER(TO_CHAR(SYSDATE@!,'j')) AND "MEMO_SOURCE"=DECODE("EXIST_EOM_DATA",1,'E','A') AND INTERNAL_FUNCTION("MEMO_SOURCE")))
       filter(("DATE_ID"=TO_NUMBER(TO_CHAR(SYSDATE@!,'j')) AND "MEMO_SOURCE"=DECODE("EXIST_EOM_DATA",1,'E','A') AND INTERNAL_FUNCTION("MEMO_SOURCE")))
124 - access("V"."ABREV"=COALESCE(CASE  WHEN NVL("GI"."DRI_INDUSTRY_CODE",'_UNBEK')<>'_UNBEK' THEN "GI"."DRI_INDUSTRY_CODE" ELSE NULL END ,CASE  WHEN
              (NVL("GI"."STR44",'_UNBEK')<>'_UNBEKANNT' AND NVL("GI"."STR44",'_UNBEK')<>'_UNBEK') THEN "GI"."STR44" ELSE NULL END ,"DB"."STR15"))
125 - storage(("V"."TYPE"='DRI_INDUSTRY' OR "V"."TYPE"='DRI_NACE_CODE' OR "V"."TYPE"='T.NAF'))
       filter(("V"."TYPE"='DRI_INDUSTRY' OR "V"."TYPE"='DRI_NACE_CODE' OR "V"."TYPE"='T.NAF'))
126 - access("DBCL"."REFLOT"="CL_ACC"."REFDOSS")
128 - access("DBCL"."CLIENT"="CL"."CLIENT_REFINDIVIDU")
129 - access("GI"."REFINDIVIDU"="DBCL"."DEBTOR")
131 - access("DBCL"."DEBTOR"="DB"."DEBTOR_REFINDIVIDU")
133 - access("DBCL"."CONTRACT"="CTR_CASE"."REFDOSS")
135 - access("LOV_CNT"."ABREV"="CTR"."GPIOBJET")
140 - access("CTR"."TYPPIECE"='CONTRAT' AND "CTR"."REFDOSS"="CTR_CASE"."REFDOSS")
       filter("CTR"."REFDOSS" IS NOT NULL)
143 - storage(("LOV_CNT"."TYPE"='CONTRTYP' AND SYS_OP_BLOOM_FILTER(:BF0016,"LOV_CNT"."ABREV")))
       filter(("LOV_CNT"."TYPE"='CONTRTYP' AND SYS_OP_BLOOM_FILTER(:BF0016,"LOV_CNT"."ABREV")))
145 - storage(SYS_OP_BLOOM_FILTER(:BF0015,"DBCL"."CONTRACT"))
       filter(SYS_OP_BLOOM_FILTER(:BF0015,"DBCL"."CONTRACT"))
147 - storage(SYS_OP_BLOOM_FILTER(:BF0014,"DB"."DEBTOR_REFINDIVIDU"))
       filter(SYS_OP_BLOOM_FILTER(:BF0014,"DB"."DEBTOR_REFINDIVIDU"))
149 - storage(SYS_OP_BLOOM_FILTER(:BF0013,"GI"."REFINDIVIDU"))
       filter(SYS_OP_BLOOM_FILTER(:BF0013,"GI"."REFINDIVIDU"))
152 - filter("RN"=1)
153 - filter(ROW_NUMBER() OVER ( PARTITION BY "DEBTOR","CONTRACT_NUMBER" ORDER BY INTERNAL_FUNCTION("IMX_UN_ID") DESC )<=1)
154 - filter("A"."REFEXT"='COM')
155 - access("A"."LIMIT_TYPE"='C')
159 - storage(("FG04"='O' AND SYS_OP_BLOOM_FILTER(:BF0011,"REF1")))
       filter(("FG04"='O' AND SYS_OP_BLOOM_FILTER(:BF0011,"REF1")))
160 - filter("RATE_DBCL"."RNK"=1)
161 - filter(ROW_NUMBER() OVER ( PARTITION BY "GP"."REFDOSS" ORDER BY INTERNAL_FUNCTION("GP"."IMX_UN_ID") DESC )<=1)
165 - access("GP"."TYPE"='COVERAGE_RATE')
       filter("GP"."REFDOSS" IS NOT NULL)
166 - access("GP"."REFDOSS"="COMPTE"."REFDOSS")
167 - filter("COMPTE"."CATEGDOSS" LIKE 'COMPTE%')
170 - filter("A"."RN"=1)
172 - filter(ROW_NUMBER() OVER ( PARTITION BY "GP"."REFDOSS","GP"."LIB2" ORDER BY INTERNAL_FUNCTION("IMX_UN_ID") DESC )<=1)
173 - filter(("GP"."LIB2"='INSUR' OR "GP"."LIB2"='VERSITAT'))
174 - access("GP"."TYPE"='UDF')
178 - storage(("B"."TYPEDOC"='GFL' AND "B"."FG05"='O' AND SYS_OP_BLOOM_FILTER(:BF0009,"B"."GPIADR3")))
       filter(("B"."TYPEDOC"='GFL' AND "B"."FG05"='O' AND SYS_OP_BLOOM_FILTER(:BF0009,"B"."GPIADR3")))
182 - access("GL_AMT"."REFDOSS"="OPDB"."REFDOSS")
183 - storage(("GL_AMT"."REFDOSS" IS NOT NULL AND "GL_AMT"."DTJOUR"<SYSDATE@!+1))
       filter(("GL_AMT"."REFDOSS" IS NOT NULL AND "GL_AMT"."DTJOUR"<SYSDATE@!+1))
185 - filter("OP"."RNK"=1)
186 - filter(ROW_NUMBER() OVER ( PARTITION BY "REFDOSS" ORDER BY "EXTREF9")<=1)
188 - filter("REFDOSS" IS NOT NULL)
189 - access("DTJOUR"<SYSDATE@!+1)
       filter(("CODEOPER"='DB_CLDB_COV' OR "CODEOPER"='DB_CLDB_PRS' OR "CODEOPER"='PROV_DB_IN' OR "CODEOPER"='PROV_DB_REV'))
193 - filter(("FI"."FI_ACTIF"='O' AND INTERNAL_FUNCTION("FI"."FI_TYPE")))
194 - access("FI"."DATE_ID"=TO_NUMBER(TO_CHAR(SYSDATE@!,'j')))
195 - filter("UDF_INDIV"."RNK"=1)
196 - filter(ROW_NUMBER() OVER ( PARTITION BY "REFINDIVIDU" ORDER BY INTERNAL_FUNCTION("DT_MAJ_DT") DESC )<=1)
197 - storage("VALEUR_REF_INDIV"='FINREP COUNTERPARTY')
       filter("VALEUR_REF_INDIV"='FINREP COUNTERPARTY')
200 - filter("A"."RNK"=1)
202 - filter(ROW_NUMBER() OVER ( PARTITION BY "TI"."REFINDIVIDU","TI"."SOCIETE" ORDER BY INTERNAL_FUNCTION("TI"."IMX_UN_ID") DESC )<=1)
203 - storage(("TI"."SOCIETE"='KUKURZ' OR "TI"."SOCIETE"='National bank code ID OeNB'))
       filter(("TI"."SOCIETE"='KUKURZ' OR "TI"."SOCIETE"='National bank code ID OeNB'))
206 - filter("KSV_EBS"."RNK"=1)
208 - filter(ROW_NUMBER() OVER ( PARTITION BY "KSV"."REFINDIVIDU","KSV"."STR1" ORDER BY INTERNAL_FUNCTION("KSV"."IMX_UN_ID") DESC )<=1)
210 - filter((NVL("KSV"."DT07_DT",SYSDATE@!)>=TRUNC(SYSDATE@!) AND "KSV"."DT09_DT"<=TRUNC(SYSDATE@!)))
211 - access((("KSV"."TYPE"='COTE FACTOR' OR "KSV"."TYPE"='COTE FACTOR HIS')) AND (("KSV"."STR1"='EBS' OR "KSV"."STR1"='KSV')))
213 - filter("RNK"=1)
214 - filter(ROW_NUMBER() OVER ( PARTITION BY "GPARAM"."REFINDIVIDU" ORDER BY INTERNAL_FUNCTION("GPARAM"."IMX_UN_ID") DESC )<=1)
215 - access("PD"."DETNUM"=TO_NUMBER(NVL("GPARAM"."STR2",'0')))
216 - storage(("GPARAM"."STR1"='KSV' AND INTERNAL_FUNCTION("GPARAM"."TYPE")))
       filter(("GPARAM"."STR1"='KSV' AND INTERNAL_FUNCTION("GPARAM"."TYPE") AND NVL("GPARAM"."DT07_DT",SYSDATE@!)>=TRUNC(SYSDATE@!) AND "GPARAM"."DT09_DT"<=TRUNC(SYSDATE@!)))
219 - access("GRP"."REFGROUPE"="GRISK"."REFGROUPE")
220 - access("GRP"."REFGROUPE"="GRICOS"."REFGROUPE")
224 - access("B"."TYPE"='DEBTOR_GRP_DGGFL_LIM_PARAM')
       filter("B"."TYPE"='DEBTOR_GRP_DGGFL_LIM_PARAM')
225 - access("GRP"."REFGROUPE"="GIDET"."REFGROUPE" AND "GPRDET"."REF1"="GIDET"."DEBROR")
227 - access("GEXT"."REFGROUPE"="GRP"."REFGROUPE")
228 - storage("GEXT"."REFEXT_TYPE"='OeNB group number')
       filter("GEXT"."REFEXT_TYPE"='OeNB group number')
229 - access("GPRDET"."REFGROUPE"="GRP"."REFGROUPE")
231 - access("GPRDET"."TYPE"='LIST')
       filter("GPRDET"."TYPE"='LIST')
232 - storage(("GRP"."DTDEACT_DT" IS NULL AND "GRP"."TYPE"='DEBITEURS'))
       filter(("GRP"."DTDEACT_DT" IS NULL AND "GRP"."TYPE"='DEBITEURS'))
236 - access("LEA"."REFGROUPE"="ITEM_1")
239 - storage("GPRDET"."TYPE"='LIST')
       filter("GPRDET"."TYPE"='LIST')
240 - filter("LEA"."RNK"=1)
241 - filter(ROW_NUMBER() OVER ( PARTITION BY "GI"."REFINDIVIDU","GI"."STR1" ORDER BY INTERNAL_FUNCTION("GI"."IMX_UN_ID") DESC )<=1)
242 - access("GRL"."MAITRE"="GI"."REFINDIVIDU")
244 - storage("GRL"."TYPE"='DEBITEURS')
       filter("GRL"."TYPE"='DEBITEURS')
246 - storage((INTERNAL_FUNCTION("GI"."STR1") AND INTERNAL_FUNCTION("GI"."TYPE") AND SYS_OP_BLOOM_FILTER(:BF0018,"GI"."REFINDIVIDU")))
       filter((INTERNAL_FUNCTION("GI"."STR1") AND INTERNAL_FUNCTION("GI"."TYPE") AND SYS_OP_BLOOM_FILTER(:BF0018,"GI"."REFINDIVIDU")))
249 - filter("HRISK"."RNK"=1)
250 - filter(ROW_NUMBER() OVER ( PARTITION BY "REFGROUPE" ORDER BY INTERNAL_FUNCTION("RISK_EUR") DESC )<=1)
253 - access("DBOP"."REFDOSS"="COMPTE"."REFDOSS")
254 - access("GPR"."REFGROUPE"="GPRDET"."REFGROUPE")
255 - storage("GPR"."TYPE"='DEBITEURS')
       filter("GPR"."TYPE"='DEBITEURS')
256 - access("COMPTE"."DEBTOR"="GPRDET"."REF1")
258 - storage(("GPRDET"."REF1" IS NOT NULL AND "GPRDET"."TYPE"='LIST'))
       filter(("GPRDET"."REF1" IS NOT NULL AND "GPRDET"."TYPE"='LIST'))
260 - filter("DBOP"."REFDOSS" IS NOT NULL)
261 - access("DBOP"."DTJOUR"=TRUNC(SYSDATE@!) AND (("DBOP"."CODEOPER"='DB_CLDB_COV' OR "DBOP"."CODEOPER"='DB_CLDB_PRS')))
262 - filter("GI"."RNK"=1)
264 - filter("GI"."STR1"='KSV')
265 - access("GI"."REFINDIVIDU"="HRISK"."DEBTOR")
       filter(("GI"."TYPE"='COTE FACTOR' OR "GI"."TYPE"='COTE FACTOR HIS'))
271 - access("FIC"."FI_REFELEM"="RENT_AMT"."REFELEM")
275 - storage(("FIC"."FI_ACTIF"='O' AND INTERNAL_FUNCTION("FIC"."FI_TYPE")))
       filter(("FIC"."FI_ACTIF"='O' AND INTERNAL_FUNCTION("FIC"."FI_TYPE")))
278 - access("C"."DEBTOR_REF"=DECODE("COFACT"."STR1",'FIN',NULL,"COFACT"."REFINDIVIDU"))
279 - storage("C"."CATEGDOSS"='COMPTE')
       filter("C"."CATEGDOSS"='COMPTE')
280 - access("B"."CLIENT_REF"=DECODE("COFACT"."STR1",'FIN',"COFACT"."REFINDIVIDU",NULL))
281 - filter("COFACT"."RNK"=1)
282 - filter(ROW_NUMBER() OVER ( PARTITION BY "A"."REFINDIVIDU","STR1" ORDER BY INTERNAL_FUNCTION("A"."IMX_UN_ID") DESC )<=1)
285 - access((("A"."TYPE"='COTE FACTOR' OR "A"."TYPE"='COTE FACTOR HIS')) AND (("A"."STR1"='DRI' OR "A"."STR1"='FIN')))
286 - storage("B"."CATEGDOSS"='COMPTE')
       filter("B"."CATEGDOSS"='COMPTE')
287 - access("V"."ABREV"=COALESCE(CASE  WHEN NVL("GI"."DRI_INDUSTRY_CODE",'_UNBEK')<>'_UNBEK' THEN "GI"."DRI_INDUSTRY_CODE" ELSE NULL END ,CASE  WHEN
              (NVL("GI"."STR44",'_UNBEK')<>'_UNBEKANNT' AND NVL("GI"."STR44",'_UNBEK')<>'_UNBEK') THEN "GI"."STR44" ELSE NULL END ,"CL"."STR15"))
288 - storage(("V"."TYPE"='DRI_INDUSTRY' OR "V"."TYPE"='DRI_NACE_CODE' OR "V"."TYPE"='T.NAF'))
       filter(("V"."TYPE"='DRI_INDUSTRY' OR "V"."TYPE"='DRI_NACE_CODE' OR "V"."TYPE"='T.NAF'))
289 - access("EX_RATE"."ORIGINE"="CL_ACC"."DEVISE")
291 - filter("RNK"=1)
292 - filter(ROW_NUMBER() OVER ( PARTITION BY "ORIGINE" ORDER BY INTERNAL_FUNCTION("T"."DTDEBUT_DT") DESC )<=1)
293 - filter(("T"."TYPE"='MR' AND "T"."PLACE"='AUT' AND NVL("T"."DESTINATION",'EUR')='EUR'))
294 - access("T"."DTDEBUT_DT"<=SYSDATE@!)
       filter("T"."DTDEBUT_DT"<=SYSDATE@!)
295 - access("COMPTA_BAK"."REFDOSS"="CL_ACC"."REFDOSS")
296 - access("RISK_EUR"."DECOMPTE_REFDOSS"="CL_ACC"."REFDOSS")
298 - access("GRPNEW"."REFINDIVIDU"="CL"."CLIENT_REFINDIVIDU")
299 - access("EBDRI"."REFINDIVIDU"="CL"."CLIENT_REFINDIVIDU")
301 - access("KSV_EBS_RATE"."REFINDIVIDU"="CL"."CLIENT_REFINDIVIDU")
303 - access("T1"."REFINDIVIDU"="CL"."CLIENT_REFINDIVIDU")
305 - access("CL"."CLIENT_REFINDIVIDU"="CL_ACC"."CLIENT")
307 - access("RECEI"."REFINDIVIDU"="CL_ACC"."CLIENT")
309 - access("PD_LGD"."REFINDIVIDU"="CL_ACC"."CLIENT")
310 - access("CL_PORF"."CL_ACCOUNT_CASE"="CL_ACC"."REFDOSS")
311 - access("LOV_CNT"."ABREV"="CTR"."GPIOBJET")
313 - access("INS_QUALITY"."REFDOSS"="CTR_CASE"."REFDOSS")
315 - access("EBV"."REFINDIVIDU"="CL_ACC"."CLIENT")
317 - access("EXT"."REFINDIVIDU"="CL_ACC"."CLIENT")
318 - access("TCL"."REFDOSS"="CL_ACC"."REFDOSS" AND "TCL"."REFINDIVIDU"="CL_ACC"."CLIENT")
322 - access("CTR_CASE"."REFDOSS"="CL_ACC"."REFLOT")
327 - access("CTR"."TYPPIECE"='CONTRAT' AND "CTR"."REFDOSS"="CTR_CASE"."REFDOSS")
       filter("CTR"."REFDOSS" IS NOT NULL)
330 - storage(SYS_OP_BLOOM_FILTER(:BF0028,"CL_ACC"."REFLOT"))
       filter(SYS_OP_BLOOM_FILTER(:BF0028,"CL_ACC"."REFLOT"))
331 - access("DEC"."TYPPIECE"='SOUS-CONTRAT' AND "DEC"."REFDOSS"="CL_ACC"."REFDOSS")
       filter("DEC"."REFDOSS" IS NOT NULL)
334 - storage(("TCL"."REFTYPE"='CL' AND SYS_OP_BLOOM_FILTER(:BF0027,"TCL"."REFDOSS","TCL"."REFINDIVIDU")))
       filter(("TCL"."REFTYPE"='CL' AND SYS_OP_BLOOM_FILTER(:BF0027,"TCL"."REFDOSS","TCL"."REFINDIVIDU")))
335 - filter("EXT"."RNK"=1)
336 - filter(ROW_NUMBER() OVER ( PARTITION BY "REFINDIVIDU" ORDER BY INTERNAL_FUNCTION("IMX_UN_ID") DESC )<=1)
339 - access((("TYPE"='COTE FACTOR' OR "TYPE"='COTE FACTOR HIS')) AND "STR1"='FIN')
343 - storage(SYS_OP_BLOOM_FILTER(:BF0026,"REFINDIVIDU"))
       filter(SYS_OP_BLOOM_FILTER(:BF0026,"REFINDIVIDU"))
346 - filter("A"."RN"=1)
348 - filter(ROW_NUMBER() OVER ( PARTITION BY "GP"."REFDOSS","GP"."LIB2" ORDER BY INTERNAL_FUNCTION("IMX_UN_ID") DESC )<=1)
349 - filter(("GP"."LIB2"='INSUR' OR "GP"."LIB2"='VERSITAT'))
350 - access("GP"."TYPE"='UDF')
352 - storage(("LOV_CNT"."TYPE"='CONTRTYP' AND SYS_OP_BLOOM_FILTER(:BF0024,"LOV_CNT"."ABREV")))
       filter(("LOV_CNT"."TYPE"='CONTRTYP' AND SYS_OP_BLOOM_FILTER(:BF0024,"LOV_CNT"."ABREV")))
354 - filter("RNK"=1)
355 - filter(ROW_NUMBER() OVER ( PARTITION BY "CL_ACCOUNT_CASE","DATE_ID","CURRENCY" ORDER BY INTERNAL_FUNCTION("DATE_ID") DESC )<=1)
356 - storage(("MEMO_SOURCE"='A' AND "DATE_ID"=TO_NUMBER(TO_CHAR(SYSDATE@!,'j'))))
       filter(("MEMO_SOURCE"='A' AND "DATE_ID"=TO_NUMBER(TO_CHAR(SYSDATE@!,'j'))))
358 - filter("RNK"=1)
359 - filter(ROW_NUMBER() OVER ( PARTITION BY "GPARAM"."REFINDIVIDU" ORDER BY INTERNAL_FUNCTION("GPARAM"."IMX_UN_ID") DESC )<=1)
360 - access("PD"."DETNUM"=TO_NUMBER(NVL("GPARAM"."STR2",'0')))
361 - storage(("GPARAM"."STR1"='KSV' AND INTERNAL_FUNCTION("GPARAM"."TYPE")))
       filter(("GPARAM"."STR1"='KSV' AND INTERNAL_FUNCTION("GPARAM"."TYPE") AND NVL("GPARAM"."DT07_DT",SYSDATE@!)>=TRUNC(SYSDATE@!) AND "GPARAM"."DT09_DT"<=TRUNC(SYSDATE@!)))
364 - storage(SYS_OP_BLOOM_FILTER(:BF0023,"RECEI"."REFINDIVIDU"))
       filter(SYS_OP_BLOOM_FILTER(:BF0023,"RECEI"."REFINDIVIDU"))
366 - storage(SYS_OP_BLOOM_FILTER(:BF0022,"CL"."CLIENT_REFINDIVIDU"))
       filter(SYS_OP_BLOOM_FILTER(:BF0022,"CL"."CLIENT_REFINDIVIDU"))
369 - filter("A"."RNK"=1)
371 - filter(ROW_NUMBER() OVER ( PARTITION BY "TI"."REFINDIVIDU","TI"."SOCIETE" ORDER BY INTERNAL_FUNCTION("TI"."IMX_UN_ID") DESC )<=1)
372 - storage(("TI"."SOCIETE"='KUKURZ' OR "TI"."SOCIETE"='National bank code ID OeNB'))
       filter(("TI"."SOCIETE"='KUKURZ' OR "TI"."SOCIETE"='National bank code ID OeNB'))
375 - filter("KSV_EBS"."RNK"=1)
377 - filter(ROW_NUMBER() OVER ( PARTITION BY "KSV"."REFINDIVIDU","KSV"."STR1" ORDER BY INTERNAL_FUNCTION("KSV"."IMX_UN_ID") DESC )<=1)
379 - filter((NVL("KSV"."DT07_DT",SYSDATE@!)>=TRUNC(SYSDATE@!) AND "KSV"."DT09_DT"<=TRUNC(SYSDATE@!)))
380 - access((("KSV"."TYPE"='COTE FACTOR' OR "KSV"."TYPE"='COTE FACTOR HIS')) AND (("KSV"."STR1"='EBS' OR "KSV"."STR1"='KSV')))
382 - access("GI"."REFINDIVIDU"="CL"."CLIENT_REFINDIVIDU")
384 - filter("COFACT"."RNK"=1)
385 - filter(ROW_NUMBER() OVER ( PARTITION BY "A"."REFINDIVIDU","STR1" ORDER BY INTERNAL_FUNCTION("A"."IMX_UN_ID") DESC )<=1)
388 - access((("A"."TYPE"='COTE FACTOR' OR "A"."TYPE"='COTE FACTOR HIS')) AND "A"."STR1"='DRI')
390 - access("GRP"."REFGROUPE"="GRISK"."REFGROUPE")
391 - access("GRP"."REFGROUPE"="GRICOS"."REFGROUPE")
395 - access("B"."TYPE"='DEBTOR_GRP_DGGFL_LIM_PARAM')
       filter("B"."TYPE"='DEBTOR_GRP_DGGFL_LIM_PARAM')
396 - access("GRP"."REFGROUPE"="GIDET"."REFGROUPE" AND "GPRDET"."REF1"="GIDET"."DEBROR")
398 - access("GEXT"."REFGROUPE"="GRP"."REFGROUPE")
399 - storage("GEXT"."REFEXT_TYPE"='OeNB group number')
       filter("GEXT"."REFEXT_TYPE"='OeNB group number')
400 - access("GPRDET"."REFGROUPE"="GRP"."REFGROUPE")
402 - access("GPRDET"."TYPE"='LIST')
       filter("GPRDET"."TYPE"='LIST')
403 - storage(("GRP"."DTDEACT_DT" IS NULL AND "GRP"."TYPE"='DEBITEURS'))
       filter(("GRP"."DTDEACT_DT" IS NULL AND "GRP"."TYPE"='DEBITEURS'))
407 - access("LEA"."REFGROUPE"="ITEM_1")
410 - storage("GPRDET"."TYPE"='LIST')
       filter("GPRDET"."TYPE"='LIST')
411 - filter("LEA"."RNK"=1)
412 - filter(ROW_NUMBER() OVER ( PARTITION BY "GI"."REFINDIVIDU","GI"."STR1" ORDER BY INTERNAL_FUNCTION("GI"."IMX_UN_ID") DESC )<=1)
413 - access("GRL"."MAITRE"="GI"."REFINDIVIDU")
415 - storage("GRL"."TYPE"='DEBITEURS')
       filter("GRL"."TYPE"='DEBITEURS')
417 - storage((INTERNAL_FUNCTION("GI"."STR1") AND INTERNAL_FUNCTION("GI"."TYPE") AND SYS_OP_BLOOM_FILTER(:BF0030,"GI"."REFINDIVIDU")))
       filter((INTERNAL_FUNCTION("GI"."STR1") AND INTERNAL_FUNCTION("GI"."TYPE") AND SYS_OP_BLOOM_FILTER(:BF0030,"GI"."REFINDIVIDU")))
420 - filter("HRISK"."RNK"=1)
421 - filter(ROW_NUMBER() OVER ( PARTITION BY "REFGROUPE" ORDER BY INTERNAL_FUNCTION("RISK_EUR") DESC )<=1)
424 - access("DBOP"."REFDOSS"="COMPTE"."REFDOSS")
425 - access("GPR"."REFGROUPE"="GPRDET"."REFGROUPE")
426 - storage("GPR"."TYPE"='DEBITEURS')
       filter("GPR"."TYPE"='DEBITEURS')
427 - access("COMPTE"."DEBTOR"="GPRDET"."REF1")
429 - storage(("GPRDET"."REF1" IS NOT NULL AND "GPRDET"."TYPE"='LIST'))
       filter(("GPRDET"."REF1" IS NOT NULL AND "GPRDET"."TYPE"='LIST'))
431 - filter("DBOP"."REFDOSS" IS NOT NULL)

*/
/********************************OLD Metrics***************************************/

/********************************New SQL*******************************************/

SELECT /*+no_merge no_push_pred LEADING(ctr_case ctr lov_cnt dbcl db gi cl cl_acc) FULL(ctr_case) INDEX(ctr G_PIECE_TYPE_REFDOSS_IDX) USE_NL(ctr) FULL(lov_cnt) USE_HASH(lov_cnt) FULL(dbcl) USE_HASH(dbcl) FULL(db) 
       USE_HASH(db) FULL(gi) USE_HASH(gi) FULL(cl) USE_HASH(cl) FULL(cl_acc) USE_HASH(cl_acc) USE_HASH(port_dbcl) USE_HASH(redec_amt) USE_HASH(redebtor_amt) USE_HASH(max_overdue) USE_HASH(police) 
       USE_HASH(ins_quality) USE_HASH(ebv) FULL(recei) USE_HASH(recei) USE_HASH(t1) USE_HASH(ext) USE_HASH(gfl) USE_HASH(neu_gru) USE_HASH(compte_rate) USE_HASH(cnt_rate) USE_HASH(udf_indiv) 
       USE_HASH(compta_bak) USE_HASH(cl_hist) FULL(v) USE_HASH(v) USE_HASH(rate_dbcl) USE_HASH(rate_contr)*/
       DISTINCT 
       t1.NOneNB                                as "OeNB ID Nr.",
       grpnew.GOneNB                            as "OeNB-Gr.ID.Nr",
       grpnew.GOneNBN                           as "Name Gruppe",
       db.DEBTOR_REFINDIVIDU                    as "Poolnummer",
       RTRIM(LTRIM(db.DEBTOR_PRENOM || ' ' || db.DEBTOR_NOM)) as "Individual Name",
       db.DEBTOR_PAYS                           as "Land",
       db.DEBTOR_CP                             as "PLZ",
       db.DEBTOR_VILLE                          as "Ort",
       --IMBWEB-6448
       ksv_ebs_rate.KSV_RATE                    as "KSV-Rating",
       ksv_ebs_rate.EBS_RATE                    as "KSV Rating – EB Rating",
       db.STR15                                 as "Nace Code 1- KSV",
       gi.STR44                                 as "EB Nace Code",
       gi.DRI_INDUSTRY_CODE                     as "Nace Code 2",
       --IMBDEV-10690
       COALESCE(CASE WHEN NVL(gi.DRI_INDUSTRY_CODE,'_UNBEK') != '_UNBEK' THEN gi.DRI_INDUSTRY_CODE ELSE NULL END,
                CASE WHEN NVL(gi.STR44,'_UNBEK') NOT IN ('_UNBEKANNT','_UNBEK') THEN gi.STR44 ELSE NULL END,db.STR15) as "Final Nace",
       SUBSTR(COALESCE(CASE WHEN NVL(gi.DRI_INDUSTRY_CODE,'_UNBEK') != '_UNBEK' THEN gi.DRI_INDUSTRY_CODE ELSE NULL END,
                CASE WHEN NVL(gi.STR44,'_UNBEK') NOT IN ('_UNBEKANNT','_UNBEK') THEN gi.STR44 ELSE NULL END,db.STR15), 1, 1) as "Industry Nace Code",
       (CASE WHEN v.TYPE = 'T.NAF' THEN v.VALEUR
             WHEN v.TYPE IN ('DRI_INDUSTRY', 'DRI_NACE_CODE') THEN v.ABREV1
         END)                                    as "Industry Segment",
       ext."EB Rating"                           as "EB Rating",
       ext."EBS Rating Datum"                    as "EBS Rating Datum",
       cl.CLIENT_REFINDIVIDU                         as "Client ID",
       RTRIM(LTRIM(cl.CLIENT_PRENOM || ' ' || cl.CLIENT_NOM))      as "Client Name",
       dbcl.ANCREFDOSS                               as "Vkf.Nr",
       --
       cl_acc.REFDOSSEXT                            as "Contract NR-SAP-FI",       
       cl_acc.REFDOSS                                as "Subcontract Reference",
       cl_acc.DEVISE                                 as "Subcontract Currency",
       NVL(port_dbcl.PORTFOLIO_DBCL,0)               as "Saldo",
       NVL(compte_rate.MT01,cnt_rate.MT01)           as "Vkf.BV",
       ext."Client Financial Rating"                 as "Client Financial Rating",
       recei.DEFAULT_EVENT                           as "Ereignis Code",
       NVL(lov_cnt.VALEUR_AN,ctr.GPIOBJET)                 as "Qualitat",
       ins_quality.LIB3                                    as "Insurance Quality",
       (CASE WHEN police.POLICE_HODER = dbcl.FACTOR 
              AND police.REF_INSURER = dbcl.FACTOR THEN 'J'  
        ELSE 'N' END)                                      as "Haftung IMB",                                  
       NULL                                                as "Syndication",
       gfl.MT03                                            as "Erste group guarantee",
       NULL                                                as "Foreign Bank (guarantee)",
       100 - NVL(rate_dbcl.MT01,rate_contr.MT01)           as "SB",
       redebtor_amt.REDEBTOR_AMT                           as "Debtor Limit",
       (CH_TAUX.Conv_Orig_Dest_Tx(ad_jullian_date(to_char(Sysdate, 'DD/MM/RRRR')),    --IMBWEB-6367- change from :Date to sysdate
                                   port_dbcl.PORTFOLIO_DBCL,
                                   port_dbcl.FI_DEVISE_DOS, 
                                   AD_GET_SYS_CCY, 
                                   'MR',
                                   ''))                      as "Portfolio in EUR",
       (CH_TAUX.Conv_Orig_Dest_Tx(ad_jullian_date(to_char(Sysdate, 'DD/MM/RRRR')),
                                 NVL(cl_hist.Retention_NBV, 0),
                                 cl_hist.currency, 
                                 AD_GET_SYS_CCY, 
                                 'MR',
                                 ''))                      as "Retention NBV in EUR",
      police.NOM_INSURER                                   as "Versicherer",
      --IMBDEV-10690
      '1'                                                  as "Riskexposure Level",
      compta_bak.RISK_EUR_NOEX                             as "Riskexposure",
      compta_bak.RISK_EUR                                  as "Riskexposure in EUR",
      NVL(ex_rate.TAUX,1.0)                                as "Wechselkurs",
      ex_rate.CRDATE4I_DT                                  as "Wechselkurs Datum",      
      udf_indiv.VALUE                                      as "FINREP",
      compta_bak.GL_AMT                                    as "GL Account",
      t1.KUKURZ                                            as "KuKurz",
      gi.IFRS_9_STAGE                                      as "Stage",
      neu_gru.NEU_SUB_gruppen                              as "NEU / SUB_gruppen, wenn vorhanden",
      RTRIM(LTRIM((CASE WHEN grpnew.GOneNBN IS NOT NULL THEN grpnew.GOneNBN
                   ELSE db.DEBTOR_PRENOM || ' ' || db.DEBTOR_NOM END)))                                        as "Gruppe / Name für Pivot",
      --IMBDEV-10690
      (CASE WHEN grpnew.GOneNB IS NOT NULL THEN grpnew.Gruppe_DRI_Rating ELSE NULL END) as "Gruppe DRI-Rating",
      --
      (CASE 
         WHEN grpnew.GOneNB IS NOT NULL AND grpnew.Gruppe_KSV_Rating > 0 THEN grpnew.Gruppe_KSV_Rating 
         WHEN grpnew.GOneNB IS NOT NULL AND NVL(grpnew.Gruppe_KSV_Rating,0) = 0 AND grpnew.GKVS_HRISK > 0 THEN grpnew.GKVS_HRISK 
         WHEN grpnew.GOneNB IS NOT NULL AND NVL(grpnew.GKVS_HRISK,0) = 0 THEN ksv_ebs_rate.KSV_RATE
       END    
      ) as "Gruppe KSV-Rating",
      -- 
      (CASE 
         WHEN grpnew.GOneNB IS NOT NULL AND grpnew.Gruppe_KSV_Rating > 0 THEN 'Group' 
         WHEN grpnew.GOneNB IS NOT NULL AND NVL(grpnew.Gruppe_KSV_Rating,0) = 0 AND grpnew.GKVS_HRISK > 0 THEN 'Riskexposure' 
         WHEN grpnew.GOneNB IS NOT NULL AND NVL(grpnew.GKVS_HRISK,0) = 0 THEN 'Debtor'
       END    
      ) as "Gruppe KSV-Rating Level", 
      --   
      (CASE WHEN grpnew.GOneNB IS NOT NULL THEN grpnew.Gruppe_RICOS ELSE NULL END) as "Gruppe RICOS",
      --  
      compta_bak.CR_LOSS  as "Expected Loss Betrag in EUR",
      --
      (-1)*compta_bak.RISK_EUR*NVL(pd_lgd.pd,AD_PD_LGD_DEFAULT.AD_GET_PD_DEFAULT)*AD_PD_LGD_DEFAULT.AD_GET_LGD_BU    as "Kalkulierter Expected Loss Betrag in EUR",
      --
      DECODE(c_limit.c_flag, 1, dbcl.CREDIT_LIMIT, null)  as "Versicherungssumme",
      (CH_TAUX.Conv_Orig_Dest_Tx(ad_jullian_date(to_char(Sysdate, 'DD/MM/RRRR')),
                                 decode(c_limit.c_flag, 1, dbcl.CREDIT_LIMIT, null),
                                 dbcl.DEVISE, 
                                 AD_GET_SYS_CCY, 
                                 'MR',
                                 ''))                      as "Versicherungssumme in EUR",
      (CH_TAUX.Conv_Orig_Dest_Tx(ad_jullian_date(to_char(Sysdate, 'DD/MM/RRRR')),
                                 redec_amt.REDEC_AMT,
                                 redec_amt.GPIDEVIS, 
                                 AD_GET_SYS_CCY, 
                                 'MR',
                                 ''))                      as "Abbausaldo in EUR",
      max_overdue.MAX_OVERDUE                              as "Max. Überfällig in Tagen",
      (CH_TAUX.Conv_Orig_Dest_Tx(ad_jullian_date(to_char(Sysdate, 'DD/MM/RRRR')),
                                 max_overdue.SUM_OVER,
                                 max_overdue.FI_DEVISE_DOS, 
                                 AD_GET_SYS_CCY, 
                                 'MR',
                                 ''))                      as "Summe Überfällig in EUR",
      (CH_TAUX.Conv_Orig_Dest_Tx(ad_jullian_date(to_char(Sysdate, 'DD/MM/RRRR')),
                                 max_overdue.SUM_OVER_RISK,
                                 max_overdue.FI_DEVISE_DOS, 
                                 AD_GET_SYS_CCY, 
                                 'MR',
                                 ''))                      as "Summe Überfällig Riskexposure in EUR",
      NULL as "NPL-Unlikely to pay, not past-due or <= 90 days",
      NULL as "NPL-Past due greater than 90 days up to 180 days",
      NULL as "NPL-Past due greater than 180 days up to 1 year",
      NULL as "NPL-Past due greater than 1 year up to 5 years",
      NULL as "NPL-Past due greater than 5 years",
      (CASE  WHEN max_overdue.MAX_OVERDUE <= 0 THEN '0 - 0' 
             WHEN max_overdue.MAX_OVERDUE <= 30 THEN '1 - up to 30 days'
             WHEN max_overdue.MAX_OVERDUE BETWEEN 31 AND 60 THEN '2 - 31 to 60 days' 
             WHEN max_overdue.MAX_OVERDUE BETWEEN 61 AND 90 THEN '3 - 61 to 90 days'
             WHEN max_overdue.MAX_OVERDUE BETWEEN 91 AND 180 THEN '4 - 91 to 180 days'
             WHEN max_overdue.MAX_OVERDUE BETWEEN 181 AND 360 THEN '5 - 181  days to 1 year'
             WHEN max_overdue.MAX_OVERDUE BETWEEN 361 AND 720 THEN '6 - 1 year to 2 years'
             WHEN max_overdue.MAX_OVERDUE BETWEEN 721 AND 1800 THEN '7 - 2 years to 5 years'
             WHEN max_overdue.MAX_OVERDUE > 1801 THEN '8 - greater than 7 years' 
       END) as "PL/NPL-Type",
       CASE WHEN ebv.total_ebv > 0 THEN ebv.total_ebv ELSE NULL END  AS "Total EBV >0"
  FROM AD_ACCOUNT_DEBTOR_CLIENT dbcl,
       AD_DEBTORS               db,
       AD_CLIENTS               cl,
       AD_CASE_CONTRAT          ctr_case,
       G_PIECE                  ctr,
       AD_ACCOUNT_CLIENT_MVIEW  cl_acc,
       (SELECT /*+no_merge no_push_pred*/debtor, contract_number, client,c_flag
          FROM (SELECT /*+index( a AD_LIMIT_DEBTOR_IND)*/
                 a.debtor,
                 a.client,
                 a.contract_number,
                 1 c_flag,
                 row_number() over(PARTITION BY debtor, contract_number ORDER BY imx_un_id DESC) rn
                  FROM ad_limits a
                 WHERE a.limit_type = 'C'
                   AND a.refext = 'COM')
         WHERE rn = 1
       )c_limit,
       --IMBDEV-10690 - to modify sub query ti
      (SELECT /*+ no_merge no_push_pred */
               REFINDIVIDU,MAX(NOneNB) NOneNB,MAX(KUKURZ) KUKURZ
         FROM (SELECT /*+FULL(ti)*/  
                       ti.REFINDIVIDU,
                       (CASE WHEN ti.SOCIETE = 'National bank code ID OeNB' THEN ti.REFEXT ELSE NULL END) as NOneNB, 
                       (CASE WHEN ti.SOCIETE = 'KUKURZ' THEN ti.REFEXT ELSE NULL END) as KUKURZ,
                       ROW_NUMBER() OVER (PARTITION BY ti.REFINDIVIDU,ti.SOCIETE  ORDER BY ti.IMX_UN_ID DESC) rnk
                  FROM T_INDIVIDU ti
                 WHERE ti.SOCIETE IN ('National bank code ID OeNB','KUKURZ') 
               )a                     
        WHERE a.rnk =1
        GROUP BY REFINDIVIDU
       )t1,
       --IMBDEV-10690
      (SELECT /*+no_merge no_push_pred LEADING(gnumber)*/
             gnumber.DEBTOR,
             gnumber.GNUMBER   AS GOneNB,
             gnumber.GNOM      AS GOneNBN,
             gidet.GDRI_RATE   AS Gruppe_DRI_Rating, 
             gidet.GKSV_RATE   AS Gruppe_KSV_Rating,
             gricos.LMIT_RICOS AS Gruppe_RICOS,
             grisk.GKVS_HRISK  AS GKVS_HRISK
       FROM (SELECT /*+LEADING(gprdet grp gext) INDEX(gprdet G_GROUPINDIVDET_RFTRPE_IDX)*/
                     gprdet.REF1 AS DEBTOR,
                     grp.REFGROUPE,
                     CASE WHEN grp.DTDEACT_DT IS NULL THEN gext.REFEXT ELSE NULL END AS GNUMBER,
                    CASE WHEN grp.DTDEACT_DT IS NULL THEN grp.NOM ELSE NULL END AS GNOM
                FROM G_GROUPINDIVDET gprdet,
                     G_GROUPINDIV grp,
                     G_GROUP_REFEXT gext
               WHERE 1=1
                 AND gprdet.TYPE ='LIST'
                 AND gprdet.REFGROUPE = grp.REFGROUPE
                 AND grp.TYPE ='DEBITEURS'
                 AND gext.REFGROUPE = grp.REFGROUPE
                 AND gext.REFEXT_TYPE = 'OeNB group number' 
                 AND grp.DTDEACT_DT IS NULL
               )gnumber,
              (SELECT /*+ no_merge no_push_pred*/
                      lea.REFINDIVIDU AS LEADER,
                      lea.REFGROUPE,
                      gprdet.REF1 AS DEBROR,
                      MAX(DRI_RATE) AS GDRI_RATE,
                      MAX(KSV_RATE) AS GKSV_RATE
                 FROM(SELECT gi.REFINDIVIDU,grl.REFGROUPE,
                             CASE WHEN gi.STR1 ='DRI' THEN gi.STR2 ELSE NULL END as DRI_RATE, 
                             CASE WHEN gi.STR1 ='KSV' AND TRUNC(sysdate) BETWEEN gi.dt09_dt AND NVL(gi.dt07_dt, SYSDATE) 
                                  THEN gi.STR2 ELSE NULL END as KSV_RATE,
                             ROW_NUMBER() OVER (PARTITION BY gi.REFINDIVIDU,gi.STR1  ORDER BY gi.IMX_UN_ID DESC) rnk
                        FROM G_GROUPINDIV grl,
                             G_INDIVPARAM gi
                      WHERE grl.MAITRE = gi.REFINDIVIDU -- from leader
                        AND grL.type = 'DEBITEURS'
                        AND gi.TYPE IN ('COTE FACTOR','COTE FACTOR HIS')
                        AND gi.STR1 IN ('DRI','KSV')
                      )lea,
                      G_GROUPINDIVDET gprdet 
                WHERE lea.rnk =1
                  AND lea.REFGROUPE = gprdet.REFGROUPE
                  AND gprdet.TYPE ='LIST'
                GROUP BY lea.REFINDIVIDU,lea.REFGROUPE,gprdet.REF1
              )gidet,
              (SELECT /*+ no_merge no_push_pred*/
                       hrisk.REFGROUPE, hrisk.DEBTOR,gi.GKVS_HRISK
                  FROM (SELECT gi.REFINDIVIDU,
                               gi.STR2 as GKVS_HRISK,
                               ROW_NUMBER() OVER (PARTITION BY gi.REFINDIVIDU,gi.STR1  ORDER BY gi.IMX_UN_ID DESC) rnk
                          FROM G_INDIVPARAM gi
                         WHERE 1=1
                           AND gi.TYPE IN ('COTE FACTOR','COTE FACTOR HIS')
                           AND gi.STR1 = 'KSV'
                       ) gi,
                      (SELECT /*+ no_merge no_push_pred*/
                               REFGROUPE,DEBTOR,
                               ROW_NUMBER() OVER (PARTITION BY REFGROUPE ORDER BY RISK_EUR DESC) rnk
                          FROM(SELECT /*+ no_merge no_push_pred LEADING(compte)*/
                                        gprdet.REFGROUPE,
                                        compte.DEBTOR,
                                        SUM(CASE WHEN substr(dbop.compte, 1, 1) = '1' 
                                                 THEN DECODE(dbop.sens, 'd', dbop.montant_mvt, dbop.montant_mvt * -1) 
                                        ELSE NULL END) RISK_EUR
                                   FROM NAM_ECR_COMPTA_BAK dbop,
                                       AD_ACCOUNT_DEBTOR_CLIENT compte,
                                        G_GROUPINDIVDET gprdet,
                                        G_GROUPINDIV gpr
                                  WHERE dbop.DTJOUR = TRUNC(sysdate)
                                    AND dbop.refdoss is not null
                                    AND dbop.codeoper IN ('DB_CLDB_COV', 'DB_CLDB_PRS') 
                                    AND dbop.REFDOSS = compte.REFDOSS
                                    AND compte.DEBTOR = gprdet.REF1
                                    AND gprdet.TYPE ='LIST'
                                    AND gpr.REFGROUPE = gprdet.REFGROUPE
                                    AND gpr.type = 'DEBITEURS'
                                  GROUP BY gprdet.REFGROUPE,compte.DEBTOR
                               )
                        )hrisk
                WHERE 1=1
                  AND hrisk.DEBTOR = gi.REFINDIVIDU
                  AND hrisk.RNK =1
                  AND gi.RNK =1
                )grisk,
                (SELECT /*+ no_merge no_push_pred INDEX(B G_GROUPINDIVDET_RFTRPE_IDX)*/
                      B.REFGROUPE,
                      SUM(B.MT01) LMIT_RICOS
                 FROM G_GROUPINDIVDET B
                WHERE 1=1
                  AND B.TYPE ='DEBTOR_GRP_DGGFL_LIM_PARAM'
                GROUP BY B.REFGROUPE
              )gricos
         WHERE gnumber.REFGROUPE = gidet.REFGROUPE(+)
           AND gnumber.DEBTOR =  gidet.DEBROR(+)
           AND gnumber.REFGROUPE = grisk.REFGROUPE(+) 
           AND gnumber.REFGROUPE = gricos.REFGROUPE(+)
       )grpnew,   
       (SELECT /*+ no_merge no_push_pred LEADING(cofact b) FULL(b) USE_HASH(b) FULL(c) USE_HASH(c)*/
               NVL(b.refdoss, c.refdoss) as refdoss,
               MAX(cofact."EB Rating")                             as "EB Rating",
               MAX(cofact."EBS Rating Datum")                      as "EBS Rating Datum",
               MAX(cofact."Client Financial Rating")               as "Client Financial Rating"
          FROM (SELECT /*+INDEX(a G_INDPAR_TYPSTR1_IDX)*/
                       a.REFINDIVIDU,a.STR1,
                       -- IMBWEB-6448     
                       (CASE WHEN a.STR1 ='DRI' THEN a.STR2 ELSE NULL END) as "EB Rating",
                       (CASE WHEN a.STR1 ='DRI' THEN a.DT01_DT ELSE NULL END) as "EBS Rating Datum",
                       --
                       (CASE WHEN a.STR1 ='FIN' THEN a.STR2 ELSE NULL END)      as "Client Financial Rating",          
                       ROW_NUMBER() OVER(PARTITION BY a.REFINDIVIDU,STR1 ORDER BY a.IMX_UN_ID DESC) rnk
                  FROM G_INDIVPARAM a               
                 WHERE a.TYPE IN ('COTE FACTOR','COTE FACTOR HIS')
                   AND a.STR1 IN ('FIN','DRI')   
                )cofact,
                ad_cases b,
                ad_cases c  
          WHERE cofact.rnk =1
            AND b.client_ref(+) = DECODE(cofact.STR1, 'FIN', cofact.REFINDIVIDU, NULL)
            AND b.categdoss(+) = 'COMPTE'
            AND c.debtor_ref(+) = DECODE(cofact.STR1, 'FIN', NULL, cofact.REFINDIVIDU)
            AND c.categdoss(+) = 'COMPTE'
         GROUP BY NVL(b.refdoss, c.refdoss)
       )ext,
       --IMBWEB-6448
       (SELECT /*+ no_merge no_push_pred*/
               REFINDIVIDU,
               MAX(KSV_RATE) KSV_RATE,
               MAX(EBS_RATE) EBS_RATE
        FROM (SELECT /*+INDEX(ksv G_INDPAR_TYPSTR1_IDX)*/ 
                     ksv.REFINDIVIDU,
                     (CASE WHEN ksv.STR1 ='KSV' THEN ksv.STR2 ELSE NULL END)  KSV_RATE,  
                     (CASE WHEN ksv.STR1 ='EBS' THEN ksv.STR2 ELSE NULL END)  EBS_RATE,            
                     ROW_NUMBER() OVER(PARTITION BY ksv.REFINDIVIDU,ksv.STR1 ORDER BY ksv.imx_un_id DESC) rnk
                FROM G_INDIVPARAM ksv
               WHERE ksv.TYPE IN ('COTE FACTOR','COTE FACTOR HIS')
                 AND ksv.STR1 IN ('KSV','EBS')
                 AND TRUNC(sysdate) BETWEEN ksv.DT09_DT AND NVL(ksv.DT07_DT,SYSDATE)
              )ksv_ebs
        WHERE ksv_ebs.rnk =1
        GROUP BY REFINDIVIDU
       )ksv_ebs_rate,
       G_INDIVIDU               gi,
       (SELECT /*+ no_merge no_push_pred*/
               REFINDIVIDU,MT03
          FROM (SELECT /*+INDEX(c G_INDPAR_TYPSTR1_IDX)*/
                       c.REFINDIVIDU, 
                       c.MT03,
                       row_number() over(PARTITION BY c.refindividu ORDER BY c.imx_un_id DESC) rnk
                  FROM G_INDIVPARAM c
                 WHERE c.TYPE = 'DEBTOR_GFL_LIM_PARAM'
                 )comm
           WHERE comm.rnk =1
       )gfl,
       (SELECT/*+FULL(G_GROUPINDIVDET)*/ 
               DISTINCT REF1,
               'Excluded from group guarantee' as NEU_SUB_gruppen
             FROM G_GROUPINDIVDET
            WHERE FG04 = 'O'
       )neu_gru,     
       V_DOMAINE               v,
       G_RECEIVERSHIP          recei,
       (SELECT  /*+ no_merge no_push_pred LEADING(gp) INDEX(gp G_PIECEDET_STR1_IDX) INDEX(compte AD_CASES_PK) USE_NL(compte)*/
               compte.REFDOSS,gp.MT01,
               ROW_NUMBER() OVER(PARTITION BY gp.REFDOSS ORDER BY gp.IMX_UN_ID DESC ) rnk
          FROM G_PIECEDET gp,
               AD_CASES compte
          WHERE gp.TYPE ='COVERAGE_RATE'
            AND gp.REFDOSS = compte.REFDOSS
            AND compte.CATEGDOSS LIKE 'COMPTE%'
       ) rate_dbcl,   
       (SELECT  /*+ no_merge no_push_pred LEADING(gp) INDEX(gp G_PIECEDET_STR1_IDX) INDEX(compte AD_CASES_PK) USE_NL(compte)*/
               cnt.CONTRACT_CASE,gp.MT01,
               ROW_NUMBER() OVER(PARTITION BY gp.REFDOSS ORDER BY gp.IMX_UN_ID DESC ) rnk
          FROM G_PIECEDET gp,
               AD_CASES cnt
          WHERE gp.TYPE ='COVERAGE_RATE'
            AND gp.REFDOSS = cnt.CONTRACT_CASE
            AND cnt.CATEGDOSS LIKE 'CONTRAT%'
       )rate_contr,
       ( SELECT/*+INDEX(INDEX(AD_CLIENT_STATEMENT_HISTORY PK_AD_CL_HISTORY)*/ 
                        CL_ACCOUNT_CASE,
                        BLOCKED_AMOUNT + RETENTIONS Retention_NBV,
                        CURRENCY
                   FROM AD_CLIENT_STATEMENT_HISTORY
                  WHERE date_id = TO_CHAR(sysdate,'J')
                    AND memo_source in ('A', 'E')
                    AND memo_source = DECODE(exist_eom_data, 1, 'E', 'A')
        ) cl_hist,
        (SELECT/*+INDEX(fi AD_FINELEM_PK)*/ 
                fi.FI_REFDOSS REFDOSS,fi.FI_DEVISE_DOS,
                SUM(fi.FI_OPEN_AMOUNT) PORTFOLIO_DBCL
           FROM AD_FINELEM fi
           WHERE fi.DATE_ID = TO_CHAR(sysdate,'J')
             AND fi.FI_TYPE IN ('FACTURE','OTHER DEBIT (SAF)','NOTE DE CREDIT')
             AND fi.FI_ACTIF ='O'
          GROUP BY fi.FI_REFDOSS,fi.FI_DEVISE_DOS
        )port_dbcl,
        (SELECT  /*+ no_merge no_push_pred LEADING(gp) INDEX(gp G_PIECEDET_STR1_IDX) INDEX(compte AD_CASES_PK) USE_NL(compte)*/
                 compte.REFDOSS,gp.MT01,
                 ROW_NUMBER() OVER(PARTITION BY gp.REFDOSS ORDER BY gp.IMX_UN_ID DESC ) rnk
          FROM G_PIECEDET gp,
               AD_CASES compte
          WHERE gp.TYPE ='FINRATE'
            AND gp.REFDOSS = compte.REFDOSS
            AND compte.CATEGDOSS LIKE 'COMPTE%'
            AND MT01 IS NOT NULL 
            AND gp.STR2 ='PDEF'
        ) compte_rate,
        (SELECT /*+ no_merge no_push_pred LEADING(gp) USE_HASH(cnt)*/
                 cnt.CONTRACT_CASE,gp.MT01,
                 ROW_NUMBER() OVER(PARTITION BY gp.REFDOSS ORDER BY gp.IMX_UN_ID DESC ) rnk
          FROM G_PIECEDET gp,
               AD_CASES cnt
          WHERE gp.TYPE ='FINRATE'
            AND gp.REFDOSS = cnt.CONTRACT_CASE
            AND cnt.CATEGDOSS LIKE 'CONTRAT%' 
            AND MT01 IS NOT NULL
            AND gp.STR2 ='PDEF' 
        ) cnt_rate, 
        (SELECT /*+ no_merge no_push_pred LEADING(gl_amt) FULL(gl_amt) */
                 gl_amt.REFDOSS, opdb.CR_LOSS, opdb.RISK_EUR,opdb.RISK_EUR_NOEX,
                 LISTAGG(DISTINCT CASE WHEN substr(gl_amt.EXTREF18, 1, 1) = 1 
                                        AND decode(gl_amt.sens, 'd', gl_amt.montant_mvt, gl_amt.montant_mvt * -1)>0 
                                        AND trunc(gl_amt.DTJOUR) = TRUNC(sysdate)
                                   THEN gl_amt.EXTREF18 ELSE NULL END,',')GL_AMT
           FROM NAM_ECR_COMPTA_BAK gl_amt,
                (SELECT /*+ no_merge no_push_pred*/
                        REFDOSS,EXTREF9,op.RISK_EUR as RISK_EUR_NOEX,
                        (CH_TAUX.Conv_Orig_Dest_Tx(ad_jullian_date(to_char(Sysdate, 'DD/MM/RRRR')),
                                                   op.CR_LOSS,
                                                   op.EL2, 
                                                   AD_GET_SYS_CCY, 
                                                   'MR',
                                                   ''))CR_LOSS,
                        (CH_TAUX.Conv_Orig_Dest_Tx(ad_jullian_date(to_char(Sysdate, 'DD/MM/RRRR')),
                                                   op.RISK_EUR,
                                                   op.EL2, 
                                                   AD_GET_SYS_CCY, 
                                                   'MR',
                                                   ''))RISK_EUR
                  FROM (SELECT /*+ no_merge no_push_pred full(NAM_ECR_COMPTA_BAK)*/
                                REFDOSS,
                                EXTREF9,
                                EL2,
                                SUM(CASE WHEN codeoper IN ('DB_CLDB_COV', 'DB_CLDB_PRS') 
                                          AND substr(compte, 1, 1) = '1' AND TRUNC(DTJOUR) = TRUNC(sysdate) 
                                         THEN DECODE(sens, 'd', montant_mvt, montant_mvt * -1) 
                                ELSE NULL END) RISK_EUR,
                                SUM(CASE WHEN codeoper IN ('PROV_DB_IN', 'PROV_DB_REV') 
                                              AND substr(compte, 1, 1) = '2'  
                                         THEN DECODE(sens, 'd', montant_mvt, montant_mvt * -1) 
                                ELSE NULL END) CR_LOSS,
                                ROW_NUMBER() OVER(PARTITION BY REFDOSS ORDER BY EXTREF9 ASC) rnk    
                           FROM NAM_ECR_COMPTA_BAK
                          WHERE DTJOUR < sysdate+1
                            AND refdoss is not null
                            AND codeoper IN ('PROV_DB_IN', 'PROV_DB_REV','DB_CLDB_COV', 'DB_CLDB_PRS') 
                          GROUP BY REFDOSS,EXTREF9,EL2
                        )op
                  WHERE op.rnk =1
                  )opdb
          WHERE gl_amt.REFDOSS = opdb.REFDOSS(+)
            AND gl_amt.DTJOUR < sysdate+1 
            AND gl_amt.REFDOSS is not null
          GROUP BY gl_amt.REFDOSS, opdb.CR_LOSS, opdb.RISK_EUR,opdb.RISK_EUR_NOEX   
        )compta_bak,
        (SELECT /*+no_merge no_push_pred*/
                refindividu,str2,pd
            FROM( SELECT /*+no_merge no_push_pred LEADING(gparam pd) FULL(gparam) FULL(pd) USE_HASH(pd)*/
                         gparam.refindividu, gparam.str2, 
                         pd.valeur/100 pd, 
                         row_number() over(partition by gparam.refindividu ORDER BY gparam.imx_un_id DESC) rnk
                    FROM g_indivparam gparam, 
                         ad_ksv_to_pd_mview pd
                   WHERE gparam.type IN ('COTE FACTOR', 'COTE FACTOR HIS')
                     AND gparam.str1 = 'KSV'
                     AND TRUNC(sysdate) BETWEEN gparam.dt09_dt AND NVL(gparam.dt07_dt, SYSDATE)
                     AND nvl(gparam.str2,0) = pd.detnum(+)
                ) 
          WHERE rnk =1 
        )pd_lgd,
        (SELECT /*+ no_merge no_push_pred FULL(UDF_INDIV)*/
                 REFINDIVIDU,
                 VALUE_C||VALUE_N||VALUE_D VALUE,
                 ROW_NUMBER() OVER(PARTITION BY REFINDIVIDU ORDER BY DT_MAJ_DT DESC) rnk
          FROM UDF_INDIV
          WHERE VALEUR_REF_INDIV ='FINREP COUNTERPARTY'
        )udf_indiv,
        (SELECT /*+ no_merge no_push_pred LEADING(B) FULL(B) FULL(A) USE_HASH(A)*/
                B.REFDOSS,B.GPIDEVIS,
                decode(sign(SUM(B.MT02 - A.CONSUMED_AMT)), -1, (-1)*SUM(B.MT02 - A.CONSUMED_AMT), NULL) REDEC_AMT /*overspending means consumed amt > lim. amt*/
           FROM AD_LIMITS_CONSUMATION A,
                AD_REQUEST_LIMIT_MVIEW B
          WHERE A.REFPIECE = B.LIBELLE_20_12
            AND B.FG05 ='O'
            AND B.TYPEDOC ='C'
          GROUP BY B.REFDOSS,B.GPIDEVIS
        )redec_amt,
        (SELECT /*+ no_merge no_push_pred FULL(B)*/
                B.GPIADR3,
                SUM(B.MT02) REDEBTOR_AMT
           FROM AD_REQUEST_LIMIT_MVIEW B
          WHERE B.FG05 ='O'
            AND B.TYPEDOC ='GFL'
          GROUP BY B.GPIADR3
        )redebtor_amt,
        (SELECT /*+no_merge no_push_pred*/
               FI_REFDOSS,FI_DEVISE_DOS,SUM_OVER,SUM_OVER_RISK,
               CASE WHEN FI_DTDEBUT_OVERDUE < AD_JULLIAN_DATE(to_char(Sysdate, 'DD/MM/RRRR')) 
                    THEN AD_JULLIAN_DATE(sysdate) - FI_DTDEBUT_OVERDUE
               ELSE (-1)*(FI_DTDEBUT_OVERDUE - AD_JULLIAN_DATE(to_char(Sysdate, 'DD/MM/RRRR'))) END MAX_OVERDUE     
         FROM(SELECT /*+no_merge no_push_pred*/
                     fic.FI_REFDOSS,fic.FI_DEVISE_DOS,
                     SUM(fic.SUM_OVER) SUM_OVER,
                     SUM(fic.SUM_OVER_RISK) SUM_OVER_RISK,
                     MIN(FI_DTDEBUT_OVERDUE)FI_DTDEBUT_OVERDUE
              FROM(SELECT /*+no_merge no_push_pred FULL(fi) FULL(rent_amt) USE_HASH(rent_amt)*/ 
                          fic.FI_REFDOSS,fic.FI_DTDEBUT,rent_amt.REAL_AMOUNT_DEC,fic.FI_OPEN_AMOUNT,fic.FI_DEVISE_DOS,
                          fi_refelem,
                          (CASE WHEN (AD_JULLIAN_DATE(to_char(Sysdate, 'DD/MM/RRRR')) - fic.FI_DTDEBUT) >= 90 
                                THEN fic.FI_MONTANT_DOS ELSE NULL END) SUM_OVER,
                          (CASE WHEN fic.FI_OPEN_AMOUNT - NVL(rent_amt.REAL_AMOUNT_DEC,0) > 0
                                 AND (AD_JULLIAN_DATE(to_char(Sysdate, 'DD/MM/RRRR')) - fic.FI_DTDEBUT) >= 90 
                                THEN fic.FI_OPEN_AMOUNT - NVL(rent_amt.REAL_AMOUNT_DEC,0) ELSE NULL END) SUM_OVER_RISK,
                          (CASE WHEN (FI_OPEN_AMOUNT - NVL(REAL_AMOUNT_DEC,0) > 0) THEN fic.FI_DTDEBUT ELSE NULL END) FI_DTDEBUT_OVERDUE
                     FROM AD_FINELEM_3NF fic,
                          (SELECT /*+FULL(G_VENRESTRICTION)*/ 
                                  REFELEM, SUM(REAL_AMOUNT_DEC) REAL_AMOUNT_DEC
                             FROM G_VENRESTRICTION GROUP BY REFELEM
                           )rent_amt
                     WHERE fic.FI_TYPE in ('FACTURE','OTHER DEBIT (SAF)')
                       AND fic.FI_ACTIF ='O'
                       AND fic.FI_REFELEM = rent_amt.REFELEM(+)
                   )fic 
               GROUP BY  fic.FI_REFDOSS,fic.FI_DEVISE_DOS)
         )max_overdue,
         (SELECT /*+no_merge no_push_pred*/COMPTE_CASE,
                 NVL(POLICE_HODER_DBCL,POLICE_HODER_CON)  POLICE_HODER,
                 NVL(REF_INSURER_DBCL,REF_INSURER_CON)  REF_INSURER,
                 NVL(NOM_INSURER_DBCL,NOM_INSURER_CON)  NOM_INSURER 
            FROM (SELECT /*+no_merge no_push_pred*/ COMPTE_CASE,
                         max(POLICE_HODER_DBCL) POLICE_HODER_DBCL,
                         max(POLICE_HODER_CON)  POLICE_HODER_CON,
                         max(REF_INSURER_DBCL) REF_INSURER_DBCL,
                         max(REF_INSURER_CON) REF_INSURER_CON,
                         max(NOM_INSURER_DBCL) NOM_INSURER_DBCL,
                         max(NOM_INSURER_CON) NOM_INSURER_CON
                   FROM (SELECT /*+LEADING(B C D E dbcl F) INDEX(B TYPPIECE_LASTLOAD_IND) INDEX(C GPDET_TYP_REF_IDX) USE_NL(C) 
                               INDEX(D G_PIECE_TYPE_REFPIECE_INX) USE_NL(D) INDEX(E AD_CASE_POLICE_PK) USE_NL(E) 
                               FULL(dbcl) USE_HASH(dbcl) FULL(F) USE_HASH(F)*/
                               B.REFDOSS COMPTE_CASE,
                               D.ST02 POLICE_HODER_DBCL,
                               E.DB_REF REF_INSURER_DBCL,
                               E.DB_NOM NOM_INSURER_DBCL,
                               NULL POLICE_HODER_CON,
                               NULL REF_INSURER_CON,
                               NULL NOM_INSURER_CON
                          FROM G_PIECE B,
                               G_PIECEDET C,
                               G_PIECE D,
                               AD_CASE_POLICE E,
                               AD_ACCOUNT_DEBTOR_CLIENT dbcl,
                               AD_DEBTORS F
                          WHERE B.TYPPIECE ='COMPTE'
                            AND B.REFPIECE = C.REFPIECE
                            AND C.TYPE = 'ASSURANCE_CREDIT'
                            AND NVL(C.STR7,C.STR9) = D.REFPIECE
                            AND D.TYPPIECE ='POLICE'
                            AND D.REFDOSS = E.REFDOSS
                            AND SYSDATE BETWEEN C.DT01_DT AND NVL(C.DT02_DT,SYSDATE)
                            AND dbcl.REFDOSS = B.REFDOSS
                           AND dbcl.DEBTOR = F.DEBTOR_REFINDIVIDU
                            AND F.DEBTOR_PAYS = C.STR1
                            UNION
                            SELECT /*+LEADING(B C D E dbcl F) INDEX(B TYPPIECE_LASTLOAD_IND) INDEX(C GPDET_TYP_REF_IDX) USE_NL(C) 
                                     INDEX(D G_PIECE_TYPE_REFPIECE_INX) USE_NL(D) INDEX(E AD_CASE_POLICE_PK) USE_NL(E) 
                                     FULL(dbcl) USE_HASH(dbcl) FULL(F) USE_HASH(F)*/
                                 dbcl.REFDOSS COMPTE_CASE,
                                 NULL POLICE_HODER_DBCL,
                                 NULL REF_INSURER_DBCL,
                                 NULL NOM_INSURER_DBCL,
                                 D.ST02 POLICE_HODER_CON,
                                 E.DB_REF REF_INSURER_CON,
                                 E.DB_NOM NOM_INSURER_CON
                          FROM G_PIECE B,
                               G_PIECEDET C,
                               G_PIECE D,
                               AD_CASE_POLICE E,
                               AD_CASES dbcl,
                               AD_DEBTORS F
                          WHERE B.TYPPIECE ='CONTRAT'
                            AND B.REFPIECE = C.REFPIECE
                            AND C.TYPE = 'ASSURANCE_CREDIT'
                            AND NVL(C.STR7,C.STR9) = D.REFPIECE
                            AND D.TYPPIECE ='POLICE'
                            AND D.REFDOSS = E.REFDOSS
                            AND B.REFDOSS = dbcl.CONTRACT_CASE
                            AND dbcl.CATEGDOSS ='COMPTE'
                            AND SYSDATE BETWEEN C.DT01_DT AND NVL(C.DT02_DT,SYSDATE)
                            AND dbcl.DEBTOR_REF = F.DEBTOR_REFINDIVIDU
                            AND F.DEBTOR_PAYS = C.STR1
                      )group by COMPTE_CASE
                 )
       )police,
       (SELECT /*+ no_merge no_push_pred*/
               a.REFDOSS,LISTAGG(a.LIB3) WITHIN GROUP(ORDER BY a.ord) LIB3
          FROM (SELECT /*+ no_merge no_push_pred INDEX(gp G_PIECEDET_TYPE_LASTLOAD_IDX)*/
                        gp.REFDOSS,
                        gp.LIB3,
                        DECODE(gp.LIB2,'VERSITAT',1,2) ord,
                        row_number() over(partition by gp.REFDOSS,gp.LIB2 order by IMX_UN_ID desc) rn 
                  FROM G_PIECEDET gp
                  WHERE gp.type ='UDF'
                    AND gp.LIB2 in ('VERSITAT','INSUR')
                 )a
          WHERE a.rn =1
          GROUP BY a.REFDOSS
      )ins_quality,
      (SELECT /*+ no_merge no_push_pred FULL(T_EXTERN_CALC_PROV)*/
               REFINDIVIDU, SUM(NVL(EWB_ALLOCATION,0) - NVL(EWB_RELEASE,0) - NVL(EWB_USAGE,0)) total_ebv
          FROM T_EXTERN_CALC_PROV
         GROUP BY REFINDIVIDU
       )ebv,
       V_DOMAINE lov_cnt,
       (SELECT /*+ no_merge no_push_pred */ origine,taux,CRDATE4I_DT 
         FROM (SELECT /*+ INDEX_DESC(T T_DEVISE_IX3)*/ 
                    origine,destination,NVL(taux,1.0)taux,TRUNC(CRDATE4I_DT) CRDATE4I_DT,
                    row_number() over (partition by origine order by DTDEBUT_DT desc) rnk
                FROM t_devise T
               WHERE T.dtdebut_dt <= sysdate
                 AND T.TYPE = 'MR'
                 AND T.place = 'AUT'
                 AND NVL( T.Destination, 'EUR' ) = 'EUR'
             )
        WHERE rnk =1
       )ex_rate  
 WHERE dbcl.DEBTOR = db.DEBTOR_REFINDIVIDU
   AND dbcl.CLIENT = cl.CLIENT_REFINDIVIDU
   AND dbcl.CONTRACT = ctr_case.REFDOSS
   AND ctr.REFDOSS = ctr_case.REFDOSS
   AND ctr.TYPPIECE = 'CONTRAT'
   AND dbcl.REFLOT = cl_acc.REFDOSS   
   AND t1.REFINDIVIDU(+) = db.DEBTOR_REFINDIVIDU
   AND ext.REFDOSS(+) = dbcl.REFDOSS
   --IMBWEB-6448
   AND ksv_ebs_rate.REFINDIVIDU(+) = db.DEBTOR_REFINDIVIDU
   AND v.TYPE(+) IN ('T.NAF', 'DRI_INDUSTRY', 'DRI_NACE_CODE')
   -- IMBWEB-6583
   AND v.ABREV(+) = COALESCE(CASE WHEN NVL(gi.DRI_INDUSTRY_CODE,'_UNBEK') != '_UNBEK' THEN gi.DRI_INDUSTRY_CODE ELSE NULL END,
                             CASE WHEN NVL(gi.STR44,'_UNBEK') NOT IN ('_UNBEKANNT','_UNBEK') THEN gi.STR44 ELSE NULL END,db.STR15)   
   AND recei.REFINDIVIDU(+) = cl.CLIENT_REFINDIVIDU
   AND rate_dbcl.REFDOSS(+) = dbcl.REFDOSS
   AND rate_dbcl.rnk(+) =1
   AND rate_contr.CONTRACT_CASE(+) = ctr.REFDOSS
   AND rate_contr.rnk(+) =1
   --
   AND cl_hist.CL_ACCOUNT_CASE(+) = dbcl.REFLOT
   AND compta_bak.REFDOSS(+) = dbcl.REFDOSS
   AND port_dbcl.REFDOSS = dbcl.REFDOSS
   AND compte_rate.REFDOSS(+) = dbcl.REFDOSS
   AND compte_rate.rnk(+) =1
   AND cnt_rate.CONTRACT_CASE(+) = ctr.REFDOSS
   AND cnt_rate.rnk(+) =1
   AND udf_indiv.REFINDIVIDU(+) = db.DEBTOR_REFINDIVIDU
   AND udf_indiv.rnk(+) =1
   AND gi.REFINDIVIDU = dbcl.DEBTOR
   AND gfl.REFINDIVIDU(+) = db.DEBTOR_REFINDIVIDU
   AND neu_gru.REF1(+) = db.DEBTOR_REFINDIVIDU
   AND redec_amt.REFDOSS(+) = dbcl.REFDOSS
   AND redebtor_amt.GPIADR3(+) = db.DEBTOR_REFINDIVIDU
   AND max_overdue.FI_REFDOSS(+) = dbcl.REFDOSS 
   AND police.COMPTE_CASE(+) = dbcl.REFDOSS
   AND ins_quality.REFDOSS(+) = ctr_case.REFDOSS
   AND ebv.REFINDIVIDU(+) = dbcl.DEBTOR
   AND lov_cnt.TYPE(+) ='CONTRTYP'
   AND lov_cnt.ABREV(+) = ctr.GPIOBJET
   AND dbcl.DEBTOR = c_limit.DEBTOR(+)
   AND dbcl.CLIENT = c_limit.CLIENT(+)
   AND dbcl.ANCREFDOSS = c_limit.CONTRACT_NUMBER(+)
   AND pd_lgd.REFINDIVIDU(+) = dbcl.DEBTOR
   AND ex_rate.ORIGINE(+) = dbcl.DEVISE
   AND db.DEBTOR_REFINDIVIDU = grpnew.DEBTOR(+)
UNION ALL
SELECT /*+no_merge no_push_pred LEADING(ctr_case ctr cl_acc dec tcl) FULL(ctr_case) INDEX(ctr G_PIECE_TYPE_REFDOSS_IDX) USE_NL(ctr) FULL(cl_acc) USE_HASH(cl_acc) INDEX(dec G_PIECE_TYPE_REFDOSS_IDX) USE_NL(dec) 
        FULL(tcl) USE_HASH(tcl) FULL(cl) USE_HASH(cl) USE_HASH(cl_porf) USE_HASH(ins_quality) USE_HASH(ext) USE_HASH(ebv) FULL(recei) USE_HASH(recei) FULL(lov_cnt) USE_HASH(lov_cnt)
        USE_HASH(Risk_EUR) USE_HASH(compta_bak)*/ 
       t1.NOneNB                           as "OeNB ID Nr.",
       grpnew.GOneNB                           as "OeNB-Gr.ID.Nr",
       grpnew.GOneNBN                          as "Name Gruppe",
       cl.CLIENT_REFINDIVIDU               as "Poolnummer",
       --IMBDEV-10690
       RTRIM(LTRIM(cl.CLIENT_PRENOM || ' ' || cl.CLIENT_NOM)) as "Individual Name",
       cl.CLIENT_PAYS                      as "Land",
       cl.CLIENT_CP                        as "PLZ",
       cl.CLIENT_VILLE                     as "Ort",
       --
       ksv_ebs_rate.KSV_RATE               as "KSV-Rating",
       ksv_ebs_rate.EBS_RATE               as "KSV Rating – EB Rating",
       cl.STR15                            as "Nace Code 1- KSV",
       gi.STR44                            as "EB Nace Code",
       gi.DRI_INDUSTRY_CODE                as "Nace Code 2",
       COALESCE(CASE WHEN NVL(gi.DRI_INDUSTRY_CODE,'_UNBEK') != '_UNBEK' THEN gi.DRI_INDUSTRY_CODE ELSE NULL END,
                CASE WHEN NVL(gi.STR44,'_UNBEK') NOT IN ('_UNBEKANNT','_UNBEK') THEN gi.STR44 ELSE NULL END,cl.STR15) as "Final Nace",
       SUBSTR(COALESCE(CASE WHEN NVL(gi.DRI_INDUSTRY_CODE,'_UNBEK') != '_UNBEK' THEN gi.DRI_INDUSTRY_CODE ELSE NULL END,
                CASE WHEN NVL(gi.STR44,'_UNBEK') NOT IN ('_UNBEKANNT','_UNBEK') THEN gi.STR44 ELSE NULL END,cl.STR15), 1, 1) as "Industry Nace Code",
       (CASE WHEN v.TYPE = 'T.NAF' THEN v.VALEUR
             WHEN v.TYPE IN ('DRI_INDUSTRY', 'DRI_NACE_CODE') THEN v.ABREV1
         END)                               as "Industry Segment",
       --  
       ebdri.EB_Rating                      as "EB Rating",
       ebdri.EBS_Rating_Datum               as "EBS Rating Datum",
       --
       cl.CLIENT_REFINDIVIDU                as "Client ID",
       RTRIM(LTRIM(cl.CLIENT_PRENOM || ' ' || cl.CLIENT_NOM)) as "Client Name",
       cl_acc.CONTRACT_NUMBER                                 as "Vkf.Nr",
       tcl.refdossext                                         as "Contract NR-SAP-FI",
       cl_acc.REFDOSS                                as "Subcontract Reference",
       cl_acc.DEVISE                                 as "Subcontract Currency",
       cl_porf.PORTFOLIO                             as "Saldo",
       NULL                                          as "Vkf.BV",
       ext.STR2                                      as "Client Financial Rating",
       recei.DEFAULT_EVENT                           as "Ereignis Code",
       NVL(lov_cnt.VALEUR_AN,ctr.GPIOBJET)            as "Qualitat",
       ins_quality.LIB3                              as "Insurance Quality",
       NULL                                          as "Haftung IMB",
       NULL                                          as "Syndication",
       NULL                                          as "Erste group guarantee",
       NULL                                          as "Foreign Bank (guarantee)",
       NULL                                          as "SB",       
       NULL                                          as "Debtor Limit",
      (CH_TAUX.Conv_Orig_Dest_Tx(ad_jullian_date(to_char(Sysdate, 'DD/MM/RRRR')),
                                 cl_porf.PORTFOLIO,
                                 cl_porf.currency, 
                                 AD_GET_SYS_CCY, 
                                 'MR',
                                 ''))                as "Portfolio in EUR",
      (CH_TAUX.Conv_Orig_Dest_Tx(ad_jullian_date(to_char(Sysdate, 'DD/MM/RRRR')),
                                 NVL(cl_porf.BLOCKED_AMOUNT + cl_porf.RETENTIONS, 0),
                                 cl_porf.currency, 
                                 AD_GET_SYS_CCY, 
                                 'MR',
                                 ''))                as "Retention NBV in EUR",
      NULL                                           as "Versicherer",
      --IMBDEV-10690
      '2'                                            as "Riskexposure Level", 
      (CASE WHEN NVL(dec.libelle_20_3,'N') = 'O'  
           THEN NVL(compta_bak.SUPPLIER_AMT_NOEX,0) + NVL(Risk_EUR.df_monttc_noexdf,0)
           ELSE NVL(compta_bak.SUPPLIER_AMT_NOEX,0) + NVL(Risk_EUR.df_monttc_noexndf,0) 
      END)                                           as "Riskexposure",         
      (CASE WHEN NVL(dec.libelle_20_3,'N') = 'N'  
           THEN NVL(compta_bak.SUPPLIER_AMT,0) + NVL(Risk_EUR.df_monttc_evo,0)
           ELSE NVL(compta_bak.SUPPLIER_AMT,0) + NVL(Risk_EUR.df_monttc,0) 
      END)                                           as "Riskexposure in EUR", 
      NVL(ex_rate.TAUX,1.0)                          as "Wechselkurs", 
      ex_rate.CRDATE4I_DT                            as "Wechselkurs Datum",
      --                            
      NULL                                           as "FINREP",
      compta_bak.GL_AMT                              as "GL Account",
      NULL                                           as "KuKurz",
      NULL                                           as "Stage",
      NULL                                           as "NEU / SUB_gruppen, wenn vorhanden",
      RTRIM(LTRIM((CASE WHEN grpnew.GOneNBN IS NOT NULL THEN grpnew.GOneNBN
            ELSE cl.CLIENT_PRENOM || ' ' || cl.CLIENT_NOM END)))  as "Gruppe / Name für Pivot",
      --IMBDEV-10690
/*     NULL     as "Gruppe DRI-Rating",
      NULL     as "Gruppe KSV-Rating",   
      NULL     as "Gruppe KSV-Rating Level",
      NULL     as "Gruppe RICOS",*/
      (CASE WHEN grpnew.GOneNB IS NOT NULL THEN grpnew.Gruppe_DRI_Rating ELSE NULL END) as "Gruppe DRI-Rating",
      --
      (CASE 
         WHEN grpnew.GOneNB IS NOT NULL AND grpnew.Gruppe_KSV_Rating > 0 THEN grpnew.Gruppe_KSV_Rating 
         WHEN grpnew.GOneNB IS NOT NULL AND NVL(grpnew.Gruppe_KSV_Rating,0) = 0 AND grpnew.GKVS_HRISK > 0 THEN grpnew.GKVS_HRISK 
         WHEN grpnew.GOneNB IS NOT NULL AND NVL(grpnew.GKVS_HRISK,0) = 0 THEN ksv_ebs_rate.KSV_RATE
       END    
      ) as "Gruppe KSV-Rating",
      -- 
      (CASE 
         WHEN grpnew.GOneNB IS NOT NULL AND grpnew.Gruppe_KSV_Rating > 0 THEN 'Group' 
         WHEN grpnew.GOneNB IS NOT NULL AND NVL(grpnew.Gruppe_KSV_Rating,0) = 0 AND grpnew.GKVS_HRISK > 0 THEN 'Riskexposure' 
         WHEN grpnew.GOneNB IS NOT NULL AND NVL(grpnew.GKVS_HRISK,0) = 0 THEN 'Debtor'
       END    
      ) as "Gruppe KSV-Rating Level", 
      --   
      (CASE WHEN grpnew.GOneNB IS NOT NULL THEN grpnew.Gruppe_RICOS ELSE NULL END) as "Gruppe RICOS",      
      --          
      compta_bak.CR_LOSS                             as "Expected Loss Betrag in EUR",
      --
      (-1)*(CASE WHEN ebv.total_ebv >0 THEN 0 ELSE 
            NVL(compta_bak.SUPPLIER_AMT,0)*NVL(pd_lgd.pd,AD_PD_LGD_DEFAULT.AD_GET_PD_DEFAULT)*AD_PD_LGD_DEFAULT.AD_GET_LGD_BU 
       END)                                              as "Kalkulierter Expected Loss Betrag in EUR",
      --
      NULL                                           as "Versicherungssumme",
      NULL                                           as "Versicherungssumme in EUR",
      NULL                                           as "Abbausaldo in EUR",  
      ext.MAX_OVERDUE                                as "Max. Überfällig in Tagen" ,
      NULL                                           as "Summe Überfällig",
      NULL                                           as "Summe Überfällig Riskexposure in EUR",
      TO_NUMBER(DECODE(ext.npl_level,'<90_days',NVL(compta_bak.SUPPLIER_AMT,0) + NVL(Risk_EUR.df_monttc,0),NULL))  as "NPL-Unlikely to pay, not past-due or <= 90 days" ,
      TO_NUMBER(DECODE(ext.npl_level,'91_180'  ,NVL(compta_bak.SUPPLIER_AMT,0) + NVL(Risk_EUR.df_monttc,0),NULL))  as "NPL-Past due greater than 90 days up to 180 days",
      TO_NUMBER(DECODE(ext.npl_level,'181_360' ,NVL(compta_bak.SUPPLIER_AMT,0) + NVL(Risk_EUR.df_monttc,0),NULL))  as "NPL-Past due greater than 180 days up to 1 year", 
      TO_NUMBER(DECODE(ext.npl_level,'5_years' ,NVL(compta_bak.SUPPLIER_AMT,0) + NVL(Risk_EUR.df_monttc,0),NULL))  as "NPL-Past due greater than 1 year up to 5 years", 
      TO_NUMBER(DECODE(ext.npl_level,'over_5years',NVL(compta_bak.SUPPLIER_AMT,0) + NVL(Risk_EUR.df_monttc,0),NULL))  as "NPL-Past due greater than 5 years",
     (CASE WHEN ext.MAX_OVERDUE <= 0 THEN '0 - 0' 
           WHEN ext.MAX_OVERDUE <=30 THEN '1 - up to 30 days'
           WHEN ext.MAX_OVERDUE BETWEEN 31 AND 60 THEN '2 - 31 to 60 days' 
           WHEN ext.MAX_OVERDUE BETWEEN 61 AND 90 THEN '3 - 61 to 90 days'
           WHEN ext.MAX_OVERDUE BETWEEN 91 AND 180 THEN '4 - 91 to 180 days'
           WHEN ext.MAX_OVERDUE BETWEEN 181 AND 360 THEN '5 - 181  days to 1 year'
           WHEN ext.MAX_OVERDUE BETWEEN 361 AND 720 THEN '6 - 1 year to 2 years'
           WHEN ext.MAX_OVERDUE BETWEEN 721 AND 1800 THEN '7 - 2 years to 5 years'
           WHEN ext.MAX_OVERDUE > 1801 THEN '8 - greater than 7 years' 
      END) as "PL/NPL-Type",
      CASE WHEN ebv.total_ebv > 0 THEN ebv.total_ebv ELSE NULL END  AS "Total EBV >0"                                                                                                                                                                                                                                                                                                                                                
FROM AD_ACCOUNT_CLIENT_MVIEW  cl_acc,
     g_piece                  dec,
     AD_CLIENTS               cl,
     AD_CASE_CONTRAT          ctr_case,
     G_PIECE                  ctr,
     G_RECEIVERSHIP           recei,
     G_INDIVIDU               gi,
     V_DOMAINE               v,
     (SELECT REFDOSS,EXTREF9,GL_AMT,op.SUPPLIER_AMT as SUPPLIER_AMT_NOEX,
             (CH_TAUX.Conv_Orig_Dest_Tx(ad_jullian_date(to_char(Sysdate, 'DD/MM/RRRR')),
                                           op.CR_LOSS,
                                           op.EL2, 
                                           AD_GET_SYS_CCY, 
                                           'MR',
                                           ''))CR_LOSS,
             (CH_TAUX.Conv_Orig_Dest_Tx(ad_jullian_date(to_char(Sysdate, 'DD/MM/RRRR')),
                                           op.SUPPLIER_AMT,
                                           op.EL2, 
                                           AD_GET_SYS_CCY, 
                                           'MR',
                                           '')) SUPPLIER_AMT
        FROM (SELECT /*+ no_merge no_push_pred FULL(NAM_ECR_COMPTA_BAK)*/
                        REFDOSS,
                        EXTREF9,
                        EL2,
                        LISTAGG(DISTINCT CASE WHEN substr(EXTREF18, 1, 1) = 1 
                                     AND decode(sens, 'd', montant_mvt, montant_mvt * -1)>0
                                     AND trunc(DTJOUR) = TRUNC(sysdate)
                                     THEN EXTREF18 ELSE NULL END,',')GL_AMT,  
                        SUM(CASE WHEN codeoper IN ('PROV_CL_IN', 'PROV_CL_REV') 
                                      AND substr(compte, 1, 1) = '2'  
                                 THEN DECODE(sens, 'd', montant_mvt, montant_mvt * -1) 
                        ELSE NULL END) CR_LOSS,
                        SUM(CASE WHEN codeoper IN ('ASSET_SUPPLIER') 
                                 AND substr(compte, 1, 1) = '1' AND trunc(DTJOUR) = TRUNC(sysdate)
                                 THEN DECODE(sens, 'd', montant_mvt, montant_mvt * -1) 
                        ELSE NULL END)SUPPLIER_AMT,  
                        ROW_NUMBER() OVER(PARTITION BY REFDOSS ORDER BY EXTREF9 ASC) rnk    
                   FROM NAM_ECR_COMPTA_BAK
                   WHERE DTJOUR < sysdate+1
                     AND refdoss is not null
                  GROUP BY REFDOSS,EXTREF9,EL2
             )op
        WHERE op.rnk =1
      )compta_bak,
      (SELECT /*+no_merge no_push_pred*/
                refindividu,str2,pd
            FROM( SELECT /*+no_merge no_push_pred LEADING(gparam pd) FULL(gparam) FULL(pd) USE_HASH(pd)*/
                         gparam.refindividu, gparam.str2, 
                         pd.valeur/100 pd, 
                         row_number() over(partition by gparam.refindividu ORDER BY gparam.imx_un_id DESC) rnk
                    FROM g_indivparam gparam, 
                         ad_ksv_to_pd_mview pd
                   WHERE gparam.type IN ('COTE FACTOR', 'COTE FACTOR HIS')
                     AND gparam.str1 = 'KSV'
                     AND TRUNC(sysdate) BETWEEN gparam.dt09_dt AND NVL(gparam.dt07_dt, SYSDATE)
                     AND nvl(gparam.str2,0) = pd.detnum(+)
                ) 
          WHERE rnk =1 
      )pd_lgd,
      (SELECT /*+ no_merge no_push_pred LEADING(fd) FULL(fd) FULL(fp) USE_HASH(fp) USE_HASH(cl_struct)*/
             cl_struct.decompte_refdoss,--SUM(fd.df_monttc_mvt) df_monttc_mvt,
             SUM(CASE WHEN cl_struct.VCSOURCE IN ('1','2','3') 
                      THEN DECODE(fd.df_sen,'D',(fd.df_monttc_mvt - NVL(fd.df_paye_mvt, 0)),(fd.df_monttc_mvt - NVL(fd.df_paye_mvt, 0))*(-1)) ELSE 0 END)df_monttc_noexdf,
             SUM(CASE WHEN cl_struct.VCSOURCE IN ('1','3') 
                      THEN DECODE(fd.df_sen,'D',(fd.df_monttc_mvt - NVL(fd.df_paye_mvt, 0)),(fd.df_monttc_mvt - NVL(fd.df_paye_mvt, 0))*(-1)) ELSE 0 END)df_monttc_noexndf,           
             SUM(CASE WHEN cl_struct.VCSOURCE IN ('1','2','3')
                      THEN CH_TAUX.Conv_Orig_Dest_Tx(ad_jullian_date(to_char(Sysdate, 'DD/MM/RRRR')),
                                       NVL(DECODE(fd.df_sen,'D',(fd.df_monttc_mvt - NVL(fd.df_paye_mvt, 0)),(fd.df_monttc_mvt - NVL(fd.df_paye_mvt, 0))*(-1)), 0),
                                       fd.df_devise_mvt, 
                                       AD_GET_SYS_CCY, 
                                       'MR',
                                       '') ELSE 0 END) df_monttc,
             SUM(CASE WHEN cl_struct.VCSOURCE IN ('1','3')
                      THEN CH_TAUX.Conv_Orig_Dest_Tx(ad_jullian_date(to_char(Sysdate, 'DD/MM/RRRR')),
                                       NVL(DECODE(fd.df_sen,'D',(fd.df_monttc_mvt - NVL(fd.df_paye_mvt, 0)),(fd.df_monttc_mvt - NVL(fd.df_paye_mvt, 0))*(-1)), 0),
                                       fd.df_devise_mvt, 
                                       AD_GET_SYS_CCY, 
                                       'MR',
                                       '') ELSE 0 END) df_monttc_evo                          
        FROM f_detfac fd,
             (select distinct pf_nom from f_parfac where nvl(pf_fg_tech_item, 'N') = 'N' ) fp, 
             (select/*+FULL(ad_cases)*/ 
                     refdoss, client_ref,
                     decode(categdoss, 'COMPTE', decompte_ref, refdoss) decompte_refdoss, 
                     decode(categdoss, 'COMPTE', '3', '1') VCSOURCE
                from ad_cases 
               where categdoss in ('COMPTE', 'DECOMPTE')
             union all
              select/*+FULL(ad_cases)*/ 
                     contract_case,client_ref, -- contract level
                     refdoss decompte_refdoss, '2' VCSOURCE
                from ad_cases  
               where categdoss = 'DECOMPTE'
                 and default_decompte = 'O'
             ) cl_struct
       WHERE NVL(fd.df_ann, 0) = 0 
         AND fd.df_monttc_mvt - NVL(fd.df_paye_mvt, 0) > 0 
         AND fd.df_rel IS NOT NULL
         AND fd.df_dos = cl_struct.refdoss
         AND fd.df_cli = cl_struct.client_ref
         AND upper(fd.df_nom) = fp.pf_nom
         AND DF_DAT <=  TO_CHAR(sysdate,'J')
      group by cl_struct.decompte_refdoss
      )Risk_EUR,
      (SELECT /*+ no_merge no_push_pred */
             CL_ACCOUNT_CASE,
             CURRENCY,
             PORTFOLIO,
             BLOCKED_AMOUNT,
             RETENTIONS,
             FIU_EUR
      FROM (SELECT /*+ no_merge no_push_pred INDEX(PK_AD_CL_HISTORY)*/
                       DATE_ID,
                       CL_ACCOUNT_CASE, 
                       PORTFOLIO,
                       BLOCKED_AMOUNT, 
                       RETENTIONS,
                       FIU_EUR,
                       CURRENCY,
                       ROW_NUMBER() OVER(PARTITION BY CL_ACCOUNT_CASE,DATE_ID,CURRENCY ORDER BY DATE_ID DESC) rnk
                  FROM AD_CLIENT_STATEMENT_HISTORY
                WHERE MEMO_SOURCE ='A'
                 AND DATE_ID = TO_CHAR(sysdate,'J')
             ) 
      WHERE rnk =1 
     )cl_porf,
     (SELECT /*+ no_merge no_push_pred*/
             a.REFDOSS,LISTAGG(a.LIB3) WITHIN GROUP(ORDER BY a.ord) LIB3
        FROM (SELECT /*+ no_merge no_push_pred INDEX(gp G_PIECEDET_TYPE_LASTLOAD_IDX)*/
                      gp.REFDOSS,
                      gp.LIB3,
                      DECODE(gp.LIB2,'VERSITAT',1,2) ord,
                      row_number() over(partition by gp.REFDOSS,gp.LIB2 order by IMX_UN_ID desc) rn 
                FROM G_PIECEDET gp
               WHERE gp.type ='UDF'
                 AND gp.LIB2 in ('VERSITAT','INSUR')
               )a
        WHERE a.rn =1
        GROUP BY a.REFDOSS
    )ins_quality,
    (SELECT /*+INDEX(G_INDIVPARAM G_INDPAR_TYPSTR1_IDX)*/
             REFINDIVIDU,DT02_DT ,STR2,
             (CASE WHEN STR2 ='R' AND  (TO_CHAR(sysdate,'J') - TO_CHAR(DT02_DT,'J')) BETWEEN  0 AND 90 THEN  '<90_days' 
                   WHEN STR2 ='R' AND  (TO_CHAR(sysdate,'J') - TO_CHAR(DT02_DT,'J')) BETWEEN 91 AND 180 THEN '91_180' 
                   WHEN STR2 ='R' AND  (TO_CHAR(sysdate,'J') - TO_CHAR(DT02_DT,'J')) BETWEEN 181 AND 360 THEN '181_360' 
                   WHEN STR2 ='R' AND  (TO_CHAR(sysdate,'J') - TO_CHAR(DT02_DT,'J')) BETWEEN 361 AND 1800 THEN '5_years'
                   WHEN STR2 ='R' AND  (TO_CHAR(sysdate,'J') - TO_CHAR(DT02_DT,'J')) > 1800 THEN 'over_5years' 
                   ELSE NULL  END) npl_level,
             (CASE WHEN STR2 ='R' AND TO_CHAR(sysdate,'J') > TO_CHAR(DT02_DT,'J')
                  THEN (TO_CHAR(sysdate,'J') - TO_CHAR(DT02_DT,'J')) ELSE NULL END) MAX_OVERDUE,      
             ROW_NUMBER() OVER(PARTITION BY REFINDIVIDU ORDER BY IMX_UN_ID DESC) rnk
        FROM G_INDIVPARAM
       WHERE TYPE IN ('COTE FACTOR','COTE FACTOR HIS')
         AND STR1 ='FIN'
    )ext,
   --IMBDEV-10690
   (SELECT /*+ no_merge no_push_pred*/
           REFINDIVIDU,
           MAX(KSV_RATE) KSV_RATE,
           MAX(EBS_RATE) EBS_RATE
    FROM (SELECT /*+INDEX(ksv G_INDPAR_TYPSTR1_IDX)*/ 
                 ksv.REFINDIVIDU,
                 (CASE WHEN ksv.STR1 ='KSV' THEN ksv.STR2 ELSE NULL END)  KSV_RATE,  
                 (CASE WHEN ksv.STR1 ='EBS' THEN ksv.STR2 ELSE NULL END)  EBS_RATE,            
                 ROW_NUMBER() OVER(PARTITION BY ksv.REFINDIVIDU,ksv.STR1 ORDER BY ksv.imx_un_id DESC) rnk
            FROM G_INDIVPARAM ksv
           WHERE ksv.TYPE IN ('COTE FACTOR','COTE FACTOR HIS')
             AND ksv.STR1 IN ('KSV','EBS')
             AND TRUNC(sysdate) BETWEEN ksv.DT09_DT AND NVL(ksv.DT07_DT,SYSDATE)
          )ksv_ebs
    WHERE ksv_ebs.rnk =1
    GROUP BY REFINDIVIDU
   )ksv_ebs_rate,   
  (SELECT /*+ no_merge no_push_pred FULL(T_EXTERN_CALC_PROV)*/
           REFINDIVIDU, SUM(NVL(EWB_ALLOCATION,0) - NVL(EWB_RELEASE,0) - NVL(EWB_USAGE,0)) total_ebv
      FROM T_EXTERN_CALC_PROV
     GROUP BY REFINDIVIDU       
   )ebv,
   V_DOMAINE lov_cnt,
   --IMBWEB-6520
    (SELECT /*+ no_merge no_push_pred */
             REFINDIVIDU,MAX(NOneNB) NOneNB,MAX(KUKURZ) KUKURZ
       FROM (SELECT /*+FULL(ti)*/  
                     ti.REFINDIVIDU,
                     (CASE WHEN ti.SOCIETE = 'National bank code ID OeNB' THEN ti.REFEXT ELSE NULL END) as NOneNB, 
                     (CASE WHEN ti.SOCIETE = 'KUKURZ' THEN ti.REFEXT ELSE NULL END) as KUKURZ,
                     ROW_NUMBER() OVER (PARTITION BY ti.REFINDIVIDU,ti.SOCIETE  ORDER BY ti.IMX_UN_ID DESC) rnk
                FROM T_INDIVIDU ti
               WHERE ti.SOCIETE IN ('National bank code ID OeNB','KUKURZ') 
             )a                     
      WHERE a.rnk =1
      GROUP BY REFINDIVIDU
     )t1,
    (SELECT /*+no_merge no_push_pred LEADING(gnumber)*/
           gnumber.REFINDIVIDU,
           gnumber.GNUMBER   AS GOneNB,
           gnumber.GNOM      AS GOneNBN,
           gidet.GDRI_RATE   AS Gruppe_DRI_Rating, 
           gidet.GKSV_RATE   AS Gruppe_KSV_Rating,
           gricos.LMIT_RICOS AS Gruppe_RICOS,
           grisk.GKVS_HRISK  AS GKVS_HRISK
     FROM (SELECT /*+LEADING(gprdet grp gext) INDEX(gprdet G_GROUPINDIVDET_RFTRPE_IDX)*/
                   gprdet.REF1 AS REFINDIVIDU,
                   grp.REFGROUPE,
                   CASE WHEN grp.DTDEACT_DT IS NULL THEN gext.REFEXT ELSE NULL END AS GNUMBER,
                   CASE WHEN grp.DTDEACT_DT IS NULL THEN grp.NOM ELSE NULL END AS GNOM
              FROM G_GROUPINDIVDET gprdet,
                   G_GROUPINDIV grp,
                   G_GROUP_REFEXT gext
             WHERE 1=1
               AND gprdet.TYPE ='LIST'
               AND gprdet.REFGROUPE = grp.REFGROUPE
               AND grp.TYPE ='DEBITEURS'
               AND gext.REFGROUPE = grp.REFGROUPE
               AND gext.REFEXT_TYPE = 'OeNB group number' 
               AND grp.DTDEACT_DT IS NULL
             )gnumber,
            (SELECT /*+ no_merge no_push_pred*/
                    lea.REFINDIVIDU AS LEADER,
                    lea.REFGROUPE,
                    gprdet.REF1 AS DEBROR,
                    MAX(DRI_RATE) AS GDRI_RATE,
                    MAX(KSV_RATE) AS GKSV_RATE
               FROM(SELECT gi.REFINDIVIDU,grl.REFGROUPE,
                           CASE WHEN gi.STR1 ='DRI' THEN gi.STR2 ELSE NULL END as DRI_RATE, 
                           CASE WHEN gi.STR1 ='KSV' AND TRUNC(sysdate) BETWEEN gi.dt09_dt AND NVL(gi.dt07_dt, SYSDATE) 
                                THEN gi.STR2 ELSE NULL END as KSV_RATE,
                           ROW_NUMBER() OVER (PARTITION BY gi.REFINDIVIDU,gi.STR1  ORDER BY gi.IMX_UN_ID DESC) rnk
                      FROM G_GROUPINDIV grl,
                           G_INDIVPARAM gi
                    WHERE grl.MAITRE = gi.REFINDIVIDU -- from leader
                      AND grL.type = 'DEBITEURS'
                      AND gi.TYPE IN ('COTE FACTOR','COTE FACTOR HIS')
                      AND gi.STR1 IN ('DRI','KSV')
                    )lea,
                    G_GROUPINDIVDET gprdet 
              WHERE lea.rnk =1
                AND lea.REFGROUPE = gprdet.REFGROUPE
                AND gprdet.TYPE ='LIST'
              GROUP BY lea.REFINDIVIDU,lea.REFGROUPE,gprdet.REF1
            )gidet,
            (SELECT /*+ no_merge no_push_pred*/
                     hrisk.REFGROUPE, hrisk.DEBTOR,gi.GKVS_HRISK
                FROM (SELECT gi.REFINDIVIDU,
                             gi.STR2 as GKVS_HRISK,
                             ROW_NUMBER() OVER (PARTITION BY gi.REFINDIVIDU,gi.STR1  ORDER BY gi.IMX_UN_ID DESC) rnk
                        FROM G_INDIVPARAM gi
                       WHERE 1=1
                         AND gi.TYPE IN ('COTE FACTOR','COTE FACTOR HIS')
                         AND gi.STR1 = 'KSV'
                     ) gi,
                    (SELECT /*+ no_merge no_push_pred*/
                             REFGROUPE,DEBTOR,
                             ROW_NUMBER() OVER (PARTITION BY REFGROUPE ORDER BY RISK_EUR DESC) rnk
                        FROM(SELECT /*+ no_merge no_push_pred LEADING(compte)*/
                                      gprdet.REFGROUPE,
                                      compte.DEBTOR,
                                      SUM(CASE WHEN substr(dbop.compte, 1, 1) = '1' 
                                               THEN DECODE(dbop.sens, 'd', dbop.montant_mvt, dbop.montant_mvt * -1) 
                                      ELSE NULL END) RISK_EUR
                                 FROM NAM_ECR_COMPTA_BAK dbop,
                                      AD_ACCOUNT_DEBTOR_CLIENT compte,
                                      G_GROUPINDIVDET gprdet,
                                      G_GROUPINDIV gpr
                                WHERE dbop.DTJOUR = TRUNC(sysdate)
                                  AND dbop.refdoss is not null
                                  AND dbop.codeoper IN ('DB_CLDB_COV', 'DB_CLDB_PRS') 
                                  AND dbop.REFDOSS = compte.REFDOSS
                                  AND compte.DEBTOR = gprdet.REF1
                                  AND gprdet.TYPE ='LIST'
                                  AND gpr.REFGROUPE = gprdet.REFGROUPE
                                  AND gpr.type = 'DEBITEURS'
                                GROUP BY gprdet.REFGROUPE,compte.DEBTOR
                             )
                      )hrisk
              WHERE 1=1
                AND hrisk.DEBTOR = gi.REFINDIVIDU
                AND hrisk.RNK =1
                AND gi.RNK =1
              )grisk,
              (SELECT /*+ no_merge no_push_pred INDEX(B G_GROUPINDIVDET_RFTRPE_IDX)*/
                    B.REFGROUPE,
                    SUM(B.MT01) LMIT_RICOS
               FROM G_GROUPINDIVDET B
              WHERE 1=1
                AND B.TYPE ='DEBTOR_GRP_DGGFL_LIM_PARAM'
              GROUP BY B.REFGROUPE
            )gricos
       WHERE gnumber.REFGROUPE = gidet.REFGROUPE(+)
         AND gnumber.REFINDIVIDU =  gidet.DEBROR(+)
         AND gnumber.REFGROUPE = grisk.REFGROUPE(+)   
         AND gnumber.REFGROUPE = gricos.REFGROUPE(+)
     )grpnew,
     t_intervenants tcl,
     --IMBDEV-10690
    (SELECT /*+ no_merge no_push_pred LEADING(cofact b) FULL(b) USE_HASH(b) FULL(c) USE_HASH(c)*/
           REFINDIVIDU                           as REFINDIVIDU,
           EB_Rating                             as EB_Rating,
           EBS_Rating_Datum                      as EBS_Rating_Datum
      FROM (SELECT /*+INDEX(a G_INDPAR_TYPSTR1_IDX)*/
                   a.REFINDIVIDU,a.STR1,
                   (CASE WHEN a.STR1 ='DRI' THEN a.STR2 ELSE NULL END) as EB_Rating,
                   (CASE WHEN a.STR1 ='DRI' THEN a.DT01_DT ELSE NULL END) as EBS_Rating_Datum,       
                   ROW_NUMBER() OVER(PARTITION BY a.REFINDIVIDU,STR1 ORDER BY a.IMX_UN_ID DESC) rnk
              FROM G_INDIVPARAM a               
             WHERE a.TYPE IN ('COTE FACTOR','COTE FACTOR HIS')
               AND a.STR1 IN ('DRI')   
            )cofact
       WHERE cofact.rnk =1      
      )ebdri,
     (SELECT /*+ no_merge no_push_pred */ origine,taux, CRDATE4I_DT
         FROM (SELECT /*+ INDEX_DESC(T T_DEVISE_IX3)*/ 
                    origine,destination,NVL(taux,1.0)taux,TRUNC(CRDATE4I_DT) CRDATE4I_DT,
                    row_number() over (partition by origine order by DTDEBUT_DT desc) rnk
                FROM t_devise T
               WHERE T.dtdebut_dt <= sysdate
                 AND T.TYPE = 'MR'
                 AND T.place = 'AUT'
                 AND NVL( T.Destination, 'EUR' ) = 'EUR'
             )
        WHERE rnk =1
      )ex_rate
WHERE cl.CLIENT_REFINDIVIDU = cl_acc.CLIENT
  AND tcl.refdoss(+) = cl_acc.REFDOSS
  AND tcl.refindividu(+) = cl_acc.CLIENT
  AND tcl.reftype(+) = 'CL'
  AND dec.refdoss = cl_acc.REFDOSS
  AND dec.typpiece = 'SOUS-CONTRAT'
  AND compta_bak.REFDOSS(+) = cl_acc.REFDOSS
  AND cl_porf.CL_ACCOUNT_CASE = cl_acc.REFDOSS
  AND ctr_case.REFDOSS = cl_acc.REFLOT
  AND ctr.REFDOSS = ctr_case.REFDOSS
  AND ctr.TYPPIECE = 'CONTRAT'
  AND ext.rnk(+) =1
  AND ext.REFINDIVIDU(+) = cl_acc.CLIENT
  AND recei.REFINDIVIDU(+) = cl_acc.CLIENT
  AND ins_quality.REFDOSS(+) = ctr_case.REFDOSS
  AND ebv.REFINDIVIDU(+) = cl_acc.CLIENT
  AND Risk_EUR.decompte_refdoss(+) = cl_acc.REFDOSS
  AND lov_cnt.TYPE(+) ='CONTRTYP'
  AND lov_cnt.ABREV(+) = ctr.GPIOBJET
  --
  AND t1.REFINDIVIDU(+) = cl.CLIENT_REFINDIVIDU
  AND grpnew.REFINDIVIDU(+) = cl.CLIENT_REFINDIVIDU
  AND pd_lgd.REFINDIVIDU(+) = cl_acc.CLIENT
  AND ksv_ebs_rate.REFINDIVIDU(+) = cl.CLIENT_REFINDIVIDU
  AND gi.REFINDIVIDU(+) = cl.CLIENT_REFINDIVIDU
  AND v.TYPE(+) IN ('T.NAF', 'DRI_INDUSTRY', 'DRI_NACE_CODE')
  AND v.ABREV(+) = COALESCE(CASE WHEN NVL(gi.DRI_INDUSTRY_CODE,'_UNBEK') != '_UNBEK' THEN gi.DRI_INDUSTRY_CODE ELSE NULL END,
                             CASE WHEN NVL(gi.STR44,'_UNBEK') NOT IN ('_UNBEKANNT','_UNBEK') THEN gi.STR44 ELSE NULL END,cl.STR15) 
  AND ebdri.REFINDIVIDU(+) = cl.CLIENT_REFINDIVIDU
  AND ex_rate.ORIGINE(+) =  cl_acc.DEVISE;
/********************************New SQL*******************************************/
/********************************New Metrics***************************************/
/*
Plan hash value: 984431882
---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                                    | Name                          | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  | Writes |
---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                                             |                               |      1 |        |  1689M(100)|      0 |00:01:49.28 |      16M|     14M|    784K|
|   1 |  UNION-ALL                                                   |                               |      1 |        |            |      0 |00:01:49.28 |      16M|     14M|    784K|
|   2 |   HASH UNIQUE                                                |                               |      1 |    194M|  1687M  (7)|      0 |00:01:48.82 |      16M|     14M|    784K|
|*  3 |    HASH JOIN RIGHT OUTER                                     |                               |      1 |    194M|  1337M  (9)|      0 |00:01:48.82 |      16M|     14M|    784K|
|   4 |     VIEW                                                     |                               |      1 |  12481 | 10728   (1)|     32 |00:00:00.02 |   10718 |      0 |      0 |
|*  5 |      VIEW                                                    |                               |      1 |  12481 | 10728   (1)|     32 |00:00:00.02 |   10718 |      0 |      0 |
|*  6 |       WINDOW NOSORT                                          |                               |      1 |  12481 | 10728   (1)|  12510 |00:00:00.02 |   10718 |      0 |      0 |
|*  7 |        TABLE ACCESS BY INDEX ROWID                           | T_DEVISE                      |      1 |  12481 | 10728   (1)|  12510 |00:00:00.01 |   10718 |      0 |      0 |
|*  8 |         INDEX SKIP SCAN DESCENDING                           | T_DEVISE_IX3                  |      1 |  12510 |    34   (3)|  12510 |00:00:00.01 |      42 |      0 |      0 |
|*  9 |     HASH JOIN OUTER                                          |                               |      1 |   9040K|  1337M  (9)|      0 |00:01:48.82 |      16M|     14M|    784K|
|* 10 |      HASH JOIN RIGHT OUTER                                   |                               |      1 |   8342 |  1242M (10)|      0 |00:01:48.82 |      16M|     14M|    784K|
|  11 |       VIEW                                                   |                               |      1 |      2 |   818K  (1)|  47698 |00:00:04.55 |     813K|  51408 |  51408 |
|  12 |        VIEW                                                  |                               |      1 |      2 |   818K  (1)|  47698 |00:00:04.54 |     813K|  51408 |  51408 |
|  13 |         HASH GROUP BY                                        |                               |      1 |      2 |   818K  (1)|  47698 |00:00:04.53 |     813K|  51408 |  51408 |
|  14 |          VIEW                                                |                               |      1 |      2 |   818K  (1)|  63688 |00:00:04.32 |     813K|  48762 |  48762 |
|  15 |           SORT UNIQUE                                        |                               |      1 |      2 |   818K  (1)|  63688 |00:00:04.31 |     813K|  48762 |  48762 |
|  16 |            UNION-ALL                                         |                               |      1 |        |            |  63689 |00:00:04.15 |     813K|  48762 |  48762 |
|* 17 |             HASH JOIN                                        |                               |      1 |      1 |   816K  (1)|  16045 |00:00:01.03 |     791K|      0 |      0 |
|  18 |              JOIN FILTER CREATE                              | :BF0000                       |      1 |      1 |   815K  (1)|  16048 |00:00:00.98 |     787K|      0 |      0 |
|* 19 |               HASH JOIN                                      |                               |      1 |      1 |   815K  (1)|  16048 |00:00:00.98 |     787K|      0 |      0 |
|  20 |                JOIN FILTER CREATE                            | :BF0001                       |      1 |      1 |   815K  (1)|  16048 |00:00:00.92 |     779K|      0 |      0 |
|  21 |                 NESTED LOOPS                                 |                               |      1 |      1 |   815K  (1)|  16048 |00:00:00.92 |     779K|      0 |      0 |
|  22 |                  NESTED LOOPS                                |                               |      1 |      1 |   815K  (1)|  16048 |00:00:00.91 |     763K|      0 |      0 |
|  23 |                   NESTED LOOPS                               |                               |      1 |      1 |   815K  (1)|  16048 |00:00:00.89 |     763K|      0 |      0 |
|  24 |                    NESTED LOOPS                              |                               |      1 |  20534 |   753K  (1)|  16108 |00:00:00.86 |     757K|      0 |      0 |
|* 25 |                     TABLE ACCESS BY INDEX ROWID BATCHED      | G_PIECE                       |      1 |    169K| 92748   (1)|    240K|00:00:00.33 |     119K|      0 |      0 |
|* 26 |                      INDEX RANGE SCAN                        | TYPPIECE_LASTLOAD_IND         |      1 |    240K|  1009   (2)|    240K|00:00:00.04 |     882 |      0 |      0 |
|* 27 |                     TABLE ACCESS BY INDEX ROWID BATCHED      | G_PIECEDET                    |    240K|      1 |     4   (0)|  16108 |00:00:00.49 |     637K|      0 |      0 |
|* 28 |                      INDEX RANGE SCAN                        | GPDET_TYP_REF_IDX             |    240K|      1 |     3   (0)|  16279 |00:00:00.41 |     622K|      0 |      0 |
|* 29 |                    TABLE ACCESS BY INDEX ROWID BATCHED       | G_PIECE                       |  16108 |      1 |     3   (0)|  16048 |00:00:00.03 |    6029 |      0 |      0 |
|* 30 |                     INDEX RANGE SCAN                         | G_PIECE_TYPE_REFPIECE_INX     |  16108 |      1 |     2   (0)|  16048 |00:00:00.01 |     257 |      0 |      0 |
|* 31 |                   INDEX UNIQUE SCAN                          | AD_CASE_POLICE_PK             |  16048 |      1 |     0   (0)|  16048 |00:00:00.01 |       4 |      0 |      0 |
|  32 |                  TABLE ACCESS BY INDEX ROWID                 | AD_CASE_POLICE                |  16048 |      1 |     1   (0)|  16048 |00:00:00.01 |   16048 |      0 |      0 |
|  33 |                JOIN FILTER USE                               | :BF0001                       |      1 |    240K|   280  (15)|  63395 |00:00:00.04 |    7517 |      0 |      0 |
|* 34 |                 TABLE ACCESS STORAGE FULL                    | AD_ACCOUNT_DEBTOR_CLIENT      |      1 |    240K|   280  (15)|  63395 |00:00:00.04 |    7517 |      0 |      0 |
|  35 |              JOIN FILTER USE                                 | :BF0000                       |      1 |    148K|   161  (10)|  40484 |00:00:00.03 |    4536 |      0 |      0 |
|* 36 |               TABLE ACCESS STORAGE FULL                      | AD_DEBTORS                    |      1 |    148K|   161  (10)|  40484 |00:00:00.03 |    4536 |      0 |      0 |
|* 37 |             HASH JOIN                                        |                               |      1 |      1 |  2641   (3)|  47644 |00:00:03.10 |   22107 |  48762 |  48762 |
|  38 |              JOIN FILTER CREATE                              | :BF0002                       |      1 |      1 |  2477   (2)|   3285K|00:00:00.63 |   17571 |      0 |      0 |
|* 39 |               HASH JOIN                                      |                               |      1 |      1 |  2477   (2)|   3285K|00:00:00.46 |   17571 |      0 |      0 |
|  40 |                JOIN FILTER CREATE                            | :BF0003                       |      1 |      1 |  2293   (1)|   7957 |00:00:00.04 |   12909 |      0 |      0 |
|  41 |                 NESTED LOOPS                                 |                               |      1 |      1 |  2293   (1)|   7957 |00:00:00.04 |   12909 |      0 |      0 |
|  42 |                  NESTED LOOPS                                |                               |      1 |      1 |  2293   (1)|   7957 |00:00:00.03 |    4952 |      0 |      0 |
|  43 |                   NESTED LOOPS                               |                               |      1 |      1 |  2292   (1)|   7957 |00:00:00.02 |    4948 |      0 |      0 |
|  44 |                    NESTED LOOPS                              |                               |      1 |    308 |  1366   (1)|   7957 |00:00:00.01 |    2657 |      0 |      0 |
|* 45 |                     TABLE ACCESS BY INDEX ROWID BATCHED      | G_PIECE                       |      1 |    307 |   170   (0)|    436 |00:00:00.01 |     432 |      0 |      0 |
|* 46 |                      INDEX RANGE SCAN                        | TYPPIECE_LASTLOAD_IND         |      1 |    436 |     4   (0)|    436 |00:00:00.01 |       5 |      0 |      0 |
|* 47 |                     TABLE ACCESS BY INDEX ROWID BATCHED      | G_PIECEDET                    |    436 |      1 |     4   (0)|   7957 |00:00:00.01 |    2225 |      0 |      0 |
|* 48 |                      INDEX RANGE SCAN                        | GPDET_TYP_REF_IDX             |    436 |      1 |     3   (0)|   8267 |00:00:00.01 |    1320 |      0 |      0 |
|* 49 |                    TABLE ACCESS BY INDEX ROWID BATCHED       | G_PIECE                       |   7957 |      1 |     3   (0)|   7957 |00:00:00.01 |    2291 |      0 |      0 |
|* 50 |                     INDEX RANGE SCAN                         | G_PIECE_TYPE_REFPIECE_INX     |   7957 |      1 |     2   (0)|   7957 |00:00:00.01 |     356 |      0 |      0 |
|* 51 |                   INDEX UNIQUE SCAN                          | AD_CASE_POLICE_PK             |   7957 |      1 |     0   (0)|   7957 |00:00:00.01 |       4 |      0 |      0 |
|  52 |                  TABLE ACCESS BY INDEX ROWID                 | AD_CASE_POLICE                |   7957 |      1 |     1   (0)|   7957 |00:00:00.01 |    7957 |      0 |      0 |
|  53 |                JOIN FILTER USE                               | :BF0003                       |      1 |    240K|   179  (17)|  47722 |00:00:00.04 |    4662 |      0 |      0 |
|* 54 |                 TABLE ACCESS STORAGE FULL                    | AD_CASES                      |      1 |    240K|   179  (17)|  47722 |00:00:00.04 |    4662 |      0 |      0 |
|  55 |              JOIN FILTER USE                                 | :BF0002                       |      1 |    148K|   161  (10)|    148K|00:00:00.05 |    4536 |      0 |      0 |
|* 56 |               TABLE ACCESS STORAGE FULL                      | AD_DEBTORS                    |      1 |    148K|   161  (10)|    148K|00:00:00.03 |    4536 |      0 |      0 |
|* 57 |       HASH JOIN OUTER                                        |                               |      1 |   8342 |  1241M (10)|      0 |00:01:48.82 |      15M|     14M|    733K|
|  58 |        JOIN FILTER CREATE                                    | :BF0004                       |      1 |   3431 |  1241M (10)|      0 |00:01:48.82 |      15M|     14M|    733K|
|* 59 |         HASH JOIN OUTER                                      |                               |      1 |   3431 |  1241M (10)|      0 |00:01:48.82 |      15M|     14M|    733K|
|* 60 |          HASH JOIN RIGHT OUTER                               |                               |      1 |   1301 |  1241M (10)|      0 |00:01:48.82 |      15M|     14M|    733K|
|  61 |           VIEW                                               |                               |      1 |    147K| 26252   (1)|    147K|00:00:00.97 |   28182 |   1574 |      0 |
|* 62 |            VIEW                                              |                               |      1 |    147K| 26252   (1)|    147K|00:00:00.97 |   28182 |   1574 |      0 |
|* 63 |             WINDOW SORT PUSHED RANK                          |                               |      1 |    147K| 26252   (1)|    147K|00:00:00.96 |   28182 |   1574 |      0 |
|  64 |              TABLE ACCESS BY INDEX ROWID BATCHED             | G_INDIVPARAM                  |      1 |    147K| 25247   (1)|    147K|00:00:00.67 |   28182 |   1574 |      0 |
|* 65 |               INDEX RANGE SCAN                               | G_INDPAR_TYPSTR1_IDX          |      1 |    147K|   634   (2)|    147K|00:00:00.31 |     690 |    689 |      0 |
|* 66 |           HASH JOIN OUTER                                    |                               |      1 |    866 |  1241M (10)|      0 |00:01:48.82 |      15M|     14M|    733K|
|* 67 |            HASH JOIN OUTER                                   |                               |      1 |    629 |  1241M (10)|      0 |00:01:48.82 |      15M|     14M|    733K|
|  68 |             JOIN FILTER CREATE                               | :BF0005                       |      1 |    629 |  1241M (10)|      0 |00:01:48.82 |      15M|     14M|    733K|
|* 69 |              HASH JOIN OUTER                                 |                               |      1 |    629 |  1241M (10)|      0 |00:01:48.82 |      15M|     14M|    733K|
|  70 |               JOIN FILTER CREATE                             | :BF0006                       |      1 |    629 |  1241M (10)|      0 |00:01:48.82 |      15M|     14M|    733K|
|* 71 |                HASH JOIN OUTER                               |                               |      1 |    629 |  1241M (10)|      0 |00:01:48.82 |      15M|     14M|    733K|
|* 72 |                 HASH JOIN                                    |                               |      1 |    428 |  1241M (10)|      0 |00:01:48.82 |      15M|     14M|    733K|
|  73 |                  JOIN FILTER CREATE                          | :BF0007                       |      1 |    668 |  1241M (10)|    240K|00:01:48.42 |      15M|     14M|    721K|
|* 74 |                   HASH JOIN RIGHT OUTER                      |                               |      1 |    668 |  1241M (10)|    240K|00:01:48.39 |      15M|     14M|    721K|
|* 75 |                    VIEW                                      |                               |      1 |   4007 | 10065   (1)|    120 |00:00:00.06 |   18944 |      0 |      0 |
|* 76 |                     WINDOW SORT PUSHED RANK                  |                               |      1 |   4007 | 10065   (1)|    120 |00:00:00.06 |   18944 |      0 |      0 |
|* 77 |                      HASH JOIN                               |                               |      1 |   4007 | 10064   (1)|   1237 |00:00:00.06 |   18944 |      0 |      0 |
|  78 |                       TABLE ACCESS BY INDEX ROWID BATCHED    | G_PIECEDET                    |      1 |  20885 | 10050   (1)|  27893 |00:00:00.05 |   18850 |      0 |      0 |
|* 79 |                        INDEX RANGE SCAN                      | G_PIECEDET_STR1_IDX           |      1 |  20885 |   157   (2)|  27893 |00:00:00.01 |     147 |      0 |      0 |
|  80 |                       TABLE ACCESS BY INDEX ROWID BATCHED    | AD_CASES                      |      1 |    436 |    13   (0)|    436 |00:00:00.01 |      94 |      0 |      0 |
|* 81 |                        INDEX RANGE SCAN                      | AD_CASES_CATEGDOSS_IDX        |      1 |    436 |     4   (0)|    436 |00:00:00.01 |       6 |      0 |      0 |
|* 82 |                    HASH JOIN OUTER                           |                               |      1 |    413 |  1241M (10)|    240K|00:01:48.33 |      15M|     14M|    721K|
|  83 |                     JOIN FILTER CREATE                       | :BF0008                       |      1 |    413 |   116K  (2)|    240K|00:00:06.22 |     381K|    234K|  49203 |
|* 84 |                      HASH JOIN OUTER                         |                               |      1 |    413 |   116K  (2)|    240K|00:00:06.20 |     381K|    234K|  49203 |
|  85 |                       JOIN FILTER CREATE                     | :BF0009                       |      1 |    413 |   112K  (2)|    240K|00:00:05.43 |     289K|    137K|  45171 |
|* 86 |                        HASH JOIN OUTER                       |                               |      1 |    413 |   112K  (2)|    240K|00:00:05.40 |     289K|    137K|  45171 |
|  87 |                         JOIN FILTER CREATE                   | :BF0010                       |      1 |    413 |   104K  (2)|    240K|00:00:04.28 |     275K|    133K|  41139 |
|* 88 |                          HASH JOIN OUTER                     |                               |      1 |    413 |   104K  (2)|    240K|00:00:04.25 |     275K|    133K|  41139 |
|* 89 |                           HASH JOIN OUTER                    |                               |      1 |    411 | 52680   (3)|    240K|00:00:03.17 |     223K|    121K|  29358 |
|  90 |                            JOIN FILTER CREATE                | :BF0011                       |      1 |    411 | 52663   (3)|    240K|00:00:02.54 |     223K|    114K|  22365 |
|* 91 |                             HASH JOIN RIGHT OUTER            |                               |      1 |    411 | 52663   (3)|    240K|00:00:02.53 |     223K|    114K|  22365 |
|  92 |                              VIEW                            |                               |      1 |   4714 |  3783  (22)|  28948 |00:00:00.08 |   94451 |  92408 |      0 |
|  93 |                               HASH GROUP BY                  |                               |      1 |   4714 |  3783  (22)|  28948 |00:00:00.08 |   94451 |  92408 |      0 |
|* 94 |                                HASH JOIN                     |                               |      1 |   4714 |  3782  (22)|  28948 |00:00:00.07 |   94451 |  92408 |      0 |
|  95 |                                 JOIN FILTER CREATE           | :BF0012                       |      1 |  18069 |  3687  (22)|  28949 |00:00:00.04 |   92414 |  92408 |      0 |
|* 96 | L                                MAT_VIEW ACCESS STORAGE FUL | AD_REQUEST_LIMIT_MVIEW        |      1 |  18069 |  3687  (22)|  28949 |00:00:00.03 |   92414 |  92408 |      0 |
|  97 |                                 JOIN FILTER USE              | :BF0012                       |      1 |    332K|    87  (22)|  45136 |00:00:00.02 |    2036 |      0 |      0 |
|* 98 |                                  TABLE ACCESS STORAGE FULL   | AD_LIMITS_CONSUMATION         |      1 |    332K|    87  (22)|  45136 |00:00:00.02 |    2036 |      0 |      0 |
|* 99 |                              HASH JOIN RIGHT OUTER           |                               |      1 |    411 | 48879   (1)|    240K|00:00:02.41 |     129K|  22365 |  22365 |
|*100 |                               VIEW                           |                               |      1 |     16 |  2522   (1)|    429 |00:00:00.05 |   10173 |      0 |      0 |
|*101 |                                WINDOW SORT PUSHED RANK       |                               |      1 |     16 |  2522   (1)|    429 |00:00:00.04 |   10173 |      0 |      0 |
|*102 |                                 HASH JOIN                    |                               |      1 |     16 |  2521   (1)|   6870 |00:00:00.04 |   10173 |      0 |      0 |
|*103 |  BATCHED                         TABLE ACCESS BY INDEX ROWID | G_PIECEDET                    |      1 |     83 |  2508   (1)|  15198 |00:00:00.03 |   10079 |      0 |      0 |
|*104 |                                   INDEX RANGE SCAN           | G_PIECEDET_TYPE_LASTLOAD_IDX  |      1 |  23961 |   123   (1)|  23987 |00:00:00.01 |      95 |      0 |      0 |
| 105 |  BATCHED                         TABLE ACCESS BY INDEX ROWID | AD_CASES                      |      1 |    436 |    13   (0)|    436 |00:00:00.01 |      94 |      0 |      0 |
|*106 |                                   INDEX RANGE SCAN           | AD_CASES_CATEGDOSS_IDX        |      1 |    436 |     4   (0)|    436 |00:00:00.01 |       6 |      0 |      0 |
|*107 |                               HASH JOIN RIGHT OUTER          |                               |      1 |    410 | 46357   (1)|    240K|00:00:02.35 |     119K|  22365 |  22365 |
|*108 |                                VIEW                          |                               |      1 |     83 |  8807   (1)|      8 |00:00:00.05 |   26645 |      0 |      0 |
|*109 |                                 WINDOW SORT PUSHED RANK      |                               |      1 |     83 |  8807   (1)|      8 |00:00:00.05 |   26645 |      0 |      0 |
| 110 |                                  NESTED LOOPS                |                               |      1 |     83 |  8806   (1)|      8 |00:00:00.05 |   26645 |      0 |      0 |
| 111 |                                   NESTED LOOPS               |                               |      1 |     83 |  8806   (1)|  15161 |00:00:00.04 |   11484 |      0 |      0 |
|*112 | ID BATCHED                         TABLE ACCESS BY INDEX ROW | G_PIECEDET                    |      1 |     83 |  8640   (1)|  15198 |00:00:00.03 |   10695 |      0 |      0 |
|*113 |                                     INDEX RANGE SCAN         | G_PIECEDET_STR1_IDX           |      1 |  17953 |   135   (1)|  23987 |00:00:00.01 |     108 |      0 |      0 |
|*114 |                                    INDEX UNIQUE SCAN         | AD_CASES_PK                   |  15198 |      1 |     1   (0)|  15161 |00:00:00.01 |     789 |      0 |      0 |
|*115 | D                                 TABLE ACCESS BY INDEX ROWI | AD_CASES                      |  15161 |      1 |     2   (0)|      8 |00:00:00.01 |   15161 |      0 |      0 |
|*116 |                                HASH JOIN RIGHT OUTER         |                               |      1 |    410 | 37549   (1)|    240K|00:00:02.28 |   92398 |  22365 |  22365 |
| 117 |                                 VIEW                         |                               |      1 |      8 |     3  (34)|     14 |00:00:00.01 |       3 |      0 |      0 |
| 118 |                                  HASH GROUP BY               |                               |      1 |      8 |     3  (34)|     14 |00:00:00.01 |       3 |      0 |      0 |
| 119 |                                   TABLE ACCESS STORAGE FULL  | T_EXTERN_CALC_PROV            |      1 |     81 |     2   (0)|     81 |00:00:00.01 |       3 |      0 |      0 |
|*120 |                                 HASH JOIN OUTER              |                               |      1 |    410 | 37546   (1)|    240K|00:00:02.26 |   92395 |  22365 |  22365 |
|*121 |                                  HASH JOIN RIGHT OUTER       |                               |      1 |    410 |  2486  (10)|    240K|00:00:01.42 |   30120 |  13545 |  13545 |
| 122 |                                   TABLE ACCESS STORAGE FULL  | G_RECEIVERSHIP                |      1 |   1954 |     2   (0)|   1954 |00:00:00.01 |      27 |      0 |      0 |
|*123 |                                   HASH JOIN RIGHT OUTER      |                               |      1 |    410 |  2484  (10)|    240K|00:00:01.41 |   30093 |  13545 |  13545 |
|*124 |                                    TABLE ACCESS STORAGE FULL | AD_CLIENT_STATEMENT_HISTORY   |      1 |     70 |   120  (20)|      0 |00:00:00.03 |    3010 |      0 |      0 |
|*125 |                                    HASH JOIN RIGHT OUTER     |                               |      1 |    407 |  2363  (10)|    240K|00:00:01.37 |   27083 |  13545 |  13545 |
|*126 | L                                   TABLE ACCESS STORAGE FUL | V_DOMAINE                     |      1 |   3096 |    67  (11)|   3102 |00:00:00.01 |    1830 |      0 |      0 |
|*127 |                                     HASH JOIN                |                               |      1 |    407 |  2297  (10)|    240K|00:00:01.29 |   25253 |  13545 |  13545 |
| 128 |  FULL                                MAT_VIEW ACCESS STORAGE | AD_ACCOUNT_CLIENT_MVIEW       |      1 |    489 |     2   (0)|    489 |00:00:00.01 |      13 |      0 |      0 |
|*129 |                                      HASH JOIN               |                               |      1 |    396 |  2294  (10)|    240K|00:00:01.26 |   25239 |  13545 |  13545 |
|*130 |                                       HASH JOIN              |                               |      1 |    396 |  2292  (10)|    240K|00:00:00.84 |   25218 |   8127 |   8127 |
| 131 |                                        JOIN FILTER CREATE    | :BF0013                       |      1 |    396 |  1842   (5)|    240K|00:00:00.41 |   15048 |   3087 |   3087 |
|*132 |                                         HASH JOIN            |                               |      1 |    396 |  1842   (5)|    240K|00:00:00.39 |   15048 |   3087 |   3087 |
| 133 |                                          JOIN FILTER CREATE  | :BF0014                       |      1 |    396 |  1671   (4)|    240K|00:00:00.08 |   10511 |      0 |      0 |
|*134 |                                           HASH JOIN          |                               |      1 |    396 |  1671   (4)|    240K|00:00:00.07 |   10511 |      0 |      0 |
| 135 | E                                          JOIN FILTER CREAT | :BF0015                       |      1 |      1 |  1378   (1)|    436 |00:00:00.01 |    2993 |      0 |      0 |
|*136 |                                             HASH JOIN OUTER  |                               |      1 |      1 |  1378   (1)|    436 |00:00:00.01 |    2993 |      0 |      0 |
| 137 | ATE                                          JOIN FILTER CRE | :BF0016                       |      1 |      1 |  1313   (1)|    436 |00:00:00.01 |    1163 |      0 |      0 |
| 138 |                                               NESTED LOOPS   |                               |      1 |      1 |  1313   (1)|    436 |00:00:00.01 |    1163 |      0 |      0 |
| 139 |                                                NESTED LOOPS  |                               |      1 |    436 |  1313   (1)|    436 |00:00:00.01 |     727 |      0 |      0 |
| 140 |  STORAGE FULL                                   TABLE ACCESS | AD_CASE_CONTRAT               |      1 |    436 |     3   (0)|    436 |00:00:00.01 |      38 |      0 |      0 |
|*141 | SCAN                                            INDEX RANGE  | G_PIECE_TYPE_REFDOSS_IDX      |    436 |      1 |     2   (0)|    436 |00:00:00.01 |     689 |      0 |      0 |
| 142 | BY INDEX ROWID                                 TABLE ACCESS  | G_PIECE                       |    436 |      1 |     3   (0)|    436 |00:00:00.01 |     436 |      0 |      0 |
| 143 |                                              JOIN FILTER USE | :BF0016                       |      1 |     13 |    65   (8)|     10 |00:00:00.01 |    1830 |      0 |      0 |
|*144 | TORAGE FULL                                   TABLE ACCESS S | V_DOMAINE                     |      1 |     13 |    65   (8)|     10 |00:00:00.01 |    1830 |      0 |      0 |
| 145 |                                            JOIN FILTER USE   | :BF0015                       |      1 |    240K|   288  (17)|    240K|00:00:00.05 |    7517 |      0 |      0 |
|*146 | RAGE FULL                                   TABLE ACCESS STO | AD_ACCOUNT_DEBTOR_CLIENT      |      1 |    240K|   288  (17)|    240K|00:00:00.04 |    7517 |      0 |      0 |
| 147 |                                          JOIN FILTER USE     | :BF0014                       |      1 |    148K|   167  (14)|    148K|00:00:00.03 |    4536 |      0 |      0 |
|*148 | GE FULL                                   TABLE ACCESS STORA | AD_DEBTORS                    |      1 |    148K|   167  (14)|    148K|00:00:00.03 |    4536 |      0 |      0 |
| 149 |                                        JOIN FILTER USE       | :BF0013                       |      1 |    156K|   447  (29)|    156K|00:00:00.08 |   10169 |      0 |      0 |
|*150 |  FULL                                   TABLE ACCESS STORAGE | G_INDIVIDU                    |      1 |    156K|   447  (29)|    156K|00:00:00.07 |   10169 |      0 |      0 |
| 151 | ULL                                   TABLE ACCESS STORAGE F | AD_CLIENTS                    |      1 |    423 |     2   (0)|    423 |00:00:00.01 |      20 |      0 |      0 |
| 152 |                                  VIEW                        |                               |      1 |   9361 | 35060   (1)|  29108 |00:00:00.19 |   62275 |      0 |      0 |
|*153 |                                   VIEW                       |                               |      1 |   9361 | 35060   (1)|  29108 |00:00:00.19 |   62275 |      0 |      0 |
|*154 |                                    WINDOW SORT PUSHED RANK   |                               |      1 |   9361 | 35060   (1)|  29108 |00:00:00.19 |   62275 |      0 |      0 |
|*155 | WID BATCHED                         TABLE ACCESS BY INDEX RO | AD_LIMITS                     |      1 |   9361 | 35058   (1)|  62419 |00:00:00.14 |   62275 |      0 |      0 |
|*156 |                                      INDEX RANGE SCAN        | AD_LIMIT_DEBTOR_IND           |      1 |  62418 |   231   (2)|  62420 |00:00:00.01 |     273 |      0 |      0 |
| 157 |                            VIEW                              |                               |      1 |   7307 |    17  (36)|    259 |00:00:00.02 |     293 |     38 |      0 |
| 158 |                             HASH UNIQUE                      |                               |      1 |   7307 |    17  (36)|    259 |00:00:00.02 |     293 |     38 |      0 |
| 159 |                              JOIN FILTER USE                 | :BF0011                       |      1 |   8114 |    15  (27)|    259 |00:00:00.02 |     293 |     38 |      0 |
|*160 |                               TABLE ACCESS STORAGE FULL      | G_GROUPINDIVDET               |      1 |   8114 |    15  (27)|    259 |00:00:00.02 |     293 |     38 |      0 |
|*161 |                           VIEW                               |                               |      1 |  20865 | 52105   (1)|  24501 |00:00:00.29 |   51446 |    362 |      0 |
|*162 |                            WINDOW SORT PUSHED RANK           |                               |      1 |  20865 | 52105   (1)|  24501 |00:00:00.29 |   51446 |    362 |      0 |
| 163 |                             NESTED LOOPS                     |                               |      1 |  20865 | 51892   (1)|  24749 |00:00:00.27 |   51446 |    362 |      0 |
| 164 |                              NESTED LOOPS                    |                               |      1 |  20885 | 51892   (1)|  27856 |00:00:00.22 |   23590 |    362 |      0 |
| 165 | TCHED                         TABLE ACCESS BY INDEX ROWID BA | G_PIECEDET                    |      1 |  20885 | 10050   (1)|  27893 |00:00:00.05 |   18850 |      0 |      0 |
|*166 |                                INDEX RANGE SCAN              | G_PIECEDET_STR1_IDX           |      1 |  20885 |   157   (2)|  27893 |00:00:00.01 |     147 |      0 |      0 |
|*167 |                               INDEX UNIQUE SCAN              | AD_CASES_PK                   |  27893 |      1 |     1   (0)|  27856 |00:00:00.16 |    4740 |    362 |      0 |
|*168 |                              TABLE ACCESS BY INDEX ROWID     | AD_CASES                      |  27856 |      1 |     2   (0)|  24749 |00:00:00.04 |   27856 |      0 |      0 |
| 169 |                         VIEW                                 |                               |      1 |  52278 |  7781   (1)|    412 |00:00:00.56 |   14042 |      0 |      0 |
| 170 |                          SORT GROUP BY                       |                               |      1 |  52278 |  7781   (1)|    412 |00:00:00.56 |   14042 |      0 |      0 |
|*171 |                           VIEW                               |                               |      1 |  58912 |  7781   (1)|    531 |00:00:00.56 |   14042 |      0 |      0 |
| 172 |                            JOIN FILTER USE                   | :BF0010                       |      1 |  58912 |  7781   (1)|    531 |00:00:00.56 |   14042 |      0 |      0 |
|*173 |                             WINDOW SORT PUSHED RANK          |                               |      1 |  58912 |  7781   (1)|  31892 |00:00:00.56 |   14042 |      0 |      0 |
|*174 | CHED                         TABLE ACCESS BY INDEX ROWID BAT | G_PIECEDET                    |      1 |  58912 |  7346   (1)|  35001 |00:00:00.51 |   14042 |      0 |      0 |
|*175 |                               INDEX RANGE SCAN               | G_PIECEDET_TYPE_LASTLOAD_IDX  |      1 |  70276 |   353   (1)|  70301 |00:00:00.01 |     229 |      0 |      0 |
| 176 |                       VIEW                                   |                               |      1 |    138K|  4390  (19)|    147K|00:00:00.16 |   92414 |  92408 |      0 |
| 177 |                        HASH GROUP BY                         |                               |      1 |    138K|  4390  (19)|    147K|00:00:00.15 |   92414 |  92408 |      0 |
| 178 |                         JOIN FILTER USE                      | :BF0009                       |      1 |    320K|  3666  (21)|    147K|00:00:00.09 |   92414 |  92408 |      0 |
|*179 |                          MAT_VIEW ACCESS STORAGE FULL        | AD_REQUEST_LIMIT_MVIEW        |      1 |    320K|  3666  (21)|    147K|00:00:00.08 |   92414 |  92408 |      0 |
| 180 |                     VIEW                                     |                               |      1 |    151K|  1241M (10)|    152K|00:01:47.80 |      14M|     13M|    668K|
| 181 |                      SORT GROUP BY                           |                               |      1 |    151K|  1241M (10)|    152K|00:01:47.78 |      14M|     13M|    668K|
| 182 |                       JOIN FILTER USE                        | :BF0008                       |      1 |    254G|  6394K (85)|    107M|00:03:21.86 |      14M|     13M|    668K|
|*183 |                        HASH JOIN OUTER                       |                               |      1 |    254G|  6394K (85)|    107M|00:03:12.35 |      14M|     13M|    668K|
|*184 |                         TABLE ACCESS STORAGE FULL            | NAM_ECR_COMPTA_BAK            |      1 |    107M|   269K (23)|    107M|00:00:30.38 |    6646K|   6646K|      0 |
| 185 |                         VIEW                                 |                               |      1 |     42M|   764K  (8)|    141K|00:01:25.58 |    8352K|   6646K|      0 |
|*186 |                          VIEW                                |                               |      1 |     42M|   764K  (8)|    141K|00:01:16.48 |    6646K|   6646K|      0 |
|*187 |                           WINDOW NOSORT                      |                               |      1 |     42M|   764K  (8)|    141K|00:01:16.45 |    6646K|   6646K|      0 |
| 188 |                            SORT GROUP BY                     |                               |      1 |     42M|   764K  (8)|    141K|00:01:16.35 |    6646K|   6646K|      0 |
|*189 |                             TABLE ACCESS STORAGE FULL        | NAM_ECR_COMPTA_BAK            |      1 |     42M|   251K (18)|     43M|00:00:19.67 |    6646K|   6646K|      0 |
| 190 |                  VIEW                                        |                               |      1 |    154K|   152K  (1)|      0 |00:00:00.01 |       3 |      0 |      0 |
| 191 |                   HASH GROUP BY                              |                               |      1 |    154K|   152K  (1)|      0 |00:00:00.01 |       3 |      0 |      0 |
| 192 |                    JOIN FILTER USE                           | :BF0007                       |      1 |    154K|   151K  (1)|      0 |00:00:00.01 |       3 |      0 |      0 |
|*193 |                     TABLE ACCESS BY INDEX ROWID BATCHED      | AD_FINELEM                    |      1 |    154K|   151K  (1)|      0 |00:00:00.01 |       3 |      0 |      0 |
|*194 |                      INDEX RANGE SCAN                        | AD_FINELEM_PK                 |      1 |    160K|   207   (4)|      0 |00:00:00.01 |       3 |      0 |      0 |
|*195 |                 VIEW                                         |                               |      0 |    128K|  2511  (10)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*196 |                  WINDOW SORT PUSHED RANK                     |                               |      0 |    128K|  2511  (10)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*197 |                   TABLE ACCESS STORAGE FULL                  | UDF_INDIV                     |      0 |    128K|  1384  (15)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 198 |               VIEW                                           |                               |      0 |    113K|  1868   (6)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 199 |                HASH GROUP BY                                 |                               |      0 |    113K|  1868   (6)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*200 |                 VIEW                                         |                               |      0 |    184K|  1868   (6)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 201 |                  JOIN FILTER USE                             | :BF0006                       |      0 |    184K|  1868   (6)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*202 |                   WINDOW SORT PUSHED RANK                    |                               |      0 |    184K|  1868   (6)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*203 |                    TABLE ACCESS STORAGE FULL                 | T_INDIVIDU                    |      0 |    184K|   458  (15)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 204 |             VIEW                                             |                               |      0 |    139K|   149K  (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 205 |              HASH GROUP BY                                   |                               |      0 |    139K|   149K  (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*206 |               VIEW                                           |                               |      0 |    308K|   149K  (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 207 |                JOIN FILTER USE                               | :BF0005                       |      0 |    308K|   149K  (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*208 |                 WINDOW SORT PUSHED RANK                      |                               |      0 |    308K|   149K  (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 209 |                  INLIST ITERATOR                             |                               |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
|*210 |                   TABLE ACCESS BY INDEX ROWID BATCHED        | G_INDIVPARAM                  |      0 |    308K|   146K  (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*211 |                    INDEX RANGE SCAN                          | G_INDPAR_TYPSTR1_IDX          |      0 |    861K|  3328   (2)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 212 |            VIEW                                              |                               |      0 |    156K|  4612  (22)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*213 |             VIEW                                             |                               |      0 |    156K|  4612  (22)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*214 |              WINDOW SORT PUSHED RANK                         |                               |      0 |    156K|  4612  (22)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*215 |               HASH JOIN OUTER                                |                               |      0 |    156K|  2945  (34)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*216 |                TABLE ACCESS STORAGE FULL                     | G_INDIVPARAM                  |      0 |    156K|  2862  (34)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 217 |                MAT_VIEW ACCESS STORAGE FULL                  | AD_KSV_TO_PD_MVIEW            |      0 |    601 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 218 |          VIEW                                                |                               |      0 |    217K|   333K  (8)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*219 |           HASH JOIN OUTER                                    |                               |      0 |    217K|   333K  (8)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*220 |            HASH JOIN RIGHT OUTER                             |                               |      0 |  15608 | 23092   (3)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 221 |             VIEW                                             |                               |      0 |   3176 |  3849   (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 222 |              HASH GROUP BY                                   |                               |      0 |   3176 |  3849   (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 223 |               TABLE ACCESS BY INDEX ROWID BATCHED            | G_GROUPINDIVDET               |      0 |   4736 |  3849   (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*224 |                INDEX FULL SCAN                               | G_GROUPINDIVDET_RFTRPE_IDX    |      0 |   4736 |   108   (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*225 |             HASH JOIN OUTER                                  |                               |      0 |  15608 | 19242   (3)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 226 |              JOIN FILTER CREATE                              | :BF0017                       |      0 |  15608 | 12545   (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*227 |               HASH JOIN                                      |                               |      0 |  15608 | 12545   (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*228 |                TABLE ACCESS STORAGE FULL                     | G_GROUP_REFEXT                |      0 |   4727 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*229 |                HASH JOIN                                     |                               |      0 |  14728 | 12541   (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 230 |                 TABLE ACCESS BY INDEX ROWID BATCHED          | G_GROUPINDIVDET               |      0 |  15736 | 12535   (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*231 |                  INDEX FULL SCAN                             | G_GROUPINDIVDET_RFTRPE_IDX    |      0 |  15736 |   108   (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*232 |                 TABLE ACCESS STORAGE FULL                    | G_GROUPINDIV                  |      0 |   4412 |     5  (20)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 233 |              VIEW                                            |                               |      0 |  67010 |  6695   (8)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 234 |               HASH GROUP BY                                  |                               |      0 |  67010 |  6695   (8)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 235 |                JOIN FILTER USE                               | :BF0017                       |      0 |  67010 |  2637  (18)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*236 |                 HASH JOIN                                    |                               |      0 |  67010 |  2637  (18)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 237 |                  VIEW                                        | VW_GBF_10                     |      0 |  15736 |    10  (40)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 238 |                   HASH GROUP BY                              |                               |      0 |  15736 |    10  (40)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*239 |                    INDEX STORAGE FAST FULL SCAN              | G_GROUPINDIVDET_REF1_IDX      |      0 |  15736 |     7  (15)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*240 |                  VIEW                                        |                               |      0 |  20172 |  2624  (18)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*241 |                   WINDOW SORT PUSHED RANK                    |                               |      0 |  20172 |  2624  (18)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*242 |                    HASH JOIN                                 |                               |      0 |  20172 |  2350  (20)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 243 |                     JOIN FILTER CREATE                       | :BF0018                       |      0 |   4735 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*244 |                      TABLE ACCESS STORAGE FULL               | G_GROUPINDIV                  |      0 |   4735 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 245 |                     JOIN FILTER USE                          | :BF0018                       |      0 |    708K|  2330  (19)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*246 |                      TABLE ACCESS STORAGE FULL               | G_INDIVPARAM                  |      0 |    708K|  2330  (19)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 247 |            VIEW                                              |                               |      0 |  68323 |   310K  (9)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 248 |             NESTED LOOPS                                     |                               |      0 |  68323 |   310K  (9)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*249 |              VIEW                                            |                               |      0 |  25110 |  8697   (2)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*250 |               WINDOW SORT PUSHED RANK                        |                               |      0 |  25110 |  8697   (2)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 251 |                VIEW                                          |                               |      0 |  25110 |  8495   (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 252 |                 HASH GROUP BY                                |                               |      0 |  25110 |  8495   (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*253 |                  HASH JOIN                                   |                               |      0 |  25110 |  8490   (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*254 |                   HASH JOIN                                  |                               |      0 |  21206 |   364  (15)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*255 |                    TABLE ACCESS STORAGE FULL                 | G_GROUPINDIV                  |      0 |   4735 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*256 |                    HASH JOIN                                 |                               |      0 |  21205 |   359  (14)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 257 |                     TABLE ACCESS STORAGE FULL                | AD_ACCOUNT_DEBTOR_CLIENT      |      0 |    240K|   280  (15)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*258 |                     INDEX STORAGE FAST FULL SCAN             | G_GROUPINDIVDET_REF1_IDX      |      0 |  12713 |     7  (15)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 259 |                   INLIST ITERATOR                            |                               |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
|*260 |                    TABLE ACCESS BY INDEX ROWID BATCHED       | NAM_ECR_COMPTA_BAK            |      0 |  62639 |  8124   (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*261 |                     INDEX RANGE SCAN                         | NAM_ECR_COMPTA_BAK_DTJOUR_IDX |      0 |  64589 |   328   (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*262 |              VIEW PUSHED PREDICATE                           |                               |      0 |      1 |    12   (9)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 263 |               WINDOW SORT                                    |                               |      0 |      3 |    12   (9)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*264 |                TABLE ACCESS BY INDEX ROWID BATCHED           | G_INDIVPARAM                  |      0 |      3 |    11   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*265 |                 INDEX RANGE SCAN                             | G_INDIVPARAM_REFIND           |      0 |     10 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 266 |        VIEW                                                  |                               |      0 |    509K| 19990  (10)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 267 |         VIEW                                                 |                               |      0 |    509K| 19990  (10)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 268 |          HASH GROUP BY                                       |                               |      0 |    509K| 19990  (10)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 269 |           VIEW                                               |                               |      0 |    509K| 14768  (12)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 270 |            JOIN FILTER USE                                   | :BF0004                       |      0 |    509K| 14768  (12)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*271 |             HASH JOIN RIGHT OUTER                            |                               |      0 |    509K| 14768  (12)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 272 |              VIEW                                            |                               |      0 |  21372 |    23  (27)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 273 |               HASH GROUP BY                                  |                               |      0 |  21372 |    23  (27)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 274 |                TABLE ACCESS STORAGE FULL                     | G_VENRESTRICTION              |      0 |  21372 |    19  (11)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*275 |              TABLE ACCESS STORAGE FULL                       | AD_FINELEM_3NF                |      0 |    509K| 14734  (12)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 276 |      VIEW                                                    |                               |      0 |    260M|    93M  (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 277 |       HASH GROUP BY                                          |                               |      0 |    260M|    93M  (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*278 |        HASH JOIN RIGHT OUTER                                 |                               |      0 |    260M|  2375K  (2)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*279 |         TABLE ACCESS STORAGE FULL                            | AD_CASES                      |      0 |    240K|   179  (17)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*280 |         HASH JOIN OUTER                                      |                               |      0 |    156M| 56609   (7)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*281 |          VIEW                                                |                               |      0 |    274K| 49093   (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*282 |           WINDOW SORT PUSHED RANK                            |                               |      0 |    274K| 49093   (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 283 |            INLIST ITERATOR                                   |                               |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
| 284 |             TABLE ACCESS BY INDEX ROWID BATCHED              | G_INDIVPARAM                  |      0 |    274K| 46757   (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*285 |              INDEX RANGE SCAN                                | G_INDPAR_TYPSTR1_IDX          |      0 |    274K|  1137   (2)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*286 |          TABLE ACCESS STORAGE FULL                           | AD_CASES                      |      0 |    240K|   178  (17)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*287 |   HASH JOIN RIGHT OUTER                                      |                               |      1 |   2038K|  2349K  (6)|      0 |00:00:00.46 |   45171 |    121 |      0 |
|*288 |    TABLE ACCESS STORAGE FULL                                 | V_DOMAINE                     |      1 |   3096 |    67  (11)|   3102 |00:00:00.01 |    1830 |      0 |      0 |
|*289 |    HASH JOIN RIGHT OUTER                                     |                               |      1 |   2038K|  2349K  (6)|      0 |00:00:00.44 |   43341 |    121 |      0 |
| 290 |     VIEW                                                     |                               |      1 |  12481 | 10728   (1)|     32 |00:00:00.02 |   10718 |      0 |      0 |
|*291 |      VIEW                                                    |                               |      1 |  12481 | 10728   (1)|     32 |00:00:00.02 |   10718 |      0 |      0 |
|*292 |       WINDOW NOSORT                                          |                               |      1 |  12481 | 10728   (1)|  12510 |00:00:00.02 |   10718 |      0 |      0 |
|*293 |        TABLE ACCESS BY INDEX ROWID                           | T_DEVISE                      |      1 |  12481 | 10728   (1)|  12510 |00:00:00.01 |   10718 |      0 |      0 |
|*294 |         INDEX SKIP SCAN DESCENDING                           | T_DEVISE_IX3                  |      1 |  12510 |    34   (3)|  12510 |00:00:00.01 |      42 |      0 |      0 |
|*295 |     HASH JOIN OUTER                                          |                               |      1 |   5227 |  2338K  (6)|      0 |00:00:00.42 |   32623 |    121 |      0 |
|*296 |      HASH JOIN OUTER                                         |                               |      1 |      8 |   556K  (6)|      0 |00:00:00.42 |   32623 |    121 |      0 |
| 297 |       JOIN FILTER CREATE                                     | :BF0019                       |      1 |      1 |   548K  (6)|      0 |00:00:00.42 |   32623 |    121 |      0 |
|*298 |        HASH JOIN OUTER                                       |                               |      1 |      1 |   548K  (6)|      0 |00:00:00.42 |   32623 |    121 |      0 |
|*299 |         HASH JOIN OUTER                                      |                               |      1 |      1 |   215K  (2)|      0 |00:00:00.42 |   32623 |    121 |      0 |
| 300 |          NESTED LOOPS OUTER                                  |                               |      1 |      1 |   166K  (2)|      0 |00:00:00.42 |   32623 |    121 |      0 |
|*301 |           HASH JOIN OUTER                                    |                               |      1 |      1 |   166K  (2)|      0 |00:00:00.42 |   32623 |    121 |      0 |
| 302 |            JOIN FILTER CREATE                                | :BF0020                       |      1 |      1 | 16501   (8)|      0 |00:00:00.42 |   32623 |    121 |      0 |
|*303 |             HASH JOIN OUTER                                  |                               |      1 |      1 | 16501   (8)|      0 |00:00:00.42 |   32623 |    121 |      0 |
| 304 |              JOIN FILTER CREATE                              | :BF0021                       |      1 |      1 | 14630   (8)|      0 |00:00:00.42 |   32623 |    121 |      0 |
|*305 |               HASH JOIN                                      |                               |      1 |      1 | 14630   (8)|      0 |00:00:00.42 |   32623 |    121 |      0 |
| 306 |                JOIN FILTER CREATE                            | :BF0022                       |      1 |      1 | 14628   (8)|      0 |00:00:00.42 |   32623 |    121 |      0 |
|*307 |                 HASH JOIN OUTER                              |                               |      1 |      1 | 14628   (8)|      0 |00:00:00.42 |   32623 |    121 |      0 |
| 308 |                  JOIN FILTER CREATE                          | :BF0023                       |      1 |      1 | 14625   (8)|      0 |00:00:00.42 |   32623 |    121 |      0 |
|*309 |                   HASH JOIN OUTER                            |                               |      1 |      1 | 14625   (8)|      0 |00:00:00.42 |   32623 |    121 |      0 |
|*310 |                    HASH JOIN                                 |                               |      1 |      1 | 10010   (2)|      0 |00:00:00.42 |   32623 |    121 |      0 |
|*311 |                     HASH JOIN OUTER                          |                               |      1 |      1 |  9897   (2)|    489 |00:00:00.40 |   29612 |    121 |      0 |
| 312 |                      JOIN FILTER CREATE                      | :BF0024                       |      1 |      1 |  9832   (2)|    489 |00:00:00.40 |   27782 |    121 |      0 |
|*313 |                       HASH JOIN OUTER                        |                               |      1 |      1 |  9832   (2)|    489 |00:00:00.40 |   27782 |    121 |      0 |
| 314 |                        JOIN FILTER CREATE                    | :BF0025                       |      1 |      1 |  2050   (3)|    489 |00:00:00.29 |   14740 |    121 |      0 |
|*315 |                         HASH JOIN OUTER                      |                               |      1 |      1 |  2050   (3)|    489 |00:00:00.29 |   14740 |    121 |      0 |
| 316 |                          JOIN FILTER CREATE                  | :BF0026                       |      1 |      1 |  2047   (3)|    489 |00:00:00.29 |   14737 |    121 |      0 |
|*317 |                           HASH JOIN OUTER                    |                               |      1 |      1 |  2047   (3)|    489 |00:00:00.29 |   14737 |    121 |      0 |
|*318 |                            HASH JOIN OUTER                   |                               |      1 |      1 |  1723   (4)|    489 |00:00:00.28 |   13007 |    121 |      0 |
| 319 |                             JOIN FILTER CREATE               | :BF0027                       |      1 |      1 |  1318   (1)|    489 |00:00:00.05 |    1992 |    121 |      0 |
| 320 |                              NESTED LOOPS                    |                               |      1 |      1 |  1318   (1)|    489 |00:00:00.05 |    1992 |    121 |      0 |
| 321 |                               NESTED LOOPS                   |                               |      1 |      1 |  1318   (1)|    489 |00:00:00.01 |    1498 |      0 |      0 |
|*322 |                                HASH JOIN                     |                               |      1 |      1 |  1315   (1)|    489 |00:00:00.01 |    1176 |      0 |      0 |
| 323 |                                 JOIN FILTER CREATE           | :BF0028                       |      1 |      1 |  1313   (1)|    436 |00:00:00.01 |    1163 |      0 |      0 |
| 324 |                                  NESTED LOOPS                |                               |      1 |      1 |  1313   (1)|    436 |00:00:00.01 |    1163 |      0 |      0 |
| 325 |                                   NESTED LOOPS               |                               |      1 |    436 |  1313   (1)|    436 |00:00:00.01 |     727 |      0 |      0 |
| 326 |                                    TABLE ACCESS STORAGE FULL | AD_CASE_CONTRAT               |      1 |    436 |     3   (0)|    436 |00:00:00.01 |      38 |      0 |      0 |
|*327 |                                    INDEX RANGE SCAN          | G_PIECE_TYPE_REFDOSS_IDX      |    436 |      1 |     2   (0)|    436 |00:00:00.01 |     689 |      0 |      0 |
| 328 | D                                 TABLE ACCESS BY INDEX ROWI | G_PIECE                       |    436 |      1 |     3   (0)|    436 |00:00:00.01 |     436 |      0 |      0 |
| 329 |                                 JOIN FILTER USE              | :BF0028                       |      1 |    489 |     2   (0)|    489 |00:00:00.01 |      13 |      0 |      0 |
|*330 | L                                MAT_VIEW ACCESS STORAGE FUL | AD_ACCOUNT_CLIENT_MVIEW       |      1 |    489 |     2   (0)|    489 |00:00:00.01 |      13 |      0 |      0 |
|*331 |                                INDEX RANGE SCAN              | G_PIECE_TYPE_REFDOSS_IDX      |    489 |      1 |     2   (0)|    489 |00:00:00.01 |     322 |      0 |      0 |
| 332 |                               TABLE ACCESS BY INDEX ROWID    | G_PIECE                       |    489 |      1 |     3   (0)|    489 |00:00:00.04 |     494 |    121 |      0 |
| 333 |                             JOIN FILTER USE                  | :BF0027                       |      1 |    241K|   399  (12)|   2220 |00:00:00.23 |   11015 |      0 |      0 |
|*334 |                              TABLE ACCESS STORAGE FULL       | T_INTERVENANTS                |      1 |    241K|   399  (12)|   2220 |00:00:00.23 |   11015 |      0 |      0 |
|*335 |                            VIEW                              |                               |      1 |   1878 |   324   (1)|   1795 |00:00:00.01 |    1730 |      0 |      0 |
|*336 |                             WINDOW SORT PUSHED RANK          |                               |      1 |   1878 |   324   (1)|   1795 |00:00:00.01 |    1730 |      0 |      0 |
| 337 |                              INLIST ITERATOR                 |                               |      1 |        |            |   2667 |00:00:00.01 |    1730 |      0 |      0 |
| 338 | TCHED                         TABLE ACCESS BY INDEX ROWID BA | G_INDIVPARAM                  |      2 |   1878 |   323   (1)|   2667 |00:00:00.01 |    1730 |      0 |      0 |
|*339 |                                INDEX RANGE SCAN              | G_INDPAR_TYPSTR1_IDX          |      2 |   1878 |    10   (0)|   2667 |00:00:00.01 |      18 |      0 |      0 |
| 340 |                          VIEW                                |                               |      1 |      8 |     3  (34)|     14 |00:00:00.01 |       3 |      0 |      0 |
| 341 |                           HASH GROUP BY                      |                               |      1 |      8 |     3  (34)|     14 |00:00:00.01 |       3 |      0 |      0 |
| 342 |                            JOIN FILTER USE                   | :BF0026                       |      1 |     81 |     2   (0)|     81 |00:00:00.01 |       3 |      0 |      0 |
|*343 |                             TABLE ACCESS STORAGE FULL        | T_EXTERN_CALC_PROV            |      1 |     81 |     2   (0)|     81 |00:00:00.01 |       3 |      0 |      0 |
| 344 |                        VIEW                                  |                               |      1 |  52278 |  7781   (1)|    418 |00:00:00.11 |   13042 |      0 |      0 |
| 345 |                         SORT GROUP BY                        |                               |      1 |  52278 |  7781   (1)|    418 |00:00:00.11 |   13042 |      0 |      0 |
|*346 |                          VIEW                                |                               |      1 |  58912 |  7781   (1)|    537 |00:00:00.11 |   13042 |      0 |      0 |
| 347 |                           JOIN FILTER USE                    | :BF0025                       |      1 |  58912 |  7781   (1)|    537 |00:00:00.11 |   13042 |      0 |      0 |
|*348 |                            WINDOW SORT PUSHED RANK           |                               |      1 |  58912 |  7781   (1)|  31892 |00:00:00.11 |   13042 |      0 |      0 |
|*349 | HED                         TABLE ACCESS BY INDEX ROWID BATC | G_PIECEDET                    |      1 |  58912 |  7346   (1)|  35001 |00:00:00.06 |   13042 |      0 |      0 |
|*350 |                              INDEX RANGE SCAN                | G_PIECEDET_TYPE_LASTLOAD_IDX  |      1 |  70276 |   353   (1)|  70301 |00:00:00.01 |     229 |      0 |      0 |
| 351 |                      JOIN FILTER USE                         | :BF0024                       |      1 |     13 |    65   (8)|     10 |00:00:00.01 |    1830 |      0 |      0 |
|*352 |                       TABLE ACCESS STORAGE FULL              | V_DOMAINE                     |      1 |     13 |    65   (8)|     10 |00:00:00.01 |    1830 |      0 |      0 |
| 353 |                     VIEW                                     |                               |      1 |    203 |   113  (15)|      0 |00:00:00.02 |    3011 |      0 |      0 |
|*354 |                      VIEW                                    |                               |      1 |    203 |   113  (15)|      0 |00:00:00.02 |    3011 |      0 |      0 |
|*355 |                       WINDOW SORT PUSHED RANK                |                               |      1 |    203 |   113  (15)|      0 |00:00:00.02 |    3011 |      0 |      0 |
|*356 |                        TABLE ACCESS STORAGE FULL             | AD_CLIENT_STATEMENT_HISTORY   |      1 |    203 |   112  (14)|      0 |00:00:00.02 |    3011 |      0 |      0 |
| 357 |                    VIEW                                      |                               |      0 |    156K|  4612  (22)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*358 |                     VIEW                                     |                               |      0 |    156K|  4612  (22)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*359 |                      WINDOW SORT PUSHED RANK                 |                               |      0 |    156K|  4612  (22)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*360 |                       HASH JOIN OUTER                        |                               |      0 |    156K|  2945  (34)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*361 |                        TABLE ACCESS STORAGE FULL             | G_INDIVPARAM                  |      0 |    156K|  2862  (34)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 362 |                        MAT_VIEW ACCESS STORAGE FULL          | AD_KSV_TO_PD_MVIEW            |      0 |    601 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 363 |                  JOIN FILTER USE                             | :BF0023                       |      0 |   1954 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*364 |                   TABLE ACCESS STORAGE FULL                  | G_RECEIVERSHIP                |      0 |   1954 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 365 |                JOIN FILTER USE                               | :BF0022                       |      0 |    423 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*366 |                 TABLE ACCESS STORAGE FULL                    | AD_CLIENTS                    |      0 |    423 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 367 |              VIEW                                            |                               |      0 |    113K|  1868   (6)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 368 |               HASH GROUP BY                                  |                               |      0 |    113K|  1868   (6)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*369 |                VIEW                                          |                               |      0 |    184K|  1868   (6)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 370 |                 JOIN FILTER USE                              | :BF0021                       |      0 |    184K|  1868   (6)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*371 |                  WINDOW SORT PUSHED RANK                     |                               |      0 |    184K|  1868   (6)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*372 |                   TABLE ACCESS STORAGE FULL                  | T_INDIVIDU                    |      0 |    184K|   458  (15)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 373 |            VIEW                                              |                               |      0 |    139K|   149K  (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 374 |             HASH GROUP BY                                    |                               |      0 |    139K|   149K  (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*375 |              VIEW                                            |                               |      0 |    308K|   149K  (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 376 |               JOIN FILTER USE                                | :BF0020                       |      0 |    308K|   149K  (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*377 |                WINDOW SORT PUSHED RANK                       |                               |      0 |    308K|   149K  (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 378 |                 INLIST ITERATOR                              |                               |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
|*379 |                  TABLE ACCESS BY INDEX ROWID BATCHED         | G_INDIVPARAM                  |      0 |    308K|   146K  (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*380 |                   INDEX RANGE SCAN                           | G_INDPAR_TYPSTR1_IDX          |      0 |    861K|  3328   (2)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 381 |           TABLE ACCESS BY INDEX ROWID                        | G_INDIVIDU                    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*382 |            INDEX UNIQUE SCAN                                 | G_INDIVIDU_PK                 |      0 |      1 |     0   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 383 |          VIEW                                                |                               |      0 |    272K| 48774   (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*384 |           VIEW                                               |                               |      0 |    272K| 48774   (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*385 |            WINDOW SORT PUSHED RANK                           |                               |      0 |    272K| 48774   (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 386 |             INLIST ITERATOR                                  |                               |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
| 387 |              TABLE ACCESS BY INDEX ROWID BATCHED             | G_INDIVPARAM                  |      0 |    272K| 46455   (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*388 |               INDEX RANGE SCAN                               | G_INDPAR_TYPSTR1_IDX          |      0 |    272K|  1148   (2)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 389 |         VIEW                                                 |                               |      0 |    217K|   333K  (8)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*390 |          HASH JOIN OUTER                                     |                               |      0 |    217K|   333K  (8)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*391 |           HASH JOIN RIGHT OUTER                              |                               |      0 |  15608 | 23092   (3)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 392 |            VIEW                                              |                               |      0 |   3176 |  3849   (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 393 |             HASH GROUP BY                                    |                               |      0 |   3176 |  3849   (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 394 |              TABLE ACCESS BY INDEX ROWID BATCHED             | G_GROUPINDIVDET               |      0 |   4736 |  3849   (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*395 |               INDEX FULL SCAN                                | G_GROUPINDIVDET_RFTRPE_IDX    |      0 |   4736 |   108   (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*396 |            HASH JOIN OUTER                                   |                               |      0 |  15608 | 19242   (3)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 397 |             JOIN FILTER CREATE                               | :BF0029                       |      0 |  15608 | 12545   (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*398 |              HASH JOIN                                       |                               |      0 |  15608 | 12545   (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*399 |               TABLE ACCESS STORAGE FULL                      | G_GROUP_REFEXT                |      0 |   4727 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*400 |               HASH JOIN                                      |                               |      0 |  14728 | 12541   (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 401 |                TABLE ACCESS BY INDEX ROWID BATCHED           | G_GROUPINDIVDET               |      0 |  15736 | 12535   (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*402 |                 INDEX FULL SCAN                              | G_GROUPINDIVDET_RFTRPE_IDX    |      0 |  15736 |   108   (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*403 |                TABLE ACCESS STORAGE FULL                     | G_GROUPINDIV                  |      0 |   4412 |     5  (20)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 404 |             VIEW                                             |                               |      0 |  67010 |  6695   (8)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 405 |              HASH GROUP BY                                   |                               |      0 |  67010 |  6695   (8)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 406 |               JOIN FILTER USE                                | :BF0029                       |      0 |  67010 |  2637  (18)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*407 |                HASH JOIN                                     |                               |      0 |  67010 |  2637  (18)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 408 |                 VIEW                                         | VW_GBF_20                     |      0 |  15736 |    10  (40)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 409 |                  HASH GROUP BY                               |                               |      0 |  15736 |    10  (40)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*410 |                   INDEX STORAGE FAST FULL SCAN               | G_GROUPINDIVDET_REF1_IDX      |      0 |  15736 |     7  (15)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*411 |                 VIEW                                         |                               |      0 |  20172 |  2624  (18)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*412 |                  WINDOW SORT PUSHED RANK                     |                               |      0 |  20172 |  2624  (18)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*413 |                   HASH JOIN                                  |                               |      0 |  20172 |  2350  (20)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 414 |                    JOIN FILTER CREATE                        | :BF0030                       |      0 |   4735 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*415 |                     TABLE ACCESS STORAGE FULL                | G_GROUPINDIV                  |      0 |   4735 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 416 |                    JOIN FILTER USE                           | :BF0030                       |      0 |    708K|  2330  (19)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*417 |                     TABLE ACCESS STORAGE FULL                | G_INDIVPARAM                  |      0 |    708K|  2330  (19)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 418 |           VIEW                                               |                               |      0 |  68323 |   310K  (9)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 419 |            NESTED LOOPS                                      |                               |      0 |  68323 |   310K  (9)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*420 |             VIEW                                             |                               |      0 |  25110 |  8697   (2)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*421 |              WINDOW SORT PUSHED RANK                         |                               |      0 |  25110 |  8697   (2)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 422 |               VIEW                                           |                               |      0 |  25110 |  8495   (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 423 |                HASH GROUP BY                                 |                               |      0 |  25110 |  8495   (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*424 |                 HASH JOIN                                    |                               |      0 |  25110 |  8490   (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*425 |                  HASH JOIN                                   |                               |      0 |  21206 |   364  (15)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*426 |                   TABLE ACCESS STORAGE FULL                  | G_GROUPINDIV                  |      0 |   4735 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*427 |                   HASH JOIN                                  |                               |      0 |  21205 |   359  (14)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 428 |                    TABLE ACCESS STORAGE FULL                 | AD_ACCOUNT_DEBTOR_CLIENT      |      0 |    240K|   280  (15)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*429 |                    INDEX STORAGE FAST FULL SCAN              | G_GROUPINDIVDET_REF1_IDX      |      0 |  12713 |     7  (15)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 430 |                  INLIST ITERATOR                             |                               |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
|*431 |                   TABLE ACCESS BY INDEX ROWID BATCHED        | NAM_ECR_COMPTA_BAK            |      0 |  62639 |  8124   (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*432 |                    INDEX RANGE SCAN                          | NAM_ECR_COMPTA_BAK_DTJOUR_IDX |      0 |  64589 |   328   (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*433 |             VIEW PUSHED PREDICATE                            |                               |      0 |      1 |    12   (9)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 434 |              WINDOW SORT                                     |                               |      0 |      3 |    12   (9)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*435 |               TABLE ACCESS BY INDEX ROWID BATCHED            | G_INDIVPARAM                  |      0 |      3 |    11   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*436 |                INDEX RANGE SCAN                              | G_INDIVPARAM_REFIND           |      0 |     10 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 437 |       VIEW                                                   |                               |      0 |    209K|  7251  (22)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 438 |        HASH GROUP BY                                         |                               |      0 |    209K|  7251  (22)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 439 |         JOIN FILTER USE                                      | :BF0019                       |      0 |    209K|  7215  (22)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*440 |          HASH JOIN                                           |                               |      0 |    209K|  7215  (22)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 441 |           VIEW                                               |                               |      0 |    418 |     3  (34)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 442 |            HASH UNIQUE                                       |                               |      0 |    418 |     3  (34)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*443 |             TABLE ACCESS STORAGE FULL                        | F_PARFAC                      |      0 |    552 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*444 |           HASH JOIN                                          |                               |      0 |    217K|  7207  (22)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*445 |            TABLE ACCESS STORAGE FULL                         | F_DETFAC                      |      0 |    217K|  6583  (23)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 446 |            VIEW                                              |                               |      0 |    241K|   369  (20)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 447 |             UNION-ALL                                        |                               |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
|*448 |              TABLE ACCESS STORAGE FULL                       | AD_CASES                      |      0 |    241K|   184  (20)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*449 |              TABLE ACCESS STORAGE FULL                       | AD_CASES                      |      0 |     28 |   185  (20)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 450 |      VIEW                                                    |                               |      0 |    107M|  1780K  (6)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*451 |       VIEW                                                   |                               |      0 |    107M|  1780K  (6)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*452 |        WINDOW NOSORT                                         |                               |      0 |    107M|  1780K  (6)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 453 |         SORT GROUP BY                                        |                               |      0 |    107M|  1780K  (6)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*454 |          TABLE ACCESS STORAGE FULL                           | NAM_ECR_COMPTA_BAK            |      0 |    107M|   272K (24)|      0 |00:00:00.01 |       0 |      0 |      0 |
---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   3 - access("EX_RATE"."ORIGINE"="DBCL"."DEVISE")
   5 - filter("RNK"=1)
   6 - filter(ROW_NUMBER() OVER ( PARTITION BY "ORIGINE" ORDER BY INTERNAL_FUNCTION("T"."DTDEBUT_DT") DESC )<=1)
   7 - filter(("T"."TYPE"='MR' AND "T"."PLACE"='AUT' AND NVL("T"."DESTINATION",'EUR')='EUR'))
   8 - access("T"."DTDEBUT_DT"<=SYSDATE@!)
       filter("T"."DTDEBUT_DT"<=SYSDATE@!)
   9 - access("EXT"."REFDOSS"="DBCL"."REFDOSS")
  10 - access("POLICE"."COMPTE_CASE"="DBCL"."REFDOSS")
  17 - access("DBCL"."DEBTOR"="F"."DEBTOR_REFINDIVIDU" AND "F"."DEBTOR_PAYS"="C"."STR1")
  19 - access("DBCL"."REFDOSS"="B"."REFDOSS")
  25 - filter("B"."REFDOSS" IS NOT NULL)
  26 - access("B"."TYPPIECE"='COMPTE')
  27 - filter(("C"."STR1" IS NOT NULL AND NVL("C"."DT02_DT",SYSDATE@!)>=SYSDATE@!))
  28 - access("C"."TYPE"='ASSURANCE_CREDIT' AND "B"."REFPIECE"="C"."REFPIECE" AND "C"."DT01_DT"<=SYSDATE@!)
  29 - filter("D"."REFDOSS" IS NOT NULL)
  30 - access("D"."TYPPIECE"='POLICE' AND "D"."REFPIECE"=NVL("C"."STR7","C"."STR9"))
  31 - access("D"."REFDOSS"="E"."REFDOSS")
  34 - storage(SYS_OP_BLOOM_FILTER(:BF0001,"DBCL"."REFDOSS"))
       filter(SYS_OP_BLOOM_FILTER(:BF0001,"DBCL"."REFDOSS"))
  36 - storage(SYS_OP_BLOOM_FILTER(:BF0000,"F"."DEBTOR_REFINDIVIDU","F"."DEBTOR_PAYS"))
       filter(SYS_OP_BLOOM_FILTER(:BF0000,"F"."DEBTOR_REFINDIVIDU","F"."DEBTOR_PAYS"))
  37 - access("DBCL"."DEBTOR_REF"="F"."DEBTOR_REFINDIVIDU" AND "F"."DEBTOR_PAYS"="C"."STR1")
  39 - access("B"."REFDOSS"="DBCL"."CONTRACT_CASE")
  45 - filter("B"."REFDOSS" IS NOT NULL)
  46 - access("B"."TYPPIECE"='CONTRAT')
  47 - filter(("C"."STR1" IS NOT NULL AND NVL("C"."DT02_DT",SYSDATE@!)>=SYSDATE@!))
  48 - access("C"."TYPE"='ASSURANCE_CREDIT' AND "B"."REFPIECE"="C"."REFPIECE" AND "C"."DT01_DT"<=SYSDATE@!)
  49 - filter("D"."REFDOSS" IS NOT NULL)
  50 - access("D"."TYPPIECE"='POLICE' AND "D"."REFPIECE"=NVL("C"."STR7","C"."STR9"))
  51 - access("D"."REFDOSS"="E"."REFDOSS")
  54 - storage(("DBCL"."CATEGDOSS"='COMPTE' AND SYS_OP_BLOOM_FILTER(:BF0003,"DBCL"."CONTRACT_CASE")))
       filter(("DBCL"."CATEGDOSS"='COMPTE' AND SYS_OP_BLOOM_FILTER(:BF0003,"DBCL"."CONTRACT_CASE")))
  56 - storage(SYS_OP_BLOOM_FILTER(:BF0002,"F"."DEBTOR_REFINDIVIDU","F"."DEBTOR_PAYS"))
       filter(SYS_OP_BLOOM_FILTER(:BF0002,"F"."DEBTOR_REFINDIVIDU","F"."DEBTOR_PAYS"))
  57 - access("MAX_OVERDUE"."FI_REFDOSS"="DBCL"."REFDOSS")
  59 - access("DB"."DEBTOR_REFINDIVIDU"="GRPNEW"."DEBTOR")
  60 - access("GFL"."REFINDIVIDU"="DB"."DEBTOR_REFINDIVIDU")
  62 - filter("COMM"."RNK"=1)
  63 - filter(ROW_NUMBER() OVER ( PARTITION BY "C"."REFINDIVIDU" ORDER BY INTERNAL_FUNCTION("C"."IMX_UN_ID") DESC )<=1)
  65 - access("C"."TYPE"='DEBTOR_GFL_LIM_PARAM')
  66 - access("PD_LGD"."REFINDIVIDU"="DBCL"."DEBTOR")
  67 - access("KSV_EBS_RATE"."REFINDIVIDU"="DB"."DEBTOR_REFINDIVIDU")
  69 - access("T1"."REFINDIVIDU"="DB"."DEBTOR_REFINDIVIDU")
  71 - access("UDF_INDIV"."REFINDIVIDU"="DB"."DEBTOR_REFINDIVIDU")
  72 - access("PORT_DBCL"."REFDOSS"="DBCL"."REFDOSS")
  74 - access("RATE_CONTR"."CONTRACT_CASE"="CTR"."REFDOSS")
  75 - filter("RATE_CONTR"."RNK"=1)
  76 - filter(ROW_NUMBER() OVER ( PARTITION BY "GP"."REFDOSS" ORDER BY INTERNAL_FUNCTION("GP"."IMX_UN_ID") DESC )<=1)
  77 - access("GP"."REFDOSS"="CNT"."CONTRACT_CASE")
  79 - access("GP"."TYPE"='COVERAGE_RATE')
       filter("GP"."REFDOSS" IS NOT NULL)
  81 - access("CNT"."CATEGDOSS" LIKE 'CONTRAT%')
       filter("CNT"."CATEGDOSS" LIKE 'CONTRAT%')
  82 - access("COMPTA_BAK"."REFDOSS"="DBCL"."REFDOSS")
  84 - access("REDEBTOR_AMT"."GPIADR3"="DB"."DEBTOR_REFINDIVIDU")
  86 - access("INS_QUALITY"."REFDOSS"="CTR_CASE"."REFDOSS")
  88 - access("RATE_DBCL"."REFDOSS"="DBCL"."REFDOSS")
  89 - access("NEU_GRU"."REF1"="DB"."DEBTOR_REFINDIVIDU")
  91 - access("REDEC_AMT"."REFDOSS"="DBCL"."REFDOSS")
  94 - access("A"."REFPIECE"="B"."LIBELLE_20_12")
  96 - storage(("B"."LIBELLE_20_12" IS NOT NULL AND "B"."TYPEDOC"='C' AND "B"."FG05"='O'))
       filter(("B"."LIBELLE_20_12" IS NOT NULL AND "B"."TYPEDOC"='C' AND "B"."FG05"='O'))
  98 - storage(SYS_OP_BLOOM_FILTER(:BF0012,"A"."REFPIECE"))
       filter(SYS_OP_BLOOM_FILTER(:BF0012,"A"."REFPIECE"))
  99 - access("CNT_RATE"."CONTRACT_CASE"="CTR"."REFDOSS")
100 - filter("CNT_RATE"."RNK"=1)
101 - filter(ROW_NUMBER() OVER ( PARTITION BY "GP"."REFDOSS" ORDER BY INTERNAL_FUNCTION("GP"."IMX_UN_ID") DESC )<=1)
102 - access("GP"."REFDOSS"="CNT"."CONTRACT_CASE")
103 - filter(("GP"."STR2"='PDEF' AND "GP"."REFDOSS" IS NOT NULL AND "MT01" IS NOT NULL))
104 - access("GP"."TYPE"='FINRATE')
106 - access("CNT"."CATEGDOSS" LIKE 'CONTRAT%')
       filter("CNT"."CATEGDOSS" LIKE 'CONTRAT%')
107 - access("COMPTE_RATE"."REFDOSS"="DBCL"."REFDOSS")
108 - filter("COMPTE_RATE"."RNK"=1)
109 - filter(ROW_NUMBER() OVER ( PARTITION BY "GP"."REFDOSS" ORDER BY INTERNAL_FUNCTION("GP"."IMX_UN_ID") DESC )<=1)
112 - filter(("GP"."STR2"='PDEF' AND "MT01" IS NOT NULL))
113 - access("GP"."TYPE"='FINRATE')
       filter("GP"."REFDOSS" IS NOT NULL)
114 - access("GP"."REFDOSS"="COMPTE"."REFDOSS")
115 - filter("COMPTE"."CATEGDOSS" LIKE 'COMPTE%')
116 - access("EBV"."REFINDIVIDU"="DBCL"."DEBTOR")
120 - access("DBCL"."DEBTOR"="C_LIMIT"."DEBTOR" AND "DBCL"."CLIENT"="C_LIMIT"."CLIENT" AND "DBCL"."ANCREFDOSS"="C_LIMIT"."CONTRACT_NUMBER")
121 - access("RECEI"."REFINDIVIDU"="CL"."CLIENT_REFINDIVIDU")
123 - access("CL_ACCOUNT_CASE"="DBCL"."REFLOT")
124 - storage(("DATE_ID"=TO_NUMBER(TO_CHAR(SYSDATE@!,'j')) AND "MEMO_SOURCE"=DECODE("EXIST_EOM_DATA",1,'E','A') AND INTERNAL_FUNCTION("MEMO_SOURCE")))
       filter(("DATE_ID"=TO_NUMBER(TO_CHAR(SYSDATE@!,'j')) AND "MEMO_SOURCE"=DECODE("EXIST_EOM_DATA",1,'E','A') AND INTERNAL_FUNCTION("MEMO_SOURCE")))
125 - access("V"."ABREV"=COALESCE(CASE  WHEN NVL("GI"."DRI_INDUSTRY_CODE",'_UNBEK')<>'_UNBEK' THEN "GI"."DRI_INDUSTRY_CODE" ELSE NULL END ,CASE  WHEN
              (NVL("GI"."STR44",'_UNBEK')<>'_UNBEKANNT' AND NVL("GI"."STR44",'_UNBEK')<>'_UNBEK') THEN "GI"."STR44" ELSE NULL END ,"DB"."STR15"))
126 - storage(("V"."TYPE"='DRI_INDUSTRY' OR "V"."TYPE"='DRI_NACE_CODE' OR "V"."TYPE"='T.NAF'))
       filter(("V"."TYPE"='DRI_INDUSTRY' OR "V"."TYPE"='DRI_NACE_CODE' OR "V"."TYPE"='T.NAF'))
127 - access("DBCL"."REFLOT"="CL_ACC"."REFDOSS")
129 - access("DBCL"."CLIENT"="CL"."CLIENT_REFINDIVIDU")
130 - access("GI"."REFINDIVIDU"="DBCL"."DEBTOR")
132 - access("DBCL"."DEBTOR"="DB"."DEBTOR_REFINDIVIDU")
134 - access("DBCL"."CONTRACT"="CTR_CASE"."REFDOSS")
136 - access("LOV_CNT"."ABREV"="CTR"."GPIOBJET")
141 - access("CTR"."TYPPIECE"='CONTRAT' AND "CTR"."REFDOSS"="CTR_CASE"."REFDOSS")
       filter("CTR"."REFDOSS" IS NOT NULL)
144 - storage(("LOV_CNT"."TYPE"='CONTRTYP' AND SYS_OP_BLOOM_FILTER(:BF0016,"LOV_CNT"."ABREV")))
       filter(("LOV_CNT"."TYPE"='CONTRTYP' AND SYS_OP_BLOOM_FILTER(:BF0016,"LOV_CNT"."ABREV")))
146 - storage(SYS_OP_BLOOM_FILTER(:BF0015,"DBCL"."CONTRACT"))
       filter(SYS_OP_BLOOM_FILTER(:BF0015,"DBCL"."CONTRACT"))
148 - storage(SYS_OP_BLOOM_FILTER(:BF0014,"DB"."DEBTOR_REFINDIVIDU"))
       filter(SYS_OP_BLOOM_FILTER(:BF0014,"DB"."DEBTOR_REFINDIVIDU"))
150 - storage(SYS_OP_BLOOM_FILTER(:BF0013,"GI"."REFINDIVIDU"))
       filter(SYS_OP_BLOOM_FILTER(:BF0013,"GI"."REFINDIVIDU"))
153 - filter("RN"=1)
154 - filter(ROW_NUMBER() OVER ( PARTITION BY "DEBTOR","CONTRACT_NUMBER" ORDER BY INTERNAL_FUNCTION("IMX_UN_ID") DESC )<=1)
155 - filter("A"."REFEXT"='COM')
156 - access("A"."LIMIT_TYPE"='C')
160 - storage(("FG04"='O' AND SYS_OP_BLOOM_FILTER(:BF0011,"REF1")))
       filter(("FG04"='O' AND SYS_OP_BLOOM_FILTER(:BF0011,"REF1")))
161 - filter("RATE_DBCL"."RNK"=1)
162 - filter(ROW_NUMBER() OVER ( PARTITION BY "GP"."REFDOSS" ORDER BY INTERNAL_FUNCTION("GP"."IMX_UN_ID") DESC )<=1)
166 - access("GP"."TYPE"='COVERAGE_RATE')
       filter("GP"."REFDOSS" IS NOT NULL)
167 - access("GP"."REFDOSS"="COMPTE"."REFDOSS")
168 - filter("COMPTE"."CATEGDOSS" LIKE 'COMPTE%')
171 - filter("A"."RN"=1)
173 - filter(ROW_NUMBER() OVER ( PARTITION BY "GP"."REFDOSS","GP"."LIB2" ORDER BY INTERNAL_FUNCTION("IMX_UN_ID") DESC )<=1)
174 - filter(("GP"."LIB2"='INSUR' OR "GP"."LIB2"='VERSITAT'))
175 - access("GP"."TYPE"='UDF')
179 - storage(("B"."TYPEDOC"='GFL' AND "B"."FG05"='O' AND SYS_OP_BLOOM_FILTER(:BF0009,"B"."GPIADR3")))
       filter(("B"."TYPEDOC"='GFL' AND "B"."FG05"='O' AND SYS_OP_BLOOM_FILTER(:BF0009,"B"."GPIADR3")))
183 - access("GL_AMT"."REFDOSS"="OPDB"."REFDOSS")
184 - storage(("GL_AMT"."REFDOSS" IS NOT NULL AND "GL_AMT"."DTJOUR"<SYSDATE@!+1))
       filter(("GL_AMT"."REFDOSS" IS NOT NULL AND "GL_AMT"."DTJOUR"<SYSDATE@!+1))
186 - filter("OP"."RNK"=1)
187 - filter(ROW_NUMBER() OVER ( PARTITION BY "REFDOSS" ORDER BY "EXTREF9")<=1)
189 - storage((INTERNAL_FUNCTION("CODEOPER") AND "REFDOSS" IS NOT NULL AND "DTJOUR"<SYSDATE@!+1))
       filter((INTERNAL_FUNCTION("CODEOPER") AND "REFDOSS" IS NOT NULL AND "DTJOUR"<SYSDATE@!+1))
193 - filter(("FI"."FI_ACTIF"='O' AND INTERNAL_FUNCTION("FI"."FI_TYPE")))
194 - access("FI"."DATE_ID"=TO_NUMBER(TO_CHAR(SYSDATE@!,'j')))
195 - filter("UDF_INDIV"."RNK"=1)
196 - filter(ROW_NUMBER() OVER ( PARTITION BY "REFINDIVIDU" ORDER BY INTERNAL_FUNCTION("DT_MAJ_DT") DESC )<=1)
197 - storage("VALEUR_REF_INDIV"='FINREP COUNTERPARTY')
       filter("VALEUR_REF_INDIV"='FINREP COUNTERPARTY')
200 - filter("A"."RNK"=1)
202 - filter(ROW_NUMBER() OVER ( PARTITION BY "TI"."REFINDIVIDU","TI"."SOCIETE" ORDER BY INTERNAL_FUNCTION("TI"."IMX_UN_ID") DESC )<=1)
203 - storage(("TI"."SOCIETE"='KUKURZ' OR "TI"."SOCIETE"='National bank code ID OeNB'))
       filter(("TI"."SOCIETE"='KUKURZ' OR "TI"."SOCIETE"='National bank code ID OeNB'))
206 - filter("KSV_EBS"."RNK"=1)
208 - filter(ROW_NUMBER() OVER ( PARTITION BY "KSV"."REFINDIVIDU","KSV"."STR1" ORDER BY INTERNAL_FUNCTION("KSV"."IMX_UN_ID") DESC )<=1)
210 - filter((NVL("KSV"."DT07_DT",SYSDATE@!)>=TRUNC(SYSDATE@!) AND "KSV"."DT09_DT"<=TRUNC(SYSDATE@!)))
211 - access((("KSV"."TYPE"='COTE FACTOR' OR "KSV"."TYPE"='COTE FACTOR HIS')) AND (("KSV"."STR1"='EBS' OR "KSV"."STR1"='KSV')))
213 - filter("RNK"=1)
214 - filter(ROW_NUMBER() OVER ( PARTITION BY "GPARAM"."REFINDIVIDU" ORDER BY INTERNAL_FUNCTION("GPARAM"."IMX_UN_ID") DESC )<=1)
215 - access("PD"."DETNUM"=TO_NUMBER(NVL("GPARAM"."STR2",'0')))
216 - storage(("GPARAM"."STR1"='KSV' AND INTERNAL_FUNCTION("GPARAM"."TYPE")))
       filter(("GPARAM"."STR1"='KSV' AND INTERNAL_FUNCTION("GPARAM"."TYPE") AND NVL("GPARAM"."DT07_DT",SYSDATE@!)>=TRUNC(SYSDATE@!) AND "GPARAM"."DT09_DT"<=TRUNC(SYSDATE@!)))
219 - access("GRP"."REFGROUPE"="GRISK"."REFGROUPE")
220 - access("GRP"."REFGROUPE"="GRICOS"."REFGROUPE")
224 - access("B"."TYPE"='DEBTOR_GRP_DGGFL_LIM_PARAM')
       filter("B"."TYPE"='DEBTOR_GRP_DGGFL_LIM_PARAM')
225 - access("GRP"."REFGROUPE"="GIDET"."REFGROUPE" AND "GPRDET"."REF1"="GIDET"."DEBROR")
227 - access("GEXT"."REFGROUPE"="GRP"."REFGROUPE")
228 - storage("GEXT"."REFEXT_TYPE"='OeNB group number')
       filter("GEXT"."REFEXT_TYPE"='OeNB group number')
229 - access("GPRDET"."REFGROUPE"="GRP"."REFGROUPE")
231 - access("GPRDET"."TYPE"='LIST')
       filter("GPRDET"."TYPE"='LIST')
232 - storage(("GRP"."DTDEACT_DT" IS NULL AND "GRP"."TYPE"='DEBITEURS'))
       filter(("GRP"."DTDEACT_DT" IS NULL AND "GRP"."TYPE"='DEBITEURS'))
236 - access("LEA"."REFGROUPE"="ITEM_1")
239 - storage("GPRDET"."TYPE"='LIST')
       filter("GPRDET"."TYPE"='LIST')
240 - filter("LEA"."RNK"=1)
241 - filter(ROW_NUMBER() OVER ( PARTITION BY "GI"."REFINDIVIDU","GI"."STR1" ORDER BY INTERNAL_FUNCTION("GI"."IMX_UN_ID") DESC )<=1)
242 - access("GRL"."MAITRE"="GI"."REFINDIVIDU")
244 - storage("GRL"."TYPE"='DEBITEURS')
       filter("GRL"."TYPE"='DEBITEURS')
246 - storage((INTERNAL_FUNCTION("GI"."STR1") AND INTERNAL_FUNCTION("GI"."TYPE") AND SYS_OP_BLOOM_FILTER(:BF0018,"GI"."REFINDIVIDU")))
       filter((INTERNAL_FUNCTION("GI"."STR1") AND INTERNAL_FUNCTION("GI"."TYPE") AND SYS_OP_BLOOM_FILTER(:BF0018,"GI"."REFINDIVIDU")))
249 - filter("HRISK"."RNK"=1)
250 - filter(ROW_NUMBER() OVER ( PARTITION BY "REFGROUPE" ORDER BY INTERNAL_FUNCTION("RISK_EUR") DESC )<=1)
253 - access("DBOP"."REFDOSS"="COMPTE"."REFDOSS")
254 - access("GPR"."REFGROUPE"="GPRDET"."REFGROUPE")
255 - storage("GPR"."TYPE"='DEBITEURS')
       filter("GPR"."TYPE"='DEBITEURS')
256 - access("COMPTE"."DEBTOR"="GPRDET"."REF1")
258 - storage(("GPRDET"."REF1" IS NOT NULL AND "GPRDET"."TYPE"='LIST'))
       filter(("GPRDET"."REF1" IS NOT NULL AND "GPRDET"."TYPE"='LIST'))
260 - filter("DBOP"."REFDOSS" IS NOT NULL)
261 - access("DBOP"."DTJOUR"=TRUNC(SYSDATE@!) AND (("DBOP"."CODEOPER"='DB_CLDB_COV' OR "DBOP"."CODEOPER"='DB_CLDB_PRS')))
262 - filter("GI"."RNK"=1)
264 - filter("GI"."STR1"='KSV')
265 - access("GI"."REFINDIVIDU"="HRISK"."DEBTOR")
       filter(("GI"."TYPE"='COTE FACTOR' OR "GI"."TYPE"='COTE FACTOR HIS'))
271 - access("FIC"."FI_REFELEM"="RENT_AMT"."REFELEM")
275 - storage(("FIC"."FI_ACTIF"='O' AND INTERNAL_FUNCTION("FIC"."FI_TYPE")))
       filter(("FIC"."FI_ACTIF"='O' AND INTERNAL_FUNCTION("FIC"."FI_TYPE")))
278 - access("C"."DEBTOR_REF"=DECODE("COFACT"."STR1",'FIN',NULL,"COFACT"."REFINDIVIDU"))
279 - storage("C"."CATEGDOSS"='COMPTE')
       filter("C"."CATEGDOSS"='COMPTE')
280 - access("B"."CLIENT_REF"=DECODE("COFACT"."STR1",'FIN',"COFACT"."REFINDIVIDU",NULL))
281 - filter("COFACT"."RNK"=1)
282 - filter(ROW_NUMBER() OVER ( PARTITION BY "A"."REFINDIVIDU","STR1" ORDER BY INTERNAL_FUNCTION("A"."IMX_UN_ID") DESC )<=1)
285 - access((("A"."TYPE"='COTE FACTOR' OR "A"."TYPE"='COTE FACTOR HIS')) AND (("A"."STR1"='DRI' OR "A"."STR1"='FIN')))
286 - storage("B"."CATEGDOSS"='COMPTE')
       filter("B"."CATEGDOSS"='COMPTE')
287 - access("V"."ABREV"=COALESCE(CASE  WHEN NVL("GI"."DRI_INDUSTRY_CODE",'_UNBEK')<>'_UNBEK' THEN "GI"."DRI_INDUSTRY_CODE" ELSE NULL END ,CASE  WHEN
              (NVL("GI"."STR44",'_UNBEK')<>'_UNBEKANNT' AND NVL("GI"."STR44",'_UNBEK')<>'_UNBEK') THEN "GI"."STR44" ELSE NULL END ,"CL"."STR15"))
288 - storage(("V"."TYPE"='DRI_INDUSTRY' OR "V"."TYPE"='DRI_NACE_CODE' OR "V"."TYPE"='T.NAF'))
       filter(("V"."TYPE"='DRI_INDUSTRY' OR "V"."TYPE"='DRI_NACE_CODE' OR "V"."TYPE"='T.NAF'))
289 - access("EX_RATE"."ORIGINE"="CL_ACC"."DEVISE")
291 - filter("RNK"=1)
292 - filter(ROW_NUMBER() OVER ( PARTITION BY "ORIGINE" ORDER BY INTERNAL_FUNCTION("T"."DTDEBUT_DT") DESC )<=1)
293 - filter(("T"."TYPE"='MR' AND "T"."PLACE"='AUT' AND NVL("T"."DESTINATION",'EUR')='EUR'))
294 - access("T"."DTDEBUT_DT"<=SYSDATE@!)
       filter("T"."DTDEBUT_DT"<=SYSDATE@!)
295 - access("COMPTA_BAK"."REFDOSS"="CL_ACC"."REFDOSS")
296 - access("RISK_EUR"."DECOMPTE_REFDOSS"="CL_ACC"."REFDOSS")
298 - access("GRPNEW"."REFINDIVIDU"="CL"."CLIENT_REFINDIVIDU")
299 - access("EBDRI"."REFINDIVIDU"="CL"."CLIENT_REFINDIVIDU")
301 - access("KSV_EBS_RATE"."REFINDIVIDU"="CL"."CLIENT_REFINDIVIDU")
303 - access("T1"."REFINDIVIDU"="CL"."CLIENT_REFINDIVIDU")
305 - access("CL"."CLIENT_REFINDIVIDU"="CL_ACC"."CLIENT")
307 - access("RECEI"."REFINDIVIDU"="CL_ACC"."CLIENT")
309 - access("PD_LGD"."REFINDIVIDU"="CL_ACC"."CLIENT")
310 - access("CL_PORF"."CL_ACCOUNT_CASE"="CL_ACC"."REFDOSS")
311 - access("LOV_CNT"."ABREV"="CTR"."GPIOBJET")
313 - access("INS_QUALITY"."REFDOSS"="CTR_CASE"."REFDOSS")
315 - access("EBV"."REFINDIVIDU"="CL_ACC"."CLIENT")
317 - access("EXT"."REFINDIVIDU"="CL_ACC"."CLIENT")
318 - access("TCL"."REFDOSS"="CL_ACC"."REFDOSS" AND "TCL"."REFINDIVIDU"="CL_ACC"."CLIENT")
322 - access("CTR_CASE"."REFDOSS"="CL_ACC"."REFLOT")
327 - access("CTR"."TYPPIECE"='CONTRAT' AND "CTR"."REFDOSS"="CTR_CASE"."REFDOSS")
       filter("CTR"."REFDOSS" IS NOT NULL)
330 - storage(SYS_OP_BLOOM_FILTER(:BF0028,"CL_ACC"."REFLOT"))
       filter(SYS_OP_BLOOM_FILTER(:BF0028,"CL_ACC"."REFLOT"))
331 - access("DEC"."TYPPIECE"='SOUS-CONTRAT' AND "DEC"."REFDOSS"="CL_ACC"."REFDOSS")
       filter("DEC"."REFDOSS" IS NOT NULL)
334 - storage(("TCL"."REFTYPE"='CL' AND SYS_OP_BLOOM_FILTER(:BF0027,"TCL"."REFDOSS","TCL"."REFINDIVIDU")))
       filter(("TCL"."REFTYPE"='CL' AND SYS_OP_BLOOM_FILTER(:BF0027,"TCL"."REFDOSS","TCL"."REFINDIVIDU")))
335 - filter("EXT"."RNK"=1)
336 - filter(ROW_NUMBER() OVER ( PARTITION BY "REFINDIVIDU" ORDER BY INTERNAL_FUNCTION("IMX_UN_ID") DESC )<=1)
339 - access((("TYPE"='COTE FACTOR' OR "TYPE"='COTE FACTOR HIS')) AND "STR1"='FIN')
343 - storage(SYS_OP_BLOOM_FILTER(:BF0026,"REFINDIVIDU"))
       filter(SYS_OP_BLOOM_FILTER(:BF0026,"REFINDIVIDU"))
346 - filter("A"."RN"=1)
348 - filter(ROW_NUMBER() OVER ( PARTITION BY "GP"."REFDOSS","GP"."LIB2" ORDER BY INTERNAL_FUNCTION("IMX_UN_ID") DESC )<=1)
349 - filter(("GP"."LIB2"='INSUR' OR "GP"."LIB2"='VERSITAT'))
350 - access("GP"."TYPE"='UDF')
352 - storage(("LOV_CNT"."TYPE"='CONTRTYP' AND SYS_OP_BLOOM_FILTER(:BF0024,"LOV_CNT"."ABREV")))
       filter(("LOV_CNT"."TYPE"='CONTRTYP' AND SYS_OP_BLOOM_FILTER(:BF0024,"LOV_CNT"."ABREV")))
354 - filter("RNK"=1)
355 - filter(ROW_NUMBER() OVER ( PARTITION BY "CL_ACCOUNT_CASE","DATE_ID","CURRENCY" ORDER BY INTERNAL_FUNCTION("DATE_ID") DESC )<=1)
356 - storage(("MEMO_SOURCE"='A' AND "DATE_ID"=TO_NUMBER(TO_CHAR(SYSDATE@!,'j'))))
       filter(("MEMO_SOURCE"='A' AND "DATE_ID"=TO_NUMBER(TO_CHAR(SYSDATE@!,'j'))))
358 - filter("RNK"=1)
359 - filter(ROW_NUMBER() OVER ( PARTITION BY "GPARAM"."REFINDIVIDU" ORDER BY INTERNAL_FUNCTION("GPARAM"."IMX_UN_ID") DESC )<=1)
360 - access("PD"."DETNUM"=TO_NUMBER(NVL("GPARAM"."STR2",'0')))
361 - storage(("GPARAM"."STR1"='KSV' AND INTERNAL_FUNCTION("GPARAM"."TYPE")))
       filter(("GPARAM"."STR1"='KSV' AND INTERNAL_FUNCTION("GPARAM"."TYPE") AND NVL("GPARAM"."DT07_DT",SYSDATE@!)>=TRUNC(SYSDATE@!) AND "GPARAM"."DT09_DT"<=TRUNC(SYSDATE@!)))
364 - storage(SYS_OP_BLOOM_FILTER(:BF0023,"RECEI"."REFINDIVIDU"))
       filter(SYS_OP_BLOOM_FILTER(:BF0023,"RECEI"."REFINDIVIDU"))
366 - storage(SYS_OP_BLOOM_FILTER(:BF0022,"CL"."CLIENT_REFINDIVIDU"))
       filter(SYS_OP_BLOOM_FILTER(:BF0022,"CL"."CLIENT_REFINDIVIDU"))
369 - filter("A"."RNK"=1)
371 - filter(ROW_NUMBER() OVER ( PARTITION BY "TI"."REFINDIVIDU","TI"."SOCIETE" ORDER BY INTERNAL_FUNCTION("TI"."IMX_UN_ID") DESC )<=1)
372 - storage(("TI"."SOCIETE"='KUKURZ' OR "TI"."SOCIETE"='National bank code ID OeNB'))
       filter(("TI"."SOCIETE"='KUKURZ' OR "TI"."SOCIETE"='National bank code ID OeNB'))
375 - filter("KSV_EBS"."RNK"=1)
377 - filter(ROW_NUMBER() OVER ( PARTITION BY "KSV"."REFINDIVIDU","KSV"."STR1" ORDER BY INTERNAL_FUNCTION("KSV"."IMX_UN_ID") DESC )<=1)
379 - filter((NVL("KSV"."DT07_DT",SYSDATE@!)>=TRUNC(SYSDATE@!) AND "KSV"."DT09_DT"<=TRUNC(SYSDATE@!)))
380 - access((("KSV"."TYPE"='COTE FACTOR' OR "KSV"."TYPE"='COTE FACTOR HIS')) AND (("KSV"."STR1"='EBS' OR "KSV"."STR1"='KSV')))
382 - access("GI"."REFINDIVIDU"="CL"."CLIENT_REFINDIVIDU")
384 - filter("COFACT"."RNK"=1)
385 - filter(ROW_NUMBER() OVER ( PARTITION BY "A"."REFINDIVIDU","STR1" ORDER BY INTERNAL_FUNCTION("A"."IMX_UN_ID") DESC )<=1)
388 - access((("A"."TYPE"='COTE FACTOR' OR "A"."TYPE"='COTE FACTOR HIS')) AND "A"."STR1"='DRI')
390 - access("GRP"."REFGROUPE"="GRISK"."REFGROUPE")
391 - access("GRP"."REFGROUPE"="GRICOS"."REFGROUPE")
395 - access("B"."TYPE"='DEBTOR_GRP_DGGFL_LIM_PARAM')
       filter("B"."TYPE"='DEBTOR_GRP_DGGFL_LIM_PARAM')
396 - access("GRP"."REFGROUPE"="GIDET"."REFGROUPE" AND "GPRDET"."REF1"="GIDET"."DEBROR")
398 - access("GEXT"."REFGROUPE"="GRP"."REFGROUPE")
399 - storage("GEXT"."REFEXT_TYPE"='OeNB group number')
       filter("GEXT"."REFEXT_TYPE"='OeNB group number')
400 - access("GPRDET"."REFGROUPE"="GRP"."REFGROUPE")
402 - access("GPRDET"."TYPE"='LIST')
       filter("GPRDET"."TYPE"='LIST')
403 - storage(("GRP"."DTDEACT_DT" IS NULL AND "GRP"."TYPE"='DEBITEURS'))
       filter(("GRP"."DTDEACT_DT" IS NULL AND "GRP"."TYPE"='DEBITEURS'))
407 - access("LEA"."REFGROUPE"="ITEM_1")
410 - storage("GPRDET"."TYPE"='LIST')
       filter("GPRDET"."TYPE"='LIST')
411 - filter("LEA"."RNK"=1)
412 - filter(ROW_NUMBER() OVER ( PARTITION BY "GI"."REFINDIVIDU","GI"."STR1" ORDER BY INTERNAL_FUNCTION("GI"."IMX_UN_ID") DESC )<=1)
413 - access("GRL"."MAITRE"="GI"."REFINDIVIDU")
415 - storage("GRL"."TYPE"='DEBITEURS')
       filter("GRL"."TYPE"='DEBITEURS')
417 - storage((INTERNAL_FUNCTION("GI"."STR1") AND INTERNAL_FUNCTION("GI"."TYPE") AND SYS_OP_BLOOM_FILTER(:BF0030,"GI"."REFINDIVIDU")))
       filter((INTERNAL_FUNCTION("GI"."STR1") AND INTERNAL_FUNCTION("GI"."TYPE") AND SYS_OP_BLOOM_FILTER(:BF0030,"GI"."REFINDIVIDU")))
420 - filter("HRISK"."RNK"=1)
421 - filter(ROW_NUMBER() OVER ( PARTITION BY "REFGROUPE" ORDER BY INTERNAL_FUNCTION("RISK_EUR") DESC )<=1)
424 - access("DBOP"."REFDOSS"="COMPTE"."REFDOSS")
425 - access("GPR"."REFGROUPE"="GPRDET"."REFGROUPE")
426 - storage("GPR"."TYPE"='DEBITEURS')
       filter("GPR"."TYPE"='DEBITEURS')
427 - access("COMPTE"."DEBTOR"="GPRDET"."REF1")
429 - storage(("GPRDET"."REF1" IS NOT NULL AND "GPRDET"."TYPE"='LIST'))
       filter(("GPRDET"."REF1" IS NOT NULL AND "GPRDET"."TYPE"='LIST'))
431 - filter("DBOP"."REFDOSS" IS NOT NULL)
432 - access("DBOP"."DTJOUR"=TRUNC(SYSDATE@!) AND (("DBOP"."CODEOPER"='DB_CLDB_COV' OR "DBOP"."CODEOPER"='DB_CLDB_PRS')))
433 - filter("GI"."RNK"=1)
435 - filter("GI"."STR1"='KSV')
436 - access("GI"."REFINDIVIDU"="HRISK"."DEBTOR")
       filter(("GI"."TYPE"='COTE FACTOR' OR "GI"."TYPE"='COTE FACTOR HIS'))
440 - access("FP"."PF_NOM"=UPPER("FD"."DF_NOM"))
443 - storage(NVL("PF_FG_TECH_ITEM",'N')='N')
       filter(NVL("PF_FG_TECH_ITEM",'N')='N')
444 - access("FD"."DF_DOS"="CL_STRUCT"."REFDOSS" AND "FD"."DF_CLI"="CL_STRUCT"."CLIENT_REF")
445 - storage(("FD"."DF_MONTTC_MVT"-NVL("FD"."DF_PAYE_MVT",0)>0 AND NVL("FD"."DF_ANN",0)=0 AND "FD"."DF_REL" IS NOT NULL AND "DF_DAT"<=TO_NUMBER(TO_CHAR(SYSDATE@!,'j'))))
       filter(("FD"."DF_MONTTC_MVT"-NVL("FD"."DF_PAYE_MVT",0)>0 AND NVL("FD"."DF_ANN",0)=0 AND "FD"."DF_REL" IS NOT NULL AND "DF_DAT"<=TO_NUMBER(TO_CHAR(SYSDATE@!,'j'))))
448 - storage(("CATEGDOSS"='COMPTE' OR "CATEGDOSS"='DECOMPTE'))
       filter(("CATEGDOSS"='COMPTE' OR "CATEGDOSS"='DECOMPTE'))
449 - storage(("CATEGDOSS"='DECOMPTE' AND "DEFAULT_DECOMPTE"='O'))
       filter(("CATEGDOSS"='DECOMPTE' AND "DEFAULT_DECOMPTE"='O'))
451 - filter("OP"."RNK"=1)
452 - filter(ROW_NUMBER() OVER ( PARTITION BY "REFDOSS" ORDER BY "EXTREF9")<=1)
454 - storage(("REFDOSS" IS NOT NULL AND "DTJOUR"<SYSDATE@!+1))
       filter(("REFDOSS" IS NOT NULL AND "DTJOUR"<SYSDATE@!+1))

*/
/********************************New Metrics***************************************/

/********************************Index statistics**********************************/

/********************************Other SQLs****************************************/          
/*

*/ 
/********************************Other SQLs****************************************/              
