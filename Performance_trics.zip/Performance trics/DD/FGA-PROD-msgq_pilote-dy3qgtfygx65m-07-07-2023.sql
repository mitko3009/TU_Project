/********************************************************************************
*********       E-mail subject: FGADEV-5293
*********             Instance: PROD
*********          Description: 
Problem:
Slow query on PROD from msgq_pilote module.

Analysis:
On 07/07/2023 the provided query was slow.
The problem was inapropriate execution plan and too much data were taken from table T_INTERVENANTS.


Suggestion:
Please add hint as it is shown in the New SQL.

*********               SQL_ID: dy3qgtfygx65m
*********      Program/Package: nb_ref_dos_GA_REGL_2
*********              Request: Dimitare Ivanov
*********               Author: Dimitar Dimitrov
********* Received e-mail date: 07/07/2023
*********      Resolution date: 07/07/2023
*********  Trace old file here: \\epox\specifs\performance\tmp\
*********  Trace new file here:
***********************************************************************************/

/********************************OLD SQL*******************************************/

SELECT COUNT(dos_gar.refdoss) 
  FROM g_dossier dos_regl, 
       g_dossier dos_eve, 
       g_dossier dos_gar 
 WHERE dos_eve.refdoss = dos_regl.refhierarchie 
   AND dos_regl.categdoss = 'REGLEMENT' 
   AND dos_eve.refdoss = dos_gar.refhierarchie 
   AND dos_gar.categdoss = 'GARANT AUTEUR' 
   AND dos_regl.refdoss = :refdos  
   AND EXISTS ( SELECT 1 
                  FROM t_intervenants r, 
                       t_intervenants ga 
                 WHERE ga.refdoss = :refdos 
                   AND ga.reftype = 'CL' 
                   AND r.reftype = 'CL' 
                   AND r.refdoss = dos_eve.refdoss 
                   AND ga.refindividu = r.refindividu ) 
   AND EXISTS ( SELECT 1 
                  FROM t_filiere f 
                 WHERE f.nom = 'RGAR' 
                   AND f.dtfin IS NULL 
                   AND f.refdoss = dos_gar.refdoss ) 
   AND EXISTS ( SELECT 1 
                  FROM t_element_se e 
                 WHERE e.libelle = 'att indemnisation RGAR' 
                   AND e.refdoss = dos_gar.refdoss ) 
   AND EXISTS ( SELECT 1 
                  FROM g_personnel p 
                 WHERE dos_gar.rangmt = p.refperso 
                   AND p.groupe = 'JUDICIAIRE' );
/********************************OLD SQL*******************************************/
/********************************OLD Metrics***************************************/
/*
  
MODULE      SQL_ID         PLAN_HASH FROM                           TO                                 ACTIVE NUMBER_OF_EXECUTIONS PERC

----------- ------------- ---------- ------------------------------ ------------------------------ ---------- -------------------- ------

msgq_pilote dy3qgtfygx65m  380893321 2023/07/07 10:00:02            2023/07/07 11:59:57                 24990               110169 38%

msgq        bk7f5ngcp99n4 1857232375 2023/07/07 10:00:33            2023/07/07 11:59:57                  4580               123419 7%

msgq        03mtb50d0ctq4   33400020 2023/07/07 10:01:03            2023/07/07 11:59:47                  3740               123808 6%



SQL_ID              MODULE               ELAPSED MAX_WAIT        GETS      READS       ROWS   ELAP/EXEC  GETS/EXEC READS/EXEC  ROWS/EXEC       EXEC PLAN_HASH_VALUE
------------------- ----------------- ---------- --------- ---------- ---------- ---------- ----------- ---------- ---------- ---------- ---------- ---------------
dy3qgtfygx65m       msgq_pilote            86316 31% cpu   3285680529     488611     564685         .15    5817.97        .87          1     564747       380893321
 
Plan hash VALUE: 380893321
----------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                          | Name              | Starts | E-ROWS | Cost (%CPU)| A-ROWS |   A-TIME   | Buffers | Reads  |
----------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                   |                   |      1 |        |     8 (100)|      1 |00:00:00.40 |    4852 |      2 |
|   1 |  SORT AGGREGATE                    |                   |      1 |      1 |            |      1 |00:00:00.40 |    4852 |      2 |
|   2 |   NESTED LOOPS SEMI                |                   |      1 |      1 |     8   (0)|      0 |00:00:00.40 |    4852 |      2 |
|   3 |    NESTED LOOPS SEMI               |                   |      1 |      1 |     7   (0)|      0 |00:00:00.40 |    4852 |      2 |
|   4 |     NESTED LOOPS SEMI              |                   |      1 |      1 |     6   (0)|      0 |00:00:00.40 |    4852 |      2 |
|   5 |      NESTED LOOPS                  |                   |      1 |      1 |     5   (0)|      0 |00:00:00.40 |    4852 |      2 |
|   6 |       NESTED LOOPS SEMI            |                   |      1 |      1 |     4   (0)|      1 |00:00:00.40 |    4849 |      2 |
|   7 |        NESTED LOOPS                |                   |      1 |      1 |     2   (0)|      1 |00:00:00.01 |       8 |      2 |
|*  8 |         TABLE ACCESS BY INDEX ROWID| G_DOSSIER         |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       5 |      2 |
|*  9 |          INDEX UNIQUE SCAN         | DOS_REFDOSS       |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |      1 |
|* 10 |         INDEX UNIQUE SCAN          | DOS_REFDOSS       |      1 |   5316K|     1   (0)|      1 |00:00:00.01 |       3 |      0 |
|* 11 |        VIEW                        | VW_SQ_1           |      1 |     46 |     2   (0)|      1 |00:00:00.40 |    4841 |      0 |
|  12 |         NESTED LOOPS               |                   |      1 |   3322 |     2   (0)|    579K|00:00:00.30 |    4841 |      0 |
|* 13 |          INDEX RANGE SCAN          | INT_REFDOSS       |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       4 |      0 |
|* 14 |          INDEX RANGE SCAN          | INT_INDIV         |      1 |   3127 |     1   (0)|    579K|00:00:00.16 |    4837 |      0 |
|  15 |       TABLE ACCESS BY INDEX ROWID  | G_DOSSIER         |      1 |      1 |     1   (0)|      0 |00:00:00.01 |       3 |      0 |
|* 16 |        INDEX RANGE SCAN            | REFHIERARCHIE_IDX |      1 |      1 |     1   (0)|      0 |00:00:00.01 |       3 |      0 |
|* 17 |      INDEX RANGE SCAN              | TIND_FIL          |      0 |   1821 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 18 |     TABLE ACCESS BY INDEX ROWID    | G_PERSONNEL       |      0 |     56 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 19 |      INDEX RANGE SCAN              | GPERSREFP         |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 20 |    TABLE ACCESS BY INDEX ROWID     | T_ELEMENT_SE      |      0 |   7400 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 21 |     INDEX RANGE SCAN               | ELESE_DOSELEM     |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
----------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (IDENTIFIED BY operation id):
---------------------------------------------------
   8 - FILTER(("DOS_REGL"."REFHIERARCHIE" IS NOT NULL AND "DOS_REGL"."CATEGDOSS"='REGLEMENT'))
   9 - access("DOS_REGL"."REFDOSS"=:REFDOS)
  10 - access("DOS_EVE"."REFDOSS"="DOS_REGL"."REFHIERARCHIE")
  11 - FILTER("ITEM_1"="DOS_EVE"."REFDOSS")
  13 - access("GA"."REFDOSS"=:REFDOS AND "GA"."REFTYPE"='CL')
  14 - access("GA"."REFINDIVIDU"="R"."REFINDIVIDU" AND "R"."REFTYPE"='CL')
  16 - access("DOS_EVE"."REFDOSS"="DOS_GAR"."REFHIERARCHIE" AND "DOS_GAR"."CATEGDOSS"='GARANT AUTEUR')
       FILTER("DOS_GAR"."REFHIERARCHIE" IS NOT NULL)
  17 - access("F"."REFDOSS"="DOS_GAR"."REFDOSS" AND "F"."NOM"='RGAR' AND "F"."DTFIN" IS NULL)
  18 - FILTER("P"."GROUPE"='JUDICIAIRE')
  19 - access("DOS_GAR"."RANGMT"="P"."REFPERSO")
  20 - FILTER("E"."LIBELLE"='att indemnisation RGAR')
  21 - access("E"."REFDOSS"="DOS_GAR"."REFDOSS")
  
*/
/********************************OLD Metrics***************************************/

/********************************New SQL*******************************************/

SELECT COUNT(dos_gar.refdoss) 
  FROM g_dossier dos_regl, 
       g_dossier dos_eve, 
       g_dossier dos_gar 
 WHERE dos_eve.refdoss = dos_regl.refhierarchie 
   AND dos_regl.categdoss = 'REGLEMENT' 
   AND dos_eve.refdoss = dos_gar.refhierarchie 
   AND dos_gar.categdoss = 'GARANT AUTEUR' 
   AND dos_regl.refdoss = :refdos  
   AND EXISTS ( SELECT /*+ leading(r)*/ 1 
                  FROM t_intervenants r, 
                       t_intervenants ga 
                 WHERE ga.refdoss = :refdos 
                   AND ga.reftype = 'CL' 
                   AND r.reftype = 'CL' 
                   AND r.refdoss = dos_eve.refdoss 
                   AND ga.refindividu = r.refindividu ) 
   AND EXISTS ( SELECT 1 
                  FROM t_filiere f 
                 WHERE f.nom = 'RGAR' 
                   AND f.dtfin IS NULL 
                   AND f.refdoss = dos_gar.refdoss ) 
   AND EXISTS ( SELECT 1 
                  FROM t_element_se e 
                 WHERE e.libelle = 'att indemnisation RGAR' 
                   AND e.refdoss = dos_gar.refdoss ) 
   AND EXISTS ( SELECT 1 
                  FROM g_personnel p 
                 WHERE dos_gar.rangmt = p.refperso 
                   AND p.groupe = 'JUDICIAIRE' );
/********************************New SQL*******************************************/
/********************************New Metrics***************************************/
/*
Plan hash value: 3307228244

-------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                          | Name              | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers |
-------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                   |                   |      1 |        |     8 (100)|      1 |00:00:00.01 |      11 |
|   1 |  SORT AGGREGATE                    |                   |      1 |      1 |            |      1 |00:00:00.01 |      11 |
|   2 |   NESTED LOOPS SEMI                |                   |      1 |      1 |     8   (0)|      0 |00:00:00.01 |      11 |
|   3 |    NESTED LOOPS SEMI               |                   |      1 |      1 |     6   (0)|      0 |00:00:00.01 |      11 |
|   4 |     NESTED LOOPS SEMI              |                   |      1 |      1 |     5   (0)|      0 |00:00:00.01 |      11 |
|   5 |      NESTED LOOPS SEMI             |                   |      1 |      1 |     4   (0)|      0 |00:00:00.01 |      11 |
|   6 |       NESTED LOOPS                 |                   |      1 |      1 |     3   (0)|      0 |00:00:00.01 |      11 |
|   7 |        NESTED LOOPS                |                   |      1 |      1 |     2   (0)|      1 |00:00:00.01 |       8 |
|*  8 |         TABLE ACCESS BY INDEX ROWID| G_DOSSIER         |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       5 |
|*  9 |          INDEX UNIQUE SCAN         | DOS_REFDOSS       |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |
|* 10 |         INDEX UNIQUE SCAN          | DOS_REFDOSS       |      1 |   5316K|     1   (0)|      1 |00:00:00.01 |       3 |
|  11 |        TABLE ACCESS BY INDEX ROWID | G_DOSSIER         |      1 |      1 |     1   (0)|      0 |00:00:00.01 |       3 |
|* 12 |         INDEX RANGE SCAN           | REFHIERARCHIE_IDX |      1 |      1 |     1   (0)|      0 |00:00:00.01 |       3 |
|* 13 |       INDEX RANGE SCAN             | TIND_FIL          |      0 |   1821 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 14 |      TABLE ACCESS BY INDEX ROWID   | G_PERSONNEL       |      0 |     56 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 15 |       INDEX RANGE SCAN             | GPERSREFP         |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 16 |     TABLE ACCESS BY INDEX ROWID    | T_ELEMENT_SE      |      0 |    526 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 17 |      INDEX RANGE SCAN              | ELESE_DOSELEM     |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|  18 |    VIEW PUSHED PREDICATE           | VW_SQ_1           |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |
|  19 |     NESTED LOOPS                   |                   |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |
|* 20 |      INDEX RANGE SCAN              | INT_REFDOSS       |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 21 |      INDEX RANGE SCAN              | INT_REFDOSS       |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
-------------------------------------------------------------------------------------------------------------------------------

Predicate Information (identified by operation id):
---------------------------------------------------

   8 - filter(("DOS_REGL"."REFHIERARCHIE" IS NOT NULL AND "DOS_REGL"."CATEGDOSS"='REGLEMENT'))
   9 - access("DOS_REGL"."REFDOSS"=:REFDOS)
  10 - access("DOS_EVE"."REFDOSS"="DOS_REGL"."REFHIERARCHIE")
  12 - access("DOS_EVE"."REFDOSS"="DOS_GAR"."REFHIERARCHIE" AND "DOS_GAR"."CATEGDOSS"='GARANT AUTEUR')
       filter("DOS_GAR"."REFHIERARCHIE" IS NOT NULL)
  13 - access("F"."REFDOSS"="DOS_GAR"."REFDOSS" AND "F"."NOM"='RGAR' AND "F"."DTFIN" IS NULL)
  14 - filter("P"."GROUPE"='JUDICIAIRE')
  15 - access("DOS_GAR"."RANGMT"="P"."REFPERSO")
  16 - filter("E"."LIBELLE"='att indemnisation RGAR')
  17 - access("E"."REFDOSS"="DOS_GAR"."REFDOSS")
  20 - access("R"."REFDOSS"="DOS_EVE"."REFDOSS" AND "R"."REFTYPE"='CL')
  21 - access("GA"."REFDOSS"=:REFDOS AND "GA"."REFTYPE"='CL' AND "GA"."REFINDIVIDU"="R"."REFINDIVIDU")
*/
/********************************New Metrics***************************************/

/********************************Index statistics**********************************/

/********************************Other SQLs****************************************/          
/*

*/ 
/********************************Other SQLs****************************************/              
