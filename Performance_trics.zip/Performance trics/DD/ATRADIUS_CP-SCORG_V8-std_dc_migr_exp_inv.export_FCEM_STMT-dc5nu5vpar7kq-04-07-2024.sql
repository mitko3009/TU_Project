/********************************************************************************
*********       E-mail subject: ACPDEV-4751
*********             Instance: SCORG V8
*********          Description: 
Problem:
std_dc_migr_exp_inv.export_FCEM_STMT was running for more than 3.5h on SCORG V9.

Analysis:
After the analyze of module std_dc_migr_exp_inv.export_FCEM_STMT we found that the TOP SQL, which was responsible for 100% of the time was dc5nu5vpar7kq.
This is an INSERT statement, which loops with full scans over each of the MIGR% tables, for each line from F_ENTREL.

Suggestion:
Please change the query as it is shown in the New SQL section below.

*********               SQL_ID: dc5nu5vpar7kq
*********      Program/Package: 
*********              Request: Iva Zareva
*********               Author: Dimitar Dimitrov
********* Received e-mail date: 02/07/2024
*********      Resolution date: 04/07/2024
*********  Trace old file here: \\epox\specifs\performance\tmp\
*********  Trace new file here:
***********************************************************************************/

/********************************OLD SQL*******************************************/

INSERT INTO MIGR_DC_FCEM_STMT
  (ER_CONTR,
   ER_NUM,
   ER_ANN,
   ER_CCR,
   ER_CCR_MVT,
   ER_CDB,
   ER_CDB_MVT,
   ER_CLI,
   ER_COM,
   ER_CREATEUR,
   ER_DAT,
   ER_DAT_DT,
   ER_DAT_SYS,
   ER_DEVISE,
   ER_DEVISE_BU,
   ER_DEVISE_CON,
   ER_DEVISE_DOS,
   ER_DEVISE_MAN,
   ER_DEVISE_MVT,
   ER_DREG,
   ER_DREG_DT,
   ER_ENCOURS,
   ER_ENCOURS_MVT,
   ER_INVGRP,
   ER_MOYP,
   ER_NUMCHQ,
   ER_NUMEXT,
   ER_PAYE,
   ER_PAYE_BU,
   ER_PAYE_CON,
   ER_PAYE_MAN,
   ER_PAYE_MVT,
   ER_REASON,
   ER_REFEXT1,
   ER_REFEXT2,
   ER_REFTXT,
   ER_REFTXT_CPY,
   ER_REG_DT,
   ER_SPHP,
   ER_TAUX_MAN,
   ER_TAUX_MVT,
   ER_TCR,
   ER_TCR_BU,
   ER_TCR_CON,
   ER_TCR_MAN,
   ER_TCR_MVT,
   ER_TDB,
   ER_TDB_BU,
   ER_TDB_CON,
   ER_TDB_MAN,
   ER_TDB_MVT,
   ER_VAL,
   ID_VALIDATION,
   INV_SALE_DT)
  SELECT ER_CONTR,
         ER_NUM,
         ER_ANN,
         ER_CCR,
         ER_CCR_MVT,
         ER_CDB,
         ER_CDB_MVT,
         ER_CLI,
         ER_COM,
         ER_CREATEUR,
         ER_DAT,
         ER_DAT_DT,
         ER_DAT_SYS,
         ER_DEVISE,
         ER_DEVISE_BU,
         ER_DEVISE_CON,
         ER_DEVISE_DOS,
         ER_DEVISE_MAN,
         ER_DEVISE_MVT,
         ER_DREG,
         ER_DREG_DT,
         ER_ENCOURS,
         ER_ENCOURS_MVT,
         ER_INVGRP,
         ER_MOYP,
         ER_NUMCHQ,
         ER_NUMEXT,
         ER_PAYE,
         ER_PAYE_BU,
         ER_PAYE_CON,
         ER_PAYE_MAN,
         ER_PAYE_MVT,
         ER_REASON,
         ER_REFEXT1,
         ER_REFEXT2,
         ER_REFTXT,
         ER_REFTXT_CPY,
         ER_REG_DT,
         ER_SPHP,
         ER_TAUX_MAN,
         ER_TAUX_MVT,
         ER_TCR,
         ER_TCR_BU,
         ER_TCR_CON,
         ER_TCR_MAN,
         ER_TCR_MVT,
         ER_TDB,
         ER_TDB_BU,
         ER_TDB_CON,
         ER_TDB_MAN,
         ER_TDB_MVT,
         ER_VAL,
         ID_VALIDATION,
         INV_SALE_DT
    FROM F_ENTREL
   WHERE EXISTS (SELECT 1
            FROM MIGR_DC_CA
           WHERE REFDOSS = F_ENTREL.ER_CONTR
          UNION
          SELECT 1
            FROM MIGR_DC_LFCE_ENT
           WHERE EF_REL = F_ENTREL.ER_NUM)
     AND ER_CLI IS NOT NULL
     AND ER_DAT IS NOT NULL
     AND ER_DAT_DT IS NOT NULL;
/********************************OLD SQL*******************************************/
/********************************OLD Metrics***************************************/
/*
MODULE                           PROGRAM                                            SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- -------------------------------------------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
std_dc_migr_exp_inv.export_FCEM_ std_migration_robot                                dc5nu5vpar7kq 2697293673        811       2894 ON CPU               2024/07/02 10:28:43  2024/07/02 14:29:51        1447                    1 +000000000 04:01:08.402 29%
STMT

std_dc_migr_exp_ind.export_EIP   std_migration_robot                                              3550170199        577      13883 ON CPU               2024/07/02 10:44:34  2024/07/02 13:57:50        1148                    1 +000000000 03:13:16.187 23%
std_dc_migr_exp_case.export_MAIL std_migration_robot                                78h2y267tny81                                  db file sequential r 2024/07/02 10:27:43  2024/07/02 14:18:01         325                    2 +000000000 03:50:18.189 7%
std_dc_migr_exp_case.export_SLD  std_migration_robot                                                                               db file sequential r 2024/07/02 10:27:33  2024/07/02 14:17:11         324                    2 +000000000 03:49:38.188 7%
std_dc_migr_exp_case.export_INF  std_migration_robot                                                                               db file sequential r 2024/07/02 10:27:33  2024/07/02 13:59:00         194                    2 +000000000 03:31:27.124 4%
std_dc_migr_exp_ind.export_USE   std_migration_robot                                                               2057      37176 ON CPU               2024/07/02 10:20:02  2024/07/02 10:44:04         143                    1 +000000000 00:24:01.192 3%


MODULE                           PROGRAM                                            SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- -------------------------------------------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
std_dc_migr_exp_inv.export_FCEM_ std_migration_robot                                dc5nu5vpar7kq 2697293673        811       2894 ON CPU               2024/07/02 10:28:43  2024/07/02 14:29:51        1447                    1 +000000000 04:01:08.402 100%
STMT

std_dc_migr_exp_inv.export_FCEM_ std_migration_robot                                dc5nu5vpar7kq 2697293673        811       2894 db file scattered re 2024/07/02 10:28:33  2024/07/02 10:28:33           1                    1 +000000000 00:00:00.000 0%
STMT


MODULE                           PROGRAM                                            SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- -------------------------------------------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
std_dc_migr_exp_inv.export_FCEM_ std_migration_robot                                dc5nu5vpar7kq 2697293673        811       2894                      2024/07/02 10:28:33  2024/07/02 14:29:51        1448                    1 +000000000 04:01:18.421 100%
STMT

SQL_ID        SQL_PLAN_HASH_VALUE SQL_PLAN_LINE_ID SQL_PLAN_OPERATION             SQL_PLAN_OPTIONS                   ACTIVE
------------- ------------------- ---------------- ------------------------------ ------------------------------ ----------
dc5nu5vpar7kq          2697293673                7 TABLE ACCESS                   FULL                                 1435
dc5nu5vpar7kq          2697293673                6 TABLE ACCESS                   FULL                                   12
dc5nu5vpar7kq          2697293673                2 FILTER                                                                 1


INSTANCE_NUMBER SQL_ID            ELAPSED MAX_WAIT_ON     PC_OF  WAIT_TIME            GETS      READS       ROWS  ELAP/EXEC       GETS/EXEC READS/EXEC  ROWS/EXEC       EXEC PLAN_HASH_VALUE
--------------- ------------- ----------- --------------- ----- ---------- --------------- ---------- ---------- ---------- --------------- ---------- ---------- ---------- ---------------
              1 dc5nu5vpar7kq       16287 CPU             100%  6783.15024      1791708138      18831          0   16287.05      1791708138      18831          0          0      2697293673

Plan hash value: 2697293673
----------------------------------------------------------------------------------------------
| Id  | Operation                | Name              | Rows  | Bytes | Cost (%CPU)| Time     |
----------------------------------------------------------------------------------------------
|   0 | INSERT STATEMENT         |                   |       |       |    10M(100)|          |
|   1 |  LOAD TABLE CONVENTIONAL | MIGR_DC_FCEM_STMT |       |       |            |          |
|*  2 |   FILTER                 |                   |       |       |            |          |
|*  3 |    TABLE ACCESS FULL     | F_ENTREL          |  2685K|   402M| 15167   (3)| 00:00:01 |
|   4 |    SORT UNIQUE           |                   |     2 |    62 |     4   (0)| 00:00:01 |
|   5 |     UNION-ALL            |                   |       |       |            |          |
|*  6 |      TABLE ACCESS FULL   | MIGR_DC_CA        |     1 |    17 |     2   (0)| 00:00:01 |
|*  7 |      TABLE ACCESS FULL   | MIGR_DC_LFCE_ENT  |     1 |    14 |     2   (0)| 00:00:01 |
----------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   2 - filter( IS NOT NULL)
   3 - filter(("ER_CLI" IS NOT NULL AND "ER_DAT" IS NOT NULL AND "ER_DAT_DT" IS NOT
              NULL))
   6 - filter("REFDOSS"=:B1)
   7 - filter("EF_REL"=:B1)
*/
/********************************OLD Metrics***************************************/

/********************************New SQL*******************************************/

INSERT INTO MIGR_DC_FCEM_STMT
  (ER_CONTR,
   ER_NUM,
   ER_ANN,
   ER_CCR,
   ER_CCR_MVT,
   ER_CDB,
   ER_CDB_MVT,
   ER_CLI,
   ER_COM,
   ER_CREATEUR,
   ER_DAT,
   ER_DAT_DT,
   ER_DAT_SYS,
   ER_DEVISE,
   ER_DEVISE_BU,
   ER_DEVISE_CON,
   ER_DEVISE_DOS,
   ER_DEVISE_MAN,
   ER_DEVISE_MVT,
   ER_DREG,
   ER_DREG_DT,
   ER_ENCOURS,
   ER_ENCOURS_MVT,
   ER_INVGRP,
   ER_MOYP,
   ER_NUMCHQ,
   ER_NUMEXT,
   ER_PAYE,
   ER_PAYE_BU,
   ER_PAYE_CON,
   ER_PAYE_MAN,
   ER_PAYE_MVT,
   ER_REASON,
   ER_REFEXT1,
   ER_REFEXT2,
   ER_REFTXT,
   ER_REFTXT_CPY,
   ER_REG_DT,
   ER_SPHP,
   ER_TAUX_MAN,
   ER_TAUX_MVT,
   ER_TCR,
   ER_TCR_BU,
   ER_TCR_CON,
   ER_TCR_MAN,
   ER_TCR_MVT,
   ER_TDB,
   ER_TDB_BU,
   ER_TDB_CON,
   ER_TDB_MAN,
   ER_TDB_MVT,
   ER_VAL,
   ID_VALIDATION,
   INV_SALE_DT)
SELECT /*+ full(MD) full(Me) full(FE) use_hash(ME) use_hash(MD) */
DISTINCT ER_CONTR,
         ER_NUM,
         ER_ANN,
         ER_CCR,
         ER_CCR_MVT,
         ER_CDB,
         ER_CDB_MVT,
         ER_CLI,
         ER_COM,
         ER_CREATEUR,
         ER_DAT,
         ER_DAT_DT,
         ER_DAT_SYS,
         ER_DEVISE,
         ER_DEVISE_BU,
         ER_DEVISE_CON,
         ER_DEVISE_DOS,
         ER_DEVISE_MAN,
         ER_DEVISE_MVT,
         ER_DREG,
         ER_DREG_DT,
         ER_ENCOURS,
         ER_ENCOURS_MVT,
         ER_INVGRP,
         ER_MOYP,
         ER_NUMCHQ,
         ER_NUMEXT,
         ER_PAYE,
         ER_PAYE_BU,
         ER_PAYE_CON,
         ER_PAYE_MAN,
         ER_PAYE_MVT,
         ER_REASON,
         ER_REFEXT1,
         ER_REFEXT2,
         ER_REFTXT,
         ER_REFTXT_CPY,
         ER_REG_DT,
         ER_SPHP,
         ER_TAUX_MAN,
         ER_TAUX_MVT,
         ER_TCR,
         ER_TCR_BU,
         ER_TCR_CON,
         ER_TCR_MAN,
         ER_TCR_MVT,
         ER_TDB,
         ER_TDB_BU,
         ER_TDB_CON,
         ER_TDB_MAN,
         ER_TDB_MVT,
         ER_VAL,
         ID_VALIDATION,
         INV_SALE_DT
    FROM F_ENTREL FE,
         MIGR_DC_CA MD,
         MIGR_DC_LFCE_ENT ME      
   WHERE MD.REFDOSS(+) = FE.ER_CONTR
     AND ME.EF_REL(+) = FE.ER_NUM
     AND FE.ER_CLI IS NOT NULL
     AND FE.ER_DAT IS NOT NULL
     AND FE.ER_DAT_DT IS NOT NULL
     AND ( MD.REFDOSS = FE.ER_CONTR
        OR ME.EF_REL = FE.ER_NUM );
/********************************New SQL*******************************************/
/********************************New Metrics***************************************/
/*
Plan hash value: 391013164
-------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                 | Name              | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  |
-------------------------------------------------------------------------------------------------------------------------------
|   0 | INSERT STATEMENT          |                   |      1 |        | 15206 (100)|      0 |00:00:05.92 |     114K|     36 |
|   1 |  LOAD TABLE CONVENTIONAL  | MIGR_DC_FCEM_STMT |      1 |        |            |      0 |00:00:05.92 |     114K|     36 |
|   2 |   HASH UNIQUE             |                   |      1 |      1 | 15206   (3)|    208K|00:00:05.17 |   80367 |      0 |
|*  3 |    FILTER                 |                   |      1 |        |            |    334K|00:00:03.83 |   80367 |      0 |
|*  4 |     HASH JOIN RIGHT OUTER |                   |      1 |      1 | 15205   (3)|   2812K|00:00:03.72 |   80367 |      0 |
|   5 |      TABLE ACCESS FULL    | MIGR_DC_LFCE_ENT  |      1 |      1 |     2   (0)|    372K|00:00:00.10 |   12661 |      0 |
|*  6 |      HASH JOIN RIGHT OUTER|                   |      1 |   2685K| 15189   (3)|   2686K|00:00:02.08 |   67706 |      0 |
|   7 |       TABLE ACCESS FULL   | MIGR_DC_CA        |      1 |      1 |     2   (0)|  13115 |00:00:00.01 |      98 |      0 |
|*  8 |       TABLE ACCESS FULL   | F_ENTREL          |      1 |   2685K| 15172   (3)|   2686K|00:00:01.84 |   67608 |      0 |
-------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   3 - filter(("MD"."REFDOSS"="FE"."ER_CONTR" OR "ME"."EF_REL"="FE"."ER_NUM"))
   4 - access("ME"."EF_REL"="FE"."ER_NUM")
   6 - access("MD"."REFDOSS"="FE"."ER_CONTR")
   8 - filter(("FE"."ER_CLI" IS NOT NULL AND "FE"."ER_DAT" IS NOT NULL AND "FE"."ER_DAT_DT" IS NOT NULL))
*/
/********************************New Metrics***************************************/

/********************************Index statistics**********************************/

/********************************Other SQLs****************************************/          
/*

*/ 
/********************************Other SQLs****************************************/              
