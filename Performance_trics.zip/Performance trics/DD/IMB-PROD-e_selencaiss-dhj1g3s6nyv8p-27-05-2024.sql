/********************************************************************************
*********       E-mail subject: IMBDEV-11990
*********             Instance: PROD
*********          Description: 
Problem:
SQL dhj1g3s6nyv8p was found in the V9 logs from screen e_selencaiss.

Analysis:
We analyzed SQL 3hgxvdu4wjffh, which based on the V9 logs was associated with the slowness in screen e_selencaiss.
There are two problems in this SQL. The first is the UPPER on crm.login ( UPPER(crm.login) LIKE UPPER(:B2) ), 
which doesn't allow to use the hint on column login. The second problem is the inappropriate hint. The combination of the two things 
doesn't allow Oracle to choose a good execution plan.

Suggestion:
Please change the SQL as it is shown in the New SQL section below.

*********               SQL_ID: dhj1g3s6nyv8p
*********      Program/Package: 
*********              Request: Dimitare Ivanov
*********               Author: Dimitar Dimitrov
********* Received e-mail date: 23/05/2024
*********      Resolution date: 27/05/2024
*********  Trace old file here: \\epox\specifs\performance\tmp\
*********  Trace new file here:
***********************************************************************************/

/********************************OLD SQL*******************************************/

var B1 varchar2(32);
exec :B1 := 'AN';
var B2 varchar2(32);
exec :B2 := 'J10ADWA';
var B3 number;
exec :B3 := 201;
var B4 number;
exec :B4 := 1;

SELECT *
  FROM (SELECT /*+ first_rows(201)*/
         foo.*, ROWNUM rnum
          FROM (SELECT referEncaiss referEncaiss,
                       typeElem typeElem,
                       (SELECT chemin
                          FROM v_tdomaine
                         WHERE TYPE = 'NAM_COLLECTE'
                           AND abrev = SUBSTR(compostage, 1, 3)
                           AND langue = :B1
                           AND ROWNUM = 1) bookCode,
                       SUM(amountAllocatedPaymentAccount) OVER() totalAmountMouvements,
                       receptionDate receptionDate,
                       dtconfirm_dt dtconfirm_dt,
                       clientName clientName,
                       vcsNumber vcsNumber,
                       fg19 fg19,
                       externalCase externalCase,
                       paymentSource paymentSource,
                       encaissAmount encaissAmount,
                       displayPaymentType displayPaymentType,
                       additionalCommunication additionalCommunication,
                       algorithmResult algorithmResult,
                       paymentType paymentType,
                       paymentIdentification paymentIdentification,
                       amountAllocatedPayment amountAllocatedPayment,
                       internalCaseReference internalCaseReference,
                       COUNT(1) OVER() totalNumberMouvements,
                       CASE
                         WHEN internalCaseReference IS NULL THEN
                          montantNc
                         WHEN upper(libelleBal) LIKE
                              'DELAI AVANT ENCAISSEMENT%' THEN
                          (SELECT NVL(abs(montant_dosBal), 0) -
                                  NVL((SELECT ftr_match.partprelettrpmt(refelemBal,
                                                                       refdossBal,
                                                                       typeelemBal)
                                        FROM dual),
                                      0)
                             FROM dual)
                         ELSE
                          (SELECT NVL(ABS(montant_dosBal), 0) -
                                  NVL((SELECT SUM(NVL(ABS(montant_dos), 0))
                                        FROM g_venelem
                                       WHERE refencaiss = refelemBal
                                         AND refdoss = refdossBal
                                         AND typencaiss = typeelemBal),
                                      0)
                             FROM dual)
                       END balance,
                       payerReference payerReference,
                       imxUserId imxUserId,
                       payerName payerName,
                       caseManagerName caseManagerName,
                       batchSearch batchSearch,
                       transStatus transStatus,
                       paymentStatus paymentStatus,
                       cancelationDate cancelationDate,
                       comments comments,
                       amountAllocatedPaymentAccount amountAllocatedPaymentAccount,
                       paymentReference paymentReference,
                       no_bordereau no_bordereau,
                       stampingNumber stampingNumber,
                       crmManager crmManager,
                       masterStampingNumber masterStampingNumber,
                       paymentTitle paymentTitle,
                       initialAmount initialAmount,
                       displayPaymentMethod displayPaymentMethod,
                       paymentMethod paymentMethod,
                       paymentDate paymentDate,
                       paymentCurrency paymentCurrency,
                       secondComment secondComment,
                       dtcompt dtcompt,
                       DECODE(internalCaseReference,
                              NULL,
                              devise,
                              (SELECT devise
                                 FROM g_dossier
                                WHERE refdoss = internalCaseReference)) balanceCurrency
                  FROM (SELECT main_query.refer referEncaiss,
                               main_query.refdossier internalCaseReference,
                               main_query.montant_dos encaissAmount,
                               main_query.date1 paymentDate,
                               main_query.refindividu payerReference,
                               main_query.date2 receptionDate,
                               main_query.type_enc paymentType,
                               main_query.type_enc_aff displayPaymentType,
                               main_query.libelle paymentTitle,
                               main_query.nom_payeur payerName,
                               main_query.mont_mvt amountAllocatedPayment,
                               main_query.mont_enc amountAllocatedPaymentAccount,
                               main_query.mont_init initialAmount,
                               main_query.dev_init paymentCurrency,
                               main_query.no_bordereau,
                               main_query.num_vcs vcsNumber,
                               main_query.moyp paymentMethod,
                               main_query.moyp_trad displayPaymentMethod,
                               main_query.num_cheque paymentReference,
                               main_query.annul_dt cancelationDate,
                               main_query.typeelem typeElem,
                               main_query.source_pmt paymentSource,
                               main_query.rangmt imxUserId,
                               main_query.monref,
                               main_query.dtconfirm_dt,
                               main_query.clientName,
                               main_query.fg19,
                               main_query.refer_doss externalCase,
                               main_query.dtcompt,
                               main_query.namcol_ref stampingNumber,
                               gp.login caseManagerName,
                               nc.dtlot batchSearch,
                               nc.comm paymentIdentification,
                               nc.comm2 secondComment,
                               nc.master_compostage masterStampingNumber,
                               nc.compostage,
                               nc.devise,
                               nc.etat transStatus,
                               v2.valeur_trad algorithmResult,
                               nc.comments,
                               DECODE(To_Char(nc.messages), NULL, 'N', 'O') additionalCommunication,
                               crm.login crmManager,
                               v3.valeur_trad paymentStatus,
                               bal.refelem refelemBal,
                               bal.refdoss refdossBal,
                               bal.typeelem typeelemBal,
                               bal.libelle libelleBal,
                               bal.montant_dos montant_dosBal,
                               nc.montant montantNc
                          FROM (SELECT /*+ index(TNMP aggreg_t_ecrdos_nmp$bal) leading(D) */
                                 EN.refencaiss REFER,
                                 VEN.refdoss REFDOSSIER,
                                 VEN.montant_dos montant_dos,
                                 t.dtassoc_dt DATE1,
                                 NVL(en.dtreception_dt, en.dtencaiss_dt) DATE2,
                                 'RECOUVREMENT DEBITEUR NON LETTRE' TYPE_ENC,
                                 'Debtor collection not fully matched' TYPE_ENC_AFF,
                                 v1.valeur_trad libelle,
                                 i.nom || ' ' || i.prenom NOM_PAYEUR,
                                 I.refindividu,
                                 VEN.montant_mvt MONT_MVT,
                                 t.montant MONT_ENC,
                                 NVL(DECODE(nc.signe, 1, -1, 1) * nc.montant,
                                     en.montant_mvt) MONT_INIT,
                                 NVL(nc.devise, en.devise_mvt) dev_INIT,
                                 EN.no_ordre NO_BORDEREAU,
                                 EN.num_vcs num_vcs,
                                 EN.moyenpaimt MOYP,
                                 moy.valeur_trad MOYP_TRAD,
                                 EN.numchq NUM_CHEQUE,
                                 Nvl(en.dtannul_dt, en.dtimpaye_dt) annul_dt,
                                 t.TYPEELEM typeelem,
                                 'ENCAISS' source_pmt,
                                 d.rangmt rangmt,
                                 (SELECT ctr.monref
                                    FROM g_dossier ctr,
                                         g_dossier deco,
                                         g_dossier cpt
                                   WHERE ctr.refdoss = deco.reflot
                                     AND deco.refdoss = cpt.reflot
                                     AND cpt.refdoss = d.refdoss
                                     AND cpt.refdoss = nc.refdoss
                                  UNION
                                  SELECT ctr.monref
                                    FROM g_dossier ctr, g_dossier dcpt
                                   WHERE ctr.refdoss = dcpt.reflot
                                     AND dcpt.refdoss = nc.refdoss
                                     AND dcpt.categdoss LIKE 'DECOMPTE%'
                                  UNION
                                  SELECT ctr.monref
                                    FROM g_dossier ctr
                                   WHERE ctr.refdoss = nc.refdoss
                                     AND ctr.categdoss LIKE 'CONTRAT%') monref,
                                 en.DTCONFIRM_DT DTCONFIRM_DT,
                                 CL.nom clientName,
                                 ACL.fg19,
                                 Nvl(D.ancrefdoss, t.refdoss) refer_doss,
                                 t.dtsaisie dtcompt,
                                 en.lieupaimt namcol_ref,
                                 en.refrepres,
                                 en.dtimpaye_dt
                                  FROM g_ventilenc VEN,
                                       g_encaissement EN,
                                       nam_collecte NC,
                                       aggreg_t_ecrdos_nmp TNMP,
                                       g_dossier D,
                                       T_ELEMENTS t,
                                       G_INDIVIDU i,
                                       t_intervenants tcl,
                                       g_individu cl,
                                       g_accords acl,
                                       (SELECT valeur,
                                               MAX(valeur_trad) valeur_trad
                                          FROM v_tdomaine
                                         WHERE type = 'libfds'
                                           AND langue = NVL(:B1, 'FR')
                                         GROUP BY valeur) v1,
                                       (SELECT valeur,
                                               MAX(valeur_trad) valeur_trad
                                          FROM v_tdomaine
                                         WHERE type = 'MOYENPAIMT'
                                           AND langue = :B1
                                         GROUP BY valeur) moy
                                 WHERE t.refelem = en.REFENCAISS
                                   AND t.refdoss = D.refdoss
                                   AND acl.refindividu(+) = cl.refindividu
                                   AND t.refelem = ven.refencaiss(+)
                                   AND t.refdoss = ven.refdoss(+)
                                   AND EN.moyenpaimt = moy.valeur(+)
                                   AND EN.libelle = v1.valeur(+)
                                   AND EN.traite = '2'
                                   AND NC.refer(+) = EN.refencaiss
                                   AND NC.compostage(+) = EN.lieupaimt
                                   AND VEN.refencaiss = TNMP.refelem
                                   AND VEN.refdoss = TNMP.refdoss
                                   AND TNMP.balance_dcpt < 0
                                   AND t.typeelem in ('en', 'vd')
                                   AND en.traite NOT IN ('9')
                                   AND en.typencaiss in
                                       ('e_saencaiss', 'e_savirmt')
                                   AND EN.REFPAYEUR = I.REFINDIVIDU
                                   AND tcl.refdoss = D.refdoss
                                   AND tcl.reftype = 'CL'
                                   AND tcl.refindividu = cl.refindividu) main_query,
                               nam_collecte nc,
                               g_personnel gp,
                               t_elements bal,
                               (SELECT abrev, MAX(valeur_trad) valeur_trad
                                  FROM v_tdomaine
                                 WHERE type = 'DV_IDENT_CODES'
                                   AND langue = :B1
                                 GROUP BY abrev) v2,
                               (SELECT abrev, MAX(valeur_trad) valeur_trad
                                  FROM v_tdomaine
                                 WHERE type = 'STATUT_PAIEMENT'
                                   AND langue = :B1
                                 GROUP BY abrev) v3,
                               g_personnel crm
                         WHERE main_query.namcol_ref = nc.compostage(+)
                           AND main_query.rangmt = gp.refperso(+)
                           AND main_query.monref = crm.refperso(+)
                           AND nc.traite = v2.abrev(+)
                           AND main_query.refer = bal.refelem(+)
                           AND main_query.refdossier = bal.refdoss(+)
                           AND DECODE(main_query.refrepres,
                                      NULL,
                                      DECODE(main_query.dtimpaye_dt,
                                             NULL,
                                             'ENCAISSE',
                                             'IMPAYE'),
                                      'REPRESENTE') = v3.abrev(+)
                           AND UPPER(crm.login) LIKE UPPER(:B2))
                 WHERE 1 = 1
                 ORDER BY paymentType,
                          DECODE(internalCaseReference,
                                 'REPART CHQ',
                                 'REPART CHQ',
                                 TO_NUMBER(internalCaseReference)),
                          paymentDate,
                          internalCaseReference) foo
         WHERE ROWNUM <= :B3)
 WHERE 1 = 1
   AND rnum >= :B4;
/********************************OLD SQL*******************************************/
/********************************OLD Metrics***************************************/
/*
MODULE                           SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL             PERC
-------------------------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
EE1E8ECC0129D241BC50A5973E92071B dhj1g3s6nyv8p  467985873       1582      35297                      2024/05/22 14:30:00  2024/05/22 14:31:41          99                    1 +000000000 00:01:40.350 99%
699264288D62D7CCD8E041A7392BBB6E bq81fvs05c3kt 1348103355       1582      35297 ON CPU               2024/05/22 14:32:42  2024/05/22 14:32:42           1                    1 +000000000 00:00:00.000 1%

INSTANCE_NUMBER SQL_ID            ELAPSED MAX_WAIT_ON     PC_OF  WAIT_TIME            GETS      READS       ROWS  ELAP/EXEC       GETS/EXEC READS/EXEC  ROWS/EXEC       EXEC PLAN_HASH_VALUE
--------------- ------------- ----------- --------------- ----- ---------- --------------- ---------- ---------- ---------- --------------- ---------- ---------- ---------- ---------------
              2 dhj1g3s6nyv8p         797 IO              56%   860.997317       112798988    1398837         14      797.3       112798988    1398837         14          1       467985873
              1 dhj1g3s6nyv8p         711 IO              53%   764.181916       112972067    1171153         14     711.36       112972067    1171153         14          1       467985873


Plan hash value: 467985873
------------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                                    | Name                    | Rows  | Bytes |TempSpc| Cost (%CPU)| Time     |
------------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                                             |                         |       |       |       |  3070K(100)|          |
|*  1 |  COUNT STOPKEY                                               |                         |       |       |       |            |          |
|   2 |   VIEW                                                       | V_TDOMAINE              |    37 | 22940 |       |    37   (0)| 00:00:01 |
|   3 |    UNION-ALL                                                 |                         |       |       |       |            |          |
|*  4 |     FILTER                                                   |                         |       |       |       |            |          |
|   5 |      TABLE ACCESS BY INDEX ROWID BATCHED                     | V_DOMAINE               |     1 |    23 |       |     1   (0)| 00:00:01 |
|*  6 |       INDEX RANGE SCAN                                       | DOM_TYPABREV            |     1 |       |       |     1   (0)| 00:00:01 |
|*  7 |     FILTER                                                   |                         |       |       |       |            |          |
|   8 |      TABLE ACCESS BY INDEX ROWID BATCHED                     | V_DOMAINE               |     1 |    23 |       |     1   (0)| 00:00:01 |
|*  9 |       INDEX RANGE SCAN                                       | DOM_TYPABREV            |     1 |       |       |     1   (0)| 00:00:01 |
|* 10 |     FILTER                                                   |                         |       |       |       |            |          |
|  11 |      TABLE ACCESS BY INDEX ROWID BATCHED                     | V_DOMAINE               |     1 |    23 |       |     1   (0)| 00:00:01 |
|* 12 |       INDEX RANGE SCAN                                       | DOM_TYPABREV            |     1 |       |       |     1   (0)| 00:00:01 |
|* 13 |     FILTER                                                   |                         |       |       |       |            |          |
|  14 |      TABLE ACCESS BY INDEX ROWID BATCHED                     | V_DOMAINE               |     1 |    23 |       |     1   (0)| 00:00:01 |
|* 15 |       INDEX RANGE SCAN                                       | DOM_TYPABREV            |     1 |       |       |     1   (0)| 00:00:01 |
|* 16 |     FILTER                                                   |                         |       |       |       |            |          |
|  17 |      TABLE ACCESS BY INDEX ROWID BATCHED                     | V_DOMAINE               |     1 |    23 |       |     1   (0)| 00:00:01 |
|* 18 |       INDEX RANGE SCAN                                       | DOM_TYPABREV            |     1 |       |       |     1   (0)| 00:00:01 |
|* 19 |     FILTER                                                   |                         |       |       |       |            |          |
|  20 |      TABLE ACCESS BY INDEX ROWID BATCHED                     | V_DOMAINE               |     1 |    23 |       |     1   (0)| 00:00:01 |
|* 21 |       INDEX RANGE SCAN                                       | DOM_TYPABREV            |     1 |       |       |     1   (0)| 00:00:01 |
|* 22 |     FILTER                                                   |                         |       |       |       |            |          |
|  23 |      TABLE ACCESS BY INDEX ROWID BATCHED                     | V_DOMAINE               |     1 |    23 |       |     1   (0)| 00:00:01 |
|* 24 |       INDEX RANGE SCAN                                       | DOM_TYPABREV            |     1 |       |       |     1   (0)| 00:00:01 |
|* 25 |     FILTER                                                   |                         |       |       |       |            |          |
|  26 |      TABLE ACCESS BY INDEX ROWID BATCHED                     | V_DOMAINE               |     1 |    23 |       |     1   (0)| 00:00:01 |
|* 27 |       INDEX RANGE SCAN                                       | DOM_TYPABREV            |     1 |       |       |     1   (0)| 00:00:01 |
|* 28 |     FILTER                                                   |                         |       |       |       |            |          |
|  29 |      TABLE ACCESS BY INDEX ROWID BATCHED                     | V_DOMAINE               |     1 |    23 |       |     1   (0)| 00:00:01 |
|* 30 |       INDEX RANGE SCAN                                       | DOM_TYPABREV            |     1 |       |       |     1   (0)| 00:00:01 |
|* 31 |     FILTER                                                   |                         |       |       |       |            |          |
|  32 |      TABLE ACCESS BY INDEX ROWID BATCHED                     | V_DOMAINE               |     1 |    23 |       |     1   (0)| 00:00:01 |
|* 33 |       INDEX RANGE SCAN                                       | DOM_TYPABREV            |     1 |       |       |     1   (0)| 00:00:01 |
|* 34 |     FILTER                                                   |                         |       |       |       |            |          |
|  35 |      TABLE ACCESS BY INDEX ROWID BATCHED                     | V_DOMAINE               |     1 |    23 |       |     1   (0)| 00:00:01 |
|* 36 |       INDEX RANGE SCAN                                       | DOM_TYPABREV            |     1 |       |       |     1   (0)| 00:00:01 |
|* 37 |     FILTER                                                   |                         |       |       |       |            |          |
|  38 |      TABLE ACCESS BY INDEX ROWID BATCHED                     | V_DOMAINE               |     1 |    23 |       |     1   (0)| 00:00:01 |
|* 39 |       INDEX RANGE SCAN                                       | DOM_TYPABREV            |     1 |       |       |     1   (0)| 00:00:01 |
|* 40 |     FILTER                                                   |                         |       |       |       |            |          |
|  41 |      TABLE ACCESS BY INDEX ROWID BATCHED                     | V_DOMAINE               |     1 |    23 |       |     1   (0)| 00:00:01 |
|* 42 |       INDEX RANGE SCAN                                       | DOM_TYPABREV            |     1 |       |       |     1   (0)| 00:00:01 |
|* 43 |     FILTER                                                   |                         |       |       |       |            |          |
|  44 |      TABLE ACCESS BY INDEX ROWID BATCHED                     | V_DOMAINE               |     1 |    23 |       |     1   (0)| 00:00:01 |
|* 45 |       INDEX RANGE SCAN                                       | DOM_TYPABREV            |     1 |       |       |     1   (0)| 00:00:01 |
|* 46 |     FILTER                                                   |                         |       |       |       |            |          |
|  47 |      TABLE ACCESS BY INDEX ROWID BATCHED                     | V_DOMAINE               |     1 |    23 |       |     1   (0)| 00:00:01 |
|* 48 |       INDEX RANGE SCAN                                       | DOM_TYPABREV            |     1 |       |       |     1   (0)| 00:00:01 |
|* 49 |     FILTER                                                   |                         |       |       |       |            |          |
|  50 |      TABLE ACCESS BY INDEX ROWID BATCHED                     | V_DOMAINE               |     1 |    23 |       |     1   (0)| 00:00:01 |
|* 51 |       INDEX RANGE SCAN                                       | DOM_TYPABREV            |     1 |       |       |     1   (0)| 00:00:01 |
|* 52 |     FILTER                                                   |                         |       |       |       |            |          |
|  53 |      TABLE ACCESS BY INDEX ROWID BATCHED                     | V_DOMAINE               |     1 |    23 |       |     1   (0)| 00:00:01 |
|* 54 |       INDEX RANGE SCAN                                       | DOM_TYPABREV            |     1 |       |       |     1   (0)| 00:00:01 |
|* 55 |     FILTER                                                   |                         |       |       |       |            |          |
|  56 |      TABLE ACCESS BY INDEX ROWID BATCHED                     | V_DOMAINE               |     1 |    23 |       |     1   (0)| 00:00:01 |
|* 57 |       INDEX RANGE SCAN                                       | DOM_TYPABREV            |     1 |       |       |     1   (0)| 00:00:01 |
|* 58 |     FILTER                                                   |                         |       |       |       |            |          |
|  59 |      TABLE ACCESS BY INDEX ROWID BATCHED                     | V_DOMAINE               |     1 |    23 |       |     1   (0)| 00:00:01 |
|* 60 |       INDEX RANGE SCAN                                       | DOM_TYPABREV            |     1 |       |       |     1   (0)| 00:00:01 |
|* 61 |     FILTER                                                   |                         |       |       |       |            |          |
|  62 |      TABLE ACCESS BY INDEX ROWID BATCHED                     | V_DOMAINE               |     1 |    23 |       |     1   (0)| 00:00:01 |
|* 63 |       INDEX RANGE SCAN                                       | DOM_TYPABREV            |     1 |       |       |     1   (0)| 00:00:01 |
|* 64 |     FILTER                                                   |                         |       |       |       |            |          |
|  65 |      TABLE ACCESS BY INDEX ROWID BATCHED                     | V_DOMAINE               |     1 |    23 |       |     1   (0)| 00:00:01 |
|* 66 |       INDEX RANGE SCAN                                       | DOM_TYPABREV            |     1 |       |       |     1   (0)| 00:00:01 |
|* 67 |     FILTER                                                   |                         |       |       |       |            |          |
|  68 |      TABLE ACCESS BY INDEX ROWID BATCHED                     | V_DOMAINE               |     1 |    23 |       |     1   (0)| 00:00:01 |
|* 69 |       INDEX RANGE SCAN                                       | DOM_TYPABREV            |     1 |       |       |     1   (0)| 00:00:01 |
|* 70 |     FILTER                                                   |                         |       |       |       |            |          |
|  71 |      TABLE ACCESS BY INDEX ROWID BATCHED                     | V_DOMAINE               |     1 |    23 |       |     1   (0)| 00:00:01 |
|* 72 |       INDEX RANGE SCAN                                       | DOM_TYPABREV            |     1 |       |       |     1   (0)| 00:00:01 |
|* 73 |     FILTER                                                   |                         |       |       |       |            |          |
|  74 |      TABLE ACCESS BY INDEX ROWID BATCHED                     | V_DOMAINE               |     1 |    23 |       |     1   (0)| 00:00:01 |
|* 75 |       INDEX RANGE SCAN                                       | DOM_TYPABREV            |     1 |       |       |     1   (0)| 00:00:01 |
|* 76 |     FILTER                                                   |                         |       |       |       |            |          |
|  77 |      TABLE ACCESS BY INDEX ROWID BATCHED                     | V_DOMAINE               |     1 |    23 |       |     1   (0)| 00:00:01 |
|* 78 |       INDEX RANGE SCAN                                       | DOM_TYPABREV            |     1 |       |       |     1   (0)| 00:00:01 |
|* 79 |     FILTER                                                   |                         |       |       |       |            |          |
|  80 |      TABLE ACCESS BY INDEX ROWID BATCHED                     | V_DOMAINE               |     1 |    23 |       |     1   (0)| 00:00:01 |
|* 81 |       INDEX RANGE SCAN                                       | DOM_TYPABREV            |     1 |       |       |     1   (0)| 00:00:01 |
|* 82 |     FILTER                                                   |                         |       |       |       |            |          |
|  83 |      TABLE ACCESS BY INDEX ROWID BATCHED                     | V_DOMAINE               |     1 |    23 |       |     1   (0)| 00:00:01 |
|* 84 |       INDEX RANGE SCAN                                       | DOM_TYPABREV            |     1 |       |       |     1   (0)| 00:00:01 |
|* 85 |     FILTER                                                   |                         |       |       |       |            |          |
|  86 |      TABLE ACCESS BY INDEX ROWID BATCHED                     | V_DOMAINE               |     1 |    23 |       |     1   (0)| 00:00:01 |
|* 87 |       INDEX RANGE SCAN                                       | DOM_TYPABREV            |     1 |       |       |     1   (0)| 00:00:01 |
|* 88 |     FILTER                                                   |                         |       |       |       |            |          |
|  89 |      TABLE ACCESS BY INDEX ROWID BATCHED                     | V_DOMAINE               |     1 |    23 |       |     1   (0)| 00:00:01 |
|* 90 |       INDEX RANGE SCAN                                       | DOM_TYPABREV            |     1 |       |       |     1   (0)| 00:00:01 |
|* 91 |     FILTER                                                   |                         |       |       |       |            |          |
|  92 |      TABLE ACCESS BY INDEX ROWID BATCHED                     | V_DOMAINE               |     1 |    23 |       |     1   (0)| 00:00:01 |
|* 93 |       INDEX RANGE SCAN                                       | DOM_TYPABREV            |     1 |       |       |     1   (0)| 00:00:01 |
|* 94 |     FILTER                                                   |                         |       |       |       |            |          |
|  95 |      TABLE ACCESS BY INDEX ROWID BATCHED                     | V_DOMAINE               |     1 |    23 |       |     1   (0)| 00:00:01 |
|* 96 |       INDEX RANGE SCAN                                       | DOM_TYPABREV            |     1 |       |       |     1   (0)| 00:00:01 |
|* 97 |     FILTER                                                   |                         |       |       |       |            |          |
|  98 |      TABLE ACCESS BY INDEX ROWID BATCHED                     | V_DOMAINE               |     1 |    23 |       |     1   (0)| 00:00:01 |
|* 99 |       INDEX RANGE SCAN                                       | DOM_TYPABREV            |     1 |       |       |     1   (0)| 00:00:01 |
|*100 |     FILTER                                                   |                         |       |       |       |            |          |
| 101 |      TABLE ACCESS BY INDEX ROWID BATCHED                     | V_DOMAINE               |     1 |    23 |       |     1   (0)| 00:00:01 |
|*102 |       INDEX RANGE SCAN                                       | DOM_TYPABREV            |     1 |       |       |     1   (0)| 00:00:01 |
|*103 |     FILTER                                                   |                         |       |       |       |            |          |
| 104 |      TABLE ACCESS BY INDEX ROWID BATCHED                     | V_DOMAINE               |     1 |    23 |       |     1   (0)| 00:00:01 |
|*105 |       INDEX RANGE SCAN                                       | DOM_TYPABREV            |     1 |       |       |     1   (0)| 00:00:01 |
|*106 |     FILTER                                                   |                         |       |       |       |            |          |
| 107 |      TABLE ACCESS BY INDEX ROWID BATCHED                     | V_DOMAINE               |     1 |    23 |       |     1   (0)| 00:00:01 |
|*108 |       INDEX RANGE SCAN                                       | DOM_TYPABREV            |     1 |       |       |     1   (0)| 00:00:01 |
|*109 |     FILTER                                                   |                         |       |       |       |            |          |
| 110 |      TABLE ACCESS BY INDEX ROWID BATCHED                     | V_DOMAINE               |     1 |    23 |       |     1   (0)| 00:00:01 |
|*111 |       INDEX RANGE SCAN                                       | DOM_TYPABREV            |     1 |       |       |     1   (0)| 00:00:01 |
|*112 |     FILTER                                                   |                         |       |       |       |            |          |
| 113 |      TABLE ACCESS BY INDEX ROWID BATCHED                     | V_DOMAINE               |     1 |    23 |       |     1   (0)| 00:00:01 |
|*114 |       INDEX RANGE SCAN                                       | DOM_TYPABREV            |     1 |       |       |     1   (0)| 00:00:01 |
| 115 |  FAST DUAL                                                   |                         |     1 |       |       |     2   (0)| 00:00:01 |
| 116 |  FAST DUAL                                                   |                         |     1 |       |       |     2   (0)| 00:00:01 |
| 117 |   SORT AGGREGATE                                             |                         |     1 |    28 |       |            |          |
|*118 |    TABLE ACCESS BY INDEX ROWID BATCHED                       | G_VENELEM               |     1 |    28 |       |     1   (0)| 00:00:01 |
|*119 |     INDEX RANGE SCAN                                         | VEN_ENCAIS              |     1 |       |       |     1   (0)| 00:00:01 |
| 120 |   FAST DUAL                                                  |                         |     1 |       |       |     2   (0)| 00:00:01 |
| 121 |  TABLE ACCESS BY INDEX ROWID                                 | G_DOSSIER               |     1 |    15 |       |     1   (0)| 00:00:01 |
|*122 |   INDEX UNIQUE SCAN                                          | DOS_REFDOSS             |     1 |       |       |     1   (0)| 00:00:01 |
|*123 |  VIEW                                                        |                         |   201 |  1134K|       |  3070K  (1)| 00:02:00 |
|*124 |   COUNT STOPKEY                                              |                         |       |       |       |            |          |
| 125 |    VIEW                                                      |                         |   202 |  1138K|       |  3070K  (1)| 00:02:00 |
| 126 |     WINDOW SORT                                              |                         |   202 |  1740K|       |  3070K  (1)| 00:02:00 |
|*127 |      FILTER                                                  |                         |       |       |       |            |          |
|*128 |       HASH JOIN RIGHT OUTER                                  |                         |   202 |  1740K|       |  3066K  (1)| 00:02:00 |
| 129 |        VIEW                                                  |                         |    45 | 19530 |       |    38   (3)| 00:00:01 |
| 130 |         HASH GROUP BY                                        |                         |    45 | 18360 |       |    38   (3)| 00:00:01 |
| 131 |          VIEW                                                | V_TDOMAINE              |  1665 |   663K|       |    37   (0)| 00:00:01 |
| 132 |           UNION-ALL                                          |                         |       |       |       |            |          |
|*133 |            FILTER                                            |                         |       |       |       |            |          |
| 134 |             TABLE ACCESS BY INDEX ROWID BATCHED              | V_DOMAINE               |    45 |  1440 |       |     1   (0)| 00:00:01 |
|*135 |              INDEX RANGE SCAN                                | V_DOMAINE_TYPE_CODE_IDX |    45 |       |       |     1   (0)| 00:00:01 |
|*136 |            FILTER                                            |                         |       |       |       |            |          |
| 137 |             TABLE ACCESS BY INDEX ROWID BATCHED              | V_DOMAINE               |    45 |  1575 |       |     1   (0)| 00:00:01 |
|*138 |              INDEX RANGE SCAN                                | V_DOMAINE_TYPE_CODE_IDX |    45 |       |       |     1   (0)| 00:00:01 |
|*139 |            FILTER                                            |                         |       |       |       |            |          |
| 140 |             TABLE ACCESS BY INDEX ROWID BATCHED              | V_DOMAINE               |    45 |   990 |       |     1   (0)| 00:00:01 |
|*141 |              INDEX RANGE SCAN                                | V_DOMAINE_TYPE_CODE_IDX |    45 |       |       |     1   (0)| 00:00:01 |
|*142 |            FILTER                                            |                         |       |       |       |            |          |
| 143 |             TABLE ACCESS BY INDEX ROWID BATCHED              | V_DOMAINE               |    45 |   990 |       |     1   (0)| 00:00:01 |
|*144 |              INDEX RANGE SCAN                                | V_DOMAINE_TYPE_CODE_IDX |    45 |       |       |     1   (0)| 00:00:01 |
|*145 |            FILTER                                            |                         |       |       |       |            |          |
| 146 |             TABLE ACCESS BY INDEX ROWID BATCHED              | V_DOMAINE               |    45 | 14220 |       |     1   (0)| 00:00:01 |
|*147 |              INDEX RANGE SCAN                                | V_DOMAINE_TYPE_CODE_IDX |    45 |       |       |     1   (0)| 00:00:01 |
|*148 |            FILTER                                            |                         |       |       |       |            |          |
| 149 |             TABLE ACCESS BY INDEX ROWID BATCHED              | V_DOMAINE               |    45 |   990 |       |     1   (0)| 00:00:01 |
|*150 |              INDEX RANGE SCAN                                | V_DOMAINE_TYPE_CODE_IDX |    45 |       |       |     1   (0)| 00:00:01 |
|*151 |            FILTER                                            |                         |       |       |       |            |          |
| 152 |             TABLE ACCESS BY INDEX ROWID BATCHED              | V_DOMAINE               |    45 |   990 |       |     1   (0)| 00:00:01 |
|*153 |              INDEX RANGE SCAN                                | V_DOMAINE_TYPE_CODE_IDX |    45 |       |       |     1   (0)| 00:00:01 |
|*154 |            FILTER                                            |                         |       |       |       |            |          |
| 155 |             TABLE ACCESS BY INDEX ROWID BATCHED              | V_DOMAINE               |    45 |   990 |       |     1   (0)| 00:00:01 |
|*156 |              INDEX RANGE SCAN                                | V_DOMAINE_TYPE_CODE_IDX |    45 |       |       |     1   (0)| 00:00:01 |
|*157 |            FILTER                                            |                         |       |       |       |            |          |
| 158 |             TABLE ACCESS BY INDEX ROWID BATCHED              | V_DOMAINE               |    45 |   990 |       |     1   (0)| 00:00:01 |
|*159 |              INDEX RANGE SCAN                                | V_DOMAINE_TYPE_CODE_IDX |    45 |       |       |     1   (0)| 00:00:01 |
|*160 |            FILTER                                            |                         |       |       |       |            |          |
| 161 |             TABLE ACCESS BY INDEX ROWID BATCHED              | V_DOMAINE               |    45 | 14220 |       |     1   (0)| 00:00:01 |
|*162 |              INDEX RANGE SCAN                                | V_DOMAINE_TYPE_CODE_IDX |    45 |       |       |     1   (0)| 00:00:01 |
|*163 |            FILTER                                            |                         |       |       |       |            |          |
| 164 |             TABLE ACCESS BY INDEX ROWID BATCHED              | V_DOMAINE               |    45 |  1260 |       |     1   (0)| 00:00:01 |
|*165 |              INDEX RANGE SCAN                                | V_DOMAINE_TYPE_CODE_IDX |    45 |       |       |     1   (0)| 00:00:01 |
|*166 |            FILTER                                            |                         |       |       |       |            |          |
| 167 |             TABLE ACCESS BY INDEX ROWID BATCHED              | V_DOMAINE               |    45 |   990 |       |     1   (0)| 00:00:01 |
|*168 |              INDEX RANGE SCAN                                | V_DOMAINE_TYPE_CODE_IDX |    45 |       |       |     1   (0)| 00:00:01 |
|*169 |            FILTER                                            |                         |       |       |       |            |          |
| 170 |             TABLE ACCESS BY INDEX ROWID BATCHED              | V_DOMAINE               |    45 | 14220 |       |     1   (0)| 00:00:01 |
|*171 |              INDEX RANGE SCAN                                | V_DOMAINE_TYPE_CODE_IDX |    45 |       |       |     1   (0)| 00:00:01 |
|*172 |            FILTER                                            |                         |       |       |       |            |          |
| 173 |             TABLE ACCESS BY INDEX ROWID BATCHED              | V_DOMAINE               |    45 |   990 |       |     1   (0)| 00:00:01 |
|*174 |              INDEX RANGE SCAN                                | V_DOMAINE_TYPE_CODE_IDX |    45 |       |       |     1   (0)| 00:00:01 |
|*175 |            FILTER                                            |                         |       |       |       |            |          |
| 176 |             TABLE ACCESS BY INDEX ROWID BATCHED              | V_DOMAINE               |    45 |  2340 |       |     1   (0)| 00:00:01 |
|*177 |              INDEX RANGE SCAN                                | V_DOMAINE_TYPE_CODE_IDX |    45 |       |       |     1   (0)| 00:00:01 |
|*178 |            FILTER                                            |                         |       |       |       |            |          |
| 179 |             TABLE ACCESS BY INDEX ROWID BATCHED              | V_DOMAINE               |    45 |   990 |       |     1   (0)| 00:00:01 |
|*180 |              INDEX RANGE SCAN                                | V_DOMAINE_TYPE_CODE_IDX |    45 |       |       |     1   (0)| 00:00:01 |
|*181 |            FILTER                                            |                         |       |       |       |            |          |
| 182 |             TABLE ACCESS BY INDEX ROWID BATCHED              | V_DOMAINE               |    45 |   990 |       |     1   (0)| 00:00:01 |
|*183 |              INDEX RANGE SCAN                                | V_DOMAINE_TYPE_CODE_IDX |    45 |       |       |     1   (0)| 00:00:01 |
|*184 |            FILTER                                            |                         |       |       |       |            |          |
| 185 |             TABLE ACCESS BY INDEX ROWID BATCHED              | V_DOMAINE               |    45 |   990 |       |     1   (0)| 00:00:01 |
|*186 |              INDEX RANGE SCAN                                | V_DOMAINE_TYPE_CODE_IDX |    45 |       |       |     1   (0)| 00:00:01 |
|*187 |            FILTER                                            |                         |       |       |       |            |          |
| 188 |             TABLE ACCESS BY INDEX ROWID BATCHED              | V_DOMAINE               |    45 |   990 |       |     1   (0)| 00:00:01 |
|*189 |              INDEX RANGE SCAN                                | V_DOMAINE_TYPE_CODE_IDX |    45 |       |       |     1   (0)| 00:00:01 |
|*190 |            FILTER                                            |                         |       |       |       |            |          |
| 191 |             TABLE ACCESS BY INDEX ROWID BATCHED              | V_DOMAINE               |    45 |   990 |       |     1   (0)| 00:00:01 |
|*192 |              INDEX RANGE SCAN                                | V_DOMAINE_TYPE_CODE_IDX |    45 |       |       |     1   (0)| 00:00:01 |
|*193 |            FILTER                                            |                         |       |       |       |            |          |
| 194 |             TABLE ACCESS BY INDEX ROWID BATCHED              | V_DOMAINE               |    45 |   990 |       |     1   (0)| 00:00:01 |
|*195 |              INDEX RANGE SCAN                                | V_DOMAINE_TYPE_CODE_IDX |    45 |       |       |     1   (0)| 00:00:01 |
|*196 |            FILTER                                            |                         |       |       |       |            |          |
| 197 |             TABLE ACCESS BY INDEX ROWID BATCHED              | V_DOMAINE               |    45 |   990 |       |     1   (0)| 00:00:01 |
|*198 |              INDEX RANGE SCAN                                | V_DOMAINE_TYPE_CODE_IDX |    45 |       |       |     1   (0)| 00:00:01 |
|*199 |            FILTER                                            |                         |       |       |       |            |          |
| 200 |             TABLE ACCESS BY INDEX ROWID BATCHED              | V_DOMAINE               |    45 |  1260 |       |     1   (0)| 00:00:01 |
|*201 |              INDEX RANGE SCAN                                | V_DOMAINE_TYPE_CODE_IDX |    45 |       |       |     1   (0)| 00:00:01 |
|*202 |            FILTER                                            |                         |       |       |       |            |          |
| 203 |             TABLE ACCESS BY INDEX ROWID BATCHED              | V_DOMAINE               |    45 | 14220 |       |     1   (0)| 00:00:01 |
|*204 |              INDEX RANGE SCAN                                | V_DOMAINE_TYPE_CODE_IDX |    45 |       |       |     1   (0)| 00:00:01 |
|*205 |            FILTER                                            |                         |       |       |       |            |          |
| 206 |             TABLE ACCESS BY INDEX ROWID BATCHED              | V_DOMAINE               |    45 | 14220 |       |     1   (0)| 00:00:01 |
|*207 |              INDEX RANGE SCAN                                | V_DOMAINE_TYPE_CODE_IDX |    45 |       |       |     1   (0)| 00:00:01 |
|*208 |            FILTER                                            |                         |       |       |       |            |          |
| 209 |             TABLE ACCESS BY INDEX ROWID BATCHED              | V_DOMAINE               |    45 |   990 |       |     1   (0)| 00:00:01 |
|*210 |              INDEX RANGE SCAN                                | V_DOMAINE_TYPE_CODE_IDX |    45 |       |       |     1   (0)| 00:00:01 |
|*211 |            FILTER                                            |                         |       |       |       |            |          |
| 212 |             TABLE ACCESS BY INDEX ROWID BATCHED              | V_DOMAINE               |    45 |   990 |       |     1   (0)| 00:00:01 |
|*213 |              INDEX RANGE SCAN                                | V_DOMAINE_TYPE_CODE_IDX |    45 |       |       |     1   (0)| 00:00:01 |
|*214 |            FILTER                                            |                         |       |       |       |            |          |
| 215 |             TABLE ACCESS BY INDEX ROWID BATCHED              | V_DOMAINE               |    45 |   990 |       |     1   (0)| 00:00:01 |
|*216 |              INDEX RANGE SCAN                                | V_DOMAINE_TYPE_CODE_IDX |    45 |       |       |     1   (0)| 00:00:01 |
|*217 |            FILTER                                            |                         |       |       |       |            |          |
| 218 |             TABLE ACCESS BY INDEX ROWID BATCHED              | V_DOMAINE               |    45 |   990 |       |     1   (0)| 00:00:01 |
|*219 |              INDEX RANGE SCAN                                | V_DOMAINE_TYPE_CODE_IDX |    45 |       |       |     1   (0)| 00:00:01 |
|*220 |            FILTER                                            |                         |       |       |       |            |          |
| 221 |             TABLE ACCESS BY INDEX ROWID BATCHED              | V_DOMAINE               |    45 |   990 |       |     1   (0)| 00:00:01 |
|*222 |              INDEX RANGE SCAN                                | V_DOMAINE_TYPE_CODE_IDX |    45 |       |       |     1   (0)| 00:00:01 |
|*223 |            FILTER                                            |                         |       |       |       |            |          |
| 224 |             TABLE ACCESS BY INDEX ROWID BATCHED              | V_DOMAINE               |    45 |   990 |       |     1   (0)| 00:00:01 |
|*225 |              INDEX RANGE SCAN                                | V_DOMAINE_TYPE_CODE_IDX |    45 |       |       |     1   (0)| 00:00:01 |
|*226 |            FILTER                                            |                         |       |       |       |            |          |
| 227 |             TABLE ACCESS BY INDEX ROWID BATCHED              | V_DOMAINE               |    45 |   990 |       |     1   (0)| 00:00:01 |
|*228 |              INDEX RANGE SCAN                                | V_DOMAINE_TYPE_CODE_IDX |    45 |       |       |     1   (0)| 00:00:01 |
|*229 |            FILTER                                            |                         |       |       |       |            |          |
| 230 |             TABLE ACCESS BY INDEX ROWID BATCHED              | V_DOMAINE               |    45 |   990 |       |     1   (0)| 00:00:01 |
|*231 |              INDEX RANGE SCAN                                | V_DOMAINE_TYPE_CODE_IDX |    45 |       |       |     1   (0)| 00:00:01 |
|*232 |            FILTER                                            |                         |       |       |       |            |          |
| 233 |             TABLE ACCESS BY INDEX ROWID BATCHED              | V_DOMAINE               |    45 |   990 |       |     1   (0)| 00:00:01 |
|*234 |              INDEX RANGE SCAN                                | V_DOMAINE_TYPE_CODE_IDX |    45 |       |       |     1   (0)| 00:00:01 |
|*235 |            FILTER                                            |                         |       |       |       |            |          |
| 236 |             TABLE ACCESS BY INDEX ROWID BATCHED              | V_DOMAINE               |    45 |  1215 |       |     1   (0)| 00:00:01 |
|*237 |              INDEX RANGE SCAN                                | V_DOMAINE_TYPE_CODE_IDX |    45 |       |       |     1   (0)| 00:00:01 |
|*238 |            FILTER                                            |                         |       |       |       |            |          |
| 239 |             TABLE ACCESS BY INDEX ROWID BATCHED              | V_DOMAINE               |    45 |   990 |       |     1   (0)| 00:00:01 |
|*240 |              INDEX RANGE SCAN                                | V_DOMAINE_TYPE_CODE_IDX |    45 |       |       |     1   (0)| 00:00:01 |
|*241 |            FILTER                                            |                         |       |       |       |            |          |
| 242 |             TABLE ACCESS BY INDEX ROWID BATCHED              | V_DOMAINE               |    45 | 14220 |       |     1   (0)| 00:00:01 |
|*243 |              INDEX RANGE SCAN                                | V_DOMAINE_TYPE_CODE_IDX |    45 |       |       |     1   (0)| 00:00:01 |
|*244 |        HASH JOIN RIGHT OUTER                                 |                         |   202 |  1210K|       |  3066K  (1)| 00:02:00 |
| 245 |         VIEW                                                 |                         |    45 | 19530 |       |    38   (3)| 00:00:01 |
| 246 |          HASH GROUP BY                                       |                         |    45 | 18360 |       |    38   (3)| 00:00:01 |
| 247 |           VIEW                                               | V_TDOMAINE              |  1665 |   663K|       |    37   (0)| 00:00:01 |
| 248 |            UNION-ALL                                         |                         |       |       |       |            |          |
|*249 |             FILTER                                           |                         |       |       |       |            |          |
| 250 |              TABLE ACCESS BY INDEX ROWID BATCHED             | V_DOMAINE               |    45 |  1440 |       |     1   (0)| 00:00:01 |
|*251 |               INDEX RANGE SCAN                               | V_DOMAINE_TYPE_CODE_IDX |    45 |       |       |     1   (0)| 00:00:01 |
|*252 |             FILTER                                           |                         |       |       |       |            |          |
| 253 |              TABLE ACCESS BY INDEX ROWID BATCHED             | V_DOMAINE               |    45 |  1575 |       |     1   (0)| 00:00:01 |
|*254 |               INDEX RANGE SCAN                               | V_DOMAINE_TYPE_CODE_IDX |    45 |       |       |     1   (0)| 00:00:01 |
|*255 |             FILTER                                           |                         |       |       |       |            |          |
| 256 |              TABLE ACCESS BY INDEX ROWID BATCHED             | V_DOMAINE               |    45 |   990 |       |     1   (0)| 00:00:01 |
|*257 |               INDEX RANGE SCAN                               | V_DOMAINE_TYPE_CODE_IDX |    45 |       |       |     1   (0)| 00:00:01 |
|*258 |             FILTER                                           |                         |       |       |       |            |          |
| 259 |              TABLE ACCESS BY INDEX ROWID BATCHED             | V_DOMAINE               |    45 |   990 |       |     1   (0)| 00:00:01 |
|*260 |               INDEX RANGE SCAN                               | V_DOMAINE_TYPE_CODE_IDX |    45 |       |       |     1   (0)| 00:00:01 |
|*261 |             FILTER                                           |                         |       |       |       |            |          |
| 262 |              TABLE ACCESS BY INDEX ROWID BATCHED             | V_DOMAINE               |    45 | 14220 |       |     1   (0)| 00:00:01 |
|*263 |               INDEX RANGE SCAN                               | V_DOMAINE_TYPE_CODE_IDX |    45 |       |       |     1   (0)| 00:00:01 |
|*264 |             FILTER                                           |                         |       |       |       |            |          |
| 265 |              TABLE ACCESS BY INDEX ROWID BATCHED             | V_DOMAINE               |    45 |   990 |       |     1   (0)| 00:00:01 |
|*266 |               INDEX RANGE SCAN                               | V_DOMAINE_TYPE_CODE_IDX |    45 |       |       |     1   (0)| 00:00:01 |
|*267 |             FILTER                                           |                         |       |       |       |            |          |
| 268 |              TABLE ACCESS BY INDEX ROWID BATCHED             | V_DOMAINE               |    45 |   990 |       |     1   (0)| 00:00:01 |
|*269 |               INDEX RANGE SCAN                               | V_DOMAINE_TYPE_CODE_IDX |    45 |       |       |     1   (0)| 00:00:01 |
|*270 |             FILTER                                           |                         |       |       |       |            |          |
| 271 |              TABLE ACCESS BY INDEX ROWID BATCHED             | V_DOMAINE               |    45 |   990 |       |     1   (0)| 00:00:01 |
|*272 |               INDEX RANGE SCAN                               | V_DOMAINE_TYPE_CODE_IDX |    45 |       |       |     1   (0)| 00:00:01 |
|*273 |             FILTER                                           |                         |       |       |       |            |          |
| 274 |              TABLE ACCESS BY INDEX ROWID BATCHED             | V_DOMAINE               |    45 |   990 |       |     1   (0)| 00:00:01 |
|*275 |               INDEX RANGE SCAN                               | V_DOMAINE_TYPE_CODE_IDX |    45 |       |       |     1   (0)| 00:00:01 |
|*276 |             FILTER                                           |                         |       |       |       |            |          |
| 277 |              TABLE ACCESS BY INDEX ROWID BATCHED             | V_DOMAINE               |    45 | 14220 |       |     1   (0)| 00:00:01 |
|*278 |               INDEX RANGE SCAN                               | V_DOMAINE_TYPE_CODE_IDX |    45 |       |       |     1   (0)| 00:00:01 |
|*279 |             FILTER                                           |                         |       |       |       |            |          |
| 280 |              TABLE ACCESS BY INDEX ROWID BATCHED             | V_DOMAINE               |    45 |  1260 |       |     1   (0)| 00:00:01 |
|*281 |               INDEX RANGE SCAN                               | V_DOMAINE_TYPE_CODE_IDX |    45 |       |       |     1   (0)| 00:00:01 |
|*282 |             FILTER                                           |                         |       |       |       |            |          |
| 283 |              TABLE ACCESS BY INDEX ROWID BATCHED             | V_DOMAINE               |    45 |   990 |       |     1   (0)| 00:00:01 |
|*284 |               INDEX RANGE SCAN                               | V_DOMAINE_TYPE_CODE_IDX |    45 |       |       |     1   (0)| 00:00:01 |
|*285 |             FILTER                                           |                         |       |       |       |            |          |
| 286 |              TABLE ACCESS BY INDEX ROWID BATCHED             | V_DOMAINE               |    45 | 14220 |       |     1   (0)| 00:00:01 |
|*287 |               INDEX RANGE SCAN                               | V_DOMAINE_TYPE_CODE_IDX |    45 |       |       |     1   (0)| 00:00:01 |
|*288 |             FILTER                                           |                         |       |       |       |            |          |
| 289 |              TABLE ACCESS BY INDEX ROWID BATCHED             | V_DOMAINE               |    45 |   990 |       |     1   (0)| 00:00:01 |
|*290 |               INDEX RANGE SCAN                               | V_DOMAINE_TYPE_CODE_IDX |    45 |       |       |     1   (0)| 00:00:01 |
|*291 |             FILTER                                           |                         |       |       |       |            |          |
| 292 |              TABLE ACCESS BY INDEX ROWID BATCHED             | V_DOMAINE               |    45 |  2340 |       |     1   (0)| 00:00:01 |
|*293 |               INDEX RANGE SCAN                               | V_DOMAINE_TYPE_CODE_IDX |    45 |       |       |     1   (0)| 00:00:01 |
|*294 |             FILTER                                           |                         |       |       |       |            |          |
| 295 |              TABLE ACCESS BY INDEX ROWID BATCHED             | V_DOMAINE               |    45 |   990 |       |     1   (0)| 00:00:01 |
|*296 |               INDEX RANGE SCAN                               | V_DOMAINE_TYPE_CODE_IDX |    45 |       |       |     1   (0)| 00:00:01 |
|*297 |             FILTER                                           |                         |       |       |       |            |          |
| 298 |              TABLE ACCESS BY INDEX ROWID BATCHED             | V_DOMAINE               |    45 |   990 |       |     1   (0)| 00:00:01 |
|*299 |               INDEX RANGE SCAN                               | V_DOMAINE_TYPE_CODE_IDX |    45 |       |       |     1   (0)| 00:00:01 |
|*300 |             FILTER                                           |                         |       |       |       |            |          |
| 301 |              TABLE ACCESS BY INDEX ROWID BATCHED             | V_DOMAINE               |    45 |   990 |       |     1   (0)| 00:00:01 |
|*302 |               INDEX RANGE SCAN                               | V_DOMAINE_TYPE_CODE_IDX |    45 |       |       |     1   (0)| 00:00:01 |
|*303 |             FILTER                                           |                         |       |       |       |            |          |
| 304 |              TABLE ACCESS BY INDEX ROWID BATCHED             | V_DOMAINE               |    45 |   990 |       |     1   (0)| 00:00:01 |
|*305 |               INDEX RANGE SCAN                               | V_DOMAINE_TYPE_CODE_IDX |    45 |       |       |     1   (0)| 00:00:01 |
|*306 |             FILTER                                           |                         |       |       |       |            |          |
| 307 |              TABLE ACCESS BY INDEX ROWID BATCHED             | V_DOMAINE               |    45 |   990 |       |     1   (0)| 00:00:01 |
|*308 |               INDEX RANGE SCAN                               | V_DOMAINE_TYPE_CODE_IDX |    45 |       |       |     1   (0)| 00:00:01 |
|*309 |             FILTER                                           |                         |       |       |       |            |          |
| 310 |              TABLE ACCESS BY INDEX ROWID BATCHED             | V_DOMAINE               |    45 |   990 |       |     1   (0)| 00:00:01 |
|*311 |               INDEX RANGE SCAN                               | V_DOMAINE_TYPE_CODE_IDX |    45 |       |       |     1   (0)| 00:00:01 |
|*312 |             FILTER                                           |                         |       |       |       |            |          |
| 313 |              TABLE ACCESS BY INDEX ROWID BATCHED             | V_DOMAINE               |    45 |   990 |       |     1   (0)| 00:00:01 |
|*314 |               INDEX RANGE SCAN                               | V_DOMAINE_TYPE_CODE_IDX |    45 |       |       |     1   (0)| 00:00:01 |
|*315 |             FILTER                                           |                         |       |       |       |            |          |
| 316 |              TABLE ACCESS BY INDEX ROWID BATCHED             | V_DOMAINE               |    45 |  1260 |       |     1   (0)| 00:00:01 |
|*317 |               INDEX RANGE SCAN                               | V_DOMAINE_TYPE_CODE_IDX |    45 |       |       |     1   (0)| 00:00:01 |
|*318 |             FILTER                                           |                         |       |       |       |            |          |
| 319 |              TABLE ACCESS BY INDEX ROWID BATCHED             | V_DOMAINE               |    45 | 14220 |       |     1   (0)| 00:00:01 |
|*320 |               INDEX RANGE SCAN                               | V_DOMAINE_TYPE_CODE_IDX |    45 |       |       |     1   (0)| 00:00:01 |
|*321 |             FILTER                                           |                         |       |       |       |            |          |
| 322 |              TABLE ACCESS BY INDEX ROWID BATCHED             | V_DOMAINE               |    45 | 14220 |       |     1   (0)| 00:00:01 |
|*323 |               INDEX RANGE SCAN                               | V_DOMAINE_TYPE_CODE_IDX |    45 |       |       |     1   (0)| 00:00:01 |
|*324 |             FILTER                                           |                         |       |       |       |            |          |
| 325 |              TABLE ACCESS BY INDEX ROWID BATCHED             | V_DOMAINE               |    45 |   990 |       |     1   (0)| 00:00:01 |
|*326 |               INDEX RANGE SCAN                               | V_DOMAINE_TYPE_CODE_IDX |    45 |       |       |     1   (0)| 00:00:01 |
|*327 |             FILTER                                           |                         |       |       |       |            |          |
| 328 |              TABLE ACCESS BY INDEX ROWID BATCHED             | V_DOMAINE               |    45 |   990 |       |     1   (0)| 00:00:01 |
|*329 |               INDEX RANGE SCAN                               | V_DOMAINE_TYPE_CODE_IDX |    45 |       |       |     1   (0)| 00:00:01 |
|*330 |             FILTER                                           |                         |       |       |       |            |          |
| 331 |              TABLE ACCESS BY INDEX ROWID BATCHED             | V_DOMAINE               |    45 |   990 |       |     1   (0)| 00:00:01 |
|*332 |               INDEX RANGE SCAN                               | V_DOMAINE_TYPE_CODE_IDX |    45 |       |       |     1   (0)| 00:00:01 |
|*333 |             FILTER                                           |                         |       |       |       |            |          |
| 334 |              TABLE ACCESS BY INDEX ROWID BATCHED             | V_DOMAINE               |    45 |   990 |       |     1   (0)| 00:00:01 |
|*335 |               INDEX RANGE SCAN                               | V_DOMAINE_TYPE_CODE_IDX |    45 |       |       |     1   (0)| 00:00:01 |
|*336 |             FILTER                                           |                         |       |       |       |            |          |
| 337 |              TABLE ACCESS BY INDEX ROWID BATCHED             | V_DOMAINE               |    45 |   990 |       |     1   (0)| 00:00:01 |
|*338 |               INDEX RANGE SCAN                               | V_DOMAINE_TYPE_CODE_IDX |    45 |       |       |     1   (0)| 00:00:01 |
|*339 |             FILTER                                           |                         |       |       |       |            |          |
| 340 |              TABLE ACCESS BY INDEX ROWID BATCHED             | V_DOMAINE               |    45 |   990 |       |     1   (0)| 00:00:01 |
|*341 |               INDEX RANGE SCAN                               | V_DOMAINE_TYPE_CODE_IDX |    45 |       |       |     1   (0)| 00:00:01 |
|*342 |             FILTER                                           |                         |       |       |       |            |          |
| 343 |              TABLE ACCESS BY INDEX ROWID BATCHED             | V_DOMAINE               |    45 |   990 |       |     1   (0)| 00:00:01 |
|*344 |               INDEX RANGE SCAN                               | V_DOMAINE_TYPE_CODE_IDX |    45 |       |       |     1   (0)| 00:00:01 |
|*345 |             FILTER                                           |                         |       |       |       |            |          |
| 346 |              TABLE ACCESS BY INDEX ROWID BATCHED             | V_DOMAINE               |    45 |   990 |       |     1   (0)| 00:00:01 |
|*347 |               INDEX RANGE SCAN                               | V_DOMAINE_TYPE_CODE_IDX |    45 |       |       |     1   (0)| 00:00:01 |
|*348 |             FILTER                                           |                         |       |       |       |            |          |
| 349 |              TABLE ACCESS BY INDEX ROWID BATCHED             | V_DOMAINE               |    45 |   990 |       |     1   (0)| 00:00:01 |
|*350 |               INDEX RANGE SCAN                               | V_DOMAINE_TYPE_CODE_IDX |    45 |       |       |     1   (0)| 00:00:01 |
|*351 |             FILTER                                           |                         |       |       |       |            |          |
| 352 |              TABLE ACCESS BY INDEX ROWID BATCHED             | V_DOMAINE               |    45 |  1215 |       |     1   (0)| 00:00:01 |
|*353 |               INDEX RANGE SCAN                               | V_DOMAINE_TYPE_CODE_IDX |    45 |       |       |     1   (0)| 00:00:01 |
|*354 |             FILTER                                           |                         |       |       |       |            |          |
| 355 |              TABLE ACCESS BY INDEX ROWID BATCHED             | V_DOMAINE               |    45 |   990 |       |     1   (0)| 00:00:01 |
|*356 |               INDEX RANGE SCAN                               | V_DOMAINE_TYPE_CODE_IDX |    45 |       |       |     1   (0)| 00:00:01 |
|*357 |             FILTER                                           |                         |       |       |       |            |          |
| 358 |              TABLE ACCESS BY INDEX ROWID BATCHED             | V_DOMAINE               |    45 | 14220 |       |     1   (0)| 00:00:01 |
|*359 |               INDEX RANGE SCAN                               | V_DOMAINE_TYPE_CODE_IDX |    45 |       |       |     1   (0)| 00:00:01 |
| 360 |         NESTED LOOPS OUTER                                   |                         |   202 |   764K|       |  3066K  (1)| 00:02:00 |
| 361 |          NESTED LOOPS OUTER                                  |                         |   202 |   755K|       |  3066K  (1)| 00:02:00 |
|*362 |           HASH JOIN                                          |                         |   202 |   675K|    17M|  3066K  (1)| 00:02:00 |
|*363 |            INDEX RANGE SCAN                                  | AGGREG_T_ECRDOS_NMP$BAL |   511K|    11M|       |    43   (0)| 00:00:01 |
| 364 |            NESTED LOOPS                                      |                         |  2270 |  4553K|       |  3065K  (1)| 00:02:00 |
| 365 |             NESTED LOOPS                                     |                         |  2271 |  4553K|       |  3065K  (1)| 00:02:00 |
| 366 |              NESTED LOOPS OUTER                              |                         |  2271 |  4488K|       |  3065K  (1)| 00:02:00 |
| 367 |               NESTED LOOPS OUTER                             |                         |  2271 |  3592K|       |  2981K  (1)| 00:01:57 |
| 368 |                NESTED LOOPS                                  |                         |  2435K|  3660M|       |  2955K  (1)| 00:01:56 |
|*369 |                 HASH JOIN RIGHT OUTER                        |                         |  2436K|  3573M|       |  2906K  (1)| 00:01:54 |
| 370 |                  VIEW                                        |                         |    45 | 18855 |       |    38   (3)| 00:00:01 |
| 371 |                   HASH GROUP BY                              |                         |    45 | 18855 |       |    38   (3)| 00:00:01 |
| 372 |                    VIEW                                      | V_TDOMAINE              |  1665 |   681K|       |    37   (0)| 00:00:01 |
| 373 |                     UNION-ALL                                |                         |       |       |       |            |          |
|*374 |                      FILTER                                  |                         |       |       |       |            |          |
| 375 |                       TABLE ACCESS BY INDEX ROWID BATCHED    | V_DOMAINE               |    45 |  1935 |       |     1   (0)| 00:00:01 |
|*376 |                        INDEX RANGE SCAN                      | V_DOMAINE_TYPE_CODE_IDX |    45 |       |       |     1   (0)| 00:00:01 |
|*377 |                      FILTER                                  |                         |       |       |       |            |          |
| 378 |                       TABLE ACCESS BY INDEX ROWID BATCHED    | V_DOMAINE               |    45 |  2070 |       |     1   (0)| 00:00:01 |
|*379 |                        INDEX RANGE SCAN                      | V_DOMAINE_TYPE_CODE_IDX |    45 |       |       |     1   (0)| 00:00:01 |
|*380 |                      FILTER                                  |                         |       |       |       |            |          |
| 381 |                       TABLE ACCESS BY INDEX ROWID BATCHED    | V_DOMAINE               |    45 |  1485 |       |     1   (0)| 00:00:01 |
|*382 |                        INDEX RANGE SCAN                      | V_DOMAINE_TYPE_CODE_IDX |    45 |       |       |     1   (0)| 00:00:01 |
|*383 |                      FILTER                                  |                         |       |       |       |            |          |
| 384 |                       TABLE ACCESS BY INDEX ROWID BATCHED    | V_DOMAINE               |    45 |  1485 |       |     1   (0)| 00:00:01 |
|*385 |                        INDEX RANGE SCAN                      | V_DOMAINE_TYPE_CODE_IDX |    45 |       |       |     1   (0)| 00:00:01 |
|*386 |                      FILTER                                  |                         |       |       |       |            |          |
| 387 |                       TABLE ACCESS BY INDEX ROWID BATCHED    | V_DOMAINE               |    45 | 14220 |       |     1   (0)| 00:00:01 |
|*388 |                        INDEX RANGE SCAN                      | V_DOMAINE_TYPE_CODE_IDX |    45 |       |       |     1   (0)| 00:00:01 |
|*389 |                      FILTER                                  |                         |       |       |       |            |          |
| 390 |                       TABLE ACCESS BY INDEX ROWID BATCHED    | V_DOMAINE               |    45 |  1485 |       |     1   (0)| 00:00:01 |
|*391 |                        INDEX RANGE SCAN                      | V_DOMAINE_TYPE_CODE_IDX |    45 |       |       |     1   (0)| 00:00:01 |
|*392 |                      FILTER                                  |                         |       |       |       |            |          |
| 393 |                       TABLE ACCESS BY INDEX ROWID BATCHED    | V_DOMAINE               |    45 |  1485 |       |     1   (0)| 00:00:01 |
|*394 |                        INDEX RANGE SCAN                      | V_DOMAINE_TYPE_CODE_IDX |    45 |       |       |     1   (0)| 00:00:01 |
|*395 |                      FILTER                                  |                         |       |       |       |            |          |
| 396 |                       TABLE ACCESS BY INDEX ROWID BATCHED    | V_DOMAINE               |    45 |  1485 |       |     1   (0)| 00:00:01 |
|*397 |                        INDEX RANGE SCAN                      | V_DOMAINE_TYPE_CODE_IDX |    45 |       |       |     1   (0)| 00:00:01 |
|*398 |                      FILTER                                  |                         |       |       |       |            |          |
| 399 |                       TABLE ACCESS BY INDEX ROWID BATCHED    | V_DOMAINE               |    45 |  1485 |       |     1   (0)| 00:00:01 |
|*400 |                        INDEX RANGE SCAN                      | V_DOMAINE_TYPE_CODE_IDX |    45 |       |       |     1   (0)| 00:00:01 |
|*401 |                      FILTER                                  |                         |       |       |       |            |          |
| 402 |                       TABLE ACCESS BY INDEX ROWID BATCHED    | V_DOMAINE               |    45 | 14220 |       |     1   (0)| 00:00:01 |
|*403 |                        INDEX RANGE SCAN                      | V_DOMAINE_TYPE_CODE_IDX |    45 |       |       |     1   (0)| 00:00:01 |
|*404 |                      FILTER                                  |                         |       |       |       |            |          |
| 405 |                       TABLE ACCESS BY INDEX ROWID BATCHED    | V_DOMAINE               |    45 |  1755 |       |     1   (0)| 00:00:01 |
|*406 |                        INDEX RANGE SCAN                      | V_DOMAINE_TYPE_CODE_IDX |    45 |       |       |     1   (0)| 00:00:01 |
|*407 |                      FILTER                                  |                         |       |       |       |            |          |
| 408 |                       TABLE ACCESS BY INDEX ROWID BATCHED    | V_DOMAINE               |    45 |  1485 |       |     1   (0)| 00:00:01 |
|*409 |                        INDEX RANGE SCAN                      | V_DOMAINE_TYPE_CODE_IDX |    45 |       |       |     1   (0)| 00:00:01 |
|*410 |                      FILTER                                  |                         |       |       |       |            |          |
| 411 |                       TABLE ACCESS BY INDEX ROWID BATCHED    | V_DOMAINE               |    45 | 14220 |       |     1   (0)| 00:00:01 |
|*412 |                        INDEX RANGE SCAN                      | V_DOMAINE_TYPE_CODE_IDX |    45 |       |       |     1   (0)| 00:00:01 |
|*413 |                      FILTER                                  |                         |       |       |       |            |          |
| 414 |                       TABLE ACCESS BY INDEX ROWID BATCHED    | V_DOMAINE               |    45 |  1485 |       |     1   (0)| 00:00:01 |
|*415 |                        INDEX RANGE SCAN                      | V_DOMAINE_TYPE_CODE_IDX |    45 |       |       |     1   (0)| 00:00:01 |
|*416 |                      FILTER                                  |                         |       |       |       |            |          |
| 417 |                       TABLE ACCESS BY INDEX ROWID BATCHED    | V_DOMAINE               |    45 |  2070 |       |     1   (0)| 00:00:01 |
|*418 |                        INDEX RANGE SCAN                      | V_DOMAINE_TYPE_CODE_IDX |    45 |       |       |     1   (0)| 00:00:01 |
|*419 |                      FILTER                                  |                         |       |       |       |            |          |
| 420 |                       TABLE ACCESS BY INDEX ROWID BATCHED    | V_DOMAINE               |    45 |  1485 |       |     1   (0)| 00:00:01 |
|*421 |                        INDEX RANGE SCAN                      | V_DOMAINE_TYPE_CODE_IDX |    45 |       |       |     1   (0)| 00:00:01 |
|*422 |                      FILTER                                  |                         |       |       |       |            |          |
| 423 |                       TABLE ACCESS BY INDEX ROWID BATCHED    | V_DOMAINE               |    45 |  1485 |       |     1   (0)| 00:00:01 |
|*424 |                        INDEX RANGE SCAN                      | V_DOMAINE_TYPE_CODE_IDX |    45 |       |       |     1   (0)| 00:00:01 |
|*425 |                      FILTER                                  |                         |       |       |       |            |          |
| 426 |                       TABLE ACCESS BY INDEX ROWID BATCHED    | V_DOMAINE               |    45 |  1485 |       |     1   (0)| 00:00:01 |
|*427 |                        INDEX RANGE SCAN                      | V_DOMAINE_TYPE_CODE_IDX |    45 |       |       |     1   (0)| 00:00:01 |
|*428 |                      FILTER                                  |                         |       |       |       |            |          |
| 429 |                       TABLE ACCESS BY INDEX ROWID BATCHED    | V_DOMAINE               |    45 |  1485 |       |     1   (0)| 00:00:01 |
|*430 |                        INDEX RANGE SCAN                      | V_DOMAINE_TYPE_CODE_IDX |    45 |       |       |     1   (0)| 00:00:01 |
|*431 |                      FILTER                                  |                         |       |       |       |            |          |
| 432 |                       TABLE ACCESS BY INDEX ROWID BATCHED    | V_DOMAINE               |    45 |  1485 |       |     1   (0)| 00:00:01 |
|*433 |                        INDEX RANGE SCAN                      | V_DOMAINE_TYPE_CODE_IDX |    45 |       |       |     1   (0)| 00:00:01 |
|*434 |                      FILTER                                  |                         |       |       |       |            |          |
| 435 |                       TABLE ACCESS BY INDEX ROWID BATCHED    | V_DOMAINE               |    45 |  1485 |       |     1   (0)| 00:00:01 |
|*436 |                        INDEX RANGE SCAN                      | V_DOMAINE_TYPE_CODE_IDX |    45 |       |       |     1   (0)| 00:00:01 |
|*437 |                      FILTER                                  |                         |       |       |       |            |          |
| 438 |                       TABLE ACCESS BY INDEX ROWID BATCHED    | V_DOMAINE               |    45 |  1485 |       |     1   (0)| 00:00:01 |
|*439 |                        INDEX RANGE SCAN                      | V_DOMAINE_TYPE_CODE_IDX |    45 |       |       |     1   (0)| 00:00:01 |
|*440 |                      FILTER                                  |                         |       |       |       |            |          |
| 441 |                       TABLE ACCESS BY INDEX ROWID BATCHED    | V_DOMAINE               |    45 |  1755 |       |     1   (0)| 00:00:01 |
|*442 |                        INDEX RANGE SCAN                      | V_DOMAINE_TYPE_CODE_IDX |    45 |       |       |     1   (0)| 00:00:01 |
|*443 |                      FILTER                                  |                         |       |       |       |            |          |
| 444 |                       TABLE ACCESS BY INDEX ROWID BATCHED    | V_DOMAINE               |    45 | 14220 |       |     1   (0)| 00:00:01 |
|*445 |                        INDEX RANGE SCAN                      | V_DOMAINE_TYPE_CODE_IDX |    45 |       |       |     1   (0)| 00:00:01 |
|*446 |                      FILTER                                  |                         |       |       |       |            |          |
| 447 |                       TABLE ACCESS BY INDEX ROWID BATCHED    | V_DOMAINE               |    45 | 14220 |       |     1   (0)| 00:00:01 |
|*448 |                        INDEX RANGE SCAN                      | V_DOMAINE_TYPE_CODE_IDX |    45 |       |       |     1   (0)| 00:00:01 |
|*449 |                      FILTER                                  |                         |       |       |       |            |          |
| 450 |                       TABLE ACCESS BY INDEX ROWID BATCHED    | V_DOMAINE               |    45 |  1485 |       |     1   (0)| 00:00:01 |
|*451 |                        INDEX RANGE SCAN                      | V_DOMAINE_TYPE_CODE_IDX |    45 |       |       |     1   (0)| 00:00:01 |
|*452 |                      FILTER                                  |                         |       |       |       |            |          |
| 453 |                       TABLE ACCESS BY INDEX ROWID BATCHED    | V_DOMAINE               |    45 |  1485 |       |     1   (0)| 00:00:01 |
|*454 |                        INDEX RANGE SCAN                      | V_DOMAINE_TYPE_CODE_IDX |    45 |       |       |     1   (0)| 00:00:01 |
|*455 |                      FILTER                                  |                         |       |       |       |            |          |
| 456 |                       TABLE ACCESS BY INDEX ROWID BATCHED    | V_DOMAINE               |    45 |  1485 |       |     1   (0)| 00:00:01 |
|*457 |                        INDEX RANGE SCAN                      | V_DOMAINE_TYPE_CODE_IDX |    45 |       |       |     1   (0)| 00:00:01 |
|*458 |                      FILTER                                  |                         |       |       |       |            |          |
| 459 |                       TABLE ACCESS BY INDEX ROWID BATCHED    | V_DOMAINE               |    45 |  1485 |       |     1   (0)| 00:00:01 |
|*460 |                        INDEX RANGE SCAN                      | V_DOMAINE_TYPE_CODE_IDX |    45 |       |       |     1   (0)| 00:00:01 |
|*461 |                      FILTER                                  |                         |       |       |       |            |          |
| 462 |                       TABLE ACCESS BY INDEX ROWID BATCHED    | V_DOMAINE               |    45 |  1485 |       |     1   (0)| 00:00:01 |
|*463 |                        INDEX RANGE SCAN                      | V_DOMAINE_TYPE_CODE_IDX |    45 |       |       |     1   (0)| 00:00:01 |
|*464 |                      FILTER                                  |                         |       |       |       |            |          |
| 465 |                       TABLE ACCESS BY INDEX ROWID BATCHED    | V_DOMAINE               |    45 |  1485 |       |     1   (0)| 00:00:01 |
|*466 |                        INDEX RANGE SCAN                      | V_DOMAINE_TYPE_CODE_IDX |    45 |       |       |     1   (0)| 00:00:01 |
|*467 |                      FILTER                                  |                         |       |       |       |            |          |
| 468 |                       TABLE ACCESS BY INDEX ROWID BATCHED    | V_DOMAINE               |    45 |  1485 |       |     1   (0)| 00:00:01 |
|*469 |                        INDEX RANGE SCAN                      | V_DOMAINE_TYPE_CODE_IDX |    45 |       |       |     1   (0)| 00:00:01 |
|*470 |                      FILTER                                  |                         |       |       |       |            |          |
| 471 |                       TABLE ACCESS BY INDEX ROWID BATCHED    | V_DOMAINE               |    45 |  1485 |       |     1   (0)| 00:00:01 |
|*472 |                        INDEX RANGE SCAN                      | V_DOMAINE_TYPE_CODE_IDX |    45 |       |       |     1   (0)| 00:00:01 |
|*473 |                      FILTER                                  |                         |       |       |       |            |          |
| 474 |                       TABLE ACCESS BY INDEX ROWID BATCHED    | V_DOMAINE               |    45 |  1485 |       |     1   (0)| 00:00:01 |
|*475 |                        INDEX RANGE SCAN                      | V_DOMAINE_TYPE_CODE_IDX |    45 |       |       |     1   (0)| 00:00:01 |
|*476 |                      FILTER                                  |                         |       |       |       |            |          |
| 477 |                       TABLE ACCESS BY INDEX ROWID BATCHED    | V_DOMAINE               |    45 |  1710 |       |     1   (0)| 00:00:01 |
|*478 |                        INDEX RANGE SCAN                      | V_DOMAINE_TYPE_CODE_IDX |    45 |       |       |     1   (0)| 00:00:01 |
|*479 |                      FILTER                                  |                         |       |       |       |            |          |
| 480 |                       TABLE ACCESS BY INDEX ROWID BATCHED    | V_DOMAINE               |    45 |  1485 |       |     1   (0)| 00:00:01 |
|*481 |                        INDEX RANGE SCAN                      | V_DOMAINE_TYPE_CODE_IDX |    45 |       |       |     1   (0)| 00:00:01 |
|*482 |                      FILTER                                  |                         |       |       |       |            |          |
| 483 |                       TABLE ACCESS BY INDEX ROWID BATCHED    | V_DOMAINE               |    45 | 14220 |       |     1   (0)| 00:00:01 |
|*484 |                        INDEX RANGE SCAN                      | V_DOMAINE_TYPE_CODE_IDX |    45 |       |       |     1   (0)| 00:00:01 |
| 485 |                  NESTED LOOPS                                |                         |  2436K|  1644M|       |  2906K  (1)| 00:01:54 |
| 486 |                   NESTED LOOPS                               |                         |  2547K|  1644M|       |  2906K  (1)| 00:01:54 |
| 487 |                    NESTED LOOPS                              |                         |  2547K|  1166M|       |  2638K  (1)| 00:01:44 |
|*488 |                     HASH JOIN RIGHT OUTER                    |                         |   252K|   105M|       |  2413K  (1)| 00:01:35 |
| 489 |                      TABLE ACCESS STORAGE FULL FIRST ROWS    | G_ACCORDS               |    44 |   484 |       |     4   (0)| 00:00:01 |
|*490 |                      HASH JOIN                               |                         |   252K|    71M|  7304K|  2413K  (1)| 00:01:35 |
| 491 |                       TABLE ACCESS STORAGE FULL FIRST ROWS   | G_INDIVIDU              |   155K|  5472K|       |  7303   (1)| 00:00:01 |
|*492 |                       HASH JOIN                              |                         |   252K|    39M|       |  2395K  (1)| 00:01:34 |
|*493 |                        INDEX SKIP SCAN                       | INT_INDIV               | 48259 |  1131K|       |    36   (0)| 00:00:01 |
| 494 |                        NESTED LOOPS                          |                         |  1260K|    85M|       |  2395K  (1)| 00:01:34 |
| 495 |                         NESTED LOOPS OUTER                   |                         | 23491 |  1009K|       |  1413   (1)| 00:00:01 |
| 496 |                          TABLE ACCESS STORAGE FULL FIRST ROWS| G_DOSSIER               | 23495 |   390K|       |   943   (1)| 00:00:01 |
| 497 |                          TABLE ACCESS BY INDEX ROWID BATCHED | G_PERSONNEL             |     1 |    27 |       |     1   (0)| 00:00:01 |
|*498 |                           INDEX RANGE SCAN                   | GPERSREFP               |     1 |       |       |     1   (0)| 00:00:01 |
|*499 |                         TABLE ACCESS STORAGE FULL FIRST ROWS | G_PERSONNEL             |    54 |  1458 |       |   102   (0)| 00:00:01 |
| 500 |                     TABLE ACCESS BY INDEX ROWID BATCHED      | T_ELEMENTS              |    10 |   410 |       |     1   (0)| 00:00:01 |
|*501 |                      INDEX RANGE SCAN                        | ELE_ELEMDOSS            |    30 |       |       |     1   (0)| 00:00:01 |
|*502 |                    INDEX UNIQUE SCAN                         | REFENCAISS              |     1 |       |       |     1   (0)| 00:00:01 |
|*503 |                   TABLE ACCESS BY INDEX ROWID                | G_ENCAISSEMENT          |     1 |   228 |       |     1   (0)| 00:00:01 |
| 504 |                 TABLE ACCESS BY INDEX ROWID                  | G_INDIVIDU              |     1 |    38 |       |     1   (0)| 00:00:01 |
|*505 |                  INDEX UNIQUE SCAN                           | IND_REFINDIV            |     1 |       |       |     1   (0)| 00:00:01 |
|*506 |                TABLE ACCESS BY INDEX ROWID                   | NAM_COLLECTE            |     1 |    44 |       |     1   (0)| 00:00:01 |
|*507 |                 INDEX UNIQUE SCAN                            | COLCOMPOSTAGE           |     1 |       |       |     1   (0)| 00:00:01 |
| 508 |               VIEW PUSHED PREDICATE                          |                         |     1 |   404 |       |    37   (0)| 00:00:01 |
| 509 |                SORT GROUP BY                                 |                         |    37 | 15503 |       |    37   (0)| 00:00:01 |
| 510 |                 VIEW                                         | V_TDOMAINE              |    37 | 15503 |       |    37   (0)| 00:00:01 |
| 511 |                  UNION-ALL                                   |                         |       |       |       |            |          |
|*512 |                   FILTER                                     |                         |       |       |       |            |          |
| 513 |                    TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE               |     1 |    43 |       |     1   (0)| 00:00:01 |
|*514 |                     INDEX RANGE SCAN                         | DOM_TYPVAL              |     2 |       |       |     1   (0)| 00:00:01 |
|*515 |                   FILTER                                     |                         |       |       |       |            |          |
| 516 |                    TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE               |     1 |    46 |       |     1   (0)| 00:00:01 |
|*517 |                     INDEX RANGE SCAN                         | DOM_TYPVAL              |     2 |       |       |     1   (0)| 00:00:01 |
|*518 |                   FILTER                                     |                         |       |       |       |            |          |
| 519 |                    TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE               |     1 |    33 |       |     1   (0)| 00:00:01 |
|*520 |                     INDEX RANGE SCAN                         | DOM_TYPVAL              |     2 |       |       |     1   (0)| 00:00:01 |
|*521 |                   FILTER                                     |                         |       |       |       |            |          |
| 522 |                    TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE               |     1 |    33 |       |     1   (0)| 00:00:01 |
|*523 |                     INDEX RANGE SCAN                         | DOM_TYPVAL              |     2 |       |       |     1   (0)| 00:00:01 |
|*524 |                   FILTER                                     |                         |       |       |       |            |          |
| 525 |                    TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE               |     1 |   316 |       |     1   (0)| 00:00:01 |
|*526 |                     INDEX RANGE SCAN                         | DOM_TYPVAL              |     2 |       |       |     1   (0)| 00:00:01 |
|*527 |                   FILTER                                     |                         |       |       |       |            |          |
| 528 |                    TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE               |     1 |    33 |       |     1   (0)| 00:00:01 |
|*529 |                     INDEX RANGE SCAN                         | DOM_TYPVAL              |     2 |       |       |     1   (0)| 00:00:01 |
|*530 |                   FILTER                                     |                         |       |       |       |            |          |
| 531 |                    TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE               |     1 |    33 |       |     1   (0)| 00:00:01 |
|*532 |                     INDEX RANGE SCAN                         | DOM_TYPVAL              |     2 |       |       |     1   (0)| 00:00:01 |
|*533 |                   FILTER                                     |                         |       |       |       |            |          |
| 534 |                    TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE               |     1 |    33 |       |     1   (0)| 00:00:01 |
|*535 |                     INDEX RANGE SCAN                         | DOM_TYPVAL              |     2 |       |       |     1   (0)| 00:00:01 |
|*536 |                   FILTER                                     |                         |       |       |       |            |          |
| 537 |                    TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE               |     1 |    33 |       |     1   (0)| 00:00:01 |
|*538 |                     INDEX RANGE SCAN                         | DOM_TYPVAL              |     2 |       |       |     1   (0)| 00:00:01 |
|*539 |                   FILTER                                     |                         |       |       |       |            |          |
| 540 |                    TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE               |     1 |   316 |       |     1   (0)| 00:00:01 |
|*541 |                     INDEX RANGE SCAN                         | DOM_TYPVAL              |     2 |       |       |     1   (0)| 00:00:01 |
|*542 |                   FILTER                                     |                         |       |       |       |            |          |
| 543 |                    TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE               |     1 |    39 |       |     1   (0)| 00:00:01 |
|*544 |                     INDEX RANGE SCAN                         | DOM_TYPVAL              |     2 |       |       |     1   (0)| 00:00:01 |
|*545 |                   FILTER                                     |                         |       |       |       |            |          |
| 546 |                    TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE               |     1 |    33 |       |     1   (0)| 00:00:01 |
|*547 |                     INDEX RANGE SCAN                         | DOM_TYPVAL              |     2 |       |       |     1   (0)| 00:00:01 |
|*548 |                   FILTER                                     |                         |       |       |       |            |          |
| 549 |                    TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE               |     1 |   316 |       |     1   (0)| 00:00:01 |
|*550 |                     INDEX RANGE SCAN                         | DOM_TYPVAL              |     2 |       |       |     1   (0)| 00:00:01 |
|*551 |                   FILTER                                     |                         |       |       |       |            |          |
| 552 |                    TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE               |     1 |    33 |       |     1   (0)| 00:00:01 |
|*553 |                     INDEX RANGE SCAN                         | DOM_TYPVAL              |     2 |       |       |     1   (0)| 00:00:01 |
|*554 |                   FILTER                                     |                         |       |       |       |            |          |
| 555 |                    TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE               |     1 |    46 |       |     1   (0)| 00:00:01 |
|*556 |                     INDEX RANGE SCAN                         | DOM_TYPVAL              |     2 |       |       |     1   (0)| 00:00:01 |
|*557 |                   FILTER                                     |                         |       |       |       |            |          |
| 558 |                    TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE               |     1 |    33 |       |     1   (0)| 00:00:01 |
|*559 |                     INDEX RANGE SCAN                         | DOM_TYPVAL              |     2 |       |       |     1   (0)| 00:00:01 |
|*560 |                   FILTER                                     |                         |       |       |       |            |          |
| 561 |                    TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE               |     1 |    33 |       |     1   (0)| 00:00:01 |
|*562 |                     INDEX RANGE SCAN                         | DOM_TYPVAL              |     2 |       |       |     1   (0)| 00:00:01 |
|*563 |                   FILTER                                     |                         |       |       |       |            |          |
| 564 |                    TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE               |     1 |    33 |       |     1   (0)| 00:00:01 |
|*565 |                     INDEX RANGE SCAN                         | DOM_TYPVAL              |     2 |       |       |     1   (0)| 00:00:01 |
|*566 |                   FILTER                                     |                         |       |       |       |            |          |
| 567 |                    TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE               |     1 |    33 |       |     1   (0)| 00:00:01 |
|*568 |                     INDEX RANGE SCAN                         | DOM_TYPVAL              |     2 |       |       |     1   (0)| 00:00:01 |
|*569 |                   FILTER                                     |                         |       |       |       |            |          |
| 570 |                    TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE               |     1 |    33 |       |     1   (0)| 00:00:01 |
|*571 |                     INDEX RANGE SCAN                         | DOM_TYPVAL              |     2 |       |       |     1   (0)| 00:00:01 |
|*572 |                   FILTER                                     |                         |       |       |       |            |          |
| 573 |                    TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE               |     1 |    33 |       |     1   (0)| 00:00:01 |
|*574 |                     INDEX RANGE SCAN                         | DOM_TYPVAL              |     2 |       |       |     1   (0)| 00:00:01 |
|*575 |                   FILTER                                     |                         |       |       |       |            |          |
| 576 |                    TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE               |     1 |    33 |       |     1   (0)| 00:00:01 |
|*577 |                     INDEX RANGE SCAN                         | DOM_TYPVAL              |     2 |       |       |     1   (0)| 00:00:01 |
|*578 |                   FILTER                                     |                         |       |       |       |            |          |
| 579 |                    TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE               |     1 |    39 |       |     1   (0)| 00:00:01 |
|*580 |                     INDEX RANGE SCAN                         | DOM_TYPVAL              |     2 |       |       |     1   (0)| 00:00:01 |
|*581 |                   FILTER                                     |                         |       |       |       |            |          |
| 582 |                    TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE               |     1 |   316 |       |     1   (0)| 00:00:01 |
|*583 |                     INDEX RANGE SCAN                         | DOM_TYPVAL              |     2 |       |       |     1   (0)| 00:00:01 |
|*584 |                   FILTER                                     |                         |       |       |       |            |          |
| 585 |                    TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE               |     1 |   316 |       |     1   (0)| 00:00:01 |
|*586 |                     INDEX RANGE SCAN                         | DOM_TYPVAL              |     2 |       |       |     1   (0)| 00:00:01 |
|*587 |                   FILTER                                     |                         |       |       |       |            |          |
| 588 |                    TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE               |     1 |    33 |       |     1   (0)| 00:00:01 |
|*589 |                     INDEX RANGE SCAN                         | DOM_TYPVAL              |     2 |       |       |     1   (0)| 00:00:01 |
|*590 |                   FILTER                                     |                         |       |       |       |            |          |
| 591 |                    TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE               |     1 |    33 |       |     1   (0)| 00:00:01 |
|*592 |                     INDEX RANGE SCAN                         | DOM_TYPVAL              |     2 |       |       |     1   (0)| 00:00:01 |
|*593 |                   FILTER                                     |                         |       |       |       |            |          |
| 594 |                    TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE               |     1 |    33 |       |     1   (0)| 00:00:01 |
|*595 |                     INDEX RANGE SCAN                         | DOM_TYPVAL              |     2 |       |       |     1   (0)| 00:00:01 |
|*596 |                   FILTER                                     |                         |       |       |       |            |          |
| 597 |                    TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE               |     1 |    33 |       |     1   (0)| 00:00:01 |
|*598 |                     INDEX RANGE SCAN                         | DOM_TYPVAL              |     2 |       |       |     1   (0)| 00:00:01 |
|*599 |                   FILTER                                     |                         |       |       |       |            |          |
| 600 |                    TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE               |     1 |    33 |       |     1   (0)| 00:00:01 |
|*601 |                     INDEX RANGE SCAN                         | DOM_TYPVAL              |     2 |       |       |     1   (0)| 00:00:01 |
|*602 |                   FILTER                                     |                         |       |       |       |            |          |
| 603 |                    TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE               |     1 |    33 |       |     1   (0)| 00:00:01 |
|*604 |                     INDEX RANGE SCAN                         | DOM_TYPVAL              |     2 |       |       |     1   (0)| 00:00:01 |
|*605 |                   FILTER                                     |                         |       |       |       |            |          |
| 606 |                    TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE               |     1 |    33 |       |     1   (0)| 00:00:01 |
|*607 |                     INDEX RANGE SCAN                         | DOM_TYPVAL              |     2 |       |       |     1   (0)| 00:00:01 |
|*608 |                   FILTER                                     |                         |       |       |       |            |          |
| 609 |                    TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE               |     1 |    33 |       |     1   (0)| 00:00:01 |
|*610 |                     INDEX RANGE SCAN                         | DOM_TYPVAL              |     2 |       |       |     1   (0)| 00:00:01 |
|*611 |                   FILTER                                     |                         |       |       |       |            |          |
| 612 |                    TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE               |     1 |    33 |       |     1   (0)| 00:00:01 |
|*613 |                     INDEX RANGE SCAN                         | DOM_TYPVAL              |     2 |       |       |     1   (0)| 00:00:01 |
|*614 |                   FILTER                                     |                         |       |       |       |            |          |
| 615 |                    TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE               |     1 |    38 |       |     1   (0)| 00:00:01 |
|*616 |                     INDEX RANGE SCAN                         | DOM_TYPVAL              |     2 |       |       |     1   (0)| 00:00:01 |
|*617 |                   FILTER                                     |                         |       |       |       |            |          |
| 618 |                    TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE               |     1 |    33 |       |     1   (0)| 00:00:01 |
|*619 |                     INDEX RANGE SCAN                         | DOM_TYPVAL              |     2 |       |       |     1   (0)| 00:00:01 |
|*620 |                   FILTER                                     |                         |       |       |       |            |          |
| 621 |                    TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE               |     1 |   316 |       |     1   (0)| 00:00:01 |
|*622 |                     INDEX RANGE SCAN                         | DOM_TYPVAL              |     2 |       |       |     1   (0)| 00:00:01 |
|*623 |              INDEX UNIQUE SCAN                               | VENT_REFDOSS            |     1 |       |       |     1   (0)| 00:00:01 |
| 624 |             TABLE ACCESS BY INDEX ROWID                      | G_VENTILENC             |     1 |    30 |       |     1   (0)| 00:00:01 |
| 625 |           TABLE ACCESS BY INDEX ROWID                        | NAM_COLLECTE            |     1 |   409 |       |     1   (0)| 00:00:01 |
|*626 |            INDEX UNIQUE SCAN                                 | COLCOMPOSTAGE           |     1 |       |       |     1   (0)| 00:00:01 |
|*627 |          TABLE ACCESS BY INDEX ROWID BATCHED                 | T_ELEMENTS              |     1 |    45 |       |     1   (0)| 00:00:01 |
|*628 |           INDEX RANGE SCAN                                   | ELE_ELEMTYPE            |     1 |       |       |     1   (0)| 00:00:01 |
| 629 |       SORT UNIQUE                                            |                         |     3 |   254 |       |     6   (0)| 00:00:01 |
| 630 |        UNION-ALL                                             |                         |       |       |       |            |          |
|*631 |         FILTER                                               |                         |       |       |       |            |          |
| 632 |          NESTED LOOPS                                        |                         |     1 |    59 |       |     3   (0)| 00:00:01 |
| 633 |           NESTED LOOPS                                       |                         |     1 |    59 |       |     3   (0)| 00:00:01 |
| 634 |            NESTED LOOPS                                      |                         |     1 |    44 |       |     2   (0)| 00:00:01 |
|*635 |             INDEX RANGE SCAN                                 | DOS_REFDOSS_REFLOT_IDX  |     1 |    22 |       |     1   (0)| 00:00:01 |
|*636 |             INDEX RANGE SCAN                                 | DOS_REFDOSS_REFLOT_IDX  |     1 |    22 |       |     1   (0)| 00:00:01 |
|*637 |            INDEX UNIQUE SCAN                                 | DOS_REFDOSS             |     1 |       |       |     1   (0)| 00:00:01 |
| 638 |           TABLE ACCESS BY INDEX ROWID                        | G_DOSSIER               |     1 |    15 |       |     1   (0)| 00:00:01 |
| 639 |         NESTED LOOPS                                         |                         |     1 |    45 |       |     2   (0)| 00:00:01 |
|*640 |          TABLE ACCESS BY INDEX ROWID                         | G_DOSSIER               |     1 |    30 |       |     1   (0)| 00:00:01 |
|*641 |           INDEX UNIQUE SCAN                                  | DOS_REFDOSS             |     1 |       |       |     1   (0)| 00:00:01 |
| 642 |          TABLE ACCESS BY INDEX ROWID                         | G_DOSSIER               |     1 |    15 |       |     1   (0)| 00:00:01 |
|*643 |           INDEX UNIQUE SCAN                                  | DOS_REFDOSS             |     1 |       |       |     1   (0)| 00:00:01 |
|*644 |         TABLE ACCESS BY INDEX ROWID                          | G_DOSSIER               |     1 |    23 |       |     1   (0)| 00:00:01 |
|*645 |          INDEX UNIQUE SCAN                                   | DOS_REFDOSS             |     1 |       |       |     1   (0)| 00:00:01 |
------------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   1 - filter(ROWNUM=1)
   4 - filter('AL'=:1)
   6 - access("TYPE"='NAM_COLLECTE' AND "ABREV"=SUBSTR(:B1,1,3))
   7 - filter('AN'=:1)
   9 - access("TYPE"='NAM_COLLECTE' AND "ABREV"=SUBSTR(:B1,1,3))
  10 - filter('AR'=:1)
  12 - access("TYPE"='NAM_COLLECTE' AND "ABREV"=SUBSTR(:B1,1,3))
  13 - filter('BG'=:1)
  15 - access("TYPE"='NAM_COLLECTE' AND "ABREV"=SUBSTR(:B1,1,3))
  16 - filter('BR'=:1)
  18 - access("TYPE"='NAM_COLLECTE' AND "ABREV"=SUBSTR(:B1,1,3))
  19 - filter('CE'=:1)
  21 - access("TYPE"='NAM_COLLECTE' AND "ABREV"=SUBSTR(:B1,1,3))
  22 - filter('CH'=:1)
  24 - access("TYPE"='NAM_COLLECTE' AND "ABREV"=SUBSTR(:B1,1,3))
  25 - filter('CS'=:1)
  27 - access("TYPE"='NAM_COLLECTE' AND "ABREV"=SUBSTR(:B1,1,3))
  28 - filter('DA'=:1)
  30 - access("TYPE"='NAM_COLLECTE' AND "ABREV"=SUBSTR(:B1,1,3))
  31 - filter('EL'=:1)
  33 - access("TYPE"='NAM_COLLECTE' AND "ABREV"=SUBSTR(:B1,1,3))
  34 - filter('ES'=:1)
  36 - access("TYPE"='NAM_COLLECTE' AND "ABREV"=SUBSTR(:B1,1,3))
  37 - filter('ET'=:1)
  39 - access("TYPE"='NAM_COLLECTE' AND "ABREV"=SUBSTR(:B1,1,3))
  40 - filter('FI'=:1)
  42 - access("TYPE"='NAM_COLLECTE' AND "ABREV"=SUBSTR(:B1,1,3))
  43 - filter('FL'=:1)
  45 - access("TYPE"='NAM_COLLECTE' AND "ABREV"=SUBSTR(:B1,1,3))
  46 - filter('FR'=:1)
  48 - access("TYPE"='NAM_COLLECTE' AND "ABREV"=SUBSTR(:B1,1,3))
  49 - filter('HR'=:1)
  51 - access("TYPE"='NAM_COLLECTE' AND "ABREV"=SUBSTR(:B1,1,3))
  52 - filter('HU'=:1)
  54 - access("TYPE"='NAM_COLLECTE' AND "ABREV"=SUBSTR(:B1,1,3))
  55 - filter('IT'=:1)
  57 - access("TYPE"='NAM_COLLECTE' AND "ABREV"=SUBSTR(:B1,1,3))
  58 - filter('IW'=:1)
  60 - access("TYPE"='NAM_COLLECTE' AND "ABREV"=SUBSTR(:B1,1,3))
  61 - filter('JA'=:1)
  63 - access("TYPE"='NAM_COLLECTE' AND "ABREV"=SUBSTR(:B1,1,3))
  64 - filter('LV'=:1)
  66 - access("TYPE"='NAM_COLLECTE' AND "ABREV"=SUBSTR(:B1,1,3))
  67 - filter('MX'=:1)
  69 - access("TYPE"='NAM_COLLECTE' AND "ABREV"=SUBSTR(:B1,1,3))
  70 - filter('NL'=:1)
  72 - access("TYPE"='NAM_COLLECTE' AND "ABREV"=SUBSTR(:B1,1,3))
  73 - filter('NO'=:1)
  75 - access("TYPE"='NAM_COLLECTE' AND "ABREV"=SUBSTR(:B1,1,3))
  76 - filter('NO'=:1)
  78 - access("TYPE"='NAM_COLLECTE' AND "ABREV"=SUBSTR(:B1,1,3))
  79 - filter('PL'=:1)
  81 - access("TYPE"='NAM_COLLECTE' AND "ABREV"=SUBSTR(:B1,1,3))
  82 - filter('PT'=:1)
  84 - access("TYPE"='NAM_COLLECTE' AND "ABREV"=SUBSTR(:B1,1,3))
  85 - filter('RO'=:1)
  87 - access("TYPE"='NAM_COLLECTE' AND "ABREV"=SUBSTR(:B1,1,3))
  88 - filter('RU'=:1)
  90 - access("TYPE"='NAM_COLLECTE' AND "ABREV"=SUBSTR(:B1,1,3))
  91 - filter('SK'=:1)
  93 - access("TYPE"='NAM_COLLECTE' AND "ABREV"=SUBSTR(:B1,1,3))
  94 - filter('SL'=:1)
  96 - access("TYPE"='NAM_COLLECTE' AND "ABREV"=SUBSTR(:B1,1,3))
  97 - filter('SR'=:1)
  99 - access("TYPE"='NAM_COLLECTE' AND "ABREV"=SUBSTR(:B1,1,3))
100 - filter('SV'=:1)
102 - access("TYPE"='NAM_COLLECTE' AND "ABREV"=SUBSTR(:B1,1,3))
103 - filter('TR'=:1)
105 - access("TYPE"='NAM_COLLECTE' AND "ABREV"=SUBSTR(:B1,1,3))
106 - filter('US'=:1)
108 - access("TYPE"='NAM_COLLECTE' AND "ABREV"=SUBSTR(:B1,1,3))
109 - filter('VI'=:1)
111 - access("TYPE"='NAM_COLLECTE' AND "ABREV"=SUBSTR(:B1,1,3))
112 - filter('ZH'=:1)
114 - access("TYPE"='NAM_COLLECTE' AND "ABREV"=SUBSTR(:B1,1,3))
118 - filter(("REFDOSS"=:B1 AND "TYPENCAISS"=:B2))
119 - access("REFENCAISS"=:B1)
122 - access("REFDOSS"=:B1)
123 - filter("RNUM">=:8)
124 - filter(ROWNUM<=:7)
127 - filter("CRM"."REFPERSO"=)
128 - access("V3"."ABREV"=DECODE("EN"."REFREPRES",NULL,DECODE(INTERNAL_FUNCTION("EN"."DTIMPAYE_DT"),NULL,'ENCAISSE','IMPAYE'),'REPRESEN
              TE'))
133 - filter('AL'=:5)
135 - access("TYPE"='STATUT_PAIEMENT')
136 - filter('AN'=:5)
138 - access("TYPE"='STATUT_PAIEMENT')
139 - filter('AR'=:5)
141 - access("TYPE"='STATUT_PAIEMENT')
142 - filter('BG'=:5)
144 - access("TYPE"='STATUT_PAIEMENT')
145 - filter('BR'=:5)
147 - access("TYPE"='STATUT_PAIEMENT')
148 - filter('CE'=:5)
150 - access("TYPE"='STATUT_PAIEMENT')
151 - filter('CH'=:5)
153 - access("TYPE"='STATUT_PAIEMENT')
154 - filter('CS'=:5)
156 - access("TYPE"='STATUT_PAIEMENT')
157 - filter('DA'=:5)
159 - access("TYPE"='STATUT_PAIEMENT')
160 - filter('EL'=:5)
162 - access("TYPE"='STATUT_PAIEMENT')
163 - filter('ES'=:5)
165 - access("TYPE"='STATUT_PAIEMENT')
166 - filter('ET'=:5)
168 - access("TYPE"='STATUT_PAIEMENT')
169 - filter('FI'=:5)
171 - access("TYPE"='STATUT_PAIEMENT')
172 - filter('FL'=:5)
174 - access("TYPE"='STATUT_PAIEMENT')
175 - filter('FR'=:5)
177 - access("TYPE"='STATUT_PAIEMENT')
178 - filter('HR'=:5)
180 - access("TYPE"='STATUT_PAIEMENT')
181 - filter('HU'=:5)
183 - access("TYPE"='STATUT_PAIEMENT')
184 - filter('IT'=:5)
186 - access("TYPE"='STATUT_PAIEMENT')
187 - filter('IW'=:5)
189 - access("TYPE"='STATUT_PAIEMENT')
190 - filter('JA'=:5)
192 - access("TYPE"='STATUT_PAIEMENT')
193 - filter('LV'=:5)
195 - access("TYPE"='STATUT_PAIEMENT')
196 - filter('MX'=:5)
198 - access("TYPE"='STATUT_PAIEMENT')
199 - filter('NL'=:5)
201 - access("TYPE"='STATUT_PAIEMENT')
202 - filter('NO'=:5)
204 - access("TYPE"='STATUT_PAIEMENT')
205 - filter('NO'=:5)
207 - access("TYPE"='STATUT_PAIEMENT')
208 - filter('PL'=:5)
210 - access("TYPE"='STATUT_PAIEMENT')
211 - filter('PT'=:5)
213 - access("TYPE"='STATUT_PAIEMENT')
214 - filter('RO'=:5)
216 - access("TYPE"='STATUT_PAIEMENT')
217 - filter('RU'=:5)
219 - access("TYPE"='STATUT_PAIEMENT')
220 - filter('SK'=:5)
222 - access("TYPE"='STATUT_PAIEMENT')
223 - filter('SL'=:5)
225 - access("TYPE"='STATUT_PAIEMENT')
226 - filter('SR'=:5)
228 - access("TYPE"='STATUT_PAIEMENT')
229 - filter('SV'=:5)
231 - access("TYPE"='STATUT_PAIEMENT')
232 - filter('TR'=:5)
234 - access("TYPE"='STATUT_PAIEMENT')
235 - filter('US'=:5)
237 - access("TYPE"='STATUT_PAIEMENT')
238 - filter('VI'=:5)
240 - access("TYPE"='STATUT_PAIEMENT')
241 - filter('ZH'=:5)
243 - access("TYPE"='STATUT_PAIEMENT')
244 - access("NC"."TRAITE"=TO_NUMBER("V2"."ABREV"))
249 - filter('AL'=:4)
251 - access("TYPE"='DV_IDENT_CODES')
252 - filter('AN'=:4)
254 - access("TYPE"='DV_IDENT_CODES')
255 - filter('AR'=:4)
257 - access("TYPE"='DV_IDENT_CODES')
258 - filter('BG'=:4)
260 - access("TYPE"='DV_IDENT_CODES')
261 - filter('BR'=:4)
263 - access("TYPE"='DV_IDENT_CODES')
264 - filter('CE'=:4)
266 - access("TYPE"='DV_IDENT_CODES')
267 - filter('CH'=:4)
269 - access("TYPE"='DV_IDENT_CODES')
270 - filter('CS'=:4)
272 - access("TYPE"='DV_IDENT_CODES')
273 - filter('DA'=:4)
275 - access("TYPE"='DV_IDENT_CODES')
276 - filter('EL'=:4)
278 - access("TYPE"='DV_IDENT_CODES')
279 - filter('ES'=:4)
281 - access("TYPE"='DV_IDENT_CODES')
282 - filter('ET'=:4)
284 - access("TYPE"='DV_IDENT_CODES')
285 - filter('FI'=:4)
287 - access("TYPE"='DV_IDENT_CODES')
288 - filter('FL'=:4)
290 - access("TYPE"='DV_IDENT_CODES')
291 - filter('FR'=:4)
293 - access("TYPE"='DV_IDENT_CODES')
294 - filter('HR'=:4)
296 - access("TYPE"='DV_IDENT_CODES')
297 - filter('HU'=:4)
299 - access("TYPE"='DV_IDENT_CODES')
300 - filter('IT'=:4)
302 - access("TYPE"='DV_IDENT_CODES')
303 - filter('IW'=:4)
305 - access("TYPE"='DV_IDENT_CODES')
306 - filter('JA'=:4)
308 - access("TYPE"='DV_IDENT_CODES')
309 - filter('LV'=:4)
311 - access("TYPE"='DV_IDENT_CODES')
312 - filter('MX'=:4)
314 - access("TYPE"='DV_IDENT_CODES')
315 - filter('NL'=:4)
317 - access("TYPE"='DV_IDENT_CODES')
318 - filter('NO'=:4)
320 - access("TYPE"='DV_IDENT_CODES')
321 - filter('NO'=:4)
323 - access("TYPE"='DV_IDENT_CODES')
324 - filter('PL'=:4)
326 - access("TYPE"='DV_IDENT_CODES')
327 - filter('PT'=:4)
329 - access("TYPE"='DV_IDENT_CODES')
330 - filter('RO'=:4)
332 - access("TYPE"='DV_IDENT_CODES')
333 - filter('RU'=:4)
335 - access("TYPE"='DV_IDENT_CODES')
336 - filter('SK'=:4)
338 - access("TYPE"='DV_IDENT_CODES')
339 - filter('SL'=:4)
341 - access("TYPE"='DV_IDENT_CODES')
342 - filter('SR'=:4)
344 - access("TYPE"='DV_IDENT_CODES')
345 - filter('SV'=:4)
347 - access("TYPE"='DV_IDENT_CODES')
348 - filter('TR'=:4)
350 - access("TYPE"='DV_IDENT_CODES')
351 - filter('US'=:4)
353 - access("TYPE"='DV_IDENT_CODES')
354 - filter('VI'=:4)
356 - access("TYPE"='DV_IDENT_CODES')
357 - filter('ZH'=:4)
359 - access("TYPE"='DV_IDENT_CODES')
362 - access("VEN"."REFENCAISS"="TNMP"."REFELEM" AND "VEN"."REFDOSS"="TNMP"."REFDOSS")
363 - access("TNMP"."BALANCE_DCPT"<0)
369 - access("EN"."MOYENPAIMT"="MOY"."VALEUR")
374 - filter('AL'=:3)
376 - access("TYPE"='MOYENPAIMT')
377 - filter('AN'=:3)
379 - access("TYPE"='MOYENPAIMT')
380 - filter('AR'=:3)
382 - access("TYPE"='MOYENPAIMT')
383 - filter('BG'=:3)
385 - access("TYPE"='MOYENPAIMT')
386 - filter('BR'=:3)
388 - access("TYPE"='MOYENPAIMT')
389 - filter('CE'=:3)
391 - access("TYPE"='MOYENPAIMT')
392 - filter('CH'=:3)
394 - access("TYPE"='MOYENPAIMT')
395 - filter('CS'=:3)
397 - access("TYPE"='MOYENPAIMT')
398 - filter('DA'=:3)
400 - access("TYPE"='MOYENPAIMT')
401 - filter('EL'=:3)
403 - access("TYPE"='MOYENPAIMT')
404 - filter('ES'=:3)
406 - access("TYPE"='MOYENPAIMT')
407 - filter('ET'=:3)
409 - access("TYPE"='MOYENPAIMT')
410 - filter('FI'=:3)
412 - access("TYPE"='MOYENPAIMT')
413 - filter('FL'=:3)
415 - access("TYPE"='MOYENPAIMT')
416 - filter('FR'=:3)
418 - access("TYPE"='MOYENPAIMT')
419 - filter('HR'=:3)
421 - access("TYPE"='MOYENPAIMT')
422 - filter('HU'=:3)
424 - access("TYPE"='MOYENPAIMT')
425 - filter('IT'=:3)
427 - access("TYPE"='MOYENPAIMT')
428 - filter('IW'=:3)
430 - access("TYPE"='MOYENPAIMT')
431 - filter('JA'=:3)
433 - access("TYPE"='MOYENPAIMT')
434 - filter('LV'=:3)
436 - access("TYPE"='MOYENPAIMT')
437 - filter('MX'=:3)
439 - access("TYPE"='MOYENPAIMT')
440 - filter('NL'=:3)
442 - access("TYPE"='MOYENPAIMT')
443 - filter('NO'=:3)
445 - access("TYPE"='MOYENPAIMT')
446 - filter('NO'=:3)
448 - access("TYPE"='MOYENPAIMT')
449 - filter('PL'=:3)
451 - access("TYPE"='MOYENPAIMT')
452 - filter('PT'=:3)
454 - access("TYPE"='MOYENPAIMT')
455 - filter('RO'=:3)
457 - access("TYPE"='MOYENPAIMT')
458 - filter('RU'=:3)
460 - access("TYPE"='MOYENPAIMT')
461 - filter('SK'=:3)
463 - access("TYPE"='MOYENPAIMT')
464 - filter('SL'=:3)
466 - access("TYPE"='MOYENPAIMT')
467 - filter('SR'=:3)
469 - access("TYPE"='MOYENPAIMT')
470 - filter('SV'=:3)
472 - access("TYPE"='MOYENPAIMT')
473 - filter('TR'=:3)
475 - access("TYPE"='MOYENPAIMT')
476 - filter('US'=:3)
478 - access("TYPE"='MOYENPAIMT')
479 - filter('VI'=:3)
481 - access("TYPE"='MOYENPAIMT')
482 - filter('ZH'=:3)
484 - access("TYPE"='MOYENPAIMT')
488 - access("ACL"."REFINDIVIDU"="CL"."REFINDIVIDU")
490 - access("TCL"."REFINDIVIDU"="CL"."REFINDIVIDU")
492 - access("TCL"."REFDOSS"="D"."REFDOSS")
493 - access("TCL"."REFTYPE"='CL')
       filter("TCL"."REFTYPE"='CL')
498 - access("D"."RANGMT"="GP"."REFPERSO")
499 - storage(UPPER("CRM"."LOGIN") LIKE UPPER(:6))
       filter(UPPER("CRM"."LOGIN") LIKE UPPER(:6))
501 - access("T"."REFDOSS"="D"."REFDOSS")
       filter(("T"."TYPEELEM"='en' OR "T"."TYPEELEM"='vd'))
502 - access("T"."REFELEM"="EN"."REFENCAISS")
503 - filter((INTERNAL_FUNCTION("EN"."TYPENCAISS") AND "EN"."TRAITE"='2'))
505 - access("EN"."REFPAYEUR"="I"."REFINDIVIDU")
506 - filter(("NC"."REFER" IS NOT NULL AND "NC"."REFER"="EN"."REFENCAISS"))
507 - access("NC"."COMPOSTAGE"="EN"."LIEUPAIMT")
512 - filter(NVL(:2,'FR')='AL')
514 - access("VALEUR"="EN"."LIBELLE" AND "TYPE"='libfds')
515 - filter(NVL(:2,'FR')='AN')
517 - access("VALEUR"="EN"."LIBELLE" AND "TYPE"='libfds')
518 - filter(NVL(:2,'FR')='AR')
520 - access("VALEUR"="EN"."LIBELLE" AND "TYPE"='libfds')
521 - filter(NVL(:2,'FR')='BG')
523 - access("VALEUR"="EN"."LIBELLE" AND "TYPE"='libfds')
524 - filter(NVL(:2,'FR')='BR')
526 - access("VALEUR"="EN"."LIBELLE" AND "TYPE"='libfds')
527 - filter(NVL(:2,'FR')='CE')
529 - access("VALEUR"="EN"."LIBELLE" AND "TYPE"='libfds')
530 - filter(NVL(:2,'FR')='CH')
532 - access("VALEUR"="EN"."LIBELLE" AND "TYPE"='libfds')
533 - filter(NVL(:2,'FR')='CS')
535 - access("VALEUR"="EN"."LIBELLE" AND "TYPE"='libfds')
536 - filter(NVL(:2,'FR')='DA')
538 - access("VALEUR"="EN"."LIBELLE" AND "TYPE"='libfds')
539 - filter(NVL(:2,'FR')='EL')
541 - access("VALEUR"="EN"."LIBELLE" AND "TYPE"='libfds')
542 - filter(NVL(:2,'FR')='ES')
544 - access("VALEUR"="EN"."LIBELLE" AND "TYPE"='libfds')
545 - filter(NVL(:2,'FR')='ET')
547 - access("VALEUR"="EN"."LIBELLE" AND "TYPE"='libfds')
548 - filter(NVL(:2,'FR')='FI')
550 - access("VALEUR"="EN"."LIBELLE" AND "TYPE"='libfds')
551 - filter(NVL(:2,'FR')='FL')
553 - access("VALEUR"="EN"."LIBELLE" AND "TYPE"='libfds')
554 - filter(NVL(:2,'FR')='FR')
556 - access("VALEUR"="EN"."LIBELLE" AND "TYPE"='libfds')
557 - filter(NVL(:2,'FR')='HR')
559 - access("VALEUR"="EN"."LIBELLE" AND "TYPE"='libfds')
560 - filter(NVL(:2,'FR')='HU')
562 - access("VALEUR"="EN"."LIBELLE" AND "TYPE"='libfds')
563 - filter(NVL(:2,'FR')='IT')
565 - access("VALEUR"="EN"."LIBELLE" AND "TYPE"='libfds')
566 - filter(NVL(:2,'FR')='IW')
568 - access("VALEUR"="EN"."LIBELLE" AND "TYPE"='libfds')
569 - filter(NVL(:2,'FR')='JA')
571 - access("VALEUR"="EN"."LIBELLE" AND "TYPE"='libfds')
572 - filter(NVL(:2,'FR')='LV')
574 - access("VALEUR"="EN"."LIBELLE" AND "TYPE"='libfds')
575 - filter(NVL(:2,'FR')='MX')
577 - access("VALEUR"="EN"."LIBELLE" AND "TYPE"='libfds')
578 - filter(NVL(:2,'FR')='NL')
580 - access("VALEUR"="EN"."LIBELLE" AND "TYPE"='libfds')
581 - filter(NVL(:2,'FR')='NO')
583 - access("VALEUR"="EN"."LIBELLE" AND "TYPE"='libfds')
584 - filter(NVL(:2,'FR')='NO')
586 - access("VALEUR"="EN"."LIBELLE" AND "TYPE"='libfds')
587 - filter(NVL(:2,'FR')='PL')
589 - access("VALEUR"="EN"."LIBELLE" AND "TYPE"='libfds')
590 - filter(NVL(:2,'FR')='PT')
592 - access("VALEUR"="EN"."LIBELLE" AND "TYPE"='libfds')
593 - filter(NVL(:2,'FR')='RO')
595 - access("VALEUR"="EN"."LIBELLE" AND "TYPE"='libfds')
596 - filter(NVL(:2,'FR')='RU')
598 - access("VALEUR"="EN"."LIBELLE" AND "TYPE"='libfds')
599 - filter(NVL(:2,'FR')='SK')
601 - access("VALEUR"="EN"."LIBELLE" AND "TYPE"='libfds')
602 - filter(NVL(:2,'FR')='SL')
604 - access("VALEUR"="EN"."LIBELLE" AND "TYPE"='libfds')
605 - filter(NVL(:2,'FR')='SR')
607 - access("VALEUR"="EN"."LIBELLE" AND "TYPE"='libfds')
608 - filter(NVL(:2,'FR')='SV')
610 - access("VALEUR"="EN"."LIBELLE" AND "TYPE"='libfds')
611 - filter(NVL(:2,'FR')='TR')
613 - access("VALEUR"="EN"."LIBELLE" AND "TYPE"='libfds')
614 - filter(NVL(:2,'FR')='US')
616 - access("VALEUR"="EN"."LIBELLE" AND "TYPE"='libfds')
617 - filter(NVL(:2,'FR')='VI')
619 - access("VALEUR"="EN"."LIBELLE" AND "TYPE"='libfds')
620 - filter(NVL(:2,'FR')='ZH')
622 - access("VALEUR"="EN"."LIBELLE" AND "TYPE"='libfds')
623 - access("T"."REFDOSS"="VEN"."REFDOSS" AND "T"."REFELEM"="VEN"."REFENCAISS")
626 - access("EN"."LIEUPAIMT"="NC"."COMPOSTAGE")
627 - filter("VEN"."REFDOSS"="BAL"."REFDOSS")
628 - access("EN"."REFENCAISS"="BAL"."REFELEM")
631 - filter(:B1=:B2)
635 - access("CPT"."REFDOSS"=:B1)
636 - access("DECO"."REFDOSS"="CPT"."REFLOT")
637 - access("CTR"."REFDOSS"="DECO"."REFLOT")
640 - filter("DCPT"."CATEGDOSS" LIKE 'DECOMPTE%')
641 - access("DCPT"."REFDOSS"=:B1)
643 - access("CTR"."REFDOSS"="DCPT"."REFLOT")
644 - filter("CTR"."CATEGDOSS" LIKE 'CONTRAT%')
645 - access("CTR"."REFDOSS"=:B1)
*/
/********************************OLD Metrics***************************************/

/********************************New SQL*******************************************/

SELECT *
  FROM (SELECT /*+ first_rows(201)*/
         foo.*, ROWNUM rnum
          FROM (SELECT referEncaiss referEncaiss,
                       typeElem typeElem,
                       (SELECT chemin
                          FROM v_tdomaine
                         WHERE TYPE = 'NAM_COLLECTE'
                           AND abrev = SUBSTR(compostage, 1, 3)
                           AND langue = :B1
                           AND ROWNUM = 1) bookCode,
                       SUM(amountAllocatedPaymentAccount) OVER() totalAmountMouvements,
                       receptionDate receptionDate,
                       dtconfirm_dt dtconfirm_dt,
                       clientName clientName,
                       vcsNumber vcsNumber,
                       fg19 fg19,
                       externalCase externalCase,
                       paymentSource paymentSource,
                       encaissAmount encaissAmount,
                       displayPaymentType displayPaymentType,
                       additionalCommunication additionalCommunication,
                       algorithmResult algorithmResult,
                       paymentType paymentType,
                       paymentIdentification paymentIdentification,
                       amountAllocatedPayment amountAllocatedPayment,
                       internalCaseReference internalCaseReference,
                       COUNT(1) OVER() totalNumberMouvements,
                       CASE
                         WHEN internalCaseReference IS NULL THEN
                          montantNc
                         WHEN upper(libelleBal) LIKE
                              'DELAI AVANT ENCAISSEMENT%' THEN
                          (SELECT NVL(abs(montant_dosBal), 0) -
                                  NVL((SELECT ftr_match.partprelettrpmt(refelemBal,
                                                                       refdossBal,
                                                                       typeelemBal)
                                        FROM dual),
                                      0)
                             FROM dual)
                         ELSE
                          (SELECT NVL(ABS(montant_dosBal), 0) -
                                  NVL((SELECT SUM(NVL(ABS(montant_dos), 0))
                                        FROM g_venelem
                                       WHERE refencaiss = refelemBal
                                         AND refdoss = refdossBal
                                         AND typencaiss = typeelemBal),
                                      0)
                             FROM dual)
                       END balance,
                       payerReference payerReference,
                       imxUserId imxUserId,
                       payerName payerName,
                       caseManagerName caseManagerName,
                       batchSearch batchSearch,
                       transStatus transStatus,
                       paymentStatus paymentStatus,
                       cancelationDate cancelationDate,
                       comments comments,
                       amountAllocatedPaymentAccount amountAllocatedPaymentAccount,
                       paymentReference paymentReference,
                       no_bordereau no_bordereau,
                       stampingNumber stampingNumber,
                       crmManager crmManager,
                       masterStampingNumber masterStampingNumber,
                       paymentTitle paymentTitle,
                       initialAmount initialAmount,
                       displayPaymentMethod displayPaymentMethod,
                       paymentMethod paymentMethod,
                       paymentDate paymentDate,
                       paymentCurrency paymentCurrency,
                       secondComment secondComment,
                       dtcompt dtcompt,
                       DECODE(internalCaseReference,
                              NULL,
                              devise,
                              (SELECT devise
                                 FROM g_dossier
                                WHERE refdoss = internalCaseReference)) balanceCurrency
                  FROM (SELECT main_query.refer referEncaiss,
                               main_query.refdossier internalCaseReference,
                               main_query.montant_dos encaissAmount,
                               main_query.date1 paymentDate,
                               main_query.refindividu payerReference,
                               main_query.date2 receptionDate,
                               main_query.type_enc paymentType,
                               main_query.type_enc_aff displayPaymentType,
                               main_query.libelle paymentTitle,
                               main_query.nom_payeur payerName,
                               main_query.mont_mvt amountAllocatedPayment,
                               main_query.mont_enc amountAllocatedPaymentAccount,
                               main_query.mont_init initialAmount,
                               main_query.dev_init paymentCurrency,
                               main_query.no_bordereau,
                               main_query.num_vcs vcsNumber,
                               main_query.moyp paymentMethod,
                               main_query.moyp_trad displayPaymentMethod,
                               main_query.num_cheque paymentReference,
                               main_query.annul_dt cancelationDate,
                               main_query.typeelem typeElem,
                               main_query.source_pmt paymentSource,
                               main_query.rangmt imxUserId,
                               main_query.monref,
                               main_query.dtconfirm_dt,
                               main_query.clientName,
                               main_query.fg19,
                               main_query.refer_doss externalCase,
                               main_query.dtcompt,
                               main_query.namcol_ref stampingNumber,
                               gp.login caseManagerName,
                               nc.dtlot batchSearch,
                               nc.comm paymentIdentification,
                               nc.comm2 secondComment,
                               nc.master_compostage masterStampingNumber,
                               nc.compostage,
                               nc.devise,
                               nc.etat transStatus,
                               v2.valeur_trad algorithmResult,
                               nc.comments,
                               DECODE(To_Char(nc.messages), NULL, 'N', 'O') additionalCommunication,
                               crm.login crmManager,
                               v3.valeur_trad paymentStatus,
                               bal.refelem refelemBal,
                               bal.refdoss refdossBal,
                               bal.typeelem typeelemBal,
                               bal.libelle libelleBal,
                               bal.montant_dos montant_dosBal,
                               nc.montant montantNc
                          FROM (SELECT /*+ index(TNMP aggreg_t_ecrdos_nmp$bal) leading(TNMP) use_nl(TCL)*/
                                 EN.refencaiss REFER,
                                 VEN.refdoss REFDOSSIER,
                                 VEN.montant_dos montant_dos,
                                 t.dtassoc_dt DATE1,
                                 NVL(en.dtreception_dt, en.dtencaiss_dt) DATE2,
                                 'RECOUVREMENT DEBITEUR NON LETTRE' TYPE_ENC,
                                 'Debtor collection not fully matched' TYPE_ENC_AFF,
                                 v1.valeur_trad libelle,
                                 i.nom || ' ' || i.prenom NOM_PAYEUR,
                                 I.refindividu,
                                 VEN.montant_mvt MONT_MVT,
                                 t.montant MONT_ENC,
                                 NVL(DECODE(nc.signe, 1, -1, 1) * nc.montant,
                                     en.montant_mvt) MONT_INIT,
                                 NVL(nc.devise, en.devise_mvt) dev_INIT,
                                 EN.no_ordre NO_BORDEREAU,
                                 EN.num_vcs num_vcs,
                                 EN.moyenpaimt MOYP,
                                 moy.valeur_trad MOYP_TRAD,
                                EN.numchq NUM_CHEQUE,
                                 Nvl(en.dtannul_dt, en.dtimpaye_dt) annul_dt,
                                 t.TYPEELEM typeelem,
                                 'ENCAISS' source_pmt,
                                 d.rangmt rangmt,
                                 (SELECT ctr.monref
                                    FROM g_dossier ctr,
                                         g_dossier deco,
                                         g_dossier cpt
                                  WHERE ctr.refdoss = deco.reflot
                                     AND deco.refdoss = cpt.reflot
                                     AND cpt.refdoss = d.refdoss
                                     AND cpt.refdoss = nc.refdoss
                                  UNION
                                  SELECT ctr.monref
                                    FROM g_dossier ctr, g_dossier dcpt
                                   WHERE ctr.refdoss = dcpt.reflot
                                     AND dcpt.refdoss = nc.refdoss
                                     AND dcpt.categdoss LIKE 'DECOMPTE%'
                                  UNION
                                  SELECT ctr.monref
                                    FROM g_dossier ctr
                                   WHERE ctr.refdoss = nc.refdoss
                                     AND ctr.categdoss LIKE 'CONTRAT%') monref,
                                 en.DTCONFIRM_DT DTCONFIRM_DT,
                                 CL.nom clientName,
                                 ACL.fg19,
                                 Nvl(D.ancrefdoss, t.refdoss) refer_doss,
                                 t.dtsaisie dtcompt,
                                 en.lieupaimt namcol_ref,
                                 en.refrepres,
                                 en.dtimpaye_dt
                                  FROM g_ventilenc VEN,
                                       g_encaissement EN,
                                       nam_collecte NC,
                                       aggreg_t_ecrdos_nmp TNMP,
                                       g_dossier D,
                                       T_ELEMENTS t,
                                       G_INDIVIDU i,
                                       t_intervenants tcl,
                                       g_individu cl,
                                       g_accords acl,
                                       (SELECT valeur,
                                               MAX(valeur_trad) valeur_trad
                                          FROM v_tdomaine
                                         WHERE type = 'libfds'
                                           AND langue = NVL(:B1, 'FR')
                                         GROUP BY valeur) v1,
                                       (SELECT valeur,
                                               MAX(valeur_trad) valeur_trad
                                          FROM v_tdomaine
                                         WHERE type = 'MOYENPAIMT'
                                           AND langue = :B1
                                         GROUP BY valeur) moy
                                 WHERE t.refelem = en.REFENCAISS
                                   AND t.refdoss = D.refdoss
                                   AND acl.refindividu(+) = cl.refindividu
                                   AND t.refelem = ven.refencaiss(+)
                                   AND t.refdoss = ven.refdoss(+)
                                   AND EN.moyenpaimt = moy.valeur(+)
                                   AND EN.libelle = v1.valeur(+)
                                   AND EN.traite = '2'
                                   AND NC.refer(+) = EN.refencaiss
                                   AND NC.compostage(+) = EN.lieupaimt
                                   AND VEN.refencaiss = TNMP.refelem
                                   AND VEN.refdoss = TNMP.refdoss
                                   AND TNMP.balance_dcpt < 0
                                   AND t.typeelem in ('en', 'vd')
                                   AND en.traite NOT IN ('9')
                                   AND en.typencaiss in ('e_saencaiss', 'e_savirmt')
                                   AND EN.REFPAYEUR = I.REFINDIVIDU
                                   AND tcl.refdoss = D.refdoss
                                   AND tcl.reftype = 'CL'
                                   AND tcl.refindividu = cl.refindividu) main_query,
                               nam_collecte nc,
                               g_personnel gp,
                               t_elements bal,
                               (SELECT abrev, MAX(valeur_trad) valeur_trad
                                  FROM v_tdomaine
                                 WHERE type = 'DV_IDENT_CODES'
                                   AND langue = :B1
                                 GROUP BY abrev) v2,
                               (SELECT abrev, MAX(valeur_trad) valeur_trad
                                  FROM v_tdomaine
                                 WHERE type = 'STATUT_PAIEMENT'
                                   AND langue = :B1
                                 GROUP BY abrev) v3,
                               g_personnel crm
                         WHERE main_query.namcol_ref = nc.compostage(+)
                           AND main_query.rangmt = gp.refperso(+)
                           AND main_query.monref = crm.refperso(+)
                           AND nc.traite = v2.abrev(+)
                           AND main_query.refer = bal.refelem(+)
                           AND main_query.refdossier = bal.refdoss(+)
                           AND DECODE(main_query.refrepres,
                                      NULL,
                                      DECODE(main_query.dtimpaye_dt,
                                             NULL,
                                             'ENCAISSE',
                                             'IMPAYE'),
                                      'REPRESENTE') = v3.abrev(+)
                           AND crm.login LIKE :B2)
                 WHERE 1 = 1
                 ORDER BY paymentType,
                          DECODE(internalCaseReference,
                                 'REPART CHQ',
                                 'REPART CHQ',
                                 TO_NUMBER(internalCaseReference)),
                          paymentDate,
                          internalCaseReference) foo
         WHERE ROWNUM <= :B3)
WHERE 1 = 1
   AND rnum >= :B4;
/********************************New SQL*******************************************/
/********************************New Metrics***************************************/
/*
Plan hash value: 4196834620
-------------------------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                                  | Name                    | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers |
-------------------------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                                           |                         |      1 |        |  7959K(100)|     14 |00:00:00.20 |   68657 |
|*  1 |  COUNT STOPKEY                                             |                         |     14 |        |            |     14 |00:00:00.01 |      56 |
|   2 |   VIEW                                                     | V_TDOMAINE              |     14 |     37 |    37   (0)|     14 |00:00:00.01 |      56 |
|   3 |    UNION-ALL                                               |                         |     14 |        |            |     14 |00:00:00.01 |      56 |
|*  4 |     FILTER                                                 |                         |     14 |        |            |      0 |00:00:00.01 |       0 |
|   5 |      TABLE ACCESS BY INDEX ROWID BATCHED                   | V_DOMAINE               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|*  6 |       INDEX RANGE SCAN                                     | DOM_TYPABREV            |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|*  7 |     FILTER                                                 |                         |     14 |        |            |     14 |00:00:00.01 |      56 |
|   8 |      TABLE ACCESS BY INDEX ROWID BATCHED                   | V_DOMAINE               |     14 |      1 |     1   (0)|     14 |00:00:00.01 |      56 |
|*  9 |       INDEX RANGE SCAN                                     | DOM_TYPABREV            |     14 |      1 |     1   (0)|     14 |00:00:00.01 |      42 |
|* 10 |     FILTER                                                 |                         |      0 |        |            |      0 |00:00:00.01 |       0 |
|  11 |      TABLE ACCESS BY INDEX ROWID BATCHED                   | V_DOMAINE               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 12 |       INDEX RANGE SCAN                                     | DOM_TYPABREV            |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 13 |     FILTER                                                 |                         |      0 |        |            |      0 |00:00:00.01 |       0 |
|  14 |      TABLE ACCESS BY INDEX ROWID BATCHED                   | V_DOMAINE               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 15 |       INDEX RANGE SCAN                                     | DOM_TYPABREV            |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 16 |     FILTER                                                 |                         |      0 |        |            |      0 |00:00:00.01 |       0 |
|  17 |      TABLE ACCESS BY INDEX ROWID BATCHED                   | V_DOMAINE               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 18 |       INDEX RANGE SCAN                                     | DOM_TYPABREV            |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 19 |     FILTER                                                 |                         |      0 |        |            |      0 |00:00:00.01 |       0 |
|  20 |      TABLE ACCESS BY INDEX ROWID BATCHED                   | V_DOMAINE               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 21 |       INDEX RANGE SCAN                                     | DOM_TYPABREV            |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 22 |     FILTER                                                 |                         |      0 |        |            |      0 |00:00:00.01 |       0 |
|  23 |      TABLE ACCESS BY INDEX ROWID BATCHED                   | V_DOMAINE               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 24 |       INDEX RANGE SCAN                                     | DOM_TYPABREV            |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 25 |     FILTER                                                 |                         |      0 |        |            |      0 |00:00:00.01 |       0 |
|  26 |      TABLE ACCESS BY INDEX ROWID BATCHED                   | V_DOMAINE               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 27 |       INDEX RANGE SCAN                                     | DOM_TYPABREV            |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 28 |     FILTER                                                 |                         |      0 |        |            |      0 |00:00:00.01 |       0 |
|  29 |      TABLE ACCESS BY INDEX ROWID BATCHED                   | V_DOMAINE               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 30 |       INDEX RANGE SCAN                                     | DOM_TYPABREV            |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 31 |     FILTER                                                 |                         |      0 |        |            |      0 |00:00:00.01 |       0 |
|  32 |      TABLE ACCESS BY INDEX ROWID BATCHED                   | V_DOMAINE               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 33 |       INDEX RANGE SCAN                                     | DOM_TYPABREV            |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 34 |     FILTER                                                 |                         |      0 |        |            |      0 |00:00:00.01 |       0 |
|  35 |      TABLE ACCESS BY INDEX ROWID BATCHED                   | V_DOMAINE               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 36 |       INDEX RANGE SCAN                                     | DOM_TYPABREV            |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 37 |     FILTER                                                 |                         |      0 |        |            |      0 |00:00:00.01 |       0 |
|  38 |      TABLE ACCESS BY INDEX ROWID BATCHED                   | V_DOMAINE               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 39 |       INDEX RANGE SCAN                                     | DOM_TYPABREV            |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 40 |     FILTER                                                 |                         |      0 |        |            |      0 |00:00:00.01 |       0 |
|  41 |      TABLE ACCESS BY INDEX ROWID BATCHED                   | V_DOMAINE               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 42 |       INDEX RANGE SCAN                                     | DOM_TYPABREV            |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 43 |     FILTER                                                 |                         |      0 |        |            |      0 |00:00:00.01 |       0 |
|  44 |      TABLE ACCESS BY INDEX ROWID BATCHED                   | V_DOMAINE               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 45 |       INDEX RANGE SCAN                                     | DOM_TYPABREV            |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 46 |     FILTER                                                 |                         |      0 |        |            |      0 |00:00:00.01 |       0 |
|  47 |      TABLE ACCESS BY INDEX ROWID BATCHED                   | V_DOMAINE               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 48 |       INDEX RANGE SCAN                                     | DOM_TYPABREV            |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 49 |     FILTER                                                 |                         |      0 |        |            |      0 |00:00:00.01 |       0 |
|  50 |      TABLE ACCESS BY INDEX ROWID BATCHED                   | V_DOMAINE               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 51 |       INDEX RANGE SCAN                                     | DOM_TYPABREV            |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 52 |     FILTER                                                 |                         |      0 |        |            |      0 |00:00:00.01 |       0 |
|  53 |      TABLE ACCESS BY INDEX ROWID BATCHED                   | V_DOMAINE               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 54 |       INDEX RANGE SCAN                                     | DOM_TYPABREV            |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 55 |     FILTER                                                 |                         |      0 |        |            |      0 |00:00:00.01 |       0 |
|  56 |      TABLE ACCESS BY INDEX ROWID BATCHED                   | V_DOMAINE               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 57 |       INDEX RANGE SCAN                                     | DOM_TYPABREV            |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 58 |     FILTER                                                 |                         |      0 |        |            |      0 |00:00:00.01 |       0 |
|  59 |      TABLE ACCESS BY INDEX ROWID BATCHED                   | V_DOMAINE               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 60 |       INDEX RANGE SCAN                                     | DOM_TYPABREV            |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 61 |     FILTER                                                 |                         |      0 |        |            |      0 |00:00:00.01 |       0 |
|  62 |      TABLE ACCESS BY INDEX ROWID BATCHED                   | V_DOMAINE               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 63 |       INDEX RANGE SCAN                                     | DOM_TYPABREV            |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 64 |     FILTER                                                 |                         |      0 |        |            |      0 |00:00:00.01 |       0 |
|  65 |      TABLE ACCESS BY INDEX ROWID BATCHED                   | V_DOMAINE               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 66 |       INDEX RANGE SCAN                                     | DOM_TYPABREV            |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 67 |     FILTER                                                 |                         |      0 |        |            |      0 |00:00:00.01 |       0 |
|  68 |      TABLE ACCESS BY INDEX ROWID BATCHED                   | V_DOMAINE               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 69 |       INDEX RANGE SCAN                                     | DOM_TYPABREV            |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 70 |     FILTER                                                 |                         |      0 |        |            |      0 |00:00:00.01 |       0 |
|  71 |      TABLE ACCESS BY INDEX ROWID BATCHED                   | V_DOMAINE               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 72 |       INDEX RANGE SCAN                                     | DOM_TYPABREV            |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 73 |     FILTER                                                 |                         |      0 |        |            |      0 |00:00:00.01 |       0 |
|  74 |      TABLE ACCESS BY INDEX ROWID BATCHED                   | V_DOMAINE               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 75 |       INDEX RANGE SCAN                                     | DOM_TYPABREV            |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 76 |     FILTER                                                 |                         |      0 |        |            |      0 |00:00:00.01 |       0 |
|  77 |      TABLE ACCESS BY INDEX ROWID BATCHED                   | V_DOMAINE               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 78 |       INDEX RANGE SCAN                                     | DOM_TYPABREV            |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 79 |     FILTER                                                 |                         |      0 |        |            |      0 |00:00:00.01 |       0 |
|  80 |      TABLE ACCESS BY INDEX ROWID BATCHED                   | V_DOMAINE               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 81 |       INDEX RANGE SCAN                                     | DOM_TYPABREV            |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 82 |     FILTER                                                 |                         |      0 |        |            |      0 |00:00:00.01 |       0 |
|  83 |      TABLE ACCESS BY INDEX ROWID BATCHED                   | V_DOMAINE               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 84 |       INDEX RANGE SCAN                                     | DOM_TYPABREV            |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 85 |     FILTER                                                 |                         |      0 |        |            |      0 |00:00:00.01 |       0 |
|  86 |      TABLE ACCESS BY INDEX ROWID BATCHED                   | V_DOMAINE               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 87 |       INDEX RANGE SCAN                                     | DOM_TYPABREV            |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 88 |     FILTER                                                 |                         |      0 |        |            |      0 |00:00:00.01 |       0 |
|  89 |      TABLE ACCESS BY INDEX ROWID BATCHED                   | V_DOMAINE               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 90 |       INDEX RANGE SCAN                                     | DOM_TYPABREV            |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 91 |     FILTER                                                 |                         |      0 |        |            |      0 |00:00:00.01 |       0 |
|  92 |      TABLE ACCESS BY INDEX ROWID BATCHED                   | V_DOMAINE               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 93 |       INDEX RANGE SCAN                                     | DOM_TYPABREV            |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 94 |     FILTER                                                 |                         |      0 |        |            |      0 |00:00:00.01 |       0 |
|  95 |      TABLE ACCESS BY INDEX ROWID BATCHED                   | V_DOMAINE               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 96 |       INDEX RANGE SCAN                                     | DOM_TYPABREV            |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 97 |     FILTER                                                 |                         |      0 |        |            |      0 |00:00:00.01 |       0 |
|  98 |      TABLE ACCESS BY INDEX ROWID BATCHED                   | V_DOMAINE               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 99 |       INDEX RANGE SCAN                                     | DOM_TYPABREV            |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|*100 |     FILTER                                                 |                         |      0 |        |            |      0 |00:00:00.01 |       0 |
| 101 |      TABLE ACCESS BY INDEX ROWID BATCHED                   | V_DOMAINE               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|*102 |       INDEX RANGE SCAN                                     | DOM_TYPABREV            |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|*103 |     FILTER                                                 |                         |      0 |        |            |      0 |00:00:00.01 |       0 |
| 104 |      TABLE ACCESS BY INDEX ROWID BATCHED                   | V_DOMAINE               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|*105 |       INDEX RANGE SCAN                                     | DOM_TYPABREV            |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|*106 |     FILTER                                                 |                         |      0 |        |            |      0 |00:00:00.01 |       0 |
| 107 |      TABLE ACCESS BY INDEX ROWID BATCHED                   | V_DOMAINE               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|*108 |       INDEX RANGE SCAN                                     | DOM_TYPABREV            |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|*109 |     FILTER                                                 |                         |      0 |        |            |      0 |00:00:00.01 |       0 |
| 110 |      TABLE ACCESS BY INDEX ROWID BATCHED                   | V_DOMAINE               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|*111 |       INDEX RANGE SCAN                                     | DOM_TYPABREV            |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|*112 |     FILTER                                                 |                         |      0 |        |            |      0 |00:00:00.01 |       0 |
| 113 |      TABLE ACCESS BY INDEX ROWID BATCHED                   | V_DOMAINE               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|*114 |       INDEX RANGE SCAN                                     | DOM_TYPABREV            |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
| 115 |  FAST DUAL                                                 |                         |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |
| 116 |  FAST DUAL                                                 |                         |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |
| 117 |   SORT AGGREGATE                                           |                         |     14 |      1 |            |     14 |00:00:00.01 |      42 |
|*118 |    TABLE ACCESS BY INDEX ROWID BATCHED                     | G_VENELEM               |     14 |      1 |     1   (0)|     48 |00:00:00.01 |      42 |
|*119 |     INDEX RANGE SCAN                                       | VEN_ENCAIS              |     14 |      1 |     1   (0)|     48 |00:00:00.01 |      30 |
| 120 |   FAST DUAL                                                |                         |     14 |      1 |     2   (0)|     14 |00:00:00.01 |       0 |
| 121 |  TABLE ACCESS BY INDEX ROWID                               | G_DOSSIER               |     10 |      1 |     1   (0)|     10 |00:00:00.01 |      32 |
|*122 |   INDEX UNIQUE SCAN                                        | DOS_REFDOSS             |     10 |      1 |     1   (0)|     10 |00:00:00.01 |      22 |
|*123 |  VIEW                                                      |                         |      1 |    201 |  7959K  (1)|     14 |00:00:00.20 |   68657 |
|*124 |   COUNT STOPKEY                                            |                         |      1 |        |            |     14 |00:00:00.20 |   68657 |
| 125 |    VIEW                                                    |                         |      1 |    176K|  7959K  (1)|     14 |00:00:00.20 |   68657 |
| 126 |     WINDOW SORT                                            |                         |      1 |    176K|  7959K  (1)|     14 |00:00:00.20 |   68527 |
| 127 |      NESTED LOOPS OUTER                                    |                         |      1 |    165 | 56485   (1)|     14 |00:00:00.20 |   68527 |
| 128 |       NESTED LOOPS                                         |                         |      1 |    165 | 56478   (1)|     14 |00:00:00.20 |   68469 |
|*129 |        HASH JOIN RIGHT OUTER                               |                         |      1 |    174K| 52997   (1)|   3142 |00:00:00.18 |   65497 |
| 130 |         VIEW                                               |                         |      1 |     45 |    38   (3)|    176 |00:00:00.01 |      75 |
| 131 |          HASH GROUP BY                                     |                         |      1 |     45 |    38   (3)|    176 |00:00:00.01 |      75 |
| 132 |           VIEW                                             | V_TDOMAINE              |      1 |   1665 |    37   (0)|    177 |00:00:00.01 |      75 |
| 133 |            UNION-ALL                                       |                         |      1 |        |            |    177 |00:00:00.01 |      75 |
|*134 |             FILTER                                         |                         |      1 |        |            |      0 |00:00:00.01 |       0 |
| 135 |              TABLE ACCESS BY INDEX ROWID BATCHED           | V_DOMAINE               |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*136 |               INDEX RANGE SCAN                             | V_DOMAINE_TYPE_CODE_IDX |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*137 |             FILTER                                         |                         |      1 |        |            |    177 |00:00:00.01 |      75 |
| 138 |              TABLE ACCESS BY INDEX ROWID BATCHED           | V_DOMAINE               |      1 |     45 |     1   (0)|    177 |00:00:00.01 |      75 |
|*139 |               INDEX RANGE SCAN                             | V_DOMAINE_TYPE_CODE_IDX |      1 |     45 |     1   (0)|    177 |00:00:00.01 |       3 |
|*140 |             FILTER                                         |                         |      1 |        |            |      0 |00:00:00.01 |       0 |
| 141 |              TABLE ACCESS BY INDEX ROWID BATCHED           | V_DOMAINE               |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*142 |               INDEX RANGE SCAN                             | V_DOMAINE_TYPE_CODE_IDX |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*143 |             FILTER                                         |                         |      1 |        |            |      0 |00:00:00.01 |       0 |
| 144 |              TABLE ACCESS BY INDEX ROWID BATCHED           | V_DOMAINE               |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*145 |               INDEX RANGE SCAN                             | V_DOMAINE_TYPE_CODE_IDX |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*146 |             FILTER                                         |                         |      1 |        |            |      0 |00:00:00.01 |       0 |
| 147 |              TABLE ACCESS BY INDEX ROWID BATCHED           | V_DOMAINE               |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*148 |               INDEX RANGE SCAN                             | V_DOMAINE_TYPE_CODE_IDX |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*149 |             FILTER                                         |                         |      1 |        |            |      0 |00:00:00.01 |       0 |
| 150 |              TABLE ACCESS BY INDEX ROWID BATCHED           | V_DOMAINE               |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*151 |               INDEX RANGE SCAN                             | V_DOMAINE_TYPE_CODE_IDX |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*152 |             FILTER                                         |                         |      1 |        |            |      0 |00:00:00.01 |       0 |
| 153 |              TABLE ACCESS BY INDEX ROWID BATCHED           | V_DOMAINE               |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*154 |               INDEX RANGE SCAN                             | V_DOMAINE_TYPE_CODE_IDX |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*155 |             FILTER                                         |                         |      1 |        |            |      0 |00:00:00.01 |       0 |
| 156 |              TABLE ACCESS BY INDEX ROWID BATCHED           | V_DOMAINE               |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*157 |               INDEX RANGE SCAN                             | V_DOMAINE_TYPE_CODE_IDX |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*158 |             FILTER                                         |                         |      1 |        |            |      0 |00:00:00.01 |       0 |
| 159 |              TABLE ACCESS BY INDEX ROWID BATCHED           | V_DOMAINE               |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*160 |               INDEX RANGE SCAN                             | V_DOMAINE_TYPE_CODE_IDX |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*161 |             FILTER                                         |                         |      1 |        |            |      0 |00:00:00.01 |       0 |
| 162 |              TABLE ACCESS BY INDEX ROWID BATCHED           | V_DOMAINE               |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*163 |               INDEX RANGE SCAN                             | V_DOMAINE_TYPE_CODE_IDX |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*164 |             FILTER                                         |                         |      1 |        |            |      0 |00:00:00.01 |       0 |
| 165 |              TABLE ACCESS BY INDEX ROWID BATCHED           | V_DOMAINE               |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*166 |               INDEX RANGE SCAN                             | V_DOMAINE_TYPE_CODE_IDX |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*167 |             FILTER                                         |                         |      1 |        |            |      0 |00:00:00.01 |       0 |
| 168 |              TABLE ACCESS BY INDEX ROWID BATCHED           | V_DOMAINE               |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*169 |               INDEX RANGE SCAN                             | V_DOMAINE_TYPE_CODE_IDX |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*170 |             FILTER                                         |                         |      1 |        |            |      0 |00:00:00.01 |       0 |
| 171 |              TABLE ACCESS BY INDEX ROWID BATCHED           | V_DOMAINE               |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*172 |               INDEX RANGE SCAN                             | V_DOMAINE_TYPE_CODE_IDX |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*173 |             FILTER                                         |                         |      1 |        |            |      0 |00:00:00.01 |       0 |
| 174 |              TABLE ACCESS BY INDEX ROWID BATCHED           | V_DOMAINE               |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*175 |               INDEX RANGE SCAN                             | V_DOMAINE_TYPE_CODE_IDX |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*176 |             FILTER                                         |                         |      1 |        |            |      0 |00:00:00.01 |       0 |
| 177 |              TABLE ACCESS BY INDEX ROWID BATCHED           | V_DOMAINE               |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*178 |               INDEX RANGE SCAN                             | V_DOMAINE_TYPE_CODE_IDX |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*179 |             FILTER                                         |                         |      1 |        |            |      0 |00:00:00.01 |       0 |
| 180 |              TABLE ACCESS BY INDEX ROWID BATCHED           | V_DOMAINE               |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*181 |               INDEX RANGE SCAN                             | V_DOMAINE_TYPE_CODE_IDX |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*182 |             FILTER                                         |                         |      1 |        |            |      0 |00:00:00.01 |       0 |
| 183 |              TABLE ACCESS BY INDEX ROWID BATCHED           | V_DOMAINE               |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*184 |               INDEX RANGE SCAN                             | V_DOMAINE_TYPE_CODE_IDX |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*185 |             FILTER                                         |                         |      1 |        |            |      0 |00:00:00.01 |       0 |
| 186 |              TABLE ACCESS BY INDEX ROWID BATCHED           | V_DOMAINE               |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*187 |               INDEX RANGE SCAN                             | V_DOMAINE_TYPE_CODE_IDX |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*188 |             FILTER                                         |                         |      1 |        |            |      0 |00:00:00.01 |       0 |
| 189 |              TABLE ACCESS BY INDEX ROWID BATCHED           | V_DOMAINE               |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*190 |               INDEX RANGE SCAN                             | V_DOMAINE_TYPE_CODE_IDX |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*191 |             FILTER                                         |                         |      1 |        |            |      0 |00:00:00.01 |       0 |
| 192 |              TABLE ACCESS BY INDEX ROWID BATCHED           | V_DOMAINE               |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*193 |               INDEX RANGE SCAN                             | V_DOMAINE_TYPE_CODE_IDX |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*194 |             FILTER                                         |                         |      1 |        |            |      0 |00:00:00.01 |       0 |
| 195 |              TABLE ACCESS BY INDEX ROWID BATCHED           | V_DOMAINE               |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*196 |               INDEX RANGE SCAN                             | V_DOMAINE_TYPE_CODE_IDX |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*197 |             FILTER                                         |                         |      1 |        |            |      0 |00:00:00.01 |       0 |
| 198 |              TABLE ACCESS BY INDEX ROWID BATCHED           | V_DOMAINE               |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*199 |               INDEX RANGE SCAN                             | V_DOMAINE_TYPE_CODE_IDX |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*200 |             FILTER                                         |                         |      1 |        |            |      0 |00:00:00.01 |       0 |
| 201 |              TABLE ACCESS BY INDEX ROWID BATCHED           | V_DOMAINE               |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*202 |               INDEX RANGE SCAN                             | V_DOMAINE_TYPE_CODE_IDX |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*203 |             FILTER                                         |                         |      1 |        |            |      0 |00:00:00.01 |       0 |
| 204 |              TABLE ACCESS BY INDEX ROWID BATCHED           | V_DOMAINE               |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*205 |               INDEX RANGE SCAN                             | V_DOMAINE_TYPE_CODE_IDX |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*206 |             FILTER                                         |                         |      1 |        |            |      0 |00:00:00.01 |       0 |
| 207 |              TABLE ACCESS BY INDEX ROWID BATCHED           | V_DOMAINE               |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*208 |               INDEX RANGE SCAN                             | V_DOMAINE_TYPE_CODE_IDX |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*209 |             FILTER                                         |                         |      1 |        |            |      0 |00:00:00.01 |       0 |
| 210 |              TABLE ACCESS BY INDEX ROWID BATCHED           | V_DOMAINE               |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*211 |               INDEX RANGE SCAN                             | V_DOMAINE_TYPE_CODE_IDX |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*212 |             FILTER                                         |                         |      1 |        |            |      0 |00:00:00.01 |       0 |
| 213 |              TABLE ACCESS BY INDEX ROWID BATCHED           | V_DOMAINE               |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*214 |               INDEX RANGE SCAN                             | V_DOMAINE_TYPE_CODE_IDX |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*215 |             FILTER                                         |                         |      1 |        |            |      0 |00:00:00.01 |       0 |
| 216 |              TABLE ACCESS BY INDEX ROWID BATCHED           | V_DOMAINE               |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*217 |               INDEX RANGE SCAN                             | V_DOMAINE_TYPE_CODE_IDX |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*218 |             FILTER                                         |                         |      1 |        |            |      0 |00:00:00.01 |       0 |
| 219 |              TABLE ACCESS BY INDEX ROWID BATCHED           | V_DOMAINE               |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*220 |               INDEX RANGE SCAN                             | V_DOMAINE_TYPE_CODE_IDX |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*221 |             FILTER                                         |                         |      1 |        |            |      0 |00:00:00.01 |       0 |
| 222 |              TABLE ACCESS BY INDEX ROWID BATCHED           | V_DOMAINE               |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*223 |               INDEX RANGE SCAN                             | V_DOMAINE_TYPE_CODE_IDX |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*224 |             FILTER                                         |                         |      1 |        |            |      0 |00:00:00.01 |       0 |
| 225 |              TABLE ACCESS BY INDEX ROWID BATCHED           | V_DOMAINE               |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*226 |               INDEX RANGE SCAN                             | V_DOMAINE_TYPE_CODE_IDX |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*227 |             FILTER                                         |                         |      1 |        |            |      0 |00:00:00.01 |       0 |
| 228 |              TABLE ACCESS BY INDEX ROWID BATCHED           | V_DOMAINE               |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*229 |               INDEX RANGE SCAN                             | V_DOMAINE_TYPE_CODE_IDX |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*230 |             FILTER                                         |                         |      1 |        |            |      0 |00:00:00.01 |       0 |
| 231 |              TABLE ACCESS BY INDEX ROWID BATCHED           | V_DOMAINE               |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*232 |               INDEX RANGE SCAN                             | V_DOMAINE_TYPE_CODE_IDX |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*233 |             FILTER                                         |                         |      1 |        |            |      0 |00:00:00.01 |       0 |
| 234 |              TABLE ACCESS BY INDEX ROWID BATCHED           | V_DOMAINE               |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*235 |               INDEX RANGE SCAN                             | V_DOMAINE_TYPE_CODE_IDX |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*236 |             FILTER                                         |                         |      1 |        |            |      0 |00:00:00.01 |       0 |
| 237 |              TABLE ACCESS BY INDEX ROWID BATCHED           | V_DOMAINE               |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*238 |               INDEX RANGE SCAN                             | V_DOMAINE_TYPE_CODE_IDX |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*239 |             FILTER                                         |                         |      1 |        |            |      0 |00:00:00.01 |       0 |
| 240 |              TABLE ACCESS BY INDEX ROWID BATCHED           | V_DOMAINE               |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*241 |               INDEX RANGE SCAN                             | V_DOMAINE_TYPE_CODE_IDX |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*242 |             FILTER                                         |                         |      1 |        |            |      0 |00:00:00.01 |       0 |
| 243 |              TABLE ACCESS BY INDEX ROWID BATCHED           | V_DOMAINE               |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*244 |               INDEX RANGE SCAN                             | V_DOMAINE_TYPE_CODE_IDX |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
| 245 |         NESTED LOOPS OUTER                                 |                         |      1 |    174K| 52958   (1)|   3142 |00:00:00.18 |   65422 |
| 246 |          NESTED LOOPS OUTER                                |                         |      1 |    174K| 52020   (1)|   3142 |00:00:00.17 |   64918 |
| 247 |           NESTED LOOPS                                     |                         |      1 |    174K| 50144   (1)|   3142 |00:00:00.17 |   64414 |
|*248 |            HASH JOIN RIGHT OUTER                           |                         |      1 |    174K| 46662   (1)|   3142 |00:00:00.15 |   55337 |
| 249 |             VIEW                                           |                         |      1 |     45 |    38   (3)|      0 |00:00:00.01 |       2 |
| 250 |              HASH GROUP BY                                 |                         |      1 |     45 |    38   (3)|      0 |00:00:00.01 |       2 |
| 251 |               VIEW                                         | V_TDOMAINE              |      1 |   1665 |    37   (0)|      0 |00:00:00.01 |       2 |
| 252 |                UNION-ALL                                   |                         |      1 |        |            |      0 |00:00:00.01 |       2 |
|*253 |                 FILTER                                     |                         |      1 |        |            |      0 |00:00:00.01 |       0 |
| 254 |                  TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE               |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*255 |                   INDEX RANGE SCAN                         | V_DOMAINE_TYPE_CODE_IDX |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*256 |                 FILTER                                     |                         |      1 |        |            |      0 |00:00:00.01 |       2 |
| 257 |                  TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE               |      1 |     45 |     1   (0)|      0 |00:00:00.01 |       2 |
|*258 |                   INDEX RANGE SCAN                         | V_DOMAINE_TYPE_CODE_IDX |      1 |     45 |     1   (0)|      0 |00:00:00.01 |       2 |
|*259 |                 FILTER                                     |                         |      1 |        |            |      0 |00:00:00.01 |       0 |
| 260 |                  TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE               |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*261 |                   INDEX RANGE SCAN                         | V_DOMAINE_TYPE_CODE_IDX |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*262 |                 FILTER                                     |                         |      1 |        |            |      0 |00:00:00.01 |       0 |
| 263 |                  TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE               |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*264 |                   INDEX RANGE SCAN                         | V_DOMAINE_TYPE_CODE_IDX |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*265 |                 FILTER                                     |                         |      1 |        |            |      0 |00:00:00.01 |       0 |
| 266 |                  TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE               |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*267 |                   INDEX RANGE SCAN                         | V_DOMAINE_TYPE_CODE_IDX |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*268 |                 FILTER                                     |                         |      1 |        |            |      0 |00:00:00.01 |       0 |
| 269 |                  TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE               |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*270 |                   INDEX RANGE SCAN                         | V_DOMAINE_TYPE_CODE_IDX |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*271 |                 FILTER                                     |                         |      1 |        |            |      0 |00:00:00.01 |       0 |
| 272 |                  TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE               |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*273 |                   INDEX RANGE SCAN                         | V_DOMAINE_TYPE_CODE_IDX |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*274 |                 FILTER                                     |                         |      1 |        |            |      0 |00:00:00.01 |       0 |
| 275 |                  TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE               |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*276 |                   INDEX RANGE SCAN                         | V_DOMAINE_TYPE_CODE_IDX |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*277 |                 FILTER                                     |                         |      1 |        |            |      0 |00:00:00.01 |       0 |
| 278 |                  TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE               |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*279 |                   INDEX RANGE SCAN                         | V_DOMAINE_TYPE_CODE_IDX |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*280 |                 FILTER                                     |                         |      1 |        |            |      0 |00:00:00.01 |       0 |
| 281 |                  TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE               |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*282 |                   INDEX RANGE SCAN                         | V_DOMAINE_TYPE_CODE_IDX |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*283 |                 FILTER                                     |                         |      1 |        |            |      0 |00:00:00.01 |       0 |
| 284 |                  TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE               |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*285 |                   INDEX RANGE SCAN                         | V_DOMAINE_TYPE_CODE_IDX |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*286 |                 FILTER                                     |                         |      1 |        |            |      0 |00:00:00.01 |       0 |
| 287 |                  TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE               |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*288 |                   INDEX RANGE SCAN                         | V_DOMAINE_TYPE_CODE_IDX |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*289 |                 FILTER                                     |                         |      1 |        |            |      0 |00:00:00.01 |       0 |
| 290 |                  TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE               |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*291 |                   INDEX RANGE SCAN                         | V_DOMAINE_TYPE_CODE_IDX |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*292 |                 FILTER                                     |                         |      1 |        |            |      0 |00:00:00.01 |       0 |
| 293 |                  TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE               |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*294 |                   INDEX RANGE SCAN                         | V_DOMAINE_TYPE_CODE_IDX |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*295 |                 FILTER                                     |                         |      1 |        |            |      0 |00:00:00.01 |       0 |
| 296 |                  TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE               |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*297 |                   INDEX RANGE SCAN                         | V_DOMAINE_TYPE_CODE_IDX |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*298 |                 FILTER                                     |                         |      1 |        |            |      0 |00:00:00.01 |       0 |
| 299 |                  TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE               |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*300 |                   INDEX RANGE SCAN                         | V_DOMAINE_TYPE_CODE_IDX |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*301 |                 FILTER                                     |                         |      1 |        |            |      0 |00:00:00.01 |       0 |
| 302 |                  TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE               |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*303 |                   INDEX RANGE SCAN                         | V_DOMAINE_TYPE_CODE_IDX |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*304 |                 FILTER                                     |                         |      1 |        |            |      0 |00:00:00.01 |       0 |
| 305 |                  TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE               |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*306 |                   INDEX RANGE SCAN                         | V_DOMAINE_TYPE_CODE_IDX |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*307 |                 FILTER                                     |                         |      1 |        |            |      0 |00:00:00.01 |       0 |
| 308 |                  TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE               |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*309 |                   INDEX RANGE SCAN                         | V_DOMAINE_TYPE_CODE_IDX |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*310 |                 FILTER                                     |                         |      1 |        |            |      0 |00:00:00.01 |       0 |
| 311 |                  TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE               |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*312 |                   INDEX RANGE SCAN                         | V_DOMAINE_TYPE_CODE_IDX |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*313 |                 FILTER                                     |                         |      1 |        |            |      0 |00:00:00.01 |       0 |
| 314 |                  TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE               |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*315 |                   INDEX RANGE SCAN                         | V_DOMAINE_TYPE_CODE_IDX |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*316 |                 FILTER                                     |                         |      1 |        |            |      0 |00:00:00.01 |       0 |
| 317 |                  TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE               |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*318 |                   INDEX RANGE SCAN                         | V_DOMAINE_TYPE_CODE_IDX |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*319 |                 FILTER                                     |                         |      1 |        |            |      0 |00:00:00.01 |       0 |
| 320 |                  TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE               |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*321 |                   INDEX RANGE SCAN                         | V_DOMAINE_TYPE_CODE_IDX |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*322 |                 FILTER                                     |                         |      1 |        |            |      0 |00:00:00.01 |       0 |
| 323 |                  TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE               |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*324 |                   INDEX RANGE SCAN                         | V_DOMAINE_TYPE_CODE_IDX |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*325 |                 FILTER                                     |                         |      1 |        |            |      0 |00:00:00.01 |       0 |
| 326 |                  TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE               |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*327 |                   INDEX RANGE SCAN                         | V_DOMAINE_TYPE_CODE_IDX |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*328 |                 FILTER                                     |                         |      1 |        |            |      0 |00:00:00.01 |       0 |
| 329 |                  TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE               |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*330 |                   INDEX RANGE SCAN                         | V_DOMAINE_TYPE_CODE_IDX |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*331 |                 FILTER                                     |                         |      1 |        |            |      0 |00:00:00.01 |       0 |
| 332 |                  TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE               |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*333 |                   INDEX RANGE SCAN                         | V_DOMAINE_TYPE_CODE_IDX |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*334 |                 FILTER                                     |                         |      1 |        |            |      0 |00:00:00.01 |       0 |
| 335 |                  TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE               |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*336 |                   INDEX RANGE SCAN                         | V_DOMAINE_TYPE_CODE_IDX |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*337 |                 FILTER                                     |                         |      1 |        |            |      0 |00:00:00.01 |       0 |
| 338 |                  TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE               |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*339 |                   INDEX RANGE SCAN                         | V_DOMAINE_TYPE_CODE_IDX |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*340 |                 FILTER                                     |                         |      1 |        |            |      0 |00:00:00.01 |       0 |
| 341 |                  TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE               |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*342 |                   INDEX RANGE SCAN                         | V_DOMAINE_TYPE_CODE_IDX |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*343 |                 FILTER                                     |                         |      1 |        |            |      0 |00:00:00.01 |       0 |
| 344 |                  TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE               |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*345 |                   INDEX RANGE SCAN                         | V_DOMAINE_TYPE_CODE_IDX |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*346 |                 FILTER                                     |                         |      1 |        |            |      0 |00:00:00.01 |       0 |
| 347 |                  TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE               |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*348 |                   INDEX RANGE SCAN                         | V_DOMAINE_TYPE_CODE_IDX |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*349 |                 FILTER                                     |                         |      1 |        |            |      0 |00:00:00.01 |       0 |
| 350 |                  TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE               |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*351 |                   INDEX RANGE SCAN                         | V_DOMAINE_TYPE_CODE_IDX |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*352 |                 FILTER                                     |                         |      1 |        |            |      0 |00:00:00.01 |       0 |
| 353 |                  TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE               |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*354 |                   INDEX RANGE SCAN                         | V_DOMAINE_TYPE_CODE_IDX |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*355 |                 FILTER                                     |                         |      1 |        |            |      0 |00:00:00.01 |       0 |
| 356 |                  TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE               |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*357 |                   INDEX RANGE SCAN                         | V_DOMAINE_TYPE_CODE_IDX |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*358 |                 FILTER                                     |                         |      1 |        |            |      0 |00:00:00.01 |       0 |
| 359 |                  TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE               |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*360 |                   INDEX RANGE SCAN                         | V_DOMAINE_TYPE_CODE_IDX |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*361 |                 FILTER                                     |                         |      1 |        |            |      0 |00:00:00.01 |       0 |
| 362 |                  TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE               |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*363 |                   INDEX RANGE SCAN                         | V_DOMAINE_TYPE_CODE_IDX |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*364 |             HASH JOIN RIGHT OUTER                          |                         |      1 |    174K| 46623   (1)|   3142 |00:00:00.15 |   55335 |
| 365 |              VIEW                                          |                         |      1 |     45 |    38   (3)|     15 |00:00:00.01 |       6 |
| 366 |               HASH GROUP BY                                |                         |      1 |     45 |    38   (3)|     15 |00:00:00.01 |       6 |
| 367 |                VIEW                                        | V_TDOMAINE              |      1 |   1665 |    37   (0)|     15 |00:00:00.01 |       6 |
| 368 |                 UNION-ALL                                  |                         |      1 |        |            |     15 |00:00:00.01 |       6 |
|*369 |                  FILTER                                    |                         |      1 |        |            |      0 |00:00:00.01 |       0 |
| 370 |                   TABLE ACCESS BY INDEX ROWID BATCHED      | V_DOMAINE               |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*371 |                    INDEX RANGE SCAN                        | V_DOMAINE_TYPE_CODE_IDX |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*372 |                  FILTER                                    |                         |      1 |        |            |     15 |00:00:00.01 |       6 |
| 373 |                   TABLE ACCESS BY INDEX ROWID BATCHED      | V_DOMAINE               |      1 |     45 |     1   (0)|     15 |00:00:00.01 |       6 |
|*374 |                    INDEX RANGE SCAN                        | V_DOMAINE_TYPE_CODE_IDX |      1 |     45 |     1   (0)|     15 |00:00:00.01 |       2 |
|*375 |                  FILTER                                    |                         |      1 |        |            |      0 |00:00:00.01 |       0 |
| 376 |                   TABLE ACCESS BY INDEX ROWID BATCHED      | V_DOMAINE               |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*377 |                    INDEX RANGE SCAN                        | V_DOMAINE_TYPE_CODE_IDX |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*378 |                  FILTER                                    |                         |      1 |        |            |      0 |00:00:00.01 |       0 |
| 379 |                   TABLE ACCESS BY INDEX ROWID BATCHED      | V_DOMAINE               |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*380 |                    INDEX RANGE SCAN                        | V_DOMAINE_TYPE_CODE_IDX |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*381 |                  FILTER                                    |                         |      1 |        |            |      0 |00:00:00.01 |       0 |
| 382 |                   TABLE ACCESS BY INDEX ROWID BATCHED      | V_DOMAINE               |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*383 |                    INDEX RANGE SCAN                        | V_DOMAINE_TYPE_CODE_IDX |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*384 |                  FILTER                                    |                         |      1 |        |            |      0 |00:00:00.01 |       0 |
| 385 |                   TABLE ACCESS BY INDEX ROWID BATCHED      | V_DOMAINE               |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*386 |                    INDEX RANGE SCAN                        | V_DOMAINE_TYPE_CODE_IDX |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*387 |                  FILTER                                    |                         |      1 |        |            |      0 |00:00:00.01 |       0 |
| 388 |                   TABLE ACCESS BY INDEX ROWID BATCHED      | V_DOMAINE               |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*389 |                    INDEX RANGE SCAN                        | V_DOMAINE_TYPE_CODE_IDX |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*390 |                  FILTER                                    |                         |      1 |        |            |      0 |00:00:00.01 |       0 |
| 391 |                   TABLE ACCESS BY INDEX ROWID BATCHED      | V_DOMAINE               |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*392 |                    INDEX RANGE SCAN                        | V_DOMAINE_TYPE_CODE_IDX |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*393 |                  FILTER                                    |                         |      1 |        |            |      0 |00:00:00.01 |       0 |
| 394 |                   TABLE ACCESS BY INDEX ROWID BATCHED      | V_DOMAINE               |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*395 |                    INDEX RANGE SCAN                        | V_DOMAINE_TYPE_CODE_IDX |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*396 |                  FILTER                                    |                         |      1 |        |            |      0 |00:00:00.01 |       0 |
| 397 |                   TABLE ACCESS BY INDEX ROWID BATCHED      | V_DOMAINE               |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*398 |                    INDEX RANGE SCAN                        | V_DOMAINE_TYPE_CODE_IDX |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*399 |                  FILTER                                    |                         |      1 |        |            |      0 |00:00:00.01 |       0 |
| 400 |                   TABLE ACCESS BY INDEX ROWID BATCHED      | V_DOMAINE               |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*401 |                    INDEX RANGE SCAN                        | V_DOMAINE_TYPE_CODE_IDX |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*402 |                  FILTER                                    |                         |      1 |        |            |      0 |00:00:00.01 |       0 |
| 403 |                   TABLE ACCESS BY INDEX ROWID BATCHED      | V_DOMAINE               |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*404 |                    INDEX RANGE SCAN                        | V_DOMAINE_TYPE_CODE_IDX |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*405 |                  FILTER                                    |                         |      1 |        |            |      0 |00:00:00.01 |       0 |
| 406 |                   TABLE ACCESS BY INDEX ROWID BATCHED      | V_DOMAINE               |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*407 |                    INDEX RANGE SCAN                        | V_DOMAINE_TYPE_CODE_IDX |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*408 |                  FILTER                                    |                         |      1 |        |            |      0 |00:00:00.01 |       0 |
| 409 |                   TABLE ACCESS BY INDEX ROWID BATCHED      | V_DOMAINE               |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*410 |                    INDEX RANGE SCAN                        | V_DOMAINE_TYPE_CODE_IDX |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*411 |                  FILTER                                    |                         |      1 |        |            |      0 |00:00:00.01 |       0 |
| 412 |                   TABLE ACCESS BY INDEX ROWID BATCHED      | V_DOMAINE               |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*413 |                    INDEX RANGE SCAN                        | V_DOMAINE_TYPE_CODE_IDX |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*414 |                  FILTER                                    |                         |      1 |        |            |      0 |00:00:00.01 |       0 |
| 415 |                   TABLE ACCESS BY INDEX ROWID BATCHED      | V_DOMAINE               |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*416 |                    INDEX RANGE SCAN                        | V_DOMAINE_TYPE_CODE_IDX |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*417 |                  FILTER                                    |                         |      1 |        |            |      0 |00:00:00.01 |       0 |
| 418 |                   TABLE ACCESS BY INDEX ROWID BATCHED      | V_DOMAINE               |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*419 |                    INDEX RANGE SCAN                        | V_DOMAINE_TYPE_CODE_IDX |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*420 |                  FILTER                                    |                         |      1 |        |            |      0 |00:00:00.01 |       0 |
| 421 |                   TABLE ACCESS BY INDEX ROWID BATCHED      | V_DOMAINE               |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*422 |                    INDEX RANGE SCAN                        | V_DOMAINE_TYPE_CODE_IDX |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*423 |                  FILTER                                    |                         |      1 |        |            |      0 |00:00:00.01 |       0 |
| 424 |                   TABLE ACCESS BY INDEX ROWID BATCHED      | V_DOMAINE               |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*425 |                    INDEX RANGE SCAN                        | V_DOMAINE_TYPE_CODE_IDX |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*426 |                  FILTER                                    |                         |      1 |        |            |      0 |00:00:00.01 |       0 |
| 427 |                   TABLE ACCESS BY INDEX ROWID BATCHED      | V_DOMAINE               |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*428 |                    INDEX RANGE SCAN                        | V_DOMAINE_TYPE_CODE_IDX |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*429 |                  FILTER                                    |                         |      1 |        |            |      0 |00:00:00.01 |       0 |
| 430 |                   TABLE ACCESS BY INDEX ROWID BATCHED      | V_DOMAINE               |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*431 |                    INDEX RANGE SCAN                        | V_DOMAINE_TYPE_CODE_IDX |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*432 |                  FILTER                                    |                         |      1 |        |            |      0 |00:00:00.01 |       0 |
| 433 |                   TABLE ACCESS BY INDEX ROWID BATCHED      | V_DOMAINE               |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*434 |                    INDEX RANGE SCAN                        | V_DOMAINE_TYPE_CODE_IDX |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*435 |                  FILTER                                    |                         |      1 |        |            |      0 |00:00:00.01 |       0 |
| 436 |                   TABLE ACCESS BY INDEX ROWID BATCHED      | V_DOMAINE               |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*437 |                    INDEX RANGE SCAN                        | V_DOMAINE_TYPE_CODE_IDX |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*438 |                  FILTER                                    |                         |      1 |        |            |      0 |00:00:00.01 |       0 |
| 439 |                   TABLE ACCESS BY INDEX ROWID BATCHED      | V_DOMAINE               |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*440 |                    INDEX RANGE SCAN                        | V_DOMAINE_TYPE_CODE_IDX |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*441 |                  FILTER                                    |                         |      1 |        |            |      0 |00:00:00.01 |       0 |
| 442 |                   TABLE ACCESS BY INDEX ROWID BATCHED      | V_DOMAINE               |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*443 |                    INDEX RANGE SCAN                        | V_DOMAINE_TYPE_CODE_IDX |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*444 |                  FILTER                                    |                         |      1 |        |            |      0 |00:00:00.01 |       0 |
| 445 |                   TABLE ACCESS BY INDEX ROWID BATCHED      | V_DOMAINE               |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*446 |                    INDEX RANGE SCAN                        | V_DOMAINE_TYPE_CODE_IDX |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*447 |                  FILTER                                    |                         |      1 |        |            |      0 |00:00:00.01 |       0 |
| 448 |                   TABLE ACCESS BY INDEX ROWID BATCHED      | V_DOMAINE               |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*449 |                    INDEX RANGE SCAN                        | V_DOMAINE_TYPE_CODE_IDX |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*450 |                  FILTER                                    |                         |      1 |        |            |      0 |00:00:00.01 |       0 |
| 451 |                   TABLE ACCESS BY INDEX ROWID BATCHED      | V_DOMAINE               |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*452 |                    INDEX RANGE SCAN                        | V_DOMAINE_TYPE_CODE_IDX |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*453 |                  FILTER                                    |                         |      1 |        |            |      0 |00:00:00.01 |       0 |
| 454 |                   TABLE ACCESS BY INDEX ROWID BATCHED      | V_DOMAINE               |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*455 |                    INDEX RANGE SCAN                        | V_DOMAINE_TYPE_CODE_IDX |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*456 |                  FILTER                                    |                         |      1 |        |            |      0 |00:00:00.01 |       0 |
| 457 |                   TABLE ACCESS BY INDEX ROWID BATCHED      | V_DOMAINE               |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*458 |                    INDEX RANGE SCAN                        | V_DOMAINE_TYPE_CODE_IDX |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*459 |                  FILTER                                    |                         |      1 |        |            |      0 |00:00:00.01 |       0 |
| 460 |                   TABLE ACCESS BY INDEX ROWID BATCHED      | V_DOMAINE               |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*461 |                    INDEX RANGE SCAN                        | V_DOMAINE_TYPE_CODE_IDX |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*462 |                  FILTER                                    |                         |      1 |        |            |      0 |00:00:00.01 |       0 |
| 463 |                   TABLE ACCESS BY INDEX ROWID BATCHED      | V_DOMAINE               |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*464 |                    INDEX RANGE SCAN                        | V_DOMAINE_TYPE_CODE_IDX |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*465 |                  FILTER                                    |                         |      1 |        |            |      0 |00:00:00.01 |       0 |
| 466 |                   TABLE ACCESS BY INDEX ROWID BATCHED      | V_DOMAINE               |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*467 |                    INDEX RANGE SCAN                        | V_DOMAINE_TYPE_CODE_IDX |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*468 |                  FILTER                                    |                         |      1 |        |            |      0 |00:00:00.01 |       0 |
| 469 |                   TABLE ACCESS BY INDEX ROWID BATCHED      | V_DOMAINE               |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*470 |                    INDEX RANGE SCAN                        | V_DOMAINE_TYPE_CODE_IDX |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*471 |                  FILTER                                    |                         |      1 |        |            |      0 |00:00:00.01 |       0 |
| 472 |                   TABLE ACCESS BY INDEX ROWID BATCHED      | V_DOMAINE               |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*473 |                    INDEX RANGE SCAN                        | V_DOMAINE_TYPE_CODE_IDX |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*474 |                  FILTER                                    |                         |      1 |        |            |      0 |00:00:00.01 |       0 |
| 475 |                   TABLE ACCESS BY INDEX ROWID BATCHED      | V_DOMAINE               |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*476 |                    INDEX RANGE SCAN                        | V_DOMAINE_TYPE_CODE_IDX |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*477 |                  FILTER                                    |                         |      1 |        |            |      0 |00:00:00.01 |       0 |
| 478 |                   TABLE ACCESS BY INDEX ROWID BATCHED      | V_DOMAINE               |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*479 |                    INDEX RANGE SCAN                        | V_DOMAINE_TYPE_CODE_IDX |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*480 |              HASH JOIN RIGHT OUTER                         |                         |      1 |    174K| 46585   (1)|   3142 |00:00:00.14 |   55329 |
| 481 |               VIEW                                         |                         |      1 |     45 |    38   (3)|     24 |00:00:00.01 |      14 |
| 482 |                HASH GROUP BY                               |                         |      1 |     45 |    38   (3)|     24 |00:00:00.01 |      14 |
| 483 |                 VIEW                                       | V_TDOMAINE              |      1 |   1665 |    37   (0)|     24 |00:00:00.01 |      14 |
| 484 |                  UNION-ALL                                 |                         |      1 |        |            |     24 |00:00:00.01 |      14 |
|*485 |                   FILTER                                   |                         |      1 |        |            |      0 |00:00:00.01 |       0 |
| 486 |                    TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE               |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*487 |                     INDEX RANGE SCAN                       | V_DOMAINE_TYPE_CODE_IDX |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*488 |                   FILTER                                   |                         |      1 |        |            |     24 |00:00:00.01 |      14 |
| 489 |                    TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE               |      1 |     45 |     1   (0)|     24 |00:00:00.01 |      14 |
|*490 |                     INDEX RANGE SCAN                       | V_DOMAINE_TYPE_CODE_IDX |      1 |     45 |     1   (0)|     24 |00:00:00.01 |       2 |
|*491 |                   FILTER                                   |                         |      1 |        |            |      0 |00:00:00.01 |       0 |
| 492 |                    TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE               |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*493 |                     INDEX RANGE SCAN                       | V_DOMAINE_TYPE_CODE_IDX |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*494 |                   FILTER                                   |                         |      1 |        |            |      0 |00:00:00.01 |       0 |
| 495 |                    TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE               |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*496 |                     INDEX RANGE SCAN                       | V_DOMAINE_TYPE_CODE_IDX |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*497 |                   FILTER                                   |                         |      1 |        |            |      0 |00:00:00.01 |       0 |
| 498 |                    TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE               |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*499 |                     INDEX RANGE SCAN                       | V_DOMAINE_TYPE_CODE_IDX |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*500 |                   FILTER                                   |                         |      1 |        |            |      0 |00:00:00.01 |       0 |
| 501 |                    TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE               |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*502 |                     INDEX RANGE SCAN                       | V_DOMAINE_TYPE_CODE_IDX |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*503 |                   FILTER                                   |                         |      1 |        |            |      0 |00:00:00.01 |       0 |
| 504 |                    TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE               |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*505 |                     INDEX RANGE SCAN                       | V_DOMAINE_TYPE_CODE_IDX |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*506 |                   FILTER                                   |                         |      1 |        |            |      0 |00:00:00.01 |       0 |
| 507 |                    TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE               |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*508 |                     INDEX RANGE SCAN                       | V_DOMAINE_TYPE_CODE_IDX |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*509 |                   FILTER                                   |                         |      1 |        |            |      0 |00:00:00.01 |       0 |
| 510 |                    TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE               |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*511 |                     INDEX RANGE SCAN                       | V_DOMAINE_TYPE_CODE_IDX |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*512 |                   FILTER                                   |                         |      1 |        |            |      0 |00:00:00.01 |       0 |
| 513 |                    TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE               |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*514 |                     INDEX RANGE SCAN                       | V_DOMAINE_TYPE_CODE_IDX |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*515 |                   FILTER                                   |                         |      1 |        |            |      0 |00:00:00.01 |       0 |
| 516 |                    TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE               |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*517 |                     INDEX RANGE SCAN                       | V_DOMAINE_TYPE_CODE_IDX |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*518 |                   FILTER                                   |                         |      1 |        |            |      0 |00:00:00.01 |       0 |
| 519 |                    TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE               |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*520 |                     INDEX RANGE SCAN                       | V_DOMAINE_TYPE_CODE_IDX |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*521 |                   FILTER                                   |                         |      1 |        |            |      0 |00:00:00.01 |       0 |
| 522 |                    TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE               |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*523 |                     INDEX RANGE SCAN                       | V_DOMAINE_TYPE_CODE_IDX |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*524 |                   FILTER                                   |                         |      1 |        |            |      0 |00:00:00.01 |       0 |
| 525 |                    TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE               |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*526 |                     INDEX RANGE SCAN                       | V_DOMAINE_TYPE_CODE_IDX |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*527 |                   FILTER                                   |                         |      1 |        |            |      0 |00:00:00.01 |       0 |
| 528 |                    TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE               |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*529 |                     INDEX RANGE SCAN                       | V_DOMAINE_TYPE_CODE_IDX |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*530 |                   FILTER                                   |                         |      1 |        |            |      0 |00:00:00.01 |       0 |
| 531 |                    TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE               |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*532 |                     INDEX RANGE SCAN                       | V_DOMAINE_TYPE_CODE_IDX |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*533 |                   FILTER                                   |                         |      1 |        |            |      0 |00:00:00.01 |       0 |
| 534 |                    TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE               |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*535 |                     INDEX RANGE SCAN                       | V_DOMAINE_TYPE_CODE_IDX |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*536 |                   FILTER                                   |                         |      1 |        |            |      0 |00:00:00.01 |       0 |
| 537 |                    TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE               |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*538 |                     INDEX RANGE SCAN                       | V_DOMAINE_TYPE_CODE_IDX |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*539 |                   FILTER                                   |                         |      1 |        |            |      0 |00:00:00.01 |       0 |
| 540 |                    TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE               |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*541 |                     INDEX RANGE SCAN                       | V_DOMAINE_TYPE_CODE_IDX |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*542 |                   FILTER                                   |                         |      1 |        |            |      0 |00:00:00.01 |       0 |
| 543 |                    TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE               |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*544 |                     INDEX RANGE SCAN                       | V_DOMAINE_TYPE_CODE_IDX |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*545 |                   FILTER                                   |                         |      1 |        |            |      0 |00:00:00.01 |       0 |
| 546 |                    TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE               |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*547 |                     INDEX RANGE SCAN                       | V_DOMAINE_TYPE_CODE_IDX |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*548 |                   FILTER                                   |                         |      1 |        |            |      0 |00:00:00.01 |       0 |
| 549 |                    TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE               |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*550 |                     INDEX RANGE SCAN                       | V_DOMAINE_TYPE_CODE_IDX |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*551 |                   FILTER                                   |                         |      1 |        |            |      0 |00:00:00.01 |       0 |
| 552 |                    TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE               |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*553 |                     INDEX RANGE SCAN                       | V_DOMAINE_TYPE_CODE_IDX |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*554 |                   FILTER                                   |                         |      1 |        |            |      0 |00:00:00.01 |       0 |
| 555 |                    TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE               |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*556 |                     INDEX RANGE SCAN                       | V_DOMAINE_TYPE_CODE_IDX |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*557 |                   FILTER                                   |                         |      1 |        |            |      0 |00:00:00.01 |       0 |
| 558 |                    TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE               |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*559 |                     INDEX RANGE SCAN                       | V_DOMAINE_TYPE_CODE_IDX |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*560 |                   FILTER                                   |                         |      1 |        |            |      0 |00:00:00.01 |       0 |
| 561 |                    TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE               |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*562 |                     INDEX RANGE SCAN                       | V_DOMAINE_TYPE_CODE_IDX |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*563 |                   FILTER                                   |                         |      1 |        |            |      0 |00:00:00.01 |       0 |
| 564 |                    TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE               |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*565 |                     INDEX RANGE SCAN                       | V_DOMAINE_TYPE_CODE_IDX |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*566 |                   FILTER                                   |                         |      1 |        |            |      0 |00:00:00.01 |       0 |
| 567 |                    TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE               |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*568 |                     INDEX RANGE SCAN                       | V_DOMAINE_TYPE_CODE_IDX |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*569 |                   FILTER                                   |                         |      1 |        |            |      0 |00:00:00.01 |       0 |
| 570 |                    TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE               |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*571 |                     INDEX RANGE SCAN                       | V_DOMAINE_TYPE_CODE_IDX |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*572 |                   FILTER                                   |                         |      1 |        |            |      0 |00:00:00.01 |       0 |
| 573 |                    TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE               |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*574 |                     INDEX RANGE SCAN                       | V_DOMAINE_TYPE_CODE_IDX |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*575 |                   FILTER                                   |                         |      1 |        |            |      0 |00:00:00.01 |       0 |
| 576 |                    TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE               |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*577 |                     INDEX RANGE SCAN                       | V_DOMAINE_TYPE_CODE_IDX |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*578 |                   FILTER                                   |                         |      1 |        |            |      0 |00:00:00.01 |       0 |
| 579 |                    TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE               |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*580 |                     INDEX RANGE SCAN                       | V_DOMAINE_TYPE_CODE_IDX |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*581 |                   FILTER                                   |                         |      1 |        |            |      0 |00:00:00.01 |       0 |
| 582 |                    TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE               |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*583 |                     INDEX RANGE SCAN                       | V_DOMAINE_TYPE_CODE_IDX |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*584 |                   FILTER                                   |                         |      1 |        |            |      0 |00:00:00.01 |       0 |
| 585 |                    TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE               |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*586 |                     INDEX RANGE SCAN                       | V_DOMAINE_TYPE_CODE_IDX |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*587 |                   FILTER                                   |                         |      1 |        |            |      0 |00:00:00.01 |       0 |
| 588 |                    TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE               |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*589 |                     INDEX RANGE SCAN                       | V_DOMAINE_TYPE_CODE_IDX |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*590 |                   FILTER                                   |                         |      1 |        |            |      0 |00:00:00.01 |       0 |
| 591 |                    TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE               |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*592 |                     INDEX RANGE SCAN                       | V_DOMAINE_TYPE_CODE_IDX |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*593 |                   FILTER                                   |                         |      1 |        |            |      0 |00:00:00.01 |       0 |
| 594 |                    TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE               |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
|*595 |                     INDEX RANGE SCAN                       | V_DOMAINE_TYPE_CODE_IDX |      0 |     45 |     1   (0)|      0 |00:00:00.01 |       0 |
| 596 |               NESTED LOOPS                                 |                         |      1 |    174K| 46546   (1)|   3142 |00:00:00.14 |   55315 |
| 597 |                NESTED LOOPS                                |                         |      1 |    174K| 46546   (1)|   3142 |00:00:00.13 |   52353 |
|*598 |                 HASH JOIN RIGHT OUTER                      |                         |      1 |    174K| 43064   (1)|   3142 |00:00:00.12 |   46139 |
| 599 |                  TABLE ACCESS STORAGE FULL FIRST ROWS      | G_ACCORDS               |      1 |     44 |     4   (0)|     44 |00:00:00.01 |       6 |
| 600 |                  NESTED LOOPS                              |                         |      1 |    174K| 43060   (1)|   3142 |00:00:00.11 |   46133 |
| 601 |                   NESTED LOOPS                             |                         |      1 |    174K| 43060   (1)|   3142 |00:00:00.11 |   43535 |
| 602 |                    NESTED LOOPS                            |                         |      1 |    174K| 39578   (1)|   3142 |00:00:00.10 |   37407 |
|*603 |                     HASH JOIN RIGHT OUTER                  |                         |      1 |    218K| 35210   (1)|   3142 |00:00:00.08 |   31245 |
| 604 |                      TABLE ACCESS STORAGE FULL FIRST ROWS  | G_PERSONNEL             |      1 |   1073 |   103   (0)|   1074 |00:00:00.01 |     373 |
| 605 |                      NESTED LOOPS                          |                         |      1 |    218K| 35107   (1)|   3142 |00:00:00.08 |   30872 |
| 606 |                       NESTED LOOPS                         |                         |      1 |    218K| 35107   (1)|   3142 |00:00:00.07 |   27861 |
| 607 |                        NESTED LOOPS                        |                         |      1 |    218K| 30739   (1)|   3142 |00:00:00.05 |   21702 |
| 608 |                         NESTED LOOPS                       |                         |      1 |    511K| 10275   (1)|   3142 |00:00:00.03 |    9443 |
|*609 |                          INDEX RANGE SCAN                  | AGGREG_T_ECRDOS_NMP$BAL |      1 |    511K|    43   (0)|   3142 |00:00:00.01 |      84 |
| 610 |                          TABLE ACCESS BY INDEX ROWID       | G_VENTILENC             |   3142 |      1 |     1   (0)|   3142 |00:00:00.02 |    9359 |
|*611 |                           INDEX UNIQUE SCAN                | VENT_REFDOSS            |   3142 |      1 |     1   (0)|   3142 |00:00:00.02 |    6214 |
|*612 |                         TABLE ACCESS BY INDEX ROWID BATCHED| T_ELEMENTS              |   3142 |      1 |     1   (0)|   3142 |00:00:00.03 |   12259 |
|*613 |                          INDEX RANGE SCAN                  | ELE_ELEMTYPE            |   3142 |      1 |     1   (0)|   3142 |00:00:00.02 |    9341 |
|*614 |                        INDEX UNIQUE SCAN                   | DOS_REFDOSS             |   3142 |      1 |     1   (0)|   3142 |00:00:00.01 |    6159 |
| 615 |                       TABLE ACCESS BY INDEX ROWID          | G_DOSSIER               |   3142 |      1 |     1   (0)|   3142 |00:00:00.01 |    3011 |
|*616 |                     INDEX RANGE SCAN                       | INT_REFDOSS             |   3142 |      1 |     1   (0)|   3142 |00:00:00.02 |    6162 |
|*617 |                    INDEX UNIQUE SCAN                       | IND_REFINDIV            |   3142 |      1 |     1   (0)|   3142 |00:00:00.01 |    6128 |
| 618 |                   TABLE ACCESS BY INDEX ROWID              | G_INDIVIDU              |   3142 |      1 |     1   (0)|   3142 |00:00:00.01 |    2598 |
|*619 |                 INDEX UNIQUE SCAN                          | REFENCAISS              |   3142 |      1 |     1   (0)|   3142 |00:00:00.01 |    6214 |
|*620 |                TABLE ACCESS BY INDEX ROWID                 | G_ENCAISSEMENT          |   3142 |      1 |     1   (0)|   3142 |00:00:00.01 |    2962 |
| 621 |            TABLE ACCESS BY INDEX ROWID                     | G_INDIVIDU              |   3142 |      1 |     1   (0)|   3142 |00:00:00.02 |    9077 |
|*622 |             INDEX UNIQUE SCAN                              | IND_REFINDIV            |   3142 |      1 |     1   (0)|   3142 |00:00:00.01 |    6204 |
|*623 |           TABLE ACCESS BY INDEX ROWID                      | NAM_COLLECTE            |   3142 |      1 |     1   (0)|    164 |00:00:00.01 |     504 |
|*624 |            INDEX UNIQUE SCAN                               | COLCOMPOSTAGE           |   3142 |      1 |     1   (0)|    164 |00:00:00.01 |     330 |
| 625 |          TABLE ACCESS BY INDEX ROWID                       | NAM_COLLECTE            |   3142 |      1 |     1   (0)|    164 |00:00:00.01 |     504 |
|*626 |           INDEX UNIQUE SCAN                                | COLCOMPOSTAGE           |   3142 |      1 |     1   (0)|    164 |00:00:00.01 |     330 |
|*627 |        TABLE ACCESS BY INDEX ROWID BATCHED                 | G_PERSONNEL             |   3142 |      1 |     1   (0)|     14 |00:00:00.02 |    2972 |
|*628 |         INDEX RANGE SCAN                                   | GPERSREFP               |   3142 |      1 |     1   (0)|    164 |00:00:00.02 |    2850 |
| 629 |          SORT UNIQUE                                       |                         |   2280 |      3 |     6   (0)|    142 |00:00:00.02 |    2842 |
| 630 |           UNION-ALL                                        |                         |   2280 |        |            |    142 |00:00:00.01 |    2842 |
|*631 |            FILTER                                          |                         |   2280 |        |            |    142 |00:00:00.01 |    1694 |
| 632 |             NESTED LOOPS                                   |                         |    142 |      1 |     3   (0)|    142 |00:00:00.01 |    1694 |
| 633 |              NESTED LOOPS                                  |                         |    142 |      1 |     3   (0)|    142 |00:00:00.01 |    1271 |
| 634 |               NESTED LOOPS                                 |                         |    142 |      1 |     2   (0)|    142 |00:00:00.01 |     854 |
|*635 |                INDEX RANGE SCAN                            | DOS_REFDOSS_REFLOT_IDX  |    142 |      1 |     1   (0)|    142 |00:00:00.01 |     428 |
|*636 |                INDEX RANGE SCAN                            | DOS_REFDOSS_REFLOT_IDX  |    142 |      1 |     1   (0)|    142 |00:00:00.01 |     426 |
|*637 |               INDEX UNIQUE SCAN                            | DOS_REFDOSS             |    142 |      1 |     1   (0)|    142 |00:00:00.01 |     417 |
| 638 |              TABLE ACCESS BY INDEX ROWID                   | G_DOSSIER               |    142 |      1 |     1   (0)|    142 |00:00:00.01 |     423 |
| 639 |            NESTED LOOPS                                    |                         |   2280 |      1 |     2   (0)|      0 |00:00:00.01 |     574 |
|*640 |             TABLE ACCESS BY INDEX ROWID                    | G_DOSSIER               |   2280 |      1 |     1   (0)|      0 |00:00:00.01 |     574 |
|*641 |              INDEX UNIQUE SCAN                             | DOS_REFDOSS             |   2280 |      1 |     1   (0)|    142 |00:00:00.01 |     426 |
| 642 |             TABLE ACCESS BY INDEX ROWID                    | G_DOSSIER               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|*643 |              INDEX UNIQUE SCAN                             | DOS_REFDOSS             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|*644 |            TABLE ACCESS BY INDEX ROWID                     | G_DOSSIER               |   2280 |      1 |     1   (0)|      0 |00:00:00.01 |     574 |
|*645 |             INDEX UNIQUE SCAN                              | DOS_REFDOSS             |   2280 |      1 |     1   (0)|    142 |00:00:00.01 |     426 |
|*646 |       TABLE ACCESS BY INDEX ROWID BATCHED                  | T_ELEMENTS              |     14 |      1 |     1   (0)|     14 |00:00:00.01 |      58 |
|*647 |        INDEX RANGE SCAN                                    | ELE_ELEMTYPE            |     14 |      1 |     1   (0)|     14 |00:00:00.01 |      44 |
-------------------------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   1 - filter(ROWNUM=1)
   4 - filter('AL'=:B1)
   6 - access("TYPE"='NAM_COLLECTE' AND "ABREV"=SUBSTR(:B1,1,3))
   7 - filter('AN'=:B1)
   9 - access("TYPE"='NAM_COLLECTE' AND "ABREV"=SUBSTR(:B1,1,3))
  10 - filter('AR'=:B1)
  12 - access("TYPE"='NAM_COLLECTE' AND "ABREV"=SUBSTR(:B1,1,3))
  13 - filter('BG'=:B1)
  15 - access("TYPE"='NAM_COLLECTE' AND "ABREV"=SUBSTR(:B1,1,3))
  16 - filter('BR'=:B1)
  18 - access("TYPE"='NAM_COLLECTE' AND "ABREV"=SUBSTR(:B1,1,3))
  19 - filter('CE'=:B1)
  21 - access("TYPE"='NAM_COLLECTE' AND "ABREV"=SUBSTR(:B1,1,3))
  22 - filter('CH'=:B1)
  24 - access("TYPE"='NAM_COLLECTE' AND "ABREV"=SUBSTR(:B1,1,3))
  25 - filter('CS'=:B1)
  27 - access("TYPE"='NAM_COLLECTE' AND "ABREV"=SUBSTR(:B1,1,3))
  28 - filter('DA'=:B1)
  30 - access("TYPE"='NAM_COLLECTE' AND "ABREV"=SUBSTR(:B1,1,3))
  31 - filter('EL'=:B1)
  33 - access("TYPE"='NAM_COLLECTE' AND "ABREV"=SUBSTR(:B1,1,3))
  34 - filter('ES'=:B1)
  36 - access("TYPE"='NAM_COLLECTE' AND "ABREV"=SUBSTR(:B1,1,3))
  37 - filter('ET'=:B1)
  39 - access("TYPE"='NAM_COLLECTE' AND "ABREV"=SUBSTR(:B1,1,3))
  40 - filter('FI'=:B1)
  42 - access("TYPE"='NAM_COLLECTE' AND "ABREV"=SUBSTR(:B1,1,3))
  43 - filter('FL'=:B1)
  45 - access("TYPE"='NAM_COLLECTE' AND "ABREV"=SUBSTR(:B1,1,3))
  46 - filter('FR'=:B1)
  48 - access("TYPE"='NAM_COLLECTE' AND "ABREV"=SUBSTR(:B1,1,3))
  49 - filter('HR'=:B1)
  51 - access("TYPE"='NAM_COLLECTE' AND "ABREV"=SUBSTR(:B1,1,3))
  52 - filter('HU'=:B1)
  54 - access("TYPE"='NAM_COLLECTE' AND "ABREV"=SUBSTR(:B1,1,3))
  55 - filter('IT'=:B1)
  57 - access("TYPE"='NAM_COLLECTE' AND "ABREV"=SUBSTR(:B1,1,3))
  58 - filter('IW'=:B1)
  60 - access("TYPE"='NAM_COLLECTE' AND "ABREV"=SUBSTR(:B1,1,3))
  61 - filter('JA'=:B1)
  63 - access("TYPE"='NAM_COLLECTE' AND "ABREV"=SUBSTR(:B1,1,3))
  64 - filter('LV'=:B1)
  66 - access("TYPE"='NAM_COLLECTE' AND "ABREV"=SUBSTR(:B1,1,3))
  67 - filter('MX'=:B1)
  69 - access("TYPE"='NAM_COLLECTE' AND "ABREV"=SUBSTR(:B1,1,3))
  70 - filter('NL'=:B1)
  72 - access("TYPE"='NAM_COLLECTE' AND "ABREV"=SUBSTR(:B1,1,3))
  73 - filter('NO'=:B1)
  75 - access("TYPE"='NAM_COLLECTE' AND "ABREV"=SUBSTR(:B1,1,3))
  76 - filter('NO'=:B1)
  78 - access("TYPE"='NAM_COLLECTE' AND "ABREV"=SUBSTR(:B1,1,3))
  79 - filter('PL'=:B1)
  81 - access("TYPE"='NAM_COLLECTE' AND "ABREV"=SUBSTR(:B1,1,3))
  82 - filter('PT'=:B1)
  84 - access("TYPE"='NAM_COLLECTE' AND "ABREV"=SUBSTR(:B1,1,3))
  85 - filter('RO'=:B1)
  87 - access("TYPE"='NAM_COLLECTE' AND "ABREV"=SUBSTR(:B1,1,3))
  88 - filter('RU'=:B1)
  90 - access("TYPE"='NAM_COLLECTE' AND "ABREV"=SUBSTR(:B1,1,3))
  91 - filter('SK'=:B1)
  93 - access("TYPE"='NAM_COLLECTE' AND "ABREV"=SUBSTR(:B1,1,3))
  94 - filter('SL'=:B1)
  96 - access("TYPE"='NAM_COLLECTE' AND "ABREV"=SUBSTR(:B1,1,3))
  97 - filter('SR'=:B1)
  99 - access("TYPE"='NAM_COLLECTE' AND "ABREV"=SUBSTR(:B1,1,3))
100 - filter('SV'=:B1)
102 - access("TYPE"='NAM_COLLECTE' AND "ABREV"=SUBSTR(:B1,1,3))
103 - filter('TR'=:B1)
105 - access("TYPE"='NAM_COLLECTE' AND "ABREV"=SUBSTR(:B1,1,3))
106 - filter('US'=:B1)
108 - access("TYPE"='NAM_COLLECTE' AND "ABREV"=SUBSTR(:B1,1,3))
109 - filter('VI'=:B1)
111 - access("TYPE"='NAM_COLLECTE' AND "ABREV"=SUBSTR(:B1,1,3))
112 - filter('ZH'=:B1)
114 - access("TYPE"='NAM_COLLECTE' AND "ABREV"=SUBSTR(:B1,1,3))
118 - filter(("REFDOSS"=:B1 AND "TYPENCAISS"=:B2))
119 - access("REFENCAISS"=:B1)
122 - access("REFDOSS"=:B1)
123 - filter("RNUM">=:B4)
124 - filter(ROWNUM<=:B3)
129 - access("NC"."TRAITE"=TO_NUMBER("V2"."ABREV"))
134 - filter('AL'=:B1)
136 - access("TYPE"='DV_IDENT_CODES')
137 - filter('AN'=:B1)
139 - access("TYPE"='DV_IDENT_CODES')
140 - filter('AR'=:B1)
142 - access("TYPE"='DV_IDENT_CODES')
143 - filter('BG'=:B1)
145 - access("TYPE"='DV_IDENT_CODES')
146 - filter('BR'=:B1)
148 - access("TYPE"='DV_IDENT_CODES')
149 - filter('CE'=:B1)
151 - access("TYPE"='DV_IDENT_CODES')
152 - filter('CH'=:B1)
154 - access("TYPE"='DV_IDENT_CODES')
155 - filter('CS'=:B1)
157 - access("TYPE"='DV_IDENT_CODES')
158 - filter('DA'=:B1)
160 - access("TYPE"='DV_IDENT_CODES')
161 - filter('EL'=:B1)
163 - access("TYPE"='DV_IDENT_CODES')
164 - filter('ES'=:B1)
166 - access("TYPE"='DV_IDENT_CODES')
167 - filter('ET'=:B1)
169 - access("TYPE"='DV_IDENT_CODES')
170 - filter('FI'=:B1)
172 - access("TYPE"='DV_IDENT_CODES')
173 - filter('FL'=:B1)
175 - access("TYPE"='DV_IDENT_CODES')
176 - filter('FR'=:B1)
178 - access("TYPE"='DV_IDENT_CODES')
179 - filter('HR'=:B1)
181 - access("TYPE"='DV_IDENT_CODES')
182 - filter('HU'=:B1)
184 - access("TYPE"='DV_IDENT_CODES')
185 - filter('IT'=:B1)
187 - access("TYPE"='DV_IDENT_CODES')
188 - filter('IW'=:B1)
190 - access("TYPE"='DV_IDENT_CODES')
191 - filter('JA'=:B1)
193 - access("TYPE"='DV_IDENT_CODES')
194 - filter('LV'=:B1)
196 - access("TYPE"='DV_IDENT_CODES')
197 - filter('MX'=:B1)
199 - access("TYPE"='DV_IDENT_CODES')
200 - filter('NL'=:B1)
202 - access("TYPE"='DV_IDENT_CODES')
203 - filter('NO'=:B1)
205 - access("TYPE"='DV_IDENT_CODES')
206 - filter('NO'=:B1)
208 - access("TYPE"='DV_IDENT_CODES')
209 - filter('PL'=:B1)
211 - access("TYPE"='DV_IDENT_CODES')
212 - filter('PT'=:B1)
214 - access("TYPE"='DV_IDENT_CODES')
215 - filter('RO'=:B1)
217 - access("TYPE"='DV_IDENT_CODES')
218 - filter('RU'=:B1)
220 - access("TYPE"='DV_IDENT_CODES')
221 - filter('SK'=:B1)
223 - access("TYPE"='DV_IDENT_CODES')
224 - filter('SL'=:B1)
226 - access("TYPE"='DV_IDENT_CODES')
227 - filter('SR'=:B1)
229 - access("TYPE"='DV_IDENT_CODES')
230 - filter('SV'=:B1)
232 - access("TYPE"='DV_IDENT_CODES')
233 - filter('TR'=:B1)
235 - access("TYPE"='DV_IDENT_CODES')
236 - filter('US'=:B1)
238 - access("TYPE"='DV_IDENT_CODES')
239 - filter('VI'=:B1)
241 - access("TYPE"='DV_IDENT_CODES')
242 - filter('ZH'=:B1)
244 - access("TYPE"='DV_IDENT_CODES')
248 - access("V3"."ABREV"=DECODE("EN"."REFREPRES",NULL,DECODE(INTERNAL_FUNCTION("EN"."DTIMPAYE_DT"),NULL,'ENCAISSE','IMPAYE'),'REPRESENTE'))
253 - filter('AL'=:B1)
255 - access("TYPE"='STATUT_PAIEMENT')
256 - filter('AN'=:B1)
258 - access("TYPE"='STATUT_PAIEMENT')
259 - filter('AR'=:B1)
261 - access("TYPE"='STATUT_PAIEMENT')
262 - filter('BG'=:B1)
264 - access("TYPE"='STATUT_PAIEMENT')
265 - filter('BR'=:B1)
267 - access("TYPE"='STATUT_PAIEMENT')
268 - filter('CE'=:B1)
270 - access("TYPE"='STATUT_PAIEMENT')
271 - filter('CH'=:B1)
273 - access("TYPE"='STATUT_PAIEMENT')
274 - filter('CS'=:B1)
276 - access("TYPE"='STATUT_PAIEMENT')
277 - filter('DA'=:B1)
279 - access("TYPE"='STATUT_PAIEMENT')
280 - filter('EL'=:B1)
282 - access("TYPE"='STATUT_PAIEMENT')
283 - filter('ES'=:B1)
285 - access("TYPE"='STATUT_PAIEMENT')
286 - filter('ET'=:B1)
288 - access("TYPE"='STATUT_PAIEMENT')
289 - filter('FI'=:B1)
291 - access("TYPE"='STATUT_PAIEMENT')
292 - filter('FL'=:B1)
294 - access("TYPE"='STATUT_PAIEMENT')
295 - filter('FR'=:B1)
297 - access("TYPE"='STATUT_PAIEMENT')
298 - filter('HR'=:B1)
300 - access("TYPE"='STATUT_PAIEMENT')
301 - filter('HU'=:B1)
303 - access("TYPE"='STATUT_PAIEMENT')
304 - filter('IT'=:B1)
306 - access("TYPE"='STATUT_PAIEMENT')
307 - filter('IW'=:B1)
309 - access("TYPE"='STATUT_PAIEMENT')
310 - filter('JA'=:B1)
312 - access("TYPE"='STATUT_PAIEMENT')
313 - filter('LV'=:B1)
315 - access("TYPE"='STATUT_PAIEMENT')
316 - filter('MX'=:B1)
318 - access("TYPE"='STATUT_PAIEMENT')
319 - filter('NL'=:B1)
321 - access("TYPE"='STATUT_PAIEMENT')
322 - filter('NO'=:B1)
324 - access("TYPE"='STATUT_PAIEMENT')
325 - filter('NO'=:B1)
327 - access("TYPE"='STATUT_PAIEMENT')
328 - filter('PL'=:B1)
330 - access("TYPE"='STATUT_PAIEMENT')
331 - filter('PT'=:B1)
333 - access("TYPE"='STATUT_PAIEMENT')
334 - filter('RO'=:B1)
336 - access("TYPE"='STATUT_PAIEMENT')
337 - filter('RU'=:B1)
339 - access("TYPE"='STATUT_PAIEMENT')
340 - filter('SK'=:B1)
342 - access("TYPE"='STATUT_PAIEMENT')
343 - filter('SL'=:B1)
345 - access("TYPE"='STATUT_PAIEMENT')
346 - filter('SR'=:B1)
348 - access("TYPE"='STATUT_PAIEMENT')
349 - filter('SV'=:B1)
351 - access("TYPE"='STATUT_PAIEMENT')
352 - filter('TR'=:B1)
354 - access("TYPE"='STATUT_PAIEMENT')
355 - filter('US'=:B1)
357 - access("TYPE"='STATUT_PAIEMENT')
358 - filter('VI'=:B1)
360 - access("TYPE"='STATUT_PAIEMENT')
361 - filter('ZH'=:B1)
363 - access("TYPE"='STATUT_PAIEMENT')
364 - access("EN"."MOYENPAIMT"="MOY"."VALEUR")
369 - filter('AL'=:B1)
371 - access("TYPE"='MOYENPAIMT')
372 - filter('AN'=:B1)
374 - access("TYPE"='MOYENPAIMT')
375 - filter('AR'=:B1)
377 - access("TYPE"='MOYENPAIMT')
378 - filter('BG'=:B1)
380 - access("TYPE"='MOYENPAIMT')
381 - filter('BR'=:B1)
383 - access("TYPE"='MOYENPAIMT')
384 - filter('CE'=:B1)
386 - access("TYPE"='MOYENPAIMT')
387 - filter('CH'=:B1)
389 - access("TYPE"='MOYENPAIMT')
390 - filter('CS'=:B1)
392 - access("TYPE"='MOYENPAIMT')
393 - filter('DA'=:B1)
395 - access("TYPE"='MOYENPAIMT')
396 - filter('EL'=:B1)
398 - access("TYPE"='MOYENPAIMT')
399 - filter('ES'=:B1)
401 - access("TYPE"='MOYENPAIMT')
402 - filter('ET'=:B1)
404 - access("TYPE"='MOYENPAIMT')
405 - filter('FI'=:B1)
407 - access("TYPE"='MOYENPAIMT')
408 - filter('FL'=:B1)
410 - access("TYPE"='MOYENPAIMT')
411 - filter('FR'=:B1)
413 - access("TYPE"='MOYENPAIMT')
414 - filter('HR'=:B1)
416 - access("TYPE"='MOYENPAIMT')
417 - filter('HU'=:B1)
419 - access("TYPE"='MOYENPAIMT')
420 - filter('IT'=:B1)
422 - access("TYPE"='MOYENPAIMT')
423 - filter('IW'=:B1)
425 - access("TYPE"='MOYENPAIMT')
426 - filter('JA'=:B1)
428 - access("TYPE"='MOYENPAIMT')
429 - filter('LV'=:B1)
431 - access("TYPE"='MOYENPAIMT')
432 - filter('MX'=:B1)
434 - access("TYPE"='MOYENPAIMT')
435 - filter('NL'=:B1)
437 - access("TYPE"='MOYENPAIMT')
438 - filter('NO'=:B1)
440 - access("TYPE"='MOYENPAIMT')
441 - filter('NO'=:B1)
443 - access("TYPE"='MOYENPAIMT')
444 - filter('PL'=:B1)
446 - access("TYPE"='MOYENPAIMT')
447 - filter('PT'=:B1)
449 - access("TYPE"='MOYENPAIMT')
450 - filter('RO'=:B1)
452 - access("TYPE"='MOYENPAIMT')
453 - filter('RU'=:B1)
455 - access("TYPE"='MOYENPAIMT')
456 - filter('SK'=:B1)
458 - access("TYPE"='MOYENPAIMT')
459 - filter('SL'=:B1)
461 - access("TYPE"='MOYENPAIMT')
462 - filter('SR'=:B1)
464 - access("TYPE"='MOYENPAIMT')
465 - filter('SV'=:B1)
467 - access("TYPE"='MOYENPAIMT')
468 - filter('TR'=:B1)
470 - access("TYPE"='MOYENPAIMT')
471 - filter('US'=:B1)
473 - access("TYPE"='MOYENPAIMT')
474 - filter('VI'=:B1)
476 - access("TYPE"='MOYENPAIMT')
477 - filter('ZH'=:B1)
479 - access("TYPE"='MOYENPAIMT')
480 - access("EN"."LIBELLE"="V1"."VALEUR")
485 - filter(NVL(:B1,'FR')='AL')
487 - access("TYPE"='libfds')
488 - filter(NVL(:B1,'FR')='AN')
490 - access("TYPE"='libfds')
491 - filter(NVL(:B1,'FR')='AR')
493 - access("TYPE"='libfds')
494 - filter(NVL(:B1,'FR')='BG')
496 - access("TYPE"='libfds')
497 - filter(NVL(:B1,'FR')='BR')
499 - access("TYPE"='libfds')
500 - filter(NVL(:B1,'FR')='CE')
502 - access("TYPE"='libfds')
503 - filter(NVL(:B1,'FR')='CH')
505 - access("TYPE"='libfds')
506 - filter(NVL(:B1,'FR')='CS')
508 - access("TYPE"='libfds')
509 - filter(NVL(:B1,'FR')='DA')
511 - access("TYPE"='libfds')
512 - filter(NVL(:B1,'FR')='EL')
514 - access("TYPE"='libfds')
515 - filter(NVL(:B1,'FR')='ES')
517 - access("TYPE"='libfds')
518 - filter(NVL(:B1,'FR')='ET')
520 - access("TYPE"='libfds')
521 - filter(NVL(:B1,'FR')='FI')
523 - access("TYPE"='libfds')
524 - filter(NVL(:B1,'FR')='FL')
526 - access("TYPE"='libfds')
527 - filter(NVL(:B1,'FR')='FR')
529 - access("TYPE"='libfds')
530 - filter(NVL(:B1,'FR')='HR')
532 - access("TYPE"='libfds')
533 - filter(NVL(:B1,'FR')='HU')
535 - access("TYPE"='libfds')
536 - filter(NVL(:B1,'FR')='IT')
538 - access("TYPE"='libfds')
539 - filter(NVL(:B1,'FR')='IW')
541 - access("TYPE"='libfds')
542 - filter(NVL(:B1,'FR')='JA')
544 - access("TYPE"='libfds')
545 - filter(NVL(:B1,'FR')='LV')
547 - access("TYPE"='libfds')
548 - filter(NVL(:B1,'FR')='MX')
550 - access("TYPE"='libfds')
551 - filter(NVL(:B1,'FR')='NL')
553 - access("TYPE"='libfds')
554 - filter(NVL(:B1,'FR')='NO')
556 - access("TYPE"='libfds')
557 - filter(NVL(:B1,'FR')='NO')
559 - access("TYPE"='libfds')
560 - filter(NVL(:B1,'FR')='PL')
562 - access("TYPE"='libfds')
563 - filter(NVL(:B1,'FR')='PT')
565 - access("TYPE"='libfds')
566 - filter(NVL(:B1,'FR')='RO')
568 - access("TYPE"='libfds')
569 - filter(NVL(:B1,'FR')='RU')
571 - access("TYPE"='libfds')
572 - filter(NVL(:B1,'FR')='SK')
574 - access("TYPE"='libfds')
575 - filter(NVL(:B1,'FR')='SL')
577 - access("TYPE"='libfds')
578 - filter(NVL(:B1,'FR')='SR')
580 - access("TYPE"='libfds')
581 - filter(NVL(:B1,'FR')='SV')
583 - access("TYPE"='libfds')
584 - filter(NVL(:B1,'FR')='TR')
586 - access("TYPE"='libfds')
587 - filter(NVL(:B1,'FR')='US')
589 - access("TYPE"='libfds')
590 - filter(NVL(:B1,'FR')='VI')
592 - access("TYPE"='libfds')
593 - filter(NVL(:B1,'FR')='ZH')
595 - access("TYPE"='libfds')
598 - access("ACL"."REFINDIVIDU"="CL"."REFINDIVIDU")
603 - access("D"."RANGMT"="GP"."REFPERSO")
609 - access("TNMP"."BALANCE_DCPT"<0)
611 - access("VEN"."REFDOSS"="TNMP"."REFDOSS" AND "VEN"."REFENCAISS"="TNMP"."REFELEM")
612 - filter("T"."REFDOSS"="VEN"."REFDOSS")
613 - access("T"."REFELEM"="VEN"."REFENCAISS")
       filter(("T"."TYPEELEM"='en' OR "T"."TYPEELEM"='vd'))
614 - access("T"."REFDOSS"="D"."REFDOSS")
616 - access("TCL"."REFDOSS"="D"."REFDOSS" AND "TCL"."REFTYPE"='CL')
617 - access("TCL"."REFINDIVIDU"="CL"."REFINDIVIDU")
619 - access("T"."REFELEM"="EN"."REFENCAISS")
620 - filter((INTERNAL_FUNCTION("EN"."TYPENCAISS") AND "EN"."TRAITE"='2'))
622 - access("EN"."REFPAYEUR"="I"."REFINDIVIDU")
623 - filter(("NC"."REFER" IS NOT NULL AND "NC"."REFER"="EN"."REFENCAISS"))
624 - access("NC"."COMPOSTAGE"="EN"."LIEUPAIMT")
626 - access("EN"."LIEUPAIMT"="NC"."COMPOSTAGE")
627 - filter("CRM"."LOGIN" LIKE :B2)
628 - access("CRM"."REFPERSO"=)
631 - filter(:B1=:B2)
635 - access("CPT"."REFDOSS"=:B1)
636 - access("DECO"."REFDOSS"="CPT"."REFLOT")
637 - access("CTR"."REFDOSS"="DECO"."REFLOT")
640 - filter("DCPT"."CATEGDOSS" LIKE 'DECOMPTE%')
641 - access("DCPT"."REFDOSS"=:B1)
643 - access("CTR"."REFDOSS"="DCPT"."REFLOT")
644 - filter("CTR"."CATEGDOSS" LIKE 'CONTRAT%')
645 - access("CTR"."REFDOSS"=:B1)
646 - filter("VEN"."REFDOSS"="BAL"."REFDOSS")
647 - access("EN"."REFENCAISS"="BAL"."REFELEM")

*/
/********************************New Metrics***************************************/

/********************************Index statistics**********************************/

/********************************Other SQLs****************************************/          
/*

*/ 
/********************************Other SQLs****************************************/              
