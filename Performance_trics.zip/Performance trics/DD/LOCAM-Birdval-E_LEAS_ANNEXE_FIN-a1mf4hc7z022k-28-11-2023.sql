/********************************************************************************
*********       E-mail subject: LOCAMDEV-22490
*********             Instance: Birdval
*********          Description: 
Problem:
Slowness in accessing screen e_leas_annexe_fin on Birdval.

Analysis:
The top SQL for user imx in module E_LEAS_ANNEXE_FIN on 28/11/2023 at 15:00 PM on Birdval was a1mf4hc7z022k. The problem was missing index on column REQ_PREST_ID in table T_CALC_PREST_INSTAL.
Because of the missing index, instead of accessing table T_CALC_PREST_INSTAL through column REQ_PREST_ID and joining it with table T_PREST_CALC_RULES, 
Oracle makes full scan of table T_PREST_CALC_RULES and then make MERGE JOIN CARTESIAN with table T_CALC_PREST_INSTAL, which is not optimal and leads to bad execution plan.

Suggestion:
Please create index on column REQ_PREST_ID on table T_CALC_PREST_INSTAL.

*********               SQL_ID: a1mf4hc7z022k
*********      Program/Package: screen e_leas_annexe_fin
*********              Request: Desislav Donev
*********               Author: Dimitar Dimitrov
********* Received e-mail date: 28/11/2023
*********      Resolution date: 28/11/2023
*********  Trace old file here: \\epox\specifs\performance\tmp\
*********  Trace new file here:
***********************************************************************************/

/********************************OLD SQL*******************************************/
var B6 VARCHAR2(32);
exec :B6 := 'A7049818';
var B5 NUMBER;
exec :B5 := 80582336;
var B4 NUMBER;
exec :B4 := 1;
var B3 NUMBER;
exec :B3 := 1;
var B2 VARCHAR2(32);
exec :B2 := '2311280026';
var B1 VARCHAR2(32);
exec :B1 := '2023-11-28';

SELECT NVL( :B4 , 0 ) + NVL( SUM( I.INSTALLMENT_AMT ), 0 ), 
       NVL( :B3 , 0 ) + NVL( SUM( NVL( I.INSTALLMENT_AMT, 0)* ( 1 + LEASE_FUNC_CALC_AMORT.GETVATCURRENTRATE(:B2 , R.VAT_CATEG, to_date(:B1,'yyyy-mm-dd') , NULL)/100)), 0 ) 
  FROM T_CALC_PREST_INSTAL I, 
       T_PREST_CALC_RULES R
 WHERE I.REQ_PREST_ID IN ( SELECT IMX_UN_ID 
                             FROM T_REQ_SERV_INSUR 
                            WHERE REFPIECE_REQST = :B6 
                              AND FIN_REQ_ANNEX_ID = :B5 
                              AND REFER_SERV_INSUR <> 'PREST INTERCAL' 
                              AND TYPE_SERVICE IN ( 'A', 'S' ) ) 
   AND I.PREST_RULE_ID = R.IMX_UN_ID;
/********************************OLD SQL*******************************************/
/********************************OLD Metrics***************************************/
/*

*/
/********************************OLD Metrics***************************************/

MODULE                           CLIENT_ID       SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- --------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
E_LEAS_ANNEXE_FIN                imx                                             606      37572                      2023/11/28 15:01:47  2023/11/28 15:08:29         403                  340 +000000000 00:06:42.036 82%
E_LEAS_ANNEXE_FIN                imx                                             899       6347                      2023/11/28 15:07:01  2023/11/28 15:08:29          89                  337 +000000000 00:01:28.015 18%

MODULE                           CLIENT_ID       SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- --------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
E_LEAS_ANNEXE_FIN                imx             a1mf4hc7z022k 3398669736        606      37572                      2023/11/28 15:01:53  2023/11/28 15:08:29         396                   11 +000000000 00:06:36.036 80%
E_LEAS_ANNEXE_FIN                imx             a1mf4hc7z022k 3398669736        899       6347                      2023/11/28 15:07:03  2023/11/28 15:08:29          87                    5 +000000000 00:01:26.015 18%

SQL_ID              MODULE               ELAPSED MAX_WAIT        GETS      READS       ROWS   ELAP/EXEC  GETS/EXEC READS/EXEC  ROWS/EXEC       EXEC PLAN_HASH_VALUE
------------------- ----------------- ---------- --------- ---------- ---------- ---------- ----------- ---------- ---------- ---------- ---------- ---------------
a1mf4hc7z022k       PL/SQL Developer         505 98% io       4477501      28569         68        7.43    65845.6     420.13          1         68      3398669736

SQL_ID              SQL_PLAN_HASH_VALUE SQL_PLAN_LINE_ID SQL_PLAN_OPERATION             SQL_PLAN_OPTIONS                   ACTIVE
------------------- ------------------- ---------------- ------------------------------ ------------------------------ ----------
a1mf4hc7z022k                3398669736               10 TABLE ACCESS                   BY INDEX ROWID                        388
a1mf4hc7z022k                3398669736                8 TABLE ACCESS                   FULL                                   57
a1mf4hc7z022k                3398669736                9 INDEX                          RANGE SCAN                             38

Plan hash value: 3398669736
--------------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                               | Name                   | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  |
--------------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                        |                        |      1 |        |   307 (100)|      1 |00:00:10.40 |     634K|   7414 |
|   1 |  SORT AGGREGATE                         |                        |      1 |      1 |            |      1 |00:00:10.40 |     634K|   7414 |
|   2 |   NESTED LOOPS                          |                        |      1 |      1 |   307   (1)|      0 |00:00:10.40 |     634K|   7414 |
|   3 |    NESTED LOOPS                         |                        |      1 |    264 |   307   (1)|   2728K|00:00:03.37 |     514K|   2669 |
|   4 |     MERGE JOIN CARTESIAN                |                        |      1 |     12 |   306   (1)|    525K|00:00:00.50 |    1386 |   1381 |
|*  5 |      TABLE ACCESS BY INDEX ROWID BATCHED| T_REQ_SERV_INSUR       |      1 |      1 |     1   (0)|      8 |00:00:00.01 |       4 |      2 |
|*  6 |       INDEX RANGE SCAN                  | IDX_REQ_SERV_INS_ANNEX |      1 |      2 |     1   (0)|      8 |00:00:00.01 |       3 |      2 |
|   7 |      BUFFER SORT                        |                        |      8 |  65636 |   305   (1)|    525K|00:00:00.46 |    1382 |   1379 |
|   8 |       TABLE ACCESS FULL                 | T_PREST_CALC_RULES     |      1 |  65636 |   305   (1)|  65732 |00:00:00.40 |    1382 |   1379 |
|*  9 |     INDEX RANGE SCAN                    | IX_PREST_TAMO_RULE     |    525K|     22 |     1   (0)|   2728K|00:00:02.58 |     513K|   1288 |
|* 10 |    TABLE ACCESS BY INDEX ROWID          | T_CALC_PREST_INSTAL    |   2728K|      1 |     1   (0)|      0 |00:00:06.68 |     119K|   4745 |
--------------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   5 - filter(("REFPIECE_REQST"=:B6 AND "REFER_SERV_INSUR"<>'PREST INTERCAL' AND INTERNAL_FUNCTION("TYPE_SERVICE")))
   6 - access("FIN_REQ_ANNEX_ID"=:B5)
   9 - access("I"."PREST_RULE_ID"="R"."IMX_UN_ID")
  10 - filter("I"."REQ_PREST_ID"="IMX_UN_ID")
/********************************New SQL*******************************************/
-- No change in the SQL text.
/********************************New SQL*******************************************/
/********************************New Metrics***************************************/
/*
Plan hash value: 2227918364
--------------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                               | Name                   | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  |
--------------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                        |                        |      1 |        |     3 (100)|      1 |00:00:00.01 |      17 |      2 |
|   1 |  SORT AGGREGATE                         |                        |      1 |      1 |            |      1 |00:00:00.01 |      17 |      2 |
|   2 |   NESTED LOOPS                          |                        |      1 |      1 |     3   (0)|      0 |00:00:00.01 |      17 |      2 |
|   3 |    NESTED LOOPS                         |                        |      1 |      1 |     3   (0)|      0 |00:00:00.01 |      17 |      2 |
|   4 |     NESTED LOOPS                        |                        |      1 |      1 |     2   (0)|      0 |00:00:00.01 |      17 |      2 |
|*  5 |      TABLE ACCESS BY INDEX ROWID BATCHED| T_REQ_SERV_INSUR       |      1 |      1 |     1   (0)|      8 |00:00:00.01 |       4 |      2 |
|*  6 |       INDEX RANGE SCAN                  | IDX_REQ_SERV_INS_ANNEX |      1 |      2 |     1   (0)|      8 |00:00:00.01 |       3 |      2 |
|   7 |      TABLE ACCESS BY INDEX ROWID BATCHED| T_CALC_PREST_INSTAL    |      8 |     23 |     1   (0)|      0 |00:00:00.01 |      13 |      0 |
|*  8 |       INDEX RANGE SCAN                  | TEST_DD_REQ_PREST_ID   |      8 |     23 |     1   (0)|      0 |00:00:00.01 |      13 |      0 |
|*  9 |     INDEX UNIQUE SCAN                   | PK_T_PREST_CALC_RULES  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|  10 |    TABLE ACCESS BY INDEX ROWID          | T_PREST_CALC_RULES     |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
--------------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   5 - filter(("REFPIECE_REQST"=:B6 AND "REFER_SERV_INSUR"<>'PREST INTERCAL' AND INTERNAL_FUNCTION("TYPE_SERVICE")))
   6 - access("FIN_REQ_ANNEX_ID"=:B5)
   8 - access("I"."REQ_PREST_ID"="IMX_UN_ID")
   9 - access("I"."PREST_RULE_ID"="R"."IMX_UN_ID")
*/
/********************************New Metrics***************************************/

/********************************Index statistics**********************************/

/********************************Other SQLs****************************************/          
/*

*/ 
/********************************Other SQLs****************************************/              
