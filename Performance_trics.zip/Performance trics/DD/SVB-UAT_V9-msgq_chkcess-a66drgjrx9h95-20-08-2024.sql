/********************************************************************************
*********       E-mail subject: SVBWEB-6054
*********             Instance: UAT V9
*********          Description: 
Problem:
Call chkcess@A71AZ83B is taking too much time on UAT V9.

Analysis:
After the analyze, we found that the TOP SQL a66drgjrx9h95 is responsibe for 100% of the time.
The problem in it is that it is not accessing the tables in the correct order from performance poin of view. Instead of start the execution from table g_piece inv, it 
starts from table g_db_ptf_item gdb with full scan and then goes to the other tables. We added hint to force the CBO to start from g_piece inv.

Suggestion:
Please add hint as it is shown in the New SQLs ection below.

*********               SQL_ID: a66drgjrx9h95
*********      Program/Package: 
*********              Request: Eduardo Jiménez 
*********               Author: Dimitar Dimitrov
********* Received e-mail date: 20/08/2024
*********      Resolution date: 20/08/2024
*********  Trace old file here: \\epox\specifs\performance\tmp\
*********  Trace new file here:
***********************************************************************************/

/********************************OLD SQL*******************************************/

var b0 varchar2(32);
exec :b0 := 'A71ALTNG';

update g_db_ptf_item gdb
   SET fg_pay_method_determ_by_stst = 'O'
 WHERE EXISTS ( SELECT 1
                  FROM g_piece inv, 
                       g_elemfi inv_e
                 WHERE inv.typpiece = 'FACTURE'
                   AND inv.gpidepot = :b0
                   AND dt02 IS NOT NULL
                   AND str_5_1 IS NULL
                   AND inv.gpiheure = inv_e.refelem
                   AND inv_e.refelem = gdb.refelem );
/********************************OLD SQL*******************************************/
/********************************OLD Metrics***************************************/
/*
MODULE                           PROGRAM                                            CLIENT_ID       SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- -------------------------------------------------- --------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
msgq_chkcess                     msg_q02                                                            a66drgjrx9h95 2637531014       1322      35679 db file sequential r 2024/08/19 10:46:53  2024/08/19 11:57:59         367                    1 +000000000 01:11:05.874 86%
msgq_chkcess                     msg_q02                                                            a66drgjrx9h95 2637531014       1322      35679 ON CPU               2024/08/19 10:47:43  2024/08/19 11:56:19          57                    1 +000000000 01:08:35.744 13%
msgq_chkcess                     msg_q02                                                            a66drgjrx9h95 2637531014       1322      35679 gc cr grant 2-way    2024/08/19 10:56:53  2024/08/19 11:31:28           3                    1 +000000000 00:34:34.915 1%
msgq_calfidec                    msg_q02                                                            3rfkupbgf6m9a          0       1322      35679 db file sequential r 2024/08/19 11:58:09  2024/08/19 11:58:09           1                    1 +000000000 00:00:00.000 0%

 
MODULE                           PROGRAM                                            CLIENT_ID       SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- -------------------------------------------------- --------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
msgq_chkcess                     msg_q02                                                            a66drgjrx9h95 2637531014       1322      35679                      2024/08/19 10:46:53  2024/08/19 11:57:59         427                    1 +000000000 01:11:05.874 100%
msgq_calfidec                    msg_q02                                                            3rfkupbgf6m9a          0       1322      35679 db file sequential r 2024/08/19 11:58:09  2024/08/19 11:58:09           1                    1 +000000000 00:00:00.000 0%



INSTANCE_NUMBER SQL_ID            ELAPSED MAX_WAIT_ON     PC_OF  WAIT_TIME            GETS      READS       ROWS  ELAP/EXEC       GETS/EXEC READS/EXEC  ROWS/EXEC       EXEC PLAN_HASH_VALUE
--------------- ------------- ----------- --------------- ----- ---------- --------------- ---------- ---------- ---------- --------------- ---------- ---------- ---------- ---------------
              1 a66drgjrx9h95        5964 IO              78%   6489.93991       314425846   14889143          0    2981.84       157212923  7444571.5          0          2  2637531014


Plan hash value: 2637531014
----------------------------------------------------------------------------------------------------------
| Id  | Operation                              | Name            | Rows  | Bytes | Cost (%CPU)| Time     |
----------------------------------------------------------------------------------------------------------
|   0 | UPDATE STATEMENT                       |                 |       |       |    71M(100)|          |
|   1 |  UPDATE                                | G_DB_PTF_ITEM   |       |       |            |          |
|*  2 |   FILTER                               |                 |       |       |            |          |
|   3 |    TABLE ACCESS FULL                   | G_DB_PTF_ITEM   |    23M|   703M| 15372  (19)| 00:00:01 |
|   4 |    NESTED LOOPS                        |                 |     1 |    44 |     3   (0)| 00:00:01 |
|*  5 |     INDEX UNIQUE SCAN                  | EFI_REFELEM     |     1 |     9 |     1   (0)| 00:00:01 |
|*  6 |     TABLE ACCESS BY INDEX ROWID BATCHED| G_PIECE         |     1 |    35 |     2   (0)| 00:00:01 |
|*  7 |      INDEX RANGE SCAN                  | GP_GRTYPE_MT_DT |     1 |       |     2   (0)| 00:00:01 |
----------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   2 - filter( IS NOT NULL)
   5 - access("INV_E"."REFELEM"=:B1)
   6 - filter(("STR_5_1" IS NULL AND "INV"."GPIDEPOT"=:B0 AND "DT02" IS NOT NULL))
   7 - access("INV"."TYPPIECE"='FACTURE' AND "INV"."GPIHEURE"=:B1)

*/
/********************************OLD Metrics***************************************/

/********************************New SQL*******************************************/

var b0 varchar2(32);
exec :b0 := 'A71ALTNG';

update g_db_ptf_item gdb
   SET fg_pay_method_determ_by_stst = 'O'
 WHERE EXISTS ( SELECT /*+ unnest no_push_pred */
                       1
                  FROM g_piece inv, 
                       g_elemfi inv_e
                 WHERE inv.typpiece = 'FACTURE'
                   AND inv.gpidepot = :b0
                   AND dt02 IS NOT NULL
                   AND str_5_1 IS NULL
                   AND inv.gpiheure = inv_e.refelem
                   AND inv_e.refelem = gdb.refelem );
/********************************New SQL*******************************************/
/********************************New Metrics***************************************/
/*
Plan hash value: 3123943400
-------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                 | Name             | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers |
-------------------------------------------------------------------------------------------------------------------------------------
|   0 | UPDATE STATEMENT                          |                  |      1 |        |    39 (100)|      0 |00:00:00.01 |      66 |
|   1 |  UPDATE                                   | G_DB_PTF_ITEM    |      1 |        |            |      0 |00:00:00.01 |      66 |
|   2 |   NESTED LOOPS                            |                  |      1 |      1 |    39   (3)|      0 |00:00:00.01 |      66 |
|   3 |    NESTED LOOPS                           |                  |      1 |      1 |    39   (3)|      0 |00:00:00.01 |      66 |
|   4 |     VIEW                                  | VW_SQ_1          |      1 |      1 |    37   (0)|      0 |00:00:00.01 |      66 |
|   5 |      SORT UNIQUE                          |                  |      1 |      1 |            |      0 |00:00:00.01 |      66 |
|   6 |       NESTED LOOPS SEMI                   |                  |      1 |      1 |    37   (0)|      0 |00:00:00.01 |      66 |
|*  7 |        TABLE ACCESS BY INDEX ROWID BATCHED| G_PIECE          |      1 |     18 |    28   (0)|      0 |00:00:00.01 |      66 |
|*  8 |         INDEX RANGE SCAN                  | GP_GPIDEP        |      1 |    138 |     2   (0)|     27 |00:00:00.01 |       4 |
|*  9 |        INDEX UNIQUE SCAN                  | EFI_REFELEM      |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 10 |     INDEX UNIQUE SCAN                     | PK_G_DB_PTF_ITEM |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|  11 |    TABLE ACCESS BY INDEX ROWID            | G_DB_PTF_ITEM    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
-------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   7 - filter(("STR_5_1" IS NULL AND "DT02" IS NOT NULL AND "INV"."GPIHEURE" IS NOT NULL AND "INV"."TYPPIECE"='FACTURE'))
   8 - access("INV"."GPIDEPOT"=:B0)
   9 - access("INV"."GPIHEURE"="INV_E"."REFELEM")
  10 - access("ITEM_1"="GDB"."REFELEM")
*/
/********************************New Metrics***************************************/

/********************************Index statistics**********************************/

/********************************Other SQLs****************************************/          
/*

*/ 
/********************************Other SQLs****************************************/              
