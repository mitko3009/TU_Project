=============================================================================================================================
####### Verifying that the Oracle TNS listener is running ##########
Before you install Enterprise Reporter, ensure that the Oracle TNS listener is running.

To verify that the Oracle TNS listener is running

1. Log on to the Enterprise Reporter Management Server.

2. In an operating system console, change to the following directory:

Solaris:     Oracle_HOME/bin

Windows:     Oracle_HOME\bin

3.  To verify if the TNS listener is running, type the following command:

  tnsping service_name

where service_name is the service name of the database instance - for example, ccer

4.  After the command runs, do the following based on the message that returned after you ran tnsping:

TNS-03505: Failed to resolve name:
The tnsping utility cannot resolve the service name.
Do the following:

 - On the Management Server, verify that the service name entries are correct in the SQLNET.ora and TNSNAMES.ora files. These files reside in the following location:

   Solaris: Oracle_HOME/network/admin

   Windows: Oracle_HOME\network\admin

 - Repeat step 3.

TNS-12541: TNS: no listener
Indicates that the TNS listener service is not running.
Do the following:

 - Log on to the host where the Oracle database resides.

 - Change to the following directory:

  Solaris: Oracle_HOME/bin

  Windows: Oracle_HOME\bin

 - To start the listener service, type the following command:

  Solaris: lsnrctl START

  Windows: LSNRCTL.EXE start

 - Repeat step 3 to verify that the TNS listener is running.

OK (# msec)
