############################################################
######### LOGISTA рутинки ##########

1. с WINSCP от Advinced button на дадения сървър качвам скриптовете в моята хоум директория /root/home/dxcbella

2. Като юзър ORACLE директорията ,в която се слагат скриптовете преди екзекютването им cd /home/oracle/intervenciones  създавам директория с номера на чейнджа и датата: 20191118_E-C01836586

3. След като съм си прехвърлила скриптовете с SCP като root влизам в моя хоум cd /root/home/dxcbella и правя прехвърлянето към създадената от мен директовия за екзекютването:

[root@ra005 dxcbella]# mv 1516.004.06-001-MAIN-TBL-TIPOS_PUNTOS_INTERES.sql /home/oracle/intervenciones/20191127_E-C01840446

4. Като ги преместя отива в /home/oracle/intervenciones и влизам в създадената дир за където са скриптовете 20191127_E-C01840446 за да им променя пърмишъните

[root@ra005 20191127_E-C01840446]# chown oracle:oinstall 1516.004.06-001-MAIN-TBL-TIPOS_PUNTOS_INTERES.sql

5. След това su - oracle
. oraenv
влизам в директорията да съм там ,където са скриптовете
влизам в базата и изпъпнявам 
@script   АКО Е В ТОЗИ СЛУЧАЙ


#### В тази директория /home/oracle/intervenciones/PUBP  се намира един скрипт  llamasql.ksh ,който се редактира в този случай ,като има един скрипт,който извиква много други



#######
ra005(PUBP):/home/oracle/intervenciones > cd PUBP/
ra005(PUBP):/home/oracle/intervenciones/PUBP > ll
total 60
drwxr-xr-x  7 oracle oinstall  4096 Nov 19 16:23 .
drwxr-xr-x 18 oracle oinstall  4096 Nov 19 16:19 ..
drwxr-xr-x  2 oracle oinstall  4096 Feb 20  2019 20190219_E-C01731296
drwxr-xr-x  2 oracle oinstall  4096 Feb 21  2019 20190221_E-C01732339
drwxr-xr-x  2 oracle oinstall  4096 Mar  5  2019 20190306_E-C01737479
drwxr-xr-x  2 oracle oinstall  4096 Mar 20  2019 20190320_E-C01742841
drwxr-xr-x  2 oracle oinstall  4096 Oct 30 15:21 E-C01829843
-rwxr-xr-x  1 oracle oinstall   539 Nov 19 16:23 llamasql.ksh
-rw-------  1 oracle oinstall 27851 Oct 30 15:21 nohup.out
ra005(PUBP):/home/oracle/intervenciones/PUBP > vi llamasql.ksh

llamasql.ksh  -  Вътре редактираме пътя со скриптовете  /home/oracle/intervenciones/20191127_E-C01840446 
и по-надолу слагаме главния скрипт,който трябва да извика другите
и се изпълнява така 

ra005(PUBP):/home/oracle > cd /home/oracle/intervenciones/PUBP




НО ПРЕДИ ДА ЕКЗЕКЮТНЕМ КАКВОТО И ДА БИЛО ПРОВЕРЯВАМЕ:

### INVALID objects

COLUMN object_name FORMAT A30
SELECT owner,object_type,object_name,status
FROM   dba_objects
WHERE  status = 'INVALID'
ORDER BY owner, object_type, object_name;



EXEC ALETSYS.UTL_RECOMPILAR.RECOMP_SERIAL();


Alter package TESALO.PCK_TESALO compile body; 


select OWNER, OBJECT_NAME, OBJECT_TYPE, STATUS
FROM ALL_OBJECTS
WHERE OWNER<>'OUTLN' AND OWNER<>'SYS' AND OWNER<>'PUBLIC' AND OWNER<>'SYSTEM'
AND OWNER<>'WMSYS' AND OWNER<>'PERFSTAT' AND      
STATUS='INVALID'
ORDER BY OWNER, OBJECT_TYPE;



##### ТАКА ИЗПЪЛНЯВАМЕ СКРИПРА,КОЙТО ТРЯБВА ДА СЕ ПУСНЕ СЪС СЕТНАТА ВЪПРОСНАТА СХЕМА, НО ПРЕДИ ДА ВЛЯЗА В БАЗАТА ТРЯБВА ДА СЪМ В ДИРЕКТОРИЯТА НА СКРИПТА:
ra005(PUBP):/home/oracle/intervenciones/20191127_E-C01840446 > sqlplus / as sysdba
SQL> ALTER SESSION SET CURRENT_SCHEMA=SAFE_MAIN;
SQL> @MASTER-MAIN-001_1114.sql
SQL> commit;

Commit complete.


######
ra005(PUBP):/home/oracle/intervenciones > cd PUBP
ra005(PUBP):/home/oracle/intervenciones/PUBP > ls -la
ra005(PUBP):/home/oracle/intervenciones/PUBP > ./llamasql.ksh



###### СЛЕД ТОВА ПРОВЕРЯВАМЕ ОТНОВО ЗА INVALID OBJECTS И ИЗПЪЛНЯВАМ СКРИПТА,КОЙТО ГИ ПОПРАВЯ UTLRP
### INVALID objects

COLUMN object_name FORMAT A30
SELECT owner,object_type,object_name,status
FROM   dba_objects
WHERE  status = 'INVALID'
ORDER BY owner, object_type, object_name;

####
@?/rdbms/admin/utlrp.sql

### АКО ИСКА НЯКОЙ ЛОГОВЕТЕ ОТ СКРИПТОВЕТЕ МОГА ДА ГИ СВАЛЯ С WINSCP,А ТЕ СА В ДИРЕКТОРИАТА,КОЯТО НАПРАВИХ СЪС СКРИПТОВЕТЕ

ra005(PUBP):/home/oracle/intervenciones/20191127_E-C01840446 > ls -lart
-rw-r--r--  1 oracle oinstall  393 Nov 27 15:32 SAFE_EMPRESA47.log
-rw-r--r--  1 oracle oinstall  393 Nov 27 15:32 SAFE_EMPRESA45.log
-rw-r--r--  1 oracle oinstall  393 Nov 27 15:32 SAFE_EMPRESA36.log
-rw-r--r--  1 oracle oinstall  393 Nov 27 15:32 SAFE_EMPRESA33.log
-rw-r--r--  1 oracle oinstall  393 Nov 27 15:32 SAFE_EMPRESA26.log
-rw-r--r--  1 oracle oinstall  393 Nov 27 15:32 SAFE_EMPRESA08.log
-rw-r--r--  1 oracle oinstall  393 Nov 27 15:32 SAFE_EMPRESA07.log
-rw-r--r--  1 oracle oinstall  393 Nov 27 15:32 SAFE_EMPRESA01.log
-rw-r--r--  1 oracle oinstall  393 Nov 27 15:32 SAFE_EMPRESA63.log
-rw-r--r--  1 oracle oinstall  393 Nov 27 15:32 SAFE_EMPRESA50.log
ra005(PUBP):/home/oracle/intervenciones/20191127_E-C01840446 > cat SAFE_EMPRESA47.log
SQL>
SQL> alter session set current_schema=SAFE_MAIN;

Session altered.

SQL>
SQL> @MASTER-EMPRESA-002_1114.sql

Table altered.


Comment created.




///////////////////////////////


SQL> desc dba_users

SQL> select USERNAME,DEFAULT_TABLESPACE from dba_users;

SQL> select USERNAME,DEFAULT_TABLESPACE from dba_users where USERNAME='SAFE_MAIN';

USERNAME                       DEFAULT_TABLESPACE
------------------------------ ------------------------------
SAFE_MAIN                      SAFE_MAIN_P

export NLS_LANG=SPANISH_SPAIN.WE8MSWIN1252


 
EXEC ALETSYS.DBATOOLS.STOPJOBS(0); 
alter trigger ALETSYS.BLOQUEOOPERACIONESDDLQUALITY disable; 

EXEC ALETSYS.DBATOOLS.STARTJOBS;  
alter trigger ALETSYS.BLOQUEOOPERACIONESDDLQUALITY enable;



####
select OWNER, OBJECT_NAME, OBJECT_TYPE, STATUS 
FROM ALL_OBJECTS WHERE OWNER<>'OUTLN' AND 
OWNER<>'SYS' AND OWNER<>'PUBLIC' AND OWNER<>'SYSTEM'AND OWNER<>'WMSYS' AND OWNER<>'PERFSTAT' AND 
STATUS='INVALID' ORDER BY OWNER, OBJECT_TYPE; 


EXEC ALETSYS.UTL_RECOMPILAR.RECOMP_SERIAL();

####
select * from all_indexes where STATUS='UNUSABLE';


///////////

EXEC ALEPSYS.DBATOOLS.STOPJOBS(0);
alter trigger ALEPSYS.BLOQUEOOPERACIONESDDL disable;

EXEC ALEPSYS.DBATOOLS.STARTJOBS;
alter trigger ALEPSYS.BLOQUEOOPERACIONESDDL enable;
 

EXEC ALEPSYS.UTL_RECOMPILAR.RECOMP_SERIAL();


 
 ///////////////////////////////////////////////////////////////
 ///////////////////////////////////////////////////////////////
 ## Find job who block something ##
 [‎3/‎25/‎2020 11:09 AM]  Ushagelov, Spas:  
чат пат има един джоб , който върви и блокира разни неща по имплементацията на тоя чейндж
 
[‎3/‎25/‎2020 11:09 AM]  Ushagelov, Spas:  
можеш да видиш с : 
 
[‎3/‎25/‎2020 11:09 AM]  Ushagelov, Spas:  
set linesize 400
col USERNAME for a10
col LOGON_TIME for a20
col IS_BLOCKING for a15
col PROGRAM for a25
select
l1.INST_ID, l1.sid, a.serial#, a.USERNAME, a.PROGRAM, TO_CHAR(a.logon_time, 'MM/DD/YY HH24:MI:SS') as logon_time, 'IS_BLOCKING' as IS_BLOCKING,
l2.INST_ID, l2.sid, b.serial#, b.USERNAME, b.PROGRAM, TO_CHAR(b.logon_time, 'MM/DD/YY HH24:MI:SS') as logon_time
from gv$lock l1, gv$lock l2, gv$session a, gv$session b
where l1.id1=l2.id1 and l1.id2=l2.id2 and a.SID=l1.sid and b.SID=l2.sid
and l1.inst_id=l2.inst_id and l2.inst_id=a.inst_id and a.inst_id=b.inst_id and l1.sid! = l2.sid
and l1.block =1 and l2.request > 0 order by a.LOGON_TIME; 
 
[‎3/‎25/‎2020 11:09 AM]  Ushagelov, Spas:  
или с  :
 
[‎3/‎25/‎2020 11:09 AM]  Ushagelov, Spas:  
set lines 240
set pages 200
alter session set nls_date_format='MM/DD/YYYY HH24:MI:SS';
col event for a50
col P1TEXT for a10
col P2TEXT for a10
col P3TEXT for a10
col WAIT_CLASS for a10
col SID for 99999
col machine for a30
col USERNAME for a20
select username,P1text,p1,p2text,p2,machine,sql_Id ,status, event, wait_class,sid,wait_time,SQL_EXEC_START from gv$session where WAIT_CLASS <> 'Idle'  order by SQL_EXEC_START;
	 
 
[‎3/‎25/‎2020 11:09 AM]  Ushagelov, Spas:  
видях му сид-а и го убих 

////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////

ito-do-bulgaria-webmiddleware-net-ii-rst@dxc.com  -  web and middleware coleagues
HPLogista_CM@dxc.com
rafael.gonzalez@logista.es
rvilla@logista.es
jdiego@logista.es
Explotacion.informatica@integra2.es
ihernandez@integra2.es
tpradas@integra2.es
i2development@integra2.es


Dear customer,

Please find below the status of Change:  Standard Change - PSS-ALPHIL-002 - DB Script Execution on PUBT DATE: 30/01/2020 AT 10:30 H E-C01861225

Planned start date:  29/01/2020  10:00   BG Local time
Planned end date:   29/01/2020   11:00   BG Local time

Status: Started



Hello ,

We are starting with the implementation of the change


======================================

Hello,

Maintenance tasks were disabled from DB side.

===============================================

an error occurred after executing the following script
