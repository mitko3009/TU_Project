/********************************************************************************
*********       E-mail subject: SVBDEV-7643
*********             Instance: QA2 V9
*********          Description: 
Problem:
SQL dyaw4yun0z7xv was the TOP SQL in imxbatch_LimitRevision1.

Analysis:
I checked SQL dyaw4yun0z7xv on QA2 V9 and the problem of this query is that it starts it execution from G_PIECE PL selecting around 1.4 milion rows 
and than filter them by many conditions, where the rows that match the conditions became 0 and the query finishes.
I executed it on PROD and the execution plan starts from G_PIECE PFACTC, from where it finds around 2600 rows for condition PFACTC.typpiece = 'FACTORINGCRITERIA'.
I used hints to force oracle to start the execution from PFACTC.typpiece = 'FACTORINGCRITERIA' on QA2 and it works fast as on PROD. This optimization 
is the best that we can propose for now, but if we face a moment where we found a lot of rows for PFACTC.typpiece = 'FACTORINGCRITERIA' 
we can face again performance problem. Please add hints as it is show in the New SQL section blow and if again there is performance problems, we 
will investigate again.

Suggestion:
Please add hints as it is shown in the New SQL section below.

*********               SQL_ID: dyaw4yun0z7xv 
*********      Program/Package: 
*********              Request: Georgi Kudinev
*********               Author: Dimitar Dimitrov
********* Received e-mail date: 27/05/2024
*********      Resolution date: 27/05/2024
*********  Trace old file here: \\epox\specifs\performance\tmp\
*********  Trace new file here:
***********************************************************************************/

/********************************OLD SQL*******************************************/

SELECT CONTRAT.reffactor /* automatically injected */, 
       PL.refpiece, /*PL.gpiadr3, PL.gpidepot, PL.gpityptrib, PFACTC.mt12,*/ 
       PL.mt02, 
       PL.code, --convert from factor currency to limitCurrency                                                                         
       CASE 
        WHEN PL.code != nvl(ftr_fin_factor.getCurrency ( nvl(PL.gpityptrib,'NA')), PL.code)                                
         THEN (SELECT NVL(CH_TAUX.Conv_Orig_Dest_Tx(TO_CHAR(to_date(2460445,'j'),'j'),                                                             
      /*LimitValue*/  FTR_MATCH.getMaxPortfolio(PL.gpidepot,PL.gpiadr3, PL.gpityptrib,1,TO_CHAR(to_date(2460445,'j')-PFACTC.mt12,'j')),  
      /*FactCurrency*/NVL(ftr_fin_factor.getCurrency ( nvl(PL.gpityptrib,'NA')), PL.code),                                  
      /*ApprCurrency*/PL.code,                                                                                              
                      'MER'),0)
                 FROM dual)                                                                                    
         ELSE (SELECT NVL(FTR_MATCH.getMaxPortfolio(PL.gpidepot,PL.gpiadr3, PL.gpityptrib,1,TO_CHAR(to_date(2460445,'j')-PFACTC.mt12,'j')) ,0)                                                                                                       
                 FROM dual)                                                                                                 
       END CASE,                                                                                                   
       PFACTC.mt57                                                                                                 
  FROM g_piece PL, 
       g_dossier CONTRAT, 
       g_piece PFACTC, 
       g_piece Compte                                                
 WHERE PL.typpiece = 'REQUEST_LIMITE'                                                                               
     -- active limit                                                                                                   
   AND PL.GPIROLE IN ( 'DC', 'DT' )                                                                                  
   AND PL.mt02 > 0                                                                                                   
   AND PL.FG05 = 'O'                                                                                                 
   AND PL.TYPEDOC = 'C'                                                                                              
   AND PL.GPIDTDEB <= TO_CHAR(to_date(2460445,'j'),'j')                                                       
   AND ( nvl( PL.GPIDATE1, PL.GPIDTFIN ) IS NULL                                                                     
      OR nvl( PL.GPIDATE1, PL.GPIDTFIN ) >= TO_CHAR(to_date(2460445,'j'),'j'))                             
   AND PL.gpiheure = CONTRAT.ancrefdoss                                                                              
   AND CONTRAT.refdoss = PFACTC.refdoss                                                                              
    /* reffactor condition */
   AND CONTRAT.reffactor IN ('A60029KT') 
   AND PFACTC.typpiece = 'FACTORINGCRITERIA'                                                                         
     -- Automatic cancellation period is filled                                                                        
   AND PFACTC.mt12 IS NOT NULL                                                                                       
     -- is not flagged as no revision for underuse                                                                     
   AND nvl(PFACTC.fg40, 'N') = 'N'                                                                                   
     -- Revision Rounding Amount                                                                                       
   AND PFACTC.mt57 IS NOT NULL                                                                                       
   AND PL.refdoss = Compte.refdoss                                                                                   
   AND Compte.typpiece = 'COMPTE'                                                                                    
   AND nvl(Compte.fg41, 'N') = 'N';
/********************************OLD SQL*******************************************/
/********************************OLD Metrics***************************************/
/*

MODULE                           SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL            PERC
-------------------------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
imxbatch_LimitRevision1          dyaw4yun0z7xv 3712322698        259      64393 db file sequential r 2024/05/13 12:11:35  2024/05/13 12:44:51         198                    1 +000000000 00:33:16.306 31%
imxbatch_ClientFunding                                           914      61604 db file sequential r 2024/05/13 12:00:12  2024/05/13 12:15:55          73               112444 +000000000 00:15:42.896 11%
imxbatch_Consolidation           c19tjju2br3mk 1135474889                       db file sequential r 2024/05/13 12:11:35  2024/05/13 12:13:05          73                    8 +000000000 00:01:30.002 11%


MODULE                           SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL            PERC
-------------------------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
imxbatch_LimitRevision1          dyaw4yun0z7xv 3712322698        259      64393                      2024/05/13 12:11:35  2024/05/13 12:44:51         200                    1 +000000000 00:33:16.306 100%


INSTANCE_NUMBER SQL_ID            ELAPSED MAX_WAIT_ON     PC_OF  WAIT_TIME            GETS      READS       ROWS  ELAP/EXEC       GETS/EXEC READS/EXEC  ROWS/EXEC       EXEC PLAN_HASH_VALUE
--------------- ------------- ----------- --------------- ----- ---------- --------------- ---------- ---------- ---------- --------------- ---------- ---------- ---------- ---------------
              1 dyaw4yun0z7xv        2014 IO              97%   2052.28305          664863     648050          0    2014.21          664863     648050          0          1  3712322698

SQL_ID        SQL_PLAN_HASH_VALUE SQL_PLAN_LINE_ID SQL_PLAN_OPERATION             SQL_PLAN_OPTIONS                   ACTIVE
------------- ------------------- ---------------- ------------------------------ ------------------------------ ----------
dyaw4yun0z7xv          3712322698                8 TABLE ACCESS                   BY INDEX ROWID BATCHED                199
dyaw4yun0z7xv          3712322698                9 INDEX                          RANGE SCAN                              1


Plan hash value: 3712322698
---------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                | Name             | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  |
---------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                         |                  |      1 |        |    14 (100)|      0 |00:06:04.72 |     664K|    640K|
|   1 |  FAST DUAL                               |                  |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|   2 |   FAST DUAL                              |                  |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|   3 |  NESTED LOOPS                            |                  |      1 |      1 |    10  (10)|      0 |00:06:04.72 |     664K|    640K|
|   4 |   NESTED LOOPS                           |                  |      1 |      1 |    10  (10)|      0 |00:06:04.72 |     664K|    640K|
|   5 |    NESTED LOOPS                          |                  |      1 |      1 |     8  (13)|      0 |00:06:04.72 |     664K|    640K|
|   6 |     NESTED LOOPS                         |                  |      1 |      1 |     5   (0)|      0 |00:06:04.72 |     664K|    640K|
|   7 |      INLIST ITERATOR                     |                  |      1 |        |            |      0 |00:06:04.72 |     664K|    640K|
|*  8 |       TABLE ACCESS BY INDEX ROWID BATCHED| G_PIECE          |      2 |      1 |     3   (0)|      0 |00:06:04.72 |     664K|    640K|
|*  9 |        INDEX RANGE SCAN                  | G_PIECE$ID_VENTE |      2 |      3 |     3  (34)|   1434K|00:00:05.25 |    6590 |   6586 |
|* 10 |      TABLE ACCESS BY INDEX ROWID BATCHED | G_PIECE          |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 11 |       INDEX RANGE SCAN                   | PIE_REFDOSS      |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 12 |     TABLE ACCESS BY INDEX ROWID BATCHED  | G_DOSSIER        |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 13 |      INDEX RANGE SCAN                    | DOS_ANCREFDOSS   |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 14 |    INDEX RANGE SCAN                      | PIE_REFDOSS      |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 15 |   TABLE ACCESS BY INDEX ROWID            | G_PIECE          |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
---------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   8 - filter(("PL"."TYPEDOC"='C' AND "PL"."FG05"='O' AND "PL"."GPIHEURE" IS NOT NULL AND "PL"."REFDOSS" IS NOT NULL AND
              (NVL("PL"."GPIDATE1","PL"."GPIDTFIN") IS NULL OR NVL("PL"."GPIDATE1","PL"."GPIDTFIN")>=2460445) AND "PL"."GPIDTDEB"<=2460445 AND
              "PL"."MT02">0))
   9 - access((("PL"."GPIROLE"='DC' OR "PL"."GPIROLE"='DT')) AND "PL"."TYPPIECE"='REQUEST_LIMITE')
  10 - filter(NVL("COMPTE"."FG41",'N')='N')
  11 - access("PL"."REFDOSS"="COMPTE"."REFDOSS" AND "COMPTE"."TYPPIECE"='COMPTE')
       filter("COMPTE"."REFDOSS" IS NOT NULL)
  12 - filter("CONTRAT"."REFFACTOR"='A60029KT')
  13 - access("PL"."GPIHEURE"="CONTRAT"."ANCREFDOSS")
       filter("CONTRAT"."ANCREFDOSS" IS NOT NULL)
  14 - access("CONTRAT"."REFDOSS"="PFACTC"."REFDOSS" AND "PFACTC"."TYPPIECE"='FACTORINGCRITERIA')
       filter("PFACTC"."REFDOSS" IS NOT NULL)
  15 - filter(("PFACTC"."MT57" IS NOT NULL AND "PFACTC"."MT12" IS NOT NULL AND NVL("PFACTC"."FG40",'N')='N'))  
*/
/********************************OLD Metrics***************************************/

/********************************New SQL*******************************************/

SELECT /*+ leading(PFACTC) index(PFACTC PIECE_TYP_MT43_IDX) */
       CONTRAT.reffactor /* automatically injected */, 
       PL.refpiece, /*PL.gpiadr3, PL.gpidepot, PL.gpityptrib, PFACTC.mt12,*/ 
       PL.mt02, 
       PL.code, --convert from factor currency to limitCurrency                                                                         
       CASE 
        WHEN PL.code != nvl(ftr_fin_factor.getCurrency ( nvl(PL.gpityptrib,'NA')), PL.code)                                
         THEN (SELECT NVL(CH_TAUX.Conv_Orig_Dest_Tx(TO_CHAR(to_date(2460445,'j'),'j'),                                                             
      /*LimitValue*/  FTR_MATCH.getMaxPortfolio(PL.gpidepot,PL.gpiadr3, PL.gpityptrib,1,TO_CHAR(to_date(2460445,'j')-PFACTC.mt12,'j')),  
      /*FactCurrency*/NVL(ftr_fin_factor.getCurrency ( nvl(PL.gpityptrib,'NA')), PL.code),                                  
      /*ApprCurrency*/PL.code,                                                                                              
                      'MER'),0)
                 FROM dual)                                                                                    
         ELSE (SELECT NVL(FTR_MATCH.getMaxPortfolio(PL.gpidepot,PL.gpiadr3, PL.gpityptrib,1,TO_CHAR(to_date(2460445,'j')-PFACTC.mt12,'j')) ,0)                                                                                                       
                 FROM dual)                                                                                                 
       END CASE,                                                                                                   
       PFACTC.mt57                                                                                                 
  FROM g_piece PL, 
       g_dossier CONTRAT, 
       g_piece PFACTC, 
       g_piece Compte                                                
 WHERE PL.typpiece = 'REQUEST_LIMITE'                                                                               
     -- active limit                                                                                                   
   AND PL.GPIROLE IN ( 'DC', 'DT' )                                                                                  
   AND PL.mt02 > 0                                                                                                   
   AND PL.FG05 = 'O'                                                                                                 
   AND PL.TYPEDOC = 'C'                                                                                              
   AND PL.GPIDTDEB <= TO_CHAR(to_date(2460445,'j'),'j')                                                       
   AND ( nvl( PL.GPIDATE1, PL.GPIDTFIN ) IS NULL                                                                     
      OR nvl( PL.GPIDATE1, PL.GPIDTFIN ) >= TO_CHAR(to_date(2460445,'j'),'j'))                             
   AND PL.gpiheure = CONTRAT.ancrefdoss                                                                              
   AND CONTRAT.refdoss = PFACTC.refdoss                                                                              
    /* reffactor condition */
   AND CONTRAT.reffactor IN ('A60029KT') 
   AND PFACTC.typpiece = 'FACTORINGCRITERIA'                                                                         
     -- Automatic cancellation period is filled                                                                        
   AND PFACTC.mt12 IS NOT NULL                                                                                       
     -- is not flagged as no revision for underuse                                                                     
   AND nvl(PFACTC.fg40, 'N') = 'N'                                                                                   
     -- Revision Rounding Amount                                                                                       
   AND PFACTC.mt57 IS NOT NULL                                                                                       
   AND PL.refdoss = Compte.refdoss                                                                                   
   AND Compte.typpiece = 'COMPTE'                                                                                    
   AND nvl(Compte.fg41, 'N') = 'N';
/********************************New SQL*******************************************/
/********************************New Metrics***************************************/
/*
Plan hash value: 4123610116
----------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                               | Name               | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  |
----------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                        |                    |      1 |        |   298 (100)|      0 |00:00:00.12 |    7278 |    175 |
|   1 |  FAST DUAL                              |                    |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|   2 |   FAST DUAL                             |                    |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|   3 |  NESTED LOOPS                           |                    |      1 |      1 |   294   (1)|      0 |00:00:00.12 |    7278 |    175 |
|   4 |   NESTED LOOPS                          |                    |      1 |      1 |   294   (1)|      0 |00:00:00.12 |    7278 |    175 |
|   5 |    NESTED LOOPS                         |                    |      1 |      1 |   292   (1)|      0 |00:00:00.12 |    7278 |    175 |
|   6 |     NESTED LOOPS                        |                    |      1 |      1 |   290   (1)|      0 |00:00:00.12 |    7278 |    175 |
|*  7 |      TABLE ACCESS BY INDEX ROWID BATCHED| G_PIECE            |      1 |      1 |   289   (1)|      0 |00:00:00.12 |    7278 |    175 |
|*  8 |       INDEX RANGE SCAN                  | PIECE_TYP_MT43_IDX |      1 |   2684 |     7   (0)|   2684 |00:00:00.01 |      31 |     29 |
|*  9 |      TABLE ACCESS BY INDEX ROWID        | G_DOSSIER          |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 10 |       INDEX UNIQUE SCAN                 | DOS_REFDOSS        |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 11 |     TABLE ACCESS BY INDEX ROWID BATCHED | G_PIECE            |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 12 |      INDEX RANGE SCAN                   | GP_GRTYPE_MT_DT    |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 13 |    INDEX RANGE SCAN                     | PIE_REFDOSS        |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 14 |   TABLE ACCESS BY INDEX ROWID           | G_PIECE            |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
----------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   7 - filter(("PFACTC"."MT57" IS NOT NULL AND "PFACTC"."MT12" IS NOT NULL AND "PFACTC"."REFDOSS" IS NOT NULL AND
              NVL("PFACTC"."FG40",'N')='N'))
   8 - access("PFACTC"."TYPPIECE"='FACTORINGCRITERIA')
   9 - filter(("CONTRAT"."ANCREFDOSS" IS NOT NULL AND "CONTRAT"."REFFACTOR"='A60029KT'))
  10 - access("CONTRAT"."REFDOSS"="PFACTC"."REFDOSS")
  11 - filter(("PL"."TYPEDOC"='C' AND "PL"."FG05"='O' AND INTERNAL_FUNCTION("PL"."GPIROLE") AND "PL"."REFDOSS" IS NOT NULL AND
              (NVL("PL"."GPIDATE1","PL"."GPIDTFIN") IS NULL OR NVL("PL"."GPIDATE1","PL"."GPIDTFIN")>=2460445) AND "PL"."GPIDTDEB"<=2460445 AND
              "PL"."MT02">0))
  12 - access("PL"."TYPPIECE"='REQUEST_LIMITE' AND "PL"."GPIHEURE"="CONTRAT"."ANCREFDOSS")
       filter("PL"."GPIHEURE" IS NOT NULL)
  13 - access("PL"."REFDOSS"="COMPTE"."REFDOSS" AND "COMPTE"."TYPPIECE"='COMPTE')
       filter("COMPTE"."REFDOSS" IS NOT NULL)
  14 - filter(NVL("COMPTE"."FG41",'N')='N')
*/
/********************************New Metrics***************************************/

/********************************Index statistics**********************************/

/********************************Other SQLs****************************************/          
/*

*/ 
/********************************Other SQLs****************************************/              
