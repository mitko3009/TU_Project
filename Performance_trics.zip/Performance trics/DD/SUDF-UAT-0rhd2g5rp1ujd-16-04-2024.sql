/********************************************************************************
*********       E-mail subject: SUDFWEB-1922
*********             Instance: UAT V9
*********          Description: 
Problem:
Slow query from e_pmtalettrer on UAT V9.


Analysis:
We find that the query from the .har file, which took around 12 minutes is with sql_id 0rhd2g5rp1ujd.
The problem in it is that the query doesn't start from the most selective part, which is table g_dossier and conditions ( reflot = :B1 AND categdoss LIKE 'COMPTE%' ).
To be possible to start from it, we should move table g_dossier into the two unions as it is made in the New SQL section below. 
By this way, we will have control over the query execution.

Suggestion:
Please change the SQL text as it is shown in the New SQL section below.

*********               SQL_ID: 0rhd2g5rp1ujd
*********      Program/Package: e_pmtalettrer 
*********              Request: Rodrigo Chavez
*********               Author: Dimitar Dimitrov
********* Received e-mail date: 15/04/2024
*********      Resolution date: 16/04/2024
*********  Trace old file here: \\epox\specifs\performance\tmp\
*********  Trace new file here:
***********************************************************************************/

/********************************OLD SQL*******************************************/

VAR B1 VARCHAR2(32);
EXEC :B1 := '1706220088';
VAR B2 VARCHAR2(32);
EXEC :B2 := 'ALMATIS GMBH%';
VAR B3 VARCHAR2(32);
EXEC :B3 := '2021-01-01';
VAR B4 NUMBER;
EXEC :B4 := 2001;
VAR B5 NUMBER;
EXEC :B5 := 1;

SELECT g_main.*
  FROM (SELECT /*+ first_rows(2001)*/
         foo.*, ROWNUM rnum
          FROM (SELECT pmtRef               pmtRef,
                       pmtDate              pmtDate,
                       bookCode             bookCode,
                       pmtAmount            pmtAmount,
                       pmtCurrency          pmtCurrency,
                       balance              unmAmount,
                       pmtCommunication     pmtCommunication,
                       clientName           clientName,
                       clientFstName        clientFstName,
                       clientFullName       clientFullName,
                       caseRef              caseRef,
                       intComment           intComment,
                       extComment           extComment,
                       clclNumber           clclNumber,
                       debtorName           debtorName,
                       thirdCtraManagerName thirdCtraManagerName,
                       forthCtraManagerName forthCtraManagerName,
                       factoringType        factoringType,
                       caseManagerName      caseManagerName
                  FROM (SELECT pmtRef,
                               pmtDate,
                               bookCode,
                               pmtAmount,
                               pmtCurrency,
                               DECODE(traite,
                                      '2',
                                      DECODE(matched_amt,
                                             0.0,
                                             pmtAmount,
                                             CH_TAUX.ConversDosMvt(dtjour,
                                                                   caseRef,
                                                                   montant_dos -
                                                                   matched_amt,
                                                                   pmtCurrency,
                                                                   'A')),
                                      traite,
                                      '0',
                                      DECODE(matched_amt,
                                             0.0,
                                             pmtAmount,
                                             CH_TAUX.ConversDosMvt(dtjour,
                                                                   caseRef,
                                                                   montant_dos -
                                                                   matched_amt,
                                                                   pmtCurrency,
                                                                   'A'))) AS BALANCE,
                               pmtCommunication,
                               clientRef,
                               clientName,
                               clientFstName,
                               clientFullName,
                               caseRef,
                               intComment,
                               extComment,
                               clclNumber,
                               debtorName,
                               thirdCtraManagerName,
                               forthCtraManagerName,
                               factoringType,
                               caseManagerName,
                               refpayer
                          FROM (SELECT tbl.refencaiss pmtRef,
                                       tbl.receptionDate pmtDate,
                                       tbl.bookCode bookCode,
                                       tbl.montant_mvt pmtAmount,
                                       tbl.devise_mvt pmtCurrency,
                                       tbl.communication pmtCommunication,
                                       CL.refindividu clientRef,
                                       CL.nom clientName,
                                       CL.prenom clientFstName,
                                       CL.nom || ' ' || CL.prenom clientFullName,
                                       tbl.refdoss caseRef,
                                       tbl.comments intComment,
                                       tbl.ext_comments extComment,
                                       tbl.traite,
                                       tbl.dtjour,
                                       tbl.montant_dos,
                                       tbl.matched_amt matched_amt,
                                       tbl.refpayeur refpayer,
                                       (SELECT refext
                                          FROM t_individu
                                         WHERE 1 = 1
                                           AND societe = 'CLIENT_NUMBER'
                                           AND refindividu = tbl.refpayeur
                                           AND refext2 = CL.refindividu
                                           AND rownum = 1) clclNumber,
                                       DB.nom debtorName,
                                       (SELECT G.nom
                                          FROM g_piece P, g_individu G
                                         WHERE 1 = 1
                                           AND P.refdoss =
                                               (SELECT reflot
                                                  FROM g_dossier
                                                 WHERE refdoss =
                                                       (SELECT reflot
                                                          FROM g_dossier
                                                         WHERE refdoss =
                                                               tbl.refdoss))
                                           AND P.typpiece = 'CONTRAT'
                                           AND P.str_20_1 = G.refindividu) thirdCtraManagerName,
                                       (SELECT G.nom
                                          FROM g_piece P, g_individu G
                                         WHERE 1 = 1
                                           AND P.refdoss =
                                               (SELECT reflot
                                                  FROM g_dossier
                                                 WHERE refdoss =
                                                       (SELECT reflot
                                                          FROM g_dossier
                                                         WHERE refdoss =
                                                               tbl.refdoss))
                                           AND P.typpiece = 'CONTRAT'
                                           AND P.st20 = G.refindividu) forthCtraManagerName,
                                       (SELECT case
                                                 when 0 <
                                                      (select count(*)
                                                         FROM g_dossier CMT,
                                                              g_dossier DEC,
                                                              g_dossier CTR,
                                                              g_dossier REV
                                                        WHERE 1 = 1
                                                          AND CMT.refdoss =
                                                              tbl.refdoss
                                                          AND CMT.reflot =
                                                              DEC.refdoss
                                                          AND DEC.reflot =
                                                              CTR.Refdoss
                                                          AND CTR.refhierarchie =
                                                              REV.refdoss
                                                          AND REV.categdoss =
                                                              'COMPTE DB CTR') then
                                                  'Reverse'
                                                 else
                                                  'Classical'
                                               end
                                          from dual) factoringType,
                                       MAN.nom caseManagerName
                                  FROM (SELECT /*+ leading(TNMP) index(TNMP aggreg_t_ecrdos_nmp$bal) */
                                         ENC.refencaiss,
                                         ENC.comments,
                                         ENC.ext_comments,
                                         D.chemin AS bookCode,
                                         ENC.devise_mvt,
                                         NVL(ENC.dtencaiss_dt,
                                             ENC.dtreception_dt) AS receptionDate,
                                         VENTIL.montant_mvt,
                                         ENC.refpayeur,
                                         ENC.comm || ENC.comm2 AS communication,
                                         VENTIL.refdoss,
                                         ENC.traite,
                                         ENC.dtjour,
                                         VENTIL.montant_dos,
                                         nvl(VENTIL.matched_amt, 0) matched_amt
                                          FROM g_ventilenc         VENTIL,
                                               g_encaissement      ENC,
                                               nam_collecte        NC,
                                               aggreg_t_ecrdos_nmp TNMP,
                                               v_domaine           D
                                         WHERE ENC.traite = '2'
                                           AND NC.refer(+) = ENC.refencaiss
                                           AND NC.compostage(+) = TNMP.lieupaimt
                                           AND ENC.typencaiss IN
                                               ('e_saencaiss', 'e_savirmt')
                                           AND ENC.refencaiss =
                                               VENTIL.refencaiss
                                           AND VENTIL.refencaiss = TNMP.refelem
                                           AND VENTIL.refdoss = TNMP.refdoss
                                           AND TNMP.balance_dcpt < 0
                                           AND D.type(+) = 'NAM_COLLECTE'
                                           AND SUBSTR(TNMP.lieupaimt, 1, 3) =
                                               D.abrev(+)
                                        UNION ALL
                                        SELECT /*+ leading(VENTIL) index(VENTIL G_VENTILENC_REFDOSS_TRAITE) */
                                         ENC.refencaiss,
                                         ENC.comments,
                                         ENC.ext_comments,
                                         D.chemin AS bookCode,
                                         ENC.devise_mvt,
                                         NVL(ENC.dtencaiss_dt,
                                             ENC.dtreception_dt) AS receptionDate,
                                         VENTIL.montant_mvt,
                                         ENC.refpayeur,
                                         ENC.comm || ENC.comm2 AS communication,
                                         VENTIL.refdoss,
                                         ENC.traite,
                                         ENC.dtjour,
                                         VENTIL.montant_dos,
                                         nvl(VENTIL.matched_amt, 0) matched_amt
                                          FROM g_ventilenc    VENTIL,
                                               g_encaissement ENC,
                                               nam_collecte   NC,
                                               t_elements     E,
                                               v_domaine      D
                                         WHERE VENTIL.traite = '0'
                                           AND NC.refer(+) = ENC.refencaiss
                                           AND NC.compostage(+) = ENC.lieupaimt
                                           AND ENC.typencaiss IN
                                               ('e_saencaiss', 'e_savirmt')
                                           AND ENC.refencaiss = VENTIL.refencaiss
                                           AND E.refdoss = VENTIL.refdoss
                                           AND E.typeelem = 'en'
                                           AND E.refelem = ENC.refencaiss
                                           AND D.type(+) = 'NAM_COLLECTE'
                                           AND SUBSTR(ENC.lieupaimt, 1, 3) = D.abrev(+)) tbl,
                                       t_intervenants CLI,
                                       g_individu CL,
                                       g_dossier DOSS,
                                       g_individu DB,
                                       g_personnel USR,
                                       g_individu MAN
                                 WHERE 1 = 1
                                   AND CLI.reftype = 'CL'
                                   AND CLI.refdoss = tbl.refdoss
                                   AND CLI.refindividu = CL.refindividu
                                   AND DOSS.refdoss = tbl.refdoss
                                   AND DB.refindividu = tbl.refpayeur
                                   AND USR.refperso = DOSS.rangmt
                                   AND USR.refindividu = MAN.refindividu))
                 WHERE 1 = 1
                   AND caseRef IN
                       (SELECT refdoss
                          FROM g_dossier
                         WHERE reflot = :B1
                           AND categdoss LIKE 'COMPTE%')
                   AND NVL(balance, 0) <> 0
                   AND clientFullName like :B2 || '%'
                   AND pmtDate >= :B3
                 ORDER BY pmtDate, pmtAmount DESC, bookCode, pmtRef) foo
         WHERE ROWNUM <= :B4) g_main
 WHERE 1 = 1
   AND rnum >= :B5;
/********************************OLD SQL*******************************************/
/********************************OLD Metrics***************************************/
/*
MODULE                           SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
E711B68C1E5BBCFC8C0C6F5A9421ABD7 0rhd2g5rp1ujd  993906225        288      11699 db file sequential r 2024/04/11 15:05:02  2024/04/11 15:15:02          32                    1 +000000000 00:10:00.370 47%
E711B68C1E5BBCFC8C0C6F5A9421ABD7 0rhd2g5rp1ujd  993906225        288      11699 read by other sessio 2024/04/11 15:04:32  2024/04/11 15:15:12          27                    1 +000000000 00:10:40.383 40%
E711B68C1E5BBCFC8C0C6F5A9421ABD7 0rhd2g5rp1ujd  993906225        288      11699 ON CPU               2024/04/11 15:04:22  2024/04/11 15:12:12           5                    1 +000000000 00:07:50.289 7%
E711B68C1E5BBCFC8C0C6F5A9421ABD7 0rhd2g5rp1ujd  993906225        288      11699 db file parallel rea 2024/04/11 15:04:02  2024/04/11 15:13:42           4                    1 +000000000 00:09:40.324 6% 

MODULE                           SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
E711B68C1E5BBCFC8C0C6F5A9421ABD7 0rhd2g5rp1ujd  993906225        288      11699                      2024/04/11 15:04:02  2024/04/11 15:15:12          68                    1 +000000000 00:11:10.385 100%

Plan hash value: 993906225
------------------------------------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                             | Name                           | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  |
------------------------------------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                                      |                                |      1 |        |   162K(100)|      0 |00:00:00.01 |       0 |      0 |
|*  1 |  COUNT STOPKEY                                        |                                |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*  2 |   TABLE ACCESS BY INDEX ROWID BATCHED                 | T_INDIVIDU                     |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*  3 |    INDEX RANGE SCAN                                   | IX_T_INDIVIDU                  |      0 |      3 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|   4 |  NESTED LOOPS                                         |                                |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|   5 |   NESTED LOOPS                                        |                                |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*  6 |    TABLE ACCESS BY INDEX ROWID BATCHED                | G_PIECE                        |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*  7 |     INDEX RANGE SCAN                                  | PIE_REFDOSS                    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*  8 |      INDEX RANGE SCAN                                 | DOS_REFDOSS_REFLOT_IDX         |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*  9 |       INDEX RANGE SCAN                                | DOS_REFDOSS_REFLOT_IDX         |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 10 |    INDEX UNIQUE SCAN                                  | IND_REFINDIV                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|  11 |   TABLE ACCESS BY INDEX ROWID                         | G_INDIVIDU                     |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|  12 |  NESTED LOOPS                                         |                                |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|  13 |   NESTED LOOPS                                        |                                |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 14 |    TABLE ACCESS BY INDEX ROWID BATCHED                | G_PIECE                        |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 15 |     INDEX RANGE SCAN                                  | PIE_REFDOSS                    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 16 |      INDEX RANGE SCAN                                 | DOS_REFDOSS_REFLOT_IDX         |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 17 |       INDEX RANGE SCAN                                | DOS_REFDOSS_REFLOT_IDX         |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 18 |    INDEX UNIQUE SCAN                                  | IND_REFINDIV                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|  19 |   TABLE ACCESS BY INDEX ROWID                         | G_INDIVIDU                     |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|  20 |  NESTED LOOPS                                         |                                |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|  21 |   NESTED LOOPS                                        |                                |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|  22 |    NESTED LOOPS                                       |                                |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|  23 |     NESTED LOOPS                                      |                                |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 24 |      INDEX RANGE SCAN                                 | DOS_REFDOSS_REFLOT_IDX         |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 25 |      INDEX RANGE SCAN                                 | DOS_REFDOSS_REFLOT_IDX         |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 26 |     TABLE ACCESS BY INDEX ROWID                       | G_DOSSIER                      |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 27 |      INDEX UNIQUE SCAN                                | DOS_REFDOSS                    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 28 |    INDEX UNIQUE SCAN                                  | DOS_REFDOSS                    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 29 |   TABLE ACCESS BY INDEX ROWID                         | G_DOSSIER                      |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|  30 |  FAST DUAL                                            |                                |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 31 |  VIEW                                                 |                                |      1 |      1 |   162K  (1)|      0 |00:00:00.01 |       0 |      0 |
|* 32 |   COUNT STOPKEY                                       |                                |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  33 |    VIEW                                               |                                |      1 |      1 |   162K  (1)|      0 |00:00:00.01 |       0 |      0 |
|* 34 |     SORT ORDER BY STOPKEY                             |                                |      1 |      1 |   162K  (1)|      0 |00:00:00.01 |       0 |      0 |
|  35 |      NESTED LOOPS                                     |                                |      1 |      1 |   162K  (1)|      0 |00:00:00.01 |       0 |      0 |
|  36 |       NESTED LOOPS                                    |                                |      1 |      1 |   162K  (1)|      0 |00:00:00.01 |       0 |      0 |
|  37 |        NESTED LOOPS                                   |                                |      1 |      1 |   162K  (1)|      0 |00:00:00.01 |       0 |      0 |
|  38 |         NESTED LOOPS                                  |                                |      1 |      1 |   162K  (1)|      0 |00:00:00.01 |       0 |      0 |
|  39 |          NESTED LOOPS                                 |                                |      1 |      1 |   162K  (1)|      0 |00:00:00.01 |       0 |      0 |
|  40 |           NESTED LOOPS                                |                                |      1 |      1 |   162K  (1)|      1 |00:00:03.42 |   15941 |   2153 |
|* 41 |            HASH JOIN                                  |                                |      1 |      1 |   162K  (1)|      1 |00:00:03.42 |   15938 |   2153 |
|* 42 |             INDEX RANGE SCAN                          | G_DOSSIER_RL_CD_RD_RF_IDX      |      1 |     32 |     1   (0)|    390 |00:00:00.01 |       7 |      3 |
|* 43 |             VIEW                                      |                                |      1 |   2020 |   162K  (1)|   4006 |00:00:06.17 |   39245 |   4050 |
|  44 |              UNION-ALL                                |                                |      1 |        |            |   4006 |00:00:06.00 |   35066 |   4050 |
|  45 |               NESTED LOOPS OUTER                      |                                |      1 |   2001 |   651   (0)|   4006 |00:00:06.00 |   35066 |   4050 |
|* 46 |                HASH JOIN RIGHT OUTER                  |                                |      1 |   2001 |   650   (0)|   4006 |00:00:05.96 |   35013 |   4025 |
|  47 |                 TABLE ACCESS BY INDEX ROWID BATCHED   | V_DOMAINE                      |      1 |     36 |     1   (0)|    734 |00:00:00.01 |      63 |      0 |
|* 48 |                  INDEX RANGE SCAN                     | V_DOMAINE_TYPE_CODE_IDX        |      1 |     36 |     1   (0)|    734 |00:00:00.01 |      12 |      0 |
|  49 |                 NESTED LOOPS                          |                                |      1 |   2001 |   649   (0)|   4006 |00:00:05.95 |   34950 |   4025 |
|  50 |                  NESTED LOOPS                         |                                |      1 |  10614 |   649   (0)|   4213 |00:00:03.11 |   30890 |   1980 |
|  51 |                   NESTED LOOPS                        |                                |      1 |  10614 |   330   (0)|   4213 |00:00:00.11 |   18293 |      0 |
|* 52 |                    INDEX UNIQUE SCAN                  | PK_AGGREG_T_ECRDOS_NMP         |      1 |  10620 |    12   (0)|   4213 |00:00:00.03 |    5871 |      0 |
|* 53 |                     INDEX RANGE SCAN                  | AGGREG_T_ECRDOS_NMP$BAL        |      1 |    565K|     1   (0)|   4213 |00:00:00.01 |     197 |      0 |
|  54 |                    TABLE ACCESS BY INDEX ROWID BATCHED| G_VENTILENC                    |   4213 |      1 |     1   (0)|   4213 |00:00:00.07 |   12422 |      0 |
|* 55 |                     INDEX RANGE SCAN                  | ALT_G_VENT_REF                 |   4213 |      1 |     1   (0)|   4213 |00:00:00.05 |    8415 |      0 |
|* 56 |                   INDEX UNIQUE SCAN                   | REFENCAISS                     |   4213 |      1 |     1   (0)|   4213 |00:00:03.00 |   12597 |   1980 |
|* 57 |                  TABLE ACCESS BY INDEX ROWID          | G_ENCAISSEMENT                 |   4213 |      1 |     1   (0)|   4006 |00:00:02.83 |    4060 |   2045 |
|* 58 |                TABLE ACCESS BY INDEX ROWID            | NAM_COLLECTE                   |   4006 |      1 |     1   (0)|     17 |00:00:00.03 |      53 |     25 |
|* 59 |                 INDEX UNIQUE SCAN                     | COLCOMPOSTAGE                  |   4006 |      1 |     1   (0)|     17 |00:00:00.02 |      35 |     14 |
|  60 |               NESTED LOOPS OUTER                      |                                |      1 |     19 |   161K  (1)|      0 |00:00:00.01 |       0 |      0 |
|* 61 |                HASH JOIN                              |                                |      1 |     19 |   161K  (1)|      0 |00:00:00.01 |       0 |      0 |
|  62 |                 TABLE ACCESS BY INDEX ROWID BATCHED   | T_ELEMENTS                     |      1 |   5829K| 27116   (1)|    684K|00:00:33.20 |     235K|  85940 |
|* 63 |                  INDEX SKIP SCAN                      | ELE_ELEMDOSS                   |      1 |   5829K|  3029   (1)|    684K|00:00:10.51 |    8474 |   7706 |
|* 64 |                 HASH JOIN                             |                                |      0 |   5851K| 93989   (1)|      0 |00:00:00.01 |       0 |      0 |
|  65 |                  TABLE ACCESS BY INDEX ROWID BATCHED  | G_VENTILENC                    |      0 |   9051K| 25865   (1)|      0 |00:00:00.01 |       0 |      0 |
|* 66 |                   INDEX SKIP SCAN                     | G_VENTILENC_REFDOSS_TRAITE     |      0 |   9051K|  1389   (1)|      0 |00:00:00.01 |       0 |      0 |
|* 67 |                  TABLE ACCESS BY INDEX ROWID BATCHED  | G_ENCAISSEMENT                 |      0 |   5846K| 26575   (1)|      0 |00:00:00.01 |       0 |      0 |
|* 68 |                   INDEX RANGE SCAN                    | G_ENC_FUNC_DTREC_DTENC         |      0 |     29M|  1145   (1)|      0 |00:00:00.01 |       0 |      0 |
|  69 |                TABLE ACCESS BY INDEX ROWID BATCHED    | V_DOMAINE                      |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 70 |                 INDEX RANGE SCAN                      | DOM_TYPABREV                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 71 |            INDEX RANGE SCAN                           | INT_REFDOSS                    |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |      0 |
|* 72 |           TABLE ACCESS BY INDEX ROWID                 | G_INDIVIDU                     |      1 |      1 |     1   (0)|      0 |00:00:00.01 |       4 |      0 |
|* 73 |            INDEX UNIQUE SCAN                          | IND_REFINDIV                   |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |      0 |
|  74 |          TABLE ACCESS BY INDEX ROWID                  | G_INDIVIDU                     |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 75 |           INDEX UNIQUE SCAN                           | IND_REFINDIV                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 76 |         INDEX RANGE SCAN                              | G_DOSSIER_REFDOSS_SOLDE_RANGMT |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|  77 |        TABLE ACCESS BY INDEX ROWID BATCHED            | G_PERSONNEL                    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 78 |         INDEX RANGE SCAN                              | GPERSREFP                      |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|  79 |       TABLE ACCESS BY INDEX ROWID                     | G_INDIVIDU                     |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 80 |        INDEX UNIQUE SCAN                              | IND_REFINDIV                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
------------------------------------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   1 - filter(ROWNUM=1)
   2 - filter(("REFEXT2"=:B1 AND "SOCIETE"='CLIENT_NUMBER'))
   3 - access("REFINDIVIDU"=:B1)
   6 - filter("P"."STR_20_1" IS NOT NULL)
   7 - access("P"."REFDOSS"= AND "P"."TYPPIECE"='CONTRAT')
   8 - access("REFDOSS"=)
   9 - access("REFDOSS"=:B1)
  10 - access("P"."STR_20_1"="G"."REFINDIVIDU")
  14 - filter("P"."ST20" IS NOT NULL)
  15 - access("P"."REFDOSS"= AND "P"."TYPPIECE"='CONTRAT')
  16 - access("REFDOSS"=)
  17 - access("REFDOSS"=:B1)
  18 - access("P"."ST20"="G"."REFINDIVIDU")
  24 - access("CMT"."REFDOSS"=:B1)
  25 - access("CMT"."REFLOT"="DEC"."REFDOSS")
  26 - filter("CTR"."REFHIERARCHIE" IS NOT NULL)
  27 - access("DEC"."REFLOT"="CTR"."REFDOSS")
  28 - access("CTR"."REFHIERARCHIE"="REV"."REFDOSS")
  29 - filter("REV"."CATEGDOSS"='COMPTE DB CTR')
  31 - filter("RNUM">=:B5)
  32 - filter(ROWNUM<=:B4)
  34 - filter(ROWNUM<=:B4)
  41 - access("TBL"."REFDOSS"="REFDOSS")
  42 - access("REFLOT"=:B1 AND "CATEGDOSS" LIKE 'COMPTE%')
       filter("CATEGDOSS" LIKE 'COMPTE%')
  43 - filter(NVL(DECODE("TBL"."TRAITE",'2',DECODE("TBL"."MATCHED_AMT",0,"TBL"."MONTANT_MVT","CH_TAUX"."CONVERSDOSMVT"("TBL"."DTJOUR","TBL"."REFDOSS","TBL"."MON
              TANT_DOS"-"TBL"."MATCHED_AMT","TBL"."DEVISE_MVT",'A')),"TBL"."TRAITE",0,DECODE("TBL"."MATCHED_AMT",0,"TBL"."MONTANT_MVT","CH_TAUX"."CONVERSDOSMVT"("TBL"."DTJOUR
              ","TBL"."REFDOSS","TBL"."MONTANT_DOS"-"TBL"."MATCHED_AMT","TBL"."DEVISE_MVT",'A'))),0)<>0)
  46 - access("D"."ABREV"=SUBSTR("TNMP"."LIEUPAIMT",1,3))
  48 - access("D"."TYPE"='NAM_COLLECTE')
  52 - access("TNMP"."BALANCE_DCPT"<0)
  53 - access("TNMP"."BALANCE_DCPT"<0)
  55 - access("VENTIL"."REFENCAISS"="TNMP"."REFELEM" AND "VENTIL"."REFDOSS"="TNMP"."REFDOSS")
  56 - access("ENC"."REFENCAISS"="VENTIL"."REFENCAISS")
  57 - filter((INTERNAL_FUNCTION("ENC"."TYPENCAISS") AND NVL("DTENCAISS_DT","DTRECEPTION_DT")>=:B3 AND "ENC"."TRAITE"='2'))
  58 - filter(("NC"."REFER" IS NOT NULL AND "NC"."REFER"="ENC"."REFENCAISS"))
  59 - access("NC"."COMPOSTAGE"="TNMP"."LIEUPAIMT")
  61 - access("E"."REFDOSS"="VENTIL"."REFDOSS" AND "E"."REFELEM"="ENC"."REFENCAISS")
  63 - access("E"."TYPEELEM"='en')
       filter("E"."TYPEELEM"='en')
  64 - access("ENC"."REFENCAISS"="VENTIL"."REFENCAISS")
  66 - access("VENTIL"."TRAITE"='0')
       filter("VENTIL"."TRAITE"='0')
  67 - filter(("ENC"."TYPENCAISS"='e_saencaiss' OR "ENC"."TYPENCAISS"='e_savirmt'))
  68 - access("ENC"."SYS_NC00232$">=:B3)
  70 - access("D"."TYPE"='NAM_COLLECTE' AND "D"."ABREV"=SUBSTR("ENC"."LIEUPAIMT",1,3))
  71 - access("CLI"."REFDOSS"="TBL"."REFDOSS" AND "CLI"."REFTYPE"='CL')
  72 - filter("CL"."NOM"||' '||"CL"."PRENOM" LIKE :B2||'%')
  73 - access("CLI"."REFINDIVIDU"="CL"."REFINDIVIDU")
  75 - access("DB"."REFINDIVIDU"="TBL"."REFPAYEUR")
  76 - access("DOSS"."REFDOSS"="TBL"."REFDOSS")
  78 - access("USR"."REFPERSO"="DOSS"."RANGMT")
  80 - access("USR"."REFINDIVIDU"="MAN"."REFINDIVIDU")  
*/
/********************************OLD Metrics***************************************/

/********************************New SQL*******************************************/

SELECT g_main.*
  FROM (SELECT /*+ first_rows(2001)*/
         foo.*, ROWNUM rnum
          FROM (SELECT pmtRef               pmtRef,
                       pmtDate              pmtDate,
                       bookCode             bookCode,
                       pmtAmount            pmtAmount,
                       pmtCurrency          pmtCurrency,
                       balance              unmAmount,
                       pmtCommunication     pmtCommunication,
                       clientName           clientName,
                       clientFstName        clientFstName,
                       clientFullName       clientFullName,
                       caseRef              caseRef,
                       intComment           intComment,
                       extComment           extComment,
                       clclNumber           clclNumber,
                       debtorName           debtorName,
                       thirdCtraManagerName thirdCtraManagerName,
                       forthCtraManagerName forthCtraManagerName,
                       factoringType        factoringType,
                       caseManagerName      caseManagerName
                  FROM (SELECT pmtRef,
                               pmtDate,
                               bookCode,
                               pmtAmount,
                               pmtCurrency,
                               DECODE(traite,
                                      '2',
                                      DECODE(matched_amt,
                                             0.0,
                                             pmtAmount,
                                             CH_TAUX.ConversDosMvt(dtjour,
                                                                   caseRef,
                                                                   montant_dos -
                                                                   matched_amt,
                                                                   pmtCurrency,
                                                                   'A')),
                                      traite,
                                      '0',
                                      DECODE(matched_amt,
                                             0.0,
                                             pmtAmount,
                                             CH_TAUX.ConversDosMvt(dtjour,
                                                                   caseRef,
                                                                   montant_dos -
                                                                   matched_amt,
                                                                   pmtCurrency,
                                                                   'A'))) AS BALANCE,
                               pmtCommunication,
                               clientRef,
                               clientName,
                               clientFstName,
                               clientFullName,
                               caseRef,
                               intComment,
                               extComment,
                               clclNumber,
                               debtorName,
                               thirdCtraManagerName,
                               forthCtraManagerName,
                               factoringType,
                               caseManagerName,
                               refpayer
                          FROM (SELECT tbl.refencaiss pmtRef,
                                       tbl.receptionDate pmtDate,
                                       tbl.bookCode bookCode,
                                       tbl.montant_mvt pmtAmount,
                                       tbl.devise_mvt pmtCurrency,
                                       tbl.communication pmtCommunication,
                                       CL.refindividu clientRef,
                                       CL.nom clientName,
                                       CL.prenom clientFstName,
                                       CL.nom || ' ' || CL.prenom clientFullName,
                                       tbl.refdoss caseRef,
                                       tbl.comments intComment,
                                       tbl.ext_comments extComment,
                                       tbl.traite,
                                       tbl.dtjour,
                                       tbl.montant_dos,
                                       tbl.matched_amt matched_amt,
                                       tbl.refpayeur refpayer,
                                       (SELECT refext
                                          FROM t_individu
                                         WHERE 1 = 1
                                           AND societe = 'CLIENT_NUMBER'
                                           AND refindividu = tbl.refpayeur
                                           AND refext2 = CL.refindividu
                                           AND rownum = 1) clclNumber,
                                       DB.nom debtorName,
                                       (SELECT G.nom
                                          FROM g_piece P, g_individu G
                                         WHERE 1 = 1
                                           AND P.refdoss =
                                               (SELECT reflot
                                                  FROM g_dossier
                                                 WHERE refdoss =
                                                       (SELECT reflot
                                                          FROM g_dossier
                                                         WHERE refdoss =
                                                               tbl.refdoss))
                                           AND P.typpiece = 'CONTRAT'
                                           AND P.str_20_1 = G.refindividu) thirdCtraManagerName,
                                       (SELECT G.nom
                                          FROM g_piece P, g_individu G
                                         WHERE 1 = 1
                                           AND P.refdoss =
                                               (SELECT reflot
                                                  FROM g_dossier
                                                 WHERE refdoss =
                                                       (SELECT reflot
                                                          FROM g_dossier
                                                         WHERE refdoss =
                                                               tbl.refdoss))
                                           AND P.typpiece = 'CONTRAT'
                                           AND P.st20 = G.refindividu) forthCtraManagerName,
                                       (SELECT case
                                                 when 0 <
                                                      (select count(*)
                                                         FROM g_dossier CMT,
                                                              g_dossier DEC,
                                                              g_dossier CTR,
                                                              g_dossier REV
                                                        WHERE 1 = 1
                                                          AND CMT.refdoss =
                                                              tbl.refdoss
                                                          AND CMT.reflot =
                                                              DEC.refdoss
                                                          AND DEC.reflot =
                                                              CTR.Refdoss
                                                          AND CTR.refhierarchie =
                                                              REV.refdoss
                                                          AND REV.categdoss =
                                                              'COMPTE DB CTR') then
                                                  'Reverse'
                                                 else
                                                  'Classical'
                                               end
                                          from dual) factoringType,
                                       MAN.nom caseManagerName
                                  FROM (SELECT /*+ leading(GD TNMP) index(TNMP PK_AGGREG_T_ECRDOS_NMP)*/
                                         ENC.refencaiss,
                                         ENC.comments,
                                         ENC.ext_comments,
                                         D.chemin AS bookCode,
                                         ENC.devise_mvt,
                                         NVL(ENC.dtencaiss_dt, ENC.dtreception_dt) AS receptionDate,
                                         VENTIL.montant_mvt,
                                         ENC.refpayeur,
                                         ENC.comm || ENC.comm2 AS communication,
                                         VENTIL.refdoss,
                                         ENC.traite,
                                         ENC.dtjour,
                                         VENTIL.montant_dos,
                                         nvl(VENTIL.matched_amt, 0) matched_amt
                                          FROM g_ventilenc         VENTIL,
                                               g_encaissement      ENC,
                                               nam_collecte        NC,
                                               aggreg_t_ecrdos_nmp TNMP,
                                               v_domaine           D,
                                               g_dossier           GD
                                         WHERE ENC.traite = '2'
                                           AND GD.reflot = :B1
                                           AND GD.categdoss LIKE 'COMPTE%'
                                           AND GD.refdoss = TNMP.refdoss
                                           AND NC.refer(+) = ENC.refencaiss
                                           AND NC.compostage(+) = TNMP.lieupaimt
                                           AND ENC.typencaiss IN ('e_saencaiss', 'e_savirmt')
                                           AND ENC.refencaiss = VENTIL.refencaiss
                                           AND VENTIL.refencaiss = TNMP.refelem
                                           AND VENTIL.refdoss = TNMP.refdoss
                                           AND TNMP.balance_dcpt < 0
                                           AND D.type(+) = 'NAM_COLLECTE'
                                           AND SUBSTR(TNMP.lieupaimt, 1, 3) = D.abrev(+)
                                        UNION ALL
                                        SELECT /*+ leading(GD VENTIL) use_nl(E ENC) */
                                         ENC.refencaiss,
                                         ENC.comments,
                                         ENC.ext_comments,
                                         D.chemin AS bookCode,
                                         ENC.devise_mvt,
                                         NVL(ENC.dtencaiss_dt,
                                             ENC.dtreception_dt) AS receptionDate,
                                         VENTIL.montant_mvt,
                                         ENC.refpayeur,
                                         ENC.comm || ENC.comm2 AS communication,
                                         VENTIL.refdoss,
                                         ENC.traite,
                                         ENC.dtjour,
                                         VENTIL.montant_dos,
                                         nvl(VENTIL.matched_amt, 0) matched_amt
                                          FROM g_ventilenc    VENTIL,
                                               g_encaissement ENC,
                                               nam_collecte   NC,
                                               t_elements     E,
                                               v_domaine      D,
                                               g_dossier      GD
                                         WHERE VENTIL.traite = '0'
                                           AND GD.reflot = :B1
                                           AND GD.categdoss LIKE 'COMPTE%'
                                           AND GD.refdoss = VENTIL.refdoss
                                           AND NC.refer(+) = ENC.refencaiss
                                           AND NC.compostage(+) = ENC.lieupaimt
                                           AND ENC.typencaiss IN
                                               ('e_saencaiss', 'e_savirmt')
                                           AND ENC.refencaiss =
                                               VENTIL.refencaiss
                                           AND E.refdoss = VENTIL.refdoss
                                           AND E.typeelem = 'en'
                                           AND E.refelem = ENC.refencaiss
                                           AND D.type(+) = 'NAM_COLLECTE'
                                           AND SUBSTR(ENC.lieupaimt, 1, 3) = D.abrev(+)) tbl,
                                       t_intervenants CLI,
                                       g_individu CL,
                                       g_dossier DOSS,
                                       g_individu DB,
                                       g_personnel USR,
                                       g_individu MAN
                                 WHERE 1 = 1
                                   AND CLI.reftype = 'CL'
                                   AND CLI.refdoss = tbl.refdoss
                                   AND CLI.refindividu = CL.refindividu
                                   AND DOSS.refdoss = tbl.refdoss
                                   AND DB.refindividu = tbl.refpayeur
                                   AND USR.refperso = DOSS.rangmt
                                   AND USR.refindividu = MAN.refindividu))
                 WHERE 1 = 1                   
                   AND NVL(balance, 0) <> 0
                   AND clientFullName like :B2 || '%'
                   AND pmtDate >= :B3
                 ORDER BY pmtDate, pmtAmount DESC, bookCode, pmtRef) foo
         WHERE ROWNUM <= :B4) g_main
 WHERE 1 = 1
   AND rnum >= :B5;
/********************************New SQL*******************************************/
/********************************New Metrics***************************************/
/*

Plan hash value: 1556832928
--------------------------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                            | Name                           | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers |
--------------------------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                                     |                                |      1 |        |   135 (100)|      1 |00:00:00.01 |    1631 |
|*  1 |  COUNT STOPKEY                                       |                                |      1 |        |            |      1 |00:00:00.01 |       4 |
|*  2 |   TABLE ACCESS BY INDEX ROWID BATCHED                | T_INDIVIDU                     |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       4 |
|*  3 |    INDEX RANGE SCAN                                  | IX_T_INDIVIDU                  |      1 |      3 |     1   (0)|      1 |00:00:00.01 |       3 |
|   4 |  NESTED LOOPS                                        |                                |      1 |      1 |     2   (0)|      1 |00:00:00.01 |      17 |
|   5 |   NESTED LOOPS                                       |                                |      1 |      1 |     2   (0)|      1 |00:00:00.01 |      16 |
|*  6 |    TABLE ACCESS BY INDEX ROWID BATCHED               | G_PIECE                        |      1 |      1 |     1   (0)|      1 |00:00:00.01 |      13 |
|*  7 |     INDEX RANGE SCAN                                 | PIE_REFDOSS                    |      1 |      1 |     1   (0)|      1 |00:00:00.01 |      10 |
|*  8 |      INDEX RANGE SCAN                                | DOS_REFDOSS_REFLOT_IDX         |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       6 |
|*  9 |       INDEX RANGE SCAN                               | DOS_REFDOSS_REFLOT_IDX         |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |
|* 10 |    INDEX UNIQUE SCAN                                 | IND_REFINDIV                   |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |
|  11 |   TABLE ACCESS BY INDEX ROWID                        | G_INDIVIDU                     |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       1 |
|  12 |  NESTED LOOPS                                        |                                |      1 |      1 |     2   (0)|      1 |00:00:00.01 |      17 |
|  13 |   NESTED LOOPS                                       |                                |      1 |      1 |     2   (0)|      1 |00:00:00.01 |      16 |
|* 14 |    TABLE ACCESS BY INDEX ROWID BATCHED               | G_PIECE                        |      1 |      1 |     1   (0)|      1 |00:00:00.01 |      13 |
|* 15 |     INDEX RANGE SCAN                                 | PIE_REFDOSS                    |      1 |      1 |     1   (0)|      1 |00:00:00.01 |      10 |
|* 16 |      INDEX RANGE SCAN                                | DOS_REFDOSS_REFLOT_IDX         |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       6 |
|* 17 |       INDEX RANGE SCAN                               | DOS_REFDOSS_REFLOT_IDX         |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |
|* 18 |    INDEX UNIQUE SCAN                                 | IND_REFINDIV                   |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |
|  19 |   TABLE ACCESS BY INDEX ROWID                        | G_INDIVIDU                     |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       1 |
|  20 |  NESTED LOOPS                                        |                                |      1 |      1 |     4   (0)|      0 |00:00:00.01 |      13 |
|  21 |   NESTED LOOPS                                       |                                |      1 |      1 |     4   (0)|      0 |00:00:00.01 |      13 |
|  22 |    NESTED LOOPS                                      |                                |      1 |      1 |     3   (0)|      0 |00:00:00.01 |      13 |
|  23 |     NESTED LOOPS                                     |                                |      1 |      1 |     2   (0)|      1 |00:00:00.01 |       6 |
|* 24 |      INDEX RANGE SCAN                                | DOS_REFDOSS_REFLOT_IDX         |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |
|* 25 |      INDEX RANGE SCAN                                | DOS_REFDOSS_REFLOT_IDX         |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |
|* 26 |     TABLE ACCESS BY INDEX ROWID                      | G_DOSSIER                      |      1 |      1 |     1   (0)|      0 |00:00:00.01 |       7 |
|* 27 |      INDEX UNIQUE SCAN                               | DOS_REFDOSS                    |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |
|* 28 |    INDEX UNIQUE SCAN                                 | DOS_REFDOSS                    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 29 |   TABLE ACCESS BY INDEX ROWID                        | G_DOSSIER                      |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|  30 |  FAST DUAL                                           |                                |      1 |      1 |     2   (0)|      1 |00:00:00.01 |       0 |
|* 31 |  VIEW                                                |                                |      1 |      1 |   135   (1)|      1 |00:00:00.01 |    1631 |
|* 32 |   COUNT STOPKEY                                      |                                |      1 |        |            |      1 |00:00:00.01 |    1631 |
|  33 |    VIEW                                              |                                |      1 |      1 |   135   (1)|      1 |00:00:00.01 |    1631 |
|* 34 |     SORT ORDER BY STOPKEY                            |                                |      1 |      1 |   135   (1)|      1 |00:00:00.01 |    1580 |
|  35 |      NESTED LOOPS                                    |                                |      1 |      1 |   123   (0)|      1 |00:00:00.01 |    1580 |
|  36 |       NESTED LOOPS                                   |                                |      1 |      1 |   122   (0)|      1 |00:00:00.01 |    1576 |
|  37 |        NESTED LOOPS                                  |                                |      1 |      1 |   121   (0)|      1 |00:00:00.01 |    1572 |
|  38 |         NESTED LOOPS                                 |                                |      1 |      1 |   120   (0)|      1 |00:00:00.01 |    1569 |
|  39 |          NESTED LOOPS                                |                                |      1 |      1 |   119   (0)|      1 |00:00:00.01 |    1566 |
|  40 |           NESTED LOOPS                               |                                |      1 |      1 |   118   (0)|      1 |00:00:00.01 |    1563 |
|* 41 |            VIEW                                      |                                |      1 |     79 |   117   (0)|      1 |00:00:00.01 |    1559 |
|  42 |             UNION-ALL                                |                                |      1 |        |            |      1 |00:00:00.01 |    1559 |
|  43 |              NESTED LOOPS OUTER                      |                                |      1 |     78 |    29   (0)|      1 |00:00:00.01 |     402 |
|* 44 |               HASH JOIN RIGHT OUTER                  |                                |      1 |     78 |    28   (0)|      1 |00:00:00.01 |     402 |
|  45 |                TABLE ACCESS BY INDEX ROWID BATCHED   | V_DOMAINE                      |      1 |     36 |     1   (0)|    734 |00:00:00.01 |      63 |
|* 46 |                 INDEX RANGE SCAN                     | V_DOMAINE_TYPE_CODE_IDX        |      1 |     36 |     1   (0)|    734 |00:00:00.01 |      12 |
|  47 |                NESTED LOOPS                          |                                |      1 |     78 |    27   (0)|      1 |00:00:00.01 |     339 |
|  48 |                 NESTED LOOPS                         |                                |      1 |    412 |    27   (0)|      1 |00:00:00.01 |     338 |
|  49 |                  NESTED LOOPS                        |                                |      1 |    412 |    14   (0)|      1 |00:00:00.01 |     334 |
|  50 |                   NESTED LOOPS                       |                                |      1 |    412 |     2   (0)|      1 |00:00:00.01 |     330 |
|* 51 |                    INDEX RANGE SCAN                  | G_DOSSIER_RL_CD_RD_RF_IDX      |      1 |     32 |     1   (0)|    390 |00:00:00.01 |       7 |
|* 52 |                    INDEX RANGE SCAN                  | PK_AGGREG_T_ECRDOS_NMP         |    390 |     13 |     1   (0)|      1 |00:00:00.01 |     323 |
|  53 |                   TABLE ACCESS BY INDEX ROWID BATCHED| G_VENTILENC                    |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       4 |
|* 54 |                    INDEX RANGE SCAN                  | ALT_G_VENT_REF                 |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |
|* 55 |                  INDEX UNIQUE SCAN                   | REFENCAISS                     |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       4 |
|* 56 |                 TABLE ACCESS BY INDEX ROWID          | G_ENCAISSEMENT                 |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       1 |
|* 57 |               TABLE ACCESS BY INDEX ROWID            | NAM_COLLECTE                   |      1 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 58 |                INDEX UNIQUE SCAN                     | COLCOMPOSTAGE                  |      1 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|  59 |              NESTED LOOPS OUTER                      |                                |      1 |      1 |    88   (0)|      0 |00:00:00.01 |    1157 |
|  60 |               NESTED LOOPS                           |                                |      1 |      1 |    87   (0)|      0 |00:00:00.01 |    1157 |
|  61 |                NESTED LOOPS                          |                                |      1 |    934 |    49   (0)|      0 |00:00:00.01 |    1157 |
|  62 |                 NESTED LOOPS                         |                                |      1 |   1445 |     6   (0)|      0 |00:00:00.01 |    1157 |
|* 63 |                  INDEX RANGE SCAN                    | G_DOSSIER_RL_CD_RD_RF_IDX      |      1 |     32 |     1   (0)|    390 |00:00:00.01 |       7 |
|  64 |                  TABLE ACCESS BY INDEX ROWID BATCHED | G_VENTILENC                    |    390 |     45 |     1   (0)|      0 |00:00:00.01 |    1150 |
|* 65 |                   INDEX RANGE SCAN                   | G_VENTILENC_REFDOSS_TRAITE     |    390 |     45 |     1   (0)|      0 |00:00:00.01 |    1150 |
|* 66 |                 TABLE ACCESS BY INDEX ROWID          | G_ENCAISSEMENT                 |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 67 |                  INDEX UNIQUE SCAN                   | REFENCAISS                     |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 68 |                TABLE ACCESS BY INDEX ROWID BATCHED   | T_ELEMENTS                     |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 69 |                 INDEX RANGE SCAN                     | ELE_ELEMTYPE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|  70 |               TABLE ACCESS BY INDEX ROWID BATCHED    | V_DOMAINE                      |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 71 |                INDEX RANGE SCAN                      | DOM_TYPABREV                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|  72 |            TABLE ACCESS BY INDEX ROWID               | G_INDIVIDU                     |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       4 |
|* 73 |             INDEX UNIQUE SCAN                        | IND_REFINDIV                   |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |
|* 74 |           INDEX RANGE SCAN                           | INT_REFDOSS                    |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |
|* 75 |          INDEX RANGE SCAN                            | G_DOSSIER_REFDOSS_SOLDE_RANGMT |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |
|  76 |         TABLE ACCESS BY INDEX ROWID BATCHED          | G_PERSONNEL                    |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |
|* 77 |          INDEX RANGE SCAN                            | GPERSREFP                      |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       2 |
|  78 |        TABLE ACCESS BY INDEX ROWID                   | G_INDIVIDU                     |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       4 |
|* 79 |         INDEX UNIQUE SCAN                            | IND_REFINDIV                   |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |
|* 80 |       TABLE ACCESS BY INDEX ROWID                    | G_INDIVIDU                     |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       4 |
|* 81 |        INDEX UNIQUE SCAN                             | IND_REFINDIV                   |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |
--------------------------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   1 - filter(ROWNUM=1)
   2 - filter(("REFEXT2"=:B1 AND "SOCIETE"='CLIENT_NUMBER'))
   3 - access("REFINDIVIDU"=:B1)
   6 - filter("P"."STR_20_1" IS NOT NULL)
   7 - access("P"."REFDOSS"= AND "P"."TYPPIECE"='CONTRAT')
   8 - access("REFDOSS"=)
   9 - access("REFDOSS"=:B1)
  10 - access("P"."STR_20_1"="G"."REFINDIVIDU")
  14 - filter("P"."ST20" IS NOT NULL)
  15 - access("P"."REFDOSS"= AND "P"."TYPPIECE"='CONTRAT')
  16 - access("REFDOSS"=)
  17 - access("REFDOSS"=:B1)
  18 - access("P"."ST20"="G"."REFINDIVIDU")
  24 - access("CMT"."REFDOSS"=:B1)
  25 - access("CMT"."REFLOT"="DEC"."REFDOSS")
  26 - filter("CTR"."REFHIERARCHIE" IS NOT NULL)
  27 - access("DEC"."REFLOT"="CTR"."REFDOSS")
  28 - access("CTR"."REFHIERARCHIE"="REV"."REFDOSS")
  29 - filter("REV"."CATEGDOSS"='COMPTE DB CTR')
  31 - filter("RNUM">=:B5)
  32 - filter(ROWNUM<=:B4)
  34 - filter(ROWNUM<=:B4)
  41 - filter(NVL(DECODE("TBL"."TRAITE",'2',DECODE("TBL"."MATCHED_AMT",0,"TBL"."MONTANT_MVT","CH_TAUX"."CONVERSDOSMVT"("TBL"."DTJOUR","TBL"."REFDOSS",
              "TBL"."MONTANT_DOS"-"TBL"."MATCHED_AMT","TBL"."DEVISE_MVT",'A')),"TBL"."TRAITE",0,DECODE("TBL"."MATCHED_AMT",0,"TBL"."MONTANT_MVT","CH_TAUX"."CONVERSD
              OSMVT"("TBL"."DTJOUR","TBL"."REFDOSS","TBL"."MONTANT_DOS"-"TBL"."MATCHED_AMT","TBL"."DEVISE_MVT",'A'))),0)<>0)
  44 - access("D"."ABREV"=SUBSTR("TNMP"."LIEUPAIMT",1,3))
  46 - access("D"."TYPE"='NAM_COLLECTE')
  51 - access("GD"."REFLOT"=:B1 AND "GD"."CATEGDOSS" LIKE 'COMPTE%')
       filter("GD"."CATEGDOSS" LIKE 'COMPTE%')
  52 - access("GD"."REFDOSS"="TNMP"."REFDOSS")
       filter("TNMP"."BALANCE_DCPT"<0)
  54 - access("VENTIL"."REFENCAISS"="TNMP"."REFELEM" AND "VENTIL"."REFDOSS"="TNMP"."REFDOSS")
  55 - access("ENC"."REFENCAISS"="VENTIL"."REFENCAISS")
  56 - filter((INTERNAL_FUNCTION("ENC"."TYPENCAISS") AND NVL("DTENCAISS_DT","DTRECEPTION_DT")>=:B3 AND "ENC"."TRAITE"='2'))
  57 - filter(("NC"."REFER" IS NOT NULL AND "NC"."REFER"="ENC"."REFENCAISS"))
  58 - access("NC"."COMPOSTAGE"="TNMP"."LIEUPAIMT")
  63 - access("GD"."REFLOT"=:B1 AND "GD"."CATEGDOSS" LIKE 'COMPTE%')
       filter("GD"."CATEGDOSS" LIKE 'COMPTE%')
  65 - access("GD"."REFDOSS"="VENTIL"."REFDOSS" AND "VENTIL"."TRAITE"='0')
  66 - filter((INTERNAL_FUNCTION("ENC"."TYPENCAISS") AND NVL("DTENCAISS_DT","DTRECEPTION_DT")>=:B3))
  67 - access("ENC"."REFENCAISS"="VENTIL"."REFENCAISS")
  68 - filter("E"."REFDOSS"="VENTIL"."REFDOSS")
  69 - access("E"."REFELEM"="ENC"."REFENCAISS" AND "E"."TYPEELEM"='en')
  71 - access("D"."TYPE"='NAM_COLLECTE' AND "D"."ABREV"=SUBSTR("ENC"."LIEUPAIMT",1,3))
  73 - access("DB"."REFINDIVIDU"="TBL"."REFPAYEUR")
  74 - access("CLI"."REFDOSS"="TBL"."REFDOSS" AND "CLI"."REFTYPE"='CL')
  75 - access("DOSS"."REFDOSS"="TBL"."REFDOSS")
  77 - access("USR"."REFPERSO"="DOSS"."RANGMT")
  79 - access("USR"."REFINDIVIDU"="MAN"."REFINDIVIDU")
  80 - filter("CL"."NOM"||' '||"CL"."PRENOM" LIKE :B2||'%')
  81 - access("CLI"."REFINDIVIDU"="CL"."REFINDIVIDU")
*/
/********************************New Metrics***************************************/

/********************************Index statistics**********************************/

/********************************Other SQLs****************************************/          
/*

*/ 
/********************************Other SQLs****************************************/              
