#############################################################################
#############  How to Resize the Undo Tablespace in Oracle Database
 
This post provides the steps to resize the Undo tablespace.ie, to add space or shrink the current Undo tablespace.

Shrinking Undo Tablespace Size
Undo space once allocated will be available for reuse but will not be deallocated to the OS. 
The best way to shrink Undo tablespace is to switch to a new Undo tablespace and drop the old Undo tablespace. 

The steps are:

1. Create a new undo tablespace of the same size (larger or smaller) depending on your database requirements.

SQL> create undo tablespace UNDOTBS2 datafile 'D:\ORACLE\PRODUCT\11.2.0\ORADATA\ORCL\UNDOTBS02.DBF' size 5000M;


2. Switch to the new Undo tablespace:

SQL> ALTER SYSTEM SET UNDO_TABLESPACE = UNDOTBS2 SCOPE=BOTH;


3. Check the status of the undo segments and determine if all the segments in the old undo tablespace are offline.

sql> select tablespace_name, status, count(*) from dba_rollback_segs group by tablespace_name, status;


If there are Undo segments with a status other than OFFLINE in the tablespace to be dropped, we need to wait till they become OFFLINE. You may have to wait for the duration of the tuned_undoretention (from v$undostat) to ensure all Undo segments have become OFFLINE.

sql> select status,segment_name from dba_rollback_segs where status not in ("OFFLINE') and tablespace_name=[undo tablespace to be dropped];
For example:
sql> select status,segment_name from dba_rollback_segs where status not in ("OFFLINE') and tablespace_name='UNDOTBS1';


4. If all the Undo segments in the old Undo tablespace to the dropped is of status OFFLINE, then drop the tablespace.

sql> select tablespace_name, status, count(*) from dba_rollback_segs group by tablespace_name, status;


5. Verify and then drop:

sql> drop tablespace [tablespace_name] including contents and datafiles;

For example:
sql> drop tablespace UNDOTBS1 including contents and datafiles;


##############################################
###############################################
Add Space to the Undo Tablespace
For increasing / resize undo tablespace there are two options :

Resize the existing undo datafile
Add new undo datafile to the tablespace.
1. To resize the existing undo datafile:

col T_NAME for a23
col FILE_NAME for a65
select tablespace_name T_NAME,file_name, bytes/1024/1024 MB from dba_data_files where tablespace_name =(SELECT UPPER(value) FROM v$parameter WHERE name = 'undo_tablespace') order by file_name;

alter database datafile '[COMPLETE_PATH_OF_UNDO_DBF_FILE]' resize [SIZE]M;
For example:
sql> alter database datafile 'D:\ORACLE_DB\TESTDB\TESTDB\UNDOTBS01.DBF' resize 1500M;


2. Step to add a new datafile:

sql> alter tablespace [UNDO tbs name] ADD DATAFILE '[COMPLETE_PATH_OF_UNDO_DBF_FILE]' size 20M;
For example:
sql> alter tablespace UNDOTBS1 ADD DATAFILE 'D:\ORACLE_DB\TESTDB\TESTDB\UNDOTBS02.DBF' size 20M;
