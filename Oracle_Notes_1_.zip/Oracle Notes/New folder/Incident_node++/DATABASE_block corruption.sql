####### ERRORLOG: Corrupt block relative dba: 0x02c03403 (file 11, block 13315) ######
### Database block coruption ####

#### Output ot LOG FILE #####
dbspicao -l

Corrupt block relative dba: 0x02c03403 (file 11, block 13315)
Bad header found during buffer read (logical check)
Data in bad block:
 type: 6 format: 2 rdba: 0x02c03403
 last change scn: 0x0000.07d6.6b65f563 seq: 0x1 flg: 0x04
 spare3: 0x0
 consistency value in tail: 0xf5630601
 check value in block header: 0x9fd5
 computed block checksum: 0x0                              ##### В случая като показва 0x0 означава,че си е наваксало и си е оправило нещата, и затваряме кейса. #####
 


[root@fivatx0192 ~]# cd /dev
[root@fivatx0192 dev]# ll |grep asm



#### Check size database ####

col "Database Size" format a20
col "Free space" format a20
col "Used space" format a20
select    round(sum(used.bytes) / 1024 / 1024 / 1024   ) || ' GB' "Database Size"
,         round(sum(used.bytes) / 1024 / 1024 / 1024 ) - 
          round(free.p / 1024 / 1024 / 1024  ) || ' GB' "Used space"
,         round(free.p / 1024 / 1024 / 1024 ) || ' GB' "Free space"
from    (select     bytes
          from      v$datafile
          union     all
          select    bytes
          from      v$tempfile
          union     all
          select    bytes
          from      v$log) used
,         (select sum(bytes) as p
          from dba_free_space) free
group by free.p
/ 


##### Ако базата е много голяма над 500G командата (backup validate check logical database;) ако я пуснем ще върви много бажно и ще има performance degradation. ########

RMAN> backup validate check logical database;                      ##### Tazi komanda eventualno moje da q izpylnim,ako log-a pokazva razlichno ot 0x0 i to s pozvolenie #######
## RMAN does not physically backup the database with this command
## but it reads all blocks and checks for corruptions.
## if it finds corrupted blocks it will place the information about the corruption into a view:

#### Това вади corrupt-нати blocks #####

SQL> select * from v$database_block_corruption;



SQL> select * from v$database_block_corruption;

     FILE#     BLOCK#     BLOCKS CORRUPTION_CHANGE# CORRUPTIO
---------- ---------- ---------- ------------------ ---------
         9    2642666          1                  0 CHECKSUM


========================================================
#### В случай, че има каръпнат блок се изпълняват последователно следните команди през RMAN : (logical standby)
RMAN>
LIST FAILURE;
ADVISE FAILURE;
CHANGE FAILURE;
REPAIR FAILURE;

