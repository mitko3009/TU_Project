/********************************************************************************
*********       E-mail subject: ABSAWEB-2314
*********             Instance: PROD V9
*********          Description: 
Problem:
Three pilote call was provided as slow on ABSA PROD V9.

Analysis:
I analyzed the work of the msgq_pilote for the period between 12:45 and 13:05 on 08/07/2024 and the TOP three SQLs for this module was daujxjbr82ztz, 0dy0dvna24zfu and ctxsxppszxaf6. 
They were responsible for over 90% of the time. The problem in both of them are the OR operators, which doesn't allow Oracle to choose good execution plan. They should be rewritten to UNIONs 
as it is shown in the New SQL section below.

Suggestion:
Please check are the queries in the New SQL section below functionality correct and if they are, please change the queries as it is shown in the New SQL section below.

*********               SQL_ID: daujxjbr82ztz, 0dy0dvna24zfu, ctxsxppszxaf6
*********      Program/Package: 
*********              Request: Ivaylo Tsvetkov 
*********               Author: Dimitar Dimitrov
********* Received e-mail date: 09/07/2024
*********      Resolution date: 09/07/2024
*********  Trace old file here: \\epox\specifs\performance\tmp\
*********  Trace new file here:
***********************************************************************************/

/********************************OLD SQL*******************************************/

-- daujxjbr82ztz

var REFDOS VARCHAR2(32);
exec :REFDOS := '2203300034';

var B9 varchar2(32);
exec :B9 := 'INT00000';
exec utl_app_date.cacheAppDate(:B9);

insert into g_piecedet( refdoss, refpiece, type, dt01_dt, str1)
  select refdoss,
         refpiece,
         'CONTRACT SITUATIONS',
         utl_app_date.getAppDate,
         'T'
    from g_piece
   where ( ( refdoss = :refdos 
          or refdoss in ( select refdoss
                            from g_dossier
                           where refhierarchie = :refdos
                             and exists (select 1
                                           from g_piece p, 
                                                t_intervenants i
                                          where nvl(p.fg30, 'N') = 'O'
                                            and p.typpiece = 'CLIENT_PARAMS'
                                            and p.gpiheure = i.refindividu
                                            and i.refdoss = g_dossier.refdoss
                                            and i.reftype = 'CL' )
                             and exists ( select 1
                                            from g_piece
                                           where refdoss = g_dossier.refdoss
                                             and typpiece = 'CONTRAT'
                                             and nvl(gpiaccept, 'O') <> 'N') ) ) 
     and typpiece in ('CONTRAT', 'CONTRAT REV') 
     and 'T' = ( select d.str1
                   from g_piecedet D, 
                        g_piece P
                  where P.refdoss = :refdos
                    and P.refpiece = D.refpiece
                    and P.typpiece in ('A.CONTRAT', 'A.CONTRAT REV')
                    and D.type = 'CONTRACT SITUATIONS'
                    and rownum = 1
                    and d.dt01_dt = ( select max(D.dt01_dt)
                                        from g_piecedet D, 
                                             g_piece P
                                       where P.refdoss = :refdos
                                         and P.refpiece = D.refpiece
                                         and P.typpiece in ('A.CONTRAT', 'A.CONTRAT REV')
                                         and D.type = 'CONTRACT SITUATIONS' ) ) 
     and to_char(utl_app_date.getAppDate, 'j') > nvl(gpidtfin, '9999999') 
     and utl_app_date.getAppDate > ( select max(D.dt01_dt)
                                       from g_piecedet D, 
                                            g_piece P
                                      where P.refdoss = :refdos
                                        and P.refpiece = D.refpiece
                                        and P.typpiece in ('CONTRAT', 'CONTRAT REV')
                                        and D.type = 'CONTRACT SITUATIONS' ) )
      or ( ( refdoss in ( select refdoss 
                            from g_dossier 
                           where reflot = :refdos ) 
          or refdoss in ( select refdoss
                            from g_dossier
                           where reflot in ( select refdoss
                                               from g_dossier
                                              where refhierarchie = :refdos
                                                and exists ( select 1
                                                               from g_piece p, 
                                                                    t_intervenants i
                                                              where nvl(p.fg30, 'N') = 'O'
                                                                and p.typpiece = 'CLIENT_PARAMS'
                                                                and p.gpiheure = i.refindividu
                                                                and i.refdoss = g_dossier.refdoss
                                                                and i.reftype = 'CL' )
                                                and exists ( select 1
                                                               from g_piece
                                                              where refdoss = g_dossier.refdoss
                                                                and typpiece = 'CONTRAT'
                                                                and nvl(gpiaccept, 'O') <> 'N' ) ) ) ) 
     and typpiece = 'SOUS-CONTRAT' 
     and 'T' = ( select d.str1
                   from g_piecedet D, 
                        g_piece P
                  where P.refdoss = :refdos
                    and P.refpiece = D.refpiece
                    and P.typpiece in ('A.CONTRAT', 'A.CONTRAT REV')
                    and D.type = 'CONTRACT SITUATIONS'
                    and rownum = 1
                    and d.dt01_dt = ( select max(D.dt01_dt)
                                        from g_piecedet D, 
                                             g_piece P
                                       where P.refdoss = :refdos
                                         and P.refpiece = D.refpiece
                                         and P.typpiece in ('A.CONTRAT', 'A.CONTRAT REV')
                                         and D.type = 'CONTRACT SITUATIONS' ) ) 
     and to_char(utl_app_date.getAppDate, 'j') > nvl(gpidtfin, '9999999') 
     and utl_app_date.getAppDate > ( select max(D.dt01_dt)
                                       from g_piecedet D, 
                                            g_piece P
                                      where P.refdoss = :refdos
                                        and P.refpiece = D.refpiece
                                        and P.typpiece in ('CONTRAT', 'CONTRAT REV')
                                        and D.type = 'CONTRACT SITUATIONS' ) );

-- 0dy0dvna24zfu

var REFDOS VARCHAR2(32);
exec :REFDOS := '2203300034';

var B9 varchar2(32);
exec :B9 := 'INT00000';
exec utl_app_date.cacheAppDate(:B9);

insert into g_piecedet
  (refdoss, refpiece, type, dt01_dt, str1)
  select refdoss,
         refpiece,
         'CONTRACT SITUATIONS',
         utl_app_date.getAppDate,
         'V'
    from g_piece e
   where ((e.refdoss = :refdos or
         e.refdoss in
         (select refdoss
              from g_dossier
             where refhierarchie = :refdos
               and exists (select 1
                      from g_piece p, t_intervenants i
                     where nvl(p.fg30, 'N') = 'O'
                       and p.typpiece = 'CLIENT_PARAMS'
                       and p.gpiheure = i.refindividu
                       and i.refdoss = g_dossier.refdoss
                       and i.reftype = 'CL')
               and exists (select 1
                      from g_piece
                     where refdoss = g_dossier.refdoss
                       and typpiece = 'CONTRAT'
                       and nvl(gpiaccept, 'O') <> 'N'))) and
         e.typpiece in ('CONTRAT', 'CONTRAT REV') and exists
          (select '1'
             from g_piecedet D, g_piece P
            where P.refdoss = :refdos
              and P.refpiece = D.refpiece
              and ((d.str1 in
                  ('V', 'S', 'R', 'O', 'I', 'F', 'E', 'C', 'A', 'P')) or
                  (d.str1 = 'T' and to_char(utl_app_date.getAppDate, 'j') <=
                  nvl(e.gpidtfin, '9999999')))
              and P.typpiece in ('A.CONTRAT', 'A.CONTRAT REV')
              and D.type = 'CONTRACT SITUATIONS'
              and d.dt01_dt =
                  (select max(D.dt01_dt)
                     from g_piecedet D, g_piece P
                    where P.refdoss = :refdos
                      and P.refpiece = D.refpiece
                      and P.typpiece in ('A.CONTRAT', 'A.CONTRAT REV')
                      and D.type = 'CONTRACT SITUATIONS')) and
          utl_app_date.getAppDate >
          (select max(D.dt01_dt)
             from g_piecedet D, g_piece P
            where P.refdoss = :refdos
              and P.refpiece = D.refpiece
              and P.typpiece in ('CONTRAT', 'CONTRAT REV')
              and D.type = 'CONTRACT SITUATIONS'))
      or ((e.refdoss in
         (select refdoss from g_dossier where reflot = :refdos) or
         e.refdoss in
         (select refdoss
              from g_dossier
             where reflot in
                   (select refdoss
                      from g_dossier
                     where refhierarchie = :refdos
                       and exists (select 1
                              from g_piece p, t_intervenants i
                             where nvl(p.fg30, 'N') = 'O'
                               and p.typpiece = 'CLIENT_PARAMS'
                               and p.gpiheure = i.refindividu
                               and i.refdoss = g_dossier.refdoss
                               and i.reftype = 'CL')
                       and exists
                     (select 1
                              from g_piece
                             where refdoss = g_dossier.refdoss
                               and typpiece = 'CONTRAT'
                               and nvl(gpiaccept, 'O') <> 'N')))) and
         e.typpiece = 'SOUS-CONTRAT' and exists
          (select '1'
             from g_piecedet D, g_piece P
            where P.refdoss = :refdos
              and P.refpiece = D.refpiece
              and ((d.str1 in
                  ('V', 'S', 'R', 'O', 'I', 'F', 'E', 'C', 'A', 'P')) or
                  (d.str1 = 'T' and to_char(utl_app_date.getAppDate, 'j') <=
                  nvl(e.gpidtfin, '9999999')))
              and P.typpiece in ('A.CONTRAT', 'A.CONTRAT REV')
              and D.type = 'CONTRACT SITUATIONS'
              and d.dt01_dt =
                  (select max(D.dt01_dt)
                     from g_piecedet D, g_piece P
                    where P.refdoss = :refdos
                      and P.refpiece = D.refpiece
                      and P.typpiece in ('A.CONTRAT', 'A.CONTRAT REV')
                      and D.type = 'CONTRACT SITUATIONS')) and
          utl_app_date.getAppDate >
          (select max(D.dt01_dt)
             from g_piecedet D, g_piece P
            where P.refdoss = :refdos
              and P.refpiece = D.refpiece
              and P.typpiece in ('CONTRAT', 'CONTRAT REV')
              and D.type = 'CONTRACT SITUATIONS'));


-- ctxsxppszxaf6

var REFDOS VARCHAR2(32);
exec :REFDOS := '0509300094';

var B9 varchar2(32);
exec :B9 := 'INT00000';
exec utl_app_date.cacheAppDate(:B9);

insert into g_piecedet (refdoss, refpiece, type, dt01_dt, str1)
  select refdoss,
         refpiece,
         'CONTRACT SITUATIONS',
         to_date(to_char( ( select max(Dr.dt01_dt)
                              from g_piecedet Dr, 
                                   g_piece Pr
                             where Pr.refdoss = :refdos
                               and Pr.refpiece = Dr.refpiece
                               and Pr.typpiece in ('CONTRAT', 'CONTRAT REV')
                               and Dr.type = 'CONTRACT SITUATIONS' ),
                         'jsssss') + 1,
                         'jsssss'),
         'V'
    from g_piece
   where ( ( ( refdoss = :refdos 
            or refdoss in ( select refdoss
                              from g_dossier
                             where refhierarchie = :refdos
                               and exists ( select 1
                                              from g_piece p, 
                                                   t_intervenants i
                                             where nvl(p.fg30, 'N') = 'O'
                                               and p.typpiece = 'CLIENT_PARAMS'
                                               and p.gpiheure = i.refindividu
                                               and i.refdoss = g_dossier.refdoss
                                               and i.reftype = 'CL' )
                               and exists ( select 1
                                              from g_piece
                                             where refdoss = g_dossier.refdoss
                                               and typpiece = 'CONTRAT'
                                               and nvl(gpiaccept, 'O') <> 'N' ) ) )
     and typpiece in ('CONTRAT', 'CONTRAT REV') 
     and utl_app_date.getAppDate <= ( select max(D.dt01_dt)
                                        from g_piecedet D, 
                                             g_piece P
                                       where P.refdoss = :refdos
                                         and P.refpiece = D.refpiece
                                         and P.typpiece in ('CONTRAT', 'CONTRAT REV')
                                         and D.type = 'CONTRACT SITUATIONS'
                                         and D.str1 != 'V' ) ) 
       or
         ( ( refdoss in ( select refdoss 
                            from g_dossier 
                           where reflot = :refdos ) 
          or refdoss in ( select refdoss
                            from g_dossier
                            where reflot in ( select refdoss
                                                from g_dossier
                                               where refhierarchie = :refdos
                                                 and exists ( select 1
                                                                from g_piece p, 
                                                                     t_intervenants i
                                                               where nvl(p.fg30, 'N') = 'O'
                                                                 and p.typpiece = 'CLIENT_PARAMS'
                                                                 and p.gpiheure = i.refindividu
                                                                 and i.refdoss = g_dossier.refdoss
                                                                 and i.reftype = 'CL' )
                                                 and exists ( select 1
                                                                from g_piece
                                                               where refdoss = g_dossier.refdoss
                                                                 and typpiece = 'CONTRAT'
                                                                 and nvl(gpiaccept, 'O') <> 'N') ) ) ) 
         and typpiece = 'SOUS-CONTRAT' 
         and utl_app_date.getAppDate <= ( select max(D.dt01_dt)
                                            from g_piecedet D, 
                                                 g_piece P
                                           where P.refdoss = :refdos
                                             and P.refpiece = D.refpiece
                                             and P.typpiece in ('CONTRAT', 'CONTRAT REV')
                                             and D.type = 'CONTRACT SITUATIONS'
                                             and D.str1 != 'V' ) ) )
     and 0 = ( select count(*)
                 from g_piece Pa, 
                      g_piecedet Da
                where Pa.refdoss = :refdos
                  and Pa.refpiece = Da.refpiece
                  and Pa.typpiece in ('CONTRAT', 'CONTRAT REV')
                  and Da.type = 'CONTRACT SITUATIONS'
                  and Da.str1 = 'V' );
/********************************OLD SQL*******************************************/
/********************************OLD Metrics***************************************/
/*
MODULE                    SQL_ID         PLAN_HASH SID    SERIAL# EVENT                          FROM                           TO                                 ACTIVE NUMBER_OF_EXECUTIONS PERC
------------------------- ------------- ---------- ------ ------- ------------------------------ ------------------------------ ------------------------------ ---------- -------------------- ------
msgq_pilote                                                                                      2024/07/08 12:49:01            2024/07/08 13:04:55                  1710         1142129 85%
EXTRANET                                                          ON CPU                         2024/07/08 12:47:51            2024/07/08 13:03:35                   100  777721 5%
msgq_ecrit                                                                                       2024/07/08 12:48:31            2024/07/08 12:49:11                    30         9946867 1%
msgq_calfidec                                      716    61463   ON CPU                         2024/07/08 12:48:51            2024/07/08 12:49:01                    20    6947 1%
msgq_chkcess                             891380090                                               2024/07/08 12:48:21            2024/07/08 12:56:33                    20       1 1%
msgq_memo_decompte_pmtval                                         ON CPU                         2024/07/08 12:48:41            2024/07/08 12:48:41                    20         9943420 1%
E_PMTVAL                                         0                ON CPU                         2024/07/08 12:47:51            2024/07/08 13:03:35                    20         1%
E_AFF_DOSCLI1             6pj9r5vbdk2yq   41573073                ON CPU                         2024/07/08 12:50:41            2024/07/08 12:51:21                    20      36 1%
prm_pack                  aq5gnh9tt722d          0 438    46777   ON CPU                         2024/07/08 13:02:44            2024/07/08 13:02:44                    10         0%
sqlplus                   NULL                     1572   59495   ON CPU                         2024/07/08 12:50:51            2024/07/08 12:50:51                    10         0%
asf_eddebtor2imx          NULL                     1438   9452    ON CPU                         2024/07/08 12:46:51            2024/07/08 12:46:51                    10         0%
QvOdbcConnectorPackage.ex a5pw92uvapbcv 2320185790 1572   7369    ON CPU                         2024/07/08 12:50:11            2024/07/08 12:50:11                    10       1 0%
e

PT_SNAP_SESSION           a9h9jbc76mc19 2832904052 435    1635    ON CPU                         2024/07/08 13:00:13            2024/07/08 13:00:13                    10       1 0%
E_VICHRODV                023zjv4sw4wgv 3679484294 866    23062   ON CPU                         2024/07/08 12:52:01            2024/07/08 12:52:01                    10       1 0%
msgq                      NULL                     716    61463   log file sync                  2024/07/08 12:48:41            2024/07/08 12:48:41                    10         0%


MODULE                    PROGRAM              SQL_ID         PLAN_HASH SID    SERIAL# EVENT                          FROM                           TO                    ACTIVE NUMBER_OF_EXECUTIONS PERC
------------------------- -------------------- ------------- ---------- ------ ------- ------------------------------ ------------------------------ ------------------------------ ---------- -------------------- ------
msgq_pilote               msg_q02                                       716    48578                                  2024/07/08 12:50:21            2024/07/08 13:04:55      880                     1 51%
msgq_pilote               msg_q04                                       438    46777                                  2024/07/08 12:49:01            2024/07/08 13:02:54      830               1142129 49%


MODULE                    PROGRAM              SQL_ID         PLAN_HASH SID    SERIAL# EVENT                          FROM                           TO                    ACTIVE NUMBER_OF_EXECUTIONS PERC
------------------------- -------------------- ------------- ---------- ------ ------- ------------------------------ ------------------------------ ------------------------------ ---------- -------------------- ------
msgq_pilote               msg_q04                                       438    46777                                  2024/07/08 12:49:01            2024/07/08 13:02:54      830               1142129 100%



BUFF                                         PRTY TO_CHAR(DATETR_DT,'DD/MM/YYYYHH24:MI:SS')                  TO_CHAR(DTPROCESS_DT,'DD/MM/YYYYHH24:MI:SS')              TO_CHAR(DT_ENDPROC_DT,'DD/MM/YYYYHH24:MI:SS')             CREATEUR                                                            
------------------------------------------------------------------------------------------------------------------------------------- ---------- --------------------------------------------------------- --------------------------------------------------------- --------------------------------
pilote@1104070005@SE@/dev/bkg@99               99 08/07/2024 12:48:56                                       08/07/2024 12:48:56                                       08/07/2024 13:03:01                                       msg_q04@prodintranet (TNS V1-V3)[msgq_processABS];28529;438,46777    
pilote@1104070005@SE@/dev/bkg@99               99 08/07/2024 12:48:56                                       08/07/2024 13:03:01                                       08/07/2024 13:03:01                                       msg_q04@prodintranet (TNS V1-V3)[msgq_processABS];28529;438,46777    
pilote@1104070005@¿@/dev/ttyE0054@144          99 08/07/2024 12:49:04                                       08/07/2024 13:03:01                                       08/07/2024 13:03:01                                       E_FHSEL                                                              




BUFF           MSGSEQ REFDOSS    PROCESSEDB LOCKEDBY                                 DATETR_DT           DTPROCESS_DT        DT_ENDPROC_DT       PARENT_MSGSEQ
---------- ---------- ---------- ---------- ---------------------------------------- ------------------- ------------------- ------------------- -------------
pilote@     114816089 1104070005 msg_q04                                             2024-07-08 12:48:56 2024-07-08 12:48:56 2024-07-08 13:03:01     114816088
pilote@     114816090 1104070005 msg_q04                                             2024-07-08 12:48:56 2024-07-08 13:03:01 2024-07-08 13:03:01     114816089



MODULE                    PROGRAM              SQL_ID         PLAN_HASH SID    SERIAL# EVENT                          FROM                           TO                                 ACTIVE NUMBER_OF_EXECUTIONS PERC
------------------------- -------------------- ------------- ---------- ------ ------- ------------------------------ ------------------------------ ------------------------------ ---------- -------------------- ------
msgq_pilote               msg_q04                                       438    46777   db file sequential read        2024/07/08 12:49:01            2024/07/08 13:00:54                   520                     1 63%
msgq_pilote               msg_q04                                       438    46777   direct path read               2024/07/08 12:49:51            2024/07/08 12:56:33                   130                     1 16%
msgq_pilote               msg_q04                                       438    46777   ON CPU                         2024/07/08 12:49:31            2024/07/08 13:02:54                   120               1142129 14%
msgq_pilote               msg_q04              ctxsxppszxaf6 2806067950 438    46777   db file scattered read         2024/07/08 13:01:14            2024/07/08 13:02:14                    40                     1 5%
msgq_pilote               msg_q04              ctxsxppszxaf6 2806067950 438    46777   direct path write temp         2024/07/08 13:01:44            2024/07/08 13:01:44                    10                     1 1%
msgq_pilote               msg_q04              ctxsxppszxaf6 2806067950 438    46777   direct path read temp          2024/07/08 13:02:34            2024/07/08 13:02:34                    10                     1 1%

MODULE                    PROGRAM              SQL_ID         PLAN_HASH SID    SERIAL# EVENT                          FROM                           TO                                 ACTIVE NUMBER_OF_EXECUTIONS PERC
------------------------- -------------------- ------------- ---------- ------ ------- ------------------------------ ------------------------------ ------------------------------ ---------- -------------------- ------
msgq_pilote               msg_q04              daujxjbr82ztz 2103321890 438    46777                                  2024/07/08 12:49:41            2024/07/08 12:55:13                   340                     1 41%
msgq_pilote               msg_q04              0dy0dvna24zfu 3815622967 438    46777                                  2024/07/08 12:55:23            2024/07/08 13:00:54                   340                     1 41%
msgq_pilote               msg_q04              ctxsxppszxaf6 2806067950 438    46777                                  2024/07/08 13:01:04            2024/07/08 13:02:34                   100                     1 12%
msgq_pilote               msg_q04              g279d8m3r8t53 3924234651 438    46777   db file sequential read        2024/07/08 12:49:01            2024/07/08 12:49:21                    30                     1 4%
msgq_pilote               msg_q04              47app8dk49xd1          0 438    46777   ON CPU                         2024/07/08 12:49:31            2024/07/08 12:49:31                    10                       1%
msgq_pilote               msg_q04              579pc27w27zjy  555409519 438    46777   ON CPU                         2024/07/08 13:02:54            2024/07/08 13:02:54                    10                     1 1%



SQL_ID                                     ELAPSED                     GETS      READS       ROWS  ELAP/EXEC  GETS/EXEC READS/EXEC  ROWS/EXEC       EXEC PLAN_HASH_VALUE
--------------------------------------- ---------- ------------------------ ---------- ---------- ---------- ---------- ---------- ---------- ---------- ---------------
0dy0dvna24zfu                           477.822698                 11662590    8619509          0     477.82   11662590    8619509          0          0      3815622967
daujxjbr82ztz                           760.067163                 15302443    9600550          0     380.03  7651221.5    4800275          0          2      2103321890


-- daujxjbr82ztz

Plan hash value: 2103321890
--------------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                    | Name              | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  |
--------------------------------------------------------------------------------------------------------------------------------------------------
|   0 | INSERT STATEMENT                             |                   |      1 |        |   936K(100)|      0 |00:00:00.01 |       0 |      0 |
|   1 |  LOAD TABLE CONVENTIONAL                     | G_PIECEDET        |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*  2 |   FILTER                                     |                   |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*  3 |    TABLE ACCESS FULL                         | G_PIECE           |      1 |   1595K|   936K  (1)|    625 |00:00:09.48 |     246K|    246K|
|*  4 |    TABLE ACCESS BY INDEX ROWID               | G_DOSSIER         |    224 |      1 |     1   (0)|      0 |00:00:00.01 |     674 |      0 |
|*  5 |     INDEX UNIQUE SCAN                        | DOS_REFDOSS       |    224 |      1 |     1   (0)|    224 |00:00:00.01 |     450 |      0 |
|   6 |    NESTED LOOPS                              |                   |    224 |      1 |     5   (0)|      0 |00:00:00.01 |     908 |      0 |
|   7 |     NESTED LOOPS                             |                   |    224 |      1 |     5   (0)|      0 |00:00:00.01 |     908 |      0 |
|   8 |      NESTED LOOPS SEMI                       |                   |    224 |      1 |     4   (0)|      0 |00:00:00.01 |     908 |      0 |
|   9 |       NESTED LOOPS                           |                   |    224 |      1 |     3   (0)|      0 |00:00:00.01 |     908 |      0 |
|  10 |        NESTED LOOPS                          |                   |    224 |      1 |     2   (0)|      0 |00:00:00.01 |     908 |      0 |
|  11 |         TABLE ACCESS BY INDEX ROWID          | G_DOSSIER         |    224 |      1 |     1   (0)|    224 |00:00:00.01 |     674 |      0 |
|* 12 |          INDEX UNIQUE SCAN                   | DOS_REFDOSS       |    224 |      1 |     1   (0)|    224 |00:00:00.01 |     450 |      0 |
|* 13 |         INDEX RANGE SCAN                     | REFHIERARCHIE_IDX |    224 |      1 |     1   (0)|      0 |00:00:00.01 |     234 |      0 |
|* 14 |        INDEX RANGE SCAN                      | INT_REFDOSS       |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 15 |       TABLE ACCESS BY INDEX ROWID BATCHED    | G_PIECE           |      0 |    565 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 16 |        INDEX RANGE SCAN                      | PIE_REFDOSS       |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 17 |      INDEX RANGE SCAN                        | GP_GRTYPE_MT_DT   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 18 |     TABLE ACCESS BY INDEX ROWID              | G_PIECE           |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 19 |    COUNT STOPKEY                             |                   |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  20 |     NESTED LOOPS                             |                   |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|  21 |      NESTED LOOPS                            |                   |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|  22 |       INLIST ITERATOR                        |                   |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  23 |        TABLE ACCESS BY INDEX ROWID BATCHED   | G_PIECE           |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 24 |         INDEX RANGE SCAN                     | PIE_REFDOSS       |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 25 |       INDEX RANGE SCAN                       | G_PIECEDET_REFP   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|  26 |        SORT AGGREGATE                        |                   |      0 |      1 |            |      0 |00:00:00.01 |       0 |      0 |
|  27 |         NESTED LOOPS                         |                   |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|  28 |          INLIST ITERATOR                     |                   |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  29 |           TABLE ACCESS BY INDEX ROWID BATCHED| G_PIECE           |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 30 |            INDEX RANGE SCAN                  | PIE_REFDOSS       |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 31 |          INDEX RANGE SCAN                    | G_PIECEDET_REFP   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|  32 |      TABLE ACCESS BY INDEX ROWID             | G_PIECEDET        |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|  33 |    SORT AGGREGATE                            |                   |      0 |      1 |            |      0 |00:00:00.01 |       0 |      0 |
|  34 |     NESTED LOOPS                             |                   |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|  35 |      INLIST ITERATOR                         |                   |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  36 |       TABLE ACCESS BY INDEX ROWID BATCHED    | G_PIECE           |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 37 |        INDEX RANGE SCAN                      | PIE_REFDOSS       |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 38 |      INDEX RANGE SCAN                        | G_PIECEDET_REFP   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 39 |    COUNT STOPKEY                             |                   |      1 |        |            |      1 |00:00:00.01 |      57 |      0 |
|  40 |     NESTED LOOPS                             |                   |      1 |      1 |     2   (0)|      1 |00:00:00.01 |      57 |      0 |
|  41 |      NESTED LOOPS                            |                   |      1 |      1 |     2   (0)|      1 |00:00:00.01 |      56 |      0 |
|  42 |       INLIST ITERATOR                        |                   |      1 |        |            |      5 |00:00:00.01 |       9 |      0 |
|  43 |        TABLE ACCESS BY INDEX ROWID BATCHED   | G_PIECE           |      1 |      1 |     1   (0)|      5 |00:00:00.01 |       9 |      0 |
|* 44 |         INDEX RANGE SCAN                     | PIE_REFDOSS       |      1 |      1 |     1   (0)|      5 |00:00:00.01 |       4 |      0 |
|* 45 |       INDEX RANGE SCAN                       | G_PIECEDET_REFP   |      5 |      1 |     1   (0)|      1 |00:00:00.01 |      47 |      0 |
|  46 |        SORT AGGREGATE                        |                   |      1 |      1 |            |      1 |00:00:00.01 |      30 |      0 |
|  47 |         NESTED LOOPS                         |                   |      1 |      1 |     2   (0)|     22 |00:00:00.01 |      30 |      0 |
|  48 |          INLIST ITERATOR                     |                   |      1 |        |            |      5 |00:00:00.01 |      13 |      0 |
|  49 |           TABLE ACCESS BY INDEX ROWID BATCHED| G_PIECE           |      2 |      1 |     1   (0)|      5 |00:00:00.01 |      13 |      0 |
|* 50 |            INDEX RANGE SCAN                  | PIE_REFDOSS       |      2 |      1 |     1   (0)|      5 |00:00:00.01 |       8 |      0 |
|* 51 |          INDEX RANGE SCAN                    | G_PIECEDET_REFP   |      5 |      1 |     1   (0)|     22 |00:00:00.01 |      17 |      0 |
|  52 |      TABLE ACCESS BY INDEX ROWID             | G_PIECEDET        |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       1 |      0 |
|  53 |    NESTED LOOPS                              |                   |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|  54 |     NESTED LOOPS                             |                   |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|  55 |      NESTED LOOPS SEMI                       |                   |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|  56 |       NESTED LOOPS                           |                   |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 57 |        INDEX RANGE SCAN                      | REFHIERARCHIE_IDX |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 58 |        INDEX RANGE SCAN                      | INT_REFDOSS       |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 59 |       TABLE ACCESS BY INDEX ROWID BATCHED    | G_PIECE           |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 60 |        INDEX RANGE SCAN                      | PIE_REFDOSS       |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 61 |      INDEX RANGE SCAN                        | GP_GRTYPE_MT_DT   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 62 |     TABLE ACCESS BY INDEX ROWID              | G_PIECE           |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|  63 |    SORT AGGREGATE                            |                   |      0 |      1 |            |      0 |00:00:00.01 |       0 |      0 |
|  64 |     NESTED LOOPS                             |                   |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|  65 |      INLIST ITERATOR                         |                   |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  66 |       TABLE ACCESS BY INDEX ROWID BATCHED    | G_PIECE           |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 67 |        INDEX RANGE SCAN                      | PIE_REFDOSS       |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 68 |      INDEX RANGE SCAN                        | G_PIECEDET_REFP   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
--------------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   2 - filter((("TYPPIECE"='SOUS-CONTRAT' AND ( IS NOT NULL OR  IS NOT NULL) AND ='T' AND "UTL_APP_DATE"."GETAPPDATE"()>) OR
              (INTERNAL_FUNCTION("TYPPIECE") AND ='T' AND ("REFDOSS"=:REFDOS OR  IS NOT NULL) AND "UTL_APP_DATE"."GETAPPDATE"()>)))
   3 - filter(TO_NUMBER(TO_CHAR("UTL_APP_DATE"."GETAPPDATE"(),'j'))>NVL("GPIDTFIN",9999999))
   4 - filter("REFLOT"=:REFDOS)
   5 - access("REFDOSS"=:B1)
  12 - access("REFDOSS"=:B1)
  13 - access("REFHIERARCHIE"=:REFDOS AND "REFLOT"="REFDOSS")
       filter("REFLOT"="REFDOSS")
  14 - access("I"."REFDOSS"="G_DOSSIER"."REFDOSS" AND "I"."REFTYPE"='CL')
  15 - filter(NVL("GPIACCEPT",'O')<>'N')
  16 - access("REFDOSS"="G_DOSSIER"."REFDOSS" AND "TYPPIECE"='CONTRAT')
       filter("REFDOSS" IS NOT NULL)
  17 - access("P"."TYPPIECE"='CLIENT_PARAMS' AND "P"."GPIHEURE"="I"."REFINDIVIDU")
       filter("P"."GPIHEURE" IS NOT NULL)
  18 - filter(NVL("P"."FG30",'N')='O')
  19 - filter(ROWNUM=1)
  24 - access("P"."REFDOSS"=:REFDOS AND (("P"."TYPPIECE"='A.CONTRAT' OR "P"."TYPPIECE"='A.CONTRAT REV')))
  25 - access("P"."REFPIECE"="D"."REFPIECE" AND "D"."TYPE"='CONTRACT SITUATIONS' AND "D"."DT01_DT"=)
  30 - access("P"."REFDOSS"=:REFDOS AND (("P"."TYPPIECE"='A.CONTRAT' OR "P"."TYPPIECE"='A.CONTRAT REV')))
  31 - access("P"."REFPIECE"="D"."REFPIECE" AND "D"."TYPE"='CONTRACT SITUATIONS')
       filter("D"."DT01_DT" IS NOT NULL)
  37 - access("P"."REFDOSS"=:REFDOS AND (("P"."TYPPIECE"='CONTRAT' OR "P"."TYPPIECE"='CONTRAT REV')))
  38 - access("P"."REFPIECE"="D"."REFPIECE" AND "D"."TYPE"='CONTRACT SITUATIONS')
       filter("D"."DT01_DT" IS NOT NULL)
  39 - filter(ROWNUM=1)
  44 - access("P"."REFDOSS"=:REFDOS AND (("P"."TYPPIECE"='A.CONTRAT' OR "P"."TYPPIECE"='A.CONTRAT REV')))
  45 - access("P"."REFPIECE"="D"."REFPIECE" AND "D"."TYPE"='CONTRACT SITUATIONS' AND "D"."DT01_DT"=)
  50 - access("P"."REFDOSS"=:REFDOS AND (("P"."TYPPIECE"='A.CONTRAT' OR "P"."TYPPIECE"='A.CONTRAT REV')))
  51 - access("P"."REFPIECE"="D"."REFPIECE" AND "D"."TYPE"='CONTRACT SITUATIONS')
       filter("D"."DT01_DT" IS NOT NULL)
  57 - access("REFHIERARCHIE"=:REFDOS AND "REFDOSS"=:B1)
       filter("REFDOSS"=:B1)
  58 - access("I"."REFDOSS"=:B1 AND "I"."REFTYPE"='CL')
  59 - filter(NVL("GPIACCEPT",'O')<>'N')
  60 - access("REFDOSS"=:B1 AND "TYPPIECE"='CONTRAT')
       filter("REFDOSS"="G_DOSSIER"."REFDOSS")
  61 - access("P"."TYPPIECE"='CLIENT_PARAMS' AND "P"."GPIHEURE"="I"."REFINDIVIDU")
       filter("P"."GPIHEURE" IS NOT NULL)
  62 - filter(NVL("P"."FG30",'N')='O')
  67 - access("P"."REFDOSS"=:REFDOS AND (("P"."TYPPIECE"='CONTRAT' OR "P"."TYPPIECE"='CONTRAT REV')))
  68 - access("P"."REFPIECE"="D"."REFPIECE" AND "D"."TYPE"='CONTRACT SITUATIONS')
       filter("D"."DT01_DT" IS NOT NULL)

-- 0dy0dvna24zfu

Plan hash value: 3815622967
-------------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                   | Name              | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  |
-------------------------------------------------------------------------------------------------------------------------------------------------
|   0 | INSERT STATEMENT                            |                   |      1 |        |   936K(100)|      0 |00:00:00.01 |       0 |      0 |
|   1 |  LOAD TABLE CONVENTIONAL                    | G_PIECEDET        |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*  2 |   FILTER                                    |                   |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
|   3 |    TABLE ACCESS FULL                        | G_PIECE           |      1 |     31M|   936K  (1)|   6821K|00:00:19.16 |     704K|    705K|
|   4 |    NESTED LOOPS                             |                   |    178 |      1 |     2   (0)|    178 |00:00:00.01 |    4140 |      0 |
|   5 |     NESTED LOOPS                            |                   |    178 |      1 |     2   (0)|    178 |00:00:00.01 |    3962 |      0 |
|   6 |      INLIST ITERATOR                        |                   |    178 |        |            |    890 |00:00:00.01 |    1083 |      0 |
|   7 |       TABLE ACCESS BY INDEX ROWID BATCHED   | G_PIECE           |    178 |      1 |     1   (0)|    890 |00:00:00.01 |    1083 |      0 |
|*  8 |        INDEX RANGE SCAN                     | PIE_REFDOSS       |    178 |      1 |     1   (0)|    890 |00:00:00.01 |     193 |      0 |
|*  9 |      INDEX RANGE SCAN                       | G_PIECEDET_REFP   |    890 |      1 |     1   (0)|    178 |00:00:00.01 |    2879 |      0 |
|  10 |       SORT AGGREGATE                        |                   |      1 |      1 |            |      1 |00:00:00.01 |      30 |      0 |
|  11 |        NESTED LOOPS                         |                   |      1 |      1 |     2   (0)|     22 |00:00:00.01 |      30 |      0 |
|  12 |         INLIST ITERATOR                     |                   |      1 |        |            |      5 |00:00:00.01 |      13 |      0 |
|  13 |          TABLE ACCESS BY INDEX ROWID BATCHED| G_PIECE           |      2 |      1 |     1   (0)|      5 |00:00:00.01 |      13 |      0 |
|* 14 |           INDEX RANGE SCAN                  | PIE_REFDOSS       |      2 |      1 |     1   (0)|      5 |00:00:00.01 |       8 |      0 |
|* 15 |         INDEX RANGE SCAN                    | G_PIECEDET_REFP   |      5 |      1 |     1   (0)|     22 |00:00:00.01 |      17 |      0 |
|* 16 |     TABLE ACCESS BY INDEX ROWID             | G_PIECEDET        |    178 |      1 |     1   (0)|    178 |00:00:00.01 |     178 |      0 |
|* 17 |    TABLE ACCESS BY INDEX ROWID              | G_DOSSIER         |    318 |      1 |     1   (0)|      0 |00:00:00.01 |     958 |      0 |
|* 18 |     INDEX UNIQUE SCAN                       | DOS_REFDOSS       |    318 |      1 |     1   (0)|    318 |00:00:00.01 |     640 |      0 |
|  19 |    NESTED LOOPS                             |                   |    318 |      1 |     5   (0)|      0 |00:00:00.01 |    1286 |      0 |
|  20 |     NESTED LOOPS                            |                   |    318 |      1 |     5   (0)|      0 |00:00:00.01 |    1286 |      0 |
|  21 |      NESTED LOOPS SEMI                      |                   |    318 |      1 |     4   (0)|      0 |00:00:00.01 |    1286 |      0 |
|  22 |       NESTED LOOPS                          |                   |    318 |      1 |     3   (0)|      0 |00:00:00.01 |    1286 |      0 |
|  23 |        NESTED LOOPS                         |                   |    318 |      1 |     2   (0)|      0 |00:00:00.01 |    1286 |      0 |
|  24 |         TABLE ACCESS BY INDEX ROWID         | G_DOSSIER         |    318 |      1 |     1   (0)|    318 |00:00:00.01 |     958 |      0 |
|* 25 |          INDEX UNIQUE SCAN                  | DOS_REFDOSS       |    318 |      1 |     1   (0)|    318 |00:00:00.01 |     640 |      0 |
|* 26 |         INDEX RANGE SCAN                    | REFHIERARCHIE_IDX |    318 |      1 |     1   (0)|      0 |00:00:00.01 |     328 |      0 |
|* 27 |        INDEX RANGE SCAN                     | INT_REFDOSS       |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 28 |       TABLE ACCESS BY INDEX ROWID BATCHED   | G_PIECE           |      0 |    565 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 29 |        INDEX RANGE SCAN                     | PIE_REFDOSS       |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 30 |      INDEX RANGE SCAN                       | GP_GRTYPE_MT_DT   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 31 |     TABLE ACCESS BY INDEX ROWID             | G_PIECE           |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|  32 |    SORT AGGREGATE                           |                   |      0 |      1 |            |      0 |00:00:00.01 |       0 |      0 |
|  33 |     NESTED LOOPS                            |                   |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|  34 |      INLIST ITERATOR                        |                   |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  35 |       TABLE ACCESS BY INDEX ROWID BATCHED   | G_PIECE           |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 36 |        INDEX RANGE SCAN                     | PIE_REFDOSS       |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 37 |      INDEX RANGE SCAN                       | G_PIECEDET_REFP   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|  38 |    NESTED LOOPS                             |                   |    179 |      1 |     2   (0)|    179 |00:00:00.01 |    4163 |      0 |
|  39 |     NESTED LOOPS                            |                   |    179 |      1 |     2   (0)|    179 |00:00:00.01 |    3984 |      0 |
|  40 |      INLIST ITERATOR                        |                   |    179 |        |            |    895 |00:00:00.01 |    1089 |      0 |
|  41 |       TABLE ACCESS BY INDEX ROWID BATCHED   | G_PIECE           |    179 |      1 |     1   (0)|    895 |00:00:00.01 |    1089 |      0 |
|* 42 |        INDEX RANGE SCAN                     | PIE_REFDOSS       |    179 |      1 |     1   (0)|    895 |00:00:00.01 |     194 |      0 |
|* 43 |      INDEX RANGE SCAN                       | G_PIECEDET_REFP   |    895 |      1 |     1   (0)|    179 |00:00:00.01 |    2895 |      0 |
|  44 |       SORT AGGREGATE                        |                   |      1 |      1 |            |      1 |00:00:00.01 |      30 |      0 |
|  45 |        NESTED LOOPS                         |                   |      1 |      1 |     2   (0)|     22 |00:00:00.01 |      30 |      0 |
|  46 |         INLIST ITERATOR                     |                   |      1 |        |            |      5 |00:00:00.01 |      13 |      0 |
|  47 |          TABLE ACCESS BY INDEX ROWID BATCHED| G_PIECE           |      2 |      1 |     1   (0)|      5 |00:00:00.01 |      13 |      0 |
|* 48 |           INDEX RANGE SCAN                  | PIE_REFDOSS       |      2 |      1 |     1   (0)|      5 |00:00:00.01 |       8 |      0 |
|* 49 |         INDEX RANGE SCAN                    | G_PIECEDET_REFP   |      5 |      1 |     1   (0)|     22 |00:00:00.01 |      17 |      0 |
|* 50 |     TABLE ACCESS BY INDEX ROWID             | G_PIECEDET        |    179 |      1 |     1   (0)|    179 |00:00:00.01 |     179 |      0 |
|  51 |    NESTED LOOPS                             |                   |    310 |      1 |     4   (0)|      0 |00:00:00.01 |     320 |      0 |
|  52 |     NESTED LOOPS                            |                   |    310 |      1 |     4   (0)|      0 |00:00:00.01 |     320 |      0 |
|  53 |      NESTED LOOPS SEMI                      |                   |    310 |      1 |     3   (0)|      0 |00:00:00.01 |     320 |      0 |
|  54 |       NESTED LOOPS                          |                   |    310 |      1 |     2   (0)|      0 |00:00:00.01 |     320 |      0 |
|* 55 |        INDEX RANGE SCAN                     | REFHIERARCHIE_IDX |    310 |      1 |     1   (0)|      0 |00:00:00.01 |     320 |      0 |
|* 56 |        INDEX RANGE SCAN                     | INT_REFDOSS       |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 57 |       TABLE ACCESS BY INDEX ROWID BATCHED   | G_PIECE           |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 58 |        INDEX RANGE SCAN                     | PIE_REFDOSS       |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 59 |      INDEX RANGE SCAN                       | GP_GRTYPE_MT_DT   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 60 |     TABLE ACCESS BY INDEX ROWID             | G_PIECE           |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|  61 |    SORT AGGREGATE                           |                   |      0 |      1 |            |      0 |00:00:00.01 |       0 |      0 |
|  62 |     NESTED LOOPS                            |                   |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|  63 |      INLIST ITERATOR                        |                   |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  64 |       TABLE ACCESS BY INDEX ROWID BATCHED   | G_PIECE           |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 65 |        INDEX RANGE SCAN                     | PIE_REFDOSS       |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 66 |      INDEX RANGE SCAN                       | G_PIECEDET_REFP   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
-------------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   2 - filter((("E"."TYPPIECE"='SOUS-CONTRAT' AND  IS NOT NULL AND ( IS NOT NULL OR  IS NOT NULL) AND "UTL_APP_DATE"."GETAPPDATE"()>) OR
              (INTERNAL_FUNCTION("E"."TYPPIECE") AND  IS NOT NULL AND ("E"."REFDOSS"=:REFDOS OR  IS NOT NULL) AND "UTL_APP_DATE"."GETAPPDATE"()>)))
   8 - access("P"."REFDOSS"=:REFDOS AND (("P"."TYPPIECE"='A.CONTRAT' OR "P"."TYPPIECE"='A.CONTRAT REV')))
   9 - access("P"."REFPIECE"="D"."REFPIECE" AND "D"."TYPE"='CONTRACT SITUATIONS' AND "D"."DT01_DT"=)
  14 - access("P"."REFDOSS"=:REFDOS AND (("P"."TYPPIECE"='A.CONTRAT' OR "P"."TYPPIECE"='A.CONTRAT REV')))
  15 - access("P"."REFPIECE"="D"."REFPIECE" AND "D"."TYPE"='CONTRACT SITUATIONS')
       filter("D"."DT01_DT" IS NOT NULL)
  16 - filter((INTERNAL_FUNCTION("D"."STR1") OR ("D"."STR1"='T' AND TO_NUMBER(TO_CHAR("UTL_APP_DATE"."GETAPPDATE"(),'j'))<=NVL(:B1,999999
              9))))
  17 - filter("REFLOT"=:REFDOS)
  18 - access("REFDOSS"=:B1)
  25 - access("REFDOSS"=:B1)
  26 - access("REFHIERARCHIE"=:REFDOS AND "REFLOT"="REFDOSS")
       filter("REFLOT"="REFDOSS")
  27 - access("I"."REFDOSS"="G_DOSSIER"."REFDOSS" AND "I"."REFTYPE"='CL')
  28 - filter(NVL("GPIACCEPT",'O')<>'N')
  29 - access("REFDOSS"="G_DOSSIER"."REFDOSS" AND "TYPPIECE"='CONTRAT')
       filter("REFDOSS" IS NOT NULL)
  30 - access("P"."TYPPIECE"='CLIENT_PARAMS' AND "P"."GPIHEURE"="I"."REFINDIVIDU")
       filter("P"."GPIHEURE" IS NOT NULL)
  31 - filter(NVL("P"."FG30",'N')='O')
  36 - access("P"."REFDOSS"=:REFDOS AND (("P"."TYPPIECE"='CONTRAT' OR "P"."TYPPIECE"='CONTRAT REV')))
  37 - access("P"."REFPIECE"="D"."REFPIECE" AND "D"."TYPE"='CONTRACT SITUATIONS')
       filter("D"."DT01_DT" IS NOT NULL)
  42 - access("P"."REFDOSS"=:REFDOS AND (("P"."TYPPIECE"='A.CONTRAT' OR "P"."TYPPIECE"='A.CONTRAT REV')))
  43 - access("P"."REFPIECE"="D"."REFPIECE" AND "D"."TYPE"='CONTRACT SITUATIONS' AND "D"."DT01_DT"=)
  48 - access("P"."REFDOSS"=:REFDOS AND (("P"."TYPPIECE"='A.CONTRAT' OR "P"."TYPPIECE"='A.CONTRAT REV')))
  49 - access("P"."REFPIECE"="D"."REFPIECE" AND "D"."TYPE"='CONTRACT SITUATIONS')
       filter("D"."DT01_DT" IS NOT NULL)
  50 - filter((INTERNAL_FUNCTION("D"."STR1") OR ("D"."STR1"='T' AND TO_NUMBER(TO_CHAR("UTL_APP_DATE"."GETAPPDATE"(),'j'))<=NVL(:B1,999999
              9))))
  55 - access("REFHIERARCHIE"=:REFDOS AND "REFDOSS"=:B1)
       filter("REFDOSS"=:B1)
  56 - access("I"."REFDOSS"=:B1 AND "I"."REFTYPE"='CL')
  57 - filter(NVL("GPIACCEPT",'O')<>'N')
  58 - access("REFDOSS"=:B1 AND "TYPPIECE"='CONTRAT')
       filter("REFDOSS"="G_DOSSIER"."REFDOSS")
  59 - access("P"."TYPPIECE"='CLIENT_PARAMS' AND "P"."GPIHEURE"="I"."REFINDIVIDU")
       filter("P"."GPIHEURE" IS NOT NULL)
  60 - filter(NVL("P"."FG30",'N')='O')
  65 - access("P"."REFDOSS"=:REFDOS AND (("P"."TYPPIECE"='CONTRAT' OR "P"."TYPPIECE"='CONTRAT REV')))
  66 - access("P"."REFPIECE"="D"."REFPIECE" AND "D"."TYPE"='CONTRACT SITUATIONS')
       filter("D"."DT01_DT" IS NOT NULL)


-- ctxsxppszxaf6


Plan hash value: 2977787830
------------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                 | Name               | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  |
------------------------------------------------------------------------------------------------------------------------------------------------
|   0 | INSERT STATEMENT                          |                    |      1 |        |   264K(100)|      0 |00:00:00.01 |       8 |      0 |
|   1 |  LOAD TABLE CONVENTIONAL                  | G_PIECEDET         |      1 |        |            |      0 |00:00:00.01 |       8 |      0 |
|   2 |   SORT AGGREGATE                          |                    |      0 |      1 |            |      0 |00:00:00.01 |       0 |      0 |
|   3 |    NESTED LOOPS                           |                    |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|   4 |     INLIST ITERATOR                       |                    |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|   5 |      TABLE ACCESS BY INDEX ROWID BATCHED  | G_PIECE            |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*  6 |       INDEX RANGE SCAN                    | PIE_REFDOSS        |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*  7 |     INDEX RANGE SCAN                      | G_PIECEDET_REFP    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*  8 |   FILTER                                  |                    |      1 |        |            |      0 |00:00:00.01 |       8 |      0 |
|*  9 |    FILTER                                 |                    |      1 |        |            |      0 |00:00:00.01 |       8 |      0 |
|  10 |     VIEW                                  | index$_join$_004   |      1 |     31M|   264K  (1)|      0 |00:00:00.01 |       0 |      0 |
|* 11 |      HASH JOIN                            |                    |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
|* 12 |       HASH JOIN                           |                    |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  13 |        INDEX FAST FULL SCAN               | PIECE_TYP_MT43_IDX |      1 |     31M|  1162   (1)|     14M|00:00:04.31 |   39512 |  38884 |
|  14 |        INDEX FAST FULL SCAN               | GP_REFEXT_IDX      |      0 |     31M|  1742   (1)|      0 |00:00:00.01 |       0 |      0 |
|  15 |       INDEX FAST FULL SCAN                | GP_ST01_FUNC_IDX   |      0 |     31M|  2106   (1)|      0 |00:00:00.01 |       0 |      0 |
|  16 |     NESTED LOOPS                          |                    |      1 |      1 |     2   (0)|      0 |00:00:00.01 |       8 |      0 |
|  17 |      NESTED LOOPS                         |                    |      1 |      1 |     2   (0)|      0 |00:00:00.01 |       8 |      0 |
|  18 |       INLIST ITERATOR                     |                    |      1 |        |            |      0 |00:00:00.01 |       8 |      0 |
|  19 |        TABLE ACCESS BY INDEX ROWID BATCHED| G_PIECE            |      2 |      1 |     1   (0)|      0 |00:00:00.01 |       8 |      0 |
|* 20 |         INDEX RANGE SCAN                  | PIE_REFDOSS        |      2 |      1 |     1   (0)|      0 |00:00:00.01 |       8 |      0 |
|* 21 |       INDEX RANGE SCAN                    | G_PIECEDET_REFP    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 22 |      TABLE ACCESS BY INDEX ROWID          | G_PIECEDET         |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 23 |    TABLE ACCESS BY INDEX ROWID            | G_DOSSIER          |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 24 |     INDEX UNIQUE SCAN                     | DOS_REFDOSS        |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|  25 |    NESTED LOOPS                           |                    |      0 |      1 |     5   (0)|      0 |00:00:00.01 |       0 |      0 |
|  26 |     NESTED LOOPS                          |                    |      0 |      1 |     5   (0)|      0 |00:00:00.01 |       0 |      0 |
|  27 |      NESTED LOOPS SEMI                    |                    |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|  28 |       NESTED LOOPS                        |                    |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|  29 |        NESTED LOOPS                       |                    |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|  30 |         TABLE ACCESS BY INDEX ROWID       | G_DOSSIER          |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 31 |          INDEX UNIQUE SCAN                | DOS_REFDOSS        |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 32 |         INDEX RANGE SCAN                  | REFHIERARCHIE_IDX  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 33 |        INDEX RANGE SCAN                   | INT_REFDOSS        |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 34 |       TABLE ACCESS BY INDEX ROWID BATCHED | G_PIECE            |      0 |    565 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 35 |        INDEX RANGE SCAN                   | PIE_REFDOSS        |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 36 |      INDEX RANGE SCAN                     | GP_GRTYPE_MT_DT    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 37 |     TABLE ACCESS BY INDEX ROWID           | G_PIECE            |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|  38 |    SORT AGGREGATE                         |                    |      0 |      1 |            |      0 |00:00:00.01 |       0 |      0 |
|  39 |     NESTED LOOPS                          |                    |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|  40 |      NESTED LOOPS                         |                    |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|  41 |       INLIST ITERATOR                     |                    |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  42 |        TABLE ACCESS BY INDEX ROWID BATCHED| G_PIECE            |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 43 |         INDEX RANGE SCAN                  | PIE_REFDOSS        |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 44 |       INDEX RANGE SCAN                    | G_PIECEDET_REFP    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 45 |      TABLE ACCESS BY INDEX ROWID          | G_PIECEDET         |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|  46 |    NESTED LOOPS                           |                    |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|  47 |     NESTED LOOPS                          |                    |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|  48 |      NESTED LOOPS SEMI                    |                    |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|  49 |       NESTED LOOPS                        |                    |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 50 |        INDEX RANGE SCAN                   | REFHIERARCHIE_IDX  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 51 |        INDEX RANGE SCAN                   | INT_REFDOSS        |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 52 |       TABLE ACCESS BY INDEX ROWID BATCHED | G_PIECE            |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 53 |        INDEX RANGE SCAN                   | PIE_REFDOSS        |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 54 |      INDEX RANGE SCAN                     | GP_GRTYPE_MT_DT    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 55 |     TABLE ACCESS BY INDEX ROWID           | G_PIECE            |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|  56 |    SORT AGGREGATE                         |                    |      0 |      1 |            |      0 |00:00:00.01 |       0 |      0 |
|  57 |     NESTED LOOPS                          |                    |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|  58 |      NESTED LOOPS                         |                    |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|  59 |       INLIST ITERATOR                     |                    |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  60 |        TABLE ACCESS BY INDEX ROWID BATCHED| G_PIECE            |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 61 |         INDEX RANGE SCAN                  | PIE_REFDOSS        |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 62 |       INDEX RANGE SCAN                    | G_PIECEDET_REFP    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 63 |      TABLE ACCESS BY INDEX ROWID          | G_PIECEDET         |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
------------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   6 - access("PR"."REFDOSS"=:REFDOS AND (("PR"."TYPPIECE"='CONTRAT' OR "PR"."TYPPIECE"='CONTRAT REV')))
   7 - access("PR"."REFPIECE"="DR"."REFPIECE" AND "DR"."TYPE"='CONTRACT SITUATIONS')
       filter("DR"."DT01_DT" IS NOT NULL)
   8 - filter((("TYPPIECE"='SOUS-CONTRAT' AND ( IS NOT NULL OR  IS NOT NULL) AND "UTL_APP_DATE"."GETAPPDATE"()<=) OR
              (INTERNAL_FUNCTION("TYPPIECE") AND ("REFDOSS"=:REFDOS OR  IS NOT NULL) AND "UTL_APP_DATE"."GETAPPDATE"()<=)))
   9 - filter( IS NULL)
  11 - access(ROWID=ROWID)
  12 - access(ROWID=ROWID)
  20 - access("PA"."REFDOSS"=:REFDOS AND (("PA"."TYPPIECE"='CONTRAT' OR "PA"."TYPPIECE"='CONTRAT REV')))
  21 - access("PA"."REFPIECE"="DA"."REFPIECE" AND "DA"."TYPE"='CONTRACT SITUATIONS')
  22 - filter("DA"."STR1"='V')
  23 - filter("REFLOT"=:REFDOS)
  24 - access("REFDOSS"=:B1)
  31 - access("REFDOSS"=:B1)
  32 - access("REFHIERARCHIE"=:REFDOS AND "REFLOT"="REFDOSS")
       filter("REFLOT"="REFDOSS")
  33 - access("I"."REFDOSS"="G_DOSSIER"."REFDOSS" AND "I"."REFTYPE"='CL')
  34 - filter(NVL("GPIACCEPT",'O')<>'N')
  35 - access("REFDOSS"="G_DOSSIER"."REFDOSS" AND "TYPPIECE"='CONTRAT')
       filter("REFDOSS" IS NOT NULL)
  36 - access("P"."TYPPIECE"='CLIENT_PARAMS' AND "P"."GPIHEURE"="I"."REFINDIVIDU")
       filter("P"."GPIHEURE" IS NOT NULL)
  37 - filter(NVL("P"."FG30",'N')='O')
  43 - access("P"."REFDOSS"=:REFDOS AND (("P"."TYPPIECE"='CONTRAT' OR "P"."TYPPIECE"='CONTRAT REV')))
  44 - access("P"."REFPIECE"="D"."REFPIECE" AND "D"."TYPE"='CONTRACT SITUATIONS')
       filter("D"."DT01_DT" IS NOT NULL)
  45 - filter("D"."STR1"<>'V')
  50 - access("REFHIERARCHIE"=:REFDOS AND "REFDOSS"=:B1)
       filter("REFDOSS"=:B1)
  51 - access("I"."REFDOSS"=:B1 AND "I"."REFTYPE"='CL')
  52 - filter(NVL("GPIACCEPT",'O')<>'N')
  53 - access("REFDOSS"=:B1 AND "TYPPIECE"='CONTRAT')
       filter("REFDOSS"="G_DOSSIER"."REFDOSS")
  54 - access("P"."TYPPIECE"='CLIENT_PARAMS' AND "P"."GPIHEURE"="I"."REFINDIVIDU")
       filter("P"."GPIHEURE" IS NOT NULL)
  55 - filter(NVL("P"."FG30",'N')='O')
  61 - access("P"."REFDOSS"=:REFDOS AND (("P"."TYPPIECE"='CONTRAT' OR "P"."TYPPIECE"='CONTRAT REV')))
  62 - access("P"."REFPIECE"="D"."REFPIECE" AND "D"."TYPE"='CONTRACT SITUATIONS')
       filter("D"."DT01_DT" IS NOT NULL)
  63 - filter("D"."STR1"<>'V')


*/
/********************************OLD Metrics***************************************/

/********************************New SQL*******************************************/

-- daujxjbr82ztz

insert into g_piecedet( refdoss, refpiece, type, dt01_dt, str1)
  select refdoss,
         refpiece,
         'CONTRACT SITUATIONS',
         utl_app_date.getAppDate,
         'T'
    from g_piece
   where refdoss in ( select :refdos from dual
                      union all
                     select refdoss
                            from g_dossier
                           where refhierarchie = :refdos
                             and exists (select 1
                                           from g_piece p, 
                                                t_intervenants i
                                          where nvl(p.fg30, 'N') = 'O'
                                            and p.typpiece = 'CLIENT_PARAMS'
                                            and p.gpiheure = i.refindividu
                                            and i.refdoss = g_dossier.refdoss
                                            and i.reftype = 'CL' )
                             and exists ( select 1
                                            from g_piece
                                           where refdoss = g_dossier.refdoss
                                             and typpiece = 'CONTRAT'
                                             and nvl(gpiaccept, 'O') <> 'N')  ) 
     and typpiece in ('CONTRAT', 'CONTRAT REV') 
     and 'T' = ( select d.str1
                   from g_piecedet D, 
                        g_piece P
                  where P.refdoss = :refdos
                    and P.refpiece = D.refpiece
                    and P.typpiece in ('A.CONTRAT', 'A.CONTRAT REV')
                    and D.type = 'CONTRACT SITUATIONS'
                    and rownum = 1
                    and d.dt01_dt = ( select max(D.dt01_dt)
                                        from g_piecedet D, 
                                             g_piece P
                                       where P.refdoss = :refdos
                                         and P.refpiece = D.refpiece
                                         and P.typpiece in ('A.CONTRAT', 'A.CONTRAT REV')
                                         and D.type = 'CONTRACT SITUATIONS' ) ) 
     and to_char(utl_app_date.getAppDate, 'j') > nvl(gpidtfin, '9999999') 
     and utl_app_date.getAppDate > ( select max(D.dt01_dt)
                                       from g_piecedet D, 
                                            g_piece P
                                      where P.refdoss = :refdos
                                        and P.refpiece = D.refpiece
                                        and P.typpiece in ('CONTRAT', 'CONTRAT REV')
                                        and D.type = 'CONTRACT SITUATIONS' ) 
union                                        
  select refdoss,
         refpiece,
         'CONTRACT SITUATIONS',
         utl_app_date.getAppDate,
         'T'
    from g_piece                                      
   where refdoss in (     select refdoss 
                            from g_dossier 
                           where reflot = :refdos 
                           union all      
                          select refdoss
                            from g_dossier
                           where reflot in ( select refdoss
                                               from g_dossier
                                              where refhierarchie = :refdos
                                                and exists ( select 1
                                                               from g_piece p, 
                                                                    t_intervenants i
                                                              where nvl(p.fg30, 'N') = 'O'
                                                                and p.typpiece = 'CLIENT_PARAMS'
                                                                and p.gpiheure = i.refindividu
                                                                and i.refdoss = g_dossier.refdoss
                                                                and i.reftype = 'CL' )
                                                and exists ( select 1
                                                               from g_piece
                                                              where refdoss = g_dossier.refdoss
                                                                and typpiece = 'CONTRAT'
                                                                and nvl(gpiaccept, 'O') <> 'N' ) ) )  
     and typpiece = 'SOUS-CONTRAT' 
     and 'T' = ( select d.str1
                   from g_piecedet D, 
                        g_piece P
                  where P.refdoss = :refdos
                    and P.refpiece = D.refpiece
                    and P.typpiece in ('A.CONTRAT', 'A.CONTRAT REV')
                    and D.type = 'CONTRACT SITUATIONS'
                    and rownum = 1
                    and d.dt01_dt = ( select max(D.dt01_dt)
                                        from g_piecedet D, 
                                             g_piece P
                                       where P.refdoss = :refdos
                                         and P.refpiece = D.refpiece
                                         and P.typpiece in ('A.CONTRAT', 'A.CONTRAT REV')
                                         and D.type = 'CONTRACT SITUATIONS' ) ) 
     and to_char(utl_app_date.getAppDate, 'j') > nvl(gpidtfin, '9999999') 
     and utl_app_date.getAppDate > ( select max(D.dt01_dt)
                                       from g_piecedet D, 
                                            g_piece P
                                      where P.refdoss = :refdos
                                        and P.refpiece = D.refpiece
                                        and P.typpiece in ('CONTRAT', 'CONTRAT REV')
                                        and D.type = 'CONTRACT SITUATIONS' ) ;

-- 0dy0dvna24zfu

insert into g_piecedet (refdoss, refpiece, type, dt01_dt, str1)
  select refdoss,
         refpiece,
         'CONTRACT SITUATIONS',
         utl_app_date.getAppDate,
         'V'
    from g_piece e
   where e.refdoss in ( select :refdos from dual
                         union all
                        select refdoss
                          from g_dossier
                         where refhierarchie = :refdos
                           and exists ( select 1
                                          from g_piece p, 
                                               t_intervenants i
                                         where nvl(p.fg30, 'N') = 'O'
                                           and p.typpiece = 'CLIENT_PARAMS'
                                           and p.gpiheure = i.refindividu
                                           and i.refdoss = g_dossier.refdoss
                                           and i.reftype = 'CL' )
                           and exists ( select 1
                                          from g_piece
                                         where refdoss = g_dossier.refdoss
                                           and typpiece = 'CONTRAT'
                                           and nvl(gpiaccept, 'O') <> 'N') ) 
     and e.typpiece in ('CONTRAT', 'CONTRAT REV') 
     and exists (select '1'
                   from g_piecedet D, 
                        g_piece P
                  where P.refdoss = :refdos
                    and P.refpiece = D.refpiece
                    and ( ( d.str1 in( 'V', 'S', 'R', 'O', 'I', 'F', 'E', 'C', 'A', 'P') ) 
                       or ( d.str1 = 'T' and to_char(utl_app_date.getAppDate, 'j') <= nvl(e.gpidtfin, '9999999')))
                    and P.typpiece in ('A.CONTRAT', 'A.CONTRAT REV')
                    and D.type = 'CONTRACT SITUATIONS'
                    and d.dt01_dt = ( select max(D.dt01_dt)
                                        from g_piecedet D, 
                                             g_piece P
                                       where P.refdoss = :refdos
                                         and P.refpiece = D.refpiece
                                         and P.typpiece in ('A.CONTRAT', 'A.CONTRAT REV')
                                         and D.type = 'CONTRACT SITUATIONS') ) 
     and utl_app_date.getAppDate > ( select max(D.dt01_dt)
                                       from g_piecedet D, 
                                            g_piece P
                                      where P.refdoss = :refdos
                                        and P.refpiece = D.refpiece
                                        and P.typpiece in ('CONTRAT', 'CONTRAT REV')
                                        and D.type = 'CONTRACT SITUATIONS' )
union
  select refdoss,
         refpiece,
         'CONTRACT SITUATIONS',
         utl_app_date.getAppDate,
         'V'
    from g_piece e              
   where e.refdoss in ( select refdoss 
                          from g_dossier 
                         where reflot = :refdos 
                         union all
                        select refdoss
                          from g_dossier
                         where reflot in ( select refdoss
                                             from g_dossier
                                            where refhierarchie = :refdos
                                              and exists ( select 1
                                                             from g_piece p, 
                                                                  t_intervenants i
                                                             where nvl(p.fg30, 'N') = 'O'
                                                               and p.typpiece = 'CLIENT_PARAMS'
                                                               and p.gpiheure = i.refindividu
                                                               and i.refdoss = g_dossier.refdoss
                                                               and i.reftype = 'CL' )
                                              and exists ( select 1
                                                             from g_piece
                                                            where refdoss = g_dossier.refdoss
                                                              and typpiece = 'CONTRAT'
                                                              and nvl(gpiaccept, 'O') <> 'N') )) 
                           and  e.typpiece = 'SOUS-CONTRAT' 
                           and exists ( select '1'
                                          from g_piecedet D, 
                                               g_piece P
                                         where P.refdoss = :refdos
                                           and P.refpiece = D.refpiece
                                           and ( ( d.str1 in ( 'V', 'S', 'R', 'O', 'I', 'F', 'E', 'C', 'A', 'P') ) 
                                              or ( d.str1 = 'T' and to_char(utl_app_date.getAppDate, 'j') <= nvl(e.gpidtfin, '9999999')))
                                           and P.typpiece in ('A.CONTRAT', 'A.CONTRAT REV')
                                           and D.type = 'CONTRACT SITUATIONS'
                                           and d.dt01_dt = ( select max(D.dt01_dt)
                                                               from g_piecedet D, 
                                                                    g_piece P
                                                              where P.refdoss = :refdos
                                                                and P.refpiece = D.refpiece
                                                                and P.typpiece in ('A.CONTRAT', 'A.CONTRAT REV')
                                                                and D.type = 'CONTRACT SITUATIONS' ) )
                           and utl_app_date.getAppDate > ( select max(D.dt01_dt)
                                                             from g_piecedet D, 
                                                                  g_piece P
                                                            where P.refdoss = :refdos
                                                              and P.refpiece = D.refpiece
                                                              and P.typpiece in ('CONTRAT', 'CONTRAT REV')
                                                              and D.type = 'CONTRACT SITUATIONS' ) ;

-- ctxsxppszxaf6

insert into g_piecedet (refdoss, refpiece, type, dt01_dt, str1)
  select /*+ use_concat */         
         refdoss,
         refpiece,
         'CONTRACT SITUATIONS',
         to_date(to_char( ( select max(Dr.dt01_dt)
                              from g_piecedet Dr, 
                                   g_piece Pr
                             where Pr.refdoss = :refdos
                               and Pr.refpiece = Dr.refpiece
                               and Pr.typpiece in ('CONTRAT', 'CONTRAT REV')
                               and Dr.type = 'CONTRACT SITUATIONS' ),
                         'jsssss') + 1,
                         'jsssss'),
         'V'
    from g_piece
   where ( ( refdoss in ( select :refdos 
                          from dual
                         union all
                        select refdoss
                              from g_dossier
                             where refhierarchie = :refdos
                               and exists ( select 1
                                              from g_piece p, 
                                                   t_intervenants i
                                             where nvl(p.fg30, 'N') = 'O'
                                               and p.typpiece = 'CLIENT_PARAMS'
                                               and p.gpiheure = i.refindividu
                                               and i.refdoss = g_dossier.refdoss
                                               and i.reftype = 'CL' )
                               and exists ( select 1
                                              from g_piece
                                             where refdoss = g_dossier.refdoss
                                               and typpiece = 'CONTRAT'
                                               and nvl(gpiaccept, 'O') <> 'N' ) )
     and typpiece in ('CONTRAT', 'CONTRAT REV') 
     and utl_app_date.getAppDate <= ( select max(D.dt01_dt)
                                        from g_piecedet D, 
                                             g_piece P
                                       where P.refdoss = :refdos
                                         and P.refpiece = D.refpiece
                                         and P.typpiece in ('CONTRAT', 'CONTRAT REV')
                                         and D.type = 'CONTRACT SITUATIONS'
                                         and D.str1 != 'V' ) )
       or
         (   refdoss in ( select refdoss 
                            from g_dossier 
                           where reflot = :refdos 
                           union all 
                          select refdoss
                            from g_dossier
                            where reflot in ( select refdoss
                                                from g_dossier
                                               where refhierarchie = :refdos
                                                 and exists ( select 1
                                                                from g_piece p, 
                                                                     t_intervenants i
                                                               where nvl(p.fg30, 'N') = 'O'
                                                                 and p.typpiece = 'CLIENT_PARAMS'
                                                                 and p.gpiheure = i.refindividu
                                                                 and i.refdoss = g_dossier.refdoss
                                                                 and i.reftype = 'CL' )
                                                 and exists ( select 1
                                                                from g_piece
                                                               where refdoss = g_dossier.refdoss
                                                                 and typpiece = 'CONTRAT'
                                                                 and nvl(gpiaccept, 'O') <> 'N') ) )  
         and typpiece = 'SOUS-CONTRAT' 
         and utl_app_date.getAppDate <= ( select max(D.dt01_dt)
                                            from g_piecedet D, 
                                                 g_piece P
                                           where P.refdoss = :refdos
                                             and P.refpiece = D.refpiece
                                             and P.typpiece in ('CONTRAT', 'CONTRAT REV')
                                             and D.type = 'CONTRACT SITUATIONS'
                                             and D.str1 != 'V' ) ) ) 
     and 0 = ( select count(*)
                 from g_piece Pa, 
                      g_piecedet Da
                where Pa.refdoss = :refdos
                  and Pa.refpiece = Da.refpiece
                  and Pa.typpiece in ('CONTRAT', 'CONTRAT REV')
                  and Da.type = 'CONTRACT SITUATIONS'
                  and Da.str1 = 'V' );


/********************************New SQL*******************************************/
/********************************New Metrics***************************************/
/*

-- daujxjbr82ztz

Plan hash value: 3928981284
------------------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                         | Name                      | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers |
------------------------------------------------------------------------------------------------------------------------------------------------------
|   0 | INSERT STATEMENT                                  |                           |      1 |        |    28 (100)|      0 |00:00:00.01 |     140 |
|   1 |  LOAD TABLE CONVENTIONAL                          | G_PIECEDET                |      1 |        |            |      0 |00:00:00.01 |     140 |
|   2 |   SORT UNIQUE                                     |                           |      1 |      2 |    28   (4)|      0 |00:00:00.01 |     140 |
|   3 |    UNION-ALL                                      |                           |      1 |        |            |      0 |00:00:00.01 |     140 |
|*  4 |     FILTER                                        |                           |      1 |        |            |      0 |00:00:00.01 |      70 |
|   5 |      NESTED LOOPS                                 |                           |      0 |      1 |     8   (0)|      0 |00:00:00.01 |       0 |
|   6 |       NESTED LOOPS                                |                           |      0 |      2 |     8   (0)|      0 |00:00:00.01 |       0 |
|   7 |        VIEW                                       | VW_NSO_2                  |      0 |      2 |     7   (0)|      0 |00:00:00.01 |       0 |
|   8 |         SORT UNIQUE                               |                           |      0 |      2 |     7   (0)|      0 |00:00:00.01 |       0 |
|   9 |          UNION-ALL                                |                           |      0 |        |            |      0 |00:00:00.01 |       0 |
|  10 |           TABLE ACCESS FULL                       | DUAL                      |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|  11 |           NESTED LOOPS SEMI                       |                           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|  12 |            NESTED LOOPS SEMI                      |                           |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |
|* 13 |             INDEX RANGE SCAN                      | REFHIERARCHIE_IDX         |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 14 |             TABLE ACCESS BY INDEX ROWID BATCHED   | G_PIECE                   |      0 |    565 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 15 |              INDEX RANGE SCAN                     | PIE_REFDOSS               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|  16 |            VIEW PUSHED PREDICATE                  | VW_SQ_1                   |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |
|  17 |             NESTED LOOPS                          |                           |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |
|  18 |              NESTED LOOPS                         |                           |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |
|* 19 |               INDEX RANGE SCAN                    | INT_REFDOSS               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 20 |               INDEX RANGE SCAN                    | GP_GRTYPE_MT_DT           |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 21 |              TABLE ACCESS BY INDEX ROWID          | G_PIECE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|  22 |        INLIST ITERATOR                            |                           |      0 |        |            |      0 |00:00:00.01 |       0 |
|* 23 |         INDEX RANGE SCAN                          | PIE_REFDOSS               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 24 |       TABLE ACCESS BY INDEX ROWID                 | G_PIECE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|  25 |      SORT AGGREGATE                               |                           |      1 |      1 |            |      1 |00:00:00.01 |      13 |
|  26 |       NESTED LOOPS                                |                           |      1 |      1 |     2   (0)|      4 |00:00:00.01 |      13 |
|  27 |        INLIST ITERATOR                            |                           |      1 |        |            |      1 |00:00:00.01 |       9 |
|  28 |         TABLE ACCESS BY INDEX ROWID BATCHED       | G_PIECE                   |      2 |      1 |     1   (0)|      1 |00:00:00.01 |       9 |
|* 29 |          INDEX RANGE SCAN                         | PIE_REFDOSS               |      2 |      1 |     1   (0)|      1 |00:00:00.01 |       8 |
|* 30 |        INDEX RANGE SCAN                           | G_PIECEDET_REFP           |      1 |      1 |     1   (0)|      4 |00:00:00.01 |       4 |
|* 31 |      COUNT STOPKEY                                |                           |      1 |        |            |      1 |00:00:00.01 |      57 |
|  32 |       NESTED LOOPS                                |                           |      1 |      1 |     2   (0)|      1 |00:00:00.01 |      57 |
|  33 |        NESTED LOOPS                               |                           |      1 |      1 |     2   (0)|      1 |00:00:00.01 |      56 |
|  34 |         INLIST ITERATOR                           |                           |      1 |        |            |      5 |00:00:00.01 |       9 |
|  35 |          TABLE ACCESS BY INDEX ROWID BATCHED      | G_PIECE                   |      1 |      1 |     1   (0)|      5 |00:00:00.01 |       9 |
|* 36 |           INDEX RANGE SCAN                        | PIE_REFDOSS               |      1 |      1 |     1   (0)|      5 |00:00:00.01 |       4 |
|* 37 |         INDEX RANGE SCAN                          | G_PIECEDET_REFP           |      5 |      1 |     1   (0)|      1 |00:00:00.01 |      47 |
|  38 |          SORT AGGREGATE                           |                           |      1 |      1 |            |      1 |00:00:00.01 |      30 |
|  39 |           NESTED LOOPS                            |                           |      1 |      1 |     2   (0)|     22 |00:00:00.01 |      30 |
|  40 |            INLIST ITERATOR                        |                           |      1 |        |            |      5 |00:00:00.01 |      13 |
|  41 |             TABLE ACCESS BY INDEX ROWID BATCHED   | G_PIECE                   |      2 |      1 |     1   (0)|      5 |00:00:00.01 |      13 |
|* 42 |              INDEX RANGE SCAN                     | PIE_REFDOSS               |      2 |      1 |     1   (0)|      5 |00:00:00.01 |       8 |
|* 43 |            INDEX RANGE SCAN                       | G_PIECEDET_REFP           |      5 |      1 |     1   (0)|     22 |00:00:00.01 |      17 |
|  44 |        TABLE ACCESS BY INDEX ROWID                | G_PIECEDET                |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       1 |
|* 45 |     FILTER                                        |                           |      1 |        |            |      0 |00:00:00.01 |      70 |
|* 46 |      HASH JOIN                                    |                           |      0 |      1 |     8  (13)|      0 |00:00:00.01 |       0 |
|* 47 |       TABLE ACCESS BY INDEX ROWID BATCHED         | G_PIECE                   |      0 |     29 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 48 |        INDEX RANGE SCAN                           | PIECE_TYP_MT43_IDX        |      0 |    638 |     1   (0)|      0 |00:00:00.01 |       0 |
|  49 |       VIEW                                        | VW_NSO_4                  |      0 |    228 |     7  (15)|      0 |00:00:00.01 |       0 |
|  50 |        SORT UNIQUE                                |                           |      0 |    228 |     7  (15)|      0 |00:00:00.01 |       0 |
|  51 |         UNION-ALL                                 |                           |      0 |        |            |      0 |00:00:00.01 |       0 |
|* 52 |          INDEX RANGE SCAN                         | G_DOSSIER_RL_CD_RD_RF_IDX |      0 |    114 |     1   (0)|      0 |00:00:00.01 |       0 |
|  53 |          NESTED LOOPS                             |                           |      0 |    114 |     6  (17)|      0 |00:00:00.01 |       0 |
|  54 |           VIEW                                    | VW_NSO_3                  |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|  55 |            SORT UNIQUE                            |                           |      0 |      1 |            |      0 |00:00:00.01 |       0 |
|  56 |             NESTED LOOPS                          |                           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|  57 |              NESTED LOOPS                         |                           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|  58 |               NESTED LOOPS SEMI                   |                           |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|  59 |                NESTED LOOPS                       |                           |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |
|* 60 |                 INDEX RANGE SCAN                  | REFHIERARCHIE_IDX         |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 61 |                 INDEX RANGE SCAN                  | INT_REFDOSS               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 62 |                TABLE ACCESS BY INDEX ROWID BATCHED| G_PIECE                   |      0 |    565 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 63 |                 INDEX RANGE SCAN                  | PIE_REFDOSS               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 64 |               INDEX RANGE SCAN                    | GP_GRTYPE_MT_DT           |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 65 |              TABLE ACCESS BY INDEX ROWID          | G_PIECE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 66 |           INDEX RANGE SCAN                        | G_DOSSIER_RL_CD_RD_RF_IDX |      0 |    114 |     1   (0)|      0 |00:00:00.01 |       0 |
|  67 |      SORT AGGREGATE                               |                           |      1 |      1 |            |      1 |00:00:00.01 |      13 |
|  68 |       NESTED LOOPS                                |                           |      1 |      1 |     2   (0)|      4 |00:00:00.01 |      13 |
|  69 |        INLIST ITERATOR                            |                           |      1 |        |            |      1 |00:00:00.01 |       9 |
|  70 |         TABLE ACCESS BY INDEX ROWID BATCHED       | G_PIECE                   |      2 |      1 |     1   (0)|      1 |00:00:00.01 |       9 |
|* 71 |          INDEX RANGE SCAN                         | PIE_REFDOSS               |      2 |      1 |     1   (0)|      1 |00:00:00.01 |       8 |
|* 72 |        INDEX RANGE SCAN                           | G_PIECEDET_REFP           |      1 |      1 |     1   (0)|      4 |00:00:00.01 |       4 |
|* 73 |      COUNT STOPKEY                                |                           |      1 |        |            |      1 |00:00:00.01 |      57 |
|  74 |       NESTED LOOPS                                |                           |      1 |      1 |     2   (0)|      1 |00:00:00.01 |      57 |
|  75 |        NESTED LOOPS                               |                           |      1 |      1 |     2   (0)|      1 |00:00:00.01 |      56 |
|  76 |         INLIST ITERATOR                           |                           |      1 |        |            |      5 |00:00:00.01 |       9 |
|  77 |          TABLE ACCESS BY INDEX ROWID BATCHED      | G_PIECE                   |      1 |      1 |     1   (0)|      5 |00:00:00.01 |       9 |
|* 78 |           INDEX RANGE SCAN                        | PIE_REFDOSS               |      1 |      1 |     1   (0)|      5 |00:00:00.01 |       4 |
|* 79 |         INDEX RANGE SCAN                          | G_PIECEDET_REFP           |      5 |      1 |     1   (0)|      1 |00:00:00.01 |      47 |
|  80 |          SORT AGGREGATE                           |                           |      1 |      1 |            |      1 |00:00:00.01 |      30 |
|  81 |           NESTED LOOPS                            |                           |      1 |      1 |     2   (0)|     22 |00:00:00.01 |      30 |
|  82 |            INLIST ITERATOR                        |                           |      1 |        |            |      5 |00:00:00.01 |      13 |
|  83 |             TABLE ACCESS BY INDEX ROWID BATCHED   | G_PIECE                   |      2 |      1 |     1   (0)|      5 |00:00:00.01 |      13 |
|* 84 |              INDEX RANGE SCAN                     | PIE_REFDOSS               |      2 |      1 |     1   (0)|      5 |00:00:00.01 |       8 |
|* 85 |            INDEX RANGE SCAN                       | G_PIECEDET_REFP           |      5 |      1 |     1   (0)|     22 |00:00:00.01 |      17 |
|  86 |        TABLE ACCESS BY INDEX ROWID                | G_PIECEDET                |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       1 |
------------------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   4 - filter(("UTL_APP_DATE"."GETAPPDATE"()> AND ='T'))
  13 - access("REFHIERARCHIE"=:REFDOS)
  14 - filter(NVL("GPIACCEPT",'O')<>'N')
  15 - access("REFDOSS"="G_DOSSIER"."REFDOSS" AND "TYPPIECE"='CONTRAT')
       filter("REFDOSS" IS NOT NULL)
  19 - access("I"."REFDOSS"="G_DOSSIER"."REFDOSS" AND "I"."REFTYPE"='CL')
  20 - access("P"."TYPPIECE"='CLIENT_PARAMS' AND "P"."GPIHEURE"="I"."REFINDIVIDU")
       filter("P"."GPIHEURE" IS NOT NULL)
  21 - filter(NVL("P"."FG30",'N')='O')
  23 - access("REFDOSS"=":REFDOS" AND (("TYPPIECE"='CONTRAT' OR "TYPPIECE"='CONTRAT REV')))
       filter("REFDOSS" IS NOT NULL)
  24 - filter(TO_NUMBER(TO_CHAR("UTL_APP_DATE"."GETAPPDATE"(),'j'))>NVL("GPIDTFIN",9999999))
  29 - access("P"."REFDOSS"=:REFDOS AND (("P"."TYPPIECE"='CONTRAT' OR "P"."TYPPIECE"='CONTRAT REV')))
  30 - access("P"."REFPIECE"="D"."REFPIECE" AND "D"."TYPE"='CONTRACT SITUATIONS')
       filter("D"."DT01_DT" IS NOT NULL)
  31 - filter(ROWNUM=1)
  36 - access("P"."REFDOSS"=:REFDOS AND (("P"."TYPPIECE"='A.CONTRAT' OR "P"."TYPPIECE"='A.CONTRAT REV')))
  37 - access("P"."REFPIECE"="D"."REFPIECE" AND "D"."TYPE"='CONTRACT SITUATIONS' AND "D"."DT01_DT"=)
  42 - access("P"."REFDOSS"=:REFDOS AND (("P"."TYPPIECE"='A.CONTRAT' OR "P"."TYPPIECE"='A.CONTRAT REV')))
  43 - access("P"."REFPIECE"="D"."REFPIECE" AND "D"."TYPE"='CONTRACT SITUATIONS')
       filter("D"."DT01_DT" IS NOT NULL)
  45 - filter(("UTL_APP_DATE"."GETAPPDATE"()> AND ='T'))
  46 - access("REFDOSS"="REFDOSS")
  47 - filter(("REFDOSS" IS NOT NULL AND TO_NUMBER(TO_CHAR("UTL_APP_DATE"."GETAPPDATE"(),'j'))>NVL("GPIDTFIN",9999999)))
  48 - access("TYPPIECE"='SOUS-CONTRAT')
  52 - access("REFLOT"=:REFDOS)
  60 - access("REFHIERARCHIE"=:REFDOS)
  61 - access("I"."REFDOSS"="G_DOSSIER"."REFDOSS" AND "I"."REFTYPE"='CL')
  62 - filter(NVL("GPIACCEPT",'O')<>'N')
  63 - access("REFDOSS"="G_DOSSIER"."REFDOSS" AND "TYPPIECE"='CONTRAT')
       filter("REFDOSS" IS NOT NULL)
  64 - access("P"."TYPPIECE"='CLIENT_PARAMS' AND "P"."GPIHEURE"="I"."REFINDIVIDU")
       filter("P"."GPIHEURE" IS NOT NULL)
  65 - filter(NVL("P"."FG30",'N')='O')
  66 - access("REFLOT"="REFDOSS")
  71 - access("P"."REFDOSS"=:REFDOS AND (("P"."TYPPIECE"='CONTRAT' OR "P"."TYPPIECE"='CONTRAT REV')))
  72 - access("P"."REFPIECE"="D"."REFPIECE" AND "D"."TYPE"='CONTRACT SITUATIONS')
       filter("D"."DT01_DT" IS NOT NULL)
  73 - filter(ROWNUM=1)
  78 - access("P"."REFDOSS"=:REFDOS AND (("P"."TYPPIECE"='A.CONTRAT' OR "P"."TYPPIECE"='A.CONTRAT REV')))
  79 - access("P"."REFPIECE"="D"."REFPIECE" AND "D"."TYPE"='CONTRACT SITUATIONS' AND "D"."DT01_DT"=)
  84 - access("P"."REFDOSS"=:REFDOS AND (("P"."TYPPIECE"='A.CONTRAT' OR "P"."TYPPIECE"='A.CONTRAT REV')))
  85 - access("P"."REFPIECE"="D"."REFPIECE" AND "D"."TYPE"='CONTRACT SITUATIONS')
       filter("D"."DT01_DT" IS NOT NULL)


-- 0dy0dvna24zfu

Plan hash value: 2326131502
----------------------------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                          | Name                      | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  |
----------------------------------------------------------------------------------------------------------------------------------------------------------------
|   0 | INSERT STATEMENT                                   |                           |      1 |        |    28 (100)|      0 |00:00:00.26 |   33133 |     59 |
|   1 |  LOAD TABLE CONVENTIONAL                           | G_PIECEDET                |      1 |        |            |      0 |00:00:00.26 |   33133 |     59 |
|   2 |   SORT UNIQUE                                      |                           |      1 |      2 |    28   (4)|      2 |00:00:00.01 |     932 |      0 |
|   3 |    UNION-ALL                                       |                           |      1 |        |            |      2 |00:00:00.01 |     932 |      0 |
|*  4 |     FILTER                                         |                           |      1 |        |            |      1 |00:00:00.01 |      86 |      0 |
|*  5 |      FILTER                                        |                           |      1 |        |            |      1 |00:00:00.01 |      29 |      0 |
|   6 |       NESTED LOOPS                                 |                           |      1 |      1 |     8   (0)|      1 |00:00:00.01 |      16 |      0 |
|   7 |        NESTED LOOPS                                |                           |      1 |      2 |     8   (0)|      1 |00:00:00.01 |      14 |      0 |
|   8 |         VIEW                                       | VW_NSO_2                  |      1 |      2 |     7   (0)|      1 |00:00:00.01 |       6 |      0 |
|   9 |          SORT UNIQUE                               |                           |      1 |      2 |     7   (0)|      1 |00:00:00.01 |       6 |      0 |
|  10 |           UNION-ALL                                |                           |      1 |        |            |      1 |00:00:00.01 |       6 |      0 |
|  11 |            TABLE ACCESS FULL                       | DUAL                      |      1 |      1 |     3   (0)|      1 |00:00:00.01 |       3 |      0 |
|  12 |            NESTED LOOPS SEMI                       |                           |      1 |      1 |     4   (0)|      0 |00:00:00.01 |       3 |      0 |
|  13 |             NESTED LOOPS SEMI                      |                           |      1 |      1 |     2   (0)|      0 |00:00:00.01 |       3 |      0 |
|* 14 |              INDEX RANGE SCAN                      | REFHIERARCHIE_IDX         |      1 |      1 |     1   (0)|      0 |00:00:00.01 |       3 |      0 |
|* 15 |              TABLE ACCESS BY INDEX ROWID BATCHED   | G_PIECE                   |      0 |    565 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 16 |               INDEX RANGE SCAN                     | PIE_REFDOSS               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|  17 |             VIEW PUSHED PREDICATE                  | VW_SQ_1                   |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|  18 |              NESTED LOOPS                          |                           |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|  19 |               NESTED LOOPS                         |                           |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 20 |                INDEX RANGE SCAN                    | INT_REFDOSS               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 21 |                INDEX RANGE SCAN                    | GP_GRTYPE_MT_DT           |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 22 |               TABLE ACCESS BY INDEX ROWID          | G_PIECE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|  23 |         INLIST ITERATOR                            |                           |      1 |        |            |      1 |00:00:00.01 |       8 |      0 |
|* 24 |          INDEX RANGE SCAN                          | PIE_REFDOSS               |      2 |      1 |     1   (0)|      1 |00:00:00.01 |       8 |      0 |
|  25 |        TABLE ACCESS BY INDEX ROWID                 | G_PIECE                   |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       2 |      0 |
|  26 |       SORT AGGREGATE                               |                           |      1 |      1 |            |      1 |00:00:00.01 |      13 |      0 |
|  27 |        NESTED LOOPS                                |                           |      1 |      1 |     2   (0)|      4 |00:00:00.01 |      13 |      0 |
|  28 |         INLIST ITERATOR                            |                           |      1 |        |            |      1 |00:00:00.01 |       9 |      0 |
|  29 |          TABLE ACCESS BY INDEX ROWID BATCHED       | G_PIECE                   |      2 |      1 |     1   (0)|      1 |00:00:00.01 |       9 |      0 |
|* 30 |           INDEX RANGE SCAN                         | PIE_REFDOSS               |      2 |      1 |     1   (0)|      1 |00:00:00.01 |       8 |      0 |
|* 31 |         INDEX RANGE SCAN                           | G_PIECEDET_REFP           |      1 |      1 |     1   (0)|      4 |00:00:00.01 |       4 |      0 |
|  32 |      NESTED LOOPS                                  |                           |      1 |      1 |     2   (0)|      1 |00:00:00.01 |      57 |      0 |
|  33 |       NESTED LOOPS                                 |                           |      1 |      1 |     2   (0)|      1 |00:00:00.01 |      56 |      0 |
|  34 |        INLIST ITERATOR                             |                           |      1 |        |            |      5 |00:00:00.01 |       9 |      0 |
|  35 |         TABLE ACCESS BY INDEX ROWID BATCHED        | G_PIECE                   |      1 |      1 |     1   (0)|      5 |00:00:00.01 |       9 |      0 |
|* 36 |          INDEX RANGE SCAN                          | PIE_REFDOSS               |      1 |      1 |     1   (0)|      5 |00:00:00.01 |       4 |      0 |
|* 37 |        INDEX RANGE SCAN                            | G_PIECEDET_REFP           |      5 |      1 |     1   (0)|      1 |00:00:00.01 |      47 |      0 |
|  38 |         SORT AGGREGATE                             |                           |      1 |      1 |            |      1 |00:00:00.01 |      30 |      0 |
|  39 |          NESTED LOOPS                              |                           |      1 |      1 |     2   (0)|     22 |00:00:00.01 |      30 |      0 |
|  40 |           INLIST ITERATOR                          |                           |      1 |        |            |      5 |00:00:00.01 |      13 |      0 |
|  41 |            TABLE ACCESS BY INDEX ROWID BATCHED     | G_PIECE                   |      2 |      1 |     1   (0)|      5 |00:00:00.01 |      13 |      0 |
|* 42 |             INDEX RANGE SCAN                       | PIE_REFDOSS               |      2 |      1 |     1   (0)|      5 |00:00:00.01 |       8 |      0 |
|* 43 |           INDEX RANGE SCAN                         | G_PIECEDET_REFP           |      5 |      1 |     1   (0)|     22 |00:00:00.01 |      17 |      0 |
|* 44 |       TABLE ACCESS BY INDEX ROWID                  | G_PIECEDET                |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       1 |      0 |
|* 45 |     FILTER                                         |                           |      1 |        |            |      1 |00:00:00.01 |     846 |      0 |
|* 46 |      FILTER                                        |                           |      1 |        |            |      1 |00:00:00.01 |     789 |      0 |
|* 47 |       HASH JOIN                                    |                           |      1 |      1 |     8  (13)|      1 |00:00:00.01 |     776 |      0 |
|  48 |        VIEW                                        | VW_NSO_4                  |      1 |    228 |     7  (15)|      1 |00:00:00.01 |       6 |      0 |
|  49 |         SORT UNIQUE                                |                           |      1 |    228 |     7  (15)|      1 |00:00:00.01 |       6 |      0 |
|  50 |          UNION-ALL                                 |                           |      1 |        |            |      1 |00:00:00.01 |       6 |      0 |
|* 51 |           INDEX RANGE SCAN                         | G_DOSSIER_RL_CD_RD_RF_IDX |      1 |    114 |     1   (0)|      1 |00:00:00.01 |       3 |      0 |
|  52 |           NESTED LOOPS                             |                           |      1 |    114 |     6  (17)|      0 |00:00:00.01 |       3 |      0 |
|  53 |            VIEW                                    | VW_NSO_3                  |      1 |      1 |     4   (0)|      0 |00:00:00.01 |       3 |      0 |
|  54 |             SORT UNIQUE                            |                           |      1 |      1 |            |      0 |00:00:00.01 |       3 |      0 |
|  55 |              NESTED LOOPS                          |                           |      1 |      1 |     4   (0)|      0 |00:00:00.01 |       3 |      0 |
|  56 |               NESTED LOOPS                         |                           |      1 |      1 |     4   (0)|      0 |00:00:00.01 |       3 |      0 |
|  57 |                NESTED LOOPS SEMI                   |                           |      1 |      1 |     3   (0)|      0 |00:00:00.01 |       3 |      0 |
|  58 |                 NESTED LOOPS                       |                           |      1 |      1 |     2   (0)|      0 |00:00:00.01 |       3 |      0 |
|* 59 |                  INDEX RANGE SCAN                  | REFHIERARCHIE_IDX         |      1 |      1 |     1   (0)|      0 |00:00:00.01 |       3 |      0 |
|* 60 |                  INDEX RANGE SCAN                  | INT_REFDOSS               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 61 |                 TABLE ACCESS BY INDEX ROWID BATCHED| G_PIECE                   |      0 |    565 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 62 |                  INDEX RANGE SCAN                  | PIE_REFDOSS               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 63 |                INDEX RANGE SCAN                    | GP_GRTYPE_MT_DT           |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 64 |               TABLE ACCESS BY INDEX ROWID          | G_PIECE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 65 |            INDEX RANGE SCAN                        | G_DOSSIER_RL_CD_RD_RF_IDX |      0 |    114 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 66 |        TABLE ACCESS BY INDEX ROWID BATCHED         | G_PIECE                   |      1 |    579 |     1   (0)|    638 |00:00:00.01 |     770 |      0 |
|* 67 |         INDEX RANGE SCAN                           | PIECE_TYP_MT43_IDX        |      1 |    638 |     1   (0)|    638 |00:00:00.01 |       6 |      0 |
|  68 |       SORT AGGREGATE                               |                           |      1 |      1 |            |      1 |00:00:00.01 |      13 |      0 |
|  69 |        NESTED LOOPS                                |                           |      1 |      1 |     2   (0)|      4 |00:00:00.01 |      13 |      0 |
|  70 |         INLIST ITERATOR                            |                           |      1 |        |            |      1 |00:00:00.01 |       9 |      0 |
|  71 |          TABLE ACCESS BY INDEX ROWID BATCHED       | G_PIECE                   |      2 |      1 |     1   (0)|      1 |00:00:00.01 |       9 |      0 |
|* 72 |           INDEX RANGE SCAN                         | PIE_REFDOSS               |      2 |      1 |     1   (0)|      1 |00:00:00.01 |       8 |      0 |
|* 73 |         INDEX RANGE SCAN                           | G_PIECEDET_REFP           |      1 |      1 |     1   (0)|      4 |00:00:00.01 |       4 |      0 |
|  74 |      NESTED LOOPS                                  |                           |      1 |      1 |     2   (0)|      1 |00:00:00.01 |      57 |      0 |
|  75 |       NESTED LOOPS                                 |                           |      1 |      1 |     2   (0)|      1 |00:00:00.01 |      56 |      0 |
|  76 |        INLIST ITERATOR                             |                           |      1 |        |            |      5 |00:00:00.01 |       9 |      0 |
|  77 |         TABLE ACCESS BY INDEX ROWID BATCHED        | G_PIECE                   |      1 |      1 |     1   (0)|      5 |00:00:00.01 |       9 |      0 |
|* 78 |          INDEX RANGE SCAN                          | PIE_REFDOSS               |      1 |      1 |     1   (0)|      5 |00:00:00.01 |       4 |      0 |
|* 79 |        INDEX RANGE SCAN                            | G_PIECEDET_REFP           |      5 |      1 |     1   (0)|      1 |00:00:00.01 |      47 |      0 |
|  80 |         SORT AGGREGATE                             |                           |      1 |      1 |            |      1 |00:00:00.01 |      30 |      0 |
|  81 |          NESTED LOOPS                              |                           |      1 |      1 |     2   (0)|     22 |00:00:00.01 |      30 |      0 |
|  82 |           INLIST ITERATOR                          |                           |      1 |        |            |      5 |00:00:00.01 |      13 |      0 |
|  83 |            TABLE ACCESS BY INDEX ROWID BATCHED     | G_PIECE                   |      2 |      1 |     1   (0)|      5 |00:00:00.01 |      13 |      0 |
|* 84 |             INDEX RANGE SCAN                       | PIE_REFDOSS               |      2 |      1 |     1   (0)|      5 |00:00:00.01 |       8 |      0 |
|* 85 |           INDEX RANGE SCAN                         | G_PIECEDET_REFP           |      5 |      1 |     1   (0)|     22 |00:00:00.01 |      17 |      0 |
|* 86 |       TABLE ACCESS BY INDEX ROWID                  | G_PIECEDET                |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       1 |      0 |
----------------------------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   4 - filter( IS NOT NULL)
   5 - filter("UTL_APP_DATE"."GETAPPDATE"()>)
  14 - access("REFHIERARCHIE"=:REFDOS)
  15 - filter(NVL("GPIACCEPT",'O')<>'N')
  16 - access("REFDOSS"="G_DOSSIER"."REFDOSS" AND "TYPPIECE"='CONTRAT')
       filter("REFDOSS" IS NOT NULL)
  20 - access("I"."REFDOSS"="G_DOSSIER"."REFDOSS" AND "I"."REFTYPE"='CL')
  21 - access("P"."TYPPIECE"='CLIENT_PARAMS' AND "P"."GPIHEURE"="I"."REFINDIVIDU")
       filter("P"."GPIHEURE" IS NOT NULL)
  22 - filter(NVL("P"."FG30",'N')='O')
  24 - access("E"."REFDOSS"=":REFDOS" AND (("E"."TYPPIECE"='CONTRAT' OR "E"."TYPPIECE"='CONTRAT REV')))
       filter("E"."REFDOSS" IS NOT NULL)
  30 - access("P"."REFDOSS"=:REFDOS AND (("P"."TYPPIECE"='CONTRAT' OR "P"."TYPPIECE"='CONTRAT REV')))
  31 - access("P"."REFPIECE"="D"."REFPIECE" AND "D"."TYPE"='CONTRACT SITUATIONS')
       filter("D"."DT01_DT" IS NOT NULL)
  36 - access("P"."REFDOSS"=:REFDOS AND (("P"."TYPPIECE"='A.CONTRAT' OR "P"."TYPPIECE"='A.CONTRAT REV')))
  37 - access("P"."REFPIECE"="D"."REFPIECE" AND "D"."TYPE"='CONTRACT SITUATIONS' AND "D"."DT01_DT"=)
  42 - access("P"."REFDOSS"=:REFDOS AND (("P"."TYPPIECE"='A.CONTRAT' OR "P"."TYPPIECE"='A.CONTRAT REV')))
  43 - access("P"."REFPIECE"="D"."REFPIECE" AND "D"."TYPE"='CONTRACT SITUATIONS')
       filter("D"."DT01_DT" IS NOT NULL)
  44 - filter((INTERNAL_FUNCTION("D"."STR1") OR ("D"."STR1"='T' AND TO_NUMBER(TO_CHAR("UTL_APP_DATE"."GETAPPDATE"(),'j'))<=NVL(:B1,9999999))))
  45 - filter( IS NOT NULL)
  46 - filter("UTL_APP_DATE"."GETAPPDATE"()>)
  47 - access("E"."REFDOSS"="REFDOSS")
  51 - access("REFLOT"=:REFDOS)
  59 - access("REFHIERARCHIE"=:REFDOS)
  60 - access("I"."REFDOSS"="G_DOSSIER"."REFDOSS" AND "I"."REFTYPE"='CL')
  61 - filter(NVL("GPIACCEPT",'O')<>'N')
  62 - access("REFDOSS"="G_DOSSIER"."REFDOSS" AND "TYPPIECE"='CONTRAT')
       filter("REFDOSS" IS NOT NULL)
  63 - access("P"."TYPPIECE"='CLIENT_PARAMS' AND "P"."GPIHEURE"="I"."REFINDIVIDU")
       filter("P"."GPIHEURE" IS NOT NULL)
  64 - filter(NVL("P"."FG30",'N')='O')
  65 - access("REFLOT"="REFDOSS")
  66 - filter("E"."REFDOSS" IS NOT NULL)
  67 - access("E"."TYPPIECE"='SOUS-CONTRAT')
  72 - access("P"."REFDOSS"=:REFDOS AND (("P"."TYPPIECE"='CONTRAT' OR "P"."TYPPIECE"='CONTRAT REV')))
  73 - access("P"."REFPIECE"="D"."REFPIECE" AND "D"."TYPE"='CONTRACT SITUATIONS')
       filter("D"."DT01_DT" IS NOT NULL)
  78 - access("P"."REFDOSS"=:REFDOS AND (("P"."TYPPIECE"='A.CONTRAT' OR "P"."TYPPIECE"='A.CONTRAT REV')))
  79 - access("P"."REFPIECE"="D"."REFPIECE" AND "D"."TYPE"='CONTRACT SITUATIONS' AND "D"."DT01_DT"=)
  84 - access("P"."REFDOSS"=:REFDOS AND (("P"."TYPPIECE"='A.CONTRAT' OR "P"."TYPPIECE"='A.CONTRAT REV')))
  85 - access("P"."REFPIECE"="D"."REFPIECE" AND "D"."TYPE"='CONTRACT SITUATIONS')
       filter("D"."DT01_DT" IS NOT NULL)
  86 - filter((INTERNAL_FUNCTION("D"."STR1") OR ("D"."STR1"='T' AND TO_NUMBER(TO_CHAR("UTL_APP_DATE"."GETAPPDATE"(),'j'))<=NVL(:B1,9999999))))


-- ctxsxppszxaf6

Plan hash value: 2467695247
----------------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                       | Name                      | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers |
----------------------------------------------------------------------------------------------------------------------------------------------------
|   0 | INSERT STATEMENT                                |                           |      1 |        |  2260 (100)|      0 |00:00:00.01 |      24 |
|   1 |  LOAD TABLE CONVENTIONAL                        | G_PIECEDET                |      1 |        |            |      0 |00:00:00.01 |      24 |
|   2 |   SORT AGGREGATE                                |                           |      0 |      1 |            |      0 |00:00:00.01 |       0 |
|   3 |    NESTED LOOPS                                 |                           |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |
|   4 |     INLIST ITERATOR                             |                           |      0 |        |            |      0 |00:00:00.01 |       0 |
|   5 |      TABLE ACCESS BY INDEX ROWID BATCHED        | G_PIECE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|*  6 |       INDEX RANGE SCAN                          | PIE_REFDOSS               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|*  7 |     INDEX RANGE SCAN                            | G_PIECEDET_REFP           |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|   8 |   CONCATENATION                                 |                           |      1 |        |            |      0 |00:00:00.01 |      24 |
|*  9 |    FILTER                                       |                           |      1 |        |            |      0 |00:00:00.01 |      16 |
|  10 |     INLIST ITERATOR                             |                           |      0 |        |            |      0 |00:00:00.01 |       0 |
|  11 |      TABLE ACCESS BY INDEX ROWID BATCHED        | G_PIECE                   |      0 |     31 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 12 |       INDEX RANGE SCAN                          | GP_TYPP_FG01_NB04_DOS_IDX |      0 |     31 |     1   (0)|      0 |00:00:00.01 |       0 |
|  13 |        UNION-ALL                                |                           |      0 |        |            |      0 |00:00:00.01 |       0 |
|* 14 |         FILTER                                  |                           |      0 |        |            |      0 |00:00:00.01 |       0 |
|  15 |          TABLE ACCESS FULL                      | DUAL                      |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|  16 |         NESTED LOOPS SEMI                       |                           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|  17 |          NESTED LOOPS SEMI                      |                           |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|* 18 |           INDEX RANGE SCAN                      | REFHIERARCHIE_IDX         |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 19 |           VIEW                                  | VW_SQ_1                   |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |
|  20 |            NESTED LOOPS                         |                           |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |
|  21 |             NESTED LOOPS                        |                           |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |
|* 22 |              INDEX RANGE SCAN                   | INT_REFDOSS               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 23 |              INDEX RANGE SCAN                   | GP_GRTYPE_MT_DT           |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 24 |             TABLE ACCESS BY INDEX ROWID         | G_PIECE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 25 |          TABLE ACCESS BY INDEX ROWID BATCHED    | G_PIECE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 26 |           INDEX RANGE SCAN                      | PIE_REFDOSS               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|  27 |     NESTED LOOPS                                |                           |      1 |      1 |     2   (0)|      0 |00:00:00.01 |       8 |
|  28 |      NESTED LOOPS                               |                           |      1 |      1 |     2   (0)|      0 |00:00:00.01 |       8 |
|  29 |       INLIST ITERATOR                           |                           |      1 |        |            |      0 |00:00:00.01 |       8 |
|  30 |        TABLE ACCESS BY INDEX ROWID BATCHED      | G_PIECE                   |      2 |      1 |     1   (0)|      0 |00:00:00.01 |       8 |
|* 31 |         INDEX RANGE SCAN                        | PIE_REFDOSS               |      2 |      1 |     1   (0)|      0 |00:00:00.01 |       8 |
|* 32 |       INDEX RANGE SCAN                          | G_PIECEDET_REFP           |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 33 |      TABLE ACCESS BY INDEX ROWID                | G_PIECEDET                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|  34 |     SORT AGGREGATE                              |                           |      1 |      1 |            |      1 |00:00:00.01 |       8 |
|  35 |      NESTED LOOPS                               |                           |      1 |      1 |     2   (0)|      0 |00:00:00.01 |       8 |
|  36 |       NESTED LOOPS                              |                           |      1 |      1 |     2   (0)|      0 |00:00:00.01 |       8 |
|  37 |        INLIST ITERATOR                          |                           |      1 |        |            |      0 |00:00:00.01 |       8 |
|  38 |         TABLE ACCESS BY INDEX ROWID BATCHED     | G_PIECE                   |      2 |      1 |     1   (0)|      0 |00:00:00.01 |       8 |
|* 39 |          INDEX RANGE SCAN                       | PIE_REFDOSS               |      2 |      1 |     1   (0)|      0 |00:00:00.01 |       8 |
|* 40 |        INDEX RANGE SCAN                         | G_PIECEDET_REFP           |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 41 |       TABLE ACCESS BY INDEX ROWID               | G_PIECEDET                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 42 |    FILTER                                       |                           |      1 |        |            |      0 |00:00:00.01 |       8 |
|* 43 |     FILTER                                      |                           |      1 |        |            |      0 |00:00:00.01 |       8 |
|  44 |      TABLE ACCESS BY INDEX ROWID BATCHED        | G_PIECE                   |      0 |     32 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 45 |       INDEX RANGE SCAN                          | GP_TYPP_FG01_NB04_DOS_IDX |      0 |     32 |     1   (0)|      0 |00:00:00.01 |       0 |
|  46 |        UNION-ALL                                |                           |      0 |        |            |      0 |00:00:00.01 |       0 |
|* 47 |         TABLE ACCESS BY INDEX ROWID             | G_DOSSIER                 |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 48 |          INDEX UNIQUE SCAN                      | DOS_REFDOSS               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|  49 |         NESTED LOOPS SEMI                       |                           |      0 |      1 |     5   (0)|      0 |00:00:00.01 |       0 |
|  50 |          TABLE ACCESS BY INDEX ROWID            | G_DOSSIER                 |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 51 |           INDEX UNIQUE SCAN                     | DOS_REFDOSS               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|  52 |          VIEW PUSHED PREDICATE                  | VW_NSO_2                  |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|  53 |           NESTED LOOPS                          |                           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|  54 |            NESTED LOOPS                         |                           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|  55 |             NESTED LOOPS SEMI                   |                           |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|  56 |              NESTED LOOPS                       |                           |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |
|* 57 |               INDEX RANGE SCAN                  | REFHIERARCHIE_IDX         |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 58 |               INDEX RANGE SCAN                  | INT_REFDOSS               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 59 |              TABLE ACCESS BY INDEX ROWID BATCHED| G_PIECE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 60 |               INDEX RANGE SCAN                  | PIE_REFDOSS               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 61 |             INDEX RANGE SCAN                    | GP_GRTYPE_MT_DT           |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 62 |            TABLE ACCESS BY INDEX ROWID          | G_PIECE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|  63 |      NESTED LOOPS                               |                           |      1 |      1 |     2   (0)|      0 |00:00:00.01 |       8 |
|  64 |       NESTED LOOPS                              |                           |      1 |      1 |     2   (0)|      0 |00:00:00.01 |       8 |
|  65 |        INLIST ITERATOR                          |                           |      1 |        |            |      0 |00:00:00.01 |       8 |
|  66 |         TABLE ACCESS BY INDEX ROWID BATCHED     | G_PIECE                   |      2 |      1 |     1   (0)|      0 |00:00:00.01 |       8 |
|* 67 |          INDEX RANGE SCAN                       | PIE_REFDOSS               |      2 |      1 |     1   (0)|      0 |00:00:00.01 |       8 |
|* 68 |        INDEX RANGE SCAN                         | G_PIECEDET_REFP           |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 69 |       TABLE ACCESS BY INDEX ROWID               | G_PIECEDET                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|  70 |      SORT AGGREGATE                             |                           |      0 |      1 |            |      0 |00:00:00.01 |       0 |
|  71 |       NESTED LOOPS                              |                           |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |
|  72 |        NESTED LOOPS                             |                           |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |
|  73 |         INLIST ITERATOR                         |                           |      0 |        |            |      0 |00:00:00.01 |       0 |
|  74 |          TABLE ACCESS BY INDEX ROWID BATCHED    | G_PIECE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 75 |           INDEX RANGE SCAN                      | PIE_REFDOSS               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 76 |         INDEX RANGE SCAN                        | G_PIECEDET_REFP           |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 77 |        TABLE ACCESS BY INDEX ROWID              | G_PIECEDET                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|  78 |     UNION-ALL                                   |                           |      0 |        |            |      0 |00:00:00.01 |       0 |
|* 79 |      FILTER                                     |                           |      0 |        |            |      0 |00:00:00.01 |       0 |
|  80 |       TABLE ACCESS FULL                         | DUAL                      |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|  81 |      NESTED LOOPS SEMI                          |                           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |
|  82 |       NESTED LOOPS SEMI                         |                           |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|* 83 |        INDEX RANGE SCAN                         | REFHIERARCHIE_IDX         |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 84 |        VIEW                                     | VW_SQ_1                   |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |
|  85 |         NESTED LOOPS                            |                           |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |
|  86 |          NESTED LOOPS                           |                           |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |
|* 87 |           INDEX RANGE SCAN                      | INT_REFDOSS               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 88 |           INDEX RANGE SCAN                      | GP_GRTYPE_MT_DT           |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 89 |          TABLE ACCESS BY INDEX ROWID            | G_PIECE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 90 |       TABLE ACCESS BY INDEX ROWID BATCHED       | G_PIECE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 91 |        INDEX RANGE SCAN                         | PIE_REFDOSS               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|  92 |     SORT AGGREGATE                              |                           |      1 |      1 |            |      1 |00:00:00.01 |       8 |
|  93 |      NESTED LOOPS                               |                           |      1 |      1 |     2   (0)|      0 |00:00:00.01 |       8 |
|  94 |       NESTED LOOPS                              |                           |      1 |      1 |     2   (0)|      0 |00:00:00.01 |       8 |
|  95 |        INLIST ITERATOR                          |                           |      1 |        |            |      0 |00:00:00.01 |       8 |
|  96 |         TABLE ACCESS BY INDEX ROWID BATCHED     | G_PIECE                   |      2 |      1 |     1   (0)|      0 |00:00:00.01 |       8 |
|* 97 |          INDEX RANGE SCAN                       | PIE_REFDOSS               |      2 |      1 |     1   (0)|      0 |00:00:00.01 |       8 |
|* 98 |        INDEX RANGE SCAN                         | G_PIECEDET_REFP           |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 99 |       TABLE ACCESS BY INDEX ROWID               | G_PIECEDET                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
----------------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   6 - access("PR"."REFDOSS"=:REFDOS AND (("PR"."TYPPIECE"='CONTRAT' OR "PR"."TYPPIECE"='CONTRAT REV')))
   7 - access("PR"."REFPIECE"="DR"."REFPIECE" AND "DR"."TYPE"='CONTRACT SITUATIONS')
       filter("DR"."DT01_DT" IS NOT NULL)
   9 - filter(( IS NULL AND "UTL_APP_DATE"."GETAPPDATE"()<=))
  12 - access(("TYPPIECE"='CONTRAT' OR "TYPPIECE"='CONTRAT REV'))
       filter( IS NOT NULL)
  14 - filter(:B1=:REFDOS)
  18 - access("REFHIERARCHIE"=:REFDOS AND "REFDOSS"=:B1)
       filter("REFDOSS"=:B1)
  19 - filter("ITEM_1"="G_DOSSIER"."REFDOSS")
  22 - access("I"."REFDOSS"=:B1 AND "I"."REFTYPE"='CL')
  23 - access("P"."TYPPIECE"='CLIENT_PARAMS' AND "P"."GPIHEURE"="I"."REFINDIVIDU")
       filter("P"."GPIHEURE" IS NOT NULL)
  24 - filter(NVL("P"."FG30",'N')='O')
  25 - filter(NVL("GPIACCEPT",'O')<>'N')
  26 - access("REFDOSS"=:B1 AND "TYPPIECE"='CONTRAT')
       filter("REFDOSS"="G_DOSSIER"."REFDOSS")
  31 - access("PA"."REFDOSS"=:REFDOS AND (("PA"."TYPPIECE"='CONTRAT' OR "PA"."TYPPIECE"='CONTRAT REV')))
  32 - access("PA"."REFPIECE"="DA"."REFPIECE" AND "DA"."TYPE"='CONTRACT SITUATIONS')
  33 - filter("DA"."STR1"='V')
  39 - access("P"."REFDOSS"=:REFDOS AND (("P"."TYPPIECE"='CONTRAT' OR "P"."TYPPIECE"='CONTRAT REV')))
  40 - access("P"."REFPIECE"="D"."REFPIECE" AND "D"."TYPE"='CONTRACT SITUATIONS')
       filter("D"."DT01_DT" IS NOT NULL)
  41 - filter("D"."STR1"<>'V')
  42 - filter(((LNNVL("TYPPIECE"='CONTRAT') AND LNNVL("TYPPIECE"='CONTRAT REV')) OR LNNVL( IS NOT NULL) OR
              LNNVL("UTL_APP_DATE"."GETAPPDATE"()<=)))
  43 - filter(( IS NULL AND "UTL_APP_DATE"."GETAPPDATE"()<=))
  45 - access("TYPPIECE"='SOUS-CONTRAT')
       filter( IS NOT NULL)
  47 - filter("REFLOT"=:REFDOS)
  48 - access("REFDOSS"=:B1)
  51 - access("REFDOSS"=:B1)
  57 - access("REFHIERARCHIE"=:REFDOS AND "REFDOSS"="REFLOT")
       filter("REFDOSS"="REFLOT")
  58 - access("I"."REFDOSS"="REFLOT" AND "I"."REFTYPE"='CL')
  59 - filter(NVL("GPIACCEPT",'O')<>'N')
  60 - access("REFDOSS"="REFLOT" AND "TYPPIECE"='CONTRAT')
       filter("REFDOSS"="G_DOSSIER"."REFDOSS")
  61 - access("P"."TYPPIECE"='CLIENT_PARAMS' AND "P"."GPIHEURE"="I"."REFINDIVIDU")
       filter("P"."GPIHEURE" IS NOT NULL)
  62 - filter(NVL("P"."FG30",'N')='O')
  67 - access("PA"."REFDOSS"=:REFDOS AND (("PA"."TYPPIECE"='CONTRAT' OR "PA"."TYPPIECE"='CONTRAT REV')))
  68 - access("PA"."REFPIECE"="DA"."REFPIECE" AND "DA"."TYPE"='CONTRACT SITUATIONS')
  69 - filter("DA"."STR1"='V')
  75 - access("P"."REFDOSS"=:REFDOS AND (("P"."TYPPIECE"='CONTRAT' OR "P"."TYPPIECE"='CONTRAT REV')))
  76 - access("P"."REFPIECE"="D"."REFPIECE" AND "D"."TYPE"='CONTRACT SITUATIONS')
       filter("D"."DT01_DT" IS NOT NULL)
  77 - filter("D"."STR1"<>'V')
  79 - filter(:B1=:REFDOS)
  83 - access("REFHIERARCHIE"=:REFDOS AND "REFDOSS"=:B1)
       filter("REFDOSS"=:B1)
  84 - filter("ITEM_1"="G_DOSSIER"."REFDOSS")
  87 - access("I"."REFDOSS"=:B1 AND "I"."REFTYPE"='CL')
  88 - access("P"."TYPPIECE"='CLIENT_PARAMS' AND "P"."GPIHEURE"="I"."REFINDIVIDU")
       filter("P"."GPIHEURE" IS NOT NULL)
  89 - filter(NVL("P"."FG30",'N')='O')
  90 - filter(NVL("GPIACCEPT",'O')<>'N')
  91 - access("REFDOSS"=:B1 AND "TYPPIECE"='CONTRAT')
       filter("REFDOSS"="G_DOSSIER"."REFDOSS")
  97 - access("P"."REFDOSS"=:REFDOS AND (("P"."TYPPIECE"='CONTRAT' OR "P"."TYPPIECE"='CONTRAT REV')))
  98 - access("P"."REFPIECE"="D"."REFPIECE" AND "D"."TYPE"='CONTRACT SITUATIONS')
       filter("D"."DT01_DT" IS NOT NULL)
  99 - filter("D"."STR1"<>'V')
*/
/********************************New Metrics***************************************/

/********************************Index statistics**********************************/

/********************************Other SQLs****************************************/          
/*

*/ 
/********************************Other SQLs****************************************/              
