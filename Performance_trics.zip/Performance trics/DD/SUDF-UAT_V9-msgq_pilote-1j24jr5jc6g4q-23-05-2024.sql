/********************************************************************************
*********       E-mail subject: SUDFWEB-1872
*********             Instance: UAT V9
*********          Description: 
Problem:
SQL 1j24jr5jc6g4q was the second TOP SQL in msgq_pilote module.

Analysis:
SQL 1j24jr5jc6g4q has several problems from performance point of view. We added hints to force Oracle to choose good execution plan, 
moved the function FTR_LIMIT_CACHE.GETACTIVEGLOBALPOLICYOFCASE from the where clause to the select part 
( as it is described in document SQL_with_SLA_acceptable_performanceon the P&T wiki page, it is not a good idea to call functions in the where clause ). 
Also, we added condition AND DECOMPTE.CATEGDOSS LIKE 'DECOMPTE%' to filter the selected rows from DECOMPTE.REFLOT = :B1 and left only these, which are DECOMPTES.

Suggestion:
Please check if the added condition AND DECOMPTE.CATEGDOSS LIKE 'DECOMPTE%' s functionally correct and if it is, 
please apply the suggested modifications from the New SQL section below.

*********               SQL_ID: 1j24jr5jc6g4q
*********      Program/Package: FTR_LIMIT_CACHE 
*********              Request: Zhan Nikolov 
*********               Author: Dimitar Dimitrov
********* Received e-mail date: 22/05/2024
*********      Resolution date: 23/05/2024
*********  Trace old file here: \\epox\specifs\performance\tmp\
*********  Trace new file here:
***********************************************************************************/

/********************************OLD SQL*******************************************/

VAR B1 VARCHAR2(32);
EXEC :B1 := '0001010092';

SELECT DISTINCT VENFI.COMPTE_ID,
                VENFI.LIMIT_ID,
                VENFI.LIMIT_DETAIL_ID,
                LIM.GPIRESSORT
  FROM G_VENDOSSLIMIT VENDOSS,
       G_PIECE        LIM,
       G_DOSSIER      COMPTE,
       G_DOSSIER      DECOMPTE,
       G_VENFILIMIT   VENFI
 WHERE DECOMPTE.REFLOT = :B1
   AND DECOMPTE.REFDOSS = COMPTE.REFLOT
   AND COMPTE.REFDOSS = VENDOSS.REFDOSS
   AND VENDOSS.LIMIT_ID = LIM.REFPIECE
   AND LIM.REFEXT = 'DB-POL'
   AND FTR_LIMIT_CACHE.GETACTIVEGLOBALPOLICYOFCASE(COMPTE.REFDOSS) != LIM.GPIRESSORT
   AND VENFI.LIMIT_ID = LIM.REFPIECE
   AND VENFI.COMPTE_ID = COMPTE.REFDOSS;
/********************************OLD SQL*******************************************/
/********************************OLD Metrics***************************************/
/*
Plan hash value: 65695273
------------------------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                 | Name                           | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  |
------------------------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                          |                                |      1 |        |     6 (100)|      0 |00:00:40.91 |    6274K|      4 |
|   1 |  HASH UNIQUE                              |                                |      1 |      1 |     6  (17)|      0 |00:00:40.91 |    6274K|      4 |
|   2 |   NESTED LOOPS                            |                                |      1 |      1 |     5   (0)|      0 |00:00:40.91 |    6274K|      4 |
|   3 |    NESTED LOOPS                           |                                |      1 |    357 |     5   (0)|      0 |00:00:40.91 |    6274K|      4 |
|   4 |     NESTED LOOPS                          |                                |      1 |      1 |     4   (0)|      0 |00:00:40.91 |    6274K|      4 |
|   5 |      NESTED LOOPS                         |                                |      1 |     12 |     3   (0)|   2244 |00:00:40.90 |    6272K|      4 |
|   6 |       NESTED LOOPS                        |                                |      1 |     12 |     2   (0)|    198K|00:00:01.02 |     238K|      0 |
|   7 |        TABLE ACCESS BY INDEX ROWID BATCHED| G_PIECE                        |      1 |      6 |     1   (0)|    187K|00:00:00.57 |     122K|      0 |
|*  8 |         INDEX RANGE SCAN                  | PIE_DOUBL                      |      1 |      6 |     1   (0)|    187K|00:00:00.05 |     710 |      0 |
|*  9 |        INDEX RANGE SCAN                   | G_VENDOSSLIMIT$REFDOSS_LIMITID |    187K|      2 |     1   (0)|    198K|00:00:00.40 |     115K|      0 |
|* 10 |       INDEX RANGE SCAN                    | DOS_REFDOSS_REFLOT_IDX         |    198K|      1 |     1   (0)|   2244 |00:00:39.84 |    6034K|      4 |
|* 11 |      INDEX RANGE SCAN                     | DOS_REFDOSS_REFLOT_IDX         |   2244 |      1 |     1   (0)|      0 |00:00:00.01 |    2470 |      0 |
|* 12 |     INDEX RANGE SCAN                      | G_VENFILIMIT$LIMIT_ID_IDX      |      0 |    357 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 13 |    TABLE ACCESS BY INDEX ROWID            | G_VENFILIMIT                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
------------------------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   8 - access("LIM"."REFEXT"='DB-POL')
   9 - access("VENDOSS"."LIMIT_ID"="LIM"."REFPIECE")
  10 - access("COMPTE"."REFDOSS"="VENDOSS"."REFDOSS")
       filter("LIM"."GPIRESSORT"<>"FTR_LIMIT_CACHE"."GETACTIVEGLOBALPOLICYOFCASE"("COMPTE"."REFDOSS"))
  11 - access("DECOMPTE"."REFDOSS"="COMPTE"."REFLOT" AND "DECOMPTE"."REFLOT"=:B1)
  12 - access("VENFI"."LIMIT_ID"="LIM"."REFPIECE")
  13 - filter("VENFI"."COMPTE_ID"="COMPTE"."REFDOSS") 
*/
/********************************OLD Metrics***************************************/

/********************************New SQL*******************************************/

select COMPTE_ID,
       LIMIT_ID,
       LIMIT_DETAIL_ID,
       GPIRESSORT
       from (
SELECT /*+ leading(DECOMPTE COMPTE VENDOSS LIM) index(LIM PIE_REFPIECE) */
       DISTINCT VENFI.COMPTE_ID,
                VENFI.LIMIT_ID,
                VENFI.LIMIT_DETAIL_ID,
                LIM.GPIRESSORT,
                (select FTR_LIMIT_CACHE.GETACTIVEGLOBALPOLICYOFCASE(COMPTE.REFDOSS) from dual ) GETACTIVEGLOBALPOLICYOFCASE   
  FROM G_VENDOSSLIMIT VENDOSS,
       G_PIECE        LIM,
       G_DOSSIER      COMPTE,
       G_DOSSIER      DECOMPTE,
       G_VENFILIMIT   VENFI
 WHERE DECOMPTE.REFLOT = :B1
   AND DECOMPTE.CATEGDOSS LIKE 'DECOMPTE%'
   AND DECOMPTE.REFDOSS = COMPTE.REFLOT
   AND COMPTE.REFDOSS = VENDOSS.REFDOSS
   AND VENDOSS.LIMIT_ID = LIM.REFPIECE
   AND LIM.REFEXT = 'DB-POL'
   AND VENFI.LIMIT_ID = LIM.REFPIECE
   AND VENFI.COMPTE_ID = COMPTE.REFDOSS)
where GETACTIVEGLOBALPOLICYOFCASE != GPIRESSORT;
/********************************New SQL*******************************************/
/********************************New Metrics***************************************/
/*
Plan hash value: 2234075736
-----------------------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                | Name                           | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  |
-----------------------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                         |                                |      1 |        |  1940 (100)|      0 |00:00:11.85 |   96051 |  14236 |
|   1 |  FAST DUAL                               |                                |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*  2 |  VIEW                                    |                                |      1 |      1 |  1940   (1)|      0 |00:00:11.85 |   96051 |  14236 |
|   3 |   HASH UNIQUE                            |                                |      1 |      1 |  1940   (1)|      0 |00:00:11.85 |   96051 |  14236 |
|   4 |    NESTED LOOPS                          |                                |      1 |      1 |  1937   (1)|      0 |00:00:11.85 |   96051 |  14236 |
|   5 |     NESTED LOOPS                         |                                |      1 |    357 |  1937   (1)|      0 |00:00:11.85 |   96051 |  14236 |
|   6 |      NESTED LOOPS                        |                                |      1 |      1 |  1936   (1)|      0 |00:00:11.85 |   96051 |  14236 |
|*  7 |       HASH JOIN                          |                                |      1 |  40942 |   297   (5)|  69799 |00:00:11.58 |   28127 |  14236 |
|   8 |        NESTED LOOPS                      |                                |      1 |   5166 |     2   (0)|   8542 |00:00:00.01 |     112 |      0 |
|*  9 |         INDEX RANGE SCAN                 | G_DOSSIER_RL_CD_RD_RF_IDX      |      1 |     32 |     1   (0)|      1 |00:00:00.01 |       3 |      0 |
|* 10 |         INDEX RANGE SCAN                 | G_DOSSIER_RL_CD_RD_RF_IDX      |      1 |    161 |     1   (0)|   8542 |00:00:00.01 |     109 |      0 |
|  11 |        INDEX FULL SCAN                   | G_VENDOSSLIMIT$REFDOSS_LIMITID |      1 |   2490K|   283   (0)|   2492K|00:00:11.25 |   28015 |  14236 |
|* 12 |       TABLE ACCESS BY INDEX ROWID BATCHED| G_PIECE                        |  69799 |      1 |     1   (0)|      0 |00:00:00.26 |   67924 |      0 |
|* 13 |        INDEX RANGE SCAN                  | PIE_REFPIECE                   |  69799 |      1 |     1   (0)|  69799 |00:00:00.12 |   50847 |      0 |
|* 14 |      INDEX RANGE SCAN                    | G_VENFILIMIT$LIMIT_ID_IDX      |      0 |    357 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 15 |     TABLE ACCESS BY INDEX ROWID          | G_VENFILIMIT                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
-----------------------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   2 - filter("GETACTIVEGLOBALPOLICYOFCASE"<>"GPIRESSORT")
   7 - access("COMPTE"."REFDOSS"="VENDOSS"."REFDOSS")
   9 - access("DECOMPTE"."REFLOT"=:B1 AND "DECOMPTE"."CATEGDOSS" LIKE 'DECOMPTE%')
       filter("DECOMPTE"."CATEGDOSS" LIKE 'DECOMPTE%')
  10 - access("DECOMPTE"."REFDOSS"="COMPTE"."REFLOT")
  12 - filter("LIM"."REFEXT"='DB-POL')
  13 - access("VENDOSS"."LIMIT_ID"="LIM"."REFPIECE")
  14 - access("VENFI"."LIMIT_ID"="LIM"."REFPIECE")
  15 - filter("VENFI"."COMPTE_ID"="COMPTE"."REFDOSS")  
*/
/********************************New Metrics***************************************/

/********************************Index statistics**********************************/

/********************************Other SQLs****************************************/          
/*

*/ 
/********************************Other SQLs****************************************/              
