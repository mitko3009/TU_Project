/********************************************************************************
*********       E-mail subject: LOCAMDEV-16139
*********             Instance: BIRDVAL
*********          Description: 
Problem:
ORA-01652: unable to extend temp segment by 128 in tablespace TEMP error when 
trying to use both script mass_cleaning_t_debuglog_and_t_debuglogdtl.sql which is 
done in EFDEWEB-1459 and mass_cleaning_t_debuglogdtl.sql which is done in KBCCF-8630.


Analysis:
Due to the bug in LOCAMDEV-18766 there was so many data in both tables for deletion, 
which was hard to be deleted even after optimization due to the space limitations in TEMP and TS_IMXDATA and TS_IMXINDEX tablespace.

Suggestion:
Please apply proposed optimization in the New SQL section below in mass_cleaning_T_DEBUGLOG_and_T_DEBUGLOGDTL 
and  mass_cleaning_T_DEBUGLOGDTL.

*********               SQL_ID: 67af7pbpcszb0
*********      Program/Package: e_leas_demfin_light
*********              Request: Dobrin Atanasov
*********               Author: Dimitar Dimitrov
********* Received e-mail date: 14/08/2023
*********      Resolution date: 14/08/2023
*********  Trace old file here: \\epox\specifs\performance\tmp\
*********  Trace new file here:
***********************************************************************************/

/********************************OLD SQL*******************************************/
CREATE TABLE TMP_T_DEBUGLOGDTL AS
SELECT * FROM T_DEBUGLOGDTL
WHERE headerid in
(SELECT /*+ unnest full(T_FD_HEADER) */ id
   FROM T_DEBUGLOG
  WHERE start_time >= trunc(SYSDATE) - 30  )
;
/********************************OLD SQL*******************************************/
/********************************OLD Metrics***************************************/
/*
Plan hash value: 2183095245

--------------------------------------------------------------------------------------------------------------------
| Id  | Operation                              | Name              | Rows  | Bytes |TempSpc| Cost (%CPU)| Time     |
--------------------------------------------------------------------------------------------------------------------
|   0 | CREATE TABLE STATEMENT                 |                   |       |       |       |   360K(100)|          |
|   1 |  LOAD AS SELECT                        | TMP_T_DEBUGLOGDTL |       |       |       |            |          |
|   2 |   MERGE JOIN                           |                   |    76M|  6361M|       |   150K  (1)| 00:00:06 |
|   3 |    TABLE ACCESS BY INDEX ROWID         | T_DEBUGLOGDTL     |    76M|  5264M|       | 85259   (1)| 00:00:04 |
|   4 |     INDEX FULL SCAN                    | HEADERID_IDX      |    76M|       |       |  1890   (1)| 00:00:01 |
|   5 |    SORT JOIN                           |                   |    11M|   169M|   544M| 65601   (1)| 00:00:03 |
|   6 |     TABLE ACCESS BY INDEX ROWID BATCHED| T_DEBUGLOG        |    11M|   169M|       |  4564   (1)| 00:00:01 |
|   7 |      INDEX RANGE SCAN                  | START_TIME_IDX    |    11M|       |       |   313   (1)| 00:00:01 |
--------------------------------------------------------------------------------------------------------------------

Hint Report (identified by operation id / Query Block Name / Object Alias):
Total hints for statement: 1 (N - Unresolved (1))
---------------------------------------------------------------------------

   0 -  SEL$2
         N -  full(T_FD_HEADER)
*/
/********************************OLD Metrics***************************************/

/********************************New SQL*******************************************/
CREATE  TABLE TMP_T_DEBUGLOGDTL AS
SELECT /*+ use_hash(DTL) no_swap_join_inputs(DTL) */ DTL.*
  FROM (SELECT /*+ no_merge */ *
          FROM T_DEBUGLOGDTL) DTL,
        (SELECT /*+ full(T_DEBUGLOG) no_merge */ id
           FROM T_DEBUGLOG
          WHERE start_time >= trunc(SYSDATE) - 30 ) LG
 WHERE DTL.headerid = LG.id;
/********************************New SQL*******************************************/
/********************************New Metrics***************************************/
/*
Plan hash value: 3311149220

-------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                        | Name              | Starts | E-Rows | A-Rows |   A-Time   | Buffers | Reads  |
-------------------------------------------------------------------------------------------------------------------------
|   0 | CREATE TABLE STATEMENT           |                   |      1 |        |      0 |00:00:00.01 |       0 |      0 |
|   1 |  LOAD AS SELECT                  | TMP_T_DEBUGLOGDTL |      1 |        |      0 |00:00:00.01 |       0 |      0 |
|   2 |   OPTIMIZER STATISTICS GATHERING |                   |      1 |     76M|      0 |00:00:00.01 |       0 |      0 |
|*  3 |    HASH JOIN                     |                   |      1 |     76M|      0 |00:00:00.01 |       0 |      0 |
|   4 |     VIEW                         |                   |      1 |     11M|   1961K|00:00:01.83 |   16905 |  16933 |
|*  5 |      TABLE ACCESS FULL           | T_DEBUGLOG        |      1 |     11M|   1961K|00:00:01.83 |   16905 |  16933 |
|   6 |     VIEW                         |                   |      0 |     76M|      0 |00:00:00.01 |       0 |      0 |
|   7 |      TABLE ACCESS FULL           | T_DEBUGLOGDTL     |      0 |     76M|      0 |00:00:00.01 |       0 |      0 |
-------------------------------------------------------------------------------------------------------------------------

Predicate Information (identified by operation id):
---------------------------------------------------

   3 - access("DTL"."HEADERID"="LG"."ID")
   5 - filter("START_TIME">=TRUNC(SYSDATE@!)-30)
*/
/********************************New Metrics***************************************/

/********************************Index statistics**********************************/

/********************************Other SQLs****************************************/          
/*

*/ 
/********************************Other SQLs****************************************/              
