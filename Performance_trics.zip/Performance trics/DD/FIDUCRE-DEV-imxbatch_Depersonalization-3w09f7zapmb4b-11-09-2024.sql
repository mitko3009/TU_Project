/********************************************************************************
*********       E-mail subject: FIDWEB-3020
*********             Instance: DEV
*********          Description: 
Problem:
The imxbatch_Depersonalization took over 24 hours on DEV until it failed for TEMP.

Analysis:
We analyzed the work of the imxbatch_Depersonalization and found that the two TOP SQLs 3w09f7zapmb4b and d5famw5c56166 were responsible for ~ 90% of the time.
In the New SQL section below you can find optimization for them. The optimization is that we added hints ( only for the Depersonalization batch) to force the queries to be make FULL TABLE SCANs.
For the provided UPDATE statement on table T_ELEMENTS in the task ( SQL_ID ch18w644wz5z9 ), we tried to find performance improvement in which to use less TEMP. We found that there is a variand, where we select only 
the distinct refdosses from table t_intervenants, hash join them with table T_ELEMENTS and than make filter of the conditions in v_domaine. This variant based on our test should not eat so much 
TEMP, so please change the UPDATE statement on table T_ELEMENTS as it is shown on the New SQL section below.

Suggestion:
1. Please change SQLs 3w09f7zapmb4b and d5famw5c56166 as it is shown in the New SQL section below.
2. Please change the UPDATE statement on table T_ELEMENTS as it is shown on the New SQL section below.

*********               SQL_ID: 3w09f7zapmb4b, d5famw5c56166, ch18w644wz5z9
*********      Program/Package: 
*********              Request: Ngan Ngoc Thuy To 
*********               Author: Dimitar Dimitrov
********* Received e-mail date: 11/09/2024
*********      Resolution date: 11/09/2024
*********  Trace old file here: \\epox\specifs\performance\tmp\
*********  Trace new file here:
***********************************************************************************/

/********************************OLD SQL*******************************************/

-- 3w09f7zapmb4b



UPDATE G_TEXTE
   SET PARAGRAPHE = NULL
 WHERE reftexte IN ( SELECT te.refelem
                       FROM t_elements te,
                            g_texte t,
                            ( SELECT DISTINCT ti.refdoss
                                FROM g_individu c, 
                                     t_intervenants ti
                               WHERE c.moralphy IN ('M', 'P')
                                 AND ti.refindividu = c.refindividu
                                 AND ti.refindividu IN ( SELECT REFINDIVIDU 
                                                           FROM tmp_deperson_curs ) ) d
                      WHERE te.refdoss = d.refdoss
                        AND te.typeelem in ( 'pe',
                                             'fi',
                                             'en',
                                             'vd',
                                             'sm',
                                             'me',
                                             'mr',
                                             'at',
                                             'tp',
                                             'fx',
                                             've',
                                             'tp',
                                             'ep',
                                             'fa',
                                             'di',
                                             'sd',
                                             'ie',
                                             'ng',
                                             'et',
                                             're' )
                        AND te.refelem = t.reftexte
                        AND t.refds = d.refdoss );


-- d5famw5c56166


UPDATE G_INFORMATION
   SET STR_10_1    = NULL,
       DTSAISIE_DT = NULL,
       REFPRENEUR  = NULL,
       REFEMETTEUR = NULL,
       LIBELINFO   = NULL,
       REFEXT2     = NULL,
       ENCODEUR    = NULL,
       CREATEUR    = NULL,
       NOMEMETTEUR = NULL,
       TYPEDOC     = NULL,
       LIBREINFO   = NULL
 WHERE refinfo IN ( SELECT te.refelem
                      FROM t_elements te,
                           ( SELECT DISTINCT ti.refdoss
                               FROM g_individu c,
                                    t_intervenants ti
                              WHERE c.moralphy IN ('M', 'P')
                                AND ti.refindividu = c.refindividu
                                AND ti.refindividu IN ( SELECT REFINDIVIDU 
                                                          FROM tmp_deperson_curs ) ) d
                     WHERE te.refdoss = d.refdoss);



-- UPDATE statement on table T_ELEMENTS, which was provided in the task.

 UPDATE T_ELEMENTS
    SET LIBELLE =  NULL
  WHERE typeelem in ( SELECT abrev 
                        from v_domaine 
                       where type='ELEM_CHRONO' ) 
    and refdoss in ( SELECT refdoss 
                       from t_intervenants 
                      where refindividu  IN ( SELECT REFINDIVIDU 
                                                FROM tmp_deperson_curs ) );



/********************************OLD SQL*******************************************/
/********************************OLD Metrics***************************************/
/*
SAMPLE_TIME                     SID   SERIAL# MODULE                                   CLIENT_IDENTIFIER                        TEMP_SPACE_ALLOCATED_MB SQL_ID
------------------------- --------- --------- ---------------------------------------- ---------------------------------------- ----------------------- -------------
2024/09/11 10:28:31              59     33915 imxbatch_Depersonalization                                                                           9788 ch18w644wz5z9
2024/09/11 10:28:21              59     33915 imxbatch_Depersonalization                                                                           9472 ch18w644wz5z9
2024/09/11 10:28:11              59     33915 imxbatch_Depersonalization                                                                           9191 ch18w644wz5z9
2024/09/11 10:28:01              59     33915 imxbatch_Depersonalization                                                                           8859 ch18w644wz5z9
2024/09/11 10:27:51              59     33915 imxbatch_Depersonalization                                                                           8509 ch18w644wz5z9
2024/09/11 10:27:41              59     33915 imxbatch_Depersonalization                                                                           8115 ch18w644wz5z9
2024/09/11 10:27:31              59     33915 imxbatch_Depersonalization                                                                           7826 ch18w644wz5z9
2024/09/11 10:27:21              59     33915 imxbatch_Depersonalization                                                                           7422 ch18w644wz5z9
2024/09/11 10:27:11              59     33915 imxbatch_Depersonalization                                                                           6848 ch18w644wz5z9
2024/09/11 10:27:01              59     33915 imxbatch_Depersonalization                                                                           6423 ch18w644wz5z9
2024/09/11 10:26:51              59     33915 imxbatch_Depersonalization                                                                           6051 ch18w644wz5z9
2024/09/11 10:26:41              59     33915 imxbatch_Depersonalization                                                                           5633 ch18w644wz5z9
2024/09/11 10:26:31              59     33915 imxbatch_Depersonalization                                                                           5363 ch18w644wz5z9
2024/09/11 10:26:21              59     33915 imxbatch_Depersonalization                                                                           4927 ch18w644wz5z9
2024/09/11 10:26:11              59     33915 imxbatch_Depersonalization                                                                           4629 ch18w644wz5z9
2024/09/11 10:26:00              59     33915 imxbatch_Depersonalization                                                                           4219 ch18w644wz5z9
2024/09/10 16:17:04              59     33915 imxbatch_Depersonalization                                                                           4054 d5famw5c56166
2024/09/10 16:17:14              59     33915 imxbatch_Depersonalization                                                                           4054 d5famw5c56166
2024/09/10 16:17:24              59     33915 imxbatch_Depersonalization                                                                           4054 d5famw5c56166
2024/09/10 16:17:34              59     33915 imxbatch_Depersonalization                                                                           4054 d5famw5c56166
                                                                                                                                                                      4054 d5famw5c56166



MODULE                    SQL_ID         PLAN_HASH SID    SERIAL# EVENT                          FROM                           TO                                 ACTIVE NUMBER_OF_EXECUTIONS PERC
------------------------- ------------- ---------- ------ ------- ------------------------------ ------------------------------ ------------------------------ ---------- -------------------- ------
imxbatch_Depersonalizatio                          59     33915                                  2024/09/11 00:10:08            2024/09/11 10:28:41                 36990                    1 56%
backup incr datafile      NULL                                                                   2024/09/11 00:10:08            2024/09/11 01:48:22                 23400                      35%
SQL*Plus                                                                                         2024/09/11 00:10:08            2024/09/11 11:46:39                  3230              2406937 5%
restore incr datafile     NULL                                                                   2024/09/11 01:48:52            2024/09/11 01:52:12                   710                      1%
service_bus_broker                                 67     10000   ON CPU                         2024/09/11 00:10:58            2024/09/11 10:41:54                   430              4909376 1%
rman                                                                                             2024/09/11 00:42:02            2024/09/11 11:13:22                   270               127740 0%
Oracle Enterprise Manager                                                                        2024/09/11 00:15:29            2024/09/11 11:45:29                   260                 1397 0%
backup archivelog         NULL                                                                   2024/09/11 00:11:38            2024/09/11 10:28:21                   190                      0%
stat_crx                                                                                         2024/09/11 00:42:02            2024/09/11 11:47:30                   150              5433387 0%
oracle_agent_main                                                                                2024/09/11 00:12:38            2024/09/11 10:49:06                   120                82465 0%
stat_crx_rangmt                                                                                  2024/09/11 00:42:22            2024/09/11 10:47:16                   110              5174983 0%
DBMS_SCHEDULER                                     845                                           2024/09/11 09:20:26            2024/09/11 09:24:46                    90                   30 0%
sqlplus                                                           ON CPU                         2024/09/11 03:20:12            2024/09/11 07:03:14                    40                    1 0%
emagent_SQL_oracle_databa                          800    16747   ON CPU                         2024/09/11 02:45:04            2024/09/11 05:41:35                    20                    7 0%
msgq                      8utspd5p63yxg 1462754499 20             ON CPU                         2024/09/11 01:07:54            2024/09/11 10:44:25                    20                 9221 0%
envoi_sp                  c1gszng5dj7zk 1734708297 839    32855   ON CPU                         2024/09/11 07:37:42            2024/09/11 07:37:42                    10                    1 0%



MODULE                    SQL_ID         PLAN_HASH SID    SERIAL# EVENT                          FROM                           TO                                 ACTIVE NUMBER_OF_EXECUTIONS PERC
------------------------- ------------- ---------- ------ ------- ------------------------------ ------------------------------ ------------------------------ ---------- -------------------- ------
imxbatch_Depersonalizatio                          59     33915   db file sequential read        2024/09/11 00:10:08            2024/09/11 10:23:30                 36050                    1 50%
n

backup incr datafile      NULL                                    RMAN backup & recovery I/O     2024/09/11 00:10:08            2024/09/11 01:48:22                 22940                      32%
SQL*Plus                                                          db file sequential read        2024/09/11 11:19:03            2024/09/11 12:49:01                  3690                   28 5%
sh_init_sql                                        843    32054   db file sequential read        2024/09/11 12:16:15            2024/09/11 12:49:01                  1950                    3 3%
  
  
  
FIDUCRE-DEV-imxbatch_Depersonalization-3w09f7zapmb4b-11-09-2024      




MODULE                    SQL_ID         PLAN_HASH SID    SERIAL# EVENT                          FROM                           TO                                 ACTIVE NUMBER_OF_EXECUTIONS PERC
------------------------- ------------- ---------- ------ ------- ------------------------------ ------------------------------ ------------------------------ ---------- -------------------- ------
imxbatch_Depersonalizatio                          59     33915                                  2024/09/10 09:35:05            2024/09/11 10:28:41                 89310              8563291 100%
n


MODULE                    SQL_ID         PLAN_HASH SID    SERIAL# EVENT                          FROM                           TO                                 ACTIVE NUMBER_OF_EXECUTIONS PERC
------------------------- ------------- ---------- ------ ------- ------------------------------ ------------------------------ ------------------------------ ---------- -------------------- ------
imxbatch_Depersonalizatio                          59     33915                                  2024/09/10 09:35:05            2024/09/11 10:28:41                 89310              8563291 100%
n


MODULE                    SQL_ID         PLAN_HASH SID    SERIAL# EVENT                          FROM                           TO                                 ACTIVE NUMBER_OF_EXECUTIONS PERC
------------------------- ------------- ---------- ------ ------- ------------------------------ ------------------------------ ------------------------------ ---------- -------------------- ------
imxbatch_Depersonalizatio 3w09f7zapmb4b 1461601168 59     33915                                  2024/09/10 19:36:18            2024/09/11 10:14:28                 52510                    1 59%
n

imxbatch_Depersonalizatio d5famw5c56166 3630153981 59     33915                                  2024/09/10 11:34:22            2024/09/10 19:34:28                 28720                    1 32%
n

imxbatch_Depersonalizatio fx9t9x612pgwz 3700454064 59     33915                                  2024/09/10 10:13:54            2024/09/10 11:21:49                  4070                    1 5%
n

imxbatch_Depersonalizatio bxw01wahcynqa 2455597310 59     33915                                  2024/09/10 09:35:35            2024/09/10 09:48:58                   570                    1 1%
n

imxbatch_Depersonalizatio fbfhw09snzm7x 1831406875 59     33915                                  2024/09/10 11:21:59            2024/09/10 11:34:12                   510                    1 1%

MODULE                    SQL_ID         PLAN_HASH SID    SERIAL# EVENT                          FROM                           TO                                 ACTIVE NUMBER_OF_EXECUTIONS PERC
------------------------- ------------- ---------- ------ ------- ------------------------------ ------------------------------ ------------------------------ ---------- -------------------- ------
imxbatch_Depersonalizatio ch18w644wz5z9 3185828904 59     33915                                  2024/09/11 10:23:50            2024/09/11 10:28:31                   290                    1 100%


-- 3w09f7zapmb4b

Plan hash value: 1461601168
----------------------------------------------------------------------------------
| Id  | Operation                                 | Name                | E-Rows |
----------------------------------------------------------------------------------
|   0 | UPDATE STATEMENT                          |                     |        |
|   1 |  UPDATE                                   | G_TEXTE             |        |
|   2 |   NESTED LOOPS                            |                     |     94 |
|   3 |    NESTED LOOPS                           |                     |     94 |
|   4 |     VIEW                                  | VW_NSO_1            |     93 |
|   5 |      SORT UNIQUE                          |                     |     93 |
|   6 |       NESTED LOOPS SEMI                   |                     |     93 |
|*  7 |        HASH JOIN                          |                     |     10M|
|   8 |         VIEW                              |                     |    953K|
|   9 |          SORT UNIQUE                      |                     |    953K|
|  10 |           MERGE JOIN SEMI                 |                     |   5109K|
|  11 |            MERGE JOIN                     |                     |   5109K|
|* 12 |             TABLE ACCESS BY INDEX ROWID   | G_INDIVIDU          |   1290K|
|  13 |              INDEX FULL SCAN              | IND_REFINDIV        |   1294K|
|* 14 |             SORT JOIN                     |                     |   5109K|
|  15 |              INDEX FULL SCAN              | INT_DOS_INDIV       |   5109K|
|* 16 |            SORT UNIQUE                    |                     |   1190K|
|  17 |             TABLE ACCESS FULL             | TMP_DEPERSON_CURS   |   1190K|
|  18 |         VIEW                              | index$_join$_003    |     10M|
|* 19 |          HASH JOIN                        |                     |        |
|  20 |           INDEX FAST FULL SCAN            | PK_G_TEXTE_REFTEXTE |     10M|
|  21 |           INDEX FAST FULL SCAN            | TXT_REFDS           |     10M|
|* 22 |        TABLE ACCESS BY INDEX ROWID BATCHED| T_ELEMENTS          |     21M|
|* 23 |         INDEX RANGE SCAN                  | ELE_ELEMTYPE        |      1 |
|* 24 |     INDEX RANGE SCAN                      | PK_G_TEXTE_REFTEXTE |      1 |
|  25 |    TABLE ACCESS BY INDEX ROWID            | G_TEXTE             |      1 |
----------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   7 - access("T"."REFDS"="D"."REFDOSS")
  12 - filter(("C"."MORALPHY"='M' OR "C"."MORALPHY"='P'))
  14 - access("TI"."REFINDIVIDU"="C"."REFINDIVIDU")
       filter("TI"."REFINDIVIDU"="C"."REFINDIVIDU")
  16 - access("TI"."REFINDIVIDU"="REFINDIVIDU")
       filter("TI"."REFINDIVIDU"="REFINDIVIDU")
  19 - access(ROWID=ROWID)
  22 - filter("TE"."REFDOSS"="D"."REFDOSS")
  23 - access("TE"."REFELEM"="T"."REFTEXTE")
       filter(("TE"."TYPEELEM"='at' OR "TE"."TYPEELEM"='di' OR
              "TE"."TYPEELEM"='en' OR "TE"."TYPEELEM"='ep' OR "TE"."TYPEELEM"='et' OR
              "TE"."TYPEELEM"='fa' OR "TE"."TYPEELEM"='fi' OR "TE"."TYPEELEM"='fx' OR
              "TE"."TYPEELEM"='ie' OR "TE"."TYPEELEM"='me' OR "TE"."TYPEELEM"='mr' OR
              "TE"."TYPEELEM"='ng' OR "TE"."TYPEELEM"='pe' OR "TE"."TYPEELEM"='re' OR
              "TE"."TYPEELEM"='sd' OR "TE"."TYPEELEM"='sm' OR "TE"."TYPEELEM"='tp' OR
              "TE"."TYPEELEM"='vd' OR "TE"."TYPEELEM"='ve'))
  24 - access("REFTEXTE"="REFELEM")



-- d5famw5c56166


Plan hash value: 3630153981
---------------------------------------------------------------------------
| Id  | Operation                            | Name              | E-Rows |
---------------------------------------------------------------------------
|   0 | UPDATE STATEMENT                     |                   |        |
|   1 |  UPDATE                              | G_INFORMATION     |        |
|*  2 |   HASH JOIN SEMI                     |                   |     31M|
|   3 |    TABLE ACCESS FULL                 | G_INFORMATION     |     31M|
|   4 |    VIEW                              | VW_NSO_1          |    132M|
|   5 |     NESTED LOOPS                     |                   |    132M|
|   6 |      NESTED LOOPS                    |                   |    134M|
|   7 |       VIEW                           |                   |    953K|
|   8 |        SORT UNIQUE                   |                   |    953K|
|   9 |         MERGE JOIN SEMI              |                   |   5109K|
|  10 |          MERGE JOIN                  |                   |   5109K|
|* 11 |           TABLE ACCESS BY INDEX ROWID| G_INDIVIDU        |   1290K|
|  12 |            INDEX FULL SCAN           | IND_REFINDIV      |   1294K|
|* 13 |           SORT JOIN                  |                   |   5109K|
|  14 |            INDEX FULL SCAN           | INT_DOS_INDIV     |   5109K|
|* 15 |          SORT UNIQUE                 |                   |   1190K|
|  16 |           TABLE ACCESS FULL          | TMP_DEPERSON_CURS |   1190K|
|* 17 |       INDEX RANGE SCAN               | ELE_ELEMDOSS      |    141 |
|  18 |      TABLE ACCESS BY INDEX ROWID     | T_ELEMENTS        |    139 |
---------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   2 - access("REFINFO"="REFELEM")
  11 - filter(("C"."MORALPHY"='M' OR "C"."MORALPHY"='P'))
  13 - access("TI"."REFINDIVIDU"="C"."REFINDIVIDU")
       filter("TI"."REFINDIVIDU"="C"."REFINDIVIDU")
  15 - access("TI"."REFINDIVIDU"="REFINDIVIDU")
       filter("TI"."REFINDIVIDU"="REFINDIVIDU")
  17 - access("TE"."REFDOSS"="D"."REFDOSS")




-- UPDATE statement on table T_ELEMENTS, which was provided in the task.

Plan hash value: 3185828904
----------------------------------------------------------------------------------------------------------------------------
| Id  | Operation              | Name              | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  |
----------------------------------------------------------------------------------------------------------------------------
|   0 | UPDATE STATEMENT       |                   |      1 |        |   924K(100)|      0 |00:00:00.01 |       0 |      0 |
|   1 |  UPDATE                | T_ELEMENTS        |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*  2 |   HASH JOIN SEMI       |                   |      1 |    563K|   924K  (1)|      0 |00:00:00.01 |       0 |      0 |
|*  3 |    HASH JOIN RIGHT SEMI|                   |      1 |    563K|   899K  (1)|     31M|00:07:03.24 |     988K|    988K|
|*  4 |     INDEX RANGE SCAN   | DOM_TYPABREV      |      1 |     44 |     1   (0)|     31 |00:00:00.01 |       3 |      0 |
|   5 |     TABLE ACCESS FULL  | T_ELEMENTS        |      1 |    132M|   899K  (1)|     34M|00:07:00.31 |     988K|    988K|
|   6 |    VIEW                | VW_NSO_1          |      0 |   5109K| 11271   (1)|      0 |00:00:00.01 |       0 |      0 |
|*  7 |     HASH JOIN          |                   |      0 |   5109K| 11271   (1)|      0 |00:00:00.01 |       0 |      0 |
|   8 |      TABLE ACCESS FULL | TMP_DEPERSON_CURS |      0 |   1291K|  1976   (1)|      0 |00:00:00.01 |       0 |      0 |
|   9 |      INDEX FULL SCAN   | INT_DOS_INDIV     |      0 |   5109K|   259   (0)|      0 |00:00:00.01 |       0 |      0 |
----------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   2 - access("REFDOSS"="REFDOSS")
   3 - access("TYPEELEM"="ABREV")
   4 - access("TYPE"='ELEM_CHRONO')
       filter("ABREV" IS NOT NULL)
   7 - access("REFINDIVIDU"="REFINDIVIDU")
*/
/********************************OLD Metrics***************************************/

/********************************New SQL*******************************************/

-- 3w09f7zapmb4b

UPDATE /*+ opt_param('optimizer_index_cost_adj' 10000) full(G_TEXTE) use_hash(G_TEXTE)  */
      G_TEXTE
   SET PARAGRAPHE = NULL
 WHERE reftexte IN ( SELECT te.refelem
                       FROM t_elements te,
                            g_texte t,
                            ( SELECT DISTINCT ti.refdoss
                                FROM g_individu c, 
                                     t_intervenants ti
                               WHERE c.moralphy IN ('M', 'P')
                                 AND ti.refindividu = c.refindividu
                                 AND c.refindividu IN ( SELECT REFINDIVIDU 
                                                           FROM tmp_deperson_curs ) ) d
                      WHERE te.refdoss = d.refdoss
                        AND te.typeelem in ( 'pe',
                                             'fi',
                                             'en',
                                             'vd',
                                             'sm',
                                             'me',
                                             'mr',
                                             'at',
                                             'tp',
                                             'fx',
                                             've',
                                             'tp',
                                             'ep',
                                             'fa',
                                             'di',
                                             'sd',
                                             'ie',
                                             'ng',
                                             'et',
                                             're' )
                        AND te.refelem = t.reftexte
                        AND t.refds = d.refdoss );



-- d5famw5c56166


UPDATE /*+ opt_param('optimizer_index_cost_adj' 10000) full(G_INFORMATION) use_hash(G_INFORMATION)  */
       G_INFORMATION
   SET STR_10_1    = NULL,
       DTSAISIE_DT = NULL,
       REFPRENEUR  = NULL,
       REFEMETTEUR = NULL,
       LIBELINFO   = NULL,
       REFEXT2     = NULL,
       ENCODEUR    = NULL,
       CREATEUR    = NULL,
       NOMEMETTEUR = NULL,
       TYPEDOC     = NULL,
       LIBREINFO   = NULL
 WHERE refinfo IN ( SELECT te.refelem
                      FROM t_elements te,
                           ( SELECT DISTINCT ti.refdoss
                               FROM g_individu c,
                                    t_intervenants ti
                              WHERE c.moralphy IN ('M', 'P')
                                AND ti.refindividu = c.refindividu
                                AND c.refindividu IN ( SELECT REFINDIVIDU 
                                                          FROM tmp_deperson_curs ) ) d
                     WHERE te.refdoss = d.refdoss);



-- UPDATE statement on table T_ELEMENTS, which was provided in the task.


UPDATE /*+ full(T_ELEMENTS) */
       T_ELEMENTS
   SET LIBELLE =  NULL
 WHERE 0 + 0 < ( SELECT count(*)
                   FROM v_domaine vd
                  WHERE vd.type = 'ELEM_CHRONO' 
                    AND T_ELEMENTS.typeelem = vd.abrev )
   and refdoss in ( SELECT refdoss 
                      from t_intervenants 
                     where refindividu IN ( SELECT REFINDIVIDU 
                                              FROM tmp_deperson_curs )
                     group by refdoss );
/********************************New SQL*******************************************/
/********************************New Metrics***************************************/
/*

-- 3w09f7zapmb4b

Plan hash value: 1484167254
--------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                     | Name              | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  | Writes |
--------------------------------------------------------------------------------------------------------------------------------------------
|   0 | UPDATE STATEMENT              |                   |      1 |        |  1392K(100)|      0 |00:00:00.01 |       0 |      0 |      0 |
|   1 |  UPDATE                       | G_TEXTE           |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
|*  2 |   HASH JOIN                   |                   |      1 |      3 |  1392K  (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|   3 |    VIEW                       | VW_NSO_1          |      1 |      3 |  1275K  (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|   4 |     SORT UNIQUE               |                   |      1 |      3 |  1275K  (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*  5 |      HASH JOIN SEMI           |                   |      1 |     93 |  1275K  (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*  6 |       HASH JOIN               |                   |      1 |     10M|   214K  (1)|   7930K|00:00:56.03 |     800K|    568K|   4247 |
|   7 |        VIEW                   |                   |      1 |    953K| 81434   (1)|    959K|00:00:21.67 |     388K|    212K|   4247 |
|   8 |         SORT UNIQUE           |                   |      1 |    953K| 81434   (1)|    959K|00:00:21.67 |     388K|    212K|   4247 |
|*  9 |          HASH JOIN            |                   |      1 |   5109K| 56711   (1)|   4998K|00:00:20.78 |     388K|    212K|   4247 |
|* 10 |           HASH JOIN RIGHT SEMI|                   |      1 |   1290K| 41321   (1)|   1287K|00:00:08.00 |     361K|    185K|   4247 |
|  11 |            TABLE ACCESS FULL  | TMP_DEPERSON_CURS |      1 |   1291K|  1976   (1)|   1291K|00:00:00.21 |    8864 |   8861 |      0 |
|* 12 |            TABLE ACCESS FULL  | G_INDIVIDU        |      1 |   1290K| 36649   (1)|   1290K|00:00:07.10 |     352K|    172K|      0 |
|  13 |           INDEX FAST FULL SCAN| INT_DOS_INDIV     |      1 |   5109K|  5684   (1)|   5109K|00:00:11.02 |   26475 |  26452 |      0 |
|  14 |        TABLE ACCESS FULL      | G_TEXTE           |      1 |     10M|   116K  (1)|   8142K|00:00:33.29 |     412K|    356K|      0 |
|* 15 |       TABLE ACCESS FULL       | T_ELEMENTS        |      0 |     87M|   896K  (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
|  16 |    TABLE ACCESS FULL          | G_TEXTE           |      0 |     10M|   116K  (1)|      0 |00:00:00.01 |       0 |      0 |      0 |
--------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   2 - access("REFTEXTE"="REFELEM")
   5 - access("TE"."REFDOSS"="D"."REFDOSS" AND "TE"."REFELEM"="T"."REFTEXTE")
   6 - access("T"."REFDS"="D"."REFDOSS")
   9 - access("TI"."REFINDIVIDU"="C"."REFINDIVIDU")
  10 - access("C"."REFINDIVIDU"="REFINDIVIDU")
  12 - filter(("C"."MORALPHY"='M' OR "C"."MORALPHY"='P'))
  15 - filter(("TE"."TYPEELEM"='at' OR "TE"."TYPEELEM"='di' OR "TE"."TYPEELEM"='en' OR "TE"."TYPEELEM"='ep' OR "TE"."TYPEELEM"='et'
              OR "TE"."TYPEELEM"='fa' OR "TE"."TYPEELEM"='fi' OR "TE"."TYPEELEM"='fx' OR "TE"."TYPEELEM"='ie' OR "TE"."TYPEELEM"='me' OR
              "TE"."TYPEELEM"='mr' OR "TE"."TYPEELEM"='ng' OR "TE"."TYPEELEM"='pe' OR "TE"."TYPEELEM"='re' OR "TE"."TYPEELEM"='sd' OR
              "TE"."TYPEELEM"='sm' OR "TE"."TYPEELEM"='tp' OR "TE"."TYPEELEM"='vd' OR "TE"."TYPEELEM"='ve'))

-- d5famw5c56166


Plan hash value: 235573024
---------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                   | Name              | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  |
---------------------------------------------------------------------------------------------------------------------------------
|   0 | UPDATE STATEMENT            |                   |      1 |        |  1633K(100)|      0 |00:00:00.01 |       0 |      0 |
|   1 |  UPDATE                     | G_INFORMATION     |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*  2 |   HASH JOIN SEMI            |                   |      1 |     31M|  1633K  (1)|      0 |00:00:00.01 |       0 |      0 |
|   3 |    TABLE ACCESS FULL        | G_INFORMATION     |      1 |     31M|   174K  (1)|   2170K|00:00:06.43 |   58564 |  58565 |
|   4 |    VIEW                     | VW_NSO_1          |      0 |    132M|  1178K  (1)|      0 |00:00:00.01 |       0 |      0 |
|*  5 |     HASH JOIN               |                   |      0 |    132M|  1178K  (1)|      0 |00:00:00.01 |       0 |      0 |
|   6 |      VIEW                   |                   |      0 |    953K| 81434   (1)|      0 |00:00:00.01 |       0 |      0 |
|   7 |       SORT UNIQUE           |                   |      0 |    953K| 81434   (1)|      0 |00:00:00.01 |       0 |      0 |
|*  8 |        HASH JOIN            |                   |      0 |   5109K| 56711   (1)|      0 |00:00:00.01 |       0 |      0 |
|*  9 |         HASH JOIN RIGHT SEMI|                   |      0 |   1290K| 41321   (1)|      0 |00:00:00.01 |       0 |      0 |
|  10 |          TABLE ACCESS FULL  | TMP_DEPERSON_CURS |      0 |   1291K|  1976   (1)|      0 |00:00:00.01 |       0 |      0 |
|* 11 |          TABLE ACCESS FULL  | G_INDIVIDU        |      0 |   1290K| 36649   (1)|      0 |00:00:00.01 |       0 |      0 |
|  12 |         INDEX FAST FULL SCAN| INT_DOS_INDIV     |      0 |   5109K|  5684   (1)|      0 |00:00:00.01 |       0 |      0 |
|  13 |      TABLE ACCESS FULL      | T_ELEMENTS        |      0 |    132M|   894K  (1)|      0 |00:00:00.01 |       0 |      0 |
---------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   2 - access("REFINFO"="REFELEM")
   5 - access("TE"."REFDOSS"="D"."REFDOSS")
   8 - access("TI"."REFINDIVIDU"="C"."REFINDIVIDU")
   9 - access("C"."REFINDIVIDU"="REFINDIVIDU")
  11 - filter(("C"."MORALPHY"='M' OR "C"."MORALPHY"='P'))




-- UPDATE statement on table T_ELEMENTS, which was provided in the task.


Plan hash value: 1088582437
-----------------------------------------------------------------------------------------------------------------------------
| Id  | Operation               | Name              | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  |
-----------------------------------------------------------------------------------------------------------------------------
|   0 | UPDATE STATEMENT        |                   |      1 |        |  2371K(100)|      0 |00:00:00.01 |       0 |      0 |
|   1 |  UPDATE                 | T_ELEMENTS        |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*  2 |   FILTER                |                   |      1 |        |            |   2146K|00:00:31.92 |     101K|  92507 |
|*  3 |    HASH JOIN RIGHT SEMI |                   |      1 |    132M|  2371K  (1)|   2356K|00:00:29.61 |     101K|  92504 |
|   4 |     VIEW                | VW_NSO_1          |      1 |    953K| 30527   (1)|    959K|00:00:19.68 |   34450 |  34448 |
|   5 |      SORT GROUP BY      |                   |      1 |    953K| 30527   (1)|    959K|00:00:19.68 |   34450 |  34448 |
|*  6 |       HASH JOIN         |                   |      1 |   5109K| 11271   (1)|   5000K|00:00:19.11 |   34450 |  34448 |
|   7 |        TABLE ACCESS FULL| TMP_DEPERSON_CURS |      1 |   1291K|  1976   (1)|   1291K|00:00:00.20 |    8864 |   8862 |
|   8 |        INDEX FULL SCAN  | INT_DOS_INDIV     |      1 |   5109K|   259   (0)|   5109K|00:00:17.41 |   25586 |  25586 |
|   9 |     TABLE ACCESS FULL   | T_ELEMENTS        |      1 |    132M|   899K  (1)|   2388K|00:00:06.60 |   67474 |  58056 |
|  10 |    SORT AGGREGATE       |                   |     27 |      1 |            |     27 |00:00:00.01 |      21 |      3 |
|* 11 |     INDEX RANGE SCAN    | DOM_TYPABREV      |     27 |      1 |     1   (0)|     22 |00:00:00.01 |      21 |      3 |
-----------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   2 - filter(>0)
   3 - access("REFDOSS"="REFDOSS")
   6 - access("REFINDIVIDU"="REFINDIVIDU")
  11 - access("VD"."TYPE"='ELEM_CHRONO' AND "VD"."ABREV"=:B1)
*/
/********************************New Metrics***************************************/

/********************************Index statistics**********************************/

/********************************Other SQLs****************************************/          
/*

*/ 
/********************************Other SQLs****************************************/              
