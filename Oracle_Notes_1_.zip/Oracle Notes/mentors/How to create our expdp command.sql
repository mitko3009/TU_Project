First you should know that for the sake of this guide we will look over only two of the most used types of expdp command line:
I)creating the expdp command without parallelism (in situations where the target schema is small in size).
II)creating the expdp command with parallelism function (in most scenarious is used to speed up the process of exporting the 	data and mostly when the schema size is huge).


I)
How it is look like the expdp command line:

expdp DIRECTORY=DATA_PUMP_DIR SCHEMAS=A4CDB,U4CDB4MEDIT DUMPFILE=EXPDPD_A4CDB_U4CDB4MEDIT_20190917.dmp LOGFILE=EXPDPD_A4CDB_U4CDB4MEDIT_20190917.log FLASHBACK_SCN=10428519721410

What is the meaning of each part of the command:

1) DIRECTORY=DATA_PUMP_DIR -> it is pointing to where the exported dump file/s will be stored. It is variable in the database that is set once it is created /could be changed on demand if needed/.
2) SCHEMAS=A4MSQP -> the schema we want to export 
3) DUMPFILE=EXPDPD_A4MSQP_20190731.dmp -> the name of the dump file /dump file - the file that contains all of the schema objects, grants, ddl and dml at the time the export was taken just like snapshot/
4) LOGFILE=EXPDPD_A4MSQP_20190731.log -> how our log file will be named and where we can check whether the export process is successfull and to track it using tail command
5) FLASHBACK_SCN=2045451817 -> SCN stands for System Change Number /it changes at every checkpoint, commint, rollback and it is unique also it stands for exact point in time when take the export/


How to check each of the above parameters:

1) 
as root > su - oracle > setting up the environment of the database > dbset <DB_NAME>
sqlplus / as sysdba
SQL> set lines 300
SQL> set pages 400
SQL> select * from dba_directories;

This will provide us with full list of all of the db directories set in the oracle as variables. In audi environment this looks like this -> DATA_PUMP_DIR /u01/dbteam/dump/<DB_NAME>
For example database T800 it should be DATA_PUMP_DIR /u01/dbteam/dump/T800

2)
Once we are logged into the database as sysdba:
set lines 512
set pages 1000
col USERNAME format A25
col ACCOUNT_STATUS format A17
col PASSWORD format A30
col PROFILE for a30
select USERNAME,ACCOUNT_STATUS,LOCK_DATE,CREATED, expiry_date, PROFILE,DEFAULT_TABLESPACE,TEMPORARY_TABLESPACE from dba_users 
where username like '%MSQP%' <- - -> this is where we might replace MSQP with other schema name!
--where account_status='OPEN'
--and USERNAME not like 'HP%'
order by USERNAME,ACCOUNT_STATUS; 

3)
We are just naming it as correct as possible in order to make sure that anyone including ourselves will know what is this dump about and from where /as stage/ it has been extracted:

DUMPFILE=EXPDPD_A4MSQP_20190731.dmp -> it just says that the schema A4MSQP were exported at 31.07.2019
DUMPFILE=EXPDPD_A4MSQP_Live_20190731.dmp -> same as above but specifying from which stage the export were taken. In our case the Live /production/ database

4)

All said about the dump naming is applicable for the logfile naming.

5)

How to get that SCN:

Once the environment is set and we are logged as sysdba:
select to_char(current_scn) from v$database;

TO_CHAR(CURRENT_SCN)
----------------------------------------
10409426602832

This number is at which point of the database we are taking the export and in case of restore using the exported dump file we will restore the schema at this exact time.

####################################################################

In order to create our export we need to match some prerequisites as:

1) How large the schema is?
set numformat 9999999999999999999.9999999999
SELECT SUM(BYTES)/1024/1024 "MB" FROM DBA_SEGMENTS WHERE OWNER like '&SCHEMA';

2) Do we have sufficient storage in the fswhere we plan to place the dump file?
df -h /u01/dbteam/dump/<DB_NAME>


###################################################################
- Check users details

set lines 512
set pages 1000
col USERNAME format A25
col ACCOUNT_STATUS format A17
col PASSWORD format A30
col PROFILE for a30
select USERNAME,ACCOUNT_STATUS,LOCK_DATE,CREATED, expiry_date, PROFILE,DEFAULT_TABLESPACE,TEMPORARY_TABLESPACE from dba_users 
where username like '%MEDIT%'
--where account_status='OPEN'
--and USERNAME not like 'HP%'
order by USERNAME,ACCOUNT_STATUS;

================================================================================================================================

II)
This type of export command differs from the above one by having the parallelism function in it, looks like:
expdp directory=DATA_PUMP_DIR SCHEMAS=A4SPRO2 dumpfile=EXPDPD_A4SPRO2_LIVE_20200121_%U.dmp logfile=EXPDPD_A4SPRO2_20200121_LIVE.log FLASHBACK_SCN=13754575652899 parallel=8

The parallelism itself depends highly on the CPU cores in each individual server from where you are going to perform the command.
For safety reasons the most used parallelism values are in between of 4-10.
You should understand the parallelism function as to have 4 to 10 mini workers that are helping you to finish the export faster than if you are using the normal export command (1 worker).

All of the above described essential parameters are valid here as well. Plus a mandatory one described below:
You should always use the following ending of your dump file -> <dump_name>_%U.dmp because the use of parallelism will also split the dump file into smaller pieces!

===============================================================================================================================