/********************************************************************************
*********       E-mail subject: EFEURWEB-4119
*********             Instance: PROD
*********          Description: 
Problem:
SQL 8xk1ng1602j79 ( from ftr_fiu.pck ) is the TOP SQL from the trace of the factor_invfunc.calcDecompteInvoices() on PROD.

Analysis:
As it can be seen in the execution plan below, the current execution plan of the query starts from table F_PARFAC with INDEX FAST FULL SCAN of index PARFAC_CL1, where it finds ~3k rows.
For each of these rows, it access table T_ECRDOS through the TECR$REFDOSS_CODECR_DTINTER index, where finds 370k rows and makes filter for each of them for the DTJOUR.
This can be solved by replacing the OR operator with UNION. By this way, we can separate the cases when we have PF_REFFACTOR and when it IS NULL and can instruct Oracle with hints how to execute the query.

Suggestion:
Please change SQL 8xk1ng1602j79 ( from ftr_fiu.pck ) as it is shown in the New SQL section below.

*********               SQL_ID: 8xk1ng1602j79
*********      Program/Package: ftr_fiu.pck
*********              Request: Dimitare Ivanov
*********               Author: Dimitar Dimitrov
********* Received e-mail date: 17/02/2025
*********      Resolution date: 04/03/2025
*********  Trace old file here: \\epox\specifs\performance\tmp\
*********  Trace new file here:
***********************************************************************************/

/********************************OLD SQL*******************************************/

VAR B6 VARCHAR2(32);
EXEC :B6 := '2206150050';
VAR B5 NUMBER;
EXEC :B5 := 2459762;
VAR B4 NUMBER;
EXEC :B4 := 2460735;
VAR B3 NUMBER;
EXEC :B3 := NULL;
VAR B2 NUMBER;
EXEC :B2 := NULL;
VAR B1 VARCHAR2(32);
EXEC :B1 := 'INT00000';

SELECT /*+ no_expand leading(PF) use_nl(T) index (T TECR$REFDOSS_CODECR_DTINTER) */
       T.ROWID
  FROM T_ECRDOS T, 
       F_PARFAC PF
 WHERE T.REFDOSS = :B6
   AND T.CODECR = PF.PF_NOM
   AND T.DTINTER BETWEEN NVL( :B5, 0 ) AND NVL( :B4, 9999999 )
   AND T.DTJOUR BETWEEN NVL( :B3, 0 ) AND NVL( :B2, 9999999 )
   AND (   PF.PF_REFFACTOR = :B1 
        OR     PF.PF_REFFACTOR IS NULL 
        	 AND NOT EXISTS ( SELECT 1
                              FROM F_PARFAC
                             WHERE PF_NOM = PF.PF_NOM
                               AND PF_REFFACTOR = :B1 ) );
/********************************OLD SQL*******************************************/
/********************************OLD Metrics***************************************/
/*
Plan hash value: 1752726066
-------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                      | Name                        | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers |
-------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT               |                             |      1 |        | 10240 (100)|  30988 |00:00:02.52 |     338K|
|*  1 |  FILTER                        |                             |      1 |        |            |  30988 |00:00:02.52 |     338K|
|*  2 |   FILTER                       |                             |      1 |        |            |    370K|00:00:02.38 |     338K|
|   3 |    NESTED LOOPS                |                             |      1 |      1 | 10240   (1)|    370K|00:00:02.25 |     338K|
|   4 |     NESTED LOOPS               |                             |      1 |   3021 | 10240   (1)|    370K|00:00:00.36 |   11100 |
|   5 |      INDEX FAST FULL SCAN      | PARFAC_CL1                  |      1 |   3021 |     6   (0)|   3021 |00:00:00.01 |      39 |
|*  6 |      INDEX RANGE SCAN          | TECR$REFDOSS_CODECR_DTINTER |   3021 |      1 |     3   (0)|    370K|00:00:00.26 |   11061 |
|*  7 |     TABLE ACCESS BY INDEX ROWID| T_ECRDOS                    |    370K|      1 |     4   (0)|    370K|00:00:01.58 |     327K|
|*  8 |   INDEX UNIQUE SCAN            | PARFAC_CL1                  |     10 |      1 |     1   (0)|     10 |00:00:00.01 |      20 |
-------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   1 - filter(("PF"."PF_REFFACTOR"=:B1 OR ("PF"."PF_REFFACTOR" IS NULL AND  IS NULL)))
   2 - filter((NVL(:B2,9999999)>=NVL(:B3,0) AND NVL(:B4,9999999)>=NVL(:B5,0)))
   6 - access("T"."REFDOSS"=:B6 AND "T"."CODECR"="PF"."PF_NOM" AND "T"."DTINTER">=NVL(:B5,0) AND
              "T"."DTINTER"<=NVL(:B4,9999999))
   7 - filter(("T"."DTJOUR">=NVL(:B3,0) AND "T"."DTJOUR"<=NVL(:B2,9999999)))
   8 - access("PF_NOM"=:B1 AND "PF_REFFACTOR"=:B1)
*/
/********************************OLD Metrics***************************************/

/********************************New SQL*******************************************/
VAR B6 VARCHAR2(32);
EXEC :B6 := '2206150050';
VAR B5 NUMBER;
EXEC :B5 := 2459762;
VAR B4 NUMBER;
EXEC :B4 := 2460735;
VAR B3 NUMBER;
EXEC :B3 := NULL;
VAR B2 NUMBER;
EXEC :B2 := NULL;
VAR B1 VARCHAR2(32);
EXEC :B1 := 'INT00000';

SELECT /*+ no_merge(PF) no_push_pred(PF) leading(PF) use_nl(T) index(T TECR$REFDOSS_CODECR_DTINTER) */
         T.ROWID
  FROM T_ECRDOS T, 
       ( SELECT DISTINCT pf_nom 
           FROM F_PARFAC 
          WHERE PF_REFFACTOR = :B1
             OR PF_REFFACTOR IS NULL ) PF
 WHERE T.REFDOSS = :B6
   AND T.CODECR = PF.PF_NOM
   AND T.DTINTER BETWEEN NVL( :B5, 0 ) AND NVL( :B4, 9999999 )
   AND T.DTJOUR BETWEEN NVL( :B3, 0 ) AND NVL( :B2, 9999999 );
/********************************New SQL*******************************************/
/********************************New Metrics***************************************/
/*
Plan hash value: 3696629843
--------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                    | Name                        | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  |
--------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT             |                             |      1 |        |  1075 (100)|  30989 |00:00:02.86 |   30937 |   2987 |
|   1 |  NESTED LOOPS                |                             |      1 |      1 |  1075   (1)|  30989 |00:00:02.86 |   30937 |   2987 |
|   2 |   NESTED LOOPS               |                             |      1 |    315 |  1075   (1)|  30989 |00:00:00.39 |    3329 |    252 |
|   3 |    VIEW                      |                             |      1 |    315 |     7  (15)|    286 |00:00:00.01 |      33 |      0 |
|   4 |     HASH UNIQUE              |                             |      1 |    315 |     7  (15)|    286 |00:00:00.01 |      33 |      0 |
|*  5 |      FILTER                  |                             |      1 |        |            |    557 |00:00:00.01 |      33 |      0 |
|*  6 |       INDEX FAST FULL SCAN   | PARFAC_CL1                  |      1 |    510 |     6   (0)|    557 |00:00:00.01 |      33 |      0 |
|*  7 |    INDEX RANGE SCAN          | TECR$REFDOSS_CODECR_DTINTER |    286 |      1 |     3   (0)|  30989 |00:00:00.38 |    3296 |    252 |
|*  8 |   TABLE ACCESS BY INDEX ROWID| T_ECRDOS                    |  30989 |      1 |     4   (0)|  30989 |00:00:02.44 |   27608 |   2735 |
--------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   5 - filter((NVL(:B2,9999999)>=NVL(:B3,0) AND NVL(:B4,9999999)>=NVL(:B5,0)))
   6 - filter(("PF_REFFACTOR" IS NULL OR "PF_REFFACTOR"=:B1))
   7 - access("T"."REFDOSS"=:B6 AND "T"."CODECR"="PF"."PF_NOM" AND "T"."DTINTER">=NVL(:B5,0) AND "T"."DTINTER"<=NVL(:B4,9999999))
   8 - filter(("T"."DTJOUR">=NVL(:B3,0) AND "T"."DTJOUR"<=NVL(:B2,9999999)))
*/
/********************************New Metrics***************************************/

/********************************Index statistics**********************************/

/********************************Other SQLs****************************************/          
/*

*/ 
/********************************Other SQLs****************************************/              
