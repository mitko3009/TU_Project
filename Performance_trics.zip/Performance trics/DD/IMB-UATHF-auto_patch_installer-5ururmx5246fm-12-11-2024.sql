/********************************************************************************
*********       E-mail subject: IMBWEB-8116
*********             Instance: UATHF/DVLHF
*********          Description: 
Problem:
The installation of patch DdPatch20241105_1 took ~19h on UATHF and DVLHF and didn't finish.

Analysis:
We checked on UATHF for the session that was provided in the task and found that this is the auto_patch_installer. The TOP SQL in it, which was responsible for 100% of the time is 5ururmx5246fm.
This is UPDATE statement on table NAM_ECR_COMPTA_BAK, which was executed only once but with bad execution plan, starting from the exists with FULL SCAN on table PARAM_CODALINE and than 
join table NAM_ECR_COMPTA_BAK. The better variant here is to start from table NAM_ECR_COMPTA_BAK with FULL SCAN, which we found that in parallel tooks less than 20 seconds and than access table PARAM_CODALINE.

Suggestion:
Please add hint as it is shown in the New SQL section below.

*********               SQL_ID: 5ururmx5246fm
*********      Program/Package: 
*********              Request: Deyan Dobromirov 
*********               Author: Dimitar Dimitrov
********* Received e-mail date: 12/11/2024
*********      Resolution date: 12/11/2024
*********  Trace old file here: \\epox\specifs\performance\tmp\
*********  Trace new file here:
***********************************************************************************/

/********************************OLD SQL*******************************************/

UPDATE NAM_ECR_COMPTA_BAK N 
   SET REF_OPCODE_IND_BATCH = '00000000' 
 WHERE REF_OPCODE_IND_BATCH IS NULL 
   AND FG_GL_ACC_RECLASSIFIC = 'O' 
   AND CODEOPER IN ('COM_CL_CR', 'COM_CL_DT')
   AND EXISTS ( SELECT 1 
                  FROM PARAM_CODALINE 
                 WHERE NUMPARAM = N.NUMPARAM 
                   AND LINENUM = N.LINENUM 
                   AND FG_GL_ACC_RECLASSIFIC = N.FG_GL_ACC_RECLASSIFIC 
                   AND IND_BATCH_DEF_VAL = '00000000' );
/********************************OLD SQL*******************************************/
/********************************OLD Metrics***************************************/
/*
INST_ID     SID SERIAL# PID         SPID       MODULE               EVENT                                    STATUS            SQL_ID        PLAN_HASH_VALUE CLIENT_ID    CLIENT_INFO      LOGON_TIME MACHINE    ACTION
------- ------- ------- ----------- ---------- -------------------- ---------------------------------------- ----------------- ------------- --------------- ------------ ---------------- ---------- ---------- -------------------------
2          1764   59571 567836      175022     auto_patch_installer cell single block read request           ACTIVE-58960 sec. 5ururmx5246fm      4192289417 installer    installer        11/11/24   imxappfat. DmPatch20241025_2.tar.Z
1           638   65179 1234        186572     emagent              idle-PL/SQL lock timer                   ACTIVE-7 sec.     g0bggfqrddc4w               0                      27/10/24   exa1nvm41.
1          1733   28695 1234        261781     emagent              idle-PL/SQL lock timer                   ACTIVE-48 sec.    g0bggfqrddc4w               0                      11/11/24   exa1nvm41.
1            50   41581 382793      382793                          idle-jobq slave wait                     ACTIVE-33 sec.                                                       10:21:25   exa1nvm41.
1          1202   36074 3286        3286                            idle-jobq slave wait                     ACTIVE-0 sec.                                                        10:21:58   exa1nvm41.
2          1178   43209 1234        8765       emagent              idle-PL/SQL lock timer                   ACTIVE-16 sec.    g0bggfqrddc4w               0                      11/11/24   exa1nvm42.
1            33   65091 294371      346658     oraagent.bin         idle-SQL*Net message from client         INACTIVE-72 sec.                                                   



MODULE                           PROGRAM                                            CLIENT_ID       SQL_ID         PLAN_HASH     SID SERIAL# EVENT                FROM                TO                        ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- -------------------------------------------------- --------------- ------------- ---------- ------- ------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
auto_patch_installer             sqlplus                                            installer                                   1764                              2024/11/11 09:39:57  2024/11/12 10:24:46        5910                36443 +000000001 00:44:49.068 100%


MODULE                           PROGRAM                                            CLIENT_ID       SQL_ID         PLAN_HASH     SID SERIAL# EVENT                FROM                TO                        ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- -------------------------------------------------- --------------- ------------- ---------- ------- ------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
auto_patch_installer             sqlplus                                            installer       5ururmx5246fm 4192289417    1764   59571 cell single block ph 2024/11/11 17:59:29  2024/11/12 10:24:36        5196                    1 +000000000 16:25:06.431 88%
auto_patch_installer             sqlplus                                            installer                                   1764         ON CPU               2024/11/11 09:39:57  2024/11/12 10:24:46         650                36443 +000000001 00:44:49.068 11%
auto_patch_installer             sqlplus                                            installer       5ururmx5246fm 4192289417    1764   59571 gc cr grant 2-way    2024/11/11 18:01:59  2024/11/12 09:37:00          29                    1 +000000000 15:35:00.078 0%
auto_patch_installer             sqlplus                                            installer       5ururmx5246fm 4192289417    1764   59571 cell single block re 2024/11/11 18:52:06  2024/11/12 10:14:44          27                    1 +000000000 15:22:38.373 0%
auto_patch_installer             sqlplus                                            installer       5ururmx5246fm 4192289417    1764   59571 gc current block 2-w 2024/11/11 18:32:03  2024/11/11 21:14:04           5                    1 +000000000 02:42:00.804 0%
auto_patch_installer             sqlplus                                            installer       acn7p8k0tmhfq 3808420194    1764   59571 cell disk open       2024/11/11 17:59:19  2024/11/11 17:59:19           1                      +000000000 00:00:00.000 0%
auto_patch_installer             sqlplus                                            installer       5ururmx5246fm 4192289417    1764   59571 gc cr request        2024/11/11 17:59:59  2024/11/11 17:59:59           1                    1 +000000000 00:00:00.000 0%
auto_patch_installer             sqlplus                                            installer       5ururmx5246fm 4192289417    1764   59571 gc cr grant busy     2024/11/11 22:17:02  2024/11/11 22:17:02           1                    1 +000000000 00:00:00.000 0%


MODULE                           PROGRAM                                            CLIENT_ID       SQL_ID         PLAN_HASH     SID SERIAL# EVENT                FROM                TO                        ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- -------------------------------------------------- --------------- ------------- ---------- ------- ------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
auto_patch_installer             sqlplus                                            installer       5ururmx5246fm 4192289417    1764   59571                      2024/11/11 17:59:29  2024/11/12 10:24:46        5900                    1 +000000000 16:25:16.442 100%
auto_patch_installer             sqlplus                                            installer       6axgjd16r9cj6          0    1764    3999 ON CPU               2024/11/11 09:43:47  2024/11/11 09:43:47           1                    1 +000000000 00:00:00.000 0%


INSTANCE_NUMBER SQL_ID            ELAPSED MAX_WAIT_ON     PC_OF  WAIT_TIME            GETS      READS       ROWS  ELAP/EXEC       GETS/EXEC READS/EXEC  ROWS/EXEC       EXEC PLAN_HASH_VALUE
--------------- ------------- ----------- --------------- ----- ---------- --------------- ---------- ---------- ---------- --------------- ---------- ---------- ---------- ---------------
              2 5ururmx5246fm       57646 IO              81%   63990.3233       165318933  164826796          0   57646.04       165318933  164826796          0          0     4192289417


SQL_ID        SQL_PLAN_HASH_VALUE SQL_PLAN_LINE_ID SQL_PLAN_OPERATION             SQL_PLAN_OPTIONS                   ACTIVE
------------- ------------------- ---------------- ------------------------------ ------------------------------ ----------
5ururmx5246fm          4192289417                8 TABLE ACCESS                   BY INDEX ROWID                       5734
5ururmx5246fm          4192289417                7 INDEX                          RANGE SCAN                            187
5ururmx5246fm          4192289417                6 INLIST ITERATOR                                                        6
5ururmx5246fm          4192289417                2 NESTED LOOPS                                                           2
5ururmx5246fm          4192289417                3 NESTED LOOPS                                                           1



Plan hash value: 4192289417
--------------------------------------------------------------------------
| Id  | Operation                     | Name                    | E-Rows |
--------------------------------------------------------------------------
|   0 | UPDATE STATEMENT              |                         |        |
|   1 |  UPDATE                       | NAM_ECR_COMPTA_BAK      |        |
|   2 |   NESTED LOOPS                |                         |      1 |
|   3 |    NESTED LOOPS               |                         |   5677K|
|   4 |     SORT UNIQUE               |                         |      1 |
|*  5 |      TABLE ACCESS STORAGE FULL| PARAM_CODALINE          |      1 |
|   6 |     INLIST ITERATOR           |                         |        |
|*  7 |      INDEX RANGE SCAN         | IDX7_NAM_ECR_COMPTA_BAK |   5677K|
|*  8 |    TABLE ACCESS BY INDEX ROWID| NAM_ECR_COMPTA_BAK      |    132 |
--------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   5 - storage(("IND_BATCH_DEF_VAL"='00000000' AND
              "FG_GL_ACC_RECLASSIFIC"='O'))
       filter(("IND_BATCH_DEF_VAL"='00000000' AND
              "FG_GL_ACC_RECLASSIFIC"='O'))
   7 - access(("CODEOPER"='COM_CL_CR' OR "CODEOPER"='COM_CL_DT'))
   8 - filter(("NUMPARAM"="N"."NUMPARAM" AND
              "FG_GL_ACC_RECLASSIFIC"="FG_GL_ACC_RECLASSIFIC" AND
              "LINENUM"="N"."LINENUM" AND "FG_GL_ACC_RECLASSIFIC"='O' AND
              "REF_OPCODE_IND_BATCH" IS NULL))





Global Information
------------------------------
Status              :  EXECUTING
Instance ID         :  2
Session             :  IMXDB (1764:59571)
SQL ID              :  5ururmx5246fm
SQL Execution ID    :  33554432
Execution Started   :  11/11/2024 17:59:19
First Refresh Time  :  11/11/2024 17:59:22
Last Refresh Time   :  11/12/2024 10:40:51
Duration            :  60093s
Module/Action       :  auto_patch_installer/DmPatch20241025_2.tar.Z
Service             :  imxuhf.imxDR
Program             :  sqlplus@imxappfat.eb.lan.at (TNS V1-V3)

Global Stats
===============================================================================================
| Elapsed |   Cpu   |    IO    | Application | Concurrency | Cluster  | Buffer | Read | Read  |
| Time(s) | Time(s) | Waits(s) |  Waits(s)   |  Waits(s)   | Waits(s) |  Gets  | Reqs | Bytes |
===============================================================================================
|   66704 |   12339 |    53863 |        0.00 |        3.10 |      499 |   172M | 172M |   1TB |
===============================================================================================

SQL Plan Monitoring Details (Plan Hash Value=4192289417)
===============================================================================================================================================================================================================
| Id   |            Operation            |          Name           |  Rows   | Cost  |   Time    | Start  | Execs |   Rows   | Read | Read  | Activity |                   Activity Detail                    |
|      |                                 |                         | (Estim) |       | Active(s) | Active |       | (Actual) | Reqs | Bytes |   (%)    |                     (# samples)                      |
===============================================================================================================================================================================================================
|    0 | UPDATE STATEMENT                |                         |         |       |           |        |     1 |          |      |       |          |                             |
|    1 |   UPDATE                        | NAM_ECR_COMPTA_BAK      |         |       |           |        |     1 |          |      |       |          |                             |
| -> 2 |    NESTED LOOPS                 |                         |       1 | 10567 |     60092 |     +3 |     1 |        0 |      |       |     0.03 | Cpu (5)                     |
| -> 3 |     NESTED LOOPS                |                         |      6M | 10567 |     60092 |     +3 |     1 |       1G |      |       |     0.05 | Cpu (8)                     |
|    4 |      SORT UNIQUE                |                         |       1 |    23 |     59828 |     +3 |     1 |       60 |      |       |          |                             |
|    5 |       TABLE ACCESS STORAGE FULL | PARAM_CODALINE          |       1 |    23 |         1 |     +3 |     1 |       88 |   19 |   4MB |          |                             |
| -> 6 |      INLIST ITERATOR            |                         |         |       |     60092 |     +3 |    60 |       1G |      |       |     0.06 | Cpu (11)                    |
| -> 7 |       INDEX RANGE SCAN          | IDX7_NAM_ECR_COMPTA_BAK |      6M |   192 |     60092 |     +3 |   120 |       1G |   3M |  25GB |     3.61 | gc cr grant 2-way (105)      |
|      |                                 |                         |         |       |           |        |       |          |      |       |          | gc cr request (1)           |
|      |                                 |                         |         |       |           |        |       |          |      |       |          | Cpu (147)                   |
|      |                                 |                         |         |       |           |        |       |          |      |       |          | cell single block physical read: flash cache (376)   |
| -> 8 |     TABLE ACCESS BY INDEX ROWID | NAM_ECR_COMPTA_BAK      |     132 | 10543 |     60092 |     +3 |    1G |        0 | 168M |   1TB |    96.26 | resmgr:internal state change (1)                     |
|      |                                 |                         |         |       |           |        |       |          |      |       |          | Cpu (1804)                  |
|      |                                 |                         |         |       |           |        |       |          |      |       |          | cell single block physical read: flash cache (14905) |
|      |                                 |                         |         |       |           |        |       |          |      |       |          | cell single block read request (82)                  |
===============================================================================================================================================================================================================

*/
/********************************OLD Metrics***************************************/

/********************************New SQL*******************************************/

UPDATE /*+ leading (N) full(N) parallel(4) */
       NAM_ECR_COMPTA_BAK N 
   SET REF_OPCODE_IND_BATCH = '00000000' 
 WHERE REF_OPCODE_IND_BATCH IS NULL 
   AND FG_GL_ACC_RECLASSIFIC = 'O' 
   AND CODEOPER IN ('COM_CL_CR', 'COM_CL_DT')
   AND EXISTS ( SELECT 1 
                  FROM PARAM_CODALINE 
                 WHERE NUMPARAM = N.NUMPARAM 
                   AND LINENUM = N.LINENUM 
                   AND FG_GL_ACC_RECLASSIFIC = N.FG_GL_ACC_RECLASSIFIC 
                   AND IND_BATCH_DEF_VAL = '00000000' );
/********************************New SQL*******************************************/
/********************************New Metrics***************************************/
/*
Plan hash value: 3068549879
----------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                      | Name               | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers |
----------------------------------------------------------------------------------------------------------------------------
|   0 | UPDATE STATEMENT               |                    |      1 |        |   179K(100)|      0 |00:00:03.41 |      39 |
|   1 |  UPDATE                        | NAM_ECR_COMPTA_BAK |      1 |        |            |      0 |00:00:03.41 |      39 |
|   2 |   PX COORDINATOR               |                    |      1 |        |            |      0 |00:00:03.41 |      39 |
|   3 |    PX SEND QC (RANDOM)         | :TQ10000           |      0 |   2351 |   179K (20)|      0 |00:00:00.01 |       0 |
|*  4 |     HASH JOIN SEMI             |                    |      0 |   2351 |   179K (20)|      0 |00:00:00.01 |       0 |
|   5 |      PX BLOCK ITERATOR         |                    |      0 |  47244 |   179K (20)|      0 |00:00:00.01 |       0 |
|*  6 |       TABLE ACCESS STORAGE FULL| NAM_ECR_COMPTA_BAK |      0 |  47244 |   179K (20)|      0 |00:00:00.01 |       0 |
|*  7 |      TABLE ACCESS STORAGE FULL | PARAM_CODALINE     |      0 |    100 |     6  (17)|      0 |00:00:00.01 |       0 |
----------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   4 - access("NUMPARAM"="N"."NUMPARAM" AND "LINENUM"="N"."LINENUM" AND
              "FG_GL_ACC_RECLASSIFIC"="N"."FG_GL_ACC_RECLASSIFIC")
   6 - storage(:Z>=:Z AND :Z<=:Z AND ("N"."FG_GL_ACC_RECLASSIFIC"='O' AND INTERNAL_FUNCTION("CODEOPER") AND
              "REF_OPCODE_IND_BATCH" IS NULL))
       filter(("N"."FG_GL_ACC_RECLASSIFIC"='O' AND INTERNAL_FUNCTION("CODEOPER") AND "REF_OPCODE_IND_BATCH" IS
              NULL))
   7 - storage(("IND_BATCH_DEF_VAL"='00000000' AND "FG_GL_ACC_RECLASSIFIC"='O'))
       filter(("IND_BATCH_DEF_VAL"='00000000' AND "FG_GL_ACC_RECLASSIFIC"='O'))
*/
/********************************New Metrics***************************************/

/********************************Index statistics**********************************/

/********************************Other SQLs****************************************/          
/*

*/ 
/********************************Other SQLs****************************************/              
