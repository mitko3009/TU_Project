######  If you hit the following error during relink /u01/app/oracle/oraInventory/locks


=============================\
IF you hit the following error:

Unable to lock Central Inventory.  OPatch will attempt to re-lock.
Do you want to proceed? [y|n]
y
User Responded with: Y
OPatch will sleep for few seconds, before re-trying to get the lock...


You should set the permissions to 775 /u01/app/oracle/oraInventory/locks






[root@iudb939(Staging) grid]# su - grid
Last login: Mon Jun 22 15:10:48 CEST 2020 on pts/0

-------------------------------------------------------------------------------
iudb939.sec-mgm.web.audi.vwg, Staging
-------------------------------------------------------------------------------

dirname: missing operand
Try 'dirname --help' for more information.
dirname: missing operand
Try 'dirname --help' for more information
[grid@iudb939(Staging) ~]$ $GRID_HOME/bin/relink
writing relink log to: /u01/app/12.2.0.1/grid/install/relink.log
[grid@iudb939(Staging) ~]$ cat /u01/app/12.2.0.1/grid/install/relink.log
You do not have sufficient permissions to access the inventory '/u01/app/oracle/oraInventory/locks'. Installation cannot continue. It is required that the primary group of the install user is same as the inventory owner group. Make sure that the install user is part of the inventory owner group and restart the installer.
[grid@iudb939(Staging) ~]$
[grid@iudb939(Staging) ~]$
[grid@iudb939(Staging) ~]$
[grid@iudb939(Staging) ~]$
[grid@iudb939(Staging) ~]$
[grid@iudb939(Staging) ~]$ ls -lart /u01/app/oracle/oraInventory/locks
ls: cannot access /u01/app/oracle/oraInventory/locks/.: Permission denied
ls: cannot access /u01/app/oracle/oraInventory/locks/..: Permission denied
ls: cannot access /u01/app/oracle/oraInventory/locks/inventory.lock: Permission denied
total 0
-????????? ? ? ? ?            ? inventory.lock
d????????? ? ? ? ?            ? ..
d????????? ? ? ? ?            ? .


[grid@iudb939(Staging) u01]$ cd /u01/app/oracle/oraInventory/locks
-bash: cd: /u01/app/oracle/oraInventory/locks: Permission denied

[grid@iudb939(Staging) u01]$ cd app
[grid@iudb939(Staging) app]$ ls -la
total 16
drwxr-xr-x.  8 root   oinstall 4096 Nov  5  2019 .
drwxr-xr-x.  8 root   oinstall 4096 Jun 15 10:32 ..
drwxr-xr-x.  4 root   oinstall   32 Apr 25  2018 12.2.0.1
drwxr-xr-x   3 oracle dba        17 Apr 15  2019 jenkins
drwxrwxr-x. 15 oracle oinstall 4096 Apr 20 15:46 oracle
drwxr-xr-x  12 root   root     4096 Apr 14 10:51 oracle.ahf
drwxrwxr-x.  4 grid   oinstall   31 Apr 20  2018 oraInventory
drwxr-xr-x   4 oracle oinstall   64 Sep 27  2018 software
[grid@iudb939(Staging) app]$
[grid@iudb939(Staging) app]$
[grid@iudb939(Staging) app]$
[grid@iudb939(Staging) app]$ cd oracle
[grid@iudb939(Staging) oracle]$ ls -la
total 44
drwxrwxr-x.  15 oracle oinstall  4096 Apr 20 15:46 .
drwxr-xr-x.   8 root   oinstall  4096 Nov  5  2019 ..
drwxr-xr-x.  57 oracle oinstall  4096 Apr 24 11:17 admin
drwxrwxr-x.  60 oracle oinstall  4096 Apr  9 08:59 audit
drwxrwxr-x.   8 grid   oinstall    88 Aug 22  2018 cfgtoollogs
drwxrwxr-x.   3 oracle oinstall    18 May 20  2019 checkpoints
drwxrwxr-x.   6 grid   oinstall    64 Apr 20  2018 crsdata
drwxrwxr-x.  21 oracle oinstall  4096 Apr 20  2018 diag
drwxrwxr-x.   3 oracle oinstall    21 Apr 20  2018 diagsnap
drwxrwxr-x.   7 oracle oinstall    77 Apr 20  2018 grid
drwxrwxr-x.   3 oracle oinstall    25 Apr 20  2018 iudb939
drwxrwxr-x.   3 oracle oinstall    18 Apr 20  2018 log
drwxrwxr-x  242 oracle oinstall 12288 Nov  6  2019 orachk
drwxrwx---.   7 oracle oinstall  4096 Jun 22 14:38 oraInventory
drwxrwxr-x.   7 oracle oinstall    83 Apr 20 15:46 product
-rw-r--r--    1 root   root        26 Nov 19  2019 TFA.txt
[grid@iudb939(Staging) oracle]$ cd oraInventory
[grid@iudb939(Staging) oraInventory]$ ls -la
total 40
drwxrwx---.  7 oracle oinstall  4096 Jun 22 14:38 .
drwxrwxr-x. 15 oracle oinstall  4096 Apr 20 15:46 ..
drwxrwx---. 15 oracle oinstall  4096 May 20  2019 backup
drwxrwx---.  2 oracle oinstall    60 Apr 20  2018 ContentsXML
drwxr-----   2 oracle oinstall    28 May 17 09:15 locks
drwxrwx---.  4 oracle oinstall 16384 May 17 09:15 logs
-rwxrwx---.  1 oracle oinstall    63 Apr 20  2018 oraInst.loc
-rwxrwx---.  1 oracle oinstall  1683 Apr 20  2018 orainstRoot.sh
drwxrwx---.  2 oracle oinstall    22 Apr 20  2018 oui
[grid@iudb939(Staging) oraInventory]$ cd locks
-bash: cd: locks: Permission denied
[grid@iudb939(Staging) oraInventory]$ logout


[root@iudb939(Staging) grid]# chmod 777 /u01/app/oracle/oraInventory/locks


И правя RELINK процедурата отначало !!!!!!
