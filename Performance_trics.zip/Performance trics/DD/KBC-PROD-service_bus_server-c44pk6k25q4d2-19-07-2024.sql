/********************************************************************************
*********       E-mail subject: KBCCFWEB-2360
*********             Instance: PROD
*********          Description: 
Problem:
From KBC PROD was reported slowness in the Service_bus for the period from 16/07 10:19:47 to 16/07 10:28:10.

Analysis:
After the analyze, we found that the TOP SQL c44pk6k25q4d2 was responsible for 94% of the time of module service_bus_server961C3AED8C7BD06E3A810F39A54AC8FE.
It looks like this SQL has several execution plans and in this case, it was executed with execution plan, which instead of accessing table g_indivparam using index G_INDIVPARAM_REFIND
through columns refindividu and type, it access the table through index G_IND_STR10_TYPE_IDX, which is not selective. To stabilize the query to use index G_INDIVPARAM_REFIND every time and avoid 
situations like this, we added hint as it is shown in the New SQL section below.

Suggestion:
Please change the query that is from ftr_limit2.pcc and ftr_request.pcc as it is shown in the New SQL section below.

*********               SQL_ID: c44pk6k25q4d2
*********      Program/Package: ftr_limit2.pcc, ftr_request.pcc
*********              Request: Lubomir Vladov
*********               Author: Dimitar Dimitrov
********* Received e-mail date: 18/07/2024
*********      Resolution date: 19/07/2024
*********  Trace old file here: \\epox\specifs\performance\tmp\
*********  Trace new file here:
***********************************************************************************/

/********************************OLD SQL*******************************************/

VAR B1 VARCHAR2(32);
EXEC :B1 := 'D1286576';

select nvl(mt09, (-1))
  from g_indivparam
 where type = 'HISTORY' 
   and cle_param like '%COMPANY%' 
   and refindividu = :b1
   and str10 = 'PD' 
   and dt09_dt = (select max(dt09_dt)
                     from g_indivparam
                    where type = 'HISTORY' 
                      and cle_param like '%COMPANY%'
                      and refindividu = :b1
                      and str10 = 'PD');
/********************************OLD SQL*******************************************/
/********************************OLD Metrics***************************************/
/*
MODULE                           PROGRAM                                            SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC                                                                                                                                                  
-------------------------------- -------------------------------------------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------                                                                                                                                                
service_bus_server961C3AED8C7BD0 service_bus_server                                                                1388      17933 ON CPU               2024/07/16 10:19:50  2024/07/16 10:28:12          50                 7800 +000000000 00:08:21.766 96%                                                                                                                                                   
6E3A810F39A54AC8FE                                                                                                                                                                                                                                                                                                                                                                                              
                                                                                                                                                                                                                                                                                                                                                                                                                
service_bus_serverC2B0110AD35D7C service_bus_server                                 gpjbjby74sjz7 1900895500        551      16734 ON CPU               2024/07/16 10:29:03  2024/07/16 10:29:03           1                    1 +000000000 00:00:00.000 2%                                                                                                                                                    
A87DA4C5A8699ADBD3                                                                                                                                                                                                                                                                                                                                                                                              
                                                                                                                                                                                                                                                                                                                                                                                                                
service_bus_serverC2B0110AD35D7C service_bus_server                                 22j27dthsg6pz 2054433438        551      16734 db file sequential r 2024/07/16 10:29:23  2024/07/16 10:29:23           1                    1 +000000000 00:00:00.000 2%                                                                                                                                                    
A87DA4C5A8699ADBD3  


MODULE                           PROGRAM                                            SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC                                                                                                                                                  
-------------------------------- -------------------------------------------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------                                                                                                                                                
service_bus_server961C3AED8C7BD0 service_bus_server                                                                1388      17933 ON CPU               2024/07/16 10:19:50  2024/07/16 10:28:12          50                 7800 +000000000 00:08:21.766 96%                                                                                                                                                   
6E3A810F39A54AC8FE                                                                                                                                                                                                                                                                                                                                                                                              
                                                                                                                                                                                                                                                                                                                                                                                                                
service_bus_serverC2B0110AD35D7C service_bus_server                                                                 551      16734                      2024/07/16 10:29:03  2024/07/16 10:29:23           2              3053398 +000000000 00:00:20.472 4%                                                                                                                                                    
A87DA4C5A8699ADBD3   


MODULE                           PROGRAM                                            SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC                                                                                                                                                  
-------------------------------- -------------------------------------------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------                                                                                                                                                
service_bus_server961C3AED8C7BD0 service_bus_server                                 c44pk6k25q4d2  180110520       1388      17933 ON CPU               2024/07/16 10:20:00  2024/07/16 10:28:12          49                   17 +000000000 00:08:11.526 94%                                                                                                                                                   
6E3A810F39A54AC8FE                                                                                                                                                                                                                                                                                                                                                                                              
                                                                                                                                                                                                                                                                                                                                                                                                                
service_bus_serverC2B0110AD35D7C service_bus_server                                 22j27dthsg6pz 2054433438        551      16734 db file sequential r 2024/07/16 10:29:23  2024/07/16 10:29:23           1                    1 +000000000 00:00:00.000 2%                                                                                                                                                    
A87DA4C5A8699ADBD3                                                                                                                                                                                                                                                                                                                                                                                              
                                                                                                                                                                                                                                                                                                                                                                                                                
service_bus_server961C3AED8C7BD0 service_bus_server                                 a52hwwahb6nu2 2598099793       1388      17933 ON CPU               2024/07/16 10:19:50  2024/07/16 10:19:50           1                    1 +000000000 00:00:00.000 2%                                                                                                                                                    
6E3A810F39A54AC8FE                                                                                                                                                                                                                                                                                                                                                                                              
                                                                                                                                                                                                                                                                                                                                                                                                                
service_bus_serverC2B0110AD35D7C service_bus_server                                 gpjbjby74sjz7 1900895500        551      16734 ON CPU               2024/07/16 10:29:03  2024/07/16 10:29:03           1                    1 +000000000 00:00:00.000 2%                                                                                                                                                    
A87DA4C5A8699ADBD3  



SQL_ID           SNAP_ID INSTANCE_NUMBER NAME                   POSITION DUP_POSITION DATATYPE_STRING      VALUE_STRING                             INTERVAL                                                                                                                                                                                                                                                                                                                                                        
------------- ---------- --------------- -------------------- ---------- ------------ -------------------- ---------------------------------------- ----------------------------------------------------                                                                                                                                                                                                                                                                                                            
c44pk6k25q4d2        911               1 :B1                           1              VARCHAR2(2000)       G1081622                                 2024/07/16 10                                                                                                                                                                                                                                                                                                                                                   
c44pk6k25q4d2        911               1 :B1                           1              VARCHAR2(32)         09544899                                 2024/07/16 10                                                                                                                                                                                                                                                                                                                                                   
c44pk6k25q4d2        911               1 :B1                           2              VARCHAR2(2000)       G1081622                                 2024/07/16 10                                                                                                                                                                                                                                                                                                                                                   
c44pk6k25q4d2        911               1 :B1                           2              VARCHAR2(32)         09544899                                 2024/07/16 10                                                                                                                                                                                                                                                                                                                                                   
c44pk6k25q4d2        912               1 :B1                           1              VARCHAR2(2000)       O1063JYW                                 2024/07/16 11                                                                                                                                                                                                                                                                                                                                                   
c44pk6k25q4d2        912               1 :B1                           1              VARCHAR2(32)         09544899                                 2024/07/16 11                                                                                                                                                                                                                                                                                                                                                   
c44pk6k25q4d2        912               1 :B1                           2              VARCHAR2(2000)       O1063JYW                                 2024/07/16 11                                                                                                                                                                                                                                                                                                                                                   
c44pk6k25q4d2        912               1 :B1                           2              VARCHAR2(32)         09544899                                 2024/07/16 11                                                                                                                                                                                                                                                                                                                                                   



INSTANCE_NUMBER SQL_ID            ELAPSED MAX_WAIT_ON     PC_OF  WAIT_TIME            GETS      READS       ROWS  ELAP/EXEC       GETS/EXEC READS/EXEC  ROWS/EXEC       EXEC PLAN_HASH_VALUE                                                                                                                                                                                                                                                                                                                        
--------------- ------------- ----------- --------------- ----- ---------- --------------- ---------- ---------- ---------- --------------- ---------- ---------- ---------- ---------------                                                                                                                                                                                                                                                                                                                        
              1 c44pk6k25q4d2        1357 CPU             100%  1343.27501       250827094          0         43      28.86         5336747          0        .91         47       180110520                                                                                                                                                                                                                                                                                                                        
              1 c44pk6k25q4d2           0 Application     0%             0               0          0          0          0               0          0          0          0       220936583   

 
              
SQL_ID        SQL_PLAN_HASH_VALUE SQL_PLAN_LINE_ID SQL_PLAN_OPERATION             SQL_PLAN_OPTIONS                   ACTIVE                                                                                                                                                                                                                                                                                                                                                                                         
------------- ------------------- ---------------- ------------------------------ ------------------------------ ----------                                                                                                                                                                                                                                                                                                                                                                                         
c44pk6k25q4d2           180110520                1 TABLE ACCESS                   BY INDEX ROWID BATCHED                 41                                                                                                                                                                                                                                                                                                                                                                                         
c44pk6k25q4d2           180110520                2 INDEX                          RANGE SCAN                              8                                                                                                                                                                                                                                                                                                                                                                                         
a52hwwahb6nu2          2598099793                6 INDEX                          SKIP SCAN                               1                


Plan hash value: 180110520
--------------------------------------------------------------------------------------------
| Id  | Operation                             | Name                 | E-Rows | Cost (%CPU)|
--------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                      |                      |        |     2 (100)|
|*  1 |  TABLE ACCESS BY INDEX ROWID BATCHED  | G_INDIVPARAM         |      1 |     1   (0)|
|*  2 |   INDEX RANGE SCAN                    | G_IND_STR10_TYPE_IDX |     82 |     1   (0)|
|   3 |   SORT AGGREGATE                      |                      |      1 |            |
|*  4 |    TABLE ACCESS BY INDEX ROWID BATCHED| G_INDIVPARAM         |      1 |     1   (0)|
|*  5 |     INDEX RANGE SCAN                  | G_INDIVPARAM_REFIND  |      1 |     1   (0)| 
--------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
 1 - filter(("CLE_PARAM" IS NOT NULL AND "REFINDIVIDU"=:B1 AND "CLE_PARAM" LIKE '%COMPANY%' AND "DT09_DT"=))
 2 - access("STR10"='PD' AND "TYPE"='HISTORY') 
 4 - filter(("DT09_DT" IS NOT NULL AND "STR10"='PD')) 	
 5 - access("REFINDIVIDU"=:B1 AND "TYPE"='HISTORY')	  
     filter(("CLE_PARAM" IS NOT NULL AND "CLE_PARAM" LIKE '%COMPANY%'))         
*/
/********************************OLD Metrics***************************************/

/********************************New SQL*******************************************/

select /*+ index(g_indivparam G_INDIVPARAM_REFIND) */
       nvl(mt09, (-1))
  from g_indivparam
 where type = 'HISTORY' 
   and cle_param like '%COMPANY%' 
   and refindividu = :b1
   and str10 = 'PD' 
   and dt09_dt = (select max(dt09_dt)
                     from g_indivparam
                    where type = 'HISTORY' 
                      and cle_param like '%COMPANY%'
                      and refindividu = :b1
                      and str10 = 'PD');
/********************************New SQL*******************************************/
/********************************New Metrics***************************************/
/*
Plan hash value: 220936583
------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                             | Name                | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers |
------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                      |                     |      1 |        |     2 (100)|      1 |00:00:00.01 |     445 |
|*  1 |  TABLE ACCESS BY INDEX ROWID BATCHED  | G_INDIVPARAM        |      1 |      1 |     1   (0)|      1 |00:00:00.01 |     445 |
|*  2 |   INDEX RANGE SCAN                    | G_INDIVPARAM_REFIND |      1 |      1 |     1   (0)|    220 |00:00:00.01 |       7 |
|   3 |   SORT AGGREGATE                      |                     |      1 |      1 |            |      1 |00:00:00.01 |     222 |
|*  4 |    TABLE ACCESS BY INDEX ROWID BATCHED| G_INDIVPARAM        |      1 |      1 |     1   (0)|    182 |00:00:00.01 |     222 |
|*  5 |     INDEX RANGE SCAN                  | G_INDIVPARAM_REFIND |      1 |      1 |     1   (0)|    220 |00:00:00.01 |       6 |
------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   1 - filter(("STR10"='PD' AND "DT09_DT"=))
   2 - access("REFINDIVIDU"=:B1 AND "TYPE"='HISTORY')
       filter(("CLE_PARAM" IS NOT NULL AND "CLE_PARAM" LIKE '%COMPANY%'))
   4 - filter(("DT09_DT" IS NOT NULL AND "STR10"='PD'))
   5 - access("REFINDIVIDU"=:B1 AND "TYPE"='HISTORY')
       filter(("CLE_PARAM" IS NOT NULL AND "CLE_PARAM" LIKE '%COMPANY%'))
*/
/********************************New Metrics***************************************/

/********************************Index statistics**********************************/

/********************************Other SQLs****************************************/          
/*

*/ 
/********************************Other SQLs****************************************/              
