=========================================================================
#### Grand ROLE (which can only select) and  create new USER  ########
=========================================================================

[root@ra005 ~]# ps -ef | grep pmon
[root@ra005 ~]# su - oracle
ra005():/home/oracle > . oraenv
ra005(PUBP):/home/oracle > sqlplus / as sysdba
==============================

SQL> select database_role from v$database;
SQL> show parameter unique


SQL> desc dba_users                                                      #### Да ми покаже имената на колоните в таблицата на юзърите

SQL> select USERNAME from dba_users where username='USERPUBP';           #### Да потърсим дали дадения юзър все пан не съществува :)

no rows selected

SQL> create user USERPUBP identified by Password2019;                   ##### Създаваме юзъра и му даваме парола

SQL> grant connect to USERPUBP;                                          #### Даваме му право да се кънектва към базата и в друг терминал пробваме дали се кънектва


SQL> desc dba_roles
 Name                                                                                                  Null?    Type
 --------------------------------------                                                             -------- ----------------
 ROLE                                                                                                  NOT NULL VARCHAR2(30)
 PASSWORD_REQUIRED                                                                                              VARCHAR2(8)
 AUTHENTICATION_TYPE                                                                                            VARCHAR2(11)

SQL> select ROLE from dba_roles;


SQL> select username from dba_users where username like 'SAFE%';          #### В случая на тези с SAFE_EMPRESA схеми,на техните таблици ни искат юзъра да може да прави селекти

USERNAME
------------------------------
SAFE_EMPRESA50
SAFE_EMPRESA36
SAFE_EMPRESA08
SAFE_EMPRESA33
SAFE_EMPRESA26
SAFE_EMPRESA63
SAFE_EMPRESA47
SAFE_EMPRESA01
SAFE_EMPRESA07
SAFE_EMPRESA45
SAFE_EMPRESA99

12 rows selected.

SQL> create role SAFE_SELECTROLE;                                 ##### Криейтвам нова роля,която има право само да прави select към таблиците на исканите от рикуестора схеми                             

    ##### С това правим така,че ролята,която създадохме да има право да прави само SELECT ######

BEGIN
   FOR R IN (SELECT owner, table_name FROM dba_tables where OWNER like 'SAFE_EMP%') LOOP
      EXECUTE IMMEDIATE 'grant select on '||R.owner||'.'||R.table_name||' to SAFE_SELECTROLE';
   END LOOP;
END;


SQL> SELECT count(*) FROM dba_tables where OWNER like 'SAFE_EMP%';    #### Селектваме да ни покаже колко общо са таблиците на дадените схеми,който ни трябват

  COUNT(*)
----------
      4113



SQL> select count(*) from dba_tables;      ##### Всички таблици 

  COUNT(*)
----------
      6066

SQL>
SQL>
SQL>
SQL> select count (*) from all_tables;     #####  Всички таблици към който юзъра има права

  COUNT(*)
----------
      6066

SQL> select count(*) from user_tables    ##### Всички таблици на юзъра
  2  ;

  COUNT(*)
----------
      1015
	  
	  
SQL> select count(*) from dba_tables where OWNER like 'SAFE_EMP%';


  COUNT(*)
----------
      4113


SQL> grant SAFE_SELECTROLE to USERPUBP;                               ###### Грантваме ролята на юзъра ни

Grant succeeded.


    ##############  Проверка  ######
	
SQL> desc dba_tab_privs
 Name                                                                                                  Null?    Type
 ----------------------------------------------------------------------------------------------------- -------- --------------------------------------------------------------------
 GRANTEE                                                                                               NOT NULL VARCHAR2(30)
 OWNER                                                                                                 NOT NULL VARCHAR2(30)
 TABLE_NAME                                                                                            NOT NULL VARCHAR2(30)
 GRANTOR                                                                                               NOT NULL VARCHAR2(30)
 PRIVILEGE                                                                                             NOT NULL VARCHAR2(40)
 GRANTABLE                                                                                                      VARCHAR2(3)
 HIERARCHY                                                                                                      VARCHAR2(3)

SQL> select * from dba_tab_privs where GRANTEE='SAFE_SELECTROLE';

GRANTEE                        OWNER                          TABLE_NAME                     GRANTOR                        PRIVILEGE                                GRA HIE
------------------------------ ------------------------------ ------------------------------ ------------------------------ ---------------------------------------- --- ---
SAFE_SELECTROLE                SAFE_EMPRESA33                 DIFERENCIAS                    SAFE_EMPRESA33                 SELECT                                   NO  NO
SAFE_SELECTROLE                SAFE_EMPRESA33                 DIFERENCIAS_INVENTARIO         SAFE_EMPRESA33                 SELECT                                   NO  NO
SAFE_SELECTROLE                SAFE_EMPRESA33                 DIFERENCIAS_PROVEEDOR          SAFE_EMPRESA33                 SELECT                                   NO  NO
SAFE_SELECTROLE                SAFE_EMPRESA33                 DIFERENCIA_TEMPORAL            SAFE_EMPRESA33                 SELECT                                   NO  NO
SAFE_SELECTROLE                SAFE_EMPRESA33                 DIRECCIONES_CLIENTES           SAFE_EMPRESA33                 SELECT                                   NO  NO
SAFE_SELECTROLE                SAFE_EMPRESA33                 DIRECCIONES_PROVEEDORES        SAFE_EMPRESA33                 SELECT                                   NO  NO
SAFE_SELECTROLE                SAFE_EMPRESA33                 DISTRIBUCIONES                 SAFE_EMPRESA33                 SELECT                                   NO  NO
SAFE_SELECTROLE                SAFE_EMPRESA33                 DOCUMENTOS                     SAFE_EMPRESA33                 SELECT                                   NO  NO
SAFE_SELECTROLE                SAFE_EMPRESA33                 DOCUMENTOS_CERRADOS_CLIENTES   SAFE_EMPRESA33                 SELECT                                   NO  NO
SAFE_SELECTROLE                SAFE_EMPRESA33                 DOCUMENTOS_FANDEXML            SAFE_EMPRESA33                 SELECT                                   NO  NO

   ################ Тук правим да не експирясва ##########

SQL> select profile from dba_profiles;
SQL> desc dba_profiles;

SQL> select * from dba_profiles;

SQL> alter user USERPUBP profile SAFE_PROFILE;

User altered.

SQL> select USERNAME,ACCOUNT_STATUS,PROFILE from dba_users where USERNAME in('USERPUBP');

USERNAME                       ACCOUNT_STATUS                   PROFILE
------------------------------ -------------------------------- ------------------------------
USERPUBP                       OPEN                             SAFE_PROFILE




=========================================================================================================
==========================================================================================================

##### To drop the user

revoke SAFE_SELECTROLE from USERPUBP;
drop user USERPUBP;



=======================
SA_ALPHIL
GbPFZSzaqOZwSF_8zzbyq
=========================


 
set lines 300
col USERNAME for a15
col ACCOUNT_STATUS for a10
col PROFILE for a40
select USERNAME,USER_ID,ACCOUNT_STATUS,CREATED,PROFILE,EXPIRY_DATE,CREATED from dba_users where username = UPPER( 'SA_ALPHIL'); 



; 
 #### CHECK PROFILE LIMITS FOR GIVEN PROFILE  ########

set lines 999
col PROFILE for a30
col RESOURCE_NAME for a30
col LIMIT for a20
select PROFILE,RESOURCE_NAME,LIMIT from dba_profiles where PROFILE='&PROFILE';


select * from USER_ROLE_PRIVS where USERNAME='SA_ALPHIL'; 
 

