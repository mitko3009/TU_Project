
============================================================================================================================================
######## DBSPI-0066: Alert log size 28.04 MB too big for ORA0311 >=20 MB. [Policy:DBMON-DBSPI-0066-ARM] ##########
 
##### gzip -9cv alert_KFP.log > alert_KFP.log.`date +%Y%m%d`.gz && > alert_KFP.log #######
   
   #### The alert log was truncated ..#######   ## В Solution ##

-rw-r--r--.  1 oracle oinstall    0 Jun 10 16:28 alert_ORA0311.log
-rw-r--r--.  1 root   root     1.1M Jun 10 16:28 alert_ORA0311.log.20190610.gz



1. [root@x0046 ~]# dbspicao -l

2. [root@x0046 ~]# ps -ef | grep pmon
oracle   13786     1  0 Mar27 ?        00:29:57 ora_pmon_ORA0309
oracle   13787     1  0 Mar27 ?        00:26:14 ora_pmon_ORA0310
oracle   13793     1  0 Mar27 ?        00:24:05 ora_pmon_ORA0201
oracle   13794     1  0 Mar27 ?        00:23:36 ora_pmon_ORA0222
oracle   13795     1  0 Mar27 ?        00:23:34 ora_pmon_ORA0224
oracle   13797     1  0 Mar27 ?        00:23:44 ora_pmon_ORA0241
oracle   13801     1  0 Mar27 ?        00:23:53 ora_pmon_ORA0352
oracle   13802     1  0 Mar27 ?        00:24:16 ora_pmon_ORA0293
oracle   13804     1  0 Mar27 ?        00:23:39 ora_pmon_ORA0198
oracle   13816     1  0 Mar27 ?        00:24:33 ora_pmon_ORA0227
oracle   13818     1  0 Mar27 ?        00:30:07 ora_pmon_ORA0207
oracle   13869     1  0 Mar27 ?        00:23:55 ora_pmon_ORA0194
oracle   13872     1  0 Mar27 ?        00:23:51 ora_pmon_ORA0200
oracle   13889     1  0 Mar27 ?        00:23:29 ora_pmon_ORA0229
oracle   47767     1  0 Mar28 ?        00:25:33 ora_pmon_ORA0311
root     48362 39152  0 16:19 pts/0    00:00:00 grep pmon

2. [root@x0046 ~]# dbspicao -l                                        ######## Za da izvadq loga #####

3. [root@x0046 ~]# su - oracle                         ##### V sluchaq ne izliza s komandata i pravim sledvashtoto po nadolu #######

4. x0046::~$ . oraenv
ORACLE_SID = [oracle] ? ORA0311
The Oracle base remains unchanged with value /u01/app/oracle

5. x0046:ORA0311:~$ sqlplus / as sysdba

6. SQL> show parameter back

NAME                                 TYPE                             VALUE
------------------------------------ -------------------------------- ------------------------------
background_core_dump                 string                           partial
background_dump_dest                 string                           /u01/app/oracle/diag/rdbms/ora
                                                                      0311/ORA0311/trace
backup_tape_io_slaves                boolean                          FALSE
db_flashback_retention_target        integer                          1440
fast_start_parallel_rollback         string                           LOW
rollback_segments                    string
transactions_per_rollback_segment    integer                          5
SQL> set lines 999
SQL> show parameter back

NAME                                 TYPE                             VALUE
------------------------------------ -------------------------------- ------------------------------
background_core_dump                 string                           partial
background_dump_dest                 string                           /u01/app/oracle/diag/rdbms/ora
                                                                      0311/ORA0311/trace
backup_tape_io_slaves                boolean                          FALSE
db_flashback_retention_target        integer                          1440
fast_start_parallel_rollback         string                           LOW
rollback_segments                    string
transactions_per_rollback_segment    integer                          5

7. [root@x0046 ~]# cd /u01/app/oracle/diag/rdbms/ora0311/ORA0311/trace          ##### Влизаме в директорията,където е alert log-a ########

8. root@x0046 trace]# ls -lah
total 61M
drwxr-xr-x.  3 oracle oinstall  60K Jun 10 12:00 .
drwxr-xr-x. 15 oracle oinstall 4.0K Mar 13  2017 ..
-rw-r--r--.  1 oracle oinstall  29M Jun 10 11:30 alert_ORA0311.log
-rw-r-----.  1 oracle oinstall  17M Dec  3  2018 alert_ORA0311.log.old
drwxr-xr-x.  2 oracle oinstall  12K Jun  1 00:01 cdmp_20190515220044
-rw-r-----.  1 oracle oinstall  49K Jun 10 04:20 ORA0311_arc0_60941.trc
-rw-r-----.  1 oracle oinstall 8.8K Jun 10 04:20 ORA0311_arc0_60941.trm
-rw-r-----.  1 oracle oinstall  49K Jun 10 01:00 ORA0311_arc1_60943.trc

9.[root@x0046 trace]# gzip -9cv alert_ORA0311.log>alert_ORA0311.log.`date +%Y%m%d`.gz && >alert_ORA0311.log      ##### GZIP Alert log ######
alert_ORA0311.log:       96.3%
10. [root@x0046 trace]# ls -lah
total 34M
drwxr-xr-x.  3 oracle oinstall  60K Jun 10 16:28 .
drwxr-xr-x. 15 oracle oinstall 4.0K Mar 13  2017 ..
-rw-r--r--.  1 oracle oinstall    0 Jun 10 16:28 alert_ORA0311.log
-rw-r--r--.  1 root   root     1.1M Jun 10 16:28 alert_ORA0311.log.20190610.gz
-rw-r-----.  1 oracle oinstall  17M Dec  3  2018 alert_ORA0311.log.old
drwxr-xr-x.  2 oracle oinstall  12K Jun  1 00:01 cdmp_20190515220044
-rw-r-----.  1 oracle oinstall  49K Jun 10 04:20 ORA0311_arc0_60941.trc
-rw-r-----.  1 oracle oinstall 8.8K Jun 10 04:20 ORA0311_arc0_60941.trm
-rw-r-----.  1 oracle oinstall  49K Jun 10 01:00 ORA0311_arc1_60943.trc
