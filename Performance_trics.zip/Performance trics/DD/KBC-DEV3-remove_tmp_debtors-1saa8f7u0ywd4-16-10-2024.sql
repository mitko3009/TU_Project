/********************************************************************************
*********       E-mail subject: KBCCFDEV-6085
*********             Instance: DEV3
*********          Description: 
Problem:
It was requested to check the work of the remove_tmp_debtors on DEV3.

Analysis:
I checked for module remove_tmp_debtors on KBC DEV3 for the period between 11:00 and 12:00 on 16/10/2024 and found that the TOP 2 SQLs 1saa8f7u0ywd4 and 0xkggs7n0xjf9 were 
responsible for ~90% of the time. The problem in both of them is that they are making bad execution plan because of missing index on table G_ELEMFI ( index G_ELEM_REFVALIDATOR_IDX ) 
and on table G_INDIVIDU ( index REF_ON_BOARDING_ADDRESS_IDX ), which leads to full scans.

Suggestion:
1. Please deliver index REF_ON_BOARDING_ADDRESS_IDX on table G_INDIVIDU from refbg2 to KBC DEV3. 
2. Please deliver index G_ELEM_REFVALIDATOR_IDX on table G_ELEMFI from refbg2 to KBC DEV3.

*********               SQL_ID: 1saa8f7u0ywd4, 0xkggs7n0xjf9
*********      Program/Package: 
*********              Request: Vihren Dimitrov
*********               Author: Dimitar Dimitrov
********* Received e-mail date: 16/10/2024
*********      Resolution date: 16/10/2024
*********  Trace old file here: \\epox\specifs\performance\tmp\
*********  Trace new file here:
***********************************************************************************/

/********************************OLD SQL*******************************************/

-- 1saa8f7u0ywd4

INSERT INTO ARCH_G_ELEMFI
  SELECT t.*,
         t.rowid as ARCHROWID,
         p.ARCH_ID,
         1 as CHECKTODELETE,
         'FK_G_ELEMFI_PERSO_VALDTR'
    FROM G_ELEMFI t, 
         ARCH_G_PERSONNEL p
   WHERE t.REFPERSO_VALIDATOR = p.REFPERSO
     AND NOT EXISTS ( SELECT 1 
                        FROM ARCH_G_ELEMFI ta 
                       WHERE ta.ARCHROWID = t.rowid );

-- 0xkggs7n0xjf9

INSERT INTO ARCH_G_INDIVIDU
  SELECT t.*,
         t.rowid as ARCHROWID,
         p.ARCH_ID,
         1 as CHECKTODELETE,
         'FK_G_INDIVIDU_G_ADRESSE'
    FROM G_INDIVIDU t, 
         ARCH_G_ADRESSE p
   WHERE t.REF_ON_BOARDING_ADDRESS = p.REFADR
     AND NOT EXISTS ( SELECT 1 
                        FROM ARCH_G_INDIVIDU ta 
                       WHERE ta.ARCHROWID = t.rowid );
/********************************OLD SQL*******************************************/
/********************************OLD Metrics***************************************/
/*
MODULE                           PROGRAM                                            CLIENT_ID       SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- -------------------------------------------------- --------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
remove_tmp_debtors               remove_tmp_debtors                                                                                 282      30236 ON CPU               2024/10/16 11:00:00  2024/10/16 11:56:15        2584                49191 +000000000 00:56:15.104 39%
                                                                                                    772s25v1y0x8k                                  ON CPU               2024/10/16 11:00:03  2024/10/16 11:59:59        1151                    1 +000000000 00:59:56.288 17%
imxbatch_ClientFunding           imxbatch                                                                                            30        998 db file sequential r 2024/10/16 11:00:06  2024/10/16 11:25:00         878               244656 +000000000 00:24:54.016 13%
remove_tmp_debtors               remove_tmp_debtors                                                 1saa8f7u0ywd4 1669910842        282      30236 direct path read     2024/10/16 11:00:02  2024/10/16 11:56:00         614                   34 +000000000 00:55:58.720 9%
imxbatch_ClientFunding           imxbatch                                                                                            30        998 ON CPU               2024/10/16 11:00:03  2024/10/16 11:24:58         392               216858 +000000000 00:24:55.041 6%
imxbatch_ClientFunding           imxbatch                                                                                            30        998 db file scattered re 2024/10/16 11:00:05  2024/10/16 11:21:48         103                16825 +000000000 00:21:43.552 2%
                                                                                                                           0                       log file parallel wr 2024/10/16 11:00:21  2024/10/16 11:52:06         100                      +000000000 00:51:44.768 2%
imxbatch_ClientFunding           imxbatch                                                                                            30        998 db file parallel rea 2024/10/16 11:00:18  2024/10/16 11:24:34          84                40665 +000000000 00:24:16.130 1%
remove_tmp_debtors               remove_tmp_debtors                                                                                 282      30236 db file scattered re 2024/10/16 11:00:37  2024/10/16 11:52:02          67                   30 +000000000 00:51:24.288 1%
                                 oracle                                                                                    0        257      30405 db file parallel wri 2024/10/16 11:04:22  2024/10/16 11:57:00          59                      +000000000 00:52:38.016 1%
KTSJ                                                                                                fbjs6vqydm3xa                                  ON CPU               2024/10/16 11:03:06  2024/10/16 11:58:27          47                    1 +000000000 00:55:20.833 1%
sqlplus                          sqlplus                                                                                                           ON CPU               2024/10/16 11:01:06  2024/10/16 11:59:52          43                 5228 +000000000 00:58:45.633 1%


MODULE                           PROGRAM                                            CLIENT_ID       SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                    ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- -------------------------------------------------- --------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
remove_tmp_debtors               remove_tmp_debtors                                                                                 282      30236                      2024/10/16 11:00:00  2024/10/16 11:56:15     3289                49191 +000000000 00:56:15.104 100%



MODULE                           PROGRAM                                            CLIENT_ID       SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- -------------------------------------------------- --------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
remove_tmp_debtors               remove_tmp_debtors                                                                                 282      30236 ON CPU               2024/10/16 11:00:00  2024/10/16 11:56:15        2584                49191 +000000000 00:56:15.104 79%
remove_tmp_debtors               remove_tmp_debtors                                                 1saa8f7u0ywd4 1669910842        282      30236 direct path read     2024/10/16 11:00:02  2024/10/16 11:56:00         614                   34 +000000000 00:55:58.720 19%
remove_tmp_debtors               remove_tmp_debtors                                                                                 282      30236 db file scattered re 2024/10/16 11:00:37  2024/10/16 11:52:02          67                   30 +000000000 00:51:24.288 2%
remove_tmp_debtors               remove_tmp_debtors                                                                                 282      30236 db file sequential r 2024/10/16 11:00:12  2024/10/16 11:51:55          11                   11 +000000000 00:51:42.720 0%
remove_tmp_debtors               remove_tmp_debtors                                                                                 282      30236 db file parallel rea 2024/10/16 11:00:33  2024/10/16 11:52:40           8                   31 +000000000 00:52:06.273 0%
remove_tmp_debtors               remove_tmp_debtors                                                                        0        282      30236 enq: RO - fast objec 2024/10/16 11:21:54  2024/10/16 11:52:01           5                    1 +000000000 00:30:06.333 0%


MODULE                           PROGRAM                                            CLIENT_ID       SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- -------------------------------------------------- --------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
remove_tmp_debtors               remove_tmp_debtors                                                 1saa8f7u0ywd4 1669910842        282      30236                      2024/10/16 11:00:00  2024/10/16 11:56:15        2655                   34 +000000000 00:56:15.104 81%
remove_tmp_debtors               remove_tmp_debtors                                                 0xkggs7n0xjf9 2296502009        282      30236                      2024/10/16 11:00:37  2024/10/16 11:52:39         352                   11 +000000000 00:52:01.152 11%
remove_tmp_debtors               remove_tmp_debtors                                                 d79mwqzhd55sa 3803619458        282      30236 ON CPU               2024/10/16 11:06:49  2024/10/16 11:52:05           8                41759 +000000000 00:45:15.647 0%
remove_tmp_debtors               remove_tmp_debtors                                                 0521quu2a66j0          0        282      30236 ON CPU               2024/10/16 11:00:15  2024/10/16 11:26:47           5                    6 +000000000 00:26:32.320 0%

SQL_ID        SQL_PLAN_HASH_VALUE SQL_PLAN_LINE_ID SQL_PLAN_OPERATION             SQL_PLAN_OPTIONS                   ACTIVE
------------- ------------------- ---------------- ------------------------------ ------------------------------ ----------
1saa8f7u0ywd4          1669910842                4 TABLE ACCESS                   FULL                                  267
0xkggs7n0xjf9          2296502009                4 TABLE ACCESS                   FULL                                   37


INSTANCE_NUMBER SQL_ID            ELAPSED MAX_WAIT_ON     PC_OF  WAIT_TIME            GETS      READS       ROWS  ELAP/EXEC       GETS/EXEC READS/EXEC  ROWS/EXEC       EXEC PLAN_HASH_VALUE
--------------- ------------- ----------- --------------- ----- ---------- --------------- ---------- ---------- ---------- --------------- ---------- ---------- ---------- ---------------
              1 1saa8f7u0ywd4         213 CPU             81%   212.064274        13616830   13616199          0     106.43         6808415  6808099.5          0          2      1669910842


-- 1saa8f7u0ywd4

Plan hash value: 1669910842
----------------------------------------------------------------------------------------------------------
| Id  | Operation                | Name             | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   |
----------------------------------------------------------------------------------------------------------
|   0 | INSERT STATEMENT         |                  |      1 |        |  1710K(100)|      0 |00:00:00.01 |
|   1 |  LOAD TABLE CONVENTIONAL | ARCH_G_ELEMFI    |      1 |        |            |      0 |00:00:00.01 |
|*  2 |   HASH JOIN ANTI         |                  |      1 |      1 |  1710K  (2)|      0 |00:00:00.01 |
|*  3 |    HASH JOIN             |                  |      1 |      1 |  1710K  (2)|      0 |00:00:00.01 |
|*  4 |     TABLE ACCESS FULL    | G_ELEMFI         |      1 |      1 |  1710K  (2)|      0 |00:00:00.01 |
|   5 |     TABLE ACCESS FULL    | ARCH_G_PERSONNEL |      0 |      1 |     2   (0)|      0 |00:00:00.01 |
|   6 |    TABLE ACCESS FULL     | ARCH_G_ELEMFI    |      0 |      1 |     2   (0)|      0 |00:00:00.01 |
----------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   2 - access("TA"."ARCHROWID"="T".ROWID)
   3 - access("T"."REFPERSO_VALIDATOR"="P"."REFPERSO")
   4 - filter("T"."REFPERSO_VALIDATOR" IS NOT NULL)


-- 0xkggs7n0xjf9

Plan hash value: 2296502009
---------------------------------------------------------------------------------------------------------
| Id  | Operation                | Name            | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   |
---------------------------------------------------------------------------------------------------------
|   0 | INSERT STATEMENT         |                 |      1 |        |   152K(100)|      0 |00:00:00.01 |
|   1 |  LOAD TABLE CONVENTIONAL | ARCH_G_INDIVIDU |      1 |        |            |      0 |00:00:00.01 |
|*  2 |   HASH JOIN ANTI         |                 |      1 |      1 |   152K  (4)|      0 |00:00:00.01 |
|*  3 |    HASH JOIN             |                 |      1 |      1 |   152K  (4)|      0 |00:00:00.01 |
|*  4 |     TABLE ACCESS FULL    | G_INDIVIDU      |      1 |      1 |   152K  (4)|      0 |00:00:00.01 |
|   5 |     TABLE ACCESS FULL    | ARCH_G_ADRESSE  |      0 |      1 |     3   (0)|      0 |00:00:00.01 |
|   6 |    TABLE ACCESS FULL     | ARCH_G_INDIVIDU |      0 |      2 |     3   (0)|      0 |00:00:00.01 |
---------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   2 - access("TA"."ARCHROWID"="T".ROWID)
   3 - access("T"."REF_ON_BOARDING_ADDRESS"="P"."REFADR")
   4 - filter("T"."REF_ON_BOARDING_ADDRESS" IS NOT NULL)
*/
/********************************OLD Metrics***************************************/

/********************************New SQL*******************************************/

-- No changes in the SQL text.
/********************************New SQL*******************************************/
/********************************New Metrics***************************************/
/*
-- 1saa8f7u0ywd4

Plan hash value: 800125120
--------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                      | Name             | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers |
--------------------------------------------------------------------------------------------------------------------------
|   0 | INSERT STATEMENT               |                  |      1 |        |     5 (100)|      0 |00:00:00.01 |       3 |
|   1 |  LOAD TABLE CONVENTIONAL       | ARCH_G_ELEMFI    |      1 |        |            |      0 |00:00:00.01 |       3 |
|*  2 |   HASH JOIN ANTI               |                  |      1 |      1 |     5   (0)|      0 |00:00:00.01 |       3 |
|   3 |    NESTED LOOPS                |                  |      1 |      1 |     3   (0)|      0 |00:00:00.01 |       3 |
|   4 |     NESTED LOOPS               |                  |      1 |      1 |     3   (0)|      0 |00:00:00.01 |       3 |
|   5 |      TABLE ACCESS FULL         | ARCH_G_PERSONNEL |      1 |      1 |     2   (0)|      0 |00:00:00.01 |       3 |
|*  6 |      INDEX RANGE SCAN          | TEST_DD_INDEX    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|   7 |     TABLE ACCESS BY INDEX ROWID| G_ELEMFI         |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|   8 |    TABLE ACCESS FULL           | ARCH_G_ELEMFI    |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |
--------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   2 - access("TA"."ARCHROWID"="T".ROWID)
   6 - access("T"."REFPERSO_VALIDATOR"="P"."REFPERSO")
       filter("T"."REFPERSO_VALIDATOR" IS NOT NULL)


-- 0xkggs7n0xjf9

Plan hash value: 1335766786
-------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                      | Name            | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers |
-------------------------------------------------------------------------------------------------------------------------
|   0 | INSERT STATEMENT               |                 |      1 |        |     7 (100)|      0 |00:00:00.01 |      10 |
|   1 |  LOAD TABLE CONVENTIONAL       | ARCH_G_INDIVIDU |      1 |        |            |      0 |00:00:00.01 |      10 |
|*  2 |   HASH JOIN ANTI               |                 |      1 |      1 |     7   (0)|      0 |00:00:00.01 |      10 |
|   3 |    NESTED LOOPS                |                 |      1 |      1 |     4   (0)|      0 |00:00:00.01 |      10 |
|   4 |     NESTED LOOPS               |                 |      1 |      1 |     4   (0)|      0 |00:00:00.01 |      10 |
|   5 |      TABLE ACCESS FULL         | ARCH_G_ADRESSE  |      1 |      1 |     3   (0)|      0 |00:00:00.01 |      10 |
|*  6 |      INDEX RANGE SCAN          | TEST_DD_INDEX   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|   7 |     TABLE ACCESS BY INDEX ROWID| G_INDIVIDU      |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|   8 |    TABLE ACCESS FULL           | ARCH_G_INDIVIDU |      0 |      2 |     3   (0)|      0 |00:00:00.01 |       0 |
-------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   2 - access("TA"."ARCHROWID"="T".ROWID)
   6 - access("T"."REF_ON_BOARDING_ADDRESS"="P"."REFADR")
       filter("T"."REF_ON_BOARDING_ADDRESS" IS NOT NULL) 
*/
/********************************New Metrics***************************************/

/********************************Index statistics**********************************/

/********************************Other SQLs****************************************/          
/*

*/ 
/********************************Other SQLs****************************************/              
