/********************************************************************************
*********       E-mail subject: IMBWEB-8242
*********             Instance: UATR
*********          Description: 
Problem:
We were requested to check the performance of the imxbatch_AggrFundingDay between 08:00 and 09:52 on 13/02/2025 on UATR.

Analysis:
We checked the work of the imxbatch_AggrFundingDay and found that the TOP SQL is dxbc02341c5wd ( from ftr_imxbatch.pck ), which was responsible for 100% of the time. The main problem of this query is that
table G_PIECEDET STD into the inline view DCMP is not joined to the other tables. We removed it from the query and the query became much faster, but the other thing that we noticed is that
the DCMP inline view is joined to table G_PIECE MD, where it finds over 3k rows in this case for the refodss from DCMP and after that, goes to table G_DOSSIER D to filer which of these rows is for the REFPIECE_DECOMPTE ( it is only one row ).
The better way here is to join the DCMP to table G_DOSSIER D, where we will find only the row we are interested in and then go to table G_PIECE MD to check is it 'MEMO_DECOMPTE'.
Also, we added hint to force Oracle to join table GROUP_CONTRACTS GC in the DCMP using nested loops and using index, instead of making full scan and hash join.

Suggestion:
Please check is the query in the New SQL section below functionaly correct and if it is, change SQL dxbc02341c5wd ( from ftr_imxbatch.pck ) as it is shown.

*********               SQL_ID: dxbc02341c5wd
*********      Program/Package: ftr_imxbatch.pck
*********              Request: Branimir Lalev
*********               Author: Dimitar Dimitrov
********* Received e-mail date: 14/02/2025
*********      Resolution date: 14/02/2025
*********  Trace old file here: \\epox\specifs\performance\tmp\
*********  Trace new file here:
***********************************************************************************/

/********************************OLD SQL*******************************************/

VAR B1 VARCHAR2(32);
EXEC :B1 := '0001010086';
VAR B2 VARCHAR2(32);
EXEC :B2 := '';
VAR B3 VARCHAR2(32);
EXEC :B3 := '';
VAR B4 VARCHAR2(32);
EXEC :B4 := '';
VAR B5 VARCHAR2(32);
EXEC :B5 := '';
VAR B6 VARCHAR2(32);
EXEC :B6 := '2025-02-01';

SELECT NVL( SUM( DECODE( D.DEVISE,
                         :B5,
                         STD.MT08,
                         CH_TAUX.CONV_ORIG_DEST_TX( TO_CHAR( TO_DATE(:B6, 'YYYY-MM-DD') , 'j' ),
                                                    STD.MT08,
                                                    D.DEVISE,
                                                    :B5,
                                                    'MR',
                                                    :B4,
                                                    :B3 ) ) ), 0 ) TOTAL_AVL,
       NVL( SUM( DECODE( D.REFDOSS, :B2, STD.MT08 ) ), 0 ) STMT_AVL
  FROM (SELECT DISTINCT D.REFDOSS REFDOSS, 
                        D.DEVISE DEVISE
          FROM G_DOSSIER D,
               G_DOSSIER CTR,
               G_PIECEDET STD,
               MEMBER_CONTRACT MC,
               GROUP_CONTRACTS GC,
               ( SELECT REFGROUP 
                   FROM MEMBER_CONTRACT 
                  WHERE REFDOSS = :B1 ) CONTR_GR
         WHERE MC.REFGROUP = CONTR_GR.REFGROUP
           AND GC.REFGROUP = MC.REFGROUP
           AND GC.VALID = 'O'
           AND CTR.REFDOSS = MC.REFDOSS
           AND D.REFLOT = CTR.REFDOSS
        UNION
        SELECT REFDOSS, 
               DEVISE
          FROM G_DOSSIER
         WHERE REFLOT = :B1 ) DCMP,
       G_PIECE MD,
       G_PIECEDET STD,
       G_DOSSIER D
 WHERE MD.REFDOSS = DCMP.REFDOSS
   AND MD.REFPIECE = D.REFPIECE_DECOMPTE
   AND MD.TYPPIECE = 'MEMO_DECOMPTE'
   AND STD.REFPIECE = MD.REFPIECE
   AND STD.TYPE = 'MEMO_DECOMPTE_STD';
/********************************OLD SQL*******************************************/
/********************************OLD Metrics***************************************/
/*
MODULE                           PROGRAM                                            CLIENT_ID       SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- -------------------------------------------------- --------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
imxbatch_AggrFundingDay          imxbatch                                                                                           576      46859                      2025/02/13 08:00:16  2025/02/13 09:52:58         676                   40 +000000000 01:52:41.388 100%


MODULE                           PROGRAM                                            CLIENT_ID       SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- -------------------------------------------------- --------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
imxbatch_AggrFundingDay          imxbatch                                                                                           576      46859 ON CPU               2025/02/13 08:00:27  2025/02/13 09:52:58         540                   40 +000000000 01:52:31.380 80%
imxbatch_AggrFundingDay          imxbatch                                                           dxbc02341c5wd 2695013995        576      46859 cell list of blocks  2025/02/13 08:00:47  2025/02/13 09:51:08         118                   40 +000000000 01:50:21.291 17%
imxbatch_AggrFundingDay          imxbatch                                                           dxbc02341c5wd 2695013995        576      46859 cell single block ph 2025/02/13 08:11:18  2025/02/13 09:45:27          12                   32 +000000000 01:34:09.588 2%
imxbatch_AggrFundingDay          imxbatch                                                           dxbc02341c5wd 2695013995        576      46859 cell multiblock phys 2025/02/13 08:00:16  2025/02/13 09:40:07           4                   34 +000000000 01:39:50.220 1%
imxbatch_AggrFundingDay          imxbatch                                                           dxbc02341c5wd 2695013995        576      46859 resmgr:cpu quantum   2025/02/13 08:14:38  2025/02/13 09:29:26           2                   24 +000000000 01:14:47.807 0%


MODULE                           PROGRAM                                            CLIENT_ID       SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- -------------------------------------------------- --------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
imxbatch_AggrFundingDay          imxbatch                                                           dxbc02341c5wd 2695013995        576      46859                      2025/02/13 08:00:16  2025/02/13 09:52:58         675                   40 +000000000 01:52:41.388 100%
imxbatch_AggrFundingDay          imxbatch                                                           2fz0hqc3s1q53 1110410051        576      46859 ON CPU               2025/02/13 09:41:17  2025/02/13 09:41:17           1                    1 +000000000 00:00:00.000 0%


INSTANCE_NUMBER SQL_ID            ELAPSED MAX_WAIT_ON     PC_OF  WAIT_TIME            GETS      READS       ROWS  ELAP/EXEC       GETS/EXEC READS/EXEC  ROWS/EXEC       EXEC PLAN_HASH_VALUE
--------------- ------------- ----------- --------------- ----- ---------- --------------- ---------- ---------- ---------- --------------- ---------- ---------- ---------- ---------------
              1 dxbc02341c5wd        6757 CPU             82%   7597.87612       263211944  173936497         41     164.82         6419804 4242353.59          1         41      2695013995




SQL_ID        SQL_PLAN_HASH_VALUE SQL_PLAN_LINE_ID SQL_PLAN_OPERATION             SQL_PLAN_OPTIONS                   ACTIVE
------------- ------------------- ---------------- ------------------------------ ------------------------------ ----------
dxbc02341c5wd          2695013995               11 SORT                           UNIQUE                                311
dxbc02341c5wd          2695013995                7 TABLE ACCESS                   BY INDEX ROWID BATCHED                162
dxbc02341c5wd          2695013995               27 INDEX                          STORAGE FAST FULL SCAN                106
dxbc02341c5wd          2695013995               12 UNION ALL PUSHED PREDICATE                                            69
dxbc02341c5wd          2695013995                6 HASH JOIN                                                             12
dxbc02341c5wd          2695013995                8 INDEX                          RANGE SCAN                             12
dxbc02341c5wd          2695013995                9 TABLE ACCESS                   STORAGE FULL                            1
dxbc02341c5wd          2695013995                3 HASH JOIN                                                              1
dxbc02341c5wd          2695013995               19 INDEX                          UNIQUE SCAN                             1


Plan hash value: 2695013995
------------------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                     | Name                 | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  |
------------------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                              |                      |      1 |        |  2993K(100)|      1 |00:00:33.02 |    4265K|   3417K|
|   1 |  SORT AGGREGATE                               |                      |      1 |      1 |            |      1 |00:00:33.02 |    4265K|   3417K|
|   2 |   NESTED LOOPS                                |                      |      1 |   1834 |  2993K (39)|      1 |00:00:33.02 |    4265K|   3417K|
|*  3 |    HASH JOIN                                  |                      |      1 |    323 |   259K  (3)|    497 |00:00:33.01 |    4261K|   3417K|
|   4 |     TABLE ACCESS BY INDEX ROWID BATCHED       | G_DOSSIER            |      1 |    496 |   465   (1)|    497 |00:00:00.01 |     468 |      0 |
|*  5 |      INDEX FULL SCAN                          | DOS_REFPIECE_DCPT    |      1 |    496 |     6   (0)|    497 |00:00:00.01 |      12 |      0 |
|*  6 |     HASH JOIN                                 |                      |      1 |   1184K|   258K  (3)|   1825K|00:00:32.42 |    4261K|   3417K|
|   7 |      TABLE ACCESS BY INDEX ROWID BATCHED      | G_PIECEDET           |      1 |   1185K|   154K  (1)|   1825K|00:00:28.88 |    1131K|    287K|
|*  8 |       INDEX RANGE SCAN                        | G_PIECEDET_TYPE_NB01 |      1 |   1185K|  4818   (2)|   1825K|00:00:02.27 |    7725 |   1919 |
|*  9 |      TABLE ACCESS STORAGE FULL                | G_PIECE              |      1 |   1820K|   103K  (6)|   1825K|00:00:00.51 |    3129K|   3129K|
|  10 |    VIEW                                       |                      |    497 |      1 |  8466  (43)|      1 |00:00:00.01 |    3771 |      2 |
|  11 |     SORT UNIQUE                               |                      |    497 |      2 |  8466  (43)|      1 |00:00:00.01 |    3771 |      2 |
|  12 |      UNION ALL PUSHED PREDICATE               |                      |    497 |        |            |      1 |00:00:00.01 |    3771 |      2 |
|  13 |       MERGE JOIN CARTESIAN                    |                      |    497 |    958K|  8283  (42)|      0 |00:00:00.01 |    2134 |      2 |
|  14 |        NESTED LOOPS                           |                      |    497 |      1 |     6   (0)|      0 |00:00:00.01 |    2134 |      2 |
|  15 |         NESTED LOOPS                          |                      |    497 |      1 |     6   (0)|      0 |00:00:00.01 |    2134 |      2 |
|  16 |          NESTED LOOPS                         |                      |    497 |      1 |     5   (0)|      0 |00:00:00.01 |    2134 |      2 |
|  17 |           NESTED LOOPS                        |                      |    497 |      1 |     4   (0)|      0 |00:00:00.01 |    2134 |      2 |
|  18 |            TABLE ACCESS BY INDEX ROWID        | G_DOSSIER            |    497 |      1 |     3   (0)|    497 |00:00:00.01 |    1637 |      2 |
|* 19 |             INDEX UNIQUE SCAN                 | DOS_REFDOSS          |    497 |      1 |     2   (0)|    497 |00:00:00.01 |    1139 |      2 |
|  20 |            TABLE ACCESS BY INDEX ROWID BATCHED| MEMBER_CONTRACT      |    497 |      1 |     1   (0)|      0 |00:00:00.01 |     497 |      0 |
|* 21 |             INDEX RANGE SCAN                  | MC_REFDOSS_IDX       |    497 |      1 |     0   (0)|      0 |00:00:00.01 |     497 |      0 |
|* 22 |           TABLE ACCESS BY INDEX ROWID BATCHED | MEMBER_CONTRACT      |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 23 |            INDEX RANGE SCAN                   | MC_REFDOSS_IDX       |      0 |      1 |     0   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 24 |          INDEX UNIQUE SCAN                    | PK_GROUP_CONTRACTS   |      0 |      1 |     0   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 25 |         TABLE ACCESS BY INDEX ROWID           | GROUP_CONTRACTS      |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|  26 |        BUFFER SORT                            |                      |      0 |    126M|  8282  (42)|      0 |00:00:00.01 |       0 |      0 |
|  27 |         INDEX STORAGE FAST FULL SCAN          | PK_G_PIECEDET_PK     |      0 |    126M|  8277  (42)|      0 |00:00:00.01 |       0 |      0 |
|* 28 |       TABLE ACCESS BY INDEX ROWID             | G_DOSSIER            |    497 |      1 |     3   (0)|      1 |00:00:00.01 |    1637 |      0 |
|* 29 |        INDEX UNIQUE SCAN                      | DOS_REFDOSS          |    497 |      1 |     2   (0)|    497 |00:00:00.01 |    1139 |      0 |
------------------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   3 - access("MD"."REFPIECE"="D"."REFPIECE_DECOMPTE")
   5 - filter("D"."REFPIECE_DECOMPTE" IS NOT NULL)
   6 - access("STD"."REFPIECE"="MD"."REFPIECE")
   8 - access("STD"."TYPE"='MEMO_DECOMPTE_STD')
   9 - storage("MD"."TYPPIECE"='MEMO_DECOMPTE')
       filter("MD"."TYPPIECE"='MEMO_DECOMPTE')
  19 - access("D"."REFDOSS"="MD"."REFDOSS")
  21 - access("REFDOSS"=:B1)
  22 - filter("MC"."REFGROUP"="REFGROUP")
  23 - access("D"."REFLOT"="MC"."REFDOSS")
       filter("MC"."REFDOSS" IS NOT NULL)
  24 - access("GC"."REFGROUP"="MC"."REFGROUP")
  25 - filter("GC"."VALID"='O')
  28 - filter("REFLOT"=:B1)
  29 - access("REFDOSS"="MD"."REFDOSS")

*/
/********************************OLD Metrics***************************************/

/********************************New SQL*******************************************/

SELECT /*+ leading(DCMP D MD STD) index(D DOS_REFDOSS)*/
       NVL( SUM( DECODE( D.DEVISE,
                         :B5,
                         STD.MT08,
                         CH_TAUX.CONV_ORIG_DEST_TX( TO_CHAR( TO_DATE(:B6, 'YYYY-MM-DD') , 'j' ),
                                                    STD.MT08,
                                                    D.DEVISE,
                                                    :B5,
                                                    'MR',
                                                    :B4,
                                                    :B3 ) ) ), 0 ) TOTAL_AVL,
       NVL( SUM( DECODE( D.REFDOSS, :B2, STD.MT08 ) ), 0 ) STMT_AVL
  FROM (SELECT /*+ use_nl(GC) index(GC PK_GROUP_CONTRACTS)*/
               D.REFDOSS REFDOSS, 
               D.DEVISE DEVISE
          FROM G_DOSSIER D,
               G_DOSSIER CTR,
               MEMBER_CONTRACT MC,
               GROUP_CONTRACTS GC,
               ( SELECT REFGROUP 
                   FROM MEMBER_CONTRACT 
                  WHERE REFDOSS = :B1 ) CONTR_GR
         WHERE MC.REFGROUP = CONTR_GR.REFGROUP
           AND GC.REFGROUP = MC.REFGROUP
           AND GC.VALID = 'O'
           AND CTR.REFDOSS = MC.REFDOSS
           AND D.REFLOT = CTR.REFDOSS
        UNION
        SELECT REFDOSS, 
               DEVISE
          FROM G_DOSSIER
         WHERE REFLOT = :B1 ) DCMP,
       G_PIECE MD,
       G_PIECEDET STD,
       G_DOSSIER D
WHERE D.REFDOSS = DCMP.REFDOSS
   AND MD.REFPIECE = D.REFPIECE_DECOMPTE
   AND MD.TYPPIECE = 'MEMO_DECOMPTE'
   AND STD.REFPIECE = MD.REFPIECE
   AND STD.TYPE = 'MEMO_DECOMPTE_STD';
/********************************New SQL*******************************************/
/********************************New Metrics***************************************/
/*
Plan hash value: 3737857721
---------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                       | Name               | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers |
---------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                                |                    |      1 |        |  1463 (100)|      1 |00:00:00.01 |      19 |
|   1 |  SORT AGGREGATE                                 |                    |      1 |      1 |            |      1 |00:00:00.01 |      19 |
|   2 |   NESTED LOOPS                                  |                    |      1 |      1 |  1463   (1)|      1 |00:00:00.01 |      19 |
|   3 |    NESTED LOOPS                                 |                    |      1 |      1 |  1463   (1)|      1 |00:00:00.01 |      18 |
|   4 |     NESTED LOOPS                                |                    |      1 |      1 |  1459   (1)|      1 |00:00:00.01 |      14 |
|   5 |      NESTED LOOPS                               |                    |      1 |      1 |  1456   (1)|      1 |00:00:00.01 |      10 |
|   6 |       VIEW                                      |                    |      1 |    637 |   179   (3)|      1 |00:00:00.01 |       5 |
|   7 |        SORT UNIQUE                              |                    |      1 |    637 |   179   (3)|      1 |00:00:00.01 |       5 |
|   8 |         UNION-ALL                               |                    |      1 |        |            |      1 |00:00:00.01 |       5 |
|   9 |          NESTED LOOPS                           |                    |      1 |    354 |    90   (0)|      0 |00:00:00.01 |       1 |
|  10 |           NESTED LOOPS                          |                    |      1 |    354 |    90   (0)|      0 |00:00:00.01 |       1 |
|  11 |            NESTED LOOPS                         |                    |      1 |      1 |     6   (0)|      0 |00:00:00.01 |       1 |
|  12 |             NESTED LOOPS                        |                    |      1 |      3 |     3   (0)|      0 |00:00:00.01 |       1 |
|  13 |              TABLE ACCESS BY INDEX ROWID BATCHED| MEMBER_CONTRACT    |      1 |      1 |     2   (0)|      0 |00:00:00.01 |       1 |
|* 14 |               INDEX RANGE SCAN                  | MC_REFDOSS_IDX     |      1 |      1 |     1   (0)|      0 |00:00:00.01 |       1 |
|* 15 |              TABLE ACCESS BY INDEX ROWID BATCHED| MEMBER_CONTRACT    |      0 |      3 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 16 |               INDEX RANGE SCAN                  | MC_REFGROUP_IDX    |      0 |      3 |     0   (0)|      0 |00:00:00.01 |       0 |
|* 17 |             TABLE ACCESS BY INDEX ROWID         | GROUP_CONTRACTS    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 18 |              INDEX UNIQUE SCAN                  | PK_GROUP_CONTRACTS |      0 |      1 |     0   (0)|      0 |00:00:00.01 |       0 |
|* 19 |            INDEX RANGE SCAN                     | DOSS_LOT           |      0 |    284 |     2   (0)|      0 |00:00:00.01 |       0 |
|  20 |           TABLE ACCESS BY INDEX ROWID           | G_DOSSIER          |      0 |    283 |    84   (0)|      0 |00:00:00.01 |       0 |
|  21 |          TABLE ACCESS BY INDEX ROWID BATCHED    | G_DOSSIER          |      1 |    283 |    85   (0)|      1 |00:00:00.01 |       4 |
|* 22 |           INDEX RANGE SCAN                      | DOSS_LOT           |      1 |    283 |     3   (0)|      1 |00:00:00.01 |       3 |
|* 23 |       TABLE ACCESS BY INDEX ROWID               | G_DOSSIER          |      1 |      1 |     2   (0)|      1 |00:00:00.01 |       5 |
|* 24 |        INDEX UNIQUE SCAN                        | DOS_REFDOSS        |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |
|* 25 |      TABLE ACCESS BY INDEX ROWID BATCHED        | G_PIECE            |      1 |      1 |     3   (0)|      1 |00:00:00.01 |       4 |
|* 26 |       INDEX RANGE SCAN                          | PIE_REFPIECE       |      1 |      1 |     2   (0)|      1 |00:00:00.01 |       3 |
|* 27 |     INDEX RANGE SCAN                            | G_PIECEDET_REFP    |      1 |      1 |     3   (0)|      1 |00:00:00.01 |       4 |
|  28 |    TABLE ACCESS BY INDEX ROWID                  | G_PIECEDET         |      1 |      1 |     4   (0)|      1 |00:00:00.01 |       1 |
---------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
  14 - access("REFDOSS"=:B1)
  15 - filter("MC"."REFDOSS" IS NOT NULL)
  16 - access("MC"."REFGROUP"="REFGROUP")
  17 - filter("GC"."VALID"='O')
  18 - access("GC"."REFGROUP"="MC"."REFGROUP")
  19 - access("D"."REFLOT"="MC"."REFDOSS")
  22 - access("REFLOT"=:B1)
  23 - filter("D"."REFPIECE_DECOMPTE" IS NOT NULL)
  24 - access("D"."REFDOSS"="DCMP"."REFDOSS")
  25 - filter("MD"."TYPPIECE"='MEMO_DECOMPTE')
  26 - access("MD"."REFPIECE"="D"."REFPIECE_DECOMPTE")
  27 - access("STD"."REFPIECE"="MD"."REFPIECE" AND "STD"."TYPE"='MEMO_DECOMPTE_STD')
*/
/********************************New Metrics***************************************/

/********************************Index statistics**********************************/

/********************************Other SQLs****************************************/          
/*

*/ 
/********************************Other SQLs****************************************/              
