/********************************************************************************
*********       E-mail subject: COFAWEB-7041
*********             Instance: UAT
*********          Description: 
Problem:
There was a slowness on COFACE UAT on 01/11/2023.

Analysis:
The TOP SQL for the provided period was 95zcfsw2h01gs. There was unnecessarily joined table t_elements which makes 
Oracle to use inappropriate execution plan making full scan of tables g_piece and t_elements.

Suggestion:
Please remove the unnecessarily joined table t_elements as it is shown in the New SQL section below.

*********               SQL_ID: 95zcfsw2h01gs
*********      Program/Package: 
*********              Request: Aleksandar Kotsev
*********               Author: Dimitar Dimitrov
********* Received e-mail date: 01/11/2023
*********      Resolution date: 02/11/2023
*********  Trace old file here: \\epox\specifs\performance\tmp\
*********  Trace new file here:
***********************************************************************************/

/********************************OLD SQL*******************************************/
var B1 varchar2(32);
exec :B1 := 'AN';
var B2 varchar2(32);
exec :B2 := 'AN';
var B3 varchar2(32);
exec :B3 := 'AN';
var B4 varchar2(32);
exec :B4 := 'AN';
var B5 varchar2(32);
exec :B5 := '';
var B6 varchar2(32);
exec :B6 := 'AN';
var B7 varchar2(32);
exec :B7 := '2306140368';
var B8 varchar2(32);
exec :B8 := '6510';
var B9 varchar2(32);
exec :B9 := 'AN';
var B10 varchar2(32);
exec :B10 := 'AN';

SELECT *
  FROM (SELECT DISTINCT e.refdoss refdoss,
                        e.refelem refelem,
                        e.typeelem type,
                        NVL(vd_types.abrev_trad, e.typeelem) translatedType,
                        NVL(vd_types.valeur_trad, e.typeelem) ||
                        DECODE(gelem.refext, NULL, '', ' : ' || gelem.refext) translatedTypeHint,
                        NVL(vd2.ecran, 'XXX') invisible,
                        /*link authorization NOTE ne pipaj tozi select!!!*/
                        DECODE((SELECT libelle
                                 FROM g_pers_auth g
                                WHERE g.typeelem = auth.typeelem
                                  AND rowtype = 'USER_LINK'
                                  AND g.refperso = auth.refperso
                                  AND rownum = 1),
                               'NOTHING',
                               NULL
                               /*nothing */,
                               'ALL',
                               NVL(e.libelle, 'ALL'),
                               /*all*/
                               DECODE(NVL((SELECT libelle_type
                                            FROM g_pers_auth g
                                           WHERE g.typeelem = auth.typeelem
                                             AND ROWTYPE = 'USER_LINK'
                                             AND g.refperso = auth.refperso
                                             AND NVL(imx.ftranslate_str(e.libelle,
                                                                        :B1,
                                                                        DECODE(e.typeelem,
                                                                               'an',
                                                                               e.abrev,
                                                                               e.typeelem)),
                                                     e.libelle) LIKE
                                                 g.libelle
                                             AND libelle_type = 1
                                             AND ROWNUM = 1),
                                          0),
                                      1,
                                      e.libelle,
                                      0,
                                      DECODE((SELECT LIBELLE
                                               FROM ec_user ec, g_pers_auth gp
                                              WHERE ec.groupid = gp.refperso
                                                AND ec.refperso =
                                                    auth.refperso
                                                AND gp.ROWTYPE = 'GROUP_LINK'
                                                AND gp.TYPEELEM =
                                                    auth.TYPEELEM
                                                AND ROWNUM = 1),
                                             'ALL',
                                             1,
                                             'NOTHING',
                                             0,
                                             DECODE((SELECT LIBELLE
                                                      FROM ec_user     ec,
                                                           g_pers_auth gp
                                                     WHERE ec.groupid =
                                                           gp.refperso
                                                       AND gp.TYPEELEM =
                                                           auth.TYPEELEM
                                                       AND gp.ROWTYPE =
                                                           'GROUP_LINK'
                                                       AND ec.refperso =
                                                           auth.refperso
                                                       AND ROWNUM = 1),
                                                    '0',
                                                    0,
                                                    1)))) label,
                        /* end link */
                        e.montant_dos montant,
                        e.DTASSOC_DT dateAssoc,
                        e.dtassoc,
                        e.dtsaisie,
                        e.rejet reject,
                        e.nom name,
                        e.ancrefdoss origine,
                        e.dtsaisie_dt entryDate,
                        DECODE(NVL(vd_types.abrev1, 'N'),
                               'O',
                               e.dtassoc_dt,
                               e.dtsaisie_dt) displayDate,
                        trim(DECODE(DECODE(e.typeelem || '/' ||
                                           NVL(vd2.abrev, 'NULL'),
                                           'in/STS',
                                           '0',
                                           'in/STA',
                                           '0',
                                           'in/STACUST',
                                           '0',
                                           'in/STALDC',
                                           '0',
                                           'in/LDCACK',
                                           '0',
                                           'in/LEGAL',
                                           '0',
                                           'in/NULL',
                                           DECODE(SUBSTR(e.libelle, 0, 6),
                                                  'IMXTEL',
                                                  ' ',
                                                  '0')),
                                    '0',
                                    ' ',
                                    /* start translate label 1- EXTRANET_CHRONO_LIBELLES(type, moyenpaimt or gfi.type or mlibelle), 2 - EXTRANET_CHRONO_LIBELLES(type), 3 - LIBELLINFO, 4 - ftranslate_str  */
                                    NVL(NVL((SELECT DECODE(e.typeelem,
                                                          'ms',
                                                          REPLACE(e.libelle,
                                                                  vd.chemin,
                                                                  vd.valeur_trad),
                                                          'fa',
                                                          REPLACE(UPPER(e.libelle),
                                                                  vd.chemin,
                                                                  vd.valeur_trad),
                                                          vd.valeur_trad)
                                            /* For type 'ms' replace chemin in the libelle, otherwise directlly returns translated value */
                                              FROM (SELECT vd1.abrev,
                                                           vd1.chemin,
                                                           vd1.valeur_trad,
                                                           vd1.valeur
                                                      FROM v_tdomaine vd1
                                                     WHERE vd1.type(+) =
                                                           'EXTRANET_CHRONO_LIBELLES'
                                                       AND vd1.langue(+) = :B2
                                                       AND vd1.valeur_trad IS NOT NULL
                                                     ORDER BY vd1.chemin DESC) vd
                                             WHERE vd.abrev(+) = e.typeelem
                                               AND vd.chemin =
                                                   DECODE(e.typeelem,
                                                          'en',
                                                          (SELECT ge.moyenpaimt
                                                             FROM g_encaissement ge
                                                            WHERE e.refelem =
                                                                  ge.refencaiss
                                                              AND NOT EXISTS
                                                            (SELECT 1
                                                                     FROM t_elements
                                                                    WHERE refelem =
                                                                          e.refelem
                                                                      AND e.dtannul_dt IS NULL)
                                                              AND ROWNUM < 2),
                                                          'fi',
                                                          (SELECT gfi.type
                                                             FROM g_elemfi gfi
                                                            WHERE e.refelem =
                                                                  gfi.refelem
                                                              AND ROWNUM < 2),
                                                          'fa',
                                                          (DECODE(instr(UPPER(e.libelle),
                                                                        vd.chemin),
                                                                  0,
                                                                  e.libelle,
                                                                  vd.chemin)),
                                                          'ms',
                                                          (DECODE(instr(e.libelle,
                                                                        vd.chemin),
                                                                  0,
                                                                  e.libelle,
                                                                  vd.chemin)),
                                                          /* For type 'ms' search for chemin as a part of libelle (e.g: 'RE: Message from Customer')  */
                                                          'in',
                                                          SUBSTR(e.libelle,
                                                                 0,
                                                                 LENGTH(vd.chemin))
                                                          /* translate IMXTEL */,
                                                          e.libelle)
                                               AND ROWNUM < 2),
                                            (SELECT vd3.valeur_trad
                                               FROM v_tdomaine vd3
                                              WHERE vd3.type =
                                                    'EXTRANET_CHRONO_LIBELLES'
                                                AND vd3.abrev = e.typeelem
                                                AND vd3.chemin IS NULL
                                                AND vd3.langue = :B3
                                                AND ROWNUM < 2)),
                                        /* if label starts with 'A.' then goto imx.ftranslate_str */
                                        COALESCE((SELECT v1.valeur_trad
                                                   FROM v_tdomaine v1
                                                  WHERE v1.type =
                                                        'MESSAGE_SUBJECT'
                                                    AND v1.langue = UPPER(:B4)
                                                    AND v1.valeur = e.libelle),
                                                 DECODE(SUBSTR(e.libelle, 1, 2),
                                                        'A.',
                                                        NULL,
                                                        vd2.valeur_trad),
                                                 NVL(imx.ftranslate_str(e.libelle,
                                                                        :B5,
                                                                        DECODE(e.typeelem,
                                                                               'an',
                                                                               e.abrev,
                                                                               e.typeelem)),
                                                     e.libelle))))) translatedLabel,
                        DECODE(e.typeelem, 'an', e.dtannul_dt, DTSAISIE_DT) dateSaisie,
                        NVL((SELECT Trim(i.nom || ' ' || i.prenom)
                              FROM g_individu i, g_personnel p
                             WHERE p.login = e.createur
                               AND i.refindividu = p.refindividu
                               AND ROWNUM < 2),
                            e.createur) creator,
                        DECODE(e.typeelem,
                               'fi',
                               (SELECT fa.REF_CREANCE
                                  FROM g_elemfi fa
                                 WHERE e.refelem = fa.refelem
                                   AND rownum < 2)) otherReference,
                        DECODE(e.typeelem,
                               'me',
                               NVL((SELECT '1'
                                     FROM t_mail tm, t_entmail te
                                    WHERE tm.refmail = te.refmail
                                      AND te.refmail = e.refelem
                                      AND te.sens = 'E'
                                      AND ROWNUM = 1),
                                   '0'),
                               'mr',
                               NVL((SELECT 1
                                     FROM t_mail tm, t_entmail te
                                    WHERE tm.refmail = te.refmail
                                      AND te.refmail = e.refelem
                                      AND te.sens = 'R'
                                      AND ROWNUM = 1),
                                   '0'),
                               'ms',
                               NVL((SELECT 1
                                     FROM g_information
                                    WHERE refinfo = e.refelem
                                      AND typemetteur = 'A'
                                      AND ROWNUM = 1),
                                   '0'),
                               'fi',
                               NVL((SELECT '1'
                                     FROM g_piece pie
                                    WHERE e.refelem = pie.refext
                                      AND gpiimage = 'X'
                                      AND pie.code = 'fi'
                                      AND pie.typpiece = 'IMAGE_EXTERNE'
                                      AND pie.gpiimage = 'X'
                                      AND refimage IS NOT NULL
                                      AND rownum = 1),
                                   '0'),
                               'eg',
                               NVL((SELECT '1'
                                     FROM g_piece pie
                                    WHERE (SELECT ee_maitre
                                             FROM f_entenr
                                            WHERE ee_num = e.refelem) =
                                          pie.refext
                                      AND gpiimage = 'X'
                                      AND pie.code = 'eg'
                                      AND pie.typpiece = 'IMAGE_EXTERNE'
                                      AND pie.gpiimage = 'X'
                                      AND refimage IS NOT NULL
                                      AND rownum = 1),
                                   '0'),
                               NVL((SELECT '1'
                                     FROM g_piece pie
                                    WHERE (e.refelem = pie.refpiece OR
                                          e.refelem = pie.refext)
                                      AND gpiimage = 'X'
                                      AND refimage IS NOT NULL
                                      AND rownum = 1),
                                   '0')) attachment
          FROM t_elements  e,
               g_pers_auth auth,
               v_tdomaine  vd2,
               v_tdomaine  vd_types,
               g_elemfi    gelem
         WHERE 1 = 1
           AND e.refdoss = gelem.refdoss(+)
           AND e.refelem = gelem.refelem(+)
           AND NOT EXISTS
         (SELECT gp.refpiece
                  FROM g_piece gp,
                       t_elements te
                 WHERE gp.refpiece = te.refelem
                   AND te.refelem = e.refelem
                   AND NVL(gp.FG_NOT_VISIBLE_IN_XNET, 'N') = 'O')
           AND e.typeelem NOT IN ('se', 'ng', 'an', 'yy', 'et', 'xx', 'ce')
              /* prevodi  */
           AND vd2.type(+) = 'LIBELINFO'
           AND vd2.valeur(+) = DECODE(SUBSTR(e.libelle, 1, 2),
                                      'A.',
                                      SUBSTR(e.libelle, 3),
                                      e.libelle)
           AND vd2.langue(+) = :B6
              /* authorizacia po tip */
           AND auth.typeelem = DECODE(e.typeelem,
                                      'in',
                                      DECODE(vd2.valeur, NULL, 'in', 'in_s'),
                                      e.typeelem)
           AND e.refdoss = :B7
           AND auth.rowtype = 'USER'
           AND auth.refperso = :B8
              /* disable NOTHING */
           AND auth.libelle != 'NOTHING'
              /* type=1 will be excluded later */
              /* check the rest */
           AND (NOT EXISTS (SELECT 1
                              FROM g_pers_auth ex
                             WHERE ex.refperso = auth.refperso
                               AND ex.typeelem = auth.typeelem
                               AND ex.ROWTYPE = 'USER'
                               AND ex.libelle_type = 0) OR
                (NVL(auth.libelle_type, 0) = 0 AND
                (NVL(auth.libelle, 'NOTHING') = 'ALL' OR
                e.libelle LIKE auth.libelle)))
              /* exclude labels */
           AND NOT EXISTS
         (SELECT 1
                  FROM g_pers_auth ex
                 WHERE ex.refperso = auth.refperso
                   AND ex.typeelem = auth.typeelem
                   AND ex.rowtype = 'USER'
                   AND ex.libelle_type = 1
                   AND e.libelle LIKE ex.libelle)
              /* translations check */
           AND ((EXISTS
                (SELECT vd.valeur_trad
                    FROM v_tdomaine vd
                   WHERE vd.type(+) = 'EXTRANET_CHRONO_LIBELLES'
                     AND vd.abrev(+) = e.typeelem
                     AND vd.chemin = DECODE(e.typeelem,
                                            'en',
                                            (SELECT ge.moyenpaimt
                                               FROM g_encaissement ge
                                              WHERE e.refelem = ge.refencaiss
                                                AND rownum < 2),
                                            'fi',
                                            (SELECT DISTINCT gfi.type
                                               FROM g_elemfi gfi
                                              WHERE e.refelem = gfi.refelem
                                                AND rownum < 2),
                                            e.libelle)
                     AND vd.langue(+) = :B9
                     AND vd.valeur_trad IS NOT NULL)) OR
               /* when not exists, check if it is allowed to show untranslated strings */
               ((NOT EXISTS
                (SELECT 1
                     FROM v_extr_dom ve
                    WHERE ve.type = 'CHRONO_VIEW_TRANSLATED_LABELS_ONLY'
                      AND ve.abrev = auth.refperso
                      AND valeur = 'O')) AND
               (NOT EXISTS (SELECT 1
                                FROM g_pers_auth tr
                               WHERE tr.typeelem = e.typeelem
                                 AND tr.rowtype = 'USER_TRANSL'
                                 AND tr.refperso = auth.refperso
                                 AND tr.transl = 1))))
              /* translate typeelem */
           AND vd_types.type(+) = 'ELEM_CHRONO'
           AND vd_types.langue(+) = :B10
           AND vd_types.abrev(+) = e.typeelem
           AND (e.typeelem NOT IN 'ms' OR
               1 = (SELECT DECODE((SELECT 1
                                     FROM v_extr_dom
                                    WHERE TYPE = 'CHRONO_PARTY_REQUIRED'
                                      AND abrev = auth.refperso
                                      AND valeur = 'ms'
                                      AND valeur_2 = 'USER'
                                      AND rownum = 1),
                                   1,
                                   NVL((SELECT 1
                                         FROM g_information gi
                                        WHERE gi.refinfo = e.refelem
                                          AND (gi.refemetteur IN
                                              (SELECT refindividu
                                                  FROM g_personnel
                                                 WHERE refperso = auth.refperso) OR
                                              gi.encodeur IN
                                              (SELECT refindividu
                                                  FROM g_personnel
                                                 WHERE refperso = auth.refperso))),
                                       0),
                                   1)
                       FROM dual))
              /* mr,me */
           AND (e.typeelem NOT IN ('me') OR
               1 =
               (SELECT DECODE((SELECT 1
                                 FROM v_extr_dom
                                WHERE TYPE = 'CHRONO_PARTY_REQUIRED'
                                  AND abrev = auth.refperso
                                  AND valeur IN ('me')
                                  AND valeur_2 = 'USER'
                                  AND rownum = 1),
                               1,
                               NVL((SELECT 1
                                     FROM t_entmail gi, g_personnel gp
                                    WHERE gi.refmail = e.refelem
                                      AND e.typeelem = 'me'
                                      AND ((gp.email IN (gi.expediteur,
                                                         gi.destinataire,
                                                         gi.cc)) OR
                                          (gi.expediteur IN
                                          (SELECT DISTINCT numtel
                                               FROM g_telephone tel,
                                                    v_extr_dom  ind,
                                                    v_domaine   typeTel
                                              WHERE tel.refindividu =
                                                    ind.valeur
                                                AND ind.abrev = auth.refperso
                                                AND ind.TYPE =
                                                    'EXTR_GEST_CLIENT'
                                                AND typeTel.type = 'typtel'
                                                AND typeTel.ecran = 'EMAIL'
                                                AND tel.typetel = typeTel.abrev
                                                AND tel.validite = 'O')) OR
                                          (gi.destinataire IN
                                          (SELECT DISTINCT numtel
                                               FROM g_telephone tel,
                                                    v_extr_dom  ind,
                                                    v_domaine   typeTel
                                              WHERE tel.refindividu =
                                                    ind.valeur
                                                AND ind.abrev = auth.refperso
                                                AND ind.TYPE =
                                                    'EXTR_GEST_CLIENT'
                                                AND typeTel.type = 'typtel'
                                                AND typeTel.ecran = 'EMAIL'
                                                AND tel.typetel = typeTel.abrev
                                                AND tel.validite = 'O')) OR
                                          (gi.cc IN
                                          (SELECT DISTINCT numtel
                                               FROM g_telephone tel,
                                                    v_extr_dom  ind,
                                                    v_domaine   typeTel
                                              WHERE tel.refindividu =
                                                    ind.valeur
                                                AND ind.abrev = auth.refperso
                                                AND ind.TYPE =
                                                    'EXTR_GEST_CLIENT'
                                                AND typeTel.type = 'typtel'
                                                AND typeTel.ecran = 'EMAIL'
                                                AND tel.typetel = typeTel.abrev
                                                AND tel.validite = 'O')))
                                      AND gp.refperso = auth.refperso),
                                   0),
                               1)
                   FROM dual))
           AND (e.typeelem NOT IN ('mr') OR
               1 =
               (SELECT DECODE((SELECT 1
                                 FROM v_extr_dom
                                WHERE TYPE = 'CHRONO_PARTY_REQUIRED'
                                  AND abrev = auth.refperso
                                  AND valeur IN ('mr')
                                  AND valeur_2 = 'USER'
                                  AND rownum = 1),
                               1,
                               NVL((SELECT 1
                                     FROM t_entmail gi, g_personnel gp
                                    WHERE gi.refmail = e.refelem
                                      AND e.typeelem = 'mr'
                                      AND ((gp.email IN (gi.expediteur,
                                                         gi.destinataire,
                                                         gi.cc)) OR
                                          (gi.expediteur IN
                                          (SELECT DISTINCT numtel
                                               FROM g_telephone tel,
                                                    v_extr_dom  ind,
                                                    v_domaine   typeTel
                                              WHERE tel.refindividu =
                                                    ind.valeur
                                                AND ind.abrev = auth.refperso
                                                AND ind.TYPE =
                                                    'EXTR_GEST_CLIENT'
                                                AND typeTel.type = 'typtel'
                                                AND typeTel.ecran = 'EMAIL'
                                                AND tel.typetel = typeTel.abrev
                                                AND tel.validite = 'O')) OR
                                          (gi.destinataire IN
                                          (SELECT DISTINCT numtel
                                               FROM g_telephone tel,
                                                    v_extr_dom  ind,
                                                    v_domaine   typeTel
                                              WHERE tel.refindividu =
                                                    ind.valeur
                                                AND ind.abrev = auth.refperso
                                                AND ind.TYPE =
                                                    'EXTR_GEST_CLIENT'
                                                AND typeTel.type = 'typtel'
                                                AND typeTel.ecran = 'EMAIL'
                                                AND tel.typetel = typeTel.abrev
                                                AND tel.validite = 'O')) OR
                                          (gi.cc IN
                                          (SELECT DISTINCT numtel
                                               FROM g_telephone tel,
                                                    v_extr_dom  ind,
                                                    v_domaine   typeTel
                                              WHERE tel.refindividu =
                                                    ind.valeur
                                                AND ind.abrev = auth.refperso
                                                AND ind.TYPE =
                                                    'EXTR_GEST_CLIENT'
                                                AND typeTel.type = 'typtel'
                                                AND typeTel.ecran = 'EMAIL'
                                                AND tel.typetel = typeTel.abrev
                                                AND tel.validite = 'O')))
                                      AND gp.refperso = auth.refperso),
                                   0),
                               1)
                   FROM dual))
              /*dont show hidden me, mr */
           AND NOT (e.typeelem IN ('me', 'mr') AND EXISTS
                 (SELECT 1
                       FROM t_entmail
                      WHERE t_entmail.refmail = e.refelem
                        AND t_entmail.NOT_VISIBLE = 'O'))
              /*dont show hidden in, ms */
           AND NOT (e.typeelem IN ('in', 'ms') AND EXISTS
                 (SELECT 1
                       FROM g_information
                      WHERE g_information.refinfo = e.refelem
                        AND g_information.extranet_invis = 'O'))) el_info
 WHERE 1 = 1
   AND el_info.invisible != 'invis extranet'
 ORDER BY displayDate DESC;
/********************************OLD SQL*******************************************/
/********************************OLD Metrics***************************************/
/*
MODULE                           SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL               PERC
-------------------------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
EXTRANET                                                         549      29911 db file sequential r 2023/11/01 15:09:02  2023/11/01 15:14:41         273                  13 +000000000 00:05:38.138 43%
imx2easy_monitoring              frddp1m7w3mgs  329341886        263      25224 db file sequential r 2023/11/01 15:09:26  2023/11/01 15:14:48         133                  11 +000000000 00:05:21.138 21%
imx2easy_monitoring              frddp1m7w3mgs  329341886        263      25224 ON CPU               2023/11/01 15:09:09  2023/11/01 15:14:59          97                  13 +000000000 00:05:49.138 15%
EXTRANET                         95zcfsw2h01gs 3009034583        549      29911 ON CPU               2023/11/01 15:09:08  2023/11/01 15:14:17          61                   1 +000000000 00:05:08.134 10%
stat_crx                                                         603      48111 ON CPU               2023/11/01 15:10:13  2023/11/01 15:10:37          15             5908367 +000000000 00:00:24.002 2%
soa_integration                                                                 ON CPU               2023/11/01 15:09:27  2023/11/01 15:14:09          15              424803 +000000000 00:04:41.133 2%
stat_crx_rangmt                                                  603      23107 ON CPU               2023/11/01 15:10:41  2023/11/01 15:11:06         6       1207596 +000000000 00:00:25.000 1%

 
 
 MODULE                           SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL               PERC
-------------------------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
EXTRANET                                                         549      29911 db file sequential r 2023/11/01 15:09:02  2023/11/01 15:14:41         273                  13 +000000000 00:05:38.138 81%
EXTRANET                         95zcfsw2h01gs 3009034583        549      29911 ON CPU               2023/11/01 15:09:08  2023/11/01 15:14:17          61                   1 +000000000 00:05:08.134 18%
EXTRANET                         95zcfsw2h01gs 3009034583        549      29911 direct path read tem 2023/11/01 15:13:41  2023/11/01 15:13:41         1     1 +000000000 00:00:00.000 0%

MODULE                           SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL               PERC
-------------------------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
EXTRANET                         95zcfsw2h01gs 3009034583        549      29911                      2023/11/01 15:09:07  2023/11/01 15:14:41         334                   1 +000000000 00:05:33.138 100%
EXTRANET                         1uqjuh3ny2kjh 1087835665        549      29911 db file sequential r 2023/11/01 15:09:02  2023/11/01 15:09:02         1     1 +000000000 00:00:00.000 0%


 INSTANCE_NUMBER SQL_ID            ELAPSED MAX_WAIT_ON     PC_OF  WAIT_TIME            GETS      READS       ROWS  ELAP/EXEC       GETS/EXEC READS/EXECROWS/EXEC        EXEC PLAN_HASH_VALUE
--------------- ------------- ----------- --------------- ----- ---------- --------------- ---------- ---------- ---------- --------------- ---------- ---------- ---------- ---------------
              2 95zcfsw2h01gs         534 IO              74%   600.530372        27813107    1794620         70     533.98        27813107    1794620       70           1      3009034583



SQL_ID        SQL_PLAN_HASH_VALUE SQL_PLAN_LINE_ID SQL_PLAN_OPERATION             SQL_PLAN_OPTIONS                   ACTIVE
------------- ------------------- ---------------- ------------------------------ ------------------------------ ----------
95zcfsw2h01gs          3009034583              432 TABLE ACCESS                   BY INDEX ROWID                        445
95zcfsw2h01gs          3009034583              435 INDEX                          FULL SCAN                             109
95zcfsw2h01gs          3009034583              434 SORT                           JOIN                                   18
95zcfsw2h01gs          3009034583              433 INDEX                          FULL SCAN                              17
95zcfsw2h01gs          3581398598                                                                                         1


Plan hash value: 3009034583
------------------------------------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                       | Name                        | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  | Writes |
------------------------------------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                                |                             |      1 |        |   201K(100)|     43 |00:09:23.57 |      21M|   1234K|  75845 |
|*  1 |  COUNT STOPKEY                                  |                             |      9 |        |            |      8 |00:00:00.01 |      30 |      4 |      0 |
|*  2 |   TABLE ACCESS BY INDEX ROWID BATCHED           | G_PERS_AUTH                 |      9 |      1 |     1   (0)|      8 |00:00:00.01 |      30 |      4 |      0 |
|*  3 |    INDEX RANGE SCAN                             | G_PERS_AUTH_RFPER_TYPEL_IDX |      9 |      2 |     1   (0)|     11 |00:00:00.01 |      19 |      3 |      0 |
|*  4 |   COUNT STOPKEY                                 |                             |      3 |        |            |      0 |00:00:00.01 |      18 |      0 |      0 |
|*  5 |    TABLE ACCESS BY INDEX ROWID BATCHED          | G_PERS_AUTH                 |      3 |      1 |     1   (0)|      0 |00:00:00.01 |      18 |      0 |      0 |
|*  6 |     INDEX RANGE SCAN                            | G_PERS_AUTH_RFPER_TYPEL_IDX |      3 |      2 |     1   (0)|      9 |00:00:00.01 |       9 |      0 |      0 |
|*  7 |    COUNT STOPKEY                                |                             |      2 |        |            |      1 |00:00:00.02 |      17 |     10 |      0 |
|   8 |     NESTED LOOPS                                |                             |      2 |      1 |     2   (0)|      1 |00:00:00.02 |      17 |     10 |      0 |
|   9 |      NESTED LOOPS                               |                             |      2 |      2 |     2   (0)|      3 |00:00:00.01 |      14 |      7 |      0 |
|  10 |       TABLE ACCESS BY INDEX ROWID BATCHED       | EC_USER                     |      2 |      1 |     1   (0)|      2 |00:00:00.01 |       8 |      4 |      0 |
|* 11 |        INDEX RANGE SCAN                         | EC_USER_REFPERSO_IDX        |      2 |      1 |     1   (0)|      2 |00:00:00.01 |       4 |      2 |      0 |
|* 12 |       INDEX RANGE SCAN                          | G_PERS_AUTH_RFPER_TYPEL_IDX |      2 |      2 |     1   (0)|      3 |00:00:00.01 |       6 |      3 |      0 |
|* 13 |      TABLE ACCESS BY INDEX ROWID                | G_PERS_AUTH                 |      3 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |      3 |      0 |
|* 14 |     COUNT STOPKEY                               |                             |      2 |        |            |      1 |00:00:00.01 |      17 |      0 |      0 |
|  15 |      NESTED LOOPS                               |                             |      2 |      1 |     2   (0)|      1 |00:00:00.01 |      17 |      0 |      0 |
|  16 |       NESTED LOOPS                              |                             |      2 |      2 |     2   (0)|      3 |00:00:00.01 |      14 |      0 |      0 |
|  17 |        TABLE ACCESS BY INDEX ROWID BATCHED      | EC_USER                     |      2 |      1 |     1   (0)|      2 |00:00:00.01 |       8 |      0 |      0 |
|* 18 |         INDEX RANGE SCAN                        | EC_USER_REFPERSO_IDX        |      2 |      1 |     1   (0)|      2 |00:00:00.01 |       4 |      0 |      0 |
|* 19 |        INDEX RANGE SCAN                         | G_PERS_AUTH_RFPER_TYPEL_IDX |      2 |      2 |     1   (0)|      3 |00:00:00.01 |       6 |      0 |      0 |
|* 20 |       TABLE ACCESS BY INDEX ROWID               | G_PERS_AUTH                 |      3 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |      0 |      0 |
|* 21 |  COUNT STOPKEY                                  |                             |     40 |        |            |     12 |00:00:00.05 |    7140 |     59 |      0 |
|* 22 |   FILTER                                        |                             |     40 |        |            |     12 |00:00:00.05 |    7140 |     59 |      0 |
|  23 |    VIEW                                         |                             |     40 |     37 |    38   (3)|   2487 |00:00:00.05 |    7132 |     56 |      0 |
|  24 |     SORT ORDER BY                               |                             |     40 |     37 |    38   (3)|   2487 |00:00:00.05 |    7132 |     56 |      0 |
|  25 |      VIEW                                       | V_TDOMAINE                  |     40 |     37 |    37   (0)|   3808 |00:00:00.05 |    7132 |     56 |      0 |
|  26 |       UNION-ALL                                 |                             |     40 |        |            |   3808 |00:00:00.05 |    7132 |     56 |      0 |
|* 27 |        FILTER                                   |                             |     40 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
|* 28 |         TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|* 29 |          INDEX RANGE SCAN                       | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|* 30 |        FILTER                                   |                             |     40 |        |            |   3808 |00:00:00.04 |    7132 |     56 |      0 |
|* 31 |         TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE                   |     40 |      1 |     1   (0)|   3808 |00:00:00.04 |    7132 |     56 |      0 |
|* 32 |          INDEX RANGE SCAN                       | DOM_TYPABREV                |     40 |      1 |     1   (0)|   6206 |00:00:00.01 |     132 |      2 |      0 |
|* 33 |        FILTER                                   |                             |     40 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
|* 34 |         TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|* 35 |          INDEX RANGE SCAN                       | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|* 36 |        FILTER                                   |                             |     40 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
|* 37 |         TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|* 38 |          INDEX RANGE SCAN                       | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|* 39 |        FILTER                                   |                             |     40 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
|* 40 |         TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|* 41 |          INDEX RANGE SCAN                       | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|* 42 |        FILTER                                   |                             |     40 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
|* 43 |         TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|* 44 |          INDEX RANGE SCAN                       | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|* 45 |        FILTER                                   |                             |     40 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
|* 46 |         TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|* 47 |          INDEX RANGE SCAN                       | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|* 48 |        FILTER                                   |                             |     40 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
|* 49 |         TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|* 50 |          INDEX RANGE SCAN                       | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|* 51 |        FILTER                                   |                             |     40 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
|* 52 |         TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|* 53 |          INDEX RANGE SCAN                       | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|* 54 |        FILTER                                   |                             |     40 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
|* 55 |         TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|* 56 |          INDEX RANGE SCAN                       | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|* 57 |        FILTER                                   |                             |     40 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
|* 58 |         TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|* 59 |          INDEX RANGE SCAN                       | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|* 60 |        FILTER                                   |                             |     40 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
|* 61 |         TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|* 62 |          INDEX RANGE SCAN                       | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|* 63 |        FILTER                                   |                             |     40 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
|* 64 |         TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|* 65 |          INDEX RANGE SCAN                       | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|* 66 |        FILTER                                   |                             |     40 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
|* 67 |         TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|* 68 |          INDEX RANGE SCAN                       | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|* 69 |        FILTER                                   |                             |     40 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
|* 70 |         TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|* 71 |          INDEX RANGE SCAN                       | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|* 72 |        FILTER                                   |                             |     40 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
|* 73 |         TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|* 74 |          INDEX RANGE SCAN                       | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|* 75 |        FILTER                                   |                             |     40 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
|* 76 |         TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|* 77 |          INDEX RANGE SCAN                       | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|* 78 |        FILTER                                   |                             |     40 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
|* 79 |         TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|* 80 |          INDEX RANGE SCAN                       | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|* 81 |        FILTER                                   |                             |     40 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
|* 82 |         TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|* 83 |          INDEX RANGE SCAN                       | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|* 84 |        FILTER                                   |                             |     40 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
|* 85 |         TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|* 86 |          INDEX RANGE SCAN                       | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|* 87 |        FILTER                                   |                             |     40 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
|* 88 |         TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|* 89 |          INDEX RANGE SCAN                       | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|* 90 |        FILTER                                   |                             |     40 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
|* 91 |         TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|* 92 |          INDEX RANGE SCAN                       | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|* 93 |        FILTER                                   |                             |     40 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
|* 94 |         TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|* 95 |          INDEX RANGE SCAN                       | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|* 96 |        FILTER                                   |                             |     40 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
|* 97 |         TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|* 98 |          INDEX RANGE SCAN                       | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|* 99 |        FILTER                                   |                             |     40 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
|*100 |         TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*101 |          INDEX RANGE SCAN                       | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*102 |        FILTER                                   |                             |     40 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
|*103 |         TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*104 |          INDEX RANGE SCAN                       | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*105 |        FILTER                                   |                             |     40 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
|*106 |         TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*107 |          INDEX RANGE SCAN                       | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*108 |        FILTER                                   |                             |     40 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
|*109 |         TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*110 |          INDEX RANGE SCAN                       | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*111 |        FILTER                                   |                             |     40 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
|*112 |         TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*113 |          INDEX RANGE SCAN                       | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*114 |        FILTER                                   |                             |     40 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
|*115 |         TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*116 |          INDEX RANGE SCAN                       | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*117 |        FILTER                                   |                             |     40 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
|*118 |         TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*119 |          INDEX RANGE SCAN                       | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*120 |        FILTER                                   |                             |     40 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
|*121 |         TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*122 |          INDEX RANGE SCAN                       | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*123 |        FILTER                                   |                             |     40 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
|*124 |         TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*125 |          INDEX RANGE SCAN                       | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*126 |        FILTER                                   |                             |     40 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
|*127 |         TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*128 |          INDEX RANGE SCAN                       | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*129 |        FILTER                                   |                             |     40 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
|*130 |         TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*131 |          INDEX RANGE SCAN                       | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*132 |        FILTER                                   |                             |     40 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
|*133 |         TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*134 |          INDEX RANGE SCAN                       | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*135 |        FILTER                                   |                             |     40 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
|*136 |         TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*137 |          INDEX RANGE SCAN                       | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*138 |    COUNT STOPKEY                                |                             |      1 |        |            |      0 |00:00:00.01 |       8 |      3 |      0 |
|*139 |     FILTER                                      |                             |      1 |        |            |      0 |00:00:00.01 |       8 |      3 |      0 |
| 140 |      TABLE ACCESS BY INDEX ROWID                | G_ENCAISSEMENT              |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       4 |      0 |      0 |
|*141 |       INDEX UNIQUE SCAN                         | REFENCAISS                  |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |      0 |      0 |
|*142 |      FILTER                                     |                             |      1 |        |            |      1 |00:00:00.01 |       4 |      3 |      0 |
|*143 |       INDEX RANGE SCAN                          | ELE_ELEMTYPE                |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       4 |      3 |      0 |
|*144 |    COUNT STOPKEY                                |                             |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
| 145 |     TABLE ACCESS BY INDEX ROWID                 | G_ELEMFI                    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*146 |      INDEX UNIQUE SCAN                          | EFI_REFELEM                 |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*147 |   COUNT STOPKEY                                 |                             |      8 |        |            |      0 |00:00:00.01 |     346 |      0 |      0 |
| 148 |    VIEW                                         | V_TDOMAINE                  |      8 |     37 |    37   (0)|      0 |00:00:00.01 |     346 |      0 |      0 |
| 149 |     UNION-ALL                                   |                             |      8 |        |            |      0 |00:00:00.01 |     346 |      0 |      0 |
|*150 |      FILTER                                     |                             |      8 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
|*151 |       TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*152 |        INDEX RANGE SCAN                         | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*153 |      FILTER                                     |                             |      8 |        |            |      0 |00:00:00.01 |     346 |      0 |      0 |
|*154 |       TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE                   |      8 |      1 |     1   (0)|      0 |00:00:00.01 |     346 |      0 |      0 |
|*155 |        INDEX RANGE SCAN                         | DOM_TYPABREV                |      8 |      1 |     1   (0)|    284 |00:00:00.01 |      26 |      0 |      0 |
|*156 |      FILTER                                     |                             |      8 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
|*157 |       TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*158 |        INDEX RANGE SCAN                         | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*159 |      FILTER                                     |                             |      8 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
|*160 |       TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*161 |        INDEX RANGE SCAN                         | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*162 |      FILTER                                     |                             |      8 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
|*163 |       TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*164 |        INDEX RANGE SCAN                         | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*165 |      FILTER                                     |                             |      8 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
|*166 |       TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*167 |        INDEX RANGE SCAN                         | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*168 |      FILTER                                     |                             |      8 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
|*169 |       TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*170 |        INDEX RANGE SCAN                         | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*171 |      FILTER                                     |                             |      8 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
|*172 |       TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*173 |        INDEX RANGE SCAN                         | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*174 |      FILTER                                     |                             |      8 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
|*175 |       TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*176 |        INDEX RANGE SCAN                         | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*177 |      FILTER                                     |                             |      8 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
|*178 |       TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*179 |        INDEX RANGE SCAN                         | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*180 |      FILTER                                     |                             |      8 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
|*181 |       TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*182 |        INDEX RANGE SCAN                         | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*183 |      FILTER                                     |                             |      8 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
|*184 |       TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*185 |        INDEX RANGE SCAN                         | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*186 |      FILTER                                     |                             |      8 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
|*187 |       TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*188 |        INDEX RANGE SCAN                         | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*189 |      FILTER                                     |                             |      8 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
|*190 |       TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*191 |        INDEX RANGE SCAN                         | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*192 |      FILTER                                     |                             |      8 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
|*193 |       TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*194 |        INDEX RANGE SCAN                         | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*195 |      FILTER                                     |                             |      8 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
|*196 |       TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*197 |        INDEX RANGE SCAN                         | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*198 |      FILTER                                     |                             |      8 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
|*199 |       TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*200 |        INDEX RANGE SCAN                         | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*201 |      FILTER                                     |                             |      8 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
|*202 |       TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*203 |        INDEX RANGE SCAN                         | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*204 |      FILTER                                     |                             |      8 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
|*205 |       TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*206 |        INDEX RANGE SCAN                         | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*207 |      FILTER                                     |                             |      8 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
|*208 |       TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*209 |        INDEX RANGE SCAN                         | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*210 |      FILTER                                     |                             |      8 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
|*211 |       TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*212 |        INDEX RANGE SCAN                         | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*213 |      FILTER                                     |                             |      8 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
|*214 |       TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*215 |        INDEX RANGE SCAN                         | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*216 |      FILTER                                     |                             |      8 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
|*217 |       TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*218 |        INDEX RANGE SCAN                         | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*219 |      FILTER                                     |                             |      8 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
|*220 |       TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*221 |        INDEX RANGE SCAN                         | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*222 |      FILTER                                     |                             |      8 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
|*223 |       TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*224 |        INDEX RANGE SCAN                         | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*225 |      FILTER                                     |                             |      8 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
|*226 |       TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*227 |        INDEX RANGE SCAN                         | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*228 |      FILTER                                     |                             |      8 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
|*229 |       TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*230 |        INDEX RANGE SCAN                         | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*231 |      FILTER                                     |                             |      8 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
|*232 |       TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*233 |        INDEX RANGE SCAN                         | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*234 |      FILTER                                     |                             |      8 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
|*235 |       TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*236 |        INDEX RANGE SCAN                         | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*237 |      FILTER                                     |                             |      8 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
|*238 |       TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*239 |        INDEX RANGE SCAN                         | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*240 |      FILTER                                     |                             |      8 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
|*241 |       TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*242 |        INDEX RANGE SCAN                         | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*243 |      FILTER                                     |                             |      8 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
|*244 |       TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*245 |        INDEX RANGE SCAN                         | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*246 |      FILTER                                     |                             |      8 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
|*247 |       TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*248 |        INDEX RANGE SCAN                         | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*249 |      FILTER                                     |                             |      8 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
|*250 |       TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*251 |        INDEX RANGE SCAN                         | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*252 |      FILTER                                     |                             |      8 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
|*253 |       TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*254 |        INDEX RANGE SCAN                         | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*255 |      FILTER                                     |                             |      8 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
|*256 |       TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*257 |        INDEX RANGE SCAN                         | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*258 |      FILTER                                     |                             |      8 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
|*259 |       TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*260 |        INDEX RANGE SCAN                         | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 261 |    VIEW                                         | V_TDOMAINE                  |     34 |     37 |    37   (0)|      0 |00:00:00.03 |     102 |     26 |      0 |
| 262 |     UNION-ALL                                   |                             |     34 |        |            |      0 |00:00:00.03 |     102 |     26 |      0 |
|*263 |      FILTER                                     |                             |     34 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
| 264 |       TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*265 |        INDEX RANGE SCAN                         | DOM_TYPVAL                  |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*266 |      FILTER                                     |                             |     34 |        |            |      0 |00:00:00.03 |     102 |     26 |      0 |
| 267 |       TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE                   |     34 |      1 |     1   (0)|      0 |00:00:00.03 |     102 |     26 |      0 |
|*268 |        INDEX RANGE SCAN                         | DOM_TYPVAL                  |     34 |      2 |     1   (0)|      0 |00:00:00.03 |     102 |     26 |      0 |
|*269 |      FILTER                                     |                             |     34 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
| 270 |       TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*271 |        INDEX RANGE SCAN                         | DOM_TYPVAL                  |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*272 |      FILTER                                     |                             |     34 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
| 273 |       TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*274 |        INDEX RANGE SCAN                         | DOM_TYPVAL                  |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*275 |      FILTER                                     |                             |     34 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
| 276 |       TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*277 |        INDEX RANGE SCAN                         | DOM_TYPVAL                  |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*278 |      FILTER                                     |                             |     34 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
| 279 |       TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*280 |        INDEX RANGE SCAN                         | DOM_TYPVAL                  |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*281 |      FILTER                                     |                             |     34 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
| 282 |       TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*283 |        INDEX RANGE SCAN                         | DOM_TYPVAL                  |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*284 |      FILTER                                     |                             |     34 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
| 285 |       TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*286 |        INDEX RANGE SCAN                         | DOM_TYPVAL                  |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*287 |      FILTER                                     |                             |     34 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
| 288 |       TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*289 |        INDEX RANGE SCAN                         | DOM_TYPVAL                  |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*290 |      FILTER                                     |                             |     34 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
| 291 |       TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*292 |        INDEX RANGE SCAN                         | DOM_TYPVAL                  |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*293 |      FILTER                                     |                             |     34 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
| 294 |       TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*295 |        INDEX RANGE SCAN                         | DOM_TYPVAL                  |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*296 |      FILTER                                     |                             |     34 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
| 297 |       TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*298 |        INDEX RANGE SCAN                         | DOM_TYPVAL                  |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*299 |      FILTER                                     |                             |     34 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
| 300 |       TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*301 |        INDEX RANGE SCAN                         | DOM_TYPVAL                  |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*302 |      FILTER                                     |                             |     34 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
| 303 |       TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*304 |        INDEX RANGE SCAN                         | DOM_TYPVAL                  |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*305 |      FILTER                                     |                             |     34 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
| 306 |       TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*307 |        INDEX RANGE SCAN                         | DOM_TYPVAL                  |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*308 |      FILTER                                     |                             |     34 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
| 309 |       TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*310 |        INDEX RANGE SCAN                         | DOM_TYPVAL                  |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*311 |      FILTER                                     |                             |     34 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
| 312 |       TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*313 |        INDEX RANGE SCAN                         | DOM_TYPVAL                  |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*314 |      FILTER                                     |                             |     34 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
| 315 |       TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*316 |        INDEX RANGE SCAN                         | DOM_TYPVAL                  |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*317 |      FILTER                                     |                             |     34 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
| 318 |       TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*319 |        INDEX RANGE SCAN                         | DOM_TYPVAL                  |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*320 |      FILTER                                     |                             |     34 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
| 321 |       TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*322 |        INDEX RANGE SCAN                         | DOM_TYPVAL                  |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*323 |      FILTER                                     |                             |     34 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
| 324 |       TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*325 |        INDEX RANGE SCAN                         | DOM_TYPVAL                  |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*326 |      FILTER                                     |                             |     34 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
| 327 |       TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*328 |        INDEX RANGE SCAN                         | DOM_TYPVAL                  |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*329 |      FILTER                                     |                             |     34 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
| 330 |       TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*331 |        INDEX RANGE SCAN                         | DOM_TYPVAL                  |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*332 |      FILTER                                     |                             |     34 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
| 333 |       TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*334 |        INDEX RANGE SCAN                         | DOM_TYPVAL                  |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*335 |      FILTER                                     |                             |     34 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
| 336 |       TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*337 |        INDEX RANGE SCAN                         | DOM_TYPVAL                  |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*338 |      FILTER                                     |                             |     34 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
| 339 |       TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*340 |        INDEX RANGE SCAN                         | DOM_TYPVAL                  |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*341 |      FILTER                                     |                             |     34 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
| 342 |       TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*343 |        INDEX RANGE SCAN                         | DOM_TYPVAL                  |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*344 |      FILTER                                     |                             |     34 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
| 345 |       TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*346 |        INDEX RANGE SCAN                         | DOM_TYPVAL                  |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*347 |      FILTER                                     |                             |     34 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
| 348 |       TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*349 |        INDEX RANGE SCAN                         | DOM_TYPVAL                  |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*350 |      FILTER                                     |                             |     34 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
| 351 |       TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*352 |        INDEX RANGE SCAN                         | DOM_TYPVAL                  |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*353 |      FILTER                                     |                             |     34 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
| 354 |       TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*355 |        INDEX RANGE SCAN                         | DOM_TYPVAL                  |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*356 |      FILTER                                     |                             |     34 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
| 357 |       TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*358 |        INDEX RANGE SCAN                         | DOM_TYPVAL                  |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*359 |      FILTER                                     |                             |     34 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
| 360 |       TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*361 |        INDEX RANGE SCAN                         | DOM_TYPVAL                  |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*362 |      FILTER                                     |                             |     34 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
| 363 |       TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*364 |        INDEX RANGE SCAN                         | DOM_TYPVAL                  |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*365 |      FILTER                                     |                             |     34 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
| 366 |       TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*367 |        INDEX RANGE SCAN                         | DOM_TYPVAL                  |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*368 |      FILTER                                     |                             |     34 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
| 369 |       TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*370 |        INDEX RANGE SCAN                         | DOM_TYPVAL                  |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*371 |      FILTER                                     |                             |     34 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
| 372 |       TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*373 |        INDEX RANGE SCAN                         | DOM_TYPVAL                  |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*374 |  COUNT STOPKEY                                  |                             |      7 |        |            |      0 |00:00:00.01 |      12 |      5 |      0 |
| 375 |   NESTED LOOPS                                  |                             |      7 |      1 |     2   (0)|      0 |00:00:00.01 |      12 |      5 |      0 |
| 376 |    NESTED LOOPS                                 |                             |      7 |      1 |     2   (0)|      0 |00:00:00.01 |      12 |      5 |      0 |
| 377 |     TABLE ACCESS BY INDEX ROWID BATCHED         | G_PERSONNEL                 |      7 |      1 |     1   (0)|      0 |00:00:00.01 |      12 |      5 |      0 |
|*378 |      INDEX RANGE SCAN                           | GPERSLOGIN                  |      7 |      1 |     1   (0)|      0 |00:00:00.01 |      12 |      5 |      0 |
|*379 |     INDEX UNIQUE SCAN                           | IND_REFINDIV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 380 |    TABLE ACCESS BY INDEX ROWID                  | G_INDIVIDU                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*381 |  COUNT STOPKEY                                  |                             |      7 |        |            |      7 |00:00:00.01 |      28 |      0 |      0 |
| 382 |   TABLE ACCESS BY INDEX ROWID                   | G_ELEMFI                    |      7 |      1 |     1   (0)|      7 |00:00:00.01 |      28 |      0 |      0 |
|*383 |    INDEX UNIQUE SCAN                            | EFI_REFELEM                 |      7 |      1 |     1   (0)|      7 |00:00:00.01 |      21 |      0 |      0 |
|*384 |  COUNT STOPKEY                                  |                             |      4 |        |            |      3 |00:00:00.01 |      28 |      7 |      0 |
| 385 |   NESTED LOOPS                                  |                             |      4 |      1 |     2   (0)|      3 |00:00:00.01 |      28 |      7 |      0 |
|*386 |    TABLE ACCESS BY INDEX ROWID                  | T_ENTMAIL                   |      4 |      1 |     1   (0)|      4 |00:00:00.01 |      16 |      0 |      0 |
|*387 |     INDEX UNIQUE SCAN                           | PK_MAIL                     |      4 |      1 |     1   (0)|      4 |00:00:00.01 |      12 |      0 |      0 |
|*388 |    INDEX RANGE SCAN                             | MAILREFM                    |      4 |      1 |     1   (0)|      3 |00:00:00.01 |      12 |      7 |      0 |
|*389 |   COUNT STOPKEY                                 |                             |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
| 390 |    NESTED LOOPS                                 |                             |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*391 |     TABLE ACCESS BY INDEX ROWID                 | T_ENTMAIL                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*392 |      INDEX UNIQUE SCAN                          | PK_MAIL                     |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*393 |     INDEX RANGE SCAN                            | MAILREFM                    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*394 |    COUNT STOPKEY                                |                             |      1 |        |            |      1 |00:00:00.01 |       4 |      0 |      0 |
|*395 |     TABLE ACCESS BY INDEX ROWID                 | G_INFORMATION               |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       4 |      0 |      0 |
|*396 |      INDEX UNIQUE SCAN                          | REF_INFORMATION             |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |      0 |      0 |
|*397 |     COUNT STOPKEY                               |                             |      7 |        |            |      0 |00:00:00.01 |      21 |      2 |      0 |
|*398 |      TABLE ACCESS BY INDEX ROWID BATCHED        | G_PIECE                     |      7 |      1 |     1   (0)|      0 |00:00:00.01 |      21 |      2 |      0 |
|*399 |       INDEX RANGE SCAN                          | PIECE_REFEXT_IDX            |      7 |      1 |     1   (0)|      0 |00:00:00.01 |      21 |      2 |      0 |
|*400 |      COUNT STOPKEY                              |                             |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
|*401 |       TABLE ACCESS BY INDEX ROWID BATCHED       | G_PIECE                     |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*402 |        INDEX RANGE SCAN                         | PIECE_REFEXT_IDX            |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 403 |         TABLE ACCESS BY INDEX ROWID             | F_ENTENR                    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*404 |          INDEX UNIQUE SCAN                      | PK_F_ENTENR                 |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*405 |       COUNT STOPKEY                             |                             |     31 |        |            |      1 |00:00:00.02 |     158 |     18 |      0 |
| 406 |        CONCATENATION                            |                             |     31 |        |            |      1 |00:00:00.02 |     158 |     18 |      0 |
|*407 |         FILTER                                  |                             |     31 |        |            |      1 |00:00:00.01 |      64 |      5 |      0 |
|*408 |          TABLE ACCESS BY INDEX ROWID BATCHED    | G_PIECE                     |     31 |      1 |     1   (0)|      1 |00:00:00.01 |      64 |      5 |      0 |
|*409 |           INDEX RANGE SCAN                      | PIE_REFPIECE                |     31 |      1 |     1   (0)|      2 |00:00:00.01 |      60 |      5 |      0 |
|*410 |         FILTER                                  |                             |     30 |        |            |      0 |00:00:00.02 |      94 |     13 |      0 |
|*411 |          TABLE ACCESS BY INDEX ROWID BATCHED    | G_PIECE                     |     30 |      1 |     1   (0)|      0 |00:00:00.02 |      94 |     13 |      0 |
|*412 |           INDEX RANGE SCAN                      | PIECE_REFEXT_IDX            |     30 |      1 |     1   (0)|      0 |00:00:00.02 |      94 |     13 |      0 |
| 413 |  SORT ORDER BY                                  |                             |      1 |      1 |   201K  (1)|     43 |00:09:23.57 |      21M|   1234K|  75845 |
| 414 |   VIEW                                          |                             |      1 |      1 |   201K  (1)|     43 |00:09:23.57 |      21M|   1234K|  75845 |
| 415 |    HASH UNIQUE                                  |                             |      1 |      1 |   201K  (1)|     43 |00:09:23.57 |      21M|   1234K|  75845 |
|*416 |     FILTER                                      |                             |      1 |        |            |     49 |00:09:23.41 |      21M|   1234K|  75845 |
|*417 |      HASH JOIN RIGHT ANTI                       |                             |      1 |    193 |   197K  (1)|     66 |00:09:23.27 |      21M|   1234K|  75845 |
|*418 |       TABLE ACCESS BY INDEX ROWID BATCHED       | G_PERS_AUTH                 |      1 |      5 |     1   (0)|      3 |00:00:00.02 |      19 |     16 |      0 |
|*419 |        INDEX RANGE SCAN                         | G_PERS_AUTH_RFPER_TYPEL_IDX |      1 |     45 |     1   (0)|     31 |00:00:00.01 |       3 |      3 |      0 |
|*420 |       HASH JOIN                                 |                             |      1 |    193 |   197K  (1)|     81 |00:09:23.25 |      21M|   1234K|  75845 |
|*421 |        TABLE ACCESS BY INDEX ROWID BATCHED      | G_PERS_AUTH                 |      1 |      9 |     1   (0)|     20 |00:00:00.01 |      20 |      0 |      0 |
|*422 |         INDEX RANGE SCAN                        | G_PERS_AUTH_RFPER_TYPEL_IDX |      1 |     45 |     1   (0)|     31 |00:00:00.01 |       3 |      0 |      0 |
|*423 |        FILTER                                   |                             |      1 |        |            |     67 |00:09:23.25 |      21M|   1234K|  75845 |
|*424 |         HASH JOIN OUTER                         |                             |      1 |    687 |   197K  (1)|     67 |00:09:23.25 |      21M|   1234K|  75845 |
|*425 |          HASH JOIN OUTER                        |                             |      1 |     19 |   197K  (1)|     67 |00:09:23.21 |      21M|   1234K|  75845 |
| 426 |           NESTED LOOPS OUTER                    |                             |      1 |      1 |   197K  (1)|     67 |00:09:23.20 |      21M|   1234K|  75845 |
|*427 |            HASH JOIN ANTI                       |                             |      1 |      1 |   197K  (1)|     67 |00:09:23.19 |      21M|   1234K|  75845 |
| 428 |             TABLE ACCESS BY INDEX ROWID BATCHED | T_ELEMENTS                  |      1 |     51 |     1   (0)|     67 |00:00:00.03 |      56 |     51 |      0 |
|*429 |              INDEX RANGE SCAN                   | ELE_ELEMDOSS                |      1 |     51 |     1   (0)|     67 |00:00:00.01 |       4 |      2 |      0 |
| 430 |             VIEW                                | VW_SQ_1                     |      1 |  94460 |   197K  (1)|   5156 |00:09:23.15 |      21M|   1233K|  75845 |
| 431 |              MERGE JOIN                         |                             |      1 |  94460 |   197K  (1)|   5156 |00:09:23.15 |      21M|   1233K|  75845 |
|*432 |               TABLE ACCESS BY INDEX ROWID       | G_PIECE                     |      1 |  90101 | 47658   (1)|   5156 |00:07:02.29 |      21M|    937K|      0 |
| 433 |                INDEX FULL SCAN                  | PIE_REFPIECE                |      1 |   6226K|   183   (1)|   6227K|00:00:09.41 |   18158 |  18026 |      0 |
|*434 |               SORT JOIN                         |                             |   5156 |     38M|   149K  (1)|   5156 |00:02:20.85 |     235K|    295K|  75845 |
| 435 |                INDEX FULL SCAN                  | ELE_ELEMTYPE                |      1 |     38M|  2244   (1)|     38M|00:02:07.53 |     235K|    228K|      0 |
|*436 |            TABLE ACCESS BY INDEX ROWID          | G_ELEMFI                    |     67 |      1 |     1   (0)|      7 |00:00:00.01 |     136 |     11 |      0 |
|*437 |             INDEX UNIQUE SCAN                   | EFI_REFELEM                 |     67 |      1 |     1   (0)|      7 |00:00:00.01 |     129 |      7 |      0 |
| 438 |           VIEW                                  | V_TDOMAINE                  |      1 |   2479 |    37   (0)|     23 |00:00:00.01 |      30 |     22 |      0 |
| 439 |            UNION-ALL                            |                             |      1 |        |            |     23 |00:00:00.01 |      30 |     22 |      0 |
|*440 |             FILTER                              |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
|*441 |              TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE                   |      0 |     67 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*442 |               INDEX RANGE SCAN                  | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*443 |             FILTER                              |                             |      1 |        |            |     23 |00:00:00.01 |      30 |     22 |      0 |
|*444 |              TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE                   |      1 |     67 |     1   (0)|     23 |00:00:00.01 |      30 |     22 |      0 |
|*445 |               INDEX RANGE SCAN                  | V_DOMAINE_TYPE_CODE_IDX     |      1 |     77 |     1   (0)|     25 |00:00:00.01 |       4 |      3 |      0 |
|*446 |             FILTER                              |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
|*447 |              TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE                   |      0 |     67 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*448 |               INDEX RANGE SCAN                  | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*449 |             FILTER                              |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
|*450 |              TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE                   |      0 |     67 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*451 |               INDEX RANGE SCAN                  | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*452 |             FILTER                              |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
|*453 |              TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE                   |      0 |     67 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*454 |               INDEX RANGE SCAN                  | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*455 |             FILTER                              |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
|*456 |              TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE                   |      0 |     67 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*457 |               INDEX RANGE SCAN                  | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*458 |             FILTER                              |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
|*459 |              TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE                   |      0 |     67 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*460 |               INDEX RANGE SCAN                  | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*461 |             FILTER                              |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
|*462 |              TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE                   |      0 |     67 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*463 |               INDEX RANGE SCAN                  | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*464 |             FILTER                              |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
|*465 |              TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE                   |      0 |     67 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*466 |               INDEX RANGE SCAN                  | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*467 |             FILTER                              |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
|*468 |              TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE                   |      0 |     67 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*469 |               INDEX RANGE SCAN                  | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*470 |             FILTER                              |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
|*471 |              TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE                   |      0 |     67 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*472 |               INDEX RANGE SCAN                  | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*473 |             FILTER                              |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
|*474 |              TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE                   |      0 |     67 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*475 |               INDEX RANGE SCAN                  | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*476 |             FILTER                              |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
|*477 |              TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE                   |      0 |     67 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*478 |               INDEX RANGE SCAN                  | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*479 |             FILTER                              |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
|*480 |              TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE                   |      0 |     67 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*481 |               INDEX RANGE SCAN                  | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*482 |             FILTER                              |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
|*483 |              TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE                   |      0 |     67 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*484 |               INDEX RANGE SCAN                  | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*485 |             FILTER                              |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
|*486 |              TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE                   |      0 |     67 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*487 |               INDEX RANGE SCAN                  | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*488 |             FILTER                              |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
|*489 |              TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE                   |      0 |     67 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*490 |               INDEX RANGE SCAN                  | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*491 |             FILTER                              |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
|*492 |              TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE                   |      0 |     67 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*493 |               INDEX RANGE SCAN                  | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*494 |             FILTER                              |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
|*495 |              TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE                   |      0 |     67 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*496 |               INDEX RANGE SCAN                  | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*497 |             FILTER                              |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
|*498 |              TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE                   |      0 |     67 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*499 |               INDEX RANGE SCAN                  | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*500 |             FILTER                              |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
|*501 |              TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE                   |      0 |     67 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*502 |               INDEX RANGE SCAN                  | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*503 |             FILTER                              |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
|*504 |              TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE                   |      0 |     67 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*505 |               INDEX RANGE SCAN                  | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*506 |             FILTER                              |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
|*507 |              TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE                   |      0 |     67 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*508 |               INDEX RANGE SCAN                  | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*509 |             FILTER                              |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
|*510 |              TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE                   |      0 |     67 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*511 |               INDEX RANGE SCAN                  | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*512 |             FILTER                              |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
|*513 |              TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE                   |      0 |     67 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*514 |               INDEX RANGE SCAN                  | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*515 |             FILTER                              |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
|*516 |              TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE                   |      0 |     67 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*517 |               INDEX RANGE SCAN                  | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*518 |             FILTER                              |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
|*519 |              TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE                   |      0 |     67 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*520 |               INDEX RANGE SCAN                  | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*521 |             FILTER                              |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
|*522 |              TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE                   |      0 |     67 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*523 |               INDEX RANGE SCAN                  | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*524 |             FILTER                              |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
|*525 |              TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE                   |      0 |     67 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*526 |               INDEX RANGE SCAN                  | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*527 |             FILTER                              |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
|*528 |              TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE                   |      0 |     67 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*529 |               INDEX RANGE SCAN                  | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*530 |             FILTER                              |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
|*531 |              TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE                   |      0 |     67 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*532 |               INDEX RANGE SCAN                  | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*533 |             FILTER                              |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
|*534 |              TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE                   |      0 |     67 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*535 |               INDEX RANGE SCAN                  | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*536 |             FILTER                              |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
|*537 |              TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE                   |      0 |     67 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*538 |               INDEX RANGE SCAN                  | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*539 |             FILTER                              |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
|*540 |              TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE                   |      0 |     67 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*541 |               INDEX RANGE SCAN                  | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*542 |             FILTER                              |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
|*543 |              TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE                   |      0 |     67 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*544 |               INDEX RANGE SCAN                  | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*545 |             FILTER                              |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
|*546 |              TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE                   |      0 |     67 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*547 |               INDEX RANGE SCAN                  | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*548 |             FILTER                              |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
|*549 |              TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE                   |      0 |     67 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*550 |               INDEX RANGE SCAN                  | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 551 |          VIEW                                   | V_TDOMAINE                  |      1 |   2849 |    37   (0)|    563 |00:00:00.04 |     127 |    116 |      0 |
| 552 |           UNION-ALL                             |                             |      1 |        |            |    563 |00:00:00.04 |     127 |    116 |      0 |
|*553 |            FILTER                               |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
| 554 |             TABLE ACCESS BY INDEX ROWID BATCHED | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*555 |              INDEX RANGE SCAN                   | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*556 |            FILTER                               |                             |      1 |        |            |    563 |00:00:00.04 |     127 |    116 |      0 |
| 557 |             TABLE ACCESS BY INDEX ROWID BATCHED | V_DOMAINE                   |      1 |     77 |     1   (0)|    563 |00:00:00.04 |     127 |    116 |      0 |
|*558 |              INDEX RANGE SCAN                   | V_DOMAINE_TYPE_CODE_IDX     |      1 |     77 |     1   (0)|    563 |00:00:00.01 |       9 |      7 |      0 |
|*559 |            FILTER                               |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
| 560 |             TABLE ACCESS BY INDEX ROWID BATCHED | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*561 |              INDEX RANGE SCAN                   | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*562 |            FILTER                               |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
| 563 |             TABLE ACCESS BY INDEX ROWID BATCHED | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*564 |              INDEX RANGE SCAN                   | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*565 |            FILTER                               |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
| 566 |             TABLE ACCESS BY INDEX ROWID BATCHED | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*567 |              INDEX RANGE SCAN                   | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*568 |            FILTER                               |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
| 569 |             TABLE ACCESS BY INDEX ROWID BATCHED | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*570 |              INDEX RANGE SCAN                   | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*571 |            FILTER                               |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
| 572 |             TABLE ACCESS BY INDEX ROWID BATCHED | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*573 |              INDEX RANGE SCAN                   | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*574 |            FILTER                               |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
| 575 |             TABLE ACCESS BY INDEX ROWID BATCHED | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*576 |              INDEX RANGE SCAN                   | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*577 |            FILTER                               |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
| 578 |             TABLE ACCESS BY INDEX ROWID BATCHED | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*579 |              INDEX RANGE SCAN                   | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*580 |            FILTER                               |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
| 581 |             TABLE ACCESS BY INDEX ROWID BATCHED | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*582 |              INDEX RANGE SCAN                   | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*583 |            FILTER                               |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
| 584 |             TABLE ACCESS BY INDEX ROWID BATCHED | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*585 |              INDEX RANGE SCAN                   | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*586 |            FILTER                               |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
| 587 |             TABLE ACCESS BY INDEX ROWID BATCHED | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*588 |              INDEX RANGE SCAN                   | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*589 |            FILTER                               |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
| 590 |             TABLE ACCESS BY INDEX ROWID BATCHED | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*591 |              INDEX RANGE SCAN                   | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*592 |            FILTER                               |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
| 593 |             TABLE ACCESS BY INDEX ROWID BATCHED | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*594 |              INDEX RANGE SCAN                   | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*595 |            FILTER                               |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
| 596 |             TABLE ACCESS BY INDEX ROWID BATCHED | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*597 |              INDEX RANGE SCAN                   | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*598 |            FILTER                               |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
| 599 |             TABLE ACCESS BY INDEX ROWID BATCHED | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*600 |              INDEX RANGE SCAN                   | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*601 |            FILTER                               |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
| 602 |             TABLE ACCESS BY INDEX ROWID BATCHED | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*603 |              INDEX RANGE SCAN                   | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*604 |            FILTER                               |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
| 605 |             TABLE ACCESS BY INDEX ROWID BATCHED | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*606 |              INDEX RANGE SCAN                   | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*607 |            FILTER                               |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
| 608 |             TABLE ACCESS BY INDEX ROWID BATCHED | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*609 |              INDEX RANGE SCAN                   | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*610 |            FILTER                               |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
| 611 |             TABLE ACCESS BY INDEX ROWID BATCHED | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*612 |              INDEX RANGE SCAN                   | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*613 |            FILTER                               |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
| 614 |             TABLE ACCESS BY INDEX ROWID BATCHED | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*615 |              INDEX RANGE SCAN                   | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*616 |            FILTER                               |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
| 617 |             TABLE ACCESS BY INDEX ROWID BATCHED | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*618 |              INDEX RANGE SCAN                   | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*619 |            FILTER                               |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
| 620 |             TABLE ACCESS BY INDEX ROWID BATCHED | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*621 |              INDEX RANGE SCAN                   | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*622 |            FILTER                               |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
| 623 |             TABLE ACCESS BY INDEX ROWID BATCHED | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*624 |              INDEX RANGE SCAN                   | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*625 |            FILTER                               |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
| 626 |             TABLE ACCESS BY INDEX ROWID BATCHED | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*627 |              INDEX RANGE SCAN                   | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*628 |            FILTER                               |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
| 629 |             TABLE ACCESS BY INDEX ROWID BATCHED | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*630 |              INDEX RANGE SCAN                   | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*631 |            FILTER                               |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
| 632 |             TABLE ACCESS BY INDEX ROWID BATCHED | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*633 |              INDEX RANGE SCAN                   | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*634 |            FILTER                               |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
| 635 |             TABLE ACCESS BY INDEX ROWID BATCHED | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*636 |              INDEX RANGE SCAN                   | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*637 |            FILTER                               |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
| 638 |             TABLE ACCESS BY INDEX ROWID BATCHED | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*639 |              INDEX RANGE SCAN                   | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*640 |            FILTER                               |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
| 641 |             TABLE ACCESS BY INDEX ROWID BATCHED | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*642 |              INDEX RANGE SCAN                   | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*643 |            FILTER                               |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
| 644 |             TABLE ACCESS BY INDEX ROWID BATCHED | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*645 |              INDEX RANGE SCAN                   | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*646 |            FILTER                               |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
| 647 |             TABLE ACCESS BY INDEX ROWID BATCHED | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*648 |              INDEX RANGE SCAN                   | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*649 |            FILTER                               |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
| 650 |             TABLE ACCESS BY INDEX ROWID BATCHED | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*651 |              INDEX RANGE SCAN                   | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*652 |            FILTER                               |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
| 653 |             TABLE ACCESS BY INDEX ROWID BATCHED | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*654 |              INDEX RANGE SCAN                   | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*655 |            FILTER                               |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
| 656 |             TABLE ACCESS BY INDEX ROWID BATCHED | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*657 |              INDEX RANGE SCAN                   | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*658 |            FILTER                               |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
| 659 |             TABLE ACCESS BY INDEX ROWID BATCHED | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*660 |              INDEX RANGE SCAN                   | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*661 |            FILTER                               |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
| 662 |             TABLE ACCESS BY INDEX ROWID BATCHED | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*663 |              INDEX RANGE SCAN                   | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*664 |      FILTER                                     |                             |     51 |        |            |     12 |00:00:00.02 |    6633 |      9 |      0 |
| 665 |       VIEW                                      | V_TDOMAINE                  |     51 |     37 |    37   (0)|   3572 |00:00:00.02 |    6629 |      5 |      0 |
| 666 |        UNION-ALL                                |                             |     51 |        |            |   3572 |00:00:00.02 |    6629 |      5 |      0 |
|*667 |         FILTER                                  |                             |     51 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
|*668 |          TABLE ACCESS BY INDEX ROWID BATCHED    | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*669 |           INDEX RANGE SCAN                      | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*670 |         FILTER                                  |                             |     51 |        |            |   3572 |00:00:00.01 |    6629 |      5 |      0 |
|*671 |          TABLE ACCESS BY INDEX ROWID BATCHED    | V_DOMAINE                   |     51 |      1 |     1   (0)|   3572 |00:00:00.01 |    6629 |      5 |      0 |
|*672 |           INDEX RANGE SCAN                      | DOM_TYPABREV                |     51 |      1 |     1   (0)|   5001 |00:00:00.01 |     161 |      1 |      0 |
|*673 |         FILTER                                  |                             |     39 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
|*674 |          TABLE ACCESS BY INDEX ROWID BATCHED    | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*675 |           INDEX RANGE SCAN                      | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*676 |         FILTER                                  |                             |     39 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
|*677 |          TABLE ACCESS BY INDEX ROWID BATCHED    | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*678 |           INDEX RANGE SCAN                      | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*679 |         FILTER                                  |                             |     39 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
|*680 |          TABLE ACCESS BY INDEX ROWID BATCHED    | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*681 |           INDEX RANGE SCAN                      | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*682 |         FILTER                                  |                             |     39 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
|*683 |          TABLE ACCESS BY INDEX ROWID BATCHED    | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*684 |           INDEX RANGE SCAN                      | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*685 |         FILTER                                  |                             |     39 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
|*686 |          TABLE ACCESS BY INDEX ROWID BATCHED    | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*687 |           INDEX RANGE SCAN                      | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*688 |         FILTER                                  |                             |     39 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
|*689 |          TABLE ACCESS BY INDEX ROWID BATCHED    | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*690 |           INDEX RANGE SCAN                      | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*691 |         FILTER                                  |                             |     39 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
|*692 |          TABLE ACCESS BY INDEX ROWID BATCHED    | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*693 |           INDEX RANGE SCAN                      | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*694 |         FILTER                                  |                             |     39 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
|*695 |          TABLE ACCESS BY INDEX ROWID BATCHED    | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*696 |           INDEX RANGE SCAN                      | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*697 |         FILTER                                  |                             |     39 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
|*698 |          TABLE ACCESS BY INDEX ROWID BATCHED    | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*699 |           INDEX RANGE SCAN                      | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*700 |         FILTER                                  |                             |     39 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
|*701 |          TABLE ACCESS BY INDEX ROWID BATCHED    | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*702 |           INDEX RANGE SCAN                      | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*703 |         FILTER                                  |                             |     39 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
|*704 |          TABLE ACCESS BY INDEX ROWID BATCHED    | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*705 |           INDEX RANGE SCAN                      | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*706 |         FILTER                                  |                             |     39 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
|*707 |          TABLE ACCESS BY INDEX ROWID BATCHED    | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*708 |           INDEX RANGE SCAN                      | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*709 |         FILTER                                  |                             |     39 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
|*710 |          TABLE ACCESS BY INDEX ROWID BATCHED    | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*711 |           INDEX RANGE SCAN                      | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*712 |         FILTER                                  |                             |     39 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
|*713 |          TABLE ACCESS BY INDEX ROWID BATCHED    | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*714 |           INDEX RANGE SCAN                      | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*715 |         FILTER                                  |                             |     39 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
|*716 |          TABLE ACCESS BY INDEX ROWID BATCHED    | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*717 |           INDEX RANGE SCAN                      | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*718 |         FILTER                                  |                             |     39 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
|*719 |          TABLE ACCESS BY INDEX ROWID BATCHED    | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*720 |           INDEX RANGE SCAN                      | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*721 |         FILTER                                  |                             |     39 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
|*722 |          TABLE ACCESS BY INDEX ROWID BATCHED    | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*723 |           INDEX RANGE SCAN                      | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*724 |         FILTER                                  |                             |     39 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
|*725 |          TABLE ACCESS BY INDEX ROWID BATCHED    | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*726 |           INDEX RANGE SCAN                      | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*727 |         FILTER                                  |                             |     39 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
|*728 |          TABLE ACCESS BY INDEX ROWID BATCHED    | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*729 |           INDEX RANGE SCAN                      | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*730 |         FILTER                                  |                             |     39 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
|*731 |          TABLE ACCESS BY INDEX ROWID BATCHED    | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*732 |           INDEX RANGE SCAN                      | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*733 |         FILTER                                  |                             |     39 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
|*734 |          TABLE ACCESS BY INDEX ROWID BATCHED    | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*735 |           INDEX RANGE SCAN                      | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*736 |         FILTER                                  |                             |     39 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
|*737 |          TABLE ACCESS BY INDEX ROWID BATCHED    | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*738 |           INDEX RANGE SCAN                      | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*739 |         FILTER                                  |                             |     39 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
|*740 |          TABLE ACCESS BY INDEX ROWID BATCHED    | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*741 |           INDEX RANGE SCAN                      | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*742 |         FILTER                                  |                             |     39 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
|*743 |          TABLE ACCESS BY INDEX ROWID BATCHED    | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*744 |           INDEX RANGE SCAN                      | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*745 |         FILTER                                  |                             |     39 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
|*746 |          TABLE ACCESS BY INDEX ROWID BATCHED    | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*747 |           INDEX RANGE SCAN                      | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*748 |         FILTER                                  |                             |     39 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
|*749 |          TABLE ACCESS BY INDEX ROWID BATCHED    | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*750 |           INDEX RANGE SCAN                      | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*751 |         FILTER                                  |                             |     39 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
|*752 |          TABLE ACCESS BY INDEX ROWID BATCHED    | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*753 |           INDEX RANGE SCAN                      | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*754 |         FILTER                                  |                             |     39 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
|*755 |          TABLE ACCESS BY INDEX ROWID BATCHED    | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*756 |           INDEX RANGE SCAN                      | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*757 |         FILTER                                  |                             |     39 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
|*758 |          TABLE ACCESS BY INDEX ROWID BATCHED    | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*759 |           INDEX RANGE SCAN                      | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*760 |         FILTER                                  |                             |     39 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
|*761 |          TABLE ACCESS BY INDEX ROWID BATCHED    | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*762 |           INDEX RANGE SCAN                      | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*763 |         FILTER                                  |                             |     39 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
|*764 |          TABLE ACCESS BY INDEX ROWID BATCHED    | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*765 |           INDEX RANGE SCAN                      | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*766 |         FILTER                                  |                             |     39 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
|*767 |          TABLE ACCESS BY INDEX ROWID BATCHED    | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*768 |           INDEX RANGE SCAN                      | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*769 |         FILTER                                  |                             |     39 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
|*770 |          TABLE ACCESS BY INDEX ROWID BATCHED    | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*771 |           INDEX RANGE SCAN                      | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*772 |         FILTER                                  |                             |     39 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
|*773 |          TABLE ACCESS BY INDEX ROWID BATCHED    | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*774 |           INDEX RANGE SCAN                      | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*775 |         FILTER                                  |                             |     39 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
|*776 |          TABLE ACCESS BY INDEX ROWID BATCHED    | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*777 |           INDEX RANGE SCAN                      | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*778 |       COUNT STOPKEY                             |                             |      1 |        |            |      1 |00:00:00.01 |       4 |      4 |      0 |
| 779 |        TABLE ACCESS BY INDEX ROWID              | G_ENCAISSEMENT              |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       4 |      4 |      0 |
|*780 |         INDEX UNIQUE SCAN                       | REFENCAISS                  |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |      3 |      0 |
|*781 |       COUNT STOPKEY                             |                             |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
| 782 |        TABLE ACCESS BY INDEX ROWID              | G_ELEMFI                    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*783 |         INDEX UNIQUE SCAN                       | EFI_REFELEM                 |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*784 |      TABLE ACCESS BY INDEX ROWID BATCHED        | V_EXTR_DOM                  |      1 |      1 |     1   (0)|      0 |00:00:00.02 |      21 |     21 |      0 |
|*785 |       INDEX RANGE SCAN                          | TYPEABREV_IND2              |      1 |      7 |     1   (0)|    105 |00:00:00.01 |       2 |      2 |      0 |
|*786 |      TABLE ACCESS BY INDEX ROWID BATCHED        | G_PERS_AUTH                 |      8 |      1 |     1   (0)|      0 |00:00:00.01 |      34 |      9 |      0 |
|*787 |       INDEX RANGE SCAN                          | G_PERS_AUTH_RFPER_TYPEL_IDX |      8 |      2 |     1   (0)|     19 |00:00:00.01 |      18 |      0 |      0 |
|*788 |      TABLE ACCESS BY INDEX ROWID BATCHED        | G_PERS_AUTH                 |      2 |      1 |     1   (0)|      1 |00:00:00.01 |      11 |      0 |      0 |
|*789 |       INDEX RANGE SCAN                          | G_PERS_AUTH_RFPER_TYPEL_IDX |      2 |      2 |     1   (0)|      5 |00:00:00.01 |       6 |      0 |      0 |
| 790 |      FAST DUAL                                  |                             |      2 |      1 |     2   (0)|      2 |00:00:00.01 |       0 |      0 |      0 |
|*791 |      COUNT STOPKEY                              |                             |      1 |        |            |      1 |00:00:00.02 |      42 |     31 |      0 |
|*792 |       TABLE ACCESS BY INDEX ROWID BATCHED       | V_EXTR_DOM                  |      1 |      1 |     1   (0)|      1 |00:00:00.02 |      42 |     31 |      0 |
|*793 |        INDEX RANGE SCAN                         | TYPEABREV_IND2              |      1 |      7 |     1   (0)|    909 |00:00:00.01 |       5 |      3 |      0 |
|*794 |       FILTER                                    |                             |      2 |        |            |      1 |00:00:00.01 |      17 |      5 |      0 |
| 795 |        TABLE ACCESS BY INDEX ROWID              | G_INFORMATION               |      2 |      1 |     1   (0)|      2 |00:00:00.01 |       8 |      3 |      0 |
|*796 |         INDEX UNIQUE SCAN                       | REF_INFORMATION             |      2 |      1 |     1   (0)|      2 |00:00:00.01 |       6 |      1 |      0 |
|*797 |        TABLE ACCESS BY INDEX ROWID BATCHED      | G_PERSONNEL                 |      2 |      1 |     1   (0)|      1 |00:00:00.01 |       6 |      2 |      0 |
|*798 |         INDEX RANGE SCAN                        | PK_G_PERSONNEL              |      2 |      1 |     1   (0)|      2 |00:00:00.01 |       4 |      1 |      0 |
|*799 |        TABLE ACCESS BY INDEX ROWID BATCHED      | G_PERSONNEL                 |      1 |      1 |     1   (0)|      0 |00:00:00.01 |       3 |      0 |      0 |
|*800 |         INDEX RANGE SCAN                        | PK_G_PERSONNEL              |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       2 |      0 |      0 |
| 801 |      FAST DUAL                                  |                             |      4 |      1 |     2   (0)|      4 |00:00:00.01 |       0 |      0 |      0 |
|*802 |      COUNT STOPKEY                              |                             |      1 |        |            |      0 |00:00:00.01 |       2 |      0 |      0 |
|*803 |       TABLE ACCESS BY INDEX ROWID BATCHED       | V_EXTR_DOM                  |      1 |      1 |     1   (0)|      0 |00:00:00.01 |       2 |      0 |      0 |
|*804 |        INDEX RANGE SCAN                         | TYPEABREV_IND2              |      1 |      7 |     1   (0)|      0 |00:00:00.01 |       2 |      0 |      0 |
|*805 |       FILTER                                    |                             |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
|*806 |        FILTER                                   |                             |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
| 807 |         NESTED LOOPS                            |                             |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 808 |          TABLE ACCESS BY INDEX ROWID            | T_ENTMAIL                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*809 |           INDEX UNIQUE SCAN                     | PK_MAIL                     |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 810 |          TABLE ACCESS BY INDEX ROWID BATCHED    | G_PERSONNEL                 |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*811 |           INDEX RANGE SCAN                      | PK_G_PERSONNEL              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 812 |        NESTED LOOPS                             |                             |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 813 |         NESTED LOOPS                            |                             |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 814 |          NESTED LOOPS                           |                             |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*815 |           INDEX RANGE SCAN                      | TYPEABREV                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*816 |           TABLE ACCESS BY INDEX ROWID BATCHED   | G_TELEPHONE                 |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*817 |            INDEX RANGE SCAN                     | IDX_G_TEL_INDIV             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*818 |          INDEX RANGE SCAN                       | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*819 |         TABLE ACCESS BY INDEX ROWID             | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 820 |        NESTED LOOPS                             |                             |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 821 |         NESTED LOOPS                            |                             |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 822 |          NESTED LOOPS                           |                             |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*823 |           INDEX RANGE SCAN                      | TYPEABREV                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*824 |           TABLE ACCESS BY INDEX ROWID BATCHED   | G_TELEPHONE                 |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*825 |            INDEX RANGE SCAN                     | IDX_G_TEL_INDIV             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*826 |          INDEX RANGE SCAN                       | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*827 |         TABLE ACCESS BY INDEX ROWID             | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 828 |        NESTED LOOPS                             |                             |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 829 |         NESTED LOOPS                            |                             |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 830 |          NESTED LOOPS                           |                             |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*831 |           INDEX RANGE SCAN                      | TYPEABREV                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*832 |           TABLE ACCESS BY INDEX ROWID BATCHED   | G_TELEPHONE                 |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*833 |            INDEX RANGE SCAN                     | IDX_G_TEL_INDIV             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*834 |          INDEX RANGE SCAN                       | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*835 |         TABLE ACCESS BY INDEX ROWID             | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 836 |      FAST DUAL                                  |                             |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*837 |      COUNT STOPKEY                              |                             |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
|*838 |       TABLE ACCESS BY INDEX ROWID BATCHED       | V_EXTR_DOM                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*839 |        INDEX RANGE SCAN                         | TYPEABREV_IND2              |      0 |      7 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*840 |       FILTER                                    |                             |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
|*841 |        FILTER                                   |                             |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
| 842 |         NESTED LOOPS                            |                             |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 843 |          TABLE ACCESS BY INDEX ROWID            | T_ENTMAIL                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*844 |           INDEX UNIQUE SCAN                     | PK_MAIL                     |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 845 |          TABLE ACCESS BY INDEX ROWID BATCHED    | G_PERSONNEL                 |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*846 |           INDEX RANGE SCAN                      | PK_G_PERSONNEL              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 847 |        NESTED LOOPS                             |                             |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 848 |         NESTED LOOPS                            |                             |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 849 |          NESTED LOOPS                           |                             |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*850 |           INDEX RANGE SCAN                      | TYPEABREV                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*851 |           TABLE ACCESS BY INDEX ROWID BATCHED   | G_TELEPHONE                 |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*852 |            INDEX RANGE SCAN                     | IDX_G_TEL_INDIV             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*853 |          INDEX RANGE SCAN                       | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*854 |         TABLE ACCESS BY INDEX ROWID             | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 855 |        NESTED LOOPS                             |                             |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 856 |         NESTED LOOPS                            |                             |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 857 |          NESTED LOOPS                           |                             |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*858 |           INDEX RANGE SCAN                      | TYPEABREV                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*859 |           TABLE ACCESS BY INDEX ROWID BATCHED   | G_TELEPHONE                 |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*860 |            INDEX RANGE SCAN                     | IDX_G_TEL_INDIV             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*861 |          INDEX RANGE SCAN                       | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*862 |         TABLE ACCESS BY INDEX ROWID             | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 863 |        NESTED LOOPS                             |                             |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 864 |         NESTED LOOPS                            |                             |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
| 865 |          NESTED LOOPS                           |                             |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*866 |           INDEX RANGE SCAN                      | TYPEABREV                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*867 |           TABLE ACCESS BY INDEX ROWID BATCHED   | G_TELEPHONE                 |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*868 |            INDEX RANGE SCAN                     | IDX_G_TEL_INDIV             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*869 |          INDEX RANGE SCAN                       | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*870 |         TABLE ACCESS BY INDEX ROWID             | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*871 |      TABLE ACCESS BY INDEX ROWID                | T_ENTMAIL                   |      4 |      1 |     1   (0)|      0 |00:00:00.02 |      16 |     11 |      0 |
|*872 |       INDEX UNIQUE SCAN                         | PK_MAIL                     |      4 |      1 |     1   (0)|      4 |00:00:00.01 |      12 |      7 |      0 |
|*873 |      TABLE ACCESS BY INDEX ROWID                | G_INFORMATION               |     26 |      1 |     1   (0)|      0 |00:00:00.04 |     105 |     36 |      0 |
|*874 |       INDEX UNIQUE SCAN                         | REF_INFORMATION             |     26 |      1 |     1   (0)|     26 |00:00:00.02 |      79 |     16 |      0 |
------------------------------------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   1 - filter(ROWNUM=1)
   2 - filter("ROWTYPE"='USER_LINK')
   3 - access("G"."REFPERSO"=:B1 AND "G"."TYPEELEM"=:B2)
   4 - filter(ROWNUM=1)
   5 - filter(("ROWTYPE"='USER_LINK' AND "LIBELLE_TYPE"=1 AND NVL("IMX"."FTRANSLATE_STR"(:B1,:B1,DECODE(:B2,'an',:B3,:B4)),:B5) LIKE "G"."LIBELLE"))
   6 - access("G"."REFPERSO"=:B1 AND "G"."TYPEELEM"=:B2)
   7 - filter(ROWNUM=1)
  11 - access("EC"."REFPERSO"=:B1)
  12 - access("EC"."GROUPID"="GP"."REFPERSO" AND "GP"."TYPEELEM"=:B1)
  13 - filter("GP"."ROWTYPE"='GROUP_LINK')
  14 - filter(ROWNUM=1)
  18 - access("EC"."REFPERSO"=:B1)
  19 - access("EC"."GROUPID"="GP"."REFPERSO" AND "GP"."TYPEELEM"=:B1)
  20 - filter("GP"."ROWTYPE"='GROUP_LINK')
  21 - filter(ROWNUM<2)
  22 - filter("VD"."CHEMIN"=DECODE(:B1,'en',,'fi',,'fa',DECODE(INSTR(UPPER(:B2),"VD"."CHEMIN"),0,:B3,"VD"."CHEMIN"),'ms',DECODE(INSTR(:B4,"VD"."CHEMIN"),0,:B5,"
              VD"."CHEMIN"),'in',SUBSTR(:B6,0,LENGTH("VD"."CHEMIN")),:B7))
  27 - filter('AL'=:B2)
  28 - filter("VALEUR_AL" IS NOT NULL)
  29 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
  30 - filter('AN'=:B2)
  31 - filter("VALEUR_AN" IS NOT NULL)
  32 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
  33 - filter('AR'=:B2)
  34 - filter("VALEUR_AR" IS NOT NULL)
  35 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
  36 - filter('BG'=:B2)
  37 - filter("VALEUR_BG" IS NOT NULL)
  38 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
  39 - filter('BR'=:B2)
  40 - filter("VALEUR_BR" IS NOT NULL)
  41 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
  42 - filter('CE'=:B2)
  43 - filter("VALEUR_CE" IS NOT NULL)
  44 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
  45 - filter('CH'=:B2)
  46 - filter("VALEUR_CH" IS NOT NULL)
  47 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
  48 - filter('CS'=:B2)
  49 - filter("VALEUR_CS" IS NOT NULL)
  50 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
  51 - filter('DA'=:B2)
  52 - filter("VALEUR_DA" IS NOT NULL)
  53 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
  54 - filter('EL'=:B2)
  55 - filter("VALEUR_EL" IS NOT NULL)
  56 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
  57 - filter('ES'=:B2)
  58 - filter("VALEUR_ES" IS NOT NULL)
  59 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
  60 - filter('ET'=:B2)
  61 - filter("VALEUR_ET" IS NOT NULL)
  62 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
  63 - filter('FI'=:B2)
  64 - filter("VALEUR_FI" IS NOT NULL)
  65 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
  66 - filter('FL'=:B2)
  67 - filter("VALEUR_FL" IS NOT NULL)
  68 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
  69 - filter('FR'=:B2)
  70 - filter(NVL("VALEUR_FR","VALEUR") IS NOT NULL)
  71 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
  72 - filter('HR'=:B2)
  73 - filter("VALEUR_HR" IS NOT NULL)
  74 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
  75 - filter('HU'=:B2)
  76 - filter("VALEUR_HU" IS NOT NULL)
  77 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
  78 - filter('IT'=:B2)
  79 - filter("VALEUR_IT" IS NOT NULL)
  80 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
  81 - filter('IW'=:B2)
  82 - filter("VALEUR_IW" IS NOT NULL)
  83 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
  84 - filter('JA'=:B2)
  85 - filter("VALEUR_JA" IS NOT NULL)
  86 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
  87 - filter('LT'=:B2)
  88 - filter("VALEUR_LT" IS NOT NULL)
  89 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
  90 - filter('LV'=:B2)
  91 - filter("VALEUR_LV" IS NOT NULL)
  92 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
  93 - filter('MX'=:B2)
  94 - filter("VALEUR_MX" IS NOT NULL)
  95 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
  96 - filter('NL'=:B2)
  97 - filter("VALEUR_NL" IS NOT NULL)
  98 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
  99 - filter('NO'=:B2)
 100 - filter("VALEUR_NO" IS NOT NULL)
 101 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
 102 - filter('PL'=:B2)
 103 - filter("VALEUR_PL" IS NOT NULL)
 104 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
 105 - filter('PT'=:B2)
 106 - filter("VALEUR_PT" IS NOT NULL)
 107 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
 108 - filter('RO'=:B2)
 109 - filter("VALEUR_RO" IS NOT NULL)
 110 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
 111 - filter('RU'=:B2)
 112 - filter("VALEUR_RU" IS NOT NULL)
 113 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
 114 - filter('SK'=:B2)
 115 - filter("VALEUR_SK" IS NOT NULL)
 116 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
 117 - filter('SL'=:B2)
 118 - filter("VALEUR_SL" IS NOT NULL)
 119 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
 120 - filter('SR'=:B2)
 121 - filter("VALEUR_SR" IS NOT NULL)
 122 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
 123 - filter('SV'=:B2)
 124 - filter("VALEUR_SV" IS NOT NULL)
 125 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
 126 - filter('TR'=:B2)
 127 - filter("VALEUR_TR" IS NOT NULL)
 128 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
 129 - filter('US'=:B2)
 130 - filter("VALEUR_US" IS NOT NULL)
 131 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
 132 - filter('VI'=:B2)
 133 - filter("VALEUR_VI" IS NOT NULL)
 134 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
 135 - filter('ZH'=:B2)
 136 - filter("VALEUR_ZH" IS NOT NULL)
 137 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
 138 - filter(ROWNUM<2)
 139 - filter( IS NULL)
 141 - access("GE"."REFENCAISS"=:B1)
 142 - filter(:B1 IS NULL)
 143 - access("REFELEM"=:B1)
 144 - filter(ROWNUM<2)
 146 - access("GFI"."REFELEM"=:B1)
 147 - filter(ROWNUM<2)
 150 - filter('AL'=:B3)
 151 - filter("CHEMIN" IS NULL)
 152 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
 153 - filter('AN'=:B3)
 154 - filter("CHEMIN" IS NULL)
 155 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
 156 - filter('AR'=:B3)
 157 - filter("CHEMIN" IS NULL)
 158 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
 159 - filter('BG'=:B3)
 160 - filter("CHEMIN" IS NULL)
 161 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
 162 - filter('BR'=:B3)
 163 - filter("CHEMIN" IS NULL)
 164 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
 165 - filter('CE'=:B3)
 166 - filter("CHEMIN" IS NULL)
 167 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
 168 - filter('CH'=:B3)
 169 - filter("CHEMIN" IS NULL)
 170 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
 171 - filter('CS'=:B3)
 172 - filter("CHEMIN" IS NULL)
 173 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
 174 - filter('DA'=:B3)
 175 - filter("CHEMIN" IS NULL)
 176 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
 177 - filter('EL'=:B3)
 178 - filter("CHEMIN" IS NULL)
 179 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
 180 - filter('ES'=:B3)
 181 - filter("CHEMIN" IS NULL)
 182 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
 183 - filter('ET'=:B3)
 184 - filter("CHEMIN" IS NULL)
 185 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
 186 - filter('FI'=:B3)
 187 - filter("CHEMIN" IS NULL)
 188 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
 189 - filter('FL'=:B3)
 190 - filter("CHEMIN" IS NULL)
 191 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
 192 - filter('FR'=:B3)
 193 - filter("CHEMIN" IS NULL)
 194 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
 195 - filter('HR'=:B3)
 196 - filter("CHEMIN" IS NULL)
 197 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
 198 - filter('HU'=:B3)
 199 - filter("CHEMIN" IS NULL)
 200 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
 201 - filter('IT'=:B3)
 202 - filter("CHEMIN" IS NULL)
 203 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
 204 - filter('IW'=:B3)
 205 - filter("CHEMIN" IS NULL)
 206 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
 207 - filter('JA'=:B3)
 208 - filter("CHEMIN" IS NULL)
 209 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
 210 - filter('LT'=:B3)
 211 - filter("CHEMIN" IS NULL)
 212 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
 213 - filter('LV'=:B3)
 214 - filter("CHEMIN" IS NULL)
 215 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
 216 - filter('MX'=:B3)
 217 - filter("CHEMIN" IS NULL)
 218 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
 219 - filter('NL'=:B3)
 220 - filter("CHEMIN" IS NULL)
 221 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
 222 - filter('NO'=:B3)
 223 - filter("CHEMIN" IS NULL)
 224 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
 225 - filter('PL'=:B3)
 226 - filter("CHEMIN" IS NULL)
 227 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
 228 - filter('PT'=:B3)
 229 - filter("CHEMIN" IS NULL)
 230 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
 231 - filter('RO'=:B3)
 232 - filter("CHEMIN" IS NULL)
 233 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
 234 - filter('RU'=:B3)
 235 - filter("CHEMIN" IS NULL)
 236 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
 237 - filter('SK'=:B3)
 238 - filter("CHEMIN" IS NULL)
 239 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
 240 - filter('SL'=:B3)
 241 - filter("CHEMIN" IS NULL)
 242 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
 243 - filter('SR'=:B3)
 244 - filter("CHEMIN" IS NULL)
 245 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
 246 - filter('SV'=:B3)
 247 - filter("CHEMIN" IS NULL)
 248 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
 249 - filter('TR'=:B3)
 250 - filter("CHEMIN" IS NULL)
 251 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
 252 - filter('US'=:B3)
 253 - filter("CHEMIN" IS NULL)
 254 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
 255 - filter('VI'=:B3)
 256 - filter("CHEMIN" IS NULL)
 257 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
 258 - filter('ZH'=:B3)
 259 - filter("CHEMIN" IS NULL)
 260 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
 263 - filter('AL'=UPPER(:B4))
 265 - access("VALEUR"=:B1 AND "TYPE"='MESSAGE_SUBJECT')
 266 - filter('AN'=UPPER(:B4))
 268 - access("VALEUR"=:B1 AND "TYPE"='MESSAGE_SUBJECT')
 269 - filter('AR'=UPPER(:B4))
 271 - access("VALEUR"=:B1 AND "TYPE"='MESSAGE_SUBJECT')
 272 - filter('BG'=UPPER(:B4))
 274 - access("VALEUR"=:B1 AND "TYPE"='MESSAGE_SUBJECT')
 275 - filter('BR'=UPPER(:B4))
 277 - access("VALEUR"=:B1 AND "TYPE"='MESSAGE_SUBJECT')
 278 - filter('CE'=UPPER(:B4))
 280 - access("VALEUR"=:B1 AND "TYPE"='MESSAGE_SUBJECT')
 281 - filter('CH'=UPPER(:B4))
 283 - access("VALEUR"=:B1 AND "TYPE"='MESSAGE_SUBJECT')
 284 - filter('CS'=UPPER(:B4))
 286 - access("VALEUR"=:B1 AND "TYPE"='MESSAGE_SUBJECT')
 287 - filter('DA'=UPPER(:B4))
 289 - access("VALEUR"=:B1 AND "TYPE"='MESSAGE_SUBJECT')
 290 - filter('EL'=UPPER(:B4))
 292 - access("VALEUR"=:B1 AND "TYPE"='MESSAGE_SUBJECT')
 293 - filter('ES'=UPPER(:B4))
 295 - access("VALEUR"=:B1 AND "TYPE"='MESSAGE_SUBJECT')
 296 - filter('ET'=UPPER(:B4))
 298 - access("VALEUR"=:B1 AND "TYPE"='MESSAGE_SUBJECT')
 299 - filter('FI'=UPPER(:B4))
 301 - access("VALEUR"=:B1 AND "TYPE"='MESSAGE_SUBJECT')
 302 - filter('FL'=UPPER(:B4))
 304 - access("VALEUR"=:B1 AND "TYPE"='MESSAGE_SUBJECT')
 305 - filter('FR'=UPPER(:B4))
 307 - access("VALEUR"=:B1 AND "TYPE"='MESSAGE_SUBJECT')
 308 - filter('HR'=UPPER(:B4))
 310 - access("VALEUR"=:B1 AND "TYPE"='MESSAGE_SUBJECT')
 311 - filter('HU'=UPPER(:B4))
 313 - access("VALEUR"=:B1 AND "TYPE"='MESSAGE_SUBJECT')
 314 - filter('IT'=UPPER(:B4))
 316 - access("VALEUR"=:B1 AND "TYPE"='MESSAGE_SUBJECT')
 317 - filter('IW'=UPPER(:B4))
 319 - access("VALEUR"=:B1 AND "TYPE"='MESSAGE_SUBJECT')
 320 - filter('JA'=UPPER(:B4))
 322 - access("VALEUR"=:B1 AND "TYPE"='MESSAGE_SUBJECT')
 323 - filter('LT'=UPPER(:B4))
 325 - access("VALEUR"=:B1 AND "TYPE"='MESSAGE_SUBJECT')
 326 - filter('LV'=UPPER(:B4))
 328 - access("VALEUR"=:B1 AND "TYPE"='MESSAGE_SUBJECT')
 329 - filter('MX'=UPPER(:B4))
 331 - access("VALEUR"=:B1 AND "TYPE"='MESSAGE_SUBJECT')
 332 - filter('NL'=UPPER(:B4))
 334 - access("VALEUR"=:B1 AND "TYPE"='MESSAGE_SUBJECT')
 335 - filter('NO'=UPPER(:B4))
 337 - access("VALEUR"=:B1 AND "TYPE"='MESSAGE_SUBJECT')
 338 - filter('PL'=UPPER(:B4))
 340 - access("VALEUR"=:B1 AND "TYPE"='MESSAGE_SUBJECT')
 341 - filter('PT'=UPPER(:B4))
 343 - access("VALEUR"=:B1 AND "TYPE"='MESSAGE_SUBJECT')
 344 - filter('RO'=UPPER(:B4))
 346 - access("VALEUR"=:B1 AND "TYPE"='MESSAGE_SUBJECT')
 347 - filter('RU'=UPPER(:B4))
 349 - access("VALEUR"=:B1 AND "TYPE"='MESSAGE_SUBJECT')
 350 - filter('SK'=UPPER(:B4))
 352 - access("VALEUR"=:B1 AND "TYPE"='MESSAGE_SUBJECT')
 353 - filter('SL'=UPPER(:B4))
 355 - access("VALEUR"=:B1 AND "TYPE"='MESSAGE_SUBJECT')
 356 - filter('SR'=UPPER(:B4))
 358 - access("VALEUR"=:B1 AND "TYPE"='MESSAGE_SUBJECT')
 359 - filter('SV'=UPPER(:B4))
 361 - access("VALEUR"=:B1 AND "TYPE"='MESSAGE_SUBJECT')
 362 - filter('TR'=UPPER(:B4))
 364 - access("VALEUR"=:B1 AND "TYPE"='MESSAGE_SUBJECT')
 365 - filter('US'=UPPER(:B4))
 367 - access("VALEUR"=:B1 AND "TYPE"='MESSAGE_SUBJECT')
 368 - filter('VI'=UPPER(:B4))
 370 - access("VALEUR"=:B1 AND "TYPE"='MESSAGE_SUBJECT')
 371 - filter('ZH'=UPPER(:B4))
 373 - access("VALEUR"=:B1 AND "TYPE"='MESSAGE_SUBJECT')
 374 - filter(ROWNUM<2)
 378 - access("P"."LOGIN"=:B1)
 379 - access("I"."REFINDIVIDU"="P"."REFINDIVIDU")
 381 - filter(ROWNUM<2)
 383 - access("FA"."REFELEM"=:B1)
 384 - filter(ROWNUM=1)
 386 - filter("TE"."SENS"='E')
 387 - access("TE"."REFMAIL"=:B1)
 388 - access("TM"."REFMAIL"=:B1)
 389 - filter(ROWNUM=1)
 391 - filter("TE"."SENS"='R')
 392 - access("TE"."REFMAIL"=:B1)
 393 - access("TM"."REFMAIL"=:B1)
 394 - filter(ROWNUM=1)
 395 - filter("TYPEMETTEUR"='A')
 396 - access("REFINFO"=:B1)
 397 - filter(ROWNUM=1)
 398 - filter(("REFIMAGE" IS NOT NULL AND "PIE"."CODE"='fi' AND "GPIIMAGE"='X'))
 399 - access("PIE"."REFEXT"=:B1 AND "PIE"."TYPPIECE"='IMAGE_EXTERNE')
 400 - filter(ROWNUM=1)
 401 - filter(("REFIMAGE" IS NOT NULL AND "PIE"."CODE"='eg' AND "GPIIMAGE"='X'))
 402 - access("PIE"."REFEXT"= AND "PIE"."TYPPIECE"='IMAGE_EXTERNE')
 404 - access("EE_NUM"=:B1)
 405 - filter(ROWNUM=1)
 407 - filter(ROWNUM=1)
 408 - filter(("REFIMAGE" IS NOT NULL AND "GPIIMAGE"='X'))
 409 - access("PIE"."REFPIECE"=:B1)
 410 - filter(ROWNUM=1)
 411 - filter(("REFIMAGE" IS NOT NULL AND "GPIIMAGE"='X' AND LNNVL("PIE"."REFPIECE"=:B1)))
 412 - access("PIE"."REFEXT"=:B1)
 416 - filter((( IS NOT NULL OR ( IS NULL AND  IS NULL)) AND ((("AUTH"."LIBELLE"='ALL' OR "E"."LIBELLE" LIKE "AUTH"."LIBELLE") AND
              NVL("AUTH"."LIBELLE_TYPE",0)=0) OR  IS NULL) AND ("E"."TYPEELEM"<>'ms' OR =1) AND ("E"."TYPEELEM"<>'me' OR =1) AND ("E"."TYPEELEM"<>'mr' OR =1) AND
              (("E"."TYPEELEM"<>'me' AND "E"."TYPEELEM"<>'mr') OR  IS NULL) AND (("E"."TYPEELEM"<>'in' AND "E"."TYPEELEM"<>'ms') OR  IS NULL)))
 417 - access("EX"."REFPERSO"="AUTH"."REFPERSO" AND "EX"."TYPEELEM"="AUTH"."TYPEELEM")
       filter("E"."LIBELLE" LIKE "EX"."LIBELLE")
 418 - filter(("EX"."ROWTYPE"='USER' AND "EX"."LIBELLE_TYPE"=1))
 419 - access("EX"."REFPERSO"=TO_NUMBER(:B8))
 420 - access("AUTH"."TYPEELEM"=DECODE("E"."TYPEELEM",'in',DECODE("VD2"."VALEUR",NULL,'in','in_s'),"E"."TYPEELEM"))
 421 - filter(("AUTH"."ROWTYPE"='USER' AND "AUTH"."LIBELLE"<>'NOTHING'))
 422 - access("AUTH"."REFPERSO"=TO_NUMBER(:B8))
 423 - filter(NVL("VD2"."ECRAN",'XXX')<>'invis extranet')
 424 - access("VD2"."VALEUR"=DECODE(SUBSTR("E"."LIBELLE",1,2),'A.',SUBSTR("E"."LIBELLE",3),"E"."LIBELLE"))
 425 - access("VD_TYPES"."ABREV"="E"."TYPEELEM")
 427 - access("ITEM_1"="E"."REFELEM")
 429 - access("E"."REFDOSS"=:B7)
       filter(("E"."TYPEELEM"<>'se' AND "E"."TYPEELEM"<>'ng' AND "E"."TYPEELEM"<>'an' AND "E"."TYPEELEM"<>'yy' AND "E"."TYPEELEM"<>'et' AND
              "E"."TYPEELEM"<>'xx' AND "E"."TYPEELEM"<>'ce'))
 432 - filter(NVL("GP"."FG_NOT_VISIBLE_IN_XNET",'N')='O')
 434 - access("GP"."REFPIECE"="TE"."REFELEM")
       filter("GP"."REFPIECE"="TE"."REFELEM")
 436 - filter("GELEM"."REFDOSS"=:B7)
 437 - access("E"."REFELEM"="GELEM"."REFELEM")
 440 - filter('AL'=:B10)
 441 - filter(("ABREV"<>'se' AND "ABREV"<>'ng' AND "ABREV"<>'an' AND "ABREV"<>'yy' AND "ABREV"<>'et' AND "ABREV"<>'xx' AND "ABREV"<>'ce'))
 442 - access("TYPE"='ELEM_CHRONO')
 443 - filter('AN'=:B10)
 444 - filter(("ABREV"<>'se' AND "ABREV"<>'ng' AND "ABREV"<>'an' AND "ABREV"<>'yy' AND "ABREV"<>'et' AND "ABREV"<>'xx' AND "ABREV"<>'ce'))
 445 - access("TYPE"='ELEM_CHRONO')
 446 - filter('AR'=:B10)
 447 - filter(("ABREV"<>'se' AND "ABREV"<>'ng' AND "ABREV"<>'an' AND "ABREV"<>'yy' AND "ABREV"<>'et' AND "ABREV"<>'xx' AND "ABREV"<>'ce'))
 448 - access("TYPE"='ELEM_CHRONO')
 449 - filter('BG'=:B10)
 450 - filter(("ABREV"<>'se' AND "ABREV"<>'ng' AND "ABREV"<>'an' AND "ABREV"<>'yy' AND "ABREV"<>'et' AND "ABREV"<>'xx' AND "ABREV"<>'ce'))
 451 - access("TYPE"='ELEM_CHRONO')
 452 - filter('BR'=:B10)
 453 - filter(("ABREV"<>'se' AND "ABREV"<>'ng' AND "ABREV"<>'an' AND "ABREV"<>'yy' AND "ABREV"<>'et' AND "ABREV"<>'xx' AND "ABREV"<>'ce'))
 454 - access("TYPE"='ELEM_CHRONO')
 455 - filter('CE'=:B10)
 456 - filter(("ABREV"<>'se' AND "ABREV"<>'ng' AND "ABREV"<>'an' AND "ABREV"<>'yy' AND "ABREV"<>'et' AND "ABREV"<>'xx' AND "ABREV"<>'ce'))
 457 - access("TYPE"='ELEM_CHRONO')
 458 - filter('CH'=:B10)
 459 - filter(("ABREV"<>'se' AND "ABREV"<>'ng' AND "ABREV"<>'an' AND "ABREV"<>'yy' AND "ABREV"<>'et' AND "ABREV"<>'xx' AND "ABREV"<>'ce'))
 460 - access("TYPE"='ELEM_CHRONO')
 461 - filter('CS'=:B10)
 462 - filter(("ABREV"<>'se' AND "ABREV"<>'ng' AND "ABREV"<>'an' AND "ABREV"<>'yy' AND "ABREV"<>'et' AND "ABREV"<>'xx' AND "ABREV"<>'ce'))
 463 - access("TYPE"='ELEM_CHRONO')
 464 - filter('DA'=:B10)
 465 - filter(("ABREV"<>'se' AND "ABREV"<>'ng' AND "ABREV"<>'an' AND "ABREV"<>'yy' AND "ABREV"<>'et' AND "ABREV"<>'xx' AND "ABREV"<>'ce'))
 466 - access("TYPE"='ELEM_CHRONO')
 467 - filter('EL'=:B10)
 468 - filter(("ABREV"<>'se' AND "ABREV"<>'ng' AND "ABREV"<>'an' AND "ABREV"<>'yy' AND "ABREV"<>'et' AND "ABREV"<>'xx' AND "ABREV"<>'ce'))
 469 - access("TYPE"='ELEM_CHRONO')
 470 - filter('ES'=:B10)
 471 - filter(("ABREV"<>'se' AND "ABREV"<>'ng' AND "ABREV"<>'an' AND "ABREV"<>'yy' AND "ABREV"<>'et' AND "ABREV"<>'xx' AND "ABREV"<>'ce'))
 472 - access("TYPE"='ELEM_CHRONO')
 473 - filter('ET'=:B10)
 474 - filter(("ABREV"<>'se' AND "ABREV"<>'ng' AND "ABREV"<>'an' AND "ABREV"<>'yy' AND "ABREV"<>'et' AND "ABREV"<>'xx' AND "ABREV"<>'ce'))
 475 - access("TYPE"='ELEM_CHRONO')
 476 - filter('FI'=:B10)
 477 - filter(("ABREV"<>'se' AND "ABREV"<>'ng' AND "ABREV"<>'an' AND "ABREV"<>'yy' AND "ABREV"<>'et' AND "ABREV"<>'xx' AND "ABREV"<>'ce'))
 478 - access("TYPE"='ELEM_CHRONO')
 479 - filter('FL'=:B10)
 480 - filter(("ABREV"<>'se' AND "ABREV"<>'ng' AND "ABREV"<>'an' AND "ABREV"<>'yy' AND "ABREV"<>'et' AND "ABREV"<>'xx' AND "ABREV"<>'ce'))
 481 - access("TYPE"='ELEM_CHRONO')
 482 - filter('FR'=:B10)
 483 - filter(("ABREV"<>'se' AND "ABREV"<>'ng' AND "ABREV"<>'an' AND "ABREV"<>'yy' AND "ABREV"<>'et' AND "ABREV"<>'xx' AND "ABREV"<>'ce'))
 484 - access("TYPE"='ELEM_CHRONO')
 485 - filter('HR'=:B10)
 486 - filter(("ABREV"<>'se' AND "ABREV"<>'ng' AND "ABREV"<>'an' AND "ABREV"<>'yy' AND "ABREV"<>'et' AND "ABREV"<>'xx' AND "ABREV"<>'ce'))
 487 - access("TYPE"='ELEM_CHRONO')
 488 - filter('HU'=:B10)
 489 - filter(("ABREV"<>'se' AND "ABREV"<>'ng' AND "ABREV"<>'an' AND "ABREV"<>'yy' AND "ABREV"<>'et' AND "ABREV"<>'xx' AND "ABREV"<>'ce'))
 490 - access("TYPE"='ELEM_CHRONO')
 491 - filter('IT'=:B10)
 492 - filter(("ABREV"<>'se' AND "ABREV"<>'ng' AND "ABREV"<>'an' AND "ABREV"<>'yy' AND "ABREV"<>'et' AND "ABREV"<>'xx' AND "ABREV"<>'ce'))
 493 - access("TYPE"='ELEM_CHRONO')
 494 - filter('IW'=:B10)
 495 - filter(("ABREV"<>'se' AND "ABREV"<>'ng' AND "ABREV"<>'an' AND "ABREV"<>'yy' AND "ABREV"<>'et' AND "ABREV"<>'xx' AND "ABREV"<>'ce'))
 496 - access("TYPE"='ELEM_CHRONO')
 497 - filter('JA'=:B10)
 498 - filter(("ABREV"<>'se' AND "ABREV"<>'ng' AND "ABREV"<>'an' AND "ABREV"<>'yy' AND "ABREV"<>'et' AND "ABREV"<>'xx' AND "ABREV"<>'ce'))
 499 - access("TYPE"='ELEM_CHRONO')
 500 - filter('LT'=:B10)
 501 - filter(("ABREV"<>'se' AND "ABREV"<>'ng' AND "ABREV"<>'an' AND "ABREV"<>'yy' AND "ABREV"<>'et' AND "ABREV"<>'xx' AND "ABREV"<>'ce'))
 502 - access("TYPE"='ELEM_CHRONO')
 503 - filter('LV'=:B10)
 504 - filter(("ABREV"<>'se' AND "ABREV"<>'ng' AND "ABREV"<>'an' AND "ABREV"<>'yy' AND "ABREV"<>'et' AND "ABREV"<>'xx' AND "ABREV"<>'ce'))
 505 - access("TYPE"='ELEM_CHRONO')
 506 - filter('MX'=:B10)
 507 - filter(("ABREV"<>'se' AND "ABREV"<>'ng' AND "ABREV"<>'an' AND "ABREV"<>'yy' AND "ABREV"<>'et' AND "ABREV"<>'xx' AND "ABREV"<>'ce'))
 508 - access("TYPE"='ELEM_CHRONO')
 509 - filter('NL'=:B10)
 510 - filter(("ABREV"<>'se' AND "ABREV"<>'ng' AND "ABREV"<>'an' AND "ABREV"<>'yy' AND "ABREV"<>'et' AND "ABREV"<>'xx' AND "ABREV"<>'ce'))
 511 - access("TYPE"='ELEM_CHRONO')
 512 - filter('NO'=:B10)
 513 - filter(("ABREV"<>'se' AND "ABREV"<>'ng' AND "ABREV"<>'an' AND "ABREV"<>'yy' AND "ABREV"<>'et' AND "ABREV"<>'xx' AND "ABREV"<>'ce'))
 514 - access("TYPE"='ELEM_CHRONO')
 515 - filter('PL'=:B10)
 516 - filter(("ABREV"<>'se' AND "ABREV"<>'ng' AND "ABREV"<>'an' AND "ABREV"<>'yy' AND "ABREV"<>'et' AND "ABREV"<>'xx' AND "ABREV"<>'ce'))
 517 - access("TYPE"='ELEM_CHRONO')
 518 - filter('PT'=:B10)
 519 - filter(("ABREV"<>'se' AND "ABREV"<>'ng' AND "ABREV"<>'an' AND "ABREV"<>'yy' AND "ABREV"<>'et' AND "ABREV"<>'xx' AND "ABREV"<>'ce'))
 520 - access("TYPE"='ELEM_CHRONO')
 521 - filter('RO'=:B10)
 522 - filter(("ABREV"<>'se' AND "ABREV"<>'ng' AND "ABREV"<>'an' AND "ABREV"<>'yy' AND "ABREV"<>'et' AND "ABREV"<>'xx' AND "ABREV"<>'ce'))
 523 - access("TYPE"='ELEM_CHRONO')
 524 - filter('RU'=:B10)
 525 - filter(("ABREV"<>'se' AND "ABREV"<>'ng' AND "ABREV"<>'an' AND "ABREV"<>'yy' AND "ABREV"<>'et' AND "ABREV"<>'xx' AND "ABREV"<>'ce'))
 526 - access("TYPE"='ELEM_CHRONO')
 527 - filter('SK'=:B10)
 528 - filter(("ABREV"<>'se' AND "ABREV"<>'ng' AND "ABREV"<>'an' AND "ABREV"<>'yy' AND "ABREV"<>'et' AND "ABREV"<>'xx' AND "ABREV"<>'ce'))
 529 - access("TYPE"='ELEM_CHRONO')
 530 - filter('SL'=:B10)
 531 - filter(("ABREV"<>'se' AND "ABREV"<>'ng' AND "ABREV"<>'an' AND "ABREV"<>'yy' AND "ABREV"<>'et' AND "ABREV"<>'xx' AND "ABREV"<>'ce'))
 532 - access("TYPE"='ELEM_CHRONO')
 533 - filter('SR'=:B10)
 534 - filter(("ABREV"<>'se' AND "ABREV"<>'ng' AND "ABREV"<>'an' AND "ABREV"<>'yy' AND "ABREV"<>'et' AND "ABREV"<>'xx' AND "ABREV"<>'ce'))
 535 - access("TYPE"='ELEM_CHRONO')
 536 - filter('SV'=:B10)
 537 - filter(("ABREV"<>'se' AND "ABREV"<>'ng' AND "ABREV"<>'an' AND "ABREV"<>'yy' AND "ABREV"<>'et' AND "ABREV"<>'xx' AND "ABREV"<>'ce'))
 538 - access("TYPE"='ELEM_CHRONO')
 539 - filter('TR'=:B10)
 540 - filter(("ABREV"<>'se' AND "ABREV"<>'ng' AND "ABREV"<>'an' AND "ABREV"<>'yy' AND "ABREV"<>'et' AND "ABREV"<>'xx' AND "ABREV"<>'ce'))
 541 - access("TYPE"='ELEM_CHRONO')
 542 - filter('US'=:B10)
 543 - filter(("ABREV"<>'se' AND "ABREV"<>'ng' AND "ABREV"<>'an' AND "ABREV"<>'yy' AND "ABREV"<>'et' AND "ABREV"<>'xx' AND "ABREV"<>'ce'))
 544 - access("TYPE"='ELEM_CHRONO')
 545 - filter('VI'=:B10)
 546 - filter(("ABREV"<>'se' AND "ABREV"<>'ng' AND "ABREV"<>'an' AND "ABREV"<>'yy' AND "ABREV"<>'et' AND "ABREV"<>'xx' AND "ABREV"<>'ce'))
 547 - access("TYPE"='ELEM_CHRONO')
 548 - filter('ZH'=:B10)
 549 - filter(("ABREV"<>'se' AND "ABREV"<>'ng' AND "ABREV"<>'an' AND "ABREV"<>'yy' AND "ABREV"<>'et' AND "ABREV"<>'xx' AND "ABREV"<>'ce'))
 550 - access("TYPE"='ELEM_CHRONO')
 553 - filter('AL'=:B6)
 555 - access("TYPE"='LIBELINFO')
 556 - filter('AN'=:B6)
 558 - access("TYPE"='LIBELINFO')
 559 - filter('AR'=:B6)
 561 - access("TYPE"='LIBELINFO')
 562 - filter('BG'=:B6)
 564 - access("TYPE"='LIBELINFO')
 565 - filter('BR'=:B6)
 567 - access("TYPE"='LIBELINFO')
 568 - filter('CE'=:B6)
 570 - access("TYPE"='LIBELINFO')
 571 - filter('CH'=:B6)
 573 - access("TYPE"='LIBELINFO')
 574 - filter('CS'=:B6)
 576 - access("TYPE"='LIBELINFO')
 577 - filter('DA'=:B6)
 579 - access("TYPE"='LIBELINFO')
 580 - filter('EL'=:B6)
 582 - access("TYPE"='LIBELINFO')
 583 - filter('ES'=:B6)
 585 - access("TYPE"='LIBELINFO')
 586 - filter('ET'=:B6)
 588 - access("TYPE"='LIBELINFO')
 589 - filter('FI'=:B6)
 591 - access("TYPE"='LIBELINFO')
 592 - filter('FL'=:B6)
 594 - access("TYPE"='LIBELINFO')
 595 - filter('FR'=:B6)
 597 - access("TYPE"='LIBELINFO')
 598 - filter('HR'=:B6)
 600 - access("TYPE"='LIBELINFO')
 601 - filter('HU'=:B6)
 603 - access("TYPE"='LIBELINFO')
 604 - filter('IT'=:B6)
 606 - access("TYPE"='LIBELINFO')
 607 - filter('IW'=:B6)
 609 - access("TYPE"='LIBELINFO')
 610 - filter('JA'=:B6)
 612 - access("TYPE"='LIBELINFO')
 613 - filter('LT'=:B6)
 615 - access("TYPE"='LIBELINFO')
 616 - filter('LV'=:B6)
 618 - access("TYPE"='LIBELINFO')
 619 - filter('MX'=:B6)
 621 - access("TYPE"='LIBELINFO')
 622 - filter('NL'=:B6)
 624 - access("TYPE"='LIBELINFO')
 625 - filter('NO'=:B6)
 627 - access("TYPE"='LIBELINFO')
 628 - filter('PL'=:B6)
 630 - access("TYPE"='LIBELINFO')
 631 - filter('PT'=:B6)
 633 - access("TYPE"='LIBELINFO')
 634 - filter('RO'=:B6)
 636 - access("TYPE"='LIBELINFO')
 637 - filter('RU'=:B6)
 639 - access("TYPE"='LIBELINFO')
 640 - filter('SK'=:B6)
 642 - access("TYPE"='LIBELINFO')
 643 - filter('SL'=:B6)
 645 - access("TYPE"='LIBELINFO')
 646 - filter('SR'=:B6)
 648 - access("TYPE"='LIBELINFO')
 649 - filter('SV'=:B6)
 651 - access("TYPE"='LIBELINFO')
 652 - filter('TR'=:B6)
 654 - access("TYPE"='LIBELINFO')
 655 - filter('US'=:B6)
 657 - access("TYPE"='LIBELINFO')
 658 - filter('VI'=:B6)
 660 - access("TYPE"='LIBELINFO')
 661 - filter('ZH'=:B6)
 663 - access("TYPE"='LIBELINFO')
 664 - filter("VD"."CHEMIN"=DECODE(:B1,'en',,'fi',,:B2))
 667 - filter('AL'=:B9)
 668 - filter("VALEUR_AL" IS NOT NULL)
 669 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
 670 - filter('AN'=:B9)
 671 - filter("VALEUR_AN" IS NOT NULL)
 672 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
 673 - filter('AR'=:B9)
 674 - filter("VALEUR_AR" IS NOT NULL)
 675 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
 676 - filter('BG'=:B9)
 677 - filter("VALEUR_BG" IS NOT NULL)
 678 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
 679 - filter('BR'=:B9)
 680 - filter("VALEUR_BR" IS NOT NULL)
 681 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
 682 - filter('CE'=:B9)
 683 - filter("VALEUR_CE" IS NOT NULL)
 684 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
 685 - filter('CH'=:B9)
 686 - filter("VALEUR_CH" IS NOT NULL)
 687 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
 688 - filter('CS'=:B9)
 689 - filter("VALEUR_CS" IS NOT NULL)
 690 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
 691 - filter('DA'=:B9)
 692 - filter("VALEUR_DA" IS NOT NULL)
 693 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
 694 - filter('EL'=:B9)
 695 - filter("VALEUR_EL" IS NOT NULL)
 696 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
 697 - filter('ES'=:B9)
 698 - filter("VALEUR_ES" IS NOT NULL)
 699 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
 700 - filter('ET'=:B9)
 701 - filter("VALEUR_ET" IS NOT NULL)
 702 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
 703 - filter('FI'=:B9)
 704 - filter("VALEUR_FI" IS NOT NULL)
 705 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
 706 - filter('FL'=:B9)
 707 - filter("VALEUR_FL" IS NOT NULL)
 708 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
 709 - filter('FR'=:B9)
 710 - filter(NVL("VALEUR_FR","VALEUR") IS NOT NULL)
 711 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
 712 - filter('HR'=:B9)
 713 - filter("VALEUR_HR" IS NOT NULL)
 714 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
 715 - filter('HU'=:B9)
 716 - filter("VALEUR_HU" IS NOT NULL)
 717 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
 718 - filter('IT'=:B9)
 719 - filter("VALEUR_IT" IS NOT NULL)
 720 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
 721 - filter('IW'=:B9)
 722 - filter("VALEUR_IW" IS NOT NULL)
 723 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
 724 - filter('JA'=:B9)
 725 - filter("VALEUR_JA" IS NOT NULL)
 726 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
 727 - filter('LT'=:B9)
 728 - filter("VALEUR_LT" IS NOT NULL)
 729 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
 730 - filter('LV'=:B9)
 731 - filter("VALEUR_LV" IS NOT NULL)
 732 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
 733 - filter('MX'=:B9)
 734 - filter("VALEUR_MX" IS NOT NULL)
 735 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
 736 - filter('NL'=:B9)
 737 - filter("VALEUR_NL" IS NOT NULL)
 738 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
 739 - filter('NO'=:B9)
 740 - filter("VALEUR_NO" IS NOT NULL)
 741 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
 742 - filter('PL'=:B9)
 743 - filter("VALEUR_PL" IS NOT NULL)
 744 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
 745 - filter('PT'=:B9)
 746 - filter("VALEUR_PT" IS NOT NULL)
 747 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
 748 - filter('RO'=:B9)
 749 - filter("VALEUR_RO" IS NOT NULL)
 750 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
 751 - filter('RU'=:B9)
 752 - filter("VALEUR_RU" IS NOT NULL)
 753 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
 754 - filter('SK'=:B9)
 755 - filter("VALEUR_SK" IS NOT NULL)
 756 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
 757 - filter('SL'=:B9)
 758 - filter("VALEUR_SL" IS NOT NULL)
 759 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
 760 - filter('SR'=:B9)
 761 - filter("VALEUR_SR" IS NOT NULL)
 762 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
 763 - filter('SV'=:B9)
 764 - filter("VALEUR_SV" IS NOT NULL)
 765 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
 766 - filter('TR'=:B9)
 767 - filter("VALEUR_TR" IS NOT NULL)
 768 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
 769 - filter('US'=:B9)
 770 - filter("VALEUR_US" IS NOT NULL)
 771 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
 772 - filter('VI'=:B9)
 773 - filter("VALEUR_VI" IS NOT NULL)
 774 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
 775 - filter('ZH'=:B9)
 776 - filter("VALEUR_ZH" IS NOT NULL)
 777 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
 778 - filter(ROWNUM<2)
 780 - access("GE"."REFENCAISS"=:B1)
 781 - filter(ROWNUM<2)
 783 - access("GFI"."REFELEM"=:B1)
 784 - filter(("VE"."TYPE"='CHRONO_VIEW_TRANSLATED_LABELS_ONLY' AND TO_NUMBER("VE"."ABREV")=:B1))
 785 - access("VALEUR"='O')
 786 - filter(("TR"."ROWTYPE"='USER_TRANSL' AND TO_NUMBER("TR"."TRANSL")=1))
 787 - access("TR"."REFPERSO"=:B1 AND "TR"."TYPEELEM"=:B2)
 788 - filter(("EX"."ROWTYPE"='USER' AND "EX"."LIBELLE_TYPE"=0))
 789 - access("EX"."REFPERSO"=:B1 AND "EX"."TYPEELEM"=:B2)
 791 - filter(ROWNUM=1)
 792 - filter(("VALEUR_2"='USER' AND "TYPE"='CHRONO_PARTY_REQUIRED' AND TO_NUMBER("ABREV")=:B1))
 793 - access("VALEUR"='ms')
 794 - filter(( IS NOT NULL OR  IS NOT NULL))
 796 - access("GI"."REFINFO"=:B1)
 797 - filter("REFINDIVIDU"=:B1)
 798 - access("REFPERSO"=:B1)
 799 - filter("REFINDIVIDU"=:B1)
 800 - access("REFPERSO"=:B1)
 802 - filter(ROWNUM=1)
 803 - filter(("VALEUR_2"='USER' AND "TYPE"='CHRONO_PARTY_REQUIRED' AND TO_NUMBER("ABREV")=:B1))
 804 - access("VALEUR"='me')
 805 - filter(("GP"."EMAIL"="GI"."DESTINATAIRE" OR "GP"."EMAIL"="GI"."EXPEDITEUR" OR ("GI"."CC" IS NOT NULL AND "GP"."EMAIL"="GI"."CC") OR  IS NOT NULL OR  IS
              NOT NULL OR  IS NOT NULL))
 806 - filter(:B1='me')
 809 - access("GI"."REFMAIL"=:B1)
 811 - access("GP"."REFPERSO"=:B1)
 815 - access("IND"."TYPE"='EXTR_GEST_CLIENT')
       filter(TO_NUMBER("IND"."ABREV")=:B1)
 816 - filter("TEL"."VALIDITE"='O')
 817 - access("TEL"."REFINDIVIDU"="IND"."VALEUR" AND "NUMTEL"=:B1)
       filter("NUMTEL"=:B1)
 818 - access("TYPETEL"."TYPE"='typtel' AND "TEL"."TYPETEL"="TYPETEL"."ABREV")
       filter("TYPETEL"."ABREV" IS NOT NULL)
 819 - filter("TYPETEL"."ECRAN"='EMAIL')
 823 - access("IND"."TYPE"='EXTR_GEST_CLIENT')
       filter(TO_NUMBER("IND"."ABREV")=:B1)
 824 - filter("TEL"."VALIDITE"='O')
 825 - access("TEL"."REFINDIVIDU"="IND"."VALEUR" AND "NUMTEL"=:B1)
       filter("NUMTEL"=:B1)
 826 - access("TYPETEL"."TYPE"='typtel' AND "TEL"."TYPETEL"="TYPETEL"."ABREV")
       filter("TYPETEL"."ABREV" IS NOT NULL)
 827 - filter("TYPETEL"."ECRAN"='EMAIL')
 831 - access("IND"."TYPE"='EXTR_GEST_CLIENT')
       filter(TO_NUMBER("IND"."ABREV")=:B1)
 832 - filter("TEL"."VALIDITE"='O')
 833 - access("TEL"."REFINDIVIDU"="IND"."VALEUR" AND "NUMTEL"=:B1)
       filter("NUMTEL"=:B1)
 834 - access("TYPETEL"."TYPE"='typtel' AND "TEL"."TYPETEL"="TYPETEL"."ABREV")
       filter("TYPETEL"."ABREV" IS NOT NULL)
 835 - filter("TYPETEL"."ECRAN"='EMAIL')
 837 - filter(ROWNUM=1)
 838 - filter(("VALEUR_2"='USER' AND "TYPE"='CHRONO_PARTY_REQUIRED' AND TO_NUMBER("ABREV")=:B1))
 839 - access("VALEUR"='mr')
 840 - filter(("GP"."EMAIL"="GI"."DESTINATAIRE" OR "GP"."EMAIL"="GI"."EXPEDITEUR" OR ("GI"."CC" IS NOT NULL AND "GP"."EMAIL"="GI"."CC") OR  IS NOT NULL OR  IS
              NOT NULL OR  IS NOT NULL))
 841 - filter(:B1='mr')
 844 - access("GI"."REFMAIL"=:B1)
 846 - access("GP"."REFPERSO"=:B1)
 850 - access("IND"."TYPE"='EXTR_GEST_CLIENT')
       filter(TO_NUMBER("IND"."ABREV")=:B1)
 851 - filter("TEL"."VALIDITE"='O')
 852 - access("TEL"."REFINDIVIDU"="IND"."VALEUR" AND "NUMTEL"=:B1)
       filter("NUMTEL"=:B1)
 853 - access("TYPETEL"."TYPE"='typtel' AND "TEL"."TYPETEL"="TYPETEL"."ABREV")
       filter("TYPETEL"."ABREV" IS NOT NULL)
 854 - filter("TYPETEL"."ECRAN"='EMAIL')
 858 - access("IND"."TYPE"='EXTR_GEST_CLIENT')
       filter(TO_NUMBER("IND"."ABREV")=:B1)
 859 - filter("TEL"."VALIDITE"='O')
 860 - access("TEL"."REFINDIVIDU"="IND"."VALEUR" AND "NUMTEL"=:B1)
       filter("NUMTEL"=:B1)
 861 - access("TYPETEL"."TYPE"='typtel' AND "TEL"."TYPETEL"="TYPETEL"."ABREV")
       filter("TYPETEL"."ABREV" IS NOT NULL)
 862 - filter("TYPETEL"."ECRAN"='EMAIL')
 866 - access("IND"."TYPE"='EXTR_GEST_CLIENT')
       filter(TO_NUMBER("IND"."ABREV")=:B1)
 867 - filter("TEL"."VALIDITE"='O')
 868 - access("TEL"."REFINDIVIDU"="IND"."VALEUR" AND "NUMTEL"=:B1)
       filter("NUMTEL"=:B1)
 869 - access("TYPETEL"."TYPE"='typtel' AND "TEL"."TYPETEL"="TYPETEL"."ABREV")
       filter("TYPETEL"."ABREV" IS NOT NULL)
 870 - filter("TYPETEL"."ECRAN"='EMAIL')
 871 - filter("T_ENTMAIL"."NOT_VISIBLE"='O')
 872 - access("T_ENTMAIL"."REFMAIL"=:B1)
 873 - filter("G_INFORMATION"."EXTRANET_INVIS"='O')
 874 - access("G_INFORMATION"."REFINFO"=:B1)

*/
/********************************OLD Metrics***************************************/

/********************************New SQL*******************************************/
SELECT *
  FROM (SELECT DISTINCT e.refdoss refdoss,
                        e.refelem refelem,
                        e.typeelem type,
                        NVL(vd_types.abrev_trad, e.typeelem) translatedType,
                        NVL(vd_types.valeur_trad, e.typeelem) ||
                        DECODE(gelem.refext, NULL, '', ' : ' || gelem.refext) translatedTypeHint,
                        NVL(vd2.ecran, 'XXX') invisible,
                        /*link authorization NOTE ne pipaj tozi select!!!*/
                        DECODE((SELECT libelle
                                 FROM g_pers_auth g
                                WHERE g.typeelem = auth.typeelem
                                  AND rowtype = 'USER_LINK'
                                  AND g.refperso = auth.refperso
                                  AND rownum = 1),
                               'NOTHING',
                               NULL
                               /*nothing */,
                               'ALL',
                               NVL(e.libelle, 'ALL'),
                               /*all*/
                               DECODE(NVL((SELECT libelle_type
                                            FROM g_pers_auth g
                                           WHERE g.typeelem = auth.typeelem
                                             AND ROWTYPE = 'USER_LINK'
                                             AND g.refperso = auth.refperso
                                             AND NVL(imx.ftranslate_str(e.libelle,
                                                                        :B1,
                                                                        DECODE(e.typeelem,
                                                                               'an',
                                                                               e.abrev,
                                                                               e.typeelem)),
                                                     e.libelle) LIKE
                                                 g.libelle
                                             AND libelle_type = 1
                                             AND ROWNUM = 1),
                                          0),
                                      1,
                                      e.libelle,
                                      0,
                                      DECODE((SELECT LIBELLE
                                               FROM ec_user ec, g_pers_auth gp
                                              WHERE ec.groupid = gp.refperso
                                                AND ec.refperso =
                                                    auth.refperso
                                                AND gp.ROWTYPE = 'GROUP_LINK'
                                                AND gp.TYPEELEM =
                                                    auth.TYPEELEM
                                                AND ROWNUM = 1),
                                             'ALL',
                                             1,
                                             'NOTHING',
                                             0,
                                             DECODE((SELECT LIBELLE
                                                      FROM ec_user     ec,
                                                           g_pers_auth gp
                                                     WHERE ec.groupid =
                                                           gp.refperso
                                                       AND gp.TYPEELEM =
                                                           auth.TYPEELEM
                                                       AND gp.ROWTYPE =
                                                           'GROUP_LINK'
                                                       AND ec.refperso =
                                                           auth.refperso
                                                       AND ROWNUM = 1),
                                                    '0',
                                                    0,
                                                    1)))) label,
                        /* end link */
                        e.montant_dos montant,
                        e.DTASSOC_DT dateAssoc,
                        e.dtassoc,
                        e.dtsaisie,
                        e.rejet reject,
                        e.nom name,
                        e.ancrefdoss origine,
                        e.dtsaisie_dt entryDate,
                        DECODE(NVL(vd_types.abrev1, 'N'),
                               'O',
                               e.dtassoc_dt,
                               e.dtsaisie_dt) displayDate,
                        trim(DECODE(DECODE(e.typeelem || '/' ||
                                           NVL(vd2.abrev, 'NULL'),
                                           'in/STS',
                                           '0',
                                           'in/STA',
                                           '0',
                                           'in/STACUST',
                                           '0',
                                           'in/STALDC',
                                           '0',
                                           'in/LDCACK',
                                           '0',
                                           'in/LEGAL',
                                           '0',
                                           'in/NULL',
                                           DECODE(SUBSTR(e.libelle, 0, 6),
                                                  'IMXTEL',
                                                  ' ',
                                                  '0')),
                                    '0',
                                    ' ',
                                    /* start translate label 1- EXTRANET_CHRONO_LIBELLES(type, moyenpaimt or gfi.type or mlibelle), 2 - EXTRANET_CHRONO_LIBELLES(type), 3 - LIBELLINFO, 4 - ftranslate_str  */
                                    NVL(NVL((SELECT DECODE(e.typeelem,
                                                          'ms',
                                                          REPLACE(e.libelle,
                                                                  vd.chemin,
                                                                  vd.valeur_trad),
                                                          'fa',
                                                          REPLACE(UPPER(e.libelle),
                                                                  vd.chemin,
                                                                  vd.valeur_trad),
                                                          vd.valeur_trad)
                                            /* For type 'ms' replace chemin in the libelle, otherwise directlly returns translated value */
                                              FROM (SELECT vd1.abrev,
                                                           vd1.chemin,
                                                           vd1.valeur_trad,
                                                           vd1.valeur
                                                      FROM v_tdomaine vd1
                                                     WHERE vd1.type(+) =
                                                           'EXTRANET_CHRONO_LIBELLES'
                                                       AND vd1.langue(+) = :B2
                                                       AND vd1.valeur_trad IS NOT NULL
                                                     ORDER BY vd1.chemin DESC) vd
                                             WHERE vd.abrev(+) = e.typeelem
                                               AND vd.chemin =
                                                   DECODE(e.typeelem,
                                                          'en',
                                                          (SELECT ge.moyenpaimt
                                                             FROM g_encaissement ge
                                                            WHERE e.refelem =
                                                                  ge.refencaiss
                                                              AND NOT EXISTS
                                                            (SELECT 1
                                                                     FROM t_elements
                                                                    WHERE refelem =
                                                                          e.refelem
                                                                      AND e.dtannul_dt IS NULL)
                                                              AND ROWNUM < 2),
                                                          'fi',
                                                          (SELECT gfi.type
                                                             FROM g_elemfi gfi
                                                            WHERE e.refelem =
                                                                  gfi.refelem
                                                              AND ROWNUM < 2),
                                                          'fa',
                                                          (DECODE(instr(UPPER(e.libelle),
                                                                        vd.chemin),
                                                                  0,
                                                                  e.libelle,
                                                                  vd.chemin)),
                                                          'ms',
                                                          (DECODE(instr(e.libelle,
                                                                        vd.chemin),
                                                                  0,
                                                                  e.libelle,
                                                                  vd.chemin)),
                                                          /* For type 'ms' search for chemin as a part of libelle (e.g: 'RE: Message from Customer')  */
                                                          'in',
                                                          SUBSTR(e.libelle,
                                                                 0,
                                                                 LENGTH(vd.chemin))
                                                          /* translate IMXTEL */,
                                                          e.libelle)
                                               AND ROWNUM < 2),
                                            (SELECT vd3.valeur_trad
                                               FROM v_tdomaine vd3
                                              WHERE vd3.type =
                                                    'EXTRANET_CHRONO_LIBELLES'
                                                AND vd3.abrev = e.typeelem
                                                AND vd3.chemin IS NULL
                                                AND vd3.langue = :B3
                                                AND ROWNUM < 2)),
                                        /* if label starts with 'A.' then goto imx.ftranslate_str */
                                        COALESCE((SELECT v1.valeur_trad
                                                   FROM v_tdomaine v1
                                                  WHERE v1.type =
                                                        'MESSAGE_SUBJECT'
                                                    AND v1.langue = UPPER(:B4)
                                                    AND v1.valeur = e.libelle),
                                                 DECODE(SUBSTR(e.libelle, 1, 2),
                                                        'A.',
                                                        NULL,
                                                        vd2.valeur_trad),
                                                 NVL(imx.ftranslate_str(e.libelle,
                                                                        :B5,
                                                                        DECODE(e.typeelem,
                                                                               'an',
                                                                               e.abrev,
                                                                               e.typeelem)),
                                                     e.libelle))))) translatedLabel,
                        DECODE(e.typeelem, 'an', e.dtannul_dt, DTSAISIE_DT) dateSaisie,
                        NVL((SELECT Trim(i.nom || ' ' || i.prenom)
                              FROM g_individu i, g_personnel p
                             WHERE p.login = e.createur
                               AND i.refindividu = p.refindividu
                               AND ROWNUM < 2),
                            e.createur) creator,
                        DECODE(e.typeelem,
                               'fi',
                               (SELECT fa.REF_CREANCE
                                  FROM g_elemfi fa
                                 WHERE e.refelem = fa.refelem
                                   AND rownum < 2)) otherReference,
                        DECODE(e.typeelem,
                               'me',
                               NVL((SELECT '1'
                                     FROM t_mail tm, t_entmail te
                                    WHERE tm.refmail = te.refmail
                                      AND te.refmail = e.refelem
                                      AND te.sens = 'E'
                                      AND ROWNUM = 1),
                                   '0'),
                               'mr',
                               NVL((SELECT 1
                                     FROM t_mail tm, t_entmail te
                                    WHERE tm.refmail = te.refmail
                                      AND te.refmail = e.refelem
                                      AND te.sens = 'R'
                                      AND ROWNUM = 1),
                                   '0'),
                               'ms',
                               NVL((SELECT 1
                                     FROM g_information
                                    WHERE refinfo = e.refelem
                                      AND typemetteur = 'A'
                                      AND ROWNUM = 1),
                                   '0'),
                               'fi',
                               NVL((SELECT '1'
                                     FROM g_piece pie
                                    WHERE e.refelem = pie.refext
                                      AND gpiimage = 'X'
                                      AND pie.code = 'fi'
                                      AND pie.typpiece = 'IMAGE_EXTERNE'
                                      AND pie.gpiimage = 'X'
                                      AND refimage IS NOT NULL
                                      AND rownum = 1),
                                   '0'),
                               'eg',
                               NVL((SELECT '1'
                                     FROM g_piece pie
                                    WHERE (SELECT ee_maitre
                                             FROM f_entenr
                                            WHERE ee_num = e.refelem) =
                                          pie.refext
                                      AND gpiimage = 'X'
                                      AND pie.code = 'eg'
                                      AND pie.typpiece = 'IMAGE_EXTERNE'
                                      AND pie.gpiimage = 'X'
                                      AND refimage IS NOT NULL
                                      AND rownum = 1),
                                   '0'),
                               NVL((SELECT '1'
                                     FROM g_piece pie
                                    WHERE (e.refelem = pie.refpiece OR
                                          e.refelem = pie.refext)
                                      AND gpiimage = 'X'
                                      AND refimage IS NOT NULL
                                      AND rownum = 1),
                                   '0')) attachment
          FROM t_elements  e,
               g_pers_auth auth,
               v_tdomaine  vd2,
               v_tdomaine  vd_types,
               g_elemfi    gelem
         WHERE 1 = 1
           AND e.refdoss = gelem.refdoss(+)
           AND e.refelem = gelem.refelem(+)
           AND NOT EXISTS
         (SELECT gp.refpiece
                  FROM g_piece gp
                 WHERE gp.refpiece = e.refelem
                   AND NVL(gp.FG_NOT_VISIBLE_IN_XNET, 'N') = 'O')
           AND e.typeelem NOT IN ('se', 'ng', 'an', 'yy', 'et', 'xx', 'ce')
              /* prevodi  */
           AND vd2.type(+) = 'LIBELINFO'
           AND vd2.valeur(+) = DECODE(SUBSTR(e.libelle, 1, 2),
                                      'A.',
                                      SUBSTR(e.libelle, 3),
                                      e.libelle)
           AND vd2.langue(+) = :B6
              /* authorizacia po tip */
           AND auth.typeelem = DECODE(e.typeelem,
                                      'in',
                                      DECODE(vd2.valeur, NULL, 'in', 'in_s'),
                                      e.typeelem)
           AND e.refdoss = :B7
           AND auth.rowtype = 'USER'
           AND auth.refperso = :B8
              /* disable NOTHING */
           AND auth.libelle != 'NOTHING'
              /* type=1 will be excluded later */
              /* check the rest */
           AND (NOT EXISTS (SELECT 1
                              FROM g_pers_auth ex
                             WHERE ex.refperso = auth.refperso
                               AND ex.typeelem = auth.typeelem
                               AND ex.ROWTYPE = 'USER'
                               AND ex.libelle_type = 0) OR
                (NVL(auth.libelle_type, 0) = 0 AND
                (NVL(auth.libelle, 'NOTHING') = 'ALL' OR
                e.libelle LIKE auth.libelle)))
              /* exclude labels */
           AND NOT EXISTS
         (SELECT 1
                  FROM g_pers_auth ex
                 WHERE ex.refperso = auth.refperso
                   AND ex.typeelem = auth.typeelem
                   AND ex.rowtype = 'USER'
                   AND ex.libelle_type = 1
                   AND e.libelle LIKE ex.libelle)
              /* translations check */
           AND ((EXISTS
                (SELECT vd.valeur_trad
                    FROM v_tdomaine vd
                   WHERE vd.type(+) = 'EXTRANET_CHRONO_LIBELLES'
                     AND vd.abrev(+) = e.typeelem
                     AND vd.chemin = DECODE(e.typeelem,
                                            'en',
                                            (SELECT ge.moyenpaimt
                                               FROM g_encaissement ge
                                              WHERE e.refelem = ge.refencaiss
                                                AND rownum < 2),
                                            'fi',
                                            (SELECT DISTINCT gfi.type
                                               FROM g_elemfi gfi
                                              WHERE e.refelem = gfi.refelem
                                                AND rownum < 2),
                                            e.libelle)
                     AND vd.langue(+) = :B9
                     AND vd.valeur_trad IS NOT NULL)) OR
               /* when not exists, check if it is allowed to show untranslated strings */
               ((NOT EXISTS
                (SELECT 1
                     FROM v_extr_dom ve
                    WHERE ve.type = 'CHRONO_VIEW_TRANSLATED_LABELS_ONLY'
                      AND ve.abrev = auth.refperso
                      AND valeur = 'O')) AND
               (NOT EXISTS (SELECT 1
                                FROM g_pers_auth tr
                               WHERE tr.typeelem = e.typeelem
                                 AND tr.rowtype = 'USER_TRANSL'
                                 AND tr.refperso = auth.refperso
                                 AND tr.transl = 1))))
              /* translate typeelem */
           AND vd_types.type(+) = 'ELEM_CHRONO'
           AND vd_types.langue(+) = :B10
           AND vd_types.abrev(+) = e.typeelem
           AND (e.typeelem NOT IN 'ms' OR
               1 = (SELECT DECODE((SELECT 1
                                     FROM v_extr_dom
                                    WHERE TYPE = 'CHRONO_PARTY_REQUIRED'
                                      AND abrev = auth.refperso
                                      AND valeur = 'ms'
                                      AND valeur_2 = 'USER'
                                      AND rownum = 1),
                                   1,
                                   NVL((SELECT 1
                                         FROM g_information gi
                                        WHERE gi.refinfo = e.refelem
                                          AND (gi.refemetteur IN
                                              (SELECT refindividu
                                                  FROM g_personnel
                                                 WHERE refperso = auth.refperso) OR
                                              gi.encodeur IN
                                              (SELECT refindividu
                                                  FROM g_personnel
                                                 WHERE refperso = auth.refperso))),
                                       0),
                                   1)
                       FROM dual))
              /* mr,me */
           AND (e.typeelem NOT IN ('me') OR
               1 =
               (SELECT DECODE((SELECT 1
                                 FROM v_extr_dom
                                WHERE TYPE = 'CHRONO_PARTY_REQUIRED'
                                  AND abrev = auth.refperso
                                  AND valeur IN ('me')
                                  AND valeur_2 = 'USER'
                                  AND rownum = 1),
                               1,
                               NVL((SELECT 1
                                     FROM t_entmail gi, g_personnel gp
                                    WHERE gi.refmail = e.refelem
                                      AND e.typeelem = 'me'
                                      AND ((gp.email IN (gi.expediteur,
                                                         gi.destinataire,
                                                         gi.cc)) OR
                                          (gi.expediteur IN
                                          (SELECT DISTINCT numtel
                                               FROM g_telephone tel,
                                                    v_extr_dom  ind,
                                                    v_domaine   typeTel
                                              WHERE tel.refindividu =
                                                    ind.valeur
                                                AND ind.abrev = auth.refperso
                                                AND ind.TYPE =
                                                    'EXTR_GEST_CLIENT'
                                                AND typeTel.type = 'typtel'
                                                AND typeTel.ecran = 'EMAIL'
                                                AND tel.typetel = typeTel.abrev
                                                AND tel.validite = 'O')) OR
                                          (gi.destinataire IN
                                          (SELECT DISTINCT numtel
                                               FROM g_telephone tel,
                                                    v_extr_dom  ind,
                                                    v_domaine   typeTel
                                              WHERE tel.refindividu =
                                                    ind.valeur
                                                AND ind.abrev = auth.refperso
                                                AND ind.TYPE =
                                                    'EXTR_GEST_CLIENT'
                                                AND typeTel.type = 'typtel'
                                                AND typeTel.ecran = 'EMAIL'
                                                AND tel.typetel = typeTel.abrev
                                                AND tel.validite = 'O')) OR
                                          (gi.cc IN
                                          (SELECT DISTINCT numtel
                                               FROM g_telephone tel,
                                                    v_extr_dom  ind,
                                                    v_domaine   typeTel
                                              WHERE tel.refindividu =
                                                    ind.valeur
                                                AND ind.abrev = auth.refperso
                                                AND ind.TYPE =
                                                    'EXTR_GEST_CLIENT'
                                                AND typeTel.type = 'typtel'
                                                AND typeTel.ecran = 'EMAIL'
                                                AND tel.typetel = typeTel.abrev
                                                AND tel.validite = 'O')))
                                      AND gp.refperso = auth.refperso),
                                   0),
                               1)
                   FROM dual))
           AND (e.typeelem NOT IN ('mr') OR
               1 =
               (SELECT DECODE((SELECT 1
                                 FROM v_extr_dom
                                WHERE TYPE = 'CHRONO_PARTY_REQUIRED'
                                  AND abrev = auth.refperso
                                  AND valeur IN ('mr')
                                  AND valeur_2 = 'USER'
                                  AND rownum = 1),
                               1,
                               NVL((SELECT 1
                                     FROM t_entmail gi, g_personnel gp
                                    WHERE gi.refmail = e.refelem
                                      AND e.typeelem = 'mr'
                                      AND ((gp.email IN (gi.expediteur,
                                                         gi.destinataire,
                                                         gi.cc)) OR
                                          (gi.expediteur IN
                                          (SELECT DISTINCT numtel
                                               FROM g_telephone tel,
                                                    v_extr_dom  ind,
                                                    v_domaine   typeTel
                                              WHERE tel.refindividu =
                                                    ind.valeur
                                                AND ind.abrev = auth.refperso
                                                AND ind.TYPE =
                                                    'EXTR_GEST_CLIENT'
                                                AND typeTel.type = 'typtel'
                                                AND typeTel.ecran = 'EMAIL'
                                                AND tel.typetel = typeTel.abrev
                                                AND tel.validite = 'O')) OR
                                          (gi.destinataire IN
                                          (SELECT DISTINCT numtel
                                               FROM g_telephone tel,
                                                    v_extr_dom  ind,
                                                    v_domaine   typeTel
                                              WHERE tel.refindividu =
                                                    ind.valeur
                                                AND ind.abrev = auth.refperso
                                                AND ind.TYPE =
                                                    'EXTR_GEST_CLIENT'
                                                AND typeTel.type = 'typtel'
                                                AND typeTel.ecran = 'EMAIL'
                                                AND tel.typetel = typeTel.abrev
                                                AND tel.validite = 'O')) OR
                                          (gi.cc IN
                                          (SELECT DISTINCT numtel
                                               FROM g_telephone tel,
                                                    v_extr_dom  ind,
                                                    v_domaine   typeTel
                                              WHERE tel.refindividu =
                                                    ind.valeur
                                                AND ind.abrev = auth.refperso
                                                AND ind.TYPE =
                                                    'EXTR_GEST_CLIENT'
                                                AND typeTel.type = 'typtel'
                                                AND typeTel.ecran = 'EMAIL'
                                                AND tel.typetel = typeTel.abrev
                                                AND tel.validite = 'O')))
                                      AND gp.refperso = auth.refperso),
                                   0),
                               1)
                   FROM dual))
              /*dont show hidden me, mr */
           AND NOT (e.typeelem IN ('me', 'mr') AND EXISTS
                 (SELECT 1
                       FROM t_entmail
                      WHERE t_entmail.refmail = e.refelem
                        AND t_entmail.NOT_VISIBLE = 'O'))
              /*dont show hidden in, ms */
           AND NOT (e.typeelem IN ('in', 'ms') AND EXISTS
                 (SELECT 1
                       FROM g_information
                      WHERE g_information.refinfo = e.refelem
                        AND g_information.extranet_invis = 'O'))) el_info
 WHERE 1 = 1
   AND el_info.invisible != 'invis extranet'
 ORDER BY displayDate DESC;

/********************************New SQL*******************************************/
/********************************New Metrics***************************************/
/*
Plan hash value: 3832217521
---------------------------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                       | Name                        | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  |
---------------------------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                                |                             |      1 |        |  3737 (100)|     43 |00:00:00.37 |   15205 |    460 |
|*  1 |  COUNT STOPKEY                                  |                             |      9 |        |            |      8 |00:00:00.01 |      30 |      0 |
|*  2 |   TABLE ACCESS BY INDEX ROWID BATCHED           | G_PERS_AUTH                 |      9 |      1 |     1   (0)|      8 |00:00:00.01 |      30 |      0 |
|*  3 |    INDEX RANGE SCAN                             | G_PERS_AUTH_RFPER_TYPEL_IDX |      9 |      2 |     1   (0)|     11 |00:00:00.01 |      19 |      0 |
|*  4 |   COUNT STOPKEY                                 |                             |      3 |        |            |      0 |00:00:00.01 |      18 |      0 |
|*  5 |    TABLE ACCESS BY INDEX ROWID BATCHED          | G_PERS_AUTH                 |      3 |      1 |     1   (0)|      0 |00:00:00.01 |      18 |      0 |
|*  6 |     INDEX RANGE SCAN                            | G_PERS_AUTH_RFPER_TYPEL_IDX |      3 |      2 |     1   (0)|      9 |00:00:00.01 |       9 |      0 |
|*  7 |    COUNT STOPKEY                                |                             |      2 |        |            |      1 |00:00:00.01 |      17 |     10 |
|   8 |     NESTED LOOPS                                |                             |      2 |      1 |     2   (0)|      1 |00:00:00.01 |      17 |     10 |
|   9 |      NESTED LOOPS                               |                             |      2 |      2 |     2   (0)|      3 |00:00:00.01 |      14 |      7 |
|  10 |       TABLE ACCESS BY INDEX ROWID BATCHED       | EC_USER                     |      2 |      1 |     1   (0)|      2 |00:00:00.01 |       8 |      4 |
|* 11 |        INDEX RANGE SCAN                         | EC_USER_REFPERSO_IDX        |      2 |      1 |     1   (0)|      2 |00:00:00.01 |       4 |      2 |
|* 12 |       INDEX RANGE SCAN                          | G_PERS_AUTH_RFPER_TYPEL_IDX |      2 |      2 |     1   (0)|      3 |00:00:00.01 |       6 |      3 |
|* 13 |      TABLE ACCESS BY INDEX ROWID                | G_PERS_AUTH                 |      3 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |      3 |
|* 14 |     COUNT STOPKEY                               |                             |      2 |        |            |      1 |00:00:00.01 |      17 |      0 |
|  15 |      NESTED LOOPS                               |                             |      2 |      1 |     2   (0)|      1 |00:00:00.01 |      17 |      0 |
|  16 |       NESTED LOOPS                              |                             |      2 |      2 |     2   (0)|      3 |00:00:00.01 |      14 |      0 |
|  17 |        TABLE ACCESS BY INDEX ROWID BATCHED      | EC_USER                     |      2 |      1 |     1   (0)|      2 |00:00:00.01 |       8 |      0 |
|* 18 |         INDEX RANGE SCAN                        | EC_USER_REFPERSO_IDX        |      2 |      1 |     1   (0)|      2 |00:00:00.01 |       4 |      0 |
|* 19 |        INDEX RANGE SCAN                         | G_PERS_AUTH_RFPER_TYPEL_IDX |      2 |      2 |     1   (0)|      3 |00:00:00.01 |       6 |      0 |
|* 20 |       TABLE ACCESS BY INDEX ROWID               | G_PERS_AUTH                 |      3 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |      0 |
|* 21 |  COUNT STOPKEY                                  |                             |     40 |        |            |     12 |00:00:00.05 |    7140 |     59 |
|* 22 |   FILTER                                        |                             |     40 |        |            |     12 |00:00:00.05 |    7140 |     59 |
|  23 |    VIEW                                         |                             |     40 |     37 |    38   (3)|   2487 |00:00:00.04 |    7132 |     56 |
|  24 |     SORT ORDER BY                               |                             |     40 |     37 |    38   (3)|   2487 |00:00:00.04 |    7132 |     56 |
|  25 |      VIEW                                       | V_TDOMAINE                  |     40 |     37 |    37   (0)|   3808 |00:00:00.04 |    7132 |     56 |
|  26 |       UNION-ALL                                 |                             |     40 |        |            |   3808 |00:00:00.04 |    7132 |     56 |
|* 27 |        FILTER                                   |                             |     40 |        |            |      0 |00:00:00.01 |       0 |      0 |
|* 28 |         TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 29 |          INDEX RANGE SCAN                       | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 30 |        FILTER                                   |                             |     40 |        |            |   3808 |00:00:00.04 |    7132 |     56 |
|* 31 |         TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE                   |     40 |      1 |     1   (0)|   3808 |00:00:00.04 |    7132 |     56 |
|* 32 |          INDEX RANGE SCAN                       | DOM_TYPABREV                |     40 |      1 |     1   (0)|   6206 |00:00:00.01 |     132 |      2 |
|* 33 |        FILTER                                   |                             |     40 |        |            |      0 |00:00:00.01 |       0 |      0 |
|* 34 |         TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 35 |          INDEX RANGE SCAN                       | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 36 |        FILTER                                   |                             |     40 |        |            |      0 |00:00:00.01 |       0 |      0 |
|* 37 |         TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 38 |          INDEX RANGE SCAN                       | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 39 |        FILTER                                   |                             |     40 |        |            |      0 |00:00:00.01 |       0 |      0 |
|* 40 |         TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 41 |          INDEX RANGE SCAN                       | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 42 |        FILTER                                   |                             |     40 |        |            |      0 |00:00:00.01 |       0 |      0 |
|* 43 |         TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 44 |          INDEX RANGE SCAN                       | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 45 |        FILTER                                   |                             |     40 |        |            |      0 |00:00:00.01 |       0 |      0 |
|* 46 |         TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 47 |          INDEX RANGE SCAN                       | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 48 |        FILTER                                   |                             |     40 |        |            |      0 |00:00:00.01 |       0 |      0 |
|* 49 |         TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 50 |          INDEX RANGE SCAN                       | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 51 |        FILTER                                   |                             |     40 |        |            |      0 |00:00:00.01 |       0 |      0 |
|* 52 |         TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 53 |          INDEX RANGE SCAN                       | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 54 |        FILTER                                   |                             |     40 |        |            |      0 |00:00:00.01 |       0 |      0 |
|* 55 |         TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 56 |          INDEX RANGE SCAN                       | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 57 |        FILTER                                   |                             |     40 |        |            |      0 |00:00:00.01 |       0 |      0 |
|* 58 |         TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 59 |          INDEX RANGE SCAN                       | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 60 |        FILTER                                   |                             |     40 |        |            |      0 |00:00:00.01 |       0 |      0 |
|* 61 |         TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 62 |          INDEX RANGE SCAN                       | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 63 |        FILTER                                   |                             |     40 |        |            |      0 |00:00:00.01 |       0 |      0 |
|* 64 |         TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 65 |          INDEX RANGE SCAN                       | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 66 |        FILTER                                   |                             |     40 |        |            |      0 |00:00:00.01 |       0 |      0 |
|* 67 |         TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 68 |          INDEX RANGE SCAN                       | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 69 |        FILTER                                   |                             |     40 |        |            |      0 |00:00:00.01 |       0 |      0 |
|* 70 |         TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 71 |          INDEX RANGE SCAN                       | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 72 |        FILTER                                   |                             |     40 |        |            |      0 |00:00:00.01 |       0 |      0 |
|* 73 |         TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 74 |          INDEX RANGE SCAN                       | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 75 |        FILTER                                   |                             |     40 |        |            |      0 |00:00:00.01 |       0 |      0 |
|* 76 |         TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 77 |          INDEX RANGE SCAN                       | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 78 |        FILTER                                   |                             |     40 |        |            |      0 |00:00:00.01 |       0 |      0 |
|* 79 |         TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 80 |          INDEX RANGE SCAN                       | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 81 |        FILTER                                   |                             |     40 |        |            |      0 |00:00:00.01 |       0 |      0 |
|* 82 |         TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 83 |          INDEX RANGE SCAN                       | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 84 |        FILTER                                   |                             |     40 |        |            |      0 |00:00:00.01 |       0 |      0 |
|* 85 |         TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 86 |          INDEX RANGE SCAN                       | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 87 |        FILTER                                   |                             |     40 |        |            |      0 |00:00:00.01 |       0 |      0 |
|* 88 |         TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 89 |          INDEX RANGE SCAN                       | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 90 |        FILTER                                   |                             |     40 |        |            |      0 |00:00:00.01 |       0 |      0 |
|* 91 |         TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 92 |          INDEX RANGE SCAN                       | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 93 |        FILTER                                   |                             |     40 |        |            |      0 |00:00:00.01 |       0 |      0 |
|* 94 |         TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 95 |          INDEX RANGE SCAN                       | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 96 |        FILTER                                   |                             |     40 |        |            |      0 |00:00:00.01 |       0 |      0 |
|* 97 |         TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 98 |          INDEX RANGE SCAN                       | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 99 |        FILTER                                   |                             |     40 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*100 |         TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*101 |          INDEX RANGE SCAN                       | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*102 |        FILTER                                   |                             |     40 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*103 |         TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*104 |          INDEX RANGE SCAN                       | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*105 |        FILTER                                   |                             |     40 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*106 |         TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*107 |          INDEX RANGE SCAN                       | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*108 |        FILTER                                   |                             |     40 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*109 |         TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*110 |          INDEX RANGE SCAN                       | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*111 |        FILTER                                   |                             |     40 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*112 |         TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*113 |          INDEX RANGE SCAN                       | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*114 |        FILTER                                   |                             |     40 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*115 |         TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*116 |          INDEX RANGE SCAN                       | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*117 |        FILTER                                   |                             |     40 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*118 |         TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*119 |          INDEX RANGE SCAN                       | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*120 |        FILTER                                   |                             |     40 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*121 |         TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*122 |          INDEX RANGE SCAN                       | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*123 |        FILTER                                   |                             |     40 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*124 |         TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*125 |          INDEX RANGE SCAN                       | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*126 |        FILTER                                   |                             |     40 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*127 |         TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*128 |          INDEX RANGE SCAN                       | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*129 |        FILTER                                   |                             |     40 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*130 |         TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*131 |          INDEX RANGE SCAN                       | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*132 |        FILTER                                   |                             |     40 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*133 |         TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*134 |          INDEX RANGE SCAN                       | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*135 |        FILTER                                   |                             |     40 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*136 |         TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*137 |          INDEX RANGE SCAN                       | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*138 |    COUNT STOPKEY                                |                             |      1 |        |            |      0 |00:00:00.01 |       8 |      3 |
|*139 |     FILTER                                      |                             |      1 |        |            |      0 |00:00:00.01 |       8 |      3 |
| 140 |      TABLE ACCESS BY INDEX ROWID                | G_ENCAISSEMENT              |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       4 |      0 |
|*141 |       INDEX UNIQUE SCAN                         | REFENCAISS                  |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |      0 |
|*142 |      FILTER                                     |                             |      1 |        |            |      1 |00:00:00.01 |       4 |      3 |
|*143 |       INDEX RANGE SCAN                          | ELE_ELEMTYPE                |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       4 |      3 |
|*144 |    COUNT STOPKEY                                |                             |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 145 |     TABLE ACCESS BY INDEX ROWID                 | G_ELEMFI                    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*146 |      INDEX UNIQUE SCAN                          | EFI_REFELEM                 |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*147 |   COUNT STOPKEY                                 |                             |      8 |        |            |      0 |00:00:00.01 |     346 |      0 |
| 148 |    VIEW                                         | V_TDOMAINE                  |      8 |     37 |    37   (0)|      0 |00:00:00.01 |     346 |      0 |
| 149 |     UNION-ALL                                   |                             |      8 |        |            |      0 |00:00:00.01 |     346 |      0 |
|*150 |      FILTER                                     |                             |      8 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*151 |       TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*152 |        INDEX RANGE SCAN                         | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*153 |      FILTER                                     |                             |      8 |        |            |      0 |00:00:00.01 |     346 |      0 |
|*154 |       TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE                   |      8 |      1 |     1   (0)|      0 |00:00:00.01 |     346 |      0 |
|*155 |        INDEX RANGE SCAN                         | DOM_TYPABREV                |      8 |      1 |     1   (0)|    284 |00:00:00.01 |      26 |      0 |
|*156 |      FILTER                                     |                             |      8 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*157 |       TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*158 |        INDEX RANGE SCAN                         | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*159 |      FILTER                                     |                             |      8 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*160 |       TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*161 |        INDEX RANGE SCAN                         | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*162 |      FILTER                                     |                             |      8 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*163 |       TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*164 |        INDEX RANGE SCAN                         | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*165 |      FILTER                                     |                             |      8 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*166 |       TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*167 |        INDEX RANGE SCAN                         | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*168 |      FILTER                                     |                             |      8 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*169 |       TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*170 |        INDEX RANGE SCAN                         | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*171 |      FILTER                                     |                             |      8 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*172 |       TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*173 |        INDEX RANGE SCAN                         | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*174 |      FILTER                                     |                             |      8 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*175 |       TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*176 |        INDEX RANGE SCAN                         | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*177 |      FILTER                                     |                             |      8 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*178 |       TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*179 |        INDEX RANGE SCAN                         | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*180 |      FILTER                                     |                             |      8 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*181 |       TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*182 |        INDEX RANGE SCAN                         | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*183 |      FILTER                                     |                             |      8 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*184 |       TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*185 |        INDEX RANGE SCAN                         | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*186 |      FILTER                                     |                             |      8 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*187 |       TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*188 |        INDEX RANGE SCAN                         | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*189 |      FILTER                                     |                             |      8 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*190 |       TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*191 |        INDEX RANGE SCAN                         | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*192 |      FILTER                                     |                             |      8 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*193 |       TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*194 |        INDEX RANGE SCAN                         | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*195 |      FILTER                                     |                             |      8 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*196 |       TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*197 |        INDEX RANGE SCAN                         | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*198 |      FILTER                                     |                             |      8 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*199 |       TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*200 |        INDEX RANGE SCAN                         | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*201 |      FILTER                                     |                             |      8 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*202 |       TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*203 |        INDEX RANGE SCAN                         | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*204 |      FILTER                                     |                             |      8 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*205 |       TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*206 |        INDEX RANGE SCAN                         | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*207 |      FILTER                                     |                             |      8 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*208 |       TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*209 |        INDEX RANGE SCAN                         | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*210 |      FILTER                                     |                             |      8 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*211 |       TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*212 |        INDEX RANGE SCAN                         | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*213 |      FILTER                                     |                             |      8 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*214 |       TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*215 |        INDEX RANGE SCAN                         | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*216 |      FILTER                                     |                             |      8 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*217 |       TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*218 |        INDEX RANGE SCAN                         | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*219 |      FILTER                                     |                             |      8 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*220 |       TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*221 |        INDEX RANGE SCAN                         | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*222 |      FILTER                                     |                             |      8 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*223 |       TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*224 |        INDEX RANGE SCAN                         | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*225 |      FILTER                                     |                             |      8 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*226 |       TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*227 |        INDEX RANGE SCAN                         | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*228 |      FILTER                                     |                             |      8 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*229 |       TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*230 |        INDEX RANGE SCAN                         | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*231 |      FILTER                                     |                             |      8 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*232 |       TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*233 |        INDEX RANGE SCAN                         | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*234 |      FILTER                                     |                             |      8 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*235 |       TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*236 |        INDEX RANGE SCAN                         | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*237 |      FILTER                                     |                             |      8 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*238 |       TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*239 |        INDEX RANGE SCAN                         | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*240 |      FILTER                                     |                             |      8 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*241 |       TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*242 |        INDEX RANGE SCAN                         | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*243 |      FILTER                                     |                             |      8 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*244 |       TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*245 |        INDEX RANGE SCAN                         | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*246 |      FILTER                                     |                             |      8 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*247 |       TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*248 |        INDEX RANGE SCAN                         | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*249 |      FILTER                                     |                             |      8 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*250 |       TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*251 |        INDEX RANGE SCAN                         | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*252 |      FILTER                                     |                             |      8 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*253 |       TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*254 |        INDEX RANGE SCAN                         | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*255 |      FILTER                                     |                             |      8 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*256 |       TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*257 |        INDEX RANGE SCAN                         | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*258 |      FILTER                                     |                             |      8 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*259 |       TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*260 |        INDEX RANGE SCAN                         | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 261 |    VIEW                                         | V_TDOMAINE                  |     34 |     37 |    37   (0)|      0 |00:00:00.03 |     102 |     26 |
| 262 |     UNION-ALL                                   |                             |     34 |        |            |      0 |00:00:00.03 |     102 |     26 |
|*263 |      FILTER                                     |                             |     34 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 264 |       TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*265 |        INDEX RANGE SCAN                         | DOM_TYPVAL                  |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*266 |      FILTER                                     |                             |     34 |        |            |      0 |00:00:00.03 |     102 |     26 |
| 267 |       TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE                   |     34 |      1 |     1   (0)|      0 |00:00:00.03 |     102 |     26 |
|*268 |        INDEX RANGE SCAN                         | DOM_TYPVAL                  |     34 |      2 |     1   (0)|      0 |00:00:00.03 |     102 |     26 |
|*269 |      FILTER                                     |                             |     34 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 270 |       TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*271 |        INDEX RANGE SCAN                         | DOM_TYPVAL                  |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*272 |      FILTER                                     |                             |     34 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 273 |       TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*274 |        INDEX RANGE SCAN                         | DOM_TYPVAL                  |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*275 |      FILTER                                     |                             |     34 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 276 |       TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*277 |        INDEX RANGE SCAN                         | DOM_TYPVAL                  |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*278 |      FILTER                                     |                             |     34 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 279 |       TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*280 |        INDEX RANGE SCAN                         | DOM_TYPVAL                  |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*281 |      FILTER                                     |                             |     34 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 282 |       TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*283 |        INDEX RANGE SCAN                         | DOM_TYPVAL                  |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*284 |      FILTER                                     |                             |     34 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 285 |       TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*286 |        INDEX RANGE SCAN                         | DOM_TYPVAL                  |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*287 |      FILTER                                     |                             |     34 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 288 |       TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*289 |        INDEX RANGE SCAN                         | DOM_TYPVAL                  |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*290 |      FILTER                                     |                             |     34 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 291 |       TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*292 |        INDEX RANGE SCAN                         | DOM_TYPVAL                  |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*293 |      FILTER                                     |                             |     34 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 294 |       TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*295 |        INDEX RANGE SCAN                         | DOM_TYPVAL                  |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*296 |      FILTER                                     |                             |     34 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 297 |       TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*298 |        INDEX RANGE SCAN                         | DOM_TYPVAL                  |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*299 |      FILTER                                     |                             |     34 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 300 |       TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*301 |        INDEX RANGE SCAN                         | DOM_TYPVAL                  |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*302 |      FILTER                                     |                             |     34 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 303 |       TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*304 |        INDEX RANGE SCAN                         | DOM_TYPVAL                  |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*305 |      FILTER                                     |                             |     34 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 306 |       TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*307 |        INDEX RANGE SCAN                         | DOM_TYPVAL                  |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*308 |      FILTER                                     |                             |     34 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 309 |       TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*310 |        INDEX RANGE SCAN                         | DOM_TYPVAL                  |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*311 |      FILTER                                     |                             |     34 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 312 |       TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*313 |        INDEX RANGE SCAN                         | DOM_TYPVAL                  |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*314 |      FILTER                                     |                             |     34 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 315 |       TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*316 |        INDEX RANGE SCAN                         | DOM_TYPVAL                  |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*317 |      FILTER                                     |                             |     34 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 318 |       TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*319 |        INDEX RANGE SCAN                         | DOM_TYPVAL                  |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*320 |      FILTER                                     |                             |     34 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 321 |       TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*322 |        INDEX RANGE SCAN                         | DOM_TYPVAL                  |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*323 |      FILTER                                     |                             |     34 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 324 |       TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*325 |        INDEX RANGE SCAN                         | DOM_TYPVAL                  |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*326 |      FILTER                                     |                             |     34 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 327 |       TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*328 |        INDEX RANGE SCAN                         | DOM_TYPVAL                  |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*329 |      FILTER                                     |                             |     34 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 330 |       TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*331 |        INDEX RANGE SCAN                         | DOM_TYPVAL                  |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*332 |      FILTER                                     |                             |     34 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 333 |       TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*334 |        INDEX RANGE SCAN                         | DOM_TYPVAL                  |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*335 |      FILTER                                     |                             |     34 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 336 |       TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*337 |        INDEX RANGE SCAN                         | DOM_TYPVAL                  |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*338 |      FILTER                                     |                             |     34 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 339 |       TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*340 |        INDEX RANGE SCAN                         | DOM_TYPVAL                  |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*341 |      FILTER                                     |                             |     34 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 342 |       TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*343 |        INDEX RANGE SCAN                         | DOM_TYPVAL                  |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*344 |      FILTER                                     |                             |     34 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 345 |       TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*346 |        INDEX RANGE SCAN                         | DOM_TYPVAL                  |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*347 |      FILTER                                     |                             |     34 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 348 |       TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*349 |        INDEX RANGE SCAN                         | DOM_TYPVAL                  |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*350 |      FILTER                                     |                             |     34 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 351 |       TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*352 |        INDEX RANGE SCAN                         | DOM_TYPVAL                  |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*353 |      FILTER                                     |                             |     34 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 354 |       TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*355 |        INDEX RANGE SCAN                         | DOM_TYPVAL                  |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*356 |      FILTER                                     |                             |     34 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 357 |       TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*358 |        INDEX RANGE SCAN                         | DOM_TYPVAL                  |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*359 |      FILTER                                     |                             |     34 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 360 |       TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*361 |        INDEX RANGE SCAN                         | DOM_TYPVAL                  |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*362 |      FILTER                                     |                             |     34 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 363 |       TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*364 |        INDEX RANGE SCAN                         | DOM_TYPVAL                  |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*365 |      FILTER                                     |                             |     34 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 366 |       TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*367 |        INDEX RANGE SCAN                         | DOM_TYPVAL                  |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*368 |      FILTER                                     |                             |     34 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 369 |       TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*370 |        INDEX RANGE SCAN                         | DOM_TYPVAL                  |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*371 |      FILTER                                     |                             |     34 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 372 |       TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*373 |        INDEX RANGE SCAN                         | DOM_TYPVAL                  |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*374 |  COUNT STOPKEY                                  |                             |      7 |        |            |      0 |00:00:00.01 |      12 |      5 |
| 375 |   NESTED LOOPS                                  |                             |      7 |      1 |     2   (0)|      0 |00:00:00.01 |      12 |      5 |
| 376 |    NESTED LOOPS                                 |                             |      7 |      1 |     2   (0)|      0 |00:00:00.01 |      12 |      5 |
| 377 |     TABLE ACCESS BY INDEX ROWID BATCHED         | G_PERSONNEL                 |      7 |      1 |     1   (0)|      0 |00:00:00.01 |      12 |      5 |
|*378 |      INDEX RANGE SCAN                           | GPERSLOGIN                  |      7 |      1 |     1   (0)|      0 |00:00:00.01 |      12 |      5 |
|*379 |     INDEX UNIQUE SCAN                           | IND_REFINDIV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 380 |    TABLE ACCESS BY INDEX ROWID                  | G_INDIVIDU                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*381 |  COUNT STOPKEY                                  |                             |      7 |        |            |      7 |00:00:00.01 |      28 |      0 |
| 382 |   TABLE ACCESS BY INDEX ROWID                   | G_ELEMFI                    |      7 |      1 |     1   (0)|      7 |00:00:00.01 |      28 |      0 |
|*383 |    INDEX UNIQUE SCAN                            | EFI_REFELEM                 |      7 |      1 |     1   (0)|      7 |00:00:00.01 |      21 |      0 |
|*384 |  COUNT STOPKEY                                  |                             |      4 |        |            |      3 |00:00:00.01 |      28 |      7 |
| 385 |   NESTED LOOPS                                  |                             |      4 |      1 |     2   (0)|      3 |00:00:00.01 |      28 |      7 |
|*386 |    TABLE ACCESS BY INDEX ROWID                  | T_ENTMAIL                   |      4 |      1 |     1   (0)|      4 |00:00:00.01 |      16 |      0 |
|*387 |     INDEX UNIQUE SCAN                           | PK_MAIL                     |      4 |      1 |     1   (0)|      4 |00:00:00.01 |      12 |      0 |
|*388 |    INDEX RANGE SCAN                             | MAILREFM                    |      4 |      1 |     1   (0)|      3 |00:00:00.01 |      12 |      7 |
|*389 |   COUNT STOPKEY                                 |                             |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 390 |    NESTED LOOPS                                 |                             |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*391 |     TABLE ACCESS BY INDEX ROWID                 | T_ENTMAIL                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*392 |      INDEX UNIQUE SCAN                          | PK_MAIL                     |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*393 |     INDEX RANGE SCAN                            | MAILREFM                    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*394 |    COUNT STOPKEY                                |                             |      1 |        |            |      1 |00:00:00.01 |       4 |      0 |
|*395 |     TABLE ACCESS BY INDEX ROWID                 | G_INFORMATION               |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       4 |      0 |
|*396 |      INDEX UNIQUE SCAN                          | REF_INFORMATION             |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |      0 |
|*397 |     COUNT STOPKEY                               |                             |      7 |        |            |      0 |00:00:00.01 |      21 |      2 |
|*398 |      TABLE ACCESS BY INDEX ROWID BATCHED        | G_PIECE                     |      7 |      1 |     1   (0)|      0 |00:00:00.01 |      21 |      2 |
|*399 |       INDEX RANGE SCAN                          | PIECE_REFEXT_IDX            |      7 |      1 |     1   (0)|      0 |00:00:00.01 |      21 |      2 |
|*400 |      COUNT STOPKEY                              |                             |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*401 |       TABLE ACCESS BY INDEX ROWID BATCHED       | G_PIECE                     |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*402 |        INDEX RANGE SCAN                         | PIECE_REFEXT_IDX            |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 403 |         TABLE ACCESS BY INDEX ROWID             | F_ENTENR                    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*404 |          INDEX UNIQUE SCAN                      | PK_F_ENTENR                 |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*405 |       COUNT STOPKEY                             |                             |     31 |        |            |      1 |00:00:00.01 |     158 |     13 |
| 406 |        CONCATENATION                            |                             |     31 |        |            |      1 |00:00:00.01 |     158 |     13 |
|*407 |         FILTER                                  |                             |     31 |        |            |      1 |00:00:00.01 |      64 |      0 |
|*408 |          TABLE ACCESS BY INDEX ROWID BATCHED    | G_PIECE                     |     31 |      1 |     1   (0)|      1 |00:00:00.01 |      64 |      0 |
|*409 |           INDEX RANGE SCAN                      | PIE_REFPIECE                |     31 |      1 |     1   (0)|      2 |00:00:00.01 |      60 |      0 |
|*410 |         FILTER                                  |                             |     30 |        |            |      0 |00:00:00.01 |      94 |     13 |
|*411 |          TABLE ACCESS BY INDEX ROWID BATCHED    | G_PIECE                     |     30 |      1 |     1   (0)|      0 |00:00:00.01 |      94 |     13 |
|*412 |           INDEX RANGE SCAN                      | PIECE_REFEXT_IDX            |     30 |      1 |     1   (0)|      0 |00:00:00.01 |      94 |     13 |
| 413 |  SORT ORDER BY                                  |                             |      1 |      1 |  3737   (1)|     43 |00:00:00.37 |   15205 |    460 |
| 414 |   VIEW                                          |                             |      1 |      1 |  3736   (1)|     43 |00:00:00.37 |   15205 |    460 |
| 415 |    HASH UNIQUE                                  |                             |      1 |      1 |  3736   (1)|     43 |00:00:00.37 |   15205 |    460 |
|*416 |     FILTER                                      |                             |      1 |        |            |     49 |00:00:00.24 |    7284 |    338 |
|*417 |      HASH JOIN RIGHT ANTI                       |                             |      1 |    193 |    80   (0)|     66 |00:00:00.14 |     403 |    226 |
|*418 |       TABLE ACCESS BY INDEX ROWID BATCHED       | G_PERS_AUTH                 |      1 |      5 |     1   (0)|      3 |00:00:00.01 |      19 |     16 |
|*419 |        INDEX RANGE SCAN                         | G_PERS_AUTH_RFPER_TYPEL_IDX |      1 |     45 |     1   (0)|     31 |00:00:00.01 |       3 |      3 |
|*420 |       HASH JOIN                                 |                             |      1 |    193 |    79   (0)|     81 |00:00:00.13 |     384 |    210 |
|*421 |        TABLE ACCESS BY INDEX ROWID BATCHED      | G_PERS_AUTH                 |      1 |      9 |     1   (0)|     20 |00:00:00.01 |      20 |      0 |
|*422 |         INDEX RANGE SCAN                        | G_PERS_AUTH_RFPER_TYPEL_IDX |      1 |     45 |     1   (0)|     31 |00:00:00.01 |       3 |      0 |
|*423 |        FILTER                                   |                             |      1 |        |            |     67 |00:00:00.13 |     364 |    210 |
|*424 |         HASH JOIN OUTER                         |                             |      1 |    687 |    78   (0)|     67 |00:00:00.13 |     364 |    210 |
|*425 |          HASH JOIN OUTER                        |                             |      1 |     19 |    41   (0)|     67 |00:00:00.09 |     237 |     94 |
| 426 |           NESTED LOOPS OUTER                    |                             |      1 |      1 |     4   (0)|     67 |00:00:00.08 |     207 |     72 |
| 427 |            NESTED LOOPS ANTI                    |                             |      1 |      1 |     3   (0)|     67 |00:00:00.07 |     132 |     61 |
| 428 |             TABLE ACCESS BY INDEX ROWID BATCHED | T_ELEMENTS                  |      1 |     51 |     1   (0)|     67 |00:00:00.06 |      62 |     53 |
|*429 |              INDEX RANGE SCAN                   | ELE_ELEMDOSS                |      1 |     51 |     1   (0)|     67 |00:00:00.01 |       4 |      2 |
|*430 |             TABLE ACCESS BY INDEX ROWID BATCHED | G_PIECE                     |     67 |  90066 |     1   (0)|      0 |00:00:00.01 |      70 |      8 |
|*431 |              INDEX RANGE SCAN                   | PIE_REFPIECE                |     67 |      1 |     1   (0)|      2 |00:00:00.01 |      62 |      6 |
|*432 |            TABLE ACCESS BY INDEX ROWID          | G_ELEMFI                    |     67 |      1 |     1   (0)|      7 |00:00:00.01 |      75 |     11 |
|*433 |             INDEX UNIQUE SCAN                   | EFI_REFELEM                 |     67 |      1 |     1   (0)|      7 |00:00:00.01 |      68 |      7 |
| 434 |           VIEW                                  | V_TDOMAINE                  |      1 |   2479 |    37   (0)|     23 |00:00:00.01 |      30 |     22 |
| 435 |            UNION-ALL                            |                             |      1 |        |            |     23 |00:00:00.01 |      30 |     22 |
|*436 |             FILTER                              |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*437 |              TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE                   |      0 |     67 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*438 |               INDEX RANGE SCAN                  | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*439 |             FILTER                              |                             |      1 |        |            |     23 |00:00:00.01 |      30 |     22 |
|*440 |              TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE                   |      1 |     67 |     1   (0)|     23 |00:00:00.01 |      30 |     22 |
|*441 |               INDEX RANGE SCAN                  | V_DOMAINE_TYPE_CODE_IDX     |      1 |     77 |     1   (0)|     25 |00:00:00.01 |       4 |      3 |
|*442 |             FILTER                              |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*443 |              TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE                   |      0 |     67 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*444 |               INDEX RANGE SCAN                  | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*445 |             FILTER                              |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*446 |              TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE                   |      0 |     67 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*447 |               INDEX RANGE SCAN                  | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*448 |             FILTER                              |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*449 |              TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE                   |      0 |     67 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*450 |               INDEX RANGE SCAN                  | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*451 |             FILTER                              |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*452 |              TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE                   |      0 |     67 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*453 |               INDEX RANGE SCAN                  | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*454 |             FILTER                              |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*455 |              TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE                   |      0 |     67 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*456 |               INDEX RANGE SCAN                  | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*457 |             FILTER                              |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*458 |              TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE                   |      0 |     67 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*459 |               INDEX RANGE SCAN                  | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*460 |             FILTER                              |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*461 |              TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE                   |      0 |     67 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*462 |               INDEX RANGE SCAN                  | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*463 |             FILTER                              |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*464 |              TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE                   |      0 |     67 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*465 |               INDEX RANGE SCAN                  | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*466 |             FILTER                              |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*467 |              TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE                   |      0 |     67 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*468 |               INDEX RANGE SCAN                  | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*469 |             FILTER                              |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*470 |              TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE                   |      0 |     67 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*471 |               INDEX RANGE SCAN                  | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*472 |             FILTER                              |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*473 |              TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE                   |      0 |     67 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*474 |               INDEX RANGE SCAN                  | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*475 |             FILTER                              |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*476 |              TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE                   |      0 |     67 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*477 |               INDEX RANGE SCAN                  | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*478 |             FILTER                              |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*479 |              TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE                   |      0 |     67 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*480 |               INDEX RANGE SCAN                  | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*481 |             FILTER                              |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*482 |              TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE                   |      0 |     67 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*483 |               INDEX RANGE SCAN                  | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*484 |             FILTER                              |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*485 |              TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE                   |      0 |     67 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*486 |               INDEX RANGE SCAN                  | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*487 |             FILTER                              |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*488 |              TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE                   |      0 |     67 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*489 |               INDEX RANGE SCAN                  | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*490 |             FILTER                              |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*491 |              TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE                   |      0 |     67 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*492 |               INDEX RANGE SCAN                  | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*493 |             FILTER                              |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*494 |              TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE                   |      0 |     67 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*495 |               INDEX RANGE SCAN                  | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*496 |             FILTER                              |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*497 |              TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE                   |      0 |     67 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*498 |               INDEX RANGE SCAN                  | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*499 |             FILTER                              |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*500 |              TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE                   |      0 |     67 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*501 |               INDEX RANGE SCAN                  | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*502 |             FILTER                              |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*503 |              TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE                   |      0 |     67 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*504 |               INDEX RANGE SCAN                  | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*505 |             FILTER                              |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*506 |              TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE                   |      0 |     67 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*507 |               INDEX RANGE SCAN                  | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*508 |             FILTER                              |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*509 |              TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE                   |      0 |     67 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*510 |               INDEX RANGE SCAN                  | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*511 |             FILTER                              |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*512 |              TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE                   |      0 |     67 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*513 |               INDEX RANGE SCAN                  | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*514 |             FILTER                              |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*515 |              TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE                   |      0 |     67 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*516 |               INDEX RANGE SCAN                  | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*517 |             FILTER                              |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*518 |              TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE                   |      0 |     67 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*519 |               INDEX RANGE SCAN                  | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*520 |             FILTER                              |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*521 |              TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE                   |      0 |     67 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*522 |               INDEX RANGE SCAN                  | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*523 |             FILTER                              |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*524 |              TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE                   |      0 |     67 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*525 |               INDEX RANGE SCAN                  | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*526 |             FILTER                              |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*527 |              TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE                   |      0 |     67 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*528 |               INDEX RANGE SCAN                  | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*529 |             FILTER                              |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*530 |              TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE                   |      0 |     67 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*531 |               INDEX RANGE SCAN                  | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*532 |             FILTER                              |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*533 |              TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE                   |      0 |     67 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*534 |               INDEX RANGE SCAN                  | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*535 |             FILTER                              |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*536 |              TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE                   |      0 |     67 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*537 |               INDEX RANGE SCAN                  | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*538 |             FILTER                              |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*539 |              TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE                   |      0 |     67 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*540 |               INDEX RANGE SCAN                  | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*541 |             FILTER                              |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*542 |              TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE                   |      0 |     67 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*543 |               INDEX RANGE SCAN                  | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*544 |             FILTER                              |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*545 |              TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE                   |      0 |     67 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*546 |               INDEX RANGE SCAN                  | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 547 |          VIEW                                   | V_TDOMAINE                  |      1 |   2849 |    37   (0)|    563 |00:00:00.04 |     127 |    116 |
| 548 |           UNION-ALL                             |                             |      1 |        |            |    563 |00:00:00.04 |     127 |    116 |
|*549 |            FILTER                               |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 550 |             TABLE ACCESS BY INDEX ROWID BATCHED | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*551 |              INDEX RANGE SCAN                   | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*552 |            FILTER                               |                             |      1 |        |            |    563 |00:00:00.04 |     127 |    116 |
| 553 |             TABLE ACCESS BY INDEX ROWID BATCHED | V_DOMAINE                   |      1 |     77 |     1   (0)|    563 |00:00:00.04 |     127 |    116 |
|*554 |              INDEX RANGE SCAN                   | V_DOMAINE_TYPE_CODE_IDX     |      1 |     77 |     1   (0)|    563 |00:00:00.01 |       9 |      7 |
|*555 |            FILTER                               |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 556 |             TABLE ACCESS BY INDEX ROWID BATCHED | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*557 |              INDEX RANGE SCAN                   | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*558 |            FILTER                               |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 559 |             TABLE ACCESS BY INDEX ROWID BATCHED | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*560 |              INDEX RANGE SCAN                   | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*561 |            FILTER                               |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 562 |             TABLE ACCESS BY INDEX ROWID BATCHED | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*563 |              INDEX RANGE SCAN                   | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*564 |            FILTER                               |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 565 |             TABLE ACCESS BY INDEX ROWID BATCHED | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*566 |              INDEX RANGE SCAN                   | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*567 |            FILTER                               |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 568 |             TABLE ACCESS BY INDEX ROWID BATCHED | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*569 |              INDEX RANGE SCAN                   | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*570 |            FILTER                               |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 571 |             TABLE ACCESS BY INDEX ROWID BATCHED | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*572 |              INDEX RANGE SCAN                   | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*573 |            FILTER                               |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 574 |             TABLE ACCESS BY INDEX ROWID BATCHED | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*575 |              INDEX RANGE SCAN                   | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*576 |            FILTER                               |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 577 |             TABLE ACCESS BY INDEX ROWID BATCHED | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*578 |              INDEX RANGE SCAN                   | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*579 |            FILTER                               |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 580 |             TABLE ACCESS BY INDEX ROWID BATCHED | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*581 |              INDEX RANGE SCAN                   | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*582 |            FILTER                               |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 583 |             TABLE ACCESS BY INDEX ROWID BATCHED | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*584 |              INDEX RANGE SCAN                   | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*585 |            FILTER                               |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 586 |             TABLE ACCESS BY INDEX ROWID BATCHED | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*587 |              INDEX RANGE SCAN                   | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*588 |            FILTER                               |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 589 |             TABLE ACCESS BY INDEX ROWID BATCHED | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*590 |              INDEX RANGE SCAN                   | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*591 |            FILTER                               |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 592 |             TABLE ACCESS BY INDEX ROWID BATCHED | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*593 |              INDEX RANGE SCAN                   | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*594 |            FILTER                               |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 595 |             TABLE ACCESS BY INDEX ROWID BATCHED | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*596 |              INDEX RANGE SCAN                   | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*597 |            FILTER                               |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 598 |             TABLE ACCESS BY INDEX ROWID BATCHED | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*599 |              INDEX RANGE SCAN                   | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*600 |            FILTER                               |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 601 |             TABLE ACCESS BY INDEX ROWID BATCHED | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*602 |              INDEX RANGE SCAN                   | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*603 |            FILTER                               |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 604 |             TABLE ACCESS BY INDEX ROWID BATCHED | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*605 |              INDEX RANGE SCAN                   | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*606 |            FILTER                               |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 607 |             TABLE ACCESS BY INDEX ROWID BATCHED | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*608 |              INDEX RANGE SCAN                   | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*609 |            FILTER                               |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 610 |             TABLE ACCESS BY INDEX ROWID BATCHED | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*611 |              INDEX RANGE SCAN                   | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*612 |            FILTER                               |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 613 |             TABLE ACCESS BY INDEX ROWID BATCHED | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*614 |              INDEX RANGE SCAN                   | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*615 |            FILTER                               |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 616 |             TABLE ACCESS BY INDEX ROWID BATCHED | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*617 |              INDEX RANGE SCAN                   | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*618 |            FILTER                               |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 619 |             TABLE ACCESS BY INDEX ROWID BATCHED | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*620 |              INDEX RANGE SCAN                   | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*621 |            FILTER                               |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 622 |             TABLE ACCESS BY INDEX ROWID BATCHED | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*623 |              INDEX RANGE SCAN                   | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*624 |            FILTER                               |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 625 |             TABLE ACCESS BY INDEX ROWID BATCHED | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*626 |              INDEX RANGE SCAN                   | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*627 |            FILTER                               |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 628 |             TABLE ACCESS BY INDEX ROWID BATCHED | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*629 |              INDEX RANGE SCAN                   | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*630 |            FILTER                               |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 631 |             TABLE ACCESS BY INDEX ROWID BATCHED | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*632 |              INDEX RANGE SCAN                   | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*633 |            FILTER                               |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 634 |             TABLE ACCESS BY INDEX ROWID BATCHED | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*635 |              INDEX RANGE SCAN                   | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*636 |            FILTER                               |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 637 |             TABLE ACCESS BY INDEX ROWID BATCHED | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*638 |              INDEX RANGE SCAN                   | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*639 |            FILTER                               |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 640 |             TABLE ACCESS BY INDEX ROWID BATCHED | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*641 |              INDEX RANGE SCAN                   | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*642 |            FILTER                               |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 643 |             TABLE ACCESS BY INDEX ROWID BATCHED | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*644 |              INDEX RANGE SCAN                   | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*645 |            FILTER                               |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 646 |             TABLE ACCESS BY INDEX ROWID BATCHED | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*647 |              INDEX RANGE SCAN                   | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*648 |            FILTER                               |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 649 |             TABLE ACCESS BY INDEX ROWID BATCHED | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*650 |              INDEX RANGE SCAN                   | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*651 |            FILTER                               |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 652 |             TABLE ACCESS BY INDEX ROWID BATCHED | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*653 |              INDEX RANGE SCAN                   | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*654 |            FILTER                               |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 655 |             TABLE ACCESS BY INDEX ROWID BATCHED | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*656 |              INDEX RANGE SCAN                   | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*657 |            FILTER                               |                             |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 658 |             TABLE ACCESS BY INDEX ROWID BATCHED | V_DOMAINE                   |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*659 |              INDEX RANGE SCAN                   | V_DOMAINE_TYPE_CODE_IDX     |      0 |     77 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*660 |      FILTER                                     |                             |     51 |        |            |     12 |00:00:00.02 |    6633 |      9 |
| 661 |       VIEW                                      | V_TDOMAINE                  |     51 |     37 |    37   (0)|   3572 |00:00:00.01 |    6629 |      5 |
| 662 |        UNION-ALL                                |                             |     51 |        |            |   3572 |00:00:00.01 |    6629 |      5 |
|*663 |         FILTER                                  |                             |     51 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*664 |          TABLE ACCESS BY INDEX ROWID BATCHED    | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*665 |           INDEX RANGE SCAN                      | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*666 |         FILTER                                  |                             |     51 |        |            |   3572 |00:00:00.01 |    6629 |      5 |
|*667 |          TABLE ACCESS BY INDEX ROWID BATCHED    | V_DOMAINE                   |     51 |      1 |     1   (0)|   3572 |00:00:00.01 |    6629 |      5 |
|*668 |           INDEX RANGE SCAN                      | DOM_TYPABREV                |     51 |      1 |     1   (0)|   5001 |00:00:00.01 |     161 |      1 |
|*669 |         FILTER                                  |                             |     39 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*670 |          TABLE ACCESS BY INDEX ROWID BATCHED    | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*671 |           INDEX RANGE SCAN                      | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*672 |         FILTER                                  |                             |     39 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*673 |          TABLE ACCESS BY INDEX ROWID BATCHED    | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*674 |           INDEX RANGE SCAN                      | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*675 |         FILTER                                  |                             |     39 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*676 |          TABLE ACCESS BY INDEX ROWID BATCHED    | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*677 |           INDEX RANGE SCAN                      | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*678 |         FILTER                                  |                             |     39 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*679 |          TABLE ACCESS BY INDEX ROWID BATCHED    | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*680 |           INDEX RANGE SCAN                      | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*681 |         FILTER                                  |                             |     39 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*682 |          TABLE ACCESS BY INDEX ROWID BATCHED    | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*683 |           INDEX RANGE SCAN                      | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*684 |         FILTER                                  |                             |     39 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*685 |          TABLE ACCESS BY INDEX ROWID BATCHED    | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*686 |           INDEX RANGE SCAN                      | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*687 |         FILTER                                  |                             |     39 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*688 |          TABLE ACCESS BY INDEX ROWID BATCHED    | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*689 |           INDEX RANGE SCAN                      | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*690 |         FILTER                                  |                             |     39 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*691 |          TABLE ACCESS BY INDEX ROWID BATCHED    | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*692 |           INDEX RANGE SCAN                      | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*693 |         FILTER                                  |                             |     39 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*694 |          TABLE ACCESS BY INDEX ROWID BATCHED    | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*695 |           INDEX RANGE SCAN                      | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*696 |         FILTER                                  |                             |     39 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*697 |          TABLE ACCESS BY INDEX ROWID BATCHED    | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*698 |           INDEX RANGE SCAN                      | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*699 |         FILTER                                  |                             |     39 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*700 |          TABLE ACCESS BY INDEX ROWID BATCHED    | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*701 |           INDEX RANGE SCAN                      | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*702 |         FILTER                                  |                             |     39 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*703 |          TABLE ACCESS BY INDEX ROWID BATCHED    | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*704 |           INDEX RANGE SCAN                      | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*705 |         FILTER                                  |                             |     39 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*706 |          TABLE ACCESS BY INDEX ROWID BATCHED    | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*707 |           INDEX RANGE SCAN                      | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*708 |         FILTER                                  |                             |     39 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*709 |          TABLE ACCESS BY INDEX ROWID BATCHED    | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*710 |           INDEX RANGE SCAN                      | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*711 |         FILTER                                  |                             |     39 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*712 |          TABLE ACCESS BY INDEX ROWID BATCHED    | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*713 |           INDEX RANGE SCAN                      | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*714 |         FILTER                                  |                             |     39 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*715 |          TABLE ACCESS BY INDEX ROWID BATCHED    | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*716 |           INDEX RANGE SCAN                      | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*717 |         FILTER                                  |                             |     39 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*718 |          TABLE ACCESS BY INDEX ROWID BATCHED    | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*719 |           INDEX RANGE SCAN                      | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*720 |         FILTER                                  |                             |     39 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*721 |          TABLE ACCESS BY INDEX ROWID BATCHED    | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*722 |           INDEX RANGE SCAN                      | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*723 |         FILTER                                  |                             |     39 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*724 |          TABLE ACCESS BY INDEX ROWID BATCHED    | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*725 |           INDEX RANGE SCAN                      | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*726 |         FILTER                                  |                             |     39 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*727 |          TABLE ACCESS BY INDEX ROWID BATCHED    | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*728 |           INDEX RANGE SCAN                      | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*729 |         FILTER                                  |                             |     39 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*730 |          TABLE ACCESS BY INDEX ROWID BATCHED    | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*731 |           INDEX RANGE SCAN                      | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*732 |         FILTER                                  |                             |     39 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*733 |          TABLE ACCESS BY INDEX ROWID BATCHED    | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*734 |           INDEX RANGE SCAN                      | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*735 |         FILTER                                  |                             |     39 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*736 |          TABLE ACCESS BY INDEX ROWID BATCHED    | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*737 |           INDEX RANGE SCAN                      | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*738 |         FILTER                                  |                             |     39 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*739 |          TABLE ACCESS BY INDEX ROWID BATCHED    | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*740 |           INDEX RANGE SCAN                      | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*741 |         FILTER                                  |                             |     39 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*742 |          TABLE ACCESS BY INDEX ROWID BATCHED    | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*743 |           INDEX RANGE SCAN                      | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*744 |         FILTER                                  |                             |     39 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*745 |          TABLE ACCESS BY INDEX ROWID BATCHED    | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*746 |           INDEX RANGE SCAN                      | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*747 |         FILTER                                  |                             |     39 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*748 |          TABLE ACCESS BY INDEX ROWID BATCHED    | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*749 |           INDEX RANGE SCAN                      | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*750 |         FILTER                                  |                             |     39 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*751 |          TABLE ACCESS BY INDEX ROWID BATCHED    | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*752 |           INDEX RANGE SCAN                      | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*753 |         FILTER                                  |                             |     39 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*754 |          TABLE ACCESS BY INDEX ROWID BATCHED    | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*755 |           INDEX RANGE SCAN                      | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*756 |         FILTER                                  |                             |     39 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*757 |          TABLE ACCESS BY INDEX ROWID BATCHED    | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*758 |           INDEX RANGE SCAN                      | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*759 |         FILTER                                  |                             |     39 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*760 |          TABLE ACCESS BY INDEX ROWID BATCHED    | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*761 |           INDEX RANGE SCAN                      | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*762 |         FILTER                                  |                             |     39 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*763 |          TABLE ACCESS BY INDEX ROWID BATCHED    | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*764 |           INDEX RANGE SCAN                      | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*765 |         FILTER                                  |                             |     39 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*766 |          TABLE ACCESS BY INDEX ROWID BATCHED    | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*767 |           INDEX RANGE SCAN                      | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*768 |         FILTER                                  |                             |     39 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*769 |          TABLE ACCESS BY INDEX ROWID BATCHED    | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*770 |           INDEX RANGE SCAN                      | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*771 |         FILTER                                  |                             |     39 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*772 |          TABLE ACCESS BY INDEX ROWID BATCHED    | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*773 |           INDEX RANGE SCAN                      | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*774 |       COUNT STOPKEY                             |                             |      1 |        |            |      1 |00:00:00.01 |       4 |      4 |
| 775 |        TABLE ACCESS BY INDEX ROWID              | G_ENCAISSEMENT              |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       4 |      4 |
|*776 |         INDEX UNIQUE SCAN                       | REFENCAISS                  |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |      3 |
|*777 |       COUNT STOPKEY                             |                             |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 778 |        TABLE ACCESS BY INDEX ROWID              | G_ELEMFI                    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*779 |         INDEX UNIQUE SCAN                       | EFI_REFELEM                 |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*780 |      TABLE ACCESS BY INDEX ROWID BATCHED        | V_EXTR_DOM                  |      1 |      1 |     1   (0)|      0 |00:00:00.02 |      21 |     21 |
|*781 |       INDEX RANGE SCAN                          | TYPEABREV_IND2              |      1 |      7 |     1   (0)|    105 |00:00:00.01 |       2 |      2 |
|*782 |      TABLE ACCESS BY INDEX ROWID BATCHED        | G_PERS_AUTH                 |      8 |      1 |     1   (0)|      0 |00:00:00.01 |      34 |      0 |
|*783 |       INDEX RANGE SCAN                          | G_PERS_AUTH_RFPER_TYPEL_IDX |      8 |      2 |     1   (0)|     19 |00:00:00.01 |      18 |      0 |
|*784 |      TABLE ACCESS BY INDEX ROWID BATCHED        | G_PERS_AUTH                 |      2 |      1 |     1   (0)|      1 |00:00:00.01 |      11 |      0 |
|*785 |       INDEX RANGE SCAN                          | G_PERS_AUTH_RFPER_TYPEL_IDX |      2 |      2 |     1   (0)|      5 |00:00:00.01 |       6 |      0 |
| 786 |      FAST DUAL                                  |                             |      2 |      1 |     2   (0)|      2 |00:00:00.01 |       0 |      0 |
|*787 |      COUNT STOPKEY                              |                             |      1 |        |            |      1 |00:00:00.01 |      42 |     31 |
|*788 |       TABLE ACCESS BY INDEX ROWID BATCHED       | V_EXTR_DOM                  |      1 |      1 |     1   (0)|      1 |00:00:00.01 |      42 |     31 |
|*789 |        INDEX RANGE SCAN                         | TYPEABREV_IND2              |      1 |      7 |     1   (0)|    909 |00:00:00.01 |       5 |      3 |
|*790 |       FILTER                                    |                             |      2 |        |            |      1 |00:00:00.01 |      17 |      4 |
| 791 |        TABLE ACCESS BY INDEX ROWID              | G_INFORMATION               |      2 |      1 |     1   (0)|      2 |00:00:00.01 |       8 |      3 |
|*792 |         INDEX UNIQUE SCAN                       | REF_INFORMATION             |      2 |      1 |     1   (0)|      2 |00:00:00.01 |       6 |      1 |
|*793 |        TABLE ACCESS BY INDEX ROWID BATCHED      | G_PERSONNEL                 |      2 |      1 |     1   (0)|      1 |00:00:00.01 |       6 |      1 |
|*794 |         INDEX RANGE SCAN                        | PK_G_PERSONNEL              |      2 |      1 |     1   (0)|      2 |00:00:00.01 |       4 |      1 |
|*795 |        TABLE ACCESS BY INDEX ROWID BATCHED      | G_PERSONNEL                 |      1 |      1 |     1   (0)|      0 |00:00:00.01 |       3 |      0 |
|*796 |         INDEX RANGE SCAN                        | PK_G_PERSONNEL              |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       2 |      0 |
| 797 |      FAST DUAL                                  |                             |      4 |      1 |     2   (0)|      4 |00:00:00.01 |       0 |      0 |
|*798 |      COUNT STOPKEY                              |                             |      1 |        |            |      0 |00:00:00.01 |       2 |      0 |
|*799 |       TABLE ACCESS BY INDEX ROWID BATCHED       | V_EXTR_DOM                  |      1 |      1 |     1   (0)|      0 |00:00:00.01 |       2 |      0 |
|*800 |        INDEX RANGE SCAN                         | TYPEABREV_IND2              |      1 |      7 |     1   (0)|      0 |00:00:00.01 |       2 |      0 |
|*801 |       FILTER                                    |                             |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*802 |        FILTER                                   |                             |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 803 |         NESTED LOOPS                            |                             |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
| 804 |          TABLE ACCESS BY INDEX ROWID            | T_ENTMAIL                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*805 |           INDEX UNIQUE SCAN                     | PK_MAIL                     |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 806 |          TABLE ACCESS BY INDEX ROWID BATCHED    | G_PERSONNEL                 |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*807 |           INDEX RANGE SCAN                      | PK_G_PERSONNEL              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 808 |        NESTED LOOPS                             |                             |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
| 809 |         NESTED LOOPS                            |                             |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
| 810 |          NESTED LOOPS                           |                             |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*811 |           INDEX RANGE SCAN                      | TYPEABREV                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*812 |           TABLE ACCESS BY INDEX ROWID BATCHED   | G_TELEPHONE                 |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*813 |            INDEX RANGE SCAN                     | IDX_G_TEL_INDIV             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*814 |          INDEX RANGE SCAN                       | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*815 |         TABLE ACCESS BY INDEX ROWID             | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 816 |        NESTED LOOPS                             |                             |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
| 817 |         NESTED LOOPS                            |                             |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
| 818 |          NESTED LOOPS                           |                             |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*819 |           INDEX RANGE SCAN                      | TYPEABREV                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*820 |           TABLE ACCESS BY INDEX ROWID BATCHED   | G_TELEPHONE                 |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*821 |            INDEX RANGE SCAN                     | IDX_G_TEL_INDIV             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*822 |          INDEX RANGE SCAN                       | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*823 |         TABLE ACCESS BY INDEX ROWID             | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 824 |        NESTED LOOPS                             |                             |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
| 825 |         NESTED LOOPS                            |                             |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
| 826 |          NESTED LOOPS                           |                             |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*827 |           INDEX RANGE SCAN                      | TYPEABREV                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*828 |           TABLE ACCESS BY INDEX ROWID BATCHED   | G_TELEPHONE                 |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*829 |            INDEX RANGE SCAN                     | IDX_G_TEL_INDIV             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*830 |          INDEX RANGE SCAN                       | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*831 |         TABLE ACCESS BY INDEX ROWID             | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 832 |      FAST DUAL                                  |                             |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*833 |      COUNT STOPKEY                              |                             |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*834 |       TABLE ACCESS BY INDEX ROWID BATCHED       | V_EXTR_DOM                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*835 |        INDEX RANGE SCAN                         | TYPEABREV_IND2              |      0 |      7 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*836 |       FILTER                                    |                             |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*837 |        FILTER                                   |                             |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 838 |         NESTED LOOPS                            |                             |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
| 839 |          TABLE ACCESS BY INDEX ROWID            | T_ENTMAIL                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*840 |           INDEX UNIQUE SCAN                     | PK_MAIL                     |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 841 |          TABLE ACCESS BY INDEX ROWID BATCHED    | G_PERSONNEL                 |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*842 |           INDEX RANGE SCAN                      | PK_G_PERSONNEL              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 843 |        NESTED LOOPS                             |                             |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
| 844 |         NESTED LOOPS                            |                             |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
| 845 |          NESTED LOOPS                           |                             |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*846 |           INDEX RANGE SCAN                      | TYPEABREV                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*847 |           TABLE ACCESS BY INDEX ROWID BATCHED   | G_TELEPHONE                 |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*848 |            INDEX RANGE SCAN                     | IDX_G_TEL_INDIV             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*849 |          INDEX RANGE SCAN                       | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*850 |         TABLE ACCESS BY INDEX ROWID             | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 851 |        NESTED LOOPS                             |                             |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
| 852 |         NESTED LOOPS                            |                             |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
| 853 |          NESTED LOOPS                           |                             |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*854 |           INDEX RANGE SCAN                      | TYPEABREV                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*855 |           TABLE ACCESS BY INDEX ROWID BATCHED   | G_TELEPHONE                 |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*856 |            INDEX RANGE SCAN                     | IDX_G_TEL_INDIV             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*857 |          INDEX RANGE SCAN                       | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*858 |         TABLE ACCESS BY INDEX ROWID             | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 859 |        NESTED LOOPS                             |                             |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
| 860 |         NESTED LOOPS                            |                             |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
| 861 |          NESTED LOOPS                           |                             |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*862 |           INDEX RANGE SCAN                      | TYPEABREV                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*863 |           TABLE ACCESS BY INDEX ROWID BATCHED   | G_TELEPHONE                 |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*864 |            INDEX RANGE SCAN                     | IDX_G_TEL_INDIV             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*865 |          INDEX RANGE SCAN                       | DOM_TYPABREV                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*866 |         TABLE ACCESS BY INDEX ROWID             | V_DOMAINE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*867 |      TABLE ACCESS BY INDEX ROWID                | T_ENTMAIL                   |      4 |      1 |     1   (0)|      0 |00:00:00.01 |      16 |     11 |
|*868 |       INDEX UNIQUE SCAN                         | PK_MAIL                     |      4 |      1 |     1   (0)|      4 |00:00:00.01 |      12 |      7 |
|*869 |      TABLE ACCESS BY INDEX ROWID                | G_INFORMATION               |     26 |      1 |     1   (0)|      0 |00:00:00.04 |     105 |     36 |
|*870 |       INDEX UNIQUE SCAN                         | REF_INFORMATION             |     26 |      1 |     1   (0)|     26 |00:00:00.02 |      79 |     16 |
---------------------------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   1 - filter(ROWNUM=1)
   2 - filter("ROWTYPE"='USER_LINK')
   3 - access("G"."REFPERSO"=:B1 AND "G"."TYPEELEM"=:B2)
   4 - filter(ROWNUM=1)
   5 - filter(("ROWTYPE"='USER_LINK' AND "LIBELLE_TYPE"=1 AND NVL("IMX"."FTRANSLATE_STR"(:B1,:B1,DECODE(:B2,'an',:B3,:B4)),:B5) LIKE "G"."LIBELLE"))
   6 - access("G"."REFPERSO"=:B1 AND "G"."TYPEELEM"=:B2)
   7 - filter(ROWNUM=1)
  11 - access("EC"."REFPERSO"=:B1)
  12 - access("EC"."GROUPID"="GP"."REFPERSO" AND "GP"."TYPEELEM"=:B1)
  13 - filter("GP"."ROWTYPE"='GROUP_LINK')
  14 - filter(ROWNUM=1)
  18 - access("EC"."REFPERSO"=:B1)
  19 - access("EC"."GROUPID"="GP"."REFPERSO" AND "GP"."TYPEELEM"=:B1)
  20 - filter("GP"."ROWTYPE"='GROUP_LINK')
  21 - filter(ROWNUM<2)
  22 - filter("VD"."CHEMIN"=DECODE(:B1,'en',,'fi',,'fa',DECODE(INSTR(UPPER(:B2),"VD"."CHEMIN"),0,:B3,"VD"."CHEMIN"),'ms',DECODE(INSTR(:B4,"VD"."CHEMIN"
              ),0,:B5,"VD"."CHEMIN"),'in',SUBSTR(:B6,0,LENGTH("VD"."CHEMIN")),:B7))
  27 - filter('AL'=:B2)
  28 - filter("VALEUR_AL" IS NOT NULL)
  29 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
  30 - filter('AN'=:B2)
  31 - filter("VALEUR_AN" IS NOT NULL)
  32 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
  33 - filter('AR'=:B2)
  34 - filter("VALEUR_AR" IS NOT NULL)
  35 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
  36 - filter('BG'=:B2)
  37 - filter("VALEUR_BG" IS NOT NULL)
  38 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
  39 - filter('BR'=:B2)
  40 - filter("VALEUR_BR" IS NOT NULL)
  41 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
  42 - filter('CE'=:B2)
  43 - filter("VALEUR_CE" IS NOT NULL)
  44 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
  45 - filter('CH'=:B2)
  46 - filter("VALEUR_CH" IS NOT NULL)
  47 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
  48 - filter('CS'=:B2)
  49 - filter("VALEUR_CS" IS NOT NULL)
  50 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
  51 - filter('DA'=:B2)
  52 - filter("VALEUR_DA" IS NOT NULL)
  53 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
  54 - filter('EL'=:B2)
  55 - filter("VALEUR_EL" IS NOT NULL)
  56 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
  57 - filter('ES'=:B2)
  58 - filter("VALEUR_ES" IS NOT NULL)
  59 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
  60 - filter('ET'=:B2)
  61 - filter("VALEUR_ET" IS NOT NULL)
  62 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
  63 - filter('FI'=:B2)
  64 - filter("VALEUR_FI" IS NOT NULL)
  65 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
  66 - filter('FL'=:B2)
  67 - filter("VALEUR_FL" IS NOT NULL)
  68 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
  69 - filter('FR'=:B2)
  70 - filter(NVL("VALEUR_FR","VALEUR") IS NOT NULL)
  71 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
  72 - filter('HR'=:B2)
  73 - filter("VALEUR_HR" IS NOT NULL)
  74 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
  75 - filter('HU'=:B2)
  76 - filter("VALEUR_HU" IS NOT NULL)
  77 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
  78 - filter('IT'=:B2)
  79 - filter("VALEUR_IT" IS NOT NULL)
  80 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
  81 - filter('IW'=:B2)
  82 - filter("VALEUR_IW" IS NOT NULL)
  83 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
  84 - filter('JA'=:B2)
  85 - filter("VALEUR_JA" IS NOT NULL)
  86 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
  87 - filter('LT'=:B2)
  88 - filter("VALEUR_LT" IS NOT NULL)
  89 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
  90 - filter('LV'=:B2)
  91 - filter("VALEUR_LV" IS NOT NULL)
  92 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
  93 - filter('MX'=:B2)
  94 - filter("VALEUR_MX" IS NOT NULL)
  95 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
  96 - filter('NL'=:B2)
  97 - filter("VALEUR_NL" IS NOT NULL)
  98 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
  99 - filter('NO'=:B2)
 100 - filter("VALEUR_NO" IS NOT NULL)
 101 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
 102 - filter('PL'=:B2)
 103 - filter("VALEUR_PL" IS NOT NULL)
 104 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
 105 - filter('PT'=:B2)
 106 - filter("VALEUR_PT" IS NOT NULL)
 107 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
 108 - filter('RO'=:B2)
 109 - filter("VALEUR_RO" IS NOT NULL)
 110 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
 111 - filter('RU'=:B2)
 112 - filter("VALEUR_RU" IS NOT NULL)
 113 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
 114 - filter('SK'=:B2)
 115 - filter("VALEUR_SK" IS NOT NULL)
 116 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
 117 - filter('SL'=:B2)
 118 - filter("VALEUR_SL" IS NOT NULL)
 119 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
 120 - filter('SR'=:B2)
 121 - filter("VALEUR_SR" IS NOT NULL)
 122 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
 123 - filter('SV'=:B2)
 124 - filter("VALEUR_SV" IS NOT NULL)
 125 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
 126 - filter('TR'=:B2)
 127 - filter("VALEUR_TR" IS NOT NULL)
 128 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
 129 - filter('US'=:B2)
 130 - filter("VALEUR_US" IS NOT NULL)
 131 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
 132 - filter('VI'=:B2)
 133 - filter("VALEUR_VI" IS NOT NULL)
 134 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
 135 - filter('ZH'=:B2)
 136 - filter("VALEUR_ZH" IS NOT NULL)
 137 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
 138 - filter(ROWNUM<2)
 139 - filter( IS NULL)
 141 - access("GE"."REFENCAISS"=:B1)
 142 - filter(:B1 IS NULL)
 143 - access("REFELEM"=:B1)
 144 - filter(ROWNUM<2)
 146 - access("GFI"."REFELEM"=:B1)
 147 - filter(ROWNUM<2)
 150 - filter('AL'=:B3)
 151 - filter("CHEMIN" IS NULL)
 152 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
 153 - filter('AN'=:B3)
 154 - filter("CHEMIN" IS NULL)
 155 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
 156 - filter('AR'=:B3)
 157 - filter("CHEMIN" IS NULL)
 158 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
 159 - filter('BG'=:B3)
 160 - filter("CHEMIN" IS NULL)
 161 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
 162 - filter('BR'=:B3)
 163 - filter("CHEMIN" IS NULL)
 164 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
 165 - filter('CE'=:B3)
 166 - filter("CHEMIN" IS NULL)
 167 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
 168 - filter('CH'=:B3)
 169 - filter("CHEMIN" IS NULL)
 170 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
 171 - filter('CS'=:B3)
 172 - filter("CHEMIN" IS NULL)
 173 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
 174 - filter('DA'=:B3)
 175 - filter("CHEMIN" IS NULL)
 176 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
 177 - filter('EL'=:B3)
 178 - filter("CHEMIN" IS NULL)
 179 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
 180 - filter('ES'=:B3)
 181 - filter("CHEMIN" IS NULL)
 182 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
 183 - filter('ET'=:B3)
 184 - filter("CHEMIN" IS NULL)
 185 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
 186 - filter('FI'=:B3)
 187 - filter("CHEMIN" IS NULL)
 188 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
 189 - filter('FL'=:B3)
 190 - filter("CHEMIN" IS NULL)
 191 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
 192 - filter('FR'=:B3)
 193 - filter("CHEMIN" IS NULL)
 194 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
 195 - filter('HR'=:B3)
 196 - filter("CHEMIN" IS NULL)
 197 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
 198 - filter('HU'=:B3)
 199 - filter("CHEMIN" IS NULL)
 200 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
 201 - filter('IT'=:B3)
 202 - filter("CHEMIN" IS NULL)
 203 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
 204 - filter('IW'=:B3)
 205 - filter("CHEMIN" IS NULL)
 206 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
 207 - filter('JA'=:B3)
 208 - filter("CHEMIN" IS NULL)
 209 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
 210 - filter('LT'=:B3)
 211 - filter("CHEMIN" IS NULL)
 212 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
 213 - filter('LV'=:B3)
 214 - filter("CHEMIN" IS NULL)
 215 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
 216 - filter('MX'=:B3)
 217 - filter("CHEMIN" IS NULL)
 218 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
 219 - filter('NL'=:B3)
 220 - filter("CHEMIN" IS NULL)
 221 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
 222 - filter('NO'=:B3)
 223 - filter("CHEMIN" IS NULL)
 224 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
 225 - filter('PL'=:B3)
 226 - filter("CHEMIN" IS NULL)
 227 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
 228 - filter('PT'=:B3)
 229 - filter("CHEMIN" IS NULL)
 230 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
 231 - filter('RO'=:B3)
 232 - filter("CHEMIN" IS NULL)
 233 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
 234 - filter('RU'=:B3)
 235 - filter("CHEMIN" IS NULL)
 236 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
 237 - filter('SK'=:B3)
 238 - filter("CHEMIN" IS NULL)
 239 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
 240 - filter('SL'=:B3)
 241 - filter("CHEMIN" IS NULL)
 242 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
 243 - filter('SR'=:B3)
 244 - filter("CHEMIN" IS NULL)
 245 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
 246 - filter('SV'=:B3)
 247 - filter("CHEMIN" IS NULL)
 248 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
 249 - filter('TR'=:B3)
 250 - filter("CHEMIN" IS NULL)
 251 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
 252 - filter('US'=:B3)
 253 - filter("CHEMIN" IS NULL)
 254 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
 255 - filter('VI'=:B3)
 256 - filter("CHEMIN" IS NULL)
 257 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
 258 - filter('ZH'=:B3)
 259 - filter("CHEMIN" IS NULL)
 260 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
 263 - filter('AL'=UPPER(:B4))
 265 - access("VALEUR"=:B1 AND "TYPE"='MESSAGE_SUBJECT')
 266 - filter('AN'=UPPER(:B4))
 268 - access("VALEUR"=:B1 AND "TYPE"='MESSAGE_SUBJECT')
 269 - filter('AR'=UPPER(:B4))
 271 - access("VALEUR"=:B1 AND "TYPE"='MESSAGE_SUBJECT')
 272 - filter('BG'=UPPER(:B4))
 274 - access("VALEUR"=:B1 AND "TYPE"='MESSAGE_SUBJECT')
 275 - filter('BR'=UPPER(:B4))
 277 - access("VALEUR"=:B1 AND "TYPE"='MESSAGE_SUBJECT')
 278 - filter('CE'=UPPER(:B4))
 280 - access("VALEUR"=:B1 AND "TYPE"='MESSAGE_SUBJECT')
 281 - filter('CH'=UPPER(:B4))
 283 - access("VALEUR"=:B1 AND "TYPE"='MESSAGE_SUBJECT')
 284 - filter('CS'=UPPER(:B4))
 286 - access("VALEUR"=:B1 AND "TYPE"='MESSAGE_SUBJECT')
 287 - filter('DA'=UPPER(:B4))
 289 - access("VALEUR"=:B1 AND "TYPE"='MESSAGE_SUBJECT')
 290 - filter('EL'=UPPER(:B4))
 292 - access("VALEUR"=:B1 AND "TYPE"='MESSAGE_SUBJECT')
 293 - filter('ES'=UPPER(:B4))
 295 - access("VALEUR"=:B1 AND "TYPE"='MESSAGE_SUBJECT')
 296 - filter('ET'=UPPER(:B4))
 298 - access("VALEUR"=:B1 AND "TYPE"='MESSAGE_SUBJECT')
 299 - filter('FI'=UPPER(:B4))
 301 - access("VALEUR"=:B1 AND "TYPE"='MESSAGE_SUBJECT')
 302 - filter('FL'=UPPER(:B4))
 304 - access("VALEUR"=:B1 AND "TYPE"='MESSAGE_SUBJECT')
 305 - filter('FR'=UPPER(:B4))
 307 - access("VALEUR"=:B1 AND "TYPE"='MESSAGE_SUBJECT')
 308 - filter('HR'=UPPER(:B4))
 310 - access("VALEUR"=:B1 AND "TYPE"='MESSAGE_SUBJECT')
 311 - filter('HU'=UPPER(:B4))
 313 - access("VALEUR"=:B1 AND "TYPE"='MESSAGE_SUBJECT')
 314 - filter('IT'=UPPER(:B4))
 316 - access("VALEUR"=:B1 AND "TYPE"='MESSAGE_SUBJECT')
 317 - filter('IW'=UPPER(:B4))
 319 - access("VALEUR"=:B1 AND "TYPE"='MESSAGE_SUBJECT')
 320 - filter('JA'=UPPER(:B4))
 322 - access("VALEUR"=:B1 AND "TYPE"='MESSAGE_SUBJECT')
 323 - filter('LT'=UPPER(:B4))
 325 - access("VALEUR"=:B1 AND "TYPE"='MESSAGE_SUBJECT')
 326 - filter('LV'=UPPER(:B4))
 328 - access("VALEUR"=:B1 AND "TYPE"='MESSAGE_SUBJECT')
 329 - filter('MX'=UPPER(:B4))
 331 - access("VALEUR"=:B1 AND "TYPE"='MESSAGE_SUBJECT')
 332 - filter('NL'=UPPER(:B4))
 334 - access("VALEUR"=:B1 AND "TYPE"='MESSAGE_SUBJECT')
 335 - filter('NO'=UPPER(:B4))
 337 - access("VALEUR"=:B1 AND "TYPE"='MESSAGE_SUBJECT')
 338 - filter('PL'=UPPER(:B4))
 340 - access("VALEUR"=:B1 AND "TYPE"='MESSAGE_SUBJECT')
 341 - filter('PT'=UPPER(:B4))
 343 - access("VALEUR"=:B1 AND "TYPE"='MESSAGE_SUBJECT')
 344 - filter('RO'=UPPER(:B4))
 346 - access("VALEUR"=:B1 AND "TYPE"='MESSAGE_SUBJECT')
 347 - filter('RU'=UPPER(:B4))
 349 - access("VALEUR"=:B1 AND "TYPE"='MESSAGE_SUBJECT')
 350 - filter('SK'=UPPER(:B4))
 352 - access("VALEUR"=:B1 AND "TYPE"='MESSAGE_SUBJECT')
 353 - filter('SL'=UPPER(:B4))
 355 - access("VALEUR"=:B1 AND "TYPE"='MESSAGE_SUBJECT')
 356 - filter('SR'=UPPER(:B4))
 358 - access("VALEUR"=:B1 AND "TYPE"='MESSAGE_SUBJECT')
 359 - filter('SV'=UPPER(:B4))
 361 - access("VALEUR"=:B1 AND "TYPE"='MESSAGE_SUBJECT')
 362 - filter('TR'=UPPER(:B4))
 364 - access("VALEUR"=:B1 AND "TYPE"='MESSAGE_SUBJECT')
 365 - filter('US'=UPPER(:B4))
 367 - access("VALEUR"=:B1 AND "TYPE"='MESSAGE_SUBJECT')
 368 - filter('VI'=UPPER(:B4))
 370 - access("VALEUR"=:B1 AND "TYPE"='MESSAGE_SUBJECT')
 371 - filter('ZH'=UPPER(:B4))
 373 - access("VALEUR"=:B1 AND "TYPE"='MESSAGE_SUBJECT')
 374 - filter(ROWNUM<2)
 378 - access("P"."LOGIN"=:B1)
 379 - access("I"."REFINDIVIDU"="P"."REFINDIVIDU")
 381 - filter(ROWNUM<2)
 383 - access("FA"."REFELEM"=:B1)
 384 - filter(ROWNUM=1)
 386 - filter("TE"."SENS"='E')
 387 - access("TE"."REFMAIL"=:B1)
 388 - access("TM"."REFMAIL"=:B1)
 389 - filter(ROWNUM=1)
 391 - filter("TE"."SENS"='R')
 392 - access("TE"."REFMAIL"=:B1)
 393 - access("TM"."REFMAIL"=:B1)
 394 - filter(ROWNUM=1)
 395 - filter("TYPEMETTEUR"='A')
 396 - access("REFINFO"=:B1)
 397 - filter(ROWNUM=1)
 398 - filter(("REFIMAGE" IS NOT NULL AND "PIE"."CODE"='fi' AND "GPIIMAGE"='X'))
 399 - access("PIE"."REFEXT"=:B1 AND "PIE"."TYPPIECE"='IMAGE_EXTERNE')
 400 - filter(ROWNUM=1)
 401 - filter(("REFIMAGE" IS NOT NULL AND "PIE"."CODE"='eg' AND "GPIIMAGE"='X'))
 402 - access("PIE"."REFEXT"= AND "PIE"."TYPPIECE"='IMAGE_EXTERNE')
 404 - access("EE_NUM"=:B1)
 405 - filter(ROWNUM=1)
 407 - filter(ROWNUM=1)
 408 - filter(("REFIMAGE" IS NOT NULL AND "GPIIMAGE"='X'))
 409 - access("PIE"."REFPIECE"=:B1)
 410 - filter(ROWNUM=1)
 411 - filter(("REFIMAGE" IS NOT NULL AND "GPIIMAGE"='X' AND LNNVL("PIE"."REFPIECE"=:B1)))
 412 - access("PIE"."REFEXT"=:B1)
 416 - filter((( IS NOT NULL OR ( IS NULL AND  IS NULL)) AND ((("AUTH"."LIBELLE"='ALL' OR "E"."LIBELLE" LIKE "AUTH"."LIBELLE") AND
              NVL("AUTH"."LIBELLE_TYPE",0)=0) OR  IS NULL) AND ("E"."TYPEELEM"<>'ms' OR =1) AND ("E"."TYPEELEM"<>'me' OR =1) AND ("E"."TYPEELEM"<>'mr' OR =1) AND
              (("E"."TYPEELEM"<>'me' AND "E"."TYPEELEM"<>'mr') OR  IS NULL) AND (("E"."TYPEELEM"<>'in' AND "E"."TYPEELEM"<>'ms') OR  IS NULL)))
 417 - access("EX"."REFPERSO"="AUTH"."REFPERSO" AND "EX"."TYPEELEM"="AUTH"."TYPEELEM")
       filter("E"."LIBELLE" LIKE "EX"."LIBELLE")
 418 - filter(("EX"."ROWTYPE"='USER' AND "EX"."LIBELLE_TYPE"=1))
 419 - access("EX"."REFPERSO"=TO_NUMBER(:B8))
 420 - access("AUTH"."TYPEELEM"=DECODE("E"."TYPEELEM",'in',DECODE("VD2"."VALEUR",NULL,'in','in_s'),"E"."TYPEELEM"))
 421 - filter(("AUTH"."ROWTYPE"='USER' AND "AUTH"."LIBELLE"<>'NOTHING'))
 422 - access("AUTH"."REFPERSO"=TO_NUMBER(:B8))
 423 - filter(NVL("VD2"."ECRAN",'XXX')<>'invis extranet')
 424 - access("VD2"."VALEUR"=DECODE(SUBSTR("E"."LIBELLE",1,2),'A.',SUBSTR("E"."LIBELLE",3),"E"."LIBELLE"))
 425 - access("VD_TYPES"."ABREV"="E"."TYPEELEM")
 429 - access("E"."REFDOSS"=:B7)
       filter(("E"."TYPEELEM"<>'se' AND "E"."TYPEELEM"<>'ng' AND "E"."TYPEELEM"<>'an' AND "E"."TYPEELEM"<>'yy' AND "E"."TYPEELEM"<>'et' AND
              "E"."TYPEELEM"<>'xx' AND "E"."TYPEELEM"<>'ce'))
 430 - filter(NVL("GP"."FG_NOT_VISIBLE_IN_XNET",'N')='O')
 431 - access("GP"."REFPIECE"="E"."REFELEM")
 432 - filter("GELEM"."REFDOSS"=:B7)
 433 - access("E"."REFELEM"="GELEM"."REFELEM")
 436 - filter('AL'=:B10)
 437 - filter(("ABREV"<>'se' AND "ABREV"<>'ng' AND "ABREV"<>'an' AND "ABREV"<>'yy' AND "ABREV"<>'et' AND "ABREV"<>'xx' AND "ABREV"<>'ce'))
 438 - access("TYPE"='ELEM_CHRONO')
 439 - filter('AN'=:B10)
 440 - filter(("ABREV"<>'se' AND "ABREV"<>'ng' AND "ABREV"<>'an' AND "ABREV"<>'yy' AND "ABREV"<>'et' AND "ABREV"<>'xx' AND "ABREV"<>'ce'))
 441 - access("TYPE"='ELEM_CHRONO')
 442 - filter('AR'=:B10)
 443 - filter(("ABREV"<>'se' AND "ABREV"<>'ng' AND "ABREV"<>'an' AND "ABREV"<>'yy' AND "ABREV"<>'et' AND "ABREV"<>'xx' AND "ABREV"<>'ce'))
 444 - access("TYPE"='ELEM_CHRONO')
 445 - filter('BG'=:B10)
 446 - filter(("ABREV"<>'se' AND "ABREV"<>'ng' AND "ABREV"<>'an' AND "ABREV"<>'yy' AND "ABREV"<>'et' AND "ABREV"<>'xx' AND "ABREV"<>'ce'))
 447 - access("TYPE"='ELEM_CHRONO')
 448 - filter('BR'=:B10)
 449 - filter(("ABREV"<>'se' AND "ABREV"<>'ng' AND "ABREV"<>'an' AND "ABREV"<>'yy' AND "ABREV"<>'et' AND "ABREV"<>'xx' AND "ABREV"<>'ce'))
 450 - access("TYPE"='ELEM_CHRONO')
 451 - filter('CE'=:B10)
 452 - filter(("ABREV"<>'se' AND "ABREV"<>'ng' AND "ABREV"<>'an' AND "ABREV"<>'yy' AND "ABREV"<>'et' AND "ABREV"<>'xx' AND "ABREV"<>'ce'))
 453 - access("TYPE"='ELEM_CHRONO')
 454 - filter('CH'=:B10)
 455 - filter(("ABREV"<>'se' AND "ABREV"<>'ng' AND "ABREV"<>'an' AND "ABREV"<>'yy' AND "ABREV"<>'et' AND "ABREV"<>'xx' AND "ABREV"<>'ce'))
 456 - access("TYPE"='ELEM_CHRONO')
 457 - filter('CS'=:B10)
 458 - filter(("ABREV"<>'se' AND "ABREV"<>'ng' AND "ABREV"<>'an' AND "ABREV"<>'yy' AND "ABREV"<>'et' AND "ABREV"<>'xx' AND "ABREV"<>'ce'))
 459 - access("TYPE"='ELEM_CHRONO')
 460 - filter('DA'=:B10)
 461 - filter(("ABREV"<>'se' AND "ABREV"<>'ng' AND "ABREV"<>'an' AND "ABREV"<>'yy' AND "ABREV"<>'et' AND "ABREV"<>'xx' AND "ABREV"<>'ce'))
 462 - access("TYPE"='ELEM_CHRONO')
 463 - filter('EL'=:B10)
 464 - filter(("ABREV"<>'se' AND "ABREV"<>'ng' AND "ABREV"<>'an' AND "ABREV"<>'yy' AND "ABREV"<>'et' AND "ABREV"<>'xx' AND "ABREV"<>'ce'))
 465 - access("TYPE"='ELEM_CHRONO')
 466 - filter('ES'=:B10)
 467 - filter(("ABREV"<>'se' AND "ABREV"<>'ng' AND "ABREV"<>'an' AND "ABREV"<>'yy' AND "ABREV"<>'et' AND "ABREV"<>'xx' AND "ABREV"<>'ce'))
 468 - access("TYPE"='ELEM_CHRONO')
 469 - filter('ET'=:B10)
 470 - filter(("ABREV"<>'se' AND "ABREV"<>'ng' AND "ABREV"<>'an' AND "ABREV"<>'yy' AND "ABREV"<>'et' AND "ABREV"<>'xx' AND "ABREV"<>'ce'))
 471 - access("TYPE"='ELEM_CHRONO')
 472 - filter('FI'=:B10)
 473 - filter(("ABREV"<>'se' AND "ABREV"<>'ng' AND "ABREV"<>'an' AND "ABREV"<>'yy' AND "ABREV"<>'et' AND "ABREV"<>'xx' AND "ABREV"<>'ce'))
 474 - access("TYPE"='ELEM_CHRONO')
 475 - filter('FL'=:B10)
 476 - filter(("ABREV"<>'se' AND "ABREV"<>'ng' AND "ABREV"<>'an' AND "ABREV"<>'yy' AND "ABREV"<>'et' AND "ABREV"<>'xx' AND "ABREV"<>'ce'))
 477 - access("TYPE"='ELEM_CHRONO')
 478 - filter('FR'=:B10)
 479 - filter(("ABREV"<>'se' AND "ABREV"<>'ng' AND "ABREV"<>'an' AND "ABREV"<>'yy' AND "ABREV"<>'et' AND "ABREV"<>'xx' AND "ABREV"<>'ce'))
 480 - access("TYPE"='ELEM_CHRONO')
 481 - filter('HR'=:B10)
 482 - filter(("ABREV"<>'se' AND "ABREV"<>'ng' AND "ABREV"<>'an' AND "ABREV"<>'yy' AND "ABREV"<>'et' AND "ABREV"<>'xx' AND "ABREV"<>'ce'))
 483 - access("TYPE"='ELEM_CHRONO')
 484 - filter('HU'=:B10)
 485 - filter(("ABREV"<>'se' AND "ABREV"<>'ng' AND "ABREV"<>'an' AND "ABREV"<>'yy' AND "ABREV"<>'et' AND "ABREV"<>'xx' AND "ABREV"<>'ce'))
 486 - access("TYPE"='ELEM_CHRONO')
 487 - filter('IT'=:B10)
 488 - filter(("ABREV"<>'se' AND "ABREV"<>'ng' AND "ABREV"<>'an' AND "ABREV"<>'yy' AND "ABREV"<>'et' AND "ABREV"<>'xx' AND "ABREV"<>'ce'))
 489 - access("TYPE"='ELEM_CHRONO')
 490 - filter('IW'=:B10)
 491 - filter(("ABREV"<>'se' AND "ABREV"<>'ng' AND "ABREV"<>'an' AND "ABREV"<>'yy' AND "ABREV"<>'et' AND "ABREV"<>'xx' AND "ABREV"<>'ce'))
 492 - access("TYPE"='ELEM_CHRONO')
 493 - filter('JA'=:B10)
 494 - filter(("ABREV"<>'se' AND "ABREV"<>'ng' AND "ABREV"<>'an' AND "ABREV"<>'yy' AND "ABREV"<>'et' AND "ABREV"<>'xx' AND "ABREV"<>'ce'))
 495 - access("TYPE"='ELEM_CHRONO')
 496 - filter('LT'=:B10)
 497 - filter(("ABREV"<>'se' AND "ABREV"<>'ng' AND "ABREV"<>'an' AND "ABREV"<>'yy' AND "ABREV"<>'et' AND "ABREV"<>'xx' AND "ABREV"<>'ce'))
 498 - access("TYPE"='ELEM_CHRONO')
 499 - filter('LV'=:B10)
 500 - filter(("ABREV"<>'se' AND "ABREV"<>'ng' AND "ABREV"<>'an' AND "ABREV"<>'yy' AND "ABREV"<>'et' AND "ABREV"<>'xx' AND "ABREV"<>'ce'))
 501 - access("TYPE"='ELEM_CHRONO')
 502 - filter('MX'=:B10)
 503 - filter(("ABREV"<>'se' AND "ABREV"<>'ng' AND "ABREV"<>'an' AND "ABREV"<>'yy' AND "ABREV"<>'et' AND "ABREV"<>'xx' AND "ABREV"<>'ce'))
 504 - access("TYPE"='ELEM_CHRONO')
 505 - filter('NL'=:B10)
 506 - filter(("ABREV"<>'se' AND "ABREV"<>'ng' AND "ABREV"<>'an' AND "ABREV"<>'yy' AND "ABREV"<>'et' AND "ABREV"<>'xx' AND "ABREV"<>'ce'))
 507 - access("TYPE"='ELEM_CHRONO')
 508 - filter('NO'=:B10)
 509 - filter(("ABREV"<>'se' AND "ABREV"<>'ng' AND "ABREV"<>'an' AND "ABREV"<>'yy' AND "ABREV"<>'et' AND "ABREV"<>'xx' AND "ABREV"<>'ce'))
 510 - access("TYPE"='ELEM_CHRONO')
 511 - filter('PL'=:B10)
 512 - filter(("ABREV"<>'se' AND "ABREV"<>'ng' AND "ABREV"<>'an' AND "ABREV"<>'yy' AND "ABREV"<>'et' AND "ABREV"<>'xx' AND "ABREV"<>'ce'))
 513 - access("TYPE"='ELEM_CHRONO')
 514 - filter('PT'=:B10)
 515 - filter(("ABREV"<>'se' AND "ABREV"<>'ng' AND "ABREV"<>'an' AND "ABREV"<>'yy' AND "ABREV"<>'et' AND "ABREV"<>'xx' AND "ABREV"<>'ce'))
 516 - access("TYPE"='ELEM_CHRONO')
 517 - filter('RO'=:B10)
 518 - filter(("ABREV"<>'se' AND "ABREV"<>'ng' AND "ABREV"<>'an' AND "ABREV"<>'yy' AND "ABREV"<>'et' AND "ABREV"<>'xx' AND "ABREV"<>'ce'))
 519 - access("TYPE"='ELEM_CHRONO')
 520 - filter('RU'=:B10)
 521 - filter(("ABREV"<>'se' AND "ABREV"<>'ng' AND "ABREV"<>'an' AND "ABREV"<>'yy' AND "ABREV"<>'et' AND "ABREV"<>'xx' AND "ABREV"<>'ce'))
 522 - access("TYPE"='ELEM_CHRONO')
 523 - filter('SK'=:B10)
 524 - filter(("ABREV"<>'se' AND "ABREV"<>'ng' AND "ABREV"<>'an' AND "ABREV"<>'yy' AND "ABREV"<>'et' AND "ABREV"<>'xx' AND "ABREV"<>'ce'))
 525 - access("TYPE"='ELEM_CHRONO')
 526 - filter('SL'=:B10)
 527 - filter(("ABREV"<>'se' AND "ABREV"<>'ng' AND "ABREV"<>'an' AND "ABREV"<>'yy' AND "ABREV"<>'et' AND "ABREV"<>'xx' AND "ABREV"<>'ce'))
 528 - access("TYPE"='ELEM_CHRONO')
 529 - filter('SR'=:B10)
 530 - filter(("ABREV"<>'se' AND "ABREV"<>'ng' AND "ABREV"<>'an' AND "ABREV"<>'yy' AND "ABREV"<>'et' AND "ABREV"<>'xx' AND "ABREV"<>'ce'))
 531 - access("TYPE"='ELEM_CHRONO')
 532 - filter('SV'=:B10)
 533 - filter(("ABREV"<>'se' AND "ABREV"<>'ng' AND "ABREV"<>'an' AND "ABREV"<>'yy' AND "ABREV"<>'et' AND "ABREV"<>'xx' AND "ABREV"<>'ce'))
 534 - access("TYPE"='ELEM_CHRONO')
 535 - filter('TR'=:B10)
 536 - filter(("ABREV"<>'se' AND "ABREV"<>'ng' AND "ABREV"<>'an' AND "ABREV"<>'yy' AND "ABREV"<>'et' AND "ABREV"<>'xx' AND "ABREV"<>'ce'))
 537 - access("TYPE"='ELEM_CHRONO')
 538 - filter('US'=:B10)
 539 - filter(("ABREV"<>'se' AND "ABREV"<>'ng' AND "ABREV"<>'an' AND "ABREV"<>'yy' AND "ABREV"<>'et' AND "ABREV"<>'xx' AND "ABREV"<>'ce'))
 540 - access("TYPE"='ELEM_CHRONO')
 541 - filter('VI'=:B10)
 542 - filter(("ABREV"<>'se' AND "ABREV"<>'ng' AND "ABREV"<>'an' AND "ABREV"<>'yy' AND "ABREV"<>'et' AND "ABREV"<>'xx' AND "ABREV"<>'ce'))
 543 - access("TYPE"='ELEM_CHRONO')
 544 - filter('ZH'=:B10)
 545 - filter(("ABREV"<>'se' AND "ABREV"<>'ng' AND "ABREV"<>'an' AND "ABREV"<>'yy' AND "ABREV"<>'et' AND "ABREV"<>'xx' AND "ABREV"<>'ce'))
 546 - access("TYPE"='ELEM_CHRONO')
 549 - filter('AL'=:B6)
 551 - access("TYPE"='LIBELINFO')
 552 - filter('AN'=:B6)
 554 - access("TYPE"='LIBELINFO')
 555 - filter('AR'=:B6)
 557 - access("TYPE"='LIBELINFO')
 558 - filter('BG'=:B6)
 560 - access("TYPE"='LIBELINFO')
 561 - filter('BR'=:B6)
 563 - access("TYPE"='LIBELINFO')
 564 - filter('CE'=:B6)
 566 - access("TYPE"='LIBELINFO')
 567 - filter('CH'=:B6)
 569 - access("TYPE"='LIBELINFO')
 570 - filter('CS'=:B6)
 572 - access("TYPE"='LIBELINFO')
 573 - filter('DA'=:B6)
 575 - access("TYPE"='LIBELINFO')
 576 - filter('EL'=:B6)
 578 - access("TYPE"='LIBELINFO')
 579 - filter('ES'=:B6)
 581 - access("TYPE"='LIBELINFO')
 582 - filter('ET'=:B6)
 584 - access("TYPE"='LIBELINFO')
 585 - filter('FI'=:B6)
 587 - access("TYPE"='LIBELINFO')
 588 - filter('FL'=:B6)
 590 - access("TYPE"='LIBELINFO')
 591 - filter('FR'=:B6)
 593 - access("TYPE"='LIBELINFO')
 594 - filter('HR'=:B6)
 596 - access("TYPE"='LIBELINFO')
 597 - filter('HU'=:B6)
 599 - access("TYPE"='LIBELINFO')
 600 - filter('IT'=:B6)
 602 - access("TYPE"='LIBELINFO')
 603 - filter('IW'=:B6)
 605 - access("TYPE"='LIBELINFO')
 606 - filter('JA'=:B6)
 608 - access("TYPE"='LIBELINFO')
 609 - filter('LT'=:B6)
 611 - access("TYPE"='LIBELINFO')
 612 - filter('LV'=:B6)
 614 - access("TYPE"='LIBELINFO')
 615 - filter('MX'=:B6)
 617 - access("TYPE"='LIBELINFO')
 618 - filter('NL'=:B6)
 620 - access("TYPE"='LIBELINFO')
 621 - filter('NO'=:B6)
 623 - access("TYPE"='LIBELINFO')
 624 - filter('PL'=:B6)
 626 - access("TYPE"='LIBELINFO')
 627 - filter('PT'=:B6)
 629 - access("TYPE"='LIBELINFO')
 630 - filter('RO'=:B6)
 632 - access("TYPE"='LIBELINFO')
 633 - filter('RU'=:B6)
 635 - access("TYPE"='LIBELINFO')
 636 - filter('SK'=:B6)
 638 - access("TYPE"='LIBELINFO')
 639 - filter('SL'=:B6)
 641 - access("TYPE"='LIBELINFO')
 642 - filter('SR'=:B6)
 644 - access("TYPE"='LIBELINFO')
 645 - filter('SV'=:B6)
 647 - access("TYPE"='LIBELINFO')
 648 - filter('TR'=:B6)
 650 - access("TYPE"='LIBELINFO')
 651 - filter('US'=:B6)
 653 - access("TYPE"='LIBELINFO')
 654 - filter('VI'=:B6)
 656 - access("TYPE"='LIBELINFO')
 657 - filter('ZH'=:B6)
 659 - access("TYPE"='LIBELINFO')
 660 - filter("VD"."CHEMIN"=DECODE(:B1,'en',,'fi',,:B2))
 663 - filter('AL'=:B9)
 664 - filter("VALEUR_AL" IS NOT NULL)
 665 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
 666 - filter('AN'=:B9)
 667 - filter("VALEUR_AN" IS NOT NULL)
 668 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
 669 - filter('AR'=:B9)
 670 - filter("VALEUR_AR" IS NOT NULL)
 671 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
 672 - filter('BG'=:B9)
 673 - filter("VALEUR_BG" IS NOT NULL)
 674 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
 675 - filter('BR'=:B9)
 676 - filter("VALEUR_BR" IS NOT NULL)
 677 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
 678 - filter('CE'=:B9)
 679 - filter("VALEUR_CE" IS NOT NULL)
 680 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
 681 - filter('CH'=:B9)
 682 - filter("VALEUR_CH" IS NOT NULL)
 683 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
 684 - filter('CS'=:B9)
 685 - filter("VALEUR_CS" IS NOT NULL)
 686 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
 687 - filter('DA'=:B9)
 688 - filter("VALEUR_DA" IS NOT NULL)
 689 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
 690 - filter('EL'=:B9)
 691 - filter("VALEUR_EL" IS NOT NULL)
 692 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
 693 - filter('ES'=:B9)
 694 - filter("VALEUR_ES" IS NOT NULL)
 695 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
 696 - filter('ET'=:B9)
 697 - filter("VALEUR_ET" IS NOT NULL)
 698 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
 699 - filter('FI'=:B9)
 700 - filter("VALEUR_FI" IS NOT NULL)
 701 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
 702 - filter('FL'=:B9)
 703 - filter("VALEUR_FL" IS NOT NULL)
 704 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
 705 - filter('FR'=:B9)
 706 - filter(NVL("VALEUR_FR","VALEUR") IS NOT NULL)
 707 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
 708 - filter('HR'=:B9)
 709 - filter("VALEUR_HR" IS NOT NULL)
 710 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
 711 - filter('HU'=:B9)
 712 - filter("VALEUR_HU" IS NOT NULL)
 713 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
 714 - filter('IT'=:B9)
 715 - filter("VALEUR_IT" IS NOT NULL)
 716 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
 717 - filter('IW'=:B9)
 718 - filter("VALEUR_IW" IS NOT NULL)
 719 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
 720 - filter('JA'=:B9)
 721 - filter("VALEUR_JA" IS NOT NULL)
 722 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
 723 - filter('LT'=:B9)
 724 - filter("VALEUR_LT" IS NOT NULL)
 725 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
 726 - filter('LV'=:B9)
 727 - filter("VALEUR_LV" IS NOT NULL)
 728 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
 729 - filter('MX'=:B9)
 730 - filter("VALEUR_MX" IS NOT NULL)
 731 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
 732 - filter('NL'=:B9)
 733 - filter("VALEUR_NL" IS NOT NULL)
 734 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
 735 - filter('NO'=:B9)
 736 - filter("VALEUR_NO" IS NOT NULL)
 737 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
 738 - filter('PL'=:B9)
 739 - filter("VALEUR_PL" IS NOT NULL)
 740 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
 741 - filter('PT'=:B9)
 742 - filter("VALEUR_PT" IS NOT NULL)
 743 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
 744 - filter('RO'=:B9)
 745 - filter("VALEUR_RO" IS NOT NULL)
 746 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
 747 - filter('RU'=:B9)
 748 - filter("VALEUR_RU" IS NOT NULL)
 749 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
 750 - filter('SK'=:B9)
 751 - filter("VALEUR_SK" IS NOT NULL)
 752 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
 753 - filter('SL'=:B9)
 754 - filter("VALEUR_SL" IS NOT NULL)
 755 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
 756 - filter('SR'=:B9)
 757 - filter("VALEUR_SR" IS NOT NULL)
 758 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
 759 - filter('SV'=:B9)
 760 - filter("VALEUR_SV" IS NOT NULL)
 761 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
 762 - filter('TR'=:B9)
 763 - filter("VALEUR_TR" IS NOT NULL)
 764 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
 765 - filter('US'=:B9)
 766 - filter("VALEUR_US" IS NOT NULL)
 767 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
 768 - filter('VI'=:B9)
 769 - filter("VALEUR_VI" IS NOT NULL)
 770 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
 771 - filter('ZH'=:B9)
 772 - filter("VALEUR_ZH" IS NOT NULL)
 773 - access("TYPE"='EXTRANET_CHRONO_LIBELLES' AND "ABREV"=:B1)
 774 - filter(ROWNUM<2)
 776 - access("GE"."REFENCAISS"=:B1)
 777 - filter(ROWNUM<2)
 779 - access("GFI"."REFELEM"=:B1)
 780 - filter(("VE"."TYPE"='CHRONO_VIEW_TRANSLATED_LABELS_ONLY' AND TO_NUMBER("VE"."ABREV")=:B1))
 781 - access("VALEUR"='O')
 782 - filter(("TR"."ROWTYPE"='USER_TRANSL' AND TO_NUMBER("TR"."TRANSL")=1))
 783 - access("TR"."REFPERSO"=:B1 AND "TR"."TYPEELEM"=:B2)
 784 - filter(("EX"."ROWTYPE"='USER' AND "EX"."LIBELLE_TYPE"=0))
 785 - access("EX"."REFPERSO"=:B1 AND "EX"."TYPEELEM"=:B2)
 787 - filter(ROWNUM=1)
 788 - filter(("VALEUR_2"='USER' AND "TYPE"='CHRONO_PARTY_REQUIRED' AND TO_NUMBER("ABREV")=:B1))
 789 - access("VALEUR"='ms')
 790 - filter(( IS NOT NULL OR  IS NOT NULL))
 792 - access("GI"."REFINFO"=:B1)
 793 - filter("REFINDIVIDU"=:B1)
 794 - access("REFPERSO"=:B1)
 795 - filter("REFINDIVIDU"=:B1)
 796 - access("REFPERSO"=:B1)
 798 - filter(ROWNUM=1)
 799 - filter(("VALEUR_2"='USER' AND "TYPE"='CHRONO_PARTY_REQUIRED' AND TO_NUMBER("ABREV")=:B1))
 800 - access("VALEUR"='me')
 801 - filter(("GP"."EMAIL"="GI"."DESTINATAIRE" OR "GP"."EMAIL"="GI"."EXPEDITEUR" OR ("GI"."CC" IS NOT NULL AND "GP"."EMAIL"="GI"."CC") OR  IS NOT
              NULL OR  IS NOT NULL OR  IS NOT NULL))
 802 - filter(:B1='me')
 805 - access("GI"."REFMAIL"=:B1)
 807 - access("GP"."REFPERSO"=:B1)
 811 - access("IND"."TYPE"='EXTR_GEST_CLIENT')
       filter(TO_NUMBER("IND"."ABREV")=:B1)
 812 - filter("TEL"."VALIDITE"='O')
 813 - access("TEL"."REFINDIVIDU"="IND"."VALEUR" AND "NUMTEL"=:B1)
       filter("NUMTEL"=:B1)
 814 - access("TYPETEL"."TYPE"='typtel' AND "TEL"."TYPETEL"="TYPETEL"."ABREV")
       filter("TYPETEL"."ABREV" IS NOT NULL)
 815 - filter("TYPETEL"."ECRAN"='EMAIL')
 819 - access("IND"."TYPE"='EXTR_GEST_CLIENT')
       filter(TO_NUMBER("IND"."ABREV")=:B1)
 820 - filter("TEL"."VALIDITE"='O')
 821 - access("TEL"."REFINDIVIDU"="IND"."VALEUR" AND "NUMTEL"=:B1)
       filter("NUMTEL"=:B1)
 822 - access("TYPETEL"."TYPE"='typtel' AND "TEL"."TYPETEL"="TYPETEL"."ABREV")
       filter("TYPETEL"."ABREV" IS NOT NULL)
 823 - filter("TYPETEL"."ECRAN"='EMAIL')
 827 - access("IND"."TYPE"='EXTR_GEST_CLIENT')
       filter(TO_NUMBER("IND"."ABREV")=:B1)
 828 - filter("TEL"."VALIDITE"='O')
 829 - access("TEL"."REFINDIVIDU"="IND"."VALEUR" AND "NUMTEL"=:B1)
       filter("NUMTEL"=:B1)
 830 - access("TYPETEL"."TYPE"='typtel' AND "TEL"."TYPETEL"="TYPETEL"."ABREV")
       filter("TYPETEL"."ABREV" IS NOT NULL)
 831 - filter("TYPETEL"."ECRAN"='EMAIL')
 833 - filter(ROWNUM=1)
 834 - filter(("VALEUR_2"='USER' AND "TYPE"='CHRONO_PARTY_REQUIRED' AND TO_NUMBER("ABREV")=:B1))
 835 - access("VALEUR"='mr')
 836 - filter(("GP"."EMAIL"="GI"."DESTINATAIRE" OR "GP"."EMAIL"="GI"."EXPEDITEUR" OR ("GI"."CC" IS NOT NULL AND "GP"."EMAIL"="GI"."CC") OR  IS NOT
              NULL OR  IS NOT NULL OR  IS NOT NULL))
 837 - filter(:B1='mr')
 840 - access("GI"."REFMAIL"=:B1)
 842 - access("GP"."REFPERSO"=:B1)
 846 - access("IND"."TYPE"='EXTR_GEST_CLIENT')
       filter(TO_NUMBER("IND"."ABREV")=:B1)
 847 - filter("TEL"."VALIDITE"='O')
 848 - access("TEL"."REFINDIVIDU"="IND"."VALEUR" AND "NUMTEL"=:B1)
       filter("NUMTEL"=:B1)
 849 - access("TYPETEL"."TYPE"='typtel' AND "TEL"."TYPETEL"="TYPETEL"."ABREV")
       filter("TYPETEL"."ABREV" IS NOT NULL)
 850 - filter("TYPETEL"."ECRAN"='EMAIL')
 854 - access("IND"."TYPE"='EXTR_GEST_CLIENT')
       filter(TO_NUMBER("IND"."ABREV")=:B1)
 855 - filter("TEL"."VALIDITE"='O')
 856 - access("TEL"."REFINDIVIDU"="IND"."VALEUR" AND "NUMTEL"=:B1)
       filter("NUMTEL"=:B1)
 857 - access("TYPETEL"."TYPE"='typtel' AND "TEL"."TYPETEL"="TYPETEL"."ABREV")
       filter("TYPETEL"."ABREV" IS NOT NULL)
 858 - filter("TYPETEL"."ECRAN"='EMAIL')
 862 - access("IND"."TYPE"='EXTR_GEST_CLIENT')
       filter(TO_NUMBER("IND"."ABREV")=:B1)
 863 - filter("TEL"."VALIDITE"='O')
 864 - access("TEL"."REFINDIVIDU"="IND"."VALEUR" AND "NUMTEL"=:B1)
       filter("NUMTEL"=:B1)
 865 - access("TYPETEL"."TYPE"='typtel' AND "TEL"."TYPETEL"="TYPETEL"."ABREV")
       filter("TYPETEL"."ABREV" IS NOT NULL)
 866 - filter("TYPETEL"."ECRAN"='EMAIL')
 867 - filter("T_ENTMAIL"."NOT_VISIBLE"='O')
 868 - access("T_ENTMAIL"."REFMAIL"=:B1)
 869 - filter("G_INFORMATION"."EXTRANET_INVIS"='O')
 870 - access("G_INFORMATION"."REFINFO"=:B1)
*/
/********************************New Metrics***************************************/

/********************************Index statistics**********************************/

/********************************Other SQLs****************************************/          
/*

*/ 
/********************************Other SQLs****************************************/              
