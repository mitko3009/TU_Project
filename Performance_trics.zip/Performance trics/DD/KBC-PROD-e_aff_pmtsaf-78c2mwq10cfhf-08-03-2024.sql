/********************************************************************************
*********       E-mail subject: KBCCFWEB-2186
*********             Instance: PROD
*********          Description: 
Problem:
Slowness in screen e_aff_pmtsaf on PROD. The problem was reproduced on ACC1.

Analysis:
There was a slowness in e_aff_pmtsaf on PROD. The problem was reproduced on ACC1 and the query that was considered 
as slow on ACC1 was provided. This query is selecting fom V_PMTSAF_DECLARED view. The problem comes from this that after the modification of 
V_PMTSAF_DECLARED table T_ECRDOS was added in almost all of the unions in the view. This table was accessed through index IDX_FFSI_T_ECRDOS, but 
in some of the unions column CODECR on table T_ECRDOS, which is part of IDX_FFSI_T_ECRDOS index was missing, so this index is not appropriate. 
In this case, the problem comes from the second union in V_PMTSAF_DECLARED  ( qb_name(q_002) ) where column CODECR is missing. The solution here is to 
add hint in the query to access table T_ECRDOS in the qb_name(q_002) on column REFELEM through index TECR_REFELEM.

Suggestion:
Please add hint as it is shown in the New SQL section below.

*********               SQL_ID: 78c2mwq10cfhf
*********      Program/Package: e_aff_pmtsaf
*********              Request: Petar Gichev 
*********               Author: Dimitar Dimitrov
********* Received e-mail date: 07/03/2024
*********      Resolution date: 08/03/2024
*********  Trace old file here: \\epox\specifs\performance\tmp\
*********  Trace new file here:
***********************************************************************************/

/********************************OLD SQL*******************************************/

var B1 VARCHAR2(32);
exec :B1 := '1506250354';

SELECT /*+ index(@q_002 Enc G_ENC_REFDOSS_GRP_annSAF) 
           index(@q_004 Enc G_ENC_REFDOSS_GRP_annSAF)     
           index(@q_005 Fi ELEMFI_REFDOSS_GRP_CNSAF) */
       NVL(SUM(v.montant_dcmp), 0) AS TOTAL_ALL,
       NVL(SUM(nvl2(v.dtmarque_dt, v.montant_dcmp, 0)), 0) AS TOTAL_SEL
  FROM v_pmtsaf_declared v
 WHERE 1 = 1
   AND v.refdoss_dcmp = :B1
   AND v.tp IN ('E', 'A', 'F', 'C')
   AND v.dtmarque_dt IS NULL
   AND Rec_Grp_Pmtsaf = 'NP';
/********************************OLD SQL*******************************************/
/********************************OLD Metrics***************************************/
/*
Plan hash value: 21601653
--------------------------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                        | Name                      | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  |
--------------------------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                                 |                           |      1 |        |    84 (100)|      0 |00:00:00.01 |       0 |      0 |
|   1 |  SORT AGGREGATE                                  |                           |      1 |      1 |            |      0 |00:00:00.01 |       0 |      0 |
|   2 |   VIEW                                           | V_PMTSAF_DECLARED         |      1 |     12 |    84   (5)|  47892 |00:03:34.26 |      20M|  28647 |
|   3 |    UNION-ALL                                     |                           |      1 |        |            |  47892 |00:03:34.25 |      20M|  28647 |
|*  4 |     FILTER                                       |                           |      1 |        |            |  14993 |00:00:02.26 |   63743 |   4538 |
|   5 |      NESTED LOOPS OUTER                          |                           |      1 |      1 |     5   (0)|  29986 |00:00:02.25 |   63743 |   4538 |
|   6 |       NESTED LOOPS                               |                           |      1 |      1 |     4   (0)|  14993 |00:00:01.33 |   13958 |   2670 |
|   7 |        NESTED LOOPS                              |                           |      1 |      7 |     3   (0)|   1864 |00:00:00.01 |      22 |      0 |
|   8 |         NESTED LOOPS                             |                           |      1 |      1 |     2   (0)|      1 |00:00:00.01 |       7 |      0 |
|   9 |          TABLE ACCESS BY INDEX ROWID             | G_DOSSIER                 |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       4 |      0 |
|* 10 |           INDEX UNIQUE SCAN                      | DOS_REFDOSS               |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |      0 |
|* 11 |          INDEX UNIQUE SCAN                       | DOS_REFDOSS               |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |      0 |
|* 12 |         INDEX RANGE SCAN                         | G_DOSSIER_RL_CD_RD_RF_IDX |      1 |      7 |     1   (0)|   1864 |00:00:00.01 |      15 |      0 |
|* 13 |        TABLE ACCESS BY INDEX ROWID BATCHED       | G_ENCAISSEMENT            |   1864 |      1 |     1   (0)|  14993 |00:00:01.33 |   13936 |   2670 |
|* 14 |         INDEX RANGE SCAN                         | G_ENC_REFDOSS_GRP_PMTSAF  |   1864 |      6 |     1   (0)|  14993 |00:00:00.63 |    5242 |   1190 |
|* 15 |       TABLE ACCESS BY INDEX ROWID BATCHED        | T_ECRDOS                  |  14993 |      1 |     1   (0)|  29986 |00:00:00.91 |   49785 |   1868 |
|* 16 |        INDEX RANGE SCAN                          | TECR_REFELEM              |  14993 |      2 |     1   (0)|  29986 |00:00:00.09 |   38966 |    128 |
|* 17 |     FILTER                                       |                           |      1 |        |            |  32899 |00:03:31.97 |      20M|  24109 |
|  18 |      NESTED LOOPS OUTER                          |                           |      1 |      1 |     7   (0)|    131K|00:03:31.92 |      20M|  24110 |
|  19 |       NESTED LOOPS                               |                           |      1 |      1 |     6   (0)|  32900 |00:00:03.01 |   16707 |   7541 |
|  20 |        NESTED LOOPS                              |                           |      1 |      7 |     3   (0)|     42 |00:00:00.01 |      10 |      0 |
|  21 |         NESTED LOOPS                             |                           |      1 |      1 |     2   (0)|      1 |00:00:00.01 |       7 |      0 |
|  22 |          TABLE ACCESS BY INDEX ROWID             | G_DOSSIER                 |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       4 |      0 |
|* 23 |           INDEX UNIQUE SCAN                      | DOS_REFDOSS               |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |      0 |
|* 24 |          INDEX UNIQUE SCAN                       | DOS_REFDOSS               |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |      0 |
|* 25 |         INDEX RANGE SCAN                         | G_DOSSIER_RL_CD_RD_RF_IDX |      1 |      7 |     1   (0)|     42 |00:00:00.01 |       3 |      0 |
|* 26 |        TABLE ACCESS BY INDEX ROWID BATCHED       | G_ENCAISSEMENT            |     42 |      1 |     1   (0)|  32900 |00:00:03.00 |   16697 |   7541 |
|* 27 |         INDEX RANGE SCAN                         | G_ENC_REFDOSS_GRP_ANNSAF  |     42 |     62 |     1   (0)|  32900 |00:00:00.08 |     243 |    157 |
|* 28 |       TABLE ACCESS BY INDEX ROWID BATCHED        | T_ECRDOS                  |  32900 |      1 |     1   (0)|    131K|00:03:28.89 |      20M|  16569 |
|* 29 |        INDEX RANGE SCAN                          | IDX_FFSI_T_ECRDOS         |  32900 |      1 |     1   (0)|    131K|00:03:22.42 |      20M|   4381 |
|  30 |     NESTED LOOPS                                 |                           |      0 |      1 |     7   (0)|      0 |00:00:00.01 |       0 |      0 |
|  31 |      NESTED LOOPS                                |                           |      0 |      2 |     7   (0)|      0 |00:00:00.01 |       0 |      0 |
|  32 |       NESTED LOOPS                               |                           |      0 |      1 |     6   (0)|      0 |00:00:00.01 |       0 |      0 |
|  33 |        NESTED LOOPS OUTER                        |                           |      0 |      1 |     5   (0)|      0 |00:00:00.01 |       0 |      0 |
|  34 |         NESTED LOOPS                             |                           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|  35 |          NESTED LOOPS                            |                           |      0 |      7 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|  36 |           NESTED LOOPS                           |                           |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 37 |            INDEX RANGE SCAN                      | DOS_REFDOSS_REFLOT_IDX    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 38 |            INDEX UNIQUE SCAN                     | DOS_REFDOSS               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 39 |           INDEX RANGE SCAN                       | G_DOSSIER_RL_CD_RD_RF_IDX |      0 |      7 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 40 |          TABLE ACCESS BY INDEX ROWID BATCHED     | G_ENCAISSEMENT            |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 41 |           INDEX RANGE SCAN                       | G_ENC_REFDOSS_GRP_PMTSAF  |      0 |      6 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 42 |         INDEX RANGE SCAN                         | IDX_FFSI_T_ECRDOS         |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|  43 |        TABLE ACCESS BY INDEX ROWID BATCHED       | F_DETFAC                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 44 |         INDEX RANGE SCAN                         | F_DETFAC_DF_REFINIT_IDX   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 45 |       INDEX RANGE SCAN                           | TECR_REFELEM              |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 46 |      TABLE ACCESS BY INDEX ROWID                 | T_ECRDOS                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|  47 |     NESTED LOOPS                                 |                           |      0 |      1 |     9   (0)|      0 |00:00:00.01 |       0 |      0 |
|  48 |      NESTED LOOPS                                |                           |      0 |      2 |     9   (0)|      0 |00:00:00.01 |       0 |      0 |
|  49 |       NESTED LOOPS                               |                           |      0 |      1 |     8   (0)|      0 |00:00:00.01 |       0 |      0 |
|  50 |        NESTED LOOPS OUTER                        |                           |      0 |      1 |     7   (0)|      0 |00:00:00.01 |       0 |      0 |
|  51 |         NESTED LOOPS                             |                           |      0 |      1 |     6   (0)|      0 |00:00:00.01 |       0 |      0 |
|  52 |          NESTED LOOPS                            |                           |      0 |      7 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|  53 |           NESTED LOOPS                           |                           |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 54 |            INDEX RANGE SCAN                      | DOS_REFDOSS_REFLOT_IDX    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 55 |            INDEX UNIQUE SCAN                     | DOS_REFDOSS               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 56 |           INDEX RANGE SCAN                       | G_DOSSIER_RL_CD_RD_RF_IDX |      0 |      7 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 57 |          TABLE ACCESS BY INDEX ROWID BATCHED     | G_ENCAISSEMENT            |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 58 |           INDEX RANGE SCAN                       | G_ENC_REFDOSS_GRP_ANNSAF  |      0 |     62 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 59 |         INDEX RANGE SCAN                         | IDX_FFSI_T_ECRDOS         |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|  60 |        TABLE ACCESS BY INDEX ROWID BATCHED       | F_DETFAC                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 61 |         INDEX RANGE SCAN                         | F_DETFAC_DF_REFINIT_IDX   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 62 |       INDEX RANGE SCAN                           | TECR_REFELEM              |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 63 |      TABLE ACCESS BY INDEX ROWID                 | T_ECRDOS                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|  64 |     NESTED LOOPS                                 |                           |      0 |      1 |     5   (0)|      0 |00:00:00.01 |       0 |      0 |
|  65 |      NESTED LOOPS                                |                           |      0 |      2 |     5   (0)|      0 |00:00:00.01 |       0 |      0 |
|  66 |       NESTED LOOPS                               |                           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|  67 |        NESTED LOOPS                              |                           |      0 |      7 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|  68 |         NESTED LOOPS                             |                           |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 69 |          INDEX RANGE SCAN                        | DOS_REFDOSS_REFLOT_IDX    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 70 |          INDEX UNIQUE SCAN                       | DOS_REFDOSS               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 71 |         INDEX RANGE SCAN                         | G_DOSSIER_RL_CD_RD_RF_IDX |      0 |      7 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 72 |        TABLE ACCESS BY INDEX ROWID BATCHED       | G_ELEMFI                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 73 |         INDEX RANGE SCAN                         | ELEMFI_REFDOSS_GRP_CNSAF  |      0 |     33 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 74 |       INDEX RANGE SCAN                           | TECR_REFELEM              |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 75 |      TABLE ACCESS BY INDEX ROWID                 | T_ECRDOS                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|  76 |     NESTED LOOPS                                 |                           |      0 |      1 |     5   (0)|      0 |00:00:00.01 |       0 |      0 |
|  77 |      NESTED LOOPS                                |                           |      0 |      2 |     5   (0)|      0 |00:00:00.01 |       0 |      0 |
|  78 |       NESTED LOOPS                               |                           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|  79 |        NESTED LOOPS                              |                           |      0 |      7 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|  80 |         NESTED LOOPS                             |                           |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 81 |          INDEX RANGE SCAN                        | DOS_REFDOSS_REFLOT_IDX    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 82 |          INDEX UNIQUE SCAN                       | DOS_REFDOSS               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 83 |         INDEX RANGE SCAN                         | G_DOSSIER_RL_CD_RD_RF_IDX |      0 |      7 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 84 |        TABLE ACCESS BY INDEX ROWID BATCHED       | G_ELEMFI                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 85 |         INDEX RANGE SCAN                         | GE_REFDOSS_DTANNUL_IDX    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 86 |       INDEX RANGE SCAN                           | TECR_REFELEM              |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 87 |      TABLE ACCESS BY INDEX ROWID                 | T_ECRDOS                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 88 |     FILTER                                       |                           |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  89 |      NESTED LOOPS                                |                           |      0 |      8 |     5   (0)|      0 |00:00:00.01 |       0 |      0 |
|  90 |       NESTED LOOPS                               |                           |      0 |    350 |     5   (0)|      0 |00:00:00.01 |       0 |      0 |
|  91 |        NESTED LOOPS                              |                           |      0 |      7 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|  92 |         NESTED LOOPS                             |                           |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|  93 |          TABLE ACCESS BY INDEX ROWID             | G_DOSSIER                 |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 94 |           INDEX UNIQUE SCAN                      | DOS_REFDOSS               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 95 |          INDEX UNIQUE SCAN                       | DOS_REFDOSS               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 96 |         INDEX RANGE SCAN                         | G_DOSSIER_RL_CD_RD_RF_IDX |      0 |      7 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 97 |        INDEX RANGE SCAN                          | G_ENCREFD_TRAITE          |      0 |     50 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 98 |       TABLE ACCESS BY INDEX ROWID                | G_ENCAISSEMENT            |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|  99 |     NESTED LOOPS                                 |                           |      0 |      1 |     7   (0)|      0 |00:00:00.01 |       0 |      0 |
| 100 |      NESTED LOOPS                                |                           |      0 |      2 |     7   (0)|      0 |00:00:00.01 |       0 |      0 |
| 101 |       NESTED LOOPS                               |                           |      0 |      1 |     6   (0)|      0 |00:00:00.01 |       0 |      0 |
| 102 |        MERGE JOIN CARTESIAN                      |                           |      0 |      1 |     5   (0)|      0 |00:00:00.01 |       0 |      0 |
| 103 |         MERGE JOIN CARTESIAN                     |                           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
| 104 |          NESTED LOOPS                            |                           |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
| 105 |           NESTED LOOPS                           |                           |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*106 |            INDEX RANGE SCAN                      | DOS_REFDOSS_REFLOT_IDX    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*107 |            INDEX UNIQUE SCAN                     | DOS_REFDOSS               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*108 |           INDEX RANGE SCAN                       | PK_G_ETUDE                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 109 |          BUFFER SORT                             |                           |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*110 |           TABLE ACCESS BY INDEX ROWID BATCHED    | G_PIECE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*111 |            INDEX RANGE SCAN                      | PIE_REFDOSS               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 112 |         BUFFER SORT                              |                           |      0 |      7 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*113 |          INDEX RANGE SCAN                        | G_DOSSIER_RL_CD_RD_RF_IDX |      0 |      7 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*114 |        TABLE ACCESS BY INDEX ROWID BATCHED       | G_ELEMFI                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*115 |         INDEX RANGE SCAN                         | EFI_DOS_DTEMIS_TYPE       |      0 |      5 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*116 |       INDEX RANGE SCAN                           | TECR_REFELEM              |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*117 |      TABLE ACCESS BY INDEX ROWID                 | T_ECRDOS                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 118 |     NESTED LOOPS                                 |                           |      0 |      1 |     8   (0)|      0 |00:00:00.01 |       0 |      0 |
| 119 |      NESTED LOOPS                                |                           |      0 |      2 |     8   (0)|      0 |00:00:00.01 |       0 |      0 |
| 120 |       NESTED LOOPS                               |                           |      0 |      1 |     7   (0)|      0 |00:00:00.01 |       0 |      0 |
| 121 |        MERGE JOIN CARTESIAN                      |                           |      0 |      1 |     6   (0)|      0 |00:00:00.01 |       0 |      0 |
| 122 |         MERGE JOIN CARTESIAN                     |                           |      0 |      1 |     5   (0)|      0 |00:00:00.01 |       0 |      0 |
| 123 |          NESTED LOOPS                            |                           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
| 124 |           NESTED LOOPS                           |                           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
| 125 |            NESTED LOOPS                          |                           |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
| 126 |             NESTED LOOPS                         |                           |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*127 |              INDEX RANGE SCAN                    | DOS_REFDOSS_REFLOT_IDX    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*128 |              INDEX UNIQUE SCAN                   | DOS_REFDOSS               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 129 |             TABLE ACCESS BY INDEX ROWID BATCHED  | G_PIECE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*130 |              INDEX RANGE SCAN                    | PIE_REFDOSS               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*131 |            INDEX UNIQUE SCAN                     | REFPIECE_IDX              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*132 |           TABLE ACCESS BY INDEX ROWID            | G_CF_CONTRACT             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 133 |          BUFFER SORT                             |                           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*134 |           INDEX RANGE SCAN                       | PK_G_ETUDE                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 135 |         BUFFER SORT                              |                           |      0 |      7 |     5   (0)|      0 |00:00:00.01 |       0 |      0 |
|*136 |          INDEX RANGE SCAN                        | G_DOSSIER_RL_CD_RD_RF_IDX |      0 |      7 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*137 |        TABLE ACCESS BY INDEX ROWID BATCHED       | G_ELEMFI                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*138 |         INDEX RANGE SCAN                         | G_ELEMFI_DOS_TYP_FG02     |      0 |      3 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*139 |       INDEX RANGE SCAN                           | TECR_REFELEM              |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*140 |      TABLE ACCESS BY INDEX ROWID                 | T_ECRDOS                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 141 |     NESTED LOOPS                                 |                           |      0 |      1 |     8   (0)|      0 |00:00:00.01 |       0 |      0 |
| 142 |      NESTED LOOPS                                |                           |      0 |      2 |     8   (0)|      0 |00:00:00.01 |       0 |      0 |
| 143 |       NESTED LOOPS                               |                           |      0 |      1 |     7   (0)|      0 |00:00:00.01 |       0 |      0 |
| 144 |        MERGE JOIN CARTESIAN                      |                           |      0 |      1 |     6   (0)|      0 |00:00:00.01 |       0 |      0 |
| 145 |         MERGE JOIN CARTESIAN                     |                           |      0 |      1 |     5   (0)|      0 |00:00:00.01 |       0 |      0 |
| 146 |          NESTED LOOPS                            |                           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
| 147 |           NESTED LOOPS                           |                           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
| 148 |            NESTED LOOPS                          |                           |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
| 149 |             NESTED LOOPS                         |                           |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*150 |              INDEX RANGE SCAN                    | DOS_REFDOSS_REFLOT_IDX    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*151 |              INDEX UNIQUE SCAN                   | DOS_REFDOSS               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 152 |             TABLE ACCESS BY INDEX ROWID BATCHED  | G_PIECE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*153 |              INDEX RANGE SCAN                    | PIE_REFDOSS               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*154 |            INDEX UNIQUE SCAN                     | REFPIECE_IDX              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*155 |           TABLE ACCESS BY INDEX ROWID            | G_CF_CONTRACT             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 156 |          BUFFER SORT                             |                           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*157 |           INDEX RANGE SCAN                       | PK_G_ETUDE                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 158 |         BUFFER SORT                              |                           |      0 |      7 |     5   (0)|      0 |00:00:00.01 |       0 |      0 |
|*159 |          INDEX RANGE SCAN                        | G_DOSSIER_RL_CD_RD_RF_IDX |      0 |      7 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*160 |        TABLE ACCESS BY INDEX ROWID BATCHED       | G_ELEMFI                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*161 |         INDEX RANGE SCAN                         | GE_REFDOSS_DTANNUL_IDX    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*162 |       INDEX RANGE SCAN                           | TECR_REFELEM              |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*163 |      TABLE ACCESS BY INDEX ROWID                 | T_ECRDOS                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 164 |     MERGE JOIN CARTESIAN                         |                           |      0 |      2 |    15   (0)|      0 |00:00:00.01 |       0 |      0 |
| 165 |      VIEW                                        | VW_JF_SET$491BD96D        |      0 |      2 |    14   (0)|      0 |00:00:00.01 |       0 |      0 |
| 166 |       UNION-ALL                                  |                           |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 167 |        NESTED LOOPS                              |                           |      0 |      1 |     7   (0)|      0 |00:00:00.01 |       0 |      0 |
| 168 |         NESTED LOOPS                             |                           |      0 |      2 |     7   (0)|      0 |00:00:00.01 |       0 |      0 |
| 169 |          NESTED LOOPS                            |                           |      0 |      1 |     6   (0)|      0 |00:00:00.01 |       0 |      0 |
| 170 |           MERGE JOIN CARTESIAN                   |                           |      0 |      1 |     5   (0)|      0 |00:00:00.01 |       0 |      0 |
| 171 |            NESTED LOOPS                          |                           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
| 172 |             NESTED LOOPS                         |                           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
| 173 |              NESTED LOOPS                        |                           |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
| 174 |               NESTED LOOPS                       |                           |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*175 |                INDEX RANGE SCAN                  | DOS_REFDOSS_REFLOT_IDX    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*176 |                INDEX UNIQUE SCAN                 | DOS_REFDOSS               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 177 |               TABLE ACCESS BY INDEX ROWID BATCHED| G_PIECE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*178 |                INDEX RANGE SCAN                  | PIE_REFDOSS               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*179 |              INDEX UNIQUE SCAN                   | REFPIECE_IDX              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*180 |             TABLE ACCESS BY INDEX ROWID          | G_CF_CONTRACT             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 181 |            BUFFER SORT                           |                           |      0 |      7 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*182 |             INDEX RANGE SCAN                     | G_DOSSIER_RL_CD_RD_RF_IDX |      0 |      7 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*183 |           TABLE ACCESS BY INDEX ROWID BATCHED    | G_ELEMFI                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*184 |            INDEX RANGE SCAN                      | GE_REFDOSS_DTANNUL_IDX    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*185 |          INDEX RANGE SCAN                        | TECR_REFELEM              |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*186 |         TABLE ACCESS BY INDEX ROWID              | T_ECRDOS                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 187 |        NESTED LOOPS                              |                           |      0 |      1 |     7   (0)|      0 |00:00:00.01 |       0 |      0 |
| 188 |         NESTED LOOPS                             |                           |      0 |      2 |     7   (0)|      0 |00:00:00.01 |       0 |      0 |
| 189 |          NESTED LOOPS                            |                           |      0 |      1 |     6   (0)|      0 |00:00:00.01 |       0 |      0 |
| 190 |           MERGE JOIN CARTESIAN                   |                           |      0 |      1 |     5   (0)|      0 |00:00:00.01 |       0 |      0 |
| 191 |            NESTED LOOPS                          |                           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
| 192 |             NESTED LOOPS                         |                           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
| 193 |              NESTED LOOPS                        |                           |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
| 194 |               NESTED LOOPS                       |                           |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*195 |                INDEX RANGE SCAN                  | DOS_REFDOSS_REFLOT_IDX    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*196 |                INDEX UNIQUE SCAN                 | DOS_REFDOSS               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 197 |               TABLE ACCESS BY INDEX ROWID BATCHED| G_PIECE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*198 |                INDEX RANGE SCAN                  | PIE_REFDOSS               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*199 |              INDEX UNIQUE SCAN                   | REFPIECE_IDX              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*200 |             TABLE ACCESS BY INDEX ROWID          | G_CF_CONTRACT             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 201 |            BUFFER SORT                           |                           |      0 |      7 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*202 |             INDEX RANGE SCAN                     | G_DOSSIER_RL_CD_RD_RF_IDX |      0 |      7 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*203 |           TABLE ACCESS BY INDEX ROWID BATCHED    | G_ELEMFI                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*204 |            INDEX RANGE SCAN                      | G_ELEMFI_DOS_TYP_FG02     |      0 |      3 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*205 |          INDEX RANGE SCAN                        | TECR_REFELEM              |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*206 |         TABLE ACCESS BY INDEX ROWID              | T_ECRDOS                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 207 |      BUFFER SORT                                 |                           |      0 |      1 |    15   (0)|      0 |00:00:00.01 |       0 |      0 |
|*208 |       INDEX RANGE SCAN                           | PK_G_ETUDE                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
--------------------------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   4 - filter(("ENC"."REFDOSS"=DECODE("ENC"."TYPENCAISS",'e_saencaiss',DECODE("ENC"."CREATEUR",'DB_POSITIONS',"ENC"."REFDOSS",'DB_POSITIONS_ABS',"ENC"
              ."REFDOSS","AMTDCPT"."REFDOSS"),"ENC"."REFDOSS") AND (DECODE("ENC"."TYPENCAISS",'e_saencaiss',DECODE("ENC"."CREATEUR",'DB_POSITIONS','RFIN','DB_POSITI
              ONS_ABS','RFIN',"AMTDCPT"."CODECR"),'RFIN')='RFIN' OR DECODE("ENC"."TYPENCAISS",'e_saencaiss',DECODE("ENC"."CREATEUR",'DB_POSITIONS','RFIN','DB_POSITI
              ONS_ABS','RFIN',"AMTDCPT"."CODECR"),'RFIN')='ENCAT')))
  10 - access("DECO"."REFDOSS"=:B1)
  11 - access("DECO"."REFLOT"="CONTR"."REFDOSS")
  12 - access("CMP"."REFLOT"=:B1 AND "CMP"."CATEGDOSS" LIKE 'COMPTE%')
       filter("CMP"."CATEGDOSS" LIKE 'COMPTE%')
  13 - filter(("ENC"."DTMARQUE_DT" IS NULL AND INTERNAL_FUNCTION("ENC"."TYPENCAISS") AND
              DECODE("ENC"."TYPENCAISS",'e_saencaiss',"ENC"."MOYENPAIMT",'PAIEMENT DECLARE')='PAIEMENT DECLARE' AND TO_NUMBER("ENC"."TRAITE")=2 AND
              NVL("ENC"."CREATEUR",'x')<>'e_lettrage2_PTCX'))
  14 - access("ENC"."REFDOSS"="CMP"."REFDOSS" AND "ENC"."REC_GRP_PMTSAF"='NP')
  15 - filter(("AMTDCPT"."TYPELEM"=DECODE("ENC"."CREATEUR",'DB_POSITIONS','x','DB_POSITIONS_ABS','x','e') AND "AMTDCPT"."REJET" IS NULL))
  16 - access("AMTDCPT"."REFELEM"="ENC"."REFENCAISS")
  17 - filter((DECODE("ENC"."TYPENCAISS",'e_saencaiss',DECODE("ENC"."CREATEUR",'DB_POSITIONS','RFIN','DB_POSITIONS_ABS','RFIN',"AMTDCPT"."CODECR"),'RF
              IN')='RFIN' OR DECODE("ENC"."TYPENCAISS",'e_saencaiss',DECODE("ENC"."CREATEUR",'DB_POSITIONS','RFIN','DB_POSITIONS_ABS','RFIN',"AMTDCPT"."CODECR"),'RF
              IN')='ENCAT'))
  23 - access("DECO"."REFDOSS"=:B1)
  24 - access("DECO"."REFLOT"="CONTR"."REFDOSS")
  25 - access("CMP"."REFLOT"=:B1 AND "CMP"."CATEGDOSS" LIKE 'COMPTE%')
       filter("CMP"."CATEGDOSS" LIKE 'COMPTE%')
  26 - filter(("ENC"."DTANNUL_DT" IS NOT NULL AND "ENC"."DTMARQUE_DT" IS NOT NULL AND INTERNAL_FUNCTION("ENC"."TYPENCAISS") AND
              TO_NUMBER("ENC"."TRAITE")=9 AND DECODE("ENC"."TYPENCAISS",'e_saencaiss',"ENC"."MOYENPAIMT",'PAIEMENT DECLARE')='PAIEMENT DECLARE' AND
              "ENC"."DTMARQUE_AN_DT" IS NULL AND NVL("ENC"."CREATEUR",'x')<>'e_lettrage2_PTCX'))
  27 - access("ENC"."REFDOSS"="CMP"."REFDOSS" AND "ENC"."REC_GRP_ANNSAF"='NP')
  28 - filter("AMTDCPT"."REJET" IS NULL)
  29 - access("AMTDCPT"."REFDOSS"="ENC"."REFDOSS" AND "AMTDCPT"."TYPELEM"=DECODE("ENC"."CREATEUR",'DB_POSITIONS','x','DB_POSITIONS_ABS','x','e') AND
              "AMTDCPT"."REFELEM"="ENC"."REFENCAISS")
       filter("AMTDCPT"."REFELEM"="ENC"."REFENCAISS")
  37 - access("DECO"."REFDOSS"=:B1)
  38 - access("DECO"."REFLOT"="CONTR"."REFDOSS")
  39 - access("CMP"."REFLOT"=:B1 AND "CMP"."CATEGDOSS" LIKE 'COMPTE%')
       filter("CMP"."CATEGDOSS" LIKE 'COMPTE%')
  40 - filter(("ENC"."DTMARQUE_DT" IS NULL AND "ENC"."CREATEUR"='e_lettrage2_PTCX' AND "ENC"."MOYENPAIMT"='PAIEMENT DECLARE' AND
              "ENC"."TYPENCAISS"='e_saencaiss' AND TO_NUMBER("ENC"."TRAITE")=2))
  41 - access("ENC"."REFDOSS"="CMP"."REFDOSS" AND "ENC"."REC_GRP_PMTSAF"='NP')
  42 - access("AMTDCPT"."REFDOSS"="ENC"."REFDOSS" AND "AMTDCPT"."TYPELEM"='e' AND "AMTDCPT"."CODECR"='RFIN' AND
              "AMTDCPT"."REFELEM"="ENC"."REFENCAISS")
  44 - access("DBTFA"."DF_REFINIT"="ENC"."REFENCAISS" AND "DBTFA"."DF_NOM"='RINDS')
  45 - access("RINDS"."REFELEM"="DBTFA"."DF_NUM")
  46 - filter("RINDS"."CODECR"='RINDS')
  54 - access("DECO"."REFDOSS"=:B1)
  55 - access("DECO"."REFLOT"="CONTR"."REFDOSS")
  56 - access("CMP"."REFLOT"=:B1 AND "CMP"."CATEGDOSS" LIKE 'COMPTE%')
       filter("CMP"."CATEGDOSS" LIKE 'COMPTE%')
  57 - filter(("ENC"."DTANNUL_DT" IS NOT NULL AND "ENC"."DTMARQUE_DT" IS NOT NULL AND "ENC"."CREATEUR"='e_lettrage2_PTCX' AND
              "ENC"."MOYENPAIMT"='PAIEMENT DECLARE' AND "ENC"."TYPENCAISS"='e_saencaiss' AND TO_NUMBER("ENC"."TRAITE")=9 AND "ENC"."DTMARQUE_AN_DT" IS NULL))
  58 - access("ENC"."REFDOSS"="CMP"."REFDOSS" AND "ENC"."REC_GRP_ANNSAF"='NP')
  59 - access("AMTDCPT"."REFDOSS"="ENC"."REFDOSS" AND "AMTDCPT"."TYPELEM"='e' AND "AMTDCPT"."CODECR"='RFIN' AND
              "AMTDCPT"."REFELEM"="ENC"."REFENCAISS")
  61 - access("DBTFA"."DF_REFINIT"="ENC"."REFENCAISS" AND "DBTFA"."DF_NOM"='RINDS')
  62 - access("RINDS"."REFELEM"="DBTFA"."DF_NUM")
  63 - filter("RINDS"."CODECR"='RINDS')
  69 - access("DECO"."REFDOSS"=:B1)
  70 - access("DECO"."REFLOT"="CONTR"."REFDOSS")
  71 - access("CMP"."REFLOT"=:B1 AND "CMP"."CATEGDOSS" LIKE 'COMPTE%')
       filter("CMP"."CATEGDOSS" LIKE 'COMPTE%')
  72 - filter((INTERNAL_FUNCTION("FI"."TYPE") AND "FI"."DTMARQUE_DT" IS NULL AND
              DECODE(INTERNAL_FUNCTION("FI"."DTMARQUE_DT"),NULL,"FI"."DTANNUL_DT",NULL) IS NULL))
  73 - access("FI"."REFDOSS"="CMP"."REFDOSS" AND "FI"."REC_GRP_CNSAF"='NP')
  74 - access("AMTMEMO"."REFELEM"="FI"."REFELEM")
  75 - filter(("FI"."REFDOSS"="AMTMEMO"."REFDOSS" AND NVL("AMTMEMO"."CODECR",'x')='PRIN'))
  81 - access("DECO"."REFDOSS"=:B1)
  82 - access("DECO"."REFLOT"="CONTR"."REFDOSS")
  83 - access("CMP"."REFLOT"=:B1 AND "CMP"."CATEGDOSS" LIKE 'COMPTE%')
       filter("CMP"."CATEGDOSS" LIKE 'COMPTE%')
  84 - filter(("FI"."DTMARQUE_DT" IS NOT NULL AND "FI"."REC_GRP_ANSAF"='NP' AND INTERNAL_FUNCTION("FI"."TYPE") AND "FI"."DTMARQUE_AN_DT" IS NULL))
  85 - access("FI"."REFDOSS"="CMP"."REFDOSS")
       filter("FI"."DTANNUL_DT" IS NOT NULL)
  86 - access("AMTMEMO"."REFELEM"="FI"."REFELEM")
  87 - filter(("FI"."REFDOSS"="AMTMEMO"."REFDOSS" AND NVL("AMTMEMO"."CODECR",'x')='APRIN'))
  88 - filter(NULL IS NOT NULL)
  94 - access("DECO"."REFDOSS"=:B1)
  95 - access("DECO"."REFLOT"="CONTR"."REFDOSS")
  96 - access("CMP"."REFLOT"=:B1 AND "CMP"."CATEGDOSS" LIKE 'COMPTE%')
       filter("CMP"."CATEGDOSS" LIKE 'COMPTE%')
  97 - access("ENC"."REFDOSS"="CMP"."REFDOSS" AND "ENC"."TYPENCAISS"='ptf_reconcil_saf')
       filter(("ENC"."TYPENCAISS"='ptf_reconcil_saf' AND TO_NUMBER("ENC"."TRAITE")=2))
  98 - filter("ENC"."DTENCAISS_DT" IS NULL)
 106 - access("DECO"."REFDOSS"=:B1)
 107 - access("DECO"."REFLOT"="CONTR"."REFDOSS")
 108 - access("GETDCLI"='C519')
 110 - filter("SC"."FG227"='O')
 111 - access("SC"."REFDOSS"=:B1 AND "SC"."TYPPIECE"='SOUS-CONTRAT')
 113 - access("CMP"."REFLOT"=:B1 AND "CMP"."CATEGDOSS" LIKE 'COMPTE%')
       filter("CMP"."CATEGDOSS" LIKE 'COMPTE%')
 114 - filter(("FI"."REC_GRP_CNSAF"='NP' AND "FI"."DTMARQUE_DT" IS NULL))
 115 - access("FI"."REFDOSS"="CMP"."REFDOSS")
       filter(("FI"."TYPE"='ANNULATION DAVOIRS PAR DES REGLEMENTS' OR "FI"."TYPE"='NON MATCHED PAYMENT ELEMENTS' OR "FI"."TYPE"='POSITIVE LTL
              DECLARED PAYMENTS'))
 116 - access("AMTMEMO"."REFELEM"="FI"."REFELEM")
 117 - filter(("AMTMEMO"."REFDOSS"="FI"."REFDOSS" AND "AMTMEMO"."CODECR"='DPRIN'))
 127 - access("DECO"."REFDOSS"=:B1)
 128 - access("DECO"."REFLOT"="CONTR"."REFDOSS")
 130 - access("CTR"."REFDOSS"="CONTR"."REFDOSS" AND "CTR"."TYPPIECE"='CONTRAT')
       filter("CTR"."REFDOSS" IS NOT NULL)
 131 - access("CF"."REFPIECE"="CTR"."REFPIECE")
 132 - filter("CF"."FG_FINBAL"='O')
 134 - access("GETDCLI"='C519')
 136 - access("CMP"."REFLOT"=:B1 AND "CMP"."CATEGDOSS" LIKE 'COMPTE%')
       filter("CMP"."CATEGDOSS" LIKE 'COMPTE%')
 137 - filter(("FI"."REC_GRP_CNSAF"='NP' AND "FI"."DTMARQUE_DT" IS NULL AND DECODE(INTERNAL_FUNCTION("FI"."DTMARQUE_DT"),NULL,"FI"."DTANNUL_DT",NULL)
              IS NULL))
 138 - access("FI"."REFDOSS"="CMP"."REFDOSS")
       filter(("FI"."TYPE"='OPERATION DIVERSE CREDITRICE' OR "FI"."TYPE"='OPERATION DIVERSE DEBITRICE'))
 139 - access("AMTMEMO"."REFELEM"="FI"."REFELEM")
 140 - filter(("FI"."REFDOSS"="AMTMEMO"."REFDOSS" AND NVL("AMTMEMO"."CODECR",'x')='PRIN'))
 150 - access("DECO"."REFDOSS"=:B1)
 151 - access("DECO"."REFLOT"="CONTR"."REFDOSS")
 153 - access("CTR"."REFDOSS"="CONTR"."REFDOSS" AND "CTR"."TYPPIECE"='CONTRAT')
       filter("CTR"."REFDOSS" IS NOT NULL)
 154 - access("CF"."REFPIECE"="CTR"."REFPIECE")
 155 - filter("CF"."FG_FINBAL"='O')
 157 - access("GETDCLI"='C519')
 159 - access("CMP"."REFLOT"=:B1 AND "CMP"."CATEGDOSS" LIKE 'COMPTE%')
       filter("CMP"."CATEGDOSS" LIKE 'COMPTE%')
 160 - filter(("FI"."DTMARQUE_DT" IS NOT NULL AND "FI"."REC_GRP_ANSAF"='NP' AND INTERNAL_FUNCTION("FI"."TYPE") AND "FI"."DTMARQUE_AN_DT" IS NULL))
 161 - access("FI"."REFDOSS"="CMP"."REFDOSS")
       filter("FI"."DTANNUL_DT" IS NOT NULL)
 162 - access("AMTMEMO"."REFELEM"="FI"."REFELEM")
 163 - filter(("FI"."REFDOSS"="AMTMEMO"."REFDOSS" AND NVL("AMTMEMO"."CODECR",'x')='ADPRI'))
 175 - access("DECO"."REFDOSS"=:B1)
 176 - access("DECO"."REFLOT"="CONTR"."REFDOSS")
 178 - access("CTR"."REFDOSS"="CONTR"."REFDOSS" AND "CTR"."TYPPIECE"='CONTRAT')
       filter("CTR"."REFDOSS" IS NOT NULL)
 179 - access("CF"."REFPIECE"="CTR"."REFPIECE")
 180 - filter("CF"."FG_FINBAL"='O')
 182 - access("CMP"."REFLOT"=:B1 AND "CMP"."CATEGDOSS" LIKE 'COMPTE%')
       filter("CMP"."CATEGDOSS" LIKE 'COMPTE%')
 183 - filter(("FI"."DTMARQUE_DT" IS NOT NULL AND "FI"."REC_GRP_ANSAF"='NP' AND INTERNAL_FUNCTION("FI"."TYPE") AND "FI"."DTMARQUE_AN_DT" IS NULL))
 184 - access("FI"."REFDOSS"="CMP"."REFDOSS")
       filter("FI"."DTANNUL_DT" IS NOT NULL)
 185 - access("AMTMEMO"."REFELEM"="FI"."REFELEM")
 186 - filter(("FI"."REFDOSS"="AMTMEMO"."REFDOSS" AND NVL("AMTMEMO"."CODECR",'x')='APRIN'))
 195 - access("DECO"."REFDOSS"=:B1)
 196 - access("DECO"."REFLOT"="CONTR"."REFDOSS")
 198 - access("CTR"."REFDOSS"="CONTR"."REFDOSS" AND "CTR"."TYPPIECE"='CONTRAT')
       filter("CTR"."REFDOSS" IS NOT NULL)
 199 - access("CF"."REFPIECE"="CTR"."REFPIECE")
 200 - filter("CF"."FG_FINBAL"='O')
 202 - access("CMP"."REFLOT"=:B1 AND "CMP"."CATEGDOSS" LIKE 'COMPTE%')
       filter("CMP"."CATEGDOSS" LIKE 'COMPTE%')
 203 - filter(("FI"."REC_GRP_CNSAF"='NP' AND "FI"."DTMARQUE_DT" IS NULL AND DECODE(INTERNAL_FUNCTION("FI"."DTMARQUE_DT"),NULL,"FI"."DTANNUL_DT",NULL)
              IS NULL))
 204 - access("FI"."REFDOSS"="CMP"."REFDOSS")
       filter(("FI"."TYPE"='ANNULATION ODC' OR "FI"."TYPE"='ANNULATION ODD'))
 205 - access("AMTMEMO"."REFELEM"="FI"."REFELEM")
 206 - filter(("FI"."REFDOSS"="AMTMEMO"."REFDOSS" AND NVL("AMTMEMO"."CODECR",'x')='DPRIN'))
 208 - access("GETDCLI"='C519')

*/
/********************************OLD Metrics***************************************/

/********************************New SQL*******************************************/

SELECT /*+ index(@q_002 Enc G_ENC_REFDOSS_GRP_annSAF)
           index(@q_002 AmtDcpt TECR_REFELEM) 
           index(@q_004 Enc G_ENC_REFDOSS_GRP_annSAF)     
           index(@q_005 Fi ELEMFI_REFDOSS_GRP_CNSAF) */
       NVL(SUM(v.montant_dcmp), 0) AS TOTAL_ALL,
       NVL(SUM(nvl2(v.dtmarque_dt, v.montant_dcmp, 0)), 0) AS TOTAL_SEL
  FROM v_pmtsaf_declared v
 WHERE 1 = 1
   AND v.refdoss_dcmp = :B1
   AND v.tp IN ('E', 'A', 'F', 'C')
   AND v.dtmarque_dt IS NULL
   AND Rec_Grp_Pmtsaf = 'NP';
/********************************New SQL*******************************************/
/********************************New Metrics***************************************/
/*
Plan hash value: 686649940
--------------------------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                        | Name                      | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  |
--------------------------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                                 |                           |      1 |        |    84 (100)|      1 |00:00:03.28 |     642K|   5388 |
|   1 |  SORT AGGREGATE                                  |                           |      1 |      1 |            |      1 |00:00:03.28 |     642K|   5388 |
|   2 |   VIEW                                           | V_PMTSAF_DECLARED         |      1 |     12 |    84   (5)|    118K|00:00:03.26 |     642K|   5388 |
|   3 |    UNION-ALL                                     |                           |      1 |        |            |    118K|00:00:03.25 |     642K|   5388 |
|*  4 |     FILTER                                       |                           |      1 |        |            |  14993 |00:00:00.10 |   63704 |      0 |
|   5 |      NESTED LOOPS OUTER                          |                           |      1 |      1 |     5   (0)|  29986 |00:00:00.09 |   63704 |      0 |
|   6 |       NESTED LOOPS                               |                           |      1 |      1 |     4   (0)|  14993 |00:00:00.03 |   13957 |      0 |
|   7 |        NESTED LOOPS                              |                           |      1 |      7 |     3   (0)|   1864 |00:00:00.01 |      22 |      0 |
|   8 |         NESTED LOOPS                             |                           |      1 |      1 |     2   (0)|      1 |00:00:00.01 |       7 |      0 |
|   9 |          TABLE ACCESS BY INDEX ROWID             | G_DOSSIER                 |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       4 |      0 |
|* 10 |           INDEX UNIQUE SCAN                      | DOS_REFDOSS               |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |      0 |
|* 11 |          INDEX UNIQUE SCAN                       | DOS_REFDOSS               |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |      0 |
|* 12 |         INDEX RANGE SCAN                         | G_DOSSIER_RL_CD_RD_RF_IDX |      1 |      7 |     1   (0)|   1864 |00:00:00.01 |      15 |      0 |
|* 13 |        TABLE ACCESS BY INDEX ROWID BATCHED       | G_ENCAISSEMENT            |   1864 |      1 |     1   (0)|  14993 |00:00:00.03 |   13935 |      0 |
|* 14 |         INDEX RANGE SCAN                         | G_ENC_REFDOSS_GRP_PMTSAF  |   1864 |      6 |     1   (0)|  14993 |00:00:00.01 |    5242 |      0 |
|* 15 |       TABLE ACCESS BY INDEX ROWID BATCHED        | T_ECRDOS                  |  14993 |      1 |     1   (0)|  29986 |00:00:00.05 |   49747 |      0 |
|* 16 |        INDEX RANGE SCAN                          | TECR_REFELEM              |  14993 |      2 |     1   (0)|  29986 |00:00:00.03 |   38966 |      0 |
|* 17 |     FILTER                                       |                           |      1 |        |            |    102K|00:00:00.92 |     507K|      0 |
|  18 |      NESTED LOOPS OUTER                          |                           |      1 |      1 |     7   (0)|    409K|00:00:00.85 |     507K|      0 |
|  19 |       NESTED LOOPS                               |                           |      1 |      1 |     6   (0)|    102K|00:00:00.18 |   38616 |      0 |
|  20 |        NESTED LOOPS                              |                           |      1 |      7 |     3   (0)|   1864 |00:00:00.01 |      22 |      0 |
|  21 |         NESTED LOOPS                             |                           |      1 |      1 |     2   (0)|      1 |00:00:00.01 |       7 |      0 |
|  22 |          TABLE ACCESS BY INDEX ROWID             | G_DOSSIER                 |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       4 |      0 |
|* 23 |           INDEX UNIQUE SCAN                      | DOS_REFDOSS               |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |      0 |
|* 24 |          INDEX UNIQUE SCAN                       | DOS_REFDOSS               |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |      0 |
|* 25 |         INDEX RANGE SCAN                         | G_DOSSIER_RL_CD_RD_RF_IDX |      1 |      7 |     1   (0)|   1864 |00:00:00.01 |      15 |      0 |
|* 26 |        TABLE ACCESS BY INDEX ROWID BATCHED       | G_ENCAISSEMENT            |   1864 |      1 |     1   (0)|    102K|00:00:00.17 |   38594 |      0 |
|* 27 |         INDEX RANGE SCAN                         | G_ENC_REFDOSS_GRP_ANNSAF  |   1864 |     62 |     1   (0)|    102K|00:00:00.02 |    5452 |      0 |
|* 28 |       TABLE ACCESS BY INDEX ROWID BATCHED        | T_ECRDOS                  |    102K|      1 |     1   (0)|    409K|00:00:00.62 |     469K|      0 |
|* 29 |        INDEX RANGE SCAN                          | TECR_REFELEM              |    102K|      2 |     1   (0)|    409K|00:00:00.22 |     245K|      0 |
|  30 |     NESTED LOOPS                                 |                           |      1 |      1 |     7   (0)|      0 |00:00:00.02 |   13956 |      0 |
|  31 |      NESTED LOOPS                                |                           |      1 |      2 |     7   (0)|      0 |00:00:00.02 |   13956 |      0 |
|  32 |       NESTED LOOPS                               |                           |      1 |      1 |     6   (0)|      0 |00:00:00.02 |   13956 |      0 |
|  33 |        NESTED LOOPS OUTER                        |                           |      1 |      1 |     5   (0)|      0 |00:00:00.02 |   13956 |      0 |
|  34 |         NESTED LOOPS                             |                           |      1 |      1 |     4   (0)|      0 |00:00:00.02 |   13956 |      0 |
|  35 |          NESTED LOOPS                            |                           |      1 |      7 |     3   (0)|   1864 |00:00:00.01 |      21 |      0 |
|  36 |           NESTED LOOPS                           |                           |      1 |      1 |     2   (0)|      1 |00:00:00.01 |       6 |      0 |
|* 37 |            INDEX RANGE SCAN                      | DOS_REFDOSS_REFLOT_IDX    |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |      0 |
|* 38 |            INDEX UNIQUE SCAN                     | DOS_REFDOSS               |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |      0 |
|* 39 |           INDEX RANGE SCAN                       | G_DOSSIER_RL_CD_RD_RF_IDX |      1 |      7 |     1   (0)|   1864 |00:00:00.01 |      15 |      0 |
|* 40 |          TABLE ACCESS BY INDEX ROWID BATCHED     | G_ENCAISSEMENT            |   1864 |      1 |     1   (0)|      0 |00:00:00.02 |   13935 |      0 |
|* 41 |           INDEX RANGE SCAN                       | G_ENC_REFDOSS_GRP_PMTSAF  |   1864 |      6 |     1   (0)|  14993 |00:00:00.01 |    5242 |      0 |
|* 42 |         INDEX RANGE SCAN                         | IDX_FFSI_T_ECRDOS         |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|  43 |        TABLE ACCESS BY INDEX ROWID BATCHED       | F_DETFAC                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 44 |         INDEX RANGE SCAN                         | F_DETFAC_DF_REFINIT_IDX   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 45 |       INDEX RANGE SCAN                           | TECR_REFELEM              |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 46 |      TABLE ACCESS BY INDEX ROWID                 | T_ECRDOS                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|  47 |     NESTED LOOPS                                 |                           |      1 |      1 |     9   (0)|      0 |00:00:00.09 |   38615 |      0 |
|  48 |      NESTED LOOPS                                |                           |      1 |      2 |     9   (0)|      0 |00:00:00.09 |   38615 |      0 |
|  49 |       NESTED LOOPS                               |                           |      1 |      1 |     8   (0)|      0 |00:00:00.09 |   38615 |      0 |
|  50 |        NESTED LOOPS OUTER                        |                           |      1 |      1 |     7   (0)|      0 |00:00:00.09 |   38615 |      0 |
|  51 |         NESTED LOOPS                             |                           |      1 |      1 |     6   (0)|      0 |00:00:00.09 |   38615 |      0 |
|  52 |          NESTED LOOPS                            |                           |      1 |      7 |     3   (0)|   1864 |00:00:00.01 |      21 |      0 |
|  53 |           NESTED LOOPS                           |                           |      1 |      1 |     2   (0)|      1 |00:00:00.01 |       6 |      0 |
|* 54 |            INDEX RANGE SCAN                      | DOS_REFDOSS_REFLOT_IDX    |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |      0 |
|* 55 |            INDEX UNIQUE SCAN                     | DOS_REFDOSS               |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |      0 |
|* 56 |           INDEX RANGE SCAN                       | G_DOSSIER_RL_CD_RD_RF_IDX |      1 |      7 |     1   (0)|   1864 |00:00:00.01 |      15 |      0 |
|* 57 |          TABLE ACCESS BY INDEX ROWID BATCHED     | G_ENCAISSEMENT            |   1864 |      1 |     1   (0)|      0 |00:00:00.09 |   38594 |      0 |
|* 58 |           INDEX RANGE SCAN                       | G_ENC_REFDOSS_GRP_ANNSAF  |   1864 |     62 |     1   (0)|    102K|00:00:00.02 |    5452 |      0 |
|* 59 |         INDEX RANGE SCAN                         | IDX_FFSI_T_ECRDOS         |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|  60 |        TABLE ACCESS BY INDEX ROWID BATCHED       | F_DETFAC                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 61 |         INDEX RANGE SCAN                         | F_DETFAC_DF_REFINIT_IDX   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 62 |       INDEX RANGE SCAN                           | TECR_REFELEM              |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 63 |      TABLE ACCESS BY INDEX ROWID                 | T_ECRDOS                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|  64 |     NESTED LOOPS                                 |                           |      1 |      1 |     5   (0)|   1290 |00:00:00.54 |    9822 |   1282 |
|  65 |      NESTED LOOPS                                |                           |      1 |      2 |     5   (0)|   2496 |00:00:00.43 |    8295 |   1078 |
|  66 |       NESTED LOOPS                               |                           |      1 |      1 |     4   (0)|   1290 |00:00:00.41 |    5636 |   1057 |
|  67 |        NESTED LOOPS                              |                           |      1 |      7 |     3   (0)|   1864 |00:00:00.01 |      21 |      0 |
|  68 |         NESTED LOOPS                             |                           |      1 |      1 |     2   (0)|      1 |00:00:00.01 |       6 |      0 |
|* 69 |          INDEX RANGE SCAN                        | DOS_REFDOSS_REFLOT_IDX    |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |      0 |
|* 70 |          INDEX UNIQUE SCAN                       | DOS_REFDOSS               |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |      0 |
|* 71 |         INDEX RANGE SCAN                         | G_DOSSIER_RL_CD_RD_RF_IDX |      1 |      7 |     1   (0)|   1864 |00:00:00.01 |      15 |      0 |
|* 72 |        TABLE ACCESS BY INDEX ROWID BATCHED       | G_ELEMFI                  |   1864 |      1 |     1   (0)|   1290 |00:00:00.41 |    5615 |   1057 |
|* 73 |         INDEX RANGE SCAN                         | ELEMFI_REFDOSS_GRP_CNSAF  |   1864 |     33 |     1   (0)|   1290 |00:00:00.37 |    5159 |    921 |
|* 74 |       INDEX RANGE SCAN                           | TECR_REFELEM              |   1290 |      2 |     1   (0)|   2496 |00:00:00.02 |    2659 |     21 |
|* 75 |      TABLE ACCESS BY INDEX ROWID                 | T_ECRDOS                  |   2496 |      1 |     1   (0)|   1290 |00:00:00.11 |    1527 |    204 |
|  76 |     NESTED LOOPS                                 |                           |      1 |      1 |     5   (0)|      0 |00:00:01.56 |    8819 |   4106 |
|  77 |      NESTED LOOPS                                |                           |      1 |      2 |     5   (0)|      0 |00:00:01.56 |    8819 |   4106 |
|  78 |       NESTED LOOPS                               |                           |      1 |      1 |     4   (0)|      0 |00:00:01.56 |    8819 |   4106 |
|  79 |        NESTED LOOPS                              |                           |      1 |      7 |     3   (0)|   1864 |00:00:00.01 |      21 |      0 |
|  80 |         NESTED LOOPS                             |                           |      1 |      1 |     2   (0)|      1 |00:00:00.01 |       6 |      0 |
|* 81 |          INDEX RANGE SCAN                        | DOS_REFDOSS_REFLOT_IDX    |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |      0 |
|* 82 |          INDEX UNIQUE SCAN                       | DOS_REFDOSS               |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |      0 |
|* 83 |         INDEX RANGE SCAN                         | G_DOSSIER_RL_CD_RD_RF_IDX |      1 |      7 |     1   (0)|   1864 |00:00:00.01 |      15 |      0 |
|* 84 |        TABLE ACCESS BY INDEX ROWID BATCHED       | G_ELEMFI                  |   1864 |      1 |     1   (0)|      0 |00:00:01.55 |    8798 |   4106 |
|* 85 |         INDEX RANGE SCAN                         | GE_REFDOSS_DTANNUL_IDX    |   1864 |      1 |     1   (0)|   2734 |00:00:01.24 |    8026 |   3334 |
|* 86 |       INDEX RANGE SCAN                           | TECR_REFELEM              |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 87 |      TABLE ACCESS BY INDEX ROWID                 | T_ECRDOS                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 88 |     FILTER                                       |                           |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  89 |      NESTED LOOPS                                |                           |      0 |      8 |     5   (0)|      0 |00:00:00.01 |       0 |      0 |
|  90 |       NESTED LOOPS                               |                           |      0 |    350 |     5   (0)|      0 |00:00:00.01 |       0 |      0 |
|  91 |        NESTED LOOPS                              |                           |      0 |      7 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|  92 |         NESTED LOOPS                             |                           |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|  93 |          TABLE ACCESS BY INDEX ROWID             | G_DOSSIER                 |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 94 |           INDEX UNIQUE SCAN                      | DOS_REFDOSS               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 95 |          INDEX UNIQUE SCAN                       | DOS_REFDOSS               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 96 |         INDEX RANGE SCAN                         | G_DOSSIER_RL_CD_RD_RF_IDX |      0 |      7 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 97 |        INDEX RANGE SCAN                          | G_ENCREFD_TRAITE          |      0 |     50 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 98 |       TABLE ACCESS BY INDEX ROWID                | G_ENCAISSEMENT            |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|  99 |     NESTED LOOPS                                 |                           |      1 |      1 |     7   (0)|      0 |00:00:00.01 |       7 |      0 |
| 100 |      NESTED LOOPS                                |                           |      1 |      2 |     7   (0)|      0 |00:00:00.01 |       7 |      0 |
| 101 |       NESTED LOOPS                               |                           |      1 |      1 |     6   (0)|      0 |00:00:00.01 |       7 |      0 |
| 102 |        MERGE JOIN CARTESIAN                      |                           |      1 |      1 |     5   (0)|      0 |00:00:00.01 |       7 |      0 |
| 103 |         MERGE JOIN CARTESIAN                     |                           |      1 |      1 |     4   (0)|      0 |00:00:00.01 |       7 |      0 |
| 104 |          NESTED LOOPS                            |                           |      1 |      1 |     3   (0)|      0 |00:00:00.01 |       7 |      0 |
| 105 |           NESTED LOOPS                           |                           |      1 |      1 |     2   (0)|      1 |00:00:00.01 |       6 |      0 |
|*106 |            INDEX RANGE SCAN                      | DOS_REFDOSS_REFLOT_IDX    |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |      0 |
|*107 |            INDEX UNIQUE SCAN                     | DOS_REFDOSS               |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |      0 |
|*108 |           INDEX RANGE SCAN                       | PK_G_ETUDE                |      1 |      1 |     1   (0)|      0 |00:00:00.01 |       1 |      0 |
| 109 |          BUFFER SORT                             |                           |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*110 |           TABLE ACCESS BY INDEX ROWID BATCHED    | G_PIECE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*111 |            INDEX RANGE SCAN                      | PIE_REFDOSS               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 112 |         BUFFER SORT                              |                           |      0 |      7 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*113 |          INDEX RANGE SCAN                        | G_DOSSIER_RL_CD_RD_RF_IDX |      0 |      7 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*114 |        TABLE ACCESS BY INDEX ROWID BATCHED       | G_ELEMFI                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*115 |         INDEX RANGE SCAN                         | EFI_DOS_DTEMIS_TYPE       |      0 |      5 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*116 |       INDEX RANGE SCAN                           | TECR_REFELEM              |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*117 |      TABLE ACCESS BY INDEX ROWID                 | T_ECRDOS                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 118 |     NESTED LOOPS                                 |                           |      1 |      1 |     8   (0)|      0 |00:00:00.01 |      14 |      0 |
| 119 |      NESTED LOOPS                                |                           |      1 |      2 |     8   (0)|      0 |00:00:00.01 |      14 |      0 |
| 120 |       NESTED LOOPS                               |                           |      1 |      1 |     7   (0)|      0 |00:00:00.01 |      14 |      0 |
| 121 |        MERGE JOIN CARTESIAN                      |                           |      1 |      1 |     6   (0)|      0 |00:00:00.01 |      14 |      0 |
| 122 |         MERGE JOIN CARTESIAN                     |                           |      1 |      1 |     5   (0)|      0 |00:00:00.01 |      14 |      0 |
| 123 |          NESTED LOOPS                            |                           |      1 |      1 |     4   (0)|      0 |00:00:00.01 |      14 |      0 |
| 124 |           NESTED LOOPS                           |                           |      1 |      1 |     4   (0)|      1 |00:00:00.01 |      13 |      0 |
| 125 |            NESTED LOOPS                          |                           |      1 |      1 |     3   (0)|      1 |00:00:00.01 |      11 |      0 |
| 126 |             NESTED LOOPS                         |                           |      1 |      1 |     2   (0)|      1 |00:00:00.01 |       6 |      0 |
|*127 |              INDEX RANGE SCAN                    | DOS_REFDOSS_REFLOT_IDX    |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |      0 |
|*128 |              INDEX UNIQUE SCAN                   | DOS_REFDOSS               |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |      0 |
| 129 |             TABLE ACCESS BY INDEX ROWID BATCHED  | G_PIECE                   |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       5 |      0 |
|*130 |              INDEX RANGE SCAN                    | PIE_REFDOSS               |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       4 |      0 |
|*131 |            INDEX UNIQUE SCAN                     | REFPIECE_IDX              |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       2 |      0 |
|*132 |           TABLE ACCESS BY INDEX ROWID            | G_CF_CONTRACT             |      1 |      1 |     1   (0)|      0 |00:00:00.01 |       1 |      0 |
| 133 |          BUFFER SORT                             |                           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*134 |           INDEX RANGE SCAN                       | PK_G_ETUDE                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 135 |         BUFFER SORT                              |                           |      0 |      7 |     5   (0)|      0 |00:00:00.01 |       0 |      0 |
|*136 |          INDEX RANGE SCAN                        | G_DOSSIER_RL_CD_RD_RF_IDX |      0 |      7 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*137 |        TABLE ACCESS BY INDEX ROWID BATCHED       | G_ELEMFI                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*138 |         INDEX RANGE SCAN                         | G_ELEMFI_DOS_TYP_FG02     |      0 |      3 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*139 |       INDEX RANGE SCAN                           | TECR_REFELEM              |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*140 |      TABLE ACCESS BY INDEX ROWID                 | T_ECRDOS                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 141 |     NESTED LOOPS                                 |                           |      1 |      1 |     8   (0)|      0 |00:00:00.01 |      14 |      0 |
| 142 |      NESTED LOOPS                                |                           |      1 |      2 |     8   (0)|      0 |00:00:00.01 |      14 |      0 |
| 143 |       NESTED LOOPS                               |                           |      1 |      1 |     7   (0)|      0 |00:00:00.01 |      14 |      0 |
| 144 |        MERGE JOIN CARTESIAN                      |                           |      1 |      1 |     6   (0)|      0 |00:00:00.01 |      14 |      0 |
| 145 |         MERGE JOIN CARTESIAN                     |                           |      1 |      1 |     5   (0)|      0 |00:00:00.01 |      14 |      0 |
| 146 |          NESTED LOOPS                            |                           |      1 |      1 |     4   (0)|      0 |00:00:00.01 |      14 |      0 |
| 147 |           NESTED LOOPS                           |                           |      1 |      1 |     4   (0)|      1 |00:00:00.01 |      13 |      0 |
| 148 |            NESTED LOOPS                          |                           |      1 |      1 |     3   (0)|      1 |00:00:00.01 |      11 |      0 |
| 149 |             NESTED LOOPS                         |                           |      1 |      1 |     2   (0)|      1 |00:00:00.01 |       6 |      0 |
|*150 |              INDEX RANGE SCAN                    | DOS_REFDOSS_REFLOT_IDX    |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |      0 |
|*151 |              INDEX UNIQUE SCAN                   | DOS_REFDOSS               |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |      0 |
| 152 |             TABLE ACCESS BY INDEX ROWID BATCHED  | G_PIECE                   |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       5 |      0 |
|*153 |              INDEX RANGE SCAN                    | PIE_REFDOSS               |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       4 |      0 |
|*154 |            INDEX UNIQUE SCAN                     | REFPIECE_IDX              |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       2 |      0 |
|*155 |           TABLE ACCESS BY INDEX ROWID            | G_CF_CONTRACT             |      1 |      1 |     1   (0)|      0 |00:00:00.01 |       1 |      0 |
| 156 |          BUFFER SORT                             |                           |      0 |      1 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*157 |           INDEX RANGE SCAN                       | PK_G_ETUDE                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 158 |         BUFFER SORT                              |                           |      0 |      7 |     5   (0)|      0 |00:00:00.01 |       0 |      0 |
|*159 |          INDEX RANGE SCAN                        | G_DOSSIER_RL_CD_RD_RF_IDX |      0 |      7 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*160 |        TABLE ACCESS BY INDEX ROWID BATCHED       | G_ELEMFI                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*161 |         INDEX RANGE SCAN                         | GE_REFDOSS_DTANNUL_IDX    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*162 |       INDEX RANGE SCAN                           | TECR_REFELEM              |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*163 |      TABLE ACCESS BY INDEX ROWID                 | T_ECRDOS                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 164 |     MERGE JOIN CARTESIAN                         |                           |      1 |      2 |    15   (0)|      0 |00:00:00.01 |      28 |      0 |
| 165 |      VIEW                                        | VW_JF_SET$491BD96D        |      1 |      2 |    14   (0)|      0 |00:00:00.01 |      28 |      0 |
| 166 |       UNION-ALL                                  |                           |      1 |        |            |      0 |00:00:00.01 |      28 |      0 |
| 167 |        NESTED LOOPS                              |                           |      1 |      1 |     7   (0)|      0 |00:00:00.01 |      14 |      0 |
| 168 |         NESTED LOOPS                             |                           |      1 |      2 |     7   (0)|      0 |00:00:00.01 |      14 |      0 |
| 169 |          NESTED LOOPS                            |                           |      1 |      1 |     6   (0)|      0 |00:00:00.01 |      14 |      0 |
| 170 |           MERGE JOIN CARTESIAN                   |                           |      1 |      1 |     5   (0)|      0 |00:00:00.01 |      14 |      0 |
| 171 |            NESTED LOOPS                          |                           |      1 |      1 |     4   (0)|      0 |00:00:00.01 |      14 |      0 |
| 172 |             NESTED LOOPS                         |                           |      1 |      1 |     4   (0)|      1 |00:00:00.01 |      13 |      0 |
| 173 |              NESTED LOOPS                        |                           |      1 |      1 |     3   (0)|      1 |00:00:00.01 |      11 |      0 |
| 174 |               NESTED LOOPS                       |                           |      1 |      1 |     2   (0)|      1 |00:00:00.01 |       6 |      0 |
|*175 |                INDEX RANGE SCAN                  | DOS_REFDOSS_REFLOT_IDX    |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |      0 |
|*176 |                INDEX UNIQUE SCAN                 | DOS_REFDOSS               |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |      0 |
| 177 |               TABLE ACCESS BY INDEX ROWID BATCHED| G_PIECE                   |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       5 |      0 |
|*178 |                INDEX RANGE SCAN                  | PIE_REFDOSS               |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       4 |      0 |
|*179 |              INDEX UNIQUE SCAN                   | REFPIECE_IDX              |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       2 |      0 |
|*180 |             TABLE ACCESS BY INDEX ROWID          | G_CF_CONTRACT             |      1 |      1 |     1   (0)|      0 |00:00:00.01 |       1 |      0 |
| 181 |            BUFFER SORT                           |                           |      0 |      7 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*182 |             INDEX RANGE SCAN                     | G_DOSSIER_RL_CD_RD_RF_IDX |      0 |      7 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*183 |           TABLE ACCESS BY INDEX ROWID BATCHED    | G_ELEMFI                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*184 |            INDEX RANGE SCAN                      | GE_REFDOSS_DTANNUL_IDX    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*185 |          INDEX RANGE SCAN                        | TECR_REFELEM              |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*186 |         TABLE ACCESS BY INDEX ROWID              | T_ECRDOS                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 187 |        NESTED LOOPS                              |                           |      1 |      1 |     7   (0)|      0 |00:00:00.01 |      14 |      0 |
| 188 |         NESTED LOOPS                             |                           |      1 |      2 |     7   (0)|      0 |00:00:00.01 |      14 |      0 |
| 189 |          NESTED LOOPS                            |                           |      1 |      1 |     6   (0)|      0 |00:00:00.01 |      14 |      0 |
| 190 |           MERGE JOIN CARTESIAN                   |                           |      1 |      1 |     5   (0)|      0 |00:00:00.01 |      14 |      0 |
| 191 |            NESTED LOOPS                          |                           |      1 |      1 |     4   (0)|      0 |00:00:00.01 |      14 |      0 |
| 192 |             NESTED LOOPS                         |                           |      1 |      1 |     4   (0)|      1 |00:00:00.01 |      13 |      0 |
| 193 |              NESTED LOOPS                        |                           |      1 |      1 |     3   (0)|      1 |00:00:00.01 |      11 |      0 |
| 194 |               NESTED LOOPS                       |                           |      1 |      1 |     2   (0)|      1 |00:00:00.01 |       6 |      0 |
|*195 |                INDEX RANGE SCAN                  | DOS_REFDOSS_REFLOT_IDX    |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |      0 |
|*196 |                INDEX UNIQUE SCAN                 | DOS_REFDOSS               |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |      0 |
| 197 |               TABLE ACCESS BY INDEX ROWID BATCHED| G_PIECE                   |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       5 |      0 |
|*198 |                INDEX RANGE SCAN                  | PIE_REFDOSS               |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       4 |      0 |
|*199 |              INDEX UNIQUE SCAN                   | REFPIECE_IDX              |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       2 |      0 |
|*200 |             TABLE ACCESS BY INDEX ROWID          | G_CF_CONTRACT             |      1 |      1 |     1   (0)|      0 |00:00:00.01 |       1 |      0 |
| 201 |            BUFFER SORT                           |                           |      0 |      7 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*202 |             INDEX RANGE SCAN                     | G_DOSSIER_RL_CD_RD_RF_IDX |      0 |      7 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*203 |           TABLE ACCESS BY INDEX ROWID BATCHED    | G_ELEMFI                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*204 |            INDEX RANGE SCAN                      | G_ELEMFI_DOS_TYP_FG02     |      0 |      3 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*205 |          INDEX RANGE SCAN                        | TECR_REFELEM              |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*206 |         TABLE ACCESS BY INDEX ROWID              | T_ECRDOS                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 207 |      BUFFER SORT                                 |                           |      0 |      1 |    15   (0)|      0 |00:00:00.01 |       0 |      0 |
|*208 |       INDEX RANGE SCAN                           | PK_G_ETUDE                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
--------------------------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   4 - filter(("ENC"."REFDOSS"=DECODE("ENC"."TYPENCAISS",'e_saencaiss',DECODE("ENC"."CREATEUR",'DB_POSITIONS',"ENC"."REFDOSS",'DB_POSITIONS_ABS',"ENC"
              ."REFDOSS","AMTDCPT"."REFDOSS"),"ENC"."REFDOSS") AND (DECODE("ENC"."TYPENCAISS",'e_saencaiss',DECODE("ENC"."CREATEUR",'DB_POSITIONS','RFIN','DB_POSITI
              ONS_ABS','RFIN',"AMTDCPT"."CODECR"),'RFIN')='RFIN' OR DECODE("ENC"."TYPENCAISS",'e_saencaiss',DECODE("ENC"."CREATEUR",'DB_POSITIONS','RFIN','DB_POSITI
              ONS_ABS','RFIN',"AMTDCPT"."CODECR"),'RFIN')='ENCAT')))
  10 - access("DECO"."REFDOSS"=:B1)
  11 - access("DECO"."REFLOT"="CONTR"."REFDOSS")
  12 - access("CMP"."REFLOT"=:B1 AND "CMP"."CATEGDOSS" LIKE 'COMPTE%')
       filter("CMP"."CATEGDOSS" LIKE 'COMPTE%')
  13 - filter(("ENC"."DTMARQUE_DT" IS NULL AND INTERNAL_FUNCTION("ENC"."TYPENCAISS") AND
              DECODE("ENC"."TYPENCAISS",'e_saencaiss',"ENC"."MOYENPAIMT",'PAIEMENT DECLARE')='PAIEMENT DECLARE' AND TO_NUMBER("ENC"."TRAITE")=2 AND
              NVL("ENC"."CREATEUR",'x')<>'e_lettrage2_PTCX'))
  14 - access("ENC"."REFDOSS"="CMP"."REFDOSS" AND "ENC"."REC_GRP_PMTSAF"='NP')
  15 - filter(("AMTDCPT"."TYPELEM"=DECODE("ENC"."CREATEUR",'DB_POSITIONS','x','DB_POSITIONS_ABS','x','e') AND "AMTDCPT"."REJET" IS NULL))
  16 - access("AMTDCPT"."REFELEM"="ENC"."REFENCAISS")
  17 - filter((DECODE("ENC"."TYPENCAISS",'e_saencaiss',DECODE("ENC"."CREATEUR",'DB_POSITIONS','RFIN','DB_POSITIONS_ABS','RFIN',"AMTDCPT"."CODECR"),'RF
              IN')='RFIN' OR DECODE("ENC"."TYPENCAISS",'e_saencaiss',DECODE("ENC"."CREATEUR",'DB_POSITIONS','RFIN','DB_POSITIONS_ABS','RFIN',"AMTDCPT"."CODECR"),'RF
              IN')='ENCAT'))
  23 - access("DECO"."REFDOSS"=:B1)
  24 - access("DECO"."REFLOT"="CONTR"."REFDOSS")
  25 - access("CMP"."REFLOT"=:B1 AND "CMP"."CATEGDOSS" LIKE 'COMPTE%')
       filter("CMP"."CATEGDOSS" LIKE 'COMPTE%')
  26 - filter(("ENC"."DTANNUL_DT" IS NOT NULL AND "ENC"."DTMARQUE_DT" IS NOT NULL AND INTERNAL_FUNCTION("ENC"."TYPENCAISS") AND
              TO_NUMBER("ENC"."TRAITE")=9 AND DECODE("ENC"."TYPENCAISS",'e_saencaiss',"ENC"."MOYENPAIMT",'PAIEMENT DECLARE')='PAIEMENT DECLARE' AND
              "ENC"."DTMARQUE_AN_DT" IS NULL AND NVL("ENC"."CREATEUR",'x')<>'e_lettrage2_PTCX'))
  27 - access("ENC"."REFDOSS"="CMP"."REFDOSS" AND "ENC"."REC_GRP_ANNSAF"='NP')
  28 - filter(("AMTDCPT"."REFDOSS"="ENC"."REFDOSS" AND "AMTDCPT"."TYPELEM"=DECODE("ENC"."CREATEUR",'DB_POSITIONS','x','DB_POSITIONS_ABS','x','e') AND
              "AMTDCPT"."REJET" IS NULL))
  29 - access("AMTDCPT"."REFELEM"="ENC"."REFENCAISS")
  37 - access("DECO"."REFDOSS"=:B1)
  38 - access("DECO"."REFLOT"="CONTR"."REFDOSS")
  39 - access("CMP"."REFLOT"=:B1 AND "CMP"."CATEGDOSS" LIKE 'COMPTE%')
       filter("CMP"."CATEGDOSS" LIKE 'COMPTE%')
  40 - filter(("ENC"."DTMARQUE_DT" IS NULL AND "ENC"."CREATEUR"='e_lettrage2_PTCX' AND "ENC"."MOYENPAIMT"='PAIEMENT DECLARE' AND
              "ENC"."TYPENCAISS"='e_saencaiss' AND TO_NUMBER("ENC"."TRAITE")=2))
  41 - access("ENC"."REFDOSS"="CMP"."REFDOSS" AND "ENC"."REC_GRP_PMTSAF"='NP')
  42 - access("AMTDCPT"."REFDOSS"="ENC"."REFDOSS" AND "AMTDCPT"."TYPELEM"='e' AND "AMTDCPT"."CODECR"='RFIN' AND
              "AMTDCPT"."REFELEM"="ENC"."REFENCAISS")
  44 - access("DBTFA"."DF_REFINIT"="ENC"."REFENCAISS" AND "DBTFA"."DF_NOM"='RINDS')
  45 - access("RINDS"."REFELEM"="DBTFA"."DF_NUM")
  46 - filter("RINDS"."CODECR"='RINDS')
  54 - access("DECO"."REFDOSS"=:B1)
  55 - access("DECO"."REFLOT"="CONTR"."REFDOSS")
  56 - access("CMP"."REFLOT"=:B1 AND "CMP"."CATEGDOSS" LIKE 'COMPTE%')
       filter("CMP"."CATEGDOSS" LIKE 'COMPTE%')
  57 - filter(("ENC"."DTANNUL_DT" IS NOT NULL AND "ENC"."DTMARQUE_DT" IS NOT NULL AND "ENC"."CREATEUR"='e_lettrage2_PTCX' AND
              "ENC"."MOYENPAIMT"='PAIEMENT DECLARE' AND "ENC"."TYPENCAISS"='e_saencaiss' AND TO_NUMBER("ENC"."TRAITE")=9 AND "ENC"."DTMARQUE_AN_DT" IS NULL))
  58 - access("ENC"."REFDOSS"="CMP"."REFDOSS" AND "ENC"."REC_GRP_ANNSAF"='NP')
  59 - access("AMTDCPT"."REFDOSS"="ENC"."REFDOSS" AND "AMTDCPT"."TYPELEM"='e' AND "AMTDCPT"."CODECR"='RFIN' AND
              "AMTDCPT"."REFELEM"="ENC"."REFENCAISS")
  61 - access("DBTFA"."DF_REFINIT"="ENC"."REFENCAISS" AND "DBTFA"."DF_NOM"='RINDS')
  62 - access("RINDS"."REFELEM"="DBTFA"."DF_NUM")
  63 - filter("RINDS"."CODECR"='RINDS')
  69 - access("DECO"."REFDOSS"=:B1)
  70 - access("DECO"."REFLOT"="CONTR"."REFDOSS")
  71 - access("CMP"."REFLOT"=:B1 AND "CMP"."CATEGDOSS" LIKE 'COMPTE%')
       filter("CMP"."CATEGDOSS" LIKE 'COMPTE%')
  72 - filter((INTERNAL_FUNCTION("FI"."TYPE") AND "FI"."DTMARQUE_DT" IS NULL AND
              DECODE(INTERNAL_FUNCTION("FI"."DTMARQUE_DT"),NULL,"FI"."DTANNUL_DT",NULL) IS NULL))
  73 - access("FI"."REFDOSS"="CMP"."REFDOSS" AND "FI"."REC_GRP_CNSAF"='NP')
  74 - access("AMTMEMO"."REFELEM"="FI"."REFELEM")
  75 - filter(("FI"."REFDOSS"="AMTMEMO"."REFDOSS" AND NVL("AMTMEMO"."CODECR",'x')='PRIN'))
  81 - access("DECO"."REFDOSS"=:B1)
  82 - access("DECO"."REFLOT"="CONTR"."REFDOSS")
  83 - access("CMP"."REFLOT"=:B1 AND "CMP"."CATEGDOSS" LIKE 'COMPTE%')
       filter("CMP"."CATEGDOSS" LIKE 'COMPTE%')
  84 - filter(("FI"."DTMARQUE_DT" IS NOT NULL AND "FI"."REC_GRP_ANSAF"='NP' AND INTERNAL_FUNCTION("FI"."TYPE") AND "FI"."DTMARQUE_AN_DT" IS NULL))
  85 - access("FI"."REFDOSS"="CMP"."REFDOSS")
       filter("FI"."DTANNUL_DT" IS NOT NULL)
  86 - access("AMTMEMO"."REFELEM"="FI"."REFELEM")
  87 - filter(("FI"."REFDOSS"="AMTMEMO"."REFDOSS" AND NVL("AMTMEMO"."CODECR",'x')='APRIN'))
  88 - filter(NULL IS NOT NULL)
  94 - access("DECO"."REFDOSS"=:B1)
  95 - access("DECO"."REFLOT"="CONTR"."REFDOSS")
  96 - access("CMP"."REFLOT"=:B1 AND "CMP"."CATEGDOSS" LIKE 'COMPTE%')
       filter("CMP"."CATEGDOSS" LIKE 'COMPTE%')
  97 - access("ENC"."REFDOSS"="CMP"."REFDOSS" AND "ENC"."TYPENCAISS"='ptf_reconcil_saf')
       filter(("ENC"."TYPENCAISS"='ptf_reconcil_saf' AND TO_NUMBER("ENC"."TRAITE")=2))
  98 - filter("ENC"."DTENCAISS_DT" IS NULL)
 106 - access("DECO"."REFDOSS"=:B1)
 107 - access("DECO"."REFLOT"="CONTR"."REFDOSS")
 108 - access("GETDCLI"='C519')
 110 - filter("SC"."FG227"='O')
 111 - access("SC"."REFDOSS"=:B1 AND "SC"."TYPPIECE"='SOUS-CONTRAT')
 113 - access("CMP"."REFLOT"=:B1 AND "CMP"."CATEGDOSS" LIKE 'COMPTE%')
       filter("CMP"."CATEGDOSS" LIKE 'COMPTE%')
 114 - filter(("FI"."REC_GRP_CNSAF"='NP' AND "FI"."DTMARQUE_DT" IS NULL))
 115 - access("FI"."REFDOSS"="CMP"."REFDOSS")
       filter(("FI"."TYPE"='ANNULATION DAVOIRS PAR DES REGLEMENTS' OR "FI"."TYPE"='NON MATCHED PAYMENT ELEMENTS' OR "FI"."TYPE"='POSITIVE LTL
              DECLARED PAYMENTS'))
 116 - access("AMTMEMO"."REFELEM"="FI"."REFELEM")
 117 - filter(("AMTMEMO"."REFDOSS"="FI"."REFDOSS" AND "AMTMEMO"."CODECR"='DPRIN'))
 127 - access("DECO"."REFDOSS"=:B1)
 128 - access("DECO"."REFLOT"="CONTR"."REFDOSS")
 130 - access("CTR"."REFDOSS"="CONTR"."REFDOSS" AND "CTR"."TYPPIECE"='CONTRAT')
       filter("CTR"."REFDOSS" IS NOT NULL)
 131 - access("CF"."REFPIECE"="CTR"."REFPIECE")
 132 - filter("CF"."FG_FINBAL"='O')
 134 - access("GETDCLI"='C519')
 136 - access("CMP"."REFLOT"=:B1 AND "CMP"."CATEGDOSS" LIKE 'COMPTE%')
       filter("CMP"."CATEGDOSS" LIKE 'COMPTE%')
 137 - filter(("FI"."REC_GRP_CNSAF"='NP' AND "FI"."DTMARQUE_DT" IS NULL AND DECODE(INTERNAL_FUNCTION("FI"."DTMARQUE_DT"),NULL,"FI"."DTANNUL_DT",NULL)
              IS NULL))
 138 - access("FI"."REFDOSS"="CMP"."REFDOSS")
       filter(("FI"."TYPE"='OPERATION DIVERSE CREDITRICE' OR "FI"."TYPE"='OPERATION DIVERSE DEBITRICE'))
 139 - access("AMTMEMO"."REFELEM"="FI"."REFELEM")
 140 - filter(("FI"."REFDOSS"="AMTMEMO"."REFDOSS" AND NVL("AMTMEMO"."CODECR",'x')='PRIN'))
 150 - access("DECO"."REFDOSS"=:B1)
 151 - access("DECO"."REFLOT"="CONTR"."REFDOSS")
 153 - access("CTR"."REFDOSS"="CONTR"."REFDOSS" AND "CTR"."TYPPIECE"='CONTRAT')
       filter("CTR"."REFDOSS" IS NOT NULL)
 154 - access("CF"."REFPIECE"="CTR"."REFPIECE")
 155 - filter("CF"."FG_FINBAL"='O')
 157 - access("GETDCLI"='C519')
 159 - access("CMP"."REFLOT"=:B1 AND "CMP"."CATEGDOSS" LIKE 'COMPTE%')
       filter("CMP"."CATEGDOSS" LIKE 'COMPTE%')
 160 - filter(("FI"."DTMARQUE_DT" IS NOT NULL AND "FI"."REC_GRP_ANSAF"='NP' AND INTERNAL_FUNCTION("FI"."TYPE") AND "FI"."DTMARQUE_AN_DT" IS NULL))
 161 - access("FI"."REFDOSS"="CMP"."REFDOSS")
       filter("FI"."DTANNUL_DT" IS NOT NULL)
 162 - access("AMTMEMO"."REFELEM"="FI"."REFELEM")
 163 - filter(("FI"."REFDOSS"="AMTMEMO"."REFDOSS" AND NVL("AMTMEMO"."CODECR",'x')='ADPRI'))
 175 - access("DECO"."REFDOSS"=:B1)
 176 - access("DECO"."REFLOT"="CONTR"."REFDOSS")
 178 - access("CTR"."REFDOSS"="CONTR"."REFDOSS" AND "CTR"."TYPPIECE"='CONTRAT')
       filter("CTR"."REFDOSS" IS NOT NULL)
 179 - access("CF"."REFPIECE"="CTR"."REFPIECE")
 180 - filter("CF"."FG_FINBAL"='O')
 182 - access("CMP"."REFLOT"=:B1 AND "CMP"."CATEGDOSS" LIKE 'COMPTE%')
       filter("CMP"."CATEGDOSS" LIKE 'COMPTE%')
 183 - filter(("FI"."DTMARQUE_DT" IS NOT NULL AND "FI"."REC_GRP_ANSAF"='NP' AND INTERNAL_FUNCTION("FI"."TYPE") AND "FI"."DTMARQUE_AN_DT" IS NULL))
 184 - access("FI"."REFDOSS"="CMP"."REFDOSS")
       filter("FI"."DTANNUL_DT" IS NOT NULL)
 185 - access("AMTMEMO"."REFELEM"="FI"."REFELEM")
 186 - filter(("FI"."REFDOSS"="AMTMEMO"."REFDOSS" AND NVL("AMTMEMO"."CODECR",'x')='APRIN'))
 195 - access("DECO"."REFDOSS"=:B1)
 196 - access("DECO"."REFLOT"="CONTR"."REFDOSS")
 198 - access("CTR"."REFDOSS"="CONTR"."REFDOSS" AND "CTR"."TYPPIECE"='CONTRAT')
       filter("CTR"."REFDOSS" IS NOT NULL)
 199 - access("CF"."REFPIECE"="CTR"."REFPIECE")
 200 - filter("CF"."FG_FINBAL"='O')
 202 - access("CMP"."REFLOT"=:B1 AND "CMP"."CATEGDOSS" LIKE 'COMPTE%')
       filter("CMP"."CATEGDOSS" LIKE 'COMPTE%')
 203 - filter(("FI"."REC_GRP_CNSAF"='NP' AND "FI"."DTMARQUE_DT" IS NULL AND DECODE(INTERNAL_FUNCTION("FI"."DTMARQUE_DT"),NULL,"FI"."DTANNUL_DT",NULL)
              IS NULL))
 204 - access("FI"."REFDOSS"="CMP"."REFDOSS")
       filter(("FI"."TYPE"='ANNULATION ODC' OR "FI"."TYPE"='ANNULATION ODD'))
 205 - access("AMTMEMO"."REFELEM"="FI"."REFELEM")
 206 - filter(("FI"."REFDOSS"="AMTMEMO"."REFDOSS" AND NVL("AMTMEMO"."CODECR",'x')='DPRIN'))
 208 - access("GETDCLI"='C519')
*/
/********************************New Metrics***************************************/

/********************************Index statistics**********************************/

/********************************Other SQLs****************************************/          
/*

*/ 
/********************************Other SQLs****************************************/              
