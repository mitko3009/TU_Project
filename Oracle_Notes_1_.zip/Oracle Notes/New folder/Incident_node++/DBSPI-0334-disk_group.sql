 ===========================================================================================
 ===========================================================================================
 
 ##### 	DBSPI-0334: Free space percentage 1.95 too low for RECO in database +ASM1 <=2%. ######
 
 =============================================================================================
 
[root@husexa2dbadm01 ~]# ps -ef | grep pmon
orapoim   10613      1  0 Apr05 ?        00:41:49 ora_pmon_POIM1
oratrxp   13252      1  0 Apr08 ?        00:44:05 ora_pmon_TRXP1
oraebsq  109923      1  0 Feb14 ?        00:54:11 ora_pmon_EBSQ1
orapoid  192149      1  0 Apr05 ?        00:42:26 ora_pmon_POID1
oraoimp  217988      1  0 Mar22 ?        00:42:25 ora_pmon_OIMP1
oratrxq  273703      1  0 Mar07 ?        00:56:48 ora_pmon_TRXQ1
oraoimq  281581      1  0 Mar05 ?        00:53:16 ora_pmon_OIMQ1
oraebsp  291101      1  0 May25 ?        00:22:42 ora_pmon_EBSP1
root     291338 289869  0 19:29 pts/0    00:00:00 grep pmon
oraoidq  299303      1  0 Mar07 ?        00:51:16 ora_pmon_OIDQ1
oracle   373809      1  0  2018 ?        00:28:24 asm_pmon_+ASM1
oraupk   377406      1  0  2018 ?        01:18:41 ora_pmon_UPKPROD1
oraoidp  378197      1  0 Mar22 ?        00:42:51 ora_pmon_OIDP1



[root@husexa2dbadm01 ~]# dbspicao -m334 -pv -i +ASM1                             ##### Да ни искара кои дискови групи имат най-малко място #####

ASM Instance: '+ASM1' @ '/u01/app/12.2.0/grid'
-------------------------------------------------------------
+ASM1 0334 14.34 objext=DATA diskgroup=DATA free=14758648.00 total=102903552.00 instance=+ASM1 ora_server_name=+ASM1 
+ASM1 0334 14.34 objext=DATA diskgroup=DATA free=14758648.00 total=102903552.00 instance=EBSP1 ora_server_name=+ASM1 
+ASM1 0334 14.34 objext=DATA diskgroup=DATA free=14758648.00 total=102903552.00 instance=EBSQ1 ora_server_name=+ASM1 
+ASM1 0334 14.34 objext=DATA diskgroup=DATA free=14758648.00 total=102903552.00 instance=OIDP1 ora_server_name=+ASM1 
+ASM1 0334 14.34 objext=DATA diskgroup=DATA free=14758648.00 total=102903552.00 instance=OIDQ1 ora_server_name=+ASM1 
+ASM1 0334 14.34 objext=DATA diskgroup=DATA free=14758648.00 total=102903552.00 instance=UPKPROD1 ora_server_name=+ASM1 
+ASM1 0334 14.34 objext=DATA diskgroup=DATA free=14758648.00 total=102903552.00 instance=OIMQ1 ora_server_name=+ASM1 
+ASM1 0334 14.34 objext=DATA diskgroup=DATA free=14758648.00 total=102903552.00 instance=POID1 ora_server_name=+ASM1 
+ASM1 0334 14.34 objext=DATA diskgroup=DATA free=14758648.00 total=102903552.00 instance=POIM1 ora_server_name=+ASM1 
+ASM1 0334 14.34 objext=DATA diskgroup=DATA free=14758648.00 total=102903552.00 instance=TRXP1 ora_server_name=+ASM1 
+ASM1 0334 14.34 objext=DATA diskgroup=DATA free=14758648.00 total=102903552.00 instance=TRXQ1 ora_server_name=+ASM1 
+ASM1 0334 14.34 objext=DATA diskgroup=DATA free=14758648.00 total=102903552.00 instance=OIMP1 ora_server_name=+ASM1 
+ASM1 0334 98.97 objext=DBFS_DG diskgroup=DBFS_DG free=1027496.00 total=1038240.00 instance=+ASM1 ora_server_name=+ASM1 
+ASM1 0334 98.97 objext=DBFS_DG diskgroup=DBFS_DG free=1027496.00 total=1038240.00 instance=husexa2dbadm01.hus.fi ora_server_name=+ASM1 
+ASM1 0334 78.94 objext=EBS_DATA diskgroup=EBS_DATA free=8730676.00 total=11059200.00 instance=NA ora_server_name=+ASM1 
+ASM1 0334 98.20 objext=EBS_RECO diskgroup=EBS_RECO free=10860684.00 total=11059200.00 instance=OIDQ1 ora_server_name=+ASM1 
+ASM1 0334 1.95 objext=RECO diskgroup=RECO free=216036.00 total=11059200.00 instance=EBSP1 ora_server_name=+ASM1 
+ASM1 0334 1.95 objext=RECO diskgroup=RECO free=216036.00 total=11059200.00 instance=EBSQ1 ora_server_name=+ASM1 
+ASM1 0334 1.95 objext=RECO diskgroup=RECO free=216036.00 total=11059200.00 instance=OIDP1 ora_server_name=+ASM1 
+ASM1 0334 1.95 objext=RECO diskgroup=RECO free=216036.00 total=11059200.00 instance=OIDQ1 ora_server_name=+ASM1 
+ASM1 0334 1.95 objext=RECO diskgroup=RECO free=216036.00 total=11059200.00 instance=UPKPROD1 ora_server_name=+ASM1 
+ASM1 0334 1.95 objext=RECO diskgroup=RECO free=216036.00 total=11059200.00 instance=OIMQ1 ora_server_name=+ASM1 
+ASM1 0334 1.95 objext=RECO diskgroup=RECO free=216036.00 total=11059200.00 instance=POID1 ora_server_name=+ASM1 
+ASM1 0334 1.95 objext=RECO diskgroup=RECO free=216036.00 total=11059200.00 instance=POIM1 ora_server_name=+ASM1 
+ASM1 0334 1.95 objext=RECO diskgroup=RECO free=216036.00 total=11059200.00 instance=TRXP1 ora_server_name=+ASM1 
+ASM1 0334 1.95 objext=RECO diskgroup=RECO free=216036.00 total=11059200.00 instance=TRXQ1 ora_server_name=+ASM1 
+ASM1 0334 1.95 objext=RECO diskgroup=RECO free=216036.00 total=11059200.00 instance=+ASM1 ora_server_name=+ASM1 
+ASM1 0334 1.95 objext=RECO diskgroup=RECO free=216036.00 total=11059200.00 instance=OIMP1 ora_server_name=+ASM1 



[root@husexa2dbadm01 ~]# su - oracle                                     ##### Логваме се като юзъра на +ASM в случая е oracle ####

[oracle@husexa2dbadm01 ~]$ . oraenv
ORACLE_SID = [+ASM1] ? 
The Oracle base has been set to /u01/app/oracle

[oracle@husexa2dbadm01 ~]$ sqlplus / as sysasm


##############  Check ASM disk group utilization #####

col gname form a20
col dbname form a20
col file_type form a20
set lines 300 pages 600 
SELECT
    gname,
    dbname,
    file_type,
    round(SUM(space)/1024/1024) mb,
    round(SUM(space)/1024/1024/1024) gb,
    COUNT(*) "#FILES"
FROM
    (
        SELECT
            gname,
            regexp_substr(full_alias_path, '[[:alnum:]_]*',1,4) dbname,
            file_type,
            space,
            aname,
            system_created,
            alias_directory
        FROM
            (
                SELECT
                    concat('+'||gname, sys_connect_by_path(aname, '/')) full_alias_path,
                    system_created,
                    alias_directory,
                    file_type,
                    space,
                    level,
                    gname,
                    aname
                FROM
                    (
                        SELECT
                            b.name            gname,
                            a.parent_index    pindex,
                            a.name            aname,
                            a.reference_index rindex ,
                            a.system_created,
                            a.alias_directory,
                            c.type file_type,
                            c.space
                        FROM
                            v$asm_alias a,
                            v$asm_diskgroup b,
                            v$asm_file c
                        WHERE
                            a.group_number = b.group_number
                        AND a.group_number = c.group_number(+)
                        AND a.file_number = c.file_number(+)
                        AND a.file_incarnation = c.incarnation(+) ) START WITH (mod(pindex, power(2, 24))) = 0
                AND rindex IN
                    (
                        SELECT
                            a.reference_index
                        FROM
                            v$asm_alias a,
                            v$asm_diskgroup b
                        WHERE
                            a.group_number = b.group_number
                        AND (
                                mod(a.parent_index, power(2, 24))) = 0
                            ) CONNECT BY prior rindex = pindex 
							)
        WHERE
            NOT file_type IS NULL
            and system_created = 'Y' )
GROUP BY
    gname,
    dbname,
    file_type
ORDER BY
    gname,
    dbname,
    file_type
/ 


GNAME		     DBNAME		  FILE_TYPE		       MB	  GB	 #FILES
-------------------- -------------------- -------------------- ---------- ---------- ----------
DATA		     ASM		  PARAMETERFILE 	      16	   0	      2
DATA		     DB_UNKNOWN 	  PARAMETERFILE 	       56	   0	      7
DATA		     EBSP		  CONTROLFILE		      384	   0	      2
DATA		     EBSP		  DATAFILE		   260404	 254	     61
DATA		     EBSP		  DATAGUARDCONFIG	       16	   0	      2
DATA		     EBSP		  ONLINELOG		    20488	  20	     10
DATA		     EBSP		  TEMPFILE		   100308	  98	      3
DATA		     EBSQ		  ARCHIVELOG			8	   0	      1
DATA		     EBSQ		  BACKUPSET			8	   0	      1
DATA		     EBSQ		  CONTROLFILE		      384	   0	      2
DATA		     EBSQ		  DATAFILE		   150648	 147	     60
DATA		     EBSQ		  ONLINELOG		    24240	  24	     12
DATA		     EBSQ		  PARAMETERFILE 		8	   0	      1
DATA		     EBSQ		  TEMPFILE		   127216	 124	      6
DATA		     OIDP		  CONTROLFILE		       96	   0	      1
DATA		     OIDP		  DATAFILE		    47564	  46	     10
DATA		     OIDP		  DATAGUARDCONFIG	       16	   0	      2
DATA		     OIDP		  ONLINELOG		    82120	  80	     10
DATA		     OIDP		  PARAMETERFILE 		8	   0	      1
DATA		     OIDP		  TEMPFILE		    12724	  12	      3
DATA		     OIDQ		  CONTROLFILE		      192	   0	      2
DATA		     OIDQ		  DATAFILE		    26308	  26	     10
DATA		     OIDQ		  DATAGUARDCONFIG	       16	   0	      2
DATA		     OIDQ		  ONLINELOG		   139664	 136	     20
DATA		     OIDQ		  TEMPFILE		    25448	  25	      6
DATA		     OIMP		  CONTROLFILE		     6828	   7	      1
DATA		     OIMP		  DATAFILE		   152828	 149	     14
DATA		     OIMP		  DATAGUARDCONFIG		8	   0	      1
DATA		     OIMP		  ONLINELOG		   147816	 144	     18
DATA		     OIMP		  PARAMETERFILE 		8	   0	      1
DATA		     OIMP		  TEMPFILE		    13140	  13	      5
DATA		     OIMQ		  CONTROLFILE		     3468	   3	      1
DATA		     OIMQ		  DATAFILE		   212408	 207	     27
DATA		     OIMQ		  DATAGUARDCONFIG	       32	   0	      4
DATA		     OIMQ		  ONLINELOG		   221784	 217	     30
DATA		     OIMQ		  TEMPFILE		    26280	  26	     10
DATA		     OPOIM		  CONTROLFILE		      192	   0	      2
DATA		     OPOIM		  DATAFILE		   540044	 527	     15
DATA		     OPOIM		  ONLINELOG		    65696	  64	      8
DATA		     OPOIM		  TEMPFILE		  1048844	1024	      1
DATA		     POID		  CONTROLFILE		      684	   1	      1
DATA		     POID		  DATAFILE		   123872	 121	     12
DATA		     POID		  DATAGUARDCONFIG	       16	   0	      2
DATA		     POID		  ONLINELOG		   151176	 148	     26
DATA		     POID		  PARAMETERFILE 		8	   0	      1
DATA		     POID		  TEMPFILE		    66180	  65	      4
DATA		     POIM		  CHANGETRACKING	      580	   1	      1
DATA		     POIM		  CONTROLFILE		      492	   0	      1
DATA		     POIM		  DATAFILE		 33105572      32330	    694
DATA		     POIM		  DATAGUARDCONFIG		8	   0	      1
DATA		     POIM		  ONLINELOG		   233296	 228	     36
DATA		     POIM		  TEMPFILE		  1183684	1156	     21
DATA		     TRXP		  CONTROLFILE		      192	   0	      1
DATA		     TRXP		  DATAFILE		 38916352      38004	    668
DATA		     TRXP		  DATAGUARDCONFIG	       16	   0	      2
DATA		     TRXP		  ONLINELOG		   164240	 160	     20
DATA		     TRXP		  PARAMETERFILE 		8	   0	      1
DATA		     TRXP		  TEMPFILE		   786832	 768	     14
DATA		     TRXQ		  CONTROLFILE		      192	   0	      1
DATA		     TRXQ		  DATAFILE		  9317844	9099	    462
DATA		     TRXQ		  DATAGUARDCONFIG	       16	   0	      2
DATA		     TRXQ		  ONLINELOG		   188936	 185	     26
DATA		     TRXQ		  TEMPFILE		   369464	 361	     11
DATA		     UPKPROD		  CONTROLFILE		       96	   0	      1
DATA		     UPKPROD		  DATAFILE		    23356	  23	      6
DATA		     UPKPROD		  ONLINELOG		    52992	  52	     12
DATA		     UPKPROD		  PARAMETERFILE 		8	   0	      1
DATA		     UPKPROD		  TEMPFILE		      144	   0	      1
DBFS_DG 	     ASM		  PASSWORD			0	   0	      2
DBFS_DG 	     _MGMTDB		  CONTROLFILE		       96	   0	      1
DBFS_DG 	     _MGMTDB		  DATAFILE		     8408	   8	     11
DBFS_DG 	     _MGMTDB		  ONLINELOG		      312	   0	      3
DBFS_DG 	     _MGMTDB		  PARAMETERFILE 		8	   0	      1
DBFS_DG 	     _MGMTDB		  TEMPFILE		      264	   0	      3
DBFS_DG 	     husexa2		  ASMPARAMETERFILE		8	   0	      1
DBFS_DG 	     husexa2		  OCRBACKUP		      368	   0	     12
DBFS_DG 	     husexa2		  OCRFILE		      332	   0	      1
EBS_DATA	     PHUS		  CHANGETRACKING	      224	   0	      1
EBS_DATA	     PHUS		  CONTROLFILE		      300	   0	      1
EBS_DATA	     PHUS		  DATAFILE		  1954312	1909	     57
EBS_DATA	     PHUS		  ONLINELOG		   110784	 108	     24
EBS_DATA	     PHUS		  PARAMETERFILE 		8	   0	      1
EBS_DATA	     PHUS		  TEMPFILE		   262192	 256	      4
EBS_RECO	     OIDQ		  ONLINELOG		    98544	  96	     12
EBS_RECO	     PHUS		  ARCHIVELOG		      468	   0	      5
EBS_RECO	     PHUS		  CONTROLFILE		      300	   0	      1
EBS_RECO	     PHUS		  ONLINELOG		    98544	  96	     12
RECO		     EBSP		  ARCHIVELOG		   588284	 574	    875
RECO		     EBSP		  AUTOBACKUP		      144	   0	      2
RECO		     EBSP		  BACKUPSET		    63652	  62	      1
RECO		     EBSP		  ONLINELOG		    28568	  28	     14
RECO		     EBSQ		  ARCHIVELOG		    94816	  93	    446
RECO		     EBSQ		  AUTOBACKUP		      648	   1	      9
RECO		     EBSQ		  BACKUPSET		    29096	  28	     14
RECO		     EBSQ		  CONTROLFILE		      384	   0	      2
RECO		     EBSQ		  ONLINELOG		     8080	   8	      4
RECO		     OIDP		  ARCHIVELOG		   224624	 219	   1215
RECO		     OIDP		  CONTROLFILE		      192	   0	      2
RECO		     OIDP		  FLASHBACK		    41060	  40	      5
RECO		     OIDP		  ONLINELOG		    82120	  80	     10
RECO		     OIDQ		  ARCHIVELOG		    91796	  90	   1027
RECO		     OIDQ		  AUTOBACKUP		      192	   0	      4
RECO		     OIDQ		  CONTROLFILE		      384	   0	      4
RECO		     OIDQ		  FLASHBACK		    90332	  88	     11
RECO		     OIDQ		  ONLINELOG		   139664	 136	     20
RECO		     OIMP		  ARCHIVELOG		   329748	 322	   1383
RECO		     OIMP		  CONTROLFILE		    13656	  13	      2
RECO		     OIMP		  DATAGUARDCONFIG		8	   0	      1
RECO		     OIMP		  FLASHBACK		    49272	  48	      6
RECO		     OIMP		  ONLINELOG		   147816	 144	     18
RECO		     OIMQ		  ARCHIVELOG		   233112	 228	   1202
RECO		     OIMQ		  AUTOBACKUP		    11580	  11	      5
RECO		     OIMQ		  CONTROLFILE		     7032	   7	      3
RECO		     OIMQ		  FLASHBACK		   106756	 104	     13
RECO		     OIMQ		  ONLINELOG		   221784	 217	     30
RECO		     OIMQ_TST		  FLASHBACK		    16424	  16	      2
RECO		     OPOIM		  ARCHIVELOG		      260	   0	      1
RECO		     OPOIM		  CONTROLFILE		       96	   0	      1
RECO		     OPOIM		  ONLINELOG		    65696	  64	      8
RECO		     POID		  ARCHIVELOG		   278380	 272	   1833
RECO		     POID		  AUTOBACKUP		      420	   0	      1
RECO		     POID		  BACKUPSET		      752	   1	     13
RECO		     POID		  CONTROLFILE		     1368	   1	      2
RECO		     POID		  FLASHBACK		    49272	  48	      6
RECO		     POID		  ONLINELOG		   151176	 148	     26
RECO		     POIM		  ARCHIVELOG		  1174884	1147	    353
RECO		     POIM		  CONTROLFILE		      984	   1	      2
RECO		     POIM		  DATAGUARDCONFIG		8	   0	      1
RECO		     POIM		  FLASHBACK		    57484	  56	      7
RECO		     POIM		  ONLINELOG		    69056	  67	     16
RECO		     TRXD_RE		  ARCHIVELOG		    44640	  44	      7
RECO		     TRXD_RE		  CONTROLFILE		      192	   0	      1
RECO		     TRXD_RE		  DATAFILE		   439800	 429	     33
RECO		     TRXD_RE		  ONLINELOG		    65696	  64	      8
RECO		     TRXD_RE		  TEMPFILE		    12980	  13	      5
RECO		     TRXP		  ARCHIVELOG		  2408704	2352	    367
RECO		     TRXP		  CONTROLFILE		      192	   0	      1
RECO		     TRXP		  FLASHBACK		  1609552	1572	    196
RECO		     TRXP		  ONLINELOG		   164240	 160	     20
RECO		     TRXQ		  ARCHIVELOG		  1234016	1205	    626
RECO		     TRXQ		  AUTOBACKUP		      864	   1	      9
RECO		     TRXQ		  CONTROLFILE		      768	   1	      4
RECO		     TRXQ		  DATAGUARDCONFIG		8	   0	      1
RECO		     TRXQ		  FLASHBACK		   131392	 128	     16
RECO		     TRXQ		  ONLINELOG		   188936	 185	     26
RECO		     TRXQ_TST		  FLASHBACK		    16424	  16	      2
RECO		     UPKPROD		  BACKUPSET		      620	   1	      4
RECO		     UPKPROD		  CONTROLFILE		       96	   0	      1
RECO		     UPKPROD		  ONLINELOG		    52992	  52	     12

149 rows selected.

SQL> exit

[oracle@husexa2dbadm01 ~]$ exit

root@husexa2dbadm01 ~]# su - oratrxp                                 ###### Суитчвам се като юзъра на дадената база ,която пълни , в случая е TRXP #####

Set environment

[oratrxp@husexa2dbadm01 ~]$ sqlplus / as sysdba


SQL> select database_role from v$database;                    #### Да проверя дали е праймари или стенд #####

DATABASE_ROLE
----------------
PHYSICAL STANDBY


#################### AKO E LOGICAL STANDBY ПУСКАМЕ АРХАЙВ БЕКЪП #############

################################################# ТОВА на долу СЕ ПРАВИ САМО НА ФИЗИКАЛ СТЕНБАЙ  ДА ТРИЕМ АРХАЙВ ЛОГОВЕ ПОВЕЧЕ ОТ ВЕДНЪЖ ###################################

##### ORACLE 12C - LAST RECEIVED LAST APPLY

select al.thrd "Thread", almax "Last Seq Received", lhmax "Last Seq Applied"
from (select thread# thrd, max(sequence#) almax
      from v$archived_log
      where resetlogs_change#=(select resetlogs_change# from v$database)
      group by thread#) al,
     (select thread# thrd, max(sequence#) lhmax
      from v$log_history
      where first_time=(select max(first_time) from v$log_history)
      group by thread#) lh
where al.thrd = lh.thrd;




   THREAD#  Last Recd Last Applied
---------- ---------- ------------
	 1     133063	    133062
	 2     130701	    130701





[oratrxp@husexa2dbadm01 ~]$ rman target /

==========================================================
### delete archivelog ###     И винаги оставяме някой и друг аплайнат лог ####

rman target /
delete noprompt archivelog until sequence 26075 thread 1; 
delete noprompt archivelog until sequence 24850 thread 2;  
==============================================================


RMAN> delete noprompt archivelog until sequence 133057 thread 1; 



RMAN> delete noprompt archivelog until sequence 130695 thread 2;

############################################ AKO E ПРАЙМАРИ ПУСКАМЕ ХАЙУОТЪР И НИЩО ДРУГО НЕ МОЖЕМ ДА НАПРАВИМ #################

[oratrxp@husexa2dbadm01 ~]$ logout
[root@husexa2dbadm01 ~]# dbspicao -m334 -pv -i +ASM1

ASM Instance: '+ASM1' @ '/u01/app/12.2.0/grid'
-------------------------------------------------------------
+ASM1 0334 14.34 objext=DATA diskgroup=DATA free=14758648.00 total=102903552.00 instance=+ASM1 ora_server_name=+ASM1 
+ASM1 0334 14.34 objext=DATA diskgroup=DATA free=14758648.00 total=102903552.00 instance=EBSP1 ora_server_name=+ASM1 
+ASM1 0334 14.34 objext=DATA diskgroup=DATA free=14758648.00 total=102903552.00 instance=EBSQ1 ora_server_name=+ASM1 
+ASM1 0334 14.34 objext=DATA diskgroup=DATA free=14758648.00 total=102903552.00 instance=OIDP1 ora_server_name=+ASM1 
+ASM1 0334 14.34 objext=DATA diskgroup=DATA free=14758648.00 total=102903552.00 instance=OIDQ1 ora_server_name=+ASM1 
+ASM1 0334 14.34 objext=DATA diskgroup=DATA free=14758648.00 total=102903552.00 instance=UPKPROD1 ora_server_name=+ASM1 
+ASM1 0334 14.34 objext=DATA diskgroup=DATA free=14758648.00 total=102903552.00 instance=OIMQ1 ora_server_name=+ASM1 
+ASM1 0334 14.34 objext=DATA diskgroup=DATA free=14758648.00 total=102903552.00 instance=POID1 ora_server_name=+ASM1 
+ASM1 0334 14.34 objext=DATA diskgroup=DATA free=14758648.00 total=102903552.00 instance=POIM1 ora_server_name=+ASM1 
+ASM1 0334 14.34 objext=DATA diskgroup=DATA free=14758648.00 total=102903552.00 instance=TRXP1 ora_server_name=+ASM1 
+ASM1 0334 14.34 objext=DATA diskgroup=DATA free=14758648.00 total=102903552.00 instance=TRXQ1 ora_server_name=+ASM1 
+ASM1 0334 14.34 objext=DATA diskgroup=DATA free=14758648.00 total=102903552.00 instance=OIMP1 ora_server_name=+ASM1 
+ASM1 0334 98.97 objext=DBFS_DG diskgroup=DBFS_DG free=1027496.00 total=1038240.00 instance=+ASM1 ora_server_name=+ASM1 
+ASM1 0334 98.97 objext=DBFS_DG diskgroup=DBFS_DG free=1027496.00 total=1038240.00 instance=husexa2dbadm01.hus.fi ora_server_name=+ASM1 
+ASM1 0334 78.94 objext=EBS_DATA diskgroup=EBS_DATA free=8730676.00 total=11059200.00 instance=NA ora_server_name=+ASM1 
+ASM1 0334 98.20 objext=EBS_RECO diskgroup=EBS_RECO free=10860684.00 total=11059200.00 instance=OIDQ1 ora_server_name=+ASM1 
+ASM1 0334 22.85 objext=RECO diskgroup=RECO free=2527028.00 total=11059200.00 instance=EBSP1 ora_server_name=+ASM1 
+ASM1 0334 22.85 objext=RECO diskgroup=RECO free=2527028.00 total=11059200.00 instance=EBSQ1 ora_server_name=+ASM1 
+ASM1 0334 22.85 objext=RECO diskgroup=RECO free=2527028.00 total=11059200.00 instance=OIDP1 ora_server_name=+ASM1 
+ASM1 0334 22.85 objext=RECO diskgroup=RECO free=2527028.00 total=11059200.00 instance=OIDQ1 ora_server_name=+ASM1 
+ASM1 0334 22.85 objext=RECO diskgroup=RECO free=2527028.00 total=11059200.00 instance=UPKPROD1 ora_server_name=+ASM1 
+ASM1 0334 22.85 objext=RECO diskgroup=RECO free=2527028.00 total=11059200.00 instance=OIMQ1 ora_server_name=+ASM1 
+ASM1 0334 22.85 objext=RECO diskgroup=RECO free=2527028.00 total=11059200.00 instance=POID1 ora_server_name=+ASM1 
+ASM1 0334 22.85 objext=RECO diskgroup=RECO free=2527028.00 total=11059200.00 instance=POIM1 ora_server_name=+ASM1 
+ASM1 0334 22.85 objext=RECO diskgroup=RECO free=2527028.00 total=11059200.00 instance=TRXP1 ora_server_name=+ASM1 
+ASM1 0334 22.85 objext=RECO diskgroup=RECO free=2527028.00 total=11059200.00 instance=TRXQ1 ora_server_name=+ASM1 
+ASM1 0334 22.85 objext=RECO diskgroup=RECO free=2527028.00 total=11059200.00 instance=+ASM1 ora_server_name=+ASM1 
+ASM1 0334 22.85 objext=RECO diskgroup=RECO free=2527028.00 total=11059200.00 instance=OIMP1 ora_server_name=+ASM1 


[root@husexa2dbadm01 ~]# su - oratrxq       #### Отивам на другата база която пълни в случая TRXQ ####


[oratrxq@husexa2dbadm01 ~]$ sqlplus / as sysdba


##### ORACLE 12C - LAST RECEIVED LAST APPLY

select al.thrd "Thread", almax "Last Seq Received", lhmax "Last Seq Applied"
from (select thread# thrd, max(sequence#) almax
      from v$archived_log
      where resetlogs_change#=(select resetlogs_change# from v$database)
      group by thread#) al,
     (select thread# thrd, max(sequence#) lhmax
      from v$log_history
      where first_time=(select max(first_time) from v$log_history)
      group by thread#) lh
where al.thrd = lh.thrd;

   THREAD#  Last Recd Last Applied
---------- ---------- ------------
	 1	26081	     26081
	 2	24857	     24856



SQL> select database_role from v$database;                    #### Да проверя дали е праймари или стенд #####

DATABASE_ROLE
----------------
PHYSICAL STANDBY


SQL> exit


[oratrxq@husexa2dbadm01 ~]$ rman target /



RMAN> delete noprompt archivelog until sequence 26075 thread 1;


RMAN> delete noprompt archivelog until sequence 24850 thread 2;



RMAN> exit



[root@husexa2dbadm01 ~]# dbspicao -m334 -pv -i +ASM1

ASM Instance: '+ASM1' @ '/u01/app/12.2.0/grid'
-------------------------------------------------------------
+ASM1 0334 14.34 objext=DATA diskgroup=DATA free=14757248.00 total=102903552.00 instance=+ASM1 ora_server_name=+ASM1 
+ASM1 0334 14.34 objext=DATA diskgroup=DATA free=14757248.00 total=102903552.00 instance=EBSP1 ora_server_name=+ASM1 
+ASM1 0334 14.34 objext=DATA diskgroup=DATA free=14757248.00 total=102903552.00 instance=EBSQ1 ora_server_name=+ASM1 
+ASM1 0334 14.34 objext=DATA diskgroup=DATA free=14757248.00 total=102903552.00 instance=OIDP1 ora_server_name=+ASM1 
+ASM1 0334 14.34 objext=DATA diskgroup=DATA free=14757248.00 total=102903552.00 instance=OIDQ1 ora_server_name=+ASM1 
+ASM1 0334 14.34 objext=DATA diskgroup=DATA free=14757248.00 total=102903552.00 instance=UPKPROD1 ora_server_name=+ASM1 
+ASM1 0334 14.34 objext=DATA diskgroup=DATA free=14757248.00 total=102903552.00 instance=OIMQ1 ora_server_name=+ASM1 
+ASM1 0334 14.34 objext=DATA diskgroup=DATA free=14757248.00 total=102903552.00 instance=POID1 ora_server_name=+ASM1 
+ASM1 0334 14.34 objext=DATA diskgroup=DATA free=14757248.00 total=102903552.00 instance=POIM1 ora_server_name=+ASM1 
+ASM1 0334 14.34 objext=DATA diskgroup=DATA free=14757248.00 total=102903552.00 instance=TRXP1 ora_server_name=+ASM1 
+ASM1 0334 14.34 objext=DATA diskgroup=DATA free=14757248.00 total=102903552.00 instance=TRXQ1 ora_server_name=+ASM1 
+ASM1 0334 14.34 objext=DATA diskgroup=DATA free=14757248.00 total=102903552.00 instance=OIMP1 ora_server_name=+ASM1 
+ASM1 0334 98.97 objext=DBFS_DG diskgroup=DBFS_DG free=1027496.00 total=1038240.00 instance=+ASM1 ora_server_name=+ASM1 
+ASM1 0334 98.97 objext=DBFS_DG diskgroup=DBFS_DG free=1027496.00 total=1038240.00 instance=husexa2dbadm01.hus.fi ora_server_name=+ASM1 
+ASM1 0334 78.94 objext=EBS_DATA diskgroup=EBS_DATA free=8730676.00 total=11059200.00 instance=NA ora_server_name=+ASM1 
+ASM1 0334 98.20 objext=EBS_RECO diskgroup=EBS_RECO free=10860684.00 total=11059200.00 instance=OIDQ1 ora_server_name=+ASM1 
+ASM1 0334 32.57 objext=RECO diskgroup=RECO free=3602068.00 total=11059200.00 instance=EBSP1 ora_server_name=+ASM1 
+ASM1 0334 32.57 objext=RECO diskgroup=RECO free=3602068.00 total=11059200.00 instance=EBSQ1 ora_server_name=+ASM1 
+ASM1 0334 32.57 objext=RECO diskgroup=RECO free=3602068.00 total=11059200.00 instance=OIDP1 ora_server_name=+ASM1 
+ASM1 0334 32.57 objext=RECO diskgroup=RECO free=3602068.00 total=11059200.00 instance=OIDQ1 ora_server_name=+ASM1 
+ASM1 0334 32.57 objext=RECO diskgroup=RECO free=3602068.00 total=11059200.00 instance=UPKPROD1 ora_server_name=+ASM1 
+ASM1 0334 32.57 objext=RECO diskgroup=RECO free=3602068.00 total=11059200.00 instance=OIMQ1 ora_server_name=+ASM1 
+ASM1 0334 32.57 objext=RECO diskgroup=RECO free=3602068.00 total=11059200.00 instance=POID1 ora_server_name=+ASM1 
+ASM1 0334 32.57 objext=RECO diskgroup=RECO free=3602068.00 total=11059200.00 instance=POIM1 ora_server_name=+ASM1 
+ASM1 0334 32.57 objext=RECO diskgroup=RECO free=3602068.00 total=11059200.00 instance=TRXP1 ora_server_name=+ASM1 
+ASM1 0334 32.57 objext=RECO diskgroup=RECO free=3602068.00 total=11059200.00 instance=TRXQ1 ora_server_name=+ASM1 
+ASM1 0334 32.57 objext=RECO diskgroup=RECO free=3602068.00 total=11059200.00 instance=+ASM1 ora_server_name=+ASM1 
+ASM1 0334 32.57 objext=RECO diskgroup=RECO free=3602068.00 total=11059200.00 instance=OIMP1 ora_server_name=+ASM1 



 
 
 ### The disk group usage is in range ### ###Deleted oldest archivelog files to ensure some free space.