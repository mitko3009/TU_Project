======================================================================================================================
ТРИЕМ CORE FILES, САМО ВНИМАВАМЕ КЪДЕ С ЕНАМИРАТ
ТРЯБВА ДА СА В : cdump и adump
=======================================================================================================================

[root@fivatx0122 ~]# df -h /oracle
Filesystem            Size  Used Avail Use% Mounted on
/dev/mapper/vg_fivatx0122-lv_oracle
                       48G   42G  3.9G  92% /oracle
[root@fivatx0122 ~]#
[root@fivatx0122 ~]#
[root@fivatx0122 ~]# cd /oracle
[root@fivatx0122 oracle]#
[root@fivatx0122 oracle]#
[root@fivatx0122 oracle]#
[root@fivatx0122 oracle]# ls -la
total 76
drwxr-xr-x  16 root        oinstall  4096 Aug 22  2017 .
dr-xr-xr-x. 32 root        root      4096 May 21 12:34 ..
drwxr-x---   7 oracle      oinstall  4096 Mar 16  2016 admin
drwxr-xr-x   6 oraagent12c oinstall  4096 Apr  7  2015 agent12c
drwxr-x---   4 oracle      oinstall  4096 Dec  1  2015 audit
drwxr-xr-x   6 oracle      oinstall  4096 Mar  3  2015 cfgtoollogs
drwxr-xr-x   2 oracle      oinstall  4096 Feb 27  2015 checkpoints
drwxrwx---   4 oracle      oinstall  4096 Feb 27  2015 crsdata
drwxr-xr-x   3 oracle      oinstall  4096 Nov 25  2015 depot
drwxr-x---  19 oracle      oinstall  4096 Feb 27  2015 diag
drwxr-xr-x   3 oracle      oinstall  4096 Feb 27  2015 fivatx0122
drwxr-xr-x   3 root        root      4096 Feb 27  2015 fivatx0122.adinfra.net
drwxr-xr-x   3 oracle      oinstall  4096 Feb 27  2015 log
drwx------   2 root        root     16384 Feb 20  2015 lost+found
drwxrwx---   6 oracle      oinstall  4096 May 21 12:36 oraInventory
drwxr-xr-x   3 oracle      oinstall  4096 Feb 27  2015 product
-rw-r--r--   1 root        root         0 Jul  4 02:14 redirection


[root@fivatx0122 oracle]# find . -xdev -mtime 0 -size +10000c -type f -exec ls -al {} \; |sort -k5nr |head -90
-rw------- 1 oracle asmadmin 71049216 Jul  4 02:16 ./diag/rdbms/pomadmd/POMADMD/cdump/core.4396
-rw-r----- 1 oracle asmadmin 55361536 Jul  3 11:30 ./product/12.1.0/dbhome_1/dbs/snapcf_POMADMD.f
-rw-r----- 1 oracle oinstall 37564191 Jul  4 08:56 ./diag/tnslsnr/fivatx0122/listener/trace/listener.log
-rw-r----- 1 oracle asmadmin 31604736 Jul  3 23:00 ./diag/rdbms/pomadmd/POMADMD/metadata/HM_FINDING.ams
-rw-r----- 1 oracle oinstall 28131496 Jul  4 08:47 ./diag/asm/+asm/+ASM/trace/alert_+ASM.log
-rw-r--r-- 1 oracle asmadmin 22170590 Jul  4 08:44 ./product/12.1.0/dbhome_1/rdbms/log/sbtio.log
-rw------- 1 oracle asmadmin 14053376 Jul  4 03:20 ./diag/rdbms/pomadmd/POMADMD/cdump/core_26852/core.26863
-rw------- 1 oracle asmadmin 13934592 Jul  4 04:01 ./diag/rdbms/pomadmd/POMADMD/cdump/core_25242/core.26321
-rw------- 1 oracle asmadmin 13905920 Jul  4 03:20 ./diag/rdbms/pomadmd/POMADMD/cdump/core_26850/core.26864
-rw------- 1 oracle asmadmin 13848576 Jul  4 03:20 ./diag/rdbms/pomadmd/POMADMD/cdump/core_26860/core.27188
-rw------- 1 oracle asmadmin 13836288 Jul  4 07:31 ./diag/rdbms/pomadmd/POMADMD/cdump/core_26907/core.28729
-rw------- 1 oracle asmadmin 13795328 Jul  4 06:01 ./diag/rdbms/pomadmd/POMADMD/cdump/core_21853/core.23197
-rw------- 1 oracle asmadmin 13787136 Jul  4 06:01 ./diag/rdbms/pomadmd/POMADMD/cdump/core_21855/core.23201


[root@fivatx0122 oracle]# cd ./diag/rdbms/pomadmd/POMADMD/cdump
[root@fivatx0122 cdump]# ls -la
total 1472844
drwxr-x--- 1351 oracle asmadmin    57344 Jul  4 09:01 .
drwxr-x---   16 oracle asmadmin     4096 Feb 27  2015 ..
drwxr-x---    2 oracle asmadmin     4096 Jul  4 05:02 core_10086
drwxr-x---    2 oracle asmadmin     4096 Jul  4 05:02 core_10088
drwxr-x---    2 oracle asmadmin     4096 Jul  4 05:02 core_10090
drwxr-x---    2 oracle asmadmin     4096 Jul  4 05:02 core_10092
drwxr-x---    2 oracle asmadmin     4096 Jul  4 05:02 core_10094
drwxr-x---    2 oracle asmadmin     4096 Jul  4 03:03 core_10662
drwxr-x---    2 oracle asmadmin     4096 Jul  4 03:03 core_10664
drwxr-x---    2 oracle asmadmin     4096 Jul  4 03:03 core_10666
drwxr-x---    2 oracle asmadmin     4096 Jul  4 03:03 core_10668
drwxr-x---    2 oracle asmadmin     4096 Jul  4 03:03 core_10670

[root@fivatx0122 cdump]# rm -rf core*
[root@fivatx0122 cdump]# ls -la
total 64
drwxr-x---  2 oracle asmadmin 57344 Jul  4 09:02 .
drwxr-x--- 16 oracle asmadmin  4096 Feb 27  2015 ..
[root@fivatx0122 cdump]# cd /oracle
[root@fivatx0122 oracle]# ls -la
total 

drwxr-xr-x  16 root        oinstall  4096 Aug 22  2017 .
dr-xr-xr-x. 32 root        root      4096 May 21 12:34 ..
drwxr-x---   7 oracle      oinstall  4096 Mar 16  2016 admin
drwxr-xr-x   6 oraagent12c oinstall  4096 Apr  7  2015 agent12c
drwxr-x---   4 oracle      oinstall  4096 Dec  1  2015 audit
drwxr-xr-x   6 oracle      oinstall  4096 Mar  3  2015 cfgtoollogs
drwxr-xr-x   2 oracle      oinstall  4096 Feb 27  2015 checkpoints
drwxrwx---   4 oracle      oinstall  4096 Feb 27  2015 crsdata
drwxr-xr-x   3 oracle      oinstall  4096 Nov 25  2015 depot
drwxr-x---  19 oracle      oinstall  4096 Feb 27  2015 diag
drwxr-xr-x   3 oracle      oinstall  4096 Feb 27  2015 fivatx0122
drwxr-xr-x   3 root        root      4096 Feb 27  2015 fivatx0122.adinfra.net
drwxr-xr-x   3 oracle      oinstall  4096 Feb 27  2015 log
drwx------   2 root        root     16384 Feb 20  2015 lost+found
drwxrwx---   6 oracle      oinstall  4096 May 21 12:36 oraInventory
drwxr-xr-x   3 oracle      oinstall  4096 Feb 27  2015 product
-rw-r--r--   1 root        root         0 Jul  4 02:14 redirection
