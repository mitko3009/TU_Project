

CREATE TABLE  BRREGLEEDITEUR_NEW 	 AS (SELECT * FROM BRREGLEEDITEUR); 	
CREATE TABLE  BRREGLEPROC_NEW		 AS (SELECT * FROM BRREGLEPROC);		
CREATE TABLE  BRTITREPROC_NEW		 AS (SELECT * FROM BRTITREPROC);		
CREATE TABLE  V_DOMAINE_NEW 		 AS (SELECT * FROM V_DOMAINE);




ALTER TABLE  BRREGLEEDITEUR RENAME TO    BRREGLEEDITEUR_OLD  ;
ALTER TABLE  BRREGLEPROC	RENAME TO    BRREGLEPROC_OLD	 ;
ALTER TABLE  BRTITREPROC	RENAME TO    BRTITREPROC_OLD	 ;
ALTER TABLE  V_DOMAINE 		RENAME TO    V_DOMAINE_OLD 		 ;



ALTER TABLE BRREGLEEDITEUR_NEW  RENAME TO BRREGLEEDITEUR 	;
ALTER TABLE BRREGLEPROC_NEW		RENAME TO BRREGLEPROC		;
ALTER TABLE BRTITREPROC_NEW		RENAME TO BRTITREPROC		;
ALTER TABLE V_DOMAINE_NEW 		RENAME TO V_DOMAINE 		;



select count (*) from BRREGLEEDITEUR_NEW ;
select count (*) from BRREGLEPROC_NEW	 ;
select count (*) from BRTITREPROC_NEW	 ;
select count (*) from V_DOMAINE_NEW 	 ;

select count (*) from BRREGLEEDITEUR  ;
select count (*) from BRREGLEPROC 	 ;
select count (*) from BRTITREPROC 	 ;
select count (*) from V_DOMAINE 	 ;


drop table  BRREGLEEDITEUR_OLD  ;
drop table  BRREGLEPROC_OLD	 ;
drop table  BRTITREPROC_OLD	 ;
drop table  V_DOMAINE_OLD 		 ;




	  
------------------------------------
--  Changed table brregleediteur  --
------------------------------------
 
-- Create/Recreate indexes 
create index BR_UPPERTEXTE_IDX on BRREGLEEDITEUR (UPPER(TEXTE)) tablespace CRXINDEX;
create unique index EDITEUR on BRREGLEEDITEUR (TEXTE) tablespace CRXINDEX;
  
alter table BRREGLEEDITEUR
  add constraint PK_BRREGLEEDITEUR primary key (NUMERO)
  deferrable;
alter table BRREGLEEDITEUR
  add constraint AK_KEY_2_BRREGLEE unique (LETT_NAME_CODE);
 
alter table BRREGLEEDITEUR
  add constraint HTML_MAIL_CONSTRAINT
  check (nvl(HTML_MAIL, 'N') = 'N' or MAIL= 'O');
  
  
  
---------------------------------
--  Changed table brregleproc  --
---------------------------------
 
create index PRORES on BRREGLEPROC (RESULTAT)  tablespace CRXINDEX; 
create index PRORESNUM on BRREGLEPROC (NUMERO)  tablespace CRXINDEX; 
---------------------------------
--  Changed table brtitreproc  --
---------------------------------
 
 
create index GROUPE_TYPE on BRTITREPROC (NGROUP, TYPE, GROUPE, NUMERO )tablespace CRXINDEX; 
create index PROTITRE on BRTITREPROC (NUMERO) tablespace CRXINDEX; 
-------------------------------
--  Changed table v_domaine  --
-------------------------------
 
create index DOM_CHAMP on V_DOMAINE (CHAMP)  tablespace CRXINDEX; 
create index DOM_PATCH_IDX on V_DOMAINE (PRET_POUR_PATCH)  tablespace CRXINDEX; 
create index DOM_TYPABREV on V_DOMAINE (TYPE, ABREV, VALEUR)  tablespace CRXINDEX; 
create index DOM_TYPVAL on V_DOMAINE (VALEUR, TYPE)  tablespace CRXINDEX; 
create index DOM_UPPERVAL_IDX on V_DOMAINE (UPPER(VALEUR))  tablespace CRXINDEX; 
create index V_DOMAINE_DWT on V_DOMAINE (DW_TIMESTAMP)  tablespace CRXINDEX; 
create index V_DOMAINE_TYPE_CODE_IDX on V_DOMAINE (TYPE, CODE)  tablespace CRXINDEX; 
-- Create/Recreate primary, unique and foreign key constraints 
set serveroutput on
exec IMX_UID.CREATE_INIT('V_DOMAINE');

-- Create/Recreate check constraints 
alter table V_DOMAINE
  add constraint CKT_V_DOMAINE
  check (ACTIVITY in ('ASSURANCE','BANKING','!FACTORING','FACTORING','LEASING','RECOUVREMENT','STD','TELECOM','ECOMMERCE','CREDIT_INSURANCE',NULL));

