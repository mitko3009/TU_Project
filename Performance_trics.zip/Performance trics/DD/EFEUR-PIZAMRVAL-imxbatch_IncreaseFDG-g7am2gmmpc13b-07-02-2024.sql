/********************************************************************************
*********       E-mail subject: EFEURDEV-4825
*********             Instance: PIZAMRVAL
*********          Description: 
Problem:
SQL g7am2gmmpc13b from imxbatch_IncreaseFDG has bad performance.

Analysis:
From the AWR for period from 22:04:49 to 22:06:49 on 2024/02/06 on PIZAMRVAL we can see that SQLs 83mygy5qhfvm7 and 831j4r9w7pfzd are executed over 
200k times each. They are called by SQL g7am2gmmpc13b in function ftr_decompte.isContractValid(D.refdoss) in imxbatch_IncreaseFDG.
In SQL g7am2gmmpc13b we saw that function ftr_decompte.isContractValid(D.refdoss) in called in the WHERE clause, which is not recomended from P&T, 
because by this way this function is called many times unnecessary which leads to executing the queries in the function a lot of times.
The solution here is to move the function into the SELECT part.

Suggestion:
Please modify the SQL text as it is shown in the New SQL section below.

*********               SQL_ID: g7am2gmmpc13b
*********      Program/Package: imxbatch_IncreaseFDG
*********              Request: Dimitare Ivanov
*********               Author: Dimitar Dimitrov
********* Received e-mail date: 07/02/2024
*********      Resolution date: 07/02/2024
*********  Trace old file here: \\epox\specifs\performance\tmp\
*********  Trace new file here:
***********************************************************************************/

/********************************OLD SQL*******************************************/

 SELECT  D.REFFACTOR /* automatically injected */, 
         D.refdoss
    FROM g_dossier D,  
         g_piece FC
   WHERE D.categdoss LIKE 'DECOMPTE%'
     AND ftr_decompte.isContractValid(D.refdoss) NOT IN (0,  2)
     AND FC.refdoss  = D.reflot
     AND FC.typpiece = 'FACTORINGCRITERIA'
     AND FC.fg32 = 'O'
    /* reffactor condition */
     AND D.REFFACTOR IN ('INT00000')
   ORDER BY d.refdoss;
/********************************OLD SQL*******************************************/
/********************************OLD Metrics***************************************/


/*
MODULE                           SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
imxbatch_IncreaseFDG                                                            read by other sessio 2024/02/06 22:04:59  2024/02/06 22:06:49          60               206429 +000000000 00:01:50.147 75%
imxbatch_IncreaseFDG                                                            ON CPU               2024/02/06 22:04:59  2024/02/06 22:06:09          11               368944 +000000000 00:01:10.100 14%
imxbatch_IncreaseFDG                                                            db file sequential r 2024/02/06 22:04:49  2024/02/06 22:06:39           9               210860 +000000000 00:01:50.184 11%


MODULE                           SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
imxbatch_IncreaseFDG             83mygy5qhfvm7  799553563                                            2024/02/06 22:04:49  2024/02/06 22:06:39          50               210863 +000000000 00:01:50.184 63%
imxbatch_IncreaseFDG             831j4r9w7pfzd 4254994383                                            2024/02/06 22:04:59  2024/02/06 22:06:49          26               206459 +000000000 00:01:50.147 33%
imxbatch_IncreaseFDG                                    0       1722      63211 ON CPU               2024/02/06 22:06:09  2024/02/06 22:06:09           1                      +000000000 00:00:00.000 1%
imxbatch_IncreaseFDG             0y0ztvzf62gbq  136089522       1447      26303 ON CPU               2024/02/06 22:05:39  2024/02/06 22:05:39           1                    1 +000000000 00:00:00.000 1%
imxbatch_IncreaseFDG             3326b4fcjrw4r  136089522       1439      53156 ON CPU               2024/02/06 22:05:59  2024/02/06 22:05:59           1                    1 +000000000 00:00:00.000 1%
imxbatch_IncreaseFDG             9wkwa3zzpp1wj  136089522       2005      14375 ON CPU               2024/02/06 22:06:09  2024/02/06 22:06:09           1                    1 +000000000 00:00:00.000 1%


Plan hash value: 136089522
----------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                     | Name                   | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  |
----------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT              |                        |      1 |        |     2 (100)|      2 |00:00:19.66 |     245K|  26630 |
|   1 |  NESTED LOOPS                 |                        |      1 |      1 |     2   (0)|      2 |00:00:19.66 |     245K|  26630 |
|   2 |   NESTED LOOPS                |                        |      1 |      1 |     2   (0)|   4445 |00:00:19.26 |     234K|  25979 |
|*  3 |    TABLE ACCESS BY INDEX ROWID| G_DOSSIER              |      1 |      1 |     1   (0)|   4445 |00:00:19.21 |     225K|  25965 |
|*  4 |     INDEX FULL SCAN           | DOS_REFDOSS_REFLOT_IDX |      1 |     27 |     1   (0)|   4908 |00:00:19.14 |     214K|  25965 |
|*  5 |    INDEX RANGE SCAN           | PIE_REFDOSS            |   4445 |      1 |     1   (0)|   4445 |00:00:00.04 |    8926 |     14 |
|*  6 |   TABLE ACCESS BY INDEX ROWID | G_PIECE                |   4445 |      1 |     1   (0)|      2 |00:00:00.40 |   10969 |    651 |
----------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   3 - filter(("D"."REFFACTOR"='INT00000' AND "D"."CATEGDOSS" LIKE 'DECOMPTE%'))
   4 - filter(("D"."REFLOT" IS NOT NULL AND "FTR_DECOMPTE"."ISCONTRACTVALID"("D"."REFDOSS")<>0 AND
              "FTR_DECOMPTE"."ISCONTRACTVALID"("D"."REFDOSS")<>2))
   5 - access("FC"."REFDOSS"="D"."REFLOT" AND "FC"."TYPPIECE"='FACTORINGCRITERIA')
   6 - filter("FC"."FG32"='O')   
*/
/********************************OLD Metrics***************************************/

/********************************New SQL*******************************************/

SELECT *
  FROM (    
       SELECT  D.REFFACTOR /* automatically injected */,
               D.refdoss,
               ( SELECT ftr_decompte.isContractValid(D.refdoss) from dual ) isContractValid
         FROM g_dossier D,  
              g_piece FC
        WHERE D.categdoss LIKE 'DECOMPTE%'
          AND FC.refdoss  = D.reflot
          AND FC.typpiece = 'FACTORINGCRITERIA'
          AND FC.fg32 = 'O'
         /* reffactor condition */
          AND D.REFFACTOR IN ('INT00000')
        ORDER BY d.refdoss)
  WHERE isContractValid NOT IN (0,  2);
/********************************New SQL*******************************************/
/********************************New Metrics***************************************/
/*
Plan hash value: 1892847250
--------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                      | Name                      | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  |
--------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT               |                           |      1 |        |     5 (100)|      2 |00:00:00.09 |   20867 |     36 |
|   1 |  FAST DUAL                     |                           |      2 |      1 |     2   (0)|      2 |00:00:00.01 |       0 |      0 |
|*  2 |  VIEW                          |                           |      1 |      1 |     5  (20)|      2 |00:00:00.09 |   20867 |     36 |
|   3 |   SORT ORDER BY                |                           |      1 |      1 |     5  (20)|      2 |00:00:00.09 |   20867 |     36 |
|   4 |    NESTED LOOPS                |                           |      1 |      1 |     2   (0)|      2 |00:00:00.08 |   20833 |     36 |
|   5 |     NESTED LOOPS               |                           |      1 |     42 |     2   (0)|   4672 |00:00:00.03 |    9447 |      1 |
|*  6 |      INDEX SKIP SCAN           | G_DOSSIER_RL_CD_RD_RF_IDX |      1 |     42 |     1   (0)|   4673 |00:00:00.01 |      79 |      1 |
|*  7 |      INDEX RANGE SCAN          | PIE_REFDOSS               |   4673 |      1 |     1   (0)|   4672 |00:00:00.02 |    9368 |      0 |
|*  8 |     TABLE ACCESS BY INDEX ROWID| G_PIECE                   |   4672 |      1 |     1   (0)|      2 |00:00:00.06 |   11386 |     35 |
--------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   2 - filter(("ISCONTRACTVALID"<>0 AND "ISCONTRACTVALID"<>2))
   6 - access("D"."CATEGDOSS" LIKE 'DECOMPTE%' AND "D"."REFFACTOR"='INT00000')
       filter(("D"."REFFACTOR"='INT00000' AND "D"."REFLOT" IS NOT NULL AND "D"."CATEGDOSS" LIKE 'DECOMPTE%'))
   7 - access("FC"."REFDOSS"="D"."REFLOT" AND "FC"."TYPPIECE"='FACTORINGCRITERIA')
   8 - filter("FC"."FG32"='O') 
*/
/********************************New Metrics***************************************/

/********************************Index statistics**********************************/

/********************************Other SQLs****************************************/          
/*

*/ 
/********************************Other SQLs****************************************/              
