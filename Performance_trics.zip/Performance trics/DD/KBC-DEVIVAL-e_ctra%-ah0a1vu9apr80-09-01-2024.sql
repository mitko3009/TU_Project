/********************************************************************************
*********       E-mail subject: KBCCFDEV-5594
*********             Instance: DEVIVAL
*********          Description: 
Problem:
Slowness in e_ctra_% screens from DEVIVAL.

Analysis:
The TOP SQL ah0a1vu9apr80 was responsible for 100% of the load.
The problem in it was unnecessary selecting a lot of rows from table g_db_ptf_item by making INDEX FULL SCAN 
and table g_elemfi and than merge join the two big data sets.

Suggestion:
Please modify the query as it is shown in the New SQL section below.

*********               SQL_ID: ah0a1vu9apr80
*********      Program/Package: e_ctra_% screens
*********              Request: Nina Kudineva
*********               Author: Dimitar Dimitrov
********* Received e-mail date: 09/01/2024
*********      Resolution date: 09/01/2024
*********  Trace old file here: \\epox\specifs\performance\tmp\
*********  Trace new file here:
***********************************************************************************/

/********************************OLD SQL*******************************************/
var B1 VARCHAR2(128);
exec :B1 := '0511040023';  

UPDATE g_db_ptf_item
   SET suspended_amount_fin = 0, 
       suspended_amount_cov = 0
 WHERE refelem IN
       (SELECT E.refelem
          FROM g_elemfi E,
               (SELECT refdoss
                  FROM g_dossier
                 START WITH refdoss = :B1
                CONNECT BY PRIOR refdoss = nvl(reflot, refhierarchie)) C
         WHERE E.refdoss = C.refdoss)
   AND (nvl(suspended_amount_fin, 0) > 0 OR
       nvl(suspended_amount_cov, 0) > 0);
/********************************OLD SQL*******************************************/
/********************************OLD Metrics***************************************/
/*
MODULE                           SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
1031EB915BD5B9CBA2665E2A2BD04446 ah0a1vu9apr80 3486830425        593      60170 db file sequential r 2024/01/09 10:10:26  2024/01/09 10:16:39         372                    1 +000000000 00:06:12.309 69%
                                                        0                       control file sequent 2024/01/09 10:10:06  2024/01/09 10:16:50          45                      +000000000 00:06:43.336 8%
                                                        0       1139      18541 log file parallel wr 2024/01/09 10:10:08  2024/01/09 10:16:49          18                      +000000000 00:06:40.333 3%
                                                        0                       control file paralle 2024/01/09 10:10:26  2024/01/09 10:15:57          16                      +000000000 00:05:30.276 3%
                                                        0        856      34962 db file parallel wri 2024/01/09 10:11:21  2024/01/09 10:15:50          13                      +000000000 00:04:29.225 2%
stat_crx_rangmt                                                   11      37318 db file sequential r 2024/01/09 10:10:21  2024/01/09 10:10:33          13                    1 +000000000 00:00:12.011 2%
stat_crx                         168a04rp21861 2310774181         11      15723 direct path read     2024/01/09 10:10:03  2024/01/09 10:10:16          13                    1 +000000000 00:00:13.013 2%
KTSJ                                                    0                       db file sequential r 2024/01/09 10:14:02  2024/01/09 10:14:05           7                      +000000000 00:00:03.002 1%


MODULE                           SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
1031EB915BD5B9CBA2665E2A2BD04446 ah0a1vu9apr80 3486830425        593      60170 db file sequential r 2024/01/09 10:10:26  2024/01/09 10:16:39         372                    1 +000000000 00:06:12.309 99%
1031EB915BD5B9CBA2665E2A2BD04446                                 593      60170 ON CPU               2024/01/09 10:10:25  2024/01/09 10:13:15           2                    1 +000000000 00:02:49.137 1%


MODULE                           SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
1031EB915BD5B9CBA2665E2A2BD04446 ah0a1vu9apr80 3486830425        593      60170                      2024/01/09 10:10:26  2024/01/09 10:16:39         373                    1 +000000000 00:06:12.309 100%
1031EB915BD5B9CBA2665E2A2BD04446 102rk8ka0bwpg 2263048654        593      60170 ON CPU               2024/01/09 10:10:25  2024/01/09 10:10:25           1                      +000000000 00:00:00.000 0%


SQL_ID        SQL_PLAN_HASH_VALUE SQL_PLAN_LINE_ID SQL_PLAN_OPERATION             SQL_PLAN_OPTIONS                   ACTIVE
------------- ------------------- ---------------- ------------------------------ ------------------------------ ----------
ah0a1vu9apr80          3486830425                3 TABLE ACCESS                   BY INDEX ROWID                         27
ah0a1vu9apr80          3486830425                4 INDEX                          FULL SCAN                              11


Plan hash value: 3486830425
--------------------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                     | Name                   | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  |
--------------------------------------------------------------------------------------------------------------------------------------------------------
|   0 | UPDATE STATEMENT                              |                        |      1 |        |   447 (100)|      0 |00:00:18.80 |   36150 |  10324 |
|   1 |  UPDATE                                       | G_DB_PTF_ITEM          |      1 |        |            |      0 |00:00:18.80 |   36150 |  10324 |
|   2 |   MERGE JOIN SEMI                             |                        |      1 |      1 |   447   (2)|      0 |00:00:18.80 |   36150 |  10324 |
|*  3 |    TABLE ACCESS BY INDEX ROWID                | G_DB_PTF_ITEM          |      1 |      1 |   188   (1)|      0 |00:00:18.80 |   36150 |  10324 |
|   4 |     INDEX FULL SCAN                           | PK_G_DB_PTF_ITEM       |      1 |    573K|    26   (0)|    573K|00:00:05.51 |    2678 |   2678 |
|*  5 |    SORT UNIQUE                                |                        |      0 |  16930 |   259   (3)|      0 |00:00:00.01 |       0 |      0 |
|   6 |     VIEW                                      | VW_NSO_1               |      0 |  16930 |   257   (2)|      0 |00:00:00.01 |       0 |      0 |
|   7 |      NESTED LOOPS                             |                        |      0 |  16930 |   257   (2)|      0 |00:00:00.01 |       0 |      0 |
|   8 |       VIEW                                    |                        |      0 |     89 |   255   (3)|      0 |00:00:00.01 |       0 |      0 |
|*  9 |        CONNECT BY NO FILTERING WITH START-WITH|                        |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  10 |         TABLE ACCESS FULL                     | G_DOSSIER              |      0 |   8846 |   254   (2)|      0 |00:00:00.01 |       0 |      0 |
|* 11 |       INDEX RANGE SCAN                        | G_ELEMFI$REFDOSS_ACTIF |      0 |    190 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
--------------------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   3 - filter((NVL("SUSPENDED_AMOUNT_FIN",0)>0 OR NVL("SUSPENDED_AMOUNT_COV",0)>0))
   5 - access("REFELEM"="REFELEM")
       filter("REFELEM"="REFELEM")
   9 - access(NVL("REFLOT","REFHIERARCHIE")=PRIOR NULL)
       filter("REFDOSS"=:B1)
  11 - access("E"."REFDOSS"="C"."REFDOSS")
       filter("E"."REFDOSS" IS NOT NULL)
*/
/********************************OLD Metrics***************************************/

/********************************New SQL*******************************************/

UPDATE  g_db_ptf_item
   SET suspended_amount_fin = 0, 
       suspended_amount_cov = 0
 WHERE refelem IN ( SELECT E.refelem
                      FROM g_elemfi E,
                           ( SELECT /*+ CONNECT_BY_FILTERING */
                                    refdoss
                               FROM g_dossier
                              START WITH refdoss = :B1
                            CONNECT BY PRIOR refdoss = reflot
                              UNION
                             SELECT /*+ CONNECT_BY_FILTERING */
                                    refdoss
                               FROM g_dossier
                              START WITH refdoss = :B1
                            CONNECT BY PRIOR refdoss = refhierarchie
                                         AND reflot IS NULL ) C
                     WHERE E.refdoss = C.refdoss )
   AND (    nvl(suspended_amount_fin, 0) > 0 
         OR nvl(suspended_amount_cov, 0) > 0 );
/********************************New SQL*******************************************/
/********************************New Metrics***************************************/
/*
Plan hash value: 1190899147
------------------------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                      | Name                      | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  |
------------------------------------------------------------------------------------------------------------------------------------------------------------
|   0 | UPDATE STATEMENT                               |                           |      1 |        |    45 (100)|      0 |00:00:00.07 |      72 |     22 |
|   1 |  UPDATE                                        | G_DB_PTF_ITEM             |      1 |        |            |      0 |00:00:00.07 |      72 |     22 |
|   2 |   NESTED LOOPS                                 |                           |      1 |      1 |    45   (9)|      0 |00:00:00.07 |      72 |     22 |
|   3 |    NESTED LOOPS                                |                           |      1 |   1712 |    45   (9)|      3 |00:00:00.07 |      69 |     22 |
|   4 |     VIEW                                       | VW_NSO_1                  |      1 |   1712 |    10  (30)|      3 |00:00:00.07 |      61 |     22 |
|   5 |      SORT UNIQUE                               |                           |      1 |   1712 |            |      3 |00:00:00.07 |      61 |     22 |
|   6 |       NESTED LOOPS                             |                           |      1 |   1712 |    10  (30)|      3 |00:00:00.07 |      61 |     22 |
|   7 |        VIEW                                    |                           |      1 |      9 |     9  (34)|   3003 |00:00:00.06 |      42 |     22 |
|   8 |         SORT UNIQUE                            |                           |      1 |      9 |     9  (34)|   3003 |00:00:00.06 |      42 |     22 |
|   9 |          UNION-ALL                             |                           |      1 |        |            |   3004 |00:00:00.06 |      42 |     22 |
|* 10 |           CONNECT BY WITH FILTERING (UNIQUE)   |                           |      1 |        |            |   3003 |00:00:00.06 |      35 |     22 |
|* 11 |            INDEX RANGE SCAN                    | DOS_REFDOSS_REFLOT_IDX    |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       2 |      0 |
|  12 |            NESTED LOOPS                        |                           |      3 |      6 |     2   (0)|   3002 |00:00:00.06 |      33 |     22 |
|  13 |             CONNECT BY PUMP                    |                           |      3 |        |            |   3003 |00:00:00.01 |       0 |      0 |
|* 14 |             INDEX RANGE SCAN                   | G_DOSSIER_RL_CD_RD_RF_IDX |   3003 |      6 |     1   (0)|   3002 |00:00:00.05 |      33 |     22 |
|* 15 |           CONNECT BY WITH FILTERING (UNIQUE)   |                           |      1 |        |            |      1 |00:00:00.01 |       7 |      0 |
|  16 |            TABLE ACCESS BY INDEX ROWID         | G_DOSSIER                 |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       5 |      0 |
|* 17 |             INDEX UNIQUE SCAN                  | DOS_REFDOSS               |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       2 |      0 |
|  18 |            NESTED LOOPS                        |                           |      1 |      1 |     2   (0)|      0 |00:00:00.01 |       2 |      0 |
|  19 |             CONNECT BY PUMP                    |                           |      1 |        |            |      1 |00:00:00.01 |       0 |      0 |
|* 20 |             TABLE ACCESS BY INDEX ROWID BATCHED| G_DOSSIER                 |      1 |      1 |     1   (0)|      0 |00:00:00.01 |       2 |      0 |
|* 21 |              INDEX RANGE SCAN                  | REFHIERARCHIE_IDX         |      1 |      2 |     1   (0)|      0 |00:00:00.01 |       2 |      0 |
|* 22 |        INDEX RANGE SCAN                        | G_ELEMFI$REFDOSS_ACTIF    |   3003 |    190 |     1   (0)|      3 |00:00:00.01 |      19 |      0 |
|* 23 |     INDEX UNIQUE SCAN                          | PK_G_DB_PTF_ITEM          |      3 |      1 |     1   (0)|      3 |00:00:00.01 |       8 |      0 |
|* 24 |    TABLE ACCESS BY INDEX ROWID                 | G_DB_PTF_ITEM             |      3 |      1 |     1   (0)|      0 |00:00:00.01 |       3 |      0 |
------------------------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
  10 - access("REFLOT"=PRIOR NULL)
  11 - access("REFDOSS"=:B1)
  14 - access("connect$_by$_pump$_005"."PRIOR refdoss "="REFLOT")
       filter("REFLOT" IS NOT NULL)
  15 - access("REFHIERARCHIE"=PRIOR NULL)
  17 - access("REFDOSS"=:B1)
  20 - filter("REFLOT" IS NULL)
  21 - access("connect$_by$_pump$_011"."PRIOR refdoss "="REFHIERARCHIE")
       filter("REFHIERARCHIE" IS NOT NULL)
  22 - access("E"."REFDOSS"="C"."REFDOSS")
       filter("E"."REFDOSS" IS NOT NULL)
  23 - access("REFELEM"="REFELEM")
  24 - filter((NVL("SUSPENDED_AMOUNT_FIN",0)>0 OR NVL("SUSPENDED_AMOUNT_COV",0)>0))
*/
/********************************New Metrics***************************************/

/********************************Index statistics**********************************/

/********************************Other SQLs****************************************/          
/*

*/ 
/********************************Other SQLs****************************************/              
