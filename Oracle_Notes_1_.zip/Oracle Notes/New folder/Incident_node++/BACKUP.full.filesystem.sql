###### UXMON: Filesystem /viplog_ti/oraarch diskspace utilization exceeds 70 threshold. ######
###### BACKUP ######


1. nsu

2. ps -ef | grep pmon

[root@lv209272 ~]# ps -ef | grep pmon
oracle    7902     1  0  2018 ?        00:34:22 ora_pmon_MAGDA_T
oracle    8138     1  0  2018 ?        00:30:12 ora_pmon_VIPADMT
oracle    8278     1  0  2018 ?        00:30:46 ora_pmon_VIPLOGT
root     57327 57304  0 18:39 pts/0    00:00:00 grep pmon

3. [root@lv209272 ~]# df -h /viplog_ti/oraarch

Filesystem            Size  Used Avail Use% Mounted on
/dev/mapper/VolGroup10-viplog--oraarch
                      9.8G  7.1G  2.2G  77% /viplog_ti/oraarch
					  
					  
4. [root@lv209272 ~]# cd /viplog_ti/oraarch
[root@lv209272 oraarch]# pwd
/viplog_ti/oraarch


5. [root@lv209272 oraarch]# ls -la
total 7405828
drwxr-xr-x 3 oracle oinstall    16384 Jun  3 18:40 .
drwxr-xr-x 6 oracle oinstall     4096 Oct 27  2017 ..
-rw-r--r-- 1 root   root            0 Aug  3  2018 1
drwx------ 2 oracle oinstall    16384 Oct 27  2017 lost+found
-rw-r----- 1 oracle oinstall 48130560 Jun  3 17:35 VIPLOGT_1_12546_960031706.arc
-rw-r----- 1 oracle oinstall 45732864 Jun  3 17:35 VIPLOGT_1_12547_960031706.arc
-rw-r----- 1 oracle oinstall 47714816 Jun  3 17:35 VIPLOGT_1_12548_960031706.arc
-rw-r----- 1 oracle oinstall 48785920 Jun  3 17:35 VIPLOGT_1_12549_960031706.arc
-rw-r----- 1 oracle oinstall 41979904 Jun  3 17:36 VIPLOGT_1_12550_960031706.arc
-rw-r----- 1 oracle oinstall 43616768 Jun  3 17:36 VIPLOGT_1_12551_960031706.arc
-rw-r----- 1 oracle oinstall 41298944 Jun  3 17:36 VIPLOGT_1_12552_960031706.arc
-rw-r----- 1 oracle oinstall 47714304 Jun  3 17:36 VIPLOGT_1_12553_960031706.arc
-rw-r----- 1 oracle oinstall 47713280 Jun  3 17:37 VIPLOGT_1_12554_960031706.arc

6. [root@lv209272 oraarch]# su - oracle

7. [oracle(MAGDA_T)@lv209272:/orahome/oracle]: . oraenv
   ORACLE_SID = [MAGDA_T] ? VIPLOGT
   The Oracle base remains unchanged with value /oracle


8. [oracle(VIPLOGT)@lv209272:/orahome/oracle]: sqlplus / as sysdba

 9.                                   ####### query za proverka dali ima felnat backup ######

set lines 400 pages 100                                      
col device for a8
col time_taken for a8
col START__TIME for a19
col END_TIME for a19
column TIME_TAKEN_DISPLAY format a40;
col status for a28
select command_id,TO_CHAR(start_time, 'MM/DD/YY HH24:MI:SS') as start__time,
TO_CHAR(end_time, 'MM/DD/YY HH24:MI:SS') as end_time, output_device_type as device,input_type,time_taken_display as time_taken, status
from V_$RMAN_BACKUP_JOB_DETAILS order by start_time;


COMMAND_ID                        START__TIME         END_TIME            DEVICE   INPUT_TYPE                                           TIME_TAK STATUS
--------------------------------- ------------------- ------------------- -------- ---------------------------------------------------- -------- ----------------------------
                        00:00:03 COMPLETED
2019-05-31T19:30:02               05/31/19 19:30:03   05/31/19 19:30:07   DISK     ARCHIVELOG                                           00:00:04 COMPLETED
2019-05-31T20:00:05               05/31/19 20:00:06   05/31/19 20:10:55   DISK     DB INCR                                              00:10:49 COMPLETED
2019-05-31T20:11:01               05/31/19 20:11:02   05/31/19 20:11:05   DISK     ARCHIVELOG                                           00:00:03 COMPLETED
2019-05-31T20:11:06               05/31/19 20:11:06   05/31/19 20:11:09   DISK     CONTROLFILE                                          00:00:03 COMPLETED
2019-06-02T01:30:04               06/02/19 01:30:05   06/02/19 01:30:23   DISK     ARCHIVELOG                                           00:00:18 COMPLETED
2019-06-02T05:30:03               06/02/19 05:30:04   06/02/19 05:30:07   DISK     ARCHIVELOG                                           00:00:03 COMPLETED

COMMAND_ID                        START__TIME         END_TIME            DEVICE   INPUT_TYPE                                           TIME_TAK STATUS
--------------------------------- ------------------- ------------------- -------- ---------------------------------------------------- -------- ----------------------------
2019-06-02T09:30:03               06/02/19 09:30:04   06/02/19 09:30:09   DISK     ARCHIVELOG                                           00:00:05 COMPLETED
2019-06-02T13:30:03               06/02/19 13:30:04   06/02/19 13:30:07   DISK     ARCHIVELOG                                           00:00:03 COMPLETED
2019-06-02T17:30:02               06/02/19 17:30:04   06/02/19 17:30:07   DISK     ARCHIVELOG                                           00:00:03 COMPLETED
2019-06-02T19:30:03               06/02/19 19:30:04   06/02/19 19:30:07   DISK     ARCHIVELOG                                           00:00:03 COMPLETED
2019-06-02T20:00:06               06/02/19 20:00:06   06/02/19 20:03:45   DISK     DB INCR                                              00:03:39 COMPLETED
2019-06-02T20:03:47               06/02/19 20:03:48   06/02/19 20:03:51   DISK     ARCHIVELOG                                           00:00:03 COMPLETED
2019-06-02T20:03:52               06/02/19 20:03:53   06/02/19 20:03:55   DISK     CONTROLFILE                                          00:00:02 COMPLETED
2019-06-03T01:30:03               06/03/19 01:30:04   06/03/19 01:30:09   DISK     ARCHIVELOG                                           00:00:05 COMPLETED
2019-06-03T05:30:02               06/03/19 05:30:03   06/03/19 05:30:07   DISK     ARCHIVELOG                                           00:00:04 COMPLETED
2019-06-03T09:30:02               06/03/19 09:30:04   06/03/19 09:30:07   DISK     ARCHIVELOG                                           00:00:03 COMPLETED
2019-06-03T13:30:02               06/03/19 13:30:03   06/03/19 13:30:20   DISK     ARCHIVELOG                                           00:00:17 COMPLETED
2019-06-03T17:30:04               06/03/19 17:30:05   06/03/19 17:30:53   DISK     ARCHIVELOG                                           00:00:48 COMPLETED

109 rows selected.

10 . SQL> exit


11. [oracle(VIPLOGT)@lv209272:/orahome/oracle]: df -h | grep orabck                ##### PROVERQVAM KOLKO MQSTO IMA V DIREKTORIQTA,KYDETO SE PRAVQT BACKUP-ITE #######
/dev/mapper/VolGroup15-orabck
                      660G  518G  109G  83% /orabck
					  
					  
12. [oracle(VIPLOGT)@lv209272:/orahome/oracle]: crontab -l                          ####### ZADYLJITELNO PROVERQWAM CRONTAB-A I OT TAM VIJDAM SCRIPTA ZA BACKYPVANE ILI V ESL-A ######
#----------------------------------------------------------------------------------------------------#
#             Cleanup actions
#----------------------------------------------------------------------------------------------------#
55 23 * * *  $HOME/bin/prune.pl       1>/dev/null 2>&1 # zie prune.cfg
59 23 * * *  $HOME/bin/lsnr_rotate.pl                  # rotatie lsnr log

#----------------------------------------------------------------------------------------------------#
# aanmaken rapporten LeightWeightMonitor
35 04 * * 0-6  /orahome/dbmon/LoadMonitorControl/Scripts/LMC_Collect_Data.ksh     1>/dev/null 2>&1
20 03 * * 0-6  /orahome/dbmon/loadmonitorcontrol/scripts/LMC_Collect_Data_2.ksh     1>/dev/null 2>&1
# -----------------------------------------------------------------------------------------------------#
# voor backup schudele - check backups - cron kopie maken
# -----------------------------------------------------------------------------------------------------#
20 04 * * 0-5   /orahome/dbmon/BackupControl/Scripts/GetSchedule                   1>/dev/null 2>&1
# -----------------------------------------------------------------------------------------------------#

10 21      * * 5               $HOME/bin/rman_backup.sh VIPADMT  -f all -l 0 -co -n -x 1  # Db Level 0 bu
10 21      * * 6,0-4           $HOME/bin/rman_backup.sh VIPADMT  -f all -l 1 -co -n -x 1  # Db Level 1 bu
10 3,6,9,12,15,18,22  * * 1-6  $HOME/bin/rman_backup.sh VIPADMT  -f arc -co -n -x 1       # Archiv log bu
30 20,22   * * 5               $HOME/bin/rman_backup.sh VIPADMT  -f arc -co -n -x 1       # Archiv log bu


30 23      * * 5               $HOME/bin/rman_backup.sh MAGDA_T -f all -l 0 -co -x 1 -n   # lev 0 bu
30 23      * * 6,0-4           $HOME/bin/rman_backup.sh MAGDA_T -f all -l 1 -co -x 1 -n   # lev 1 bu
45 3,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,22 * * 0-6        $HOME/bin/rman_backup.sh MAGDA_T -f arc -co -n             # arc log bu
15 3,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,22 * * 0-6        $HOME/bin/rman_backup.sh MAGDA_T -f arc -co -n             # arc log bu


00 20      * * 5               $HOME/bin/rman_backup.sh VIPLOGT  -f all -l 0 -co -n -x 1  # Db Level 0 bu
00 20      * * 0-4           $HOME/bin/rman_backup.sh VIPLOGT  -f all -l 1 -co -n -x 1  # Db Level 1 bu
30 1,5,9,13,17,19 * * 0-5      $HOME/bin/rman_backup.sh VIPLOGT  -f arc -co -n -x 1   # Archiv log bu


13.  [oracle(VIPLOGT)@lv209272:/orahome/oracle]: $HOME/bin/rman_backup.sh VIPLOGT  -f arc -co -n -x 1 &        ####PUSKAM SCRIPTA s ampersant I SLEDQ KAK VYRVI I S KOLKO PROCENTA PADA DADENATA DIREKTORIQ ####


14. [oracle(VIPLOGT)@lv209272:/orahome/oracle]: cd /viplog_ti/oraarch            ##### VSI4KO VE4E E OK #####
[oracle(VIPLOGT)@lv209272:/viplog_ti/oraarch]: ls -la
total 36
drwxr-xr-x 3 oracle oinstall 16384 Jun  3 18:52 .
drwxr-xr-x 6 oracle oinstall  4096 Oct 27  2017 ..
-rw-r--r-- 1 root   root         0 Aug  3  2018 1
drwx------ 2 oracle oinstall 16384 Oct 27  2017 lost+found


15. [oracle(VIPLOGT)@lv209272:/viplog_ti/oraarch]: df -kh               ##### vSI4KO E OK,ZATVARQME TICKET-A ######
Filesystem            Size  Used Avail Use% Mounted on

/dev/mapper/VolGroup10-viplog--oraarch
                      9.8G   23M  9.2G   1% /viplog_ti/oraarch

/dev/mapper/VolGroup15-orabck
                      660G  520G  107G  83% /orabck

