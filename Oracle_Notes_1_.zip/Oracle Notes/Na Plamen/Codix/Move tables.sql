FIDDEV-4307


ARCH_%
BRFAITBANQ
BRFAITCALCUL
BRFAITCOUT
BRFAITDEST
BRFAITENCOUR
BRFAITEVEN
BRFAITNBC
BRFAITPARA
BRFAITPNOM
BRFAITPROC
BRFAITTRIB
BRFAITTXT
BRREGLEBANQ
BRREGLECALCUL
BRREGLECOUT
BRREGLEDEST
BRREGLEEDITEUR
BRREGLEENCOUR
BRREGLEEVEN
BRREGLENBC
BRREGLEPARA
BRREGLEPNOM
BRREGLEPROC
BRREGLETRIB
BRREGLETXT
BRTITREPROC
CODECALCUL
CODECOUT
CODEPARA
IMX_INSTANCE
SE_DESIGNER
T_ANOMALY
T_HISTOEDIT
T_HISTOPAR
T_JAVA
T_LAF_SCHEMA
T_MAIL_PARAM
T_NESTED_PARAGR
T_PARAGR
T_PATCH
T_PATCH_COMP
T_PATCH_DAT
T_PATCH_DELIVERY
T_PATCHDTL
T_RESLIES
T_VARIAB
TMP_IMX_FORMS
TMP_ML_CONTROL
TMP_ML_FORMS
TMP_ML_RES
TMP_ML_TRAD
TMP_T_SSMENU
TMP_V_MENU
V_DOMAINE





'BRFAITBANQ','BRFAITCALCUL','BRFAITCOUT','BRFAITDEST','BRFAITENCOUR','BRFAITEVEN','BRFAITNBC','BRFAITPARA','BRFAITPNOM','BRFAITPROC','BRFAITTRIB','BRFAITTXT','BRREGLEBANQ','BRREGLECALCUL','BRREGLECOUT','BRREGLEDEST','BRREGLEEDITEUR','BRREGLEENCOUR','BRREGLEEVEN','BRREGLENBC','BRREGLEPARA','BRREGLEPNOM','BRREGLEPROC','BRREGLETRIB','BRREGLETXT','BRTITREPROC','CODECALCUL','CODECOUT','CODEPARA','IMX_INSTANCE','SE_DESIGNER','T_ANOMALY','T_HISTOEDIT','T_HISTOPAR','T_JAVA','T_LAF_SCHEMA','T_MAIL_PARAM','T_NESTED_PARAGR','T_PARAGR','T_PATCH','T_PATCH_COMP','T_PATCH_DAT','T_PATCH_DELIVERY','T_PATCHDTL','T_RESLIES','T_VARIAB','TMP_IMX_FORMS','TMP_ML_CONTROL','TMP_ML_FORMS','TMP_ML_RES','TMP_ML_TRAD','TMP_T_SSMENU','TMP_V_MENU','V_DOMAINE'






set lines 400
col OWNER for a10
col SEGMENT_NAME for a30   
col SEGMENT_TYPE for a20
col TABLESPACE_NAME for a15
select OWNER,SEGMENT_NAME,SEGMENT_TYPE,TABLESPACE_NAME from dba_segments where SEGMENT_NAME in 
('BRFAITBANQ','BRFAITCALCUL','BRFAITCOUT','BRFAITDEST','BRFAITENCOUR','BRFAITEVEN','BRFAITNBC','BRFAITPARA','BRFAITPNOM','BRFAITPROC','BRFAITTRIB','BRFAITTXT','BRREGLEBANQ','BRREGLECALCUL','BRREGLECOUT','BRREGLEDEST','BRREGLEEDITEUR','BRREGLEENCOUR','BRREGLEEVEN','BRREGLENBC','BRREGLEPARA','BRREGLEPNOM','BRREGLEPROC','BRREGLETRIB','BRREGLETXT','BRTITREPROC','CODECALCUL','CODECOUT','CODEPARA','IMX_INSTANCE','SE_DESIGNER','T_ANOMALY','T_HISTOEDIT','T_HISTOPAR','T_JAVA','T_LAF_SCHEMA','T_MAIL_PARAM','T_NESTED_PARAGR','T_PARAGR','T_PATCH','T_PATCH_COMP','T_PATCH_DAT','T_PATCH_DELIVERY','T_PATCHDTL','T_RESLIES','T_VARIAB','TMP_IMX_FORMS','TMP_ML_CONTROL','TMP_ML_FORMS','TMP_ML_RES','TMP_ML_TRAD','TMP_T_SSMENU','TMP_V_MENU','V_DOMAINE')
 or SEGMENT_NAME like 'ARCH_%' ;

 
 set lines 400
 col COLUMN_NAME for a32
  col TABLESPACE_NAME for a32
select table_name,column_name,TABLESPACE_NAME
                        from user_lobs 
                        where 
     table_name in ('BRFAITBANQ','BRFAITCALCUL','BRFAITCOUT','BRFAITDEST','BRFAITENCOUR','BRFAITEVEN','BRFAITNBC','BRFAITPARA','BRFAITPNOM','BRFAITPROC','BRFAITTRIB','BRFAITTXT','BRREGLEBANQ','BRREGLECALCUL','BRREGLECOUT','BRREGLEDEST','BRREGLEEDITEUR','BRREGLEENCOUR','BRREGLEEVEN','BRREGLENBC','BRREGLEPARA','BRREGLEPNOM','BRREGLEPROC','BRREGLETRIB','BRREGLETXT','BRTITREPROC','CODECALCUL','CODECOUT','CODEPARA','IMX_INSTANCE','SE_DESIGNER','T_ANOMALY','T_HISTOEDIT','T_HISTOPAR','T_JAVA','T_LAF_SCHEMA','T_MAIL_PARAM','T_NESTED_PARAGR','T_PARAGR','T_PATCH','T_PATCH_COMP','T_PATCH_DAT','T_PATCH_DELIVERY','T_PATCHDTL','T_RESLIES','T_VARIAB','TMP_IMX_FORMS','TMP_ML_CONTROL','TMP_ML_FORMS','TMP_ML_RES','TMP_ML_TRAD','TMP_T_SSMENU','TMP_V_MENU','V_DOMAINE')
 or table_name like 'ARCH_%' ;
	 
	 
	 
	 
	 
	 


 CREATE TABLESPACE "IMXPARAM" DATAFILE '/deus/intra/dbs/DATA/IMXPARAM01.dbf' size 5000M;
 
 CREATE TABLESPACE "IMXPARAM" DATAFILE '/deusval/intra/dbs/DATA/IMXPARAM01.dbf' size  5000M;
 
 CREATE TABLESPACE "IMXPARAM" DATAFILE '/deushf/intra/dbs/DATA/IMXPARAM01.dbf' size  5000M;
 
 
 
 

ALTER USER IMXDB QUOTA UNLIMITED ON IMXPARAM;




	 @$ORACLE_HOME/rdbms/admin/utlrp.sql



conn imxdb/Hljl2kXJmL649Zq7

################################################
 


---MOVE tables


set serverout on

DECLARE
BEGIN
FOR table_entry IN (select table_name
                        from user_tables 
                        where 
     table_name in ('BRFAITBANQ','BRFAITCALCUL','BRFAITCOUT','BRFAITDEST','BRFAITENCOUR','BRFAITEVEN','BRFAITNBC','BRFAITPARA','BRFAITPNOM','BRFAITPROC','BRFAITTRIB','BRFAITTXT','BRREGLEBANQ','BRREGLECALCUL','BRREGLECOUT','BRREGLEDEST','BRREGLEEDITEUR','BRREGLEENCOUR','BRREGLEEVEN','BRREGLENBC','BRREGLEPARA','BRREGLEPNOM','BRREGLEPROC','BRREGLETRIB','BRREGLETXT','BRTITREPROC','CODECALCUL','CODECOUT','CODEPARA','IMX_INSTANCE','SE_DESIGNER','T_ANOMALY','T_HISTOEDIT','T_HISTOPAR','T_JAVA','T_LAF_SCHEMA','T_MAIL_PARAM','T_NESTED_PARAGR','T_PARAGR','T_PATCH','T_PATCH_COMP','T_PATCH_DAT','T_PATCH_DELIVERY','T_PATCHDTL','T_RESLIES','T_VARIAB','TMP_IMX_FORMS','TMP_ML_CONTROL','TMP_ML_FORMS','TMP_ML_RES','TMP_ML_TRAD','TMP_T_SSMENU','TMP_V_MENU','V_DOMAINE') 
	 or table_name like 'ARCH_%' )
LOOP
begin
dbms_output.put_line('ALTER TABLE ' || table_entry.table_name || ' MOVE TABLESPACE IMXPARAM;' );
execute immediate 'ALTER TABLE ' || table_entry.table_name || ' MOVE TABLESPACE IMXPARAM';
EXCEPTION WHEN OTHERS THEN
dbms_output.put_line (SQLERRM);
end;
END LOOP;
END;
/


 
--- MOVE LOB

set serverout on

DECLARE
BEGIN
FOR table_entry IN (select table_name,column_name
                        from user_lobs 
                        where 
     table_name in ('BRFAITBANQ','BRFAITCALCUL','BRFAITCOUT','BRFAITDEST','BRFAITENCOUR','BRFAITEVEN','BRFAITNBC','BRFAITPARA','BRFAITPNOM','BRFAITPROC','BRFAITTRIB','BRFAITTXT','BRREGLEBANQ','BRREGLECALCUL','BRREGLECOUT','BRREGLEDEST','BRREGLEEDITEUR','BRREGLEENCOUR','BRREGLEEVEN','BRREGLENBC','BRREGLEPARA','BRREGLEPNOM','BRREGLEPROC','BRREGLETRIB','BRREGLETXT','BRTITREPROC','CODECALCUL','CODECOUT','CODEPARA','IMX_INSTANCE','SE_DESIGNER','T_ANOMALY','T_HISTOEDIT','T_HISTOPAR','T_JAVA','T_LAF_SCHEMA','T_MAIL_PARAM','T_NESTED_PARAGR','T_PARAGR','T_PATCH','T_PATCH_COMP','T_PATCH_DAT','T_PATCH_DELIVERY','T_PATCHDTL','T_RESLIES','T_VARIAB','TMP_IMX_FORMS','TMP_ML_CONTROL','TMP_ML_FORMS','TMP_ML_RES','TMP_ML_TRAD','TMP_T_SSMENU','TMP_V_MENU','V_DOMAINE') 
	 or table_name like 'ARCH_%' )
LOOP
begin
dbms_output.put_line('ALTER TABLE ' || table_entry.table_name || ' MOVE LOB(' ||table_entry.column_name|| ') STORE AS (TABLESPACE IMXPARAM);' );
execute immediate 'ALTER TABLE ' || table_entry.table_name || ' MOVE LOB(' ||table_entry.column_name|| ') STORE AS (TABLESPACE IMXPARAM)';
EXCEPTION WHEN OTHERS THEN
dbms_output.put_line (SQLERRM);
end;
END LOOP;
END;
/



------ INDEX REBUILD



set serverout on

DECLARE
BEGIN
    FOR index_entry IN (select INDEX_NAME 
                        from user_indexes 
                        where  table_name in ('BRFAITBANQ','BRFAITCALCUL','BRFAITCOUT','BRFAITDEST','BRFAITENCOUR','BRFAITEVEN','BRFAITNBC','BRFAITPARA','BRFAITPNOM','BRFAITPROC','BRFAITTRIB','BRFAITTXT','BRREGLEBANQ','BRREGLECALCUL','BRREGLECOUT','BRREGLEDEST','BRREGLEEDITEUR','BRREGLEENCOUR','BRREGLEEVEN','BRREGLENBC','BRREGLEPARA','BRREGLEPNOM','BRREGLEPROC','BRREGLETRIB','BRREGLETXT','BRTITREPROC','CODECALCUL','CODECOUT','CODEPARA','IMX_INSTANCE','SE_DESIGNER','T_ANOMALY','T_HISTOEDIT','T_HISTOPAR','T_JAVA','T_LAF_SCHEMA','T_MAIL_PARAM','T_NESTED_PARAGR','T_PARAGR','T_PATCH','T_PATCH_COMP','T_PATCH_DAT','T_PATCH_DELIVERY','T_PATCHDTL','T_RESLIES','T_VARIAB','TMP_IMX_FORMS','TMP_ML_CONTROL','TMP_ML_FORMS','TMP_ML_RES','TMP_ML_TRAD','TMP_T_SSMENU','TMP_V_MENU','V_DOMAINE') 
						and index_name not like 'SYS_%'
						and index_type  like '%NORMAL%'
						or table_name like 'ARCH_%'
						 )
    LOOP
        dbms_output.put_line('ALTER INDEX ' || index_entry.INDEX_NAME || ' REBUILD TABLESPACE IMXPARAM;'); 
        EXECUTE IMMEDIATE 'ALTER INDEX ' || index_entry.INDEX_NAME || ' REBUILD TABLESPACE IMXPARAM ' ;
    END LOOP;
END;
/





---- index
set serverout on

DECLARE
BEGIN
    FOR index_entry IN (select INDEX_NAME 
                        from user_indexes 
                        where 
                         index_type='NORMAL' and status='UNUSABLE')
    LOOP
        dbms_output.put_line('ALTER INDEX ' || index_entry.INDEX_NAME || ' REBUILD'); 
        EXECUTE IMMEDIATE 'ALTER INDEX ' || index_entry.INDEX_NAME || ' REBUILD' ||';';
    END LOOP;
END;
/
































--- check

  col INDEX_NAME for a30
 col TABLE_NAME for a30
 col INDEX_TYPE for a30
 set lines 400

 select INDEX_NAME,INDEX_TYPE,TABLE_NAME from DBA_INDEXES where INDEX_NAME='&index';
 


-- check  after move



SELECT 'alter index '|| owner ||'.'||index_name||' rebuild tablespace '||tablespace_name ||';'
	FROM   dba_indexes
	WHERE  status = 'UNUSABLE' ;





set lines 400 pages 100
col OWNER for a10
col SEGMENT_NAME for a30   
col SEGMENT_TYPE for a20
col TABLESPACE_NAME for a15
select OWNER,SEGMENT_NAME,SEGMENT_TYPE,TABLESPACE_NAME from dba_segments where SEGMENT_NAME in 
('BRFAITBANQ','BRFAITCALCUL','BRFAITCOUT','BRFAITDEST','BRFAITENCOUR','BRFAITEVEN','BRFAITNBC','BRFAITPARA','BRFAITPNOM','BRFAITPROC','BRFAITTRIB','BRFAITTXT','BRREGLEBANQ','BRREGLECALCUL','BRREGLECOUT','BRREGLEDEST','BRREGLEEDITEUR','BRREGLEENCOUR','BRREGLEEVEN','BRREGLENBC','BRREGLEPARA','BRREGLEPNOM','BRREGLEPROC','BRREGLETRIB','BRREGLETXT','BRTITREPROC','CODECALCUL','CODECOUT','CODEPARA','IMX_INSTANCE','SE_DESIGNER','T_ANOMALY','T_HISTOEDIT','T_HISTOPAR','T_JAVA','T_LAF_SCHEMA','T_MAIL_PARAM','T_NESTED_PARAGR','T_PARAGR','T_PATCH','T_PATCH_COMP','T_PATCH_DAT','T_PATCH_DELIVERY','T_PATCHDTL','T_RESLIES','T_VARIAB','TMP_IMX_FORMS','TMP_ML_CONTROL','TMP_ML_FORMS','TMP_ML_RES','TMP_ML_TRAD','TMP_T_SSMENU','TMP_V_MENU','V_DOMAINE')
 or SEGMENT_NAME like 'ARCH_%' and  SEGMENT_TYPE='TABLE' order by 4
 ;

 
 
 
 set lines 400
 col COLUMN_NAME for a32
  col TABLESPACE_NAME for a32
select table_name,column_name,TABLESPACE_NAME
                        from user_lobs 
                        where 
     table_name in ('BRFAITBANQ','BRFAITCALCUL','BRFAITCOUT','BRFAITDEST','BRFAITENCOUR','BRFAITEVEN','BRFAITNBC','BRFAITPARA','BRFAITPNOM','BRFAITPROC','BRFAITTRIB','BRFAITTXT','BRREGLEBANQ','BRREGLECALCUL','BRREGLECOUT','BRREGLEDEST','BRREGLEEDITEUR','BRREGLEENCOUR','BRREGLEEVEN','BRREGLENBC','BRREGLEPARA','BRREGLEPNOM','BRREGLEPROC','BRREGLETRIB','BRREGLETXT','BRTITREPROC','CODECALCUL','CODECOUT','CODEPARA','IMX_INSTANCE','SE_DESIGNER','T_ANOMALY','T_HISTOEDIT','T_HISTOPAR','T_JAVA','T_LAF_SCHEMA','T_MAIL_PARAM','T_NESTED_PARAGR','T_PARAGR','T_PATCH','T_PATCH_COMP','T_PATCH_DAT','T_PATCH_DELIVERY','T_PATCHDTL','T_RESLIES','T_VARIAB','TMP_IMX_FORMS','TMP_ML_CONTROL','TMP_ML_FORMS','TMP_ML_RES','TMP_ML_TRAD','TMP_T_SSMENU','TMP_V_MENU','V_DOMAINE')
 or table_name like 'ARCH_%' ;
	 
	 
	 
	 
	 
set lines 400
column OBJECT_NAME format a60
col owner for a10
SELECT OWNER,OBJECT_TYPE,OBJECT_NAME FROM DBA_OBJECTS WHERE STATUS= 'INVALID'  ;
 
 
 
 
 
set pages 100
set lines 400
col owner for a10
col INDEX_NAME for a35
col TABLE_NAME for a32
col COLUMN_NAME  for a35
col SEGMENT_NAME for a35
col TABLESPACE_NAME for a20



select INDEX_NAME,INDEX_TYPE,TABLE_NAME,TABLESPACE_NAME from DBA_INDEXES where INDEX_TYPE not in('LOB') and TABLE_NAME in
('BRFAITBANQ','BRFAITCALCUL','BRFAITCOUT','BRFAITDEST','BRFAITENCOUR','BRFAITEVEN','BRFAITNBC','BRFAITPARA','BRFAITPNOM','BRFAITPROC','BRFAITTRIB','BRFAITTXT','BRREGLEBANQ','BRREGLECALCUL','BRREGLECOUT','BRREGLEDEST','BRREGLEEDITEUR','BRREGLEENCOUR','BRREGLEEVEN','BRREGLENBC','BRREGLEPARA','BRREGLEPNOM','BRREGLEPROC','BRREGLETRIB','BRREGLETXT','BRTITREPROC','CODECALCUL','CODECOUT','CODEPARA','IMX_INSTANCE','SE_DESIGNER','T_ANOMALY','T_HISTOEDIT','T_HISTOPAR','T_JAVA','T_LAF_SCHEMA','T_MAIL_PARAM','T_NESTED_PARAGR','T_PARAGR','T_PATCH','T_PATCH_COMP','T_PATCH_DAT','T_PATCH_DELIVERY','T_PATCHDTL','T_RESLIES','T_VARIAB','TMP_IMX_FORMS','TMP_ML_CONTROL','TMP_ML_FORMS','TMP_ML_RES','TMP_ML_TRAD','TMP_T_SSMENU','TMP_V_MENU','V_DOMAINE')
 or table_name like 'ARCH_%';



 
 


PROMPT "Recompile invalid objects"
DECLARE
  db_version NUMBER;
BEGIN
  SELECT to_number(substr(version, 1, instr(version, '.', 1, 2) - 1))
    INTO db_version
    FROM v$instance;
  IF db_version >= 10.2 THEN
    EXECUTE IMMEDIATE 'begin DBMS_UTILITY.COMPILE_SCHEMA(user, false, true); end;';
  ELSE
    EXECUTE IMMEDIATE 'begin DBMS_UTILITY.COMPILE_SCHEMA(user, false); end;';
  END IF;
END;
/
PROMPT "List of all invalid objects"
set lines 132 pages 1000
COLUMN object_name FORMAT A30
COLUMN object_type FORMAT A30
SELECT object_type,
       object_name,
       status
  FROM user_objects
WHERE status = 'INVALID'
ORDER BY object_type, object_name;



 
 #####





set pages 100
set lines 400
col owner for a10
col INDEX_NAME for a35
col TABLE_NAME for a32
col COLUMN_NAME  for a35
col SEGMENT_NAME for a35
col TABLESPACE_NAME for a20



select INDEX_NAME,INDEX_TYPE,TABLE_NAME,TABLESPACE_NAME from DBA_INDEXES where INDEX_TYPE not in('LOB') and TABLE_NAME in
('BRFAITBANQ','BRFAITCALCUL','BRFAITCOUT','BRFAITDEST','BRFAITENCOUR','BRFAITEVEN','BRFAITNBC','BRFAITPARA','BRFAITPNOM','BRFAITPROC','BRFAITTRIB','BRFAITTXT','BRREGLEBANQ','BRREGLECALCUL','BRREGLECOUT','BRREGLEDEST','BRREGLEEDITEUR','BRREGLEENCOUR','BRREGLEEVEN','BRREGLENBC','BRREGLEPARA','BRREGLEPNOM','BRREGLEPROC','BRREGLETRIB','BRREGLETXT','BRTITREPROC','CODECALCUL','CODECOUT','CODEPARA','IMX_INSTANCE','SE_DESIGNER','T_ANOMALY','T_HISTOEDIT','T_HISTOPAR','T_JAVA','T_LAF_SCHEMA','T_MAIL_PARAM','T_NESTED_PARAGR','T_PARAGR','T_PATCH','T_PATCH_COMP','T_PATCH_DAT','T_PATCH_DELIVERY','T_PATCHDTL','T_RESLIES','T_VARIAB','TMP_IMX_FORMS','TMP_ML_CONTROL','TMP_ML_FORMS','TMP_ML_RES','TMP_ML_TRAD','TMP_T_SSMENU','TMP_V_MENU','V_DOMAINE');


set pages 100
set lines 400
col owner for a10
col INDEX_NAME for a35
col TABLE_NAME for a32
col COLUMN_NAME  for a35
col SEGMENT_NAME for a35
col TABLESPACE_NAME for a20

select TABLE_NAME,COLUMN_NAME,SEGMENT_NAME,tablespace_name from dba_lobs where TABLE_NAME in
('BRFAITBANQ','BRFAITCALCUL','BRFAITCOUT','BRFAITDEST','BRFAITENCOUR','BRFAITEVEN','BRFAITNBC','BRFAITPARA','BRFAITPNOM','BRFAITPROC','BRFAITTRIB','BRFAITTXT','BRREGLEBANQ','BRREGLECALCUL','BRREGLECOUT','BRREGLEDEST','BRREGLEEDITEUR','BRREGLEENCOUR','BRREGLEEVEN','BRREGLENBC','BRREGLEPARA','BRREGLEPNOM','BRREGLEPROC','BRREGLETRIB','BRREGLETXT','BRTITREPROC','CODECALCUL','CODECOUT','CODEPARA','IMX_INSTANCE','SE_DESIGNER','T_ANOMALY','T_HISTOEDIT','T_HISTOPAR','T_JAVA','T_LAF_SCHEMA','T_MAIL_PARAM','T_NESTED_PARAGR','T_PARAGR','T_PATCH','T_PATCH_COMP','T_PATCH_DAT','T_PATCH_DELIVERY','T_PATCHDTL','T_RESLIES','T_VARIAB','TMP_IMX_FORMS','TMP_ML_CONTROL','TMP_ML_FORMS','TMP_ML_RES','TMP_ML_TRAD','TMP_T_SSMENU','TMP_V_MENU','V_DOMAINE');


set pages 100
set lines 400
col owner for a10
col INDEX_NAME for a35
col TABLE_NAME for a32
col COLUMN_NAME  for a35
col SEGMENT_NAME for a35
col TABLESPACE_NAME for a20

select TABLE_NAME,TABLESPACE_NAME from dba_tables where TABLE_NAME in
('BRFAITBANQ','BRFAITCALCUL','BRFAITCOUT','BRFAITDEST','BRFAITENCOUR','BRFAITEVEN','BRFAITNBC','BRFAITPARA','BRFAITPNOM','BRFAITPROC','BRFAITTRIB','BRFAITTXT','BRREGLEBANQ','BRREGLECALCUL','BRREGLECOUT','BRREGLEDEST','BRREGLEEDITEUR','BRREGLEENCOUR','BRREGLEEVEN','BRREGLENBC','BRREGLEPARA','BRREGLEPNOM','BRREGLEPROC','BRREGLETRIB','BRREGLETXT','BRTITREPROC','CODECALCUL','CODECOUT','CODEPARA','IMX_INSTANCE','SE_DESIGNER','T_ANOMALY','T_HISTOEDIT','T_HISTOPAR','T_JAVA','T_LAF_SCHEMA','T_MAIL_PARAM','T_NESTED_PARAGR','T_PARAGR','T_PATCH','T_PATCH_COMP','T_PATCH_DAT','T_PATCH_DELIVERY','T_PATCHDTL','T_RESLIES','T_VARIAB','TMP_IMX_FORMS','TMP_ML_CONTROL','TMP_ML_FORMS','TMP_ML_RES','TMP_ML_TRAD','TMP_T_SSMENU','TMP_V_MENU','V_DOMAINE') order by 2 ;


################################################
 




















---- NEW METHOD


    ----      set timing on;
    ----      set serverout on;
    ----      alter table T_HISTOPAR          move update indexes TABLESPACE IMXPARAM;
    ----       
    ----       			 
    ----      alter table BRFAITBANQ          move update indexes TABLESPACE IMXPARAM;
    ----      alter table BRFAITCALCUL        move update indexes TABLESPACE IMXPARAM;
    ----      alter table BRFAITCOUT          move update indexes TABLESPACE IMXPARAM;
    ----      alter table BRFAITDEST          move update indexes TABLESPACE IMXPARAM;
    ----      alter table BRFAITENCOUR        move update indexes TABLESPACE IMXPARAM;
    ----      alter table BRFAITEVEN          move update indexes TABLESPACE IMXPARAM;
    ----      alter table BRFAITNBC           move update indexes TABLESPACE IMXPARAM;
    ----      alter table BRFAITPARA          move update indexes TABLESPACE IMXPARAM;
    ----      alter table BRFAITPNOM          move update indexes TABLESPACE IMXPARAM;
    ----      alter table BRFAITPROC          move update indexes TABLESPACE IMXPARAM;
    ----      alter table BRFAITTRIB          move update indexes TABLESPACE IMXPARAM;
    ----      alter table BRFAITTXT           move update indexes TABLESPACE IMXPARAM;
    ----      alter table BRREGLEBANQ         move update indexes TABLESPACE IMXPARAM;
    ----      alter table BRREGLECALCUL       move update indexes TABLESPACE IMXPARAM;
    ----      alter table BRREGLECOUT         move update indexes TABLESPACE IMXPARAM;
    ----      alter table BRREGLEDEST         move update indexes TABLESPACE IMXPARAM;
    ----      alter table BRREGLEEDITEUR      move update indexes TABLESPACE IMXPARAM;
    ----      alter table BRREGLEENCOUR       move update indexes TABLESPACE IMXPARAM;
    ----      alter table BRREGLEEVEN         move update indexes TABLESPACE IMXPARAM;
    ----      alter table BRREGLENBC          move update indexes TABLESPACE IMXPARAM;
    ----      alter table BRREGLEPARA         move update indexes TABLESPACE IMXPARAM;
    ----      alter table BRREGLEPNOM         move update indexes TABLESPACE IMXPARAM;
    ----      alter table BRREGLEPROC         move update indexes TABLESPACE IMXPARAM;
    ----      alter table BRREGLETRIB         move update indexes TABLESPACE IMXPARAM;
    ----      alter table BRREGLETXT          move update indexes TABLESPACE IMXPARAM;
    ----      alter table BRTITREPROC         move update indexes TABLESPACE IMXPARAM;
    ----      alter table CODECALCUL          move update indexes TABLESPACE IMXPARAM;
    ----      alter table CODECOUT            move update indexes TABLESPACE IMXPARAM;
    ----      alter table CODEPARA            move update indexes TABLESPACE IMXPARAM;
    ----      alter table IMX_INSTANCE        move update indexes TABLESPACE IMXPARAM;
    ----      alter table SE_DESIGNER         move update indexes TABLESPACE IMXPARAM;
    ----      alter table T_ANOMALY           move update indexes TABLESPACE IMXPARAM;
    ----      alter table T_HISTOEDIT         move update indexes TABLESPACE IMXPARAM;
    ----      alter table T_HISTOPAR          move update indexes TABLESPACE IMXPARAM;
    ----      alter table T_JAVA              move update indexes TABLESPACE IMXPARAM;
    ----      alter table T_LAF_SCHEMA        move update indexes TABLESPACE IMXPARAM;
    ----      alter table T_MAIL_PARAM        move update indexes TABLESPACE IMXPARAM;
    ----      alter table T_NESTED_PARAGR     move update indexes TABLESPACE IMXPARAM;
    ----      alter table T_PARAGR            move update indexes TABLESPACE IMXPARAM;
    ----      alter table T_PATCH             move update indexes TABLESPACE IMXPARAM;
    ----      alter table T_PATCH_COMP        move update indexes TABLESPACE IMXPARAM;
    ----      alter table T_PATCH_DAT         move update indexes TABLESPACE IMXPARAM;
    ----      alter table T_PATCH_DELIVERY    move update indexes TABLESPACE IMXPARAM;
    ----      alter table T_PATCHDTL          move update indexes TABLESPACE IMXPARAM;
    ----      alter table T_RESLIES           move update indexes TABLESPACE IMXPARAM;
    ----      alter table T_VARIAB            move update indexes TABLESPACE IMXPARAM;
    ----      alter table TMP_IMX_FORMS       move update indexes TABLESPACE IMXPARAM;
    ----      alter table TMP_ML_CONTROL      move update indexes TABLESPACE IMXPARAM;
    ----      alter table TMP_ML_FORMS        move update indexes TABLESPACE IMXPARAM;
    ----      alter table TMP_ML_RES          move update indexes TABLESPACE IMXPARAM;
    ----      alter table TMP_ML_TRAD         move update indexes TABLESPACE IMXPARAM;
    ----      alter table TMP_T_SSMENU        move update indexes TABLESPACE IMXPARAM;
    ----      alter table TMP_V_MENU          move update indexes TABLESPACE IMXPARAM;
    ----      alter table V_DOMAINE           move update indexes TABLESPACE IMXPARAM;
    ----      
    ----      T_PARAGR
    ----      ---MOVE tables
    ----      
    ----      
    ----       
    ----      
    ----      
    ----      set lines 400 pages 100
    ----      col table_name for a32
    ----      select table_name from user_tables 
    ----                              where 
    ----           table_name in ('BRFAITBANQ','BRFAITCALCUL','BRFAITCOUT','BRFAITDEST','BRFAITENCOUR','BRFAITEVEN','BRFAITNBC','BRFAITPARA','BRFAITPNOM','BRFAITPROC','BRFAITTRIB','BRFAITTXT','BRREGLEBANQ','BRREGLECALCUL','BRREGLECOUT','BRREGLEDEST','BRREGLEEDITEUR','BRREGLEENCOUR','BRREGLEEVEN','BRREGLENBC','BRREGLEPARA','BRREGLEPNOM','BRREGLEPROC','BRREGLETRIB','BRREGLETXT','BRTITREPROC','CODECALCUL','CODECOUT','CODEPARA','IMX_INSTANCE','SE_DESIGNER','T_ANOMALY','T_HISTOEDIT','T_HISTOPAR','T_JAVA','T_LAF_SCHEMA','T_MAIL_PARAM','T_NESTED_PARAGR','T_PARAGR','T_PATCH','T_PATCH_COMP','T_PATCH_DAT','T_PATCH_DELIVERY','T_PATCHDTL','T_RESLIES','T_VARIAB','TMP_IMX_FORMS','TMP_ML_CONTROL','TMP_ML_FORMS','TMP_ML_RES','TMP_ML_TRAD','TMP_T_SSMENU','TMP_V_MENU','V_DOMAINE') 
    ----      	 or table_name like 'ARCH_%' 
    ----      	 ;
    ----      	 
    ----      66 rows selected.	 
    ----      	 
    ----      	 --- patch content
    ----      
    ----       set serverout on
    ----       
    ----       DECLARE
    ----       BEGIN
    ----       FOR table_entry IN (select table_name,column_name
    ----                               from user_lobs 
    ----                               where 
    ----            table_name in ('BRFAITBANQ','BRFAITCALCUL','BRFAITCOUT','BRFAITDEST','BRFAITENCOUR','BRFAITEVEN','BRFAITNBC','BRFAITPARA','BRFAITPNOM','BRFAITPROC','BRFAITTRIB','BRFAITTXT','BRREGLEBANQ','BRREGLECALCUL','BRREGLECOUT','BRREGLEDEST','BRREGLEEDITEUR','BRREGLEENCOUR','BRREGLEEVEN','BRREGLENBC','BRREGLEPARA','BRREGLEPNOM','BRREGLEPROC','BRREGLETRIB','BRREGLETXT','BRTITREPROC','CODECALCUL','CODECOUT','CODEPARA','IMX_INSTANCE','SE_DESIGNER','T_ANOMALY','T_HISTOEDIT','T_HISTOPAR','T_JAVA','T_LAF_SCHEMA','T_MAIL_PARAM','T_NESTED_PARAGR','T_PARAGR','T_PATCH','T_PATCH_COMP','T_PATCH_DAT','T_PATCH_DELIVERY','T_PATCHDTL','T_RESLIES','T_VARIAB','TMP_IMX_FORMS','TMP_ML_CONTROL','TMP_ML_FORMS','TMP_ML_RES','TMP_ML_TRAD','TMP_T_SSMENU','TMP_V_MENU','V_DOMAINE') or table_name like 'ARCH_%' )
    ----       LOOP
    ----       begin
    ----       dbms_output.put_line('ALTER TABLE ' || table_entry.table_name || ' MOVE LOB(' ||table_entry.column_name|| ') STORE AS (TABLESPACE IMXPARAM);' );
    ----       execute immediate 'ALTER TABLE ' || table_entry.table_name || ' MOVE LOB(' ||table_entry.column_name|| ') STORE AS (TABLESPACE IMXPARAM)';
    ----       EXCEPTION WHEN OTHERS THEN
    ----       dbms_output.put_line (SQLERRM);
    ----       end;
    ----       END LOOP;
    ----       END;
    ----       /
    ----       
    ----       	 
    ----       	 
    ----       
    ----       set serverout on
    ----       
    ----       DECLARE
    ----       BEGIN
    ----       FOR table_entry IN (select table_name
    ----                               from user_tables 
    ----                               where 
    ----            table_name in ('BRFAITBANQ','BRFAITCALCUL','BRFAITCOUT','BRFAITDEST','BRFAITENCOUR','BRFAITEVEN','BRFAITNBC','BRFAITPARA','BRFAITPNOM','BRFAITPROC','BRFAITTRIB','BRFAITTXT','BRREGLEBANQ','BRREGLECALCUL','BRREGLECOUT','BRREGLEDEST','BRREGLEEDITEUR','BRREGLEENCOUR','BRREGLEEVEN','BRREGLENBC','BRREGLEPARA','BRREGLEPNOM','BRREGLEPROC','BRREGLETRIB','BRREGLETXT','BRTITREPROC','CODECALCUL','CODECOUT','CODEPARA','IMX_INSTANCE','SE_DESIGNER','T_ANOMALY','T_HISTOEDIT','T_HISTOPAR','T_JAVA','T_LAF_SCHEMA','T_MAIL_PARAM','T_NESTED_PARAGR','T_PARAGR','T_PATCH','T_PATCH_COMP','T_PATCH_DAT','T_PATCH_DELIVERY','T_PATCHDTL','T_RESLIES','T_VARIAB','TMP_IMX_FORMS','TMP_ML_CONTROL','TMP_ML_FORMS','TMP_ML_RES','TMP_ML_TRAD','TMP_T_SSMENU','TMP_V_MENU','V_DOMAINE') or table_name like 'ARCH_%' )
    ----        LOOP
    ----        begin
    ----        dbms_output.put_line('ALTER TABLE ' || table_entry.table_name || ' MOVE update indexes TABLESPACE IMXPARAM;');
    ----        execute immediate 'ALTER TABLE ' || table_entry.table_name || ' MOVE update indexes TABLESPACE IMXPARAM';
    ----        EXCEPTION WHEN OTHERS THEN
    ----        dbms_output.put_line (SQLERRM);
    ----        end;
    ----        END LOOP;
    ----        END;
    ----        /
    ----        









-- check  after move



SELECT 'alter index '|| owner ||'.'||index_name||' rebuild tablespace '||tablespace_name ||';'
	FROM   dba_indexes
	WHERE  status = 'UNUSABLE' ;





set lines 400 pages 100
col OWNER for a10
col SEGMENT_NAME for a30   
col SEGMENT_TYPE for a20
col TABLESPACE_NAME for a15
select OWNER,SEGMENT_NAME,SEGMENT_TYPE,TABLESPACE_NAME from dba_segments where SEGMENT_NAME in 
('BRFAITBANQ','BRFAITCALCUL','BRFAITCOUT','BRFAITDEST','BRFAITENCOUR','BRFAITEVEN','BRFAITNBC','BRFAITPARA','BRFAITPNOM','BRFAITPROC','BRFAITTRIB','BRFAITTXT','BRREGLEBANQ','BRREGLECALCUL','BRREGLECOUT','BRREGLEDEST','BRREGLEEDITEUR','BRREGLEENCOUR','BRREGLEEVEN','BRREGLENBC','BRREGLEPARA','BRREGLEPNOM','BRREGLEPROC','BRREGLETRIB','BRREGLETXT','BRTITREPROC','CODECALCUL','CODECOUT','CODEPARA','IMX_INSTANCE','SE_DESIGNER','T_ANOMALY','T_HISTOEDIT','T_HISTOPAR','T_JAVA','T_LAF_SCHEMA','T_MAIL_PARAM','T_NESTED_PARAGR','T_PARAGR','T_PATCH','T_PATCH_COMP','T_PATCH_DAT','T_PATCH_DELIVERY','T_PATCHDTL','T_RESLIES','T_VARIAB','TMP_IMX_FORMS','TMP_ML_CONTROL','TMP_ML_FORMS','TMP_ML_RES','TMP_ML_TRAD','TMP_T_SSMENU','TMP_V_MENU','V_DOMAINE')
 or SEGMENT_NAME like 'ARCH_%'  order by 4
 ;

 
 
 
 set lines 400
 col COLUMN_NAME for a32
  col TABLESPACE_NAME for a32
select table_name,column_name,TABLESPACE_NAME
                        from user_lobs 
                        where 
     table_name in ('BRFAITBANQ','BRFAITCALCUL','BRFAITCOUT','BRFAITDEST','BRFAITENCOUR','BRFAITEVEN','BRFAITNBC','BRFAITPARA','BRFAITPNOM','BRFAITPROC','BRFAITTRIB','BRFAITTXT','BRREGLEBANQ','BRREGLECALCUL','BRREGLECOUT','BRREGLEDEST','BRREGLEEDITEUR','BRREGLEENCOUR','BRREGLEEVEN','BRREGLENBC','BRREGLEPARA','BRREGLEPNOM','BRREGLEPROC','BRREGLETRIB','BRREGLETXT','BRTITREPROC','CODECALCUL','CODECOUT','CODEPARA','IMX_INSTANCE','SE_DESIGNER','T_ANOMALY','T_HISTOEDIT','T_HISTOPAR','T_JAVA','T_LAF_SCHEMA','T_MAIL_PARAM','T_NESTED_PARAGR','T_PARAGR','T_PATCH','T_PATCH_COMP','T_PATCH_DAT','T_PATCH_DELIVERY','T_PATCHDTL','T_RESLIES','T_VARIAB','TMP_IMX_FORMS','TMP_ML_CONTROL','TMP_ML_FORMS','TMP_ML_RES','TMP_ML_TRAD','TMP_T_SSMENU','TMP_V_MENU','V_DOMAINE')
 or table_name like 'ARCH_%' ;
	 
	 
	 
	 
	 
set lines 400
column OBJECT_NAME format a60
col owner for a10
SELECT OWNER,OBJECT_TYPE,OBJECT_NAME FROM DBA_OBJECTS WHERE STATUS= 'INVALID'  ;
 
 



