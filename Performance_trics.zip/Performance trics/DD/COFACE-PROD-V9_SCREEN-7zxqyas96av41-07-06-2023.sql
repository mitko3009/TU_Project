/********************************************************************************
*********       E-mail subject: COFADEV-11300
*********             Instance: PROD
*********          Description: 
Problem: 

Heavy query on PROD from V9 screen.

Analysis:

On 06/06/2023 the heaviest query on COFACE PROD was 7zxqyas96av41.
The problem was inapropriate execution plan.

Suggestion:

Please change the hints shown in the New SQL section.

*********               SQL_ID: 7zxqyas96av41
*********      Program/Package: codix.api.be.dossierComponents.dossier.CasesResource
*********              Request: Dimitare Ivanov
*********               Author: Dimitar Dimitrov
********* Received e-mail date: 06/06/2023
*********      Resolution date: 07/06/2023
*********  Trace old file here: \\epox\specifs\performance\tmp\
*********  Trace new file here:
***********************************************************************************/

/********************************OLD SQL*******************************************/


var B1 VARCHAR2(32);
EXEC :B1 := 'TC';
var B2 VARCHAR2(32);
EXEC :B2 := 'CRO';
var B3 VARCHAR2(32);
EXEC :B3 := 'CL';
var B4 VARCHAR2(32);
EXEC :B4 := 'CL';
var B5 VARCHAR2(128);
EXEC :B5 := '2306060307';
 
SELECT COUNT(DISTINCT refdoss) countCases
  FROM ( SELECT /*+ leading(g t gd ti gp git) use_nl(t ti gp gd git) index(g dos_refdoss) NUM_INDEX_KEYS(TI INT_INDIV 2) */
                TI.refdoss
           FROM T_INTERVENANTS TI,
                g_dossier      gd,
                G_PIECE         GP,
                G_INSTR_TYPE   GIT,
                T_INTERVENANTS t,
                g_dossier      g
          WHERE ti.refdoss = gp.refdoss
            AND ti.refdoss = gd.refdoss
            AND gp.refpiece = git.refpiece
            AND gp.typpiece = 'REC_CONTRAT'
            AND git.type_instr = '1'
            AND git.dt_end_dt IS NULL
            AND ti.reftype IN (:B1 , :B2 )
            AND ti.refindividu = t.refindividu
            AND t.refdoss = g.refdoss
            AND gd.categdoss = 'CUSTOMER ACCOUNT'
            AND t.REFTYPE IN (:B3 , :B4 )
            AND g.refdoss = :B5 );
	
/********************************OLD SQL*******************************************/
/********************************OLD Metrics***************************************/
/*

SQL_ID              MODULE               ELAPSED MAX_WAIT        GETS      READS       ROWS   ELAP/EXEC  GETS/EXEC READS/EXEC  ROWS/EXEC       EXEC PLAN_HASH_VALUE
------------------- ----------------- ---------- --------- ---------- ---------- ---------- ----------- ---------- ---------- ---------- ---------- ---------------
7zxqyas96av41       519FEDD0CD50A06FA      10467 98% cpu   3107531870     366910      56282         .19    55213.6       6.52          1      56282      1368371719
                    C09B7A78671425B
                    
Plan hash VALUE: 1368371719
--------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                 | Name              | Starts | E-ROWS | Cost (%CPU)| A-ROWS |   A-TIME   | Buffers |
--------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                          |                   |      1 |        |  5530 (100)|      1 |00:00:00.25 |   55252 |
|   1 |  SORT AGGREGATE                           |                   |      1 |      1 |            |      1 |00:00:00.25 |   55252 |
|   2 |   VIEW                                    | VW_DAG_0          |      1 |      1 |  5530   (1)|      0 |00:00:00.25 |   55252 |
|   3 |    HASH GROUP BY                          |                   |      1 |      1 |  5530   (1)|      0 |00:00:00.25 |   55252 |
|   4 |     NESTED LOOPS                          |                   |      1 |      3 |  5529   (1)|      0 |00:00:00.25 |   55252 |
|   5 |      NESTED LOOPS                         |                   |      1 |  13548 |  5529   (1)|      0 |00:00:00.25 |   55252 |
|   6 |       NESTED LOOPS                        |                   |      1 |   4516 |  5438   (1)|      0 |00:00:00.25 |   55252 |
|   7 |        NESTED LOOPS                       |                   |      1 |   1976 |  5340   (1)|      0 |00:00:00.25 |   55252 |
|   8 |         NESTED LOOPS                      |                   |      1 |    175K|    78   (0)|    134K|00:00:00.05 |    1513 |
|   9 |          NESTED LOOPS                     |                   |      1 |      2 |     2   (0)|      1 |00:00:00.01 |       6 |
|* 10 |           INDEX UNIQUE SCAN               | DOS_REFDOSS       |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |
|* 11 |           INDEX RANGE SCAN                | INT_REFDOSS       |      1 |      2 |     1   (0)|      1 |00:00:00.01 |       3 |
|* 12 |          INDEX SKIP SCAN                  | REFHIERARCHIE_IDX |      1 |  87562 |    38   (0)|    134K|00:00:00.04 |    1507 |
|  13 |         INLIST ITERATOR                   |                   |    134K|        |            |      0 |00:00:00.18 |   53739 |
|* 14 |          INDEX RANGE SCAN                 | INT_REFDOSS       |    268K|      1 |     1   (0)|      0 |00:00:00.14 |   53739 |
|  15 |        TABLE ACCESS BY INDEX ROWID BATCHED| G_PIECE           |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 16 |         INDEX RANGE SCAN                  | PIE_REFDOSS       |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 17 |       INDEX RANGE SCAN                    | GIT_REFPIECE_IDX  |      0 |      3 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 18 |      TABLE ACCESS BY INDEX ROWID          | G_INSTR_TYPE      |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
--------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (IDENTIFIED BY operation id):
---------------------------------------------------
  10 - access("G"."REFDOSS"=:B5)
  11 - access("T"."REFDOSS"=:B5)
       FILTER(("T"."REFTYPE"=:B3 OR "T"."REFTYPE"=:B4))
  12 - access("GD"."CATEGDOSS"='CUSTOMER ACCOUNT')
       FILTER("GD"."CATEGDOSS"='CUSTOMER ACCOUNT')
  14 - access("TI"."REFDOSS"="GD"."REFDOSS" AND (("TI"."REFTYPE"=:B1 OR "TI"."REFTYPE"=:B2)) AND
              "TI"."REFINDIVIDU"="T"."REFINDIVIDU")
  16 - access("TI"."REFDOSS"="GP"."REFDOSS" AND "GP"."TYPPIECE"='REC_CONTRAT')
  17 - access("GP"."REFPIECE"="GIT"."REFPIECE")
  18 - FILTER(("GIT"."DT_END_DT" IS NULL AND "GIT"."TYPE_INSTR"='1'))
*/
/********************************OLD Metrics***************************************/

/********************************New SQL*******************************************/

var B1 VARCHAR2(32);
EXEC :B1 := 'TC';
var B2 VARCHAR2(32);
EXEC :B2 := 'CRO';
var B3 VARCHAR2(32);
EXEC :B3 := 'CL';
var B4 VARCHAR2(32);
EXEC :B4 := 'CL';
var B5 VARCHAR2(128);
EXEC :B5 := '2306060307';
 
SELECT COUNT(DISTINCT refdoss) countCases
  FROM ( SELECT /*+ leading( g t ti gd gp git ) use_nl(t ti gp gd git) index(g dos_refdoss) NUM_INDEX_KEYS(TI INT_INDIV 2) */
                TI.refdoss
           FROM T_INTERVENANTS TI,
                g_dossier      gd,
                G_PIECE         GP,
                G_INSTR_TYPE   GIT,
                T_INTERVENANTS t,
                g_dossier      g
          WHERE ti.refdoss = gp.refdoss
            AND ti.refdoss = gd.refdoss
            AND gp.refpiece = git.refpiece
            AND gp.typpiece = 'REC_CONTRAT'
            AND git.type_instr = '1'
            AND git.dt_end_dt IS NULL
            AND ti.reftype IN (:B1 , :B2 )
            AND ti.refindividu = t.refindividu
            AND t.refdoss = g.refdoss 
            AND gd.categdoss = 'CUSTOMER ACCOUNT'
            AND t.REFTYPE IN (:B3 , :B4 )
            AND g.refdoss = :B5 );
            
/********************************New SQL*******************************************/
/********************************New Metrics***************************************/
/*
Plan hash value: 153229175

-------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                 | Name             | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers |
-------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                          |                  |      1 |        |   234 (100)|      1 |00:00:00.01 |      12 |
|   1 |  SORT AGGREGATE                           |                  |      1 |      1 |            |      1 |00:00:00.01 |      12 |
|   2 |   VIEW                                    | VW_DAG_0         |      1 |      1 |   234   (1)|      0 |00:00:00.01 |      12 |
|   3 |    HASH GROUP BY                          |                  |      1 |      1 |   234   (1)|      0 |00:00:00.01 |      12 |
|   4 |     NESTED LOOPS                          |                  |      1 |      3 |   233   (0)|      0 |00:00:00.01 |      12 |
|   5 |      NESTED LOOPS                         |                  |      1 |  13548 |   233   (0)|      0 |00:00:00.01 |      12 |
|   6 |       NESTED LOOPS                        |                  |      1 |   4516 |   142   (0)|      0 |00:00:00.01 |      12 |
|   7 |        NESTED LOOPS                       |                  |      1 |   1976 |    44   (0)|      0 |00:00:00.01 |      12 |
|   8 |         NESTED LOOPS                      |                  |      1 |   2030 |     3   (0)|      0 |00:00:00.01 |      12 |
|   9 |          NESTED LOOPS                     |                  |      1 |      2 |     2   (0)|      1 |00:00:00.01 |       6 |
|* 10 |           INDEX UNIQUE SCAN               | DOS_REFDOSS      |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |
|* 11 |           INDEX RANGE SCAN                | INT_REFDOSS      |      1 |      2 |     1   (0)|      1 |00:00:00.01 |       3 |
|  12 |          INLIST ITERATOR                  |                  |      1 |        |            |      0 |00:00:00.01 |       6 |
|* 13 |           INDEX RANGE SCAN                | INT_INDIV        |      2 |   1014 |     1   (0)|      0 |00:00:00.01 |       6 |
|* 14 |         TABLE ACCESS BY INDEX ROWID       | G_DOSSIER        |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 15 |          INDEX UNIQUE SCAN                | DOS_REFDOSS      |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|  16 |        TABLE ACCESS BY INDEX ROWID BATCHED| G_PIECE          |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 17 |         INDEX RANGE SCAN                  | PIE_REFDOSS      |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 18 |       INDEX RANGE SCAN                    | GIT_REFPIECE_IDX |      0 |      3 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 19 |      TABLE ACCESS BY INDEX ROWID          | G_INSTR_TYPE     |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
-------------------------------------------------------------------------------------------------------------------------------------

Predicate Information (identified by operation id):
---------------------------------------------------

  10 - access("G"."REFDOSS"=:B5)
  11 - access("T"."REFDOSS"=:B5)
       filter(("T"."REFTYPE"=:B3 OR "T"."REFTYPE"=:B4))
  13 - access("TI"."REFINDIVIDU"="T"."REFINDIVIDU" AND (("TI"."REFTYPE"=:B1 OR "TI"."REFTYPE"=:B2)))
  14 - filter("GD"."CATEGDOSS"='CUSTOMER ACCOUNT')
  15 - access("TI"."REFDOSS"="GD"."REFDOSS")
  17 - access("TI"."REFDOSS"="GP"."REFDOSS" AND "GP"."TYPPIECE"='REC_CONTRAT')
  18 - access("GP"."REFPIECE"="GIT"."REFPIECE")
  19 - filter(("GIT"."DT_END_DT" IS NULL AND "GIT"."TYPE_INSTR"='1'))
*/
/********************************New Metrics***************************************/

/********************************Index statistics**********************************/

/********************************Other SQLs****************************************/          
/*

*/ 
/********************************Other SQLs****************************************/              
