================================================================================
================================================================================

ПРИ CLUSTER едната ръка трябва да знае за другата, 
E-IM028740522 - Please check DB SMDMGRE hosted on iracp-bv02.gre.omc.hp.com

iracp20.ssn.entsvcs.com
=================================================================================
================================================================================

RMAN> show all
2> ;

using target database control file instead of recovery catalog
RMAN configuration parameters for database with db_unique_name SMDMGRE are:
CONFIGURE RETENTION POLICY TO RECOVERY WINDOW OF 30 DAYS;
CONFIGURE BACKUP OPTIMIZATION ON;
CONFIGURE DEFAULT DEVICE TYPE TO DISK; # default
CONFIGURE CONTROLFILE AUTOBACKUP ON;
CONFIGURE CONTROLFILE AUTOBACKUP FORMAT FOR DEVICE TYPE DISK TO '%F'; # default
CONFIGURE CONTROLFILE AUTOBACKUP FORMAT FOR DEVICE TYPE SBT_TAPE TO '%F'; # default
CONFIGURE DEVICE TYPE DISK PARALLELISM 1 BACKUP TYPE TO BACKUPSET; # default
CONFIGURE DEVICE TYPE SBT_TAPE PARALLELISM 1 BACKUP TYPE TO BACKUPSET; # default
CONFIGURE DATAFILE BACKUP COPIES FOR DEVICE TYPE DISK TO 2;
CONFIGURE DATAFILE BACKUP COPIES FOR DEVICE TYPE SBT_TAPE TO 1; # default
CONFIGURE ARCHIVELOG BACKUP COPIES FOR DEVICE TYPE DISK TO 1;
CONFIGURE ARCHIVELOG BACKUP COPIES FOR DEVICE TYPE SBT_TAPE TO 1; # default
CONFIGURE CHANNEL DEVICE TYPE 'SBT_TAPE' PARMS  'SBT_LIBRARY=/opt/omni/lib/libob2oracle8_64bit.so,ENV=(OB2BARTYPE=Oracle8,OB2APPNAME=PMDMGRE,OB2BARHOSTNAME=gracs20.gre.omc.hp.com)';
CONFIGURE MAXSETSIZE TO UNLIMITED; # default
CONFIGURE ENCRYPTION FOR DATABASE OFF; # default
CONFIGURE ENCRYPTION ALGORITHM 'AES128'; # default
CONFIGURE COMPRESSION ALGORITHM 'BASIC' AS OF RELEASE 'DEFAULT' OPTIMIZE FOR LOAD TRUE ; # default
CONFIGURE ARCHIVELOG DELETION POLICY TO APPLIED ON STANDBY;
CONFIGURE SNAPSHOT CONTROLFILE NAME TO '/u04/app/oracle/scf/PMDMGRE.scf'; 
 



SQL> show parameter control;

NAME                                 TYPE        VALUE
------------------------------------ ----------- ------------------------------
control_file_record_keep_time        integer     15
control_files                        string      +DG_DATA/smdmgre/controlfile/c
                                                 urrent.510.936117847, +DG_LOGS
                                                 /smdmgre/controlfile/current.2
                                                 1251.936117847 
 

CONFIGURE SNAPSHOT CONTROLFILE NAME TO '+DG_LOGS/smdmgre/controlfile/PMDMGRE.scf'; 
 


==================================================================================
===================================================================================

Hello Backup team,

We are contacting you regarding following request:


Backup of DB SMDMGRE hosted on iracp-bv02.gre.omc.hp.com failed with follow errors:


[Major] From: ob2rman@iracp20 "SMDMGRE" Time: 07/23/2019 02:03:51 PM
                External utility reported error.

RMAN PID=3787

[Major] From: ob2rman@iracp20 "SMDMGRE" Time: 07/23/2019 02:03:51 PM
                The database reported error while performing requested operation.

RMAN-00571: ===========================================================
RMAN-00569: =============== ERROR MESSAGE STACK FOLLOWS ===============
RMAN-00571: ===========================================================
RMAN-03009: failure of Control File and SPFILE Autobackup command on dev_0 channel at 07/23/2019 14:03:46
ORA-00245: control file backup failed; target is likely on a local file system

Recovery Manager complete.


Could you please check the DB. Please inform us upon your findings.


We have modified parameter in RMAN tool so issue should be fixed now.

Please wait for next scheduled backup window and inform us in case of errors .



Best regards,
Aleksandar Mihov

Technology Supervisor iAction DB Team
Telephone: +359 0889820093
DXC Technology
Global Delivery Center Bulgaria, Business Park Sofia, Building 8, 
Sofia 1766, Bulgaria
dxc.technology



Hello Team,

Currently there is a successful backup session.

You can close the case.

Thank you!

Best regards,
Dimitar Svetozarov Draganchev
Backup and Storage Support
ITO Global Delivery
T +359 889 751 425
ITO-GDC-Bulgaria-SMS-BURS-RST@dxc.com

DXC Technology
Business Park Sofia, Building 9
Sofia 1766 Bulgaria
Enterprise Services Bulgaria



















