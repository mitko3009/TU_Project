


Quick Reference to Patch Numbers for Database PSU, SPU(CPU), Bundle Patches and Patchsets (Doc ID 1454618.1)


chfs -a size=+2G   /dev/WANDDB 

Filesystem    GB blocks      Free %Used    Iused %Iused Mounted on
/dev/XYST_RDBMS2     21.00      7.81   63%    48069     3% /xyst/intra/rdbms2


vgdisplay




lvextend -L +3G /dev/mapper/pizaval_dbsvg-PIZAVAL_DBS2
resize2fs -p /dev/mapper/pizaval_dbsvg-PIZAVAL_DBS2



 


df -g $ORACLE_HOME
df -h $ORACLE_HOME






	cd $ORACLE_HOME/../

	du -sh *
	df -h .


$ORACLE_HOME/OPatch/opatch util cleanup



-- rm $ORACLE_HOME/rdbms/audit/*.aud
-- rm $ORACLE_HOME/../diag/tnslsnr/*/listener_*/trace/*.log
-- rm $ORACLE_HOME/../diag/tnslsnr/*/listener_*/alert/*.xml


	cd $ORACLE_HOME/../

	du -sh *
	df -h .



du -sg *
df -g .



# Oracle RDBMS logs cleanup
00 06 * * * /home/oracle/cleanup.sh




sqlplus / as sysdba 



 @$ORACLE_HOME/rdbms/admin/utlrp.sql



alter system switch logfile ;



alter system checkpoint;




1.	Prerequisites 


9.5 GB free space in the ORACLE_HOME
900MB free space in SYSAUX

--- 2.	Create database backup
--- 
--- Mount the database;
--- Create cmd file
--- 
--- run
--- {
--- allocate channel d1 device type disk;
--- backup as compressed backupset format '/TAR/BACKUP/JUST_full_%d_%s_%t_%p.dbf' database tag 'BEFORE_UPGRADE';
--- backup format '/TAR/BACKUP/JUST_full_%d_%s_%t_%p.ctl' current controlfile tag 'BEFORE_UPGRADE';
--- release channel d1;
--- }
--- exit;
--- 
--- run the backup in nohup
--- nohup rman target / cmdfile='/TAR/BACKUP/JUSTBackup.cmd' log='/TAR/BACKUP/logJUSTBackup.log' &


set linesize 400
col PROGRAM for a45
col MACHINE for a9
col username for a10
col STATUS for a10
col SQL_ID for a20
col LOCKWAIT for a22
col SQL_ID for a30

col TO_CHAR(LOGON_TIME,'YYYY/MM/DDHH24:MI:SS') for a45
select sql_id,inst_id,SID,SERIAL#,STATUS,USERNAME,MACHINE,PROGRAM,to_char(LOGON_TIME, 'YYYY/MM/DD HH24:MI:SS') LOGON_TIME,LOCKWAIT from gv$session where status='ACTIVE' and  UserName IS NOT NULL order by inst_id, LOGON_TIME;



3.	Stop the database and listener



 sqlplus / as sysdba
 
shu immediate ;

exit;


lsnrctl stop listener_DUNE



lsnrctl stop listener_DUNE



4.	Installing the new OPatch utility



cd $ORACLE_HOME/OPatch 


unzip -d $ORACLE_HOME /TAR/PATCH/p6880880_122010_Linux-x86-64.zip
unzip -d $ORACLE_HOME /TAR/PATCH/p6880880_122010_AIX64-5L.zip
 
cd /TAR/PATCH



	$ORACLE_HOME/OPatch/opatch lsinv


5.	Check for conflicts 


cd /TAR/PATCH/


$ORACLE_HOME/OPatch/opatch prereq CheckConflictAgainstOHWithDetail -ph ./




6.	List inventory


	$ORACLE_HOME/OPatch/opatch lsinv



7.	Apply the PSU

 
 

cd /TAR/PATCH/



--- 28555193


$ORACLE_HOME/OPatch/opatch rollback -id 28555193

$ORACLE_HOME/OPatch/opatch rollback -id 32132362


$ORACLE_HOME/OPatch/opatch apply


$ORACLE_HOME/OPatch/opatch lsinv



$ORACLE_HOME/OPatch/opatch lspatches

8.	Check the inventory after installation


$ORACLE_HOME/OPatch/opatch lsinv



9.	Load Modified SQL Files into the Database


cd $ORACLE_HOME/OPatch

sqlplus / as sysdba

startup

 quit

./datapatch -verbose
 
10.	Check for invalid objects and recompile 


--$ORACLE_HOME/OPatch/opatch lsinv | grep 30994996



lsnrctl start listener_


	sqlplus / as sysdba



	@$ORACLE_HOME/rdbms/admin/utlrp.sql


--- PDB

cd $ORACLE_HOME/rdbms/admin
$ORACLE_HOME/perl/bin/perl $ORACLE_HOME/rdbms/admin/catcon.pl -n 1 -e -b utlrp -d $ORACLE_HOME/rdbms/admin utlrp.sql


--- 11.	In the dba_registry_sqlpatch view, verify the Status for the APPLY is "SUCCESS". For any other status, refer to the following My Oracle Support note for additional information and actions: Document 1609718.1 Datapatch Known Issues. 





	sqlplus / as sysdba



set lines 400
column OBJECT_NAME format a60
col owner for a10
SELECT OWNER,OBJECT_TYPE,OBJECT_NAME FROM DBA_OBJECTS WHERE STATUS= 'INVALID' order by 3 ;




set lines 400
col  VERSION for a20
col  FLAGS   for a10
col  ACTION  for a15
col  STATUS  for a25
col POST_LOGFILE  for a20 
col LOGFILE       for a20 
col ACTION_TIME   for a6
col DESCRIPTION   for a30
col BUNDLE_SERIES for a30
col BUNDLE_DATA         for a20                               XMLTYPE
col PATCH_DESCRIPTOR    for a20                               XMLTYPE
col PATCH_DIRECTORY     for a20                               BLOB

select PATCH_ID,ACTION,STATUS,INSTALL_ID,DESCRIPTION from dba_registry_sqlpatch ;


set lines 300
col COMP_NAME for a36
select comp_name,version,status from dba_registry;



set lines 400 pages 100
col ACTION_TIME     for a30
col ACTION          for a10
col NAMESPACE       for a10
col VERSION         for a10
col BUNDLE_SERIES   for a10
col COMMENTS        for a25
select * from dba_registry_history;





SET LINESIZE 100
COLUMN value FORMAT A60
SELECT value
FROM   v$diag_info
WHERE  name = 'Diag Trace';



lsnrctl start listener_







--- $ORACLE_HOME/rdbms/admin/dbmsgwmfix.sql












------------- Data Guard







---    START APPLY

startup nomount ;

ALTER DATABASE MOUNT STANDBY DATABASE;

ALTER DATABASE RECOVER MANAGED STANDBY DATABASE DISCONNECT FROM SESSION;




---stop apply
 ALTER DATABASE RECOVER MANAGED STANDBY DATABASE CANCEL;
 
 
 
-------------  CHECK the state




set lines 400

SELECT open_mode,database_role FROM v$database;

select PROCESS,STATUS, THREAD#,SEQUENCE#, BLOCK#, BLOCKS from v$managed_standby ;

 sELECT DATABASE_ROLE, DB_UNIQUE_NAME INSTANCE, OPEN_MODE, PROTECTION_MODE, PROTECTION_LEVEL, SWITCHOVER_STATUS FROM V$DATABASE;



select al.thrd "Thread", almax "Last Seq Received", lhmax "Last Seq Applied"
from (select thread# thrd, max(sequence#) almax
      from v$archived_log
      where resetlogs_change#=(select resetlogs_change# from v$database)
      group by thread#) al,
     (select thread# thrd, max(sequence#) lhmax
      from v$log_history
      where resetlogs_change#=(select resetlogs_change# from v$database)
      group by thread#) lh
where al.thrd = lh.thrd;




 
   RECOVER STANDBY DATABASE USING BACKUP CONTROLFILE UNTIL CANCEL;





-------


cms set_variable RDBMS_CLIENT_HOME=/gram/intra/rdbms_2/19.17
cms set_variable RDBMS_HOME=/gram/intra/rdbms_2/19.17
cms resolve_template
cms deploy_config $IMX_CLT/config/profile.dba
cms deploy_config $IMX_CLT/config/global.imx
cms deploy_config $IMX_CLT/config/listener.ora
. ~/.profile ; load_instance_conf.sh
start_instance.sh 