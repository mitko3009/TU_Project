/********************************************************************************
*********       E-mail subject: EFDE2DEV-1189
*********             Instance: PIZAMIG
*********          Description: 
Problem:
SQL gyxfhkm5zhgsh was provided as slow from PIZAMIG.

Analysis:
The problem in SQL gyxfhkm5zhgsh is that function ftr_decompte.isContractValid(D.refdoss) is called in the WHERE clause, which leads 
to calling the function for every row. This is bad from Performance point of view and is not recomendet by P&T team as you can see in 
point 2.4 in SQL_with_SLA_acceptable_performance document on Performance and Tuning wiki page.

Suggestion:
Please modify the query as it is shown in the New SQL section below.

*********               SQL_ID: gyxfhkm5zhgsh
*********      Program/Package: DeblocageFD batch
*********              Request: Anna-Mariya Ivanova 
*********               Author: Dimitar Dimitrov
********* Received e-mail date: 26/02/2024
*********      Resolution date: 27/02/2024
*********  Trace old file here: \\epox\specifs\performance\tmp\
*********  Trace new file here:
***********************************************************************************/

/********************************OLD SQL*******************************************/
SELECT  d.reffactor /* automatically injected */, D.refdoss                                             
  FROM g_dossier D, g_piece FC                               
 WHERE D.categdoss LIKE 'DECOMPTE%'                          
   AND ftr_decompte.isContractValid(D.refdoss) NOT IN (0, 2) 
   AND FC.refdoss = D.reflot                                 
   AND FC.typpiece = 'FACTORINGCRITERIA'                     
   AND FC.fg36 = 'O'                                         
    /* reffactor condition */
   AND d.reffactor IN ('A6006XIZ') 
   ORDER BY d.refdoss;
/********************************OLD SQL*******************************************/
/********************************OLD Metrics***************************************/
/*
Plan hash value: 136089522
-------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                     | Name                   | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers |
-------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT              |                        |      1 |        |     2 (100)|      0 |00:00:00.13 |   13181 |
|   1 |  NESTED LOOPS                 |                        |      1 |      1 |     2   (0)|      0 |00:00:00.13 |   13181 |
|   2 |   NESTED LOOPS                |                        |      1 |      1 |     2   (0)|      0 |00:00:00.13 |   13181 |
|*  3 |    TABLE ACCESS BY INDEX ROWID| G_DOSSIER              |      1 |      1 |     1   (0)|      0 |00:00:00.13 |   13181 |
|*  4 |     INDEX FULL SCAN           | DOS_REFDOSS_REFLOT_IDX |      1 |      2 |     1   (0)|    263 |00:00:00.13 |   12517 |
|*  5 |    INDEX RANGE SCAN           | PIE_REFDOSS            |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|*  6 |   TABLE ACCESS BY INDEX ROWID | G_PIECE                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
-------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   3 - filter(("D"."REFFACTOR"='A6006XIZ' AND "D"."CATEGDOSS" LIKE 'DECOMPTE%'))
   4 - filter(("D"."REFLOT" IS NOT NULL AND "FTR_DECOMPTE"."ISCONTRACTVALID"("D"."REFDOSS")<>0 AND
              "FTR_DECOMPTE"."ISCONTRACTVALID"("D"."REFDOSS")<>2))
   5 - access("FC"."REFDOSS"="D"."REFLOT" AND "FC"."TYPPIECE"='FACTORINGCRITERIA')
       filter("FC"."REFDOSS" IS NOT NULL)
   6 - filter("FC"."FG36"='O')      
*/
/********************************OLD Metrics***************************************/

/********************************New SQL*******************************************/
SELECT * FROM (   
SELECT  d.reffactor /* automatically injected */,
        D.refdoss,
        (select ftr_decompte.isContractValid(D.refdoss) from dual ) isContractValid                                          
  FROM g_dossier D, g_piece FC                               
 WHERE D.categdoss LIKE 'DECOMPTE%' 
   AND FC.refdoss = D.reflot                                 
   AND FC.typpiece = 'FACTORINGCRITERIA'                     
   AND FC.fg36 = 'O'                                         
    /* reffactor condition */
   AND d.reffactor IN ('A6006XIZ') 
   ORDER BY d.refdoss)
   WHERE isContractValid NOT IN (0, 2) ;
/********************************New SQL*******************************************/
/********************************New Metrics***************************************/
/*
Plan hash value: 2318661852
---------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation           | Name                      | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  |
---------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT    |                           |      1 |        |     5 (100)|      0 |00:00:00.02 |       9 |      2 |
|   1 |  FAST DUAL          |                           |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*  2 |  VIEW               |                           |      1 |      1 |     5  (20)|      0 |00:00:00.02 |       9 |      2 |
|   3 |   SORT ORDER BY     |                           |      1 |      1 |     5  (20)|      0 |00:00:00.02 |       9 |      2 |
|   4 |    NESTED LOOPS     |                           |      1 |      1 |     2   (0)|      0 |00:00:00.02 |       9 |      2 |
|*  5 |     INDEX SKIP SCAN | PIECE_TYP_DOSS_FG_IDX     |      1 |      1 |     1   (0)|      3 |00:00:00.02 |       4 |      2 |
|*  6 |     INDEX RANGE SCAN| G_DOSSIER_RL_CD_RD_RF_IDX |      3 |      1 |     1   (0)|      0 |00:00:00.01 |       5 |      0 |
---------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   2 - filter(("ISCONTRACTVALID"<>0 AND "ISCONTRACTVALID"<>2))
   5 - access("FC"."TYPPIECE"='FACTORINGCRITERIA' AND "FC"."FG36"='O')
       filter(("FC"."FG36"='O' AND "FC"."REFDOSS" IS NOT NULL))
   6 - access("FC"."REFDOSS"="D"."REFLOT" AND "D"."CATEGDOSS" LIKE 'DECOMPTE%' AND "D"."REFFACTOR"='A6006XIZ')
       filter(("D"."REFFACTOR"='A6006XIZ' AND "D"."REFLOT" IS NOT NULL AND "D"."CATEGDOSS" LIKE 'DECOMPTE%'))   
*/
/********************************New Metrics***************************************/

/********************************Index statistics**********************************/

/********************************Other SQLs****************************************/          
/*

*/ 
/********************************Other SQLs****************************************/              
