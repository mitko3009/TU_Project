/********************************************************************************
*********       E-mail subject: ABCLDEV-5214
*********             Instance: PROD
*********          Description: 
Problem:
SQL cty7gdkcmxw99 was considered as slow on ABC Leasing PROD.

Analysis:
The problem in cty7gdkcmxw99 was missing index on column refdoss_reqst on table t_leas_assets on PROD.
Because of that the query was executed with innapropriate execution plan.

Suggestion:
Please deliver index IDX_LEAS_ASSET_REFDOSS_REQST from refbg2 to PROD.

*********               SQL_ID: cty7gdkcmxw99
*********      Program/Package: 
*********              Request: Dimitare Ivanov
*********               Author: Dimitar Dimitrov
********* Received e-mail date: 04/01/2024
*********      Resolution date: 05/01/2024
*********  Trace old file here: \\epox\specifs\performance\tmp\
*********  Trace new file here:
***********************************************************************************/

/********************************OLD SQL*******************************************/
var refdos VARCHAR2(128);
exec :refdos := '1811230162';

select count(*)
  from g_telephone
 where typetel = 'EMAIL'
   and validite = 'O'
   and refindividu = (select refindividu
                        from t_intervenants
                       where refdoss = :refdos
                         and reftype = 'DB')
   and dtmaj_dt >
       (select max(max_dt)
          from (select max(dt_creation_dt) max_dt
                  from t_gps_track_serv
                 where refalloc in
                       (select imx_un_id
                          from t_leas_assets
                         where refdoss_reqst = :refdos)
                   and dt_fin_dt is null
                   and upper(communic_stat) = 'TRUE'
                union (select max(dtsaisie_dt) max_dt
                        from t_elements
                       where refdoss = :refdos
                         and libelle = 'RESSER EMAIL UPDATE')));
/********************************OLD SQL*******************************************/
/********************************OLD Metrics***************************************/
/*
Plan hash value: 1207388749
-----------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                  | Name             | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  |
-----------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                           |                  |      1 |        |    91 (100)|      1 |00:00:00.41 |   40829 |    763 |
|   1 |  SORT AGGREGATE                            |                  |      1 |      1 |            |      1 |00:00:00.41 |   40829 |    763 |
|*  2 |   TABLE ACCESS BY INDEX ROWID BATCHED      | G_TELEPHONE      |      1 |      1 |     1   (0)|      0 |00:00:00.41 |   40829 |    763 |
|*  3 |    INDEX RANGE SCAN                        | IDX_G_TEL_INDIV  |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       6 |      0 |
|*  4 |     INDEX RANGE SCAN                       | INT_REFDOSS      |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |      0 |
|   5 |    SORT AGGREGATE                          |                  |      1 |      1 |            |      1 |00:00:00.41 |   40822 |    763 |
|   6 |     VIEW                                   |                  |      1 |      2 |    89   (2)|      1 |00:00:00.41 |   40822 |    763 |
|   7 |      SORT UNIQUE                           |                  |      1 |      2 |    89   (2)|      1 |00:00:00.41 |   40822 |    763 |
|   8 |       UNION-ALL                            |                  |      1 |        |            |      2 |00:00:00.41 |   40822 |    763 |
|   9 |        SORT AGGREGATE                      |                  |      1 |      1 |    87   (0)|      1 |00:00:00.05 |   39821 |      0 |
|  10 |         NESTED LOOPS SEMI                  |                  |      1 |      1 |    87   (0)|      0 |00:00:00.05 |   39821 |      0 |
|* 11 |          TABLE ACCESS FULL                 | T_GPS_TRACK_SERV |      1 |    199 |    85   (0)|  19936 |00:00:00.01 |     374 |      0 |
|* 12 |          TABLE ACCESS BY INDEX ROWID       | T_LEAS_ASSETS    |  19834 |      1 |     1   (0)|      0 |00:00:00.04 |   39447 |      0 |
|* 13 |           INDEX UNIQUE SCAN                | PK_T_LEAS_ASSETS |  19834 |      1 |     1   (0)|  19834 |00:00:00.02 |   19508 |      0 |
|  14 |        SORT AGGREGATE                      |                  |      1 |      1 |     1   (0)|      1 |00:00:00.36 |    1001 |    763 |
|* 15 |         TABLE ACCESS BY INDEX ROWID BATCHED| T_ELEMENTS       |      1 |      1 |     1   (0)|      0 |00:00:00.36 |    1001 |    763 |
|* 16 |          INDEX RANGE SCAN                  | ELE_ELEMDOSS     |      1 |      1 |     1   (0)|   1707 |00:00:00.02 |      11 |      9 |
-----------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   2 - filter(("VALIDITE"='O' AND "DTMAJ_DT">))
   3 - access("REFINDIVIDU"= AND "TYPETEL"='EMAIL')
   4 - access("REFDOSS"=:REFDOS AND "REFTYPE"='DB')
  11 - filter((UPPER("COMMUNIC_STAT")='TRUE' AND "DT_FIN_DT" IS NULL))
  12 - filter("REFDOSS_REQST"=:REFDOS)
  13 - access("REFALLOC"="IMX_UN_ID")
  15 - filter("LIBELLE"='RESSER EMAIL UPDATE')
  16 - access("REFDOSS"=:REFDOS)
*/
/********************************OLD Metrics***************************************/

/********************************New SQL*******************************************/
-- No changes in the SQL text.
/********************************New SQL*******************************************/
/********************************New Metrics***************************************/
/*
Plan hash value: 432938138
-------------------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                    | Name                   | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  |
-------------------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                             |                        |      1 |        |     6 (100)|      1 |00:00:00.02 |      50 |      1 |
|   1 |  SORT AGGREGATE                              |                        |      1 |      1 |            |      1 |00:00:00.02 |      50 |      1 |
|*  2 |   TABLE ACCESS BY INDEX ROWID BATCHED        | G_TELEPHONE            |      1 |      1 |     1   (0)|      0 |00:00:00.02 |      50 |      1 |
|*  3 |    INDEX RANGE SCAN                          | IDX_G_TEL_INDIV        |      1 |      1 |     1   (0)|      4 |00:00:00.01 |       6 |      0 |
|*  4 |     INDEX RANGE SCAN                         | INT_REFDOSS            |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |      0 |
|   5 |    SORT AGGREGATE                            |                        |      1 |      1 |            |      1 |00:00:00.02 |      41 |      1 |
|   6 |     VIEW                                     |                        |      1 |      2 |     4  (25)|      1 |00:00:00.02 |      41 |      1 |
|   7 |      SORT UNIQUE                             |                        |      1 |      2 |     4  (25)|      1 |00:00:00.02 |      41 |      1 |
|   8 |       UNION-ALL                              |                        |      1 |        |            |      2 |00:00:00.02 |      41 |      1 |
|   9 |        SORT AGGREGATE                        |                        |      1 |      1 |     2   (0)|      1 |00:00:00.02 |      35 |      1 |
|  10 |         NESTED LOOPS                         |                        |      1 |      1 |     2   (0)|      0 |00:00:00.02 |      35 |      1 |
|  11 |          NESTED LOOPS                        |                        |      1 |      1 |     2   (0)|      0 |00:00:00.02 |      35 |      1 |
|  12 |           TABLE ACCESS BY INDEX ROWID BATCHED| T_LEAS_ASSETS          |      1 |      1 |     1   (0)|   1090 |00:00:00.01 |      27 |      0 |
|* 13 |            INDEX RANGE SCAN                  | TEST_DD_REFDOSS_REQST  |      1 |      1 |     1   (0)|   1090 |00:00:00.01 |       6 |      0 |
|* 14 |           INDEX RANGE SCAN                   | TGTS_REFALLOC_IDX      |   1090 |      1 |     1   (0)|      0 |00:00:00.02 |       8 |      1 |
|* 15 |          TABLE ACCESS BY INDEX ROWID         | T_GPS_TRACK_SERV       |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|  16 |        SORT AGGREGATE                        |                        |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       6 |      0 |
|  17 |         TABLE ACCESS BY INDEX ROWID BATCHED  | T_ELEMENTS             |      1 |      1 |     1   (0)|      0 |00:00:00.01 |       6 |      0 |
|* 18 |          INDEX RANGE SCAN                    | ELE_DOSS_TYP_ASSOC_LIB |      1 |      1 |     1   (0)|      0 |00:00:00.01 |       6 |      0 |
-------------------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   2 - filter(("VALIDITE"='O' AND "DTMAJ_DT">))
   3 - access("REFINDIVIDU"= AND "TYPETEL"='EMAIL')
   4 - access("REFDOSS"=:REFDOS AND "REFTYPE"='DB')
  13 - access("REFDOSS_REQST"=:REFDOS)
  14 - access("REFALLOC"="IMX_UN_ID")
  15 - filter((UPPER("COMMUNIC_STAT")='TRUE' AND "DT_FIN_DT" IS NULL))
  18 - access("REFDOSS"=:REFDOS AND "LIBELLE"='RESSER EMAIL UPDATE')
       filter("LIBELLE"='RESSER EMAIL UPDATE') 
*/
/********************************New Metrics***************************************/

/********************************Index statistics**********************************/

/********************************Other SQLs****************************************/          
/*

*/ 
/********************************Other SQLs****************************************/              
