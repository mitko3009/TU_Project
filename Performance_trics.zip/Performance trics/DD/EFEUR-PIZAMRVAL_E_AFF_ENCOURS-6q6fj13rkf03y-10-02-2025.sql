/********************************************************************************
*********       E-mail subject: EFEURDEV-6326
*********             Instance: PIZAMRVAL
*********          Description: 
Problem:
The processing of 250 invoices took over 1 hour on PIZAMRVAL.

Analysis:
From what we see in the ASH, SQL 6q6fj13rkf03y was responsible for 9% of the time of the service_bus. The problem in its execution plan is that it is making INDEX FULL SCAN on REFHIERARCHIE_IDX index.
This is because several G_DOSSIER tables are joined in nested IN operators, which doesn't allow Oracle to choose good path. The solution here is to move the tables from the IN operators to the main
FROM clause and join them directly.

Suggestion: 
Please change SQL 6q6fj13rkf03y as it is shown in the New SQL section below.

*********               SQL_ID: 6q6fj13rkf03y
*********      Program/Package: 
*********              Request: Antoniya Stoyanova
*********               Author: Dimitar Dimitrov
********* Received e-mail date: 06/02/2025
*********      Resolution date: 10/02/2025
*********  Trace old file here: \\epox\specifs\performance\tmp\
*********  Trace new file here:
***********************************************************************************/

/********************************OLD SQL*******************************************/

-- 6q6fj13rkf03y

var B1 VARCHAR2(128);
exec :B1 := '2502100001';

SELECT REFDOSS
  FROM G_DOSSIER
 WHERE (    CATEGDOSS = 'COMPTE DB CTR' 
        OR CATEGDOSS LIKE 'CONTRAT%' )
   AND REFDOSS IN ( SELECT REFLOT
                      FROM G_DOSSIER
                     WHERE CATEGDOSS LIKE 'DECOMPTE%'
                       AND REFDOSS IN ( SELECT REFLOT 
                                          FROM G_DOSSIER 
                                         WHERE REFDOSS = :B1 ) );
/********************************OLD SQL*******************************************/
/********************************OLD Metrics***************************************/
/*
MODULE                           PROGRAM                                            CLIENT_ID       SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- -------------------------------------------------- --------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
service_bus_server_4BACB2C63144E service_bus_server                                 tania                                  0                                            2025/02/07 16:42:15  2025/02/07 16:53:09         85                     1 +000000000 00:10:54.485 17%
89B07E15B5F60D53818

service_bus_server_4BACB2C63144E service_bus_server                                 tania           6q6fj13rkf03y                                  ON CPU               2025/02/07 16:42:13  2025/02/07 16:52:57         45                  7778 +000000000 00:10:44.479 9%
89B07E15B5F60D53818

service_bus_server_4BACB2C63144E service_bus_server                                 tania           d16rgw4vvmj9k          0                                            2025/02/07 16:44:31  2025/02/07 16:52:39         28                  3021 +000000000 00:08:08.371 6%
89B07E15B5F60D53818

service_bus_server_4BACB2C63144E service_bus_server                                 tania           aq44g9kx5utc4          0                       ON CPU               2025/02/07 16:42:20  2025/02/07 16:53:07         24                  3921 +000000000 00:10:47.481 5%
89B07E15B5F60D53818

service_bus_server_4BACB2C63144E service_bus_server                                 tania           11zjh1181uc0u 1179845177                       ON CPU               2025/02/07 16:44:12  2025/02/07 16:53:11         24                155525 +000000000 00:08:59.408 5%
89B07E15B5F60D53818

service_bus_server_4BACB2C63144E service_bus_server                                 tania           gnbgkhp12jvgp          0                       ON CPU               2025/02/07 16:42:52  2025/02/07 16:53:10         13                  3761 +000000000 00:10:18.461 3%
89B07E15B5F60D53818

service_bus_server_4BACB2C63144E service_bus_server                                 tania           c371wgrtwp4c7 3762729752                                            2025/02/07 16:42:10  2025/02/07 16:52:14         11                  3622 +000000000 00:10:04.451 2%
89B07E15B5F60D53818

service_bus_server_4BACB2C63144E service_bus_server                                 tania           49pjn3rs8706j 1388734953                       ON CPU               2025/02/07 16:42:21  2025/02/07 16:50:02         10                 10926 +000000000 00:07:41.357 2%



Plan hash value: 2520868297
-----------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                      | Name                   | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  |
-----------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT               |                        |      1 |        |     3 (100)|      1 |00:00:00.11 |     129 |    103 |
|*  1 |  HASH JOIN RIGHT SEMI          |                        |      1 |      1 |     3   (0)|      1 |00:00:00.11 |     129 |    103 |
|   2 |   VIEW                         | VW_NSO_1               |      1 |      1 |     2   (0)|      1 |00:00:00.01 |       5 |      0 |
|   3 |    NESTED LOOPS                |                        |      1 |      1 |     2   (0)|      1 |00:00:00.01 |       5 |      0 |
|   4 |     NESTED LOOPS               |                        |      1 |      1 |     2   (0)|      1 |00:00:00.01 |       4 |      0 |
|*  5 |      INDEX RANGE SCAN          | DOS_REFDOSS_REFLOT_IDX |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       2 |      0 |
|*  6 |      INDEX UNIQUE SCAN         | DOS_REFDOSS            |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       2 |      0 |
|*  7 |     TABLE ACCESS BY INDEX ROWID| G_DOSSIER              |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       1 |      0 |
|*  8 |   INDEX FULL SCAN              | REFHIERARCHIE_IDX      |      1 |   2734 |     1   (0)|   8114 |00:00:00.10 |     124 |    103 |
-----------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   1 - access("REFDOSS"="REFLOT")
   5 - access("REFDOSS"=:B1)
       filter("REFLOT" IS NOT NULL)
   6 - access("REFDOSS"="REFLOT")
   7 - filter("CATEGDOSS" LIKE 'DECOMPTE%')
   8 - filter(("CATEGDOSS"='COMPTE DB CTR' OR "CATEGDOSS" LIKE 'CONTRAT%'))

*/
/********************************OLD Metrics***************************************/

/********************************New SQL*******************************************/

SELECT CTR.REFDOSS
  FROM G_DOSSIER CTR,
       G_DOSSIER CMT,
       G_DOSSIER DCMP
       
 WHERE (   CTR.CATEGDOSS = 'COMPTE DB CTR' 
        OR CTR.CATEGDOSS LIKE 'CONTRAT%' )
   AND CTR.REFDOSS = DCMP.REFLOT
   AND DCMP.CATEGDOSS LIKE 'DECOMPTE%'
   AND DCMP.REFDOSS = CMT.REFLOT 
   AND CMT.REFDOSS = :B1;
/********************************New SQL*******************************************/
/********************************New Metrics***************************************/
/*
Plan hash value: 1636365153
--------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                      | Name                   | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers |
--------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT               |                        |      1 |        |     3 (100)|      1 |00:00:00.01 |       9 |
|   1 |  NESTED LOOPS                  |                        |      1 |      1 |     3   (0)|      1 |00:00:00.01 |       9 |
|   2 |   NESTED LOOPS                 |                        |      1 |      1 |     3   (0)|      1 |00:00:00.01 |       8 |
|   3 |    NESTED LOOPS                |                        |      1 |      1 |     2   (0)|      1 |00:00:00.01 |       6 |
|*  4 |     INDEX RANGE SCAN           | DOS_REFDOSS_REFLOT_IDX |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |
|*  5 |     TABLE ACCESS BY INDEX ROWID| G_DOSSIER              |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |
|*  6 |      INDEX UNIQUE SCAN         | DOS_REFDOSS            |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       2 |
|*  7 |    INDEX UNIQUE SCAN           | DOS_REFDOSS            |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       2 |
|*  8 |   TABLE ACCESS BY INDEX ROWID  | G_DOSSIER              |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       1 |
--------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   4 - access("CMT"."REFDOSS"=:B1)
       filter("CMT"."REFLOT" IS NOT NULL)
   5 - filter(("DCMP"."REFLOT" IS NOT NULL AND "DCMP"."CATEGDOSS" LIKE 'DECOMPTE%'))
   6 - access("DCMP"."REFDOSS"="CMT"."REFLOT")
   7 - access("CTR"."REFDOSS"="DCMP"."REFLOT")
   8 - filter(("CTR"."CATEGDOSS"='COMPTE DB CTR' OR "CTR"."CATEGDOSS" LIKE 'CONTRAT%'))
*/
/********************************New Metrics***************************************/

/********************************Index statistics**********************************/

/********************************Other SQLs****************************************/          
/*

*/ 
/********************************Other SQLs****************************************/              
