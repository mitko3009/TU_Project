/********************************************************************************
*********       E-mail subject: IMBDEV-11884
*********             Instance: PROD
*********          Description: 
Problem:
SQL 0bfz0hwhrm035 was provided from PROD as slow.

Analysis:
When we manually executed the SQL, we found that the problem comes because in the execution plan, the query access table G_PIECE through index PIECE_TYP_MT43_IDX, which 
leads to selecting a lot of roww. The better variant here is to access table G_PIECE through index IDX_FACTURE_LIBELLE_20_9 on column LIBELLE_20_9 || '' which is much more selective.
This index exists on refbg2 and ivka, so it should be delivered to PROD and in the SQL text should be added || '' to column LIBELLE_20_9 to use index IDX_FACTURE_LIBELLE_20_9.

Suggestion:
Please modify the query as it is shown in the New SQL section below.

*********               SQL_ID: 0bfz0hwhrm035
*********      Program/Package: 
*********              Request: Valeri Tsvetanov
*********               Author: Dimitar Dimitrov
********* Received e-mail date: 12/03/2024
*********      Resolution date: 12/03/2023
*********  Trace old file here: \\epox\specifs\performance\tmp\
*********  Trace new file here:
***********************************************************************************/

/********************************OLD SQL*******************************************/
var B5 VARCHAR2(32);
exec :B5 := 'A400G0AP'
var B0 VARCHAR2(32);
exec :B0 := 'AL'
var B2 NUMBER;
exec :B2 := 1;

SELECT DISTINCT LISTAGG((DECODE(:b0,
                                'FR',
                                REASON.CHEMIN,
                                'AL',
                                REASON.CHEMIN_AL,
                                'NL',
                                REASON.CHEMIN_NL,
                                'RO',
                                REASON.CHEMIN_RO,
                                'ES',
                                REASON.CHEMIN_ES,
                                'PT',
                                REASON.CHEMIN_PT,
                                REASON.CHEMIN_AN)),
                        chr(13) || chr(10) || chr(13) || chr(10)) WITHIN GROUP(ORDER BY(DECODE(:b0, 'FR', REASON . CHEMIN, 'AL', REASON . CHEMIN_AL, 'NL', REASON . CHEMIN_NL, 'RO', REASON . CHEMIN_RO, 'ES', REASON . CHEMIN_ES, 'PT', REASON . CHEMIN_PT,
                
                REASON . CHEMIN_AN))) as REJECTIONREASON,
                MAX(CASE
                      WHEN FAC.STR_20_2 IS NULL THEN
                       PTF.UNKNOWN_DEBTOR
                      ELSE
                       (SELECT NOM
                          FROM G_INDIVIDU
                         WHERE REFINDIVIDU = FAC.STR_20_2)
                    END) AS BUYER,
                FI . MONTANT_MVT AS AMOUNT,
                FI . DEVISE_MVT AS CURRENCY,
                MAX(CASE
                      WHEN :b2 = 1 THEN
                       TO_CHAR(FI.DT_EMIS_DT, 'dd.mm.yyyy')
                      ELSE
                       TO_CHAR(FI.DT_EMIS_DT, 'dd/mm/yyyy')
                    END) AS ISSUEDATE,
                MAX(CASE
                      WHEN :b2 = 1 THEN
                       TO_CHAR(FI.DTDEBUT_DT, 'dd.mm.yyyy')
                      ELSE
                       TO_CHAR(FI.DTDEBUT_DT,'dd/mm/yyyy')
                    END) AS DUEDATE,
                FI . REFEXT AS DOCNUMBER,
                MAX(DECODE(:b0,
                           'AN',
                           V.VALEUR_AN,
                           'AL',
                           V.VALEUR_AL,
                           'ES',
                           V.VALEUR_ES,
                           'FR',
                           V.VALEUR_FR,
                           'RO',
                           V.VALEUR_RO,
                           'PT',
                           V.VALEUR_PT,
                           V.VALEUR_AN)) AS DOCTYPE,
                FI.REFELEM as FinancialElement,
                PTF.CLIENT_NUM as CLCLNum,
                MAX(V.VALEUR)
  FROM G_PIECE FAC,
       G_ELEMFI FI,
       V_DOMAINE V,
       V_DOMAINE REASON,
       G_DB_PTF_ITEM PTF,
       (SELECT DISTINCT A.TYPENCOUR,
                        FI_ALERT.REFEXT,
                        FI_ALERT.REFELEM,
                        A.REFENTITE
          FROM G_ELEMFI FI_ALERT, 
               T_ALERTE A
         WHERE A.TYPENTITE = 'F'
           AND A.REFENTITE = FI_ALERT.REFELEM
        UNION
        SELECT DISTINCT HA.TYPENCOUR,
                        FI_ALERT.REFEXT,
                        FI_ALERT.REFELEM,
                        HA.REFENTITE
          FROM G_ELEMFI FI_ALERT, 
               H_ALERTE HA
         WHERE HA.TYPENTITE = 'F'
           AND HA.REFENTITE = FI_ALERT.REFELEM) ALERTS
 WHERE FAC.TYPPIECE = 'FACTURE'
   AND FAC.LIBELLE_20_9 = :b5
   AND FI.REFPIECE2 = FAC.REFPIECE
   AND FI.TYPE = V.VALEUR
   AND V.TYPE = 'DV_DOC_TYPE'
   AND ALERTS.TYPENCOUR IN (REASON.VALEUR)
   AND REASON.TYPE = 'fact_rej_reason'
   AND ALERTS.REFENTITE = FI.REFELEM
   AND FI.REFELEM = PTF.REFELEM
 GROUP BY FI .MONTANT_MVT,
          FI .DEVISE_MVT,
          FI.REFEXT,
          FI.REFELEM,
          PTF.CLIENT_NUM;
/********************************OLD SQL*******************************************/
/********************************OLD Metrics***************************************/
/*
Plan hash value: 7002210
--------------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                   | Name               | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  |
--------------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                            |                    |      1 |        |  1111 (100)|      0 |00:03:05.26 |     767K|  84723 |
|   1 |  TABLE ACCESS BY INDEX ROWID                | G_INDIVIDU         |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*  2 |   INDEX UNIQUE SCAN                         | IND_REFINDIV       |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|   3 |  SORT GROUP BY                              |                    |      1 |      1 |  1111   (3)|      0 |00:03:05.26 |     767K|  84723 |
|   4 |   NESTED LOOPS                              |                    |      1 |      1 |  1109   (2)|      0 |00:03:05.26 |     767K|  84723 |
|   5 |    NESTED LOOPS                             |                    |      1 |      1 |  1108   (2)|      0 |00:03:05.26 |     767K|  84723 |
|   6 |     NESTED LOOPS                            |                    |      1 |     17 |  1107   (2)|      0 |00:03:05.26 |     767K|  84723 |
|   7 |      NESTED LOOPS                           |                    |      1 |     21 |  1002   (1)|      0 |00:03:05.26 |     767K|  84723 |
|   8 |       NESTED LOOPS                          |                    |      1 |     22 |  1001   (1)|      0 |00:03:05.26 |     767K|  84723 |
|*  9 |        TABLE ACCESS BY INDEX ROWID BATCHED  | G_PIECE            |      1 |     22 |  1000   (1)|      0 |00:03:05.26 |     767K|  84723 |
|* 10 |         INDEX RANGE SCAN                    | PIECE_TYP_MT43_IDX |      1 |    481K|    21   (5)|    481K|00:00:12.35 |    1595 |   1593 |
|  11 |        TABLE ACCESS BY INDEX ROWID BATCHED  | G_ELEMFI           |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 12 |         INDEX RANGE SCAN                    | EFI_REFPIECE2      |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|  13 |       TABLE ACCESS BY INDEX ROWID BATCHED   | V_DOMAINE          |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 14 |        INDEX RANGE SCAN                     | DOM_TYPVAL         |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|  15 |      VIEW                                   |                    |      0 |      1 |     5  (20)|      0 |00:00:00.01 |       0 |      0 |
|  16 |       SORT UNIQUE                           |                    |      0 |      2 |     5  (20)|      0 |00:00:00.01 |       0 |      0 |
|  17 |        UNION ALL PUSHED PREDICATE           |                    |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  18 |         NESTED LOOPS                        |                    |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|  19 |          TABLE ACCESS BY INDEX ROWID        | G_ELEMFI           |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 20 |           INDEX UNIQUE SCAN                 | EFI_REFELEM        |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|  21 |          TABLE ACCESS BY INDEX ROWID BATCHED| T_ALERTE           |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 22 |           INDEX RANGE SCAN                  | AL_TYPE_REFENTITE  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|  23 |         NESTED LOOPS                        |                    |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|  24 |          TABLE ACCESS BY INDEX ROWID        | G_ELEMFI           |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 25 |           INDEX UNIQUE SCAN                 | EFI_REFELEM        |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 26 |          TABLE ACCESS BY INDEX ROWID BATCHED| H_ALERTE           |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 27 |           INDEX RANGE SCAN                  | ALH_REFENTITE      |      0 |     18 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|  28 |     TABLE ACCESS BY INDEX ROWID BATCHED     | V_DOMAINE          |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 29 |      INDEX RANGE SCAN                       | DOM_TYPVAL         |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|  30 |    TABLE ACCESS BY INDEX ROWID              | G_DB_PTF_ITEM      |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 31 |     INDEX UNIQUE SCAN                       | PK_G_DB_PTF_ITEM   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
--------------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   2 - access("REFINDIVIDU"=:B1)
   9 - filter("FAC"."LIBELLE_20_9"=:B5)
  10 - access("FAC"."TYPPIECE"='FACTURE')
  12 - access("FI"."REFPIECE2"="FAC"."REFPIECE")
  14 - access("FI"."TYPE"="V"."VALEUR" AND "V"."TYPE"='DV_DOC_TYPE')
  20 - access("FI_ALERT"."REFELEM"="FI"."REFELEM")
  22 - access("A"."TYPENTITE"='F' AND "A"."REFENTITE"="FI"."REFELEM")
       filter("A"."REFENTITE"="FI_ALERT"."REFELEM")
  25 - access("FI_ALERT"."REFELEM"="FI"."REFELEM")
  26 - filter("HA"."TYPENTITE"='F')
  27 - access("HA"."REFENTITE"="FI"."REFELEM")
       filter("HA"."REFENTITE"="FI_ALERT"."REFELEM")
  29 - access("ALERTS"."TYPENCOUR"="REASON"."VALEUR" AND "REASON"."TYPE"='fact_rej_reason')
  31 - access("FI"."REFELEM"="PTF"."REFELEM")          
*/
/********************************OLD Metrics***************************************/

/********************************New SQL*******************************************/

SELECT DISTINCT LISTAGG((DECODE(:b0,
                                'FR',
                                REASON.CHEMIN,
                                'AL',
                                REASON.CHEMIN_AL,
                                'NL',
                                REASON.CHEMIN_NL,
                                'RO',
                                REASON.CHEMIN_RO,
                                'ES',
                                REASON.CHEMIN_ES,
                                'PT',
                                REASON.CHEMIN_PT,
                                REASON.CHEMIN_AN)),
                        chr(13) || chr(10) || chr(13) || chr(10)) WITHIN GROUP(ORDER BY(DECODE(:b0, 'FR', REASON . CHEMIN, 'AL', REASON . CHEMIN_AL, 'NL', REASON . CHEMIN_NL, 'RO', REASON . CHEMIN_RO, 'ES', REASON . CHEMIN_ES, 'PT', REASON . CHEMIN_PT,
                
                REASON . CHEMIN_AN))) as REJECTIONREASON,
                MAX(CASE
                      WHEN FAC.STR_20_2 IS NULL THEN
                       PTF.UNKNOWN_DEBTOR
                      ELSE
                       (SELECT NOM
                          FROM G_INDIVIDU
                         WHERE REFINDIVIDU = FAC.STR_20_2)
                    END) AS BUYER,
                FI . MONTANT_MVT AS AMOUNT,
                FI . DEVISE_MVT AS CURRENCY,
                MAX(CASE
                      WHEN :b2 = 1 THEN
                       TO_CHAR(FI.DT_EMIS_DT, 'dd.mm.yyyy')
                      ELSE
                       TO_CHAR(FI.DT_EMIS_DT, 'dd/mm/yyyy')
                    END) AS ISSUEDATE,
                MAX(CASE
                      WHEN :b2 = 1 THEN
                       TO_CHAR(FI.DTDEBUT_DT, 'dd.mm.yyyy')
                      ELSE
                       TO_CHAR(FI.DTDEBUT_DT,'dd/mm/yyyy')
                    END) AS DUEDATE,
                FI . REFEXT AS DOCNUMBER,
                MAX(DECODE(:b0,
                           'AN',
                           V.VALEUR_AN,
                           'AL',
                           V.VALEUR_AL,
                           'ES',
                           V.VALEUR_ES,
                           'FR',
                           V.VALEUR_FR,
                           'RO',
                           V.VALEUR_RO,
                           'PT',
                           V.VALEUR_PT,
                           V.VALEUR_AN)) AS DOCTYPE,
                FI.REFELEM as FinancialElement,
                PTF.CLIENT_NUM as CLCLNum,
                MAX(V.VALEUR)
  FROM G_PIECE FAC,
       G_ELEMFI FI,
       V_DOMAINE V,
       V_DOMAINE REASON,
       G_DB_PTF_ITEM PTF,
       (SELECT DISTINCT A.TYPENCOUR,
                        FI_ALERT.REFEXT,
                        FI_ALERT.REFELEM,
                        A.REFENTITE
          FROM G_ELEMFI FI_ALERT, 
               T_ALERTE A
         WHERE A.TYPENTITE = 'F'
           AND A.REFENTITE = FI_ALERT.REFELEM
        UNION
        SELECT DISTINCT HA.TYPENCOUR,
                        FI_ALERT.REFEXT,
                        FI_ALERT.REFELEM,
                        HA.REFENTITE
          FROM G_ELEMFI FI_ALERT, 
               H_ALERTE HA
         WHERE HA.TYPENTITE = 'F'
           AND HA.REFENTITE = FI_ALERT.REFELEM) ALERTS
 WHERE FAC.TYPPIECE = 'FACTURE'
   AND FAC.LIBELLE_20_9 ||'' = :b5
   AND FI.REFPIECE2 = FAC.REFPIECE
   AND FI.TYPE = V.VALEUR
   AND V.TYPE = 'DV_DOC_TYPE'
   AND ALERTS.TYPENCOUR = REASON.VALEUR
   AND REASON.TYPE = 'fact_rej_reason'
   AND ALERTS.REFENTITE = FI.REFELEM
   AND FI.REFELEM = PTF.REFELEM
 GROUP BY FI .MONTANT_MVT,
          FI .DEVISE_MVT,
          FI.REFEXT,
          FI.REFELEM,
          PTF.CLIENT_NUM;
/********************************New SQL*******************************************/
/********************************New Metrics***************************************/
/*
Plan hash value: 2956177461
------------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                    | Name                     | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers |
------------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                             |                          |      1 |        |    12 (100)|      0 |00:00:00.01 |       2 |
|   1 |  TABLE ACCESS BY INDEX ROWID                 | G_INDIVIDU               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|*  2 |   INDEX UNIQUE SCAN                          | IND_REFINDIV             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|   3 |  SORT GROUP BY                               |                          |      1 |      1 |    12  (17)|      0 |00:00:00.01 |       2 |
|   4 |   NESTED LOOPS                               |                          |      1 |      1 |    10  (10)|      0 |00:00:00.01 |       2 |
|   5 |    NESTED LOOPS                              |                          |      1 |      1 |     9  (12)|      0 |00:00:00.01 |       2 |
|   6 |     NESTED LOOPS                             |                          |      1 |      1 |     8  (13)|      0 |00:00:00.01 |       2 |
|   7 |      NESTED LOOPS                            |                          |      1 |      1 |     7  (15)|      0 |00:00:00.01 |       2 |
|   8 |       NESTED LOOPS                           |                          |      1 |      1 |     2   (0)|      0 |00:00:00.01 |       2 |
|*  9 |        TABLE ACCESS BY INDEX ROWID BATCHED   | G_PIECE                  |      1 |      1 |     1   (0)|      0 |00:00:00.01 |       2 |
|* 10 |         INDEX RANGE SCAN                     | IDX_FACTURE_LIBELLE_20_9 |      1 |     49 |     1   (0)|      0 |00:00:00.01 |       2 |
|  11 |        TABLE ACCESS BY INDEX ROWID BATCHED   | G_ELEMFI                 |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 12 |         INDEX RANGE SCAN                     | EFI_REFPIECE2            |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|  13 |       VIEW                                   |                          |      0 |      1 |     5  (20)|      0 |00:00:00.01 |       0 |
|  14 |        SORT UNIQUE                           |                          |      0 |      2 |     5  (20)|      0 |00:00:00.01 |       0 |
|  15 |         UNION ALL PUSHED PREDICATE           |                          |      0 |        |            |      0 |00:00:00.01 |       0 |
|  16 |          NESTED LOOPS                        |                          |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |
|  17 |           TABLE ACCESS BY INDEX ROWID        | G_ELEMFI                 |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 18 |            INDEX UNIQUE SCAN                 | EFI_REFELEM              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|  19 |           TABLE ACCESS BY INDEX ROWID BATCHED| T_ALERTE                 |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 20 |            INDEX RANGE SCAN                  | AL_TYPE_REFENTITE        |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|  21 |          NESTED LOOPS                        |                          |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |
|  22 |           TABLE ACCESS BY INDEX ROWID        | G_ELEMFI                 |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 23 |            INDEX UNIQUE SCAN                 | EFI_REFELEM              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|  24 |           TABLE ACCESS BY INDEX ROWID BATCHED| H_ALERTE                 |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 25 |            INDEX RANGE SCAN                  | ALH_TYPE_REFENTITE       |      0 |      8 |     1   (0)|      0 |00:00:00.01 |       0 |
|  26 |      TABLE ACCESS BY INDEX ROWID             | G_DB_PTF_ITEM            |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 27 |       INDEX UNIQUE SCAN                      | PK_G_DB_PTF_ITEM         |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|  28 |     TABLE ACCESS BY INDEX ROWID BATCHED      | V_DOMAINE                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 29 |      INDEX RANGE SCAN                        | DOM_TYPVAL               |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |
|  30 |    TABLE ACCESS BY INDEX ROWID BATCHED       | V_DOMAINE                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 31 |     INDEX RANGE SCAN                         | DOM_TYPVAL               |      0 |      2 |     1   (0)|      0 |00:00:00.01 |       0 |
------------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   2 - access("REFINDIVIDU"=:B1)
   9 - filter("FAC"."TYPPIECE"='FACTURE')
  10 - access("FAC"."SYS_NC00795$"=:B5)
  12 - access("FI"."REFPIECE2"="FAC"."REFPIECE")
       filter("FI"."REFPIECE2" IS NOT NULL)
  18 - access("FI_ALERT"."REFELEM"="FI"."REFELEM")
  20 - access("A"."TYPENTITE"='F' AND "A"."REFENTITE"="FI"."REFELEM")
       filter("A"."REFENTITE"="FI_ALERT"."REFELEM")
  23 - access("FI_ALERT"."REFELEM"="FI"."REFELEM")
  25 - access("HA"."TYPENTITE"='F' AND "HA"."REFENTITE"="FI"."REFELEM")
       filter("HA"."REFENTITE"="FI_ALERT"."REFELEM")
  27 - access("FI"."REFELEM"="PTF"."REFELEM")
  29 - access("FI"."TYPE"="V"."VALEUR" AND "V"."TYPE"='DV_DOC_TYPE')
  31 - access("ALERTS"."TYPENCOUR"="REASON"."VALEUR" AND "REASON"."TYPE"='fact_rej_reason')          
*/
/********************************New Metrics***************************************/

/********************************Index statistics**********************************/

/********************************Other SQLs****************************************/          
/*

*/ 
/********************************Other SQLs****************************************/              
