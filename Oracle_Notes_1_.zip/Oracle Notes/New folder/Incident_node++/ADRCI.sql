##################### ADRCI #######################

SQL> show parameter diag

NAME                                 TYPE        VALUE
------------------------------------ ----------- ------------------------------
diagnostic_dest                      string      /disk1/prod/diag

as oracle user:
adrci

adrci> show tracefiles
     diag/diag/rdbms/prod/PROD/trace/PROD_mman_5074.trc
     diag/diag/rdbms/prod/PROD/trace/PROD_vktm_4932.trc
ako iskam da procheta posledniqt tracefile trqbva da zadam pylniqt pyt :

adrci> show trace /disk1/prod/diag/diag/rdbms/prod/prod/trace/prod_ora_5582.trc


Output the results to file: /tmp/utsout_6802_140630_4.ado
/disk1/prod/diag/diag/rdbms/prod/prod/trace/prod_ora_5582.trc
----------------------------------------------------------
LEVEL PAYLOAD                                                                                                                                   
----- ------------------------------------------------------------------------------------------------------------------------------------------------
      Trace file /disk1/prod/diag/diag/rdbms/prod/prod/trace/prod_ora_5582.trc
      Oracle Database 11g Enterprise Edition Release 11.2.0.1.0 - 64bit Production
      With the Partitioning, OLAP, Data Mining and Real Application Testing options
      ORACLE_HOME = /u01/app/oracle/product/11.2.0
      System name:      Linux
      Node name:        linux.oracle
      Release:  2.6.32-200.13.1.el5uek
      Version:  #1 SMP Wed Jul 27 21:02:33 EDT 2011
      Machine:  x86_64
      Instance name: prod
      Redo thread mounted by this instance: 0 <none>
      Oracle process number: 17
      Unix process pid: 5582, image: oracle@linux.oracle (TNS V1-V3)


      *** 2019-10-26 15:38:06.639
      *** SESSION ID:(18.7) 2019-10-26 15:38:06.639
      *** CLIENT ID:() 2019-10-26 15:38:06.639
      *** SERVICE NAME:() 2019-10-26 15:38:06.639
      *** MODULE NAME:(sqlplus@linux.oracle (TNS V1-V3)) 2019-10-26 15:38:06.639
      *** ACTION NAME:() 2019-10-26 15:38:06.639

      Control file created with size 478 blocks

........................
ESC+:q!   za da izlezna ot trace file-a








=========================================================================================================
HOW TO CREATE AN INCIDENT PACKAGE FOR ORACLE SUPPORT

AS USER ORACLE:

ADRCI> SHOW PROBLEM

1    ORA 4031      3913    2012-02-22 03:18:04.677000 +01:00


SHTE VIJDAM PROBELM_ID AND PROBLEM_KEY
            
			1				ORA -600

ADRCI> SHOW INCIDENT    --- ZA DA VIDIM KAKVI I KOLKO INCIDENTI E IMALO S TAZI GRESHKA ORA-600

adrci>show incident

shte ima nomer na incident 


ADRCI> show incident -mode detail -p "incident_id=18500"  -- shte ni pokaje detailna informaciq povechetoot koqto

nie nqma da razberem no Oracle Support - shte;
shte se vijda pole PROBELM_ID     (NAPRIMER) 1

SLEDVA CREATE-VANETO NA PACKAGE

IPS= INCIDENT PACKAGE SERVICE  s dolnata komanda shte create-nem paket s problema ni za kym Oracle:

adrci> ips create package problem 1 correlate all
Created package 1 based on problem id 1 correlation level all


adrci>ips generate package 1 in "/u01"
Generated package 1 in file /u01/ORA600krh_20170504203117_com_1.zip, mode complete	

adrci>exit

cd /u01
ls -larth  --- i goresyzdadeniqt file shte e tuk prehvyrlqmi si go na nashiqt comp i go prashtame na Oracle Support



