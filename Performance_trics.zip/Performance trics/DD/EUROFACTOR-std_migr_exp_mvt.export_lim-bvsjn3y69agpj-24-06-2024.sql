/********************************************************************************
*********       E-mail subject: EFAGDEV-3429
*********             Instance: UAT1
*********          Description: 
Problem:
On 20/04/2024, the std_migr_exp_mvt.export_lim continued for more than 6 hours, were previous runs it took no more than 2 hours.

Analysis:
We analyzed the work of std_migr_exp_mvt.export_lim on 20/04 on UAT1 and found that each of the first 2 TOP SQLs were responsible for 33% of the time and
the third and the forth TOP SQLs were responsible for 13% and 14% of the time. The first two TOP SQLs bvsjn3y69agpj and 38ha8n6qcujy1 have similar problem.
They were doing bad execution plan because of two reasons. The first reason is not appropriate order of accessing the tables and the second reason is missing
index on column STR_20_1 on table G_PIECE. We rewrite the queries as it is shown in the New SQL section below, so please ask DBA to deliver the missing index
and change the SQL texts as it is shown in the New SQL section below. For the third and the forth TOP SQLs dp0wqkw36y71c and 3adwztmazcsku, the problem is
that there is no index through which to access table STD_MIGR_LIM and this two queries makes full scan of table STD_MIGR_LIM. The solution here is to create index
on column LIMIT_REF on table STD_MIGR_LIM.

Suggestion:
1. Please ask DBA to deliver the index on column STR_20_1 on table G_PIECE from refbg2 to UAT1.
2. Please rewrite SQLs bvsjn3y69agpj and 38ha8n6qcujy1 as it is shown in the New SQL section below.
3. For SQLs dp0wqkw36y71c and 3adwztmazcsku should be created index on column LIMIT_REF on table STD_MIGR_LIM, so please ask C&D or the team responsible for it to create index on this column.

*********               SQL_ID: bvsjn3y69agpj, 38ha8n6qcujy1, dp0wqkw36y71c, 3adwztmazcsku
*********      Program/Package: 
*********              Request: Siyana Nikolova 
*********               Author: Dimitar Dimitrov
********* Received e-mail date: 24/06/2024
*********      Resolution date: 24/06/2024
*********  Trace old file here: \\epox\specifs\performance\tmp\
*********  Trace new file here:
***********************************************************************************/

/********************************OLD SQL*******************************************/

-- bvsjn3y69agpj


SELECT LIM.LIMIT_REF, 
       MIN(FI.DT_EMIS_DT) AS NEW_DATE
  FROM G_VENDOSSLIMIT VEN,
       G_DOSSIER      D,
       STD_MIGR_FNC   FNC,
       G_ELEMFI       FI,
       G_PIECE        L,
       G_PIECE        REQ,
       STD_MIGR_LIM   LIM
 WHERE L.TYPPIECE = 'PARAM_LIMITE'
   AND L.REFPIECE = VEN.LIMIT_ID
   AND LIM.LIMIT_REF = REQ.REFPIECE
   AND REQ.TYPPIECE = 'REQUEST_LIMITE'
   AND L.STR_20_1 = REQ.REFPIECE
   AND LIM.TYPE_OF_REQUEST IN ('C')
   AND D.REFDOSS = VEN.REFDOSS
   AND FI.REFDOSS = D.REFDOSS
   AND FNC.ID_DOCUMENT = FI.REFELEM
   AND FNC.COVER_AMT > 0
   AND EXISTS (SELECT 1
                 FROM G_PIECE REQ, 
                      G_PIECEDET CI_CF
                WHERE REQ.REFPIECE = LIM.LIMIT_REF
                  AND REQ.TYPPIECE = 'REQUEST_LIMITE'
                  AND CI_CF.REFPIECE = REQ.REFPIECE
                  AND CI_CF.TYPE = 'REQUEST_CF_PROPOSAL')
 GROUP BY LIM.LIMIT_REF;


-- 38ha8n6qcujy1 
 
SELECT LIM.LIMIT_REF, 
       MIN(FI.DT_EMIS_DT) AS NEW_DATE
  FROM G_VENDOSSLIMIT VEN,
       G_DOSSIER      D,
       STD_MIGR_FNC   FNC,
       G_ELEMFI       FI,
       G_PIECE        L,
       G_PIECE        REQ,
       STD_MIGR_LIM   LIM
 WHERE L.TYPPIECE = 'PARAM_LIMITE'
   AND L.REFPIECE = VEN.LIMIT_ID
   AND LIM.LIMIT_REF = REQ.REFPIECE
   AND REQ.TYPPIECE = 'REQUEST_LIMITE'
   AND L.STR_20_1 = REQ.REFPIECE
   AND LIM.TYPE_OF_REQUEST IN ('C', 'CI')
   AND D.REFDOSS = VEN.REFDOSS
   AND FI.REFDOSS = D.REFDOSS
   AND FNC.ID_DOCUMENT = FI.REFELEM
   AND FNC.COVER_AMT > 0
 GROUP BY LIM.LIMIT_REF;


-- dp0wqkw36y71c


UPDATE STD_MIGR_LIM
   SET START_DATE = :B1
 WHERE LIMIT_REF = :B2
   AND START_DATE > :B1;


-- 3adwztmazcsku

UPDATE STD_MIGR_LIM
   SET CI_CF_DECISION_START_DT = :B1
 WHERE LIMIT_REF = :B2
   AND START_DATE >= :B1;
/********************************OLD SQL*******************************************/
/********************************OLD Metrics***************************************/
/*
MODULE                           SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
std_migr_exp_mvt.export_lim                                      439       2024 db file sequential r 2024/06/20 17:17:38  2024/06/20 23:56:05        1460                    1 +000000000 06:38:27.123 61%
std_migr_exp_mvt.export_lim                                      439       2024 ON CPU               2024/06/20 17:18:48  2024/06/20 23:56:25         856                52531 +000000000 06:37:37.053 36%
std_migr_exp_mvt.export_lim                                      439       2024 db file parallel rea 2024/06/20 17:17:08  2024/06/20 23:55:35          76                    1 +000000000 06:38:27.153 3%
std_migr_exp_mvt.export_lim                                      439       2024 db file scattered re 2024/06/20 17:17:18  2024/06/20 23:53:35           4                    1 +000000000 06:36:17.041 0%
std_migr_exp_mvt.export_lim      aj956nhsjz62y 3481392728        439       2024 PGA memory operation 2024/06/20 17:16:58  2024/06/20 17:16:58           1                      +000000000 00:00:00.000 0%




MODULE                           SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
std_migr_exp_mvt.export_lim      bvsjn3y69agpj 3518843589        439       2024                      2024/06/20 20:41:12  2024/06/20 22:54:44         802                    1 +000000000 02:13:32.842 33%
std_migr_exp_mvt.export_lim      38ha8n6qcujy1 1843460768        439       2024                      2024/06/20 17:33:09  2024/06/20 19:43:31         783                    1 +000000000 02:10:22.783 33%
std_migr_exp_mvt.export_lim      dp0wqkw36y71c 3557216947        439       2024 ON CPU               2024/06/20 19:43:41  2024/06/20 20:41:02         345                52391 +000000000 00:57:20.251 14%
std_migr_exp_mvt.export_lim      3adwztmazcsku 3557216947        439       2024 ON CPU               2024/06/20 22:54:54  2024/06/20 23:45:45         304                44592 +000000000 00:50:50.400 13%
std_migr_exp_mvt.export_lim      aj956nhsjz62y 3481392728        439       2024                      2024/06/20 17:16:58  2024/06/20 17:32:59          97                    1 +000000000 00:16:00.476 4%
std_migr_exp_mvt.export_lim      33hv83rutznyv  341407772        439       2024                      2024/06/20 23:45:55  2024/06/20 23:52:45          42                    1 +000000000 00:06:50.222 2%
std_migr_exp_mvt.export_lim      gfsb69pcxbz1n 4143794204        439       2024                      2024/06/20 23:52:55  2024/06/20 23:56:05          20                    1 +000000000 00:03:10.182 1%
std_migr_exp_mvt.export_lim                             0        439       2024 ON CPU               2024/06/20 23:20:45  2024/06/20 23:32:35           2                      +000000000 00:11:50.115 0%
std_migr_exp_mvt.export_lim      3yrtj0pugn2m4 3557216947        439       2024 ON CPU               2024/06/20 23:56:15  2024/06/20 23:56:15           1                    1 +000000000 00:00:00.000 0%
std_migr_exp_mvt.export_lim      2pgxg2w5zrb7w 3852426868        439       2024 ON CPU               2024/06/20 23:56:25  2024/06/20 23:56:25           1                      +000000000 00:00:00.000 0%

INSTANCE_NUMBER SQL_ID            ELAPSED MAX_WAIT_ON     PC_OF  WAIT_TIME            GETS      READS       ROWS  ELAP/EXEC       GETS/EXEC READS/EXEC  ROWS/EXEC       EXEC PLAN_HASH_VALUE
--------------- ------------- ----------- --------------- ----- ---------- --------------- ---------- ---------- ---------- --------------- ---------- ---------- ---------- ---------------
              1 38ha8n6qcujy1        7831 IO              95%   7520.00432        92434358   10367836      15400    7830.68        92434358   10367836      15400          1      1843460768
              1 3adwztmazcsku        3054 CPU             100%  937.900053       470051372      10491        543        .07           10499        .23        .01      44771      3557216947
              1 bvsjn3y69agpj        8017 IO              94%    7694.3042        82197105   10501736       5000    8017.11        82197105   10501736       5000          1      3518843589
              1 dp0wqkw36y71c        3444 CPU             100%  1071.16939       552271974      10492       1084        .07           10499         .2        .02      52601      3557216947


SQL_ID        SQL_PLAN_HASH_VALUE SQL_PLAN_LINE_ID SQL_PLAN_OPERATION             SQL_PLAN_OPTIONS                   ACTIVE
------------- ------------------- ---------------- ------------------------------ ------------------------------ ----------
38ha8n6qcujy1          1843460768               18 TABLE ACCESS                   BY INDEX ROWID BATCHED                689
38ha8n6qcujy1          1843460768               19 INDEX                          RANGE SCAN                             27
38ha8n6qcujy1          1843460768                9 TABLE ACCESS                   BY INDEX ROWID BATCHED                 24
38ha8n6qcujy1          1843460768               21 INDEX                          RANGE SCAN                             21
38ha8n6qcujy1          1843460768               20 TABLE ACCESS                   BY INDEX ROWID BATCHED                  7
38ha8n6qcujy1          1843460768               17 INDEX                          RANGE SCAN                              5
38ha8n6qcujy1          1843460768                2 NESTED LOOPS                   SEMI                                    5
38ha8n6qcujy1          1843460768               12 TABLE ACCESS                   BY INDEX ROWID                          4
38ha8n6qcujy1          1843460768               11 INDEX                          RANGE SCAN                              1
bvsjn3y69agpj          3518843589               18 TABLE ACCESS                   BY INDEX ROWID BATCHED                675
bvsjn3y69agpj          3518843589               19 INDEX                          RANGE SCAN                             35
bvsjn3y69agpj          3518843589               11 TABLE ACCESS                   BY INDEX ROWID BATCHED                 24
bvsjn3y69agpj          3518843589               21 INDEX                          RANGE SCAN                             17
bvsjn3y69agpj          3518843589               20 TABLE ACCESS                   BY INDEX ROWID BATCHED                 14
bvsjn3y69agpj          3518843589               16 INDEX                          RANGE SCAN                             13
bvsjn3y69agpj          3518843589               17 INDEX                          RANGE SCAN                              9
bvsjn3y69agpj          3518843589               14 TABLE ACCESS                   BY INDEX ROWID                          5
bvsjn3y69agpj          3518843589                2 NESTED LOOPS                   SEMI                                    3
bvsjn3y69agpj          3518843589               13 INDEX                          RANGE SCAN                              2
bvsjn3y69agpj          3518843589                8 HASH JOIN                      SEMI                                    2
bvsjn3y69agpj          3518843589               12 INDEX                          RANGE SCAN                              1
bvsjn3y69agpj          3518843589               15 TABLE ACCESS                   FULL                                    1
bvsjn3y69agpj          3518843589                9 NESTED LOOPS                                                           1
dp0wqkw36y71c          3557216947                2 TABLE ACCESS                   FULL                                  345
3adwztmazcsku          3557216947                2 TABLE ACCESS                   FULL                                  303
3adwztmazcsku          3557216947                  UPDATE STATEMENT                                                       1


-- bvsjn3y69agpj

Plan hash value: 3518843589
----------------------------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                     | Name                           | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  |
----------------------------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                              |                                |      1 |        | 18663 (100)|      0 |00:00:00.01 |       0 |      0 |
|   1 |  HASH GROUP BY                                |                                |      1 |    127 | 18663   (1)|      0 |00:00:00.01 |       0 |      0 |
|   2 |   NESTED LOOPS SEMI                           |                                |      1 |   5366 | 18661   (1)|      0 |00:00:00.01 |       0 |      0 |
|   3 |    NESTED LOOPS                               |                                |      1 |    548K| 13175   (1)|      0 |00:00:00.01 |       0 |      0 |
|   4 |     NESTED LOOPS                              |                                |      1 |   5587 | 10883   (1)|      0 |00:00:00.01 |       0 |      0 |
|   5 |      VIEW                                     | VW_GBF_44                      |      1 |   4435 | 10795   (1)|      0 |00:00:00.01 |       0 |      0 |
|   6 |       HASH GROUP BY                           |                                |      1 |   4435 | 10795   (1)|      0 |00:00:00.01 |       0 |      0 |
|   7 |        NESTED LOOPS SEMI                      |                                |      1 |   6057 | 10794   (1)|      0 |00:00:00.01 |       0 |      0 |
|*  8 |         HASH JOIN SEMI                        |                                |      1 |   6057 | 10551   (1)|      0 |00:00:00.01 |       0 |      0 |
|   9 |          NESTED LOOPS                         |                                |      1 |  61214 |  7286   (1)|   1301K|00:04:54.90 |    6735K|    675K|
|  10 |           NESTED LOOPS                        |                                |      1 |  61214 |  7286   (1)|   1307K|00:02:20.67 |    5753K|    464K|
|* 11 |            TABLE ACCESS BY INDEX ROWID BATCHED| G_PIECE                        |      1 |  61214 |  4837   (1)|   1310K|00:01:27.89 |    1922K|    403K|
|* 12 |             INDEX RANGE SCAN                  | PIECE_TYP_MT43_IDX             |      1 |   3179K|   129   (0)|   1417K|00:00:03.87 |    5418 |   5054 |
|* 13 |            INDEX RANGE SCAN                   | PIE_REFPIECE                   |   1310K|      1 |     1   (0)|   1307K|00:00:52.13 |    3831K|  61630 |
|* 14 |           TABLE ACCESS BY INDEX ROWID         | G_PIECE                        |   1307K|      1 |     1   (0)|   1301K|00:02:33.66 |     981K|    210K|
|* 15 |          TABLE ACCESS FULL                    | STD_MIGR_LIM                   |      0 |    195K|  1962   (1)|      0 |00:00:00.01 |       0 |      0 |
|* 16 |         INDEX RANGE SCAN                      | G_PIECEDET_REFP                |      0 |   5673K|     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 17 |      INDEX RANGE SCAN                         | G_VENDOSSLIMIT$REFDOSS_LIMITID |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|  18 |     TABLE ACCESS BY INDEX ROWID BATCHED       | G_ELEMFI                       |      0 |     98 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 19 |      INDEX RANGE SCAN                         | ELEMFI_REFDOSS_OUVERT_IDX      |      0 |    166 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 20 |    TABLE ACCESS BY INDEX ROWID BATCHED        | STD_MIGR_FNC                   |      0 |   5359 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 21 |     INDEX RANGE SCAN                          | IDX_FNC_DOC_DB                 |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
----------------------------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   8 - access("LIM"."LIMIT_REF"="REQ"."REFPIECE")
  11 - filter("L"."STR_20_1" IS NOT NULL)
  12 - access("L"."TYPPIECE"='PARAM_LIMITE')
  13 - access("L"."STR_20_1"="REQ"."REFPIECE")
  14 - filter("REQ"."TYPPIECE"='REQUEST_LIMITE')
  15 - filter("LIM"."TYPE_OF_REQUEST"='C')
  16 - access("CI_CF"."REFPIECE"="REQ"."REFPIECE" AND "CI_CF"."TYPE"='REQUEST_CF_PROPOSAL')
  17 - access("ITEM_1"="VEN"."LIMIT_ID")
  19 - access("FI"."REFDOSS"="VEN"."REFDOSS")
       filter("FI"."REFDOSS" IS NOT NULL)
  20 - filter("FNC"."COVER_AMT">0)
  21 - access("FNC"."ID_DOCUMENT"="FI"."REFELEM")


-- 38ha8n6qcujy1 

Plan hash value: 1843460768
--------------------------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                   | Name                           | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  |
--------------------------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                            |                                |      1 |        | 21139 (100)|      0 |00:00:00.01 |       0 |      0 |
|   1 |  HASH GROUP BY                              |                                |      1 |   7530 | 21139   (1)|      0 |00:00:00.01 |       0 |      0 |
|   2 |   NESTED LOOPS SEMI                         |                                |      1 |   7530 | 21138   (1)|      0 |00:00:00.01 |       0 |      0 |
|   3 |    NESTED LOOPS                             |                                |      1 |    769K| 13438   (1)|      0 |00:00:00.01 |       0 |      0 |
|   4 |     NESTED LOOPS                            |                                |      1 |   7841 | 10222   (1)|      0 |00:00:00.01 |       0 |      0 |
|*  5 |      HASH JOIN                              |                                |      1 |   6224 | 10098   (1)|      0 |00:00:00.01 |       0 |      0 |
|   6 |       JOIN FILTER CREATE                    | :BF0000                        |      1 |  61214 |  7286   (1)|  82724 |00:00:16.31 |     430K|  32401 |
|   7 |        NESTED LOOPS                         |                                |      1 |  61214 |  7286   (1)|  82724 |00:00:16.27 |     430K|  32401 |
|   8 |         NESTED LOOPS                        |                                |      1 |  61214 |  7286   (1)|  83296 |00:00:07.84 |     368K|  22502 |
|*  9 |          TABLE ACCESS BY INDEX ROWID BATCHED| G_PIECE                        |      1 |  61214 |  4837   (1)|  83296 |00:00:03.75 |     126K|  17816 |
|* 10 |           INDEX RANGE SCAN                  | PIECE_TYP_MT43_IDX             |      1 |   3179K|   129   (0)|  89609 |00:00:00.19 |     364 |    203 |
|* 11 |          INDEX RANGE SCAN                   | PIE_REFPIECE                   |  83296 |      1 |     1   (0)|  83296 |00:00:04.06 |     241K|   4686 |
|* 12 |         TABLE ACCESS BY INDEX ROWID         | G_PIECE                        |  83296 |      1 |     1   (0)|  82724 |00:00:08.40 |   62439 |   9899 |
|  13 |       VIEW                                  | VW_GBF_31                      |      0 |    195K|  1969   (2)|      0 |00:00:00.01 |       0 |      0 |
|  14 |        HASH GROUP BY                        |                                |      0 |    195K|  1969   (2)|      0 |00:00:00.01 |       0 |      0 |
|  15 |         JOIN FILTER USE                     | :BF0000                        |      0 |    195K|  1962   (1)|      0 |00:00:00.01 |       0 |      0 |
|* 16 |          TABLE ACCESS FULL                  | STD_MIGR_LIM                   |      0 |    195K|  1962   (1)|      0 |00:00:00.01 |       0 |      0 |
|* 17 |      INDEX RANGE SCAN                       | G_VENDOSSLIMIT$REFDOSS_LIMITID |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|  18 |     TABLE ACCESS BY INDEX ROWID BATCHED     | G_ELEMFI                       |      0 |     98 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 19 |      INDEX RANGE SCAN                       | ELEMFI_REFDOSS_OUVERT_IDX      |      0 |    166 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 20 |    TABLE ACCESS BY INDEX ROWID BATCHED      | STD_MIGR_FNC                   |      0 |   5359 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 21 |     INDEX RANGE SCAN                        | IDX_FNC_DOC_DB                 |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
--------------------------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   5 - access("ITEM_1"="REQ"."REFPIECE")
   9 - filter("L"."STR_20_1" IS NOT NULL)
  10 - access("L"."TYPPIECE"='PARAM_LIMITE')
  11 - access("L"."STR_20_1"="REQ"."REFPIECE")
  12 - filter("REQ"."TYPPIECE"='REQUEST_LIMITE')
  16 - filter((INTERNAL_FUNCTION("LIM"."TYPE_OF_REQUEST") AND SYS_OP_BLOOM_FILTER(:BF0000,"LIM"."LIMIT_REF")))
  17 - access("L"."REFPIECE"="VEN"."LIMIT_ID")
  19 - access("FI"."REFDOSS"="VEN"."REFDOSS")
       filter("FI"."REFDOSS" IS NOT NULL)
  20 - filter("FNC"."COVER_AMT">0)
  21 - access("FNC"."ID_DOCUMENT"="FI"."REFELEM") 



-- dp0wqkw36y71c

Plan hash value: 3557216947
-----------------------------------------------------------------------------------
| Id  | Operation          | Name         | Rows  | Bytes | Cost (%CPU)| Time     |
-----------------------------------------------------------------------------------
|   0 | UPDATE STATEMENT   |              |       |       |  1958 (100)|          |
|   1 |  UPDATE            | STD_MIGR_LIM |       |       |            |          |
|   2 |   TABLE ACCESS FULL| STD_MIGR_LIM |   124 |  8804 |  1958   (1)| 00:00:01 |
-----------------------------------------------------------------------------------


-- 3adwztmazcsku


Plan hash value: 3557216947
-----------------------------------------------------------------------------------
| Id  | Operation          | Name         | Rows  | Bytes | Cost (%CPU)| Time     |
-----------------------------------------------------------------------------------
|   0 | UPDATE STATEMENT   |              |       |       |  1958 (100)|          |
|   1 |  UPDATE            | STD_MIGR_LIM |       |       |            |          |
|   2 |   TABLE ACCESS FULL| STD_MIGR_LIM |   124 |  9920 |  1958   (1)| 00:00:01 |
-----------------------------------------------------------------------------------
*/
/********************************OLD Metrics***************************************/

/********************************New SQL*******************************************/

-- bvsjn3y69agpj

WITH F AS (SELECT /*+ no_merge no_push_pred leading(FNC FI) full(FNC)  cardinality(FNC 5)*/
                FI.REFDOSS REFDOSS,
                min(FI.DT_EMIS_DT) DT_EMIS_DT
           FROM STD_MIGR_FNC FNC,
                G_ELEMFI FI
          WHERE FNC.ID_DOCUMENT = FI.REFELEM
            AND FNC.COVER_AMT > 0 
           GROUP BY FI.REFDOSS ),
 D AS (SELECT /*+ no_merge no_push_pred leading(LIM REQ L VEN D) full(LIM) cardinality(LIM 5)*/
               VEN.REFDOSS REFDOSS,
               LIM.LIMIT_REF LIMIT_REF
          FROM G_VENDOSSLIMIT VEN,
               G_PIECE        L,
               G_PIECE        REQ,
               STD_MIGR_LIM   LIM
         WHERE L.TYPPIECE = 'PARAM_LIMITE'
           AND L.REFPIECE = VEN.LIMIT_ID
           AND LIM.LIMIT_REF = REQ.REFPIECE
           AND REQ.TYPPIECE = 'REQUEST_LIMITE'
           AND L.STR_20_1 = REQ.REFPIECE
           AND LIM.TYPE_OF_REQUEST IN ('C', 'CI')
           AND EXISTS (SELECT 1
                         FROM G_PIECE REQ, 
                              G_PIECEDET CI_CF
                        WHERE REQ.REFPIECE = LIM.LIMIT_REF
                          AND REQ.TYPPIECE = 'REQUEST_LIMITE'
                          AND CI_CF.REFPIECE = REQ.REFPIECE
                          AND CI_CF.TYPE = 'REQUEST_CF_PROPOSAL') )           
SELECT /*+ use_hash(D F) */
       D.LIMIT_REF, 
       MIN(F.DT_EMIS_DT) AS NEW_DATE
  FROM D,
       F
 WHERE F.REFDOSS = D.REFDOSS
 GROUP BY D.LIMIT_REF;


-- 38ha8n6qcujy1 

WITH F AS (SELECT /*+ no_merge no_push_pred leading(FNC FI) full(FNC)  cardinality(FNC 5)*/
                FI.REFDOSS REFDOSS,
                min(FI.DT_EMIS_DT) DT_EMIS_DT
           FROM STD_MIGR_FNC FNC,
                G_ELEMFI FI
          WHERE FNC.ID_DOCUMENT = FI.REFELEM
            AND FNC.COVER_AMT > 0
           GROUP BY FI.REFDOSS ),
 D AS (SELECT /*+ no_merge no_push_pred leading(LIM REQ L VEN D) full(LIM) cardinality(LIM 5)*/
               VEN.REFDOSS REFDOSS,
               LIM.LIMIT_REF LIMIT_REF
          FROM G_VENDOSSLIMIT VEN,
               G_PIECE        L,
               G_PIECE        REQ,
               STD_MIGR_LIM   LIM
         WHERE L.TYPPIECE = 'PARAM_LIMITE'
           AND L.REFPIECE = VEN.LIMIT_ID
           AND LIM.LIMIT_REF = REQ.REFPIECE
           AND REQ.TYPPIECE = 'REQUEST_LIMITE'
           AND L.STR_20_1 = REQ.REFPIECE
           AND LIM.TYPE_OF_REQUEST IN ('C', 'CI') )           
SELECT /*+ use_hash(D F) */
       D.LIMIT_REF, 
       MIN(F.DT_EMIS_DT) AS NEW_DATE
  FROM D,
       F
 WHERE F.REFDOSS = D.REFDOSS
 GROUP BY D.LIMIT_REF;
/********************************New SQL*******************************************/
/********************************New Metrics***************************************/
/*

-- bvsjn3y69agpj


Plan hash value: 2504826853
--------------------------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                   | Name                           | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  |
--------------------------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                            |                                |      1 |        |  5858 (100)|  44771 |00:05:38.00 |    5452K|    512K|
|   1 |  HASH GROUP BY                              |                                |      1 |      1 |  5858   (1)|  44771 |00:05:38.00 |    5452K|    512K|
|*  2 |   HASH JOIN                                 |                                |      1 |      1 |  5857   (1)|  92761 |00:05:37.97 |    5452K|    512K|
|   3 |    JOIN FILTER CREATE                       | :BF0000                        |      1 |      1 |  1966   (1)|    377K|00:04:24.16 |    3986K|    375K|
|   4 |     VIEW                                    |                                |      1 |      1 |  1966   (1)|    377K|00:04:23.97 |    3986K|    375K|
|   5 |      NESTED LOOPS                           |                                |      1 |      1 |  1966   (1)|    377K|00:04:23.90 |    3986K|    375K|
|   6 |       NESTED LOOPS                          |                                |      1 |      1 |  1965   (1)|    454K|00:02:55.10 |    2304K|    261K|
|   7 |        NESTED LOOPS                         |                                |      1 |      1 |  1964   (1)|    412K|00:02:50.11 |    1553K|    258K|
|   8 |         NESTED LOOPS                        |                                |      1 |      5 |  1963   (1)|    232K|00:01:21.19 |     864K|    119K|
|*  9 |          TABLE ACCESS FULL                  | STD_MIGR_LIM                   |      1 |      5 |  1962   (1)|    232K|00:00:00.94 |   10499 |   7211 |
|* 10 |          TABLE ACCESS BY INDEX ROWID BATCHED| G_PIECE                        |    232K|      1 |     1   (0)|    232K|00:01:20.03 |     853K|    112K|
|* 11 |           INDEX RANGE SCAN                  | PIE_REFPIECE                   |    232K|      1 |     1   (0)|    232K|00:00:25.32 |     649K|  31991 |
|* 12 |         TABLE ACCESS BY INDEX ROWID BATCHED | G_PIECE                        |    232K|      1 |     1   (0)|    412K|00:01:28.69 |     689K|    139K|
|* 13 |          INDEX RANGE SCAN                   | TEST_DI_GP_IDX1                |    232K|      1 |     1   (0)|    412K|00:00:02.58 |     432K|    849 |
|* 14 |        INDEX RANGE SCAN                     | G_VENDOSSLIMIT$REFDOSS_LIMITID |    412K|      1 |     1   (0)|    454K|00:00:04.73 |     750K|   2662 |
|* 15 |       INDEX RANGE SCAN                      | G_PIECEDET_REFP                |    454K|      1 |     1   (0)|    377K|00:01:28.59 |    1682K|    114K|
|  16 |    VIEW                                     |                                |      1 |      5 |  3890   (1)|  54421 |00:01:13.52 |    1465K|    136K|
|  17 |     HASH GROUP BY                           |                                |      1 |      5 |  3890   (1)|  54421 |00:01:13.52 |    1465K|    136K|
|  18 |      JOIN FILTER USE                        | :BF0000                        |      1 |      5 |  3889   (1)|    720K|00:01:12.88 |    1465K|    136K|
|  19 |       NESTED LOOPS                          |                                |      1 |      5 |  3889   (1)|    720K|00:01:12.75 |    1465K|    136K|
|  20 |        NESTED LOOPS                         |                                |      1 |      5 |  3889   (1)|    720K|00:00:16.01 |     582K|  43601 |
|* 21 |         TABLE ACCESS FULL                   | STD_MIGR_FNC                   |      1 |      5 |  3888   (1)|    720K|00:00:01.22 |   22099 |  22080 |
|* 22 |         INDEX UNIQUE SCAN                   | EFI_REFELEM                    |    720K|      1 |     1   (0)|    720K|00:00:14.47 |     560K|  21521 |
|  23 |        TABLE ACCESS BY INDEX ROWID          | G_ELEMFI                       |    720K|      1 |     1   (0)|    720K|00:00:56.40 |     882K|  93339 |
--------------------------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   2 - access("F"."REFDOSS"="D"."REFDOSS")
   9 - filter(("LIM"."TYPE_OF_REQUEST"='C' OR "LIM"."TYPE_OF_REQUEST"='CI'))
  10 - filter("REQ"."TYPPIECE"='REQUEST_LIMITE')
  11 - access("LIM"."LIMIT_REF"="REQ"."REFPIECE")
  12 - filter("L"."TYPPIECE"='PARAM_LIMITE')
  13 - access("L"."STR_20_1"="REQ"."REFPIECE")
       filter("L"."STR_20_1" IS NOT NULL)
  14 - access("L"."REFPIECE"="VEN"."LIMIT_ID")
  15 - access("CI_CF"."REFPIECE"="REQ"."REFPIECE" AND "CI_CF"."TYPE"='REQUEST_CF_PROPOSAL')
  21 - filter("FNC"."COVER_AMT">0)
  22 - access("FNC"."ID_DOCUMENT"="FI"."REFELEM")



-- 38ha8n6qcujy1 

Plan hash value: 3130449305
-------------------------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                  | Name                           | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  |
-------------------------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                           |                                |      1 |        |  5857 (100)|  52601 |00:03:48.49 |    3770K|    348K|
|   1 |  HASH GROUP BY                             |                                |      1 |      1 |  5857   (1)|  52601 |00:03:48.49 |    3770K|    348K|
|*  2 |   HASH JOIN                                |                                |      1 |      1 |  5856   (1)|    100K|00:03:48.46 |    3770K|    348K|
|   3 |    JOIN FILTER CREATE                      | :BF0000                        |      1 |      1 |  1965   (1)|    454K|00:02:37.58 |    2304K|    211K|
|   4 |     VIEW                                   |                                |      1 |      1 |  1965   (1)|    454K|00:02:37.39 |    2304K|    211K|
|   5 |      NESTED LOOPS                          |                                |      1 |      1 |  1965   (1)|    454K|00:02:37.31 |    2304K|    211K|
|   6 |       NESTED LOOPS                         |                                |      1 |      1 |  1964   (1)|    412K|00:02:31.54 |    1553K|    207K|
|   7 |        NESTED LOOPS                        |                                |      1 |      5 |  1963   (1)|    232K|00:01:20.13 |     864K|    106K|
|*  8 |         TABLE ACCESS FULL                  | STD_MIGR_LIM                   |      1 |      5 |  1962   (1)|    232K|00:00:00.68 |   10499 |   6568 |
|*  9 |         TABLE ACCESS BY INDEX ROWID BATCHED| G_PIECE                        |    232K|      1 |     1   (0)|    232K|00:01:19.27 |     853K|    100K|
|* 10 |          INDEX RANGE SCAN                  | PIE_REFPIECE                   |    232K|      1 |     1   (0)|    232K|00:00:27.70 |     649K|  32908 |
|* 11 |        TABLE ACCESS BY INDEX ROWID BATCHED | G_PIECE                        |    232K|      1 |     1   (0)|    412K|00:01:11.21 |     689K|    100K|
|* 12 |         INDEX RANGE SCAN                   | TEST_DI_GP_IDX1                |    232K|      1 |     1   (0)|    412K|00:00:02.89 |     432K|   1318 |
|* 13 |       INDEX RANGE SCAN                     | G_VENDOSSLIMIT$REFDOSS_LIMITID |    412K|      1 |     1   (0)|    454K|00:00:05.54 |     750K|   4092 |
|  14 |    VIEW                                    |                                |      1 |      5 |  3890   (1)|  54430 |00:01:10.56 |    1465K|    136K|
|  15 |     HASH GROUP BY                          |                                |      1 |      5 |  3890   (1)|  54430 |00:01:10.56 |    1465K|    136K|
|  16 |      JOIN FILTER USE                       | :BF0000                        |      1 |      5 |  3889   (1)|    720K|00:01:10.05 |    1465K|    136K|
|  17 |       NESTED LOOPS                         |                                |      1 |      5 |  3889   (1)|    720K|00:01:09.93 |    1465K|    136K|
|  18 |        NESTED LOOPS                        |                                |      1 |      5 |  3889   (1)|    720K|00:00:14.86 |     582K|  43612 |
|* 19 |         TABLE ACCESS FULL                  | STD_MIGR_FNC                   |      1 |      5 |  3888   (1)|    720K|00:00:00.38 |   22091 |  22085 |
|* 20 |         INDEX UNIQUE SCAN                  | EFI_REFELEM                    |    720K|      1 |     1   (0)|    720K|00:00:14.20 |     560K|  21527 |
|  21 |        TABLE ACCESS BY INDEX ROWID         | G_ELEMFI                       |    720K|      1 |     1   (0)|    720K|00:00:54.78 |     882K|  93360 |
-------------------------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   2 - access("F"."REFDOSS"="D"."REFDOSS")
   8 - filter(("LIM"."TYPE_OF_REQUEST"='C' OR "LIM"."TYPE_OF_REQUEST"='CI'))
   9 - filter("REQ"."TYPPIECE"='REQUEST_LIMITE')
  10 - access("LIM"."LIMIT_REF"="REQ"."REFPIECE")
  11 - filter("L"."TYPPIECE"='PARAM_LIMITE')
  12 - access("L"."STR_20_1"="REQ"."REFPIECE")
       filter("L"."STR_20_1" IS NOT NULL)
  13 - access("L"."REFPIECE"="VEN"."LIMIT_ID")
  19 - filter("FNC"."COVER_AMT">0)
  20 - access("FNC"."ID_DOCUMENT"="FI"."REFELEM")
*/
/********************************New Metrics***************************************/

/********************************Index statistics**********************************/

/********************************Other SQLs****************************************/          
/*

*/ 
/********************************Other SQLs****************************************/              
