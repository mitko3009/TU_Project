/********************************************************************************
*********       E-mail subject: COFADEV-13922
*********             Instance: PROD
*********          Description: 
Problem:
We were requested to check the performance of SE variable ds_assign_BU on COFACE PROD.

Analysis:
In the task, from the log was provided SID = 882, which is msgq_pilote ( msg_q04 ).
We checked its work for of the msgq_pilote for the provided period and found that the TOP SQL in it is c3b8jag5fccgv, which was responsible for 89% of the time.
From performance point of view, the execution plan look OK for that query, but we have suspicious that there is missing condition in the query ( the relation between tables G_PIECE and G_DOSSIER by refdoss is missing ), because in the variant that it is in the moment, it searches for all records in G_PIECE where the TYPPIECE matches ( DOS.PIECEINIT = REC.TYPPIECE ).
We added relation DOS.REFDOSS = REC.REFDOSS to the query as it is shown in the New SQL section, so could you please check is it functionally correct and if it is, please implement it.

Suggestion:
Please check is the query in the New SQL section below functioanly correct and if it is, please change it as it is shown in the New SQL section below.

*********               SQL_ID: c3b8jag5fccgv
*********      Program/Package: 
*********              Request: Huynh Cam Thi Nguyen 
*********               Author: Dimitar Dimitrov
********* Received e-mail date: 20/11/2024
*********      Resolution date: 20/11/2024
*********  Trace old file here: \\epox\specifs\performance\tmp\
*********  Trace new file here:
***********************************************************************************/

/********************************OLD SQL*******************************************/

VAR B1 VARCHAR2(32);
EXEC :B1 := '2411180289';

SELECT DECODE(FPN.CHEMIN, 'O', 2, 1)
  FROM V_DOMAINE FPN, 
       G_PIECE REC,
       G_DOSSIER DOS
 WHERE FPN.ABREV = REC.ST37
   AND FPN.TYPE = 'FRENCH_POLICY_NB'
   AND DOS.PIECEINIT = REC.TYPPIECE
   AND DOS.REFDOSS = :B1;
/********************************OLD SQL*******************************************/
/********************************OLD Metrics***************************************/
/*
MODULE                           PROGRAM                                            CLIENT_ID       SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- -------------------------------------------------- --------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
E2012BA20EB4268583096A08961925F5 iMX BE                                                                                                            ON CPU                2024/11/18 10:30:11  2024/11/18 10:31:51         17                 5893 +000000000 00:01:40.041 25%
msgq_pilote                      msg_q04                                                            c3b8jag5fccgv 4102190309        882      19850 db file sequential r  2024/11/18 10:30:41  2024/11/18 10:31:51          7                    1 +000000000 00:01:10.026 10%
EXTRANET                         EXTRANET                                                                                                          ON CPU                2024/11/18 10:30:01  2024/11/18 10:31:51          5                    1 +000000000 00:01:50.046 7%
51DFFF185D868F4CCB40FB50E4249982 iMX BE                                             Floriana_Milton 80g8pn61mcwc7 1670309620        295      20484 enq: TX - row lock c  2024/11/18 10:31:11  2024/11/18 10:31:51          5                    1 +000000000 00:00:40.017 7%
PT_SNAP_SESSION                  sqlplus                                                            bych71jzp5r3s 3946228716        501      54715 ON CPU                2024/11/18 10:30:01  2024/11/18 10:31:41          4                    8 +000000000 00:01:40.045 6%
imx2easy_monitoring              soa_integration                                                    1fk8sqs69tyw2 1695774612       1920      14186 ON CPU                2024/11/18 10:30:01  2024/11/18 10:31:21          3                    7 +000000000 00:01:20.032 4%
msgq                                                                                                d61udtn7264hs         ON CPU                                         2024/11/18 10:30:31  2024/11/18 10:31:31          2                    1 +000000000 00:01:00.020 3%


MODULE                           PROGRAM                                            CLIENT_ID       SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- -------------------------------------------------- --------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
msgq_pilote                      msg_q04                                                                                   882      19850                               2024/11/18 10:30:31  2024/11/18 10:31:51           9              5087447 +000000000 00:01:20.029 100%


MODULE                           PROGRAM                                            CLIENT_ID       SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- -------------------------------------------------- --------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
msgq_pilote                      msg_q04                                                            c3b8jag5fccgv 4102190309        882      19850 db file sequential r 2024/11/18 10:30:41  2024/11/18 10:31:51           7                    1 +000000000 00:01:10.026 78%
msgq_pilote                      msg_q04                                                            cgufjhvr9ybun 3436719319        882      19850 ON CPU               2024/11/18 10:30:31  2024/11/18 10:30:31           1                    1 +000000000 00:00:00.000 11%
msgq_pilote                      msg_q04                                                            c3b8jag5fccgv 4102190309        882      19850 db file scattered re 2024/11/18 10:31:31  2024/11/18 10:31:31           1                    1 +000000000 00:00:00.000 11%


ODULE                           PROGRAM                                            CLIENT_ID       SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- -------------------------------------------------- --------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
msgq_pilote                      msg_q04                                                            c3b8jag5fccgv 4102190309        882      19850                      2024/11/18 10:30:41  2024/11/18 10:31:51           8                    1 +000000000 00:01:10.026 89%
msgq_pilote                      msg_q04                                                            cgufjhvr9ybun 3436719319        882      19850 ON CPU               2024/11/18 10:30:31  2024/11/18 10:30:31           1                    1 +000000000 00:00:00.000 11%


SQL_ID        SQL_PLAN_HASH_VALUE SQL_PLAN_LINE_ID SQL_PLAN_OPERATION             SQL_PLAN_OPTIONS                   ACTIVE
------------- ------------------- ---------------- ------------------------------ ------------------------------ ----------
c3b8jag5fccgv          4102190309                7 TABLE ACCESS                   BY INDEX ROWID BATCHED                 7
c3b8jag5fccgv          4102190309                8 INDEX                          RANGE SCAN                             1


INSTANCE_NUMBER SQL_ID            ELAPSED MAX_WAIT_ON     PC_OF  WAIT_TIME            GETS      READS       ROWS  ELAP/EXEC       GETS/EXEC READS/EXEC  ROWS/EXEC       EXEC PLAN_HASH_VALUE
--------------- ------------- ----------- --------------- ----- ---------- --------------- ---------- ---------- ---------- --------------- ---------- ---------- ---------- ---------------
              1 c3b8jag5fccgv         232 IO              90%   237.208699         5261952     121522          0       33.2          751707   17360.29          0          7      4102190309
              1 c3b8jag5fccgv           1 CPU             100%    1.226401          746708          0          0       1.25          746708          0          0          1      1563530869


          
          
PERIOD                         CALL_TYPE            FIRST_PROCESSED_CAL LAST_PROCESSED_CALL NUMBER_OF_PROCESSED_CALLS  COUNT(*) CALLS_PER_MINUTE ELAPSED_SECONDS AVG_SECS_PER_CALL LONGEST_CALL
------------------------------ -------------------- ------------------- ------------------- ------------------------- ---------- ---------------- --------------- ----------------- ------------
2024-11-18 10:00:00            pilote               2024-11-18 10:00:18 2024-11-18 10:59:59                      1626      1626              27.1            5954              3.66          112
2024-11-18 10:00:00            ecrit                2024-11-18 10:00:14 2024-11-18 10:59:43                       155       155        2.58333333             200              1.29           33
2024-11-18 10:00:00            report               2024-11-18 10:02:17 2024-11-18 10:58:13                        36        36                .6             183              5.08           37
2024-11-18 10:00:00            edite2               2024-11-18 10:05:00 2024-11-18 10:59:18                        43        43        .716666667              24               .56            3
2024-11-18 10:00:00            edite                2024-11-18 10:10:03 2024-11-18 10:55:50                        10        10        .166666667              11                 1            4
2024-11-18 10:00:00            variab               2024-11-18 10:00:47 2024-11-18 10:59:02                        70        70        1.16666667               6               .09            1
2024-11-18 10:00:00            edite1               2024-11-18 10:35:56 2024-11-18 10:35:56                         1         1        .016666667               4                 4            4
2024-11-18 10:00:00            send_err_mail        2024-11-18 10:00:34 2024-11-18 10:58:20                        49        49        .816666667               1               .02            1

          
          
   
   
BUFF           MSGSEQ REFDOSS    PROCESSEDB LOCKEDBY                                 DATETR_DT           DTPROCESS_DT        DT_ENDPROC_DT       PARENT_MSGSEQ
---------- ---------- ---------- ---------- ---------------------------------------- ------------------- ------------------- ------------------- -------------
pilote@      56928911 2411180289 msg_q04                                             2024-11-18 10:30:29 2024-11-18 10:30:34 2024-11-18 10:32:19
pilote@      56928959 2411180289 msg_q04                                             2024-11-18 10:32:18 2024-11-18 10:32:23 2024-11-18 10:32:32      56928911
pilote@      56929273 2411180289 msg_q08                                             2024-11-18 10:43:49 2024-11-18 10:43:52 2024-11-18 10:43:54
pilote@      56929257 2411180289 msg_q05                                             2024-11-18 10:43:15 2024-11-18 10:43:15 2024-11-18 10:43:17


Plan hash value: 4102190309
----------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                             | Name                    | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers |
----------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                      |                         |      1 |        |   115 (100)|      0 |00:00:00.94 |     748K|
|*  1 |  HASH JOIN                            |                         |      1 |      1 |   115   (0)|      0 |00:00:00.94 |     748K|
|*  2 |   TABLE ACCESS BY INDEX ROWID BATCHED | V_DOMAINE               |      1 |     68 |     1   (0)|      1 |00:00:00.01 |       4 |
|*  3 |    INDEX RANGE SCAN                   | V_DOMAINE_TYPE_CODE_IDX |      1 |     77 |     1   (0)|      1 |00:00:00.01 |       3 |
|   4 |   NESTED LOOPS                        |                         |      1 |    373 |   114   (0)|  64537 |00:00:00.93 |     748K|
|   5 |    TABLE ACCESS BY INDEX ROWID        | G_DOSSIER               |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       4 |
|*  6 |     INDEX UNIQUE SCAN                 | DOS_REFDOSS             |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |
|*  7 |    TABLE ACCESS BY INDEX ROWID BATCHED| G_PIECE                 |      1 |    373 |   113   (0)|  64537 |00:00:00.92 |     748K|
|*  8 |     INDEX RANGE SCAN                  | PIECE_TYP_MT43_IDX      |      1 |  43738 |     2   (0)|    490K|00:00:00.06 |    2001 |
----------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   1 - access("FPN"."ABREV"="REC"."ST37")
   2 - filter("FPN"."ABREV" IS NOT NULL)
   3 - access("FPN"."TYPE"='FRENCH_POLICY_NB')
   6 - access("DOS"."REFDOSS"=:B1)
   7 - filter("REC"."ST37" IS NOT NULL)
   8 - access("DOS"."PIECEINIT"="REC"."TYPPIECE")
*/
/********************************OLD Metrics***************************************/

/********************************New SQL*******************************************/

SELECT DECODE(FPN.CHEMIN, 'O', 2, 1)
  FROM V_DOMAINE FPN, 
       G_PIECE REC,
       G_DOSSIER DOS
 WHERE FPN.ABREV = REC.ST37
   AND FPN.TYPE = 'FRENCH_POLICY_NB'
   AND DOS.PIECEINIT = REC.TYPPIECE
   AND DOS.REFDOSS = REC.REFDOSS
   AND DOS.REFDOSS = :B1;
/********************************New SQL*******************************************/
/********************************New Metrics***************************************/
/*
Plan hash value: 2721881276
------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                              | Name         | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers |
------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                       |              |      1 |        |     3 (100)|      0 |00:00:00.01 |     10 |
|   1 |  NESTED LOOPS                          |              |      1 |      1 |     3   (0)|      0 |00:00:00.01 |     10 |
|   2 |   NESTED LOOPS                         |              |      1 |      1 |     3   (0)|      0 |00:00:00.01 |     10 |
|   3 |    NESTED LOOPS                        |              |      1 |      1 |     2   (0)|      0 |00:00:00.01 |     10 |
|   4 |     TABLE ACCESS BY INDEX ROWID        | G_DOSSIER    |      1 |      1 |     1   (0)|      1 |00:00:00.01 |      4 |
|*  5 |      INDEX UNIQUE SCAN                 | DOS_REFDOSS  |      1 |      1 |     1   (0)|      1 |00:00:00.01 |      3 |
|*  6 |     TABLE ACCESS BY INDEX ROWID BATCHED| G_PIECE      |      1 |      1 |     1   (0)|      0 |00:00:00.01 |      6 |
|*  7 |      INDEX RANGE SCAN                  | PIE_REFDOSS  |      1 |      1 |     1   (0)|      1 |00:00:00.01 |      3 |
|*  8 |    INDEX RANGE SCAN                    | DOM_TYPABREV |      0 |      1 |     1   (0)|      0 |00:00:00.01 |      0 |
|   9 |   TABLE ACCESS BY INDEX ROWID          | V_DOMAINE    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |      0 |
------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   5 - access("DOS"."REFDOSS"=:B1)
   6 - filter("REC"."ST37" IS NOT NULL)
   7 - access("REC"."REFDOSS"=:B1 AND "DOS"."PIECEINIT"="REC"."TYPPIECE")
   8 - access("FPN"."TYPE"='FRENCH_POLICY_NB' AND "FPN"."ABREV"="REC"."ST37")
       filter("FPN"."ABREV" IS NOT NULL)
*/
/********************************New Metrics***************************************/

/********************************Index statistics**********************************/

/********************************Other SQLs****************************************/          
/*

*/ 
/********************************Other SQLs****************************************/              
