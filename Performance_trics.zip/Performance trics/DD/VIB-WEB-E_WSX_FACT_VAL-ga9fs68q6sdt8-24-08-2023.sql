/********************************************************************************
*********       E-mail subject: VWGSWEB-557
*********             Instance: QS_v9
*********          Description: 
Problem:
On 24/08/2023 there was slowness on e_fact_val screen.

Analysis:
There were two slow SQLs in E_WSX_FACT_VAL module.
The problem was inappropriate execution plan due to a missing index.

Suggestion:
Please create index ON G_PIECE(REFDOSS,TYPPIECE,DT05) to achieve the execution plans from the New Metrics section below.

Update 12/09/2023:
The suggested index had to be modified to ON G_PIECE(REFDOSS,TYPPIECE,DT03,DT05).
The SQL had to be modified from GP_CESS.dt03_dt IS NULL to GP_CESS.dt03 IS NULL in order to utilize the new index.
During tests, the execution plan was not exactly as expected, see \\epox\Specifs\performance\tmp\VWGS\E_WSX_FACT_VAL\20230912\.
There is a HASH JOIN between G_PIECE(CONTRAT) and G_DOSSIER(CONTRAT), we might need to additionally hint the SQL to use the correcte NESTED LOOPS join between the two tables.

*********               SQL_ID: 1svq3wtygymx2, ga9fs68q6sdt8
*********      Program/Package: E_WSX_FACT_VAL
*********              Request: Ivan Georgiev
*********               Author: Dimitar Dimitrov
********* Received e-mail date: 24/08/2023
*********      Resolution date: 24/08/2023
*********  Trace old file here: \\epox\Specifs\performance\tmp\VWGS\E_WSX_FACT_VAL\20230912\
*********  Trace new file here:
***********************************************************************************/

/********************************OLD SQL*******************************************/
--1svq3wtygymx2


SELECT  DATE_TRANSMISSION,
       ANCREFDOSS,
       TVA_CLIENT,
       DATE_VALEUR,
       GPIDEVIS,
       MONTANT,
       NB_DOCS,
       REFINDIVIDU,
       REFDOSS,
       NOM_CLIENT
  FROM (SELECT TI_CONTRAT.refindividu,
               NVL(GI_CONTRAT.REFEXT,
                   NVL(GI_CONTRAT.TVA, GI_CONTRAT.refindividu)) TVA_CLIENT,
               GI_CONTRAT.nom NOM_CLIENT,
               GD_CONTRAT.refdoss,
               GD_CONTRAT.ancrefdoss,
               COUNT(DISTINCT GP_CESS.refpiece) NB_DOCS,
               GP_CESS.dt05_dt AS DATE_TRANSMISSION,
               GP_CESS.dt08_dt AS DATE_VALEUR,
               GP_CESS.gpidevis,
               SUM(NVL(DECODE(GP_FACT.st09, 'RT', 0, GE.montant_mvt), 0)) MONTANT
          FROM g_piece        GP_FACT,
               g_elemfi       GE,
               g_dossier      GD_DECOMPTE,
               g_dossier      GD_CONTRAT,
               g_piece        GP_CONTRAT,
               g_piece        GP_PARAMCL,
               g_piece        GP_CESS,
               t_intervenants TI_CONTRAT,
               g_individu     GI_CONTRAT
         WHERE GP_FACT.gpiheure = GE.refelem
           AND GP_CONTRAT.refdoss = GD_CONTRAT.refdoss
           AND GP_CONTRAT.typpiece = 'CONTRAT'
           AND GP_PARAMCL.gpiheure(+) = GI_CONTRAT.refindividu
           AND GP_PARAMCL.typpiece(+) = 'CLIENT_PARAMS'
           AND GP_FACT.typpiece = 'FACTURE'
           AND GP_FACT.dt02_dt IS NULL
           AND GD_DECOMPTE.categdoss LIKE 'DECOMPTE%'
           AND GP_FACT.gpidepot = GP_CESS.refpiece
           AND GD_DECOMPTE.refdoss = GP_CESS.refdoss
           AND GP_CESS.typpiece = 'CESSION'
           AND GP_CESS.st10 = 'OK'
           AND NOT EXISTS
         (SELECT 1
                  FROM MSG_QUEUE
                 WHERE REFDOSS = GD_DECOMPTE.REFDOSS
                   AND prty <> 0
                   AND BUFF LIKE 'valcess@' || GP_CESS.refpiece || '%')
           AND GP_CESS.dt03_dt IS NULL
           AND NVL(GP_FACT.fg33, 'N') <> 'O'
           AND (GP_CESS.fg16 = 'C' AND NOT EXISTS
                (SELECT 1
                   FROM g_piece P, g_elemfi FI
                  WHERE P.gpiheure = FI.refelem
                    AND P.gpidepot = GP_CESS.refpiece
                    AND FI.dtannul_dt IS NULL
                    AND FI.dttraite IS NULL
                    AND P.dt02_dt IS NOT NULL) OR
                NVL(GP_CESS.fg16, 'I') <> 'C')
           AND EXISTS
         (SELECT 1
                  FROM g_piece FACTURES
                 WHERE FACTURES.gpidepot = GP_CESS.refpiece
                   AND NVL(FACTURES.st09, '@') <> 'RT'
                   AND FACTURES.dt02_dt IS NULL)
           AND (NOT EXISTS (SELECT 1
                              FROM t_gestfctcomp C, g_mangrp G
                             WHERE C.refmangrp = G.refmangrp
                               AND C.refperso = 13) OR
                GD_CONTRAT.reffactor IN
                (SELECT F.refindividu
                              FROM t_gestfctcomp C, g_mangrp G, t_fctmembmg F
                             WHERE C.refmangrp = G.refmangrp
                               AND G.refmangrp = F.refmangrp
                               AND C.refperso = 13))
           AND GD_DECOMPTE.reflot = GD_CONTRAT.refdoss
           AND GD_CONTRAT.categdoss LIKE 'CONTRAT%'
           AND GD_CONTRAT.refdoss = TI_CONTRAT.refdoss
           AND TI_CONTRAT.reftype =
               DECODE(GD_CONTRAT.categdoss, 'CONTRAT IMP', 'TC', 'CL')
           AND TI_CONTRAT.refindividu = GI_CONTRAT.refindividu
           AND TI_CONTRAT.refindividu = 'A90003S8'
           AND GP_CESS.dt05 = 2460129
           AND GP_CESS.gpidevis = 'EUR'
         GROUP BY TI_CONTRAT.refindividu,
                  NVL(GI_CONTRAT.REFEXT,
                      NVL(GI_CONTRAT.TVA, GI_CONTRAT.refindividu)),
                  GI_CONTRAT.nom,
                  GD_CONTRAT.refdoss,
                  GD_CONTRAT.ancrefdoss,
                  NVL(GP_CONTRAT.fg11, 'N'),
                  GP_PARAMCL.ST01,
                  GP_CESS.dt05_dt,
                  GP_CESS.dt08_dt,
                  GP_CESS.gpidevis
         ORDER BY NVL(GP_CONTRAT.fg11, 'N') DESC,
                  GP_PARAMCL.ST01,
                  TVA_CLIENT);


--ga9fs68q6sdt8


SELECT DT05_DT,
       GPIROLE,
       DT08_DT,
       GPIDEVIS,
       MT05,
       DT06_DT,
       DT07_DT,
       NB06,
       REFPIECE,
       CREATEUR,
       GPIADR3,
       FG55,
       FG56,
       GPIHEURE,
       REFDOSS_DECOMPTE
  FROM (SELECT GD_DECOMPTE.REFDOSS refdoss_DECOMPTE,
               GP_CESS.gpirole,
               GP_CESS.refpiece,
               GP_CESS.dt_creation_dt,
               GP_CESS.dt05_dt,
               GP_CESS.dt08_dt,
               GP_CESS.dt07_dt,
               GP_CESS.dt06_dt,
               GP_CESS.gpiheure,
               GP_CESS.mt05,
               GP_CESS.nb06,
               GP_CESS.gpidevis,
               GP_CESS.createur,
               GP_CESS.gpiadr3,
               GP_CESS.fg55,
               GP_CESS.fg56
          FROM g_piece        GP_FACT,
               g_elemfi       GE,
               g_dossier      GD_DECOMPTE,
               g_dossier      GD_CONTRAT,
               g_piece        GP_CESS,
               t_intervenants TI_CONTRAT
         WHERE GP_FACT.typpiece = 'FACTURE'
           AND GP_FACT.gpiheure = GE.refelem
           AND GP_FACT.dt02_dt IS NULL
           AND GD_DECOMPTE.categdoss LIKE 'DECOMPTE%'
           AND GP_FACT.gpidepot = GP_CESS.refpiece
           AND NOT EXISTS
         (SELECT 1
                  FROM MSG_QUEUE
                 WHERE REFDOSS = GD_DECOMPTE.REFDOSS
                   AND prty <> 0
                   AND BUFF LIKE 'valcess@' || GP_CESS.refpiece || '%')
           AND GD_DECOMPTE.refdoss = GP_CESS.refdoss
           AND GP_CESS.typpiece = 'CESSION'
           AND GP_CESS.st10 = 'OK'
           AND NVL(GP_FACT.fg33, 'N') <> 'O'
           AND GP_CESS.dt03_dt IS NULL
           AND (GP_CESS.fg16 = 'C' AND NOT EXISTS
                (SELECT 1
                   FROM g_piece P, g_elemfi FI
                  WHERE P.gpiheure = FI.refelem
                    AND P.gpidepot = GP_CESS.refpiece
                    AND FI.dtannul_dt IS NULL
                    AND FI.dttraite IS NULL
                    AND P.dt02_dt IS NOT NULL) OR
                NVL(GP_CESS.fg16, 'I') <> 'C')
           AND EXISTS
         (SELECT 1
                  FROM g_piece FACTURES
                 WHERE FACTURES.gpidepot = GP_CESS.refpiece
                   AND NVL(FACTURES.st09, '@') <> 'RT'
                   AND FACTURES.dt02_dt IS NULL)
           AND (NOT EXISTS (SELECT 1
                              FROM t_gestfctcomp C, g_mangrp G
                             WHERE C.refmangrp = G.refmangrp
                               AND C.refperso = 13) OR
                GD_CONTRAT.reffactor IN
                (SELECT F.refindividu
                              FROM t_gestfctcomp C, g_mangrp G, t_fctmembmg F
                             WHERE C.refmangrp = G.refmangrp
                               AND G.refmangrp = F.refmangrp
                               AND C.refperso = 13))
           AND GD_DECOMPTE.reflot = GD_CONTRAT.refdoss
           AND GD_CONTRAT.categdoss LIKE 'CONTRAT%'
           AND GD_CONTRAT.refdoss = TI_CONTRAT.refdoss
           AND TI_CONTRAT.reftype =
               DECODE(GD_CONTRAT.categdoss, 'CONTRAT IMP', 'TC', 'CL')
           AND ti_contrat.refindividu = 'A90003S8'
           AND GP_CESS.dt05 = 2460129
           AND GP_CESS.gpidevis = 'EUR'
           AND gd_contrat.refdoss = '0910150001'
         GROUP BY GD_DECOMPTE.REFDOSS,
                  GP_CESS.gpirole,
                  GP_CESS.refpiece,
                  GP_CESS.dt_creation_dt,
                  GP_CESS.dt05_dt,
                  GP_CESS.dt08_dt,
                  GP_CESS.dt07_dt,
                  GP_CESS.dt06_dt,
                  GP_CESS.gpiheure,
                  GP_CESS.mt05,
                  GP_CESS.nb06,
                  GP_CESS.gpidevis,
                  GP_CESS.createur,
                  GP_CESS.gpiadr3,
                  GP_CESS.fg55,
                  GP_CESS.fg56) LISTE_DB
 WHERE 1 = 1;

/********************************OLD SQL*******************************************/
/********************************OLD Metrics***************************************/
/*
--1svq3wtygymx2


Plan hash value: 3019008601
-------------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                        | Name                      | Starts | E-Rows | A-Rows |   A-Time   | Buffers | Reads  |
-------------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                                 |                           |      1 |        |      1 |00:00:47.56 |     175K|  79191 |
|   1 |  VIEW                                            |                           |      1 |      1 |      1 |00:00:47.56 |     175K|  79191 |
|   2 |   SORT GROUP BY                                  |                           |      1 |      1 |      1 |00:00:47.56 |     175K|  79191 |
|*  3 |    FILTER                                        |                           |      1 |        |     37 |00:00:47.56 |     175K|  79191 |
|   4 |     NESTED LOOPS SEMI                            |                           |      1 |      1 |     37 |00:00:47.56 |     175K|  79191 |
|   5 |      NESTED LOOPS                                |                           |      1 |      1 |     37 |00:00:47.56 |     175K|  79191 |
|   6 |       NESTED LOOPS                               |                           |      1 |      1 |     37 |00:00:47.55 |     175K|  79187 |
|   7 |        NESTED LOOPS ANTI                         |                           |      1 |      1 |      1 |00:00:47.55 |     175K|  79179 |
|   8 |         NESTED LOOPS                             |                           |      1 |      1 |      1 |00:00:47.55 |     175K|  79179 |
|   9 |          NESTED LOOPS                            |                           |      1 |      3 |     29 |00:00:00.01 |      96 |      7 |
|  10 |           NESTED LOOPS                           |                           |      1 |      3 |      2 |00:00:00.01 |      92 |      7 |
|  11 |            NESTED LOOPS                          |                           |      1 |     20 |      2 |00:00:00.01 |      82 |      4 |
|  12 |             MERGE JOIN CARTESIAN                 |                           |      1 |     82 |     82 |00:00:00.01 |       9 |      1 |
|  13 |              NESTED LOOPS OUTER                  |                           |      1 |      1 |      1 |00:00:00.01 |       7 |      1 |
|  14 |               TABLE ACCESS BY INDEX ROWID        | G_INDIVIDU                |      1 |      1 |      1 |00:00:00.01 |       4 |      0 |
|* 15 |                INDEX UNIQUE SCAN                 | IND_REFINDIV              |      1 |      1 |      1 |00:00:00.01 |       2 |      0 |
|  16 |               TABLE ACCESS BY INDEX ROWID BATCHED| G_PIECE                   |      1 |      1 |      0 |00:00:00.01 |       3 |      1 |
|* 17 |                INDEX RANGE SCAN                  | GP_GRTYPE_MT_DT           |      1 |      1 |      0 |00:00:00.01 |       3 |      1 |
|  18 |              BUFFER SORT                         |                           |      1 |     82 |     82 |00:00:00.01 |       2 |      0 |
|* 19 |               INDEX RANGE SCAN                   | INT_INDIV                 |      1 |     82 |     82 |00:00:00.01 |       2 |      0 |
|* 20 |             TABLE ACCESS BY INDEX ROWID          | G_DOSSIER                 |     82 |      1 |      2 |00:00:00.01 |      73 |      3 |
|* 21 |              INDEX UNIQUE SCAN                   | DOS_REFDOSS               |     82 |      1 |     82 |00:00:00.01 |      23 |      0 |
|  22 |            TABLE ACCESS BY INDEX ROWID BATCHED   | G_PIECE                   |      2 |      1 |      2 |00:00:00.01 |      10 |      3 |
|* 23 |             INDEX RANGE SCAN                     | PIE_REFDOSS               |      2 |      1 |      2 |00:00:00.01 |       8 |      1 |
|* 24 |           INDEX RANGE SCAN                       | G_DOSSIER_RL_CD_RD_RF_IDX |      2 |      1 |     29 |00:00:00.01 |       4 |      0 |
|* 25 |          TABLE ACCESS BY INDEX ROWID BATCHED     | G_PIECE                   |     29 |      1 |      1 |00:00:47.54 |     175K|  79172 |
|* 26 |           INDEX RANGE SCAN                       | PIE_REFDOSS               |     29 |    539 |  91358 |00:00:00.31 |     477 |    397 |
|* 27 |         TABLE ACCESS BY INDEX ROWID BATCHED      | MSG_QUEUE                 |      1 |      1 |      0 |00:00:00.01 |       1 |      0 |
|* 28 |          INDEX SKIP SCAN                         | PRTY_SEQ                  |      1 |      1 |      0 |00:00:00.01 |       1 |      0 |
|* 29 |        TABLE ACCESS BY INDEX ROWID BATCHED       | G_PIECE                   |      1 |     16 |     37 |00:00:00.01 |      52 |      8 |
|* 30 |         INDEX RANGE SCAN                         | GP_GPIDEP                 |      1 |     17 |     38 |00:00:00.01 |       4 |      1 |
|  31 |       TABLE ACCESS BY INDEX ROWID                | G_ELEMFI                  |     37 |      1 |     37 |00:00:00.01 |      63 |      4 |
|* 32 |        INDEX UNIQUE SCAN                         | EFI_REFELEM               |     37 |      1 |     37 |00:00:00.01 |      26 |      1 |
|* 33 |      INDEX RANGE SCAN                            | GP_GPIDEP                 |     37 |     16M|     37 |00:00:00.01 |      13 |      0 |
|  34 |     NESTED LOOPS SEMI                            |                           |      1 |      1 |      1 |00:00:00.01 |       2 |      0 |
|  35 |      INDEX FULL SCAN                             | PK_G_MANGRP               |      1 |      2 |      1 |00:00:00.01 |       1 |      0 |
|* 36 |      INDEX SKIP SCAN                             | PK_T_GESTFCTCOMP          |      1 |      1 |      1 |00:00:00.01 |       1 |      0 |
|  37 |     NESTED LOOPS SEMI                            |                           |      1 |      1 |      1 |00:00:00.01 |       3 |      0 |
|  38 |      NESTED LOOPS                                |                           |      1 |      1 |      1 |00:00:00.01 |       2 |      0 |
|* 39 |       INDEX RANGE SCAN                           | PK_T_FCTMEMBMG            |      1 |      1 |      1 |00:00:00.01 |       1 |      0 |
|* 40 |       INDEX UNIQUE SCAN                          | PK_G_MANGRP               |      1 |      1 |      1 |00:00:00.01 |       1 |      0 |
|* 41 |      INDEX SKIP SCAN                             | PK_T_GESTFCTCOMP          |      1 |      1 |      1 |00:00:00.01 |       1 |      0 |
|  42 |     NESTED LOOPS SEMI                            |                           |      1 |      1 |      0 |00:00:00.01 |       4 |      0 |
|  43 |      TABLE ACCESS BY INDEX ROWID BATCHED         | G_PIECE                   |      1 |      2 |      0 |00:00:00.01 |       4 |      0 |
|* 44 |       INDEX RANGE SCAN                           | GP_GPIDEP                 |      1 |      2 |      0 |00:00:00.01 |       4 |      0 |
|* 45 |      TABLE ACCESS BY INDEX ROWID                 | G_ELEMFI                  |      0 |      1 |      0 |00:00:00.01 |       0 |      0 |
|* 46 |       INDEX UNIQUE SCAN                          | EFI_REFELEM               |      0 |      1 |      0 |00:00:00.01 |       0 |      0 |
-------------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   3 - filter((( IS NULL OR  IS NOT NULL) AND (NVL("GP_CESS"."FG16",'I')<>'C' OR ("GP_CESS"."FG16"='C' AND  IS NULL))))
  15 - access("GI_CONTRAT"."REFINDIVIDU"='A90003S8')
  17 - access("GP_PARAMCL"."TYPPIECE"='CLIENT_PARAMS' AND "GP_PARAMCL"."GPIHEURE"='A90003S8')
  19 - access("TI_CONTRAT"."REFINDIVIDU"='A90003S8')
  20 - filter(("GD_CONTRAT"."CATEGDOSS" LIKE 'CONTRAT%' AND "TI_CONTRAT"."REFTYPE"=DECODE("GD_CONTRAT"."CATEGDOSS",'CONTRAT
              IMP','TC','CL')))
  21 - access("GD_CONTRAT"."REFDOSS"="TI_CONTRAT"."REFDOSS")
  23 - access("GP_CONTRAT"."REFDOSS"="GD_CONTRAT"."REFDOSS" AND "GP_CONTRAT"."TYPPIECE"='CONTRAT')
  24 - access("GD_DECOMPTE"."REFLOT"="GD_CONTRAT"."REFDOSS" AND "GD_DECOMPTE"."CATEGDOSS" LIKE 'DECOMPTE%')
       filter("GD_DECOMPTE"."CATEGDOSS" LIKE 'DECOMPTE%')
  25 - filter(("GP_CESS"."DT05"=2460129 AND "GP_CESS"."GPIDEVIS"='EUR' AND "GP_CESS"."ST10"='OK' AND "GP_CESS"."DT03_DT" IS NULL))
  26 - access("GD_DECOMPTE"."REFDOSS"="GP_CESS"."REFDOSS" AND "GP_CESS"."TYPPIECE"='CESSION')
  27 - filter("BUFF" LIKE 'valcess@'||"GP_CESS"."REFPIECE"||'%')
  28 - access("REFDOSS"="GD_DECOMPTE"."REFDOSS")
       filter(("REFDOSS"="GD_DECOMPTE"."REFDOSS" AND "PRTY"<>0))
  29 - filter(("GP_FACT"."TYPPIECE"='FACTURE' AND NVL("GP_FACT"."FG33",'N')<>'O'))
  30 - access("GP_FACT"."GPIDEPOT"="GP_CESS"."REFPIECE" AND "GP_FACT"."DT02_DT" IS NULL)
       filter("GP_FACT"."DT02_DT" IS NULL)
  32 - access("GP_FACT"."GPIHEURE"="GE"."REFELEM")
  33 - access("FACTURES"."GPIDEPOT"="GP_CESS"."REFPIECE" AND "FACTURES"."DT02_DT" IS NULL)
       filter(("FACTURES"."DT02_DT" IS NULL AND NVL("FACTURES"."ST09",'@')<>'RT'))
  36 - access("C"."REFMANGRP"="G"."REFMANGRP")
       filter(("C"."REFMANGRP"="G"."REFMANGRP" AND TO_NUMBER("C"."REFPERSO")=13))
  39 - access("F"."REFINDIVIDU"=:B1)
  40 - access("G"."REFMANGRP"="F"."REFMANGRP")
  41 - access("C"."REFMANGRP"="G"."REFMANGRP")
       filter(("C"."REFMANGRP"="G"."REFMANGRP" AND TO_NUMBER("C"."REFPERSO")=13))
  44 - access("P"."GPIDEPOT"=:B1)
       filter("P"."DT02_DT" IS NOT NULL)
  45 - filter(("FI"."DTTRAITE" IS NULL AND "FI"."DTANNUL_DT" IS NULL))
  46 - access("P"."GPIHEURE"="FI"."REFELEM")


--ga9fs68q6sdt8


Plan hash value: 4169276850
-------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                  | Name                      | Starts | E-Rows | A-Rows |   A-Time   | Buffers | Reads  |
-------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                           |                           |      1 |        |      1 |00:00:45.03 |     102K|  45848 |
|   1 |  HASH GROUP BY                             |                           |      1 |      1 |      1 |00:00:45.03 |     102K|  45848 |
|*  2 |   FILTER                                   |                           |      1 |        |     37 |00:00:45.03 |     102K|  45848 |
|   3 |    NESTED LOOPS SEMI                       |                           |      1 |      1 |     37 |00:00:45.03 |     102K|  45848 |
|   4 |     NESTED LOOPS SEMI                      |                           |      1 |      1 |     37 |00:00:45.03 |     102K|  45848 |
|   5 |      NESTED LOOPS                          |                           |      1 |      1 |     37 |00:00:45.03 |     102K|  45847 |
|   6 |       NESTED LOOPS ANTI                    |                           |      1 |      1 |      1 |00:00:45.02 |     102K|  45839 |
|   7 |        NESTED LOOPS                        |                           |      1 |      1 |      1 |00:00:45.02 |     102K|  45839 |
|   8 |         MERGE JOIN CARTESIAN               |                           |      1 |      1 |     15 |00:00:00.01 |       8 |      0 |
|   9 |          NESTED LOOPS SEMI                 |                           |      1 |      1 |      1 |00:00:00.01 |       6 |      0 |
|* 10 |           TABLE ACCESS BY INDEX ROWID      | G_DOSSIER                 |      1 |      1 |      1 |00:00:00.01 |       4 |      0 |
|* 11 |            INDEX UNIQUE SCAN               | DOS_REFDOSS               |      1 |      1 |      1 |00:00:00.01 |       2 |      0 |
|* 12 |           INDEX RANGE SCAN                 | INT_INDIV                 |      1 |      1 |      1 |00:00:00.01 |       2 |      0 |
|  13 |          BUFFER SORT                       |                           |      1 |      2 |     15 |00:00:00.01 |       2 |      0 |
|* 14 |           INDEX RANGE SCAN                 | G_DOSSIER_RL_CD_RD_RF_IDX |      1 |      2 |     15 |00:00:00.01 |       2 |      0 |
|* 15 |         TABLE ACCESS BY INDEX ROWID BATCHED| G_PIECE                   |     15 |      1 |      1 |00:00:45.02 |     102K|  45839 |
|* 16 |          INDEX RANGE SCAN                  | PIE_REFDOSS               |     15 |    539 |  53136 |00:00:00.26 |     277 |    231 |
|* 17 |        TABLE ACCESS BY INDEX ROWID BATCHED | MSG_QUEUE                 |      1 |      1 |      0 |00:00:00.01 |       1 |      0 |
|* 18 |         INDEX SKIP SCAN                    | PRTY_SEQ                  |      1 |      1 |      0 |00:00:00.01 |       1 |      0 |
|* 19 |       TABLE ACCESS BY INDEX ROWID BATCHED  | G_PIECE                   |      1 |     16 |     37 |00:00:00.01 |      52 |      8 |
|* 20 |        INDEX RANGE SCAN                    | GP_GPIDEP                 |      1 |     17 |     38 |00:00:00.01 |       4 |      1 |
|* 21 |      INDEX UNIQUE SCAN                     | EFI_REFELEM               |     37 |      1 |     37 |00:00:00.01 |      26 |      1 |
|* 22 |     INDEX RANGE SCAN                       | GP_GPIDEP                 |     37 |     16M|     37 |00:00:00.01 |      13 |      0 |
|  23 |    NESTED LOOPS SEMI                       |                           |      1 |      1 |      1 |00:00:00.01 |       2 |      0 |
|  24 |     INDEX FULL SCAN                        | PK_G_MANGRP               |      1 |      2 |      1 |00:00:00.01 |       1 |      0 |
|* 25 |     INDEX SKIP SCAN                        | PK_T_GESTFCTCOMP          |      1 |      1 |      1 |00:00:00.01 |       1 |      0 |
|  26 |    NESTED LOOPS SEMI                       |                           |      1 |      1 |      1 |00:00:00.01 |       3 |      0 |
|  27 |     NESTED LOOPS                           |                           |      1 |      1 |      1 |00:00:00.01 |       2 |      0 |
|* 28 |      INDEX RANGE SCAN                      | PK_T_FCTMEMBMG            |      1 |      1 |      1 |00:00:00.01 |       1 |      0 |
|* 29 |      INDEX UNIQUE SCAN                     | PK_G_MANGRP               |      1 |      1 |      1 |00:00:00.01 |       1 |      0 |
|* 30 |     INDEX SKIP SCAN                        | PK_T_GESTFCTCOMP          |      1 |      1 |      1 |00:00:00.01 |       1 |      0 |
|  31 |    NESTED LOOPS SEMI                       |                           |      1 |      1 |      0 |00:00:00.01 |       4 |      0 |
|  32 |     TABLE ACCESS BY INDEX ROWID BATCHED    | G_PIECE                   |      1 |      2 |      0 |00:00:00.01 |       4 |      0 |
|* 33 |      INDEX RANGE SCAN                      | GP_GPIDEP                 |      1 |      2 |      0 |00:00:00.01 |       4 |      0 |
|* 34 |     TABLE ACCESS BY INDEX ROWID            | G_ELEMFI                  |      0 |      1 |      0 |00:00:00.01 |       0 |      0 |
|* 35 |      INDEX UNIQUE SCAN                     | EFI_REFELEM               |      0 |      1 |      0 |00:00:00.01 |       0 |      0 |
-------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   2 - filter((( IS NULL OR  IS NOT NULL) AND (NVL("GP_CESS"."FG16",'I')<>'C' OR ("GP_CESS"."FG16"='C' AND  IS NULL))))
  10 - filter("GD_CONTRAT"."CATEGDOSS" LIKE 'CONTRAT%')
  11 - access("GD_CONTRAT"."REFDOSS"='0910150001')
  12 - access("TI_CONTRAT"."REFINDIVIDU"='A90003S8' AND "TI_CONTRAT"."REFTYPE"=DECODE("GD_CONTRAT"."CATEGDOSS",'CONTRAT
              IMP','TC','CL') AND "TI_CONTRAT"."REFDOSS"='0910150001')
  14 - access("GD_DECOMPTE"."REFLOT"='0910150001' AND "GD_DECOMPTE"."CATEGDOSS" LIKE 'DECOMPTE%')
       filter("GD_DECOMPTE"."CATEGDOSS" LIKE 'DECOMPTE%')
  15 - filter(("GP_CESS"."DT05"=2460129 AND "GP_CESS"."GPIDEVIS"='EUR' AND "GP_CESS"."ST10"='OK' AND "GP_CESS"."DT03_DT" IS NULL))
  16 - access("GD_DECOMPTE"."REFDOSS"="GP_CESS"."REFDOSS" AND "GP_CESS"."TYPPIECE"='CESSION')
  17 - filter("BUFF" LIKE 'valcess@'||"GP_CESS"."REFPIECE"||'%')
  18 - access("REFDOSS"="GD_DECOMPTE"."REFDOSS")
       filter(("PRTY"<>0 AND "REFDOSS"="GD_DECOMPTE"."REFDOSS"))
  19 - filter(("GP_FACT"."TYPPIECE"='FACTURE' AND NVL("GP_FACT"."FG33",'N')<>'O'))
  20 - access("GP_FACT"."GPIDEPOT"="GP_CESS"."REFPIECE" AND "GP_FACT"."DT02_DT" IS NULL)
       filter("GP_FACT"."DT02_DT" IS NULL)
  21 - access("GP_FACT"."GPIHEURE"="GE"."REFELEM")
  22 - access("FACTURES"."GPIDEPOT"="GP_CESS"."REFPIECE" AND "FACTURES"."DT02_DT" IS NULL)
       filter(("FACTURES"."DT02_DT" IS NULL AND NVL("FACTURES"."ST09",'@')<>'RT'))
  25 - access("C"."REFMANGRP"="G"."REFMANGRP")
       filter(("C"."REFMANGRP"="G"."REFMANGRP" AND TO_NUMBER("C"."REFPERSO")=13))
  28 - access("F"."REFINDIVIDU"=:B1)
  29 - access("G"."REFMANGRP"="F"."REFMANGRP")
  30 - access("C"."REFMANGRP"="G"."REFMANGRP")
       filter(("C"."REFMANGRP"="G"."REFMANGRP" AND TO_NUMBER("C"."REFPERSO")=13))
  33 - access("P"."GPIDEPOT"=:B1)
       filter("P"."DT02_DT" IS NOT NULL)
  34 - filter(("FI"."DTTRAITE" IS NULL AND "FI"."DTANNUL_DT" IS NULL))
  35 - access("P"."GPIHEURE"="FI"."REFELEM")
*/
/********************************OLD Metrics***************************************/

/********************************New SQL*******************************************/

;
/********************************New SQL*******************************************/
/********************************New Metrics***************************************/
/*
--1svq3wtygymx2


Plan hash value: 3892354261
-------------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                        | Name                      | Starts | E-Rows | A-Rows |   A-Time   | Buffers | Reads  |
-------------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                                 |                           |      1 |        |      1 |00:00:00.03 |     335 |     43 |
|   1 |  VIEW                                            |                           |      1 |      1 |      1 |00:00:00.03 |     335 |     43 |
|   2 |   SORT GROUP BY                                  |                           |      1 |      1 |      1 |00:00:00.03 |     335 |     43 |
|*  3 |    FILTER                                        |                           |      1 |        |     37 |00:00:00.03 |     335 |     43 |
|   4 |     NESTED LOOPS SEMI                            |                           |      1 |      1 |     37 |00:00:00.03 |     326 |     43 |
|   5 |      NESTED LOOPS                                |                           |      1 |      1 |     37 |00:00:00.03 |     313 |     43 |
|   6 |       NESTED LOOPS                               |                           |      1 |      1 |     37 |00:00:00.02 |     250 |     39 |
|   7 |        NESTED LOOPS ANTI                         |                           |      1 |      1 |      1 |00:00:00.02 |     198 |     32 |
|   8 |         NESTED LOOPS                             |                           |      1 |      1 |      1 |00:00:00.02 |     197 |     32 |
|   9 |          NESTED LOOPS                            |                           |      1 |      3 |     29 |00:00:00.01 |      96 |     14 |
|  10 |           NESTED LOOPS                           |                           |      1 |      3 |      2 |00:00:00.01 |      92 |     12 |
|  11 |            NESTED LOOPS                          |                           |      1 |     20 |      2 |00:00:00.01 |      82 |      6 |
|  12 |             MERGE JOIN CARTESIAN                 |                           |      1 |     82 |     82 |00:00:00.01 |       9 |      2 |
|  13 |              NESTED LOOPS OUTER                  |                           |      1 |      1 |      1 |00:00:00.01 |       7 |      1 |
|  14 |               TABLE ACCESS BY INDEX ROWID        | G_INDIVIDU                |      1 |      1 |      1 |00:00:00.01 |       4 |      0 |
|* 15 |                INDEX UNIQUE SCAN                 | IND_REFINDIV              |      1 |      1 |      1 |00:00:00.01 |       2 |      0 |
|  16 |               TABLE ACCESS BY INDEX ROWID BATCHED| G_PIECE                   |      1 |      1 |      0 |00:00:00.01 |       3 |      1 |
|* 17 |                INDEX RANGE SCAN                  | GP_GRTYPE_MT_DT           |      1 |      1 |      0 |00:00:00.01 |       3 |      1 |
|  18 |              BUFFER SORT                         |                           |      1 |     82 |     82 |00:00:00.01 |       2 |      1 |
|* 19 |               INDEX RANGE SCAN                   | INT_INDIV                 |      1 |     82 |     82 |00:00:00.01 |       2 |      1 |
|* 20 |             TABLE ACCESS BY INDEX ROWID          | G_DOSSIER                 |     82 |      1 |      2 |00:00:00.01 |      73 |      4 |
|* 21 |              INDEX UNIQUE SCAN                   | DOS_REFDOSS               |     82 |      1 |     82 |00:00:00.01 |      23 |      0 |
|  22 |            TABLE ACCESS BY INDEX ROWID BATCHED   | G_PIECE                   |      2 |      1 |      2 |00:00:00.01 |      10 |      6 |
|* 23 |             INDEX RANGE SCAN                     | GP_REF_TYPPI_DT_IDX       |      2 |      1 |      2 |00:00:00.01 |       8 |      4 |
|* 24 |           INDEX RANGE SCAN                       | G_DOSSIER_RL_CD_RD_RF_IDX |      2 |      1 |     29 |00:00:00.01 |       4 |      2 |
|* 25 |          TABLE ACCESS BY INDEX ROWID BATCHED     | G_PIECE                   |     29 |      1 |      1 |00:00:00.01 |     101 |     18 |
|* 26 |           INDEX RANGE SCAN                       | GP_REF_TYPPI_DT_IDX       |     29 |      5 |      5 |00:00:00.01 |      91 |     14 |
|* 27 |         TABLE ACCESS BY INDEX ROWID BATCHED      | MSG_QUEUE                 |      1 |      1 |      0 |00:00:00.01 |       1 |      0 |
|* 28 |          INDEX SKIP SCAN                         | PRTY_SEQ                  |      1 |      1 |      0 |00:00:00.01 |       1 |      0 |
|* 29 |        TABLE ACCESS BY INDEX ROWID BATCHED       | G_PIECE                   |      1 |     16 |     37 |00:00:00.01 |      52 |      7 |
|* 30 |         INDEX RANGE SCAN                         | GP_GPIDEP                 |      1 |     17 |     38 |00:00:00.01 |       4 |      0 |
|  31 |       TABLE ACCESS BY INDEX ROWID                | G_ELEMFI                  |     37 |      1 |     37 |00:00:00.01 |      63 |      4 |
|* 32 |        INDEX UNIQUE SCAN                         | EFI_REFELEM               |     37 |      1 |     37 |00:00:00.01 |      26 |      1 |
|* 33 |      INDEX RANGE SCAN                            | GP_GPIDEP                 |     37 |     16M|     37 |00:00:00.01 |      13 |      0 |
|  34 |     NESTED LOOPS SEMI                            |                           |      1 |      1 |      1 |00:00:00.01 |       2 |      0 |
|  35 |      INDEX FULL SCAN                             | PK_G_MANGRP               |      1 |      2 |      1 |00:00:00.01 |       1 |      0 |
|* 36 |      INDEX SKIP SCAN                             | PK_T_GESTFCTCOMP          |      1 |      1 |      1 |00:00:00.01 |       1 |      0 |
|  37 |     NESTED LOOPS SEMI                            |                           |      1 |      1 |      1 |00:00:00.01 |       3 |      0 |
|  38 |      NESTED LOOPS                                |                           |      1 |      1 |      1 |00:00:00.01 |       2 |      0 |
|* 39 |       INDEX RANGE SCAN                           | PK_T_FCTMEMBMG            |      1 |      1 |      1 |00:00:00.01 |       1 |      0 |
|* 40 |       INDEX UNIQUE SCAN                          | PK_G_MANGRP               |      1 |      1 |      1 |00:00:00.01 |       1 |      0 |
|* 41 |      INDEX SKIP SCAN                             | PK_T_GESTFCTCOMP          |      1 |      1 |      1 |00:00:00.01 |       1 |      0 |
|  42 |     NESTED LOOPS SEMI                            |                           |      1 |      1 |      0 |00:00:00.01 |       4 |      0 |
|  43 |      TABLE ACCESS BY INDEX ROWID BATCHED         | G_PIECE                   |      1 |      2 |      0 |00:00:00.01 |       4 |      0 |
|* 44 |       INDEX RANGE SCAN                           | GP_GPIDEP                 |      1 |      2 |      0 |00:00:00.01 |       4 |      0 |
|* 45 |      TABLE ACCESS BY INDEX ROWID                 | G_ELEMFI                  |      0 |      1 |      0 |00:00:00.01 |       0 |      0 |
|* 46 |       INDEX UNIQUE SCAN                          | EFI_REFELEM               |      0 |      1 |      0 |00:00:00.01 |       0 |      0 |
-------------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   3 - filter((( IS NULL OR  IS NOT NULL) AND (NVL("GP_CESS"."FG16",'I')<>'C' OR ("GP_CESS"."FG16"='C' AND  IS NULL))))
  15 - access("GI_CONTRAT"."REFINDIVIDU"='A90003S8')
  17 - access("GP_PARAMCL"."TYPPIECE"='CLIENT_PARAMS' AND "GP_PARAMCL"."GPIHEURE"='A90003S8')
  19 - access("TI_CONTRAT"."REFINDIVIDU"='A90003S8')
  20 - filter(("GD_CONTRAT"."CATEGDOSS" LIKE 'CONTRAT%' AND "TI_CONTRAT"."REFTYPE"=DECODE("GD_CONTRAT"."CATEGDOSS",'CONTRAT
              IMP','TC','CL')))
  21 - access("GD_CONTRAT"."REFDOSS"="TI_CONTRAT"."REFDOSS")
  23 - access("GP_CONTRAT"."REFDOSS"="GD_CONTRAT"."REFDOSS" AND "GP_CONTRAT"."TYPPIECE"='CONTRAT')
  24 - access("GD_DECOMPTE"."REFLOT"="GD_CONTRAT"."REFDOSS" AND "GD_DECOMPTE"."CATEGDOSS" LIKE 'DECOMPTE%')
       filter("GD_DECOMPTE"."CATEGDOSS" LIKE 'DECOMPTE%')
  25 - filter(("GP_CESS"."GPIDEVIS"='EUR' AND "GP_CESS"."ST10"='OK' AND "GP_CESS"."DT03_DT" IS NULL))
  26 - access("GD_DECOMPTE"."REFDOSS"="GP_CESS"."REFDOSS" AND "GP_CESS"."TYPPIECE"='CESSION' AND "GP_CESS"."DT05"=2460129)
  27 - filter("BUFF" LIKE 'valcess@'||"GP_CESS"."REFPIECE"||'%')
  28 - access("REFDOSS"="GD_DECOMPTE"."REFDOSS")
       filter(("REFDOSS"="GD_DECOMPTE"."REFDOSS" AND "PRTY"<>0))
  29 - filter(("GP_FACT"."TYPPIECE"='FACTURE' AND NVL("GP_FACT"."FG33",'N')<>'O'))
  30 - access("GP_FACT"."GPIDEPOT"="GP_CESS"."REFPIECE" AND "GP_FACT"."DT02_DT" IS NULL)
       filter("GP_FACT"."DT02_DT" IS NULL)
  32 - access("GP_FACT"."GPIHEURE"="GE"."REFELEM")
  33 - access("FACTURES"."GPIDEPOT"="GP_CESS"."REFPIECE" AND "FACTURES"."DT02_DT" IS NULL)
       filter(("FACTURES"."DT02_DT" IS NULL AND NVL("FACTURES"."ST09",'@')<>'RT'))
  36 - access("C"."REFMANGRP"="G"."REFMANGRP")
       filter(("C"."REFMANGRP"="G"."REFMANGRP" AND TO_NUMBER("C"."REFPERSO")=13))
  39 - access("F"."REFINDIVIDU"=:B1)
  40 - access("G"."REFMANGRP"="F"."REFMANGRP")
  41 - access("C"."REFMANGRP"="G"."REFMANGRP")
       filter(("C"."REFMANGRP"="G"."REFMANGRP" AND TO_NUMBER("C"."REFPERSO")=13))
  44 - access("P"."GPIDEPOT"=:B1)
       filter("P"."DT02_DT" IS NOT NULL)
  45 - filter(("FI"."DTTRAITE" IS NULL AND "FI"."DTANNUL_DT" IS NULL))
  46 - access("P"."GPIHEURE"="FI"."REFELEM")



--ga9fs68q6sdt8


Plan hash value: 3678683036
----------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                  | Name                      | Starts | E-Rows | A-Rows |   A-Time   | Buffers |
----------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                           |                           |      1 |        |      1 |00:00:00.01 |     164 |
|   1 |  HASH GROUP BY                             |                           |      1 |      1 |      1 |00:00:00.01 |     164 |
|*  2 |   FILTER                                   |                           |      1 |        |     37 |00:00:00.01 |     164 |
|   3 |    NESTED LOOPS SEMI                       |                           |      1 |      1 |     37 |00:00:00.01 |     155 |
|   4 |     NESTED LOOPS SEMI                      |                           |      1 |      1 |     37 |00:00:00.01 |     142 |
|   5 |      NESTED LOOPS                          |                           |      1 |      1 |     37 |00:00:00.01 |     116 |
|   6 |       NESTED LOOPS ANTI                    |                           |      1 |      1 |      1 |00:00:00.01 |      64 |
|   7 |        NESTED LOOPS                        |                           |      1 |      1 |      1 |00:00:00.01 |      63 |
|   8 |         MERGE JOIN CARTESIAN               |                           |      1 |      1 |     15 |00:00:00.01 |       8 |
|   9 |          NESTED LOOPS SEMI                 |                           |      1 |      1 |      1 |00:00:00.01 |       6 |
|* 10 |           TABLE ACCESS BY INDEX ROWID      | G_DOSSIER                 |      1 |      1 |      1 |00:00:00.01 |       4 |
|* 11 |            INDEX UNIQUE SCAN               | DOS_REFDOSS               |      1 |      1 |      1 |00:00:00.01 |       2 |
|* 12 |           INDEX RANGE SCAN                 | INT_INDIV                 |      1 |      1 |      1 |00:00:00.01 |       2 |
|  13 |          BUFFER SORT                       |                           |      1 |      2 |     15 |00:00:00.01 |       2 |
|* 14 |           INDEX RANGE SCAN                 | G_DOSSIER_RL_CD_RD_RF_IDX |      1 |      2 |     15 |00:00:00.01 |       2 |
|* 15 |         TABLE ACCESS BY INDEX ROWID BATCHED| G_PIECE                   |     15 |      1 |      1 |00:00:00.01 |      55 |
|* 16 |          INDEX RANGE SCAN                  | GP_REF_TYPPI_DT_IDX       |     15 |      5 |      4 |00:00:00.01 |      47 |
|* 17 |        TABLE ACCESS BY INDEX ROWID BATCHED | MSG_QUEUE                 |      1 |      1 |      0 |00:00:00.01 |       1 |
|* 18 |         INDEX SKIP SCAN                    | PRTY_SEQ                  |      1 |      1 |      0 |00:00:00.01 |       1 |
|* 19 |       TABLE ACCESS BY INDEX ROWID BATCHED  | G_PIECE                   |      1 |     16 |     37 |00:00:00.01 |      52 |
|* 20 |        INDEX RANGE SCAN                    | GP_GPIDEP                 |      1 |     17 |     38 |00:00:00.01 |       4 |
|* 21 |      INDEX UNIQUE SCAN                     | EFI_REFELEM               |     37 |      1 |     37 |00:00:00.01 |      26 |
|* 22 |     INDEX RANGE SCAN                       | GP_GPIDEP                 |     37 |     16M|     37 |00:00:00.01 |      13 |
|  23 |    NESTED LOOPS SEMI                       |                           |      1 |      1 |      1 |00:00:00.01 |       2 |
|  24 |     INDEX FULL SCAN                        | PK_G_MANGRP               |      1 |      2 |      1 |00:00:00.01 |       1 |
|* 25 |     INDEX SKIP SCAN                        | PK_T_GESTFCTCOMP          |      1 |      1 |      1 |00:00:00.01 |       1 |
|  26 |    NESTED LOOPS SEMI                       |                           |      1 |      1 |      1 |00:00:00.01 |       3 |
|  27 |     NESTED LOOPS                           |                           |      1 |      1 |      1 |00:00:00.01 |       2 |
|* 28 |      INDEX RANGE SCAN                      | PK_T_FCTMEMBMG            |      1 |      1 |      1 |00:00:00.01 |       1 |
|* 29 |      INDEX UNIQUE SCAN                     | PK_G_MANGRP               |      1 |      1 |      1 |00:00:00.01 |       1 |
|* 30 |     INDEX SKIP SCAN                        | PK_T_GESTFCTCOMP          |      1 |      1 |      1 |00:00:00.01 |       1 |
|  31 |    NESTED LOOPS SEMI                       |                           |      1 |      1 |      0 |00:00:00.01 |       4 |
|  32 |     TABLE ACCESS BY INDEX ROWID BATCHED    | G_PIECE                   |      1 |      2 |      0 |00:00:00.01 |       4 |
|* 33 |      INDEX RANGE SCAN                      | GP_GPIDEP                 |      1 |      2 |      0 |00:00:00.01 |       4 |
|* 34 |     TABLE ACCESS BY INDEX ROWID            | G_ELEMFI                  |      0 |      1 |      0 |00:00:00.01 |       0 |
|* 35 |      INDEX UNIQUE SCAN                     | EFI_REFELEM               |      0 |      1 |      0 |00:00:00.01 |       0 |
----------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   2 - filter((( IS NULL OR  IS NOT NULL) AND (NVL("GP_CESS"."FG16",'I')<>'C' OR ("GP_CESS"."FG16"='C' AND  IS NULL))))
  10 - filter("GD_CONTRAT"."CATEGDOSS" LIKE 'CONTRAT%')
  11 - access("GD_CONTRAT"."REFDOSS"='0910150001')
  12 - access("TI_CONTRAT"."REFINDIVIDU"='A90003S8' AND "TI_CONTRAT"."REFTYPE"=DECODE("GD_CONTRAT"."CATEGDOSS",'CONTRAT
              IMP','TC','CL') AND "TI_CONTRAT"."REFDOSS"='0910150001')
  14 - access("GD_DECOMPTE"."REFLOT"='0910150001' AND "GD_DECOMPTE"."CATEGDOSS" LIKE 'DECOMPTE%')
       filter("GD_DECOMPTE"."CATEGDOSS" LIKE 'DECOMPTE%')
  15 - filter(("GP_CESS"."GPIDEVIS"='EUR' AND "GP_CESS"."ST10"='OK' AND "GP_CESS"."DT03_DT" IS NULL))
  16 - access("GD_DECOMPTE"."REFDOSS"="GP_CESS"."REFDOSS" AND "GP_CESS"."TYPPIECE"='CESSION' AND "GP_CESS"."DT05"=2460129)
  17 - filter("BUFF" LIKE 'valcess@'||"GP_CESS"."REFPIECE"||'%')
  18 - access("REFDOSS"="GD_DECOMPTE"."REFDOSS")
       filter(("PRTY"<>0 AND "REFDOSS"="GD_DECOMPTE"."REFDOSS"))
  19 - filter(("GP_FACT"."TYPPIECE"='FACTURE' AND NVL("GP_FACT"."FG33",'N')<>'O'))
  20 - access("GP_FACT"."GPIDEPOT"="GP_CESS"."REFPIECE" AND "GP_FACT"."DT02_DT" IS NULL)
       filter("GP_FACT"."DT02_DT" IS NULL)
  21 - access("GP_FACT"."GPIHEURE"="GE"."REFELEM")
  22 - access("FACTURES"."GPIDEPOT"="GP_CESS"."REFPIECE" AND "FACTURES"."DT02_DT" IS NULL)
       filter(("FACTURES"."DT02_DT" IS NULL AND NVL("FACTURES"."ST09",'@')<>'RT'))
  25 - access("C"."REFMANGRP"="G"."REFMANGRP")
       filter(("C"."REFMANGRP"="G"."REFMANGRP" AND TO_NUMBER("C"."REFPERSO")=13))
  28 - access("F"."REFINDIVIDU"=:B1)
  29 - access("G"."REFMANGRP"="F"."REFMANGRP")
  30 - access("C"."REFMANGRP"="G"."REFMANGRP")
       filter(("C"."REFMANGRP"="G"."REFMANGRP" AND TO_NUMBER("C"."REFPERSO")=13))
  33 - access("P"."GPIDEPOT"=:B1)
       filter("P"."DT02_DT" IS NOT NULL)
  34 - filter(("FI"."DTTRAITE" IS NULL AND "FI"."DTANNUL_DT" IS NULL))
  35 - access("P"."GPIHEURE"="FI"."REFELEM")
*/
/********************************New Metrics***************************************/

/********************************Index statistics**********************************/

/********************************Other SQLs****************************************/          
/*

*/ 
/********************************Other SQLs****************************************/              
