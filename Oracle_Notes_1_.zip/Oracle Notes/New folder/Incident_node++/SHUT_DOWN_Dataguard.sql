##### Shuting down Dataguard (Primary and physical standby ####



1) shutdown Primary :

Stop monitoring:
[root@isecdb2 ~]# dbspicol OFF

Change home 'Y' value to 'N' in oratab file:
[oracle@isecdb2-INFRAP2-/home/oracle]> vi /etc/oratab 

[oracle@isecdb2-INFRAP2-/home/oracle]> ps -ef | grep pmon
oracle    12808      1  0 Sep13 ?        00:03:49 ora_pmon_INFRAP2
oracle    95631  93043  0 12:19 pts/0    00:00:00 grep --color=auto pmon

[oracle@isecdb2-INFRAP2-/home/oracle]> ps -ef | grep tns
root         69      2  0 Sep13 ?        00:00:00 [netns]
oracle    12560      1  0 Sep13 ?        00:09:23 /u01/app/oracle/product/12.1.0.2/dbhome_1/bin/tnslsnr LISTENER -inherit
oracle    95636  93043  0 12:19 pts/0    00:00:00 grep --color=auto tns

[oracle@isecdb2-INFRAP2-/home/oracle]> sqlplus "/as sysdba"

SQL> alter system set log_archive_dest_state_2=defer;     СПИРАМ ШИПИНГА НА ЛОГОВЕ КЪМ СТЕНДБАЯ
SQL> alter system switch logfile;      ЗАПИСВА ИНФОРМАЦИЯТА ОТ КЪРЕНТ ЛОГ ФАЙЛА И ПОЧВА В НОВ 
SQL> shut immediate;
SQL> exit

[oracle@isecdb2-INFRAP2-/home/oracle]> lsnrctl stop LISTENER




===========================================================================

2) shutdown Standby:

Change home 'Y' value to 'N' in oratab file:
[oracle@isecdb1-INFRAP1-/home/oracle]> vi /etc/oratab

[oracle@isecdb1-INFRAP1-/home/oracle]> ps -ef | grep pmon
oracle    26622      1  0 Sep17 ?        00:02:48 ora_pmon_INFRAP1
oracle    27785  19015  0 12:34 pts/0    00:00:00 grep --color=auto pmon

[oracle@isecdb1-INFRAP1-/home/oracle]> ps -ef | grep tns
root         69      2  0 Sep17 ?        00:00:00 [netns]
oracle    14896      1  0 Sep17 ?        00:00:39 /u01/app/oracle/product/12.1.0.2/dbhome_1/bin/tnslsnr LISTENER -inherit
oracle    27790  19015  0 12:34 pts/0    00:00:00 grep --color=auto tns

[oracle@isecdb1-INFRAP1-/home/oracle]> sqlplus "/as sysdba"

SQL> select name,open_mode from v$database;               ИМЕТО НА БАЗАТА 
SQL> alter database recover managed standby database cancel;      ГАСЯ ОПЦИЯТА ДА НЕ СЕ РЕКОВЪРВА СТЕНДБАЯ
SQL> shutdown immediate;


[oracle@isecdb1-INFRAP1-/home/oracle]> lsnrctl stop LISTENER


*****************************************STARTUP*********************************

3) startup standby :


[oracle@isecdb1-INFRAP1-/home/oracle]> lsnrctl start LISTENER
[oracle@isecdb1-INFRAP1-/home/oracle]> sqlplus "/as sysdba"

SQL> startup nomount;
SQL> alter database mount standby database;
SQL> alter database recover managed standby database disconnect from session;  =----    АКТИВИРА РИКАВЪРА НА БАЗАТА
SQL> select name,open_mode from v$database;    -------- В МОУНТ САМО ТРЯБВА ДА Е

Change home 'N' value to 'Y' in oratab file:
[oracle@isecdb1-INFRAP1-/home/oracle]> vi /etc/oratab

4) Startup Primary:


[oracle@isecdb2-INFRAP2-/home/oracle]> lsnrctl start LISTENER

SQL> startup
SQL> alter system set log_archive_dest_state_2=ENABLE;
SQL> alter system switch logfile;

Change home 'N' value to 'Y' in oratab file:
[oracle@isecdb2-INFRAP2-/home/oracle]> vi /etc/oratab 

Start monitoring:
[root@isecdb2 ~]# dbspicol ON


### Check the sync on standby:

select al.thread#,
        al.last_rec "Last Recd",
        la.last_app "Last Applied"
from
  (select thread#, max(sequence#) last_rec
    from v$archived_log
    group by thread#) al,
  (select thread#, max(sequence#) last_app
    from v$archived_log
    where applied='YES' and registrar='RFS'
    group by thread#) la
where al.thread#=la.thread#
and al.thread# != 0
order by al.thread#
/


Please know you can contact me at any time if you have any concerns or questions.


