/********************************************************************************
*********       E-mail subject: EHWEB-822
*********             Instance: PROD
*********          Description: 
Problem:
There was a slowness in service_bus_broker on PROD.

Analysis:
The Top SQL was 8krkhqbjzxg5w. Inappropriate execution plan was used because of missing index on column refperso on table t_elements 
and Oracle make index skip scan instead of index range scan. Because we want only the active elements the solution here is to select the data 
from table t_element_se where there is index on column refperso and Oracle make index range scan instead of index skip scan.

Suggestion:
Please rewrite the query in source utl_eh_initdos.pcs to select from table t_element_se as it is shown in the New SQL section below.

*********               SQL_ID: 8krkhqbjzxg5w
*********      Program/Package: 
*********              Request: Giao My Tran 
*********               Author: Dimitar Dimitrov
********* Received e-mail date: 16/10/2023
*********      Resolution date: 16/10/2023
*********  Trace old file here: \\epox\specifs\performance\tmp\
*********  Trace new file here:
***********************************************************************************/

/********************************OLD SQL*******************************************/
var B1 NUMBER;
exec :B1 := '30000544';

select count(*)
  INTO :b0
  FROM t_elements
 WHERE libelle IN ('Alert: case creation on closed debtor',
                   'Alert: amount too big for auto allocation',
                   'Alert: amount too small for creation',
                   'Alert: possible bankruptcy',
                   'Alert: debtor ceased trading',
                   'Alert: debtor with not assets',
                   'Alert: debtor situation death')
   AND refperso = :B1
   AND typeelem = 'se'
   AND actif = 'o';
/********************************OLD SQL*******************************************/
/********************************OLD Metrics***************************************/
/*
MODULE                    SQL_ID         PLAN_HASH SID    SERIAL# EVENT                          FROM                           TO                                 ACTIVE NUMBER_OF_EXECUTIONS PERC
------------------------- ------------- ---------- ------ ------- ------------------------------ ------------------------------ ------------------------------ ---------- -------------------- ------
service_bus_serverE126BBE 8krkhqbjzxg5w 4010067596 458    63213   db file sequential read        2023/10/13 17:04:41            2023/10/13 17:13:52                   520       1 22%
1BA233718C0D8576AA93B88

EXCEL.EXE                 f6q0j3dxkyut5 2583729286 1417   16589   db file parallel read          2023/10/13 17:04:21            2023/10/13 17:13:42                   330       1 14%
EXCEL.EXE                 f6q0j3dxkyut5 2583729286 1417   16589   db file sequential read        2023/10/13 17:04:01            2023/10/13 17:13:52                   150       1 6%


MODULE                    SQL_ID         PLAN_HASH SID    SERIAL# EVENT                          FROM                           TO                                 ACTIVE NUMBER_OF_EXECUTIONS PERC
------------------------- ------------- ---------- ------ ------- ------------------------------ ------------------------------ ------------------------------ ---------- -------------------- ------
service_bus_serverE126BBE 8krkhqbjzxg5w 4010067596 458    63213                                  2023/10/13 17:04:41            2023/10/13 17:13:52                   560       1 100%
1BA233718C0D8576AA93B88

PLAN HASH VALUE  : 4010067596
----------------------------------------------------------------------------------------------------------
| Id  | Operation                            | Name                   | Rows  | Bytes | Cost  | Time     |
----------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                     |                        |       |       | 14242 |          |
|   1 |  SORT AGGREGATE                      |                        |     1 |    33 |       |          |
|*  2 |   TABLE ACCESS BY INDEX ROWID BATCHED| T_ELEMENTS             |     1 |    33 | 14242 | 00:00:01 |
|*  3 |    INDEX SKIP SCAN                   | ELE_DOSS_TYP_ASSOC_LIB |     7 |       | 14242 | 00:00:01 |
----------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
2 - filter(("REFPERSO"=:B1 AND "ACTIF"='o'))
3 - access("TYPEELEM"='se')
filter(("TYPEELEM"='se' AND INTERNAL_FUNCTION("LIBELLE")))
*/
/********************************OLD Metrics***************************************/

/********************************New SQL*******************************************/
select count(*)
  INTO :b0
  FROM t_element_se
 WHERE libelle IN ('Alert: case creation on closed debtor',
                   'Alert: amount too big for auto allocation',
                   'Alert: amount too small for creation',
                   'Alert: possible bankruptcy',
                   'Alert: debtor ceased trading',
                   'Alert: debtor with not assets',
                   'Alert: debtor situation death')
   AND refperso = :B1;
/********************************New SQL*******************************************/
/********************************New Metrics***************************************/
/*
Plan hash value: 3235018671
-----------------------------------------------------------------------------------------------------------
| Id  | Operation         | Name               | Starts | E-Rows | A-Rows |   A-Time   | Buffers | Reads  |
-----------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT  |                    |      1 |        |      1 |00:00:00.01 |       4 |      2 |
|   1 |  SORT AGGREGATE   |                    |      1 |      1 |      1 |00:00:00.01 |       4 |      2 |
|*  2 |   INDEX RANGE SCAN| ELESE_REFPERSO_IDX |      1 |  12141 |      1 |00:00:00.01 |       4 |      2 |
-----------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   2 - access("REFPERSO"=:B1)
       filter(("LIBELLE"='Alert: amount too big for auto allocation' OR "LIBELLE"='Alert: amount
              too small for creation' OR "LIBELLE"='Alert: case creation on closed debtor' OR "LIBELLE"='Alert:
              debtor ceased trading' OR "LIBELLE"='Alert: debtor situation death' OR "LIBELLE"='Alert: debtor
              with not assets' OR "LIBELLE"='Alert: possible bankruptcy'))

*/
/********************************New Metrics***************************************/

/********************************Index statistics**********************************/

/********************************Other SQLs****************************************/          
/*

*/ 
/********************************Other SQLs****************************************/              
