/********************************************************************************
*********       E-mail subject: EFDE2DEV-1410
*********             Instance: PIZAMIG
*********          Description: 
Problem:
SQL br1dz41t7kga1 took 38% of the time of msgq_calfidec module for msg_q06 in SID 303 and SERIAL# 12824.

Analysis:
We found that in msg_q06 was 84% of the time. SQL br1dz41t7kga1 as the TOP SQL for module msgq_calfidec for SID 303 and SERIAL# 12824. The problem in it was because of the IN and the subquery in it, table G_VENRESTRICTION
can not be accessed through all three columns REFDOSS, REFELEM and RESTRICTION_CODE, which are part of index VENRESTRICT_IDX of table G_VENRESTRICTION. Here, we can 
propose two posssible variants of optimization. The first in to rewrite the UPDATE statement into MERGE INTO satatement as it is shown in the New SQL section below. The second is 
to modify the UPDATE statement as it is shown in the New SQL section below to be possible to access table G_VENRESTRICTION through the three columns.

Suggestion:
Please choose one of the proposed variants in the New SQL section below and apply it.

*********               SQL_ID: br1dz41t7kga1
*********      Program/Package: ftr_fin_calc_item.pck
*********              Request: Dimitare Ivanov
*********               Author: Dimitar Dimitrov
********* Received e-mail date: 15/03/2024
*********      Resolution date: 18/03/2024
*********  Trace old file here: \\epox\specifs\performance\tmp\
*********  Trace new file here:
***********************************************************************************/

/********************************OLD SQL*******************************************/
var B1 VARCHAR2(32);
exec :B1 := '0001010039';

UPDATE G_VENRESTRICTION
   SET FG_CALCFIN_SUSP = 'O'
 WHERE REFDOSS = :B1
   AND REFELEM || '' = 'NMP'
   AND RESTRICTION_CODE IN (SELECT * FROM TABLE(:B2));

/********************************OLD SQL*******************************************/
/********************************OLD Metrics***************************************/
/*

BUFF           MSGSEQ REFDOSS    PROCESSEDB LOCKEDBY                                 DATETR_DT           DTPROCESS_DT        DT_ENDPROC_DT       PARENT_MSGSEQ
---------- ---------- ---------- ---------- ---------------------------------------- ------------------- ------------------- ------------------- -------------
calfidec@   158134441 0001010039 msg_q06                                             2024-03-14 19:51:34 2024-03-14 19:52:17 2024-03-14 20:17:36 
 

MODULE                           SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
msgq_calfidec                                                                   ON CPU               2024/03/14 19:52:11  2024/03/14 20:17:33         177               483963 +000000000 00:25:21.547 61%
PT_MIGR_STATS_CREATE                                                            db file sequential r 2024/03/14 20:18:43  2024/03/14 20:19:53          44               179707 +000000000 00:01:10.101 15%
PT_MIGR_STATS_CREATE                                                            ON CPU               2024/03/14 20:19:03  2024/03/14 20:19:53          28              1584692 +000000000 00:00:50.077 10%
                                                        0       1139      25047 log file parallel wr 2024/03/14 19:52:21  2024/03/14 20:03:32           6                      +000000000 00:11:10.664 2%
std_migr_mvt.createCalfidecCalls cg1y8t92pa5mf 2819895597        595      30376 ON CPU               2024/03/14 19:50:51  2024/03/14 19:51:31           5                    1 +000000000 00:00:40.050 2%



MODULE                           SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
msgq_calfidec                                                                   ON CPU               2024/03/14 19:52:11  2024/03/14 20:17:33         177               483963 +000000000 00:25:21.547 98%
msgq_calfidec                                                                   db file sequential r 2024/03/14 19:52:11  2024/03/14 20:03:52           4                73016 +000000000 00:11:40.698 2%



MODULE                           PROGRAM                                            SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- -------------------------------------------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
msgq_calfidec                    msg_q06                                                                            303      12824                      2024/03/14 19:52:21  2024/03/14 20:17:33         152              483911 +000000000 00:25:11.532 84%
msgq_calfidec                    msg_q07                                                                            603       4885 ON CPU               2024/03/14 19:52:21  2024/03/14 19:54:21          13               83702 +000000000 00:02:00.112 7%
msgq_calfidec                    msg_q09                                                                           1166      28338 ON CPU               2024/03/14 19:52:21  2024/03/14 19:53:11           6               93420 +000000000 00:00:50.052 3%
msgq_calfidec                    msg_q04                                                                           2032      14225 ON CPU               2024/03/14 19:52:21  2024/03/14 19:52:41           3               12097 +000000000 00:00:20.027 2%
msgq_calfidec                    msg_q05                                                                              6      30887 ON CPU               2024/03/14 19:52:21  2024/03/14 19:52:41           3                2822 +000000000 00:00:20.027 2%
msgq_calfidec                    msg_q03                                            gwqv4yb5fzczt          0       1729      59706 ON CPU               2024/03/14 19:52:11  2024/03/14 19:52:11           1             +000000000 00:00:00.000 1%
msgq_calfidec                    msg_q12                                            2x0jz0ju9xb65  216350828       2027      41520 ON CPU               2024/03/14 19:52:21  2024/03/14 19:52:21           1           1 +000000000 00:00:00.000 1%
msgq_calfidec                    msg_q08                                            34g47mfz4hhgs  865734001        863      43484 ON CPU               2024/03/14 19:52:21  2024/03/14 19:52:21           1           1 +000000000 00:00:00.000 1%
msgq_calfidec                    msg_q02                                            9ksmt45rs91p1          0       1442      12059 db file sequential r 2024/03/14 19:52:11  2024/03/14 19:52:11           1           1 +000000000 00:00:00.000 1%



MODULE                           SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
msgq_calfidec                    br1dz41t7kga1 1548218346        303      12824 ON CPU               2024/03/14 19:53:31  2024/03/14 20:17:23          69                96365 +000000000 00:23:51.452 38%
msgq_calfidec                    9ksmt45rs91p1          0        303      12824 ON CPU               2024/03/14 19:52:41  2024/03/14 20:16:03          28                    1 +000000000 00:23:21.412 15%
msgq_calfidec                    auwc9ykrza68u  990930743        303      12824 ON CPU               2024/03/14 19:58:32  2024/03/14 20:17:33           6                   14 +000000000 00:19:01.189 3%
msgq_calfidec                    23archgv3dvmf 1465607453        303      12824 ON CPU               2024/03/14 19:54:41  2024/03/14 20:12:33           5                68312 +000000000 00:17:51.091 3%
msgq_calfidec                    bx3vu0ajddfr0 3206045038        603       4885 ON CPU               2024/03/14 19:53:21  2024/03/14 19:54:21           4                12653 +000000000 00:01:00.052 2%
msgq_calfidec                    bx3vu0ajddfr0 3206045038        303      12824 ON CPU               2024/03/14 19:52:51  2024/03/14 20:15:13           4               101389 +000000000 00:22:21.351 2%
msgq_calfidec                                           0        303      12824 ON CPU               2024/03/14 19:53:41  2024/03/14 20:14:23           4                      +000000000 00:20:41.259 2%
msgq_calfidec                    9qaf3qtcpyhm0                   303      12824 ON CPU               2024/03/14 20:03:42  2024/03/14 20:13:13           3                 5840 +000000000 00:09:30.591 2%
msgq_calfidec                    2t0yvmk1y00wa 1388734953        303      12824                      2024/03/14 19:54:01  2024/03/14 20:01:02           3                37611 +000000000 00:07:00.411 2%



INSTANCE_NUMBER SQL_ID            ELAPSED MAX_WAIT_ON     PC_OF  WAIT_TIME            GETS      READS       ROWS  ELAP/EXEC       GETS/EXEC READS/EXEC  ROWS/EXEC       EXEC PLAN_HASH_VALUE
--------------- ------------- ----------- --------------- ----- ---------- --------------- ---------- ---------- ---------- --------------- ---------- ---------- ---------- ---------------
              1 br1dz41t7kga1         441 CPU             100%  439.421279        26655704          0          0        .01             595          0          0      44812      1548218346
              


Plan hash value: 1548218346
---------------------------------------------------------------------------
| Id  | Operation                             | Name             | E-Rows |
---------------------------------------------------------------------------
|   0 | UPDATE STATEMENT                      |                  |        |
|   1 |  UPDATE                               | G_VENRESTRICTION |        |
|*  2 |   HASH JOIN SEMI                      |                  |      1 |
|   3 |    TABLE ACCESS BY INDEX ROWID BATCHED| G_VENRESTRICTION |      1 |
|*  4 |     INDEX RANGE SCAN                  | VENRESTRICT_IDX  |      1 |
|   5 |    COLLECTION ITERATOR PICKLER FETCH  |                  |      5 |
---------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   2 - access("RESTRICTION_CODE"=VALUE(KOKBF$))
   4 - access("REFDOSS"=:B1)
       filter("REFELEM"||''='NMP')
*/
/********************************OLD Metrics***************************************/

/********************************New SQL*******************************************/
-- Variant where the UPDATE is rewritten to MERGE statement

var B1 varchar2(32);
exec :B1 := '0301010080';

MERGE /*+ leading(RC) use_nl(GV) index(GV VENRESTRICT_IDX)*/
      INTO G_VENRESTRICTION GV
      USING ( SELECT column_value as RESTRICTION_CODE
                FROM TABLE(test_dd_restriction_code_list.show_restriction_code_list) r ) RC
         ON ( GV.RESTRICTION_CODE = RC.RESTRICTION_CODE 
          AND GV.REFDOSS = :B1
          AND GV.REFELEM = 'A700MTVK' )
 WHEN MATCHED THEN
	    UPDATE SET FG_CALCFIN_SUSP = 'O';


-- Variant where the UPDATE is modifyed to use all three columns and to access table G_VENRESTRICTION by the most selective way.

var B1 varchar2(32);
exec :B1 := '0301010080';

UPDATE G_VENRESTRICTION GV
   SET FG_CALCFIN_SUSP = 'O'
 WHERE ROWID IN ( SELECT /*+ leading(R) use_nl(GV) index(GV VENRESTRICT_IDX)*/
                         ROWID
                    FROM G_VENRESTRICTION GV,
                         TABLE(test_di_restriction_list) R 
                   WHERE REFDOSS = :B1 
                     AND REFELEM = 'A700MTVK' 
                     AND RESTRICTION_CODE = R.column_value );
/********************************New SQL*******************************************/
/********************************New Metrics***************************************/
/*
-- With the MERGE statement

Plan hash value: 830534598
-------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                             | Name                       | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers |
-------------------------------------------------------------------------------------------------------------------------------------------
|   0 | MERGE STATEMENT                       |                            |      3 |        |    25 (100)|      0 |00:00:00.01 |     116 |
|   1 |  MERGE                                | G_VENRESTRICTION           |      3 |        |            |      0 |00:00:00.01 |     116 |
|   2 |   VIEW                                |                            |      3 |        |            |      6 |00:00:00.01 |      16 |
|   3 |    NESTED LOOPS                       |                            |      3 |      1 |    25   (0)|      6 |00:00:00.01 |      16 |
|   4 |     NESTED LOOPS                      |                            |      3 |      5 |    25   (0)|      6 |00:00:00.01 |      14 |
|   5 |      COLLECTION ITERATOR PICKLER FETCH| SHOW_RESTRICTION_CODE_LIST |      3 |      5 |    24   (0)|      6 |00:00:00.01 |       0 |
|*  6 |      INDEX RANGE SCAN                 | VENRESTRICT_IDX            |      6 |      1 |     1   (0)|      6 |00:00:00.01 |      14 |
|   7 |     TABLE ACCESS BY INDEX ROWID       | G_VENRESTRICTION           |      6 |      1 |     1   (0)|      6 |00:00:00.01 |       2 |
-------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   6 - access("GV"."REFDOSS"=:B1 AND "GV"."RESTRICTION_CODE"=VALUE(KOKBF$) AND "GV"."REFELEM"='A700MTVK')


-- With the modified UPDATE statement

Plan hash value: 3821581629
------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                              | Name                     | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers |
------------------------------------------------------------------------------------------------------------------------------------------
|   0 | UPDATE STATEMENT                       |                          |      1 |        |   189 (100)|      0 |00:00:00.01 |     176 |
|   1 |  UPDATE                                | G_VENRESTRICTION         |      1 |        |            |      0 |00:00:00.01 |     176 |
|   2 |   NESTED LOOPS                         |                          |      1 |      1 |   189   (1)|      3 |00:00:00.01 |      14 |
|   3 |    VIEW                                | VW_NSO_1                 |      1 |    480 |   187   (0)|      3 |00:00:00.01 |      12 |
|   4 |     SORT UNIQUE                        |                          |      1 |      1 |            |      3 |00:00:00.01 |      12 |
|   5 |      NESTED LOOPS                      |                          |      1 |    480 |   187   (0)|      3 |00:00:00.01 |      12 |
|   6 |       COLLECTION ITERATOR PICKLER FETCH| TEST_DI_RESTRICTION_LIST |      1 |   8168 |    24   (0)|      5 |00:00:00.01 |       0 |
|*  7 |       INDEX RANGE SCAN                 | VENRESTRICT_IDX          |      5 |      1 |     1   (0)|      3 |00:00:00.01 |      12 |
|   8 |    TABLE ACCESS BY USER ROWID          | G_VENRESTRICTION         |      3 |      1 |     1   (0)|      3 |00:00:00.01 |       2 |
------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   7 - access("REFDOSS"=:B1 AND "RESTRICTION_CODE"=VALUE(KOKBF$) AND "REFELEM"='A700MTVK')
*/
/********************************New Metrics***************************************/

/********************************Index statistics**********************************/

/********************************Other SQLs****************************************/          
/*

*/ 
/********************************Other SQLs****************************************/              
