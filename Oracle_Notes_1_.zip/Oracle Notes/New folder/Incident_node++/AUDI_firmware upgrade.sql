######## firmware upgrade #######


Connect to the server where the firmware will be upgraded:
Create an ssh session to the server <iudb771>
============================================================================================================
as root> 
crsctl disable crs (this is because the server will be rebooted several times during the upgrade)!!!!!!!
============================================================================================================
switch to oracle> 
su - oracle 

relocate the services from this noe to the second node of the pair 
as oracle 
/u01/dbteam/scripts/maintenance/reloc_services.sh -F iudb771 -T iudb787 -u hpioshtv
Please enter hpioshtv's password: 2Start:123456789

Once the list ends type "Y" for yes.

Right after the services are relocated switch again to root and stop the local crs:

as root: crsct stop crs

Check if anything is running by typing:

ps -ef |grep pmon
ps -ef|grep crs

Inform Clavelyn you are done.

After she comes back to you with the information she is done upgrading, start the crs and enable the clusterware:
as root:
crsctl enable crs
crsctl start crs

Make sure all of the databases are up and running once the crs is fully loaded.
============================================================================================================
============================================================================================================

THE ABOVE STEPS SHOULD BE REPEAT ON THE SECOND NODE OF THE PAIR IUDB771/IUDB787:


============================================================================================================
Connect to the server where the firmware will be upgraded:
Create an ssh session to the server <iudb787>
============================================================================================================
as root> 
crsctl disable crs (this is because the server will be rebooted several times during the upgrade)!!!!!!!
============================================================================================================
switch to oracle> 
su - oracle 

relocate the services from this noe to the second node of the pair 
as oracle 
/u01/dbteam/scripts/maintenance/reloc_services.sh -F iudb787 -T iudb771 -u hpioshtv
Please enter hpioshtv's password: 2Start:123456789

Once the list ends type "Y" for yes.

Right after the services are relocated switch again to root and stop the local crs:

as root: crsctl stop crs

Check if anything is running by typing:

ps -ef |grep pmon
ps -ef|grep crs

Inform Clavelyn you are done.

After she comes back to you with the information she is done upgrading, start the crs and enable the clusterware:
as root:
crsctl enable crs
crsctl start crs
