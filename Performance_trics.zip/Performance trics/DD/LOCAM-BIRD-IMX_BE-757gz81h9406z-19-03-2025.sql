/********************************************************************************
*********       E-mail subject: LOCAMDEV-27562
*********             Instance: BIRD
*********          Description: 
Problem:
SQL 757gz81h9406z took almost 2 hours on BIRD and didn't finish.

Analysis:
I executed the query on BIRD and as it can be seen in its execution plan, it starts from V_DOMAINE. After that, goes to table G_INDIVIDU with INDEX_SKIP_SCAN on index IND_TYPAUTRENOM, 
where finds all refindividus for which the NOM starts with 'A%'. For all of them, it access table T_INTERVENANTS and makes MERGE JOIN CARTESIAN with the selected rows from V_DOMAINE.
To avoid this, we have two options. The first option if to add hint to the query to force Oracle to start from table G_INDIVIDU using index IDX_NOM. The second option is too remove the 
EXISTS and the IN operators and to join the queries directly into the main FROM clause, where with hints we can instruct Oracle how to execute the query. Both variants can be seen in the New SQL 
section below, but we recommend to use the first variant ( where only hints are added without changing the SQL text ). Also, as it can be seen the module is IMX BE, which means that this 
maybe is not query from screen - it looks like something from a test. This query, by this way searching for all refindividus for which the NOM starts with 'A%' should not be executed, because 
this is not selective criteria and it goes through huge amount of data, which leads to taking time.

Suggestion:
1. Please change SQL 757gz81h9406z as it is shown in Option 1 in the New SQL section below only for this variant of the query ( if the query is dynamic ).
2. Please check what is executing this query for NOM like 'A%' and avoid such executions, because 'A%' doesn't looks like real business case, it is not selective and it will take time.

*********               SQL_ID: 757gz81h9406z
*********      Program/Package: 
*********              Request: Dimitare Ivanov
*********               Author: Dimitar Dimitrov
********* Received e-mail date: 19/03/2025
*********      Resolution date: 19/03/2025
*********  Trace old file here: \\epox\specifs\performance\tmp\
*********  Trace new file here:
***********************************************************************************/

/********************************OLD SQL*******************************************/

var B1 VARCHAR2(128);
exec :B1 := 'intervenant';
var B2 VARCHAR2(128);
exec :B2 := 'traittier%';
var B3 VARCHAR2(32);
exec :B3 := 'XX';
var B4 VARCHAR2(32);
exec :B4 := 'A';
var B5 VARCHAR2(32);
exec :B5 := 'A';
var B6 NUMBER;
exec :B6 := 26;
var B7 NUMBER;
exec :B7 := 1;

SELECT *
  FROM (SELECT /*+ first_rows(26)*/
         foo.*, ROWNUM rnum
          FROM ( SELECT R.profession profession,
                        R.refindividu refIndividual,
                        NVL(R.str85, 'O') vatRecov,
                        R.ville city,
                        R.nom name,
                        R.refext extRef,
                        R.cp postCode,
                        R.adr1 addr,
                        R.prenom foreName
                   FROM ( SELECT G.nom,
                                 G.prenom,
                                 G.adr1,
                                 G.cp,
                                 G.ville,
                                 G.profession,
                                 G.refext,
                                 G.refindividu,
                                 G.str85
                            FROM g_individu G
                           WHERE 1 = 1
                             AND G.refindividu IN ( SELECT T.refindividu
                                                      FROM t_intervenants T
                                                     WHERE 1 = 1
                                                       AND EXISTS ( SELECT 1
                                                                      FROM V_DOMAINE
                                                                     WHERE TYPE = :B1
                                                                       AND ecran LIKE :B2
                                                                       AND abrev = DECODE( T.reftype, :B3, T.refrenvindiv, T.reftype ) ) )
                             AND G.nom like :B4 || '%' ) R
                  WHERE 1 = 1
                    AND R.nom like :B5 || '%'
                  ORDER BY nom, refindividu ) foo
         WHERE ROWNUM <= :B6 )
 WHERE 1 = 1
   AND rnum >= :B7;
/********************************OLD SQL*******************************************/
/********************************OLD Metrics***************************************/
/*
    SID SERIAL# PID         SPID       MODULE               EVENT                                    STATUS            SQL_ID        PLAN_HASH_VALUE CLIENT_ID    CLIENT_INFO      LOGON_TIME MACHINE    ACTION
------- ------- ----------- ---------- -------------------- ---------------------------------------- ----------------- ------------- --------------- ------------ ---------------- ---------- ---------- -------------------------
     21   60697 1234        10994      iMX BE               db file sequential read                  ACTIVE-7392 sec.  757gz81h9406z      1596088464                               07:36:26   767bde368d


Plan hash value: 1596088464
---------------------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                     | Name                    | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  |
---------------------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                              |                         |      1 |        |    11 (100)|      0 |00:00:00.01 |       0 |      0 |
|*  1 |  VIEW                                         |                         |      1 |      1 |    11  (19)|      0 |00:00:00.01 |       0 |      0 |
|*  2 |   COUNT STOPKEY                               |                         |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
|   3 |    VIEW                                       |                         |      1 |      1 |    11  (19)|      0 |00:00:00.01 |       0 |      0 |
|*  4 |     SORT ORDER BY STOPKEY                     |                         |      1 |      1 |    11  (19)|      0 |00:00:00.01 |       0 |      0 |
|   5 |      VIEW                                     | VM_NWVW_2               |      1 |      1 |    11  (19)|      0 |00:00:00.01 |       0 |      0 |
|   6 |       HASH UNIQUE                             |                         |      1 |      1 |    11  (19)|      0 |00:00:00.01 |       0 |      0 |
|   7 |        NESTED LOOPS                           |                         |      1 |      1 |    10  (10)|      0 |00:00:00.01 |       0 |      0 |
|   8 |         NESTED LOOPS                          |                         |      1 |    160 |    10  (10)|  82094 |00:00:18.56 |   20706 |  11024 |
|   9 |          MERGE JOIN CARTESIAN                 |                         |      1 |      8 |     8  (13)|   2148 |00:00:00.36 |    6122 |    814 |
|  10 |           SORT UNIQUE                         |                         |      1 |      1 |     1   (0)|      2 |00:00:00.01 |      43 |      0 |
|* 11 |            TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE               |      1 |      1 |     1   (0)|    102 |00:00:00.01 |      43 |      0 |
|* 12 |             INDEX RANGE SCAN                  | V_DOMAINE_TYPE_CODE_IDX |      1 |     43 |     1   (0)|    113 |00:00:00.01 |       3 |      0 |
|  13 |           BUFFER SORT                         |                         |      1 |   2173 |     7  (15)|   2148 |00:00:00.36 |    6079 |    814 |
|  14 |            TABLE ACCESS BY INDEX ROWID BATCHED| G_INDIVIDU              |      1 |   2173 |     6   (0)|   3373 |00:00:00.35 |    6079 |    814 |
|* 15 |             INDEX SKIP SCAN                   | IND_TYPAUTRENOM         |      1 |   2173 |     1   (0)|   3373 |00:00:00.11 |      26 |     23 |
|* 16 |          INDEX RANGE SCAN                     | INT_INDIV               |   2148 |     20 |     1   (0)|  82094 |00:00:18.19 |   14584 |  10210 |
|* 17 |         TABLE ACCESS BY INDEX ROWID           | T_INTERVENANTS          |  82094 |      1 |     1   (0)|      0 |00:00:12.83 |   51229 |   5976 |
---------------------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   1 - filter("RNUM">=:B7)
   2 - filter(ROWNUM<=:B6)
   4 - filter(ROWNUM<=:B6)
  11 - filter("ECRAN" LIKE :B2)
  12 - access("TYPE"=:B1)
  15 - access("G"."NOM" LIKE :B5||'%')
       filter(("G"."NOM" LIKE :B5||'%' AND "G"."NOM" LIKE :B4||'%'))
  16 - access("G"."REFINDIVIDU"="T"."REFINDIVIDU")
  17 - filter("ABREV"=DECODE("T"."REFTYPE",:B3,"T"."REFRENVINDIV","T"."REFTYPE"))

*/
/********************************OLD Metrics***************************************/

/********************************New SQL*******************************************/

-- Option 1

SELECT *
  FROM (SELECT /*+ first_rows(26)*/
         foo.*, ROWNUM rnum
          FROM ( SELECT R.profession profession,
                        R.refindividu refIndividual,
                        NVL(R.str85, 'O') vatRecov,
                        R.ville city,
                        R.nom name,
                        R.refext extRef,
                        R.cp postCode,
                        R.adr1 addr,
                        R.prenom foreName
                   FROM ( SELECT /*+ leading(G) index(G IDX_NOM) */
                                 G.nom,
                                 G.prenom,
                                 G.adr1,
                                 G.cp,
                                 G.ville,
                                 G.profession,
                                 G.refext,
                                 G.refindividu,
                                 G.str85
                            FROM g_individu G
                           WHERE 1 = 1
                             AND G.refindividu IN ( SELECT T.refindividu
                                                      FROM t_intervenants T
                                                     WHERE 1 = 1
                                                       AND EXISTS ( SELECT 1
                                                                      FROM V_DOMAINE
                                                                     WHERE TYPE = :B1
                                                                       AND ecran LIKE :B2
                                                                       AND abrev = DECODE( T.reftype, :B3, T.refrenvindiv, T.reftype ) ) )
                             AND G.nom like :B4 || '%' ) R
                  WHERE 1 = 1
                    AND R.nom like :B5 || '%'
                  ORDER BY nom, refindividu ) foo
         WHERE ROWNUM <= :B6 )
 WHERE 1 = 1
   AND rnum >= :B7;



-- Option 2

SELECT *
  FROM (SELECT /*+ first_rows(26)*/
         foo.*, ROWNUM rnum
          FROM ( SELECT R.profession profession,
                        R.refindividu refIndividual,
                        NVL(R.str85, 'O') vatRecov,
                        R.ville city,
                        R.nom name,
                        R.refext extRef,
                        R.cp postCode,
                        R.adr1 addr,
                        R.prenom foreName
                   FROM ( SELECT /*+ leading(G T VD) index(G IDX_NOM) index(T INT_INDIV) use_hash(VD)*/
                                 G.nom,
                                 G.prenom,
                                 G.adr1,
                                 G.cp,
                                 G.ville,
                                 G.profession,
                                 G.refext,
                                 G.refindividu,
                                 G.str85
                            FROM g_individu G,
                                 t_intervenants T,
                                 V_DOMAINE VD 
                           WHERE 1 = 1
                             AND G.refindividu = T.refindividu
                             AND G.nom like :B4 || '%' 
                             AND VD.TYPE = :B1
                             AND VD.ecran LIKE :B2
                             AND VD.abrev = DECODE( T.reftype, :B3, T.refrenvindiv, T.reftype ) ) R
                  WHERE 1 = 1
                    AND R.nom like :B5 || '%'
                  ORDER BY nom, refindividu ) foo
         WHERE ROWNUM <= :B6 )
 WHERE 1 = 1
   AND rnum >= :B7;
/********************************New SQL*******************************************/
/********************************New Metrics***************************************/
/*
Plan hash value: 3192842721
--------------------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                    | Name                    | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  |
--------------------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                             |                         |      1 |        |   335 (100)|     26 |00:02:33.46 |     199K|  90934 |
|*  1 |  VIEW                                        |                         |      1 |      2 |   335   (1)|     26 |00:02:33.46 |     199K|  90934 |
|*  2 |   COUNT STOPKEY                              |                         |      1 |        |            |     26 |00:02:33.46 |     199K|  90934 |
|   3 |    VIEW                                      |                         |      1 |      2 |   335   (1)|     26 |00:02:33.46 |     199K|  90934 |
|*  4 |     SORT ORDER BY STOPKEY                    |                         |      1 |      2 |   335   (1)|     26 |00:02:33.46 |     199K|  90934 |
|   5 |      VIEW                                    | VM_NWVW_2               |      1 |      2 |   335   (1)|    209 |00:02:33.46 |     199K|  90934 |
|   6 |       HASH UNIQUE                            |                         |      1 |      2 |   335   (1)|    209 |00:02:33.46 |     199K|  90934 |
|*  7 |        HASH JOIN RIGHT SEMI                  |                         |      1 |      2 |   334   (1)|    183K|00:02:33.42 |     199K|  90934 |
|*  8 |         TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE               |      1 |      1 |     1   (0)|    102 |00:00:00.01 |      43 |      0 |
|*  9 |          INDEX RANGE SCAN                    | V_DOMAINE_TYPE_CODE_IDX |      1 |     43 |     1   (0)|    113 |00:00:00.01 |       3 |      0 |
|  10 |         NESTED LOOPS                         |                         |      1 |  43180 |   332   (0)|    184K|00:02:33.34 |     199K|  90934 |
|  11 |          NESTED LOOPS                        |                         |      1 |  43460 |   332   (0)|    184K|00:02:19.23 |   97282 |  81984 |
|  12 |           TABLE ACCESS BY INDEX ROWID BATCHED| G_INDIVIDU              |      1 |   2173 |     6   (0)|   3373 |00:00:00.22 |    6070 |    761 |
|* 13 |            INDEX RANGE SCAN                  | IDX_NOM                 |      1 |   2173 |     1   (0)|   3373 |00:00:00.02 |      15 |     10 |
|* 14 |           INDEX RANGE SCAN                   | INT_INDIV               |   3373 |     20 |     1   (0)|    184K|00:02:18.99 |   91212 |  81223 |
|  15 |          TABLE ACCESS BY INDEX ROWID         | T_INTERVENANTS          |    184K|     20 |     1   (0)|    184K|00:00:14.05 |     102K|   8950 |
--------------------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   1 - filter("RNUM">=:B7)
   2 - filter(ROWNUM<=:B6)
   4 - filter(ROWNUM<=:B6)
   7 - access("ABREV"=DECODE("T"."REFTYPE",:B3,"T"."REFRENVINDIV","T"."REFTYPE"))
   8 - filter("ECRAN" LIKE :B2)
   9 - access("TYPE"=:B1)
  13 - access("G"."NOM" LIKE :B5||'%')
       filter(("G"."NOM" LIKE :B5||'%' AND "G"."NOM" LIKE :B4||'%'))
  14 - access("G"."REFINDIVIDU"="T"."REFINDIVIDU")  
*/
/********************************New Metrics***************************************/

/********************************Index statistics**********************************/

/********************************Other SQLs****************************************/          
/*

*/ 
/********************************Other SQLs****************************************/              
