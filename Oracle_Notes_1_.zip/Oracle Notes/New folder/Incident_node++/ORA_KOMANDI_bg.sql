﻿AVR - TEKSTOVI DOKUMENT kym 10 gb

env|grep DB_NAME

set define off - чете примерно при query буквално символи (примерно: & * /)

aliases - ??

dump - това е нещо, като КОШ-а/rycicle bin при Windows

. oraenv - SET INSTANCE - SET-ва се oracle environment

dbspicao -pdvf - с тази команда се проверява връзката към базата, трябва навсякъде да пише ОК

startup mount - стартира се базата и остава в MOUNT режим
alter databse open - базата се отваря

dbspicao -m58(метрика) -r1(report)

@file_name.sql - execute file in DB / изпълнява/зарежда файла в базата

dbspicao - тази команда run-ва метрики

env - показва списък с изнесени(exported) променливи(variables)

env-i - почиства environment(среда) за sub shell-a

stdin - стандартен вход - пример: мишка, клавиатура

stdout - пример: екран(монитор)

stderr - стандартна грешка

>file - quick file clear

comm - means commparing

set - stream editor

locate - locate files

##### begin VI EDITOR #####
vi(m) - vi editor improved

u - UNDO the last action

. - repeat the last action

dd - cut the current line

yy - copy the current line

p - paste after the current line

P - paste before the current line

3dd - cut three lines

4yy - copy after lines

:w - save (write)

:w - fname - save as fname

:q - quit

:wq - save and quit

ZZ - save and quit

:q! - quit (discard your changes)

:w! - save and write to non-writable file)

##### end VI EDITOR #####

/\< asdf \>  - търсене в базата за думата asdf

ls -li - inode member can be seen with this command

df -i - with this command can see how many inodes are used how many are free on mounted file system



##### start NETWORK COMMANDS #####
ping -c2
telnet
ftp - file transfer protocol
scp - based on BSD RCP protocol
SSH - source shell
winscp
sftp - ssh file transfer protocol
ifconfig - (interface configuration) - sys administration
utility
netstat - network statistics
entstat -rn
traceroute - computer network diagnostic tool
nslookup - network administration command line tool for querying the domain name system(DNS) to obtain domain name or IP


##### end NETWORK COMMANDS #####

uname -a - print system info
uptime - shows from how long the machine is UP and works
top - real time view of a running system
free - dispays amount of free and used memory
swap - unix systems are swap to describe memory pages between RAM and DISK, and a region of a disk.
swapinfo - prints info about device file system paging space
vmstat - report virtual memory statistics
dmesg - the program helps users to print out their bootup messages

df - показва свободното пространство в системата
du - проверка на заеманото място на директорийте
at - executes commands at a spesific time
atq - lists the users pending jobs
atrm - delete jobs
fstab - static information about the filesystem

shu - SHUTDOWN the database

grep -i - (ignore) - не прави разлика между малки и големи букви
ps -ef | grep -i - да не е case sensitive - да не хваща големи и малки букви
ps -ef - see processes
ps -ef | grep pmon - see users, databse
man kill - killing procesess
kill -l - killing procesess

dbspicfg -e | grep gmcgcec - показва акаунта и паролата

flashback; - възвръщане на DROP-нати файлове, нещо като recyclebin на Windows

col - column

##### start ABBREVIATIONS#####
PDL - 
RBA - 
DTS - Data Technical Support
TL - Team Leader
TTL - Technical Team Leader
COP - Change Operation Plan
LVM - LOGICAL VOLUME MANAGER
SR - Service Request
ESL - Enterprise System List


##### end ABBREVIATIONS#####

du -sh* - проверка за най-голямата директория
du -kh - показва пространството

cat/etc/oratab - списък с Базите и Instance-ите

\.cfg - търсене на всички файлове с разширение .cfg

get - вземи/свали файл от сървъра/базата на работния компютър

rm -f (force) - force remove on files

bye - logout

dbspicol ON - включва мониторинга
dbspicol OFF - спира мониторинга

dbmoncol OFF - спира само INSTANCE

highwatermark - resizing DATA FILES

cluster - сегмент, който може да съдържа няколко таблици

df -h - 
dbspicao -dpvf - check connection
dbspicao -dpvf - check INSTANCE

; or | - разграничава различни команди, написани на един и същи ред

dbspicao -l -  show ALERT LOG

ls -lart - list long, all, reverse, time

SET ORACLE SID=(DB name)

dbmoncol - DataBase Monitoring

lsb_release -a - shows distribution and release of OS

lscpu - information about CPU

sensors - info about temperature on the processor

cat etc/oratab - Lists DB

find -name listener*.log - търси навсякъде всякакви .log файлове

cat /etc/password | grep id (example 5004) 

env|grep ORA - проверка environment

./sqlplus /as sysdba - run-ва от директорията

PVS - shows physical hard disks

G - Global

show parameter back - alert log (for oracle v11)

diagnostic_dest - diagnostics

find / -name alert_*.log

dbspicfg -e - показва спрецификазията на мониторинга
./omnib - starts backup (oracle v8)


########################


set oracle sid=database

srvctl start database -d -name of the DB		  ### Start database
srvctl status database -n - name of the node      ### Check the working nodes
srvctl stop database - -i - name of the instance   ### Stop instances

dbspicol OFF - stops monitoring
dbspicol ON - start monitoring

dbmoncol - отделен мониторинг

dbspicao -m6 -r1 -i(ime na instace)

sqlplus / as sysdba - dostyp do bazata danni

show pdbs - pokazva pdbs

drop pluggable  database pdb1 - trie pluggable database, vkliuchitelno i failovete

which oraenv  - pokazva koi environment se polzva

. oraenv - source-va

env | grep ORA - pokazva kakvo sme setnali



SQL> show user - pokazva user-a
SQL> show con_name - pokazva imeto na konteinera kym koito sme konnektnati
SQL> show con_id - pokazva ID-to na konteinera
SQL> select name, cdb, con_id from v$database; - pokazva imeto na bazata danni, che e konteiner i port count
SQL> select vabber from v$version; - pokazva versiqta na bazata danni
SQL> col name format a8 - formatira redovete
SQL> select name, con_id from v$containers order by con_id; - pokazva konteinerite podredeni po ID
SQL> show pdbs - pokazva pluggable bazite danni i dali sa otvoreni i mount-nati
SQL> col pdb_name, status from db_pdbs order by 1 - pokazva dali sa otvoreni i kakyv e statusa im
SQL> select file_name, tablespace_name from cfb_data - pokazva vsichki imena na failove i asociiranite tablespace imena

formatirane na redovete
col file_name format a50
col tablespace_name format a10

col name format a12

SQL> select file_name, tablespace_name from cdb_temp_files - pokazva TEMP failovete
SQL> col member format a42
SQL> select group#, member, con_id from v$controlfile; - pokazva kontrolnite failove
SQL> set pages 140
SQL> select distinct username from cdb_users where common='YES' order by 1; - pokazva user-ite v bazata danni
SQL> col username format a25
SQL> select con_id, username from cdb_users; - pokazva vsichki potrebiteli vyv vsichki pluggable bazi
SQL> select instance_name, status, con_id from v$instance; - pokazva imeto i statusa na instance-a
SQL> select instance_name, status, con_id from v$instance; - pokazva vsichkite syrvyri za CDBs, za XML schema, za PDB-tata, za SYS i za SYS Background
SQL> col con_id format 999
SQL> col name format a10
SQL> select con_id, name, open_mode from v$pdbs; - pokazva v kakyv mod sa bazite danni s READ, WRITE
SQL> alter pluggable database pdb1 open - s tazi komanda se otvarq bazata v READ, WRITE, no ako veche e otvore v tozi status, to togava izpliuva greshka (ORA-65019: pluggable databse PDB1 already open)
SQL> alter session set container=pdb1; - svyrzva i zadava na nashata sesiq da polzva PDB1
SQL> select file_name, tablespace_name from dba_data_files - pokazva imenata na failovete i tablespace, koito sa asociirani kym bazata
SQL> select file_name, tablespace_name from dba_temp_files; - mojem da vidim temp failovete
SQL> select distinct username from dba_users where common='NO'; - pokazva samo LOCAL USERS
SQL> disconnect - diskonektva bazata
SQL> show user - ako e diskonektnata, nqma takyv
SQL> connect system/oracle_4U@localhost:1521/PDB1.example.com - konnekt forma kym dadena baza
SQL> ./sql - vhod kym sql plus-a
SQL> help - pokazva komandi
SQL> history - pokazva istoriq na vyvedenite komandi
SQL> alter system - promqna na nivo sistemen admin
SQL> alter session - promqna na nivo sesiq
SQL> v$parameter - pokazva nastoqshto izpolzvashtite se parametri

v SPFILE.ora - mogat da se promenqt statichnite parametri i vlizat v sila sled restart ili shutdown
deterved - na sistemno nivo moje da promeni parametrite samo za novite sessi.

SQL> l - vryshta poslednata izpolzvana komanda
SQL> show parameter sga - pokazva vsichko za sga
SQL> v$parameter - pokazva kakvo raboti v pametta i v moqta sessiq
SQL> v$spparameter - pokazva vsichko za setnati parametri
SQL> edit - vkarva direktno vyv VI editor
SQL> v$parameter2 - pokazva gi razdelno parametrite
SQL> v$system_parameter - pokazva vsichko koeto e efektivno vkliucheno v cqlata sistema

shutdown -> nomount(instance started) -> mount(control file-opened) -> open(all files are loaded and opened)

NOMOUNT - pri startirane na instance se chete initialization file (ako ima takyv) ako ne shte se polzva po default (spfile)

MOUT - otvarq se control file-a koito ima imenata i lokaciite na vseki edin data file-a

SHUTDOWN - NORMAL - ne pozvolqva novi konekcii. Izchakva prikliuchvane na nastoqshtite sesii i tranzakcii
		 - TRANSACTIONAL - ne pozvolqva novi connections, ne chaka zavyrshvane na sessite, no chaka zavyrshvane na tranzakciite, force-va checkpoint i zatvarq 
		 - IMMEDIATE - ne pozvolqva novi connections, ne chaka sessite da priklichat, ne chaka tranzakciite, pravi rollback na DIRT BUFFER-a, checkpoint i zatvarq bazata
		 - ABORT - vse edno butash shaltera!
		  
SQL> alter pluggable database PDB1 open; - startirane na pluggable baza danni v READ/WRITE (variantite sa: READ/WRITE, READ ONLY, MIGRATE, MOUNTED)

ADR - AUTOMATIC DIAGNOSTIC RESPOSITORY - tuk v INSTANCE-a sa: ALERT LOG, TRACES, HEALT MONITOR REPORTS
SQL> select * from v$diag_info; - pokazva dali ADR e vkliucheno

ALERT LOG-a e v papka alert v instance-a (ORCL) primerno i e s razshirenie .XML

ORA-1578 - block corruption
ORA-60 - load lock
ORA-600 - generete internal error

SQL> v$diag_info - moje da se nameri lokaciqta na alert log-a

ALERT LOG-a mojem da go razgledame v TEXT EDITOR (primerno VI) ili ADRCI

ADRCI - command line interface

TRACE FILE - sydyrja informaciq za error-a

adrci> set editor (vi or gedit)
adrci > show_alert - shte go pokaje s gedit (izliza se s exit)

DDL log file - moje da se vidqt PDL komandite, koito sa izpylneni. Ima go v 2 varianta .XML i human readable

v$views or Dynamic Performance

views - pokazvat ni systoqnito na bazite (kolko sesii sa CONNECTED v momenta)
kakyv e state-a na failovete, state-a na logs, kakvi JOBS ARE RUNNING, backup status, memory allocation.
kak ASM si vzaimodeistva s INSTANCE-a. Moje da se vidi kakvi SQL zaqvki sa izpylneni syshto, statistiki i metriki.
Tezi View-ta sa OWNED BY SYS. VIEW-tata sa na razpolojenie pri OPEN STATE. Pri MOUNT moje da se izpylnqva VEIW-ta, svyrzani s INSTANCE-a, no ne i s bazata.

SQL> create pfile=initORCL.ora from spfile; - syzdavane na pfile ot syshtestvuvashtiq takyv.
SQL> show parameter db_name - pokazva imeto na bazata.
SQL> show parameter db_domain - pokazva domain-a
SQL> show parameter db_recovery_file_dest - pokazva kyde se namira rocovery failovete
SQL> show parameter sga - pokazva parametrite na sga
SQL> show parameter undo_tablespace - pokazva undo tables space parametyra
SQL> show parameter control_files - pokazva kontrolnite failove
SQL> show parameter processes - pokazva procesite
SQL> show parameter sessions - pokazva sessite
SQL> show parameter transactions - pokazva tranzakciite
SQL> show parameter db_files - pokazva DB inicializirashtite failovi parametri


#####ADVANCED PARAMETERS#####
SQL> show parameter commit_logging
SQL> show parameter shared_pool_size
SQL> show parameter db_block_size - pokazva goleminata na blokovete
SQL> show parameter memory_target - pokazva memori dali e AUTO ili NE e

SQL> desc v$parameter
SQL> alter session set container=PDB1; - connect PDB1
SQL> alter pluggable database pdb1 open; - startirane na PDB1

sqlplus system(USER)/oracle_4U(PASSWORD)@localhost:1521(LISTENER + DOMAIN)/PDB1(DATABASE NAME)

SQL> save q1 - syzdava se fail s ime 
SQL> shutdown immediate - spira bazata nezabavno
SQL> startup - pali bazata
SQL> startup nomount - startira bazata v nomount state
SQL> alter databse mount; - mountvane na bazata danni
SQL> alter database open; - zarejda i otvarqne na vsichki vailove i bazata preminava v open state.