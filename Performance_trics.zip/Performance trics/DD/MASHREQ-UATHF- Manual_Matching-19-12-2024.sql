/********************************************************************************
*********       E-mail subject: MASHWEB-1932
*********             Instance: UATHF
*********          Description: 
Problem:
Three queries was provided from the BE LOG. 

Analysis:
We manually executed them on UATHF and found that they have similar problem.
The heaviest part in the execution plans look the SUBSELECT, where we have several nested IN operators with joins in them, which leads to millions iterations. We joined the tables
directly without the INs, which decreased the execution time from 6-7 minutes to 2-3 seconds. We couldn't reproduce be problem on the SQL in the sql2.txt file, but it looks the same as the
other two so we applied the same in it. Also, as it can be seen in the execution plans in the New Metrics section below, one of the heaviest parts is the INDEX SKIP SCAN on index NEC_BAK_RECONCIL_IDX
on table NAM_ECR_COMPTA_BAK. This is because there is no index on column extref19 on table NAM_ECR_COMPTA_BAK ( which column is used to join the table with g_main ). Please check is it possible to
use other indexed column instead of column extref19 or if it is not possible to use other column, please discuss with C&D to create index on column extref19 on table NAM_ECR_COMPTA_BAK.
Also, we noticed that the statistics were not gathered on UATHF since 20/03/2024, but we will open separate task for to the system_support team for that.

Suggestion:
1. Please change the SQLs as it is shown in the New SQL section below.
2. Please check is it possible to use indexed column to join table NAM_ECR_COMPTA_BAK with g_main or if it is not possible, please discuss with C&D to create index on column extref19 on table NAM_ECR_COMPTA_BAK.

*********               SQL_ID: 
*********      Program/Package: 
*********              Request: Georgi Georgiev
*********               Author: Dimitar Dimitrov
********* Received e-mail date: 18/12/2024
*********      Resolution date: 19/12/2024
*********  Trace old file here: \\epox\specifs\performance\tmp\
*********  Trace new file here:
***********************************************************************************/

/********************************OLD SQL*******************************************/

-- SQL1

VAR B1 NUMBER;
EXEC :B1 := 1;
VAR B2 VARCHAR2(32);
EXEC :B2 := 'AN';
VAR B3 VARCHAR2(32);
EXEC :B3 := '2411220003';
VAR B4 NUMBER;
EXEC :B4 := 0;
VAR B5 NUMBER;
EXEC :B5 := 2001;
var B9 varchar2(32);
exec :B9 := 'INT00000';
exec utl_app_date.cacheAppDate(:B9);


SELECT g_main.*,
       ( SELECT COUNT(1)
           FROM g_elemfi E, 
                g_elemfi_aggr A, 
                g_piece B, 
                g_outpmt_exec O
          WHERE A.reffacture = E.Refpiece2
            AND B.refpiece = A.Refaggr
            AND O.refer = B.gpiressort
            AND O.dtexecution_dt IS NOT NULL
            AND E.refelem = g_main.refElem ) funded,
       ( SELECT COUNT(*)
           FROM nam_ecr_compta_bak AGGR
          WHERE AGGR.extref19 = g_main.extInvNumber
            AND AGGR.codeoper = 'MATCH_PMT'
            AND AGGR.status_reconcil = 'REJECTED' ) AS rejected
   FROM ( SELECT /*+ first_rows(2001)*/
                 foo.*, 
                 ROWNUM rnum
            FROM ( SELECT typeelem typeElem,
                          SUM(NVL(reconciled_solde, 0)) OVER() balanceTot,
                          clientName clientName,
                          dtdebut_dt dueDate,
                          NVL(montant_dos, 0) - NVL(lettrage, 0) -
                          NVL(prelettrage, 0) * NVL(:B1, 0) balanceEx,
                          refext extInvNumber,
                          libelle type,
                          refelemfi refElemFi,
                          prelettrage preMatching,
                          lettrage matching,
                          SUM(NVL(montant_dos, 0) - NVL(lettrage, 0) -
                              NVL(prelettrage, 0) * NVL(:B1, 0)) OVER() balanceExTot,
                          refdoss caseRef,
                          reconciled_solde balance,
                          flag_ctx flagCtx,
                          calcDueDate calcDueDate,
                          refelem refElem,
                          montant_dos invoiceAmt,
                          refpiece2 refDoc2,
                          imx.ftranslate_str(libelle, :B2, typeelem) displayType,
                          clRefInd clRefInd,
                          poExtRef poExtRef,
                          ge_elemfi_type geElemType,
                          abrev abbrev,
                          date_facture invDate,
                          imx_un_id uniqueId
                     FROM ( WITH T AS ( SELECT /*+ inline push_pred */
                                               ICL.refindividu clRefInd,
                                               ICL.nom clientName,
                                               CMPT.refdoss,
                                               row_number() OVER( PARTITION BY CMPT.refdoss ORDER BY CMPT.refdoss ) rn
                                          FROM t_intervenants CL,
                                               g_individu     ICL,
                                               g_dossier      CMPT
                                         WHERE 1 = 1
                                           AND CL.refdoss = CMPT.refdoss
                                           AND CL.reftype =
                                               DECODE( CMPT.categdoss, 'COMPTE IMP', 'TC', 'CL' )
                                           AND ICL.refindividu = CL.refindividu )
                         SELECT GE.REFPIECE2 REFPIECE2,
                                T_ELEMENTS.imx_un_id imx_un_id,
                                T_ELEMENTS.REFDOSS REFDOSS,
                                T_ELEMENTS.REFELEM REFELEM,
                                T_ELEMENTS.REFELEMFI REFELEMFI,
                                T_ELEMENTS.TYPEELEM TYPEELEM,
                                GE.REFEXT REFEXT,
                                GE.DTDEBUT_DT DTDEBUT_DT,
                                GE.DT_EMIS_DT DATE_FACTURE,
                                T_ELEMENTS.LIBELLE LIBELLE,
                                T_ELEMENTS.ABREV ABREV,
                                T_ELEMENTS.DTASSOC_DT DTASSOC_DT,
                                GE.MONTANT_DOS MONTANT_DOS,
                                ( SELECT /*+ push_pred */
                                         SUM(montant_dos)
                                    FROM g_prelettrage
                                   WHERE typelem = T_ELEMENTS.typeelem
                                     AND refelem = T_ELEMENTS.refelem ) PRELETTRAGE,
                                DECODE( GE.matched_amt, NULL, Ftr_Match.PartieLettreDette( T_ELEMENTS.refelem, T_ELEMENTS.typeelem, T_ELEMENTS.abrev ), GE.matched_amt ) Lettrage,
                                NVL( GE.montant_dos, 0) - NVL( Ftr_Match.LettrReelDette( T_ELEMENTS.refelem, T_ELEMENTS.typeelem, '' ), 0 ) RECONCILED_SOLDE,
                                ge.type ge_elemfi_type,
                                GE.flag_ctx FLAG_CTX,
                                T.clRefInd,
                                T.clientName,
                                ( SELECT LISTAGG(refext, ',') WITHIN GROUP( ORDER BY 1 )
                                    FROM g_piece
                                   WHERE refpiece IN ( SELECT refpiece3
                                                         FROM g_elemfi
                                                        WHERE refelem IN ( SELECT v.refelem
                                                                             FROM g_venelem v, 
                                                                                  g_elemfi poi
                                                                            WHERE poi.type = 'PO INVOICED'
                                                                              AND poi.ref_creance = ge.refelem
                                                                              AND poi.refelem = v.refencaiss
                                                                              AND poi.refdoss = ge.refdoss
                                                                              AND V.typencaiss = 'fi'
                                                                              AND V.typelem = 'fi' ) ) ) poExtRef,
                                GP_FACT.commentaire comm,
                                GP_FACT.dt13_dt calcDueDate
                           FROM T_ELEMENTS,
                                G_ELEMFI   GE,
                                g_dossier  GD,
                                T,
                                g_piece    GP_FACT
                          WHERE ge.refelem = t_elements.refelem
                            AND t_elements.refdoss = gd.refdoss
                            AND GE.MONTANT_DOS >= 0
                            AND NVL(GE.libelle, 'X') <> 'TOLERANCE AMOUNT'
                            AND t_elements.typeelem = 'fi'
                            AND (gd.categdoss LIKE 'COMPTE%')
                            AND t_elements.refdoss = T.refdoss(+)
                            AND 1 = T.rn(+)
                            AND ge.refelem = GP_FACT.gpiheure(+)
                            AND 'FACTURE' = GP_FACT.typpiece(+)
                            AND t_elements.refdoss = GP_FACT.refdoss(+)
                            AND NOT EXISTS ( SELECT 1
                                               FROM g_elemfi g2, 
                                                    v_elemfi v2
                                              WHERE g2.refelem = t_elements.refelem
                                                AND g2.type = v2.type
                                                AND v2.fg_parent_invoice = 'O' )
                            AND NOT EXISTS ( SELECT 1
                                               FROM g_piece po
                                              WHERE GE.refpiece3 IS NOT NULL
                                                AND GE.refpiece3 = po.refpiece
                                                AND po.typpiece = 'BON DE COMMANDE' )
                            AND T_ELEMENTS.refdoss = :B3
                            AND (  ( NVL(T_ELEMENTS.montant_dos, 0) - FTR_MATCH.LettrReelDette( T_ELEMENTS.refelem,
                                                                                                T_ELEMENTS.typeelem,
                                                                                                '' ) ) > 0 
                                OR FTR_MATCH.DateDernLettr( T_ELEMENTS.refelem,
                                                            T_ELEMENTS.typeelem,
                                                            T_ELEMENTS.abrev,
                                                            T_ELEMENTS.refdoss,
                                                            'f' ) > TO_CHAR( ADD_MONTHS( SYSDATE, -NVL( :B4, 1 ) ), 'j' ) )
                            AND T_ELEMENTS.libelle NOT LIKE '%MVT MIGRATION CTX%'
                            AND NVL(T_ELEMENTS.Libelle, 'X') NOT LIKE 'REMBOURSEMENT NC%'
                            AND ge.type <> 'SALES ORDER'
                         UNION
                         SELECT NULL REFPIECE2,
                                T_ELEMENTS.imx_un_id imx_un_id,
                                T_ELEMENTS.REFDOSS REFDOSS,
                                T_ELEMENTS.REFELEM REFELEM,
                                T_ELEMENTS.REFELEMFI REFELEMFI,
                                T_ELEMENTS.TYPEELEM TYPEELEM,
                                GE.REFEXT REFEXT,
                                GE.dtreception_dt DTDEBUT_DT,
                                GE.dtjour_dt DATE_FACTURE,
                                DECODE(t_elements.typeelem,
                                       'tp',
                                       NVL(GE.LIBELLE, T_ELEMENTS.LIBELLE),
                                       T_ELEMENTS.LIBELLE) LIBELLE,
                                T_ELEMENTS.ABREV ABREV,
                                T_ELEMENTS.DTASSOC_DT DTASSOC_DT,
                                GE.MONTANT_DOS MONTANT_DOS,
                                NULL PRELETTRAGE,
                                Ftr_Match.PartieLettreDette(T_ELEMENTS.refelem,
                                                            T_ELEMENTS.typeelem,
                                                            T_ELEMENTS.abrev) Lettrage,
                                NVL(GE.montant_dos, 0) -
                                NVL(Ftr_Match.LettrReelDette(T_ELEMENTS.refelem,
                                                             T_ELEMENTS.typeelem,
                                                             ''),
                                    0) RECONCILED_SOLDE,
                                T_ELEMENTS.typeelem ge_elemfi_type,
                                NULL FLAG_CTX,
                                T.clRefInd,
                                T.clientName,
                                NULL poExtRef,
                                NULL comm,
                                NULL calcDueDate
                           FROM T_ELEMENTS, 
                                G_ENCAISSEMENT GE, 
                                g_dossier GD, T
                          WHERE t_elements.typeelem IN ('tp', 've')
                            AND t_elements.refdoss = gd.refdoss
                            AND ge.refencaiss = t_elements.refelem
                            AND t_elements.refdoss = T.refdoss(+)
                            AND 1 = T.rn(+)
                            AND ge.typencaiss = DECODE( t_elements.typeelem, 'tp', 'e_sadecaiss', 'e_savirmt' )
                            AND ( gd.categdoss LIKE 'COMPTE%' )
                            AND NOT EXISTS ( SELECT 1
                                               FROM g_elemfi g2, 
                                                    v_elemfi v2
                                              WHERE g2.refelem = t_elements.refelem
                                                AND g2.type = v2.type
                                                AND v2.fg_parent_invoice = 'O' )
                            AND T_ELEMENTS.refdoss = :B3
                            AND (  ( NVL(T_ELEMENTS.montant_dos, 0 ) - FTR_MATCH.LettrReelDette( T_ELEMENTS.refelem, T_ELEMENTS.typeelem, '' ) ) > 0
                                OR FTR_MATCH.DateDernLettr( T_ELEMENTS.refelem, T_ELEMENTS.typeelem, T_ELEMENTS.abrev, T_ELEMENTS.refdoss, 'f' ) >  TO_CHAR(ADD_MONTHS(SYSDATE, -NVL(:B4, 1)), 'j'))
                            AND T_ELEMENTS.libelle not like '%MVT MIGRATION CTX%'
                            AND NVL(T_ELEMENTS.Libelle, 'X') NOT LIKE 'REMBOURSEMENT NC%'
                         UNION
                         SELECT NULL REFPIECE2,
                                T_ELEMENTS.imx_un_id imx_un_id,
                                T_ELEMENTS.REFDOSS REFDOSS,
                                T_ELEMENTS.REFELEM REFELEM,
                                T_ELEMENTS.REFELEMFI REFELEMFI,
                                T_ELEMENTS.TYPEELEM TYPEELEM,
                                GE.REFEXT REFEXT,
                                GE.dtreception_dt DTDEBUT_DT,
                                GE.dtjour_dt DATE_FACTURE,
                                GE.LIBELLE LIBELLE,
                                T_ELEMENTS.ABREV ABREV,
                                T_ELEMENTS.DTASSOC_DT DTASSOC_DT,
                                GE.MONTANT_DOS MONTANT_DOS,
                                NULL PRELETTRAGE,
                                Ftr_Match.PartieLettreDette(T_ELEMENTS.refelem,
                                                            T_ELEMENTS.typeelem,
                                                            T_ELEMENTS.abrev) Lettrage,
                                NVL(GE.montant_dos, 0) -
                                NVL(Ftr_Match.LettrReelDette(T_ELEMENTS.refelem,
                                                             T_ELEMENTS.typeelem,
                                                             ''),
                                    0) RECONCILED_SOLDE,
                                t_elements.typeelem ge_elemfi_type,
                                NULL FLAG_CTX,
                                T.clRefInd,
                                T.clientName,
                                NULL poExtRef,
                                NULL comm,
                                NULL calcDueDate
                           FROM T_ELEMENTS, 
                                G_ENCAISSEMENT GE, 
                                g_dossier GD, T
                          WHERE t_elements.typeelem = 'rd'
                            AND t_elements.refdoss = gd.refdoss
                            AND ge.refencaiss = t_elements.refelem
                            AND t_elements.refdoss = T.refdoss(+)
                            AND 1 = T.rn(+)
                            AND ge.typencaiss = 'rembdir'
                            AND (gd.categdoss LIKE 'COMPTE%')
                            AND NOT EXISTS ( SELECT 1
                                               FROM g_elemfi g2, 
                                                    v_elemfi v2
                                              WHERE g2.refelem = t_elements.refelem
                                                AND g2.type = v2.type
                                                AND v2.fg_parent_invoice = 'O' )
                            AND T_ELEMENTS.refdoss = :B4
                            AND (  ( NVL(T_ELEMENTS.montant_dos, 0) - FTR_MATCH.LettrReelDette( T_ELEMENTS.refelem, T_ELEMENTS.typeelem, '' ) ) > 0 
                                OR FTR_MATCH.DateDernLettr( T_ELEMENTS.refelem, T_ELEMENTS.typeelem, T_ELEMENTS.abrev, T_ELEMENTS.refdoss, 'f') > TO_CHAR(ADD_MONTHS(SYSDATE, -NVL(:B4, 1)), 'j'))
                            AND T_ELEMENTS.libelle not like '%MVT MIGRATION CTX%'
                            AND NVL(T_ELEMENTS.Libelle, 'X') NOT LIKE 'REMBOURSEMENT NC%'
                         UNION
                         SELECT NULL REFPIECE2,
                                T_ELEMENTS.imx_un_id imx_un_id,
                                T_ELEMENTS.REFDOSS REFDOSS,
                                T_ELEMENTS.REFELEM REFELEM,
                                T_ELEMENTS.REFELEMFI REFELEMFI,
                                T_ELEMENTS.TYPEELEM TYPEELEM,
                                NULL REFEXT,
                                T_ELEMENTS.dtassoc_dt DTDEBUT_DT,
                                T_ELEMENTS.dtsaisie_dt DATE_FACTURE,
                                T_ELEMENTS.LIBELLE LIBELLE,
                                T_ELEMENTS.ABREV ABREV,
                                T_ELEMENTS.DTASSOC_DT DTASSOC_DT,
                                T_ELEMENTS.MONTANT_DOS MONTANT_DOS,
                                NULL PRELETTRAGE,
                                Ftr_Match.PartieLettreDette(T_ELEMENTS.refelem,
                                                            T_ELEMENTS.typeelem,
                                                            T_ELEMENTS.abrev) Lettrage,
                                NVL(T_ELEMENTS.MONTANT_DOS, 0) -
                                NVL(Ftr_Match.LettrReelDette(T_ELEMENTS.refelem,
                                                             T_ELEMENTS.typeelem,
                                                             T_ELEMENTS.abrev),
                                    0) RECONCILED_SOLDE,
                                t_elements.typeelem ge_elemfi_type,
                                NULL FLAG_CTX,
                                T.clRefInd,
                                T.clientName,
                                NULL poExtRef,
                                NULL comm,
                                NULL calcDueDate
                           FROM T_ELEMENTS,
                                f_detenr   GE,
                                g_dossier  GD,
                                f_parenr   FPA,
                                T
                          WHERE t_elements.typeelem = 'rg'
                            AND t_elements.refdoss = gd.refdoss
                            AND (de_des = 'T' AND de_sen = 'R' OR
                                de_des = 'E' AND de_sen = 'V')
                            AND de_nte IS NOT NULL
                            AND de_num = t_elements.refelem
                            AND ge.de_nom = fpa.pe_nom
                            AND FPA.pe_cha IS NOT NULL
                            AND SUBSTR(FPA.pe_cha, 2, 1) = 'D'
                            AND FPA.pe_nom NOT IN ('PNCDB')
                            AND gd.categdoss LIKE 'COMPTE%'
                            AND t_elements.refdoss = T.refdoss(+)
                            AND 1 = T.rn(+)
                            AND NOT EXISTS ( SELECT 1
                                               FROM g_elemfi g2, 
                                                    v_elemfi v2
                                              WHERE g2.refelem = t_elements.refelem
                                                AND g2.type = v2.type
                                                AND v2.fg_parent_invoice = 'O' )
                            AND T_ELEMENTS.refdoss = :B3
                            AND (  ( NVL(T_ELEMENTS.montant_dos, 0) - FTR_MATCH.LettrReelDette(T_ELEMENTS.refelem, T_ELEMENTS.typeelem, T_ELEMENTS.abrev ) ) > 0 
                                OR FTR_MATCH.DateDernLettr( T_ELEMENTS.refelem, T_ELEMENTS.typeelem, T_ELEMENTS.abrev, T_ELEMENTS.refdoss, 'f') > TO_CHAR(ADD_MONTHS(SYSDATE, -NVL(:B4, 1)), 'j'))
                            AND T_ELEMENTS.libelle not like '%MVT MIGRATION CTX%'
                            AND NVL(T_ELEMENTS.Libelle, 'X') NOT LIKE 'REMBOURSEMENT NC%') T_ELEMENTS
                          WHERE 1 = 1
                          ORDER BY invDate, uniqueId
                ) foo
         WHERE ROWNUM <= :B5) g_main
 WHERE 1 = 1
   AND rnum >= :B1;



-- SQL2

VAR B1 NUMBER;
EXEC :B1 = 1;
VAR B2 VARCHAR2(32);
EXEC :B2 = 'AN';
VAR B3 VARCHAR2(32);
EXEC :B3 = '2411220003';
VAR B4 VARCHAR2(32);
EXEC :B4 = '';
VAR B5 NUMBER;
EXEC :B5 = 10001;
var B9 varchar2(32);
exec :B9 := 'INT00000';
exec utl_app_date.cacheAppDate(:B9);

SELECT g_main.*,
       (SELECT COUNT(1)
          FROM g_elemfi E, g_elemfi_aggr A, g_piece B, g_outpmt_exec O
         WHERE A.reffacture = E.Refpiece2
           AND B.refpiece = A.Refaggr
           AND O.refer = B.gpiressort
           AND O.dtexecution_dt IS NOT NULL
           AND E.refelem = g_main.refElem) funded,
       (SELECT COUNT(*)
          FROM nam_ecr_compta_bak AGGR
         WHERE AGGR.extref19 = g_main.extInvNumber
           AND AGGR.codeoper = 'MATCH_PMT'
           AND AGGR.status_reconcil = 'REJECTED') AS rejected
  FROM (SELECT /*+ first_rows(10001)*/
         foo.*, ROWNUM rnum
          FROM (SELECT typeelem typeElem,
                       SUM(NVL(reconciled_solde, 0)) OVER() balanceTot,
                       clientName clientName,
                       dtdebut_dt dueDate,
                       NVL(montant_dos, 0) - NVL(lettrage, 0) -
                       NVL(prelettrage, 0) * NVL(:B1, 0) balanceEx,
                       refext extInvNumber,
                       libelle type,
                       refelemfi refElemFi,
                       prelettrage preMatching,
                       lettrage matching,
                       SUM(NVL(montant_dos, 0) - NVL(lettrage, 0) -
                           NVL(prelettrage, 0) * NVL(:B1, 0)) OVER() balanceExTot,
                       refdoss caseRef,
                       reconciled_solde balance,
                       flag_ctx flagCtx,
                       calcDueDate calcDueDate,
                       refelem refElem,
                       montant_dos invoiceAmt,
                       refpiece2 refDoc2,
                       imx.ftranslate_str(libelle, :B2, typeelem) displayType,
                       clRefInd clRefInd,
                       poExtRef poExtRef,
                       ge_elemfi_type geElemType,
                       abrev abbrev,
                       date_facture invDate,
                       imx_un_id uniqueId
                  FROM (WITH T AS (SELECT /*+ inline push_pred */
                                    ICL.refindividu clRefInd,
                                    ICL.nom clientName,
                                    CMPT.refdoss,
                                    row_number() OVER(PARTITION BY CMPT.refdoss ORDER BY CMPT.refdoss) rn
                                     FROM t_intervenants CL,
                                          g_individu     ICL,
                                          g_dossier      CMPT
                                    WHERE 1 = 1
                                      AND CL.refdoss = CMPT.refdoss
                                      AND CL.reftype =
                                          DECODE(CMPT.categdoss,
                                                 'COMPTE IMP',
                                                 'TC',
                                                 'CL')
                                      AND ICL.refindividu = CL.refindividu)
                         SELECT GE.REFPIECE2 REFPIECE2,
                                T_ELEMENTS.imx_un_id imx_un_id,
                                T_ELEMENTS.REFDOSS REFDOSS,
                                T_ELEMENTS.REFELEM REFELEM,
                                T_ELEMENTS.REFELEMFI REFELEMFI,
                                T_ELEMENTS.TYPEELEM TYPEELEM,
                                GE.REFEXT REFEXT,
                                GE.DTDEBUT_DT DTDEBUT_DT,
                                GE.DT_EMIS_DT DATE_FACTURE,
                                T_ELEMENTS.LIBELLE LIBELLE,
                                T_ELEMENTS.ABREV ABREV,
                                T_ELEMENTS.DTASSOC_DT DTASSOC_DT,
                                GE.MONTANT_DOS MONTANT_DOS,
                                (SELECT /*+ push_pred */
                                  SUM(montant_dos)
                                   FROM g_prelettrage
                                  WHERE typelem = T_ELEMENTS.typeelem
                                    AND refelem = T_ELEMENTS.refelem) PRELETTRAGE,
                                DECODE(GE.matched_amt,
                                       NULL,
                                       Ftr_Match.PartieLettreDette(T_ELEMENTS.refelem,
                                                                   T_ELEMENTS.typeelem,
                                                                   T_ELEMENTS.abrev),
                                       GE.matched_amt) Lettrage,
                                NVL(GE.montant_dos, 0) -
                                NVL(Ftr_Match.LettrReelDette(T_ELEMENTS.refelem,
                                                             T_ELEMENTS.typeelem,
                                                             ''),
                                    0) RECONCILED_SOLDE,
                                ge.type ge_elemfi_type,
                                GE.flag_ctx FLAG_CTX,
                                T.clRefInd,
                                T.clientName,
                                (SELECT LISTAGG(refext, ',') WITHIN GROUP(ORDER BY 1)
                                   FROM g_piece
                                  WHERE refpiece IN
                                        (SELECT refpiece3
                                           FROM g_elemfi
                                          WHERE refelem IN
                                                (SELECT v.refelem
                                                   FROM g_venelem v, g_elemfi poi
                                                  WHERE poi.type = 'PO INVOICED'
                                                    AND poi.ref_creance =
                                                        ge.refelem
                                                    AND poi.refelem =
                                                        v.refencaiss
                                                    AND poi.refdoss = ge.refdoss
                                                    AND V.typencaiss = 'fi'
                                                    AND V.typelem = 'fi'))) poExtRef,
                                GP_FACT.commentaire comm,
                                GP_FACT.dt13_dt calcDueDate
                           FROM T_ELEMENTS,
                                G_ELEMFI   GE,
                                g_dossier  GD,
                                T,
                                g_piece    GP_FACT
                          WHERE ge.refelem = t_elements.refelem
                            AND t_elements.refdoss = gd.refdoss
                            AND GE.MONTANT_DOS >= 0
                            AND NVL(GE.libelle, 'X') <> 'TOLERANCE AMOUNT'
                            AND t_elements.typeelem = 'fi'
                            AND (gd.categdoss LIKE 'COMPTE%')
                            AND t_elements.refdoss = T.refdoss(+)
                            AND 1 = T.rn(+)
                            AND ge.refelem = GP_FACT.gpiheure(+)
                            AND 'FACTURE' = GP_FACT.typpiece(+)
                            AND t_elements.refdoss = GP_FACT.refdoss(+)
                            AND NOT EXISTS
                          (SELECT 1
                                   FROM g_elemfi g2, v_elemfi v2
                                  WHERE g2.refelem = t_elements.refelem
                                    AND g2.type = v2.type
                                    AND v2.fg_parent_invoice = 'O')
                            AND NOT EXISTS
                          (SELECT 1
                                   FROM g_piece po
                                  WHERE GE.refpiece3 IS NOT NULL
                                    AND GE.refpiece3 = po.refpiece
                                    AND po.typpiece = 'BON DE COMMANDE')
                            AND T_ELEMENTS.refdoss = :B3
                            AND ((NVL(T_ELEMENTS.montant_dos, 0) -
                                FTR_MATCH.LettrReelDette(T_ELEMENTS.refelem,
                                                           T_ELEMENTS.typeelem,
                                                           '')) > 0 OR
                                FTR_MATCH.DateDernLettr(T_ELEMENTS.refelem,
                                                         T_ELEMENTS.typeelem,
                                                         T_ELEMENTS.abrev,
                                                         T_ELEMENTS.refdoss,
                                                         'f') >
                                TO_CHAR(ADD_MONTHS(SYSDATE, -NVL(:B4, 1)), 'j'))
                            AND T_ELEMENTS.libelle NOT LIKE
                                '%MVT MIGRATION CTX%'
                            AND NVL(T_ELEMENTS.Libelle, 'X') NOT LIKE
                                'REMBOURSEMENT NC%'
                            AND ge.type <> 'SALES ORDER'
                         UNION
                         SELECT NULL REFPIECE2,
                                T_ELEMENTS.imx_un_id imx_un_id,
                                T_ELEMENTS.REFDOSS REFDOSS,
                                T_ELEMENTS.REFELEM REFELEM,
                                T_ELEMENTS.REFELEMFI REFELEMFI,
                                T_ELEMENTS.TYPEELEM TYPEELEM,
                                GE.REFEXT REFEXT,
                                GE.dtreception_dt DTDEBUT_DT,
                                GE.dtjour_dt DATE_FACTURE,
                                DECODE(t_elements.typeelem,
                                       'tp',
                                       NVL(GE.LIBELLE, T_ELEMENTS.LIBELLE),
                                       T_ELEMENTS.LIBELLE) LIBELLE,
                                T_ELEMENTS.ABREV ABREV,
                                T_ELEMENTS.DTASSOC_DT DTASSOC_DT,
                                GE.MONTANT_DOS MONTANT_DOS,
                                NULL PRELETTRAGE,
                                Ftr_Match.PartieLettreDette(T_ELEMENTS.refelem,
                                                            T_ELEMENTS.typeelem,
                                                            T_ELEMENTS.abrev) Lettrage,
                                NVL(GE.montant_dos, 0) -
                                NVL(Ftr_Match.LettrReelDette(T_ELEMENTS.refelem,
                                                             T_ELEMENTS.typeelem,
                                                             ''),
                                    0) RECONCILED_SOLDE,
                                T_ELEMENTS.typeelem ge_elemfi_type,
                                NULL FLAG_CTX,
                                T.clRefInd,
                                T.clientName,
                                NULL poExtRef,
                                NULL comm,
                                NULL calcDueDate
                           FROM T_ELEMENTS, G_ENCAISSEMENT GE, g_dossier GD, T
                          WHERE t_elements.typeelem IN ('tp', 've')
                            AND t_elements.refdoss = gd.refdoss
                            AND ge.refencaiss = t_elements.refelem
                            AND t_elements.refdoss = T.refdoss(+)
                            AND 1 = T.rn(+)
                            AND ge.typencaiss =
                                DECODE(t_elements.typeelem,
                                       'tp',
                                       'e_sadecaiss',
                                       'e_savirmt')
                            AND (gd.categdoss LIKE 'COMPTE%')
                            AND NOT EXISTS
                          (SELECT 1
                                   FROM g_elemfi g2, v_elemfi v2
                                  WHERE g2.refelem = t_elements.refelem
                                    AND g2.type = v2.type
                                    AND v2.fg_parent_invoice = 'O')
                            AND T_ELEMENTS.refdoss = :B3
                            AND ((NVL(T_ELEMENTS.montant_dos, 0) -
                                FTR_MATCH.LettrReelDette(T_ELEMENTS.refelem,
                                                           T_ELEMENTS.typeelem,
                                                           '')) > 0 OR
                                FTR_MATCH.DateDernLettr(T_ELEMENTS.refelem,
                                                         T_ELEMENTS.typeelem,
                                                         T_ELEMENTS.abrev,
                                                         T_ELEMENTS.refdoss,
                                                         'f') >
                                TO_CHAR(ADD_MONTHS(SYSDATE, -NVL(:B4, 1)), 'j'))
                            AND T_ELEMENTS.libelle not like
                                '%MVT MIGRATION CTX%'
                            AND NVL(T_ELEMENTS.Libelle, 'X') NOT LIKE
                                'REMBOURSEMENT NC%'
                         UNION
                         SELECT NULL REFPIECE2,
                                T_ELEMENTS.imx_un_id imx_un_id,
                                T_ELEMENTS.REFDOSS REFDOSS,
                                T_ELEMENTS.REFELEM REFELEM,
                                T_ELEMENTS.REFELEMFI REFELEMFI,
                                T_ELEMENTS.TYPEELEM TYPEELEM,
                                GE.REFEXT REFEXT,
                                GE.dtreception_dt DTDEBUT_DT,
                                GE.dtjour_dt DATE_FACTURE,
                                GE.LIBELLE LIBELLE,
                                T_ELEMENTS.ABREV ABREV,
                                T_ELEMENTS.DTASSOC_DT DTASSOC_DT,
                                GE.MONTANT_DOS MONTANT_DOS,
                                NULL PRELETTRAGE,
                                Ftr_Match.PartieLettreDette(T_ELEMENTS.refelem,
                                                            T_ELEMENTS.typeelem,
                                                            T_ELEMENTS.abrev) Lettrage,
                                NVL(GE.montant_dos, 0) -
                                NVL(Ftr_Match.LettrReelDette(T_ELEMENTS.refelem,
                                                             T_ELEMENTS.typeelem,
                                                             ''),
                                    0) RECONCILED_SOLDE,
                                t_elements.typeelem ge_elemfi_type,
                                NULL FLAG_CTX,
                                T.clRefInd,
                                T.clientName,
                                NULL poExtRef,
                                NULL comm,
                                NULL calcDueDate
                           FROM T_ELEMENTS, G_ENCAISSEMENT GE, g_dossier GD, T
                          WHERE t_elements.typeelem = 'rd'
                            AND t_elements.refdoss = gd.refdoss
                            AND ge.refencaiss = t_elements.refelem
                            AND t_elements.refdoss = T.refdoss(+)
                            AND 1 = T.rn(+)
                            AND ge.typencaiss = 'rembdir'
                            AND (gd.categdoss LIKE 'COMPTE%')
                            AND NOT EXISTS
                          (SELECT 1
                                   FROM g_elemfi g2, v_elemfi v2
                                  WHERE g2.refelem = t_elements.refelem
                                    AND g2.type = v2.type
                                    AND v2.fg_parent_invoice = 'O')
                            AND T_ELEMENTS.refdoss = :B3
                            AND ((NVL(T_ELEMENTS.montant_dos, 0) -
                                FTR_MATCH.LettrReelDette(T_ELEMENTS.refelem,
                                                           T_ELEMENTS.typeelem,
                                                           '')) > 0 OR
                                FTR_MATCH.DateDernLettr(T_ELEMENTS.refelem,
                                                         T_ELEMENTS.typeelem,
                                                         T_ELEMENTS.abrev,
                                                         T_ELEMENTS.refdoss,
                                                         'f') >
                                TO_CHAR(ADD_MONTHS(SYSDATE, -NVL(:B4, 1)), 'j'))
                            AND T_ELEMENTS.libelle not like
                                '%MVT MIGRATION CTX%'
                            AND NVL(T_ELEMENTS.Libelle, 'X') NOT LIKE
                                'REMBOURSEMENT NC%'
                         UNION
                         SELECT NULL REFPIECE2,
                                T_ELEMENTS.imx_un_id imx_un_id,
                                T_ELEMENTS.REFDOSS REFDOSS,
                                T_ELEMENTS.REFELEM REFELEM,
                                T_ELEMENTS.REFELEMFI REFELEMFI,
                                T_ELEMENTS.TYPEELEM TYPEELEM,
                                NULL REFEXT,
                                T_ELEMENTS.dtassoc_dt DTDEBUT_DT,
                                T_ELEMENTS.dtsaisie_dt DATE_FACTURE,
                                T_ELEMENTS.LIBELLE LIBELLE,
                                T_ELEMENTS.ABREV ABREV,
                                T_ELEMENTS.DTASSOC_DT DTASSOC_DT,
                                T_ELEMENTS.MONTANT_DOS MONTANT_DOS,
                                NULL PRELETTRAGE,
                                Ftr_Match.PartieLettreDette(T_ELEMENTS.refelem,
                                                            T_ELEMENTS.typeelem,
                                                            T_ELEMENTS.abrev) Lettrage,
                                NVL(T_ELEMENTS.MONTANT_DOS, 0) -
                                NVL(Ftr_Match.LettrReelDette(T_ELEMENTS.refelem,
                                                             T_ELEMENTS.typeelem,
                                                             T_ELEMENTS.abrev),
                                    0) RECONCILED_SOLDE,
                                t_elements.typeelem ge_elemfi_type,
                                NULL FLAG_CTX,
                                T.clRefInd,
                                T.clientName,
                                NULL poExtRef,
                                NULL comm,
                                NULL calcDueDate
                           FROM T_ELEMENTS,
                                f_detenr   GE,
                                g_dossier  GD,
                                f_parenr   FPA,
                                T
                          WHERE t_elements.typeelem = 'rg'
                            AND t_elements.refdoss = gd.refdoss
                            AND (de_des = 'T' AND de_sen = 'R' OR
                                de_des = 'E' AND de_sen = 'V')
                            AND de_nte IS NOT NULL
                            AND de_num = t_elements.refelem
                            AND ge.de_nom = fpa.pe_nom
                            AND FPA.pe_cha IS NOT NULL
                            AND SUBSTR(FPA.pe_cha, 2, 1) = 'D'
                            AND FPA.pe_nom NOT IN ('PNCDB')
                            AND gd.categdoss LIKE 'COMPTE%'
                            AND t_elements.refdoss = T.refdoss(+)
                            AND 1 = T.rn(+)
                            AND NOT EXISTS
                          (SELECT 1
                                   FROM g_elemfi g2, v_elemfi v2
                                  WHERE g2.refelem = t_elements.refelem
                                    AND g2.type = v2.type
                                    AND v2.fg_parent_invoice = 'O')
                            AND T_ELEMENTS.refdoss = :B3
                            AND ((NVL(T_ELEMENTS.montant_dos, 0) -
                                FTR_MATCH.LettrReelDette(T_ELEMENTS.refelem,
                                                           T_ELEMENTS.typeelem,
                                                           T_ELEMENTS.abrev)) > 0 OR
                                FTR_MATCH.DateDernLettr(T_ELEMENTS.refelem,
                                                         T_ELEMENTS.typeelem,
                                                         T_ELEMENTS.abrev,
                                                         T_ELEMENTS.refdoss,
                                                         'f') >
                                TO_CHAR(ADD_MONTHS(SYSDATE, -NVL(:B4, 1)), 'j'))
                            AND T_ELEMENTS.libelle not like
                                '%MVT MIGRATION CTX%'
                            AND NVL(T_ELEMENTS.Libelle, 'X') NOT LIKE
                                'REMBOURSEMENT NC%') T_ELEMENTS
                          WHERE 1 = 1
                            AND t_elements.imx_un_id IN ( 9065866,9065867,9065864,9065865,9065870,9065871,9065868,9065869,9065858,9065859,9065856,9065857,9065862,9065863,9065860,9065861,9065882,9065883,9065880,9065881,9065886,9065887,9065884,9065885,9065874,9065875,9065872,9065873,9065878,9065879,9065876,9065877,9065898,9065899,9065896,9065897,9065902,9065903,9065900,9065901,9065890,9065891,9065888,9065889,9065894,9065895,9065892,9065893,9065914,9065915,9065912,9065913,9065918,9065919,9065916,9065917,9065906,9065907,9065904,9065905,9065910,9065911,9065908,9065909,9065930,9065931,9065928,9065929,9065934,9065935,9065932,9065933,9065922,9065923,9065920,9065921,9065926,9065927,9065924,9065925,9065946,9065947,9065944,9065945,9065950,9065951,9065948,9065949,9065938,9065939,9065936,9065937,9065942,9065943,9065940,9065941,9065962,9065963,9065960,9065961,9065966,9065967,9065964,9065965,9065954,9065955,9065952,9065953,9065958,9065959,9065956,9065957,9065978,9065979,9065976,9065977,9065982,9065983,9065980,9065981,9065970,9065971,9065968,9065969,9065974,9065975,9065972,9065973,9065834,9065835,9065832,9065833,9065838,9065839,9065836,9065837,9065830,9065831,9065850,9065851,9065848,9065849,9065854,9065855,9065852,9065853,9065842,9065843,9065840,9065841,9065846,9065847,9065844,9065845,9066122,9066123,9066120,9066121,9066126,9066127,9066124,9066125,9066114,9066115,9066112,9066113,9066118,9066119,9066116,9066117,9066138,9066139,9066136,9066137,9066142,9066143,9066140,9066141,9066130,9066131,9066128,9066129,9066134,9066135,9066132,9066133,9066154,9066155,9066152,9066153,9066158,9066159,9066156,9066157,9066146,9066147,9066144,9066145,9066150,9066151,9066148,9066149,9066170,9066171,9066168,9066169,9066174,9066175,9066172,9066173,9066162,9066163,9066160,9066161,9066166,9066167,9066164,9066165,9066186,9066187,9066184,9066185 ) 
                          ORDER BY invDate, uniqueId
                ) foo
         WHERE ROWNUM <= :B5) g_main
 WHERE 1 = 1
   AND rnum >= :B1;


-- SQL3


VAR B1 NUMBER;
EXEC :B1 := 1;
VAR B2 VARCHAR2(32);
EXEC :B2 := 'AN';
VAR B3 VARCHAR2(32);
EXEC :B3 := '2411220003';
VAR B4 NUMBER;
EXEC :B4 := 0;
VAR B5 NUMBER;
EXEC :B5 := 2001;
VAR B6 NUMBER;
EXEC :B6 := 1;
var B9 varchar2(32);
exec :B9 := 'INT00000';
exec utl_app_date.cacheAppDate(:B9);


SELECT g_main.*,
       (SELECT COUNT(1)
          FROM g_elemfi E, g_elemfi_aggr A, g_piece B, g_outpmt_exec O
         WHERE A.reffacture = E.Refpiece2
           AND B.refpiece = A.Refaggr
           AND O.refer = B.gpiressort
           AND O.dtexecution_dt IS NOT NULL
           AND E.refelem = g_main.refElem) funded,
       (SELECT COUNT(*)
          FROM nam_ecr_compta_bak AGGR
         WHERE AGGR.extref19 = g_main.extInvNumber
           AND AGGR.codeoper = 'MATCH_PMT'
           AND AGGR.status_reconcil = 'REJECTED') AS rejected
  FROM (SELECT /*+ first_rows(2001)*/
         foo.*, ROWNUM rnum
          FROM (SELECT typeelem typeElem,
                       SUM(NVL(reconciled_solde, 0)) OVER() balanceTot,
                       clientName clientName,
                       dtdebut_dt dueDate,
                       NVL(montant_dos, 0) - NVL(lettrage, 0) -
                       NVL(prelettrage, 0) * NVL(:B1, 0) balanceEx,
                       refext extInvNumber,
                       libelle type,
                       refelemfi refElemFi,
                       prelettrage preMatching,
                       lettrage matching,
                       SUM(NVL(montant_dos, 0) - NVL(lettrage, 0) -
                           NVL(prelettrage, 0) * NVL(:B1, 0)) OVER() balanceExTot,
                       refdoss caseRef,
                       reconciled_solde balance,
                       flag_ctx flagCtx,
                       calcDueDate calcDueDate,
                       refelem refElem,
                       montant_dos invoiceAmt,
                       refpiece2 refDoc2,
                       imx.ftranslate_str(libelle, :B2, typeelem) displayType,
                       clRefInd clRefInd,
                       poExtRef poExtRef,
                       ge_elemfi_type geElemType,
                       abrev abbrev,
                       date_facture invDate,
                       imx_un_id uniqueId
                  FROM (WITH T AS (SELECT /*+ inline push_pred */
                                    ICL.refindividu clRefInd,
                                    ICL.nom clientName,
                                    CMPT.refdoss,
                                    row_number() OVER(PARTITION BY CMPT.refdoss ORDER BY CMPT.refdoss) rn
                                     FROM t_intervenants CL,
                                          g_individu     ICL,
                                          g_dossier      CMPT
                                    WHERE 1 = 1
                                      AND CL.refdoss = CMPT.refdoss
                                      AND CL.reftype =
                                          DECODE(CMPT.categdoss,
                                                 'COMPTE IMP',
                                                 'TC',
                                                 'CL')
                                      AND ICL.refindividu = CL.refindividu)
                         SELECT GE.REFPIECE2 REFPIECE2,
                                T_ELEMENTS.imx_un_id imx_un_id,
                                T_ELEMENTS.REFDOSS REFDOSS,
                                T_ELEMENTS.REFELEM REFELEM,
                                T_ELEMENTS.REFELEMFI REFELEMFI,
                                T_ELEMENTS.TYPEELEM TYPEELEM,
                                GE.REFEXT REFEXT,
                                GE.DTDEBUT_DT DTDEBUT_DT,
                                GE.DT_EMIS_DT DATE_FACTURE,
                                T_ELEMENTS.LIBELLE LIBELLE,
                                T_ELEMENTS.ABREV ABREV,
                                T_ELEMENTS.DTASSOC_DT DTASSOC_DT,
                                GE.MONTANT_DOS MONTANT_DOS,
                                (SELECT /*+ push_pred */
                                  SUM(montant_dos)
                                   FROM g_prelettrage
                                  WHERE typelem = T_ELEMENTS.typeelem
                                    AND refelem = T_ELEMENTS.refelem) PRELETTRAGE,
                                DECODE(GE.matched_amt,
                                       NULL,
                                       Ftr_Match.PartieLettreDette(T_ELEMENTS.refelem,
                                                                   T_ELEMENTS.typeelem,
                                                                   T_ELEMENTS.abrev),
                                       GE.matched_amt) Lettrage,
                                NVL(GE.montant_dos, 0) -
                                NVL(Ftr_Match.LettrReelDette(T_ELEMENTS.refelem,
                                                             T_ELEMENTS.typeelem,
                                                             ''),
                                    0) RECONCILED_SOLDE,
                                ge.type ge_elemfi_type,
                                GE.flag_ctx FLAG_CTX,
                                T.clRefInd,
                                T.clientName,
                                (SELECT LISTAGG(refext, ',') WITHIN GROUP(ORDER BY 1)
                                   FROM g_piece
                                  WHERE refpiece IN
                                        (SELECT refpiece3
                                           FROM g_elemfi
                                          WHERE refelem IN
                                                (SELECT v.refelem
                                                   FROM g_venelem v, g_elemfi poi
                                                  WHERE poi.type = 'PO INVOICED'
                                                    AND poi.ref_creance =
                                                        ge.refelem
                                                    AND poi.refelem =
                                                        v.refencaiss
                                                    AND poi.refdoss = ge.refdoss
                                                    AND V.typencaiss = 'fi'
                                                    AND V.typelem = 'fi'))) poExtRef,
                                GP_FACT.commentaire comm,
                                GP_FACT.dt13_dt calcDueDate
                           FROM T_ELEMENTS,
                                G_ELEMFI   GE,
                                g_dossier  GD,
                                T,
                                g_piece    GP_FACT
                          WHERE ge.refelem = t_elements.refelem
                            AND t_elements.refdoss = gd.refdoss
                            AND GE.MONTANT_DOS >= 0
                            AND NVL(GE.libelle, 'X') <> 'TOLERANCE AMOUNT'
                            AND t_elements.typeelem = 'fi'
                            AND (gd.categdoss LIKE 'COMPTE%')
                            AND t_elements.refdoss = T.refdoss(+)
                            AND 1 = T.rn(+)
                            AND ge.refelem = GP_FACT.gpiheure(+)
                            AND 'FACTURE' = GP_FACT.typpiece(+)
                            AND t_elements.refdoss = GP_FACT.refdoss(+)
                            AND NOT EXISTS
                          (SELECT 1
                                   FROM g_elemfi g2, v_elemfi v2
                                  WHERE g2.refelem = t_elements.refelem
                                    AND g2.type = v2.type
                                    AND v2.fg_parent_invoice = 'O')
                            AND NOT EXISTS
                          (SELECT 1
                                   FROM g_piece po
                                  WHERE GE.refpiece3 IS NOT NULL
                                    AND GE.refpiece3 = po.refpiece
                                    AND po.typpiece = 'BON DE COMMANDE')
                            AND T_ELEMENTS.refdoss = :B3
                            AND ((NVL(T_ELEMENTS.montant_dos, 0) -
                                FTR_MATCH.LettrReelDette(T_ELEMENTS.refelem,
                                                           T_ELEMENTS.typeelem,
                                                           '')) > 0 OR
                                FTR_MATCH.DateDernLettr(T_ELEMENTS.refelem,
                                                         T_ELEMENTS.typeelem,
                                                         T_ELEMENTS.abrev,
                                                         T_ELEMENTS.refdoss,
                                                         'f') >
                                TO_CHAR(ADD_MONTHS(SYSDATE, -NVL(:B4, 1)), 'j'))
                            AND T_ELEMENTS.libelle NOT LIKE
                                '%MVT MIGRATION CTX%'
                            AND NVL(T_ELEMENTS.Libelle, 'X') NOT LIKE
                                'REMBOURSEMENT NC%'
                            AND ge.type <> 'SALES ORDER'
                         UNION
                         SELECT NULL REFPIECE2,
                                T_ELEMENTS.imx_un_id imx_un_id,
                                T_ELEMENTS.REFDOSS REFDOSS,
                                T_ELEMENTS.REFELEM REFELEM,
                                T_ELEMENTS.REFELEMFI REFELEMFI,
                                T_ELEMENTS.TYPEELEM TYPEELEM,
                                GE.REFEXT REFEXT,
                                GE.dtreception_dt DTDEBUT_DT,
                                GE.dtjour_dt DATE_FACTURE,
                                DECODE(t_elements.typeelem,
                                       'tp',
                                       NVL(GE.LIBELLE, T_ELEMENTS.LIBELLE),
                                       T_ELEMENTS.LIBELLE) LIBELLE,
                                T_ELEMENTS.ABREV ABREV,
                                T_ELEMENTS.DTASSOC_DT DTASSOC_DT,
                                GE.MONTANT_DOS MONTANT_DOS,
                                NULL PRELETTRAGE,
                                Ftr_Match.PartieLettreDette(T_ELEMENTS.refelem,
                                                            T_ELEMENTS.typeelem,
                                                            T_ELEMENTS.abrev) Lettrage,
                                NVL(GE.montant_dos, 0) -
                                NVL(Ftr_Match.LettrReelDette(T_ELEMENTS.refelem,
                                                             T_ELEMENTS.typeelem,
                                                             ''),
                                    0) RECONCILED_SOLDE,
                                T_ELEMENTS.typeelem ge_elemfi_type,
                                NULL FLAG_CTX,
                                T.clRefInd,
                                T.clientName,
                                NULL poExtRef,
                                NULL comm,
                                NULL calcDueDate
                           FROM T_ELEMENTS, G_ENCAISSEMENT GE, g_dossier GD, T
                          WHERE t_elements.typeelem IN ('tp', 've')
                            AND t_elements.refdoss = gd.refdoss
                            AND ge.refencaiss = t_elements.refelem
                            AND t_elements.refdoss = T.refdoss(+)
                            AND 1 = T.rn(+)
                            AND ge.typencaiss =
                                DECODE(t_elements.typeelem,
                                       'tp',
                                       'e_sadecaiss',
                                       'e_savirmt')
                            AND (gd.categdoss LIKE 'COMPTE%')
                            AND NOT EXISTS
                          (SELECT 1
                                   FROM g_elemfi g2, v_elemfi v2
                                  WHERE g2.refelem = t_elements.refelem
                                    AND g2.type = v2.type
                                    AND v2.fg_parent_invoice = 'O')
                            AND T_ELEMENTS.refdoss = :B3
                            AND ((NVL(T_ELEMENTS.montant_dos, 0) -
                                FTR_MATCH.LettrReelDette(T_ELEMENTS.refelem,
                                                           T_ELEMENTS.typeelem,
                                                           '')) > 0 OR
                                FTR_MATCH.DateDernLettr(T_ELEMENTS.refelem,
                                                         T_ELEMENTS.typeelem,
                                                         T_ELEMENTS.abrev,
                                                         T_ELEMENTS.refdoss,
                                                         'f') >
                                TO_CHAR(ADD_MONTHS(SYSDATE, -NVL(:B4, 1)), 'j'))
                            AND T_ELEMENTS.libelle not like
                                '%MVT MIGRATION CTX%'
                            AND NVL(T_ELEMENTS.Libelle, 'X') NOT LIKE
                                'REMBOURSEMENT NC%'
                         UNION
                         SELECT NULL REFPIECE2,
                                T_ELEMENTS.imx_un_id imx_un_id,
                                T_ELEMENTS.REFDOSS REFDOSS,
                                T_ELEMENTS.REFELEM REFELEM,
                                T_ELEMENTS.REFELEMFI REFELEMFI,
                                T_ELEMENTS.TYPEELEM TYPEELEM,
                                GE.REFEXT REFEXT,
                                GE.dtreception_dt DTDEBUT_DT,
                                GE.dtjour_dt DATE_FACTURE,
                                GE.LIBELLE LIBELLE,
                                T_ELEMENTS.ABREV ABREV,
                                T_ELEMENTS.DTASSOC_DT DTASSOC_DT,
                                GE.MONTANT_DOS MONTANT_DOS,
                                NULL PRELETTRAGE,
                                Ftr_Match.PartieLettreDette(T_ELEMENTS.refelem,
                                                            T_ELEMENTS.typeelem,
                                                            T_ELEMENTS.abrev) Lettrage,
                                NVL(GE.montant_dos, 0) -
                                NVL(Ftr_Match.LettrReelDette(T_ELEMENTS.refelem,
                                                             T_ELEMENTS.typeelem,
                                                             ''),
                                    0) RECONCILED_SOLDE,
                                t_elements.typeelem ge_elemfi_type,
                                NULL FLAG_CTX,
                                T.clRefInd,
                                T.clientName,
                                NULL poExtRef,
                                NULL comm,
                                NULL calcDueDate
                           FROM T_ELEMENTS, G_ENCAISSEMENT GE, g_dossier GD, T
                          WHERE t_elements.typeelem = 'rd'
                            AND t_elements.refdoss = gd.refdoss
                            AND ge.refencaiss = t_elements.refelem
                            AND t_elements.refdoss = T.refdoss(+)
                            AND 1 = T.rn(+)
                            AND ge.typencaiss = 'rembdir'
                            AND (gd.categdoss LIKE 'COMPTE%')
                            AND NOT EXISTS
                          (SELECT 1
                                   FROM g_elemfi g2, v_elemfi v2
                                  WHERE g2.refelem = t_elements.refelem
                                    AND g2.type = v2.type
                                    AND v2.fg_parent_invoice = 'O')
                            AND T_ELEMENTS.refdoss = :B3
                            AND ((NVL(T_ELEMENTS.montant_dos, 0) -
                                FTR_MATCH.LettrReelDette(T_ELEMENTS.refelem,
                                                           T_ELEMENTS.typeelem,
                                                           '')) > 0 OR
                                FTR_MATCH.DateDernLettr(T_ELEMENTS.refelem,
                                                         T_ELEMENTS.typeelem,
                                                         T_ELEMENTS.abrev,
                                                         T_ELEMENTS.refdoss,
                                                         'f') >
                                TO_CHAR(ADD_MONTHS(SYSDATE, -NVL(:B4, 1)), 'j'))
                            AND T_ELEMENTS.libelle not like
                                '%MVT MIGRATION CTX%'
                            AND NVL(T_ELEMENTS.Libelle, 'X') NOT LIKE
                                'REMBOURSEMENT NC%'
                         UNION
                         SELECT NULL REFPIECE2,
                                T_ELEMENTS.imx_un_id imx_un_id,
                                T_ELEMENTS.REFDOSS REFDOSS,
                                T_ELEMENTS.REFELEM REFELEM,
                                T_ELEMENTS.REFELEMFI REFELEMFI,
                                T_ELEMENTS.TYPEELEM TYPEELEM,
                                NULL REFEXT,
                                T_ELEMENTS.dtassoc_dt DTDEBUT_DT,
                                T_ELEMENTS.dtsaisie_dt DATE_FACTURE,
                                T_ELEMENTS.LIBELLE LIBELLE,
                                T_ELEMENTS.ABREV ABREV,
                                T_ELEMENTS.DTASSOC_DT DTASSOC_DT,
                                T_ELEMENTS.MONTANT_DOS MONTANT_DOS,
                                NULL PRELETTRAGE,
                                Ftr_Match.PartieLettreDette(T_ELEMENTS.refelem,
                                                            T_ELEMENTS.typeelem,
                                                            T_ELEMENTS.abrev) Lettrage,
                                NVL(T_ELEMENTS.MONTANT_DOS, 0) -
                                NVL(Ftr_Match.LettrReelDette(T_ELEMENTS.refelem,
                                                             T_ELEMENTS.typeelem,
                                                             T_ELEMENTS.abrev),
                                    0) RECONCILED_SOLDE,
                                t_elements.typeelem ge_elemfi_type,
                                NULL FLAG_CTX,
                                T.clRefInd,
                                T.clientName,
                                NULL poExtRef,
                                NULL comm,
                                NULL calcDueDate
                           FROM T_ELEMENTS,
                                f_detenr   GE,
                                g_dossier  GD,
                                f_parenr   FPA,
                                T
                          WHERE t_elements.typeelem = 'rg'
                            AND t_elements.refdoss = gd.refdoss
                            AND (de_des = 'T' AND de_sen = 'R' OR
                                de_des = 'E' AND de_sen = 'V')
                            AND de_nte IS NOT NULL
                            AND de_num = t_elements.refelem
                            AND ge.de_nom = fpa.pe_nom
                            AND FPA.pe_cha IS NOT NULL
                            AND SUBSTR(FPA.pe_cha, 2, 1) = 'D'
                            AND FPA.pe_nom NOT IN ('PNCDB')
                            AND gd.categdoss LIKE 'COMPTE%'
                            AND t_elements.refdoss = T.refdoss(+)
                            AND 1 = T.rn(+)
                            AND NOT EXISTS
                          (SELECT 1
                                   FROM g_elemfi g2, v_elemfi v2
                                  WHERE g2.refelem = t_elements.refelem
                                    AND g2.type = v2.type
                                    AND v2.fg_parent_invoice = 'O')
                            AND T_ELEMENTS.refdoss = :B3
                            AND ((NVL(T_ELEMENTS.montant_dos, 0) -
                                FTR_MATCH.LettrReelDette(T_ELEMENTS.refelem,
                                                           T_ELEMENTS.typeelem,
                                                           T_ELEMENTS.abrev)) > 0 OR
                                FTR_MATCH.DateDernLettr(T_ELEMENTS.refelem,
                                                         T_ELEMENTS.typeelem,
                                                         T_ELEMENTS.abrev,
                                                         T_ELEMENTS.refdoss,
                                                         'f') >
                                TO_CHAR(ADD_MONTHS(SYSDATE, -NVL(:B4, 1)), 'j'))
                            AND T_ELEMENTS.libelle not like
                                '%MVT MIGRATION CTX%'
                            AND NVL(T_ELEMENTS.Libelle, 'X') NOT LIKE
                                'REMBOURSEMENT NC%') T_ELEMENTS
                          WHERE 1 = 1
                          ORDER BY invDate, uniqueId
                ) foo
         WHERE ROWNUM <= :B5) g_main
 WHERE 1 = 1
   AND rnum >= :B6;

/********************************OLD SQL*******************************************/
/********************************OLD Metrics***************************************/
/*
-- SQL1

Plan hash value: 2397567600
-------------------------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                         | Name                    | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  |
-------------------------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                                  |                         |      1 |        |   144K(100)|   1570 |00:06:54.47 |     100M|   1320 |
|   1 |  SORT AGGREGATE                                   |                         |   1570 |      1 |            |   1570 |00:00:00.04 |    2048 |      9 |
|   2 |   NESTED LOOPS                                    |                         |   1570 |      1 |     4   (0)|      0 |00:00:00.04 |    2048 |      9 |
|   3 |    NESTED LOOPS                                   |                         |   1570 |      1 |     4   (0)|      0 |00:00:00.03 |    2048 |      9 |
|   4 |     NESTED LOOPS                                  |                         |   1570 |      1 |     3   (0)|      0 |00:00:00.03 |    2048 |      9 |
|   5 |      NESTED LOOPS                                 |                         |   1570 |      1 |     2   (0)|      0 |00:00:00.03 |    2048 |      9 |
|   6 |       TABLE ACCESS BY INDEX ROWID                 | G_ELEMFI                |   1570 |      1 |     1   (0)|   1570 |00:00:00.01 |    1729 |      0 |
|*  7 |        INDEX UNIQUE SCAN                          | EFI_REFELEM             |   1570 |      1 |     1   (0)|   1570 |00:00:00.01 |     159 |      0 |
|*  8 |       INDEX RANGE SCAN                            | AK_KEY_2_G_ELEMFI       |   1570 |      1 |     1   (0)|      0 |00:00:00.02 |     319 |      9 |
|*  9 |      TABLE ACCESS BY INDEX ROWID BATCHED          | G_PIECE                 |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 10 |       INDEX RANGE SCAN                            | PIE_REFPIECE            |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 11 |     INDEX RANGE SCAN                              | G_OUTPMT_EXEC_REFER_IDX |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 12 |    TABLE ACCESS BY INDEX ROWID                    | G_OUTPMT_EXEC           |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|  13 |  SORT AGGREGATE                                   |                         |   1570 |      1 |            |   1570 |00:00:21.19 |    3052K|   1673 |
|* 14 |   TABLE ACCESS BY INDEX ROWID BATCHED             | NAM_ECR_COMPTA_BAK      |   1570 |      1 |     3   (0)|    158 |00:00:21.18 |    3052K|   1673 |
|* 15 |    INDEX SKIP SCAN                                | NEC_BAK_RECONCIL_IDX    |   1570 |    468 |     2   (0)|     16M|00:00:06.97 |     197K|    126 |
|* 16 |  VIEW                                             |                         |      1 |      4 |   144K  (1)|   1570 |00:06:54.47 |     100M|   1320 |
|* 17 |   COUNT STOPKEY                                   |                         |      1 |        |            |   1570 |00:06:54.46 |     100M|   1320 |
|  18 |    VIEW                                           |                         |      1 |      4 |   144K  (1)|   1570 |00:06:54.46 |     100M|   1320 |
|  19 |     WINDOW SORT                                   |                         |      1 |      4 |   144K  (1)|   1570 |00:06:53.31 |     100M|   1229 |
|  20 |      VIEW                                         |                         |      1 |      4 |   144K  (1)|   1570 |00:06:53.30 |     100M|   1229 |
|  21 |       SORT UNIQUE                                 |                         |      1 |      4 |   144K  (1)|   1570 |00:06:53.30 |     100M|   1229 |
|  22 |        UNION-ALL                                  |                         |      1 |        |            |   1570 |00:06:53.28 |     100M|   1229 |
|  23 |         SORT GROUP BY                             |                         |   1570 |      1 |            |   1570 |00:06:51.48 |     100M|    581 |
|* 24 |          INDEX FULL SCAN                          | GP_REFEXT_IDX           |   1570 |   2512 |     5   (0)|      0 |00:06:51.45 |     100M|    581 |
|  25 |           NESTED LOOPS                            |                         |     99M|      1 |     3   (0)|      0 |00:04:52.26 |      99M|      2 |
|  26 |            NESTED LOOPS                           |                         |     99M|      1 |     3   (0)|      0 |00:04:27.87 |      99M|      2 |
|  27 |             MERGE JOIN CARTESIAN                  |                         |     99M|      1 |     2   (0)|      0 |00:04:09.18 |      99M|      2 |
|* 28 |              TABLE ACCESS BY INDEX ROWID BATCHED  | G_ELEMFI                |     99M|      1 |     1   (0)|      0 |00:03:10.41 |      99M|      2 |
|* 29 |               INDEX RANGE SCAN                    | G_ELEMFI_DOS_TYP_FG02   |     99M|      1 |     1   (0)|      0 |00:02:40.90 |      99M|      2 |
|  30 |              BUFFER SORT                          |                         |      0 |     23 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|  31 |               TABLE ACCESS BY INDEX ROWID BATCHED | G_ELEMFI                |      0 |     23 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 32 |                INDEX RANGE SCAN                   | G_ELEMFI_REFPIECE_IDX   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 33 |             INDEX RANGE SCAN                      | VEN_ENCAIS              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 34 |            TABLE ACCESS BY INDEX ROWID            | G_VENELEM               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 35 |         FILTER                                    |                         |      1 |        |            |   1570 |00:00:01.57 |   22886 |    642 |
|  36 |          NESTED LOOPS OUTER                       |                         |      1 |      1 |     8   (0)|   1570 |00:00:01.54 |   16338 |    640 |
|  37 |           NESTED LOOPS OUTER                      |                         |      1 |      1 |     5   (0)|   1570 |00:00:01.46 |   16305 |    637 |
|  38 |            NESTED LOOPS                           |                         |      1 |      1 |     4   (0)|   1570 |00:00:00.93 |   11768 |    277 |
|  39 |             NESTED LOOPS OUTER                    |                         |      1 |      1 |     3   (0)|   1570 |00:00:00.77 |   11294 |    139 |
|  40 |              NESTED LOOPS                         |                         |      1 |      1 |     2   (0)|   1570 |00:00:00.76 |   11290 |    137 |
|* 41 |               TABLE ACCESS BY INDEX ROWID         | G_DOSSIER               |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |      0 |
|* 42 |                INDEX UNIQUE SCAN                  | DOS_REFDOSS             |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       2 |      0 |
|* 43 |               TABLE ACCESS BY INDEX ROWID BATCHED | T_ELEMENTS              |      1 |      1 |     1   (0)|   1570 |00:00:00.76 |   11287 |    137 |
|* 44 |                INDEX RANGE SCAN                   | ELE_DOSS_TYP_ASSOC_LIB  |      1 |      1 |     1   (0)|   2014 |00:00:00.04 |      17 |     14 |
|  45 |              VIEW PUSHED PREDICATE                | VW_SSQ_1                |   1570 |      1 |     1   (0)|      1 |00:00:00.02 |       4 |      2 |
|  46 |               SORT GROUP BY                       |                         |   1570 |      1 |     1   (0)|      1 |00:00:00.01 |       4 |      2 |
|* 47 |                TABLE ACCESS BY INDEX ROWID BATCHED| G_PRELETTRAGE           |   1570 |      1 |     1   (0)|      1 |00:00:00.01 |       4 |      2 |
|* 48 |                 INDEX RANGE SCAN                  | G_PREL_ELEM             |   1570 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |      1 |
|* 49 |             TABLE ACCESS BY INDEX ROWID           | G_ELEMFI                |   1570 |      1 |     1   (0)|   1570 |00:00:00.15 |     474 |    138 |
|* 50 |              INDEX UNIQUE SCAN                    | EFI_REFELEM             |   1570 |      1 |     1   (0)|   1570 |00:00:00.02 |     299 |      9 |
|* 51 |            TABLE ACCESS BY INDEX ROWID BATCHED    | G_PIECE                 |   1570 |      1 |     1   (0)|   1570 |00:00:00.52 |    4537 |    360 |
|* 52 |             INDEX RANGE SCAN                      | GP_GRTYPE_MT_DT         |   1570 |      1 |     1   (0)|   1570 |00:00:00.07 |     868 |     36 |
|* 53 |           VIEW PUSHED PREDICATE                   |                         |   1570 |      1 |     3   (0)|   1570 |00:00:00.08 |      33 |      3 |
|  54 |            WINDOW BUFFER                          |                         |   1570 |      1 |     3   (0)|   1570 |00:00:00.07 |      33 |      3 |
|* 55 |             FILTER                                |                         |   1570 |        |            |   1570 |00:00:00.04 |      33 |      3 |
|  56 |              NESTED LOOPS                         |                         |   1570 |      1 |     3   (0)|   1570 |00:00:00.04 |      33 |      3 |
|  57 |               NESTED LOOPS                        |                         |   1570 |      1 |     3   (0)|   1570 |00:00:00.03 |      32 |      2 |
|  58 |                NESTED LOOPS                       |                         |   1570 |      1 |     2   (0)|   1570 |00:00:00.02 |      18 |      2 |
|  59 |                 TABLE ACCESS BY INDEX ROWID       | G_DOSSIER               |   1570 |      1 |     1   (0)|   1570 |00:00:00.01 |      10 |      0 |
|* 60 |                  INDEX UNIQUE SCAN                | DOS_REFDOSS             |   1570 |      1 |     1   (0)|   1570 |00:00:00.01 |       9 |      0 |
|* 61 |                 INDEX RANGE SCAN                  | INT_REFDOSS             |   1570 |      1 |     1   (0)|   1570 |00:00:00.01 |       8 |      2 |
|* 62 |                INDEX UNIQUE SCAN                  | IND_REFINDIV            |   1570 |      1 |     1   (0)|   1570 |00:00:00.01 |      14 |      0 |
|  63 |               TABLE ACCESS BY INDEX ROWID         | G_INDIVIDU              |   1570 |      1 |     1   (0)|   1570 |00:00:00.01 |       1 |      1 |
|  64 |          NESTED LOOPS                             |                         |   1570 |      1 |     2   (0)|      0 |00:00:00.03 |    6548 |      2 |
|  65 |           TABLE ACCESS BY INDEX ROWID             | G_ELEMFI                |   1570 |      1 |     1   (0)|   1570 |00:00:00.01 |    3397 |      0 |
|* 66 |            INDEX UNIQUE SCAN                      | EFI_REFELEM             |   1570 |      1 |     1   (0)|   1570 |00:00:00.01 |    1827 |      0 |
|* 67 |           TABLE ACCESS BY INDEX ROWID BATCHED     | V_ELEMFI                |   1570 |      1 |     1   (0)|      0 |00:00:00.01 |    3151 |      2 |
|* 68 |            INDEX RANGE SCAN                       | VF_TYPE_FINANCING       |   1570 |      1 |     1   (0)|   1570 |00:00:00.01 |    1581 |      1 |
|* 69 |          FILTER                                   |                         |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
|* 70 |           TABLE ACCESS BY INDEX ROWID BATCHED     | G_PIECE                 |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 71 |            INDEX RANGE SCAN                       | PIE_REFPIECE            |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 72 |         FILTER                                    |                         |      1 |        |            |      0 |00:00:00.01 |       9 |      1 |
|  73 |          NESTED LOOPS OUTER                       |                         |      1 |      1 |     6   (0)|      0 |00:00:00.01 |       9 |      1 |
|  74 |           NESTED LOOPS                            |                         |      1 |      1 |     3   (0)|      0 |00:00:00.01 |       9 |      1 |
|  75 |            NESTED LOOPS                           |                         |      1 |      1 |     2   (0)|      0 |00:00:00.01 |       9 |      1 |
|* 76 |             TABLE ACCESS BY INDEX ROWID           | G_DOSSIER               |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |      0 |
|* 77 |              INDEX UNIQUE SCAN                    | DOS_REFDOSS             |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       2 |      0 |
|  78 |             INLIST ITERATOR                       |                         |      1 |        |            |      0 |00:00:00.01 |       6 |      1 |
|* 79 |              TABLE ACCESS BY INDEX ROWID BATCHED  | T_ELEMENTS              |      2 |      1 |     1   (0)|      0 |00:00:00.01 |       6 |      1 |
|* 80 |               INDEX RANGE SCAN                    | ELE_DOSS_TYP_ASSOC_LIB  |      2 |      1 |     1   (0)|      0 |00:00:00.01 |       6 |      1 |
|* 81 |            TABLE ACCESS BY INDEX ROWID            | G_ENCAISSEMENT          |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 82 |             INDEX UNIQUE SCAN                     | REFENCAISS              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 83 |           VIEW PUSHED PREDICATE                   |                         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|  84 |            WINDOW BUFFER                          |                         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 85 |             FILTER                                |                         |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  86 |              NESTED LOOPS                         |                         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|  87 |               NESTED LOOPS                        |                         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|  88 |                NESTED LOOPS                       |                         |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|  89 |                 TABLE ACCESS BY INDEX ROWID       | G_DOSSIER               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 90 |                  INDEX UNIQUE SCAN                | DOS_REFDOSS             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 91 |                 INDEX RANGE SCAN                  | INT_REFDOSS             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 92 |                INDEX UNIQUE SCAN                  | IND_REFINDIV            |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|  93 |               TABLE ACCESS BY INDEX ROWID         | G_INDIVIDU              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|  94 |          NESTED LOOPS                             |                         |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|  95 |           TABLE ACCESS BY INDEX ROWID             | G_ELEMFI                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 96 |            INDEX UNIQUE SCAN                      | EFI_REFELEM             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 97 |           TABLE ACCESS BY INDEX ROWID BATCHED     | V_ELEMFI                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 98 |            INDEX RANGE SCAN                       | VF_TYPE_FINANCING       |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 99 |         FILTER                                    |                         |      1 |        |            |      0 |00:00:00.01 |       4 |      4 |
| 100 |          NESTED LOOPS OUTER                       |                         |      1 |      1 |     6   (0)|      0 |00:00:00.01 |       4 |      4 |
| 101 |           NESTED LOOPS                            |                         |      1 |      1 |     3   (0)|      0 |00:00:00.01 |       4 |      4 |
| 102 |            NESTED LOOPS                           |                         |      1 |      1 |     2   (0)|      0 |00:00:00.01 |       4 |      4 |
|*103 |             INDEX SKIP SCAN                       | REFHIERARCHIE_IDX       |      1 |      1 |     1   (0)|      0 |00:00:00.01 |       4 |      4 |
|*104 |             TABLE ACCESS BY INDEX ROWID BATCHED   | T_ELEMENTS              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*105 |              INDEX RANGE SCAN                     | ELE_DOSS_TYP_ASSOC_LIB  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*106 |            TABLE ACCESS BY INDEX ROWID            | G_ENCAISSEMENT          |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*107 |             INDEX UNIQUE SCAN                     | REFENCAISS              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*108 |           VIEW PUSHED PREDICATE                   |                         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
| 109 |            WINDOW BUFFER                          |                         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
| 110 |             NESTED LOOPS                          |                         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
| 111 |              NESTED LOOPS                         |                         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
| 112 |               NESTED LOOPS                        |                         |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
| 113 |                TABLE ACCESS BY INDEX ROWID        | G_DOSSIER               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*114 |                 INDEX UNIQUE SCAN                 | DOS_REFDOSS             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*115 |                INDEX RANGE SCAN                   | INT_REFDOSS             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*116 |               INDEX UNIQUE SCAN                   | IND_REFINDIV            |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 117 |              TABLE ACCESS BY INDEX ROWID          | G_INDIVIDU              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 118 |          NESTED LOOPS                             |                         |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
| 119 |           TABLE ACCESS BY INDEX ROWID             | G_ELEMFI                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*120 |            INDEX UNIQUE SCAN                      | EFI_REFELEM             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*121 |           TABLE ACCESS BY INDEX ROWID BATCHED     | V_ELEMFI                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*122 |            INDEX RANGE SCAN                       | VF_TYPE_FINANCING       |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 123 |         NESTED LOOPS OUTER                        |                         |      1 |      1 |     7   (0)|      0 |00:00:00.01 |       4 |      1 |
| 124 |          NESTED LOOPS                             |                         |      1 |      1 |     4   (0)|      0 |00:00:00.01 |       4 |      1 |
| 125 |           NESTED LOOPS                            |                         |      1 |      1 |     3   (0)|      0 |00:00:00.01 |       4 |      1 |
| 126 |            NESTED LOOPS                           |                         |      1 |      1 |     2   (0)|      0 |00:00:00.01 |       4 |      1 |
|*127 |             TABLE ACCESS BY INDEX ROWID           | G_DOSSIER               |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |      0 |
|*128 |              INDEX UNIQUE SCAN                    | DOS_REFDOSS             |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       2 |      0 |
|*129 |             TABLE ACCESS BY INDEX ROWID BATCHED   | F_DETENR                |      1 |      1 |     1   (0)|      0 |00:00:00.01 |       1 |      1 |
|*130 |              INDEX FULL SCAN                      | DETENR_NTE              |      1 |      1 |     1   (0)|      0 |00:00:00.01 |       1 |      1 |
|*131 |            TABLE ACCESS BY INDEX ROWID            | F_PARENR                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*132 |             INDEX UNIQUE SCAN                     | PARENR_CL1              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*133 |           TABLE ACCESS BY INDEX ROWID BATCHED     | T_ELEMENTS              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*134 |            INDEX RANGE SCAN                       | ELE_ELEMTYPE            |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 135 |             NESTED LOOPS                          |                         |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
| 136 |              TABLE ACCESS BY INDEX ROWID          | G_ELEMFI                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*137 |               INDEX UNIQUE SCAN                   | EFI_REFELEM             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*138 |              TABLE ACCESS BY INDEX ROWID BATCHED  | V_ELEMFI                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*139 |               INDEX RANGE SCAN                    | VF_TYPE_FINANCING       |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*140 |          VIEW PUSHED PREDICATE                    |                         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
| 141 |           WINDOW BUFFER                           |                         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*142 |            FILTER                                 |                         |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 143 |             NESTED LOOPS                          |                         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
| 144 |              NESTED LOOPS                         |                         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
| 145 |               NESTED LOOPS                        |                         |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
| 146 |                TABLE ACCESS BY INDEX ROWID        | G_DOSSIER               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*147 |                 INDEX UNIQUE SCAN                 | DOS_REFDOSS             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*148 |                INDEX RANGE SCAN                   | INT_REFDOSS             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*149 |               INDEX UNIQUE SCAN                   | IND_REFINDIV            |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 150 |              TABLE ACCESS BY INDEX ROWID          | G_INDIVIDU              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
-------------------------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   7 - access("E"."REFELEM"=:B1)
   8 - access("A"."REFFACTURE"="E"."REFPIECE2")
   9 - filter("B"."GPIRESSORT" IS NOT NULL)
  10 - access("B"."REFPIECE"="A"."REFAGGR")
  11 - access("O"."REFER"="B"."GPIRESSORT")
  12 - filter("O"."DTEXECUTION_DT" IS NOT NULL)
  14 - filter(("AGGR"."EXTREF19"=:B1 AND "AGGR"."CODEOPER"='MATCH_PMT'))
  15 - access("AGGR"."STATUS_RECONCIL"='REJECTED')
       filter("AGGR"."STATUS_RECONCIL"='REJECTED')
  16 - filter("RNUM">=:B1)
  17 - filter(ROWNUM<=:B5)
  24 - filter( IS NOT NULL)
  28 - filter("POI"."REF_CREANCE"=:B1)
  29 - access("POI"."REFDOSS"=:B1 AND "POI"."TYPE"='PO INVOICED')
  32 - access("REFPIECE3"=:B1)
  33 - access("POI"."REFELEM"="V"."REFENCAISS")
  34 - filter(("V"."TYPENCAISS"='fi' AND "REFELEM"="V"."REFELEM" AND "V"."TYPELEM"='fi'))
  35 - filter(( IS NULL AND  IS NULL))
  41 - filter("GD"."CATEGDOSS" LIKE 'COMPTE%')
  42 - access("GD"."REFDOSS"=:B3)
  43 - filter((NVL("T_ELEMENTS"."MONTANT_DOS",0)-"FTR_MATCH"."LETTRREELDETTE"("T_ELEMENTS"."REFELEM","T_ELEMENTS"."TYPEELEM",'')>0 OR
              "FTR_MATCH"."DATEDERNLETTR"("T_ELEMENTS"."REFELEM","T_ELEMENTS"."TYPEELEM","T_ELEMENTS"."ABREV","T_ELEMENTS"."REFDOSS",'f')>TO_NUMBER(TO_CHAR(ADD_MON
              THS(SYSDATE@!,(-NVL(:B4,1))),'j'))))
  44 - access("T_ELEMENTS"."REFDOSS"=:B3 AND "T_ELEMENTS"."TYPEELEM"='fi')
       filter((NVL("T_ELEMENTS"."LIBELLE",'X') NOT LIKE 'REMBOURSEMENT NC%' AND "T_ELEMENTS"."LIBELLE" NOT LIKE '%MVT MIGRATION CTX%' AND
              "T_ELEMENTS"."LIBELLE" IS NOT NULL))
  47 - filter("TYPELEM"="T_ELEMENTS"."TYPEELEM")
  48 - access("REFELEM"="T_ELEMENTS"."REFELEM")
  49 - filter(("GE"."TYPE"<>'SALES ORDER' AND NVL("GE"."LIBELLE",'X')<>'TOLERANCE AMOUNT' AND "GE"."MONTANT_DOS">=0))
  50 - access("GE"."REFELEM"="T_ELEMENTS"."REFELEM")
  51 - filter("GP_FACT"."REFDOSS"=:B3)
  52 - access("GP_FACT"."TYPPIECE"='FACTURE' AND "GE"."REFELEM"="GP_FACT"."GPIHEURE")
       filter("GP_FACT"."GPIHEURE" IS NOT NULL)
  53 - filter("T"."RN"=1)
  55 - filter("T_ELEMENTS"."REFDOSS"=:B3)
  60 - access("CMPT"."REFDOSS"=:B3)
  61 - access("CL"."REFDOSS"=:B3 AND "CL"."REFTYPE"=DECODE("CMPT"."CATEGDOSS",'COMPTE IMP','TC','CL'))
  62 - access("ICL"."REFINDIVIDU"="CL"."REFINDIVIDU")
  66 - access("G2"."REFELEM"=:B1)
  67 - filter("V2"."FG_PARENT_INVOICE"='O')
  68 - access("G2"."TYPE"="V2"."TYPE")
  69 - filter(:B1 IS NOT NULL)
  70 - filter("PO"."TYPPIECE"='BON DE COMMANDE')
  71 - access("PO"."REFPIECE"=:B1)
  72 - filter( IS NULL)
  76 - filter("GD"."CATEGDOSS" LIKE 'COMPTE%')
  77 - access("GD"."REFDOSS"=:B3)
  79 - filter((NVL("T_ELEMENTS"."MONTANT_DOS",0)-"FTR_MATCH"."LETTRREELDETTE"("T_ELEMENTS"."REFELEM","T_ELEMENTS"."TYPEELEM",'')>0 OR
              "FTR_MATCH"."DATEDERNLETTR"("T_ELEMENTS"."REFELEM","T_ELEMENTS"."TYPEELEM","T_ELEMENTS"."ABREV","T_ELEMENTS"."REFDOSS",'f')>TO_NUMBER(TO_CHAR(ADD_MON
              THS(SYSDATE@!,(-NVL(:B4,1))),'j'))))
  80 - access("T_ELEMENTS"."REFDOSS"=:B3 AND (("T_ELEMENTS"."TYPEELEM"='tp' OR "T_ELEMENTS"."TYPEELEM"='ve')))
       filter((NVL("T_ELEMENTS"."LIBELLE",'X') NOT LIKE 'REMBOURSEMENT NC%' AND "T_ELEMENTS"."LIBELLE" NOT LIKE '%MVT MIGRATION CTX%' AND
              "T_ELEMENTS"."LIBELLE" IS NOT NULL))
  81 - filter("GE"."TYPENCAISS"=DECODE("T_ELEMENTS"."TYPEELEM",'tp','e_sadecaiss','e_savirmt'))
  82 - access("GE"."REFENCAISS"="T_ELEMENTS"."REFELEM")
  83 - filter("T"."RN"=1)
  85 - filter("T_ELEMENTS"."REFDOSS"=:B3)
  90 - access("CMPT"."REFDOSS"=:B3)
  91 - access("CL"."REFDOSS"=:B3 AND "CL"."REFTYPE"=DECODE("CMPT"."CATEGDOSS",'COMPTE IMP','TC','CL'))
  92 - access("ICL"."REFINDIVIDU"="CL"."REFINDIVIDU")
  96 - access("G2"."REFELEM"=:B1)
  97 - filter("V2"."FG_PARENT_INVOICE"='O')
  98 - access("G2"."TYPE"="V2"."TYPE")
  99 - filter( IS NULL)
 103 - access("GD"."CATEGDOSS" LIKE 'COMPTE%')
       filter(("GD"."CATEGDOSS" LIKE 'COMPTE%' AND TO_NUMBER("GD"."REFDOSS")=:B4))
 104 - filter((NVL("T_ELEMENTS"."MONTANT_DOS",0)-"FTR_MATCH"."LETTRREELDETTE"("T_ELEMENTS"."REFELEM","T_ELEMENTS"."TYPEELEM",'')>0 OR
              "FTR_MATCH"."DATEDERNLETTR"("T_ELEMENTS"."REFELEM","T_ELEMENTS"."TYPEELEM","T_ELEMENTS"."ABREV","T_ELEMENTS"."REFDOSS",'f')>TO_NUMBER(TO_CHAR(ADD_MON
              THS(SYSDATE@!,(-NVL(:B4,1))),'j'))))
 105 - access("T_ELEMENTS"."REFDOSS"="GD"."REFDOSS" AND "T_ELEMENTS"."TYPEELEM"='rd')
       filter((TO_NUMBER("T_ELEMENTS"."REFDOSS")=:B4 AND NVL("T_ELEMENTS"."LIBELLE",'X') NOT LIKE 'REMBOURSEMENT NC%' AND "T_ELEMENTS"."LIBELLE" NOT
              LIKE '%MVT MIGRATION CTX%' AND "T_ELEMENTS"."LIBELLE" IS NOT NULL))
 106 - filter("GE"."TYPENCAISS"='rembdir')
 107 - access("GE"."REFENCAISS"="T_ELEMENTS"."REFELEM")
 108 - filter("T"."RN"=1)
 114 - access("CMPT"."REFDOSS"="T_ELEMENTS"."REFDOSS")
       filter(TO_NUMBER("CMPT"."REFDOSS")=:B4)
 115 - access("CL"."REFDOSS"="T_ELEMENTS"."REFDOSS" AND "CL"."REFTYPE"=DECODE("CMPT"."CATEGDOSS",'COMPTE IMP','TC','CL'))
 116 - access("ICL"."REFINDIVIDU"="CL"."REFINDIVIDU")
 120 - access("G2"."REFELEM"=:B1)
 121 - filter("V2"."FG_PARENT_INVOICE"='O')
 122 - access("G2"."TYPE"="V2"."TYPE")
 127 - filter("GD"."CATEGDOSS" LIKE 'COMPTE%')
 128 - access("GD"."REFDOSS"=:B3)
 129 - filter(((("DE_SEN"='R' AND "DE_DES"='T') OR ("DE_SEN"='V' AND "DE_DES"='E')) AND "GE"."DE_NOM"<>'PNCDB'))
 130 - filter("DE_NTE" IS NOT NULL)
 131 - filter(("FPA"."PE_CHA" IS NOT NULL AND SUBSTR("FPA"."PE_CHA",2,1)='D'))
 132 - access("GE"."DE_NOM"="FPA"."PE_NOM")
       filter("FPA"."PE_NOM"<>'PNCDB')
 133 - filter(("T_ELEMENTS"."REFDOSS"=:B3 AND NVL("T_ELEMENTS"."LIBELLE",'X') NOT LIKE 'REMBOURSEMENT NC%' AND "T_ELEMENTS"."LIBELLE" NOT LIKE '%MVT
              MIGRATION CTX%' AND "T_ELEMENTS"."LIBELLE" IS NOT NULL AND (NVL("T_ELEMENTS"."MONTANT_DOS",0)-"FTR_MATCH"."LETTRREELDETTE"("T_ELEMENTS"."REFELEM","T_
              ELEMENTS"."TYPEELEM","T_ELEMENTS"."ABREV")>0 OR "FTR_MATCH"."DATEDERNLETTR"("T_ELEMENTS"."REFELEM","T_ELEMENTS"."TYPEELEM","T_ELEMENTS"."ABREV","T_EL
              EMENTS"."REFDOSS",'f')>TO_NUMBER(TO_CHAR(ADD_MONTHS(SYSDATE@!,(-NVL(:B4,1))),'j')))))
 134 - access("DE_NUM"="T_ELEMENTS"."REFELEM" AND "T_ELEMENTS"."TYPEELEM"='rg')
       filter( IS NULL)
 137 - access("G2"."REFELEM"=:B1)
 138 - filter("V2"."FG_PARENT_INVOICE"='O')
 139 - access("G2"."TYPE"="V2"."TYPE")
 140 - filter("T"."RN"=1)
 142 - filter("T_ELEMENTS"."REFDOSS"=:B3)
 147 - access("CMPT"."REFDOSS"=:B3)
 148 - access("CL"."REFDOSS"=:B3 AND "CL"."REFTYPE"=DECODE("CMPT"."CATEGDOSS",'COMPTE IMP','TC','CL'))
 149 - access("ICL"."REFINDIVIDU"="CL"."REFINDIVIDU")



-- SQL2

Plan hash value: 238437186
------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                         | Name                    | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   |
------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                                  |                         |      1 |        |   144K(100)|      0 |00:00:00.01 |
|   1 |  SORT AGGREGATE                                   |                         |      0 |      1 |            |      0 |00:00:00.01 |
|   2 |   NESTED LOOPS                                    |                         |      0 |      1 |     4   (0)|      0 |00:00:00.01 |
|   3 |    NESTED LOOPS                                   |                         |      0 |      1 |     4   (0)|      0 |00:00:00.01 |
|   4 |     NESTED LOOPS                                  |                         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |
|   5 |      NESTED LOOPS                                 |                         |      0 |      1 |     2   (0)|      0 |00:00:00.01 |
|   6 |       TABLE ACCESS BY INDEX ROWID                 | G_ELEMFI                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |
|*  7 |        INDEX UNIQUE SCAN                          | EFI_REFELEM             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |
|*  8 |       INDEX RANGE SCAN                            | AK_KEY_2_G_ELEMFI       |      0 |      1 |     1   (0)|      0 |00:00:00.01 |
|*  9 |      TABLE ACCESS BY INDEX ROWID BATCHED          | G_PIECE                 |      0 |      1 |     1   (0)|      0 |00:00:00.01 |
|* 10 |       INDEX RANGE SCAN                            | PIE_REFPIECE            |      0 |      1 |     1   (0)|      0 |00:00:00.01 |
|* 11 |     INDEX RANGE SCAN                              | G_OUTPMT_EXEC_REFER_IDX |      0 |      1 |     1   (0)|      0 |00:00:00.01 |
|* 12 |    TABLE ACCESS BY INDEX ROWID                    | G_OUTPMT_EXEC           |      0 |      1 |     1   (0)|      0 |00:00:00.01 |
|  13 |  SORT AGGREGATE                                   |                         |      0 |      1 |            |      0 |00:00:00.01 |
|* 14 |   TABLE ACCESS BY INDEX ROWID BATCHED             | NAM_ECR_COMPTA_BAK      |      0 |      1 |     3   (0)|      0 |00:00:00.01 |
|* 15 |    INDEX SKIP SCAN                                | NEC_BAK_RECONCIL_IDX    |      0 |    468 |     2   (0)|      0 |00:00:00.01 |
|* 16 |  VIEW                                             |                         |      1 |      4 |   144K  (1)|      0 |00:00:00.01 |
|* 17 |   COUNT STOPKEY                                   |                         |      1 |        |            |      0 |00:00:00.01 |
|  18 |    VIEW                                           |                         |      1 |      4 |   144K  (1)|      0 |00:00:00.01 |
|  19 |     WINDOW SORT                                   |                         |      1 |      4 |   144K  (1)|      0 |00:00:00.01 |
|  20 |      VIEW                                         |                         |      1 |      4 |   144K  (1)|      0 |00:00:00.01 |
|  21 |       SORT UNIQUE                                 |                         |      1 |      4 |   144K  (1)|      0 |00:00:00.01 |
|  22 |        UNION-ALL                                  |                         |      1 |        |            |      0 |00:00:00.01 |
|  23 |         SORT GROUP BY                             |                         |      0 |      1 |            |      0 |00:00:00.01 |
|* 24 |          INDEX FULL SCAN                          | GP_REFEXT_IDX           |      0 |   2512 |     5   (0)|      0 |00:00:00.01 |
|  25 |           NESTED LOOPS                            |                         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |
|  26 |            NESTED LOOPS                           |                         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |
|  27 |             MERGE JOIN CARTESIAN                  |                         |      0 |      1 |     2   (0)|      0 |00:00:00.01 |
|* 28 |              TABLE ACCESS BY INDEX ROWID BATCHED  | G_ELEMFI                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |
|* 29 |               INDEX RANGE SCAN                    | G_ELEMFI_DOS_TYP_FG02   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |
|  30 |              BUFFER SORT                          |                         |      0 |     23 |     1   (0)|      0 |00:00:00.01 |
|  31 |               TABLE ACCESS BY INDEX ROWID BATCHED | G_ELEMFI                |      0 |     23 |     1   (0)|      0 |00:00:00.01 |
|* 32 |                INDEX RANGE SCAN                   | G_ELEMFI_REFPIECE_IDX   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |
|* 33 |             INDEX RANGE SCAN                      | VEN_ENCAIS              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |
|* 34 |            TABLE ACCESS BY INDEX ROWID            | G_VENELEM               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |
|* 35 |         FILTER                                    |                         |      1 |        |            |      0 |00:00:00.01 |
|  36 |          NESTED LOOPS OUTER                       |                         |      1 |      1 |     8   (0)|      0 |00:00:00.01 |
|  37 |           NESTED LOOPS OUTER                      |                         |      1 |      1 |     5   (0)|      0 |00:00:00.01 |
|  38 |            NESTED LOOPS                           |                         |      1 |      1 |     4   (0)|      0 |00:00:00.01 |
|  39 |             NESTED LOOPS OUTER                    |                         |      1 |      1 |     3   (0)|      0 |00:00:00.01 |
|  40 |              NESTED LOOPS                         |                         |      1 |      1 |     2   (0)|      0 |00:00:00.01 |
|* 41 |               TABLE ACCESS BY INDEX ROWID BATCHED | G_DOSSIER               |      1 |      1 |     1   (0)|      0 |00:00:00.01 |
|* 42 |                INDEX RANGE SCAN                   | DOSS_CODESOC_IDX        |      1 |      1 |     1   (0)|      0 |00:00:00.01 |
|* 43 |               TABLE ACCESS BY INDEX ROWID BATCHED | T_ELEMENTS              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |
|* 44 |                INDEX RANGE SCAN                   | ELE_ELEMDOSS            |      0 |      1 |     1   (0)|      0 |00:00:00.01 |
|  45 |              VIEW PUSHED PREDICATE                | VW_SSQ_1                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |
|  46 |               SORT GROUP BY                       |                         |      0 |      1 |     1   (0)|      0 |00:00:00.01 |
|* 47 |                TABLE ACCESS BY INDEX ROWID BATCHED| G_PRELETTRAGE           |      0 |      1 |     1   (0)|      0 |00:00:00.01 |
|* 48 |                 INDEX RANGE SCAN                  | G_PREL_ELEM             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |
|* 49 |             TABLE ACCESS BY INDEX ROWID           | G_ELEMFI                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |
|* 50 |              INDEX UNIQUE SCAN                    | EFI_REFELEM             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |
|* 51 |            TABLE ACCESS BY INDEX ROWID BATCHED    | G_PIECE                 |      0 |      1 |     1   (0)|      0 |00:00:00.01 |
|* 52 |             INDEX RANGE SCAN                      | PIE_REFDOSS             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |
|* 53 |           VIEW PUSHED PREDICATE                   |                         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |
|  54 |            WINDOW BUFFER                          |                         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |
|* 55 |             FILTER                                |                         |      0 |        |            |      0 |00:00:00.01 |
|  56 |              NESTED LOOPS                         |                         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |
|  57 |               NESTED LOOPS                        |                         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |
|  58 |                NESTED LOOPS                       |                         |      0 |      1 |     2   (0)|      0 |00:00:00.01 |
|  59 |                 TABLE ACCESS BY INDEX ROWID       | G_DOSSIER               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |
|* 60 |                  INDEX RANGE SCAN                 | DOSS_CODESOC_IDX        |      0 |      1 |     1   (0)|      0 |00:00:00.01 |
|* 61 |                 INDEX RANGE SCAN                  | INT_REFDOSS             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |
|* 62 |                INDEX UNIQUE SCAN                  | IND_REFINDIV            |      0 |      1 |     1   (0)|      0 |00:00:00.01 |
|  63 |               TABLE ACCESS BY INDEX ROWID         | G_INDIVIDU              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |
|  64 |          NESTED LOOPS                             |                         |      0 |      1 |     2   (0)|      0 |00:00:00.01 |
|  65 |           TABLE ACCESS BY INDEX ROWID             | G_ELEMFI                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |
|* 66 |            INDEX UNIQUE SCAN                      | EFI_REFELEM             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |
|* 67 |           TABLE ACCESS BY INDEX ROWID BATCHED     | V_ELEMFI                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |
|* 68 |            INDEX RANGE SCAN                       | VF_TYPE_FINANCING       |      0 |      1 |     1   (0)|      0 |00:00:00.01 |
|* 69 |          FILTER                                   |                         |      0 |        |            |      0 |00:00:00.01 |
|* 70 |           TABLE ACCESS BY INDEX ROWID BATCHED     | G_PIECE                 |      0 |      1 |     1   (0)|      0 |00:00:00.01 |
|* 71 |            INDEX RANGE SCAN                       | PIE_REFPIECE            |      0 |      1 |     1   (0)|      0 |00:00:00.01 |
|* 72 |         FILTER                                    |                         |      0 |        |            |      0 |00:00:00.01 |
|  73 |          NESTED LOOPS OUTER                       |                         |      0 |      1 |     6   (0)|      0 |00:00:00.01 |
|  74 |           NESTED LOOPS                            |                         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |
|  75 |            NESTED LOOPS                           |                         |      0 |      1 |     2   (0)|      0 |00:00:00.01 |
|* 76 |             TABLE ACCESS BY INDEX ROWID BATCHED   | G_DOSSIER               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |
|* 77 |              INDEX RANGE SCAN                     | DOSS_CODESOC_IDX        |      0 |      1 |     1   (0)|      0 |00:00:00.01 |
|* 78 |             TABLE ACCESS BY INDEX ROWID BATCHED   | T_ELEMENTS              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |
|* 79 |              INDEX RANGE SCAN                     | ELE_ELEMDOSS            |      0 |      1 |     1   (0)|      0 |00:00:00.01 |
|* 80 |            TABLE ACCESS BY INDEX ROWID            | G_ENCAISSEMENT          |      0 |      1 |     1   (0)|      0 |00:00:00.01 |
|* 81 |             INDEX UNIQUE SCAN                     | REFENCAISS              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |
|* 82 |           VIEW PUSHED PREDICATE                   |                         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |
|  83 |            WINDOW BUFFER                          |                         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |
|* 84 |             FILTER                                |                         |      0 |        |            |      0 |00:00:00.01 |
|  85 |              NESTED LOOPS                         |                         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |
|  86 |               NESTED LOOPS                        |                         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |
|  87 |                NESTED LOOPS                       |                         |      0 |      1 |     2   (0)|      0 |00:00:00.01 |
|  88 |                 TABLE ACCESS BY INDEX ROWID       | G_DOSSIER               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |
|* 89 |                  INDEX RANGE SCAN                 | DOSS_CODESOC_IDX        |      0 |      1 |     1   (0)|      0 |00:00:00.01 |
|* 90 |                 INDEX RANGE SCAN                  | INT_REFDOSS             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |
|* 91 |                INDEX UNIQUE SCAN                  | IND_REFINDIV            |      0 |      1 |     1   (0)|      0 |00:00:00.01 |
|  92 |               TABLE ACCESS BY INDEX ROWID         | G_INDIVIDU              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |
|  93 |          NESTED LOOPS                             |                         |      0 |      1 |     2   (0)|      0 |00:00:00.01 |
|  94 |           TABLE ACCESS BY INDEX ROWID             | G_ELEMFI                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |
|* 95 |            INDEX UNIQUE SCAN                      | EFI_REFELEM             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |
|* 96 |           TABLE ACCESS BY INDEX ROWID BATCHED     | V_ELEMFI                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |
|* 97 |            INDEX RANGE SCAN                       | VF_TYPE_FINANCING       |      0 |      1 |     1   (0)|      0 |00:00:00.01 |
|* 98 |         FILTER                                    |                         |      0 |        |            |      0 |00:00:00.01 |
|  99 |          NESTED LOOPS OUTER                       |                         |      0 |      1 |     6   (0)|      0 |00:00:00.01 |
| 100 |           NESTED LOOPS                            |                         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |
| 101 |            NESTED LOOPS                           |                         |      0 |      1 |     2   (0)|      0 |00:00:00.01 |
|*102 |             TABLE ACCESS BY INDEX ROWID BATCHED   | G_DOSSIER               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |
|*103 |              INDEX RANGE SCAN                     | DOSS_CODESOC_IDX        |      0 |      1 |     1   (0)|      0 |00:00:00.01 |
|*104 |             TABLE ACCESS BY INDEX ROWID BATCHED   | T_ELEMENTS              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |
|*105 |              INDEX RANGE SCAN                     | ELE_ELEMDOSS            |      0 |      1 |     1   (0)|      0 |00:00:00.01 |
|*106 |            TABLE ACCESS BY INDEX ROWID            | G_ENCAISSEMENT          |      0 |      1 |     1   (0)|      0 |00:00:00.01 |
|*107 |             INDEX UNIQUE SCAN                     | REFENCAISS              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |
|*108 |           VIEW PUSHED PREDICATE                   |                         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |
| 109 |            WINDOW BUFFER                          |                         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |
|*110 |             FILTER                                |                         |      0 |        |            |      0 |00:00:00.01 |
| 111 |              NESTED LOOPS                         |                         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |
| 112 |               NESTED LOOPS                        |                         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |
| 113 |                NESTED LOOPS                       |                         |      0 |      1 |     2   (0)|      0 |00:00:00.01 |
| 114 |                 TABLE ACCESS BY INDEX ROWID       | G_DOSSIER               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |
|*115 |                  INDEX RANGE SCAN                 | DOSS_CODESOC_IDX        |      0 |      1 |     1   (0)|      0 |00:00:00.01 |
|*116 |                 INDEX RANGE SCAN                  | INT_REFDOSS             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |
|*117 |                INDEX UNIQUE SCAN                  | IND_REFINDIV            |      0 |      1 |     1   (0)|      0 |00:00:00.01 |
| 118 |               TABLE ACCESS BY INDEX ROWID         | G_INDIVIDU              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |
| 119 |          NESTED LOOPS                             |                         |      0 |      1 |     2   (0)|      0 |00:00:00.01 |
| 120 |           TABLE ACCESS BY INDEX ROWID             | G_ELEMFI                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |
|*121 |            INDEX UNIQUE SCAN                      | EFI_REFELEM             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |
|*122 |           TABLE ACCESS BY INDEX ROWID BATCHED     | V_ELEMFI                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |
|*123 |            INDEX RANGE SCAN                       | VF_TYPE_FINANCING       |      0 |      1 |     1   (0)|      0 |00:00:00.01 |
|*124 |         FILTER                                    |                         |      0 |        |            |      0 |00:00:00.01 |
| 125 |          NESTED LOOPS OUTER                       |                         |      0 |      1 |     7   (0)|      0 |00:00:00.01 |
| 126 |           NESTED LOOPS                            |                         |      0 |      1 |     4   (0)|      0 |00:00:00.01 |
| 127 |            NESTED LOOPS                           |                         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |
| 128 |             NESTED LOOPS                          |                         |      0 |      1 |     2   (0)|      0 |00:00:00.01 |
|*129 |              TABLE ACCESS BY INDEX ROWID BATCHED  | G_DOSSIER               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |
|*130 |               INDEX RANGE SCAN                    | DOSS_CODESOC_IDX        |      0 |      1 |     1   (0)|      0 |00:00:00.01 |
|*131 |              TABLE ACCESS BY INDEX ROWID BATCHED  | F_DETENR                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |
|*132 |               INDEX FULL SCAN                     | DETENR_NTE              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |
|*133 |             TABLE ACCESS BY INDEX ROWID BATCHED   | T_ELEMENTS              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |
|*134 |              INDEX RANGE SCAN                     | ELE_ELEMDOSS            |      0 |      1 |     1   (0)|      0 |00:00:00.01 |
|*135 |            TABLE ACCESS BY INDEX ROWID            | F_PARENR                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |
|*136 |             INDEX UNIQUE SCAN                     | PARENR_CL1              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |
|*137 |           VIEW PUSHED PREDICATE                   |                         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |
| 138 |            WINDOW BUFFER                          |                         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |
|*139 |             FILTER                                |                         |      0 |        |            |      0 |00:00:00.01 |
| 140 |              NESTED LOOPS                         |                         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |
| 141 |               NESTED LOOPS                        |                         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |
| 142 |                NESTED LOOPS                       |                         |      0 |      1 |     2   (0)|      0 |00:00:00.01 |
| 143 |                 TABLE ACCESS BY INDEX ROWID       | G_DOSSIER               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |
|*144 |                  INDEX RANGE SCAN                 | DOSS_CODESOC_IDX        |      0 |      1 |     1   (0)|      0 |00:00:00.01 |
|*145 |                 INDEX RANGE SCAN                  | INT_REFDOSS             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |
|*146 |                INDEX UNIQUE SCAN                  | IND_REFINDIV            |      0 |      1 |     1   (0)|      0 |00:00:00.01 |
| 147 |               TABLE ACCESS BY INDEX ROWID         | G_INDIVIDU              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |
| 148 |          NESTED LOOPS                             |                         |      0 |      1 |     2   (0)|      0 |00:00:00.01 |
| 149 |           TABLE ACCESS BY INDEX ROWID             | G_ELEMFI                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |
|*150 |            INDEX UNIQUE SCAN                      | EFI_REFELEM             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |
|*151 |           TABLE ACCESS BY INDEX ROWID BATCHED     | V_ELEMFI                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |
|*152 |            INDEX RANGE SCAN                       | VF_TYPE_FINANCING       |      0 |      1 |     1   (0)|      0 |00:00:00.01 |
------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   7 - access("E"."REFELEM"=:B1)
   8 - access("A"."REFFACTURE"="E"."REFPIECE2")
   9 - filter("B"."GPIRESSORT" IS NOT NULL)
  10 - access("B"."REFPIECE"="A"."REFAGGR")
  11 - access("O"."REFER"="B"."GPIRESSORT")
  12 - filter("O"."DTEXECUTION_DT" IS NOT NULL)
  14 - filter(("AGGR"."EXTREF19"=:B1 AND "AGGR"."CODEOPER"='MATCH_PMT'))
  15 - access("AGGR"."STATUS_RECONCIL"='REJECTED')
       filter("AGGR"."STATUS_RECONCIL"='REJECTED')
  16 - filter("RNUM">=:B1)
  17 - filter(ROWNUM<=:B5)
  24 - filter( IS NOT NULL)
  28 - filter("POI"."REF_CREANCE"=:B1)
  29 - access("POI"."REFDOSS"=:B1 AND "POI"."TYPE"='PO INVOICED')
  32 - access("REFPIECE3"=:B1)
  33 - access("POI"."REFELEM"="V"."REFENCAISS")
  34 - filter(("V"."TYPENCAISS"='fi' AND "REFELEM"="V"."REFELEM" AND "V"."TYPELEM"='fi'))
  35 - filter(( IS NULL AND  IS NULL))
  41 - filter("GD"."CATEGDOSS" LIKE 'COMPTE%')
  42 - access("GD"."REFDOSS"=:B3)
  43 - filter((NVL("T_ELEMENTS"."LIBELLE",'X') NOT LIKE 'REMBOURSEMENT NC%' AND "T_ELEMENTS"."LIBELLE" NOT LIKE '%MVT MIGRATION
              CTX%' AND "T_ELEMENTS"."LIBELLE" IS NOT NULL AND (NVL("T_ELEMENTS"."MONTANT_DOS",0)-"FTR_MATCH"."LETTRREELDETTE"("T_ELEMENTS"."REF
              ELEM","T_ELEMENTS"."TYPEELEM",'')>0 OR "FTR_MATCH"."DATEDERNLETTR"("T_ELEMENTS"."REFELEM","T_ELEMENTS"."TYPEELEM","T_ELEMENTS"."AB
              REV","T_ELEMENTS"."REFDOSS",'f')>TO_NUMBER(TO_CHAR(ADD_MONTHS(SYSDATE@!,(-TO_NUMBER(NVL(:B4,'1')))),'j'))) AND
              INTERNAL_FUNCTION("T_ELEMENTS"."IMX_UN_ID")))
  44 - access("T_ELEMENTS"."REFDOSS"=:B3 AND "T_ELEMENTS"."TYPEELEM"='fi')
  47 - filter("TYPELEM"="T_ELEMENTS"."TYPEELEM")
  48 - access("REFELEM"="T_ELEMENTS"."REFELEM")
  49 - filter(("GE"."TYPE"<>'SALES ORDER' AND NVL("GE"."LIBELLE",'X')<>'TOLERANCE AMOUNT' AND "GE"."MONTANT_DOS">=0))
  50 - access("GE"."REFELEM"="T_ELEMENTS"."REFELEM")
  51 - filter(("GP_FACT"."GPIHEURE" IS NOT NULL AND "GE"."REFELEM"="GP_FACT"."GPIHEURE"))
  52 - access("GP_FACT"."REFDOSS"=:B3 AND "GP_FACT"."TYPPIECE"='FACTURE')
  53 - filter("T"."RN"=1)
  55 - filter("T_ELEMENTS"."REFDOSS"=:B3)
  60 - access("CMPT"."REFDOSS"=:B3)
  61 - access("CL"."REFDOSS"=:B3 AND "CL"."REFTYPE"=DECODE("CMPT"."CATEGDOSS",'COMPTE IMP','TC','CL'))
  62 - access("ICL"."REFINDIVIDU"="CL"."REFINDIVIDU")
  66 - access("G2"."REFELEM"=:B1)
  67 - filter("V2"."FG_PARENT_INVOICE"='O')
  68 - access("G2"."TYPE"="V2"."TYPE")
  69 - filter(:B1 IS NOT NULL)
  70 - filter("PO"."TYPPIECE"='BON DE COMMANDE')
  71 - access("PO"."REFPIECE"=:B1)
  72 - filter( IS NULL)
  76 - filter("GD"."CATEGDOSS" LIKE 'COMPTE%')
  77 - access("GD"."REFDOSS"=:B3)
  78 - filter((NVL("T_ELEMENTS"."LIBELLE",'X') NOT LIKE 'REMBOURSEMENT NC%' AND "T_ELEMENTS"."LIBELLE" NOT LIKE '%MVT MIGRATION
              CTX%' AND "T_ELEMENTS"."LIBELLE" IS NOT NULL AND (NVL("T_ELEMENTS"."MONTANT_DOS",0)-"FTR_MATCH"."LETTRREELDETTE"("T_ELEMENTS"."REF
              ELEM","T_ELEMENTS"."TYPEELEM",'')>0 OR "FTR_MATCH"."DATEDERNLETTR"("T_ELEMENTS"."REFELEM","T_ELEMENTS"."TYPEELEM","T_ELEMENTS"."AB
              REV","T_ELEMENTS"."REFDOSS",'f')>TO_NUMBER(TO_CHAR(ADD_MONTHS(SYSDATE@!,(-TO_NUMBER(NVL(:B4,'1')))),'j'))) AND
              INTERNAL_FUNCTION("T_ELEMENTS"."IMX_UN_ID")))
  79 - access("T_ELEMENTS"."REFDOSS"=:B3)
       filter(("T_ELEMENTS"."TYPEELEM"='tp' OR "T_ELEMENTS"."TYPEELEM"='ve'))
  80 - filter("GE"."TYPENCAISS"=DECODE("T_ELEMENTS"."TYPEELEM",'tp','e_sadecaiss','e_savirmt'))
  81 - access("GE"."REFENCAISS"="T_ELEMENTS"."REFELEM")
  82 - filter("T"."RN"=1)
  84 - filter("T_ELEMENTS"."REFDOSS"=:B3)
  89 - access("CMPT"."REFDOSS"=:B3)
  90 - access("CL"."REFDOSS"=:B3 AND "CL"."REFTYPE"=DECODE("CMPT"."CATEGDOSS",'COMPTE IMP','TC','CL'))
  91 - access("ICL"."REFINDIVIDU"="CL"."REFINDIVIDU")
  95 - access("G2"."REFELEM"=:B1)
  96 - filter("V2"."FG_PARENT_INVOICE"='O')
  97 - access("G2"."TYPE"="V2"."TYPE")
  98 - filter( IS NULL)
 102 - filter("GD"."CATEGDOSS" LIKE 'COMPTE%')
 103 - access("GD"."REFDOSS"=:B3)
 104 - filter((NVL("T_ELEMENTS"."LIBELLE",'X') NOT LIKE 'REMBOURSEMENT NC%' AND "T_ELEMENTS"."LIBELLE" NOT LIKE '%MVT MIGRATION
              CTX%' AND "T_ELEMENTS"."LIBELLE" IS NOT NULL AND (NVL("T_ELEMENTS"."MONTANT_DOS",0)-"FTR_MATCH"."LETTRREELDETTE"("T_ELEMENTS"."REF
              ELEM","T_ELEMENTS"."TYPEELEM",'')>0 OR "FTR_MATCH"."DATEDERNLETTR"("T_ELEMENTS"."REFELEM","T_ELEMENTS"."TYPEELEM","T_ELEMENTS"."AB
              REV","T_ELEMENTS"."REFDOSS",'f')>TO_NUMBER(TO_CHAR(ADD_MONTHS(SYSDATE@!,(-TO_NUMBER(NVL(:B4,'1')))),'j'))) AND
              INTERNAL_FUNCTION("T_ELEMENTS"."IMX_UN_ID")))
 105 - access("T_ELEMENTS"."REFDOSS"=:B3 AND "T_ELEMENTS"."TYPEELEM"='rd')
 106 - filter("GE"."TYPENCAISS"='rembdir')
 107 - access("GE"."REFENCAISS"="T_ELEMENTS"."REFELEM")
 108 - filter("T"."RN"=1)
 110 - filter("T_ELEMENTS"."REFDOSS"=:B3)
 115 - access("CMPT"."REFDOSS"=:B3)
 116 - access("CL"."REFDOSS"=:B3 AND "CL"."REFTYPE"=DECODE("CMPT"."CATEGDOSS",'COMPTE IMP','TC','CL'))
 117 - access("ICL"."REFINDIVIDU"="CL"."REFINDIVIDU")
 121 - access("G2"."REFELEM"=:B1)
 122 - filter("V2"."FG_PARENT_INVOICE"='O')
 123 - access("G2"."TYPE"="V2"."TYPE")
 124 - filter( IS NULL)
 129 - filter("GD"."CATEGDOSS" LIKE 'COMPTE%')
 130 - access("GD"."REFDOSS"=:B3)
 131 - filter(((("DE_SEN"='R' AND "DE_DES"='T') OR ("DE_SEN"='V' AND "DE_DES"='E')) AND "GE"."DE_NOM"<>'PNCDB'))
 132 - filter("DE_NTE" IS NOT NULL)
 133 - filter(("DE_NUM"="T_ELEMENTS"."REFELEM" AND NVL("T_ELEMENTS"."LIBELLE",'X') NOT LIKE 'REMBOURSEMENT NC%' AND
              "T_ELEMENTS"."LIBELLE" NOT LIKE '%MVT MIGRATION CTX%' AND "T_ELEMENTS"."LIBELLE" IS NOT NULL AND
              (NVL("T_ELEMENTS"."MONTANT_DOS",0)-"FTR_MATCH"."LETTRREELDETTE"("T_ELEMENTS"."REFELEM","T_ELEMENTS"."TYPEELEM","T_ELEMENTS"."ABREV
              ")>0 OR "FTR_MATCH"."DATEDERNLETTR"("T_ELEMENTS"."REFELEM","T_ELEMENTS"."TYPEELEM","T_ELEMENTS"."ABREV","T_ELEMENTS"."REFDOSS",'f'
              )>TO_NUMBER(TO_CHAR(ADD_MONTHS(SYSDATE@!,(-TO_NUMBER(NVL(:B4,'1')))),'j'))) AND INTERNAL_FUNCTION("T_ELEMENTS"."IMX_UN_ID")))
 134 - access("T_ELEMENTS"."REFDOSS"=:B3 AND "T_ELEMENTS"."TYPEELEM"='rg')
 135 - filter(("FPA"."PE_CHA" IS NOT NULL AND SUBSTR("FPA"."PE_CHA",2,1)='D'))
 136 - access("GE"."DE_NOM"="FPA"."PE_NOM")
       filter("FPA"."PE_NOM"<>'PNCDB')
 137 - filter("T"."RN"=1)
 139 - filter("T_ELEMENTS"."REFDOSS"=:B3)
 144 - access("CMPT"."REFDOSS"=:B3)
 145 - access("CL"."REFDOSS"=:B3 AND "CL"."REFTYPE"=DECODE("CMPT"."CATEGDOSS",'COMPTE IMP','TC','CL'))
 146 - access("ICL"."REFINDIVIDU"="CL"."REFINDIVIDU")
 150 - access("G2"."REFELEM"=:B1)
 151 - filter("V2"."FG_PARENT_INVOICE"='O')
 152 - access("G2"."TYPE"="V2"."TYPE")



-- SQL3


Plan hash value: 3135024063
-------------------------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                         | Name                    | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  |
-------------------------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                                  |                         |      1 |        |   144K(100)|   1570 |00:06:58.04 |     100M|      1 |
|   1 |  SORT AGGREGATE                                   |                         |   1570 |      1 |            |   1570 |00:00:00.02 |    2048 |      0 |
|   2 |   NESTED LOOPS                                    |                         |   1570 |      1 |     4   (0)|      0 |00:00:00.02 |    2048 |      0 |
|   3 |    NESTED LOOPS                                   |                         |   1570 |      1 |     4   (0)|      0 |00:00:00.02 |    2048 |      0 |
|   4 |     NESTED LOOPS                                  |                         |   1570 |      1 |     3   (0)|      0 |00:00:00.02 |    2048 |      0 |
|   5 |      NESTED LOOPS                                 |                         |   1570 |      1 |     2   (0)|      0 |00:00:00.02 |    2048 |      0 |
|   6 |       TABLE ACCESS BY INDEX ROWID                 | G_ELEMFI                |   1570 |      1 |     1   (0)|   1570 |00:00:00.01 |    1729 |      0 |
|*  7 |        INDEX UNIQUE SCAN                          | EFI_REFELEM             |   1570 |      1 |     1   (0)|   1570 |00:00:00.01 |     159 |      0 |
|*  8 |       INDEX RANGE SCAN                            | AK_KEY_2_G_ELEMFI       |   1570 |      1 |     1   (0)|      0 |00:00:00.01 |     319 |      0 |
|*  9 |      TABLE ACCESS BY INDEX ROWID BATCHED          | G_PIECE                 |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 10 |       INDEX RANGE SCAN                            | PIE_REFPIECE            |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 11 |     INDEX RANGE SCAN                              | G_OUTPMT_EXEC_REFER_IDX |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 12 |    TABLE ACCESS BY INDEX ROWID                    | G_OUTPMT_EXEC           |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|  13 |  SORT AGGREGATE                                   |                         |   1570 |      1 |            |   1570 |00:00:19.00 |    3052K|      0 |
|* 14 |   TABLE ACCESS BY INDEX ROWID BATCHED             | NAM_ECR_COMPTA_BAK      |   1570 |      1 |     3   (0)|    158 |00:00:18.99 |    3052K|      0 |
|* 15 |    INDEX SKIP SCAN                                | NEC_BAK_RECONCIL_IDX    |   1570 |    468 |     2   (0)|     16M|00:00:06.73 |     197K|      0 |
|* 16 |  VIEW                                             |                         |      1 |      4 |   144K  (1)|   1570 |00:06:58.04 |     100M|      1 |
|* 17 |   COUNT STOPKEY                                   |                         |      1 |        |            |   1570 |00:06:58.04 |     100M|      1 |
|  18 |    VIEW                                           |                         |      1 |      4 |   144K  (1)|   1570 |00:06:58.03 |     100M|      1 |
|  19 |     WINDOW SORT                                   |                         |      1 |      4 |   144K  (1)|   1570 |00:06:57.06 |     100M|      1 |
|  20 |      VIEW                                         |                         |      1 |      4 |   144K  (1)|   1570 |00:06:57.03 |     100M|      1 |
|  21 |       SORT UNIQUE                                 |                         |      1 |      4 |   144K  (1)|   1570 |00:06:57.03 |     100M|      1 |
|  22 |        UNION-ALL                                  |                         |      1 |        |            |   1570 |00:06:57.02 |     100M|      1 |
|  23 |         SORT GROUP BY                             |                         |   1570 |      1 |            |   1570 |00:06:56.13 |     100M|      0 |
|* 24 |          INDEX FULL SCAN                          | GP_REFEXT_IDX           |   1570 |   2512 |     5   (0)|      0 |00:06:56.10 |     100M|      0 |
|  25 |           NESTED LOOPS                            |                         |     99M|      1 |     3   (0)|      0 |00:04:53.94 |      99M|      0 |
|  26 |            NESTED LOOPS                           |                         |     99M|      1 |     3   (0)|      0 |00:04:30.50 |      99M|      0 |
|  27 |             MERGE JOIN CARTESIAN                  |                         |     99M|      1 |     2   (0)|      0 |00:04:11.85 |      99M|      0 |
|* 28 |              TABLE ACCESS BY INDEX ROWID BATCHED  | G_ELEMFI                |     99M|      1 |     1   (0)|      0 |00:03:13.03 |      99M|      0 |
|* 29 |               INDEX RANGE SCAN                    | G_ELEMFI_DOS_TYP_FG02   |     99M|      1 |     1   (0)|      0 |00:02:43.83 |      99M|      0 |
|  30 |              BUFFER SORT                          |                         |      0 |     23 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|  31 |               TABLE ACCESS BY INDEX ROWID BATCHED | G_ELEMFI                |      0 |     23 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 32 |                INDEX RANGE SCAN                   | G_ELEMFI_REFPIECE_IDX   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 33 |             INDEX RANGE SCAN                      | VEN_ENCAIS              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 34 |            TABLE ACCESS BY INDEX ROWID            | G_VENELEM               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 35 |         FILTER                                    |                         |      1 |        |            |   1570 |00:00:00.69 |   22884 |      0 |
|  36 |          NESTED LOOPS OUTER                       |                         |      1 |      1 |     8   (0)|   1570 |00:00:00.65 |   16336 |      0 |
|  37 |           NESTED LOOPS OUTER                      |                         |      1 |      1 |     5   (0)|   1570 |00:00:00.58 |   16303 |      0 |
|  38 |            NESTED LOOPS                           |                         |      1 |      1 |     4   (0)|   1570 |00:00:00.56 |   11766 |      0 |
|  39 |             NESTED LOOPS OUTER                    |                         |      1 |      1 |     3   (0)|   1570 |00:00:00.54 |   11292 |      0 |
|  40 |              NESTED LOOPS                         |                         |      1 |      1 |     2   (0)|   1570 |00:00:00.53 |   11288 |      0 |
|* 41 |               TABLE ACCESS BY INDEX ROWID         | G_DOSSIER               |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |      0 |
|* 42 |                INDEX UNIQUE SCAN                  | DOS_REFDOSS             |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       2 |      0 |
|* 43 |               TABLE ACCESS BY INDEX ROWID BATCHED | T_ELEMENTS              |      1 |      1 |     1   (0)|   1570 |00:00:00.53 |   11285 |      0 |
|* 44 |                INDEX RANGE SCAN                   | ELE_DOSS_TYP_ASSOC_LIB  |      1 |      1 |     1   (0)|   2014 |00:00:00.01 |      17 |      0 |
|  45 |              VIEW PUSHED PREDICATE                | VW_SSQ_1                |   1570 |      1 |     1   (0)|      1 |00:00:00.01 |       4 |      0 |
|  46 |               SORT GROUP BY                       |                         |   1570 |      1 |     1   (0)|      1 |00:00:00.01 |       4 |      0 |
|* 47 |                TABLE ACCESS BY INDEX ROWID BATCHED| G_PRELETTRAGE           |   1570 |      1 |     1   (0)|      1 |00:00:00.01 |       4 |      0 |
|* 48 |                 INDEX RANGE SCAN                  | G_PREL_ELEM             |   1570 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |      0 |
|* 49 |             TABLE ACCESS BY INDEX ROWID           | G_ELEMFI                |   1570 |      1 |     1   (0)|   1570 |00:00:00.01 |     474 |      0 |
|* 50 |              INDEX UNIQUE SCAN                    | EFI_REFELEM             |   1570 |      1 |     1   (0)|   1570 |00:00:00.01 |     299 |      0 |
|* 51 |            TABLE ACCESS BY INDEX ROWID BATCHED    | G_PIECE                 |   1570 |      1 |     1   (0)|   1570 |00:00:00.03 |    4537 |      0 |
|* 52 |             INDEX RANGE SCAN                      | GP_GRTYPE_MT_DT         |   1570 |      1 |     1   (0)|   1570 |00:00:00.01 |     868 |      0 |
|* 53 |           VIEW PUSHED PREDICATE                   |                         |   1570 |      1 |     3   (0)|   1570 |00:00:00.07 |      33 |      0 |
|  54 |            WINDOW BUFFER                          |                         |   1570 |      1 |     3   (0)|   1570 |00:00:00.06 |      33 |      0 |
|* 55 |             FILTER                                |                         |   1570 |        |            |   1570 |00:00:00.03 |      33 |      0 |
|  56 |              NESTED LOOPS                         |                         |   1570 |      1 |     3   (0)|   1570 |00:00:00.03 |      33 |      0 |
|  57 |               NESTED LOOPS                        |                         |   1570 |      1 |     3   (0)|   1570 |00:00:00.03 |      32 |      0 |
|  58 |                NESTED LOOPS                       |                         |   1570 |      1 |     2   (0)|   1570 |00:00:00.02 |      18 |      0 |
|  59 |                 TABLE ACCESS BY INDEX ROWID       | G_DOSSIER               |   1570 |      1 |     1   (0)|   1570 |00:00:00.01 |      10 |      0 |
|* 60 |                  INDEX UNIQUE SCAN                | DOS_REFDOSS             |   1570 |      1 |     1   (0)|   1570 |00:00:00.01 |       9 |      0 |
|* 61 |                 INDEX RANGE SCAN                  | INT_REFDOSS             |   1570 |      1 |     1   (0)|   1570 |00:00:00.01 |       8 |      0 |
|* 62 |                INDEX UNIQUE SCAN                  | IND_REFINDIV            |   1570 |      1 |     1   (0)|   1570 |00:00:00.01 |      14 |      0 |
|  63 |               TABLE ACCESS BY INDEX ROWID         | G_INDIVIDU              |   1570 |      1 |     1   (0)|   1570 |00:00:00.01 |       1 |      0 |
|  64 |          NESTED LOOPS                             |                         |   1570 |      1 |     2   (0)|      0 |00:00:00.02 |    6548 |      0 |
|  65 |           TABLE ACCESS BY INDEX ROWID             | G_ELEMFI                |   1570 |      1 |     1   (0)|   1570 |00:00:00.01 |    3397 |      0 |
|* 66 |            INDEX UNIQUE SCAN                      | EFI_REFELEM             |   1570 |      1 |     1   (0)|   1570 |00:00:00.01 |    1827 |      0 |
|* 67 |           TABLE ACCESS BY INDEX ROWID BATCHED     | V_ELEMFI                |   1570 |      1 |     1   (0)|      0 |00:00:00.01 |    3151 |      0 |
|* 68 |            INDEX RANGE SCAN                       | VF_TYPE_FINANCING       |   1570 |      1 |     1   (0)|   1570 |00:00:00.01 |    1581 |      0 |
|* 69 |          FILTER                                   |                         |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
|* 70 |           TABLE ACCESS BY INDEX ROWID BATCHED     | G_PIECE                 |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 71 |            INDEX RANGE SCAN                       | PIE_REFPIECE            |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 72 |         FILTER                                    |                         |      1 |        |            |      0 |00:00:00.01 |       9 |      0 |
|  73 |          NESTED LOOPS OUTER                       |                         |      1 |      1 |     6   (0)|      0 |00:00:00.01 |       9 |      0 |
|  74 |           NESTED LOOPS                            |                         |      1 |      1 |     3   (0)|      0 |00:00:00.01 |       9 |      0 |
|  75 |            NESTED LOOPS                           |                         |      1 |      1 |     2   (0)|      0 |00:00:00.01 |       9 |      0 |
|* 76 |             TABLE ACCESS BY INDEX ROWID           | G_DOSSIER               |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |      0 |
|* 77 |              INDEX UNIQUE SCAN                    | DOS_REFDOSS             |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       2 |      0 |
|  78 |             INLIST ITERATOR                       |                         |      1 |        |            |      0 |00:00:00.01 |       6 |      0 |
|* 79 |              TABLE ACCESS BY INDEX ROWID BATCHED  | T_ELEMENTS              |      2 |      1 |     1   (0)|      0 |00:00:00.01 |       6 |      0 |
|* 80 |               INDEX RANGE SCAN                    | ELE_DOSS_TYP_ASSOC_LIB  |      2 |      1 |     1   (0)|      0 |00:00:00.01 |       6 |      0 |
|* 81 |            TABLE ACCESS BY INDEX ROWID            | G_ENCAISSEMENT          |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 82 |             INDEX UNIQUE SCAN                     | REFENCAISS              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 83 |           VIEW PUSHED PREDICATE                   |                         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|  84 |            WINDOW BUFFER                          |                         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 85 |             FILTER                                |                         |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  86 |              NESTED LOOPS                         |                         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|  87 |               NESTED LOOPS                        |                         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|  88 |                NESTED LOOPS                       |                         |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|  89 |                 TABLE ACCESS BY INDEX ROWID       | G_DOSSIER               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 90 |                  INDEX UNIQUE SCAN                | DOS_REFDOSS             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 91 |                 INDEX RANGE SCAN                  | INT_REFDOSS             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 92 |                INDEX UNIQUE SCAN                  | IND_REFINDIV            |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|  93 |               TABLE ACCESS BY INDEX ROWID         | G_INDIVIDU              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|  94 |          NESTED LOOPS                             |                         |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|  95 |           TABLE ACCESS BY INDEX ROWID             | G_ELEMFI                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 96 |            INDEX UNIQUE SCAN                      | EFI_REFELEM             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 97 |           TABLE ACCESS BY INDEX ROWID BATCHED     | V_ELEMFI                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 98 |            INDEX RANGE SCAN                       | VF_TYPE_FINANCING       |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 99 |         FILTER                                    |                         |      1 |        |            |      0 |00:00:00.01 |       6 |      1 |
| 100 |          NESTED LOOPS OUTER                       |                         |      1 |      1 |     6   (0)|      0 |00:00:00.01 |       6 |      1 |
| 101 |           NESTED LOOPS                            |                         |      1 |      1 |     3   (0)|      0 |00:00:00.01 |       6 |      1 |
| 102 |            NESTED LOOPS                           |                         |      1 |      1 |     2   (0)|      0 |00:00:00.01 |       6 |      1 |
|*103 |             TABLE ACCESS BY INDEX ROWID           | G_DOSSIER               |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |      0 |
|*104 |              INDEX UNIQUE SCAN                    | DOS_REFDOSS             |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       2 |      0 |
|*105 |             TABLE ACCESS BY INDEX ROWID BATCHED   | T_ELEMENTS              |      1 |      1 |     1   (0)|      0 |00:00:00.01 |       3 |      1 |
|*106 |              INDEX RANGE SCAN                     | ELE_DOSS_TYP_ASSOC_LIB  |      1 |      1 |     1   (0)|      0 |00:00:00.01 |       3 |      1 |
|*107 |            TABLE ACCESS BY INDEX ROWID            | G_ENCAISSEMENT          |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*108 |             INDEX UNIQUE SCAN                     | REFENCAISS              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*109 |           VIEW PUSHED PREDICATE                   |                         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
| 110 |            WINDOW BUFFER                          |                         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*111 |             FILTER                                |                         |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 112 |              NESTED LOOPS                         |                         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
| 113 |               NESTED LOOPS                        |                         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
| 114 |                NESTED LOOPS                       |                         |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
| 115 |                 TABLE ACCESS BY INDEX ROWID       | G_DOSSIER               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*116 |                  INDEX UNIQUE SCAN                | DOS_REFDOSS             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*117 |                 INDEX RANGE SCAN                  | INT_REFDOSS             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*118 |                INDEX UNIQUE SCAN                  | IND_REFINDIV            |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 119 |               TABLE ACCESS BY INDEX ROWID         | G_INDIVIDU              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 120 |          NESTED LOOPS                             |                         |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
| 121 |           TABLE ACCESS BY INDEX ROWID             | G_ELEMFI                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*122 |            INDEX UNIQUE SCAN                      | EFI_REFELEM             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*123 |           TABLE ACCESS BY INDEX ROWID BATCHED     | V_ELEMFI                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*124 |            INDEX RANGE SCAN                       | VF_TYPE_FINANCING       |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 125 |         NESTED LOOPS OUTER                        |                         |      1 |      1 |     7   (0)|      0 |00:00:00.01 |       4 |      0 |
| 126 |          NESTED LOOPS                             |                         |      1 |      1 |     4   (0)|      0 |00:00:00.01 |       4 |      0 |
| 127 |           NESTED LOOPS                            |                         |      1 |      1 |     3   (0)|      0 |00:00:00.01 |       4 |      0 |
| 128 |            NESTED LOOPS                           |                         |      1 |      1 |     2   (0)|      0 |00:00:00.01 |       4 |      0 |
|*129 |             TABLE ACCESS BY INDEX ROWID           | G_DOSSIER               |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |      0 |
|*130 |              INDEX UNIQUE SCAN                    | DOS_REFDOSS             |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       2 |      0 |
|*131 |             TABLE ACCESS BY INDEX ROWID BATCHED   | F_DETENR                |      1 |      1 |     1   (0)|      0 |00:00:00.01 |       1 |      0 |
|*132 |              INDEX FULL SCAN                      | DETENR_NTE              |      1 |      1 |     1   (0)|      0 |00:00:00.01 |       1 |      0 |
|*133 |            TABLE ACCESS BY INDEX ROWID            | F_PARENR                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*134 |             INDEX UNIQUE SCAN                     | PARENR_CL1              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*135 |           TABLE ACCESS BY INDEX ROWID BATCHED     | T_ELEMENTS              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*136 |            INDEX RANGE SCAN                       | ELE_ELEMTYPE            |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 137 |             NESTED LOOPS                          |                         |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
| 138 |              TABLE ACCESS BY INDEX ROWID          | G_ELEMFI                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*139 |               INDEX UNIQUE SCAN                   | EFI_REFELEM             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*140 |              TABLE ACCESS BY INDEX ROWID BATCHED  | V_ELEMFI                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*141 |               INDEX RANGE SCAN                    | VF_TYPE_FINANCING       |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*142 |          VIEW PUSHED PREDICATE                    |                         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
| 143 |           WINDOW BUFFER                           |                         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*144 |            FILTER                                 |                         |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
| 145 |             NESTED LOOPS                          |                         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
| 146 |              NESTED LOOPS                         |                         |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |      0 |
| 147 |               NESTED LOOPS                        |                         |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
| 148 |                TABLE ACCESS BY INDEX ROWID        | G_DOSSIER               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*149 |                 INDEX UNIQUE SCAN                 | DOS_REFDOSS             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*150 |                INDEX RANGE SCAN                   | INT_REFDOSS             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*151 |               INDEX UNIQUE SCAN                   | IND_REFINDIV            |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 152 |              TABLE ACCESS BY INDEX ROWID          | G_INDIVIDU              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
-------------------------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   7 - access("E"."REFELEM"=:B1)
   8 - access("A"."REFFACTURE"="E"."REFPIECE2")
   9 - filter("B"."GPIRESSORT" IS NOT NULL)
  10 - access("B"."REFPIECE"="A"."REFAGGR")
  11 - access("O"."REFER"="B"."GPIRESSORT")
  12 - filter("O"."DTEXECUTION_DT" IS NOT NULL)
  14 - filter(("AGGR"."EXTREF19"=:B1 AND "AGGR"."CODEOPER"='MATCH_PMT'))
  15 - access("AGGR"."STATUS_RECONCIL"='REJECTED')
       filter("AGGR"."STATUS_RECONCIL"='REJECTED')
  16 - filter("RNUM">=:B6)
  17 - filter(ROWNUM<=:B5)
  24 - filter( IS NOT NULL)
  28 - filter("POI"."REF_CREANCE"=:B1)
  29 - access("POI"."REFDOSS"=:B1 AND "POI"."TYPE"='PO INVOICED')
  32 - access("REFPIECE3"=:B1)
  33 - access("POI"."REFELEM"="V"."REFENCAISS")
  34 - filter(("V"."TYPENCAISS"='fi' AND "REFELEM"="V"."REFELEM" AND "V"."TYPELEM"='fi'))
  35 - filter(( IS NULL AND  IS NULL))
  41 - filter("GD"."CATEGDOSS" LIKE 'COMPTE%')
  42 - access("GD"."REFDOSS"=:B3)
  43 - filter((NVL("T_ELEMENTS"."MONTANT_DOS",0)-"FTR_MATCH"."LETTRREELDETTE"("T_ELEMENTS"."REFELEM","T_ELEMENTS"."TYPEELEM",'')>0 OR
              "FTR_MATCH"."DATEDERNLETTR"("T_ELEMENTS"."REFELEM","T_ELEMENTS"."TYPEELEM","T_ELEMENTS"."ABREV","T_ELEMENTS"."REFDOSS",'f')>TO_NUMBER(TO_CHAR(ADD_MON
              THS(SYSDATE@!,(-NVL(:B4,1))),'j'))))
  44 - access("T_ELEMENTS"."REFDOSS"=:B3 AND "T_ELEMENTS"."TYPEELEM"='fi')
       filter((NVL("T_ELEMENTS"."LIBELLE",'X') NOT LIKE 'REMBOURSEMENT NC%' AND "T_ELEMENTS"."LIBELLE" NOT LIKE '%MVT MIGRATION CTX%' AND
              "T_ELEMENTS"."LIBELLE" IS NOT NULL))
  47 - filter("TYPELEM"="T_ELEMENTS"."TYPEELEM")
  48 - access("REFELEM"="T_ELEMENTS"."REFELEM")
  49 - filter(("GE"."TYPE"<>'SALES ORDER' AND NVL("GE"."LIBELLE",'X')<>'TOLERANCE AMOUNT' AND "GE"."MONTANT_DOS">=0))
  50 - access("GE"."REFELEM"="T_ELEMENTS"."REFELEM")
  51 - filter("GP_FACT"."REFDOSS"=:B3)
  52 - access("GP_FACT"."TYPPIECE"='FACTURE' AND "GE"."REFELEM"="GP_FACT"."GPIHEURE")
       filter("GP_FACT"."GPIHEURE" IS NOT NULL)
  53 - filter("T"."RN"=1)
  55 - filter("T_ELEMENTS"."REFDOSS"=:B3)
  60 - access("CMPT"."REFDOSS"=:B3)
  61 - access("CL"."REFDOSS"=:B3 AND "CL"."REFTYPE"=DECODE("CMPT"."CATEGDOSS",'COMPTE IMP','TC','CL'))
  62 - access("ICL"."REFINDIVIDU"="CL"."REFINDIVIDU")
  66 - access("G2"."REFELEM"=:B1)
  67 - filter("V2"."FG_PARENT_INVOICE"='O')
  68 - access("G2"."TYPE"="V2"."TYPE")
  69 - filter(:B1 IS NOT NULL)
  70 - filter("PO"."TYPPIECE"='BON DE COMMANDE')
  71 - access("PO"."REFPIECE"=:B1)
  72 - filter( IS NULL)
  76 - filter("GD"."CATEGDOSS" LIKE 'COMPTE%')
  77 - access("GD"."REFDOSS"=:B3)
  79 - filter((NVL("T_ELEMENTS"."MONTANT_DOS",0)-"FTR_MATCH"."LETTRREELDETTE"("T_ELEMENTS"."REFELEM","T_ELEMENTS"."TYPEELEM",'')>0 OR
              "FTR_MATCH"."DATEDERNLETTR"("T_ELEMENTS"."REFELEM","T_ELEMENTS"."TYPEELEM","T_ELEMENTS"."ABREV","T_ELEMENTS"."REFDOSS",'f')>TO_NUMBER(TO_CHAR(ADD_MON
              THS(SYSDATE@!,(-NVL(:B4,1))),'j'))))
  80 - access("T_ELEMENTS"."REFDOSS"=:B3 AND (("T_ELEMENTS"."TYPEELEM"='tp' OR "T_ELEMENTS"."TYPEELEM"='ve')))
       filter((NVL("T_ELEMENTS"."LIBELLE",'X') NOT LIKE 'REMBOURSEMENT NC%' AND "T_ELEMENTS"."LIBELLE" NOT LIKE '%MVT MIGRATION CTX%' AND
              "T_ELEMENTS"."LIBELLE" IS NOT NULL))
  81 - filter("GE"."TYPENCAISS"=DECODE("T_ELEMENTS"."TYPEELEM",'tp','e_sadecaiss','e_savirmt'))
  82 - access("GE"."REFENCAISS"="T_ELEMENTS"."REFELEM")
  83 - filter("T"."RN"=1)
  85 - filter("T_ELEMENTS"."REFDOSS"=:B3)
  90 - access("CMPT"."REFDOSS"=:B3)
  91 - access("CL"."REFDOSS"=:B3 AND "CL"."REFTYPE"=DECODE("CMPT"."CATEGDOSS",'COMPTE IMP','TC','CL'))
  92 - access("ICL"."REFINDIVIDU"="CL"."REFINDIVIDU")
  96 - access("G2"."REFELEM"=:B1)
  97 - filter("V2"."FG_PARENT_INVOICE"='O')
  98 - access("G2"."TYPE"="V2"."TYPE")
  99 - filter( IS NULL)
 103 - filter("GD"."CATEGDOSS" LIKE 'COMPTE%')
 104 - access("GD"."REFDOSS"=:B3)
 105 - filter((NVL("T_ELEMENTS"."MONTANT_DOS",0)-"FTR_MATCH"."LETTRREELDETTE"("T_ELEMENTS"."REFELEM","T_ELEMENTS"."TYPEELEM",'')>0 OR
              "FTR_MATCH"."DATEDERNLETTR"("T_ELEMENTS"."REFELEM","T_ELEMENTS"."TYPEELEM","T_ELEMENTS"."ABREV","T_ELEMENTS"."REFDOSS",'f')>TO_NUMBER(TO_CHAR(ADD_MON
              THS(SYSDATE@!,(-NVL(:B4,1))),'j'))))
 106 - access("T_ELEMENTS"."REFDOSS"=:B3 AND "T_ELEMENTS"."TYPEELEM"='rd')
       filter((NVL("T_ELEMENTS"."LIBELLE",'X') NOT LIKE 'REMBOURSEMENT NC%' AND "T_ELEMENTS"."LIBELLE" NOT LIKE '%MVT MIGRATION CTX%' AND
              "T_ELEMENTS"."LIBELLE" IS NOT NULL))
 107 - filter("GE"."TYPENCAISS"='rembdir')
 108 - access("GE"."REFENCAISS"="T_ELEMENTS"."REFELEM")
 109 - filter("T"."RN"=1)
 111 - filter("T_ELEMENTS"."REFDOSS"=:B3)
 116 - access("CMPT"."REFDOSS"=:B3)
 117 - access("CL"."REFDOSS"=:B3 AND "CL"."REFTYPE"=DECODE("CMPT"."CATEGDOSS",'COMPTE IMP','TC','CL'))
 118 - access("ICL"."REFINDIVIDU"="CL"."REFINDIVIDU")
 122 - access("G2"."REFELEM"=:B1)
 123 - filter("V2"."FG_PARENT_INVOICE"='O')
 124 - access("G2"."TYPE"="V2"."TYPE")
 129 - filter("GD"."CATEGDOSS" LIKE 'COMPTE%')
 130 - access("GD"."REFDOSS"=:B3)
 131 - filter(((("DE_SEN"='R' AND "DE_DES"='T') OR ("DE_SEN"='V' AND "DE_DES"='E')) AND "GE"."DE_NOM"<>'PNCDB'))
 132 - filter("DE_NTE" IS NOT NULL)
 133 - filter(("FPA"."PE_CHA" IS NOT NULL AND SUBSTR("FPA"."PE_CHA",2,1)='D'))
 134 - access("GE"."DE_NOM"="FPA"."PE_NOM")
       filter("FPA"."PE_NOM"<>'PNCDB')
 135 - filter(("T_ELEMENTS"."REFDOSS"=:B3 AND NVL("T_ELEMENTS"."LIBELLE",'X') NOT LIKE 'REMBOURSEMENT NC%' AND "T_ELEMENTS"."LIBELLE" NOT LIKE '%MVT
              MIGRATION CTX%' AND "T_ELEMENTS"."LIBELLE" IS NOT NULL AND (NVL("T_ELEMENTS"."MONTANT_DOS",0)-"FTR_MATCH"."LETTRREELDETTE"("T_ELEMENTS"."REFELEM","T_
              ELEMENTS"."TYPEELEM","T_ELEMENTS"."ABREV")>0 OR "FTR_MATCH"."DATEDERNLETTR"("T_ELEMENTS"."REFELEM","T_ELEMENTS"."TYPEELEM","T_ELEMENTS"."ABREV","T_EL
              EMENTS"."REFDOSS",'f')>TO_NUMBER(TO_CHAR(ADD_MONTHS(SYSDATE@!,(-NVL(:B4,1))),'j')))))
 136 - access("DE_NUM"="T_ELEMENTS"."REFELEM" AND "T_ELEMENTS"."TYPEELEM"='rg')
       filter( IS NULL)
 139 - access("G2"."REFELEM"=:B1)
 140 - filter("V2"."FG_PARENT_INVOICE"='O')
 141 - access("G2"."TYPE"="V2"."TYPE")
 142 - filter("T"."RN"=1)
 144 - filter("T_ELEMENTS"."REFDOSS"=:B3)
 149 - access("CMPT"."REFDOSS"=:B3)
 150 - access("CL"."REFDOSS"=:B3 AND "CL"."REFTYPE"=DECODE("CMPT"."CATEGDOSS",'COMPTE IMP','TC','CL'))
 151 - access("ICL"."REFINDIVIDU"="CL"."REFINDIVIDU")
*/
/********************************OLD Metrics***************************************/

/********************************New SQL*******************************************/
-- SQL1

SELECT g_main.*,
       ( SELECT COUNT(1)
           FROM g_elemfi E, 
                g_elemfi_aggr A, 
                g_piece B, 
                g_outpmt_exec O
          WHERE A.reffacture = E.Refpiece2
            AND B.refpiece = A.Refaggr
            AND O.refer = B.gpiressort
            AND O.dtexecution_dt IS NOT NULL
            AND E.refelem = g_main.refElem ) funded,
       ( SELECT COUNT(*)
           FROM nam_ecr_compta_bak AGGR
          WHERE AGGR.extref19 = g_main.extInvNumber
            AND AGGR.codeoper = 'MATCH_PMT'
            AND AGGR.status_reconcil = 'REJECTED' ) AS rejected
   FROM ( SELECT /*+ first_rows(2001)*/
                 foo.*, 
                 ROWNUM rnum
            FROM ( SELECT typeelem typeElem,
                          SUM(NVL(reconciled_solde, 0)) OVER() balanceTot,
                          clientName clientName,
                          dtdebut_dt dueDate,
                          NVL(montant_dos, 0) - NVL(lettrage, 0) -
                          NVL(prelettrage, 0) * NVL(:B1, 0) balanceEx,
                          refext extInvNumber,
                          libelle type,
                          refelemfi refElemFi,
                          prelettrage preMatching,
                          lettrage matching,
                          SUM(NVL(montant_dos, 0) - NVL(lettrage, 0) -
                              NVL(prelettrage, 0) * NVL(:B1, 0)) OVER() balanceExTot,
                          refdoss caseRef,
                          reconciled_solde balance,
                          flag_ctx flagCtx,
                          calcDueDate calcDueDate,
                          refelem refElem,
                          montant_dos invoiceAmt,
                          refpiece2 refDoc2,
                          imx.ftranslate_str(libelle, :B2, typeelem) displayType,
                          clRefInd clRefInd,
                          poExtRef poExtRef,
                          ge_elemfi_type geElemType,
                          abrev abbrev,
                          date_facture invDate,
                          imx_un_id uniqueId
                     FROM ( WITH T AS ( SELECT /*+ inline push_pred */
                                               ICL.refindividu clRefInd,
                                               ICL.nom clientName,
                                               CMPT.refdoss,
                                               row_number() OVER( PARTITION BY CMPT.refdoss ORDER BY CMPT.refdoss ) rn
                                          FROM t_intervenants CL,
                                               g_individu     ICL,
                                               g_dossier      CMPT
                                         WHERE 1 = 1
                                           AND CL.refdoss = CMPT.refdoss
                                           AND CL.reftype =
                                               DECODE( CMPT.categdoss, 'COMPTE IMP', 'TC', 'CL' )
                                           AND ICL.refindividu = CL.refindividu )
                         SELECT /*+ leading(T_ELEMENTS) */
                                GE.REFPIECE2 REFPIECE2,
                                T_ELEMENTS.imx_un_id imx_un_id,
                                T_ELEMENTS.REFDOSS REFDOSS,
                                T_ELEMENTS.REFELEM REFELEM,
                                T_ELEMENTS.REFELEMFI REFELEMFI,
                                T_ELEMENTS.TYPEELEM TYPEELEM,
                                GE.REFEXT REFEXT,
                                GE.DTDEBUT_DT DTDEBUT_DT,
                                GE.DT_EMIS_DT DATE_FACTURE,
                                T_ELEMENTS.LIBELLE LIBELLE,
                                T_ELEMENTS.ABREV ABREV,
                                T_ELEMENTS.DTASSOC_DT DTASSOC_DT,
                                GE.MONTANT_DOS MONTANT_DOS,
                                ( SELECT /*+ push_pred */
                                         SUM(montant_dos)
                                    FROM g_prelettrage
                                   WHERE typelem = T_ELEMENTS.typeelem
                                     AND refelem = T_ELEMENTS.refelem ) PRELETTRAGE,
                                DECODE( GE.matched_amt, NULL, Ftr_Match.PartieLettreDette( T_ELEMENTS.refelem, T_ELEMENTS.typeelem, T_ELEMENTS.abrev ), GE.matched_amt ) Lettrage,
                                NVL( GE.montant_dos, 0) - NVL( Ftr_Match.LettrReelDette( T_ELEMENTS.refelem, T_ELEMENTS.typeelem, '' ), 0 ) RECONCILED_SOLDE,
                                ge.type ge_elemfi_type,
                                GE.flag_ctx FLAG_CTX,
                                T.clRefInd,
                                T.clientName,
                                ( SELECT LISTAGG(gp.refext, ',') WITHIN GROUP( ORDER BY 1 )
                                    FROM g_piece gp,
                                         g_elemfi ge,
                                         g_venelem v, 
                                         g_elemfi poi
                                   WHERE gp.refpiece = ge.refpiece3
                                     AND ge.refelem = v.refelem
                                     AND poi.type = 'PO INVOICED'
                                     AND poi.ref_creance = ge.refelem
                                     AND poi.refelem = v.refencaiss
                                     AND poi.refdoss = ge.refdoss
                                     AND V.typencaiss = 'fi'
                                     AND V.typelem = 'fi' ) poExtRef,
                                GP_FACT.commentaire comm,
                                GP_FACT.dt13_dt calcDueDate
                           FROM T_ELEMENTS,
                                G_ELEMFI   GE,
                                g_dossier  GD,
                                T,
                                g_piece    GP_FACT
                          WHERE ge.refelem = t_elements.refelem
                            AND t_elements.refdoss = gd.refdoss
                            AND GE.MONTANT_DOS >= 0
                            AND NVL(GE.libelle, 'X') <> 'TOLERANCE AMOUNT'
                            AND t_elements.typeelem = 'fi'
                            AND (gd.categdoss LIKE 'COMPTE%')
                            AND t_elements.refdoss = T.refdoss(+)
                            AND 1 = T.rn(+)
                            AND ge.refelem = GP_FACT.gpiheure(+)
                            AND 'FACTURE' = GP_FACT.typpiece(+)
                            AND t_elements.refdoss = GP_FACT.refdoss(+)
                            AND NOT EXISTS ( SELECT 1
                                               FROM g_elemfi g2, 
                                                    v_elemfi v2
                                              WHERE g2.refelem = t_elements.refelem
                                                AND g2.type = v2.type
                                                AND v2.fg_parent_invoice = 'O' )
                            AND NOT EXISTS ( SELECT 1
                                               FROM g_piece po
                                              WHERE GE.refpiece3 IS NOT NULL
                                                AND GE.refpiece3 = po.refpiece
                                                AND po.typpiece = 'BON DE COMMANDE' )
                            AND T_ELEMENTS.refdoss = :B3
                            AND (  ( NVL(T_ELEMENTS.montant_dos, 0) - FTR_MATCH.LettrReelDette( T_ELEMENTS.refelem,
                                                                                                T_ELEMENTS.typeelem,
                                                                                                '' ) ) > 0 
                                OR FTR_MATCH.DateDernLettr( T_ELEMENTS.refelem,
                                                            T_ELEMENTS.typeelem,
                                                            T_ELEMENTS.abrev,
                                                            T_ELEMENTS.refdoss,
                                                            'f' ) > TO_CHAR( ADD_MONTHS( SYSDATE, -NVL( :B4, 1 ) ), 'j' ) )
                            AND T_ELEMENTS.libelle NOT LIKE '%MVT MIGRATION CTX%'
                            AND NVL(T_ELEMENTS.Libelle, 'X') NOT LIKE 'REMBOURSEMENT NC%'
                            AND ge.type <> 'SALES ORDER'
                         UNION
                         SELECT /*+ leading(T_ELEMENTS) */
                                NULL REFPIECE2,
                                T_ELEMENTS.imx_un_id imx_un_id,
                                T_ELEMENTS.REFDOSS REFDOSS,
                                T_ELEMENTS.REFELEM REFELEM,
                                T_ELEMENTS.REFELEMFI REFELEMFI,
                                T_ELEMENTS.TYPEELEM TYPEELEM,
                                GE.REFEXT REFEXT,
                                GE.dtreception_dt DTDEBUT_DT,
                                GE.dtjour_dt DATE_FACTURE,
                                DECODE(t_elements.typeelem,
                                       'tp',
                                       NVL(GE.LIBELLE, T_ELEMENTS.LIBELLE),
                                       T_ELEMENTS.LIBELLE) LIBELLE,
                                T_ELEMENTS.ABREV ABREV,
                                T_ELEMENTS.DTASSOC_DT DTASSOC_DT,
                                GE.MONTANT_DOS MONTANT_DOS,
                                NULL PRELETTRAGE,
                                Ftr_Match.PartieLettreDette(T_ELEMENTS.refelem,
                                                            T_ELEMENTS.typeelem,
                                                            T_ELEMENTS.abrev) Lettrage,
                                NVL(GE.montant_dos, 0) -
                                NVL(Ftr_Match.LettrReelDette(T_ELEMENTS.refelem,
                                                             T_ELEMENTS.typeelem,
                                                             ''),
                                    0) RECONCILED_SOLDE,
                                T_ELEMENTS.typeelem ge_elemfi_type,
                                NULL FLAG_CTX,
                                T.clRefInd,
                                T.clientName,
                                NULL poExtRef,
                                NULL comm,
                                NULL calcDueDate
                           FROM T_ELEMENTS, 
                                G_ENCAISSEMENT GE, 
                                g_dossier GD, 
                                T
                          WHERE t_elements.typeelem IN ('tp', 've')
                            AND t_elements.refdoss = gd.refdoss
                            AND ge.refencaiss = t_elements.refelem
                            AND t_elements.refdoss = T.refdoss(+)
                            AND 1 = T.rn(+)
                            AND ge.typencaiss = DECODE( t_elements.typeelem, 'tp', 'e_sadecaiss', 'e_savirmt' )
                            AND ( gd.categdoss LIKE 'COMPTE%' )
                            AND NOT EXISTS ( SELECT 1
                                               FROM g_elemfi g2, 
                                                    v_elemfi v2
                                              WHERE g2.refelem = t_elements.refelem
                                                AND g2.type = v2.type
                                                AND v2.fg_parent_invoice = 'O' )
                            AND T_ELEMENTS.refdoss = :B3
                            AND (  ( NVL(T_ELEMENTS.montant_dos, 0 ) - FTR_MATCH.LettrReelDette( T_ELEMENTS.refelem, T_ELEMENTS.typeelem, '' ) ) > 0
                                OR FTR_MATCH.DateDernLettr( T_ELEMENTS.refelem, T_ELEMENTS.typeelem, T_ELEMENTS.abrev, T_ELEMENTS.refdoss, 'f' ) >  TO_CHAR(ADD_MONTHS(SYSDATE, -NVL(:B4, 1)), 'j'))
                            AND T_ELEMENTS.libelle not like '%MVT MIGRATION CTX%'
                            AND NVL(T_ELEMENTS.Libelle, 'X') NOT LIKE 'REMBOURSEMENT NC%'
                         UNION
                         SELECT /*+ leading(T_ELEMENTS) */
                                NULL REFPIECE2,
                                T_ELEMENTS.imx_un_id imx_un_id,
                                T_ELEMENTS.REFDOSS REFDOSS,
                                T_ELEMENTS.REFELEM REFELEM,
                                T_ELEMENTS.REFELEMFI REFELEMFI,
                                T_ELEMENTS.TYPEELEM TYPEELEM,
                                GE.REFEXT REFEXT,
                                GE.dtreception_dt DTDEBUT_DT,
                                GE.dtjour_dt DATE_FACTURE,
                                GE.LIBELLE LIBELLE,
                                T_ELEMENTS.ABREV ABREV,
                                T_ELEMENTS.DTASSOC_DT DTASSOC_DT,
                                GE.MONTANT_DOS MONTANT_DOS,
                                NULL PRELETTRAGE,
                                Ftr_Match.PartieLettreDette(T_ELEMENTS.refelem,
                                                            T_ELEMENTS.typeelem,
                                                            T_ELEMENTS.abrev) Lettrage,
                                NVL(GE.montant_dos, 0) -
                                NVL(Ftr_Match.LettrReelDette(T_ELEMENTS.refelem,
                                                             T_ELEMENTS.typeelem,
                                                             ''),
                                    0) RECONCILED_SOLDE,
                                t_elements.typeelem ge_elemfi_type,
                                NULL FLAG_CTX,
                                T.clRefInd,
                                T.clientName,
                                NULL poExtRef,
                                NULL comm,
                                NULL calcDueDate
                           FROM T_ELEMENTS, 
                                G_ENCAISSEMENT GE, 
                                g_dossier GD,
                                T
                          WHERE t_elements.typeelem = 'rd'
                            AND t_elements.refdoss = gd.refdoss
                            AND ge.refencaiss = t_elements.refelem
                            AND t_elements.refdoss = T.refdoss(+)
                            AND 1 = T.rn(+)
                            AND ge.typencaiss = 'rembdir'
                            AND (gd.categdoss LIKE 'COMPTE%')
                            AND NOT EXISTS ( SELECT 1
                                               FROM g_elemfi g2, 
                                                    v_elemfi v2
                                              WHERE g2.refelem = t_elements.refelem
                                                AND g2.type = v2.type
                                                AND v2.fg_parent_invoice = 'O' )
                            AND T_ELEMENTS.refdoss = :B4
                            AND (  ( NVL(T_ELEMENTS.montant_dos, 0) - FTR_MATCH.LettrReelDette( T_ELEMENTS.refelem, T_ELEMENTS.typeelem, '' ) ) > 0 
                                OR FTR_MATCH.DateDernLettr( T_ELEMENTS.refelem, T_ELEMENTS.typeelem, T_ELEMENTS.abrev, T_ELEMENTS.refdoss, 'f') > TO_CHAR(ADD_MONTHS(SYSDATE, -NVL(:B4, 1)), 'j'))
                            AND T_ELEMENTS.libelle not like '%MVT MIGRATION CTX%'
                            AND NVL(T_ELEMENTS.Libelle, 'X') NOT LIKE 'REMBOURSEMENT NC%'
                         UNION
                         SELECT /*+ leading(T_ELEMENTS) */
                                NULL REFPIECE2,
                                T_ELEMENTS.imx_un_id imx_un_id,
                                T_ELEMENTS.REFDOSS REFDOSS,
                                T_ELEMENTS.REFELEM REFELEM,
                                T_ELEMENTS.REFELEMFI REFELEMFI,
                                T_ELEMENTS.TYPEELEM TYPEELEM,
                                NULL REFEXT,
                                T_ELEMENTS.dtassoc_dt DTDEBUT_DT,
                                T_ELEMENTS.dtsaisie_dt DATE_FACTURE,
                                T_ELEMENTS.LIBELLE LIBELLE,
                                T_ELEMENTS.ABREV ABREV,
                                T_ELEMENTS.DTASSOC_DT DTASSOC_DT,
                                T_ELEMENTS.MONTANT_DOS MONTANT_DOS,
                                NULL PRELETTRAGE,
                                Ftr_Match.PartieLettreDette(T_ELEMENTS.refelem,
                                                            T_ELEMENTS.typeelem,
                                                            T_ELEMENTS.abrev) Lettrage,
                                NVL(T_ELEMENTS.MONTANT_DOS, 0) -
                                NVL(Ftr_Match.LettrReelDette(T_ELEMENTS.refelem,
                                                             T_ELEMENTS.typeelem,
                                                             T_ELEMENTS.abrev),
                                    0) RECONCILED_SOLDE,
                                t_elements.typeelem ge_elemfi_type,
                                NULL FLAG_CTX,
                                T.clRefInd,
                                T.clientName,
                                NULL poExtRef,
                                NULL comm,
                                NULL calcDueDate
                           FROM T_ELEMENTS,
                                f_detenr   GE,
                                g_dossier  GD,
                                f_parenr   FPA,
                                T
                          WHERE t_elements.typeelem = 'rg'
                            AND t_elements.refdoss = gd.refdoss
                            AND (de_des = 'T' AND de_sen = 'R' OR
                                de_des = 'E' AND de_sen = 'V')
                            AND de_nte IS NOT NULL
                            AND de_num = t_elements.refelem
                            AND ge.de_nom = fpa.pe_nom
                            AND FPA.pe_cha IS NOT NULL
                            AND SUBSTR(FPA.pe_cha, 2, 1) = 'D'
                            AND FPA.pe_nom NOT IN ('PNCDB')
                            AND gd.categdoss LIKE 'COMPTE%'
                            AND t_elements.refdoss = T.refdoss(+)
                            AND 1 = T.rn(+)
                            AND NOT EXISTS ( SELECT 1
                                               FROM g_elemfi g2, 
                                                    v_elemfi v2
                                              WHERE g2.refelem = t_elements.refelem
                                                AND g2.type = v2.type
                                                AND v2.fg_parent_invoice = 'O' )
                            AND T_ELEMENTS.refdoss = :B3
                            AND (  ( NVL(T_ELEMENTS.montant_dos, 0) - FTR_MATCH.LettrReelDette(T_ELEMENTS.refelem, T_ELEMENTS.typeelem, T_ELEMENTS.abrev ) ) > 0 
                                OR FTR_MATCH.DateDernLettr( T_ELEMENTS.refelem, T_ELEMENTS.typeelem, T_ELEMENTS.abrev, T_ELEMENTS.refdoss, 'f') > TO_CHAR(ADD_MONTHS(SYSDATE, -NVL(:B4, 1)), 'j'))
                            AND T_ELEMENTS.libelle not like '%MVT MIGRATION CTX%'
                            AND NVL(T_ELEMENTS.Libelle, 'X') NOT LIKE 'REMBOURSEMENT NC%') T_ELEMENTS
                          WHERE 1 = 1
                          ORDER BY invDate, uniqueId
                ) foo
         WHERE ROWNUM <= :B5) g_main
 WHERE 1 = 1
   AND rnum >= :B1;



-- SQL2

SELECT g_main.*,
       (SELECT COUNT(1)
          FROM g_elemfi E, g_elemfi_aggr A, g_piece B, g_outpmt_exec O
         WHERE A.reffacture = E.Refpiece2
           AND B.refpiece = A.Refaggr
           AND O.refer = B.gpiressort
           AND O.dtexecution_dt IS NOT NULL
           AND E.refelem = g_main.refElem) funded,
       (SELECT COUNT(*)
          FROM nam_ecr_compta_bak AGGR
         WHERE AGGR.extref19 = g_main.extInvNumber
           AND AGGR.codeoper = 'MATCH_PMT'
           AND AGGR.status_reconcil = 'REJECTED') AS rejected
  FROM (SELECT /*+ first_rows(10001)*/
         foo.*, ROWNUM rnum
          FROM (SELECT typeelem typeElem,
                       SUM(NVL(reconciled_solde, 0)) OVER() balanceTot,
                       clientName clientName,
                       dtdebut_dt dueDate,
                       NVL(montant_dos, 0) - NVL(lettrage, 0) -
                       NVL(prelettrage, 0) * NVL(:B1, 0) balanceEx,
                       refext extInvNumber,
                       libelle type,
                       refelemfi refElemFi,
                       prelettrage preMatching,
                       lettrage matching,
                       SUM(NVL(montant_dos, 0) - NVL(lettrage, 0) -
                           NVL(prelettrage, 0) * NVL(:B1, 0)) OVER() balanceExTot,
                       refdoss caseRef,
                       reconciled_solde balance,
                       flag_ctx flagCtx,
                       calcDueDate calcDueDate,
                       refelem refElem,
                       montant_dos invoiceAmt,
                       refpiece2 refDoc2,
                       imx.ftranslate_str(libelle, :B2, typeelem) displayType,
                       clRefInd clRefInd,
                       poExtRef poExtRef,
                       ge_elemfi_type geElemType,
                       abrev abbrev,
                       date_facture invDate,
                       imx_un_id uniqueId
                  FROM (WITH T AS (SELECT /*+ inline push_pred */
                                    ICL.refindividu clRefInd,
                                    ICL.nom clientName,
                                    CMPT.refdoss,
                                    row_number() OVER(PARTITION BY CMPT.refdoss ORDER BY CMPT.refdoss) rn
                                     FROM t_intervenants CL,
                                          g_individu     ICL,
                                          g_dossier      CMPT
                                    WHERE 1 = 1
                                      AND CL.refdoss = CMPT.refdoss
                                      AND CL.reftype =
                                          DECODE(CMPT.categdoss,
                                                 'COMPTE IMP',
                                                 'TC',
                                                 'CL')
                                      AND ICL.refindividu = CL.refindividu)
                         SELECT /*+ leading(T_ELEMENTS) */
                                GE.REFPIECE2 REFPIECE2,
                                T_ELEMENTS.imx_un_id imx_un_id,
                                T_ELEMENTS.REFDOSS REFDOSS,
                                T_ELEMENTS.REFELEM REFELEM,
                                T_ELEMENTS.REFELEMFI REFELEMFI,
                                T_ELEMENTS.TYPEELEM TYPEELEM,
                                GE.REFEXT REFEXT,
                                GE.DTDEBUT_DT DTDEBUT_DT,
                                GE.DT_EMIS_DT DATE_FACTURE,
                                T_ELEMENTS.LIBELLE LIBELLE,
                                T_ELEMENTS.ABREV ABREV,
                                T_ELEMENTS.DTASSOC_DT DTASSOC_DT,
                                GE.MONTANT_DOS MONTANT_DOS,
                                (SELECT /*+ push_pred */
                                  SUM(montant_dos)
                                   FROM g_prelettrage
                                  WHERE typelem = T_ELEMENTS.typeelem
                                    AND refelem = T_ELEMENTS.refelem) PRELETTRAGE,
                                DECODE(GE.matched_amt,
                                       NULL,
                                       Ftr_Match.PartieLettreDette(T_ELEMENTS.refelem,
                                                                   T_ELEMENTS.typeelem,
                                                                   T_ELEMENTS.abrev),
                                       GE.matched_amt) Lettrage,
                                NVL(GE.montant_dos, 0) -
                                NVL(Ftr_Match.LettrReelDette(T_ELEMENTS.refelem,
                                                             T_ELEMENTS.typeelem,
                                                             ''),
                                    0) RECONCILED_SOLDE,
                                ge.type ge_elemfi_type,
                                GE.flag_ctx FLAG_CTX,
                                T.clRefInd,
                                T.clientName,
                                (SELECT LISTAGG(gp.refext, ',') WITHIN GROUP(ORDER BY 1)
                                   FROM g_piece gp,
                                        g_elemfi ge,
                                        g_venelem v, 
                                        g_elemfi poi
                                  WHERE gp.refpiece = ge.refpiece3
                                    AND  ge.refelem = v.refelem
                                    AND poi.type = 'PO INVOICED'
                                    AND poi.ref_creance = ge.refelem
                                    AND poi.refelem = v.refencaiss
                                    AND poi.refdoss = ge.refdoss
                                    AND V.typencaiss = 'fi'
                                    AND V.typelem = 'fi' ) poExtRef,
                                GP_FACT.commentaire comm,
                                GP_FACT.dt13_dt calcDueDate
                           FROM T_ELEMENTS,
                                G_ELEMFI   GE,
                                g_dossier  GD,
                                T,
                                g_piece    GP_FACT
                          WHERE ge.refelem = t_elements.refelem
                            AND t_elements.refdoss = gd.refdoss
                            AND GE.MONTANT_DOS >= 0
                            AND NVL(GE.libelle, 'X') <> 'TOLERANCE AMOUNT'
                            AND t_elements.typeelem = 'fi'
                            AND (gd.categdoss LIKE 'COMPTE%')
                            AND t_elements.refdoss = T.refdoss(+)
                            AND 1 = T.rn(+)
                            AND ge.refelem = GP_FACT.gpiheure(+)
                            AND 'FACTURE' = GP_FACT.typpiece(+)
                            AND t_elements.refdoss = GP_FACT.refdoss(+)
                            AND NOT EXISTS
                          (SELECT 1
                                   FROM g_elemfi g2, v_elemfi v2
                                  WHERE g2.refelem = t_elements.refelem
                                    AND g2.type = v2.type
                                    AND v2.fg_parent_invoice = 'O')
                            AND NOT EXISTS
                          (SELECT 1
                                   FROM g_piece po
                                  WHERE GE.refpiece3 IS NOT NULL
                                    AND GE.refpiece3 = po.refpiece
                                    AND po.typpiece = 'BON DE COMMANDE')
                            AND T_ELEMENTS.refdoss = :B3
                            AND ((NVL(T_ELEMENTS.montant_dos, 0) -
                                FTR_MATCH.LettrReelDette(T_ELEMENTS.refelem,
                                                           T_ELEMENTS.typeelem,
                                                           '')) > 0 OR
                                FTR_MATCH.DateDernLettr(T_ELEMENTS.refelem,
                                                         T_ELEMENTS.typeelem,
                                                         T_ELEMENTS.abrev,
                                                         T_ELEMENTS.refdoss,
                                                         'f') >
                                TO_CHAR(ADD_MONTHS(SYSDATE, -NVL(:B4, 1)), 'j'))
                            AND T_ELEMENTS.libelle NOT LIKE
                                '%MVT MIGRATION CTX%'
                            AND NVL(T_ELEMENTS.Libelle, 'X') NOT LIKE
                                'REMBOURSEMENT NC%'
                            AND ge.type <> 'SALES ORDER'
                         UNION
                         SELECT /*+ leading(T_ELEMENTS) */
                                NULL REFPIECE2,
                                T_ELEMENTS.imx_un_id imx_un_id,
                                T_ELEMENTS.REFDOSS REFDOSS,
                                T_ELEMENTS.REFELEM REFELEM,
                                T_ELEMENTS.REFELEMFI REFELEMFI,
                                T_ELEMENTS.TYPEELEM TYPEELEM,
                                GE.REFEXT REFEXT,
                                GE.dtreception_dt DTDEBUT_DT,
                                GE.dtjour_dt DATE_FACTURE,
                                DECODE(t_elements.typeelem,
                                       'tp',
                                       NVL(GE.LIBELLE, T_ELEMENTS.LIBELLE),
                                       T_ELEMENTS.LIBELLE) LIBELLE,
                                T_ELEMENTS.ABREV ABREV,
                                T_ELEMENTS.DTASSOC_DT DTASSOC_DT,
                                GE.MONTANT_DOS MONTANT_DOS,
                                NULL PRELETTRAGE,
                                Ftr_Match.PartieLettreDette(T_ELEMENTS.refelem,
                                                            T_ELEMENTS.typeelem,
                                                            T_ELEMENTS.abrev) Lettrage,
                                NVL(GE.montant_dos, 0) -
                                NVL(Ftr_Match.LettrReelDette(T_ELEMENTS.refelem,
                                                             T_ELEMENTS.typeelem,
                                                             ''),
                                    0) RECONCILED_SOLDE,
                                T_ELEMENTS.typeelem ge_elemfi_type,
                                NULL FLAG_CTX,
                                T.clRefInd,
                                T.clientName,
                                NULL poExtRef,
                                NULL comm,
                                NULL calcDueDate
                           FROM T_ELEMENTS, G_ENCAISSEMENT GE, g_dossier GD, T
                          WHERE t_elements.typeelem IN ('tp', 've')
                            AND t_elements.refdoss = gd.refdoss
                            AND ge.refencaiss = t_elements.refelem
                            AND t_elements.refdoss = T.refdoss(+)
                            AND 1 = T.rn(+)
                            AND ge.typencaiss =
                                DECODE(t_elements.typeelem,
                                       'tp',
                                       'e_sadecaiss',
                                       'e_savirmt')
                            AND (gd.categdoss LIKE 'COMPTE%')
                            AND NOT EXISTS
                          (SELECT 1
                                   FROM g_elemfi g2, v_elemfi v2
                                  WHERE g2.refelem = t_elements.refelem
                                    AND g2.type = v2.type
                                    AND v2.fg_parent_invoice = 'O')
                            AND T_ELEMENTS.refdoss = :B3
                            AND ((NVL(T_ELEMENTS.montant_dos, 0) -
                                FTR_MATCH.LettrReelDette(T_ELEMENTS.refelem,
                                                           T_ELEMENTS.typeelem,
                                                           '')) > 0 OR
                                FTR_MATCH.DateDernLettr(T_ELEMENTS.refelem,
                                                         T_ELEMENTS.typeelem,
                                                         T_ELEMENTS.abrev,
                                                         T_ELEMENTS.refdoss,
                                                         'f') >
                                TO_CHAR(ADD_MONTHS(SYSDATE, -NVL(:B4, 1)), 'j'))
                            AND T_ELEMENTS.libelle not like
                                '%MVT MIGRATION CTX%'
                            AND NVL(T_ELEMENTS.Libelle, 'X') NOT LIKE
                                'REMBOURSEMENT NC%'
                         UNION
                         SELECT /*+ leading(T_ELEMENTS) */
                                NULL REFPIECE2,
                                T_ELEMENTS.imx_un_id imx_un_id,
                                T_ELEMENTS.REFDOSS REFDOSS,
                                T_ELEMENTS.REFELEM REFELEM,
                                T_ELEMENTS.REFELEMFI REFELEMFI,
                                T_ELEMENTS.TYPEELEM TYPEELEM,
                                GE.REFEXT REFEXT,
                                GE.dtreception_dt DTDEBUT_DT,
                                GE.dtjour_dt DATE_FACTURE,
                                GE.LIBELLE LIBELLE,
                                T_ELEMENTS.ABREV ABREV,
                                T_ELEMENTS.DTASSOC_DT DTASSOC_DT,
                                GE.MONTANT_DOS MONTANT_DOS,
                                NULL PRELETTRAGE,
                                Ftr_Match.PartieLettreDette(T_ELEMENTS.refelem,
                                                            T_ELEMENTS.typeelem,
                                                            T_ELEMENTS.abrev) Lettrage,
                                NVL(GE.montant_dos, 0) -
                                NVL(Ftr_Match.LettrReelDette(T_ELEMENTS.refelem,
                                                             T_ELEMENTS.typeelem,
                                                             ''),
                                    0) RECONCILED_SOLDE,
                                t_elements.typeelem ge_elemfi_type,
                                NULL FLAG_CTX,
                                T.clRefInd,
                                T.clientName,
                                NULL poExtRef,
                                NULL comm,
                                NULL calcDueDate
                           FROM T_ELEMENTS, G_ENCAISSEMENT GE, g_dossier GD, T
                          WHERE t_elements.typeelem = 'rd'
                            AND t_elements.refdoss = gd.refdoss
                            AND ge.refencaiss = t_elements.refelem
                            AND t_elements.refdoss = T.refdoss(+)
                            AND 1 = T.rn(+)
                            AND ge.typencaiss = 'rembdir'
                            AND (gd.categdoss LIKE 'COMPTE%')
                            AND NOT EXISTS
                          (SELECT 1
                                   FROM g_elemfi g2, v_elemfi v2
                                  WHERE g2.refelem = t_elements.refelem
                                    AND g2.type = v2.type
                                    AND v2.fg_parent_invoice = 'O')
                            AND T_ELEMENTS.refdoss = :B3
                            AND ((NVL(T_ELEMENTS.montant_dos, 0) -
                                FTR_MATCH.LettrReelDette(T_ELEMENTS.refelem,
                                                           T_ELEMENTS.typeelem,
                                                           '')) > 0 OR
                                FTR_MATCH.DateDernLettr(T_ELEMENTS.refelem,
                                                         T_ELEMENTS.typeelem,
                                                         T_ELEMENTS.abrev,
                                                         T_ELEMENTS.refdoss,
                                                         'f') >
                                TO_CHAR(ADD_MONTHS(SYSDATE, -NVL(:B4, 1)), 'j'))
                            AND T_ELEMENTS.libelle not like
                                '%MVT MIGRATION CTX%'
                            AND NVL(T_ELEMENTS.Libelle, 'X') NOT LIKE
                                'REMBOURSEMENT NC%'
                         UNION
                         SELECT /*+ leading(T_ELEMENTS) */
                                NULL REFPIECE2,
                                T_ELEMENTS.imx_un_id imx_un_id,
                                T_ELEMENTS.REFDOSS REFDOSS,
                                T_ELEMENTS.REFELEM REFELEM,
                                T_ELEMENTS.REFELEMFI REFELEMFI,
                                T_ELEMENTS.TYPEELEM TYPEELEM,
                                NULL REFEXT,
                                T_ELEMENTS.dtassoc_dt DTDEBUT_DT,
                                T_ELEMENTS.dtsaisie_dt DATE_FACTURE,
                                T_ELEMENTS.LIBELLE LIBELLE,
                                T_ELEMENTS.ABREV ABREV,
                                T_ELEMENTS.DTASSOC_DT DTASSOC_DT,
                                T_ELEMENTS.MONTANT_DOS MONTANT_DOS,
                                NULL PRELETTRAGE,
                                Ftr_Match.PartieLettreDette(T_ELEMENTS.refelem,
                                                            T_ELEMENTS.typeelem,
                                                            T_ELEMENTS.abrev) Lettrage,
                                NVL(T_ELEMENTS.MONTANT_DOS, 0) -
                                NVL(Ftr_Match.LettrReelDette(T_ELEMENTS.refelem,
                                                             T_ELEMENTS.typeelem,
                                                             T_ELEMENTS.abrev),
                                    0) RECONCILED_SOLDE,
                                t_elements.typeelem ge_elemfi_type,
                                NULL FLAG_CTX,
                                T.clRefInd,
                                T.clientName,
                                NULL poExtRef,
                                NULL comm,
                                NULL calcDueDate
                           FROM T_ELEMENTS,
                                f_detenr   GE,
                                g_dossier  GD,
                                f_parenr   FPA,
                                T
                          WHERE t_elements.typeelem = 'rg'
                            AND t_elements.refdoss = gd.refdoss
                            AND (de_des = 'T' AND de_sen = 'R' OR
                                de_des = 'E' AND de_sen = 'V')
                            AND de_nte IS NOT NULL
                            AND de_num = t_elements.refelem
                            AND ge.de_nom = fpa.pe_nom
                            AND FPA.pe_cha IS NOT NULL
                            AND SUBSTR(FPA.pe_cha, 2, 1) = 'D'
                            AND FPA.pe_nom NOT IN ('PNCDB')
                            AND gd.categdoss LIKE 'COMPTE%'
                            AND t_elements.refdoss = T.refdoss(+)
                            AND 1 = T.rn(+)
                            AND NOT EXISTS
                          (SELECT 1
                                   FROM g_elemfi g2, v_elemfi v2
                                  WHERE g2.refelem = t_elements.refelem
                                    AND g2.type = v2.type
                                    AND v2.fg_parent_invoice = 'O')
                            AND T_ELEMENTS.refdoss = :B3
                            AND ((NVL(T_ELEMENTS.montant_dos, 0) -
                                FTR_MATCH.LettrReelDette(T_ELEMENTS.refelem,
                                                           T_ELEMENTS.typeelem,
                                                           T_ELEMENTS.abrev)) > 0 OR
                                FTR_MATCH.DateDernLettr(T_ELEMENTS.refelem,
                                                         T_ELEMENTS.typeelem,
                                                         T_ELEMENTS.abrev,
                                                         T_ELEMENTS.refdoss,
                                                         'f') >
                                TO_CHAR(ADD_MONTHS(SYSDATE, -NVL(:B4, 1)), 'j'))
                            AND T_ELEMENTS.libelle not like
                                '%MVT MIGRATION CTX%'
                            AND NVL(T_ELEMENTS.Libelle, 'X') NOT LIKE
                                'REMBOURSEMENT NC%') T_ELEMENTS
                          WHERE 1 = 1
                            AND t_elements.imx_un_id IN ( 9065866,9065867,9065864,9065865,9065870,9065871,9065868,9065869,9065858,9065859,9065856,9065857,9065862,9065863,9065860,9065861,9065882,9065883,9065880,9065881,9065886,9065887,9065884,9065885,9065874,9065875,9065872,9065873,9065878,9065879,9065876,9065877,9065898,9065899,9065896,9065897,9065902,9065903,9065900,9065901,9065890,9065891,9065888,9065889,9065894,9065895,9065892,9065893,9065914,9065915,9065912,9065913,9065918,9065919,9065916,9065917,9065906,9065907,9065904,9065905,9065910,9065911,9065908,9065909,9065930,9065931,9065928,9065929,9065934,9065935,9065932,9065933,9065922,9065923,9065920,9065921,9065926,9065927,9065924,9065925,9065946,9065947,9065944,9065945,9065950,9065951,9065948,9065949,9065938,9065939,9065936,9065937,9065942,9065943,9065940,9065941,9065962,9065963,9065960,9065961,9065966,9065967,9065964,9065965,9065954,9065955,9065952,9065953,9065958,9065959,9065956,9065957,9065978,9065979,9065976,9065977,9065982,9065983,9065980,9065981,9065970,9065971,9065968,9065969,9065974,9065975,9065972,9065973,9065834,9065835,9065832,9065833,9065838,9065839,9065836,9065837,9065830,9065831,9065850,9065851,9065848,9065849,9065854,9065855,9065852,9065853,9065842,9065843,9065840,9065841,9065846,9065847,9065844,9065845,9066122,9066123,9066120,9066121,9066126,9066127,9066124,9066125,9066114,9066115,9066112,9066113,9066118,9066119,9066116,9066117,9066138,9066139,9066136,9066137,9066142,9066143,9066140,9066141,9066130,9066131,9066128,9066129,9066134,9066135,9066132,9066133,9066154,9066155,9066152,9066153,9066158,9066159,9066156,9066157,9066146,9066147,9066144,9066145,9066150,9066151,9066148,9066149,9066170,9066171,9066168,9066169,9066174,9066175,9066172,9066173,9066162,9066163,9066160,9066161,9066166,9066167,9066164,9066165,9066186,9066187,9066184,9066185 ) 
                          ORDER BY invDate, uniqueId
                ) foo
         WHERE ROWNUM <= :B5) g_main
 WHERE 1 = 1
   AND rnum >= :B1;


-- SQL3

SELECT g_main.*,
       (SELECT COUNT(1)
          FROM g_elemfi E, g_elemfi_aggr A, g_piece B, g_outpmt_exec O
         WHERE A.reffacture = E.Refpiece2
           AND B.refpiece = A.Refaggr
           AND O.refer = B.gpiressort
           AND O.dtexecution_dt IS NOT NULL
           AND E.refelem = g_main.refElem) funded,
       (SELECT COUNT(*)
          FROM nam_ecr_compta_bak AGGR
         WHERE AGGR.extref19 = g_main.extInvNumber
           AND AGGR.codeoper = 'MATCH_PMT'
           AND AGGR.status_reconcil = 'REJECTED') AS rejected
  FROM (SELECT /*+ first_rows(2001)*/
         foo.*, ROWNUM rnum
          FROM (SELECT typeelem typeElem,
                       SUM(NVL(reconciled_solde, 0)) OVER() balanceTot,
                       clientName clientName,
                       dtdebut_dt dueDate,
                       NVL(montant_dos, 0) - NVL(lettrage, 0) -
                       NVL(prelettrage, 0) * NVL(:B1, 0) balanceEx,
                       refext extInvNumber,
                       libelle type,
                       refelemfi refElemFi,
                       prelettrage preMatching,
                       lettrage matching,
                       SUM(NVL(montant_dos, 0) - NVL(lettrage, 0) -
                           NVL(prelettrage, 0) * NVL(:B1, 0)) OVER() balanceExTot,
                       refdoss caseRef,
                       reconciled_solde balance,
                       flag_ctx flagCtx,
                       calcDueDate calcDueDate,
                       refelem refElem,
                       montant_dos invoiceAmt,
                       refpiece2 refDoc2,
                       imx.ftranslate_str(libelle, :B2, typeelem) displayType,
                       clRefInd clRefInd,
                       poExtRef poExtRef,
                       ge_elemfi_type geElemType,
                       abrev abbrev,
                       date_facture invDate,
                       imx_un_id uniqueId
                  FROM (WITH T AS (SELECT /*+ inline push_pred */
                                    ICL.refindividu clRefInd,
                                    ICL.nom clientName,
                                    CMPT.refdoss,
                                    row_number() OVER(PARTITION BY CMPT.refdoss ORDER BY CMPT.refdoss) rn
                                     FROM t_intervenants CL,
                                          g_individu     ICL,
                                          g_dossier      CMPT
                                    WHERE 1 = 1
                                      AND CL.refdoss = CMPT.refdoss
                                      AND CL.reftype =
                                          DECODE(CMPT.categdoss,
                                                 'COMPTE IMP',
                                                 'TC',
                                                 'CL')
                                      AND ICL.refindividu = CL.refindividu)
                         SELECT /*+ leading(T_ELEMENTS) */
                                GE.REFPIECE2 REFPIECE2,
                                T_ELEMENTS.imx_un_id imx_un_id,
                                T_ELEMENTS.REFDOSS REFDOSS,
                                T_ELEMENTS.REFELEM REFELEM,
                                T_ELEMENTS.REFELEMFI REFELEMFI,
                                T_ELEMENTS.TYPEELEM TYPEELEM,
                                GE.REFEXT REFEXT,
                                GE.DTDEBUT_DT DTDEBUT_DT,
                                GE.DT_EMIS_DT DATE_FACTURE,
                                T_ELEMENTS.LIBELLE LIBELLE,
                                T_ELEMENTS.ABREV ABREV,
                                T_ELEMENTS.DTASSOC_DT DTASSOC_DT,
                                GE.MONTANT_DOS MONTANT_DOS,
                                (SELECT /*+ push_pred */
                                  SUM(montant_dos)
                                   FROM g_prelettrage
                                  WHERE typelem = T_ELEMENTS.typeelem
                                    AND refelem = T_ELEMENTS.refelem) PRELETTRAGE,
                                DECODE(GE.matched_amt,
                                       NULL,
                                       Ftr_Match.PartieLettreDette(T_ELEMENTS.refelem,
                                                                   T_ELEMENTS.typeelem,
                                                                   T_ELEMENTS.abrev),
                                       GE.matched_amt) Lettrage,
                                NVL(GE.montant_dos, 0) -
                                NVL(Ftr_Match.LettrReelDette(T_ELEMENTS.refelem,
                                                             T_ELEMENTS.typeelem,
                                                             ''),
                                    0) RECONCILED_SOLDE,
                                ge.type ge_elemfi_type,
                                GE.flag_ctx FLAG_CTX,
                                T.clRefInd,
                                T.clientName,
                                (SELECT LISTAGG(gp.refext, ',') WITHIN GROUP(ORDER BY 1)
                                   FROM g_piece gp,
                                        g_elemfi ge,
                                        g_venelem v, 
                                        g_elemfi poi
                                  WHERE gp.refpiece = ge.refpiece3
                                    AND ge.refelem = v.refelem
                                    AND poi.type = 'PO INVOICED'
                                    AND poi.ref_creance = ge.refelem
                                    AND poi.refelem = v.refencaiss
                                    AND poi.refdoss = ge.refdoss
                                    AND V.typencaiss = 'fi'
                                    AND V.typelem = 'fi' ) poExtRef,
                                GP_FACT.commentaire comm,
                                GP_FACT.dt13_dt calcDueDate
                           FROM T_ELEMENTS,
                                G_ELEMFI   GE,
                                g_dossier  GD,
                                T,
                                g_piece    GP_FACT
                          WHERE ge.refelem = t_elements.refelem
                            AND t_elements.refdoss = gd.refdoss
                            AND GE.MONTANT_DOS >= 0
                            AND NVL(GE.libelle, 'X') <> 'TOLERANCE AMOUNT'
                            AND t_elements.typeelem = 'fi'
                            AND (gd.categdoss LIKE 'COMPTE%')
                            AND t_elements.refdoss = T.refdoss(+)
                            AND 1 = T.rn(+)
                            AND ge.refelem = GP_FACT.gpiheure(+)
                            AND 'FACTURE' = GP_FACT.typpiece(+)
                            AND t_elements.refdoss = GP_FACT.refdoss(+)
                            AND NOT EXISTS
                          (SELECT 1
                                   FROM g_elemfi g2, v_elemfi v2
                                  WHERE g2.refelem = t_elements.refelem
                                    AND g2.type = v2.type
                                    AND v2.fg_parent_invoice = 'O')
                            AND NOT EXISTS
                          (SELECT 1
                                   FROM g_piece po
                                  WHERE GE.refpiece3 IS NOT NULL
                                    AND GE.refpiece3 = po.refpiece
                                    AND po.typpiece = 'BON DE COMMANDE')
                            AND T_ELEMENTS.refdoss = :B3
                            AND ((NVL(T_ELEMENTS.montant_dos, 0) -
                                FTR_MATCH.LettrReelDette(T_ELEMENTS.refelem,
                                                           T_ELEMENTS.typeelem,
                                                           '')) > 0 OR
                                FTR_MATCH.DateDernLettr(T_ELEMENTS.refelem,
                                                         T_ELEMENTS.typeelem,
                                                         T_ELEMENTS.abrev,
                                                         T_ELEMENTS.refdoss,
                                                         'f') >
                                TO_CHAR(ADD_MONTHS(SYSDATE, -NVL(:B4, 1)), 'j'))
                            AND T_ELEMENTS.libelle NOT LIKE
                                '%MVT MIGRATION CTX%'
                            AND NVL(T_ELEMENTS.Libelle, 'X') NOT LIKE
                                'REMBOURSEMENT NC%'
                            AND ge.type <> 'SALES ORDER'
                         UNION
                         SELECT /*+ leading(T_ELEMENTS) */
                                NULL REFPIECE2,
                                T_ELEMENTS.imx_un_id imx_un_id,
                                T_ELEMENTS.REFDOSS REFDOSS,
                                T_ELEMENTS.REFELEM REFELEM,
                                T_ELEMENTS.REFELEMFI REFELEMFI,
                                T_ELEMENTS.TYPEELEM TYPEELEM,
                                GE.REFEXT REFEXT,
                                GE.dtreception_dt DTDEBUT_DT,
                                GE.dtjour_dt DATE_FACTURE,
                                DECODE(t_elements.typeelem,
                                       'tp',
                                       NVL(GE.LIBELLE, T_ELEMENTS.LIBELLE),
                                       T_ELEMENTS.LIBELLE) LIBELLE,
                                T_ELEMENTS.ABREV ABREV,
                                T_ELEMENTS.DTASSOC_DT DTASSOC_DT,
                                GE.MONTANT_DOS MONTANT_DOS,
                                NULL PRELETTRAGE,
                                Ftr_Match.PartieLettreDette(T_ELEMENTS.refelem,
                                                            T_ELEMENTS.typeelem,
                                                            T_ELEMENTS.abrev) Lettrage,
                                NVL(GE.montant_dos, 0) -
                                NVL(Ftr_Match.LettrReelDette(T_ELEMENTS.refelem,
                                                             T_ELEMENTS.typeelem,
                                                             ''),
                                    0) RECONCILED_SOLDE,
                                T_ELEMENTS.typeelem ge_elemfi_type,
                                NULL FLAG_CTX,
                                T.clRefInd,
                                T.clientName,
                                NULL poExtRef,
                                NULL comm,
                                NULL calcDueDate
                           FROM T_ELEMENTS, 
                                G_ENCAISSEMENT GE, 
                                g_dossier GD, 
                                T
                          WHERE t_elements.typeelem IN ('tp', 've')
                            AND t_elements.refdoss = gd.refdoss
                            AND ge.refencaiss = t_elements.refelem
                            AND t_elements.refdoss = T.refdoss(+)
                            AND 1 = T.rn(+)
                            AND ge.typencaiss =
                                DECODE(t_elements.typeelem,
                                       'tp',
                                       'e_sadecaiss',
                                       'e_savirmt')
                            AND (gd.categdoss LIKE 'COMPTE%')
                            AND NOT EXISTS
                          (SELECT 1
                                   FROM g_elemfi g2, v_elemfi v2
                                  WHERE g2.refelem = t_elements.refelem
                                    AND g2.type = v2.type
                                    AND v2.fg_parent_invoice = 'O')
                            AND T_ELEMENTS.refdoss = :B3
                            AND ((NVL(T_ELEMENTS.montant_dos, 0) -
                                FTR_MATCH.LettrReelDette(T_ELEMENTS.refelem,
                                                           T_ELEMENTS.typeelem,
                                                           '')) > 0 OR
                                FTR_MATCH.DateDernLettr(T_ELEMENTS.refelem,
                                                         T_ELEMENTS.typeelem,
                                                         T_ELEMENTS.abrev,
                                                         T_ELEMENTS.refdoss,
                                                         'f') >
                                TO_CHAR(ADD_MONTHS(SYSDATE, -NVL(:B4, 1)), 'j'))
                            AND T_ELEMENTS.libelle not like
                                '%MVT MIGRATION CTX%'
                            AND NVL(T_ELEMENTS.Libelle, 'X') NOT LIKE
                                'REMBOURSEMENT NC%'
                         UNION
                         SELECT /*+ leading(T_ELEMENTS) */
                                NULL REFPIECE2,
                                T_ELEMENTS.imx_un_id imx_un_id,
                                T_ELEMENTS.REFDOSS REFDOSS,
                                T_ELEMENTS.REFELEM REFELEM,
                                T_ELEMENTS.REFELEMFI REFELEMFI,
                                T_ELEMENTS.TYPEELEM TYPEELEM,
                                GE.REFEXT REFEXT,
                                GE.dtreception_dt DTDEBUT_DT,
                                GE.dtjour_dt DATE_FACTURE,
                                GE.LIBELLE LIBELLE,
                                T_ELEMENTS.ABREV ABREV,
                                T_ELEMENTS.DTASSOC_DT DTASSOC_DT,
                                GE.MONTANT_DOS MONTANT_DOS,
                                NULL PRELETTRAGE,
                                Ftr_Match.PartieLettreDette(T_ELEMENTS.refelem,
                                                            T_ELEMENTS.typeelem,
                                                            T_ELEMENTS.abrev) Lettrage,
                                NVL(GE.montant_dos, 0) -
                                NVL(Ftr_Match.LettrReelDette(T_ELEMENTS.refelem,
                                                             T_ELEMENTS.typeelem,
                                                             ''),
                                    0) RECONCILED_SOLDE,
                                t_elements.typeelem ge_elemfi_type,
                                NULL FLAG_CTX,
                                T.clRefInd,
                                T.clientName,
                                NULL poExtRef,
                                NULL comm,
                                NULL calcDueDate
                           FROM T_ELEMENTS, 
                                G_ENCAISSEMENT GE, 
                                g_dossier GD, 
                                T
                          WHERE t_elements.typeelem = 'rd'
                            AND t_elements.refdoss = gd.refdoss
                            AND ge.refencaiss = t_elements.refelem
                            AND t_elements.refdoss = T.refdoss(+)
                            AND 1 = T.rn(+)
                            AND ge.typencaiss = 'rembdir'
                            AND (gd.categdoss LIKE 'COMPTE%')
                            AND NOT EXISTS
                          (SELECT 1
                                   FROM g_elemfi g2, v_elemfi v2
                                  WHERE g2.refelem = t_elements.refelem
                                    AND g2.type = v2.type
                                    AND v2.fg_parent_invoice = 'O')
                            AND T_ELEMENTS.refdoss = :B3
                            AND ((NVL(T_ELEMENTS.montant_dos, 0) -
                                FTR_MATCH.LettrReelDette(T_ELEMENTS.refelem,
                                                           T_ELEMENTS.typeelem,
                                                           '')) > 0 OR
                                FTR_MATCH.DateDernLettr(T_ELEMENTS.refelem,
                                                         T_ELEMENTS.typeelem,
                                                         T_ELEMENTS.abrev,
                                                         T_ELEMENTS.refdoss,
                                                         'f') >
                                TO_CHAR(ADD_MONTHS(SYSDATE, -NVL(:B4, 1)), 'j'))
                            AND T_ELEMENTS.libelle not like
                                '%MVT MIGRATION CTX%'
                            AND NVL(T_ELEMENTS.Libelle, 'X') NOT LIKE
                                'REMBOURSEMENT NC%'
                         UNION
                         SELECT /*+ leading(T_ELEMENTS) */
                                NULL REFPIECE2,
                                T_ELEMENTS.imx_un_id imx_un_id,
                                T_ELEMENTS.REFDOSS REFDOSS,
                                T_ELEMENTS.REFELEM REFELEM,
                                T_ELEMENTS.REFELEMFI REFELEMFI,
                                T_ELEMENTS.TYPEELEM TYPEELEM,
                                NULL REFEXT,
                                T_ELEMENTS.dtassoc_dt DTDEBUT_DT,
                                T_ELEMENTS.dtsaisie_dt DATE_FACTURE,
                                T_ELEMENTS.LIBELLE LIBELLE,
                                T_ELEMENTS.ABREV ABREV,
                                T_ELEMENTS.DTASSOC_DT DTASSOC_DT,
                                T_ELEMENTS.MONTANT_DOS MONTANT_DOS,
                                NULL PRELETTRAGE,
                                Ftr_Match.PartieLettreDette(T_ELEMENTS.refelem,
                                                            T_ELEMENTS.typeelem,
                                                            T_ELEMENTS.abrev) Lettrage,
                                NVL(T_ELEMENTS.MONTANT_DOS, 0) -
                                NVL(Ftr_Match.LettrReelDette(T_ELEMENTS.refelem,
                                                             T_ELEMENTS.typeelem,
                                                             T_ELEMENTS.abrev),
                                    0) RECONCILED_SOLDE,
                                t_elements.typeelem ge_elemfi_type,
                                NULL FLAG_CTX,
                                T.clRefInd,
                                T.clientName,
                                NULL poExtRef,
                                NULL comm,
                                NULL calcDueDate
                           FROM T_ELEMENTS,
                                f_detenr   GE,
                                g_dossier  GD,
                                f_parenr   FPA,
                                T
                          WHERE t_elements.typeelem = 'rg'
                            AND t_elements.refdoss = gd.refdoss
                            AND (de_des = 'T' AND de_sen = 'R' OR
                                de_des = 'E' AND de_sen = 'V')
                            AND de_nte IS NOT NULL
                            AND de_num = t_elements.refelem
                            AND ge.de_nom = fpa.pe_nom
                            AND FPA.pe_cha IS NOT NULL
                            AND SUBSTR(FPA.pe_cha, 2, 1) = 'D'
                            AND FPA.pe_nom NOT IN ('PNCDB')
                            AND gd.categdoss LIKE 'COMPTE%'
                            AND t_elements.refdoss = T.refdoss(+)
                            AND 1 = T.rn(+)
                            AND NOT EXISTS
                          (SELECT 1
                                   FROM g_elemfi g2, v_elemfi v2
                                  WHERE g2.refelem = t_elements.refelem
                                    AND g2.type = v2.type
                                    AND v2.fg_parent_invoice = 'O')
                            AND T_ELEMENTS.refdoss = :B3
                            AND ((NVL(T_ELEMENTS.montant_dos, 0) -
                                FTR_MATCH.LettrReelDette(T_ELEMENTS.refelem,
                                                           T_ELEMENTS.typeelem,
                                                           T_ELEMENTS.abrev)) > 0 OR
                                FTR_MATCH.DateDernLettr(T_ELEMENTS.refelem,
                                                         T_ELEMENTS.typeelem,
                                                         T_ELEMENTS.abrev,
                                                         T_ELEMENTS.refdoss,
                                                         'f') >
                                TO_CHAR(ADD_MONTHS(SYSDATE, -NVL(:B4, 1)), 'j'))
                            AND T_ELEMENTS.libelle not like
                                '%MVT MIGRATION CTX%'
                            AND NVL(T_ELEMENTS.Libelle, 'X') NOT LIKE
                                'REMBOURSEMENT NC%') T_ELEMENTS
                          WHERE 1 = 1
                          ORDER BY invDate, uniqueId
                ) foo
         WHERE ROWNUM <= :B5) g_main
 WHERE 1 = 1
   AND rnum >= :B6;

/********************************New SQL*******************************************/
/********************************New Metrics***************************************/
/*
-- SQL1

Plan hash value: 876659369
----------------------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                          | Name                         | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers |
----------------------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                                   |                              |      1 |        |    50 (100)|   1570 |00:00:02.95 |   65254 |
|   1 |  SORT AGGREGATE                                    |                              |   1570 |      1 |            |   1570 |00:00:00.06 |    2048 |
|   2 |   NESTED LOOPS                                     |                              |   1570 |      1 |     4   (0)|      0 |00:00:00.06 |    2048 |
|   3 |    NESTED LOOPS                                    |                              |   1570 |      1 |     4   (0)|      0 |00:00:00.05 |    2048 |
|   4 |     NESTED LOOPS                                   |                              |   1570 |      1 |     3   (0)|      0 |00:00:00.05 |    2048 |
|   5 |      NESTED LOOPS                                  |                              |   1570 |      1 |     2   (0)|      0 |00:00:00.05 |    2048 |
|   6 |       TABLE ACCESS BY INDEX ROWID                  | G_ELEMFI                     |   1570 |      1 |     1   (0)|   1570 |00:00:00.03 |    1729 |
|*  7 |        INDEX UNIQUE SCAN                           | EFI_REFELEM                  |   1570 |      1 |     1   (0)|   1570 |00:00:00.01 |     159 |
|*  8 |       INDEX RANGE SCAN                             | AK_KEY_2_G_ELEMFI            |   1570 |      1 |     1   (0)|      0 |00:00:00.01 |     319 |
|*  9 |      TABLE ACCESS BY INDEX ROWID BATCHED           | G_PIECE                      |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 10 |       INDEX RANGE SCAN                             | PIE_REFPIECE                 |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 11 |     INDEX RANGE SCAN                               | G_OUTPMT_EXEC_REFER_IDX      |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 12 |    TABLE ACCESS BY INDEX ROWID                     | G_OUTPMT_EXEC                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|  13 |  SORT AGGREGATE                                    |                              |   1570 |      1 |            |   1570 |00:00:30.33 |    3052K|
|* 14 |   TABLE ACCESS BY INDEX ROWID BATCHED              | NAM_ECR_COMPTA_BAK           |   1570 |      1 |     3   (0)|    158 |00:00:30.31 |    3052K|
|* 15 |    INDEX SKIP SCAN                                 | NEC_BAK_RECONCIL_IDX         |   1570 |    468 |     2   (0)|     16M|00:00:08.14 |     197K|
|* 16 |  VIEW                                              |                              |      1 |      4 |    43   (3)|   1570 |00:00:02.95 |   65254 |
|* 17 |   COUNT STOPKEY                                    |                              |      1 |        |            |   1570 |00:00:02.94 |   65254 |
|  18 |    VIEW                                            |                              |      1 |      4 |    43   (3)|   1570 |00:00:02.93 |   65254 |
|  19 |     WINDOW SORT                                    |                              |      1 |      4 |    43   (3)|   1570 |00:00:00.61 |   33854 |
|  20 |      VIEW                                          |                              |      1 |      4 |    43   (3)|   1570 |00:00:00.59 |   33854 |
|  21 |       SORT UNIQUE                                  |                              |      1 |      4 |    43   (3)|   1570 |00:00:00.59 |   33854 |
|  22 |        UNION-ALL                                   |                              |      1 |        |            |   1570 |00:00:00.58 |   33854 |
|  23 |         SORT GROUP BY                              |                              |      1 |      1 |            |      1 |00:00:00.01 |       1 |
|  24 |          NESTED LOOPS                              |                              |      1 |      1 |     4   (0)|      0 |00:00:00.01 |       1 |
|  25 |           NESTED LOOPS                             |                              |      1 |      1 |     4   (0)|      0 |00:00:00.01 |       1 |
|  26 |            NESTED LOOPS                            |                              |      1 |      1 |     3   (0)|      0 |00:00:00.01 |       1 |
|  27 |             NESTED LOOPS                           |                              |      1 |      1 |     2   (0)|      0 |00:00:00.01 |       1 |
|  28 |              TABLE ACCESS BY INDEX ROWID BATCHED   | G_ELEMFI                     |      1 |      1 |     1   (0)|      0 |00:00:00.01 |       1 |
|* 29 |               INDEX FULL SCAN                      | G_ELEMFI_REFPIECE_IDX        |      1 |      1 |     1   (0)|      0 |00:00:00.01 |       1 |
|  30 |              TABLE ACCESS BY INDEX ROWID BATCHED   | G_PIECE                      |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 31 |               INDEX RANGE SCAN                     | PIE_REFPIECE                 |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 32 |             TABLE ACCESS BY INDEX ROWID BATCHED    | G_ELEMFI                     |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 33 |              INDEX RANGE SCAN                      | G_ELEMFI$REFDOSS_REF_CREANCE |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 34 |            INDEX RANGE SCAN                        | VEN_ENCAIS                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 35 |           TABLE ACCESS BY INDEX ROWID              | G_VENELEM                    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 36 |         FILTER                                     |                              |      1 |        |            |   1570 |00:00:00.32 |   22865 |
|  37 |          NESTED LOOPS OUTER                        |                              |      1 |      1 |     8   (0)|   1570 |00:00:00.30 |   16328 |
|  38 |           NESTED LOOPS OUTER                       |                              |      1 |      1 |     5   (0)|   1570 |00:00:00.27 |   16295 |
|  39 |            NESTED LOOPS                            |                              |      1 |      1 |     4   (0)|   1570 |00:00:00.25 |   11760 |
|  40 |             MERGE JOIN CARTESIAN                   |                              |      1 |      1 |     3   (0)|   1570 |00:00:00.24 |   11286 |
|  41 |              NESTED LOOPS OUTER                    |                              |      1 |      1 |     2   (0)|   1570 |00:00:00.24 |   11283 |
|* 42 |               TABLE ACCESS BY INDEX ROWID BATCHED  | T_ELEMENTS                   |      1 |      1 |     1   (0)|   1570 |00:00:00.23 |   11279 |
|* 43 |                INDEX RANGE SCAN                    | ELE_DOSS_TYP_ASSOC_LIB       |      1 |      1 |     1   (0)|   2014 |00:00:00.01 |      17 |
|  44 |               VIEW PUSHED PREDICATE                | VW_SSQ_1                     |   1570 |      1 |     1   (0)|      1 |00:00:00.01 |       4 |
|  45 |                SORT GROUP BY                       |                              |   1570 |      1 |     1   (0)|      1 |00:00:00.01 |       4 |
|* 46 |                 TABLE ACCESS BY INDEX ROWID BATCHED| G_PRELETTRAGE                |   1570 |      1 |     1   (0)|      1 |00:00:00.01 |       4 |
|* 47 |                  INDEX RANGE SCAN                  | G_PREL_ELEM                  |   1570 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |
|  48 |              BUFFER SORT                           |                              |   1570 |      1 |     2   (0)|   1570 |00:00:00.01 |       3 |
|* 49 |               TABLE ACCESS BY INDEX ROWID          | G_DOSSIER                    |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |
|* 50 |                INDEX UNIQUE SCAN                   | DOS_REFDOSS                  |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       2 |
|* 51 |             TABLE ACCESS BY INDEX ROWID            | G_ELEMFI                     |   1570 |      1 |     1   (0)|   1570 |00:00:00.01 |     474 |
|* 52 |              INDEX UNIQUE SCAN                     | EFI_REFELEM                  |   1570 |      1 |     1   (0)|   1570 |00:00:00.01 |     299 |
|* 53 |            TABLE ACCESS BY INDEX ROWID BATCHED     | G_PIECE                      |   1570 |      1 |     1   (0)|   1570 |00:00:00.02 |    4535 |
|* 54 |             INDEX RANGE SCAN                       | GP_GRTYPE_MT_DT              |   1570 |      1 |     1   (0)|   1570 |00:00:00.01 |     866 |
|* 55 |           VIEW PUSHED PREDICATE                    |                              |   1570 |      1 |     3   (0)|   1570 |00:00:00.03 |      33 |
|  56 |            WINDOW BUFFER                           |                              |   1570 |      1 |     3   (0)|   1570 |00:00:00.03 |      33 |
|* 57 |             FILTER                                 |                              |   1570 |        |            |   1570 |00:00:00.01 |      33 |
|  58 |              NESTED LOOPS                          |                              |   1570 |      1 |     3   (0)|   1570 |00:00:00.01 |      33 |
|  59 |               NESTED LOOPS                         |                              |   1570 |      1 |     3   (0)|   1570 |00:00:00.01 |      32 |
|  60 |                NESTED LOOPS                        |                              |   1570 |      1 |     2   (0)|   1570 |00:00:00.01 |      18 |
|  61 |                 TABLE ACCESS BY INDEX ROWID        | G_DOSSIER                    |   1570 |      1 |     1   (0)|   1570 |00:00:00.01 |      10 |
|* 62 |                  INDEX UNIQUE SCAN                 | DOS_REFDOSS                  |   1570 |      1 |     1   (0)|   1570 |00:00:00.01 |       9 |
|* 63 |                 INDEX RANGE SCAN                   | INT_REFDOSS                  |   1570 |      1 |     1   (0)|   1570 |00:00:00.01 |       8 |
|* 64 |                INDEX UNIQUE SCAN                   | IND_REFINDIV                 |   1570 |      1 |     1   (0)|   1570 |00:00:00.01 |      14 |
|  65 |               TABLE ACCESS BY INDEX ROWID          | G_INDIVIDU                   |   1570 |      1 |     1   (0)|   1570 |00:00:00.01 |       1 |
|  66 |          NESTED LOOPS                              |                              |   1570 |      1 |     2   (0)|      0 |00:00:00.02 |    6537 |
|  67 |           TABLE ACCESS BY INDEX ROWID              | G_ELEMFI                     |   1570 |      1 |     1   (0)|   1570 |00:00:00.01 |    3397 |
|* 68 |            INDEX UNIQUE SCAN                       | EFI_REFELEM                  |   1570 |      1 |     1   (0)|   1570 |00:00:00.01 |    1827 |
|* 69 |           TABLE ACCESS BY INDEX ROWID BATCHED      | V_ELEMFI                     |   1570 |      1 |     1   (0)|      0 |00:00:00.01 |    3140 |
|* 70 |            INDEX RANGE SCAN                        | VF_TYPE_FINANCING            |   1570 |      1 |     1   (0)|   1570 |00:00:00.01 |    1570 |
|* 71 |          FILTER                                    |                              |      1 |        |            |      0 |00:00:00.01 |       0 |
|* 72 |           TABLE ACCESS BY INDEX ROWID BATCHED      | G_PIECE                      |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 73 |            INDEX RANGE SCAN                        | PIE_REFPIECE                 |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 74 |         FILTER                                     |                              |      1 |        |            |      0 |00:00:00.01 |       6 |
|  75 |          NESTED LOOPS OUTER                        |                              |      1 |      1 |     6   (0)|      0 |00:00:00.01 |       6 |
|  76 |           NESTED LOOPS                             |                              |      1 |      1 |     3   (0)|      0 |00:00:00.01 |       6 |
|  77 |            MERGE JOIN CARTESIAN                    |                              |      1 |      1 |     2   (0)|      0 |00:00:00.01 |       6 |
|  78 |             INLIST ITERATOR                        |                              |      1 |        |            |      0 |00:00:00.01 |       6 |
|* 79 |              TABLE ACCESS BY INDEX ROWID BATCHED   | T_ELEMENTS                   |      2 |      1 |     1   (0)|      0 |00:00:00.01 |       6 |
|* 80 |               INDEX RANGE SCAN                     | ELE_DOSS_TYP_ASSOC_LIB       |      2 |      1 |     1   (0)|      0 |00:00:00.01 |       6 |
|  81 |             BUFFER SORT                            |                              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 82 |              TABLE ACCESS BY INDEX ROWID           | G_DOSSIER                    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 83 |               INDEX UNIQUE SCAN                    | DOS_REFDOSS                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 84 |            TABLE ACCESS BY INDEX ROWID             | G_ENCAISSEMENT               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 85 |             INDEX UNIQUE SCAN                      | REFENCAISS                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 86 |           VIEW PUSHED PREDICATE                    |                              |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|  87 |            WINDOW BUFFER                           |                              |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|* 88 |             FILTER                                 |                              |      0 |        |            |      0 |00:00:00.01 |       0 |
|  89 |              NESTED LOOPS                          |                              |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|  90 |               NESTED LOOPS                         |                              |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|  91 |                NESTED LOOPS                        |                              |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |
|  92 |                 TABLE ACCESS BY INDEX ROWID        | G_DOSSIER                    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 93 |                  INDEX UNIQUE SCAN                 | DOS_REFDOSS                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 94 |                 INDEX RANGE SCAN                   | INT_REFDOSS                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 95 |                INDEX UNIQUE SCAN                   | IND_REFINDIV                 |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|  96 |               TABLE ACCESS BY INDEX ROWID          | G_INDIVIDU                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|  97 |          NESTED LOOPS                              |                              |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |
|  98 |           TABLE ACCESS BY INDEX ROWID              | G_ELEMFI                     |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 99 |            INDEX UNIQUE SCAN                       | EFI_REFELEM                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|*100 |           TABLE ACCESS BY INDEX ROWID BATCHED      | V_ELEMFI                     |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|*101 |            INDEX RANGE SCAN                        | VF_TYPE_FINANCING            |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|*102 |         FILTER                                     |                              |      1 |        |            |      0 |00:00:00.01 |     226 |
| 103 |          NESTED LOOPS OUTER                        |                              |      1 |      1 |     8   (0)|      0 |00:00:00.01 |     226 |
| 104 |           NESTED LOOPS                             |                              |      1 |      1 |     5   (0)|      0 |00:00:00.01 |     226 |
| 105 |            NESTED LOOPS                            |                              |      1 |      1 |     4   (0)|      0 |00:00:00.01 |     226 |
|*106 |             TABLE ACCESS BY INDEX ROWID BATCHED    | T_ELEMENTS                   |      1 |      1 |     3   (0)|      0 |00:00:00.01 |     226 |
|*107 |              INDEX SKIP SCAN                       | ELE_ELEMDOSS                 |      1 |     14 |     3   (0)|      0 |00:00:00.01 |     226 |
|*108 |             TABLE ACCESS BY INDEX ROWID            | G_DOSSIER                    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|*109 |              INDEX UNIQUE SCAN                     | DOS_REFDOSS                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|*110 |            TABLE ACCESS BY INDEX ROWID             | G_ENCAISSEMENT               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|*111 |             INDEX UNIQUE SCAN                      | REFENCAISS                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|*112 |           VIEW PUSHED PREDICATE                    |                              |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
| 113 |            WINDOW BUFFER                           |                              |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
| 114 |             NESTED LOOPS                           |                              |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
| 115 |              NESTED LOOPS                          |                              |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
| 116 |               NESTED LOOPS                         |                              |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |
| 117 |                TABLE ACCESS BY INDEX ROWID         | G_DOSSIER                    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|*118 |                 INDEX UNIQUE SCAN                  | DOS_REFDOSS                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|*119 |                INDEX RANGE SCAN                    | INT_REFDOSS                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|*120 |               INDEX UNIQUE SCAN                    | IND_REFINDIV                 |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
| 121 |              TABLE ACCESS BY INDEX ROWID           | G_INDIVIDU                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
| 122 |          NESTED LOOPS                              |                              |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |
| 123 |           TABLE ACCESS BY INDEX ROWID              | G_ELEMFI                     |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|*124 |            INDEX UNIQUE SCAN                       | EFI_REFELEM                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|*125 |           TABLE ACCESS BY INDEX ROWID BATCHED      | V_ELEMFI                     |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|*126 |            INDEX RANGE SCAN                        | VF_TYPE_FINANCING            |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|*127 |         FILTER                                     |                              |      1 |        |            |      0 |00:00:00.01 |       3 |
| 128 |          NESTED LOOPS OUTER                        |                              |      1 |      1 |     7   (0)|      0 |00:00:00.01 |       3 |
| 129 |           MERGE JOIN CARTESIAN                     |                              |      1 |      1 |     4   (0)|      0 |00:00:00.01 |       3 |
| 130 |            NESTED LOOPS                            |                              |      1 |      1 |     3   (0)|      0 |00:00:00.01 |       3 |
| 131 |             NESTED LOOPS                           |                              |      1 |      1 |     3   (0)|      0 |00:00:00.01 |       3 |
| 132 |              NESTED LOOPS                          |                              |      1 |      1 |     2   (0)|      0 |00:00:00.01 |       3 |
|*133 |               TABLE ACCESS BY INDEX ROWID BATCHED  | T_ELEMENTS                   |      1 |      1 |     1   (0)|      0 |00:00:00.01 |       3 |
|*134 |                INDEX RANGE SCAN                    | ELE_DOSS_TYP_ASSOC_LIB       |      1 |      1 |     1   (0)|      0 |00:00:00.01 |       3 |
|*135 |               TABLE ACCESS BY INDEX ROWID BATCHED  | F_DETENR                     |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|*136 |                INDEX FULL SCAN                     | DETENR_NTE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|*137 |              INDEX UNIQUE SCAN                     | PARENR_CL1                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|*138 |             TABLE ACCESS BY INDEX ROWID            | F_PARENR                     |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
| 139 |            BUFFER SORT                             |                              |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*140 |             TABLE ACCESS BY INDEX ROWID            | G_DOSSIER                    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|*141 |              INDEX UNIQUE SCAN                     | DOS_REFDOSS                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|*142 |           VIEW PUSHED PREDICATE                    |                              |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
| 143 |            WINDOW BUFFER                           |                              |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*144 |             FILTER                                 |                              |      0 |        |            |      0 |00:00:00.01 |       0 |
| 145 |              NESTED LOOPS                          |                              |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
| 146 |               NESTED LOOPS                         |                              |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
| 147 |                NESTED LOOPS                        |                              |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |
| 148 |                 TABLE ACCESS BY INDEX ROWID        | G_DOSSIER                    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|*149 |                  INDEX UNIQUE SCAN                 | DOS_REFDOSS                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|*150 |                 INDEX RANGE SCAN                   | INT_REFDOSS                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|*151 |                INDEX UNIQUE SCAN                   | IND_REFINDIV                 |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
| 152 |               TABLE ACCESS BY INDEX ROWID          | G_INDIVIDU                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
| 153 |          NESTED LOOPS                              |                              |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |
| 154 |           TABLE ACCESS BY INDEX ROWID              | G_ELEMFI                     |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|*155 |            INDEX UNIQUE SCAN                       | EFI_REFELEM                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|*156 |           TABLE ACCESS BY INDEX ROWID BATCHED      | V_ELEMFI                     |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|*157 |            INDEX RANGE SCAN                        | VF_TYPE_FINANCING            |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
----------------------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   7 - access("E"."REFELEM"=:B1)
   8 - access("A"."REFFACTURE"="E"."REFPIECE2")
   9 - filter("B"."GPIRESSORT" IS NOT NULL)
  10 - access("B"."REFPIECE"="A"."REFAGGR")
  11 - access("O"."REFER"="B"."GPIRESSORT")
  12 - filter("O"."DTEXECUTION_DT" IS NOT NULL)
  14 - filter(("AGGR"."EXTREF19"=:B1 AND "AGGR"."CODEOPER"='MATCH_PMT'))
  15 - access("AGGR"."STATUS_RECONCIL"='REJECTED')
       filter("AGGR"."STATUS_RECONCIL"='REJECTED')
  16 - filter("RNUM">=:B1)
  17 - filter(ROWNUM<=:B5)
  29 - filter("GE"."REFPIECE3" IS NOT NULL)
  31 - access("GP"."REFPIECE"="GE"."REFPIECE3")
  32 - filter("POI"."TYPE"='PO INVOICED')
  33 - access("POI"."REFDOSS"="GE"."REFDOSS" AND "POI"."REF_CREANCE"="GE"."REFELEM")
       filter("POI"."REF_CREANCE" IS NOT NULL)
  34 - access("POI"."REFELEM"="V"."REFENCAISS")
  35 - filter(("V"."TYPENCAISS"='fi' AND "GE"."REFELEM"="V"."REFELEM" AND "V"."TYPELEM"='fi'))
  36 - filter(( IS NULL AND  IS NULL))
  42 - filter((NVL("T_ELEMENTS"."MONTANT_DOS",0)-"FTR_MATCH"."LETTRREELDETTE"("T_ELEMENTS"."REFELEM","T_ELEMENTS"."TYPEELEM",'')>0 OR
              "FTR_MATCH"."DATEDERNLETTR"("T_ELEMENTS"."REFELEM","T_ELEMENTS"."TYPEELEM","T_ELEMENTS"."ABREV","T_ELEMENTS"."REFDOSS",'f')>TO_NUMBER(TO_CHAR(ADD_
              MONTHS(SYSDATE@!,(-NVL(:B4,1))),'j'))))
  43 - access("T_ELEMENTS"."REFDOSS"=:B3 AND "T_ELEMENTS"."TYPEELEM"='fi')
       filter((NVL("T_ELEMENTS"."LIBELLE",'X') NOT LIKE 'REMBOURSEMENT NC%' AND "T_ELEMENTS"."LIBELLE" NOT LIKE '%MVT MIGRATION CTX%' AND
              "T_ELEMENTS"."LIBELLE" IS NOT NULL))
  46 - filter("TYPELEM"="T_ELEMENTS"."TYPEELEM")
  47 - access("REFELEM"="T_ELEMENTS"."REFELEM")
  49 - filter("GD"."CATEGDOSS" LIKE 'COMPTE%')
  50 - access("GD"."REFDOSS"=:B3)
  51 - filter(("GE"."TYPE"<>'SALES ORDER' AND NVL("GE"."LIBELLE",'X')<>'TOLERANCE AMOUNT' AND "GE"."MONTANT_DOS">=0))
  52 - access("GE"."REFELEM"="T_ELEMENTS"."REFELEM")
  53 - filter("GP_FACT"."REFDOSS"=:B3)
  54 - access("GP_FACT"."TYPPIECE"='FACTURE' AND "GE"."REFELEM"="GP_FACT"."GPIHEURE")
       filter("GP_FACT"."GPIHEURE" IS NOT NULL)
  55 - filter("T"."RN"=1)
  57 - filter("T_ELEMENTS"."REFDOSS"=:B3)
  62 - access("CMPT"."REFDOSS"=:B3)
  63 - access("CL"."REFDOSS"=:B3 AND "CL"."REFTYPE"=DECODE("CMPT"."CATEGDOSS",'COMPTE IMP','TC','CL'))
  64 - access("ICL"."REFINDIVIDU"="CL"."REFINDIVIDU")
  68 - access("G2"."REFELEM"=:B1)
  69 - filter("V2"."FG_PARENT_INVOICE"='O')
  70 - access("G2"."TYPE"="V2"."TYPE")
  71 - filter(:B1 IS NOT NULL)
  72 - filter("PO"."TYPPIECE"='BON DE COMMANDE')
  73 - access("PO"."REFPIECE"=:B1)
  74 - filter( IS NULL)
  79 - filter((NVL("T_ELEMENTS"."MONTANT_DOS",0)-"FTR_MATCH"."LETTRREELDETTE"("T_ELEMENTS"."REFELEM","T_ELEMENTS"."TYPEELEM",'')>0 OR
              "FTR_MATCH"."DATEDERNLETTR"("T_ELEMENTS"."REFELEM","T_ELEMENTS"."TYPEELEM","T_ELEMENTS"."ABREV","T_ELEMENTS"."REFDOSS",'f')>TO_NUMBER(TO_CHAR(ADD_
              MONTHS(SYSDATE@!,(-NVL(:B4,1))),'j'))))
  80 - access("T_ELEMENTS"."REFDOSS"=:B3 AND (("T_ELEMENTS"."TYPEELEM"='tp' OR "T_ELEMENTS"."TYPEELEM"='ve')))
       filter((NVL("T_ELEMENTS"."LIBELLE",'X') NOT LIKE 'REMBOURSEMENT NC%' AND "T_ELEMENTS"."LIBELLE" NOT LIKE '%MVT MIGRATION CTX%' AND
              "T_ELEMENTS"."LIBELLE" IS NOT NULL))
  82 - filter("GD"."CATEGDOSS" LIKE 'COMPTE%')
  83 - access("GD"."REFDOSS"=:B3)
  84 - filter("GE"."TYPENCAISS"=DECODE("T_ELEMENTS"."TYPEELEM",'tp','e_sadecaiss','e_savirmt'))
  85 - access("GE"."REFENCAISS"="T_ELEMENTS"."REFELEM")
  86 - filter("T"."RN"=1)
  88 - filter("T_ELEMENTS"."REFDOSS"=:B3)
  93 - access("CMPT"."REFDOSS"=:B3)
  94 - access("CL"."REFDOSS"=:B3 AND "CL"."REFTYPE"=DECODE("CMPT"."CATEGDOSS",'COMPTE IMP','TC','CL'))
  95 - access("ICL"."REFINDIVIDU"="CL"."REFINDIVIDU")
  99 - access("G2"."REFELEM"=:B1)
 100 - filter("V2"."FG_PARENT_INVOICE"='O')
 101 - access("G2"."TYPE"="V2"."TYPE")
 102 - filter( IS NULL)
 106 - filter((NVL("T_ELEMENTS"."LIBELLE",'X') NOT LIKE 'REMBOURSEMENT NC%' AND "T_ELEMENTS"."LIBELLE" NOT LIKE '%MVT MIGRATION CTX%' AND
              "T_ELEMENTS"."LIBELLE" IS NOT NULL AND (NVL("T_ELEMENTS"."MONTANT_DOS",0)-"FTR_MATCH"."LETTRREELDETTE"("T_ELEMENTS"."REFELEM","T_ELEMENTS"."TYPEEL
              EM",'')>0 OR "FTR_MATCH"."DATEDERNLETTR"("T_ELEMENTS"."REFELEM","T_ELEMENTS"."TYPEELEM","T_ELEMENTS"."ABREV","T_ELEMENTS"."REFDOSS",'f')>TO_NUMBER
              (TO_CHAR(ADD_MONTHS(SYSDATE@!,(-NVL(:B4,1))),'j')))))
 107 - access("T_ELEMENTS"."TYPEELEM"='rd')
       filter(("T_ELEMENTS"."TYPEELEM"='rd' AND TO_NUMBER("T_ELEMENTS"."REFDOSS")=:B4))
 108 - filter("GD"."CATEGDOSS" LIKE 'COMPTE%')
 109 - access("T_ELEMENTS"."REFDOSS"="GD"."REFDOSS")
       filter(TO_NUMBER("GD"."REFDOSS")=:B4)
 110 - filter("GE"."TYPENCAISS"='rembdir')
 111 - access("GE"."REFENCAISS"="T_ELEMENTS"."REFELEM")
 112 - filter("T"."RN"=1)
 118 - access("CMPT"."REFDOSS"="T_ELEMENTS"."REFDOSS")
       filter(TO_NUMBER("CMPT"."REFDOSS")=:B4)
 119 - access("CL"."REFDOSS"="T_ELEMENTS"."REFDOSS" AND "CL"."REFTYPE"=DECODE("CMPT"."CATEGDOSS",'COMPTE IMP','TC','CL'))
 120 - access("ICL"."REFINDIVIDU"="CL"."REFINDIVIDU")
 124 - access("G2"."REFELEM"=:B1)
 125 - filter("V2"."FG_PARENT_INVOICE"='O')
 126 - access("G2"."TYPE"="V2"."TYPE")
 127 - filter( IS NULL)
 133 - filter((NVL("T_ELEMENTS"."MONTANT_DOS",0)-"FTR_MATCH"."LETTRREELDETTE"("T_ELEMENTS"."REFELEM","T_ELEMENTS"."TYPEELEM","T_ELEMENTS"."ABREV")
              >0 OR "FTR_MATCH"."DATEDERNLETTR"("T_ELEMENTS"."REFELEM","T_ELEMENTS"."TYPEELEM","T_ELEMENTS"."ABREV","T_ELEMENTS"."REFDOSS",'f')>TO_NUMBER(TO_CHA
              R(ADD_MONTHS(SYSDATE@!,(-NVL(:B4,1))),'j'))))
 134 - access("T_ELEMENTS"."REFDOSS"=:B3 AND "T_ELEMENTS"."TYPEELEM"='rg')
       filter((NVL("T_ELEMENTS"."LIBELLE",'X') NOT LIKE 'REMBOURSEMENT NC%' AND "T_ELEMENTS"."LIBELLE" NOT LIKE '%MVT MIGRATION CTX%' AND
              "T_ELEMENTS"."LIBELLE" IS NOT NULL))
 135 - filter(("DE_NUM"="T_ELEMENTS"."REFELEM" AND (("DE_SEN"='R' AND "DE_DES"='T') OR ("DE_SEN"='V' AND "DE_DES"='E')) AND
              "GE"."DE_NOM"<>'PNCDB'))
 136 - filter("DE_NTE" IS NOT NULL)
 137 - access("GE"."DE_NOM"="FPA"."PE_NOM")
       filter("FPA"."PE_NOM"<>'PNCDB')
 138 - filter(("FPA"."PE_CHA" IS NOT NULL AND SUBSTR("FPA"."PE_CHA",2,1)='D'))
 140 - filter("GD"."CATEGDOSS" LIKE 'COMPTE%')
 141 - access("GD"."REFDOSS"=:B3)
 142 - filter("T"."RN"=1)
 144 - filter("T_ELEMENTS"."REFDOSS"=:B3)
 149 - access("CMPT"."REFDOSS"=:B3)
 150 - access("CL"."REFDOSS"=:B3 AND "CL"."REFTYPE"=DECODE("CMPT"."CATEGDOSS",'COMPTE IMP','TC','CL'))
 151 - access("ICL"."REFINDIVIDU"="CL"."REFINDIVIDU")
 155 - access("G2"."REFELEM"=:B1)
 156 - filter("V2"."FG_PARENT_INVOICE"='O')
 157 - access("G2"."TYPE"="V2"."TYPE")



-- SQL2

Plan hash value: 98245239
------------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                          | Name                         | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   |
------------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                                   |                              |      1 |        |    48 (100)|      0 |00:00:00.01 |
|   1 |  SORT AGGREGATE                                    |                              |      0 |      1 |            |      0 |00:00:00.01 |
|   2 |   NESTED LOOPS                                     |                              |      0 |      1 |     4   (0)|      0 |00:00:00.01 |
|   3 |    NESTED LOOPS                                    |                              |      0 |      1 |     4   (0)|      0 |00:00:00.01 |
|   4 |     NESTED LOOPS                                   |                              |      0 |      1 |     3   (0)|      0 |00:00:00.01 |
|   5 |      NESTED LOOPS                                  |                              |      0 |      1 |     2   (0)|      0 |00:00:00.01 |
|   6 |       TABLE ACCESS BY INDEX ROWID                  | G_ELEMFI                     |      0 |      1 |     1   (0)|      0 |00:00:00.01 |
|*  7 |        INDEX UNIQUE SCAN                           | EFI_REFELEM                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |
|*  8 |       INDEX RANGE SCAN                             | AK_KEY_2_G_ELEMFI            |      0 |      1 |     1   (0)|      0 |00:00:00.01 |
|*  9 |      TABLE ACCESS BY INDEX ROWID BATCHED           | G_PIECE                      |      0 |      1 |     1   (0)|      0 |00:00:00.01 |
|* 10 |       INDEX RANGE SCAN                             | PIE_REFPIECE                 |      0 |      1 |     1   (0)|      0 |00:00:00.01 |
|* 11 |     INDEX RANGE SCAN                               | G_OUTPMT_EXEC_REFER_IDX      |      0 |      1 |     1   (0)|      0 |00:00:00.01 |
|* 12 |    TABLE ACCESS BY INDEX ROWID                     | G_OUTPMT_EXEC                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |
|  13 |  SORT AGGREGATE                                    |                              |      0 |      1 |            |      0 |00:00:00.01 |
|* 14 |   TABLE ACCESS BY INDEX ROWID BATCHED              | NAM_ECR_COMPTA_BAK           |      0 |      1 |     3   (0)|      0 |00:00:00.01 |
|* 15 |    INDEX SKIP SCAN                                 | NEC_BAK_RECONCIL_IDX         |      0 |    468 |     2   (0)|      0 |00:00:00.01 |
|* 16 |  VIEW                                              |                              |      1 |      4 |    41   (3)|      0 |00:00:00.01 |
|* 17 |   COUNT STOPKEY                                    |                              |      1 |        |            |      0 |00:00:00.01 |
|  18 |    VIEW                                            |                              |      1 |      4 |    41   (3)|      0 |00:00:00.01 |
|  19 |     WINDOW SORT                                    |                              |      1 |      4 |    41   (3)|      0 |00:00:00.01 |
|  20 |      VIEW                                          |                              |      1 |      4 |    41   (3)|      0 |00:00:00.01 |
|  21 |       SORT UNIQUE                                  |                              |      1 |      4 |    41   (3)|      0 |00:00:00.01 |
|  22 |        UNION-ALL                                   |                              |      1 |        |            |      0 |00:00:00.01 |
|  23 |         SORT GROUP BY                              |                              |      0 |      1 |            |      0 |00:00:00.01 |
|  24 |          NESTED LOOPS                              |                              |      0 |      1 |     4   (0)|      0 |00:00:00.01 |
|  25 |           NESTED LOOPS                             |                              |      0 |      1 |     4   (0)|      0 |00:00:00.01 |
|  26 |            NESTED LOOPS                            |                              |      0 |      1 |     3   (0)|      0 |00:00:00.01 |
|  27 |             NESTED LOOPS                           |                              |      0 |      1 |     2   (0)|      0 |00:00:00.01 |
|  28 |              TABLE ACCESS BY INDEX ROWID BATCHED   | G_ELEMFI                     |      0 |      1 |     1   (0)|      0 |00:00:00.01 |
|* 29 |               INDEX FULL SCAN                      | G_ELEMFI_REFPIECE_IDX        |      0 |      1 |     1   (0)|      0 |00:00:00.01 |
|  30 |              TABLE ACCESS BY INDEX ROWID BATCHED   | G_PIECE                      |      0 |      1 |     1   (0)|      0 |00:00:00.01 |
|* 31 |               INDEX RANGE SCAN                     | PIE_REFPIECE                 |      0 |      1 |     1   (0)|      0 |00:00:00.01 |
|* 32 |             TABLE ACCESS BY INDEX ROWID BATCHED    | G_ELEMFI                     |      0 |      1 |     1   (0)|      0 |00:00:00.01 |
|* 33 |              INDEX RANGE SCAN                      | G_ELEMFI$REFDOSS_REF_CREANCE |      0 |      1 |     1   (0)|      0 |00:00:00.01 |
|* 34 |            INDEX RANGE SCAN                        | VEN_ENCAIS                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |
|* 35 |           TABLE ACCESS BY INDEX ROWID              | G_VENELEM                    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |
|* 36 |         FILTER                                     |                              |      1 |        |            |      0 |00:00:00.01 |
|  37 |          NESTED LOOPS OUTER                        |                              |      1 |      1 |     8   (0)|      0 |00:00:00.01 |
|  38 |           NESTED LOOPS OUTER                       |                              |      1 |      1 |     5   (0)|      0 |00:00:00.01 |
|  39 |            NESTED LOOPS                            |                              |      1 |      1 |     4   (0)|      0 |00:00:00.01 |
|  40 |             MERGE JOIN CARTESIAN                   |                              |      1 |      1 |     3   (0)|      0 |00:00:00.01 |
|  41 |              NESTED LOOPS OUTER                    |                              |      1 |      1 |     2   (0)|      0 |00:00:00.01 |
|* 42 |               TABLE ACCESS BY INDEX ROWID BATCHED  | T_ELEMENTS                   |      1 |      1 |     1   (0)|      0 |00:00:00.01 |
|* 43 |                INDEX RANGE SCAN                    | ELE_ELEMDOSS                 |      1 |      1 |     1   (0)|      0 |00:00:00.01 |
|  44 |               VIEW PUSHED PREDICATE                | VW_SSQ_1                     |      0 |      1 |     1   (0)|      0 |00:00:00.01 |
|  45 |                SORT GROUP BY                       |                              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |
|* 46 |                 TABLE ACCESS BY INDEX ROWID BATCHED| G_PRELETTRAGE                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |
|* 47 |                  INDEX RANGE SCAN                  | G_PREL_ELEM                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |
|  48 |              BUFFER SORT                           |                              |      0 |      1 |     2   (0)|      0 |00:00:00.01 |
|* 49 |               TABLE ACCESS BY INDEX ROWID BATCHED  | G_DOSSIER                    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |
|* 50 |                INDEX RANGE SCAN                    | DOSS_CODESOC_IDX             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |
|* 51 |             TABLE ACCESS BY INDEX ROWID            | G_ELEMFI                     |      0 |      1 |     1   (0)|      0 |00:00:00.01 |
|* 52 |              INDEX UNIQUE SCAN                     | EFI_REFELEM                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |
|* 53 |            TABLE ACCESS BY INDEX ROWID BATCHED     | G_PIECE                      |      0 |      1 |     1   (0)|      0 |00:00:00.01 |
|* 54 |             INDEX RANGE SCAN                       | PIE_REFDOSS                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |
|* 55 |           VIEW PUSHED PREDICATE                    |                              |      0 |      1 |     3   (0)|      0 |00:00:00.01 |
|  56 |            WINDOW BUFFER                           |                              |      0 |      1 |     3   (0)|      0 |00:00:00.01 |
|* 57 |             FILTER                                 |                              |      0 |        |            |      0 |00:00:00.01 |
|  58 |              NESTED LOOPS                          |                              |      0 |      1 |     3   (0)|      0 |00:00:00.01 |
|  59 |               NESTED LOOPS                         |                              |      0 |      1 |     3   (0)|      0 |00:00:00.01 |
|  60 |                NESTED LOOPS                        |                              |      0 |      1 |     2   (0)|      0 |00:00:00.01 |
|  61 |                 TABLE ACCESS BY INDEX ROWID        | G_DOSSIER                    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |
|* 62 |                  INDEX RANGE SCAN                  | DOSS_CODESOC_IDX             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |
|* 63 |                 INDEX RANGE SCAN                   | INT_REFDOSS                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |
|* 64 |                INDEX UNIQUE SCAN                   | IND_REFINDIV                 |      0 |      1 |     1   (0)|      0 |00:00:00.01 |
|  65 |               TABLE ACCESS BY INDEX ROWID          | G_INDIVIDU                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |
|  66 |          NESTED LOOPS                              |                              |      0 |      1 |     2   (0)|      0 |00:00:00.01 |
|  67 |           TABLE ACCESS BY INDEX ROWID              | G_ELEMFI                     |      0 |      1 |     1   (0)|      0 |00:00:00.01 |
|* 68 |            INDEX UNIQUE SCAN                       | EFI_REFELEM                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |
|* 69 |           TABLE ACCESS BY INDEX ROWID BATCHED      | V_ELEMFI                     |      0 |      1 |     1   (0)|      0 |00:00:00.01 |
|* 70 |            INDEX RANGE SCAN                        | VF_TYPE_FINANCING            |      0 |      1 |     1   (0)|      0 |00:00:00.01 |
|* 71 |          FILTER                                    |                              |      0 |        |            |      0 |00:00:00.01 |
|* 72 |           TABLE ACCESS BY INDEX ROWID BATCHED      | G_PIECE                      |      0 |      1 |     1   (0)|      0 |00:00:00.01 |
|* 73 |            INDEX RANGE SCAN                        | PIE_REFPIECE                 |      0 |      1 |     1   (0)|      0 |00:00:00.01 |
|* 74 |         FILTER                                     |                              |      0 |        |            |      0 |00:00:00.01 |
|  75 |          NESTED LOOPS OUTER                        |                              |      0 |      1 |     6   (0)|      0 |00:00:00.01 |
|  76 |           NESTED LOOPS                             |                              |      0 |      1 |     3   (0)|      0 |00:00:00.01 |
|  77 |            MERGE JOIN CARTESIAN                    |                              |      0 |      1 |     2   (0)|      0 |00:00:00.01 |
|* 78 |             TABLE ACCESS BY INDEX ROWID BATCHED    | T_ELEMENTS                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |
|* 79 |              INDEX RANGE SCAN                      | ELE_ELEMDOSS                 |      0 |      1 |     1   (0)|      0 |00:00:00.01 |
|  80 |             BUFFER SORT                            |                              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |
|* 81 |              TABLE ACCESS BY INDEX ROWID BATCHED   | G_DOSSIER                    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |
|* 82 |               INDEX RANGE SCAN                     | DOSS_CODESOC_IDX             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |
|* 83 |            TABLE ACCESS BY INDEX ROWID             | G_ENCAISSEMENT               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |
|* 84 |             INDEX UNIQUE SCAN                      | REFENCAISS                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |
|* 85 |           VIEW PUSHED PREDICATE                    |                              |      0 |      1 |     3   (0)|      0 |00:00:00.01 |
|  86 |            WINDOW BUFFER                           |                              |      0 |      1 |     3   (0)|      0 |00:00:00.01 |
|* 87 |             FILTER                                 |                              |      0 |        |            |      0 |00:00:00.01 |
|  88 |              NESTED LOOPS                          |                              |      0 |      1 |     3   (0)|      0 |00:00:00.01 |
|  89 |               NESTED LOOPS                         |                              |      0 |      1 |     3   (0)|      0 |00:00:00.01 |
|  90 |                NESTED LOOPS                        |                              |      0 |      1 |     2   (0)|      0 |00:00:00.01 |
|  91 |                 TABLE ACCESS BY INDEX ROWID        | G_DOSSIER                    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |
|* 92 |                  INDEX RANGE SCAN                  | DOSS_CODESOC_IDX             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |
|* 93 |                 INDEX RANGE SCAN                   | INT_REFDOSS                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |
|* 94 |                INDEX UNIQUE SCAN                   | IND_REFINDIV                 |      0 |      1 |     1   (0)|      0 |00:00:00.01 |
|  95 |               TABLE ACCESS BY INDEX ROWID          | G_INDIVIDU                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |
|  96 |          NESTED LOOPS                              |                              |      0 |      1 |     2   (0)|      0 |00:00:00.01 |
|  97 |           TABLE ACCESS BY INDEX ROWID              | G_ELEMFI                     |      0 |      1 |     1   (0)|      0 |00:00:00.01 |
|* 98 |            INDEX UNIQUE SCAN                       | EFI_REFELEM                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |
|* 99 |           TABLE ACCESS BY INDEX ROWID BATCHED      | V_ELEMFI                     |      0 |      1 |     1   (0)|      0 |00:00:00.01 |
|*100 |            INDEX RANGE SCAN                        | VF_TYPE_FINANCING            |      0 |      1 |     1   (0)|      0 |00:00:00.01 |
|*101 |         FILTER                                     |                              |      0 |        |            |      0 |00:00:00.01 |
| 102 |          NESTED LOOPS OUTER                        |                              |      0 |      1 |     6   (0)|      0 |00:00:00.01 |
| 103 |           NESTED LOOPS                             |                              |      0 |      1 |     3   (0)|      0 |00:00:00.01 |
| 104 |            MERGE JOIN CARTESIAN                    |                              |      0 |      1 |     2   (0)|      0 |00:00:00.01 |
|*105 |             TABLE ACCESS BY INDEX ROWID BATCHED    | T_ELEMENTS                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |
|*106 |              INDEX RANGE SCAN                      | ELE_ELEMDOSS                 |      0 |      1 |     1   (0)|      0 |00:00:00.01 |
| 107 |             BUFFER SORT                            |                              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |
|*108 |              TABLE ACCESS BY INDEX ROWID BATCHED   | G_DOSSIER                    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |
|*109 |               INDEX RANGE SCAN                     | DOSS_CODESOC_IDX             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |
|*110 |            TABLE ACCESS BY INDEX ROWID             | G_ENCAISSEMENT               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |
|*111 |             INDEX UNIQUE SCAN                      | REFENCAISS                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |
|*112 |           VIEW PUSHED PREDICATE                    |                              |      0 |      1 |     3   (0)|      0 |00:00:00.01 |
| 113 |            WINDOW BUFFER                           |                              |      0 |      1 |     3   (0)|      0 |00:00:00.01 |
|*114 |             FILTER                                 |                              |      0 |        |            |      0 |00:00:00.01 |
| 115 |              NESTED LOOPS                          |                              |      0 |      1 |     3   (0)|      0 |00:00:00.01 |
| 116 |               NESTED LOOPS                         |                              |      0 |      1 |     3   (0)|      0 |00:00:00.01 |
| 117 |                NESTED LOOPS                        |                              |      0 |      1 |     2   (0)|      0 |00:00:00.01 |
| 118 |                 TABLE ACCESS BY INDEX ROWID        | G_DOSSIER                    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |
|*119 |                  INDEX RANGE SCAN                  | DOSS_CODESOC_IDX             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |
|*120 |                 INDEX RANGE SCAN                   | INT_REFDOSS                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |
|*121 |                INDEX UNIQUE SCAN                   | IND_REFINDIV                 |      0 |      1 |     1   (0)|      0 |00:00:00.01 |
| 122 |               TABLE ACCESS BY INDEX ROWID          | G_INDIVIDU                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |
| 123 |          NESTED LOOPS                              |                              |      0 |      1 |     2   (0)|      0 |00:00:00.01 |
| 124 |           TABLE ACCESS BY INDEX ROWID              | G_ELEMFI                     |      0 |      1 |     1   (0)|      0 |00:00:00.01 |
|*125 |            INDEX UNIQUE SCAN                       | EFI_REFELEM                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |
|*126 |           TABLE ACCESS BY INDEX ROWID BATCHED      | V_ELEMFI                     |      0 |      1 |     1   (0)|      0 |00:00:00.01 |
|*127 |            INDEX RANGE SCAN                        | VF_TYPE_FINANCING            |      0 |      1 |     1   (0)|      0 |00:00:00.01 |
|*128 |         FILTER                                     |                              |      0 |        |            |      0 |00:00:00.01 |
| 129 |          NESTED LOOPS OUTER                        |                              |      0 |      1 |     7   (0)|      0 |00:00:00.01 |
| 130 |           NESTED LOOPS                             |                              |      0 |      1 |     4   (0)|      0 |00:00:00.01 |
| 131 |            MERGE JOIN CARTESIAN                    |                              |      0 |      1 |     3   (0)|      0 |00:00:00.01 |
| 132 |             NESTED LOOPS                           |                              |      0 |      1 |     2   (0)|      0 |00:00:00.01 |
| 133 |              NESTED LOOPS                          |                              |      0 |      1 |     2   (0)|      0 |00:00:00.01 |
|*134 |               TABLE ACCESS BY INDEX ROWID BATCHED  | T_ELEMENTS                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |
|*135 |                INDEX RANGE SCAN                    | ELE_ELEMDOSS                 |      0 |      1 |     1   (0)|      0 |00:00:00.01 |
|*136 |               INDEX FULL SCAN                      | DETENR_NTE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |
|*137 |              TABLE ACCESS BY INDEX ROWID           | F_DETENR                     |      0 |      1 |     1   (0)|      0 |00:00:00.01 |
| 138 |             BUFFER SORT                            |                              |      0 |      1 |     2   (0)|      0 |00:00:00.01 |
|*139 |              TABLE ACCESS BY INDEX ROWID BATCHED   | G_DOSSIER                    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |
|*140 |               INDEX RANGE SCAN                     | DOSS_CODESOC_IDX             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |
|*141 |            TABLE ACCESS BY INDEX ROWID             | F_PARENR                     |      0 |      1 |     1   (0)|      0 |00:00:00.01 |
|*142 |             INDEX UNIQUE SCAN                      | PARENR_CL1                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |
|*143 |           VIEW PUSHED PREDICATE                    |                              |      0 |      1 |     3   (0)|      0 |00:00:00.01 |
| 144 |            WINDOW BUFFER                           |                              |      0 |      1 |     3   (0)|      0 |00:00:00.01 |
|*145 |             FILTER                                 |                              |      0 |        |            |      0 |00:00:00.01 |
| 146 |              NESTED LOOPS                          |                              |      0 |      1 |     3   (0)|      0 |00:00:00.01 |
| 147 |               NESTED LOOPS                         |                              |      0 |      1 |     3   (0)|      0 |00:00:00.01 |
| 148 |                NESTED LOOPS                        |                              |      0 |      1 |     2   (0)|      0 |00:00:00.01 |
| 149 |                 TABLE ACCESS BY INDEX ROWID        | G_DOSSIER                    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |
|*150 |                  INDEX RANGE SCAN                  | DOSS_CODESOC_IDX             |      0 |      1 |     1   (0)|      0 |00:00:00.01 |
|*151 |                 INDEX RANGE SCAN                   | INT_REFDOSS                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |
|*152 |                INDEX UNIQUE SCAN                   | IND_REFINDIV                 |      0 |      1 |     1   (0)|      0 |00:00:00.01 |
| 153 |               TABLE ACCESS BY INDEX ROWID          | G_INDIVIDU                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |
| 154 |          NESTED LOOPS                              |                              |      0 |      1 |     2   (0)|      0 |00:00:00.01 |
| 155 |           TABLE ACCESS BY INDEX ROWID              | G_ELEMFI                     |      0 |      1 |     1   (0)|      0 |00:00:00.01 |
|*156 |            INDEX UNIQUE SCAN                       | EFI_REFELEM                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |
|*157 |           TABLE ACCESS BY INDEX ROWID BATCHED      | V_ELEMFI                     |      0 |      1 |     1   (0)|      0 |00:00:00.01 |
|*158 |            INDEX RANGE SCAN                        | VF_TYPE_FINANCING            |      0 |      1 |     1   (0)|      0 |00:00:00.01 |
------------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   7 - access("E"."REFELEM"=:B1)
   8 - access("A"."REFFACTURE"="E"."REFPIECE2")
   9 - filter("B"."GPIRESSORT" IS NOT NULL)
  10 - access("B"."REFPIECE"="A"."REFAGGR")
  11 - access("O"."REFER"="B"."GPIRESSORT")
  12 - filter("O"."DTEXECUTION_DT" IS NOT NULL)
  14 - filter(("AGGR"."EXTREF19"=:B1 AND "AGGR"."CODEOPER"='MATCH_PMT'))
  15 - access("AGGR"."STATUS_RECONCIL"='REJECTED')
       filter("AGGR"."STATUS_RECONCIL"='REJECTED')
  16 - filter("RNUM">=:B1)
  17 - filter(ROWNUM<=:B5)
  29 - filter("GE"."REFPIECE3" IS NOT NULL)
  31 - access("GP"."REFPIECE"="GE"."REFPIECE3")
  32 - filter("POI"."TYPE"='PO INVOICED')
  33 - access("POI"."REFDOSS"="GE"."REFDOSS" AND "POI"."REF_CREANCE"="GE"."REFELEM")
       filter("POI"."REF_CREANCE" IS NOT NULL)
  34 - access("POI"."REFELEM"="V"."REFENCAISS")
  35 - filter(("V"."TYPENCAISS"='fi' AND "GE"."REFELEM"="V"."REFELEM" AND "V"."TYPELEM"='fi'))
  36 - filter(( IS NULL AND  IS NULL))
  42 - filter((NVL("T_ELEMENTS"."LIBELLE",'X') NOT LIKE 'REMBOURSEMENT NC%' AND "T_ELEMENTS"."LIBELLE" NOT LIKE '%MVT MIGRATION CTX%'
              AND "T_ELEMENTS"."LIBELLE" IS NOT NULL AND (NVL("T_ELEMENTS"."MONTANT_DOS",0)-"FTR_MATCH"."LETTRREELDETTE"("T_ELEMENTS"."REFELEM","T_ELE
              MENTS"."TYPEELEM",'')>0 OR "FTR_MATCH"."DATEDERNLETTR"("T_ELEMENTS"."REFELEM","T_ELEMENTS"."TYPEELEM","T_ELEMENTS"."ABREV","T_ELEMENTS".
              "REFDOSS",'f')>TO_NUMBER(TO_CHAR(ADD_MONTHS(SYSDATE@!,(-TO_NUMBER(NVL(:B4,'1')))),'j'))) AND
              INTERNAL_FUNCTION("T_ELEMENTS"."IMX_UN_ID")))
  43 - access("T_ELEMENTS"."REFDOSS"=:B3 AND "T_ELEMENTS"."TYPEELEM"='fi')
  46 - filter("TYPELEM"="T_ELEMENTS"."TYPEELEM")
  47 - access("REFELEM"="T_ELEMENTS"."REFELEM")
  49 - filter("GD"."CATEGDOSS" LIKE 'COMPTE%')
  50 - access("GD"."REFDOSS"=:B3)
  51 - filter(("GE"."TYPE"<>'SALES ORDER' AND NVL("GE"."LIBELLE",'X')<>'TOLERANCE AMOUNT' AND "GE"."MONTANT_DOS">=0))
  52 - access("GE"."REFELEM"="T_ELEMENTS"."REFELEM")
  53 - filter(("GP_FACT"."GPIHEURE" IS NOT NULL AND "GE"."REFELEM"="GP_FACT"."GPIHEURE"))
  54 - access("GP_FACT"."REFDOSS"=:B3 AND "GP_FACT"."TYPPIECE"='FACTURE')
  55 - filter("T"."RN"=1)
  57 - filter("T_ELEMENTS"."REFDOSS"=:B3)
  62 - access("CMPT"."REFDOSS"=:B3)
  63 - access("CL"."REFDOSS"=:B3 AND "CL"."REFTYPE"=DECODE("CMPT"."CATEGDOSS",'COMPTE IMP','TC','CL'))
  64 - access("ICL"."REFINDIVIDU"="CL"."REFINDIVIDU")
  68 - access("G2"."REFELEM"=:B1)
  69 - filter("V2"."FG_PARENT_INVOICE"='O')
  70 - access("G2"."TYPE"="V2"."TYPE")
  71 - filter(:B1 IS NOT NULL)
  72 - filter("PO"."TYPPIECE"='BON DE COMMANDE')
  73 - access("PO"."REFPIECE"=:B1)
  74 - filter( IS NULL)
  78 - filter((NVL("T_ELEMENTS"."LIBELLE",'X') NOT LIKE 'REMBOURSEMENT NC%' AND "T_ELEMENTS"."LIBELLE" NOT LIKE '%MVT MIGRATION CTX%'
              AND "T_ELEMENTS"."LIBELLE" IS NOT NULL AND (NVL("T_ELEMENTS"."MONTANT_DOS",0)-"FTR_MATCH"."LETTRREELDETTE"("T_ELEMENTS"."REFELEM","T_ELE
              MENTS"."TYPEELEM",'')>0 OR "FTR_MATCH"."DATEDERNLETTR"("T_ELEMENTS"."REFELEM","T_ELEMENTS"."TYPEELEM","T_ELEMENTS"."ABREV","T_ELEMENTS".
              "REFDOSS",'f')>TO_NUMBER(TO_CHAR(ADD_MONTHS(SYSDATE@!,(-TO_NUMBER(NVL(:B4,'1')))),'j'))) AND
              INTERNAL_FUNCTION("T_ELEMENTS"."IMX_UN_ID")))
  79 - access("T_ELEMENTS"."REFDOSS"=:B3)
       filter(("T_ELEMENTS"."TYPEELEM"='tp' OR "T_ELEMENTS"."TYPEELEM"='ve'))
  81 - filter("GD"."CATEGDOSS" LIKE 'COMPTE%')
  82 - access("GD"."REFDOSS"=:B3)
  83 - filter("GE"."TYPENCAISS"=DECODE("T_ELEMENTS"."TYPEELEM",'tp','e_sadecaiss','e_savirmt'))
  84 - access("GE"."REFENCAISS"="T_ELEMENTS"."REFELEM")
  85 - filter("T"."RN"=1)
  87 - filter("T_ELEMENTS"."REFDOSS"=:B3)
  92 - access("CMPT"."REFDOSS"=:B3)
  93 - access("CL"."REFDOSS"=:B3 AND "CL"."REFTYPE"=DECODE("CMPT"."CATEGDOSS",'COMPTE IMP','TC','CL'))
  94 - access("ICL"."REFINDIVIDU"="CL"."REFINDIVIDU")
  98 - access("G2"."REFELEM"=:B1)
  99 - filter("V2"."FG_PARENT_INVOICE"='O')
 100 - access("G2"."TYPE"="V2"."TYPE")
 101 - filter( IS NULL)
 105 - filter((NVL("T_ELEMENTS"."LIBELLE",'X') NOT LIKE 'REMBOURSEMENT NC%' AND "T_ELEMENTS"."LIBELLE" NOT LIKE '%MVT MIGRATION CTX%'
              AND "T_ELEMENTS"."LIBELLE" IS NOT NULL AND (NVL("T_ELEMENTS"."MONTANT_DOS",0)-"FTR_MATCH"."LETTRREELDETTE"("T_ELEMENTS"."REFELEM","T_ELE
              MENTS"."TYPEELEM",'')>0 OR "FTR_MATCH"."DATEDERNLETTR"("T_ELEMENTS"."REFELEM","T_ELEMENTS"."TYPEELEM","T_ELEMENTS"."ABREV","T_ELEMENTS".
              "REFDOSS",'f')>TO_NUMBER(TO_CHAR(ADD_MONTHS(SYSDATE@!,(-TO_NUMBER(NVL(:B4,'1')))),'j'))) AND
              INTERNAL_FUNCTION("T_ELEMENTS"."IMX_UN_ID")))
 106 - access("T_ELEMENTS"."REFDOSS"=:B3 AND "T_ELEMENTS"."TYPEELEM"='rd')
 108 - filter("GD"."CATEGDOSS" LIKE 'COMPTE%')
 109 - access("GD"."REFDOSS"=:B3)
 110 - filter("GE"."TYPENCAISS"='rembdir')
 111 - access("GE"."REFENCAISS"="T_ELEMENTS"."REFELEM")
 112 - filter("T"."RN"=1)
 114 - filter("T_ELEMENTS"."REFDOSS"=:B3)
 119 - access("CMPT"."REFDOSS"=:B3)
 120 - access("CL"."REFDOSS"=:B3 AND "CL"."REFTYPE"=DECODE("CMPT"."CATEGDOSS",'COMPTE IMP','TC','CL'))
 121 - access("ICL"."REFINDIVIDU"="CL"."REFINDIVIDU")
 125 - access("G2"."REFELEM"=:B1)
 126 - filter("V2"."FG_PARENT_INVOICE"='O')
 127 - access("G2"."TYPE"="V2"."TYPE")
 128 - filter( IS NULL)
 134 - filter((NVL("T_ELEMENTS"."LIBELLE",'X') NOT LIKE 'REMBOURSEMENT NC%' AND "T_ELEMENTS"."LIBELLE" NOT LIKE '%MVT MIGRATION CTX%'
              AND "T_ELEMENTS"."LIBELLE" IS NOT NULL AND (NVL("T_ELEMENTS"."MONTANT_DOS",0)-"FTR_MATCH"."LETTRREELDETTE"("T_ELEMENTS"."REFELEM","T_ELE
              MENTS"."TYPEELEM","T_ELEMENTS"."ABREV")>0 OR "FTR_MATCH"."DATEDERNLETTR"("T_ELEMENTS"."REFELEM","T_ELEMENTS"."TYPEELEM","T_ELEMENTS"."AB
              REV","T_ELEMENTS"."REFDOSS",'f')>TO_NUMBER(TO_CHAR(ADD_MONTHS(SYSDATE@!,(-TO_NUMBER(NVL(:B4,'1')))),'j'))) AND
              INTERNAL_FUNCTION("T_ELEMENTS"."IMX_UN_ID")))
 135 - access("T_ELEMENTS"."REFDOSS"=:B3 AND "T_ELEMENTS"."TYPEELEM"='rg')
 136 - filter("DE_NTE" IS NOT NULL)
 137 - filter(("DE_NUM"="T_ELEMENTS"."REFELEM" AND (("DE_SEN"='R' AND "DE_DES"='T') OR ("DE_SEN"='V' AND "DE_DES"='E')) AND
              "GE"."DE_NOM"<>'PNCDB'))
 139 - filter("GD"."CATEGDOSS" LIKE 'COMPTE%')
 140 - access("GD"."REFDOSS"=:B3)
 141 - filter(("FPA"."PE_CHA" IS NOT NULL AND SUBSTR("FPA"."PE_CHA",2,1)='D'))
 142 - access("GE"."DE_NOM"="FPA"."PE_NOM")
       filter("FPA"."PE_NOM"<>'PNCDB')
 143 - filter("T"."RN"=1)
 145 - filter("T_ELEMENTS"."REFDOSS"=:B3)
 150 - access("CMPT"."REFDOSS"=:B3)
 151 - access("CL"."REFDOSS"=:B3 AND "CL"."REFTYPE"=DECODE("CMPT"."CATEGDOSS",'COMPTE IMP','TC','CL'))
 152 - access("ICL"."REFINDIVIDU"="CL"."REFINDIVIDU")
 156 - access("G2"."REFELEM"=:B1)
 157 - filter("V2"."FG_PARENT_INVOICE"='O')
 158 - access("G2"."TYPE"="V2"."TYPE")



-- SQL3

Plan hash value: 30422097
----------------------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                          | Name                         | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers |
----------------------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                                   |                              |      1 |        |    48 (100)|   1570 |00:00:02.90 |   65031 |
|   1 |  SORT AGGREGATE                                    |                              |   1570 |      1 |            |   1570 |00:00:00.06 |    2048 |
|   2 |   NESTED LOOPS                                     |                              |   1570 |      1 |     4   (0)|      0 |00:00:00.06 |    2048 |
|   3 |    NESTED LOOPS                                    |                              |   1570 |      1 |     4   (0)|      0 |00:00:00.05 |    2048 |
|   4 |     NESTED LOOPS                                   |                              |   1570 |      1 |     3   (0)|      0 |00:00:00.05 |    2048 |
|   5 |      NESTED LOOPS                                  |                              |   1570 |      1 |     2   (0)|      0 |00:00:00.05 |    2048 |
|   6 |       TABLE ACCESS BY INDEX ROWID                  | G_ELEMFI                     |   1570 |      1 |     1   (0)|   1570 |00:00:00.03 |    1729 |
|*  7 |        INDEX UNIQUE SCAN                           | EFI_REFELEM                  |   1570 |      1 |     1   (0)|   1570 |00:00:00.01 |     159 |
|*  8 |       INDEX RANGE SCAN                             | AK_KEY_2_G_ELEMFI            |   1570 |      1 |     1   (0)|      0 |00:00:00.01 |     319 |
|*  9 |      TABLE ACCESS BY INDEX ROWID BATCHED           | G_PIECE                      |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 10 |       INDEX RANGE SCAN                             | PIE_REFPIECE                 |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 11 |     INDEX RANGE SCAN                               | G_OUTPMT_EXEC_REFER_IDX      |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 12 |    TABLE ACCESS BY INDEX ROWID                     | G_OUTPMT_EXEC                |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|  13 |  SORT AGGREGATE                                    |                              |   1570 |      1 |            |   1570 |00:00:30.87 |    3052K|
|* 14 |   TABLE ACCESS BY INDEX ROWID BATCHED              | NAM_ECR_COMPTA_BAK           |   1570 |      1 |     3   (0)|    158 |00:00:30.85 |    3052K|
|* 15 |    INDEX SKIP SCAN                                 | NEC_BAK_RECONCIL_IDX         |   1570 |    468 |     2   (0)|     16M|00:00:08.28 |     197K|
|* 16 |  VIEW                                              |                              |      1 |      4 |    41   (3)|   1570 |00:00:02.90 |   65031 |
|* 17 |   COUNT STOPKEY                                    |                              |      1 |        |            |   1570 |00:00:02.88 |   65031 |
|  18 |    VIEW                                            |                              |      1 |      4 |    41   (3)|   1570 |00:00:02.88 |   65031 |
|  19 |     WINDOW SORT                                    |                              |      1 |      4 |    41   (3)|   1570 |00:00:00.53 |   33631 |
|  20 |      VIEW                                          |                              |      1 |      4 |    41   (3)|   1570 |00:00:00.50 |   33631 |
|  21 |       SORT UNIQUE                                  |                              |      1 |      4 |    41   (3)|   1570 |00:00:00.50 |   33631 |
|  22 |        UNION-ALL                                   |                              |      1 |        |            |   1570 |00:00:00.49 |   33631 |
|  23 |         SORT GROUP BY                              |                              |      1 |      1 |            |      1 |00:00:00.01 |       1 |
|  24 |          NESTED LOOPS                              |                              |      1 |      1 |     4   (0)|      0 |00:00:00.01 |       1 |
|  25 |           NESTED LOOPS                             |                              |      1 |      1 |     4   (0)|      0 |00:00:00.01 |       1 |
|  26 |            NESTED LOOPS                            |                              |      1 |      1 |     3   (0)|      0 |00:00:00.01 |       1 |
|  27 |             NESTED LOOPS                           |                              |      1 |      1 |     2   (0)|      0 |00:00:00.01 |       1 |
|  28 |              TABLE ACCESS BY INDEX ROWID BATCHED   | G_ELEMFI                     |      1 |      1 |     1   (0)|      0 |00:00:00.01 |       1 |
|* 29 |               INDEX FULL SCAN                      | G_ELEMFI_REFPIECE_IDX        |      1 |      1 |     1   (0)|      0 |00:00:00.01 |       1 |
|  30 |              TABLE ACCESS BY INDEX ROWID BATCHED   | G_PIECE                      |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 31 |               INDEX RANGE SCAN                     | PIE_REFPIECE                 |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 32 |             TABLE ACCESS BY INDEX ROWID BATCHED    | G_ELEMFI                     |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 33 |              INDEX RANGE SCAN                      | G_ELEMFI$REFDOSS_REF_CREANCE |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 34 |            INDEX RANGE SCAN                        | VEN_ENCAIS                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 35 |           TABLE ACCESS BY INDEX ROWID              | G_VENELEM                    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 36 |         FILTER                                     |                              |      1 |        |            |   1570 |00:00:00.30 |   22865 |
|  37 |          NESTED LOOPS OUTER                        |                              |      1 |      1 |     8   (0)|   1570 |00:00:00.28 |   16328 |
|  38 |           NESTED LOOPS OUTER                       |                              |      1 |      1 |     5   (0)|   1570 |00:00:00.25 |   16295 |
|  39 |            NESTED LOOPS                            |                              |      1 |      1 |     4   (0)|   1570 |00:00:00.23 |   11760 |
|  40 |             MERGE JOIN CARTESIAN                   |                              |      1 |      1 |     3   (0)|   1570 |00:00:00.22 |   11286 |
|  41 |              NESTED LOOPS OUTER                    |                              |      1 |      1 |     2   (0)|   1570 |00:00:00.21 |   11283 |
|* 42 |               TABLE ACCESS BY INDEX ROWID BATCHED  | T_ELEMENTS                   |      1 |      1 |     1   (0)|   1570 |00:00:00.21 |   11279 |
|* 43 |                INDEX RANGE SCAN                    | ELE_DOSS_TYP_ASSOC_LIB       |      1 |      1 |     1   (0)|   2014 |00:00:00.01 |      17 |
|  44 |               VIEW PUSHED PREDICATE                | VW_SSQ_1                     |   1570 |      1 |     1   (0)|      1 |00:00:00.01 |       4 |
|  45 |                SORT GROUP BY                       |                              |   1570 |      1 |     1   (0)|      1 |00:00:00.01 |       4 |
|* 46 |                 TABLE ACCESS BY INDEX ROWID BATCHED| G_PRELETTRAGE                |   1570 |      1 |     1   (0)|      1 |00:00:00.01 |       4 |
|* 47 |                  INDEX RANGE SCAN                  | G_PREL_ELEM                  |   1570 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |
|  48 |              BUFFER SORT                           |                              |   1570 |      1 |     2   (0)|   1570 |00:00:00.01 |       3 |
|* 49 |               TABLE ACCESS BY INDEX ROWID          | G_DOSSIER                    |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |
|* 50 |                INDEX UNIQUE SCAN                   | DOS_REFDOSS                  |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       2 |
|* 51 |             TABLE ACCESS BY INDEX ROWID            | G_ELEMFI                     |   1570 |      1 |     1   (0)|   1570 |00:00:00.01 |     474 |
|* 52 |              INDEX UNIQUE SCAN                     | EFI_REFELEM                  |   1570 |      1 |     1   (0)|   1570 |00:00:00.01 |     299 |
|* 53 |            TABLE ACCESS BY INDEX ROWID BATCHED     | G_PIECE                      |   1570 |      1 |     1   (0)|   1570 |00:00:00.02 |    4535 |
|* 54 |             INDEX RANGE SCAN                       | GP_GRTYPE_MT_DT              |   1570 |      1 |     1   (0)|   1570 |00:00:00.01 |     866 |
|* 55 |           VIEW PUSHED PREDICATE                    |                              |   1570 |      1 |     3   (0)|   1570 |00:00:00.03 |      33 |
|  56 |            WINDOW BUFFER                           |                              |   1570 |      1 |     3   (0)|   1570 |00:00:00.03 |      33 |
|* 57 |             FILTER                                 |                              |   1570 |        |            |   1570 |00:00:00.01 |      33 |
|  58 |              NESTED LOOPS                          |                              |   1570 |      1 |     3   (0)|   1570 |00:00:00.01 |      33 |
|  59 |               NESTED LOOPS                         |                              |   1570 |      1 |     3   (0)|   1570 |00:00:00.01 |      32 |
|  60 |                NESTED LOOPS                        |                              |   1570 |      1 |     2   (0)|   1570 |00:00:00.01 |      18 |
|  61 |                 TABLE ACCESS BY INDEX ROWID        | G_DOSSIER                    |   1570 |      1 |     1   (0)|   1570 |00:00:00.01 |      10 |
|* 62 |                  INDEX UNIQUE SCAN                 | DOS_REFDOSS                  |   1570 |      1 |     1   (0)|   1570 |00:00:00.01 |       9 |
|* 63 |                 INDEX RANGE SCAN                   | INT_REFDOSS                  |   1570 |      1 |     1   (0)|   1570 |00:00:00.01 |       8 |
|* 64 |                INDEX UNIQUE SCAN                   | IND_REFINDIV                 |   1570 |      1 |     1   (0)|   1570 |00:00:00.01 |      14 |
|  65 |               TABLE ACCESS BY INDEX ROWID          | G_INDIVIDU                   |   1570 |      1 |     1   (0)|   1570 |00:00:00.01 |       1 |
|  66 |          NESTED LOOPS                              |                              |   1570 |      1 |     2   (0)|      0 |00:00:00.01 |    6537 |
|  67 |           TABLE ACCESS BY INDEX ROWID              | G_ELEMFI                     |   1570 |      1 |     1   (0)|   1570 |00:00:00.01 |    3397 |
|* 68 |            INDEX UNIQUE SCAN                       | EFI_REFELEM                  |   1570 |      1 |     1   (0)|   1570 |00:00:00.01 |    1827 |
|* 69 |           TABLE ACCESS BY INDEX ROWID BATCHED      | V_ELEMFI                     |   1570 |      1 |     1   (0)|      0 |00:00:00.01 |    3140 |
|* 70 |            INDEX RANGE SCAN                        | VF_TYPE_FINANCING            |   1570 |      1 |     1   (0)|   1570 |00:00:00.01 |    1570 |
|* 71 |          FILTER                                    |                              |      1 |        |            |      0 |00:00:00.01 |       0 |
|* 72 |           TABLE ACCESS BY INDEX ROWID BATCHED      | G_PIECE                      |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 73 |            INDEX RANGE SCAN                        | PIE_REFPIECE                 |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 74 |         FILTER                                     |                              |      1 |        |            |      0 |00:00:00.01 |       6 |
|  75 |          NESTED LOOPS OUTER                        |                              |      1 |      1 |     6   (0)|      0 |00:00:00.01 |       6 |
|  76 |           NESTED LOOPS                             |                              |      1 |      1 |     3   (0)|      0 |00:00:00.01 |       6 |
|  77 |            MERGE JOIN CARTESIAN                    |                              |      1 |      1 |     2   (0)|      0 |00:00:00.01 |       6 |
|  78 |             INLIST ITERATOR                        |                              |      1 |        |            |      0 |00:00:00.01 |       6 |
|* 79 |              TABLE ACCESS BY INDEX ROWID BATCHED   | T_ELEMENTS                   |      2 |      1 |     1   (0)|      0 |00:00:00.01 |       6 |
|* 80 |               INDEX RANGE SCAN                     | ELE_DOSS_TYP_ASSOC_LIB       |      2 |      1 |     1   (0)|      0 |00:00:00.01 |       6 |
|  81 |             BUFFER SORT                            |                              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 82 |              TABLE ACCESS BY INDEX ROWID           | G_DOSSIER                    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 83 |               INDEX UNIQUE SCAN                    | DOS_REFDOSS                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 84 |            TABLE ACCESS BY INDEX ROWID             | G_ENCAISSEMENT               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 85 |             INDEX UNIQUE SCAN                      | REFENCAISS                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 86 |           VIEW PUSHED PREDICATE                    |                              |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|  87 |            WINDOW BUFFER                           |                              |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|* 88 |             FILTER                                 |                              |      0 |        |            |      0 |00:00:00.01 |       0 |
|  89 |              NESTED LOOPS                          |                              |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|  90 |               NESTED LOOPS                         |                              |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|  91 |                NESTED LOOPS                        |                              |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |
|  92 |                 TABLE ACCESS BY INDEX ROWID        | G_DOSSIER                    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 93 |                  INDEX UNIQUE SCAN                 | DOS_REFDOSS                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 94 |                 INDEX RANGE SCAN                   | INT_REFDOSS                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 95 |                INDEX UNIQUE SCAN                   | IND_REFINDIV                 |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|  96 |               TABLE ACCESS BY INDEX ROWID          | G_INDIVIDU                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|  97 |          NESTED LOOPS                              |                              |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |
|  98 |           TABLE ACCESS BY INDEX ROWID              | G_ELEMFI                     |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 99 |            INDEX UNIQUE SCAN                       | EFI_REFELEM                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|*100 |           TABLE ACCESS BY INDEX ROWID BATCHED      | V_ELEMFI                     |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|*101 |            INDEX RANGE SCAN                        | VF_TYPE_FINANCING            |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|*102 |         FILTER                                     |                              |      1 |        |            |      0 |00:00:00.01 |       3 |
| 103 |          NESTED LOOPS OUTER                        |                              |      1 |      1 |     6   (0)|      0 |00:00:00.01 |       3 |
| 104 |           NESTED LOOPS                             |                              |      1 |      1 |     3   (0)|      0 |00:00:00.01 |       3 |
| 105 |            MERGE JOIN CARTESIAN                    |                              |      1 |      1 |     2   (0)|      0 |00:00:00.01 |       3 |
|*106 |             TABLE ACCESS BY INDEX ROWID BATCHED    | T_ELEMENTS                   |      1 |      1 |     1   (0)|      0 |00:00:00.01 |       3 |
|*107 |              INDEX RANGE SCAN                      | ELE_DOSS_TYP_ASSOC_LIB       |      1 |      1 |     1   (0)|      0 |00:00:00.01 |       3 |
| 108 |             BUFFER SORT                            |                              |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|*109 |              TABLE ACCESS BY INDEX ROWID           | G_DOSSIER                    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|*110 |               INDEX UNIQUE SCAN                    | DOS_REFDOSS                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|*111 |            TABLE ACCESS BY INDEX ROWID             | G_ENCAISSEMENT               |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|*112 |             INDEX UNIQUE SCAN                      | REFENCAISS                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|*113 |           VIEW PUSHED PREDICATE                    |                              |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
| 114 |            WINDOW BUFFER                           |                              |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*115 |             FILTER                                 |                              |      0 |        |            |      0 |00:00:00.01 |       0 |
| 116 |              NESTED LOOPS                          |                              |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
| 117 |               NESTED LOOPS                         |                              |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
| 118 |                NESTED LOOPS                        |                              |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |
| 119 |                 TABLE ACCESS BY INDEX ROWID        | G_DOSSIER                    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|*120 |                  INDEX UNIQUE SCAN                 | DOS_REFDOSS                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|*121 |                 INDEX RANGE SCAN                   | INT_REFDOSS                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|*122 |                INDEX UNIQUE SCAN                   | IND_REFINDIV                 |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
| 123 |               TABLE ACCESS BY INDEX ROWID          | G_INDIVIDU                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
| 124 |          NESTED LOOPS                              |                              |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |
| 125 |           TABLE ACCESS BY INDEX ROWID              | G_ELEMFI                     |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|*126 |            INDEX UNIQUE SCAN                       | EFI_REFELEM                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|*127 |           TABLE ACCESS BY INDEX ROWID BATCHED      | V_ELEMFI                     |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|*128 |            INDEX RANGE SCAN                        | VF_TYPE_FINANCING            |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|*129 |         FILTER                                     |                              |      1 |        |            |      0 |00:00:00.01 |       3 |
| 130 |          NESTED LOOPS OUTER                        |                              |      1 |      1 |     7   (0)|      0 |00:00:00.01 |       3 |
| 131 |           MERGE JOIN CARTESIAN                     |                              |      1 |      1 |     4   (0)|      0 |00:00:00.01 |       3 |
| 132 |            NESTED LOOPS                            |                              |      1 |      1 |     3   (0)|      0 |00:00:00.01 |       3 |
| 133 |             NESTED LOOPS                           |                              |      1 |      1 |     3   (0)|      0 |00:00:00.01 |       3 |
| 134 |              NESTED LOOPS                          |                              |      1 |      1 |     2   (0)|      0 |00:00:00.01 |       3 |
|*135 |               TABLE ACCESS BY INDEX ROWID BATCHED  | T_ELEMENTS                   |      1 |      1 |     1   (0)|      0 |00:00:00.01 |       3 |
|*136 |                INDEX RANGE SCAN                    | ELE_DOSS_TYP_ASSOC_LIB       |      1 |      1 |     1   (0)|      0 |00:00:00.01 |       3 |
|*137 |               TABLE ACCESS BY INDEX ROWID BATCHED  | F_DETENR                     |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|*138 |                INDEX FULL SCAN                     | DETENR_NTE                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|*139 |              INDEX UNIQUE SCAN                     | PARENR_CL1                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|*140 |             TABLE ACCESS BY INDEX ROWID            | F_PARENR                     |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
| 141 |            BUFFER SORT                             |                              |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*142 |             TABLE ACCESS BY INDEX ROWID            | G_DOSSIER                    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|*143 |              INDEX UNIQUE SCAN                     | DOS_REFDOSS                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|*144 |           VIEW PUSHED PREDICATE                    |                              |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
| 145 |            WINDOW BUFFER                           |                              |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
|*146 |             FILTER                                 |                              |      0 |        |            |      0 |00:00:00.01 |       0 |
| 147 |              NESTED LOOPS                          |                              |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
| 148 |               NESTED LOOPS                         |                              |      0 |      1 |     3   (0)|      0 |00:00:00.01 |       0 |
| 149 |                NESTED LOOPS                        |                              |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |
| 150 |                 TABLE ACCESS BY INDEX ROWID        | G_DOSSIER                    |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|*151 |                  INDEX UNIQUE SCAN                 | DOS_REFDOSS                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|*152 |                 INDEX RANGE SCAN                   | INT_REFDOSS                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|*153 |                INDEX UNIQUE SCAN                   | IND_REFINDIV                 |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
| 154 |               TABLE ACCESS BY INDEX ROWID          | G_INDIVIDU                   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
| 155 |          NESTED LOOPS                              |                              |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |
| 156 |           TABLE ACCESS BY INDEX ROWID              | G_ELEMFI                     |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|*157 |            INDEX UNIQUE SCAN                       | EFI_REFELEM                  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|*158 |           TABLE ACCESS BY INDEX ROWID BATCHED      | V_ELEMFI                     |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|*159 |            INDEX RANGE SCAN                        | VF_TYPE_FINANCING            |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
----------------------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   7 - access("E"."REFELEM"=:B1)
   8 - access("A"."REFFACTURE"="E"."REFPIECE2")
   9 - filter("B"."GPIRESSORT" IS NOT NULL)
  10 - access("B"."REFPIECE"="A"."REFAGGR")
  11 - access("O"."REFER"="B"."GPIRESSORT")
  12 - filter("O"."DTEXECUTION_DT" IS NOT NULL)
  14 - filter(("AGGR"."EXTREF19"=:B1 AND "AGGR"."CODEOPER"='MATCH_PMT'))
  15 - access("AGGR"."STATUS_RECONCIL"='REJECTED')
       filter("AGGR"."STATUS_RECONCIL"='REJECTED')
  16 - filter("RNUM">=:B6)
  17 - filter(ROWNUM<=:B5)
  29 - filter("GE"."REFPIECE3" IS NOT NULL)
  31 - access("GP"."REFPIECE"="GE"."REFPIECE3")
  32 - filter("POI"."TYPE"='PO INVOICED')
  33 - access("POI"."REFDOSS"="GE"."REFDOSS" AND "POI"."REF_CREANCE"="GE"."REFELEM")
       filter("POI"."REF_CREANCE" IS NOT NULL)
  34 - access("POI"."REFELEM"="V"."REFENCAISS")
  35 - filter(("V"."TYPENCAISS"='fi' AND "GE"."REFELEM"="V"."REFELEM" AND "V"."TYPELEM"='fi'))
  36 - filter(( IS NULL AND  IS NULL))
  42 - filter((NVL("T_ELEMENTS"."MONTANT_DOS",0)-"FTR_MATCH"."LETTRREELDETTE"("T_ELEMENTS"."REFELEM","T_ELEMENTS"."TYPEELEM",'')>0 OR
              "FTR_MATCH"."DATEDERNLETTR"("T_ELEMENTS"."REFELEM","T_ELEMENTS"."TYPEELEM","T_ELEMENTS"."ABREV","T_ELEMENTS"."REFDOSS",'f')>TO_NUMBER(TO_CHAR(ADD_
              MONTHS(SYSDATE@!,(-NVL(:B4,1))),'j'))))
  43 - access("T_ELEMENTS"."REFDOSS"=:B3 AND "T_ELEMENTS"."TYPEELEM"='fi')
       filter((NVL("T_ELEMENTS"."LIBELLE",'X') NOT LIKE 'REMBOURSEMENT NC%' AND "T_ELEMENTS"."LIBELLE" NOT LIKE '%MVT MIGRATION CTX%' AND
              "T_ELEMENTS"."LIBELLE" IS NOT NULL))
  46 - filter("TYPELEM"="T_ELEMENTS"."TYPEELEM")
  47 - access("REFELEM"="T_ELEMENTS"."REFELEM")
  49 - filter("GD"."CATEGDOSS" LIKE 'COMPTE%')
  50 - access("GD"."REFDOSS"=:B3)
  51 - filter(("GE"."TYPE"<>'SALES ORDER' AND NVL("GE"."LIBELLE",'X')<>'TOLERANCE AMOUNT' AND "GE"."MONTANT_DOS">=0))
  52 - access("GE"."REFELEM"="T_ELEMENTS"."REFELEM")
  53 - filter("GP_FACT"."REFDOSS"=:B3)
  54 - access("GP_FACT"."TYPPIECE"='FACTURE' AND "GE"."REFELEM"="GP_FACT"."GPIHEURE")
       filter("GP_FACT"."GPIHEURE" IS NOT NULL)
  55 - filter("T"."RN"=1)
  57 - filter("T_ELEMENTS"."REFDOSS"=:B3)
  62 - access("CMPT"."REFDOSS"=:B3)
  63 - access("CL"."REFDOSS"=:B3 AND "CL"."REFTYPE"=DECODE("CMPT"."CATEGDOSS",'COMPTE IMP','TC','CL'))
  64 - access("ICL"."REFINDIVIDU"="CL"."REFINDIVIDU")
  68 - access("G2"."REFELEM"=:B1)
  69 - filter("V2"."FG_PARENT_INVOICE"='O')
  70 - access("G2"."TYPE"="V2"."TYPE")
  71 - filter(:B1 IS NOT NULL)
  72 - filter("PO"."TYPPIECE"='BON DE COMMANDE')
  73 - access("PO"."REFPIECE"=:B1)
  74 - filter( IS NULL)
  79 - filter((NVL("T_ELEMENTS"."MONTANT_DOS",0)-"FTR_MATCH"."LETTRREELDETTE"("T_ELEMENTS"."REFELEM","T_ELEMENTS"."TYPEELEM",'')>0 OR
              "FTR_MATCH"."DATEDERNLETTR"("T_ELEMENTS"."REFELEM","T_ELEMENTS"."TYPEELEM","T_ELEMENTS"."ABREV","T_ELEMENTS"."REFDOSS",'f')>TO_NUMBER(TO_CHAR(ADD_
              MONTHS(SYSDATE@!,(-NVL(:B4,1))),'j'))))
  80 - access("T_ELEMENTS"."REFDOSS"=:B3 AND (("T_ELEMENTS"."TYPEELEM"='tp' OR "T_ELEMENTS"."TYPEELEM"='ve')))
       filter((NVL("T_ELEMENTS"."LIBELLE",'X') NOT LIKE 'REMBOURSEMENT NC%' AND "T_ELEMENTS"."LIBELLE" NOT LIKE '%MVT MIGRATION CTX%' AND
              "T_ELEMENTS"."LIBELLE" IS NOT NULL))
  82 - filter("GD"."CATEGDOSS" LIKE 'COMPTE%')
  83 - access("GD"."REFDOSS"=:B3)
  84 - filter("GE"."TYPENCAISS"=DECODE("T_ELEMENTS"."TYPEELEM",'tp','e_sadecaiss','e_savirmt'))
  85 - access("GE"."REFENCAISS"="T_ELEMENTS"."REFELEM")
  86 - filter("T"."RN"=1)
  88 - filter("T_ELEMENTS"."REFDOSS"=:B3)
  93 - access("CMPT"."REFDOSS"=:B3)
  94 - access("CL"."REFDOSS"=:B3 AND "CL"."REFTYPE"=DECODE("CMPT"."CATEGDOSS",'COMPTE IMP','TC','CL'))
  95 - access("ICL"."REFINDIVIDU"="CL"."REFINDIVIDU")
  99 - access("G2"."REFELEM"=:B1)
 100 - filter("V2"."FG_PARENT_INVOICE"='O')
 101 - access("G2"."TYPE"="V2"."TYPE")
 102 - filter( IS NULL)
 106 - filter((NVL("T_ELEMENTS"."MONTANT_DOS",0)-"FTR_MATCH"."LETTRREELDETTE"("T_ELEMENTS"."REFELEM","T_ELEMENTS"."TYPEELEM",'')>0 OR
              "FTR_MATCH"."DATEDERNLETTR"("T_ELEMENTS"."REFELEM","T_ELEMENTS"."TYPEELEM","T_ELEMENTS"."ABREV","T_ELEMENTS"."REFDOSS",'f')>TO_NUMBER(TO_CHAR(ADD_
              MONTHS(SYSDATE@!,(-NVL(:B4,1))),'j'))))
 107 - access("T_ELEMENTS"."REFDOSS"=:B3 AND "T_ELEMENTS"."TYPEELEM"='rd')
       filter((NVL("T_ELEMENTS"."LIBELLE",'X') NOT LIKE 'REMBOURSEMENT NC%' AND "T_ELEMENTS"."LIBELLE" NOT LIKE '%MVT MIGRATION CTX%' AND
              "T_ELEMENTS"."LIBELLE" IS NOT NULL))
 109 - filter("GD"."CATEGDOSS" LIKE 'COMPTE%')
 110 - access("GD"."REFDOSS"=:B3)
 111 - filter("GE"."TYPENCAISS"='rembdir')
 112 - access("GE"."REFENCAISS"="T_ELEMENTS"."REFELEM")
 113 - filter("T"."RN"=1)
 115 - filter("T_ELEMENTS"."REFDOSS"=:B3)
 120 - access("CMPT"."REFDOSS"=:B3)
 121 - access("CL"."REFDOSS"=:B3 AND "CL"."REFTYPE"=DECODE("CMPT"."CATEGDOSS",'COMPTE IMP','TC','CL'))
 122 - access("ICL"."REFINDIVIDU"="CL"."REFINDIVIDU")
 126 - access("G2"."REFELEM"=:B1)
 127 - filter("V2"."FG_PARENT_INVOICE"='O')
 128 - access("G2"."TYPE"="V2"."TYPE")
 129 - filter( IS NULL)
 135 - filter((NVL("T_ELEMENTS"."MONTANT_DOS",0)-"FTR_MATCH"."LETTRREELDETTE"("T_ELEMENTS"."REFELEM","T_ELEMENTS"."TYPEELEM","T_ELEMENTS"."ABREV")
              >0 OR "FTR_MATCH"."DATEDERNLETTR"("T_ELEMENTS"."REFELEM","T_ELEMENTS"."TYPEELEM","T_ELEMENTS"."ABREV","T_ELEMENTS"."REFDOSS",'f')>TO_NUMBER(TO_CHA
              R(ADD_MONTHS(SYSDATE@!,(-NVL(:B4,1))),'j'))))
 136 - access("T_ELEMENTS"."REFDOSS"=:B3 AND "T_ELEMENTS"."TYPEELEM"='rg')
       filter((NVL("T_ELEMENTS"."LIBELLE",'X') NOT LIKE 'REMBOURSEMENT NC%' AND "T_ELEMENTS"."LIBELLE" NOT LIKE '%MVT MIGRATION CTX%' AND
              "T_ELEMENTS"."LIBELLE" IS NOT NULL))
 137 - filter(("DE_NUM"="T_ELEMENTS"."REFELEM" AND (("DE_SEN"='R' AND "DE_DES"='T') OR ("DE_SEN"='V' AND "DE_DES"='E')) AND
              "GE"."DE_NOM"<>'PNCDB'))
 138 - filter("DE_NTE" IS NOT NULL)
 139 - access("GE"."DE_NOM"="FPA"."PE_NOM")
       filter("FPA"."PE_NOM"<>'PNCDB')
 140 - filter(("FPA"."PE_CHA" IS NOT NULL AND SUBSTR("FPA"."PE_CHA",2,1)='D'))
 142 - filter("GD"."CATEGDOSS" LIKE 'COMPTE%')
 143 - access("GD"."REFDOSS"=:B3)
 144 - filter("T"."RN"=1)
 146 - filter("T_ELEMENTS"."REFDOSS"=:B3)
 151 - access("CMPT"."REFDOSS"=:B3)
 152 - access("CL"."REFDOSS"=:B3 AND "CL"."REFTYPE"=DECODE("CMPT"."CATEGDOSS",'COMPTE IMP','TC','CL'))
 153 - access("ICL"."REFINDIVIDU"="CL"."REFINDIVIDU")
 157 - access("G2"."REFELEM"=:B1)
 158 - filter("V2"."FG_PARENT_INVOICE"='O')
 159 - access("G2"."TYPE"="V2"."TYPE") 
*/
/********************************New Metrics***************************************/

/********************************Index statistics**********************************/

/********************************Other SQLs****************************************/          
/*

*/ 
/********************************Other SQLs****************************************/              
