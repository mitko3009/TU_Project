/********************************************************************************
*********       E-mail subject: EFDE2WEB-1104
*********             Instance: UAT2
*********          Description: 
Problem:
Searching for alerts on some contract takes more than 4 minutes.

Analysis:
The slow service call from the HAR file was not found in the BE logs, so I tried to search in the ASH what is responsible for the 4 minutes delay based on the time period in the HAR file.
After my analysis, I found session for this period with client_id = inacheva ( in the attached video in the task it can be seen that the user, who tests is with user name Irina Nancheva, so I thing that is what we are looking for ).
The TOP SQL in this session, which is responsible for 100% of the time is ats3wqwa005us. The problem in it is that it is searching in table g_dossier GD_CONTRAT for ancrefdoss with % in front, which is not recommended from P&T.
Could you please remove the % in front when searching?

Suggestion:
Please change the query as it is show in the New SQL section below.

*********               SQL_ID: ats3wqwa005us
*********      Program/Package: 
*********              Request: Irina Nacheva
*********               Author: Dimitar Dimitrov
********* Received e-mail date: 12/08/2024
*********      Resolution date: 15/08/2024
*********  Trace old file here: \\epox\specifs\performance\tmp\
*********  Trace new file here:
***********************************************************************************/

/********************************OLD SQL*******************************************/

var B1 VARCHAR2(32);
EXEC :B1 := 'ES01305';
var B2 NUMBER;
EXEC :B2 := 16;
var B3 NUMBER;
EXEC :B3 := 1;

SELECT *
  FROM (SELECT /*+ first_rows(16)*/
         foo.*, ROWNUM rnum
          FROM (SELECT montant_mvt amount,
                       refpiece    docRef,
                       refdoss     clAccount,
                       refext      invNumber,
                       nom         debtorName,
                       devise_mvt  currency,
                       ancrefdoss  cntNumber,
                       refelem     refElem,
                       clDbAccount clDbAccount
                  FROM (SELECT 'NO COLOR' AS color,
                               GD_DECOMPTE.refdoss,
                               GD_CONTRAT.ancrefdoss,
                               GD_COMPTE.refdoss clDbAccount,
                               GP_FACT.refpiece,
                               ELEMFI.refelem,
                               ELEMFI.refext,
                               ELEMFI.montant_mvt,
                               GD_COMPTE.nom,
                               ELEMFI.devise_mvt
                          FROM g_dossier GD_DECOMPTE,
                               g_dossier GD_CONTRAT,
                               g_piece GP_FACT,
                               g_elemfi ELEMFI,
                               (SELECT GD_COMPTE.reflot,
                                       GD_COMPTE.refdoss,
                                       gi.nom
                                  FROM g_dossier      GD_COMPTE,
                                       t_intervenants TI_COMPTE,
                                       g_individu     GI
                                 WHERE TI_COMPTE.refdoss = GD_COMPTE.refdoss
                                   AND GD_COMPTE.categdoss LIKE 'COMPTE%'
                                   AND gi.refindividu = TI_COMPTE.refindividu
                                   AND TI_COMPTE.reftype = 'DB') GD_COMPTE
                         WHERE 1 = 1
                           AND GD_DECOMPTE.reflot = GD_CONTRAT.refdoss
                           AND GD_CONTRAT.categdoss LIKE 'CONTRAT%'
                           AND GD_COMPTE.reflot = GD_DECOMPTE.refdoss
                           AND GP_FACT.refdoss = GD_COMPTE.refdoss
                           AND GP_FACT.typpiece = 'FACTURE'
                           AND GP_FACT.gpiheure = ELEMFI.refelem
                           AND ELEMFI.dttraite_dt IS NULL
                           AND 0 <>
                               DECODE(GP_FACT.dt10,
                                      NULL,
                                      GP_FACT.mt24,
                                      ftr_util.SoldeF_DCPT(ELEMFI.refelem))
                           AND EXISTS ( SELECT 1
                                          FROM eligib_ctrl
                                         WHERE dt_resolve IS NULL
                                           AND reffacture = GP_FACT.refpiece
                                           AND ROWNUM = 1 )
                           AND GD_CONTRAT.ancrefdoss LIKE '%' || :B1 || '%')
                 WHERE 1 = 1
                 ORDER BY refelem, refelem) foo
         WHERE ROWNUM <= :B2)
 WHERE 1 = 1
   AND rnum >= :B3;
/********************************OLD SQL*******************************************/
/********************************OLD Metrics***************************************/
/*

MODULE                           PROGRAM                                            CLIENT_ID       SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM     TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- -------------------------------------------------- --------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
msgq_pilote                      msg_queue                                                                         264992408        847       3158 db file scattered re 2024/08/12 15:47:04  2024/08/12 15:56:44      52                    1 +000000000 00:09:40.472 23%
msgq_chkcess                     msg_q03                                                                                            210      31617 ON CPU               2024/08/12 15:47:04  2024/08/12 15:58:54      47               195979 +000000000 00:11:50.549 21%
484D1A4168F0449D1BF42A62072C4231 iMX BE                                             inacheva        ats3wqwa005us  522901675                       db file sequential r 2024/08/12 15:47:14  2024/08/12 15:58:04      32                    2 +000000000 00:10:50.515 14%
484D1A4168F0449D1BF42A62072C4231 iMX BE                                             inacheva        ats3wqwa005us  522901675                       ON CPU               2024/08/12 15:47:04  2024/08/12 15:57:04      18                    2 +000000000 00:10:00.487 8%
bmx_alibatch                     bmx_alibatch                                                       crcgjv2y3kyrt  601495094       1471       3460 ON CPU               2024/08/12 15:47:54  2024/08/12 15:58:54      18                  258 +000000000 00:11:00.509 8%
msgq_chkcess                     msg_q03                                                                                   0        210      31617 log file sync        2024/08/12 15:51:04  2024/08/12 15:54:34      15                      +000000000 00:03:30.168 7%
SQL*Plus                         sqlplus                                                                                                           ON CPU               2024/08/12 15:47:04  2024/08/12 15:58:34      14                  154 +000000000 00:11:30.538 6%
msgq_pilote                      msg_queue                                                                                          847       3158 ON CPU               2024/08/12 15:47:24  2024/08/12 15:57:54      12                    4 +000000000 00:10:30.500 5%
msgq_calfidec                    msg_q02                                                                                             18      27703 ON CPU               2024/08/12 15:58:14  2024/08/12 15:58:34       3                 1246 +000000000 00:00:20.012 1%
sqlplus                          sqlplus                                                                                   0                       log file sync        2024/08/12 15:52:44  2024/08/12 15:54:14       3                      +000000000 00:01:30.078 1%
prm_pack                         msg_queue                                                                                          847       3158 ON CPU               2024/08/12 15:57:04  2024/08/12 15:57:14       2                    1 +000000000 00:00:10.004 1%
bmx_alibatch                     bmx_alibatch                                                                              0       1471       3460 log file sync        2024/08/12 15:51:54  2024/08/12 15:53:44       2                      +000000000 00:01:50.086 1%
msgq                             msg_q02                                                                                             18      27703 ON CPU               2024/08/12 15:55:44  2024/08/12 15:58:54       2                  927 +000000000 00:03:10.128 1%
msgq_chkcess                     msg_q03                                                            7unuvjx2tjj48          0        210      31617 db file sequential r 2024/08/12 15:50:34  2024/08/12 15:50:34       1                    1 +000000000 00:00:00.000 0%
msgq_pilote                      msg_queue                                                                                 0        847       3158 log file sync        2024/08/12 15:58:04  2024/08/12 15:58:04       1                      +000000000 00:00:00.000 0%
sqlplus                          sqlplus                                                            f0h5rpzmhju11  461584377       1062      17253 ON CPU               2024/08/12 15:55:44  2024/08/12 15:55:44       1                    1 +000000000 00:00:00.000 0%
 
 


MODULE                           PROGRAM                                            CLIENT_ID       SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM     TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- -------------------------------------------------- --------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
484D1A4168F0449D1BF42A62072C4231 iMX BE                                             inacheva        ats3wqwa005us  522901675                       db file sequential r 2024/08/12 15:47:14  2024/08/12 15:58:04      32                    2 +000000000 00:10:50.515 64%
484D1A4168F0449D1BF42A62072C4231 iMX BE                                             inacheva        ats3wqwa005us  522901675                       ON CPU               2024/08/12 15:47:04  2024/08/12 15:57:04      18                    2 +000000000 00:10:00.487 36%


MODULE                           PROGRAM                                            CLIENT_ID       SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM     TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- -------------------------------------------------- --------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
484D1A4168F0449D1BF42A62072C4231 iMX BE                                             inacheva        ats3wqwa005us  522901675                                            2024/08/12 15:47:04  2024/08/12 15:58:04      50                    2 +000000000 00:11:00.522 100%


INSTANCE_NUMBER SQL_ID            ELAPSED MAX_WAIT_ON     PC_OF  WAIT_TIME            GETS      READS       ROWS  ELAP/EXEC       GETS/EXEC READS/EXEC  ROWS/EXEC       EXEC PLAN_HASH_VALUE
--------------- ------------- ----------- --------------- ----- ---------- --------------- ---------- ---------- ---------- --------------- ---------- ---------- ---------- ---------------
              1 ats3wqwa005us         514 IO              65%   582.376176        23227654     728314         19     257.19        11613827     364157        9.5          2   522901675

Plan hash value: 522901675
--------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                        | Name                      | Rows  | Bytes |TempSpc| Cost (%CPU)| Time     |
--------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                                 |                           |       |       |       |   368K(100)|          |
|*  1 |  VIEW                                            |                           |     1 |   568 |       |   368K  (1)| 00:00:15 |
|*  2 |   COUNT STOPKEY                                  |                           |       |       |       |            |          |
|   3 |    VIEW                                          |                           |     1 |   555 |       |   368K  (1)| 00:00:15 |
|*  4 |     SORT ORDER BY STOPKEY                        |                           |     1 |   213 |       |   368K  (1)| 00:00:15 |
|   5 |      NESTED LOOPS                                |                           |   615 |   127K|       |   344K  (1)| 00:00:14 |
|   6 |       NESTED LOOPS                               |                           |   615 |   127K|       |   344K  (1)| 00:00:14 |
|*  7 |        HASH JOIN                                 |                           |   615 |   106K|       |   342K  (1)| 00:00:14 |
|   8 |         NESTED LOOPS                             |                           |   590 | 90270 |       |   341K  (1)| 00:00:14 |
|   9 |          NESTED LOOPS                            |                           | 26980 | 90270 |       |   341K  (1)| 00:00:14 |
|* 10 |           HASH JOIN                              |                           | 26980 |  3056K|  4000K|   291K  (1)| 00:00:12 |
|* 11 |            HASH JOIN                             |                           | 48152 |  3432K|  2752K|  2459   (1)| 00:00:01 |
|* 12 |             HASH JOIN                            |                           | 51235 |  2151K|       |   911   (1)| 00:00:01 |
|* 13 |              TABLE ACCESS BY INDEX ROWID BATCHED | G_DOSSIER                 |  1315 | 27615 |       |   277   (0)| 00:00:01 |
|* 14 |               INDEX RANGE SCAN                   | DOS_ANCREFDOSS            |   287 |       |       |     2   (0)| 00:00:01 |
|  15 |              INDEX FAST FULL SCAN                | DOS_REFDOSS_REFLOT_IDX    |   341K|  7344K|       |   631   (1)| 00:00:01 |
|* 16 |             INDEX FAST FULL SCAN                 | G_DOSSIER_RL_CD_RD_RF_IDX |   327K|  9598K|       |   760   (1)| 00:00:01 |
|* 17 |            TABLE ACCESS BY INDEX ROWID BATCHED   | G_PIECE                   |   193K|  8144K|       |   287K  (1)| 00:00:12 |
|* 18 |             INDEX SKIP SCAN                      | GP_REFEXT_IDX             |   378K|       |       |   105K  (1)| 00:00:05 |
|* 19 |              COUNT STOPKEY                       |                           |       |       |       |            |          |
|* 20 |               TABLE ACCESS BY INDEX ROWID BATCHED| ELIGIB_CTRL               |     1 |    14 |       |     4   (0)| 00:00:01 |
|* 21 |                INDEX RANGE SCAN                  | EC_REFFACTURE_IDX         |     3 |       |       |     3   (0)| 00:00:01 |
|* 22 |           INDEX UNIQUE SCAN                      | EFI_REFELEM               |     1 |       |       |     1   (0)| 00:00:01 |
|* 23 |          TABLE ACCESS BY INDEX ROWID             | G_ELEMFI                  |     1 |    37 |       |     2   (0)| 00:00:01 |
|* 24 |         INDEX FAST FULL SCAN                     | INT_INDIV                 |   341K|  8012K|       |  1073   (1)| 00:00:01 |
|* 25 |        INDEX UNIQUE SCAN                         | IND_REFINDIV              |     1 |       |       |     1   (0)| 00:00:01 |
|  26 |       TABLE ACCESS BY INDEX ROWID                | G_INDIVIDU                |     1 |    36 |       |     2   (0)| 00:00:01 |
--------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   1 - filter("RNUM">=:3)
   2 - filter(ROWNUM<=:2)
   4 - filter(ROWNUM<=:2)
   7 - access("TI_COMPTE"."REFDOSS"="GD_COMPTE"."REFDOSS")
  10 - access("GP_FACT"."REFDOSS"="GD_COMPTE"."REFDOSS")
  11 - access("GD_COMPTE"."REFLOT"="GD_DECOMPTE"."REFDOSS")
  12 - access("GD_DECOMPTE"."REFLOT"="GD_CONTRAT"."REFDOSS")
  13 - filter("GD_CONTRAT"."CATEGDOSS" LIKE 'CONTRAT%')
  14 - access("GD_CONTRAT"."ANCREFDOSS" LIKE '%'||:1||'%')
       filter("GD_CONTRAT"."ANCREFDOSS" LIKE '%'||:1||'%')
  16 - filter("GD_COMPTE"."CATEGDOSS" LIKE 'COMPTE%')
  17 - filter(("GP_FACT"."REFDOSS" IS NOT NULL AND "GP_FACT"."GPIHEURE" IS NOT NULL))
  18 - access("GP_FACT"."TYPPIECE"='FACTURE')
       filter(("GP_FACT"."TYPPIECE"='FACTURE' AND  IS NOT NULL))
  19 - filter(ROWNUM=1)
  20 - filter("DT_RESOLVE" IS NULL)
  21 - access("REFFACTURE"=:B1)
  22 - access("GP_FACT"."GPIHEURE"="ELEMFI"."REFELEM")
       filter(DECODE(TO_CHAR("GP_FACT"."DT10"),NULL,"GP_FACT"."MT24","FTR_UTIL"."SOLDEF_DCPT"("ELEMFI"."REFELEM"))<>0)
  23 - filter("ELEMFI"."DTTRAITE_DT" IS NULL)
  24 - filter("TI_COMPTE"."REFTYPE"='DB')
  25 - access("GI"."REFINDIVIDU"="TI_COMPTE"."REFINDIVIDU") 
 
*/
/********************************OLD Metrics***************************************/

/********************************New SQL*******************************************/

SELECT *
  FROM (SELECT /*+ first_rows(16)*/
         foo.*, ROWNUM rnum
          FROM (SELECT montant_mvt amount,
                       refpiece    docRef,
                       refdoss     clAccount,
                       refext      invNumber,
                       nom         debtorName,
                       devise_mvt  currency,
                       ancrefdoss  cntNumber,
                       refelem     refElem,
                       clDbAccount clDbAccount
                  FROM (SELECT 'NO COLOR' AS color,
                               GD_DECOMPTE.refdoss,
                               GD_CONTRAT.ancrefdoss,
                               GD_COMPTE.refdoss clDbAccount,
                               GP_FACT.refpiece,
                               ELEMFI.refelem,
                               ELEMFI.refext,
                               ELEMFI.montant_mvt,
                               GD_COMPTE.nom,
                               ELEMFI.devise_mvt
                          FROM g_dossier GD_DECOMPTE,
                               g_dossier GD_CONTRAT,
                               g_piece GP_FACT,
                               g_elemfi ELEMFI,
                               (SELECT GD_COMPTE.reflot,
                                       GD_COMPTE.refdoss,
                                       gi.nom
                                  FROM g_dossier      GD_COMPTE,
                                       t_intervenants TI_COMPTE,
                                       g_individu     GI
                                 WHERE TI_COMPTE.refdoss = GD_COMPTE.refdoss
                                   AND GD_COMPTE.categdoss LIKE 'COMPTE%'
                                   AND gi.refindividu = TI_COMPTE.refindividu
                                   AND TI_COMPTE.reftype = 'DB') GD_COMPTE
                         WHERE 1 = 1
                           AND GD_DECOMPTE.reflot = GD_CONTRAT.refdoss
                           AND GD_CONTRAT.categdoss LIKE 'CONTRAT%'
                           AND GD_COMPTE.reflot = GD_DECOMPTE.refdoss
                           AND GP_FACT.refdoss = GD_COMPTE.refdoss
                           AND GP_FACT.typpiece = 'FACTURE'
                           AND GP_FACT.gpiheure = ELEMFI.refelem
                           AND ELEMFI.dttraite_dt IS NULL
                           AND 0 <>
                               DECODE(GP_FACT.dt10,
                                      NULL,
                                      GP_FACT.mt24,
                                      ftr_util.SoldeF_DCPT(ELEMFI.refelem))
                           AND EXISTS ( SELECT 1
                                          FROM eligib_ctrl
                                         WHERE dt_resolve IS NULL
                                           AND reffacture = GP_FACT.refpiece
                                           AND ROWNUM = 1 )
                           AND GD_CONTRAT.ancrefdoss LIKE :B1 || '%')
                 WHERE 1 = 1
                 ORDER BY refelem, refelem) foo
         WHERE ROWNUM <= :B2)
 WHERE 1 = 1
   AND rnum >= :B3;
/********************************New SQL*******************************************/
/********************************New Metrics***************************************/
/*
Plan hash value: 110723437
-------------------------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                       | Name                      | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  |
-------------------------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                                |                           |      1 |        |    37 (100)|     16 |00:00:00.11 |   13113 |     50 |
|*  1 |  VIEW                                           |                           |      1 |      1 |    37   (3)|     16 |00:00:00.11 |   13113 |     50 |
|*  2 |   COUNT STOPKEY                                 |                           |      1 |        |            |     16 |00:00:00.11 |   13113 |     50 |
|   3 |    VIEW                                         |                           |      1 |      1 |    37   (3)|     16 |00:00:00.11 |   13113 |     50 |
|*  4 |     SORT ORDER BY STOPKEY                       |                           |      1 |      1 |    37   (3)|     16 |00:00:00.11 |   13113 |     50 |
|*  5 |      FILTER                                     |                           |      1 |        |            |    114 |00:00:00.11 |   13113 |     50 |
|   6 |       NESTED LOOPS                              |                           |      1 |      1 |    32   (0)|    437 |00:00:00.11 |   12224 |     50 |
|   7 |        NESTED LOOPS                             |                           |      1 |      3 |    32   (0)|    437 |00:00:00.11 |   11778 |     50 |
|   8 |         NESTED LOOPS                            |                           |      1 |      3 |    26   (0)|   3501 |00:00:00.09 |    7875 |     50 |
|   9 |          NESTED LOOPS                           |                           |      1 |      1 |    15   (0)|    115 |00:00:00.07 |     430 |     50 |
|  10 |           NESTED LOOPS                          |                           |      1 |      1 |    13   (0)|    115 |00:00:00.04 |     142 |     30 |
|  11 |            NESTED LOOPS                         |                           |      1 |      1 |    11   (0)|    115 |00:00:00.01 |      10 |      0 |
|  12 |             NESTED LOOPS                        |                           |      1 |      3 |     5   (0)|      1 |00:00:00.01 |       6 |      0 |
|* 13 |              TABLE ACCESS BY INDEX ROWID BATCHED| G_DOSSIER                 |      1 |      1 |     3   (0)|      1 |00:00:00.01 |       3 |      0 |
|* 14 |               INDEX RANGE SCAN                  | DOS_ANCREFDOSS            |      1 |      1 |     2   (0)|      1 |00:00:00.01 |       2 |      0 |
|* 15 |              INDEX RANGE SCAN                   | G_DOSSIER_RL_CD_RD_RF_IDX |      1 |     39 |     2   (0)|      1 |00:00:00.01 |       3 |      0 |
|* 16 |             INDEX RANGE SCAN                    | G_DOSSIER_RL_CD_RD_RF_IDX |      1 |      1 |     2   (0)|    115 |00:00:00.01 |       4 |      0 |
|* 17 |            INDEX RANGE SCAN                     | INT_REFDOSS               |    115 |      1 |     2   (0)|    115 |00:00:00.04 |     132 |     30 |
|  18 |           TABLE ACCESS BY INDEX ROWID           | G_INDIVIDU                |    115 |      1 |     2   (0)|    115 |00:00:00.03 |     288 |     20 |
|* 19 |            INDEX UNIQUE SCAN                    | IND_REFINDIV              |    115 |      1 |     1   (0)|    115 |00:00:00.01 |     204 |      2 |
|* 20 |          TABLE ACCESS BY INDEX ROWID BATCHED    | G_PIECE                   |    115 |     11 |    11   (0)|   3501 |00:00:00.03 |    7445 |      0 |
|* 21 |           INDEX RANGE SCAN                      | PIE_REFDOSS               |    115 |     15 |     3   (0)|   3501 |00:00:00.01 |     309 |      0 |
|* 22 |         INDEX UNIQUE SCAN                       | EFI_REFELEM               |   3501 |      1 |     1   (0)|    437 |00:00:00.01 |    3903 |      0 |
|* 23 |        TABLE ACCESS BY INDEX ROWID              | G_ELEMFI                  |    437 |      1 |     2   (0)|    437 |00:00:00.01 |     446 |      0 |
|* 24 |       COUNT STOPKEY                             |                           |    437 |        |            |    114 |00:00:00.01 |     889 |      0 |
|* 25 |        TABLE ACCESS BY INDEX ROWID BATCHED      | ELIGIB_CTRL               |    437 |      1 |     4   (0)|    114 |00:00:00.01 |     889 |      0 |
|* 26 |         INDEX RANGE SCAN                        | EC_REFFACTURE_IDX         |    437 |      3 |     3   (0)|    114 |00:00:00.01 |     775 |      0 |
-------------------------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   1 - filter("RNUM">=:B3)
   2 - filter(ROWNUM<=:B2)
   4 - filter(ROWNUM<=:B2)
   5 - filter( IS NOT NULL)
  13 - filter("GD_CONTRAT"."CATEGDOSS" LIKE 'CONTRAT%')
  14 - access("GD_CONTRAT"."ANCREFDOSS" LIKE :B1||'%')
       filter("GD_CONTRAT"."ANCREFDOSS" LIKE :B1||'%')
  15 - access("GD_DECOMPTE"."REFLOT"="GD_CONTRAT"."REFDOSS")
  16 - access("GD_COMPTE"."REFLOT"="GD_DECOMPTE"."REFDOSS" AND "GD_COMPTE"."CATEGDOSS" LIKE 'COMPTE%')
       filter("GD_COMPTE"."CATEGDOSS" LIKE 'COMPTE%')
  17 - access("TI_COMPTE"."REFDOSS"="GD_COMPTE"."REFDOSS" AND "TI_COMPTE"."REFTYPE"='DB')
  19 - access("GI"."REFINDIVIDU"="TI_COMPTE"."REFINDIVIDU")
  20 - filter("GP_FACT"."GPIHEURE" IS NOT NULL)
  21 - access("GP_FACT"."REFDOSS"="GD_COMPTE"."REFDOSS" AND "GP_FACT"."TYPPIECE"='FACTURE')
       filter("GP_FACT"."REFDOSS" IS NOT NULL)
  22 - access("GP_FACT"."GPIHEURE"="ELEMFI"."REFELEM")
       filter(DECODE(TO_CHAR("GP_FACT"."DT10"),NULL,"GP_FACT"."MT24","FTR_UTIL"."SOLDEF_DCPT"("ELEMFI"."REFELEM"))<>0)
  23 - filter("ELEMFI"."DTTRAITE_DT" IS NULL)
  24 - filter(ROWNUM=1)
  25 - filter("DT_RESOLVE" IS NULL)
  26 - access("REFFACTURE"=:B1) 
 
*/
/********************************New Metrics***************************************/

/********************************Index statistics**********************************/

/********************************Other SQLs****************************************/          
/*

*/ 
/********************************Other SQLs****************************************/              
