##### ESL CHECKS #####
## CHECKED ESL: YES
## CHECKED PREVIOUS INCIDENTS: YES
## SPECIAL HANDLING: No
## SCHEDULED OUTAGE: No

##### INVESTIGATION #####



##### TRANSFERRING #####
## WHY: 
## TO: 
## HANDSHAKE NEEDED: YES/NO


##### PENDING #####
## WHY: 
## NEXT-ACTION DATE: 
## NEXT-ACTION: 


##### RESOLVED CASE #####
## SOLUTION:�


##### E-MAIL SENT OUT #####


