/********************************************************************************
*********       E-mail subject: MOBARCWEB-613
*********             Instance: PROD
*********          Description: 
Problem:

Slow query on PROD from V9.

Analysis:

On 07/07/2023 the provided query was slow.
The problem was that in this case the bind for column refindividu was 'INT00000' and 
oracle use inappropriate execution plan and start from table t_intervenants instead of table g_dossier.


Suggestion:

Please add hint as it is shown in the New SQL section below to navigate oracle to start from table g_dossier.

*********               SQL_ID: dhgrhnxak3n7r
*********      Program/Package: V9 BackEnd
*********              Request: Dimitare Ivanov
*********               Author: Dimitar Dimitrov
********* Received e-mail date: 11/07/2023
*********      Resolution date: 13/07/2023
*********  Trace old file here: \\epox\specifs\performance\tmp\
*********  Trace new file here:
***********************************************************************************/

/********************************OLD SQL*******************************************/
SELECT *
  FROM (SELECT /*+ first_rows(2001)*/
         foo.*, ROWNUM rnum
          FROM (SELECT caseRef      caseRef,
                       amount       amount,
                       customerCode customerCode
                  FROM (SELECT d.ancrefdoss  customerCode,
                               d.soldedb_dos amount,
                               d.refdoss     caseRef
                          FROM g_dossier d, t_intervenants t
                         WHERE t.refindividu = :bind1
                           AND t.reftype = 'CL'
                           AND t.refdoss = d.refdoss
                           AND d.refdoss <> :bind2)
                 WHERE 1 = 1
                   AND customerCode LIKE :bind3
                 ORDER BY customerCode, amount, customerCode) foo
         WHERE ROWNUM <= :bind4)
 WHERE 1 = 1
   AND rnum >= :bind5;
/********************************OLD SQL*******************************************/
/********************************OLD Metrics***************************************/
/*
Plan hash value: 230474104
-------------------------------------------------------------------------------------------------------------------
| Id  | Operation                        | Name        | Starts | E-Rows | A-Rows |   A-Time   | Buffers | Reads  |
-------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                 |             |      1 |        |      1 |00:02:50.62 |    3976K|    788K|
|*  1 |  VIEW                            |             |      1 |      1 |      1 |00:02:50.62 |    3976K|    788K|
|*  2 |   COUNT STOPKEY                  |             |      1 |        |      1 |00:02:50.62 |    3976K|    788K|
|   3 |    VIEW                          |             |      1 |      1 |      1 |00:02:50.62 |    3976K|    788K|
|*  4 |     SORT ORDER BY STOPKEY        |             |      1 |      1 |      1 |00:02:50.62 |    3976K|    788K|
|   5 |      NESTED LOOPS                |             |      1 |      1 |      1 |00:02:50.62 |    3976K|    788K|
|   6 |       NESTED LOOPS               |             |      1 |      1 |   8818K|00:00:23.37 |     352K|  47077 |
|*  7 |        INDEX RANGE SCAN          | INT_INDIV   |      1 |      1 |   8818K|00:00:07.00 |   44518 |  44517 |
|*  8 |        INDEX UNIQUE SCAN         | DOS_REFDOSS |   8818K|      1 |   8818K|00:00:09.94 |     308K|   2560 |
|*  9 |       TABLE ACCESS BY INDEX ROWID| G_DOSSIER   |   8818K|      1 |      1 |00:02:23.25 |    3623K|    741K|
-------------------------------------------------------------------------------------------------------------------

Predicate Information (identified by operation id):
---------------------------------------------------
   1 - filter("RNUM">=:BIND5)
   2 - filter(ROWNUM<=:BIND4)
   4 - filter(ROWNUM<=:BIND4)
   7 - access("T"."REFINDIVIDU"=:BIND1 AND "T"."REFTYPE"='CL')
       filter("T"."REFDOSS"<>:BIND2)
   8 - access("T"."REFDOSS"="D"."REFDOSS")
       filter("D"."REFDOSS"<>:BIND2)
   9 - filter("D"."ANCREFDOSS" LIKE TO_CHAR(:BIND3))
*/
/********************************OLD Metrics***************************************/

/********************************New SQL*******************************************/
SELECT *
  FROM (SELECT /*+ first_rows(2001)*/
         foo.*, ROWNUM rnum
          FROM (SELECT caseRef      caseRef,
                       amount       amount,
                       customerCode customerCode
                  FROM (SELECT /*+ leading(d)*/ d.ancrefdoss  customerCode,
                               d.soldedb_dos amount,
                               d.refdoss     caseRef
                          FROM g_dossier d, t_intervenants t
                         WHERE t.refindividu = :bind1
                           AND t.reftype = 'CL'
                           AND t.refdoss = d.refdoss
                           AND d.refdoss <> :bind2)
                 WHERE 1 = 1
                   AND customerCode LIKE :bind3
                 ORDER BY customerCode, amount, customerCode) foo
         WHERE ROWNUM <= :bind4)
 WHERE 1 = 1
   AND rnum >= :bind5;
/********************************New SQL*******************************************/
/********************************New Metrics***************************************/
/*
Plan hash value: 2213090559
---------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                | Name           | Starts | E-Rows | A-Rows |   A-Time   | Buffers |
---------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                         |                |      1 |        |      2 |00:00:00.01 |      11 |
|*  1 |  VIEW                                    |                |      1 |      1 |      2 |00:00:00.01 |      11 |
|*  2 |   COUNT STOPKEY                          |                |      1 |        |      2 |00:00:00.01 |      11 |
|   3 |    VIEW                                  |                |      1 |      1 |      2 |00:00:00.01 |      11 |
|*  4 |     SORT ORDER BY STOPKEY                |                |      1 |      1 |      2 |00:00:00.01 |      11 |
|   5 |      NESTED LOOPS                        |                |      1 |      1 |      2 |00:00:00.01 |      11 |
|*  6 |       TABLE ACCESS BY INDEX ROWID BATCHED| G_DOSSIER      |      1 |      1 |      2 |00:00:00.01 |       5 |
|*  7 |        INDEX RANGE SCAN                  | DOS_ANCREFDOSS |      1 |      1 |      2 |00:00:00.01 |       3 |
|*  8 |       INDEX RANGE SCAN                   | INT_REFDOSS    |      2 |      1 |      2 |00:00:00.01 |       6 |
---------------------------------------------------------------------------------------------------------------------

Predicate Information (identified by operation id):
---------------------------------------------------
   1 - filter("RNUM">=:BIND5)
   2 - filter(ROWNUM<=:BIND4)
   4 - filter(ROWNUM<=:BIND4)
   6 - filter("D"."REFDOSS"<>:BIND2)
   7 - access("D"."ANCREFDOSS" LIKE TO_CHAR(:BIND3))
       filter("D"."ANCREFDOSS" LIKE TO_CHAR(:BIND3))
   8 - access("T"."REFDOSS"="D"."REFDOSS" AND "T"."REFTYPE"='CL' AND "T"."REFINDIVIDU"=:BIND1)
       filter("T"."REFDOSS"<>:BIND2)
*/
/********************************New Metrics***************************************/

/********************************Index statistics**********************************/

/********************************Other SQLs****************************************/          
/*

*/ 
/********************************Other SQLs****************************************/              
