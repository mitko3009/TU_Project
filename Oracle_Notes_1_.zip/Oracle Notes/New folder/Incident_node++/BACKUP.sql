physical backup - cold or hot

Cold Backup - offline database - the system change number 
in the data blocks and in the control files will e the SAME so it leads to consistant backup of a database!!!


Logical Backup - Data Pump/Export - suppose if we need to make a backup of only one tablespace


HOW TO START A COLD BACKUP IN ARCHIVE MODE:

SQL> select file_name from dba_data_files;

FILE_NAME
--------------------------------------------------------------------------------
/disk1/prod/data/system.dbf
/disk1/prod/data/sysaux.dbf
/disk1/prod/data/undotbs.dbf
/disk1/prod/data/user01.dbf
/disk2/prod1/data/data99.dbf
/disk2/prod1/data/data03.dbf
/disk2/prod1/data/unotbs1b.dbf
/disk2/prod1/data/undotbs201.dbf

8 rows selected.

SQL> select name from v$controlfile;

NAME
--------------------------------------------------------------------------------
/disk1/prod/control/control01.ctl
/disk1/prod/control/control02.ctl

SQL> se^H^H^Harci
SP2-0042: unknown command arci" - rest of line ignored.
SQL>
SQL>
SQL> archive log list
Database log mode              Archive Mode
Automatic archival             Enabled
Archive destination            /disk1/prod/arch
Oldest online log sequence     40
Next log sequence to archive   42
Current log sequence           42
SQL> shutdown transactional;
Database closed.
Database dismounted.
ORACLE instance shut down.
SQL> exit
Disconnected from Oracle Database 11g Enterprise Edition Release 11.2.0.1.0 - 64bit Production
With the Partitioning, OLAP, Data Mining and Real Application Testing options
[oracle@linux ~]$ exit
logout
[root@linux ~]# cd /
[root@linux /]# pwd
/
[root@linux /]# ls
bin   disk1  home   lost+found  mnt  proc  selinux  tftpboot  usr
boot  disk2  lib    media       net  root  srv      tmp       var
dev   etc    lib64  misc        opt  sbin  sys      u01
[root@linux /]# mkdir coldbackup
[root@linux /]# cd /disk1/prod
[root@linux prod]# ls
arch  control  data  diag  fra  log  redo
[root@linux prod]# cp -r data /coldbackup/
[root@linux prod]# cp -r control /coldbackup/
[root@linux prod]# cp -r arch /controlbackup/
[root@linux prod]# cd /
[root@linux /]# cd coldbackup/
[root@linux coldbackup]# ls -larth
total 20K
drwxr-xr-x  2 root root 4.0K Mar 18 15:01 data
drwxr-xr-x  2 root root 4.0K Mar 18 15:01 control
drwxr-xr-x  4 root root 4.0K Mar 18 15:01 .
drwxr-xr-x 31 root root 4.0K Mar 18 15:02 ..
[root@linux coldbackup]# cd /disk1/prod
[root@linux prod]# cd arch/
[root@linux arch]# ls -larth
total 287M
drwxr-xr-x 9 oracle oinstall 4.0K Oct 26 01:16 ..
-rw-r----- 1 oracle oinstall 240K Dec  1 23:44 1_12_1022686686.dbf
-rw-r----- 1 oracle oinstall  67K Dec  1 23:54 1_13_1022686686.dbf
-rw-r----- 1 oracle oinstall  23M Dec 24 23:18 1_14_1022686686.dbf
-rw-r----- 1 oracle oinstall  58M Dec 25 02:59 1_15_1022686686.dbf
-rw-r----- 1 oracle oinstall 5.8M Dec 30 10:10 1_16_1022686686.dbf
-rw-r----- 1 oracle oinstall  25M Dec 30 15:35 1_17_1022686686.dbf
-rw-r----- 1 oracle oinstall 1.5K Dec 30 15:35 1_18_1022686686.dbf
-rw-r----- 1 oracle oinstall 967K Dec 30 16:02 1_19_1022686686.dbf
-rw-r----- 1 oracle oinstall 7.0K Dec 30 16:02 1_20_1022686686.dbf
-rw-r----- 1 oracle oinstall 7.0K Dec 30 16:09 1_21_1022686686.dbf
-rw-r----- 1 oracle oinstall 1.0K Dec 30 16:09 1_22_1022686686.dbf
-rw-r----- 1 oracle oinstall 1.5K Dec 30 16:09 1_23_1022686686.dbf
-rw-r----- 1 oracle oinstall  67K Dec 30 16:32 1_24_1022686686.dbf
-rw-r----- 1 oracle oinstall 3.0K Dec 30 16:33 1_25_1022686686.dbf
-rw-r----- 1 oracle oinstall 1.5K Dec 30 16:33 1_26_1022686686.dbf
-rw-r----- 1 oracle oinstall  15K Dec 30 16:40 1_27_1022686686.dbf
-rw-r----- 1 oracle oinstall 1.0K Dec 30 16:41 1_28_1022686686.dbf
-rw-r----- 1 oracle oinstall 2.1M Jan 11 03:29 1_29_1022686686.dbf
-rw-r----- 1 oracle oinstall  30M Jan 31 10:56 1_30_1022686686.dbf
-rw-r----- 1 oracle oinstall 9.8M Jan 31 14:00 1_31_1022686686.dbf
-rw-r----- 1 oracle oinstall 5.6M Feb  3 23:03 1_32_1022686686.dbf
-rw-r----- 1 oracle oinstall  23M Feb  7 10:36 1_33_1022686686.dbf
-rw-r----- 1 oracle oinstall 9.8M Feb  8 06:49 1_34_1022686686.dbf
-rw-r----- 1 oracle oinstall  18M Feb 25 08:47 1_35_1022686686.dbf
-rw-r----- 1 oracle oinstall  40M Mar  3 17:12 1_36_1022686686.dbf
-rw-r----- 1 oracle oinstall 5.2M Mar  6 02:03 1_37_1022686686.dbf
-rw-r----- 1 oracle oinstall  21M Mar  9 16:15 1_38_1022686686.dbf
-rw-r----- 1 oracle oinstall 4.6M Mar 10 19:28 1_39_1022686686.dbf
-rw-r----- 1 oracle oinstall 1.7M Mar 14 02:29 1_40_1022686686.dbf
-rw-r----- 1 oracle oinstall 6.0M Mar 17 17:16 1_41_1022686686.dbf
drwxr-xr-x 2 oracle oinstall 4.0K Mar 17 17:16 .
[root@linux arch]# cd ..
[root@linux prod]# cp -r arch /coldbackup/
[root@linux prod]# cd /coldbackup/
[root@linux coldbackup]# ls -larth
total 24K
drwxr-xr-x  2 root root 4.0K Mar 18 15:01 data
drwxr-xr-x  2 root root 4.0K Mar 18 15:01 control
drwxr-xr-x 31 root root 4.0K Mar 18 15:02 ..
drwxr-xr-x  5 root root 4.0K Mar 18 15:03 .
drwxr-xr-x  2 root root 4.0K Mar 18 15:03 arch
[root@linux coldbackup]# cd data
[root@linux data]# ls -la
total 1230056
drwxr-xr-x 2 root root      4096 Mar 18 15:01 .
drwxr-xr-x 5 root root      4096 Mar 18 15:03 ..
-rw-r----- 1 root root 314580992 Mar 18 15:01 sysaux.dbf
-rw-r----- 1 root root 314580992 Mar 18 15:01 system.dbf
-rw-r----- 1 root root 104865792 Mar 18 15:01 undotbs.dbf
-rw-r----- 1 root root 524296192 Mar 18 15:01 user01.dbf
[root@linux data]# cd ..
[root@linux coldbackup]# cd arch
[root@linux arch]# ls -larth
total 287M
-rw-r----- 1 root root 1.7M Mar 18 15:03 1_40_1022686686.dbf
-rw-r----- 1 root root 3.0K Mar 18 15:03 1_25_1022686686.dbf
drwxr-xr-x 5 root root 4.0K Mar 18 15:03 ..
-rw-r----- 1 root root 4.6M Mar 18 15:03 1_39_1022686686.dbf
-rw-r----- 1 root root 5.2M Mar 18 15:03 1_37_1022686686.dbf
-rw-r----- 1 root root 9.8M Mar 18 15:03 1_34_1022686686.dbf
-rw-r----- 1 root root  23M Mar 18 15:03 1_33_1022686686.dbf
-rw-r----- 1 root root  30M Mar 18 15:03 1_30_1022686686.dbf
-rw-r----- 1 root root  25M Mar 18 15:03 1_17_1022686686.dbf
-rw-r----- 1 root root 6.0M Mar 18 15:03 1_41_1022686686.dbf
-rw-r----- 1 root root  21M Mar 18 15:03 1_38_1022686686.dbf
-rw-r----- 1 root root 5.6M Mar 18 15:03 1_32_1022686686.dbf
-rw-r----- 1 root root 9.8M Mar 18 15:03 1_31_1022686686.dbf
-rw-r----- 1 root root 1.0K Mar 18 15:03 1_28_1022686686.dbf
-rw-r----- 1 root root 2.1M Mar 18 15:03 1_29_1022686686.dbf
-rw-r----- 1 root root 1.5K Mar 18 15:03 1_23_1022686686.dbf
-rw-r----- 1 root root 967K Mar 18 15:03 1_19_1022686686.dbf
-rw-r----- 1 root root  58M Mar 18 15:03 1_15_1022686686.dbf
-rw-r----- 1 root root  40M Mar 18 15:03 1_36_1022686686.dbf
-rw-r----- 1 root root  18M Mar 18 15:03 1_35_1022686686.dbf
-rw-r----- 1 root root  15K Mar 18 15:03 1_27_1022686686.dbf
-rw-r----- 1 root root 1.5K Mar 18 15:03 1_26_1022686686.dbf
-rw-r----- 1 root root  67K Mar 18 15:03 1_24_1022686686.dbf
-rw-r----- 1 root root 1.0K Mar 18 15:03 1_22_1022686686.dbf
-rw-r----- 1 root root 7.0K Mar 18 15:03 1_21_1022686686.dbf
-rw-r----- 1 root root 7.0K Mar 18 15:03 1_20_1022686686.dbf
-rw-r----- 1 root root 1.5K Mar 18 15:03 1_18_1022686686.dbf
-rw-r----- 1 root root 5.8M Mar 18 15:03 1_16_1022686686.dbf
-rw-r----- 1 root root  23M Mar 18 15:03 1_14_1022686686.dbf
-rw-r----- 1 root root  67K Mar 18 15:03 1_13_1022686686.dbf
-rw-r----- 1 root root 240K Mar 18 15:03 1_12_1022686686.dbf
drwxr-xr-x 2 root root 4.0K Mar 18 15:03 .
[root@linux arch]# cd ..
[root@linux coldbackup]# cd control/
[root@linux control]# ls -la
total 15360
drwxr-xr-x 2 root root    4096 Mar 18 15:01 .
drwxr-xr-x 5 root root    4096 Mar 18 15:03 ..
-rw-r----- 1 root root 7847936 Mar 18 15:01 control01.ctl
-rw-r----- 1 root root 7847936 Mar 18 15:01 control02.ctl
[root@linux control]# cd ..
[root@linux coldbackup]# pwd
/coldbackup
[root@linux coldbackup]# su - oracle
[oracle@linux ~]$ . oraenv
ORACLE_SID = [prod] ? PROD
The Oracle base for ORACLE_HOME=/u01/app/oracle/product/11.2.0 is /u01/app/oracle
[oracle@linux ~]$ sqlplus / as sysdba

SQL*Plus: Release 11.2.0.1.0 Production on Wed Mar 18 15:05:08 2020

Copyright (c) 1982, 2009, Oracle.  All rights reserved.

Connected to an idle instance.

SQL> startup;
ORACLE instance started.

Total System Global Area  521936896 bytes
Fixed Size                  2214936 bytes
Variable Size             352322536 bytes
Database Buffers          163577856 bytes
Redo Buffers                3821568 bytes
Database mounted.
Database opened.
SQL>
======================================================================================================

HOW TO MAKE A HOT BACKUP IN ARCHIVE Mode

1.MAKE SURE THE DATABASE IS IN ARCHIVING Mode
2.DETERMINE THE LOCATION OF DATA FILES, CONTROL FILES AND OTHER FILES TO BACKUP BY QUERYING THE Database
3.CHECK THE CURRENT MAXIMUM SEQUENCE NUMBER FROM ONLINE REDO LOG FILES(EXAMPLE:  41)
4.PUT THE DATABASE IN BACKUP MODE
5.BACKUP DATA FILES USING THE OS UTILITY cp(COPY)
6.TAKE THE DATABASE OUT OF BACKUP MODE
7.TRIGGER A CHECKPOINT (ARCHIVE THE CURRENT LOGFILE)
8.BACKUP THE CONTROL FILES
9.FIND THE CURRENT MAXIMUM SEQUENCE NUMBER FROM ONLINE REDO LOG FILES (EXAMPLE :46)
10.TAKE THE BACKUP OF ARCHIVED LOGS GENERATED DURING BACKUP (IE BETWEEN CURRENT SEQUENCE NUMBER IN sTEP 3 TO 9, DON'T INCLUDE
CURRENT MAXIMUM SEQUENCE NUMBER. SO AS PER OUR EXAMPLE WE TAKE 41,42,43,44,45)


[root@linux ~]# cd /
[root@linux /]# cd /disk1
[root@linux disk1]# mkdir hotbackup
[root@linux disk1]# cd /
[root@linux /]# cd disk1
[root@linux disk1]# cd prod
[root@linux prod]# ls -la
total 68
drwxr-xr-x 9 oracle oinstall 4096 Oct 26 01:16 .
drwxr-xr-x 5 oracle oinstall 4096 Mar 18 15:27 ..
drwxr-xr-x 2 oracle oinstall 4096 Mar 17 17:16 arch
drwxr-xr-x 2 oracle oinstall 4096 Oct 26 15:38 control
drwxr-xr-x 2 oracle oinstall 4096 Oct 26 15:38 data
drwxr-xr-x 3 oracle oinstall 4096 Oct 26 14:59 diag
drwxr-xr-x 2 oracle oinstall 4096 Oct 26 01:16 fra
drwxr-xr-x 2 oracle oinstall 4096 Oct 26 01:16 log
drwxr-xr-x 2 oracle oinstall 4096 Oct 26 15:38 redo
[root@linux prod]# cp -r data /disk1/hotbackup/
[root@linux prod]# cd /disk1/hotbackup/data/
[root@linux data]# ls -larth
total 1.2G
drwxr-xr-x 3 root root 4.0K Mar 18 15:27 ..
-rw-r----- 1 root root 501M Mar 18 15:28 user01.dbf
-rw-r----- 1 root root 301M Mar 18 15:28 sysaux.dbf
-rw-r----- 1 root root 301M Mar 18 15:28 system.dbf
drwxr-xr-x 2 root root 4.0K Mar 18 15:28 .
-rw-r----- 1 root root 101M Mar 18 15:28 undotbs.dbf
[root@linux data]# cd /disk1/
[root@linux disk1]# ls -la
total 40
drwxr-xr-x  5 oracle oinstall  4096 Mar 18 15:27 .
drwxr-xr-x 31 root   root      4096 Mar 18 15:02 ..
drwxr-xr-x  3 root   root      4096 Mar 18 15:27 hotbackup
drwx------  2 oracle oinstall 16384 Oct 25 19:24 lost+found
drwxr-xr-x  9 oracle oinstall  4096 Oct 26 01:16 prod
[root@linux disk1]# chown oracle hotbackup/
[root@linux disk1]# ls -la
total 40
drwxr-xr-x  5 oracle oinstall  4096 Mar 18 15:27 .
drwxr-xr-x 31 root   root      4096 Mar 18 15:02 ..
drwxr-xr-x  3 oracle root      4096 Mar 18 15:27 hotbackup
drwx------  2 oracle oinstall 16384 Oct 25 19:24 lost+found
drwxr-xr-x  9 oracle oinstall  4096 Oct 26 01:16 prod

[root@linux ~]# su - oracle
[oracle@linux ~]$ . oraenv
ORACLE_SID = [prod] ? PROD
The Oracle base for ORACLE_HOME=/u01/app/oracle/product/11.2.0 is /u01/app/or
[oracle@linux ~]$ sqlplus / as sysdba

SQL*Plus: Release 11.2.0.1.0 Production on Wed Mar 18 15:23:23 2020

Copyright (c) 1982, 2009, Oracle.  All rights reserved.


Connected to:
Oracle Database 11g Enterprise Edition Release 11.2.0.1.0 - 64bit Production
With the Partitioning, OLAP, Data Mining and Real Application Testing options

SQL> archive log list;
Database log mode              Archive Mode
Automatic archival             Enabled
Archive destination            /disk1/prod/arch
Oldest online log sequence     40
Next log sequence to archive   42
Current log sequence           42
SQL> select file_name from dba_data_files;

FILE_NAME
--------------------------------------------------------------------------------
/disk1/prod/data/system.dbf
/disk1/prod/data/sysaux.dbf
/disk1/prod/data/undotbs.dbf
/disk1/prod/data/user01.dbf
/disk2/prod1/data/data99.dbf
/disk2/prod1/data/data03.dbf
/disk2/prod1/data/unotbs1b.dbf
/disk2/prod1/data/undotbs201.dbf

8 rows selected.

SQL> select name from v$controlfile;

NAME
--------------------------------------------------------------------------------
/disk1/prod/control/control01.ctl
/disk1/prod/control/control02.ctl

SQL> select group#, sequence#, status from v$log;

    GROUP#  SEQUENCE# STATUS
---------- ---------- ----------------
         1         42 CURRENT
         2         41 INACTIVE
         3         40 INACTIVE

SQL> alter database begin backup;

Database altered.

SQL> select file#, status from v$backup;

     FILE# STATUS
---------- ------------------
         1 ACTIVE
         2 ACTIVE
         3 ACTIVE
         4 ACTIVE
         5 ACTIVE
         6 ACTIVE
         7 ACTIVE
         8 ACTIVE

8 rows selected.

SQL> alter database end backup;

Database altered.

SQL> select file#, status from v$backup;

     FILE# STATUS
---------- ------------------
         1 NOT ACTIVE
         2 NOT ACTIVE
         3 NOT ACTIVE
         4 NOT ACTIVE
         5 NOT ACTIVE
         6 NOT ACTIVE
         7 NOT ACTIVE
         8 NOT ACTIVE

8 rows selected.

SQL> alter system archive log current;

System altered.

SQL> select group#, sequence#, status from v$log;

    GROUP#  SEQUENCE# STATUS
---------- ---------- ----------------
         1         42 ACTIVE
         2         41 INACTIVE
         3         43 CURRENT


SQL> alter database backup controlfile to '/disk1/hotbackup/control.bk';

Database altered.

SQL>



[root@linux hotbackup]# cd /disk1/prod/arch
[root@linux arch]# ls -larth
total 320M
drwxr-xr-x 9 oracle oinstall 4.0K Oct 26 01:16 ..
-rw-r----- 1 oracle oinstall 240K Dec  1 23:44 1_12_1022686686.dbf
-rw-r----- 1 oracle oinstall  67K Dec  1 23:54 1_13_1022686686.dbf
-rw-r----- 1 oracle oinstall  23M Dec 24 23:18 1_14_1022686686.dbf
-rw-r----- 1 oracle oinstall  58M Dec 25 02:59 1_15_1022686686.dbf
-rw-r----- 1 oracle oinstall 5.8M Dec 30 10:10 1_16_1022686686.dbf
-rw-r----- 1 oracle oinstall  25M Dec 30 15:35 1_17_1022686686.dbf
-rw-r----- 1 oracle oinstall 1.5K Dec 30 15:35 1_18_1022686686.dbf
-rw-r----- 1 oracle oinstall 967K Dec 30 16:02 1_19_1022686686.dbf
-rw-r----- 1 oracle oinstall 7.0K Dec 30 16:02 1_20_1022686686.dbf
-rw-r----- 1 oracle oinstall 7.0K Dec 30 16:09 1_21_1022686686.dbf
-rw-r----- 1 oracle oinstall 1.0K Dec 30 16:09 1_22_1022686686.dbf
-rw-r----- 1 oracle oinstall 1.5K Dec 30 16:09 1_23_1022686686.dbf
-rw-r----- 1 oracle oinstall  67K Dec 30 16:32 1_24_1022686686.dbf
-rw-r----- 1 oracle oinstall 3.0K Dec 30 16:33 1_25_1022686686.dbf
-rw-r----- 1 oracle oinstall 1.5K Dec 30 16:33 1_26_1022686686.dbf
-rw-r----- 1 oracle oinstall  15K Dec 30 16:40 1_27_1022686686.dbf
-rw-r----- 1 oracle oinstall 1.0K Dec 30 16:41 1_28_1022686686.dbf
-rw-r----- 1 oracle oinstall 2.1M Jan 11 03:29 1_29_1022686686.dbf
-rw-r----- 1 oracle oinstall  30M Jan 31 10:56 1_30_1022686686.dbf
-rw-r----- 1 oracle oinstall 9.8M Jan 31 14:00 1_31_1022686686.dbf
-rw-r----- 1 oracle oinstall 5.6M Feb  3 23:03 1_32_1022686686.dbf
-rw-r----- 1 oracle oinstall  23M Feb  7 10:36 1_33_1022686686.dbf
-rw-r----- 1 oracle oinstall 9.8M Feb  8 06:49 1_34_1022686686.dbf
-rw-r----- 1 oracle oinstall  18M Feb 25 08:47 1_35_1022686686.dbf
-rw-r----- 1 oracle oinstall  40M Mar  3 17:12 1_36_1022686686.dbf
-rw-r----- 1 oracle oinstall 5.2M Mar  6 02:03 1_37_1022686686.dbf
-rw-r----- 1 oracle oinstall  21M Mar  9 16:15 1_38_1022686686.dbf
-rw-r----- 1 oracle oinstall 4.6M Mar 10 19:28 1_39_1022686686.dbf
-rw-r----- 1 oracle oinstall 1.7M Mar 14 02:29 1_40_1022686686.dbf
-rw-r----- 1 oracle oinstall 6.0M Mar 17 17:16 1_41_1022686686.dbf
-rw-r----- 1 oracle oinstall  33M Mar 18 15:29 1_42_1022686686.dbf
drwxr-xr-x 2 oracle oinstall 4.0K Mar 18 15:29 .
[root@linux arch]# cp 1_42_1022686686.dbf /disk1/hotbackup/
[root@linux arch]# cd /disk1/hotbackup/
[root@linux hotbackup]# ls -la
total 41128
drwxr-xr-x 3 oracle root         4096 Mar 18 15:34 .
drwxr-xr-x 5 oracle oinstall     4096 Mar 18 15:27 ..
-rw-r----- 1 root   root     34198528 Mar 18 15:34 1_42_1022686686.dbf
-rw-r----- 1 oracle oinstall  7847936 Mar 18 15:33 control.bk
drwxr-xr-x 2 root   root         4096 Mar 18 15:28 data
[root@linux hotbackup]#
======================================================================================================================
ORA-10873: file 1 needs to be either taken out of backup mode or media recovered

We are getting below ORA error message while trying to bringing up the Oracle database.

SQL> startup;
ORA-32004: obsolete or deprecated parameter(s) specified for RDBMS instance
ORACLE instance started.
 
Total System Global Area 1.7638E+10 bytes
Fixed Size 2260272 bytes
Variable Size 7985955536 bytes
Database Buffers 9596567552 bytes
Redo Buffers 53452800 bytes
Database mounted.
ORA-10873: file 1 needs to be either taken out of backup mode or media
recovered
ORA-01110: data file 1: 'D:\ORACLE\PRD\SAPDATA1\SYSTEM_1\SYSTEM.DATA1'


Solution
1. Bring down the Oracle database.

SQL> shutdown immediate;
Database dismounted.
ORACLE instance shut down.
2. Start the Oracle database in mount mode.

SQL> startup mount;
ORA-32004: obsolete or deprecated parameter(s) specified for RDBMS instance
ORACLE instance started.
 
Total System Global Area 1.7638E+10 bytes
Fixed Size 2260272 bytes
Variable Size 7985955536 bytes
Database Buffers 9596567552 bytes
Redo Buffers 53452800 bytes
Database mounted.


3. Look up the backup status.

SQL> select * from V$BACKUP;
 
FILE# STATUS CHANGE# TIME
---------- ------------------ ---------- ---------------
1 ACTIVE 347324791 21-SEP-15
2 ACTIVE 347324820 21-SEP-15
3 ACTIVE 347324835 21-SEP-15
4 ACTIVE 347324841 21-SEP-15
5 ACTIVE 347324841 21-SEP-15
6 ACTIVE 347324847 21-SEP-15
7 ACTIVE 347324847 21-SEP-15
8 ACTIVE 347324853 21-SEP-15
9 ACTIVE 347324847 21-SEP-15
10 ACTIVE 347324841 21-SEP-15
11 ACTIVE 347324841 21-SEP-15
11 rows selected.
4. End the backup state.

SQL> alter database end backup;


5. Open the database.

SQL> alter database open;





