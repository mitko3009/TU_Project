/********************************************************************************
*********       E-mail subject: KBCCFDEV-5762
*********             Instance: NOTOVAL
*********          Description: 
Problem:
The invoicing(processEvent("factcom2"), processEvent("fsif2")) took 9 hours.

Analysis:
From the analyze of the provided chkcess@A799B611 on NOTOVAL, we found that this is msg_q04.
We checked that it was working in the database under session with SID = 2001 and SERIAL = 43274 ( which is the same SID that was provided from log in the task ).
The TOP SQL for this module was f5d4v6bqvq2sz ( it was responsible for 81% of the time ).
It looks like in some situations Oracle choose bad execution plan for it, where instead of accessing table T_ECRDOS through the REFELEM, it access it through the REFDOSS, which 
leads to selecting a lot of rows. We added hint to stabilize the execution plan and to access table T_ECRDOS through the REFELEM.

Suggestion:
Please add hint as it is shown in the New SQL section below.

*********               SQL_ID: f5d4v6bqvq2sz
*********      Program/Package: 
*********              Request: Adelina Gencheva
*********               Author: Dimitar Dimitrov
********* Received e-mail date: 16/09/2024
*********      Resolution date: 16/09/2024
*********  Trace old file here: \\epox\specifs\performance\tmp\
*********  Trace new file here:
***********************************************************************************/

/********************************OLD SQL*******************************************/

VAR B1 NUMBER;
EXEC :B1 := 0
VAR B2 VARCHAR2(32);
EXEC :B2 := 'A793X8O4';
VAR B3 VARCHAR2(32);
EXEC :B3 := '';
VAR B4 VARCHAR2(32);
EXEC :B4 := '';
VAR B5 NUMBER;
EXEC :B5 := NULL
VAR B6 NUMBER;
EXEC :B6:= NULL
VAR B7 VARCHAR2(32);
EXEC :B7 := '';
VAR B8 NUMBER;
EXEC :B8 := NULL
VAR B9 NUMBER;
EXEC :B9 := NULL
VAR B10 NUMBER;
EXEC :B10 := NULL
VAR B11 NUMBER;
EXEC :B11 := NULL
VAR B12 NUMBER;
EXEC :B12 := NULL
VAR B13 NUMBER;
EXEC :B13 := NULL;
VAR B14 VARCHAR2(32);
EXEC :B14 := '';
VAR B15 VARCHAR2(32);
EXEC :B15 := '2409090002';

INSERT INTO T_ECRDOS ( REFDOSS,
                       CODECR,
                       REFELEM,
                       TYPELEM,
                       MNT_DCPT,
                       DBDU,
                       DBDU_DOS,
                       DBDEDUC,
                       DBDEDUC_DOS,
                       REFJOUR,
                       DTJOUR,
                       DATECR,
                       DTINTER,
                       LIBELLE,
                       ANCREFDOSS,
                       DEVISE_DOS )
  SELECT :B15,
         PF_CPT,
         :B2,
         'i',
         DECODE(DF_SEN,
                'D',
                DECODE(:B14,
                       'DEC',
                       NVL(:B13, DF_MONTTC_MVT),
                       NVL(:B12, DF_MONTTC)),
                -DECODE(:B14,
                        'DEC',
                        NVL(:B13, DF_MONTTC_MVT),
                        NVL(:B12, DF_MONTTC))),
         DECODE(:B11, 1, NVL(:B10, DF_MONTTC), NULL),
         DECODE(:B11, 1, NVL(:B8, DF_MONTTC_DOS), NULL),
         DECODE(:B9, 1, NVL(:B10, DF_MONTTC), NULL),
         DECODE(:B9, 1, NVL(:B8, DF_MONTTC_DOS), NULL),
         :B7,
         :B6,
         :B6,
         :B5,
         DECODE(NVL(:B4, '~xXx~xXx~'),
                '~xXx~xXx~',
                PF_LIB,
                SUBSTR(PF_LIB || ' ' || :B4, 1, 60)),
         DF_DOS,
         NVL( :B3, DF_DEVISE_MVT )
    FROM F_PARFAC PF, 
         F_DETFAC, 
         G_DOSSIER
   WHERE PF.PF_NOM = DF_NOM
     AND PF.PF_CPT IS NOT NULL
     AND REFDOSS = DF_DOS
     AND DF_NUM = :B2
     AND (   NVL(PF.PF_REFFACTOR, 'X' ) = REFFACTOR
         OR (    PF.PF_REFFACTOR IS NULL 
         	   AND NOT EXISTS ( SELECT 1
                                FROM F_PARFAC PF1
                               WHERE NVL(PF1.PF_REFFACTOR, 'X') = REFFACTOR
                                 AND PF1.PF_NOM = PF.PF_NOM ) ) )
     AND ( NOT EXISTS( SELECT 1
                         FROM T_ECRDOS ECR
                        WHERE ECR.CODECR = PF_CPT
                          AND ECR.REFDOSS = :B15
                          AND ECR.REFELEM = :B2 ) 
         OR 1 = :B1 );
/********************************OLD SQL*******************************************/
/********************************OLD Metrics***************************************/
/*
MODULE                           PROGRAM                                            CLIENT_ID       SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- -------------------------------------------------- --------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
msgq_chkcess                     msg_q04                                                                                           2001      43274 ON CPU               2024/09/14 07:40:01  2024/09/14 16:59:49       3150              16258020 +000000000 09:19:48.096 96%
msgq_chkcess                     msg_q04                                                                                           2001      43274 db file sequential r 2024/09/14 07:40:42  2024/09/14 16:59:59        120               1500365 +000000000 09:19:17.377 4%
msgq_chkcess                     msg_q04                                                            243tj6ff7v4as  514217430       2001      43274 db file parallel rea 2024/09/14 07:53:40  2024/09/14 07:53:40          1                     1 +000000000 00:00:00.000 0%


MODULE                           PROGRAM                                            CLIENT_ID       SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- -------------------------------------------------- --------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
msgq_chkcess                     msg_q04                                                                                           2001      43274                      2024/09/14 07:40:01  2024/09/14 16:59:59       3271              16258020 +000000000 09:19:58.337 100%


MODULE                           PROGRAM                                            CLIENT_ID       SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- -------------------------------------------------- --------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
msgq_chkcess                     msg_q04                                                            f5d4v6bqvq2sz 2657108927       2001      43274                      2024/09/14 08:31:13  2024/09/14 16:46:30       2648                203290 +000000000 08:15:17.309 81%
msgq_chkcess                     msg_q04                                                            579pc27w27zjy  555409519       2001      43274 ON CPU               2024/09/14 07:40:32  2024/09/14 16:54:52         54               2079674 +000000000 09:14:20.412 2%
msgq_chkcess                     msg_q04                                                            9fyzycp9a53r3 4145146419       2001      43274 ON CPU               2024/09/14 07:40:01  2024/09/14 16:55:33         46               2511392 +000000000 09:15:32.099 1%
msgq_chkcess                     msg_q04                                                            61qmffqa19hmu 2422122865       2001      43274 ON CPU               2024/09/14 08:32:14  2024/09/14 16:38:39         38                198026 +000000000 08:06:24.832 1%
msgq_chkcess                     msg_q04                                                                                   0       2001      43274 ON CPU               2024/09/14 07:42:55  2024/09/14 16:50:57         34                       +000000000 09:08:01.536 1%


INSTANCE_NUMBER SQL_ID            ELAPSED MAX_WAIT_ON     PC_OF  WAIT_TIME            GETS      READS       ROWS  ELAP/EXEC       GETS/EXEC READS/EXEC  ROWS/EXEC       EXEC PLAN_HASH_VALUE
--------------- ------------- ----------- --------------- ----- ---------- --------------- ---------- ---------- ---------- --------------- ---------- ---------- ---------- ---------------
              1 f5d4v6bqvq2sz       27754 CPU             99%   26647.6088      6616470497      58113     203659        .14           32488        .29          1     203659      2657108927


SQL_ID        SQL_PLAN_HASH_VALUE SQL_PLAN_LINE_ID SQL_PLAN_OPERATION             SQL_PLAN_OPTIONS                   ACTIVE
------------- ------------------- ---------------- ------------------------------ ------------------------------ ----------
f5d4v6bqvq2sz          2657108927               12 TABLE ACCESS                   BY INDEX ROWID BATCHED               1560
f5d4v6bqvq2sz          2657108927               13 INDEX                          SKIP SCAN                            1054
f5d4v6bqvq2sz          2657108927                  INSERT STATEMENT                                                      31
f5d4v6bqvq2sz          2657108927                                                                                         1
f5d4v6bqvq2sz          2657108927                2 FILTER                                                                 1
f5d4v6bqvq2sz          2657108927               10 INDEX                          RANGE SCAN                              1



Plan hash value: 2679716247
-----------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                | Name         | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  |
-----------------------------------------------------------------------------------------------------------------------------------------
|   0 | INSERT STATEMENT                         |              |      1 |        |     3 (100)|      0 |00:00:00.01 |      15 |      3 |
|   1 |  LOAD TABLE CONVENTIONAL                 | T_ECRDOS     |      1 |        |            |      0 |00:00:00.01 |      15 |      3 |
|*  2 |   FILTER                                 |              |      1 |        |            |      0 |00:00:00.01 |      15 |      3 |
|   3 |    NESTED LOOPS                          |              |      1 |      1 |     3   (0)|      1 |00:00:00.01 |      11 |      1 |
|   4 |     NESTED LOOPS                         |              |      1 |      1 |     3   (0)|      1 |00:00:00.01 |      10 |      1 |
|   5 |      NESTED LOOPS                        |              |      1 |      1 |     2   (0)|      1 |00:00:00.01 |       9 |      1 |
|   6 |       TABLE ACCESS BY INDEX ROWID BATCHED| F_DETFAC     |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       4 |      1 |
|*  7 |        INDEX RANGE SCAN                  | DETFAC_NUM   |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |      0 |
|   8 |       TABLE ACCESS BY INDEX ROWID        | G_DOSSIER    |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       5 |      0 |
|*  9 |        INDEX UNIQUE SCAN                 | DOS_REFDOSS  |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       2 |      0 |
|* 10 |      INDEX RANGE SCAN                    | PARFAC_CL1   |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       1 |      0 |
|* 11 |     TABLE ACCESS BY INDEX ROWID          | F_PARFAC     |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       1 |      0 |
|* 12 |    TABLE ACCESS BY INDEX ROWID BATCHED   | T_ECRDOS     |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       4 |      2 |
|* 13 |     INDEX RANGE SCAN                     | TECR_REFELEM |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |      1 |
|* 14 |    INDEX SKIP SCAN                       | PARFAC_CL1   |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
-----------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   2 - filter(((1=:B1 OR  IS NULL) AND ("REFFACTOR"=NVL("PF"."PF_REFFACTOR",'X') OR ("PF"."PF_REFFACTOR" IS NULL AND  IS NULL))))
   7 - access("DF_NUM"=:B2)
   9 - access("REFDOSS"="DF_DOS")
  10 - access("PF"."PF_NOM"="DF_NOM")
  11 - filter("PF"."PF_CPT" IS NOT NULL)
  12 - filter(("ECR"."REFDOSS"=:B15 AND "ECR"."CODECR"=:B1))
  13 - access("ECR"."REFELEM"=:B2)
  14 - access("PF1"."PF_NOM"=:B1)
       filter(NVL("PF1"."PF_REFFACTOR",'X')=:B1)
*/
/********************************OLD Metrics***************************************/

/********************************New SQL*******************************************/

INSERT INTO T_ECRDOS ( REFDOSS,
                       CODECR,
                       REFELEM,
                       TYPELEM,
                       MNT_DCPT,
                       DBDU,
                       DBDU_DOS,
                       DBDEDUC,
                       DBDEDUC_DOS,
                       REFJOUR,
                       DTJOUR,
                       DATECR,
                       DTINTER,
                       LIBELLE,
                       ANCREFDOSS,
                       DEVISE_DOS )
  SELECT :B15,
         PF_CPT,
         :B2,
         'i',
         DECODE(DF_SEN,
                'D',
                DECODE(:B14,
                       'DEC',
                       NVL(:B13, DF_MONTTC_MVT),
                       NVL(:B12, DF_MONTTC)),
                -DECODE(:B14,
                        'DEC',
                        NVL(:B13, DF_MONTTC_MVT),
                        NVL(:B12, DF_MONTTC))),
         DECODE(:B11, 1, NVL(:B10, DF_MONTTC), NULL),
         DECODE(:B11, 1, NVL(:B8, DF_MONTTC_DOS), NULL),
         DECODE(:B9, 1, NVL(:B10, DF_MONTTC), NULL),
         DECODE(:B9, 1, NVL(:B8, DF_MONTTC_DOS), NULL),
         :B7,
         :B6,
         :B6,
         :B5,
         DECODE(NVL(:B4, '~xXx~xXx~'),
                '~xXx~xXx~',
                PF_LIB,
                SUBSTR(PF_LIB || ' ' || :B4, 1, 60)),
         DF_DOS,
         NVL( :B3, DF_DEVISE_MVT )
    FROM F_PARFAC PF, 
         F_DETFAC, 
         G_DOSSIER
   WHERE PF.PF_NOM = DF_NOM
     AND PF.PF_CPT IS NOT NULL
     AND REFDOSS = DF_DOS
     AND DF_NUM = :B2
     AND (   NVL(PF.PF_REFFACTOR, 'X' ) = REFFACTOR
         OR (    PF.PF_REFFACTOR IS NULL 
         	   AND NOT EXISTS ( SELECT 1
                                FROM F_PARFAC PF1
                               WHERE NVL(PF1.PF_REFFACTOR, 'X') = REFFACTOR
                                 AND PF1.PF_NOM = PF.PF_NOM ) ) )
     AND ( NOT EXISTS( SELECT /*+ index(ECR TECR_REFELEM) */
                              1
                         FROM T_ECRDOS ECR
                        WHERE ECR.CODECR = PF_CPT
                          AND ECR.REFDOSS = :B15
                          AND ECR.REFELEM = :B2 ) 
         OR 1 = :B1 );
/********************************New SQL*******************************************/
/********************************New Metrics***************************************/
/*
-- No change in the execution plan


*/
/********************************New Metrics***************************************/

/********************************Index statistics**********************************/

/********************************Other SQLs****************************************/          
/*

*/ 
/********************************Other SQLs****************************************/              
