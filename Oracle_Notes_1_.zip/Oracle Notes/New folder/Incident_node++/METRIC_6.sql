﻿######################################### Za m0006 tablespace ############################################16 and 26 are the same like 6
####  1.Kachvam se na syrvara
####  2.Switch kato root (nsu)
####  3.ps -ef | grep pmon   (Da proverq kolko bazi i kakwi ima tuk,i koi e user-a)


[root@clv100503 ~]# ps -ef | grep pmon
oracle   19224     1  0 May06 ?        00:01:45 ora_pmon_DIGIS_PS


####  4.dbspicao -m6 -r1 -i (imeto na bazata)   (proverqwam 6-ta metrika na tazi baza)

[root@clv100503 ~]# dbspicao -m6 -r1 -i DIGIS_PS


                    Report For Database DIGIS_PS

                      Tue 21 May 2019 10:34:37 AM CEST

                    Metric TblSpaceFreePctCnt (0006)

                                    DATA FILE        FREE       FILE SYSTEM
TABLESPACE_NAME                     SPACE (MB)       SPACE (MB) SPACE (MB)    PERCENT FREE   AUTOEXTEND
---------------------------------- ---------------- ----------- ------------  ------------   ----------
DIGIS_LOBS                        238500.00         5584.56      35500.00        14.99           YES
SYSAUX                              2420.00          155.75       5580.00        71.70           YES
SYSTEM                               840.00            1.25       7160.00        89.52           YES
DIGIS_TABLES                        5700.00          281.75      90300.00        94.36           YES
DIGIS_INDEXES                       2400.00          193.25      93600.00        97.70           YES
AUDTBS                               100.00           44.19       3900.00        98.60           YES
DBA_MONITOR                           20.00            4.75       3980.00        99.62           YES
USERS                                 30.00           20.62       3970.00        99.77           YES
DBA_TABLES                            10.00            9.00       3990.00        99.98           YES


#### 6. Kato root:   ####### Проверявам всяка файлова колко е заетото и колко е свободното място,което има в Gb
### Linux ---> df -h
### HP-UX


df -Pk | awk '
BEGIN {print "Filesystem                   \t Total GB  \t Avail GB \t Used GB\t Used%\t Mount Point"
       print "-------------------------------\t ------------\t ------------\t ------------\t ------\t -----------------------------"}
END {print ""}
/dev/ || /^[0-9a-zA-Z.]*:\// {
printf ("%-25s\t %10.2fG\t %10.2fG\t %10.2fG\t %4.0f%%\t %-25s\n",$1,$2/1024/1024,$4/1024/1024,$3/1024/1024,$5,$6)
}'


#### 7. Switch kato user-a,v sluchaia "oracle"

[root@clv100503 ~]# su - oracle



#### 8. Setvam enviroment-a kato vyvejdam imeto na dadenata baza (DIGIS_PS)

$ . oraenv
ORACLE_SID = [OVEDWR_P] ? DIGIS_PS
The Oracle base remains unchanged with value /oracle
[oracle(DIGIS_PS)@clv100503:/home/oracle]


#### 9. Kachvam se na bazata:

$ sqlplus / as sysdba


##### 10.Proverqvam dali sym na pravilnata baza:

SQL> show parameter name         -------.> and SQL> show parameter unique


##### 11.Run-vam tozi script za da mi izkara kakvi sa failovete v  tpzi tablespace i razmeri:

set linesize 400
set pages 500
col FILE_NAME for a72
col TABLESPACE_NAME for a30
select file_id,FILE_NAME, TABLESPACE_NAME, (increment_by*(bytes/blocks))/1024 increment_by_kb, BYTES/1024/1024, MAXBYTES/1024/1024, 
AUTOEXTENSIBLE from dba_data_files where TABLESPACE_NAME='&tablespace_name';


##### Чек при 18C
SQL> select * from DBA_TABLESPACE_USAGE_METRICS;


#######
show parameter create          #### Най-вече за бази,които нямат ASM


##### 12.Izpylnqvam sledvashtata komanda s syotwetniq pyt na tablespace za da vidq kolko mqsto iima v failovata sistema: 

SQL> !df -h /oracle/oradata/DIGIS_PS/dbfiles1
Filesystem                     Size  Used Avail Use% Mounted on
/dev/mapper/vg_app-lv_app_u32  410G  248G  163G  61% /u32

====================================================================
####### 6 METRIC (df) - +ASM +DATA - !Checking free space. 

set linesize 333
column pct_free format 99.99
select group_number, name, total_mb, free_mb, total_mb -free_mb used_mb, case when total_mb=0 then 0 else  free_mb/total_mb *100 end pct_free from v$asm_diskgroup
/




##################
SELECT NAME FROM V$DATAFILE;



########
SQL> alter system set db_create_file_dest='+DATA1';


/////////////////////////////////////////////////

### Diskgroup free space and usage space

set lines 300
col Name for a25
select NAME,SPACE_LIMIT/1024/1024/1024 "SPACE LIMIT(GB)",
round(SPACE_USED/1024/1024/1024) "SPACE USED(GB)",round(SPACE_RECLAIMABLE/1024/1024/1024) "SPACE RECLAIMABLE(GB)",NUMBER_OF_FILES
from V$RECOVERY_FILE_DEST;



### Check ASM SPACE/STORAGE:

column pct_free format 99.99
select group_number, name, total_mb, free_mb, total_mb -free_mb used_mb,
case when total_mb=0 then 0 else  free_mb/total_mb *100 end pct_free
from v$asm_diskgroup
/



######################################
select b.tablespace_name, tbs_size "SIZE GB", a.free_space "FREE GB"
from  (select tablespace_name, round(sum(bytes)/1024/1024/1024 ,2) as free_space
from dba_free_space
group by tablespace_name) a,
(select tablespace_name, sum(bytes)/1024/1024/1024 as tbs_size
from dba_data_files
group by tablespace_name) b
where a.tablespace_name(+)=b.tablespace_name
and a.tablespace_name in ('FLSTP11')
order by a.tablespace_name;


########################################
set lines 400
set pages 1000
col FILE_NAME for a80
select t.FILE_NAME,t.AUTOEXTENSIBLE,t.FILE_ID,t.TABLESPACE_NAME,t.BYTES /1024/1024 "MB", t.MAXBYTES /1024/1024 "MAX_MB" from dba_data_files t
where t.TABLESPACE_NAME in ('FLSTP11'); 

========================================================================

######  SELECT name, free_mb, total_mb, free_mb/total_mb*100 as percentage FROM v$asm_diskgroup;
   
   
#### Check for BIG datafile tablespace
select name, bigfile from v$tablespace;   
   

#####  13.Vijdam,che ima i pravq nov file:

##### AUTOEXTEND YES ######
SQL> alter tablespace REORG_TS add datafile '/oracle/oradata/OVEDWS_P/dbfiles1/reorg_ts_05.dbf' size 1000M autoextend on next 102400K maxsize unlimited;

SQL> alter tablespace ARCHDOC2016 add datafile 'F:\DATA\USYS\ARCHDOC201612.DBF' size 100M autoextend on next 10240K maxsize unlimited;

SQL> alter tablespace SPRO2_DAT_OBJ add datafile '+DATA2' size 1000M autoextend on maxsize unlimited;             #### kogato e ASM ili OMF s sami naimenuvashti se failove 


##### AUTOEXTEND  NO  ######
SQL> alter tablespace ABACUS360_TBS add datafile '/prd/PMEL/ora_data/abacus360_tbs_66.dbf' size 65535M;           #### kogato e ASM ili OMF s sami naimenuvashti se failove i autoextend NO               
SQL> alter tablespace FLSTP11_IDX add datafile size 30G;
alter tablespace FLSTP11 add datafile size 30G;




######## ili ako extendvam datafile-a maxsiza ####
alter database datafile 13 autoextend on maxsize 13000M;
alter database datafile 46 autoextend ON next 102400K maxsize 29840M;
alter database datafile 535 size 20000M autoextend on maxsize 32767.9844M;

####### RESIZING .dbf FILES autoextend NO
alter database datafile 111 resize 32767M;
alter database datafile 35 resize 27978M;


##### Объркано създаден файл като локация. От 12 версия нагоре можем online да мнестим създадени файлове
но трябва да сме много бързи преди да е почнало да пише базата в него. Move datafile!!!!!!!

alter tablespace DOM2_TIMESERIES_INDX add datafile 'FLASH2' size 100M autoextend on maxsize unlimited;   ----->  трябваше да сложа '+FLASH2'

        20 +FLASH/ARAMPROD/DATAFILE/dom2_timeseries_indx.281.1012756661             DOM2_TIMESERIES_INDX                      1024             237         32767.9844 YES
        21 +FLASH/ARAMPROD/DATAFILE/dom2_timeseries_indx.282.1012756681             DOM2_TIMESERIES_INDX                      1024             237         32767.9844 YES
       166 +DATA/ARAMDEV/DATAFILE/dom2_timeseries_indx.289.1014992167               DOM2_TIMESERIES_INDX                         0              10                  0 NO
 --->      205 /oracle/product/12.2.0/dbhome_1/dbs/FLASH2                               DOM2_TIMESERIES_INDX                         8             100         32767.9844 YES

18 rows selected.

SQL>
SQL> alter database move datafile 205 to '+FLASH2';

Database altered.

   FILE_ID FILE_NAME                                                                TABLESPACE_NAME                INCREMENT_BY_KB BYTES/1024/1024 MAXBYTES/1024/1024 AUT
---------- ------------------------------------------------------------------------ ------------------------------ --------------- --------------- ------------------ ---
       205 +FLASH2/ARAMDEV/DATAFILE/dom2_timeseries_indx.1096.1044382135            DOM2_TIMESERIES_INDX                         8             100         32767.9844 YES








13. Izpylnqvam kato ROOT proverka dali PERCENT FREE se e uvelichilo:


[root@clv100503 ~]# dbspicao -m6 -r1 -i DIGIS_PS


                    Report For Database DIGIS_PS

                      Tue 21 May 2019 10:45:42 AM CEST

                    Metric TblSpaceFreePctCnt (0006)

                                    DATA FILE        FREE       FILE SYSTEM
TABLESPACE_NAME                     SPACE (MB)       SPACE (MB) SPACE (MB)    PERCENT FREE   AUTOEXTEND
---------------------------------- ---------------- ----------- ------------  ------------   ----------
DIGIS_LOBS                        239500.00         6583.56      50500.00        19.68           YES
SYSAUX                              2420.00          155.69       5580.00        71.70           YES
SYSTEM                               840.00            1.25       7160.00        89.52           YES
DIGIS_TABLES                        5700.00          281.75      90300.00        94.36           YES
DIGIS_INDEXES                       2400.00          193.25      93600.00        97.70           YES
AUDTBS                               100.00           44.19       3900.00        98.60           YES
DBA_MONITOR                           20.00            4.75       3980.00        99.62           YES
USERS                                 30.00           20.62       3970.00        99.77           YES
DBA_TABLES                            10.00            9.00       3990.00        99.98           YES



#############################################
#############################################
#############################################

select count(SESSION_NUM) Sessions, tablespace Temp_Tablespace from v$sort_usage group by TABLESPACE;


/opt/oracle/util/mlpx/rc_mon ------> oramoncfg ima edin file v tazi directoriq
tam gi pishe
другата е тука: /var/opt/OV/conf/OpC 

SQL> select TABLESPACE_NAME from DBA_TABLESPACE_USAGE_METRICS where USED_PERCENT between 90 and 100;


######## M6 IN QUERY ###  Ако dbspicao -m6 не работи


set lines 250
set pages 40
col 1 noprint;
break on 1
compute sum of megs_alloc on 1
compute sum of megs_free on 1
compute sum of megs_used on 1
compute sum of megs_max on 1
select 1, a.tablespace_name,
       round(a.bytes_alloc / 1024 / 1024, 2) megs_alloc,
       round(nvl(b.bytes_free, 0) / 1024 / 1024, 2) megs_free,
       round((a.bytes_alloc - nvl(b.bytes_free, 0)) / 1024 / 1024, 2) megs_used,
       round((nvl(b.bytes_free, 0) / a.bytes_alloc) * 100,2) Pct_Free,
       100 - round((nvl(b.bytes_free, 0) / a.bytes_alloc) * 100,2) Pct_used,
       round(maxbytes/1048576,2) Megs_max,
      round(100*(round((a.bytes_alloc - nvl(b.bytes_free, 0)) / 1024 / 1024, 2))/(round(maxbytes/1048576,2)),2) pct_used_max
from ( select f.tablespace_name,
               sum(f.bytes) bytes_alloc,
               sum(decode(f.autoextensible, 'YES', CASE WHEN f.maxbytes >= f.bytes THEN f.maxbytes ELSE f.bytes END, 'NO', f.bytes)) maxbytes
        from dba_data_files f
        group by tablespace_name) a,
      ( select f.tablespace_name,
               sum(f.bytes) bytes_free
        from dba_free_space f
        group by tablespace_name) b
where a.tablespace_name = b.tablespace_name (+)
union
select 1, h.tablespace_name,
       round(sum(h.bytes_free + h.bytes_used) / 1048576, 2),
       round(sum((h.bytes_free + h.bytes_used) - nvl(p.bytes_used, 0)) / 1048576, 2),
       round(sum(nvl(p.bytes_used, 0))/ 1048576, 2) megs_used,
       round((sum((h.bytes_free + h.bytes_used) - nvl(p.bytes_used, 0)) / sum(h.bytes_used + h.bytes_free)) * 100,2),
       100 - round((sum((h.bytes_free + h.bytes_used) - nvl(p.bytes_used, 0)) / sum(h.bytes_used + h.bytes_free)) * 100,2),
       round(sum(decode(f.autoextensible, 'YES', CASE WHEN f.maxbytes >= (h.bytes_used + h.bytes_free) THEN f.maxbytes ELSE (h.bytes_used + h.bytes_free) END, 'NO', f.bytes)) / 1048576, 2) Max,
       round(100*(round(sum(nvl(p.bytes_used, 0))/ 1048576, 2))/(round(sum(decode(f.autoextensible, 'YES', CASE WHEN f.maxbytes >= (h.bytes_used + h.bytes_free) THEN f.maxbytes ELSE (h.bytes_used + h.bytes_free) END, 'NO', f.bytes)) / 1048576, 2)),2)
from sys.v_$TEMP_SPACE_HEADER h, sys.v_$Temp_extent_pool p, dba_temp_files f
where p.file_id(+) = h.file_id
and p.tablespace_name(+) = h.tablespace_name
and h.file_id = f.file_id
and h.tablespace_name = f.tablespace_name
group by h.tablespace_name
ORDER BY PCT_USED_MAX desc;



########################################
#########################################
 ##### NEW View m6 

set linesize 100 pages 100 trimspool on numwidth 14
col name format a25
col owner format a15
col "Used (GB)" format a15
col "Free (GB)" format a15
col "(Used) %" format a15
col "Size (M)" format a15
SELECT d.status "Status", d.tablespace_name "Name",
TO_CHAR(NVL(a.bytes / 1024 / 1024 / 1024, 0),'99,999,990.90') "Size (GB)",
TO_CHAR(NVL(a.bytes - NVL(f.bytes, 0), 0)/1024/1024/1024,'99999999.99') "Used (GB)",
TO_CHAR(NVL(f.bytes / 1024 / 1024 / 1024, 0),'99,999,990.90')"Free (GB)",
TO_CHAR(NVL((a.bytes - NVL(f.bytes, 0)) / a.bytes * 100, 0), '900.00') "(Used) %"
FROM sys.dba_tablespaces d,
(select tablespace_name, sum(bytes) bytes from dba_data_files group by tablespace_name) a,
(select tablespace_name, sum(bytes) bytes from dba_free_space group by tablespace_name) f WHERE
d.tablespace_name = a.tablespace_name(+) AND d.tablespace_name = f.tablespace_name(+) AND NOT
(d.extent_management like 'LOCAL' AND d.contents like 'TEMPORARY')
UNION ALL
SELECT d.status
"Status", d.tablespace_name "Name",
TO_CHAR(NVL(a.bytes / 1024 /1024 /1024, 0), '99,999,990.90') "Size (GB)",
TO_CHAR(NVL(t.bytes,0)/1024/1024 /1024, '99999999.99') "Used (GB)",
TO_CHAR(NVL((a.bytes -NVL(t.bytes,0)) / 1024 / 1024 /1024, 0), '99,999,990,90') "Free (GB)",
TO_CHAR(NVL(t.bytes / a.bytes * 100, 0), '990.00') "(Used) %"
FROM sys.dba_tablespaces d,
(select tablespace_name, sum(bytes) bytes from dba_temp_files group by tablespace_name) a,
(select tablespace_name, sum(bytes_cached) bytes from v$temp_extent_pool group by tablespace_name) t
WHERE d.tablespace_name = a.tablespace_name(+) AND d.tablespace_name = t.tablespace_name(+) AND
d.extent_management like 'LOCAL'AND d.contents like 'TEMPORARY';


#############################
############################

#### Check table space size in GB

SELECT /* + RULE */
	df.tablespace_name AS "Tablespace"
	,df.bytes / (1024 * 1024 * 1024) AS "Size (GB)"
	,Trunc(fs.bytes / (1024 * 1024 * 1024)) AS "Free (GB)"
FROM (
	SELECT tablespace_name
		,Sum(bytes) AS bytes
	FROM dba_free_space
	GROUP BY tablespace_name
	) fs
	,(
		SELECT tablespace_name
			,SUM(bytes) AS bytes
		FROM dba_data_files
		GROUP BY tablespace_name
		) df
WHERE fs.tablespace_name = df.tablespace_name
ORDER BY 3 DESC;

#######################
#############################

################## CHECK TABLESPACE USAGE: #####################

select s.username "USER",s.sid,s.osuser,
u.tablespace "TS" ,
sum(u.blocks) * &BLOCK_SIZE./1024/1024 MB,
x.sql_text
from v$session s,v$sort_usage u,v$sqltext x
where s.saddr=u.session_addr and s.sql_address=x.address
group by s.sid, s.username, osuser, tablespace, sql_text, address, piece
order by sid, piece asc;


#################################
##################################

#### OBJECTS IN TABLESPACE ###

set pages 1000
Set lines 400
col OWNER for a30
col SEGMENT_NAME for a30
select owner, segment_name, segment_type, bytes /1024/1024 MB 
from dba_segments where tablespace_name ='SYSAUX'  ORDER BY MB; 

############################
###########################

##############  STATUS OF TABLESPACE ##########

SELECT NAME,
    FILE#,
    STATUS,
    CHECKPOINT_CHANGE# "CHECKPOINT"   
  FROM   V$DATAFILE_HEADER;


###############################
################################

UNDO FREESPACE

select a.tablespace_name, SIZEMB, USAGEMB, (SIZEMB - USAGEMB) FREEMB
from (select sum(bytes) / 1024 / 1024 SIZEMB, b.tablespace_name
from dba_data_files a, dba_tablespaces b
where a.tablespace_name = b.tablespace_name
and b.contents = 'UNDO'
group by b.tablespace_name) a,
(select c.tablespace_name, sum(bytes) / 1024 / 1024 USAGEMB
from DBA_UNDO_EXTENTS c
where status <> 'EXPIRED'
group by c.tablespace_name) b
where a.tablespace_name = b.tablespace_name; 


###################################
####################################

SYSAUX tablespace
 
1.	Check  all table spaces (the long query) 
2.	Check utilization of tablespace SYSAUX/SYSTEM
3.	Check  tablespace SYSAUX/SYSTEM usage with 
 select occupant_desc, space_usage_kbytes/1024 as usage_MB from v$sysaux_occupants where space_usage_kbytes > 0 order by space_usage_kbytes desc;

4.	Send email to DL and PDL to perform housekeeping
 