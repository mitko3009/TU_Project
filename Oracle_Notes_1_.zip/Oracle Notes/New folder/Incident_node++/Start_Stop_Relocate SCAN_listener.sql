####################################################################################
#########  Start/ Stop / Relocate SCAN listener in Oracle 11gR2 RAC


1) Check listener status ( login to grid home)

a) Check the cluster resource status
$ crsctl stat res -t

verify the output for listener
--------------------------------------------------------------------------------
NAME           TARGET  STATE        SERVER                   STATE_DETAILS    
--------------------------------------------------------------------------------
Local Resources
--------------------------------------------------------------------------------
ora.DATA.dg
               ONLINE  ONLINE       node1                                      
               ONLINE  ONLINE       node2                                      
ora.FRA.dg
               ONLINE  ONLINE       node1                                      
               ONLINE  ONLINE       node2                                      
ora.LISTENER.lsnr
               ONLINE  ONLINE       node1                                      
               ONLINE  ONLINE       node2                                      
ora.asm
               ONLINE  ONLINE       node1                    Started          
               ONLINE  ONLINE       node2                    Started          
ora.gsd
               OFFLINE OFFLINE      node1                                      
               OFFLINE OFFLINE      node2                                      
ora.net1.network
               ONLINE  ONLINE       node1                                      
               ONLINE  ONLINE       node2                                      
ora.ons
               ONLINE  ONLINE       node1                                      
               ONLINE  ONLINE       node2                                      
ora.registry.acfs
               ONLINE  ONLINE       node1                                      
               ONLINE  ONLINE       node2                                      
--------------------------------------------------------------------------------
Cluster Resources
--------------------------------------------------------------------------------
ora.LISTENER_SCAN1.lsnr
      1        ONLINE  ONLINE       node2                                      
ora.LISTENER_SCAN2.lsnr
      1        ONLINE  ONLINE       node1                                      
ora.LISTENER_SCAN3.lsnr
      1        ONLINE  ONLINE       node1                                      
ora.cvu
      1        ONLINE  ONLINE       node1                                      
ora.node1.vip
      1        ONLINE  ONLINE       node1                                      
ora.node2.vip
      1        ONLINE  ONLINE       node2                                      
ora.PROD.db
      1        ONLINE  ONLINE       node1                    Open              
      2        ONLINE  ONLINE       node2                    Open              
ora.oc4j
      1        ONLINE  ONLINE       node1                                      
ora.scan1.vip
      1        ONLINE  ONLINE       node2                                      
ora.scan2.vip
      1        ONLINE  ONLINE       node1                                      
ora.scan3.vip
      1        ONLINE  ONLINE       node1

b) Check the scan listener status

$ srvctl status scan_listener

SCAN Listener LISTENER_SCAN1 is enabled
SCAN listener LISTENER_SCAN1 is running on node node2
SCAN Listener LISTENER_SCAN2 is enabled
SCAN listener LISTENER_SCAN2 is running on node node1
SCAN Listener LISTENER_SCAN3 is enabled
SCAN listener LISTENER_SCAN3 is running on node node1

c) Check the listener home. That sholud run in grid home:

LSNRCTL for IBM/AIX RISC System/6000: Version 11.2.0.3.0 - Production on 13-DEC-2014 14:02:27
Copyright (c) 1991, 2011, Oracle.  All rights reserved.
Connecting to (ADDRESS=(PROTOCOL=tcp)(HOST=)(PORT=1521))
STATUS of the LISTENER
------------------------
Alias                     LISTENER
Version                   TNSLSNR for IBM/AIX RISC System/6000: Version 11.2.0.3.0 - Production
Start Date                19-AUG-2014 21:46:52
Uptime                    115 days 16 hr. 15 min. 34 sec
Trace Level               off
Security                  ON: Local OS Authentication
SNMP                      ON
Listener Parameter File   /u01/app/grid/network/admin/listener.ora
Listener Log File         /u01/app/oracle/diag/tnslsnr/node1/listener/alert/log.xml
Listening Endpoints Summary...
  (DESCRIPTION=(ADDRESS=(PROTOCOL=ipc)(KEY=LISTENER)))
  (DESCRIPTION=(ADDRESS=(PROTOCOL=tcp)(HOST=10.20.30.40)(PORT=1521)))
  (DESCRIPTION=(ADDRESS=(PROTOCOL=tcp)(HOST=10.20.30.41)(PORT=1521)))
Services Summary...
Service "+ASM" has 1 instance(s).
  Instance "+ASM1", status READY, has 1 handler(s) for this service...
Service "PROD" has 1 instance(s).
  Instance "PROD1", status READY, has 1 handler(s) for this service...
Service "PRODXDB" has 1 instance(s).
  Instance "PROD1", status READY, has 1 handler(s) for this service...
The command completed successfully




2) Start scan listener:

a) Start scan listener

$ srvctl start scan_listener

b) If lsnrctl status showing rdbms home, then do the following

$ lsnrctl stop
$ export ORACLE_HOME=/u01/app/grid
$ lsnrctl start



3) Relocate SCAN listener

a) To relocate
When you find all 3 scan listeners are running on single node, then you may relocate any one of the listener

$ srvctl relocate scan_LISTENER -i 1 -n node2

b) Check current status after Relocate SCAN_LISTENER:

bash-3.2$ srvctl status scan_listener
SCAN Listener LISTENER_SCAN1 is enabled
SCAN listener LISTENER_SCAN1 is running on node node2
SCAN Listener LISTENER_SCAN2 is enabled
SCAN listener LISTENER_SCAN2 is running on node node1
SCAN Listener LISTENER_SCAN3 is enabled
SCAN listener LISTENER_SCAN3 is running on node node1

c) inherit status

$ ps -ef|grep inherit
  oracle 49741838  9633998   0 14:10:00  pts/0  0:00 grep inherit
  oracle 18547030        1   0 13:26:56      -  0:00 /u01/app/grid/bin/tnslsnr LISTENER_SCAN1 -inherit
  oracle 31588762        1   0 13:20:20      -  0:14 /u01/app/grid/bin/tnslsnr LISTENER -inherit


So What is difference is between relocating the SCAN using srvctl relocate scan and SCAN_LISTENER  by using srvctl relocate scan_listener command?

Regarding questions; The difference between a SCAN VIP and a normal RAC VIP, is that the RAC VIP has a node it want’s to run on and each node has one (whereas you only have 3 SCANs). 
If it fails over to another node, the normal VIP exists, but does not accept connections, whereas the SCAN is not fix to a node and can run on any node in the cluster (and will accept connections anytime).

Now that this works, the SCAN VIP will always move with the SCAN listener (otherwise it would not make any sense). 
Hence there is really no difference in moving the SCAN VIP (because this will trigger a relocate of the listener) 
or to move the SCAN_Listener (since this will move the VIP it depends on).



3) Checking SCAN IPs

$ srvctl config scan

SCAN name: scandb.production.com, Network: 1/10.20.30.0/255.255.255.192/en8
SCAN VIP name: scan1, IP: /scandb.production.com/10.20.30.42
SCAN VIP name: scan2, IP: /scandb.production.com/10.20.30.43
SCAN VIP name: scan3, IP: /scandb.production.com/10.20.30.44