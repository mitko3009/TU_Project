OUTPUT
----------------------------------------------------------------------------------------------------------------------------------


connected to target database: P55016 (DBID=3276966882)
connected to recovery catalog database
recovery catalog schema release 12.02.00.01. is newer than RMAN release

=========
CAUSE
The catalog schema version is different from the rman executable version.
Version of RMAN client (RMAN executable) displayed when you start RMAN
Run the below command as rman catalog schema owner to find the catalog schema version
SQL> SELECT * FROM rcver;
=========

!!!!!!!!!!!
Start SQL*Plus and connect to the recovery catalog database as the catalog owner. For example:

% sqlplus rman/cat@catdb

Query the RCVER table to obtain the schema version, as in the following example (sample output included):

SELECT *
FROM rcver;

VERSION
------------
09.02.00

RMAN Backup and Upgrading the Recovery Catalog 
It is good practice to have the catalog the same version as the RMAN client you are using. This ensures the complete compatibility between the two of them. However, if the recovery catalog is older than the RMAN client that you are using, then it is a must that you upgrade the recovery catalog to match with the clients version.

To determine the version of the catalog, connect to the recovery catalog using the catalog owners credentials and issue:

   SQL> select * from rcver;