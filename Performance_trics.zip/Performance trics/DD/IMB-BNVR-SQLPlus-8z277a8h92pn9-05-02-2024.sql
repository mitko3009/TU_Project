/********************************************************************************
*********       E-mail subject: IMBDEV-11630
*********             Instance: BNVR
*********          Description: 
Problem:
Patch installation took around 7 hours on IMB BNVR/DLV instances.

Analysis:
From the analyze on instance BNVR I found that the TOP SQL 8z277a8h92pn9 from module SQL*Plus is responsible for around 54% of the time.
The problem was that Oracle start the execution from column REFEXT on table G_PIECE which is not selective and generate 
inappropriate execution plan. The query should start from column GPIMARQUE on table G_PIECE because it is the most selective part. 
The solution here is to add hint to use index REFVIGN on column GPIMARQUE on table G_PIECE and start the execution from it.
This is again from the reprise_fill_group_of_same_limits_id script which was discussed in IMB-3860.

Suggestion:
This query is from ftr_request_limit.pck source.
Please add hint as it is shown in the New SQL section below.

*********               SQL_ID: 8z277a8h92pn9
*********      Program/Package: ftr_request_limit
*********              Request: Zornitsa Taskova
*********               Author: Dimitar Dimitrov
********* Received e-mail date: 05/02/2024
*********      Resolution date: 05/02/2024
*********  Trace old file here: \\epox\specifs\performance\tmp\
*********  Trace new file here:
***********************************************************************************/

/********************************OLD SQL*******************************************/

var B1 VARCHAR2(32);
exec :B1 := 'INT00000';
var B2 VARCHAR2(32);
exec :B2 := 'A600E2A8';
var B3 VARCHAR2(32);
exec :B3 := 'FIN';

SELECT GPIHEURE
  FROM G_PIECE
WHERE TYPPIECE = 'PARAM_LIMITE'
   AND GPIDEPOT = :B3
   AND REFEXT = 'DBR'
   AND GPIMARQUE = :B2
   AND GPIHEURE IS NOT NULL
   AND (GPITYPTRIB = :B1 OR (GPITYPTRIB IS NULL AND :B1 IS NULL))
   AND ROWNUM = 1;
/********************************OLD SQL*******************************************/
/********************************OLD Metrics***************************************/
/*
SQL_ID        SQL_PLAN_HASH_VALUE SQL_PLAN_LINE_ID SQL_PLAN_OPERATION             SQL_PLAN_OPTIONS                   ACTIVE
------------- ------------------- ---------------- ------------------------------ ------------------------------ ----------
8z277a8h92pn9          4036935372                2 TABLE ACCESS                   BY INDEX ROWID BATCHED               1240
8z277a8h92pn9          4036935372                3 INDEX                          RANGE SCAN                             94
8z277a8h92pn9          4036935372                1 COUNT                          STOPKEY                                 1

INSTANCE_NUMBER SQL_ID            ELAPSED MAX_WAIT_ON     PC_OF  WAIT_TIME            GETS      READS       ROWS  ELAP/EXEC       GETS/EXEC READS/EXEC  ROWS/EXEC       EXEC PLAN_HASH_VALUE
--------------- ------------- ----------- --------------- ----- ---------- --------------- ---------- ---------- ---------- --------------- ---------- ---------- ---------- ---------------
              1 8z277a8h92pn9       13881 CPU             97%   13326.8768      6320511974     925379     140113         .1           45095        6.6          1     140160      4036935372


Plan hash value: 4036935372
-------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                            | Name      | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers |
-------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                     |           |      1 |        |     5 (100)|      1 |00:00:00.07 |   31258 |
|*  1 |  COUNT STOPKEY                       |           |      1 |        |            |      1 |00:00:00.07 |   31258 |
|*  2 |   TABLE ACCESS BY INDEX ROWID BATCHED| G_PIECE   |      1 |      1 |     5   (0)|      1 |00:00:00.07 |   31258 |
|*  3 |    INDEX RANGE SCAN                  | PIE_DOUBL |      1 |      3 |     3   (0)|  71564 |00:00:00.01 |     242 |
-------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   1 - filter(ROWNUM=1)
   2 - filter(("GPIMARQUE"=:B2 AND "GPIDEPOT"=:B3 AND "GPIHEURE" IS NOT NULL AND "TYPPIECE"='PARAM_LIMITE' AND
              ("GPITYPTRIB"=:B1 OR (:B1 IS NULL AND "GPITYPTRIB" IS NULL))))
   3 - access("REFEXT"='DBR')
*/
/********************************OLD Metrics***************************************/

/********************************New SQL*******************************************/
SELECT /*+ index(G_PIECE REFVIGN) */
       GPIHEURE
  FROM G_PIECE
WHERE TYPPIECE = 'PARAM_LIMITE'
   AND GPIDEPOT = :B3
   AND REFEXT = 'DBR'
   AND GPIMARQUE = :B2
   AND GPIHEURE IS NOT NULL
   AND (GPITYPTRIB = :B1 OR (GPITYPTRIB IS NULL AND :B1 IS NULL))
   AND ROWNUM = 1;
/********************************New SQL*******************************************/
/********************************New Metrics***************************************/
/*
Plan hash value: 4042454954
--------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                            | Name    | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  |
--------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                     |         |      1 |        |     7 (100)|      1 |00:00:00.03 |       4 |      3 |
|*  1 |  COUNT STOPKEY                       |         |      1 |        |            |      1 |00:00:00.03 |       4 |      3 |
|*  2 |   TABLE ACCESS BY INDEX ROWID BATCHED| G_PIECE |      1 |      1 |     7   (0)|      1 |00:00:00.03 |       4 |      3 |
|*  3 |    INDEX RANGE SCAN                  | REFVIGN |      1 |      6 |     3   (0)|      1 |00:00:00.03 |       3 |      3 |
--------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   1 - filter(ROWNUM=1)
   2 - filter(("REFEXT"='DBR' AND "GPIDEPOT"=:B3 AND "GPIHEURE" IS NOT NULL AND "TYPPIECE"='PARAM_LIMITE' AND
              ("GPITYPTRIB"=:B1 OR (:B1 IS NULL AND "GPITYPTRIB" IS NULL))))
   3 - access("GPIMARQUE"=:B2)
*/
/********************************New Metrics***************************************/

/********************************Index statistics**********************************/

/********************************Other SQLs****************************************/          
/*

*/ 
/********************************Other SQLs****************************************/              
