﻿=========================================================================================
LSNR-0001:TNS check did not detect listener LISTENER grid, listener may be down; Error [Oracle listener LISTENER grid process not running.]. [Policy:DBMON-LSNR-0001-ARM]
==========================================================================================
###########  Start the Clusterware
###########


[root@defreon2430 ~]# ps -ef | grep tns
root       133     2  0 Aug29 ?        00:00:00 [netns]
root     13406 13178  0 09:54 pts/0    00:00:00 grep tns

[root@defreon2430 ~]# dbspicao -pdvf
-bash: dbspicao: command not found

[root@defreon2430 ~]# ps -ef | grep pmon
root     16139 13178  0 09:56 pts/0    00:00:00 grep pmon

[root@defreon2430 ~]# cat /etc/oratab


iiqQQ2:/u01/app/oracle/12.1.0.2/db_home:N        # line added by DMA
iiqQQ:/u01/app/oracle/12.1.0.2/db_home:N                # line added by Agent
+ASM2:/u01/app/12.1.0.2/grid:N          # line added by Agent                              ##### Взимаме холма нан ASM_а ######


[root@defreon2430 ~]# /u01/app/12.1.0.2/grid/bin/crsctl start crs
CRS-4640: Oracle High Availability Services is already active
CRS-4000: Command Start failed, or completed with errors.


[root@defreon2430 ~]# /u01/app/12.1.0.2/grid/bin/crsctl stop crs
CRS-2796: The command may not proceed when Cluster Ready Services is not running
CRS-4687: Shutdown command has completed with errors.
CRS-4000: Command Stop failed, or completed with errors.

[root@defreon2430 ~]# /u01/app/12.1.0.2/grid/bin/crsctl start crs
CRS-4640: Oracle High Availability Services is already active
CRS-4000: Command Start failed, or completed with errors.

[root@defreon2430 ~]# /u01/app/12.1.0.2/grid/bin/crsctl stop crs -f              ############## В случая го спираме с форс понеже се гаси и стартира с грешки #####

CRS-2791: Starting shutdown of Oracle High Availability Services-managed resources on 'defreon2430'
CRS-2673: Attempting to stop 'ora.mdnsd' on 'defreon2430'
CRS-2673: Attempting to stop 'ora.gpnpd' on 'defreon2430'
CRS-2673: Attempting to stop 'ora.crf' on 'defreon2430'
CRS-2673: Attempting to stop 'ora.evmd' on 'defreon2430'
CRS-2673: Attempting to stop 'ora.drivers.acfs' on 'defreon2430'
CRS-2677: Stop of 'ora.drivers.acfs' on 'defreon2430' succeeded
CRS-2677: Stop of 'ora.crf' on 'defreon2430' succeeded
CRS-2673: Attempting to stop 'ora.gipcd' on 'defreon2430'
CRS-2677: Stop of 'ora.mdnsd' on 'defreon2430' succeeded
CRS-2677: Stop of 'ora.gpnpd' on 'defreon2430' succeeded
CRS-2677: Stop of 'ora.evmd' on 'defreon2430' succeeded
CRS-2677: Stop of 'ora.gipcd' on 'defreon2430' succeeded
CRS-2793: Shutdown of Oracle High Availability Services-managed resources on 'defreon2430' has completed
CRS-4133: Oracle High Availability Services has been stopped.


[root@defreon2430 ~]# /u01/app/12.1.0.2/grid/bin/crsctl start crs
CRS-4123: Oracle High Availability Services has been started.


[root@defreon2430 ~]# ps -ef | grep pmon                                ####### Изчакваме малко и се моли всичко да се стартира :) ######

grid     19133     1  0 09:59 ?        00:00:00 asm_pmon_+ASM2
oracle   20461     1  0 10:00 ?        00:00:00 ora_pmon_iiqQQ2
root     20852 13178  0 10:00 pts/0    00:00:00 grep pmon

[root@defreon2430 ~]# ps -ef | grep tns
root       133     2  0 Aug29 ?        00:00:00 [netns]
grid     19701     1  0 09:59 ?        00:00:00 /u01/app/12.1.0.2/grid/bin/tnslsnr LISTENER -no_crs_notify -inherit
root     21429 13178  0 10:00 pts/0    00:00:00 grep tns



[root@defreon2430 ~]# su - grid


[grid@defreon2430 ~]$ . oraenv
ORACLE_SID = [grid] ? ASM2
ORACLE_HOME = [/home/oracle] ? /u01/app/12.1.0.2/grid
The Oracle base has been set to /u01/app/grid


[grid@defreon2430 ~]$ crsctl stat res -t
--------------------------------------------------------------------------------
Name           Target  State        Server                   State details
--------------------------------------------------------------------------------
Local Resources
--------------------------------------------------------------------------------
ora.DATA.dg
               ONLINE  ONLINE       defreon2428              STABLE
               ONLINE  ONLINE       defreon2430              STABLE
ora.LISTENER.lsnr
               ONLINE  ONLINE       defreon2428              STABLE
               ONLINE  ONLINE       defreon2430              STABLE
ora.OCR.dg
               ONLINE  ONLINE       defreon2428              STABLE
               ONLINE  ONLINE       defreon2430              STABLE
ora.RECO.dg
               ONLINE  ONLINE       defreon2428              STABLE
               ONLINE  ONLINE       defreon2430              STABLE
ora.asm
               ONLINE  ONLINE       defreon2428              Started,STABLE
               ONLINE  ONLINE       defreon2430              Started,STABLE
ora.net1.network
               ONLINE  ONLINE       defreon2428              STABLE
               ONLINE  ONLINE       defreon2430              STABLE
ora.ons
               ONLINE  ONLINE       defreon2428              STABLE
               ONLINE  ONLINE       defreon2430              STABLE
--------------------------------------------------------------------------------
Cluster Resources
--------------------------------------------------------------------------------
ora.LISTENER_SCAN1.lsnr
      1        ONLINE  ONLINE       defreon2428              STABLE
ora.MGMTLSNR
      1        OFFLINE OFFLINE                               STABLE
ora.cvu
      1        ONLINE  ONLINE       defreon2428              STABLE
ora.defreon2428.vip
      1        ONLINE  ONLINE       defreon2428              STABLE
ora.defreon2430.vip
      1        ONLINE  ONLINE       defreon2430              STABLE
ora.iiqqq.db
      1        ONLINE  ONLINE       defreon2428              STABLE
      2        ONLINE  ONLINE       defreon2430              Open,STABLE
ora.oc4j
      1        ONLINE  ONLINE       defreon2428              STABLE
ora.scan1.vip
      1        ONLINE  ONLINE       defreon2428              STABLE
--------------------------------------------------------------------------------