/********************************************************************************
*********       E-mail subject: EFEURWEB-3622
*********             Instance: PROD
*********          Description: 
Problem:
SQL 39czn16069v1g was the TOP SQL in module EXTRANET on 14/03/2024 on EFEUR PROD.

Analysis:
SQL 39czn16069v1g which is the TOP SQL was already analyzed in EFDEWEB-748. The problem now is that instead of  
accessing table G_PIECE GP through column REFPIECE and index PIE_REFPIECE, it choose to access it through column REFEXT and index PIECE_REFEXT_IDX, 
which is not selective. It needs one more hint to choose the good execution plan which has been achieved in EFDEWEB-748. 

Suggestion:
Please add hint as it is shown in the New SQL section below.

*********               SQL_ID: 39czn16069v1g
*********      Program/Package: EXTRANET
*********              Request: Dimitare Ivanov
*********               Author: Dimitar Dimitrov
********* Received e-mail date: 20/03/2024		
*********      Resolution date: 22/03/2024
*********  Trace old file here: \\epox\specifs\performance\tmp\
*********  Trace new file here:
***********************************************************************************/

/********************************OLD SQL*******************************************/

var B3 VARCHAR2(1000);
exec :B3 := 'DE04864';
var B2 VARCHAR2(128);
exec :B2 := 'A600QQ9H';
var B1 VARCHAR2(32);
exec :B1 := 'A600QMMH';
var B4 VARCHAR2(32);
exec :B4 := 'EUR';

SELECT /*+ index(REQ PIE_GPILIBLIBRE) leading(REQ) */
 NVL(CH_TAUX.CONV_ORIG_DEST_TX(TO_CHAR(SYSDATE, 'j'),
                               NVL(DET.MT01, 0),
                               GP.GPIDEVIS,
                               :B4,
                               'MR',
                               ''),
     0) AS LIMITAMOUNT,
 NVL(CH_TAUX.CONV_ORIG_DEST_TX(TO_CHAR(SYSDATE, 'j'),
                               FTR_FIN_LIMIT.GETCONSUMEDAMOUNT(GP.REFPIECE,
                                                               DET.NB04),
                               GP.GPIDEVIS,
                               :B4,
                               'MR',
                               ''),
     0) AS LIMITCONSUMED
  FROM G_PIECE REQ, 
       G_PIECE GP, 
       G_PIECEDET DET
 WHERE REQ.TYPPIECE = 'REQUEST_LIMITE'
   AND REQ.TYPEDOC = 'C'
   AND REQ.GPIADR3 = :B2
   AND REQ.GPIDEPOT = :B1
   AND REQ.GPIHEURE = :B3
   AND REQ.GPILIBLIBRE LIKE 'L1.' || :B2 || '.' || :B1 || '.%'
   AND REQ.LIBELLE_20_12 = GP.REFPIECE
   AND GP.TYPPIECE = 'PARAM_LIMITE'
   AND GP.REFEXT = 'COM'
   AND DET.REFPIECE = GP.REFPIECE
   AND DET.TYPE = 'DETAIL_LIMITE'
   AND SYSDATE BETWEEN DET.DT01_DT AND NVL(DET.DT02_DT, SYSDATE)
   AND ROWNUM = 1;
  
/********************************OLD SQL*******************************************/
/********************************OLD Metrics***************************************/
/*
Plan hash value: 933770268
-----------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                               | Name             | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers |
-----------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                        |                  |      1 |        |    20 (100)|      1 |00:00:00.54 |   94496 |
|*  1 |  COUNT STOPKEY                          |                  |      1 |        |            |      1 |00:00:00.54 |   94496 |
|   2 |   NESTED LOOPS                          |                  |      1 |      1 |    20   (0)|      1 |00:00:00.54 |   94496 |
|   3 |    NESTED LOOPS                         |                  |      1 |      1 |    20   (0)|      1 |00:00:00.54 |   94495 |
|   4 |     NESTED LOOPS                        |                  |      1 |      1 |    16   (0)|      1 |00:00:00.54 |   94491 |
|*  5 |      TABLE ACCESS BY INDEX ROWID BATCHED| G_PIECE          |      1 |      1 |    13   (0)|      1 |00:00:00.01 |       7 |
|*  6 |       INDEX RANGE SCAN                  | PIE_GPILIBLIBRE  |      1 |     27 |     3   (0)|      2 |00:00:00.01 |       3 |
|*  7 |      TABLE ACCESS BY INDEX ROWID BATCHED| G_PIECE          |      1 |      1 |     3   (0)|      1 |00:00:00.54 |   94484 |
|*  8 |       INDEX RANGE SCAN                  | PIECE_REFEXT_IDX |      1 |      1 |     2   (0)|    301K|00:00:00.09 |    1850 |
|*  9 |     INDEX RANGE SCAN                    | G_PIECEDET_REFP  |      1 |      1 |     3   (0)|      1 |00:00:00.01 |       4 |
|  10 |    TABLE ACCESS BY INDEX ROWID          | G_PIECEDET       |      1 |      1 |     4   (0)|      1 |00:00:00.01 |       1 |
-----------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   1 - filter(ROWNUM=1)
   5 - filter(("REQ"."LIBELLE_20_12" IS NOT NULL AND "REQ"."GPIHEURE"=:B3 AND "REQ"."GPIDEPOT"=:B1 AND "REQ"."GPIADR3"=:B2
              AND "REQ"."TYPPIECE"='REQUEST_LIMITE' AND "REQ"."TYPEDOC"='C'))
   6 - access("REQ"."GPILIBLIBRE" LIKE 'L1.'||:B2||'.'||:B1||'.%')
       filter("REQ"."GPILIBLIBRE" LIKE 'L1.'||:B2||'.'||:B1||'.%')
   7 - filter("REQ"."LIBELLE_20_12"="GP"."REFPIECE")
   8 - access("GP"."REFEXT"='COM' AND "GP"."TYPPIECE"='PARAM_LIMITE')
   9 - access("DET"."REFPIECE"="GP"."REFPIECE" AND "DET"."TYPE"='DETAIL_LIMITE' AND "DET"."DT01_DT"<=SYSDATE@!)
       filter(NVL("DET"."DT02_DT",SYSDATE@!)>=SYSDATE@!)
*/
/********************************OLD Metrics***************************************/

/********************************New SQL*******************************************/

SELECT  /*+ index(REQ PIE_GPILIBLIBRE) index(GP PIE_REFPIECE) leading(REQ) */
 NVL(CH_TAUX.CONV_ORIG_DEST_TX(TO_CHAR(SYSDATE, 'j'),
                               NVL(DET.MT01, 0),
                               GP.GPIDEVIS,
                               :B4,
                               'MR',
                               ''),
     0) AS LIMITAMOUNT,
 NVL(CH_TAUX.CONV_ORIG_DEST_TX(TO_CHAR(SYSDATE, 'j'),
                               FTR_FIN_LIMIT.GETCONSUMEDAMOUNT(GP.REFPIECE,
                                                               DET.NB04),
                               GP.GPIDEVIS,
                               :B4,
                               'MR',
                               ''), 
     0) AS LIMITCONSUMED
  FROM G_PIECE REQ, 
       G_PIECE GP, 
       G_PIECEDET DET
 WHERE REQ.TYPPIECE = 'REQUEST_LIMITE'
   AND REQ.TYPEDOC = 'C'
   AND REQ.GPIADR3 = :B2
   AND REQ.GPIDEPOT = :B1
   AND REQ.GPIHEURE = :B3
   AND REQ.GPILIBLIBRE LIKE 'L1.' || :B2 || '.' || :B1 || '.%'
   AND REQ.LIBELLE_20_12 = GP.REFPIECE
   AND GP.TYPPIECE = 'PARAM_LIMITE'
   AND GP.REFEXT = 'COM'
   AND DET.REFPIECE = GP.REFPIECE
   AND DET.TYPE = 'DETAIL_LIMITE'
   AND SYSDATE BETWEEN DET.DT01_DT AND NVL(DET.DT02_DT, SYSDATE)
   AND ROWNUM = 1;
/********************************New SQL*******************************************/
/********************************New Metrics***************************************/
/*
Plan hash value: 3954607538
----------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                               | Name            | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers |
----------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                        |                 |      1 |        |    20 (100)|      1 |00:00:00.01 |      17 |
|*  1 |  COUNT STOPKEY                          |                 |      1 |        |            |      1 |00:00:00.01 |      17 |
|   2 |   NESTED LOOPS                          |                 |      1 |      1 |    20   (0)|      1 |00:00:00.01 |      17 |
|   3 |    NESTED LOOPS                         |                 |      1 |      1 |    20   (0)|      1 |00:00:00.01 |      16 |
|   4 |     NESTED LOOPS                        |                 |      1 |      1 |    16   (0)|      1 |00:00:00.01 |      12 |
|*  5 |      TABLE ACCESS BY INDEX ROWID BATCHED| G_PIECE         |      1 |      1 |    13   (0)|      1 |00:00:00.01 |       7 |
|*  6 |       INDEX RANGE SCAN                  | PIE_GPILIBLIBRE |      1 |     27 |     3   (0)|      2 |00:00:00.01 |       3 |
|*  7 |      TABLE ACCESS BY INDEX ROWID BATCHED| G_PIECE         |      1 |      1 |     3   (0)|      1 |00:00:00.01 |       5 |
|*  8 |       INDEX RANGE SCAN                  | PIE_REFPIECE    |      1 |      1 |     2   (0)|      1 |00:00:00.01 |       3 |
|*  9 |     INDEX RANGE SCAN                    | G_PIECEDET_REFP |      1 |      1 |     3   (0)|      1 |00:00:00.01 |       4 |
|  10 |    TABLE ACCESS BY INDEX ROWID          | G_PIECEDET      |      1 |      1 |     4   (0)|      1 |00:00:00.01 |       1 |
----------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   1 - filter(ROWNUM=1)
   5 - filter(("REQ"."LIBELLE_20_12" IS NOT NULL AND "REQ"."GPIHEURE"=:B3 AND "REQ"."TYPPIECE"='REQUEST_LIMITE' AND
              "REQ"."TYPEDOC"='C'))
   6 - access("REQ"."GPILIBLIBRE" LIKE 'L1.'||:B2||'.'||:B1||'.%')
       filter("REQ"."GPILIBLIBRE" LIKE 'L1.'||:B2||'.'||:B1||'.%')
   7 - filter(("GP"."REFEXT"='COM' AND "GP"."TYPPIECE"='PARAM_LIMITE'))
   8 - access("REQ"."LIBELLE_20_12"="GP"."REFPIECE")
   9 - access("DET"."REFPIECE"="GP"."REFPIECE" AND "DET"."TYPE"='DETAIL_LIMITE' AND "DET"."DT01_DT"<=SYSDATE@!)
       filter(NVL("DET"."DT02_DT",SYSDATE@!)>=SYSDATE@!) 
*/
/********************************New Metrics***************************************/

/********************************Index statistics**********************************/

/********************************Other SQLs****************************************/          
/*

*/ 
/********************************Other SQLs****************************************/              
