###### The monitoring was not turned on #########
###### DBSPI Collection is OFF for database ETPP for more than 1440 minutes. Please check DBSPI configuration, including db_mon.cfg.

1. Switch like root (nsu)
2. dbspicao -pdfv    (Da check-na bazata dali e OKAY)
 
                                Checking instance: 'DEV' @ '/u01/app/oracle/product/12.1.0.2/dbhome_4':
                                                    Connect:         OKAY
                                                    Filter 6:        OKAY
                                                    Filter 16:       OKAY

                                  DB-SPI Collection/Analysis has been turned OFF for instance ETPP


3. ps -ef | grep pmon

      grid      7617     1  0  2018 ?        00:17:21 asm_pmon_+ASM1
      grid     11602     1  0  2018 ?        00:17:22 apx_pmon_+APX1
      root     17413 14912  0 15:06 pts/0    00:00:00 grep pmon
      oracle   61456     1  0 Mar27 ?        00:04:26 ora_pmon_ETPP
      oracle   91923     1  0 May18 ?        00:00:30 ora_pmon_DEV
	  
	  
4. dbspicfg -e     

 SYNTAX_VERSION 4

ORACLE

  HOME "/u01/app/oracle/product/12.1.0.2/dbhome_4"
    DATABASE "DEV" CONNECT "hp_dbspi/hp_dbspi@DEV"
           LOGFILE "/u01/app/oracle/diag/rdbms/dev/DEV/trace/alert_DEV.log"
           FILTER 6 "tablespace_name not in ('UNDOTBS1','TEMP')"
           FILTER 16 "tablespace_name not in ('UNDOTBS1','TEMP')"
    DATABASE "ETPP" CONNECT "hp_dbspi/hp_dbspi@ETPP"
           FILTER 6 "tablespace_name not in ('UNDOTBS1','TEMP')"
           FILTER 16 "tablespace_name not in ('UNDOTBS1','TEMP')"
		   
5. su - oracle

6. . oraenv

           ra001():/home/oracle > . oraenv
           ORACLE_SID = [oracle] ? ETPP
           The Oracle base has been set to /u01/app/oracle
           
7. sqlplus hp_dbspi/hp_dbspi@ETPP      (Kachvam se na bazata chrez    sqlplus <user_name>/<password>@<database_name>  localno)



           SQL*Plus: Release 12.1.0.2.0 Production on Fri May 24 15:08:22 2019

           Copyright (c) 1982, 2014, Oracle.  All rights reserved.

           Last Successful login time: Tue May 14 2019 15:28:40 +02:00

8. sho parameter db_name

NAME                                 TYPE        VALUE
------------------------------------ ----------- ------------------------------
db_name                              string      ETPP


9. dbmoncol database oracle ETPP ON     (Izpylnqva se kato ROOT,puskame monitorring-a)

10. dbspicao -pdfv       (Pravim proverka dali e trygnal)

               Checking instance: 'DEV' @ '/u01/app/oracle/product/12.1.0.2/dbhome_4':
                        Connect:         OKAY
                        Filter 6:        OKAY
                        Filter 16:       OKAY

               Checking instance: 'ETPP' @ '/u01/app/oracle/product/12.1.0.2/dbhome_4':
                        Connect:         OKAY
                        Filter 6:        OKAY
                        Filter 16:       OKAY


###### The monitorring was not turned on . The database is up and running #########		   