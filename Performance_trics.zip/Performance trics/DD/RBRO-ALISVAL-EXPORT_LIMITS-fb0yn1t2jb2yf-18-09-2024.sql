/********************************************************************************
*********       E-mail subject: RBRODEV-4151
*********             Instance: Alisval
*********          Description: 
Problem:
The rbr_dwh_full.ksh took almost 4 hours on Alisval.

Analysis:
From the analyze, we found that most of the time was spent in module EXPORT_RISK_EXPOSURE, where for TOP SQLs we have queries like f488v1c6f2z9p, 64pup47bgfuaz, b7dkkspfxqq7x and d4asrz6brx4dh.
Similar situation was already analyzed in https://tts.codix.eu/jira/browse/RBRODEV-2494?focusedCommentId=14575591&page=com.atlassian.jira.plugin.system.issuetabpanels:comment-tabpanel#comment-14575591 ,
so please do the same here. The next TOP module is the EXPORT_LIMITS. The TOP SQL in the EXPORT_LIMITS module is fb0yn1t2jb2yf. It looks like this query selects big amount of rows from 
G_PIECE, so we think that if we use WITH caluse, in which we select all the common rows for the two unions using FULL SCAN of table G_PIECE will be better from performance point of view, to please change the query 
as it is shown in the New SQL section below.

Suggestion:
1. For the EXPORT_RISK_EXPOSURE module, please see the suggestion in https://tts.codix.eu/jira/browse/RBRODEV-2494?focusedCommentId=14575591&page=com.atlassian.jira.plugin.system.issuetabpanels:comment-tabpanel#comment-14575591.
2. For the EXPORT_LIMITS module, please change SQL fb0yn1t2jb2yf as it is shown in the New SQL section below.

*********               SQL_ID: fb0yn1t2jb2yf
*********      Program/Package: 
*********              Request: Rositsa Nenova 
*********               Author: Dimitar Dimitrov
********* Received e-mail date: 18/09/2024
*********      Resolution date: 18/09/2024
*********  Trace old file here: \\epox\specifs\performance\tmp\
*********  Trace new file here:
***********************************************************************************/

/********************************OLD SQL*******************************************/

-- fb0yn1t2jb2yf


SELECT LIMIT_ROWID, 
       LIMIT_REF, 
       LIMIT_TYPE
  FROM ( SELECT R.ROWID    AS LIMIT_ROWID,
                R.REFPIECE AS LIMIT_REF,
                R.TYPPIECE AS LIMIT_TYPE
           FROM G_PIECE R
          WHERE R.TYPPIECE = 'REQUEST_LIMITE'
         UNION ALL
         SELECT P.ROWID    AS LIMIT_ROWID,
                P.REFPIECE AS LIMIT_REF,
                P.TYPPIECE AS LIMIT_TYPE
           FROM G_PIECE P
          WHERE P.TYPPIECE = 'PARAM_LIMITE'
            AND P.TYPEDOC = 'MONTANT'
            AND P.LIBELLE_20_1 IS NULL
            AND P.GPIDEPOT != 'CI'
            AND NOT EXISTS ( SELECT 1
                               FROM G_PIECE
                              WHERE TYPPIECE = 'REQUEST_LIMITE'
                                AND LIBELLE_20_12 = P.REFPIECE ) ) ;

/********************************OLD SQL*******************************************/
/********************************OLD Metrics***************************************/
/*

-- For EXPORT_LIMITS module

MODULE                           PROGRAM                                            CLIENT_ID       SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- -------------------------------------------------- --------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
EXPORT_LIMITS                    sqlplus                                            unknown         fb0yn1t2jb2yf  666023439        779      40514                      2024/09/17 23:05:12  2024/09/17 23:37:15        127                     1 +000000000 00:32:02.498 9%
EXPORT_RISK_EXPOSURE             sqlplus                                            unknown         64pup47bgfuaz 2425615062        779      40514                      2024/09/18 00:42:40  2024/09/18 02:30:49        124                 16468 +000000000 01:48:09.333 9%
EXPORT_RISK_EXPOSURE             sqlplus                                            unknown         b7dkkspfxqq7x  545253794        779      40514 ON CPU               2024/09/18 00:42:00  2024/09/18 02:35:50        114                 17424 +000000000 01:53:49.769 8%
EXPORT_RISK_EXPOSURE             sqlplus                                            unknown         d4asrz6brx4dh   33656117        779      40514 ON CPU               2024/09/18 00:43:10  2024/09/18 02:30:19         84                 16328 +000000000 01:47:09.243 6%
EXPORT_RISK_EXPOSURE             sqlplus                                            unknown         f488v1c6f2z9p 1542145442        779      40514                      2024/09/18 00:40:40  2024/09/18 02:36:40         82                 10001 +000000000 01:56:00.015 6%


INSTANCE_NUMBER SQL_ID            ELAPSED MAX_WAIT_ON     PC_OF  WAIT_TIME            GETS      READS       ROWS  ELAP/EXEC       GETS/EXEC READS/EXEC  ROWS/EXEC       EXEC PLAN_HASH_VALUE
--------------- ------------- ----------- --------------- ----- ---------- --------------- ---------- ---------- ---------- --------------- ---------- ---------- ---------- ---------------
              1 fb0yn1t2jb2yf        1281 CPU             87%    1247.0185       970351329      11423      50648    1281.15       970351329      11423      50648          0       666023439


Plan hash value: 666023439
-------------------------------------------------------------------------------------------------------------
| Id  | Operation                              | Name               | Rows  | Bytes | Cost (%CPU)| Time     |
-------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                       |                    |       |       |   127 (100)|          |
|   1 |  VIEW                                  |                    | 50066 |  5475K|   127   (1)| 00:00:01 |
|   2 |   UNION-ALL                            |                    |       |       |            |          |
|   3 |    TABLE ACCESS BY INDEX ROWID BATCHED | G_PIECE            | 50065 |  1711K|    63   (0)| 00:00:01 |
|   4 |     INDEX RANGE SCAN                   | PIECE_TYP_MT43_IDX | 50065 |       |     3   (0)| 00:00:01 |
|   5 |    NESTED LOOPS ANTI                   |                    |     1 |    57 |    64   (0)| 00:00:01 |
|   6 |     TABLE ACCESS BY INDEX ROWID BATCHED| G_PIECE            |     1 |    41 |     1   (0)| 00:00:01 |
|   7 |      INDEX RANGE SCAN                  | GP_TYPEDOC         |     9 |       |     1   (0)| 00:00:01 |
|   8 |     TABLE ACCESS BY INDEX ROWID BATCHED| G_PIECE            |   253 |  4048 |    63   (0)| 00:00:01 |
|   9 |      INDEX RANGE SCAN                  | PIECE_TYP_MT43_IDX | 50065 |       |     3   (0)| 00:00:01 |
-------------------------------------------------------------------------------------------------------------



-- For EXPORT_RISK_EXPOSURE module

MODULE                           PROGRAM                                            CLIENT_ID       SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- -------------------------------------------------- --------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
EXPORT_RISK_EXPOSURE             sqlplus                                            unknown                                         779      40514                      2024/09/18 00:28:29  2024/09/18 02:37:50        776                283757 +000000000 02:09:20.852 57%
EXPORT_LIMITS                    sqlplus                                            unknown                                         779      40514                      2024/09/17 22:52:32  2024/09/17 23:37:15        269                115174 +000000000 00:44:43.339 20%
EXPORT_INVOICES                  sqlplus                                            unknown                                         779      40514                      2024/09/18 00:06:07  2024/09/18 00:21:18         92                225367 +000000000 00:15:11.255 7%
EXPORT_CONTRACTS                 sqlplus                                            unknown                                         779      40514                      2024/09/17 23:37:25  2024/09/17 23:52:06         89                 44829 +000000000 00:14:40.935 7%
EXPORT_ACCOUNTS                  sqlplus                                            unknown                                         779      40514                      2024/09/17 23:58:26  2024/09/18 00:04:37         38                161420 +000000000 00:06:10.650 3%
EXPORT_INTEREST                  sqlplus                                            unknown                                         779      40514                      2024/09/17 23:54:26  2024/09/17 23:58:16         24                   985 +000000000 00:03:50.230 2%
EXPORT_ACCOUNTING_MOVEMENTS      sqlplus                                            unknown                                        1152      36427                      2024/09/18 02:43:30  2024/09/18 02:46:00         16                240577 +000000000 00:02:30.119 1%
EXPORT_CL_DB_ACCOUNTS            sqlplus                                            unknown                                         779      40514                      2024/09/18 00:26:09  2024/09/18 00:28:19         14                 32972 +000000000 00:02:10.166 1%
EXPORT_FINANCING                 sqlplus                                            unknown                                         779      40514                      2024/09/17 23:52:16  2024/09/17 23:54:16         13                     1 +000000000 00:02:00.204 1%
EXPORT_INSURANCE_POLICIES        sqlplus                                            unknown         am50dz4ywtdb9 1206990984        779      40514 db file sequential r 2024/09/18 00:24:09  2024/09/18 00:25:59         12                     1 +000000000 00:01:50.097 1%
EXPORT_BUNDLES                   sqlplus                                            unknown                                         779      40514                      2024/09/18 00:21:28  2024/09/18 00:22:48          9                 13435 +000000000 00:01:20.073 1%
EXPORT_LIM_DOSS_LINK             sqlplus                                            unknown                                         779      40514                      2024/09/18 00:05:07  2024/09/18 00:05:57          6                183308 +000000000 00:00:50.055 0%
EXPORT_EVENTS                    sqlplus                                            unknown                                         779      40514                      2024/09/18 00:23:18  2024/09/18 00:23:59          5                246677 +000000000 00:00:40.015 0%
EXPORT_CREDIT_FEES               sqlplus                                            unknown         c6xhqrc4jn0cr  475680224        779      40514 direct path read     2024/09/18 00:22:58  2024/09/18 00:23:08          2                     1 +000000000 00:00:10.040 0%
EXPORT_CNT_ACC_LINK              sqlplus                                            unknown                                         779      40514                      2024/09/18 00:04:47  2024/09/18 00:04:57          2                 48724 +000000000 00:00:10.000 0%
EXPORT_ACC_EVENTS                sqlplus                                            unknown         aqp64m9d0ac88          0        779      40514 db file sequential r 2024/09/17 22:52:22  2024/09/17 22:52:22          1                     1 +000000000 00:00:00.000 0%



MODULE                           PROGRAM                                            CLIENT_ID       SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- -------------------------------------------------- --------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
EXPORT_RISK_EXPOSURE             sqlplus                                            unknown                                         779      40514 ON CPU               2024/09/18 00:28:39  2024/09/18 02:37:50        582                137164 +000000000 02:09:10.842 75%
EXPORT_RISK_EXPOSURE             sqlplus                                            unknown                                         779      40514 db file sequential r 2024/09/18 00:28:29  2024/09/18 02:37:30        112                283757 +000000000 02:09:00.842 14%
EXPORT_RISK_EXPOSURE             sqlplus                                            unknown         7jvvbqu566ctv 4174066312        779      40514 direct path read     2024/09/18 00:28:49  2024/09/18 00:38:49         53                     1 +000000000 00:10:00.635 7%
EXPORT_RISK_EXPOSURE             sqlplus                                            unknown                                         779      40514 db file parallel rea 2024/09/18 00:28:59  2024/09/18 02:36:40         29                 10012 +000000000 02:07:40.762 4%



MODULE                           PROGRAM                                            CLIENT_ID       SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- -------------------------------------------------- --------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
EXPORT_RISK_EXPOSURE             sqlplus                                            unknown         64pup47bgfuaz 2425615062        779      40514                      2024/09/18 00:42:40  2024/09/18 02:30:49        124                 16468 +000000000 01:48:09.333 16%
EXPORT_RISK_EXPOSURE             sqlplus                                            unknown         b7dkkspfxqq7x  545253794        779      40514 ON CPU               2024/09/18 00:42:00  2024/09/18 02:35:50        114                 17424 +000000000 01:53:49.769 15%
EXPORT_RISK_EXPOSURE             sqlplus                                            unknown         d4asrz6brx4dh   33656117        779      40514 ON CPU               2024/09/18 00:43:10  2024/09/18 02:30:19         84                 16328 +000000000 01:47:09.243 11%
EXPORT_RISK_EXPOSURE             sqlplus                                            unknown         f488v1c6f2z9p 1542145442        779      40514                      2024/09/18 00:40:40  2024/09/18 02:36:40         82                 10001 +000000000 01:56:00.015 11%
EXPORT_RISK_EXPOSURE             sqlplus                                            unknown         7jvvbqu566ctv 4174066312        779      40514                      2024/09/18 00:28:49  2024/09/18 00:38:49         61                     1 +000000000 00:10:00.635 8%
EXPORT_RISK_EXPOSURE             sqlplus                                            unknown         gjzdu6mdb82cx 1517371338        779      40514 ON CPU               2024/09/18 00:44:00  2024/09/18 02:17:28         60                  8391 +000000000 01:33:28.021 8%
EXPORT_RISK_EXPOSURE             sqlplus                                            unknown         b4uyncu1ftcuj 1517371338        779      40514 ON CPU               2024/09/18 00:43:40  2024/09/18 02:19:18         53                  8827 +000000000 01:35:38.173 7%



INSTANCE_NUMBER SQL_ID            ELAPSED MAX_WAIT_ON     PC_OF  WAIT_TIME            GETS      READS       ROWS  ELAP/EXEC       GETS/EXEC READS/EXEC  ROWS/EXEC       EXEC PLAN_HASH_VALUE
--------------- ------------- ----------- --------------- ----- ---------- --------------- ---------- ---------- ---------- --------------- ---------- ---------- ---------- ---------------
              1 64pup47bgfuaz         925 CPU             81%   1110.59294        11794028        257      11177        .08            1055        .02          1      11177      2425615062
              1 7jvvbqu566ctv         611 IO              96%   614.739529         3494035    3401041       2300     611.01         3494035    3401041       2300          1      4174066312
              1 b7dkkspfxqq7x         709 CPU             100%  690.162084       265944965         38      11136        .06           23820          0          1      11165       545253794
              1 d4asrz6brx4dh         931 CPU             81%   1118.05441        11843458          0      11177        .08            1060          0          1      11177        33656117
              1 f488v1c6f2z9p         668 CPU             61%   763.337871         8020871      75199       6210        .11            1292      12.11          1       6210      1542145442
              


*/
/********************************OLD Metrics***************************************/

/********************************New SQL*******************************************/

WITH limit AS ( SELECT /*+ full(p) */
                       P.ROWID    AS LIMIT_ROWID,
                       P.REFPIECE,
                       P.TYPPIECE,
                       P.LIBELLE_20_12,
                       P.GPIDEPOT,
                       P.LIBELLE_20_1,
                       P.TYPEDOC
                  FROM G_PIECE P
                 WHERE P.TYPPIECE IN ('PARAM_LIMITE','REQUEST_LIMITE') )
SELECT LIMIT_ROWID, 
       LIMIT_REF, 
       LIMIT_TYPE
  FROM ( SELECT LIMIT_ROWID,
                R.REFPIECE AS LIMIT_REF,
                R.TYPPIECE AS LIMIT_TYPE
           FROM limit R
          WHERE R.TYPPIECE = 'REQUEST_LIMITE'
          UNION ALL
         SELECT LIMIT_ROWID,
                P.REFPIECE AS LIMIT_REF,
                P.TYPPIECE AS LIMIT_TYPE
           FROM limit P
          WHERE P.TYPPIECE = 'PARAM_LIMITE'
            AND P.TYPEDOC = 'MONTANT'
            AND P.LIBELLE_20_1 IS NULL
            AND P.GPIDEPOT != 'CI'
            AND NOT EXISTS ( SELECT 1
                               FROM limit
                              WHERE TYPPIECE = 'REQUEST_LIMITE'
                                AND LIBELLE_20_12 = P.REFPIECE ) );
/********************************New SQL*******************************************/
/********************************New Metrics***************************************/
/*
Plan hash value: 3104876887
---------------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                  | Name                        | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  | Writes |
---------------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT           |                             |      1 |        |   154K(100)|  63058 |00:01:49.84 |     771K|    697K|    503 |
|   1 |  TEMP TABLE TRANSFORMATION |                             |      1 |        |            |  63058 |00:01:49.84 |     771K|    697K|    503 |
|   2 |   LOAD AS SELECT           |                             |      1 |        |            |      0 |00:01:49.16 |     765K|    696K|    503 |
|*  3 |    TABLE ACCESS FULL       | G_PIECE                     |      1 |  68400 |   151K  (1)|  68466 |00:01:48.96 |     765K|    696K|      0 |
|   4 |   VIEW                     |                             |      1 |    136K|  2360   (1)|  63058 |00:00:00.67 |    5696 |    503 |      0 |
|   5 |    UNION-ALL               |                             |      1 |        |            |  63058 |00:00:00.66 |    5696 |    503 |      0 |
|*  6 |     VIEW                   |                             |      1 |  68400 |    90   (2)|  50794 |00:00:00.55 |    3873 |    503 |      0 |
|   7 |      TABLE ACCESS FULL     | SYS_TEMP_0FD9E86D4_AECE51C9 |      1 |  68400 |    90   (2)|  68466 |00:00:00.54 |    3873 |    503 |      0 |
|*  8 |     HASH JOIN RIGHT ANTI   |                             |      1 |  68400 |  2270   (1)|  12264 |00:00:00.08 |    1823 |      0 |      0 |
|*  9 |      VIEW                  |                             |      1 |  68400 |    90   (2)|  50794 |00:00:00.02 |     505 |      0 |      0 |
|  10 |       TABLE ACCESS FULL    | SYS_TEMP_0FD9E86D4_AECE51C9 |      1 |  68400 |    90   (2)|  68466 |00:00:00.02 |     505 |      0 |      0 |
|* 11 |      VIEW                  |                             |      1 |  68400 |    90   (2)|  15855 |00:00:00.04 |    1318 |      0 |      0 |
|  12 |       TABLE ACCESS FULL    | SYS_TEMP_0FD9E86D4_AECE51C9 |      1 |  68400 |    90   (2)|  68466 |00:00:00.03 |    1318 |      0 |      0 |
---------------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   3 - filter(("P"."TYPPIECE"='PARAM_LIMITE' OR "P"."TYPPIECE"='REQUEST_LIMITE'))
   6 - filter("R"."TYPPIECE"='REQUEST_LIMITE')
   8 - access("LIBELLE_20_12"="P"."REFPIECE")
   9 - filter("TYPPIECE"='REQUEST_LIMITE')
  11 - filter(("P"."TYPPIECE"='PARAM_LIMITE' AND "P"."TYPEDOC"='MONTANT' AND "P"."LIBELLE_20_1" IS NULL AND "P"."GPIDEPOT"<>'CI'))
*/
/********************************New Metrics***************************************/

/********************************Index statistics**********************************/

/********************************Other SQLs****************************************/          
/*

*/ 
/********************************Other SQLs****************************************/              
