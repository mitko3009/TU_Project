-- create the profiler tables
@$RDBMS_HOME/rdbms/admin/proftab.sql


-- to run the profiler for an SQL
exec dbms_profiler.start_profiler('TEST_DI_FTR_FIN_LIMIT');

create table test_di_FTR_FIN_LIMIT as
SELECT FTR_FIN_LIMIT.getConsumedAmount(gp.refpiece, det.nb04) as getConsumerAmount
  FROM g_piece gp, g_piecedet det
 WHERE gp.typpiece = 'PARAM_LIMITE'
   AND det.refpiece = gp.refpiece
   AND det.TYPE = 'DETAIL_LIMITE'
   AND SYSDATE BETWEEN det.dt01_dt AND nvl(det.dt02_dt, SYSDATE);

exec dbms_profiler.stop_profiler;



-- to run the profiler for an PLSQL Block
DECLARE
  l_result  BINARY_INTEGER;
  l_millesime varchar2(5);
  l_availot number;
BEGIN
  l_result := DBMS_PROFILER.start_profiler(run_comment => 'search_engine');
  
  for i in (
  select millesime, nvl(sum(availot) ,0)
  from ( select millesime, availot, nomLot
           from snap_bourse_new snap, g_piece lot
          where snap.nomLot = lot.nb01
            and snap.idVente = lot.gpirole 
            and lang = :b1 
            AND (    (     formatKeyword like '%'||format_keyword('coteaux')||'%' 
                       AND formatKeyword like '%'||format_keyword('peyrus')||'%' 
                       AND formatKeyword like '%'||format_keyword('pic')||'%' ) 
                  OR (     formatKeyword like '%'||format_keyword('coteaux')||'%' ) 
                  OR (     formatKeyword like '%'||format_keyword('coteaux')||'%' 
                       AND formatKeyword like '%'||format_keyword('pic')||'%' ) 
                  OR (     formatKeyword like '%'||format_keyword('coteaux')||'%' 
                       AND formatKeyword like '%'||format_keyword('peyrus')||'%' ) 
                  OR (     formatKeyword like '%'||format_keyword('peyrus')||'%' ) 
                  OR (     formatKeyword like '%'||format_keyword('pic')||'%' ) 
                  OR (     formatKeyword like '%'||format_keyword('peyrus')||'%' 
                       AND formatKeyword like '%'||format_keyword('pic')||'%' ) ) 
          group by millesime,nomLot,availot )
 group by millesime
 order by millesime desc ) loop
 null;
 end loop;
 
  l_result := DBMS_PROFILER.stop_profiler;
  
END;
/




-- to check all the profiled statements
col RUN_OWNER for a10
col RUN_COMMENT for a70
select runid,
           run_owner, 
           run_date,
           run_total_time/1000000000 run_total_time,
           run_comment
    from plsql_profiler_runs
order by run_date desc;

  


-- to check the last profile you named TEST_DI_FTR_FIN_LIMIT
col type for a20
col name for a30
col text for a60 truncate
select /*+ leading(p) use_nl(s) */ 
       p.runid,
       p.type,
       p.name,
       p.line,
       p.total_occur,
       p.total_time,
       p.min_time,
       p.max_time,
       s.text
  from user_source s,
       ( select /*+ no_merge no_push_pred */ *
           from ( select pu.runid,
                         pu.unit_type type, 
                         pu.unit_name name, 
                         pd.line# line, 
                         pd.total_occur, 
                         pd.total_time/1000000000 total_time, 
                         pd.min_time/1000000000 min_time, 
                         pd.max_time/1000000000 max_time 
                    from plsql_profiler_data pd, 
                         plsql_profiler_units pu,
                         ( select runid
                             from ( select runid, max(run_date) over () max_run_date, run_date
                                      from plsql_profiler_runs
                                     where 1 =1
                                       and run_comment like 'TEST_DI_FTR_FIN_LIMIT%' 
                                       -- and runid = 39
                                       )
                            where max_run_date = run_date ) pr
                   where pd.runid = pr.runid
                     and pd.runid = pu.runid
                     and pd.unit_number = pu.unit_number 
                   order by pd.total_time desc )
         where rownum <= 20 ) p
 where p.name = s.name(+)
   and p.type = s.type(+)
   and p.line = s.line(+);




-- PL/SQL Hierarchical Profiler - https://blogs.oracle.com/coretec/post/plsql-tuning-with-plsql-hierarchical-profiler
-- First time.
EXEC DBMS_HPROF.create_tables;

-- Recreate objects if present.
EXEC DBMS_HPROF.create_tables(force_it => TRUE);

GRANT EXECUTE ON dbms_hprof TO gen$huis;
CREATE OR REPLACE DIRECTORY PROFILER_DIR AS '/devi/intra/imx/tmp/';
GRANT READ, WRITE ON DIRECTORY profiler_dir TO gen$huis;

BEGIN
  DBMS_HPROF.START_PROFILING('PROFILER_DIR', 'hprof_ftr_overspending_runStatisticGathering.txt');
  ftr_overspending.runStatisticGathering;
  DBMS_HPROF.STOP_PROFILING;
END;
/

plshprof -output $TMP/hprof_ftr_overspending $TMP/HPROF_CFC_MIGRATION.txt



GRANT EXECUTE ON dbms_hprof TO imxdb;
CREATE OR REPLACE DIRECTORY PROFILER_DIR AS '/ivka/intra/imx/tmp/';
CREATE OR REPLACE DIRECTORY PROFILER_DIR AS '/tmp/';
GRANT READ, WRITE ON DIRECTORY profiler_dir TO imxdb;

plshprof -output /tmp/hprof_ftr_overspending /tmp/hprof_ftr_overspending_runStatisticGathering.txt




