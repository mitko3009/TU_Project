/********************************************************************************
*********       E-mail subject: EFEURDEV-6065
*********             Instance: PROD
*********          Description: 
Problem:
SQL 6p1v5fv6sr0gx was the second TOP SQL in the imxbatch_ValidateCessions on 05/12/2024.

Analysis:
Based on what we see in the execution plan, it looks like the tables are not joined in the correct order from performance point of view, which leads to unnecessary selecting ~1800 rows in this case 
and iterating through the tables with them ( the heaviest part is accessing table G_PIECEDET foe each row, which we want to avoid). We think that the more selective way here will be first to 
filter the rows in table g_piecedet CntrSit by the imx_un_id column and then continue only for the imx_un_id that we are interested from ( it looks like we only need from the max imx_un_id in 
table g_piecedet for the given refpiece and type = 'CONTRACT SITUATIONS').
We found that on the HOTFIX instance the bad execution plan from PROD can be reproduced, so we tested on HOTFIX and it looks like this variant is better.

Suggestion:
Please change SQL 6p1v5fv6sr0gx ( ES Variable:target_case ) as it is shown in the New SQL section below.

*********               SQL_ID: 6p1v5fv6sr0gx
*********      Program/Package: ES Variable:target_case
*********              Request: Dimitare Ivanov
*********               Author: Dimitar Dimitrov
********* Received e-mail date: 05/12/2024
*********      Resolution date: 11/12/2024
*********  Trace old file here: \\epox\specifs\performance\tmp\
*********  Trace new file here:
***********************************************************************************/

/********************************OLD SQL*******************************************/

var B1 VARCHAR2(32);
exec :B1 := '2411130685';
var B2 VARCHAR2(32);
exec :B2 := '2411130685';
var B3 VARCHAR2(32);
exec :B3 := '2411130685';
var B4 VARCHAR2(32);
exec :B4 := '2411130685';
var B5 VARCHAR2(32);
exec :B5 := '2411130685';
exec utl_app_date.cacheAppDateCase(:B5);

select   DB.refindividu DEBTORREF,
       CL.refindividu CLREF,
       CreditIns.str1 DBCNTRY,
       CreditIns.str2 PLCYTYPE,
       nvl(CreditIns.str7, CreditIns.str9) PLCYREF,
       Contrat.refdoss CONTRACTREF
  from g_dossier      Compte,
       g_dossier      Decompte,
       g_piece        Contrat,
       g_piecedet     CntrSit,
       g_piecedet     CreditIns,
       t_intervenants DB,
       t_intervenants CL
 where Contrat.fg10 = 'O'
   and Contrat.typpiece = 'CONTRAT'
   and Contrat.refpiece = CreditIns.refpiece
   and CntrSit.refpiece = Contrat.refpiece
   and CntrSit.type = 'CONTRACT SITUATIONS'
   and CntrSit.str1 not in ('A', 'O', 'F', 'P', 'T')
   and CntrSit.imx_un_id = ( select max(imx_un_id)
                               from g_piecedet
                              where refpiece = CntrSit.refpiece
                                and type = 'CONTRACT SITUATIONS' )
   and CL.refdoss = :B1
   and CL.reftype = 'CL'
   and DB.refdoss = :B2
   and DB.reftype = 'DB'
   and Compte.refdoss = :B3
   and Compte.reflot = Decompte.refdoss
   and Decompte.reflot = Contrat.refdoss
   and CreditIns.type = 'ASSURANCE_CREDIT'
   and CreditIns.str1 = ( select pays 
                            from g_individu 
                           where refindividu = DB.refindividu )
   and to_char(nvl(CreditIns.dt01_dt, utl_app_date.getAppDate), 'j') <= to_char(utl_app_date.getAppDate, 'j')
   and to_char(nvl(CreditIns.dt02_dt, utl_app_date.getAppDate), 'j') >= to_char(utl_app_date.getAppDate, 'j')
   and not exists ( select 1
                      from t_attente
                     where refentite = :B4
                       and typencour = 'Case to archive' )
   and not exists ( select 1
                      from t_element_se
                     where refdoss = :B5
                       and libelle = 'Case to archive' );
/********************************OLD SQL*******************************************/
/********************************OLD Metrics***************************************/
/*
MODULE                           SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
imxbatch_ValidateCessions                                        156      15727                      2024/12/05 22:21:06  2024/12/06 00:19:51         542             15437889 +000000000 01:58:44.629 100%

MODULE                           SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
imxbatch_ValidateCessions        4yt6p8wvy6s4z          0        156      15727 ON CPU               2024/12/05 23:52:30  2024/12/06 00:14:01          86                    1 +000000000 00:21:30.762 16%
imxbatch_ValidateCessions        6p1v5fv6sr0gx 3614057665        156      15727 ON CPU               2024/12/05 22:55:18  2024/12/05 23:50:50          63                50211 +000000000 00:55:31.893 12%
imxbatch_ValidateCessions                               0        156      15727                      2024/12/05 22:22:37  2024/12/06 00:19:11          37                    1 +000000000 01:56:34.497 7%
imxbatch_ValidateCessions        c7qk5jrznw98c          0        156      15727 ON CPU               2024/12/05 23:53:20  2024/12/06 00:13:01          21               830106 +000000000 00:19:40.703 4%
imxbatch_ValidateCessions        4gmuzm0j6qsn1 2944573405        156      15727 ON CPU               2024/12/05 22:22:57  2024/12/05 22:47:58          19                57759 +000000000 00:25:01.332 4%
imxbatch_ValidateCessions        gs85yy22h1kq7 3039937457        156      15727                      2024/12/05 22:56:08  2024/12/05 23:44:30          18                43728 +000000000 00:48:21.656 3%

SQL_ID        SQL_PLAN_HASH_VALUE SQL_PLAN_LINE_ID SQL_PLAN_OPERATION             SQL_PLAN_OPTIONS                   ACTIVE
------------- ------------------- ---------------- ------------------------------ ------------------------------ ----------
6p1v5fv6sr0gx          3614057665               23 TABLE ACCESS                   BY INDEX ROWID                         15
6p1v5fv6sr0gx          3614057665               19 INDEX                          RANGE SCAN                             11
6p1v5fv6sr0gx          3614057665               20 TABLE ACCESS                   BY INDEX ROWID BATCHED                 10
6p1v5fv6sr0gx          3614057665               24 BUFFER                         SORT                                    7
6p1v5fv6sr0gx          3614057665               22 INDEX                          RANGE SCAN                              6
6p1v5fv6sr0gx          3614057665               21 INDEX                          RANGE SCAN                              4
6p1v5fv6sr0gx          3614057665                3 FILTER                                                                 3
6p1v5fv6sr0gx          3614057665                  SELECT STATEMENT                                                       1
6p1v5fv6sr0gx          3614057665               27 INDEX                          SKIP SCAN                               1
6p1v5fv6sr0gx          3614057665                7 NESTED LOOPS                                                           1
6p1v5fv6sr0gx          3614057665                5 MERGE JOIN                     CARTESIAN                               1
6p1v5fv6sr0gx          3614057665               14 INDEX                          RANGE SCAN                              1
6p1v5fv6sr0gx          3614057665                2 HASH                           GROUP BY                                1
6p1v5fv6sr0gx          3614057665               18 TABLE ACCESS                   BY INDEX ROWID BATCHED                  1


-- manual on HOTFIX
Plan hash value: 3614057665
-----------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                     | Name                   | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers |
-----------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                              |                        |      1 |        |    36 (100)|      1 |00:00:00.02 |    2324 |
|*  1 |  FILTER                                       |                        |      1 |        |            |      1 |00:00:00.02 |    2324 |
|   2 |   HASH GROUP BY                               |                        |      1 |      1 |    36   (3)|      4 |00:00:00.02 |    2324 |
|*  3 |    FILTER                                     |                        |      1 |        |            |     16 |00:00:00.02 |    2324 |
|*  4 |     FILTER                                    |                        |      1 |        |            |   1792 |00:00:00.02 |    2321 |
|   5 |      MERGE JOIN CARTESIAN                     |                        |      1 |      1 |    25   (0)|   1792 |00:00:00.02 |    2313 |
|   6 |       NESTED LOOPS                            |                        |      1 |      1 |    23   (0)|   1792 |00:00:00.01 |    2310 |
|   7 |        NESTED LOOPS                           |                        |      1 |      1 |    23   (0)|   1792 |00:00:00.01 |     518 |
|   8 |         NESTED LOOPS                          |                        |      1 |      1 |    19   (0)|    448 |00:00:00.01 |     500 |
|   9 |          NESTED LOOPS                         |                        |      1 |      1 |    15   (0)|    112 |00:00:00.01 |      34 |
|  10 |           NESTED LOOPS                        |                        |      1 |      1 |    11   (0)|      1 |00:00:00.01 |      19 |
|  11 |            NESTED LOOPS                       |                        |      1 |      1 |     7   (0)|      1 |00:00:00.01 |       9 |
|  12 |             NESTED LOOPS                      |                        |      1 |      1 |     5   (0)|      1 |00:00:00.01 |       6 |
|* 13 |              INDEX RANGE SCAN                 | DOS_REFDOSS_REFLOT_IDX |      1 |      1 |     3   (0)|      1 |00:00:00.01 |       3 |
|* 14 |              INDEX RANGE SCAN                 | DOS_REFDOSS_REFLOT_IDX |      1 |      1 |     2   (0)|      1 |00:00:00.01 |       3 |
|* 15 |             INDEX RANGE SCAN                  | INT_REFDOSS            |      1 |      1 |     2   (0)|      1 |00:00:00.01 |       3 |
|* 16 |            TABLE ACCESS BY INDEX ROWID BATCHED| G_PIECE                |      1 |      1 |     4   (0)|      1 |00:00:00.01 |      10 |
|* 17 |             INDEX RANGE SCAN                  | PIE_REFDOSS            |      1 |      1 |     3   (0)|      1 |00:00:00.01 |       8 |
|  18 |           TABLE ACCESS BY INDEX ROWID BATCHED | G_PIECEDET             |      1 |      1 |     4   (0)|    112 |00:00:00.01 |      15 |
|* 19 |            INDEX RANGE SCAN                   | G_PIECEDET_REFP        |      1 |      1 |     3   (0)|    112 |00:00:00.01 |       6 |
|* 20 |          TABLE ACCESS BY INDEX ROWID BATCHED  | G_PIECEDET             |    112 |      1 |     4   (0)|    448 |00:00:00.01 |     466 |
|* 21 |           INDEX RANGE SCAN                    | G_PIECEDET_REFP        |    112 |      1 |     3   (0)|    448 |00:00:00.01 |      18 |
|* 22 |         INDEX RANGE SCAN                      | G_PIECEDET_REFP        |    448 |      1 |     3   (0)|   1792 |00:00:00.01 |      18 |
|  23 |        TABLE ACCESS BY INDEX ROWID            | G_PIECEDET             |   1792 |      1 |     4   (0)|   1792 |00:00:00.01 |    1792 |
|  24 |       BUFFER SORT                             |                        |   1792 |      1 |    22   (5)|   1792 |00:00:00.01 |       3 |
|* 25 |        INDEX RANGE SCAN                       | INT_REFDOSS            |      1 |      1 |     2   (0)|      1 |00:00:00.01 |       3 |
|* 26 |      TABLE ACCESS BY INDEX ROWID BATCHED      | T_ELEMENT_SE           |      1 |      1 |     4   (0)|      0 |00:00:00.01 |       4 |
|* 27 |       INDEX SKIP SCAN                         | ELESE_DOSELEM          |      1 |      1 |     3   (0)|      2 |00:00:00.01 |       3 |
|* 28 |      TABLE ACCESS BY INDEX ROWID BATCHED      | T_ATTENTE              |      1 |      1 |     4   (0)|      0 |00:00:00.01 |       4 |
|* 29 |       INDEX SKIP SCAN                         | PK_ATTENTE             |      1 |      1 |     3   (0)|      1 |00:00:00.01 |       3 |
|  30 |     TABLE ACCESS BY INDEX ROWID               | G_INDIVIDU             |      1 |      1 |     2   (0)|      1 |00:00:00.01 |       3 |
|* 31 |      INDEX UNIQUE SCAN                        | IND_REFINDIV           |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       2 |
-----------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   1 - filter("CNTRSIT"."IMX_UN_ID"=MAX("IMX_UN_ID"))
   3 - filter("CREDITINS"."STR1"=)
   4 - filter(( IS NULL AND  IS NULL))
  13 - access("COMPTE"."REFDOSS"=:B3)
  14 - access("COMPTE"."REFLOT"="DECOMPTE"."REFDOSS")
  15 - access("DB"."REFDOSS"=:B2 AND "DB"."REFTYPE"='DB')
  16 - filter("CONTRAT"."FG10"='O')
  17 - access("DECOMPTE"."REFLOT"="CONTRAT"."REFDOSS" AND "CONTRAT"."TYPPIECE"='CONTRAT')
       filter("CONTRAT"."REFDOSS" IS NOT NULL)
  19 - access("CONTRAT"."REFPIECE"="CREDITINS"."REFPIECE" AND "CREDITINS"."TYPE"='ASSURANCE_CREDIT')
       filter((TO_CHAR(NVL("CREDITINS"."DT01_DT","UTL_APP_DATE"."GETAPPDATE"()),'j')<=TO_CHAR("UTL_APP_DATE"."GETAPPDATE"(),'j') AND
              TO_CHAR(NVL("CREDITINS"."DT02_DT","UTL_APP_DATE"."GETAPPDATE"()),'j')>=TO_CHAR("UTL_APP_DATE"."GETAPPDATE"(),'j')))
  20 - filter(("CNTRSIT"."STR1"<>'A' AND "CNTRSIT"."STR1"<>'O' AND "CNTRSIT"."STR1"<>'F' AND "CNTRSIT"."STR1"<>'P' AND
              "CNTRSIT"."STR1"<>'T'))
  21 - access("CNTRSIT"."REFPIECE"="CONTRAT"."REFPIECE" AND "CNTRSIT"."TYPE"='CONTRACT SITUATIONS')
  22 - access("REFPIECE"="CNTRSIT"."REFPIECE" AND "TYPE"='CONTRACT SITUATIONS')
  25 - access("CL"."REFDOSS"=:B1 AND "CL"."REFTYPE"='CL')
  26 - filter("LIBELLE"='Case to archive')
  27 - access("REFDOSS"=:B5)
  28 - filter("TYPENCOUR"='Case to archive')
  29 - access("REFENTITE"=:B4)
  31 - access("REFINDIVIDU"=:B1)
*/
/********************************OLD Metrics***************************************/

/********************************New SQL*******************************************/

select DB.refindividu DEBTORREF,
       CL.refindividu CLREF,
       CreditIns.str1 DBCNTRY,
       CreditIns.str2 PLCYTYPE,
       nvl(CreditIns.str7, CreditIns.str9) PLCYREF,
       Contrat.refdoss CONTRACTREF
  from g_dossier      Compte,
       g_dossier      Decompte,
       g_piece        Contrat,
       g_piecedet     CntrSit,
       g_piecedet     CreditIns,
       t_intervenants DB,
       t_intervenants CL
 where Contrat.fg10 = 'O'
   and Contrat.typpiece = 'CONTRAT'
   and Contrat.refpiece = CreditIns.refpiece
   and CntrSit.refpiece = Contrat.refpiece
   and CntrSit.type = 'CONTRACT SITUATIONS'
   and CntrSit.str1 not in ('A', 'O', 'F', 'P', 'T')
   and CntrSit.imx_un_id = ( select max(imx_un_id)
                               from g_piecedet
                              where refpiece = Contrat.refpiece
                                and type = 'CONTRACT SITUATIONS' )
   and CL.refdoss = :B1
   and CL.reftype = 'CL'
   and DB.refdoss = :B2
   and DB.reftype = 'DB'
   and Compte.refdoss = :B3
   and Compte.reflot = Decompte.refdoss
   and Decompte.reflot = Contrat.refdoss
   and CreditIns.type = 'ASSURANCE_CREDIT'
   and CreditIns.str1 = ( select pays 
                            from g_individu 
                           where refindividu = DB.refindividu )
   and to_char(nvl(CreditIns.dt01_dt, utl_app_date.getAppDate), 'j') <= to_char(utl_app_date.getAppDate, 'j')
   and to_char(nvl(CreditIns.dt02_dt, utl_app_date.getAppDate), 'j') >= to_char(utl_app_date.getAppDate, 'j')
   and not exists ( select 1
                      from t_attente
                     where refentite = :B4
                       and typencour = 'Case to archive' )
   and not exists ( select 1
                      from t_element_se
                     where refdoss = :B5
                       and libelle = 'Case to archive' );
/********************************New SQL*******************************************/
/********************************New Metrics***************************************/
/*
Plan hash value: 3258660890
------------------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                   | Name                   | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  |
------------------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                            |                        |      1 |        |    30 (100)|      1 |00:00:00.01 |      55 |      4 |
|*  1 |  FILTER                                     |                        |      1 |        |            |      1 |00:00:00.01 |      55 |      4 |
|*  2 |   FILTER                                    |                        |      1 |        |            |    112 |00:00:00.01 |      52 |      4 |
|   3 |    NESTED LOOPS                             |                        |      1 |      1 |    19   (0)|    112 |00:00:00.01 |      44 |      0 |
|   4 |     NESTED LOOPS                            |                        |      1 |      1 |    19   (0)|    112 |00:00:00.01 |      37 |      0 |
|   5 |      NESTED LOOPS                           |                        |      1 |      1 |    15   (0)|      1 |00:00:00.01 |      31 |      0 |
|   6 |       NESTED LOOPS                          |                        |      1 |      1 |    13   (0)|      1 |00:00:00.01 |      19 |      0 |
|   7 |        MERGE JOIN CARTESIAN                 |                        |      1 |      1 |     9   (0)|      1 |00:00:00.01 |      12 |      0 |
|   8 |         NESTED LOOPS                        |                        |      1 |      1 |     7   (0)|      1 |00:00:00.01 |       9 |      0 |
|   9 |          NESTED LOOPS                       |                        |      1 |      1 |     5   (0)|      1 |00:00:00.01 |       6 |      0 |
|* 10 |           INDEX RANGE SCAN                  | DOS_REFDOSS_REFLOT_IDX |      1 |      1 |     3   (0)|      1 |00:00:00.01 |       3 |      0 |
|* 11 |           INDEX RANGE SCAN                  | DOS_REFDOSS_REFLOT_IDX |      1 |      1 |     2   (0)|      1 |00:00:00.01 |       3 |      0 |
|* 12 |          INDEX RANGE SCAN                   | INT_REFDOSS            |      1 |      1 |     2   (0)|      1 |00:00:00.01 |       3 |      0 |
|  13 |         BUFFER SORT                         |                        |      1 |      1 |     7   (0)|      1 |00:00:00.01 |       3 |      0 |
|* 14 |          INDEX RANGE SCAN                   | INT_REFDOSS            |      1 |      1 |     2   (0)|      1 |00:00:00.01 |       3 |      0 |
|* 15 |        TABLE ACCESS BY INDEX ROWID BATCHED  | G_PIECE                |      1 |      1 |     4   (0)|      1 |00:00:00.01 |       7 |      0 |
|* 16 |         INDEX RANGE SCAN                    | PIE_REFDOSS            |      1 |      1 |     3   (0)|      1 |00:00:00.01 |       5 |      0 |
|* 17 |       TABLE ACCESS BY INDEX ROWID           | G_PIECEDET             |      1 |      1 |     2   (0)|      1 |00:00:00.01 |      12 |      0 |
|* 18 |        INDEX UNIQUE SCAN                    | PK_G_PIECEDET_PK       |      1 |      1 |     1   (0)|      1 |00:00:00.01 |      11 |      0 |
|  19 |         SORT AGGREGATE                      |                        |      1 |      1 |            |      1 |00:00:00.01 |       8 |      0 |
|  20 |          TABLE ACCESS BY INDEX ROWID BATCHED| G_PIECEDET             |      1 |      1 |     5   (0)|      4 |00:00:00.01 |       8 |      0 |
|* 21 |           INDEX RANGE SCAN                  | G_PIECEDET_REFP        |      1 |      1 |     4   (0)|      4 |00:00:00.01 |       4 |      0 |
|* 22 |      INDEX RANGE SCAN                       | G_PIECEDET_REFP        |      1 |      1 |     3   (0)|    112 |00:00:00.01 |       6 |      0 |
|  23 |     TABLE ACCESS BY INDEX ROWID             | G_PIECEDET             |    112 |      1 |     4   (0)|    112 |00:00:00.01 |       7 |      0 |
|* 24 |    TABLE ACCESS BY INDEX ROWID BATCHED      | T_ELEMENT_SE           |      1 |      1 |     5   (0)|      0 |00:00:00.01 |       4 |      2 |
|* 25 |     INDEX RANGE SCAN                        | ELESE_DOSELEM          |      1 |      2 |     3   (0)|      2 |00:00:00.01 |       3 |      1 |
|* 26 |    TABLE ACCESS BY INDEX ROWID BATCHED      | T_ATTENTE              |      1 |      1 |     4   (0)|      0 |00:00:00.01 |       4 |      2 |
|* 27 |     INDEX SKIP SCAN                         | PK_ATTENTE             |      1 |      1 |     3   (0)|      1 |00:00:00.01 |       3 |      1 |
|  28 |   TABLE ACCESS BY INDEX ROWID               | G_INDIVIDU             |      1 |      1 |     2   (0)|      1 |00:00:00.01 |       3 |      0 |
|* 29 |    INDEX UNIQUE SCAN                        | IND_REFINDIV           |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       2 |      0 |
------------------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   1 - filter("CREDITINS"."STR1"=)
   2 - filter(( IS NULL AND  IS NULL))
  10 - access("COMPTE"."REFDOSS"=:B3)
  11 - access("COMPTE"."REFLOT"="DECOMPTE"."REFDOSS")
  12 - access("DB"."REFDOSS"=:B2 AND "DB"."REFTYPE"='DB')
  14 - access("CL"."REFDOSS"=:B1 AND "CL"."REFTYPE"='CL')
  15 - filter("CONTRAT"."FG10"='O')
  16 - access("DECOMPTE"."REFLOT"="CONTRAT"."REFDOSS" AND "CONTRAT"."TYPPIECE"='CONTRAT')
       filter("CONTRAT"."REFDOSS" IS NOT NULL)
  17 - filter(("CNTRSIT"."REFPIECE"="CONTRAT"."REFPIECE" AND "CNTRSIT"."TYPE"='CONTRACT SITUATIONS' AND "CNTRSIT"."STR1"<>'A' AND
              "CNTRSIT"."STR1"<>'O' AND "CNTRSIT"."STR1"<>'F' AND "CNTRSIT"."STR1"<>'P' AND "CNTRSIT"."STR1"<>'T'))
  18 - access("CNTRSIT"."IMX_UN_ID"=)
  21 - access("REFPIECE"=:B1 AND "TYPE"='CONTRACT SITUATIONS')
  22 - access("CONTRAT"."REFPIECE"="CREDITINS"."REFPIECE" AND "CREDITINS"."TYPE"='ASSURANCE_CREDIT')
       filter((TO_CHAR(NVL("CREDITINS"."DT01_DT","UTL_APP_DATE"."GETAPPDATE"()),'j')<=TO_CHAR("UTL_APP_DATE"."GETAPPDATE"(),'j') AND
              TO_CHAR(NVL("CREDITINS"."DT02_DT","UTL_APP_DATE"."GETAPPDATE"()),'j')>=TO_CHAR("UTL_APP_DATE"."GETAPPDATE"(),'j')))
  24 - filter("LIBELLE"='Case to archive')
  25 - access("REFDOSS"=:B5)
  26 - filter("TYPENCOUR"='Case to archive')
  27 - access("REFENTITE"=:B4)
  29 - access("REFINDIVIDU"=:B1) 
  
*/
/********************************New Metrics***************************************/

/********************************Index statistics**********************************/

/********************************Other SQLs****************************************/          
/*

*/ 
/********************************Other SQLs****************************************/              
