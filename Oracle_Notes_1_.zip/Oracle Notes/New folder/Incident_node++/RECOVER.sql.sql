###RECOVER A CONTROL FILE IF IT IS DELETED###

-TRQBVA DA IMAME BACKUP NA CONTROL FILE-A!!!


SQL> show parameter control;

NAME                                 TYPE        VALUE
------------------------------------ ----------- ------------------------------
control_file_record_keep_time        integer     7
control_files                        string      /disk1/prod/control/control01.
                                                 ctl, /disk1/prod/control/contr
                                                 ol02.ctl


[oracle@linux disk1]$ cd hotbackup/
[oracle@linux hotbackup]$ ls -la
total 41128
drwxr-xr-x 3 oracle root         4096 Mar 18 15:34 .
drwxr-xr-x 5 oracle oinstall     4096 Mar 18 15:27 ..
-rw-r----- 1 root   root     34198528 Mar 18 15:34 1_42_1022686686.dbf
-rw-r----- 1 oracle oinstall  7847936 Mar 18 15:33 control.bk     ---- TOVA NIE BACKUP CONTROL FILE-A(POSLEDNIQT NI NAI-AKTUALEN)
drwxr-xr-x 2 root   root         4096 Mar 18 15:28 data


[oracle@linux ~]$ cd /disk1/prod/control/
[oracle@linux control]$ ls -la
total 15368
drwxr-xr-x 2 oracle oinstall    4096 Oct 26 15:38 .
drwxr-xr-x 9 oracle oinstall    4096 Oct 26 01:16 ..
-rw-r----- 1 oracle oinstall 7847936 Mar 21 22:04 control01.ctl
-rw-r----- 1 oracle oinstall 7847936 Mar 21 22:04 control02.ctl

[oracle@linux control]$ rm control01.ctl
[oracle@linux control]$ rm control02.ctl


SQL> shutdown abort;
ORACLE instance shut down.


[oracle@linux disk1]$ cd hotbackup/
[oracle@linux hotbackup]$ ls -la
total 41128
drwxr-xr-x 3 oracle root         4096 Mar 18 15:34 .
drwxr-xr-x 5 oracle oinstall     4096 Mar 18 15:27 ..
-rw-r----- 1 root   root     34198528 Mar 18 15:34 1_42_1022686686.dbf
-rw-r----- 1 oracle oinstall  7847936 Mar 18 15:33 control.bk
drwxr-xr-x 2 root   root         4096 Mar 18 15:28 data
[oracle@linux hotbackup]$ mv control.bk /disk1/prod/control   --- MESTIM GO V ORIGINAL DEST-A
[oracle@linux hotbackup]$ cd /disk1/prod/control
[oracle@linux control]$ mv control.bk control01.ctl   --- RENAME IT AS IT WAS
[oracle@linux control]$ cp control01.ctl control02.ctl --- MAKE A SECOND COPY AS IT WAS


SQL> alter database mount;

Database altered.


V DRUGA CONSOLA USPOREDNO:

[root@linux log]# find / -type -f -name redo*.log
..........
[root@linux log]# cd /disk2/prod1/log/   --- SEGA COPY /disk2/prod1/log/redo01.log AND PASTE DOLU V DRUGATA CONSOLA V SQL-A
[root@linux log]# ls -larth
total 881M
drwxr-xr-x 8 oracle oinstall 4.0K Oct 26 15:55 ..
-rw-r----- 1 oracle oinstall  51M Oct 27 10:46 redo02.log
-rw-r----- 1 oracle oinstall  51M Oct 27 15:16 old_redo03.log
-rw-r----- 1 oracle oinstall  51M Oct 27 19:05 redo01.log
-rw-r----- 1 oracle oinstall 101M Dec 30 16:02 redo04.log
-rw-r----- 1 oracle oinstall 101M Dec 30 16:09 redo05
-rw-r----- 1 oracle oinstall 101M Dec 30 16:33 redo02b.log
drwxr-xr-x 2 oracle oinstall 4.0K Dec 30 16:40 .
-rw-r----- 1 oracle oinstall 101M Mar 21 21:53 redo9.log
-rw-r----- 1 oracle oinstall 101M Mar 21 21:53 redo03.log
-rw-r----- 1 oracle oinstall 101M Mar 21 21:53 redo01c.log
-rw-r----- 1 oracle oinstall 101M Mar 21 21:53 redo01b.log
-rw-r----- 1 oracle oinstall  11M Mar 21 22:10 redo8.log
-rw-r----- 1 oracle oinstall  11M Mar 21 22:10 redo7.log
-rw-r----- 1 oracle oinstall  11M Mar 21 22:10 redo6.log


SQL> recover database using backup controlfile until cancel;

ORA-00279: change 814897 generated at 03/18/2020 15:29:38 needed for thread 1
ORA-00289: suggestion : /disk1/prod/arch/1_43_1022686686.dbf
ORA-00280: change 814897 for thread 1 is in sequence #43


Specify log: {<RET>=suggested | filename | AUTO | CANCEL}  --- TRQBVA DA MU OKAJEM PYTQ DO 1-IQT REDO ONLINE .LOG, AKO NE E DOSTATYCHEN - SLEDVASHTIQ
/disk2/prod1/log/redo01.log


AKO NQMA PROBLEM SHTE IZPISHE:
Log applied.
Media recovery complete.

SQL> alter database open resetlogs;

Database altered.

GOTOVO - BAZATA E OPEN!


NO AKO IMA PROBLEM, MOOJE DA PRODYLJIM I DA COPY/PASTE I DRUGITE REDO LOG-OVE, A NAKRAQ PAK AKO NE STAVA:

[oracle@linux control]$ rman target /

RMAN> recover database;

Starting recover at 21-MAR-20
using target database control file instead of recovery catalog
allocated channel: ORA_DISK_1
channel ORA_DISK_1: SID=18 device type=DISK

starting media recovery

archived log for thread 1 with sequence 44 is already on disk as file /disk1/prod/redo/redo02.rdo
archived log for thread 1 with sequence 45 is already on disk as file /disk1/prod/redo/redo01.rdo
archived log for thread 1 with sequence 46 is already on disk as file /disk2/prod1/log/redo6.log
archived log file name=/disk1/prod/arch/1_43_1022686686.dbf thread=1 sequence=43
archived log file name=/disk1/prod/redo/redo02.rdo thread=1 sequence=44
archived log file name=/disk1/prod/redo/redo01.rdo thread=1 sequence=45
archived log file name=/disk2/prod1/log/redo6.log thread=1 sequence=46
media recovery complete, elapsed time: 00:00:01
Finished recover at 21-MAR-20

RMAN> exit



Recovery Manager complete.


SQL> shut immediate;
ORA-01109: database not open


Database dismounted.
ORACLE instance shut down.
SQL> startup mount;
ORACLE instance started.

Total System Global Area  521936896 bytes
Fixed Size                  2214936 bytes
Variable Size             356516840 bytes
Database Buffers          159383552 bytes
Redo Buffers                3821568 bytes
Database mounted.
SQL> alter database open resetlogs;

Database altered.


====================================================================================================================

#############RECOVER SYSTEM TABLESPACE#############

TRQBVA DA IMAME BACKUP NA TABLESPACE SYSTEM!!!



SQL> select name from v$datafile;

NAME
------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
/disk1/prod/data/system.dbf
/disk1/prod/data/sysaux.dbf
/disk1/prod/data/undotbs.dbf
/disk1/prod/data/user01.dbf
/disk2/prod1/data/data99.dbf
/disk2/prod1/data/data03.dbf
/disk2/prod1/data/unotbs1b.dbf
/disk2/prod1/data/undotbs201.dbf

8 rows selected.



[oracle@linux data]$ pwd
/disk1/prod/data
[oracle@linux data]$ ls -larth
total 1.2G
drwxr-xr-x 9 oracle oinstall 4.0K Oct 26 01:16 ..
drwxr-xr-x 2 oracle oinstall 4.0K Oct 26 15:38 .
-rw-r----- 1 oracle oinstall 501M Mar 21 22:55 user01.dbf
-rw-r----- 1 oracle oinstall 301M Mar 22 02:30 system.dbf
-rw-r----- 1 oracle oinstall 101M Mar 22 02:35 undotbs.dbf
-rw-r----- 1 oracle oinstall 301M Mar 22 02:35 sysaux.dbf

[oracle@linux data]$ rm system.dbf


SQL> shutdown abort;
ORACLE instance shut down.


[root@linux log]# cd /disk1/hotbackup/
[root@linux hotbackup]# cd data
[root@linux data]# ls -larth
total 1.2G
-rw-r----- 1 root   root 501M Mar 18 15:28 user01.dbf
-rw-r----- 1 root   root 301M Mar 18 15:28 sysaux.dbf
-rw-r----- 1 root   root 301M Mar 18 15:28 system.dbf
drwxr-xr-x 2 root   root 4.0K Mar 18 15:28 .
-rw-r----- 1 root   root 101M Mar 18 15:28 undotbs.dbf
drwxr-xr-x 3 oracle root 4.0K Mar 21 22:11 ..

[root@linux data]# cp system.dbf /disk1/prod/data

[root@linux data]# cd /disk1/prod/data
[root@linux data]# ls -larth
total 1.2G
drwxr-xr-x 9 oracle oinstall 4.0K Oct 26 01:16 ..
-rw-r----- 1 oracle oinstall 501M Mar 21 22:55 user01.dbf
-rw-r----- 1 oracle oinstall 101M Mar 22 02:35 undotbs.dbf
-rw-r----- 1 oracle oinstall 301M Mar 22 02:35 sysaux.dbf
drwxr-xr-x 2 oracle oinstall 4.0K Mar 22 02:44 .
-rw-r----- 1 root   root     301M Mar 22 02:44 system.dbf

[root@linux data]# chown oracle:oinstall system.dbf


SQL> startup mount;
ORACLE instance started.

Total System Global Area  521936896 bytes
Fixed Size                  2214936 bytes
Variable Size             356516840 bytes
Database Buffers          159383552 bytes
Redo Buffers                3821568 bytes
Database mounted.
SQL> recover tablespace system;
ORA-00279: change 814807 generated at 03/18/2020 15:25:54 needed for thread 1
ORA-00289: suggestion : /disk1/prod/arch/1_42_1022686686.dbf
ORA-00280: change 814807 for thread 1 is in sequence #42


Specify log: {<RET>=suggested | filename | AUTO | CANCEL}
AUTO   ---- IZPISVAME AUTO + ENTER

ORA-00279: change 814897 generated at 03/18/2020 15:29:38 needed for thread 1
ORA-00289: suggestion : /disk1/prod/arch/1_43_1022686686.dbf
ORA-00280: change 814897 for thread 1 is in sequence #43


ORA-00279: change 821811 generated at 03/18/2020 22:00:18 needed for thread 1
ORA-00289: suggestion : /disk1/prod/arch/1_44_1022686686.dbf
ORA-00280: change 821811 for thread 1 is in sequence #44


ORA-00279: change 846332 generated at 03/20/2020 07:46:27 needed for thread 1
ORA-00289: suggestion : /disk1/prod/arch/1_45_1022686686.dbf
ORA-00280: change 846332 for thread 1 is in sequence #45


ORA-00279: change 893436 generated at 03/21/2020 21:53:00 needed for thread 1
ORA-00289: suggestion : /disk1/prod/arch/1_46_1022686686.dbf
ORA-00280: change 893436 for thread 1 is in sequence #46


Log applied.
Media recovery complete.


SQL> ALTER DATABASE OPEN;

Database altered.















