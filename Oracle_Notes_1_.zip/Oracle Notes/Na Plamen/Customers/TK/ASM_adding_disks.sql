. oraenv   +ASM1
sqlplus / as sysasm


crsctl query css votedisk
asmcmd -p lsdg
ALTER DISKGROUP CRS1 ONLINE DISK CRS1_0004;

select GROUP_NUMBER,name,VALUE from v$asm_attribute where name like '%repair_time%';



set lines 555
column pct_free format 99.99
select group_number, name, total_mb, free_mb, total_mb -free_mb used_mb,
case when total_mb=0 then 0 else  free_mb/total_mb *100 end pct_free
from v$asm_diskgroup
/

GROUP_NUMBER NAME											  TOTAL_MB    FREE_MB	 USED_MB PCT_FREE
------------ ------------------------------------------------------------------------------------------ ---------- ---------- ---------- --------
	   5 FRA2											   1048576     319488	  729088    30.47
	   2 DATA1											  15728640     767780	14960860     4.88
	   1 CRS1									    		  3072	     2120	     952    69.01
	   3 DATA2											  16777216    1140202	15637014     6.80
	   4 FRA1											   2097152    1380918	  716234    65.85




set pages 1000
col path format a40
set lines 200
col header_status for a15
col name for a15
col failgroup format a15
col path format a30
select GROUP_NUMBER,NAME, HEADER_STATUS, FAILGROUP,PATH, TOTAL_MB,FREE_MB MOUNT_DATE from v$asm_disk
order by name, failgroup asc;

GROUP_NUMBER NAME	     HEADER_STATUS   FAILGROUP	     PATH			      TOTAL_MB MOUNT_DATE
------------ --------------- --------------- --------------- ---------------- -------------- ---------- ----------
	   1 CRS1_0001	     MEMBER	     FG2	     /dev/asm/CRS-srv40003		      1024	      856
	   1 CRS1_0002	     MEMBER	     FG1	     /dev/asm/CRS-srv40001		      1024	      888
	   1 CRS1_0004	     MEMBER	     FG4	     /dev/asm/CRS-iscsi-quorum		  1024	      376
	   2 DATA1_0000      MEMBER	     FG1	     /dev/asm/data-srv40001-001 	524288	    25396
	   2 DATA1_0001      MEMBER	     FG1	     /dev/asm/data-srv40001-002 	524288	    25382
	   2 DATA1_0002      MEMBER	     FG1	     /dev/asm/data-srv40001-003 	524288	    25415
	   2 DATA1_0003      MEMBER	     FG2	     /dev/asm/data-srv40003-011 	524288	    25576
	   2 DATA1_0004      MEMBER	     FG2	     /dev/asm/data-srv40003-012 	524288	    25557
	   2 DATA1_0005      MEMBER	     FG1	     /dev/asm/data-srv40001-011 	524288	    25424
	   2 DATA1_0006      MEMBER	     FG1	     /dev/asm/data-srv40001-012 	524288	    25561
	   2 DATA1_0007      MEMBER	     FG1	     /dev/asm/data-srv40001-004 	524288	    25559
	   2 DATA1_0011      MEMBER	     FG1	     /dev/asm/data-srv40001-005 	524288	    25548
	   2 DATA1_0012      MEMBER	     FG1	     /dev/asm/data-srv40001-006 	524288	    25578
	   2 DATA1_0013      MEMBER	     FG1	     /dev/asm/data-srv40001-007 	524288	    25574
	   2 DATA1_0017      MEMBER	     FG1	     /dev/asm/data-srv40001-008 	524288	    25576
	   2 DATA1_0018      MEMBER	     FG1	     /dev/asm/data-srv40001-009 	524288	    25580
	   2 DATA1_0019      MEMBER	     FG1	     /dev/asm/data-srv40001-010 	524288	    25587
	   2 DATA1_0020      MEMBER	     FG2	     /dev/asm/data-srv40003-001 	524288	    25567
	   2 DATA1_0021      MEMBER	     FG2	     /dev/asm/data-srv40003-002 	524288	    25504
	   2 DATA1_0022      MEMBER	     FG2	     /dev/asm/data-srv40003-003 	524288	    25398
	   2 DATA1_0023      MEMBER	     FG2	     /dev/asm/data-srv40003-004 	524288	    25557
	   2 DATA1_0024      MEMBER	     FG2	     /dev/asm/data-srv40003-005 	524288	    25565
	   2 DATA1_0025      MEMBER	     FG2	     /dev/asm/data-srv40003-006 	524288	    25554
	   2 DATA1_0026      MEMBER	     FG2	     /dev/asm/data-srv40003-007 	524288	    25395
	   2 DATA1_0027      MEMBER	     FG2	     /dev/asm/data-srv40003-008 	524288	    25557
	   2 DATA1_0028      MEMBER	     FG2	     /dev/asm/data-srv40003-009 	524288	    25600
	   2 DATA1_0029      MEMBER	     FG2	     /dev/asm/data-srv40003-010 	524288	    25422
	   2 DATA1_0030      MEMBER	     FG2	     /dev/asm/data-srv40003-013 	524288	    25343
	   2 DATA1_0031      MEMBER	     FG1	     /dev/asm/data-srv40001-013 	524288	    25401
	   2 DATA1_0032      MEMBER	     FG2	     /dev/asm/data-srv40003-014 	524288	    25396
	   2 DATA1_0033      MEMBER	     FG1	     /dev/asm/data-srv40001-014 	524288	    25374
	   2 DATA1_0034      MEMBER	     FG2	     /dev/asm/data-srv40003-015 	524288	    26899
	   2 DATA1_0035      MEMBER	     FG1	     /dev/asm/data-srv40001-015 	524288	    26935
	   3 DATA2_0000      MEMBER	     FG2	     /dev/asm/data2-srv40003-001	524288	    35629
	   3 DATA2_0001      MEMBER	     FG2	     /dev/asm/data2-srv40003-002	524288	    35425
	   3 DATA2_0002      MEMBER	     FG2	     /dev/asm/data2-srv40003-003	524288	    35460
	   3 DATA2_0003      MEMBER	     FG2	     /dev/asm/data2-srv40003-004	524288	    35618
	   3 DATA2_0004      MEMBER	     FG2	     /dev/asm/data2-srv40003-005	524288	    35657
	   3 DATA2_0005      MEMBER	     FG1	     /dev/asm/data2-srv40001-001	524288	    35488
	   3 DATA2_0006      MEMBER	     FG1	     /dev/asm/data2-srv40001-002	524288	    35493
	   3 DATA2_0007      MEMBER	     FG1	     /dev/asm/data2-srv40001-003	524288	    35441
	   3 DATA2_0008      MEMBER	     FG1	     /dev/asm/data2-srv40001-004	524288	    35479
	   3 DATA2_0009      MEMBER	     FG1	     /dev/asm/data2-srv40001-005	524288	    35454
	   3 DATA2_0010      MEMBER	     FG1	     /dev/asm/data2-srv40001-006	524288	    35472
	   3 DATA2_0011      MEMBER	     FG1	     /dev/asm/data2-srv40001-007	524288	    35478
	   3 DATA2_0012      MEMBER	     FG1	     /dev/asm/data2-srv40001-008	524288	    35603
	   3 DATA2_0013      MEMBER	     FG1	     /dev/asm/data2-srv40001-009	524288	    35615
	   3 DATA2_0014      MEMBER	     FG1	     /dev/asm/data2-srv40001-010	524288	    35632
	   3 DATA2_0015      MEMBER	     FG1	     /dev/asm/data2-srv40001-011	524288	    35634
	   3 DATA2_0016      MEMBER	     FG1	     /dev/asm/data2-srv40001-012	524288	    35611
	   3 DATA2_0017      MEMBER	     FG1	     /dev/asm/data2-srv40001-013	524288	    35619
	   3 DATA2_0018      MEMBER	     FG1	     /dev/asm/data2-srv40001-014	524288	    35611
	   3 DATA2_0019      MEMBER	     FG2	     /dev/asm/data2-srv40003-006	524288	    35465
	   3 DATA2_0020      MEMBER	     FG2	     /dev/asm/data2-srv40003-007	524288	    35483
	   3 DATA2_0021      MEMBER	     FG2	     /dev/asm/data2-srv40003-008	524288	    35439
	   3 DATA2_0022      MEMBER	     FG2	     /dev/asm/data2-srv40003-009	524288	    35645
	   3 DATA2_0023      MEMBER	     FG2	     /dev/asm/data2-srv40003-010	524288	    35609
	   3 DATA2_0024      MEMBER	     FG2	     /dev/asm/data2-srv40003-011	524288	    35648
	   3 DATA2_0025      MEMBER	     FG2	     /dev/asm/data2-srv40003-012	524288	    35624
	   3 DATA2_0026      MEMBER	     FG2	     /dev/asm/data2-srv40003-013	524288	    35584
	   3 DATA2_0027      MEMBER	     FG2	     /dev/asm/data2-srv40003-014	524288	    35475
	   3 DATA2_0028      MEMBER	     FG2	     /dev/asm/data2-srv40003-015	524288	    35496
	   3 DATA2_0029      MEMBER	     FG1	     /dev/asm/data2-srv40001-015	524288	    35614
	   3 DATA2_0030      MEMBER	     FG2	     /dev/asm/data2-srv40003-016	524288	    36844
	   3 DATA2_0031      MEMBER	     FG1	     /dev/asm/data2-srv40001-016	524288	    36857
	   4 FRA1_0002	     MEMBER	     FG1	     /dev/asm/fra-srv40001-001		524288	   345229
	   4 FRA1_0003	     MEMBER	     FG1	     /dev/asm/fra-srv40001-002		524288	   345230
	   4 FRA1_0004	     MEMBER	     FG2	     /dev/asm/fra-srv40003-001		524288	   345233
	   4 FRA1_0005	     MEMBER	     FG2	     /dev/asm/fra-srv40003-002		524288	   345226
	   5 FRA2_0000	     MEMBER	     FG2	     /dev/asm/fra2-srv40003-001 	524288	   159744
	   5 FRA2_0001	     MEMBER	     FG1	     /dev/asm/fra2-srv40001-001 	524288	   159744
	   0		         CANDIDATE			     /dev/asm/data-srv40001-016 	     0		0
	   0		         CANDIDATE			     /dev/asm/data-srv40003-016 	     0		0

73 rows selected.



0                 CANDIDATE                       /dev/asm/data-srv40001-019              0          0
0                 CANDIDATE                       /dev/asm/data-srv40003-019              0          0




SQL> ALTER DISKGROUP DATA1 ADD FAILGROUP FG2 DISK '/dev/asm/data-tkse3par53-014' NAME DATA1_0026 REBALANCE POWER 0;

Diskgroup altered.

SQL> ALTER DISKGROUP DATA1 ADD FAILGROUP FG1 DISK '/dev/asm/data-tkse3par52-014' NAME DATA1_0027 REBALANCE POWER 0;


ALTER DISKGROUP DATA1 ADD FAILGROUP FG1 DISK '/dev/asm/data-srv40001-019' NAME DATA1_0042 REBALANCE POWER 0;


ALTER DISKGROUP DATA1 ADD FAILGROUP FG2 DISK '/dev/asm/data-srv40003-019' NAME DATA1_0043 REBALANCE POWER 0;



Diskgroup altered.

###################################
ALTER DISKGROUP DATA1 ADD DISK '/dev/asm/data1_057' NAME DATA1_0057 REBALANCE POWER 0;
ALTER DISKGROUP DATA1 ADD DISK '/dev/asm/data1_058' NAME DATA1_0058 REBALANCE POWER 0;

 0                 CANDIDATE                       /dev/asm/data1_057                      0          0
 0                 CANDIDATE                       /dev/asm/data1_058                      0          0




set lines 555
column pct_free format 99.99
select group_number, name, total_mb, free_mb, total_mb -free_mb used_mb,
case when total_mb=0 then 0 else  free_mb/total_mb *100 end pct_free
from v$asm_diskgroup
/  

GROUP_NUMBER NAME	       TOTAL_MB    FREE_MB    USED_MB PCT_FREE
------------ --------------- ---------- ---------- ---------- --------
	   5 FRA2		1048576     319488     729088	 30.47
	   2 DATA1	       16777216    1816334   14960882	 10.83
	   1 CRS1		   3072       2120	  952	 69.01
	   3 DATA2	       16777216    1140202   15637014	  6.80
	   4 FRA1		2097152    1402976     694176	 66.90


set pages 1000
col path format a40
set lines 200
col header_status for a15
col name for a15
col failgroup format a15
col path format a30
select GROUP_NUMBER,NAME, HEADER_STATUS, FAILGROUP,PATH, TOTAL_MB,FREE_MB MOUNT_DATE from v$asm_disk
order by name, failgroup asc;

GROUP_NUMBER NAME	     HEADER_STATUS   FAILGROUP	     PATH			      TOTAL_MB MOUNT_DATE
------------ --------------- --------------- --------------- ------------------------------ ---------- ----------
	   1 CRS1_0001	     MEMBER	     FG2	     /dev/asm/CRS-srv40003		  1024	      856
	   1 CRS1_0002	     MEMBER	     FG1	     /dev/asm/CRS-srv40001		  1024	      888
	   1 CRS1_0004	     MEMBER	     FG4	     /dev/asm/CRS-iscsi-quorum		  1024	      376
	   2 DATA1_0000      MEMBER	     FG1	     /dev/asm/data-srv40001-001 	524288	    25396
	   2 DATA1_0001      MEMBER	     FG1	     /dev/asm/data-srv40001-002 	524288	    25382
	   2 DATA1_0002      MEMBER	     FG1	     /dev/asm/data-srv40001-003 	524288	    25415
	   2 DATA1_0003      MEMBER	     FG2	     /dev/asm/data-srv40003-011 	524288	    25576
	   2 DATA1_0004      MEMBER	     FG2	     /dev/asm/data-srv40003-012 	524288	    25557
	   2 DATA1_0005      MEMBER	     FG1	     /dev/asm/data-srv40001-011 	524288	    25424
	   2 DATA1_0006      MEMBER	     FG1	     /dev/asm/data-srv40001-012 	524288	    25561
	   2 DATA1_0007      MEMBER	     FG1	     /dev/asm/data-srv40001-004 	524288	    25559
	   2 DATA1_0011      MEMBER	     FG1	     /dev/asm/data-srv40001-005 	524288	    25548
	   2 DATA1_0012      MEMBER	     FG1	     /dev/asm/data-srv40001-006 	524288	    25578
	   2 DATA1_0013      MEMBER	     FG1	     /dev/asm/data-srv40001-007 	524288	    25574
	   2 DATA1_0017      MEMBER	     FG1	     /dev/asm/data-srv40001-008 	524288	    25576
	   2 DATA1_0018      MEMBER	     FG1	     /dev/asm/data-srv40001-009 	524288	    25580
	   2 DATA1_0019      MEMBER	     FG1	     /dev/asm/data-srv40001-010 	524288	    25587
	   2 DATA1_0020      MEMBER	     FG2	     /dev/asm/data-srv40003-001 	524288	    25567
	   2 DATA1_0021      MEMBER	     FG2	     /dev/asm/data-srv40003-002 	524288	    25504
	   2 DATA1_0022      MEMBER	     FG2	     /dev/asm/data-srv40003-003 	524288	    25398
	   2 DATA1_0023      MEMBER	     FG2	     /dev/asm/data-srv40003-004 	524288	    25557
	   2 DATA1_0024      MEMBER	     FG2	     /dev/asm/data-srv40003-005 	524288	    25565
	   2 DATA1_0025      MEMBER	     FG2	     /dev/asm/data-srv40003-006 	524288	    25554
	   2 DATA1_0026      MEMBER	     FG2	     /dev/asm/data-srv40003-007 	524288	    25395
	   2 DATA1_0027      MEMBER	     FG2	     /dev/asm/data-srv40003-008 	524288	    25557
	   2 DATA1_0028      MEMBER	     FG2	     /dev/asm/data-srv40003-009 	524288	    25600
	   2 DATA1_0029      MEMBER	     FG2	     /dev/asm/data-srv40003-010 	524288	    25422
	   2 DATA1_0030      MEMBER	     FG2	     /dev/asm/data-srv40003-013 	524288	    25343
	   2 DATA1_0031      MEMBER	     FG1	     /dev/asm/data-srv40001-013 	524288	    25401
	   2 DATA1_0032      MEMBER	     FG2	     /dev/asm/data-srv40003-014 	524288	    25396
	   2 DATA1_0033      MEMBER	     FG1	     /dev/asm/data-srv40001-014 	524288	    25374
	   2 DATA1_0034      MEMBER	     FG2	     /dev/asm/data-srv40003-015 	524288	    26899
	   2 DATA1_0035      MEMBER	     FG1	     /dev/asm/data-srv40001-015 	524288	    26935
	   2 DATA1_0036      MEMBER	     FG2	     /dev/asm/data-srv40003-016 	524288	   524277
	   2 DATA1_0037      MEMBER	     FG1	     /dev/asm/data-srv40001-016 	524288	   524277



SQL> ALTER DISKGROUP DATA1 REBALANCE POWER 50;

Diskgroup altered.

SQL> 


set lines 500
col GROUP_NUMBER for a40
col OPERATION for a30
col PASS for a20
col STATE for a20
col POWER for a60
col ERROR_CODE for a30
select * from v$asm_operation;

GROUP_NUMBER OPERATION	     PASS			 STATE		   POWER     ACTUAL	 SOFAR	 EST_WORK   EST_RATE EST_MINUTES ERROR_CODE																  CON_ID
------------ --------------- --------------------------- ------------ ---------- ---------- ---------- ---------- ---------- ----------- ------------------------------------------------------------------------------------------------------------------------------------ ----------
	   2 REBAL	     RESYNC			 DONE		      50	 50	     0		0	   0	       0																	       0
	   2 REBAL	     REBALANCE			 EST		      50	 50	     0		0	   0	       0																	       0
	   2 REBAL	     COMPACT			 WAIT		      50	 50	     0		0	   0	       0																	       0

SQL> /


set lines 400
select * from v$asm_operation;

GROUP_NUMBER OPERATION	     PASS			 STATE		   POWER     ACTUAL	 SOFAR	 EST_WORK   EST_RATE EST_MINUTES ERROR_CODE																  CON_ID
------------ --------------- --------------------------- ------------ ---------- ---------- ---------- ---------- ---------- ----------- ------------------------------------------------------------------------------------------------------------------------------------ ----------
	   2 REBAL	     RESYNC			 DONE		      50	 50	     0		0	   0	       0																	       0
	   2 REBAL	     REBALANCE			 RUN		      50	 50    3307963	  3720313      91523	       4																	       0
	   2 REBAL	     COMPACT			 WAIT		      50	 50	     0		0	   0	       0																	       0
