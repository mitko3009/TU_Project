/********************************************************************************
*********       E-mail subject: EFDE2WEB-879
*********             Instance: UAT1 V8
*********          Description: 
Problem:
SQL query was provided as slow from EUROFACTOR UAT1.

Analysis:
The problem of the provided query is that it selects millions rows from tables g_piece Req and g_piece ParentReq and then for each of the selected rows 
access table g_societe Child. To avoid this, we made one temporary view, which contains the common rows for table g_piece Req and g_piece ParentReq and 
than, using hash join, join table g_societe Child with this view. I executed the provided query in parallel to see what result it will return and it doesn't 
select any rows, the new variant of the query in the New SQL section below also doesn't select any rows, but just to be sure, please check is the query 
in the New SQL section below functionaly correct and if it is, plase apply the suggested modification, if it is not correct, please let me know.

Suggestion:
Please check is the variant of the query in the New SQL section below functionally correct and if it is, please change the query as 
it is shown in the New SQL section below.

*********               SQL_ID: cyaqfp9gsnfjp
*********      Program/Package: 
*********              Request: Dobromir Boyadzhiev 
*********               Author: Dimitar Dimitrov
********* Received e-mail date: 22/07/2024
*********      Resolution date: 22/07/2024
*********  Trace old file here: \\epox\specifs\performance\tmp\
*********  Trace new file here:
***********************************************************************************/

/********************************OLD SQL*******************************************/

SELECT Req.refpiece refRequest
  FROM g_societe Child, 
       g_piece Req, 
       g_piece ParentReq
 WHERE Child.refindividu = ParentReq.gpiadr3
   AND Child.refsoc = Req.gpiadr3
   AND Req.typpiece = 'REQUEST_LIMITE'
   AND Req.fg05 = 'O'
   AND Req.typedoc IN ('C', 'F')
   AND ParentReq.typpiece = 'REQUEST_LIMITE'
   AND ParentReq.gpiheure = Req.gpiheure
   AND ParentReq.typedoc = Req.typedoc
   AND ParentReq.fg05 = 'O';
/********************************OLD SQL*******************************************/
/********************************OLD Metrics***************************************/
/*
Plan hash value: 1437326600
-------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                               | Name            | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  |
-------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                        |                 |      1 |        |    32 (100)|      0 |00:00:00.01 |       0 |      0 |
|   1 |  NESTED LOOPS                           |                 |      1 |      1 |    32   (0)|      0 |00:00:00.01 |       0 |      0 |
|   2 |   NESTED LOOPS                          |                 |      1 |      2 |    32   (0)|   3610K|00:00:04.25 |   28935 |   2946 |
|   3 |    NESTED LOOPS                         |                 |      1 |      2 |    31   (0)|    693 |00:00:01.95 |    5857 |   2171 |
|   4 |     INLIST ITERATOR                     |                 |      1 |        |            |   1836 |00:00:01.93 |    4036 |   2171 |
|*  5 |      TABLE ACCESS BY INDEX ROWID BATCHED| G_PIECE         |      1 |     39 |    30   (0)|   1836 |00:00:01.93 |    4036 |   2171 |
|*  6 |       INDEX RANGE SCAN                  | GP_TYPEDOC      |      1 |  19539 |     1   (0)|   7769 |00:00:00.04 |      38 |     37 |
|*  7 |     INDEX RANGE SCAN                    | REF_SOC         |   1836 |      1 |     1   (0)|    693 |00:00:00.02 |    1821 |      0 |
|*  8 |    INDEX RANGE SCAN                     | GP_GRTYPE_MT_DT |    693 |      1 |     1   (0)|   3610K|00:00:01.83 |   23078 |    775 |
|*  9 |   TABLE ACCESS BY INDEX ROWID           | G_PIECE         |   3610K|      1 |     1   (0)|      0 |00:01:03.12 |    1946K|  58032 |
-------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   5 - filter(("PARENTREQ"."GPIADR3" IS NOT NULL AND "PARENTREQ"."GPIHEURE" IS NOT NULL AND "PARENTREQ"."FG05"='O'))
   6 - access((("PARENTREQ"."TYPEDOC"='C' OR "PARENTREQ"."TYPEDOC"='F')) AND "PARENTREQ"."TYPPIECE"='REQUEST_LIMITE')
   7 - access("CHILD"."REFINDIVIDU"="PARENTREQ"."GPIADR3")
   8 - access("REQ"."TYPPIECE"='REQUEST_LIMITE' AND "PARENTREQ"."GPIHEURE"="REQ"."GPIHEURE")
       filter("REQ"."GPIHEURE" IS NOT NULL)
   9 - filter(("REQ"."GPIADR3" IS NOT NULL AND "CHILD"."REFSOC"="REQ"."GPIADR3" AND "PARENTREQ"."TYPEDOC"="REQ"."TYPEDOC" AND
              "REQ"."FG05"='O' AND INTERNAL_FUNCTION("REQ"."TYPEDOC")))
*/
/********************************OLD Metrics***************************************/

/********************************New SQL*******************************************/

WITH TMP_G_PIECE AS ( SELECT /*+ no_merge full(g_piece) */
                         refpiece,
                         gpiadr3,
                         gpiheure,
                         typedoc
                    FROM g_piece
                   WHERE typpiece = 'REQUEST_LIMITE'
                     AND fg05 = 'O'
                     AND typedoc IN ('C', 'F') )
SELECT /*+ leading(Child Req ParentReq) use_hash(Req ParentReq) */
       Req.refpiece refRequest
  FROM g_societe Child, 
       TMP_G_PIECE Req, 
       TMP_G_PIECE ParentReq
 WHERE Child.refindividu = ParentReq.gpiadr3
   AND Child.refsoc = Req.gpiadr3
   AND ParentReq.gpiheure = Req.gpiheure
   AND ParentReq.typedoc = Req.typedoc;
select * from table(dbms_xplan.display_cursor(null, null, 'RUNSTATS_LAST +COST +HINT_REPORT'));
/********************************New SQL*******************************************/
/********************************New Metrics***************************************/
/*
Plan hash value: 1556096601
--------------------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                | Name                        | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  |
--------------------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                         |                             |      1 |        |  3606K(100)|      0 |00:01:30.44 |      20M|     20M|
|   1 |  TEMP TABLE TRANSFORMATION               |                             |      1 |        |            |      0 |00:01:30.44 |      20M|     20M|
|   2 |   LOAD AS SELECT (CURSOR DURATION MEMORY)| SYS_TEMP_0FD9D67C1_B01CC96F |      1 |        |            |      0 |00:01:29.66 |      20M|     20M|
|*  3 |    TABLE ACCESS FULL                     | G_PIECE                     |      1 |  24890 |  3606K  (1)|    903K|00:01:29.19 |      20M|     20M|
|*  4 |   HASH JOIN                              |                             |      1 |      1 |    48   (3)|      0 |00:00:00.79 |     107 |      1 |
|*  5 |    HASH JOIN                             |                             |      1 |      1 |    25   (4)|   1848 |00:00:00.17 |     107 |      1 |
|   6 |     INDEX FULL SCAN                      | REF_SOC                     |      1 |  19281 |     1   (0)|  19281 |00:00:00.01 |     107 |      1 |
|*  7 |     VIEW                                 |                             |      1 |  24890 |    23   (0)|    807K|00:00:00.12 |       0 |      0 |
|   8 |      TABLE ACCESS FULL                   | SYS_TEMP_0FD9D67C1_B01CC96F |      1 |  24890 |    23   (0)|    903K|00:00:00.08 |       0 |      0 |
|*  9 |    VIEW                                  |                             |      1 |  24890 |    23   (0)|    807K|00:00:00.33 |       0 |      0 |
|  10 |     TABLE ACCESS FULL                    | SYS_TEMP_0FD9D67C1_B01CC96F |      1 |  24890 |    23   (0)|    903K|00:00:00.14 |       0 |      0 |
--------------------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   3 - filter(("TYPPIECE"='REQUEST_LIMITE' AND "FG05"='O'))
   4 - access("CHILD"."REFINDIVIDU"="PARENTREQ"."GPIADR3" AND "PARENTREQ"."GPIHEURE"="REQ"."GPIHEURE" AND "PARENTREQ"."TYPEDOC"="REQ"."TYPEDOC")
   5 - access("CHILD"."REFSOC"="REQ"."GPIADR3")
   7 - filter(("REQ"."TYPEDOC"='C' OR "REQ"."TYPEDOC"='F'))
   9 - filter(("PARENTREQ"."TYPEDOC"='C' OR "PARENTREQ"."TYPEDOC"='F'))
*/
/********************************New Metrics***************************************/

/********************************Index statistics**********************************/

/********************************Other SQLs****************************************/          
/*

*/ 
/********************************Other SQLs****************************************/              
