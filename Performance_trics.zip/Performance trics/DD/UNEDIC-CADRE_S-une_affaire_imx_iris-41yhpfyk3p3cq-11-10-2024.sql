/********************************************************************************
*********       E-mail subject: UDCDEV-5342
*********             Instance: CADRE-S
*********          Description: 
Problem:
The une_affaire_imx_iris took ~4 minutes to export only 3 affaires.

Analysis:
I checked the work of the une_affaire_imx_iris on CADRE-S for the provided period and found that the TOP SQL 41yhpfyk3p3cq was responsible for 79% of the time.
The problem in this SQL is in the second UNION, where it starts the execution from table T_INTERVENANTS DB by making INDEX SKIP SCAN on index INT_REFDOSS and after that  
HASH JOIN it with the dataset made from tables G_DOSSIER D and G_CONNU_EXT_DWH. In this case, where " B2 = 'A' ", the most selective way is to start from table G_CONNU_EXT_DWH 
from condition " extsystem = :b2 " and then with nested loops access table G_DOSSIER D and table T_INTERVENANTS DB. We changed the query to start from table G_CONNU_EXT_DWH, but 
from what I saw, in table G_CONNU_EXT_DWH there are over 900k rows for " EXTSYSTEM = 'I' ", which means that is you use " B2 = 'I' ", the query should go through big amount of data and it will take time.


Suggestion:
1. Please change the query as it is shown in the New SQL section below.
2. Please keep in mind that if you use B2 := 'I', the query should go through the tables with ~1 million rows and it will take time.

*********               SQL_ID: 41yhpfyk3p3cq
*********      Program/Package: 
*********              Request: Wafa Bedoui
*********               Author: Dimitar Dimitrov
********* Received e-mail date: 11/10/2024
*********      Resolution date: 11/10/2024
*********  Trace old file here: \\epox\specifs\performance\tmp\
*********  Trace new file here:
***********************************************************************************/

/********************************OLD SQL*******************************************/

VAR B0 VARCHAR2(32);
EXEC :B0 := 'C';
VAR B2 VARCHAR2(32);
EXEC :B2 := 'A';

SELECT D.REFDOSS,
       D.ancrefdoss,
       TO_CHAR( D.DT_DT_DT, 'YYYY-MM-DD"T"HH24:MI:SS' ),
       TO_CHAR( D.DTCALCULS_dt, 'YYYY-MM-DD"T"HH24:MI:SS' ),
       D.rangmt,
       DB.refindividu,
       D.juriste_sj,
       D.createur,
       D.CODEHONOR,
       D.honoraires,
       NVL( D.SOMMCERTAINE, 'N' ),
       TO_CHAR( D.BUREAU_AGS_DT, 'YYYY-MM-DD' ),
       D.FG_IS_PARENT_COMP
  FROM G_DOSSIER D, 
       T_INTERVENANTS DB
 WHERE :b0 IN ('A', 'B')
   AND D.refspe = 'AFFAIRE'
   AND D.refdoss = DB . refdoss
   AND DB.reftype = 'DB'
   AND D.refdoss IN ( SELECT refdoss
                        FROM t_reprise_list
                       WHERE client = 'DOCAPOSTE'
                         AND createur = 'CODIX'
                         AND resultat = 'AFFAIRE' )
UNION 
SELECT D.REFDOSS,
       D.ancrefdoss,
       TO_CHAR( D.DT_DT_DT, 'YYYY-MM-DD"T"HH24:MI:SS' ),
       TO_CHAR( D.DTCALCULS_dt, 'YYYY-MM-DD"T"HH24:MI:SS' ),
       D.rangmt,
       DB.refindividu,
       D.juriste_sj,
       D.createur,
       D.CODEHONOR,
       D.honoraires,
       NVL( D.SOMMCERTAINE, 'N' ),
       TO_CHAR( D.BUREAU_AGS_DT, 'YYYY-MM-DD' ),
       D.FG_IS_PARENT_COMP
  FROM G_DOSSIER D, 
       T_INTERVENANTS DB
 WHERE :b0 = 'C'
   AND D.refspe = 'AFFAIRE'
   AND D.refdoss = DB.refdoss
   AND DB.reftype = 'DB'
   AND D.refdoss IN ( SELECT REFERENCE
                        FROM G_CONNU_EXT_DWH
                       WHERE TABLENAME = 'G_DOSSIER'
                         AND extsystem = :b2 );
/********************************OLD SQL*******************************************/
/********************************OLD Metrics***************************************/
/*
MODULE                           PROGRAM                                            CLIENT_ID       SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                TO                      ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC  
-------------------------------- -------------------------------------------------- --------------- ------------- ---------- ---------- ---------- -------------------- ------------------- ------------------- ---------- -------------------- ----------------------- ------
une_affaire_imx_iris             une_affaire_imx_iris                                                                                24       6883 db file sequential r 2024/10/09 16:37:27 2024/10/09 16:40:37         17                 1983 +00 00:03:10.167000     28%   
une_sal_imx_iris                 une_sal_imx_iris                                                   8ndfj24y1k6dx  191908165         24      41818 db file parallel rea 2024/10/09 16:42:47 2024/10/09 16:44:57          8                    1 +00 00:02:10.100000     13%   
SQL Developer                    SQL Developer                                                      98sz0jugskfzk 3354864790        808      19536 ON CPU               2024/10/09 16:35:07 2024/10/09 16:36:37          5                   51 +00 00:01:30.095000     8%    
stat_crx                         stat_crx                                                                                                          direct path read     2024/10/09 16:36:07 2024/10/09 16:41:57          5                    2 +00 00:05:50.314000     8%    
une_ent_imx_iris                 une_ent_imx_iris                                                   247y5yfunp2nv 2947938375         24      15571 db file parallel rea 2024/10/09 16:41:27 2024/10/09 16:42:27          4                    1 +00 00:01:00.059000     7%    
une_litp_imx_iris                une_litp_imx_iris                                                  5hadr6b5mbsw7 3855612617         24      44947 db file parallel rea 2024/10/09 16:40:47 2024/10/09 16:41:17          4                    1 +00 00:00:30.033000     7%    
une_sal_imx_iris                 une_sal_imx_iris                                                   8ndfj24y1k6dx  191908165         24      41818 ON CPU               2024/10/09 16:42:37 2024/10/09 16:44:17          4                    1 +00 00:01:40.078000     7%    
une_sal_imx_iris                 une_sal_imx_iris                                                   8ndfj24y1k6dx  191908165         24      41818 db file sequential r 2024/10/09 16:43:47 2024/10/09 16:44:27          3                    1 +00 00:00:40.030000     5%    
MMON_SLAVE                       oracle                                                             30p3mh3brvpt9 2244669142         41      57682 db file sequential r 2024/10/09 16:37:17 2024/10/09 16:37:27          2                    1 +00 00:00:10.009000     3%    
stat_crx                         stat_crx                                                                                           829      52511 ON CPU               2024/10/09 16:41:47 2024/10/09 16:42:07          2                    1 +00 00:00:20.017000     3%    
une_ent_imx_iris                 une_ent_imx_iris                                                   247y5yfunp2nv 2947938375         24      15571 ON CPU               2024/10/09 16:41:37 2024/10/09 16:42:17          2                    1 +00 00:00:40.042000     3%    
une_ent_imx_iris                 une_ent_imx_iris                                                   247y5yfunp2nv 2947938375         24      15571 db file sequential r 2024/10/09 16:41:57 2024/10/09 16:41:57          1                    1 +00 00:00:00.000000     2%    
une_affaire_imx_iris             une_affaire_imx_iris                                               41yhpfyk3p3cq 3344266049         24       6883 ON CPU               2024/10/09 16:39:47 2024/10/09 16:39:47          1                    1 +00 00:00:00.000000     2%    
une_affaire_imx_iris             une_affaire_imx_iris                                               4j4yybj6d2ugx   74011339         24       6883 db file parallel rea 2024/10/09 16:40:27 2024/10/09 16:40:27          1                    1 +00 00:00:00.000000     2%    
sqlplus                          sqlplus                                                            8c90k86169sn2 4190239309         24      35065 control file sequent 2024/10/09 16:35:17 2024/10/09 16:35:17          1                    1 +00 00:00:00.000000     2%    
SQL Developer                    SQL Developer                                                      3da70012yx2ua 1050098399        808      19536 db file sequential r 2024/10/09 16:35:37 2024/10/09 16:35:37          1                    1 +00 00:00:00.000000     2%    


MODULE                           PROGRAM                                            CLIENT_ID       SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                TO                      ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC  
-------------------------------- -------------------------------------------------- --------------- ------------- ---------- ---------- ---------- -------------------- ------------------- ------------------- ---------- -------------------- ----------------------- ------
une_affaire_imx_iris             une_affaire_imx_iris                                                                                24       6883 db file sequential r 2024/10/09 16:37:27 2024/10/09 16:40:37         17                 1983 +00 00:03:10.167000     89%   
une_affaire_imx_iris             une_affaire_imx_iris                                               4j4yybj6d2ugx   74011339         24       6883 db file parallel rea 2024/10/09 16:40:27 2024/10/09 16:40:27          1                    1 +00 00:00:00.000000     5%    
une_affaire_imx_iris             une_affaire_imx_iris                                               41yhpfyk3p3cq 3344266049         24       6883 ON CPU               2024/10/09 16:39:47 2024/10/09 16:39:47          1                    1 +00 00:00:00.000000     5%    


MODULE                           PROGRAM                                            CLIENT_ID       SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                TO                      ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC  
-------------------------------- -------------------------------------------------- --------------- ------------- ---------- ---------- ---------- -------------------- ------------------- ------------------- ---------- -------------------- ----------------------- ------
une_affaire_imx_iris             une_affaire_imx_iris                                                                                24       6883                      2024/10/09 16:37:27 2024/10/09 16:40:37         19                 1983 +00 00:03:10.167000     100%  


MODULE                           PROGRAM                                            CLIENT_ID       SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                TO                      ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC  
-------------------------------- -------------------------------------------------- --------------- ------------- ---------- ---------- ---------- -------------------- ------------------- ------------------- ---------- -------------------- ----------------------- ------
une_affaire_imx_iris             une_affaire_imx_iris                                               41yhpfyk3p3cq 3344266049         24       6883                      2024/10/09 16:37:27 2024/10/09 16:39:47         15                    1 +00 00:02:20.116000     79%   
une_affaire_imx_iris             une_affaire_imx_iris                                               4j4yybj6d2ugx   74011339         24       6883                      2024/10/09 16:40:27 2024/10/09 16:40:37          2                   27 +00 00:00:10.008000     11%   
une_affaire_imx_iris             une_affaire_imx_iris                                               6b0921zqwpra5 1593630923         24       6883 db file sequential r 2024/10/09 16:40:07 2024/10/09 16:40:07          1                    1 +00 00:00:00.000000     5%    
une_affaire_imx_iris             une_affaire_imx_iris                                               37hvug2y88010 2721419635         24       6883 db file sequential r 2024/10/09 16:40:17 2024/10/09 16:40:17          1                    1 +00 00:00:00.000000     5%    




INSTANCE_NUMBER SQL_ID            ELAPSED MAX_WAIT_ON     PC_OF  WAIT_TIME       GETS      READS       ROWS  ELAP/EXEC  GETS/EXEC READS/EXEC  ROWS/EXEC       EXEC PLAN_HASH_VALUE
--------------- ------------- ----------- --------------- ----- ---------- ---------- ---------- ---------- ---------- ---------- ---------- ---------- ---------- ---------------
              1 4j4yybj6d2ugx           3 IO              90%     2,755479      38021       1245       3791 ,03            372,75      12,21      37,17        102        74011339
              1 41yhpfyk3p3cq         141 IO              90%   144,947724     114229     128950          3      140,6     114229     128950          3          0      3344266049
              1 41yhpfyk3p3cq           0 Application     0%             0          0          0          0          0          0          0          0          0       185222475


SQL_ID           SNAP_ID INSTANCE_NUMBER NAME                   POSITION DUP_POSITION DATATYPE_STRING      VALUE_STRING                             INTERVAL               
------------- ---------- --------------- -------------------- ---------- ------------ -------------------- ---------------------------------------- -----------------------
4j4yybj6d2ugx      17791               1 :B0                           1              VARCHAR2(128)        F1288542                                 2024/10/09 17          
4j4yybj6d2ugx      17791               1 :B1                           2              VARCHAR2(128)        1401072641                               2024/10/09 17          
41yhpfyk3p3cq      17791               1 :B0                           1              VARCHAR2(128)        B                                        2024/10/09 17          
41yhpfyk3p3cq      17791               1 :B0                           1              VARCHAR2(128)        C                                        2024/10/09 17          
41yhpfyk3p3cq      17791               1 :B0                           2              VARCHAR2(128)        B                                        2024/10/09 17          
41yhpfyk3p3cq      17791               1 :B0                           2              VARCHAR2(128)        C                                        2024/10/09 17          
41yhpfyk3p3cq      17791               1 :B2                           3              VARCHAR2(128)        list_test_ms.csv                         2024/10/09 17          
41yhpfyk3p3cq      17791               1 :B2                           3              VARCHAR2(128)        A                                        2024/10/09 17   


SQL_ID        SQL_PLAN_HASH_VALUE SQL_PLAN_LINE_ID SQL_PLAN_OPERATION             SQL_PLAN_OPTIONS                   ACTIVE
------------- ------------------- ---------------- ------------------------------ ------------------------------ ----------
4j4yybj6d2ugx            74011339               11 TABLE ACCESS                   BY INDEX ROWID BATCHED                  2
41yhpfyk3p3cq          3344266049               13 INDEX                          SKIP SCAN                              14
41yhpfyk3p3cq          3344266049               12 HASH JOIN                                                              1



INDEX_NAME                     INFO       BLEVEL       ROWS   ROWS/KEY       KEYS     BLOCKS   CF  DATAB/KEY  LEAFB/KEY LAST_ANALYZED       COLUMNS                                                     
------------------------------ ------ ---------- ---------- ---------- ---------- ---------- ---- ---------- ---------- ------------------- ------------------------------------------------------------
PK_G_CONNU_EXT_DWH             UNIQUE          2     925797          1     925797       6899               1          1 2024-10-05 10:25:35 EXTSYSTEM,TABLENAME,REFERENCE     


Plan hash value: 3344266049
--------------------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                | Name               | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  | Writes |
--------------------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                         |                    |      1 |        | 89782 (100)|      3 |00:00:08.18 |     116K|  14880 |  29760 |
|   1 |  SORT UNIQUE                             |                    |      1 |    238K| 89782   (1)|      3 |00:00:08.18 |     116K|  14880 |  29760 |
|   2 |   UNION-ALL                              |                    |      1 |        |            |      3 |00:00:08.18 |     116K|  14880 |  29760 |
|*  3 |    FILTER                                |                    |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |      0 |
|   4 |     NESTED LOOPS                         |                    |      0 |      1 |    66   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|   5 |      NESTED LOOPS                        |                    |      0 |      1 |    65   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*  6 |       TABLE ACCESS BY INDEX ROWID BATCHED| T_REPRISE_LIST     |      0 |      1 |    64   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*  7 |        INDEX RANGE SCAN                  | T_REPLIST_CLIDOSS  |      0 |   1815 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*  8 |       TABLE ACCESS BY INDEX ROWID BATCHED| G_DOSSIER          |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|*  9 |        INDEX RANGE SCAN                  | DOS_REFDOSS        |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|* 10 |      INDEX RANGE SCAN                    | INT_REFDOSS        |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |      0 |
|* 11 |    FILTER                                |                    |      1 |        |            |      3 |00:00:08.18 |     116K|  14880 |  29760 |
|* 12 |     HASH JOIN                            |                    |      1 |    238K| 83415   (1)|      3 |00:00:08.18 |     116K|  14880 |  29760 |
|* 13 |      INDEX SKIP SCAN                     | INT_REFDOSS        |      1 |    677K| 11459   (1)|   8037K|00:00:05.10 |     116K|      0 |      0 |
|  14 |      NESTED LOOPS                        |                    |      1 |    231K| 69637   (1)|      3 |00:00:00.01 |      77 |      0 |      0 |
|  15 |       NESTED LOOPS                       |                    |      1 |    231K| 69637   (1)|     23 |00:00:00.01 |      51 |      0 |      0 |
|* 16 |        INDEX RANGE SCAN                  | PK_G_CONNU_EXT_DWH |      1 |    231K|   173   (0)|     23 |00:00:00.01 |       3 |      0 |      0 |
|* 17 |        INDEX RANGE SCAN                  | DOS_REFDOSS        |     23 |      1 |     1   (0)|     23 |00:00:00.01 |      48 |      0 |      0 |
|* 18 |       TABLE ACCESS BY INDEX ROWID        | G_DOSSIER          |     23 |      1 |     1   (0)|      3 |00:00:00.01 |      26 |      0 |      0 |
--------------------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   3 - filter((:B0='A' OR :B0='B'))
   6 - filter(("RESULTAT"='AFFAIRE' AND "CREATEUR"='CODIX'))
   7 - access("CLIENT"='DOCAPOSTE')
       filter("REFDOSS" IS NOT NULL)
   8 - filter("D"."REFSPE"='AFFAIRE')
   9 - access("D"."REFDOSS"="REFDOSS")
  10 - access("D"."REFDOSS"="DB"."REFDOSS" AND "DB"."REFTYPE"='DB')
  11 - filter(:B0='C')
  12 - access("D"."REFDOSS"="DB"."REFDOSS")
  13 - access("DB"."REFTYPE"='DB')
       filter("DB"."REFTYPE"='DB')
  16 - access("EXTSYSTEM"=:B2 AND "TABLENAME"='G_DOSSIER')
  17 - access("D"."REFDOSS"="REFERENCE")
  18 - filter("D"."REFSPE"='AFFAIRE')
 
*/
/********************************OLD Metrics***************************************/

/********************************New SQL*******************************************/

SELECT D.REFDOSS,
       D.ancrefdoss,
       TO_CHAR( D.DT_DT_DT, 'YYYY-MM-DD"T"HH24:MI:SS' ),
       TO_CHAR( D.DTCALCULS_dt, 'YYYY-MM-DD"T"HH24:MI:SS' ),
       D.rangmt,
       DB.refindividu,
       D.juriste_sj,
       D.createur,
       D.CODEHONOR,
       D.honoraires,
       NVL( D.SOMMCERTAINE, 'N' ),
       TO_CHAR( D.BUREAU_AGS_DT, 'YYYY-MM-DD' ),
       D.FG_IS_PARENT_COMP
  FROM G_DOSSIER D, 
       T_INTERVENANTS DB
 WHERE :b0 IN ('A', 'B')
   AND D.refspe = 'AFFAIRE'
   AND D.refdoss = DB . refdoss
   AND DB.reftype = 'DB'
   AND D.refdoss IN ( SELECT refdoss
                        FROM t_reprise_list
                       WHERE client = 'DOCAPOSTE'
                         AND createur = 'CODIX'
                         AND resultat = 'AFFAIRE' )
UNION 
SELECT /*+ leading(GC D DB) use_nl(DB) */
       D.REFDOSS,
       D.ancrefdoss,
       TO_CHAR( D.DT_DT_DT, 'YYYY-MM-DD"T"HH24:MI:SS' ),
       TO_CHAR( D.DTCALCULS_dt, 'YYYY-MM-DD"T"HH24:MI:SS' ),
       D.rangmt,
       DB.refindividu,
       D.juriste_sj,
       D.createur,
       D.CODEHONOR,
       D.honoraires,
       NVL( D.SOMMCERTAINE, 'N' ),
       TO_CHAR( D.BUREAU_AGS_DT, 'YYYY-MM-DD' ),
       D.FG_IS_PARENT_COMP
  FROM G_DOSSIER D, 
       T_INTERVENANTS DB,
       G_CONNU_EXT_DWH GC
 WHERE :b0 = 'C'
   AND D.refspe = 'AFFAIRE'
   AND D.refdoss = DB.refdoss
   AND DB.reftype = 'DB'
   AND D.refdoss = GC.REFERENCE
   AND GC.TABLENAME = 'G_DOSSIER'
   AND GC.extsystem = :b2;

/********************************New SQL*******************************************/
/********************************New Metrics***************************************/
/*

Plan hash value: 185222475
--------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                | Name               | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers |
--------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                         |                    |      1 |        |   122K(100)|      3 |00:00:00.01 |      85 |
|   1 |  SORT UNIQUE                             |                    |      1 |    238K|   122K  (1)|      3 |00:00:00.01 |      85 |
|   2 |   UNION-ALL                              |                    |      1 |        |            |      3 |00:00:00.01 |      85 |
|*  3 |    FILTER                                |                    |      1 |        |            |      0 |00:00:00.01 |       0 |
|   4 |     NESTED LOOPS                         |                    |      0 |      1 |    66   (0)|      0 |00:00:00.01 |       0 |
|   5 |      NESTED LOOPS                        |                    |      0 |      1 |    65   (0)|      0 |00:00:00.01 |       0 |
|*  6 |       TABLE ACCESS BY INDEX ROWID BATCHED| T_REPRISE_LIST     |      0 |      1 |    64   (0)|      0 |00:00:00.01 |       0 |
|*  7 |        INDEX RANGE SCAN                  | T_REPLIST_CLIDOSS  |      0 |   1815 |     2   (0)|      0 |00:00:00.01 |       0 |
|*  8 |       TABLE ACCESS BY INDEX ROWID BATCHED| G_DOSSIER          |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|*  9 |        INDEX RANGE SCAN                  | DOS_REFDOSS        |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 10 |      INDEX RANGE SCAN                    | INT_REFDOSS        |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 11 |    FILTER                                |                    |      1 |        |            |      3 |00:00:00.01 |      85 |
|  12 |     NESTED LOOPS                         |                    |      1 |    238K|   115K  (1)|      3 |00:00:00.01 |      85 |
|  13 |      NESTED LOOPS                        |                    |      1 |    231K| 69637   (1)|      3 |00:00:00.01 |      77 |
|* 14 |       INDEX RANGE SCAN                   | PK_G_CONNU_EXT_DWH |      1 |    231K|   173   (0)|     23 |00:00:00.01 |       3 |
|* 15 |       TABLE ACCESS BY INDEX ROWID BATCHED| G_DOSSIER          |     23 |      1 |     1   (0)|      3 |00:00:00.01 |      74 |
|* 16 |        INDEX RANGE SCAN                  | DOS_REFDOSS        |     23 |      1 |     1   (0)|     23 |00:00:00.01 |      48 |
|* 17 |      INDEX RANGE SCAN                    | INT_REFDOSS        |      3 |      1 |     1   (0)|      3 |00:00:00.01 |       8 |
--------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   3 - filter((:B0='A' OR :B0='B'))
   6 - filter(("RESULTAT"='AFFAIRE' AND "CREATEUR"='CODIX'))
   7 - access("CLIENT"='DOCAPOSTE')
       filter("REFDOSS" IS NOT NULL)
   8 - filter("D"."REFSPE"='AFFAIRE')
   9 - access("D"."REFDOSS"="REFDOSS")
  10 - access("D"."REFDOSS"="DB"."REFDOSS" AND "DB"."REFTYPE"='DB')
  11 - filter(:B0='C')
  14 - access("GC"."EXTSYSTEM"=:B2 AND "GC"."TABLENAME"='G_DOSSIER')
  15 - filter("D"."REFSPE"='AFFAIRE')
  16 - access("D"."REFDOSS"="GC"."REFERENCE")
  17 - access("D"."REFDOSS"="DB"."REFDOSS" AND "DB"."REFTYPE"='DB')


*/
/********************************New Metrics***************************************/

/********************************Index statistics**********************************/

/********************************Other SQLs****************************************/          
/*

*/ 
/********************************Other SQLs****************************************/              
