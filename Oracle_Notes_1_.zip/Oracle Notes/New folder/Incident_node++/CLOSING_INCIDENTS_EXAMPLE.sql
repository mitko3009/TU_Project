======================================================================================================================================================
#### Connect to OVO server :

ESL--> Node Tools --> Monitoring --> OM Server(качвам се и от там SSH) --> ssh dxcbella@srv1900.thyssen.com

========================================================================================
#######
Oncall agent advised to pend it for office hours.

==================================================================

#### Return to the correct queue ####

 The database is not supported from EMEA oracle team    -----------> Това пишем в дескрипшъна
 
 Затваря се с --  save --> exit
 
 ======
 
 ### Hello team,

AEPW04 is not supported by the EMEA Oracle team 
Please re-route to the proper support team for further investigation  

================================================================================================================

DBSPI-0001.3: DB-SPI cannot connect to database A217, may be down; Oracle error [ORA-04031: unable to allocate 4192 bytes of shared memory 'shared pool','unknown object',]. [Policy:DBMON-DBSPI-0001.3-Critical-ARM]
## The database has been restarted due to cannot connect to database A217 . Due to the inability to  allocate bytes of shared memory . Now the database is up and running ####

Checking instance: 'A217' @ '/u01/app/oracle/product/12.1.0/dbhome_1':
        Connect:         OKAY
        Filter 6:        OKAY
        Filter 4:        OKAY
		
		затваря се със solved
		
		
===============================================================================================================================
===============================================================================================================================


DBSPI-0058: Archive free space percentage 15.00% too low for archive device \wisk7_p\oraarch for WISK7_P <=15%. [Policy:DBMON-DBSPI-0058-ARM]

15/07/2019 18:11:10 (IPEHLIVANSK2@DXC.COM):
####  Current available free disk space on arch dest is above the threshold.###

===============================================================================================================================
================================================================================================================================


EDEL_PRD:ERRORLOG: ORA-07445: Exception aangetroffen: core-dump [evaopn3()+601] [SIGSEGV] [ADDR:0x0] [PC:0x10D0C4C9] [Address not mapped to object] [].

za void, ako se povtarq poveche ot nqkolko pyti se pishe mail

=================================================================================================================================
======================================================================================================================================


DBSPI-0062: Background dump device used percentage 95.00% too high for PCM02IDA1 >=95%. [Policy:DBMON-DBSPI-0062-ARM]

reshava se kato 6-ta metrika,triqt se trc.trm

==================================================================================================================================
===================================================================================================================================

#### No database impact #### Nqma wyzdejstvie vyrhu bazata danni

=======================================================================================================================================
================================================================================================================================

#### Hung process was termined manually ### Zawisnaliq proces be terminiran rychno

==============================================================================================================================
==============================================================================================================================

##### CANCELLED ROUTINE / REJECT - PROCEDURE #####
==============================================================================================================================

Status: Cancelled

Assignment Group: E-CHGIMP-ADECCO-REJECT-CE

Clousure Code: 
Clousure Comments: 

New Update: text, desc

## There are no update objective description for exexution for our power shell.

From the DROP-DOWN menu -> show parent change -> abondon -> clousure code: cancelled -> clousure comment: text -> finish

DESCR: Change will be rejected due to: different output

Change will be REJECTED due to: different output (execution error)


==============================================================================================================================
===============================================================================================================================

##### VRYSHTANE NA TICKET / SEND BACK TICKET #####

vzimame opashkata ot Related Records -> Assignment Workgroup (copy)

i q Paste-vame v Assignment Group

Mahame svoeto ime ot Assignee

Save -> Exit

#### TRANSFERRING ####
### Reason: Database is not under support. According our check this is not Oracle database.
============================================================================================================================
==============================================================================================================================


##### TRANSFERRING TICKET #####

Assignment Group: (must be viewed in ESL, and pasted Assignment Group) W-INCSSP-AVON-ITO-DB

Activities -> Update ->
(Ako izrichno e kazano) Type: waiting for customer
Update:
###### TRANSFERRING #####
###To: W-INCSSP-AVON-ITO-DB
###Reason: Out of our scope. Not supported.

Save
Cancel

==============================================================================================================================
##### SERCICE CALL/REQUEST - USER CLOSURE #####
==============================================================================================================================
RESOLVE -> SAVE -> CLOSE -> CANCEL
RESOLVE -> SAVE -> CANCEL    --  Това се използва,за да могат да се го върнат ако трябва


==============================================================================================================================
##### NO FAULT FOUND #####
==============================================================================================================================

In activities -> Update

### The filesystem is below the threshold, No fault found.

[root@fivatx0128 oracle]# df -kh /oracle
Filesystem                               Size  Used Avail Use% Mounted on
/dev/mapper/vg00-lv_oracle     98G   66G   27G  72% /oracle

Closure Code: No fault found

Solution: ### The filesystem is below the treshold, No fault found.

Resolve - Save - Close - Cancel

==============================================================================================================================
##### VOID #####
==============================================================================================================================

VOID -> Resolve -> Save -> Close -> Cancel

clousure code: Void

Activities -> Update: ### Void ###

==============================================================================================================================
##### FOR PENDING #####
==============================================================================================================================
For PENDING

send email

Activities
type: waiting for customer
update: 
### PENDING for extend ###
or only
### PENDING ###

email comunication

assignee: Delivery instance owner (From HPSM)
change emea_

if the ticket is re-send to another rst [DTS##] - it means you must do it

user closure - EMPTY

Save -> Cancel

==============================================================================================================================
##### INCIDENTS/TICKETS WHICH ARE FOR VOID #####
==============================================================================================================================

[ARESFR-11521] dbspiadm conncheck -nw returns an unexpected result without any instance info
EXT3-fs: : barriers not enabled
UXMON: These metrics exceeded their threshold. Please check OS:15MinLoadUtilzation:15MinLoadUtilzation ACTUAL=32 .
IREPAYPRD:ERRORLOG: ORA-00206: error in writing (block 3, # blocks 1) of control file
DBGSMP:ERRORLOG: ORA-00270: error creating archive log
ejdep12:ERRORLOG: ORA-01122: database file 1 failed verification check
DBSPI10-82: Data logging failed for ORAOSM_METRICS.  Make sure Performance Agent is installed and running. (Unknown error 256)
DBSPI10-82: Data logging failed for ORAUDM_METRICS.  Make sure CODA is running.
[ARESFR-11521] DBSPI10-82: Data logging failed for ORAUDM_METRICS.  Make sure Performance Agent is
Data collection issue identified on server sehdcx0007.adinfra.net {eServiceOK} [fridvhprl806.res.hpe.com] (StPr)
PU5ZS:ERRORLOG: ORA-04031 heap dump being written to trace file /oracle/diag/rdbms/pu5zs/PU5ZS/trace/PU5ZS_ora_41509.trc
DBSPI10-82
DBSPI10-82: Data logging failed for DBSPI_ORA_REPORT.  Make sure Performance Agent is installed and running. (Unknown error)
UHR2D:ERRORLOG: ORA-1652: unable to extend temp segment by 128 in tablespace TEMP
[ARESFR-11521] pl1qmb:ERRORLOG: ORA-1652: unable to extend temp segment by 128 in tablespace
PORA2:ERRORLOG: Minor:ORA-01555 caused by SQL statement below (SQL ID: 8z6jf4nswsn2v, Query Duration=40859 sec, SCN: 0x0038.8ffa6940):
DBSPI-0733: Database MENAD have 35.00 users with 'DBA' privilege too high [Policy:DBMON-DBSPI-0733-ARM]   ##### Namira se fajla v /var/opt/OV/dbspi  i se zakomentira metrikata ####
0731 - syshto se zakomentira
DBSPI10-82: Data logging failed for DBSPI_ORA_GRAPH.  Make sure the performance agent is running.

## VOID, ako e idvalo poveche ot nqkolko dena, togava investigirame: DVNCI_PS:ERRORLOG: ORA-07445: Exception aangetroffen: core-dump [__intel_ssse3_rep_memcpy()+7608] [SIGSEGV] [ADDR:0x7F89B858252D] [PC:0x609CB58] [Address not mapped to object] [].


==============================================================================================================================
DBSPI-0813: Database ERFPRD_1 has 1.00 severe events. [Policy:DBMON-DBSPI-0813-ARM]
==============================================================================================================================
- Ima greshka v config file, contact with AAT

[root@plprdodb301 ~]# dbspicao -m813 -pv -i ERFPRD_1

Instance: 'ERFPRD_1' @ '/u01/app/db/12.1.0/erfprd'
-------------------------------------------------------------
2019-03-29T12:23:17 ERROR dbspicao(10) ERFPRD_1 [metric0813:udm.c:333]: DBSPI31-10: No UDM configuration available (config file 'dbspiudm.cfg' installed?).
