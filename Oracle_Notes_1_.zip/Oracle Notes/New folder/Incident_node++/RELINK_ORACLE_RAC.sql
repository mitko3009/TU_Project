###########################################################################################################
########## ORACLE  RAC  ########
###### STOP CRS /  Relink  /Start CRS  #####

[root@a0ora021t ~]# ps -ef | grep tns
root       136     2  0 Oct10 ?        00:00:00 [netns]
grid      4163     1  0 Oct10 ?        02:32:20 /u01/app/12.1.0/grid/bin/tnslsnr LISTENER -no_crs_notify -inherit
oracle    4167     1  0 Oct10 ?        00:12:22 /u01/app/oracle/product/12.1.0/dbhome_1/bin/tnslsnr LISTENER_BCKP -no_crs_notify -inherit
grid      4224     1  0 Oct10 ?        00:29:29 /u01/app/12.1.0/grid/bin/tnslsnr LISTENER_SCAN1 -no_crs_notify -inherit
root      8963 29668  0 18:21 pts/0    00:00:00 grep --color=auto tns


[root@a0ora021t ~]# ps -ef | grep [p]mon
grid      3006     1  0 Oct10 ?        00:05:54 asm_pmon_+ASM1
oracle    4669     1  0 Oct10 ?        00:09:49 ora_pmon_aquapp1t1
oracle    4673     1  0 Oct10 ?        00:11:48 ora_pmon_aquapp1d1
oracle    4677     1  0 Oct10 ?        00:10:55 ora_pmon_aquapp2t1
oracle    4686     1  0 Oct10 ?        00:08:47 ora_pmon_reaapp1t1
oracle    4688     1  0 Oct10 ?        00:09:35 ora_pmon_fcceap1t1
oracle    8445     1  0 Oct10 ?        00:09:55 ora_pmon_fccoim1d1
oracle    8484     1  0 Oct10 ?        00:09:26 ora_pmon_fccite1d1
oracle    8536     1  0 Oct10 ?        00:09:23 ora_pmon_cpvapp1t1
oracle    8540     1  0 Oct10 ?        00:09:45 ora_pmon_fccoid1t1
oracle    8710     1  0 Oct10 ?        00:09:25 ora_pmon_fccudb1d1
oracle    8780     1  0 Oct10 ?        00:09:13 ora_pmon_fccite1t1
oracle    8785     1  0 Oct10 ?        00:09:49 ora_pmon_fccdocut1
oracle    8805     1  0 Oct10 ?        00:09:30 ora_pmon_cpvapp1d1
oracle    8813     1  0 Oct10 ?        00:10:17 ora_pmon_fccitr1t1
oracle    8846     1  0 Oct10 ?        00:09:26 ora_pmon_fcceap1d1
oracle    8864     1  0 Oct10 ?        00:09:24 ora_pmon_fccoam1t1



fccitr1t:/u01/app/oracle/product/12.1.0/dbhome_1:N              # line added by Agent
aquapp2p:/u01/app/oracle/product/12.1.0/dbhome_1:N              # line added by Agent
fccoam1t:/u01/app/oracle/product/12.1.0/dbhome_1:N              # line added by Agent
aquapp1d:/u01/app/oracle/product/12.1.0/dbhome_1:N              # line added by Agent
fccoid1t:/u01/app/oracle/product/12.1.0/dbhome_1:N              # line added by Agent
fccudb1d:/u01/app/oracle/product/12.1.0/dbhome_1:N              # line added by Agent
reaapp1t:/u01/app/oracle/product/12.1.0/dbhome_1:N              # line added by Agent
cpvapp1d:/u01/app/oracle/product/12.1.0/dbhome_1:N              # line added by Agent
fcceap1d:/u01/app/oracle/product/12.1.0/dbhome_1:N              # line added by Agent
-MGMTDB:/u01/app/12.1.0/grid:N          # line added by Agent
fccite1d:/u01/app/oracle/product/12.1.0/dbhome_1:N              # line added by Agent
+ASM1:/u01/app/12.1.0/grid:N            # line added by Agent
fcceap1t:/u01/app/oracle/product/12.1.0/dbhome_1:N              # line added by Agent
aquapp2t:/u01/app/oracle/product/12.1.0/dbhome_1:N              # line added by Agent
aquapp1t:/u01/app/oracle/product/12.1.0/dbhome_1:N              # line added by Agent
fccoim1d:/u01/app/oracle/product/12.1.0/dbhome_1:N              # line added by Agent
fccite1t:/u01/app/oracle/product/12.1.0/dbhome_1:N              # line added by Agent
fccdocut:/u01/app/oracle/product/12.1.0/dbhome_1:N              # line added by Agent
cpvapp1t:/u01/app/oracle/product/12.1.0/dbhome_1:N              # line added by Agent


=================================================
[root@iracp31 ~]# cd <ASM_Home>/bin
[root@iracp31 bin]# ./crsctl stat res -t -init

[root@iracp31 bin]# dbspicol OFF

### Check after stop crs
[root@iracp31 bin]# ps -ef | grep s.bin
root      1455 15803  0 15:03 pts/1    00:00:00 grep s.bin
[root@iracp31 bin]# ps -ef | grep crs
root      2033 15803  0 15:03 pts/1    00:00:00 grep crs


### as root

 

/u01/app/12.1.0/grid/bin/crsctl stop crs

/u01/app/12.1.0/grid/bin/crsctl disable crs

 
### checks:

/u01/app/12.1.0/grid/bin/crsctl config crs

/u01/app/12.1.0/grid/bin/crsctl stat res -t

ps -fu grid
=======================================
=========================================


 ###### DB Relink ######


## 1) Stop all oracle instances and listeners accessing this ORACLE_HOME. Verify for running processes

 
As root:

 ps -fu oracle

 
## 2) Connect as oracle and relink binaries:

 
$ $ORACLE_HOME/bin/relink all

 
## 3) Check relink log for errors:

 
$ORACLE_HOME/install/relink.log 

 
###### Relink Grid ######

## As root user, unlock the home:

 
cd /u01/app/12.1.0/grid/crs/install

./rootcrs.pl -unlock

 
## As the grid infrastructure owner, relink the binaries:

 
$ export ORACLE_HOME=/u01/app/12.1.0/grid

 $ /u01/app/12.1.0/grid/bin/relink all

 
## As root user, lock the home and start the clusterware:

 
cd /u01/app/12.1.0/grid/rdbms/install

 ./rootadd_rdbms.sh

 

cd /u01/app/12.1.0/grid/crs/install

 ./rootcrs.pl -patch



CRS services (CRS, CSS ASM instances, diskgroups, listeners, DB instances, etc.) will automatically start.

 

$ < Grid Infrastructure Oracle Home>/install/relink.log

 


/u01/app/12.1.0/grid/bin/crsctl enable crs

 

/u01/app/12.1.0/grid/bin/crsctl check crs

 

/u01/app/12.1.0/grid/bin/crsctl config crs

 

/u01/app/12.1.0/grid/bin/crsctl stat res -t

 


dbspicol ON



