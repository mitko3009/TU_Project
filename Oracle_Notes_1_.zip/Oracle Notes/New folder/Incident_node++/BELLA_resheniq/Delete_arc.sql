root@uv162662 # su - oracle
Oracle Corporation      SunOS 5.10      Generic Patch   January 2005
You have mail.
###############################################################################
###############################################################################
!!! Oracle DIAG/TUNING pack is prohibited !!!
###############################################################################
[(WISKI7TI)@uv162662:/export/home/oracle]
$
[(WISKI7TI)@uv162662:/export/home/oracle]
$
[(WISKI7TI)@uv162662:/export/home/oracle]
$ ps -ef | grep pmon
  oracle  9758  8303   0   Jul 01 ?           1:12 ora_pmon_WISKI7TI
  oracle 14536  8303   0   Dec 05 ?          36:45 ora_pmon_KIWIS7TI
  oracle 14283 14272   0 06:46:51 pts/2       0:00 grep pmon
[(WISKI7TI)@uv162662:/export/home/oracle]
$
[(WISKI7TI)@uv162662:/export/home/oracle]
$

$ . oraenv
ORACLE_SID = [WISKI7TI] ? WISKI7TI
The Oracle base remains unchanged with value /oracle
[(WISKI7TI)@uv162662:/export/home/oracle]
$
[(WISKI7TI)@uv162662:/export/home/oracle]
$ rman target /

Recovery Manager: Release 12.2.0.1.0 - Production on Do Jul 4 06:47:44 2019

Copyright (c) 1982, 2017, Oracle and/or its affiliates.  All rights reserved.

Verbonden met doeldatabase: WISKI7TI (DBID=3222797347)

RMAN>

RMAN>

RMAN>

RMAN> crosscheck archivelog all;

Het control-bestand van de doeldatabase wordt gebruikt in plaats van de herstelcatalogus.
Kanaal is toegewezen: ORA_DISK_1.
Kanaal ORA_DISK_1: SID=640 apparaattype=DISK
Validatie is geslaagd voor gearchiveerd logbestand.
Bestandsnaam gearchiveerd log=/oracle/oraarch/WISKI7TI/WISKI7TI_1_208046_968056612.arc RECID=208043 STAMP=1012681429
Validatie is geslaagd voor gearchiveerd logbestand.
Bestandsnaam gearchiveerd log=/oracle/oraarch/WISKI7TI/WISKI7TI_1_208047_968056612.arc RECID=208044 STAMP=1012681469
Validatie is geslaagd voor gearchiveerd logbestand.
Bestandsnaam gearchiveerd log=/oracle/oraarch/WISKI7TI/WISKI7TI_1_208048_968056612.arc RECID=208045 STAMP=1012681520
Validatie is geslaagd voor gearchiveerd logbestand.
Bestandsnaam gearchiveerd log=/oracle/oraarch/WISKI7TI/WISKI7TI_1_208049_968056612.arc RECID=208046 STAMP=1012681566
Validatie is geslaagd voor gearchiveerd logbestand.
Bestandsnaam gearchiveerd log=/oracle/oraarch/WISKI7TI/WISKI7TI_1_208050_968056612.arc RECID=208047 STAMP=1012681624


RMAN>

RMAN>

RMAN> exit


Recovery Manager is voltooid.
[(WISKI7TI)@uv162662:/export/home/oracle]
$
[(WISKI7TI)@uv162662:/export/home/oracle]
$
[(WISKI7TI)@uv162662:/export/home/oracle]
$
[(WISKI7TI)@uv162662:/export/home/oracle]
$ exit
root@uv162662 #
root@uv162662 #
root@uv162662 #
root@uv162662 #
root@uv162662 # dbspicao -m58 -r1
/bin/ksh: dbspicao:  not found
root@uv162662 # df -h /wiski7/orabck
Filesystem             size   used  avail capacity  Mounted on
/wiski7/orabck         1.4T   1.4T   4.7G   100%    /wiski7/orabck
root@uv162662 # df -kh  size   used  avail capacity  Mounted on
/wiski7/orabck         1.4T   1.4T   4.7G   100df: (size      ) not a block device, directory or mounted resource
df: (used      ) not a block device, directory or mounted resource
df: (avail     ) not a block device, directory or mounted resource
df: (capacity  ) not a block device, directory or mounted resource
df: (Mounted   ) not a block device, directory or mounted resource
df: (on        ) not a block device, directory or mounted resource
root@uv162662 # /wiski7/orabck         1.4T   1.4T   4.7G   100
/bin/ksh: /wiski7/orabck: cannot execute
root@uv162662 # df -kh /wiski7/orabck
Filesystem             size   used  avail capacity  Mounted on
/wiski7/orabck         1.4T   1.4T   4.6G   100%    /wiski7/orabck
root@uv162662 # cd /wiski7/orabck
root@uv162662 #
root@uv162662 #
root@uv162662 # ls -la
total 767
drwxr-xr-x   6 oracle   oinstall       7 May 11 19:31 .
drwxr-xr-x   7 oracle   oinstall       7 Jul  1 08:26 ..
drwxr-xr-x   3 oracle   oinstall      55 May  8 14:26 exp
drwxr-xr-x   2 oracle   oinstall       2 Jun  9  2015 flash
drwxr-xr-x   2 oracle   oinstall    2068 Jul  4 04:05 log
-rw-r--r--   1 root     root           0 Feb  9 17:21 redirection
drwxr-xr-x   2 oracle   oinstall     264 Jul  4 06:33 rman
root@uv162662 #
root@uv162662 #
root@uv162662 #
root@uv162662 # cd rman
root@uv162662 #
root@uv162662 #
root@uv162662 # ls -lart
total 3009494207
drwxr-xr-x   6 oracle   oinstall       7 May 11 19:31 ..
-rw-r-----   1 oracle   oinstall 72892416 Jun 25 21:05 WISKI7TI.9317.1.ctl
-rw-r-----   1 oracle   oinstall 72892416 Jun 26 23:59 WISKI7TI.9382.1.ctl
-rw-r-----   1 oracle   oinstall 72892416 Jun 27 23:46 WISKI7TI.9436.1.ctl
-rw-r-----   1 oracle   oinstall 10735468544 Jun 28 20:11 WISKI7TI_2019-06-28_9484.1.lev0
-rw-r-----   1 oracle   oinstall 10735476736 Jun 28 21:18 WISKI7TI_2019-06-28_9484.2.lev0
-rw-r-----   1 oracle   oinstall 10735435776 Jun 28 22:25 WISKI7TI_2019-06-28_9484.3.lev0
-rw-r-----   1 oracle   oinstall 10735689728 Jun 28 23:27 WISKI7TI_2019-06-28_9484.4.lev0
-rw-r-----   1 oracle   oinstall 10735378432 Jun 29 00:36 WISKI7TI_2019-06-28_9484.5.lev0
-rw-r-----   1 oracle   oinstall 10735452160 Jun 29 01:46 WISKI7TI_2019-06-29_9484.6.lev0
-rw-r-----   1 oracle   oinstall 10735501312 Jun 29 02:55 WISKI7TI_2019-06-29_9484.7.lev0
-rw-r-----   1 oracle   oinstall 3476635648 Jun 29 03:20 WISKI7TI_2019-06-29_9484.8.lev0
-rw-r-----   1 oracle   oinstall 7651328 Jun 29 03:21 WISKI7TI_2019-06-29_9490.1.lev0
-rw-r-----   1 oracle   oinstall 72892416 Jun 29 11:25 WISKI7TI.9520.1.ctl
-rw-r-----   1 oracle   oinstall 8872460288 Jun 29 20:54 WISKI7TI_2019-06-29_9544.1.lev1
-rw-r-----   1 oracle   oinstall 7618560 Jun 29 20:54 WISKI7TI_2019-06-29_9550.1.lev1
-rw-r-----   1 oracle   oinstall 72892416 Jun 30 00:33 WISKI7TI.9560.1.ctl
-rw-r-----   1 oracle   oinstall 8749301760 Jun 30 20:50 WISKI7TI_2019-06-30_9602.1.lev1
-rw-r-----   1 oracle   oinstall 7618560 Jun 30 20:50 WISKI7TI_2019-06-30_9607.1.lev1
-rw-r-----   1 oracle   oinstall 72892416 Jun 30 23:56 WISKI7TI.9616.1.ctl
-rw-r-----   1 oracle   oinstall  114688 Jun 30 23:56 WISKI7TI.9617.1.spf
-rw-r-----   1 oracle   oinstall 1131313152 Jul  1 00:53 WISKI7TI_2019-07-01_9614.2.arc
-rw-r-----   1 oracle   oinstall 10735330816 Jul  1 02:09 WISKI7TI_2019-07-01_9618.1.arc
-rw-r-----   1 oracle   oinstall 1171044352 Jul  1 02:16 WISKI7TI_2019-07-01_9618.2.arc
-rw-r-----   1 oracle   oinstall 10735585792 Jul  1 02:22 WISKI7TI_2019-07-01_9619.1.arc
-rw-r-----   1 oracle   oinstall 1306064384 Jul  1 02:30 WISKI7TI_2019-07-01_9619.2.arc
-rw-r-----   1 oracle   oinstall 10735622144 Jul  1 03:16 WISKI7TI_2019-07-01_9620.1.arc
-rw-r-----   1 oracle   oinstall 1690561024 Jul  1 03:27 WISKI7TI_2019-07-01_9620.2.arc
-rw-r-----   1 oracle   oinstall 10735375360 Jul  1 03:29 WISKI7TI_2019-07-01_9621.1.arc
-rw-r-----   1 oracle   oinstall 1178650112 Jul  1 03:36 WISKI7TI_2019-07-01_9621.2.arc
-rw-r-----   1 oracle   oinstall 10735464448 Jul  1 03:41 WISKI7TI_2019-07-01_9622.1.arc
-rw-r-----   1 oracle   oinstall 1440265728 Jul  1 03:51 WISKI7TI_2019-07-01_9622.2.arc
-rw-r-----   1 oracle   oinstall 10735863808 Jul  1 04:41 WISKI7TI_2019-07-01_9623.1.arc
-rw-r-----   1 oracle   oinstall 1447936000 Jul  1 04:51 WISKI7TI_2019-07-01_9623.2.arc
-rw-r-----   1 oracle   oinstall 10735348736 Jul  1 04:54 WISKI7TI_2019-07-01_9624.1.arc
-rw-r-----   1 oracle   oinstall 1278407168 Jul  1 05:02 WISKI7TI_2019-07-01_9624.2.arc
-rw-r-----   1 oracle   oinstall 10735391232 Jul  1 05:08 WISKI7TI_2019-07-01_9625.1.arc
-rw-r-----   1 oracle   oinstall 1292932608 Jul  1 05:17 WISKI7TI_2019-07-01_9625.2.arc
-rw-r-----   1 oracle   oinstall 10735875584 Jul  1 05:27 WISKI7TI_2019-07-01_9626.1.arc
-rw-r-----   1 oracle   oinstall 1310484480 Jul  1 05:36 WISKI7TI_2019-07-01_9626.2.arc
-rw-r-----   1 oracle   oinstall 10735673856 Jul  1 06:09 WISKI7TI_2019-07-01_9627.1.arc
-rw-r-----   1 oracle   oinstall 1558891520 Jul  1 06:20 WISKI7TI_2019-07-01_9627.2.arc
-rw-r-----   1 oracle   oinstall 10735616512 Jul  1 06:22 WISKI7TI_2019-07-01_9628.1.arc
-rw-r-----   1 oracle   oinstall 1051436544 Jul  1 06:30 WISKI7TI_2019-07-01_9628.2.arc
-rw-r-----   1 oracle   oinstall 10735510528 Jul  1 06:34 WISKI7TI_2019-07-01_9629.1.arc
-rw-r-----   1 oracle   oinstall 1469381632 Jul  1 06:44 WISKI7TI_2019-07-01_9629.2.arc
-rw-r-----   1 oracle   oinstall 10735521792 Jul  1 06:59 WISKI7TI_2019-07-01_9630.1.arc
-rw-r-----   1 oracle   oinstall 1396912128 Jul  1 07:11 WISKI7TI_2019-07-01_9630.2.arc
-rw-r-----   1 oracle   oinstall 10735421952 Jul  1 07:35 WISKI7TI_2019-07-01_9631.1.arc
-rw-r-----   1 oracle   oinstall 10735393792 Jul  1 07:41 WISKI7TI_2019-07-01_9632.1.arc
-rw-r-----   1 oracle   oinstall 1144279552 Jul  1 07:41 WISKI7TI_2019-07-01_9631.2.arc
-rw-r-----   1 oracle   oinstall 138729984 Jul  1 07:42 WISKI7TI_2019-07-01_9632.2.arc
-rw-r-----   1 oracle   oinstall 10735520256 Jul  1 09:51 WISKI7TI_2019-07-01_9637.1.arc
-rw-r-----   1 oracle   oinstall 1969598976 Jul  1 10:00 WISKI7TI_2019-07-01_9637.2.arc
-rw-r-----   1 oracle   oinstall 10735590912 Jul  1 10:52 WISKI7TI_2019-07-01_9638.1.arc
-rw-r-----   1 oracle   oinstall 1712016384 Jul  1 11:01 WISKI7TI_2019-07-01_9638.2.arc
-rw-r-----   1 oracle   oinstall 10735561728 Jul  1 12:03 WISKI7TI_2019-07-01_9639.1.arc
-rw-r-----   1 oracle   oinstall 10735509504 Jul  1 12:12 WISKI7TI_2019-07-01_9640.1.arc
-rw-r-----   1 oracle   oinstall 1681040896 Jul  1 12:13 WISKI7TI_2019-07-01_9639.2.arc
-rw-r-----   1 oracle   oinstall 322352128 Jul  1 12:14 WISKI7TI_2019-07-01_9640.2.arc
-rw-r-----   1 oracle   oinstall 10735447552 Jul  1 13:16 WISKI7TI_2019-07-01_9641.1.arc
-rw-r-----   1 oracle   oinstall 10735348736 Jul  1 13:20 WISKI7TI_2019-07-01_9642.1.arc
-rw-r-----   1 oracle   oinstall 528292864 Jul  1 13:23 WISKI7TI_2019-07-01_9642.2.arc
-rw-r-----   1 oracle   oinstall 1951328256 Jul  1 13:29 WISKI7TI_2019-07-01_9641.2.arc
-rw-r-----   1 oracle   oinstall 10735594496 Jul  1 14:14 WISKI7TI_2019-07-01_9643.1.arc
-rw-r-----   1 oracle   oinstall 1082394112 Jul  1 14:20 WISKI7TI_2019-07-01_9643.2.arc
-rw-r-----   1 oracle   oinstall 10735507968 Jul  1 14:30 WISKI7TI_2019-07-01_9644.1.arc
-rw-r-----   1 oracle   oinstall 291357696 Jul  1 14:32 WISKI7TI_2019-07-01_9644.2.arc
-rw-r-----   1 oracle   oinstall 10735415808 Jul  1 14:32 WISKI7TI_2019-07-01_9645.1.arc
-rw-r-----   1 oracle   oinstall 1642014208 Jul  1 14:43 WISKI7TI_2019-07-01_9645.2.arc
-rw-r-----   1 oracle   oinstall 10735599104 Jul  1 15:28 WISKI7TI_2019-07-01_9646.1.arc
-rw-r-----   1 oracle   oinstall 1246551552 Jul  1 15:37 WISKI7TI_2019-07-01_9646.2.arc
-rw-r-----   1 oracle   oinstall 10735441408 Jul  1 15:42 WISKI7TI_2019-07-01_9647.1.arc
-rw-r-----   1 oracle   oinstall 327394816 Jul  1 15:44 WISKI7TI_2019-07-01_9647.2.arc
-rw-r-----   1 oracle   oinstall 10735328768 Jul  1 15:54 WISKI7TI_2019-07-01_9648.1.arc
-rw-r-----   1 oracle   oinstall 979124736 Jul  1 16:02 WISKI7TI_2019-07-01_9648.2.arc
-rw-r-----   1 oracle   oinstall 10563002368 Jul  1 16:19 WISKI7TI_2019-07-01_9649.1.arc
-rw-r-----   1 oracle   oinstall 10519863296 Jul  1 17:04 WISKI7TI_2019-07-01_9652.1.arc
-rw-r-----   1 oracle   oinstall 10647364608 Jul  1 18:07 WISKI7TI_2019-07-01_9654.1.arc
-rw-r-----   1 oracle   oinstall 10735604224 Jul  1 18:10 WISKI7TI_2019-07-01_9655.1.arc
-rw-r-----   1 oracle   oinstall 484044800 Jul  1 18:14 WISKI7TI_2019-07-01_9655.2.arc
-rw-r-----   1 oracle   oinstall 10396164096 Jul  1 19:11 WISKI7TI_2019-07-01_9656.1.arc
-rw-r-----   1 oracle   oinstall 10735504384 Jul  1 19:22 WISKI7TI_2019-07-01_9657.1.arc
-rw-r-----   1 oracle   oinstall 499117056 Jul  1 19:25 WISKI7TI_2019-07-01_9657.2.arc
-rw-r-----   1 oracle   oinstall 10334812160 Jul  1 20:18 WISKI7TI_2019-07-01_9659.1.arc
-rw-r-----   1 oracle   oinstall 8906096640 Jul  1 20:32 WISKI7TI_2019-07-01_9658.1.lev1
-rw-r-----   1 oracle   oinstall 7618560 Jul  1 20:32 WISKI7TI_2019-07-01_9662.1.lev1
-rw-r-----   1 oracle   oinstall 10735338496 Jul  1 20:37 WISKI7TI_2019-07-01_9660.1.arc
-rw-r-----   1 oracle   oinstall 210141696 Jul  1 20:39 WISKI7TI_2019-07-01_9660.2.arc
-rw-r-----   1 oracle   oinstall 9688634368 Jul  1 21:21 WISKI7TI_2019-07-01_9661.1.arc
-rw-r-----   1 oracle   oinstall 10735600128 Jul  1 21:43 WISKI7TI_2019-07-01_9663.1.arc
-rw-r-----   1 oracle   oinstall 10728016896 Jul  1 21:54 WISKI7TI_2019-07-01_9664.1.arc
-rw-r-----   1 oracle   oinstall 1942389760 Jul  1 21:55 WISKI7TI_2019-07-01_9663.2.arc
-rw-r-----   1 oracle   oinstall 72892416 Jul  1 21:55 WISKI7TI.9667.1.ctl
-rw-r-----   1 oracle   oinstall  114688 Jul  1 21:55 WISKI7TI.9668.1.spf
-rw-r-----   1 oracle   oinstall 10654437376 Jul  1 23:07 WISKI7TI_2019-07-01_9666.1.arc
-rw-r-----   1 oracle   oinstall 10735465472 Jul  2 00:21 WISKI7TI_2019-07-01_9669.1.arc
-rw-r-----   1 oracle   oinstall 147106816 Jul  2 00:22 WISKI7TI_2019-07-02_9669.2.arc
-rw-r-----   1 oracle   oinstall 1210337280 Jul  3 01:42 WISKI7TI_2019-07-03_9714.2.arc
-rw-r-----   1 oracle   oinstall 10735434240 Jul  3 02:31 WISKI7TI_2019-07-03_9715.1.arc
-rw-r-----   1 oracle   oinstall 2094388736 Jul  3 02:44 WISKI7TI_2019-07-03_9715.2.arc
-rw-r-----   1 oracle   oinstall 10735649792 Jul  3 02:56 WISKI7TI_2019-07-03_9716.1.arc
-rw-r-----   1 oracle   oinstall 925659648 Jul  3 03:02 WISKI7TI_2019-07-03_9716.2.arc
-rw-r-----   1 oracle   oinstall 10735603200 Jul  3 03:19 WISKI7TI_2019-07-03_9717.1.arc
-rw-r-----   1 oracle   oinstall 2044970496 Jul  3 03:32 WISKI7TI_2019-07-03_9717.2.arc
-rw-r-----   1 oracle   oinstall 10735366656 Jul  3 03:55 WISKI7TI_2019-07-03_9718.1.arc
-rw-r-----   1 oracle   oinstall 2135947264 Jul  3 04:11 WISKI7TI_2019-07-03_9718.2.arc
-rw-r-----   1 oracle   oinstall 1546793472 Jul  3 12:27 WISKI7TI_2019-07-03_9739.2.arc
-rw-r-----   1 oracle   oinstall 10735449088 Jul  3 12:42 WISKI7TI_2019-07-03_9741.1.arc
-rw-r-----   1 oracle   oinstall 10735583744 Jul  3 12:44 WISKI7TI_2019-07-03_9742.1.arc
-rw-r-----   1 oracle   oinstall 301732352 Jul  3 12:46 WISKI7TI_2019-07-03_9742.2.arc
-rw-r-----   1 oracle   oinstall 1354177536 Jul  3 12:48 WISKI7TI_2019-07-03_9741.2.arc
-rw-r-----   1 oracle   oinstall 10735425536 Jul  3 13:23 WISKI7TI_2019-07-03_9743.1.arc
-rw-r-----   1 oracle   oinstall 447384064 Jul  3 13:26 WISKI7TI_2019-07-03_9743.2.arc
-rw-r-----   1 oracle   oinstall 10735531520 Jul  3 13:27 WISKI7TI_2019-07-03_9744.1.arc
-rw-r-----   1 oracle   oinstall 73056256 Jul  3 13:28 WISKI7TI.9748.1.ctl
-rw-r-----   1 oracle   oinstall 72990720 Jul  3 13:28 WISKI7TI_control.bck
-rw-r-----   1 oracle   oinstall  114688 Jul  3 13:29 WISKI7TI.9749.1.spf
-rw-r--r--   1 oracle   oinstall    1307 Jul  3 13:29 initWISKI7TI.ora
-rw-r-----   1 oracle   oinstall 1555141632 Jul  3 13:39 WISKI7TI_2019-07-03_9744.2.arc
-rw-r-----   1 oracle   oinstall 10735420928 Jul  3 13:52 WISKI7TI_2019-07-03_9745.1.arc
-rw-r-----   1 oracle   oinstall 402080256 Jul  3 13:55 WISKI7TI_2019-07-03_9745.2.arc
-rw-r-----   1 oracle   oinstall 10735703552 Jul  3 14:18 WISKI7TI_2019-07-03_9747.1.arc
-rw-r-----   1 oracle   oinstall 650500608 Jul  3 14:21 WISKI7TI_2019-07-03_9747.2.arc
-rw-r-----   1 oracle   oinstall 10735732224 Jul  3 15:24 WISKI7TI_2019-07-03_9752.1.arc
-rw-r-----   1 oracle   oinstall 314120192 Jul  3 15:26 WISKI7TI_2019-07-03_9752.2.arc
-rw-r-----   1 oracle   oinstall 10735823872 Jul  3 16:17 WISKI7TI_2019-07-03_9753.1.arc
-rw-r-----   1 oracle   oinstall 330719232 Jul  3 16:19 WISKI7TI_2019-07-03_9753.2.arc
-rw-r-----   1 oracle   oinstall 8859598336 Jul  3 16:23 WISKI7TI_2019-07-03_9754.1.arc
-rw-r-----   1 oracle   oinstall 8817131008 Jul  3 17:14 WISKI7TI_2019-07-03_9756.1.arc
-rw-r-----   1 oracle   oinstall 10735357440 Jul  4 06:27 WISKI7TI_2019-07-04_9773.1.arc
-rw-r-----   1 oracle   oinstall 856461312 Jul  4 06:33 WISKI7TI_2019-07-04_9773.2.arc
drwxr-xr-x   2 oracle   oinstall     264 Jul  4 06:33 .
-rw-r-----   1 oracle   oinstall 3098542592 Jul  4 06:52 WISKI7TI_2019-07-04_9775.1.arc
-rw-r-----   1 oracle   oinstall 9017754112 Jul  4 06:52 WISKI7TI_2019-07-04_9774.1.arc
root@uv162662 # pwd
/wiski7/orabck/rman
root@uv162662 # rm -f WISKI7TI_2019-07-01_*.arc


root@uv162662 # df -h .
Filesystem             size   used  avail capacity  Mounted on
/wiski7/orabck         1.4T   1.0T   434G    71%    /wiski7/orabck
root@uv162662 #
Using username "dxcbella".
Authenticating with public key "imported-openssh-key" from agent
Last login: Thu Jul  4 06:46:07 2019 from bebsumvg001.et.
Oracle Corporation      SunOS 5.10      Generic Patch   January 2005
