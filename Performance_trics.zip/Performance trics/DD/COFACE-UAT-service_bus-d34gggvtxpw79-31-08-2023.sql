/********************************************************************************
*********       E-mail subject: COFAWEB-7115
*********             Instance: UAT
*********          Description: 
Problem:
There was a performance issue with function utl_dc_auto_invoicing_get.getSplitInsured();

Analysis:
We analyzed the service_bus call between 12:00 and 12:11 on 28/08/2023.
The problem was in SQL with id d34gggvtxpw79. 
This SQL occasionally generates an execution plan, starting from DF_NUM <= NVL(:B1, DF_NUM), because it is executed with :B1 := null.
On the next execution, the oracle re-uses the previously generated plan, but this time :B1 is not null, which leads to a wide index range scan on DETFAC_NUM.
The solution is to concatenate '' to DF_NUM. By this way Oracle will not use that index, will not devide the query on two parts and will not start the execution from that column.


Suggestion:
Please add '' to column DF_NUM on the last row of the query as it is shown in the New SQL section below.

*********               SQL_ID: d34gggvtxpw79
*********      Program/Package: service_bus_server
*********              Request: Dimitare Ivanov
*********               Author: Dimitar Dimitrov
********* Received e-mail date: 30/08/2023
*********      Resolution date: 31/08/2023
*********  Trace old file here: \\epox\specifs\performance\tmp\
*********  Trace new file here:
***********************************************************************************/

/********************************OLD SQL*******************************************/
SELECT DECODE(:B7,
              'I',
              NVL(SUM(NVL(DF_MONTTC_CON, 0)), 0),
              'C',
              NVL(SUM(NVL(DF_MONTTC_DOS, 0)), 0),
              'B',
              NVL(SUM(NVL(DF_MONTTC_BU, 0)), 0),
              'A',
              NVL(SUM(NVL(DF_MONTTC, 0)), 0),
              'M',
              NVL(SUM(NVL(DF_MONTTC_MVT, 0)), 0),
              0)
  FROM F_DETFAC DF
 WHERE DF_NOM IN ('SAC', 'VDIR')
   AND DF_DOS = :B6
   AND NVL(DF_ANN, 0) = 0
   AND (PHASE_CREAT_REF = :B5 OR :B5 IS NULL)
   AND (:B4 = 'ALL' OR
       (:B4 IN ('CURRENT', 'CURRSPLIT') AND DF_REFINIT = :B3) OR
       (:B4 = 'OLD' AND NVL(DF_REFINIT, 'x') <> :B3 AND NOT EXISTS
        (SELECT 1
            FROM G_ENCAISSEMENT
           WHERE REFENCAISS = DF.DF_REFINIT
             AND REFDOSS = DF.DF_DOS
             AND CREATEUR = 'cfc_migration'
             AND NVL(TO_CHAR(DTRECEPTION_DT, 'J'), 0) <= :B8)) OR
       (:B4 = 'OLDWM' AND NVL(DF_REFINIT, 'x') <> :B3 AND NOT EXISTS
        (SELECT 1
            FROM G_ENCAISSEMENT
           WHERE REFENCAISS = DF.DF_REFINIT
             AND CREATEUR = 'cfc_migration')) OR
       (:B4 = 'OLDM' AND NVL(DF_REFINIT, 'x') <> :B3 AND EXISTS
        (SELECT 1
            FROM G_ENCAISSEMENT
           WHERE REFENCAISS = DF.DF_REFINIT
             AND REFDOSS = DF.DF_DOS
             AND CREATEUR = 'cfc_migration'
             AND NVL(TO_CHAR(DTRECEPTION_DT, 'J'), 0) > :B8)))
   AND NOT EXISTS
 (SELECT 1
          FROM T_INTERVENANTS
         WHERE REFDOSS = DF_DOS
           AND REFTYPE = 'BU'
           AND REFINDIVIDU = DF_CLI)
   AND TO_CHAR(DF_TAUX_DT, 'j') <= NVL(:B2, TO_CHAR(DF_TAUX_DT, 'j'))
   AND DF_NUM <= NVL(:B1, DF_NUM);
/********************************OLD SQL*******************************************/
/********************************OLD Metrics***************************************/
/*
 MODULE                           SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL              PERC
-------------------------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
imx2easy_monitoring              8yccgkdw6ufjb  222606624        607       4326 db file sequential r 2023/08/28 12:00:11  2023/08/28 12:13:32          35        30 +000000000 00:13:20.409 13%
imx2easy_monitoring              8yccgkdw6ufjb  222606624        607       4326 ON CPU               2023/08/28 11:56:01  2023/08/28 12:14:42          28        51 +000000000 00:18:40.676 10%
service_bus_server519FEDD0CD50A0                                                ON CPU               2023/08/28 12:03:51  2023/08/28 12:10:02          27      1700 +000000000 00:06:10.178 10%
6FAC09B7A78671425B

MODULE                           ACTION                    SQL_ID               PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO    ACTIVE NUMBER_OF_EXECUTIONS INTERVAL         PERC
-------------------------------- ------------------------- ------------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
service_bus_server519FEDD0CD50A0 2/406/558250              d34gggvtxpw79        200349768        110      59185                      2023/08/28 12:01:51  2023/08/28 12:10:02        50                  214 +000000000 00:08:10.354 94%
6FAC09B7A78671425B

service_bus_server519FEDD0CD50A0 2/652/558229              5dabz1pvatgs0       3792502790        300      40556 db file sequential r 2023/08/28 12:03:01  2023/08/28 12:03:01         1                    1 +000000000 00:00:00.000 2%
6FAC09B7A78671425B

service_bus_server519FEDD0CD50A0 2/309/558256              3cfqf7kuup8pz       1670309620        457      42002 ON CPU               2023/08/28 12:06:51  2023/08/28 12:06:51         1                    1 +000000000 00:00:00.000 2%
6FAC09B7A78671425B

service_bus_server519FEDD0CD50A0 2/406/558250              859pf9x41baq4                0        110      59185 db file sequential r 2023/08/28 12:01:41  2023/08/28 12:01:41         1                    1 +000000000 00:00:00.000 2%
6FAC09B7A78671425B

Plan hash value: 200349768
--------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                | Name            | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  |
--------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                         |                 |      1 |        |     4 (100)|      1 |00:00:18.14 |     728K|  55808 |
|   1 |  SORT AGGREGATE                          |                 |      1 |      1 |            |      1 |00:00:18.14 |     728K|  55808 |
|   2 |   CONCATENATION                          |                 |      1 |        |            |     23 |00:00:18.14 |     728K|  55808 |
|*  3 |    FILTER                                |                 |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
|*  4 |     FILTER                               |                 |      1 |        |            |      0 |00:00:00.01 |       0 |      0 |
|   5 |      NESTED LOOPS ANTI                   |                 |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*  6 |       TABLE ACCESS BY INDEX ROWID BATCHED| F_DETFAC        |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*  7 |        INDEX RANGE SCAN                  | IDX_DETFAC_DCPT |      0 |      5 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*  8 |       INDEX RANGE SCAN                   | INT_REFDOSS     |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*  9 |     TABLE ACCESS BY INDEX ROWID          | G_ENCAISSEMENT  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 10 |      INDEX UNIQUE SCAN                   | REFENCAISS      |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 11 |     TABLE ACCESS BY INDEX ROWID          | G_ENCAISSEMENT  |     30 |      1 |     1   (0)|      7 |00:00:00.01 |     110 |      0 |
|* 12 |      INDEX UNIQUE SCAN                   | REFENCAISS      |     30 |      1 |     1   (0)|     30 |00:00:00.01 |      77 |      0 |
|* 13 |     TABLE ACCESS BY INDEX ROWID          | G_ENCAISSEMENT  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 14 |      INDEX UNIQUE SCAN                   | REFENCAISS      |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 15 |    FILTER                                |                 |      1 |        |            |     23 |00:00:18.14 |     728K|  55808 |
|* 16 |     FILTER                               |                 |      1 |        |            |     30 |00:00:18.13 |     728K|  55808 |
|  17 |      NESTED LOOPS ANTI                   |                 |      1 |      1 |     2   (0)|     30 |00:00:18.13 |     728K|  55808 |
|* 18 |       TABLE ACCESS BY INDEX ROWID BATCHED| F_DETFAC        |      1 |      1 |     1   (0)|     30 |00:00:18.13 |     728K|  55808 |
|* 19 |        INDEX RANGE SCAN                  | DETFAC_NUM      |      1 |      1 |     1   (0)|    889K|00:00:00.94 |    2537 |   2537 |
|* 20 |       INDEX RANGE SCAN                   | INT_REFDOSS     |      1 |      1 |     1   (0)|      0 |00:00:00.01 |       3 |      0 |
|* 21 |     TABLE ACCESS BY INDEX ROWID          | G_ENCAISSEMENT  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 22 |      INDEX UNIQUE SCAN                   | REFENCAISS      |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 23 |     TABLE ACCESS BY INDEX ROWID          | G_ENCAISSEMENT  |     30 |      1 |     1   (0)|      7 |00:00:00.01 |     110 |      0 |
|* 24 |      INDEX UNIQUE SCAN                   | REFENCAISS      |     30 |      1 |     1   (0)|     30 |00:00:00.01 |      77 |      0 |
|* 25 |     TABLE ACCESS BY INDEX ROWID          | G_ENCAISSEMENT  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 26 |      INDEX UNIQUE SCAN                   | REFENCAISS      |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
--------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   3 - filter((:B4='ALL' OR ("DF_REFINIT"=:B3 AND (:B4='CURRENT' OR :B4='CURRSPLIT')) OR (:B4='OLD' AND NVL("DF_REFINIT",'x')<>:B3
              AND  IS NULL) OR (:B4='OLDWM' AND NVL("DF_REFINIT",'x')<>:B3 AND  IS NULL) OR (:B4='OLDM' AND NVL("DF_REFINIT",'x')<>:B3 AND  IS
              NOT NULL)))
   4 - filter(:B1 IS NULL)
   6 - filter(((:B5 IS NULL OR "PHASE_CREAT_REF"=:B5) AND "DF_NUM"<="DF_NUM" AND INTERNAL_FUNCTION("DF_NOM") AND
              TO_NUMBER(TO_CHAR(INTERNAL_FUNCTION("DF_TAUX_DT"),'j'))<=NVL(:B2,TO_NUMBER(TO_CHAR(INTERNAL_FUNCTION("DF_TAUX_DT"),'j'))) AND
              NVL("DF_ANN",0)=0))
   7 - access("DF_DOS"=:B6)
   8 - access("REFDOSS"=:B6 AND "REFTYPE"='BU' AND "REFINDIVIDU"="DF_CLI")
   9 - filter(("REFDOSS"=:B1 AND "CREATEUR"='cfc_migration' AND TO_NUMBER(NVL(TO_CHAR(INTERNAL_FUNCTION("DTRECEPTION_DT"),'j'),'0'))
              <=:B8))
  10 - access("REFENCAISS"=:B1)
  11 - filter("CREATEUR"='cfc_migration')
  12 - access("REFENCAISS"=:B1)
  13 - filter(("REFDOSS"=:B1 AND "CREATEUR"='cfc_migration' AND TO_NUMBER(NVL(TO_CHAR(INTERNAL_FUNCTION("DTRECEPTION_DT"),'j'),'0'))
              >:B8))
  14 - access("REFENCAISS"=:B1)
  15 - filter((:B4='ALL' OR ("DF_REFINIT"=:B3 AND (:B4='CURRENT' OR :B4='CURRSPLIT')) OR (:B4='OLD' AND NVL("DF_REFINIT",'x')<>:B3
              AND  IS NULL) OR (:B4='OLDWM' AND NVL("DF_REFINIT",'x')<>:B3 AND  IS NULL) OR (:B4='OLDM' AND NVL("DF_REFINIT",'x')<>:B3 AND  IS
              NOT NULL)))
  16 - filter(:B1 IS NOT NULL)
  18 - filter(("DF_DOS"=:B6 AND (:B5 IS NULL OR "PHASE_CREAT_REF"=:B5) AND INTERNAL_FUNCTION("DF_NOM") AND
              TO_NUMBER(TO_CHAR(INTERNAL_FUNCTION("DF_TAUX_DT"),'j'))<=NVL(:B2,TO_NUMBER(TO_CHAR(INTERNAL_FUNCTION("DF_TAUX_DT"),'j'))) AND
              NVL("DF_ANN",0)=0))
  19 - access("DF_NUM"<=:B1)
  20 - access("REFDOSS"=:B6 AND "REFTYPE"='BU' AND "REFINDIVIDU"="DF_CLI")
  21 - filter(("REFDOSS"=:B1 AND "CREATEUR"='cfc_migration' AND TO_NUMBER(NVL(TO_CHAR(INTERNAL_FUNCTION("DTRECEPTION_DT"),'j'),'0'))
              <=:B8))
  22 - access("REFENCAISS"=:B1)
  23 - filter("CREATEUR"='cfc_migration')
  24 - access("REFENCAISS"=:B1)
  25 - filter(("REFDOSS"=:B1 AND "CREATEUR"='cfc_migration' AND TO_NUMBER(NVL(TO_CHAR(INTERNAL_FUNCTION("DTRECEPTION_DT"),'j'),'0'))
              >:B8))
  26 - access("REFENCAISS"=:B1)
*/
/********************************OLD Metrics***************************************/

/********************************New SQL*******************************************/
SELECT DECODE(:B7,
              'I',
              NVL(SUM(NVL(DF_MONTTC_CON, 0)), 0),
              'C',
              NVL(SUM(NVL(DF_MONTTC_DOS, 0)), 0),
              'B',
              NVL(SUM(NVL(DF_MONTTC_BU, 0)), 0),
              'A',
              NVL(SUM(NVL(DF_MONTTC, 0)), 0),
              'M',
              NVL(SUM(NVL(DF_MONTTC_MVT, 0)), 0),
              0)
  FROM F_DETFAC DF
 WHERE DF_NOM IN ('SAC', 'VDIR')
   AND DF_DOS = :B6
   AND NVL(DF_ANN, 0) = 0
   AND (PHASE_CREAT_REF = :B5 OR :B5 IS NULL)
   AND (:B4 = 'ALL' OR
       (:B4 IN ('CURRENT', 'CURRSPLIT') AND DF_REFINIT = :B3) OR
       (:B4 = 'OLD' AND NVL(DF_REFINIT, 'x') <> :B3 AND NOT EXISTS
        (SELECT 1
            FROM G_ENCAISSEMENT
           WHERE REFENCAISS = DF.DF_REFINIT
             AND REFDOSS = DF.DF_DOS
             AND CREATEUR = 'cfc_migration'
             AND NVL(TO_CHAR(DTRECEPTION_DT, 'J'), 0) <= :B8)) OR
       (:B4 = 'OLDWM' AND NVL(DF_REFINIT, 'x') <> :B3 AND NOT EXISTS
        (SELECT 1
            FROM G_ENCAISSEMENT
           WHERE REFENCAISS = DF.DF_REFINIT
             AND CREATEUR = 'cfc_migration')) OR
       (:B4 = 'OLDM' AND NVL(DF_REFINIT, 'x') <> :B3 AND EXISTS
        (SELECT 1
            FROM G_ENCAISSEMENT
           WHERE REFENCAISS = DF.DF_REFINIT
             AND REFDOSS = DF.DF_DOS
             AND CREATEUR = 'cfc_migration'
             AND NVL(TO_CHAR(DTRECEPTION_DT, 'J'), 0) > :B8)))
   AND NOT EXISTS
 (SELECT 1
          FROM T_INTERVENANTS
         WHERE REFDOSS = DF_DOS
           AND REFTYPE = 'BU'
           AND REFINDIVIDU = DF_CLI)
   AND TO_CHAR(DF_TAUX_DT, 'j') <= NVL(:B2, TO_CHAR(DF_TAUX_DT, 'j'))
   AND DF_NUM || '' <= NVL(:B1, DF_NUM);
/********************************New SQL*******************************************/
/********************************New Metrics***************************************/
/*
Plan hash value: 600067818
---------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                              | Name            | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers |
---------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                       |                 |      1 |        |     2 (100)|      1 |00:00:00.01 |     146 |
|   1 |  SORT AGGREGATE                        |                 |      1 |      1 |            |      1 |00:00:00.01 |     146 |
|*  2 |   FILTER                               |                 |      1 |        |            |     23 |00:00:00.01 |     146 |
|   3 |    NESTED LOOPS ANTI                   |                 |      1 |      1 |     2   (0)|     30 |00:00:00.01 |      37 |
|*  4 |     TABLE ACCESS BY INDEX ROWID BATCHED| F_DETFAC        |      1 |      1 |     1   (0)|     30 |00:00:00.01 |      34 |
|*  5 |      INDEX RANGE SCAN                  | IDX_DETFAC_DCPT |      1 |      5 |     1   (0)|     41 |00:00:00.01 |       3 |
|*  6 |     INDEX RANGE SCAN                   | INT_REFDOSS     |      1 |      1 |     1   (0)|      0 |00:00:00.01 |       3 |
|*  7 |    TABLE ACCESS BY INDEX ROWID         | G_ENCAISSEMENT  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|*  8 |     INDEX UNIQUE SCAN                  | REFENCAISS      |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|*  9 |    TABLE ACCESS BY INDEX ROWID         | G_ENCAISSEMENT  |     30 |      1 |     1   (0)|      7 |00:00:00.01 |     109 |
|* 10 |     INDEX UNIQUE SCAN                  | REFENCAISS      |     30 |      1 |     1   (0)|     30 |00:00:00.01 |      76 |
|* 11 |    TABLE ACCESS BY INDEX ROWID         | G_ENCAISSEMENT  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
|* 12 |     INDEX UNIQUE SCAN                  | REFENCAISS      |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |
---------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   2 - filter((:B4='ALL' OR ("DF_REFINIT"=:B3 AND (:B4='CURRENT' OR :B4='CURRSPLIT')) OR (:B4='OLD' AND
              NVL("DF_REFINIT",'x')<>:B3 AND  IS NULL) OR (:B4='OLDWM' AND NVL("DF_REFINIT",'x')<>:B3 AND  IS NULL) OR (:B4='OLDM' AND
              NVL("DF_REFINIT",'x')<>:B3 AND  IS NOT NULL)))
   4 - filter(((:B5 IS NULL OR "PHASE_CREAT_REF"=:B5) AND INTERNAL_FUNCTION("DF_NOM") AND
              "DF_NUM"||''<=NVL(:B1,"DF_NUM") AND TO_NUMBER(TO_CHAR(INTERNAL_FUNCTION("DF_TAUX_DT"),'j'))<=NVL(:B2,TO_NUMBER(TO_CHAR(IN
              TERNAL_FUNCTION("DF_TAUX_DT"),'j'))) AND NVL("DF_ANN",0)=0))
   5 - access("DF_DOS"=:B6)
   6 - access("REFDOSS"=:B6 AND "REFTYPE"='BU' AND "REFINDIVIDU"="DF_CLI")
   7 - filter(("REFDOSS"=:B1 AND "CREATEUR"='cfc_migration' AND
              TO_NUMBER(NVL(TO_CHAR(INTERNAL_FUNCTION("DTRECEPTION_DT"),'j'),'0'))<=:B8))
   8 - access("REFENCAISS"=:B1)
   9 - filter("CREATEUR"='cfc_migration')
  10 - access("REFENCAISS"=:B1)
  11 - filter(("REFDOSS"=:B1 AND "CREATEUR"='cfc_migration' AND
              TO_NUMBER(NVL(TO_CHAR(INTERNAL_FUNCTION("DTRECEPTION_DT"),'j'),'0'))>:B8))
  12 - access("REFENCAISS"=:B1)
*/
/********************************New Metrics***************************************/

/********************************Index statistics**********************************/

/********************************Other SQLs****************************************/          
/*

*/ 
/********************************Other SQLs****************************************/              
