/********************************************************************************
*********       E-mail subject: ACSTDWEB-1914
*********             Instance: SCOR-G
*********          Description: 
Problem:
The std_dc_migr_exp_case.export_ISSNV took over 13 hour on Atradius SCOR-G.

Analysis:
After the analyze, we found that the TOP SQL in std_dc_migr_exp_case.export_ISSNV module , which was responsible for 100% of the time was 5dkyjt53310uu.
The main problem in this query is that there is not joined table ( MIGR_DC_ISSNV MIGR ), which leads to MERGE JOIN CARTESIAN. Could you please remove the
not joined table and add hint to force Oracle to make full scan of table G_TEXTE G. By this way, it will join it with HASH JOIN.

Suggestion:
Please change the query as it is shown in the New SQL section below.

*********               SQL_ID: 5dkyjt53310uu
*********      Program/Package: 
*********              Request: Iva Zareva
*********               Author: Dimitar Dimitrov
********* Received e-mail date: 01/10/2024
*********      Resolution date: 01/10/2024
*********  Trace old file here: \\epox\specifs\performance\tmp\
*********  Trace new file here:
***********************************************************************************/

/********************************OLD SQL*******************************************/
VAR B1 NUMBER;
EXEC :B1 := 0;
VAR B2 NUMBER;
EXEC :B2 := 0;

INSERT INTO MIGR_DC_ISSNV ( REFTEXTE,
                            DTCREAT,
                            DTCREAT_DT,
                            MANAGER,
                            TITLE,
                            REF_IND,
                            DTEDIT,
                            TYPE_PAPER,
                            TYPENVOI,
                            NB_COPIES,
                            ON_PRINTER,
                            ETAT,
                            PAGE_NB,
                            REFDOSS,
                            LANGUAGE,
                            CP,
                            DTEDIT_DT,
                            PARAGRAPHE,
                            COMMENTAIRE,
                            DTMODIFY,
                            REFMASTER,
                            EXPORT_FILENAME,
                            BARCODE,
                            BARCODE2,
                            CODE_ENVOI,
                            DTSTATUS_VAL,
                            FLAGS,
                            EXPORT_DIR )
  SELECT G.REFTEXTE,
         G.DTCREAT,
         G.DTCREAT_DT,
         G.ECRAN,
         G.TITRE,
         G.REFDESTIN,
         G.DTEDIT,
         G.PAPIER,
         G.TYPENVOI,
         G.NBCOPIES,
         G.IMPRIMANTE,
         G.ETAT,
         G.NUMPAGE,
         G.REFDS,
         G.LANGUE,
         G.CP,
         G.DTEDIT_DT,
         G.PARAGRAPHE,
         G.COMMENTAIRE,
         G.DTMODIFY,
         G.REFMASTER,
         G.EXPORT_FILENAME,
         G.BARCODE,
         G.BARCODE2,
         G.CODE_ENVOI,
         G.DTSTATUS_VAL,
         G.FLAGS,
         G.EXPORT_DIR
    FROM G_TEXTE G,
         ( SELECT REFDOSS
             FROM MIGR_DC_DBCC
           UNION
           SELECT REFDOSS
             FROM MIGR_DC_CA ) MIGR_CASE,
         MIGR_DC_ISSNV MIGR
   WHERE EXISTS ( SELECT 1 
                    FROM MIGR_DC_ISSNV MIGR 
                   WHERE MIGR.REFMASTER = G.REFTEXTE )
     AND NOT EXISTS ( SELECT 1 
                        FROM MIGR_DC_ISSNV MIGR 
                       WHERE MIGR.REFTEXTE = G.REFTEXTE )
     AND G.REFDS = MIGR_CASE.REFDOSS
     AND G.DTCREAT IS NOT NULL
     AND G.DTCREAT_DT IS NOT NULL
     AND G.REFDESTIN IS NOT NULL
     AND G.DTEDIT IS NOT NULL
     AND ORA_HASH(G.REFTEXTE, :B2 - 1) = :B1;
/********************************OLD SQL*******************************************/
/********************************OLD Metrics***************************************/
/*
MODULE                           PROGRAM                                            CLIENT_ID       SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- -------------------------------------------------- --------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
std_dc_migr_exp_case.export_ISSN std_migration_robot                                                5dkyjt53310uu 2990108019       1831      26278 ON CPU               2024/09/30 18:00:00  2024/10/01 07:25:28       48293                    1 +000000000 13:25:27.971 77%
V

inv_dc_batch                     inv_dc_batch                                                                                                      ON CPU               2024/09/30 19:01:28  2024/10/01 01:05:21        2412              6008910 +000000000 06:03:53.101 4%
oracle                           oracle                                                                                                            ON CPU               2024/09/30 18:00:12  2024/10/01 07:17:01        1871                49765 +000000000 13:16:49.627 3%
inv_dc_batch                     inv_dc_batch                                                                                                      db file sequential r 2024/09/30 19:01:27  2024/10/01 01:05:23        1050               283076 +000000000 06:03:56.111 2%


MODULE                           PROGRAM                                            CLIENT_ID       SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- -------------------------------------------------- --------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
std_dc_migr_exp_case.export_ISSN std_migration_robot                                                                               1831      26278                      2024/09/30 17:12:25  2024/10/01 07:25:28       51164                    1 +000000000 14:13:03.007 100%
V


MODULE                           PROGRAM                                            CLIENT_ID       SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- -------------------------------------------------- --------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
std_dc_migr_exp_case.export_ISSN std_migration_robot                                                                               1831      26278 ON CPU               2024/09/30 17:12:25  2024/10/01 07:25:28       51115                    1 +000000000 14:13:03.007 100%
V

std_dc_migr_exp_case.export_ISSN std_migration_robot                                                                               1831      26278 db file sequential r 2024/09/30 17:12:27  2024/10/01 07:14:44          49                    1 +000000000 14:02:17.557 0%
V


MODULE                           PROGRAM                                            CLIENT_ID       SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- -------------------------------------------------- --------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
std_dc_migr_exp_case.export_ISSN std_migration_robot                                                5dkyjt53310uu 2990108019       1831      26278                      2024/09/30 17:12:57  2024/10/01 07:25:28       51132                    1 +000000000 14:12:31.010 100%
V

std_dc_migr_exp_case.export_ISSN std_migration_robot                                                1u9yz5w31yngh  391261811       1831      26278                      2024/09/30 17:12:25  2024/09/30 17:12:56          32                    1 +000000000 00:00:30.998 0%
V


SQL_ID        SQL_PLAN_HASH_VALUE SQL_PLAN_LINE_ID SQL_PLAN_OPERATION             SQL_PLAN_OPTIONS                   ACTIVE
------------- ------------------- ---------------- ------------------------------ ------------------------------ ----------
5dkyjt53310uu          2990108019               18 TABLE ACCESS                   BY INDEX ROWID                       2898
5dkyjt53310uu          2990108019               17 INDEX                          UNIQUE SCAN                          1701
5dkyjt53310uu          2990108019               11 BUFFER                         SORT                                  430
5dkyjt53310uu          2990108019                4 NESTED LOOPS                                                          51
5dkyjt53310uu          2990108019                5 MERGE JOIN                     CARTESIAN                              45
5dkyjt53310uu          2990108019                3 NESTED LOOPS                                                          16


INSTANCE_NUMBER SQL_ID            ELAPSED MAX_WAIT_ON     PC_OF  WAIT_TIME            GETS      READS       ROWS  ELAP/EXEC       GETS/EXEC READS/EXEC  ROWS/EXEC       EXEC PLAN_HASH_VALUE
--------------- ------------- ----------- --------------- ----- ---------- --------------- ---------- ---------- ---------- --------------- ---------- ---------- ---------- ---------------
              1 5dkyjt53310uu       49644 CPU             100%  21061.2312     11353580101      19350          0   49643.63     11353580101      19350          0          0      2990108019
              
    SID SERIAL# PID         SPID       MODULE               EVENT                                    STATUS            SQL_ID        PLAN_HASH_VALUE CLIENT_ID    CLIENT_INFO      LOGON_TIME MACHINE    ACTION
------- ------- ----------- ---------- -------------------- ---------------------------------------- ----------------- ------------- --------------- ------------ ---------------- ---------- ---------- -------------------------
   1831   26278 31195904    41354152   std_dc_migr_exp_case on cpu                                   ACTIVE-69561 sec. 5dkyjt53310uu      2990108019              31195904@std_mig 30/09/24
 

Plan hash value: 2990108019
-------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                     | Name          | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  |
-------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT              |               |      1 |        |    11 (100)|      0 |00:00:00.58 |   62175 |   2206 |
|*  1 |  HASH JOIN ANTI               |               |      1 |      1 |    11   (0)|      0 |00:00:00.58 |   62175 |   2206 |
|   2 |   NESTED LOOPS                |               |      1 |      1 |     9   (0)|      0 |00:00:00.58 |   62175 |   2206 |
|   3 |    NESTED LOOPS               |               |      1 |      1 |     9   (0)|      0 |00:00:00.58 |   62175 |   2206 |
|   4 |     MERGE JOIN CARTESIAN      |               |      1 |      1 |     8   (0)|      0 |00:00:00.58 |   62175 |   2206 |
|   5 |      MERGE JOIN CARTESIAN     |               |      1 |      1 |     4   (0)|      0 |00:00:00.58 |   62175 |   2206 |
|   6 |       TABLE ACCESS FULL       | MIGR_DC_ISSNV |      1 |      1 |     2   (0)|      0 |00:00:00.58 |   62175 |   2206 |
|   7 |       BUFFER SORT             |               |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|   8 |        SORT UNIQUE            |               |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|   9 |         TABLE ACCESS FULL     | MIGR_DC_ISSNV |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|  10 |      BUFFER SORT              |               |      0 |      2 |     6   (0)|      0 |00:00:00.01 |       0 |      0 |
|  11 |       VIEW                    |               |      0 |      2 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|  12 |        SORT UNIQUE            |               |      0 |      2 |     4   (0)|      0 |00:00:00.01 |       0 |      0 |
|  13 |         UNION-ALL             |               |      0 |        |            |      0 |00:00:00.01 |       0 |      0 |
|  14 |          TABLE ACCESS FULL    | MIGR_DC_DBCC  |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|  15 |          TABLE ACCESS FULL    | MIGR_DC_CA    |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 16 |     INDEX UNIQUE SCAN         | TXT_REFTEXTE  |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 17 |    TABLE ACCESS BY INDEX ROWID| G_TEXTE       |      0 |      1 |     1   (0)|      0 |00:00:00.01 |       0 |      0 |
|  18 |   TABLE ACCESS FULL           | MIGR_DC_ISSNV |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |      0 |
-------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   1 - access("MIGR"."REFTEXTE"="G"."REFTEXTE")
  16 - access("MIGR"."REFMASTER"="G"."REFTEXTE")
       filter(ORA_HASH("G"."REFTEXTE",:B2-1)=:B1)
  17 - filter(("G"."REFDS"="MIGR_CASE"."REFDOSS" AND "G"."REFDESTIN" IS NOT NULL AND "G"."DTCREAT" IS NOT NULL AND
              "G"."DTCREAT_DT" IS NOT NULL AND "G"."DTEDIT" IS NOT NULL))


*/
/********************************OLD Metrics***************************************/

/********************************New SQL*******************************************/

INSERT INTO MIGR_DC_ISSNV ( REFTEXTE,
                            DTCREAT,
                            DTCREAT_DT,
                            MANAGER,
                            TITLE,
                            REF_IND,
                            DTEDIT,
                            TYPE_PAPER,
                            TYPENVOI,
                            NB_COPIES,
                            ON_PRINTER,
                            ETAT,
                            PAGE_NB,
                            REFDOSS,
                            LANGUAGE,
                            CP,
                            DTEDIT_DT,
                            PARAGRAPHE,
                            COMMENTAIRE,
                            DTMODIFY,
                            REFMASTER,
                            EXPORT_FILENAME,
                            BARCODE,
                            BARCODE2,
                            CODE_ENVOI,
                            DTSTATUS_VAL,
                            FLAGS,
                            EXPORT_DIR )
  SELECT /*+ FULL(G) */
         G.REFTEXTE,
         G.DTCREAT,
         G.DTCREAT_DT,
         G.ECRAN,
         G.TITRE,
         G.REFDESTIN,
         G.DTEDIT,
         G.PAPIER,
         G.TYPENVOI,
         G.NBCOPIES,
         G.IMPRIMANTE,
         G.ETAT,
         G.NUMPAGE,
         G.REFDS,
         G.LANGUE,
         G.CP,
         G.DTEDIT_DT,
         G.PARAGRAPHE,
         G.COMMENTAIRE,
         G.DTMODIFY,
         G.REFMASTER,
         G.EXPORT_FILENAME,
         G.BARCODE,
         G.BARCODE2,
         G.CODE_ENVOI,
         G.DTSTATUS_VAL,
         G.FLAGS,
         G.EXPORT_DIR
    FROM G_TEXTE G,
         ( SELECT REFDOSS
             FROM MIGR_DC_DBCC
           UNION
           SELECT REFDOSS
             FROM MIGR_DC_CA ) MIGR_CASE
   WHERE EXISTS ( SELECT 1 
                    FROM MIGR_DC_ISSNV MIGR 
                   WHERE MIGR.REFMASTER = G.REFTEXTE )
     AND NOT EXISTS ( SELECT 1 
                        FROM MIGR_DC_ISSNV MIGR 
                       WHERE MIGR.REFTEXTE = G.REFTEXTE )
     AND G.REFDS = MIGR_CASE.REFDOSS
     AND G.DTCREAT IS NOT NULL
     AND G.DTCREAT_DT IS NOT NULL
     AND G.REFDESTIN IS NOT NULL
     AND G.DTEDIT IS NOT NULL
     AND ORA_HASH(G.REFTEXTE, :B2 - 1) = :B1;
/********************************New SQL*******************************************/
/********************************New Metrics***************************************/
/*
Plan hash value: 961660360
-----------------------------------------------------------------------------------------------------------------
| Id  | Operation                | Name          | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers |
-----------------------------------------------------------------------------------------------------------------
|   0 | INSERT STATEMENT         |               |      1 |        |   261K(100)|      0 |00:00:00.21 |   62175 |
|   1 |  LOAD TABLE CONVENTIONAL | MIGR_DC_ISSNV |      1 |        |            |      0 |00:00:00.21 |   62175 |
|*  2 |   HASH JOIN ANTI         |               |      1 |      1 |   261K  (1)|      0 |00:00:00.21 |   62175 |
|*  3 |    HASH JOIN             |               |      1 |      1 |   261K  (1)|      0 |00:00:00.21 |   62175 |
|*  4 |     HASH JOIN RIGHT SEMI |               |      1 |      1 |   261K  (1)|      0 |00:00:00.21 |   62175 |
|   5 |      TABLE ACCESS FULL   | MIGR_DC_ISSNV |      1 |      1 |     2   (0)|      0 |00:00:00.21 |   62175 |
|*  6 |      TABLE ACCESS FULL   | G_TEXTE       |      0 |    166K|   261K  (1)|      0 |00:00:00.01 |       0 |
|   7 |     VIEW                 |               |      0 |      2 |     4   (0)|      0 |00:00:00.01 |       0 |
|   8 |      SORT UNIQUE         |               |      0 |      2 |     4   (0)|      0 |00:00:00.01 |       0 |
|   9 |       UNION-ALL          |               |      0 |        |            |      0 |00:00:00.01 |       0 |
|  10 |        TABLE ACCESS FULL | MIGR_DC_DBCC  |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |
|  11 |        TABLE ACCESS FULL | MIGR_DC_CA    |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |
|  12 |    TABLE ACCESS FULL     | MIGR_DC_ISSNV |      0 |      1 |     2   (0)|      0 |00:00:00.01 |       0 |
-----------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   2 - access("MIGR"."REFTEXTE"="G"."REFTEXTE")
   3 - access("G"."REFDS"="MIGR_CASE"."REFDOSS")
   4 - access("MIGR"."REFMASTER"="G"."REFTEXTE")
   6 - filter(("G"."REFDESTIN" IS NOT NULL AND ORA_HASH("G"."REFTEXTE",:B2-1)=:B1 AND "G"."DTCREAT" IS
              NOT NULL AND "G"."DTCREAT_DT" IS NOT NULL AND "G"."DTEDIT" IS NOT NULL))
*/
/********************************New Metrics***************************************/

/********************************Index statistics**********************************/

/********************************Other SQLs****************************************/          
/*

*/ 
/********************************Other SQLs****************************************/              
