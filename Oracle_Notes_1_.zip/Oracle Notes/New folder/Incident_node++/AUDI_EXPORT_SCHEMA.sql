#################################################
###################################################
###  EXPORT NA SCHEMA 

Export of a schema and hash value is required from us for the Live DB.



####Example for EXPDP ########


1.Винаги първо проверявам пата на директорията!!!!!!
#####
col current_scn  format 99999999999999999999;
col DIRECTORY_PATH for a65;
col DIRECTORY_NAME for a40;
col OWNER for a40;
set lines 300;
select current_scn from v$database;
select * from dba_directories; 


#####
2. Проверявам дали има място за в директорията където правим дъмпа(целия път)
SQL> !df -h /u01/dbteam/dump/E60012


#####
3. проверявам сайза на схемата задълже:
### SCHEMA SIZE ###
set numformat 9999999999999999999.9999999999
SELECT SUM(BYTES)/1024/1024/1024 "GB" FROM DBA_SEGMENTS WHERE OWNER like '&SCHEMA';
 
==================================================
!!!! Това е в случай,че няма такава директория и искам да я създам
CREATE OR REPLACE DIRECTORY DATA_PUMP_DIR AS '/datadomain/ryelxwebeqdb1/gmcgeuc';
=====================================================
geta -n 143_PROTEX

--> directory - показва къде да запази дъмп файла (DATA_PUMP_DIR): 
select * from dba_directories;

--> DUMPFILE - наименуванието на дъмп файла (143_PROTEX_A4PROTEX_0508Liveexp.dmp) - първо се пише името на апликейшъна(всеки апликейшън си има номер) след това името на схемата и после датата!!

--> А4 са основните схеми ,където се съдържа информацията

--> U4 юзъра съдържа синоними към обектите на А4
(когато иска да се дъмпи нещо винаги е А4,освен ,ако не е споменат и U4!!!!)
апликейшъна е конфигуриран да се свързва към базата с U4



#######
expdp directory=DATA_PUMP_DIR DUMPFILE=195_EFKO_P_EFKO_1223_A4EFKO_1009LIVEexp.dmp LOGFILE=195_EFKO_P_EFKO_1223_A4EFKO_1009LIVEexp.log FLASHBACK_SCN=10425549655265 SCHEMAS=A4EFKO  



####### Start  expdp with parallel #######
expdp directory=DATA_PUMP_DIR DUMPFILE=141_MBVSRV_A4MBVSRV_2111Liveexp_%U.dmp LOGFILE=141_MBVSRV_A4MBVSRV_2111Liveexp.log FLASHBACK_SCN=************ SCHEMAS=A4MBVSRV parallel=4

When prompted type “/ as sysdba”


#############
#####
expdp userid=\"/ as sysdba\" SCHEMAS=TXSADMIN DIRECTORY=DUMP_DIR_EXPORT DUMPFILE=11032020_6098_TXS_UAT_pre_keymigration.dmp ESTIMATE_ONLY=Y LOGFILE=A4GWB_package_20161017.log  




=============================================

##################
### Show SCN ####

select current_scn from v$database;

          CURRENT_SCN
---------------------
       10409054972156 
	   
	   
####################
## Courrent SCN

col current_scn  format 99999999999999999999;
set lines 300;
select current_scn from v$database;	   



#########################
### SCN to DATE TIMESTAMP and DATE TIMESTAMP to SCN
	   
set num 30
  

SQL> select scn_to_timestamp(10409457246294) as timestamp from dual;
SQL> select timestamp_to_scn(to_timestamp('31/07/2019 22:00:00','DD/MM/YYYY HH24:MI:SS')) as scn from dual;
 
======================================================

##### свързвам се със сървър,база и сървиз:
con -c


===================================

################
### USER 
set lines 512
set pages 1000
col USERNAME format A20
col ACCOUNT_STATUS format A17
col PASSWORD format A30
col PROFILE for a30
select USERNAME,ACCOUNT_STATUS,LOCK_DATE,CREATED, PASSWORD, PROFILE,default_tablespace from dba_users 
where username like '%MAGO%'
--where account_status='OPEN'
--and USERNAME not like 'HP%'
order by USERNAME,ACCOUNT_STATUS;


==================================================

##### LONG OPS of expdp Schema #####

set linesize 400 pages 30 
col TARGET for a21 
col USERNAME for a10 
col TARGET_DESC for a15 
col "rem mins" for 9999.9 a8 
col UNITS for a10 
col TIME_REMAINING for a20 
col START__TIME for a20 
col LAST__UPDATE_TIME for a20 
SELECT SID, SERIAL#,USERNAME, to_char(START_TIME, 'YYYY/MM/DD HH24:MI:SS') START__TIME,to_char(LAST_UPDATE_TIME, 
'YYYY/MM/DD HH24:MI:SS') LAST__UPDATE_TIME,TIME_REMAINING/60 as "rem mins", TARGET, TARGET_DESC,SOFAR, 
TOTALWORK, UNITS, ROUND(SOFAR/TOTALWORK*100,2) "%_COMPLETE" FROM GV$SESSION_LONGOPS WHERE TOTALWORK != 0 AND SOFAR <> TOTALWORK 
--and sid='234' 
order by START_TIME; 



############################################
###############################################
######  HASH VALUE

## connect to ivmg863

as root:

--> cd /var/apphome/087_cip
--> ./cip_encrypt_db_passwords_v4.sh

[r2cip@ivmg863(Production) ~]$ exit         <=== You have to exit or ctrl+D from r2cip user in order to start the script

[setup] Enter (Sub-)AppId (3 or 5 digit number): === this prompt is for the application ID. In our case is 143. 
143		

[setup] Enter Stage (lowercase): ==== this prompt is for the stage of the environment. In our case pro(Live). 
pro

[setup] Enter the current state of operation: ==== this prompt is always operations. 
operations

fNDIENq0Kb25KlIFh_0eGH_cTwHKhu
[populate_properties] Please enter the password(s) for stage pro:
[populate_properties] #db_a4user= A4PROTEX
[populate_properties] Enter value for 'db_a4password': LyImBQ_78g7ppL6fEa8ZEVW_GhJy0m
 [populate_properties] ... all properties entered.


--> You can check application users passwords by:

Login to ivmg700, switch to oracle and use geta:

Geta –h : will show you the available options. 

Example for password check:

geta -p -n 143_PROTEX


######################################
######################################

