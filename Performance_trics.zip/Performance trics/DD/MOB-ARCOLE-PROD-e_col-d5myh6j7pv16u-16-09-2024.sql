/********************************************************************************
*********       E-mail subject: MOBARCWEB-769
*********             Instance: PROD
*********          Description: 
Problem:
The manual matching of the payments in e_col / IMX. It takes 50 seconds for each payment to match it on the correct customer code.

Analysis:
Based on the information in the HAR file, we found in the BE logs that the query, responsible for the slowness is d5myh6j7pv16u.
This query was executed with bad execution plan, because Oracle expects that from the UNIONs, where it is seraching for the REFODSS for table T_INTERVENANTS will return near 400k rows, but in reality, it returns 
only 2 rows. Because of that expectations, it makes HASH JOIN for table T_INTERVENANTS and the inline view DB. We added hints to help the CBO to understand how many rows are expected.

Suggestion:
Please add hints as it is shown in the New SQL section below.

*********               SQL_ID: d5myh6j7pv16u
*********      Program/Package: 
*********              Request: Ravi Mahant
*********               Author: Dimitar Dimitrov
********* Received e-mail date: 16/09/2024
*********      Resolution date: 16/09/2024
*********  Trace old file here: \\epox\specifs\performance\tmp\
*********  Trace new file here:
***********************************************************************************/

/********************************OLD SQL*******************************************/

var B1 VARCHAR2(32);
exec :B1 := 'A60EX5Y5';
var B2 VARCHAR2(128);
exec :B2 := '2308010734';
var B3 VARCHAR2(128);
exec :B3 := '2308010734';
var B4 VARCHAR2(32);
exec :B4 := 'INT00000';
var B5 NUMBER;
exec :B5 := 2001;
var B6 NUMBER;
exec :B6 := 1;

SELECT *
  FROM ( SELECT /*+ first_rows(2001)*/
                foo.*, ROWNUM rnum
           FROM ( SELECT amtLastPmt  amtLastPmt,
                         extCaseRef  extCaseRef,
                         custName    custName,
                         amtCaseCurr amtCaseCurr,
                         intCaseRef  intCaseRef,
                         debBalance  debBalance,
                         caseCurr    caseCurr
                    FROM ( SELECT d.refdoss intCaseRef,
                                  d.ancrefdoss extCaseRef,
                                  db.name custName,
                                  tcm_dossier.debitbalance(d.refdoss) debBalance,
                                  ( SELECT montant_dos
                                      FROM t_elements
                                     WHERE typeelem = 'en'
                                       AND d.refdoss = refdoss
                                       AND refelem = ( SELECT MAX(refelem)
                                                         FROM t_elements
                                                        WHERE refdoss = d.refdoss
                                                          AND typeelem = 'en' ) ) amtCaseCurr,
                                  d.devise caseCurr,
                                  ( SELECT montant
                                      FROM t_elements
                                     WHERE typeelem = 'en'
                                       AND d.refdoss = refdoss
                                       AND refelem = ( SELECT MAX(refelem)
                                                         FROM t_elements
                                                        WHERE refdoss = d.refdoss
                                                          AND typeelem = 'en' ) ) amtLastPmt
                             FROM g_dossier d,
                                  t_intervenants ti,
                                  ( SELECT RTRIM(gi.nom || ' ' || gi.prenom) name,
                                           refdoss
                                      FROM t_intervenants ti,
                                           g_individu gi
                                     WHERE ti.reftype = 'DB'
                                       AND ti.refindividu = gi.refindividu ) db
                            WHERE d.refdoss = db.refdoss(+)
                              AND ti.refdoss IN ( SELECT TI.refdoss
                                                    FROM t_intervenants TI
                                                   WHERE TI.reftype = 'DB'
                                                     AND TI.refindividu = :B1
                                                   UNION ALL
                                                  SELECT TI_DB.refdoss
                                                    FROM t_intervenants TI_ORIG,
                                                         v_domaine      VD,
                                                         t_intervenants TI_DB
                                                   WHERE TI_ORIG.reftype = VD.abrev
                                                     AND TI_DB.reftype = 'DB'
                                                     AND TI_DB.refindividu = TI_ORIG.refindividu
                                                     AND VD.type = 'intervenant'
                                                     and VD.ecran = 'traitdebiteur'
                                                     AND TI_ORIG.refdoss = :B2
                                                   UNION ALL
                                                  SELECT TI_TPB.refdoss
                                                    FROM t_intervenants TI_TPB,
                                                         t_intervenants TI_ORIG
                                                   WHERE TI_TPB.reftype = 'TPB'
                                                     AND TI_TPB.refindividu = TI_ORIG.refindividu
                                                     AND TI_ORIG.refdoss = :B3
                                                     AND TI_ORIG.reftype = 'DB' )
                              AND ti.refindividu || '' = :B4
                              AND ti.reftype = 'CL'
                              AND ti.refdoss = d.refdoss ) pay
                   WHERE 1 = 1
                   ORDER BY extCaseRef,
                            custName,
                            debBalance,
                            amtCaseCurr,
                            caseCurr,
                            amtLastPmt,
                            intCaseRef ) foo
          WHERE ROWNUM <= :B5 )
 WHERE 1 = 1
   AND rnum >= :B6;
/********************************OLD SQL*******************************************/
/********************************OLD Metrics***************************************/
/*
MODULE                           CLIENT_ID       SQL_ID         PLAN_HASH        SID    SERIAL# EVENT                FROM                 TO                       ACTIVE NUMBER_OF_EXECUTIONS INTERVAL                PERC
-------------------------------- --------------- ------------- ---------- ---------- ---------- -------------------- -------------------- -------------------- ---------- -------------------- ----------------------- ------
0E6C7FE81CF73C542F56EC48AC23A346 etemmerm        d5myh6j7pv16u  245614488                                            2024/09/16 11:20:14  2024/09/16 11:36:46         339                   12 +000000000 00:16:31.688 5%



Plan hash value: 245614488
--------------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                         | Name         | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  |
--------------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                                  |              |      1 |        |   866K(100)|      1 |00:01:22.07 |    9201K|  77042 |
|*  1 |  TABLE ACCESS BY INDEX ROWID BATCHED              | T_ELEMENTS   |      1 |      1 |     1   (0)|      1 |00:00:00.01 |      22 |      0 |
|*  2 |   INDEX RANGE SCAN                                | ELE_ELEMTYPE |      1 |      1 |     1   (0)|      1 |00:00:00.01 |      21 |      0 |
|   3 |    SORT AGGREGATE                                 |              |      1 |      1 |            |      1 |00:00:00.01 |      17 |      0 |
|   4 |     TABLE ACCESS BY INDEX ROWID BATCHED           | T_ELEMENTS   |      1 |      5 |     1   (0)|     13 |00:00:00.01 |      17 |      0 |
|*  5 |      INDEX RANGE SCAN                             | ELE_ELEMDOSS |      1 |     19 |     1   (0)|     13 |00:00:00.01 |       4 |      0 |
|*  6 |  TABLE ACCESS BY INDEX ROWID BATCHED              | T_ELEMENTS   |      1 |      1 |     1   (0)|      1 |00:00:00.01 |      22 |      9 |
|*  7 |   INDEX RANGE SCAN                                | ELE_ELEMTYPE |      1 |      1 |     1   (0)|      1 |00:00:00.01 |      21 |      9 |
|   8 |    SORT AGGREGATE                                 |              |      1 |      1 |            |      1 |00:00:00.01 |      17 |      9 |
|   9 |     TABLE ACCESS BY INDEX ROWID BATCHED           | T_ELEMENTS   |      1 |      5 |     1   (0)|     13 |00:00:00.01 |      17 |      9 |
|* 10 |      INDEX RANGE SCAN                             | ELE_ELEMDOSS |      1 |     19 |     1   (0)|     13 |00:00:00.01 |       4 |      0 |
|* 11 |  VIEW                                             |              |      1 |   2001 |   866K  (1)|      1 |00:01:22.07 |    9201K|  77042 |
|* 12 |   COUNT STOPKEY                                   |              |      1 |        |            |      1 |00:01:22.07 |    9201K|  77042 |
|  13 |    VIEW                                           |              |      1 |    379K|   866K  (1)|      1 |00:01:22.07 |    9201K|  77042 |
|* 14 |     SORT ORDER BY STOPKEY                         |              |      1 |    379K|   866K  (1)|      1 |00:01:22.07 |    9201K|  77042 |
|* 15 |      HASH JOIN OUTER                              |              |      1 |    379K| 82219   (1)|      1 |00:01:22.06 |    9201K|  77033 |
|  16 |       NESTED LOOPS                                |              |      1 |    379K| 10290   (1)|      1 |00:00:17.04 |   95982 |      0 |
|  17 |        NESTED LOOPS                               |              |      1 |    379K| 10290   (1)|      1 |00:00:17.04 |   95981 |      0 |
|  18 |         MERGE JOIN                                |              |      1 |    379K|  2704   (1)|      1 |00:00:17.04 |   95978 |      0 |
|* 19 |          INDEX SKIP SCAN                          | INT_REFDOSS  |      1 |    847K|  1063   (0)|   8844K|00:00:09.15 |   95954 |      0 |
|* 20 |          SORT JOIN                                |              |   8844K|    369K|  1640   (2)|      1 |00:00:03.22 |      24 |      0 |
|  21 |           VIEW                                    | VW_NSO_1     |      1 |    369K|     6   (0)|      1 |00:00:00.02 |      24 |      0 |
|  22 |            HASH UNIQUE                            |              |      1 |    369K|     6   (0)|      1 |00:00:00.02 |      24 |      0 |
|  23 |             UNION-ALL                             |              |      1 |        |            |      2 |00:00:00.01 |      24 |      0 |
|* 24 |              INDEX RANGE SCAN                     | INT_INDIV    |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       4 |      0 |
|  25 |              NESTED LOOPS                         |              |      1 |      3 |     3   (0)|      1 |00:00:00.01 |      13 |      0 |
|  26 |               NESTED LOOPS                        |              |      1 |      1 |     2   (0)|      1 |00:00:00.01 |       9 |      0 |
|* 27 |                INDEX RANGE SCAN                   | INT_REFDOSS  |      1 |      2 |     1   (0)|      3 |00:00:00.01 |       3 |      0 |
|* 28 |                TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE    |      3 |      1 |     1   (0)|      1 |00:00:00.01 |       6 |      0 |
|* 29 |                 INDEX RANGE SCAN                  | DOM_TYPABREV |      3 |      1 |     1   (0)|      3 |00:00:00.01 |       5 |      0 |
|* 30 |               INDEX RANGE SCAN                    | INT_INDIV    |      1 |    396K|     1   (0)|      1 |00:00:00.01 |       4 |      0 |
|  31 |              NESTED LOOPS                         |              |      1 |    369K|     2   (0)|      0 |00:00:00.01 |       7 |      0 |
|* 32 |               INDEX RANGE SCAN                    | INT_REFDOSS  |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |      0 |
|* 33 |               INDEX RANGE SCAN                    | INT_INDIV    |      1 |    396K|     1   (0)|      0 |00:00:00.01 |       4 |      0 |
|* 34 |         INDEX UNIQUE SCAN                         | DOS_REFDOSS  |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |      0 |
|  35 |        TABLE ACCESS BY INDEX ROWID                | G_DOSSIER    |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       1 |      0 |
|  36 |       VIEW                                        |              |      1 |   1814K| 37369   (1)|   9295K|00:01:00.04 |    9105K|  77033 |
|  37 |        NESTED LOOPS                               |              |      1 |   1814K| 37369   (1)|   9295K|00:00:53.44 |    9105K|  77033 |
|  38 |         NESTED LOOPS                              |              |      1 |   1814K| 37369   (1)|   9295K|00:00:27.91 |    5455K|    164 |
|* 39 |          INDEX SKIP SCAN                          | INT_REFDOSS  |      1 |   1814K|  1063   (0)|   9295K|00:00:09.29 |     101K|     13 |
|* 40 |          INDEX UNIQUE SCAN                        | IND_REFINDIV |   9295K|      1 |     1   (0)|   9295K|00:00:13.41 |    5353K|    151 |
|  41 |         TABLE ACCESS BY INDEX ROWID               | G_INDIVIDU   |   9295K|      1 |     1   (0)|   9295K|00:00:20.72 |    3650K|  76869 |
--------------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   1 - filter("REFDOSS"=:B1)
   2 - access("REFELEM"= AND "TYPEELEM"='en')
   5 - access("REFDOSS"=:B1 AND "TYPEELEM"='en')
   6 - filter("REFDOSS"=:B1)
   7 - access("REFELEM"= AND "TYPEELEM"='en')
  10 - access("REFDOSS"=:B1 AND "TYPEELEM"='en')
  11 - filter("RNUM">=:B6)
  12 - filter(ROWNUM<=:B5)
  14 - filter(ROWNUM<=:B5)
  15 - access("D"."REFDOSS"="DB"."REFDOSS")
  19 - access("TI"."REFTYPE"='CL')
       filter(("TI"."REFTYPE"='CL' AND "TI"."REFINDIVIDU"||''=:B4))
  20 - access("TI"."REFDOSS"="REFDOSS")
       filter("TI"."REFDOSS"="REFDOSS")
  24 - access("TI"."REFINDIVIDU"=:B1 AND "TI"."REFTYPE"='DB')
  27 - access("TI_ORIG"."REFDOSS"=:B2)
  28 - filter("VD"."ECRAN"='traitdebiteur')
  29 - access("VD"."TYPE"='intervenant' AND "TI_ORIG"."REFTYPE"="VD"."ABREV")
       filter("VD"."ABREV" IS NOT NULL)
  30 - access("TI_DB"."REFINDIVIDU"="TI_ORIG"."REFINDIVIDU" AND "TI_DB"."REFTYPE"='DB')
  32 - access("TI_ORIG"."REFDOSS"=:B3 AND "TI_ORIG"."REFTYPE"='DB')
  33 - access("TI_TPB"."REFINDIVIDU"="TI_ORIG"."REFINDIVIDU" AND "TI_TPB"."REFTYPE"='TPB')
  34 - access("TI"."REFDOSS"="D"."REFDOSS")
  39 - access("TI"."REFTYPE"='DB')
       filter("TI"."REFTYPE"='DB')
  40 - access("TI"."REFINDIVIDU"="GI"."REFINDIVIDU")
*/
/********************************OLD Metrics***************************************/

/********************************New SQL*******************************************/

SELECT *
  FROM ( SELECT /*+ first_rows(2001)*/
                foo.*, ROWNUM rnum
           FROM ( SELECT amtLastPmt  amtLastPmt,
                         extCaseRef  extCaseRef,
                         custName    custName,
                         amtCaseCurr amtCaseCurr,
                         intCaseRef  intCaseRef,
                         debBalance  debBalance,
                         caseCurr    caseCurr
                    FROM ( SELECT d.refdoss intCaseRef,
                                  d.ancrefdoss extCaseRef,
                                  db.name custName,
                                  tcm_dossier.debitbalance(d.refdoss) debBalance,
                                  ( SELECT montant_dos
                                      FROM t_elements
                                     WHERE typeelem = 'en'
                                       AND d.refdoss = refdoss
                                       AND refelem = ( SELECT MAX(refelem)
                                                         FROM t_elements
                                                        WHERE refdoss = d.refdoss
                                                          AND typeelem = 'en' ) ) amtCaseCurr,
                                  d.devise caseCurr,
                                  ( SELECT montant
                                      FROM t_elements
                                     WHERE typeelem = 'en'
                                       AND d.refdoss = refdoss
                                       AND refelem = ( SELECT MAX(refelem)
                                                         FROM t_elements
                                                        WHERE refdoss = d.refdoss
                                                          AND typeelem = 'en' ) ) amtLastPmt
                             FROM g_dossier d,
                                  t_intervenants ti,
                                  ( SELECT /*+ push_pred */
                                           RTRIM(gi.nom || ' ' || gi.prenom) name,
                                           refdoss
                                      FROM t_intervenants ti,
                                           g_individu gi
                                     WHERE ti.reftype = 'DB'
                                       AND ti.refindividu = gi.refindividu ) db
                            WHERE d.refdoss = db.refdoss(+)
                              AND ti.refdoss IN ( SELECT /*+ cardinality(5) */
                                                         TI.refdoss
                                                    FROM t_intervenants TI
                                                   WHERE TI.reftype = 'DB'
                                                     AND TI.refindividu = :B1
                                                   UNION ALL
                                                  SELECT /*+ cardinality(5) */
                                                         TI_DB.refdoss
                                                    FROM t_intervenants TI_ORIG,
                                                         v_domaine      VD,
                                                         t_intervenants TI_DB
                                                   WHERE TI_ORIG.reftype = VD.abrev
                                                     AND TI_DB.reftype = 'DB'
                                                     AND TI_DB.refindividu = TI_ORIG.refindividu
                                                     AND VD.type = 'intervenant'
                                                     and VD.ecran = 'traitdebiteur'
                                                     AND TI_ORIG.refdoss = :B2
                                                   UNION ALL
                                                  SELECT /*+ cardinality(5) */
                                                         TI_TPB.refdoss
                                                    FROM t_intervenants TI_TPB,
                                                         t_intervenants TI_ORIG
                                                   WHERE TI_TPB.reftype = 'TPB'
                                                     AND TI_TPB.refindividu = TI_ORIG.refindividu
                                                     AND TI_ORIG.refdoss = :B3
                                                     AND TI_ORIG.reftype = 'DB' )
                              AND ti.refindividu || '' = :B4
                              AND ti.reftype = 'CL'
                              AND ti.refdoss = d.refdoss ) pay
                   WHERE 1 = 1
                   ORDER BY extCaseRef,
                            custName,
                            debBalance,
                            amtCaseCurr,
                            caseCurr,
                            amtLastPmt,
                            intCaseRef ) foo
          WHERE ROWNUM <= :B5 )
 WHERE 1 = 1
   AND rnum >= :B6;
/********************************New SQL*******************************************/
/********************************New Metrics***************************************/
/*
Plan hash value: 2341153474
------------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                       | Name         | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  |
------------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                                |              |      1 |        |    54 (100)|      1 |00:00:00.03 |     122 |     43 |
|*  1 |  TABLE ACCESS BY INDEX ROWID BATCHED            | T_ELEMENTS   |      1 |      1 |     1   (0)|      1 |00:00:00.01 |      22 |      0 |
|*  2 |   INDEX RANGE SCAN                              | ELE_ELEMTYPE |      1 |      1 |     1   (0)|      1 |00:00:00.01 |      21 |      0 |
|   3 |    SORT AGGREGATE                               |              |      1 |      1 |            |      1 |00:00:00.01 |      17 |      0 |
|   4 |     TABLE ACCESS BY INDEX ROWID BATCHED         | T_ELEMENTS   |      1 |      5 |     1   (0)|     13 |00:00:00.01 |      17 |      0 |
|*  5 |      INDEX RANGE SCAN                           | ELE_ELEMDOSS |      1 |     19 |     1   (0)|     13 |00:00:00.01 |       4 |      0 |
|*  6 |  TABLE ACCESS BY INDEX ROWID BATCHED            | T_ELEMENTS   |      1 |      1 |     1   (0)|      1 |00:00:00.01 |      22 |     16 |
|*  7 |   INDEX RANGE SCAN                              | ELE_ELEMTYPE |      1 |      1 |     1   (0)|      1 |00:00:00.01 |      21 |     16 |
|   8 |    SORT AGGREGATE                               |              |      1 |      1 |            |      1 |00:00:00.01 |      17 |     15 |
|   9 |     TABLE ACCESS BY INDEX ROWID BATCHED         | T_ELEMENTS   |      1 |      5 |     1   (0)|     13 |00:00:00.01 |      17 |     15 |
|* 10 |      INDEX RANGE SCAN                           | ELE_ELEMDOSS |      1 |     19 |     1   (0)|     13 |00:00:00.01 |       4 |      2 |
|* 11 |  VIEW                                           |              |      1 |     15 |    54   (2)|      1 |00:00:00.03 |     122 |     43 |
|* 12 |   COUNT STOPKEY                                 |              |      1 |        |            |      1 |00:00:00.03 |     122 |     43 |
|  13 |    VIEW                                         |              |      1 |     15 |    54   (2)|      1 |00:00:00.03 |     122 |     43 |
|* 14 |     SORT ORDER BY STOPKEY                       |              |      1 |     15 |    54   (2)|      1 |00:00:00.03 |     122 |     43 |
|  15 |      NESTED LOOPS OUTER                         |              |      1 |     15 |    38   (0)|      1 |00:00:00.01 |      38 |      5 |
|  16 |       NESTED LOOPS                              |              |      1 |     15 |     8   (0)|      1 |00:00:00.01 |      31 |      3 |
|  17 |        NESTED LOOPS                             |              |      1 |     15 |     7   (0)|      1 |00:00:00.01 |      27 |      1 |
|  18 |         VIEW                                    | VW_NSO_1     |      1 |     15 |     6   (0)|      1 |00:00:00.01 |      24 |      1 |
|  19 |          HASH UNIQUE                            |              |      1 |     15 |     6   (0)|      1 |00:00:00.01 |      24 |      1 |
|  20 |           UNION-ALL                             |              |      1 |        |            |      2 |00:00:00.01 |      24 |      1 |
|* 21 |            INDEX RANGE SCAN                     | INT_INDIV    |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       4 |      0 |
|  22 |            NESTED LOOPS                         |              |      1 |      3 |     3   (0)|      1 |00:00:00.01 |      13 |      1 |
|  23 |             NESTED LOOPS                        |              |      1 |      1 |     2   (0)|      1 |00:00:00.01 |       9 |      1 |
|* 24 |              INDEX RANGE SCAN                   | INT_REFDOSS  |      1 |      2 |     1   (0)|      3 |00:00:00.01 |       3 |      1 |
|* 25 |              TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE    |      3 |      1 |     1   (0)|      1 |00:00:00.01 |       6 |      0 |
|* 26 |               INDEX RANGE SCAN                  | DOM_TYPABREV |      3 |      1 |     1   (0)|      3 |00:00:00.01 |       5 |      0 |
|* 27 |             INDEX RANGE SCAN                    | INT_INDIV    |      1 |    396K|     1   (0)|      1 |00:00:00.01 |       4 |      0 |
|  28 |            NESTED LOOPS                         |              |      1 |    369K|     2   (0)|      0 |00:00:00.01 |       7 |      0 |
|* 29 |             INDEX RANGE SCAN                    | INT_REFDOSS  |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |      0 |
|* 30 |             INDEX RANGE SCAN                    | INT_INDIV    |      1 |    396K|     1   (0)|      0 |00:00:00.01 |       4 |      0 |
|* 31 |         INDEX RANGE SCAN                        | INT_REFDOSS  |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |      0 |
|  32 |        TABLE ACCESS BY INDEX ROWID              | G_DOSSIER    |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       4 |      2 |
|* 33 |         INDEX UNIQUE SCAN                       | DOS_REFDOSS  |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |      1 |
|  34 |       VIEW PUSHED PREDICATE                     |              |      1 |      1 |     2   (0)|      1 |00:00:00.01 |       7 |      2 |
|  35 |        NESTED LOOPS                             |              |      1 |      1 |     2   (0)|      1 |00:00:00.01 |       7 |      2 |
|  36 |         NESTED LOOPS                            |              |      1 |      1 |     2   (0)|      1 |00:00:00.01 |       6 |      1 |
|* 37 |          INDEX RANGE SCAN                       | INT_REFDOSS  |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |      0 |
|* 38 |          INDEX UNIQUE SCAN                      | IND_REFINDIV |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       3 |      1 |
|  39 |         TABLE ACCESS BY INDEX ROWID             | G_INDIVIDU   |      1 |      1 |     1   (0)|      1 |00:00:00.01 |       1 |      1 |
------------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   1 - filter("REFDOSS"=:B1)
   2 - access("REFELEM"= AND "TYPEELEM"='en')
   5 - access("REFDOSS"=:B1 AND "TYPEELEM"='en')
   6 - filter("REFDOSS"=:B1)
   7 - access("REFELEM"= AND "TYPEELEM"='en')
  10 - access("REFDOSS"=:B1 AND "TYPEELEM"='en')
  11 - filter("RNUM">=:B6)
  12 - filter(ROWNUM<=:B5)
  14 - filter(ROWNUM<=:B5)
  21 - access("TI"."REFINDIVIDU"=:B1 AND "TI"."REFTYPE"='DB')
  24 - access("TI_ORIG"."REFDOSS"=:B2)
  25 - filter("VD"."ECRAN"='traitdebiteur')
  26 - access("VD"."TYPE"='intervenant' AND "TI_ORIG"."REFTYPE"="VD"."ABREV")
       filter("VD"."ABREV" IS NOT NULL)
  27 - access("TI_DB"."REFINDIVIDU"="TI_ORIG"."REFINDIVIDU" AND "TI_DB"."REFTYPE"='DB')
  29 - access("TI_ORIG"."REFDOSS"=:B3 AND "TI_ORIG"."REFTYPE"='DB')
  30 - access("TI_TPB"."REFINDIVIDU"="TI_ORIG"."REFINDIVIDU" AND "TI_TPB"."REFTYPE"='TPB')
  31 - access("TI"."REFDOSS"="REFDOSS" AND "TI"."REFTYPE"='CL')
       filter("TI"."REFINDIVIDU"||''=:B4)
  33 - access("TI"."REFDOSS"="D"."REFDOSS")
  37 - access("REFDOSS"="D"."REFDOSS" AND "TI"."REFTYPE"='DB')
  38 - access("TI"."REFINDIVIDU"="GI"."REFINDIVIDU")
*/
/********************************New Metrics***************************************/

/********************************Index statistics**********************************/

/********************************Other SQLs****************************************/          
/*

*/ 
/********************************Other SQLs****************************************/              
