/********************************************************************************
*********       E-mail subject: KBCCFWEB-2185
*********             Instance: DEV3
*********          Description: 
Problem:
Slowness on KBC DEV3 was noticed when KBCUTIL.P_RETRIEVE_SOA_TRANSACT is called.

Analysis:
We traced the provided select query from KBCUTIL.P_RETRIEVE_SOA_TRANSACT which contains gen$huis.ftr_views.v_client_current_acc('0001020130',9999999,9999999,'','AN','O041DEWX')).
From the trace file we found that the second TOP SQL was 1h5mfuw6dhrms.
Tha problem was that inappropriate index was used when accessing table T_ECRDOS, which leads to unnecessary selecting a lot of data.
The solution here is to make Oracle to use index T_ECRDOS$ORIG_REFLOT on table T_ECRDOS for accessing the data from column ORIG_REFLOT.

Suggestion:
Please add hint as it is shown in the New SQL section below.

*********               SQL_ID: 1h5mfuw6dhrms
*********      Program/Package: ftr_views.v_client_current_acc
*********              Request: Dimitare Ivanov
*********               Author: Dimitar Dimitrov
********* Received e-mail date: 22/11/2023
*********      Resolution date: 27/11/2023
*********  Trace old file here: \\epox\specifs\performance\tmp\
*********  Trace new file here:
***********************************************************************************/

/********************************OLD SQL*******************************************/
var B4 VARCHAR2(128);
exec :B4 := 'INT00000';
var B8 VARCHAR2(128);
exec :B8 := 'AN';
var B7 VARCHAR2(128);
exec :B7 := '0001020130';
var B5 VARCHAR2(128);
exec :B5 := '';
var B6 VARCHAR2(128);
exec :B6 := 'O041DEWX';
var B3 VARCHAR2(128);
exec :B3 := '';
var B2 NUMBER;
exec :B2 := 9999999;
var B1 NUMBER;
exec :B1 := 9999999;
var B9 VARCHAR2(128);
exec :B9 := 'N';
var B10 VARCHAR2(128);
exec :B10 := 'N';
var B11 VARCHAR2(128);
exec :B11 := 'N';
var B12 VARCHAR2(128);
exec :B12 := '';
var B13 VARCHAR2(128);
exec :B13 := '';
var B14 NUMBER;
exec :B14 := 2460269;
var B15 VARCHAR2(128);
exec :B15 := '';
var B16 VARCHAR2(128);
exec :B16 := '';
var B17 VARCHAR2(128);
exec :B17 := '';
var B18 VARCHAR2(128);
exec :B18 := '';
var B19 VARCHAR2(128);
exec :B19 := '';
var B20 VARCHAR2(128);
exec :B20 := '';
var B21 VARCHAR2(128);
exec :B21 := '';
var B22 VARCHAR2(128);
exec :B22 := 'GBR';
var B23 NUMBER;
exec :B23 := 1000000000000;


SELECT REFELEM REFELEM,
       REFDOSS REFDOSS_DCMP,
       CODECR CODECR,
       TRUNC(DTJOUR_DT) TRANSACTION_DT,
       TRUNC(DTINTER_DT) VALUE_DT,
       DECODE(SIGN(SUM(MNT_DCPT)), 1, SUM(MNT_DCPT)) DEBIT_DCMP,
       DECODE(SIGN(SUM(MNT_DCPT)), -1, ABS(SUM(MNT_DCPT))) CREDIT_DCMP,
       MAX(LIBELLE) LABEL,
       1 NB,
       (SELECT DISTINCT FIRST_VALUE(PF_LIB_TRAD) OVER(ORDER BY PF_REFFACTOR NULLS LAST)
          FROM V_FPARFAC
         WHERE PF_NOM = T.CODECR
           AND (PF_REFFACTOR IS NULL OR PF_REFFACTOR = :B4)
           AND LANGUE = :B8) LABEL_DESC,
       DECODE(T.CODECR,
              'VDIS',
              (SELECT FI.REFEXT
                 FROM F_DETFAC DF, G_ELEMFI FI
                WHERE DF.DF_NUM = T.REFELEM
                  AND FI.REFELEM = DF.DF_REFINIT)) REFEXT,
       NULL RETENTIONINDIC,
       MAX(DECODE(LENGTH(T.MEMO_DECOMPTE), 8, T.MEMO_DECOMPTE, NULL)) MEMO_DECOMPTE
  FROM T_ECRDOS T, F_PARFAC PF
 WHERE T.REFDOSS = :B7
   AND T.MEMO_DECOMPTE BETWEEN NVL(:B5, :B6) AND NVL(:B6, :B5)
   AND T.CODECR = PF.PF_NOM
   AND (PF.PF_REFFACTOR = :B4 OR PF.PF_REFFACTOR IS NULL AND NOT EXISTS
        (SELECT 1
           FROM F_PARFAC
          WHERE PF_NOM = PF.PF_NOM
            AND PF_REFFACTOR = :B4))
   AND T.CODECR NOT IN ('IND', 'RIND', 'RINDS', 'CRINS')
   AND (:B3 IS NULL AND T.DTJOUR <= NVL(:B2, T.DTJOUR) AND
       T.DTINTER <= NVL(:B1, T.DTINTER) OR
       :B3 = CODECR AND T.DTJOUR = NVL(:B2, T.DTJOUR) AND
       T.DTINTER = NVL(:B1, T.DTINTER))
 GROUP BY REFELEM, REFDOSS, CODECR, TRUNC(DTJOUR_DT), TRUNC(DTINTER_DT)
HAVING NVL(SUM(MNT_DCPT), 0) <> 0
UNION ALL
SELECT DF.DF_NUM REFELEM,
       DF.DF_DOS REFDOSS_DCMP,
       DF.DF_NOM CODECR,
       TRUNC(DF.DF_DAT_DT) TRANSACTION_DT,
       TRUNC(DF.F_DT_TRAITE_DT) VALUE_DT,
       DECODE(SIGN(DECODE(DF.DF_NOM, D.ABREV, 1, 'L' || D.ABREV, -1) *
                   DF.DF_MONTTC_MVT),
              1,
              DECODE(DF.DF_NOM, D.ABREV, 1, 'L' || D.ABREV, -1) *
              DF.DF_MONTTC_MVT) DEBIT_DCMP,
       DECODE(SIGN(DECODE(DF.DF_NOM, D.ABREV, 1, 'L' || D.ABREV, -1) *
                   DF.DF_MONTTC_MVT),
              -1,
              ABS(DECODE(DF.DF_NOM, D.ABREV, 1, 'L' || D.ABREV, -1) *
                  DF.DF_MONTTC_MVT)) CREDIT_DCMP,
       D.VALEUR LABEL,
       1 NB,
       (SELECT DISTINCT FIRST_VALUE(PF_LIB_TRAD) OVER(ORDER BY PF_REFFACTOR NULLS LAST)
          FROM V_FPARFAC
         WHERE PF_NOM = DF.DF_NOM
           AND (PF_REFFACTOR IS NULL OR PF_REFFACTOR = :B4)
           AND LANGUE = :B8) LABEL_DESC,
       NULL REFEXT,
       NULL RETENTIONINDIC,
       DECODE(LENGTH(DF.MEMO_DECOMPTE), 8, DF.MEMO_DECOMPTE, NULL) MEMO_DECOMPTE
  FROM F_DETFAC DF, V_DOMAINE D
 WHERE DF.DF_DOS = :B7
   AND DF.MEMO_DECOMPTE BETWEEN NVL(:B5, :B6) AND NVL(:B6, :B5)
   AND D.TYPE = 'RESERV'
   AND DF.DF_NOM IN (D.ABREV, 'L' || D.ABREV)
   AND (D.CHEMIN NOT IN ('UTILISATION_EXTERNE', 'ENCAISSEMENT') OR
       D.CHEMIN IS NULL)
   AND :B9 = 'O'
   AND (:B3 IS NULL AND DF.DF_DAT <= NVL(:B2, DF.DF_DAT) AND
       DF.F_DT_TRAITE <= NVL(:B1, DF.F_DT_TRAITE) OR
       :B3 = DF.DF_NOM AND DF.DF_DAT = NVL(:B2, DF.DF_DAT) AND
       DF.F_DT_TRAITE = NVL(:B1, DF.F_DT_TRAITE))
UNION ALL
SELECT REFELEM,
       REFDOSS_DCMP,
       CODECR,
       TRANSACTION_DT,
       VALUE_DT,
       DEBIT_DCMP,
       CREDIT_DCMP,
       LABEL,
       NB,
       (SELECT IMX.FTRANSLATE_STR(LABEL, :B8, CODECR) FROM DUAL) LABEL_DESC,
       REFEXT,
       RETENTIONINDIC,
       MEMO_DECOMPTE
  FROM (SELECT REFELEM REFELEM,
               REFDOSS REFDOSS_DCMP,
               CODECR CODECR,
               TRUNC(DTJOUR_DT) TRANSACTION_DT,
               TRUNC(DTINTER_DT) VALUE_DT,
               DECODE(SIGN(NVL(SUM(CLDEPOT_DOS), 0)),
                      -1,
                      ABS(SUM(CLDEPOT_DOS))) DEBIT_DCMP,
               DECODE(SIGN(NVL(SUM(CLDEPOT_DOS), 0)), 1, SUM(CLDEPOT_DOS)) CREDIT_DCMP,
               MAX(LIBELLE) LABEL,
               1 NB,
               NULL REFEXT,
               NULL RETENTIONINDIC,
               MAX(DECODE(LENGTH(MEMO_DECOMPTE), 8, MEMO_DECOMPTE, NULL)) MEMO_DECOMPTE
          FROM T_ECRDOS
         WHERE REFDOSS = :B7
           AND MEMO_DECOMPTE BETWEEN NVL(:B5, :B6) AND NVL(:B6, :B5)
           AND CODECR = 'PMTDB'
           AND REFLIEN IS NOT NULL
           AND REFCREANCE IS NOT NULL
           AND (:B3 IS NULL AND DTJOUR <= NVL(:B2, DTJOUR) AND
               DTINTER <= NVL(:B1, DTINTER) OR
               :B3 = CODECR AND DTJOUR = NVL(:B2, DTJOUR) AND
               DTINTER = NVL(:B1, DTINTER))
           AND :B10 = 'N'
         GROUP BY REFELEM,
                  REFDOSS,
                  CODECR,
                  TRUNC(DTJOUR_DT),
                  TRUNC(DTINTER_DT)
        HAVING NVL(SUM(CLDEPOT_DOS), 0) <> 0)
UNION ALL
SELECT REFELEM,
       REFDOSS_DCMP,
       CODECR,
       TRANSACTION_DT,
       VALUE_DT,
       DEBIT_DCMP,
       CREDIT_DCMP,
       LABEL,
       NB,
       (SELECT IMX.FTRANSLATE_STR(LABEL, :B8, CODECR) FROM DUAL) LABEL_DESC,
       REFEXT,
       RETENTIONINDIC,
       MEMO_DECOMPTE
  FROM (SELECT DECODE(TYPELEM, 'Z', REFEXT, REFELEM) REFELEM,
               REFDOSS REFDOSS_DCMP,
               DECODE(TYPELEM, 'Z', TYPE, CODECR) CODECR,
               TRUNC(DTJOUR_DT) TRANSACTION_DT,
               TRUNC(DTINTER_DT) VALUE_DT,
               SUM(DECODE(CODECR,
                          'KCRED',
                          DBDU_DOS,
                          DECODE(TYPELEM, 'Z', DBDU_DOS))) DEBIT_DCMP,
               SUM(DECODE(CODECR,
                          'ANRED',
                          DBDU_DOS,
                          DECODE(TYPELEM, 'Z', DBDEDUC_DOS))) CREDIT_DCMP,
               MAX(LIBELLE) LABEL,
               1 NB,
               NULL REFEXT,
               NULL RETENTIONINDIC,
               MAX(DECODE(LENGTH(MEMO_DECOMPTE), 8, MEMO_DECOMPTE, NULL)) MEMO_DECOMPTE
          FROM T_ECRDOS
         WHERE REFDOSS = :B7
           AND MEMO_DECOMPTE BETWEEN NVL(:B5, :B6) AND NVL(:B6, :B5)
           AND CODECR IN ('KCRED',
                          'ANRED',
                          'CTRET',
                          'CRRET',
                          'FCITB',
                          'RFCTB',
                          'FNCTB',
                          'RFNCB')
           AND (:B3 IS NULL AND DTJOUR <= NVL(:B2, DTJOUR) AND
               DTINTER <= NVL(:B1, DTINTER) OR
               :B3 = DECODE(TYPELEM, 'Z', TYPE, CODECR) AND
               DTJOUR = NVL(:B2, DTJOUR) AND DTINTER = NVL(:B1, DTINTER))
         GROUP BY DECODE(TYPELEM, 'Z', REFEXT, REFELEM),
                  REFDOSS,
                  DECODE(TYPELEM, 'Z', TYPE, CODECR),
                  TRUNC(DTJOUR_DT),
                  TRUNC(DTINTER_DT)
        HAVING NVL(SUM(NVL(DBDU_DOS, DBDEDUC_DOS)), 0) <> 0)
UNION ALL
SELECT REFELEM,
       REFDOSS_DCMP,
       CODECR,
       TRANSACTION_DT,
       VALUE_DT,
       DEBIT_DCMP,
       CREDIT_DCMP,
       LABEL,
       NB,
       CASE
         WHEN :B3 IS NULL AND T_ECRDOS_CODECR IN ('PRIN', 'DPRIN') THEN
          :B16
         WHEN :B3 IS NULL AND T_ECRDOS_CODECR IN ('APRIN', 'ADPRI') THEN
          :B15
         ELSE
          (SELECT IMX.FTRANSLATE_STR(LABEL, :B8, T_ECRDOS_CODECR) FROM DUAL)
       END LABEL_DESC,
       REFEXT,
       RETENTIONINDIC,
       MEMO_DECOMPTE
  FROM (SELECT /*+ index (md PIE_REFDOSS)*/
         T.REFELEM REFELEM,
         C.REFLOT REFDOSS_DCMP,
         'CESS' || DECODE(T.CODECR, 'PRIN', 'INV', 'DPRIN', 'INV', 'ANN') ||
         DECODE(:B12, 'AF', F.GPIDEPOT) CODECR,
         DECODE(:B12, 'AF', TRUNC(F.DT02_DT), TRUNC(T.DTJOUR_DT)) TRANSACTION_DT,
         DECODE(:B12, 'AF', TRUNC(F.DT02_DT), TRUNC(T.DTJOUR_DT)) VALUE_DT,
         DECODE(SIGN(SUM(T.MNT_DCPT)), -1, ABS(SUM(T.MNT_DCPT))) DEBIT_DCMP,
         DECODE(SIGN(SUM(T.MNT_DCPT)), 1, SUM(T.MNT_DCPT)) CREDIT_DCMP,
         MAX(T.LIBELLE) LABEL,
         1 NB,
         T.CODECR T_ECRDOS_CODECR,
         MAX(FI.REFEXT) REFEXT,
         NULL RETENTIONINDIC,
         MAX(DECODE(LENGTH(T.ORIG_REFLOT), 8, T.ORIG_REFLOT, NULL)) MEMO_DECOMPTE
          FROM G_PIECE   MD,
               G_DOSSIER C,
               T_ECRDOS  T,
               G_ELEMFI  FI,
               V_ELEMFI  VE,
               G_PIECE   F
         WHERE MD.REFDOSS = :B7
           AND MD.TYPPIECE = 'MEMO_DECOMPTE'
           AND MD.DT10 BETWEEN NVL(:B13, :B14) AND NVL(:B14, :B13)
           AND MD.REFPIECE BETWEEN NVL(:B5, :B6) AND NVL(:B6, :B5)
           AND C.REFLOT = MD.REFDOSS
           AND T.REFDOSS = C.REFDOSS
           AND T.ORIG_REFLOT = MD.REFPIECE
           AND T.TYPELEM = 'f'
           AND T.CODECR IN ('PRIN', 'APRIN', 'DPRIN', 'ADPRI')
           AND FI.REFELEM = T.REFELEM
           AND VE.TYPE = FI.TYPE
           AND VE.CESSION = 'O'
           AND VE.TYPE NOT IN ('SAF CN COMP',
                               'DRAFT',
                               'NON MATCHED PAYMENT ELEMENTS',
                               'POSITIVE LTL DECLARED PAYMENTS',
                               'ANNULATION DAVOIRS PAR DES REGLEMENTS',
                               'OPERATION DIVERSE CREDITRICE',
                               'ANNULATION ODC',
                               'OPERATION DIVERSE DEBITRICE',
                               'ANNULATION ODD')
           AND F.GPIHEURE = FI.REFELEM
           AND F.TYPPIECE = 'FACTURE'
           AND (:B3 IS NULL AND
               DECODE(:B12, 'AF', F.DT02, T.DTJOUR) <=
               NVL(:B2, DECODE(:B12, 'AF', F.DT02, T.DTJOUR)) AND
               DECODE(:B12, 'AF', F.DT02, T.DTJOUR) <=
               NVL(:B1, DECODE(:B12, 'AF', F.DT02, T.DTJOUR)) OR
               :B3 = 'CESS' ||
               DECODE(T.CODECR, 'PRIN', 'INV', 'DPRIN', 'INV', 'ANN') ||
               DECODE(:B12, 'AF', F.GPIDEPOT) AND
               DECODE(:B12, 'AF', F.DT02, T.DTJOUR) =
               NVL(:B2, DECODE(:B12, 'AF', F.DT02, T.DTJOUR)) AND
               DECODE(:B12, 'AF', F.DT02, T.DTJOUR) =
               NVL(:B1, DECODE(:B12, 'AF', F.DT02, T.DTJOUR)))
           AND (:B10 = 'N' OR :B11 = 'O')
         GROUP BY T.REFELEM,
                  F.GPIDEPOT,
                  C.REFLOT,
                  T.CODECR,
                  TRUNC(F.DT02_DT),
                  TRUNC(T.DTJOUR_DT)
        HAVING NVL(SUM(T.MNT_DCPT), 0) <> 0)
UNION ALL
SELECT REFELEM,
       REFDOSS_DCMP,
       CODECR,
       TRANSACTION_DT,
       VALUE_DT,
       DEBIT_DCMP,
       CREDIT_DCMP,
       LABEL,
       NB,
       CASE
         WHEN :B3 IS NULL AND CODECR = 'PRIN' THEN
          :B20
         WHEN :B3 IS NULL AND CODECR = 'APRIN' THEN
          :B19
         WHEN :B3 IS NULL AND CODECR = 'DPRIN' THEN
          :B18
         WHEN :B3 IS NULL AND CODECR = 'ADPRI' THEN
          :B17
         ELSE
          (SELECT IMX.FTRANSLATE_STR(LABEL, :B8, CODECR) FROM DUAL)
       END LABEL_DESC,
       REFEXT,
       RETENTIONINDIC,
       MEMO_DECOMPTE
  FROM (SELECT /*+ index (md PIE_REFDOSS)*/
         T.REFELEM REFELEM,
         C.REFLOT REFDOSS_DCMP,
         T.CODECR CODECR,
         TRUNC(T.DTJOUR_DT) TRANSACTION_DT,
         TRUNC(T.DTJOUR_DT) VALUE_DT,
         DECODE(SIGN(SUM(T.MNT_DCPT)), -1, ABS(SUM(T.MNT_DCPT))) DEBIT_DCMP,
         DECODE(SIGN(SUM(T.MNT_DCPT)), 1, SUM(T.MNT_DCPT)) CREDIT_DCMP,
         MAX(T.LIBELLE) LABEL,
         1 NB,
         MAX(FI.REFEXT) REFEXT,
         NULL RETENTIONINDIC,
         MAX(DECODE(LENGTH(T.ORIG_REFLOT), 8, T.ORIG_REFLOT, NULL)) MEMO_DECOMPTE
          FROM G_PIECE MD, G_DOSSIER C, T_ECRDOS T, G_ELEMFI FI, V_ELEMFI VE
         WHERE MD.REFDOSS = :B7
           AND MD.TYPPIECE = 'MEMO_DECOMPTE'
           AND MD.DT10 BETWEEN NVL(:B13, :B14) AND NVL(:B14, :B13)
           AND MD.REFPIECE BETWEEN NVL(:B5, :B6) AND NVL(:B6, :B5)
           AND C.REFLOT = MD.REFDOSS
           AND T.REFDOSS = C.REFDOSS
           AND T.ORIG_REFLOT = MD.REFPIECE
           AND T.TYPELEM = 'f'
           AND T.CODECR IN ('PRIN', 'APRIN', 'DPRIN', 'ADPRI')
           AND FI.REFELEM = T.REFELEM
           AND VE.TYPE = FI.TYPE
           AND NVL(VE.CESSION, 'N') = 'N'
           AND VE.TYPE NOT IN ('SAF CN COMP',
                               'DRAFT',
                               'NON MATCHED PAYMENT ELEMENTS',
                               'POSITIVE LTL DECLARED PAYMENTS',
                               'ANNULATION DAVOIRS PAR DES REGLEMENTS',
                               'OPERATION DIVERSE CREDITRICE',
                               'ANNULATION ODC',
                               'OPERATION DIVERSE DEBITRICE',
                               'ANNULATION ODD')
           AND (:B3 IS NULL AND T.DTJOUR <= NVL(:B2, T.DTJOUR) AND
               T.DTJOUR <= NVL(:B1, T.DTJOUR) OR
               :B3 = T.CODECR AND T.DTJOUR = NVL(:B2, T.DTJOUR) AND
               T.DTJOUR = NVL(:B1, T.DTJOUR))
           AND (:B10 = 'N' OR :B11 = 'O')
         GROUP BY T.REFELEM, C.REFLOT, T.CODECR, TRUNC(T.DTJOUR_DT)
        HAVING NVL(SUM(T.MNT_DCPT), 0) <> 0)
UNION ALL
SELECT REFELEM,
       REFDOSS_DCMP,
       CODECR,
       TRANSACTION_DT,
       VALUE_DT,
       DEBIT_DCMP,
       CREDIT_DCMP,
       LABEL,
       NB,
       (SELECT IMX.FTRANSLATE_STR(LABEL, :B8, CODECR) FROM DUAL) LABEL_DESC,
       REFEXT,
       RETENTIONINDIC,
       MEMO_DECOMPTE
  FROM (SELECT /*+ index (md PIE_REFDOSS)*/
         T.REFELEM REFELEM,
         C.REFLOT REFDOSS_DCMP,
         T.CODECR CODECR,
         TRUNC(T.DTJOUR_DT) TRANSACTION_DT,
         TRUNC(T.DTINTER_DT) VALUE_DT,
         DECODE(SIGN(NVL(SUM(T.MNT_DCPT), 0)), -1, ABS(SUM(T.MNT_DCPT))) DEBIT_DCMP,
         DECODE(SIGN(NVL(SUM(T.MNT_DCPT), 0)), 1, SUM(T.MNT_DCPT)) CREDIT_DCMP,
         MAX(T.LIBELLE) LABEL,
         1 NB,
         NULL REFEXT,
         NULL RETENTIONINDIC,
         MAX(DECODE(LENGTH(T.ORIG_REFLOT), 8, T.ORIG_REFLOT, NULL)) MEMO_DECOMPTE
          FROM G_PIECE MD, G_DOSSIER C, T_ECRDOS T
         WHERE MD.REFDOSS = :B7
           AND MD.TYPPIECE = 'MEMO_DECOMPTE'
           AND MD.DT10 BETWEEN NVL(:B13, :B14) AND NVL(:B14, :B13)
           AND MD.REFPIECE BETWEEN NVL(:B5, :B6) AND NVL(:B6, :B5)
           AND C.REFLOT = MD.REFDOSS
           AND T.REFDOSS = C.REFDOSS
           AND T.ORIG_REFLOT = MD.REFPIECE
           AND T.CODECR IN ('DCONV', 'ADCON')
           AND (:B3 IS NULL AND T.DTJOUR <= NVL(:B2, T.DTJOUR) AND
               T.DTINTER <= NVL(:B1, T.DTINTER) OR
               :B3 = T.CODECR AND T.DTJOUR = NVL(:B2, T.DTJOUR) AND
               T.DTINTER = NVL(:B1, T.DTINTER))
           AND :B10 = 'N'
         GROUP BY T.REFELEM,
                  C.REFLOT,
                  T.CODECR,
                  TRUNC(T.DTJOUR_DT),
                  TRUNC(T.DTINTER_DT)
        HAVING NVL(SUM(T.MNT_DCPT), 0) <> 0)
UNION ALL
SELECT REFELEM,
       REFDOSS_DCMP,
       CODECR,
       TRANSACTION_DT,
       VALUE_DT,
       DEBIT_DCMP,
       CREDIT_DCMP,
       LABEL,
       NB,
       (SELECT IMX.FTRANSLATE_STR(LABEL, :B8, CODECR) FROM DUAL) LABEL_DESC,
       REFEXT,
       RETENTIONINDIC,
       MEMO_DECOMPTE
  FROM (SELECT ARCH.MAX_ARCH_TRANS_DATE TRANSACTION_DT,
               ARCH.MAX_ARCH_VALUE_DATE VALUE_DT,
               ARCH.ARCH_COUNTER NB,
               'ARCHIVED CCA BALANCE' LABEL,
               DECODE(SIGN(ARCH.AMOUNT_ARCH_PART_BAL),
                      -1,
                      ABS(ARCH.AMOUNT_ARCH_PART_BAL)) CREDIT_DCMP,
               DECODE(SIGN(ARCH.AMOUNT_ARCH_PART_BAL),
                      1,
                      ARCH.AMOUNT_ARCH_PART_BAL) DEBIT_DCMP,
               NULL REFELEM,
               ARCH.REFDOSS REFDOSS_DCMP,
               'ARCHBAL' CODECR,
               NULL REFEXT,
               NULL RETENTIONINDIC,
               ARCH.MAX_MEMO_DECOMPTE MEMO_DECOMPTE
          FROM T_ARCH_DCPT_BALANCES ARCH
         WHERE TYPE_BALANCE = 'CCA'
           AND REFDOSS = :B7
           AND (:B3 IS NULL AND
               TO_CHAR(ARCH.MAX_ARCH_TRANS_DATE, 'j') <=
               NVL(:B2, TO_CHAR(ARCH.MAX_ARCH_TRANS_DATE, 'j')) AND
               TO_CHAR(ARCH.MAX_ARCH_VALUE_DATE, 'j') <=
               NVL(:B1, TO_CHAR(ARCH.MAX_ARCH_VALUE_DATE, 'j')) OR
               :B3 = 'ARCHBAL' AND
               TO_CHAR(ARCH.MAX_ARCH_TRANS_DATE, 'j') =
               NVL(:B2, TO_CHAR(ARCH.MAX_ARCH_TRANS_DATE, 'j')) AND
               TO_CHAR(ARCH.MAX_ARCH_VALUE_DATE, 'j') =
               NVL(:B1, TO_CHAR(ARCH.MAX_ARCH_VALUE_DATE, 'j')))
           AND ARCH.MAX_MEMO_DECOMPTE BETWEEN NVL(:B5, :B6) AND
               NVL(:B6, :B5))
UNION ALL
SELECT COMPOSTAGE REFELEM,
       REFDOSS REFDOSS_DCMP,
       'encEPS' CODECR,
       TRUNC(DTEXTRAIT_DT) TRANSACTION_DT,
       TRUNC(DT_RECONCILIATION_DT) VALUE_DT,
       ABS(DECODE(SIGNE,
                  1,
                  CASE
                    WHEN MONTANT_MVT IS NOT NULL AND DEVISE_MVT = :B22 THEN
                     MONTANT_MVT
                    WHEN MONTANT_MVT_BQ IS NOT NULL AND DEVISE_MVT_BQ = :B22 THEN
                     MONTANT_MVT_BQ
                    WHEN MONTANT3 IS NOT NULL AND DEVISE3 = :B22 THEN
                     MONTANT3
                    WHEN DEVISE = :B22 THEN
                     NVL(MONTANT, 0)
                    ELSE
                     CH_TAUX.CONVERSMVTDOS(DTEXTRAIT,
                                           REFDOSS,
                                           NVL(MONTANT, 0),
                                           DEVISE,
                                           'A')
                  END)) DEBIT_DCMP,
       ABS(DECODE(SIGNE,
                  0,
                  CASE
                    WHEN MONTANT_MVT IS NOT NULL AND DEVISE_MVT = :B22 THEN
                     MONTANT_MVT
                    WHEN MONTANT_MVT_BQ IS NOT NULL AND DEVISE_MVT_BQ = :B22 THEN
                     MONTANT_MVT_BQ
                    WHEN MONTANT3 IS NOT NULL AND DEVISE3 = :B22 THEN
                     MONTANT3
                    WHEN DEVISE = :B22 THEN
                     NVL(MONTANT, 0)
                    ELSE
                     CH_TAUX.CONVERSMVTDOS(DTEXTRAIT,
                                           REFDOSS,
                                           NVL(MONTANT, 0),
                                           DEVISE,
                                           'A')
                  END)) CREDIT_DCMP,
       NULL LABEL,
       1 NB,
       :B21 LABEL_DESC,
       NULL REFEXT,
       NULL RETENTIONINDIC,
       DECODE(LENGTH(MEMO_DECOMPTE), 8, MEMO_DECOMPTE, NULL) MEMO_DECOMPTE
  FROM NAM_COLLECTE
 WHERE ROWID IN (SELECT /*+ cardinality(5) */
                  COLUMN_VALUE
                   FROM TABLE(FTR_FIU.FIUROWIDLIST_EPSPMT(:B7,
                                                          :B6,
                                                          NULL,
                                                          :B1,
                                                          NULL,
                                                          :B2,
                                                          :B5))
                  WHERE ROWNUM < :B23)
   AND NVL(MONTANT, 0) != 0
   AND (:B3 IS NULL AND DTEXTRAIT <= NVL(:B2, DTEXTRAIT) AND
       TO_CHAR(DT_RECONCILIATION_DT, 'j') <=
       NVL(:B1, TO_CHAR(DT_RECONCILIATION_DT, 'j')) OR
       :B3 = 'encEPS' AND DTEXTRAIT = NVL(:B2, DTEXTRAIT) AND
       TO_CHAR(DT_RECONCILIATION_DT, 'j') =
       NVL(:B1, TO_CHAR(DT_RECONCILIATION_DT, 'j')))
   AND :B10 = 'N';
/********************************OLD SQL*******************************************/
/********************************OLD Metrics***************************************/
/*
Plan hash value: 58441273
-------------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                      | Name                        | Starts | E-Rows | A-Rows |   A-Time   | Buffers | Reads  |
-------------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                               |                             |      1 |        |      0 |00:00:01.99 |   14329 |   3426 |
|   1 |  UNION-ALL                                     |                             |      1 |        |      0 |00:00:01.99 |   14329 |   3426 |
|   2 |   SORT UNIQUE                                  |                             |      0 |      1 |      0 |00:00:00.01 |       0 |      0 |
|   3 |    WINDOW SORT                                 |                             |      0 |      1 |      0 |00:00:00.01 |       0 |      0 |
|   4 |     VIEW                                       | V_FPARFAC                   |      0 |     11 |      0 |00:00:00.01 |       0 |      0 |
|   5 |      UNION-ALL                                 |                             |      0 |        |      0 |00:00:00.01 |       0 |      0 |
|*  6 |       FILTER                                   |                             |      0 |        |      0 |00:00:00.01 |       0 |      0 |
|   7 |        TABLE ACCESS BY INDEX ROWID BATCHED     | F_PARFAC                    |      0 |      1 |      0 |00:00:00.01 |       0 |      0 |
|*  8 |         INDEX RANGE SCAN                       | PARFAC_CL1                  |      0 |      1 |      0 |00:00:00.01 |       0 |      0 |
|*  9 |       FILTER                                   |                             |      0 |        |      0 |00:00:00.01 |       0 |      0 |
|  10 |        TABLE ACCESS BY INDEX ROWID BATCHED     | F_PARFAC                    |      0 |      1 |      0 |00:00:00.01 |       0 |      0 |
|* 11 |         INDEX RANGE SCAN                       | PARFAC_CL1                  |      0 |      1 |      0 |00:00:00.01 |       0 |      0 |
|* 12 |       FILTER                                   |                             |      0 |        |      0 |00:00:00.01 |       0 |      0 |
|  13 |        TABLE ACCESS BY INDEX ROWID BATCHED     | F_PARFAC                    |      0 |      1 |      0 |00:00:00.01 |       0 |      0 |
|* 14 |         INDEX RANGE SCAN                       | PARFAC_CL1                  |      0 |      1 |      0 |00:00:00.01 |       0 |      0 |
|* 15 |       FILTER                                   |                             |      0 |        |      0 |00:00:00.01 |       0 |      0 |
|  16 |        TABLE ACCESS BY INDEX ROWID BATCHED     | F_PARFAC                    |      0 |      1 |      0 |00:00:00.01 |       0 |      0 |
|* 17 |         INDEX RANGE SCAN                       | PARFAC_CL1                  |      0 |      1 |      0 |00:00:00.01 |       0 |      0 |
|* 18 |       FILTER                                   |                             |      0 |        |      0 |00:00:00.01 |       0 |      0 |
|  19 |        TABLE ACCESS BY INDEX ROWID BATCHED     | F_PARFAC                    |      0 |      1 |      0 |00:00:00.01 |       0 |      0 |
|* 20 |         INDEX RANGE SCAN                       | PARFAC_CL1                  |      0 |      1 |      0 |00:00:00.01 |       0 |      0 |
|* 21 |       FILTER                                   |                             |      0 |        |      0 |00:00:00.01 |       0 |      0 |
|  22 |        TABLE ACCESS BY INDEX ROWID BATCHED     | F_PARFAC                    |      0 |      1 |      0 |00:00:00.01 |       0 |      0 |
|* 23 |         INDEX RANGE SCAN                       | PARFAC_CL1                  |      0 |      1 |      0 |00:00:00.01 |       0 |      0 |
|* 24 |       FILTER                                   |                             |      0 |        |      0 |00:00:00.01 |       0 |      0 |
|  25 |        TABLE ACCESS BY INDEX ROWID BATCHED     | F_PARFAC                    |      0 |      1 |      0 |00:00:00.01 |       0 |      0 |
|* 26 |         INDEX RANGE SCAN                       | PARFAC_CL1                  |      0 |      1 |      0 |00:00:00.01 |       0 |      0 |
|* 27 |       FILTER                                   |                             |      0 |        |      0 |00:00:00.01 |       0 |      0 |
|  28 |        TABLE ACCESS BY INDEX ROWID BATCHED     | F_PARFAC                    |      0 |      1 |      0 |00:00:00.01 |       0 |      0 |
|* 29 |         INDEX RANGE SCAN                       | PARFAC_CL1                  |      0 |      1 |      0 |00:00:00.01 |       0 |      0 |
|* 30 |       FILTER                                   |                             |      0 |        |      0 |00:00:00.01 |       0 |      0 |
|  31 |        TABLE ACCESS BY INDEX ROWID BATCHED     | F_PARFAC                    |      0 |      1 |      0 |00:00:00.01 |       0 |      0 |
|* 32 |         INDEX RANGE SCAN                       | PARFAC_CL1                  |      0 |      1 |      0 |00:00:00.01 |       0 |      0 |
|* 33 |       FILTER                                   |                             |      0 |        |      0 |00:00:00.01 |       0 |      0 |
|  34 |        TABLE ACCESS BY INDEX ROWID BATCHED     | F_PARFAC                    |      0 |      1 |      0 |00:00:00.01 |       0 |      0 |
|* 35 |         INDEX RANGE SCAN                       | PARFAC_CL1                  |      0 |      1 |      0 |00:00:00.01 |       0 |      0 |
|* 36 |       FILTER                                   |                             |      0 |        |      0 |00:00:00.01 |       0 |      0 |
|  37 |        TABLE ACCESS BY INDEX ROWID BATCHED     | F_PARFAC                    |      0 |      1 |      0 |00:00:00.01 |       0 |      0 |
|* 38 |         INDEX RANGE SCAN                       | PARFAC_CL1                  |      0 |      1 |      0 |00:00:00.01 |       0 |      0 |
|  39 |   NESTED LOOPS                                 |                             |      0 |      1 |      0 |00:00:00.01 |       0 |      0 |
|  40 |    NESTED LOOPS                                |                             |      0 |      1 |      0 |00:00:00.01 |       0 |      0 |
|  41 |     TABLE ACCESS BY INDEX ROWID BATCHED        | F_DETFAC                    |      0 |      1 |      0 |00:00:00.01 |       0 |      0 |
|* 42 |      INDEX RANGE SCAN                          | DETFAC_NUM                  |      0 |      1 |      0 |00:00:00.01 |       0 |      0 |
|* 43 |     INDEX UNIQUE SCAN                          | EFI_REFELEM                 |      0 |      1 |      0 |00:00:00.01 |       0 |      0 |
|  44 |    TABLE ACCESS BY INDEX ROWID                 | G_ELEMFI                    |      0 |      1 |      0 |00:00:00.01 |       0 |      0 |
|* 45 |   FILTER                                       |                             |      1 |        |      0 |00:00:00.01 |       4 |      4 |
|  46 |    HASH GROUP BY                               |                             |      1 |      1 |      0 |00:00:00.01 |       4 |      4 |
|* 47 |     FILTER                                     |                             |      1 |        |      0 |00:00:00.01 |       4 |      4 |
|* 48 |      FILTER                                    |                             |      1 |        |      0 |00:00:00.01 |       4 |      4 |
|  49 |       NESTED LOOPS                             |                             |      1 |      1 |      0 |00:00:00.01 |       4 |      4 |
|* 50 |        TABLE ACCESS BY INDEX ROWID BATCHED     | T_ECRDOS                    |      1 |      1 |      0 |00:00:00.01 |       4 |      4 |
|* 51 |         INDEX RANGE SCAN                       | T_ECRDOS_MEMO_IDX           |      1 |      1 |      0 |00:00:00.01 |       4 |      4 |
|* 52 |        INDEX RANGE SCAN                        | PARFAC_CL1                  |      0 |      1 |      0 |00:00:00.01 |       0 |      0 |
|* 53 |      INDEX UNIQUE SCAN                         | PARFAC_CL1                  |      0 |      1 |      0 |00:00:00.01 |       0 |      0 |
|  54 |   SORT UNIQUE                                  |                             |      0 |      1 |      0 |00:00:00.01 |       0 |      0 |
|  55 |    WINDOW SORT                                 |                             |      0 |      1 |      0 |00:00:00.01 |       0 |      0 |
|  56 |     VIEW                                       | V_FPARFAC                   |      0 |     11 |      0 |00:00:00.01 |       0 |      0 |
|  57 |      UNION-ALL                                 |                             |      0 |        |      0 |00:00:00.01 |       0 |      0 |
|* 58 |       FILTER                                   |                             |      0 |        |      0 |00:00:00.01 |       0 |      0 |
|  59 |        TABLE ACCESS BY INDEX ROWID BATCHED     | F_PARFAC                    |      0 |      1 |      0 |00:00:00.01 |       0 |      0 |
|* 60 |         INDEX RANGE SCAN                       | PARFAC_CL1                  |      0 |      1 |      0 |00:00:00.01 |       0 |      0 |
|* 61 |       FILTER                                   |                             |      0 |        |      0 |00:00:00.01 |       0 |      0 |
|  62 |        TABLE ACCESS BY INDEX ROWID BATCHED     | F_PARFAC                    |      0 |      1 |      0 |00:00:00.01 |       0 |      0 |
|* 63 |         INDEX RANGE SCAN                       | PARFAC_CL1                  |      0 |      1 |      0 |00:00:00.01 |       0 |      0 |
|* 64 |       FILTER                                   |                             |      0 |        |      0 |00:00:00.01 |       0 |      0 |
|  65 |        TABLE ACCESS BY INDEX ROWID BATCHED     | F_PARFAC                    |      0 |      1 |      0 |00:00:00.01 |       0 |      0 |
|* 66 |         INDEX RANGE SCAN                       | PARFAC_CL1                  |      0 |      1 |      0 |00:00:00.01 |       0 |      0 |
|* 67 |       FILTER                                   |                             |      0 |        |      0 |00:00:00.01 |       0 |      0 |
|  68 |        TABLE ACCESS BY INDEX ROWID BATCHED     | F_PARFAC                    |      0 |      1 |      0 |00:00:00.01 |       0 |      0 |
|* 69 |         INDEX RANGE SCAN                       | PARFAC_CL1                  |      0 |      1 |      0 |00:00:00.01 |       0 |      0 |
|* 70 |       FILTER                                   |                             |      0 |        |      0 |00:00:00.01 |       0 |      0 |
|  71 |        TABLE ACCESS BY INDEX ROWID BATCHED     | F_PARFAC                    |      0 |      1 |      0 |00:00:00.01 |       0 |      0 |
|* 72 |         INDEX RANGE SCAN                       | PARFAC_CL1                  |      0 |      1 |      0 |00:00:00.01 |       0 |      0 |
|* 73 |       FILTER                                   |                             |      0 |        |      0 |00:00:00.01 |       0 |      0 |
|  74 |        TABLE ACCESS BY INDEX ROWID BATCHED     | F_PARFAC                    |      0 |      1 |      0 |00:00:00.01 |       0 |      0 |
|* 75 |         INDEX RANGE SCAN                       | PARFAC_CL1                  |      0 |      1 |      0 |00:00:00.01 |       0 |      0 |
|* 76 |       FILTER                                   |                             |      0 |        |      0 |00:00:00.01 |       0 |      0 |
|  77 |        TABLE ACCESS BY INDEX ROWID BATCHED     | F_PARFAC                    |      0 |      1 |      0 |00:00:00.01 |       0 |      0 |
|* 78 |         INDEX RANGE SCAN                       | PARFAC_CL1                  |      0 |      1 |      0 |00:00:00.01 |       0 |      0 |
|* 79 |       FILTER                                   |                             |      0 |        |      0 |00:00:00.01 |       0 |      0 |
|  80 |        TABLE ACCESS BY INDEX ROWID BATCHED     | F_PARFAC                    |      0 |      1 |      0 |00:00:00.01 |       0 |      0 |
|* 81 |         INDEX RANGE SCAN                       | PARFAC_CL1                  |      0 |      1 |      0 |00:00:00.01 |       0 |      0 |
|* 82 |       FILTER                                   |                             |      0 |        |      0 |00:00:00.01 |       0 |      0 |
|  83 |        TABLE ACCESS BY INDEX ROWID BATCHED     | F_PARFAC                    |      0 |      1 |      0 |00:00:00.01 |       0 |      0 |
|* 84 |         INDEX RANGE SCAN                       | PARFAC_CL1                  |      0 |      1 |      0 |00:00:00.01 |       0 |      0 |
|* 85 |       FILTER                                   |                             |      0 |        |      0 |00:00:00.01 |       0 |      0 |
|  86 |        TABLE ACCESS BY INDEX ROWID BATCHED     | F_PARFAC                    |      0 |      1 |      0 |00:00:00.01 |       0 |      0 |
|* 87 |         INDEX RANGE SCAN                       | PARFAC_CL1                  |      0 |      1 |      0 |00:00:00.01 |       0 |      0 |
|* 88 |       FILTER                                   |                             |      0 |        |      0 |00:00:00.01 |       0 |      0 |
|  89 |        TABLE ACCESS BY INDEX ROWID BATCHED     | F_PARFAC                    |      0 |      1 |      0 |00:00:00.01 |       0 |      0 |
|* 90 |         INDEX RANGE SCAN                       | PARFAC_CL1                  |      0 |      1 |      0 |00:00:00.01 |       0 |      0 |
|* 91 |   FILTER                                       |                             |      1 |        |      0 |00:00:00.01 |       0 |      0 |
|  92 |    NESTED LOOPS                                |                             |      0 |      1 |      0 |00:00:00.01 |       0 |      0 |
|  93 |     NESTED LOOPS                               |                             |      0 |      1 |      0 |00:00:00.01 |       0 |      0 |
|* 94 |      TABLE ACCESS BY INDEX ROWID BATCHED       | F_DETFAC                    |      0 |      1 |      0 |00:00:00.01 |       0 |      0 |
|* 95 |       INDEX RANGE SCAN                         | IDX_DETFAC_DCPT             |      0 |      1 |      0 |00:00:00.01 |       0 |      0 |
|* 96 |      INDEX RANGE SCAN                          | DOM_TYPABREV                |      0 |      1 |      0 |00:00:00.01 |       0 |      0 |
|* 97 |     TABLE ACCESS BY INDEX ROWID                | V_DOMAINE                   |      0 |      1 |      0 |00:00:00.01 |       0 |      0 |
|  98 |   FAST DUAL                                    |                             |      0 |      1 |      0 |00:00:00.01 |       0 |      0 |
|  99 |   VIEW                                         |                             |      1 |      1 |      0 |00:00:00.01 |       4 |      0 |
|*100 |    FILTER                                      |                             |      1 |        |      0 |00:00:00.01 |       4 |      0 |
| 101 |     HASH GROUP BY                              |                             |      1 |      1 |      0 |00:00:00.01 |       4 |      0 |
|*102 |      FILTER                                    |                             |      1 |        |      0 |00:00:00.01 |       4 |      0 |
|*103 |       TABLE ACCESS BY INDEX ROWID BATCHED      | T_ECRDOS                    |      1 |      1 |      0 |00:00:00.01 |       4 |      0 |
|*104 |        INDEX RANGE SCAN                        | T_ECRDOS_MEMO_IDX           |      1 |      1 |      0 |00:00:00.01 |       4 |      0 |
| 105 |   FAST DUAL                                    |                             |      0 |      1 |      0 |00:00:00.01 |       0 |      0 |
| 106 |   VIEW                                         |                             |      1 |      1 |      0 |00:00:00.01 |       4 |      0 |
|*107 |    FILTER                                      |                             |      1 |        |      0 |00:00:00.01 |       4 |      0 |
| 108 |     HASH GROUP BY                              |                             |      1 |      1 |      0 |00:00:00.01 |       4 |      0 |
|*109 |      FILTER                                    |                             |      1 |        |      0 |00:00:00.01 |       4 |      0 |
|*110 |       TABLE ACCESS BY INDEX ROWID BATCHED      | T_ECRDOS                    |      1 |      1 |      0 |00:00:00.01 |       4 |      0 |
|*111 |        INDEX RANGE SCAN                        | T_ECRDOS_MEMO_IDX           |      1 |      1 |      0 |00:00:00.01 |       4 |      0 |
| 112 |   FAST DUAL                                    |                             |      0 |      1 |      0 |00:00:00.01 |       0 |      0 |
| 113 |   VIEW                                         |                             |      1 |      1 |      0 |00:00:00.01 |      10 |      8 |
|*114 |    FILTER                                      |                             |      1 |        |      0 |00:00:00.01 |      10 |      8 |
| 115 |     HASH GROUP BY                              |                             |      1 |      1 |      0 |00:00:00.01 |      10 |      8 |
|*116 |      FILTER                                    |                             |      1 |        |      0 |00:00:00.01 |      10 |      8 |
| 117 |       NESTED LOOPS                             |                             |      1 |      1 |      0 |00:00:00.01 |      10 |      8 |
| 118 |        NESTED LOOPS                            |                             |      1 |      1 |      0 |00:00:00.01 |      10 |      8 |
| 119 |         NESTED LOOPS                           |                             |      1 |      1 |      0 |00:00:00.01 |      10 |      8 |
| 120 |          NESTED LOOPS                          |                             |      1 |      1 |      0 |00:00:00.01 |      10 |      8 |
| 121 |           NESTED LOOPS                         |                             |      1 |      1 |      0 |00:00:00.01 |      10 |      8 |
| 122 |            NESTED LOOPS                        |                             |      1 |      1 |      0 |00:00:00.01 |      10 |      8 |
|*123 |             TABLE ACCESS BY INDEX ROWID BATCHED| G_PIECE                     |      1 |      1 |      1 |00:00:00.01 |       6 |      4 |
|*124 |              INDEX RANGE SCAN                  | PIE_REFDOSS                 |      1 |      1 |      2 |00:00:00.01 |       4 |      2 |
|*125 |             TABLE ACCESS BY INDEX ROWID BATCHED| T_ECRDOS                    |      1 |      1 |      0 |00:00:00.01 |       4 |      4 |
|*126 |              INDEX RANGE SCAN                  | T_ECRDOS$ORIG_REFLOT        |      1 |     12 |      0 |00:00:00.01 |       4 |      4 |
|*127 |            INDEX RANGE SCAN                    | DOS_REFDOSS_REFLOT_IDX      |      0 |      1 |      0 |00:00:00.01 |       0 |      0 |
|*128 |           TABLE ACCESS BY INDEX ROWID          | G_ELEMFI                    |      0 |      1 |      0 |00:00:00.01 |       0 |      0 |
|*129 |            INDEX UNIQUE SCAN                   | EFI_REFELEM                 |      0 |      1 |      0 |00:00:00.01 |       0 |      0 |
|*130 |          TABLE ACCESS BY INDEX ROWID BATCHED   | V_ELEMFI                    |      0 |      1 |      0 |00:00:00.01 |       0 |      0 |
|*131 |           INDEX RANGE SCAN                     | VF_TYPE_FINANCING           |      0 |      1 |      0 |00:00:00.01 |       0 |      0 |
|*132 |         INDEX RANGE SCAN                       | GP_GRTYPE_MT_DT             |      0 |      1 |      0 |00:00:00.01 |       0 |      0 |
|*133 |        TABLE ACCESS BY INDEX ROWID             | G_PIECE                     |      0 |      1 |      0 |00:00:00.01 |       0 |      0 |
| 134 |   FAST DUAL                                    |                             |      0 |      1 |      0 |00:00:00.01 |       0 |      0 |
| 135 |   VIEW                                         |                             |      1 |      1 |      0 |00:00:01.87 |   13734 |   3196 |
|*136 |    FILTER                                      |                             |      1 |        |      0 |00:00:01.87 |   13734 |   3196 |
| 137 |     HASH GROUP BY                              |                             |      1 |      1 |      0 |00:00:01.87 |   13734 |   3196 |
|*138 |      FILTER                                    |                             |      1 |        |      0 |00:00:01.87 |   13734 |   3196 |
| 139 |       NESTED LOOPS                             |                             |      1 |      1 |      0 |00:00:01.87 |   13734 |   3196 |
| 140 |        NESTED LOOPS                            |                             |      1 |      1 |      0 |00:00:01.87 |   13734 |   3196 |
| 141 |         NESTED LOOPS                           |                             |      1 |      1 |      0 |00:00:01.87 |   13734 |   3196 |
| 142 |          NESTED LOOPS                          |                             |      1 |      1 |      0 |00:00:01.87 |   13734 |   3196 |
| 143 |           MERGE JOIN CARTESIAN                 |                             |      1 |      1 |    143 |00:00:00.01 |      10 |      3 |
|*144 |            TABLE ACCESS BY INDEX ROWID BATCHED | G_PIECE                     |      1 |      1 |      1 |00:00:00.01 |       6 |      0 |
|*145 |             INDEX RANGE SCAN                   | PIE_REFDOSS                 |      1 |      1 |      2 |00:00:00.01 |       4 |      0 |
| 146 |            BUFFER SORT                         |                             |      1 |    120 |    143 |00:00:00.01 |       4 |      3 |
|*147 |             INDEX RANGE SCAN                   | G_DOSSIER_RL_CD_RD_RF_IDX   |      1 |    120 |    143 |00:00:00.01 |       4 |      3 |
|*148 |           TABLE ACCESS BY INDEX ROWID BATCHED  | T_ECRDOS                    |    143 |      1 |      0 |00:00:01.87 |   13724 |   3193 |
|*149 |            INDEX RANGE SCAN                    | IDX_FFSI_T_ECRDOS           |    143 |      4 |  47289 |00:00:00.22 |     607 |    518 |
|*150 |          TABLE ACCESS BY INDEX ROWID           | G_ELEMFI                    |      0 |      1 |      0 |00:00:00.01 |       0 |      0 |
|*151 |           INDEX UNIQUE SCAN                    | EFI_REFELEM                 |      0 |      1 |      0 |00:00:00.01 |       0 |      0 |
|*152 |         INDEX RANGE SCAN                       | VF_TYPE_FINANCING           |      0 |      1 |      0 |00:00:00.01 |       0 |      0 |
|*153 |        TABLE ACCESS BY INDEX ROWID             | V_ELEMFI                    |      0 |      1 |      0 |00:00:00.01 |       0 |      0 |
| 154 |   FAST DUAL                                    |                             |      0 |      1 |      0 |00:00:00.01 |       0 |      0 |
| 155 |   VIEW                                         |                             |      1 |      1 |      0 |00:00:00.11 |     568 |    217 |
|*156 |    FILTER                                      |                             |      1 |        |      0 |00:00:00.11 |     568 |    217 |
| 157 |     HASH GROUP BY                              |                             |      1 |      1 |      0 |00:00:00.11 |     568 |    217 |
|*158 |      FILTER                                    |                             |      1 |        |      0 |00:00:00.11 |     568 |    217 |
| 159 |       NESTED LOOPS                             |                             |      1 |      1 |      0 |00:00:00.11 |     568 |    217 |
| 160 |        NESTED LOOPS                            |                             |      1 |      6 |      0 |00:00:00.11 |     568 |    217 |
| 161 |         MERGE JOIN CARTESIAN                   |                             |      1 |      1 |    143 |00:00:00.01 |      10 |      0 |
|*162 |          TABLE ACCESS BY INDEX ROWID BATCHED   | G_PIECE                     |      1 |      1 |      1 |00:00:00.01 |       6 |      0 |
|*163 |           INDEX RANGE SCAN                     | PIE_REFDOSS                 |      1 |      1 |      2 |00:00:00.01 |       4 |      0 |
| 164 |          BUFFER SORT                           |                             |      1 |    120 |    143 |00:00:00.01 |       4 |      0 |
|*165 |           INDEX RANGE SCAN                     | G_DOSSIER_RL_CD_RD_RF_IDX   |      1 |    120 |    143 |00:00:00.01 |       4 |      0 |
| 166 |         INLIST ITERATOR                        |                             |    143 |        |      0 |00:00:00.11 |     558 |    217 |
|*167 |          INDEX RANGE SCAN                      | TECR$REFDOSS_CODECR_DTINTER |    286 |      6 |      0 |00:00:00.11 |     558 |    217 |
|*168 |        TABLE ACCESS BY INDEX ROWID             | T_ECRDOS                    |      0 |      1 |      0 |00:00:00.01 |       0 |      0 |
| 169 |   FAST DUAL                                    |                             |      0 |      1 |      0 |00:00:00.01 |       0 |      0 |
|*170 |   FILTER                                       |                             |      1 |        |      0 |00:00:00.01 |       1 |      1 |
|*171 |    TABLE ACCESS BY INDEX ROWID                 | T_ARCH_DCPT_BALANCES        |      1 |      1 |      0 |00:00:00.01 |       1 |      1 |
|*172 |     INDEX UNIQUE SCAN                          | PK_ARCH_DCPT_BALANCES       |      1 |      1 |      0 |00:00:00.01 |       1 |      1 |
|*173 |   FILTER                                       |                             |      1 |        |      0 |00:00:00.01 |       4 |      0 |
| 174 |    NESTED LOOPS                                |                             |      1 |     75 |      0 |00:00:00.01 |       4 |      0 |
| 175 |     SORT UNIQUE                                |                             |      1 |      5 |      0 |00:00:00.01 |       4 |      0 |
| 176 |      VIEW                                      | VW_NSO_1                    |      1 |      5 |      0 |00:00:00.01 |       4 |      0 |
| 177 |       HASH UNIQUE                              |                             |      1 |      1 |      0 |00:00:00.01 |       4 |      0 |
|*178 |        COUNT STOPKEY                           |                             |      1 |        |      0 |00:00:00.01 |       4 |      0 |
| 179 |         COLLECTION ITERATOR PICKLER FETCH      | FIUROWIDLIST_EPSPMT         |      1 |   8168 |      0 |00:00:00.01 |       4 |      0 |
|*180 |     TABLE ACCESS BY USER ROWID                 | NAM_COLLECTE                |      0 |     75 |      0 |00:00:00.01 |       0 |      0 |
-------------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   6 - filter('AL'=:B8)
   8 - access("PF_NOM"=:B1)
       filter(("PF_REFFACTOR" IS NULL OR "PF_REFFACTOR"=:B4))
   9 - filter('AN'=:B8)
  11 - access("PF_NOM"=:B1)
       filter(("PF_REFFACTOR" IS NULL OR "PF_REFFACTOR"=:B4))
  12 - filter('DA'=:B8)
  14 - access("PF_NOM"=:B1)
       filter(("PF_REFFACTOR" IS NULL OR "PF_REFFACTOR"=:B4))
  15 - filter('ES'=:B8)
  17 - access("PF_NOM"=:B1)
       filter(("PF_REFFACTOR" IS NULL OR "PF_REFFACTOR"=:B4))
  18 - filter('FI'=:B8)
  20 - access("PF_NOM"=:B1)
       filter(("PF_REFFACTOR" IS NULL OR "PF_REFFACTOR"=:B4))
  21 - filter('FR'=:B8)
  23 - access("PF_NOM"=:B1)
       filter(("PF_REFFACTOR" IS NULL OR "PF_REFFACTOR"=:B4))
  24 - filter('HU'=:B8)
  26 - access("PF_NOM"=:B1)
       filter(("PF_REFFACTOR" IS NULL OR "PF_REFFACTOR"=:B4))
  27 - filter('IT'=:B8)
  29 - access("PF_NOM"=:B1)
       filter(("PF_REFFACTOR" IS NULL OR "PF_REFFACTOR"=:B4))
  30 - filter('NL'=:B8)
  32 - access("PF_NOM"=:B1)
       filter(("PF_REFFACTOR" IS NULL OR "PF_REFFACTOR"=:B4))
  33 - filter('NO'=:B8)
  35 - access("PF_NOM"=:B1)
       filter(("PF_REFFACTOR" IS NULL OR "PF_REFFACTOR"=:B4))
  36 - filter('PT'=:B8)
  38 - access("PF_NOM"=:B1)
       filter(("PF_REFFACTOR" IS NULL OR "PF_REFFACTOR"=:B4))
  42 - access("DF"."DF_NUM"=:B1)
  43 - access("FI"."REFELEM"="DF"."DF_REFINIT")
  45 - filter(NVL(SUM("MNT_DCPT"),0)<>0)
  47 - filter(("PF"."PF_REFFACTOR"=:B4 OR ("PF"."PF_REFFACTOR" IS NULL AND  IS NULL)))
  48 - filter(NVL(:B6,:B5)>=NVL(:B5,:B6))
  50 - filter((((:B3 IS NULL AND "T"."DTINTER"<=NVL(:B1,"T"."DTINTER") AND "T"."DTJOUR"<=NVL(:B2,"T"."DTJOUR")) OR ("CODECR"=:B3 AND
              "T"."DTJOUR"=NVL(:B2,"T"."DTJOUR") AND "T"."DTINTER"=NVL(:B1,"T"."DTINTER"))) AND "T"."CODECR"<>'IND' AND "T"."CODECR"<>'RIND' AND
              "T"."CODECR"<>'RINDS' AND "T"."CODECR"<>'CRINS'))
  51 - access("T"."REFDOSS"=:B7 AND "T"."MEMO_DECOMPTE">=NVL(:B5,:B6) AND "T"."MEMO_DECOMPTE"<=NVL(:B6,:B5))
  52 - access("CODECR"="PF"."PF_NOM")
       filter(("PF"."PF_NOM"<>'IND' AND "PF"."PF_NOM"<>'RIND' AND "PF"."PF_NOM"<>'RINDS' AND "PF"."PF_NOM"<>'CRINS'))
  53 - access("PF_NOM"=:B1 AND "PF_REFFACTOR"=:B4)
  58 - filter('AL'=:B8)
  60 - access("PF_NOM"=:B1)
       filter(("PF_REFFACTOR" IS NULL OR "PF_REFFACTOR"=:B4))
  61 - filter('AN'=:B8)
  63 - access("PF_NOM"=:B1)
       filter(("PF_REFFACTOR" IS NULL OR "PF_REFFACTOR"=:B4))
  64 - filter('DA'=:B8)
  66 - access("PF_NOM"=:B1)
       filter(("PF_REFFACTOR" IS NULL OR "PF_REFFACTOR"=:B4))
  67 - filter('ES'=:B8)
  69 - access("PF_NOM"=:B1)
       filter(("PF_REFFACTOR" IS NULL OR "PF_REFFACTOR"=:B4))
  70 - filter('FI'=:B8)
  72 - access("PF_NOM"=:B1)
       filter(("PF_REFFACTOR" IS NULL OR "PF_REFFACTOR"=:B4))
  73 - filter('FR'=:B8)
  75 - access("PF_NOM"=:B1)
       filter(("PF_REFFACTOR" IS NULL OR "PF_REFFACTOR"=:B4))
  76 - filter('HU'=:B8)
  78 - access("PF_NOM"=:B1)
       filter(("PF_REFFACTOR" IS NULL OR "PF_REFFACTOR"=:B4))
  79 - filter('IT'=:B8)
  81 - access("PF_NOM"=:B1)
       filter(("PF_REFFACTOR" IS NULL OR "PF_REFFACTOR"=:B4))
  82 - filter('NL'=:B8)
  84 - access("PF_NOM"=:B1)
       filter(("PF_REFFACTOR" IS NULL OR "PF_REFFACTOR"=:B4))
  85 - filter('NO'=:B8)
  87 - access("PF_NOM"=:B1)
       filter(("PF_REFFACTOR" IS NULL OR "PF_REFFACTOR"=:B4))
  88 - filter('PT'=:B8)
  90 - access("PF_NOM"=:B1)
       filter(("PF_REFFACTOR" IS NULL OR "PF_REFFACTOR"=:B4))
  91 - filter((NVL(:B6,:B5)>=NVL(:B5,:B6) AND :B9='O'))
  94 - filter(((:B3 IS NULL AND "DF"."F_DT_TRAITE"<=NVL(:B1,"DF"."F_DT_TRAITE") AND "DF"."DF_DAT"<=NVL(:B2,"DF"."DF_DAT")) OR
              ("DF"."DF_NOM"=:B3 AND "DF"."DF_DAT"=NVL(:B2,"DF"."DF_DAT") AND "DF"."F_DT_TRAITE"=NVL(:B1,"DF"."F_DT_TRAITE"))))
  95 - access("DF"."DF_DOS"=:B7 AND "DF"."MEMO_DECOMPTE">=NVL(:B5,:B6) AND "DF"."MEMO_DECOMPTE"<=NVL(:B6,:B5))
  96 - access("D"."TYPE"='RESERV')
       filter((("DF"."DF_NOM"="D"."ABREV" AND "D"."ABREV" IS NOT NULL) OR "DF"."DF_NOM"='L'||"D"."ABREV"))
  97 - filter(("D"."CHEMIN" IS NULL OR ("D"."CHEMIN"<>'UTILISATION_EXTERNE' AND "D"."CHEMIN"<>'ENCAISSEMENT')))
 100 - filter(NVL(SUM("CLDEPOT_DOS"),0)<>0)
 102 - filter((NVL(:B6,:B5)>=NVL(:B5,:B6) AND :B10='N'))
 103 - filter(("REFLIEN" IS NOT NULL AND "REFCREANCE" IS NOT NULL AND "CODECR"='PMTDB' AND ((:B3 IS NULL AND
              "DTINTER"<=NVL(:B1,"DTINTER") AND "DTJOUR"<=NVL(:B2,"DTJOUR")) OR ("CODECR"=:B3 AND "DTJOUR"=NVL(:B2,"DTJOUR") AND
              "DTINTER"=NVL(:B1,"DTINTER")))))
 104 - access("REFDOSS"=:B7 AND "MEMO_DECOMPTE">=NVL(:B5,:B6) AND "MEMO_DECOMPTE"<=NVL(:B6,:B5))
 107 - filter(NVL(SUM(NVL("DBDU_DOS","DBDEDUC_DOS")),0)<>0)
 109 - filter(NVL(:B6,:B5)>=NVL(:B5,:B6))
 110 - filter((((:B3 IS NULL AND "DTINTER"<=NVL(:B1,"DTINTER") AND "DTJOUR"<=NVL(:B2,"DTJOUR")) OR ("DTJOUR"=NVL(:B2,"DTJOUR") AND
              "DTINTER"=NVL(:B1,"DTINTER") AND DECODE("TYPELEM",'Z',"TYPE","CODECR")=:B3)) AND INTERNAL_FUNCTION("CODECR")))
 111 - access("REFDOSS"=:B7 AND "MEMO_DECOMPTE">=NVL(:B5,:B6) AND "MEMO_DECOMPTE"<=NVL(:B6,:B5))
 114 - filter(NVL(SUM("T"."MNT_DCPT"),0)<>0)
 116 - filter((NVL(:B6,:B5)>=NVL(:B5,:B6) AND NVL(:B14,TO_NUMBER(:B13))>=TO_NUMBER(NVL(:B13,TO_CHAR(:B14))) AND (:B10='N' OR :B11='O')))
 123 - filter(("MD"."REFPIECE">=NVL(:B5,:B6) AND "MD"."REFPIECE"<=NVL(:B6,:B5)))
 124 - access("MD"."REFDOSS"=:B7 AND "MD"."TYPPIECE"='MEMO_DECOMPTE' AND "MD"."DT10">=TO_NUMBER(NVL(:B13,TO_CHAR(:B14))) AND
              "MD"."DT10"<=NVL(:B14,TO_NUMBER(:B13)))
 125 - filter(("T"."TYPELEM"='f' AND INTERNAL_FUNCTION("T"."CODECR")))
 126 - access("T"."ORIG_REFLOT"="MD"."REFPIECE")
       filter(("T"."ORIG_REFLOT"<=NVL(:B6,:B5) AND "T"."ORIG_REFLOT">=NVL(:B5,:B6)))
 127 - access("T"."REFDOSS"="C"."REFDOSS" AND "C"."REFLOT"=:B7)
 128 - filter(("FI"."TYPE"<>'SAF CN COMP' AND "FI"."TYPE"<>'DRAFT' AND "FI"."TYPE"<>'NON MATCHED PAYMENT ELEMENTS' AND
              "FI"."TYPE"<>'POSITIVE LTL DECLARED PAYMENTS' AND "FI"."TYPE"<>'ANNULATION DAVOIRS PAR DES REGLEMENTS' AND "FI"."TYPE"<>'OPERATION
              DIVERSE CREDITRICE' AND "FI"."TYPE"<>'ANNULATION ODC' AND "FI"."TYPE"<>'OPERATION DIVERSE DEBITRICE' AND "FI"."TYPE"<>'ANNULATION ODD'))
 129 - access("FI"."REFELEM"="T"."REFELEM")
 130 - filter("VE"."CESSION"='O')
 131 - access("VE"."TYPE"="FI"."TYPE")
       filter(("VE"."TYPE"<>'SAF CN COMP' AND "VE"."TYPE"<>'DRAFT' AND "VE"."TYPE"<>'NON MATCHED PAYMENT ELEMENTS' AND
              "VE"."TYPE"<>'POSITIVE LTL DECLARED PAYMENTS' AND "VE"."TYPE"<>'ANNULATION DAVOIRS PAR DES REGLEMENTS' AND "VE"."TYPE"<>'OPERATION
              DIVERSE CREDITRICE' AND "VE"."TYPE"<>'ANNULATION ODC' AND "VE"."TYPE"<>'OPERATION DIVERSE DEBITRICE' AND "VE"."TYPE"<>'ANNULATION ODD'))
 132 - access("F"."TYPPIECE"='FACTURE' AND "F"."GPIHEURE"="FI"."REFELEM")
       filter("F"."GPIHEURE" IS NOT NULL)
 133 - filter(((:B3 IS NULL AND DECODE(:B12,'AF',"F"."DT02","T"."DTJOUR")<=NVL(:B2,DECODE(:B12,'AF',"F"."DT02","T"."DTJOUR")) AND
              DECODE(:B12,'AF',"F"."DT02","T"."DTJOUR")<=NVL(:B1,DECODE(:B12,'AF',"F"."DT02","T"."DTJOUR"))) OR
              ('CESS'||DECODE("T"."CODECR",'PRIN','INV','DPRIN','INV','ANN')||DECODE(:B12,'AF',"F"."GPIDEPOT")=:B3 AND
              DECODE(:B12,'AF',"F"."DT02","T"."DTJOUR")=NVL(:B2,DECODE(:B12,'AF',"F"."DT02","T"."DTJOUR")) AND
              DECODE(:B12,'AF',"F"."DT02","T"."DTJOUR")=NVL(:B1,DECODE(:B12,'AF',"F"."DT02","T"."DTJOUR")))))
 136 - filter(NVL(SUM("T"."MNT_DCPT"),0)<>0)
 138 - filter((NVL(:B6,:B5)>=NVL(:B5,:B6) AND NVL(:B14,TO_NUMBER(:B13))>=TO_NUMBER(NVL(:B13,TO_CHAR(:B14))) AND (:B10='N' OR :B11='O')))
 144 - filter(("MD"."REFPIECE">=NVL(:B5,:B6) AND "MD"."REFPIECE"<=NVL(:B6,:B5)))
 145 - access("MD"."REFDOSS"=:B7 AND "MD"."TYPPIECE"='MEMO_DECOMPTE' AND "MD"."DT10">=TO_NUMBER(NVL(:B13,TO_CHAR(:B14))) AND
              "MD"."DT10"<=NVL(:B14,TO_NUMBER(:B13)))
 147 - access("C"."REFLOT"=:B7)
 148 - filter((((:B3 IS NULL AND "T"."DTJOUR"<=NVL(:B2,"T"."DTJOUR") AND "T"."DTJOUR"<=NVL(:B1,"T"."DTJOUR")) OR ("T"."CODECR"=:B3 AND
              "T"."DTJOUR"=NVL(:B2,"T"."DTJOUR") AND "T"."DTJOUR"=NVL(:B1,"T"."DTJOUR"))) AND "T"."ORIG_REFLOT"="MD"."REFPIECE" AND
              "T"."ORIG_REFLOT"<=NVL(:B6,:B5) AND "T"."ORIG_REFLOT">=NVL(:B5,:B6)))
 149 - access("T"."REFDOSS"="C"."REFDOSS" AND "T"."TYPELEM"='f')
       filter(("T"."CODECR"='ADPRI' OR "T"."CODECR"='APRIN' OR "T"."CODECR"='DPRIN' OR "T"."CODECR"='PRIN'))
 150 - filter(("FI"."TYPE"<>'SAF CN COMP' AND "FI"."TYPE"<>'DRAFT' AND "FI"."TYPE"<>'NON MATCHED PAYMENT ELEMENTS' AND
              "FI"."TYPE"<>'POSITIVE LTL DECLARED PAYMENTS' AND "FI"."TYPE"<>'ANNULATION DAVOIRS PAR DES REGLEMENTS' AND "FI"."TYPE"<>'OPERATION
              DIVERSE CREDITRICE' AND "FI"."TYPE"<>'ANNULATION ODC' AND "FI"."TYPE"<>'OPERATION DIVERSE DEBITRICE' AND "FI"."TYPE"<>'ANNULATION ODD'))
 151 - access("FI"."REFELEM"="T"."REFELEM")
 152 - access("VE"."TYPE"="FI"."TYPE")
       filter(("VE"."TYPE"<>'SAF CN COMP' AND "VE"."TYPE"<>'DRAFT' AND "VE"."TYPE"<>'NON MATCHED PAYMENT ELEMENTS' AND
              "VE"."TYPE"<>'POSITIVE LTL DECLARED PAYMENTS' AND "VE"."TYPE"<>'ANNULATION DAVOIRS PAR DES REGLEMENTS' AND "VE"."TYPE"<>'OPERATION
              DIVERSE CREDITRICE' AND "VE"."TYPE"<>'ANNULATION ODC' AND "VE"."TYPE"<>'OPERATION DIVERSE DEBITRICE' AND "VE"."TYPE"<>'ANNULATION ODD'))
 153 - filter(NVL("VE"."CESSION",'N')='N')
 156 - filter(NVL(SUM("T"."MNT_DCPT"),0)<>0)
 158 - filter((NVL(:B6,:B5)>=NVL(:B5,:B6) AND NVL(:B14,TO_NUMBER(:B13))>=TO_NUMBER(NVL(:B13,TO_CHAR(:B14))) AND :B10='N'))
 162 - filter(("MD"."REFPIECE">=NVL(:B5,:B6) AND "MD"."REFPIECE"<=NVL(:B6,:B5)))
 163 - access("MD"."REFDOSS"=:B7 AND "MD"."TYPPIECE"='MEMO_DECOMPTE' AND "MD"."DT10">=TO_NUMBER(NVL(:B13,TO_CHAR(:B14))) AND
              "MD"."DT10"<=NVL(:B14,TO_NUMBER(:B13)))
 165 - access("C"."REFLOT"=:B7)
 167 - access("T"."REFDOSS"="C"."REFDOSS" AND (("T"."CODECR"='ADCON' OR "T"."CODECR"='DCONV')))
 168 - filter((((:B3 IS NULL AND "T"."DTINTER"<=NVL(:B1,"T"."DTINTER") AND "T"."DTJOUR"<=NVL(:B2,"T"."DTJOUR")) OR ("T"."CODECR"=:B3 AND
              "T"."DTJOUR"=NVL(:B2,"T"."DTJOUR") AND "T"."DTINTER"=NVL(:B1,"T"."DTINTER"))) AND "T"."ORIG_REFLOT"="MD"."REFPIECE" AND
              "T"."ORIG_REFLOT"<=NVL(:B6,:B5) AND "T"."ORIG_REFLOT">=NVL(:B5,:B6)))
 170 - filter(NVL(:B6,:B5)>=NVL(:B5,:B6))
 171 - filter((((:B3 IS NULL AND TO_NUMBER(TO_CHAR(INTERNAL_FUNCTION("ARCH"."MAX_ARCH_TRANS_DATE"),'j'))<=NVL(:B2,TO_NUMBER(TO_CHAR(INTER
              NAL_FUNCTION("ARCH"."MAX_ARCH_TRANS_DATE"),'j'))) AND TO_NUMBER(TO_CHAR(INTERNAL_FUNCTION("ARCH"."MAX_ARCH_VALUE_DATE"),'j'))<=NVL(:B1,TO
              _NUMBER(TO_CHAR(INTERNAL_FUNCTION("ARCH"."MAX_ARCH_VALUE_DATE"),'j')))) OR (:B3='ARCHBAL' AND
              TO_NUMBER(TO_CHAR(INTERNAL_FUNCTION("ARCH"."MAX_ARCH_TRANS_DATE"),'j'))=NVL(:B2,TO_NUMBER(TO_CHAR(INTERNAL_FUNCTION("ARCH"."MAX_ARCH_TRAN
              S_DATE"),'j'))) AND TO_NUMBER(TO_CHAR(INTERNAL_FUNCTION("ARCH"."MAX_ARCH_VALUE_DATE"),'j'))=NVL(:B1,TO_NUMBER(TO_CHAR(INTERNAL_FUNCTION("
              ARCH"."MAX_ARCH_VALUE_DATE"),'j'))))) AND "ARCH"."MAX_MEMO_DECOMPTE">=NVL(:B5,:B6) AND "ARCH"."MAX_MEMO_DECOMPTE"<=NVL(:B6,:B5)))
 172 - access("REFDOSS"=:B7 AND "TYPE_BALANCE"='CCA')
 173 - filter(:B10='N')
 178 - filter(ROWNUM<:B23)
 180 - filter((((:B3 IS NULL AND "DTEXTRAIT"<=NVL(:B2,"DTEXTRAIT") AND
              TO_NUMBER(TO_CHAR(INTERNAL_FUNCTION("DT_RECONCILIATION_DT"),'j'))<=NVL(:B1,TO_NUMBER(TO_CHAR(INTERNAL_FUNCTION("DT_RECONCILIATION_DT"),'j
              ')))) OR (:B3='encEPS' AND "DTEXTRAIT"=NVL(:B2,"DTEXTRAIT") AND TO_NUMBER(TO_CHAR(INTERNAL_FUNCTION("DT_RECONCILIATION_DT"),'j'))=NVL(:B1
              ,TO_NUMBER(TO_CHAR(INTERNAL_FUNCTION("DT_RECONCILIATION_DT"),'j'))))) AND NVL("MONTANT",0)<>0))

*/
/********************************OLD Metrics***************************************/

/********************************New SQL*******************************************/

SELECT REFELEM REFELEM,
       REFDOSS REFDOSS_DCMP,
       CODECR CODECR,
       TRUNC(DTJOUR_DT) TRANSACTION_DT,
       TRUNC(DTINTER_DT) VALUE_DT,
       DECODE(SIGN(SUM(MNT_DCPT)), 1, SUM(MNT_DCPT)) DEBIT_DCMP,
       DECODE(SIGN(SUM(MNT_DCPT)), -1, ABS(SUM(MNT_DCPT))) CREDIT_DCMP,
       MAX(LIBELLE) LABEL,
       1 NB,
       (SELECT DISTINCT FIRST_VALUE(PF_LIB_TRAD) OVER(ORDER BY PF_REFFACTOR NULLS LAST)
          FROM V_FPARFAC
         WHERE PF_NOM = T.CODECR
           AND (PF_REFFACTOR IS NULL OR PF_REFFACTOR = :B4)
           AND LANGUE = :B8) LABEL_DESC,
       DECODE(T.CODECR,
              'VDIS',
              (SELECT FI.REFEXT
                 FROM F_DETFAC DF, G_ELEMFI FI
                WHERE DF.DF_NUM = T.REFELEM
                  AND FI.REFELEM = DF.DF_REFINIT)) REFEXT,
       NULL RETENTIONINDIC,
       MAX(DECODE(LENGTH(T.MEMO_DECOMPTE), 8, T.MEMO_DECOMPTE, NULL)) MEMO_DECOMPTE
  FROM T_ECRDOS T, F_PARFAC PF
 WHERE T.REFDOSS = :B7
   AND T.MEMO_DECOMPTE BETWEEN NVL(:B5, :B6) AND NVL(:B6, :B5)
   AND T.CODECR = PF.PF_NOM
   AND (PF.PF_REFFACTOR = :B4 OR PF.PF_REFFACTOR IS NULL AND NOT EXISTS
        (SELECT 1
           FROM F_PARFAC
          WHERE PF_NOM = PF.PF_NOM
            AND PF_REFFACTOR = :B4))
   AND T.CODECR NOT IN ('IND', 'RIND', 'RINDS', 'CRINS')
   AND (:B3 IS NULL AND T.DTJOUR <= NVL(:B2, T.DTJOUR) AND
       T.DTINTER <= NVL(:B1, T.DTINTER) OR
       :B3 = CODECR AND T.DTJOUR = NVL(:B2, T.DTJOUR) AND
       T.DTINTER = NVL(:B1, T.DTINTER))
 GROUP BY REFELEM, REFDOSS, CODECR, TRUNC(DTJOUR_DT), TRUNC(DTINTER_DT)
HAVING NVL(SUM(MNT_DCPT), 0) <> 0
UNION ALL
SELECT DF.DF_NUM REFELEM,
       DF.DF_DOS REFDOSS_DCMP,
       DF.DF_NOM CODECR,
       TRUNC(DF.DF_DAT_DT) TRANSACTION_DT,
       TRUNC(DF.F_DT_TRAITE_DT) VALUE_DT,
       DECODE(SIGN(DECODE(DF.DF_NOM, D.ABREV, 1, 'L' || D.ABREV, -1) *
                   DF.DF_MONTTC_MVT),
              1,
              DECODE(DF.DF_NOM, D.ABREV, 1, 'L' || D.ABREV, -1) *
              DF.DF_MONTTC_MVT) DEBIT_DCMP,
       DECODE(SIGN(DECODE(DF.DF_NOM, D.ABREV, 1, 'L' || D.ABREV, -1) *
                   DF.DF_MONTTC_MVT),
              -1,
              ABS(DECODE(DF.DF_NOM, D.ABREV, 1, 'L' || D.ABREV, -1) *
                  DF.DF_MONTTC_MVT)) CREDIT_DCMP,
       D.VALEUR LABEL,
       1 NB,
       (SELECT DISTINCT FIRST_VALUE(PF_LIB_TRAD) OVER(ORDER BY PF_REFFACTOR NULLS LAST)
          FROM V_FPARFAC
         WHERE PF_NOM = DF.DF_NOM
           AND (PF_REFFACTOR IS NULL OR PF_REFFACTOR = :B4)
           AND LANGUE = :B8) LABEL_DESC,
       NULL REFEXT,
       NULL RETENTIONINDIC,
       DECODE(LENGTH(DF.MEMO_DECOMPTE), 8, DF.MEMO_DECOMPTE, NULL) MEMO_DECOMPTE
  FROM F_DETFAC DF, V_DOMAINE D
 WHERE DF.DF_DOS = :B7
   AND DF.MEMO_DECOMPTE BETWEEN NVL(:B5, :B6) AND NVL(:B6, :B5)
   AND D.TYPE = 'RESERV'
   AND DF.DF_NOM IN (D.ABREV, 'L' || D.ABREV)
   AND (D.CHEMIN NOT IN ('UTILISATION_EXTERNE', 'ENCAISSEMENT') OR
       D.CHEMIN IS NULL)
   AND :B9 = 'O'
   AND (:B3 IS NULL AND DF.DF_DAT <= NVL(:B2, DF.DF_DAT) AND
       DF.F_DT_TRAITE <= NVL(:B1, DF.F_DT_TRAITE) OR
       :B3 = DF.DF_NOM AND DF.DF_DAT = NVL(:B2, DF.DF_DAT) AND
       DF.F_DT_TRAITE = NVL(:B1, DF.F_DT_TRAITE))
UNION ALL
SELECT REFELEM,
       REFDOSS_DCMP,
       CODECR,
       TRANSACTION_DT,
       VALUE_DT,
       DEBIT_DCMP,
       CREDIT_DCMP,
       LABEL,
       NB,
       (SELECT IMX.FTRANSLATE_STR(LABEL, :B8, CODECR) FROM DUAL) LABEL_DESC,
       REFEXT,
       RETENTIONINDIC,
       MEMO_DECOMPTE
  FROM (SELECT REFELEM REFELEM,
               REFDOSS REFDOSS_DCMP,
               CODECR CODECR,
               TRUNC(DTJOUR_DT) TRANSACTION_DT,
               TRUNC(DTINTER_DT) VALUE_DT,
               DECODE(SIGN(NVL(SUM(CLDEPOT_DOS), 0)),
                      -1,
                      ABS(SUM(CLDEPOT_DOS))) DEBIT_DCMP,
               DECODE(SIGN(NVL(SUM(CLDEPOT_DOS), 0)), 1, SUM(CLDEPOT_DOS)) CREDIT_DCMP,
               MAX(LIBELLE) LABEL,
               1 NB,
               NULL REFEXT,
               NULL RETENTIONINDIC,
               MAX(DECODE(LENGTH(MEMO_DECOMPTE), 8, MEMO_DECOMPTE, NULL)) MEMO_DECOMPTE
          FROM T_ECRDOS
         WHERE REFDOSS = :B7
           AND MEMO_DECOMPTE BETWEEN NVL(:B5, :B6) AND NVL(:B6, :B5)
           AND CODECR = 'PMTDB'
           AND REFLIEN IS NOT NULL
           AND REFCREANCE IS NOT NULL
           AND (:B3 IS NULL AND DTJOUR <= NVL(:B2, DTJOUR) AND
               DTINTER <= NVL(:B1, DTINTER) OR
               :B3 = CODECR AND DTJOUR = NVL(:B2, DTJOUR) AND
               DTINTER = NVL(:B1, DTINTER))
           AND :B10 = 'N'
         GROUP BY REFELEM,
                  REFDOSS,
                  CODECR,
                  TRUNC(DTJOUR_DT),
                  TRUNC(DTINTER_DT)
        HAVING NVL(SUM(CLDEPOT_DOS), 0) <> 0)
UNION ALL
SELECT REFELEM,
       REFDOSS_DCMP,
       CODECR,
       TRANSACTION_DT,
       VALUE_DT,
       DEBIT_DCMP,
       CREDIT_DCMP,
       LABEL,
       NB,
       (SELECT IMX.FTRANSLATE_STR(LABEL, :B8, CODECR) FROM DUAL) LABEL_DESC,
       REFEXT,
       RETENTIONINDIC,
       MEMO_DECOMPTE
  FROM (SELECT DECODE(TYPELEM, 'Z', REFEXT, REFELEM) REFELEM,
               REFDOSS REFDOSS_DCMP,
               DECODE(TYPELEM, 'Z', TYPE, CODECR) CODECR,
               TRUNC(DTJOUR_DT) TRANSACTION_DT,
               TRUNC(DTINTER_DT) VALUE_DT,
               SUM(DECODE(CODECR,
                          'KCRED',
                          DBDU_DOS,
                          DECODE(TYPELEM, 'Z', DBDU_DOS))) DEBIT_DCMP,
               SUM(DECODE(CODECR,
                          'ANRED',
                          DBDU_DOS,
                          DECODE(TYPELEM, 'Z', DBDEDUC_DOS))) CREDIT_DCMP,
               MAX(LIBELLE) LABEL,
               1 NB,
               NULL REFEXT,
               NULL RETENTIONINDIC,
               MAX(DECODE(LENGTH(MEMO_DECOMPTE), 8, MEMO_DECOMPTE, NULL)) MEMO_DECOMPTE
          FROM T_ECRDOS
         WHERE REFDOSS = :B7
           AND MEMO_DECOMPTE BETWEEN NVL(:B5, :B6) AND NVL(:B6, :B5)
           AND CODECR IN ('KCRED',
                          'ANRED',
                          'CTRET',
                          'CRRET',
                          'FCITB',
                          'RFCTB',
                          'FNCTB',
                          'RFNCB')
           AND (:B3 IS NULL AND DTJOUR <= NVL(:B2, DTJOUR) AND
               DTINTER <= NVL(:B1, DTINTER) OR
               :B3 = DECODE(TYPELEM, 'Z', TYPE, CODECR) AND
               DTJOUR = NVL(:B2, DTJOUR) AND DTINTER = NVL(:B1, DTINTER))
         GROUP BY DECODE(TYPELEM, 'Z', REFEXT, REFELEM),
                  REFDOSS,
                  DECODE(TYPELEM, 'Z', TYPE, CODECR),
                  TRUNC(DTJOUR_DT),
                  TRUNC(DTINTER_DT)
        HAVING NVL(SUM(NVL(DBDU_DOS, DBDEDUC_DOS)), 0) <> 0)
UNION ALL
SELECT REFELEM,
       REFDOSS_DCMP,
       CODECR,
       TRANSACTION_DT,
       VALUE_DT,
       DEBIT_DCMP,
       CREDIT_DCMP,
       LABEL,
       NB,
       CASE
         WHEN :B3 IS NULL AND T_ECRDOS_CODECR IN ('PRIN', 'DPRIN') THEN
          :B16
         WHEN :B3 IS NULL AND T_ECRDOS_CODECR IN ('APRIN', 'ADPRI') THEN
          :B15
         ELSE
          (SELECT IMX.FTRANSLATE_STR(LABEL, :B8, T_ECRDOS_CODECR) FROM DUAL)
       END LABEL_DESC,
       REFEXT,
       RETENTIONINDIC,
       MEMO_DECOMPTE
  FROM (SELECT /*+ index (md PIE_REFDOSS)*/
         T.REFELEM REFELEM,
         C.REFLOT REFDOSS_DCMP,
         'CESS' || DECODE(T.CODECR, 'PRIN', 'INV', 'DPRIN', 'INV', 'ANN') ||
         DECODE(:B12, 'AF', F.GPIDEPOT) CODECR,
         DECODE(:B12, 'AF', TRUNC(F.DT02_DT), TRUNC(T.DTJOUR_DT)) TRANSACTION_DT,
         DECODE(:B12, 'AF', TRUNC(F.DT02_DT), TRUNC(T.DTJOUR_DT)) VALUE_DT,
         DECODE(SIGN(SUM(T.MNT_DCPT)), -1, ABS(SUM(T.MNT_DCPT))) DEBIT_DCMP,
         DECODE(SIGN(SUM(T.MNT_DCPT)), 1, SUM(T.MNT_DCPT)) CREDIT_DCMP,
         MAX(T.LIBELLE) LABEL,
         1 NB,
         T.CODECR T_ECRDOS_CODECR,
         MAX(FI.REFEXT) REFEXT,
         NULL RETENTIONINDIC,
         MAX(DECODE(LENGTH(T.ORIG_REFLOT), 8, T.ORIG_REFLOT, NULL)) MEMO_DECOMPTE
          FROM G_PIECE   MD,
               G_DOSSIER C,
               T_ECRDOS  T,
               G_ELEMFI  FI,
               V_ELEMFI  VE,
               G_PIECE   F
         WHERE MD.REFDOSS = :B7
           AND MD.TYPPIECE = 'MEMO_DECOMPTE'
           AND MD.DT10 BETWEEN NVL(:B13, :B14) AND NVL(:B14, :B13)
           AND MD.REFPIECE BETWEEN NVL(:B5, :B6) AND NVL(:B6, :B5)
           AND C.REFLOT = MD.REFDOSS
           AND T.REFDOSS = C.REFDOSS
           AND T.ORIG_REFLOT = MD.REFPIECE
           AND T.TYPELEM = 'f'
           AND T.CODECR IN ('PRIN', 'APRIN', 'DPRIN', 'ADPRI')
           AND FI.REFELEM = T.REFELEM
           AND VE.TYPE = FI.TYPE
           AND VE.CESSION = 'O'
           AND VE.TYPE NOT IN ('SAF CN COMP',
                               'DRAFT',
                               'NON MATCHED PAYMENT ELEMENTS',
                               'POSITIVE LTL DECLARED PAYMENTS',
                               'ANNULATION DAVOIRS PAR DES REGLEMENTS',
                               'OPERATION DIVERSE CREDITRICE',
                               'ANNULATION ODC',
                               'OPERATION DIVERSE DEBITRICE',
                               'ANNULATION ODD')
           AND F.GPIHEURE = FI.REFELEM
           AND F.TYPPIECE = 'FACTURE'
           AND (:B3 IS NULL AND
               DECODE(:B12, 'AF', F.DT02, T.DTJOUR) <=
               NVL(:B2, DECODE(:B12, 'AF', F.DT02, T.DTJOUR)) AND
               DECODE(:B12, 'AF', F.DT02, T.DTJOUR) <=
               NVL(:B1, DECODE(:B12, 'AF', F.DT02, T.DTJOUR)) OR
               :B3 = 'CESS' ||
               DECODE(T.CODECR, 'PRIN', 'INV', 'DPRIN', 'INV', 'ANN') ||
               DECODE(:B12, 'AF', F.GPIDEPOT) AND
               DECODE(:B12, 'AF', F.DT02, T.DTJOUR) =
               NVL(:B2, DECODE(:B12, 'AF', F.DT02, T.DTJOUR)) AND
               DECODE(:B12, 'AF', F.DT02, T.DTJOUR) =
               NVL(:B1, DECODE(:B12, 'AF', F.DT02, T.DTJOUR)))
           AND (:B10 = 'N' OR :B11 = 'O')
         GROUP BY T.REFELEM,
                  F.GPIDEPOT,
                  C.REFLOT,
                  T.CODECR,
                  TRUNC(F.DT02_DT),
                  TRUNC(T.DTJOUR_DT)
        HAVING NVL(SUM(T.MNT_DCPT), 0) <> 0)
UNION ALL
SELECT REFELEM,
       REFDOSS_DCMP,
       CODECR,
       TRANSACTION_DT,
       VALUE_DT,
       DEBIT_DCMP,
       CREDIT_DCMP,
       LABEL,
       NB,
       CASE
         WHEN :B3 IS NULL AND CODECR = 'PRIN' THEN
          :B20
         WHEN :B3 IS NULL AND CODECR = 'APRIN' THEN
          :B19
         WHEN :B3 IS NULL AND CODECR = 'DPRIN' THEN
          :B18
         WHEN :B3 IS NULL AND CODECR = 'ADPRI' THEN
          :B17
         ELSE
          (SELECT IMX.FTRANSLATE_STR(LABEL, :B8, CODECR) FROM DUAL)
       END LABEL_DESC,
       REFEXT,
       RETENTIONINDIC,
       MEMO_DECOMPTE
  FROM (SELECT /*+ index (md PIE_REFDOSS) index (T T_ECRDOS$ORIG_REFLOT) */
         T.REFELEM REFELEM,
         C.REFLOT REFDOSS_DCMP,
         T.CODECR CODECR,
         TRUNC(T.DTJOUR_DT) TRANSACTION_DT,
         TRUNC(T.DTJOUR_DT) VALUE_DT,
         DECODE(SIGN(SUM(T.MNT_DCPT)), -1, ABS(SUM(T.MNT_DCPT))) DEBIT_DCMP,
         DECODE(SIGN(SUM(T.MNT_DCPT)), 1, SUM(T.MNT_DCPT)) CREDIT_DCMP,
         MAX(T.LIBELLE) LABEL,
         1 NB,
         MAX(FI.REFEXT) REFEXT,
         NULL RETENTIONINDIC,
         MAX(DECODE(LENGTH(T.ORIG_REFLOT), 8, T.ORIG_REFLOT, NULL)) MEMO_DECOMPTE
          FROM G_PIECE MD, G_DOSSIER C, T_ECRDOS T, G_ELEMFI FI, V_ELEMFI VE
         WHERE MD.REFDOSS = :B7
           AND MD.TYPPIECE = 'MEMO_DECOMPTE'
           AND MD.DT10 BETWEEN NVL(:B13, :B14) AND NVL(:B14, :B13)
           AND MD.REFPIECE BETWEEN NVL(:B5, :B6) AND NVL(:B6, :B5)
           AND C.REFLOT = MD.REFDOSS
           AND T.REFDOSS = C.REFDOSS
           AND T.ORIG_REFLOT = MD.REFPIECE
           AND T.TYPELEM = 'f'
           AND T.CODECR IN ('PRIN', 'APRIN', 'DPRIN', 'ADPRI')
           AND FI.REFELEM = T.REFELEM
           AND VE.TYPE = FI.TYPE
           AND NVL(VE.CESSION, 'N') = 'N'
           AND VE.TYPE NOT IN ('SAF CN COMP',
                               'DRAFT',
                               'NON MATCHED PAYMENT ELEMENTS',
                               'POSITIVE LTL DECLARED PAYMENTS',
                               'ANNULATION DAVOIRS PAR DES REGLEMENTS',
                               'OPERATION DIVERSE CREDITRICE',
                               'ANNULATION ODC',
                               'OPERATION DIVERSE DEBITRICE',
                               'ANNULATION ODD')
           AND (:B3 IS NULL AND T.DTJOUR <= NVL(:B2, T.DTJOUR) AND
               T.DTJOUR <= NVL(:B1, T.DTJOUR) OR
               :B3 = T.CODECR AND T.DTJOUR = NVL(:B2, T.DTJOUR) AND
               T.DTJOUR = NVL(:B1, T.DTJOUR))
           AND (:B10 = 'N' OR :B11 = 'O')
         GROUP BY T.REFELEM, C.REFLOT, T.CODECR, TRUNC(T.DTJOUR_DT)
        HAVING NVL(SUM(T.MNT_DCPT), 0) <> 0)
UNION ALL
SELECT REFELEM,
       REFDOSS_DCMP,
       CODECR,
       TRANSACTION_DT,
       VALUE_DT,
       DEBIT_DCMP,
       CREDIT_DCMP,
       LABEL,
       NB,
       (SELECT IMX.FTRANSLATE_STR(LABEL, :B8, CODECR) FROM DUAL) LABEL_DESC,
       REFEXT,
       RETENTIONINDIC,
       MEMO_DECOMPTE
  FROM (SELECT /*+ index (md PIE_REFDOSS)*/
         T.REFELEM REFELEM,
         C.REFLOT REFDOSS_DCMP,
         T.CODECR CODECR,
         TRUNC(T.DTJOUR_DT) TRANSACTION_DT,
         TRUNC(T.DTINTER_DT) VALUE_DT,
         DECODE(SIGN(NVL(SUM(T.MNT_DCPT), 0)), -1, ABS(SUM(T.MNT_DCPT))) DEBIT_DCMP,
         DECODE(SIGN(NVL(SUM(T.MNT_DCPT), 0)), 1, SUM(T.MNT_DCPT)) CREDIT_DCMP,
         MAX(T.LIBELLE) LABEL,
         1 NB,
         NULL REFEXT,
         NULL RETENTIONINDIC,
         MAX(DECODE(LENGTH(T.ORIG_REFLOT), 8, T.ORIG_REFLOT, NULL)) MEMO_DECOMPTE
          FROM G_PIECE MD, G_DOSSIER C, T_ECRDOS T
         WHERE MD.REFDOSS = :B7
           AND MD.TYPPIECE = 'MEMO_DECOMPTE'
           AND MD.DT10 BETWEEN NVL(:B13, :B14) AND NVL(:B14, :B13)
           AND MD.REFPIECE BETWEEN NVL(:B5, :B6) AND NVL(:B6, :B5)
           AND C.REFLOT = MD.REFDOSS
           AND T.REFDOSS = C.REFDOSS
           AND T.ORIG_REFLOT = MD.REFPIECE
           AND T.CODECR IN ('DCONV', 'ADCON')
           AND (:B3 IS NULL AND T.DTJOUR <= NVL(:B2, T.DTJOUR) AND
               T.DTINTER <= NVL(:B1, T.DTINTER) OR
               :B3 = T.CODECR AND T.DTJOUR = NVL(:B2, T.DTJOUR) AND
               T.DTINTER = NVL(:B1, T.DTINTER))
           AND :B10 = 'N'
         GROUP BY T.REFELEM,
                  C.REFLOT,
                  T.CODECR,
                  TRUNC(T.DTJOUR_DT),
                  TRUNC(T.DTINTER_DT)
        HAVING NVL(SUM(T.MNT_DCPT), 0) <> 0)
UNION ALL
SELECT REFELEM,
       REFDOSS_DCMP,
       CODECR,
       TRANSACTION_DT,
       VALUE_DT,
       DEBIT_DCMP,
       CREDIT_DCMP,
       LABEL,
       NB,
       (SELECT IMX.FTRANSLATE_STR(LABEL, :B8, CODECR) FROM DUAL) LABEL_DESC,
       REFEXT,
       RETENTIONINDIC,
       MEMO_DECOMPTE
  FROM (SELECT ARCH.MAX_ARCH_TRANS_DATE TRANSACTION_DT,
               ARCH.MAX_ARCH_VALUE_DATE VALUE_DT,
               ARCH.ARCH_COUNTER NB,
               'ARCHIVED CCA BALANCE' LABEL,
               DECODE(SIGN(ARCH.AMOUNT_ARCH_PART_BAL),
                      -1,
                      ABS(ARCH.AMOUNT_ARCH_PART_BAL)) CREDIT_DCMP,
               DECODE(SIGN(ARCH.AMOUNT_ARCH_PART_BAL),
                      1,
                      ARCH.AMOUNT_ARCH_PART_BAL) DEBIT_DCMP,
               NULL REFELEM,
               ARCH.REFDOSS REFDOSS_DCMP,
               'ARCHBAL' CODECR,
               NULL REFEXT,
               NULL RETENTIONINDIC,
               ARCH.MAX_MEMO_DECOMPTE MEMO_DECOMPTE
          FROM T_ARCH_DCPT_BALANCES ARCH
         WHERE TYPE_BALANCE = 'CCA'
           AND REFDOSS = :B7
           AND (:B3 IS NULL AND
               TO_CHAR(ARCH.MAX_ARCH_TRANS_DATE, 'j') <=
               NVL(:B2, TO_CHAR(ARCH.MAX_ARCH_TRANS_DATE, 'j')) AND
               TO_CHAR(ARCH.MAX_ARCH_VALUE_DATE, 'j') <=
               NVL(:B1, TO_CHAR(ARCH.MAX_ARCH_VALUE_DATE, 'j')) OR
               :B3 = 'ARCHBAL' AND
               TO_CHAR(ARCH.MAX_ARCH_TRANS_DATE, 'j') =
               NVL(:B2, TO_CHAR(ARCH.MAX_ARCH_TRANS_DATE, 'j')) AND
               TO_CHAR(ARCH.MAX_ARCH_VALUE_DATE, 'j') =
               NVL(:B1, TO_CHAR(ARCH.MAX_ARCH_VALUE_DATE, 'j')))
           AND ARCH.MAX_MEMO_DECOMPTE BETWEEN NVL(:B5, :B6) AND
               NVL(:B6, :B5))
UNION ALL
SELECT COMPOSTAGE REFELEM,
       REFDOSS REFDOSS_DCMP,
       'encEPS' CODECR,
       TRUNC(DTEXTRAIT_DT) TRANSACTION_DT,
       TRUNC(DT_RECONCILIATION_DT) VALUE_DT,
       ABS(DECODE(SIGNE,
                  1,
                  CASE
                    WHEN MONTANT_MVT IS NOT NULL AND DEVISE_MVT = :B22 THEN
                     MONTANT_MVT
                    WHEN MONTANT_MVT_BQ IS NOT NULL AND DEVISE_MVT_BQ = :B22 THEN
                     MONTANT_MVT_BQ
                    WHEN MONTANT3 IS NOT NULL AND DEVISE3 = :B22 THEN
                     MONTANT3
                    WHEN DEVISE = :B22 THEN
                     NVL(MONTANT, 0)
                    ELSE
                     CH_TAUX.CONVERSMVTDOS(DTEXTRAIT,
                                           REFDOSS,
                                           NVL(MONTANT, 0),
                                           DEVISE,
                                           'A')
                  END)) DEBIT_DCMP,
       ABS(DECODE(SIGNE,
                  0,
                  CASE
                    WHEN MONTANT_MVT IS NOT NULL AND DEVISE_MVT = :B22 THEN
                     MONTANT_MVT
                    WHEN MONTANT_MVT_BQ IS NOT NULL AND DEVISE_MVT_BQ = :B22 THEN
                     MONTANT_MVT_BQ
                    WHEN MONTANT3 IS NOT NULL AND DEVISE3 = :B22 THEN
                     MONTANT3
                    WHEN DEVISE = :B22 THEN
                     NVL(MONTANT, 0)
                    ELSE
                     CH_TAUX.CONVERSMVTDOS(DTEXTRAIT,
                                           REFDOSS,
                                           NVL(MONTANT, 0),
                                           DEVISE,
                                           'A')
                  END)) CREDIT_DCMP,
       NULL LABEL,
       1 NB,
       :B21 LABEL_DESC,
       NULL REFEXT,
       NULL RETENTIONINDIC,
       DECODE(LENGTH(MEMO_DECOMPTE), 8, MEMO_DECOMPTE, NULL) MEMO_DECOMPTE
  FROM NAM_COLLECTE
 WHERE ROWID IN (SELECT /*+ cardinality(5) */
                  COLUMN_VALUE
                   FROM TABLE(FTR_FIU.FIUROWIDLIST_EPSPMT(:B7,
                                                          :B6,
                                                          NULL,
                                                          :B1,
                                                          NULL,
                                                          :B2,
                                                          :B5))
                  WHERE ROWNUM < :B23)
   AND NVL(MONTANT, 0) != 0
   AND (:B3 IS NULL AND DTEXTRAIT <= NVL(:B2, DTEXTRAIT) AND
       TO_CHAR(DT_RECONCILIATION_DT, 'j') <=
       NVL(:B1, TO_CHAR(DT_RECONCILIATION_DT, 'j')) OR
       :B3 = 'encEPS' AND DTEXTRAIT = NVL(:B2, DTEXTRAIT) AND
       TO_CHAR(DT_RECONCILIATION_DT, 'j') =
       NVL(:B1, TO_CHAR(DT_RECONCILIATION_DT, 'j')))
   AND :B10 = 'N';
/********************************New SQL*******************************************/
/********************************New Metrics***************************************/
/*
Plan hash value: 3785912020
----------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                      | Name                        | Starts | E-Rows | A-Rows |   A-Time   | Buffers |
----------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                               |                             |      1 |        |      0 |00:00:00.01 |     605 |
|   1 |  UNION-ALL                                     |                             |      1 |        |      0 |00:00:00.01 |     605 |
|   2 |   SORT UNIQUE                                  |                             |      0 |      1 |      0 |00:00:00.01 |       0 |
|   3 |    WINDOW SORT                                 |                             |      0 |      1 |      0 |00:00:00.01 |       0 |
|   4 |     VIEW                                       | V_FPARFAC                   |      0 |     11 |      0 |00:00:00.01 |       0 |
|   5 |      UNION-ALL                                 |                             |      0 |        |      0 |00:00:00.01 |       0 |
|*  6 |       FILTER                                   |                             |      0 |        |      0 |00:00:00.01 |       0 |
|   7 |        TABLE ACCESS BY INDEX ROWID BATCHED     | F_PARFAC                    |      0 |      1 |      0 |00:00:00.01 |       0 |
|*  8 |         INDEX RANGE SCAN                       | PARFAC_CL1                  |      0 |      1 |      0 |00:00:00.01 |       0 |
|*  9 |       FILTER                                   |                             |      0 |        |      0 |00:00:00.01 |       0 |
|  10 |        TABLE ACCESS BY INDEX ROWID BATCHED     | F_PARFAC                    |      0 |      1 |      0 |00:00:00.01 |       0 |
|* 11 |         INDEX RANGE SCAN                       | PARFAC_CL1                  |      0 |      1 |      0 |00:00:00.01 |       0 |
|* 12 |       FILTER                                   |                             |      0 |        |      0 |00:00:00.01 |       0 |
|  13 |        TABLE ACCESS BY INDEX ROWID BATCHED     | F_PARFAC                    |      0 |      1 |      0 |00:00:00.01 |       0 |
|* 14 |         INDEX RANGE SCAN                       | PARFAC_CL1                  |      0 |      1 |      0 |00:00:00.01 |       0 |
|* 15 |       FILTER                                   |                             |      0 |        |      0 |00:00:00.01 |       0 |
|  16 |        TABLE ACCESS BY INDEX ROWID BATCHED     | F_PARFAC                    |      0 |      1 |      0 |00:00:00.01 |       0 |
|* 17 |         INDEX RANGE SCAN                       | PARFAC_CL1                  |      0 |      1 |      0 |00:00:00.01 |       0 |
|* 18 |       FILTER                                   |                             |      0 |        |      0 |00:00:00.01 |       0 |
|  19 |        TABLE ACCESS BY INDEX ROWID BATCHED     | F_PARFAC                    |      0 |      1 |      0 |00:00:00.01 |       0 |
|* 20 |         INDEX RANGE SCAN                       | PARFAC_CL1                  |      0 |      1 |      0 |00:00:00.01 |       0 |
|* 21 |       FILTER                                   |                             |      0 |        |      0 |00:00:00.01 |       0 |
|  22 |        TABLE ACCESS BY INDEX ROWID BATCHED     | F_PARFAC                    |      0 |      1 |      0 |00:00:00.01 |       0 |
|* 23 |         INDEX RANGE SCAN                       | PARFAC_CL1                  |      0 |      1 |      0 |00:00:00.01 |       0 |
|* 24 |       FILTER                                   |                             |      0 |        |      0 |00:00:00.01 |       0 |
|  25 |        TABLE ACCESS BY INDEX ROWID BATCHED     | F_PARFAC                    |      0 |      1 |      0 |00:00:00.01 |       0 |
|* 26 |         INDEX RANGE SCAN                       | PARFAC_CL1                  |      0 |      1 |      0 |00:00:00.01 |       0 |
|* 27 |       FILTER                                   |                             |      0 |        |      0 |00:00:00.01 |       0 |
|  28 |        TABLE ACCESS BY INDEX ROWID BATCHED     | F_PARFAC                    |      0 |      1 |      0 |00:00:00.01 |       0 |
|* 29 |         INDEX RANGE SCAN                       | PARFAC_CL1                  |      0 |      1 |      0 |00:00:00.01 |       0 |
|* 30 |       FILTER                                   |                             |      0 |        |      0 |00:00:00.01 |       0 |
|  31 |        TABLE ACCESS BY INDEX ROWID BATCHED     | F_PARFAC                    |      0 |      1 |      0 |00:00:00.01 |       0 |
|* 32 |         INDEX RANGE SCAN                       | PARFAC_CL1                  |      0 |      1 |      0 |00:00:00.01 |       0 |
|* 33 |       FILTER                                   |                             |      0 |        |      0 |00:00:00.01 |       0 |
|  34 |        TABLE ACCESS BY INDEX ROWID BATCHED     | F_PARFAC                    |      0 |      1 |      0 |00:00:00.01 |       0 |
|* 35 |         INDEX RANGE SCAN                       | PARFAC_CL1                  |      0 |      1 |      0 |00:00:00.01 |       0 |
|* 36 |       FILTER                                   |                             |      0 |        |      0 |00:00:00.01 |       0 |
|  37 |        TABLE ACCESS BY INDEX ROWID BATCHED     | F_PARFAC                    |      0 |      1 |      0 |00:00:00.01 |       0 |
|* 38 |         INDEX RANGE SCAN                       | PARFAC_CL1                  |      0 |      1 |      0 |00:00:00.01 |       0 |
|  39 |   NESTED LOOPS                                 |                             |      0 |      1 |      0 |00:00:00.01 |       0 |
|  40 |    NESTED LOOPS                                |                             |      0 |      1 |      0 |00:00:00.01 |       0 |
|  41 |     TABLE ACCESS BY INDEX ROWID BATCHED        | F_DETFAC                    |      0 |      1 |      0 |00:00:00.01 |       0 |
|* 42 |      INDEX RANGE SCAN                          | DETFAC_NUM                  |      0 |      1 |      0 |00:00:00.01 |       0 |
|* 43 |     INDEX UNIQUE SCAN                          | EFI_REFELEM                 |      0 |      1 |      0 |00:00:00.01 |       0 |
|  44 |    TABLE ACCESS BY INDEX ROWID                 | G_ELEMFI                    |      0 |      1 |      0 |00:00:00.01 |       0 |
|* 45 |   FILTER                                       |                             |      1 |        |      0 |00:00:00.01 |       4 |
|  46 |    HASH GROUP BY                               |                             |      1 |      1 |      0 |00:00:00.01 |       4 |
|* 47 |     FILTER                                     |                             |      1 |        |      0 |00:00:00.01 |       4 |
|* 48 |      FILTER                                    |                             |      1 |        |      0 |00:00:00.01 |       4 |
|  49 |       NESTED LOOPS                             |                             |      1 |      1 |      0 |00:00:00.01 |       4 |
|* 50 |        TABLE ACCESS BY INDEX ROWID BATCHED     | T_ECRDOS                    |      1 |      1 |      0 |00:00:00.01 |       4 |
|* 51 |         INDEX RANGE SCAN                       | T_ECRDOS_MEMO_IDX           |      1 |      1 |      0 |00:00:00.01 |       4 |
|* 52 |        INDEX RANGE SCAN                        | PARFAC_CL1                  |      0 |      1 |      0 |00:00:00.01 |       0 |
|* 53 |      INDEX UNIQUE SCAN                         | PARFAC_CL1                  |      0 |      1 |      0 |00:00:00.01 |       0 |
|  54 |   SORT UNIQUE                                  |                             |      0 |      1 |      0 |00:00:00.01 |       0 |
|  55 |    WINDOW SORT                                 |                             |      0 |      1 |      0 |00:00:00.01 |       0 |
|  56 |     VIEW                                       | V_FPARFAC                   |      0 |     11 |      0 |00:00:00.01 |       0 |
|  57 |      UNION-ALL                                 |                             |      0 |        |      0 |00:00:00.01 |       0 |
|* 58 |       FILTER                                   |                             |      0 |        |      0 |00:00:00.01 |       0 |
|  59 |        TABLE ACCESS BY INDEX ROWID BATCHED     | F_PARFAC                    |      0 |      1 |      0 |00:00:00.01 |       0 |
|* 60 |         INDEX RANGE SCAN                       | PARFAC_CL1                  |      0 |      1 |      0 |00:00:00.01 |       0 |
|* 61 |       FILTER                                   |                             |      0 |        |      0 |00:00:00.01 |       0 |
|  62 |        TABLE ACCESS BY INDEX ROWID BATCHED     | F_PARFAC                    |      0 |      1 |      0 |00:00:00.01 |       0 |
|* 63 |         INDEX RANGE SCAN                       | PARFAC_CL1                  |      0 |      1 |      0 |00:00:00.01 |       0 |
|* 64 |       FILTER                                   |                             |      0 |        |      0 |00:00:00.01 |       0 |
|  65 |        TABLE ACCESS BY INDEX ROWID BATCHED     | F_PARFAC                    |      0 |      1 |      0 |00:00:00.01 |       0 |
|* 66 |         INDEX RANGE SCAN                       | PARFAC_CL1                  |      0 |      1 |      0 |00:00:00.01 |       0 |
|* 67 |       FILTER                                   |                             |      0 |        |      0 |00:00:00.01 |       0 |
|  68 |        TABLE ACCESS BY INDEX ROWID BATCHED     | F_PARFAC                    |      0 |      1 |      0 |00:00:00.01 |       0 |
|* 69 |         INDEX RANGE SCAN                       | PARFAC_CL1                  |      0 |      1 |      0 |00:00:00.01 |       0 |
|* 70 |       FILTER                                   |                             |      0 |        |      0 |00:00:00.01 |       0 |
|  71 |        TABLE ACCESS BY INDEX ROWID BATCHED     | F_PARFAC                    |      0 |      1 |      0 |00:00:00.01 |       0 |
|* 72 |         INDEX RANGE SCAN                       | PARFAC_CL1                  |      0 |      1 |      0 |00:00:00.01 |       0 |
|* 73 |       FILTER                                   |                             |      0 |        |      0 |00:00:00.01 |       0 |
|  74 |        TABLE ACCESS BY INDEX ROWID BATCHED     | F_PARFAC                    |      0 |      1 |      0 |00:00:00.01 |       0 |
|* 75 |         INDEX RANGE SCAN                       | PARFAC_CL1                  |      0 |      1 |      0 |00:00:00.01 |       0 |
|* 76 |       FILTER                                   |                             |      0 |        |      0 |00:00:00.01 |       0 |
|  77 |        TABLE ACCESS BY INDEX ROWID BATCHED     | F_PARFAC                    |      0 |      1 |      0 |00:00:00.01 |       0 |
|* 78 |         INDEX RANGE SCAN                       | PARFAC_CL1                  |      0 |      1 |      0 |00:00:00.01 |       0 |
|* 79 |       FILTER                                   |                             |      0 |        |      0 |00:00:00.01 |       0 |
|  80 |        TABLE ACCESS BY INDEX ROWID BATCHED     | F_PARFAC                    |      0 |      1 |      0 |00:00:00.01 |       0 |
|* 81 |         INDEX RANGE SCAN                       | PARFAC_CL1                  |      0 |      1 |      0 |00:00:00.01 |       0 |
|* 82 |       FILTER                                   |                             |      0 |        |      0 |00:00:00.01 |       0 |
|  83 |        TABLE ACCESS BY INDEX ROWID BATCHED     | F_PARFAC                    |      0 |      1 |      0 |00:00:00.01 |       0 |
|* 84 |         INDEX RANGE SCAN                       | PARFAC_CL1                  |      0 |      1 |      0 |00:00:00.01 |       0 |
|* 85 |       FILTER                                   |                             |      0 |        |      0 |00:00:00.01 |       0 |
|  86 |        TABLE ACCESS BY INDEX ROWID BATCHED     | F_PARFAC                    |      0 |      1 |      0 |00:00:00.01 |       0 |
|* 87 |         INDEX RANGE SCAN                       | PARFAC_CL1                  |      0 |      1 |      0 |00:00:00.01 |       0 |
|* 88 |       FILTER                                   |                             |      0 |        |      0 |00:00:00.01 |       0 |
|  89 |        TABLE ACCESS BY INDEX ROWID BATCHED     | F_PARFAC                    |      0 |      1 |      0 |00:00:00.01 |       0 |
|* 90 |         INDEX RANGE SCAN                       | PARFAC_CL1                  |      0 |      1 |      0 |00:00:00.01 |       0 |
|* 91 |   FILTER                                       |                             |      1 |        |      0 |00:00:00.01 |       0 |
|  92 |    NESTED LOOPS                                |                             |      0 |      1 |      0 |00:00:00.01 |       0 |
|  93 |     NESTED LOOPS                               |                             |      0 |      1 |      0 |00:00:00.01 |       0 |
|* 94 |      TABLE ACCESS BY INDEX ROWID BATCHED       | F_DETFAC                    |      0 |      1 |      0 |00:00:00.01 |       0 |
|* 95 |       INDEX RANGE SCAN                         | IDX_DETFAC_DCPT             |      0 |      1 |      0 |00:00:00.01 |       0 |
|* 96 |      INDEX RANGE SCAN                          | DOM_TYPABREV                |      0 |      1 |      0 |00:00:00.01 |       0 |
|* 97 |     TABLE ACCESS BY INDEX ROWID                | V_DOMAINE                   |      0 |      1 |      0 |00:00:00.01 |       0 |
|  98 |   FAST DUAL                                    |                             |      0 |      1 |      0 |00:00:00.01 |       0 |
|  99 |   VIEW                                         |                             |      1 |      1 |      0 |00:00:00.01 |       4 |
|*100 |    FILTER                                      |                             |      1 |        |      0 |00:00:00.01 |       4 |
| 101 |     HASH GROUP BY                              |                             |      1 |      1 |      0 |00:00:00.01 |       4 |
|*102 |      FILTER                                    |                             |      1 |        |      0 |00:00:00.01 |       4 |
|*103 |       TABLE ACCESS BY INDEX ROWID BATCHED      | T_ECRDOS                    |      1 |      1 |      0 |00:00:00.01 |       4 |
|*104 |        INDEX RANGE SCAN                        | T_ECRDOS_MEMO_IDX           |      1 |      1 |      0 |00:00:00.01 |       4 |
| 105 |   FAST DUAL                                    |                             |      0 |      1 |      0 |00:00:00.01 |       0 |
| 106 |   VIEW                                         |                             |      1 |      1 |      0 |00:00:00.01 |       4 |
|*107 |    FILTER                                      |                             |      1 |        |      0 |00:00:00.01 |       4 |
| 108 |     HASH GROUP BY                              |                             |      1 |      1 |      0 |00:00:00.01 |       4 |
|*109 |      FILTER                                    |                             |      1 |        |      0 |00:00:00.01 |       4 |
|*110 |       TABLE ACCESS BY INDEX ROWID BATCHED      | T_ECRDOS                    |      1 |      1 |      0 |00:00:00.01 |       4 |
|*111 |        INDEX RANGE SCAN                        | T_ECRDOS_MEMO_IDX           |      1 |      1 |      0 |00:00:00.01 |       4 |
| 112 |   FAST DUAL                                    |                             |      0 |      1 |      0 |00:00:00.01 |       0 |
| 113 |   VIEW                                         |                             |      1 |      1 |      0 |00:00:00.01 |      10 |
|*114 |    FILTER                                      |                             |      1 |        |      0 |00:00:00.01 |      10 |
| 115 |     HASH GROUP BY                              |                             |      1 |      1 |      0 |00:00:00.01 |      10 |
|*116 |      FILTER                                    |                             |      1 |        |      0 |00:00:00.01 |      10 |
| 117 |       NESTED LOOPS                             |                             |      1 |      1 |      0 |00:00:00.01 |      10 |
| 118 |        NESTED LOOPS                            |                             |      1 |      1 |      0 |00:00:00.01 |      10 |
| 119 |         NESTED LOOPS                           |                             |      1 |      1 |      0 |00:00:00.01 |      10 |
| 120 |          NESTED LOOPS                          |                             |      1 |      1 |      0 |00:00:00.01 |      10 |
| 121 |           NESTED LOOPS                         |                             |      1 |      1 |      0 |00:00:00.01 |      10 |
| 122 |            NESTED LOOPS                        |                             |      1 |      1 |      0 |00:00:00.01 |      10 |
|*123 |             TABLE ACCESS BY INDEX ROWID BATCHED| G_PIECE                     |      1 |      1 |      1 |00:00:00.01 |       6 |
|*124 |              INDEX RANGE SCAN                  | PIE_REFDOSS                 |      1 |      1 |      2 |00:00:00.01 |       4 |
|*125 |             TABLE ACCESS BY INDEX ROWID BATCHED| T_ECRDOS                    |      1 |      1 |      0 |00:00:00.01 |       4 |
|*126 |              INDEX RANGE SCAN                  | T_ECRDOS$ORIG_REFLOT        |      1 |     12 |      0 |00:00:00.01 |       4 |
|*127 |            INDEX RANGE SCAN                    | DOS_REFDOSS_REFLOT_IDX      |      0 |      1 |      0 |00:00:00.01 |       0 |
|*128 |           TABLE ACCESS BY INDEX ROWID          | G_ELEMFI                    |      0 |      1 |      0 |00:00:00.01 |       0 |
|*129 |            INDEX UNIQUE SCAN                   | EFI_REFELEM                 |      0 |      1 |      0 |00:00:00.01 |       0 |
|*130 |          TABLE ACCESS BY INDEX ROWID BATCHED   | V_ELEMFI                    |      0 |      1 |      0 |00:00:00.01 |       0 |
|*131 |           INDEX RANGE SCAN                     | VF_TYPE_FINANCING           |      0 |      1 |      0 |00:00:00.01 |       0 |
|*132 |         INDEX RANGE SCAN                       | GP_GRTYPE_MT_DT             |      0 |      1 |      0 |00:00:00.01 |       0 |
|*133 |        TABLE ACCESS BY INDEX ROWID             | G_PIECE                     |      0 |      1 |      0 |00:00:00.01 |       0 |
| 134 |   FAST DUAL                                    |                             |      0 |      1 |      0 |00:00:00.01 |       0 |
| 135 |   VIEW                                         |                             |      1 |      1 |      0 |00:00:00.01 |      10 |
|*136 |    FILTER                                      |                             |      1 |        |      0 |00:00:00.01 |      10 |
| 137 |     HASH GROUP BY                              |                             |      1 |      1 |      0 |00:00:00.01 |      10 |
|*138 |      FILTER                                    |                             |      1 |        |      0 |00:00:00.01 |      10 |
| 139 |       NESTED LOOPS                             |                             |      1 |      1 |      0 |00:00:00.01 |      10 |
| 140 |        NESTED LOOPS                            |                             |      1 |      1 |      0 |00:00:00.01 |      10 |
| 141 |         NESTED LOOPS                           |                             |      1 |      1 |      0 |00:00:00.01 |      10 |
| 142 |          NESTED LOOPS                          |                             |      1 |      1 |      0 |00:00:00.01 |      10 |
| 143 |           NESTED LOOPS                         |                             |      1 |      1 |      0 |00:00:00.01 |      10 |
|*144 |            TABLE ACCESS BY INDEX ROWID BATCHED | G_PIECE                     |      1 |      1 |      1 |00:00:00.01 |       6 |
|*145 |             INDEX RANGE SCAN                   | PIE_REFDOSS                 |      1 |      1 |      2 |00:00:00.01 |       4 |
|*146 |            TABLE ACCESS BY INDEX ROWID BATCHED | T_ECRDOS                    |      1 |      1 |      0 |00:00:00.01 |       4 |
|*147 |             INDEX RANGE SCAN                   | T_ECRDOS$ORIG_REFLOT        |      1 |     12 |      0 |00:00:00.01 |       4 |
|*148 |           INDEX RANGE SCAN                     | DOS_REFDOSS_REFLOT_IDX      |      0 |      1 |      0 |00:00:00.01 |       0 |
|*149 |          TABLE ACCESS BY INDEX ROWID           | G_ELEMFI                    |      0 |      1 |      0 |00:00:00.01 |       0 |
|*150 |           INDEX UNIQUE SCAN                    | EFI_REFELEM                 |      0 |      1 |      0 |00:00:00.01 |       0 |
|*151 |         INDEX RANGE SCAN                       | VF_TYPE_FINANCING           |      0 |      1 |      0 |00:00:00.01 |       0 |
|*152 |        TABLE ACCESS BY INDEX ROWID             | V_ELEMFI                    |      0 |      1 |      0 |00:00:00.01 |       0 |
| 153 |   FAST DUAL                                    |                             |      0 |      1 |      0 |00:00:00.01 |       0 |
| 154 |   VIEW                                         |                             |      1 |      1 |      0 |00:00:00.01 |     568 |
|*155 |    FILTER                                      |                             |      1 |        |      0 |00:00:00.01 |     568 |
| 156 |     HASH GROUP BY                              |                             |      1 |      1 |      0 |00:00:00.01 |     568 |
|*157 |      FILTER                                    |                             |      1 |        |      0 |00:00:00.01 |     568 |
| 158 |       NESTED LOOPS                             |                             |      1 |      1 |      0 |00:00:00.01 |     568 |
| 159 |        NESTED LOOPS                            |                             |      1 |      6 |      0 |00:00:00.01 |     568 |
| 160 |         MERGE JOIN CARTESIAN                   |                             |      1 |      1 |    143 |00:00:00.01 |      10 |
|*161 |          TABLE ACCESS BY INDEX ROWID BATCHED   | G_PIECE                     |      1 |      1 |      1 |00:00:00.01 |       6 |
|*162 |           INDEX RANGE SCAN                     | PIE_REFDOSS                 |      1 |      1 |      2 |00:00:00.01 |       4 |
| 163 |          BUFFER SORT                           |                             |      1 |    120 |    143 |00:00:00.01 |       4 |
|*164 |           INDEX RANGE SCAN                     | G_DOSSIER_RL_CD_RD_RF_IDX   |      1 |    120 |    143 |00:00:00.01 |       4 |
| 165 |         INLIST ITERATOR                        |                             |    143 |        |      0 |00:00:00.01 |     558 |
|*166 |          INDEX RANGE SCAN                      | TECR$REFDOSS_CODECR_DTINTER |    286 |      6 |      0 |00:00:00.01 |     558 |
|*167 |        TABLE ACCESS BY INDEX ROWID             | T_ECRDOS                    |      0 |      1 |      0 |00:00:00.01 |       0 |
| 168 |   FAST DUAL                                    |                             |      0 |      1 |      0 |00:00:00.01 |       0 |
|*169 |   FILTER                                       |                             |      1 |        |      0 |00:00:00.01 |       1 |
|*170 |    TABLE ACCESS BY INDEX ROWID                 | T_ARCH_DCPT_BALANCES        |      1 |      1 |      0 |00:00:00.01 |       1 |
|*171 |     INDEX UNIQUE SCAN                          | PK_ARCH_DCPT_BALANCES       |      1 |      1 |      0 |00:00:00.01 |       1 |
|*172 |   FILTER                                       |                             |      1 |        |      0 |00:00:00.01 |       4 |
| 173 |    NESTED LOOPS                                |                             |      1 |     75 |      0 |00:00:00.01 |       4 |
| 174 |     SORT UNIQUE                                |                             |      1 |      5 |      0 |00:00:00.01 |       4 |
| 175 |      VIEW                                      | VW_NSO_1                    |      1 |      5 |      0 |00:00:00.01 |       4 |
| 176 |       HASH UNIQUE                              |                             |      1 |      1 |      0 |00:00:00.01 |       4 |
|*177 |        COUNT STOPKEY                           |                             |      1 |        |      0 |00:00:00.01 |       4 |
| 178 |         COLLECTION ITERATOR PICKLER FETCH      | FIUROWIDLIST_EPSPMT         |      1 |   8168 |      0 |00:00:00.01 |       4 |
|*179 |     TABLE ACCESS BY USER ROWID                 | NAM_COLLECTE                |      0 |     75 |      0 |00:00:00.01 |       0 |
----------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   6 - filter('AL'=:B8)
   8 - access("PF_NOM"=:B1)
       filter(("PF_REFFACTOR" IS NULL OR "PF_REFFACTOR"=:B4))
   9 - filter('AN'=:B8)
  11 - access("PF_NOM"=:B1)
       filter(("PF_REFFACTOR" IS NULL OR "PF_REFFACTOR"=:B4))
  12 - filter('DA'=:B8)
  14 - access("PF_NOM"=:B1)
       filter(("PF_REFFACTOR" IS NULL OR "PF_REFFACTOR"=:B4))
  15 - filter('ES'=:B8)
  17 - access("PF_NOM"=:B1)
       filter(("PF_REFFACTOR" IS NULL OR "PF_REFFACTOR"=:B4))
  18 - filter('FI'=:B8)
  20 - access("PF_NOM"=:B1)
       filter(("PF_REFFACTOR" IS NULL OR "PF_REFFACTOR"=:B4))
  21 - filter('FR'=:B8)
  23 - access("PF_NOM"=:B1)
       filter(("PF_REFFACTOR" IS NULL OR "PF_REFFACTOR"=:B4))
  24 - filter('HU'=:B8)
  26 - access("PF_NOM"=:B1)
       filter(("PF_REFFACTOR" IS NULL OR "PF_REFFACTOR"=:B4))
  27 - filter('IT'=:B8)
  29 - access("PF_NOM"=:B1)
       filter(("PF_REFFACTOR" IS NULL OR "PF_REFFACTOR"=:B4))
  30 - filter('NL'=:B8)
  32 - access("PF_NOM"=:B1)
       filter(("PF_REFFACTOR" IS NULL OR "PF_REFFACTOR"=:B4))
  33 - filter('NO'=:B8)
  35 - access("PF_NOM"=:B1)
       filter(("PF_REFFACTOR" IS NULL OR "PF_REFFACTOR"=:B4))
  36 - filter('PT'=:B8)
  38 - access("PF_NOM"=:B1)
       filter(("PF_REFFACTOR" IS NULL OR "PF_REFFACTOR"=:B4))
  42 - access("DF"."DF_NUM"=:B1)
  43 - access("FI"."REFELEM"="DF"."DF_REFINIT")
  45 - filter(NVL(SUM("MNT_DCPT"),0)<>0)
  47 - filter(("PF"."PF_REFFACTOR"=:B4 OR ("PF"."PF_REFFACTOR" IS NULL AND  IS NULL)))
  48 - filter(NVL(:B6,:B5)>=NVL(:B5,:B6))
  50 - filter((((:B3 IS NULL AND "T"."DTINTER"<=NVL(:B1,"T"."DTINTER") AND "T"."DTJOUR"<=NVL(:B2,"T"."DTJOUR")) OR
              ("CODECR"=:B3 AND "T"."DTJOUR"=NVL(:B2,"T"."DTJOUR") AND "T"."DTINTER"=NVL(:B1,"T"."DTINTER"))) AND "T"."CODECR"<>'IND' AND
              "T"."CODECR"<>'RIND' AND "T"."CODECR"<>'RINDS' AND "T"."CODECR"<>'CRINS'))
  51 - access("T"."REFDOSS"=:B7 AND "T"."MEMO_DECOMPTE">=NVL(:B5,:B6) AND "T"."MEMO_DECOMPTE"<=NVL(:B6,:B5))
  52 - access("CODECR"="PF"."PF_NOM")
       filter(("PF"."PF_NOM"<>'IND' AND "PF"."PF_NOM"<>'RIND' AND "PF"."PF_NOM"<>'RINDS' AND "PF"."PF_NOM"<>'CRINS'))
  53 - access("PF_NOM"=:B1 AND "PF_REFFACTOR"=:B4)
  58 - filter('AL'=:B8)
  60 - access("PF_NOM"=:B1)
       filter(("PF_REFFACTOR" IS NULL OR "PF_REFFACTOR"=:B4))
  61 - filter('AN'=:B8)
  63 - access("PF_NOM"=:B1)
       filter(("PF_REFFACTOR" IS NULL OR "PF_REFFACTOR"=:B4))
  64 - filter('DA'=:B8)
  66 - access("PF_NOM"=:B1)
       filter(("PF_REFFACTOR" IS NULL OR "PF_REFFACTOR"=:B4))
  67 - filter('ES'=:B8)
  69 - access("PF_NOM"=:B1)
       filter(("PF_REFFACTOR" IS NULL OR "PF_REFFACTOR"=:B4))
  70 - filter('FI'=:B8)
  72 - access("PF_NOM"=:B1)
       filter(("PF_REFFACTOR" IS NULL OR "PF_REFFACTOR"=:B4))
  73 - filter('FR'=:B8)
  75 - access("PF_NOM"=:B1)
       filter(("PF_REFFACTOR" IS NULL OR "PF_REFFACTOR"=:B4))
  76 - filter('HU'=:B8)
  78 - access("PF_NOM"=:B1)
       filter(("PF_REFFACTOR" IS NULL OR "PF_REFFACTOR"=:B4))
  79 - filter('IT'=:B8)
  81 - access("PF_NOM"=:B1)
       filter(("PF_REFFACTOR" IS NULL OR "PF_REFFACTOR"=:B4))
  82 - filter('NL'=:B8)
  84 - access("PF_NOM"=:B1)
       filter(("PF_REFFACTOR" IS NULL OR "PF_REFFACTOR"=:B4))
  85 - filter('NO'=:B8)
  87 - access("PF_NOM"=:B1)
       filter(("PF_REFFACTOR" IS NULL OR "PF_REFFACTOR"=:B4))
  88 - filter('PT'=:B8)
  90 - access("PF_NOM"=:B1)
       filter(("PF_REFFACTOR" IS NULL OR "PF_REFFACTOR"=:B4))
  91 - filter((NVL(:B6,:B5)>=NVL(:B5,:B6) AND :B9='O'))
  94 - filter(((:B3 IS NULL AND "DF"."F_DT_TRAITE"<=NVL(:B1,"DF"."F_DT_TRAITE") AND "DF"."DF_DAT"<=NVL(:B2,"DF"."DF_DAT")) OR
              ("DF"."DF_NOM"=:B3 AND "DF"."DF_DAT"=NVL(:B2,"DF"."DF_DAT") AND "DF"."F_DT_TRAITE"=NVL(:B1,"DF"."F_DT_TRAITE"))))
  95 - access("DF"."DF_DOS"=:B7 AND "DF"."MEMO_DECOMPTE">=NVL(:B5,:B6) AND "DF"."MEMO_DECOMPTE"<=NVL(:B6,:B5))
  96 - access("D"."TYPE"='RESERV')
       filter((("DF"."DF_NOM"="D"."ABREV" AND "D"."ABREV" IS NOT NULL) OR "DF"."DF_NOM"='L'||"D"."ABREV"))
  97 - filter(("D"."CHEMIN" IS NULL OR ("D"."CHEMIN"<>'UTILISATION_EXTERNE' AND "D"."CHEMIN"<>'ENCAISSEMENT')))
 100 - filter(NVL(SUM("CLDEPOT_DOS"),0)<>0)
 102 - filter((NVL(:B6,:B5)>=NVL(:B5,:B6) AND :B10='N'))
 103 - filter(("REFLIEN" IS NOT NULL AND "REFCREANCE" IS NOT NULL AND "CODECR"='PMTDB' AND ((:B3 IS NULL AND
              "DTINTER"<=NVL(:B1,"DTINTER") AND "DTJOUR"<=NVL(:B2,"DTJOUR")) OR ("CODECR"=:B3 AND "DTJOUR"=NVL(:B2,"DTJOUR") AND
              "DTINTER"=NVL(:B1,"DTINTER")))))
 104 - access("REFDOSS"=:B7 AND "MEMO_DECOMPTE">=NVL(:B5,:B6) AND "MEMO_DECOMPTE"<=NVL(:B6,:B5))
 107 - filter(NVL(SUM(NVL("DBDU_DOS","DBDEDUC_DOS")),0)<>0)
 109 - filter(NVL(:B6,:B5)>=NVL(:B5,:B6))
 110 - filter((((:B3 IS NULL AND "DTINTER"<=NVL(:B1,"DTINTER") AND "DTJOUR"<=NVL(:B2,"DTJOUR")) OR ("DTJOUR"=NVL(:B2,"DTJOUR")
              AND "DTINTER"=NVL(:B1,"DTINTER") AND DECODE("TYPELEM",'Z',"TYPE","CODECR")=:B3)) AND INTERNAL_FUNCTION("CODECR")))
 111 - access("REFDOSS"=:B7 AND "MEMO_DECOMPTE">=NVL(:B5,:B6) AND "MEMO_DECOMPTE"<=NVL(:B6,:B5))
 114 - filter(NVL(SUM("T"."MNT_DCPT"),0)<>0)
 116 - filter((NVL(:B6,:B5)>=NVL(:B5,:B6) AND NVL(:B14,TO_NUMBER(:B13))>=TO_NUMBER(NVL(:B13,TO_CHAR(:B14))) AND (:B10='N' OR
              :B11='O')))
 123 - filter(("MD"."REFPIECE">=NVL(:B5,:B6) AND "MD"."REFPIECE"<=NVL(:B6,:B5)))
 124 - access("MD"."REFDOSS"=:B7 AND "MD"."TYPPIECE"='MEMO_DECOMPTE' AND "MD"."DT10">=TO_NUMBER(NVL(:B13,TO_CHAR(:B14))) AND
              "MD"."DT10"<=NVL(:B14,TO_NUMBER(:B13)))
 125 - filter(("T"."TYPELEM"='f' AND INTERNAL_FUNCTION("T"."CODECR")))
 126 - access("T"."ORIG_REFLOT"="MD"."REFPIECE")
       filter(("T"."ORIG_REFLOT"<=NVL(:B6,:B5) AND "T"."ORIG_REFLOT">=NVL(:B5,:B6)))
 127 - access("T"."REFDOSS"="C"."REFDOSS" AND "C"."REFLOT"=:B7)
 128 - filter(("FI"."TYPE"<>'SAF CN COMP' AND "FI"."TYPE"<>'DRAFT' AND "FI"."TYPE"<>'NON MATCHED PAYMENT ELEMENTS' AND
              "FI"."TYPE"<>'POSITIVE LTL DECLARED PAYMENTS' AND "FI"."TYPE"<>'ANNULATION DAVOIRS PAR DES REGLEMENTS' AND
              "FI"."TYPE"<>'OPERATION DIVERSE CREDITRICE' AND "FI"."TYPE"<>'ANNULATION ODC' AND "FI"."TYPE"<>'OPERATION DIVERSE DEBITRICE'
              AND "FI"."TYPE"<>'ANNULATION ODD'))
 129 - access("FI"."REFELEM"="T"."REFELEM")
 130 - filter("VE"."CESSION"='O')
 131 - access("VE"."TYPE"="FI"."TYPE")
       filter(("VE"."TYPE"<>'SAF CN COMP' AND "VE"."TYPE"<>'DRAFT' AND "VE"."TYPE"<>'NON MATCHED PAYMENT ELEMENTS' AND
              "VE"."TYPE"<>'POSITIVE LTL DECLARED PAYMENTS' AND "VE"."TYPE"<>'ANNULATION DAVOIRS PAR DES REGLEMENTS' AND
              "VE"."TYPE"<>'OPERATION DIVERSE CREDITRICE' AND "VE"."TYPE"<>'ANNULATION ODC' AND "VE"."TYPE"<>'OPERATION DIVERSE DEBITRICE'
              AND "VE"."TYPE"<>'ANNULATION ODD'))
 132 - access("F"."TYPPIECE"='FACTURE' AND "F"."GPIHEURE"="FI"."REFELEM")
       filter("F"."GPIHEURE" IS NOT NULL)
 133 - filter(((:B3 IS NULL AND DECODE(:B12,'AF',"F"."DT02","T"."DTJOUR")<=NVL(:B2,DECODE(:B12,'AF',"F"."DT02","T"."DTJOUR"))
              AND DECODE(:B12,'AF',"F"."DT02","T"."DTJOUR")<=NVL(:B1,DECODE(:B12,'AF',"F"."DT02","T"."DTJOUR"))) OR
              ('CESS'||DECODE("T"."CODECR",'PRIN','INV','DPRIN','INV','ANN')||DECODE(:B12,'AF',"F"."GPIDEPOT")=:B3 AND
              DECODE(:B12,'AF',"F"."DT02","T"."DTJOUR")=NVL(:B2,DECODE(:B12,'AF',"F"."DT02","T"."DTJOUR")) AND
              DECODE(:B12,'AF',"F"."DT02","T"."DTJOUR")=NVL(:B1,DECODE(:B12,'AF',"F"."DT02","T"."DTJOUR")))))
 136 - filter(NVL(SUM("T"."MNT_DCPT"),0)<>0)
 138 - filter((NVL(:B6,:B5)>=NVL(:B5,:B6) AND NVL(:B14,TO_NUMBER(:B13))>=TO_NUMBER(NVL(:B13,TO_CHAR(:B14))) AND (:B10='N' OR
              :B11='O')))
 144 - filter(("MD"."REFPIECE">=NVL(:B5,:B6) AND "MD"."REFPIECE"<=NVL(:B6,:B5)))
 145 - access("MD"."REFDOSS"=:B7 AND "MD"."TYPPIECE"='MEMO_DECOMPTE' AND "MD"."DT10">=TO_NUMBER(NVL(:B13,TO_CHAR(:B14))) AND
              "MD"."DT10"<=NVL(:B14,TO_NUMBER(:B13)))
 146 - filter(("T"."TYPELEM"='f' AND ((:B3 IS NULL AND "T"."DTJOUR"<=NVL(:B2,"T"."DTJOUR") AND
              "T"."DTJOUR"<=NVL(:B1,"T"."DTJOUR")) OR ("T"."CODECR"=:B3 AND "T"."DTJOUR"=NVL(:B2,"T"."DTJOUR") AND
              "T"."DTJOUR"=NVL(:B1,"T"."DTJOUR"))) AND INTERNAL_FUNCTION("T"."CODECR")))
 147 - access("T"."ORIG_REFLOT"="MD"."REFPIECE")
       filter(("T"."ORIG_REFLOT"<=NVL(:B6,:B5) AND "T"."ORIG_REFLOT">=NVL(:B5,:B6)))
 148 - access("T"."REFDOSS"="C"."REFDOSS" AND "C"."REFLOT"=:B7)
 149 - filter(("FI"."TYPE"<>'SAF CN COMP' AND "FI"."TYPE"<>'DRAFT' AND "FI"."TYPE"<>'NON MATCHED PAYMENT ELEMENTS' AND
              "FI"."TYPE"<>'POSITIVE LTL DECLARED PAYMENTS' AND "FI"."TYPE"<>'ANNULATION DAVOIRS PAR DES REGLEMENTS' AND
              "FI"."TYPE"<>'OPERATION DIVERSE CREDITRICE' AND "FI"."TYPE"<>'ANNULATION ODC' AND "FI"."TYPE"<>'OPERATION DIVERSE DEBITRICE'
              AND "FI"."TYPE"<>'ANNULATION ODD'))
 150 - access("FI"."REFELEM"="T"."REFELEM")
 151 - access("VE"."TYPE"="FI"."TYPE")
       filter(("VE"."TYPE"<>'SAF CN COMP' AND "VE"."TYPE"<>'DRAFT' AND "VE"."TYPE"<>'NON MATCHED PAYMENT ELEMENTS' AND
              "VE"."TYPE"<>'POSITIVE LTL DECLARED PAYMENTS' AND "VE"."TYPE"<>'ANNULATION DAVOIRS PAR DES REGLEMENTS' AND
              "VE"."TYPE"<>'OPERATION DIVERSE CREDITRICE' AND "VE"."TYPE"<>'ANNULATION ODC' AND "VE"."TYPE"<>'OPERATION DIVERSE DEBITRICE'
              AND "VE"."TYPE"<>'ANNULATION ODD'))
 152 - filter(NVL("VE"."CESSION",'N')='N')
 155 - filter(NVL(SUM("T"."MNT_DCPT"),0)<>0)
 157 - filter((NVL(:B6,:B5)>=NVL(:B5,:B6) AND NVL(:B14,TO_NUMBER(:B13))>=TO_NUMBER(NVL(:B13,TO_CHAR(:B14))) AND :B10='N'))
 161 - filter(("MD"."REFPIECE">=NVL(:B5,:B6) AND "MD"."REFPIECE"<=NVL(:B6,:B5)))
 162 - access("MD"."REFDOSS"=:B7 AND "MD"."TYPPIECE"='MEMO_DECOMPTE' AND "MD"."DT10">=TO_NUMBER(NVL(:B13,TO_CHAR(:B14))) AND
              "MD"."DT10"<=NVL(:B14,TO_NUMBER(:B13)))
 164 - access("C"."REFLOT"=:B7)
 166 - access("T"."REFDOSS"="C"."REFDOSS" AND (("T"."CODECR"='ADCON' OR "T"."CODECR"='DCONV')))
 167 - filter((((:B3 IS NULL AND "T"."DTINTER"<=NVL(:B1,"T"."DTINTER") AND "T"."DTJOUR"<=NVL(:B2,"T"."DTJOUR")) OR
              ("T"."CODECR"=:B3 AND "T"."DTJOUR"=NVL(:B2,"T"."DTJOUR") AND "T"."DTINTER"=NVL(:B1,"T"."DTINTER"))) AND
              "T"."ORIG_REFLOT"="MD"."REFPIECE" AND "T"."ORIG_REFLOT"<=NVL(:B6,:B5) AND "T"."ORIG_REFLOT">=NVL(:B5,:B6)))
 169 - filter(NVL(:B6,:B5)>=NVL(:B5,:B6))
 170 - filter((((:B3 IS NULL AND TO_NUMBER(TO_CHAR(INTERNAL_FUNCTION("ARCH"."MAX_ARCH_TRANS_DATE"),'j'))<=NVL(:B2,TO_NUMBER(TO_C
              HAR(INTERNAL_FUNCTION("ARCH"."MAX_ARCH_TRANS_DATE"),'j'))) AND TO_NUMBER(TO_CHAR(INTERNAL_FUNCTION("ARCH"."MAX_ARCH_VALUE_DATE")
              ,'j'))<=NVL(:B1,TO_NUMBER(TO_CHAR(INTERNAL_FUNCTION("ARCH"."MAX_ARCH_VALUE_DATE"),'j')))) OR (:B3='ARCHBAL' AND
              TO_NUMBER(TO_CHAR(INTERNAL_FUNCTION("ARCH"."MAX_ARCH_TRANS_DATE"),'j'))=NVL(:B2,TO_NUMBER(TO_CHAR(INTERNAL_FUNCTION("ARCH"."MAX_
              ARCH_TRANS_DATE"),'j'))) AND TO_NUMBER(TO_CHAR(INTERNAL_FUNCTION("ARCH"."MAX_ARCH_VALUE_DATE"),'j'))=NVL(:B1,TO_NUMBER(TO_CHAR(I
              NTERNAL_FUNCTION("ARCH"."MAX_ARCH_VALUE_DATE"),'j'))))) AND "ARCH"."MAX_MEMO_DECOMPTE">=NVL(:B5,:B6) AND
              "ARCH"."MAX_MEMO_DECOMPTE"<=NVL(:B6,:B5)))
 171 - access("REFDOSS"=:B7 AND "TYPE_BALANCE"='CCA')
 172 - filter(:B10='N')
 177 - filter(ROWNUM<:B23)
 179 - filter((((:B3 IS NULL AND "DTEXTRAIT"<=NVL(:B2,"DTEXTRAIT") AND
              TO_NUMBER(TO_CHAR(INTERNAL_FUNCTION("DT_RECONCILIATION_DT"),'j'))<=NVL(:B1,TO_NUMBER(TO_CHAR(INTERNAL_FUNCTION("DT_RECONCILIATIO
              N_DT"),'j')))) OR (:B3='encEPS' AND "DTEXTRAIT"=NVL(:B2,"DTEXTRAIT") AND
              TO_NUMBER(TO_CHAR(INTERNAL_FUNCTION("DT_RECONCILIATION_DT"),'j'))=NVL(:B1,TO_NUMBER(TO_CHAR(INTERNAL_FUNCTION("DT_RECONCILIATION
              _DT"),'j'))))) AND NVL("MONTANT",0)<>0))
*/
/********************************New Metrics***************************************/

/********************************Index statistics**********************************/

/********************************Other SQLs****************************************/          
/*

*/ 
/********************************Other SQLs****************************************/              
