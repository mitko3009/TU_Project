/********************************************************************************
*********       E-mail subject: EFDE2DEV-1922
*********             Instance: PRE-PORD
*********          Description: 
Problem:
This query was provided from the BE log, where it took 26 seconds.

Analysis:
We analyzed the provided query and found that there are two main reasons for the slowness. The first reason is that it takes ~ 8 seconds for this query to be parsed. The main reason for the parse time
is the v_tdomaine. In EFDE2WEB-1105 the problem with the number of languages in v_tdomaine was discussed, so if it is expected from queries like this to spend less time in parse, the number of the languages in v_tdomaine
should be reduced or it should be made to materialized view or table. The second reason for the time is the execution. To improve the execution time, the new version of index AL_DTCREATION_IDX on table T_ALERTE should be delivered
from refbg2 to PREPROD. The new version of the index contains and column catperso in it. Also, please change the check for the date to be without TRUNC() function on
column dtcreation_dt on table T_ALERTE, which will allow the use of the index.


Suggestion:
1. Please ask DBA to deliver the new version of index AL_DTCREATION_IDX on table T_ALERTE from refbg2 to PREPROD.
2. Please ask Apps & Services team to change the query as it is shown in the New SQL section below.
3. Please discuss with the client is it possible to reduce the number of languages in V_TDOMAINE ( such discussion was already made in EFDE2WEB-1105 ) or discuss with C&D is it possible 
to make V_TDOMAINE to materialize view or table, which should help with the parse time.

*********               SQL_ID: 
*********      Program/Package: 
*********              Request: Dimitare Ivanov
*********               Author: Dimitar Dimitrov
********* Received e-mail date: 10/09/2024
*********      Resolution date: 27/09/2024
*********  Trace old file here: \\epox\specifs\performance\tmp\
*********  Trace new file here:
***********************************************************************************/

/********************************OLD SQL*******************************************/

VAR B1 VARCHAR2(32);
EXEC :B1 := 'AN';
VAR B2 VARCHAR2(32);
EXEC :B2 := 'DONT_USE';
VAR B3 VARCHAR2(32);
EXEC :B3 := 'FACTORING';
VAR B4 VARCHAR2(32);
EXEC :B4 := 'A602TXYF';
VAR B5 NUMBER;
EXEC :B5 := 3328;
VAR B6 VARCHAR2(32);
EXEC :B6 := '2024-09-10';
VAR B7 NUMBER;
EXEC :B7 := 2001;
VAR B8 NUMBER;
EXEC :B8 := 1;
 
SELECT /*+ OPT_PARAM('_optimizer_use_feedback' 'false') */
 *
  FROM (SELECT /*+ first_rows(2001)*/
         foo.*, ROWNUM rnum
          FROM (SELECT displayStage      displayStage,
                       amount            amount,
                       creator           creator,
                       contract          contract,
                       caseRefIMX        caseRefIMX,
                       creationDate      creationDate,
                       additionalDetails additionalDetails,
                       typeStage         typeStage,
                       nbAlertProcessed  nbAlertProcessed,
                       reference         reference,
                       uniqueRowId       uniqueRowId,
                       caseRef           caseRef,
                       readyToExport     readyToExport,
                       stage             stage,
                       intRef            intRef,
                       nameManager       nameManager,
                       processDate       processDate,
                       nameDebtor        nameDebtor,
                       displayTypeStage  displayTypeStage,
                       idManager         idManager,
                       currency          currency,
                       groupManager      groupManager,
                       alertId           alertId,
                       nameClient        nameClient
                  FROM (SELECT groupManager groupManager,
                               idManager idManager,
                               namemanager nameManager,
                               typestage typeStage,
                               displayTypeStage displayTypeStage,
                               stage stage,
                               displayStage displayStage,
                               caseref caseRef,
                               caseRefIMX caseRefIMX,
                               nameclient nameClient,
                               reference reference,
                               amount amount,
                               processdate processDate,
                               creationDate creationDate,
                               intref intRef,
                               CASE
                                 WHEN EXISTS
                                  (SELECT 1
                                         FROM g_dossier
                                        WHERE refdoss IN
                                              (SELECT refhierarchie
                                                 FROM g_dossier
                                                WHERE ancrefdoss = contract)
                                          AND categdoss = 'COMPTE DB CTR') THEN
                                  (SELECT ancrefdoss
                                     FROM g_dossier
                                    WHERE refdoss IN
                                          (SELECT refhierarchie
                                             FROM g_dossier
                                            WHERE ancrefdoss = t.contract)
                                      AND categdoss = 'COMPTE DB CTR')
                                 ELSE
                                  t.contract
                               END contract,
                               CASE
                                 WHEN EXISTS
                                  (SELECT 1
                                         FROM g_dossier
                                        WHERE refdoss IN
                                              (SELECT refhierarchie
                                                 FROM g_dossier
                                                WHERE ancrefdoss = contract)
                                          AND categdoss = 'COMPTE DB CTR') THEN
                                  (SELECT I.nom
                                     FROM g_individu     I,
                                          t_intervenants TI,
                                          g_dossier      D1,
                                          g_dossier      D2
                                    WHERE TI.refdoss = D1.refdoss
                                      AND D1.refdoss = D2.refhierarchie
                                      AND D2.ancrefdoss = t.contract
                                      AND D1.categdoss = 'COMPTE DB CTR'
                                      AND I.refindividu = TI.refindividu
                                      AND TI.reftype = 'DB'
                                      AND ROWNUM = 1)
                                 ELSE
                                  (SELECT I.nom
                                     FROM g_individu     I,
                                          t_intervenants TI,
                                          g_dossier      GD
                                    WHERE TI.refdoss = GD.refdoss
                                      AND GD.ancrefdoss = t.contract
                                      AND I.refindividu = TI.refindividu
                                      AND TI.reftype = 'DB'
                                      AND ROWNUM = 1)
                               END nameDebtor,
                               alerte_id alertId,
                               un_key uniqueRowId,
                               readyToExport readyToExport,
                               v.abrev_trad currency,
                               creator creator,
                               nbAlertProcessed nbAlertProcessed,
                               CASE
                                 WHEN EXISTS
                                  (SELECT 1
                                         FROM t_alert_not_es_det
                                        WHERE alerte_id = t.alerte_id) THEN
                                  (SELECT LISTAGG(valeur, '; ') WITHIN GROUP(ORDER BY order_info)
                                     FROM (SELECT v.valeur_trad || ' ' ||
                                                  td.value_info valeur,
                                                  order_info
                                             FROM t_alert_not_es_det td,
                                                  v_tdomaine         v
                                            WHERE v.type = 'DV_AGENDA_DETAILS'
                                              AND td.type_info = v.abrev
                                              AND v.langue = :B1
                                              AND td.alerte_id = t.alerte_id))
                               END additionalDetails
                          FROM (SELECT ta.ROWID un_key,
                                       NVL(vgr.valeur_trad, gp.groupe) groupManager,
                                       ta.catperso idManager,
                                       DECODE(gi.prenom,
                                              NULL,
                                              gi.nom,
                                              gi.prenom || ' ' || gi.nom) namemanager,
                                       NVL(v.valeur_trad, ta.typentite) displayTypeStage,
                                       ta.typentite typestage,
                                       ta.refentite intref,
                                       ta.refext reference,
                                       ta.refdoss caseRefIMX,
                                       ta.refctr contract,
                                       NVL(v1.valeur_trad, ta.typencour) displayStage,
                                       ta.typencour stage,
                                       ta.montant amount,
                                       ta.dttrait_dt processdate,
                                       ta.dtcreation_dt creationDate,
                                       DECODE(:B2,
                                              'C204',
                                              ta.refctr,
                                              'C405',
                                              ta.refdoss,
                                              'C202',
                                              ta.refdoss,
                                              NVL(gd.ancrefdoss, gd.refdoss)) caseref,
                                       ta.alerte_id alerte_id,
                                       ta.fg02 readyToExport,
                                       NVL(cli.nameclient, cl.nameclient) nameclient,
                                       CASE
                                         WHEN :B3 = 'FACTORING' AND
                                              gd.reffactor IS NOT NULL AND
                                              v1.place = 1 THEN
                                          ftr_fin_factor.getCurrency(gd.reffactor)
                                         WHEN v1.place = 2 THEN
                                          ta.devise_alerte
                                         ELSE
                                          NVL(gd.devise, ta.devise_alerte)
                                       END currency,
                                       CASE
                                         WHEN :B3 = 'FACTORING' THEN
                                          CASE
                                            WHEN ta.createur = 'SE' THEN
                                             NVL((SELECT valeur_trad
                                                   FROM v_tdomaine
                                                  WHERE type = 'NONSE_CREATOR'
                                                    AND abrev = 'SE'
                                                    AND langue = :B1),
                                                 ta.createur)
                                            WHEN ta.createur = 'FTR_CTRL' AND
                                                 EXISTS
                                             (SELECT 1
                                                    FROM eligib_ctrl e
                                                   WHERE e.alerte_id = ta.alerte_id) THEN
                                             NVL((SELECT valeur_trad
                                                   FROM v_tdomaine
                                                  WHERE type = 'NONSE_CREATOR'
                                                    AND abrev = 'EC'
                                                    AND langue = :B1),
                                                 ta.createur)
                                            WHEN ta.createur = 'FTR_CTRL' AND
                                                 NOT EXISTS
                                             (SELECT 1
                                                    FROM eligib_ctrl e
                                                   WHERE e.alerte_id = ta.alerte_id) THEN
                                             NVL((SELECT valeur_trad
                                                   FROM v_tdomaine
                                                  WHERE type = 'NONSE_CREATOR'
                                                    AND abrev = 'AF'
                                                    AND langue = :B1),
                                                 ta.createur)
                                            ELSE
                                             ta.createur
                                          END
                                         ELSE
                                          ta.createur
                                       END creator,
                                       ta.nb_alert_processed nbAlertProcessed
                                  FROM t_alerte ta,
                                       g_personnel gp,
                                       g_individu gi,
                                       g_dossier gd,
                                       (SELECT valeur,
                                               MAX(valeur_trad) valeur_trad
                                          FROM v_tdomaine
                                         WHERE type = 'GROUPE'
                                           AND langue = :B1
                                         GROUP BY valeur) vgr,
                                       (SELECT abrev,
                                               MAX(valeur_trad) valeur_trad
                                          FROM v_tdomaine
                                         WHERE type = 'DV_TYPE_APPEL'
                                           AND langue = :B1
                                         GROUP BY abrev) v,
                                       (SELECT valeur,
                                               MAX(valeur_trad) valeur_trad,
                                               MAX(place) place
                                          FROM v_tdomaine
                                         WHERE type = 'DV_AGENDA_NON_SE'
                                           AND langue = :B1
                                         GROUP BY valeur) v1,
                                       (SELECT /*+ merge push_pred */
                                         ti.refdoss, gi.nom nameclient
                                          FROM t_intervenants ti,
                                               g_individu     gi,
                                               v_intervenants I,
                                               v_domaine      D,
                                               g_dossier      G
                                         WHERE ti.refdoss = G.refdoss
                                           AND ti.refindividu = gi.refindividu
                                           AND I.reftype_aff = 'CLI'
                                           AND I.categdoss = D.abrev
                                           AND I.reftype_bd = ti.reftype
                                           AND D.type = 'categdoss'
                                           AND D.valeur = G.categdoss) cli,
                                       (SELECT /*+ merge push_pred */
                                         t.refdoss, i.nom nameclient
                                          FROM g_individu i, t_intervenants t
                                         WHERE i.refindividu = t.refindividu
                                           AND t.reftype = 'CL') cl
                                 WHERE ta.catperso = gp.refperso
                                   AND ta.refdoss = gd.refdoss(+)
                                   AND vgr.valeur(+) = gp.groupe
                                   AND ta.typentite = v.abrev(+)
                                   AND ta.typencour = v1.valeur(+)
                                   AND ta.refdoss = cli.refdoss(+)
                                   AND ta.refdoss = cl.refdoss(+)
                                   AND gp.refindividu = gi.refindividu
                                   AND gi.refindividu IN
                                       (SELECT gip.str1
                                          FROM g_indivparam gip
                                         WHERE gip.type = 'appel_nonse'
                                           AND gip.refindividu = :B4
                                        UNION ALL
                                        SELECT :B4
                                          FROM dual
                                        UNION ALL
                                        SELECT P.refindividu
                                          FROM g_personnel P, g_agenda A
                                         WHERE P.refrempl = :B5
                                           AND TO_CHAR(SYSDATE, 'j') = A.jour
                                           AND A.refperso = P.refperso)
                                   AND NOT EXISTS
                                 (SELECT 1
                                          FROM v_domaine
                                         WHERE type = 'DV_AGENDA_NON_SE'
                                           AND valeur = ta.typencour
                                           AND abrev6 = 'O')
                                    AND TRUNC(ta.dtcreation_dt) >= TO_DATE(TO_CHAR(to_date(:B6,'yyyy-mm-dd'), 'RRRRMMDD'),'RRRRMMDD')) t,
                               (SELECT abrev, MAX(abrev_trad) abrev_trad
                                  FROM v_tdomaine
                                 WHERE type = 'DEVISE'
                                   AND langue = :B1
                                 GROUP BY abrev) v
                         WHERE t.currency = v.abrev(+)) mca
                 WHERE 1 = 1
                 ORDER BY processDate DESC, processDate DESC) foo
         WHERE ROWNUM <= :B7)
 WHERE 1 = 1
   AND rnum >= :B8;
/********************************OLD SQL*******************************************/
/********************************OLD Metrics***************************************/
/*
-- Parse time on PREPROD

Explained.
Elapsed: 00:00:08.38


Plan hash value: 632079245
------------------------------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation					       | Name			 | Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads  |
------------------------------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT				       |			 |	1 |	   | 51388 (100)|   2001 |00:00:09.26 |     926K|   1978 |
|   1 |  VIEW						       | V_TDOMAINE		 |	1 |	36 |   144   (0)|      0 |00:00:00.01 |       3 |      0 |
|   2 |   UNION-ALL					       |			 |	1 |	   |		|      0 |00:00:00.01 |       3 |      0 |
|*  3 |    FILTER					       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
|   4 |     TABLE ACCESS BY INDEX ROWID BATCHED 	       | V_DOMAINE		 |	0 |	 1 |	 4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*  5 |      INDEX RANGE SCAN				       | DOM_TYPABREV		 |	0 |	 1 |	 3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*  6 |    FILTER					       |			 |	1 |	   |		|      0 |00:00:00.01 |       3 |      0 |
|   7 |     TABLE ACCESS BY INDEX ROWID BATCHED 	       | V_DOMAINE		 |	1 |	 1 |	 4   (0)|      0 |00:00:00.01 |       3 |      0 |
|*  8 |      INDEX RANGE SCAN				       | DOM_TYPABREV		 |	1 |	 1 |	 3   (0)|      0 |00:00:00.01 |       3 |      0 |
|*  9 |    FILTER					       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
|  10 |     TABLE ACCESS BY INDEX ROWID BATCHED 	       | V_DOMAINE		 |	0 |	 1 |	 4   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 11 |      INDEX RANGE SCAN				       | DOM_TYPABREV		 |	0 |	 1 |	 3   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 12 |    FILTER					       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
|  13 |     TABLE ACCESS BY INDEX ROWID BATCHED 	       | V_DOMAINE		 |	0 |	 1 |	 4   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 14 |      INDEX RANGE SCAN				       | DOM_TYPABREV		 |	0 |	 1 |	 3   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 15 |    FILTER					       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
|  16 |     TABLE ACCESS BY INDEX ROWID BATCHED 	       | V_DOMAINE		 |	0 |	 1 |	 4   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 17 |      INDEX RANGE SCAN				       | DOM_TYPABREV		 |	0 |	 1 |	 3   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 18 |    FILTER					       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
|  19 |     TABLE ACCESS BY INDEX ROWID BATCHED 	       | V_DOMAINE		 |	0 |	 1 |	 4   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 20 |      INDEX RANGE SCAN				       | DOM_TYPABREV		 |	0 |	 1 |	 3   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 21 |    FILTER					       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
|  22 |     TABLE ACCESS BY INDEX ROWID BATCHED 	       | V_DOMAINE		 |	0 |	 1 |	 4   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 23 |      INDEX RANGE SCAN				       | DOM_TYPABREV		 |	0 |	 1 |	 3   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 24 |    FILTER					       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
|  25 |     TABLE ACCESS BY INDEX ROWID BATCHED 	       | V_DOMAINE		 |	0 |	 1 |	 4   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 26 |      INDEX RANGE SCAN				       | DOM_TYPABREV		 |	0 |	 1 |	 3   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 27 |    FILTER					       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
|  28 |     TABLE ACCESS BY INDEX ROWID BATCHED 	       | V_DOMAINE		 |	0 |	 1 |	 4   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 29 |      INDEX RANGE SCAN				       | DOM_TYPABREV		 |	0 |	 1 |	 3   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 30 |    FILTER					       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
|  31 |     TABLE ACCESS BY INDEX ROWID BATCHED 	       | V_DOMAINE		 |	0 |	 1 |	 4   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 32 |      INDEX RANGE SCAN				       | DOM_TYPABREV		 |	0 |	 1 |	 3   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 33 |    FILTER					       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
|  34 |     TABLE ACCESS BY INDEX ROWID BATCHED 	       | V_DOMAINE		 |	0 |	 1 |	 4   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 35 |      INDEX RANGE SCAN				       | DOM_TYPABREV		 |	0 |	 1 |	 3   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 36 |    FILTER					       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
|  37 |     TABLE ACCESS BY INDEX ROWID BATCHED 	       | V_DOMAINE		 |	0 |	 1 |	 4   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 38 |      INDEX RANGE SCAN				       | DOM_TYPABREV		 |	0 |	 1 |	 3   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 39 |    FILTER					       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
|  40 |     TABLE ACCESS BY INDEX ROWID BATCHED 	       | V_DOMAINE		 |	0 |	 1 |	 4   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 41 |      INDEX RANGE SCAN				       | DOM_TYPABREV		 |	0 |	 1 |	 3   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 42 |    FILTER					       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
|  43 |     TABLE ACCESS BY INDEX ROWID BATCHED 	       | V_DOMAINE		 |	0 |	 1 |	 4   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 44 |      INDEX RANGE SCAN				       | DOM_TYPABREV		 |	0 |	 1 |	 3   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 45 |    FILTER					       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
|  46 |     TABLE ACCESS BY INDEX ROWID BATCHED 	       | V_DOMAINE		 |	0 |	 1 |	 4   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 47 |      INDEX RANGE SCAN				       | DOM_TYPABREV		 |	0 |	 1 |	 3   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 48 |    FILTER					       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
|  49 |     TABLE ACCESS BY INDEX ROWID BATCHED 	       | V_DOMAINE		 |	0 |	 1 |	 4   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 50 |      INDEX RANGE SCAN				       | DOM_TYPABREV		 |	0 |	 1 |	 3   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 51 |    FILTER					       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
|  52 |     TABLE ACCESS BY INDEX ROWID BATCHED 	       | V_DOMAINE		 |	0 |	 1 |	 4   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 53 |      INDEX RANGE SCAN				       | DOM_TYPABREV		 |	0 |	 1 |	 3   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 54 |    FILTER					       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
|  55 |     TABLE ACCESS BY INDEX ROWID BATCHED 	       | V_DOMAINE		 |	0 |	 1 |	 4   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 56 |      INDEX RANGE SCAN				       | DOM_TYPABREV		 |	0 |	 1 |	 3   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 57 |    FILTER					       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
|  58 |     TABLE ACCESS BY INDEX ROWID BATCHED 	       | V_DOMAINE		 |	0 |	 1 |	 4   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 59 |      INDEX RANGE SCAN				       | DOM_TYPABREV		 |	0 |	 1 |	 3   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 60 |    FILTER					       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
|  61 |     TABLE ACCESS BY INDEX ROWID BATCHED 	       | V_DOMAINE		 |	0 |	 1 |	 4   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 62 |      INDEX RANGE SCAN				       | DOM_TYPABREV		 |	0 |	 1 |	 3   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 63 |    FILTER					       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
|  64 |     TABLE ACCESS BY INDEX ROWID BATCHED 	       | V_DOMAINE		 |	0 |	 1 |	 4   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 65 |      INDEX RANGE SCAN				       | DOM_TYPABREV		 |	0 |	 1 |	 3   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 66 |    FILTER					       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
|  67 |     TABLE ACCESS BY INDEX ROWID BATCHED 	       | V_DOMAINE		 |	0 |	 1 |	 4   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 68 |      INDEX RANGE SCAN				       | DOM_TYPABREV		 |	0 |	 1 |	 3   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 69 |    FILTER					       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
|  70 |     TABLE ACCESS BY INDEX ROWID BATCHED 	       | V_DOMAINE		 |	0 |	 1 |	 4   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 71 |      INDEX RANGE SCAN				       | DOM_TYPABREV		 |	0 |	 1 |	 3   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 72 |    FILTER					       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
|  73 |     TABLE ACCESS BY INDEX ROWID BATCHED 	       | V_DOMAINE		 |	0 |	 1 |	 4   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 74 |      INDEX RANGE SCAN				       | DOM_TYPABREV		 |	0 |	 1 |	 3   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 75 |    FILTER					       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
|  76 |     TABLE ACCESS BY INDEX ROWID BATCHED 	       | V_DOMAINE		 |	0 |	 1 |	 4   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 77 |      INDEX RANGE SCAN				       | DOM_TYPABREV		 |	0 |	 1 |	 3   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 78 |    FILTER					       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
|  79 |     TABLE ACCESS BY INDEX ROWID BATCHED 	       | V_DOMAINE		 |	0 |	 1 |	 4   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 80 |      INDEX RANGE SCAN				       | DOM_TYPABREV		 |	0 |	 1 |	 3   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 81 |    FILTER					       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
|  82 |     TABLE ACCESS BY INDEX ROWID BATCHED 	       | V_DOMAINE		 |	0 |	 1 |	 4   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 83 |      INDEX RANGE SCAN				       | DOM_TYPABREV		 |	0 |	 1 |	 3   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 84 |    FILTER					       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
|  85 |     TABLE ACCESS BY INDEX ROWID BATCHED 	       | V_DOMAINE		 |	0 |	 1 |	 4   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 86 |      INDEX RANGE SCAN				       | DOM_TYPABREV		 |	0 |	 1 |	 3   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 87 |    FILTER					       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
|  88 |     TABLE ACCESS BY INDEX ROWID BATCHED 	       | V_DOMAINE		 |	0 |	 1 |	 4   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 89 |      INDEX RANGE SCAN				       | DOM_TYPABREV		 |	0 |	 1 |	 3   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 90 |    FILTER					       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
|  91 |     TABLE ACCESS BY INDEX ROWID BATCHED 	       | V_DOMAINE		 |	0 |	 1 |	 4   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 92 |      INDEX RANGE SCAN				       | DOM_TYPABREV		 |	0 |	 1 |	 3   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 93 |    FILTER					       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
|  94 |     TABLE ACCESS BY INDEX ROWID BATCHED 	       | V_DOMAINE		 |	0 |	 1 |	 4   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 95 |      INDEX RANGE SCAN				       | DOM_TYPABREV		 |	0 |	 1 |	 3   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 96 |    FILTER					       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
|  97 |     TABLE ACCESS BY INDEX ROWID BATCHED 	       | V_DOMAINE		 |	0 |	 1 |	 4   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 98 |      INDEX RANGE SCAN				       | DOM_TYPABREV		 |	0 |	 1 |	 3   (0)|      0 |00:00:00.01 |       0 |      0 |
|* 99 |    FILTER					       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 100 |     TABLE ACCESS BY INDEX ROWID BATCHED 	       | V_DOMAINE		 |	0 |	 1 |	 4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*101 |      INDEX RANGE SCAN				       | DOM_TYPABREV		 |	0 |	 1 |	 3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*102 |    FILTER					       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 103 |     TABLE ACCESS BY INDEX ROWID BATCHED 	       | V_DOMAINE		 |	0 |	 1 |	 4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*104 |      INDEX RANGE SCAN				       | DOM_TYPABREV		 |	0 |	 1 |	 3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*105 |    FILTER					       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 106 |     TABLE ACCESS BY INDEX ROWID BATCHED 	       | V_DOMAINE		 |	0 |	 1 |	 4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*107 |      INDEX RANGE SCAN				       | DOM_TYPABREV		 |	0 |	 1 |	 3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*108 |    FILTER					       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 109 |     TABLE ACCESS BY INDEX ROWID BATCHED 	       | V_DOMAINE		 |	0 |	 1 |	 4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*110 |      INDEX RANGE SCAN				       | DOM_TYPABREV		 |	0 |	 1 |	 3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*111 |     INDEX RANGE SCAN				       | ELIGB_ALERT_ID_IDX	 |    127 |	 1 |	 3   (0)|      0 |00:00:00.01 |     137 |      3 |
| 112 |      VIEW					       | V_TDOMAINE		 |	0 |	36 |   144   (0)|      0 |00:00:00.01 |       0 |      0 |
| 113 |       UNION-ALL 				       |			 |	0 |	   |		|      0 |00:00:00.01 |       0 |      0 |
|*114 |        FILTER					       |			 |	0 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 115 | 	TABLE ACCESS BY INDEX ROWID BATCHED	       | V_DOMAINE		 |	0 |	 1 |	 4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*116 | 	 INDEX RANGE SCAN			       | DOM_TYPABREV		 |	0 |	 1 |	 3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*117 |        FILTER					       |			 |	0 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 118 | 	TABLE ACCESS BY INDEX ROWID BATCHED	       | V_DOMAINE		 |	0 |	 1 |	 4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*119 | 	 INDEX RANGE SCAN			       | DOM_TYPABREV		 |	0 |	 1 |	 3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*120 |        FILTER					       |			 |	0 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 121 | 	TABLE ACCESS BY INDEX ROWID BATCHED	       | V_DOMAINE		 |	0 |	 1 |	 4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*122 | 	 INDEX RANGE SCAN			       | DOM_TYPABREV		 |	0 |	 1 |	 3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*123 |        FILTER					       |			 |	0 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 124 | 	TABLE ACCESS BY INDEX ROWID BATCHED	       | V_DOMAINE		 |	0 |	 1 |	 4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*125 | 	 INDEX RANGE SCAN			       | DOM_TYPABREV		 |	0 |	 1 |	 3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*126 |        FILTER					       |			 |	0 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 127 | 	TABLE ACCESS BY INDEX ROWID BATCHED	       | V_DOMAINE		 |	0 |	 1 |	 4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*128 | 	 INDEX RANGE SCAN			       | DOM_TYPABREV		 |	0 |	 1 |	 3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*129 |        FILTER					       |			 |	0 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 130 | 	TABLE ACCESS BY INDEX ROWID BATCHED	       | V_DOMAINE		 |	0 |	 1 |	 4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*131 | 	 INDEX RANGE SCAN			       | DOM_TYPABREV		 |	0 |	 1 |	 3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*132 |        FILTER					       |			 |	0 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 133 | 	TABLE ACCESS BY INDEX ROWID BATCHED	       | V_DOMAINE		 |	0 |	 1 |	 4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*134 | 	 INDEX RANGE SCAN			       | DOM_TYPABREV		 |	0 |	 1 |	 3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*135 |        FILTER					       |			 |	0 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 136 | 	TABLE ACCESS BY INDEX ROWID BATCHED	       | V_DOMAINE		 |	0 |	 1 |	 4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*137 | 	 INDEX RANGE SCAN			       | DOM_TYPABREV		 |	0 |	 1 |	 3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*138 |        FILTER					       |			 |	0 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 139 | 	TABLE ACCESS BY INDEX ROWID BATCHED	       | V_DOMAINE		 |	0 |	 1 |	 4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*140 | 	 INDEX RANGE SCAN			       | DOM_TYPABREV		 |	0 |	 1 |	 3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*141 |        FILTER					       |			 |	0 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 142 | 	TABLE ACCESS BY INDEX ROWID BATCHED	       | V_DOMAINE		 |	0 |	 1 |	 4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*143 | 	 INDEX RANGE SCAN			       | DOM_TYPABREV		 |	0 |	 1 |	 3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*144 |        FILTER					       |			 |	0 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 145 | 	TABLE ACCESS BY INDEX ROWID BATCHED	       | V_DOMAINE		 |	0 |	 1 |	 4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*146 | 	 INDEX RANGE SCAN			       | DOM_TYPABREV		 |	0 |	 1 |	 3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*147 |        FILTER					       |			 |	0 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 148 | 	TABLE ACCESS BY INDEX ROWID BATCHED	       | V_DOMAINE		 |	0 |	 1 |	 4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*149 | 	 INDEX RANGE SCAN			       | DOM_TYPABREV		 |	0 |	 1 |	 3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*150 |        FILTER					       |			 |	0 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 151 | 	TABLE ACCESS BY INDEX ROWID BATCHED	       | V_DOMAINE		 |	0 |	 1 |	 4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*152 | 	 INDEX RANGE SCAN			       | DOM_TYPABREV		 |	0 |	 1 |	 3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*153 |        FILTER					       |			 |	0 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 154 | 	TABLE ACCESS BY INDEX ROWID BATCHED	       | V_DOMAINE		 |	0 |	 1 |	 4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*155 | 	 INDEX RANGE SCAN			       | DOM_TYPABREV		 |	0 |	 1 |	 3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*156 |        FILTER					       |			 |	0 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 157 | 	TABLE ACCESS BY INDEX ROWID BATCHED	       | V_DOMAINE		 |	0 |	 1 |	 4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*158 | 	 INDEX RANGE SCAN			       | DOM_TYPABREV		 |	0 |	 1 |	 3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*159 |        FILTER					       |			 |	0 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 160 | 	TABLE ACCESS BY INDEX ROWID BATCHED	       | V_DOMAINE		 |	0 |	 1 |	 4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*161 | 	 INDEX RANGE SCAN			       | DOM_TYPABREV		 |	0 |	 1 |	 3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*162 |        FILTER					       |			 |	0 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 163 | 	TABLE ACCESS BY INDEX ROWID BATCHED	       | V_DOMAINE		 |	0 |	 1 |	 4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*164 | 	 INDEX RANGE SCAN			       | DOM_TYPABREV		 |	0 |	 1 |	 3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*165 |        FILTER					       |			 |	0 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 166 | 	TABLE ACCESS BY INDEX ROWID BATCHED	       | V_DOMAINE		 |	0 |	 1 |	 4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*167 | 	 INDEX RANGE SCAN			       | DOM_TYPABREV		 |	0 |	 1 |	 3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*168 |        FILTER					       |			 |	0 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 169 | 	TABLE ACCESS BY INDEX ROWID BATCHED	       | V_DOMAINE		 |	0 |	 1 |	 4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*170 | 	 INDEX RANGE SCAN			       | DOM_TYPABREV		 |	0 |	 1 |	 3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*171 |        FILTER					       |			 |	0 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 172 | 	TABLE ACCESS BY INDEX ROWID BATCHED	       | V_DOMAINE		 |	0 |	 1 |	 4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*173 | 	 INDEX RANGE SCAN			       | DOM_TYPABREV		 |	0 |	 1 |	 3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*174 |        FILTER					       |			 |	0 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 175 | 	TABLE ACCESS BY INDEX ROWID BATCHED	       | V_DOMAINE		 |	0 |	 1 |	 4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*176 | 	 INDEX RANGE SCAN			       | DOM_TYPABREV		 |	0 |	 1 |	 3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*177 |        FILTER					       |			 |	0 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 178 | 	TABLE ACCESS BY INDEX ROWID BATCHED	       | V_DOMAINE		 |	0 |	 1 |	 4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*179 | 	 INDEX RANGE SCAN			       | DOM_TYPABREV		 |	0 |	 1 |	 3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*180 |        FILTER					       |			 |	0 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 181 | 	TABLE ACCESS BY INDEX ROWID BATCHED	       | V_DOMAINE		 |	0 |	 1 |	 4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*182 | 	 INDEX RANGE SCAN			       | DOM_TYPABREV		 |	0 |	 1 |	 3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*183 |        FILTER					       |			 |	0 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 184 | 	TABLE ACCESS BY INDEX ROWID BATCHED	       | V_DOMAINE		 |	0 |	 1 |	 4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*185 | 	 INDEX RANGE SCAN			       | DOM_TYPABREV		 |	0 |	 1 |	 3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*186 |        FILTER					       |			 |	0 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 187 | 	TABLE ACCESS BY INDEX ROWID BATCHED	       | V_DOMAINE		 |	0 |	 1 |	 4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*188 | 	 INDEX RANGE SCAN			       | DOM_TYPABREV		 |	0 |	 1 |	 3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*189 |        FILTER					       |			 |	0 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 190 | 	TABLE ACCESS BY INDEX ROWID BATCHED	       | V_DOMAINE		 |	0 |	 1 |	 4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*191 | 	 INDEX RANGE SCAN			       | DOM_TYPABREV		 |	0 |	 1 |	 3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*192 |        FILTER					       |			 |	0 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 193 | 	TABLE ACCESS BY INDEX ROWID BATCHED	       | V_DOMAINE		 |	0 |	 1 |	 4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*194 | 	 INDEX RANGE SCAN			       | DOM_TYPABREV		 |	0 |	 1 |	 3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*195 |        FILTER					       |			 |	0 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 196 | 	TABLE ACCESS BY INDEX ROWID BATCHED	       | V_DOMAINE		 |	0 |	 1 |	 4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*197 | 	 INDEX RANGE SCAN			       | DOM_TYPABREV		 |	0 |	 1 |	 3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*198 |        FILTER					       |			 |	0 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 199 | 	TABLE ACCESS BY INDEX ROWID BATCHED	       | V_DOMAINE		 |	0 |	 1 |	 4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*200 | 	 INDEX RANGE SCAN			       | DOM_TYPABREV		 |	0 |	 1 |	 3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*201 |        FILTER					       |			 |	0 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 202 | 	TABLE ACCESS BY INDEX ROWID BATCHED	       | V_DOMAINE		 |	0 |	 1 |	 4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*203 | 	 INDEX RANGE SCAN			       | DOM_TYPABREV		 |	0 |	 1 |	 3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*204 |        FILTER					       |			 |	0 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 205 | 	TABLE ACCESS BY INDEX ROWID BATCHED	       | V_DOMAINE		 |	0 |	 1 |	 4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*206 | 	 INDEX RANGE SCAN			       | DOM_TYPABREV		 |	0 |	 1 |	 3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*207 |        FILTER					       |			 |	0 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 208 | 	TABLE ACCESS BY INDEX ROWID BATCHED	       | V_DOMAINE		 |	0 |	 1 |	 4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*209 | 	 INDEX RANGE SCAN			       | DOM_TYPABREV		 |	0 |	 1 |	 3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*210 |        FILTER					       |			 |	0 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 211 | 	TABLE ACCESS BY INDEX ROWID BATCHED	       | V_DOMAINE		 |	0 |	 1 |	 4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*212 | 	 INDEX RANGE SCAN			       | DOM_TYPABREV		 |	0 |	 1 |	 3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*213 |        FILTER					       |			 |	0 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 214 | 	TABLE ACCESS BY INDEX ROWID BATCHED	       | V_DOMAINE		 |	0 |	 1 |	 4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*215 | 	 INDEX RANGE SCAN			       | DOM_TYPABREV		 |	0 |	 1 |	 3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*216 |        FILTER					       |			 |	0 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 217 | 	TABLE ACCESS BY INDEX ROWID BATCHED	       | V_DOMAINE		 |	0 |	 1 |	 4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*218 | 	 INDEX RANGE SCAN			       | DOM_TYPABREV		 |	0 |	 1 |	 3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*219 |        FILTER					       |			 |	0 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 220 | 	TABLE ACCESS BY INDEX ROWID BATCHED	       | V_DOMAINE		 |	0 |	 1 |	 4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*221 | 	 INDEX RANGE SCAN			       | DOM_TYPABREV		 |	0 |	 1 |	 3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*222 | 	INDEX RANGE SCAN			       | ELIGB_ALERT_ID_IDX	 |    127 |	 1 |	 3   (0)|      0 |00:00:00.01 |     137 |      0 |
| 223 | 	 VIEW					       | V_TDOMAINE		 |	1 |	36 |   144   (0)|      0 |00:00:00.01 |       3 |      0 |
| 224 | 	  UNION-ALL				       |			 |	1 |	   |		|      0 |00:00:00.01 |       3 |      0 |
|*225 | 	   FILTER				       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 226 | 	    TABLE ACCESS BY INDEX ROWID BATCHED        | V_DOMAINE		 |	0 |	 1 |	 4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*227 | 	     INDEX RANGE SCAN			       | DOM_TYPABREV		 |	0 |	 1 |	 3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*228 | 	   FILTER				       |			 |	1 |	   |		|      0 |00:00:00.01 |       3 |      0 |
| 229 | 	    TABLE ACCESS BY INDEX ROWID BATCHED        | V_DOMAINE		 |	1 |	 1 |	 4   (0)|      0 |00:00:00.01 |       3 |      0 |
|*230 | 	     INDEX RANGE SCAN			       | DOM_TYPABREV		 |	1 |	 1 |	 3   (0)|      0 |00:00:00.01 |       3 |      0 |
|*231 | 	   FILTER				       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 232 | 	    TABLE ACCESS BY INDEX ROWID BATCHED        | V_DOMAINE		 |	0 |	 1 |	 4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*233 | 	     INDEX RANGE SCAN			       | DOM_TYPABREV		 |	0 |	 1 |	 3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*234 | 	   FILTER				       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 235 | 	    TABLE ACCESS BY INDEX ROWID BATCHED        | V_DOMAINE		 |	0 |	 1 |	 4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*236 | 	     INDEX RANGE SCAN			       | DOM_TYPABREV		 |	0 |	 1 |	 3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*237 | 	   FILTER				       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 238 | 	    TABLE ACCESS BY INDEX ROWID BATCHED        | V_DOMAINE		 |	0 |	 1 |	 4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*239 | 	     INDEX RANGE SCAN			       | DOM_TYPABREV		 |	0 |	 1 |	 3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*240 | 	   FILTER				       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 241 | 	    TABLE ACCESS BY INDEX ROWID BATCHED        | V_DOMAINE		 |	0 |	 1 |	 4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*242 | 	     INDEX RANGE SCAN			       | DOM_TYPABREV		 |	0 |	 1 |	 3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*243 | 	   FILTER				       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 244 | 	    TABLE ACCESS BY INDEX ROWID BATCHED        | V_DOMAINE		 |	0 |	 1 |	 4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*245 | 	     INDEX RANGE SCAN			       | DOM_TYPABREV		 |	0 |	 1 |	 3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*246 | 	   FILTER				       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 247 | 	    TABLE ACCESS BY INDEX ROWID BATCHED        | V_DOMAINE		 |	0 |	 1 |	 4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*248 | 	     INDEX RANGE SCAN			       | DOM_TYPABREV		 |	0 |	 1 |	 3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*249 | 	   FILTER				       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 250 | 	    TABLE ACCESS BY INDEX ROWID BATCHED        | V_DOMAINE		 |	0 |	 1 |	 4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*251 | 	     INDEX RANGE SCAN			       | DOM_TYPABREV		 |	0 |	 1 |	 3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*252 | 	   FILTER				       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 253 | 	    TABLE ACCESS BY INDEX ROWID BATCHED        | V_DOMAINE		 |	0 |	 1 |	 4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*254 | 	     INDEX RANGE SCAN			       | DOM_TYPABREV		 |	0 |	 1 |	 3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*255 | 	   FILTER				       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 256 | 	    TABLE ACCESS BY INDEX ROWID BATCHED        | V_DOMAINE		 |	0 |	 1 |	 4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*257 | 	     INDEX RANGE SCAN			       | DOM_TYPABREV		 |	0 |	 1 |	 3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*258 | 	   FILTER				       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 259 | 	    TABLE ACCESS BY INDEX ROWID BATCHED        | V_DOMAINE		 |	0 |	 1 |	 4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*260 | 	     INDEX RANGE SCAN			       | DOM_TYPABREV		 |	0 |	 1 |	 3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*261 | 	   FILTER				       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 262 | 	    TABLE ACCESS BY INDEX ROWID BATCHED        | V_DOMAINE		 |	0 |	 1 |	 4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*263 | 	     INDEX RANGE SCAN			       | DOM_TYPABREV		 |	0 |	 1 |	 3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*264 | 	   FILTER				       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 265 | 	    TABLE ACCESS BY INDEX ROWID BATCHED        | V_DOMAINE		 |	0 |	 1 |	 4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*266 | 	     INDEX RANGE SCAN			       | DOM_TYPABREV		 |	0 |	 1 |	 3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*267 | 	   FILTER				       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 268 | 	    TABLE ACCESS BY INDEX ROWID BATCHED        | V_DOMAINE		 |	0 |	 1 |	 4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*269 | 	     INDEX RANGE SCAN			       | DOM_TYPABREV		 |	0 |	 1 |	 3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*270 | 	   FILTER				       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 271 | 	    TABLE ACCESS BY INDEX ROWID BATCHED        | V_DOMAINE		 |	0 |	 1 |	 4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*272 | 	     INDEX RANGE SCAN			       | DOM_TYPABREV		 |	0 |	 1 |	 3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*273 | 	   FILTER				       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 274 | 	    TABLE ACCESS BY INDEX ROWID BATCHED        | V_DOMAINE		 |	0 |	 1 |	 4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*275 | 	     INDEX RANGE SCAN			       | DOM_TYPABREV		 |	0 |	 1 |	 3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*276 | 	   FILTER				       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 277 | 	    TABLE ACCESS BY INDEX ROWID BATCHED        | V_DOMAINE		 |	0 |	 1 |	 4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*278 | 	     INDEX RANGE SCAN			       | DOM_TYPABREV		 |	0 |	 1 |	 3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*279 | 	   FILTER				       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 280 | 	    TABLE ACCESS BY INDEX ROWID BATCHED        | V_DOMAINE		 |	0 |	 1 |	 4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*281 | 	     INDEX RANGE SCAN			       | DOM_TYPABREV		 |	0 |	 1 |	 3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*282 | 	   FILTER				       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 283 | 	    TABLE ACCESS BY INDEX ROWID BATCHED        | V_DOMAINE		 |	0 |	 1 |	 4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*284 | 	     INDEX RANGE SCAN			       | DOM_TYPABREV		 |	0 |	 1 |	 3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*285 | 	   FILTER				       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 286 | 	    TABLE ACCESS BY INDEX ROWID BATCHED        | V_DOMAINE		 |	0 |	 1 |	 4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*287 | 	     INDEX RANGE SCAN			       | DOM_TYPABREV		 |	0 |	 1 |	 3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*288 | 	   FILTER				       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 289 | 	    TABLE ACCESS BY INDEX ROWID BATCHED        | V_DOMAINE		 |	0 |	 1 |	 4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*290 | 	     INDEX RANGE SCAN			       | DOM_TYPABREV		 |	0 |	 1 |	 3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*291 | 	   FILTER				       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 292 | 	    TABLE ACCESS BY INDEX ROWID BATCHED        | V_DOMAINE		 |	0 |	 1 |	 4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*293 | 	     INDEX RANGE SCAN			       | DOM_TYPABREV		 |	0 |	 1 |	 3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*294 | 	   FILTER				       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 295 | 	    TABLE ACCESS BY INDEX ROWID BATCHED        | V_DOMAINE		 |	0 |	 1 |	 4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*296 | 	     INDEX RANGE SCAN			       | DOM_TYPABREV		 |	0 |	 1 |	 3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*297 | 	   FILTER				       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 298 | 	    TABLE ACCESS BY INDEX ROWID BATCHED        | V_DOMAINE		 |	0 |	 1 |	 4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*299 | 	     INDEX RANGE SCAN			       | DOM_TYPABREV		 |	0 |	 1 |	 3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*300 | 	   FILTER				       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 301 | 	    TABLE ACCESS BY INDEX ROWID BATCHED        | V_DOMAINE		 |	0 |	 1 |	 4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*302 | 	     INDEX RANGE SCAN			       | DOM_TYPABREV		 |	0 |	 1 |	 3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*303 | 	   FILTER				       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 304 | 	    TABLE ACCESS BY INDEX ROWID BATCHED        | V_DOMAINE		 |	0 |	 1 |	 4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*305 | 	     INDEX RANGE SCAN			       | DOM_TYPABREV		 |	0 |	 1 |	 3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*306 | 	   FILTER				       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 307 | 	    TABLE ACCESS BY INDEX ROWID BATCHED        | V_DOMAINE		 |	0 |	 1 |	 4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*308 | 	     INDEX RANGE SCAN			       | DOM_TYPABREV		 |	0 |	 1 |	 3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*309 | 	   FILTER				       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 310 | 	    TABLE ACCESS BY INDEX ROWID BATCHED        | V_DOMAINE		 |	0 |	 1 |	 4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*311 | 	     INDEX RANGE SCAN			       | DOM_TYPABREV		 |	0 |	 1 |	 3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*312 | 	   FILTER				       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 313 | 	    TABLE ACCESS BY INDEX ROWID BATCHED        | V_DOMAINE		 |	0 |	 1 |	 4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*314 | 	     INDEX RANGE SCAN			       | DOM_TYPABREV		 |	0 |	 1 |	 3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*315 | 	   FILTER				       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 316 | 	    TABLE ACCESS BY INDEX ROWID BATCHED        | V_DOMAINE		 |	0 |	 1 |	 4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*317 | 	     INDEX RANGE SCAN			       | DOM_TYPABREV		 |	0 |	 1 |	 3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*318 | 	   FILTER				       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 319 | 	    TABLE ACCESS BY INDEX ROWID BATCHED        | V_DOMAINE		 |	0 |	 1 |	 4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*320 | 	     INDEX RANGE SCAN			       | DOM_TYPABREV		 |	0 |	 1 |	 3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*321 | 	   FILTER				       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 322 | 	    TABLE ACCESS BY INDEX ROWID BATCHED        | V_DOMAINE		 |	0 |	 1 |	 4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*323 | 	     INDEX RANGE SCAN			       | DOM_TYPABREV		 |	0 |	 1 |	 3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*324 | 	   FILTER				       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 325 | 	    TABLE ACCESS BY INDEX ROWID BATCHED        | V_DOMAINE		 |	0 |	 1 |	 4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*326 | 	     INDEX RANGE SCAN			       | DOM_TYPABREV		 |	0 |	 1 |	 3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*327 | 	   FILTER				       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 328 | 	    TABLE ACCESS BY INDEX ROWID BATCHED        | V_DOMAINE		 |	0 |	 1 |	 4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*329 | 	     INDEX RANGE SCAN			       | DOM_TYPABREV		 |	0 |	 1 |	 3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*330 | 	   FILTER				       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 331 | 	    TABLE ACCESS BY INDEX ROWID BATCHED        | V_DOMAINE		 |	0 |	 1 |	 4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*332 | 	     INDEX RANGE SCAN			       | DOM_TYPABREV		 |	0 |	 1 |	 3   (0)|      0 |00:00:00.01 |       0 |      0 |
| 333 |  NESTED LOOPS					       |			 |     20 |	 1 |	 4   (0)|      0 |00:00:00.01 |      92 |      1 |
| 334 |   NESTED LOOPS					       |			 |     20 |	 1 |	 4   (0)|      0 |00:00:00.01 |      92 |      1 |
|*335 |    TABLE ACCESS BY INDEX ROWID BATCHED		       | G_DOSSIER		 |     20 |	 1 |	 2   (0)|      0 |00:00:00.01 |      92 |      1 |
|*336 |     INDEX RANGE SCAN				       | DOS_ANCREFDOSS 	 |     20 |	 1 |	 1   (0)|     19 |00:00:00.01 |      38 |      1 |
|*337 |    INDEX UNIQUE SCAN				       | DOS_REFDOSS		 |	0 |	 1 |	 1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*338 |   TABLE ACCESS BY INDEX ROWID			       | G_DOSSIER		 |	0 |	 1 |	 2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*339 |    FILTER					       |			 |	0 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 340 |     TABLE ACCESS BY INDEX ROWID BATCHED 	       | G_DOSSIER		 |	0 |  26321 |  2981   (1)|      0 |00:00:00.01 |       0 |      0 |
|*341 |      INDEX RANGE SCAN				       | DOS_CATDOSS		 |	0 |  26321 |   122   (0)|      0 |00:00:00.01 |       0 |      0 |
|*342 |     TABLE ACCESS BY INDEX ROWID BATCHED 	       | G_DOSSIER		 |	0 |	 1 |	 2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*343 |      INDEX RANGE SCAN				       | DOS_ANCREFDOSS 	 |	0 |	 1 |	 1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*344 |  INDEX RANGE SCAN				       | IDX_ALERTID_DET	 |   2001 |	 1 |	 1   (0)|      0 |00:00:00.01 |    2001 |      0 |
| 345 |   SORT GROUP BY 				       |			 |	0 |	 1 |		|      0 |00:00:00.01 |       0 |      0 |
| 346 |    NESTED LOOPS 				       |			 |	0 |	 1 |   145   (0)|      0 |00:00:00.01 |       0 |      0 |
| 347 |     TABLE ACCESS BY INDEX ROWID BATCHED 	       | T_ALERT_NOT_ES_DET	 |	0 |	 1 |	 1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*348 |      INDEX RANGE SCAN				       | IDX_ALERTID_DET	 |	0 |	 1 |	 1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 349 |     VIEW					       | V_TDOMAINE		 |	0 |	 1 |   144   (0)|      0 |00:00:00.01 |       0 |      0 |
| 350 |      UNION ALL PUSHED PREDICATE 		       |			 |	0 |	   |		|      0 |00:00:00.01 |       0 |      0 |
|*351 |       FILTER					       |			 |	0 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 352 |        TABLE ACCESS BY INDEX ROWID BATCHED	       | V_DOMAINE		 |	0 |	 1 |	 4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*353 | 	INDEX RANGE SCAN			       | DOM_TYPABREV		 |	0 |	 1 |	 3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*354 |       FILTER					       |			 |	0 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 355 |        TABLE ACCESS BY INDEX ROWID BATCHED	       | V_DOMAINE		 |	0 |	 1 |	 4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*356 | 	INDEX RANGE SCAN			       | DOM_TYPABREV		 |	0 |	 1 |	 3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*357 |       FILTER					       |			 |	0 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 358 |        TABLE ACCESS BY INDEX ROWID BATCHED	       | V_DOMAINE		 |	0 |	 1 |	 4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*359 | 	INDEX RANGE SCAN			       | DOM_TYPABREV		 |	0 |	 1 |	 3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*360 |       FILTER					       |			 |	0 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 361 |        TABLE ACCESS BY INDEX ROWID BATCHED	       | V_DOMAINE		 |	0 |	 1 |	 4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*362 | 	INDEX RANGE SCAN			       | DOM_TYPABREV		 |	0 |	 1 |	 3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*363 |       FILTER					       |			 |	0 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 364 |        TABLE ACCESS BY INDEX ROWID BATCHED	       | V_DOMAINE		 |	0 |	 1 |	 4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*365 | 	INDEX RANGE SCAN			       | DOM_TYPABREV		 |	0 |	 1 |	 3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*366 |       FILTER					       |			 |	0 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 367 |        TABLE ACCESS BY INDEX ROWID BATCHED	       | V_DOMAINE		 |	0 |	 1 |	 4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*368 | 	INDEX RANGE SCAN			       | DOM_TYPABREV		 |	0 |	 1 |	 3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*369 |       FILTER					       |			 |	0 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 370 |        TABLE ACCESS BY INDEX ROWID BATCHED	       | V_DOMAINE		 |	0 |	 1 |	 4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*371 | 	INDEX RANGE SCAN			       | DOM_TYPABREV		 |	0 |	 1 |	 3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*372 |       FILTER					       |			 |	0 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 373 |        TABLE ACCESS BY INDEX ROWID BATCHED	       | V_DOMAINE		 |	0 |	 1 |	 4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*374 | 	INDEX RANGE SCAN			       | DOM_TYPABREV		 |	0 |	 1 |	 3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*375 |       FILTER					       |			 |	0 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 376 |        TABLE ACCESS BY INDEX ROWID BATCHED	       | V_DOMAINE		 |	0 |	 1 |	 4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*377 | 	INDEX RANGE SCAN			       | DOM_TYPABREV		 |	0 |	 1 |	 3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*378 |       FILTER					       |			 |	0 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 379 |        TABLE ACCESS BY INDEX ROWID BATCHED	       | V_DOMAINE		 |	0 |	 1 |	 4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*380 | 	INDEX RANGE SCAN			       | DOM_TYPABREV		 |	0 |	 1 |	 3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*381 |       FILTER					       |			 |	0 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 382 |        TABLE ACCESS BY INDEX ROWID BATCHED	       | V_DOMAINE		 |	0 |	 1 |	 4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*383 | 	INDEX RANGE SCAN			       | DOM_TYPABREV		 |	0 |	 1 |	 3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*384 |       FILTER					       |			 |	0 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 385 |        TABLE ACCESS BY INDEX ROWID BATCHED	       | V_DOMAINE		 |	0 |	 1 |	 4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*386 | 	INDEX RANGE SCAN			       | DOM_TYPABREV		 |	0 |	 1 |	 3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*387 |       FILTER					       |			 |	0 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 388 |        TABLE ACCESS BY INDEX ROWID BATCHED	       | V_DOMAINE		 |	0 |	 1 |	 4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*389 | 	INDEX RANGE SCAN			       | DOM_TYPABREV		 |	0 |	 1 |	 3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*390 |       FILTER					       |			 |	0 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 391 |        TABLE ACCESS BY INDEX ROWID BATCHED	       | V_DOMAINE		 |	0 |	 1 |	 4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*392 | 	INDEX RANGE SCAN			       | DOM_TYPABREV		 |	0 |	 1 |	 3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*393 |       FILTER					       |			 |	0 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 394 |        TABLE ACCESS BY INDEX ROWID BATCHED	       | V_DOMAINE		 |	0 |	 1 |	 4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*395 | 	INDEX RANGE SCAN			       | DOM_TYPABREV		 |	0 |	 1 |	 3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*396 |       FILTER					       |			 |	0 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 397 |        TABLE ACCESS BY INDEX ROWID BATCHED	       | V_DOMAINE		 |	0 |	 1 |	 4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*398 | 	INDEX RANGE SCAN			       | DOM_TYPABREV		 |	0 |	 1 |	 3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*399 |       FILTER					       |			 |	0 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 400 |        TABLE ACCESS BY INDEX ROWID BATCHED	       | V_DOMAINE		 |	0 |	 1 |	 4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*401 | 	INDEX RANGE SCAN			       | DOM_TYPABREV		 |	0 |	 1 |	 3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*402 |       FILTER					       |			 |	0 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 403 |        TABLE ACCESS BY INDEX ROWID BATCHED	       | V_DOMAINE		 |	0 |	 1 |	 4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*404 | 	INDEX RANGE SCAN			       | DOM_TYPABREV		 |	0 |	 1 |	 3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*405 |       FILTER					       |			 |	0 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 406 |        TABLE ACCESS BY INDEX ROWID BATCHED	       | V_DOMAINE		 |	0 |	 1 |	 4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*407 | 	INDEX RANGE SCAN			       | DOM_TYPABREV		 |	0 |	 1 |	 3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*408 |       FILTER					       |			 |	0 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 409 |        TABLE ACCESS BY INDEX ROWID BATCHED	       | V_DOMAINE		 |	0 |	 1 |	 4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*410 | 	INDEX RANGE SCAN			       | DOM_TYPABREV		 |	0 |	 1 |	 3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*411 |       FILTER					       |			 |	0 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 412 |        TABLE ACCESS BY INDEX ROWID BATCHED	       | V_DOMAINE		 |	0 |	 1 |	 4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*413 | 	INDEX RANGE SCAN			       | DOM_TYPABREV		 |	0 |	 1 |	 3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*414 |       FILTER					       |			 |	0 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 415 |        TABLE ACCESS BY INDEX ROWID BATCHED	       | V_DOMAINE		 |	0 |	 1 |	 4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*416 | 	INDEX RANGE SCAN			       | DOM_TYPABREV		 |	0 |	 1 |	 3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*417 |       FILTER					       |			 |	0 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 418 |        TABLE ACCESS BY INDEX ROWID BATCHED	       | V_DOMAINE		 |	0 |	 1 |	 4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*419 | 	INDEX RANGE SCAN			       | DOM_TYPABREV		 |	0 |	 1 |	 3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*420 |       FILTER					       |			 |	0 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 421 |        TABLE ACCESS BY INDEX ROWID BATCHED	       | V_DOMAINE		 |	0 |	 1 |	 4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*422 | 	INDEX RANGE SCAN			       | DOM_TYPABREV		 |	0 |	 1 |	 3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*423 |       FILTER					       |			 |	0 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 424 |        TABLE ACCESS BY INDEX ROWID BATCHED	       | V_DOMAINE		 |	0 |	 1 |	 4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*425 | 	INDEX RANGE SCAN			       | DOM_TYPABREV		 |	0 |	 1 |	 3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*426 |       FILTER					       |			 |	0 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 427 |        TABLE ACCESS BY INDEX ROWID BATCHED	       | V_DOMAINE		 |	0 |	 1 |	 4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*428 | 	INDEX RANGE SCAN			       | DOM_TYPABREV		 |	0 |	 1 |	 3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*429 |       FILTER					       |			 |	0 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 430 |        TABLE ACCESS BY INDEX ROWID BATCHED	       | V_DOMAINE		 |	0 |	 1 |	 4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*431 | 	INDEX RANGE SCAN			       | DOM_TYPABREV		 |	0 |	 1 |	 3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*432 |       FILTER					       |			 |	0 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 433 |        TABLE ACCESS BY INDEX ROWID BATCHED	       | V_DOMAINE		 |	0 |	 1 |	 4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*434 | 	INDEX RANGE SCAN			       | DOM_TYPABREV		 |	0 |	 1 |	 3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*435 |       FILTER					       |			 |	0 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 436 |        TABLE ACCESS BY INDEX ROWID BATCHED	       | V_DOMAINE		 |	0 |	 1 |	 4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*437 | 	INDEX RANGE SCAN			       | DOM_TYPABREV		 |	0 |	 1 |	 3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*438 |       FILTER					       |			 |	0 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 439 |        TABLE ACCESS BY INDEX ROWID BATCHED	       | V_DOMAINE		 |	0 |	 1 |	 4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*440 | 	INDEX RANGE SCAN			       | DOM_TYPABREV		 |	0 |	 1 |	 3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*441 |       FILTER					       |			 |	0 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 442 |        TABLE ACCESS BY INDEX ROWID BATCHED	       | V_DOMAINE		 |	0 |	 1 |	 4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*443 | 	INDEX RANGE SCAN			       | DOM_TYPABREV		 |	0 |	 1 |	 3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*444 |       FILTER					       |			 |	0 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 445 |        TABLE ACCESS BY INDEX ROWID BATCHED	       | V_DOMAINE		 |	0 |	 1 |	 4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*446 | 	INDEX RANGE SCAN			       | DOM_TYPABREV		 |	0 |	 1 |	 3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*447 |       FILTER					       |			 |	0 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 448 |        TABLE ACCESS BY INDEX ROWID BATCHED	       | V_DOMAINE		 |	0 |	 1 |	 4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*449 | 	INDEX RANGE SCAN			       | DOM_TYPABREV		 |	0 |	 1 |	 3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*450 |       FILTER					       |			 |	0 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 451 |        TABLE ACCESS BY INDEX ROWID BATCHED	       | V_DOMAINE		 |	0 |	 1 |	 4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*452 | 	INDEX RANGE SCAN			       | DOM_TYPABREV		 |	0 |	 1 |	 3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*453 |       FILTER					       |			 |	0 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 454 |        TABLE ACCESS BY INDEX ROWID BATCHED	       | V_DOMAINE		 |	0 |	 1 |	 4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*455 | 	INDEX RANGE SCAN			       | DOM_TYPABREV		 |	0 |	 1 |	 3   (0)|      0 |00:00:00.01 |       0 |      0 |
|*456 |       FILTER					       |			 |	0 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 457 |        TABLE ACCESS BY INDEX ROWID BATCHED	       | V_DOMAINE		 |	0 |	 1 |	 4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*458 | 	INDEX RANGE SCAN			       | DOM_TYPABREV		 |	0 |	 1 |	 3   (0)|      0 |00:00:00.01 |       0 |      0 |
| 459 |  NESTED LOOPS					       |			 |     20 |	 1 |	 4   (0)|      0 |00:00:00.01 |      92 |      0 |
| 460 |   NESTED LOOPS					       |			 |     20 |	 1 |	 4   (0)|      0 |00:00:00.01 |      92 |      0 |
|*461 |    TABLE ACCESS BY INDEX ROWID BATCHED		       | G_DOSSIER		 |     20 |	 1 |	 2   (0)|      0 |00:00:00.01 |      92 |      0 |
|*462 |     INDEX RANGE SCAN				       | DOS_ANCREFDOSS 	 |     20 |	 1 |	 1   (0)|     19 |00:00:00.01 |      38 |      0 |
|*463 |    INDEX UNIQUE SCAN				       | DOS_REFDOSS		 |	0 |	 1 |	 1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*464 |   TABLE ACCESS BY INDEX ROWID			       | G_DOSSIER		 |	0 |	 1 |	 2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*465 |    COUNT STOPKEY				       |			 |	0 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 466 |     NESTED LOOPS				       |			 |	0 |	 1 |	 8   (0)|      0 |00:00:00.01 |       0 |      0 |
| 467 |      NESTED LOOPS				       |			 |	0 |	 1 |	 8   (0)|      0 |00:00:00.01 |       0 |      0 |
| 468 |       NESTED LOOPS				       |			 |	0 |	 1 |	 6   (0)|      0 |00:00:00.01 |       0 |      0 |
| 469 |        NESTED LOOPS				       |			 |	0 |	 1 |	 4   (0)|      0 |00:00:00.01 |       0 |      0 |
|*470 | 	TABLE ACCESS BY INDEX ROWID BATCHED	       | G_DOSSIER		 |	0 |	 1 |	 2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*471 | 	 INDEX RANGE SCAN			       | DOS_ANCREFDOSS 	 |	0 |	 1 |	 1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*472 | 	TABLE ACCESS BY INDEX ROWID		       | G_DOSSIER		 |	0 |	 1 |	 2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*473 | 	 INDEX UNIQUE SCAN			       | DOS_REFDOSS		 |	0 |	 1 |	 1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*474 |        INDEX RANGE SCAN 			       | INT_REFDOSS		 |	0 |	 1 |	 2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*475 |       INDEX UNIQUE SCAN 			       | IND_REFINDIV		 |	0 |	 1 |	 1   (0)|      0 |00:00:00.01 |       0 |      0 |
| 476 |      TABLE ACCESS BY INDEX ROWID		       | G_INDIVIDU		 |	0 |	 1 |	 2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*477 |     COUNT STOPKEY				       |			 |     20 |	   |		|     19 |00:00:00.01 |     186 |      5 |
| 478 |      NESTED LOOPS				       |			 |     20 |	 3 |	14   (0)|     19 |00:00:00.01 |     186 |      5 |
| 479 |       NESTED LOOPS				       |			 |     20 |	 3 |	14   (0)|     19 |00:00:00.01 |     166 |      5 |
| 480 |        NESTED LOOPS				       |			 |     20 |	 3 |	 8   (0)|     19 |00:00:00.01 |     114 |      5 |
| 481 | 	TABLE ACCESS BY INDEX ROWID BATCHED	       | G_DOSSIER		 |     20 |	60 |	 2   (0)|     19 |00:00:00.01 |      57 |      0 |
|*482 | 	 INDEX RANGE SCAN			       | DOS_ANCREFDOSS 	 |     20 |	 1 |	 1   (0)|     19 |00:00:00.01 |      38 |      0 |
|*483 | 	INDEX RANGE SCAN			       | INT_REFDOSS		 |     19 |	 1 |	 2   (0)|     19 |00:00:00.01 |      57 |      5 |
|*484 |        INDEX UNIQUE SCAN			       | IND_REFINDIV		 |     19 |	 1 |	 1   (0)|     19 |00:00:00.01 |      52 |      0 |
| 485 |       TABLE ACCESS BY INDEX ROWID		       | G_INDIVIDU		 |     19 |	 1 |	 2   (0)|     19 |00:00:00.01 |      20 |      0 |
|*486 |  VIEW						       |			 |	1 |	 1 | 51388   (1)|   2001 |00:00:09.26 |     926K|   1978 |
|*487 |   COUNT STOPKEY 				       |			 |	1 |	   |		|   2001 |00:00:09.25 |     926K|   1978 |
| 488 |    VIEW 					       |			 |	1 |	 1 | 51388   (1)|   2001 |00:00:09.25 |     926K|   1978 |
|*489 |     SORT ORDER BY STOPKEY			       |			 |	1 |	 1 | 51388   (1)|   2001 |00:00:09.22 |     923K|   1969 |
|*490 |      HASH JOIN OUTER				       |			 |	1 |	 1 |  1675   (1)|  74674 |00:00:09.12 |     923K|   1969 |
| 491 |       JOIN FILTER CREATE			       | :BF0000		 |	1 |	 1 |  1386   (1)|  74674 |00:00:08.86 |     923K|   1969 |
| 492 |        NESTED LOOPS OUTER			       |			 |	1 |	 1 |  1386   (1)|  74674 |00:00:08.80 |     923K|   1969 |
| 493 | 	NESTED LOOPS OUTER			       |			 |	1 |	 1 |  1376   (1)|  74674 |00:00:05.79 |     503K|   1926 |
|*494 | 	 HASH JOIN OUTER			       |			 |	1 |	 1 |  1371   (1)|  74674 |00:00:02.67 |     340K|     58 |
| 495 | 	  JOIN FILTER CREATE			       | :BF0001		 |	1 |	 1 |  1081   (1)|  74674 |00:00:02.41 |     340K|     58 |
|*496 | 	   HASH JOIN OUTER			       |			 |	1 |	 1 |  1081   (1)|  74674 |00:00:02.38 |     340K|     58 |
| 497 | 	    JOIN FILTER CREATE			       | :BF0002		 |	1 |	 1 |   792   (1)|  74674 |00:00:02.16 |     340K|     58 |
|*498 | 	     HASH JOIN OUTER			       |			 |	1 |	 1 |   792   (1)|  74674 |00:00:02.14 |     340K|     58 |
| 499 | 	      JOIN FILTER CREATE		       | :BF0003		 |	1 |	 1 |   502   (0)|  74674 |00:00:01.90 |     340K|     58 |
| 500 | 	       NESTED LOOPS ANTI		       |			 |	1 |	 1 |   502   (0)|  74674 |00:00:01.88 |     340K|     58 |
| 501 | 		NESTED LOOPS OUTER		       |			 |	1 |	 1 |   499   (0)|  74674 |00:00:01.55 |     339K|     54 |
| 502 | 		 NESTED LOOPS			       |			 |	1 |	 1 |   497   (0)|  74674 |00:00:00.67 |   54712 |      8 |
| 503 | 		  NESTED LOOPS			       |			 |	1 |	 1 |	21   (0)|    569 |00:00:00.02 |    1888 |      8 |
| 504 | 		   NESTED LOOPS 		       |			 |	1 |	 4 |	16   (0)|    569 |00:00:00.02 |    1194 |      8 |
| 505 | 		    VIEW			       | VW_NSO_1		 |	1 |	 4 |	 8   (0)|    570 |00:00:00.01 |      10 |      8 |
| 506 | 		     HASH UNIQUE		       |			 |	1 |	 4 |	 8   (0)|    570 |00:00:00.01 |      10 |      8 |
| 507 | 		      UNION-ALL 		       |			 |	1 |	   |		|    571 |00:00:00.01 |      10 |      8 |
|*508 | 		       INDEX RANGE SCAN 	       | G_INDIVPARAM_REFIND	 |	1 |	 2 |	 3   (0)|    570 |00:00:00.01 |       9 |      8 |
| 509 | 		       FAST DUAL		       |			 |	1 |	 1 |	 2   (0)|      1 |00:00:00.01 |       0 |      0 |
| 510 | 		       NESTED LOOPS		       |			 |	1 |	 1 |	 3   (0)|      0 |00:00:00.01 |       1 |      0 |
| 511 | 			NESTED LOOPS		       |			 |	1 |	 1 |	 3   (0)|      0 |00:00:00.01 |       1 |      0 |
|*512 | 			 INDEX RANGE SCAN	       | AGE_PERSOJOUR		 |	1 |	 1 |	 1   (0)|      0 |00:00:00.01 |       1 |      0 |
|*513 | 			 INDEX RANGE SCAN	       | GPERSREFP		 |	0 |	 1 |	 1   (0)|      0 |00:00:00.01 |       0 |      0 |
|*514 | 			TABLE ACCESS BY INDEX ROWID    | G_PERSONNEL		 |	0 |	 1 |	 2   (0)|      0 |00:00:00.01 |       0 |      0 |
| 515 | 		    TABLE ACCESS BY INDEX ROWID        | G_INDIVIDU		 |    570 |	 1 |	 2   (0)|    569 |00:00:00.01 |    1184 |      0 |
|*516 | 		     INDEX UNIQUE SCAN		       | IND_REFINDIV		 |    570 |	 1 |	 1   (0)|    569 |00:00:00.01 |     744 |      0 |
| 517 | 		   TABLE ACCESS BY INDEX ROWID BATCHED | G_PERSONNEL		 |    569 |	 1 |	 2   (0)|    569 |00:00:00.01 |     694 |      0 |
|*518 | 		    INDEX RANGE SCAN		       | GPERS_REFIN_IDX	 |    569 |	 1 |	 1   (0)|    569 |00:00:00.01 |     246 |      0 |
|*519 | 		  TABLE ACCESS BY INDEX ROWID BATCHED  | T_ALERTE		 |    569 |	 3 |   476   (0)|  74674 |00:00:00.62 |   52824 |      0 |
|*520 | 		   INDEX RANGE SCAN		       | AL_PERS_TYPENC 	 |    569 |   1852 |	41   (0)|    206K|00:00:00.10 |    5369 |      0 |
| 521 | 		 TABLE ACCESS BY INDEX ROWID	       | G_DOSSIER		 |  74674 |	 1 |	 2   (0)|  74081 |00:00:00.80 |     284K|     46 |
|*522 | 		  INDEX UNIQUE SCAN		       | DOS_REFDOSS		 |  74674 |	 1 |	 1   (0)|  74081 |00:00:00.28 |     116K|     46 |
|*523 | 		TABLE ACCESS BY INDEX ROWID BATCHED    | V_DOMAINE		 |  74674 |	 1 |	 3   (0)|      0 |00:00:00.28 |     756 |      4 |
|*524 | 		 INDEX RANGE SCAN		       | DOM_TYPVAL		 |  74674 |	 1 |	 1   (0)|  74674 |00:00:00.15 |     621 |      4 |
| 525 | 	      VIEW				       |			 |	1 |	40 |   289   (1)|     43 |00:00:00.01 |     365 |      0 |
| 526 | 	       HASH GROUP BY			       |			 |	1 |	40 |   289   (1)|     43 |00:00:00.01 |     365 |      0 |
| 527 | 		VIEW				       | V_TDOMAINE		 |	1 |   1404 |   288   (0)|     43 |00:00:00.01 |     365 |      0 |
| 528 | 		 JOIN FILTER USE		       | :BF0003		 |	1 |	   |		|     43 |00:00:00.01 |     365 |      0 |
| 529 | 		  UNION-ALL			       |			 |	1 |	   |		|    815 |00:00:00.01 |     365 |      0 |
|*530 | 		   FILTER			       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 531 | 		    TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE		 |	0 |	39 |	 8   (0)|      0 |00:00:00.01 |       0 |      0 |
|*532 | 		     INDEX RANGE SCAN		       | V_DOMAINE_TYPE_CODE_IDX |	0 |	39 |	 2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*533 | 		   FILTER			       |			 |	1 |	   |		|    815 |00:00:00.01 |     365 |      0 |
| 534 | 		    TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE		 |	1 |	39 |	 8   (0)|    815 |00:00:00.01 |     365 |      0 |
|*535 | 		     INDEX RANGE SCAN		       | V_DOMAINE_TYPE_CODE_IDX |	1 |	39 |	 2   (0)|    815 |00:00:00.01 |       6 |      0 |
|*536 | 		   FILTER			       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 537 | 		    TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE		 |	0 |	39 |	 8   (0)|      0 |00:00:00.01 |       0 |      0 |
|*538 | 		     INDEX RANGE SCAN		       | V_DOMAINE_TYPE_CODE_IDX |	0 |	39 |	 2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*539 | 		   FILTER			       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 540 | 		    TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE		 |	0 |	39 |	 8   (0)|      0 |00:00:00.01 |       0 |      0 |
|*541 | 		     INDEX RANGE SCAN		       | V_DOMAINE_TYPE_CODE_IDX |	0 |	39 |	 2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*542 | 		   FILTER			       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 543 | 		    TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE		 |	0 |	39 |	 8   (0)|      0 |00:00:00.01 |       0 |      0 |
|*544 | 		     INDEX RANGE SCAN		       | V_DOMAINE_TYPE_CODE_IDX |	0 |	39 |	 2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*545 | 		   FILTER			       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 546 | 		    TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE		 |	0 |	39 |	 8   (0)|      0 |00:00:00.01 |       0 |      0 |
|*547 | 		     INDEX RANGE SCAN		       | V_DOMAINE_TYPE_CODE_IDX |	0 |	39 |	 2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*548 | 		   FILTER			       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 549 | 		    TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE		 |	0 |	39 |	 8   (0)|      0 |00:00:00.01 |       0 |      0 |
|*550 | 		     INDEX RANGE SCAN		       | V_DOMAINE_TYPE_CODE_IDX |	0 |	39 |	 2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*551 | 		   FILTER			       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 552 | 		    TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE		 |	0 |	39 |	 8   (0)|      0 |00:00:00.01 |       0 |      0 |
|*553 | 		     INDEX RANGE SCAN		       | V_DOMAINE_TYPE_CODE_IDX |	0 |	39 |	 2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*554 | 		   FILTER			       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 555 | 		    TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE		 |	0 |	39 |	 8   (0)|      0 |00:00:00.01 |       0 |      0 |
|*556 | 		     INDEX RANGE SCAN		       | V_DOMAINE_TYPE_CODE_IDX |	0 |	39 |	 2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*557 | 		   FILTER			       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 558 | 		    TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE		 |	0 |	39 |	 8   (0)|      0 |00:00:00.01 |       0 |      0 |
|*559 | 		     INDEX RANGE SCAN		       | V_DOMAINE_TYPE_CODE_IDX |	0 |	39 |	 2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*560 | 		   FILTER			       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 561 | 		    TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE		 |	0 |	39 |	 8   (0)|      0 |00:00:00.01 |       0 |      0 |
|*562 | 		     INDEX RANGE SCAN		       | V_DOMAINE_TYPE_CODE_IDX |	0 |	39 |	 2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*563 | 		   FILTER			       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 564 | 		    TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE		 |	0 |	39 |	 8   (0)|      0 |00:00:00.01 |       0 |      0 |
|*565 | 		     INDEX RANGE SCAN		       | V_DOMAINE_TYPE_CODE_IDX |	0 |	39 |	 2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*566 | 		   FILTER			       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 567 | 		    TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE		 |	0 |	39 |	 8   (0)|      0 |00:00:00.01 |       0 |      0 |
|*568 | 		     INDEX RANGE SCAN		       | V_DOMAINE_TYPE_CODE_IDX |	0 |	39 |	 2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*569 | 		   FILTER			       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 570 | 		    TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE		 |	0 |	39 |	 8   (0)|      0 |00:00:00.01 |       0 |      0 |
|*571 | 		     INDEX RANGE SCAN		       | V_DOMAINE_TYPE_CODE_IDX |	0 |	39 |	 2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*572 | 		   FILTER			       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 573 | 		    TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE		 |	0 |	39 |	 8   (0)|      0 |00:00:00.01 |       0 |      0 |
|*574 | 		     INDEX RANGE SCAN		       | V_DOMAINE_TYPE_CODE_IDX |	0 |	39 |	 2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*575 | 		   FILTER			       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 576 | 		    TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE		 |	0 |	39 |	 8   (0)|      0 |00:00:00.01 |       0 |      0 |
|*577 | 		     INDEX RANGE SCAN		       | V_DOMAINE_TYPE_CODE_IDX |	0 |	39 |	 2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*578 | 		   FILTER			       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 579 | 		    TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE		 |	0 |	39 |	 8   (0)|      0 |00:00:00.01 |       0 |      0 |
|*580 | 		     INDEX RANGE SCAN		       | V_DOMAINE_TYPE_CODE_IDX |	0 |	39 |	 2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*581 | 		   FILTER			       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 582 | 		    TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE		 |	0 |	39 |	 8   (0)|      0 |00:00:00.01 |       0 |      0 |
|*583 | 		     INDEX RANGE SCAN		       | V_DOMAINE_TYPE_CODE_IDX |	0 |	39 |	 2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*584 | 		   FILTER			       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 585 | 		    TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE		 |	0 |	39 |	 8   (0)|      0 |00:00:00.01 |       0 |      0 |
|*586 | 		     INDEX RANGE SCAN		       | V_DOMAINE_TYPE_CODE_IDX |	0 |	39 |	 2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*587 | 		   FILTER			       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 588 | 		    TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE		 |	0 |	39 |	 8   (0)|      0 |00:00:00.01 |       0 |      0 |
|*589 | 		     INDEX RANGE SCAN		       | V_DOMAINE_TYPE_CODE_IDX |	0 |	39 |	 2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*590 | 		   FILTER			       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 591 | 		    TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE		 |	0 |	39 |	 8   (0)|      0 |00:00:00.01 |       0 |      0 |
|*592 | 		     INDEX RANGE SCAN		       | V_DOMAINE_TYPE_CODE_IDX |	0 |	39 |	 2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*593 | 		   FILTER			       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 594 | 		    TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE		 |	0 |	39 |	 8   (0)|      0 |00:00:00.01 |       0 |      0 |
|*595 | 		     INDEX RANGE SCAN		       | V_DOMAINE_TYPE_CODE_IDX |	0 |	39 |	 2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*596 | 		   FILTER			       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 597 | 		    TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE		 |	0 |	39 |	 8   (0)|      0 |00:00:00.01 |       0 |      0 |
|*598 | 		     INDEX RANGE SCAN		       | V_DOMAINE_TYPE_CODE_IDX |	0 |	39 |	 2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*599 | 		   FILTER			       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 600 | 		    TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE		 |	0 |	39 |	 8   (0)|      0 |00:00:00.01 |       0 |      0 |
|*601 | 		     INDEX RANGE SCAN		       | V_DOMAINE_TYPE_CODE_IDX |	0 |	39 |	 2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*602 | 		   FILTER			       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 603 | 		    TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE		 |	0 |	39 |	 8   (0)|      0 |00:00:00.01 |       0 |      0 |
|*604 | 		     INDEX RANGE SCAN		       | V_DOMAINE_TYPE_CODE_IDX |	0 |	39 |	 2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*605 | 		   FILTER			       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 606 | 		    TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE		 |	0 |	39 |	 8   (0)|      0 |00:00:00.01 |       0 |      0 |
|*607 | 		     INDEX RANGE SCAN		       | V_DOMAINE_TYPE_CODE_IDX |	0 |	39 |	 2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*608 | 		   FILTER			       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 609 | 		    TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE		 |	0 |	39 |	 8   (0)|      0 |00:00:00.01 |       0 |      0 |
|*610 | 		     INDEX RANGE SCAN		       | V_DOMAINE_TYPE_CODE_IDX |	0 |	39 |	 2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*611 | 		   FILTER			       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 612 | 		    TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE		 |	0 |	39 |	 8   (0)|      0 |00:00:00.01 |       0 |      0 |
|*613 | 		     INDEX RANGE SCAN		       | V_DOMAINE_TYPE_CODE_IDX |	0 |	39 |	 2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*614 | 		   FILTER			       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 615 | 		    TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE		 |	0 |	39 |	 8   (0)|      0 |00:00:00.01 |       0 |      0 |
|*616 | 		     INDEX RANGE SCAN		       | V_DOMAINE_TYPE_CODE_IDX |	0 |	39 |	 2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*617 | 		   FILTER			       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 618 | 		    TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE		 |	0 |	39 |	 8   (0)|      0 |00:00:00.01 |       0 |      0 |
|*619 | 		     INDEX RANGE SCAN		       | V_DOMAINE_TYPE_CODE_IDX |	0 |	39 |	 2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*620 | 		   FILTER			       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 621 | 		    TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE		 |	0 |	39 |	 8   (0)|      0 |00:00:00.01 |       0 |      0 |
|*622 | 		     INDEX RANGE SCAN		       | V_DOMAINE_TYPE_CODE_IDX |	0 |	39 |	 2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*623 | 		   FILTER			       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 624 | 		    TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE		 |	0 |	39 |	 8   (0)|      0 |00:00:00.01 |       0 |      0 |
|*625 | 		     INDEX RANGE SCAN		       | V_DOMAINE_TYPE_CODE_IDX |	0 |	39 |	 2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*626 | 		   FILTER			       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 627 | 		    TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE		 |	0 |	39 |	 8   (0)|      0 |00:00:00.01 |       0 |      0 |
|*628 | 		     INDEX RANGE SCAN		       | V_DOMAINE_TYPE_CODE_IDX |	0 |	39 |	 2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*629 | 		   FILTER			       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 630 | 		    TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE		 |	0 |	39 |	 8   (0)|      0 |00:00:00.01 |       0 |      0 |
|*631 | 		     INDEX RANGE SCAN		       | V_DOMAINE_TYPE_CODE_IDX |	0 |	39 |	 2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*632 | 		   FILTER			       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 633 | 		    TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE		 |	0 |	39 |	 8   (0)|      0 |00:00:00.01 |       0 |      0 |
|*634 | 		     INDEX RANGE SCAN		       | V_DOMAINE_TYPE_CODE_IDX |	0 |	39 |	 2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*635 | 		   FILTER			       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 636 | 		    TABLE ACCESS BY INDEX ROWID BATCHED| V_DOMAINE		 |	0 |	39 |	 8   (0)|      0 |00:00:00.01 |       0 |      0 |
|*637 | 		     INDEX RANGE SCAN		       | V_DOMAINE_TYPE_CODE_IDX |	0 |	39 |	 2   (0)|      0 |00:00:00.01 |       0 |      0 |
| 638 | 	    VIEW				       |			 |	1 |	40 |   289   (1)|      9 |00:00:00.01 |       8 |      0 |
| 639 | 	     HASH GROUP BY			       |			 |	1 |	40 |   289   (1)|      9 |00:00:00.01 |       8 |      0 |
| 640 | 	      VIEW				       | V_TDOMAINE		 |	1 |   1404 |   288   (0)|      9 |00:00:00.01 |       8 |      0 |
| 641 | 	       JOIN FILTER USE			       | :BF0002		 |	1 |	   |		|      9 |00:00:00.01 |       8 |      0 |
| 642 | 		UNION-ALL			       |			 |	1 |	   |		|     37 |00:00:00.01 |       8 |      0 |
|*643 | 		 FILTER 			       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 644 | 		  TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE		 |	0 |	39 |	 8   (0)|      0 |00:00:00.01 |       0 |      0 |
|*645 | 		   INDEX RANGE SCAN		       | V_DOMAINE_TYPE_CODE_IDX |	0 |	39 |	 2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*646 | 		 FILTER 			       |			 |	1 |	   |		|     37 |00:00:00.01 |       8 |      0 |
| 647 | 		  TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE		 |	1 |	39 |	 8   (0)|     37 |00:00:00.01 |       8 |      0 |
|*648 | 		   INDEX RANGE SCAN		       | V_DOMAINE_TYPE_CODE_IDX |	1 |	39 |	 2   (0)|     37 |00:00:00.01 |       2 |      0 |
|*649 | 		 FILTER 			       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 650 | 		  TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE		 |	0 |	39 |	 8   (0)|      0 |00:00:00.01 |       0 |      0 |
|*651 | 		   INDEX RANGE SCAN		       | V_DOMAINE_TYPE_CODE_IDX |	0 |	39 |	 2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*652 | 		 FILTER 			       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 653 | 		  TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE		 |	0 |	39 |	 8   (0)|      0 |00:00:00.01 |       0 |      0 |
|*654 | 		   INDEX RANGE SCAN		       | V_DOMAINE_TYPE_CODE_IDX |	0 |	39 |	 2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*655 | 		 FILTER 			       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 656 | 		  TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE		 |	0 |	39 |	 8   (0)|      0 |00:00:00.01 |       0 |      0 |
|*657 | 		   INDEX RANGE SCAN		       | V_DOMAINE_TYPE_CODE_IDX |	0 |	39 |	 2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*658 | 		 FILTER 			       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 659 | 		  TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE		 |	0 |	39 |	 8   (0)|      0 |00:00:00.01 |       0 |      0 |
|*660 | 		   INDEX RANGE SCAN		       | V_DOMAINE_TYPE_CODE_IDX |	0 |	39 |	 2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*661 | 		 FILTER 			       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 662 | 		  TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE		 |	0 |	39 |	 8   (0)|      0 |00:00:00.01 |       0 |      0 |
|*663 | 		   INDEX RANGE SCAN		       | V_DOMAINE_TYPE_CODE_IDX |	0 |	39 |	 2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*664 | 		 FILTER 			       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 665 | 		  TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE		 |	0 |	39 |	 8   (0)|      0 |00:00:00.01 |       0 |      0 |
|*666 | 		   INDEX RANGE SCAN		       | V_DOMAINE_TYPE_CODE_IDX |	0 |	39 |	 2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*667 | 		 FILTER 			       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 668 | 		  TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE		 |	0 |	39 |	 8   (0)|      0 |00:00:00.01 |       0 |      0 |
|*669 | 		   INDEX RANGE SCAN		       | V_DOMAINE_TYPE_CODE_IDX |	0 |	39 |	 2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*670 | 		 FILTER 			       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 671 | 		  TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE		 |	0 |	39 |	 8   (0)|      0 |00:00:00.01 |       0 |      0 |
|*672 | 		   INDEX RANGE SCAN		       | V_DOMAINE_TYPE_CODE_IDX |	0 |	39 |	 2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*673 | 		 FILTER 			       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 674 | 		  TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE		 |	0 |	39 |	 8   (0)|      0 |00:00:00.01 |       0 |      0 |
|*675 | 		   INDEX RANGE SCAN		       | V_DOMAINE_TYPE_CODE_IDX |	0 |	39 |	 2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*676 | 		 FILTER 			       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 677 | 		  TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE		 |	0 |	39 |	 8   (0)|      0 |00:00:00.01 |       0 |      0 |
|*678 | 		   INDEX RANGE SCAN		       | V_DOMAINE_TYPE_CODE_IDX |	0 |	39 |	 2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*679 | 		 FILTER 			       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 680 | 		  TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE		 |	0 |	39 |	 8   (0)|      0 |00:00:00.01 |       0 |      0 |
|*681 | 		   INDEX RANGE SCAN		       | V_DOMAINE_TYPE_CODE_IDX |	0 |	39 |	 2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*682 | 		 FILTER 			       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 683 | 		  TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE		 |	0 |	39 |	 8   (0)|      0 |00:00:00.01 |       0 |      0 |
|*684 | 		   INDEX RANGE SCAN		       | V_DOMAINE_TYPE_CODE_IDX |	0 |	39 |	 2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*685 | 		 FILTER 			       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 686 | 		  TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE		 |	0 |	39 |	 8   (0)|      0 |00:00:00.01 |       0 |      0 |
|*687 | 		   INDEX RANGE SCAN		       | V_DOMAINE_TYPE_CODE_IDX |	0 |	39 |	 2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*688 | 		 FILTER 			       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 689 | 		  TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE		 |	0 |	39 |	 8   (0)|      0 |00:00:00.01 |       0 |      0 |
|*690 | 		   INDEX RANGE SCAN		       | V_DOMAINE_TYPE_CODE_IDX |	0 |	39 |	 2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*691 | 		 FILTER 			       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 692 | 		  TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE		 |	0 |	39 |	 8   (0)|      0 |00:00:00.01 |       0 |      0 |
|*693 | 		   INDEX RANGE SCAN		       | V_DOMAINE_TYPE_CODE_IDX |	0 |	39 |	 2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*694 | 		 FILTER 			       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 695 | 		  TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE		 |	0 |	39 |	 8   (0)|      0 |00:00:00.01 |       0 |      0 |
|*696 | 		   INDEX RANGE SCAN		       | V_DOMAINE_TYPE_CODE_IDX |	0 |	39 |	 2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*697 | 		 FILTER 			       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 698 | 		  TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE		 |	0 |	39 |	 8   (0)|      0 |00:00:00.01 |       0 |      0 |
|*699 | 		   INDEX RANGE SCAN		       | V_DOMAINE_TYPE_CODE_IDX |	0 |	39 |	 2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*700 | 		 FILTER 			       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 701 | 		  TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE		 |	0 |	39 |	 8   (0)|      0 |00:00:00.01 |       0 |      0 |
|*702 | 		   INDEX RANGE SCAN		       | V_DOMAINE_TYPE_CODE_IDX |	0 |	39 |	 2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*703 | 		 FILTER 			       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 704 | 		  TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE		 |	0 |	39 |	 8   (0)|      0 |00:00:00.01 |       0 |      0 |
|*705 | 		   INDEX RANGE SCAN		       | V_DOMAINE_TYPE_CODE_IDX |	0 |	39 |	 2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*706 | 		 FILTER 			       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 707 | 		  TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE		 |	0 |	39 |	 8   (0)|      0 |00:00:00.01 |       0 |      0 |
|*708 | 		   INDEX RANGE SCAN		       | V_DOMAINE_TYPE_CODE_IDX |	0 |	39 |	 2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*709 | 		 FILTER 			       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 710 | 		  TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE		 |	0 |	39 |	 8   (0)|      0 |00:00:00.01 |       0 |      0 |
|*711 | 		   INDEX RANGE SCAN		       | V_DOMAINE_TYPE_CODE_IDX |	0 |	39 |	 2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*712 | 		 FILTER 			       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 713 | 		  TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE		 |	0 |	39 |	 8   (0)|      0 |00:00:00.01 |       0 |      0 |
|*714 | 		   INDEX RANGE SCAN		       | V_DOMAINE_TYPE_CODE_IDX |	0 |	39 |	 2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*715 | 		 FILTER 			       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 716 | 		  TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE		 |	0 |	39 |	 8   (0)|      0 |00:00:00.01 |       0 |      0 |
|*717 | 		   INDEX RANGE SCAN		       | V_DOMAINE_TYPE_CODE_IDX |	0 |	39 |	 2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*718 | 		 FILTER 			       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 719 | 		  TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE		 |	0 |	39 |	 8   (0)|      0 |00:00:00.01 |       0 |      0 |
|*720 | 		   INDEX RANGE SCAN		       | V_DOMAINE_TYPE_CODE_IDX |	0 |	39 |	 2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*721 | 		 FILTER 			       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 722 | 		  TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE		 |	0 |	39 |	 8   (0)|      0 |00:00:00.01 |       0 |      0 |
|*723 | 		   INDEX RANGE SCAN		       | V_DOMAINE_TYPE_CODE_IDX |	0 |	39 |	 2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*724 | 		 FILTER 			       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 725 | 		  TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE		 |	0 |	39 |	 8   (0)|      0 |00:00:00.01 |       0 |      0 |
|*726 | 		   INDEX RANGE SCAN		       | V_DOMAINE_TYPE_CODE_IDX |	0 |	39 |	 2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*727 | 		 FILTER 			       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 728 | 		  TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE		 |	0 |	39 |	 8   (0)|      0 |00:00:00.01 |       0 |      0 |
|*729 | 		   INDEX RANGE SCAN		       | V_DOMAINE_TYPE_CODE_IDX |	0 |	39 |	 2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*730 | 		 FILTER 			       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 731 | 		  TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE		 |	0 |	39 |	 8   (0)|      0 |00:00:00.01 |       0 |      0 |
|*732 | 		   INDEX RANGE SCAN		       | V_DOMAINE_TYPE_CODE_IDX |	0 |	39 |	 2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*733 | 		 FILTER 			       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 734 | 		  TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE		 |	0 |	39 |	 8   (0)|      0 |00:00:00.01 |       0 |      0 |
|*735 | 		   INDEX RANGE SCAN		       | V_DOMAINE_TYPE_CODE_IDX |	0 |	39 |	 2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*736 | 		 FILTER 			       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 737 | 		  TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE		 |	0 |	39 |	 8   (0)|      0 |00:00:00.01 |       0 |      0 |
|*738 | 		   INDEX RANGE SCAN		       | V_DOMAINE_TYPE_CODE_IDX |	0 |	39 |	 2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*739 | 		 FILTER 			       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 740 | 		  TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE		 |	0 |	39 |	 8   (0)|      0 |00:00:00.01 |       0 |      0 |
|*741 | 		   INDEX RANGE SCAN		       | V_DOMAINE_TYPE_CODE_IDX |	0 |	39 |	 2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*742 | 		 FILTER 			       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 743 | 		  TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE		 |	0 |	39 |	 8   (0)|      0 |00:00:00.01 |       0 |      0 |
|*744 | 		   INDEX RANGE SCAN		       | V_DOMAINE_TYPE_CODE_IDX |	0 |	39 |	 2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*745 | 		 FILTER 			       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 746 | 		  TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE		 |	0 |	39 |	 8   (0)|      0 |00:00:00.01 |       0 |      0 |
|*747 | 		   INDEX RANGE SCAN		       | V_DOMAINE_TYPE_CODE_IDX |	0 |	39 |	 2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*748 | 		 FILTER 			       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 749 | 		  TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE		 |	0 |	39 |	 8   (0)|      0 |00:00:00.01 |       0 |      0 |
|*750 | 		   INDEX RANGE SCAN		       | V_DOMAINE_TYPE_CODE_IDX |	0 |	39 |	 2   (0)|      0 |00:00:00.01 |       0 |      0 |
| 751 | 	  VIEW					       |			 |	1 |	40 |   289   (1)|      8 |00:00:00.01 |      27 |      0 |
| 752 | 	   HASH GROUP BY			       |			 |	1 |	40 |   289   (1)|      8 |00:00:00.01 |      27 |      0 |
| 753 | 	    VIEW				       | V_TDOMAINE		 |	1 |   1404 |   288   (0)|      8 |00:00:00.01 |      27 |      0 |
| 754 | 	     JOIN FILTER USE			       | :BF0001		 |	1 |	   |		|      8 |00:00:00.01 |      27 |      0 |
| 755 | 	      UNION-ALL 			       |			 |	1 |	   |		|     42 |00:00:00.01 |      27 |      0 |
|*756 | 	       FILTER				       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 757 | 		TABLE ACCESS BY INDEX ROWID BATCHED    | V_DOMAINE		 |	0 |	39 |	 8   (0)|      0 |00:00:00.01 |       0 |      0 |
|*758 | 		 INDEX RANGE SCAN		       | V_DOMAINE_TYPE_CODE_IDX |	0 |	39 |	 2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*759 | 	       FILTER				       |			 |	1 |	   |		|     42 |00:00:00.01 |      27 |      0 |
| 760 | 		TABLE ACCESS BY INDEX ROWID BATCHED    | V_DOMAINE		 |	1 |	39 |	 8   (0)|     42 |00:00:00.01 |      27 |      0 |
|*761 | 		 INDEX RANGE SCAN		       | V_DOMAINE_TYPE_CODE_IDX |	1 |	39 |	 2   (0)|     42 |00:00:00.01 |       2 |      0 |
|*762 | 	       FILTER				       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 763 | 		TABLE ACCESS BY INDEX ROWID BATCHED    | V_DOMAINE		 |	0 |	39 |	 8   (0)|      0 |00:00:00.01 |       0 |      0 |
|*764 | 		 INDEX RANGE SCAN		       | V_DOMAINE_TYPE_CODE_IDX |	0 |	39 |	 2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*765 | 	       FILTER				       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 766 | 		TABLE ACCESS BY INDEX ROWID BATCHED    | V_DOMAINE		 |	0 |	39 |	 8   (0)|      0 |00:00:00.01 |       0 |      0 |
|*767 | 		 INDEX RANGE SCAN		       | V_DOMAINE_TYPE_CODE_IDX |	0 |	39 |	 2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*768 | 	       FILTER				       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 769 | 		TABLE ACCESS BY INDEX ROWID BATCHED    | V_DOMAINE		 |	0 |	39 |	 8   (0)|      0 |00:00:00.01 |       0 |      0 |
|*770 | 		 INDEX RANGE SCAN		       | V_DOMAINE_TYPE_CODE_IDX |	0 |	39 |	 2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*771 | 	       FILTER				       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 772 | 		TABLE ACCESS BY INDEX ROWID BATCHED    | V_DOMAINE		 |	0 |	39 |	 8   (0)|      0 |00:00:00.01 |       0 |      0 |
|*773 | 		 INDEX RANGE SCAN		       | V_DOMAINE_TYPE_CODE_IDX |	0 |	39 |	 2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*774 | 	       FILTER				       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 775 | 		TABLE ACCESS BY INDEX ROWID BATCHED    | V_DOMAINE		 |	0 |	39 |	 8   (0)|      0 |00:00:00.01 |       0 |      0 |
|*776 | 		 INDEX RANGE SCAN		       | V_DOMAINE_TYPE_CODE_IDX |	0 |	39 |	 2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*777 | 	       FILTER				       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 778 | 		TABLE ACCESS BY INDEX ROWID BATCHED    | V_DOMAINE		 |	0 |	39 |	 8   (0)|      0 |00:00:00.01 |       0 |      0 |
|*779 | 		 INDEX RANGE SCAN		       | V_DOMAINE_TYPE_CODE_IDX |	0 |	39 |	 2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*780 | 	       FILTER				       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 781 | 		TABLE ACCESS BY INDEX ROWID BATCHED    | V_DOMAINE		 |	0 |	39 |	 8   (0)|      0 |00:00:00.01 |       0 |      0 |
|*782 | 		 INDEX RANGE SCAN		       | V_DOMAINE_TYPE_CODE_IDX |	0 |	39 |	 2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*783 | 	       FILTER				       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 784 | 		TABLE ACCESS BY INDEX ROWID BATCHED    | V_DOMAINE		 |	0 |	39 |	 8   (0)|      0 |00:00:00.01 |       0 |      0 |
|*785 | 		 INDEX RANGE SCAN		       | V_DOMAINE_TYPE_CODE_IDX |	0 |	39 |	 2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*786 | 	       FILTER				       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 787 | 		TABLE ACCESS BY INDEX ROWID BATCHED    | V_DOMAINE		 |	0 |	39 |	 8   (0)|      0 |00:00:00.01 |       0 |      0 |
|*788 | 		 INDEX RANGE SCAN		       | V_DOMAINE_TYPE_CODE_IDX |	0 |	39 |	 2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*789 | 	       FILTER				       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 790 | 		TABLE ACCESS BY INDEX ROWID BATCHED    | V_DOMAINE		 |	0 |	39 |	 8   (0)|      0 |00:00:00.01 |       0 |      0 |
|*791 | 		 INDEX RANGE SCAN		       | V_DOMAINE_TYPE_CODE_IDX |	0 |	39 |	 2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*792 | 	       FILTER				       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 793 | 		TABLE ACCESS BY INDEX ROWID BATCHED    | V_DOMAINE		 |	0 |	39 |	 8   (0)|      0 |00:00:00.01 |       0 |      0 |
|*794 | 		 INDEX RANGE SCAN		       | V_DOMAINE_TYPE_CODE_IDX |	0 |	39 |	 2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*795 | 	       FILTER				       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 796 | 		TABLE ACCESS BY INDEX ROWID BATCHED    | V_DOMAINE		 |	0 |	39 |	 8   (0)|      0 |00:00:00.01 |       0 |      0 |
|*797 | 		 INDEX RANGE SCAN		       | V_DOMAINE_TYPE_CODE_IDX |	0 |	39 |	 2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*798 | 	       FILTER				       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 799 | 		TABLE ACCESS BY INDEX ROWID BATCHED    | V_DOMAINE		 |	0 |	39 |	 8   (0)|      0 |00:00:00.01 |       0 |      0 |
|*800 | 		 INDEX RANGE SCAN		       | V_DOMAINE_TYPE_CODE_IDX |	0 |	39 |	 2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*801 | 	       FILTER				       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 802 | 		TABLE ACCESS BY INDEX ROWID BATCHED    | V_DOMAINE		 |	0 |	39 |	 8   (0)|      0 |00:00:00.01 |       0 |      0 |
|*803 | 		 INDEX RANGE SCAN		       | V_DOMAINE_TYPE_CODE_IDX |	0 |	39 |	 2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*804 | 	       FILTER				       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 805 | 		TABLE ACCESS BY INDEX ROWID BATCHED    | V_DOMAINE		 |	0 |	39 |	 8   (0)|      0 |00:00:00.01 |       0 |      0 |
|*806 | 		 INDEX RANGE SCAN		       | V_DOMAINE_TYPE_CODE_IDX |	0 |	39 |	 2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*807 | 	       FILTER				       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 808 | 		TABLE ACCESS BY INDEX ROWID BATCHED    | V_DOMAINE		 |	0 |	39 |	 8   (0)|      0 |00:00:00.01 |       0 |      0 |
|*809 | 		 INDEX RANGE SCAN		       | V_DOMAINE_TYPE_CODE_IDX |	0 |	39 |	 2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*810 | 	       FILTER				       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 811 | 		TABLE ACCESS BY INDEX ROWID BATCHED    | V_DOMAINE		 |	0 |	39 |	 8   (0)|      0 |00:00:00.01 |       0 |      0 |
|*812 | 		 INDEX RANGE SCAN		       | V_DOMAINE_TYPE_CODE_IDX |	0 |	39 |	 2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*813 | 	       FILTER				       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 814 | 		TABLE ACCESS BY INDEX ROWID BATCHED    | V_DOMAINE		 |	0 |	39 |	 8   (0)|      0 |00:00:00.01 |       0 |      0 |
|*815 | 		 INDEX RANGE SCAN		       | V_DOMAINE_TYPE_CODE_IDX |	0 |	39 |	 2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*816 | 	       FILTER				       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 817 | 		TABLE ACCESS BY INDEX ROWID BATCHED    | V_DOMAINE		 |	0 |	39 |	 8   (0)|      0 |00:00:00.01 |       0 |      0 |
|*818 | 		 INDEX RANGE SCAN		       | V_DOMAINE_TYPE_CODE_IDX |	0 |	39 |	 2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*819 | 	       FILTER				       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 820 | 		TABLE ACCESS BY INDEX ROWID BATCHED    | V_DOMAINE		 |	0 |	39 |	 8   (0)|      0 |00:00:00.01 |       0 |      0 |
|*821 | 		 INDEX RANGE SCAN		       | V_DOMAINE_TYPE_CODE_IDX |	0 |	39 |	 2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*822 | 	       FILTER				       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 823 | 		TABLE ACCESS BY INDEX ROWID BATCHED    | V_DOMAINE		 |	0 |	39 |	 8   (0)|      0 |00:00:00.01 |       0 |      0 |
|*824 | 		 INDEX RANGE SCAN		       | V_DOMAINE_TYPE_CODE_IDX |	0 |	39 |	 2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*825 | 	       FILTER				       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 826 | 		TABLE ACCESS BY INDEX ROWID BATCHED    | V_DOMAINE		 |	0 |	39 |	 8   (0)|      0 |00:00:00.01 |       0 |      0 |
|*827 | 		 INDEX RANGE SCAN		       | V_DOMAINE_TYPE_CODE_IDX |	0 |	39 |	 2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*828 | 	       FILTER				       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 829 | 		TABLE ACCESS BY INDEX ROWID BATCHED    | V_DOMAINE		 |	0 |	39 |	 8   (0)|      0 |00:00:00.01 |       0 |      0 |
|*830 | 		 INDEX RANGE SCAN		       | V_DOMAINE_TYPE_CODE_IDX |	0 |	39 |	 2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*831 | 	       FILTER				       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 832 | 		TABLE ACCESS BY INDEX ROWID BATCHED    | V_DOMAINE		 |	0 |	39 |	 8   (0)|      0 |00:00:00.01 |       0 |      0 |
|*833 | 		 INDEX RANGE SCAN		       | V_DOMAINE_TYPE_CODE_IDX |	0 |	39 |	 2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*834 | 	       FILTER				       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 835 | 		TABLE ACCESS BY INDEX ROWID BATCHED    | V_DOMAINE		 |	0 |	39 |	 8   (0)|      0 |00:00:00.01 |       0 |      0 |
|*836 | 		 INDEX RANGE SCAN		       | V_DOMAINE_TYPE_CODE_IDX |	0 |	39 |	 2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*837 | 	       FILTER				       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 838 | 		TABLE ACCESS BY INDEX ROWID BATCHED    | V_DOMAINE		 |	0 |	39 |	 8   (0)|      0 |00:00:00.01 |       0 |      0 |
|*839 | 		 INDEX RANGE SCAN		       | V_DOMAINE_TYPE_CODE_IDX |	0 |	39 |	 2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*840 | 	       FILTER				       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 841 | 		TABLE ACCESS BY INDEX ROWID BATCHED    | V_DOMAINE		 |	0 |	39 |	 8   (0)|      0 |00:00:00.01 |       0 |      0 |
|*842 | 		 INDEX RANGE SCAN		       | V_DOMAINE_TYPE_CODE_IDX |	0 |	39 |	 2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*843 | 	       FILTER				       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 844 | 		TABLE ACCESS BY INDEX ROWID BATCHED    | V_DOMAINE		 |	0 |	39 |	 8   (0)|      0 |00:00:00.01 |       0 |      0 |
|*845 | 		 INDEX RANGE SCAN		       | V_DOMAINE_TYPE_CODE_IDX |	0 |	39 |	 2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*846 | 	       FILTER				       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 847 | 		TABLE ACCESS BY INDEX ROWID BATCHED    | V_DOMAINE		 |	0 |	39 |	 8   (0)|      0 |00:00:00.01 |       0 |      0 |
|*848 | 		 INDEX RANGE SCAN		       | V_DOMAINE_TYPE_CODE_IDX |	0 |	39 |	 2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*849 | 	       FILTER				       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 850 | 		TABLE ACCESS BY INDEX ROWID BATCHED    | V_DOMAINE		 |	0 |	39 |	 8   (0)|      0 |00:00:00.01 |       0 |      0 |
|*851 | 		 INDEX RANGE SCAN		       | V_DOMAINE_TYPE_CODE_IDX |	0 |	39 |	 2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*852 | 	       FILTER				       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 853 | 		TABLE ACCESS BY INDEX ROWID BATCHED    | V_DOMAINE		 |	0 |	39 |	 8   (0)|      0 |00:00:00.01 |       0 |      0 |
|*854 | 		 INDEX RANGE SCAN		       | V_DOMAINE_TYPE_CODE_IDX |	0 |	39 |	 2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*855 | 	       FILTER				       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 856 | 		TABLE ACCESS BY INDEX ROWID BATCHED    | V_DOMAINE		 |	0 |	39 |	 8   (0)|      0 |00:00:00.01 |       0 |      0 |
|*857 | 		 INDEX RANGE SCAN		       | V_DOMAINE_TYPE_CODE_IDX |	0 |	39 |	 2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*858 | 	       FILTER				       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 859 | 		TABLE ACCESS BY INDEX ROWID BATCHED    | V_DOMAINE		 |	0 |	39 |	 8   (0)|      0 |00:00:00.01 |       0 |      0 |
|*860 | 		 INDEX RANGE SCAN		       | V_DOMAINE_TYPE_CODE_IDX |	0 |	39 |	 2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*861 | 	       FILTER				       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 862 | 		TABLE ACCESS BY INDEX ROWID BATCHED    | V_DOMAINE		 |	0 |	39 |	 8   (0)|      0 |00:00:00.01 |       0 |      0 |
|*863 | 		 INDEX RANGE SCAN		       | V_DOMAINE_TYPE_CODE_IDX |	0 |	39 |	 2   (0)|      0 |00:00:00.01 |       0 |      0 |
| 864 | 	 VIEW PUSHED PREDICATE			       |			 |  74674 |	 1 |	 5   (0)|  74081 |00:00:03.05 |     163K|   1868 |
| 865 | 	  NESTED LOOPS				       |			 |  74674 |	 1 |	 5   (0)|  74081 |00:00:02.94 |     163K|   1868 |
| 866 | 	   NESTED LOOPS 			       |			 |  74674 |	 1 |	 5   (0)|  74081 |00:00:02.48 |     157K|   1757 |
|*867 | 	    INDEX RANGE SCAN			       | INT_REFDOSS		 |  74674 |	 1 |	 3   (0)|  74081 |00:00:02.12 |     114K|   1703 |
|*868 | 	    INDEX UNIQUE SCAN			       | IND_REFINDIV		 |  74081 |	 1 |	 1   (0)|  74081 |00:00:00.25 |   42954 |     54 |
| 869 | 	   TABLE ACCESS BY INDEX ROWID		       | G_INDIVIDU		 |  74081 |	 1 |	 2   (0)|  74081 |00:00:00.33 |    5436 |    111 |
| 870 | 	VIEW PUSHED PREDICATE			       |			 |  74674 |	 1 |	10   (0)|  74081 |00:00:02.94 |     420K|     43 |
| 871 | 	 NESTED LOOPS				       |			 |  74674 |	 1 |	10   (0)|  74081 |00:00:02.86 |     420K|     43 |
| 872 | 	  NESTED LOOPS				       |			 |  74674 |	 1 |	10   (0)|  74081 |00:00:02.66 |     414K|     43 |
| 873 | 	   NESTED LOOPS 			       |			 |  74674 |	 1 |	 8   (0)|  74081 |00:00:02.40 |     371K|     43 |
| 874 | 	    NESTED LOOPS			       |			 |  74674 |	 1 |	 7   (0)|    154K|00:00:01.84 |     371K|     43 |
| 875 | 	     NESTED LOOPS			       |			 |  74674 |	 1 |	 5   (0)|  74081 |00:00:01.27 |     253K|      0 |
| 876 | 	      TABLE ACCESS BY INDEX ROWID	       | G_DOSSIER		 |  74674 |	 1 |	 3   (0)|  74081 |00:00:00.51 |     178K|      0 |
|*877 | 	       INDEX UNIQUE SCAN		       | DOS_REFDOSS		 |  74674 |	 1 |	 2   (0)|  74081 |00:00:00.26 |     116K|      0 |
|*878 | 	      INDEX RANGE SCAN			       | DOM_TYPABREV		 |  74081 |	 1 |	 2   (0)|  74081 |00:00:00.64 |   74113 |      0 |
|*879 | 	     INDEX RANGE SCAN			       | INT_REFDOSS		 |  74081 |	 1 |	 2   (0)|    154K|00:00:00.42 |     118K|     43 |
|*880 | 	    TABLE ACCESS BY INDEX ROWID BATCHED        | V_INTERVENANTS 	 |    154K|	 1 |	 1   (0)|  74081 |00:00:00.40 |       4 |      0 |
|*881 | 	     INDEX RANGE SCAN			       | V_INTERVENANTS_AK	 |    154K|	 1 |	 0   (0)|    100K|00:00:00.24 |       3 |      0 |
|*882 | 	   INDEX UNIQUE SCAN			       | IND_REFINDIV		 |  74081 |	 1 |	 1   (0)|  74081 |00:00:00.13 |   42954 |      0 |
| 883 | 	  TABLE ACCESS BY INDEX ROWID		       | G_INDIVIDU		 |  74081 |	 1 |	 2   (0)|  74081 |00:00:00.08 |    5436 |      0 |
| 884 |       VIEW					       |			 |	1 |	40 |   289   (1)|      7 |00:00:00.01 |      38 |      0 |
| 885 |        HASH GROUP BY				       |			 |	1 |	40 |   289   (1)|      7 |00:00:00.01 |      38 |      0 |
| 886 | 	VIEW					       | V_TDOMAINE		 |	1 |   1404 |   288   (0)|      7 |00:00:00.01 |      38 |      0 |
| 887 | 	 JOIN FILTER USE			       | :BF0000		 |	1 |	   |		|      7 |00:00:00.01 |      38 |      0 |
| 888 | 	  UNION-ALL				       |			 |	1 |	   |		|    191 |00:00:00.01 |      38 |      0 |
|*889 | 	   FILTER				       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 890 | 	    TABLE ACCESS BY INDEX ROWID BATCHED        | V_DOMAINE		 |	0 |	39 |	 8   (0)|      0 |00:00:00.01 |       0 |      0 |
|*891 | 	     INDEX RANGE SCAN			       | V_DOMAINE_TYPE_CODE_IDX |	0 |	39 |	 2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*892 | 	   FILTER				       |			 |	1 |	   |		|    191 |00:00:00.01 |      38 |      0 |
| 893 | 	    TABLE ACCESS BY INDEX ROWID BATCHED        | V_DOMAINE		 |	1 |	39 |	 8   (0)|    191 |00:00:00.01 |      38 |      0 |
|*894 | 	     INDEX RANGE SCAN			       | V_DOMAINE_TYPE_CODE_IDX |	1 |	39 |	 2   (0)|    191 |00:00:00.01 |       2 |      0 |
|*895 | 	   FILTER				       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 896 | 	    TABLE ACCESS BY INDEX ROWID BATCHED        | V_DOMAINE		 |	0 |	39 |	 8   (0)|      0 |00:00:00.01 |       0 |      0 |
|*897 | 	     INDEX RANGE SCAN			       | V_DOMAINE_TYPE_CODE_IDX |	0 |	39 |	 2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*898 | 	   FILTER				       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 899 | 	    TABLE ACCESS BY INDEX ROWID BATCHED        | V_DOMAINE		 |	0 |	39 |	 8   (0)|      0 |00:00:00.01 |       0 |      0 |
|*900 | 	     INDEX RANGE SCAN			       | V_DOMAINE_TYPE_CODE_IDX |	0 |	39 |	 2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*901 | 	   FILTER				       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 902 | 	    TABLE ACCESS BY INDEX ROWID BATCHED        | V_DOMAINE		 |	0 |	39 |	 8   (0)|      0 |00:00:00.01 |       0 |      0 |
|*903 | 	     INDEX RANGE SCAN			       | V_DOMAINE_TYPE_CODE_IDX |	0 |	39 |	 2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*904 | 	   FILTER				       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 905 | 	    TABLE ACCESS BY INDEX ROWID BATCHED        | V_DOMAINE		 |	0 |	39 |	 8   (0)|      0 |00:00:00.01 |       0 |      0 |
|*906 | 	     INDEX RANGE SCAN			       | V_DOMAINE_TYPE_CODE_IDX |	0 |	39 |	 2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*907 | 	   FILTER				       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 908 | 	    TABLE ACCESS BY INDEX ROWID BATCHED        | V_DOMAINE		 |	0 |	39 |	 8   (0)|      0 |00:00:00.01 |       0 |      0 |
|*909 | 	     INDEX RANGE SCAN			       | V_DOMAINE_TYPE_CODE_IDX |	0 |	39 |	 2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*910 | 	   FILTER				       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 911 | 	    TABLE ACCESS BY INDEX ROWID BATCHED        | V_DOMAINE		 |	0 |	39 |	 8   (0)|      0 |00:00:00.01 |       0 |      0 |
|*912 | 	     INDEX RANGE SCAN			       | V_DOMAINE_TYPE_CODE_IDX |	0 |	39 |	 2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*913 | 	   FILTER				       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 914 | 	    TABLE ACCESS BY INDEX ROWID BATCHED        | V_DOMAINE		 |	0 |	39 |	 8   (0)|      0 |00:00:00.01 |       0 |      0 |
|*915 | 	     INDEX RANGE SCAN			       | V_DOMAINE_TYPE_CODE_IDX |	0 |	39 |	 2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*916 | 	   FILTER				       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 917 | 	    TABLE ACCESS BY INDEX ROWID BATCHED        | V_DOMAINE		 |	0 |	39 |	 8   (0)|      0 |00:00:00.01 |       0 |      0 |
|*918 | 	     INDEX RANGE SCAN			       | V_DOMAINE_TYPE_CODE_IDX |	0 |	39 |	 2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*919 | 	   FILTER				       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 920 | 	    TABLE ACCESS BY INDEX ROWID BATCHED        | V_DOMAINE		 |	0 |	39 |	 8   (0)|      0 |00:00:00.01 |       0 |      0 |
|*921 | 	     INDEX RANGE SCAN			       | V_DOMAINE_TYPE_CODE_IDX |	0 |	39 |	 2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*922 | 	   FILTER				       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 923 | 	    TABLE ACCESS BY INDEX ROWID BATCHED        | V_DOMAINE		 |	0 |	39 |	 8   (0)|      0 |00:00:00.01 |       0 |      0 |
|*924 | 	     INDEX RANGE SCAN			       | V_DOMAINE_TYPE_CODE_IDX |	0 |	39 |	 2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*925 | 	   FILTER				       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 926 | 	    TABLE ACCESS BY INDEX ROWID BATCHED        | V_DOMAINE		 |	0 |	39 |	 8   (0)|      0 |00:00:00.01 |       0 |      0 |
|*927 | 	     INDEX RANGE SCAN			       | V_DOMAINE_TYPE_CODE_IDX |	0 |	39 |	 2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*928 | 	   FILTER				       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 929 | 	    TABLE ACCESS BY INDEX ROWID BATCHED        | V_DOMAINE		 |	0 |	39 |	 8   (0)|      0 |00:00:00.01 |       0 |      0 |
|*930 | 	     INDEX RANGE SCAN			       | V_DOMAINE_TYPE_CODE_IDX |	0 |	39 |	 2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*931 | 	   FILTER				       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 932 | 	    TABLE ACCESS BY INDEX ROWID BATCHED        | V_DOMAINE		 |	0 |	39 |	 8   (0)|      0 |00:00:00.01 |       0 |      0 |
|*933 | 	     INDEX RANGE SCAN			       | V_DOMAINE_TYPE_CODE_IDX |	0 |	39 |	 2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*934 | 	   FILTER				       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 935 | 	    TABLE ACCESS BY INDEX ROWID BATCHED        | V_DOMAINE		 |	0 |	39 |	 8   (0)|      0 |00:00:00.01 |       0 |      0 |
|*936 | 	     INDEX RANGE SCAN			       | V_DOMAINE_TYPE_CODE_IDX |	0 |	39 |	 2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*937 | 	   FILTER				       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 938 | 	    TABLE ACCESS BY INDEX ROWID BATCHED        | V_DOMAINE		 |	0 |	39 |	 8   (0)|      0 |00:00:00.01 |       0 |      0 |
|*939 | 	     INDEX RANGE SCAN			       | V_DOMAINE_TYPE_CODE_IDX |	0 |	39 |	 2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*940 | 	   FILTER				       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 941 | 	    TABLE ACCESS BY INDEX ROWID BATCHED        | V_DOMAINE		 |	0 |	39 |	 8   (0)|      0 |00:00:00.01 |       0 |      0 |
|*942 | 	     INDEX RANGE SCAN			       | V_DOMAINE_TYPE_CODE_IDX |	0 |	39 |	 2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*943 | 	   FILTER				       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 944 | 	    TABLE ACCESS BY INDEX ROWID BATCHED        | V_DOMAINE		 |	0 |	39 |	 8   (0)|      0 |00:00:00.01 |       0 |      0 |
|*945 | 	     INDEX RANGE SCAN			       | V_DOMAINE_TYPE_CODE_IDX |	0 |	39 |	 2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*946 | 	   FILTER				       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 947 | 	    TABLE ACCESS BY INDEX ROWID BATCHED        | V_DOMAINE		 |	0 |	39 |	 8   (0)|      0 |00:00:00.01 |       0 |      0 |
|*948 | 	     INDEX RANGE SCAN			       | V_DOMAINE_TYPE_CODE_IDX |	0 |	39 |	 2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*949 | 	   FILTER				       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 950 | 	    TABLE ACCESS BY INDEX ROWID BATCHED        | V_DOMAINE		 |	0 |	39 |	 8   (0)|      0 |00:00:00.01 |       0 |      0 |
|*951 | 	     INDEX RANGE SCAN			       | V_DOMAINE_TYPE_CODE_IDX |	0 |	39 |	 2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*952 | 	   FILTER				       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 953 | 	    TABLE ACCESS BY INDEX ROWID BATCHED        | V_DOMAINE		 |	0 |	39 |	 8   (0)|      0 |00:00:00.01 |       0 |      0 |
|*954 | 	     INDEX RANGE SCAN			       | V_DOMAINE_TYPE_CODE_IDX |	0 |	39 |	 2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*955 | 	   FILTER				       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 956 | 	    TABLE ACCESS BY INDEX ROWID BATCHED        | V_DOMAINE		 |	0 |	39 |	 8   (0)|      0 |00:00:00.01 |       0 |      0 |
|*957 | 	     INDEX RANGE SCAN			       | V_DOMAINE_TYPE_CODE_IDX |	0 |	39 |	 2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*958 | 	   FILTER				       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 959 | 	    TABLE ACCESS BY INDEX ROWID BATCHED        | V_DOMAINE		 |	0 |	39 |	 8   (0)|      0 |00:00:00.01 |       0 |      0 |
|*960 | 	     INDEX RANGE SCAN			       | V_DOMAINE_TYPE_CODE_IDX |	0 |	39 |	 2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*961 | 	   FILTER				       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 962 | 	    TABLE ACCESS BY INDEX ROWID BATCHED        | V_DOMAINE		 |	0 |	39 |	 8   (0)|      0 |00:00:00.01 |       0 |      0 |
|*963 | 	     INDEX RANGE SCAN			       | V_DOMAINE_TYPE_CODE_IDX |	0 |	39 |	 2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*964 | 	   FILTER				       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 965 | 	    TABLE ACCESS BY INDEX ROWID BATCHED        | V_DOMAINE		 |	0 |	39 |	 8   (0)|      0 |00:00:00.01 |       0 |      0 |
|*966 | 	     INDEX RANGE SCAN			       | V_DOMAINE_TYPE_CODE_IDX |	0 |	39 |	 2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*967 | 	   FILTER				       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 968 | 	    TABLE ACCESS BY INDEX ROWID BATCHED        | V_DOMAINE		 |	0 |	39 |	 8   (0)|      0 |00:00:00.01 |       0 |      0 |
|*969 | 	     INDEX RANGE SCAN			       | V_DOMAINE_TYPE_CODE_IDX |	0 |	39 |	 2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*970 | 	   FILTER				       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 971 | 	    TABLE ACCESS BY INDEX ROWID BATCHED        | V_DOMAINE		 |	0 |	39 |	 8   (0)|      0 |00:00:00.01 |       0 |      0 |
|*972 | 	     INDEX RANGE SCAN			       | V_DOMAINE_TYPE_CODE_IDX |	0 |	39 |	 2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*973 | 	   FILTER				       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 974 | 	    TABLE ACCESS BY INDEX ROWID BATCHED        | V_DOMAINE		 |	0 |	39 |	 8   (0)|      0 |00:00:00.01 |       0 |      0 |
|*975 | 	     INDEX RANGE SCAN			       | V_DOMAINE_TYPE_CODE_IDX |	0 |	39 |	 2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*976 | 	   FILTER				       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 977 | 	    TABLE ACCESS BY INDEX ROWID BATCHED        | V_DOMAINE		 |	0 |	39 |	 8   (0)|      0 |00:00:00.01 |       0 |      0 |
|*978 | 	     INDEX RANGE SCAN			       | V_DOMAINE_TYPE_CODE_IDX |	0 |	39 |	 2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*979 | 	   FILTER				       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 980 | 	    TABLE ACCESS BY INDEX ROWID BATCHED        | V_DOMAINE		 |	0 |	39 |	 8   (0)|      0 |00:00:00.01 |       0 |      0 |
|*981 | 	     INDEX RANGE SCAN			       | V_DOMAINE_TYPE_CODE_IDX |	0 |	39 |	 2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*982 | 	   FILTER				       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 983 | 	    TABLE ACCESS BY INDEX ROWID BATCHED        | V_DOMAINE		 |	0 |	39 |	 8   (0)|      0 |00:00:00.01 |       0 |      0 |
|*984 | 	     INDEX RANGE SCAN			       | V_DOMAINE_TYPE_CODE_IDX |	0 |	39 |	 2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*985 | 	   FILTER				       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 986 | 	    TABLE ACCESS BY INDEX ROWID BATCHED        | V_DOMAINE		 |	0 |	39 |	 8   (0)|      0 |00:00:00.01 |       0 |      0 |
|*987 | 	     INDEX RANGE SCAN			       | V_DOMAINE_TYPE_CODE_IDX |	0 |	39 |	 2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*988 | 	   FILTER				       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 989 | 	    TABLE ACCESS BY INDEX ROWID BATCHED        | V_DOMAINE		 |	0 |	39 |	 8   (0)|      0 |00:00:00.01 |       0 |      0 |
|*990 | 	     INDEX RANGE SCAN			       | V_DOMAINE_TYPE_CODE_IDX |	0 |	39 |	 2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*991 | 	   FILTER				       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 992 | 	    TABLE ACCESS BY INDEX ROWID BATCHED        | V_DOMAINE		 |	0 |	39 |	 8   (0)|      0 |00:00:00.01 |       0 |      0 |
|*993 | 	     INDEX RANGE SCAN			       | V_DOMAINE_TYPE_CODE_IDX |	0 |	39 |	 2   (0)|      0 |00:00:00.01 |       0 |      0 |
|*994 | 	   FILTER				       |			 |	1 |	   |		|      0 |00:00:00.01 |       0 |      0 |
| 995 | 	    TABLE ACCESS BY INDEX ROWID BATCHED        | V_DOMAINE		 |	0 |	39 |	 8   (0)|      0 |00:00:00.01 |       0 |      0 |
|*996 | 	     INDEX RANGE SCAN			       | V_DOMAINE_TYPE_CODE_IDX |	0 |	39 |	 2   (0)|      0 |00:00:00.01 |       0 |      0 |
------------------------------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   3 - filter('AL'=:B1)
   5 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='SE')
   6 - filter('AN'=:B1)
   8 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='SE')
   9 - filter('AR'=:B1)
  11 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='SE')
  12 - filter('BG'=:B1)
  14 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='SE')
  15 - filter('BR'=:B1)
  17 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='SE')
  18 - filter('CE'=:B1)
  20 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='SE')
  21 - filter('CH'=:B1)
  23 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='SE')
  24 - filter('CS'=:B1)
  26 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='SE')
  27 - filter('DA'=:B1)
  29 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='SE')
  30 - filter('EL'=:B1)
  32 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='SE')
  33 - filter('ES'=:B1)
  35 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='SE')
  36 - filter('ET'=:B1)
  38 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='SE')
  39 - filter('FI'=:B1)
  41 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='SE')
  42 - filter('FR'=:B1)
  44 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='SE')
  45 - filter('HR'=:B1)
  47 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='SE')
  48 - filter('HU'=:B1)
  50 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='SE')
  51 - filter('IT'=:B1)
  53 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='SE')
  54 - filter('IW'=:B1)
  56 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='SE')
  57 - filter('JA'=:B1)
  59 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='SE')
  60 - filter('LT'=:B1)
  62 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='SE')
  63 - filter('LV'=:B1)
  65 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='SE')
  66 - filter('MX'=:B1)
  68 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='SE')
  69 - filter('NL'=:B1)
  71 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='SE')
  72 - filter('NO'=:B1)
  74 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='SE')
  75 - filter('PL'=:B1)
  77 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='SE')
  78 - filter('PT'=:B1)
  80 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='SE')
  81 - filter('RO'=:B1)
  83 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='SE')
  84 - filter('RU'=:B1)
  86 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='SE')
  87 - filter('SK'=:B1)
  89 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='SE')
  90 - filter('SL'=:B1)
  92 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='SE')
  93 - filter('SR'=:B1)
  95 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='SE')
  96 - filter('SV'=:B1)
  98 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='SE')
  99 - filter('TR'=:B1)
 101 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='SE')
 102 - filter('US'=:B1)
 104 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='SE')
 105 - filter('VI'=:B1)
 107 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='SE')
 108 - filter('ZH'=:B1)
 110 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='SE')
 111 - access("E"."ALERTE_ID"=:B1)
 114 - filter('AL'=:B1)
 116 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='EC')
 117 - filter('AN'=:B1)
 119 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='EC')
 120 - filter('AR'=:B1)
 122 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='EC')
 123 - filter('BG'=:B1)
 125 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='EC')
 126 - filter('BR'=:B1)
 128 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='EC')
 129 - filter('CE'=:B1)
 131 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='EC')
 132 - filter('CH'=:B1)
 134 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='EC')
 135 - filter('CS'=:B1)
 137 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='EC')
 138 - filter('DA'=:B1)
 140 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='EC')
 141 - filter('EL'=:B1)
 143 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='EC')
 144 - filter('ES'=:B1)
 146 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='EC')
 147 - filter('ET'=:B1)
 149 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='EC')
 150 - filter('FI'=:B1)
 152 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='EC')
 153 - filter('FR'=:B1)
 155 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='EC')
 156 - filter('HR'=:B1)
 158 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='EC')
 159 - filter('HU'=:B1)
 161 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='EC')
 162 - filter('IT'=:B1)
 164 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='EC')
 165 - filter('IW'=:B1)
 167 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='EC')
 168 - filter('JA'=:B1)
 170 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='EC')
 171 - filter('LT'=:B1)
 173 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='EC')
 174 - filter('LV'=:B1)
 176 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='EC')
 177 - filter('MX'=:B1)
 179 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='EC')
 180 - filter('NL'=:B1)
 182 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='EC')
 183 - filter('NO'=:B1)
 185 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='EC')
 186 - filter('PL'=:B1)
 188 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='EC')
 189 - filter('PT'=:B1)
 191 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='EC')
 192 - filter('RO'=:B1)
 194 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='EC')
 195 - filter('RU'=:B1)
 197 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='EC')
 198 - filter('SK'=:B1)
 200 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='EC')
 201 - filter('SL'=:B1)
 203 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='EC')
 204 - filter('SR'=:B1)
 206 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='EC')
 207 - filter('SV'=:B1)
 209 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='EC')
 210 - filter('TR'=:B1)
 212 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='EC')
 213 - filter('US'=:B1)
 215 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='EC')
 216 - filter('VI'=:B1)
 218 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='EC')
 219 - filter('ZH'=:B1)
 221 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='EC')
 222 - access("E"."ALERTE_ID"=:B1)
 225 - filter('AL'=:B1)
 227 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='AF')
 228 - filter('AN'=:B1)
 230 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='AF')
 231 - filter('AR'=:B1)
 233 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='AF')
 234 - filter('BG'=:B1)
 236 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='AF')
 237 - filter('BR'=:B1)
 239 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='AF')
 240 - filter('CE'=:B1)
 242 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='AF')
 243 - filter('CH'=:B1)
 245 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='AF')
 246 - filter('CS'=:B1)
 248 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='AF')
 249 - filter('DA'=:B1)
 251 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='AF')
 252 - filter('EL'=:B1)
 254 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='AF')
 255 - filter('ES'=:B1)
 257 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='AF')
 258 - filter('ET'=:B1)
 260 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='AF')
 261 - filter('FI'=:B1)
 263 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='AF')
 264 - filter('FR'=:B1)
 266 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='AF')
 267 - filter('HR'=:B1)
 269 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='AF')
 270 - filter('HU'=:B1)
 272 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='AF')
 273 - filter('IT'=:B1)
 275 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='AF')
 276 - filter('IW'=:B1)
 278 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='AF')
 279 - filter('JA'=:B1)
 281 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='AF')
 282 - filter('LT'=:B1)
 284 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='AF')
 285 - filter('LV'=:B1)
 287 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='AF')
 288 - filter('MX'=:B1)
 290 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='AF')
 291 - filter('NL'=:B1)
 293 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='AF')
 294 - filter('NO'=:B1)
 296 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='AF')
 297 - filter('PL'=:B1)
 299 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='AF')
 300 - filter('PT'=:B1)
 302 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='AF')
 303 - filter('RO'=:B1)
 305 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='AF')
 306 - filter('RU'=:B1)
 308 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='AF')
 309 - filter('SK'=:B1)
 311 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='AF')
 312 - filter('SL'=:B1)
 314 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='AF')
 315 - filter('SR'=:B1)
 317 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='AF')
 318 - filter('SV'=:B1)
 320 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='AF')
 321 - filter('TR'=:B1)
 323 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='AF')
 324 - filter('US'=:B1)
 326 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='AF')
 327 - filter('VI'=:B1)
 329 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='AF')
 330 - filter('ZH'=:B1)
 332 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='AF')
 335 - filter("REFHIERARCHIE" IS NOT NULL)
 336 - access("ANCREFDOSS"=:B1)
 337 - access("REFDOSS"="REFHIERARCHIE")
 338 - filter("CATEGDOSS"='COMPTE DB CTR')
 339 - filter( IS NOT NULL)
 341 - access("CATEGDOSS"='COMPTE DB CTR')
 342 - filter("REFHIERARCHIE"=:B1)
 343 - access("ANCREFDOSS"=:B1)
 344 - access("ALERTE_ID"=:B1)
 348 - access("TD"."ALERTE_ID"=:B1)
 351 - filter('AL'=:B1)
 353 - access("TYPE"='DV_AGENDA_DETAILS' AND "ABREV"="TD"."TYPE_INFO")
 354 - filter('AN'=:B1)
 356 - access("TYPE"='DV_AGENDA_DETAILS' AND "ABREV"="TD"."TYPE_INFO")
 357 - filter('AR'=:B1)
 359 - access("TYPE"='DV_AGENDA_DETAILS' AND "ABREV"="TD"."TYPE_INFO")
 360 - filter('BG'=:B1)
 362 - access("TYPE"='DV_AGENDA_DETAILS' AND "ABREV"="TD"."TYPE_INFO")
 363 - filter('BR'=:B1)
 365 - access("TYPE"='DV_AGENDA_DETAILS' AND "ABREV"="TD"."TYPE_INFO")
 366 - filter('CE'=:B1)
 368 - access("TYPE"='DV_AGENDA_DETAILS' AND "ABREV"="TD"."TYPE_INFO")
 369 - filter('CH'=:B1)
 371 - access("TYPE"='DV_AGENDA_DETAILS' AND "ABREV"="TD"."TYPE_INFO")
 372 - filter('CS'=:B1)
 374 - access("TYPE"='DV_AGENDA_DETAILS' AND "ABREV"="TD"."TYPE_INFO")
 375 - filter('DA'=:B1)
 377 - access("TYPE"='DV_AGENDA_DETAILS' AND "ABREV"="TD"."TYPE_INFO")
 378 - filter('EL'=:B1)
 380 - access("TYPE"='DV_AGENDA_DETAILS' AND "ABREV"="TD"."TYPE_INFO")
 381 - filter('ES'=:B1)
 383 - access("TYPE"='DV_AGENDA_DETAILS' AND "ABREV"="TD"."TYPE_INFO")
 384 - filter('ET'=:B1)
 386 - access("TYPE"='DV_AGENDA_DETAILS' AND "ABREV"="TD"."TYPE_INFO")
 387 - filter('FI'=:B1)
 389 - access("TYPE"='DV_AGENDA_DETAILS' AND "ABREV"="TD"."TYPE_INFO")
 390 - filter('FR'=:B1)
 392 - access("TYPE"='DV_AGENDA_DETAILS' AND "ABREV"="TD"."TYPE_INFO")
 393 - filter('HR'=:B1)
 395 - access("TYPE"='DV_AGENDA_DETAILS' AND "ABREV"="TD"."TYPE_INFO")
 396 - filter('HU'=:B1)
 398 - access("TYPE"='DV_AGENDA_DETAILS' AND "ABREV"="TD"."TYPE_INFO")
 399 - filter('IT'=:B1)
 401 - access("TYPE"='DV_AGENDA_DETAILS' AND "ABREV"="TD"."TYPE_INFO")
 402 - filter('IW'=:B1)
 404 - access("TYPE"='DV_AGENDA_DETAILS' AND "ABREV"="TD"."TYPE_INFO")
 405 - filter('JA'=:B1)
 407 - access("TYPE"='DV_AGENDA_DETAILS' AND "ABREV"="TD"."TYPE_INFO")
 408 - filter('LT'=:B1)
 410 - access("TYPE"='DV_AGENDA_DETAILS' AND "ABREV"="TD"."TYPE_INFO")
 411 - filter('LV'=:B1)
 413 - access("TYPE"='DV_AGENDA_DETAILS' AND "ABREV"="TD"."TYPE_INFO")
 414 - filter('MX'=:B1)
 416 - access("TYPE"='DV_AGENDA_DETAILS' AND "ABREV"="TD"."TYPE_INFO")
 417 - filter('NL'=:B1)
 419 - access("TYPE"='DV_AGENDA_DETAILS' AND "ABREV"="TD"."TYPE_INFO")
 420 - filter('NO'=:B1)
 422 - access("TYPE"='DV_AGENDA_DETAILS' AND "ABREV"="TD"."TYPE_INFO")
 423 - filter('PL'=:B1)
 425 - access("TYPE"='DV_AGENDA_DETAILS' AND "ABREV"="TD"."TYPE_INFO")
 426 - filter('PT'=:B1)
 428 - access("TYPE"='DV_AGENDA_DETAILS' AND "ABREV"="TD"."TYPE_INFO")
 429 - filter('RO'=:B1)
 431 - access("TYPE"='DV_AGENDA_DETAILS' AND "ABREV"="TD"."TYPE_INFO")
 432 - filter('RU'=:B1)
 434 - access("TYPE"='DV_AGENDA_DETAILS' AND "ABREV"="TD"."TYPE_INFO")
 435 - filter('SK'=:B1)
 437 - access("TYPE"='DV_AGENDA_DETAILS' AND "ABREV"="TD"."TYPE_INFO")
 438 - filter('SL'=:B1)
 440 - access("TYPE"='DV_AGENDA_DETAILS' AND "ABREV"="TD"."TYPE_INFO")
 441 - filter('SR'=:B1)
 443 - access("TYPE"='DV_AGENDA_DETAILS' AND "ABREV"="TD"."TYPE_INFO")
 444 - filter('SV'=:B1)
 446 - access("TYPE"='DV_AGENDA_DETAILS' AND "ABREV"="TD"."TYPE_INFO")
 447 - filter('TR'=:B1)
 449 - access("TYPE"='DV_AGENDA_DETAILS' AND "ABREV"="TD"."TYPE_INFO")
 450 - filter('US'=:B1)
 452 - access("TYPE"='DV_AGENDA_DETAILS' AND "ABREV"="TD"."TYPE_INFO")
 453 - filter('VI'=:B1)
 455 - access("TYPE"='DV_AGENDA_DETAILS' AND "ABREV"="TD"."TYPE_INFO")
 456 - filter('ZH'=:B1)
 458 - access("TYPE"='DV_AGENDA_DETAILS' AND "ABREV"="TD"."TYPE_INFO")
 461 - filter("REFHIERARCHIE" IS NOT NULL)
 462 - access("ANCREFDOSS"=:B1)
 463 - access("REFDOSS"="REFHIERARCHIE")
 464 - filter("CATEGDOSS"='COMPTE DB CTR')
 465 - filter(ROWNUM=1)
 470 - filter("D2"."REFHIERARCHIE" IS NOT NULL)
 471 - access("D2"."ANCREFDOSS"=:B1)
 472 - filter("D1"."CATEGDOSS"='COMPTE DB CTR')
 473 - access("D1"."REFDOSS"="D2"."REFHIERARCHIE")
 474 - access("TI"."REFDOSS"="D1"."REFDOSS" AND "TI"."REFTYPE"='DB')
 475 - access("I"."REFINDIVIDU"="TI"."REFINDIVIDU")
 477 - filter(ROWNUM=1)
 482 - access("GD"."ANCREFDOSS"=:B1)
 483 - access("TI"."REFDOSS"="GD"."REFDOSS" AND "TI"."REFTYPE"='DB')
 484 - access("I"."REFINDIVIDU"="TI"."REFINDIVIDU")
 486 - filter("RNUM">=:B8)
 487 - filter(ROWNUM<=:B7)
 489 - filter(ROWNUM<=:B7)
 490 - access("V"."ABREV"=CASE	WHEN ((:B3='FACTORING') AND ("GD"."REFFACTOR" IS NOT NULL) AND ("V1"."PLACE"=1)) THEN
	      "FTR_FIN_FACTOR"."GETCURRENCY"("GD"."REFFACTOR") WHEN ("V1"."PLACE"=2) THEN "TA"."DEVISE_ALERTE" ELSE NVL("GD"."DEVISE","TA"."DEVISE_ALERTE") END )
 494 - access("VGR"."VALEUR"="GP"."GROUPE")
 496 - access("TA"."TYPENTITE"="V"."ABREV")
 498 - access("TA"."TYPENCOUR"="V1"."VALEUR")
 508 - access("GIP"."REFINDIVIDU"=:B4 AND "GIP"."TYPE"='appel_nonse')
 512 - access("A"."JOUR"=TO_NUMBER(TO_CHAR(SYSDATE@!,'j')))
       filter("A"."REFPERSO" IS NOT NULL)
 513 - access("A"."REFPERSO"="P"."REFPERSO")
 514 - filter("P"."REFREMPL"=:B5)
 516 - access("GI"."REFINDIVIDU"="STR1")
 518 - access("GP"."REFINDIVIDU"="GI"."REFINDIVIDU")
 519 - filter(TRUNC(INTERNAL_FUNCTION("TA"."DTCREATION_DT"))>=TO_DATE(TO_CHAR(TO_DATE(:B6,'yyyy-mm-dd'),'RRRRMMDD'),'RRRRMMDD'))
 520 - access("TA"."CATPERSO"="GP"."REFPERSO")
 522 - access("TA"."REFDOSS"="GD"."REFDOSS")
 523 - filter("ABREV6"='O')
 524 - access("VALEUR"="TA"."TYPENCOUR" AND "TYPE"='DV_AGENDA_NON_SE')
 530 - filter('AL'=:B1)
 532 - access("TYPE"='DV_AGENDA_NON_SE')
 533 - filter('AN'=:B1)
 535 - access("TYPE"='DV_AGENDA_NON_SE')
 536 - filter('AR'=:B1)
 538 - access("TYPE"='DV_AGENDA_NON_SE')
 539 - filter('BG'=:B1)
 541 - access("TYPE"='DV_AGENDA_NON_SE')
 542 - filter('BR'=:B1)
 544 - access("TYPE"='DV_AGENDA_NON_SE')
 545 - filter('CE'=:B1)
 547 - access("TYPE"='DV_AGENDA_NON_SE')
 548 - filter('CH'=:B1)
 550 - access("TYPE"='DV_AGENDA_NON_SE')
 551 - filter('CS'=:B1)
 553 - access("TYPE"='DV_AGENDA_NON_SE')
 554 - filter('DA'=:B1)
 556 - access("TYPE"='DV_AGENDA_NON_SE')
 557 - filter('EL'=:B1)
 559 - access("TYPE"='DV_AGENDA_NON_SE')
 560 - filter('ES'=:B1)
 562 - access("TYPE"='DV_AGENDA_NON_SE')
 563 - filter('ET'=:B1)
 565 - access("TYPE"='DV_AGENDA_NON_SE')
 566 - filter('FI'=:B1)
 568 - access("TYPE"='DV_AGENDA_NON_SE')
 569 - filter('FR'=:B1)
 571 - access("TYPE"='DV_AGENDA_NON_SE')
 572 - filter('HR'=:B1)
 574 - access("TYPE"='DV_AGENDA_NON_SE')
 575 - filter('HU'=:B1)
 577 - access("TYPE"='DV_AGENDA_NON_SE')
 578 - filter('IT'=:B1)
 580 - access("TYPE"='DV_AGENDA_NON_SE')
 581 - filter('IW'=:B1)
 583 - access("TYPE"='DV_AGENDA_NON_SE')
 584 - filter('JA'=:B1)
 586 - access("TYPE"='DV_AGENDA_NON_SE')
 587 - filter('LT'=:B1)
 589 - access("TYPE"='DV_AGENDA_NON_SE')
 590 - filter('LV'=:B1)
 592 - access("TYPE"='DV_AGENDA_NON_SE')
 593 - filter('MX'=:B1)
 595 - access("TYPE"='DV_AGENDA_NON_SE')
 596 - filter('NL'=:B1)
 598 - access("TYPE"='DV_AGENDA_NON_SE')
 599 - filter('NO'=:B1)
 601 - access("TYPE"='DV_AGENDA_NON_SE')
 602 - filter('PL'=:B1)
 604 - access("TYPE"='DV_AGENDA_NON_SE')
 605 - filter('PT'=:B1)
 607 - access("TYPE"='DV_AGENDA_NON_SE')
 608 - filter('RO'=:B1)
 610 - access("TYPE"='DV_AGENDA_NON_SE')
 611 - filter('RU'=:B1)
 613 - access("TYPE"='DV_AGENDA_NON_SE')
 614 - filter('SK'=:B1)
 616 - access("TYPE"='DV_AGENDA_NON_SE')
 617 - filter('SL'=:B1)
 619 - access("TYPE"='DV_AGENDA_NON_SE')
 620 - filter('SR'=:B1)
 622 - access("TYPE"='DV_AGENDA_NON_SE')
 623 - filter('SV'=:B1)
 625 - access("TYPE"='DV_AGENDA_NON_SE')
 626 - filter('TR'=:B1)
 628 - access("TYPE"='DV_AGENDA_NON_SE')
 629 - filter('US'=:B1)
 631 - access("TYPE"='DV_AGENDA_NON_SE')
 632 - filter('VI'=:B1)
 634 - access("TYPE"='DV_AGENDA_NON_SE')
 635 - filter('ZH'=:B1)
 637 - access("TYPE"='DV_AGENDA_NON_SE')
 643 - filter('AL'=:B1)
 645 - access("TYPE"='DV_TYPE_APPEL')
 646 - filter('AN'=:B1)
 648 - access("TYPE"='DV_TYPE_APPEL')
 649 - filter('AR'=:B1)
 651 - access("TYPE"='DV_TYPE_APPEL')
 652 - filter('BG'=:B1)
 654 - access("TYPE"='DV_TYPE_APPEL')
 655 - filter('BR'=:B1)
 657 - access("TYPE"='DV_TYPE_APPEL')
 658 - filter('CE'=:B1)
 660 - access("TYPE"='DV_TYPE_APPEL')
 661 - filter('CH'=:B1)
 663 - access("TYPE"='DV_TYPE_APPEL')
 664 - filter('CS'=:B1)
 666 - access("TYPE"='DV_TYPE_APPEL')
 667 - filter('DA'=:B1)
 669 - access("TYPE"='DV_TYPE_APPEL')
 670 - filter('EL'=:B1)
 672 - access("TYPE"='DV_TYPE_APPEL')
 673 - filter('ES'=:B1)
 675 - access("TYPE"='DV_TYPE_APPEL')
 676 - filter('ET'=:B1)
 678 - access("TYPE"='DV_TYPE_APPEL')
 679 - filter('FI'=:B1)
 681 - access("TYPE"='DV_TYPE_APPEL')
 682 - filter('FR'=:B1)
 684 - access("TYPE"='DV_TYPE_APPEL')
 685 - filter('HR'=:B1)
 687 - access("TYPE"='DV_TYPE_APPEL')
 688 - filter('HU'=:B1)
 690 - access("TYPE"='DV_TYPE_APPEL')
 691 - filter('IT'=:B1)
 693 - access("TYPE"='DV_TYPE_APPEL')
 694 - filter('IW'=:B1)
 696 - access("TYPE"='DV_TYPE_APPEL')
 697 - filter('JA'=:B1)
 699 - access("TYPE"='DV_TYPE_APPEL')
 700 - filter('LT'=:B1)
 702 - access("TYPE"='DV_TYPE_APPEL')
 703 - filter('LV'=:B1)
 705 - access("TYPE"='DV_TYPE_APPEL')
 706 - filter('MX'=:B1)
 708 - access("TYPE"='DV_TYPE_APPEL')
 709 - filter('NL'=:B1)
 711 - access("TYPE"='DV_TYPE_APPEL')
 712 - filter('NO'=:B1)
 714 - access("TYPE"='DV_TYPE_APPEL')
 715 - filter('PL'=:B1)
 717 - access("TYPE"='DV_TYPE_APPEL')
 718 - filter('PT'=:B1)
 720 - access("TYPE"='DV_TYPE_APPEL')
 721 - filter('RO'=:B1)
 723 - access("TYPE"='DV_TYPE_APPEL')
 724 - filter('RU'=:B1)
 726 - access("TYPE"='DV_TYPE_APPEL')
 727 - filter('SK'=:B1)
 729 - access("TYPE"='DV_TYPE_APPEL')
 730 - filter('SL'=:B1)
 732 - access("TYPE"='DV_TYPE_APPEL')
 733 - filter('SR'=:B1)
 735 - access("TYPE"='DV_TYPE_APPEL')
 736 - filter('SV'=:B1)
 738 - access("TYPE"='DV_TYPE_APPEL')
 739 - filter('TR'=:B1)
 741 - access("TYPE"='DV_TYPE_APPEL')
 742 - filter('US'=:B1)
 744 - access("TYPE"='DV_TYPE_APPEL')
 745 - filter('VI'=:B1)
 747 - access("TYPE"='DV_TYPE_APPEL')
 748 - filter('ZH'=:B1)
 750 - access("TYPE"='DV_TYPE_APPEL')
 756 - filter('AL'=:B1)
 758 - access("TYPE"='GROUPE')
 759 - filter('AN'=:B1)
 761 - access("TYPE"='GROUPE')
 762 - filter('AR'=:B1)
 764 - access("TYPE"='GROUPE')
 765 - filter('BG'=:B1)
 767 - access("TYPE"='GROUPE')
 768 - filter('BR'=:B1)
 770 - access("TYPE"='GROUPE')
 771 - filter('CE'=:B1)
 773 - access("TYPE"='GROUPE')
 774 - filter('CH'=:B1)
 776 - access("TYPE"='GROUPE')
 777 - filter('CS'=:B1)
 779 - access("TYPE"='GROUPE')
 780 - filter('DA'=:B1)
 782 - access("TYPE"='GROUPE')
 783 - filter('EL'=:B1)
 785 - access("TYPE"='GROUPE')
 786 - filter('ES'=:B1)
 788 - access("TYPE"='GROUPE')
 789 - filter('ET'=:B1)
 791 - access("TYPE"='GROUPE')
 792 - filter('FI'=:B1)
 794 - access("TYPE"='GROUPE')
 795 - filter('FR'=:B1)
 797 - access("TYPE"='GROUPE')
 798 - filter('HR'=:B1)
 800 - access("TYPE"='GROUPE')
 801 - filter('HU'=:B1)
 803 - access("TYPE"='GROUPE')
 804 - filter('IT'=:B1)
 806 - access("TYPE"='GROUPE')
 807 - filter('IW'=:B1)
 809 - access("TYPE"='GROUPE')
 810 - filter('JA'=:B1)
 812 - access("TYPE"='GROUPE')
 813 - filter('LT'=:B1)
 815 - access("TYPE"='GROUPE')
 816 - filter('LV'=:B1)
 818 - access("TYPE"='GROUPE')
 819 - filter('MX'=:B1)
 821 - access("TYPE"='GROUPE')
 822 - filter('NL'=:B1)
 824 - access("TYPE"='GROUPE')
 825 - filter('NO'=:B1)
 827 - access("TYPE"='GROUPE')
 828 - filter('PL'=:B1)
 830 - access("TYPE"='GROUPE')
 831 - filter('PT'=:B1)
 833 - access("TYPE"='GROUPE')
 834 - filter('RO'=:B1)
 836 - access("TYPE"='GROUPE')
 837 - filter('RU'=:B1)
 839 - access("TYPE"='GROUPE')
 840 - filter('SK'=:B1)
 842 - access("TYPE"='GROUPE')
 843 - filter('SL'=:B1)
 845 - access("TYPE"='GROUPE')
 846 - filter('SR'=:B1)
 848 - access("TYPE"='GROUPE')
 849 - filter('SV'=:B1)
 851 - access("TYPE"='GROUPE')
 852 - filter('TR'=:B1)
 854 - access("TYPE"='GROUPE')
 855 - filter('US'=:B1)
 857 - access("TYPE"='GROUPE')
 858 - filter('VI'=:B1)
 860 - access("TYPE"='GROUPE')
 861 - filter('ZH'=:B1)
 863 - access("TYPE"='GROUPE')
 867 - access("T"."REFDOSS"="TA"."REFDOSS" AND "T"."REFTYPE"='CL')
 868 - access("I"."REFINDIVIDU"="T"."REFINDIVIDU")
 877 - access("G"."REFDOSS"="TA"."REFDOSS")
 878 - access("D"."TYPE"='categdoss' AND "D"."VALEUR"="G"."CATEGDOSS")
       filter(("D"."VALEUR"="G"."CATEGDOSS" AND "D"."ABREV" IS NOT NULL))
 879 - access("TI"."REFDOSS"="TA"."REFDOSS")
       filter("TI"."REFDOSS"="G"."REFDOSS")
 880 - filter("I"."REFTYPE_AFF"='CLI')
 881 - access("I"."CATEGDOSS"="D"."ABREV" AND "I"."REFTYPE_BD"="TI"."REFTYPE")
 882 - access("TI"."REFINDIVIDU"="GI"."REFINDIVIDU")
 889 - filter('AL'=:B1)
 891 - access("TYPE"='DEVISE')
 892 - filter('AN'=:B1)
 894 - access("TYPE"='DEVISE')
 895 - filter('AR'=:B1)
 897 - access("TYPE"='DEVISE')
 898 - filter('BG'=:B1)
 900 - access("TYPE"='DEVISE')
 901 - filter('BR'=:B1)
 903 - access("TYPE"='DEVISE')
 904 - filter('CE'=:B1)
 906 - access("TYPE"='DEVISE')
 907 - filter('CH'=:B1)
 909 - access("TYPE"='DEVISE')
 910 - filter('CS'=:B1)
 912 - access("TYPE"='DEVISE')
 913 - filter('DA'=:B1)
 915 - access("TYPE"='DEVISE')
 916 - filter('EL'=:B1)
 918 - access("TYPE"='DEVISE')
 919 - filter('ES'=:B1)
 921 - access("TYPE"='DEVISE')
 922 - filter('ET'=:B1)
 924 - access("TYPE"='DEVISE')
 925 - filter('FI'=:B1)
 927 - access("TYPE"='DEVISE')
 928 - filter('FR'=:B1)
 930 - access("TYPE"='DEVISE')
 931 - filter('HR'=:B1)
 933 - access("TYPE"='DEVISE')
 934 - filter('HU'=:B1)
 936 - access("TYPE"='DEVISE')
 937 - filter('IT'=:B1)
 939 - access("TYPE"='DEVISE')
 940 - filter('IW'=:B1)
 942 - access("TYPE"='DEVISE')
 943 - filter('JA'=:B1)
 945 - access("TYPE"='DEVISE')
 946 - filter('LT'=:B1)
 948 - access("TYPE"='DEVISE')
 949 - filter('LV'=:B1)
 951 - access("TYPE"='DEVISE')
 952 - filter('MX'=:B1)
 954 - access("TYPE"='DEVISE')
 955 - filter('NL'=:B1)
 957 - access("TYPE"='DEVISE')
 958 - filter('NO'=:B1)
 960 - access("TYPE"='DEVISE')
 961 - filter('PL'=:B1)
 963 - access("TYPE"='DEVISE')
 964 - filter('PT'=:B1)
 966 - access("TYPE"='DEVISE')
 967 - filter('RO'=:B1)
 969 - access("TYPE"='DEVISE')
 970 - filter('RU'=:B1)
 972 - access("TYPE"='DEVISE')
 973 - filter('SK'=:B1)
 975 - access("TYPE"='DEVISE')
 976 - filter('SL'=:B1)
 978 - access("TYPE"='DEVISE')
 979 - filter('SR'=:B1)
 981 - access("TYPE"='DEVISE')
 982 - filter('SV'=:B1)
 984 - access("TYPE"='DEVISE')
 985 - filter('TR'=:B1)
 987 - access("TYPE"='DEVISE')
 988 - filter('US'=:B1)
 990 - access("TYPE"='DEVISE')
 991 - filter('VI'=:B1)
 993 - access("TYPE"='DEVISE')
 994 - filter('ZH'=:B1)
 996 - access("TYPE"='DEVISE')
*/
/********************************OLD Metrics***************************************/

/********************************New SQL*******************************************/

SELECT /*+ OPT_PARAM('_optimizer_use_feedback' 'false') */
 *
  FROM (SELECT /*+ first_rows(2001)*/
         foo.*, ROWNUM rnum
          FROM (SELECT displayStage      displayStage,
                       amount            amount,
                       creator           creator,
                       contract          contract,
                       caseRefIMX        caseRefIMX,
                       creationDate      creationDate,
                       additionalDetails additionalDetails,
                       typeStage         typeStage,
                       nbAlertProcessed  nbAlertProcessed,
                       reference         reference,
                       uniqueRowId       uniqueRowId,
                       caseRef           caseRef,
                       readyToExport     readyToExport,
                       stage             stage,
                       intRef            intRef,
                       nameManager       nameManager,
                       processDate       processDate,
                       nameDebtor        nameDebtor,
                       displayTypeStage  displayTypeStage,
                       idManager         idManager,
                       currency          currency,
                       groupManager      groupManager,
                       alertId           alertId,
                       nameClient        nameClient
                  FROM (SELECT groupManager groupManager,
                               idManager idManager,
                               namemanager nameManager,
                               typestage typeStage,
                               displayTypeStage displayTypeStage,
                               stage stage,
                               displayStage displayStage,
                               caseref caseRef,
                               caseRefIMX caseRefIMX,
                               nameclient nameClient,
                               reference reference,
                               amount amount,
                               processdate processDate,
                               creationDate creationDate,
                               intref intRef,
                               CASE
                                 WHEN EXISTS
                                  (SELECT 1
                                         FROM g_dossier
                                        WHERE refdoss IN
                                              (SELECT refhierarchie
                                                 FROM g_dossier
                                                WHERE ancrefdoss = contract)
                                          AND categdoss = 'COMPTE DB CTR') THEN
                                  (SELECT ancrefdoss
                                     FROM g_dossier
                                    WHERE refdoss IN
                                          (SELECT refhierarchie
                                             FROM g_dossier
                                            WHERE ancrefdoss = t.contract)
                                      AND categdoss = 'COMPTE DB CTR')
                                 ELSE
                                  t.contract
                               END contract,
                               CASE
                                 WHEN EXISTS
                                  (SELECT 1
                                         FROM g_dossier
                                        WHERE refdoss IN
                                              (SELECT refhierarchie
                                                 FROM g_dossier
                                                WHERE ancrefdoss = contract)
                                          AND categdoss = 'COMPTE DB CTR') THEN
                                  (SELECT I.nom
                                     FROM g_individu     I,
                                          t_intervenants TI,
                                          g_dossier      D1,
                                          g_dossier      D2
                                    WHERE TI.refdoss = D1.refdoss
                                      AND D1.refdoss = D2.refhierarchie
                                      AND D2.ancrefdoss = t.contract
                                      AND D1.categdoss = 'COMPTE DB CTR'
                                      AND I.refindividu = TI.refindividu
                                      AND TI.reftype = 'DB'
                                      AND ROWNUM = 1)
                                 ELSE
                                  (SELECT I.nom
                                     FROM g_individu     I,
                                          t_intervenants TI,
                                          g_dossier      GD
                                    WHERE TI.refdoss = GD.refdoss
                                      AND GD.ancrefdoss = t.contract
                                      AND I.refindividu = TI.refindividu
                                      AND TI.reftype = 'DB'
                                      AND ROWNUM = 1)
                               END nameDebtor,
                               alerte_id alertId,
                               un_key uniqueRowId,
                               readyToExport readyToExport,
                               v.abrev_trad currency,
                               creator creator,
                               nbAlertProcessed nbAlertProcessed,
                               CASE
                                 WHEN EXISTS
                                  (SELECT 1
                                         FROM t_alert_not_es_det
                                        WHERE alerte_id = t.alerte_id) THEN
                                  (SELECT LISTAGG(valeur, '; ') WITHIN GROUP(ORDER BY order_info)
                                     FROM (SELECT v.valeur_trad || ' ' ||
                                                  td.value_info valeur,
                                                  order_info
                                             FROM t_alert_not_es_det td,
                                                  v_tdomaine         v
                                            WHERE v.type = 'DV_AGENDA_DETAILS'
                                              AND td.type_info = v.abrev
                                              AND v.langue = :B1
                                              AND td.alerte_id = t.alerte_id))
                               END additionalDetails
                          FROM (SELECT ta.ROWID un_key,
                                       NVL(vgr.valeur_trad, gp.groupe) groupManager,
                                       ta.catperso idManager,
                                       DECODE(gi.prenom,
                                              NULL,
                                              gi.nom,
                                              gi.prenom || ' ' || gi.nom) namemanager,
                                       NVL(v.valeur_trad, ta.typentite) displayTypeStage,
                                       ta.typentite typestage,
                                       ta.refentite intref,
                                       ta.refext reference,
                                       ta.refdoss caseRefIMX,
                                       ta.refctr contract,
                                       NVL(v1.valeur_trad, ta.typencour) displayStage,
                                       ta.typencour stage,
                                       ta.montant amount,
                                       ta.dttrait_dt processdate,
                                       ta.dtcreation_dt creationDate,
                                       DECODE(:B2,
                                              'C204',
                                              ta.refctr,
                                              'C405',
                                              ta.refdoss,
                                              'C202',
                                              ta.refdoss,
                                              NVL(gd.ancrefdoss, gd.refdoss)) caseref,
                                       ta.alerte_id alerte_id,
                                       ta.fg02 readyToExport,
                                       NVL(cli.nameclient, cl.nameclient) nameclient,
                                       CASE
                                         WHEN :B3 = 'FACTORING' AND
                                              gd.reffactor IS NOT NULL AND
                                              v1.place = 1 THEN
                                          ftr_fin_factor.getCurrency(gd.reffactor)
                                         WHEN v1.place = 2 THEN
                                          ta.devise_alerte
                                         ELSE
                                          NVL(gd.devise, ta.devise_alerte)
                                       END currency,
                                       CASE
                                         WHEN :B3 = 'FACTORING' THEN
                                          CASE
                                            WHEN ta.createur = 'SE' THEN
                                             NVL((SELECT valeur_trad
                                                   FROM v_tdomaine
                                                  WHERE type = 'NONSE_CREATOR'
                                                    AND abrev = 'SE'
                                                    AND langue = :B1),
                                                 ta.createur)
                                            WHEN ta.createur = 'FTR_CTRL' AND
                                                 EXISTS
                                             (SELECT 1
                                                    FROM eligib_ctrl e
                                                   WHERE e.alerte_id = ta.alerte_id) THEN
                                             NVL((SELECT valeur_trad
                                                   FROM v_tdomaine
                                                  WHERE type = 'NONSE_CREATOR'
                                                    AND abrev = 'EC'
                                                    AND langue = :B1),
                                                 ta.createur)
                                            WHEN ta.createur = 'FTR_CTRL' AND
                                                 NOT EXISTS
                                             (SELECT 1
                                                    FROM eligib_ctrl e
                                                   WHERE e.alerte_id = ta.alerte_id) THEN
                                             NVL((SELECT valeur_trad
                                                   FROM v_tdomaine
                                                  WHERE type = 'NONSE_CREATOR'
                                                    AND abrev = 'AF'
                                                    AND langue = :B1),
                                                 ta.createur)
                                            ELSE
                                             ta.createur
                                          END
                                         ELSE
                                          ta.createur
                                       END creator,
                                       ta.nb_alert_processed nbAlertProcessed
                                  FROM t_alerte ta,
                                       g_personnel gp,
                                       g_individu gi,
                                       g_dossier gd,
                                       (SELECT valeur,
                                               MAX(valeur_trad) valeur_trad
                                          FROM v_tdomaine
                                         WHERE type = 'GROUPE'
                                           AND langue = :B1
                                         GROUP BY valeur) vgr,
                                       (SELECT abrev,
                                               MAX(valeur_trad) valeur_trad
                                          FROM v_tdomaine
                                         WHERE type = 'DV_TYPE_APPEL'
                                           AND langue = :B1
                                         GROUP BY abrev) v,
                                       (SELECT valeur,
                                               MAX(valeur_trad) valeur_trad,
                                               MAX(place) place
                                          FROM v_tdomaine
                                         WHERE type = 'DV_AGENDA_NON_SE'
                                           AND langue = :B1
                                         GROUP BY valeur) v1,
                                       (SELECT /*+ merge push_pred */
                                         ti.refdoss, gi.nom nameclient
                                          FROM t_intervenants ti,
                                               g_individu     gi,
                                               v_intervenants I,
                                               v_domaine      D,
                                               g_dossier      G
                                         WHERE ti.refdoss = G.refdoss
                                           AND ti.refindividu = gi.refindividu
                                           AND I.reftype_aff = 'CLI'
                                           AND I.categdoss = D.abrev
                                           AND I.reftype_bd = ti.reftype
                                           AND D.type = 'categdoss'
                                           AND D.valeur = G.categdoss) cli,
                                       (SELECT /*+ merge push_pred */
                                         t.refdoss, i.nom nameclient
                                          FROM g_individu i, t_intervenants t
                                         WHERE i.refindividu = t.refindividu
                                           AND t.reftype = 'CL') cl
                                 WHERE ta.catperso = gp.refperso
                                   AND ta.refdoss = gd.refdoss(+)
                                   AND vgr.valeur(+) = gp.groupe
                                   AND ta.typentite = v.abrev(+)
                                   AND ta.typencour = v1.valeur(+)
                                   AND ta.refdoss = cli.refdoss(+)
                                   AND ta.refdoss = cl.refdoss(+)
                                   AND gp.refindividu = gi.refindividu
                                   AND gi.refindividu IN
                                       (SELECT gip.str1
                                          FROM g_indivparam gip
                                         WHERE gip.type = 'appel_nonse'
                                           AND gip.refindividu = :B4
                                        UNION ALL
                                        SELECT :B4
                                          FROM dual
                                        UNION ALL
                                        SELECT P.refindividu
                                          FROM g_personnel P, g_agenda A
                                         WHERE P.refrempl = :B5
                                           AND TO_CHAR(SYSDATE, 'j') = A.jour
                                           AND A.refperso = P.refperso)
                                   AND NOT EXISTS
                                 (SELECT 1
                                          FROM v_domaine
                                         WHERE type = 'DV_AGENDA_NON_SE'
                                           AND valeur = ta.typencour
                                           AND abrev6 = 'O')
                                    AND ta.dtcreation_dt >= trunc(to_date(:B6,'yyyy-mm-dd'))) t,
                               (SELECT abrev, MAX(abrev_trad) abrev_trad
                                  FROM v_tdomaine
                                 WHERE type = 'DEVISE'
                                   AND langue = :B1
                                 GROUP BY abrev) v
                         WHERE t.currency = v.abrev(+)) mca
                 WHERE 1 = 1
                 ORDER BY processDate DESC, processDate DESC) foo
         WHERE ROWNUM <= :B7)
 WHERE 1 = 1
   AND rnum >= :B8;
/********************************New SQL*******************************************/
/********************************New Metrics***************************************/
/*
Plan hash value: 1705398061
---------------------------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation					  | Name		| Starts | E-Rows | Cost (%CPU)| A-Rows |   A-Time   | Buffers | Reads	|
---------------------------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT				  |			|      1 |	  | 50262 (100)|      7 |00:00:00.03 |	  3309 |      6 |
|   1 |  VIEW						  | V_TDOMAINE		|      0 |     36 |   144   (0)|      0 |00:00:00.01 |	     0 |      0 |
|   2 |   UNION-ALL					  |			|      0 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
|*  3 |    FILTER					  |			|      0 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
|   4 |     TABLE ACCESS BY INDEX ROWID BATCHED 	  | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*  5 |      INDEX RANGE SCAN				  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*  6 |    FILTER					  |			|      0 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
|   7 |     TABLE ACCESS BY INDEX ROWID BATCHED 	  | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*  8 |      INDEX RANGE SCAN				  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*  9 |    FILTER					  |			|      0 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
|  10 |     TABLE ACCESS BY INDEX ROWID BATCHED 	  | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|* 11 |      INDEX RANGE SCAN				  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|* 12 |    FILTER					  |			|      0 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
|  13 |     TABLE ACCESS BY INDEX ROWID BATCHED 	  | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|* 14 |      INDEX RANGE SCAN				  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|* 15 |    FILTER					  |			|      0 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
|  16 |     TABLE ACCESS BY INDEX ROWID BATCHED 	  | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|* 17 |      INDEX RANGE SCAN				  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|* 18 |    FILTER					  |			|      0 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
|  19 |     TABLE ACCESS BY INDEX ROWID BATCHED 	  | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|* 20 |      INDEX RANGE SCAN				  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|* 21 |    FILTER					  |			|      0 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
|  22 |     TABLE ACCESS BY INDEX ROWID BATCHED 	  | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|* 23 |      INDEX RANGE SCAN				  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|* 24 |    FILTER					  |			|      0 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
|  25 |     TABLE ACCESS BY INDEX ROWID BATCHED 	  | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|* 26 |      INDEX RANGE SCAN				  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|* 27 |    FILTER					  |			|      0 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
|  28 |     TABLE ACCESS BY INDEX ROWID BATCHED 	  | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|* 29 |      INDEX RANGE SCAN				  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|* 30 |    FILTER					  |			|      0 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
|  31 |     TABLE ACCESS BY INDEX ROWID BATCHED 	  | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|* 32 |      INDEX RANGE SCAN				  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|* 33 |    FILTER					  |			|      0 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
|  34 |     TABLE ACCESS BY INDEX ROWID BATCHED 	  | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|* 35 |      INDEX RANGE SCAN				  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|* 36 |    FILTER					  |			|      0 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
|  37 |     TABLE ACCESS BY INDEX ROWID BATCHED 	  | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|* 38 |      INDEX RANGE SCAN				  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|* 39 |    FILTER					  |			|      0 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
|  40 |     TABLE ACCESS BY INDEX ROWID BATCHED 	  | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|* 41 |      INDEX RANGE SCAN				  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|* 42 |    FILTER					  |			|      0 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
|  43 |     TABLE ACCESS BY INDEX ROWID BATCHED 	  | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|* 44 |      INDEX RANGE SCAN				  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|* 45 |    FILTER					  |			|      0 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
|  46 |     TABLE ACCESS BY INDEX ROWID BATCHED 	  | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|* 47 |      INDEX RANGE SCAN				  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|* 48 |    FILTER					  |			|      0 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
|  49 |     TABLE ACCESS BY INDEX ROWID BATCHED 	  | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|* 50 |      INDEX RANGE SCAN				  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|* 51 |    FILTER					  |			|      0 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
|  52 |     TABLE ACCESS BY INDEX ROWID BATCHED 	  | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|* 53 |      INDEX RANGE SCAN				  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|* 54 |    FILTER					  |			|      0 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
|  55 |     TABLE ACCESS BY INDEX ROWID BATCHED 	  | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|* 56 |      INDEX RANGE SCAN				  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|* 57 |    FILTER					  |			|      0 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
|  58 |     TABLE ACCESS BY INDEX ROWID BATCHED 	  | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|* 59 |      INDEX RANGE SCAN				  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|* 60 |    FILTER					  |			|      0 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
|  61 |     TABLE ACCESS BY INDEX ROWID BATCHED 	  | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|* 62 |      INDEX RANGE SCAN				  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|* 63 |    FILTER					  |			|      0 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
|  64 |     TABLE ACCESS BY INDEX ROWID BATCHED 	  | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|* 65 |      INDEX RANGE SCAN				  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|* 66 |    FILTER					  |			|      0 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
|  67 |     TABLE ACCESS BY INDEX ROWID BATCHED 	  | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|* 68 |      INDEX RANGE SCAN				  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|* 69 |    FILTER					  |			|      0 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
|  70 |     TABLE ACCESS BY INDEX ROWID BATCHED 	  | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|* 71 |      INDEX RANGE SCAN				  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|* 72 |    FILTER					  |			|      0 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
|  73 |     TABLE ACCESS BY INDEX ROWID BATCHED 	  | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|* 74 |      INDEX RANGE SCAN				  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|* 75 |    FILTER					  |			|      0 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
|  76 |     TABLE ACCESS BY INDEX ROWID BATCHED 	  | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|* 77 |      INDEX RANGE SCAN				  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|* 78 |    FILTER					  |			|      0 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
|  79 |     TABLE ACCESS BY INDEX ROWID BATCHED 	  | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|* 80 |      INDEX RANGE SCAN				  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|* 81 |    FILTER					  |			|      0 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
|  82 |     TABLE ACCESS BY INDEX ROWID BATCHED 	  | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|* 83 |      INDEX RANGE SCAN				  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|* 84 |    FILTER					  |			|      0 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
|  85 |     TABLE ACCESS BY INDEX ROWID BATCHED 	  | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|* 86 |      INDEX RANGE SCAN				  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|* 87 |    FILTER					  |			|      0 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
|  88 |     TABLE ACCESS BY INDEX ROWID BATCHED 	  | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|* 89 |      INDEX RANGE SCAN				  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|* 90 |    FILTER					  |			|      0 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
|  91 |     TABLE ACCESS BY INDEX ROWID BATCHED 	  | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|* 92 |      INDEX RANGE SCAN				  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|* 93 |    FILTER					  |			|      0 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
|  94 |     TABLE ACCESS BY INDEX ROWID BATCHED 	  | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|* 95 |      INDEX RANGE SCAN				  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|* 96 |    FILTER					  |			|      0 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
|  97 |     TABLE ACCESS BY INDEX ROWID BATCHED 	  | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|* 98 |      INDEX RANGE SCAN				  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|* 99 |    FILTER					  |			|      0 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 100 |     TABLE ACCESS BY INDEX ROWID BATCHED 	  | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*101 |      INDEX RANGE SCAN				  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*102 |    FILTER					  |			|      0 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 103 |     TABLE ACCESS BY INDEX ROWID BATCHED 	  | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*104 |      INDEX RANGE SCAN				  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*105 |    FILTER					  |			|      0 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 106 |     TABLE ACCESS BY INDEX ROWID BATCHED 	  | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*107 |      INDEX RANGE SCAN				  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*108 |    FILTER					  |			|      0 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 109 |     TABLE ACCESS BY INDEX ROWID BATCHED 	  | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*110 |      INDEX RANGE SCAN				  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*111 |     INDEX RANGE SCAN				  | ELIGB_ALERT_ID_IDX	|      5 |	1 |	3   (0)|      5 |00:00:00.01 |	    15 |      0 |
| 112 |      VIEW					  | V_TDOMAINE		|      1 |     36 |   144   (0)|      0 |00:00:00.01 |	     3 |      0 |
| 113 |       UNION-ALL 				  |			|      1 |	  |	       |      0 |00:00:00.01 |	     3 |      0 |
|*114 |        FILTER					  |			|      1 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 115 | 	TABLE ACCESS BY INDEX ROWID BATCHED	  | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*116 | 	 INDEX RANGE SCAN			  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*117 |        FILTER					  |			|      1 |	  |	       |      0 |00:00:00.01 |	     3 |      0 |
| 118 | 	TABLE ACCESS BY INDEX ROWID BATCHED	  | V_DOMAINE		|      1 |	1 |	4   (0)|      0 |00:00:00.01 |	     3 |      0 |
|*119 | 	 INDEX RANGE SCAN			  | DOM_TYPABREV	|      1 |	1 |	3   (0)|      0 |00:00:00.01 |	     3 |      0 |
|*120 |        FILTER					  |			|      1 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 121 | 	TABLE ACCESS BY INDEX ROWID BATCHED	  | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*122 | 	 INDEX RANGE SCAN			  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*123 |        FILTER					  |			|      1 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 124 | 	TABLE ACCESS BY INDEX ROWID BATCHED	  | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*125 | 	 INDEX RANGE SCAN			  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*126 |        FILTER					  |			|      1 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 127 | 	TABLE ACCESS BY INDEX ROWID BATCHED	  | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*128 | 	 INDEX RANGE SCAN			  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*129 |        FILTER					  |			|      1 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 130 | 	TABLE ACCESS BY INDEX ROWID BATCHED	  | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*131 | 	 INDEX RANGE SCAN			  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*132 |        FILTER					  |			|      1 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 133 | 	TABLE ACCESS BY INDEX ROWID BATCHED	  | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*134 | 	 INDEX RANGE SCAN			  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*135 |        FILTER					  |			|      1 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 136 | 	TABLE ACCESS BY INDEX ROWID BATCHED	  | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*137 | 	 INDEX RANGE SCAN			  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*138 |        FILTER					  |			|      1 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 139 | 	TABLE ACCESS BY INDEX ROWID BATCHED	  | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*140 | 	 INDEX RANGE SCAN			  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*141 |        FILTER					  |			|      1 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 142 | 	TABLE ACCESS BY INDEX ROWID BATCHED	  | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*143 | 	 INDEX RANGE SCAN			  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*144 |        FILTER					  |			|      1 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 145 | 	TABLE ACCESS BY INDEX ROWID BATCHED	  | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*146 | 	 INDEX RANGE SCAN			  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*147 |        FILTER					  |			|      1 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 148 | 	TABLE ACCESS BY INDEX ROWID BATCHED	  | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*149 | 	 INDEX RANGE SCAN			  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*150 |        FILTER					  |			|      1 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 151 | 	TABLE ACCESS BY INDEX ROWID BATCHED	  | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*152 | 	 INDEX RANGE SCAN			  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*153 |        FILTER					  |			|      1 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 154 | 	TABLE ACCESS BY INDEX ROWID BATCHED	  | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*155 | 	 INDEX RANGE SCAN			  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*156 |        FILTER					  |			|      1 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 157 | 	TABLE ACCESS BY INDEX ROWID BATCHED	  | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*158 | 	 INDEX RANGE SCAN			  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*159 |        FILTER					  |			|      1 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 160 | 	TABLE ACCESS BY INDEX ROWID BATCHED	  | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*161 | 	 INDEX RANGE SCAN			  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*162 |        FILTER					  |			|      1 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 163 | 	TABLE ACCESS BY INDEX ROWID BATCHED	  | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*164 | 	 INDEX RANGE SCAN			  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*165 |        FILTER					  |			|      1 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 166 | 	TABLE ACCESS BY INDEX ROWID BATCHED	  | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*167 | 	 INDEX RANGE SCAN			  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*168 |        FILTER					  |			|      1 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 169 | 	TABLE ACCESS BY INDEX ROWID BATCHED	  | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*170 | 	 INDEX RANGE SCAN			  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*171 |        FILTER					  |			|      1 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 172 | 	TABLE ACCESS BY INDEX ROWID BATCHED	  | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*173 | 	 INDEX RANGE SCAN			  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*174 |        FILTER					  |			|      1 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 175 | 	TABLE ACCESS BY INDEX ROWID BATCHED	  | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*176 | 	 INDEX RANGE SCAN			  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*177 |        FILTER					  |			|      1 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 178 | 	TABLE ACCESS BY INDEX ROWID BATCHED	  | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*179 | 	 INDEX RANGE SCAN			  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*180 |        FILTER					  |			|      1 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 181 | 	TABLE ACCESS BY INDEX ROWID BATCHED	  | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*182 | 	 INDEX RANGE SCAN			  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*183 |        FILTER					  |			|      1 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 184 | 	TABLE ACCESS BY INDEX ROWID BATCHED	  | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*185 | 	 INDEX RANGE SCAN			  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*186 |        FILTER					  |			|      1 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 187 | 	TABLE ACCESS BY INDEX ROWID BATCHED	  | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*188 | 	 INDEX RANGE SCAN			  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*189 |        FILTER					  |			|      1 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 190 | 	TABLE ACCESS BY INDEX ROWID BATCHED	  | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*191 | 	 INDEX RANGE SCAN			  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*192 |        FILTER					  |			|      1 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 193 | 	TABLE ACCESS BY INDEX ROWID BATCHED	  | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*194 | 	 INDEX RANGE SCAN			  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*195 |        FILTER					  |			|      1 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 196 | 	TABLE ACCESS BY INDEX ROWID BATCHED	  | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*197 | 	 INDEX RANGE SCAN			  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*198 |        FILTER					  |			|      1 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 199 | 	TABLE ACCESS BY INDEX ROWID BATCHED	  | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*200 | 	 INDEX RANGE SCAN			  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*201 |        FILTER					  |			|      1 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 202 | 	TABLE ACCESS BY INDEX ROWID BATCHED	  | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*203 | 	 INDEX RANGE SCAN			  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*204 |        FILTER					  |			|      1 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 205 | 	TABLE ACCESS BY INDEX ROWID BATCHED	  | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*206 | 	 INDEX RANGE SCAN			  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*207 |        FILTER					  |			|      1 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 208 | 	TABLE ACCESS BY INDEX ROWID BATCHED	  | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*209 | 	 INDEX RANGE SCAN			  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*210 |        FILTER					  |			|      1 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 211 | 	TABLE ACCESS BY INDEX ROWID BATCHED	  | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*212 | 	 INDEX RANGE SCAN			  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*213 |        FILTER					  |			|      1 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 214 | 	TABLE ACCESS BY INDEX ROWID BATCHED	  | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*215 | 	 INDEX RANGE SCAN			  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*216 |        FILTER					  |			|      1 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 217 | 	TABLE ACCESS BY INDEX ROWID BATCHED	  | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*218 | 	 INDEX RANGE SCAN			  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*219 |        FILTER					  |			|      1 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 220 | 	TABLE ACCESS BY INDEX ROWID BATCHED	  | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*221 | 	 INDEX RANGE SCAN			  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*222 | 	INDEX RANGE SCAN			  | ELIGB_ALERT_ID_IDX	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
| 223 | 	 VIEW					  | V_TDOMAINE		|      0 |     36 |   144   (0)|      0 |00:00:00.01 |	     0 |      0 |
| 224 | 	  UNION-ALL				  |			|      0 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
|*225 | 	   FILTER				  |			|      0 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 226 | 	    TABLE ACCESS BY INDEX ROWID BATCHED   | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*227 | 	     INDEX RANGE SCAN			  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*228 | 	   FILTER				  |			|      0 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 229 | 	    TABLE ACCESS BY INDEX ROWID BATCHED   | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*230 | 	     INDEX RANGE SCAN			  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*231 | 	   FILTER				  |			|      0 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 232 | 	    TABLE ACCESS BY INDEX ROWID BATCHED   | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*233 | 	     INDEX RANGE SCAN			  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*234 | 	   FILTER				  |			|      0 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 235 | 	    TABLE ACCESS BY INDEX ROWID BATCHED   | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*236 | 	     INDEX RANGE SCAN			  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*237 | 	   FILTER				  |			|      0 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 238 | 	    TABLE ACCESS BY INDEX ROWID BATCHED   | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*239 | 	     INDEX RANGE SCAN			  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*240 | 	   FILTER				  |			|      0 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 241 | 	    TABLE ACCESS BY INDEX ROWID BATCHED   | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*242 | 	     INDEX RANGE SCAN			  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*243 | 	   FILTER				  |			|      0 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 244 | 	    TABLE ACCESS BY INDEX ROWID BATCHED   | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*245 | 	     INDEX RANGE SCAN			  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*246 | 	   FILTER				  |			|      0 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 247 | 	    TABLE ACCESS BY INDEX ROWID BATCHED   | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*248 | 	     INDEX RANGE SCAN			  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*249 | 	   FILTER				  |			|      0 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 250 | 	    TABLE ACCESS BY INDEX ROWID BATCHED   | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*251 | 	     INDEX RANGE SCAN			  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*252 | 	   FILTER				  |			|      0 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 253 | 	    TABLE ACCESS BY INDEX ROWID BATCHED   | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*254 | 	     INDEX RANGE SCAN			  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*255 | 	   FILTER				  |			|      0 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 256 | 	    TABLE ACCESS BY INDEX ROWID BATCHED   | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*257 | 	     INDEX RANGE SCAN			  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*258 | 	   FILTER				  |			|      0 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 259 | 	    TABLE ACCESS BY INDEX ROWID BATCHED   | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*260 | 	     INDEX RANGE SCAN			  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*261 | 	   FILTER				  |			|      0 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 262 | 	    TABLE ACCESS BY INDEX ROWID BATCHED   | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*263 | 	     INDEX RANGE SCAN			  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*264 | 	   FILTER				  |			|      0 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 265 | 	    TABLE ACCESS BY INDEX ROWID BATCHED   | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*266 | 	     INDEX RANGE SCAN			  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*267 | 	   FILTER				  |			|      0 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 268 | 	    TABLE ACCESS BY INDEX ROWID BATCHED   | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*269 | 	     INDEX RANGE SCAN			  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*270 | 	   FILTER				  |			|      0 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 271 | 	    TABLE ACCESS BY INDEX ROWID BATCHED   | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*272 | 	     INDEX RANGE SCAN			  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*273 | 	   FILTER				  |			|      0 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 274 | 	    TABLE ACCESS BY INDEX ROWID BATCHED   | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*275 | 	     INDEX RANGE SCAN			  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*276 | 	   FILTER				  |			|      0 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 277 | 	    TABLE ACCESS BY INDEX ROWID BATCHED   | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*278 | 	     INDEX RANGE SCAN			  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*279 | 	   FILTER				  |			|      0 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 280 | 	    TABLE ACCESS BY INDEX ROWID BATCHED   | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*281 | 	     INDEX RANGE SCAN			  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*282 | 	   FILTER				  |			|      0 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 283 | 	    TABLE ACCESS BY INDEX ROWID BATCHED   | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*284 | 	     INDEX RANGE SCAN			  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*285 | 	   FILTER				  |			|      0 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 286 | 	    TABLE ACCESS BY INDEX ROWID BATCHED   | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*287 | 	     INDEX RANGE SCAN			  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*288 | 	   FILTER				  |			|      0 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 289 | 	    TABLE ACCESS BY INDEX ROWID BATCHED   | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*290 | 	     INDEX RANGE SCAN			  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*291 | 	   FILTER				  |			|      0 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 292 | 	    TABLE ACCESS BY INDEX ROWID BATCHED   | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*293 | 	     INDEX RANGE SCAN			  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*294 | 	   FILTER				  |			|      0 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 295 | 	    TABLE ACCESS BY INDEX ROWID BATCHED   | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*296 | 	     INDEX RANGE SCAN			  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*297 | 	   FILTER				  |			|      0 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 298 | 	    TABLE ACCESS BY INDEX ROWID BATCHED   | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*299 | 	     INDEX RANGE SCAN			  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*300 | 	   FILTER				  |			|      0 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 301 | 	    TABLE ACCESS BY INDEX ROWID BATCHED   | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*302 | 	     INDEX RANGE SCAN			  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*303 | 	   FILTER				  |			|      0 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 304 | 	    TABLE ACCESS BY INDEX ROWID BATCHED   | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*305 | 	     INDEX RANGE SCAN			  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*306 | 	   FILTER				  |			|      0 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 307 | 	    TABLE ACCESS BY INDEX ROWID BATCHED   | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*308 | 	     INDEX RANGE SCAN			  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*309 | 	   FILTER				  |			|      0 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 310 | 	    TABLE ACCESS BY INDEX ROWID BATCHED   | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*311 | 	     INDEX RANGE SCAN			  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*312 | 	   FILTER				  |			|      0 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 313 | 	    TABLE ACCESS BY INDEX ROWID BATCHED   | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*314 | 	     INDEX RANGE SCAN			  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*315 | 	   FILTER				  |			|      0 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 316 | 	    TABLE ACCESS BY INDEX ROWID BATCHED   | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*317 | 	     INDEX RANGE SCAN			  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*318 | 	   FILTER				  |			|      0 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 319 | 	    TABLE ACCESS BY INDEX ROWID BATCHED   | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*320 | 	     INDEX RANGE SCAN			  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*321 | 	   FILTER				  |			|      0 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 322 | 	    TABLE ACCESS BY INDEX ROWID BATCHED   | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*323 | 	     INDEX RANGE SCAN			  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*324 | 	   FILTER				  |			|      0 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 325 | 	    TABLE ACCESS BY INDEX ROWID BATCHED   | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*326 | 	     INDEX RANGE SCAN			  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*327 | 	   FILTER				  |			|      0 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 328 | 	    TABLE ACCESS BY INDEX ROWID BATCHED   | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*329 | 	     INDEX RANGE SCAN			  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*330 | 	   FILTER				  |			|      0 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 331 | 	    TABLE ACCESS BY INDEX ROWID BATCHED   | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*332 | 	     INDEX RANGE SCAN			  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
| 333 |  NESTED LOOPS					  |			|      1 |	1 |	4   (0)|      0 |00:00:00.01 |	     5 |      0 |
| 334 |   NESTED LOOPS					  |			|      1 |	1 |	4   (0)|      0 |00:00:00.01 |	     5 |      0 |
|*335 |    TABLE ACCESS BY INDEX ROWID BATCHED		  | G_DOSSIER		|      1 |	1 |	2   (0)|      0 |00:00:00.01 |	     5 |      0 |
|*336 |     INDEX RANGE SCAN				  | DOS_ANCREFDOSS	|      1 |	1 |	1   (0)|      1 |00:00:00.01 |	     2 |      0 |
|*337 |    INDEX UNIQUE SCAN				  | DOS_REFDOSS 	|      0 |	1 |	1   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*338 |   TABLE ACCESS BY INDEX ROWID			  | G_DOSSIER		|      0 |	1 |	2   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*339 |    FILTER					  |			|      0 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 340 |     TABLE ACCESS BY INDEX ROWID BATCHED 	  | G_DOSSIER		|      0 |  26321 |  2981   (1)|      0 |00:00:00.01 |	     0 |      0 |
|*341 |      INDEX RANGE SCAN				  | DOS_CATDOSS 	|      0 |  26321 |   122   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*342 |     TABLE ACCESS BY INDEX ROWID BATCHED 	  | G_DOSSIER		|      0 |	1 |	2   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*343 |      INDEX RANGE SCAN				  | DOS_ANCREFDOSS	|      0 |	1 |	1   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*344 |  INDEX RANGE SCAN				  | IDX_ALERTID_DET	|      7 |	1 |	1   (0)|      0 |00:00:00.01 |	     7 |      1 |
| 345 |   SORT GROUP BY 				  |			|      0 |	1 |	       |      0 |00:00:00.01 |	     0 |      0 |
| 346 |    NESTED LOOPS 				  |			|      0 |	1 |   145   (0)|      0 |00:00:00.01 |	     0 |      0 |
| 347 |     TABLE ACCESS BY INDEX ROWID BATCHED 	  | T_ALERT_NOT_ES_DET	|      0 |	1 |	1   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*348 |      INDEX RANGE SCAN				  | IDX_ALERTID_DET	|      0 |	1 |	1   (0)|      0 |00:00:00.01 |	     0 |      0 |
| 349 |     VIEW					  | V_TDOMAINE		|      0 |	1 |   144   (0)|      0 |00:00:00.01 |	     0 |      0 |
| 350 |      UNION ALL PUSHED PREDICATE 		  |			|      0 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
|*351 |       FILTER					  |			|      0 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 352 |        TABLE ACCESS BY INDEX ROWID BATCHED	  | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*353 | 	INDEX RANGE SCAN			  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*354 |       FILTER					  |			|      0 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 355 |        TABLE ACCESS BY INDEX ROWID BATCHED	  | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*356 | 	INDEX RANGE SCAN			  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*357 |       FILTER					  |			|      0 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 358 |        TABLE ACCESS BY INDEX ROWID BATCHED	  | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*359 | 	INDEX RANGE SCAN			  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*360 |       FILTER					  |			|      0 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 361 |        TABLE ACCESS BY INDEX ROWID BATCHED	  | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*362 | 	INDEX RANGE SCAN			  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*363 |       FILTER					  |			|      0 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 364 |        TABLE ACCESS BY INDEX ROWID BATCHED	  | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*365 | 	INDEX RANGE SCAN			  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*366 |       FILTER					  |			|      0 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 367 |        TABLE ACCESS BY INDEX ROWID BATCHED	  | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*368 | 	INDEX RANGE SCAN			  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*369 |       FILTER					  |			|      0 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 370 |        TABLE ACCESS BY INDEX ROWID BATCHED	  | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*371 | 	INDEX RANGE SCAN			  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*372 |       FILTER					  |			|      0 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 373 |        TABLE ACCESS BY INDEX ROWID BATCHED	  | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*374 | 	INDEX RANGE SCAN			  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*375 |       FILTER					  |			|      0 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 376 |        TABLE ACCESS BY INDEX ROWID BATCHED	  | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*377 | 	INDEX RANGE SCAN			  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*378 |       FILTER					  |			|      0 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 379 |        TABLE ACCESS BY INDEX ROWID BATCHED	  | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*380 | 	INDEX RANGE SCAN			  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*381 |       FILTER					  |			|      0 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 382 |        TABLE ACCESS BY INDEX ROWID BATCHED	  | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*383 | 	INDEX RANGE SCAN			  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*384 |       FILTER					  |			|      0 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 385 |        TABLE ACCESS BY INDEX ROWID BATCHED	  | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*386 | 	INDEX RANGE SCAN			  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*387 |       FILTER					  |			|      0 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 388 |        TABLE ACCESS BY INDEX ROWID BATCHED	  | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*389 | 	INDEX RANGE SCAN			  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*390 |       FILTER					  |			|      0 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 391 |        TABLE ACCESS BY INDEX ROWID BATCHED	  | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*392 | 	INDEX RANGE SCAN			  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*393 |       FILTER					  |			|      0 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 394 |        TABLE ACCESS BY INDEX ROWID BATCHED	  | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*395 | 	INDEX RANGE SCAN			  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*396 |       FILTER					  |			|      0 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 397 |        TABLE ACCESS BY INDEX ROWID BATCHED	  | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*398 | 	INDEX RANGE SCAN			  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*399 |       FILTER					  |			|      0 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 400 |        TABLE ACCESS BY INDEX ROWID BATCHED	  | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*401 | 	INDEX RANGE SCAN			  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*402 |       FILTER					  |			|      0 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 403 |        TABLE ACCESS BY INDEX ROWID BATCHED	  | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*404 | 	INDEX RANGE SCAN			  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*405 |       FILTER					  |			|      0 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 406 |        TABLE ACCESS BY INDEX ROWID BATCHED	  | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*407 | 	INDEX RANGE SCAN			  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*408 |       FILTER					  |			|      0 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 409 |        TABLE ACCESS BY INDEX ROWID BATCHED	  | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*410 | 	INDEX RANGE SCAN			  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*411 |       FILTER					  |			|      0 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 412 |        TABLE ACCESS BY INDEX ROWID BATCHED	  | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*413 | 	INDEX RANGE SCAN			  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*414 |       FILTER					  |			|      0 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 415 |        TABLE ACCESS BY INDEX ROWID BATCHED	  | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*416 | 	INDEX RANGE SCAN			  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*417 |       FILTER					  |			|      0 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 418 |        TABLE ACCESS BY INDEX ROWID BATCHED	  | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*419 | 	INDEX RANGE SCAN			  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*420 |       FILTER					  |			|      0 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 421 |        TABLE ACCESS BY INDEX ROWID BATCHED	  | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*422 | 	INDEX RANGE SCAN			  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*423 |       FILTER					  |			|      0 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 424 |        TABLE ACCESS BY INDEX ROWID BATCHED	  | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*425 | 	INDEX RANGE SCAN			  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*426 |       FILTER					  |			|      0 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 427 |        TABLE ACCESS BY INDEX ROWID BATCHED	  | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*428 | 	INDEX RANGE SCAN			  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*429 |       FILTER					  |			|      0 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 430 |        TABLE ACCESS BY INDEX ROWID BATCHED	  | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*431 | 	INDEX RANGE SCAN			  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*432 |       FILTER					  |			|      0 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 433 |        TABLE ACCESS BY INDEX ROWID BATCHED	  | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*434 | 	INDEX RANGE SCAN			  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*435 |       FILTER					  |			|      0 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 436 |        TABLE ACCESS BY INDEX ROWID BATCHED	  | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*437 | 	INDEX RANGE SCAN			  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*438 |       FILTER					  |			|      0 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 439 |        TABLE ACCESS BY INDEX ROWID BATCHED	  | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*440 | 	INDEX RANGE SCAN			  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*441 |       FILTER					  |			|      0 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 442 |        TABLE ACCESS BY INDEX ROWID BATCHED	  | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*443 | 	INDEX RANGE SCAN			  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*444 |       FILTER					  |			|      0 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 445 |        TABLE ACCESS BY INDEX ROWID BATCHED	  | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*446 | 	INDEX RANGE SCAN			  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*447 |       FILTER					  |			|      0 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 448 |        TABLE ACCESS BY INDEX ROWID BATCHED	  | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*449 | 	INDEX RANGE SCAN			  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*450 |       FILTER					  |			|      0 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 451 |        TABLE ACCESS BY INDEX ROWID BATCHED	  | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*452 | 	INDEX RANGE SCAN			  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*453 |       FILTER					  |			|      0 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 454 |        TABLE ACCESS BY INDEX ROWID BATCHED	  | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*455 | 	INDEX RANGE SCAN			  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*456 |       FILTER					  |			|      0 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 457 |        TABLE ACCESS BY INDEX ROWID BATCHED	  | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*458 | 	INDEX RANGE SCAN			  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
| 459 |  NESTED LOOPS					  |			|      1 |	1 |	4   (0)|      0 |00:00:00.01 |	     5 |      0 |
| 460 |   NESTED LOOPS					  |			|      1 |	1 |	4   (0)|      0 |00:00:00.01 |	     5 |      0 |
|*461 |    TABLE ACCESS BY INDEX ROWID BATCHED		  | G_DOSSIER		|      1 |	1 |	2   (0)|      0 |00:00:00.01 |	     5 |      0 |
|*462 |     INDEX RANGE SCAN				  | DOS_ANCREFDOSS	|      1 |	1 |	1   (0)|      1 |00:00:00.01 |	     2 |      0 |
|*463 |    INDEX UNIQUE SCAN				  | DOS_REFDOSS 	|      0 |	1 |	1   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*464 |   TABLE ACCESS BY INDEX ROWID			  | G_DOSSIER		|      0 |	1 |	2   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*465 |    COUNT STOPKEY				  |			|      0 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 466 |     NESTED LOOPS				  |			|      0 |	1 |	8   (0)|      0 |00:00:00.01 |	     0 |      0 |
| 467 |      NESTED LOOPS				  |			|      0 |	1 |	8   (0)|      0 |00:00:00.01 |	     0 |      0 |
| 468 |       NESTED LOOPS				  |			|      0 |	1 |	6   (0)|      0 |00:00:00.01 |	     0 |      0 |
| 469 |        NESTED LOOPS				  |			|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*470 | 	TABLE ACCESS BY INDEX ROWID BATCHED	  | G_DOSSIER		|      0 |	1 |	2   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*471 | 	 INDEX RANGE SCAN			  | DOS_ANCREFDOSS	|      0 |	1 |	1   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*472 | 	TABLE ACCESS BY INDEX ROWID		  | G_DOSSIER		|      0 |	1 |	2   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*473 | 	 INDEX UNIQUE SCAN			  | DOS_REFDOSS 	|      0 |	1 |	1   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*474 |        INDEX RANGE SCAN 			  | INT_REFDOSS 	|      0 |	1 |	2   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*475 |       INDEX UNIQUE SCAN 			  | IND_REFINDIV	|      0 |	1 |	1   (0)|      0 |00:00:00.01 |	     0 |      0 |
| 476 |      TABLE ACCESS BY INDEX ROWID		  | G_INDIVIDU		|      0 |	1 |	2   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*477 |     COUNT STOPKEY				  |			|      1 |	  |	       |      1 |00:00:00.01 |	    10 |      0 |
| 478 |      NESTED LOOPS				  |			|      1 |	3 |    14   (0)|      1 |00:00:00.01 |	    10 |      0 |
| 479 |       NESTED LOOPS				  |			|      1 |	3 |    14   (0)|      1 |00:00:00.01 |	     9 |      0 |
| 480 |        NESTED LOOPS				  |			|      1 |	3 |	8   (0)|      1 |00:00:00.01 |	     6 |      0 |
| 481 | 	TABLE ACCESS BY INDEX ROWID BATCHED	  | G_DOSSIER		|      1 |     60 |	2   (0)|      1 |00:00:00.01 |	     3 |      0 |
|*482 | 	 INDEX RANGE SCAN			  | DOS_ANCREFDOSS	|      1 |	1 |	1   (0)|      1 |00:00:00.01 |	     2 |      0 |
|*483 | 	INDEX RANGE SCAN			  | INT_REFDOSS 	|      1 |	1 |	2   (0)|      1 |00:00:00.01 |	     3 |      0 |
|*484 |        INDEX UNIQUE SCAN			  | IND_REFINDIV	|      1 |	1 |	1   (0)|      1 |00:00:00.01 |	     3 |      0 |
| 485 |       TABLE ACCESS BY INDEX ROWID		  | G_INDIVIDU		|      1 |	1 |	2   (0)|      1 |00:00:00.01 |	     1 |      0 |
|*486 |  VIEW						  |			|      1 |	1 | 50262   (1)|      7 |00:00:00.03 |	  3309 |      6 |
|*487 |   COUNT STOPKEY 				  |			|      1 |	  |	       |      7 |00:00:00.03 |	  3309 |      6 |
| 488 |    VIEW 					  |			|      1 |	1 | 50262   (1)|      7 |00:00:00.03 |	  3309 |      6 |
|*489 |     SORT ORDER BY STOPKEY			  |			|      1 |	1 | 50262   (1)|      7 |00:00:00.02 |	  3264 |      5 |
| 490 |      NESTED LOOPS OUTER 			  |			|      1 |	1 |   549   (0)|      7 |00:00:00.02 |	  3264 |      5 |
| 491 |       NESTED LOOPS OUTER			  |			|      1 |	1 |   405   (0)|      7 |00:00:00.02 |	  3240 |      5 |
| 492 |        NESTED LOOPS OUTER			  |			|      1 |	1 |   261   (0)|      7 |00:00:00.02 |	  3220 |      5 |
| 493 | 	NESTED LOOPS OUTER			  |			|      1 |	1 |   153   (0)|      7 |00:00:00.02 |	  3201 |      4 |
| 494 | 	 NESTED LOOPS OUTER			  |			|      1 |	1 |    45   (0)|      7 |00:00:00.02 |	  3180 |      4 |
| 495 | 	  NESTED LOOPS OUTER			  |			|      1 |	1 |    35   (0)|      7 |00:00:00.02 |	  3106 |      4 |
| 496 | 	   NESTED LOOPS OUTER			  |			|      1 |	1 |    30   (0)|      7 |00:00:00.02 |	  3075 |      4 |
| 497 | 	    NESTED LOOPS ANTI			  |			|      1 |	1 |    28   (0)|      7 |00:00:00.02 |	  3047 |      4 |
| 498 | 	     NESTED LOOPS			  |			|      1 |	1 |    25   (0)|      7 |00:00:00.02 |	  3039 |      3 |
| 499 | 	      NESTED LOOPS			  |			|      1 |	1 |    21   (0)|    569 |00:00:00.01 |	  1888 |      1 |
| 500 | 	       NESTED LOOPS			  |			|      1 |	4 |    16   (0)|    569 |00:00:00.01 |	  1194 |      0 |
| 501 | 		VIEW				  | VW_NSO_1		|      1 |	4 |	8   (0)|    570 |00:00:00.01 |	    10 |      0 |
| 502 | 		 HASH UNIQUE			  |			|      1 |	4 |	8   (0)|    570 |00:00:00.01 |	    10 |      0 |
| 503 | 		  UNION-ALL			  |			|      1 |	  |	       |    571 |00:00:00.01 |	    10 |      0 |
|*504 | 		   INDEX RANGE SCAN		  | G_INDIVPARAM_REFIND |      1 |	2 |	3   (0)|    570 |00:00:00.01 |	     9 |      0 |
| 505 | 		   FAST DUAL			  |			|      1 |	1 |	2   (0)|      1 |00:00:00.01 |	     0 |      0 |
| 506 | 		   NESTED LOOPS 		  |			|      1 |	1 |	3   (0)|      0 |00:00:00.01 |	     1 |      0 |
| 507 | 		    NESTED LOOPS		  |			|      1 |	1 |	3   (0)|      0 |00:00:00.01 |	     1 |      0 |
|*508 | 		     INDEX RANGE SCAN		  | AGE_PERSOJOUR	|      1 |	1 |	1   (0)|      0 |00:00:00.01 |	     1 |      0 |
|*509 | 		     INDEX RANGE SCAN		  | GPERSREFP		|      0 |	1 |	1   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*510 | 		    TABLE ACCESS BY INDEX ROWID   | G_PERSONNEL 	|      0 |	1 |	2   (0)|      0 |00:00:00.01 |	     0 |      0 |
| 511 | 		TABLE ACCESS BY INDEX ROWID	  | G_INDIVIDU		|    570 |	1 |	2   (0)|    569 |00:00:00.01 |	  1184 |      0 |
|*512 | 		 INDEX UNIQUE SCAN		  | IND_REFINDIV	|    570 |	1 |	1   (0)|    569 |00:00:00.01 |	   744 |      0 |
| 513 | 	       TABLE ACCESS BY INDEX ROWID BATCHED| G_PERSONNEL 	|    569 |	1 |	2   (0)|    569 |00:00:00.01 |	   694 |      1 |
|*514 | 		INDEX RANGE SCAN		  | GPERS_REFIN_IDX	|    569 |	1 |	1   (0)|    569 |00:00:00.01 |	   246 |      1 |
|*515 | 	      TABLE ACCESS BY INDEX ROWID BATCHED | T_ALERTE		|    569 |	1 |	4   (0)|      7 |00:00:00.01 |	  1151 |      2 |
|*516 | 	       INDEX RANGE SCAN 		  | AL_DTCREATION_IDX	|    569 |	8 |	2   (0)|   3983 |00:00:00.01 |	    13 |      1 |
|*517 | 	     TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE		|      3 |	1 |	3   (0)|      0 |00:00:00.01 |	     8 |      1 |
|*518 | 	      INDEX RANGE SCAN			  | DOM_TYPVAL		|      3 |	1 |	1   (0)|      3 |00:00:00.01 |	     5 |      0 |
| 519 | 	    TABLE ACCESS BY INDEX ROWID 	  | G_DOSSIER		|      7 |	1 |	2   (0)|      7 |00:00:00.01 |	    28 |      0 |
|*520 | 	     INDEX UNIQUE SCAN			  | DOS_REFDOSS 	|      7 |	1 |	1   (0)|      7 |00:00:00.01 |	    16 |      0 |
| 521 | 	   VIEW PUSHED PREDICATE		  |			|      7 |	1 |	5   (0)|      7 |00:00:00.01 |	    31 |      0 |
| 522 | 	    NESTED LOOPS			  |			|      7 |	1 |	5   (0)|      7 |00:00:00.01 |	    31 |      0 |
| 523 | 	     NESTED LOOPS			  |			|      7 |	1 |	5   (0)|      7 |00:00:00.01 |	    30 |      0 |
|*524 | 	      INDEX RANGE SCAN			  | INT_REFDOSS 	|      7 |	1 |	3   (0)|      7 |00:00:00.01 |	    16 |      0 |
|*525 | 	      INDEX UNIQUE SCAN 		  | IND_REFINDIV	|      7 |	1 |	1   (0)|      7 |00:00:00.01 |	    14 |      0 |
| 526 | 	     TABLE ACCESS BY INDEX ROWID	  | G_INDIVIDU		|      7 |	1 |	2   (0)|      7 |00:00:00.01 |	     1 |      0 |
| 527 | 	  VIEW PUSHED PREDICATE 		  |			|      7 |	1 |    10   (0)|      7 |00:00:00.01 |	    74 |      0 |
| 528 | 	   NESTED LOOPS 			  |			|      7 |	1 |    10   (0)|      7 |00:00:00.01 |	    74 |      0 |
| 529 | 	    NESTED LOOPS			  |			|      7 |	1 |    10   (0)|      7 |00:00:00.01 |	    73 |      0 |
| 530 | 	     NESTED LOOPS			  |			|      7 |	1 |	8   (0)|      7 |00:00:00.01 |	    59 |      0 |
| 531 | 	      NESTED LOOPS			  |			|      7 |	1 |	7   (0)|     14 |00:00:00.01 |	    55 |      0 |
| 532 | 	       NESTED LOOPS			  |			|      7 |	1 |	5   (0)|      7 |00:00:00.01 |	    39 |      0 |
| 533 | 		TABLE ACCESS BY INDEX ROWID	  | G_DOSSIER		|      7 |	1 |	3   (0)|      7 |00:00:00.01 |	    19 |      0 |
|*534 | 		 INDEX UNIQUE SCAN		  | DOS_REFDOSS 	|      7 |	1 |	2   (0)|      7 |00:00:00.01 |	    16 |      0 |
|*535 | 		INDEX RANGE SCAN		  | DOM_TYPABREV	|      7 |	1 |	2   (0)|      7 |00:00:00.01 |	    20 |      0 |
|*536 | 	       INDEX RANGE SCAN 		  | INT_REFDOSS 	|      7 |	1 |	2   (0)|     14 |00:00:00.01 |	    16 |      0 |
|*537 | 	      TABLE ACCESS BY INDEX ROWID BATCHED | V_INTERVENANTS	|     14 |	1 |	1   (0)|      7 |00:00:00.01 |	     4 |      0 |
|*538 | 	       INDEX RANGE SCAN 		  | V_INTERVENANTS_AK	|     14 |	1 |	0   (0)|      9 |00:00:00.01 |	     3 |      0 |
|*539 | 	     INDEX UNIQUE SCAN			  | IND_REFINDIV	|      7 |	1 |	1   (0)|      7 |00:00:00.01 |	    14 |      0 |
| 540 | 	    TABLE ACCESS BY INDEX ROWID 	  | G_INDIVIDU		|      7 |	1 |	2   (0)|      7 |00:00:00.01 |	     1 |      0 |
| 541 | 	 VIEW PUSHED PREDICATE			  |			|      7 |	1 |   108   (0)|      7 |00:00:00.01 |	    21 |      0 |
| 542 | 	  SORT GROUP BY 			  |			|      7 |	1 |   108   (0)|      7 |00:00:00.01 |	    21 |      0 |
| 543 | 	   VIEW 				  | V_TDOMAINE		|      7 |     36 |   108   (0)|      7 |00:00:00.01 |	    21 |      0 |
| 544 | 	    UNION-ALL				  |			|      7 |	  |	       |      7 |00:00:00.01 |	    21 |      0 |
|*545 | 	     FILTER				  |			|      7 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 546 | 	      TABLE ACCESS BY INDEX ROWID BATCHED | V_DOMAINE		|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*547 | 	       INDEX RANGE SCAN 		  | DOM_TYPVAL		|      0 |	1 |	1   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*548 | 	     FILTER				  |			|      7 |	  |	       |      7 |00:00:00.01 |	    21 |      0 |
| 549 | 	      TABLE ACCESS BY INDEX ROWID BATCHED | V_DOMAINE		|      7 |	1 |	3   (0)|      7 |00:00:00.01 |	    21 |      0 |
|*550 | 	       INDEX RANGE SCAN 		  | DOM_TYPVAL		|      7 |	1 |	1   (0)|      7 |00:00:00.01 |	    14 |      0 |
|*551 | 	     FILTER				  |			|      7 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 552 | 	      TABLE ACCESS BY INDEX ROWID BATCHED | V_DOMAINE		|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*553 | 	       INDEX RANGE SCAN 		  | DOM_TYPVAL		|      0 |	1 |	1   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*554 | 	     FILTER				  |			|      7 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 555 | 	      TABLE ACCESS BY INDEX ROWID BATCHED | V_DOMAINE		|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*556 | 	       INDEX RANGE SCAN 		  | DOM_TYPVAL		|      0 |	1 |	1   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*557 | 	     FILTER				  |			|      7 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 558 | 	      TABLE ACCESS BY INDEX ROWID BATCHED | V_DOMAINE		|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*559 | 	       INDEX RANGE SCAN 		  | DOM_TYPVAL		|      0 |	1 |	1   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*560 | 	     FILTER				  |			|      7 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 561 | 	      TABLE ACCESS BY INDEX ROWID BATCHED | V_DOMAINE		|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*562 | 	       INDEX RANGE SCAN 		  | DOM_TYPVAL		|      0 |	1 |	1   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*563 | 	     FILTER				  |			|      7 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 564 | 	      TABLE ACCESS BY INDEX ROWID BATCHED | V_DOMAINE		|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*565 | 	       INDEX RANGE SCAN 		  | DOM_TYPVAL		|      0 |	1 |	1   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*566 | 	     FILTER				  |			|      7 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 567 | 	      TABLE ACCESS BY INDEX ROWID BATCHED | V_DOMAINE		|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*568 | 	       INDEX RANGE SCAN 		  | DOM_TYPVAL		|      0 |	1 |	1   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*569 | 	     FILTER				  |			|      7 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 570 | 	      TABLE ACCESS BY INDEX ROWID BATCHED | V_DOMAINE		|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*571 | 	       INDEX RANGE SCAN 		  | DOM_TYPVAL		|      0 |	1 |	1   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*572 | 	     FILTER				  |			|      7 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 573 | 	      TABLE ACCESS BY INDEX ROWID BATCHED | V_DOMAINE		|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*574 | 	       INDEX RANGE SCAN 		  | DOM_TYPVAL		|      0 |	1 |	1   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*575 | 	     FILTER				  |			|      7 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 576 | 	      TABLE ACCESS BY INDEX ROWID BATCHED | V_DOMAINE		|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*577 | 	       INDEX RANGE SCAN 		  | DOM_TYPVAL		|      0 |	1 |	1   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*578 | 	     FILTER				  |			|      7 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 579 | 	      TABLE ACCESS BY INDEX ROWID BATCHED | V_DOMAINE		|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*580 | 	       INDEX RANGE SCAN 		  | DOM_TYPVAL		|      0 |	1 |	1   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*581 | 	     FILTER				  |			|      7 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 582 | 	      TABLE ACCESS BY INDEX ROWID BATCHED | V_DOMAINE		|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*583 | 	       INDEX RANGE SCAN 		  | DOM_TYPVAL		|      0 |	1 |	1   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*584 | 	     FILTER				  |			|      7 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 585 | 	      TABLE ACCESS BY INDEX ROWID BATCHED | V_DOMAINE		|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*586 | 	       INDEX RANGE SCAN 		  | DOM_TYPVAL		|      0 |	1 |	1   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*587 | 	     FILTER				  |			|      7 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 588 | 	      TABLE ACCESS BY INDEX ROWID BATCHED | V_DOMAINE		|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*589 | 	       INDEX RANGE SCAN 		  | DOM_TYPVAL		|      0 |	1 |	1   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*590 | 	     FILTER				  |			|      7 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 591 | 	      TABLE ACCESS BY INDEX ROWID BATCHED | V_DOMAINE		|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*592 | 	       INDEX RANGE SCAN 		  | DOM_TYPVAL		|      0 |	1 |	1   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*593 | 	     FILTER				  |			|      7 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 594 | 	      TABLE ACCESS BY INDEX ROWID BATCHED | V_DOMAINE		|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*595 | 	       INDEX RANGE SCAN 		  | DOM_TYPVAL		|      0 |	1 |	1   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*596 | 	     FILTER				  |			|      7 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 597 | 	      TABLE ACCESS BY INDEX ROWID BATCHED | V_DOMAINE		|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*598 | 	       INDEX RANGE SCAN 		  | DOM_TYPVAL		|      0 |	1 |	1   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*599 | 	     FILTER				  |			|      7 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 600 | 	      TABLE ACCESS BY INDEX ROWID BATCHED | V_DOMAINE		|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*601 | 	       INDEX RANGE SCAN 		  | DOM_TYPVAL		|      0 |	1 |	1   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*602 | 	     FILTER				  |			|      7 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 603 | 	      TABLE ACCESS BY INDEX ROWID BATCHED | V_DOMAINE		|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*604 | 	       INDEX RANGE SCAN 		  | DOM_TYPVAL		|      0 |	1 |	1   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*605 | 	     FILTER				  |			|      7 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 606 | 	      TABLE ACCESS BY INDEX ROWID BATCHED | V_DOMAINE		|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*607 | 	       INDEX RANGE SCAN 		  | DOM_TYPVAL		|      0 |	1 |	1   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*608 | 	     FILTER				  |			|      7 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 609 | 	      TABLE ACCESS BY INDEX ROWID BATCHED | V_DOMAINE		|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*610 | 	       INDEX RANGE SCAN 		  | DOM_TYPVAL		|      0 |	1 |	1   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*611 | 	     FILTER				  |			|      7 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 612 | 	      TABLE ACCESS BY INDEX ROWID BATCHED | V_DOMAINE		|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*613 | 	       INDEX RANGE SCAN 		  | DOM_TYPVAL		|      0 |	1 |	1   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*614 | 	     FILTER				  |			|      7 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 615 | 	      TABLE ACCESS BY INDEX ROWID BATCHED | V_DOMAINE		|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*616 | 	       INDEX RANGE SCAN 		  | DOM_TYPVAL		|      0 |	1 |	1   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*617 | 	     FILTER				  |			|      7 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 618 | 	      TABLE ACCESS BY INDEX ROWID BATCHED | V_DOMAINE		|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*619 | 	       INDEX RANGE SCAN 		  | DOM_TYPVAL		|      0 |	1 |	1   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*620 | 	     FILTER				  |			|      7 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 621 | 	      TABLE ACCESS BY INDEX ROWID BATCHED | V_DOMAINE		|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*622 | 	       INDEX RANGE SCAN 		  | DOM_TYPVAL		|      0 |	1 |	1   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*623 | 	     FILTER				  |			|      7 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 624 | 	      TABLE ACCESS BY INDEX ROWID BATCHED | V_DOMAINE		|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*625 | 	       INDEX RANGE SCAN 		  | DOM_TYPVAL		|      0 |	1 |	1   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*626 | 	     FILTER				  |			|      7 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 627 | 	      TABLE ACCESS BY INDEX ROWID BATCHED | V_DOMAINE		|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*628 | 	       INDEX RANGE SCAN 		  | DOM_TYPVAL		|      0 |	1 |	1   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*629 | 	     FILTER				  |			|      7 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 630 | 	      TABLE ACCESS BY INDEX ROWID BATCHED | V_DOMAINE		|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*631 | 	       INDEX RANGE SCAN 		  | DOM_TYPVAL		|      0 |	1 |	1   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*632 | 	     FILTER				  |			|      7 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 633 | 	      TABLE ACCESS BY INDEX ROWID BATCHED | V_DOMAINE		|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*634 | 	       INDEX RANGE SCAN 		  | DOM_TYPVAL		|      0 |	1 |	1   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*635 | 	     FILTER				  |			|      7 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 636 | 	      TABLE ACCESS BY INDEX ROWID BATCHED | V_DOMAINE		|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*637 | 	       INDEX RANGE SCAN 		  | DOM_TYPVAL		|      0 |	1 |	1   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*638 | 	     FILTER				  |			|      7 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 639 | 	      TABLE ACCESS BY INDEX ROWID BATCHED | V_DOMAINE		|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*640 | 	       INDEX RANGE SCAN 		  | DOM_TYPVAL		|      0 |	1 |	1   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*641 | 	     FILTER				  |			|      7 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 642 | 	      TABLE ACCESS BY INDEX ROWID BATCHED | V_DOMAINE		|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*643 | 	       INDEX RANGE SCAN 		  | DOM_TYPVAL		|      0 |	1 |	1   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*644 | 	     FILTER				  |			|      7 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 645 | 	      TABLE ACCESS BY INDEX ROWID BATCHED | V_DOMAINE		|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*646 | 	       INDEX RANGE SCAN 		  | DOM_TYPVAL		|      0 |	1 |	1   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*647 | 	     FILTER				  |			|      7 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 648 | 	      TABLE ACCESS BY INDEX ROWID BATCHED | V_DOMAINE		|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*649 | 	       INDEX RANGE SCAN 		  | DOM_TYPVAL		|      0 |	1 |	1   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*650 | 	     FILTER				  |			|      7 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 651 | 	      TABLE ACCESS BY INDEX ROWID BATCHED | V_DOMAINE		|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*652 | 	       INDEX RANGE SCAN 		  | DOM_TYPVAL		|      0 |	1 |	1   (0)|      0 |00:00:00.01 |	     0 |      0 |
| 653 | 	VIEW PUSHED PREDICATE			  |			|      7 |	1 |   108   (0)|      7 |00:00:00.01 |	    19 |      1 |
| 654 | 	 SORT GROUP BY				  |			|      7 |	1 |   108   (0)|      7 |00:00:00.01 |	    19 |      1 |
| 655 | 	  VIEW					  | V_TDOMAINE		|      7 |     36 |   108   (0)|      7 |00:00:00.01 |	    19 |      1 |
| 656 | 	   UNION-ALL				  |			|      7 |	  |	       |      7 |00:00:00.01 |	    19 |      1 |
|*657 | 	    FILTER				  |			|      7 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 658 | 	     TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE		|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*659 | 	      INDEX RANGE SCAN			  | DOM_TYPVAL		|      0 |	1 |	1   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*660 | 	    FILTER				  |			|      7 |	  |	       |      7 |00:00:00.01 |	    19 |      1 |
| 661 | 	     TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE		|      7 |	1 |	3   (0)|      7 |00:00:00.01 |	    19 |      1 |
|*662 | 	      INDEX RANGE SCAN			  | DOM_TYPVAL		|      7 |	1 |	1   (0)|      7 |00:00:00.01 |	    12 |      1 |
|*663 | 	    FILTER				  |			|      7 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 664 | 	     TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE		|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*665 | 	      INDEX RANGE SCAN			  | DOM_TYPVAL		|      0 |	1 |	1   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*666 | 	    FILTER				  |			|      7 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 667 | 	     TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE		|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*668 | 	      INDEX RANGE SCAN			  | DOM_TYPVAL		|      0 |	1 |	1   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*669 | 	    FILTER				  |			|      7 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 670 | 	     TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE		|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*671 | 	      INDEX RANGE SCAN			  | DOM_TYPVAL		|      0 |	1 |	1   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*672 | 	    FILTER				  |			|      7 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 673 | 	     TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE		|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*674 | 	      INDEX RANGE SCAN			  | DOM_TYPVAL		|      0 |	1 |	1   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*675 | 	    FILTER				  |			|      7 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 676 | 	     TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE		|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*677 | 	      INDEX RANGE SCAN			  | DOM_TYPVAL		|      0 |	1 |	1   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*678 | 	    FILTER				  |			|      7 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 679 | 	     TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE		|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*680 | 	      INDEX RANGE SCAN			  | DOM_TYPVAL		|      0 |	1 |	1   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*681 | 	    FILTER				  |			|      7 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 682 | 	     TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE		|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*683 | 	      INDEX RANGE SCAN			  | DOM_TYPVAL		|      0 |	1 |	1   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*684 | 	    FILTER				  |			|      7 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 685 | 	     TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE		|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*686 | 	      INDEX RANGE SCAN			  | DOM_TYPVAL		|      0 |	1 |	1   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*687 | 	    FILTER				  |			|      7 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 688 | 	     TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE		|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*689 | 	      INDEX RANGE SCAN			  | DOM_TYPVAL		|      0 |	1 |	1   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*690 | 	    FILTER				  |			|      7 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 691 | 	     TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE		|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*692 | 	      INDEX RANGE SCAN			  | DOM_TYPVAL		|      0 |	1 |	1   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*693 | 	    FILTER				  |			|      7 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 694 | 	     TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE		|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*695 | 	      INDEX RANGE SCAN			  | DOM_TYPVAL		|      0 |	1 |	1   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*696 | 	    FILTER				  |			|      7 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 697 | 	     TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE		|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*698 | 	      INDEX RANGE SCAN			  | DOM_TYPVAL		|      0 |	1 |	1   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*699 | 	    FILTER				  |			|      7 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 700 | 	     TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE		|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*701 | 	      INDEX RANGE SCAN			  | DOM_TYPVAL		|      0 |	1 |	1   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*702 | 	    FILTER				  |			|      7 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 703 | 	     TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE		|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*704 | 	      INDEX RANGE SCAN			  | DOM_TYPVAL		|      0 |	1 |	1   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*705 | 	    FILTER				  |			|      7 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 706 | 	     TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE		|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*707 | 	      INDEX RANGE SCAN			  | DOM_TYPVAL		|      0 |	1 |	1   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*708 | 	    FILTER				  |			|      7 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 709 | 	     TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE		|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*710 | 	      INDEX RANGE SCAN			  | DOM_TYPVAL		|      0 |	1 |	1   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*711 | 	    FILTER				  |			|      7 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 712 | 	     TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE		|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*713 | 	      INDEX RANGE SCAN			  | DOM_TYPVAL		|      0 |	1 |	1   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*714 | 	    FILTER				  |			|      7 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 715 | 	     TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE		|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*716 | 	      INDEX RANGE SCAN			  | DOM_TYPVAL		|      0 |	1 |	1   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*717 | 	    FILTER				  |			|      7 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 718 | 	     TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE		|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*719 | 	      INDEX RANGE SCAN			  | DOM_TYPVAL		|      0 |	1 |	1   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*720 | 	    FILTER				  |			|      7 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 721 | 	     TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE		|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*722 | 	      INDEX RANGE SCAN			  | DOM_TYPVAL		|      0 |	1 |	1   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*723 | 	    FILTER				  |			|      7 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 724 | 	     TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE		|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*725 | 	      INDEX RANGE SCAN			  | DOM_TYPVAL		|      0 |	1 |	1   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*726 | 	    FILTER				  |			|      7 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 727 | 	     TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE		|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*728 | 	      INDEX RANGE SCAN			  | DOM_TYPVAL		|      0 |	1 |	1   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*729 | 	    FILTER				  |			|      7 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 730 | 	     TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE		|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*731 | 	      INDEX RANGE SCAN			  | DOM_TYPVAL		|      0 |	1 |	1   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*732 | 	    FILTER				  |			|      7 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 733 | 	     TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE		|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*734 | 	      INDEX RANGE SCAN			  | DOM_TYPVAL		|      0 |	1 |	1   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*735 | 	    FILTER				  |			|      7 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 736 | 	     TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE		|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*737 | 	      INDEX RANGE SCAN			  | DOM_TYPVAL		|      0 |	1 |	1   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*738 | 	    FILTER				  |			|      7 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 739 | 	     TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE		|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*740 | 	      INDEX RANGE SCAN			  | DOM_TYPVAL		|      0 |	1 |	1   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*741 | 	    FILTER				  |			|      7 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 742 | 	     TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE		|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*743 | 	      INDEX RANGE SCAN			  | DOM_TYPVAL		|      0 |	1 |	1   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*744 | 	    FILTER				  |			|      7 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 745 | 	     TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE		|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*746 | 	      INDEX RANGE SCAN			  | DOM_TYPVAL		|      0 |	1 |	1   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*747 | 	    FILTER				  |			|      7 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 748 | 	     TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE		|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*749 | 	      INDEX RANGE SCAN			  | DOM_TYPVAL		|      0 |	1 |	1   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*750 | 	    FILTER				  |			|      7 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 751 | 	     TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE		|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*752 | 	      INDEX RANGE SCAN			  | DOM_TYPVAL		|      0 |	1 |	1   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*753 | 	    FILTER				  |			|      7 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 754 | 	     TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE		|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*755 | 	      INDEX RANGE SCAN			  | DOM_TYPVAL		|      0 |	1 |	1   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*756 | 	    FILTER				  |			|      7 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 757 | 	     TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE		|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*758 | 	      INDEX RANGE SCAN			  | DOM_TYPVAL		|      0 |	1 |	1   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*759 | 	    FILTER				  |			|      7 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 760 | 	     TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE		|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*761 | 	      INDEX RANGE SCAN			  | DOM_TYPVAL		|      0 |	1 |	1   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*762 | 	    FILTER				  |			|      7 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 763 | 	     TABLE ACCESS BY INDEX ROWID BATCHED  | V_DOMAINE		|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*764 | 	      INDEX RANGE SCAN			  | DOM_TYPVAL		|      0 |	1 |	1   (0)|      0 |00:00:00.01 |	     0 |      0 |
| 765 |        VIEW PUSHED PREDICATE			  |			|      7 |	1 |   144   (0)|      5 |00:00:00.01 |	    20 |      0 |
| 766 | 	SORT GROUP BY				  |			|      7 |	1 |   144   (0)|      5 |00:00:00.01 |	    20 |      0 |
| 767 | 	 VIEW					  | V_TDOMAINE		|      7 |     36 |   144   (0)|      5 |00:00:00.01 |	    20 |      0 |
| 768 | 	  UNION-ALL				  |			|      7 |	  |	       |      5 |00:00:00.01 |	    20 |      0 |
|*769 | 	   FILTER				  |			|      7 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 770 | 	    TABLE ACCESS BY INDEX ROWID BATCHED   | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*771 | 	     INDEX RANGE SCAN			  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*772 | 	   FILTER				  |			|      7 |	  |	       |      5 |00:00:00.01 |	    20 |      0 |
| 773 | 	    TABLE ACCESS BY INDEX ROWID BATCHED   | V_DOMAINE		|      7 |	1 |	4   (0)|      5 |00:00:00.01 |	    20 |      0 |
|*774 | 	     INDEX RANGE SCAN			  | DOM_TYPABREV	|      7 |	1 |	3   (0)|      5 |00:00:00.01 |	    15 |      0 |
|*775 | 	   FILTER				  |			|      7 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 776 | 	    TABLE ACCESS BY INDEX ROWID BATCHED   | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*777 | 	     INDEX RANGE SCAN			  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*778 | 	   FILTER				  |			|      7 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 779 | 	    TABLE ACCESS BY INDEX ROWID BATCHED   | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*780 | 	     INDEX RANGE SCAN			  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*781 | 	   FILTER				  |			|      7 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 782 | 	    TABLE ACCESS BY INDEX ROWID BATCHED   | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*783 | 	     INDEX RANGE SCAN			  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*784 | 	   FILTER				  |			|      7 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 785 | 	    TABLE ACCESS BY INDEX ROWID BATCHED   | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*786 | 	     INDEX RANGE SCAN			  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*787 | 	   FILTER				  |			|      7 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 788 | 	    TABLE ACCESS BY INDEX ROWID BATCHED   | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*789 | 	     INDEX RANGE SCAN			  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*790 | 	   FILTER				  |			|      7 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 791 | 	    TABLE ACCESS BY INDEX ROWID BATCHED   | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*792 | 	     INDEX RANGE SCAN			  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*793 | 	   FILTER				  |			|      7 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 794 | 	    TABLE ACCESS BY INDEX ROWID BATCHED   | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*795 | 	     INDEX RANGE SCAN			  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*796 | 	   FILTER				  |			|      7 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 797 | 	    TABLE ACCESS BY INDEX ROWID BATCHED   | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*798 | 	     INDEX RANGE SCAN			  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*799 | 	   FILTER				  |			|      7 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 800 | 	    TABLE ACCESS BY INDEX ROWID BATCHED   | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*801 | 	     INDEX RANGE SCAN			  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*802 | 	   FILTER				  |			|      7 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 803 | 	    TABLE ACCESS BY INDEX ROWID BATCHED   | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*804 | 	     INDEX RANGE SCAN			  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*805 | 	   FILTER				  |			|      7 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 806 | 	    TABLE ACCESS BY INDEX ROWID BATCHED   | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*807 | 	     INDEX RANGE SCAN			  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*808 | 	   FILTER				  |			|      7 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 809 | 	    TABLE ACCESS BY INDEX ROWID BATCHED   | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*810 | 	     INDEX RANGE SCAN			  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*811 | 	   FILTER				  |			|      7 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 812 | 	    TABLE ACCESS BY INDEX ROWID BATCHED   | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*813 | 	     INDEX RANGE SCAN			  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*814 | 	   FILTER				  |			|      7 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 815 | 	    TABLE ACCESS BY INDEX ROWID BATCHED   | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*816 | 	     INDEX RANGE SCAN			  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*817 | 	   FILTER				  |			|      7 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 818 | 	    TABLE ACCESS BY INDEX ROWID BATCHED   | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*819 | 	     INDEX RANGE SCAN			  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*820 | 	   FILTER				  |			|      7 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 821 | 	    TABLE ACCESS BY INDEX ROWID BATCHED   | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*822 | 	     INDEX RANGE SCAN			  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*823 | 	   FILTER				  |			|      7 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 824 | 	    TABLE ACCESS BY INDEX ROWID BATCHED   | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*825 | 	     INDEX RANGE SCAN			  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*826 | 	   FILTER				  |			|      7 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 827 | 	    TABLE ACCESS BY INDEX ROWID BATCHED   | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*828 | 	     INDEX RANGE SCAN			  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*829 | 	   FILTER				  |			|      7 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 830 | 	    TABLE ACCESS BY INDEX ROWID BATCHED   | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*831 | 	     INDEX RANGE SCAN			  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*832 | 	   FILTER				  |			|      7 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 833 | 	    TABLE ACCESS BY INDEX ROWID BATCHED   | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*834 | 	     INDEX RANGE SCAN			  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*835 | 	   FILTER				  |			|      7 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 836 | 	    TABLE ACCESS BY INDEX ROWID BATCHED   | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*837 | 	     INDEX RANGE SCAN			  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*838 | 	   FILTER				  |			|      7 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 839 | 	    TABLE ACCESS BY INDEX ROWID BATCHED   | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*840 | 	     INDEX RANGE SCAN			  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*841 | 	   FILTER				  |			|      7 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 842 | 	    TABLE ACCESS BY INDEX ROWID BATCHED   | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*843 | 	     INDEX RANGE SCAN			  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*844 | 	   FILTER				  |			|      7 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 845 | 	    TABLE ACCESS BY INDEX ROWID BATCHED   | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*846 | 	     INDEX RANGE SCAN			  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*847 | 	   FILTER				  |			|      7 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 848 | 	    TABLE ACCESS BY INDEX ROWID BATCHED   | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*849 | 	     INDEX RANGE SCAN			  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*850 | 	   FILTER				  |			|      7 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 851 | 	    TABLE ACCESS BY INDEX ROWID BATCHED   | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*852 | 	     INDEX RANGE SCAN			  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*853 | 	   FILTER				  |			|      7 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 854 | 	    TABLE ACCESS BY INDEX ROWID BATCHED   | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*855 | 	     INDEX RANGE SCAN			  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*856 | 	   FILTER				  |			|      7 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 857 | 	    TABLE ACCESS BY INDEX ROWID BATCHED   | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*858 | 	     INDEX RANGE SCAN			  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*859 | 	   FILTER				  |			|      7 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 860 | 	    TABLE ACCESS BY INDEX ROWID BATCHED   | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*861 | 	     INDEX RANGE SCAN			  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*862 | 	   FILTER				  |			|      7 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 863 | 	    TABLE ACCESS BY INDEX ROWID BATCHED   | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*864 | 	     INDEX RANGE SCAN			  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*865 | 	   FILTER				  |			|      7 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 866 | 	    TABLE ACCESS BY INDEX ROWID BATCHED   | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*867 | 	     INDEX RANGE SCAN			  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*868 | 	   FILTER				  |			|      7 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 869 | 	    TABLE ACCESS BY INDEX ROWID BATCHED   | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*870 | 	     INDEX RANGE SCAN			  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*871 | 	   FILTER				  |			|      7 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 872 | 	    TABLE ACCESS BY INDEX ROWID BATCHED   | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*873 | 	     INDEX RANGE SCAN			  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*874 | 	   FILTER				  |			|      7 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 875 | 	    TABLE ACCESS BY INDEX ROWID BATCHED   | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*876 | 	     INDEX RANGE SCAN			  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
| 877 |       VIEW PUSHED PREDICATE			  |			|      7 |	1 |   144   (0)|      7 |00:00:00.01 |	    24 |      0 |
| 878 |        SORT GROUP BY				  |			|      7 |	1 |   144   (0)|      7 |00:00:00.01 |	    24 |      0 |
| 879 | 	VIEW					  | V_TDOMAINE		|      7 |     36 |   144   (0)|      7 |00:00:00.01 |	    24 |      0 |
| 880 | 	 UNION-ALL				  |			|      7 |	  |	       |      7 |00:00:00.01 |	    24 |      0 |
|*881 | 	  FILTER				  |			|      7 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 882 | 	   TABLE ACCESS BY INDEX ROWID BATCHED	  | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*883 | 	    INDEX RANGE SCAN			  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*884 | 	  FILTER				  |			|      7 |	  |	       |      7 |00:00:00.01 |	    24 |      0 |
| 885 | 	   TABLE ACCESS BY INDEX ROWID BATCHED	  | V_DOMAINE		|      7 |	1 |	4   (0)|      7 |00:00:00.01 |	    24 |      0 |
|*886 | 	    INDEX RANGE SCAN			  | DOM_TYPABREV	|      7 |	1 |	3   (0)|      7 |00:00:00.01 |	    17 |      0 |
|*887 | 	  FILTER				  |			|      7 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 888 | 	   TABLE ACCESS BY INDEX ROWID BATCHED	  | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*889 | 	    INDEX RANGE SCAN			  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*890 | 	  FILTER				  |			|      7 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 891 | 	   TABLE ACCESS BY INDEX ROWID BATCHED	  | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*892 | 	    INDEX RANGE SCAN			  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*893 | 	  FILTER				  |			|      7 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 894 | 	   TABLE ACCESS BY INDEX ROWID BATCHED	  | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*895 | 	    INDEX RANGE SCAN			  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*896 | 	  FILTER				  |			|      7 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 897 | 	   TABLE ACCESS BY INDEX ROWID BATCHED	  | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*898 | 	    INDEX RANGE SCAN			  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*899 | 	  FILTER				  |			|      7 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 900 | 	   TABLE ACCESS BY INDEX ROWID BATCHED	  | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*901 | 	    INDEX RANGE SCAN			  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*902 | 	  FILTER				  |			|      7 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 903 | 	   TABLE ACCESS BY INDEX ROWID BATCHED	  | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*904 | 	    INDEX RANGE SCAN			  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*905 | 	  FILTER				  |			|      7 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 906 | 	   TABLE ACCESS BY INDEX ROWID BATCHED	  | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*907 | 	    INDEX RANGE SCAN			  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*908 | 	  FILTER				  |			|      7 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 909 | 	   TABLE ACCESS BY INDEX ROWID BATCHED	  | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*910 | 	    INDEX RANGE SCAN			  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*911 | 	  FILTER				  |			|      7 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 912 | 	   TABLE ACCESS BY INDEX ROWID BATCHED	  | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*913 | 	    INDEX RANGE SCAN			  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*914 | 	  FILTER				  |			|      7 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 915 | 	   TABLE ACCESS BY INDEX ROWID BATCHED	  | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*916 | 	    INDEX RANGE SCAN			  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*917 | 	  FILTER				  |			|      7 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 918 | 	   TABLE ACCESS BY INDEX ROWID BATCHED	  | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*919 | 	    INDEX RANGE SCAN			  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*920 | 	  FILTER				  |			|      7 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 921 | 	   TABLE ACCESS BY INDEX ROWID BATCHED	  | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*922 | 	    INDEX RANGE SCAN			  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*923 | 	  FILTER				  |			|      7 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 924 | 	   TABLE ACCESS BY INDEX ROWID BATCHED	  | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*925 | 	    INDEX RANGE SCAN			  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*926 | 	  FILTER				  |			|      7 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 927 | 	   TABLE ACCESS BY INDEX ROWID BATCHED	  | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*928 | 	    INDEX RANGE SCAN			  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*929 | 	  FILTER				  |			|      7 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 930 | 	   TABLE ACCESS BY INDEX ROWID BATCHED	  | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*931 | 	    INDEX RANGE SCAN			  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*932 | 	  FILTER				  |			|      7 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 933 | 	   TABLE ACCESS BY INDEX ROWID BATCHED	  | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*934 | 	    INDEX RANGE SCAN			  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*935 | 	  FILTER				  |			|      7 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 936 | 	   TABLE ACCESS BY INDEX ROWID BATCHED	  | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*937 | 	    INDEX RANGE SCAN			  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*938 | 	  FILTER				  |			|      7 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 939 | 	   TABLE ACCESS BY INDEX ROWID BATCHED	  | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*940 | 	    INDEX RANGE SCAN			  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*941 | 	  FILTER				  |			|      7 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 942 | 	   TABLE ACCESS BY INDEX ROWID BATCHED	  | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*943 | 	    INDEX RANGE SCAN			  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*944 | 	  FILTER				  |			|      7 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 945 | 	   TABLE ACCESS BY INDEX ROWID BATCHED	  | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*946 | 	    INDEX RANGE SCAN			  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*947 | 	  FILTER				  |			|      7 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 948 | 	   TABLE ACCESS BY INDEX ROWID BATCHED	  | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*949 | 	    INDEX RANGE SCAN			  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*950 | 	  FILTER				  |			|      7 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 951 | 	   TABLE ACCESS BY INDEX ROWID BATCHED	  | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*952 | 	    INDEX RANGE SCAN			  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*953 | 	  FILTER				  |			|      7 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 954 | 	   TABLE ACCESS BY INDEX ROWID BATCHED	  | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*955 | 	    INDEX RANGE SCAN			  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*956 | 	  FILTER				  |			|      7 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 957 | 	   TABLE ACCESS BY INDEX ROWID BATCHED	  | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*958 | 	    INDEX RANGE SCAN			  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*959 | 	  FILTER				  |			|      7 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 960 | 	   TABLE ACCESS BY INDEX ROWID BATCHED	  | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*961 | 	    INDEX RANGE SCAN			  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*962 | 	  FILTER				  |			|      7 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 963 | 	   TABLE ACCESS BY INDEX ROWID BATCHED	  | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*964 | 	    INDEX RANGE SCAN			  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*965 | 	  FILTER				  |			|      7 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 966 | 	   TABLE ACCESS BY INDEX ROWID BATCHED	  | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*967 | 	    INDEX RANGE SCAN			  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*968 | 	  FILTER				  |			|      7 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 969 | 	   TABLE ACCESS BY INDEX ROWID BATCHED	  | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*970 | 	    INDEX RANGE SCAN			  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*971 | 	  FILTER				  |			|      7 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 972 | 	   TABLE ACCESS BY INDEX ROWID BATCHED	  | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*973 | 	    INDEX RANGE SCAN			  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*974 | 	  FILTER				  |			|      7 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 975 | 	   TABLE ACCESS BY INDEX ROWID BATCHED	  | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*976 | 	    INDEX RANGE SCAN			  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*977 | 	  FILTER				  |			|      7 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 978 | 	   TABLE ACCESS BY INDEX ROWID BATCHED	  | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*979 | 	    INDEX RANGE SCAN			  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*980 | 	  FILTER				  |			|      7 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 981 | 	   TABLE ACCESS BY INDEX ROWID BATCHED	  | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*982 | 	    INDEX RANGE SCAN			  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*983 | 	  FILTER				  |			|      7 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 984 | 	   TABLE ACCESS BY INDEX ROWID BATCHED	  | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*985 | 	    INDEX RANGE SCAN			  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*986 | 	  FILTER				  |			|      7 |	  |	       |      0 |00:00:00.01 |	     0 |      0 |
| 987 | 	   TABLE ACCESS BY INDEX ROWID BATCHED	  | V_DOMAINE		|      0 |	1 |	4   (0)|      0 |00:00:00.01 |	     0 |      0 |
|*988 | 	    INDEX RANGE SCAN			  | DOM_TYPABREV	|      0 |	1 |	3   (0)|      0 |00:00:00.01 |	     0 |      0 |
---------------------------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   3 - filter('AL'=:B1)
   5 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='SE')
   6 - filter('AN'=:B1)
   8 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='SE')
   9 - filter('AR'=:B1)
  11 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='SE')
  12 - filter('BG'=:B1)
  14 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='SE')
  15 - filter('BR'=:B1)
  17 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='SE')
  18 - filter('CE'=:B1)
  20 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='SE')
  21 - filter('CH'=:B1)
  23 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='SE')
  24 - filter('CS'=:B1)
  26 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='SE')
  27 - filter('DA'=:B1)
  29 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='SE')
  30 - filter('EL'=:B1)
  32 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='SE')
  33 - filter('ES'=:B1)
  35 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='SE')
  36 - filter('ET'=:B1)
  38 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='SE')
  39 - filter('FI'=:B1)
  41 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='SE')
  42 - filter('FR'=:B1)
  44 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='SE')
  45 - filter('HR'=:B1)
  47 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='SE')
  48 - filter('HU'=:B1)
  50 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='SE')
  51 - filter('IT'=:B1)
  53 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='SE')
  54 - filter('IW'=:B1)
  56 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='SE')
  57 - filter('JA'=:B1)
  59 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='SE')
  60 - filter('LT'=:B1)
  62 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='SE')
  63 - filter('LV'=:B1)
  65 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='SE')
  66 - filter('MX'=:B1)
  68 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='SE')
  69 - filter('NL'=:B1)
  71 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='SE')
  72 - filter('NO'=:B1)
  74 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='SE')
  75 - filter('PL'=:B1)
  77 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='SE')
  78 - filter('PT'=:B1)
  80 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='SE')
  81 - filter('RO'=:B1)
  83 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='SE')
  84 - filter('RU'=:B1)
  86 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='SE')
  87 - filter('SK'=:B1)
  89 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='SE')
  90 - filter('SL'=:B1)
  92 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='SE')
  93 - filter('SR'=:B1)
  95 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='SE')
  96 - filter('SV'=:B1)
  98 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='SE')
  99 - filter('TR'=:B1)
 101 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='SE')
 102 - filter('US'=:B1)
 104 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='SE')
 105 - filter('VI'=:B1)
 107 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='SE')
 108 - filter('ZH'=:B1)
 110 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='SE')
 111 - access("E"."ALERTE_ID"=:B1)
 114 - filter('AL'=:B1)
 116 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='EC')
 117 - filter('AN'=:B1)
 119 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='EC')
 120 - filter('AR'=:B1)
 122 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='EC')
 123 - filter('BG'=:B1)
 125 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='EC')
 126 - filter('BR'=:B1)
 128 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='EC')
 129 - filter('CE'=:B1)
 131 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='EC')
 132 - filter('CH'=:B1)
 134 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='EC')
 135 - filter('CS'=:B1)
 137 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='EC')
 138 - filter('DA'=:B1)
 140 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='EC')
 141 - filter('EL'=:B1)
 143 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='EC')
 144 - filter('ES'=:B1)
 146 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='EC')
 147 - filter('ET'=:B1)
 149 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='EC')
 150 - filter('FI'=:B1)
 152 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='EC')
 153 - filter('FR'=:B1)
 155 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='EC')
 156 - filter('HR'=:B1)
 158 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='EC')
 159 - filter('HU'=:B1)
 161 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='EC')
 162 - filter('IT'=:B1)
 164 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='EC')
 165 - filter('IW'=:B1)
 167 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='EC')
 168 - filter('JA'=:B1)
 170 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='EC')
 171 - filter('LT'=:B1)
 173 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='EC')
 174 - filter('LV'=:B1)
 176 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='EC')
 177 - filter('MX'=:B1)
 179 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='EC')
 180 - filter('NL'=:B1)
 182 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='EC')
 183 - filter('NO'=:B1)
 185 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='EC')
 186 - filter('PL'=:B1)
 188 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='EC')
 189 - filter('PT'=:B1)
 191 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='EC')
 192 - filter('RO'=:B1)
 194 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='EC')
 195 - filter('RU'=:B1)
 197 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='EC')
 198 - filter('SK'=:B1)
 200 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='EC')
 201 - filter('SL'=:B1)
 203 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='EC')
 204 - filter('SR'=:B1)
 206 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='EC')
 207 - filter('SV'=:B1)
 209 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='EC')
 210 - filter('TR'=:B1)
 212 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='EC')
 213 - filter('US'=:B1)
 215 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='EC')
 216 - filter('VI'=:B1)
 218 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='EC')
 219 - filter('ZH'=:B1)
 221 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='EC')
 222 - access("E"."ALERTE_ID"=:B1)
 225 - filter('AL'=:B1)
 227 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='AF')
 228 - filter('AN'=:B1)
 230 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='AF')
 231 - filter('AR'=:B1)
 233 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='AF')
 234 - filter('BG'=:B1)
 236 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='AF')
 237 - filter('BR'=:B1)
 239 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='AF')
 240 - filter('CE'=:B1)
 242 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='AF')
 243 - filter('CH'=:B1)
 245 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='AF')
 246 - filter('CS'=:B1)
 248 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='AF')
 249 - filter('DA'=:B1)
 251 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='AF')
 252 - filter('EL'=:B1)
 254 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='AF')
 255 - filter('ES'=:B1)
 257 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='AF')
 258 - filter('ET'=:B1)
 260 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='AF')
 261 - filter('FI'=:B1)
 263 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='AF')
 264 - filter('FR'=:B1)
 266 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='AF')
 267 - filter('HR'=:B1)
 269 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='AF')
 270 - filter('HU'=:B1)
 272 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='AF')
 273 - filter('IT'=:B1)
 275 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='AF')
 276 - filter('IW'=:B1)
 278 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='AF')
 279 - filter('JA'=:B1)
 281 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='AF')
 282 - filter('LT'=:B1)
 284 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='AF')
 285 - filter('LV'=:B1)
 287 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='AF')
 288 - filter('MX'=:B1)
 290 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='AF')
 291 - filter('NL'=:B1)
 293 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='AF')
 294 - filter('NO'=:B1)
 296 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='AF')
 297 - filter('PL'=:B1)
 299 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='AF')
 300 - filter('PT'=:B1)
 302 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='AF')
 303 - filter('RO'=:B1)
 305 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='AF')
 306 - filter('RU'=:B1)
 308 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='AF')
 309 - filter('SK'=:B1)
 311 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='AF')
 312 - filter('SL'=:B1)
 314 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='AF')
 315 - filter('SR'=:B1)
 317 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='AF')
 318 - filter('SV'=:B1)
 320 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='AF')
 321 - filter('TR'=:B1)
 323 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='AF')
 324 - filter('US'=:B1)
 326 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='AF')
 327 - filter('VI'=:B1)
 329 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='AF')
 330 - filter('ZH'=:B1)
 332 - access("TYPE"='NONSE_CREATOR' AND "ABREV"='AF')
 335 - filter("REFHIERARCHIE" IS NOT NULL)
 336 - access("ANCREFDOSS"=:B1)
 337 - access("REFDOSS"="REFHIERARCHIE")
 338 - filter("CATEGDOSS"='COMPTE DB CTR')
 339 - filter( IS NOT NULL)
 341 - access("CATEGDOSS"='COMPTE DB CTR')
 342 - filter("REFHIERARCHIE"=:B1)
 343 - access("ANCREFDOSS"=:B1)
 344 - access("ALERTE_ID"=:B1)
 348 - access("TD"."ALERTE_ID"=:B1)
 351 - filter('AL'=:B1)
 353 - access("TYPE"='DV_AGENDA_DETAILS' AND "ABREV"="TD"."TYPE_INFO")
 354 - filter('AN'=:B1)
 356 - access("TYPE"='DV_AGENDA_DETAILS' AND "ABREV"="TD"."TYPE_INFO")
 357 - filter('AR'=:B1)
 359 - access("TYPE"='DV_AGENDA_DETAILS' AND "ABREV"="TD"."TYPE_INFO")
 360 - filter('BG'=:B1)
 362 - access("TYPE"='DV_AGENDA_DETAILS' AND "ABREV"="TD"."TYPE_INFO")
 363 - filter('BR'=:B1)
 365 - access("TYPE"='DV_AGENDA_DETAILS' AND "ABREV"="TD"."TYPE_INFO")
 366 - filter('CE'=:B1)
 368 - access("TYPE"='DV_AGENDA_DETAILS' AND "ABREV"="TD"."TYPE_INFO")
 369 - filter('CH'=:B1)
 371 - access("TYPE"='DV_AGENDA_DETAILS' AND "ABREV"="TD"."TYPE_INFO")
 372 - filter('CS'=:B1)
 374 - access("TYPE"='DV_AGENDA_DETAILS' AND "ABREV"="TD"."TYPE_INFO")
 375 - filter('DA'=:B1)
 377 - access("TYPE"='DV_AGENDA_DETAILS' AND "ABREV"="TD"."TYPE_INFO")
 378 - filter('EL'=:B1)
 380 - access("TYPE"='DV_AGENDA_DETAILS' AND "ABREV"="TD"."TYPE_INFO")
 381 - filter('ES'=:B1)
 383 - access("TYPE"='DV_AGENDA_DETAILS' AND "ABREV"="TD"."TYPE_INFO")
 384 - filter('ET'=:B1)
 386 - access("TYPE"='DV_AGENDA_DETAILS' AND "ABREV"="TD"."TYPE_INFO")
 387 - filter('FI'=:B1)
 389 - access("TYPE"='DV_AGENDA_DETAILS' AND "ABREV"="TD"."TYPE_INFO")
 390 - filter('FR'=:B1)
 392 - access("TYPE"='DV_AGENDA_DETAILS' AND "ABREV"="TD"."TYPE_INFO")
 393 - filter('HR'=:B1)
 395 - access("TYPE"='DV_AGENDA_DETAILS' AND "ABREV"="TD"."TYPE_INFO")
 396 - filter('HU'=:B1)
 398 - access("TYPE"='DV_AGENDA_DETAILS' AND "ABREV"="TD"."TYPE_INFO")
 399 - filter('IT'=:B1)
 401 - access("TYPE"='DV_AGENDA_DETAILS' AND "ABREV"="TD"."TYPE_INFO")
 402 - filter('IW'=:B1)
 404 - access("TYPE"='DV_AGENDA_DETAILS' AND "ABREV"="TD"."TYPE_INFO")
 405 - filter('JA'=:B1)
 407 - access("TYPE"='DV_AGENDA_DETAILS' AND "ABREV"="TD"."TYPE_INFO")
 408 - filter('LT'=:B1)
 410 - access("TYPE"='DV_AGENDA_DETAILS' AND "ABREV"="TD"."TYPE_INFO")
 411 - filter('LV'=:B1)
 413 - access("TYPE"='DV_AGENDA_DETAILS' AND "ABREV"="TD"."TYPE_INFO")
 414 - filter('MX'=:B1)
 416 - access("TYPE"='DV_AGENDA_DETAILS' AND "ABREV"="TD"."TYPE_INFO")
 417 - filter('NL'=:B1)
 419 - access("TYPE"='DV_AGENDA_DETAILS' AND "ABREV"="TD"."TYPE_INFO")
 420 - filter('NO'=:B1)
 422 - access("TYPE"='DV_AGENDA_DETAILS' AND "ABREV"="TD"."TYPE_INFO")
 423 - filter('PL'=:B1)
 425 - access("TYPE"='DV_AGENDA_DETAILS' AND "ABREV"="TD"."TYPE_INFO")
 426 - filter('PT'=:B1)
 428 - access("TYPE"='DV_AGENDA_DETAILS' AND "ABREV"="TD"."TYPE_INFO")
 429 - filter('RO'=:B1)
 431 - access("TYPE"='DV_AGENDA_DETAILS' AND "ABREV"="TD"."TYPE_INFO")
 432 - filter('RU'=:B1)
 434 - access("TYPE"='DV_AGENDA_DETAILS' AND "ABREV"="TD"."TYPE_INFO")
 435 - filter('SK'=:B1)
 437 - access("TYPE"='DV_AGENDA_DETAILS' AND "ABREV"="TD"."TYPE_INFO")
 438 - filter('SL'=:B1)
 440 - access("TYPE"='DV_AGENDA_DETAILS' AND "ABREV"="TD"."TYPE_INFO")
 441 - filter('SR'=:B1)
 443 - access("TYPE"='DV_AGENDA_DETAILS' AND "ABREV"="TD"."TYPE_INFO")
 444 - filter('SV'=:B1)
 446 - access("TYPE"='DV_AGENDA_DETAILS' AND "ABREV"="TD"."TYPE_INFO")
 447 - filter('TR'=:B1)
 449 - access("TYPE"='DV_AGENDA_DETAILS' AND "ABREV"="TD"."TYPE_INFO")
 450 - filter('US'=:B1)
 452 - access("TYPE"='DV_AGENDA_DETAILS' AND "ABREV"="TD"."TYPE_INFO")
 453 - filter('VI'=:B1)
 455 - access("TYPE"='DV_AGENDA_DETAILS' AND "ABREV"="TD"."TYPE_INFO")
 456 - filter('ZH'=:B1)
 458 - access("TYPE"='DV_AGENDA_DETAILS' AND "ABREV"="TD"."TYPE_INFO")
 461 - filter("REFHIERARCHIE" IS NOT NULL)
 462 - access("ANCREFDOSS"=:B1)
 463 - access("REFDOSS"="REFHIERARCHIE")
 464 - filter("CATEGDOSS"='COMPTE DB CTR')
 465 - filter(ROWNUM=1)
 470 - filter("D2"."REFHIERARCHIE" IS NOT NULL)
 471 - access("D2"."ANCREFDOSS"=:B1)
 472 - filter("D1"."CATEGDOSS"='COMPTE DB CTR')
 473 - access("D1"."REFDOSS"="D2"."REFHIERARCHIE")
 474 - access("TI"."REFDOSS"="D1"."REFDOSS" AND "TI"."REFTYPE"='DB')
 475 - access("I"."REFINDIVIDU"="TI"."REFINDIVIDU")
 477 - filter(ROWNUM=1)
 482 - access("GD"."ANCREFDOSS"=:B1)
 483 - access("TI"."REFDOSS"="GD"."REFDOSS" AND "TI"."REFTYPE"='DB')
 484 - access("I"."REFINDIVIDU"="TI"."REFINDIVIDU")
 486 - filter("RNUM">=:B8)
 487 - filter(ROWNUM<=:B7)
 489 - filter(ROWNUM<=:B7)
 504 - access("GIP"."REFINDIVIDU"=:B4 AND "GIP"."TYPE"='appel_nonse')
 508 - access("A"."JOUR"=TO_NUMBER(TO_CHAR(SYSDATE@!,'j')))
       filter("A"."REFPERSO" IS NOT NULL)
 509 - access("A"."REFPERSO"="P"."REFPERSO")
 510 - filter("P"."REFREMPL"=:B5)
 512 - access("GI"."REFINDIVIDU"="STR1")
 514 - access("GP"."REFINDIVIDU"="GI"."REFINDIVIDU")
 515 - filter("TA"."CATPERSO"="GP"."REFPERSO")
 516 - access("TA"."DTCREATION_DT">=TRUNC(TO_DATE(:B6,'yyyy-mm-dd')))
 517 - filter("ABREV6"='O')
 518 - access("VALEUR"="TA"."TYPENCOUR" AND "TYPE"='DV_AGENDA_NON_SE')
 520 - access("TA"."REFDOSS"="GD"."REFDOSS")
 524 - access("T"."REFDOSS"="TA"."REFDOSS" AND "T"."REFTYPE"='CL')
 525 - access("I"."REFINDIVIDU"="T"."REFINDIVIDU")
 534 - access("G"."REFDOSS"="TA"."REFDOSS")
 535 - access("D"."TYPE"='categdoss' AND "D"."VALEUR"="G"."CATEGDOSS")
       filter(("D"."VALEUR"="G"."CATEGDOSS" AND "D"."ABREV" IS NOT NULL))
 536 - access("TI"."REFDOSS"="TA"."REFDOSS")
       filter("TI"."REFDOSS"="G"."REFDOSS")
 537 - filter("I"."REFTYPE_AFF"='CLI')
 538 - access("I"."CATEGDOSS"="D"."ABREV" AND "I"."REFTYPE_BD"="TI"."REFTYPE")
 539 - access("TI"."REFINDIVIDU"="GI"."REFINDIVIDU")
 545 - filter('AL'=:B1)
 547 - access("VALEUR"="TA"."TYPENCOUR" AND "TYPE"='DV_AGENDA_NON_SE')
 548 - filter('AN'=:B1)
 550 - access("VALEUR"="TA"."TYPENCOUR" AND "TYPE"='DV_AGENDA_NON_SE')
 551 - filter('AR'=:B1)
 553 - access("VALEUR"="TA"."TYPENCOUR" AND "TYPE"='DV_AGENDA_NON_SE')
 554 - filter('BG'=:B1)
 556 - access("VALEUR"="TA"."TYPENCOUR" AND "TYPE"='DV_AGENDA_NON_SE')
 557 - filter('BR'=:B1)
 559 - access("VALEUR"="TA"."TYPENCOUR" AND "TYPE"='DV_AGENDA_NON_SE')
 560 - filter('CE'=:B1)
 562 - access("VALEUR"="TA"."TYPENCOUR" AND "TYPE"='DV_AGENDA_NON_SE')
 563 - filter('CH'=:B1)
 565 - access("VALEUR"="TA"."TYPENCOUR" AND "TYPE"='DV_AGENDA_NON_SE')
 566 - filter('CS'=:B1)
 568 - access("VALEUR"="TA"."TYPENCOUR" AND "TYPE"='DV_AGENDA_NON_SE')
 569 - filter('DA'=:B1)
 571 - access("VALEUR"="TA"."TYPENCOUR" AND "TYPE"='DV_AGENDA_NON_SE')
 572 - filter('EL'=:B1)
 574 - access("VALEUR"="TA"."TYPENCOUR" AND "TYPE"='DV_AGENDA_NON_SE')
 575 - filter('ES'=:B1)
 577 - access("VALEUR"="TA"."TYPENCOUR" AND "TYPE"='DV_AGENDA_NON_SE')
 578 - filter('ET'=:B1)
 580 - access("VALEUR"="TA"."TYPENCOUR" AND "TYPE"='DV_AGENDA_NON_SE')
 581 - filter('FI'=:B1)
 583 - access("VALEUR"="TA"."TYPENCOUR" AND "TYPE"='DV_AGENDA_NON_SE')
 584 - filter('FR'=:B1)
 586 - access("VALEUR"="TA"."TYPENCOUR" AND "TYPE"='DV_AGENDA_NON_SE')
 587 - filter('HR'=:B1)
 589 - access("VALEUR"="TA"."TYPENCOUR" AND "TYPE"='DV_AGENDA_NON_SE')
 590 - filter('HU'=:B1)
 592 - access("VALEUR"="TA"."TYPENCOUR" AND "TYPE"='DV_AGENDA_NON_SE')
 593 - filter('IT'=:B1)
 595 - access("VALEUR"="TA"."TYPENCOUR" AND "TYPE"='DV_AGENDA_NON_SE')
 596 - filter('IW'=:B1)
 598 - access("VALEUR"="TA"."TYPENCOUR" AND "TYPE"='DV_AGENDA_NON_SE')
 599 - filter('JA'=:B1)
 601 - access("VALEUR"="TA"."TYPENCOUR" AND "TYPE"='DV_AGENDA_NON_SE')
 602 - filter('LT'=:B1)
 604 - access("VALEUR"="TA"."TYPENCOUR" AND "TYPE"='DV_AGENDA_NON_SE')
 605 - filter('LV'=:B1)
 607 - access("VALEUR"="TA"."TYPENCOUR" AND "TYPE"='DV_AGENDA_NON_SE')
 608 - filter('MX'=:B1)
 610 - access("VALEUR"="TA"."TYPENCOUR" AND "TYPE"='DV_AGENDA_NON_SE')
 611 - filter('NL'=:B1)
 613 - access("VALEUR"="TA"."TYPENCOUR" AND "TYPE"='DV_AGENDA_NON_SE')
 614 - filter('NO'=:B1)
 616 - access("VALEUR"="TA"."TYPENCOUR" AND "TYPE"='DV_AGENDA_NON_SE')
 617 - filter('PL'=:B1)
 619 - access("VALEUR"="TA"."TYPENCOUR" AND "TYPE"='DV_AGENDA_NON_SE')
 620 - filter('PT'=:B1)
 622 - access("VALEUR"="TA"."TYPENCOUR" AND "TYPE"='DV_AGENDA_NON_SE')
 623 - filter('RO'=:B1)
 625 - access("VALEUR"="TA"."TYPENCOUR" AND "TYPE"='DV_AGENDA_NON_SE')
 626 - filter('RU'=:B1)
 628 - access("VALEUR"="TA"."TYPENCOUR" AND "TYPE"='DV_AGENDA_NON_SE')
 629 - filter('SK'=:B1)
 631 - access("VALEUR"="TA"."TYPENCOUR" AND "TYPE"='DV_AGENDA_NON_SE')
 632 - filter('SL'=:B1)
 634 - access("VALEUR"="TA"."TYPENCOUR" AND "TYPE"='DV_AGENDA_NON_SE')
 635 - filter('SR'=:B1)
 637 - access("VALEUR"="TA"."TYPENCOUR" AND "TYPE"='DV_AGENDA_NON_SE')
 638 - filter('SV'=:B1)
 640 - access("VALEUR"="TA"."TYPENCOUR" AND "TYPE"='DV_AGENDA_NON_SE')
 641 - filter('TR'=:B1)
 643 - access("VALEUR"="TA"."TYPENCOUR" AND "TYPE"='DV_AGENDA_NON_SE')
 644 - filter('US'=:B1)
 646 - access("VALEUR"="TA"."TYPENCOUR" AND "TYPE"='DV_AGENDA_NON_SE')
 647 - filter('VI'=:B1)
 649 - access("VALEUR"="TA"."TYPENCOUR" AND "TYPE"='DV_AGENDA_NON_SE')
 650 - filter('ZH'=:B1)
 652 - access("VALEUR"="TA"."TYPENCOUR" AND "TYPE"='DV_AGENDA_NON_SE')
 657 - filter('AL'=:B1)
 659 - access("VALEUR"="GP"."GROUPE" AND "TYPE"='GROUPE')
 660 - filter('AN'=:B1)
 662 - access("VALEUR"="GP"."GROUPE" AND "TYPE"='GROUPE')
 663 - filter('AR'=:B1)
 665 - access("VALEUR"="GP"."GROUPE" AND "TYPE"='GROUPE')
 666 - filter('BG'=:B1)
 668 - access("VALEUR"="GP"."GROUPE" AND "TYPE"='GROUPE')
 669 - filter('BR'=:B1)
 671 - access("VALEUR"="GP"."GROUPE" AND "TYPE"='GROUPE')
 672 - filter('CE'=:B1)
 674 - access("VALEUR"="GP"."GROUPE" AND "TYPE"='GROUPE')
 675 - filter('CH'=:B1)
 677 - access("VALEUR"="GP"."GROUPE" AND "TYPE"='GROUPE')
 678 - filter('CS'=:B1)
 680 - access("VALEUR"="GP"."GROUPE" AND "TYPE"='GROUPE')
 681 - filter('DA'=:B1)
 683 - access("VALEUR"="GP"."GROUPE" AND "TYPE"='GROUPE')
 684 - filter('EL'=:B1)
 686 - access("VALEUR"="GP"."GROUPE" AND "TYPE"='GROUPE')
 687 - filter('ES'=:B1)
 689 - access("VALEUR"="GP"."GROUPE" AND "TYPE"='GROUPE')
 690 - filter('ET'=:B1)
 692 - access("VALEUR"="GP"."GROUPE" AND "TYPE"='GROUPE')
 693 - filter('FI'=:B1)
 695 - access("VALEUR"="GP"."GROUPE" AND "TYPE"='GROUPE')
 696 - filter('FR'=:B1)
 698 - access("VALEUR"="GP"."GROUPE" AND "TYPE"='GROUPE')
 699 - filter('HR'=:B1)
 701 - access("VALEUR"="GP"."GROUPE" AND "TYPE"='GROUPE')
 702 - filter('HU'=:B1)
 704 - access("VALEUR"="GP"."GROUPE" AND "TYPE"='GROUPE')
 705 - filter('IT'=:B1)
 707 - access("VALEUR"="GP"."GROUPE" AND "TYPE"='GROUPE')
 708 - filter('IW'=:B1)
 710 - access("VALEUR"="GP"."GROUPE" AND "TYPE"='GROUPE')
 711 - filter('JA'=:B1)
 713 - access("VALEUR"="GP"."GROUPE" AND "TYPE"='GROUPE')
 714 - filter('LT'=:B1)
 716 - access("VALEUR"="GP"."GROUPE" AND "TYPE"='GROUPE')
 717 - filter('LV'=:B1)
 719 - access("VALEUR"="GP"."GROUPE" AND "TYPE"='GROUPE')
 720 - filter('MX'=:B1)
 722 - access("VALEUR"="GP"."GROUPE" AND "TYPE"='GROUPE')
 723 - filter('NL'=:B1)
 725 - access("VALEUR"="GP"."GROUPE" AND "TYPE"='GROUPE')
 726 - filter('NO'=:B1)
 728 - access("VALEUR"="GP"."GROUPE" AND "TYPE"='GROUPE')
 729 - filter('PL'=:B1)
 731 - access("VALEUR"="GP"."GROUPE" AND "TYPE"='GROUPE')
 732 - filter('PT'=:B1)
 734 - access("VALEUR"="GP"."GROUPE" AND "TYPE"='GROUPE')
 735 - filter('RO'=:B1)
 737 - access("VALEUR"="GP"."GROUPE" AND "TYPE"='GROUPE')
 738 - filter('RU'=:B1)
 740 - access("VALEUR"="GP"."GROUPE" AND "TYPE"='GROUPE')
 741 - filter('SK'=:B1)
 743 - access("VALEUR"="GP"."GROUPE" AND "TYPE"='GROUPE')
 744 - filter('SL'=:B1)
 746 - access("VALEUR"="GP"."GROUPE" AND "TYPE"='GROUPE')
 747 - filter('SR'=:B1)
 749 - access("VALEUR"="GP"."GROUPE" AND "TYPE"='GROUPE')
 750 - filter('SV'=:B1)
 752 - access("VALEUR"="GP"."GROUPE" AND "TYPE"='GROUPE')
 753 - filter('TR'=:B1)
 755 - access("VALEUR"="GP"."GROUPE" AND "TYPE"='GROUPE')
 756 - filter('US'=:B1)
 758 - access("VALEUR"="GP"."GROUPE" AND "TYPE"='GROUPE')
 759 - filter('VI'=:B1)
 761 - access("VALEUR"="GP"."GROUPE" AND "TYPE"='GROUPE')
 762 - filter('ZH'=:B1)
 764 - access("VALEUR"="GP"."GROUPE" AND "TYPE"='GROUPE')
 769 - filter('AL'=:B1)
 771 - access("TYPE"='DEVISE' AND "ABREV"=CASE	WHEN ((:B3='FACTORING') AND ("GD"."REFFACTOR" IS NOT NULL) AND ("V1"."PLACE"=1)) THEN
	      "FTR_FIN_FACTOR"."GETCURRENCY"("GD"."REFFACTOR") WHEN ("V1"."PLACE"=2) THEN "TA"."DEVISE_ALERTE" ELSE NVL("GD"."DEVISE","TA"."DEVISE_ALERTE")
	      END )
 772 - filter('AN'=:B1)
 774 - access("TYPE"='DEVISE' AND "ABREV"=CASE	WHEN ((:B3='FACTORING') AND ("GD"."REFFACTOR" IS NOT NULL) AND ("V1"."PLACE"=1)) THEN
	      "FTR_FIN_FACTOR"."GETCURRENCY"("GD"."REFFACTOR") WHEN ("V1"."PLACE"=2) THEN "TA"."DEVISE_ALERTE" ELSE NVL("GD"."DEVISE","TA"."DEVISE_ALERTE")
	      END )
 775 - filter('AR'=:B1)
 777 - access("TYPE"='DEVISE' AND "ABREV"=CASE	WHEN ((:B3='FACTORING') AND ("GD"."REFFACTOR" IS NOT NULL) AND ("V1"."PLACE"=1)) THEN
	      "FTR_FIN_FACTOR"."GETCURRENCY"("GD"."REFFACTOR") WHEN ("V1"."PLACE"=2) THEN "TA"."DEVISE_ALERTE" ELSE NVL("GD"."DEVISE","TA"."DEVISE_ALERTE")
	      END )
 778 - filter('BG'=:B1)
 780 - access("TYPE"='DEVISE' AND "ABREV"=CASE	WHEN ((:B3='FACTORING') AND ("GD"."REFFACTOR" IS NOT NULL) AND ("V1"."PLACE"=1)) THEN
	      "FTR_FIN_FACTOR"."GETCURRENCY"("GD"."REFFACTOR") WHEN ("V1"."PLACE"=2) THEN "TA"."DEVISE_ALERTE" ELSE NVL("GD"."DEVISE","TA"."DEVISE_ALERTE")
	      END )
 781 - filter('BR'=:B1)
 783 - access("TYPE"='DEVISE' AND "ABREV"=CASE	WHEN ((:B3='FACTORING') AND ("GD"."REFFACTOR" IS NOT NULL) AND ("V1"."PLACE"=1)) THEN
	      "FTR_FIN_FACTOR"."GETCURRENCY"("GD"."REFFACTOR") WHEN ("V1"."PLACE"=2) THEN "TA"."DEVISE_ALERTE" ELSE NVL("GD"."DEVISE","TA"."DEVISE_ALERTE")
	      END )
 784 - filter('CE'=:B1)
 786 - access("TYPE"='DEVISE' AND "ABREV"=CASE	WHEN ((:B3='FACTORING') AND ("GD"."REFFACTOR" IS NOT NULL) AND ("V1"."PLACE"=1)) THEN
	      "FTR_FIN_FACTOR"."GETCURRENCY"("GD"."REFFACTOR") WHEN ("V1"."PLACE"=2) THEN "TA"."DEVISE_ALERTE" ELSE NVL("GD"."DEVISE","TA"."DEVISE_ALERTE")
	      END )
 787 - filter('CH'=:B1)
 789 - access("TYPE"='DEVISE' AND "ABREV"=CASE	WHEN ((:B3='FACTORING') AND ("GD"."REFFACTOR" IS NOT NULL) AND ("V1"."PLACE"=1)) THEN
	      "FTR_FIN_FACTOR"."GETCURRENCY"("GD"."REFFACTOR") WHEN ("V1"."PLACE"=2) THEN "TA"."DEVISE_ALERTE" ELSE NVL("GD"."DEVISE","TA"."DEVISE_ALERTE")
	      END )
 790 - filter('CS'=:B1)
 792 - access("TYPE"='DEVISE' AND "ABREV"=CASE	WHEN ((:B3='FACTORING') AND ("GD"."REFFACTOR" IS NOT NULL) AND ("V1"."PLACE"=1)) THEN
	      "FTR_FIN_FACTOR"."GETCURRENCY"("GD"."REFFACTOR") WHEN ("V1"."PLACE"=2) THEN "TA"."DEVISE_ALERTE" ELSE NVL("GD"."DEVISE","TA"."DEVISE_ALERTE")
	      END )
 793 - filter('DA'=:B1)
 795 - access("TYPE"='DEVISE' AND "ABREV"=CASE	WHEN ((:B3='FACTORING') AND ("GD"."REFFACTOR" IS NOT NULL) AND ("V1"."PLACE"=1)) THEN
	      "FTR_FIN_FACTOR"."GETCURRENCY"("GD"."REFFACTOR") WHEN ("V1"."PLACE"=2) THEN "TA"."DEVISE_ALERTE" ELSE NVL("GD"."DEVISE","TA"."DEVISE_ALERTE")
	      END )
 796 - filter('EL'=:B1)
 798 - access("TYPE"='DEVISE' AND "ABREV"=CASE	WHEN ((:B3='FACTORING') AND ("GD"."REFFACTOR" IS NOT NULL) AND ("V1"."PLACE"=1)) THEN
	      "FTR_FIN_FACTOR"."GETCURRENCY"("GD"."REFFACTOR") WHEN ("V1"."PLACE"=2) THEN "TA"."DEVISE_ALERTE" ELSE NVL("GD"."DEVISE","TA"."DEVISE_ALERTE")
	      END )
 799 - filter('ES'=:B1)
 801 - access("TYPE"='DEVISE' AND "ABREV"=CASE	WHEN ((:B3='FACTORING') AND ("GD"."REFFACTOR" IS NOT NULL) AND ("V1"."PLACE"=1)) THEN
	      "FTR_FIN_FACTOR"."GETCURRENCY"("GD"."REFFACTOR") WHEN ("V1"."PLACE"=2) THEN "TA"."DEVISE_ALERTE" ELSE NVL("GD"."DEVISE","TA"."DEVISE_ALERTE")
	      END )
 802 - filter('ET'=:B1)
 804 - access("TYPE"='DEVISE' AND "ABREV"=CASE	WHEN ((:B3='FACTORING') AND ("GD"."REFFACTOR" IS NOT NULL) AND ("V1"."PLACE"=1)) THEN
	      "FTR_FIN_FACTOR"."GETCURRENCY"("GD"."REFFACTOR") WHEN ("V1"."PLACE"=2) THEN "TA"."DEVISE_ALERTE" ELSE NVL("GD"."DEVISE","TA"."DEVISE_ALERTE")
	      END )
 805 - filter('FI'=:B1)
 807 - access("TYPE"='DEVISE' AND "ABREV"=CASE	WHEN ((:B3='FACTORING') AND ("GD"."REFFACTOR" IS NOT NULL) AND ("V1"."PLACE"=1)) THEN
	      "FTR_FIN_FACTOR"."GETCURRENCY"("GD"."REFFACTOR") WHEN ("V1"."PLACE"=2) THEN "TA"."DEVISE_ALERTE" ELSE NVL("GD"."DEVISE","TA"."DEVISE_ALERTE")
	      END )
 808 - filter('FR'=:B1)
 810 - access("TYPE"='DEVISE' AND "ABREV"=CASE	WHEN ((:B3='FACTORING') AND ("GD"."REFFACTOR" IS NOT NULL) AND ("V1"."PLACE"=1)) THEN
	      "FTR_FIN_FACTOR"."GETCURRENCY"("GD"."REFFACTOR") WHEN ("V1"."PLACE"=2) THEN "TA"."DEVISE_ALERTE" ELSE NVL("GD"."DEVISE","TA"."DEVISE_ALERTE")
	      END )
 811 - filter('HR'=:B1)
 813 - access("TYPE"='DEVISE' AND "ABREV"=CASE	WHEN ((:B3='FACTORING') AND ("GD"."REFFACTOR" IS NOT NULL) AND ("V1"."PLACE"=1)) THEN
	      "FTR_FIN_FACTOR"."GETCURRENCY"("GD"."REFFACTOR") WHEN ("V1"."PLACE"=2) THEN "TA"."DEVISE_ALERTE" ELSE NVL("GD"."DEVISE","TA"."DEVISE_ALERTE")
	      END )
 814 - filter('HU'=:B1)
 816 - access("TYPE"='DEVISE' AND "ABREV"=CASE	WHEN ((:B3='FACTORING') AND ("GD"."REFFACTOR" IS NOT NULL) AND ("V1"."PLACE"=1)) THEN
	      "FTR_FIN_FACTOR"."GETCURRENCY"("GD"."REFFACTOR") WHEN ("V1"."PLACE"=2) THEN "TA"."DEVISE_ALERTE" ELSE NVL("GD"."DEVISE","TA"."DEVISE_ALERTE")
	      END )
 817 - filter('IT'=:B1)
 819 - access("TYPE"='DEVISE' AND "ABREV"=CASE	WHEN ((:B3='FACTORING') AND ("GD"."REFFACTOR" IS NOT NULL) AND ("V1"."PLACE"=1)) THEN
	      "FTR_FIN_FACTOR"."GETCURRENCY"("GD"."REFFACTOR") WHEN ("V1"."PLACE"=2) THEN "TA"."DEVISE_ALERTE" ELSE NVL("GD"."DEVISE","TA"."DEVISE_ALERTE")
	      END )
 820 - filter('IW'=:B1)
 822 - access("TYPE"='DEVISE' AND "ABREV"=CASE	WHEN ((:B3='FACTORING') AND ("GD"."REFFACTOR" IS NOT NULL) AND ("V1"."PLACE"=1)) THEN
	      "FTR_FIN_FACTOR"."GETCURRENCY"("GD"."REFFACTOR") WHEN ("V1"."PLACE"=2) THEN "TA"."DEVISE_ALERTE" ELSE NVL("GD"."DEVISE","TA"."DEVISE_ALERTE")
	      END )
 823 - filter('JA'=:B1)
 825 - access("TYPE"='DEVISE' AND "ABREV"=CASE	WHEN ((:B3='FACTORING') AND ("GD"."REFFACTOR" IS NOT NULL) AND ("V1"."PLACE"=1)) THEN
	      "FTR_FIN_FACTOR"."GETCURRENCY"("GD"."REFFACTOR") WHEN ("V1"."PLACE"=2) THEN "TA"."DEVISE_ALERTE" ELSE NVL("GD"."DEVISE","TA"."DEVISE_ALERTE")
	      END )
 826 - filter('LT'=:B1)
 828 - access("TYPE"='DEVISE' AND "ABREV"=CASE	WHEN ((:B3='FACTORING') AND ("GD"."REFFACTOR" IS NOT NULL) AND ("V1"."PLACE"=1)) THEN
	      "FTR_FIN_FACTOR"."GETCURRENCY"("GD"."REFFACTOR") WHEN ("V1"."PLACE"=2) THEN "TA"."DEVISE_ALERTE" ELSE NVL("GD"."DEVISE","TA"."DEVISE_ALERTE")
	      END )
 829 - filter('LV'=:B1)
 831 - access("TYPE"='DEVISE' AND "ABREV"=CASE	WHEN ((:B3='FACTORING') AND ("GD"."REFFACTOR" IS NOT NULL) AND ("V1"."PLACE"=1)) THEN
	      "FTR_FIN_FACTOR"."GETCURRENCY"("GD"."REFFACTOR") WHEN ("V1"."PLACE"=2) THEN "TA"."DEVISE_ALERTE" ELSE NVL("GD"."DEVISE","TA"."DEVISE_ALERTE")
	      END )
 832 - filter('MX'=:B1)
 834 - access("TYPE"='DEVISE' AND "ABREV"=CASE	WHEN ((:B3='FACTORING') AND ("GD"."REFFACTOR" IS NOT NULL) AND ("V1"."PLACE"=1)) THEN
	      "FTR_FIN_FACTOR"."GETCURRENCY"("GD"."REFFACTOR") WHEN ("V1"."PLACE"=2) THEN "TA"."DEVISE_ALERTE" ELSE NVL("GD"."DEVISE","TA"."DEVISE_ALERTE")
	      END )
 835 - filter('NL'=:B1)
 837 - access("TYPE"='DEVISE' AND "ABREV"=CASE	WHEN ((:B3='FACTORING') AND ("GD"."REFFACTOR" IS NOT NULL) AND ("V1"."PLACE"=1)) THEN
	      "FTR_FIN_FACTOR"."GETCURRENCY"("GD"."REFFACTOR") WHEN ("V1"."PLACE"=2) THEN "TA"."DEVISE_ALERTE" ELSE NVL("GD"."DEVISE","TA"."DEVISE_ALERTE")
	      END )
 838 - filter('NO'=:B1)
 840 - access("TYPE"='DEVISE' AND "ABREV"=CASE	WHEN ((:B3='FACTORING') AND ("GD"."REFFACTOR" IS NOT NULL) AND ("V1"."PLACE"=1)) THEN
	      "FTR_FIN_FACTOR"."GETCURRENCY"("GD"."REFFACTOR") WHEN ("V1"."PLACE"=2) THEN "TA"."DEVISE_ALERTE" ELSE NVL("GD"."DEVISE","TA"."DEVISE_ALERTE")
	      END )
 841 - filter('PL'=:B1)
 843 - access("TYPE"='DEVISE' AND "ABREV"=CASE	WHEN ((:B3='FACTORING') AND ("GD"."REFFACTOR" IS NOT NULL) AND ("V1"."PLACE"=1)) THEN
	      "FTR_FIN_FACTOR"."GETCURRENCY"("GD"."REFFACTOR") WHEN ("V1"."PLACE"=2) THEN "TA"."DEVISE_ALERTE" ELSE NVL("GD"."DEVISE","TA"."DEVISE_ALERTE")
	      END )
 844 - filter('PT'=:B1)
 846 - access("TYPE"='DEVISE' AND "ABREV"=CASE	WHEN ((:B3='FACTORING') AND ("GD"."REFFACTOR" IS NOT NULL) AND ("V1"."PLACE"=1)) THEN
	      "FTR_FIN_FACTOR"."GETCURRENCY"("GD"."REFFACTOR") WHEN ("V1"."PLACE"=2) THEN "TA"."DEVISE_ALERTE" ELSE NVL("GD"."DEVISE","TA"."DEVISE_ALERTE")
	      END )
 847 - filter('RO'=:B1)
 849 - access("TYPE"='DEVISE' AND "ABREV"=CASE	WHEN ((:B3='FACTORING') AND ("GD"."REFFACTOR" IS NOT NULL) AND ("V1"."PLACE"=1)) THEN
	      "FTR_FIN_FACTOR"."GETCURRENCY"("GD"."REFFACTOR") WHEN ("V1"."PLACE"=2) THEN "TA"."DEVISE_ALERTE" ELSE NVL("GD"."DEVISE","TA"."DEVISE_ALERTE")
	      END )
 850 - filter('RU'=:B1)
 852 - access("TYPE"='DEVISE' AND "ABREV"=CASE	WHEN ((:B3='FACTORING') AND ("GD"."REFFACTOR" IS NOT NULL) AND ("V1"."PLACE"=1)) THEN
	      "FTR_FIN_FACTOR"."GETCURRENCY"("GD"."REFFACTOR") WHEN ("V1"."PLACE"=2) THEN "TA"."DEVISE_ALERTE" ELSE NVL("GD"."DEVISE","TA"."DEVISE_ALERTE")
	      END )
 853 - filter('SK'=:B1)
 855 - access("TYPE"='DEVISE' AND "ABREV"=CASE	WHEN ((:B3='FACTORING') AND ("GD"."REFFACTOR" IS NOT NULL) AND ("V1"."PLACE"=1)) THEN
	      "FTR_FIN_FACTOR"."GETCURRENCY"("GD"."REFFACTOR") WHEN ("V1"."PLACE"=2) THEN "TA"."DEVISE_ALERTE" ELSE NVL("GD"."DEVISE","TA"."DEVISE_ALERTE")
	      END )
 856 - filter('SL'=:B1)
 858 - access("TYPE"='DEVISE' AND "ABREV"=CASE	WHEN ((:B3='FACTORING') AND ("GD"."REFFACTOR" IS NOT NULL) AND ("V1"."PLACE"=1)) THEN
	      "FTR_FIN_FACTOR"."GETCURRENCY"("GD"."REFFACTOR") WHEN ("V1"."PLACE"=2) THEN "TA"."DEVISE_ALERTE" ELSE NVL("GD"."DEVISE","TA"."DEVISE_ALERTE")
	      END )
 859 - filter('SR'=:B1)
 861 - access("TYPE"='DEVISE' AND "ABREV"=CASE	WHEN ((:B3='FACTORING') AND ("GD"."REFFACTOR" IS NOT NULL) AND ("V1"."PLACE"=1)) THEN
	      "FTR_FIN_FACTOR"."GETCURRENCY"("GD"."REFFACTOR") WHEN ("V1"."PLACE"=2) THEN "TA"."DEVISE_ALERTE" ELSE NVL("GD"."DEVISE","TA"."DEVISE_ALERTE")
	      END )
 862 - filter('SV'=:B1)
 864 - access("TYPE"='DEVISE' AND "ABREV"=CASE	WHEN ((:B3='FACTORING') AND ("GD"."REFFACTOR" IS NOT NULL) AND ("V1"."PLACE"=1)) THEN
	      "FTR_FIN_FACTOR"."GETCURRENCY"("GD"."REFFACTOR") WHEN ("V1"."PLACE"=2) THEN "TA"."DEVISE_ALERTE" ELSE NVL("GD"."DEVISE","TA"."DEVISE_ALERTE")
	      END )
 865 - filter('TR'=:B1)
 867 - access("TYPE"='DEVISE' AND "ABREV"=CASE	WHEN ((:B3='FACTORING') AND ("GD"."REFFACTOR" IS NOT NULL) AND ("V1"."PLACE"=1)) THEN
	      "FTR_FIN_FACTOR"."GETCURRENCY"("GD"."REFFACTOR") WHEN ("V1"."PLACE"=2) THEN "TA"."DEVISE_ALERTE" ELSE NVL("GD"."DEVISE","TA"."DEVISE_ALERTE")
	      END )
 868 - filter('US'=:B1)
 870 - access("TYPE"='DEVISE' AND "ABREV"=CASE	WHEN ((:B3='FACTORING') AND ("GD"."REFFACTOR" IS NOT NULL) AND ("V1"."PLACE"=1)) THEN
	      "FTR_FIN_FACTOR"."GETCURRENCY"("GD"."REFFACTOR") WHEN ("V1"."PLACE"=2) THEN "TA"."DEVISE_ALERTE" ELSE NVL("GD"."DEVISE","TA"."DEVISE_ALERTE")
	      END )
 871 - filter('VI'=:B1)
 873 - access("TYPE"='DEVISE' AND "ABREV"=CASE	WHEN ((:B3='FACTORING') AND ("GD"."REFFACTOR" IS NOT NULL) AND ("V1"."PLACE"=1)) THEN
	      "FTR_FIN_FACTOR"."GETCURRENCY"("GD"."REFFACTOR") WHEN ("V1"."PLACE"=2) THEN "TA"."DEVISE_ALERTE" ELSE NVL("GD"."DEVISE","TA"."DEVISE_ALERTE")
	      END )
 874 - filter('ZH'=:B1)
 876 - access("TYPE"='DEVISE' AND "ABREV"=CASE	WHEN ((:B3='FACTORING') AND ("GD"."REFFACTOR" IS NOT NULL) AND ("V1"."PLACE"=1)) THEN
	      "FTR_FIN_FACTOR"."GETCURRENCY"("GD"."REFFACTOR") WHEN ("V1"."PLACE"=2) THEN "TA"."DEVISE_ALERTE" ELSE NVL("GD"."DEVISE","TA"."DEVISE_ALERTE")
	      END )
 881 - filter('AL'=:B1)
 883 - access("TYPE"='DV_TYPE_APPEL' AND "ABREV"="TA"."TYPENTITE")
 884 - filter('AN'=:B1)
 886 - access("TYPE"='DV_TYPE_APPEL' AND "ABREV"="TA"."TYPENTITE")
 887 - filter('AR'=:B1)
 889 - access("TYPE"='DV_TYPE_APPEL' AND "ABREV"="TA"."TYPENTITE")
 890 - filter('BG'=:B1)
 892 - access("TYPE"='DV_TYPE_APPEL' AND "ABREV"="TA"."TYPENTITE")
 893 - filter('BR'=:B1)
 895 - access("TYPE"='DV_TYPE_APPEL' AND "ABREV"="TA"."TYPENTITE")
 896 - filter('CE'=:B1)
 898 - access("TYPE"='DV_TYPE_APPEL' AND "ABREV"="TA"."TYPENTITE")
 899 - filter('CH'=:B1)
 901 - access("TYPE"='DV_TYPE_APPEL' AND "ABREV"="TA"."TYPENTITE")
 902 - filter('CS'=:B1)
 904 - access("TYPE"='DV_TYPE_APPEL' AND "ABREV"="TA"."TYPENTITE")
 905 - filter('DA'=:B1)
 907 - access("TYPE"='DV_TYPE_APPEL' AND "ABREV"="TA"."TYPENTITE")
 908 - filter('EL'=:B1)
 910 - access("TYPE"='DV_TYPE_APPEL' AND "ABREV"="TA"."TYPENTITE")
 911 - filter('ES'=:B1)
 913 - access("TYPE"='DV_TYPE_APPEL' AND "ABREV"="TA"."TYPENTITE")
 914 - filter('ET'=:B1)
 916 - access("TYPE"='DV_TYPE_APPEL' AND "ABREV"="TA"."TYPENTITE")
 917 - filter('FI'=:B1)
 919 - access("TYPE"='DV_TYPE_APPEL' AND "ABREV"="TA"."TYPENTITE")
 920 - filter('FR'=:B1)
 922 - access("TYPE"='DV_TYPE_APPEL' AND "ABREV"="TA"."TYPENTITE")
 923 - filter('HR'=:B1)
 925 - access("TYPE"='DV_TYPE_APPEL' AND "ABREV"="TA"."TYPENTITE")
 926 - filter('HU'=:B1)
 928 - access("TYPE"='DV_TYPE_APPEL' AND "ABREV"="TA"."TYPENTITE")
 929 - filter('IT'=:B1)
 931 - access("TYPE"='DV_TYPE_APPEL' AND "ABREV"="TA"."TYPENTITE")
 932 - filter('IW'=:B1)
 934 - access("TYPE"='DV_TYPE_APPEL' AND "ABREV"="TA"."TYPENTITE")
 935 - filter('JA'=:B1)
 937 - access("TYPE"='DV_TYPE_APPEL' AND "ABREV"="TA"."TYPENTITE")
 938 - filter('LT'=:B1)
 940 - access("TYPE"='DV_TYPE_APPEL' AND "ABREV"="TA"."TYPENTITE")
 941 - filter('LV'=:B1)
 943 - access("TYPE"='DV_TYPE_APPEL' AND "ABREV"="TA"."TYPENTITE")
 944 - filter('MX'=:B1)
 946 - access("TYPE"='DV_TYPE_APPEL' AND "ABREV"="TA"."TYPENTITE")
 947 - filter('NL'=:B1)
 949 - access("TYPE"='DV_TYPE_APPEL' AND "ABREV"="TA"."TYPENTITE")
 950 - filter('NO'=:B1)
 952 - access("TYPE"='DV_TYPE_APPEL' AND "ABREV"="TA"."TYPENTITE")
 953 - filter('PL'=:B1)
 955 - access("TYPE"='DV_TYPE_APPEL' AND "ABREV"="TA"."TYPENTITE")
 956 - filter('PT'=:B1)
 958 - access("TYPE"='DV_TYPE_APPEL' AND "ABREV"="TA"."TYPENTITE")
 959 - filter('RO'=:B1)
 961 - access("TYPE"='DV_TYPE_APPEL' AND "ABREV"="TA"."TYPENTITE")
 962 - filter('RU'=:B1)
 964 - access("TYPE"='DV_TYPE_APPEL' AND "ABREV"="TA"."TYPENTITE")
 965 - filter('SK'=:B1)
 967 - access("TYPE"='DV_TYPE_APPEL' AND "ABREV"="TA"."TYPENTITE")
 968 - filter('SL'=:B1)
 970 - access("TYPE"='DV_TYPE_APPEL' AND "ABREV"="TA"."TYPENTITE")
 971 - filter('SR'=:B1)
 973 - access("TYPE"='DV_TYPE_APPEL' AND "ABREV"="TA"."TYPENTITE")
 974 - filter('SV'=:B1)
 976 - access("TYPE"='DV_TYPE_APPEL' AND "ABREV"="TA"."TYPENTITE")
 977 - filter('TR'=:B1)
 979 - access("TYPE"='DV_TYPE_APPEL' AND "ABREV"="TA"."TYPENTITE")
 980 - filter('US'=:B1)
 982 - access("TYPE"='DV_TYPE_APPEL' AND "ABREV"="TA"."TYPENTITE")
 983 - filter('VI'=:B1)
 985 - access("TYPE"='DV_TYPE_APPEL' AND "ABREV"="TA"."TYPENTITE")
 986 - filter('ZH'=:B1)
 988 - access("TYPE"='DV_TYPE_APPEL' AND "ABREV"="TA"."TYPENTITE")

*/
/********************************New Metrics***************************************/

/********************************Index statistics**********************************/

/********************************Other SQLs****************************************/          
/*

*/ 
/********************************Other SQLs****************************************/              
