2305512.1 



select occupant_desc, space_usage_kbytes/1024 as usage_MB from v$sysaux_occupants where space_usage_kbytes > 0 order by space_usage_kbytes desc;



DECLARE
v_tname VARCHAR2(32767);
BEGIN
v_tname := 'AUTO_STATS_ADVISOR_TASK';
DBMS_STATS.DROP_ADVISOR_TASK(v_tname);
END;
/


--recreate the AUTO_STATS_ADVISOR_TASK 

 EXEC DBMS_STATS.INIT_PACKAGE();
 
---Reorganize the table and its indexes after dropping the task.

 ALTER TABLE WRI$_ADV_OBJECTS MOVE;
 ALTER INDEX WRI$_ADV_OBJECTS_IDX_01 REBUILD;
 ALTER INDEX WRI$_ADV_OBJECTS_PK REBUILD;
  ALTER INDEX WRI$_ADV_OBJECTS_IDX_02 REBUILD;
 
 ---alter index SYS.WRH$_SYSMETRIC_HISTORY_INDEX rebuild online tablespace SYSAUX;
 
 select occupant_desc, space_usage_kbytes/1024 as usage_MB from v$sysaux_occupants where space_usage_kbytes > 0 order by space_usage_kbytes desc;


 
 
---- disable
 
 DECLARE
filter1 CLOB;
BEGIN
filter1 := DBMS_STATS.CONFIGURE_ADVISOR_RULE_FILTER('AUTO_STATS_ADVISOR_TASK','EXECUTE',NULL,'DISABLE');
END;
/






----
 
 SET pagesize 300 
SET pagesize 300 
SET linesize 200 
COL "Resize Command" for a110 

SELECT 'alter database datafile '''||file_name||''' resize '||       DECODE(trunc(ceil( (nvl(hwm,1)*(size_db_block))/1024/1024 ) /10),0 ,10, ceil( (nvl(hwm,1)* (size_db_block))/1024/1024 )) ||'M;' "Resize Command",       AUTOEXTENSIBLE , bytes/1024/1024 "CurrentSize(Mb)" ,       ( (bytes/1024/1024) - ceil( (nvl(hwm,1)* (size_db_block))/1024/1024 ) ) "FreeSize(Mb)" 
  FROM dba_data_files a,       ( SELECT /*+ no_merge */ file_id, max(block_id+blocks-1) AS hwm FROM dba_extents GROUP BY file_id ) b ,       (SELECT /*+ no_merge */ TO_NUMBER(value) AS size_db_block FROM v$parameter WHERE name = 'db_block_size') c 
 WHERE a.file_id = b.file_id(+) AND tablespace_name in ('SYSAUX')   AND ceil(blocks*(c.size_db_block)/1024/1024)- ceil((nvl(hwm,1)*(c.size_db_block))/1024/1024 ) > 10 ORDER BY "FreeSize(Mb)" ASC;
 
 



select occupant_desc, space_usage_kbytes/1024 as usage_MB from v$sysaux_occupants where space_usage_kbytes > 0 order by space_usage_kbytes desc;




SELECT 'alter index '|| owner ||'.'||index_name||' rebuild online tablespace '||tablespace_name ||';'
FROM   dba_indexes
WHERE  status = 'UNUSABLE'; 

---
set linesize 555
    set pagesize 555
    col TABLESPACE_NAME for a22
	col FILE_NAME for a61
	select file_id,FILE_NAME, TABLESPACE_NAME, BYTES/1024/1024, MAXBYTES/1024/1024, (increment_by*(bytes/blocks))/1024 increment_by_kb,
	AUTOEXTENSIBLE from dba_data_files where 
    TABLESPACE_NAME='UNDOTBS1'
	/
	
	
	set linesize 555
    set pagesize 555
    col TABLESPACE_NAME for a22
	col FILE_NAME for a61
	select file_id,FILE_NAME, TABLESPACE_NAME, BYTES/1024/1024, MAXBYTES/1024/1024, (increment_by*(bytes/blocks))/1024 increment_by_kb,
	AUTOEXTENSIBLE from dba_data_files where 
    TABLESPACE_NAME='SYSAUX'
	/
	


---
How To Purge Optimizer Statistics Advisor Old Records From 12.2 Onwards (Doc ID 2660128.1)


	
	EXEC DBMS_AUTO_TASK_ADMIN.DISABLE(client_name=>'sql tuning advisor', operation=>NULL, window_name=>NULL);
EXEC DBMS_AUTO_TASK_ADMIN.DISABLE(client_name=>'auto space advisor', operation=>NULL, window_name=>NULL);
EXEC DBMS_AUTO_TASK_ADMIN.DISABLE(client_name=>'auto optimizer stats collection', operation=>NULL, window_name=>NULL);


exec dbms_stats.alter_stats_history_retention(14);

How to Manually Purge Orphan Rows from AWR Repository Tables In Sysaux Tablespace (Doc ID 2536631.1)


exec dbms_stats.purge_stats( SYSDATE - 14 );





col COLUMN_NAME for a35
select OWNER,TABLE_NAME,COLUMN_NAME,TABLE_NAME from dba_lobs where SEGMENT_NAME in('SYS_LOB0000008788C00008$$');

ALTER TABLE WRI$_ADV_OBJECTS MOVE TABLESPACE SYSAUX LOB (ATTR4) STORE AS (TABLESPACE SYSAUX);  



SELECT window_name,
       resource_plan,
       NEXT_START_DATE,
       LAST_START_DATE
FROM   dba_scheduler_windows
ORDER BY window_name;



Time Window	Start	
MONDAY_WINDOW	10 pm	
TUESDAY_WINDOW	10 pm	
WEDNESDAY_WINDOW	10 pm
THURSDAY_WINDOW	10 pm	
FRIDAY_WINDOW	10 pm	
SATURDAY_WINDOW	6 am	
SUNDAY_WINDOW	6 am	
 
 
 
 
 
 
 
 
 
 
 
set serverout on 

exec DBMS_MVIEW_STATS.SET_SYSTEM_DEFAULT ('RETENTION_PERIOD',2);
exec DBMS_MVIEW_STATS.SET_SYSTEM_DEFAULT ('COLLECTION_LEVEL','TYPICAL');
exec DBMS_MVIEW_STATS.SET_MVREF_STATS_PARAMS (null,'TYPICAL',2);
exec DBMS_MVIEW_STATS.PURGE_REFRESH_STATS (null,2);
commit;




