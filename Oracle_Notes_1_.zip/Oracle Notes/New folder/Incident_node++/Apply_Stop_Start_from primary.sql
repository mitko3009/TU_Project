Baramov, Kamen (Oracle DBA) 11:52 AM: 
DGMGRL>  edit database 'PO23STB' set state='apply-off';

Baramov, Kamen (Oracle DBA) 11:52 AM: 
после като метнат праймърито на srv3609

Baramov, Kamen (Oracle DBA) 11:53 AM: 
DGMGRL>  edit database 'PO23STB' set state='apply-on';

Baramov, Kamen (Oracle DBA) 11:54 AM: 
DGMGRL>  show database verbose 'PO23STB';


Pehlivanska, Izabela Kalinova 11:55 AM: 
първо гася праймарито --> спирам аплай с горната команда
след това
пускам аплай ---> и стартирам базата


Baramov, Kamen (Oracle DBA) 11:56 AM: 
не не
Baramov, Kamen (Oracle DBA) 11:56 AM: 
първо се спира аплая, после базата
Baramov, Kamen (Oracle DBA) 11:57 AM: 
после се пуска базата (вероятно автоматично на новия нод), после се пуска аплая




