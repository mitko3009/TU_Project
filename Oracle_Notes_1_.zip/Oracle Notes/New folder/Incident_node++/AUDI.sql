﻿################################################################
################################################################
######## Set environment on AUDI ##########

dbset <db_name>


###### Ot ivmg700 ---> fast checks

nodeset -ll
#1592834557
clush -g MBBPreLive 'ps -ef | grep pmon'
#1592834583
clush --help


clush -g MBBPreLive 'srvctl status service -db P55009'
clush -w <node>,<node>,<node> 'ps -ef | grep pmon'


#####################################
######################################

#### Когато са разместени инстансите се наместват така:
srvctl modify instance -d <db_name> -i <db_instance> -n <node_name>

ama 
no tova bih mogal da go plqsna ako da rechem osven razmestvane po nodes
se bqha razmenili i cifrite
t.e. P55006_1  da e P55006_3
v segashniq sluchai trqbva e-change ili normalen v zavisimost poneje za da go fixna si e downtime
poneje kato mu kaja P55006_1 zapali na iudb771 i P55006_2 pali na 787
ako tragna da gi spiram samo instance by instance shte stane kakafoniq


################################
################################


#### Намествам пърмишъни


Fixing permissions issue with grid binaries:

As a root

cd $ORACLE_HOME/crs/install
/u01/app/12.2.0.1/grid/crs/install/rootcrs.sh -unlock

/u01/app/12.2.0.1/grid/crs/install/rootcrs.sh -init

/u01/app/12.2.0.1/grid/crs/install/rootcrs.sh -lock

crsctl start crs

####
cluvfy comp software -n all -verbose



##################################
##################################
CHECK FOR LOW FREE SPACE IN TABLESPACESS: AUDI(TABLESPACE 006 metric)


select df.tablespace_name "Tablespace",
totalusedspace "Used MB",
(df.totalspace - tu.totalusedspace) "Free MB",
df.totalspace "Total MB",
round(100 * ( (df.totalspace - tu.totalusedspace)/ df.totalspace))
"Pct. Free"
from
(select tablespace_name,
round(sum(bytes) / 1048576) TotalSpace
from dba_data_files 
group by tablespace_name) df,
(select round(sum(bytes)/(1024*1024)) totalusedspace, tablespace_name
from dba_segments 
group by tablespace_name) tu
where df.tablespace_name = tu.tablespace_name ;


####################################
#####################################
######## M6 IN QUERY ###


set lines 250
set pages 40
col 1 noprint;
break on 1
compute sum of megs_alloc on 1
compute sum of megs_free on 1
compute sum of megs_used on 1
compute sum of megs_max on 1
select 1, a.tablespace_name,
       round(a.bytes_alloc / 1024 / 1024, 2) megs_alloc,
       round(nvl(b.bytes_free, 0) / 1024 / 1024, 2) megs_free,
       round((a.bytes_alloc - nvl(b.bytes_free, 0)) / 1024 / 1024, 2) megs_used,
       round((nvl(b.bytes_free, 0) / a.bytes_alloc) * 100,2) Pct_Free,
       100 - round((nvl(b.bytes_free, 0) / a.bytes_alloc) * 100,2) Pct_used,
       round(maxbytes/1048576,2) Megs_max,
      round(100*(round((a.bytes_alloc - nvl(b.bytes_free, 0)) / 1024 / 1024, 2))/(round(maxbytes/1048576,2)),2) pct_used_max
from ( select f.tablespace_name,
               sum(f.bytes) bytes_alloc,
               sum(decode(f.autoextensible, 'YES', CASE WHEN f.maxbytes >= f.bytes THEN f.maxbytes ELSE f.bytes END, 'NO', f.bytes)) maxbytes
        from dba_data_files f
        group by tablespace_name) a,
      ( select f.tablespace_name,
               sum(f.bytes) bytes_free
        from dba_free_space f
        group by tablespace_name) b
where a.tablespace_name = b.tablespace_name (+)
union
select 1, h.tablespace_name,
       round(sum(h.bytes_free + h.bytes_used) / 1048576, 2),
       round(sum((h.bytes_free + h.bytes_used) - nvl(p.bytes_used, 0)) / 1048576, 2),
       round(sum(nvl(p.bytes_used, 0))/ 1048576, 2) megs_used,
       round((sum((h.bytes_free + h.bytes_used) - nvl(p.bytes_used, 0)) / sum(h.bytes_used + h.bytes_free)) * 100,2),
       100 - round((sum((h.bytes_free + h.bytes_used) - nvl(p.bytes_used, 0)) / sum(h.bytes_used + h.bytes_free)) * 100,2),
       round(sum(decode(f.autoextensible, 'YES', CASE WHEN f.maxbytes >= (h.bytes_used + h.bytes_free) THEN f.maxbytes ELSE (h.bytes_used + h.bytes_free) END, 'NO', f.bytes)) / 1048576, 2) Max,
       round(100*(round(sum(nvl(p.bytes_used, 0))/ 1048576, 2))/(round(sum(decode(f.autoextensible, 'YES', CASE WHEN f.maxbytes >= (h.bytes_used + h.bytes_free) THEN f.maxbytes ELSE (h.bytes_used + h.bytes_free) END, 'NO', f.bytes)) / 1048576, 2)),2)
from sys.v_$TEMP_SPACE_HEADER h, sys.v_$Temp_extent_pool p, dba_temp_files f
where p.file_id(+) = h.file_id
and p.tablespace_name(+) = h.tablespace_name
and h.file_id = f.file_id
and h.tablespace_name = f.tablespace_name
group by h.tablespace_name
ORDER BY PCT_USED_MAX desc;





###################################################
################## Check disk group size ##########


[grid@iudb771(Production) ~]$ asmcmd lsdg
State    Type    Rebal  Sector  Logical_Sector  Block       AU   Total_MB   Free_MB  Req_mir_free_MB  Usable_file_MB  Offline_disks  Voting_files  Name
MOUNTED  NORMAL  N         512             512   4096  4194304   10239920   5957832          1023992         2466920              0             N  ACFS/
MOUNTED  NORMAL  N         512             512   4096  4194304   45055648   4230844          1023992         1603426              0             N  BACKUPS/
MOUNTED  NORMAL  N         512             512   4096  4194304    3071976   2881440          1023992          928724              0             N  DATA/
MOUNTED  NORMAL  N         512             512   4096  4194304   31743752   6695584          1023992         2835796              0             N  DATA1/



[‎6/‎23/‎2020 10:21 PM]  Shterev, Ivaylo:  

SET LINESIZE  200
SET PAGESIZE  9999
SET VERIFY    off 
COLUMN disk_group_name        FORMAT a20           HEAD 'Disk Group Name'
COLUMN disk_file_path         FORMAT a40           HEAD 'Path'
COLUMN disk_file_name         FORMAT a20           HEAD 'File Name'
COLUMN disk_file_fail_group   FORMAT a20           HEAD 'Fail Group'
COLUMN total_mb               FORMAT 999,999,999   HEAD 'File Size (MB)'
COLUMN used_mb                FORMAT 999,999,999   HEAD 'Used Size (MB)'
COLUMN pct_used               FORMAT 999.99        HEAD 'Pct. Used'
COLUMN State				  FORMAT a20           HEAD 'State'
break on report on disk_group_name skip 1
compute sum label ""              of total_mb used_mb on disk_group_name
compute sum label "Grand Total: " of total_mb used_mb on report
SELECT
 GROUP_NUMBER          Group_number
  , NVL(a.name, '[CANDIDATE]')                       disk_group_name
  , b.path                                           disk_file_path
  , b.name                                           disk_file_name
  , b.failgroup                                      disk_file_fail_group
  , b.total_mb                                       total_mb
 , (b.total_mb - b.free_mb)                         used_mb,
 a.STATE                                            State
--  , ROUND((1- (b.free_mb / b.total_mb))*100, 2)      pct_used
FROM
	v$asm_diskgroup a RIGHT OUTER JOIN v$asm_disk b USING (group_number)
ORDER BY b.name
/ 
 



###############################
################################
####Check diskgroup status

col DG_NAME for a15
col NAME for a20
col PATH for a60
select d.inst_id,dg.name dg_name,dg.state dg_state,dg.type,d.name,d.DISK_NUMBER dsk_no,d.MOUNT_STATUS,d.HEADER_STATUS,d.MODE_STATUS,d.STATE,d.PATH,d.FAILGROUP FROM GV$ASM_DISK d,gv$asm_diskgroup dg
where dg.group_number(+)=d.group_number and d.inst_id = dg.inst_id order by dg_name;


###################################
###################################
#### Start disk group ONLINE
alter diskgroup DATA online all;



################
################
#### Check disk group size ###
select name, total_mb, free_mb, usable_file_mb,
round(((total_mb-nvl(free_mb,0))/total_mb)*100,0) percent_used
from v$ASM_DISKGROUP_STAT;



##############################
####### LIST DISK GROUP, FILEPATH STATUS (ASM)

set pages 1000
col path format a40
set lines 200
col failgroup format a30
col path format a40
select GROUP_NUMBER,NAME, STATE, MOUNT_STATUS,MODE_STATUS, HEADER_STATUS, FAILGROUP,PATH, TOTAL_MB,FREE_MB,OS_MB, MOUNT_DATE from v$asm_disk; 


##########################
##########################
set lines 300
col Name for a25
select NAME,SPACE_LIMIT/1024/1024/1024 "SPACE LIMIT(GB)",
round(SPACE_USED/1024/1024/1024) "SPACE USED(GB)",round(SPACE_RECLAIMABLE/1024/1024/1024) "SPACE RECLAIMABLE(GB)",NUMBER_OF_FILES
from V$RECOVERY_FILE_DEST;

NAME                      SPACE LIMIT(GB) SPACE USED(GB) SPACE RECLAIMABLE(GB) NUMBER_OF_FILES
------------------------- --------------- -------------- --------------------- ---------------
+FRA4                                 700            324                   324            4604


##############################
##### CHECK WHICH DISKGROUP IS MOUNT ######

##with su - grid

asmcmd

lsdg

lsdsk

##### Mount disk group ####
su - grid
sqlplus / as sysasm
SQL> ALTER DISKGROUP DATA MOUNT



###############################
###############################
#####  Check User status and profile

select username,account_status,default_tablespace,profile from dba_users;

select username,account_status,default_tablespace,profile from dba_users where username like'%А4%';




SELECT USERNAME, ACCOUNT_STATUS, LOCK_DATE FROM DBA_USERS WHERE USERNAME like 'U4MM%' and PROFILE='AUDI_U4USER_PROFILE';




############################
##############################
## Find datafile 
select FILE_NAME,FILE_ID,TABLESPACE_NAME,BYTES,STATUS from DBA_DATA_FILES;



==========================================================================
==========================================================================







