############################################################
#### WBS ######

FORTUM - FI1-FO001.10.24.02
LOGISTA - ES1-1LO63.10.01
VOBE - BE1-VOI23.02.01.02

MLP -  DE1-ML009.10.40.01

OGE - DE1-OG002.10.48.02
EON - DE1-EORUN.10.01.07
HUS - FI1-HUSUS.10.01.03-attribute ORACLE
    --> new  WBS --> FI1-HUSUS.10.23
	
TK - DE1-TA012.01.32
GEFA - DE1-GE001.10.21
MEWA - DE1-MEWA2.10.09.01
SIDEL - SE1-SI001.10.23.13.11    --->trqbva Incident ID
OSDO - US1-ESM06.70.12
VAILLANT - DE1-VG001.10.16.10
KFGROUP - SE1-COOP1.10.01   ----> trqbva Incident ID attribute DB/ORACLE
ROBR - NL1-RB060.10.13 -----> Attribute ORACLE
AUDI - DE1-AW009.10.01
KSB - DE1-KSB15.10.02.03
CACF-BANKIA - ES1-7CAF1.10.20
ApoBank - DE1-APO21.01.02.02 
FCC - ES1-1PX02.10.03
DXC Enterprise Cloud Services (cCell Services) -DE1-CS003.01.03.11
BNP Paribas Fortis - BE1-IP001.10.02.55
cCELL - DE1-CS003.01.03.11

Kaercher - DE1-UN001.10.06

BANKIA - ne mi dava da sloja WBS
