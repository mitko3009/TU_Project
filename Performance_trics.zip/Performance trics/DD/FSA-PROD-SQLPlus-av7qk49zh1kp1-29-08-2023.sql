/********************************************************************************
*********       E-mail subject: FSADEV-104
*********             Instance: PROD
*********          Description: 
Problem:
The provided SQL was slow on PROD.

Analysis:
The problem was inapropriate execution plan.

Suggestion:
1. Please set module for this script, so it could be easily identifiable in the DB.
   You can use exec dbms_application_info.set_module('BASKET_TIMEOUT',null); for example.
   
2. Please ask C&D to create an index on G_INDIVIDU(BASKET_TIMEOUT_DT).

3. Please ask C&D to create an index on G_INFORMATION(DATE2_DT).

4. Please modify the SQL from BASKET_TIMEOUT.prc as shown in the New SQL section below.

*********               SQL_ID: av7qk49zh1kp1
*********      Program/Package: BASKET_TIMEOUT.prc
*********              Request: Ivan Georgiev
*********               Author: Dimitar Dimitrov
********* Received e-mail date: 29/08/2023
*********      Resolution date: 29/08/2023
*********  Trace old file here: \\epox\specifs\performance\tmp\
*********  Trace new file here:
***********************************************************************************/

/********************************OLD SQL*******************************************/
SELECT EN.REFPIECE           EN_REFPIECE,
       EN.GPIROLE            SALE_ID,
       EN.REFDOSS,
       EN.GPIREFNOTAIRE      NUM_LOT,
       LOT.NB03,
       LOT.REFIMAGE,
       VENTE.DATE2_DT        SALE_END_DT,
       IND.BASKET_TIMEOUT_DT BASKET_TIMEOUT_DT,
       IND.REFINDIVIDU       REFINDIVIDU
  FROM G_PIECE        EN,
       G_PIECE        LOT,
       G_INFORMATION  VENTE,
       G_INDIVIDU     IND,
       T_INTERVENANTS INTR
 WHERE EN.TYPPIECE = 'ENCHERE'
   AND EN.FG11 = 2
   AND EN.LIBELLE_100_2 IS NULL
   AND VENTE.REFTXT = 'VENTE'
   AND LOT.NB01 = EN.GPIREFNOTAIRE
   AND LOT.GPIROLE = EN.GPIROLE
   AND EN.GPIROLE = VENTE.REFINFO
   AND VENTE.TYPEMEDIA = 'vente flash'
   AND INTR.REFINDIVIDU = IND.REFINDIVIDU
   AND EN.REFDOSS = INTR.REFDOSS
   AND (TO_CHAR(IND.BASKET_TIMEOUT_DT + (1 / 1440 * 1),
                'dd/mm/yyyy HH24:mi') = TO_CHAR(:B2, 'dd/mm/yyyy HH24:mi') OR
       TO_CHAR(VENTE.DATE2_DT + (1 / 1440 * 1), 'dd/mm/yyyy HH24:mi') =
       TO_CHAR(:B2, 'dd/mm/yyyy HH24:mi') OR
       TO_CHAR(:B2 + (1 / 1440 * :B1), 'dd/mm/yyyy HH24:mi') =
       TO_CHAR(IND.BASKET_TIMEOUT_DT, 'dd/mm/yyyy HH24:mi'))
 ORDER BY REFINDIVIDU, EN.GPIROLE, LOT.NB03;
/********************************OLD SQL*******************************************/
/********************************OLD Metrics***************************************/
/*
Plan hash value: 2494636269
-----------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                 | Name                        | Starts | E-Rows | A-Rows |   A-Time   | Buffers |
-----------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                          |                             |      1 |        |      0 |00:00:05.56 |    1359K|
|   1 |  SORT ORDER BY                            |                             |      1 |      1 |      0 |00:00:05.56 |    1359K|
|   2 |   NESTED LOOPS                            |                             |      1 |      1 |      0 |00:00:05.56 |    1359K|
|   3 |    NESTED LOOPS                           |                             |      1 |     25 |     26 |00:00:05.56 |    1359K|
|   4 |     NESTED LOOPS                          |                             |      1 |     25 |     26 |00:00:05.56 |    1359K|
|   5 |      NESTED LOOPS                         |                             |      1 |     13 |     13 |00:00:05.56 |    1359K|
|   6 |       NESTED LOOPS                        |                             |      1 |  28769 |     21 |00:00:05.56 |    1359K|
|*  7 |        TABLE ACCESS BY INDEX ROWID BATCHED| G_INFORMATION               |      1 |   3769 |   2750 |00:00:00.02 |   10618 |
|*  8 |         INDEX RANGE SCAN                  | G_INFORMATION$REFTXT        |      1 |  26383 |  23082 |00:00:00.01 |      62 |
|*  9 |        TABLE ACCESS BY INDEX ROWID BATCHED| G_PIECE                     |   2750 |      8 |     21 |00:00:05.54 |    1348K|
|* 10 |         INDEX RANGE SCAN                  | G_PIECE$ID_VENTE            |   2750 |    131 |   2345K|00:00:00.41 |   16152 |
|  11 |       TABLE ACCESS BY INDEX ROWID BATCHED | G_PIECE                     |     21 |      1 |     13 |00:00:00.01 |      51 |
|* 12 |        INDEX RANGE SCAN                   | G_PIEC_NB1_ROL_TYPP_NB2_IDX |     21 |      3 |     13 |00:00:00.01 |      44 |
|* 13 |      INDEX RANGE SCAN                     | INT_DOS_INDIV               |     13 |      2 |     26 |00:00:00.01 |      28 |
|* 14 |     INDEX UNIQUE SCAN                     | GING_REFIND_UIDX            |     26 |      1 |     26 |00:00:00.01 |      54 |
|* 15 |    TABLE ACCESS BY INDEX ROWID            | G_INDIVIDU                  |     26 |      1 |      0 |00:00:00.01 |      47 |
-----------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   7 - filter("VENTE"."TYPEMEDIA"='vente flash')
   8 - access("VENTE"."REFTXT"='VENTE')
   9 - filter(("EN"."REFDOSS" IS NOT NULL AND TO_NUMBER("EN"."FG11")=2 AND "EN"."LIBELLE_100_2" IS NULL))
  10 - access("EN"."GPIROLE"="VENTE"."REFINFO" AND "EN"."TYPPIECE"='ENCHERE')
       filter("EN"."GPIROLE" IS NOT NULL)
  12 - access("LOT"."NB01"=TO_NUMBER("EN"."GPIREFNOTAIRE") AND "LOT"."GPIROLE"="EN"."GPIROLE")
       filter("LOT"."GPIROLE" IS NOT NULL)
  13 - access("EN"."REFDOSS"="INTR"."REFDOSS")
  14 - access("INTR"."REFINDIVIDU"="IND"."REFINDIVIDU")
  15 - filter((TO_CHAR(INTERNAL_FUNCTION("IND"."BASKET_TIMEOUT_DT")+.000694444444444444444444444444444444444444,'dd/mm/yyyy
               HH24:mi')=TO_CHAR(TO_DATE(TO_CHAR(TO_DATE(:B2,'mm/dd/yyyy hh24:mi:ss')),'mm/dd/yyyy hh24:mi:ss'),'dd/mm/yyyy HH24:mi') OR
              TO_CHAR(INTERNAL_FUNCTION("VENTE"."DATE2_DT")+.000694444444444444444444444444444444444444,'dd/mm/yyyy
              HH24:mi')=TO_CHAR(TO_DATE(:B2,'mm/dd/yyyy hh24:mi:ss'),'dd/mm/yyyy HH24:mi') OR
              TO_CHAR(INTERNAL_FUNCTION("IND"."BASKET_TIMEOUT_DT"),'dd/mm/yyyy HH24:mi')=TO_CHAR(TO_DATE(:B2,'mm/dd/yyyy
              hh24:mi:ss')+.000694444444444444444444444444444444444444*:B1,'dd/mm/yyyy HH24:mi')))
 
 
*/
/********************************OLD Metrics***************************************/

/********************************New SQL*******************************************/
SELECT EN.REFPIECE           EN_REFPIECE,
       EN.GPIROLE            SALE_ID,
       EN.REFDOSS,
       EN.GPIREFNOTAIRE      NUM_LOT,
       LOT.NB03,
       LOT.REFIMAGE,
       VENTE.DATE2_DT        SALE_END_DT,
       IND.BASKET_TIMEOUT_DT BASKET_TIMEOUT_DT,
       IND.REFINDIVIDU       REFINDIVIDU
  FROM G_PIECE        EN,
       G_PIECE        LOT,
       G_INFORMATION  VENTE,
       G_INDIVIDU     IND,
       T_INTERVENANTS INTR
 WHERE EN.TYPPIECE = 'ENCHERE'
   AND EN.FG11 = '2'
   AND EN.LIBELLE_100_2 IS NULL
   AND VENTE.REFTXT = 'VENTE'
   AND LOT.NB01 = EN.GPIREFNOTAIRE
   AND LOT.GPIROLE = EN.GPIROLE
   AND EN.GPIROLE = VENTE.REFINFO
   AND VENTE.TYPEMEDIA = 'vente flash'
   AND INTR.REFINDIVIDU = IND.REFINDIVIDU
   AND EN.REFDOSS = INTR.REFDOSS
   AND IND.BASKET_TIMEOUT_DT >= trunc(to_date(:B2,'dd/mm/yyyy hh24:mi:ss'),'MI') - (1 / 1440 * 1)
   AND IND.BASKET_TIMEOUT_DT < trunc(to_date(:B2,'dd/mm/yyyy hh24:mi:ss'),'MI')
 UNION
SELECT EN.REFPIECE           EN_REFPIECE,
       EN.GPIROLE            SALE_ID,
       EN.REFDOSS,
       EN.GPIREFNOTAIRE      NUM_LOT,
       LOT.NB03,
       LOT.REFIMAGE,
       VENTE.DATE2_DT        SALE_END_DT,
       IND.BASKET_TIMEOUT_DT BASKET_TIMEOUT_DT,
       IND.REFINDIVIDU       REFINDIVIDU
  FROM G_PIECE        EN,
       G_PIECE        LOT,
       G_INFORMATION  VENTE,
       G_INDIVIDU     IND,
       T_INTERVENANTS INTR
 WHERE EN.TYPPIECE = 'ENCHERE'
   AND EN.FG11 = '2'
   AND EN.LIBELLE_100_2 IS NULL
   AND VENTE.REFTXT = 'VENTE'
   AND LOT.NB01 = EN.GPIREFNOTAIRE
   AND LOT.GPIROLE = EN.GPIROLE
   AND EN.GPIROLE = VENTE.REFINFO
   AND VENTE.TYPEMEDIA = 'vente flash'
   AND INTR.REFINDIVIDU = IND.REFINDIVIDU
   AND EN.REFDOSS = INTR.REFDOSS
   AND VENTE.DATE2_DT >= trunc(to_date(:B2,'dd/mm/yyyy hh24:mi:ss'),'MI') - (1 / 1440 * 1)
   AND VENTE.DATE2_DT < trunc(to_date(:B2,'dd/mm/yyyy hh24:mi:ss'),'MI')
 UNION
SELECT EN.REFPIECE           EN_REFPIECE,
       EN.GPIROLE            SALE_ID,
       EN.REFDOSS,
       EN.GPIREFNOTAIRE      NUM_LOT,
       LOT.NB03,
       LOT.REFIMAGE,
       VENTE.DATE2_DT        SALE_END_DT,
       IND.BASKET_TIMEOUT_DT BASKET_TIMEOUT_DT,
       IND.REFINDIVIDU       REFINDIVIDU
  FROM G_PIECE        EN,
       G_PIECE        LOT,
       G_INFORMATION  VENTE,
       G_INDIVIDU     IND,
       T_INTERVENANTS INTR
 WHERE EN.TYPPIECE = 'ENCHERE'
   AND EN.FG11 = '2'
   AND EN.LIBELLE_100_2 IS NULL
   AND VENTE.REFTXT = 'VENTE'
   AND LOT.NB01 = EN.GPIREFNOTAIRE
   AND LOT.GPIROLE = EN.GPIROLE
   AND EN.GPIROLE = VENTE.REFINFO
   AND VENTE.TYPEMEDIA = 'vente flash'
   AND INTR.REFINDIVIDU = IND.REFINDIVIDU
   AND EN.REFDOSS = INTR.REFDOSS
   AND IND.BASKET_TIMEOUT_DT >= trunc(to_date(:B2,'dd/mm/yyyy hh24:mi:ss'),'MI') + (1 / 1440 * :B1)
   AND IND.BASKET_TIMEOUT_DT < trunc(to_date(:B2,'dd/mm/yyyy hh24:mi:ss'),'MI') + (1 / 1440 * :B1) + (1 / 1440)
ORDER BY REFINDIVIDU, SALE_ID, NB03;
/********************************New SQL*******************************************/
/********************************New Metrics***************************************/
/*
CREATE INDEX TEST_DI_IND_IDX1 ON G_INDIVIDU(BASKET_TIMEOUT_DT);
exec DBMS_STATS.GATHER_INDEX_STATS(ownname => user, indname => 'TEST_DI_IND_IDX1', ESTIMATE_PERCENT => dbms_stats.auto_sample_size, degree => 1, force => true, no_invalidate => false);

CREATE INDEX TEST_DI_INF_IDX1 ON G_INFORMATION(DATE2_DT);
exec DBMS_STATS.GATHER_INDEX_STATS(ownname => user, indname => 'TEST_DI_INF_IDX1', ESTIMATE_PERCENT => dbms_stats.auto_sample_size, degree => 1, force => true, no_invalidate => false);

Plan hash value: 1803450847
-------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                                   | Name                        | Starts | E-Rows | A-Rows |   A-Time   | Buffers |
-------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                            |                             |      1 |        |      0 |00:00:00.01 |      28 |
|   1 |  SORT UNIQUE                                |                             |      1 |      3 |      0 |00:00:00.01 |      28 |
|   2 |   UNION-ALL                                 |                             |      1 |        |      0 |00:00:00.01 |      28 |
|*  3 |    FILTER                                   |                             |      1 |        |      0 |00:00:00.01 |      24 |
|   4 |     NESTED LOOPS                            |                             |      1 |      1 |      0 |00:00:00.01 |      24 |
|   5 |      NESTED LOOPS                           |                             |      1 |      3 |      0 |00:00:00.01 |      24 |
|   6 |       NESTED LOOPS                          |                             |      1 |      1 |      0 |00:00:00.01 |      24 |
|   7 |        NESTED LOOPS                         |                             |      1 |      2 |      0 |00:00:00.01 |      24 |
|   8 |         NESTED LOOPS                        |                             |      1 |      2 |      3 |00:00:00.01 |      13 |
|   9 |          TABLE ACCESS BY INDEX ROWID BATCHED| G_INDIVIDU                  |      1 |      1 |      3 |00:00:00.01 |       5 |
|* 10 |           INDEX RANGE SCAN                  | TEST_DI_IND_IDX1            |      1 |     11 |      3 |00:00:00.01 |       2 |
|* 11 |          INDEX RANGE SCAN                   | INT_INDIV                   |      3 |      2 |      3 |00:00:00.01 |       8 |
|* 12 |         TABLE ACCESS BY INDEX ROWID BATCHED | G_PIECE                     |      3 |      1 |      0 |00:00:00.01 |      11 |
|* 13 |          INDEX RANGE SCAN                   | GP_FG11_IDW_IDX             |      3 |     17 |      0 |00:00:00.01 |      11 |
|* 14 |        TABLE ACCESS BY INDEX ROWID          | G_INFORMATION               |      0 |      1 |      0 |00:00:00.01 |       0 |
|* 15 |         INDEX UNIQUE SCAN                   | REF_INFORMATION             |      0 |      1 |      0 |00:00:00.01 |       0 |
|* 16 |       INDEX RANGE SCAN                      | G_PIEC_NB1_ROL_TYPP_NB2_IDX |      0 |      3 |      0 |00:00:00.01 |       0 |
|  17 |      TABLE ACCESS BY INDEX ROWID            | G_PIECE                     |      0 |      1 |      0 |00:00:00.01 |       0 |
|* 18 |    FILTER                                   |                             |      1 |        |      0 |00:00:00.01 |       2 |
|  19 |     NESTED LOOPS                            |                             |      1 |      1 |      0 |00:00:00.01 |       2 |
|  20 |      NESTED LOOPS                           |                             |      1 |      3 |      0 |00:00:00.01 |       2 |
|  21 |       NESTED LOOPS                          |                             |      1 |      1 |      0 |00:00:00.01 |       2 |
|  22 |        NESTED LOOPS                         |                             |      1 |      1 |      0 |00:00:00.01 |       2 |
|  23 |         NESTED LOOPS                        |                             |      1 |      1 |      0 |00:00:00.01 |       2 |
|* 24 |          TABLE ACCESS BY INDEX ROWID BATCHED| G_INFORMATION               |      1 |      1 |      0 |00:00:00.01 |       2 |
|* 25 |           INDEX RANGE SCAN                  | TEST_DI_INF_IDX1            |      1 |      4 |      0 |00:00:00.01 |       2 |
|* 26 |          TABLE ACCESS BY INDEX ROWID BATCHED| G_PIECE                     |      0 |      8 |      0 |00:00:00.01 |       0 |
|* 27 |           INDEX RANGE SCAN                  | G_PIECE$ID_VENTE            |      0 |    131 |      0 |00:00:00.01 |       0 |
|* 28 |         INDEX RANGE SCAN                    | INT_DOS_INDIV               |      0 |      2 |      0 |00:00:00.01 |       0 |
|  29 |        TABLE ACCESS BY INDEX ROWID          | G_INDIVIDU                  |      0 |      1 |      0 |00:00:00.01 |       0 |
|* 30 |         INDEX UNIQUE SCAN                   | GING_REFIND_UIDX            |      0 |      1 |      0 |00:00:00.01 |       0 |
|* 31 |       INDEX RANGE SCAN                      | G_PIEC_NB1_ROL_TYPP_NB2_IDX |      0 |      3 |      0 |00:00:00.01 |       0 |
|  32 |      TABLE ACCESS BY INDEX ROWID            | G_PIECE                     |      0 |      1 |      0 |00:00:00.01 |       0 |
|* 33 |    FILTER                                   |                             |      1 |        |      0 |00:00:00.01 |       2 |
|  34 |     NESTED LOOPS                            |                             |      1 |      1 |      0 |00:00:00.01 |       2 |
|  35 |      NESTED LOOPS                           |                             |      1 |      3 |      0 |00:00:00.01 |       2 |
|  36 |       NESTED LOOPS                          |                             |      1 |      1 |      0 |00:00:00.01 |       2 |
|  37 |        NESTED LOOPS                         |                             |      1 |      2 |      0 |00:00:00.01 |       2 |
|  38 |         NESTED LOOPS                        |                             |      1 |      2 |      0 |00:00:00.01 |       2 |
|  39 |          TABLE ACCESS BY INDEX ROWID BATCHED| G_INDIVIDU                  |      1 |      1 |      0 |00:00:00.01 |       2 |
|* 40 |           INDEX RANGE SCAN                  | TEST_DI_IND_IDX1            |      1 |     11 |      0 |00:00:00.01 |       2 |
|* 41 |          INDEX RANGE SCAN                   | INT_INDIV                   |      0 |      2 |      0 |00:00:00.01 |       0 |
|* 42 |         TABLE ACCESS BY INDEX ROWID BATCHED | G_PIECE                     |      0 |      1 |      0 |00:00:00.01 |       0 |
|* 43 |          INDEX RANGE SCAN                   | GP_FG11_IDW_IDX             |      0 |     17 |      0 |00:00:00.01 |       0 |
|* 44 |        TABLE ACCESS BY INDEX ROWID          | G_INFORMATION               |      0 |      1 |      0 |00:00:00.01 |       0 |
|* 45 |         INDEX UNIQUE SCAN                   | REF_INFORMATION             |      0 |      1 |      0 |00:00:00.01 |       0 |
|* 46 |       INDEX RANGE SCAN                      | G_PIEC_NB1_ROL_TYPP_NB2_IDX |      0 |      3 |      0 |00:00:00.01 |       0 |
|  47 |      TABLE ACCESS BY INDEX ROWID            | G_PIECE                     |      0 |      1 |      0 |00:00:00.01 |       0 |
-------------------------------------------------------------------------------------------------------------------------------------
Predicate Information (identified by operation id):
---------------------------------------------------
   3 - filter(TRUNC(TO_DATE(:B2,'dd/mm/yyyy hh24:mi:ss'),'fmmi')>TRUNC(TO_DATE(:B2,'dd/mm/yyyy
              hh24:mi:ss'),'fmmi')-.000694444444444444444444444444444444444444)
  10 - access("IND"."BASKET_TIMEOUT_DT">=TRUNC(TO_DATE(:B2,'dd/mm/yyyy
              hh24:mi:ss'),'fmmi')-.000694444444444444444444444444444444444444 AND "IND"."BASKET_TIMEOUT_DT"<TRUNC(TO_DATE(:B2,'dd/mm/yyyy
              hh24:mi:ss'),'fmmi'))
  11 - access("INTR"."REFINDIVIDU"="IND"."REFINDIVIDU")
  12 - filter(("EN"."LIBELLE_100_2" IS NULL AND "EN"."GPIROLE" IS NOT NULL))
  13 - access("EN"."FG11"='2' AND "EN"."REFDOSS"="INTR"."REFDOSS" AND "EN"."TYPPIECE"='ENCHERE')
       filter("EN"."REFDOSS" IS NOT NULL)
  14 - filter(("VENTE"."TYPEMEDIA"='vente flash' AND "VENTE"."REFTXT"='VENTE'))
  15 - access("EN"."GPIROLE"="VENTE"."REFINFO")
  16 - access("LOT"."NB01"=TO_NUMBER("EN"."GPIREFNOTAIRE") AND "LOT"."GPIROLE"="EN"."GPIROLE")
       filter("LOT"."GPIROLE" IS NOT NULL)
  18 - filter(TRUNC(TO_DATE(:B2,'dd/mm/yyyy hh24:mi:ss'),'fmmi')>TRUNC(TO_DATE(:B2,'dd/mm/yyyy
              hh24:mi:ss'),'fmmi')-.000694444444444444444444444444444444444444)
  24 - filter(("VENTE"."TYPEMEDIA"='vente flash' AND "VENTE"."REFTXT"='VENTE'))
  25 - access("VENTE"."DATE2_DT">=TRUNC(TO_DATE(:B2,'dd/mm/yyyy
              hh24:mi:ss'),'fmmi')-.000694444444444444444444444444444444444444 AND "VENTE"."DATE2_DT"<TRUNC(TO_DATE(:B2,'dd/mm/yyyy
              hh24:mi:ss'),'fmmi'))
  26 - filter(("EN"."FG11"='2' AND "EN"."REFDOSS" IS NOT NULL AND "EN"."LIBELLE_100_2" IS NULL))
  27 - access("EN"."GPIROLE"="VENTE"."REFINFO" AND "EN"."TYPPIECE"='ENCHERE')
       filter("EN"."GPIROLE" IS NOT NULL)
  28 - access("EN"."REFDOSS"="INTR"."REFDOSS")
  30 - access("INTR"."REFINDIVIDU"="IND"."REFINDIVIDU")
  31 - access("LOT"."NB01"=TO_NUMBER("EN"."GPIREFNOTAIRE") AND "LOT"."GPIROLE"="EN"."GPIROLE")
       filter("LOT"."GPIROLE" IS NOT NULL)
  33 - filter(TRUNC(TO_DATE(:B2,'dd/mm/yyyy hh24:mi:ss'),'fmmi')+.000694444444444444444444444444444444444444*:B1+.00069444444
              4444444444444444444444444444444>TRUNC(TO_DATE(:B2,'dd/mm/yyyy hh24:mi:ss'),'fmmi')+.00069444444444444444444444444444444444444
              4*:B1)
  40 - access("IND"."BASKET_TIMEOUT_DT">=TRUNC(TO_DATE(:B2,'dd/mm/yyyy
              hh24:mi:ss'),'fmmi')+.000694444444444444444444444444444444444444*:B1 AND
              "IND"."BASKET_TIMEOUT_DT"<TRUNC(TO_DATE(:B2,'dd/mm/yyyy hh24:mi:ss'),'fmmi')+.000694444444444444444444444444444444444444*:B1+
              .000694444444444444444444444444444444444444)
  41 - access("INTR"."REFINDIVIDU"="IND"."REFINDIVIDU")
  42 - filter(("EN"."LIBELLE_100_2" IS NULL AND "EN"."GPIROLE" IS NOT NULL))
  43 - access("EN"."FG11"='2' AND "EN"."REFDOSS"="INTR"."REFDOSS" AND "EN"."TYPPIECE"='ENCHERE')
       filter("EN"."REFDOSS" IS NOT NULL)
  44 - filter(("VENTE"."TYPEMEDIA"='vente flash' AND "VENTE"."REFTXT"='VENTE'))
  45 - access("EN"."GPIROLE"="VENTE"."REFINFO")
  46 - access("LOT"."NB01"=TO_NUMBER("EN"."GPIREFNOTAIRE") AND "LOT"."GPIROLE"="EN"."GPIROLE")
       filter("LOT"."GPIROLE" IS NOT NULL)
*/
/********************************New Metrics***************************************/

/********************************Index statistics**********************************/

/********************************Other SQLs****************************************/          
/*

*/ 
/********************************Other SQLs****************************************/              
