######## CHECK ######

[root@fivatx0014 ~]# ps -ef | grep pmon
root      7736  5908  0 08:00 pts/1    00:00:00 grep pmon
oracle   44986     1  0  2018 ?        01:40:22 ora_pmon_OEM12


[root@fivatx0014 ~]# ps -ef | grep tns
root       135     2  0  2018 ?        00:00:00 [netns]
root      7766  5908  0 08:00 pts/1    00:00:00 grep tns
oracle   26276     1  0  2018 ?        00:44:13 /oracle/app/oracle/product/11.2.0/dbhome_1/bin/tnslsnr LISTENER -inherit

[root@fivatx0014 ~]# uptime
 08:00:19 up 344 days, 13:47,  2 users,  load average: 2.19, 2.26, 2.18

[root@fivatx0014 ~]# dbmoncol
Use of uninitialized value in pattern match (m//) at /var/opt/OV/bin/instrumentation/dbmoncol.pl line 248, <CFG> line 1047.

ERROR: No arguments
Usage:
	dbmoncol LISTENER <listener owner> <listener name> <ON|OFF|AUTO>
	dbmoncol DATABASE <dbtype> <instance> <BACKUP|SCHEDULED_OUTAGE|STANDBY_CLUSTER|OFF|ON>
	dbmoncol -version

Examples:
	dbmoncol LISTENER ORACLE LISTENER OFF
	dbmoncol LISTENER ORACLE LISTENER1 ON
	dbmoncol LISTENER ORACLE LISTENER1 AUTO
	
	dbmoncol DATABASE ORACLE openview BACKUP
	dbmoncol DATABASE ORACLE openview SCHEDULED_OUTAGE
	dbmoncol DATABASE ORACLE openview STANDBY_CLUSTER
	dbmoncol DATABASE ORACLE openview OFF
	dbmoncol DATABASE ORACLE openview ON
	
	dbmoncol DATABASE PROGRESS instance_name ON
	dbmoncol DATABASE PROGRESS instance_name OFF
	
	dbmoncol DATABASE MYSQL instance_name ON
	dbmoncol DATABASE MYSQL instance_name OFF	
	
	dbmoncol -version


[root@fivatx0014 ~]# dbspicao -pdfv
Checking instance: 'OEM12' @ '/oracle/app/oracle/product/11.2.0/dbhome_1':
	Connect:	 OKAY
	Filter 6:	 OKAY
	Filter 4:	 OKAY


##### STOP MONITORING ####

[root@fivatx0014 ~]# dbmoncol DATABASE ORACLE OEM12 OFF

[root@fivatx0014 ~]# dbspicao -pdfv
DB-SPI Collection/Analysis has been turned OFF for instance OEM12


#### SWITCH LIKE ORACLE USER ######

[root@fivatx0014 ~]# su - oracle

         Present  Choices: 
==================================================
                                         
OEM12:/oracle/app/oracle/product/11.2.0/dbhome_1:N
                                         
   Current ORACLE_SID=OEM12 
==================================================
*****************************************************************
The following aliases are available
 * psora - Shows the processes that contains .ora. string
 * cdn - change to network/admin folder
 * sqldba - sqlplus / as sysdba
 * alertlog - tail -100 to the alert.log
 * cdo - change to ORACLE_HOME
 * lsnrstatus - lsnrctl status
********************************************************************
To set the environment for OEM12 type OEM12

oracle@fivatx0014:~[?1034hOEM12:/home/oracle:fivatx0014.adinfra.net # . oraenv
ORACLE_SID = [OEM12] ? OEM!@^H^H12        12

The Oracle base remains unchanged with value /oracle/app/oracle


oracle@fivatx0014:~OEM12:/home/oracle:fivatx0014.adinfra.net # cat /etc/oratab


# This file is used by ORACLE utilities.  It is created by root.sh
# and updated by either Database Configuration Assistant while creating
# a database or ASM Configuration Assistant while creating ASM instance.

# A colon, ':', is used as the field terminator.  A new line terminates
# the entry.  Lines beginning with a pound sign, '#', are comments.
#
# Entries are of the form:
#   $ORACLE_SID:$ORACLE_HOME:<N|Y>:
#
# The first and second fields are the system identifier and home
# directory of the database respectively.  The third filed indicates
# to the dbstart utility that the database should , "Y", or should not,
# "N", be brought up at system boot time.
#
# Multiple entries with the same $ORACLE_SID are not allowed.
#
#
OEM12:/oracle/app/oracle/product/11.2.0/dbhome_1:N
FIDO:/oracle/app/oracle/product/12.2.0.1/client:N

oracle@fivatx0014:~OEM12:/home/oracle:fivatx0014.adinfra.net # sqlplus / as sysdba

SQL*Plus: Release 11.2.0.3.0 Production on Sat May 25 08:02:32 2019

Copyright (c) 1982, 2011, Oracle.  All rights reserved.


Connected to:
Oracle Database 11g Enterprise Edition Release 11.2.0.3.0 - 64bit Production
With the Partitioning, OLAP, Data Mining and Real Application Testing options


####### SHUT DOWN IMMEDIATE ####

SQL> shu immediate
Database closed.
Database dismounted.
ORACLE instance shut down.

Broadcast message from dxtedy@fivatx0014.adinfra.net
	(/dev/pts/0) at 8:11 ...

The system is going down for reboot NOW!
Connection to fivatx0014.adinfra.net closed by remote host.
Connection to fivatx0014.adinfra.net closed.
